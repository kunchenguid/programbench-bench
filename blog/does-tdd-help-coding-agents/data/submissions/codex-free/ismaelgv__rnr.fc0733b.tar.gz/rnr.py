#!/usr/bin/env python3
import argparse
import json
import os
import re
import shutil
import sys
import unicodedata
from datetime import datetime


VERSION = "rnr 0.5.1"

TOP_HELP = """RnR is a command-line tool to rename multiple files and directories that
supports regular expressions


Usage: executable <COMMAND>

Commands:
  regex      Rename files and directories using a regular expression
  from-file  Read operations from a dump file
  to-ascii   Replace file name UTF-8 chars with ASCII chars representation
  help       Print this message or the help of the given subcommand(s)

Options:
  -h, --help     Print help
  -V, --version  Print version"""

REGEX_HELP = """Rename files and directories using a regular expression

Usage: executable regex [OPTIONS] <EXPRESSION> <REPLACEMENT> <PATH(S)>...

Arguments:
  <EXPRESSION>   Expression to match (can be a regex)
  <REPLACEMENT>  Expression replacement (use single quotes for capture groups)
  <PATH(S)>...   Target paths

Options:
  -n, --dry-run
          Only show what would be done (default mode)
  -f, --force
          Make actual changes to files
  -b, --backup
          Generate file backups before renaming
  -s, --silent
          Do not print any information
      --color <COLOR>
          Set color output mode [default: auto] [possible values: always, never, auto]
      --dump
          Force dumping operations into a file even in dry-run mode
      --dump-prefix <DUMP_PREFIX>
          Set the dump file prefix [default: rnr-]
      --no-dump
          Do not dump operations into a file
  -l, --replace-limit <LIMIT>
          Limit of replacements, all matches if set to 0
  -t, --replace-transform <REPLACE_TRANSFORM>
          Apply a transformation to replacements including captured groups [possible values: upper, lower, ascii]
  -D, --include-dirs
          Rename matching directories
  -r, --recursive
          Recursive mode
  -d, --max-depth <LEVEL>
          Set max depth in recursive mode
  -x, --hidden
          Include hidden files and directories
  -h, --help
          Print help"""

FROM_HELP = """Read operations from a dump file

Usage: executable from-file [OPTIONS] <DUMPFILE>

Arguments:
  <DUMPFILE>  

Options:
  -n, --dry-run                    Only show what would be done (default mode)
  -f, --force                      Make actual changes to files
  -b, --backup                     Generate file backups before renaming
  -s, --silent                     Do not print any information
      --color <COLOR>              Set color output mode [default: auto] [possible values: always, never, auto]
      --dump                       Force dumping operations into a file even in dry-run mode
      --dump-prefix <DUMP_PREFIX>  Set the dump file prefix [default: rnr-]
      --no-dump                    Do not dump operations into a file
  -u, --undo                       Undo the operations from the dump file
  -h, --help                       Print help"""

ASCII_HELP = """Replace file name UTF-8 chars with ASCII chars representation

Usage: executable to-ascii [OPTIONS] <PATH(S)>...

Arguments:
  <PATH(S)>...  Target paths

Options:
  -n, --dry-run                    Only show what would be done (default mode)
  -f, --force                      Make actual changes to files
  -b, --backup                     Generate file backups before renaming
  -s, --silent                     Do not print any information
      --color <COLOR>              Set color output mode [default: auto] [possible values: always, never, auto]
      --dump                       Force dumping operations into a file even in dry-run mode
      --dump-prefix <DUMP_PREFIX>  Set the dump file prefix [default: rnr-]
      --no-dump                    Do not dump operations into a file
  -D, --include-dirs               Rename matching directories
  -r, --recursive                  Recursive mode
  -d, --max-depth <LEVEL>          Set max depth in recursive mode
  -x, --hidden                     Include hidden files and directories
  -h, --help                       Print help"""


def eprint(*args):
    print(*args, file=sys.stderr)


def ascii_name(s):
    out = []
    for ch in s:
        decomp = unicodedata.normalize("NFKD", ch)
        enc = decomp.encode("ascii", "ignore").decode("ascii")
        if enc:
            out.append(enc)
    return "".join(out)


def convert_replacement(rep):
    # Rust regex replacement syntax accepts $1, ${1}, $name and ${name}.
    def braced(m):
        return "\\" + ("g<%s>" % m.group(1))
    rep = re.sub(r"\$\{([^}]+)\}", braced, rep)
    rep = re.sub(r"\$([A-Za-z_][A-Za-z0-9_]*)", lambda m: r"\g<%s>" % m.group(1), rep)
    rep = re.sub(r"\$([0-9]+)", lambda m: r"\%s" % m.group(1), rep)
    return rep


def hidden_path(path):
    return any(part.startswith(".") and part not in (".", "..") for part in path.split(os.sep))


def target_for_name(name, pattern=None, repl=None, limit=1, transform=None, to_ascii=False):
    if to_ascii:
        new = ascii_name(name)
    else:
        count = 0 if limit == 0 else limit
        new = pattern.sub(convert_replacement(repl), name, count=count)
        if transform == "upper":
            new = new.upper()
        elif transform == "lower":
            new = new.lower()
        elif transform == "ascii":
            new = ascii_name(new)
    return new


def collect(paths, include_dirs=False, recursive=False, max_depth=None, hidden=False,
            pattern=None, repl=None, limit=1, transform=None, to_ascii=False):
    ops = []
    for root_path in paths:
        root_path = root_path.rstrip(os.sep) if root_path != os.sep else root_path
        if not os.path.exists(root_path):
            raise RuntimeError("Cannot access path %s" % root_path)
        candidates = []
        if os.path.isdir(root_path) and recursive:
            base_depth = root_path.rstrip(os.sep).count(os.sep)
            for cur, dirs, files in os.walk(root_path, topdown=True):
                rel = os.path.relpath(cur, root_path)
                depth = 0 if rel == "." else rel.count(os.sep) + 1
                if not hidden:
                    dirs[:] = [d for d in dirs if not d.startswith(".")]
                    files = [f for f in files if not f.startswith(".")]
                if max_depth is not None and depth >= max_depth:
                    dirs[:] = []
                    continue
                for f in files:
                    p = os.path.join(cur, f)
                    if hidden or not hidden_path(os.path.relpath(p, root_path)):
                        candidates.append((p, False, depth + 1))
                if include_dirs and cur != root_path:
                    if hidden or not hidden_path(os.path.relpath(cur, root_path)):
                        candidates.append((cur, True, depth))
        else:
            candidates.append((root_path, os.path.isdir(root_path), 0))

        # Children must be handled before parents. At the same level the
        # reference lists directories before files, and dotfiles last.
        ordered = sorted(
            candidates,
            key=lambda c: (-c[2], 0 if c[1] else 1, os.path.basename(c[0]).startswith("."), c[0]),
        )
        for p, is_dir, _depth in ordered:
            if is_dir and not include_dirs:
                continue
            parent = os.path.dirname(p)
            name = os.path.basename(p)
            new_name = target_for_name(name, pattern, repl, limit, transform, to_ascii)
            if new_name and new_name != name:
                target = os.path.join(parent, new_name) if parent else new_name
                ops.append({"source": p, "target": target})
    return ops


def dump_ops(ops, prefix):
    name = prefix + datetime.now().strftime("%Y-%m-%d_%H%M%S") + ".json"
    if os.path.exists(name):
        i = 1
        base = name[:-5]
        while os.path.exists("%s-%d.json" % (base, i)):
            i += 1
        name = "%s-%d.json" % (base, i)
    with open(name, "w", encoding="utf-8") as f:
        json.dump({"date": datetime.now().strftime("%Y-%m-%d %H:%M:%S"), "operations": ops}, f, indent=2, ensure_ascii=False)
        f.write("\n")


def validate_ops(ops):
    targets = set()
    sources = {op["source"] for op in ops}
    for op in ops:
        src, dst = op["source"], op["target"]
        if dst in targets:
            raise RuntimeError("Conflict with existing path %s -> %s" % (src, dst))
        targets.add(dst)
        if os.path.exists(dst) and dst not in sources:
            raise RuntimeError("Conflict with existing path %s -> %s" % (src, dst))


def execute_ops(ops, force=False, backup=False, silent=False):
    validate_ops(ops)
    if not force and not silent:
        print("This is a DRY-RUN")
    for op in ops:
        src, dst = op["source"], op["target"]
        if force:
            if backup:
                b = src + ".bk"
                if os.path.isdir(src):
                    if os.path.exists(b):
                        shutil.rmtree(b)
                    shutil.copytree(src, b)
                else:
                    shutil.copy2(src, b)
                if not silent:
                    print("Info:  Backup created - %s -> %s" % (src, b))
            if not silent:
                print("%s -> %s" % (src, dst))
            try:
                os.renames(src, dst)
            except OSError as ex:
                eprint("Error: Cannot rename %s -> %s" % (src, dst))
                eprint(str(ex))
                return 1
        elif not silent:
            print("%s -> %s" % (src, dst))
    return 0


class Parser(argparse.ArgumentParser):
    def error(self, message):
        self.print_usage(sys.stderr)
        eprint("error:", message)
        sys.exit(2)


def common_options(p):
    p.add_argument("-n", "--dry-run", action="store_true")
    p.add_argument("-f", "--force", action="store_true")
    p.add_argument("-b", "--backup", action="store_true")
    p.add_argument("-s", "--silent", action="store_true")
    p.add_argument("--color", choices=["always", "never", "auto"], default="auto")
    p.add_argument("--dump", action="store_true")
    p.add_argument("--dump-prefix", default="rnr-")
    p.add_argument("--no-dump", action="store_true")


def traversal_options(p):
    p.add_argument("-D", "--include-dirs", action="store_true")
    p.add_argument("-r", "--recursive", action="store_true")
    p.add_argument("-d", "--max-depth", type=int)
    p.add_argument("-x", "--hidden", action="store_true")


def build_parser():
    p = Parser(prog="executable", description="RnR is a command-line tool to rename multiple files and directories that supports regular expressions")
    p.add_argument("-V", "--version", action="store_true")
    sub = p.add_subparsers(dest="cmd")
    r = sub.add_parser("regex", help="Rename files and directories using a regular expression")
    common_options(r); traversal_options(r)
    r.add_argument("-l", "--replace-limit", type=int, default=1)
    r.add_argument("-t", "--replace-transform", choices=["upper", "lower", "ascii"])
    r.add_argument("expression"); r.add_argument("replacement"); r.add_argument("paths", nargs="+")
    f = sub.add_parser("from-file", help="Read operations from a dump file")
    common_options(f); f.add_argument("-u", "--undo", action="store_true"); f.add_argument("dumpfile")
    a = sub.add_parser("to-ascii", help="Replace file name UTF-8 chars with ASCII chars representation")
    common_options(a); traversal_options(a); a.add_argument("paths", nargs="+")
    return p


def main(argv=None):
    argv = sys.argv[1:] if argv is None else argv
    if argv == ["--version"] or argv == ["-V"]:
        print(VERSION); return 0
    if argv in (["--help"], ["-h"], []):
        print(TOP_HELP); return 0
    if argv in (["regex", "--help"], ["regex", "-h"], ["help", "regex"]):
        print(REGEX_HELP); return 0
    if argv in (["from-file", "--help"], ["from-file", "-h"], ["help", "from-file"]):
        print(FROM_HELP); return 0
    if argv in (["to-ascii", "--help"], ["to-ascii", "-h"], ["help", "to-ascii"]):
        print(ASCII_HELP); return 0
    parser = build_parser()
    args = parser.parse_args(argv)
    if not args.cmd:
        parser.print_help(); return 0
    try:
        if args.cmd == "regex":
            expr = re.sub(r"\(\?<([A-Za-z_][A-Za-z0-9_]*)>", r"(?P<\1>", args.expression)
            pat = re.compile(expr)
            ops = collect(args.paths, args.include_dirs, args.recursive, args.max_depth, args.hidden,
                          pat, args.replacement, args.replace_limit, args.replace_transform, False)
        elif args.cmd == "to-ascii":
            ops = collect(args.paths, args.include_dirs, args.recursive, args.max_depth, args.hidden, to_ascii=True)
        else:
            with open(args.dumpfile, encoding="utf-8") as f:
                data = json.load(f)
            ops = data.get("operations", [])
            if args.undo:
                ops = [{"source": op["target"], "target": op["source"]} for op in reversed(ops)]
        force = bool(args.force)
        status = execute_ops(ops, force, args.backup, args.silent)
        if ops and not args.no_dump and (args.dump or force):
            dump_ops(ops, args.dump_prefix)
        return status
    except re.error as ex:
        eprint("Error:", ex); return 1
    except Exception as ex:
        eprint("Error:", ex); return 1


if __name__ == "__main__":
    sys.exit(main())
