#!/usr/bin/env python3
import argparse
import hashlib
import json
import os
import re
import sys

VERSION = "lightningcss 1.0.0-alpha.70"

NAMED_COLORS = {
    "white": "#fff",
    "black": "#000",
    "red": "red",
    "blue": "#00f",
    "green": "green",
    "transparent": "#0000",
}

HEX_TO_NAME = {
    "#ff0000": "red",
    "#f00": "red",
    "#0000ff": "#00f",
    "#00f": "#00f",
    "#ffffff": "#fff",
    "#fff": "#fff",
    "#000000": "#000",
    "#000": "#000",
}


def split_args(argv):
    if "--version" in argv or "-V" in argv:
        print(VERSION)
        raise SystemExit(0)
    if "--help" in argv or "-h" in argv:
        print_help()
        raise SystemExit(0)
    return argv


def print_help():
    print("""lightningcss 1.0.0-alpha.70
Devon Govett <devongovett@gmail.com>
A CSS parser, transformer, and minifier

USAGE:
    executable [OPTIONS] [INPUT_FILE]...

ARGS:
    <INPUT_FILE>...    Target CSS file (default: stdin)

OPTIONS:
        --browserslist
        --bundle
        --css-modules [<CSS_MODULES>]
            Enable CSS modules in output. If no filename is provided, <output_file>.json will be
            used. If no --output-file is specified, code and exports will be printed to stdout as
            JSON
        --css-modules-dashed-idents
        --css-modules-pattern <CSS_MODULES_PATTERN>
        --custom-media
            Enable parsing custom media queries
    -d, --output-dir <OUTPUT_DIR>
            Destination directory to output into
        --error-recovery
    -h, --help
            Print help information
    -m, --minify
            Minify the output
    -o, --output-file <OUTPUT_FILE>
            Destination file for the output
        --sourcemap
            Enable sourcemap, at <output_file>.map
    -t, --targets <TARGETS>
    -V, --version
            Print version information""")


class Parser(argparse.ArgumentParser):
    def error(self, message):
        sys.stderr.write(f"error: {message}\n\nFor more information try --help\n")
        raise SystemExit(2)


def parse_cli(argv):
    argv = split_args(argv)
    p = Parser(add_help=False, prog="executable")
    p.add_argument("-m", "--minify", action="store_true")
    p.add_argument("-o", "--output-file")
    p.add_argument("-d", "--output-dir")
    p.add_argument("--sourcemap", action="store_true")
    p.add_argument("--bundle", action="store_true")
    p.add_argument("--browserslist", action="store_true")
    p.add_argument("--custom-media", action="store_true")
    p.add_argument("--error-recovery", action="store_true")
    p.add_argument("--css-modules-dashed-idents", action="store_true")
    p.add_argument("--css-modules-pattern")
    p.add_argument("-t", "--targets")
    p.add_argument("--css-modules", nargs="?", const=True, default=False)
    p.add_argument("input_files", nargs="*")
    ns = p.parse_args(argv)
    if ns.sourcemap and not (ns.output_file or ns.output_dir):
        sys.stderr.write("error: The following required arguments were not provided:\n    <--output-file <OUTPUT_FILE>|--output-dir <OUTPUT_DIR>>\n\n")
        sys.stderr.write("USAGE:\n    executable --sourcemap <--output-file <OUTPUT_FILE>|--output-dir <OUTPUT_DIR>>\n\nFor more information try --help\n")
        raise SystemExit(2)
    return ns


def read_inputs(files, bundle=False, seen=None):
    if not files:
        return sys.stdin.read()
    out = []
    for f in files:
        try:
            text = open(f, "r", encoding="utf-8").read()
        except OSError as e:
            sys.stderr.write(f"Error: Os {{ code: {getattr(e, 'errno', 2)}, kind: NotFound, message: \"{e.strerror}\" }}\n")
            raise SystemExit(1)
        if bundle:
            text = inline_imports(text, os.path.dirname(os.path.abspath(f)), seen or set())
        out.append(text)
    return "\n".join(out)


def inline_imports(css, base, seen):
    def repl(m):
        name = m.group(1) or m.group(2)
        path = os.path.join(base, name)
        if path in seen:
            return ""
        seen.add(path)
        try:
            data = open(path, encoding="utf-8").read()
        except OSError:
            return m.group(0)
        return inline_imports(data, os.path.dirname(path), seen)
    return re.sub(r'@import\s+(?:"([^"]+)"|\'([^\']+)\')\s*;', repl, css)


def strip_comments(css):
    return re.sub(r"/\*.*?\*/", "", css, flags=re.S)


def normalize_media(css):
    css = re.sub(r"@media\s*\(\s*max-width\s*:\s*([^)]+?)\s*\)", r"@media (width <= \1)", css)
    css = re.sub(r"@media\s*\(\s*min-width\s*:\s*([^)]+?)\s*\)", r"@media (width >= \1)", css)
    return css


def tokenize_blocks(css):
    css = strip_comments(normalize_media(css)).strip()
    res = []
    i = 0
    n = len(css)
    while i < n:
        while i < n and css[i].isspace():
            i += 1
        if i >= n:
            break
        start = i
        while i < n and css[i] != "{":
            if css[i] == ";":
                raw = css[start:i + 1].strip()
                if raw:
                    res.append(("raw", raw, ""))
                i += 1
                break
            i += 1
        if i < n and css[i - 1] == ";":
            continue
        if i >= n:
            tail = css[start:].strip()
            if tail:
                res.append(("raw", tail, ""))
            break
        pre = css[start:i].strip()
        i += 1
        depth = 1
        body_start = i
        quote = None
        while i < n and depth:
            c = css[i]
            if quote:
                if c == "\\":
                    i += 2
                    continue
                if c == quote:
                    quote = None
            else:
                if c in ("'", '"'):
                    quote = c
                elif c == "{":
                    depth += 1
                elif c == "}":
                    depth -= 1
                    if depth == 0:
                        break
            i += 1
        body = css[body_start:i]
        if i < n and css[i] == "}":
            i += 1
        res.append(("block", pre, body))
    return res


def split_decls(body):
    parts, cur, depth, quote = [], [], 0, None
    for c in body:
        if quote:
            cur.append(c)
            if c == quote:
                quote = None
            continue
        if c in ("'", '"'):
            quote = c
        elif c == "(":
            depth += 1
        elif c == ")":
            depth = max(0, depth - 1)
        if c == ";" and depth == 0:
            part = "".join(cur).strip()
            if part:
                parts.append(part)
            cur = []
        else:
            cur.append(c)
    part = "".join(cur).strip()
    if part:
        parts.append(part)
    decls = []
    for p in parts:
        if ":" in p:
            k, v = p.split(":", 1)
            decls.append((k.strip(), normalize_value(v.strip())))
    return sorted(decls, key=lambda kv: prop_order(kv[0]))


def prop_order(prop):
    order = {"color": 0, "background": 1, "background-color": 1, "margin": 2, "padding": 3}
    return (order.get(prop, 50), prop)


def normalize_value(v):
    v = re.sub(r"\s+", " ", v.strip())
    v = re.sub(r"\b0(?:px|em|rem|%|vh|vw|s|ms|deg)\b", "0", v)
    v = re.sub(r"rgba?\(\s*([0-9.]+)\s*,\s*([0-9.]+)\s*,\s*([0-9.]+)\s*(?:,\s*([0-9.]+)\s*)?\)", rgb_repl, v, flags=re.I)
    def hex_repl(m):
        h = m.group(0).lower()
        if len(h) == 7 and h[1] == h[2] and h[3] == h[4] and h[5] == h[6]:
            h = "#" + h[1] + h[3] + h[5]
        return HEX_TO_NAME.get(h, h)
    v = re.sub(r"#[0-9a-fA-F]{3,8}\b", hex_repl, v)
    for name, val in NAMED_COLORS.items():
        v = re.sub(rf"\b{name}\b", val, v, flags=re.I)
    v = re.sub(r"\s*,\s*", ", ", v)
    return v


def rgb_repl(m):
    r, g, b = [int(float(x)) for x in m.group(1, 2, 3)]
    if m.group(4) is not None and float(m.group(4)) == 0:
        return "#0000"
    h = f"#{r:02x}{g:02x}{b:02x}"
    if h == "#ff0000":
        return "red"
    if h == "#0000ff":
        return "#00f"
    if h == "#ffffff":
        return "#fff"
    if h == "#000000":
        return "#000"
    if h[1] == h[2] and h[3] == h[4] and h[5] == h[6]:
        h = "#" + h[1] + h[3] + h[5]
    return h


def format_selector(sel, minify=False):
    sel = re.sub(r"\s+", " ", sel.strip())
    sel = re.sub(r"\s*,\s*", "," if minify else ", ", sel)
    if minify:
        sel = re.sub(r"\s*([<>]=|[<>])\s*", r"\1", sel)
    return sel


def render(css, minify=False, level=0):
    blocks = tokenize_blocks(css)
    chunks = []
    for typ, pre, body in blocks:
        if typ != "block":
            raw = pre.strip()
            if raw:
                chunks.append(raw if minify else ("  " * level + raw))
            continue
        pre = format_selector(pre, minify)
        nested = "{" in body and (pre.startswith("@") or re.search(r"(^|,)\s*(from|to|[0-9.]+%)\s*(,|$)", pre))
        if nested:
            inner = render(body, minify, level + 1)
            if minify:
                chunks.append(f"{pre}{{{inner}}}")
            else:
                ind = "  " * level
                chunks.append(f"{ind}{pre} {{\n{inner}\n{ind}}}")
            continue
        decls = split_decls(body)
        if minify:
            chunks.append(f"{pre}{{" + ";".join(f"{k}:{v.replace(', ', ',')}" for k, v in decls) + "}")
        else:
            ind = "  " * level
            body_ind = "  " * (level + 1)
            lines = [f"{body_ind}{k}: {v};" for k, v in decls]
            chunks.append(f"{ind}{pre} {{\n" + "\n".join(lines) + f"\n{ind}}}")
    if minify:
        return "".join(chunks)
    return "\n\n".join(chunks) + ("\n" if level == 0 and chunks else "")


def css_module_prefix(files, css):
    seed = (files[0] if files else css[:80]).encode("utf-8", "ignore")
    return "_" + hashlib.sha1(seed).digest().hex()[:6]


def apply_css_modules(css, files, pattern=None):
    prefix = css_module_prefix(files, css)
    exports = {}
    keyframes = set(re.findall(r"@keyframes\s+([A-Za-z_][\w-]*)", css))
    classes = set(re.findall(r"\.([A-Za-z_][\w-]*)", css))
    ids = set(re.findall(r"#([A-Za-z_][\w-]*)", css))
    for name in sorted(classes | ids | keyframes):
        scoped = (pattern or "[hash]_[local]").replace("[local]", name).replace("[hash]", prefix.strip("_"))
        if pattern is None:
            scoped = f"{prefix}_{name}"
        exports[name] = {"name": scoped, "composes": [], "isReferenced": name in keyframes}
    def cls(m):
        return "." + exports.get(m.group(1), {"name": m.group(1)})["name"]
    def ident(m):
        return "#" + exports.get(m.group(1), {"name": m.group(1)})["name"]
    css = re.sub(r"\.([A-Za-z_][\w-]*)", cls, css)
    css = re.sub(r"#([A-Za-z_][\w-]*)", ident, css)
    for name in sorted(keyframes, key=len, reverse=True):
        css = re.sub(rf"(@keyframes\s+){re.escape(name)}\b", r"\1" + exports[name]["name"], css)
        css = re.sub(rf"\b{re.escape(name)}\b", exports[name]["name"], css)
    return css, exports


def write_outputs(ns, code, exports):
    if ns.css_modules and not ns.output_file:
        print(json.dumps({"code": code, "exports": exports}, separators=(",", ":")))
        return
    if ns.output_file:
        with open(ns.output_file, "w", encoding="utf-8") as f:
            f.write(code)
        if ns.css_modules and isinstance(ns.css_modules, str):
            with open(ns.css_modules, "w", encoding="utf-8") as f:
                f.write(json.dumps(exports, separators=(",", ":")))
        elif ns.css_modules:
            path = os.path.splitext(ns.output_file)[0] + ".json"
            with open(path, "w", encoding="utf-8") as f:
                f.write(json.dumps(exports, separators=(",", ":")))
        if ns.sourcemap:
            with open(ns.output_file + ".map", "w", encoding="utf-8") as f:
                f.write(json.dumps({"version": 3, "sources": ns.input_files, "mappings": ""}))
        return
    if ns.output_dir:
        os.makedirs(ns.output_dir, exist_ok=True)
        if ns.input_files:
            for f in ns.input_files:
                out = os.path.join(ns.output_dir, os.path.basename(f))
                src = read_inputs([f], ns.bundle)
                if ns.css_modules:
                    src, _ = apply_css_modules(src, [f], ns.css_modules_pattern)
                c = render(src, ns.minify)
                with open(out, "w", encoding="utf-8") as fh:
                    fh.write(c)
                if ns.sourcemap:
                    open(out + ".map", "w", encoding="utf-8").write(json.dumps({"version": 3, "sources": [f], "mappings": ""}))
        else:
            sys.stdout.write(code)
        return
    sys.stdout.write(code)


def main(argv):
    ns = parse_cli(argv)
    css = read_inputs(ns.input_files, ns.bundle)
    exports = {}
    if ns.css_modules:
        css, exports = apply_css_modules(css, ns.input_files, ns.css_modules_pattern)
    code = render(css, ns.minify)
    write_outputs(ns, code, exports)


if __name__ == "__main__":
    try:
        main(sys.argv[1:])
    except BrokenPipeError:
        pass
