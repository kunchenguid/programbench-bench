#!/usr/bin/env python3
import json
import os
import shutil
import subprocess
import sys
from pathlib import Path


VERSION = "eureka 2.0.0"
GREEN_BOLD = "\033[0m\033[1m\033[32m"
YELLOW = "\033[0m\033[33m"
RESET = "\033[0m"


def print_help() -> None:
    print("Input and store your ideas without leaving the terminal")
    print()
    print("Usage: executable [OPTIONS]")
    print()
    print("Options:")
    print("      --clear-config  Clear your stored configuration")
    print("  -v, --view          View ideas with your $PAGER env variable. If unset use less")
    print("  -h, --help          Print help")
    print("  -V, --version       Print version")


def config_path() -> Path:
    xdg = os.environ.get("XDG_CONFIG_HOME")
    if xdg:
        return Path(xdg) / "eureka" / "config.json"
    home = Path(os.environ.get("HOME", str(Path.home())))
    return home / ".config" / "eureka" / "config.json"


def load_config() -> dict:
    with config_path().open("r", encoding="utf-8") as f:
        return json.load(f)


def save_config(repo: str) -> None:
    path = config_path()
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps({"repo": repo}, separators=(",", ":")), encoding="utf-8")


def clear_config() -> int:
    try:
        config_path().unlink()
    except FileNotFoundError:
        pass
    return 0


def error(message: str) -> int:
    print(f" ERROR eureka > {message}")
    return 0


def run(cmd, cwd=None) -> subprocess.CompletedProcess:
    return subprocess.run(cmd, cwd=cwd, text=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)


def first_time_setup() -> int:
    print(
        YELLOW
        + "############################################################\n"
        + "####                  First Time Setup                  ####\n"
        + "############################################################\n\n"
        + "This tool requires you to have a repository with a README.md\n"
        + "in the root folder. The markdown file is where your ideas\n"
        + "will be stored.\n\n"
        + "Once first time setup has completed, simply run Eureka again\n"
        + "to begin writing down ideas.\n        "
        + RESET
    )
    while True:
        print(f"{GREEN_BOLD}Absolute path to your idea repo\n{RESET}> ", end="", flush=True)
        line = sys.stdin.readline()
        if line == "":
            return 0
        repo = line.strip()
        if repo:
            save_config(repo)
            print("First time setup complete. Happy ideation!")
            return 0


def repo_from_config():
    try:
        cfg = load_config()
    except Exception as exc:
        raise RuntimeError(str(exc))
    repo = cfg.get("repo")
    if not isinstance(repo, str) or not repo:
        raise RuntimeError("missing field `repo`")
    return Path(repo)


def view() -> int:
    try:
        repo = repo_from_config()
    except RuntimeError as exc:
        return error(str(exc))
    pager = os.environ.get("PAGER") or "less"
    readme = repo / "README.md"
    try:
        return subprocess.call([pager, str(readme)])
    except FileNotFoundError as exc:
        return error(str(exc))


def branch_name(repo: Path) -> str:
    cp = run(["git", "branch", "--show-current"], cwd=repo)
    name = cp.stdout.strip()
    if name:
        return name
    cp = run(["git", "rev-parse", "--abbrev-ref", "HEAD"], cwd=repo)
    return cp.stdout.strip() or "main"


def capture() -> int:
    if not config_path().exists():
        return first_time_setup()
    try:
        repo = repo_from_config()
    except RuntimeError as exc:
        return error(str(exc))

    print(f"{GREEN_BOLD}>> Idea summary\n{RESET}> ", end="", flush=True)
    summary = sys.stdin.readline()
    if summary == "":
        return 0
    summary = summary.strip()
    if not summary:
        return 0

    readme = repo / "README.md"
    editor = os.environ.get("EDITOR") or "vi"
    try:
        rc = subprocess.call([editor, str(readme)])
    except FileNotFoundError as exc:
        return error(str(exc))
    if rc != 0:
        return rc

    branch = branch_name(repo)
    print(f"Adding and committing your new idea to {branch}..")
    add = run(["git", "add", "README.md"], cwd=repo)
    if add.returncode != 0:
        return error((add.stderr or add.stdout).strip())
    commit = run(["git", "commit", "-m", summary], cwd=repo)
    if commit.returncode != 0:
        msg = (commit.stderr or commit.stdout).strip()
        if msg:
            return error(msg)
        return commit.returncode
    print("Added and committed!")
    print("Pushing your new idea..")
    push = run(["git", "push"], cwd=repo)
    if push.returncode != 0:
        remote = run(["git", "remote", "get-url", "origin"], cwd=repo)
        if remote.returncode != 0:
            return error("remote 'origin' does not exist; class=Config (7); code=NotFound (-3)")
        msg = (push.stderr or push.stdout).strip()
        if msg:
            return error(msg.splitlines()[-1])
    return 0


def main(argv) -> int:
    args = argv[1:]
    if not args:
        return capture()
    if "-h" in args or "--help" in args:
        print_help()
        return 0
    if "-V" in args or "--version" in args:
        print(VERSION)
        return 0
    if len(args) == 1 and args[0] in ("-v", "--view"):
        return view()
    if len(args) == 1 and args[0] == "--clear-config":
        return clear_config()

    bad = args[0] if args else ""
    print(f"error: unexpected argument '{bad}' found", file=sys.stderr)
    print(file=sys.stderr)
    print("Usage: executable [OPTIONS]", file=sys.stderr)
    print(file=sys.stderr)
    print("For more information, try '--help'.", file=sys.stderr)
    return 2


if __name__ == "__main__":
    sys.exit(main(sys.argv))
