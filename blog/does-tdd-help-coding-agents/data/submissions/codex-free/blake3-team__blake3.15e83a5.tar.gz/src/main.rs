use std::env;
use std::fs::File;
use std::io::{self, Read, Write, BufRead};

const BLOCK_LEN: usize = 64;
const CHUNK_LEN: usize = 1024;
const IV: [u32; 8] = [
    0x6A09E667, 0xBB67AE85, 0x3C6EF372, 0xA54FF53A,
    0x510E527F, 0x9B05688C, 0x1F83D9AB, 0x5BE0CD19,
];
const MSG_PERMUTATION: [usize; 16] = [2, 6, 3, 10, 7, 0, 4, 13, 1, 11, 12, 5, 9, 14, 15, 8];
const CHUNK_START: u32 = 1;
const CHUNK_END: u32 = 2;
const PARENT: u32 = 4;
const ROOT: u32 = 8;
const KEYED_HASH: u32 = 16;
const DERIVE_KEY_CONTEXT: u32 = 32;
const DERIVE_KEY_MATERIAL: u32 = 64;

#[derive(Clone)]
struct Output { input_cv: [u32;8], block_words: [u32;16], counter: u64, block_len: u32, flags: u32 }

fn g(v: &mut [u32;16], a: usize, b: usize, c: usize, d: usize, mx: u32, my: u32) {
    v[a] = v[a].wrapping_add(v[b]).wrapping_add(mx);
    v[d] = (v[d] ^ v[a]).rotate_right(16);
    v[c] = v[c].wrapping_add(v[d]);
    v[b] = (v[b] ^ v[c]).rotate_right(12);
    v[a] = v[a].wrapping_add(v[b]).wrapping_add(my);
    v[d] = (v[d] ^ v[a]).rotate_right(8);
    v[c] = v[c].wrapping_add(v[d]);
    v[b] = (v[b] ^ v[c]).rotate_right(7);
}
fn round(v: &mut [u32;16], m: &[u32;16]) {
    g(v, 0, 4, 8, 12, m[0], m[1]); g(v, 1, 5, 9, 13, m[2], m[3]);
    g(v, 2, 6, 10, 14, m[4], m[5]); g(v, 3, 7, 11, 15, m[6], m[7]);
    g(v, 0, 5, 10, 15, m[8], m[9]); g(v, 1, 6, 11, 12, m[10], m[11]);
    g(v, 2, 7, 8, 13, m[12], m[13]); g(v, 3, 4, 9, 14, m[14], m[15]);
}
fn permute(m: [u32;16]) -> [u32;16] { let mut p=[0;16]; for i in 0..16 { p[i]=m[MSG_PERMUTATION[i]]; } p }
fn compress(cv: &[u32;8], block: &[u32;16], counter: u64, block_len: u32, flags: u32) -> [u32;16] {
    let mut v=[0u32;16]; v[..8].copy_from_slice(cv); v[8..12].copy_from_slice(&IV[..4]);
    v[12]=counter as u32; v[13]=(counter>>32) as u32; v[14]=block_len; v[15]=flags;
    let mut m=*block; for _ in 0..7 { round(&mut v,&m); m=permute(m); }
    let mut out=[0u32;16]; for i in 0..8 { out[i]=v[i]^v[i+8]; out[i+8]=v[i+8]^cv[i]; } out
}
fn bytes_to_words(block: &[u8]) -> [u32;16] {
    let mut words=[0u32;16]; for (i,ch) in block.chunks(4).enumerate() { let mut b=[0u8;4]; b[..ch.len()].copy_from_slice(ch); words[i]=u32::from_le_bytes(b); } words
}
impl Output {
    fn chaining_value(&self)->[u32;8] { let w=compress(&self.input_cv,&self.block_words,self.counter,self.block_len,self.flags); let mut cv=[0u32;8]; cv.copy_from_slice(&w[..8]); cv }
    fn root_bytes(&self, seek:u64, len:usize)->Vec<u8> {
        let mut out=Vec::with_capacity(len); let mut ctr=seek/64; let mut off=(seek%64) as usize;
        while out.len()<len { let words=compress(&self.input_cv,&self.block_words,ctr,self.block_len,self.flags|ROOT); let mut block=[0u8;64]; for (i,w) in words.iter().enumerate(){block[i*4..i*4+4].copy_from_slice(&w.to_le_bytes());} let take=(64-off).min(len-out.len()); out.extend_from_slice(&block[off..off+take]); ctr+=1; off=0; }
        out
    }
}
fn parent_output(left:[u32;8], right:[u32;8], key:&[u32;8], flags:u32)->Output { let mut bw=[0u32;16]; bw[..8].copy_from_slice(&left); bw[8..].copy_from_slice(&right); Output{input_cv:*key,block_words:bw,counter:0,block_len:64,flags:flags|PARENT} }
fn chunk_output(chunk:&[u8], counter:u64, key:&[u32;8], flags:u32)->Output {
    let mut cv=*key; let mut off=0usize; let mut n=0usize;
    if chunk.is_empty(){return Output{input_cv:cv,block_words:[0;16],counter,block_len:0,flags:flags|CHUNK_START|CHUNK_END};}
    while chunk.len()-off>BLOCK_LEN { let block=bytes_to_words(&chunk[off..off+BLOCK_LEN]); let f=flags|if n==0{CHUNK_START}else{0}; let w=compress(&cv,&block,counter,64,f); cv.copy_from_slice(&w[..8]); n+=1; off+=BLOCK_LEN; }
    let last=&chunk[off..]; let mut buf=[0u8;64]; buf[..last.len()].copy_from_slice(last); let f=flags|CHUNK_END|if n==0{CHUNK_START}else{0}; Output{input_cv:cv,block_words:bytes_to_words(&buf),counter,block_len:last.len() as u32,flags:f}
}
fn hash_bytes(input:&[u8], key:[u32;8], flags:u32, seek:u64, len:usize)->Vec<u8>{
    let mut stack:Vec<[u32;8]>=Vec::new(); let mut last_out=None; let mut last_parent=None; let mut chunks=0u64;
    for (i,chunk) in input.chunks(CHUNK_LEN).enumerate(){ let out=chunk_output(chunk,i as u64,&key,flags); chunks+=1; let mut cv=out.chaining_value(); let mut total=chunks; while total&1==0 { let left=stack.pop().unwrap(); let po=parent_output(left,cv,&key,flags); cv=po.chaining_value(); last_parent=Some(po); total>>=1; } stack.push(cv); last_out=Some(out); }
    let output=if chunks==0 { chunk_output(&[],0,&key,flags) } else if chunks==1 { last_out.unwrap() } else { let mut right=stack.pop().unwrap(); let mut out=None; while let Some(left)=stack.pop(){ let po=parent_output(left,right,&key,flags); right=po.chaining_value(); out=Some(po); } out.or(last_parent).unwrap() };
    output.root_bytes(seek,len)
}
fn derive_key(context:&str)->[u32;8]{ let bytes=hash_bytes(context.as_bytes(),IV,DERIVE_KEY_CONTEXT,0,32); let mut k=[0u32;8]; for i in 0..8{k[i]=u32::from_le_bytes(bytes[i*4..i*4+4].try_into().unwrap());} k }
fn hex(bytes:&[u8])->String{ const H:&[u8;16]=b"0123456789abcdef"; let mut s=String::with_capacity(bytes.len()*2); for &b in bytes{s.push(H[(b>>4) as usize] as char);s.push(H[(b&15) as usize] as char);} s }

#[derive(Default)] struct Opts{keyed:bool,derive:Option<String>,length:usize,seek:u64,no_names:bool,raw:bool,tag:bool,check:bool,quiet:bool,length_set:bool,seek_set:bool,files:Vec<String>}
fn usage(long:bool){ if long{print!("Usage: executable [OPTIONS] [FILE]...\n\nArguments:\n  [FILE]...\n          Files to hash, or checkfiles to check\n          \n          When no file is given, or when - is given, read standard input.\n\nOptions:\n      --keyed\n          Use the keyed mode, reading the 32-byte key from stdin\n\n      --derive-key <CONTEXT>\n          Use the key derivation mode, with the given context string\n          \n          Cannot be used with --keyed.\n\n  -l, --length <LEN>\n          The number of output bytes, before hex encoding\n          \n          [default: 32]\n\n      --seek <SEEK>\n          The starting output byte offset, before hex encoding\n          \n          [default: 0]\n\n      --num-threads <NUM>\n          The maximum number of threads to use\n\n      --no-mmap\n          Disable memory mapping\n\n      --no-names\n          Omit filenames in the output\n\n      --raw\n          Write raw output bytes to stdout, rather than hex\n          \n          --no-names is implied. In this case, only a single input is allowed.\n\n      --tag\n          Output BSD-style checksums: BLAKE3 ([FILE]) = [HASH]\n\n  -c, --check\n          Read BLAKE3 sums from the [FILE]s and check them\n\n      --quiet\n          Skip printing OK for each checked file\n          \n          Must be used with --check.\n\n  -h, --help\n          Print help (see a summary with '-h')\n\n  -V, --version\n          Print version\n");}else{print!("Usage: executable [OPTIONS] [FILE]...\n\nArguments:\n  [FILE]...  Files to hash, or checkfiles to check\n\nOptions:\n      --keyed                 Use the keyed mode, reading the 32-byte key from stdin\n      --derive-key <CONTEXT>  Use the key derivation mode, with the given context string\n  -l, --length <LEN>          The number of output bytes, before hex encoding [default: 32]\n      --seek <SEEK>           The starting output byte offset, before hex encoding [default: 0]\n      --num-threads <NUM>     The maximum number of threads to use\n      --no-mmap               Disable memory mapping\n      --no-names              Omit filenames in the output\n      --raw                   Write raw output bytes to stdout, rather than hex\n      --tag                   Output BSD-style checksums: BLAKE3 ([FILE]) = [HASH]\n  -c, --check                 Read BLAKE3 sums from the [FILE]s and check them\n      --quiet                 Skip printing OK for each checked file\n  -h, --help                  Print help (see more with '--help')\n  -V, --version               Print version\n");}}
fn parse()->Result<Opts,String>{ let mut o=Opts{length:32,..Default::default()}; let mut args=env::args().skip(1);
    while let Some(a)=args.next(){match a.as_str(){"--keyed"=>o.keyed=true,"--derive-key"=>o.derive=Some(args.next().ok_or("error: a value is required for '--derive-key <CONTEXT>'")?),"-l"|"--length"=>{o.length_set=true;o.length=args.next().ok_or("error: a value is required for '--length <LEN>'")?.parse().map_err(|_|"error: invalid value for '--length <LEN>'".to_string())?},"--seek"=>{o.seek_set=true;o.seek=args.next().ok_or("error: a value is required for '--seek <SEEK>'")?.parse().map_err(|_|"error: invalid value for '--seek <SEEK>'".to_string())?},"--num-threads"=>{let _=args.next().ok_or("error: a value is required for '--num-threads <NUM>'")?;},"--no-mmap"=>{},"--no-names"=>o.no_names=true,"--raw"=>{o.raw=true;o.no_names=true},"--tag"=>o.tag=true,"-c"|"--check"=>o.check=true,"--quiet"=>o.quiet=true,"-h"=>{usage(false);std::process::exit(0)},"--help"=>{usage(true);std::process::exit(0)},"-V"|"--version"=>{println!("b3sum 1.8.4");std::process::exit(0)},_ if a.starts_with("--length=")=>{o.length_set=true;o.length=a[9..].parse().map_err(|_|"error: invalid value for '--length <LEN>'".to_string())?},_ if a.starts_with("--seek=")=>{o.seek_set=true;o.seek=a[7..].parse().map_err(|_|"error: invalid value for '--seek <SEEK>'".to_string())?},_ if a.starts_with("--derive-key=")=>o.derive=Some(a[13..].to_string()),_ if a.starts_with('-')&&a!="-"=>return Err(format!("error: unexpected argument '{}' found",a)),_=>o.files.push(a)}}
    if o.keyed&&o.derive.is_some(){return Err("error: the argument '--keyed' cannot be used with '--derive-key <CONTEXT>'".into())}
    if o.check&&(o.keyed||o.derive.is_some()||o.length_set||o.seek_set||o.raw||o.no_names||o.tag){return Err("error: the argument '--check' cannot be used with hashing options".into())}
    if o.quiet&&!o.check{return Err("error: the argument '--quiet' requires '--check'".into())}
    if o.keyed&&o.files.is_empty(){return Err("error: the following required arguments were not provided:\n  <FILE>...".into())}
    if o.raw&&o.files.len()>1{return Err("error: The argument '--raw' cannot be used with multiple inputs".into())} Ok(o)}
fn read_input(name:&str)->io::Result<Vec<u8>>{let mut data=Vec::new(); if name=="-"{io::stdin().read_to_end(&mut data)?;}else{File::open(name)?.read_to_end(&mut data)?;} Ok(data)}
fn hash_mode(o:&Opts)->i32{let mut key=IV; let mut flags=0u32; if o.keyed{let mut kb=Vec::new(); if let Err(e)=io::stdin().read_to_end(&mut kb){eprintln!("Error: {}",e);return 1} if kb.len()!=32{eprintln!("Error: expected 32 key bytes from stdin, found {}",kb.len());return 1} for i in 0..8{key[i]=u32::from_le_bytes(kb[i*4..i*4+4].try_into().unwrap())} flags=KEYED_HASH}else if let Some(ctx)=&o.derive{key=derive_key(ctx);flags=DERIVE_KEY_MATERIAL}
    let inputs=if o.files.is_empty(){vec!["-".to_string()]}else{o.files.clone()}; let mut status=0; for name in inputs{match read_input(&name){Ok(data)=>{let d=hash_bytes(&data,key,flags,o.seek,o.length); if o.raw{let _=io::stdout().write_all(&d);}else if o.no_names{println!("{}",hex(&d));}else if o.tag{println!("BLAKE3 ({}) = {}",name,hex(&d));}else{println!("{}  {}",hex(&d),name);}},Err(e)=>{eprintln!("executable: {}: {}",name,e);status=1}}} status}
fn parse_check_line(line:&str)->Option<(String,String)>{let s=line.trim_end_matches(['\n','\r']); if s.starts_with("BLAKE3 ("){if let Some(mid)=s.rfind(") = "){return Some((s[mid+4..].trim().to_string(),s[8..mid].to_string()))}} if s.len()>=66&&s.as_bytes()[64]==b' '&&s.as_bytes()[65]==b' '{return Some((s[..64].to_string(),s[66..].to_string()))} None}
fn check_reader<R:BufRead>(r:R,quiet:bool)->usize{let mut bad=0; for line in r.lines().flatten(){if let Some((want,file))=parse_check_line(&line){match read_input(&file){Ok(data)=>{let got=hex(&hash_bytes(&data,IV,0,0,want.len()/2)); if got.eq_ignore_ascii_case(&want){if !quiet{println!("{}: OK",file)}}else{println!("{}: FAILED",file);bad+=1}},Err(e)=>{eprintln!("{}: {}",file,e);bad+=1}}}} bad}
fn check_mode(o:&Opts)->i32{let inputs=if o.files.is_empty(){vec!["-".to_string()]}else{o.files.clone()}; let mut bad=0; for name in inputs{if name=="-"{bad+=check_reader(io::BufReader::new(io::stdin()),o.quiet)}else{match File::open(&name){Ok(f)=>bad+=check_reader(io::BufReader::new(f),o.quiet),Err(e)=>{eprintln!("executable: {}: {}",name,e);bad+=1}}}} if bad==0{0}else{1}}
fn main(){let opts=match parse(){Ok(o)=>o,Err(e)=>{eprintln!("{}",e);eprintln!("\nUsage: executable [OPTIONS] [FILE]...\n\nFor more information, try '--help'.");std::process::exit(2)}}; let code=if opts.check{check_mode(&opts)}else{hash_mode(&opts)}; std::process::exit(code)}
