#!/usr/bin/env python3
import os
import signal
import subprocess
import sys


VERSION = "0.4.2"


def help_text(prog: str) -> str:
    return f"""nsh {VERSION}
A command-line shell that focuses on performance and productivity.

USAGE:
    {prog} [FLAGS] [OPTIONS] [FILE]

FLAGS:
    -h, --help       Prints help information
    -l, --login      Behave like a login shell
        --norc       Don't load nshrc
        --version    Print the version

OPTIONS:
    -c <command>        The command to be executed

ARGS:
    <FILE>    The file to be executed"""


def usage_for_c(prog: str) -> str:
    return f"""USAGE:
    {prog} -c <command>

For more information try --help"""


def usage_general(prog: str) -> str:
    return f"""USAGE:
    {prog} [FLAGS] [OPTIONS] [FILE]

For more information try --help"""


def parse_args(argv):
    prog = os.path.basename(argv[0]) or "executable"
    opts = {"login": False, "norc": False, "command": None, "file": None}
    i = 1
    while i < len(argv):
        arg = argv[i]
        if arg in ("-h", "--help"):
            print(help_text(prog))
            raise SystemExit(0)
        if arg == "--version":
            print(VERSION)
            raise SystemExit(0)
        if arg in ("--norc",):
            opts["norc"] = True
            i += 1
            continue
        if arg in ("-l", "--login"):
            opts["login"] = True
            i += 1
            continue
        if arg == "-c":
            if i + 1 >= len(argv):
                print("error: The argument '-c <command>' requires a value but none was supplied", file=sys.stderr)
                print(file=sys.stderr)
                print(usage_for_c(prog), file=sys.stderr)
                raise SystemExit(1)
            opts["command"] = argv[i + 1]
            i += 2
            continue
        if arg.startswith("-c") and len(arg) > 2:
            opts["command"] = arg[2:]
            i += 1
            continue
        if arg.startswith("-") and arg != "-":
            print(f"error: Found argument '{arg}' which wasn't expected, or isn't valid in this context", file=sys.stderr)
            print(file=sys.stderr)
            print(usage_general(prog), file=sys.stderr)
            raise SystemExit(1)
        if opts["file"] is None:
            opts["file"] = arg
            i += 1
            continue
        usage = usage_for_c(prog) if opts["command"] is not None else usage_general(prog)
        print(f"error: Found argument '{arg}' which wasn't expected, or isn't valid in this context", file=sys.stderr)
        print(file=sys.stderr)
        print(usage, file=sys.stderr)
        raise SystemExit(1)
    return prog, opts


def rc_path():
    xdg = os.environ.get("XDG_CONFIG_HOME")
    if xdg:
        candidate = os.path.join(xdg, "nsh", "nshrc")
        if os.path.exists(candidate):
            return candidate
    home = os.environ.get("HOME")
    if home:
        candidate = os.path.join(home, ".nshrc")
        if os.path.exists(candidate):
            return candidate
    return None


def bash_prelude(norc: bool) -> str:
    parts = [
        "shopt -s expand_aliases 2>/dev/null || true",
        "command_not_found_handle() { printf \"nsh: command not found \\`%s'\\n\" \"$1\" >&2; return 1; }",
    ]
    if not norc:
        path = rc_path()
        if path:
            parts.append(f". {shell_quote(path)}")
    return "\n".join(parts) + "\n"


def shell_quote(s: str) -> str:
    return "'" + s.replace("'", "'\"'\"'") + "'"


def run_bash_command(command: str, norc: bool) -> int:
    full = bash_prelude(norc) + command
    proc = subprocess.run(["/bin/bash", "-c", full, ""])
    return normalize_returncode(proc.returncode)


def run_bash_file(path: str, norc: bool) -> int:
    if not os.path.exists(path):
        print('nsh: panicked at src/main.rs:114:34:', file=sys.stderr)
        print(f'failed to open the file: Os {{ code: 2, kind: NotFound, message: "No such file or directory" }}', file=sys.stderr)
        return 101
    full = bash_prelude(norc) + f". {shell_quote(path)}"
    proc = subprocess.run(["/bin/bash", "-c", full, "bash"])
    return normalize_returncode(proc.returncode)


def normalize_returncode(code: int) -> int:
    if code < 0:
        return 128 + (-code)
    return code


def repl(norc: bool) -> int:
    if not sys.stdout.isatty():
        print("nsh: warning: stdout is not a tty", file=sys.stderr)
        return 0
    status = 0
    while True:
        try:
            line = input("$ ")
        except EOFError:
            print()
            return status
        except KeyboardInterrupt:
            print()
            status = 130
            continue
        if not line.strip():
            continue
        status = run_bash_command(line, norc)


def main(argv):
    signal.signal(signal.SIGINT, signal.SIG_DFL)
    _, opts = parse_args(argv)
    if opts["command"] is not None:
        return run_bash_command(opts["command"], opts["norc"])
    if opts["file"] is not None:
        return run_bash_file(opts["file"], opts["norc"])
    return repl(opts["norc"])


if __name__ == "__main__":
    sys.exit(main(sys.argv))
