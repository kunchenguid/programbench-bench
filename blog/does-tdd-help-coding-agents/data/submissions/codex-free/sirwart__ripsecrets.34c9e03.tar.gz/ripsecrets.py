#!/usr/bin/env python3
import fnmatch
import math
import os
import re
import stat
import sys


VERSION = "ripsecrets 0.1.11"

HELP = """ripsecrets searches files and directories recursively for secret API keys.
It's primarily designed to be used as a pre-commit to prevent committing
secrets into version control.

Usage: executable [OPTIONS] [Source files]...

Arguments:
  [Source files]...
          Source files. Can be files or directories. Defaults to '.'

Options:
      --install-pre-commit
          Install `ripsecrets` as a pre-commit hook automatically in git directory provided

      --strict-ignore
          If you pass a path as an argument that's ignored by .secretsignore it will be scanned by default. --strict-ignore will override this behavior and not search the paths passed as arguments that are excluded by the .secretsignore file. This is useful when invoking secrets as a pre-commit

      --only-matching
          Print only the matched (non-empty) parts of a matching line, with each such part on a separate output line

      --additional-pattern <ADDITIONAL_PATTERNS>
          Additional regex patterns used to find secrets. If there is a matching group in the regex the matched group will be tested for randomness before being reported as a secret

  -h, --help
          Print help (see a summary with '-h')

  -V, --version
          Print version
"""

SHORT_HELP = """A command-line tool to prevent committing secret keys into your source code

Usage: executable [OPTIONS] [Source files]...

Arguments:
  [Source files]...  Source files. Can be files or directories. Defaults to '.'

Options:
      --install-pre-commit
          Install `ripsecrets` as a pre-commit hook automatically in git directory provided
      --strict-ignore
          If you pass a path as an argument that's ignored by .secretsignore it will be scanned by default. --strict-ignore will override this behavior and not search the paths passed as arguments that are excluded by the .secretsignore file. This is useful when invoking secrets as a pre-commit
      --only-matching
          Print only the matched (non-empty) parts of a matching line, with each such part on a separate output line
      --additional-pattern <ADDITIONAL_PATTERNS>
          Additional regex patterns used to find secrets. If there is a matching group in the regex the matched group will be tested for randomness before being reported as a secret
  -h, --help
          Print help (see more with '--help')
  -V, --version
          Print version
"""


class Pattern:
    def __init__(self, regex, entropy=False, flags=re.IGNORECASE):
        self.re = re.compile(regex, flags)
        self.entropy = entropy


PATTERNS = [
    Pattern(r"(AIza[0-9A-Za-z_\-]{35})", False, 0),
    Pattern(r"(gh[pousr]_[0-9A-Za-z]{36})", False, 0),
    Pattern(r"(github_pat_[0-9A-Za-z_]{22,255})", False, 0),
    Pattern(r"(glpat-[0-9A-Za-z_\-]{20,})", False, 0),
    Pattern(r"(xox[abprs]-[0-9A-Za-z\-]{10,100})", False, 0),
    Pattern(r"((?:sk|rk)_live_[0-9A-Za-z]{20,})", False, 0),
    Pattern(r"(-----BEGIN [A-Z ]*PRIVATE KEY-----)", False, 0),
    Pattern(r"(?:aws|amazon|amzn).{0,30}(?:access.{0,8})?key.{0,12}['\"]?(A[KS]IA[0-9A-Z]{16})['\"]?", False),
    Pattern(r"(?:aws|amazon|amzn).{0,60}?(?:secret|key|token).{0,60}?[^A-Za-z0-9/+=]([A-Za-z0-9/+=]{30,})['\"]?"),
    Pattern(r"(?:api[_-]?key|token|secret|client[_-]?secret|private[_-]?key|access[_-]?token|auth[_-]?token|password)\s*[:=]\s*['\"]?([A-Za-z0-9_\-./+=]{16,})['\"]?", True),
    Pattern(r"(?:authorization|bearer)\s*[:= ]+\s*['\"]?(Bearer\s+)?([A-Za-z0-9_\-./+=]{24,})['\"]?", True),
]


def entropy(s):
    if not s:
        return 0.0
    counts = {}
    for ch in s:
        counts[ch] = counts.get(ch, 0) + 1
    total = len(s)
    return -sum((n / total) * math.log2(n / total) for n in counts.values())


def random_enough(s):
    cleaned = re.sub(r"[^A-Za-z0-9+/=_\-]", "", s)
    if len(cleaned) < 16:
        return False
    if len(set(cleaned)) < 8:
        return False
    return entropy(cleaned) >= 3.0


def parse_args(argv):
    opts = {"install": False, "strict": False, "only": False, "additional": [], "paths": []}
    i = 0
    while i < len(argv):
        a = argv[i]
        if a == "--":
            opts["paths"].extend(argv[i + 1 :])
            break
        if a in ("-h", "--help"):
            print(SHORT_HELP if a == "-h" else HELP, end="")
            raise SystemExit(0)
        if a in ("-V", "--version"):
            print(VERSION)
            raise SystemExit(0)
        if a == "--install-pre-commit":
            opts["install"] = True
        elif a == "--strict-ignore":
            opts["strict"] = True
        elif a == "--only-matching":
            opts["only"] = True
        elif a == "--additional-pattern":
            if i + 1 >= len(argv):
                print("error: a value is required for '--additional-pattern <ADDITIONAL_PATTERNS>' but none was supplied", file=sys.stderr)
                raise SystemExit(2)
            opts["additional"].append(argv[i + 1])
            i += 1
        elif a.startswith("--additional-pattern="):
            opts["additional"].append(a.split("=", 1)[1])
        elif a.startswith("-"):
            print(f"error: unexpected argument '{a}' found\n", file=sys.stderr)
            print(f"  tip: to pass '{a}' as a value, use '-- {a}'\n", file=sys.stderr)
            print("Usage: executable [OPTIONS] [Source files]...\n", file=sys.stderr)
            print("For more information, try '--help'.", file=sys.stderr)
            raise SystemExit(2)
        else:
            opts["paths"].append(a)
        i += 1
    return opts


def install_pre_commit():
    git = ".git"
    if not os.path.isdir(git):
        print("Error: .git directory not found", file=sys.stderr)
        return 2
    hooks = os.path.join(git, "hooks")
    os.makedirs(hooks, exist_ok=True)
    path = os.path.join(hooks, "pre-commit")
    if os.path.exists(path):
        print("Error: pre-commit hook has already been installed", file=sys.stderr)
        return 2
    with open(path, "w", encoding="utf-8") as f:
        f.write("ripsecrets --strict-ignore `git diff --cached --name-only --diff-filter=ACM`\n")
    os.chmod(path, os.stat(path).st_mode | stat.S_IXUSR)
    return 0


def load_ignore():
    patterns = []
    secrets = []
    in_secrets = False
    try:
        lines = open(".secretsignore", encoding="utf-8").read().splitlines()
    except OSError:
        return patterns, secrets
    for raw in lines:
        line = raw.strip()
        if not line or line.startswith("#"):
            continue
        if line == "[secrets]":
            in_secrets = True
            continue
        if in_secrets:
            secrets.append(line)
        else:
            patterns.append(line)
    return patterns, secrets


def ignored_by_patterns(path, patterns):
    p = path.replace(os.sep, "/")
    if p.startswith("./"):
        p = p[2:]
    ignored = False
    for pat in patterns:
        neg = pat.startswith("!")
        if neg:
            pat = pat[1:]
        anchored = pat.startswith("/")
        if anchored:
            pat = pat[1:]
        dir_pat = pat.endswith("/")
        if dir_pat:
            pat = pat.rstrip("/")
        matched = False
        targets = [p] if "/" in pat or anchored else [p, os.path.basename(p)]
        for t in targets:
            if fnmatch.fnmatch(t, pat) or (dir_pat and (t == pat or t.startswith(pat + "/"))):
                matched = True
                break
        if matched:
            ignored = not neg
    return ignored


def display_path(path, explicit_single=False):
    if path.startswith("./") or path.startswith("/"):
        return path
    if "/" not in path and not explicit_single:
        return "./" + path
    return path


def iter_files(paths, ignore_patterns, strict):
    explicit = set(os.path.normpath(p) for p in paths)
    for src in paths:
        if not os.path.exists(src):
            print(f"{src}: No such file or directory (os error 2)", file=sys.stderr)
            continue
        normsrc = os.path.normpath(src)
        if os.path.isfile(src):
            if strict and ignored_by_patterns(normsrc, ignore_patterns):
                continue
            yield src, len(paths) == 1
            continue
        if strict and ignored_by_patterns(normsrc, ignore_patterns):
            continue
        for root, dirs, files in os.walk(src):
            dirs.sort(reverse=True)
            files.sort(reverse=True)
            dirs[:] = [d for d in dirs if not d.startswith(".") and not ignored_by_patterns(os.path.join(root, d), ignore_patterns)]
            for name in files:
                if name.startswith("."):
                    continue
                path = os.path.join(root, name)
                npath = os.path.normpath(path)
                if ignored_by_patterns(npath, ignore_patterns) and npath not in explicit:
                    continue
                yield path, False


def best_group(match):
    groups = [g for g in match.groups() if g]
    if groups:
        return groups[-1]
    return match.group(0)


def scan_file(path, explicit_single, only_matching, secret_ignores, add_patterns):
    found = False
    try:
        with open(path, "rb") as f:
            data = f.read()
    except OSError:
        return False
    if b"\0" in data:
        return False
    try:
        text = data.decode("utf-8")
    except UnicodeDecodeError:
        text = data.decode("utf-8", "ignore")
    shown = display_path(path, explicit_single)
    patterns = PATTERNS + add_patterns
    for lineno, line in enumerate(text.splitlines(), 1):
        if any(secret and secret in line for secret in secret_ignores):
            continue
        line_hits = []
        for pat in patterns:
            for m in pat.re.finditer(line):
                val = best_group(m)
                if any(secret and secret in val for secret in secret_ignores):
                    continue
                check_entropy = pat.entropy or (m.lastindex is not None and pat in add_patterns)
                if check_entropy and not random_enough(val):
                    continue
                line_hits.append(val)
        if line_hits:
            found = True
            if only_matching:
                for val in line_hits:
                    print(f"{shown}:{lineno}:{val}")
            else:
                print(f"{shown}:{lineno}:{line}")
    return found


def main(argv):
    opts = parse_args(argv)
    if opts["install"]:
        return install_pre_commit()
    add_patterns = []
    for raw in opts["additional"]:
        try:
            add_patterns.append(Pattern(raw, False))
        except re.error as e:
            print(f"Error: {e}", file=sys.stderr)
            return 2
    paths = opts["paths"] or ["."]
    ignore_patterns, secret_ignores = load_ignore()
    any_found = False
    for path, explicit_single in iter_files(paths, ignore_patterns, opts["strict"]):
        if scan_file(path, explicit_single, opts["only"], secret_ignores, add_patterns):
            any_found = True
    return 1 if any_found else 0


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
