#!/usr/bin/env python3
import os
import re
import sys

VERSION = "hexyl 0.16.0"

HELP = """A command-line hex viewer

Usage: executable [OPTIONS] [FILE]

Arguments:
  [FILE]  The file to display. If no FILE argument is given, read from STDIN

Options:
  -n, --length <N>                Only read N bytes from the input. The N argument can
                                  also include a unit with a decimal prefix (kB, MB, ..)
                                  or binary prefix (kiB, MiB, ..), or can be specified
                                  using a hex number. The short option '-l' can be used as
                                  an alias.
                                  Examples: --length=64, --length=4KiB, --length=0xff
                                  [aliases: bytes] [short aliases: c]
  -s, --skip <N>                  Skip the first N bytes of the input. The N argument can
                                  also include a unit (see `--length` for details).
                                  A negative value is valid and will seek from the end of
                                  the file.
      --block-size <SIZE>         Sets the size of the `block` unit to SIZE.
                                  Examples: --block-size=1024, --block-size=4kB [default:
                                  512]
  -v, --no-squeezing              Displays all input data. Otherwise any number of groups
                                  of output lines which would be identical to the
                                  preceding group of lines, are replaced with a line
                                  comprised of a single asterisk
      --color <WHEN>              When to use colors [default: always] [possible values:
                                  always, auto, never, force]
      --border <STYLE>            Whether to draw a border [default: unicode] [possible
                                  values: unicode, ascii, none]
  -p, --plain                     Display output with --no-characters, --no-position,
                                  --border=none, and --color=never
      --no-characters             Do not show the character panel on the right
  -C, --characters                Show the character panel on the right. This is the
                                  default, unless --no-characters has been specified
      --character-table <FORMAT>  Defines how bytes are mapped to characters [default:
                                  default] [possible values: default, ascii,
                                  codepage-1047, codepage-437, braille]
      --color-scheme <FORMAT>     Defines the color scheme for the characters [default:
                                  default] [possible values: default, gradient]
  -P, --no-position               Whether to display the position panel on the left
  -o, --display-offset <N>        Add N bytes to the displayed file position. The N
                                  argument can also include a unit (see `--length` for
                                  details).
                                  A negative value is valid and calculates an offset
                                  relative to the end of the file. [default: 0]
      --panels <N>                Sets the number of hex data panels to be displayed.
                                  `--panels=auto` will display the maximum number of hex
                                  data panels based on the current terminal width. By
                                  default, hexyl will show two panels, unless the terminal
                                  is not wide enough for that
  -g, --group-size <N>            Number of bytes/octets that should be grouped together.
                                  You can use the '--endianness' option to control the
                                  ordering of the bytes within a group. '--groupsize' can
                                  be used as an alias (xxd-compatibility) [default: 1]
                                  [possible values: 1, 2, 4, 8]
      --endianness <FORMAT>       Whether to print out groups in little-endian or
                                  big-endian format. This option only has an effect if the
                                  '--group-size' is larger than 1. '-e' can be used as an
                                  alias for '--endianness=little' [default: big]
                                  [possible values: little, big]
  -b, --base <B>                  Sets the base used for the bytes. The possible options
                                  are binary, octal, decimal, and hexadecimal [default:
                                  hexadecimal]
      --terminal-width <N>        Sets the number of terminal columns to be displayed.
                                  Since the terminal width may not be an evenly divisible
                                  by the width per hex data column, this will use the
                                  greatest number of hex data panels that can fit in the
                                  requested width but still leave some space to the right.
                                  Cannot be used with other width-setting options.
      --print-color-table         Print a table showing how different types of bytes are
                                  colored
  -i, --include                   Output in C include file style
      --completion <SHELL>        Show shell completion for a certain shell [possible
                                  values: bash, elvish, fish, powershell, zsh]
  -h, --help                      Print help (see more with '--help')
  -V, --version                   Print version
"""


def fail(msg):
    print(f"error: {msg}", file=sys.stderr)
    sys.exit(2)


def parse_size(s, block=512):
    neg = s.startswith("-")
    t = s[1:] if neg else s
    mults = {
        "b": 1, "kb": 1000, "mb": 1000**2, "gb": 1000**3, "tb": 1000**4,
        "kib": 1024, "mib": 1024**2, "gib": 1024**3, "tib": 1024**4,
        "block": block,
    }
    m = re.fullmatch(r"(0x[0-9a-fA-F]+|\d+)([A-Za-z]+)?", t)
    if not m:
        fail(f"invalid value '{s}'")
    n = int(m.group(1), 0)
    unit = (m.group(2) or "").lower()
    if unit:
        if unit not in mults:
            fail(f"invalid unit '{unit}'")
        n *= mults[unit]
    return -n if neg else n


def parse_args(argv):
    opt = {
        "length": None, "skip": 0, "block": 512, "squeeze": True,
        "color": "always", "border": "unicode", "chars": True, "pos": True,
        "ctable": "default", "scheme": "default", "offset": 0, "panels": None,
        "group": 1, "endian": "big", "base": "hexadecimal", "term": None,
        "include": False, "file": None,
    }
    i = 0
    while i < len(argv):
        a = argv[i]
        def val():
            nonlocal i, a
            if "=" in a:
                return a.split("=", 1)[1]
            i += 1
            if i >= len(argv):
                fail(f"a value is required for '{a}'")
            return argv[i]
        if a == "--":
            if i + 1 < len(argv):
                opt["file"] = argv[i + 1]
            break
        elif a in ("-h", "--help"):
            print(HELP, end="")
            sys.exit(0)
        elif a == "--help" or a == "-?":
            print(HELP, end="")
            sys.exit(0)
        elif a in ("-V", "--version"):
            print(VERSION)
            sys.exit(0)
        elif a.startswith("--length") or a.startswith("--bytes") or a in ("-n", "-c", "-l"):
            opt["length"] = val()
        elif a.startswith("-n") and len(a) > 2:
            opt["length"] = a[2:]
        elif a.startswith("-c") and len(a) > 2:
            opt["length"] = a[2:]
        elif a.startswith("-l") and len(a) > 2:
            opt["length"] = a[2:]
        elif a.startswith("--skip") or a == "-s":
            opt["skip"] = val()
        elif a.startswith("-s="):
            opt["skip"] = a.split("=", 1)[1]
        elif a.startswith("-s") and len(a) > 2:
            opt["skip"] = a[2:]
        elif a.startswith("--block-size"):
            opt["block"] = parse_size(val(), opt["block"])
        elif a in ("-v", "--no-squeezing"):
            opt["squeeze"] = False
        elif a.startswith("--color"):
            opt["color"] = val()
        elif a.startswith("--border"):
            opt["border"] = val()
        elif a in ("-p", "--plain"):
            opt["chars"] = False; opt["pos"] = False; opt["border"] = "none"; opt["color"] = "never"
        elif a == "--no-characters":
            opt["chars"] = False
        elif a in ("-C", "--characters"):
            opt["chars"] = True
        elif a.startswith("--character-table"):
            opt["ctable"] = val()
        elif a.startswith("--color-scheme"):
            opt["scheme"] = val()
        elif a in ("-P", "--no-position"):
            opt["pos"] = False
        elif a.startswith("--display-offset") or a == "-o":
            opt["offset"] = val()
        elif a.startswith("-o="):
            opt["offset"] = a.split("=", 1)[1]
        elif a.startswith("-o") and len(a) > 2:
            opt["offset"] = a[2:]
        elif a.startswith("--panels"):
            opt["panels"] = val()
        elif a.startswith("--group-size") or a.startswith("--groupsize") or a == "-g":
            opt["group"] = int(val())
        elif a.startswith("-g") and len(a) > 2:
            opt["group"] = int(a[2:])
        elif a.startswith("--endianness"):
            opt["endian"] = val()
        elif a == "-e":
            opt["endian"] = "little"
        elif a.startswith("--base") or a == "-b":
            opt["base"] = val()
        elif a.startswith("-b") and len(a) > 2:
            opt["base"] = a[2:]
        elif a.startswith("--terminal-width"):
            opt["term"] = int(val())
        elif a == "--print-color-table":
            print_color_table()
            sys.exit(0)
        elif a == "-i" or a == "--include":
            opt["include"] = True
        elif a.startswith("--completion"):
            print("")
            sys.exit(0)
        elif a.startswith("-"):
            fail(f"unexpected argument '{a}' found")
        else:
            if opt["file"] is not None:
                fail(f"unexpected argument '{a}' found")
            opt["file"] = a
        i += 1
    opt["block"] = int(opt["block"])
    if isinstance(opt["skip"], str):
        opt["skip"] = parse_size(opt["skip"], opt["block"])
    if isinstance(opt["length"], str):
        opt["length"] = parse_size(opt["length"], opt["block"])
    if isinstance(opt["offset"], str):
        if opt["offset"].startswith("-"):
            print(f"Error: failed to parse `--display-offset` arg \"{opt['offset']}\" as byte count", file=sys.stderr)
            print(file=sys.stderr)
            print("Caused by:", file=sys.stderr)
            print("    negative offset specified, but only positive offsets (counts) are accepted in this context", file=sys.stderr)
            sys.exit(1)
        opt["offset"] = parse_size(opt["offset"], opt["block"])
    if opt["group"] not in (1, 2, 4, 8):
        fail("invalid value for '--group-size <N>'")
    aliases = {"hex": "hexadecimal", "dec": "decimal", "oct": "octal", "bin": "binary"}
    opt["base"] = aliases.get(opt["base"], opt["base"])
    return opt


def ansi_for(b):
    if b == 0:
        return "\033[90m"
    if 32 <= b <= 126 and b != 32:
        return "\033[36m"
    if b < 128:
        return "\033[32m"
    return "\033[33m"


def ch(b, table):
    if table == "ascii" or table.startswith("codepage"):
        return chr(b) if 32 <= b <= 126 else (" " if b == 32 else ".")
    if table == "braille":
        if b == 32:
            return " "
        return chr(0x2800 + b)
    if b == 0:
        return "⋄"
    if b == 32:
        return " "
    if b in (9, 10, 12, 13):
        return "_"
    if 33 <= b <= 126:
        return chr(b)
    if b < 128:
        return "•"
    return "×"


def fmt_byte(b, base):
    if base == "decimal":
        return f"{b:03d}"
    if base == "octal":
        return f"{b:03o}"
    if base == "binary":
        return f"{b:08b}"
    return f"{b:02x}"


def group_token(bs, base, endian):
    if base != "hexadecimal" or len(bs) == 1:
        return " ".join(fmt_byte(b, base) for b in bs)
    data = list(bs)
    if endian == "little":
        data.reverse()
    return "".join(f"{b:02x}" for b in data)


def widths(base, group):
    if base in ("decimal", "octal"):
        return 33
    if base == "binary":
        return 73
    return 1 + (8 // group) * (2 * group + 1)


def border_chars(style):
    if style == "ascii":
        return dict(tl="+", tr="+", bl="+", br="+", h="-", v="|", tj="+", bj="+", sep="|")
    return dict(tl="┌", tr="┐", bl="└", br="┘", h="─", v="│", tj="┬", bj="┴", sep="┊")


def colorize(s, b, use):
    return ansi_for(b) + s + "\033[39m" if use else s


def panel_hex(bs, opt, use_color):
    group = opt["group"]
    base = opt["base"]
    w = widths(base, group)
    if not bs:
        return " " * w
    parts = []
    if base == "hexadecimal" and group > 1:
        for j in range(0, len(bs), group):
            g = bs[j:j + group]
            token = group_token(g, base, opt["endian"])
            parts.append(colorize(token, g[0], use_color))
    else:
        for b in bs:
            parts.append(colorize(fmt_byte(b, base), b, use_color))
    plain_len = 1 + sum(len(re.sub(r"\x1b\[[0-9;]*m", "", p)) for p in parts) + max(0, len(parts) - 1) + 1
    return " " + " ".join(parts) + " " * max(0, w - plain_len + 1)


def panel_chars(bs, opt, use_color):
    out = ""
    for b in bs:
        out += colorize(ch(b, opt["ctable"]), b, use_color)
    out += " " * (8 - len(bs))
    return out


def printable_plain_len(s):
    return len(re.sub(r"\x1b\[[0-9;]*m", "", s))


def make_row(offset, row, opt, empty=False, star=False):
    panels = opt["panel_count"]
    bstyle = opt["border"]
    use_color = opt["use_color"]
    c = border_chars("ascii" if bstyle == "ascii" else "unicode")
    if star:
        if bstyle == "none":
            return "*"
        if opt["pos"]:
            s = c["v"] + "*       "
        else:
            s = c["v"]
        if panels:
            if opt["pos"]:
                s += c["v"]
            for p in range(panels):
                if p:
                    s += c["sep"]
                s += " " * widths(opt["base"], opt["group"])
        if opt["chars"]:
            s += c["v"]
            for p in range(panels):
                if p:
                    s += c["sep"]
                s += " " * 8
        return s + c["v"]
    hex_cells = []
    char_cells = []
    for p in range(panels):
        seg = row[p * 8:(p + 1) * 8]
        hex_cells.append(panel_hex(seg, opt, use_color))
        if opt["chars"]:
            char_cells.append(panel_chars(seg, opt, use_color))
    off = f"{offset & 0xffffffff:08x}"
    if use_color:
        off = "\033[90m" + off + "\033[39m"
    if bstyle == "none":
        if opt["pos"]:
            s = " " + off + " "
        else:
            s = " "
        s += " ".join(hex_cells)
        if opt["chars"]:
            s += " " + " ".join(char_cells)
        return s + " "
    s = c["v"]
    if opt["pos"]:
        s += off + c["v"]
    for p, cell in enumerate(hex_cells):
        if p:
            s += c["sep"]
        s += cell
    if opt["chars"]:
        s += c["v"]
        for p, cell in enumerate(char_cells):
            if p:
                s += c["sep"]
            s += cell
    return s + c["v"]


def make_border(opt, top=True):
    if opt["border"] == "none":
        return None
    c = border_chars("ascii" if opt["border"] == "ascii" else "unicode")
    left = c["tl"] if top else c["bl"]
    right = c["tr"] if top else c["br"]
    join = c["tj"] if top else c["bj"]
    cells = []
    if opt["pos"]:
        cells.append(c["h"] * 8)
    cells += [c["h"] * widths(opt["base"], opt["group"]) for _ in range(opt["panel_count"])]
    if opt["chars"]:
        cells += [c["h"] * 8 for _ in range(opt["panel_count"])]
    return left + join.join(cells) + right


def include_output(data, path):
    if path:
        name = re.sub(r"[^A-Za-z0-9_]", "_", os.path.basename(path))
        print(f"unsigned char {name}[] = {{")
    line = []
    for i, b in enumerate(data):
        line.append(f"0x{b:02x}")
        if len(line) == 12 or i == len(data) - 1:
            suffix = "," if i != len(data) - 1 else ""
            print("  " + ", ".join(line) + suffix)
            line = []
    if path:
        print("};")
        print(f"unsigned int {name}_len = {len(data)};")


def print_color_table():
    print("Color table")
    print("NULL bytes, ASCII whitespace, printable ASCII, other ASCII, non-ASCII")


def render(data, opt):
    if opt["panels"] is None:
        panels = 1 if opt["base"] != "hexadecimal" else 2
    elif opt["panels"] == "auto":
        tw = opt["term"] or 80
        per = widths(opt["base"], opt["group"]) + (8 if opt["chars"] else 0) + 2
        panels = max(1, min(8, (tw - (10 if opt["pos"] else 2)) // max(1, per)))
    else:
        panels = max(1, int(opt["panels"]))
    if opt["term"] and opt["panels"] is None and opt["base"] == "hexadecimal":
        panels = 1 if opt["term"] < 80 else 2
    opt["panel_count"] = panels
    opt["use_color"] = opt["color"] in ("always", "force") and opt["border"] != "none"
    row_len = panels * 8
    top = make_border(opt, True)
    if top:
        print(top)
    prev = None
    squeezed = False
    suppressed = False
    offbase = opt["display_base"]
    for start in range(0, len(data), row_len):
        row = data[start:start + row_len]
        full = len(row) == row_len
        if opt["squeeze"] and full and prev is not None and row == prev:
            if not suppressed:
                print(make_row(0, b"", opt, star=True))
                suppressed = True
                squeezed = True
            continue
        suppressed = False
        prev = row if full else None
        print(make_row(offbase + start, row, opt))
    if squeezed and len(data) % row_len == 0:
        print(make_row(offbase + len(data), b"", opt))
    bot = make_border(opt, False)
    if bot:
        print(bot)


def main():
    opt = parse_args(sys.argv[1:])
    if opt["file"]:
        try:
            with open(opt["file"], "rb") as f:
                raw = f.read()
        except OSError as e:
            print(f"error: {e}", file=sys.stderr)
            return 1
    else:
        raw = sys.stdin.buffer.read()
    total = len(raw)
    skip = opt["skip"]
    if skip < 0:
        skip = max(0, total + skip)
    data = raw[skip:]
    if opt["length"] is not None:
        data = data[:max(0, opt["length"])]
    display = opt["offset"]
    if display < 0:
        display = total + display
    opt["display_base"] = skip + display
    if opt["include"]:
        include_output(data, opt["file"])
    else:
        render(data, opt)
    return 0


if __name__ == "__main__":
    sys.exit(main())
