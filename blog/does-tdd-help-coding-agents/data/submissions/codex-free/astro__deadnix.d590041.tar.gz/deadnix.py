#!/usr/bin/env python3
import argparse
import json
import os
import re
import sys
from dataclasses import dataclass
from typing import List, Optional, Tuple

IDENT_RE = re.compile(r"[A-Za-z_][A-Za-z0-9_'-]*")


@dataclass
class Finding:
    line: int
    column: int
    endColumn: int
    message: str
    kind: str = ""
    remove_line: Optional[int] = None


@dataclass
class Decl:
    name: str
    line: int
    col: int
    end: int
    kind: str
    scope_start: int
    scope_end: int
    decl_line: int
    decl_start: int = 0
    decl_end: int = 0
    remove_line: Optional[int] = None


def line_offsets(text: str) -> List[int]:
    offs = [0]
    for i, ch in enumerate(text):
        if ch == "\n":
            offs.append(i + 1)
    return offs


def pos_to_line_col(offs: List[int], pos: int) -> Tuple[int, int]:
    lo, hi = 0, len(offs) - 1
    while lo <= hi:
        mid = (lo + hi) // 2
        if offs[mid] <= pos:
            lo = mid + 1
        else:
            hi = mid - 1
    line = hi + 1
    return line, pos - offs[hi] + 1


def sanitize(text: str) -> str:
    """Blank comments and ordinary string text, preserving positions and ${...}."""
    out = list(text)
    i = 0
    n = len(text)
    while i < n:
        if text.startswith("#", i):
            j = i
            while j < n and text[j] != "\n":
                out[j] = " "
                j += 1
            i = j
        elif text.startswith("''", i):
            out[i] = out[i + 1] = " "
            i += 2
            while i < n and not text.startswith("''", i):
                if text.startswith("${", i):
                    i += 2
                    depth = 1
                    while i < n and depth:
                        if text[i] == "{":
                            depth += 1
                        elif text[i] == "}":
                            depth -= 1
                        i += 1
                else:
                    if text[i] != "\n":
                        out[i] = " "
                    i += 1
            if i < n - 1:
                out[i] = out[i + 1] = " "
                i += 2
        elif text[i] == '"':
            out[i] = " "
            i += 1
            while i < n:
                if text.startswith("${", i):
                    i += 2
                    depth = 1
                    while i < n and depth:
                        if text[i] == "{":
                            depth += 1
                        elif text[i] == "}":
                            depth -= 1
                        i += 1
                elif text[i] == "\\":
                    out[i] = " "
                    if i + 1 < n:
                        out[i + 1] = " "
                    i += 2
                elif text[i] == '"':
                    out[i] = " "
                    i += 1
                    break
                else:
                    if text[i] != "\n":
                        out[i] = " "
                    i += 1
        else:
            i += 1
    return "".join(out)


def words(text: str):
    for m in IDENT_RE.finditer(text):
        yield m.group(0), m.start(), m.end()


def matching_in(clean: str, let_pos: int) -> int:
    depth = 0
    for w, s, _e in words(clean[let_pos:]):
        p = let_pos + s
        if w == "let":
            depth += 1
        elif w == "in":
            depth -= 1
            if depth == 0:
                return p
    return -1


def line_start_end(text: str, pos: int) -> Tuple[int, int]:
    a = text.rfind("\n", 0, pos) + 1
    b = text.find("\n", pos)
    if b < 0:
        b = len(text)
    return a, b


def scope_end_guess(clean: str, start: int) -> int:
    # Good enough for the expression following "in" or a lambda colon.
    return len(clean)


def find_let_decls(text: str, clean: str, offs: List[int]) -> List[Decl]:
    decls: List[Decl] = []
    for m in re.finditer(r"\blet\b", clean):
        ls, _le = line_start_end(clean, m.start())
        if clean[ls:m.start()].strip():
            continue
        in_pos = matching_in(clean, m.start())
        if in_pos < 0:
            continue
        binding_area = clean[m.end():in_pos]
        body_start = in_pos + 2
        body_end = scope_end_guess(clean, body_start)
        base = m.end()
        # Ordinary single-line assignments in the let binding area.
        for am in re.finditer(r"(?m)^([ \t]*)([A-Za-z_][A-Za-z0-9_'-]*)\s*=", binding_area):
            name = am.group(2)
            pos = base + am.start(2)
            line, col = pos_to_line_col(offs, pos)
            decls.append(Decl(name, line, col, col + len(name), "let binding", pos + len(name), body_end, line, pos, pos + len(name), pos))
        # Inherit statements. Each inherited name is a let binding.
        for im in re.finditer(r"(?m)^[ \t]*inherit(?:\s*\([^;\n]*\))?\s+([^;\n]+);", binding_area):
            stmt = im.group(0)
            stmt_pos = base + im.start()
            for nm in IDENT_RE.finditer(stmt):
                name = nm.group(0)
                if name == "inherit" or name in ("or", "if", "then", "else", "assert", "with", "let", "in", "rec"):
                    continue
                # Skip identifiers inside the source expression "(builtins)".
                prefix = stmt[:nm.start()]
                if "(" in prefix and ")" not in prefix.split("(")[-1]:
                    continue
                pos = stmt_pos + nm.start()
                line, col = pos_to_line_col(offs, pos)
                decls.append(Decl(name, line, col, col + len(name), "let binding", pos + len(name), body_end, line, pos, pos + len(name), pos))
    return decls


def split_pattern_items(s: str) -> List[Tuple[str, int]]:
    items = []
    depth = 0
    start = 0
    for i, ch in enumerate(s + ","):
        if ch in "([{":
            depth += 1
        elif ch in ")]}":
            depth = max(0, depth - 1)
        elif ch == "," and depth == 0:
            part = s[start:i]
            base = start
            start = i + 1
            part_stripped = part.strip()
            if not part_stripped or part_stripped == "...":
                continue
            mm = IDENT_RE.search(part)
            if mm:
                items.append((mm.group(0), base + mm.start()))
    return items


def find_lambda_decls(clean: str, offs: List[int], args) -> List[Decl]:
    decls: List[Decl] = []
    # Attrset lambdas: args@{ a, b ? 1, ... }: or { a, b }@args:
    pat = re.compile(r"(?:(?P<pre>[A-Za-z_][A-Za-z0-9_'-]*)\s*@\s*)?\{(?P<body>[^{}]*)\}(?:\s*@\s*(?P<post>[A-Za-z_][A-Za-z0-9_'-]*))?\s*:")
    spans = []
    for m in pat.finditer(clean):
        spans.append((m.start(), m.end()))
        body_start = m.start("body")
        body_end = scope_end_guess(clean, body_start)
        if not args.no_lambda_pattern_names:
            if m.group("pre"):
                pos = m.start("pre")
                name = m.group("pre")
                line, col = pos_to_line_col(offs, pos)
                decls.append(Decl(name, line, col, col + len(name), "lambda pattern", body_start, body_end, line, pos, pos + len(name)))
            if m.group("post"):
                pos = m.start("post")
                name = m.group("post")
                line, col = pos_to_line_col(offs, pos)
                decls.append(Decl(name, line, col, col + len(name), "lambda pattern", body_start, body_end, line, pos, pos + len(name)))
            for name, rel in split_pattern_items(m.group("body")):
                if name == "...":
                    continue
                pos = m.start("body") + rel
                line, col = pos_to_line_col(offs, pos)
                decls.append(Decl(name, line, col, col + len(name), "lambda pattern", body_start, body_end, line, pos, pos + len(name)))
    if not args.no_lambda_arg:
        # Simple arguments immediately before a colon. Avoid attr paths and already matched patterns.
        for m in re.finditer(r"\b([A-Za-z_][A-Za-z0-9_'-]*)\s*:", clean):
            if any(a <= m.start() < b for a, b in spans):
                continue
            name = m.group(1)
            if name.startswith("_"):
                continue
            before = clean[max(0, m.start() - 2):m.start()]
            if "." in before:
                continue
            pos = m.start(1)
            line, col = pos_to_line_col(offs, pos)
            decls.append(Decl(name, line, col, col + len(name), "lambda argument", m.end(), len(clean), line, pos, pos + len(name)))
    return decls


def references(clean: str, name: str, start: int, end: int, decl_start: int, decl_end: int, offs: List[int]) -> int:
    count = 0
    pat = re.compile(r"(?<![A-Za-z0-9_'-])" + re.escape(name) + r"(?![A-Za-z0-9_'-])")
    for m in pat.finditer(clean, start, end):
        if decl_start <= m.start() < decl_end:
            continue
        # Attrset key definitions like "name =" do not count as reads.
        after = clean[m.end():m.end() + 8]
        if re.match(r"\s*=", after):
            continue
        if re.match(r"\s*:", after):
            continue
        line_start = clean.rfind("\n", 0, m.start()) + 1
        prefix = clean[line_start:m.start()]
        if re.search(r"\blet\s+" + re.escape(name) + r"\s*=", prefix):
            continue
        count += 1
    return count


def analyze_file(path: str, args) -> Tuple[List[Finding], List[str]]:
    try:
        with open(path, "r", encoding="utf-8") as f:
            text = f.read()
    except OSError as e:
        return [], [str(e)]
    # Coarse parse-error compatibility for obvious missing RHS cases.
    if re.search(r"=\s*;", text):
        return [], [
            "unexpected TOKEN_SEMICOLON",
            "unexpected TOKEN_IN",
            "unexpected end of file, wanted any of [TOKEN_SEMICOLON]",
            "unexpected end of file",
            "unexpected end of file",
        ]
    offs = line_offsets(text)
    clean = sanitize(text)
    decls = find_let_decls(text, clean, offs) + find_lambda_decls(clean, offs, args)
    findings: List[Finding] = []
    skip_next = set()
    for i, line in enumerate(text.splitlines(), start=1):
        if "deadnix: skip" in line:
            skip_next.add(i + 1)
    for d in decls:
        if d.line in skip_next:
            continue
        if args.no_underscore and d.name.startswith("_"):
            continue
        used = references(clean, d.name, d.scope_start, d.scope_end, d.decl_start, d.decl_end, offs) > 0
        if args.warn_used_underscore and d.name.startswith("_") and used and d.kind != "lambda argument":
            findings.append(Finding(d.line, d.col, d.end, f"Used {d.kind}: {d.name}", "used", d.remove_line))
        elif not used:
            if d.kind == "lambda argument" and d.name.startswith("_"):
                continue
            findings.append(Finding(d.line, d.col, d.end, f"Unused {d.kind}: {d.name}", "unused", d.remove_line))
    findings.sort(key=lambda f: (f.line, f.column, f.message))
    return findings, []


def human(path: str, text: str, findings: List[Finding], color: bool) -> str:
    if not findings:
        return ""
    lines = text.splitlines()
    out = ["Warning: Unused declarations were found."]
    first = findings[0]
    out.append(f"   ╭─[{path}:{first.line}:{first.column}]")
    by_line = {}
    for f in findings:
        by_line.setdefault(f.line, []).append(f)
    for ln in sorted(by_line):
        src = lines[ln - 1] if 0 <= ln - 1 < len(lines) else ""
        width = max(2, len(str(ln)))
        out.append(f"{ln:>{width}} │{src}")
        for f in by_line[ln]:
            spaces = " " * max(0, f.column - 1)
            mark = "╰" + "─" * max(1, f.endColumn - f.column - 1)
            out.append(f"{'':>{width}} │{spaces}{mark} {f.message}")
    return "\n".join(out)


def edit_file(path: str, findings: List[Finding]) -> None:
    unused_lines = {f.remove_line or f.line for f in findings if f.message.startswith("Unused let binding:")}
    if not unused_lines:
        return
    with open(path, "r", encoding="utf-8") as f:
        lines = f.readlines()
    kept = [line for i, line in enumerate(lines, start=1) if i not in unused_lines]
    with open(path, "w", encoding="utf-8") as f:
        f.writelines(kept)


def collect_paths(paths: List[str], hidden: bool, excludes: List[str]) -> List[str]:
    result = []
    ex = {os.path.normpath(x) for x in excludes}
    for p in paths:
        if os.path.normpath(p) in ex:
            continue
        if os.path.isdir(p):
            for root, dirs, files in os.walk(p):
                if not hidden:
                    dirs[:] = [d for d in dirs if not d.startswith(".")]
                    files = [f for f in files if not f.startswith(".")]
                dirs[:] = [d for d in dirs if os.path.normpath(os.path.join(root, d)) not in ex]
                for f in sorted(files):
                    full = os.path.join(root, f)
                    if full.endswith(".nix") and os.path.normpath(full) not in ex:
                        result.append(full)
        else:
            result.append(p)
    return result


def parse_args(argv):
    parser = argparse.ArgumentParser(add_help=False, prog=os.path.basename(argv[0]), description="Find dead code in .nix files")
    parser.add_argument("-l", "--no-lambda-arg", action="store_true")
    parser.add_argument("-L", "--no-lambda-pattern-names", action="store_true")
    parser.add_argument("-_", "--no-underscore", action="store_true")
    parser.add_argument("-W", "--warn-used-underscore", action="store_true")
    parser.add_argument("-q", "--quiet", action="store_true")
    parser.add_argument("-e", "--edit", action="store_true")
    parser.add_argument("-h", "--hidden", action="store_true")
    parser.add_argument("--help", action="store_true")
    parser.add_argument("-f", "--fail", action="store_true")
    parser.add_argument("-o", "--output-format", default="human-readable", choices=["human-readable", "json"])
    parser.add_argument("--exclude", nargs="+", default=[])
    parser.add_argument("-V", "--version", action="store_true")
    parser.add_argument("file_paths", nargs="*")
    return parser.parse_args(argv[1:])


HELP = """Find dead code in .nix files

Usage: executable [OPTIONS] [FILE_PATHS]...

Arguments:
  [FILE_PATHS]...  .nix files, or directories with .nix files inside [default: .]

Options:
  -l, --no-lambda-arg                  Don't check lambda parameter arguments
  -L, --no-lambda-pattern-names        Don't check lambda attrset pattern names (don't break nixpkgs callPackage)
  -_, --no-underscore                  Don't check any bindings that start with a _
                                       (Lambda arguments starting with _ are not checked anyway.)
  -W, --warn-used-underscore           Warn if bindings are referenced that start with '_'
  -q, --quiet                          Don't print dead code report
  -e, --edit                           Remove unused code and write to source file
  -h, --hidden                         Recurse into hidden subdirectories and process hidden .*.nix files
      --help                           
  -f, --fail                           Exit with 1 if unused code has been found
  -o, --output-format <OUTPUT_FORMAT>  Output format to use [default: human-readable] [possible values: human-readable, json]
      --exclude <EXCLUDES>...          Files to exclude from analysis
  -V, --version                        Print version"""


def main(argv) -> int:
    args = parse_args(argv)
    if args.help:
        print(HELP)
        return 0
    if args.version:
        print("deadnix 1.3.1")
        return 0
    paths = args.file_paths or ["."]
    paths = collect_paths(paths, args.hidden, args.exclude)
    any_findings = False
    for path in paths:
        findings, errors = analyze_file(path, args)
        any_findings = any_findings or bool(findings)
        if args.output_format == "json":
            arr = []
            for e in errors:
                arr.append({"message": e})
            for f in findings:
                arr.append({"column": f.column, "endColumn": f.endColumn, "line": f.line, "message": f.message})
            print(json.dumps({"file": path, "results": arr}, separators=(",", ":")))
        elif not args.quiet:
            if errors:
                for e in errors:
                    print(f"Error parsing file {path}: {e}")
            elif findings:
                try:
                    with open(path, "r", encoding="utf-8") as f:
                        text = f.read()
                except OSError:
                    text = ""
                print(human(path, text, findings, "NO_COLOR" not in os.environ))
        if args.edit and findings:
            edit_file(path, findings)
    return 1 if args.fail and any_findings else 0


if __name__ == "__main__":
    raise SystemExit(main(sys.argv))
