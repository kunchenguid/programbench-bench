#!/usr/bin/env python3
import base64
import gzip
import http.client
import json
import mimetypes
import os
import re
import ssl
import sys
import urllib.parse
import urllib.request

VERSION = "0.25.3"
UA = f"xh/{VERSION}"

HELP = """xh is a friendly and fast tool for sending HTTP requests

Usage: executable [OPTIONS] <[METHOD] URL> [REQUEST_ITEM]...

Arguments:
  <[METHOD] URL>     The request URL, preceded by an optional HTTP method
  [REQUEST_ITEM]...  Optional key-value pairs to be included in the request.

Options:
  -j, --json
          (default) Serialize data items from the command line as a JSON object
  -f, --form
          Serialize data items from the command line as form fields
      --multipart
          Like --form, but force a multipart/form-data request even without files
      --raw <RAW>
          Pass raw request data without extra processing
      --pretty <STYLE>
          Controls output processing [possible values: all, colors, format, none]
      --format-options <FORMAT_OPTIONS>
          Set output formatting options
  -s, --style <THEME>
          Output coloring style [possible values: auto, solarized, monokai, fruity]
      --response-charset <ENCODING>
          Override the response encoding for terminal display purposes
      --response-mime <MIME_TYPE>
          Override the response mime type for coloring and formatting for the terminal
  -p, --print <FORMAT>
          String specifying what the output should contain
  -h, --headers
          Print only the response headers. Shortcut for --print=h
  -b, --body
          Print only the response body. Shortcut for --print=b
  -m, --meta
          Print only the response metadata. Shortcut for --print=m
  -v, --verbose...
          Print the whole request as well as the response
      --debug
          Print full error stack traces and debug log messages
      --all
          Show any intermediary requests/responses while following redirects with --follow
  -P, --history-print <FORMAT>
          The same as --print but applies only to intermediary requests/responses
  -q, --quiet...
          Do not print to stdout or stderr
  -S, --stream
          Always stream the response body
  -x, --compress...
          Content compressed (encoded) with Deflate algorithm
  -o, --output <FILE>
          Save output to FILE instead of stdout
  -d, --download
          Download the body to a file instead of printing it
  -c, --continue
          Resume an interrupted download. Requires --download and --output
      --session <FILE>
          Create, or reuse and update a session
      --session-read-only <FILE>
          Create or read a session without updating it from the request/response exchange
  -A, --auth-type <AUTH_TYPE>
          Specify the auth mechanism [possible values: basic, bearer, digest]
  -a, --auth <USER[:PASS] | TOKEN>
          Authenticate as USER with PASS (-A basic|digest) or with TOKEN (-A bearer)
      --ignore-netrc
          Do not use credentials from .netrc
      --offline
          Construct HTTP requests without sending them anywhere
      --check-status
          (default) Exit with an error status code if the server replies with an error
  -F, --follow
          Do follow redirects
      --max-redirects <NUM>
          Number of redirects to follow. Only respected if --follow is used
      --timeout <SEC>
          Connection timeout of the request
      --proxy <PROTOCOL:URL>
          Use a proxy for a protocol. For example: --proxy https:http://proxy.host:8080
      --verify <VERIFY>
          If "no", skip SSL verification. If a file path, use it as a CA bundle
      --cert <FILE>
          Use a client side certificate for SSL
      --cert-key <FILE>
          A private key file to use with --cert
      --ssl <VERSION>
          Force a particular TLS version [possible values: auto, tls1, tls1.1, tls1.2, tls1.3]
      --https
          Make HTTPS requests if not specified in the URL
      --http-version <VERSION>
          HTTP version to use [possible values: 1.0, 1.1, 2, 2-prior-knowledge, 3-prior-knowledge]
      --resolve <HOST:ADDRESS>
          Override DNS resolution for specific domain to a custom IP
      --interface <NAME>
          Bind to a network interface or local IP address
  -4, --ipv4
          Resolve hostname to ipv4 addresses only
  -6, --ipv6
          Resolve hostname to ipv6 addresses only
      --unix-socket <FILE>
          Connect using a Unix domain socket
  -I, --ignore-stdin
          Do not attempt to read stdin
      --curl
          Print a translation to a curl command
      --curl-long
          Use the long versions of curl's flags
      --generate <KIND>
          Generate shell completions or man pages
      --help
          Print help
  -V, --version
          Print version

Each option can be reset with a --no-OPTION argument.

Run "xh help" for more complete documentation.
"""

LONG_HELP = """xh is a friendly and fast tool for sending HTTP requests.

It reimplements as much as possible of HTTPie's excellent design, with a focus on improved
performance.

""" + HELP


class Opts:
    def __init__(self):
        self.json_mode = True
        self.form = False
        self.multipart = False
        self.raw = None
        self.offline = False
        self.curl = False
        self.curl_long = False
        self.ignore_stdin = False
        self.print_fmt = None
        self.output = None
        self.download = False
        self.follow = False
        self.check_status = True
        self.auth = None
        self.auth_type = "basic"
        self.headers_only = False
        self.body_only = False
        self.meta = False
        self.verbose = 0
        self.quiet = 0
        self.https = False
        self.timeout = 0
        self.verify = "yes"
        self.compress = 0
        self.extra = {}


def die(msg, code=1, usage=False):
    sys.stderr.write(msg + "\n")
    if usage:
        sys.stderr.write("\nFor more information, try '--help'.\n")
    raise SystemExit(code)


def parse_argv(argv):
    o = Opts()
    pos = []
    i = 0
    takes = {
        "--raw", "--pretty", "--format-options", "--style", "-s", "--response-charset",
        "--response-mime", "--print", "-p", "--history-print", "-P", "--output", "-o",
        "--session", "--session-read-only", "--auth-type", "-A", "--auth", "-a",
        "--max-redirects", "--timeout", "--proxy", "--verify", "--cert", "--cert-key",
        "--ssl", "--http-version", "--resolve", "--interface", "--unix-socket", "--generate",
    }
    while i < len(argv):
        a = argv[i]
        if a == "--":
            pos.extend(argv[i+1:])
            break
        if not a.startswith("-") or a == "-":
            pos.append(a); i += 1; continue
        name, val = (a.split("=", 1) + [None])[:2] if a.startswith("--") and "=" in a else (a, None)
        def need():
            nonlocal i, val
            if val is not None:
                return val
            i += 1
            if i >= len(argv):
                die(f"error: a value is required for '{name}' but none was supplied", 2, True)
            return argv[i]
        if name in ("--help",):
            print(HELP); raise SystemExit(0)
        if name == "-V" or name == "--version":
            print(f"xh {VERSION}\n-native-tls +rustls"); raise SystemExit(0)
        if name in ("-j", "--json", "--no-form", "--no-multipart"):
            o.json_mode = True; o.form = o.multipart = False
        elif name in ("-f", "--form"):
            o.form = True; o.json_mode = o.multipart = False
        elif name == "--multipart":
            o.multipart = True; o.form = True; o.json_mode = False
        elif name == "--raw":
            o.raw = need()
        elif name == "--pretty":
            v = need()
            if v not in ("all", "colors", "format", "none"):
                die(f"error: invalid value '{v}' for '--pretty <STYLE>'\n  [possible values: all, colors, format, none]", 2, True)
        elif name in ("--style", "-s"):
            v = need()
            if v not in ("auto", "solarized", "monokai", "fruity"):
                die(f"error: invalid value '{v}' for '--style <THEME>'\n  [possible values: auto, solarized, monokai, fruity]", 2, True)
        elif name == "--offline":
            o.offline = True
        elif name == "--curl":
            o.curl = True
        elif name == "--curl-long":
            o.curl = True; o.curl_long = True
        elif name in ("-I", "--ignore-stdin"):
            o.ignore_stdin = True
        elif name in ("-h", "--headers"):
            o.print_fmt = "h"
        elif name in ("-b", "--body"):
            o.print_fmt = "b"
        elif name in ("-m", "--meta"):
            o.print_fmt = "m"
        elif name in ("-p", "--print"):
            o.print_fmt = need()
        elif name in ("-v", "--verbose"):
            o.verbose += 1
        elif re.fullmatch(r"-v+", name):
            o.verbose += len(name) - 1
        elif name in ("-q", "--quiet"):
            o.quiet += 1
        elif re.fullmatch(r"-q+", name):
            o.quiet += len(name) - 1
        elif name in ("-o", "--output"):
            o.output = need()
        elif name in ("-d", "--download"):
            o.download = True
        elif name in ("-F", "--follow"):
            o.follow = True
        elif name == "--check-status":
            o.check_status = True
        elif name == "--no-check-status":
            o.check_status = False
        elif name in ("-a", "--auth"):
            o.auth = need()
        elif name in ("-A", "--auth-type"):
            o.auth_type = need()
        elif name == "--https":
            o.https = True
        elif name == "--timeout":
            try: o.timeout = float(need())
            except ValueError: o.timeout = 0
        elif name == "--verify":
            o.verify = need()
        elif name in ("-x", "--compress"):
            o.compress += 1
        elif re.fullmatch(r"-x+", name):
            o.compress += len(name) - 1
        elif name == "--generate":
            kind = need()
            if kind == "man":
                print('.TH XH 1 2026-05-28 0.25.3 "User Commands"\n.SH NAME\nxh \\- Friendly and fast tool for sending HTTP requests')
            elif kind.startswith("complete-"):
                print("# shell completions for xh")
            else:
                die(f"error: invalid value '{kind}' for '--generate <KIND>'\n  [possible values: complete-bash, complete-elvish, complete-fish, complete-nushell, complete-powershell, complete-zsh, man]", 2, True)
            raise SystemExit(0)
        elif name in takes:
            o.extra[name] = need()
        elif name.startswith("--no-"):
            pass
        elif name in ("-4", "--ipv4", "-6", "--ipv6", "-S", "--stream", "--debug", "--all", "-c", "--continue", "--ignore-netrc"):
            pass
        else:
            die(f"error: unexpected argument '{a}' found", 2, True)
        i += 1
    return o, pos


def split_method_url(pos):
    if not pos:
        die("error: the following required arguments were not provided:\n  <[METHOD] URL>\n\nUsage: executable <[METHOD] URL> [REQUEST_ITEM]...", 2, True)
    methods = {"GET","POST","PUT","PATCH","DELETE","HEAD","OPTIONS","TRACE","CONNECT"}
    if pos[0].upper() in methods:
        if len(pos) < 2:
            die("error: Missing <URL>\n\nUsage: executable [OPTIONS] <[METHOD] URL> [REQUEST_ITEM]...", 2, True)
        return pos[0].upper(), pos[1], pos[2:], True
    return None, pos[0], pos[1:], False


def normalize_url(s, https_default=False):
    scheme = "https" if https_default else "http"
    if s.startswith("://"):
        s = s[3:]
    elif s.startswith(":/"):
        s = "localhost" + s[1:]
    elif s.startswith(":"):
        s = "localhost" + s
    if "://" not in s:
        s = scheme + "://" + s
    p = urllib.parse.urlsplit(s)
    path = p.path or "/"
    return urllib.parse.urlunsplit((p.scheme or scheme, p.netloc, path, p.query, p.fragment))


def title_header(k):
    return "-".join(part[:1].upper() + part[1:].lower() for part in k.split("-"))


def find_sep(item):
    esc = False
    for i, ch in enumerate(item):
        if esc:
            esc = False; continue
        if ch == "\\":
            esc = True; continue
        if item.startswith(":=", i): return i, ":="
        if item.startswith("==", i): return i, "=="
        if ch in "=:@;" and i > 0: return i, ch
    return None, None


def unesc(s):
    out = ""; esc = False
    for ch in s:
        if esc:
            out += ch; esc = False
        elif ch == "\\":
            esc = True
        else:
            out += ch
    if esc: out += "\\"
    return out


def read_text_file(path):
    with open(path, "rb") as f:
        return f.read().decode("utf-8", "replace")


def parse_items(items, o):
    body_fields, query, headers, files = {}, [], [], []
    body_file = None
    for item in items:
        if item.startswith("@") and len(item) > 1:
            body_file = item[1:]; continue
        idx, sep = find_sep(item)
        if sep is None:
            die(f'error: Invalid value for \'[REQUEST_ITEM]...\': "{item}"', 2, True)
        key = unesc(item[:idx])
        val = item[idx+len(sep):]
        if sep == "==":
            query.append((key, val))
        elif sep == ":":
            if val.startswith("@"):
                val = read_text_file(val[1:])
            headers.append((title_header(key), None if val == "" else val))
        elif sep == ";":
            headers.append((title_header(key), ""))
        elif sep == "@":
            files.append((key, val))
        elif sep == "=":
            if val.startswith("@"):
                val = read_text_file(val[1:])
            body_fields[key] = val
        elif sep == ":=":
            if o.form:
                die("executable: error: JSON values are not supported in Form fields")
            try:
                body_fields[key] = json.loads(val)
            except Exception:
                die(f"executable: error: '{val}' is not a valid JSON value")
    return body_fields, query, headers, files, body_file


def build_body(o, fields, files, body_file, stdin_body):
    ctype = None; body = None
    if o.raw is not None:
        body = o.raw.encode()
        ctype = "application/json"
    elif body_file:
        body = open(body_file, "rb").read()
        ctype = mimetypes.guess_type(body_file)[0] or "text/plain"
    elif fields or files:
        if o.form or o.multipart:
            if files or o.multipart:
                boundary = "xhboundary"
                parts = []
                for k, v in fields.items():
                    parts.append(f"--{boundary}\r\nContent-Disposition: form-data; name=\"{k}\"\r\n\r\n{v}\r\n".encode())
                for k, spec in files:
                    path = spec.split(";", 1)[0]
                    filename = os.path.basename(path)
                    data = open(path, "rb").read()
                    parts.append(f"--{boundary}\r\nContent-Disposition: form-data; name=\"{k}\"; filename=\"{filename}\"\r\n\r\n".encode()+data+b"\r\n")
                parts.append(f"--{boundary}--\r\n".encode())
                body = b"".join(parts); ctype = f"multipart/form-data; boundary={boundary}"
            else:
                body = urllib.parse.urlencode({k: str(v) for k, v in fields.items()}).encode()
                ctype = "application/x-www-form-urlencoded"
        else:
            body = json.dumps(fields, separators=(",", ":")).encode()
            ctype = "application/json"
    elif stdin_body is not None:
        body = stdin_body
        ctype = "application/json" if body == b"" else "application/json"
    return body, ctype


def request_parts(url, query):
    p = urllib.parse.urlsplit(url)
    q = urllib.parse.parse_qsl(p.query, keep_blank_values=True) + query
    path = p.path or "/"
    if q:
        path += "?" + urllib.parse.urlencode(q)
    host = p.netloc
    return p, path, host


def default_accept(has_body):
    return "application/json, */*;q=0.5" if has_body else "*/*"


def build_headers(o, host, ctype, body, custom):
    hdr = [
        ("Accept-Encoding", "gzip, deflate, br, zstd"),
        ("User-Agent", UA),
        ("Connection", "keep-alive"),
    ]
    if ctype:
        hdr.append(("Accept", "application/json, */*;q=0.5" if ctype == "application/json" else "*/*"))
        hdr.append(("Content-Type", ctype))
    else:
        hdr.append(("Accept", "*/*"))
    unset = {k.lower() for k, v in custom if v is None}
    hdr = [(k, v) for k, v in hdr if k.lower() not in unset]
    hdr.extend((k, v) for k, v in custom if v is not None)
    if body is not None and ctype:
        hdr.append(("Content-Length", str(len(body))))
    hdr.append(("Host", host))
    if o.auth and o.auth_type == "basic":
        token = base64.b64encode(o.auth.encode()).decode()
        hdr.append(("Authorization", "Basic " + token))
    elif o.auth and o.auth_type == "bearer":
        hdr.append(("Authorization", "Bearer " + o.auth))
    return hdr


def offline_print(method, path, headers, body):
    sys.stdout.write(f"{method} {path} HTTP/1.1\n")
    for k, v in headers:
        sys.stdout.write(f"{k}: {v}\n")
    sys.stdout.write("\n")
    if body is not None:
        sys.stdout.flush()
        sys.stdout.buffer.write(body)
        sys.stdout.buffer.flush()
        sys.stdout.write("\n")


def shquote(s):
    if re.fullmatch(r"[A-Za-z0-9_./:=@%+,-]+", s):
        return s
    return "'" + s.replace("'", "'\\''") + "'"


def curl_print(o, method, url, body, ctype, custom, explicit_method):
    long = o.curl_long
    args = ["curl"]
    if explicit_method and method != "GET":
        args += ["--request" if long else "-X", method]
    args.append(shquote(url))
    for k, v in custom:
        if v is None:
            continue
        args += ["--header" if long else "-H", shquote(f"{k.lower()}: {v}")]
    if ctype and not o.form:
        args += ["--header" if long else "-H", shquote(f"content-type: {ctype}")]
        args += ["--header" if long else "-H", shquote("accept: application/json, */*;q=0.5")]
    if o.auth:
        if o.auth_type == "bearer":
            args += ["--oauth2-bearer", shquote(o.auth)]
        else:
            args += ["--basic", "-u" if not long else "--user", shquote(o.auth)]
    if body:
        if o.form and not o.multipart:
            for pair in body.decode().split("&"):
                args += ["--data-urlencode" if long else "--data-urlencode", shquote(urllib.parse.unquote_plus(pair))]
        else:
            args += ["--data" if long else "-d", shquote(body.decode("utf-8", "replace"))]
    print(" ".join(args))


class NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        return None


def perform(o, method, url, headers, body):
    req_headers = {k: v for k, v in headers if k.lower() not in ("host", "connection")}
    if "Accept-Encoding" in req_headers:
        req_headers["Accept-Encoding"] = "gzip, deflate"
    handlers = []
    if not o.follow:
        handlers.append(NoRedirect)
    if url.startswith("https") and o.verify in ("no", "false"):
        ctx = ssl._create_unverified_context()
        handlers.append(urllib.request.HTTPSHandler(context=ctx))
    opener = urllib.request.build_opener(*handlers)
    req = urllib.request.Request(url, data=body if method not in ("GET","HEAD") else None, headers=req_headers, method=method)
    try:
        resp = opener.open(req, timeout=o.timeout or None)
        data = resp.read()
        code = resp.getcode(); reason = getattr(resp, "reason", "OK")
        hdrs = list(resp.headers.items())
    except urllib.error.HTTPError as e:
        data = e.read()
        code = e.code; reason = e.reason; hdrs = list(e.headers.items())
    except Exception as e:
        die(f"executable: error: {e}")
    if any(k.lower() == "content-encoding" and v.lower() == "gzip" for k, v in hdrs):
        try: data = gzip.decompress(data)
        except Exception: pass
    return code, reason, hdrs, data


def format_response(o, code, reason, hdrs, data):
    fmt = o.print_fmt
    if o.verbose:
        fmt = "HhBb"
    if fmt is None:
        fmt = "b"
    out = bytearray()
    if "h" in fmt:
        out.extend(f"HTTP/1.1 {code} {reason}\n".encode())
        for k, v in hdrs:
            out.extend(f"{k}: {v}\n".encode())
        out.extend(b"\n")
    if "b" in fmt or "m" in fmt:
        out.extend(data)
    return bytes(out)


def main(argv):
    if len(argv) == 1 and argv[0] == "help":
        print(LONG_HELP); return 0
    o, pos = parse_argv(argv)
    explicit_method, raw_url, items, method_given = split_method_url(pos)
    url = normalize_url(raw_url, o.https or os.path.basename(sys.argv[0]) in ("xhs", "https", "xhttps"))
    fields, query, custom, files, body_file = parse_items(items, o)
    stdin_body = None
    if not o.ignore_stdin and not o.curl and not sys.stdin.isatty():
        stdin_body = sys.stdin.buffer.read()
    if stdin_body is not None and (fields or files):
        die("executable: error: Request body (from stdin) and request data (key=value) cannot be mixed. Pass --ignore-stdin to ignore standard input.")
    if stdin_body is not None and o.raw is not None:
        die("executable: error: Request body from stdin and --raw cannot be mixed. Pass --ignore-stdin to ignore standard input.")
    body, ctype = build_body(o, fields, files, body_file, stdin_body)
    method = explicit_method or ("POST" if (fields or files or body_file or stdin_body is not None or o.raw is not None) else "GET")
    p, path, host = request_parts(url, query)
    url = urllib.parse.urlunsplit((p.scheme, p.netloc, path, "", ""))
    headers = build_headers(o, host, ctype, body, custom)
    if o.curl:
        curl_print(o, method, url, body, ctype, custom, method_given)
        return 0
    if o.offline:
        offline_print(method, path, headers, body)
        return 0
    code, reason, rh, data = perform(o, method, url, headers, body)
    if o.check_status and code >= 300:
        if o.quiet < 1:
            sys.stderr.write(f"executable: warning: HTTP {code} {reason}\n")
        status = 3 if code < 400 else 4 if code < 500 else 5
    else:
        status = 0
    out = format_response(o, code, reason, rh, data)
    if o.output or o.download:
        fn = o.output
        if not fn:
            fn = os.path.basename(urllib.parse.urlsplit(url).path) or "index.html"
        with open(fn, "wb") as f: f.write(out if not o.download else data)
    elif o.quiet < 1:
        sys.stdout.buffer.write(out)
    return status


if __name__ == "__main__":
    try:
        raise SystemExit(main(sys.argv[1:]))
    except BrokenPipeError:
        raise SystemExit(0)
