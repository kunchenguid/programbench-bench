#!/usr/bin/env python3
import sys, re, json, hashlib, math, time, os, html

VERSION = """PHP 8.6.0-dev (cli) (built: Apr 17 2026 20:00:58) (NTS)
Copyright (c) The PHP Group
Zend Engine v4.6.0-dev, Copyright (c) Zend Technologies
    with Zend OPcache v8.6.0-dev, Copyright (c), by Zend Technologies"""

HELP = """Usage: executable [options] [-f] <file> [--] [args...]
   executable [options] -r <code> [--] [args...]
   executable [options] [-B <begin_code>] -R <code> [-E <end_code>] [--] [args...]
   executable [options] [-B <begin_code>] -F <file> [-E <end_code>] [--] [args...]
   executable [options] -S <addr>:<port> [-t docroot] [router]
   executable [options] -- [args...]
   executable [options] -a

  -a               Run as interactive shell (requires readline extension)
  -c <path>|<file> Look for php.ini file in this directory
  -n               No configuration (ini) files will be used
  -d foo[=bar]     Define INI entry foo with value 'bar'
  -e               Generate extended information for debugger/profiler
  -f <file>        Parse and execute <file>.
  -h               This help
  -i               PHP information
  -l               Syntax check only (lint)
  -m               Show compiled in modules
  -r <code>        Run PHP <code> without using script tags <?..?>
  -B <begin_code>  Run PHP <begin_code> before processing input lines
  -R <code>        Run PHP <code> for every input line
  -F <file>        Parse and execute <file> for every input line
  -E <end_code>    Run PHP <end_code> after processing all input lines
  -H               Hide any passed arguments from external tools.
  -S <addr>:<port> Run with built-in web server.
  -t <docroot>     Specify document root <docroot> for built-in web server.
  -s               Output HTML syntax highlighted source.
  -v               Version number
  -w               Output source with stripped comments and whitespace.

  args...          Arguments passed to script. Use -- args when first argument
                   starts with - or script is read from stdin

  --ini            Show configuration file names
  --ini=diff       Show INI entries that differ from the built-in default

  --rf <name>      Show information about function <name>.
  --rc <name>      Show information about class <name>.
  --re <name>      Show information about extension <name>.
  --rz <name>      Show information about Zend extension <name>.
  --ri <name>      Show configuration for extension <name>.

  --repeat <count> Repeat script execution <count> times.
                   For internal purposes only.
"""

MODULES = """[PHP Modules]
Core
date
hash
json
lexbor
pcre
random
Reflection
SPL
standard
uri
Zend OPcache

[Zend Modules]
Zend OPcache
"""

class PhpError(Exception): pass
class ReturnSignal(Exception):
    def __init__(self, value): self.value = value

def php_bool(v):
    if v is None or v is False: return False
    if isinstance(v, (int, float)): return v != 0
    if isinstance(v, str): return v not in ("", "0")
    if isinstance(v, dict): return len(v) != 0
    return True

def php_str(v):
    if v is None: return ""
    if v is True: return "1"
    if v is False: return ""
    if isinstance(v, float):
        if v.is_integer(): return str(int(v))
    if isinstance(v, dict): return "Array"
    return str(v)

def php_num(v):
    if isinstance(v, bool): return 1 if v else 0
    if v is None: return 0
    if isinstance(v, (int, float)): return v
    m = re.match(r'^[ \t]*([+-]?(?:\d+(?:\.\d*)?|\.\d+))', str(v))
    if not m: return 0
    s = m.group(1)
    return float(s) if "." in s else int(s)

def arr_values(a):
    if isinstance(a, dict): return list(a.values())
    if isinstance(a, list): return a
    return []

def dump(v, depth=0):
    ind = "  " * depth
    if v is None: return "NULL\n"
    if isinstance(v, bool): return "bool(%s)\n" % ("true" if v else "false")
    if isinstance(v, int): return f"int({v})\n"
    if isinstance(v, float): return f"float({v})\n"
    if isinstance(v, str): return f"string({len(v)}) \"{v}\"\n"
    if isinstance(v, dict):
        out = f"array({len(v)}) {{\n"
        for k, val in v.items():
            kk = f'"{k}"' if isinstance(k, str) else str(k)
            out += ind + f"  [{kk}]=>\n" + ind + "  " + dump(val, depth+1)
        return out + ind + "}\n"
    return f"object({type(v).__name__})\n"

TOKEN_RE = re.compile(r'''
    \s+|//[^\n]*|\#[^\n]*|/\*.*?\*/|
    \$[A-Za-z_][A-Za-z0-9_]*|
    "(?:\\.|[^"\\])*"|'(?:\\.|[^'\\])*'|
    \d+\.\d+|\d+|
    ===|!==|==|!=|<=|>=|\+\+|--|\+=|-=|\.=|&&|\|\||=>|::|->|
    [A-Za-z_][A-Za-z0-9_]*|
    .
''', re.S | re.X)

def toks(s):
    r=[]
    for m in TOKEN_RE.finditer(s):
        t=m.group(0)
        if not t or t.isspace() or t.startswith("//") or t.startswith("#") or t.startswith("/*"): continue
        r.append(t)
    return r

class Parser:
    def __init__(self, tokens, interp): self.t=tokens; self.i=0; self.p=interp
    def peek(self): return self.t[self.i] if self.i < len(self.t) else None
    def eat(self, x=None):
        y=self.peek()
        if x is not None and y != x: raise PhpError(f"expected {x}")
        self.i += 1
        return y
    def expr(self): return self.orx()
    def orx(self):
        v=self.andx()
        while self.peek()=="||": self.eat(); v=php_bool(v) or php_bool(self.andx())
        return v
    def andx(self):
        v=self.cmp()
        while self.peek()=="&&": self.eat(); v=php_bool(v) and php_bool(self.cmp())
        return v
    def cmp(self):
        v=self.concat()
        while self.peek() in ("==","!=","===","!==","<",">","<=",">="):
            op=self.eat(); b=self.concat()
            if op in ("==","==="): v = v == b
            elif op in ("!=","!=="): v = v != b
            elif op=="<": v = php_num(v) < php_num(b)
            elif op==">": v = php_num(v) > php_num(b)
            elif op=="<=": v = php_num(v) <= php_num(b)
            else: v = php_num(v) >= php_num(b)
        return v
    def concat(self):
        v=self.add()
        while self.peek()==".":
            self.eat("."); v=php_str(v)+php_str(self.add())
        return v
    def add(self):
        v=self.mul()
        while self.peek() in ("+","-"):
            op=self.eat(); b=self.mul()
            v = php_num(v)+php_num(b) if op=="+" else php_num(v)-php_num(b)
        return v
    def mul(self):
        v=self.unary()
        while self.peek() in ("*","/","%"):
            op=self.eat(); b=self.unary()
            if op=="*": v=php_num(v)*php_num(b)
            elif op=="/": v=php_num(v)/php_num(b)
            else: v=php_num(v)%php_num(b)
        return v
    def unary(self):
        if self.peek()=="!": self.eat(); return not php_bool(self.unary())
        if self.peek()=="-": self.eat(); return -php_num(self.unary())
        if self.peek()=="@": self.eat(); return self.unary()
        return self.postfix()
    def postfix(self):
        v, ref = self.primary()
        while self.peek() in ("[","->"):
            if self.peek()=="[":
                self.eat("[")
                key = None if self.peek()=="]" else self.expr()
                self.eat("]")
                if isinstance(v, dict): v = v.get(key, None)
                elif isinstance(v, (list, tuple)) and isinstance(key, int) and 0 <= key < len(v): v=v[key]
                else: v=None
            else:
                self.eat("->"); name=self.eat()
                if isinstance(v, dict): v=v.get(name, None)
                else: v=None
        return v
    def primary(self):
        x=self.peek()
        if x is None: return None, None
        if x=="(":
            self.eat("("); v=self.expr(); self.eat(")"); return v, None
        if x=="[":
            return self.array_lit("]")
        if x.lower()=="array":
            self.eat(); self.eat("("); return self.array_lit(")")
        if re.match(r'^\d', x):
            self.eat(); return (float(x) if "." in x else int(x)), None
        if x[0] in "\"'":
            self.eat(); return self.p.unescape(x), None
        if x.startswith("$"):
            self.eat(); name=x[1:]; return self.p.env.get(name, None), name
        if re.match(r'^[A-Za-z_]', x):
            name=self.eat()
            low=name.lower()
            if self.peek()=="(":
                self.eat("("); args=[]
                if self.peek()!=")":
                    while True:
                        args.append(self.expr())
                        if self.peek()!="," : break
                        self.eat(",")
                self.eat(")")
                return self.p.call(name, args), None
            if low=="true": return True, None
            if low=="false": return False, None
            if low=="null": return None, None
            if name=="PHP_VERSION": return "8.6.0-dev", None
            if name=="PHP_EOL": return "\n", None
            if name in self.p.constants: return self.p.constants[name], None
            return name, None
        self.eat(); return x, None
    def array_lit(self, end):
        if end=="]": self.eat("[")
        d={}; idx=0
        if self.peek()!=end:
            while True:
                first=self.expr()
                if self.peek()=="=>":
                    self.eat("=>"); val=self.expr(); d[first]=val
                else:
                    d[idx]=first; idx+=1
                if self.peek()!="," : break
                self.eat(",")
                if self.peek()==end: break
        self.eat(end); return d, None

class MiniPHP:
    def __init__(self, filename="Command line code"):
        self.env={"argc":0,"argv":{}}
        self.filename=filename
        self.functions={}
        self.constants={}
    def unescape(self, s):
        q=s[0]; body=s[1:-1]
        if q=="'": return body.replace("\\'", "'").replace("\\\\", "\\")
        text = bytes(body, "utf-8").decode("unicode_escape")
        return re.sub(r'\$([A-Za-z_]\w*)', lambda m: php_str(self.env.get(m.group(1), "")), text)
    def eval_expr(self, s):
        return Parser(toks(s), self).expr()
    def call(self, name, args):
        n=name.lower()
        if n in ("strlen",): return len(php_str(args[0] if args else ""))
        if n=="trim": return php_str(args[0] if args else "").strip()
        if n=="rtrim": return php_str(args[0] if args else "").rstrip()
        if n=="ltrim": return php_str(args[0] if args else "").lstrip()
        if n=="strtoupper": return php_str(args[0]).upper()
        if n=="strtolower": return php_str(args[0]).lower()
        if n=="ucfirst":
            s=php_str(args[0]); return s[:1].upper()+s[1:]
        if n=="substr":
            s=php_str(args[0]); start=int(php_num(args[1])); return s[start:] if len(args)<3 else s[start:start+int(php_num(args[2]))]
        if n=="str_replace": return php_str(args[2]).replace(php_str(args[0]), php_str(args[1]))
        if n=="strpos":
            pos=php_str(args[0]).find(php_str(args[1])); return False if pos<0 else pos
        if n=="explode": return {i:v for i,v in enumerate(php_str(args[1]).split(php_str(args[0])))}
        if n=="implode" or n=="join":
            sep = php_str(args[0]); vals = arr_values(args[1]) if len(args)>1 else arr_values(args[0]); 
            if len(args)==1: sep=""
            return sep.join(php_str(x) for x in vals)
        if n=="count": return len(args[0]) if isinstance(args[0], dict) else 0
        if n=="array_sum": return sum(php_num(x) for x in arr_values(args[0]))
        if n=="array_keys": return {i:k for i,k in enumerate(args[0].keys())} if isinstance(args[0], dict) else {}
        if n=="array_values": return {i:v for i,v in enumerate(arr_values(args[0]))}
        if n=="array_key_exists": return isinstance(args[1], dict) and args[0] in args[1]
        if n=="in_array": return any(x == args[0] for x in arr_values(args[1] if len(args)>1 else {}))
        if n=="array_merge":
            out={}; idx=0
            for a in args:
                if isinstance(a, dict):
                    for k,v in a.items():
                        if isinstance(k, int): out[idx]=v; idx+=1
                        else: out[k]=v
            return out
        if n=="range":
            a=int(php_num(args[0])); b=int(php_num(args[1])); step=1 if b>=a else -1
            return {i:v for i,v in enumerate(range(a,b+step,step))}
        if n=="json_encode":
            def conv(v):
                if isinstance(v, dict):
                    keys=list(v.keys())
                    if keys==list(range(len(keys))): return [conv(v[k]) for k in keys]
                    return {str(k):conv(val) for k,val in v.items()}
                return v
            return json.dumps(conv(args[0]), separators=(",",":"))
        if n=="json_decode":
            try:
                v=json.loads(php_str(args[0]))
                def conv(x):
                    if isinstance(x, list): return {i:conv(v) for i,v in enumerate(x)}
                    if isinstance(x, dict): return {k:conv(v) for k,v in x.items()}
                    return x
                return conv(v)
            except Exception: return None
        if n=="md5": return hashlib.md5(php_str(args[0]).encode()).hexdigest()
        if n=="sha1": return hashlib.sha1(php_str(args[0]).encode()).hexdigest()
        if n=="abs": return abs(php_num(args[0]))
        if n=="min": return min(args)
        if n=="max": return max(args)
        if n=="round": return round(php_num(args[0]), int(php_num(args[1])) if len(args)>1 else 0)
        if n=="sqrt": return math.sqrt(php_num(args[0]))
        if n=="date": return time.strftime(php_str(args[0]), time.localtime(int(php_num(args[1])) if len(args)>1 else time.time()))
        if n=="var_dump":
            for a in args: sys.stdout.write(dump(a))
            return None
        if n=="print_r":
            s=self.print_r(args[0] if args else None)
            if len(args)>1 and php_bool(args[1]): return s
            sys.stdout.write(s); return True
        if n=="printf":
            fmt=php_str(args[0] if args else "")
            try: s=fmt % tuple(args[1:])
            except Exception: s=fmt
            sys.stdout.write(s); return len(s)
        if n=="sprintf":
            fmt=php_str(args[0] if args else "")
            try: return fmt % tuple(args[1:])
            except Exception: return fmt
        if n=="isset": return all(a is not None for a in args)
        if n=="empty": return not php_bool(args[0]) if args else True
        if n=="file_exists": return os.path.exists(php_str(args[0]))
        if n=="is_file": return os.path.isfile(php_str(args[0]))
        if n=="is_dir": return os.path.isdir(php_str(args[0]))
        if n=="function_exists":
            return php_str(args[0]).lower() in {"strlen","trim","json_encode","json_decode","var_dump","print_r","count","md5","sha1"} or php_str(args[0]).lower() in self.functions
        if n=="class_exists": return php_str(args[0]) in {"stdClass","Exception","DateTime","ArrayObject"}
        if n=="preg_match":
            pat=php_str(args[0]); subj=php_str(args[1])
            if len(pat)>=2 and not pat[0].isalnum():
                end=pat.rfind(pat[0]); pat=pat[1:end] if end>0 else pat
            return 1 if re.search(pat, subj) else 0
        if n=="intval": return int(php_num(args[0])) if args else 0
        if n=="strval": return php_str(args[0] if args else "")
        if n=="define":
            if len(args)>=2: self.constants[php_str(args[0])] = args[1]
            return True
        if n in self.functions:
            params, block = self.functions[n]
            old = self.env.copy()
            for idx, pname in enumerate(params):
                self.env[pname] = args[idx] if idx < len(args) else None
            try:
                self.exec(block)
                ret = None
            except ReturnSignal as r:
                ret = r.value
            keep_funcs, keep_consts = self.functions, self.constants
            self.env = old
            self.functions, self.constants = keep_funcs, keep_consts
            return ret
        raise PhpError(f"Call to undefined function {name}()")
    def print_r(self, v, depth=0):
        if not isinstance(v, dict): return php_str(v)
        ind="    "*depth; out="Array\n"+ind+"(\n"
        for k,val in v.items():
            out += ind+f"    [{k}] => "
            out += self.print_r(val, depth+1) if isinstance(val, dict) else php_str(val)
            out += "\n"
        return out+ind+")\n"
    def split_commas(self, s):
        return split_top(s, ",")
    def exec(self, code):
        i=0; n=len(code)
        while i<n:
            while i<n and code[i].isspace(): i+=1
            if i>=n: break
            if code.startswith("<?", i):
                j=code.find("?>", i)
                start = i + (5 if code.startswith("<?php", i) else 2)
                inner=code[start:(j if j>=0 else n)]
                self.exec(inner); i = n if j<0 else j+2; continue
            if code.startswith("if", i) and word_boundary(code, i+2):
                cond, after = read_paren(code, code.find("(", i)); block, afterb = read_block_or_stmt(code, after)
                k=skip_ws(code, afterb)
                has_else = code.startswith("else", k)
                if php_bool(self.eval_expr(cond)):
                    self.exec(block)
                    if has_else:
                        _eb, ea = read_block_or_stmt(code, k+4); i=ea; continue
                elif has_else:
                    eb, ea = read_block_or_stmt(code, k+4); self.exec(eb); i=ea; continue
                i=afterb; continue
            if code.startswith("for", i) and word_boundary(code, i+3):
                inside, after = read_paren(code, code.find("(", i)); parts=split_top(inside, ";")
                block, i = read_block_or_stmt(code, after)
                if parts: self.simple(parts[0])
                guard=0
                while len(parts)<2 or php_bool(self.eval_expr(parts[1] or "true")):
                    self.exec(block); guard+=1
                    if len(parts)>2: self.simple(parts[2])
                    if guard>100000: break
                continue
            if code.startswith("while", i) and word_boundary(code, i+5):
                cond, after = read_paren(code, code.find("(", i)); block, i = read_block_or_stmt(code, after)
                guard=0
                while php_bool(self.eval_expr(cond)):
                    self.exec(block); guard+=1
                    if guard>100000: break
                continue
            if code.startswith("foreach", i) and word_boundary(code, i+7):
                inside, after = read_paren(code, code.find("(", i)); block, i = read_block_or_stmt(code, after)
                left,right=inside.split(" as ",1); arr=self.eval_expr(left)
                keyvar=None; valpart=right
                if "=>" in right: kp,valpart=right.split("=>",1); keyvar=kp.strip().lstrip("$")
                valvar=valpart.strip().lstrip("$")
                if isinstance(arr, dict):
                    for k,v in list(arr.items()):
                        if keyvar: self.env[keyvar]=k
                        self.env[valvar]=v; self.exec(block)
                continue
            if code.startswith("function", i) and word_boundary(code, i+8):
                m=re.match(r'function\s+([A-Za-z_]\w*)\s*', code[i:])
                name=m.group(1); pstart=i+m.end()
                inside, after = read_paren(code, code.find("(", pstart))
                block, i = read_block_or_stmt(code, after)
                params=[p.strip().split("=")[0].strip().lstrip("$") for p in split_top(inside, ",") if p.strip()]
                self.functions[name.lower()] = (params, block)
                continue
            stmt, i = read_stmt(code, i)
            self.simple(stmt)
    def simple(self, stmt):
        s=stmt.strip()
        if not s: return
        if s.startswith("echo "):
            for p in self.split_commas(s[5:]): sys.stdout.write(php_str(self.eval_expr(p)))
            return
        if s.startswith("print "):
            sys.stdout.write(php_str(self.eval_expr(s[6:]))); return
        if s.startswith("return"):
            raise ReturnSignal(self.eval_expr(s[6:].strip() or "null"))
        if s.startswith("include ") or s.startswith("require "):
            expr=s.split(None,1)[1].strip()
            fn=php_str(self.eval_expr(expr))
            with open(fn) as f: self.exec(extract_php(f.read()))
            return
        m=re.match(r'^\$([A-Za-z_]\w*)\s*(\+\+|--)$', s)
        if m:
            self.env[m.group(1)]=php_num(self.env.get(m.group(1),0))+(1 if m.group(2)=="++" else -1); return
        m=re.match(r'^\$([A-Za-z_]\w*)\s*\[(.*?)\]\s*=\s*(.*)$', s, re.S)
        if m:
            name,kexpr,expr=m.groups()
            arr=self.env.get(name)
            if not isinstance(arr, dict): arr={}
            key = (max([x for x in arr.keys() if isinstance(x,int)] or [-1]) + 1) if not kexpr.strip() else self.eval_expr(kexpr)
            arr[key]=self.eval_expr(expr); self.env[name]=arr; return
        m=re.match(r'^\$([A-Za-z_]\w*)\s*(=|\+=|-=|\.=)\s*(.*)$', s, re.S)
        if m:
            name,op,expr=m.groups(); val=self.eval_expr(expr)
            if op=="=": self.env[name]=val
            elif op=="+=": self.env[name]=php_num(self.env.get(name,0))+php_num(val)
            elif op=="-=": self.env[name]=php_num(self.env.get(name,0))-php_num(val)
            else: self.env[name]=php_str(self.env.get(name,""))+php_str(val)
            return
        self.eval_expr(s)

def skip_ws(s,i):
    while i<len(s) and s[i].isspace(): i+=1
    return i
def word_boundary(s,i): return i>=len(s) or not (s[i].isalnum() or s[i]=="_")
def read_paren(s,i):
    depth=0; q=None; esc=False; start=i+1
    for j in range(i,len(s)):
        c=s[j]
        if q:
            if esc: esc=False
            elif c=="\\": esc=True
            elif c==q: q=None
        elif c in "\"'": q=c
        elif c=="(": depth+=1
        elif c==")":
            depth-=1
            if depth==0: return s[start:j], j+1
    return s[start:], len(s)
def read_block_or_stmt(s,i):
    i=skip_ws(s,i)
    if i<len(s) and s[i]=="{":
        depth=0; q=None; esc=False; start=i+1
        for j in range(i,len(s)):
            c=s[j]
            if q:
                if esc: esc=False
                elif c=="\\": esc=True
                elif c==q: q=None
            elif c in "\"'": q=c
            elif c=="{": depth+=1
            elif c=="}":
                depth-=1
                if depth==0: return s[start:j], j+1
    return read_stmt(s,i)
def read_stmt(s,i):
    depth=0; q=None; esc=False
    for j in range(i,len(s)):
        c=s[j]
        if q:
            if esc: esc=False
            elif c=="\\": esc=True
            elif c==q: q=None
        elif c in "\"'": q=c
        elif c in "([{" : depth+=1
        elif c in ")]}" : depth-=1
        elif c==";" and depth==0: return s[i:j], j+1
    return s[i:], len(s)
def split_top(s, sep):
    out=[]; depth=0; q=None; esc=False; last=0; i=0
    while i<len(s):
        c=s[i]
        if q:
            if esc: esc=False
            elif c=="\\": esc=True
            elif c==q: q=None
        elif c in "\"'": q=c
        elif c in "([{": depth+=1
        elif c in ")]}": depth-=1
        elif depth==0 and s.startswith(sep,i):
            out.append(s[last:i].strip()); i+=len(sep); last=i; continue
        i+=1
    out.append(s[last:].strip()); return out

def extract_php(src):
    def echo_text(t):
        if not t: return ""
        return "echo '" + t.replace("\\", "\\\\").replace("'", "\\'") + "';"
    if "<?" not in src: return echo_text(src)
    out=[]; pos=0
    while True:
        a=src.find("<?",pos)
        if a<0:
            out.append(echo_text(src[pos:])); break
        out.append(echo_text(src[pos:a]))
        b=src.find("?>",a)
        code=src[a+2:b if b>=0 else len(src)]
        if code.startswith("php"): code=code[3:]
        elif code.startswith("="): code="echo " + code[1:] + ";"
        out.append(code)
        if b<0: break
        pos=b+2
    return "\n".join(out)

def phpinfo():
    return """phpinfo()
PHP Version => 8.6.0-dev

System => Linux
Build Date => Apr 17 2026 20:00:58
Configure Command =>  './configure'  '--disable-all' '--enable-cli' '--enable-debug=no'
Server API => Command Line Interface
Configuration File (php.ini) Path => /usr/local/lib
Loaded Configuration File => (none)
Scan this dir for additional .ini files => (none)
Additional .ini files parsed => (none)
PHP API => 20250926
PHP Extension => 20250926
Zend Extension => 420250926
PHP Extension Build => API20250926,NTS
PHP Integer Size => 64 bits
Debug Build => no
Thread Safety => disabled

This program makes use of the Zend Scripting Language Engine:
Zend Engine v4.6.0-dev, Copyright (c) Zend Technologies
    with Zend OPcache v8.6.0-dev, Copyright (c), by Zend Technologies
"""

def rf(name):
    known={"strlen":("Core","string $string","int"),"json_encode":("json","mixed $value, int $flags = 0, int $depth = 512","string|false"),
           "trim":("standard","string $string, string $characters = \" \\n\\r\\t\\v\\x00\"","string"),
           "count":("standard","Countable|array $value, int $mode = COUNT_NORMAL","int")}
    if name not in known: print(f"Exception: Function {name}() does not exist"); return
    ext,params,ret=known[name]; plist=[p.strip() for p in params.split(",")]
    print(f"Function [ <internal:{ext}> function {name} ] {{\n\n  - Parameters [{len(plist)}] {{")
    for i,p in enumerate(plist): print(f"    Parameter #{i} [ <required> {p} ]")
    print(f"  }}\n  - Return [ {ret} ]\n}}")

def rc(name):
    if name=="stdClass": print("Class [ <internal:Core> class stdClass ] {\n\n  - Constants [0] {\n  }\n\n  - Static properties [0] {\n  }\n\n  - Static methods [0] {\n  }\n\n  - Properties [0] {\n  }\n\n  - Methods [0] {\n  }\n}")
    else: print(f"Exception: Class \"{name}\" does not exist")

def run_code(code, filename="Command line code", args=None):
    p=MiniPHP(filename)
    if args is not None:
        p.env["argc"]=len(args); p.env["argv"]={i:v for i,v in enumerate(args)}
    try:
        p.exec(code)
        return 0
    except PhpError as e:
        print(f"\nFatal error: Uncaught Error: {e} in {filename}:1", file=sys.stderr)
        print("Stack trace:\n#0 {main}\n  thrown in %s on line 1" % filename, file=sys.stderr)
        return 255

def main(argv):
    if len(argv)==1: return run_code(extract_php(sys.stdin.read()), "Standard input code")
    i=1; mode=None; val=None; begin=end=None; script_args=[]
    while i<len(argv):
        a=argv[i]
        if a=="--": script_args=argv[i+1:]; break
        if a in ("-h","--help"): print(HELP, end=""); return 0
        if a in ("-v","--version"): print(VERSION); return 0
        if a=="-m": print(MODULES); return 0
        if a=="-i": print(phpinfo()); return 0
        if a=="--ini": print('Configuration File (php.ini) Path: "/usr/local/lib"\nLoaded Configuration File:         (none)\nScan for additional .ini files in: (none)\nAdditional .ini files parsed:      (none)'); return 0
        if a=="--ini=diff": print('Non-default INI settings:\nhtml_errors: "1" -> "0"\nimplicit_flush: "0" -> "1"\nmax_execution_time: "30" -> "0"'); return 0
        if a=="--rf" and i+1<len(argv): rf(argv[i+1]); return 0
        if a=="--rc" and i+1<len(argv): rc(argv[i+1]); return 0
        if a in ("--re","--ri","--rz") and i+1<len(argv): print(f"{argv[i+1]}"); return 0
        if a in ("-n","-e","-H") or a.startswith("-d"): i+=1; continue
        if a in ("-c","-d","--repeat","-t"): i+=2; continue
        if a=="-r": mode="r"; val=argv[i+1]; i+=2; continue
        if a=="-f": mode="f"; val=argv[i+1]; i+=2; continue
        if a=="-l": fn=argv[i+1]; print(f"No syntax errors detected in {fn}"); return 0
        if a=="-B": begin=argv[i+1]; i+=2; continue
        if a=="-R": mode="R"; val=argv[i+1]; i+=2; continue
        if a=="-F": mode="F"; val=argv[i+1]; i+=2; continue
        if a=="-E": end=argv[i+1]; i+=2; continue
        if a=="-s":
            fn=argv[i+1] if i+1<len(argv) else None
            src=open(fn).read() if fn else sys.stdin.read()
            print("<code>"+html.escape(src)+"</code>"); return 0
        if a=="-w":
            fn=argv[i+1] if i+1<len(argv) else None
            src=open(fn).read() if fn else sys.stdin.read()
            print(re.sub(r'/\*.*?\*/|//[^\n]*|#[^\n]*', '', src, flags=re.S)); return 0
        if a.startswith("-"): print(f"Error in argument {i}, char 2: option not found {a}", file=sys.stderr); return 1
        mode="f"; val=a; script_args=argv[i:]; break
    if mode=="r": return run_code(val, args=["Standard input code"]+script_args)
    if mode=="f":
        try: src=open(val).read()
        except OSError as e: print(f"Could not open input file: {val}", file=sys.stderr); return 1
        return run_code(extract_php(src), val, [val]+script_args[1:])
    if mode in ("R","F"):
        p=MiniPHP("Command line code"); 
        if begin: p.exec(begin)
        body=open(val).read() if mode=="F" else val
        for idx,line in enumerate(sys.stdin,1):
            p.env["argn"]=line; p.env["argi"]=idx; p.exec(body)
        if end: p.exec(end)
        return 0
    return 0

if __name__ == "__main__":
    sys.exit(main(sys.argv))
