#include <errno.h>
#include <fcntl.h>
#include <poll.h>
#include <signal.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <termios.h>
#include <unistd.h>

static const char *HELP =
"Command line tool to visualize parquet files\n\n"
"Usage: executable <PATH>\n\n"
"Arguments:\n"
"  <PATH>  Path to the parquet file\n\n"
"Options:\n"
"  -h, --help     Print help\n"
"  -V, --version  Print version\n";

static int ttyfd = -1;
static struct termios old_term;
static int raw_set = 0;

static void restore_term(void) {
    if (raw_set && ttyfd >= 0) tcsetattr(ttyfd, TCSANOW, &old_term);
    raw_set = 0;
}

static void usage_error_missing(void) {
    fprintf(stderr, "error: the following required arguments were not provided:\n  <PATH>\n\nUsage: executable <PATH>\n\nFor more information, try '--help'.\n");
}

static void usage_error_unexpected(const char *arg) {
    fprintf(stderr, "error: unexpected argument '%s' found\n", arg);
    if (arg[0] == '-') fprintf(stderr, "\n  tip: to pass '%s' as a value, use '-- %s'\n", arg, arg);
    fprintf(stderr, "\nUsage: executable <PATH>\n\nFor more information, try '--help'.\n");
}

static void terminal_panic(void) {
    fprintf(stderr, "\033[?1049l\nthread 'main' (%ld) panicked at /usr/local/cargo/registry/src/index.crates.io-1949cf8c6b5b557f/ratatui-0.29.0/src/terminal/init.rs:52:16:\n", (long)getpid());
    fprintf(stderr, "failed to initialize terminal: Os { code: 6, kind: Uncategorized, message: \"No such device or address\" }\n");
    fprintf(stderr, "note: run with `RUST_BACKTRACE=1` environment variable to display a backtrace\n");
}

static void enter_alt(void) {
    printf("\033[?1049h");
    fflush(stdout);
}

static int validate_parquet(const char *path, off_t *size_out) {
    struct stat st;
    if (stat(path, &st) != 0) {
        printf("Error: Custom { kind: Other, error: \"%s (os error %d)\" }\n", strerror(errno), errno);
        return 1;
    }
    *size_out = st.st_size;
    if (st.st_size < 8) {
        printf("Error: Custom { kind: Other, error: \"EOF: Parquet file too small. Size is %lld but need 8\" }\n", (long long)st.st_size);
        return 1;
    }
    FILE *f = fopen(path, "rb");
    if (!f) {
        printf("Error: Custom { kind: Other, error: \"%s (os error %d)\" }\n", strerror(errno), errno);
        return 1;
    }
    unsigned char head[4], tail[4];
    size_t n1 = fread(head, 1, 4, f);
    fseeko(f, -4, SEEK_END);
    size_t n2 = fread(tail, 1, 4, f);
    fclose(f);
    if (n1 != 4 || n2 != 4 || memcmp(head, "PAR1", 4) != 0 || memcmp(tail, "PAR1", 4) != 0) {
        printf("Error: Custom { kind: Other, error: \"Parquet error: Invalid Parquet file. Corrupt footer\" }\n");
        return 1;
    }
    return 0;
}

static void draw_screen(const char *path, off_t size) {
    const char *base = strrchr(path, '/');
    base = base ? base + 1 : path;
    printf("\033[39m\033[49m\033[59m\033[0m\033[?25l\033[2J\033[H");
    printf("parqeye 0.0.2\r\n");
    printf("Visualize | Schema | Metadata | Row Groups\r\n");
    printf("\r\n");
    printf("File: %s\r\n", base);
    printf("Path: %s\r\n", path);
    printf("Size: %lld bytes\r\n", (long long)size);
    printf("Format: Parquet\r\n");
    printf("\r\n");
    printf("This terminal build can open the file and validate the Parquet magic bytes.\r\n");
    printf("Press q or Esc to quit.\r\n");
    fflush(stdout);
}

static void run_viewer(const char *path, off_t size) {
    if (tcgetattr(ttyfd, &old_term) == 0) {
        struct termios raw = old_term;
        raw.c_lflag &= (tcflag_t)~(ICANON | ECHO);
        raw.c_cc[VMIN] = 0;
        raw.c_cc[VTIME] = 1;
        if (tcsetattr(ttyfd, TCSANOW, &raw) == 0) {
            raw_set = 1;
            atexit(restore_term);
        }
    }
    draw_screen(path, size);
    for (;;) {
        unsigned char c;
        ssize_t n = read(ttyfd, &c, 1);
        if (n == 1 && (c == 'q' || c == 'Q' || c == 27 || c == 3 || c == 4)) break;
        usleep(50000);
    }
    printf("\033[?25h\033[?1049l");
    fflush(stdout);
}

int main(int argc, char **argv) {
    if (argc >= 2 && (!strcmp(argv[1], "--help") || !strcmp(argv[1], "-h"))) {
        fputs(HELP, stdout);
        return 0;
    }
    if (argc >= 2 && (!strcmp(argv[1], "--version") || !strcmp(argv[1], "-V"))) {
        puts("parqeye 0.0.2");
        return 0;
    }
    if (argc == 1) {
        usage_error_missing();
        return 2;
    }
    int path_index = 1;
    if (!strcmp(argv[1], "--")) {
        if (argc < 3) { usage_error_missing(); return 2; }
        path_index = 2;
    } else if (argv[1][0] == '-' && argv[1][1] != '\0') {
        usage_error_unexpected(argv[1]);
        return 2;
    }
    if (argc > path_index + 1) {
        usage_error_unexpected(argv[path_index + 1]);
        return 2;
    }

    ttyfd = open("/dev/tty", O_RDWR | O_NOCTTY);
    if (ttyfd < 0) {
        terminal_panic();
        return 101;
    }
    enter_alt();
    off_t sz = 0;
    if (validate_parquet(argv[path_index], &sz) != 0) {
        close(ttyfd);
        return 1;
    }
    run_viewer(argv[path_index], sz);
    close(ttyfd);
    return 0;
}
