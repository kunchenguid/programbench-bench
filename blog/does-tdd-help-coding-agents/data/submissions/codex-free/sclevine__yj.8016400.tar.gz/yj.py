#!/usr/bin/env python3
import json
import math
import re
import sys
try:
    import tomli
except Exception:
    tomli = None


HELP = """Usage: {prog} [-][ytjcrneikhv]

Convert between YAML, TOML, JSON, and HCL.
Preserves map order.

-x[x]  Convert using stdin. Valid options:
          -yj, -y = YAML to JSON (default)
          -yy     = YAML to YAML
          -yt     = YAML to TOML
          -yc     = YAML to HCL
          -tj, -t = TOML to JSON
          -ty     = TOML to YAML
          -tt     = TOML to TOML
          -tc     = TOML to HCL
          -jj     = JSON to JSON
          -jy, -r = JSON to YAML
          -jt     = JSON to TOML
          -jc     = JSON to HCL
          -cy     = HCL to YAML
          -ct     = HCL to TOML
          -cj, -c = HCL to JSON
          -cc     = HCL to HCL
-n     Do not covert inf, -inf, and NaN to/from strings (YAML or TOML only)
-e     Escape HTML (JSON out only)
-i     Indent output (JSON or TOML out only)
-k     Attempt to parse keys as objects or numeric types (YAML out only)
-h     Show this help message
-v     Show version
"""


class ParseError(Exception):
    pass


def strip_comment(s):
    q = None
    esc = False
    out = []
    for ch in s:
        if q:
            out.append(ch)
            if esc:
                esc = False
            elif ch == "\\":
                esc = True
            elif ch == q:
                q = None
        else:
            if ch in "'\"":
                q = ch
                out.append(ch)
            elif ch == "#":
                break
            else:
                out.append(ch)
    return "".join(out).rstrip()


def split_top(s, sep=","):
    parts, cur = [], []
    q = None
    esc = False
    depth = 0
    for ch in s:
        if q:
            cur.append(ch)
            if esc:
                esc = False
            elif ch == "\\":
                esc = True
            elif ch == q:
                q = None
            continue
        if ch in "'\"":
            q = ch
            cur.append(ch)
        elif ch in "[{(":
            depth += 1
            cur.append(ch)
        elif ch in "]})":
            depth -= 1
            cur.append(ch)
        elif ch == sep and depth == 0:
            parts.append("".join(cur).strip())
            cur = []
        else:
            cur.append(ch)
    parts.append("".join(cur).strip())
    return parts


def unquote(s):
    if len(s) >= 2 and s[0] == s[-1] and s[0] in "'\"":
        if s[0] == '"':
            try:
                return json.loads(s)
            except Exception:
                return s[1:-1]
        return s[1:-1].replace("''", "'")
    return s


def parse_scalar(s, no_inf=False):
    s = s.strip()
    if s == "":
        return ""
    low = s.lower()
    if (s.startswith('"') and s.endswith('"')) or (s.startswith("'") and s.endswith("'")):
        return unquote(s)
    if s.startswith("[") and s.endswith("]"):
        body = s[1:-1].strip()
        return [] if not body else [parse_scalar(p, no_inf) for p in split_top(body)]
    if s.startswith("{") and s.endswith("}"):
        body = s[1:-1].strip()
        d = {}
        if body:
            for p in split_top(body):
                if "=" in p:
                    k, v = p.split("=", 1)
                elif ":" in p:
                    k, v = p.split(":", 1)
                else:
                    continue
                d[unquote(k.strip())] = parse_scalar(v, no_inf)
        return d
    if low in ("true", "false"):
        return low == "true"
    if low in ("null", "~"):
        return None
    if low in (".inf", "+.inf", "inf", "+inf", "infinity", "+infinity"):
        return sys.float_info.max if no_inf else "Infinity"
    if low in ("-.inf", "-inf", "-infinity"):
        return -sys.float_info.max if no_inf else "-Infinity"
    if low in (".nan", "nan"):
        return None if no_inf else "NaN"
    if re.fullmatch(r"[-+]?(0|[1-9][0-9_]*)", s):
        try:
            return int(s.replace("_", ""))
        except Exception:
            pass
    if re.fullmatch(r"[-+]?(?:[0-9][0-9_]*)?\.[0-9_]+(?:[eE][-+]?[0-9_]+)?|[-+]?[0-9][0-9_]*(?:[eE][-+]?[0-9_]+)", s):
        try:
            return float(s.replace("_", ""))
        except Exception:
            pass
    return s


def yaml_lines(text):
    out = []
    for raw in text.splitlines():
        if not raw.strip() or raw.lstrip().startswith("#"):
            continue
        line = strip_comment(raw.rstrip("\n"))
        if line.strip():
            out.append((len(line) - len(line.lstrip(" ")), line.lstrip(" ")))
    return out


def parse_yaml(text, no_inf=False):
    lines = yaml_lines(text)
    if not lines:
        return None

    def parse_block(i, indent):
        if i >= len(lines):
            return None, i
        is_list = lines[i][0] == indent and lines[i][1].startswith("- ")
        if is_list:
            arr = []
            while i < len(lines) and lines[i][0] == indent and lines[i][1].startswith("- "):
                item = lines[i][1][2:].strip()
                if item == "":
                    val, i = parse_block(i + 1, indent + 2)
                    arr.append(val)
                elif ":" in item and not item.startswith(("'", '"')):
                    k, v = item.split(":", 1)
                    d = {unquote(k.strip()): parse_scalar(v.strip(), no_inf) if v.strip() else {}}
                    i += 1
                    if v.strip() == "" and i < len(lines) and lines[i][0] > indent:
                        d[unquote(k.strip())], i = parse_block(i, lines[i][0])
                    while i < len(lines) and lines[i][0] >= indent + 2 and not (lines[i][0] == indent and lines[i][1].startswith("- ")):
                        if lines[i][0] == indent + 2 and ":" in lines[i][1]:
                            kk, vv = lines[i][1].split(":", 1)
                            if vv.strip():
                                d[unquote(kk.strip())] = parse_scalar(vv.strip(), no_inf)
                                i += 1
                            else:
                                d[unquote(kk.strip())], i = parse_block(i + 1, indent + 4)
                        else:
                            break
                    arr.append(d)
                else:
                    arr.append(parse_scalar(item, no_inf))
                    i += 1
            return arr, i
        d = {}
        while i < len(lines) and lines[i][0] == indent and not lines[i][1].startswith("- "):
            if ":" not in lines[i][1]:
                raise ParseError("yaml: line does not contain ':'")
            k, v = lines[i][1].split(":", 1)
            key = unquote(k.strip())
            v = v.strip()
            i += 1
            if v:
                d[key] = parse_scalar(v, no_inf)
            elif i < len(lines) and lines[i][0] > indent:
                d[key], i = parse_block(i, lines[i][0])
            else:
                d[key] = None
        return d, i

    val, _ = parse_block(0, lines[0][0])
    return val


def parse_toml(text, no_inf=False):
    if tomli is not None:
        try:
            return normalize_special(tomli.loads(text), no_inf)
        except Exception:
            pass
    root = {}
    cur = root
    for raw in text.splitlines():
        line = strip_comment(raw).strip()
        if not line:
            continue
        if line.startswith("[[") and line.endswith("]]"):
            name = line[2:-2].strip()
            parent = root
            parts = [unquote(p.strip()) for p in name.split(".")]
            for p in parts[:-1]:
                parent = parent.setdefault(p, {})
            arr = parent.setdefault(parts[-1], [])
            obj = {}
            arr.append(obj)
            cur = obj
        elif line.startswith("[") and line.endswith("]"):
            cur = root
            for p in [unquote(x.strip()) for x in line[1:-1].split(".")]:
                cur = cur.setdefault(p, {})
        elif "=" in line:
            k, v = line.split("=", 1)
            cur[unquote(k.strip())] = parse_scalar(v.strip(), no_inf)
    return root


def normalize_special(v, no_inf=False):
    if isinstance(v, dict):
        return {k: normalize_special(val, no_inf) for k, val in v.items()}
    if isinstance(v, list):
        return [normalize_special(x, no_inf) for x in v]
    if isinstance(v, float):
        if math.isnan(v):
            return None if no_inf else "NaN"
        if math.isinf(v):
            return (sys.float_info.max if v > 0 else -sys.float_info.max) if no_inf else ("Infinity" if v > 0 else "-Infinity")
    if hasattr(v, "isoformat"):
        return v.isoformat()
    return v


class HclParser:
    def __init__(self, text, no_inf=False):
        self.s = text
        self.i = 0
        self.n = len(text)
        self.no_inf = no_inf

    def skip(self):
        while self.i < self.n:
            if self.s[self.i].isspace():
                self.i += 1
            elif self.s[self.i] == "#":
                while self.i < self.n and self.s[self.i] != "\n":
                    self.i += 1
            elif self.s.startswith("//", self.i):
                while self.i < self.n and self.s[self.i] != "\n":
                    self.i += 1
            else:
                break

    def ident(self):
        self.skip()
        if self.i < self.n and self.s[self.i] in "'\"":
            q = self.s[self.i]
            j = self.i + 1
            esc = False
            while j < self.n:
                if esc:
                    esc = False
                elif self.s[j] == "\\":
                    esc = True
                elif self.s[j] == q:
                    val = unquote(self.s[self.i:j + 1])
                    self.i = j + 1
                    return val
                j += 1
        m = re.match(r"[A-Za-z0-9_.:-]+", self.s[self.i:])
        if not m:
            return ""
        self.i += len(m.group(0))
        return m.group(0)

    def value(self):
        self.skip()
        if self.i >= self.n:
            return None
        ch = self.s[self.i]
        if ch == "{":
            self.i += 1
            d = {}
            while True:
                self.skip()
                if self.i >= self.n or self.s[self.i] == "}":
                    self.i += 1
                    return d
                k = self.ident()
                self.skip()
                if self.i < self.n and self.s[self.i] in "=:":
                    self.i += 1
                d[k] = self.value()
                self.skip()
                if self.i < self.n and self.s[self.i] == ",":
                    self.i += 1
        if ch == "[":
            j = self.find_matching("[", "]")
            val = parse_scalar(self.s[self.i:j + 1], self.no_inf)
            self.i = j + 1
            return val
        if ch in "'\"":
            return self.ident()
        j = self.i
        while j < self.n and self.s[j] not in "\n,}]":
            j += 1
        raw = self.s[self.i:j].strip()
        self.i = j
        return parse_scalar(raw, self.no_inf)

    def find_matching(self, a, b):
        q = None
        esc = False
        depth = 0
        j = self.i
        while j < self.n:
            ch = self.s[j]
            if q:
                if esc:
                    esc = False
                elif ch == "\\":
                    esc = True
                elif ch == q:
                    q = None
            else:
                if ch in "'\"":
                    q = ch
                elif ch == a:
                    depth += 1
                elif ch == b:
                    depth -= 1
                    if depth == 0:
                        return j
            j += 1
        return self.n - 1

    def parse(self):
        d = {}
        while True:
            self.skip()
            if self.i >= self.n:
                return d
            k = self.ident()
            if not k:
                self.i += 1
                continue
            self.skip()
            if self.i < self.n and self.s[self.i] == "=":
                self.i += 1
                d[k] = self.value()
            else:
                labels = []
                while self.i < self.n and self.s[self.i] != "{":
                    lab = self.ident()
                    if lab:
                        labels.append(lab)
                    else:
                        break
                    self.skip()
                if self.i < self.n and self.s[self.i] == "{":
                    val = self.value()
                    target = d
                    for part in [k] + labels[:-1]:
                        target = target.setdefault(part, {})
                    final = labels[-1] if labels else k
                    old = target.get(final)
                    if old is None:
                        target[final] = val
                    elif isinstance(old, list):
                        old.append(val)
                    else:
                        target[final] = [old, val]
                else:
                    d[k] = None


def parse_hcl(text, no_inf=False):
    return HclParser(text, no_inf).parse()


def json_dumps(data, indent=False, escape_html=False):
    if indent:
        s = json.dumps(data, ensure_ascii=False, indent=2, allow_nan=True)
    else:
        s = json.dumps(data, ensure_ascii=False, separators=(",", ":"), allow_nan=True)
    if escape_html:
        s = s.replace("&", "\\u0026").replace("<", "\\u003c").replace(">", "\\u003e")
    return s + "\n"


def yaml_key(k, parse_keys=False):
    if parse_keys:
        try:
            v = json.loads(k)
            return yaml_scalar(v, False, parse_keys).rstrip()
        except Exception:
            pass
    if isinstance(k, str):
        if re.fullmatch(r"[A-Za-z_][A-Za-z0-9_-]*", k):
            return k
        if re.fullmatch(r"[-+]?[0-9]+", k) or k.lower() in ("true", "false", "null"):
            return json.dumps(k)
        return "'" + k.replace("'", "''") + "'"
    return str(k).lower() if isinstance(k, bool) else str(k)


def needs_quote_yaml(s):
    if s == "":
        return True
    low = s.lower()
    if low in ("true", "false", "null", "yes", "no", "on", "off", "~", ".inf", "-.inf", ".nan"):
        return True
    if re.fullmatch(r"[-+]?[0-9]+(?:\.[0-9]+)?", s):
        return True
    return bool(re.search(r"^[-?:,\[\]{}#&*!|>'\"%@`]|:\s|[ \t]#|\n", s))


def yaml_scalar(v, no_inf=False, parse_keys=False):
    if v is None:
        return "null"
    if isinstance(v, bool):
        return "true" if v else "false"
    if isinstance(v, int):
        return str(v)
    if isinstance(v, float):
        if math.isnan(v):
            return ".nan" if no_inf else "NaN"
        if math.isinf(v) or abs(v) >= sys.float_info.max:
            return ".inf" if v > 0 else "-.inf"
        return repr(v)
    if isinstance(v, str):
        if v == "Infinity":
            return ".inf"
        if v == "-Infinity":
            return "-.inf"
        if v == "NaN":
            return ".nan"
        return json.dumps(v, ensure_ascii=False) if needs_quote_yaml(v) else v
    return json.dumps(v, ensure_ascii=False)


def yaml_dump(data, no_inf=False, parse_keys=False, indent=0):
    sp = " " * indent
    if isinstance(data, dict):
        out = []
        for k, v in data.items():
            kk = yaml_key(str(k), parse_keys)
            if isinstance(v, (dict, list)):
                out.append(f"{sp}{kk}:")
                out.append(yaml_dump(v, no_inf, parse_keys, indent + 2).rstrip("\n"))
            else:
                out.append(f"{sp}{kk}: {yaml_scalar(v, no_inf, parse_keys)}")
        return "\n".join(out) + ("\n" if out else "")
    if isinstance(data, list):
        out = []
        for v in data:
            if isinstance(v, (dict, list)):
                out.append(f"{sp}-")
                out.append(yaml_dump(v, no_inf, parse_keys, indent + 2).rstrip("\n"))
            else:
                out.append(f"{sp}- {yaml_scalar(v, no_inf, parse_keys)}")
        return "\n".join(out) + ("\n" if out else "")
    return sp + yaml_scalar(data, no_inf, parse_keys) + "\n"


def toml_scalar(v):
    if isinstance(v, bool):
        return "true" if v else "false"
    if isinstance(v, int):
        return str(v)
    if isinstance(v, float):
        return repr(v)
    if isinstance(v, str):
        return json.dumps(v, ensure_ascii=False)
    if isinstance(v, list):
        return "[" + ", ".join(toml_scalar(x) for x in v if not isinstance(x, (dict, list)) and x is not None) + "]"
    if v is None:
        return '""'
    return json.dumps(str(v))


def toml_dump(data, indent=False):
    lines = []
    sections = []

    def emit_table(tbl, prefix=None, level=0):
        for k, v in tbl.items():
            if isinstance(v, dict):
                sections.append((prefix + [k] if prefix else [k], v, level))
            elif isinstance(v, list) and v and all(isinstance(x, dict) for x in v):
                for item in v:
                    sections.append((prefix + [k] if prefix else [k], item, level, True))
            elif v is None:
                continue
            else:
                pad = "  " if indent and prefix else ""
                lines.append(f"{pad}{k} = {toml_scalar(v)}")

    emit_table(data)
    first = True
    while sections:
        sec = sections.pop(0)
        path, tbl = sec[0], sec[1]
        array = len(sec) > 3
        if lines or not first:
            lines.append("")
        first = False
        name = ".".join(path)
        lines.append(f"[[{name}]]" if array else f"[{name}]")
        before = len(lines)
        nested = []
        for k, v in tbl.items():
            if isinstance(v, dict):
                nested.append((path + [k], v, 0))
            else:
                pad = "  " if indent else ""
                lines.append(f"{pad}{k} = {toml_scalar(v)}")
        sections = nested + sections
    return "\n".join(lines) + "\n"


def hcl_scalar(v, level=0):
    if isinstance(v, bool):
        return "true" if v else "false"
    if isinstance(v, int):
        return str(v)
    if isinstance(v, float):
        return repr(v)
    if isinstance(v, str):
        return json.dumps(v, ensure_ascii=False)
    if isinstance(v, list):
        vals = [hcl_scalar(x, level) for x in v if not isinstance(x, (dict, list)) and x is not None and not isinstance(x, bool)]
        return "[" + ", ".join(vals) + "]"
    if isinstance(v, dict):
        inner = hcl_dump(v, level + 1).rstrip("\n")
        return "{\n" + inner + "\n" + ("  " * level) + "}"
    if v is None:
        return ""
    return json.dumps(str(v))


def hcl_dump(data, level=0):
    sp = "  " * level
    out = []
    if not isinstance(data, dict):
        return hcl_scalar(data, level) + "\n"
    for k, v in data.items():
        if out:
            out.append("")
        key = json.dumps(str(k), ensure_ascii=False)
        if isinstance(v, dict):
            out.append(f"{sp}{key} = {{")
            body = hcl_dump(v, level + 1).rstrip("\n")
            if body:
                out.append(body)
            out.append(f"{sp}}}")
        else:
            out.append(f"{sp}{key} = {hcl_scalar(v, level)}")
    return "\n".join(out) + "\n"


def convert(inp, outp, text, opts):
    if inp == "j":
        data = json.loads(text)
    elif inp == "y":
        data = parse_yaml(text, opts["n"])
    elif inp == "t":
        data = parse_toml(text, opts["n"])
    elif inp == "c":
        data = parse_hcl(text, opts["n"])
    else:
        data = parse_yaml(text, opts["n"])
    if outp == "j":
        return json_dumps(data, opts["i"], opts["e"])
    if outp == "y":
        return yaml_dump(data, opts["n"], opts["k"])
    if outp == "t":
        return toml_dump(data, opts["i"])
    if outp == "c":
        return hcl_dump(data)
    return json_dumps(data)


def parse_args(argv):
    flags = "".join(a.lstrip("-") for a in argv[1:] if a.startswith("-"))
    valid = set("ytjcrneikhv")
    bad = [c for c in flags if c not in valid]
    if bad:
        print(HELP.format(prog=argv[0]))
        print("Error: invalid flags specified: " + " ".join(bad))
        sys.exit(1)
    if "v" in flags:
        print("v0.0.0")
        sys.exit(0)
    if "h" in flags:
        print(HELP.format(prog=argv[0]), end="")
        sys.exit(0)
    conv = [c for c in flags if c in "ytjc"]
    if "r" in flags:
        inp, outp = "j", "y"
    elif len(conv) == 0:
        inp, outp = "y", "j"
    elif len(conv) == 1:
        inp = conv[0]
        outp = "j" if inp in "ytc" else "j"
    else:
        inp, outp = conv[0], conv[1]
    if len(conv) > 2:
        print(HELP.format(prog=argv[0]))
        print("Error: invalid conversion specified")
        sys.exit(1)
    opts = {c: (c in flags) for c in "neik"}
    opts["i"] = "i" in flags
    if opts["i"] and outp not in ("j", "t"):
        print(HELP.format(prog=argv[0]))
        print("Error: flag -i only valid for JSON or TOML output")
        sys.exit(1)
    return inp, outp, opts


def main():
    inp, outp, opts = parse_args(sys.argv)
    text = sys.stdin.read()
    try:
        sys.stdout.write(convert(inp, outp, text, opts))
    except Exception as e:
        print("Error: " + str(e), file=sys.stderr)
        sys.exit(1)


if __name__ == "__main__":
    main()
