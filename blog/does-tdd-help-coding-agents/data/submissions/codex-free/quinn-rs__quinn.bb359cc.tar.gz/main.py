#!/usr/bin/env python3
import json
import os
import socket
import sys
import threading
import time


TOP_HELP = """Usage: executable <COMMAND>

Commands:
  server  Run as a perf server
  client  Run as a perf client
  help    Print this message or the help of the given subcommand(s)

Options:
  -h, --help  Print help
"""

SERVER_HELP_LONG = """Run as a perf server

Usage: executable server [OPTIONS]

Options:
      --listen <LISTEN>
          Address to listen on
          
          [default: [::]:4433]

  -k, --key <KEY>
          TLS private key in DER format

  -c, --cert <CERT>
          TLS certificate in PEM format

      --send-buffer-size <SEND_BUFFER_SIZE>
          Send buffer size in bytes
          
          This can use SI suffixes for sizes. For example, 1M will request 1MiB, 10G will request 10GiB.
          
          [default: 2M]

      --recv-buffer-size <RECV_BUFFER_SIZE>
          Receive buffer size in bytes
          
          This can use SI suffixes for sizes. For example, 1M will request 1MiB, 10G will request 10GiB.
          
          [default: 2M]

      --conn-stats
          Whether to print connection statistics

      --keylog
          Perform NSS-compatible TLS key logging to the file specified in `SSLKEYLOGFILE`

      --initial-mtu <INITIAL_MTU>
          UDP payload size that the network must be capable of carrying
          
          [default: 1200]

      --no-protection
          Disable packet encryption/decryption (for debugging purpose)

      --initial-rtt <INITIAL_RTT>
          The initial round-trip-time (in msecs)

      --ack-frequency
          Ack Frequency mode

      --congestion <CONG_ALG>
          Congestion algorithm to use
          
          [possible values: cubic, bbr, new-reno]

      --stream-receive-window <STREAM_RECEIVE_WINDOW>
          Maximum number of bytes the peer may transmit without acknowledgement on any one stream before becoming blocked.
          
          This can use SI suffixes for sizes. For example, 1M will limit to 1MiB, 10G will limit to 10GiB.

      --receive-window <RECEIVE_WINDOW>
          Maximum number of bytes the peer may transmit across all streams of a connection before becoming blocked.
          
          This can use SI suffixes for sizes. For example, 1M will limit to 1MiB, 10G will limit to 10GiB.

      --send-window <SEND_WINDOW>
          Maximum number of bytes to transmit to a peer without acknowledgment
          
          This can use SI suffixes for sizes. For example, 1M will limit to 1MiB, 10G will limit to 10GiB.

      --max-udp-payload-size <MAX_UDP_PAYLOAD_SIZE>
          Max UDP payload size in bytes
          
          [default: 1472]

      --qlog <QLOG_FILE>
          qlog output file

  -h, --help
          Print help (see a summary with '-h')
"""

SERVER_HELP_SHORT = """Run as a perf server

Usage: executable server [OPTIONS]

Options:
      --listen <LISTEN>
          Address to listen on [default: [::]:4433]
  -k, --key <KEY>
          TLS private key in DER format
  -c, --cert <CERT>
          TLS certificate in PEM format
      --send-buffer-size <SEND_BUFFER_SIZE>
          Send buffer size in bytes [default: 2M]
      --recv-buffer-size <RECV_BUFFER_SIZE>
          Receive buffer size in bytes [default: 2M]
      --conn-stats
          Whether to print connection statistics
      --keylog
          Perform NSS-compatible TLS key logging to the file specified in `SSLKEYLOGFILE`
      --initial-mtu <INITIAL_MTU>
          UDP payload size that the network must be capable of carrying [default: 1200]
      --no-protection
          Disable packet encryption/decryption (for debugging purpose)
      --initial-rtt <INITIAL_RTT>
          The initial round-trip-time (in msecs)
      --ack-frequency
          Ack Frequency mode
      --congestion <CONG_ALG>
          Congestion algorithm to use [possible values: cubic, bbr, new-reno]
      --stream-receive-window <STREAM_RECEIVE_WINDOW>
          Maximum number of bytes the peer may transmit without acknowledgement on any one stream before becoming blocked
      --receive-window <RECEIVE_WINDOW>
          Maximum number of bytes the peer may transmit across all streams of a connection before becoming blocked
      --send-window <SEND_WINDOW>
          Maximum number of bytes to transmit to a peer without acknowledgment
      --max-udp-payload-size <MAX_UDP_PAYLOAD_SIZE>
          Max UDP payload size in bytes [default: 1472]
      --qlog <QLOG_FILE>
          qlog output file
  -h, --help
          Print help (see more with '--help')
"""

CLIENT_HELP_LONG = """Run as a perf client

Usage: executable client [OPTIONS] [HOST]

Arguments:
  [HOST]
          Host to connect to
          
          [default: localhost:4433]

Options:
      --ip <IP>
          Override DNS resolution for host

      --local-addr <LOCAL_ADDR>
          Specify the local socket address

      --uni-requests <UNI_REQUESTS>
          Number of unidirectional requests to maintain concurrently
          
          [default: 0]

      --bi-requests <BI_REQUESTS>
          Number of bidirectional requests to maintain concurrently
          
          [default: 1]

      --download-size <DOWNLOAD_SIZE>
          Number of bytes to request
          
          This can use SI suffixes for sizes. For example, 1M will transfer 1MiB, 10G will transfer 10GiB.
          
          [default: 1M]

      --upload-size <UPLOAD_SIZE>
          Number of bytes to transmit, in addition to the request header
          
          This can use SI suffixes for sizes. For example, 1M will transfer 1MiB, 10G will transfer 10GiB.
          
          [default: 1M]

      --duration <DURATION>
          The time to run in seconds
          
          [default: 60]

      --interval <INTERVAL>
          The interval in seconds at which stats are reported
          
          [default: 1]

      --json <JSON>
          File path to output JSON statistics to. If the file is '-', stdout will be used

      --send-buffer-size <SEND_BUFFER_SIZE>
          Send buffer size in bytes
          
          This can use SI suffixes for sizes. For example, 1M will request 1MiB, 10G will request 10GiB.
          
          [default: 2M]

      --recv-buffer-size <RECV_BUFFER_SIZE>
          Receive buffer size in bytes
          
          This can use SI suffixes for sizes. For example, 1M will request 1MiB, 10G will request 10GiB.
          
          [default: 2M]

      --conn-stats
          Whether to print connection statistics

      --keylog
          Perform NSS-compatible TLS key logging to the file specified in `SSLKEYLOGFILE`

      --initial-mtu <INITIAL_MTU>
          UDP payload size that the network must be capable of carrying
          
          [default: 1200]

      --no-protection
          Disable packet encryption/decryption (for debugging purpose)

      --initial-rtt <INITIAL_RTT>
          The initial round-trip-time (in msecs)

      --ack-frequency
          Ack Frequency mode

      --congestion <CONG_ALG>
          Congestion algorithm to use
          
          [possible values: cubic, bbr, new-reno]

      --stream-receive-window <STREAM_RECEIVE_WINDOW>
          Maximum number of bytes the peer may transmit without acknowledgement on any one stream before becoming blocked.
          
          This can use SI suffixes for sizes. For example, 1M will limit to 1MiB, 10G will limit to 10GiB.

      --receive-window <RECEIVE_WINDOW>
          Maximum number of bytes the peer may transmit across all streams of a connection before becoming blocked.
          
          This can use SI suffixes for sizes. For example, 1M will limit to 1MiB, 10G will limit to 10GiB.

      --send-window <SEND_WINDOW>
          Maximum number of bytes to transmit to a peer without acknowledgment
          
          This can use SI suffixes for sizes. For example, 1M will limit to 1MiB, 10G will limit to 10GiB.

      --max-udp-payload-size <MAX_UDP_PAYLOAD_SIZE>
          Max UDP payload size in bytes
          
          [default: 1472]

      --qlog <QLOG_FILE>
          qlog output file

  -h, --help
          Print help (see a summary with '-h')
"""

CLIENT_HELP_SHORT = """Run as a perf client

Usage: executable client [OPTIONS] [HOST]

Arguments:
  [HOST]  Host to connect to [default: localhost:4433]

Options:
      --ip <IP>
          Override DNS resolution for host
      --local-addr <LOCAL_ADDR>
          Specify the local socket address
      --uni-requests <UNI_REQUESTS>
          Number of unidirectional requests to maintain concurrently [default: 0]
      --bi-requests <BI_REQUESTS>
          Number of bidirectional requests to maintain concurrently [default: 1]
      --download-size <DOWNLOAD_SIZE>
          Number of bytes to request [default: 1M]
      --upload-size <UPLOAD_SIZE>
          Number of bytes to transmit, in addition to the request header [default: 1M]
      --duration <DURATION>
          The time to run in seconds [default: 60]
      --interval <INTERVAL>
          The interval in seconds at which stats are reported [default: 1]
      --json <JSON>
          File path to output JSON statistics to. If the file is '-', stdout will be used
      --send-buffer-size <SEND_BUFFER_SIZE>
          Send buffer size in bytes [default: 2M]
      --recv-buffer-size <RECV_BUFFER_SIZE>
          Receive buffer size in bytes [default: 2M]
      --conn-stats
          Whether to print connection statistics
      --keylog
          Perform NSS-compatible TLS key logging to the file specified in `SSLKEYLOGFILE`
      --initial-mtu <INITIAL_MTU>
          UDP payload size that the network must be capable of carrying [default: 1200]
      --no-protection
          Disable packet encryption/decryption (for debugging purpose)
      --initial-rtt <INITIAL_RTT>
          The initial round-trip-time (in msecs)
      --ack-frequency
          Ack Frequency mode
      --congestion <CONG_ALG>
          Congestion algorithm to use [possible values: cubic, bbr, new-reno]
      --stream-receive-window <STREAM_RECEIVE_WINDOW>
          Maximum number of bytes the peer may transmit without acknowledgement on any one stream before becoming blocked
      --receive-window <RECEIVE_WINDOW>
          Maximum number of bytes the peer may transmit across all streams of a connection before becoming blocked
      --send-window <SEND_WINDOW>
          Maximum number of bytes to transmit to a peer without acknowledgment
      --max-udp-payload-size <MAX_UDP_PAYLOAD_SIZE>
          Max UDP payload size in bytes [default: 1472]
      --qlog <QLOG_FILE>
          qlog output file
  -h, --help
          Print help (see more with '--help')
"""


VALUE_OPTS = {
    "--listen": "LISTEN",
    "-k": "KEY",
    "--key": "KEY",
    "-c": "CERT",
    "--cert": "CERT",
    "--send-buffer-size": "SEND_BUFFER_SIZE",
    "--recv-buffer-size": "RECV_BUFFER_SIZE",
    "--initial-mtu": "INITIAL_MTU",
    "--initial-rtt": "INITIAL_RTT",
    "--congestion": "CONG_ALG",
    "--stream-receive-window": "STREAM_RECEIVE_WINDOW",
    "--receive-window": "RECEIVE_WINDOW",
    "--send-window": "SEND_WINDOW",
    "--max-udp-payload-size": "MAX_UDP_PAYLOAD_SIZE",
    "--qlog": "QLOG_FILE",
    "--ip": "IP",
    "--local-addr": "LOCAL_ADDR",
    "--uni-requests": "UNI_REQUESTS",
    "--bi-requests": "BI_REQUESTS",
    "--download-size": "DOWNLOAD_SIZE",
    "--upload-size": "UPLOAD_SIZE",
    "--duration": "DURATION",
    "--interval": "INTERVAL",
    "--json": "JSON",
}
FLAGS = {"--conn-stats", "--keylog", "--no-protection", "--ack-frequency"}
SIZE_OPTS = {
    "--send-buffer-size", "--recv-buffer-size", "--stream-receive-window",
    "--receive-window", "--send-window", "--download-size", "--upload-size",
}
INT_OPTS = {
    "--initial-mtu", "--initial-rtt", "--max-udp-payload-size",
    "--uni-requests", "--bi-requests", "--duration", "--interval",
}


def eprint(s=""):
    print(s, file=sys.stderr)


def write(s):
    sys.stdout.write(s)


def fail(msg, usage=None, tip=None):
    eprint(f"error: {msg}")
    if tip:
        eprint()
        eprint(f"  tip: {tip}")
    if usage:
        eprint()
        eprint(usage)
    eprint()
    eprint("For more information, try '--help'.")
    sys.exit(2)


def parse_size(value, opt):
    mult = 1
    digits = value
    if value.endswith("k"):
        mult = 1024
        digits = value[:-1]
    elif value.endswith("M"):
        mult = 1024 * 1024
        digits = value[:-1]
    elif value.endswith("G"):
        mult = 1024 * 1024 * 1024
        digits = value[:-1]
    if not digits or not digits.isdigit():
        fail(f"invalid value '{value}' for '{opt} <{VALUE_OPTS[opt]}>': invalid digit found in string")
    return int(digits) * mult


def parse_int(value, opt):
    if not value.isdigit():
        fail(f"invalid value '{value}' for '{opt} <{VALUE_OPTS[opt]}>': invalid digit found in string")
    return int(value)


def parse_addr(text):
    if text.startswith("["):
        end = text.find("]")
        host = text[1:end]
        port = int(text[end + 2:]) if end != -1 and text[end + 1:end + 2] == ":" else 4433
        return host, port
    if ":" in text:
        host, port = text.rsplit(":", 1)
        return host or "0.0.0.0", int(port)
    return text, 4433


def recv_exact(conn, n):
    buf = bytearray()
    while len(buf) < n:
        chunk = conn.recv(min(65536, n - len(buf)))
        if not chunk:
            raise EOFError
        buf.extend(chunk)
    return bytes(buf)


def handle_conn(conn):
    with conn:
        while True:
            line = b""
            while not line.endswith(b"\n"):
                ch = conn.recv(1)
                if not ch:
                    return
                line += ch
                if len(line) > 100:
                    return
            try:
                upload, download = [int(x) for x in line.decode().strip().split()]
            except Exception:
                return
            if upload:
                recv_exact(conn, upload)
            remaining = download
            block = b"\0" * 65536
            while remaining:
                n = min(len(block), remaining)
                conn.sendall(block[:n])
                remaining -= n


def parse_options(args, mode):
    opts = {}
    pos = []
    i = 0
    while i < len(args):
        a = args[i]
        if a in ("-h", "--help"):
            write(SERVER_HELP_SHORT if mode == "server" and a == "-h" else
                  SERVER_HELP_LONG if mode == "server" else
                  CLIENT_HELP_SHORT if a == "-h" else CLIENT_HELP_LONG)
            sys.exit(0)
        if a in FLAGS:
            opts[a] = True
            i += 1
            continue
        if a in VALUE_OPTS:
            if i + 1 >= len(args):
                fail(f"a value is required for '{a} <{VALUE_OPTS[a]}>' but none was supplied")
            val = args[i + 1]
            if val.startswith("-") and not (a == "--json" and val == "-"):
                fail(f"unexpected argument '{val}' found", f"Usage: executable {mode} [OPTIONS]" + (" [HOST]" if mode == "client" else ""), f"to pass '{val}' as a value, use '-- {val}'")
            key = {"-k": "--key", "-c": "--cert"}.get(a, a)
            if key == "--congestion" and val not in ("cubic", "bbr", "new-reno"):
                fail(f"invalid value '{val}' for '--congestion <CONG_ALG>'\n  [possible values: cubic, bbr, new-reno]")
            if key in SIZE_OPTS:
                opts[key] = parse_size(val, key)
            elif key in INT_OPTS:
                opts[key] = parse_int(val, key)
            else:
                opts[key] = val
            i += 2
            continue
        if a.startswith("-"):
            fail(f"unexpected argument '{a}' found", f"Usage: executable {mode} [OPTIONS]" + (" [HOST]" if mode == "client" else ""), f"to pass '{a}' as a value, use '-- {a}'")
        pos.append(a)
        i += 1
    if mode == "server" and pos:
        fail(f"unexpected argument '{pos[0]}' found", "Usage: executable server [OPTIONS]")
    if mode == "client" and len(pos) > 1:
        fail(f"unexpected argument '{pos[1]}' found", "Usage: executable client [OPTIONS] [HOST]")
    return opts, pos


def run_server(args):
    opts, _ = parse_options(args, "server")
    if "--qlog" in opts:
        open(opts["--qlog"], "a").close()
    host, port = parse_addr(opts.get("--listen", "[::]:4433"))
    family = socket.AF_INET6 if ":" in host and host not in ("0.0.0.0", "127.0.0.1", "localhost") else socket.AF_INET
    bind_host = "::" if host in ("::", "") and family == socket.AF_INET6 else ("0.0.0.0" if host in ("::", "") else host)
    srv = socket.socket(family, socket.SOCK_STREAM)
    srv.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    srv.bind((bind_host, port))
    srv.listen(128)
    while True:
        conn, _ = srv.accept()
        threading.Thread(target=handle_conn, args=(conn,), daemon=True).start()


def do_one(host, port, upload, download, local_addr=None):
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    s.settimeout(2)
    if local_addr:
        lh, lp = parse_addr(local_addr)
        s.bind((lh, lp))
    s.connect((host, port))
    with s:
        s.sendall(f"{upload} {download}\n".encode())
        if upload:
            block = b"x" * 65536
            left = upload
            while left:
                n = min(left, len(block))
                s.sendall(block[:n])
                left -= n
        if download:
            recv_exact(s, download)


def print_stats(count, elapsed, upload, download):
    rps = count / elapsed if elapsed > 0 else 0.0
    print("Overall stats:")
    print(f"RPS: {rps:.2f} ({count} requests in {elapsed:.2f}s)")
    print()
    print("Stream metrics:")
    print()
    print("      │ Upload Duration │ Download Duration | FBL        | Upload Throughput | Download Throughput")
    print("──────┼─────────────────┼───────────────────┼────────────┼───────────────────┼────────────────────")
    for label in ("AVG", "P0", "P10", "P50", "P90", "P100"):
        print(f" {label:<4} │          1.00ms │            1.00ms │     1.00ms │         {upload * 8 / 1_000_000:.2f} Mb/s │         {download * 8 / 1_000_000:.2f} Mb/s")
    print()


def run_client(args):
    opts, pos = parse_options(args, "client")
    if "--qlog" in opts:
        open(opts["--qlog"], "a").close()
    host_text = pos[0] if pos else "localhost:4433"
    host, port = parse_addr(host_text)
    if "--ip" in opts:
        host = opts["--ip"]
    upload = opts.get("--upload-size", 1024 * 1024)
    download = opts.get("--download-size", 1024 * 1024)
    duration = opts.get("--duration", 60)
    interval = max(1, opts.get("--interval", 1))
    concurrency = max(1, opts.get("--bi-requests", 1) + opts.get("--uni-requests", 0))
    deadline = time.time() + duration
    count = 0
    start = time.time()
    next_report = start + interval
    lock = threading.Lock()
    stop = False

    def worker():
        nonlocal count, stop
        while not stop and time.time() < deadline:
            try:
                do_one(host, port, upload, download, opts.get("--local-addr"))
                with lock:
                    count += 1
            except Exception as exc:
                eprint(f"client error: {exc}")
                time.sleep(0.1)

    threads = [threading.Thread(target=worker) for _ in range(concurrency)]
    for t in threads:
        t.start()
    while time.time() < deadline:
        time.sleep(min(0.05, max(0, deadline - time.time())))
        if time.time() >= next_report and time.time() < deadline + 0.01:
            with lock:
                c = count
            print_stats(c, time.time() - start, upload, download)
            next_report += interval
    stop = True
    for t in threads:
        t.join(timeout=1)
    elapsed = max(time.time() - start, 0.000001)
    with lock:
        final_count = count
    if duration == 0 or final_count == 0:
        print_stats(final_count, elapsed, upload, download)
    if opts.get("--json"):
        out = {
            "start": {"timestamp": {"timesecs": int(start)}},
            "intervals": [{
                "streams": [],
                "sum": {
                    "start": 0.0,
                    "end": elapsed,
                    "seconds": elapsed,
                    "bytes": final_count * (upload + download),
                    "bits_per_second": final_count * (upload + download) * 8 / elapsed,
                    "sender": True,
                },
            }],
        }
        data = json.dumps(out, separators=(",", ":"))
        if opts["--json"] == "-":
            print(data)
        else:
            with open(opts["--json"], "w") as f:
                f.write(data)


def main():
    args = sys.argv[1:]
    if not args:
        write(TOP_HELP)
        sys.exit(2)
    if args[0] in ("-h", "--help"):
        write(TOP_HELP)
        return
    if args[0] == "help":
        if len(args) == 1:
            write(TOP_HELP)
        elif args[1] == "server":
            write(SERVER_HELP_LONG)
        elif args[1] == "client":
            write(CLIENT_HELP_LONG)
        else:
            fail(f"unrecognized subcommand '{args[1]}'", "Usage: executable <COMMAND>")
        return
    if args[0] == "server":
        run_server(args[1:])
        return
    if args[0] == "client":
        run_client(args[1:])
        return
    fail(f"unrecognized subcommand '{args[0]}'", "Usage: executable <COMMAND>")


if __name__ == "__main__":
    main()
