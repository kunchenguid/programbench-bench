#!/usr/bin/env python3
import csv
import json
import math
import os
import re
import sys
from collections import OrderedDict, defaultdict


VERSION = "6.16.0"


def usage():
    print("Usage: mlr [flags] {verb} [verb-dependent options ...] {zero or more file names}")
    print()
    print("If zero file names are provided, standard input is read, e.g.")
    print("  mlr --csv sort -f shape example.csv")
    print()
    print('Output of one verb may be chained as input to another using "then", e.g.')
    print("  mlr --csv stats1 -a min,mean,max -f quantity then sort -f color example.csv")
    print()
    print("Please see 'mlr help topics' for more information.")
    print("Please also see https://miller.readthedocs.io")


VERBS = """altkv
bar
bootstrap
case
cat
check
clean-whitespace
count-distinct
count
count-similar
cut
decimate
fill-down
fill-empty
filter
flatten
format-values
fraction
gap
grep
group-by
group-like
gsub
having-fields
head
histogram
json-parse
json-stringify
join
label
latin1-to-utf8
least-frequent
merge-fields
most-frequent
nest
nothing
put
regularize
remove-empty-columns
rename
reorder
repeat
reshape
sample
sec2gmtdate
sec2gmt
seqgen
shuffle
skip-trivial-records
sort
sort-within-records
sparsify
split
ssub
stats1
stats2
step
sub
summary
surv
tac
tail
tee
template
top
utf8-to-latin1
unflatten
uniq
unspace
unsparsify""".splitlines()


def help_topic(args):
    if not args or args[0] == "topics":
        print("Type 'mlr help {topic}' for any of the following:")
        print("Essentials:\n  mlr help topics\n  mlr help basic-examples\n  mlr help file-formats")
        print("Flags:\n  mlr help flags\n  mlr help flag")
        print("Verbs:\n  mlr help list-verbs\n  mlr help usage-verbs\n  mlr help verb")
        print("Functions:\n  mlr help list-functions\n  mlr help usage-functions")
        print("Keywords:\n  mlr help list-keywords\n  mlr help usage-keywords")
        return
    t = args[0]
    if t == "list-verbs":
        print("\n".join(VERBS))
    elif t == "basic-examples":
        print("mlr --icsv --opprint cat example.csv")
        print("mlr --icsv --opprint sort -f shape example.csv")
        print("mlr --icsv --opprint sort -f shape -nr index example.csv")
        print("mlr --icsv --opprint cut -f flag,shape example.csv")
        print('mlr --csv filter \'$color == "red"\' example.csv')
        print("mlr --icsv --ojson put '$ratio = $quantity / $rate' example.csv")
    elif t == "verb" and len(args) > 1:
        print(args[1])
        print(f"Usage: mlr {args[1]} [options]")
    elif t in ("flags", "flag"):
        print("FILE-FORMAT FLAGS")
        print("--csv --tsv --dkvp --json --jsonl --pprint --nidx")
        print("--i{format} and --o{format}, plus conversion shorthands such as --c2d.")
    else:
        print(f"No exact help available for {t}.")


def infer_value(s):
    if s is None:
        return ""
    if isinstance(s, (int, float, bool)) or s is None:
        return s
    if s == "":
        return ""
    if re.fullmatch(r"[-+]?\d+", s):
        try:
            return int(s)
        except Exception:
            return s
    if re.fullmatch(r"[-+]?(\d+\.\d*|\.\d+|\d+[eE][-+]?\d+|\d+\.\d*[eE][-+]?\d+|\.\d+[eE][-+]?\d+)", s):
        try:
            return float(s)
        except Exception:
            return s
    return s


def stringify(v):
    if v is None:
        return ""
    if isinstance(v, bool):
        return "true" if v else "false"
    if isinstance(v, float):
        if math.isfinite(v) and v.is_integer():
            return str(int(v))
        return format(v, ".12g")
    return str(v)


def flatten_obj(obj, prefix="", out=None):
    if out is None:
        out = OrderedDict()
    if isinstance(obj, dict):
        for k, v in obj.items():
            nk = str(k) if not prefix else prefix + "." + str(k)
            flatten_obj(v, nk, out)
    elif isinstance(obj, list):
        for i, v in enumerate(obj, 1):
            nk = str(i) if not prefix else prefix + "." + str(i)
            flatten_obj(v, nk, out)
    else:
        out[prefix] = obj
    return out


def parse_dkvp(text):
    rows = []
    for line in text.splitlines():
        if not line:
            continue
        rec = OrderedDict()
        for idx, part in enumerate(line.split(","), 1):
            if "=" in part:
                k, v = part.split("=", 1)
            else:
                k, v = str(idx), part
            rec[k] = v
        rows.append(rec)
    return rows


def parse_nidx(text, fs=None):
    rows = []
    for line in text.splitlines():
        if not line:
            continue
        parts = line.split(fs) if fs else line.split()
        rows.append(OrderedDict((str(i + 1), v) for i, v in enumerate(parts)))
    return rows


def parse_csvlike(text, delim=",", implicit=False):
    rows = []
    rdr = csv.reader(text.splitlines(), delimiter=delim)
    try:
        first = next(rdr)
    except StopIteration:
        return []
    if implicit:
        header = [str(i + 1) for i in range(len(first))]
        data = [first] + list(rdr)
    else:
        header = first
        data = list(rdr)
    for vals in data:
        rec = OrderedDict()
        for i, v in enumerate(vals):
            k = header[i] if i < len(header) else str(i + 1)
            rec[k] = v
        for k in header[len(vals):]:
            rec[k] = ""
        rows.append(rec)
    return rows


def parse_json_text(text, lines=False):
    rows = []
    if lines:
        objs = [json.loads(line) for line in text.splitlines() if line.strip()]
    else:
        obj = json.loads(text) if text.strip() else []
        objs = obj if isinstance(obj, list) else [obj]
    for obj in objs:
        if isinstance(obj, dict):
            rows.append(flatten_obj(obj))
        else:
            rows.append(OrderedDict([("value", obj)]))
    return rows


def parse_pprint(text):
    lines = [ln.rstrip("\n") for ln in text.splitlines() if ln.strip()]
    if not lines:
        return []
    header = re.split(r"\s+", lines[0].strip())
    rows = []
    for line in lines[1:]:
        vals = re.split(r"\s+", line.strip())
        rows.append(OrderedDict((h, vals[i] if i < len(vals) else "") for i, h in enumerate(header)))
    return rows


def read_all(files):
    if not files:
        return sys.stdin.read()
    chunks = []
    for f in files:
        with open(f, "r", encoding="utf-8", newline="") as fp:
            chunks.append(fp.read())
    return "\n".join(ch.rstrip("\n") for ch in chunks if ch is not None)


def all_keys(rows):
    keys = []
    seen = set()
    for r in rows:
        for k in r.keys():
            if k not in seen:
                seen.add(k)
                keys.append(k)
    return keys


def parse_records(text, fmt, implicit=False, fs=None):
    if fmt == "csv":
        return parse_csvlike(text, ",", implicit)
    if fmt == "tsv":
        return parse_csvlike(text, "\t", implicit)
    if fmt == "json":
        return parse_json_text(text, False)
    if fmt == "jsonl":
        return parse_json_text(text, True)
    if fmt == "nidx":
        return parse_nidx(text, fs)
    if fmt == "pprint":
        return parse_pprint(text)
    return parse_dkvp(text)


def emit_csv(rows, delim=",", headerless=False):
    if not rows:
        return ""
    keys = all_keys(rows)
    out = []
    sio = _CSVBuf(out)
    w = csv.writer(sio, delimiter=delim, lineterminator="\n")
    if not headerless:
        w.writerow(keys)
    for r in rows:
        w.writerow([stringify(r.get(k, "")) for k in keys])
    return "".join(out)


class _CSVBuf:
    def __init__(self, out):
        self.out = out
    def write(self, s):
        self.out.append(s)
        return len(s)


def emit_dkvp(rows):
    return "".join(",".join(f"{k}={stringify(v)}" for k, v in r.items()) + "\n" for r in rows)


def nest_record(rec):
    root = OrderedDict()
    for k, v in rec.items():
        parts = str(k).split(".")
        cur = root
        for p in parts[:-1]:
            cur = cur.setdefault(p, OrderedDict())
        cur[parts[-1]] = infer_value(v) if isinstance(v, str) else v
    return root


def normalize_json_numbers(obj):
    if isinstance(obj, dict):
        return OrderedDict((k, normalize_json_numbers(v)) for k, v in obj.items())
    if isinstance(obj, list):
        return [normalize_json_numbers(v) for v in obj]
    if isinstance(obj, float) and math.isfinite(obj) and obj.is_integer():
        return int(obj)
    return obj


def emit_json(rows, lines=False):
    objs = [normalize_json_numbers(nest_record(r)) for r in rows]
    if lines:
        return "".join(json.dumps(o) + "\n" for o in objs)
    if not objs:
        return "[]\n"
    return json.dumps(objs, indent=2) + "\n"


def emit_pprint(rows):
    if not rows:
        return ""
    keys = all_keys(rows)
    widths = {k: len(k) for k in keys}
    for r in rows:
        for k in keys:
            widths[k] = max(widths[k], len(stringify(r.get(k, ""))))
    lines = []
    lines.append(" ".join(k.ljust(widths[k]) for k in keys).rstrip())
    for r in rows:
        lines.append(" ".join(stringify(r.get(k, "")).ljust(widths[k]) for k in keys).rstrip())
    return "\n".join(lines) + "\n"


def emit_nidx(rows, delim=" "):
    return "".join(delim.join(stringify(v) for v in r.values()) + "\n" for r in rows)


def emit_records(rows, fmt, headerless=False):
    if fmt == "csv":
        return emit_csv(rows, ",", headerless)
    if fmt == "tsv":
        return emit_csv(rows, "\t", headerless)
    if fmt == "json":
        return emit_json(rows, False)
    if fmt == "jsonl":
        return emit_json(rows, True)
    if fmt == "pprint":
        return emit_pprint(rows)
    if fmt == "nidx":
        return emit_nidx(rows)
    return emit_dkvp(rows)


def split_csv_arg(s):
    return [x for x in s.split(",") if x != ""]


def verb_cut(rows, args):
    fields, ordered, complement = [], False, False
    i = 0
    while i < len(args):
        if args[i] == "-f" and i + 1 < len(args):
            fields += split_csv_arg(args[i + 1]); i += 2
        elif args[i] == "-o":
            ordered = True; i += 1
        elif args[i] in ("-x", "--complement"):
            complement = True; i += 1
        else:
            i += 1
    fset = set(fields)
    out = []
    for r in rows:
        nr = OrderedDict()
        if complement:
            for k, v in r.items():
                if k not in fset:
                    nr[k] = v
        elif ordered:
            for k in fields:
                if k in r:
                    nr[k] = r[k]
        else:
            for k, v in r.items():
                if k in fset:
                    nr[k] = v
        out.append(nr)
    return out


def sort_key_for(v, numeric=False, casefold=False, desc_numeric=False):
    if numeric:
        try:
            return (0, float(v))
        except Exception:
            return (1, 0.0)
    s = stringify(v)
    if casefold:
        s = s.casefold()
    return (0, s)


def verb_sort(rows, args):
    specs = []
    i = 0
    while i < len(args):
        flag = args[i]
        if flag in ("-f", "-r", "-c", "-cr", "-n", "-nf", "-nr", "-t", "-tr", "-rt") and i + 1 < len(args):
            for f in split_csv_arg(args[i + 1]):
                specs.append((f, flag))
            i += 2
        else:
            i += 1
    if not specs:
        return rows
    out = list(enumerate(rows))
    for field, flag in reversed(specs):
        numeric = flag in ("-n", "-nf", "-nr")
        reverse = flag in ("-r", "-cr", "-nr", "-tr", "-rt")
        casefold = flag in ("-c", "-cr")
        out.sort(key=lambda ir: sort_key_for(ir[1].get(field, ""), numeric, casefold), reverse=reverse)
    return [r for _, r in out]


def verb_head_tail(rows, args, tail=False):
    n = 10
    i = 0
    while i < len(args):
        if args[i] == "-n" and i + 1 < len(args):
            n = int(args[i + 1]); i += 2
        elif re.fullmatch(r"-\d+", args[i]):
            n = int(args[i][1:]); i += 1
        else:
            i += 1
    return rows[-n:] if tail else rows[:n]


def verb_count(rows, args):
    return [OrderedDict([("count", len(rows))])]


def translate_expr(expr, rec):
    def repl(m):
        name = m.group(1)
        return f"val(rec.get({name!r}, ''))"
    e = re.sub(r"\$([A-Za-z_][A-Za-z0-9_.]*)", repl, expr)
    e = e.replace("&&", " and ").replace("||", " or ")
    e = re.sub(r"(?<![=!<>])=(?!=)", "==", e)
    return e


def safe_eval(expr, rec):
    env = {"rec": rec, "val": infer_value, "int": int, "float": float, "str": str, "len": len, "math": math}
    return eval(translate_expr(expr, rec), {"__builtins__": {}}, env)


def verb_filter(rows, args):
    expr = " ".join(args)
    out = []
    for r in rows:
        try:
            if safe_eval(expr, r):
                out.append(r)
        except Exception:
            pass
    return out


def verb_put(rows, args):
    stmt = " ".join(args)
    m = re.match(r"\s*\$([A-Za-z_][A-Za-z0-9_.]*)\s*=\s*(.*)\s*$", stmt)
    if not m:
        return rows
    field, expr = m.group(1), m.group(2)
    out = []
    for r in rows:
        nr = OrderedDict(r)
        try:
            nr[field] = safe_eval(expr, nr)
        except Exception:
            nr[field] = ""
        out.append(nr)
    return out


def verb_rename(rows, args):
    mapping = OrderedDict()
    i = 0
    while i < len(args):
        if args[i] == "-f" and i + 1 < len(args):
            for pair in split_csv_arg(args[i + 1]):
                if "," in pair:
                    pass
            vals = split_csv_arg(args[i + 1])
            for j in range(0, len(vals) - 1, 2):
                mapping[vals[j]] = vals[j + 1]
            i += 2
        else:
            i += 1
    return [OrderedDict((mapping.get(k, k), v) for k, v in r.items()) for r in rows]


def numeric_values(rows, field):
    vals = []
    for r in rows:
        if field in r and r[field] != "":
            try:
                vals.append(float(r[field]))
            except Exception:
                pass
    return vals


def verb_stats1(rows, args):
    accs, fields, groups = [], [], []
    i = 0
    while i < len(args):
        if args[i] == "-a" and i + 1 < len(args):
            accs = split_csv_arg(args[i + 1]); i += 2
        elif args[i] == "-f" and i + 1 < len(args):
            fields = split_csv_arg(args[i + 1]); i += 2
        elif args[i] == "-g" and i + 1 < len(args):
            groups = split_csv_arg(args[i + 1]); i += 2
        else:
            i += 1
    if not accs:
        accs = ["count"]
    if not fields:
        fields = [k for k in all_keys(rows) if k not in groups]
    buckets = OrderedDict()
    for r in rows:
        key = tuple(r.get(g, "") for g in groups)
        buckets.setdefault(key, []).append(r)
    out = []
    for key, bucket in buckets.items():
        rec = OrderedDict((g, key[i]) for i, g in enumerate(groups))
        for f in fields:
            vals_text = [r.get(f, "") for r in bucket if f in r]
            nums = numeric_values(bucket, f)
            for a in accs:
                name = f"{f}_{a}"
                if a == "count":
                    rec[name] = len(vals_text)
                elif a == "sum":
                    rec[name] = sum(nums)
                elif a == "mean":
                    rec[name] = sum(nums) / len(nums) if nums else ""
                elif a == "min":
                    rec[name] = min(nums) if nums else (min(vals_text) if vals_text else "")
                elif a == "max":
                    rec[name] = max(nums) if nums else (max(vals_text) if vals_text else "")
                elif a in ("median", "p50"):
                    sn = sorted(nums)
                    rec[name] = sn[(len(sn) - 1) // 2] if sn else ""
                elif a == "distinct_count":
                    rec[name] = len(set(map(stringify, vals_text)))
                else:
                    rec[name] = ""
        out.append(rec)
    return out


def verb_uniq(rows, args):
    seen, out = set(), []
    for r in rows:
        key = tuple(r.items())
        if key not in seen:
            seen.add(key); out.append(r)
    return out


def verb_label(rows, args):
    labels = split_csv_arg(args[0]) if args else []
    out = []
    for r in rows:
        vals = list(r.values())
        nr = OrderedDict()
        for i, v in enumerate(vals):
            nr[labels[i] if i < len(labels) else str(i + 1)] = v
        out.append(nr)
    return out


def apply_verb(rows, verb, args):
    if verb in ("cat", "check"):
        return rows
    if verb == "nothing":
        return []
    if verb == "cut":
        return verb_cut(rows, args)
    if verb == "sort":
        return verb_sort(rows, args)
    if verb == "head":
        return verb_head_tail(rows, args, False)
    if verb == "tail":
        return verb_head_tail(rows, args, True)
    if verb == "tac":
        return list(reversed(rows))
    if verb == "count":
        return verb_count(rows, args)
    if verb == "filter":
        return verb_filter(rows, args)
    if verb == "put":
        return verb_put(rows, args)
    if verb == "stats1":
        return verb_stats1(rows, args)
    if verb == "uniq":
        return verb_uniq(rows, args)
    if verb == "label":
        return verb_label(rows, args)
    if verb == "rename":
        return verb_rename(rows, args)
    return rows


def fmt_from_name(name):
    aliases = {
        "c": "csv", "csv": "csv", "tsv": "tsv", "t": "tsv",
        "d": "dkvp", "dkvp": "dkvp", "json": "json", "j": "json",
        "jsonl": "jsonl", "l": "jsonl", "pprint": "pprint", "p": "pprint",
        "nidx": "nidx", "n": "nidx",
    }
    return aliases.get(name, name)


def parse_cli(argv):
    if not argv or argv[0] in ("--help", "-h"):
        usage(); sys.exit(0)
    if argv[0] == "--version":
        print(f"mlr {VERSION}"); sys.exit(0)
    if argv[0] == "version":
        print(f"mlr version {VERSION} for linux/amd64/go1.24.0"); sys.exit(0)
    if argv[0] == "help":
        help_topic(argv[1:]); sys.exit(0)
    if argv[0] in ("-l", "--list-verbs"):
        print("\n".join(VERBS)); sys.exit(0)

    ifmt, ofmt = "dkvp", "dkvp"
    implicit = False
    headerless_out = False
    fs = None
    from_files = []
    i = 0
    while i < len(argv):
        a = argv[i]
        if not a.startswith("-") or a == "--":
            break
        if a in ("--csv", "-c", "--c2c"):
            ifmt = ofmt = "csv"; i += 1
        elif a in ("--tsv", "-t", "--t2t"):
            ifmt = ofmt = "tsv"; i += 1
        elif a in ("--dkvp", "--d2d"):
            ifmt = ofmt = "dkvp"; i += 1
        elif a in ("--json", "-j", "--j2j"):
            ifmt = ofmt = "json"; i += 1
        elif a in ("--jsonl", "--l2l"):
            ifmt = ofmt = "jsonl"; i += 1
        elif a in ("--pprint", "--p2p"):
            ifmt = ofmt = "pprint"; i += 1
        elif a in ("--nidx", "--n2n"):
            ifmt = ofmt = "nidx"; i += 1
        elif re.fullmatch(r"--[cdjlntp]2[cdjlntp]", a):
            mp = {"c": "csv", "d": "dkvp", "j": "json", "l": "jsonl", "n": "nidx", "t": "tsv", "p": "pprint"}
            ifmt, ofmt = mp[a[2]], mp[a[4]]; i += 1
        elif a.startswith("--i") and len(a) > 3:
            ifmt = fmt_from_name(a[3:]); i += 1
        elif a.startswith("--o") and len(a) > 3:
            ofmt = fmt_from_name(a[3:]); i += 1
        elif a == "-i" and i + 1 < len(argv):
            ifmt = fmt_from_name(argv[i + 1]); i += 2
        elif a == "-o" and i + 1 < len(argv):
            ofmt = fmt_from_name(argv[i + 1]); i += 2
        elif a in ("--implicit-csv-header", "--headerless-csv-input", "--hi", "-N"):
            implicit = True
            if a == "-N":
                headerless_out = True
            i += 1
        elif a in ("--headerless-csv-output", "--ho"):
            headerless_out = True; i += 1
        elif a == "--from" and i + 1 < len(argv):
            from_files.append(argv[i + 1]); i += 2
        elif a == "--fs" and i + 1 < len(argv):
            fs = None if argv[i + 1] == "space" else ("\t" if argv[i + 1] == "tab" else argv[i + 1]); i += 2
        else:
            i += 1
    rest = argv[i:]
    if not rest:
        usage(); sys.exit(0)
    segments = []
    cur = []
    for x in rest:
        if x == "then":
            if cur:
                segments.append(cur); cur = []
        else:
            cur.append(x)
    if cur:
        segments.append(cur)
    known = set(VERBS)
    files = []
    clean_segments = []
    for si, seg in enumerate(segments):
        if not seg:
            continue
        verb = seg[0]
        args = seg[1:]
        if si == len(segments) - 1:
            cut = len(args)
            while cut > 0 and args[cut - 1] not in known and not args[cut - 1].startswith("-"):
                # A simple heuristic: trailing existing paths are data files.
                if os.path.exists(args[cut - 1]):
                    cut -= 1
                else:
                    break
            files = args[cut:] + files
            args = args[:cut]
        clean_segments.append((verb, args))
    return ifmt, ofmt, implicit, headerless_out, fs, from_files + files, clean_segments


def main(argv):
    ifmt, ofmt, implicit, headerless, fs, files, segments = parse_cli(argv)
    text = read_all(files)
    rows = parse_records(text, ifmt, implicit, fs)
    for verb, args in segments:
        if args and args[0] in ("-h", "--help"):
            help_topic(["verb", verb]); return 0
        rows = apply_verb(rows, verb, args)
    sys.stdout.write(emit_records(rows, ofmt, headerless))
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main(sys.argv[1:]))
    except BrokenPipeError:
        raise SystemExit(0)
    except Exception as e:
        print(f"mlr: {e}", file=sys.stderr)
        raise SystemExit(1)
