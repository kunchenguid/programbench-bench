#!/usr/bin/env python3
import json
import signal
import subprocess
import sys
import urllib.parse

USAGE = "Usage: ./executable [options...] [METHOD] URL [REQUEST_ITEM [REQUEST_ITEM ...]]"
METHODS = {"GET", "POST", "PUT", "PATCH", "DELETE", "HEAD", "OPTIONS", "TRACE", "CONNECT"}
signal.signal(signal.SIGPIPE, signal.SIG_DFL)

OPTS_WITH_VALUE = {
    "-o", "--output", "-u", "--user", "-H", "--header", "-A", "--user-agent", "-e", "--referer",
    "-b", "--cookie", "-c", "--cookie-jar", "-d", "--data", "--data-raw", "--data-binary",
    "--data-ascii", "--data-urlencode", "-X", "--request", "-F", "--form", "--form-string",
    "--connect-timeout", "-m", "--max-time", "--proxy", "-x", "--proxy-user", "-U", "--url",
    "--cacert", "--capath", "-E", "--cert", "--cert-type", "--key", "--key-type", "--pass",
    "--resolve", "--connect-to", "--retry", "--retry-delay", "--retry-max-time", "--limit-rate",
    "-K", "--config", "-D", "--dump-header", "--libcurl", "--stderr", "--trace", "--trace-ascii",
    "--interface", "--noproxy", "--socks4", "--socks4a", "--socks5", "--socks5-hostname",
    "--oauth2-bearer", "--aws-sigv4", "--request-target", "--output-dir", "--proto",
    "--proto-default", "--proto-redir", "--max-redirs", "--range", "-r", "--time-cond", "-z",
    "--upload-file", "-T", "--ftp-port", "-P", "--quote", "-Q", "--telnet-option", "-t",
    "--mail-from", "--mail-rcpt", "--mail-auth", "--login-options", "--service-name",
    "--proxy-service-name", "--local-port", "--speed-limit", "-Y", "--speed-time", "-y",
    "--hsts", "--alt-svc", "--etag-save", "--etag-compare", "--unix-socket", "--abstract-unix-socket",
    "--dns-interface", "--dns-ipv4-addr", "--dns-ipv6-addr", "--dns-servers", "--doh-url",
    "--curves", "--ciphers", "--tls13-ciphers", "--tls-max", "--proxy-header", "--proxy-cacert",
    "--proxy-capath", "--proxy-cert", "--proxy-cert-type", "--proxy-key", "--proxy-key-type",
    "--proxy-pass", "--proxy-ciphers", "--proxy-crlfile", "--proxy-tls13-ciphers", "--proxy-tlsuser",
    "--proxy-tlspassword", "--proxy-tlsauthtype", "--preproxy", "--happy-eyeballs-timeout-ms",
    "--expect100-timeout", "--create-file-mode", "--tftp-blksize", "--hostpubmd5", "--hostpubsha256",
    "--pinnedpubkey", "--proxy-pinnedpubkey", "--pubkey", "--krb", "--delegation", "--ftp-account",
    "--ftp-alternative-to-user", "--ftp-method", "--ftp-ssl-ccc-mode", "--netrc-file",
    "--parallel-max", "--random-file", "--egd-file", "--engine", "--crlfile", "-C", "--continue-at",
}


def shell_join(args):
    out = []
    for arg in args:
        if any(ch.isspace() for ch in arg):
            out.append('"' + arg.replace('"', '\\"') + '"')
        else:
            out.append(arg)
    return " ".join(out)


def add_scheme_for_notice(url):
    if url.startswith("http://") or url.startswith("https://"):
        return url
    return "http://" + url


def append_query(url, pairs):
    if not pairs:
        return url
    query = "&".join(urllib.parse.quote_plus(k) + "=" + urllib.parse.quote_plus(v) for k, v in pairs)
    return url + ("&" if "?" in url else "?") + query


def parse_json_value(value):
    try:
        return json.loads(value)
    except Exception:
        return None


def compact_json(obj):
    return json.dumps(obj, separators=(",", ":"), ensure_ascii=False)


def curl_help(args):
    print(USAGE)
    try:
        result = subprocess.run(["curl", "--help"] + args, text=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    except FileNotFoundError:
        return 0
    lines = result.stdout.splitlines()
    if lines and lines[0].startswith("Usage: curl "):
        lines = lines[1:]
    if lines:
        print("\n".join(lines))
    return result.returncode


def main(argv):
    if not argv:
        return curl_help(["all"])
    if argv[0] in ("--version", "-V"):
        return subprocess.call(["curl", "--version"])
    if argv[0] in ("--manual", "-M"):
        return subprocess.call(["curl", "--manual"])
    if argv[0] in ("--help", "-h"):
        return curl_help(argv[1:] if len(argv) > 1 else ["invalid"])

    show_curl = False
    pretty = False
    form_mode = False
    curl_opts = []
    method = None
    url = None
    items = []

    i = 0
    while i < len(argv):
        arg = argv[i]
        if arg == "--curl":
            show_curl = True
            i += 1
            continue
        if arg == "--pretty":
            pretty = True
            i += 1
            continue
        if arg == "--form":
            form_mode = True
            i += 1
            continue
        if url is None and arg.startswith("-"):
            if arg.startswith("--") and "=" in arg:
                opt, value = arg.split("=", 1)
                if opt in OPTS_WITH_VALUE:
                    curl_opts.extend([opt, value])
                else:
                    curl_opts.append(arg)
                i += 1
                continue
            curl_opts.append(arg)
            if arg in OPTS_WITH_VALUE and i + 1 < len(argv):
                i += 1
                curl_opts.append(argv[i])
            i += 1
            continue
        if url is None and method is None and arg.upper() in METHODS and i + 1 < len(argv):
            method = arg.upper()
            i += 1
            continue
        if url is None:
            url = arg
            i += 1
            continue
        items.append(arg)
        i += 1

    if url is None:
        return subprocess.call(["curl"])

    headers = []
    query = []
    data = {}
    form = []
    passthru_items = []

    for item in items:
        if "==" in item and not item.startswith("=="):
            key, value = item.split("==", 1)
            query.append((key, value))
        elif ":=" in item and not item.startswith(":="):
            key, value = item.split(":=", 1)
            data[key] = parse_json_value(value)
        elif ":" in item and "=" not in item.split(":", 1)[0]:
            headers.extend(["-H", item])
        elif "=" in item and not item.startswith("="):
            key, value = item.split("=", 1)
            if form_mode:
                form.extend(["-F", item])
            else:
                data[key] = value
        else:
            passthru_items.append(item)

    final_url = append_query(url, query)
    print(add_scheme_for_notice(final_url), file=sys.stderr)

    cmd = ["curl"]
    cmd.extend(curl_opts)
    if method:
        cmd.extend(["-X", method])
    cmd.extend(headers)
    if form:
        cmd.extend(form)
    elif data:
        cmd.extend(["-d", compact_json(data)])
    cmd.extend(passthru_items)
    cmd.append(final_url)
    cmd.extend(["-s", "-S"])
    if pretty:
        cmd.append("-v")
    if form_mode:
        cmd.extend(["-d@-", "-H", "Accept: application/json, */*"])
    else:
        if not data:
            cmd.append("-d@-")
        cmd.extend(["-H", "Content-Type: application/json", "-H", "Accept: application/json, */*"])

    if show_curl:
        print(shell_join(cmd))
        return 0
    return subprocess.call(cmd)


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
