#!/usr/bin/env python3
import os
import shlex
import subprocess
import sys
import tempfile

VERSION = "0.9.28rc"

HELP = """Tiny C Compiler 0.9.28rc - Copyright (C) 2001-2006 Fabrice Bellard
Usage: tcc [options...] [-o outfile] [-c] infile(s)...
       tcc [options...] -run infile (or --) [arguments...]
General options:
  -c           compile only - generate an object file
  -o outfile   set output filename
  -run         run compiled source [with custom stdin: -rstdin FILE]
  -fflag       set or reset (with 'no-' prefix) 'flag' (see tcc -hh)
  -Wwarning    set or reset (with 'no-' prefix) 'warning' (see tcc -hh)
  -w           disable all warnings
  -v --version show version
  -vv          show search paths or loaded files
  -h -hh       show this, show more help
  -bench       show compilation statistics
  -            use stdin pipe as infile
  @listfile    read arguments from listfile
Preprocessor options:
  -Idir        add include path 'dir'
  -Dsym[=val]  define 'sym' with value 'val'
  -Usym        undefine 'sym'
  -E           preprocess only
  -nostdinc    do not use standard system include paths
Linker options:
  -Ldir        add library path 'dir'
  -llib        link with dynamic or static library 'lib'
  -nostdlib    do not link with standard crt and libraries
  -r           generate (relocatable) object file
  -rdynamic    export all global symbols to dynamic linker
  -shared      generate a shared library/dll
  -soname      set name for shared library to be used at runtime
  -Wl,-opt[=val]  set linker option (see tcc -hh)
Debugger options:
  -g           generate stab runtime debug info
  -gdwarf[-x]  generate dwarf runtime debug info
  -b           compile with built-in memory and bounds checker (implies -g)
  -bt[N]       link with backtrace (stack dump) support [show max N callers]
Misc. options:
  -std=version define __STDC_VERSION__ according to version (c11/gnu11)
  -x[c|a|b|n]  specify type of the next infile (C,ASM,BIN,NONE)
  -Bdir        set tcc's private include/library dir
  -M[M]D       generate make dependency file [ignore system files]
  -M[M]        as above but no other output
  -MF file     specify dependency file name
  -m32/64      defer to i386/x86_64 cross compiler
Tools:
  create library  : tcc -ar [crstvx] lib [files]
Discussion & bug reports:
  https://lists.nongnu.org/mailman/listinfo/tinycc-devel
"""

MORE_HELP = """Tiny C Compiler 0.9.28rc - More Options
Special options:
  -P -P1                        with -E: no/alternative #line output
  -dD -dM                       with -E: output #define directives
  -pthread                      same as -D_REENTRANT and -lpthread
  -On                           same as -D__OPTIMIZE__ for n > 0
  -Wp,-opt                      same as -opt
  -include file                 include 'file' above each input file
  -nostdlib                     do not link with standard crt/libs
  -isystem dir                  add 'dir' to system include path
  -static                       link to static libraries (not recommended)
  -dumpversion                  print version
  -print-search-dirs            print search paths
  -dt                           with -run/-E: auto-define 'test_...' macros
Ignored options:
  -arch -C --param -pedantic -pipe -s -traditional
-W[no-]... warnings:
  all                           turn on some (*) warnings
  error[=warning]               stop after warning (any or specified)
  write-strings                 strings are const
  unsupported                   warn about ignored options, pragmas, etc.
  implicit-function-declaration warn for missing prototype (*)
  discarded-qualifiers          warn when const is dropped (*)
-f[no-]... flags:
  unsigned-char                 default char is unsigned
  signed-char                   default char is signed
  common                        use common section instead of bss
  leading-underscore            decorate extern symbols
  ms-extensions                 allow anonymous struct in struct
  dollars-in-identifiers        allow '$' in C symbols
  reverse-funcargs              evaluate function arguments right to left
  gnu89-inline                  'extern inline' is like 'static inline'
  asynchronous-unwind-tables    create eh_frame section [on]
  test-coverage                 create code coverage code
-m... target specific options:
  ms-bitfields                  use MSVC bitfield layout
  no-sse                        disable floats on x86_64
-Wl,... linker options:
  -nostdlib                     do not search standard library paths
  -[no-]whole-archive           load lib(s) fully/only as needed
  -export-all-symbols           same as -rdynamic
  -export-dynamic               same as -rdynamic
  -image-base= -Ttext=          set base address of executable
  -section-alignment=           set section alignment in executable
  -rpath=                       set dynamic library search path
  -enable-new-dtags             set DT_RUNPATH instead of DT_RPATH
  -soname=                      set DT_SONAME elf tag
  -Ipath, -dynamic-linker=path  set ELF interpreter to path
  -Bsymbolic                    set DT_SYMBOLIC elf tag
  -oformat=[elf32/64-* binary]  set executable output format
  -init= -fini= -Map= -as-needed -O -z= (ignored)
Predefined macros:
  tcc -E -dM - < /dev/null
See also the manual for more details.
"""

SEARCH_DIRS = """install: /usr/local/lib/tcc
include:
  /usr/local/lib/tcc/include
  /usr/local/include/x86_64-linux-gnu
  /usr/local/include
  /usr/include/x86_64-linux-gnu
  /usr/include
libraries:
  /usr/local/lib/tcc
  /usr/lib/x86_64-linux-gnu
  /usr/lib
  /lib/x86_64-linux-gnu
  /lib
  /usr/local/lib/x86_64-linux-gnu
  /usr/local/lib
libtcc1:
  /usr/local/lib/tcc/libtcc1.a
crt:
  /usr/lib/x86_64-linux-gnu
elfinterp:
  /lib64/ld-linux-x86-64.so.2
"""


def eprint(msg):
    print(msg, file=sys.stderr)


def expand_at(args):
    out = []
    for a in args:
        if a.startswith('@') and len(a) > 1:
            try:
                with open(a[1:], 'r') as f:
                    out.extend(shlex.split(f.read(), comments=True))
            except OSError as ex:
                eprint(f"tcc: error: could not read '{a[1:]}': {ex.strerror}")
                sys.exit(1)
        else:
            out.append(a)
    return out


def run_cmd(cmd, stdin_file=None):
    try:
        if stdin_file:
            with open(stdin_file, 'rb') as f:
                return subprocess.call(cmd, stdin=f)
        return subprocess.call(cmd)
    except FileNotFoundError:
        eprint(f"tcc: error: required tool not found: {cmd[0]}")
        return 1


def translate_args(args, output_override=None, for_run=False):
    out = ['-D__TINYC__=928']
    if '-shared' in args:
        out.append('-fPIC')
    skip = 0
    saw_output = False
    i = 0
    while i < len(args):
        a = args[i]
        if skip:
            skip -= 1
            i += 1
            continue
        if a == '-bench' or a == '-dt':
            i += 1
            continue
        if a == '-b' or a.startswith('-bt'):
            out.append('-g')
            i += 1
            continue
        if a.startswith('-gdwarf'):
            out.append('-g')
            i += 1
            continue
        if a == '-soname':
            if i + 1 >= len(args):
                eprint("tcc: error: argument to '-soname' is missing")
                sys.exit(1)
            out.append('-Wl,-soname,' + args[i+1])
            i += 2
            continue
        if a == '-Bdir':
            i += 1
            continue
        if a == '-B':
            i += 2
            continue
        if a in ('-arch', '--param'):
            i += 2
            continue
        if a in ('-C', '-traditional'):
            i += 1
            continue
        if a == '-P1':
            out.append('-P')
            i += 1
            continue
        if a == '-pthread':
            out.extend(['-D_REENTRANT', '-pthread'])
            i += 1
            continue
        if a == '-Wall':
            out.append('-Wall')
            i += 1
            continue
        if a == '-w':
            out.append('-w')
            i += 1
            continue
        if a.startswith('-Wno-'):
            warn = a[5:]
            if warn in ('unsupported', 'error'):
                i += 1
                continue
            out.append(a)
            i += 1
            continue
        if a.startswith('-Werror='):
            warn = a.split('=', 1)[1]
            if warn == 'unsupported':
                out.append('-Werror')
            else:
                out.append(a)
            i += 1
            continue
        if a in ('-Wunsupported', '-Werror-unsupported'):
            i += 1
            continue
        if a.startswith('-Wp,'):
            out.extend([x for x in a[4:].split(',') if x])
            i += 1
            continue
        if a.startswith('-Wl,-soname='):
            out.append('-Wl,-soname,' + a.split('=',1)[1])
            i += 1
            continue
        if a == '-o':
            saw_output = True
            if output_override is not None:
                i += 2
                continue
            out.extend(args[i:i+2])
            i += 2
            continue
        if a.startswith('-o') and len(a) > 2:
            saw_output = True
            if output_override is not None:
                i += 1
                continue
            out.append(a)
            i += 1
            continue
        if a == '-run' or a == '-rstdin':
            i += 1
            continue
        if a == '-':
            out.extend(['-x', 'c', '-', '-x', 'none'])
            i += 1
            continue
        if a.startswith('-fno-'):
            flag = a[5:]
            if flag in ('common','unsigned-char','signed-char','gnu89-inline','ms-extensions','dollars-in-identifiers','asynchronous-unwind-tables'):
                out.append(a)
            i += 1
            continue
        if a.startswith('-f'):
            flag = a[2:]
            if flag in ('common','unsigned-char','signed-char','gnu89-inline','ms-extensions','dollars-in-identifiers','asynchronous-unwind-tables'):
                out.append(a)
            elif flag == 'leading-underscore':
                out.append('-fleading-underscore')
            i += 1
            continue
        if a == '-mno-sse':
            out.append(a)
            i += 1
            continue
        if a == '-mms-bitfields':
            out.append(a)
            i += 1
            continue
        if a == '-x' and i + 1 < len(args):
            m = {'c':'c','a':'assembler','n':'none','b':'binary'}.get(args[i+1], args[i+1])
            out.extend(['-x', m])
            i += 2
            continue
        if a.startswith('-x') and len(a) > 2:
            m = {'c':'c','a':'assembler','n':'none','b':'binary'}.get(a[2:], a[2:])
            out.extend(['-x', m])
            i += 1
            continue
        out.append(a)
        i += 1
    if output_override is not None:
        out.extend(['-o', output_override])
    return out


def find_run(args):
    try:
        idx = args.index('-run')
    except ValueError:
        return None
    before = args[:idx]
    rest = args[idx+1:]
    if not rest:
        eprint("tcc: error: file '-run' not found")
        sys.exit(1)
    stdin_file = None
    if rest and rest[0] == '--':
        rest = rest[1:]
    if not rest:
        source = '-'
        prog_args = []
    else:
        source = rest[0]
        prog_args = rest[1:]
    cleaned_prog_args = []
    i = 0
    while i < len(prog_args):
        if prog_args[i] == '-rstdin' and i + 1 < len(prog_args):
            stdin_file = prog_args[i+1]
            i += 2
        else:
            cleaned_prog_args.append(prog_args[i])
            i += 1
    return before, source, cleaned_prog_args, stdin_file


def main():
    args = expand_at(sys.argv[1:])
    if not args or args[0] in ('-h', '--help'):
        sys.stdout.write(HELP)
        return 0
    if args[0] == '-hh':
        sys.stdout.write(MORE_HELP)
        return 0
    if args == ['-dumpversion']:
        print(VERSION)
        return 0
    if args == ['-print-search-dirs']:
        sys.stdout.write(SEARCH_DIRS)
        return 0
    if args == ['-v'] or args == ['--version']:
        print("tcc version 0.9.28rc 2026-04-21 build@237d0db* (x86_64 Linux)")
        return 0
    if args == ['-vv']:
        sys.stdout.write(SEARCH_DIRS)
        return 0
    if args and args[0] == '-ar':
        if len(args) == 1:
            sys.stdout.write(HELP)
            return 0
        return run_cmd(['ar'] + args[1:])
    for a in args:
        if a == '-no-such-option' or (a.startswith('--') and a not in ('--version',)):
            eprint(f"tcc: error: invalid option -- '{a}'")
            return 1
    run_spec = find_run(args)
    if run_spec:
        before, source, prog_args, stdin_file = run_spec
        with tempfile.TemporaryDirectory(prefix='tccrun-') as td:
            exe = os.path.join(td, 'a.out')
            src_to_use = source
            if source == '-':
                src_to_use = os.path.join(td, 'stdin.c')
                with open(src_to_use, 'wb') as f:
                    f.write(sys.stdin.buffer.read())
            cmd = ['gcc'] + translate_args(before + [src_to_use], output_override=exe, for_run=True)
            rc = run_cmd(cmd)
            if rc != 0:
                return rc
            return run_cmd([exe] + prog_args, stdin_file=stdin_file)
    cmd = ['gcc'] + translate_args(args)
    return run_cmd(cmd)

if __name__ == '__main__':
    sys.exit(main())
