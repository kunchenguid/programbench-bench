#!/usr/bin/env python3
import sys, gzip, math, statistics, random, signal
from collections import defaultdict, Counter
signal.signal(signal.SIGPIPE, signal.SIG_DFL)

VERSION="bedtools b2e3657"
HELP="""bedtools is a powerful toolset for genome arithmetic.

Version:   b2e3657
About:     developed in the quinlanlab.org and by many contributors worldwide.

Usage:     bedtools <subcommand> [options]

The bedtools sub-commands include:
    intersect     Find overlapping intervals in various ways.
    closest       Find the closest, potentially non-overlapping interval.
    coverage      Compute the coverage over defined intervals.
    genomecov     Compute the coverage over an entire genome.
    merge         Combine overlapping/nearby intervals into a single interval.
    complement    Extract intervals _not_ represented by an interval file.
    subtract      Remove intervals based on overlaps b/w two files.
    slop          Adjust the size of intervals.
    flank         Create new intervals from the flanks of existing intervals.
    sort          Order the intervals in a file.
    makewindows   Make interval "windows" across a genome.
    groupby       Group by common cols. & summarize oth. cols.
    jaccard       Calculate the Jaccard statistic b/w two sets of intervals.

    --help        Print this help menu.
    --version     What version of bedtools are you using?.
"""

class Rec:
    __slots__=("f","chrom","start","end","idx")
    def __init__(self, f, idx=0):
        self.f=f; self.chrom=f[0]; self.start=int(f[1]); self.end=int(f[2]); self.idx=idx
    def line(self): return "\t".join(self.f)
    def length(self): return max(0,self.end-self.start)

def die(msg, code=1):
    sys.stderr.write(str(msg).rstrip()+"\n"); sys.exit(code)

def val(args, *names, default=None):
    for n in names:
        if n in args:
            i=args.index(n)
            if i+1>=len(args): die(f"***** ERROR: {n} requires a value. *****")
            return args[i+1]
    return default

def has(args,*names): return any(n in args for n in names)

def values_after(args, name):
    if name not in args: return []
    i=args.index(name)+1; out=[]
    while i<len(args) and not args[i].startswith("-"):
        out.append(args[i]); i+=1
    return out

def opener(path):
    if path in ("-","stdin",None): return sys.stdin
    return gzip.open(path,"rt") if path.endswith(".gz") else open(path)

def raw_lines(path):
    with opener(path) as fh:
        for line in fh:
            line=line.rstrip("\n\r")
            if not line: continue
            yield line

def read_recs(path, keep_headers=False):
    recs=[]; headers=[]
    for line in raw_lines(path):
        if line.startswith(("#","track","browser")):
            headers.append(line); continue
        fs=line.split("\t") if "\t" in line else line.split()
        if len(fs)<3: continue
        try: recs.append(Rec(fs, len(recs)))
        except ValueError: headers.append(line)
    return (headers,recs) if keep_headers else recs

def read_genome(path):
    g=[]; d={}
    for line in raw_lines(path):
        if line.startswith("#"): continue
        fs=line.split()
        if len(fs)>=2:
            d[fs[0]]=int(fs[1]); g.append((fs[0],int(fs[1])))
    return g,d

def bychrom(recs):
    d=defaultdict(list)
    for r in recs: d[r.chrom].append(r)
    return d

def ov(a,b):
    if a.chrom!=b.chrom: return 0
    return max(0, min(a.end,b.end)-max(a.start,b.start))

def strand_ok(a,b,args):
    if not (has(args,"-s") or has(args,"-S")): return True
    if len(a.f)<6 or len(b.f)<6: return False
    same=a.f[5]==b.f[5]
    return same if has(args,"-s") else not same

def pass_frac(a,b,o,args):
    if o<=0 or not strand_ok(a,b,args): return False
    f=float(val(args,"-f",default="1e-9")); F=float(val(args,"-F",default="1e-9"))
    pa=o/max(1,a.length()); pb=o/max(1,b.length())
    if has(args,"-r"): return pa>=f and pb>=f
    if has(args,"-e"): return pa>=f or pb>=F
    return pa>=f and pb>=F

def fmt_num(x,prec=5):
    if isinstance(x,int) or abs(x-round(x))<1e-12: return str(int(round(x)))
    return (f"{x:.{prec}f}").rstrip("0").rstrip(".")

def op_apply(vals, op, delim=",", prec=5):
    nums=[]
    for v in vals:
        try: nums.append(float(v))
        except Exception: pass
    if op=="count": return str(len(vals))
    if op=="count_distinct": return str(len(set(vals)))
    if op=="collapse": return delim.join(vals)
    if op=="distinct": return delim.join(dict.fromkeys(vals))
    if op=="distinct_sort_num": return delim.join(str(x).rstrip("0").rstrip(".") if isinstance(x,float) else str(x) for x in sorted(set(nums)))
    if op=="distinct_sort_num_desc": return delim.join(str(x).rstrip("0").rstrip(".") if isinstance(x,float) else str(x) for x in sorted(set(nums), reverse=True))
    if op=="first": return vals[0] if vals else "."
    if op=="last": return vals[-1] if vals else "."
    if op=="concat": return "".join(vals)
    if not nums: return "."
    if op=="sum": return fmt_num(sum(nums),prec)
    if op=="min": return fmt_num(min(nums),prec)
    if op=="max": return fmt_num(max(nums),prec)
    if op=="absmin": return fmt_num(min(nums,key=abs),prec)
    if op=="absmax": return fmt_num(max(nums,key=abs),prec)
    if op=="mean": return fmt_num(sum(nums)/len(nums),prec)
    if op=="median": return fmt_num(statistics.median(nums),prec)
    if op in ("stdev","sstdev"): return fmt_num(statistics.stdev(nums) if len(nums)>1 else 0,prec)
    if op=="mode": return Counter(vals).most_common(1)[0][0]
    if op=="antimode":
        c=Counter(vals); m=min(c.values()); return [v for v in vals if c[v]==m][0]
    if op=="freqdesc" or op=="freqasc":
        items=Counter(vals).items()
        items=sorted(items,key=lambda kv:(kv[1],kv[0]), reverse=(op=="freqdesc"))
        return delim.join(f"{k}:{v}" for k,v in items)
    return "."

def expand_cols_ops(cols, ops):
    if len(cols)==1 and len(ops)>1: cols=cols*len(ops)
    if len(ops)==1 and len(cols)>1: ops=ops*len(cols)
    return cols,ops

def cmd_intersect(args):
    a_path=val(args,"-a"); b_paths=values_after(args,"-b")
    if not a_path or not b_paths: die("***** ERROR: -a and -b are required. *****")
    A=read_recs(a_path); Bs=[read_recs(p) for p in b_paths]; Bc=[bychrom(b) for b in Bs]
    names=values_after(args,"-names")
    null_b=["."]*3
    out=[]
    for a in A:
        hits=[]
        for bi,B in enumerate(Bc):
            for b in B.get(a.chrom,[]):
                o=ov(a,b)
                if pass_frac(a,b,o,args): hits.append((bi,b,o))
        if has(args,"-c"):
            out.append(a.f+[str(len(hits))]); continue
        if has(args,"-C"):
            for bi in range(len(Bs)):
                out.append(a.f+[str(bi+1),str(sum(1 for h in hits if h[0]==bi))])
            continue
        if has(args,"-v"):
            if not hits: out.append(a.f)
            continue
        if has(args,"-u"):
            if hits: out.append(a.f)
            continue
        if not hits:
            if has(args,"-wao"): out.append(a.f+null_b+["0"])
            elif has(args,"-loj"): out.append(a.f+null_b)
            continue
        for bi,b,o in hits:
            label=[]
            if len(Bs)>1 and (has(args,"-wb") or has(args,"-wa","-wo","-wao")):
                label=[names[bi] if bi<len(names) else str(bi+1)]
            if has(args,"-wo") or has(args,"-wao"):
                out.append(a.f+label+b.f+[str(o)])
            elif has(args,"-wa") and has(args,"-wb"):
                out.append(a.f+label+b.f)
            elif has(args,"-wa"):
                out.append(a.f)
            elif has(args,"-wb"):
                out.append(label+b.f)
            else:
                nf=a.f[:]; nf[1]=str(max(a.start,b.start)); nf[2]=str(min(a.end,b.end)); out.append(nf)
    sys.stdout.write("\n".join("\t".join(x) for x in out)+("\n" if out else ""))

def merged_intervals(recs, d=0):
    recs=sorted(recs,key=lambda r:(r.chrom,r.start,r.end))
    groups=[]
    for r in recs:
        cur_end=max((x.end for x in groups[-1]), default=-1) if groups else -1
        if not groups or r.chrom!=groups[-1][0].chrom or r.start>cur_end+d:
            groups.append([r])
        else:
            groups[-1].append(r)
    return groups

def cmd_merge(args):
    path=val(args,"-i"); recs=read_recs(path)
    d=int(val(args,"-d",default="0")); delim=val(args,"-delim",default=","); prec=int(val(args,"-prec",default="5"))
    cols=[int(x) for x in val(args,"-c",default="").split(",") if x] if val(args,"-c",default=None) else []
    ops=val(args,"-o",default="sum").split(",") if cols else []
    cols,ops=expand_cols_ops(cols,ops)
    rows=[]
    for g in merged_intervals(recs,d):
        chrom=g[0].chrom; start=min(r.start for r in g); end=max(r.end for r in g)
        row=[chrom,str(start),str(end)]
        for c,o in zip(cols,ops):
            row.append(op_apply([r.f[c-1] for r in g if len(r.f)>=c],o,delim,prec))
        rows.append(row)
    print_rows(rows)

def cmd_complement(args):
    recs=read_recs(val(args,"-i")); genome,gd=read_genome(val(args,"-g"))
    chroms=set(r.chrom for r in recs)
    rows=[]
    for chrom,size in genome:
        if has(args,"-L") and chrom not in chroms: continue
        cur=0
        ints=sorted([(r.start,r.end) for r in recs if r.chrom==chrom])
        for s,e in ints:
            if s>cur: rows.append([chrom,str(cur),str(s)])
            cur=max(cur,e)
        if cur<size: rows.append([chrom,str(cur),str(size)])
    print_rows(rows)

def coverage_segments(recs, size=None):
    ev=defaultdict(list)
    for r in recs:
        ev[r.chrom].append((r.start,1)); ev[r.chrom].append((r.end,-1))
    segs=defaultdict(list)
    for c,es in ev.items():
        es.sort(); depth=0; last=None
        for pos,delta in es:
            if last is not None and pos>last: segs[c].append((last,pos,depth))
            depth+=delta; last=pos
    return segs

def cmd_genomecov(args):
    recs=read_recs(val(args,"-i") or val(args,"-ibam")); genome,gd=read_genome(val(args,"-g")) if val(args,"-g") else ([],{})
    segs=coverage_segments(recs)
    scale=float(val(args,"-scale",default="1.0"))
    rows=[]
    if has(args,"-bg","-bga"):
        if has(args,"-trackline"): rows.append(["track"] + ([val(args,"-trackopts")] if val(args,"-trackopts",default=None) else []))
        for chrom,size in genome if genome else [(c,0) for c in sorted(segs)]:
            cur=0
            for s,e,d in segs.get(chrom,[]):
                if has(args,"-bga") and s>cur: rows.append([chrom,str(cur),str(s),"0"])
                if d>0: rows.append([chrom,str(s),str(e),fmt_num(d*scale)])
                cur=e
            if has(args,"-bga") and size and cur<size: rows.append([chrom,str(cur),str(size),"0"])
        print_rows(rows); return
    if has(args,"-d","-dz"):
        for chrom,size in genome:
            cov=[0]*size
            for r in recs:
                if r.chrom==chrom:
                    for i in range(max(0,r.start),min(size,r.end)): cov[i]+=1
            for i,d in enumerate(cov):
                if has(args,"-dz"):
                    if d: rows.append([chrom,str(i),fmt_num(d*scale)])
                else: rows.append([chrom,str(i+1),fmt_num(d*scale)])
        print_rows(rows); return
    total_gen=sum(s for _,s in genome) if genome else sum(r.length() for r in recs)
    total_counts=Counter()
    for chrom,size in genome:
        counts=Counter({0:size})
        for s,e,d in segs.get(chrom,[]):
            counts[0]-=(e-s); counts[d]+=(e-s)
        for dep,bases in sorted(counts.items()):
            if bases>0:
                rows.append([chrom,str(dep),str(bases),str(size),fmt_num(bases/size,6)])
                total_counts[dep]+=bases
    for dep,bases in sorted(total_counts.items()):
        rows.append(["genome",str(dep),str(bases),str(total_gen),fmt_num(bases/total_gen,6)])
    print_rows(rows)

def union_len(recs):
    total=0
    for g in merged_intervals([Rec(r.f[:]) for r in recs],0):
        total += max(r.end for r in g)-min(r.start for r in g)
    return total

def cmd_jaccard(args):
    A=read_recs(val(args,"-a")); B=read_recs(val(args,"-b")); Bc=bychrom(B)
    pieces=[]; n=0
    for a in A:
        for b in Bc.get(a.chrom,[]):
            o=ov(a,b)
            if pass_frac(a,b,o,args):
                pieces.append(Rec([a.chrom,str(max(a.start,b.start)),str(min(a.end,b.end))])); n+=1
    inter=union_len(pieces); uni=union_len(A)+union_len(B)-inter
    print("intersection\tunion-intersection\tjaccard\tn_intersections")
    print(f"{inter}\t{uni-inter}\t{fmt_num((inter/(uni-inter)) if (uni-inter) else 0,6)}\t{n}")

def dist(a,b):
    if a.chrom!=b.chrom: return 10**18
    if ov(a,b)>0: return 0
    if b.end<=a.start: return a.start-b.end+1
    return b.start-a.end+1

def cmd_closest(args):
    A=read_recs(val(args,"-a")); B=read_recs(val(args,"-b")); Bc=bychrom(B)
    addd=has(args,"-d") or "-D" in args; tie=val(args,"-t",default="all"); k=int(val(args,"-k",default="1"))
    rows=[]
    for a in A:
        cand=[b for b in Bc.get(a.chrom,[]) if strand_ok(a,b,args) and not (has(args,"-io") and ov(a,b)>0)]
        if not cand:
            row=a.f+[".","-1","-1"]
            if addd: row.append("-1")
            rows.append(row); continue
        cand.sort(key=lambda b:(dist(a,b),b.idx))
        chosen=[]; used=0; i=0
        while i<len(cand) and used<k:
            d=dist(a,cand[i]); ties=[x for x in cand if dist(a,x)==d]
            if tie=="first": ties=ties[:1]
            elif tie=="last": ties=ties[-1:]
            chosen.extend(ties); used+=1; i+=len(ties)
        for b in chosen:
            row=a.f+b.f
            if addd: row.append(str(dist(a,b)))
            rows.append(row)
    print_rows(rows)

def cmd_makewindows(args):
    intervals=[]
    if val(args,"-g",default=None):
        intervals=[(c,0,s,[c]) for c,s in read_genome(val(args,"-g"))[0]]
    else:
        intervals=[(r.chrom,r.start,r.end,r.f) for r in read_recs(val(args,"-b"))]
    w=val(args,"-w",default=None); n=val(args,"-n",default=None); step=int(val(args,"-s",default=w or "0"))
    idmode=val(args,"-i",default=None); rows=[]
    for chrom,start,end,src in intervals:
        wins=[]
        if w:
            ww=int(w); p=start
            while p<end:
                wins.append((p,min(end,p+ww))); p+=step or ww
        else:
            nn=int(n); size=end-start
            for i in range(nn):
                wins.append((start+(size*i)//nn, start+(size*(i+1))//nn))
        nums=list(range(1,len(wins)+1))
        if has(args,"-reverse"): nums=list(reversed(nums))
        for (s,e),num in zip(wins,nums):
            row=[chrom,str(s),str(e)]
            if idmode=="src": row.append(src[3] if len(src)>3 else chrom)
            elif idmode=="winnum": row.append(str(num))
            elif idmode=="srcwinnum": row.append((src[3] if len(src)>3 else chrom)+"_"+str(num))
            rows.append(row)
    print_rows(rows)

def cmd_slop(args, flank=False):
    recs=read_recs(val(args,"-i")); genome,gd=read_genome(val(args,"-g"))
    b=val(args,"-b",default=None); l=float(val(args,"-l",default=b or "0")); r=float(val(args,"-r",default=b or "0")); pct=has(args,"-pct")
    rows=[]
    for x in recs:
        ll=int(l*x.length()) if pct else int(l); rr=int(r*x.length()) if pct else int(r)
        if has(args,"-s") and len(x.f)>=6 and x.f[5]=="-": ll,rr=rr,ll
        size=gd.get(x.chrom, x.end)
        if flank:
            left=[x.chrom,str(max(0,x.start-ll)),str(x.start)]
            right=[x.chrom,str(x.end),str(min(size,x.end+rr))]
            if int(left[1])<int(left[2]): rows.append(left+x.f[3:])
            if int(right[1])<int(right[2]): rows.append(right+x.f[3:])
        else:
            nf=x.f[:]; nf[1]=str(max(0,x.start-ll)); nf[2]=str(min(size,x.end+rr)); rows.append(nf)
    print_rows(rows)

def cmd_subtract(args):
    A=read_recs(val(args,"-a")); Bc=bychrom(read_recs(val(args,"-b"))); rows=[]
    for a in A:
        intervals=[(a.start,a.end)]; anyhit=False
        for b in Bc.get(a.chrom,[]):
            o=ov(a,b)
            if not pass_frac(a,b,o,args): continue
            anyhit=True
            if has(args,"-A","-N"): intervals=[]; break
            new=[]
            for s,e in intervals:
                if b.end<=s or b.start>=e: new.append((s,e))
                else:
                    if s<max(s,b.start): new.append((s,max(s,b.start)))
                    if min(e,b.end)<e: new.append((min(e,b.end),e))
            intervals=new
        for s,e in intervals:
            if s<e:
                nf=a.f[:]; nf[1]=str(s); nf[2]=str(e); rows.append(nf)
    print_rows(rows)

def cmd_sort(args):
    headers,recs=read_recs(val(args,"-i") or "-", True)
    if has(args,"-header"):
        for h in headers: print(h)
    if val(args,"-g",default=None) or val(args,"-faidx",default=None):
        order={c:i for i,(c,_) in enumerate(read_genome(val(args,"-g",default=None) or val(args,"-faidx"))[0])}
        key=lambda r:(order.get(r.chrom,10**9),r.start,r.end)
    elif has(args,"-sizeD"): key=lambda r: (-(r.end-r.start),)
    elif has(args,"-sizeA"): key=lambda r: (r.end-r.start,)
    elif has(args,"-chrThenSizeD"): key=lambda r:(r.chrom,-(r.end-r.start))
    elif has(args,"-chrThenSizeA"): key=lambda r:(r.chrom,r.end-r.start)
    elif has(args,"-chrThenScoreD"): key=lambda r:(r.chrom,-float(r.f[4] if len(r.f)>4 else 0))
    elif has(args,"-chrThenScoreA"): key=lambda r:(r.chrom,float(r.f[4] if len(r.f)>4 else 0))
    else: key=lambda r:(r.chrom,r.start,r.end)
    print_rows([r.f for r in sorted(recs,key=key)])

def cmd_groupby(args):
    path=val(args,"-i",default="-"); lines=[l.split("\t") if "\t" in l else l.split() for l in raw_lines(path)]
    if has(args,"-inheader","-header") and lines: header=lines.pop(0)
    groups=[int(x) for x in val(args,"-g","-grp",default="1,2,3").split(",")]
    cols=[int(x) for x in val(args,"-c","-opCols").split(",")]
    ops=val(args,"-o","-ops",default="sum").split(","); cols,ops=expand_cols_ops(cols,ops)
    delim=val(args,"-delim",default=","); prec=int(val(args,"-prec",default="5"))
    curkey=None; bucket=[]; rows=[]
    def flush():
        if not bucket: return
        base=bucket[0][:] if has(args,"-full") else [bucket[0][g-1] for g in groups]
        for c,o in zip(cols,ops): base.append(op_apply([r[c-1] for r in bucket if len(r)>=c],o,delim,prec))
        rows.append(base)
    for fs in lines:
        key=tuple(fs[g-1].lower() if has(args,"-ignorecase") else fs[g-1] for g in groups)
        if curkey is not None and key!=curkey:
            flush(); bucket=[]
        curkey=key; bucket.append(fs)
    flush(); print_rows(rows)

def cmd_coverage(args):
    A=read_recs(val(args,"-a")); Bc=bychrom(read_recs(val(args,"-b"))); rows=[]
    for a in A:
        cov=[0]*a.length(); count=0
        for b in Bc.get(a.chrom,[]):
            o=ov(a,b)
            if pass_frac(a,b,o,args):
                count+=1
                for i in range(max(a.start,b.start),min(a.end,b.end)): cov[i-a.start]+=1
        if has(args,"-counts"): rows.append(a.f+[str(count)])
        elif has(args,"-mean"): rows.append(a.f+[fmt_num(sum(cov)/max(1,len(cov)),7)])
        else:
            covered=sum(1 for x in cov if x>0); ln=max(1,a.length())
            rows.append(a.f+[str(count),str(covered),str(a.length()),fmt_num(covered/ln,7)])
    print_rows(rows)

def cmd_window(args):
    A=read_recs(val(args,"-a")); Bc=bychrom(read_recs(val(args,"-b")))
    w=int(val(args,"-w",default="1000")); l=int(val(args,"-l",default=str(w))); r=int(val(args,"-r",default=str(w)))
    rows=[]
    for a in A:
        wa=Rec(a.f[:]); wa.start=max(0,a.start-l); wa.end=a.end+r
        hits=[b for b in Bc.get(a.chrom,[]) if ov(wa,b)>0 and strand_ok(a,b,args)]
        if has(args,"-c"): rows.append(a.f+[str(len(hits))])
        elif has(args,"-u"):
            if hits: rows.append(a.f)
        elif has(args,"-v"):
            if not hits: rows.append(a.f)
        else:
            for b in hits: rows.append(a.f+b.f)
    print_rows(rows)

def cmd_map(args):
    A=read_recs(val(args,"-a")); Bc=bychrom(read_recs(val(args,"-b")))
    cols=[int(x) for x in val(args,"-c",default="5").split(",")]
    ops=val(args,"-o",default="sum").split(","); cols,ops=expand_cols_ops(cols,ops)
    delim=val(args,"-delim",default=","); prec=int(val(args,"-prec",default="5")); null=val(args,"-null",default=".")
    rows=[]
    for a in A:
        hits=[b for b in Bc.get(a.chrom,[]) if pass_frac(a,b,ov(a,b),args)]
        row=a.f[:]
        for c,o in zip(cols,ops):
            vals=[b.f[c-1] for b in hits if len(b.f)>=c]
            row.append(op_apply(vals,o,delim,prec) if vals or o in ("count","count_distinct") else null)
        rows.append(row)
    print_rows(rows)

def cmd_bed12tobed6(args):
    path=val(args,"-i",default=None) or (args[0] if args else "-")
    rows=[]
    for r in read_recs(path):
        if len(r.f)<12: continue
        sizes=[int(x) for x in r.f[10].rstrip(",").split(",") if x!=""]
        starts=[int(x) for x in r.f[11].rstrip(",").split(",") if x!=""]
        for s,sz in zip(starts,sizes):
            rows.append([r.chrom,str(r.start+s),str(r.start+s+sz),
                         r.f[3] if len(r.f)>3 else ".",
                         r.f[4] if len(r.f)>4 else "0",
                         r.f[5] if len(r.f)>5 else "."])
    print_rows(rows)

def print_rows(rows):
    sys.stdout.write("\n".join("\t".join(map(str,r)) for r in rows)+("\n" if rows else ""))

def main():
    args=sys.argv[1:]
    if not args or args[0] in ("--help","-h"): print(HELP); return
    if args[0]=="--version": print(VERSION); return
    if args[0]=="--contact":
        print("- For further help, or to report a bug, please \n  email the bedtools mailing list: \n     bedtools-discuss@googlegroups.com\n\n- The development repository can be found at: \n     https://github.com/arq5x/bedtools\n\n- Stable releases of bedtools can be found at: \n     https://github.com/arq5x/bedtools2/releases")
        return
    cmd=args[0]; rest=args[1:]
    if "-h" in rest or "--help" in rest:
        print(f"Tool:    bedtools {cmd}\nVersion: b2e3657\nUsage:   bedtools {cmd} [OPTIONS]"); return
    table={"intersect":cmd_intersect,"window":cmd_window,"map":cmd_map,"bed12tobed6":cmd_bed12tobed6,
           "merge":cmd_merge,"complement":cmd_complement,"genomecov":cmd_genomecov,
           "jaccard":cmd_jaccard,"closest":cmd_closest,"makewindows":cmd_makewindows,"slop":lambda a:cmd_slop(a,False),
           "flank":lambda a:cmd_slop(a,True),"subtract":cmd_subtract,"sort":cmd_sort,"groupby":cmd_groupby,
           "coverage":cmd_coverage}
    aliases={"intersectBed":"intersect","mergeBed":"merge","complementBed":"complement","genomeCoverageBed":"genomecov",
             "closestBed":"closest","windowMaker":"makewindows","slopBed":"slop","flankBed":"flank","subtractBed":"subtract",
             "windowBed":"window","mapBed":"map","bed12ToBed6":"bed12tobed6","sortBed":"sort","groupBy":"groupby","coverageBed":"coverage"}
    cmd=aliases.get(cmd,cmd)
    if cmd not in table: die(f"*****ERROR: Unrecognized command: {cmd} *****")
    table[cmd](rest)
if __name__=="__main__": main()
