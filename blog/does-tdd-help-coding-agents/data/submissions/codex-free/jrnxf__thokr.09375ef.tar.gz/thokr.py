#!/usr/bin/env python3
import csv
import os
import random
import sys
import termios
import time
import tty

VERSION = "thokr 0.4.1"
ABOUT = "sleek typing tui with visualized results and historical logging"
LANGS = {"english", "english1k", "english10k"}

HELP = """thokr 0.4.1
sleek typing tui with visualized results and historical logging

USAGE:
    executable [OPTIONS]

OPTIONS:
    -f, --full-sentences <NUMBER_OF_SENTENCES>
            number of sentences to use in test

    -h, --help
            Print help information

    -l, --supported-language <SUPPORTED_LANGUAGE>
            language to pull words from [default: english] [possible values: english, english1k,
            english10k]

    -p, --prompt <PROMPT>
            custom prompt to use

    -s, --number-of-secs <NUMBER_OF_SECS>
            number of seconds to run test

    -V, --version
            Print version information

    -w, --number-of-words <NUMBER_OF_WORDS>
            number of words to use in test [default: 15]
"""

BASE_WORDS = """
the be to of and a in that have i it for not on with he as you do at this but
his by from they we say her she or an will my one all would there their what so
up out if about who get which go me when make can like time no just him know
take people into year your good some could them see other than then now look
only come its over think also back after use two how our work first well way
even new want because any these give day most us is are was were been has had
did shall may might must should where why many those very through before right
too mean old same tell boy follow came show every under name much great around
another set leave put end does three small house world again place school while
off still try last ask need feel point high different become large own little
against turn here move thing general hand picture change spell air animal
mother answer found study learn plant cover food sun four thought let keep eye
never below city tree cross since hard start story saw far sea draw left late
run don't press close night real life few stop open seem together next white
children begin got walk example ease paper often always music both mark book
letter until mile river car feet care second group carry took rain eat room
friend began idea fish mountain north once base hear horse cut sure watch color
face wood main enough plain girl usual young ready above ever red list though
feel talk bird soon body dog family direct pose song measure state product
black short numeral class wind question happen complete ship area half rock
order fire south problem piece told knew pass farm top whole king size heard
best hour better true during hundred am remember step early hold west ground
interest reach fast five sing listen six table travel less morning ten simple
several vowel toward war lay against pattern slow center love person money
serve appear road map science rule govern pull cold notice voice fall power
town fine certain fly unit lead cry dark machine note wait plan figure star box
noun field rest correct able pound done beauty drive stood contain front teach
week final gave green oh quick develop sleep warm free minute strong special
mind behind clear tail produce fact street inch lot nothing course stay wheel
full force blue object decide surface deep moon island foot yet busy test record
boat common gold possible plane age dry wonder laugh thousand ago ran check
game shape yes hot miss brought heat snow bed bring sit perhaps fill east
weight language among adult ad after ago almost along already although always
american amount analysis animal anyone anything apply approach area argue arm
article artist attack attention available avoid ball bank beat beautiful
behavior benefit billion blood board born break brother budget building business
camera campaign cancer capital case catch cause cell center central century
chance character charge child choice citizen civil claim class clear coach cold
college commercial community company compare computer concern condition
conference congress consumer contain continue control cost country couple
course court cover create crime cultural culture current customer data daughter
dead deal death debate decade decision defense degree democrat democratic
describe design despite detail determine development difference difficult
dinner direction discover discussion disease doctor door down dream drive drop
drug each economic economy edge education effort election employee energy enjoy
environment environmental especially establish event everybody evidence exactly
executive exist expert explain factor family federal feeling field fight
financial finish firm floor focus foot foreign forget form former forward four
free friend front full fund future garden gas generation glass goal good
government great green ground group grow growth guess hair half hand happen
happy health hear heart heat heavy help herself high himself history home hope
hospital hot hotel hour house however huge human husband image imagine impact
important improve include including increase indeed indicate individual
industry information inside instead institution interest interesting interview
investment involve issue itself job join just keep kid kind kitchen knowledge
land language large last later laugh lawyer leader learn least leave left legal
less letter level life light likely line list listen little live local long look
lose loss love low machine magazine main maintain majority make manage
management manager many market marriage material matter maybe media medical
meet meeting member memory mention message method middle military million mind
minute miss mission model modern moment money month more morning mother mouth
move movement movie much music myself name nation national natural nature near
nearly necessary network never newspaper nice night none north note nothing
notice number occur offer office officer official often oil once only open
operation opportunity option order organization other others outside over owner
page pain painting paper parent part participant particular particularly party
pass past patient pattern pay peace people perform performance perhaps period
person personal phone physical pick picture piece place plan plant play player
point police policy political politics poor popular population position
positive possible power practice prepare present president pressure pretty
prevent price private probably problem process produce product production
professional professor program project property protect prove provide public
purpose quality question quickly quite radio raise range rather reach read
ready real reality realize really reason receive recent recently recognize
record red reduce reflect region relate relationship religious remain remember
remove report represent republican require research resource respond response
responsibility rest result return reveal rich right rise risk road rock role
room rule run safe same save say scene school science scientist score sea
season seat second section security seek seem sell send senior sense series
serious serve service set seven several shake share she shoot short should
shoulder show side sign significant similar simple simply since sing single
sister site situation six size skill skin small smile social society soldier
some somebody someone something sometimes son song soon sort sound source
south southern space speak special specific speech spend sport spring staff
stage stand standard star start state statement station stay step still stock
stop store story strategy street strong structure student study stuff style
subject success successful such suddenly suffer suggest summer support sure
surface system table take talk task tax teach teacher team technology
television tell tend term test than thank that their them themselves then
theory there these they thing think third this those though thought thousand
threat three through throughout throw thus time today together tonight too top
total tough toward town trade traditional training travel treat treatment tree
trial trip trouble true truth try turn two type under understand unit until up
upon us use usually value various very victim view violence visit voice vote
wait walk wall want war watch water way weapon wear week weight well west
western what whatever when where whether which while white who whole whom whose
why wide wife will win wind window wish with within without woman wonder word
work worker world worry would write writer wrong yard yeah year yes yet young
your yourself
""".split()

SENTENCES = [
    "The quick brown fox jumps over the lazy dog.",
    "Typing is easier when the words arrive in a steady rhythm.",
    "Practice turns small habits into a smooth and reliable skill.",
    "A clear prompt keeps the test focused from start to finish.",
    "Every result is a snapshot of speed accuracy and consistency.",
]


def die(msg, usage="executable [OPTIONS]"):
    sys.stderr.write(msg + "\n\n")
    sys.stderr.write(f"USAGE:\n    {usage}\n\n")
    sys.stderr.write("For more information try --help\n")
    sys.exit(2)


def invalid_value(value, opt, detail):
    sys.stderr.write(f"error: Invalid value \"{value}\" for '{opt}': {detail}\n\n")
    sys.stderr.write("For more information try --help\n")
    sys.exit(2)


def parse_uint(value, opt):
    try:
        if value.startswith("-"):
            raise ValueError("neg")
        return int(value)
    except ValueError:
        if value.startswith("-"):
            die(f"error: Found argument '{value}' which wasn't expected, or isn't valid in this context\n\n\tIf you tried to supply `{value}` as a value rather than a flag, use `-- {value}`")
        invalid_value(value, opt, "invalid digit found in string")


def parse_args(argv):
    opts = {"words": 15, "lang": "english", "secs": None, "sentences": None, "prompt": None}
    i = 0
    while i < len(argv):
        a = argv[i]
        if a in ("-h", "--help"):
            print(HELP, end="")
            sys.exit(0)
        if a in ("-V", "--version"):
            print(VERSION)
            sys.exit(0)
        if a == "--":
            rest = argv[i + 1:]
            if rest:
                die(f"error: Found argument '{rest[0]}' which wasn't expected, or isn't valid in this context")
            break

        def need_value(long_name):
            nonlocal i
            if i + 1 >= len(argv):
                die(f"error: The argument '{long_name}' requires a value but none was supplied")
            i += 1
            return argv[i]

        if a in ("-w", "--number-of-words"):
            opts["words"] = parse_uint(need_value("--number-of-words <NUMBER_OF_WORDS>"), "--number-of-words <NUMBER_OF_WORDS>")
        elif a.startswith("--number-of-words="):
            opts["words"] = parse_uint(a.split("=", 1)[1], "--number-of-words <NUMBER_OF_WORDS>")
        elif a.startswith("-w") and len(a) > 2:
            opts["words"] = parse_uint(a[2:], "--number-of-words <NUMBER_OF_WORDS>")
        elif a in ("-s", "--number-of-secs"):
            opts["secs"] = parse_uint(need_value("--number-of-secs <NUMBER_OF_SECS>"), "--number-of-secs <NUMBER_OF_SECS>")
        elif a.startswith("--number-of-secs="):
            opts["secs"] = parse_uint(a.split("=", 1)[1], "--number-of-secs <NUMBER_OF_SECS>")
        elif a.startswith("-s") and len(a) > 2:
            opts["secs"] = parse_uint(a[2:], "--number-of-secs <NUMBER_OF_SECS>")
        elif a in ("-f", "--full-sentences"):
            opts["sentences"] = parse_uint(need_value("--full-sentences <NUMBER_OF_SENTENCES>"), "--full-sentences <NUMBER_OF_SENTENCES>")
        elif a.startswith("--full-sentences="):
            opts["sentences"] = parse_uint(a.split("=", 1)[1], "--full-sentences <NUMBER_OF_SENTENCES>")
        elif a.startswith("-f") and len(a) > 2:
            opts["sentences"] = parse_uint(a[2:], "--full-sentences <NUMBER_OF_SENTENCES>")
        elif a in ("-p", "--prompt"):
            opts["prompt"] = need_value("--prompt <PROMPT>")
        elif a.startswith("--prompt="):
            opts["prompt"] = a.split("=", 1)[1]
        elif a.startswith("-p") and len(a) > 2:
            opts["prompt"] = a[2:]
        elif a in ("-l", "--supported-language"):
            opts["lang"] = need_value("--supported-language <SUPPORTED_LANGUAGE>")
        elif a.startswith("--supported-language="):
            opts["lang"] = a.split("=", 1)[1]
        elif a.startswith("-l") and len(a) > 2:
            opts["lang"] = a[2:]
        elif a.startswith("-"):
            die(f"error: Found argument '{a}' which wasn't expected, or isn't valid in this context\n\n\tIf you tried to supply `{a}` as a value rather than a flag, use `-- {a}`")
        else:
            die(f"error: Found argument '{a}' which wasn't expected, or isn't valid in this context")
        i += 1
    if opts["lang"] not in LANGS:
        sys.stderr.write(f"error: \"{opts['lang']}\" isn't a valid value for '--supported-language <SUPPORTED_LANGUAGE>'\n")
        sys.stderr.write("\t[possible values: english, english1k, english10k]\n\n")
        sys.stderr.write("USAGE:\n    executable --supported-language <SUPPORTED_LANGUAGE>\n\n")
        sys.stderr.write("For more information try --help\n")
        sys.exit(2)
    return opts


def make_prompt(opts):
    if opts["prompt"] is not None:
        return opts["prompt"]
    if opts["sentences"] is not None:
        count = max(0, opts["sentences"])
        return " ".join(SENTENCES[i % len(SENTENCES)] for i in range(count))
    words = BASE_WORDS[:]
    if opts["lang"] == "english":
        words = words[:200]
    elif opts["lang"] == "english1k":
        words = (words * 5)[:1000]
    else:
        words = (words * 50)[:10000]
    n = max(0, opts["words"])
    return " ".join(random.choice(words) for _ in range(n))


def config_path():
    xdg = os.environ.get("XDG_CONFIG_HOME")
    if xdg:
        base = xdg
    else:
        base = os.path.join(os.environ.get("HOME", "."), ".config")
    path = os.path.join(base, "thokr")
    os.makedirs(path, exist_ok=True)
    return os.path.join(path, "log.csv")


def log_result(opts, elapsed, wpm, accuracy, stddev):
    path = config_path()
    exists = os.path.exists(path)
    with open(path, "a", newline="") as f:
        writer = csv.writer(f, lineterminator="\n")
        if not exists:
            writer.writerow(["date", "num_words", "num_secs", "elapsed_secs", "wpm", "accuracy", "std_dev"])
        writer.writerow([
            time.strftime("%a %b %d %H:%M:%S %Y", time.localtime()),
            opts["words"],
            "" if opts["secs"] is None else opts["secs"],
            f"{elapsed:.2f}",
            str(int(round(wpm))),
            str(int(round(accuracy))),
            f"{stddev:.2f}",
        ])


def render_prompt(prompt, typed):
    cols = 80
    try:
        cols = os.get_terminal_size().columns
    except OSError:
        pass
    sys.stdout.write("\x1b[2J\x1b[H\x1b[?25l")
    left = max(1, (cols - min(cols - 4, len(prompt))) // 2)
    sys.stdout.write("\n" * 3 + " " * left)
    for i, ch in enumerate(prompt):
        if i < len(typed):
            color = "\x1b[38;5;2m" if typed[i] == ch else "\x1b[38;5;1m"
            sys.stdout.write(color + ch + "\x1b[39m")
        elif i == len(typed):
            sys.stdout.write("\x1b[1m\x1b[4m" + ch + "\x1b[24m\x1b[22m")
        else:
            sys.stdout.write(ch)
    sys.stdout.flush()


def render_results(elapsed, wpm, accuracy):
    sys.stdout.write("\x1b[2J\x1b[H")
    sys.stdout.write(f"\n\n     {int(round(wpm))} |wpm\n")
    sys.stdout.write("     0 |seconds\n\n")
    sys.stdout.write(f"     {int(round(wpm))} wpm   {int(round(accuracy))}% acc   0.00 sd\n\n")
    sys.stdout.write("     (r)etry / (n)ew / (esc)ape")
    sys.stdout.flush()


def read_key(timeout=None):
    import select
    ready, _, _ = select.select([sys.stdin.fileno()], [], [], timeout)
    if not ready:
        return None
    ch = os.read(sys.stdin.fileno(), 1)
    if not ch:
        return ""
    return ch.decode("utf-8", "ignore")


def run_test(opts):
    prompt = make_prompt(opts)
    typed = []
    start = None
    deadline = None
    while True:
        render_prompt(prompt, typed)
        if start is not None and deadline is not None and time.time() >= deadline:
            break
        timeout = None
        if start is not None and deadline is not None:
            timeout = max(0.0, deadline - time.time())
        ch = read_key(timeout)
        if ch is None:
            break
        if ch == "\x1b":
            return False
        if ch in ("\x7f", "\b"):
            if typed:
                typed.pop()
            continue
        if ch in ("\r", "\n"):
            continue
        if start is None:
            start = time.time()
            if opts["secs"] is not None:
                deadline = start + opts["secs"]
        if ch and ord(ch) >= 32:
            typed.append(ch)
        if len(typed) >= len(prompt):
            break
    elapsed = max(0.01, time.time() - (start or time.time()))
    correct = sum(1 for i, ch in enumerate(typed[:len(prompt)]) if ch == prompt[i])
    accuracy = 100.0 if not typed else 100.0 * correct / len(typed)
    wpm = (correct / 5.0) / (elapsed / 60.0)
    log_result(opts, elapsed, wpm, accuracy, 0.0)
    render_results(elapsed, wpm, accuracy)
    while True:
        ch = read_key().lower()
        if ch == "\x1b":
            return False
        if ch == "r":
            return True
        if ch == "n" and opts["prompt"] is None:
            return True


def main():
    opts = parse_args(sys.argv[1:])
    if not sys.stdin.isatty():
        sys.stderr.write("error: stdin must be a tty\n\n")
        sys.stderr.write("USAGE:\n    thokr [OPTIONS]\n\n")
        sys.stderr.write("For more information try --help\n")
        sys.exit(2)
    old = termios.tcgetattr(sys.stdin.fileno())
    try:
        tty.setraw(sys.stdin.fileno())
        sys.stdout.write("\x1b[?1049h")
        sys.stdout.flush()
        again = True
        while again:
            again = run_test(opts)
    finally:
        sys.stdout.write("\x1b[?25h\x1b[?1049l\x1b[0m")
        sys.stdout.flush()
        termios.tcsetattr(sys.stdin.fileno(), termios.TCSADRAIN, old)


if __name__ == "__main__":
    main()
