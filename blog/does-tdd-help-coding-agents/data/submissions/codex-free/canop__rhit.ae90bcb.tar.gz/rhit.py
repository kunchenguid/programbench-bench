#!/usr/bin/env python3
import argparse
import csv
import gzip
import json
import os
import re
import sys
from collections import defaultdict
from datetime import datetime, time

VERSION = "rhit 2.0.4"
MONTHS = {m: i + 1 for i, m in enumerate("Jan Feb Mar Apr May Jun Jul Aug Sep Oct Nov Dec".split())}
LOG_RE = re.compile(r'^(\S+) \S+ \S+ \[([^:]+):(\d\d):(\d\d):(\d\d) ([^\]]+)\] "([^"]*)" (\d{3}) (\S+) "([^"]*)" "([^"]*)"$')
REQ_RE = re.compile(r"^([A-Z]+)\s+(\S+)(?:\s+HTTP/[0-9.]+)?$")
RESOURCE_RE = re.compile(r"\.(?:png|jpe?g|gif|svg|ico|css|js|map|woff2?|ttf|eot|webp|avif|mp4|mp3|pdf|xml|txt)(?:$|\?)", re.I)


class Hit:
    __slots__ = ("raw", "ip", "date", "time", "dt", "method", "path", "status", "bytes", "referer")

    def __init__(self, raw, ip, date, t, dt, method, path, status, sent, referer):
        self.raw = raw
        self.ip = ip
        self.date = date
        self.time = t
        self.dt = dt
        self.method = method
        self.path = path
        self.status = status
        self.bytes = sent
        self.referer = referer


def parse_line(line):
    m = LOG_RE.match(line.rstrip("\n"))
    if not m:
        return None
    ip, dpart, hh, mm, ss, _zone, req, status, sent, referer, _ua = m.groups()
    try:
        day, mon, year = dpart.split("/")
        dt = datetime(int(year), MONTHS[mon], int(day), int(hh), int(mm), int(ss))
    except Exception:
        return None
    rm = REQ_RE.match(req)
    if rm:
        method, path = rm.groups()
        path = path.split("?", 1)[0]
    else:
        method, path = "none", req
    try:
        b = 0 if sent == "-" else int(sent)
    except ValueError:
        b = 0
    return Hit(line.rstrip("\n"), ip, dt.strftime("%Y/%m/%d"), dt.strftime("%H:%M:%S"), dt, method, path, status, b, referer)


def candidate_file(path, no_check):
    if no_check:
        return True
    name = os.path.basename(path)
    return ("access" in name and (name.endswith(".log") or ".log." in name or name.endswith(".gz"))) or name.startswith("access.log")


def iter_files(paths, no_check):
    if not paths:
        paths = ["/var/log/nginx"]
    files = []
    for p in paths:
        if os.path.isdir(p):
            for root, _dirs, names in os.walk(p):
                for n in sorted(names):
                    fp = os.path.join(root, n)
                    if os.path.isfile(fp) and candidate_file(fp, no_check):
                        files.append(fp)
        elif os.path.isfile(p):
            files.append(p)
    return sorted(files)


def read_hits(paths, no_check=False):
    for fp in iter_files(paths, no_check):
        opener = gzip.open if fp.endswith(".gz") else open
        try:
            with opener(fp, "rt", encoding="utf-8", errors="replace") as f:
                for line in f:
                    h = parse_line(line)
                    if h:
                        yield h
        except Exception as e:
            print(f"Error reading {fp}: {e}", file=sys.stderr)


def compile_text_filter(expr):
    if not expr:
        return lambda _s: True
    expr = expr.strip()
    parts = [p.strip() for p in expr.split(",") if p.strip()]
    if len(parts) > 1:
        funcs = [compile_text_filter(p) for p in parts]
        return lambda s: all(f(s) for f in funcs)
    neg = expr.startswith("!")
    if neg:
        expr = expr[1:].strip()
    try:
        rx = re.compile(expr, re.I)
        fn = lambda s: rx.search(s or "") is not None
    except re.error:
        fn = lambda s: expr.lower() in (s or "").lower()
    return (lambda s: not fn(s)) if neg else fn


def status_filter(expr):
    if not expr:
        return lambda _s: True
    terms = [t.strip() for t in expr.split(",") if t.strip()]

    def one(term, status):
        neg = term.startswith("!")
        if neg:
            term = term[1:]
        ok = False
        if re.fullmatch(r"\dxx", term):
            ok = status.startswith(term[0])
        elif re.fullmatch(r"\d{3}-\d{3}", term):
            a, b = map(int, term.split("-"))
            ok = a <= int(status) <= b
        elif re.fullmatch(r"\d{3}", term):
            ok = status == term
        return (not ok) if neg else ok

    def filt(status):
        positives = [t for t in terms if not t.startswith("!")]
        if positives and not any(one(t, status) for t in positives):
            return False
        return all(one(t, status) for t in terms if t.startswith("!"))
    return filt


def parse_date_token(tok, end=False):
    if "T" in tok:
        d, ts = tok.split("T", 1)
    else:
        d, ts = tok, None
    nums = [int(x) for x in d.split("/") if x != ""]
    year = nums[0] if len(nums) > 0 else 1
    month = nums[1] if len(nums) > 1 else (12 if end else 1)
    day = nums[2] if len(nums) > 2 else (31 if end else 1)
    if len(nums) == 1:
        month = 12 if end else 1
        day = 31 if end else 1
    if len(nums) == 2:
        day = 31 if end else 1
    hh = 23 if end else 0
    mm = 59 if end else 0
    ss = 59 if end else 0
    if ts:
        tnums = [int(x) for x in ts.split(":")]
        hh = tnums[0]
        mm = tnums[1] if len(tnums) > 1 else (59 if end else 0)
        ss = tnums[2] if len(tnums) > 2 else (59 if end else 0)
    return datetime(year, month, min(day, 31), hh, mm, ss)


def date_filter(expr):
    if not expr:
        return lambda _h: True
    expr = expr.strip()
    neg = expr.startswith("!")
    if neg:
        inner = date_filter(expr[1:])
        return lambda h: not inner(h)
    if expr.startswith(">"):
        d = parse_date_token(expr[1:], True)
        return lambda h: h.dt > d
    if expr.startswith("<"):
        d = parse_date_token(expr[1:], False)
        return lambda h: h.dt < d
    if "-" in expr:
        a, b = expr.split("-", 1)
        da, db = parse_date_token(a, False), parse_date_token(b, True)
        return lambda h: da <= h.dt <= db
    first = expr.split("/", 1)[0]
    if len(first) < 4:
        nums = [int(x) for x in expr.split("/") if x != ""]
        if len(nums) == 1:
            return lambda h: h.dt.month == nums[0]
        if len(nums) == 2:
            return lambda h: h.dt.month == nums[0] and h.dt.day == nums[1]
    da, db = parse_date_token(expr, False), parse_date_token(expr, True)
    return lambda h: da <= h.dt <= db


def time_filter(expr):
    if not expr:
        return lambda _h: True
    expr = expr.strip()
    op = None
    if expr[0] in "<>":
        op, expr = expr[0], expr[1:]
    parts = [int(x) for x in expr.split(":")]
    tm = time(parts[0], parts[1] if len(parts) > 1 else 0, parts[2] if len(parts) > 2 else 0)
    if op == ">":
        return lambda h: h.dt.time() > tm
    if op == "<":
        return lambda h: h.dt.time() < tm
    return lambda h: h.dt.time().replace(second=0) == tm.replace(second=0)


def apply_filters(hits, args):
    pf = compile_text_filter(args.path)
    rf = compile_text_filter(args.referer)
    ipf = compile_text_filter(args.ip)
    mf = compile_text_filter(args.method)
    sf = status_filter(args.status)
    df = date_filter(args.date)
    tf = time_filter(args.time)
    out = []
    for h in hits:
        if ipf(h.ip) and mf(h.method) and pf(h.path) and rf(h.referer) and sf(h.status) and df(h) and tf(h):
            out.append(h)
    return out


def csv_quote(s):
    buf = []
    w = csv.writer(buf := DummyWriter(), lineterminator="")
    w.writerow([s])
    return buf.data


class DummyWriter:
    def __init__(self):
        self.data = ""
    def write(self, s):
        self.data += s


def output_csv(hits):
    print("date,time,remote address,method,path,status,bytes sent,referer")
    for h in hits:
        print(",".join([
            h.date,
            h.time,
            h.ip,
            h.method,
            csv_cell(h.path),
            h.status,
            str(h.bytes),
            csv_cell(h.referer),
        ]))


def csv_cell(s):
    return '"' + str(s).replace('"', '""') + '"'


def output_json(hits):
    arr = [{
        "date": h.date,
        "time": h.time,
        "remote_addr": h.ip,
        "method": h.method,
        "path": h.path,
        "status": h.status,
        "bytes_sent": h.bytes,
        "referer": h.referer,
    } for h in hits]
    print(json.dumps(arr, indent=2))


def parse_fields(spec):
    default = ["date", "status", "ref", "path"]
    allf = ["date", "time", "method", "status", "ip", "ref", "path"]
    aliases = {"d": "date", "date": "date", "t": "time", "time": "time", "m": "method", "method": "method",
               "s": "status", "status": "status", "i": "ip", "ip": "ip", "r": "ref", "ref": "ref", "referer": "ref",
               "p": "path", "path": "path", "paths": "path", "a": "all", "all": "all"}
    if not spec:
        return default
    spec = spec.replace(",", "+")
    fields = list(default) if spec[0] in "+-" else []
    tokens = re.findall(r"[+-]?[^+-]+", spec)
    for tok in tokens:
        sign = "+"
        if tok[0] in "+-":
            sign, tok = tok[0], tok[1:]
        tok = tok.strip()
        if tok == "all":
            val = allf
        else:
            val = [aliases.get(tok)]
        for v in val:
            if not v:
                continue
            if sign == "-":
                fields = [f for f in fields if f != v]
            else:
                if v in fields:
                    fields.remove(v)
                fields.append(v)
    return fields


def table_counts(hits, attr, include_resources=True):
    d = defaultdict(lambda: [0, 0])
    for h in hits:
        val = getattr(h, attr)
        if attr == "referer" and val == "-":
            continue
        if attr == "path" and not include_resources and RESOURCE_RE.search(val):
            continue
        d[val][0] += 1
        d[val][1] += h.bytes
    return sorted(d.items(), key=lambda kv: (-kv[1][0], -kv[1][1], kv[0]))


def output_tables(hits, args):
    total_b = sum(h.bytes for h in hits)
    if hits:
        print(f"{len(hits)} hits and {total_b} from {hits[0].date} to {hits[-1].date}")
    else:
        print("0 hits")
        return
    fields = parse_fields(args.fields)
    names = {"status": ("HTTP status codes", "status", "status"), "ref": ("referrers", "referrer", "referer"),
             "path": ("paths", "path", "path"), "ip": ("remote addresses", "remote address", "ip"),
             "method": ("methods", "method", "method")}
    if "date" in fields:
        by = defaultdict(lambda: [0, 0])
        for h in hits:
            by[h.date][0] += 1; by[h.date][1] += h.bytes
        print("date,hits,bytes")
        for k in sorted(by):
            print(f"{k},{by[k][0]},{by[k][1]}")
    if "time" in fields:
        by = defaultdict(lambda: [0, 0])
        for h in hits:
            by[h.time[:2]][0] += 1; by[h.time[:2]][1] += h.bytes
        print("time,hits,bytes")
        for k in sorted(by):
            print(f"{k}:00,{by[k][0]},{by[k][1]}")
    limit = {0: 3, 1: 10, 2: 20, 3: 40, 4: 80, 5: 160, 6: 100000}.get(args.length, 100000)
    for f in fields:
        if f not in names:
            continue
        title, col, attr = names[f]
        rows = table_counts(hits, attr, include_resources=args.all)[:limit]
        extra = " (excluding resources like images, css, etc.)." if f == "path" and not args.all else "."
        print(f"{len(rows)} {title}{extra}")
        print(f"#,{col},hits,%,bytes")
        for i, (val, (cnt, b)) in enumerate(rows, 1):
            pct = 100.0 * cnt / len(hits) if hits else 0.0
            print(f"{i},{val},{cnt},{pct:.1f}%,{b}")


def main(argv=None):
    p = argparse.ArgumentParser(prog="executable", add_help=False, usage="%(prog)s [OPTIONS] [FILES]...")
    p.add_argument("--help", action="store_true")
    p.add_argument("--version", action="store_true")
    p.add_argument("--color", default="auto")
    p.add_argument("-k", "--key", default="hits")
    p.add_argument("-l", "--length", type=int, default=1)
    p.add_argument("-f", "--fields")
    p.add_argument("-c", "--changes", action="store_true")
    p.add_argument("-d", "--date")
    p.add_argument("-i", "--ip")
    p.add_argument("-m", "--method")
    p.add_argument("-p", "--path")
    p.add_argument("-r", "--referer")
    p.add_argument("-s", "--status")
    p.add_argument("-t", "--time")
    p.add_argument("-a", "--all", action="store_true")
    p.add_argument("--no-name-check", action="store_true")
    p.add_argument("-o", "--output", default="tables")
    p.add_argument("--silent-load", action="store_true")
    p.add_argument("files", nargs="*")
    args = p.parse_args(argv)
    if args.help:
        print("""                    rhit 2.0.4

Rhit analyzes your nginx logs.

Usage:  rhit [options] [FILES]

Options:
  --help                 Print help information
  --version              Print the version
  --color <auto|yes|no>  Whether to have styles and colors
  -k, --key <KEY>        Key used in sorting: hits or bytes
  -l, --length <LENGTH>  Detail level
  -f, --fields <FIELDS>  Fields to display
  -c, --changes          Add tables with changes
  -d, --date <DATE>      Filter dates
  -i, --ip <IP>          Filter IP
  -m, --method <METHOD>  Filter method
  -p, --path <PATH>      Filter path
  -r, --referer <REF>    Filter referer
  -s, --status <STATUS>  Filter status
  -t, --time <TIME>      Filter time
  -a, --all              Show all paths
  --no-name-check        Try to open all files
  -o, --output <OUTPUT>  tables, raw, csv, json""")
        return 0
    if args.version:
        print(VERSION)
        return 0
    outmap = {"t": "tables", "table": "tables", "tables": "tables", "r": "raw", "raw": "raw",
              "c": "csv", "csv": "csv", "j": "json", "json": "json"}
    if args.output not in outmap:
        print(f"error: invalid value '{args.output}' for '--output <OUTPUT>': unrecognized output \"{args.output}\"", file=sys.stderr)
        return 2
    args.output = outmap[args.output]
    hits = list(read_hits(args.files, args.no_name_check))
    hits = apply_filters(hits, args)
    hits.sort(key=lambda h: h.dt)
    if args.output == "raw":
        for h in hits:
            print(h.raw)
    elif args.output == "csv":
        output_csv(hits)
    elif args.output == "json":
        output_json(hits)
    else:
        output_tables(hits, args)
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except BrokenPipeError:
        raise SystemExit(0)
