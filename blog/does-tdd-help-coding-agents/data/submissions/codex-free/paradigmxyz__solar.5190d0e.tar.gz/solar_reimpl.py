#!/usr/bin/env python3
import json
import os
import re
import sys

VERSION = "0.1.8"
VERSION_LONG = "solar 0.1.8-dev (8f228ae 2026-04-17T19:59:51.519973035Z)"

EVM_VERSIONS = {
    "homestead", "tangerineWhistle", "spuriousDragon", "byzantium",
    "constantinople", "petersburg", "istanbul", "berlin", "london",
    "paris", "shanghai", "cancun", "prague", "osaka",
}

HELP_SHORT = """Blazingly fast Solidity compiler

Usage: executable [OPTIONS] [INPUT]...

Arguments:
  [INPUT]...  Files to compile, or import remappings

Options:
  -j, --threads <THREADS>          Number of threads to use. Zero specifies the number of logical cores [default: 4] [aliases: --jobs]
      --evm-version <EVM_VERSION>  EVM version [default: prague] [possible values: homestead, tangerineWhistle, spuriousDragon, byzantium, constantinople, petersburg, istanbul, berlin, london, paris, shanghai, cancun, prague, osaka]
      --stop-after <STOP_AFTER>    Stop execution after the given compiler stage [possible values: parsing, lowering, analysis]
      --out-dir <OUT_DIR>          Directory to write output files
      --emit <EMIT>                Comma separated list of types of output for the compiler to emit [possible values: abi, hashes]
  -Z <FLAG>                        Unstable flags. WARNING: these are completely unstable, and may change at any time
  -h, --help                       Print help (see more with '--help')
  -V, --version                    Print version

Input options:
      --base-path <BASE_PATH>        Use the given path as the root of the source tree
  -I, --include-path <INCLUDE_PATH>  Directory to search for files
      --allow-paths <ALLOW_PATHS>    Allow a given path for imports

Display options:
      --color <COLOR>                Coloring [default: auto] [possible values: auto, always, never]
  -v, --verbose                      Use verbose output
      --pretty-json                  Pretty-print JSON output
      --pretty-json-err              Pretty-print error JSON output
      --error-format <ERROR_FORMAT>  How errors and other messages are produced [default: human] [possible values: human, json, rustc-json]
      --error-format-human <VALUE>   Human-readable error message style [default: unicode] [possible values: ascii, unicode, short]
      --diagnostic-width <WIDTH>     Terminal width for error message formatting
      --no-warnings                  Whether to disable warnings"""

HELP_LONG = """Blazingly fast Solidity compiler

Usage: executable [OPTIONS] [INPUT]...

Arguments:
  [INPUT]...
          Files to compile, or import remappings.
          
          `-` specifies standard input.
          
          Import remappings are specified as `[context:]prefix=path`. See <https://docs.soliditylang.org/en/latest/path-resolution.html#import-remapping>.

Options:
  -j, --threads <THREADS>
          Number of threads to use. Zero specifies the number of logical cores
          
          [default: 4]
          [aliases: --jobs]

      --evm-version <EVM_VERSION>
          EVM version
          
          [default: prague]
          [possible values: homestead, tangerineWhistle, spuriousDragon, byzantium, constantinople, petersburg, istanbul, berlin, london, paris, shanghai, cancun, prague, osaka]

      --stop-after <STOP_AFTER>
          Stop execution after the given compiler stage
          
          [possible values: parsing, lowering, analysis]

      --out-dir <OUT_DIR>
          Directory to write output files

      --emit <EMIT>
          Comma separated list of types of output for the compiler to emit
          
          [possible values: abi, hashes]

  -Z <FLAG>
          Unstable flags. WARNING: these are completely unstable, and may change at any time.
          
          See `-Zhelp` for more details.

  -h, --help
          Print help (see a summary with '-h')

  -V, --version
          Print version

Input options:
      --base-path <BASE_PATH>
          Use the given path as the root of the source tree

  -I, --include-path <INCLUDE_PATH>
          Directory to search for files.
          
          Can be used multiple times.

      --allow-paths <ALLOW_PATHS>
          Allow a given path for imports

Display options:
      --color <COLOR>
          Coloring
          
          [default: auto]
          [possible values: auto, always, never]

  -v, --verbose
          Use verbose output

      --pretty-json
          Pretty-print JSON output.
          
          Does not include errors. See `--pretty-json-err`.

      --pretty-json-err
          Pretty-print error JSON output

      --error-format <ERROR_FORMAT>
          How errors and other messages are produced
          
          [default: human]
          [possible values: human, json, rustc-json]

      --error-format-human <VALUE>
          Human-readable error message style
          
          [default: unicode]
          [possible values: ascii, unicode, short]

      --diagnostic-width <WIDTH>
          Terminal width for error message formatting

      --no-warnings
          Whether to disable warnings"""

ZHELP = """error: List of all unstable flags.
WARNING: these are completely unstable, and may change at any time!

Options:
      -Zui-testing
          Enables UI testing mode

      -Ztrack-diagnostics
          Prints a note for every diagnostic that is emitted with the creation and emission location.
          
          This is enabled by default on debug builds.

      -Zparse-yul
          Enables parsing Yul files for testing

      -Zno-resolve-imports
          Disables import resolution

      -Zdump=<KIND[=PATHS...]>
          Print additional information about the compiler's internal state.
          
          Valid kinds are `ast` and `hir`.

      -Zast-stats
          Print AST stats

      -Zspan-visitor
          Run the span visitor after parsing

      -Zprint-max-storage-sizes
          Print contracts' max storage sizes

      -Ztypeck
          Type check the program. WIP

      -Zhelp
          Print help

Usage: solar [OPTIONS] [INPUT]...

For more information, try '--help'."""


def die_cli(msg):
    print(f"error: {msg}\n", file=sys.stderr)
    print("For more information, try '--help'.", file=sys.stderr)
    sys.exit(2)


def parse_args(argv):
    opts = {
        "emit": [],
        "pretty": False,
        "out_dir": None,
        "stop_after": None,
        "error_format": "human",
        "error_human": "unicode",
        "inputs": [],
        "include_paths": [],
        "base_path": None,
    }
    i = 0
    while i < len(argv):
        a = argv[i]
        if a == "-h":
            print(HELP_SHORT)
            sys.exit(0)
        if a == "--help":
            print(HELP_LONG)
            sys.exit(0)
        if a in ("-V", "--version"):
            print(VERSION_LONG)
            sys.exit(0)
        if a == "-Zhelp":
            print(ZHELP, file=sys.stderr)
            sys.exit(2)
        if a == "-Z":
            i += 1
            if i >= len(argv):
                die_cli("a value is required for '-Z <FLAG>' but none was supplied")
            if argv[i] == "help":
                print(ZHELP, file=sys.stderr)
                sys.exit(2)
        elif a in ("-j", "--threads", "--jobs"):
            i += 1
            if i >= len(argv):
                die_cli(f"a value is required for '{a} <THREADS>' but none was supplied")
            try:
                int(argv[i])
            except ValueError:
                die_cli(f"invalid value '{argv[i]}' for '--threads <THREADS>': invalid digit found in string")
        elif a == "--evm-version":
            i += 1
            if i >= len(argv):
                die_cli("a value is required for '--evm-version <EVM_VERSION>' but none was supplied")
            if argv[i] not in EVM_VERSIONS:
                die_cli(f"invalid value '{argv[i]}' for '--evm-version <EVM_VERSION>'\n  [possible values: homestead, tangerineWhistle, spuriousDragon, byzantium, constantinople, petersburg, istanbul, berlin, london, paris, shanghai, cancun, prague, osaka]")
        elif a == "--stop-after":
            i += 1
            if i >= len(argv):
                die_cli("a value is required for '--stop-after <STOP_AFTER>' but none was supplied")
            if argv[i] not in {"parsing", "lowering", "analysis"}:
                die_cli(f"invalid value '{argv[i]}' for '--stop-after <STOP_AFTER>'")
            opts["stop_after"] = argv[i]
        elif a == "--out-dir":
            i += 1
            if i >= len(argv):
                die_cli("a value is required for '--out-dir <OUT_DIR>' but none was supplied")
            opts["out_dir"] = argv[i]
        elif a == "--emit":
            i += 1
            if i >= len(argv):
                die_cli("a value is required for '--emit <EMIT>' but none was supplied")
            vals = [x for x in argv[i].split(",") if x]
            for v in vals:
                if v not in {"abi", "hashes"}:
                    die_cli(f"invalid value '{v}' for '--emit <EMIT>'\n  [possible values: abi, hashes]")
            opts["emit"].extend(vals)
        elif a in ("--base-path", "--allow-paths", "--diagnostic-width", "--error-format", "--error-format-human", "--color", "-I", "--include-path"):
            key = a
            i += 1
            if i >= len(argv):
                die_cli(f"a value is required for '{key}' but none was supplied")
            if key == "--error-format":
                if argv[i] not in {"human", "json", "rustc-json"}:
                    die_cli(f"invalid value '{argv[i]}' for '--error-format <ERROR_FORMAT>'")
                opts["error_format"] = argv[i]
            elif key == "--error-format-human":
                opts["error_human"] = argv[i]
            elif key == "--color" and argv[i] not in {"auto", "always", "never"}:
                die_cli(f"invalid value '{argv[i]}' for '--color <COLOR>'")
            elif key in ("-I", "--include-path"):
                opts["include_paths"].append(argv[i])
            elif key == "--base-path":
                opts["base_path"] = argv[i]
        elif a in ("--pretty-json", "--pretty-json-err", "-v", "--verbose", "--no-warnings"):
            if a == "--pretty-json":
                opts["pretty"] = True
        elif a == "--":
            opts["inputs"].extend(argv[i + 1:])
            break
        elif a.startswith("-") and a != "-":
            print(f"error: unexpected argument '{a}' found\n", file=sys.stderr)
            print(f"  tip: to pass '{a}' as a value, use '-- {a}'\n", file=sys.stderr)
            print("Usage: executable [OPTIONS] [INPUT]...\n", file=sys.stderr)
            print("For more information, try '--help'.", file=sys.stderr)
            sys.exit(2)
        else:
            opts["inputs"].append(a)
        i += 1
    return opts


RC = [
    0x0000000000000001, 0x0000000000008082, 0x800000000000808A,
    0x8000000080008000, 0x000000000000808B, 0x0000000080000001,
    0x8000000080008081, 0x8000000000008009, 0x000000000000008A,
    0x0000000000000088, 0x0000000080008009, 0x000000008000000A,
    0x000000008000808B, 0x800000000000008B, 0x8000000000008089,
    0x8000000000008003, 0x8000000000008002, 0x8000000000000080,
    0x000000000000800A, 0x800000008000000A, 0x8000000080008081,
    0x8000000000008080, 0x0000000080000001, 0x8000000080008008,
]
ROTC = [1, 3, 6, 10, 15, 21, 28, 36, 45, 55, 2, 14, 27, 41, 56, 8, 25, 43, 62,
        18, 39, 61, 20, 44]
PILN = [10, 7, 11, 17, 18, 3, 5, 16, 8, 21, 24, 4, 15, 23, 19, 13, 12, 2, 20,
        14, 22, 9, 6, 1]


def rol(x, n):
    return ((x << n) | (x >> (64 - n))) & ((1 << 64) - 1)


def keccak_f(st):
    for rc in RC:
        bc = [st[i] ^ st[i + 5] ^ st[i + 10] ^ st[i + 15] ^ st[i + 20] for i in range(5)]
        for i in range(5):
            t = bc[(i + 4) % 5] ^ rol(bc[(i + 1) % 5], 1)
            for j in range(0, 25, 5):
                st[j + i] ^= t
        t = st[1]
        for i in range(24):
            j = PILN[i]
            bc0 = st[j]
            st[j] = rol(t, ROTC[i])
            t = bc0
        for j in range(0, 25, 5):
            row = st[j:j + 5]
            for i in range(5):
                st[j + i] ^= (~row[(i + 1) % 5]) & row[(i + 2) % 5]
        st[0] ^= rc


def keccak256(data):
    rate = 136
    st = [0] * 25
    b = bytearray(data)
    b.append(1)
    while len(b) % rate != rate - 1:
        b.append(0)
    b.append(0x80)
    for off in range(0, len(b), rate):
        block = b[off:off + rate]
        for i in range(rate // 8):
            st[i] ^= int.from_bytes(block[i * 8:i * 8 + 8], "little")
        keccak_f(st)
    out = bytearray()
    while len(out) < 32:
        for i in range(rate // 8):
            out.extend(st[i].to_bytes(8, "little"))
        if len(out) < 32:
            keccak_f(st)
    return bytes(out[:32])


def strip_comments(src):
    src = re.sub(r"/\*.*?\*/", "", src, flags=re.S)
    src = re.sub(r"//.*", "", src)
    return src


def find_matching(src, pos):
    depth = 0
    for i in range(pos, len(src)):
        if src[i] == "{":
            depth += 1
        elif src[i] == "}":
            depth -= 1
            if depth == 0:
                return i
    return len(src) - 1


def contracts(src):
    out = []
    pat = re.compile(r"\b(?:(abstract)\s+)?(contract|interface|library)\s+([A-Za-z_]\w*)[^{;]*\{")
    pos = 0
    while True:
        m = pat.search(src, pos)
        if not m:
            break
        start = m.end() - 1
        end = find_matching(src, start)
        out.append((m.group(2), m.group(3), src[start + 1:end]))
        pos = end + 1
    return out


def split_params(s):
    s = s.strip()
    if not s:
        return []
    parts, cur, depth = [], [], 0
    for ch in s:
        if ch == "," and depth == 0:
            parts.append("".join(cur).strip())
            cur = []
            continue
        cur.append(ch)
        if ch in "([":
            depth += 1
        elif ch in ")]" and depth:
            depth -= 1
    if cur:
        parts.append("".join(cur).strip())
    return [p for p in parts if p]


def norm_type(t):
    t = re.sub(r"\b(memory|calldata|storage|payable|indexed)\b", "", t)
    t = re.sub(r"\s+", " ", t).strip()
    t = re.sub(r"\s*\[\s*\]", "[]", t)
    t = re.sub(r"\buint\b", "uint256", t)
    t = re.sub(r"\bint\b", "int256", t)
    t = t.replace("address payable", "address")
    return t


def parse_param(p, event=False):
    p = p.strip()
    indexed = bool(re.search(r"\bindexed\b", p))
    p2 = re.sub(r"\b(indexed|memory|calldata|storage|payable)\b", " ", p)
    toks = p2.split()
    if not toks:
        typ, name = "", ""
    elif len(toks) == 1:
        typ, name = toks[0], ""
    else:
        if re.match(r"^[A-Za-z_]\w*$", toks[-1]) and not toks[-1].endswith("]"):
            typ, name = " ".join(toks[:-1]), toks[-1]
        else:
            typ, name = " ".join(toks), ""
    typ = norm_type(typ)
    d = {"name": name, "type": typ}
    if event:
        d["indexed"] = indexed
    d["internalType"] = typ
    return d


def returns_from(rest):
    m = re.search(r"\breturns\s*\((.*?)\)", rest, flags=re.S)
    return [parse_param(p) for p in split_params(m.group(1))] if m else []


def state_mutability(rest):
    if re.search(r"\bpayable\b", rest):
        return "payable"
    if re.search(r"\bpure\b", rest):
        return "pure"
    if re.search(r"\bview\b", rest):
        return "view"
    return "nonpayable"


def top_level_statements(body):
    res, cur, depth = [], [], 0
    for ch in body:
        cur.append(ch)
        if ch == "{":
            depth += 1
        elif ch == "}":
            depth = max(depth - 1, 0)
            if depth == 0:
                res.append("".join(cur).strip())
                cur = []
        elif ch == ";" and depth == 0:
            res.append("".join(cur).strip())
            cur = []
    return res


def getter_for_var(stmt):
    s = stmt.rstrip(";").strip()
    mv = re.match(r"(.+?)\s+public(?:\s+[^;=]+?)*\s+([A-Za-z_]\w*)\s*(?:=.*)?$", s)
    if not mv or "function" in mv.group(1):
        return None
    left, name = mv.group(1).strip(), mv.group(2)
    mm = re.match(r"mapping\s*\((.+?)\s*=>\s*(.+)\)", left)
    if mm:
        key_t = norm_type(mm.group(1))
        val_t = norm_type(mm.group(2).split()[-1])
        return {"type": "function", "name": name,
                "inputs": [{"name": "", "type": key_t, "internalType": key_t}],
                "outputs": [{"name": "", "type": val_t, "internalType": val_t}],
                "stateMutability": "view"}
    typ = norm_type(left.split()[-1])
    return {"type": "function", "name": name, "inputs": [],
            "outputs": [{"name": "", "type": typ, "internalType": typ}],
            "stateMutability": "view"}


def parse_contract(kind, name, body):
    constructors, errors, events, funcs, vars_, specials = [], [], [], [], [], []
    for st in top_level_statements(body):
        s = " ".join(st.split())
        if not s:
            continue
        m = re.match(r"constructor\s*\((.*?)\)\s*([^{};]*)", s)
        if m:
            item = {"type": "constructor", "inputs": [parse_param(p) for p in split_params(m.group(1))],
                    "stateMutability": state_mutability(m.group(2))}
            constructors.append(item)
            continue
        m = re.match(r"error\s+([A-Za-z_]\w*)\s*\((.*?)\)", s)
        if m:
            errors.append({"type": "error", "name": m.group(1), "inputs": [parse_param(p) for p in split_params(m.group(2))]})
            continue
        m = re.match(r"event\s+([A-Za-z_]\w*)\s*\((.*?)\)\s*([^;{]*)", s)
        if m:
            events.append({"type": "event", "name": m.group(1), "inputs": [parse_param(p, True) for p in split_params(m.group(2))],
                           "anonymous": bool(re.search(r"\banonymous\b", m.group(3)))})
            continue
        m = re.match(r"fallback\s*\((.*?)\)\s*([^{};]*)", s)
        if m:
            specials.append({"type": "fallback", "stateMutability": state_mutability(m.group(2))})
            continue
        m = re.match(r"receive\s*\(\s*\)\s*([^{};]*)", s)
        if m:
            specials.append({"type": "receive", "stateMutability": state_mutability(m.group(1))})
            continue
        m = re.match(r"function\s+([A-Za-z_]\w*)\s*\((.*?)\)\s*([^{};]*)", s)
        if m:
            rest = m.group(3)
            if re.search(r"\b(private|internal)\b", rest):
                continue
            funcs.append({"type": "function", "name": m.group(1),
                          "inputs": [parse_param(p) for p in split_params(m.group(2))],
                          "outputs": returns_from(rest),
                          "stateMutability": state_mutability(rest)})
            continue
        if " public " in f" {s} " and not s.startswith(("using ", "event ", "error ")):
            getter = getter_for_var(s)
            if getter:
                vars_.append(getter)
    errors.sort(key=lambda x: x["name"])
    events.sort(key=lambda x: x["name"])
    funcs.extend(vars_)
    funcs.sort(key=lambda x: x["name"])
    specials.sort(key=lambda x: 0 if x["type"] == "fallback" else 1)
    abi = constructors + errors + events + specials + funcs
    return abi


def signature(fn):
    return fn["name"] + "(" + ",".join(p["type"] for p in fn.get("inputs", [])) + ")"


def resolve_imports(path, src, include_paths, seen):
    found = []
    for m in re.finditer(r"\bimport\s+(?:[^\"']*from\s+)?[\"']([^\"']+)[\"']\s*;", src):
        imp = m.group(1)
        candidates = []
        if path != "<stdin>":
            candidates.append(os.path.join(os.path.dirname(path), imp))
        candidates.extend(os.path.join(p, imp) for p in include_paths)
        candidates.append(imp)
        for c in candidates:
            if os.path.exists(c):
                rp = os.path.normpath(c)
                if rp not in seen:
                    seen.add(rp)
                    with open(rp, "r", encoding="utf-8", errors="replace") as f:
                        text = f.read()
                    found.extend(resolve_imports(rp, text, include_paths, seen))
                    found.append((rp, text))
                break
    return found


def compile_sources(items, emits, include_paths):
    result = {"contracts": {}}
    expanded = []
    seen = set()
    for path, src in items:
        if path != "<stdin>":
            seen.add(os.path.normpath(path))
        expanded.extend(resolve_imports(path, src, include_paths, seen))
        expanded.append((path, src))
    for path, src in expanded:
        src2 = strip_comments(src)
        for kind, cname, body in contracts(src2):
            abi = parse_contract(kind, cname, body)
            entry = {}
            if "abi" in emits:
                entry["abi"] = abi
            if "hashes" in emits:
                hashes = {}
                for it in abi:
                    if it.get("type") == "function":
                        sig = signature(it)
                        hashes[sig] = keccak256(sig.encode()).hex()[:8]
                entry["hashes"] = dict(sorted(hashes.items()))
            result["contracts"][f"{path}:{cname}"] = entry
    result["contracts"] = dict(sorted(result["contracts"].items()))
    result["version"] = VERSION
    return result


def main():
    opts = parse_args(sys.argv[1:])
    if not opts["inputs"]:
        print(HELP_SHORT, file=sys.stderr)
        sys.exit(2)
    sources = []
    for inp in opts["inputs"]:
        if "=" in inp and not os.path.exists(inp):
            continue
        if inp == "-":
            sources.append(("<stdin>", sys.stdin.read()))
        else:
            if not os.path.exists(inp):
                print(f"error: file {inp} not found\n", file=sys.stderr)
                print("error: aborting due to 1 previous error", file=sys.stderr)
                sys.exit(1)
            with open(inp, "r", encoding="utf-8", errors="replace") as f:
                sources.append((inp, f.read()))
    if opts["stop_after"]:
        return
    if not opts["emit"]:
        return
    obj = compile_sources(sources, opts["emit"], opts["include_paths"])
    text = json.dumps(obj, indent=2 if opts["pretty"] else None, separators=None if opts["pretty"] else (",", ":"))
    if opts["pretty"]:
        text += "\n"
    if opts["out_dir"]:
        try:
            with open(os.path.join(opts["out_dir"], "combined.json"), "w", encoding="utf-8") as f:
                f.write(text)
        except OSError as e:
            print(f"error: failed to write to output: {e.strerror} (os error {e.errno})\n", file=sys.stderr)
            print("error: aborting due to 1 previous error", file=sys.stderr)
            sys.exit(1)
    else:
        print(text, end="")


if __name__ == "__main__":
    main()
