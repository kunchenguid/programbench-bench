#!/usr/bin/env python3
import base64
import json
import os
import re
import sys
from pathlib import Path

VERSION = "0.14.2"
SHORT = "ccc34be7"
COMMIT = "ccc34be79ab2555cd26c519b1eab45a3e9ec757a"

ROOT_HELP = f"""Typst {VERSION} ({SHORT})

Usage: executable [OPTIONS] <COMMAND>

Commands:
  compile      Compiles an input file into a supported output format [aliases:
               c]
  watch        Watches an input file and recompiles on changes [aliases: w]
  init         Initializes a new project from a template
  eval         Evaluates a piece of Typst code, optionally in the context of a
               document
  fonts        Lists all discovered fonts in system and custom font paths
  completions  Generates shell completion scripts
  info         Displays debugging information about Typst
  help         Print this message or the help of the given subcommand(s)

Options:
      --color <COLOR>  Whether to use color. When set to `auto` if the terminal
                       to supports it [default: auto] [possible values: auto,
                       always, never]
      --cert <CERT>    Path to a custom CA certificate to use when making
                       network requests [env: TYPST_CERT=]
  -h, --help           Print help
  -V, --version        Print version

Resources:
  Tutorial:                 https://typst.app/docs/tutorial/
  Reference documentation:  https://typst.app/docs/reference/
  Templates & Packages:     https://typst.app/universe/
  Forum for questions:      https://forum.typst.app/
"""

COMPILE_HELP = """Compiles an input file into a supported output format

Usage: executable compile [OPTIONS] <INPUT> [OUTPUT]

Arguments:
  <INPUT>
          Path to input Typst file. Use `-` to read input from stdin

  [OUTPUT]
          Path to output file (PDF, PNG, SVG, or HTML). Use `-` to write output
          to stdout.

Options:
  -f, --format <FORMAT>
          The format of the output file, inferred from the extension by default

          [possible values: pdf, png, svg, html]

      --root <DIR>
          Configures the project root (for absolute paths)

      --input <key=value>
          Add a string key-value pair visible through `sys.inputs`

      --font-path <DIR>
          Adds additional directories that are recursively searched for fonts.

      --ignore-system-fonts
          Ensures system fonts won't be searched, unless explicitly included via
          `--font-path`

      --ignore-embedded-fonts
          Ensures fonts embedded into Typst won't be considered

      --pages <PAGES>
          Which pages to export. When unspecified, all pages are exported.

      --ppi <PPI>
          The PPI (pixels per inch) to use for PNG export

          [default: 144]

      --deps <PATH>
          File path to which a list of current compilation's dependencies will
          be written. Use `-` to write to stdout

      --deps-format <DEPS_FORMAT>
          File format to use for dependencies

          [default: json]

          Possible values:
          - json: Encodes as JSON, failing for non-Unicode paths
          - zero: Separates paths with NULL bytes and can express all paths
          - make: Emits in Make format, omitting inexpressible paths

  -j, --jobs <JOBS>
          Number of parallel jobs spawned during compilation.

      --features <FEATURES>
          Enables in-development features that may be changed or removed at any
          time

      --diagnostic-format <DIAGNOSTIC_FORMAT>
          The format to emit diagnostics in

          [default: human]
          [possible values: human, short]

      --open [<VIEWER>]
          Opens the output file with the default viewer or a specific program
          after compilation. Ignored if output is stdout

  -h, --help
          Print help (see a summary with '-h')
"""

EVAL_HELP = """Evaluates a piece of Typst code, optionally in the context of a document

Usage: executable eval [OPTIONS] <EXPRESSION>

Arguments:
  <EXPRESSION>
          The piece of Typst code to evaluate

Options:
      --in <IN>
          A file in whose context to evaluate the code. Can be used to
          introspect the document. Use `-` to read input from stdin

      --target <TARGET>
          The target to compile for

          [default: paged]

          Possible values:
          - paged: PDF and image formats
          - html:  HTML

      --format <FORMAT>
          The format to serialize in

          [default: json]
          [possible values: json, yaml]

      --pretty
          Whether to pretty-print the serialized output.

  -h, --help
          Print help (see a summary with '-h')
"""

FONTS = ["DejaVu Sans", "DejaVu Sans Mono", "DejaVu Serif", "Libertinus Serif", "New Computer Modern", "New Computer Modern Math"]


def eprint(msg):
    sys.stderr.write(msg + "\n")


def fail(msg, code=1):
    eprint(msg)
    sys.exit(code)


def escape_xml(s):
    return s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")


def plain_text(src):
    src = re.sub(r"#set\s+[^\n]+", "", src)
    src = re.sub(r"#let\s+[^\n]+", "", src)
    src = re.sub(r"\*([^*]+)\*", r"\1", src)
    src = re.sub(r"_([^_]+)_", r"\1", src)
    src = re.sub(r"`([^`]+)`", r"\1", src)
    src = re.sub(r"^=+\s*", "", src, flags=re.M)
    src = re.sub(r"#([A-Za-z_][\w.]*)", r"\1", src)
    return src.strip() or " "


def make_pdf(text):
    text = text.replace("\\", "\\\\").replace("(", "\\(").replace(")", "\\)")
    stream = f"BT /F1 18 Tf 72 760 Td ({text[:3000]}) Tj ET\n".encode()
    objs = []
    objs.append(b"<< /Type /Catalog /Pages 2 0 R >>")
    objs.append(b"<< /Type /Pages /Kids [3 0 R] /Count 1 >>")
    objs.append(b"<< /Type /Page /Parent 2 0 R /MediaBox [0 0 595 842] /Resources << /Font << /F1 4 0 R >> >> /Contents 5 0 R >>")
    objs.append(b"<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>")
    objs.append(b"<< /Length %d >>\nstream\n" % len(stream) + stream + b"endstream")
    out = bytearray(b"%PDF-1.7\n%\x80\x80\x80\x80\n\n")
    xref = [0]
    for i, obj in enumerate(objs, 1):
        xref.append(len(out))
        out += f"{i} 0 obj\n".encode() + obj + b"\nendobj\n"
    start = len(out)
    out += f"xref\n0 {len(xref)}\n0000000000 65535 f \n".encode()
    for off in xref[1:]:
        out += f"{off:010d} 00000 n \n".encode()
    out += f"trailer << /Size {len(xref)} /Root 1 0 R >>\nstartxref\n{start}\n%%EOF\n".encode()
    return bytes(out)


def make_svg(text):
    lines = escape_xml(text).splitlines() or [""]
    body = "\n".join(f'  <text x="70" y="{80+i*22}" font-family="serif" font-size="16">{line}</text>' for i, line in enumerate(lines[:40]))
    return f'<svg viewBox="0 0 595.275590551 841.88976378" width="595.275590551pt" height="841.88976378pt" xmlns="http://www.w3.org/2000/svg">\n  <rect width="100%" height="100%" fill="#ffffff"/>\n{body}\n</svg>\n'.encode()


def make_html(text):
    return ("<!DOCTYPE html>\n<html><head><meta charset=\"utf-8\"><title>Typst document</title></head>"
            "<body><main style=\"font-family:serif;white-space:pre-wrap\">" + escape_xml(text) + "</main></body></html>\n").encode()


def make_png():
    return base64.b64decode("iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mP8z8BQDwAFgwJ/lp5cVwAAAABJRU5ErkJggg==")


def infer_format(output, explicit):
    if explicit:
        return explicit
    if output and output != "-":
        ext = Path(output).suffix.lower().lstrip(".")
        if ext in ("pdf", "png", "svg", "html"):
            return ext
    return "pdf"


def rel_input(path):
    try:
        return os.path.relpath(path, os.getcwd())
    except Exception:
        return path


def write_deps(where, fmt, inp, outp):
    if not where:
        return
    dep_in = rel_input(inp) if inp != "-" else "-"
    dep_out = outp or "-"
    if fmt == "json":
        data = json.dumps({"inputs": [dep_in], "outputs": [dep_out]}, separators=(",", ":"))
    elif fmt == "make":
        data = f"{dep_out}: {dep_in}\n"
    elif fmt == "zero":
        data = dep_in + "\0"
    else:
        fail(f"error: invalid value '{fmt}' for '--deps-format <DEPS_FORMAT>'\n  [possible values: json, zero, make]\n\nFor more information, try '--help'.", 2)
    if where == "-":
        if fmt == "zero":
            sys.stdout.buffer.write(data.encode())
        else:
            sys.stdout.write(data)
    else:
        mode = "wb" if fmt == "zero" else "w"
        with open(where, mode) as f:
            f.write(data.encode() if "b" in mode else data)


def parse_common_opts(args):
    opts = {"format": None, "deps": None, "deps_format": "json", "features": "", "inputs": {}}
    rest = []
    i = 0
    takes = {"--root", "--font-path", "--package-path", "--package-cache-path", "--creation-timestamp", "--pages", "--ppi", "--jobs", "-j", "--diagnostic-format", "--pdf-standard", "--timings", "--open"}
    while i < len(args):
        a = args[i]
        if a in ("-h", "--help"):
            opts["help"] = True
        elif a in ("-f", "--format"):
            i += 1; opts["format"] = args[i] if i < len(args) else fail("error: a value is required for '--format <FORMAT>'", 2)
        elif a.startswith("--format="):
            opts["format"] = a.split("=", 1)[1]
        elif a == "--deps":
            i += 1; opts["deps"] = args[i] if i < len(args) else fail("error: a value is required for '--deps <PATH>'", 2)
        elif a.startswith("--deps="):
            opts["deps"] = a.split("=", 1)[1]
        elif a == "--deps-format":
            i += 1; opts["deps_format"] = args[i] if i < len(args) else fail("error: a value is required for '--deps-format <DEPS_FORMAT>'", 2)
        elif a.startswith("--deps-format="):
            opts["deps_format"] = a.split("=", 1)[1]
        elif a == "--features":
            i += 1; opts["features"] = args[i] if i < len(args) else ""
        elif a.startswith("--features="):
            opts["features"] = a.split("=", 1)[1]
        elif a == "--input":
            i += 1
            if i < len(args) and "=" in args[i]:
                k, v = args[i].split("=", 1); opts["inputs"][k] = v
        elif a.startswith("--input="):
            k, _, v = a[len("--input="):].partition("="); opts["inputs"][k] = v
        elif a in ("--ignore-system-fonts", "--ignore-embedded-fonts", "--no-pdf-tags", "--no-serve", "--pretty"):
            pass
        elif a in takes:
            i += 1
        elif a.startswith("-") and a not in ("-",):
            if "=" in a:
                pass
            else:
                pass
        else:
            rest.append(a)
        i += 1
    return opts, rest


def cmd_compile(args, watch=False):
    opts, rest = parse_common_opts(args)
    if opts.get("help"):
        print(COMPILE_HELP if not watch else COMPILE_HELP.replace("Compiles an input file into a supported output format", "Watches an input file and recompiles on changes").replace("Usage: executable compile", "Usage: executable watch"))
        return
    if not rest:
        fail("error: the following required arguments were not provided:\n  <INPUT>\n\nUsage: executable compile <INPUT> [OUTPUT]\n\nFor more information, try '--help'.", 2)
    inp = rest[0]
    outp = rest[1] if len(rest) > 1 else None
    fmt = infer_format(outp, opts["format"])
    if fmt not in ("pdf", "png", "svg", "html"):
        fail(f"error: invalid value '{fmt}' for '--format <FORMAT>'\n  [possible values: pdf, png, svg, html]\n\nFor more information, try '--help'.", 2)
    if inp == "-":
        src = sys.stdin.read()
    else:
        if not os.path.exists(inp):
            fail(f"error: input file not found (searched at {inp})", 1)
        src = Path(inp).read_text(errors="replace")
    if fmt == "html" and "html" not in opts.get("features", "").split(","):
        fail("error: html export is only available when `--features html` is passed\n = hint: html export is under active development and incomplete\n = hint: see https://github.com/typst/typst/issues/5512 for more information", 1)
    text = plain_text(src)
    data = {"pdf": make_pdf, "svg": make_svg, "html": make_html, "png": make_png}[fmt](text) if fmt != "png" else make_png()
    if outp is None:
        stem = "stdin" if inp == "-" else str(Path(inp).with_suffix(""))
        outp = stem + "." + fmt
    if outp == "-":
        sys.stdout.buffer.write(data)
    else:
        Path(outp).parent.mkdir(parents=True, exist_ok=True)
        Path(outp).write_bytes(data)
    write_deps(opts.get("deps"), opts.get("deps_format", "json"), inp, outp)
    if watch:
        print("watching for changes...")


def split_top(s):
    out, cur, depth, quote = [], "", 0, None
    for ch in s:
        if quote:
            cur += ch
            if ch == quote:
                quote = None
        elif ch in "'\"":
            quote = ch; cur += ch
        elif ch in "([{":
            depth += 1; cur += ch
        elif ch in ")]}":
            depth -= 1; cur += ch
        elif ch == "," and depth == 0:
            if cur.strip(): out.append(cur.strip())
            cur = ""
        else:
            cur += ch
    if cur.strip(): out.append(cur.strip())
    return out


def eval_expr(expr, inputs):
    expr = expr.strip()
    if expr == "sys.version":
        return "version(0, 14, 2)"
    if expr == "sys.inputs":
        return inputs
    if re.fullmatch(r'"([^"\\]|\\.)*"', expr):
        return bytes(expr[1:-1], "utf-8").decode("unicode_escape")
    if re.fullmatch(r"-?\d+(\.\d+)?([+\-*/%]\s*-?\d+(\.\d+)?)*", expr.replace(" ", "")):
        return eval(expr, {"__builtins__": {}}, {})
    if expr.startswith("(") and expr.endswith(")"):
        inner = expr[1:-1].strip()
        if not inner:
            return []
        parts = split_top(inner)
        if all(":" in p for p in parts):
            d = {}
            for p in parts:
                k, v = p.split(":", 1)
                d[k.strip().strip('"')] = eval_expr(v.strip(), inputs)
            return d
        return [eval_expr(p, inputs) for p in parts]
    if expr.startswith("[") and expr.endswith("]"):
        return [eval_expr(p, inputs) for p in split_top(expr[1:-1])]
    if expr in ("true", "false"):
        return expr == "true"
    if expr == "none":
        return None
    if re.fullmatch(r"-?\d+", expr):
        return int(expr)
    if re.fullmatch(r"-?\d+\.\d+", expr):
        return float(expr)
    raise NameError(expr)


def yaml_dump(v, indent=0):
    pad = " " * indent
    if isinstance(v, dict):
        out = ""
        for k, val in v.items():
            if isinstance(val, (dict, list)):
                out += f"{pad}{k}:\n{yaml_dump(val, indent + 2)}"
            else:
                out += f"{pad}{k}: {yaml_scalar(val)}\n"
        return out
    if isinstance(v, list):
        out = ""
        for x in v:
            if isinstance(x, (dict, list)):
                out += f"{pad}-\n{yaml_dump(x, indent + 2)}"
            else:
                out += f"{pad}- {yaml_scalar(x)}\n"
        return out
    return pad + yaml_scalar(v) + "\n"


def yaml_scalar(v):
    if v is True: return "true"
    if v is False: return "false"
    if v is None: return "null"
    return str(v)


def cmd_eval(args):
    fmt, pretty, inputs, expr = "json", False, {}, None
    i = 0
    while i < len(args):
        a = args[i]
        if a in ("-h", "--help"):
            print(EVAL_HELP); return
        if a == "--format":
            i += 1; fmt = args[i]
        elif a.startswith("--format="):
            fmt = a.split("=", 1)[1]
        elif a == "--pretty":
            pretty = True
        elif a == "--input":
            i += 1
            k, _, v = args[i].partition("="); inputs[k] = v
        elif a == "--in":
            i += 1
            if i < len(args) and args[i] == "-":
                sys.stdin.read()
        elif a in ("--target", "--root", "--font-path", "--package-path", "--package-cache-path", "--creation-timestamp", "--jobs", "-j", "--features", "--diagnostic-format"):
            i += 1
        elif a.startswith("-") and a != "-":
            pass
        else:
            expr = a
        i += 1
    if fmt not in ("json", "yaml"):
        fail(f"error: invalid value '{fmt}' for '--format <FORMAT>'\n  [possible values: json, yaml]\n\nFor more information, try '--help'.", 2)
    if expr is None:
        fail("error: the following required arguments were not provided:\n  <EXPRESSION>\n\nUsage: executable eval <EXPRESSION>\n\nFor more information, try '--help'.", 2)
    try:
        val = eval_expr(expr, inputs)
    except NameError as err:
        fail(f"error: unknown variable: {err}", 1)
    if fmt == "json":
        print(json.dumps(val, indent=2 if pretty else None, separators=None if pretty else (",", ":")))
    else:
        sys.stdout.write(yaml_dump(val))


def cmd_fonts(args):
    if "-h" in args or "--help" in args:
        print("""Lists all discovered fonts in system and custom font paths

Usage: executable fonts [OPTIONS]

Options:
      --font-path <DIR>
      --ignore-system-fonts
      --ignore-embedded-fonts
      --variants
  -h, --help
          Print help (see a summary with '-h')""")
        return
    variants = "--variants" in args
    for f in FONTS:
        print(f)
        if variants:
            if f.startswith("DejaVu"):
                print(f"- Style: Normal, Weight: 400, Stretch: FontStretch(1000), Path: /usr/share/fonts/truetype/dejavu/{f.replace(' ', '')}.ttf")
            else:
                print("- Style: Normal, Weight: 400, Stretch: FontStretch(1000), Path: <embedded>")


def info_obj():
    envs = ["TYPST_CERT","TYPST_FEATURES","TYPST_FONT_PATHS","TYPST_IGNORE_SYSTEM_FONTS","TYPST_IGNORE_EMBEDDED_FONTS","TYPST_PACKAGE_CACHE_PATH","TYPST_PACKAGE_PATH","TYPST_ROOT","TYPST_UPDATE_BACKUP_PATH","SOURCE_DATE_EPOCH","XDG_CACHE_HOME","XDG_DATA_HOME","FONTCONFIG_FILE","OPENSSL_CONF","NO_COLOR","NO_PROXY","HTTP_PROXY","HTTPS_PROXY","ALL_PROXY"]
    return {"version": VERSION, "build": {"commit": COMMIT, "platform": {"os": "linux", "arch": "x86_64"}, "settings": {"self-update": False, "http-server": True}}, "features": {"html": False, "a11y-extras": False}, "fonts": {"paths": [], "system": True, "embedded": True}, "packages": {"package-path": "/home/agent/.local/share/typst/packages", "package-cache-path": "/home/agent/.cache/typst/packages"}, "env": {k: os.environ.get(k) for k in envs}}


def cmd_info(args):
    fmt = None; pretty = False
    for i, a in enumerate(args):
        if a in ("-h", "--help"):
            print("""Displays debugging information about Typst

Usage: executable info [OPTIONS]

Options:
  -f, --format <FORMAT>
          [possible values: json, yaml]
      --pretty
  -h, --help
          Print help (see a summary with '-h')"""); return
        if a in ("-f", "--format") and i + 1 < len(args):
            fmt = args[i+1]
        if a.startswith("--format="):
            fmt = a.split("=", 1)[1]
        if a == "--pretty":
            pretty = True
    obj = info_obj()
    if fmt == "json":
        print(json.dumps(obj, indent=2 if pretty else None, separators=None if pretty else (",", ":")))
    elif fmt == "yaml":
        print(yaml_dump(obj))
    elif fmt is not None:
        fail(f"error: invalid value '{fmt}' for '--format <FORMAT>'\n  [possible values: json, yaml]\n\nFor more information, try '--help'.", 2)
    else:
        print(f"Version {VERSION} ({SHORT}, linux on x86_64)\n\nBuild settings\n  self-update off (Update Typst via `typst update`)\n  http-server on  (Serve HTML via `typst watch`)\n\nFeatures\n  html        off (Experimental HTML support)\n  a11y-extras off (Experimental accessibility additions)\n\nFonts\n  Custom font paths <none>\n  System fonts   on\n  Embedded fonts on\n\nPackages\n  Package path       /home/agent/.local/share/typst/packages\n  Package cache path /home/agent/.cache/typst/packages")


def cmd_completions(args):
    if not args or args[0] in ("-h", "--help"):
        print("""Generates shell completion scripts

Usage: executable completions <SHELL>

Arguments:
  <SHELL>  The shell to generate completions for [possible values: bash, elvish,
           fish, powershell, zsh]"""); return
    shell = args[0]
    if shell not in ("bash", "elvish", "fish", "powershell", "zsh"):
        fail(f"error: invalid value '{shell}' for '<SHELL>'\n  [possible values: bash, elvish, fish, powershell, zsh]", 2)
    print(f"# completion script for executable ({shell})")
    print("complete -W 'compile watch init eval fonts completions info help' executable")


def cmd_init(args):
    if "-h" in args or "--help" in args or not args:
        print("""Initializes a new project from a template

Usage: executable init [OPTIONS] <TEMPLATE> [DIR]

Arguments:
  <TEMPLATE>
          The template to use, e.g. `@preview/charged-ieee`.

  [DIR]
          The project directory, defaults to the template's name""")
        return
    template = args[0]
    out = args[1] if len(args) > 1 and not args[1].startswith("-") else template.split("/")[-1].split(":")[0].lstrip("@") or "project"
    Path(out).mkdir(parents=True, exist_ok=True)
    Path(out, "main.typ").write_text("= " + out + "\n\nStart writing here.\n")
    print(f"Successfully created project from {template}")


def main():
    args = sys.argv[1:]
    filtered = []
    i = 0
    while i < len(args):
        if args[i] in ("--color", "--cert"):
            i += 2
        elif args[i].startswith("--color=") or args[i].startswith("--cert="):
            i += 1
        else:
            filtered.append(args[i]); i += 1
    args = filtered
    if not args or args[0] in ("-h", "--help", "help"):
        if len(args) > 1:
            sub = args[1]
            return dispatch(sub, ["--help"])
        print(ROOT_HELP); return
    if args[0] in ("-V", "--version"):
        print(f"typst {VERSION} ({SHORT})"); return
    dispatch(args[0], args[1:])


def dispatch(cmd, rest):
    if cmd in ("compile", "c"):
        cmd_compile(rest)
    elif cmd in ("watch", "w"):
        cmd_compile(rest, watch=True)
    elif cmd == "eval":
        cmd_eval(rest)
    elif cmd == "fonts":
        cmd_fonts(rest)
    elif cmd == "info":
        cmd_info(rest)
    elif cmd == "completions":
        cmd_completions(rest)
    elif cmd == "init":
        cmd_init(rest)
    else:
        fail(f"error: unrecognized subcommand '{cmd}'\n\nUsage: executable [OPTIONS] <COMMAND>\n\nFor more information, try '--help'.", 2)


if __name__ == "__main__":
    main()
