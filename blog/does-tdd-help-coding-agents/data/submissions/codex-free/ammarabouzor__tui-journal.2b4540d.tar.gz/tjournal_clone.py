#!/usr/bin/env python3
import json
import os
import re
import shutil
import sqlite3
import sys
from pathlib import Path


VERSION = "tui-journal 0.16.1"
HOME = os.path.expanduser("~")
DEFAULT_CONFIG_DIR = os.path.join(HOME, ".config", "tui-journal")
DEFAULT_LOG = os.path.join(HOME, ".cache", "tui-journal", "tui-journal.log")
DEFAULT_JSON = os.path.join(HOME, "tui-journal", "entries.json")
DEFAULT_SQLITE = os.path.join(HOME, "tui-journal", "entries.db")
DEFAULT_STATE = os.path.join(HOME, ".local", "state", "tui-journal")

THEME_DEFAULT = """[general.input_block_active]
fg = "LightYellow"
modifiers = ""

[general.input_block_invalid]
fg = "LightRed"
modifiers = ""

[general.input_corsur_active]
fg = "Black"
bg = "LightYellow"
modifiers = ""

[general.input_corsur_invalid]
fg = "Black"
bg = "LightRed"
modifiers = ""

[general.list_item_selected]
fg = "LightYellow"
modifiers = "BOLD"

[general.list_highlight_active]
fg = "Black"
bg = "LightGreen"
modifiers = ""

[general.list_highlight_inactive]
fg = "Black"
bg = "LightBlue"
modifiers = ""

[journals_list.block_active]
fg = "Reset"
modifiers = "BOLD"

[journals_list.block_inactive]
fg = "#AAAAC8"
modifiers = ""

[journals_list.block_multi_select]
fg = "Yellow"
modifiers = "BOLD | ITALIC"

[journals_list.highlight_active]
fg = "Black"
bg = "LightGreen"
modifiers = "BOLD"

[journals_list.highlight_inactive]
fg = "Black"
bg = "LightBlue"
modifiers = "BOLD"

[journals_list.title_active]
fg = "Reset"
modifiers = "BOLD"

[journals_list.title_inactive]
fg = "#AAAAC8"
modifiers = "BOLD"

[journals_list.title_selected]
fg = "Yellow"
modifiers = "BOLD"

[journals_list.date_priority]
fg = "LightBlue"
modifiers = ""

[journals_list.tags_default]
fg = "LightCyan"
modifiers = "DIM"

[editor.block_insert]
fg = "LightGreen"
modifiers = "BOLD"

[editor.block_visual]
fg = "Blue"
modifiers = "BOLD"

[editor.block_normal_active]
fg = "Reset"
modifiers = "BOLD"

[editor.block_normal_inactive]
fg = "#AAAAC8"
modifiers = ""

[editor.cursor_normal]
fg = "Black"
bg = "White"
modifiers = ""

[editor.cursor_insert]
fg = "Black"
bg = "LightGreen"
modifiers = ""

[editor.cursor_visual]
fg = "Black"
bg = "Blue"
modifiers = ""

[editor.selection_style]
fg = "Black"
bg = "White"
modifiers = ""

[msgbox]
error = "LightRed"
warning = "Yellow"
info = "LightGreen"
question = "LightBlue"
"""


HELP = """Tui app allows writing and managing journals/notes from within the terminal With different local back-ends

Usage: executable [OPTIONS] [COMMAND]

Commands:
  print-config     Print the current settings including the paths for the back-end files [aliases: pc]
  import-journals  Import journals from the given transfer JSON file to the current back-end file [aliases: imj]
  assign-priority  Assign priority for all the entries with empty priority field [aliases: ap]
  theme            Provides commands regarding changing themes and styles of the app [aliases: style]
  help             Print this message or the help of the given subcommand(s)

Options:
  -j, --json-file-path <FILE PATH>    Sets the entries Json file path and starts using it
  -s, --sqlite-file-path <FILE PATH>  Sets the entries sqlite file path and starts using it
  -b, --backend-type <BACKEND_TYPE>   Sets the backend type and starts using it [possible values: json, sqlite]
  -c, --config <DIR PATH>             Specifies the path for the configuration directory.
                                      Configuration files is considered as root for themes file too.
                                      It still accepts the path for configuration file for backward compatibility.
                                      (default path: /home/agent/.config/tui-journal)
  -v, --verbose...                    Increases logging verbosity each use for up to 3 times
  -l, --log <FILE PATH>               Specifies a file to use for logging
                                      (default file: /home/agent/.cache/tui-journal/tui-journal.log)
  -h, --help                          Print help
  -V, --version                       Print version"""

THEME_HELP = """Provides commands regarding changing themes and styles of the app

Usage: executable theme <COMMAND>

Commands:
  print-path      Prints the path to the user themes file [aliases: path]
  print-default   Dumps the styles with the default values to be used as a reference and base for user custom themes [aliases: default]
  write-defaults  Creates user custom themes file if doesn't exist then writes the default styles to it [aliases: write]
  help            Print this message or the help of the given subcommand(s)

Options:
  -h, --help  Print help"""


def eprint(msg):
    print(msg, file=sys.stderr)


def fail(msg, code=2):
    eprint(msg)
    sys.exit(code)


def parse_value(v):
    v = v.strip()
    if len(v) >= 2 and v[0] == v[-1] == '"':
        return v[1:-1]
    if v == "true":
        return True
    if v == "false":
        return False
    try:
        return int(v)
    except ValueError:
        return v


def read_config(path):
    cfg = default_config()
    config_file = path if path.endswith(".toml") else os.path.join(path, "config.toml")
    if not os.path.exists(config_file):
        return cfg
    section = None
    for raw in Path(config_file).read_text(errors="replace").splitlines():
        line = raw.split("#", 1)[0].strip()
        if not line:
            continue
        m = re.match(r"^\[([A-Za-z0-9_.-]+)\]$", line)
        if m:
            section = m.group(1)
            continue
        if "=" not in line:
            continue
        key, val = [p.strip() for p in line.split("=", 1)]
        target = cfg if section is None else cfg.setdefault(section, {})
        target[key] = parse_value(val)
    return cfg


def default_config():
    return {
        "backend_type": "Sqlite",
        "scroll_per_page": 5,
        "sync_os_clipboard": False,
        "history_limit": 10,
        "colored_tags": True,
        "datum_visibility": "show",
        "app_state_dir": DEFAULT_STATE,
        "export": {"show_confirmation": True},
        "external_editor": {"auto_save": False, "temp_file_extension": "txt"},
        "json_backend": {"file_path": DEFAULT_JSON},
        "sqlite_backend": {"file_path": DEFAULT_SQLITE},
    }


def bool_s(v):
    return "true" if bool(v) else "false"


def print_config(cfg):
    print(f'backend_type = "{cfg.get("backend_type", "Sqlite")}"')
    print(f'scroll_per_page = {cfg.get("scroll_per_page", 5)}')
    print(f'sync_os_clipboard = {bool_s(cfg.get("sync_os_clipboard", False))}')
    print(f'history_limit = {cfg.get("history_limit", 10)}')
    print(f'colored_tags = {bool_s(cfg.get("colored_tags", True))}')
    print(f'datum_visibility = "{cfg.get("datum_visibility", "show")}"')
    print(f'app_state_dir = "{cfg.get("app_state_dir", DEFAULT_STATE)}"')
    print()
    print("[export]")
    print(f'show_confirmation = {bool_s(cfg.get("export", {}).get("show_confirmation", True))}')
    print()
    print("[external_editor]")
    ee = cfg.get("external_editor", {})
    print(f'auto_save = {bool_s(ee.get("auto_save", False))}')
    print(f'temp_file_extension = "{ee.get("temp_file_extension", "txt")}"')
    print()
    print("[json_backend]")
    print(f'file_path = "{cfg.get("json_backend", {}).get("file_path", DEFAULT_JSON)}"')
    print()
    print("[sqlite_backend]")
    print(f'file_path = "{cfg.get("sqlite_backend", {}).get("file_path", DEFAULT_SQLITE)}"')


def load_json_entries(path):
    if not os.path.exists(path) or os.path.getsize(path) == 0:
        return []
    with open(path, "r", encoding="utf-8") as f:
        data = json.load(f)
    if isinstance(data, list):
        return data
    if isinstance(data, dict):
        for key in ("entries", "journals", "items"):
            if isinstance(data.get(key), list):
                return data[key]
    return []


def save_json_entries(path, entries):
    os.makedirs(os.path.dirname(path) or ".", exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        json.dump(entries, f, ensure_ascii=False, indent=2)
        f.write("\n")


def sqlite_connect(path):
    os.makedirs(os.path.dirname(path) or ".", exist_ok=True)
    con = sqlite3.connect(path)
    con.execute(
        "create table if not exists journals ("
        "id integer primary key autoincrement, "
        "data text not null, "
        "priority integer)"
    )
    return con


def import_entries(cfg, src):
    with open(src, "r", encoding="utf-8") as f:
        data = json.load(f)
    if isinstance(data, dict):
        entries = data.get("entries") or data.get("journals") or data.get("items") or []
    else:
        entries = data
    if not isinstance(entries, list):
        raise ValueError("transfer JSON must contain an array")
    if cfg.get("backend_type") == "Json":
        path = cfg["json_backend"]["file_path"]
        current = load_json_entries(path)
        current.extend(entries)
        save_json_entries(path, current)
    else:
        path = cfg["sqlite_backend"]["file_path"]
        con = sqlite_connect(path)
        for entry in entries:
            prio = entry.get("priority") if isinstance(entry, dict) else None
            con.execute("insert into journals(data, priority) values(?, ?)", (json.dumps(entry), prio))
        con.commit()
        con.close()


def is_empty_priority(v):
    return v is None or v == "" or v == 0


def assign_priority(cfg, priority):
    if cfg.get("backend_type") == "Json":
        path = cfg["json_backend"]["file_path"]
        entries = load_json_entries(path)
        changed = False
        for entry in entries:
            if isinstance(entry, dict) and is_empty_priority(entry.get("priority")):
                entry["priority"] = priority
                changed = True
        if changed or not os.path.exists(path):
            save_json_entries(path, entries)
    else:
        path = cfg["sqlite_backend"]["file_path"]
        con = sqlite_connect(path)
        cols = [row[1] for row in con.execute("pragma table_info(journals)")]
        if "priority" in cols:
            con.execute("update journals set priority=? where priority is null or priority=0", (priority,))
        con.commit()
        con.close()


def config_dir_for_theme(config_path):
    return os.path.dirname(config_path) if config_path.endswith(".toml") else config_path


def consume_global(argv):
    cfg_path = DEFAULT_CONFIG_DIR
    rest = []
    overrides = []
    i = 0
    while i < len(argv):
        a = argv[i]
        if a in ("-h", "--help"):
            print(HELP)
            sys.exit(0)
        if a in ("-V", "--version"):
            print(VERSION)
            sys.exit(0)
        if a in ("-c", "--config", "-j", "--json-file-path", "-s", "--sqlite-file-path", "-b", "--backend-type", "-l", "--log"):
            if i + 1 >= len(argv):
                fail(f"error: a value is required for '{a} <...>' but none was supplied\n\nFor more information, try '--help'.")
            val = argv[i + 1]
            if a in ("-c", "--config"):
                cfg_path = val
            else:
                overrides.append((a, val))
            i += 2
            continue
        if a.startswith("-v") and set(a[1:]) == {"v"}:
            i += 1
            continue
        rest.extend(argv[i:])
        break
    cfg = read_config(cfg_path)
    for a, val in overrides:
        if a in ("-j", "--json-file-path"):
            cfg["backend_type"] = "Json"
            cfg["json_backend"]["file_path"] = val
        elif a in ("-s", "--sqlite-file-path"):
            cfg["backend_type"] = "Sqlite"
            cfg["sqlite_backend"]["file_path"] = val
        elif a in ("-b", "--backend-type"):
            if val not in ("json", "sqlite"):
                fail(f"error: invalid value '{val}' for '--backend-type <BACKEND_TYPE>'\n  [possible values: json, sqlite]\n\nFor more information, try '--help'.")
            cfg["backend_type"] = "Json" if val == "json" else "Sqlite"
    return cfg_path, cfg, rest


def main():
    cfg_path, cfg, args = consume_global(sys.argv[1:])
    if not args:
        print("TUI mode is not available in this reimplementation. Use --help for command-line options.")
        return 0
    cmd = args[0]
    rest = args[1:]
    if cmd == "help":
        if rest and rest[0] in ("theme", "style"):
            print(THEME_HELP)
        elif rest and rest[0] in ("print-config", "pc"):
            print("Print the current settings including the paths for the back-end files\n\nUsage: executable print-config\n\nOptions:\n  -h, --help  Print help")
        elif rest and rest[0] in ("import-journals", "imj"):
            print("Import journals from the given transfer JSON file to the current back-end file\n\nUsage: executable import-journals --path <FILE PATH>\n\nOptions:\n  -p, --path <FILE PATH>  Path of the JSON file to import from\n  -h, --help              Print help")
        elif rest and rest[0] in ("assign-priority", "ap"):
            print("Assign priority for all the entries with empty priority field\n\nUsage: executable assign-priority <PRIORITY>\n\nArguments:\n  <PRIORITY>  Priority value (Positive number)\n\nOptions:\n  -h, --help  Print help")
        else:
            print(HELP)
    elif cmd in ("print-config", "pc"):
        if rest and rest[0] in ("-h", "--help"):
            print("Print the current settings including the paths for the back-end files\n\nUsage: executable print-config\n\nOptions:\n  -h, --help  Print help")
        else:
            print_config(cfg)
    elif cmd in ("theme", "style"):
        if not rest or rest[0] in ("-h", "--help", "help"):
            print(THEME_HELP)
        elif rest[0] in ("print-path", "path"):
            print(os.path.join(config_dir_for_theme(cfg_path), "themes.toml"))
        elif rest[0] in ("print-default", "default"):
            print(THEME_DEFAULT)
        elif rest[0] in ("write-defaults", "write"):
            p = os.path.join(config_dir_for_theme(cfg_path), "themes.toml")
            os.makedirs(os.path.dirname(p), exist_ok=True)
            Path(p).write_text(THEME_DEFAULT, encoding="utf-8")
            print(f"Default themes have been written to {p}")
        else:
            fail(f"error: unrecognized subcommand '{rest[0]}'\n\nUsage: executable theme <COMMAND>\n\nFor more information, try '--help'.")
    elif cmd in ("import-journals", "imj"):
        if rest and rest[0] in ("-h", "--help"):
            print("Import journals from the given transfer JSON file to the current back-end file\n\nUsage: executable import-journals --path <FILE PATH>\n\nOptions:\n  -p, --path <FILE PATH>  Path of the JSON file to import from\n  -h, --help              Print help")
        else:
            src = None
            i = 0
            while i < len(rest):
                if rest[i] in ("-p", "--path") and i + 1 < len(rest):
                    src = rest[i + 1]
                    i += 2
                else:
                    i += 1
            if not src:
                fail("error: the following required arguments were not provided:\n  --path <FILE PATH>\n\nUsage: executable import-journals --path <FILE PATH>\n\nFor more information, try '--help'.")
            try:
                import_entries(cfg, src)
            except Exception as ex:
                eprint(f"Error: {ex}")
                return 1
    elif cmd in ("assign-priority", "ap"):
        if rest and rest[0] in ("-h", "--help"):
            print("Assign priority for all the entries with empty priority field\n\nUsage: executable assign-priority <PRIORITY>\n\nArguments:\n  <PRIORITY>  Priority value (Positive number)\n\nOptions:\n  -h, --help  Print help")
        else:
            if not rest:
                fail("error: the following required arguments were not provided:\n  <PRIORITY>\n\nUsage: executable assign-priority <PRIORITY>\n\nFor more information, try '--help'.")
            val = rest[0]
            if val == "--" and len(rest) > 1:
                val = rest[1]
            try:
                priority = int(val)
            except ValueError:
                fail(f"error: invalid value '{val}' for '<PRIORITY>': invalid digit found in string\n\nFor more information, try '--help'.")
            if priority < 0:
                fail(f"error: invalid value '{val}' for '<PRIORITY>': {val} is not in 0..=4294967295\n\nFor more information, try '--help'.")
            assign_priority(cfg, priority)
    else:
        fail(f"error: unrecognized subcommand '{cmd}'\n\nUsage: executable [OPTIONS] [COMMAND]\n\nFor more information, try '--help'.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
