#!/usr/bin/env python3
import html
import json
import os
import re
import sys

VERSION = """pandoc 3.9.0.2
Features: +server +lua
Scripting engine: Lua 5.4
User data directory: /home/agent/.local/share/pandoc
Copyright (C) 2006-2025 John MacFarlane. Web:  https://pandoc.org
This is free software; see the source for copying conditions. There is no
warranty, not even for merchantability or fitness for a particular purpose.
"""

INPUT_FORMATS = """asciidoc
biblatex
bibtex
bits
commonmark
commonmark_x
creole
csljson
csv
djot
docbook
docx
dokuwiki
endnotexml
epub
fb2
gfm
haddock
html
ipynb
jats
jira
json
latex
man
markdown
markdown_github
markdown_mmd
markdown_phpextra
markdown_strict
mdoc
mediawiki
muse
native
odt
opml
org
pod
pptx
ris
rst
rtf
t2t
textile
tikiwiki
tsv
twiki
typst
vimwiki
xlsx
xml
"""

OUTPUT_FORMATS = """ansi
asciidoc
asciidoc_legacy
asciidoctor
bbcode
bbcode_fluxbb
bbcode_hubzilla
bbcode_phpbb
bbcode_steam
bbcode_xenforo
beamer
biblatex
bibtex
chunkedhtml
commonmark
commonmark_x
context
csljson
djot
docbook
docbook4
docbook5
docx
dokuwiki
dzslides
epub
epub2
epub3
fb2
gfm
haddock
html
html4
html5
icml
ipynb
jats
jats_archiving
jats_articleauthoring
jats_publishing
jira
json
latex
man
markdown
markdown_github
markdown_mmd
markdown_phpextra
markdown_strict
markua
mediawiki
ms
muse
native
odt
opendocument
opml
org
pdf
plain
pptx
revealjs
rst
rtf
s5
slideous
slidy
tei
texinfo
textile
typst
vimdoc
xml
xwiki
zimwiki
"""

HELP = """executable [OPTIONS] [FILES]
  -f FORMAT, -r FORMAT  --from=FORMAT, --read=FORMAT
  -t FORMAT, -w FORMAT  --to=FORMAT, --write=FORMAT
  -o FILE               --output=FILE
                        --data-dir=DIRECTORY
  -M KEY[:VALUE]        --metadata=KEY[:VALUE]
                        --metadata-file=FILE
  -d FILE               --defaults=FILE
                        --file-scope[=true|false]
                        --sandbox[=true|false]
  -s[true|false]        --standalone[=true|false]
                        --template=FILE
  -V KEY[:VALUE]        --variable=KEY[:VALUE]
                        --variable-json=KEY[:JSON]
                        --wrap=auto|none|preserve
                        --ascii[=true|false]
                        --toc[=true|false], --table-of-contents[=true|false]
                        --toc-depth=NUMBER
                        --lof[=true|false], --list-of-figures[=true|false]
                        --lot[=true|false], --list-of-tables[=true|false]
  -N[true|false]        --number-sections[=true|false]
                        --number-offset=NUMBERS
                        --top-level-division=section|chapter|part
                        --extract-media=PATH
                        --resource-path=SEARCHPATH
  -H FILE               --include-in-header=FILE
  -B FILE               --include-before-body=FILE
  -A FILE               --include-after-body=FILE
                        --no-highlight
                        --highlight-style=STYLE|FILE
                        --syntax-definition=FILE
                        --syntax-highlighting=none|default|idiomatic|<stylename>|<themepath>
                        --dpi=NUMBER
                        --eol=crlf|lf|native
                        --columns=NUMBER
  -p[true|false]        --preserve-tabs[=true|false]
                        --tab-stop=NUMBER
                        --pdf-engine=PROGRAM
                        --pdf-engine-opt=STRING
                        --reference-doc=FILE
                        --self-contained[=true|false]
                        --embed-resources[=true|false]
                        --link-images[=true|false]
                        --request-header=NAME:VALUE
                        --no-check-certificate[=true|false]
                        --abbreviations=FILE
                        --indented-code-classes=STRING
                        --default-image-extension=extension
  -F PROGRAM            --filter=PROGRAM
  -L SCRIPTPATH         --lua-filter=SCRIPTPATH
                        --shift-heading-level-by=NUMBER
                        --base-header-level=NUMBER
                        --track-changes=accept|reject|all
                        --strip-comments[=true|false]
                        --reference-links[=true|false]
                        --reference-location=block|section|document
                        --figure-caption-position=above|below
                        --table-caption-position=above|below
                        --markdown-headings=setext|atx
                        --list-tables[=true|false]
                        --listings[=true|false]
  -i[true|false]        --incremental[=true|false]
                        --slide-level=NUMBER
                        --section-divs[=true|false]
                        --html-q-tags[=true|false]
                        --email-obfuscation=none|javascript|references
                        --id-prefix=STRING
  -T STRING             --title-prefix=STRING
  -c URL                --css=URL
                        --epub-subdirectory=DIRNAME
                        --epub-cover-image=FILE
                        --epub-title-page[=true|false]
                        --epub-metadata=FILE
                        --epub-embed-font=FILE
                        --split-level=NUMBER
                        --chunk-template=PATHTEMPLATE
                        --epub-chapter-level=NUMBER
                        --ipynb-output=all|none|best
  -C                    --citeproc
                        --bibliography=FILE
                        --csl=FILE
                        --citation-abbreviations=FILE
                        --natbib
                        --biblatex
                        --mathml
                        --webtex[=URL]
                        --mathjax[=URL]
                        --katex[=URL]
                        --gladtex
                        --trace[=true|false]
                        --dump-args[=true|false]
                        --ignore-args[=true|false]
                        --verbose
                        --quiet
                        --fail-if-warnings[=true|false]
                        --log=FILE
                        --bash-completion
                        --list-input-formats
                        --list-output-formats
                        --list-extensions[=FORMAT]
                        --list-highlight-languages
                        --list-highlight-styles
  -D FORMAT             --print-default-template=FORMAT
                        --print-default-data-file=FILE
                        --print-highlight-style=STYLE|FILE
  -v                    --version
  -h                    --help
"""

SUPPORTED_IN = set(INPUT_FORMATS.split())
SUPPORTED_OUT = set(OUTPUT_FORMATS.split())


def die(msg, code):
    sys.stderr.write(msg + "\n")
    raise SystemExit(code)


def slugify(s):
    s = re.sub(r"<[^>]+>", "", s)
    s = re.sub(r"[^\w\s-]", "", s.lower(), flags=re.UNICODE)
    s = re.sub(r"\s+", "-", s.strip())
    return s


def strip_meta(text):
    lines = text.splitlines()
    if lines and lines[0].strip() == "---":
        for i in range(1, min(len(lines), 80)):
            if lines[i].strip() in ("---", "..."):
                return "\n".join(lines[i + 1:]).lstrip("\n")
    while lines and lines[0].startswith("%"):
        lines.pop(0)
    return "\n".join(lines)


def inline_html(s):
    s = html.escape(s, quote=False)
    s = re.sub(r"`([^`]+)`", lambda m: "<code>" + m.group(1) + "</code>", s)
    s = re.sub(r"!\[([^\]]*)\]\(([^)]+)\)", lambda m: f'<img src="{html.escape(m.group(2), quote=True)}" alt="{html.escape(m.group(1), quote=True)}" />', s)
    s = re.sub(r"\[([^\]]+)\]\(([^)]+)\)", lambda m: f'<a href="{html.escape(m.group(2), quote=True)}">{m.group(1)}</a>', s)
    s = re.sub(r"\*\*([^*]+)\*\*", r"<strong>\1</strong>", s)
    s = re.sub(r"__([^_]+)__", r"<strong>\1</strong>", s)
    s = re.sub(r"(?<!\*)\*([^*]+)\*(?!\*)", r"<em>\1</em>", s)
    s = re.sub(r"(?<!_)_([^_]+)_(?!_)", r"<em>\1</em>", s)
    return s


def inline_plain(s):
    s = re.sub(r"!\[([^\]]*)\]\(([^)]+)\)", r"\1", s)
    s = re.sub(r"\[([^\]]+)\]\(([^)]+)\)", r"\1", s)
    s = re.sub(r"`([^`]+)`", r"\1", s)
    s = re.sub(r"\*\*([^*]+)\*\*", r"\1", s)
    s = re.sub(r"__([^_]+)__", r"\1", s)
    s = re.sub(r"(?<!\*)\*([^*]+)\*(?!\*)", r"\1", s)
    s = re.sub(r"(?<!_)_([^_]+)_(?!_)", r"\1", s)
    return html.unescape(re.sub(r"<[^>]+>", "", s))


def tex_escape(s):
    repl = {
        "\\": r"\textbackslash{}",
        "&": r"\&",
        "%": r"\%",
        "$": r"\$",
        "#": r"\#",
        "_": r"\_",
        "{": r"\{",
        "}": r"\}",
        "~": r"\textasciitilde{}",
        "^": r"\textasciicircum{}",
    }
    return "".join(repl.get(c, c) for c in s)


def inline_latex(s):
    placeholders = []
    def hold(val):
        placeholders.append(val)
        return f"\u0000{len(placeholders)-1}\u0000"
    s = re.sub(r"`([^`]+)`", lambda m: hold(r"\texttt{" + tex_escape(m.group(1)) + "}"), s)
    s = re.sub(r"!\[([^\]]*)\]\(([^)]+)\)", lambda m: hold(r"\includegraphics{" + tex_escape(m.group(2)) + "}"), s)
    s = re.sub(r"\[([^\]]+)\]\(([^)]+)\)", lambda m: hold(r"\href{" + tex_escape(m.group(2)) + "}{" + tex_escape(m.group(1)) + "}"), s)
    s = tex_escape(s)
    s = re.sub(r"\*\*([^*]+)\*\*", r"\\textbf{\1}", s)
    s = re.sub(r"__([^_]+)__", r"\\textbf{\1}", s)
    s = re.sub(r"(?<!\*)\*([^*]+)\*(?!\*)", r"\\emph{\1}", s)
    s = re.sub(r"(?<!_)_([^_]+)_(?!_)", r"\\emph{\1}", s)
    for i, val in enumerate(placeholders):
        s = s.replace(f"\u0000{i}\u0000", val)
    return s


def blocks(markdown):
    text = strip_meta(markdown).replace("\r\n", "\n").replace("\r", "\n")
    lines = text.split("\n")
    out = []
    i = 0
    while i < len(lines):
        line = lines[i]
        if not line.strip():
            i += 1
            continue
        if line.startswith("```") or line.startswith("~~~"):
            fence = line[:3]
            code = []
            i += 1
            while i < len(lines) and not lines[i].startswith(fence):
                code.append(lines[i])
                i += 1
            if i < len(lines):
                i += 1
            out.append(("code", "\n".join(code)))
            continue
        if line.startswith("    "):
            code = []
            while i < len(lines) and (lines[i].startswith("    ") or not lines[i].strip()):
                code.append(lines[i][4:] if lines[i].startswith("    ") else "")
                i += 1
            out.append(("code", "\n".join(code).rstrip("\n")))
            continue
        m = re.match(r"^(#{1,6})\s+(.*?)\s*#*\s*$", line)
        if m:
            out.append(("heading", len(m.group(1)), m.group(2).strip()))
            i += 1
            continue
        if i + 1 < len(lines) and re.match(r"^[=-]{3,}\s*$", lines[i + 1]):
            out.append(("heading", 1 if lines[i + 1].lstrip()[0] == "=" else 2, line.strip()))
            i += 2
            continue
        if re.match(r"^\s*[-+*]\s+", line):
            items = []
            while i < len(lines) and re.match(r"^\s*[-+*]\s+", lines[i]):
                items.append(re.sub(r"^\s*[-+*]\s+", "", lines[i]).strip())
                i += 1
            out.append(("ul", items))
            continue
        if re.match(r"^\s*\d+[.)]\s+", line):
            items = []
            while i < len(lines) and re.match(r"^\s*\d+[.)]\s+", lines[i]):
                items.append(re.sub(r"^\s*\d+[.)]\s+", "", lines[i]).strip())
                i += 1
            out.append(("ol", items))
            continue
        if line.startswith(">"):
            qs = []
            while i < len(lines) and lines[i].startswith(">"):
                qs.append(re.sub(r"^>\s?", "", lines[i]))
                i += 1
            out.append(("quote", "\n".join(qs).strip()))
            continue
        if "|" in line and i + 1 < len(lines) and re.match(r"^\s*\|?[-:| ]+\|?\s*$", lines[i + 1]):
            rows = [line, lines[i + 1]]
            i += 2
            while i < len(lines) and "|" in lines[i] and lines[i].strip():
                rows.append(lines[i])
                i += 1
            out.append(("table", rows))
            continue
        para = [line.strip()]
        i += 1
        while i < len(lines) and lines[i].strip() and not re.match(r"^(#{1,6})\s+", lines[i]) and not re.match(r"^\s*([-+*]|\d+[.)])\s+", lines[i]) and not lines[i].startswith(("```", "~~~", ">")):
            para.append(lines[i].strip())
            i += 1
        out.append(("para", " ".join(para)))
    return out


def render_html(md, standalone=False):
    parts = []
    for b in blocks(md):
        if b[0] == "heading":
            _, level, text = b
            parts.append(f'<h{level} id="{slugify(inline_plain(text))}">{inline_html(text)}</h{level}>')
        elif b[0] == "para":
            parts.append(f"<p>{inline_html(b[1])}</p>")
        elif b[0] == "code":
            parts.append("<pre><code>" + html.escape(b[1], quote=False) + "</code></pre>")
        elif b[0] == "ul":
            parts.append("<ul>")
            parts += [f"<li>{inline_html(x)}</li>" for x in b[1]]
            parts.append("</ul>")
        elif b[0] == "ol":
            parts.append('<ol type="1">')
            parts += [f"<li>{inline_html(x)}</li>" for x in b[1]]
            parts.append("</ol>")
        elif b[0] == "quote":
            parts.append("<blockquote>")
            parts.append(f"<p>{inline_html(b[1])}</p>")
            parts.append("</blockquote>")
        elif b[0] == "table":
            rows = [[c.strip() for c in r.strip().strip("|").split("|")] for r in b[1]]
            parts.append("<table>")
            if rows:
                parts.append("<thead><tr>" + "".join(f"<th>{inline_html(c)}</th>" for c in rows[0]) + "</tr></thead>")
            if len(rows) > 2:
                parts.append("<tbody>")
                for r in rows[2:]:
                    parts.append("<tr>" + "".join(f"<td>{inline_html(c)}</td>" for c in r) + "</tr>")
                parts.append("</tbody>")
            parts.append("</table>")
    body = "\n".join(parts)
    if standalone:
        title = ""
        m = re.search(r"^%+\s*(.+)$", md, re.M)
        if not m:
            m = re.search(r"^title:\s*(.+)$", md, re.M)
        if m:
            title = inline_plain(m.group(1)).strip()
        return f'<!DOCTYPE html>\n<html xmlns="http://www.w3.org/1999/xhtml" lang="" xml:lang="">\n<head>\n  <meta charset="utf-8" />\n  <meta name="generator" content="pandoc" />\n  <title>{html.escape(title)}</title>\n</head>\n<body>\n{body}\n</body>\n</html>'
    return body


def render_plain(md):
    parts = []
    for b in blocks(md):
        if b[0] == "heading":
            parts.append(inline_plain(b[2]))
        elif b[0] == "para":
            parts.append(inline_plain(b[1]))
        elif b[0] == "code":
            parts.append("\n".join("    " + x for x in b[1].splitlines()))
        elif b[0] == "ul":
            parts.append("\n".join("- " + inline_plain(x) for x in b[1]))
        elif b[0] == "ol":
            parts.append("\n".join(f"{n}.  {inline_plain(x)}" for n, x in enumerate(b[1], 1)))
        elif b[0] == "quote":
            parts.append("  " + inline_plain(b[1]))
        elif b[0] == "table":
            rows = [[inline_plain(c.strip()) for c in r.strip().strip("|").split("|")] for r in b[1] if not re.match(r"^\s*\|?[-:| ]+\|?\s*$", r)]
            parts.append("\n".join("  ".join(r) for r in rows))
    return "\n\n".join(parts)


def render_markdown(md):
    parts = []
    for b in blocks(md):
        if b[0] == "heading":
            parts.append("#" * b[1] + " " + inline_plain(b[2]))
        elif b[0] == "para":
            parts.append(b[1])
        elif b[0] == "code":
            parts.append("\n".join("    " + x for x in b[1].splitlines()))
        elif b[0] == "ul":
            parts.append("\n".join("- " + x for x in b[1]))
        elif b[0] == "ol":
            parts.append("\n".join(f"{n}.  {x}" for n, x in enumerate(b[1], 1)))
        elif b[0] == "quote":
            parts.append("\n".join("> " + x for x in b[1].splitlines()))
        elif b[0] == "table":
            parts.append("\n".join(b[1]))
    return "\n\n".join(parts)


def render_latex(md):
    parts = []
    for b in blocks(md):
        if b[0] == "heading":
            cmd = ["section", "subsection", "subsubsection", "paragraph", "subparagraph", "subparagraph"][b[1]-1]
            title = inline_latex(b[2])
            parts.append(f"\\{cmd}{{{title}}}\\label{{{slugify(inline_plain(b[2]))}}}")
        elif b[0] == "para":
            parts.append(inline_latex(b[1]))
        elif b[0] == "code":
            parts.append("\\begin{verbatim}\n" + b[1] + "\n\\end{verbatim}")
        elif b[0] == "ul":
            x = ["\\begin{itemize}", "\\tightlist"]
            for item in b[1]:
                x += ["\\item", "  " + inline_latex(item)]
            x.append("\\end{itemize}")
            parts.append("\n".join(x))
        elif b[0] == "ol":
            x = ["\\begin{enumerate}", "\\def\\labelenumi{\\arabic{enumi}.}", "\\tightlist"]
            for item in b[1]:
                x += ["\\item", "  " + inline_latex(item)]
            x.append("\\end{enumerate}")
            parts.append("\n".join(x))
        elif b[0] == "quote":
            parts.append("\\begin{quote}\n" + inline_latex(b[1]) + "\n\\end{quote}")
        elif b[0] == "table":
            rows = [[inline_latex(c.strip()) for c in r.strip().strip("|").split("|")] for r in b[1] if not re.match(r"^\s*\|?[-:| ]+\|?\s*$", r)]
            if rows:
                cols = "l" * len(rows[0])
                body = ["\\begin{tabular}{" + cols + "}"]
                body += [" & ".join(r) + r" \\" for r in rows]
                body.append("\\end{tabular}")
                parts.append("\n".join(body))
    return "\n\n".join(parts)


def html_to_md(s):
    def clean(x):
        return html.unescape(re.sub(r"(?is)<[^>]+>", "", x))
    s = re.sub(r"(?is)<(script|style).*?</\1>", "", s)
    s = re.sub(r"(?is)<a[^>]*href=['\"]([^'\"]+)['\"][^>]*>(.*?)</a>", lambda m: f"[{clean(m.group(2))}]({m.group(1)})", s)
    s = re.sub(r"(?is)<h([1-6])[^>]*>(.*?)</h\1>", lambda m: "\n\n" + "#" * int(m.group(1)) + " " + clean(m.group(2)) + "\n\n", s)
    s = re.sub(r"(?is)<br\s*/?>", "\n", s)
    s = re.sub(r"(?is)<p[^>]*>(.*?)</p>", lambda m: "\n\n" + clean(m.group(1)) + "\n\n", s)
    s = re.sub(r"(?is)<li[^>]*>(.*?)</li>", lambda m: "\n- " + clean(m.group(1)), s)
    s = re.sub(r"(?is)<pre[^>]*><code[^>]*>(.*?)</code></pre>", lambda m: "\n\n" + "\n".join("    " + html.unescape(x) for x in m.group(1).splitlines()) + "\n\n", s)
    s = html.unescape(re.sub(r"(?is)<[^>]+>", "", s))
    return re.sub(r"\n{3,}", "\n\n", s).strip()


def to_json(md):
    arr = []
    for b in blocks(md):
        if b[0] == "heading":
            arr.append({"t": "Header", "c": [b[1], [slugify(inline_plain(b[2])), [], []], [{"t": "Str", "c": inline_plain(b[2])}]]})
        elif b[0] == "para":
            arr.append({"t": "Para", "c": [{"t": "Str", "c": inline_plain(b[1])}]})
        elif b[0] == "code":
            arr.append({"t": "CodeBlock", "c": [["", [], []], b[1]]})
    return json.dumps({"pandoc-api-version": [1, 23, 1], "meta": {}, "blocks": arr}, ensure_ascii=False)


def from_json(s):
    try:
        obj = json.loads(s)
        outs = []
        for b in obj.get("blocks", []):
            t = b.get("t")
            c = b.get("c")
            if t == "Header":
                text = stringify_inlines(c[2])
                outs.append("#" * int(c[0]) + " " + text)
            elif t == "Para":
                outs.append(stringify_inlines(c))
            elif t == "CodeBlock":
                outs.append("```\n" + c[1] + "\n```")
        return "\n\n".join(outs)
    except Exception:
        return s


def stringify_inlines(xs):
    if isinstance(xs, str):
        return xs
    out = []
    for x in xs or []:
        if isinstance(x, dict):
            t, c = x.get("t"), x.get("c")
            if t == "Str":
                out.append(str(c))
            elif t == "Space":
                out.append(" ")
            elif t in ("Emph", "Strong"):
                out.append(stringify_inlines(c))
    return "".join(out)


def convert(text, infmt, outfmt, standalone=False):
    infmt = (infmt or "markdown").split("+")[0]
    outfmt = (outfmt or "html").split("+")[0]
    if infmt in ("html", "html4", "html5"):
        text = html_to_md(text)
    elif infmt == "json":
        text = from_json(text)
    if outfmt in ("html", "html4", "html5", "revealjs", "s5", "slidy", "slideous", "dzslides"):
        return render_html(text, standalone)
    if outfmt in ("plain", "ansi"):
        return render_plain(text)
    if outfmt in ("markdown", "commonmark", "commonmark_x", "gfm", "markdown_github", "markdown_strict", "markdown_mmd", "markdown_phpextra"):
        return render_markdown(text)
    if outfmt in ("latex", "beamer", "context"):
        return render_latex(text)
    if outfmt == "json":
        return to_json(text)
    if outfmt == "native":
        return repr(json.loads(to_json(text)).get("blocks", []))
    if outfmt in ("docbook", "docbook4", "docbook5", "xml", "opendocument", "tei", "jats", "jats_archiving", "jats_articleauthoring", "jats_publishing"):
        return "<?xml version=\"1.0\" encoding=\"utf-8\"?>\n" + render_html(text, False)
    return render_markdown(text)


def infer_out(path):
    ext = os.path.splitext(path or "")[1].lower().lstrip(".")
    return {
        "htm": "html", "html": "html", "tex": "latex", "ltx": "latex",
        "txt": "plain", "text": "plain", "md": "markdown", "markdown": "markdown",
        "json": "json", "xml": "xml",
    }.get(ext, "html")


def infer_in(path):
    ext = os.path.splitext(path or "")[1].lower().lstrip(".")
    return {
        "htm": "html", "html": "html", "xhtml": "html",
        "tex": "latex", "ltx": "latex",
        "txt": "markdown", "text": "markdown", "md": "markdown", "markdown": "markdown",
        "json": "json", "xml": "xml",
    }.get(ext, "markdown")


def main(argv):
    infmt = None
    outfmt = None
    output = None
    standalone = False
    files = []
    i = 0
    skip_next = {"--data-dir", "--metadata-file", "--defaults", "--template", "--toc-depth", "--number-offset", "--top-level-division", "--extract-media", "--resource-path", "--include-in-header", "--include-before-body", "--include-after-body", "--highlight-style", "--syntax-definition", "--syntax-highlighting", "--dpi", "--eol", "--columns", "--tab-stop", "--pdf-engine", "--pdf-engine-opt", "--reference-doc", "--request-header", "--abbreviations", "--indented-code-classes", "--default-image-extension", "--filter", "--lua-filter", "--shift-heading-level-by", "--base-header-level", "--track-changes", "--reference-location", "--figure-caption-position", "--table-caption-position", "--markdown-headings", "--slide-level", "--email-obfuscation", "--id-prefix", "--title-prefix", "--css", "--epub-subdirectory", "--epub-cover-image", "--epub-metadata", "--epub-embed-font", "--split-level", "--chunk-template", "--epub-chapter-level", "--ipynb-output", "--bibliography", "--csl", "--citation-abbreviations", "--log"}
    while i < len(argv):
        a = argv[i]
        if a in ("-h", "--help"):
            print(HELP, end="")
            return 0
        if a in ("-v", "--version"):
            print(VERSION, end="")
            return 0
        if a == "--list-input-formats":
            print(INPUT_FORMATS, end="")
            return 0
        if a == "--list-output-formats":
            print(OUTPUT_FORMATS, end="")
            return 0
        if a.startswith("--list-extensions"):
            print("+smart\n+yaml_metadata_block\n+auto_identifiers\n+tables\n+fenced_code_blocks\n+footnotes\n+citations")
            return 0
        if a == "--list-highlight-languages":
            print("bash\nc\ncpp\ncss\nhaskell\nhtml\njavascript\njson\nlua\nmarkdown\npython\nrust\nxml\nyaml")
            return 0
        if a == "--list-highlight-styles":
            print("pygments\ntango\nespresso\nzenburn\nkate\nmonochrome\nbreezedark\nhaddock")
            return 0
        if a in ("-D", "--print-default-template"):
            fmt = argv[i + 1] if i + 1 < len(argv) else "html"
            print("$body$" if fmt not in ("html", "html5") else "<!DOCTYPE html>\n<html>\n<head><title>$title$</title></head>\n<body>\n$body$\n</body>\n</html>")
            return 0
        if a.startswith("--print-default-template="):
            print("$body$")
            return 0
        if a == "--print-default-data-file":
            return 0
        if a in ("-f", "-r", "--from", "--read"):
            i += 1; infmt = argv[i]
        elif (a.startswith("-f") or a.startswith("-r")) and len(a) > 2:
            infmt = a[2:]
        elif a.startswith("--from=") or a.startswith("--read="):
            infmt = a.split("=", 1)[1]
        elif a in ("-t", "-w", "--to", "--write"):
            i += 1; outfmt = argv[i]
        elif (a.startswith("-t") or a.startswith("-w")) and len(a) > 2:
            outfmt = a[2:]
        elif a.startswith("--to=") or a.startswith("--write="):
            outfmt = a.split("=", 1)[1]
        elif a == "-o" or a == "--output":
            i += 1; output = argv[i]
        elif a.startswith("-o") and len(a) > 2:
            output = a[2:]
        elif a.startswith("--output="):
            output = a.split("=", 1)[1]
        elif a in ("-s", "--standalone") or a.startswith("-s") or a.startswith("--standalone"):
            standalone = not (a.endswith("false") or a.endswith("=false"))
        elif a in ("-M", "--metadata", "-V", "--variable", "--variable-json", "-H", "-B", "-A", "-F", "-L", "-T", "-c", "-d"):
            i += 1
        elif any(a.startswith(x + "=") for x in skip_next) or re.match(r"^-[MNpis][a-z]*?(true|false)$", a):
            pass
        elif a in skip_next:
            i += 1
        elif a.startswith("-"):
            known_flags = {"--file-scope", "--sandbox", "--ascii", "--toc", "--table-of-contents", "--lof", "--list-of-figures", "--lot", "--list-of-tables", "-N", "--number-sections", "--no-highlight", "-p", "--preserve-tabs", "--self-contained", "--embed-resources", "--link-images", "--no-check-certificate", "--strip-comments", "--reference-links", "--list-tables", "--listings", "-i", "--incremental", "--section-divs", "--html-q-tags", "-C", "--citeproc", "--natbib", "--biblatex", "--mathml", "--webtex", "--mathjax", "--katex", "--gladtex", "--trace", "--dump-args", "--ignore-args", "--verbose", "--quiet", "--fail-if-warnings", "--bash-completion"}
            base = a.split("=", 1)[0]
            if base not in known_flags:
                die(f"Unknown option {a}.\nTry executable --help for more information.", 6)
        else:
            files.append(a)
        i += 1
    if infmt and infmt.split("+")[0] not in SUPPORTED_IN:
        die("Unknown input format " + infmt.split("+")[0], 21)
    if output and outfmt is None:
        outfmt = infer_out(output)
    if outfmt and outfmt.split("+")[0] not in SUPPORTED_OUT:
        die("Unknown output format " + outfmt.split("+")[0], 22)
    if not outfmt:
        outfmt = "html"
    if infmt is None and files and files[0] != "-":
        infmt = infer_in(files[0])
    chunks = []
    if files:
        for p in files:
            if p == "-":
                chunks.append(sys.stdin.read())
            else:
                try:
                    with open(p, "r", encoding="utf-8") as f:
                        chunks.append(f.read())
                except OSError as e:
                    die(f"executable: {p}: openBinaryFile: {e.strerror} ({e.errno})", 1)
    else:
        chunks.append(sys.stdin.read())
    result = convert("\n\n".join(chunks), infmt or "markdown", outfmt, standalone)
    if result and not result.endswith("\n"):
        result += "\n"
    if output:
        with open(output, "w", encoding="utf-8") as f:
            f.write(result)
    else:
        sys.stdout.write(result)
    return 0


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
