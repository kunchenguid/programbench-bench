#include <ctype.h>
#include <errno.h>
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <strings.h>

#ifndef M_PI
#define M_PI 3.14159265358979323846
#endif

typedef struct { double x,y,z; } Vec3;
typedef struct { int r,g,b; } Color;
typedef struct { int a,b,c; Color col; } Tri;
typedef struct { char name[128]; Color col; } Mat;

static Vec3 *verts; static int nverts, cverts;
static Tri *tris; static int ntris, ctris;
static Mat *mats; static int nmats, cmats;
static Color cur = {180,180,180};

static void *xrealloc(void *p, size_t n) {
    void *q = realloc(p, n);
    if (!q) { perror("realloc"); exit(1); }
    return q;
}
static void add_vert(double x,double y,double z){
    if(nverts==cverts){ cverts=cverts?cverts*2:1024; verts=xrealloc(verts,cverts*sizeof(*verts)); }
    verts[nverts++] = (Vec3){x,y,z};
}
static void add_tri(int a,int b,int c, Color col){
    if(a<0||b<0||c<0||a>=nverts||b>=nverts||c>=nverts) return;
    if(ntris==ctris){ ctris=ctris?ctris*2:1024; tris=xrealloc(tris,ctris*sizeof(*tris)); }
    tris[ntris++] = (Tri){a,b,c,col};
}
static char *trim(char *s){ while(isspace((unsigned char)*s)) s++; char *e=s+strlen(s); while(e>s&&isspace((unsigned char)e[-1])) *--e=0; return s; }
static int clamp255(double v){ if(v<0) return 0; if(v>255) return 255; return (int)(v+0.5); }
static Color mat_lookup(const char *name){
    for(int i=0;i<nmats;i++) if(strcmp(mats[i].name,name)==0) return mats[i].col;
    return (Color){180,180,180};
}
static int load_mtl(const char *path){
    FILE *f=fopen(path,"r");
    if(!f) return 0;
    char line[512], name[128]="";
    while(fgets(line,sizeof line,f)){
        char *s=trim(line);
        if(strncmp(s,"newmtl ",7)==0){ snprintf(name,sizeof name,"%s",trim(s+7)); }
        else if(strncmp(s,"Kd ",3)==0 && name[0]){
            double r,g,b;
            if(sscanf(s+3,"%lf %lf %lf",&r,&g,&b)==3){
                if(nmats==cmats){ cmats=cmats?cmats*2:32; mats=xrealloc(mats,cmats*sizeof(*mats)); }
                snprintf(mats[nmats].name,sizeof mats[nmats].name,"%s",name);
                mats[nmats].col=(Color){clamp255(r*255),clamp255(g*255),clamp255(b*255)};
                nmats++;
            }
        }
    }
    fclose(f);
    return 1;
}
static int face_index(const char *tok){
    int idx=atoi(tok);
    if(idx<0) return nverts+idx;
    return idx-1;
}
static void load_obj(const char *path){
    FILE *f=fopen(path,"r");
    if(!f){
        fprintf(stderr,"thread 'main' panicked at src/inputs.rs:126:39:\ncalled `Result::unwrap()` on an `Err` value: \"filename: [%s] couldn't load, tobj couldnt load/parse OBJ. open file failed\"\n", path);
        exit(101);
    }
    char line[2048];
    while(fgets(line,sizeof line,f)){
        char *s=trim(line);
        if(strncmp(s,"v ",2)==0){
            double x,y,z; if(sscanf(s+2,"%lf %lf %lf",&x,&y,&z)==3) add_vert(x,y,z);
        } else if(strncmp(s,"mtllib ",7)==0){
            if(!load_mtl(trim(s+7))){
                fprintf(stderr,"thread 'main' panicked at src/inputs.rs:112:39:\nExpected to have materials.: OpenFileFailed\n");
                exit(101);
            }
        } else if(strncmp(s,"usemtl ",7)==0){
            cur=mat_lookup(trim(s+7));
        } else if(strncmp(s,"f ",2)==0){
            int ids[64], n=0; char *p=s+2, *tok;
            while((tok=strtok(n?NULL:p," \t\r\n")) && n<64){ ids[n++]=face_index(tok); p=NULL; }
            for(int i=1;i+1<n;i++) add_tri(ids[0],ids[i],ids[i+1],cur);
        }
    }
    fclose(f);
}
static void load_stl(const char *path){
    FILE *f=fopen(path,"r");
    if(!f){ fprintf(stderr,"could not open %s\n",path); exit(101); }
    char line[512]; Vec3 tmp[3]; int k=0;
    while(fgets(line,sizeof line,f)){
        char *s=trim(line);
        if(strncmp(s,"vertex ",7)==0){
            double x,y,z; if(sscanf(s+7,"%lf %lf %lf",&x,&y,&z)==3){ tmp[k++]=(Vec3){x,y,z}; }
            if(k==3){ int base=nverts; add_vert(tmp[0].x,tmp[0].y,tmp[0].z); add_vert(tmp[1].x,tmp[1].y,tmp[1].z); add_vert(tmp[2].x,tmp[2].y,tmp[2].z); add_tri(base,base+1,base+2,(Color){180,180,180}); k=0; }
        }
    }
    fclose(f);
}
static void load_model(const char *path){
    const char *dot=strrchr(path,'.');
    if(dot && (!strcasecmp(dot,".stl"))) load_stl(path); else load_obj(path);
}
static Vec3 rot(Vec3 v,double ax,double ay,double az){
    double c=cos(ax),s=sin(ax); double y=v.y*c-v.z*s,z=v.y*s+v.z*c; v.y=y; v.z=z;
    c=cos(ay); s=sin(ay); double x=v.x*c+v.z*s; z=-v.x*s+v.z*c; v.x=x; v.z=z;
    c=cos(az); s=sin(az); x=v.x*c-v.y*s; y=v.x*s+v.y*c; v.x=x; v.y=y;
    return v;
}
static double edge(double ax,double ay,double bx,double by,double px,double py){ return (px-ax)*(by-ay)-(py-ay)*(bx-ax); }
static char shade_char(double nz){
    const char *r=" .:-=+*#";
    double v=fabs(nz); int i=(int)(v*7.99); if(i<1)i=1; if(i>7)i=7; return r[i];
}
static char *render(int w,int h,double ax,double ay,double az,int html,int ansi){
    if(w<1) w=80;
    if(h<1) h=24;
    Vec3 *tv=xrealloc(NULL,nverts*sizeof(*tv));
    double minx=1e100,maxx=-1e100,miny=1e100,maxy=-1e100;
    for(int i=0;i<nverts;i++){ tv[i]=rot(verts[i],ax,ay,az); if(tv[i].x<minx)minx=tv[i].x; if(tv[i].x>maxx)maxx=tv[i].x; if(tv[i].y<miny)miny=tv[i].y; if(tv[i].y>maxy)maxy=tv[i].y; }
    double sx=(maxx-minx)?(w-2)/(maxx-minx):1, sy=(maxy-miny)?(h-2)/(maxy-miny):1, sc=sx<sy?sx:sy;
    if(sc<=0) sc=1;
    char *pix=xrealloc(NULL,w*h); Color *cols=xrealloc(NULL,w*h*sizeof(*cols)); double *zbuf=xrealloc(NULL,w*h*sizeof(*zbuf));
    for(int i=0;i<w*h;i++){ pix[i]=' '; cols[i]=(Color){0,0,0}; zbuf[i]=-1e100; }
    for(int t=0;t<ntris;t++){
        Vec3 a=tv[tris[t].a],b=tv[tris[t].b],c=tv[tris[t].c];
        double x1=(a.x-(minx+maxx)/2)*sc+w/2.0, y1=h/2.0-(a.y-(miny+maxy)/2)*sc;
        double x2=(b.x-(minx+maxx)/2)*sc+w/2.0, y2=h/2.0-(b.y-(miny+maxy)/2)*sc;
        double x3=(c.x-(minx+maxx)/2)*sc+w/2.0, y3=h/2.0-(c.y-(miny+maxy)/2)*sc;
        double area=edge(x1,y1,x2,y2,x3,y3); if(fabs(area)<1e-9) continue;
        Vec3 u={b.x-a.x,b.y-a.y,b.z-a.z}, v={c.x-a.x,c.y-a.y,c.z-a.z};
        Vec3 n={u.y*v.z-u.z*v.y,u.z*v.x-u.x*v.z,u.x*v.y-u.y*v.x};
        double nl=sqrt(n.x*n.x+n.y*n.y+n.z*n.z); if(nl) { n.x/=nl; n.y/=nl; n.z/=nl; }
        int minxi=(int)floor(fmin(x1,fmin(x2,x3))), maxxi=(int)ceil(fmax(x1,fmax(x2,x3)));
        int minyi=(int)floor(fmin(y1,fmin(y2,y3))), maxyi=(int)ceil(fmax(y1,fmax(y2,y3)));
        if(minxi<0) minxi=0;
        if(minyi<0) minyi=0;
        if(maxxi>=w) maxxi=w-1;
        if(maxyi>=h) maxyi=h-1;
        for(int y=minyi;y<=maxyi;y++) for(int x=minxi;x<=maxxi;x++){
            double px=x+0.5, py=y+0.5;
            double w1=edge(x2,y2,x3,y3,px,py)/area, w2=edge(x3,y3,x1,y1,px,py)/area, w3=edge(x1,y1,x2,y2,px,py)/area;
            if(w1>=-1e-6&&w2>=-1e-6&&w3>=-1e-6){
                double zz=w1*a.z+w2*b.z+w3*c.z; int id=y*w+x;
                if(zz>zbuf[id]){ zbuf[id]=zz; pix[id]=shade_char(n.z); cols[id]=tris[t].col; }
            }
        }
    }
    size_t cap=(size_t)w*h*(html?45:40)+h*8+64, len=0; char *out=xrealloc(NULL,cap);
    for(int y=0;y<h;y++){
        for(int x=0;x<w;x++){
            int id=y*w+x; Color cc=cols[id]; char ch=pix[id];
            int n;
            if(html) n=snprintf(out+len,cap-len,"<span style=\"color:rgb(%d,%d,%d)\">%c",cc.r,cc.g,cc.b,ch);
            else if(ansi) n=snprintf(out+len,cap-len,"\033[48;2;25;25;25m\033[38;2;%d;%d;%dm%c\033[49m\033[39m",cc.r,cc.g,cc.b,ch);
            else n=snprintf(out+len,cap-len,"%c",ch);
            len += (size_t)n;
            if(len+80>cap){ cap*=2; out=xrealloc(out,cap); }
        }
        out[len++]='\n'; out[len]=0;
    }
    free(tv); free(pix); free(cols); free(zbuf); return out;
}
static void print_help(void){
    puts("Sloth 0.1\nMitchell Hynes. <mshynes@mun.ca>\nA toy for rendering 3D objects in the command line\n\nUSAGE:\n    executable [FLAGS] [OPTIONS] <input filename(s)>... [SUBCOMMAND]\n\nFLAGS:\n    -h, --help       Prints help information\n    -b               Flags the rasterizer to render without color\n    -V, --version    Prints version information\n\nOPTIONS:\n    -x, --yaw <x>      Sets the object's static X rotation (in radians)\n    -y, --pitch <y>    Sets the object's static Y rotation (in radians)\n    -z, --roll <z>     Sets the object's static Z rotation (in radians)\n\nARGS:\n    <input filename(s)>...    Sets the input file to render\n\nSUBCOMMANDS:\n    help     Prints this message or the help of the given subcommand(s)\n    image    Generates a colorless terminal output as lines of text");
}
static void print_image_help(void){
    puts("executable-image \nMitchell Hynes <mitchell.hynes@ecumene.xyz>\nGenerates a colorless terminal output as lines of text\n\nUSAGE:\n    executable <input filename(s)>... image [FLAGS] [OPTIONS] -w <width>\n\nFLAGS:\n        --help       Prints help information\n    -b               Flags the rasterizer to render without color\n    -V, --version    Prints version information\n\nOPTIONS:\n    -j, --webify <frame count>    Generates a portable JS based render of your object for the web\n    -h <height>                   Sets the height of the image to generate\n    -w <width>                    Sets the width of the image to generate\n    -x, --yaw <x>                 Sets the object's static X rotation (in radians)\n    -y, --pitch <y>               Sets the object's static Y rotation (in radians)\n    -z, --roll <z>                Sets the object's static Z rotation (in radians)");
}
int main(int argc,char **argv){
    if(argc==1){ print_help(); return 0; }
    double ax=0,ay=0,az=0; int image=0,w=0,h=0,web=0,bw=0; char *files[256]; int nf=0;
    for(int i=1;i<argc;i++){
        char *a=argv[i];
        if(!strcmp(a,"--help")||!strcmp(a,"help")){ if(image) print_image_help(); else print_help(); return 0; }
        else if(!strcmp(a,"-V")||!strcmp(a,"--version")){ puts("Sloth 0.1"); return 0; }
        else if(!strcmp(a,"image")) image=1;
        else if(!strcmp(a,"-b")) bw=1;
        else if((!strcmp(a,"-x")||!strcmp(a,"--yaw")) && i+1<argc) ax=atof(argv[++i]);
        else if((!strcmp(a,"-y")||!strcmp(a,"--pitch")) && i+1<argc) ay=atof(argv[++i]);
        else if((!strcmp(a,"-z")||!strcmp(a,"--roll")) && i+1<argc) az=atof(argv[++i]);
        else if(!strcmp(a,"-w") && i+1<argc) w=atoi(argv[++i]);
        else if(!strcmp(a,"-h") && i+1<argc) h=atoi(argv[++i]);
        else if((!strcmp(a,"-j")||!strcmp(a,"--webify")) && i+1<argc) web=atoi(argv[++i]);
        else if(a[0]=='-' && strcmp(a,"-")) { fprintf(stderr,"error: Found argument '%s' which wasn't expected\n",a); return 1; }
        else files[nf++]=a;
    }
    if(image && w<=0){ fprintf(stderr,"error: The following required arguments were not provided:\n    -w <width>\n\nUSAGE:\n    executable <input filename(s)>... image [FLAGS] [OPTIONS] -w <width>\n\nFor more information try --help\n"); return 1; }
    if(nf==0){ if(image){ fprintf(stderr,"error: The following required arguments were not provided:\n    <input filename(s)>...\n"); return 1; } print_help(); return 0; }
    for(int i=0;i<nf;i++) load_model(files[i]);
    if(h<=0) h=w;
    if(web>0){
        puts("let frames = [");
        for(int i=0;i<web;i++){ char *s=render(w,h,ax,ay+2*M_PI*i/web,az,1,0); printf("`\n%s`%s\n",s,(i==web-1)?"":","); free(s); }
        puts("];");
    } else {
        char *s=render(image?w:80,image?h:40,ax,ay,az,0,!bw || bw); fputs(s,stdout); free(s);
    }
    return 0;
}
