#!/usr/bin/env python3
import argparse
import csv
import html
import json
import os
import re
import sqlite3
import sys

VERSION = "v0.0.1 (Unknown Version) 780a7396"

HELP = """\033[1mUsage: \033[00m\033[32m./executable\033[00m\033[33m [OPTIONS] FILENAME [SQL]

\033[00m\033[1mFILENAME\033[00m is the name of a DuckDB database. A new database is created
if the file does not previously exist.

\033[1mOPTIONS:
\033[00m\033[32m  -ascii\033[00m                   set output mode to 'ascii'
\033[32m  -bail\033[00m                    stop after hitting an error
\033[32m  -batch\033[00m                   force batch I/O'
\033[32m  -box\033[00m                     set output mode to 'box'
\033[32m  -column\033[00m                  set output mode to 'column'
\033[32m  -cmd\033[00m\033[33m COMMAND\033[00m             run "COMMAND" before reading stdin
\033[32m  -csv\033[00m                     set output mode to 'csv'
\033[32m  -c\033[00m\033[33m COMMAND\033[00m               run "COMMAND" and exit
\033[32m  -echo\033[00m                    print commands before execution
\033[32m  -f\033[00m\033[33m FILENAME\033[00m              read/process named file and exit
\033[32m  -format\033[00m                  format SQL from stdin, writing result to stdout
\033[32m  -format-file\033[00m\033[33m FILENAME\033[00m    format SQL in file, writing result to stdout
\033[32m  -init\033[00m\033[33m FILENAME\033[00m           read/process named file
\033[32m  -header\033[00m                  turn headers on
\033[32m  -h\033[00m                       show help message
\033[32m  -help\033[00m                    show help message
\033[32m  -html\033[00m                    set output mode to HTML
\033[32m  -interactive\033[00m             force interactive I/O
\033[32m  -json\033[00m                    set output mode to 'json'
\033[32m  -jsonlines\033[00m               set output mode to 'jsonlines'
\033[32m  -line\033[00m                    set output mode to 'line'
\033[32m  -list\033[00m                    set output mode to 'list'
\033[32m  -markdown\033[00m                set output mode to 'markdown'
\033[32m  -newline\033[00m\033[33m SEP\033[00m             set output row separator. Default: '\\n'
\033[32m  -no-init\033[00m                 skip processing the init file
\033[32m  -no-stdin\033[00m                exit after processing options instead of reading stdin
\033[32m  -noheader\033[00m                turn headers off
\033[32m  -nullvalue\033[00m\033[33m TEXT\033[00m          set text string for NULL values. Default 'NULL'
\033[32m  -quote\033[00m                   set output mode to 'quote'
\033[32m  -readonly\033[00m                open the database read-only
\033[32m  -s\033[00m\033[33m COMMAND\033[00m               run "COMMAND" and exit
\033[32m  -safe\033[00m                    enable safe-mode
\033[32m  -separator\033[00m\033[33m SEP\033[00m           set output column separator. Default: '|'
\033[32m  -storage-version\033[00m\033[33m VER\033[00m     database storage compatibility version to use. Default: 'v0.10.0'
\033[32m  -table\033[00m                   set output mode to 'table'
\033[32m  -ui\033[00m                      launches a web interface using the ui extension (configurable with .ui_command)
\033[32m  -unredacted\033[00m              allow printing unredacted secrets
\033[32m  -unsigned\033[00m                allow loading of unsigned extensions
\033[32m  -version\033[00m                 show DuckDB version"""


class Shell:
    def __init__(self, dbpath):
        if dbpath in (None, "", ":memory:"):
            self.conn = sqlite3.connect(":memory:")
        else:
            self.conn = sqlite3.connect(dbpath)
        self.conn.create_function("regexp_matches", 2, lambda s, p: 1 if re.search(p, str(s or "")) else 0)
        self.mode = "box"
        self.headers = True
        self.null = "NULL"
        self.sep = "|"
        self.newline = "\n"
        self.bail = False
        self.echo = False
        self.csv_counter = 0

    def split_sql(self, text):
        out, buf, quote, esc = [], [], None, False
        for ch in text:
            buf.append(ch)
            if quote:
                if ch == quote and not esc:
                    quote = None
                esc = (ch == "\\" and not esc)
                if ch != "\\":
                    esc = False
            elif ch in ("'", '"'):
                quote = ch
            elif ch == ";":
                s = "".join(buf).strip()
                if s:
                    out.append(s[:-1].strip())
                buf = []
        s = "".join(buf).strip()
        if s:
            out.append(s)
        return out

    def run_script(self, text):
        rc = 0
        statements = []
        sqlbuf = []
        for line in text.splitlines():
            if line.lstrip().startswith(".") and not sqlbuf:
                statements.append(line.strip())
            elif line.lstrip().startswith("."):
                statements.extend(self.split_sql("\n".join(sqlbuf)))
                sqlbuf = []
                statements.append(line.strip())
            else:
                sqlbuf.append(line)
        if sqlbuf:
            statements.extend(self.split_sql("\n".join(sqlbuf)))
        for stmt in statements:
            if not stmt:
                continue
            if self.echo:
                print(stmt + ";")
            try:
                self.run_one(stmt)
            except Exception as e:
                print(self.format_error(e), file=sys.stderr)
                rc = 1
                if self.bail:
                    break
        return rc

    def format_error(self, e):
        msg = str(e)
        if isinstance(e, sqlite3.OperationalError):
            return "Parser Error: " + msg
        return "Error: " + msg

    def dot(self, line):
        parts = line.strip().split()
        cmd = parts[0][1:] if parts else ""
        args = parts[1:]
        if cmd in ("quit", "exit"):
            raise SystemExit(int(args[0]) if args and args[0].isdigit() else 0)
        if cmd in ("help",):
            print(".help                            Show help text\n.mode MODE                       Set output mode\n.tables                          List names of tables\n.schema ?TABLE?                  Show CREATE statements\n.read FILE                       Read input from FILE\n.quit                            Exit this program")
        elif cmd in ("version",):
            print(VERSION)
        elif cmd in ("mode",) and args:
            self.mode = args[0].lower()
        elif cmd in ("headers", "header") and args:
            self.headers = args[0].lower() in ("on", "yes", "1", "true")
        elif cmd == "nullvalue" and args:
            self.null = " ".join(args)
        elif cmd == "separator" and args:
            self.sep = decode_sep(args[0])
            if len(args) > 1:
                self.newline = decode_sep(args[1])
        elif cmd == "tables":
            self.run_one("show tables")
        elif cmd == "schema":
            rows = self.conn.execute("select sql from sqlite_master where sql is not null order by name").fetchall()
            for (sql,) in rows:
                print(sql + ";")
        elif cmd == "read" and args:
            with open(args[0]) as f:
                return self.run_script(f.read())
        elif cmd == "import" and len(args) >= 2:
            self.import_csv(args[0], args[1])
        elif cmd == "print":
            print(" ".join(args))
        return 0

    def run_one(self, stmt):
        if stmt.lstrip().startswith("."):
            return self.dot(stmt)
        low = stmt.strip().lower()
        if low == "show tables":
            cur = self.conn.execute("select name from sqlite_master where type in ('table','view') and name not like 'sqlite_%' order by name")
            return self.render(cur, [("name", None)])
        if low.startswith("describe ") or low.startswith("desc "):
            q = re.sub(r"(?is)^(describe|desc)\s+", "", stmt).strip()
            if q.lower().startswith("select"):
                cur = self.conn.execute("select * from (" + self.translate(q) + ") limit 0")
                rows = [(d[0], "varchar", "YES", None, None, None) for d in cur.description]
            else:
                name = q.strip('"`')
                rows = [(r[1], r[2] or "varchar", "YES" if not r[3] else "NO", None, None, None) for r in self.conn.execute(f"pragma table_info({quote_ident(name)})")]
            self.render_rows(["column_name", "column_type", "null", "key", "default", "extra"], rows)
            return
        sql = self.translate(stmt)
        cur = self.conn.execute(sql)
        if cur.description:
            self.render(cur, cur.description)
        else:
            self.conn.commit()

    def translate(self, sql):
        s = sql.strip()
        m = re.fullmatch(r"(?is)select\s+range\s*\(\s*(\d+)\s*\)\s*", s)
        if m:
            n = int(m.group(1))
            return "select " + sql_quote("[" + ", ".join(str(i) for i in range(n)) + "]") + f' as "range({n})"'
        s = re.sub(r"(?i)\btrue\b", "1", s)
        s = re.sub(r"(?i)\bfalse\b", "0", s)
        s = re.sub(r"(?i)\b::\s*([a-zA-Z_][\w()]*)", "", s)
        s = re.sub(r"(?i)\bILIKE\b", "LIKE", s)
        s = re.sub(r"(?i)\bVARCHAR\b", "TEXT", s)
        s = re.sub(r"(?i)\bDOUBLE\b", "REAL", s)
        s = re.sub(r"(?i)\bHUGEINT\b|\bUBIGINT\b|\bBIGINT\b|\bINTEGER\b|\bINT\b|\bBOOLEAN\b", "INTEGER", s)
        s = re.sub(r"(?i)\bcount\s*\(\s*\*\s*\)", "count(*)", s)
        s = self.rewrite_range(s)
        s = self.rewrite_csv_files(s)
        s = self.rewrite_read_csv(s)
        return s

    def rewrite_range(self, s):
        def repl(m):
            n = int(m.group(1))
            name = f"__range_{self.csv_counter}"
            self.csv_counter += 1
            self.conn.execute(f"drop table if exists {name}")
            self.conn.execute(f"create temp table {name}(range integer)")
            self.conn.executemany(f"insert into {name}(range) values (?)", [(i,) for i in range(n)])
            return name
        return re.sub(r"(?i)\brange\s*\(\s*(\d+)\s*\)", repl, s)

    def rewrite_read_csv(self, s):
        def repl(m):
            return self.load_csv(m.group(1))
        return re.sub(r"(?i)(read_csv_auto|read_csv)\s*\(\s*'([^']+)'\s*\)", lambda m: self.load_csv(m.group(2)), s)

    def rewrite_csv_files(self, s):
        def repl(m):
            path = m.group(2)
            if path.lower().endswith(".csv"):
                return m.group(1) + " " + self.load_csv(path)
            return m.group(0)
        return re.sub(r"(?i)(from|join)\s+'([^']+)'", repl, s)

    def load_csv(self, path):
        real = path if os.path.isabs(path) else os.path.abspath(path)
        name = f"__csv_{self.csv_counter}"
        self.csv_counter += 1
        with open(real, newline="") as f:
            reader = csv.reader(f)
            rows = list(reader)
        headers = rows[0] if rows else ["column0"]
        data = rows[1:] if rows else []
        cols = [safe_col(h, i) for i, h in enumerate(headers)]
        self.conn.execute(f"drop table if exists {name}")
        self.conn.execute(f"create temp table {name}({', '.join(quote_ident(c) + ' TEXT' for c in cols)})")
        if data:
            ph = ",".join("?" for _ in cols)
            self.conn.executemany(f"insert into {name} values ({ph})", [tuple(r + [""] * (len(cols)-len(r)))[:len(cols)] for r in data])
        return name

    def import_csv(self, path, table):
        real = path if os.path.isabs(path) else os.path.abspath(path)
        with open(real, newline="") as f:
            rows = list(csv.reader(f))
        if not rows:
            return
        headers = [safe_col(h, i) for i, h in enumerate(rows[0])]
        self.conn.execute(f"create table if not exists {quote_ident(table)}({', '.join(quote_ident(c) + ' TEXT' for c in headers)})")
        if rows[1:]:
            ph = ",".join("?" for _ in headers)
            self.conn.executemany(f"insert into {quote_ident(table)} values ({ph})", [tuple(r + [""] * (len(headers)-len(r)))[:len(headers)] for r in rows[1:]])
            self.conn.commit()

    def render(self, cur, desc):
        cols = [d[0] for d in desc]
        rows = cur.fetchall()
        self.render_rows(cols, rows)

    def fmt(self, v):
        if v is None:
            return self.null
        if isinstance(v, float):
            return ("%g" % v)
        if isinstance(v, int) and v in (0, 1):
            return str(v)
        return str(v)

    def render_rows(self, cols, rows):
        vals = [[self.fmt(v) for v in row] for row in rows]
        mode = self.mode
        if mode == "csv":
            w = csv.writer(sys.stdout, lineterminator=self.newline)
            if self.headers:
                w.writerow(cols)
            w.writerows(vals)
        elif mode in ("list",):
            if self.headers:
                print(self.sep.join(cols), end=self.newline)
            for r in vals:
                print(self.sep.join(r), end=self.newline)
        elif mode == "json":
            arr = [dict((c, json_val(row[i])) for i, c in enumerate(cols)) for row in rows]
            print(json.dumps(arr, separators=(",", ":")).replace("},{", "},\n{"))
        elif mode == "jsonlines":
            for row in rows:
                print(json.dumps(dict((c, json_val(row[i])) for i, c in enumerate(cols)), separators=(",", ":")))
        elif mode == "line":
            for row in vals:
                for c, v in zip(cols, row):
                    print(f"{c:>5} = {v}")
                print()
        elif mode == "html":
            if self.headers:
                print("<tr>" + "\n".join(f"<th>{html.escape(c)}</th>" for c in cols) + "\n</tr>")
            for row in vals:
                print("<tr>" + "\n".join(f"<td>{html.escape(v)}</td>" for v in row) + "\n</tr>")
        elif mode == "quote":
            if self.headers:
                print(self.sep.join(sql_quote(c) for c in cols))
            for row in rows:
                print(self.sep.join("NULL" if v is None else (str(v) if isinstance(v, (int, float)) else sql_quote(str(v))) for v in row))
        elif mode == "ascii":
            for c in cols if self.headers else []:
                print(c)
            for row in vals:
                for v in row:
                    print(v)
        elif mode == "column":
            self.render_column(cols, vals)
        elif mode == "markdown":
            self.render_markdown(cols, vals)
        elif mode == "table":
            self.render_grid(cols, vals, ascii=True, types=False)
        else:
            self.render_grid(cols, vals, ascii=False, types=(mode == "box"))

    def render_column(self, cols, vals):
        widths = [len(c) for c in cols]
        for r in vals:
            for i, v in enumerate(r):
                widths[i] = max(widths[i], len(v))
        if self.headers:
            print("  ".join(c.ljust(widths[i]) for i, c in enumerate(cols)))
            print("  ".join("-" * widths[i] for i in range(len(cols))))
        for r in vals:
            print("  ".join(r[i].ljust(widths[i]) for i in range(len(cols))))

    def render_markdown(self, cols, vals):
        widths = [len(c) for c in cols]
        for r in vals:
            for i, v in enumerate(r):
                widths[i] = max(widths[i], len(v))
        print("| " + " | ".join(cols[i].center(widths[i]) for i in range(len(cols))) + " |")
        print("|" + "|".join("-" * (widths[i] + 2) for i in range(len(cols))) + "|")
        for r in vals:
            print("| " + " | ".join(r[i].ljust(widths[i]) for i in range(len(cols))) + " |")

    def render_grid(self, cols, vals, ascii=False, types=False):
        type_row = ["varchar"] * len(cols)
        data = ([type_row] if types and self.headers else []) + vals
        widths = [len(c) for c in cols]
        for r in data:
            for i, v in enumerate(r):
                widths[i] = max(widths[i], len(v))
        if ascii:
            tl, tr, bl, br, hz, vt, jt, jl, jr, jb, cross = "+", "+", "+", "+", "-", "|", "+", "+", "+", "+", "+"
        else:
            tl, tr, bl, br, hz, vt, jt, jl, jr, jb, cross = "┌", "┐", "└", "┘", "─", "│", "┬", "├", "┤", "┴", "┼"
        def border(left, mid, right):
            return left + mid.join(hz * (w + 2) for w in widths) + right
        print(border(tl, jt, tr))
        if self.headers:
            print(vt + vt.join(" " + cols[i].center(widths[i]) + " " for i in range(len(cols))) + vt)
            if types:
                print(vt + vt.join(" " + type_row[i].center(widths[i]) + " " for i in range(len(cols))) + vt)
            print(border(jl, cross, jr))
        for r in vals:
            print(vt + vt.join(" " + r[i].rjust(widths[i]) + " " for i in range(len(cols))) + vt)
        print(border(bl, jb, br))


def safe_col(s, i):
    s = s.strip() or f"column{i}"
    return re.sub(r"\W+", "_", s).strip("_") or f"column{i}"


def quote_ident(s):
    return '"' + s.replace('"', '""') + '"'


def sql_quote(s):
    return "'" + s.replace("'", "''") + "'"


def json_val(v):
    if v is None:
        return None
    if isinstance(v, (int, float)):
        return v
    text = str(v)
    if re.fullmatch(r"-?\d+", text):
        try:
            return int(text)
        except Exception:
            pass
    if re.fullmatch(r"-?\d+\.\d+", text):
        try:
            return float(text)
        except Exception:
            pass
    return text


def decode_sep(s):
    return s.encode().decode("unicode_escape")


def parse(argv):
    opts = {"mode": None, "commands": [], "file": None, "sql": None, "stdin": True, "header": None,
            "null": None, "sep": None, "newline": None, "bail": False, "echo": False}
    pos = []
    i = 0
    while i < len(argv):
        a = argv[i]
        if a in ("-h", "-help", "--help"):
            print(HELP)
            raise SystemExit(0)
        if a == "-version":
            print(VERSION)
            raise SystemExit(0)
        if a in ("-csv", "-list", "-column", "-json", "-jsonlines", "-line", "-markdown", "-ascii", "-box", "-table", "-quote", "-html"):
            opts["mode"] = a[1:]
        elif a in ("-header",):
            opts["header"] = True
        elif a == "-noheader":
            opts["header"] = False
        elif a in ("-separator", "-newline", "-nullvalue", "-cmd", "-c", "-s", "-f", "-init", "-storage-version"):
            if i + 1 >= len(argv):
                print(f"Missing argument to {a}", file=sys.stderr)
                raise SystemExit(1)
            v = argv[i + 1]
            i += 1
            if a == "-separator":
                opts["sep"] = decode_sep(v)
            elif a == "-newline":
                opts["newline"] = decode_sep(v)
            elif a == "-nullvalue":
                opts["null"] = v
            elif a in ("-cmd", "-init"):
                opts["commands"].append(v)
            elif a in ("-c", "-s"):
                opts["sql"] = v
                opts["stdin"] = False
            elif a == "-f":
                with open(v) as f:
                    opts["sql"] = f.read()
                opts["stdin"] = False
        elif a in ("-no-stdin",):
            opts["stdin"] = False
        elif a in ("-bail",):
            opts["bail"] = True
        elif a in ("-echo",):
            opts["echo"] = True
        elif a.startswith("-"):
            pass
        else:
            pos.append(a)
        i += 1
    if pos:
        opts["file"] = pos[0]
    if len(pos) > 1 and opts["sql"] is None:
        opts["sql"] = " ".join(pos[1:])
        opts["stdin"] = False
    return opts


def main(argv):
    opts = parse(argv)
    sh = Shell(opts["file"] or ":memory:")
    if opts["mode"]:
        sh.mode = opts["mode"]
    if opts["header"] is not None:
        sh.headers = opts["header"]
    if opts["null"] is not None:
        sh.null = opts["null"]
    if opts["sep"] is not None:
        sh.sep = opts["sep"]
    if opts["newline"] is not None:
        sh.newline = opts["newline"]
    sh.bail = opts["bail"]
    sh.echo = opts["echo"]
    rc = 0
    for c in opts["commands"]:
        rc |= sh.run_script(c)
    if opts["sql"]:
        rc |= sh.run_script(opts["sql"])
    elif opts["stdin"] and not sys.stdin.isatty():
        rc |= sh.run_script(sys.stdin.read())
    return rc


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
