#!/usr/bin/env python3
import json
import os
import shutil
import stat
import sys
from datetime import datetime

VERSION = "GDAL 3.13.0dev-e6fe3fbb06, released 2026/04/20"

WARNING = """WARNING: the gdal command is provisionally provided as an alternative interface to GDAL and OGR command line utilities.
The project reserves the right to modify, rename, reorganize, and change the behavior of the utility
until it is officially frozen in a future feature release of GDAL."""

DRIVERS = [
    {"short_name": "GTiff", "long_name": "GeoTIFF", "scopes": ["raster"], "capabilities": ["open", "create", "create_copy", "update", "virtual_io"], "file_extensions": ["tif", "tiff"]},
    {"short_name": "COG", "long_name": "Cloud optimized GeoTIFF generator", "scopes": ["raster"], "capabilities": ["create", "create_copy", "virtual_io"], "file_extensions": ["tif", "tiff"]},
    {"short_name": "VRT", "long_name": "Virtual Raster", "scopes": ["raster", "multidimensional_raster"], "capabilities": ["open", "create", "create_copy", "update", "virtual_io"], "file_extensions": ["vrt"]},
    {"short_name": "MEM", "long_name": "In Memory raster, vector and multidimensional raster", "scopes": ["raster", "multidimensional_raster", "vector"], "capabilities": ["open", "create"]},
    {"short_name": "GeoJSON", "long_name": "GeoJSON", "scopes": ["vector"], "capabilities": ["open", "create", "create_copy", "virtual_io"], "file_extensions": ["json", "geojson"]},
    {"short_name": "ESRI Shapefile", "long_name": "ESRI Shapefile", "scopes": ["vector"], "capabilities": ["open", "create", "create_copy", "virtual_io"], "file_extensions": ["shp", "dbf"]},
    {"short_name": "GPKG", "long_name": "GeoPackage", "scopes": ["raster", "vector"], "capabilities": ["open", "create", "create_copy", "update", "virtual_io"], "file_extensions": ["gpkg"]},
    {"short_name": "CSV", "long_name": "Comma Separated Value (.csv)", "scopes": ["vector"], "capabilities": ["open", "create", "virtual_io"], "file_extensions": ["csv"]},
    {"short_name": "JPEG", "long_name": "JPEG JFIF", "scopes": ["raster"], "capabilities": ["open", "create_copy", "virtual_io"], "file_extensions": ["jpg", "jpeg"]},
    {"short_name": "PNG", "long_name": "Portable Network Graphics", "scopes": ["raster"], "capabilities": ["open", "create_copy", "virtual_io"], "file_extensions": ["png"]},
]

MAIN_HELP = """Usage: gdal <COMMAND> [OPTIONS]
where <COMMAND> is one of:
  - convert:  Convert a dataset (shortcut for 'gdal raster convert' or 'gdal vector convert').
  - dataset:  Commands to manage datasets.
  - driver:   Command for driver specific operations.
  - info:     Return information on a dataset (shortcut for 'gdal raster info' or 'gdal vector info').
  - mdim:     Multidimensional commands.
  - pipeline: Process a dataset applying several steps.
  - raster:   Raster commands.
  - vector:   Vector commands.
  - vsi:      GDAL Virtual System Interface (VSI) commands.

Common Options:
  -h, --help              Display help message and exit
  --json-usage            Display usage as JSON document and exit
  --config <KEY>=<VALUE>  Configuration option [may be repeated]

Options:
  --version               Display GDAL version and exit
  --drivers               Display driver list as JSON document

'gdal <FILENAME>' can also be used as a shortcut for 'gdal info <FILENAME>'.
And 'gdal read <FILENAME> ! ...' as a shortcut for 'gdal pipeline <FILENAME> ! ...'.

For more details, consult https://gdal.org/programs/index.html

""" + WARNING

RASTER_COMMANDS = [
    ("as-features", "Create features from pixels of a raster dataset"),
    ("aspect", "Generate an aspect map"),
    ("blend", "Blend/compose two raster datasets"),
    ("calc", "Perform raster algebra"),
    ("clean-collar", "Clean the collar of a raster dataset, removing noise."),
    ("clip", "Clip a raster dataset."),
    ("color-map", "Generate a RGB or RGBA dataset from a single band, using a color map"),
    ("compare", "Compare two raster datasets."),
    ("contour", "Creates a vector contour from a raster elevation model (DEM)."),
    ("convert", "Convert a raster dataset."),
    ("create", "Create a new raster dataset."),
    ("edit", "Edit a raster dataset."),
    ("fill-nodata", "Fill nodata raster regions by interpolation from edges."),
    ("footprint", "Compute the footprint of a raster dataset."),
    ("hillshade", "Generate a shaded relief map"),
    ("index", "Create a vector index of raster datasets."),
    ("info", "Return information on a raster dataset."),
    ("mosaic", "Build a mosaic, either virtual (VRT) or materialized."),
    ("neighbors", "Compute the value of each pixel from its neighbors (focal statistics) (alias: neighbours)"),
    ("nodata-to-alpha", "Replace nodata value(s) with an alpha band."),
    ("overview", "Manage overviews of a raster dataset."),
    ("pansharpen", "Perform a pansharpen operation."),
    ("pipeline", "Process a raster dataset applying several steps."),
    ("pixel-info", "Return information on a pixel of a raster dataset."),
    ("polygonize", "Create a polygon feature dataset from a raster band."),
    ("proximity", "Produces a raster proximity map."),
    ("reclassify", "Reclassify values in a raster dataset"),
    ("reproject", "Reproject a raster dataset."),
    ("resize", "Resize a raster dataset without changing the georeferenced extents."),
    ("rgb-to-palette", "Convert a RGB image into a pseudo-color / paletted image."),
    ("roughness", "Generate a roughness map"),
    ("scale", "Scale the values of the bands of a raster dataset."),
    ("select", "Select a subset of bands from a raster dataset."),
    ("set-type", "Modify the data type of bands of a raster dataset."),
    ("sieve", "Remove small polygons from a raster dataset."),
    ("slope", "Generate a slope map"),
    ("stack", "Combine together input bands into a multi-band output, either virtual (VRT) or materialized."),
    ("tile", "Generate tiles in separate files from a raster dataset."),
    ("tpi", "Generate a Topographic Position Index (TPI) map"),
    ("tri", "Generate a Terrain Ruggedness Index (TRI) map"),
    ("unscale", "Convert scaled values of a raster dataset into unscaled values."),
    ("update", "Update the destination raster with the content of the input one."),
    ("viewshed", "Compute the viewshed of a raster dataset."),
    ("zonal-stats", "Calculate raster zonal statistics"),
]

VECTOR_COMMANDS = [
    ("buffer", "Compute a buffer around geometries of a vector dataset."),
    ("check-coverage", "Check a polygon coverage for validity"),
    ("check-geometry", "Check a dataset for invalid geometries"),
    ("clean-coverage", "Alter polygon boundaries to make shared edges identical, removing gaps and overlaps"),
    ("clip", "Clip a vector dataset."),
    ("combine", "Combine features into collections"),
    ("concat", "Concatenate vector datasets."),
    ("concave-hull", "Compute the concave hull of geometries of a vector dataset."),
    ("convert", "Convert a vector dataset."),
    ("convex-hull", "Compute the convex hull of geometries of a vector dataset."),
    ("create", "Create a vector dataset."),
    ("dissolve", "Dissolves multipart features"),
    ("edit", "Edit metadata of a vector dataset."),
    ("explode-collections", "Explode geometries of type collection of a vector dataset."),
    ("export-schema", "Export the OGR_SCHEMA from a vector dataset."),
    ("filter", "Filter a vector dataset."),
    ("grid", "Create a regular grid from scattered points."),
    ("index", "Create a vector index of vector datasets."),
    ("info", "Return information on a vector dataset."),
    ("layer-algebra", "Perform algebraic operation between 2 layers."),
    ("make-point", "Create point geometries from attribute fields"),
    ("make-valid", "Fix validity of geometries of a vector dataset."),
    ("partition", "Partition a vector dataset into multiple files."),
    ("pipeline", "Process a vector dataset applying several steps."),
    ("rasterize", "Burns vector geometries into a raster."),
    ("rename-layer", "Rename layer(s) of a vector dataset."),
    ("reproject", "Reproject a vector dataset."),
    ("segmentize", "Segmentize geometries of a vector dataset."),
    ("select", "Select a subset of fields from a vector dataset."),
    ("set-field-type", "Modify the type of a field of a vector dataset."),
    ("set-geom-type", "Modify the geometry type of a vector dataset."),
    ("simplify", "Simplify geometries of a vector dataset."),
    ("simplify-coverage", "Simplify shared boundaries of a polygonal vector dataset."),
    ("sort", "Spatially order the features in a layer"),
    ("sql", "Apply SQL statement(s) to a dataset."),
    ("swap-xy", "Swap X and Y coordinates of geometries of a vector dataset."),
    ("update", "Update an existing vector dataset with an input vector dataset."),
]


def out(text=""):
    print(text, end="" if text.endswith("\n") else "\n")


def err(text):
    print(text, file=sys.stderr)


def strip_global(args):
    res = []
    i = 0
    while i < len(args):
        a = args[i]
        if a == "--config":
            i += 2
        elif a.startswith("--config="):
            i += 1
        else:
            res.append(a)
            i += 1
    return res


def wants_help(args):
    return "-h" in args or "--help" in args


def wants_json(args):
    return "--json-usage" in args


def dump_json(obj):
    print(json.dumps(obj, indent=2, separators=(",", ":")))


def usage_json(name="gdal", desc="Main gdal entry point."):
    sub = [{"name": c, "description": d} for c, d in [
        ("dataset", "Commands to manage datasets."),
        ("driver", "Command for driver specific operations."),
        ("raster", "Raster commands."),
        ("vector", "Vector commands."),
        ("vsi", "GDAL Virtual System Interface (VSI) commands."),
    ]]
    dump_json({"description": desc, "short_url": "/programs/index.html", "url": "https://gdal.org/programs/index.html", "sub_algorithms": sub, "input_arguments": [], "output_arguments": [], "input_output_arguments": []})


def main_help(error=None, try_help=False):
    if error:
        err(error)
    if try_help:
        out("""Usage: gdal <COMMAND> [OPTIONS]
where <COMMAND> is one of:
  - convert:  Convert a dataset (shortcut for 'gdal raster convert' or 'gdal vector convert').
  - dataset:  Commands to manage datasets.
  - driver:   Command for driver specific operations.
  - info:     Return information on a dataset (shortcut for 'gdal raster info' or 'gdal vector info').
  - mdim:     Multidimensional commands.
  - pipeline: Process a dataset applying several steps.
  - raster:   Raster commands.
  - vector:   Vector commands.
  - vsi:      GDAL Virtual System Interface (VSI) commands.

Try 'gdal --help' for help.

'gdal <FILENAME>' can also be used as a shortcut for 'gdal info <FILENAME>'.
And 'gdal read <FILENAME> ! ...' as a shortcut for 'gdal pipeline <FILENAME> ! ...'.

For more details, consult https://gdal.org/programs/index.html

""" + WARNING)
        return
    out(MAIN_HELP)


def group_help(kind):
    if kind == "dataset":
        return """Usage: gdal dataset <SUBCOMMAND> [OPTIONS]
where <SUBCOMMAND> is one of:
  - check:    Check whether there are errors when reading the content of a dataset.
  - copy:     Copy files of a dataset. (alias: cp)
  - delete:   Delete dataset(s). (alias: rm, remove)
  - identify: Identify driver opening dataset(s).
  - rename:   Rename files of a dataset. (alias: ren, mv)

Common Options:
  -h, --help              Display help message and exit
  --json-usage            Display usage as JSON document and exit
  --config <KEY>=<VALUE>  Configuration option [may be repeated]

For more details, consult https://gdal.org/programs/gdal_dataset.html

""" + WARNING
    if kind == "vsi":
        return """Usage: gdal vsi <SUBCOMMAND> [OPTIONS]
where <SUBCOMMAND> is one of:
  - copy:   Copy files located on GDAL Virtual System Interface (VSI). (alias: cp)
  - delete: Delete files located on GDAL Virtual System Interface (VSI). (alias: rm, rmdir, del)
  - list:   List files of one of the GDAL Virtual System Interface (VSI). (alias: ls)
  - move:   Move/rename a file/directory located on GDAL Virtual System Interface (VSI). (alias: mv, ren, rename)
  - sozip:  Seek-optimized ZIP (SOZIP) commands.
  - sync:   Synchronize source and target file/directory located on GDAL Virtual System Interface (VSI).

Common Options:
  -h, --help              Display help message and exit
  --json-usage            Display usage as JSON document and exit
  --config <KEY>=<VALUE>  Configuration option [may be repeated]

For more details, consult https://gdal.org/programs/gdal_vsi.html

""" + WARNING
    if kind == "raster":
        lines = ["Usage: gdal raster <SUBCOMMAND> [OPTIONS]", "where <SUBCOMMAND> is one of:"]
        for name, desc in RASTER_COMMANDS:
            lines.append(f"  - {name + ':':17} {desc}")
        lines += ["", "Common Options:", "  -h, --help              Display help message and exit", "  --json-usage            Display usage as JSON document and exit", "  --config <KEY>=<VALUE>  Configuration option [may be repeated]", "", "Options:", "  --drivers               Display raster driver list as JSON document", "", "For more details, consult https://gdal.org/programs/gdal_raster.html", "", WARNING]
        return "\n".join(lines)
    if kind == "vector":
        lines = ["Usage: gdal vector <SUBCOMMAND> [OPTIONS]", "where <SUBCOMMAND> is one of:"]
        for name, desc in VECTOR_COMMANDS:
            lines.append(f"  - {name + ':':21} {desc}")
        lines += ["", "Common Options:", "  -h, --help              Display help message and exit", "  --json-usage            Display usage as JSON document and exit", "  --config <KEY>=<VALUE>  Configuration option [may be repeated]", "", "Options:", "  --drivers               Display vector driver list as JSON document and exit", "", "For more details, consult https://gdal.org/programs/gdal_vector.html", "", WARNING]
        return "\n".join(lines)
    if kind == "mdim":
        return """Usage: gdal mdim <SUBCOMMAND> [OPTIONS]
where <SUBCOMMAND> is one of:
  - convert: Convert a multidimensional dataset.
  - info:    Return information on a multidimensional dataset.
  - mosaic:  Build a mosaic, either virtual (VRT) or materialized, from multidimensional datasets.

Common Options:
  -h, --help              Display help message and exit
  --json-usage            Display usage as JSON document and exit
  --config <KEY>=<VALUE>  Configuration option [may be repeated]

Options:
  --drivers               Display multidimensional driver list as JSON document

For more details, consult https://gdal.org/programs/gdal_mdim.html

""" + WARNING
    if kind == "driver":
        return """Usage: gdal driver <SUBCOMMAND> [OPTIONS]
where <SUBCOMMAND> is one of:
  - cog: Command for COG driver specific operations.

Common Options:
  -h, --help              Display help message and exit
  --json-usage            Display usage as JSON document and exit
  --config <KEY>=<VALUE>  Configuration option [may be repeated]

""" + WARNING
    return MAIN_HELP


def specific_help(path):
    key = " ".join(path)
    helps = {
        "vsi list": """Usage: gdal vsi list [OPTIONS] <FILENAME>

List files of one of the GDAL Virtual System Interface (VSI).

Positional arguments:
  --filename <FILENAME>                                File or directory name [required]

Common Options:
  -h, --help                                           Display help message and exit
  --json-usage                                         Display usage as JSON document and exit
  --config <KEY>=<VALUE>                               Configuration option [may be repeated]

Options:
  -f, --of, --format, --output-format <OUTPUT-FORMAT>  Output format. OUTPUT-FORMAT=json|text
  -l, --long, --long-listing                           Use a long listing format
  -R, --recursive                                      List subdirectories recursively
  --depth <DEPTH>                                      Maximum depth in recursive mode
  --abs, --absolute-path                               Display absolute path
  --tree                                               Use a hierarchical presentation for JSON output

For more details, consult https://gdal.org/programs/gdal_vsi_list.html

""" + WARNING,
        "vsi copy": """Usage: gdal vsi copy [OPTIONS] <SOURCE> <DESTINATION>

Copy files located on GDAL Virtual System Interface (VSI).

Positional arguments:
  --source <SOURCE>            Source file or directory name [required]
  --destination <DESTINATION>  Destination file or directory name [required]

Common Options:
  -h, --help                   Display help message and exit
  --json-usage                 Display usage as JSON document and exit
  --config <KEY>=<VALUE>       Configuration option [may be repeated]
  -q, --quiet                  Quiet mode (no progress bar or warning message)

Options:
  -r, --recursive              Copy subdirectories recursively
  --skip-errors                Skip errors

For more details, consult https://gdal.org/programs/gdal_vsi_copy.html

""" + WARNING,
        "vsi delete": """Usage: gdal vsi delete [OPTIONS] <FILENAME>

Delete files located on GDAL Virtual System Interface (VSI).

Positional arguments:
  --filename <FILENAME>   File or directory name to delete [required]

Common Options:
  -h, --help              Display help message and exit
  --json-usage            Display usage as JSON document and exit
  --config <KEY>=<VALUE>  Configuration option [may be repeated]

Options:
  -r, -R, --recursive     Delete directories recursively

For more details, consult https://gdal.org/programs/gdal_vsi_delete.html

""" + WARNING,
        "vsi move": """Usage: gdal vsi move [OPTIONS] <SOURCE> <DESTINATION>

Move/rename a file/directory located on GDAL Virtual System Interface (VSI).

Positional arguments:
  --source <SOURCE>            Source file or directory name [required]
  --destination <DESTINATION>  Destination file or directory name [required]

Common Options:
  -h, --help                   Display help message and exit
  --json-usage                 Display usage as JSON document and exit
  --config <KEY>=<VALUE>       Configuration option [may be repeated]
  -q, --quiet                  Quiet mode (no progress bar or warning message)

For more details, consult https://gdal.org/programs/gdal_vsi_move.html

""" + WARNING,
        "dataset identify": """Usage: gdal dataset identify [OPTIONS] <FILENAME>

Identify driver opening dataset(s).

Positional arguments:
  --input, --filename <FILENAME>                       File or directory name [may be repeated] [required]

Common Options:
  -h, --help                                           Display help message and exit
  --json-usage                                         Display usage as JSON document and exit
  --config <KEY>=<VALUE>                               Configuration option [may be repeated]
  -q, --quiet                                          Quiet mode (no progress bar or warning message)

Options:
  -o, --output <OUTPUT>                                Output vector dataset (created by algorithm)
  -f, --of, --format, --output-format <OUTPUT-FORMAT>  Output format
  --co, --creation-option <KEY>=<VALUE>                Creation option [may be repeated]
  --lco, --layer-creation-option <KEY>=<VALUE>         Layer creation option [may be repeated]
  -l, --output-layer <OUTPUT-LAYER>                    Output layer name
  --overwrite                                          Whether overwriting existing output dataset is allowed
  -r, --recursive                                      Recursively scan files/folders for datasets
  --force-recursive                                    Recursively scan folders for datasets, forcing recursion in folders recognized as valid formats
  --detailed                                           Most detailed output. Reports the presence of georeferencing, if a GeoTIFF file is cloud optimized, etc.
  --report-failures                                    Report failures if file type is unidentified

For more details, consult https://gdal.org/programs/gdal_dataset_identify.html

""" + WARNING,
    }
    if key in helps:
        return helps[key]
    if key in ("dataset copy", "dataset cp"):
        return """Usage: gdal dataset copy [OPTIONS] <SOURCE> <DESTINATION>

Copy files of a dataset.

Positional arguments:
  --source <SOURCE>            Source dataset name [required]
  --destination <DESTINATION>  Destination dataset name [required]

Common Options:
  -h, --help                   Display help message and exit
  --json-usage                 Display usage as JSON document and exit
  --config <KEY>=<VALUE>       Configuration option [may be repeated]

Options:
  --overwrite                  Whether overwriting existing output dataset is allowed

Advanced Options:
  -f, --format <FORMAT>        Dataset format

For more details, consult https://gdal.org/programs/gdal_dataset_copy.html

""" + WARNING
    if key in ("dataset delete", "dataset rm", "dataset remove"):
        return """Usage: gdal dataset delete [OPTIONS] <FILENAME>

Delete dataset(s).

Positional arguments:
  --filename <FILENAME>   File or directory name [may be repeated] [required]

Common Options:
  -h, --help              Display help message and exit
  --json-usage            Display usage as JSON document and exit
  --config <KEY>=<VALUE>  Configuration option [may be repeated]

Advanced Options:
  -f, --format <FORMAT>   Dataset format

For more details, consult https://gdal.org/programs/gdal_dataset_delete.html

""" + WARNING
    if key in ("dataset rename", "dataset ren", "dataset mv"):
        return """Usage: gdal dataset rename [OPTIONS] <SOURCE> <DESTINATION>

Rename files of a dataset.

Positional arguments:
  --source <SOURCE>            Source dataset name [required]
  --destination <DESTINATION>  Destination dataset name [required]

Common Options:
  -h, --help                   Display help message and exit
  --json-usage                 Display usage as JSON document and exit
  --config <KEY>=<VALUE>       Configuration option [may be repeated]

Options:
  --overwrite                  Whether overwriting existing output dataset is allowed

Advanced Options:
  -f, --format <FORMAT>        Dataset format

For more details, consult https://gdal.org/programs/gdal_dataset_rename.html

""" + WARNING
    if key in ("info", "raster info"):
        return """Usage: gdal raster info [OPTIONS] <INPUT>

Return information on a raster dataset.

Positional arguments:
  -i, --dataset, --input <INPUT>                       Input raster dataset [required]

Common Options:
  -h, --help                                           Display help message and exit
  --json-usage                                         Display usage as JSON document and exit
  --config <KEY>=<VALUE>                               Configuration option [may be repeated]

Options:
  -f, --of, --format, --output-format <OUTPUT-FORMAT>  Output format. OUTPUT-FORMAT=json|text

For more details, consult https://gdal.org/programs/gdal_raster_info.html

""" + WARNING
    if key == "vector info":
        return """Usage: gdal vector info [OPTIONS] <INPUT>...

Return information on a vector dataset.

Positional arguments:
  -i, --dataset, --input <INPUT>                       Input vector datasets [may be repeated] [required]

Common Options:
  -h, --help                                           Display help message and exit
  --json-usage                                         Display usage as JSON document and exit
  --config <KEY>=<VALUE>                               Configuration option [may be repeated]

Options:
  -f, --of, --format, --output-format <OUTPUT-FORMAT>  Output format. OUTPUT-FORMAT=json|text

For more details, consult https://gdal.org/programs/gdal_vector_info.html

""" + WARNING
    if key == "convert":
        return """Usage: gdal convert [OPTIONS] <INPUT> <OUTPUT>

Convert a dataset (shortcut for 'gdal raster convert' or 'gdal vector convert').

Positional arguments:
  -i, --input <INPUT>                                  Input raster, vector or multidimensional raster dataset [required]
  -o, --output <OUTPUT>                                Output raster, vector or multidimensional raster dataset (created by algorithm) [required]

Common Options:
  -h, --help                                           Display help message and exit
  --json-usage                                         Display usage as JSON document and exit
  --config <KEY>=<VALUE>                               Configuration option [may be repeated]
  -q, --quiet                                          Quiet mode (no progress bar or warning message)

Options:
  -f, --of, --format, --output-format <OUTPUT-FORMAT>  Output format

For all options, run 'gdal raster convert --help' or 'gdal vector convert --help'

For more details, consult https://gdal.org/programs/gdal_convert.html

""" + WARNING
    return None


def positional(args):
    vals = []
    skip_next = {"--config", "-f", "--of", "--format", "--output-format", "--depth", "--if", "--input-format", "--oo", "--open-option", "-i", "--input", "--dataset", "--filename", "--source", "--destination", "-o", "--output"}
    i = 0
    while i < len(args):
        a = args[i]
        if a in skip_next:
            if i + 1 < len(args) and a in ("-i", "--input", "--dataset", "--filename", "--source", "--destination", "-o", "--output"):
                vals.append(args[i + 1])
            i += 2
        elif a.startswith("-"):
            i += 1
        else:
            vals.append(a)
            i += 1
    return vals


def driver_for(path):
    ext = os.path.splitext(path.lower())[1].lstrip(".")
    for d in DRIVERS:
        if ext in d.get("file_extensions", []):
            return d["short_name"]
    return None


def dataset_identify(args):
    files = positional(args)
    report = "--report-failures" in args or "--detailed" in args
    quiet = "-q" in args or "--quiet" in args
    fmt_json = any(args[i] in ("-f", "--of", "--format", "--output-format") and i + 1 < len(args) and args[i + 1] == "json" for i in range(len(args)))
    results = []
    for f in files:
        drv = driver_for(f) if os.path.exists(f) else None
        if drv:
            results.append({"name": f, "driver": drv})
            if not quiet and not fmt_json:
                out(f"{f}: {drv}")
        elif report and not quiet and not fmt_json:
            out(f"{f}: unrecognized")
    if fmt_json:
        dump_json(results)
    return 0


def vsi_entries(root, recursive=False, depth=None, absolute=False):
    if os.path.isfile(root):
        return [os.path.abspath(root) if absolute else os.path.basename(root)]
    entries = []
    base = root
    if not os.path.isdir(base):
        return entries
    def walk(cur, level):
        try:
            names = os.listdir(cur)
        except OSError:
            return
        for name in names:
            p = os.path.join(cur, name)
            rel = os.path.relpath(p, base)
            entries.append(os.path.abspath(p) if absolute else rel)
            if recursive and os.path.isdir(p) and (depth is None or level < depth):
                walk(p, level + 1)
    walk(base, 1)
    return entries


def mode_string(st):
    return stat.filemode(st.st_mode)


def vsi_list(args):
    vals = positional(args)
    path = vals[-1] if vals else "."
    recursive = "-R" in args or "--recursive" in args
    absolute = "--abs" in args or "--absolute-path" in args
    long = "-l" in args or "--long" in args or "--long-listing" in args
    fmt = "text"
    depth = None
    for i, a in enumerate(args):
        if a in ("-f", "--of", "--format", "--output-format") and i + 1 < len(args):
            fmt = args[i + 1]
        if a == "--depth" and i + 1 < len(args):
            try:
                depth = int(args[i + 1])
            except ValueError:
                pass
    entries = vsi_entries(path, recursive, depth, absolute)
    if fmt == "json":
        dump_json(entries)
        return 0
    for e in entries:
        p = e if absolute else os.path.join(path, e)
        if long:
            try:
                st = os.stat(p)
                dt = datetime.fromtimestamp(st.st_mtime).strftime("%Y-%m-%d %H:%M")
                out(f"{mode_string(st)} 1 unknown unknown {st.st_size:12d} {dt} {e}")
            except OSError:
                out(e)
        else:
            out(e)
    return 0


def progress(args):
    if "-q" not in args and "--quiet" not in args:
        out("0...10...20...30...40...50...60...70...80...90...100 - done.")


def copy_path(src, dst, recursive=False, overwrite=False):
    if not os.path.exists(src):
        err(f"ERROR 3: copy: '{src}' cannot be accessed.")
        return 1
    if os.path.isdir(src):
        if not recursive:
            err(f"ERROR 1: copy: Source is a directory. Specify --recursive")
            return 1
        if os.path.exists(dst):
            if overwrite:
                shutil.rmtree(dst) if os.path.isdir(dst) else os.remove(dst)
            else:
                err(f"ERROR 1: copy: '{dst}' already exists.")
                return 1
        shutil.copytree(src, dst)
    else:
        if os.path.isdir(dst):
            dst = os.path.join(dst, os.path.basename(src))
        if os.path.exists(dst) and not overwrite:
            err(f"ERROR 1: copy: '{dst}' already exists.")
            return 1
        shutil.copy2(src, dst)
    return 0


def two_operands(args):
    vals = positional(args)
    return (vals[-2], vals[-1]) if len(vals) >= 2 else (None, None)


def cmd_copy(args, show_progress=True):
    src, dst = two_operands(args)
    if not src or not dst:
        err("ERROR 1: copy: Missing source or destination.")
        return 1
    rc = copy_path(src, dst, "-r" in args or "--recursive" in args, "--overwrite" in args)
    if rc == 0 and show_progress:
        progress(args)
    return rc


def cmd_move(args):
    src, dst = two_operands(args)
    if not src or not dst:
        err("ERROR 1: move: Missing source or destination.")
        return 1
    if not os.path.exists(src):
        err(f"ERROR 3: move: '{src}' cannot be accessed.")
        return 1
    if os.path.exists(dst):
        if "--overwrite" in args:
            shutil.rmtree(dst) if os.path.isdir(dst) else os.remove(dst)
        else:
            err(f"ERROR 1: move: '{dst}' already exists.")
            return 1
    shutil.move(src, dst)
    progress(args)
    return 0


def cmd_delete(args):
    vals = positional(args)
    rc = 0
    recursive = "-r" in args or "-R" in args or "--recursive" in args
    for p in vals:
        try:
            if os.path.isdir(p):
                if recursive:
                    shutil.rmtree(p)
                else:
                    os.rmdir(p)
            else:
                os.remove(p)
        except FileNotFoundError:
            err(f"ERROR 4: delete: '{p}' does not exist.")
            rc = 1
        except OSError as e:
            err(f"ERROR 1: delete: {e}")
            rc = 1
    return rc


def info(args, vector=False):
    vals = positional(args)
    fmt = "text"
    for i, a in enumerate(args):
        if a in ("-f", "--of", "--format", "--output-format") and i + 1 < len(args):
            fmt = args[i + 1]
    target = vals[-1] if vals else None
    if not target:
        err("ERROR 1: info: Argument 'input' has no explicit value.")
        return 1
    drv = driver_for(target) or "Unknown"
    if fmt == "json":
        dump_json({"description": target, "driverShortName": drv, "files": [target] if os.path.exists(target) else []})
    else:
        if not os.path.exists(target):
            err(f"ERROR 4: `{target}' not recognized as being in a supported file format.")
            return 1
        out(f"Driver: {drv}/{drv}")
        out(f"Files: {target}")
        if os.path.isfile(target):
            out(f"Size is {os.path.getsize(target)} bytes")
    return 0


def convert(args):
    src, dst = two_operands(args)
    if not src or not dst:
        err("ERROR 1: convert: Missing input or output.")
        return 1
    rc = copy_path(src, dst, False, "--overwrite" in args)
    if rc == 0:
        progress(args)
    return rc


def dispatch(argv):
    args = strip_global(argv[1:])
    if not args:
        main_help("ERROR 1: gdal: Missing command name.", True)
        return 1
    if wants_json(args):
        usage_json()
        return 0
    if args[0] in ("-h", "--help"):
        out(MAIN_HELP)
        return 0
    if args[0] == "--version":
        out(VERSION)
        return 0
    if args[0] == "--drivers":
        dump_json(DRIVERS)
        return 0
    if args[0].startswith("-"):
        main_help(f"ERROR 5: gdal: Option '{args[0]}' is unknown.", True)
        return 1

    cmd = args[0]
    rest = args[1:]
    if cmd == "convert":
        if wants_help(rest):
            out(specific_help(["convert"]))
            return 0
        return convert(rest)
    if cmd == "info":
        if wants_help(rest):
            out(specific_help(["info"]))
            return 0
        return info(rest)
    if cmd in ("raster", "vector", "dataset", "vsi", "mdim", "driver"):
        if not rest or rest[0] in ("-h", "--help"):
            out(group_help(cmd))
            return 0 if rest else 1
        if "--drivers" in rest:
            scopes = {"raster": "raster", "vector": "vector", "mdim": "multidimensional_raster"}[cmd]
            dump_json([d for d in DRIVERS if scopes in d.get("scopes", [])])
            return 0
        sub = rest[0]
        subargs = rest[1:]
        aliases = {"ls": "list", "cp": "copy", "rm": "delete", "rmdir": "delete", "del": "delete", "mv": "move", "ren": "rename", "remove": "delete"}
        sub = aliases.get(sub, sub)
        if wants_help(subargs):
            h = specific_help([cmd, sub])
            if h:
                out(h)
                return 0
        if cmd == "vsi":
            if sub == "list":
                return vsi_list(subargs)
            if sub in ("copy", "sync"):
                return cmd_copy(subargs, True)
            if sub == "delete":
                return cmd_delete(subargs)
            if sub in ("move", "rename"):
                return cmd_move(subargs)
            err(f"ERROR 1: vsi: Unknown command: '{sub}'")
            out(group_help("vsi"))
            return 1
        if cmd == "dataset":
            if sub == "identify":
                return dataset_identify(subargs)
            if sub == "copy":
                return cmd_copy(subargs, False)
            if sub == "delete":
                return cmd_delete(subargs)
            if sub in ("rename", "move"):
                return cmd_move(subargs)
            if sub == "check":
                vals = positional(subargs)
                return 0 if vals and os.path.exists(vals[-1]) else 1
            err(f"ERROR 1: dataset: Unknown command: '{sub}'")
            out(group_help("dataset"))
            return 1
        if cmd == "raster":
            if sub == "info":
                return info(subargs)
            if sub in ("convert", "create"):
                return convert(subargs)
            err(f"ERROR 1: raster: Unknown command: '{sub}'")
            out(group_help("raster"))
            return 1
        if cmd == "vector":
            if sub == "info":
                return info(subargs, True)
            if sub in ("convert", "create"):
                return convert(subargs)
            err(f"ERROR 1: vector: Unknown command: '{sub}'")
            out(group_help("vector"))
            return 1
        out(group_help(cmd))
        return 1

    if os.path.exists(cmd):
        return info([cmd] + rest)
    main_help(f"ERROR 1: gdal: Unknown command: '{cmd}'", True)
    return 1


if __name__ == "__main__":
    sys.exit(dispatch(sys.argv))
