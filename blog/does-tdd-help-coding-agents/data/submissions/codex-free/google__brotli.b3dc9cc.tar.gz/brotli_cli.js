#!/usr/bin/env node
"use strict";

const fs = require("fs");
const path = require("path");
const zlib = require("zlib");

const HELP = `Usage: executable [OPTION]... [FILE]...
Options:
  -#                          compression level (0-9)
  -c, --stdout                write on standard output
  -d, --decompress            decompress
  -f, --force                 force output file overwrite
  -h, --help                  display this help and exit
  -j, --rm                    remove source file(s)
  -s, --squash                remove destination file if larger than source
  -k, --keep                  keep source file(s) (default)
  -n, --no-copy-stat          do not copy source file(s) attributes
  -o FILE, --output=FILE      output file (only if 1 input file)
  -q NUM, --quality=NUM       compression level (0-11)
  -t, --test                  test compressed file integrity
  -v, --verbose               verbose mode
  -w NUM, --lgwin=NUM         set LZ77 window size (0, 10-24)
                              window size = 2**NUM - 16
                              0 lets compressor choose the optimal value
  --large_window=NUM          use incompatible large-window brotli
                              bitstream with window size (0, 10-30)
                              WARNING: this format is not compatible
                              with brotli RFC 7932 and may not be
                              decodable with regular brotli decoders
  -C B64, --comment=B64       set comment; argument is base64-decoded first;
                              (maximal decoded length: 80)
                              when decoding: check stream comment;
                              when encoding: embed comment (fingerprint)
  -D FILE, --dictionary=FILE  use FILE as raw (LZ77) dictionary
  -K, --concatenated          allows concatenated brotli streams as input
  -S SUF, --suffix=SUF        output file suffix (default:'.br')
  -V, --version               display version and exit
  -Z, --best                  use best compression level (11) (default)
Simple options could be coalesced, i.e. '-9kf' is equivalent to '-9 -k -f'.
With no FILE, or when FILE is -, read standard input.
All arguments after '--' are treated as files.
`;

function usageError(msg) {
  if (msg) process.stderr.write(msg + "\n");
  process.stderr.write(HELP);
  process.exit(1);
}

function parseNum(name, value, min, max, allowZero) {
  if (!/^[0-9]+$/.test(value)) usageError(`error parsing ${name} value [${value}]`);
  const n = Number(value);
  if (n === 0 && allowZero) return n;
  if (name === "lgwin" && n < min) usageError(`lgwin parameter (${n}) smaller than the minimum (${min})`);
  if (n < min || n > max) usageError(`error parsing ${name} value [${value}]`);
  return n;
}

function parseArgs(argv) {
  const o = {
    stdout: false, decompress: false, force: false, rm: false, keep: true,
    noCopyStat: false, output: null, quality: 11, test: false, verbose: 0,
    lgwin: 0, suffix: ".br", comment: null, dictionary: null, concatenated: false,
    files: []
  };
  function needValue(args, idx, opt) {
    if (idx + 1 >= args.length) usageError(`expected parameter for argument ${opt}`);
    return args[idx + 1];
  }
  for (let i = 0; i < argv.length; i++) {
    const a = argv[i];
    if (a === "--") {
      o.files.push(...argv.slice(i + 1));
      break;
    }
    if (a === "-" || !a.startsWith("-")) {
      o.files.push(a);
      continue;
    }
    if (a.startsWith("--")) {
      let name = a, value = null;
      const eq = a.indexOf("=");
      if (eq >= 0) {
        name = a.slice(0, eq);
        value = a.slice(eq + 1);
      }
      const takes = new Set(["--output", "--quality", "--lgwin", "--large_window", "--comment", "--dictionary", "--suffix"]);
      if (takes.has(name) && value === null) {
        if (!["--output", "--quality", "--lgwin", "--comment", "--dictionary", "--suffix"].includes(name)) {
          usageError(`must pass the parameter as ${name}=value`);
        }
        value = needValue(argv, i, name);
        i++;
      }
      switch (name) {
        case "--stdout": o.stdout = true; break;
        case "--decompress": o.decompress = true; break;
        case "--force": o.force = true; break;
        case "--help": process.stdout.write(HELP); process.exit(0);
        case "--rm": o.rm = true; o.keep = false; break;
        case "--squash": o.squash = true; break;
        case "--keep": o.keep = true; o.rm = false; break;
        case "--no-copy-stat": o.noCopyStat = true; break;
        case "--output": o.output = value; break;
        case "--quality": o.quality = parseNum("quality", value, 0, 11, true); break;
        case "--test": o.test = true; o.decompress = true; o.stdout = true; break;
        case "--verbose": o.verbose++; break;
        case "--lgwin": o.lgwin = parseNum("lgwin", value, 10, 24, true); break;
        case "--large_window": o.lgwin = parseNum("lgwin", value, 10, 30, true); break;
        case "--comment": o.comment = decodeComment(value); break;
        case "--dictionary": o.dictionary = fs.readFileSync(value); break;
        case "--concatenated": o.concatenated = true; break;
        case "--suffix": o.suffix = value; break;
        case "--version": process.stdout.write("brotli 1.2.0\n"); process.exit(0);
        case "--best": o.quality = 11; break;
        default: usageError(`must pass the parameter as ${name}=value`);
      }
      continue;
    }
    for (let j = 1; j < a.length; j++) {
      const ch = a[j];
      const rest = a.slice(j + 1);
      const valOpt = (opt) => {
        if (rest.length) {
          j = a.length;
          return rest;
        }
        const v = needValue(argv, i, "-" + opt);
        i++;
        j = a.length;
        return v;
      };
      if (/[0-9]/.test(ch)) { o.quality = Number(ch); continue; }
      switch (ch) {
        case "c": o.stdout = true; break;
        case "d": o.decompress = true; break;
        case "f": o.force = true; break;
        case "h": process.stdout.write(HELP); process.exit(0);
        case "j": o.rm = true; o.keep = false; break;
        case "s": o.squash = true; break;
        case "k": o.keep = true; o.rm = false; break;
        case "n": o.noCopyStat = true; break;
        case "o": o.output = valOpt("o"); break;
        case "q": o.quality = parseNum("quality", valOpt("q"), 0, 11, true); break;
        case "t": o.test = true; o.decompress = true; o.stdout = true; break;
        case "v": o.verbose++; break;
        case "w": o.lgwin = parseNum("lgwin", valOpt("w"), 10, 24, true); break;
        case "C": o.comment = decodeComment(valOpt("C")); break;
        case "D": o.dictionary = fs.readFileSync(valOpt("D")); break;
        case "K": o.concatenated = true; break;
        case "S": o.suffix = valOpt("S"); break;
        case "V": process.stdout.write("brotli 1.2.0\n"); process.exit(0);
        case "Z": o.quality = 11; break;
        default: usageError(`invalid option -- ${ch}`);
      }
    }
  }
  if (o.files.length === 0) o.files.push("-");
  if (o.output !== null && o.files.length !== 1) usageError("argument --output is only valid with a single input");
  return o;
}

function decodeComment(s) {
  const b = Buffer.from(s, "base64");
  if (b.length > 80) usageError("comment is longer than 80 bytes");
  return b;
}

function compress(buf, o) {
  const params = {
    [zlib.constants.BROTLI_PARAM_QUALITY]: o.quality
  };
  if (o.lgwin) params[zlib.constants.BROTLI_PARAM_LGWIN] = o.lgwin;
  const opts = { params };
  if (o.dictionary) opts.dictionary = o.dictionary;
  return zlib.brotliCompressSync(buf, opts);
}

function decompress(buf, o) {
  const opts = o.dictionary ? { dictionary: o.dictionary } : undefined;
  if (!o.concatenated) return zlib.brotliDecompressSync(buf, opts);
  const parts = [];
  let rest = buf;
  while (rest.length) {
    let found = false;
    for (let i = 1; i <= rest.length; i++) {
      try {
        parts.push(zlib.brotliDecompressSync(rest.subarray(0, i), opts));
        rest = rest.subarray(i);
        found = true;
        break;
      } catch (_) {}
    }
    if (!found) throw new Error("corrupt input");
  }
  return Buffer.concat(parts);
}

function outputName(input, o) {
  if (o.output !== null) return o.output;
  if (o.stdout || input === "-") return null;
  if (o.decompress) {
    if (!input.endsWith(o.suffix)) {
      throw new Error(`empty output file name for [${input}] input file`);
    }
    const out = input.slice(0, -o.suffix.length);
    if (out.length === 0) throw new Error(`empty output file name for [${input}] input file`);
    return out;
  }
  return input + o.suffix;
}

function readInput(name) {
  if (name === "-") return fs.readFileSync(0);
  try {
    return fs.readFileSync(name);
  } catch (e) {
    throw new Error(`failed to open input file [${name}]: ${e.message.split(": ").pop()}`);
  }
}

function writeOutput(name, data, input, o) {
  if (name === null) {
    if (!o.test) fs.writeSync(1, data);
    return;
  }
  if (!o.force && fs.existsSync(name)) throw new Error(`failed to open output file [${name}]: File exists`);
  fs.writeFileSync(name, data);
  if (!o.noCopyStat && input !== "-") {
    try {
      const st = fs.statSync(input);
      fs.chmodSync(name, st.mode & 0o7777);
      fs.utimesSync(name, st.atime, st.mtime);
    } catch (_) {}
  }
  if (o.squash && input !== "-") {
    try {
      if (fs.statSync(name).size > fs.statSync(input).size) fs.unlinkSync(name);
    } catch (_) {}
  }
}

function processFile(file, o) {
  const input = readInput(file);
  let output;
  try {
    output = o.decompress ? decompress(input, o) : compress(input, o);
  } catch (e) {
    throw new Error(`corrupt input [${file}]`);
  }
  const outName = outputName(file, o);
  writeOutput(outName, output, file, o);
  if (o.rm && file !== "-") {
    try { fs.unlinkSync(file); } catch (_) {}
  }
}

function main() {
  const o = parseArgs(process.argv.slice(2));
  let rc = 0;
  for (const f of o.files) {
    try {
      processFile(f, o);
    } catch (e) {
      process.stderr.write(e.message + "\n");
      rc = 1;
    }
  }
  process.exit(rc);
}

main();
