#!/usr/bin/env python3
import argparse
import glob
import html
import os
import re
import sys
from html.parser import HTMLParser
from urllib.parse import quote, urljoin


BLOCK_TAGS = {
    "address", "article", "aside", "body", "center", "dd", "details", "dialog",
    "dir", "div", "dl", "dt", "fieldset", "figcaption", "figure", "footer",
    "form", "header", "html", "legend", "main", "nav", "section", "summary",
}


def esc_text(s):
    s = html.unescape(s)
    s = s.replace("\r\n", "\n").replace("\r", "\n")
    s = re.sub(r"[ \t\n\f\v]+", " ", s)
    specials = "\\`*_{}[]()#+-.!|"
    out = []
    for ch in s:
        if ch in specials:
            out.append("\\" + ch)
        else:
            out.append(ch)
    return "".join(out)


def normalize_ws(s):
    return re.sub(r"[ \t\n\f\v]+", " ", s).strip()


class Node:
    def __init__(self, tag=None, attrs=None, text=None):
        self.tag = tag
        self.attrs = dict(attrs or [])
        self.children = []
        self.text = text


class TreeParser(HTMLParser):
    def __init__(self):
        super().__init__(convert_charrefs=False)
        self.root = Node("root")
        self.stack = [self.root]

    def handle_starttag(self, tag, attrs):
        tag = tag.lower()
        n = Node(tag, attrs)
        self.stack[-1].children.append(n)
        if tag not in {"br", "hr", "img", "meta", "link", "input", "source", "area", "base", "col", "embed", "param", "track", "wbr"}:
            self.stack.append(n)

    def handle_startendtag(self, tag, attrs):
        self.handle_starttag(tag, attrs)

    def handle_endtag(self, tag):
        tag = tag.lower()
        for i in range(len(self.stack) - 1, 0, -1):
            if self.stack[i].tag == tag:
                del self.stack[i:]
                break

    def handle_data(self, data):
        if data:
            self.stack[-1].children.append(Node(text=data))

    def handle_entityref(self, name):
        self.handle_data("&" + name + ";")

    def handle_charref(self, name):
        self.handle_data("&#" + name + ";")


def parse_selector(sel):
    sel = (sel or "").strip()
    if not sel:
        return None
    m = re.match(r"^([a-zA-Z0-9_-]+)?(?:#([a-zA-Z0-9_-]+))?(?:\.([a-zA-Z0-9_-]+))?$", sel)
    if m:
        return m.groups()
    if sel.startswith("#"):
        return (None, sel[1:], None)
    if sel.startswith("."):
        return (None, None, sel[1:])
    return (sel.lower(), None, None)


def matches(node, selector):
    if not selector or not node.tag:
        return False
    tag, sid, cls = selector
    if tag and node.tag != tag.lower():
        return False
    if sid and node.attrs.get("id") != sid:
        return False
    if cls and cls not in node.attrs.get("class", "").split():
        return False
    return True


def find_matches(node, selector):
    out = []
    if matches(node, selector):
        out.append(node)
    for c in node.children:
        out.extend(find_matches(c, selector))
    return out


class Renderer:
    def __init__(self, args):
        self.args = args
        self.list_stack = []

    def render(self, node):
        if self.args.include_selector:
            roots = find_matches(node, parse_selector(self.args.include_selector))
            return self.clean_blocks("\n\n".join(self.render_block(n) for n in roots))
        return self.clean_blocks(self.render_block(node))

    def excluded(self, node):
        return self.args.exclude_selector and matches(node, parse_selector(self.args.exclude_selector))

    def children_inline(self, node):
        return "".join(self.render_inline(c) for c in node.children)

    def children_blocks(self, node):
        parts = []
        for c in node.children:
            if self.excluded(c):
                continue
            b = self.render_block(c)
            if b != "":
                parts.append(b)
        return "\n\n".join(parts)

    def render_block(self, node):
        if node.text is not None:
            return normalize_ws(esc_text(node.text))
        if self.excluded(node) or node.tag in {"script", "style", "head", "title", "noscript"}:
            return ""
        t = node.tag
        if t == "root":
            return self.children_blocks(node)
        if t in {"p", "caption"}:
            return self.children_inline(node).strip()
        if t in {"h1", "h2", "h3", "h4", "h5", "h6"}:
            return "#" * int(t[1]) + " " + self.children_inline(node).strip()
        if t == "br":
            return "  \n"
        if t == "hr":
            return "* * *"
        if t in {"pre"}:
            txt = self.raw_text(node).strip("\n")
            return "```\n" + html.unescape(txt) + "\n```"
        if t == "blockquote":
            body = self.children_blocks(node)
            return "\n".join(("> " + line if line else ">") for line in body.splitlines())
        if t in {"ul", "ol"}:
            return self.render_list(node, ordered=(t == "ol"))
        if t == "li":
            return self.children_blocks(node)
        if t == "table":
            return self.render_table(node) if self.args.plugin_table else self.children_blocks(node)
        if t in {"tr", "thead", "tbody", "tfoot"}:
            return self.children_blocks(node)
        if t in {"td", "th"}:
            return self.children_inline(node).strip()
        if t in BLOCK_TAGS:
            return self.children_blocks(node)
        return self.children_inline(node).strip()

    def render_inline(self, node):
        if node.text is not None:
            return esc_text(node.text)
        if self.excluded(node) or node.tag in {"script", "style", "head", "title"}:
            return ""
        t = node.tag
        if t == "br":
            return "  \n"
        if t == "hr":
            return "\n\n* * *\n\n"
        if t in {"strong", "b"}:
            d = self.args.opt_strong_delimiter
            return d + self.children_inline(node).strip() + d
        if t in {"em", "i"}:
            return "*" + self.children_inline(node).strip() + "*"
        if t in {"del", "s", "strike"}:
            body = self.children_inline(node).strip()
            return "~~" + body + "~~" if self.args.plugin_strikethrough else body
        if t == "code":
            return "`" + html.unescape(self.raw_text(node)).strip() + "`"
        if t == "pre":
            return "\n\n" + self.render_block(node) + "\n\n"
        if t == "a":
            body = self.children_inline(node).strip() or self.url(node.attrs.get("href", ""))
            href = self.url(node.attrs.get("href", ""))
            if not href:
                return body
            title = node.attrs.get("title")
            return "[" + body + "](" + href + (f' "{esc_title(title)}"' if title else "") + ")"
        if t == "img":
            alt = esc_text(node.attrs.get("alt", ""))
            src = self.url(node.attrs.get("src", ""))
            title = node.attrs.get("title")
            return "![" + alt + "](" + src + (f' "{esc_title(title)}"' if title else "") + ")"
        if t in {"p", *BLOCK_TAGS, "ul", "ol", "li", "blockquote", "table", "tr", "td", "th"}:
            b = self.render_block(node)
            return b
        return self.children_inline(node)

    def raw_text(self, node):
        if node.text is not None:
            return node.text
        return "".join(self.raw_text(c) for c in node.children)

    def url(self, u):
        if not u:
            return ""
        u = html.unescape(u.strip())
        if self.args.domain:
            u = urljoin(self.args.domain, u)
        return quote(u, safe="/#:?&=@%+~,;!$'()*[]")

    def render_list(self, node, ordered=False):
        lines = []
        idx = 1
        for child in node.children:
            if child.tag != "li" or self.excluded(child):
                continue
            nested = [c for c in child.children if c.tag in {"ul", "ol"}]
            non = Node("li")
            non.children = [c for c in child.children if c not in nested]
            text = self.children_blocks(non).strip()
            marker = f"{idx}. " if ordered else "- "
            idx += 1
            item_lines = text.splitlines() if text else [""]
            lines.append(marker + item_lines[0])
            for line in item_lines[1:]:
                lines.append("  " + line)
            for n in nested:
                nb = self.render_list(n, n.tag == "ol")
                if nb:
                    lines.append("  ")
                    lines.extend("  " + l if l else "" for l in nb.splitlines())
        return "\n".join(lines)

    def render_table(self, node):
        rows = []
        def walk(n):
            if n.tag == "tr":
                cells = []
                for c in n.children:
                    if c.tag in {"td", "th"}:
                        cells.append((c.tag, self.children_inline(c).strip().replace("\n", " ")))
                if cells or not self.args.opt_table_skip_empty_rows:
                    rows.append(cells)
            for c in n.children:
                walk(c)
        walk(node)
        if not rows:
            return ""
        header = rows[0]
        body = rows[1:]
        widths = [0] * max((len(r) for r in rows), default=0)
        for r in rows:
            for i, (_, val) in enumerate(r):
                widths[i] = max(widths[i], len(val))
        def fmt(r):
            vals = [r[i][1] if i < len(r) else "" for i in range(len(widths))]
            if self.args.opt_table_cell_padding_behavior == "none":
                return "|" + "|".join(vals) + "|"
            return "| " + " | ".join(vals[i].ljust(widths[i]) for i in range(len(widths))) + " |"
        sep = "|" + "|".join("-" * (w + 2 if self.args.opt_table_cell_padding_behavior != "none" else max(3, w)) for w in widths) + "|"
        if self.args.opt_table_cell_padding_behavior != "none":
            sep = "|" + "|".join("-" * (w + 2) for w in widths) + "|"
        return "\n".join([fmt(header), sep] + [fmt(r) for r in body])

    def clean_blocks(self, s):
        lines = [re.sub(r"[ \t]+$", "", l) for l in s.splitlines()]
        s = "\n".join(lines)
        s = re.sub(r"\n{3,}", "\n\n", s)
        return s.strip()


def esc_title(s):
    return html.unescape(s).replace('"', '\\"')


def convert(data, args):
    p = TreeParser()
    p.feed(data)
    return Renderer(args).render(p.root)


def parse_args(argv):
    ap = argparse.ArgumentParser(add_help=False)
    ap.add_argument("-v", "--version", action="store_true")
    ap.add_argument("--help", action="store_true")
    ap.add_argument("--input")
    ap.add_argument("--output")
    ap.add_argument("--output-overwrite", action="store_true")
    ap.add_argument("--domain")
    ap.add_argument("--exclude-selector")
    ap.add_argument("--include-selector")
    ap.add_argument("--opt-strong-delimiter", default="**", choices=["**", "__"])
    ap.add_argument("--opt-table-cell-padding-behavior", default="aligned", choices=["aligned", "minimal", "none"])
    ap.add_argument("--opt-table-header-promotion", action="store_true")
    ap.add_argument("--opt-table-newline-behavior", default="skip")
    ap.add_argument("--opt-table-presentation-tables", action="store_true")
    ap.add_argument("--opt-table-skip-empty-rows", action="store_true")
    ap.add_argument("--opt-table-span-cell-behavior", default="empty")
    ap.add_argument("--plugin-strikethrough", action="store_true")
    ap.add_argument("--plugin-table", action="store_true")
    ap.add_argument("--preserve-tags")
    ap.add_argument("--wrap-links", action="store_true")
    ap.add_argument("positional", nargs="*")
    args, unknown = ap.parse_known_args(argv)
    if unknown:
        print(f"\nerror: unknown flag: {unknown[0]}", file=sys.stderr)
        sys.exit(1)
    return args


HELP = """
# html2markdown - convert html to markdown [version dev]

Convert HTML to Markdown. Even works with entire websites!

## Basics

By default the "Commonmark" Plugin will be enabled. You can customize the options,
for example changing the appearance of bold with --opt-strong-delimiter="__"

Other Plugins can also be enabled. For example "GitHub Flavored Markdown" (GFM)
extends Commonmark with more features.

## Relative / Absolute Links

Use --domain="https://example.com" to convert *relative* links to *absolute* links.
The same also works for images.

## Flags

    -v, --version
        show the version of html2markdown and exit

    --help

    --input PATH
        Input file, directory, or glob pattern (instead of stdin)

    --output PATH
        Output file or directory (instead of stdout)

    --output-overwrite
        Replace existing files

    --domain
        The url of the web page, used to convert relative links to absolute links.

    --exclude-selector
        css query selector to exclude parts of the input

    --include-selector
        css query selector to only include parts of the input

    --opt-strong-delimiter
        Make bold text. Should <strong> be indicated by two asterisks or two underscores?
        "**" or "__" (default: "**")

    --opt-table-cell-padding-behavior
        [for --plugin-table] whether cells in the tables should include extra padding for visual continuity: "aligned", "minimal", or "none"

    --opt-table-header-promotion
        [for --plugin-table] first row should be treated as a header

    --opt-table-newline-behavior
        [for --plugin-table] how tables containing newlines should be handled: "skip" or "preserve"

    --opt-table-presentation-tables
        [for --plugin-table] whether tables with role="presentation" should be converted

    --opt-table-skip-empty-rows
        [for --plugin-table] omit empty rows from the output

    --opt-table-span-cell-behavior
        [for --plugin-table] how colspan/rowspan should be rendered: "empty" or "mirror"

    --plugin-strikethrough
        enable the plugin ~~strikethrough~~

    --plugin-table
        enable the plugin table
"""


def inputs_for(path):
    if not path:
        return []
    if os.path.isdir(path):
        return sorted([os.path.join(path, f) for f in os.listdir(path) if os.path.isfile(os.path.join(path, f))])
    g = sorted(glob.glob(path))
    return g if g else [path]


def main(argv):
    args = parse_args(argv)
    if args.help:
        print(HELP)
        return 0
    if args.version:
        print("html2markdown\n\nGitVersion:  dev\nGitCommit:   none\nBuildDate:   unknown")
        return 0
    if not args.input and args.positional:
        args.input = args.positional[0]
    if args.input:
        paths = inputs_for(args.input)
        if len(paths) > 1:
            if not args.output or not os.path.isdir(args.output):
                print("\nerror: if --input is a directory or glob pattern, --output must be a directory", file=sys.stderr)
                return 1
            for p in paths:
                with open(p, "r", encoding="utf-8", errors="replace") as f:
                    out = convert(f.read(), args)
                name = os.path.splitext(os.path.basename(p))[0] + ".md"
                dest = os.path.join(args.output, name)
                write_output(dest, out, args)
        else:
            with open(paths[0], "r", encoding="utf-8", errors="replace") as f:
                out = convert(f.read(), args)
            if args.output:
                dest = args.output
                if os.path.isdir(dest):
                    dest = os.path.join(dest, os.path.splitext(os.path.basename(paths[0]))[0] + ".md")
                write_output(dest, out, args)
            else:
                sys.stdout.write(out)
    else:
        out = convert(sys.stdin.read(), args)
        if args.output:
            write_output(args.output, out, args)
        else:
            sys.stdout.write(out)
    return 0


def write_output(path, data, args):
    if os.path.exists(path) and not args.output_overwrite:
        print(f'\nerror: output path "{path}" already exists. Use --output-overwrite to replace existing files', file=sys.stderr)
        sys.exit(1)
    with open(path, "w", encoding="utf-8") as f:
        f.write(data)


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
