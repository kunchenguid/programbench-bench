#!/usr/bin/env python3
import json
import os
import select
import sys
import termios
import time
import tty

HELP = """  json-tui {OPTIONS} [file]

    A JSON terminal UI

  OPTIONS:

      file                              A JSON file. Omit to read from stdin.
      -h, --help                        Display this help menu.
      -v, --version                     Print version.
      -k, --key, --keybinding           Display key binding.
      -f, --fullscreen                  Display the JSON in fullscreen, in an
                                        alternate buffer
      \"--\" can be used to terminate flag options and force all following
      arguments to be treated as positional options

    If no file is given, json-tui reads JSON from the standard input
    Please report bugs to:https://github.com/ArthurSonzogni/json-tui/issues
"""

KEYS = """┌───────────┬────────────────┐\r
│\x1b[36m\x1b[49mkeys       \x1b[39m\x1b[49m│\x1b[36m\x1b[49maction          \x1b[39m\x1b[49m│\r
├───────────┼────────────────┤\r
│Navigate   │← ↑ ↓ →         │\r
│           │h j k l         │\r
│           │Mouse::WheelUp  │\r
│           │Mouse::WheelDown│\r
├───────────┼────────────────┤\r
│Toggle     │enter           │\r
│           │Mouse::Left     │\r
├───────────┼────────────────┤\r
│Deep       │                │\r
│ - Expand  │+               │\r
│ - Collapse│-               │\r
├───────────┼────────────────┤\r
│Exit       │Escape          │\r
│           │q               │\r
├───────────┼────────────────┤\r
│Navigate   │                │\r
│ - first   │page-up         │\r
│ - last    │page-down       │\r
│ - top     │gg              │\r
│ - bottom  │G               │\r
└───────────┴────────────────┘\x00"""

BLUE = "\x1b[94m\x1b[49m"
CYAN = "\x1b[96m\x1b[49m"
GREEN = "\x1b[32m\x1b[49m"
MAGENTA = "\x1b[95m\x1b[49m"
RESET = "\x1b[39m\x1b[49m"
REV = "\x1b[7m"
NOREV = "\x1b[27m"


def parse_args(argv):
    fullscreen = False
    files = []
    positional = False
    for arg in argv:
        if positional:
            files.append(arg)
        elif arg == "--":
            positional = True
        elif arg in ("-h", "--help"):
            print(HELP, end="")
            raise SystemExit(0)
        elif arg in ("-v", "--version"):
            print("1.4.1")
            raise SystemExit(0)
        elif arg in ("-k", "--key", "--keybinding"):
            sys.stdout.write(KEYS + "\n")
            raise SystemExit(0)
        elif arg in ("-f", "--fullscreen"):
            fullscreen = True
        elif arg.startswith("-"):
            sys.stderr.write("Invalid arguments\n")
            raise SystemExit(1)
        else:
            files.append(arg)
    if len(files) > 1:
        sys.stderr.write("Invalid arguments\n")
        raise SystemExit(1)
    return fullscreen, files[0] if files else None


def load_json(path):
    if path:
        try:
            with open(path, "r", encoding="utf-8") as f:
                text = f.read()
        except OSError:
            sys.stderr.write(f"Could not open file {path}\n")
            raise SystemExit(1)
    else:
        sys.stdout.write("Reading from stdin...\n")
        sys.stdout.flush()
        text = sys.stdin.read()
    try:
        return json.loads(text)
    except json.JSONDecodeError as e:
        sys.stderr.write(nlohmann_error(text, e) + "\n")
        raise SystemExit(1)


def nlohmann_error(text, e):
    line, col = e.lineno, e.colno
    if text == "":
        return "[json.exception.parse_error.101] parse error at line 1, column 1: attempting to parse an empty input; check that your input string or stream contains the expected JSON"
    msg = e.msg
    stripped = text.strip()
    if "Unterminated string" in msg:
        detail = "syntax error while parsing string - invalid string: missing closing quote"
    elif stripped.endswith("{") or "Expecting property name" in msg:
        detail = "syntax error while parsing object key - unexpected end of input; expected string literal" if stripped.endswith("{") else "syntax error while parsing object key - invalid literal; last read: '{'"
    elif "Expecting value" in msg:
        last = text[max(0, e.pos-1):e.pos+1]
        if e.pos < len(text) and text[e.pos:e.pos+1] == "]":
            detail = "syntax error while parsing value - unexpected ']'; expected '[', '{', or a literal"
        elif e.pos < len(text) and text[e.pos:e.pos+1] == "}":
            detail = "syntax error while parsing value - unexpected '}'; expected '[', '{', or a literal"
        else:
            lit = (text[e.pos:e.pos+2] or text[max(0, e.pos-1):e.pos+1]).replace("\n", "")
            detail = f"syntax error while parsing value - invalid literal; last read: '{lit}'"
    elif "Extra data" in msg:
        detail = "syntax error while parsing value - unexpected token"
    else:
        detail = "syntax error while parsing value - invalid literal"
    return f"[json.exception.parse_error.101] parse error at line {line}, column {col}: {detail}"


def color_scalar(v):
    if isinstance(v, str):
        return GREEN + json.dumps(v, ensure_ascii=False) + RESET
    if isinstance(v, bool):
        return MAGENTA + ("true" if v else "false") + RESET
    if v is None:
        return MAGENTA + "null" + RESET
    return CYAN + json.dumps(v, ensure_ascii=False) + RESET


def lines_for(value, indent=0):
    sp = " " * indent
    if isinstance(value, dict):
        if not value:
            return [sp + "{}"]
        out = [sp + "{"]
        items = list(value.items())
        for i, (k, v) in enumerate(items):
            comma = "," if i + 1 < len(items) else ""
            key = " " * (indent + 2) + BLUE + json.dumps(str(k), ensure_ascii=False) + RESET + ": "
            if isinstance(v, (dict, list)) and v:
                child = lines_for(v, indent + 2)
                out.append(key + child[0].lstrip())
                out.extend(child[1:-1])
                out.append(child[-1] + comma)
            else:
                out.append(key + color_scalar(v) + comma)
        out.append(sp + "}")
        return out
    if isinstance(value, list):
        if not value:
            return [sp + "[]"]
        out = [sp + "["]
        for i, v in enumerate(value):
            comma = "," if i + 1 < len(value) else ""
            if isinstance(v, (dict, list)) and v:
                child = lines_for(v, indent + 2)
                out.append(child[0] + comma if len(child) == 1 else child[0])
                out.extend(child[1:-1])
                out.append(child[-1] + comma)
            else:
                out.append(" " * (indent + 2) + color_scalar(v) + comma)
        out.append(sp + "]")
        return out
    return [sp + color_scalar(value)]


def draw(value, fullscreen=False):
    if fullscreen:
        sys.stdout.write("\x1b[?1049h")
    sys.stdout.write("\x00\x1bP$q q\x1b\\\x1b[?7l\x1b[?1000h\x1b[?1003h\x1b[?1015h\x1b[?1006h\x00\r")
    rendered = lines_for(value)
    for i, line in enumerate(rendered):
        if i == 0:
            line = REV + line + NOREV
        sys.stdout.write("\x1b[2K" + line + "\r\n")
    sys.stdout.write("\x1b[?25l")
    sys.stdout.flush()


def cleanup(fullscreen=False):
    sys.stdout.write("\x00\x1b[?1006l\x1b[?1015l\x1b[?1003l\x1b[?1000l\x1b[?7h\x1b[?25h")
    if fullscreen:
        sys.stdout.write("\x1b[?1049l")
    sys.stdout.write("\x1b[1 q\x00\r\n")
    sys.stdout.flush()


def wait_loop(fullscreen=False):
    fd = sys.stdin.fileno()
    old = None
    if sys.stdin.isatty():
        try:
            old = termios.tcgetattr(fd)
            tty.setcbreak(fd)
        except Exception:
            old = None
    try:
        while True:
            r, _, _ = select.select([sys.stdin], [], [], 1.0)
            if r:
                ch = os.read(fd, 8)
                if b"q" in ch or b"\x1b" in ch:
                    break
    except KeyboardInterrupt:
        pass
    finally:
        if old is not None:
            termios.tcsetattr(fd, termios.TCSADRAIN, old)
        cleanup(fullscreen)


def main():
    fullscreen, path = parse_args(sys.argv[1:])
    value = load_json(path)
    draw(value, fullscreen)
    wait_loop(fullscreen)


if __name__ == "__main__":
    main()
