#!/usr/bin/env python3
import argparse
import hashlib
import math
import os
import re
import struct
import sys
import zlib

VERSION_LINES = [
    "ffmpeg version git-2026-04-13-10ea080 Copyright (c) 2000-2026 the FFmpeg developers",
    "  built with gcc 11 (Ubuntu 11.4.0-1ubuntu1~22.04.3)",
    "  configuration: --disable-ffplay --disable-ffprobe",
    "  libavutil      60. 25.100 / 60. 25.100",
    "  libavcodec     62. 23.103 / 62. 23.103",
    "  libavformat    62.  9.101 / 62.  9.101",
    "  libavdevice    62.  2.100 / 62.  2.100",
    "  libavfilter    11. 12.100 / 11. 12.100",
    "  libswscale      9.  3.100 /  9.  3.100",
    "  libswresample   6.  2.100 /  6.  2.100",
]

FORMATS = [
    (" D  ", "3dostr", "3DO STR"), ("  E ", "3g2", "3GP2 (3GPP2 file format)"),
    ("  E ", "3gp", "3GP (3GPP file format)"), (" DE ", "ac3", "raw AC-3"),
    (" DE ", "aiff", "Audio IFF"), (" DE ", "alaw", "PCM A-law"),
    (" DE ", "apng", "Animated Portable Network Graphics"), (" DE ", "asf", "ASF (Advanced / Active Streaming Format)"),
    (" DE ", "ass", "SSA (SubStation Alpha) subtitle"), (" DE ", "au", "Sun AU"),
    (" DE ", "avi", "AVI (Audio Video Interleaved)"), (" DE ", "caf", "Apple CAF (Core Audio Format)"),
    (" DE ", "crc", "CRC testing"), (" DE ", "data", "raw data"),
    (" DE ", "ffmetadata", "FFmpeg metadata in text"), (" DE ", "flac", "raw FLAC"),
    (" DE ", "flv", "FLV (Flash Video)"), (" DE ", "framecrc", "framecrc testing"),
    (" DE ", "framehash", "Per-frame hash testing"), (" DE ", "framemd5", "Per-frame MD5 testing"),
    ("  E ", "gif", "CompuServe Graphics Interchange Format (GIF)"), ("  E ", "hash", "Hash testing"),
    (" DE ", "h264", "raw H.264 video"), (" DE ", "image2", "image2 sequence"),
    (" DE ", "image2pipe", "piped image2 sequence"), (" DE ", "matroska", "Matroska"),
    ("  E ", "md5", "MD5 testing"), (" DE ", "mov", "QuickTime / MOV"),
    (" DE ", "mp3", "MP3 (MPEG audio layer 3)"), (" DE ", "mp4", "MP4 (MPEG-4 Part 14)"),
    (" DE ", "mpeg", "MPEG-1 Systems / MPEG program stream"), (" DE ", "null", "raw null video"),
    (" DE ", "ogg", "Ogg"), (" DE ", "rawvideo", "raw video"),
    (" DE ", "s16le", "PCM signed 16-bit little-endian"), (" DE ", "wav", "WAV / WAVE (Waveform Audio)"),
    (" DE ", "webm", "WebM"), (" DE ", "yuv4mpegpipe", "YUV4MPEG pipe"),
]

ENCODERS = [
    ("V....D", "bmp", "BMP (Windows and OS/2 bitmap)"),
    ("V....D", "ffv1", "FFmpeg video codec #1"),
    ("V....D", "gif", "GIF (Graphics Interchange Format)"),
    ("V....D", "h261", "H.261"),
    ("V....D", "h263", "H.263 / H.263-1996"),
    ("VF...D", "mjpeg", "MJPEG (Motion JPEG)"),
    ("V.S..D", "mpeg1video", "MPEG-1 video"),
    ("V.S..D", "mpeg2video", "MPEG-2 video"),
    ("V.S..D", "mpeg4", "MPEG-4 part 2"),
    ("V....D", "pam", "PAM (Portable AnyMap) image"),
    ("V....D", "pbm", "PBM (Portable BitMap) image"),
    ("V....D", "pgm", "PGM (Portable GrayMap) image"),
    ("VF...D", "png", "PNG (Portable Network Graphics) image"),
    ("V....D", "ppm", "PPM (Portable PixelMap) image"),
    ("VF...D", "rawvideo", "raw video"),
    ("A....D", "aac", "AAC (Advanced Audio Coding)"),
    ("A....D", "ac3", "ATSC A/52A (AC-3)"),
    ("A....D", "flac", "FLAC (Free Lossless Audio Codec)"),
    ("A....D", "mp2", "MP2 (MPEG audio layer 2)"),
    ("A....D", "mp3", "MP3 (MPEG audio layer 3)"),
    ("A....D", "pcm_s16le", "PCM signed 16-bit little-endian"),
    ("A....D", "pcm_u8", "PCM unsigned 8-bit"),
    ("S.....", "ass", "ASS (Advanced SubStation Alpha) subtitle"),
    ("S.....", "srt", "SubRip subtitle"),
]

DECODERS = [
    ("VFS..D", "bmp", "BMP (Windows and OS/2 bitmap)"),
    ("V....D", "h264", "H.264 / AVC / MPEG-4 AVC / MPEG-4 part 10"),
    ("V....D", "mpeg4", "MPEG-4 part 2"),
    ("VF...D", "png", "PNG (Portable Network Graphics) image"),
    ("V....D", "ppm", "PPM (Portable PixelMap) image"),
    ("A....D", "aac", "AAC (Advanced Audio Coding)"),
    ("A....D", "flac", "FLAC (Free Lossless Audio Codec)"),
    ("A....D", "mp3", "MP3 (MPEG audio layer 3)"),
    ("A....D", "pcm_s16le", "PCM signed 16-bit little-endian"),
    ("S.....", "srt", "SubRip subtitle"),
]

def banner(to_stdout=False, hide=False):
    if hide:
        return
    out = sys.stdout if to_stdout else sys.stderr
    print("\n".join(VERSION_LINES), file=out)

def exit_line(code=0, stream=None):
    print(f"\nExiting with exit code {code}", file=stream or sys.stdout)

def basic_help():
    banner(to_stdout=True)
    print("""Universal media converter
usage: ffmpeg [options] [[infile options] -i infile]... {[outfile options] outfile}...

Getting help:
    -h      -- print basic options
    -h long -- print more options
    -h full -- print all options (including all format and codec specific options, very long)
    -h type=name -- print all options for the named decoder/encoder/demuxer/muxer/filter/bsf/protocol
    See man ffmpeg for detailed description of the options.

Per-stream options can be followed by :<stream_spec> to apply that option to specific streams only. <stream_spec> can be a stream index, or v/a/s for video/audio/subtitle (see manual for full syntax).

Print help / information / capabilities:
-L                  show license
-license            show license
-h <topic>          show help
-version            show version
-muxers             show available muxers
-demuxers           show available demuxers
-devices            show available devices
-decoders           show available decoders
-encoders           show available encoders
-filters            show available filters
-pix_fmts           show available pixel formats
-layouts            show standard channel layouts
-sample_fmts        show available audio sample formats

Global options (affect whole program instead of just one file):
-v <loglevel>       set logging level
-y                  overwrite output files
-n                  never overwrite output files
-stats              print progress report during encoding

Per-file options (input and output):
-f <fmt>            force container format (auto-detected otherwise)
-t <duration>       stop transcoding after specified duration
-to <time_stop>     stop transcoding after specified time is reached
-ss <time_off>      start transcoding after specified time

Per-stream options:
-c[:<stream_spec>] <codec>  select encoder/decoder ('copy' to copy stream without reencoding)
-filter[:<stream_spec>] <filter_graph>  apply specified filters to audio/video

Video options:
-r[:<stream_spec>] <rate>  override input framerate/convert to given output framerate
-vn                 disable video
-vcodec <codec>     alias for -c:v
-vf <filter_graph>  alias for -filter:v

Audio options:
-ar[:<stream_spec>] <rate>  set audio sampling rate
-ac[:<stream_spec>] <channels>  set number of audio channels
-an                 disable audio
-acodec <codec>     alias for -c:a
-af <filter_graph>  alias for -filter:a

Subtitle options:
-sn                 disable subtitle""")
    exit_line(0)

def version():
    lines = VERSION_LINES.copy()
    lines[1] = lines[1].lstrip()
    lines[2] = lines[2].lstrip()
    for i in range(3, len(lines)):
        lines[i] = lines[i].lstrip()
    print("\n".join(lines))
    exit_line(0)

def list_formats(kind=None):
    banner()
    print("Formats:", file=sys.stderr)
    print(" D.. = Demuxing supported\n .E. = Muxing supported\n ..d = Is a device\n ---", file=sys.stderr)
    for flags, name, desc in FORMATS:
        if kind == "muxers" and "E" not in flags: continue
        if kind == "demuxers" and "D" not in flags: continue
        f = flags if kind is None else ("  E " if kind == "muxers" else " D  ")
        print(f"{f} {name:<15} {desc}", file=sys.stderr)

def list_codecs(enc=False, dec=False):
    banner()
    title = "Encoders" if enc else "Decoders" if dec else "Codecs"
    print(f"{title}:", file=sys.stderr)
    if enc or dec:
        print(" V..... = Video\n A..... = Audio\n S..... = Subtitle\n .F.... = Frame-level multithreading\n ..S... = Slice-level multithreading\n ...X.. = Codec is experimental\n ....B. = Supports draw_horiz_band\n .....D = Supports direct rendering method 1\n ------", file=sys.stderr)
        rows = ENCODERS if enc else DECODERS
        for flags, name, desc in rows:
            print(f" {flags} {name:<20} {desc}", file=sys.stderr)
    else:
        print(" D..... = Decoding supported\n .E.... = Encoding supported\n ..V... = Video codec\n ..A... = Audio codec\n ..S... = Subtitle codec\n -------", file=sys.stderr)
        names = sorted({r[1] for r in ENCODERS + DECODERS})
        for name in names:
            typ = "A" if name.startswith(("pcm", "mp", "aac", "flac", "ac3")) else "S" if name in ("srt","ass") else "V"
            de = "D" if any(r[1] == name for r in DECODERS) else "."
            en = "E" if any(r[1] == name for r in ENCODERS) else "."
            print(f" {de}{en}{typ}..D {name:<20} {name}", file=sys.stderr)

def list_filters():
    banner()
    print("""Filters:
  T.. = Timeline support
  .S. = Slice threading
  A = Audio input/output
  V = Video input/output
  N = Dynamic number and/or type of input/output
  | = Source or sink filter
  ------
 .. anull             A->A       Pass the source unchanged to the output.
 .. aresample         A->A       Resample audio data.
 .. atrim             A->A       Pick one continuous section from the input, drop the rest.
 T. volume            A->A       Change input volume.
 .. aevalsrc          |->A       Generate an audio signal generated by an expression.
 .. anullsrc          |->A       Null audio source, return empty audio frames.
 .. sine              |->A       Generate sine wave audio signal.
 .. color             |->V       Provide an uniformly colored input.
 .. nullsrc           |->V       Null video source, return unprocessed video frames.
 .. testsrc           |->V       Generate test pattern.
 .. format            V->V       Convert the input video to one of the specified pixel formats.
 .. scale             V->V       Scale the input video size and/or convert the image format.
 .. null              V->V       Pass the source unchanged to the output.""", file=sys.stderr)

def simple_lists(opt):
    banner()
    if opt == "-protocols":
        print("Supported file protocols:\nInput:\n  async\n  cache\n  concat\n  data\n  fd\n  file\n  http\n  pipe\n  tcp\n  udp\nOutput:\n  fd\n  file\n  http\n  md5\n  pipe\n  tee\n  tcp\n  udp", file=sys.stderr)
    elif opt == "-sample_fmts":
        print("name   depth\nu8        8 \ns16      16 \ns32      32 \nflt      32 \ndbl      64 \nu8p       8 \ns16p     16 \ns32p     32 \nfltp     32 \ndblp     64 \ns64      64 \ns64p     64 ", file=sys.stderr)
    elif opt == "-pix_fmts":
        print("Pixel formats:\nI.... = Supported Input  format for conversion\n.O... = Supported Output format for conversion\n..H.. = Hardware accelerated format\n...P. = Paletted format\n....B = Bitstream format\nFLAGS NAME            NB_COMPONENTS BITS_PER_PIXEL BIT_DEPTHS\n-----\nIO... yuv420p                3             12      8-8-8\nIO... rgb24                  3             24      8-8-8\nIO... bgr24                  3             24      8-8-8\nIO... gray                   1              8      8\nIO... rgba                   4             32      8-8-8-8", file=sys.stderr)
    elif opt == "-layouts":
        print("Individual channels:\nNAME           DESCRIPTION\nFL             front left\nFR             front right\nFC             front center\nLFE            low frequency\nBL             back left\nBR             back right\n\nStandard channel layouts:\nNAME           DECOMPOSITION\nmono           FC\nstereo         FL+FR\n2.1            FL+FR+LFE\n3.0            FL+FR+FC\nquad           FL+FR+BL+BR\n5.1            FL+FR+FC+LFE+BL+BR\n7.1            FL+FR+FC+LFE+BL+BR+SL+SR", file=sys.stderr)
    elif opt == "-devices":
        list_formats(None)
    elif opt == "-bsfs":
        print("Bitstream filters:\naac_adtstoasc\nav1_frame_merge\nav1_frame_split\nh264_mp4toannexb\nhevc_mp4toannexb\nnull\nvp9_superframe", file=sys.stderr)
    elif opt == "-hwaccels":
        print("Hardware acceleration methods:\nvdpau\ncuda\nvaapi\nqsv\ndrm\nopencl\nvulkan", file=sys.stderr)
    elif opt == "-colors":
        print("name             #RRGGBB\nAliceBlue        #f0f8ff\nblack            #000000\nblue             #0000ff\ngreen            #008000\nred              #ff0000\nwhite            #ffffff\nyellow           #ffff00", file=sys.stderr)

def parse_duration(s, default=1.0):
    if s is None:
        return default
    try:
        parts = str(s).split(":")
        if len(parts) == 3:
            return int(parts[0]) * 3600 + int(parts[1]) * 60 + float(parts[2])
        if len(parts) == 2:
            return int(parts[0]) * 60 + float(parts[1])
        return float(s)
    except Exception:
        return default

def parse_filter(spec):
    name, rest = (spec.split("=", 1) + [""])[:2] if "=" in spec else (spec, "")
    opts = {}
    if rest:
        for part in rest.split(":"):
            if "=" in part:
                k, v = part.split("=", 1)
                opts[k] = v
            elif part:
                opts[part] = "1"
    return name, opts

def color_rgb(name):
    table = {"red": (253,0,0), "green": (0,127,0), "blue": (0,0,254), "black": (0,0,0),
             "white": (255,255,255), "yellow": (255,255,0), "cyan": (0,255,255),
             "magenta": (255,0,255)}
    if name in table:
        return table[name]
    m = re.match(r"0x([0-9a-fA-F]{6})", name)
    if m:
        n = int(m.group(1), 16)
        return ((n >> 16) & 255, (n >> 8) & 255, n & 255)
    return (0,0,0)

def write_wav(path, freq=1000.0, duration=1.0, rate=44100, channels=1, silent=False):
    n = max(0, int(duration * rate))
    data = bytearray()
    for i in range(n):
        val = 0 if silent else int(4095 * math.sin(2 * math.pi * freq * i / rate))
        for _ in range(channels):
            data += struct.pack("<h", val)
    byte_rate = rate * channels * 2
    block_align = channels * 2
    riff_size = 36 + len(data)
    with open(path, "wb") as f:
        f.write(b"RIFF" + struct.pack("<I", riff_size) + b"WAVE")
        f.write(b"fmt " + struct.pack("<IHHIIHH", 16, 1, channels, rate, byte_rate, block_align, 16))
        f.write(b"data" + struct.pack("<I", len(data)) + data)

def write_ppm(path, w=320, h=240, rgb=(0,0,0), test=False):
    with open(path, "wb") as f:
        f.write(f"P6\n{w} {h}\n255\n".encode())
        if not test:
            f.write(bytes(rgb) * (w*h))
            return
        bars = [(255,255,255),(255,255,0),(0,255,255),(0,255,0),(255,0,255),(255,0,0),(0,0,255),(0,0,0)]
        for y in range(h):
            for x in range(w):
                f.write(bytes(bars[min(7, x * 8 // max(1, w))]))

def image_rows(w, h, rgb=(0,0,0), test=False):
    bars = [(255,255,255),(255,255,0),(0,255,255),(0,255,0),(255,0,255),(255,0,0),(0,0,255),(0,0,0)]
    rows = []
    for y in range(h):
        row = bytearray()
        for x in range(w):
            row.extend(bars[min(7, x * 8 // max(1, w))] if test else rgb)
        rows.append(bytes(row))
    return rows

def png_chunk(kind, data):
    return struct.pack(">I", len(data)) + kind + data + struct.pack(">I", zlib.crc32(kind + data) & 0xffffffff)

def write_png(path, w=320, h=240, rgb=(0,0,0), test=False):
    raw = b"".join(b"\x00" + row for row in image_rows(w, h, rgb, test))
    with open(path, "wb") as f:
        f.write(b"\x89PNG\r\n\x1a\n")
        f.write(png_chunk(b"IHDR", struct.pack(">IIBBBBB", w, h, 8, 2, 0, 0, 0)))
        f.write(png_chunk(b"IDAT", zlib.compress(raw)))
        f.write(png_chunk(b"IEND", b""))

def write_bmp(path, w=320, h=240, rgb=(0,0,0), test=False):
    rows = image_rows(w, h, rgb, test)
    pad = (4 - (w * 3) % 4) % 4
    data = bytearray()
    for row in reversed(rows):
        for i in range(0, len(row), 3):
            r, g, b = row[i:i+3]
            data.extend([b, g, r])
        data.extend(b"\x00" * pad)
    size = 54 + len(data)
    with open(path, "wb") as f:
        f.write(b"BM" + struct.pack("<IHHI", size, 0, 0, 54))
        f.write(struct.pack("<IiiHHIIiiII", 40, w, h, 1, 24, 0, len(data), 2835, 2835, 0, 0))
        f.write(data)

def write_image(path, w, h, rgb, test=False):
    ext = os.path.splitext(path)[1].lower()
    if ext == ".png":
        write_png(path, w, h, rgb, test)
    elif ext == ".bmp":
        write_bmp(path, w, h, rgb, test)
    elif ext == ".pgm":
        with open(path, "wb") as f:
            f.write(f"P5\n{w} {h}\n255\n".encode())
            for row in image_rows(w, h, rgb, test):
                f.write(bytes(int((row[i] + row[i+1] + row[i+2]) / 3) for i in range(0, len(row), 3)))
    else:
        write_ppm(path, w, h, rgb, test)

def inspect_file(path):
    try:
        with open(path, "rb") as f:
            head = f.read(64)
            rest = f.read()
    except Exception as e:
        print(f"{path}: {e}", file=sys.stderr)
        return
    if head.startswith(b"RIFF") and head[8:12] == b"WAVE":
        ch = struct.unpack_from("<H", head, 22)[0]
        rate = struct.unpack_from("<I", head, 24)[0]
        bits = struct.unpack_from("<H", head, 34)[0]
        print(f"Input #0, wav, from '{path}':", file=sys.stderr)
        print(f"  Duration: N/A, bitrate: {rate*ch*bits//1000} kb/s", file=sys.stderr)
        print(f"  Stream #0:0: Audio: pcm_s{bits}le, {rate} Hz, {'mono' if ch==1 else 'stereo'}, s{bits}", file=sys.stderr)
    elif head.startswith(b"P6") or head.startswith(b"P5"):
        m = re.match(br"P[56]\s+(\d+)\s+(\d+)\s+255\s", head + rest[:64])
        wh = f"{int(m.group(1))}x{int(m.group(2))}" if m else "unknown"
        print(f"Input #0, image2, from '{path}':", file=sys.stderr)
        print(f"  Stream #0:0: Video: ppm, rgb24, {wh}, 25 fps", file=sys.stderr)
    elif head.startswith(b"\x89PNG"):
        w, h = struct.unpack(">II", head[16:24])
        print(f"Input #0, png_pipe, from '{path}':", file=sys.stderr)
        print(f"  Stream #0:0: Video: png, rgb24, {w}x{h}, 25 fps", file=sys.stderr)
    else:
        print(f"Input #0, data, from '{path}':", file=sys.stderr)
        print("  Stream #0:0: Data: none", file=sys.stderr)

def read_input_bytes(inp):
    if inp in (None, "-"):
        return sys.stdin.buffer.read()
    with open(inp, "rb") as f:
        return f.read()

def infer_format(path, explicit=None):
    if explicit:
        return explicit
    ext = os.path.splitext(path or "")[1].lower().lstrip(".")
    return {"wave": "wav", "ppm": "image2", "pgm": "image2", "pam": "image2"}.get(ext, ext)

def main(argv):
    if not argv:
        banner()
        print("Universal media converter\nusage: ffmpeg [options] [[infile options] -i infile]... {[outfile options] outfile}...\n\nUse -h to get full help or, even better, run 'man ffmpeg'", file=sys.stderr)
        return 0
    if argv[0] in ("--help", "-h", "-help") or "-h" in argv:
        basic_help(); return 0
    if "-version" in argv:
        version(); return 0
    if "-L" in argv or "-license" in argv:
        banner(to_stdout=True)
        print("This version of ffmpeg is licensed under the LGPL version 2.1 or later.")
        exit_line(0); return 0
    for opt in ("-formats","-muxers","-demuxers"):
        if opt in argv:
            list_formats(None if opt == "-formats" else opt[1:]); return 0
    if "-encoders" in argv:
        list_codecs(enc=True); return 0
    if "-decoders" in argv:
        list_codecs(dec=True); return 0
    if "-codecs" in argv:
        list_codecs(); return 0
    if "-filters" in argv:
        list_filters(); return 0
    if "-buildconf" in argv:
        banner(to_stdout=True)
        print("\n  configuration:\n    --disable-ffplay\n    --disable-ffprobe")
        exit_line(0); return 0
    for opt in ("-protocols","-sample_fmts","-pix_fmts","-layouts","-devices","-bsfs","-hwaccels","-colors"):
        if opt in argv:
            simple_lists(opt); return 0

    hide = "-hide_banner" in argv
    overwrite = "-y" in argv
    never = "-n" in argv
    in_fmt = None
    out_fmt = None
    inp = None
    out = None
    duration = None
    frames = None
    ar = 44100
    ac = 1
    codec_copy = False
    i = 0
    while i < len(argv):
        a = argv[i]
        if a == "-hide_banner" or a in ("-y","-n","-stats","-nostdin","-nostats","-benchmark","-bitexact"):
            i += 1
        elif a in ("-loglevel","-v","-ss","-to","-r","-vf","-af","-filter","-filter:v","-filter:a","-metadata","-map"):
            i += 2
        elif a == "-f" and i+1 < len(argv):
            val = argv[i+1]
            if inp is None:
                in_fmt = val
            else:
                out_fmt = val
            i += 2
        elif a == "-i" and i+1 < len(argv):
            inp = argv[i+1]; i += 2
        elif a in ("-t","-frames:v","-vframes") and i+1 < len(argv):
            if a == "-t": duration = parse_duration(argv[i+1])
            else: frames = int(float(argv[i+1]))
            i += 2
        elif a.startswith("-c") or a in ("-codec","-vcodec","-acodec"):
            if i+1 < len(argv) and argv[i+1] == "copy":
                codec_copy = True
            i += 2
        elif a.startswith("-ar") and i+1 < len(argv):
            ar = int(float(argv[i+1])); i += 2
        elif a.startswith("-ac") and i+1 < len(argv):
            ac = int(float(argv[i+1])); i += 2
        elif a.startswith("-"):
            print(f"Unrecognized option '{a.lstrip('-')}'.", file=sys.stderr)
            print("Error splitting the argument list: Option not found", file=sys.stderr)
            return 8
        else:
            out = a; i += 1
    if not out:
        banner(hide=hide)
        if inp:
            inspect_file(inp)
        print("At least one output file must be specified", file=sys.stderr)
        return 1
    if os.path.exists(out) and not overwrite:
        if never:
            print(f"File '{out}' already exists. Exiting.", file=sys.stderr)
            return 1
        print(f"File '{out}' already exists. Overwrite? [y/N] ", end="", file=sys.stderr)
        ans = sys.stdin.readline().strip().lower()
        if ans not in ("y","yes"):
            print("Not overwriting - exiting", file=sys.stderr)
            return 1
    fmt = infer_format(out, out_fmt)
    if in_fmt == "lavfi" and inp:
        name, opts = parse_filter(inp)
        dur = duration or parse_duration(opts.get("duration") or opts.get("d"), 1.0)
        if name in ("sine","anullsrc"):
            freq = float(opts.get("frequency") or opts.get("f") or 1000)
            if fmt in ("wav","wave") or out.lower().endswith(".wav"):
                banner(hide=hide)
                print(f"Input #0, lavfi, from '{inp}':\n  Duration: N/A, start: 0.000000, bitrate: {ar*ac*16//1000} kb/s\n  Stream #0:0: Audio: pcm_s16le, {ar} Hz, {'mono' if ac==1 else 'stereo'}, s16", file=sys.stderr)
                write_wav(out, freq=freq, duration=dur, rate=ar, channels=ac, silent=(name=="anullsrc"))
                print(f"Output #0, wav, to '{out}':\n  Stream #0:0: Audio: pcm_s16le, {ar} Hz, {'mono' if ac==1 else 'stereo'}, s16\nsize=      {max(1, os.path.getsize(out)//1024):2d}KiB time=00:00:{dur:05.2f} bitrate= {ar*ac*16/1000:.1f}kbits/s", file=sys.stderr)
                return 0
            raw = bytearray()
            n = int(dur * ar)
            for j in range(n):
                val = 0 if name=="anullsrc" else int(4095 * math.sin(2*math.pi*freq*j/ar))
                raw += struct.pack("<h", val)
            open(out, "wb").write(raw)
            return 0
        if name in ("color","testsrc","nullsrc"):
            size = opts.get("s") or opts.get("size") or "320x240"
            m = re.match(r"(\d+)x(\d+)", size)
            w,h = (int(m.group(1)), int(m.group(2))) if m else (320,240)
            rgb = color_rgb(opts.get("c") or opts.get("color") or "black")
            banner(hide=hide)
            print(f"Input #0, lavfi, from '{inp}':\n  Stream #0:0: Video: wrapped_avframe, yuv420p, {w}x{h}, 25 fps", file=sys.stderr)
            write_image(out, w, h, rgb, test=(name=="testsrc"))
            enc = "png" if out.lower().endswith(".png") else "bmp" if out.lower().endswith(".bmp") else "ppm"
            print(f"Output #0, image2, to '{out}':\n  Stream #0:0: Video: {enc}, rgb24, {w}x{h}, 25 fps\nframe=    1 fps=0.0 q=-0.0 Lsize=N/A", file=sys.stderr)
            return 0
    try:
        data = read_input_bytes(inp)
        if fmt == "md5" or out.startswith("md5:"):
            line = "MD5=" + hashlib.md5(data).hexdigest() + "\n"
            (sys.stdout if out in ("-","md5:-") else open(out.replace("md5:",""), "w")).write(line)
        elif fmt == "hash":
            open(out, "w").write("SHA256=" + hashlib.sha256(data).hexdigest() + "\n")
        elif fmt == "crc":
            open(out, "w").write("CRC=0x%08x\n" % (zlib.crc32(data) & 0xffffffff))
        elif codec_copy or inp:
            with open(out, "wb") as f:
                f.write(data)
        else:
            open(out, "wb").close()
        return 0
    except Exception as e:
        banner(hide=hide)
        print(str(e), file=sys.stderr)
        return 1

if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
