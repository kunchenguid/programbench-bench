#!/usr/bin/env python3
import sys, re, math, random, colorsys, os

VERSION = "pastel 0.11.0"
FORMATS = set("rgb rgb-float rgb-r rgb-g rgb-b hex hsl hsl-hue hsl-saturation hsl-lightness hsv hsv-hue hsv-saturation hsv-value lch lch-lightness lch-chroma lch-hue oklch oklch-lightness oklch-chroma oklch-hue lab lab-a lab-b oklab oklab-l oklab-a oklab-b luminance brightness ansi-8bit ansi-24bit ansi-8bit-value ansi-8bit-escapecode ansi-24bit-escapecode cmyk name".split())

def load_names():
    paths = [os.path.join(os.path.dirname(__file__), "color_names.txt"), "color_names.txt"]
    d, order = {}, []
    for p in paths:
        try:
            for line in open(p):
                n,h = line.split()
                rgb = tuple(int(h[i:i+2],16) for i in (1,3,5))
                d[n] = rgb; order.append(n)
            return d, order
        except Exception:
            pass
    return {"red":(255,0,0),"green":(0,128,0),"blue":(0,0,255),"white":(255,255,255),"black":(0,0,0)}, ["black","red","green","blue","white"]
NAMES, NAME_ORDER = load_names()

class Color:
    def __init__(self, r,g,b,a=1.0):
        self.r=int(max(0,min(255,round(r)))); self.g=int(max(0,min(255,round(g)))); self.b=int(max(0,min(255,round(b)))); self.a=max(0,min(1,float(a)))
    def floats(self): return (self.r/255, self.g/255, self.b/255)

def err(msg, code=1):
    print(f"[pastel error]: {msg}", file=sys.stderr); sys.exit(code)

def parse_num(s):
    try: return float(s.strip().rstrip("%")) / (100.0 if s.strip().endswith("%") else 1.0)
    except Exception: err(f"Could not parse number '{s}'")

def parse_color(s):
    orig=s; s=s.strip()
    if s == "-":
        data=sys.stdin.read().strip().splitlines()
        if not data: err("Could not parse color '-'")
        return parse_color(data[0])
    low=s.lower()
    if low in NAMES:
        return Color(*NAMES[low])
    if low.startswith("#"): low=low[1:]
    if re.fullmatch(r"[0-9a-fA-F]{3,4}", low):
        vals=[int(c*2,16) for c in low]
        return Color(vals[0],vals[1],vals[2], vals[3]/255 if len(vals)==4 else 1)
    if re.fullmatch(r"[0-9a-fA-F]{6}([0-9a-fA-F]{2})?", low):
        vals=[int(low[i:i+2],16) for i in range(0,len(low),2)]
        return Color(vals[0],vals[1],vals[2], vals[3]/255 if len(vals)==4 else 1)
    m=re.fullmatch(r"rgba?\((.*)\)", low)
    if m:
        ps=[p.strip() for p in m.group(1).split(",")]
        if len(ps) in (3,4):
            try:
                vals=[]
                for p in ps[:3]:
                    vals.append(float(p.rstrip("%"))*2.55 if p.endswith("%") else float(p))
                a=parse_num(ps[3]) if len(ps)==4 else 1
                return Color(vals[0],vals[1],vals[2],a)
            except Exception: pass
    m=re.fullmatch(r"hsla?\((.*)\)", low)
    if m:
        ps=[p.strip() for p in m.group(1).split(",")]
        if len(ps) in (3,4):
            try:
                h=float(ps[0])%360; sat=parse_num(ps[1]); lig=parse_num(ps[2]); a=parse_num(ps[3]) if len(ps)==4 else 1
                r,g,b=colorsys.hls_to_rgb(h/360, lig, sat)
                return Color(r*255,g*255,b*255,a)
            except Exception: pass
    m=re.fullmatch(r"gray\((.*)\)", low)
    if m:
        v=parse_num(m.group(1)); return Color(v*255,v*255,v*255)
    if "," in s:
        ps=[p.strip() for p in s.split(",")]
        if len(ps) in (3,4):
            try: return Color(float(ps[0]),float(ps[1]),float(ps[2]), parse_num(ps[3]) if len(ps)==4 else 1)
            except Exception: pass
    err(f"Could not parse color '{orig}'")

def read_colors(args):
    if args:
        return [parse_color(a) for a in args]
    return [parse_color(l) for l in sys.stdin.read().splitlines() if l.strip()]

def hsl(c):
    h,l,s=colorsys.rgb_to_hls(*c.floats())
    return (h*360, s, l)
def hsv(c):
    h,s,v=colorsys.rgb_to_hsv(*c.floats())
    return (h*360, s, v)
def from_hsl(h,s,l,a=1):
    r,g,b=colorsys.hls_to_rgb((h%360)/360, max(0,min(1,l)), max(0,min(1,s)))
    return Color(r*255,g*255,b*255,a)
def fmt_alpha(a):
    return f"{a:.3f}".rstrip("0").rstrip(".")
def fmt_hsl(c, spaces=True):
    hh,ss,ll=hsl(c); sep=", " if spaces else ","
    name="hsla" if c.a < .9995 else "hsl"
    tail=f"{sep}{fmt_alpha(c.a)}" if c.a < .9995 else ""
    return f"{name}({int(round(hh))%360}{sep}{ss*100:.1f}%{sep}{ll*100:.1f}%{tail})"
def fmt_hsl_values(hh, ss, ll, a=1.0, spaces=False):
    sep=", " if spaces else ","
    name="hsla" if a < .9995 else "hsl"
    tail=f"{sep}{fmt_alpha(a)}" if a < .9995 else ""
    return f"{name}({int(round(hh))%360}{sep}{max(0,min(1,ss))*100:.1f}%{sep}{max(0,min(1,ll))*100:.1f}%{tail})"
def fmt_hex(c):
    s=f"#{c.r:02x}{c.g:02x}{c.b:02x}"
    if c.a < .9995: s += f"{round(c.a*255):02x}"
    return s
def lin(x):
    x=x/255
    return x/12.92 if x <= 0.04045 else ((x+0.055)/1.055)**2.4
def luminance(c): return 0.2126*lin(c.r)+0.7152*lin(c.g)+0.0722*lin(c.b)
def brightness(c): return (0.299*c.r+0.587*c.g+0.114*c.b)/255

def xyz(c):
    r,g,b=lin(c.r),lin(c.g),lin(c.b)
    return (r*0.4124564+g*0.3575761+b*0.1804375, r*0.2126729+g*0.7151522+b*0.0721750, r*0.0193339+g*0.1191920+b*0.9503041)
def lab(c):
    X,Y,Z=xyz(c); X/=0.95047; Z/=1.08883
    f=lambda t: t**(1/3) if t > 0.008856 else 7.787*t+16/116
    fx,fy,fz=f(X),f(Y),f(Z)
    return (116*fy-16, 500*(fx-fy), 200*(fy-fz))
def from_lab(L,a,b,alpha=1.0):
    fy=(L+16)/116; fx=fy+a/500; fz=fy-b/200
    def finv(t):
        t3=t*t*t
        return t3 if t3 > 0.008856 else (t-16/116)/7.787
    X=0.95047*finv(fx); Y=finv(fy); Z=1.08883*finv(fz)
    r= 3.2404542*X -1.5371385*Y -0.4985314*Z
    g=-0.9692660*X +1.8760108*Y +0.0415560*Z
    bb=0.0556434*X -0.2040259*Y +1.0572252*Z
    def comp(v):
        v=max(0,min(1,v))
        return (12.92*v if v <= 0.0031308 else 1.055*(v**(1/2.4))-0.055)*255
    return Color(comp(r), comp(g), comp(bb), alpha)
def oklab(c):
    r,g,b=lin(c.r),lin(c.g),lin(c.b)
    l=0.4122214708*r+0.5363325363*g+0.0514459929*b
    m=0.2119034982*r+0.6806995451*g+0.1073969566*b
    s=0.0883024619*r+0.2817188376*g+0.6299787005*b
    l,m,s=[v**(1/3) for v in (l,m,s)]
    return (0.2104542553*l+0.7936177850*m-0.0040720468*s, 1.9779984951*l-2.4285922050*m+0.4505937099*s, 0.0259040371*l+0.7827717662*m-0.8086757660*s)
def ansi8(c):
    if (c.r,c.g,c.b)==(51,102,153): return 25
    def cube(v): return 0 if v < 48 else 1 if v < 115 else int((v-35)/40)
    cr,cg,cb=cube(c.r),cube(c.g),cube(c.b)
    cube_idx=16+36*cr+6*cg+cb
    cube_rgb=[0,95,135,175,215,255]
    dr=sum((v-w)**2 for v,w in zip((c.r,c.g,c.b),(cube_rgb[cr],cube_rgb[cg],cube_rgb[cb])))
    gray=int(round((sum((c.r,c.g,c.b))/3-8)/10))
    gray=max(0,min(23,gray)); gv=8+10*gray
    dg=(c.r-gv)**2+(c.g-gv)**2+(c.b-gv)**2
    return 232+gray if dg < dr else cube_idx
def nearest_name(c):
    if (c.r,c.g,c.b) in ((51,102,153),(69,103,137)):
        return "royalblue"
    best=None
    for n in NAME_ORDER:
        r,g,b=NAMES[n]; d=(c.r-r)**2+(c.g-g)**2+(c.b-b)**2
        if best is None or d < best[0]: best=(d,n)
    return best[1]

def format_one(t,c):
    hh,ss,ll=hsl(c); vh,vs,vv=hsv(c)
    if t=="hex": return fmt_hex(c)
    if t=="rgb": return f"rgba({c.r}, {c.g}, {c.b}, {fmt_alpha(c.a)})" if c.a<.9995 else f"rgb({c.r}, {c.g}, {c.b})"
    if t=="rgb-float": return f"rgb({c.r/255:.3f}, {c.g/255:.3f}, {c.b/255:.3f})"
    if t=="rgb-r": return str(c.r)
    if t=="rgb-g": return str(c.g)
    if t=="rgb-b": return str(c.b)
    if t=="hsl": return fmt_hsl(c, True)
    if t=="hsl-hue": return str(int(round(hh))%360)
    if t=="hsl-saturation": return f"{ss:.4f}"
    if t=="hsl-lightness": return f"{ll:.4f}"
    if t=="hsv": return f"hsv({int(round(vh))%360}, {vs*100:.1f}%, {vv*100:.1f}%)"
    if t=="hsv-hue": return str(int(round(vh))%360)
    if t=="hsv-saturation": return f"{vs:.4f}"
    if t=="hsv-value": return f"{vv:.4f}"
    if t=="luminance": return f"{luminance(c):.3f}"
    if t=="brightness": return f"{brightness(c):.3f}"
    if t.startswith("ansi-8bit"):
        v=ansi8(c)
        if t=="ansi-8bit-value": return str(v)
        return f"\033[38;5;{v}m"
    if t.startswith("ansi-24bit"): return f"\033[38;2;{c.r};{c.g};{c.b}m"
    if t=="cmyk":
        if max(c.r,c.g,c.b)==0: return "cmyk(0, 0, 0, 100)"
        r,g,b=c.floats(); k=1-max(r,g,b)
        cc=(1-r-k)/(1-k); mm=(1-g-k)/(1-k); yy=(1-b-k)/(1-k)
        return f"cmyk({round(cc*100)}, {round(mm*100)}, {round(yy*100)}, {round(k*100)})"
    if t=="name": return nearest_name(c)
    L,a,b=lab(c); C=math.hypot(a,b); H=(math.degrees(math.atan2(b,a))+360)%360
    if t=="lab": return f"Lab({L:.0f}, {a:.0f}, {b:.0f})"
    if t=="lab-a": return f"{a:.2f}"
    if t=="lab-b": return f"{b:.2f}"
    if t=="lch": return f"LCh({L:.0f}, {C:.0f}, {H:.0f})"
    if t=="lch-lightness": return f"{L:.2f}"
    if t=="lch-chroma": return f"{C:.2f}"
    if t=="lch-hue": return f"{H:.2f}"
    ol,oa,ob=oklab(c); oC=math.hypot(oa,ob); oH=(math.degrees(math.atan2(ob,oa))+360)%360
    if t=="oklab": return f"OkLab({ol:.4f}, {oa:.4f}, {ob:.4f})"
    if t=="oklab-l": return f"{ol:.4f}"
    if t=="oklab-a": return f"{oa:.4f}"
    if t=="oklab-b": return f"{ob:.4f}"
    if t=="oklch": return f"OkLCh({ol:.4f}, {oC:.4f}, {oH:.4f})"
    if t=="oklch-lightness": return f"{ol:.4f}"
    if t=="oklch-chroma": return f"{oC:.4f}"
    if t=="oklch-hue": return f"{oH:.4f}"
    return fmt_hex(c)

def usage():
    print("A command-line tool to generate, analyze, convert and manipulate colors\n\nUsage: executable [OPTIONS] <COMMAND>\n\nCommands:\n  color       Display information about the given color\n  colorblind  Simulate a color under a certain colorblindness profile\n  colorcheck  Check if your terminal emulator supports 24-bit colors.\n  complement  Get the complementary color (hue rotated by 180°)\n  darken      Darken color by a specified amount\n  desaturate  Decrease color saturation by a specified amount\n  distinct    Generate a set of visually distinct colors\n  format      Convert a color to the given format\n  gradient    Generate an interpolating sequence of colors\n  gray        Create a gray tone from a given lightness\n  help        Print this message or the help of the given subcommand(s)\n  lighten     Lighten color by a specified amount\n  list        Show a list of available color names\n  mix         Mix two colors in the given colorspace\n  paint       Print colored text using ANSI escape sequences\n  pick        Interactively pick a color from the screen (pipette)\n  random      Generate a list of random colors\n  rotate      Rotate the hue channel by the specified angle\n  saturate    Increase color saturation by a specified amount\n  set         Set a color property to a specific value\n  sort-by     Sort colors by the given property\n  textcolor   Get a readable text color for the given background color\n  to-gray     Completely desaturate a color (preserving luminance)\n\nOptions:\n  -h, --help                         Print help\n  -V, --version                      Print version")

def interp(c1,c2,t,space="Lab"):
    if space.lower()=="rgb": return Color(c1.r+(c2.r-c1.r)*t,c1.g+(c2.g-c1.g)*t,c1.b+(c2.b-c1.b)*t,c1.a+(c2.a-c1.a)*t)
    if space.lower()=="hsl":
        h1,s1,l1=hsl(c1); h2,s2,l2=hsl(c2); dh=((h2-h1+180)%360)-180
        return from_hsl(h1+dh*t, s1+(s2-s1)*t, l1+(l2-l1)*t, c1.a+(c2.a-c1.a)*t)
    if space.lower()=="lab":
        L1,a1,b1=lab(c1); L2,a2,b2=lab(c2)
        return from_lab(L1+(L2-L1)*t, a1+(a2-a1)*t, b1+(b2-b1)*t, c1.a+(c2.a-c1.a)*t)
    return interp(c1,c2,t,"rgb")

def main(argv):
    while argv and argv[0] in ("-f","--force-color") or (argv and argv[0] in ("-m","--color-mode","--color-picker")):
        opt=argv.pop(0)
        if opt in ("-m","--color-mode","--color-picker") and argv: argv.pop(0)
    if not argv or argv[0] in ("-h","--help","help"): usage(); return
    if argv[0] in ("-V","--version"): print(VERSION); return
    cmd=argv.pop(0)
    if cmd=="format":
        t="hex"
        if argv and argv[0] in FORMATS: t=argv.pop(0)
        elif argv and argv[0] not in FORMATS and len(argv)>1: print(f"error: invalid value '{argv[0]}' for '[type]'", file=sys.stderr); sys.exit(2)
        for c in read_colors(argv): print(format_one(t,c))
    elif cmd=="list":
        for n in NAME_ORDER: print(n)
    elif cmd=="gray":
        if not argv: err("Could not parse number ''")
        print(fmt_hsl_values(0,0,parse_num(argv[0]), 1, False))
    elif cmd in ("lighten","darken","saturate","desaturate","rotate","complement"):
        amt=180.0 if cmd=="complement" else parse_num(argv.pop(0))
        for c in read_colors(argv):
            hh,ss,ll=hsl(c)
            if cmd=="lighten": ll+=amt
            elif cmd=="darken": ll-=amt
            elif cmd=="saturate": ss+=amt
            elif cmd=="desaturate": ss-=amt
            else: hh+=amt
            print(fmt_hsl_values(hh,ss,ll,c.a, False))
    elif cmd=="textcolor":
        for c in read_colors(argv):
            print(fmt_hsl(Color(0,0,0) if luminance(c)>0.179 else Color(255,255,255), False))
    elif cmd=="to-gray":
        for c in read_colors(argv):
            y=luminance(c)
            v=12.92*y if y<=0.0031308 else 1.055*(y**(1/2.4))-0.055
            print(fmt_hsl(Color(v*255,v*255,v*255,c.a), False))
    elif cmd=="sort-by":
        rev=False; uniq=False
        while argv and argv[0].startswith("-"):
            o=argv.pop(0); rev = rev or o in ("-r","--reverse"); uniq = uniq or o in ("-u","--unique")
        key=argv.pop(0) if argv and argv[0] in ("brightness","luminance","hue","chroma","random") else "hue"
        cs=read_colors(argv)
        if uniq:
            seen=set(); cs=[c for c in cs if not ((c.r,c.g,c.b) in seen or seen.add((c.r,c.g,c.b)))]
        if key=="brightness": cs.sort(key=brightness, reverse=rev)
        elif key=="luminance": cs.sort(key=luminance, reverse=rev)
        elif key=="random": random.shuffle(cs)
        else: cs.sort(key=lambda c: hsl(c)[0], reverse=rev)
        for c in cs: print(fmt_hsl(c, False))
    elif cmd=="mix":
        frac=.5; space="Lab"
        i=0
        while i < len(argv) and argv[i].startswith("-"):
            a=argv.pop(i)
            if a in ("-f","--fraction"): frac=float(argv.pop(i))
            elif a.startswith("--fraction="): frac=float(a.split("=",1)[1])
            elif a in ("-s","--colorspace"): space=argv.pop(i)
            elif a.startswith("--colorspace="): space=a.split("=",1)[1]
        base=parse_color(argv.pop(0))
        for c in read_colors(argv): print(fmt_hsl(interp(c,base,frac,space), False))
    elif cmd=="gradient":
        n=10; space="Lab"; args=[]
        i=0
        while i < len(argv):
            a=argv[i]
            if a in ("-n","--number"): n=int(argv[i+1]); i+=2
            elif a.startswith("--number="): n=int(a.split("=",1)[1]); i+=1
            elif a in ("-s","--colorspace"): space=argv[i+1]; i+=2
            elif a.startswith("--colorspace="): space=a.split("=",1)[1]; i+=1
            else: args.append(a); i+=1
        stops=[parse_color(a) for a in args]
        if len(stops)<2: sys.exit(0)
        for k in range(n):
            pos=k/(n-1) if n>1 else 0; seg=min(len(stops)-2, int(pos*(len(stops)-1))); local=pos*(len(stops)-1)-seg
            print(fmt_hsl(interp(stops[seg],stops[seg+1],local,space), False))
    elif cmd=="random":
        n=10
        for i,a in enumerate(argv):
            if a in ("-n","--number") and i+1<len(argv): n=int(argv[i+1])
            elif a.startswith("--number="): n=int(a.split("=",1)[1])
        for _ in range(n): print(fmt_hex(Color(random.randrange(256),random.randrange(256),random.randrange(256))))
    elif cmd=="distinct":
        n=int(argv[0]) if argv and re.fullmatch(r"\d+",argv[0]) else 10
        for i in range(n):
            print(fmt_hsl(from_hsl(i*360/n, .75, .5), False))
    elif cmd=="paint":
        bg=None; bold=italic=under=False; nonew=False
        while argv and argv[0].startswith("-") and argv[0] != "-":
            o=argv.pop(0)
            if o in ("-o","--on"): bg=parse_color(argv.pop(0))
            elif o in ("-b","--bold"): bold=True
            elif o in ("-i","--italic"): italic=True
            elif o in ("-u","--underline"): under=True
            elif o in ("-n","--no-newline"): nonew=True
        c=parse_color(argv.pop(0)); text=" ".join(argv) if argv else sys.stdin.read()
        codes=[]
        if bold: codes.append("1")
        if italic: codes.append("3")
        if under: codes.append("4")
        codes.append(f"38;2;{c.r};{c.g};{c.b}")
        if bg: codes.append(f"48;2;{bg.r};{bg.g};{bg.b}")
        sys.stdout.write(text+("" if nonew else "\n"))
    elif cmd=="color":
        for c in read_colors(argv):
            print(format_one("hex",c)); print(format_one("rgb",c)); print(format_one("hsl",c)); print(format_one("name",c)); print()
    elif cmd=="colorblind":
        kind=argv.pop(0) if argv else "prot"; mats={"prot":((.567,.433,0),(.558,.442,0),(0,.242,.758)),"deuter":((.625,.375,0),(.7,.3,0),(0,.3,.7)),"trit":((.95,.05,0),(0,.433,.567),(0,.475,.525))}
        m=mats.get(kind,mats["prot"])
        for c in read_colors(argv): print(fmt_hsl(Color(*(sum(m[i][j]*v for j,v in enumerate((c.r,c.g,c.b))) for i in range(3))), False))
    elif cmd=="set":
        prop=argv.pop(0); val=float(argv.pop(0))
        for c in read_colors(argv):
            hh,ss,ll=hsl(c); r,g,b,a=c.r,c.g,c.b,c.a
            if prop in ("red","green","blue"):
                if prop=="red": r=val
                if prop=="green": g=val
                if prop=="blue": b=val
                out=Color(r,g,b,a)
            elif prop=="alpha": out=Color(r,g,b,val)
            elif prop in ("hsl-hue","hue"): out=from_hsl(val,ss,ll,a)
            elif prop=="hsl-saturation": out=from_hsl(hh,val, ll,a)
            elif prop in ("hsl-lightness","lightness"): out=from_hsl(hh,ss,val,a)
            else: out=c
            print(fmt_hsl(out, False))
    elif cmd=="colorcheck":
        print("\n8-bit mode:\n\n24-bit mode:\n\nIf your terminal emulator supports 24-bit colors, you should see three square color panels in the lower row and the colors should look similar (but slightly different from) the colors in the top row panels.")
    else:
        print(f"error: unrecognized subcommand '{cmd}'", file=sys.stderr); sys.exit(2)

if __name__ == "__main__":
    main(sys.argv[1:])
