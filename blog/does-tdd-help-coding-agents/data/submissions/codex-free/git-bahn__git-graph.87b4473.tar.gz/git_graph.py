#!/usr/bin/env python3
import os
import re
import subprocess
import sys
from pathlib import Path

VERSION = "git-graph 0.7.0"

LONG_HELP = """Structured Git graphs for your branching model.
    https://github.com/mlange-42/git-graph

EXAMPES:
    git-graph                   -> Show graph
    git-graph --style round     -> Show graph in a different style
    git-graph --model <model>   -> Show graph using a certain <model>
    git-graph model --list      -> List available branching models
    git-graph model             -> Show repo's current branching models
    git-graph model <model>     -> Permanently set model <model> for this repo

Usage: executable [OPTIONS] [COMMAND]

Commands:
  model  Prints or permanently sets the branching model for a repository.
  help   Print this message or the help of the given subcommand(s)

Options:
  -p, --path <path>                 Open repository from this path or above. Default '.'
      --skip-repo-owner-validation  Skip owner validation for the repository.
                                    This will turn off libgit2's owner validation, which may increase security risks.
                                    Please do not disable this validation for repositories you do not trust.
  -m, --model <model>               Branching model. Available presets are [simple|git-flow|none].
                                    Default: git-flow. 
                                    Permanently set the model for a repository with
                                    > git-graph model <model>
  -n, --max-count <n>               Maximum number of commits
      --color <color>               Specify when colors should be used. One of [auto|always|never].
                                    Default: auto.
      --no-color                    Print without colors. Missing color support should be detected
                                    automatically (e.g. when piping to a file).
                                    Overrides option '--color'
  -w, --wrap [<wrap>...]            Line wrapping for formatted commit text. Default: 'auto 0 8'
                                    Argument format: [<width>|auto|none[ <indent1>[ <indent2>]]]
                                    For examples, consult 'git-graph --help'
  -f, --format <format>             Commit format. One of [oneline|short|medium|full|"<string>"].
                                      (First character can be used as abbreviation, e.g. '-f m')
                                    Default: oneline.
                                    For placeholders supported in "<string>", consult 'git-graph --help'
  -r, --reverse                     Reverse the order of commits.
  -l, --local                       Show only local branches, no remotes.
      --svg                         Render graph as SVG instead of text-based.
  -d, --debug                       Additional debug output and graphics.
  -S, --sparse                      Print a less compact graph: merge lines point to target lines
                                    rather than merge commits.
  -s, --style <style>               Output style. One of [normal/thin|round|bold|double|ascii].
                                      (First character can be used as abbreviation, e.g. '-s r')
  -h, --help                        Print help (see more with '--help')
  -V, --version                     Print version"""

MODEL_HELP = """Prints or permanently sets the branching model for a repository.

Usage: executable model [OPTIONS] [model]

Arguments:
  [model]  The branching model to be used. Available presets are [simple|git-flow|none].
           When not given, prints the currently set model.

Options:
  -l, --list  List all available branching models.
  -h, --help  Print help"""

def run(cmd, cwd=None, check=True):
    p = subprocess.run(cmd, cwd=cwd, text=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    if check and p.returncode != 0:
        sys.stderr.write(p.stderr or p.stdout)
        sys.exit(p.returncode)
    return p.stdout.rstrip("\n")

def git(cwd, args, check=True):
    return run(["git"] + args, cwd=cwd, check=check)

def repo_root(path):
    out = git(path, ["rev-parse", "--show-toplevel"], check=False)
    return out if out else None

def config_file(root):
    return Path(root) / ".git" / "git-graph.toml"

def get_model(root):
    f = config_file(root)
    if not f.exists():
        return None
    m = re.search(r'model\s*=\s*"([^"]+)"', f.read_text(errors="ignore"))
    return m.group(1) if m else None

def set_model(root, model):
    config_file(root).write_text(f'model = "{model}"\n')

def parse_args(argv):
    opts = {"path": ".", "model": None, "max": None, "format": "oneline", "style": "normal",
            "reverse": False, "local": False, "svg": False, "color": "auto"}
    rest = []
    i = 0
    while i < len(argv):
        a = argv[i]
        if a in ("-h", "--help"):
            print(LONG_HELP); sys.exit(0)
        if a in ("-V", "--version"):
            print(VERSION); sys.exit(0)
        if a == "help":
            if i + 1 < len(argv) and argv[i+1] == "model":
                print(MODEL_HELP)
            else:
                print(LONG_HELP)
            sys.exit(0)
        if a == "model":
            return opts, argv[i:]
        if a in ("-p", "--path"):
            i += 1; opts["path"] = argv[i]
        elif a.startswith("--path="):
            opts["path"] = a.split("=", 1)[1]
        elif a in ("-m", "--model"):
            i += 1; opts["model"] = argv[i]
        elif a.startswith("--model="):
            opts["model"] = a.split("=", 1)[1]
        elif a in ("-n", "--max-count"):
            i += 1; opts["max"] = argv[i]
        elif a.startswith("--max-count="):
            opts["max"] = a.split("=", 1)[1]
        elif a in ("-f", "--format"):
            i += 1; opts["format"] = argv[i]
        elif a.startswith("--format="):
            opts["format"] = a.split("=", 1)[1]
        elif a in ("-s", "--style"):
            i += 1; opts["style"] = argv[i]
        elif a.startswith("--style="):
            opts["style"] = a.split("=", 1)[1]
        elif a in ("-r", "--reverse"):
            opts["reverse"] = True
        elif a in ("-l", "--local"):
            opts["local"] = True
        elif a == "--svg":
            opts["svg"] = True
        elif a == "--no-color":
            opts["color"] = "never"
        elif a == "--color":
            i += 1; opts["color"] = argv[i]
        elif a.startswith("--color="):
            opts["color"] = a.split("=", 1)[1]
        elif a in ("-w", "--wrap", "-d", "--debug", "-S", "--sparse", "--skip-repo-owner-validation"):
            if a in ("-w", "--wrap"):
                while i + 1 < len(argv) and not argv[i+1].startswith("-"):
                    i += 1
        elif a.startswith("-"):
            print(f"error: unexpected argument '{a}' found\n\nUsage: executable [OPTIONS] [COMMAND]\n\nFor more information, try '--help'.", file=sys.stderr)
            sys.exit(2)
        else:
            rest.append(a)
        i += 1
    if rest:
        print(f"error: unexpected argument '{rest[0]}' found\n\nUsage: executable [OPTIONS] [COMMAND]\n\nFor more information, try '--help'.", file=sys.stderr)
        sys.exit(2)
    return opts, None

def handle_model(opts, argv):
    if len(argv) > 1 and argv[1] in ("-h", "--help"):
        print(MODEL_HELP); return
    if len(argv) > 1 and argv[1] in ("-l", "--list"):
        print("none\nsimple\ngit-flow"); return
    root = repo_root(opts["path"])
    if not root:
        print("ERROR: Could not find repository", file=sys.stderr); sys.exit(1)
    if len(argv) == 1:
        m = get_model(root)
        print(m if m else "No branching model set", end="" if m else "\n")
        return
    m = argv[1]
    if m not in ("none", "simple", "git-flow"):
        print(f"ERROR: No branching model named '{m}' found in /home/agent/.config/git-graph/models\n       Available models are: none, simple, git-flow", file=sys.stderr)
        sys.exit(1)
    set_model(root, m)
    print(f"Branching model set to '{m}'", end="")

def refs_for_commits(cwd, local=False):
    args = ["for-each-ref", "--format=%(objectname)%00%(refname:short)%00%(refname)"]
    if local:
        args += ["refs/heads", "refs/tags"]
    else:
        args += ["refs/heads", "refs/remotes", "refs/tags"]
    refs = {}
    for line in git(cwd, args, check=False).splitlines():
        parts = line.split("\0")
        if len(parts) >= 3:
            refs.setdefault(parts[0], []).append((parts[1], parts[2]))
    head = git(cwd, ["symbolic-ref", "--quiet", "--short", "HEAD"], check=False)
    if head:
        h = git(cwd, ["rev-parse", "HEAD"], check=False)
        refs.setdefault(h, []).insert(0, ("HEAD -> " + head, "HEAD"))
    return refs

def decorate(refs):
    if not refs:
        return ""
    branches, tags = [], []
    seen = set()
    head_target = None
    for short, full in refs:
        if full == "HEAD" and short.startswith("HEAD -> "):
            head_target = short.split(" -> ", 1)[1]
    for short, full in refs:
        if short in seen:
            continue
        seen.add(short)
        if full.startswith("refs/tags/"):
            tags.append("[" + short + "]")
        elif full.startswith("refs/remotes/") and short.endswith("/HEAD"):
            continue
        elif head_target and short == head_target:
            continue
        else:
            branches.append(short)
    out = ""
    if branches:
        out += " (" + ", ".join(branches) + ")"
    if tags:
        out += (" " if out else "") + " ".join(tags)
    return out

def commit_info(cwd, h, refs):
    fmt = "%H%x00%h%x00%P%x00%p%x00%s%x00%b%x00%B%x00%an%x00%ae%x00%ad%x00%as%x00%cn%x00%ce%x00%cd%x00%cs"
    vals = git(cwd, ["show", "-s", f"--format={fmt}", "--date=default", h]).split("\0")
    keys = ["%H","%h","%P","%p","%s","%b","%B","%an","%ae","%ad","%as","%cn","%ce","%cd","%cs"]
    d = dict(zip(keys, vals))
    d["%d"] = decorate(refs.get(h, []))
    return d

def expand(fmt, info):
    if fmt in ("o", "oneline"):
        return "%h%d %s"
    if fmt in ("s", "short"):
        return "commit %H%d%nAuthor: %an <%ae>%n%n    %s%n"
    if fmt in ("m", "medium"):
        return "commit %H%d%nAuthor: %an <%ae>%nDate:   %ad%n%n    %s%n%n%b"
    if fmt in ("f", "full"):
        return "commit %H%d%nMerge: %p%nAuthor: %an <%ae>%nCommit: %cn <%ce>%nDate:   %ad%n%n    %s%n%n%b"
    return fmt

def render_format(fmt, info):
    fmt = expand(fmt, info)
    out, i = "", 0
    while i < len(fmt):
        if fmt[i] != "%":
            out += fmt[i]; i += 1; continue
        if i + 1 < len(fmt) and fmt[i+1] == "n":
            out += "\n"; i += 2; continue
        mod = ""
        j = i + 1
        if j < len(fmt) and fmt[j] in "+- ":
            mod = fmt[j]; j += 1
        key = None
        for k in sorted(info.keys(), key=len, reverse=True):
            name = k[1:]
            if fmt.startswith(name, j):
                key = k; break
        if key:
            val = info.get(key, "")
            if mod == "+" and val:
                out += "\n"
            elif mod == " " and val:
                out += " "
            elif mod == "-" and not val:
                out = re.sub(r"\n+$", "", out)
            out += val
            i = j + len(key) - 1
        else:
            out += "%"
            i += 1
    return out.rstrip("\n")

def style_line(line, style, parents_count=1):
    s = style
    if s.startswith("a"):
        return line
    chars = {
        "normal": {"*": "●", "|": "│", "\\": "┐", "/": "┘", "-": "─"},
        "thin": {"*": "●", "|": "│", "\\": "┐", "/": "┘", "-": "─"},
        "round": {"*": "●", "|": "│", "\\": "╮", "/": "╯", "-": "─"},
        "bold": {"*": "●", "|": "┃", "\\": "┓", "/": "┛", "-": "━"},
        "double": {"*": "●", "|": "║", "\\": "╗", "/": "╝", "-": "═"},
    }.get("normal" if s.startswith("n") or s.startswith("t") else
          "round" if s.startswith("r") else "bold" if s.startswith("b") else
          "double" if s.startswith("d") else s)
    if not chars:
        print(f"Unknown characters/style '{style}'. Must be one of [normal|thin|round|bold|double|ascii]", file=sys.stderr)
        sys.exit(1)
    line = "".join(chars.get(c, c) for c in line)
    if parents_count > 1:
        line = line.replace("●", "○", 1)
    return line

def style_prefix(prefix, style, parents_count=1):
    return style_line(prefix, style, parents_count)

def render_svg(cwd, commits):
    rows = max(1, len(commits))
    print(f'<svg height="{rows*30+15}" viewBox="0 0 30 {rows*30+15}" width="30" xmlns="http://www.w3.org/2000/svg">')
    for i, _ in enumerate(commits):
        y = 15 + i * 30
        if i:
            print(f'<line x1="15" x2="15" y1="{y-30}" y2="{y}" stroke="blue" stroke-width="2"/>')
        print(f'<circle cx="15" cy="{y}" fill="blue" r="4" stroke="blue" stroke-width="1"/>')
    print("</svg>")

def render(opts):
    cwd = opts["path"]
    root = repo_root(cwd)
    if not root:
        print("ERROR: Could not find repository", file=sys.stderr); sys.exit(1)
    if opts["model"] and opts["model"] not in ("none", "simple", "git-flow"):
        print(f"ERROR: No branching model named '{opts['model']}' found in /home/agent/.config/git-graph/models\n       Available models are: none, simple, git-flow", file=sys.stderr)
        sys.exit(1)
    valid_styles = ("normal", "thin", "round", "bold", "double", "ascii", "n", "t", "r", "b", "d", "a")
    if opts["style"] not in valid_styles and not any(x.startswith(opts["style"]) for x in ("normal", "thin", "round", "bold", "double", "ascii")):
        print(f"Unknown characters/style '{opts['style']}'. Must be one of [normal|thin|round|bold|double|ascii]", file=sys.stderr)
        sys.exit(1)
    refs = refs_for_commits(root, opts["local"])
    base = ["log", "--graph", "--topo-order", "--all", "--pretty=format:%H%x00"]
    if opts["local"]:
        base = ["log", "--graph", "--topo-order", "--branches", "--tags", "--pretty=format:%H%x00"]
    if opts["reverse"]:
        base.insert(3, "--reverse")
    if opts["max"]:
        base.append("-n"); base.append(str(opts["max"]))
    raw = git(root, base, check=False)
    hashes = re.findall(r"([0-9a-f]{40})\x00", raw)
    if opts["svg"]:
        render_svg(root, hashes); return
    info_cache = {}
    for line in raw.splitlines():
        m = re.search(r"([0-9a-f]{40})\x00", line)
        if not m:
            print(style_line(line, opts["style"]))
            continue
        h = m.group(1)
        info = info_cache.get(h)
        if info is None:
            info = commit_info(root, h, refs); info_cache[h] = info
        text = render_format(opts["format"], info)
        prefix = line[:m.start()]
        pc = len(info.get("%P","").split()) if info.get("%P") else 0
        lines = text.splitlines() or [""]
        print(style_prefix(prefix, opts["style"], pc) + lines[0])
        cont_prefix = style_prefix(re.sub(r"[*]", "|", prefix), opts["style"], pc)
        for extra in lines[1:]:
            print(cont_prefix + extra)

def main():
    opts, sub = parse_args(sys.argv[1:])
    if sub:
        handle_model(opts, sub)
    else:
        render(opts)

if __name__ == "__main__":
    main()
