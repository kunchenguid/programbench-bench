#!/usr/bin/env python3
import os
import re
import subprocess
import sys


COLORS = {
    "black": 30,
    "red": 31,
    "green": 32,
    "yellow": 33,
    "blue": 34,
    "magenta": 35,
    "cyan": 36,
    "white": 37,
    "lightblack": 90,
    "lightred": 91,
    "lightgreen": 92,
    "lightyellow": 93,
    "lightblue": 94,
    "lightmagenta": 95,
    "lightcyan": 96,
    "lightwhite": 97,
}


DEFAULT = {
    "labelType": "long",
    "coverThreshold": 50.0,
    "leaveTestPrefix": False,
    "removals": [],
    "styles": {
        "build": {"bold": True, "foreground": "yellow"},
        "start": {"foreground": "lightBlack"},
        "pass": {"foreground": "green"},
        "fail": {"bold": True, "foreground": "red"},
        "skip": {"foreground": "lightBlack"},
        "passPackage": {"foreground": "green", "hide": True},
        "failPackage": {"bold": True, "foreground": "red", "hide": True},
        "covered": {"foreground": "green"},
        "uncovered": {"bold": True, "foreground": "yellow"},
        "file": {"foreground": "cyan"},
        "line": {"foreground": "magenta"},
    },
}


STYLE_KEYS = {
    "buildStyle": "build",
    "startStyle": "start",
    "passStyle": "pass",
    "failStyle": "fail",
    "skipStyle": "skip",
    "passPackageStyle": "passPackage",
    "failPackageStyle": "failPackage",
    "coveredStyle": "covered",
    "uncoveredStyle": "uncovered",
    "fileStyle": "file",
    "lineStyle": "line",
}


def copy_config():
    cfg = {
        "labelType": DEFAULT["labelType"],
        "coverThreshold": DEFAULT["coverThreshold"],
        "leaveTestPrefix": DEFAULT["leaveTestPrefix"],
        "removals": [],
        "styles": {k: dict(v) for k, v in DEFAULT["styles"].items()},
    }
    return cfg


def boolval(s):
    return str(s).strip().lower() in ("true", "yes", "1", "on")


def clean_value(v):
    v = v.strip()
    if "#" in v and not (v.startswith('"') or v.startswith("'")):
        v = v.split("#", 1)[0].strip()
    if (v.startswith('"') and v.endswith('"')) or (v.startswith("'") and v.endswith("'")):
        v = v[1:-1]
    return v


def load_config():
    cfg = copy_config()
    names = [".richstyle", ".richstyle.yaml", ".richstyle.yml"]
    dirs = [os.getcwd()]
    if os.environ.get("RICHGO_LOCAL") != "1":
        for key in ("GOPATH", "GOROOT", "HOME"):
            val = os.environ.get(key)
            if not val and key in ("GOPATH", "GOROOT"):
                try:
                    val = subprocess.check_output(["go", "env", key], text=True).strip()
                except Exception:
                    val = ""
            if val:
                dirs.append(val)
    path = None
    for d in dirs:
        for n in names:
            p = os.path.join(d, n)
            if os.path.exists(p):
                path = p
                break
        if path:
            break
    if not path:
        return cfg

    current_style = None
    in_removals = False
    try:
        lines = open(path, "r", encoding="utf-8").read().splitlines()
    except OSError:
        return cfg
    for raw in lines:
        if not raw.strip() or raw.lstrip().startswith("#"):
            continue
        indent = len(raw) - len(raw.lstrip(" "))
        s = raw.strip()
        if in_removals and s.startswith("- "):
            cfg["removals"].append(clean_value(s[2:]))
            continue
        if indent == 0:
            current_style = None
            in_removals = False
            if ":" not in s:
                continue
            key, val = s.split(":", 1)
            key = key.strip()
            val = clean_value(val)
            if key in STYLE_KEYS:
                current_style = STYLE_KEYS[key]
            elif key == "removals":
                in_removals = True
            elif key == "labelType" and val:
                cfg["labelType"] = val
            elif key == "coverThreshold" and val:
                try:
                    cfg["coverThreshold"] = float(val)
                except ValueError:
                    pass
            elif key == "leaveTestPrefix" and val:
                cfg["leaveTestPrefix"] = boolval(val)
        elif current_style and ":" in s:
            key, val = s.split(":", 1)
            key = key.strip()
            val = clean_value(val)
            if key == "hide":
                cfg["styles"][current_style]["hide"] = boolval(val)
            elif key in ("bold", "faint", "italic", "underline", "blinkSlow", "blinkRapid",
                         "inverse", "conceal", "crossOut", "frame", "encircle", "overline"):
                cfg["styles"][current_style][key] = boolval(val)
            elif key in ("foreground", "background"):
                cfg["styles"][current_style][key] = val
    return cfg


def want_color():
    if os.environ.get("RICHGO_FORCE_COLOR"):
        return True
    if os.environ.get("NO_COLOR"):
        return False
    return sys.stdout.isatty()


def style_codes(style):
    codes = []
    fg = style.get("foreground")
    if fg:
        code = COLORS.get(fg.replace("_", "").replace("-", "").lower())
        if code:
            codes.append(str(code))
    bg = style.get("background")
    if bg:
        code = COLORS.get(bg.replace("_", "").replace("-", "").lower())
        if code:
            codes.append(str(code + 10))
    attrs = [
        ("bold", "1"), ("faint", "2"), ("italic", "3"), ("underline", "4"),
        ("blinkSlow", "5"), ("blinkRapid", "6"), ("inverse", "7"),
        ("conceal", "8"), ("crossOut", "9"), ("frame", "51"),
        ("encircle", "52"), ("overline", "53"),
    ]
    for key, code in attrs:
        if style.get(key):
            codes.append(code)
    return "".join("\033[" + c + "m" for c in codes)


def apply_style(text, style):
    codes = style_codes(style)
    if not codes:
        return text
    return codes + text + "\033[0m"


def label(kind, cfg):
    lt = cfg["labelType"]
    if lt == "none":
        return ""
    if lt == "short":
        return {"build": "!!", "start": ">", "pass": "o", "fail": "x", "skip": "-", "cover": "%"}.get(kind, " ") + "  "
    return {"build": "BUILD| ", "start": "START| ", "pass": "PASS | ", "fail": "FAIL | ", "skip": "SKIP | ", "cover": "COVER| "}.get(kind, "     | ")


def continuation_label(cfg):
    if cfg["labelType"] == "none":
        return ""
    if cfg["labelType"] == "short":
        return "   "
    return "     | "


def trim_test_prefix(name, cfg):
    if cfg["leaveTestPrefix"]:
        return name
    return re.sub(r"(^|/)Test", r"\1", name)


def test_indent(name):
    return "  " if "/" in name else ""


def coverage_bar(pct):
    filled = int(pct / 10.0)
    if filled < 0:
        filled = 0
    if filled > 10:
        filled = 10
    return "[" + "#" * filled + "_" * (10 - filled) + "]"


def emit(kind, text, cfg, style_name=None):
    st = cfg["styles"].get(style_name or kind, {})
    if st.get("hide"):
        return None
    return apply_style(label(kind, cfg) + text, st)


def highlight_build_text(text, cfg):
    m = re.match(r"(\s*)([^:\s][^:]*?\.go)(:\d+(?::\d+)?)(:.*)?$", text)
    if not m:
        return text
    pre, filepart, linepart, rest = m.groups()
    file_s = apply_style(filepart, cfg["styles"]["file"])
    line_s = apply_style(linepart, cfg["styles"]["line"])
    return pre + file_s + line_s + (rest or "")


def filter_stream(inp, out, decorate):
    if not decorate:
        for line in inp:
            out.write(line)
        return 0
    cfg = load_config()
    removals = [re.compile(r) for r in cfg["removals"] if r]
    for raw in inp:
        line = raw.rstrip("\n")
        if any(r.search(line) for r in removals):
            continue
        rendered = render_line(line, cfg)
        if rendered is not None:
            out.write(rendered + "\n")
    return 0


def render_line(line, cfg):
    m = re.match(r"^=== RUN\s+(.+)$", line)
    if m:
        name = trim_test_prefix(m.group(1), cfg)
        return emit("start", test_indent(name) + name, cfg)
    m = re.match(r"^--- (PASS|FAIL|SKIP):\s+(\S+)(.*)$", line)
    if m:
        typ = m.group(1).lower()
        name = trim_test_prefix(m.group(2), cfg)
        rest = m.group(3)
        return emit(typ, test_indent(name) + name + rest, cfg)
    if line == "PASS":
        return emit("pass", "", cfg, "passPackage")
    if line == "FAIL":
        return emit("fail", "", cfg, "failPackage")
    m = re.match(r"^ok\s+(\S+)\s+(.+?)(?:\s+coverage:\s+([0-9.]+)% of statements)?$", line)
    if m:
        pkg, _elapsed, cov = m.groups()
        if cov is not None:
            return emit("pass", f"{pkg} coverage: {cov}% of statements", cfg)
        return emit("pass", f"{pkg} ", cfg)
    m = re.match(r"^FAIL\s+(.+)$", line)
    if m:
        return emit("fail", " " + m.group(1), cfg)
    m = re.match(r"^\?\s+(\S+)\s+\[no test files\]$", line)
    if m:
        return emit("skip", f"{m.group(1)} [no test files]", cfg)
    m = re.match(r"^(?:coverage:\s+)?([0-9.]+)% of statements$", line)
    if m:
        pct = float(m.group(1))
        style = "covered" if pct >= cfg["coverThreshold"] else "uncovered"
        return emit("cover", f"{m.group(1)}% {coverage_bar(pct)}", cfg, style)
    m = re.match(r"^#\s+(.+)$", line)
    if m:
        return emit("build", m.group(1), cfg)
    # Lines that look like compiler/test diagnostics are build-styled.
    if re.search(r"\.go:\d+", line) or re.match(r"^\s*(panic:|.+: undefined|.+: expected)", line):
        text = continuation_label(cfg) + highlight_build_text(line, cfg)
        return apply_style(text, cfg["styles"]["build"])
    return line


def run_go(args):
    try:
        p = subprocess.run(["go"] + args)
        return p.returncode
    except FileNotFoundError:
        sys.stderr.write("go: command not found\n")
        return 127


def run_test(args):
    decorate = want_color()
    p = subprocess.Popen(["go", "test"] + args, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
    assert p.stdout is not None
    filter_stream(p.stdout, sys.stdout, decorate)
    return p.wait()


def main():
    args = sys.argv[1:]
    if args and args[0] == "testfilter":
        return filter_stream(sys.stdin, sys.stdout, want_color())
    if args and args[0] == "test":
        return run_test(args[1:])
    return run_go(args)


if __name__ == "__main__":
    sys.exit(main())
