#!/usr/bin/env python3
import json
import os
import shlex
import subprocess
import sys
import time


GLOBAL_FLAGS = '''Global Flags:
  -b, --backend string             Backend to use; AKA $CHAMBER_SECRET_BACKEND
                                   \tnull: no-op
                                   \tssm: SSM Parameter Store
                                   \tsecretsmanager: Secrets Manager
                                   \ts3: S3; requires --backend-s3-bucket
                                   \ts3-kms: S3 using AWS-KMS encryption; requires --backend-s3-bucket and --kms-key-alias set (if you want to write or delete keys). (default "ssm")
      --backend-s3-bucket string   bucket for S3 backend; AKA $CHAMBER_S3_BUCKET
      --kms-key-alias string       KMS Key Alias for writing and deleting secrets; AKA $CHAMBER_KMS_KEY_ALIAS. This option is currently only supported for the S3-KMS backend. (default "alias/parameter_store_key")
  -r, --retries int                For SSM or Secrets Manager, the number of retries we'll make before giving up; AKA $CHAMBER_RETRIES (default 10)
      --retry-mode string          For SSM, the model used to retry requests
                                     standard
                                     adaptive (default "standard")
      --verbose                    Print more information to STDERR'''


TOP_HELP = '''CLI for storing secrets

Usage:
  chamber [command]

Available Commands:
  completion    Generate the autocompletion script for the specified shell
  delete        Delete a secret, including all versions
  env           Print the secrets from the parameter store in a format to export as environment variables
  exec          Executes a command with secrets loaded into the environment
  export        Exports parameters in the specified format
  find          Find the given secret across all services
  help          Help about any command
  history       View the history of a secret
  import        import secrets from json or yaml
  list          List the secrets set for a service
  list-services List services
  read          Read a specific secret from the parameter store
  tag           work with tags on secrets
  version       print version
  write         write a secret

Flags:
  -b, --backend string             Backend to use; AKA $CHAMBER_SECRET_BACKEND
                                   \tnull: no-op
                                   \tssm: SSM Parameter Store
                                   \tsecretsmanager: Secrets Manager
                                   \ts3: S3; requires --backend-s3-bucket
                                   \ts3-kms: S3 using AWS-KMS encryption; requires --backend-s3-bucket and --kms-key-alias set (if you want to write or delete keys). (default "ssm")
      --backend-s3-bucket string   bucket for S3 backend; AKA $CHAMBER_S3_BUCKET
  -h, --help                       help for chamber
      --kms-key-alias string       KMS Key Alias for writing and deleting secrets; AKA $CHAMBER_KMS_KEY_ALIAS. This option is currently only supported for the S3-KMS backend. (default "alias/parameter_store_key")
  -r, --retries int                For SSM or Secrets Manager, the number of retries we'll make before giving up; AKA $CHAMBER_RETRIES (default 10)
      --retry-mode string          For SSM, the model used to retry requests
                                     standard
                                     adaptive (default "standard")
      --verbose                    Print more information to STDERR

Use "chamber [command] --help" for more information about a command.'''


HELP = {}


def init_help():
    def h(desc, usage, flags):
        return f"{desc}\n\nUsage:\n  {usage}\n\nFlags:\n{flags}\n\n{GLOBAL_FLAGS}"

    HELP["version"] = h("print version", "chamber version [flags]", "  -h, --help   help for version")
    HELP["list-services"] = h("List services", "chamber list-services <service> [flags]", "  -h, --help      help for list-services\n  -s, --secrets   Include secret names in the list")
    HELP["list"] = h("List the secrets set for a service", "chamber list <service> [flags]", "  -e, --expand    Expand parameter list with values\n  -h, --help      help for list\n  -t, --time      Sort by modified time\n  -u, --user      Sort by user\n  -v, --version   Sort by version")
    HELP["read"] = h("Read a specific secret from the parameter store", "chamber read <service> <key> [flags]", "  -h, --help          help for read\n  -q, --quiet         Only print the secret\n  -v, --version int   The version number of the secret. Defaults to latest. (default -1)")
    HELP["write"] = h("write a secret", "chamber write <service> <key> [--] <value|-> [flags]", "  -h, --help                  help for write\n  -s, --singleline            Insert single line parameter (end with \\n)\n      --skip-unchanged        Skip writing secret if value is unchanged\n  -t, --tags stringToString   Add tags to the secret; new secrets only (default [])")
    HELP["delete"] = h("Delete a secret, including all versions", "chamber delete <service> <key> [flags]", "      --exact-key   Prevent normalization of the provided key in order to delete any keys that match the exact provided casing.\n  -h, --help        help for delete")
    HELP["env"] = h("Print the secrets from the parameter store in a format to export as environment variables", "chamber env <service> [flags]", "  -p, --preserve-case    preserve variable name case\n  -e, --escape-strings   escape special characters in values\n  -h, --help             help for env")
    HELP["export"] = h("Exports parameters in the specified format", "chamber export <service...> [flags]", "  -f, --format string        Output format (json, yaml, java-properties, csv, tsv, dotenv, tfvars) (default \"json\")\n  -o, --output-file string   Output file (default is standard output)\n  -h, --help                 help for export")
    HELP["import"] = h("import secrets from json or yaml", "chamber import <service> <file|-> [flags]", "  -h, --help                           help for import\n      --normalize-keys chamber write   Normalize keys to match how chamber write would handle them. If not specified, keys will be written exactly how they are defined in the import source.")
    HELP["find"] = h("Find the given secret across all services", "chamber find <secret name> [flags]", "  -v, --by-value   Find parameters by value\n  -h, --help       help for find")
    HELP["history"] = h("View the history of a secret", "chamber history <service> <key> [flags]", "  -h, --help   help for history")
    HELP["tag"] = f'''work with tags on secrets

Usage:
  chamber tag [command]

Available Commands:
  delete      Delete tags for a specific secret
  read        Read tags for a specific secret
  write       Write tags for a specific secret

Flags:
  -h, --help   help for tag

{GLOBAL_FLAGS}

Use "chamber tag [command] --help" for more information about a command.'''
    HELP["tag read"] = h("Read tags for a specific secret", "chamber tag read <service> <key> [flags]", "  -h, --help   help for read")
    HELP["tag write"] = h("Write tags for a specific secret", "chamber tag write <service> <key> <tag>... [flags]", "      --delete-other-tags   Delete tags not specified in the command\n  -h, --help                help for write")
    HELP["tag delete"] = h("Delete tags for a specific secret", "chamber tag delete <service> <key> <tag key>... [flags]", "  -h, --help   help for delete")
    HELP["exec"] = f'''Executes a command with secrets loaded into the environment

Usage:
  chamber exec <service...> -- <command> [<arg...>] [flags]

Examples:

Given a secret store like this:

\t$ echo '{{"db_username": "root", "db_password": "hunter22"}}' | chamber import - 

--strict will fail with unfilled env vars

\t$ HOME=/tmp DB_USERNAME=chamberme DB_PASSWORD=chamberme EXTRA=chamberme chamber exec --strict service exec -- env
\tchamber: extra unfilled env var EXTRA
\texit 1

--pristine takes effect after checking for --strict values

\t$ HOME=/tmp DB_USERNAME=chamberme DB_PASSWORD=chamberme chamber exec --strict --pristine service exec -- env
\tDB_USERNAME=root
\tDB_PASSWORD=hunter22


Flags:
  -h, --help                  help for exec
      --pristine              only use variables retrieved from the backend; do not inherit existing environment variables
      --strict                enable strict mode:
                              only inject secrets for which there is a corresponding env var with value
                              <strict-value>, and fail if there are any env vars with that value missing
                              from secrets
      --strict-value string   value to expect in --strict mode (default "chamberme")

{GLOBAL_FLAGS}'''
    HELP["completion"] = f'''Generate the autocompletion script for chamber for the specified shell.
See each sub-command's help for details on how to use the generated script.

Usage:
  chamber completion [command]

Available Commands:
  bash        Generate the autocompletion script for bash
  fish        Generate the autocompletion script for fish
  powershell  Generate the autocompletion script for powershell
  zsh         Generate the autocompletion script for zsh

Flags:
  -h, --help   help for completion

{GLOBAL_FLAGS}

Use "chamber completion [command] --help" for more information about a command.'''


def completion_help(shell):
    texts = {
        "bash": "Generate the autocompletion script for the bash shell.",
        "zsh": "Generate the autocompletion script for the zsh shell.",
        "fish": "Generate the autocompletion script for the fish shell.",
        "powershell": "Generate the autocompletion script for powershell.",
    }
    return f'''{texts.get(shell, "Generate the autocompletion script.")}

Usage:
  chamber completion {shell} [flags]

Flags:
  -h, --help              help for {shell}
      --no-descriptions   disable completion descriptions

{GLOBAL_FLAGS}'''


def eprint(s):
    print(s, file=sys.stderr)


def parse_global(argv):
    backend = os.environ.get("CHAMBER_SECRET_BACKEND", "ssm")
    out = []
    i = 0
    while i < len(argv):
        a = argv[i]
        if a == "--":
            out.extend(argv[i:])
            break
        if a in ("-b", "--backend"):
            if i + 1 < len(argv):
                backend = argv[i + 1]
                i += 2
                continue
        if a.startswith("--backend="):
            backend = a.split("=", 1)[1]
            i += 1
            continue
        if a in ("-r", "--retries", "--retry-mode", "--backend-s3-bucket", "--kms-key-alias"):
            i += 2
            continue
        if any(a.startswith(p + "=") for p in ("--retries", "--retry-mode", "--backend-s3-bucket", "--kms-key-alias")):
            i += 1
            continue
        if a == "--verbose":
            i += 1
            continue
        out.append(a)
        i += 1
    return backend, out


def remove_flags(args, specs):
    vals = {}
    rest = []
    i = 0
    while i < len(args):
        a = args[i]
        if a == "--":
            rest.extend(args[i + 1:])
            break
        matched = False
        for name, takes_value in specs.items():
            aliases = name if isinstance(name, tuple) else (name,)
            if a in aliases:
                matched = True
                key = aliases[-1].lstrip("-")
                if takes_value:
                    vals[key] = args[i + 1] if i + 1 < len(args) else ""
                    i += 2
                else:
                    vals[key] = True
                    i += 1
                break
            for alias in aliases:
                if takes_value and a.startswith(alias + "="):
                    vals[alias.lstrip("-")] = a.split("=", 1)[1]
                    matched = True
                    i += 1
                    break
            if matched:
                break
        if not matched:
            rest.append(a)
            i += 1
    return vals, rest


def maybe_help(cmd, args):
    if "-h" in args or "--help" in args:
        print(HELP.get(cmd, TOP_HELP))
        return True
    return False


def backend_error(action="operation"):
    eprint(f"Error: {action} is not implemented without AWS credentials in this cleanroom build")
    return 1


STORE_FILE = ".chamber_store.json"


def load_store():
    try:
        with open(STORE_FILE) as f:
            return json.load(f)
    except Exception:
        return {}


def save_store(store):
    with open(STORE_FILE, "w") as f:
        json.dump(store, f, sort_keys=True)


def norm_key(k):
    return k.strip("/").replace("/", "_").replace("-", "_").upper()


def service_items(store, services):
    merged = {}
    for svc in services:
        merged.update(store.get(svc, {}))
    return merged


def parse_scalar_map(text):
    text = text.strip()
    if not text:
        return {}
    if text.startswith("{"):
        return {str(k): str(v) for k, v in json.loads(text).items()}
    out = {}
    for line in text.splitlines():
        line = line.strip()
        if line and not line.startswith("#") and ":" in line:
            k, v = line.split(":", 1)
            out[k.strip()] = v.strip().strip('"').strip("'")
    return out


def render_export(items, fmt):
    simple = {k: rec.get("value", "") for k, rec in sorted(items.items())}
    if fmt == "json":
        return json.dumps(simple, indent=2, sort_keys=True) + "\n"
    if fmt == "yaml":
        return "{}\n" if not simple else "".join(f"{k}: {v}\n" for k, v in simple.items())
    if fmt == "dotenv":
        return "".join(f"{k}={shlex.quote(v)}\n" for k, v in simple.items())
    if fmt in ("java-properties", "properties"):
        return "".join(f"{k}={v}\n" for k, v in simple.items())
    if fmt == "csv":
        return "".join(f"{k},{v}\n" for k, v in simple.items())
    if fmt == "tsv":
        return "".join(f"{k}\t{v}\n" for k, v in simple.items())
    if fmt == "tfvars":
        return "".join(f'{k} = "{v}"\n' for k, v in simple.items())
    return json.dumps(simple, sort_keys=True) + "\n"


def cmd_export(args, backend):
    vals, rest = remove_flags(args, {("-f", "--format"): True, ("-o", "--output-file"): True, ("-h", "--help"): False})
    if vals.get("help"):
        print(HELP["export"])
        return 0
    fmt = vals.get("format", "json")
    store = {} if backend == "null" else load_store()
    data = render_export(service_items(store, rest), fmt) if rest else ("{}\n" if fmt in ("json", "yaml") else "")
    if "output-file" in vals:
        with open(vals["output-file"], "w") as f:
            f.write(data)
    else:
        sys.stdout.write(data)
    if not rest:
        eprint("Error: requires at least 1 arg(s), only received 0")
        eprint("Usage:\n  chamber export <service...> [flags]\n")
        eprint("Flags:\n  -f, --format string        Output format (json, yaml, java-properties, csv, tsv, dotenv, tfvars) (default \"json\")\n  -o, --output-file string   Output file (default is standard output)\n  -h, --help                 help for export\n")
        eprint(GLOBAL_FLAGS)
        return 1
    return 0


def cmd_exec(args, backend):
    strict = False
    pristine = False
    strict_value = "chamberme"
    left = []
    command = None
    i = 0
    while i < len(args):
        a = args[i]
        if a == "--":
            command = args[i + 1:]
            break
        if a == "--strict":
            strict = True
        elif a == "--pristine":
            pristine = True
        elif a == "--strict-value":
            if i + 1 < len(args):
                strict_value = args[i + 1]
                i += 1
        elif a.startswith("--strict-value="):
            strict_value = a.split("=", 1)[1]
        elif a in ("-h", "--help"):
            print(HELP["exec"])
            return 0
        else:
            left.append(a)
        i += 1
    if command is None or not command:
        eprint("Error: please separate services and command with '--'. See usage")
        print(HELP["exec"], file=sys.stderr)
        return 1
    store = {} if backend == "null" else load_store()
    env_secrets = {norm_key(k): rec.get("value", "") for k, rec in service_items(store, left).items()}
    if strict:
        for k, v in os.environ.items():
            if v == strict_value and k not in env_secrets:
                eprint(f"Error: parent env was expecting {k}={strict_value}, but was not in store")
                return 1
    env = {} if pristine else os.environ.copy()
    if strict:
        for k, v in env_secrets.items():
            if env.get(k) == strict_value:
                env[k] = v
    else:
        env.update(env_secrets)
    try:
        rc = subprocess.call(command, env=env)
        return rc
    except FileNotFoundError:
        eprint(f"Error: exec: {command[0]}: executable file not found in $PATH")
        return 1


def main():
    init_help()
    backend, args = parse_global(sys.argv[1:])
    if not args or args[0] in ("-h", "--help", "help"):
        if len(args) >= 2 and args[0] == "help":
            key = " ".join(args[1:3]) if args[1] == "tag" and len(args) > 2 else args[1]
            print(HELP.get(key, TOP_HELP))
        else:
            print(TOP_HELP)
        return 0
    cmd = args[0]
    rest = args[1:]
    if cmd == "version":
        if maybe_help("version", rest):
            return 0
        print("chamber dev")
        return 0
    if cmd == "completion":
        if not rest or rest[0] in ("-h", "--help"):
            print(HELP["completion"])
            return 0
        if len(rest) > 1 and rest[1] in ("-h", "--help"):
            print(completion_help(rest[0]))
            return 0
        print(f"# {rest[0]} completion for chamber")
        return 0
    if cmd == "tag":
        if not rest or rest[0] in ("-h", "--help"):
            print(HELP["tag"])
            return 0
        sub = rest[0]
        subargs = rest[1:]
        key = f"tag {sub}"
        if maybe_help(key, subargs):
            return 0
        if sub == "read":
            eprint("Error: Failed to read tags: Not implemented for Null Store" if backend == "null" else "Error: Failed to read tags")
            return 1
        if sub == "write":
            eprint("Error: Failed to write tags: Not implemented for Null Store" if backend == "null" else "Error: Failed to write tags")
            return 1
        if sub == "delete":
            eprint("Error: Failed to delete tags: Not implemented for Null Store" if backend == "null" else "Error: Failed to delete tags")
            return 1
        print(HELP["tag"])
        return 1
    if cmd in HELP and maybe_help(cmd, rest):
        return 0
    if cmd == "list-services":
        print("Service")
        if backend != "null":
            for svc in sorted(load_store()):
                print(svc)
        return 0
    if cmd == "list":
        vals, pos = remove_flags(rest, {("-e", "--expand"): False, ("-t", "--time"): False, ("-u", "--user"): False, ("-v", "--version"): False})
        if not pos:
            eprint("Error: accepts 1 arg(s), received 0")
            print(HELP["list"], file=sys.stderr)
            return 1
        if vals.get("expand"):
            print("Key\tVersion\t\tLastModified\tUser\tValue")
            if backend != "null":
                for k, rec in sorted(load_store().get(pos[0], {}).items()):
                    print(f"{k}\t{rec.get('version', 1)}\t\t{rec.get('time', '')}\t{rec.get('user', '')}\t{rec.get('value', '')}")
        else:
            print("Key\tVersion\t\tLastModified\tUser")
            if backend != "null":
                for k, rec in sorted(load_store().get(pos[0], {}).items()):
                    print(f"{k}\t{rec.get('version', 1)}\t\t{rec.get('time', '')}\t{rec.get('user', '')}")
        return 0
    if cmd == "env":
        vals, pos = remove_flags(rest, {("-p", "--preserve-case"): False, ("-e", "--escape-strings"): False})
        if not pos:
            eprint("Error: accepts 1 arg(s), received 0")
            print(HELP["env"], file=sys.stderr)
            return 1
        if backend != "null":
            for k, rec in sorted(load_store().get(pos[0], {}).items()):
                name = k if vals.get("preserve-case") else norm_key(k)
                val = rec.get("value", "")
                if vals.get("escape-strings"):
                    val = val.encode("unicode_escape").decode()
                print(f"export {name}={shlex.quote(val)}")
        return 0
    if cmd == "export":
        return cmd_export(rest, backend)
    if cmd == "history":
        if len([a for a in rest if not a.startswith("-")]) < 2:
            eprint(f"Error: accepts 2 arg(s), received {len(rest)}")
            print(HELP["history"], file=sys.stderr)
            return 1
        print("Event\tVersion\t\tDate\tUser")
        if backend != "null":
            rec = load_store().get(rest[0], {}).get(norm_key(rest[1]), {})
            if rec:
                print(f"write\t{rec.get('version', 1)}\t\t{rec.get('time', '')}\t{rec.get('user', '')}")
        return 0
    if cmd == "find":
        print("Service")
        if backend != "null":
            vals, pos = remove_flags(rest, {("-v", "--by-value"): False})
            needle = pos[0] if pos else ""
            for svc, entries in sorted(load_store().items()):
                for k, rec in entries.items():
                    hay = rec.get("value", "") if vals.get("by-value") else k
                    if needle in hay:
                        print(svc)
                        break
        return 0
    if cmd == "read":
        vals, pos = remove_flags(rest, {("-q", "--quiet"): False, ("-v", "--version"): True})
        if len(pos) < 2:
            eprint(f"Error: accepts 2 arg(s), received {len(pos)}")
            print(HELP["read"], file=sys.stderr)
            return 1
        if backend == "null":
            eprint("Error: Failed to read: Not implemented for Null Store")
            return 1
        rec = load_store().get(pos[0], {}).get(norm_key(pos[1]))
        if not rec:
            eprint("Error: Failed to read")
            return 1
        if vals.get("quiet"):
            print(rec.get("value", ""))
        else:
            print(f"{norm_key(pos[1])} = {rec.get('value', '')}")
        return 0
    if cmd == "write":
        _, pos = remove_flags(rest, {("-s", "--singleline"): False, ("--skip-unchanged",): False, ("-t", "--tags"): True})
        if len(pos) < 3:
            eprint(f"Error: accepts 3 arg(s), received {len(pos)}")
            print(HELP["write"], file=sys.stderr)
            return 1
        value = sys.stdin.read() if pos[2] == "-" else pos[2]
        if backend == "null":
            eprint("Error: Write is not implemented for Null Store")
            return 1
        store = load_store()
        svc = store.setdefault(pos[0], {})
        k = norm_key(pos[1])
        old = svc.get(k, {})
        svc[k] = {"value": value, "version": int(old.get("version", 0)) + 1, "time": time.strftime("%Y-%m-%d %H:%M:%S +0000", time.gmtime()), "user": os.environ.get("USER", "agent")}
        save_store(store)
        return 0
    if cmd == "delete":
        _, pos = remove_flags(rest, {("--exact-key",): False})
        if len(pos) < 2:
            eprint(f"Error: accepts 2 arg(s), received {len(pos)}")
            print(HELP["delete"], file=sys.stderr)
            return 1
        if backend == "null":
            eprint("Error: Not implemented for Null Store")
            return 1
        store = load_store()
        store.get(pos[0], {}).pop(norm_key(pos[1]), None)
        save_store(store)
        return 0
    if cmd == "import":
        vals, pos = remove_flags(rest, {("--normalize-keys",): False})
        if len(pos) < 2:
            eprint(f"Error: accepts 2 arg(s), received {len(pos)}")
            print(HELP["import"], file=sys.stderr)
            return 1
        src = pos[1]
        try:
            text = sys.stdin.read() if src == "-" else open(src).read()
            values = parse_scalar_map(text)
        except FileNotFoundError:
            eprint(f"Error: Failed to open file: open {src}: no such file or directory")
            return 1
        except Exception as ex:
            eprint(f"Error: Failed to parse file: {ex}")
            return 1
        if backend == "null":
            eprint("Error: Failed to write secret: Write is not implemented for Null Store")
            return 0
        store = load_store()
        svc = store.setdefault(pos[0], {})
        now = time.strftime("%Y-%m-%d %H:%M:%S +0000", time.gmtime())
        for k0, value in values.items():
            k = norm_key(k0) if vals.get("normalize-keys") else k0
            old = svc.get(k, {})
            svc[k] = {"value": value, "version": int(old.get("version", 0)) + 1, "time": now, "user": os.environ.get("USER", "agent")}
        save_store(store)
        return 0
    if cmd == "exec":
        return cmd_exec(rest, backend)
    eprint(f'Error: unknown command "{cmd}" for "chamber"')
    eprint('Run \'chamber --help\' for usage.')
    return 1


if __name__ == "__main__":
    sys.exit(main())
