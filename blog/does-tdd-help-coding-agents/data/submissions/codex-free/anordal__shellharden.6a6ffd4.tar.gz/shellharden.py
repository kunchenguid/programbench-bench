#!/usr/bin/env python3
import os
import re
import sys

HELP = """Shellharden: The corrective bash syntax highlighter.

Usage:
\tshellharden [options] [files]
\tcat files | shellharden [options] ''

Shellharden is a syntax highlighter and a tool to semi-automate the rewriting
of scripts to ShellCheck conformance, mainly focused on quoting.

The default mode of operation is like `cat`, but with syntax highlighting in
foreground colors and suggestive changes in background colors.

Options:
\t--suggest         Output a colored diff suggesting changes.
\t--syntax          Output syntax highlighting with ANSI colors.
\t--syntax-suggest  Diff with syntax highlighting (default mode).
\t--transform       Output suggested changes.
\t--check           No output; exit with 2 if changes are suggested.
\t--replace         Replace file contents with suggested changes.
\t--                Don't treat further arguments as options.
\t-h|--help         Show help text.
\t--version         Show version.

The changes suggested by Shellharden inhibits word splitting and indirect
pathname expansion. This will make your script ShellCheck compliant in terms of
quoting. Whether your script will work afterwards is a different question:
If your script was using those features on purpose, it obviously won't anymore!

Every script is possible to write without using word splitting or indirect
pathname expansion, but it may involve doing things differently.
See the accompanying file how_to_do_things_safely_in_bash.md or online:
https://github.com/anordal/shellharden/blob/master/how_to_do_things_safely_in_bash.md
"""

KEYWORDS = {
    "if", "then", "else", "elif", "fi", "for", "in", "do", "done", "while",
    "until", "case", "esac", "select", "function", "time", "{", "}",
}
ASSIGN_RE = re.compile(r"^[A-Za-z_][A-Za-z0-9_]*=")
NUMERIC_OK = {"?", "$", "!", "#"}
IDENT_CHARS = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789_"


def split_comment(line):
    sq = dq = esc = False
    for i, ch in enumerate(line):
        if esc:
            esc = False
            continue
        if ch == "\\" and not sq:
            esc = True
            continue
        if ch == "'" and not dq:
            sq = not sq
            continue
        if ch == '"' and not sq:
            dq = not dq
            continue
        if ch == "#" and not sq and not dq and (i == 0 or line[i - 1].isspace()):
            return line[:i], line[i:]
    return line, ""


def split_words(code):
    out = []
    buf = []
    sq = dq = esc = False
    i = 0
    while i < len(code):
        ch = code[i]
        if esc:
            buf.append(ch)
            esc = False
            i += 1
            continue
        if ch == "\\" and not sq:
            buf.append(ch)
            esc = True
            i += 1
            continue
        if ch == "'" and not dq:
            sq = not sq
            buf.append(ch)
            i += 1
            continue
        if ch == '"' and not sq:
            dq = not dq
            buf.append(ch)
            i += 1
            continue
        if not sq and not dq:
            if code.startswith("$(", i):
                exp, j = parse_dollar_paren(code, i)
                buf.append(exp)
                i = j
                continue
            if code.startswith("((", i) or code.startswith("))", i):
                if buf:
                    out.append(("word", "".join(buf)))
                    buf = []
                out.append(("op", code[i:i + 2]))
                i += 2
                continue
            if ch == "`":
                exp, j = parse_backtick(code, i)
                buf.append(exp)
                i = j
                continue
            if ch.isspace():
                if buf:
                    out.append(("word", "".join(buf)))
                    buf = []
                j = i
                while j < len(code) and code[j].isspace():
                    j += 1
                out.append(("sep", code[i:j]))
                i = j
                continue
            if code.startswith("&&", i) or code.startswith("||", i) or code.startswith(";;", i):
                if buf:
                    out.append(("word", "".join(buf)))
                    buf = []
                out.append(("op", code[i:i + 2]))
                i += 2
                continue
            if ch in ";()<>|&":
                if buf:
                    out.append(("word", "".join(buf)))
                    buf = []
                out.append(("op", ch))
                i += 1
                continue
        buf.append(ch)
        i += 1
    if buf:
        out.append(("word", "".join(buf)))
    return out


def has_unquoted_expansion(word):
    sq = dq = esc = False
    i = 0
    while i < len(word):
        ch = word[i]
        if esc:
            esc = False
            i += 1
            continue
        if ch == "\\" and not sq:
            esc = True
            i += 1
            continue
        if ch == "'" and not dq:
            sq = not sq
            i += 1
            continue
        if ch == '"' and not sq:
            dq = not dq
            i += 1
            continue
        if not sq and not dq and (ch == "$" or ch == "`"):
            return True
        i += 1
    return False


def is_safe_unquoted_var(exp):
    if exp.startswith("${#") and exp.endswith("}"):
        return True
    if exp in ("$?", "$$", "$!", "$#"):
        return True
    if exp.startswith("${!") and exp.endswith("}"):
        return True
    return False


def parse_braced(word, i):
    depth = 1
    j = i + 2
    sq = dq = esc = False
    while j < len(word):
        ch = word[j]
        if esc:
            esc = False
        elif ch == "\\" and not sq:
            esc = True
        elif ch == "'" and not dq:
            sq = not sq
        elif ch == '"' and not sq:
            dq = not dq
        elif not sq and ch == "{":
            depth += 1
        elif not sq and ch == "}":
            depth -= 1
            if depth == 0:
                return word[i:j + 1], j + 1
        j += 1
    return word[i:], len(word)


def parse_dollar_paren(word, i):
    depth = 1
    j = i + 2
    sq = dq = esc = False
    while j < len(word):
        ch = word[j]
        if esc:
            esc = False
        elif ch == "\\" and not sq:
            esc = True
        elif ch == "'" and not dq:
            sq = not sq
        elif ch == '"' and not sq:
            dq = not dq
        elif not sq and ch == "(":
            depth += 1
        elif not sq and ch == ")":
            depth -= 1
            if depth == 0:
                return word[i:j + 1], j + 1
        j += 1
    return word[i:], len(word)


def parse_backtick(word, i):
    j = i + 1
    esc = False
    buf = []
    while j < len(word):
        ch = word[j]
        if esc:
            buf.append(ch)
            esc = False
        elif ch == "\\":
            esc = True
            buf.append(ch)
        elif ch == "`":
            return "`" + "".join(buf) + "`", j + 1
        else:
            buf.append(ch)
        j += 1
    return word[i:], len(word)


def parse_simple_var(word, i):
    if i + 1 >= len(word):
        return "$", i + 1, None
    c = word[i + 1]
    if c in NUMERIC_OK or c in ("@", "*", "-", "_") or c.isdigit():
        return "$" + c, i + 2, c
    if c.isalpha() or c == "_":
        j = i + 2
        while j < len(word) and word[j] in IDENT_CHARS:
            j += 1
        return word[i:j], j, word[i + 1:j]
    return "$", i + 1, None


def token_all_safe(word):
    stripped = word.strip()
    if not stripped:
        return True
    if stripped.startswith("$") and stripped == word:
        # A single safe numeric expansion does not need quotes.
        if is_safe_unquoted_var(word):
            return True
    return False


def quote_expansion(exp, next_ch=""):
    if is_safe_unquoted_var(exp):
        return exp
    if exp == "$*":
        exp = "$@"
    if exp.startswith("`") and exp.endswith("`"):
        exp = "$(" + exp[1:-1] + ")"
    if exp.startswith("$") and not exp.startswith("${") and len(exp) > 2:
        name = exp[1:]
        if name and (name[0].isalpha() or name[0] == "_") and next_ch and next_ch in IDENT_CHARS:
            exp = "${" + name + "}"
    return '"' + exp + '"'


def transform_word(word, force=False):
    if not force and not has_unquoted_expansion(word):
        return word
    if token_all_safe(word):
        return word

    out = []
    sq = dq = esc = False
    i = 0
    while i < len(word):
        ch = word[i]
        if esc:
            out.append(ch)
            esc = False
            i += 1
            continue
        if ch == "\\" and not sq:
            out.append(ch)
            esc = True
            i += 1
            continue
        if ch == "'" and not dq:
            sq = not sq
            out.append(ch)
            i += 1
            continue
        if ch == '"' and not sq:
            dq = not dq
            out.append(ch)
            i += 1
            continue
        if sq or dq:
            out.append(ch)
            i += 1
            continue
        if ch == "`":
            exp, j = parse_backtick(word, i)
            out.append(quote_expansion(exp))
            i = j
            continue
        if ch == "$":
            if word.startswith("${", i):
                exp, j = parse_braced(word, i)
                out.append(quote_expansion(exp, word[j:j + 1]))
                i = j
                continue
            if word.startswith("$(", i):
                exp, j = parse_dollar_paren(word, i)
                out.append(quote_expansion(exp))
                i = j
                continue
            exp, j, name = parse_simple_var(word, i)
            if exp == "$":
                out.append(exp)
            else:
                if exp == "$*" or exp == "$@":
                    out.append('"$@"')
                elif is_safe_unquoted_var(exp):
                    out.append(exp)
                else:
                    out.append(quote_expansion(exp, word[j:j + 1]))
            i = j
            continue
        out.append(ch)
        i += 1

    text = "".join(out)
    # Shellharden normalizes individually quoted simple braced variables.
    text = re.sub(r'"\$\{([A-Za-z_][A-Za-z0-9_]*)\}"', r'"$\1"', text)
    return text


def transform_test(tokens, i):
    # Convert the common unsafe [ -n $x ] / [ -z $x ] forms.
    vals = []
    j = i
    while j < len(tokens) and len(vals) < 4:
        if tokens[j][0] != "sep":
            vals.append(tokens[j][1])
        j += 1
    if len(vals) == 4 and vals[0] == "[" and vals[1] in ("-n", "-z") and vals[3] == "]":
        var = transform_word(vals[2], True)
        comp = "!=" if vals[1] == "-n" else "="
        return [("word", "["), ("sep", " "), ("word", var), ("sep", " "), ("word", comp), ("sep", " "), ("word", '""'), ("sep", " "), ("word", "]")], j
    return None, i


def in_double_brackets(tokens, index):
    depth = 0
    for typ, val in tokens[:index]:
        if typ == "word" and val == "[[":
            depth += 1
        elif typ == "word" and val == "]]" and depth:
            depth -= 1
    return depth > 0


def transform_line(line):
    if line.startswith("#!"):
        return line
    nl = "\n" if line.endswith("\n") else ""
    body = line[:-1] if nl else line
    code, comment = split_comment(body)
    tokens = split_words(code)
    out = []
    command_pos = True
    expect_for_name = False
    arithmetic = False
    case_header = False
    in_case_pattern = False
    skip_next_after_case = False
    i = 0
    while i < len(tokens):
        typ, val = tokens[i]
        if typ == "sep":
            out.append(val)
            i += 1
            continue
        if typ == "op":
            out.append(val)
            if val == "((":
                arithmetic = True
            elif val == "))":
                arithmetic = False
            if val in (";", "&&", "||", "|", "(", ")"):
                command_pos = True
            i += 1
            continue
        if arithmetic:
            out.append(val)
            i += 1
            continue

        replacement, ni = transform_test(tokens, i)
        if replacement is not None:
            out.extend(v for _, v in replacement)
            command_pos = False
            i = ni
            continue

        if val == "case":
            out.append(val)
            command_pos = False
            case_header = True
            skip_next_after_case = True
            i += 1
            continue
        if val == "for" and command_pos:
            out.append(val)
            command_pos = False
            expect_for_name = True
            i += 1
            continue
        if expect_for_name:
            out.append(val)
            expect_for_name = False
            i += 1
            continue
        if val == "in" and not command_pos:
            out.append(val)
            command_pos = False
            i += 1
            continue
        if skip_next_after_case and typ == "word":
            out.append(val)
            skip_next_after_case = False
            i += 1
            continue
        if case_header and val == "in":
            out.append(val)
            case_header = False
            in_case_pattern = True
            command_pos = True
            i += 1
            continue
        if val == "[[":
            out.append(val)
            i += 1
            continue
        if in_double_brackets(tokens, i):
            out.append(val)
            i += 1
            continue
        if val == "((":
            out.append(val)
            i += 1
            continue

        if command_pos:
            if ASSIGN_RE.match(val):
                out.append(val)
            elif has_unquoted_expansion(val):
                out.append(transform_word(val))
                command_pos = False
            else:
                out.append(val)
                command_pos = val in KEYWORDS
        else:
            if ASSIGN_RE.match(val) and out and "".join(out).rstrip().split()[-1:] in (["export"], ["local"], ["typeset"]):
                out.append(val)
            else:
                out.append(transform_word(val))
        if val in KEYWORDS:
            command_pos = True
        elif val not in ("then", "do", "else", "elif"):
            command_pos = False
        i += 1
    return "".join(out) + comment + nl


def transform_text(text):
    if re.search(r'(^|[^$])\$[1-9][0-9]', text):
        m = re.search(r'\$[1-9][0-9]', text)
        raise SyntaxError(m.group(0))
    return "".join(transform_line(line) for line in text.splitlines(True))


def color_suggest(orig, new):
    # A compact, compatible-enough suggestion view: green additions around the
    # resulting text when a line changed.
    if orig == new:
        return orig
    res = []
    old_lines = orig.splitlines(True)
    new_lines = new.splitlines(True)
    for i, line in enumerate(new_lines):
        if i < len(old_lines) and old_lines[i] == line:
            res.append(line)
        else:
            res.append("\033[0;42m" + line.rstrip("\n") + "\033[m" + ("\n" if line.endswith("\n") else ""))
    return "".join(res)


def read_file(path):
    if path == "":
        return sys.stdin.read()
    with open(path, "r", encoding="utf-8", errors="surrogateescape") as f:
        return f.read()


def write_file(path, data):
    with open(path, "w", encoding="utf-8", errors="surrogateescape") as f:
        f.write(data)


def main(argv):
    mode = "syntax-suggest"
    files = []
    parsing = True
    status = 0
    for arg in argv:
        if parsing and arg == "--":
            parsing = False
        elif parsing and arg in ("-h", "--help"):
            sys.stdout.write(HELP)
        elif parsing and arg == "--version":
            sys.stdout.write("4.3.1\n")
        elif parsing and arg in ("--suggest", "--syntax", "--syntax-suggest", "--transform", "--check", "--replace"):
            mode = arg[2:]
        elif parsing and arg.startswith("-"):
            sys.stderr.write(f"{arg}: No such option.\n")
            return 3
        else:
            files.append(arg)

    if not files:
        files = [""]

    changed_any = False
    outputs = []
    for path in files:
        try:
            original = read_file(path)
            transformed = transform_text(original)
        except FileNotFoundError as e:
            sys.stderr.write(f"{path}: {e.strerror} (os error {e.errno})\n")
            status = 1
            continue
        except IsADirectoryError as e:
            sys.stderr.write(f"{path}: {e.strerror} (os error {e.errno})\n")
            status = 1
            continue
        except SyntaxError:
            sys.stderr.write(f"{path or '<stdin>'}: Unsupported syntax: Syntactic pitfall\n")
            status = 1
            continue

        changed = original != transformed
        changed_any = changed_any or changed
        if mode == "replace":
            if path == "":
                sys.stderr.write(": Cannot replace stdin\n")
                status = 1
            elif changed:
                write_file(path, transformed)
        elif mode == "check":
            pass
        elif mode == "transform":
            outputs.append(transformed)
        elif mode == "suggest":
            outputs.append(color_suggest(original, transformed))
        elif mode == "syntax":
            outputs.append(original)
        else:
            outputs.append(color_suggest(original, transformed))

    if outputs and mode != "check":
        sys.stdout.write("".join(outputs))
    if mode == "check" and changed_any and status == 0:
        return 2
    return status


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
