#!/usr/bin/env python3
import argparse
import csv
import html
import json
import os
import re
import shlex
import sys
import time


VERSION = "3.54.0 2026-04-14 20:02:49 49b3bac482c831f503c7f90c35959e7ea731950e991baba86b2ab95987d2539b (64-bit)"


HELP = """Usage: ./executable [OPTIONS] [FILENAME [SQL...]]
FILENAME is the name of an SQLite database. A new database is created
if the file does not previously exist. Defaults to :memory:.
OPTIONS include:
   --                   treat no subsequent arguments as options
   -A ARGS...           run ".archive ARGS" and exit
   -append              append the database to the end of the file
   -ascii               set output mode to 'ascii'
   -bail                stop after hitting an error
   -batch               force batch I/O
   -box                 set output mode to 'box'
   -cmd COMMAND         run "COMMAND" before reading stdin
   -column              set output mode to 'column'
   -csv                 set output mode to 'csv'
   -deserialize         open the database using sqlite3_deserialize()
   -echo                print inputs before execution
   -escape T            ctrl-char escape; T is one of: symbol, ascii, off
   -init FILENAME       read/process named file
   -[no]header          turn headers on or off
   -help                show this message
   -html                set output mode to HTML
   -ifexists            only open if database already exists
   -interactive         force interactive I/O
   -json                set output mode to 'json'
   -line                set output mode to 'line'
   -list                set output mode to 'list'
   -lookaside SIZE N    use N entries of SZ bytes for lookaside memory
   -markdown            set output mode to 'markdown'
   -maxsize N           maximum size for a --deserialize database
   -memtrace            trace all memory allocations and deallocations
   -mmap N              default mmap size set to N
   -newline SEP         set output row separator. Default: '\\n'
   -nofollow            refuse to open symbolic links to database files
   -noinit              Do not read the ~/.sqliterc file at startup
   -nonce STRING        set the safe-mode escape nonce
   -no-rowid-in-view    Disable rowid-in-view using sqlite3_config()
   -nullvalue TEXT      set text string for NULL values. Default ''
   -pagecache SIZE N    use N slots of SZ bytes each for page cache memory
   -pcachetrace         trace all page cache operations
   -quote               set output mode to 'quote'
   -readonly            open the database read-only
   -safe                enable safe-mode
   -screenwidth N       use N as the default screenwidth 
   -separator SEP       set output column separator. Default: '|'
   -stats               print memory stats before each finalize
   -table               set output mode to 'table'
   -tabs                set output mode to 'tabs'
   -unsafe-testing      allow unsafe commands and modes for testing
   -version             show SQLite version
   -vfs NAME            use NAME as the default VFS
   -vfstrace            enable tracing of all VFS calls
   -zip                 open the file as a ZIP Archive"""


DOT_HELP = """.archive ...             Manage SQL archives
.backup ?DB? FILE        Backup DB (default "main") to FILE
.bail on|off             Stop after hitting an error.  Default OFF
.cd DIRECTORY            Change the working directory to DIRECTORY
.changes on|off          Show number of rows changed by SQL
.databases               List names and files of attached databases
.dump ?OBJECTS?          Render database content as SQL
.echo on|off             Turn command echo on or off
.exit ?CODE?             Exit this program with return-code CODE
.headers on|off          Turn display of headers on or off
.help ?-all? ?PATTERN?   Show help text for PATTERN
.import FILE TABLE       Import data from FILE into TABLE
.indexes ?PATTERN?       Show names of indexes matching PATTERN
.mode ?MODE? ?OPTIONS?   Set output mode
.nullvalue STRING        Use STRING in place of NULL values
.once ?OPTIONS? ?FILE?   Output for the next SQL command only to FILE
.open ?OPTIONS? ?FILE?   Close existing database and reopen FILE
.output ?FILE?           Send output to FILE or stdout if FILE is omitted
.print STRING...         Print literal STRING
.quit                    Stop interpreting input stream, exit if primary.
.read FILE               Read input from FILE or command output
.restore ?DB? FILE       Restore content of DB (default "main") from FILE
.save ?OPTIONS? FILE     Write database to FILE (an alias for .backup ...)
.schema ?PATTERN?        Show the CREATE statements matching PATTERN
.separator COL ?ROW?     Change the column and row separators
.tables ?TABLE?          List names of tables matching LIKE pattern TABLE
.timeout MS              Try opening locked tables for MS milliseconds
.timer on|off|once       Turn SQL timer on or off.
.version                 Show source, library and compiler versions"""


def unescape_arg(s):
    return s.encode("utf-8").decode("unicode_escape")


def quote_sql(v):
    if v is None:
        return "NULL"
    if isinstance(v, (int, float)):
        return str(v)
    return "'" + str(v).replace("'", "''") + "'"


def display_value(v, nullvalue=""):
    return nullvalue if v is None else str(v)


def visible_width(s):
    return len(str(s))


def split_top(s, sep=","):
    out, buf, quote, depth = [], "", None, 0
    i = 0
    while i < len(s):
        ch = s[i]
        if quote:
            buf += ch
            if ch == quote:
                if i + 1 < len(s) and s[i + 1] == quote:
                    buf += s[i + 1]
                    i += 1
                else:
                    quote = None
        else:
            if ch in ("'", '"'):
                quote = ch
                buf += ch
            elif ch == "(":
                depth += 1
                buf += ch
            elif ch == ")":
                depth -= 1
                buf += ch
            elif ch == sep and depth == 0:
                out.append(buf.strip())
                buf = ""
            else:
                buf += ch
        i += 1
    if buf.strip() or s.endswith(sep):
        out.append(buf.strip())
    return out


def split_statements(s):
    out, buf, quote = [], "", None
    i = 0
    while i < len(s):
        ch = s[i]
        buf += ch
        if quote:
            if ch == quote:
                if i + 1 < len(s) and s[i + 1] == quote:
                    buf += s[i + 1]
                    i += 1
                else:
                    quote = None
        else:
            if ch in ("'", '"'):
                quote = ch
            elif ch == ";":
                out.append(buf[:-1].strip())
                buf = ""
        i += 1
    if buf.strip():
        out.append(buf.strip())
    return [x for x in out if x]


def complete_statement(s):
    return len(split_statements(s)) > 0 and s.rstrip().endswith(";")


def parse_literal(s):
    s = s.strip()
    if not s:
        return ""
    if s.lower() == "null":
        return None
    if (s[0:1] == "'" and s[-1:] == "'") or (s[0:1] == '"' and s[-1:] == '"'):
        inner = s[1:-1]
        if s[0] not in inner.replace(s[0] + s[0], ""):
            return inner.replace(s[0] + s[0], s[0])
    try:
        if re.match(r"^[+-]?\d+$", s):
            return int(s)
        if re.match(r"^[+-]?\d+\.\d*(e[+-]?\d+)?$", s, re.I):
            return float(s)
    except Exception:
        pass
    return s


def sql_name(s):
    s = s.strip()
    if (s.startswith('"') and s.endswith('"')) or (s.startswith("[") and s.endswith("]")) or (s.startswith("`") and s.endswith("`")):
        return s[1:-1]
    return s


def expr_label(expr):
    m = re.match(r"(?is)^(.+?)\s+as\s+(.+)$", expr.strip())
    if m:
        return sql_name(m.group(2).strip())
    parts = expr.strip().rsplit(None, 1)
    if len(parts) == 2 and re.match(r"^[A-Za-z_]\w*$", parts[1]) and not re.search(r"[+\-*/()'\"]", parts[1]):
        return parts[1]
    return expr.strip()


def strip_alias(expr):
    m = re.match(r"(?is)^(.+?)\s+as\s+(.+)$", expr.strip())
    if m:
        return m.group(1).strip()
    return expr.strip()


def sql_to_python(expr):
    e = expr.strip()
    e = re.sub(r"(?i)\bsqlite_version\s*\(\s*\)", repr(VERSION.split()[0]), e)
    e = re.sub(r"(?i)\bnull\b", "None", e)
    e = re.sub(r"(?i)\band\b", "and", e)
    e = re.sub(r"(?i)\bor\b", "or", e)
    e = re.sub(r"(?i)\bnot\b", "not", e)
    e = re.sub(r"<>", "!=", e)
    e = re.sub(r"(?<![<>=!])=(?!=)", "==", e)
    e = e.replace("||", "+")
    return e


def eval_expr(expr, env):
    expr = strip_alias(expr)
    if expr == "*":
        return None
    if re.match(r"^[A-Za-z_]\w*$", expr) and expr in env:
        return env[expr]
    lit = parse_literal(expr)
    if lit != expr or expr.lower() == "null":
        return lit
    safe = {k: v for k, v in env.items()}
    safe.update({"None": None, "abs": abs, "round": round, "len": len, "length": lambda x: len(str(x)), "lower": lambda x: str(x).lower(), "upper": lambda x: str(x).upper()})
    return eval(sql_to_python(expr), {"__builtins__": {}}, safe)


class Shell:
    def __init__(self, dbname=":memory:", readonly=False):
        self.dbname = dbname or ":memory:"
        self.readonly = readonly
        self.conn = None
        self.mode = "list"
        self.headers = False
        self.nullvalue = ""
        self.separator = "|"
        self.rowsep = "\n"
        self.echo = False
        self.bail = False
        self.timer = False
        self.widths = []
        self.output = sys.stdout
        self.once = None
        self.changes = False
        self.db = {"tables": {}, "indexes": {}}
        self.open_db(self.dbname, readonly)

    def open_db(self, name, readonly=False):
        self.dbname = name or ":memory:"
        self.readonly = readonly
        self.conn = None
        if self.dbname != ":memory:" and os.path.exists(self.dbname):
            try:
                with open(self.dbname, "r") as f:
                    self.db = json.load(f)
            except Exception:
                self.db = {"tables": {}, "indexes": {}}
        else:
            self.db = {"tables": {}, "indexes": {}}

    def save_db(self):
        if self.readonly or self.dbname == ":memory:":
            return
        tmp = self.dbname + ".tmp"
        with open(tmp, "w") as f:
            json.dump(self.db, f)
        os.replace(tmp, self.dbname)

    def out(self, text="", end="\n"):
        print(text, end=end, file=self.output)

    def print_error(self, text):
        print(text, file=sys.stderr)

    def set_mode(self, mode):
        m = mode.lower()
        aliases = {"tabs": "tabs", "tab": "tabs"}
        m = aliases.get(m, m)
        if m in ("list", "line", "column", "csv", "quote", "json", "html", "table", "box", "markdown", "ascii", "tabs"):
            self.mode = m
            if m == "csv":
                self.separator = ","
            elif m == "tabs":
                self.separator = "\t"
            elif m == "ascii":
                self.separator = "\x1f"
                self.rowsep = "\x1e"
            return True
        self.print_error(f"Error: mode should be one of: ascii box column csv html insert json line list markdown quote table tabs")
        return False

    def execute_script(self, text, source="stdin"):
        rc = 0
        buf = ""
        for raw in text.splitlines(True):
            line = raw.rstrip("\n")
            if not buf and line.lstrip().startswith("."):
                if self.echo:
                    self.out(line)
                try:
                    code = self.dot_command(line)
                except SystemExit:
                    raise
                except Exception as e:
                    self.print_error(f"Error: {e}")
                    code = 1
                if code and self.bail:
                    return code
                rc = max(rc, code)
                continue
            buf += raw
            if complete_statement(buf):
                stmt = buf.strip()
                buf = ""
                if stmt:
                    if self.echo:
                        self.out(stmt)
                    code = self.execute_sql(stmt, source)
                    rc = max(rc, code)
                    if code and self.bail:
                        return rc
        if buf.strip():
            if self.echo:
                self.out(buf.strip())
            code = self.execute_sql(buf.strip(), source)
            rc = max(rc, code)
        return rc

    def execute_sql(self, sql, source="stdin"):
        start = time.time()
        try:
            for stmt in split_statements(sql):
                names, rows, changed = self.run_statement(stmt)
                if names is not None:
                    self.emit_result(names, rows)
                elif self.changes:
                    self.out(f"changes: {changed}")
            self.save_db()
            if self.timer:
                elapsed = time.time() - start
                self.print_error(f"Run Time: real {elapsed:.3f} user 0.000000 sys 0.000000")
            return 0
        except Exception as e:
            self.print_error(f"Parse error: {e}")
            return 1

    def run_statement(self, stmt):
        s = stmt.strip()
        low = s.lower()
        if not s:
            return None, None, 0
        if low.startswith("pragma"):
            return None, None, 0
        if low.startswith("begin") or low.startswith("commit") or low.startswith("rollback"):
            return None, None, 0
        if low.startswith("create table"):
            return self.sql_create_table(s)
        if low.startswith("create "):
            return self.sql_create_index(s)
        if low.startswith("drop table"):
            m = re.match(r"(?is)drop\s+table\s+(?:if\s+exists\s+)?([^\s;]+)", s)
            if m:
                self.db["tables"].pop(sql_name(m.group(1)), None)
            return None, None, 0
        if low.startswith("drop index"):
            m = re.match(r"(?is)drop\s+index\s+(?:if\s+exists\s+)?([^\s;]+)", s)
            if m:
                self.db["indexes"].pop(sql_name(m.group(1)), None)
            return None, None, 0
        if low.startswith("insert"):
            return self.sql_insert(s)
        if low.startswith("select") or low.startswith("with"):
            return self.sql_select(s)
        if low.startswith("update"):
            return self.sql_update(s)
        if low.startswith("delete"):
            return self.sql_delete(s)
        if low.startswith("alter table"):
            return self.sql_alter(s)
        raise Exception("near \"" + s.split()[0] + "\": syntax error")

    def sql_create_table(self, s):
        m = re.match(r"(?is)create\s+(?:temp\s+|temporary\s+)?table\s+(?:if\s+not\s+exists\s+)?([^\s(]+)\s*\((.*)\)\s*$", s)
        if not m:
            raise Exception("near \"table\": syntax error")
        name = sql_name(m.group(1))
        defs = split_top(m.group(2))
        cols = []
        for d in defs:
            first = d.strip().split(None, 1)[0]
            if first.lower() in ("primary", "foreign", "unique", "check", "constraint"):
                continue
            cols.append(sql_name(first))
        self.db["tables"].setdefault(name, {"columns": cols, "rows": [], "sql": s.rstrip(";")})
        return None, None, 0

    def sql_create_index(self, s):
        m = re.match(r"(?is)create\s+(?:unique\s+)?index\s+(?:if\s+not\s+exists\s+)?([^\s]+)\s+on\s+([^\s(]+)", s)
        if m:
            self.db["indexes"][sql_name(m.group(1))] = {"table": sql_name(m.group(2)), "sql": s.rstrip(";")}
            return None, None, 0
        return None, None, 0

    def sql_insert(self, s):
        m = re.match(r"(?is)insert\s+(?:or\s+\w+\s+)?into\s+([^\s(]+)\s*(?:\((.*?)\))?\s*values\s*(.*)$", s)
        if not m:
            raise Exception("near \"insert\": syntax error")
        name = sql_name(m.group(1))
        if name not in self.db["tables"]:
            raise Exception(f"no such table: {name}")
        table = self.db["tables"][name]
        cols = [sql_name(x) for x in split_top(m.group(2))] if m.group(2) else table["columns"]
        vals = m.group(3).strip()
        groups = []
        depth = 0; quote = None; start = None
        for i, ch in enumerate(vals):
            if quote:
                if ch == quote:
                    if i + 1 < len(vals) and vals[i + 1] == quote:
                        continue
                    quote = None
            else:
                if ch in ("'", '"'):
                    quote = ch
                elif ch == "(":
                    if depth == 0:
                        start = i + 1
                    depth += 1
                elif ch == ")":
                    depth -= 1
                    if depth == 0 and start is not None:
                        groups.append(vals[start:i])
        changed = 0
        for g in groups:
            items = [parse_literal(x) for x in split_top(g)]
            row = {c: None for c in table["columns"]}
            for c, v in zip(cols, items):
                row[c] = v
            table["rows"].append(row)
            changed += 1
        return None, None, changed

    def sql_select(self, s):
        m = re.match(r"(?is)^select\s+(.*?)(?:\s+from\s+([^\s]+)(.*))?$", s)
        if not m:
            raise Exception("near \"select\": syntax error")
        exprs_s, table_name, rest = m.group(1).strip(), m.group(2), (m.group(3) or "")
        where = None; order = None; limit = None
        wm = re.search(r"(?is)\s+where\s+(.+?)(?=\s+order\s+by|\s+limit|$)", rest)
        if wm:
            where = wm.group(1).strip()
        om = re.search(r"(?is)\s+order\s+by\s+(.+?)(?=\s+limit|$)", rest)
        if om:
            order = om.group(1).strip().split()[0]
        lm = re.search(r"(?is)\s+limit\s+(\d+)", rest)
        if lm:
            limit = int(lm.group(1))
        if table_name:
            name = sql_name(table_name)
            if name in ("sqlite_master", "sqlite_schema"):
                all_cols = ["type", "name", "tbl_name", "rootpage", "sql"]
                env_rows = []
                for tn, t in self.db["tables"].items():
                    env_rows.append({"type": "table", "name": tn, "tbl_name": tn, "rootpage": 0, "sql": (t.get("sql") or "").rstrip(";")})
                for ix, idx in self.db["indexes"].items():
                    env_rows.append({"type": "index", "name": ix, "tbl_name": idx.get("table"), "rootpage": 0, "sql": (idx.get("sql") or "").rstrip(";")})
            elif name not in self.db["tables"]:
                raise Exception(f"no such table: {name}")
            else:
                table = self.db["tables"][name]
                env_rows = [dict(r) for r in table["rows"]]
                all_cols = table["columns"]
        else:
            env_rows = [{}]
            all_cols = []
        if where:
            env_rows = [r for r in env_rows if bool(eval_expr(where, r))]
        if order:
            env_rows.sort(key=lambda r: (r.get(order) is None, r.get(order)))
        if limit is not None:
            env_rows = env_rows[:limit]
        exprs = split_top(exprs_s)
        if len(exprs) == 1 and exprs[0] == "*":
            names = list(all_cols)
            rows = [[r.get(c) for c in names] for r in env_rows]
            return names, rows, 0
        if len(exprs) == 1 and re.match(r"(?is)^count\s*\(\s*\*\s*\)", strip_alias(exprs[0])):
            return [expr_label(exprs[0])], [[len(env_rows)]], 0
        agg = re.match(r"(?is)^(sum|avg|min|max)\s*\(\s*([^)]+)\s*\)$", strip_alias(exprs[0])) if len(exprs) == 1 else None
        if agg:
            vals = [eval_expr(agg.group(2), r) for r in env_rows if eval_expr(agg.group(2), r) is not None]
            if agg.group(1).lower() == "sum":
                val = sum(vals) if vals else None
            elif agg.group(1).lower() == "avg":
                val = (sum(vals) / len(vals)) if vals else None
            elif agg.group(1).lower() == "min":
                val = min(vals) if vals else None
            else:
                val = max(vals) if vals else None
            return [expr_label(exprs[0])], [[val]], 0
        names = [expr_label(e) for e in exprs]
        rows = []
        for env in env_rows:
            rows.append([eval_expr(e, env) for e in exprs])
        return names, rows, 0

    def sql_update(self, s):
        m = re.match(r"(?is)^update\s+([^\s]+)\s+set\s+(.+?)(?:\s+where\s+(.+))?$", s)
        if not m:
            raise Exception("near \"update\": syntax error")
        name = sql_name(m.group(1))
        table = self.db["tables"].get(name)
        if not table:
            raise Exception(f"no such table: {name}")
        assigns = []
        for a in split_top(m.group(2)):
            k, v = a.split("=", 1)
            assigns.append((sql_name(k), v))
        changed = 0
        for row in table["rows"]:
            if not m.group(3) or eval_expr(m.group(3), row):
                for k, v in assigns:
                    row[k] = eval_expr(v, row)
                changed += 1
        return None, None, changed

    def sql_delete(self, s):
        m = re.match(r"(?is)^delete\s+from\s+([^\s]+)(?:\s+where\s+(.+))?$", s)
        if not m:
            raise Exception("near \"delete\": syntax error")
        name = sql_name(m.group(1))
        table = self.db["tables"].get(name)
        if not table:
            raise Exception(f"no such table: {name}")
        old = table["rows"]
        if m.group(2):
            table["rows"] = [r for r in old if not eval_expr(m.group(2), r)]
        else:
            table["rows"] = []
        return None, None, len(old) - len(table["rows"])

    def sql_alter(self, s):
        m = re.match(r"(?is)^alter\s+table\s+([^\s]+)\s+add\s+(?:column\s+)?([^\s]+)", s)
        if m:
            name, col = sql_name(m.group(1)), sql_name(m.group(2))
            table = self.db["tables"].get(name)
            if not table:
                raise Exception(f"no such table: {name}")
            table["columns"].append(col)
            for r in table["rows"]:
                r[col] = None
        return None, None, 0

    def emit_result(self, names, rows):
        old = self.output
        if self.once:
            self.output = open(self.once, "w", newline="")
            self.once = None
        try:
            if self.mode in ("list", "tabs", "ascii"):
                vals = []
                if self.headers:
                    vals.append(self.separator.join(names))
                for row in rows:
                    vals.append(self.separator.join(display_value(row[i], self.nullvalue) for i in range(len(names))))
                if vals:
                    self.out(self.rowsep.join(vals), end=self.rowsep)
            elif self.mode == "csv":
                writer = csv.writer(self.output, lineterminator="\r\n")
                if self.headers:
                    writer.writerow(names)
                for row in rows:
                    writer.writerow(["" if row[i] is None else row[i] for i in range(len(names))])
            elif self.mode == "quote":
                if self.headers:
                    self.out(",".join(quote_sql(n) for n in names))
                for row in rows:
                    self.out(",".join(quote_sql(row[i]) for i in range(len(names))))
            elif self.mode == "line":
                for row in rows:
                    for i, n in enumerate(names):
                        self.out(f"{n} = {display_value(row[i], self.nullvalue)}" if False else f"{n}: {display_value(row[i], self.nullvalue)}")
                    self.out("")
            elif self.mode == "json":
                arr = []
                for row in rows:
                    obj = {}
                    for i, n in enumerate(names):
                        obj[n] = row[i]
                    arr.append(obj)
                self.out(json.dumps(arr, separators=(",", ":")))
            elif self.mode == "html":
                for row in rows:
                    self.out("<TR>" + "".join(f"<TD>{html.escape(display_value(row[i], self.nullvalue))}</TD>" for i in range(len(names))) + "</TR>")
            elif self.mode in ("column", "table", "box", "markdown"):
                self.emit_grid(names, rows)
        finally:
            if self.output is not old:
                self.output.close()
                self.output = old

    def col_widths(self, names, rows):
        widths = []
        for i, n in enumerate(names):
            data = [display_value(r[i], self.nullvalue) for r in rows]
            w = max([visible_width(n)] + [visible_width(x) for x in data] + [1])
            if i < len(self.widths) and self.widths[i]:
                spec = self.widths[i]
                if spec > 0:
                    w = spec
                else:
                    w = -spec
            widths.append(w)
        return widths

    def trunc(self, s, w):
        s = str(s)
        return s[:w] if len(s) > w else s

    def emit_grid(self, names, rows):
        widths = self.col_widths(names, rows)
        def centered(s, w):
            s = self.trunc(display_value(s, self.nullvalue), w)
            pad = w - len(s)
            return " " * (pad // 2) + s + " " * (pad - pad // 2)
        def left(s, w):
            s = self.trunc(display_value(s, self.nullvalue), w)
            return s + " " * (w - len(s))
        if self.mode == "column":
            data = []
            if self.headers:
                data.append("  ".join(left(names[i], widths[i]) for i in range(len(names))).rstrip())
                data.append("  ".join("-" * widths[i] for i in range(len(names))).rstrip())
            for row in rows:
                data.append("  ".join(left(row[i], widths[i]) for i in range(len(names))).rstrip())
            for line in data:
                self.out(line)
        elif self.mode == "markdown":
            self.out("| " + " | ".join(centered(names[i], widths[i]) for i in range(len(names))) + " |")
            self.out("|" + "|".join("-" * (widths[i] + 2) for i in range(len(names))) + "|")
            for row in rows:
                self.out("| " + " | ".join(centered(row[i], widths[i]) for i in range(len(names))) + " |")
        elif self.mode == "table":
            border = "+" + "+".join("-" * (w + 2) for w in widths) + "+"
            self.out(border)
            self.out("| " + " | ".join(centered(names[i], widths[i]) for i in range(len(names))) + " |")
            self.out(border)
            for row in rows:
                self.out("| " + " | ".join(centered(row[i], widths[i]) for i in range(len(names))) + " |")
            self.out(border)
        elif self.mode == "box":
            top = "╭" + "┬".join("─" * (w + 2) for w in widths) + "╮"
            mid = "╞" + "╪".join("═" * (w + 2) for w in widths) + "╡"
            bot = "╰" + "┴".join("─" * (w + 2) for w in widths) + "╯"
            self.out(top)
            self.out("│ " + " │ ".join(centered(names[i], widths[i]) for i in range(len(names))) + " │")
            self.out(mid)
            for row in rows:
                self.out("│ " + " │ ".join(centered(row[i], widths[i]) for i in range(len(names))) + " │")
            self.out(bot)

    def dot_command(self, line):
        try:
            parts = shlex.split(line)
        except ValueError:
            parts = line.split()
        if not parts:
            return 0
        cmd = parts[0][1:]
        args = parts[1:]
        c = cmd.lower()
        if c in ("quit", "exit"):
            code = int(args[0]) if args else 0
            raise SystemExit(code)
        if c == "help":
            self.out(DOT_HELP)
        elif c == "version":
            self.out(VERSION)
        elif c == "bail":
            if args:
                self.bail = args[0].lower() in ("on", "yes", "1", "true")
            else:
                self.out("on" if self.bail else "off")
        elif c == "echo":
            if args:
                self.echo = args[0].lower() in ("on", "yes", "1", "true")
            else:
                self.out("on" if self.echo else "off")
        elif c in ("headers", "header"):
            if args:
                self.headers = args[0].lower() in ("on", "yes", "1", "true")
            else:
                self.out("on" if self.headers else "off")
        elif c == "mode":
            if args:
                return 0 if self.set_mode(args[0]) else 1
            self.out(self.mode)
        elif c == "nullvalue":
            self.nullvalue = args[0] if args else ""
        elif c == "separator":
            if args:
                self.separator = unescape_arg(args[0])
            if len(args) > 1:
                self.rowsep = unescape_arg(args[1])
        elif c == "width":
            self.widths = [int(x) for x in args]
        elif c == "print":
            self.out(" ".join(args))
        elif c == "cd":
            os.chdir(args[0] if args else os.path.expanduser("~"))
        elif c == "open":
            ro = False
            names = []
            for a in args:
                if a in ("--readonly", "-readonly"):
                    ro = True
                elif not a.startswith("-"):
                    names.append(a)
            self.open_db(names[-1] if names else ":memory:", ro)
        elif c == "read":
            if not args:
                self.print_error("Error: missing FILE argument")
                return 1
            with open(args[0], "r") as f:
                return self.execute_script(f.read(), args[0])
        elif c == "output":
            if self.output is not sys.stdout:
                self.output.close()
            if args:
                self.output = open(args[0], "w")
            else:
                self.output = sys.stdout
        elif c == "once":
            if args:
                self.once = args[-1]
        elif c == "timer":
            if args:
                self.timer = args[0].lower() in ("on", "yes", "1", "true")
            else:
                self.out("on" if self.timer else "off")
        elif c == "changes":
            if args:
                self.changes = args[0].lower() in ("on", "yes", "1", "true")
            else:
                self.out("on" if self.changes else "off")
        elif c == "databases":
            fn = "" if self.dbname == ":memory:" else self.dbname
            rw = "r/o" if self.readonly else "r/w"
            self.out(f'main: "{fn}" {rw}')
            self.out('temp: "" r/w')
        elif c == "tables":
            pattern = args[0] if args else None
            names = sorted(n for n in self.db["tables"] if not n.startswith("sqlite_"))
            if pattern:
                rx = "^" + re.escape(pattern).replace("\\*", ".*").replace("%", ".*") + "$"
                names = [n for n in names if re.match(rx, n)]
            if names:
                self.out(" ".join(names))
        elif c == "indexes":
            names = sorted(n for n in self.db["indexes"] if not n.startswith("sqlite_"))
            if args:
                names = [n for n in names if self.db["indexes"][n].get("table") == args[0]]
            if names:
                self.out(" ".join(names))
        elif c == "schema":
            pattern = args[0] if args else None
            items = []
            for n, t in sorted(self.db["tables"].items()):
                items.append((n, t.get("sql") or ("CREATE TABLE " + n + "(" + ",".join(t["columns"]) + ")")))
            for n, idx in sorted(self.db["indexes"].items()):
                items.append((n, idx.get("sql", "")))
            if pattern:
                rx = "^" + re.escape(pattern).replace("\\*", ".*").replace("%", ".*") + "$"
                items = [(n, s) for n, s in items if re.match(rx, n)]
            for _, s in items:
                if s:
                    self.out(s.rstrip(";") + ";")
        elif c == "dump":
            self.out("PRAGMA foreign_keys=OFF;")
            self.out("BEGIN TRANSACTION;")
            for n, t in sorted(self.db["tables"].items()):
                self.out((t.get("sql") or ("CREATE TABLE " + n + "(" + ",".join(t["columns"]) + ")")).rstrip(";") + ";")
                cols = t["columns"]
                for r in t["rows"]:
                    vals = ",".join(quote_sql(r.get(c)) for c in cols)
                    self.out(f"INSERT INTO {quote_sql(n) if ' ' in n else n} VALUES({vals});")
            self.out("COMMIT;")
        elif c in ("backup", "save"):
            if not args:
                self.print_error("Error: missing FILENAME")
                return 1
            target = args[-1]
            with open(target, "w") as f:
                json.dump(self.db, f)
        elif c == "restore":
            if not args:
                self.print_error("Error: missing FILENAME")
                return 1
            with open(args[-1], "r") as f:
                self.db = json.load(f)
        elif c == "import":
            if len(args) < 2:
                self.print_error("Error: usage: .import FILE TABLE")
                return 1
            return self.import_file(args[0], args[1])
        else:
            self.print_error(f"Error: unknown command or invalid arguments:  \"{line}\". Enter \".help\" for help")
            return 1
        return 0

    def import_file(self, filename, table):
        with open(filename, newline="") as f:
            if self.mode == "csv":
                reader = csv.reader(f)
            else:
                reader = (line.rstrip("\n").split(self.separator) for line in f)
            rows = list(reader)
        if not rows:
            return 0
        n = len(rows[0])
        cols = ",".join(f'"c{i}"' for i in range(1, n + 1))
        if table not in self.db["tables"]:
            self.db["tables"][table] = {"columns": [f"c{i}" for i in range(1, n + 1)], "rows": [], "sql": f"CREATE TABLE {table}({cols})"}
        cols2 = self.db["tables"][table]["columns"]
        for vals in rows:
            self.db["tables"][table]["rows"].append({c: (vals[i] if i < len(vals) else None) for i, c in enumerate(cols2)})
        self.save_db()
        return 0


def parse_args(argv):
    opts = {
        "commands": [],
        "dbname": ":memory:",
        "sql": None,
        "mode": None,
        "headers": None,
        "separator": None,
        "newline": None,
        "nullvalue": None,
        "echo": False,
        "bail": False,
        "readonly": False,
        "ifexists": False,
        "noinit": False,
    }
    i = 0
    positional = []
    while i < len(argv):
        a = argv[i]
        if a == "--":
            positional.extend(argv[i+1:])
            break
        if a in ("-help", "--help"):
            print(HELP)
            raise SystemExit(0)
        if a in ("-version", "--version"):
            print(VERSION)
            raise SystemExit(0)
        if a == "-cmd":
            i += 1
            opts["commands"].append(argv[i])
        elif a in ("-csv", "-list", "-line", "-column", "-quote", "-json", "-html", "-table", "-box", "-markdown", "-ascii", "-tabs"):
            opts["mode"] = a[1:]
        elif a in ("-header", "-headers"):
            opts["headers"] = True
        elif a in ("-noheader", "-noheaders"):
            opts["headers"] = False
        elif a == "-separator":
            i += 1
            opts["separator"] = unescape_arg(argv[i])
        elif a == "-newline":
            i += 1
            opts["newline"] = unescape_arg(argv[i])
        elif a == "-nullvalue":
            i += 1
            opts["nullvalue"] = argv[i]
        elif a == "-echo":
            opts["echo"] = True
        elif a == "-bail":
            opts["bail"] = True
        elif a == "-readonly":
            opts["readonly"] = True
        elif a == "-ifexists":
            opts["ifexists"] = True
        elif a == "-batch" or a == "-interactive" or a == "-noinit" or a == "-safe" or a == "-unsafe-testing" or a == "-deserialize" or a == "-append" or a == "-nofollow" or a == "-zip":
            pass
        elif a in ("-init", "-vfs", "-mmap", "-maxsize", "-screenwidth", "-escape", "-nonce"):
            i += 1
        elif a in ("-lookaside", "-pagecache"):
            i += 2
        elif a.startswith("-"):
            print(f"./executable: Error: unknown option: {a}", file=sys.stderr)
            print("Use -help for a list of options.", file=sys.stderr)
            raise SystemExit(1)
        else:
            positional.append(a)
        i += 1
    if positional:
        opts["dbname"] = positional[0]
        if len(positional) > 1:
            opts["sql"] = " ".join(positional[1:])
    return opts


def main(argv):
    try:
        opts = parse_args(argv)
        if opts["ifexists"] and opts["dbname"] != ":memory:" and not os.path.exists(opts["dbname"]):
            print(f"Error: database does not exist: {opts['dbname']}", file=sys.stderr)
            return 1
        sh = Shell(opts["dbname"], opts["readonly"])
        if opts["mode"]:
            sh.set_mode(opts["mode"])
        if opts["headers"] is not None:
            sh.headers = opts["headers"]
        if opts["separator"] is not None:
            sh.separator = opts["separator"]
        if opts["newline"] is not None:
            sh.rowsep = opts["newline"]
        if opts["nullvalue"] is not None:
            sh.nullvalue = opts["nullvalue"]
        sh.echo = opts["echo"]
        sh.bail = opts["bail"]
        rc = 0
        for cmd in opts["commands"]:
            rc = max(rc, sh.execute_script(cmd + ("\n" if not cmd.endswith("\n") else ""), "command-line"))
            if rc and sh.bail:
                return rc
        if opts["sql"] is not None:
            return max(rc, sh.execute_sql(opts["sql"], "command-line"))
        data = sys.stdin.read()
        if data:
            rc = max(rc, sh.execute_script(data))
        return rc
    except SystemExit as e:
        return int(e.code or 0)
    except Exception as e:
        print(f"Error: {e}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
