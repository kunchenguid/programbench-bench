#!/usr/bin/env python3
import base64, hashlib, json, os, shlex, subprocess, sys, zlib
from pathlib import Path

VERSION = "2.37.1"
SHELLS = ["json", "murex", "tcsh", "systemd", "bash", "fish", "gzenv", "vim", "zsh", "pwsh", "elvish", "gha"]


def self_path():
    try:
        return str(Path(sys.argv[0]).resolve())
    except Exception:
        return sys.argv[0]


def color(msg, red=False):
    return ("\033[31m" if red else "\033[0m") + msg + ("\033[0m" if red else "")


def log(msg, err=False):
    sys.stderr.write(color("direnv: " + msg + "\n", red=err))


def die(msg, code=1):
    log("error " + msg, True)
    sys.exit(code)


def xdg_config():
    return Path(os.environ.get("DIRENV_CONFIG") or os.environ.get("XDG_CONFIG_HOME", str(Path.home()/".config"))) / "direnv"


def xdg_data():
    return Path(os.environ.get("XDG_DATA_HOME", str(Path.home()/".local/share"))) / "direnv"


def xdg_cache():
    return Path(os.environ.get("XDG_CACHE_HOME", str(Path.home()/".cache"))) / "direnv"


def file_hash(p):
    h = hashlib.sha256()
    with open(p, 'rb') as f:
        for b in iter(lambda: f.read(65536), b''):
            h.update(b)
    return h.hexdigest()


def key_for(p):
    return hashlib.sha256(str(Path(p).resolve()).encode()).hexdigest()


def allow_dir():
    return xdg_data()/"allow"


def resolve_rc_arg(arg=None, search=True):
    if arg:
        p = Path(arg)
        if not p.is_absolute():
            p = Path.cwd()/p
        # Match direnv's slightly surprising lstat of first existing-ish prefix loosely.
        if p.is_dir():
            for name in (".envrc", ".env"):
                c = p/name
                if c.exists():
                    return c.resolve()
            return (p/".envrc").resolve()
        if p.exists():
            return p.resolve()
        # If a directory path was intended but doesn't exist, surface the parent-ish path.
        die(f"lstat {p}: no such file or directory")
    if search:
        d = Path.cwd().resolve()
        while True:
            for name in (".envrc", ".env"):
                c = d/name
                if c.exists():
                    return c
            if d.parent == d:
                return None
            d = d.parent
    return None


def is_allowed(rc):
    if not rc:
        return False
    f = allow_dir()/key_for(rc)
    try:
        return f.read_text().strip() == file_hash(rc)
    except Exception:
        return False


def set_allowed(rc, val=True):
    allow_dir().mkdir(parents=True, exist_ok=True)
    f = allow_dir()/key_for(rc)
    if val:
        f.write_text(file_hash(rc) + "\n")
    else:
        try:
            f.unlink()
        except FileNotFoundError:
            pass


def shell_quote_bash(v):
    # $'...' quoting close to direnv's bash emitter.
    s = v.replace('\\', '\\\\').replace("'", "\\'").replace('\n', '\\n').replace('\r', '\\r').replace('\t', '\\t')
    return "$'" + s + "'"


def emit_exports(shell, before, after):
    ignored = {"DIRENV_IN_ENVRC"}
    added_changed = {k: v for k, v in after.items() if k not in ignored and before.get(k) != v}
    removed = [k for k in before if k not in after and k not in ignored]
    if shell == "json":
        if not added_changed and not removed:
            return ""
        return json.dumps({"export": added_changed, "unset": removed}, sort_keys=True) + "\n"
    if shell in ("bash", "zsh"):
        out = []
        for k in sorted(removed):
            out.append(f"unset {k};")
        for k in sorted(added_changed):
            out.append(f"export {k}={shell_quote_bash(added_changed[k])};")
        return "".join(out)
    if shell == "fish":
        out = []
        for k in sorted(removed):
            out.append(f"set -e {k};")
        for k in sorted(added_changed):
            out.append(f"set -gx {k} {shlex.quote(added_changed[k])};")
        return "\n".join(out) + ("\n" if out else "")
    if shell == "tcsh":
        out = []
        for k in sorted(removed): out.append(f"unsetenv {k};")
        for k in sorted(added_changed): out.append(f"setenv {k} {shlex.quote(added_changed[k])};")
        return "".join(out)
    if shell == "gha":
        path = os.environ.get("GITHUB_ENV")
        lines = []
        for k, v in sorted(added_changed.items()):
            lines.append(f"{k}={v}")
        text = "\n".join(lines) + ("\n" if lines else "")
        if path and text:
            Path(path).open("a").write(text)
            return ""
        return text
    if shell == "systemd":
        return "\n".join(f"{k}={v}" for k, v in sorted(added_changed.items())) + ("\n" if added_changed else "")
    # vim, pwsh, elvish, murex, gzenv: useful generic key=value output.
    return "\n".join(f"{k}={shlex.quote(v)}" for k, v in sorted(added_changed.items())) + ("\n" if added_changed else "")


STDLIB = r'''
# Minimal direnv-compatible stdlib for the cleanroom reimplementation.
: "${DIRENV_CONFIG:=${XDG_CONFIG_HOME:-$HOME/.config}/direnv}"
export DIRENV_IN_ENVRC=1
has() { type "$1" >/dev/null 2>&1; }
expand_path() { local p="$1" base="${2:-$PWD}"; [[ "$p" = /* ]] || p="$base/$p"; (cd "$(dirname "$p")" 2>/dev/null && printf '%s/%s\n' "$PWD" "$(basename "$p")"); }
user_rel_path() { case "$1" in "$HOME"/*) printf '~/%s\n' "${1#$HOME/}";; "$HOME") printf '~\n';; *) printf '%s\n' "$1";; esac; }
find_up() { local name="$1" d="$PWD"; while :; do [[ -e "$d/$name" ]] && { printf '%s\n' "$d/$name"; return 0; }; [[ "$d" = / ]] && return 1; d="$(dirname "$d")"; done; }
dotenv() { local f="${1:-.env}"; [[ -f "$f" ]] || return 1; set -a; source "$f"; set +a; }
dotenv_if_exists() { local f="${1:-.env}"; [[ -f "$f" ]] && dotenv "$f" || true; }
source_env() { local f="$1"; [[ -d "$f" ]] && f="$f/.envrc"; source "$f"; }
source_env_if_exists() { [[ -f "$1" ]] && source "$1" || true; }
source_up() { local f="${1:-.envrc}" found; found="$(find_up "$f")" || return 1; source "$found"; }
source_up_if_exists() { source_up "${1:-.envrc}" || true; }
env_vars_required() { local r=0 v; for v in "$@"; do [[ -n "${!v:-}" ]] || { echo "direnv: error $v is required" >&2; r=1; }; done; return $r; }
path_add() { local var="$1" p; p="$(expand_path "$2")" || return 1; eval "export $var=\"$p\${$var:+:\${$var}}\""; }
PATH_add() { path_add PATH "$1"; }
MANPATH_add() { path_add MANPATH "$1"; }
PATH_rm() { local IFS=: out=() e pat keep; for e in $PATH; do keep=1; for pat in "$@"; do [[ "$e" == $pat ]] && keep=0; done; [[ $keep = 1 ]] && out+=("$e"); done; PATH=$(IFS=:; echo "${out[*]}"); export PATH; }
load_prefix() { local p; p="$(expand_path "$1")"; PATH_add "$p/bin"; path_add CPATH "$p/include"; path_add LD_LIBRARY_PATH "$p/lib"; path_add LIBRARY_PATH "$p/lib"; MANPATH_add "$p/share/man"; path_add PKG_CONFIG_PATH "$p/lib/pkgconfig"; }
direnv_layout_dir() { local h; h=$(printf '%s' "$PWD" | sha1sum | cut -d' ' -f1); printf '%s\n' "$PWD/.direnv"; mkdir -p "$PWD/.direnv" >/dev/null 2>&1 || true; }
layout() { local t="$1"; shift || true; case "$t" in node) PATH_add node_modules/.bin;; go) export GOPATH="$(direnv_layout_dir)/go"; PATH_add bin;; julia) export JULIA_PROJECT="$PWD";; php) PATH_add vendor/bin;; python|python3) local py="${1:-python}"; [[ "$t" = python3 ]] && py=python3; local vdir="$PWD/.direnv/python"; export VIRTUAL_ENV="$vdir"; PATH_add "$vdir/bin";; ruby) export GEM_HOME="$PWD/.direnv/ruby"; PATH_add "$GEM_HOME/bin";; *) type "layout_$t" >/dev/null 2>&1 && "layout_$t" "$@" || return 1;; esac; }
use() { local t="$1"; shift || true; type "use_$t" >/dev/null 2>&1 && "use_$t" "$@"; }
watch_file() { :; }
watch_dir() { :; }
strict_env() { set -euo pipefail; [[ $# -gt 0 ]] && "$@"; }
unstrict_env() { set +e +u +o pipefail; [[ $# -gt 0 ]] && "$@"; }
direnv_version() { direnv version "$1"; }
fetchurl() { direnv fetchurl "$@"; }
source_url() { local p; p=$(fetchurl "$1" "$2") || return 1; source "$p"; }
on_git_branch() { git rev-parse --abbrev-ref HEAD >/tmp/.direnv-branch 2>/dev/null || return 1; local b; b=$(cat /tmp/.direnv-branch); [[ $# -eq 0 || "$b" = "$1" ]]; }
if [[ -f "${DIRENV_CONFIG}/direnvrc" ]]; then source "${DIRENV_CONFIG}/direnvrc"; fi
for f in "${DIRENV_CONFIG}"/lib/*.sh; do [[ -e "$f" ]] && source "$f"; done
'''


def eval_env(rc):
    before = dict(os.environ)
    env = dict(os.environ)
    env["DIRENV_FILE"] = str(rc)
    env["DIRENV_DIR"] = "-" + str(rc.parent)
    env["DIRENV_WATCHES"] = ""
    # .env files are key/value shell fragments; .envrc gets stdlib too.
    script = "set -a\n" if rc.name == ".env" else ""
    script += STDLIB + "\n"
    script += f"cd {shlex.quote(str(rc.parent))}\nsource {shlex.quote(str(rc))}\npython3 - <<'PYDUMP'\nimport os, json\nprint('@@DIRENV_ENV@@'+json.dumps(dict(os.environ), sort_keys=True))\nPYDUMP\n"
    p = subprocess.run(["/usr/bin/bash", "-c", script], text=True, capture_output=True, env=env)
    # Preserve user output, but remove our sentinel line from stdout.
    after = None
    for line in p.stdout.splitlines(True):
        if line.startswith("@@DIRENV_ENV@@"):
            after = json.loads(line[len("@@DIRENV_ENV@@"):])
        else:
            sys.stderr.write(line)
    if p.stderr:
        sys.stderr.write(p.stderr)
    if p.returncode != 0 or after is None:
        return before, before, p.returncode or 1
    for k in ("_", "SHLVL", "PWD", "OLDPWD"):
        if k in before and k in after and before[k] != after[k]:
            after[k] = before[k]
    after["DIRENV_FILE"] = str(rc)
    after["DIRENV_DIR"] = "-" + str(rc.parent)
    return before, after, 0


def cmd_help():
    order = ["json", "murex", "tcsh", "systemd", "bash", "fish", "gzenv", "vim", "zsh", "pwsh", "elvish", "gha"]
    print(f"direnv v{VERSION}\nUsage: direnv COMMAND [...ARGS]\n\nAvailable commands\n------------------")
    print("allow [PATH_TO_RC]:\n  aliases: permit, grant\n  Grants direnv permission to load the given .envrc or .env file.")
    print("block [PATH_TO_RC]:\n  aliases: deny, disallow, revoke\n  Revokes the authorization of a given .envrc or .env file.")
    print("edit [PATH_TO_RC]:\n  Opens PATH_TO_RC or the current .envrc or .env into an $EDITOR and allow\n  the file to be loaded afterwards.")
    print("exec DIR COMMAND [...ARGS]:\n  Executes a command after loading the first .envrc or .env found in DIR")
    print("export SHELL:\n  Loads an .envrc or .env and prints the diff in terms of exports.\n  Supported SHELL values are: [" + ", ".join(order) + "]")
    print("fetchurl <url> [<integrity-hash>]:\n  Fetches a given URL into direnv's CAS")
    print("help [SHOW_PRIVATE]:\n  Shows this help")
    print("hook SHELL:\n  Used to setup the shell hook")
    print("prune:\n  Removes old allowed and required files")
    print("reload:\n  Triggers an env reload")
    print("status [--json]:\n  Prints some debug status information")
    print("stdlib:\n  Displays the stdlib available in the .envrc execution context")
    print("version [VERSION_AT_LEAST]:\n  prints the version or checks that direnv is older than VERSION_AT_LEAST.")
    print("log [--status | --error] <message>:\n  Logs a given message")


def cmd_private_help():
    cmd_help()
    print("*apply_dump FILE:\n  Accepts a filename containing `direnv dump` output and generates a series of bash export statements to apply the given env")
    print("*show_dump DUMP:\n  Show the data inside of a dump for debugging purposes")
    print("*dump [SHELL] [FILE]:")
    print("*watch SHELL PATH...:\n  Adds a path to the list that direnv watches for changes")
    print("*watch-dir SHELL DIR:\n  Recursively adds a directory to the list that direnv watches for changes")
    print("*watch-list [SHELL]:\n  Pipe pairs of `mtime path` to stdin to build a list of files to watch.")
    print("*watch-print [--null]:\n  prints the watched paths")


def cmd_hook(shell):
    if not shell or shell not in ["bash","zsh","fish","tcsh","pwsh","elvish","murex"]:
        die(f"unknown target shell '{shell}'")
    sp = self_path()
    if shell == "bash":
        print(f'''
_direnv_hook() {{
  local previous_exit_status=$?;
  vars="$({shlex.quote(sp)} export bash)";
  trap -- '' SIGINT;
  eval "$vars";
  trap - SIGINT;
  return $previous_exit_status;
}};
if [[ ";${{PROMPT_COMMAND[*]:-}};" != *";_direnv_hook;"* ]]; then
  if [[ "$(declare -p PROMPT_COMMAND 2>&1)" == "declare -a"* ]]; then
    PROMPT_COMMAND=(_direnv_hook "${{PROMPT_COMMAND[@]}}")
  else
    PROMPT_COMMAND="_direnv_hook${{PROMPT_COMMAND:+;$PROMPT_COMMAND}}"
  fi
fi''')
    elif shell == "zsh":
        print(f'''
_direnv_hook() {{
  vars="$({shlex.quote(sp)} export zsh)"
  trap -- '' SIGINT
  eval "$vars"
  trap - SIGINT
}}
typeset -ag precmd_functions
if (( ! ${{precmd_functions[(I)_direnv_hook]}} )); then
  precmd_functions=(_direnv_hook $precmd_functions)
fi
typeset -ag chpwd_functions
if (( ! ${{chpwd_functions[(I)_direnv_hook]}} )); then
  chpwd_functions=(_direnv_hook $chpwd_functions)
fi''')
    elif shell == "fish":
        print(f'''
    function __direnv_export_eval --on-event fish_prompt;
        "{sp}" export fish | source;
    end;''')
    elif shell == "tcsh":
        print(f"alias precmd 'eval `{sp} export tcsh`'", end="")
    elif shell == "pwsh":
        print(f"$ExecutionContext.SessionState.InvokeCommand.LocationChangedAction = {{ Invoke-Expression (({sp} export pwsh) -join [Environment]::NewLine) }};")
    else:
        print(f"# direnv hook for {shell}\n{sp} export {shell}")


def version_tuple(v):
    v = v.lstrip('v')
    return tuple(int(x) for x in (v.split('.') + ['0','0'])[:3] if x.isdigit())


def cmd_export(shell):
    if shell not in SHELLS:
        die(f"unknown target shell '{shell}'")
    rc = resolve_rc_arg(None)
    if not rc:
        return
    before = dict(os.environ)
    if not is_allowed(rc):
        log(f"error {rc} is blocked. Run `direnv allow` to approve its content", True)
        after = before.copy(); after["DIRENV_FILE"] = str(rc); after["DIRENV_DIR"] = "-" + str(rc.parent)
        sys.stdout.write(emit_exports(shell, before, after))
        return
    log(f"loading {rc}")
    before, after, code = eval_env(rc)
    if code != 0:
        sys.exit(code)
    changed = [k for k in after if before.get(k) != after.get(k) and not k.startswith("DIRENV_")]
    if changed:
        log("export " + " ".join("+"+k for k in sorted(changed)))
    sys.stdout.write(emit_exports(shell, before, after))


def cmd_allow(arg=None):
    rc = resolve_rc_arg(arg)
    if not rc or not rc.exists():
        die("no .envrc or .env file found")
    set_allowed(rc, True)
    log("loading " + str(rc))


def cmd_block(arg=None):
    rc = resolve_rc_arg(arg)
    if not rc or not rc.exists():
        die("no .envrc or .env file found")
    set_allowed(rc, False)


def cmd_status(json_mode=False):
    rc = resolve_rc_arg(None)
    if json_mode:
        print(json.dumps({"config":{"ConfigDir":str(xdg_config()),"SelfPath":self_path()},"state":{"foundRC":str(rc) if rc else None,"loadedRC":None}}, indent=2))
    else:
        print("direnv exec path " + self_path())
        print("DIRENV_CONFIG " + str(xdg_config()))
        print("bash_path /usr/bin/bash")
        print("disable_stdin false")
        print("warn_timeout 5s")
        print("whitelist.prefix []")
        print("whitelist.exact map[]")
        print("No .envrc or .env loaded")
        print(("Found RC " + str(rc)) if rc else "No .envrc or .env found")


def cmd_fetchurl(args):
    if not args: die("missing URL argument")
    die("fetchurl is unavailable in this network-disabled build")


def encode_dump(env):
    raw = json.dumps(env, sort_keys=True, separators=(",", ":")).encode()
    return base64.urlsafe_b64encode(zlib.compress(raw)).decode()


def decode_dump(s):
    return json.loads(zlib.decompress(base64.urlsafe_b64decode(s.encode())).decode())


def cmd_exec(args):
    if len(args) < 2: die("not enough arguments")
    d = Path(args[0]).resolve()
    old = Path.cwd(); os.chdir(d)
    rc = resolve_rc_arg(None)
    env = dict(os.environ)
    if rc and is_allowed(rc):
        before, after, code = eval_env(rc)
        if code != 0: sys.exit(code)
        env.update(after)
    os.chdir(old)
    p = subprocess.run(args[1:], env=env)
    sys.exit(p.returncode)


def main():
    args = sys.argv[1:]
    if not args or args[0] in ("help", "--help", "-h"):
        if args[:2] == ["help", "true"]:
            cmd_private_help()
        else:
            cmd_help()
        return
    cmd = args[0]; rest = args[1:]
    aliases = {"permit":"allow","grant":"allow","deny":"block","disallow":"block","revoke":"block"}
    cmd = aliases.get(cmd, cmd)
    if cmd == "version":
        if rest:
            if version_tuple(VERSION) < version_tuple(rest[0]):
                die(f"current version v{VERSION} is older than the desired version v{rest[0].lstrip('v')}")
        else: print(VERSION)
    elif cmd == "hook": cmd_hook(rest[0] if rest else "")
    elif cmd == "export": cmd_export(rest[0] if rest else "")
    elif cmd == "allow": cmd_allow(rest[0] if rest else None)
    elif cmd == "block": cmd_block(rest[0] if rest else None)
    elif cmd == "status": cmd_status(bool(rest and rest[0] == "--json"))
    elif cmd == "stdlib": print("#!/usr/bin/env bash\n" + STDLIB)
    elif cmd == "prune": pass
    elif cmd == "reload": print("export DIRENV_DIFF=$'reload';")
    elif cmd == "log":
        if len(rest) >= 2 and rest[0] in ("--status","--error"):
            log(" ".join(rest[1:]), err=(rest[0] == "--error"))
        else: die("invalid arguments")
    elif cmd == "fetchurl": cmd_fetchurl(rest)
    elif cmd == "exec": cmd_exec(rest)
    elif cmd == "dump":
        shell = rest[0] if rest else ""
        if shell == "json":
            print(json.dumps(dict(os.environ), indent=2, sort_keys=True))
        else:
            print(encode_dump(dict(os.environ)))
    elif cmd == "show_dump":
        if not rest:
            die("missing dump argument")
        print(json.dumps(decode_dump(rest[0]), indent=2, sort_keys=True))
    elif cmd == "apply_dump":
        if not rest:
            die("missing FILE argument")
        data = Path(rest[0]).read_text().strip()
        after = decode_dump(data)
        sys.stdout.write(emit_exports("bash", dict(os.environ), after))
    elif cmd in ("watch", "watch-dir", "watch-list"):
        pass
    elif cmd == "watch-print":
        pass
    elif cmd == "edit":
        rc = resolve_rc_arg(rest[0] if rest else None, search=True) or Path.cwd()/".envrc"
        editor = os.environ.get("EDITOR", "vi")
        subprocess.run([editor, str(rc)])
        if rc.exists(): set_allowed(rc, True)
    else:
        die(f"command \"{sys.argv[0]} {cmd}\" not found")

if __name__ == "__main__":
    main()
