#!/usr/bin/env python3
import argparse
import datetime
import json
import os
import re
import subprocess
import sys
import time


HELP = """a conventional changelog for the rest of us

Usage: executable [OPTIONS]

Options:
  -r, --repository <URL>  Repository used for generating commit and issue links (without the .git,
                          e.g. https://github.com/thoughtram/clog)
  -f, --from <COMMIT>     e.g. 12a8546
  -T, --format <STR>      The output format, defaults to markdown [default: markdown] [possible
                          values: markdown, json]
  -M, --major             Increment major version by one (Sets minor and patch to 0)
  -g, --git-dir <PATH>    Local .git directory (defaults to "$(pwd)/.git")
  -w, --work-tree <PATH>  Local working tree of the git project (defaults to "$(pwd)")
  -m, --minor             Increment minor version by one (Sets patch to 0)
  -p, --patch             Increment patch version by one
  -s, --subtitle <STR>    
  -t, --to <COMMIT>       e.g. 8057684 [default: HEAD]
  -o, --outfile <PATH>    Where to write the changelog (Defaults to stdout when omitted)
  -c, --config <COMMIT>   The Clog Configuration TOML file to use [default: .clog.toml]
  -i, --infile <PATH>     A changelog to append to, but *NOT* write to (Useful in conjunction with
                          --outfile)
      --setversion <VER>  e.g. 1.0.1
  -F, --from-latest-tag   use latest tag as start (instead of --from)
  -l, --link-style <STR>  The style of repository link to generate [default: github] [possible
                          values: github, gitlab, stash, cgit]
  -C, --changelog <PATH>  A previous changelog to prepend new changes to (this is like using the
                          same file for both --infile and --outfile and should not be used in
                          conjunction with either)
  -h, --help              Print help
  -V, --version           Print version


If your .git directory is a child of your project directory (most common, such as /myproject/.git)
AND not in the current working directory (i.e you need to use --work-tree or --git-dir) you only
need to specify either the --work-tree (i.e. /myproject) OR --git-dir (i.e. /myproject/.git), you
don't need to use both.

If using the --config to specify a clog configuration TOML file NOT in the current working directory
(meaning you need to use --work-tree or --git-dir) AND the TOML file is inside your project
directory (i.e. /myproject/.clog.toml) you do not need to use --work-tree or --git-dir.
"""


SECTION_ORDER = [
    "Breaking Changes",
    "Features",
    "Bug Fixes",
    "Performance",
    "Documentation",
    "Style Fixes",
    "Code Refactoring",
    "Tests",
    "Builds",
    "Continuous Integration",
    "Improvements",
]

TYPE_MAP = {
    "feat": "Features",
    "feature": "Features",
    "features": "Features",
    "fix": "Bug Fixes",
    "bugfix": "Bug Fixes",
    "bug": "Bug Fixes",
    "perf": "Performance",
    "performance": "Performance",
    "docs": "Documentation",
    "doc": "Documentation",
    "style": "Style Fixes",
    "refactor": "Code Refactoring",
    "test": "Tests",
    "tests": "Tests",
    "build": "Builds",
    "ci": "Continuous Integration",
    "improvement": "Improvements",
    "improvements": "Improvements",
    "improve": "Improvements",
}


class Parser(argparse.ArgumentParser):
    def error(self, message):
        sys.stderr.write(f"error: {message}\n\n")
        sys.stderr.write("Usage: executable [OPTIONS]\n\n")
        sys.stderr.write("For more information, try '--help'.\n")
        raise SystemExit(2)


def parse_args(argv):
    if "--help" in argv or "-h" in argv:
        print(HELP)
        raise SystemExit(0)
    if "--version" in argv or "-V" in argv:
        print("clog 0.10.0")
        raise SystemExit(0)
    p = Parser(add_help=False, prog="executable")
    p.add_argument("-r", "--repository")
    p.add_argument("-f", "--from", dest="from_commit")
    p.add_argument("-T", "--format", default="markdown", choices=["markdown", "json"])
    p.add_argument("-M", "--major", action="store_true")
    p.add_argument("-g", "--git-dir")
    p.add_argument("-w", "--work-tree")
    p.add_argument("-m", "--minor", action="store_true")
    p.add_argument("-p", "--patch", action="store_true")
    p.add_argument("-s", "--subtitle")
    p.add_argument("-t", "--to", dest="to_commit", default="HEAD")
    p.add_argument("-o", "--outfile")
    p.add_argument("-c", "--config", default=".clog.toml")
    p.add_argument("-i", "--infile")
    p.add_argument("--setversion")
    p.add_argument("-F", "--from-latest-tag", action="store_true")
    p.add_argument("-l", "--link-style", default="github", choices=["github", "gitlab", "stash", "cgit"])
    p.add_argument("-C", "--changelog")
    return p.parse_args(argv)


def read_config(path):
    cfg = {}
    try:
        text = open(path, encoding="utf-8").read()
    except OSError:
        return cfg
    in_clog = False
    for raw in text.splitlines():
        line = raw.split("#", 1)[0].strip()
        if not line:
            continue
        if line.startswith("[") and line.endswith("]"):
            in_clog = line.strip("[]").strip() == "clog"
            continue
        if not in_clog or "=" not in line:
            continue
        k, v = [x.strip() for x in line.split("=", 1)]
        if v.lower() in ("true", "false"):
            cfg[k] = v.lower() == "true"
        else:
            cfg[k] = v.strip('"').strip("'")
    return cfg


def run_git(args, git_args):
    cmd = ["git"]
    if args.git_dir:
        cmd += ["--git-dir", args.git_dir]
    if args.work_tree:
        cmd += ["--work-tree", args.work_tree]
    cmd += git_args
    try:
        return subprocess.check_output(cmd, stderr=subprocess.DEVNULL, text=True)
    except Exception:
        return ""


def latest_tag(args):
    return run_git(args, ["describe", "--tags", "--abbrev=0"]).strip()


def commit_link(repo, style, sha):
    if not repo:
        return sha[:8]
    repo = repo[:-4] if repo.endswith(".git") else repo
    if style == "cgit":
        return f"{repo}/commit/?id={sha}"
    if style == "stash":
        return f"{repo}/commits/{sha}"
    return f"{repo}/commit/{sha}"


def issue_link(repo, style, num):
    if not repo:
        return f"#{num}"
    repo = repo[:-4] if repo.endswith(".git") else repo
    if style == "cgit":
        return f"#{num}"
    return f"[#{num}]({repo}/issues/{num})"


def parse_commit(sha, subject, body):
    m = re.match(r"^([A-Za-z][A-Za-z0-9_-]*)(?:\(([^)]*)\))?(!)?:\s*(.+)$", subject.strip())
    entries = []
    if m:
        typ, scope, bang, msg = m.group(1).lower(), m.group(2), m.group(3), m.group(4).strip()
        section = TYPE_MAP.get(typ)
        if section:
            entries.append((section, scope, msg))
        if bang:
            entries.append(("Breaking Changes", scope, msg))
    for line in body.splitlines():
        bm = re.match(r"BREAKING(?: CHANGE| CHANGES)?:\s*(.+)", line.strip(), re.I)
        if bm:
            entries.append(("Breaking Changes", None, bm.group(1).strip()))
    return entries


def find_issues(text):
    nums = []
    for pat in [r"(?:close[sd]?|fix(?:e[sd])?|resolve[sd]?)\s+#(\d+)", r"\(#(\d+)\)"]:
        for n in re.findall(pat, text, re.I):
            if n not in nums:
                nums.append(n)
    return nums


def collect_commits(args, repo, style):
    start = args.from_commit
    if args.from_latest_tag:
        start = latest_tag(args) or start
    elif not start:
        cfg = read_config(args.config)
        if cfg.get("from-latest-tag"):
            start = latest_tag(args)
    rev = args.to_commit or "HEAD"
    if start:
        rev = f"{start}..{rev}"
    fmt = "%H%x1f%s%x1f%b%x1e"
    out = run_git(args, ["log", "--no-merges", f"--format={fmt}", rev])
    sections = {name: [] for name in SECTION_ORDER}
    for rec in out.split("\x1e"):
        rec = rec.strip("\n")
        if not rec:
            continue
        parts = rec.split("\x1f")
        if len(parts) < 3:
            continue
        sha, subject, body = parts[0], parts[1], parts[2]
        entries = parse_commit(sha, subject, body)
        issues = find_issues(subject + "\n" + body)
        for section, scope, msg in entries:
            meta = f"[{sha[:8]}]({commit_link(repo, style, sha)})" if repo else sha[:8]
            for n in issues:
                il = issue_link(repo, style, n)
                meta += f", closes {il}"
            sections.setdefault(section, []).append({"scope": scope, "msg": msg, "sha": sha, "meta": meta})
    return {k: v for k, v in sections.items() if v}


def previous_version(path):
    if not path:
        return None
    try:
        text = open(path, encoding="utf-8").read(4096)
    except OSError:
        return None
    m = re.search(r'<a name="v?([^"]+)"></a>\s*\n#+\s+v?([0-9]+\.[0-9]+\.[0-9]+)', text)
    if m:
        return m.group(2)
    m = re.search(r"^#+\s+v?([0-9]+\.[0-9]+\.[0-9]+)", text, re.M)
    return m.group(1) if m else None


def bump(ver, major=False, minor=False, patch=False):
    m = re.match(r"v?(\d+)\.(\d+)\.(\d+)$", ver or "")
    if not m:
        raise ValueError
    a, b, c = map(int, m.groups())
    prefix = "v" if ver.startswith("v") else ""
    if major:
        a, b, c = a + 1, 0, 0
    elif minor:
        b, c = b + 1, 0
    elif patch:
        c += 1
    return f"{prefix}{a}.{b}.{c}"


def choose_version(args):
    if args.setversion:
        return args.setversion
    old_path = args.infile or args.changelog
    old = previous_version(old_path)
    if args.major or args.minor or args.patch:
        try:
            return bump(old, args.major, args.minor, args.patch)
        except Exception:
            sys.stderr.write("\033[1;31merror:\033[0m Failed to parse version into valid SemVer. Ensure the version is in the X.Y.Z format.\n")
            raise SystemExit(1)
    return None


def markdown(version, subtitle, sections, patch_header):
    today = datetime.date.today().isoformat()
    lines = []
    if version:
        hashes = "###" if patch_header else "##"
        sub = subtitle or ""
        lines.append(f'<a name="{version}"></a>')
        lines.append(f"{hashes} {version} {sub} ({today})")
    elif subtitle:
        lines.append(f"## {subtitle} ({today})")
    else:
        lines.append(f"## {today}")
    lines.append("")
    for name in SECTION_ORDER:
        items = sections.get(name, [])
        if not items:
            continue
        lines.append("")
        lines.append(f"#### {name}")
        lines.append("")
        for it in items:
            if it["scope"]:
                lines.append(f"* **{it['scope']}**: {it['msg']} ({it['meta']})")
            else:
                lines.append(f"* {it['msg']} ({it['meta']})")
    lines.append("")
    lines.append("")
    return "\n".join(lines)


def jsonish(version, subtitle, sections, patch_header):
    today = datetime.date.today().isoformat()
    if not sections:
        sec = "null"
    else:
        serial = {k: [{"scope": i["scope"], "message": i["msg"], "commit": i["sha"][:8]} for i in v] for k, v in sections.items()}
        sec = json.dumps(serial, separators=(",", ":"))
    v = f'Some("{version}")' if version else "None"
    s = f'Some("{subtitle}")' if subtitle else "null"
    return f'{{"header":{{"version":{v},"patch_version":{str(bool(patch_header)).lower()},"subtitle":{s},"date":"{today}"}},"sections":{sec}}}'


def main(argv):
    started = time.time()
    args = parse_args(argv)
    cfg = read_config(args.config)
    repo = args.repository or cfg.get("repository")
    if not args.git_dir and not args.work_tree:
        args.work_tree = os.getcwd()
        args.git_dir = os.path.join(args.work_tree, ".git")
    if not repo and os.path.exists(args.config):
        repo = cfg.get("repository")
    version = choose_version(args)
    sections = collect_commits(args, repo, args.link_style)
    patch_header = bool(args.patch and not (args.major or args.minor))
    if args.format == "json":
        new_text = jsonish(version, args.subtitle, sections, patch_header)
    else:
        new_text = markdown(version, args.subtitle, sections, patch_header)
    infile = args.infile
    outfile = args.outfile
    if args.changelog:
        infile = args.changelog
        outfile = args.changelog
    if infile:
        try:
            old = open(infile, encoding="utf-8").read()
        except OSError:
            old = ""
        new_text = new_text + old
    if outfile:
        with open(outfile, "w", encoding="utf-8") as f:
            f.write(new_text)
    else:
        sys.stdout.write(new_text)
    elapsed = int((time.time() - started) * 1000)
    sys.stdout.write(f"changelog written. (took {elapsed} ms)\n")


if __name__ == "__main__":
    try:
        main(sys.argv[1:])
    except BrokenPipeError:
        pass
