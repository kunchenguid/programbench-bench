#!/usr/bin/env python3
import json, sys, re, math

VERSION = "jq-build-2b77eb1"

class JQError(Exception):
    pass

MISSING = object()

def jtype(v):
    if v is None: return "null"
    if isinstance(v, bool): return "boolean"
    if isinstance(v, (int, float)) and not isinstance(v, bool): return "number"
    if isinstance(v, str): return "string"
    if isinstance(v, list): return "array"
    if isinstance(v, dict): return "object"
    return "unknown"

def truthy(v):
    return not (v is False or v is None)

def jq_len(v):
    if v is None: return 0
    if isinstance(v, (str, list, dict)): return len(v)
    if isinstance(v, (int, float)) and not isinstance(v, bool): return abs(v)
    raise JQError("Cannot get length")

def compact(v, sort=False, ascii_only=False):
    return json.dumps(v, ensure_ascii=ascii_only, separators=(",", ":"), sort_keys=sort)

def pretty(v, indent=2, sort=False, ascii_only=False):
    return json.dumps(v, ensure_ascii=ascii_only, indent=indent, sort_keys=sort)

def jq_add(a, b):
    if a is None: return b
    if b is None: return a
    if isinstance(a, (int, float)) and isinstance(b, (int, float)) and not isinstance(a, bool) and not isinstance(b, bool): return a + b
    if isinstance(a, str) and isinstance(b, str): return a + b
    if isinstance(a, list) and isinstance(b, list): return a + b
    if isinstance(a, dict) and isinstance(b, dict):
        r = dict(a); r.update(b); return r
    raise JQError(f"{jtype(a)} and {jtype(b)} cannot be added")

def jq_cmp_key(v):
    order = {"null":0, "boolean":1, "number":2, "string":3, "array":4, "object":5}
    t = jtype(v)
    if isinstance(v, dict):
        return (order[t], sorted((k, jq_cmp_key(val)) for k, val in v.items()))
    if isinstance(v, list):
        return (order[t], [jq_cmp_key(x) for x in v])
    return (order[t], v)

def jq_contains(a, b):
    if isinstance(a, str) and isinstance(b, str): return b in a
    if isinstance(a, list):
        return all(any(jq_contains(x, y) if isinstance(x, (list, dict, str)) and isinstance(y, (list, dict, str)) else x == y for x in a) for y in b) if isinstance(b, list) else False
    if isinstance(a, dict) and isinstance(b, dict):
        return all(k in a and (jq_contains(a[k], v) if isinstance(a[k], (list, dict, str)) and isinstance(v, (list, dict, str)) else a[k] == v) for k, v in b.items())
    return a == b

def flatten(v, depth=None):
    out = []
    for x in v:
        if isinstance(x, list) and (depth is None or depth > 0):
            out += flatten(x, None if depth is None else depth - 1)
        else:
            out.append(x)
    return out

TOKEN_RE = re.compile(r'''
    \s*(?:
      (?P<num>-?(?:0|[1-9][0-9]*)(?:\.[0-9]+)?(?:[eE][+-]?[0-9]+)?)
    | (?P<str>"(?:\\.|[^"\\])*")
    | (?P<var>\$[A-Za-z_][A-Za-z0-9_]*)
    | (?P<op>==|!=|<=|>=|//|\|=|\+=|-=|\*=|/=|%=|\.\.|[.\[\]{}(),:|+\-*/%<>?;])
    | (?P<id>[A-Za-z_][A-Za-z0-9_]*)
    | (?P<bad>.)
    )''', re.X | re.S)

def tokenize(s):
    out = []
    pos = 0
    while pos < len(s):
        m = TOKEN_RE.match(s, pos)
        if not m: break
        pos = m.end()
        if m.group("bad"):
            raise JQError("syntax error")
        typ = m.lastgroup
        val = m.group(typ)
        if typ == "num":
            out.append(("num", float(val) if any(c in val for c in ".eE") else int(val)))
        elif typ == "str":
            out.append(("str", json.loads(val)))
        elif typ == "id":
            out.append((val, val))
        elif typ == "var":
            out.append(("var", val[1:]))
        elif typ == "op":
            out.append((val, val))
    out.append(("EOF", None))
    return out

def is_name(tok):
    return bool(re.match(r"[A-Za-z_]", tok or "")) and tok not in (
        "EOF", "then", "else", "end", "true", "false", "null", "and", "or"
    )

class Parser:
    def __init__(self, text):
        self.toks = tokenize(strip_comments(text))
        self.i = 0
    def peek(self): return self.toks[self.i][0]
    def val(self): return self.toks[self.i][1]
    def take(self, t=None):
        if t and self.peek() != t:
            raise JQError(f"expected {t}")
        x = self.toks[self.i]; self.i += 1; return x
    def parse(self):
        if self.peek() == "EOF": return ("id",)
        node = self.expr()
        return node
    def expr(self): return self.comma()
    def comma(self):
        n = self.pipe()
        while self.peek() == ",":
            self.take(","); n = ("comma", n, self.pipe())
        return n
    def pipe(self):
        n = self.logic_or()
        if self.peek() == "as":
            self.take("as")
            if self.peek() != "var":
                raise JQError("expected variable")
            var = self.take("var")[1]
            self.take("|")
            return ("as", n, var, self.pipe())
        while self.peek() == "|":
            self.take("|"); n = ("pipe", n, self.logic_or())
        return n
    def logic_or(self):
        n = self.logic_and()
        while self.peek() == "or":
            self.take("or"); n = ("bin", "or", n, self.logic_and())
        return n
    def logic_and(self):
        n = self.alt()
        while self.peek() == "and":
            self.take("and"); n = ("bin", "and", n, self.alt())
        return n
    def alt(self):
        n = self.compare()
        while self.peek() == "//":
            self.take("//"); n = ("bin", "//", n, self.compare())
        return n
    def compare(self):
        n = self.add()
        while self.peek() in ("==","!=","<",">","<=",">="):
            op = self.take()[0]; n = ("bin", op, n, self.add())
        return n
    def add(self):
        n = self.mul()
        while self.peek() in ("+","-"):
            op = self.take()[0]; n = ("bin", op, n, self.mul())
        return n
    def mul(self):
        n = self.unary()
        while self.peek() in ("*","/","%"):
            op = self.take()[0]; n = ("bin", op, n, self.unary())
        return n
    def unary(self):
        if self.peek() == "-":
            self.take("-"); return ("neg", self.unary())
        if self.peek() == "not":
            self.take("not"); return ("not", self.unary())
        return self.postfix(self.primary())
    def primary(self):
        p = self.peek()
        if p == ".":
            self.take(".")
            n = ("id",)
            if self.peek() == "str":
                n = ("index", n, ("lit", self.take("str")[1]), False)
            elif is_name(self.peek()):
                n = ("index", n, ("lit", self.take()[0]), False)
            elif self.peek() == "[":
                n = self.bracket(n)
            return n
        if p == "..":
            self.take("..")
            return ("recurse",)
        if p == "num":
            return ("lit", self.take("num")[1])
        if p == "str":
            return ("lit", self.take("str")[1])
        if p in ("true","false","null"):
            self.take(); return ("lit", {"true":True,"false":False,"null":None}[p])
        if p == "var":
            return ("var", self.take("var")[1])
        if p == "[":
            return self.array()
        if p == "{":
            return self.obj()
        if p == "(":
            self.take("("); n = self.expr(); self.take(")"); return n
        if p == "if":
            return self.ifexpr()
        if is_name(p):
            name = self.take()[0]
            if self.peek() == "(":
                self.take("(")
                args = []
                if self.peek() != ")":
                    args.append(self.expr())
                    while self.peek() == ";":
                        self.take(";"); args.append(self.expr())
                self.take(")")
                return ("call", name, args)
            return ("call", name, [])
        raise JQError("syntax error")
    def postfix(self, n):
        while True:
            if self.peek() == ".":
                self.take(".")
                if self.peek() in ("EOF", "|", ",", ")", "]", "}", ";", "then", "else", "end"):
                    n = ("pipe", n, ("id",))
                elif self.peek() == "str":
                    n = ("index", n, ("lit", self.take("str")[1]), False)
                elif is_name(self.peek()):
                    n = ("index", n, ("lit", self.take()[0]), False)
                elif self.peek() == "[":
                    n = self.bracket(n)
                else:
                    raise JQError("syntax error")
                if self.peek() == "?":
                    self.take("?"); n = ("optional", n)
            elif self.peek() == "[":
                n = self.bracket(n)
                if self.peek() == "?":
                    self.take("?"); n = ("optional", n)
            elif self.peek() == "?":
                self.take("?"); n = ("optional", n)
            else:
                break
        return n
    def bracket(self, base):
        self.take("[")
        if self.peek() == "]":
            self.take("]"); return ("iter", base)
        if self.peek() == ":":
            self.take(":")
            end = None if self.peek() == "]" else self.expr()
            self.take("]"); return ("slice", base, None, end)
        first = self.expr()
        if self.peek() == ":":
            self.take(":")
            end = None if self.peek() == "]" else self.expr()
            self.take("]"); return ("slice", base, first, end)
        self.take("]"); return ("index", base, first, False)
    def array(self):
        self.take("[")
        if self.peek() == "]":
            self.take("]"); return ("lit", [])
        e = self.expr(); self.take("]")
        return ("array", e)
    def obj(self):
        self.take("{")
        pairs = []
        if self.peek() != "}":
            while True:
                if self.peek() == "str":
                    key = self.take("str")[1]
                elif is_name(self.peek()):
                    key = self.take()[0]
                else:
                    raise JQError("object key")
                if self.peek() == ":":
                    self.take(":"); val = self.pipe()
                else:
                    val = ("index", ("id",), ("lit", key), True)
                pairs.append((key, val))
                if self.peek() != ",": break
                self.take(",")
        self.take("}")
        return ("obj", pairs)
    def ifexpr(self):
        self.take("if"); cond = self.expr(); self.take("then")
        a = self.expr(); self.take("else"); b = self.expr(); self.take("end")
        return ("if", cond, a, b)

def strip_comments(s):
    lines = []
    for line in s.splitlines():
        in_s = False; esc = False; out = []
        for ch in line:
            if in_s:
                out.append(ch)
                if esc: esc = False
                elif ch == "\\": esc = True
                elif ch == '"': in_s = False
            else:
                if ch == '"': in_s = True; out.append(ch)
                elif ch == "#": break
                else: out.append(ch)
        lines.append("".join(out))
    return "\n".join(lines)

def eval_node(n, inp, env):
    k = n[0]
    if k == "id": return [inp]
    if k == "lit": return [n[1]]
    if k == "var": return [env.get(n[1], None)]
    if k == "comma": return eval_node(n[1], inp, env) + eval_node(n[2], inp, env)
    if k == "pipe":
        out = []
        for v in eval_node(n[1], inp, env):
            out += eval_node(n[2], v, env)
        return out
    if k == "as":
        out = []
        for v in eval_node(n[1], inp, env):
            e2 = dict(env); e2[n[2]] = v
            out += eval_node(n[3], inp, e2)
        return out
    if k == "recurse":
        out = []
        def rec(v):
            out.append(v)
            if isinstance(v, list):
                for x in v: rec(x)
            elif isinstance(v, dict):
                for x in v.values(): rec(x)
        rec(inp)
        return out
    if k == "array":
        return [eval_node(n[1], inp, env)]
    if k == "obj":
        obj = {}
        for key, expr in n[1]:
            vals = eval_node(expr, inp, env)
            obj[key] = vals[-1] if vals else None
        return [obj]
    if k == "index":
        vals = eval_node(n[1], inp, env); outs = []
        idxs = eval_node(n[2], inp, env)
        idx = idxs[-1] if idxs else None
        for v in vals:
            try: outs.append(do_index(v, idx, n[3]))
            except Exception:
                if not n[3]: raise
        return outs
    if k == "iter":
        outs = []
        for v in eval_node(n[1], inp, env):
            if isinstance(v, list): outs += v
            elif isinstance(v, dict): outs += list(v.values())
            elif v is None: pass
            else: raise JQError(f"Cannot iterate over {jtype(v)}")
        return outs
    if k == "slice":
        vals = eval_node(n[1], inp, env)
        s = None if n[2] is None else int((eval_node(n[2], inp, env) or [None])[-1] or 0)
        e = None if n[3] is None else int((eval_node(n[3], inp, env) or [None])[-1] or 0)
        return [v[s:e] if isinstance(v, (list, str)) else None for v in vals]
    if k == "optional":
        try: return eval_node(n[1], inp, env)
        except Exception: return []
    if k == "neg":
        return [-v for v in eval_node(n[1], inp, env)]
    if k == "not":
        return [not truthy(v) for v in eval_node(n[1], inp, env)]
    if k == "bin":
        return eval_bin(n[1], n[2], n[3], inp, env)
    if k == "call":
        return call(n[1], n[2], inp, env)
    if k == "if":
        conds = eval_node(n[1], inp, env)
        c = conds[-1] if conds else False
        return eval_node(n[2] if truthy(c) else n[3], inp, env)
    raise JQError("bad ast")

def do_index(v, idx, quiet=False):
    if isinstance(v, dict):
        return v.get(str(idx), None)
    if isinstance(v, list):
        if not isinstance(idx, int): return None
        if idx < 0: idx += len(v)
        return v[idx] if 0 <= idx < len(v) else None
    if isinstance(v, str) and isinstance(idx, int):
        if idx < 0: idx += len(v)
        return v[idx] if 0 <= idx < len(v) else None
    if v is None:
        return None
    if quiet:
        return None
    raise JQError(f"Cannot index {jtype(v)}")

def eval_bin(op, a, b, inp, env):
    if op == "and":
        return [truthy(x) and truthy(y) for x in eval_node(a, inp, env) for y in eval_node(b, inp, env)]
    if op == "or":
        return [truthy(x) or truthy(y) for x in eval_node(a, inp, env) for y in eval_node(b, inp, env)]
    if op == "//":
        av = eval_node(a, inp, env)
        good = [x for x in av if x is not None and x is not False]
        return good if good else eval_node(b, inp, env)
    out = []
    for x in eval_node(a, inp, env):
        for y in eval_node(b, inp, env):
            if op == "+": out.append(jq_add(x, y))
            elif op == "-": out.append(x - y)
            elif op == "*":
                if isinstance(x, str) and isinstance(y, int): out.append(x * y)
                elif isinstance(y, str) and isinstance(x, int): out.append(y * x)
                else: out.append(x * y)
            elif op == "/": out.append(x / y if not (isinstance(x, str) and isinstance(y, str)) else x.split(y))
            elif op == "%": out.append(x % y)
            elif op == "==": out.append(x == y)
            elif op == "!=": out.append(x != y)
            elif op in ("<",">","<=",">="):
                cx, cy = jq_cmp_key(x), jq_cmp_key(y)
                out.append({"<":cx<cy, ">":cx>cy, "<=":cx<=cy, ">=":cx>=cy}[op])
    return out

def call(name, args, inp, env):
    if name == "empty": return []
    if name == "length": return [jq_len(inp)]
    if name == "type": return [jtype(inp)]
    if name == "keys" or name == "keys_unsorted":
        if isinstance(inp, dict):
            ks = list(inp.keys()); return [ks if name == "keys_unsorted" else sorted(ks)]
        if isinstance(inp, list): return [list(range(len(inp)))]
        return [[]]
    if name == "add":
        if not isinstance(inp, list) or not inp: return [None]
        r = inp[0]
        for x in inp[1:]: r = jq_add(r, x)
        return [r]
    if name == "tostring":
        return [inp if isinstance(inp, str) else compact(inp)]
    if name == "tonumber":
        if isinstance(inp, (int, float)) and not isinstance(inp, bool): return [inp]
        if isinstance(inp, str):
            return [float(inp) if any(c in inp for c in ".eE") else int(inp)]
        raise JQError("tonumber")
    if name == "tojson": return [compact(inp)]
    if name == "fromjson": return [json.loads(inp)]
    if name == "not": return [not truthy(inp)]
    if name == "select":
        ok = eval_node(args[0], inp, env) if args else [inp]
        return [inp] if any(truthy(x) for x in ok) else []
    if name == "map":
        if not isinstance(inp, list): raise JQError("Cannot iterate")
        return [[y for x in inp for y in eval_node(args[0], x, env)]]
    if name == "has":
        key = (eval_node(args[0], inp, env) or [None])[-1]
        if isinstance(inp, dict): return [str(key) in inp]
        if isinstance(inp, list) and isinstance(key, int): return [0 <= key < len(inp)]
        return [False]
    if name in ("values","scalars","arrays","objects","nulls","booleans","numbers","strings"):
        want = {"values":None,"scalars":("null","boolean","number","string"),"arrays":("array",),"objects":("object",),
                "nulls":("null",),"booleans":("boolean",),"numbers":("number",),"strings":("string",)}[name]
        if name == "values": return [] if inp is None else [inp]
        return [inp] if jtype(inp) in want else []
    if name == "range":
        vals = []
        ev = [(eval_node(a, inp, env) or [0])[-1] for a in args]
        if len(ev) == 1: start, end, step = 0, int(ev[0]), 1
        elif len(ev) == 2: start, end, step = int(ev[0]), int(ev[1]), 1
        else: start, end, step = int(ev[0]), int(ev[1]), int(ev[2])
        return list(range(start, end, step))
    if name == "min": return [min(inp, key=jq_cmp_key)] if isinstance(inp, list) and inp else [None]
    if name == "max": return [max(inp, key=jq_cmp_key)] if isinstance(inp, list) and inp else [None]
    if name == "sort": return [sorted(inp, key=jq_cmp_key)] if isinstance(inp, list) else [inp]
    if name == "unique":
        if not isinstance(inp, list): return [inp]
        res = []
        for x in sorted(inp, key=jq_cmp_key):
            if not any(x == y for y in res): res.append(x)
        return [res]
    if name == "reverse": return [list(reversed(inp))] if isinstance(inp, list) else [inp[::-1] if isinstance(inp, str) else inp]
    if name == "first":
        if isinstance(inp, list): return [inp[0]] if inp else [None]
        vals = eval_node(args[0], inp, env) if args else [inp]
        return vals[:1]
    if name == "last":
        if isinstance(inp, list): return [inp[-1]] if inp else [None]
        vals = eval_node(args[0], inp, env) if args else [inp]
        return vals[-1:] if vals else []
    if name == "nth":
        idx = int((eval_node(args[0], inp, env) or [0])[-1]) if args else 0
        vals = eval_node(args[1], inp, env) if len(args) > 1 else (inp if isinstance(inp, list) else [inp])
        return [vals[idx]] if 0 <= idx < len(vals) else []
    if name == "contains":
        b = (eval_node(args[0], inp, env) or [None])[-1]
        return [jq_contains(inp, b)]
    if name == "startswith":
        b = (eval_node(args[0], inp, env) or [""])[-1]
        return [isinstance(inp, str) and inp.startswith(b)]
    if name == "endswith":
        b = (eval_node(args[0], inp, env) or [""])[-1]
        return [isinstance(inp, str) and inp.endswith(b)]
    if name == "split":
        b = (eval_node(args[0], inp, env) or [""])[-1]
        return [inp.split(b)] if isinstance(inp, str) else [[]]
    if name == "join":
        sep = (eval_node(args[0], inp, env) or [""])[-1] if args else ""
        if isinstance(inp, list): return [str(sep).join(x if isinstance(x, str) else compact(x) for x in inp)]
        return [inp]
    if name == "flatten":
        d = None
        if args: d = int((eval_node(args[0], inp, env) or [0])[-1])
        return [flatten(inp, d)] if isinstance(inp, list) else [inp]
    if name == "any":
        vals = eval_node(args[0], inp, env) if args else (inp if isinstance(inp, list) else [inp])
        if len(args) > 1:
            vals = [y for x in vals for y in eval_node(args[1], x, env)]
        return [any(truthy(x) for x in vals)]
    if name == "all":
        vals = eval_node(args[0], inp, env) if args else (inp if isinstance(inp, list) else [inp])
        if len(args) > 1:
            vals = [y for x in vals for y in eval_node(args[1], x, env)]
        return [all(truthy(x) for x in vals)]
    if name == "floor": return [math.floor(inp)]
    if name == "ceil": return [math.ceil(inp)]
    if name == "sqrt": return [math.sqrt(inp)]
    if name == "abs": return [abs(inp)]
    raise JQError(f"{name}/0 is not defined")

HELP = """jq - commandline JSON processor [version build-2b77eb1]

Usage:\tjq [options] <jq filter> [file...]
\tjq [options] --args <jq filter> [strings...]
\tjq [options] --jsonargs <jq filter> [JSON_TEXTS...]

jq is a tool for processing JSON inputs, applying the given filter to
its JSON text inputs and producing the filter's results as JSON on
standard output.

Command options:
  -n, --null-input          use `null` as the single input value;
  -R, --raw-input           read each line as string instead of JSON;
  -s, --slurp               read all inputs into an array and use it as
                            the single input value;
  -c, --compact-output      compact instead of pretty-printed output;
  -r, --raw-output          output strings without escapes and quotes;
  -j, --join-output         implies -r and output without newline after
                            each output;
  -a, --ascii-output        output strings by only ASCII characters
                            using escape sequences;
  -S, --sort-keys           sort keys of each object on output;
  -V, --version             show the version;
  -h, --help                show the help;
"""

def parse_json_stream(text):
    dec = json.JSONDecoder()
    vals = []
    i = 0
    n = len(text)
    while True:
        while i < n and text[i].isspace(): i += 1
        if i >= n: break
        v, j = dec.raw_decode(text, i)
        vals.append(v); i = j
    return vals

def read_inputs(files, raw, slurp):
    chunks = []
    if files:
        for f in files:
            with open(f, "r", encoding="utf-8") as fh: chunks.append(fh.read())
    else:
        chunks.append(sys.stdin.read())
    text = "".join(chunks)
    if raw:
        if slurp: return [text]
        return text.splitlines()
    vals = parse_json_stream(text)
    return [vals] if slurp else vals

def main(argv):
    opts = {"null":False,"raw":False,"slurp":False,"compact":False,"rawout":False,"join":False,
            "nul":False,"ascii":False,"sort":False,"indent":2,"exit":False}
    env = {}
    env["ARGS"] = {"positional": [], "named": {}}
    i = 0; filter_text = None; files = []
    while i < len(argv):
        a = argv[i]
        if a in ("-h","--help"): print(HELP, end=""); return 0
        if a in ("-V","--version"): print(VERSION); return 0
        if a == "--build-configuration": print("--disable-docs --with-oniguruma=builtin --enable-static --enable-all-static --prefix=/usr/local"); return 0
        if a == "--": i += 1; break
        if a in ("-n","--null-input"): opts["null"] = True; i += 1; continue
        if a in ("-R","--raw-input"): opts["raw"] = True; i += 1; continue
        if a in ("-s","--slurp"): opts["slurp"] = True; i += 1; continue
        if a in ("-c","--compact-output"): opts["compact"] = True; i += 1; continue
        if a in ("-r","--raw-output"): opts["rawout"] = True; i += 1; continue
        if a == "--raw-output0": opts["rawout"] = True; opts["nul"] = True; i += 1; continue
        if a in ("-j","--join-output"): opts["rawout"] = True; opts["join"] = True; i += 1; continue
        if a in ("-a","--ascii-output"): opts["ascii"] = True; i += 1; continue
        if a in ("-S","--sort-keys"): opts["sort"] = True; i += 1; continue
        if a in ("-e","--exit-status"): opts["exit"] = True; i += 1; continue
        if a in ("-C","-M","--color-output","--monochrome-output","--unbuffered","--tab","--binary","-b"):
            i += 1; continue
        if a == "--indent":
            opts["indent"] = max(0, min(7, int(argv[i+1]))); i += 2; continue
        if a in ("-f","--from-file"):
            with open(argv[i+1], "r", encoding="utf-8") as fh: filter_text = fh.read()
            i += 2; continue
        if a == "--arg":
            env[argv[i+1]] = argv[i+2]; env["ARGS"]["named"][argv[i+1]] = argv[i+2]; i += 3; continue
        if a == "--argjson":
            v = json.loads(argv[i+2]); env[argv[i+1]] = v; env["ARGS"]["named"][argv[i+1]] = v; i += 3; continue
        if a == "--rawfile":
            with open(argv[i+2], "r", encoding="utf-8") as fh: v = fh.read()
            env[argv[i+1]] = v; env["ARGS"]["named"][argv[i+1]] = v; i += 3; continue
        if a == "--slurpfile":
            with open(argv[i+2], "r", encoding="utf-8") as fh: v = parse_json_stream(fh.read())
            env[argv[i+1]] = v; env["ARGS"]["named"][argv[i+1]] = v; i += 3; continue
        if a == "--args":
            if filter_text is None:
                filter_text = argv[i+1]; rest = argv[i+2:]
            else:
                rest = argv[i+1:]
            env["ARGS"]["positional"] = rest; break
        if a == "--jsonargs":
            if filter_text is None:
                filter_text = argv[i+1]; rest = argv[i+2:]
            else:
                rest = argv[i+1:]
            env["ARGS"]["positional"] = [json.loads(x) for x in rest]; break
        if a.startswith("-") and filter_text is None:
            # short option clusters like -rnc
            handled = True
            for ch in a[1:]:
                if ch == "n": opts["null"] = True
                elif ch == "R": opts["raw"] = True
                elif ch == "s": opts["slurp"] = True
                elif ch == "c": opts["compact"] = True
                elif ch == "r": opts["rawout"] = True
                elif ch == "j": opts["rawout"] = True; opts["join"] = True
                elif ch == "a": opts["ascii"] = True
                elif ch == "S": opts["sort"] = True
                elif ch == "e": opts["exit"] = True
                elif ch == "M": pass
                else: handled = False
            if handled: i += 1; continue
        if filter_text is None:
            filter_text = a
        else:
            files.append(a)
        i += 1
    files += argv[i:]
    if filter_text is None:
        print("jq: error: needs filter", file=sys.stderr); return 2
    allouts = []
    last = None
    try:
        ast = Parser(filter_text).parse()
        inputs = [None] if opts["null"] else read_inputs(files, opts["raw"], opts["slurp"])
        for inp in inputs:
            for out in eval_node(ast, inp, env):
                last = out; allouts.append(out)
                write_output(out, opts)
    except Exception as e:
        print(f"jq: error: {e}", file=sys.stderr)
        return 5
    if opts["exit"]:
        if last is None and not allouts: return 4
        return 0 if truthy(last) else 1
    return 0

def write_output(v, opts):
    end = "\0" if opts.get("nul") else ("" if opts["join"] else "\n")
    if opts["rawout"] and isinstance(v, str):
        sys.stdout.write(v + end)
    else:
        s = compact(v, opts["sort"], opts["ascii"]) if opts["compact"] else pretty(v, opts["indent"], opts["sort"], opts["ascii"])
        sys.stdout.write(s + end)

if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
