#!/usr/bin/env python3
import sys, re, json, html, time
from html.parser import HTMLParser
from urllib.parse import urljoin, urldefrag, urlparse, urlunparse
from urllib.request import Request, build_opener, ProxyHandler, HTTPSHandler
from urllib.error import HTTPError, URLError
import ssl

HELP = """Usage:
  executable [options] <url>

Application Options:
      --accepted-status-codes=<codes>       Accepted HTTP response status codes
                                            (e.g. '200..300,403') (default:
                                            200..300)
  -b, --buffer-size=<size>                  HTTP response buffer size in bytes
                                            (default: 4096)
  -c, --max-connections=<count>             Maximum number of HTTP connections
                                            (default: 512)
      --max-connections-per-host=<count>    Maximum number of HTTP connections
                                            per host (default: 512)
      --max-response-body-size=<size>       Maximum response body size to read
                                            (default: 10000000)
  -e, --exclude=<pattern>...                Exclude URLs matched with given
                                            regular expressions
  -i, --include=<pattern>...                Include URLs matched with given
                                            regular expressions
      --follow-robots-txt                   Follow robots.txt when scraping
                                            pages
      --follow-sitemap-xml                  Scrape only pages listed in
                                            sitemap.xml (deprecated)
      --header=<header>...                  Custom headers
  -f, --ignore-fragments                    Ignore URL fragments
      --max-retries=<count>                 Maximum retry count for network
                                            errors (default: 0)
      --dns-resolver=<address>              Custom DNS resolver
      --format=[text|json|junit]            Output format (default: text)
      --json                                Output results in JSON (deprecated)
      --experimental-verbose-json           Include successful results in JSON
                                            (deprecated)
      --junit                               Output results as JUnit XML file
                                            (deprecated)
  -r, --max-redirections=<count>            Maximum number of redirections
                                            (default: 64)
      --rate-limit=<rate>                   Max requests per second
  -t, --timeout=<seconds>                   Timeout for HTTP requests in
                                            seconds (default: 10)
  -v, --verbose                             Show successful results too
      --proxy=<host>                        HTTP proxy host
      --skip-tls-verification               Skip TLS certificate verification
      --one-page-only                       Only check links found in the given
                                            URL
      --color=[auto|always|never]           Color output (default: auto)
  -h, --help                                Show this help
      --version                             Show version
"""

class LinkParser(HTMLParser):
    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.links=[]; self.ids=set()
    def handle_starttag(self, tag, attrs):
        d={k.lower():v for k,v in attrs if k}
        if 'id' in d and d['id'] is not None: self.ids.add(d['id'])
        if tag.lower()=='a' and d.get('name'): self.ids.add(d['name'])
        for attr in ('href','src'):
            if d.get(attr): self.links.append(d[attr].strip())
        if d.get('srcset'):
            for part in d['srcset'].split(','):
                u=part.strip().split()
                if u: self.links.append(u[0])

class Opt: pass

def parse(argv):
    o=Opt(); o.accept='200..300'; o.excludes=[]; o.includes=[]; o.headers={}; o.ignore_frag=False
    o.format='text'; o.verbose=False; o.one=False; o.timeout=10; o.max_body=10000000; o.retries=0
    o.follow_robots=False; o.skip_tls=False; o.proxy=None; o.color='auto'; o.verbose_json=False; urls=[]
    i=0
    while i<len(argv):
        a=argv[i]
        def val(name):
            nonlocal i
            if '=' in a: return a.split('=',1)[1]
            i+=1
            if i>=len(argv): print(f"expected argument for flag `{name}'", file=sys.stderr); sys.exit(1)
            return argv[i]
        if a in ('-h','--help'):
            print(HELP,end=''); sys.exit(0)
        elif a=='--version': print('2.11.1'); sys.exit(0)
        elif a.startswith('--format'):
            v=val('format')
            if v not in ('text','json','junit'):
                print(f"Invalid value `{v}' for option `--format'. Allowed values are: text, json or junit", file=sys.stderr); sys.exit(1)
            o.format=v
        elif a=='--json': o.format='json'
        elif a=='--junit': o.format='junit'
        elif a=='--experimental-verbose-json': o.verbose_json=True
        elif a in ('-v','--verbose'): o.verbose=True
        elif a in ('-f','--ignore-fragments'): o.ignore_frag=True
        elif a=='--one-page-only': o.one=True
        elif a=='--follow-robots-txt': o.follow_robots=True
        elif a=='--follow-sitemap-xml': o.one=True
        elif a=='--skip-tls-verification': o.skip_tls=True
        elif a.startswith('--accepted-status-codes'): o.accept=val('accepted-status-codes')
        elif a in ('-e','--exclude') or a.startswith('--exclude='): o.excludes.append(re.compile(val('exclude')))
        elif a in ('-i','--include') or a.startswith('--include='): o.includes.append(re.compile(val('include')))
        elif a.startswith('--header'):
            h=val('header')
            if ':' in h:
                k,v=h.split(':',1); o.headers[k.strip()]=v.strip()
        elif a in ('-t','--timeout') or a.startswith('--timeout='): o.timeout=float(val('timeout'))
        elif a.startswith('--max-response-body-size'): o.max_body=int(val('max-response-body-size'))
        elif a.startswith('--max-retries'): o.retries=int(val('max-retries'))
        elif a.startswith('--proxy'): o.proxy=val('proxy')
        elif a in ('-b','--buffer-size','-c','--max-connections','--max-connections-per-host','-r','--max-redirections','--rate-limit','--dns-resolver','--color') or any(a.startswith(p+'=') for p in ('--buffer-size','--max-connections','--max-connections-per-host','--max-redirections','--rate-limit','--dns-resolver','--color')):
            if '=' not in a: i+=1
        elif a.startswith('-'):
            print(f"unknown flag `{a.lstrip('-')}'", file=sys.stderr); sys.exit(1)
        else: urls.append(a)
        i+=1
    if len(urls)!=1:
        print('invalid number of arguments', file=sys.stderr); sys.exit(1)
    o.root=urls[0]; return o

def accepted_parser(spec):
    parts=[]
    for p in spec.split(','):
        p=p.strip()
        if not p: continue
        if '..' in p:
            a,b=p.split('..',1); parts.append((int(a), int(b)-1))
        else:
            n=int(p); parts.append((n,n))
    return lambda code: any(a<=code<=b for a,b in parts)

def normalize(u):
    p=urlparse(u)
    if not p.scheme: return u
    net=p.netloc.lower(); scheme=p.scheme.lower()
    return urlunparse((scheme, net, p.path or '/', '', p.query, p.fragment))

def without_frag(u): return urldefrag(u)[0]
def same_site(a,b):
    pa,pb=urlparse(a),urlparse(b)
    return pa.scheme.lower()==pb.scheme.lower() and pa.netloc.lower()==pb.netloc.lower()

def wanted(o,u):
    if o.includes and not any(r.search(u) for r in o.includes): return False
    if any(r.search(u) for r in o.excludes): return False
    return True

def make_opener(o):
    handlers=[]
    if o.proxy: handlers.append(ProxyHandler({'http':o.proxy,'https':o.proxy}))
    else: handlers.append(ProxyHandler({}))
    if o.skip_tls:
        handlers.append(HTTPSHandler(context=ssl._create_unverified_context()))
    return build_opener(*handlers)

def fetch(o, opener, url):
    last=None
    for _ in range(o.retries+1):
        try:
            req=Request(url, headers=o.headers)
            with opener.open(req, timeout=o.timeout) as r:
                code=getattr(r,'status', r.getcode())
                ctype=r.headers.get('Content-Type','')
                data=r.read(o.max_body+1)[:o.max_body]
                return code, ctype, data.decode('utf-8','replace'), None
        except HTTPError as e:
            data=e.read(o.max_body+1)[:o.max_body]
            return e.code, e.headers.get('Content-Type',''), data.decode('utf-8','replace'), None
        except Exception as e:
            last=str(e)
            time.sleep(0.05)
    return 0, '', '', last or 'network error'

def read_robots(o, opener, root):
    if not o.follow_robots: return []
    p=urlparse(root); ru=urlunparse((p.scheme,p.netloc,'/robots.txt','','',''))
    code,_,body,err=fetch(o,opener,ru)
    dis=[]; active=False
    if not err and code<400:
        for line in body.splitlines():
            line=line.split('#',1)[0].strip()
            if not line or ':' not in line: continue
            k,v=line.split(':',1); k=k.strip().lower(); v=v.strip()
            if k=='user-agent': active=(v=='*')
            elif active and k=='disallow' and v: dis.append(v)
    return dis

def disallowed(dis, u):
    path=urlparse(u).path or '/'
    return any(path.startswith(d) for d in dis)

def scan(o):
    acc=accepted_parser(o.accept); opener=make_opener(o); root=normalize(o.root)
    dis=read_robots(o,opener,root)
    pages=[]; seen_pages=set(); fetched={}; queue=[root]
    root_code,root_ct,root_body,root_err = fetch(o,opener,root)
    if root_err or not acc(root_code):
        msg = root_err if root_err else str(root_code)
        print('failed to fetch root page: '+msg, file=sys.stderr); sys.exit(1)
    fetched[without_frag(root)] = (root_code, root_ct, root_body, root_err)
    def get(u):
        key=without_frag(u)
        if key not in fetched: fetched[key]=fetch(o,opener,key)
        return fetched[key]
    while queue:
        page=queue.pop(0); base=without_frag(page)
        if base in seen_pages: continue
        seen_pages.add(base)
        code,ct,body,err=get(base)
        parser=LinkParser()
        if 'html' in ct.lower() or body.lstrip().lower().startswith(('<!doctype html','<html')):
            try: parser.feed(body)
            except Exception: pass
        results=[]
        for raw in parser.links:
            if not raw or raw.startswith(('mailto:','tel:','javascript:','data:')): continue
            u=normalize(urljoin(base, raw))
            if o.ignore_frag: u=without_frag(u)
            if not wanted(o,u) or disallowed(dis,u): continue
            pu=urlparse(u)
            if pu.scheme not in ('http','https'): continue
            lcode,lct,lbody,lerr=get(u)
            error=None
            if lerr: error=lerr
            elif not acc(lcode): error=str(lcode)
            elif pu.fragment and not o.ignore_frag:
                lp=LinkParser()
                try: lp.feed(lbody)
                except Exception: pass
                frag=html.unescape(pu.fragment)
                if frag not in lp.ids: error=f'id #{frag} not found'
            item={'url':u}
            if error: item['error']=error
            else: item['status']=lcode
            results.append(item)
            if (not o.one) and same_site(root,u) and not disallowed(dis,u) and not error and ('html' in lct.lower()) and without_frag(u) not in seen_pages:
                queue.append(without_frag(u))
        pages.append({'url':base, 'links':results})
    return pages

def output_text(pages, verbose):
    bad=False
    for p in pages:
        links=[l for l in p['links'] if verbose or 'error' in l]
        if not links: continue
        print(p['url'])
        for l in links:
            if 'error' in l:
                bad=True; print(f"\t{l['error']}\t{l['url']}")
            else:
                print(f"\t{l.get('status',200)}\t{l['url']}")
    return bad

def output_json(pages, verbose):
    out=[]; bad=False
    for p in pages:
        links=[]
        for l in p['links']:
            if 'error' in l:
                bad=True; links.append({'url':l['url'],'error':l['error']})
            elif verbose:
                links.append({'url':l['url'],'status':l.get('status',200)})
        if links: out.append({'url':p['url'],'links':links})
    print(json.dumps(out,separators=(',',':')))
    return bad

def output_junit(pages):
    bad=False
    print('<?xml version="1.0" encoding="UTF-8"?>')
    print('<testsuites>')
    for p in pages:
        links=p['links']; fails=sum(1 for l in links if 'error' in l); bad = bad or fails>0
        print(f'  <testsuite name="{html.escape(p["url"],quote=True)}" tests="{len(links)}" failures="{fails}" skipped="0">')
        for l in links:
            print(f'    <testcase name="{html.escape(l["url"],quote=True)}" classname="{html.escape(p["url"],quote=True)}">', end='')
            if 'error' in l:
                print(); print(f'      <failure message="{html.escape(l["error"],quote=True)}"></failure>'); print('    </testcase>')
            else: print('</testcase>')
        print('  </testsuite>')
    print('</testsuites>')
    return bad

def main():
    o=parse(sys.argv[1:]); pages=scan(o)
    if o.format=='json': bad=output_json(pages,o.verbose or o.verbose_json)
    elif o.format=='junit': bad=output_junit(pages)
    else: bad=output_text(pages,o.verbose)
    sys.exit(1 if bad else 0)
if __name__=='__main__': main()
