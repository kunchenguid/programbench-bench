#!/usr/bin/env python3
import argparse
import json
import os
import re
import sys
from collections import OrderedDict

HELP = """Usage:
    go test ./... -json | tparse [options...]
    go test [packages...] -json | tparse [options...]
    go test [packages...] -json > pkgs.out ; tparse [options...] -file pkgs.out

Options:
    -h                 Show help.
    -v                 Show version.
    -all               Display table event for pass and skip. (Failed items always displayed)
    -pass              Display table for passed tests.
    -skip              Display table for skipped tests.
    -notests           Display packages containing no test files or empty test files.
    -smallscreen       Split subtest names vertically to fit on smaller screens.
    -slow              Number of slowest tests to display. Default is 0, display all.
    -sort              Sort table output by attribute [name, elapsed, cover]. Default is name.
    -nocolor           Disable all colors. (NO_COLOR also supported)
    -format            The output format for tables [basic, plain, markdown]. Default is basic.
    -file              Read test output from a file.
    -follow            Follow raw output from go test to stdout.
    -follow-output     Write raw output from go test to a file (takes precedence over -follow).
    -include-timestamp Include timestamps in follow output. 
    -progress          Print a single summary line for each package. Useful for long running test suites.
    -compare           Compare against a previous test output file. (experimental)
    -trimpath          Remove path prefix from package names in output, simplifying their display."""


class Test:
    def __init__(self, pkg, name):
        self.pkg = pkg
        self.name = name
        self.status = ""
        self.elapsed = 0.0
        self.output = []


class Package:
    def __init__(self, name):
        self.name = name
        self.status = ""
        self.elapsed = 0.0
        self.cover = "--"
        self.tests = OrderedDict()
        self.output = []
        self.notest = ""

    def counts(self):
        p = f = s = 0
        for t in self.tests.values():
            if t.status == "PASS":
                p += 1
            elif t.status == "FAIL":
                f += 1
            elif t.status == "SKIP":
                s += 1
        return p, f, s


def disp_pkg(name, args, banner=False):
    if banner:
        return name
    if args.trimpath and name.startswith(args.trimpath):
        return name[len(args.trimpath):]
    if args.smallscreen:
        return name.rstrip("/").split("/")[-1]
    return name


def center(s, w):
    s = str(s)
    n = w - len(s)
    if n <= 0:
        return s
    return " " * ((n + 1) // 2) + s + " " * (n // 2)


def ljust(s, w):
    return str(s) + " " * max(0, w - len(str(s)))


def table_basic(headers, rows):
    widths = [len(h) for h in headers]
    for r in rows:
        for i, c in enumerate(r):
            for part in str(c).split("\n"):
                widths[i] = max(widths[i], len(part))
    top = "╭" + "┬".join("─" * (w + 2) for w in widths) + "╮"
    sep = "├" + "┼".join("─" * (w + 2) for w in widths) + "┤"
    bot = "╰" + "┴".join("─" * (w + 2) for w in widths) + "╯"
    out = [top, "│ " + " │ ".join(center(h, widths[i]) for i, h in enumerate(headers)) + " │", sep]
    for r in rows:
        parts = [str(c).split("\n") for c in r]
        height = max(len(p) for p in parts)
        for line in range(height):
            cells = []
            for i, p in enumerate(parts):
                val = p[line] if line < len(p) else ""
                cells.append(center(val, widths[i]))
            out.append("│ " + " │ ".join(cells) + " │")
    out.append(bot)
    return "\n".join(out)


def table_plain(headers, rows):
    widths = [len(h) for h in headers]
    for r in rows:
        for i, c in enumerate(r):
            for part in str(c).split("\n"):
                widths[i] = max(widths[i], len(part))
    out = [" ".join(" " + center(h, widths[i]) + " " for i, h in enumerate(headers))]
    out.append(" ".join(" " + " " * widths[i] + " " for i in range(len(headers))))
    for r in rows:
        parts = [str(c).split("\n") for c in r]
        height = max(len(p) for p in parts)
        for line in range(height):
            vals = []
            for i, p in enumerate(parts):
                vals.append(" " + center(p[line] if line < len(p) else "", widths[i]) + " ")
            out.append(" ".join(vals))
    return "\n".join(out)


def table_markdown(headers, rows):
    widths = [len(h) for h in headers]
    for r in rows:
        for i, c in enumerate(r):
            widths[i] = max(widths[i], len(str(c)))
    out = ["| " + " | ".join(center(h, widths[i]) for i, h in enumerate(headers)) + " |"]
    out.append("|" + "|".join("-" * (w + 2) for w in widths) + "|")
    for r in rows:
        out.append("| " + " | ".join(center(str(c), widths[i]) for i, c in enumerate(r)) + " |")
    return "\n".join(out)


def render_table(headers, rows, fmt):
    if fmt == "plain":
        return table_plain(headers, rows)
    if fmt == "markdown":
        return table_markdown(headers, rows)
    return table_basic(headers, rows)


def parse_args(argv):
    argv = ["-h" if a == "--help" else "-v" if a == "--version" else a for a in argv]
    p = argparse.ArgumentParser(add_help=False)
    p.add_argument("-h", action="store_true")
    p.add_argument("-v", action="store_true")
    p.add_argument("-all", action="store_true")
    p.add_argument("-pass", dest="showpass", action="store_true")
    p.add_argument("-skip", dest="showskip", action="store_true")
    p.add_argument("-notests", action="store_true")
    p.add_argument("-smallscreen", action="store_true")
    p.add_argument("-slow", type=int, default=0)
    p.add_argument("-sort", default="name")
    p.add_argument("-nocolor", action="store_true")
    p.add_argument("-format", default="basic")
    p.add_argument("-file")
    p.add_argument("-follow", action="store_true")
    p.add_argument("-follow-output")
    p.add_argument("-include-timestamp", action="store_true")
    p.add_argument("-progress", action="store_true")
    p.add_argument("-compare")
    p.add_argument("-trimpath", default="")
    try:
        args, rest = p.parse_known_args(argv)
    except SystemExit:
        sys.exit(2)
    if rest:
        print(f"flag provided but not defined: {rest[0]}", file=sys.stderr)
        print(HELP, file=sys.stderr)
        sys.exit(2)
    return args


def read_events(args):
    if args.file:
        try:
            src = open(args.file, "r", encoding="utf-8", errors="replace")
        except OSError as e:
            print(f"open {args.file}: {e.strerror}", file=sys.stderr)
            sys.exit(1)
    else:
        if sys.stdin.isatty():
            print("stdin must be a pipe, or use -file to open a go test output file", file=sys.stderr)
            sys.exit(1)
        src = sys.stdin
    follow_file = None
    if args.follow_output:
        follow_file = open(args.follow_output, "w", encoding="utf-8")
    pkgs = OrderedDict()
    parsed = 0
    for line in src:
        try:
            ev = json.loads(line)
        except Exception:
            continue
        if not isinstance(ev, dict) or "Action" not in ev or "Package" not in ev:
            continue
        parsed += 1
        pkgname = ev.get("Package", "")
        pkg = pkgs.setdefault(pkgname, Package(pkgname))
        action = ev.get("Action", "")
        testname = ev.get("Test", "")
        out = ev.get("Output", "")
        if testname:
            test = pkg.tests.setdefault(testname, Test(pkgname, testname))
        else:
            test = None
        if action == "output":
            if out:
                pkg.output.append(out)
                if test:
                    test.output.append(out)
                m = re.search(r"coverage:\s+([0-9.]+%)", out)
                if m:
                    pkg.cover = m.group(1)
                m2 = re.search(r"\[no test files\]|\[no tests to run\]", out)
                if m2:
                    pkg.notest = m2.group(0)
            if args.follow or follow_file:
                raw = out
                if args.include_timestamp and ev.get("Time"):
                    raw = ev.get("Time") + " " + raw
                if follow_file:
                    follow_file.write(raw)
                else:
                    sys.stdout.write(raw)
        elif action in ("pass", "fail", "skip") and test:
            test.status = action.upper()
            test.elapsed = float(ev.get("Elapsed", 0) or 0)
        elif action in ("pass", "fail", "skip") and not test:
            pkg.status = "PASS" if action in ("pass", "skip") else "FAIL"
            pkg.elapsed = float(ev.get("Elapsed", 0) or 0)
            if action == "skip" and not pkg.tests:
                if not pkg.notest:
                    pkg.notest = "[no test files]"
        if args.progress and not testname and action in ("pass", "fail", "skip"):
            st = "PASS" if action in ("pass", "skip") else "FAIL"
            print(f"[{st}]\t{pkg.elapsed:9.2f}s\t{pkg.name}")
    if follow_file:
        follow_file.close()
    if args.file:
        src.close()
    if parsed == 0:
        print("no parsable events: Make sure to run go test with -json flag", file=sys.stderr)
        sys.exit(1)
    return pkgs


def test_rows(pkgs, args):
    if not (args.all or args.showpass or args.showskip):
        return []
    rows = []
    for pkg in pkgs.values():
        shown_any = False
        tests = list(pkg.tests.values())
        if args.sort == "elapsed":
            tests.sort(key=lambda t: t.elapsed, reverse=True)
        elif args.sort == "name":
            order = {"PASS": 0, "SKIP": 1, "FAIL": 2}
            tests.sort(key=lambda t: (order.get(t.status, 9), t.name))
        for t in tests:
            show = t.status == "FAIL" or args.all or (args.showpass and t.status == "PASS") or (args.showskip and t.status == "SKIP")
            if show:
                rows.append([t.status, f"{t.elapsed:.2f}", t.name, disp_pkg(pkg.name, args)])
                shown_any = True
        if (args.showpass or args.showskip or args.all) and shown_any and pkg is not list(pkgs.values())[-1]:
            rows.append(["", "", "", ""])
    if args.slow > 0:
        rows = sorted([r for r in rows if any(r)], key=lambda r: float(r[1]), reverse=True)[:args.slow]
    return rows


def summary_rows(pkgs, args):
    rows = []
    plist = list(pkgs.values())
    if args.sort == "elapsed":
        plist.sort(key=lambda p: p.elapsed, reverse=True)
    elif args.sort == "cover":
        def cov(p):
            try:
                return float(p.cover.rstrip("%"))
            except Exception:
                return -1.0
        plist.sort(key=cov, reverse=True)
    else:
        plist.sort(key=lambda p: p.name)
    for pkg in plist:
        p, f, s = pkg.counts()
        if pkg.notest and not pkg.tests:
            if args.notests:
                rows.append(["NOTEST", f"{pkg.elapsed:.2f}s", disp_pkg(pkg.name, args) + "\n" + pkg.notest, "--", "--", "--", "--"])
            continue
        st = pkg.status or ("FAIL" if f else "PASS")
        rows.append([st, f"{pkg.elapsed:.2f}s", disp_pkg(pkg.name, args), pkg.cover, str(p), str(f), str(s)])
    return rows


def failure_text(pkg):
    chunks = []
    for t in pkg.tests.values():
        if t.status != "FAIL":
            continue
        fail_lines = []
        other_lines = []
        for o in t.output:
            if o.startswith("=== RUN"):
                continue
            if o.strip() == "":
                continue
            val = o.rstrip("\n")
            if val.startswith("--- FAIL:"):
                fail_lines.append(val)
            else:
                other_lines.append(val)
        lines = fail_lines + ([""] if fail_lines and other_lines else []) + other_lines
        if lines:
            chunks.extend(lines)
            chunks.append("")
    return "\n".join(chunks).rstrip() + ("\n" if chunks else "")


def banner(pkgname):
    text = f"   FAIL  package: {pkgname}   "
    return "\n".join(["┏" + "━" * len(text) + "┓", "┃" + text + "┃", "┗" + "━" * len(text) + "┛"])


def markdown_output(pkgs, args):
    parts = []
    for pkg in pkgs.values():
        p, f, s = pkg.counts()
        if args.all or args.showpass or args.showskip or f:
            rows = []
            for t in pkg.tests.values():
                show = t.status == "FAIL" or args.all or (args.showpass and t.status == "PASS") or (args.showskip and t.status == "SKIP")
                if show:
                    rows.append([t.status, f"{t.elapsed:.2f}", t.name])
            if rows:
                parts.append(f"## 📦 Package **`{pkg.name}`**\n\nTests: ✓ {p} passed | {s} skipped | {f} failed\n\n<details>\n\n<summary>Click for test summary</summary>\n\n" + table_markdown(["Status", "Elapsed", "Test"], rows) + "\n</details>\n")
        if f:
            parts.append(f"\n## FAIL • {pkg.name}\n\n```\n{failure_text(pkg)}```\n")
    sr = summary_rows(pkgs, args)
    if sr:
        parts.append(table_markdown(["Status", "Elapsed", "Package", "Cover", "Pass", "Fail", "Skip"], sr))
    return "\n".join(parts)


def main():
    args = parse_args(sys.argv[1:])
    if args.h:
        print(HELP)
        return 0
    if args.v:
        print("tparse version: (devel)")
        return 0
    if args.format not in ("basic", "plain", "markdown"):
        args.format = "basic"
    pkgs = read_events(args)
    failed = any((p.status == "FAIL" or any(t.status == "FAIL" for t in p.tests.values())) for p in pkgs.values())
    if args.format == "markdown":
        out = markdown_output(pkgs, args)
        if out:
            print(out)
        return 1 if failed else 0
    rows = test_rows(pkgs, args)
    if rows:
        print(render_table(["Status", "Elapsed", "Test", "Package"], rows, args.format))
    for pkg in pkgs.values():
        if any(t.status == "FAIL" for t in pkg.tests.values()):
            if rows:
                print()
            print(banner(disp_pkg(pkg.name, args, banner=True)))
            print()
            txt = failure_text(pkg)
            if txt:
                print(txt)
    sr = summary_rows(pkgs, args)
    if sr:
        if rows or failed:
            print()
        print(render_table(["Status", "Elapsed", "Package", "Cover", "Pass", "Fail", "Skip"], sr, args.format))
    return 1 if failed else 0


if __name__ == "__main__":
    sys.exit(main())
