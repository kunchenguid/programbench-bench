#!/usr/bin/env python3
import json
import os
import re
import sys

HELP = """xplr 1.1.0
Arijit Basu <hi@arijitbasu.in>
A hackable, minimal, fast TUI file explorer

USAGE:
    xplr [FLAG]... [OPTION]... [PATH] [SELECTION]...

FLAGS:
  -                            Reads new-line (\\n) separated paths from stdin
  --                           Denotes the end of command-line flags and options
      --force-focus            Focuses on the given <PATH>, even if it is a directory
  -h, --help                   Prints help information
  -m, --pipe-msg-in            Helps safely passing messages to the active xplr
                                 session, use %%, %s and %q as the placeholders
  -M, --print-msg-in           Like --pipe-msg-in, but prints the message instead of
                                 passing to the active xplr session
      --print-pwd-as-result    Prints the present working directory when quitting
                                 with `PrintResultAndQuit`
      --read-only              Enables read-only mode (config.general.read_only)
      --read0                  Reads paths separated using the null character (\\0)
      --write0                 Prints paths separated using the null character (\\0)
  -0  --null                   Combines --read0 and --write0
  -V, --version                Prints version information

OPTIONS:
  -c, --config <PATH>             Specifies a custom config file (default is
                                    "$HOME/.config/xplr/init.lua")
  -C, --extra-config <PATH>...    Specifies extra config files to load
      --on-load <MESSAGE>...      Sends messages when xplr loads
      --vroot <PATH>              Treats the specified path as the virtual root

ARGS:
  <PATH>            Path to focus on, or enter if directory, (default is `.`)
  <SELECTION>...    Paths to select, requires <PATH> to be set explicitly"""

VERSION = "xplr 1.1.0"


class MsgError(Exception):
    pass


def err(message):
    print(f"error: {message}", file=sys.stderr)
    return 1


def json_quote(s):
    return json.dumps(s, ensure_ascii=False, separators=(",", ":"))


def render_template(fmt, vals):
    out = []
    i = 0
    vi = 0
    while i < len(fmt):
        ch = fmt[i]
        if ch != "%":
            out.append(ch)
            i += 1
            continue
        if i + 1 >= len(fmt):
            out.append("%")
            i += 1
            continue
        code = fmt[i + 1]
        if code == "%":
            out.append("%")
            i += 2
        elif code == "s":
            if vi >= len(vals):
                raise MsgError(f"xplr -m: placeholder missing value at column {i + 1}")
            out.append(vals[vi])
            vi += 1
            i += 2
        elif code == "q":
            if vi >= len(vals):
                raise MsgError(f"xplr -m: placeholder missing value at column {i + 1}")
            out.append(json_quote(vals[vi]))
            vi += 1
            i += 2
        elif code == "*" and i + 2 < len(fmt) and fmt[i + 2] in ("s", "q"):
            q = fmt[i + 2] == "q"
            rest = vals[vi:]
            if q:
                out.append(",".join(json_quote(v) for v in rest))
            else:
                out.append(",".join(rest))
            vi = len(vals)
            i += 3
        else:
            out.append("%")
            i += 1
    if vi < len(vals):
        raise MsgError("xplr -m: too many positional values, not enough positional placeholders")
    return "".join(out)


def split_top(s, sep=","):
    parts, buf, depth, quote, esc = [], [], 0, None, False
    for ch in s:
        if quote:
            buf.append(ch)
            if esc:
                esc = False
            elif ch == "\\":
                esc = True
            elif ch == quote:
                quote = None
            continue
        if ch in "'\"":
            quote = ch
            buf.append(ch)
        elif ch in "[{":
            depth += 1
            buf.append(ch)
        elif ch in "]}":
            depth -= 1
            buf.append(ch)
        elif ch == sep and depth == 0:
            parts.append("".join(buf).strip())
            buf = []
        else:
            buf.append(ch)
    tail = "".join(buf).strip()
    if tail or s.endswith(sep):
        parts.append(tail)
    return parts


def find_top_colon(s):
    depth, quote, esc = 0, None, False
    for i, ch in enumerate(s):
        if quote:
            if esc:
                esc = False
            elif ch == "\\":
                esc = True
            elif ch == quote:
                quote = None
            continue
        if ch in "'\"":
            quote = ch
        elif ch in "[{":
            depth += 1
        elif ch in "]}":
            depth -= 1
        elif ch == ":" and depth == 0:
            return i
    return -1


def parse_scalar(s):
    s = s.strip()
    if s == "":
        return ""
    if s[0:1] in ("\"", "'") and s[-1:] == s[0]:
        if s[0] == '"':
            try:
                return json.loads(s)
            except Exception:
                return s[1:-1]
        return s[1:-1].replace("''", "'")
    if re.fullmatch(r"[-+]?[0-9]+", s):
        try:
            return int(s)
        except Exception:
            pass
    if re.fullmatch(r"[-+]?(?:[0-9]*\.[0-9]+|[0-9]+\.[0-9]*)(?:[eE][-+]?[0-9]+)?", s):
        try:
            return float(s)
        except Exception:
            pass
    if s in ("true", "True"):
        return True
    if s in ("false", "False"):
        return False
    if s in ("null", "Null", "~"):
        return None
    return s


def parse_value(s):
    s = s.strip()
    if not s:
        raise MsgError("expected value at line 1 column 1")
    if s[0] == "{" and s[-1:] == "}":
        body = s[1:-1].strip()
        obj = {}
        if body:
            for part in split_top(body):
                c = find_top_colon(part)
                if c < 0:
                    raise MsgError("expected value at line 1 column 1")
                key = parse_scalar(part[:c].strip())
                obj[str(key)] = parse_value(part[c + 1 :])
        return obj
    if s[0] == "[" and s[-1:] == "]":
        body = s[1:-1].strip()
        if not body:
            return []
        return [parse_value(p) for p in split_top(body)]
    c = find_top_colon(s)
    if c > 0 and "\n" not in s:
        key = parse_scalar(s[:c].strip())
        return {str(key): parse_value(s[c + 1 :])}
    return parse_scalar(s)


def message_json(fmt, vals):
    rendered = render_template(fmt, vals)
    val = parse_value(rendered)
    return json.dumps(val, ensure_ascii=False, separators=(",", ":"))


def handle_msg(print_only, fmt, vals):
    try:
        data = message_json(fmt, vals)
    except MsgError as e:
        return err(str(e))
    except Exception as e:
        return err(str(e))
    if print_only:
        sys.stdout.write(data)
        return 0
    path = os.environ.get("XPLR_PIPE_MSG_IN")
    if not path:
        return err("No such file or directory (os error 2)")
    try:
        with open(path, "ab") as f:
            f.write(data.encode())
            f.write(b"\n")
    except OSError as e:
        return err(e.strerror + f" (os error {e.errno})")
    return 0


def main(argv):
    if not argv:
        return err("No such device or address (os error 6)")
    i = 0
    passthrough = False
    while i < len(argv):
        a = argv[i]
        if not passthrough and a == "--":
            passthrough = True
            i += 1
            continue
        if not passthrough and a in ("-h", "--help"):
            sys.stdout.write(HELP)
            return 0
        if not passthrough and a in ("-V", "--version"):
            print(VERSION)
            return 0
        if not passthrough and a in ("-M", "--print-msg-in"):
            if i + 1 >= len(argv):
                return err(f"usage: xplr {a} FORMAT [ARGUMENT]...")
            return handle_msg(True, argv[i + 1], argv[i + 2 :])
        if not passthrough and a in ("-m", "--pipe-msg-in"):
            if i + 1 >= len(argv):
                return err(f"usage: xplr {a} FORMAT [ARGUMENT]...")
            return handle_msg(False, argv[i + 1], argv[i + 2 :])
        if not passthrough and a in ("-c", "--config", "--vroot"):
            if i + 1 >= len(argv):
                return err(f"usage: xplr {a} PATH")
            i += 2
            continue
        if not passthrough and a in ("-C", "--extra-config", "--on-load"):
            if i + 1 >= len(argv):
                # The real binary proceeds to terminal setup for --on-load; keep that observable.
                return err("No such device or address (os error 6)") if a == "--on-load" else err(f"usage: xplr {a} PATH")
            i += 2
            continue
        if not passthrough and a.startswith("-") and a != "-":
            return err(f'invalid argument: "{a}", try `-- "{a}"` or `--help`')
        i += 1
    return err("No such device or address (os error 6)")


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
