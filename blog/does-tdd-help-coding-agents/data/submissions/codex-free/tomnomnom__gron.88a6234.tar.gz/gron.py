#!/usr/bin/env python3
import argparse
import json
import os
import re
import ssl
import sys
import urllib.request


HELP = """Transform JSON (from a file, URL, or stdin) into discrete assignments to make it greppable

Usage:
  gron [OPTIONS] [FILE|URL|-]

Options:
  -u, --ungron     Reverse the operation (turn assignments back into JSON)
  -v, --values     Print just the values of provided assignments
  -c, --colorize   Colorize output (default on tty)
  -m, --monochrome Monochrome (don't colorize output)
  -s, --stream     Treat each line of input as a separate JSON object
  -k, --insecure   Disable certificate validation
  -x, --proxy      Set proxy configuration
      --noproxy    Comma-separated list of hosts for which not to use a proxy, if one is specified.
  -j, --json       Represent gron data as JSON stream
      --no-sort    Don't sort output (faster)
      --version    Print version information

Exit Codes:
  0\tOK
  1\tFailed to open file
  2\tFailed to read input
  3\tFailed to form statements
  4\tFailed to fetch URL
  5\tFailed to parse statements
  6\tFailed to encode JSON

Examples:
  gron /tmp/apiresponse.json
  gron http://jsonplaceholder.typicode.com/users/1 
  curl -s http://jsonplaceholder.typicode.com/users/1 | gron
  gron http://jsonplaceholder.typicode.com/users/1 | grep company | gron --ungron"""


RESERVED = {
    "break", "case", "catch", "class", "const", "continue", "debugger", "default",
    "delete", "do", "else", "export", "extends", "finally", "for", "function",
    "if", "import", "in", "instanceof", "new", "return", "super", "switch",
    "this", "throw", "try", "typeof", "var", "void", "while", "with", "yield",
    "let", "static", "enum", "await", "implements", "package", "protected",
    "interface", "private", "public", "null", "true", "false",
}


def eprint(msg):
    print(msg, file=sys.stderr)


def js_string(value):
    return json.dumps(value, ensure_ascii=False, separators=(",", ":"))


def json_value(value):
    return json.dumps(value, ensure_ascii=False, separators=(",", ":"))


def pretty_json(value):
    return json.dumps(value, ensure_ascii=False, indent=2, sort_keys=True)


def is_ident(key):
    if not isinstance(key, str) or key == "" or key in RESERVED:
        return False
    first = key[0]
    if not (first == "$" or first == "_" or first.isalpha()):
        return False
    for ch in key[1:]:
        if not (ch == "$" or ch == "_" or ch.isalpha() or ch.isdigit()):
            return False
    return True


def path_to_js(path):
    out = "json"
    for part in path:
        if isinstance(part, int):
            out += f"[{part}]"
        elif is_ident(part):
            out += "." + part
        else:
            out += "[" + js_string(part) + "]"
    return out


def walk(value, path, out):
    if isinstance(value, dict):
        out.append((list(path), {}))
        for key, child in value.items():
            walk(child, path + [key], out)
    elif isinstance(value, list):
        out.append((list(path), []))
        for i, child in enumerate(value):
            walk(child, path + [i], out)
    else:
        out.append((list(path), value))


def sorted_statements(stmts, do_sort=True):
    if do_sort:
        return sorted(stmts, key=lambda kv: path_to_js(kv[0]))
    return stmts


def ansi_statement(path, value):
    return f"\033[1;30m{path_to_js(path)}\033[0m = \033[32m{json_value(value)}\033[0m;"


def print_gron(data, as_json=False, color=False, do_sort=True):
    stmts = []
    walk(data, [], stmts)
    for path, value in sorted_statements(stmts, do_sort):
        try:
            if as_json:
                print(json.dumps([path, value], ensure_ascii=False, separators=(",", ":")))
            elif color:
                print(ansi_statement(path, value))
            else:
                print(f"{path_to_js(path)} = {json_value(value)};")
        except Exception as exc:
            eprint(f"failed to encode JSON: {exc}")
            return 6
    return 0


def read_input(source, insecure=False, proxy=None, noproxy=None):
    if source is None or source == "-":
        try:
            return sys.stdin.read(), 0
        except Exception as exc:
            eprint(f"failed to read input: {exc}")
            return None, 2

    if re.match(r"^https?://", source):
        try:
            handlers = []
            if proxy:
                handlers.append(urllib.request.ProxyHandler({"http": proxy, "https": proxy}))
            if noproxy:
                os.environ["no_proxy"] = noproxy
            opener = urllib.request.build_opener(*handlers)
            ctx = ssl._create_unverified_context() if insecure else None
            req = urllib.request.Request(source, headers={"User-Agent": "gron/0.1"})
            if ctx is not None:
                resp = opener.open(req, context=ctx)
            else:
                resp = opener.open(req)
            with resp:
                return resp.read().decode("utf-8"), 0
        except Exception as exc:
            eprint(f"failed to fetch URL: {exc}")
            return None, 4

    try:
        with open(source, "r", encoding="utf-8") as f:
            return f.read(), 0
    except OSError as exc:
        eprint(str(exc))
        return None, 1
    except Exception as exc:
        eprint(f"failed to read input: {exc}")
        return None, 2


def parse_json_input(text, stream=False):
    try:
        if stream:
            vals = []
            for line in text.splitlines():
                if line.strip() == "":
                    continue
                vals.append(json.loads(line))
            return vals, 0
        return json.loads(text), 0
    except Exception as exc:
        eprint(f"failed to form statements: {exc}")
        return None, 3


def parse_path(path):
    if not path.startswith("json"):
        raise ValueError("invalid path")
    i = 4
    parts = []
    n = len(path)
    while i < n:
        if path[i] == ".":
            i += 1
            start = i
            while i < n and path[i] not in ".[":
                i += 1
            if start == i:
                raise ValueError("invalid path")
            parts.append(path[start:i])
        elif path[i] == "[":
            if i + 1 < n and path[i + 1] == '"':
                dec = json.JSONDecoder()
                val, off = dec.raw_decode(path[i + 1:])
                j = i + 1 + off
                if j >= n or path[j] != "]":
                    raise ValueError("invalid path")
                parts.append(val)
                i = j + 1
            else:
                j = path.find("]", i)
                if j < 0:
                    raise ValueError("invalid path")
                raw = path[i + 1:j].strip()
                if not re.match(r"^\d+$", raw):
                    raise ValueError("invalid array index")
                parts.append(int(raw))
                i = j + 1
        else:
            raise ValueError("invalid path")
    return parts


def parse_assignment_line(line):
    raw = line.strip()
    if raw == "":
        return None
    if raw.endswith(";"):
        raw = raw[:-1].rstrip()
    eq = find_assignment_equals(raw)
    if eq < 0:
        raise ValueError("missing equals")
    path_s = raw[:eq].strip()
    val_s = raw[eq + 1:].strip()
    if val_s == "":
        raise ValueError("invalid value ``")
    try:
        path = parse_path(path_s)
        value = json.loads(val_s)
    except json.JSONDecodeError as exc:
        raise ValueError(f"invalid value `{val_s}`") from exc
    return path, value


def find_assignment_equals(raw):
    in_str = False
    esc = False
    for i, ch in enumerate(raw):
        if in_str:
            if esc:
                esc = False
            elif ch == "\\":
                esc = True
            elif ch == '"':
                in_str = False
            continue
        if ch == '"':
            in_str = True
        elif ch == "=":
            return i
    return -1


def read_statements(text, as_json=False):
    stmts = []
    if as_json:
        for line in text.splitlines():
            if line.strip() == "":
                continue
            try:
                item = json.loads(line)
                if not isinstance(item, list) or len(item) != 2 or not isinstance(item[0], list):
                    raise ValueError("invalid JSON stream item")
                stmts.append((item[0], item[1]))
            except Exception as exc:
                eprint(f"failed to parse statements: {exc}")
                return None, 5
        return stmts, 0

    for line in text.splitlines():
        if line.strip() == "":
            continue
        try:
            parsed = parse_assignment_line(line)
            if parsed is not None:
                stmts.append(parsed)
        except Exception as exc:
            eprint(f"ungron failed for `{line}`: {exc}")
            return None, 5
    return stmts, 0


def ensure_container(parent, key, next_key):
    want = [] if isinstance(next_key, int) else {}
    if isinstance(parent, list):
        while len(parent) <= key:
            parent.append(None)
        if parent[key] is None or not isinstance(parent[key], (dict, list)):
            parent[key] = want
        return parent[key]
    if key not in parent or parent[key] is None or not isinstance(parent[key], (dict, list)):
        parent[key] = want
    return parent[key]


def assign(root, path, value):
    if not path:
        return value
    if root is None:
        root = [] if isinstance(path[0], int) else {}
    cur = root
    for idx, key in enumerate(path):
        last = idx == len(path) - 1
        if isinstance(key, int):
            if not isinstance(cur, list):
                return root
            while len(cur) <= key:
                cur.append(None)
            if last:
                cur[key] = value
            else:
                cur = ensure_container(cur, key, path[idx + 1])
        else:
            if not isinstance(cur, dict):
                return root
            if last:
                cur[key] = value
            else:
                cur = ensure_container(cur, key, path[idx + 1])
    return root


def ungron(text, as_json=False, values=False):
    stmts, code = read_statements(text, as_json)
    if code:
        return code
    if values:
        for _, value in stmts:
            if isinstance(value, (dict, list)):
                continue
            if isinstance(value, str):
                print(value)
            else:
                print(json_value(value))
        return 0
    root = None
    for path, value in stmts:
        root = assign(root, path, value)
    if root is None:
        root = {}
    try:
        print(pretty_json(root))
    except Exception as exc:
        eprint(f"failed to encode JSON: {exc}")
        return 6
    return 0


def parse_args(argv):
    p = argparse.ArgumentParser(add_help=False)
    p.add_argument("-u", "--ungron", action="store_true")
    p.add_argument("-v", "--values", action="store_true")
    p.add_argument("-c", "--colorize", action="store_true")
    p.add_argument("-m", "--monochrome", action="store_true")
    p.add_argument("-s", "--stream", action="store_true")
    p.add_argument("-k", "--insecure", action="store_true")
    p.add_argument("-x", "--proxy")
    p.add_argument("--noproxy")
    p.add_argument("-j", "--json", action="store_true")
    p.add_argument("--no-sort", action="store_true")
    p.add_argument("--version", action="store_true")
    p.add_argument("-h", "--help", action="store_true")
    p.add_argument("source", nargs="?")
    ns, extra = p.parse_known_args(argv)
    if extra:
        eprint("too many arguments")
        sys.exit(1)
    return ns


def main(argv):
    ns = parse_args(argv)
    if ns.help:
        print(HELP)
        return 0
    if ns.version:
        print("gron version dev")
        return 0

    text, code = read_input(ns.source, ns.insecure, ns.proxy, ns.noproxy)
    if code:
        return code

    if ns.ungron or ns.values:
        return ungron(text, ns.json, ns.values)

    data, code = parse_json_input(text, ns.stream)
    if code:
        return code
    color = ns.colorize and not ns.monochrome
    return print_gron(data, ns.json, color, not ns.no_sort)


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
