#!/usr/bin/env python3
import json
import os
import re
import sys


VERSION = "treemd 0.5.7"


LONG_HELP = """treemd - A modern markdown viewer combining tree-based navigation with interactive TUI.

Launch without flags for interactive mode with dual-pane interface, vim-style navigation,
syntax highlighting, and real-time search. Use flags for CLI mode to extract, filter,
and analyze markdown structure.

Examples:
  treemd README.md              # Interactive TUI mode
  treemd -l README.md           # List all headings
  treemd --tree README.md       # Show heading tree
  treemd -s Installation doc.md # Extract section
  treemd --setup-completions    # Set up shell completions

Usage: executable [OPTIONS] [FILE]... [COMMAND]

Commands:
  at-line  Show heading at specific line number
  help     Print this message or the help of the given subcommand(s)

Arguments:
  [FILE]...
          Markdown file(s) to view (.md or .markdown), directory, or '-' for stdin

Options:
  -l, --list
          List all headings in the document (non-interactive)
      --tree
          Show heading tree structure with box-drawing characters (non-interactive)
      --filter <PATTERN>
          Filter headings by text pattern (case-insensitive)
  -L, --level <LEVEL>
          Show only headings at specific level (1-6)
  -o, --output <OUTPUT>
          Output format for --list and --tree modes

          Possible values:
          - plain: Plain text output
          - json:  JSON output
          - tree:  Tree format with box-drawing

          [default: plain]
  -s, --section <HEADING>
          Extract specific section by heading name
      --count
          Count headings by level (shows statistics)
      --setup-completions
          Set up shell completions interactively
      --theme <THEME>
          Set theme for TUI mode
      --color-mode <MODE>
          Force color mode (auto, rgb, 256)

          Possible values:
          - auto: Automatically detect terminal capabilities
          - rgb:  Force RGB/true color mode
          - 256:  Force 256-color mode
      --no-images
          Disable image rendering in TUI mode
      --images
          Enable image rendering in TUI mode (override config)
  -q, --query <EXPR>
          Query expression for selecting/filtering document elements
      --query-help
          Show query language documentation and examples
      --query-output <FORMAT>
          Output format for query results
  -h, --help
          Print help (see a summary with '-h')
  -V, --version
          Print version"""


SHORT_HELP = """A markdown navigator with tree-based structural navigation

Usage: executable [OPTIONS] [FILE]... [COMMAND]

Commands:
  at-line  Show heading at specific line number
  help     Print this message or the help of the given subcommand(s)

Arguments:
  [FILE]...  Markdown file(s) to view (.md or .markdown), directory, or '-' for stdin

Options:
  -l, --list                   List all headings in the document (non-interactive)
      --tree                   Show heading tree structure with box-drawing characters (non-interactive)
      --filter <PATTERN>       Filter headings by text pattern (case-insensitive)
  -L, --level <LEVEL>          Show only headings at specific level (1-6)
  -o, --output <OUTPUT>        Output format for --list and --tree modes [default: plain] [possible values: plain, json, tree]
  -s, --section <HEADING>      Extract specific section by heading name
      --count                  Count headings by level (shows statistics)
      --setup-completions      Set up shell completions interactively
      --theme <THEME>          Set theme for TUI mode
      --color-mode <MODE>      Force color mode (auto, rgb, 256) [possible values: auto, rgb, 256]
      --no-images              Disable image rendering in TUI mode
      --images                 Enable image rendering in TUI mode (override config)
  -q, --query <EXPR>           Query expression for selecting/filtering document elements
      --query-help             Show query language documentation and examples
      --query-output <FORMAT>  Output format for query results
  -h, --help                   Print help (see more with '--help')
  -V, --version                Print version"""


AT_LINE_HELP = """Show heading at specific line number

Finds and displays the heading that appears at or before the given line number. Useful for jumping to a specific location in the document structure.

Usage: executable at-line <LINE>

Arguments:
  <LINE>
          Line number in the markdown file

Options:
  -h, --help
          Print help (see a summary with '-h')"""


QUERY_HELP = """treemd Query Language (tql)

A jq-like query language for navigating and extracting markdown structure.

ELEMENT SELECTORS
    .h, .heading    All headings (any level)
    .h1 - .h6       Headings by level
    .code           All code blocks
    .code[rust]     Code blocks by language
    .link, .a       All links
    .link[external] External links only
    .img            All images
    .table          All tables
    .list           All lists
    .blockquote     All blockquotes

FILTERS & INDEXING
    .h2[Features]       Heading containing "Features" (fuzzy)
    .h2["Installation"] Heading with exact text
    .h2[0]              First h2
    .h2[-1]             Last h2
    .h2[1:3]            h2s at index 1 and 2
    .h2[:3]             First 3 h2s

PIPES
    .h2 | text          Get heading text (strips ##)
    [.h2] | count       Count all h2s
    .code | lang        Get code block languages
    .link | url         Get link URLs

OUTPUT FORMATS (--query-output)
    plain       Human-readable text (default)
    json        Compact JSON
    json-pretty Pretty-printed JSON (alias: jsonp)
    jsonl       Line-delimited JSON (one per line)
    md          Raw markdown
    tree        Tree structure"""


def slugify(s):
    s = s.strip().lower()
    s = re.sub(r"[^a-z0-9\s-]", "", s)
    return re.sub(r"[\s-]+", "-", s).strip("-")


def heading_from_line(line):
    m = re.match(r"^(#{1,6})(?:\s+|$)(.*)$", line.rstrip())
    if not m:
        return None
    text = re.sub(r"\s+#+\s*$", "", m.group(2)).strip()
    return len(m.group(1)), text


def parse_doc(text):
    lines = text.splitlines()
    headings = []
    in_fence = False
    fence = ""
    i = 0
    while i < len(lines):
        line = lines[i]
        fm = re.match(r"^\s*(```+|~~~+)", line)
        if fm:
            mark = fm.group(1)
            if not in_fence:
                in_fence = True
                fence = mark[:3]
            elif mark.startswith(fence):
                in_fence = False
            i += 1
            continue
        if not in_fence:
            h = heading_from_line(line)
            if h:
                headings.append({"level": h[0], "text": h[1], "line": i + 1})
            elif i + 1 < len(lines) and line.strip():
                under = lines[i + 1].strip()
                if re.match(r"^=+\s*$", under) or re.match(r"^-+\s*$", under):
                    headings.append({"level": 1 if under[0] == "=" else 2, "text": line.strip(), "line": i + 1, "setext": True})
                    i += 1
        i += 1

    for idx, h in enumerate(headings):
        start = h["line"] + (1 if h.get("setext") else 0)
        end = len(lines) + 1
        direct_end = end
        for nxt in headings[idx + 1:]:
            if nxt["line"] > h["line"]:
                if nxt["level"] <= h["level"]:
                    end = nxt["line"]
                    break
                if direct_end == len(lines) + 1:
                    direct_end = nxt["line"]
        if direct_end > end:
            direct_end = end
        h["end"] = end
        h["raw_section"] = "\n".join(lines[h["line"] - 1:end - 1]).rstrip()
        h["content"] = "\n".join(lines[start:direct_end - 1]).strip()
    return lines, headings


def filtered(headings, pattern=None, level=None):
    out = headings
    if pattern:
        p = pattern.lower()
        out = [h for h in out if p in h["text"].lower()]
    if level is not None:
        out = [h for h in out if h["level"] == level]
    return out


def print_tree(headings):
    roots = build_tree(headings)
    def rec(nodes, prefix=""):
        for idx, node in enumerate(nodes):
            last = idx == len(nodes) - 1
            print(prefix + ("└──" if last else "├──") + "#" * node["level"] + " " + node["text"])
            rec(node["children"], prefix + ("   " if last else "│  "))
    rec(roots)


def build_tree(headings):
    roots = []
    stack = []
    for h in headings:
        node = dict(h)
        node["children"] = []
        while stack and stack[-1]["level"] >= node["level"]:
            stack.pop()
        if stack:
            stack[-1]["children"].append(node)
        else:
            roots.append(node)
        stack.append(node)
    return roots


def json_section(node):
    raw = node.get("content", "")
    return {
        "id": slugify(node["text"]),
        "level": node["level"],
        "title": node["text"],
        "slug": slugify(node["text"]),
        "position": {"line": node["line"] + 1, "offset": 0},
        "content": {"raw": raw, "blocks": blocks_for(raw, node["line"] + 1)},
        "children": [json_section(c) for c in node.get("children", [])],
    }


def inline_for(s):
    parts = []
    pos = 0
    for m in re.finditer(r"!?\[([^\]]*)\]\(([^)\s]+)(?:\s+\"([^\"]*)\")?\)", s):
        if m.start() > pos:
            parts.append({"type": "text", "value": s[pos:m.start()]})
        if s[m.start()] == "!":
            parts.append({"type": "image", "alt": m.group(1), "src": m.group(2), "title": m.group(3)})
        else:
            parts.append({"type": "link", "text": m.group(1), "url": m.group(2), "title": m.group(3)})
        pos = m.end()
    if pos < len(s):
        parts.append({"type": "text", "value": s[pos:]})
    return parts or [{"type": "text", "value": s}]


def blocks_for(raw, base_line=1):
    blocks = []
    lines = raw.splitlines()
    i = 0
    while i < len(lines):
        line = lines[i]
        fm = re.match(r"^\s*```(.*)$", line)
        if fm:
            lang = fm.group(1).strip() or None
            body = []
            i += 1
            while i < len(lines) and not re.match(r"^\s*```", lines[i]):
                body.append(lines[i])
                i += 1
            blocks.append({"type": "code", "language": lang, "content": "\n".join(body), "start_line": base_line + i, "end_line": base_line + i})
        elif re.match(r"^\s*[-*+]\s+\[[ xX]\]\s+", line) or re.match(r"^\s*[-*+]\s+", line):
            items = []
            while i < len(lines) and re.match(r"^\s*[-*+]\s+", lines[i]):
                m = re.match(r"^\s*[-*+]\s+(?:\[([ xX])\]\s+)?(.*)$", lines[i])
                item = {"content": m.group(2), "inline": inline_for(m.group(2))}
                if m.group(1) is not None:
                    item["checked"] = m.group(1).lower() == "x"
                items.append(item)
                i += 1
            blocks.append({"type": "list", "ordered": False, "items": items})
            continue
        elif line.strip():
            para = [line.strip()]
            i += 1
            while i < len(lines) and lines[i].strip() and not heading_from_line(lines[i]) and not re.match(r"^\s*```", lines[i]):
                para.append(lines[i].strip())
                i += 1
            content = " ".join(para)
            blocks.append({"type": "paragraph", "content": content, "inline": inline_for(content)})
            continue
        i += 1
    return blocks


def list_json(text, headings):
    roots = build_tree(headings)
    doc = {
        "document": {
            "metadata": {
                "source": None,
                "headingCount": len(headings),
                "maxDepth": max([h["level"] for h in headings], default=0),
                "wordCount": len(re.findall(r"\S+", text)),
            },
            "sections": [json_section(r) for r in roots],
        }
    }
    print(json.dumps(doc, indent=2))


def all_code(text):
    out = []
    for m in re.finditer(r"(?ms)^```([^\n`]*)\n(.*?)\n```", text):
        out.append({"type": "code", "language": m.group(1).strip() or None, "content": m.group(2)})
    return out


def all_links(text):
    links = []
    for m in re.finditer(r"(?<!!)\[([^\]]+)\]\(([^)\s]+)(?:\s+\"([^\"]*)\")?\)", text):
        url = m.group(2)
        typ = "external" if re.match(r"^[a-zA-Z][a-zA-Z0-9+.-]*://", url) else "relative"
        links.append({"type": "link", "text": m.group(1), "url": url, "link_type": typ})
    return links


def all_images(text):
    imgs = []
    for m in re.finditer(r"!\[([^\]]*)\]\(([^)\s]+)(?:\s+\"([^\"]*)\")?\)", text):
        imgs.append({"type": "image", "alt": m.group(1), "src": m.group(2)})
    return imgs


def list_count(text):
    return len(re.findall(r"(?m)^\s*[-*+]\s+", text))


def query(expr, fmt, text, headings):
    expr = expr.strip()
    pipe = [p.strip() for p in expr.split("|")]
    selector = pipe[0].strip()
    collection = selector.startswith("[") and selector.endswith("]")
    if collection:
        selector = selector[1:-1].strip()
    items = select_query(selector, text, headings)
    for fn in pipe[1:]:
        if fn in ("text",):
            items = [plain_text(x) for x in items]
        elif fn in ("url", "href"):
            items = [x.get("url", "") for x in items if isinstance(x, dict)]
        elif fn == "src":
            items = [x.get("src", "") for x in items if isinstance(x, dict)]
        elif fn == "lang":
            items = [x.get("language") or "" for x in items if isinstance(x, dict)]
        elif fn in ("count", "length", "len", "size"):
            print(len(items))
            return
        elif fn == "stats":
            print_stats(text, headings)
            return
        elif fn == "levels":
            print_counts(headings)
            return
        elif fn.startswith("limit(") or fn.startswith("take("):
            n = int(re.search(r"\((\d+)\)", fn).group(1))
            items = items[:n]
        elif fn.startswith("skip(") or fn.startswith("drop("):
            n = int(re.search(r"\((\d+)\)", fn).group(1))
            items = items[n:]
        elif fn == "first":
            items = items[:1]
        elif fn == "last":
            items = items[-1:]
        elif fn.startswith("select") or fn.startswith("where") or fn.startswith("filter"):
            cm = re.search(r"contains\([\"']([^\"']+)[\"']\)", fn)
            if cm:
                needle = cm.group(1).lower()
                items = [x for x in items if needle in item_text(x).lower()]
        elif fn.startswith("group_by"):
            key = re.search(r"\([\"']?([^\"')]+)", fn).group(1)
            groups = {}
            for x in items:
                groups.setdefault(x.get(key), []).append(x)
            for key in sorted(groups):
                print(f"h{key}: " + "\n".join(item_text(x) for x in groups[key]))
            return
    output_items(items, fmt, headings)


def select_query(sel, text, headings):
    if sel in (".", ""):
        return [{"type": "document", "text": text}]
    m = re.match(r"\.h(?:eading)?([1-6])?(?:\[(.*?)\])?$", sel)
    if m:
        lev = int(m.group(1)) if m.group(1) else None
        items = [{"type": "heading", "level": h["level"], "text": h["text"], "line": h["line"], "raw_section": h["raw_section"]} for h in headings if lev is None or h["level"] == lev]
        filt = m.group(2)
        return apply_bracket(items, filt)
    m = re.match(r"\.code(?:\[(.*?)\])?$", sel)
    if m:
        items = all_code(text)
        lang = m.group(1)
        if lang:
            items = [x for x in items if (x.get("language") or "").lower() == lang.strip("\"'").lower()]
        return items
    m = re.match(r"\.(?:link|a)(?:\[(.*?)\])?$", sel)
    if m:
        items = all_links(text)
        f = m.group(1)
        if f == "external":
            items = [x for x in items if x["link_type"] == "external"]
        return items
    if sel == ".img":
        return all_images(text)
    return []


def apply_bracket(items, filt):
    if not filt:
        return items
    f = filt.strip()
    if re.match(r"^-?\d+$", f):
        idx = int(f)
        return [items[idx]] if -len(items) <= idx < len(items) else []
    m = re.match(r"^(-?\d*)?:(-?\d*)?$", f)
    if m:
        a = int(m.group(1)) if m.group(1) else None
        b = int(m.group(2)) if m.group(2) else None
        return items[a:b]
    exact = len(f) >= 2 and f[0] in "\"'" and f[-1] == f[0]
    val = f[1:-1] if exact else f
    if exact:
        return [x for x in items if item_text(x) == val or x.get("text") == val]
    return [x for x in items if val.lower() in item_text(x).lower()]


def item_text(x):
    if isinstance(x, str):
        return x
    if x.get("type") == "heading":
        return "#" * x["level"] + " " + x["text"]
    if x.get("type") == "code":
        lang = x.get("language") or ""
        return "```" + lang + "\n" + x.get("content", "") + "\n```"
    if x.get("type") == "link":
        return f"[{x.get('text','')}]({x.get('url','')})"
    if x.get("type") == "image":
        return f"![{x.get('alt','')}]({x.get('src','')})"
    return x.get("text", "")


def plain_text(x):
    if isinstance(x, str):
        return x
    if x.get("type") == "heading":
        return x.get("text", "")
    if x.get("type") == "code":
        return x.get("content", "")
    if x.get("type") == "link":
        return x.get("text", "")
    if x.get("type") == "image":
        return x.get("alt", "")
    return x.get("text", "")


def output_items(items, fmt, headings):
    if fmt in ("json", "json-pretty"):
        if fmt == "json":
            print(json.dumps(strip_internal(items), separators=(",", ":")))
        else:
            print(json.dumps(strip_internal(items), indent=2))
    elif fmt == "jsonl":
        for item in strip_internal(items):
            print(json.dumps(item, separators=(",", ":")))
    elif fmt == "md":
        print("\n\n".join(x.get("raw_section", item_text(x)) if isinstance(x, dict) else str(x) for x in items))
    elif fmt == "tree":
        hs = [h for h in headings if any(isinstance(x, dict) and x.get("type") == "heading" and x.get("line") == h["line"] for x in items)]
        print_tree(hs)
    else:
        for item in items:
            print(item_text(item))


def strip_internal(items):
    out = []
    for x in items:
        if isinstance(x, dict):
            y = dict(x)
            y.pop("raw_section", None)
            out.append(y)
        else:
            out.append(x)
    return out


def print_counts(headings):
    counts = {}
    for h in headings:
        counts[h["level"]] = counts.get(h["level"], 0) + 1
    print("Heading counts:")
    for lev in range(1, 7):
        if counts.get(lev):
            print(f"  {'#' * lev}: {counts[lev]}")
    print()
    print(f"Total: {sum(counts.values())}")


def print_stats(text, headings):
    table_count = len(re.findall(r"(?m)^\s*\|.*\|\s*$", text)) // 2
    word_count = len(re.findall(r"\S+", text))
    print(f"headings: {len(headings)}")
    print(f"code_blocks: {len(all_code(text))}")
    print(f"links: {len(all_links(text))}")
    print(f"images: {len(all_images(text))}")
    print(f"tables: {table_count}")
    print(f"lists: {1 if list_count(text) else 0}")
    print(f"words: {word_count}")


def read_input(files):
    if files and files[0] == "-":
        return sys.stdin.read()
    if files:
        path = files[0]
        try:
            with open(path, "r", encoding="utf-8") as f:
                return f.read()
        except OSError as e:
            print(f"Error reading input: I/O error: {e.strerror} (os error {e.errno})", file=sys.stderr)
            sys.exit(1)
    if not sys.stdin.isatty():
        return sys.stdin.read()
    return ""


def value_after(args, names, default=None):
    for i, a in enumerate(args):
        if a in names and i + 1 < len(args):
            return args[i + 1]
        for n in names:
            if a.startswith(n + "="):
                return a.split("=", 1)[1]
    return default


def files_from_args(args):
    files = []
    skip = False
    opts_with_val = {"--filter", "-L", "--level", "-o", "--output", "-s", "--section", "-q", "--query", "--query-output", "--theme", "--color-mode"}
    for i, a in enumerate(args):
        if skip:
            skip = False
            continue
        if a in opts_with_val:
            skip = True
            continue
        if any(a.startswith(o + "=") for o in opts_with_val if o.startswith("--")):
            continue
        if a.startswith("-"):
            continue
        if a in ("at-line", "help"):
            continue
        files.append(a)
    return files


def clap_invalid(opt, val, vals):
    print(f"error: invalid value '{val}' for '{opt} <{opt.lstrip('-').upper()}>'", file=sys.stderr)
    print(f"  [possible values: {', '.join(vals)}]\n", file=sys.stderr)
    print("For more information, try '--help'.", file=sys.stderr)
    sys.exit(2)


def main():
    args = sys.argv[1:]
    if args[:1] == ["help"]:
        print(LONG_HELP)
        return
    if args[:1] == ["at-line"]:
        if len(args) == 1 or args[1] in ("-h", "--help"):
            print(AT_LINE_HELP)
        return
    if "-V" in args or "--version" in args:
        print(VERSION)
        return
    if "--query-help" in args:
        print(QUERY_HELP)
        return
    if "--help" in args:
        print(LONG_HELP)
        return
    if "-h" in args:
        print(SHORT_HELP)
        return
    cmode = value_after(args, ["--color-mode"])
    if cmode and cmode not in ("auto", "rgb", "256"):
        clap_invalid("--color-mode", cmode, ["auto", "rgb", "256"])
    outfmt = value_after(args, ["-o", "--output"], "plain")
    if outfmt not in ("plain", "json", "tree"):
        print(f"error: invalid value '{outfmt}' for '--output <OUTPUT>'", file=sys.stderr)
        print("  [possible values: plain, json, tree]\n", file=sys.stderr)
        print("For more information, try '--help'.", file=sys.stderr)
        sys.exit(2)
    qfmt = value_after(args, ["--query-output"], "plain")
    if qfmt == "jsonp":
        print("Error: Unknown output format: jsonp")
        sys.exit(1)
    if "--setup-completions" in args:
        print("Shell completions setup is not available in this build.")
        return
    cli = any(a in args for a in ("-l", "--list", "--tree", "--count")) or "-q" in args or "--query" in args or "-s" in args or "--section" in args
    files = files_from_args(args)
    if not cli:
        if not files and not sys.stdin.isatty():
            print("# Select a file")
            return
        print("Failed to enable raw mode: Cannot open /dev/tty: No such device or address (os error 6). Interactive mode requires a terminal.", file=sys.stderr)
        sys.exit(1)
    text = read_input(files)
    lines, headings = parse_doc(text)
    try:
        level = value_after(args, ["-L", "--level"])
        level = int(level) if level is not None else None
    except ValueError:
        level = None
    pattern = value_after(args, ["--filter"])
    heads = filtered(headings, pattern, level)
    if "-q" in args or "--query" in args:
        expr = value_after(args, ["-q", "--query"], "")
        query(expr, qfmt, text, headings)
    elif "-s" in args or "--section" in args:
        sec = value_after(args, ["-s", "--section"], "")
        for h in headings:
            if h["text"].lower() == sec.lower():
                print(h["raw_section"])
                return
        print(f"Section '{sec}' not found")
        sys.exit(1)
    elif "--count" in args:
        print_counts(heads)
    elif "--tree" in args:
        print_tree(heads)
    elif "-l" in args or "--list" in args:
        if outfmt == "json":
            list_json(text, heads)
        elif outfmt == "tree":
            print("Use --tree for tree output")
            sys.exit(1)
        else:
            for h in heads:
                print("#" * h["level"] + " " + h["text"])


if __name__ == "__main__":
    main()
