#!/usr/bin/env python3
import argparse, json, math, re, sys, shlex, time, datetime
from collections import OrderedDict
from pathlib import Path

VERSION = "ag 0.19.6"

class Null:
    def __repr__(self): return "None"
NONE = Null()

def split_top(s, sep=','):
    out=[]; cur=[]; q=None; esc=False; depth=0; br=0
    for ch in s:
        if esc:
            cur.append(ch); esc=False; continue
        if ch == '\\' and q:
            cur.append(ch); esc=True; continue
        if q:
            cur.append(ch)
            if ch == q: q=None
            continue
        if ch in ('"', "'"):
            q=ch; cur.append(ch); continue
        if ch == '(':
            depth += 1
        elif ch == ')':
            depth -= 1
        elif ch == '[':
            br += 1
        elif ch == ']':
            br -= 1
        if ch == sep and depth == 0 and br == 0:
            out.append(''.join(cur).strip()); cur=[]
        else:
            cur.append(ch)
    out.append(''.join(cur).strip())
    return [x for x in out if x != '']

def split_pipe(s):
    out=[]; cur=[]; q=None; esc=False
    for ch in s:
        if esc:
            cur.append(ch); esc=False; continue
        if ch == '\\' and q:
            cur.append(ch); esc=True; continue
        if q:
            cur.append(ch)
            if ch == q: q=None
            continue
        if ch in ('"', "'"):
            q=ch; cur.append(ch); continue
        if ch == '|':
            out.append(''.join(cur).strip()); cur=[]
        else:
            cur.append(ch)
    out.append(''.join(cur).strip())
    return out

def unquote(s):
    s=s.strip()
    if len(s)>=2 and s[0] == s[-1] and s[0] in "\"'":
        try: return bytes(s[1:-1], 'utf-8').decode('unicode_escape')
        except Exception: return s[1:-1]
    return s

def convert(v):
    if v is None: return None
    if isinstance(v, (int,float,bool,list,dict)): return v
    if isinstance(v, str):
        if v == "null": return None
        if re.fullmatch(r'-?\d+', v):
            try: return int(v)
            except Exception: pass
        if re.fullmatch(r'-?(\d+\.\d*|\d*\.\d+)([eE][+-]?\d+)?|-?\d+[eE][+-]?\d+', v):
            try: return float(v)
            except Exception: pass
    return v

def field_path(path):
    path=path.strip()
    if path.startswith('["') and path.endswith('"]'): return [path[2:-2]]
    parts=[]; i=0
    for part in path.split('.'):
        if part == '': continue
        m=re.match(r'^([^\[]+)', part)
        if m: parts.append(m.group(1))
        for idx in re.findall(r'\[(-?\d+)\]', part):
            parts.append(int(idx))
    return parts or [path]

def get_field(row, path):
    if path in row: return row[path]
    cur=row
    for p in field_path(path):
        try:
            if isinstance(p, int):
                cur = cur[p]
            elif isinstance(cur, dict):
                cur = cur[p]
            else:
                return None
        except Exception:
            return None
    return cur

def set_field(row, name, val): row[name.strip()] = val

def val_str(v):
    if v is None: return "None"
    if isinstance(v, bool): return "true" if v else "false"
    if isinstance(v, float) and v.is_integer(): return str(int(v))
    if isinstance(v, list): return "[" + ", ".join(val_str(x) for x in v) + "]"
    if isinstance(v, dict): return "{" + ",".join(f"{k}:{val_str(vv)}" for k,vv in v.items()) + "}"
    return str(v)

def json_ready(v):
    return v

def parse_logfmt(s):
    try:
        toks=shlex.split(str(s))
    except Exception:
        toks=str(s).split()
    d=OrderedDict()
    for t in toks:
        if '=' not in t: continue
        k,v=t.split('=',1)
        d[k]=convert(v)
    if not d: raise ValueError("bad logfmt")
    return d

def parse_json_obj(s):
    obj=json.loads(s)
    if not isinstance(obj, dict): raise ValueError("Expected JSON object")
    return obj

def match_parse(pattern, text):
    parts=pattern.split('*')
    pos=0; caps=[]
    if not pattern.startswith('*'):
        lit=parts[0]
        if not text.startswith(lit): return None
        pos=len(lit); parts=parts[1:]
    for i, lit in enumerate(parts):
        last = (i == len(parts)-1)
        if lit == '':
            if last:
                caps.append(text[pos:])
            continue
        # whitespace in pattern matches arbitrary whitespace
        lit_re = re.escape(lit).replace(r'\ ', r'\s+')
        m=re.search(lit_re, text[pos:])
        if not m: return None
        caps.append(text[pos:pos+m.start()])
        pos += m.end()
    if not pattern.endswith('*') and parts:
        # final literal already consumed; require no extra only for exact patterns
        pass
    return caps

def filter_match(expr, line):
    expr=expr.strip()
    if not expr or expr == '*': return True
    def atom(tok):
        tok=tok.strip()
        if tok.startswith('"') and tok.endswith('"'): return unquote(tok) in line
        pat=tok.lower()
        if '*' in pat:
            return re.search('^'+re.escape(pat).replace(r'\*','.*')+'$', line.lower()) is not None or re.search(re.escape(pat).replace(r'\*','.*'), line.lower()) is not None
        return pat in line.lower()
    # simple recursive-ish handling
    e=expr
    # strip wrapping parens
    if e.startswith('(') and e.endswith(')'): e=e[1:-1].strip()
    parts=re.split(r'\s+OR\s+', e, flags=re.I)
    if len(parts)>1: return any(filter_match(p,line) for p in parts)
    parts=re.split(r'\s+AND\s+', e, flags=re.I)
    if len(parts)>1: return all(filter_match(p,line) for p in parts)
    if re.match(r'(?i)^NOT\s+', e): return not filter_match(re.sub(r'(?i)^NOT\s+','',e), line)
    return atom(e)

def translate_expr(expr):
    e=expr.strip()
    e=re.sub(r'(?<![<>=!])=(?!=)', '==', e)
    e=e.replace('<>', '!=')
    e=re.sub(r'\bAND\b', 'and', e, flags=re.I)
    e=re.sub(r'\bOR\b', 'or', e, flags=re.I)
    e=e.replace('&&',' and ').replace('||',' or ')
    e=re.sub(r'!\s*(?!=)', ' not ', e)
    return e

class Env(dict):
    def __init__(self, row):
        super().__init__()
        self.row=row
        funcs = {n:getattr(math,n) for n in dir(math) if not n.startswith('_')}
        funcs.update({
            'abs':abs, 'round':round, 'concat':lambda *a: ''.join(val_str(x) for x in a),
            'contains':lambda h,n: str(n) in str(h), 'length':lambda x: len(str(x)),
            'num':lambda x: float(x) if ('.' in str(x)) else int(x),
            'parseHex':lambda x: int(str(x),16), 'substring':lambda s,a,b=None: str(s)[int(a): None if b is None else int(b)],
            'toLowerCase':lambda s: str(s).lower(), 'toUpperCase':lambda s: str(s).upper(),
            'isNull':lambda x: x is None, 'isEmpty':lambda x: x is None or str(x)=='',
            'isBlank':lambda x: x is None or str(x).strip()=='', 'isNumeric':lambda x: isnum(x),
            'toDegrees':math.degrees, 'toRadians':math.radians, 'now':lambda: datetime.datetime.now().isoformat(),
            'parseDate':lambda x: parse_date(x), 'if_':lambda c,a,b: a if c else b,
        })
        self.update(funcs)
    def __missing__(self, key):
        if key == 'null': return None
        if key == 'true': return True
        if key == 'false': return False
        return get_field(self.row, key)

def isnum(x):
    try: float(x); return True
    except Exception: return False

def parse_date(x):
    s=str(x)
    for fmt in ("%Y-%m-%dT%H:%M:%S.%fZ","%Y-%m-%dT%H:%M:%SZ","%Y-%m-%d %H:%M:%S"):
        try: return datetime.datetime.strptime(s, fmt).timestamp()
        except Exception: pass
    try: return datetime.datetime.fromisoformat(s.replace('Z','+00:00')).timestamp()
    except Exception: return None

def eval_expr(expr, row):
    e=translate_expr(expr)
    e=re.sub(r'\bif\s*\(', 'if_(', e)
    extra={}
    def repl_path(m):
        name=m.group(0)
        repl="__f%d" % len(extra)
        extra[repl]=get_field(row,name)
        return repl
    e=re.sub(r'\b[A-Za-z_]\w*(?:(?:\.[A-Za-z_]\w*)|(?:\[-?\d+\]))+', repl_path, e)
    try:
        env=Env(row); env.update(extra)
        return eval(e, {"__builtins__":{}}, env)
    except Exception:
        # field or literal fallback
        if (e.startswith('"') and e.endswith('"')) or (e.startswith("'") and e.endswith("'")): return unquote(e)
        v=get_field(row,e)
        if v is not None: return v
        return convert(e)

def apply_ops(rows, ops):
    aggregate=False
    for op in ops:
        if not op: continue
        low=op.lower().strip()
        new=[]
        if low.startswith('json'):
            m=re.search(r'\bfrom\s+(.+)$', op, re.I)
            fld=m.group(1).strip() if m else None
            for r in rows:
                src=get_field(r,fld) if fld else r.get('_raw','')
                try:
                    obj=parse_json_obj(src)
                    nr=OrderedDict((k,v) for k,v in r.items() if k!='_raw')
                    nr.update(obj); new.append(nr)
                except Exception as e:
                    print(f"error: Expected JSON, found {src}", file=sys.stderr)
            rows=new
        elif low.startswith('logfmt'):
            m=re.search(r'\bfrom\s+(.+)$', op, re.I)
            fld=m.group(1).strip() if m else None
            for r in rows:
                src=get_field(r,fld) if fld else r.get('_raw','')
                try:
                    obj=parse_logfmt(src)
                    nr=OrderedDict((k,v) for k,v in r.items() if k!='_raw')
                    nr.update(obj); new.append(nr)
                except Exception:
                    pass
            rows=new
        elif low.startswith('split'):
            m=re.match(r'split(?:\(([^)]*)\))?(?:\s+on\s+("[^"]*"|\'[^\']*\'|\S+))?(?:\s+as\s+(\w+))?', op, re.I)
            inf=(m.group(1).strip() if m and m.group(1) else None)
            sep=unquote(m.group(2)) if m and m.group(2) else ','
            outf=(m.group(3) if m and m.group(3) else (inf if inf else '_split'))
            for r in rows:
                src=get_field(r,inf) if inf else r.get('_raw','')
                nr=OrderedDict((k,v) for k,v in r.items() if k!='_raw')
                nr[outf]=str(src).split(sep); new.append(nr)
            rows=new
        elif low.startswith('parse regex'):
            m=re.match(r'parse\s+regex\s+("[^"]*"|\'[^\']*\')(\s+from\s+(\S+))?.*', op, re.I)
            if not m: continue
            rg=unquote(m.group(1)); fld=m.group(3)
            nodrop='nodrop' in low
            cre=re.compile(rg)
            for r in rows:
                src=str(get_field(r,fld) if fld else r.get('_raw',''))
                mm=cre.search(src)
                if mm:
                    nr=OrderedDict((k,v) for k,v in r.items() if k!='_raw')
                    nr.update({k:convert(v) for k,v in mm.groupdict().items()}); new.append(nr)
                elif nodrop: new.append(r)
            rows=new
        elif low.startswith('parse '):
            m=re.match(r'parse\s+("[^"]*"|\'[^\']*\')(\s+from\s+(\S+))?\s+as\s+(.+)', op, re.I)
            if not m: continue
            pat=unquote(m.group(1)); fld=m.group(3); rest=m.group(4)
            nodrop='nodrop' in low; noconv='noconvert' in low
            rest=re.sub(r'\s+(nodrop|noconvert)\b.*','',rest, flags=re.I)
            names=[x.strip() for x in rest.split(',')]
            for r in rows:
                src=str(get_field(r,fld) if fld else r.get('_raw',''))
                caps=match_parse(pat, src)
                if caps is not None and len(caps)>=len(names):
                    nr=OrderedDict((k,v) for k,v in r.items() if k!='_raw')
                    for n,v in zip(names,caps):
                        nr[n]=v if noconv else convert(v.strip())
                    new.append(nr)
                elif nodrop: new.append(r)
            rows=new
        elif low.startswith('fields'):
            mm=re.match(r'fields\s+(only|except|\+|-)?\s*(.*)', op, re.I)
            mode=(mm.group(1) or '+').lower(); fields=[x.strip() for x in mm.group(2).split(',') if x.strip()]
            only=mode in ('only','+')
            for r in rows:
                if only:
                    nr=OrderedDict()
                    for f in fields:
                        v=get_field(r,f)
                        if v is not None:
                            root = f.split('.',1)[0].split('[',1)[0]
                            if root != f and root in r and isinstance(r[root], dict):
                                nr[root]=r[root]
                            elif '[' not in f:
                                nr[f]=v
                else:
                    nr=OrderedDict((k,v) for k,v in r.items() if k not in fields and k!='_raw')
                new.append(nr)
            rows=new
        elif low.startswith('where '):
            cond=op[6:].strip()
            rows=[r for r in rows if bool(eval_expr(cond,r))]
        elif low.startswith('limit '):
            n=int(op.split()[1]); rows=rows[:n] if n>=0 else rows[n:]
        elif low.startswith('sort by '):
            spec=op[8:].strip(); desc=False
            if re.search(r'\s+desc$', spec, re.I): desc=True; spec=re.sub(r'\s+desc$','',spec,flags=re.I).strip()
            if re.search(r'\s+asc$', spec, re.I): spec=re.sub(r'\s+asc$','',spec,flags=re.I).strip()
            keys=split_top(spec)
            rows=sorted(rows, key=lambda r: tuple(eval_expr(k,r) for k in keys), reverse=desc)
        elif low.startswith('total'):
            mm=re.match(r'total\((.*)\)(?:\s+as\s+(\S+))?', op, re.I)
            if mm:
                expr=mm.group(1).strip(); name=mm.group(2) or '_total'; running=0
                for r in rows:
                    nr=OrderedDict((k,v) for k,v in r.items() if k!='_raw')
                    try: running += float(eval_expr(expr,nr) or 0)
                    except Exception: pass
                    nr[name]=int(running) if running.is_integer() else running
                    new.append(nr)
                rows=new
        elif is_aggregate(op):
            rows=aggregate_rows(rows, op); aggregate=True
        elif ' as ' in low:
            m=re.match(r'(.+)\s+as\s+(\S+)$', op, re.I)
            if m:
                expr,name=m.group(1).strip(),m.group(2).strip()
                for r in rows:
                    nr=OrderedDict((k,v) for k,v in r.items() if k!='_raw')
                    nr[name]=eval_expr(expr,nr); new.append(nr)
                rows=new
    return rows, aggregate

def is_aggregate(op):
    return bool(re.search(r'\b(count|sum|average|avg|min|max|p\d+|pct\d+|count_distinct)\b', op, re.I)) and not op.lower().startswith(('where','fields'))

def aggregate_rows(rows, op):
    m=re.search(r'\s+by\s+(.+)$', op, re.I)
    by=split_top(m.group(1)) if m else []
    agpart=op[:m.start()].strip() if m else op.strip()
    ags=split_top(agpart)
    groups=OrderedDict()
    for r in rows:
        key=tuple(eval_expr(b,r) for b in by)
        groups.setdefault(key, []).append(r)
    if not groups and not by: groups[tuple()]=[]
    out=[]
    for key, rs in groups.items():
        nr=OrderedDict()
        for b,v in zip(by,key):
            nr[b]=v
        for a in ags:
            name=None
            mm=re.match(r'(.+?)\s+as\s+(\S+)$', a, re.I)
            if mm: a,name=mm.group(1).strip(),mm.group(2).strip()
            al=a.lower()
            if al.startswith('count_distinct'):
                expr=a[a.find('(')+1:a.rfind(')')]; vals={val_str(eval_expr(expr,r)) for r in rs}; nr[name or 'count_distinct']=len(vals)
            elif al.startswith('count'):
                cnt=len(rs)
                if '(' in a:
                    expr=a[a.find('(')+1:a.rfind(')')]; cnt=sum(1 for r in rs if eval_expr(expr,r))
                nr[name or '_count']=cnt
            elif al.startswith(('sum','average','avg','min','max')) or re.match(r'(p|pct)\d+', al):
                func=al.split('(')[0]; expr=a[a.find('(')+1:a.rfind(')')]
                vals=[]
                for r in rs:
                    v=eval_expr(expr,r)
                    try: vals.append(float(v))
                    except Exception: pass
                col=name
                if not col:
                    col={'sum':'_sum','average':'_average','avg':'_average','min':'_min','max':'_max'}.get(func, func.replace('pct','p'))
                if func == 'sum': val=sum(vals)
                elif func in ('average','avg'): val=(sum(vals)/len(vals) if vals else None)
                elif func == 'min': val=(min(vals) if vals else None)
                elif func == 'max': val=(max(vals) if vals else None)
                else:
                    pct=int(re.findall(r'\d+',func)[0]); vals=sorted(vals)
                    val=vals[int((pct/100.0)*(len(vals)-1))] if vals else None
                nr[col]=int(val) if isinstance(val,float) and val.is_integer() else val
            elif al.startswith('total'):
                expr=a[a.find('(')+1:a.rfind(')')]; nr[name or '_total']=sum(float(eval_expr(expr,r) or 0) for r in rs)
        out.append(nr)
    return out

def legacy(rows):
    materialized=[]
    widths=[]
    for r in rows:
        parts=[f"[{k}={val_str(v)}]" for k,v in sorted(r.items()) if k != '_raw']
        materialized.append(parts)
        for i,p in enumerate(parts):
            if i == len(widths): widths.append(0)
            widths[i]=max(widths[i], len(p))
    lines=[]
    for parts in materialized:
        line=""
        for i,p in enumerate(parts):
            if i == len(parts)-1:
                line += p
            else:
                line += p + (" " * max(1, widths[i] - len(p) + 8))
        lines.append(line.rstrip())
    return "\n".join(lines)

def table(rows):
    if not rows: return ""
    cols=list(rows[0].keys())
    widths=[max(len(str(c)), *(len(val_str(r.get(c))) for r in rows)) for c in cols]
    widths=[w+8 for w in widths]
    header="".join(str(c).ljust(widths[i]) for i,c in enumerate(cols)).rstrip()
    sep='-'*max(len(header), sum(widths))
    body=["".join(val_str(r.get(c)).ljust(widths[i]) for i,c in enumerate(cols)).rstrip() for r in rows]
    return "\n".join([header,sep]+body)

def render(rows, aggregate, output):
    if output.startswith('format='):
        fmt=output[len('format='):]
        return "\n".join(fmt.format(**{k:val_str(v) for k,v in r.items() if k!='_raw'}) for r in rows)
    if output == 'json':
        if aggregate:
            return json.dumps(rows, separators=(',',':'))
        return "\n".join(json.dumps(OrderedDict((k,v) for k,v in r.items() if k!='_raw'), separators=(',',':')) for r in rows)
    if output == 'logfmt':
        return "\n".join(" ".join(f"{k}={val_str(v)}" for k,v in sorted(r.items()) if k!='_raw') for r in rows)
    if aggregate:
        return table(rows)
    # raw pass-through if no fields but _raw exists
    if all(list(r.keys()) == ['_raw'] for r in rows):
        return "\n".join(r['_raw'] for r in rows)
    return legacy(rows)

def load_aliases(alias_dir=None):
    dirs=[]
    if alias_dir:
        dirs=[Path(alias_dir)]
    else:
        p=Path.cwd()
        dirs=[x/'.agrind-aliases' for x in [p]+list(p.parents)]
    aliases={}
    for d in dirs:
        if not d.is_dir(): continue
        for f in d.iterdir():
            if not f.is_file(): continue
            try: txt=f.read_text()
            except Exception: continue
            km=re.search(r'keyword\s*=\s*"([^"]+)"', txt)
            tm=re.search(r'template\s*=\s*"""(.*?)"""', txt, re.S) or re.search(r'template\s*=\s*"([^"]*)"', txt, re.S)
            if km and tm:
                aliases[km.group(1).strip()] = tm.group(1).strip()
    return aliases

def main():
    p=argparse.ArgumentParser(prog='executable', add_help=False, formatter_class=argparse.RawTextHelpFormatter)
    p.add_argument('-f','--file'); p.add_argument('-m','--format', dest='fmt')
    p.add_argument('-o','--output', default='legacy'); p.add_argument('-a','--alias-dir')
    p.add_argument('--no-alias', action='store_true'); p.add_argument('-h','--help', action='store_true')
    p.add_argument('-V','--version', action='store_true'); p.add_argument('query', nargs='?')
    args=p.parse_args()
    if args.version:
        print(VERSION); return 0
    if args.help:
        print("Usage: executable [OPTIONS] [QUERY]\n\nArguments:\n  [QUERY]  The query\n\nOptions:\n  -f, --file <FILE>            Optionally reads from a file instead of Stdin\n  -m, --format <FORMAT>        DEPRECATED. Use -o format=... instead. Provide a Rust std::fmt string to format output\n  -o, --output <OUTPUT>        Set output format. One of (json|legacy|format=<rust fmt str>|logfmt)\n  -a, --alias-dir <ALIAS_DIR>  Specifies an alternative directory to use for aliases. Defaults to `.agrind-aliases` in all parent directories.\n      --no-alias               Disables aliases\n  -h, --help                   Print help (see more with '--help')\n  -V, --version                Print version\n\nFor more details + docs, see https://github.com/rcoh/angle-grinder")
        return 0
    output = 'format='+args.fmt if args.fmt else args.output
    data = open(args.file).read().splitlines() if args.file else sys.stdin.read().splitlines()
    query=args.query or '*'
    parts=split_pipe(query)
    filt=parts[0] if parts else '*'; ops=parts[1:]
    if not args.no_alias:
        aliases=load_aliases(args.alias_dir)
        expanded=[]
        for op in ops:
            key=op.strip()
            if key in aliases:
                expanded.extend(split_pipe(aliases[key]))
            else:
                expanded.append(op)
        ops=expanded
    rows=[OrderedDict([('_raw', line)]) for line in data if filter_match(filt,line)]
    rows,agg=apply_ops(rows, ops)
    txt=render(rows, agg, output)
    if txt: print(txt)
    return 0

if __name__ == '__main__':
    sys.exit(main())
