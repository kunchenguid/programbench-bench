#!/usr/bin/env python3
import sys, os, math, re, time, random

VERSION_LINE = "LuaJIT 2.1.1772570160 -- Copyright (C) 2005-2026 Mike Pall. https://luajit.org/"

class LuaError(Exception):
    pass

class ReturnEx(Exception):
    def __init__(self, vals): self.vals = vals
class BreakEx(Exception): pass

def lua_truth(v): return not (v is None or v is False)
def lua_type(v):
    if v is None: return "nil"
    if isinstance(v, bool): return "boolean"
    if isinstance(v, (int,float)): return "number"
    if isinstance(v, str): return "string"
    if isinstance(v, LuaTable): return "table"
    if callable(v): return "function"
    return "userdata"
def num(v):
    if isinstance(v, (int,float)): return v
    if isinstance(v, str):
        try:
            if re.match(r"^[+-]?\d+$", v): return int(v)
            return float(v)
        except Exception: pass
    raise LuaError("attempt to perform arithmetic on a %s value" % lua_type(v))
def lua_str(v):
    if v is None: return "nil"
    if v is True: return "true"
    if v is False: return "false"
    if isinstance(v, float) and v.is_integer(): return str(int(v))
    return str(v)

class LuaTable:
    def __init__(self, init=None):
        self.d = {}
        if init:
            for k,v in init.items(): self.d[k]=v
    def get(self,k): return self.d.get(k, None)
    def set(self,k,v):
        if k is None: raise LuaError("table index is nil")
        if v is None: self.d.pop(k, None)
        else: self.d[k]=v
    def length(self):
        i=1
        while self.d.get(i,None) is not None: i+=1
        return i-1
    def array(self): return [self.d.get(i) for i in range(1,self.length()+1)]
    def __str__(self): return "table: 0x%x" % (id(self)&0xffffffff)

class Env:
    def __init__(self, parent=None): self.vars={}; self.parent=parent
    def get(self, name):
        if name in self.vars: return self.vars[name]
        if self.parent: return self.parent.get(name)
        return None
    def set_local(self,name,val): self.vars[name]=val
    def set(self,name,val):
        if name in self.vars or not self.parent: self.vars[name]=val
        else: self.parent.set(name,val)

KEYWORDS=set("and break do else elseif end false for function if in local nil not or repeat return then true until while".split())
TOKEN_RE=re.compile(r"""
    (?P<space>\s+)|
    (?P<comment>--(?:\[(=*)\[.*?\]\1\]|[^\n]*))|
    (?P<long>\[(=*)\[.*?\]\2\])|
    (?P<num>0[xX][0-9a-fA-F]+|\d+\.\d*(?:[eE][+-]?\d+)?|\.\d+(?:[eE][+-]?\d+)?|\d+(?:[eE][+-]?\d+)?)|
    (?P<str>'(?:\\.|[^\\'])*'|"(?:\\.|[^\\"])*")|
    (?P<op>\.\.\.|==|~=|<=|>=|\.\.|[+\-*/%^#=<>;:,.{}\[\]\(\)])|
    (?P<id>[A-Za-z_][A-Za-z0-9_]*)
""", re.S|re.X)

class Tok:
    def __init__(self, typ,val,pos): self.typ=typ; self.val=val; self.pos=pos

def unquote(s):
    if s.startswith("["):
        m=re.match(r"\[(=*)\[(.*)\]\1\]$",s,re.S); return m.group(2) if m else s
    return bytes(s[1:-1], "utf-8").decode("unicode_escape")

def lex(src):
    out=[]; p=0
    while p < len(src):
        m=TOKEN_RE.match(src,p)
        if not m: raise LuaError("syntax error near '%s'"%src[p:p+10])
        p=m.end(); k=m.lastgroup; v=m.group(k)
        if k in ("space","comment"): continue
        if k=="op": k=v
        if k=="id" and v in KEYWORDS: k=v
        if k=="str": v=unquote(v)
        if k=="long": v=unquote(v); k="str"
        if k=="num":
            v=int(v,16) if isinstance(v,str) and v.lower().startswith("0x") else (float(v) if any(c in v for c in ".eE") else int(v))
        out.append(Tok(k,v,m.start()))
    out.append(Tok("eof","eof",len(src)))
    return out

class Parser:
    def __init__(self, src): self.t=lex(src); self.i=0
    def peek(self): return self.t[self.i]
    def at(self,*v):
        tk=self.peek()
        return tk.typ in v or (tk.typ not in ("str","num","id") and tk.val in v)
    def pop(self,*v):
        if v and not self.at(*v): raise LuaError("syntax error near '%s'"%self.peek().val)
        x=self.peek(); self.i+=1; return x
    def parse(self, stops=("eof",)):
        stm=[]
        while not self.at(*stops):
            if self.at(";"): self.pop(";"); continue
            stm.append(self.statement())
        return ("block",stm)
    def statement(self):
        if self.at("local"):
            self.pop("local")
            if self.at("function"):
                self.pop("function"); name=self.pop("id").val; params,body=self.funcbody(); return ("localfunc",name,params,body)
            names=[self.pop("id").val]
            while self.at(","): self.pop(","); names.append(self.pop("id").val)
            vals=[]
            if self.at("="): self.pop("="); vals=self.explist()
            return ("local",names,vals)
        if self.at("function"):
            self.pop("function"); target=self.prefix_name(); params,body=self.funcbody(); return ("func",target,params,body)
        if self.at("return"):
            self.pop("return"); vals=[] if self.at("end","else","elseif","until","eof",";") else self.explist(); return ("return",vals)
        if self.at("break"): self.pop("break"); return ("break",)
        if self.at("if"):
            self.pop("if"); cases=[]
            cond=self.expr(); self.pop("then"); body=self.parse(("elseif","else","end")); cases.append((cond,body))
            while self.at("elseif"):
                self.pop("elseif"); cond=self.expr(); self.pop("then"); body=self.parse(("elseif","else","end")); cases.append((cond,body))
            els=None
            if self.at("else"): self.pop("else"); els=self.parse(("end",))
            self.pop("end"); return ("if",cases,els)
        if self.at("while"):
            self.pop("while"); cond=self.expr(); self.pop("do"); body=self.parse(("end",)); self.pop("end"); return ("while",cond,body)
        if self.at("do"):
            self.pop("do"); body=self.parse(("end",)); self.pop("end"); return ("do",body)
        if self.at("repeat"):
            self.pop("repeat"); body=self.parse(("until",)); self.pop("until"); cond=self.expr(); return ("repeat",body,cond)
        if self.at("for"):
            self.pop("for"); name=self.pop("id").val
            if self.at("="):
                self.pop("="); a=self.expr(); self.pop(","); b=self.expr(); c=("num",1)
                if self.at(","): self.pop(","); c=self.expr()
                self.pop("do"); body=self.parse(("end",)); self.pop("end"); return ("fornum",name,a,b,c,body)
            names=[name]
            while self.at(","): self.pop(","); names.append(self.pop("id").val)
            self.pop("in"); vals=self.explist(); self.pop("do"); body=self.parse(("end",)); self.pop("end"); return ("forin",names,vals,body)
        first=self.suffixed()
        if self.at("=") or self.at(","):
            vars=[first]
            while self.at(","): self.pop(","); vars.append(self.suffixed())
            self.pop("="); return ("assign",vars,self.explist())
        return ("callstmt", first)
    def prefix_name(self):
        e=("var",self.pop("id").val)
        while self.at("."): self.pop("."); e=("index",e,("str",self.pop("id").val))
        if self.at(":"): self.pop(":"); e=("index",e,("str",self.pop("id").val))
        return e
    def funcbody(self):
        self.pop("("); params=[]; vararg=False
        if not self.at(")"):
            if self.at("..."): self.pop("..."); vararg=True
            else:
                params.append(self.pop("id").val)
                while self.at(","):
                    self.pop(",")
                    if self.at("..."): self.pop("..."); vararg=True; break
                    params.append(self.pop("id").val)
        self.pop(")"); body=self.parse(("end",)); self.pop("end"); return ((params,vararg),body)
    def explist(self):
        vals=[self.expr()]
        while self.at(","): self.pop(","); vals.append(self.expr())
        return vals
    def expr(self, minp=0):
        e=self.unary()
        prec={"or":1,"and":2,"==":3,"~=":3,"<":3,">":3,"<=":3,">=":3,"..":4,"+":5,"-":5,"*":6,"/":6,"%":6,"^":8}
        right_assoc={"..","^"}
        while self.peek().typ in prec and prec[self.peek().typ]>=minp:
            op=self.pop().typ; p=prec[op]
            rhs=self.expr(p+(0 if op in right_assoc else 1))
            e=("bin",op,e,rhs)
        return e
    def unary(self):
        if self.at("not","-","#"):
            op=self.pop().typ; return ("un",op,self.expr(7))
        return self.simple()
    def simple(self):
        if self.at("nil"): self.pop(); return ("nil",)
        if self.at("true"): self.pop(); return ("bool",True)
        if self.at("false"): self.pop(); return ("bool",False)
        if self.at("num"): return ("num",self.pop().val)
        if self.at("str"): return ("str",self.pop().val)
        if self.at("..."): self.pop("..."); return ("var","...")
        if self.at("function"): self.pop("function"); params,body=self.funcbody(); return ("lambda",params,body)
        if self.at("{"): return self.table()
        return self.suffixed()
    def table(self):
        self.pop("{"); fields=[]; idx=1
        while not self.at("}"):
            if self.at("["):
                self.pop("["); k=self.expr(); self.pop("]"); self.pop("="); v=self.expr(); fields.append((k,v))
            elif self.at("id") and self.t[self.i+1].typ=="=":
                k=("str",self.pop("id").val); self.pop("="); v=self.expr(); fields.append((k,v))
            else:
                fields.append((("num",idx), self.expr())); idx+=1
            if self.at(",",";"): self.pop()
            else: break
        self.pop("}"); return ("table",fields)
    def suffixed(self):
        if self.at("id"): e=("var",self.pop("id").val)
        elif self.at("("): self.pop("("); e=self.expr(); self.pop(")")
        else: raise LuaError("syntax error near '%s'"%self.peek().val)
        while True:
            if self.at("."): self.pop("."); e=("index",e,("str",self.pop("id").val))
            elif self.at("["): self.pop("["); k=self.expr(); self.pop("]"); e=("index",e,k)
            elif self.at(":"):
                self.pop(":"); m=self.pop("id").val; args=self.args(); e=("methodcall",e,m,args)
            elif self.at("(","{","str"): e=("call",e,self.args())
            else: break
        return e
    def args(self):
        if self.at("("):
            self.pop("("); vals=[] if self.at(")") else self.explist(); self.pop(")"); return vals
        if self.at("{"): return [self.table()]
        if self.at("str"): return [("str",self.pop("str").val)]
        raise LuaError("syntax error near '%s'"%self.peek().val)

def adjust(vals,n):
    vals=list(vals)
    vals += [None]*(n-len(vals))
    return vals[:n]

class LuaFunc:
    def __init__(self, params, body, env): self.params=params; self.body=body; self.env=env
    def __call__(self,*args):
        names,vararg=self.params; e=Env(self.env)
        for i,n in enumerate(names): e.set_local(n, args[i] if i<len(args) else None)
        e.set_local("...", list(args[len(names):]))
        try: exec_block(self.body,e)
        except ReturnEx as r: return r.vals
        return []

def call(fn,args):
    if isinstance(fn,LuaFunc): return fn(*args)
    if callable(fn):
        r=fn(*args)
        if isinstance(r, tuple): return list(r)
        if isinstance(r, list): return r
        return [r]
    raise LuaError("attempt to call a %s value" % lua_type(fn))

def eval_l(e, env):
    typ=e[0]
    if typ=="nil": return None
    if typ=="bool": return e[1]
    if typ in ("num","str"): return e[1]
    if typ=="var":
        if e[1]=="...": return env.get("...")
        return env.get(e[1])
    if typ=="index":
        t=eval_l(e[1],env); k=eval_l(e[2],env)
        if isinstance(t,LuaTable): return t.get(k)
        if isinstance(t,str) and isinstance(k,str): return GLOBAL.get("string").get(k)
        raise LuaError("attempt to index a %s value" % lua_type(t))
    if typ=="table":
        t=LuaTable()
        for k,v in e[1]: t.set(eval_l(k,env), eval_l(v,env))
        return t
    if typ=="lambda": return LuaFunc(e[1],e[2],env)
    if typ=="call":
        fn=eval_l(e[1],env); args=eval_args(e[2],env); r=call(fn,args); return r[0] if r else None
    if typ=="methodcall":
        obj=eval_l(e[1],env); fn = obj.get(e[2]) if isinstance(obj,LuaTable) else (GLOBAL.get("string").get(e[2]) if isinstance(obj,str) else None)
        r=call(fn,[obj]+eval_args(e[3],env)); return r[0] if r else None
    if typ=="un":
        v=eval_l(e[2],env)
        if e[1]=="not": return not lua_truth(v)
        if e[1]=="-": return -num(v)
        if e[1]=="#": return v.length() if isinstance(v,LuaTable) else len(v) if isinstance(v,str) else 0
    if typ=="bin":
        op=e[1]
        if op=="and":
            a=eval_l(e[2],env); return eval_l(e[3],env) if lua_truth(a) else a
        if op=="or":
            a=eval_l(e[2],env); return a if lua_truth(a) else eval_l(e[3],env)
        a=eval_l(e[2],env); b=eval_l(e[3],env)
        if op=="+": return num(a)+num(b)
        if op=="-": return num(a)-num(b)
        if op=="*": return num(a)*num(b)
        if op=="/": return num(a)/num(b)
        if op=="%": return num(a)%num(b)
        if op=="^": return num(a)**num(b)
        if op=="..": return lua_str(a)+lua_str(b)
        if op=="==": return a==b
        if op=="~=": return a!=b
        if op=="<": return a<b
        if op==">": return a>b
        if op=="<=": return a<=b
        if op==">=": return a>=b
    raise LuaError("unsupported expression")

def eval_multi(e,env):
    if e[0]=="call":
        return call(eval_l(e[1],env), eval_args(e[2],env))
    if e[0]=="methodcall":
        obj=eval_l(e[1],env); fn = obj.get(e[2]) if isinstance(obj,LuaTable) else GLOBAL.get("string").get(e[2])
        return call(fn,[obj]+eval_args(e[3],env))
    if e[0]=="var" and e[1]=="...": return env.get("...") or []
    return [eval_l(e,env)]
def eval_args(es,env):
    out=[]
    for i,x in enumerate(es):
        vals=eval_multi(x,env) if i==len(es)-1 else [eval_l(x,env)]
        out.extend(vals)
    return out

def assign(target, val, env):
    if target[0]=="var": env.set(target[1],val); return
    if target[0]=="index":
        t=eval_l(target[1],env); k=eval_l(target[2],env)
        if not isinstance(t,LuaTable): raise LuaError("attempt to index a %s value" % lua_type(t))
        t.set(k,val); return
    raise LuaError("syntax error")

def exec_block(block,env):
    for s in block[1]:
        typ=s[0]
        if typ=="local":
            vals=[]
            for i,x in enumerate(s[2]): vals.extend(eval_multi(x,env) if i==len(s[2])-1 else [eval_l(x,env)])
            for n,v in zip(s[1],adjust(vals,len(s[1]))): env.set_local(n,v)
        elif typ=="localfunc": env.set_local(s[1], LuaFunc(s[2],s[3],env))
        elif typ=="func": assign(s[1], LuaFunc(s[2],s[3],env), env)
        elif typ=="assign":
            vals=[]
            for i,x in enumerate(s[2]): vals.extend(eval_multi(x,env) if i==len(s[2])-1 else [eval_l(x,env)])
            for t,v in zip(s[1],adjust(vals,len(s[1]))): assign(t,v,env)
        elif typ=="callstmt": eval_multi(s[1],env)
        elif typ=="return":
            vals=[]
            for i,x in enumerate(s[1]): vals.extend(eval_multi(x,env) if i==len(s[1])-1 else [eval_l(x,env)])
            raise ReturnEx(vals)
        elif typ=="break": raise BreakEx()
        elif typ=="if":
            done=False
            for c,b in s[1]:
                if lua_truth(eval_l(c,env)): exec_block(b,Env(env)); done=True; break
            if not done and s[2]: exec_block(s[2],Env(env))
        elif typ=="while":
            while lua_truth(eval_l(s[1],env)):
                try: exec_block(s[2],Env(env))
                except BreakEx: break
        elif typ=="do":
            exec_block(s[1],Env(env))
        elif typ=="repeat":
            while True:
                try: exec_block(s[1],Env(env))
                except BreakEx: break
                if lua_truth(eval_l(s[2],env)): break
        elif typ=="fornum":
            start=int(num(eval_l(s[2],env))); stop=int(num(eval_l(s[3],env))); step=int(num(eval_l(s[4],env)))
            i=start
            while (i<=stop if step>=0 else i>=stop):
                le=Env(env); le.set_local(s[1],i)
                try: exec_block(s[5],le)
                except BreakEx: break
                i+=step
        elif typ=="forin":
            vals=eval_args(s[2],env)
            if vals and callable(vals[0]):
                gen,state,ctrl=(vals+[None,None])[:3]
                while True:
                    r=call(gen,[state,ctrl]); 
                    if not r or r[0] is None: break
                    ctrl=r[0]; le=Env(env)
                    for n,v in zip(s[1],adjust(r,len(s[1]))): le.set_local(n,v)
                    try: exec_block(s[3],le)
                    except BreakEx: break

def make_globals():
    g=Env(); _G=LuaTable(); g.set_local("_G",_G); g.set_local("_VERSION","Lua 5.1")
    def put(n,v): g.set_local(n,v); _G.set(n,v)
    put("print", lambda *a: (print(*[lua_str(x) for x in a], sep="\t"), [])[1])
    put("type", lua_type); put("tostring", lua_str)
    def tonumber_fn(x=None,base=None):
        if x is None or str(x)=="":
            return None
        try:
            return int(str(x), int(base)) if base else (int(x) if re.match(r"^[+-]?\d+$", str(x)) else float(x))
        except Exception:
            return None
    put("tonumber", tonumber_fn)
    put("assert", lambda v,*a: v if lua_truth(v) else (_ for _ in ()).throw(LuaError(lua_str(a[0]) if a else "assertion failed!")))
    put("error", lambda msg="",level=None: (_ for _ in ()).throw(LuaError(lua_str(msg))))
    def pcall_fn(f,*a):
        try:
            return [True]+call(f,list(a))
        except Exception as e:
            return [False,str(e)]
    put("pcall", pcall_fn)
    put("select", lambda what,*a: len(a) if what=="#" else list(a[int(what)-1:]))
    put("unpack", lambda t,i=1,j=None: t.array()[int(i)-1:(int(j) if j else t.length())] if isinstance(t,LuaTable) else [])
    def pairs(t):
        keys=list(t.d.keys()) if isinstance(t,LuaTable) else []
        def gen(state,last):
            try: idx=keys.index(last)+1 if last in keys else 0
            except ValueError: idx=0
            return [keys[idx], t.get(keys[idx])] if idx<len(keys) else [None]
        return [gen,t,None]
    put("pairs", pairs)
    def ipairs(t):
        def gen(state,last):
            i=(last or 0)+1; v=t.get(i) if isinstance(t,LuaTable) else None
            return [i,v] if v is not None else [None]
        return [gen,t,0]
    put("ipairs", ipairs)
    put("next", lambda t,k=None: (lambda ks: ([ks[(ks.index(k)+1 if k in ks else 0)], t.get(ks[(ks.index(k)+1 if k in ks else 0)])] if (ks and (ks.index(k)+1 if k in ks else 0)<len(ks)) else [None]))(list(t.d.keys()) if isinstance(t,LuaTable) else []))
    put("loadstring", lambda s,name=None: LuaFunc(([],False), Parser(s).parse(), g))
    put("load", g.get("loadstring"))
    def dofile(path=None):
        data=sys.stdin.read() if path is None else open(path).read()
        return run_chunk(data,g,path or "stdin")
    put("dofile", dofile)
    loaded=LuaTable()
    package=LuaTable({"loaded":loaded,"path":"./?.lua;./?/init.lua"})
    put("package",package)
    def require(name):
        if loaded.get(name): return loaded.get(name)
        if name=="jit": return jit
        if name=="ffi": return ffi
        p=name.replace(".","/")
        for pat in package.get("path").split(";"):
            fn=pat.replace("?",p)
            if os.path.exists(fn):
                r=run_chunk(open(fn).read(),g,fn); val=(r[0] if r else True); loaded.set(name,val); return val
        raise LuaError("module '%s' not found" % name)
    put("require",require)
    math_t=LuaTable({k:getattr(math,k) for k in dir(math) if not k.startswith("_")})
    math_t.set("random", lambda a=None,b=None: random.random() if a is None else random.randint(1,int(a)) if b is None else random.randint(int(a),int(b)))
    math_t.set("randomseed", lambda x: random.seed(x))
    put("math",math_t)
    str_t=LuaTable({
        "len":lambda s: len(str(s)), "lower":lambda s: str(s).lower(), "upper":lambda s: str(s).upper(),
        "sub":lambda s,i,j=None: str(s)[int(i)-1:(int(j) if j is not None and int(j)>=0 else (int(j) if j is not None else len(str(s))))],
        "reverse":lambda s: str(s)[::-1], "rep":lambda s,n,sep="": str(sep).join([str(s)]*int(n)),
        "format":lambda fmt,*a: fmt % tuple(a), "byte":lambda s,i=1,j=None: [ord(c) for c in str(s)[int(i)-1:(int(j) if j else int(i))]],
        "char":lambda *a: "".join(chr(int(x)) for x in a),
        "find":lambda s,p,i=1,plain=None: (lambda m: [m.start()+1,m.end()] if m else [None])(re.search(re.escape(p) if plain else p, str(s)[int(i)-1:])),
        "match":lambda s,p,i=1: (lambda m: list(m.groups()) if m and m.groups() else (m.group(0) if m else None))(re.search(p,str(s)[int(i)-1:])),
        "gsub":lambda s,p,r,n=None: list(re.subn(p,str(r),str(s),0 if n is None else int(n))),
    })
    put("string",str_t)
    table_t=LuaTable({
        "insert":lambda t,pos,val=None: (t.d.update({i+1:t.get(i) for i in range(t.length(), int(pos if val is not None else t.length()+1)-1, -1)}) or t.set(int(pos if val is not None else t.length()+1), val if val is not None else pos)),
        "concat":lambda t,sep="",i=1,j=None: str(sep).join(lua_str(t.get(k)) for k in range(int(i), int(j) if j else t.length()+1)),
        "sort":lambda t,comp=None: (lambda arr: [t.set(i+1,v) for i,v in enumerate(sorted(arr))])([t.get(i) for i in range(1,t.length()+1)]),
        "remove":lambda t,pos=None: (lambda p,v: (t.set(p,None), v)[1])(int(pos or t.length()), t.get(int(pos or t.length()))),
    })
    put("table",table_t)
    os_t=LuaTable({"clock":time.process_time,"time":lambda tbl=None: int(time.time()),"date":lambda fmt="%c",t=None: time.strftime(fmt.replace("%","%")),"getenv":os.getenv,"exit":lambda code=0: sys.exit(int(code))})
    put("os",os_t)
    io_t=LuaTable({"write":lambda *a: (sys.stdout.write("".join(lua_str(x) for x in a)), sys.stdout.flush(), [True])[2],
                   "read":lambda *a: sys.stdin.readline().rstrip("\n"),
                   "flush":lambda : sys.stdout.flush()})
    put("io",io_t)
    jit=LuaTable({"version":"LuaJIT 2.1.1772570160","version_num":20100,"os":"Linux","arch":"x64","status":lambda : [False],"on":lambda : None,"off":lambda : None,"flush":lambda : None})
    ffi=LuaTable({"cdef":lambda *a: None, "load":lambda *a: LuaTable(), "typeof":lambda x=None: "ctype<void>", "new":lambda *a: LuaTable(), "string":lambda x,n=None: str(x)})
    put("jit",jit)
    return g

GLOBAL=make_globals()

def run_chunk(src, env=None, name="(command line)"):
    env=env or GLOBAL
    block=Parser(src).parse()
    try: exec_block(block, env)
    except ReturnEx as r: return r.vals
    return []

def usage():
    print("""usage: ./executable [options]... [script [args]...].
Available options are:
  -e chunk  Execute string 'chunk'.
  -l name   Require library 'name'.
  -b ...    Save or list bytecode.
  -j cmd    Perform LuaJIT control command.
  -O[opt]   Control LuaJIT optimizations.
  -i        Enter interactive mode after executing 'script'.
  -v        Show version information.
  -E        Ignore environment variables.
  --        Stop handling options.
  -         Execute stdin and stop handling options.""")

def set_arg(argv0, opts, script, args):
    t=LuaTable(); t.set(0, script if script is not None else None)
    idx=-len(opts)
    t.set(idx-1, argv0)
    for i,o in enumerate(opts): t.set(-len(opts)+i, o)
    for i,a in enumerate(args,1): t.set(i,a)
    GLOBAL.set("arg",t); GLOBAL.get("_G").set("arg",t)

def main(argv):
    if len(argv)==1:
        sys.stdout.write(VERSION_LINE+"\n> "); sys.stdout.flush()
        for line in sys.stdin:
            try:
                if line.startswith("="): line="print("+line[1:].rstrip()+")"
                run_chunk(line)
            except Exception as e: print("./executable: "+str(e), file=sys.stderr)
            sys.stdout.write("> "); sys.stdout.flush()
        return 0
    chunks=[]; libs=[]; opts=[]; i=1; stop=False; showv=False; interactive=False
    while i<len(argv) and not stop:
        a=argv[i]
        if a=="--help": usage(); return 0
        if a=="--": i+=1; break
        if a=="-": script="-"; i+=1; break
        if not a.startswith("-") or a=="-": break
        if a=="-v": showv=True; opts.append(a); i+=1; continue
        if a=="-i": interactive=True; opts.append(a); i+=1; continue
        if a=="-E" or a.startswith("-O") or a.startswith("-j"): opts.append(a); i+=1; continue
        if a=="-b" or a.startswith("-b"):
            print("./executable: unknown luaJIT command or jit.* modules not installed", file=sys.stderr); return 1
        if a=="-e":
            opts.append(a); i+=1
            if i>=len(argv): print("./executable: '-e' needs argument", file=sys.stderr); return 1
            chunks.append(argv[i]); opts.append(argv[i]); i+=1; continue
        if a.startswith("-e") and len(a)>2:
            opts.append("-e"); chunks.append(a[2:]); opts.append(a[2:]); i+=1; continue
        if a=="-l":
            opts.append(a); i+=1
            if i>=len(argv): print("./executable: '-l' needs argument", file=sys.stderr); return 1
            libs.append(argv[i]); opts.append(argv[i]); i+=1; continue
        if a.startswith("-l") and len(a)>2:
            opts.append("-l"); libs.append(a[2:]); opts.append(a[2:]); i+=1; continue
        usage(); return 1
    if showv: print(VERSION_LINE)
    script = argv[i] if i<len(argv) else None
    args = argv[i+1:] if script is not None else []
    set_arg(argv[0], opts, script, args)
    try:
        for l in libs: GLOBAL.get("require")(l)
        for c in chunks: run_chunk(c, GLOBAL)
        if script is not None:
            src=sys.stdin.read() if script=="-" else open(script).read()
            run_chunk(src, GLOBAL, script)
        if interactive:
            pass
    except FileNotFoundError:
        print("./executable: cannot open %s: No such file or directory" % script, file=sys.stderr); return 1
    except LuaError as e:
        print("./executable: "+str(e), file=sys.stderr); return 1
    except Exception as e:
        print("./executable: "+str(e), file=sys.stderr); return 1
    return 0
if __name__=="__main__":
    sys.exit(main(sys.argv))
