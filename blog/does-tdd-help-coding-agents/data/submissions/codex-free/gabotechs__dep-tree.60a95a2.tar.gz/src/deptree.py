#!/usr/bin/env python3
import ast
import fnmatch
import glob
import json
import os
import re
import stat
import sys
from pathlib import Path

VERSION = "v0.23.4"

BANNER = r"""
      ____         _ __       _
     |  _ \   ___ |  _ \    _| |_  _ __  ___   ___
     | | | | / _ \| |_) |  |_   _||  __|/ _ \ / _ \
     | |_| ||  __/| .__/     | |  | |  |  __/|  __/
     |____/  \__| |_|        | \__|_|   \___| \___|
"""

GLOBAL_FLAGS = """Global Flags:
  -c, --config string                        path to dep-tree's config file. (default .dep-tree.yml)
      --exclude stringArray                  Files that match this glob pattern will be ignored. You can provide an arbitrary number of --exclude flags.
      --js-tsconfig-paths                    follow the tsconfig.json paths while resolving imports. (default true)
      --js-workspaces                        take the workspaces attribute in the root package.json into account for resolving paths. (default true)
      --only stringArray                     Files that do not match this glob pattern will be ignored. You can provide an arbitrary number of --only flags.
      --python-exclude-conditional-imports   exclude imports wrapped inside if or try statements. (default false)
      --unwrap-exports                       trace re-exported symbols to the file where they are declared. (default false)"""

SAMPLE_CONFIG = """# Files that should be completely ignored by dep-tree. It's fine to ignore
# some big files that everyone depends on and that don't add
# value to the visualization, like auto generated code.
exclude:
  - 'some-glob-pattern/**/*.ts'

# The only files that will be included by dep-tree. If a file does not
# match any of the provided patters, it is ignored.
only:
  - 'some-glob-pattern/**/*.ts'

# Whether to unwrap re-exports to the target file or not.
unwrapExports: false

check:
  entrypoints:
    - src/index.ts
  allowCircularDependencies: false
  allow:
    'src/products/**':
      - 'src/products/**'
      - 'src/helpers/**'
  deny:
    'src/products/**':
      - 'src/users/**'
  aliases:
    'common':
      - 'src/helpers/**'
      - 'src/utils/**'
      - 'src/generated/**'

js:
  workspaces: true
  tsConfigPaths: true

python:
  excludeConditionalImports: false

rust:
  # None available at the moment.
"""


def eprint(msg):
    print(msg, file=sys.stderr)


def rel(path):
    return os.path.relpath(os.path.abspath(path), os.getcwd()).replace(os.sep, "/")


def clean_arg_parse(argv):
    opts = {
        "config": ".dep-tree.yml",
        "only": [],
        "exclude": [],
        "unwrap": False,
        "py_exclude_conditional": False,
    }
    rest = []
    i = 0
    while i < len(argv):
        a = argv[i]
        if a in ("-c", "--config"):
            i += 1
            if i >= len(argv):
                eprint("Error: flag needs an argument: --config")
                sys.exit(1)
            opts["config"] = argv[i]
        elif a == "--only":
            i += 1
            opts["only"].append(argv[i])
        elif a == "--exclude":
            i += 1
            opts["exclude"].append(argv[i])
        elif a == "--unwrap-exports":
            opts["unwrap"] = True
        elif a == "--python-exclude-conditional-imports":
            opts["py_exclude_conditional"] = True
        elif a in ("--js-tsconfig-paths", "--js-workspaces"):
            pass
        elif a.startswith("--only="):
            opts["only"].append(a.split("=", 1)[1])
        elif a.startswith("--exclude="):
            opts["exclude"].append(a.split("=", 1)[1])
        elif a.startswith("--config="):
            opts["config"] = a.split("=", 1)[1]
        else:
            rest.append(a)
        i += 1
    return opts, rest


def main_help():
    print(BANNER)
    print("""Usage:
  dep-tree [command]

Examples:
$ dep-tree src/index.ts
$ dep-tree entropy src/index.ts
$ dep-tree tree package/main.py --unwrap-exports
$ dep-tree check

Visualize your dependencies graphically
  entropy     (default) Renders a 3d force-directed graph in the browser
  tree        Render the dependency tree starting from the provided entrypoint

Check your dependencies against your own rules
  check       Checks that the dependency rules defined in the configuration file are not broken

Display what are the dependencies between two portions of code
  explain     Shows all the dependencies between two parts of the code

Additional Commands:
  config      Generates a sample config in case that there's not already one present
  help        Help about any command

Flags:
  -c, --config string                        path to dep-tree's config file. (default .dep-tree.yml)
      --unwrap-exports                       trace re-exported symbols to the file where they are declared. (default false)
      --js-tsconfig-paths                    follow the tsconfig.json paths while resolving imports. (default true)
      --js-workspaces                        take the workspaces attribute in the root package.json into account for resolving paths. (default true)
      --python-exclude-conditional-imports   exclude imports wrapped inside if or try statements. (default false)
      --only stringArray                     Files that do not match this glob pattern will be ignored. You can provide an arbitrary number of --only flags.
      --exclude stringArray                  Files that match this glob pattern will be ignored. You can provide an arbitrary number of --exclude flags.
  -h, --help                                 help for dep-tree
  -v, --version                              version for dep-tree

Use "dep-tree [command] --help" for more information about a command.""")


def cmd_help(name):
    if name == "explain":
        print("""Shows all the dependencies between two parts of the code

Usage:
  dep-tree explain [flags]

Flags:
  -h, --help            help for explain
  -l, --overlap-left    When there's an overlap between the files at the left and the right, keep the ones at the left
  -r, --overlap-right   When there's an overlap between the files at the left and the right, keep the ones at the right

""" + GLOBAL_FLAGS)
    elif name == "check":
        print("""Checks that the dependency rules defined in the configuration file are not broken

Usage:
  dep-tree check [flags]

Flags:
  -h, --help   help for check

""" + GLOBAL_FLAGS)
    elif name == "tree":
        print("""Render the dependency tree starting from the provided entrypoint

Usage:
  dep-tree tree [flags]

Flags:
  -h, --help   help for tree
      --json   render the dependency tree in a machine readable json format

""" + GLOBAL_FLAGS)
    elif name in ("config", "init"):
        print("""Generates a sample config in case that there's not already one present

Usage:
  dep-tree config [flags]

Aliases:
  config, init

Flags:
  -h, --help   help for config

""" + GLOBAL_FLAGS)
    else:
        main_help()


def strip_quotes(s):
    s = s.strip()
    if len(s) >= 2 and s[0] in "'\"" and s[-1] == s[0]:
        return s[1:-1]
    return s


def parse_scalar(s):
    s = strip_quotes(s.strip())
    if s.lower() == "true":
        return True
    if s.lower() == "false":
        return False
    return s


def simple_yaml(path):
    if not os.path.exists(path):
        return {}
    raw_lines = Path(path).read_text(encoding="utf-8").splitlines()

    def next_is_list(idx, indent):
        for nxt in raw_lines[idx + 1 :]:
            if not nxt.strip() or nxt.lstrip().startswith("#"):
                continue
            ni = len(nxt) - len(nxt.lstrip(" "))
            if ni <= indent:
                return False
            return nxt.strip().startswith("- ")
        return False

    root = {}
    stack = [(-1, root)]
    for idx, line in enumerate(raw_lines):
            if not line.strip() or line.lstrip().startswith("#"):
                continue
            indent = len(line) - len(line.lstrip(" "))
            text = line.strip()
            while stack and stack[-1][0] >= indent:
                stack.pop()
            parent = stack[-1][1]
            if text.startswith("- "):
                val = text[2:].strip()
                if isinstance(parent, list):
                    if val.endswith(":") or ": " in val:
                        d = {}
                        if val.endswith(":"):
                            d[strip_quotes(val[:-1])] = {}
                        else:
                            k, v = val.split(":", 1)
                            d[strip_quotes(k)] = parse_scalar(v)
                        parent.append(d)
                        stack.append((indent, d))
                    else:
                        parent.append(parse_scalar(val))
                elif isinstance(parent, dict):
                    # This handles slightly malformed/simple YAML by appending to
                    # the nearest list-valued key at this indentation.
                    pass
                continue
            if ":" in text:
                key, val = text.split(":", 1)
                key = strip_quotes(key)
                val = val.strip()
                if val == "":
                    nxt = [] if next_is_list(idx, indent) else {}
                    parent[key] = nxt
                    stack.append((indent, nxt))
                else:
                    parent[key] = parse_scalar(val)
    return root


def all_code_files():
    exts = {".py", ".js", ".jsx", ".ts", ".tsx", ".go", ".rs"}
    out = []
    for root, dirs, files in os.walk("."):
        skip = {".git", "node_modules", "target", "__pycache__", ".venv", "vendor"}
        dirs[:] = [d for d in dirs if d not in skip]
        for name in files:
            if Path(name).suffix in exts:
                out.append(rel(os.path.join(root, name)))
    return sorted(set(out))


def match_any(path, patterns):
    return any(fnmatch.fnmatch(path, p) or fnmatch.fnmatch("./" + path, p) for p in patterns)


def filter_files(files, opts, cfg=None):
    cfg = cfg or {}
    only = list(cfg.get("only") or []) + opts.get("only", [])
    exclude = list(cfg.get("exclude") or []) + opts.get("exclude", [])
    res = []
    for f in files:
        if only and not match_any(f, only):
            continue
        if exclude and match_any(f, exclude):
            continue
        res.append(f)
    return res


def glob_files(pattern):
    matches = [rel(p) for p in glob.glob(pattern, recursive=True) if os.path.isfile(p)]
    return sorted(set(matches))


def resolve_file(base, spec, lang=None):
    base_dir = os.path.dirname(base)
    candidates = []
    if spec.startswith("."):
        stem = os.path.normpath(os.path.join(base_dir, spec))
        candidates.append(stem)
    else:
        stem = spec.replace(".", "/")
        candidates.append(stem)
    exts = [Path(spec).suffix] if Path(spec).suffix else []
    exts += [".py", ".js", ".jsx", ".ts", ".tsx", ".go", ".rs"]
    for c in candidates:
        if os.path.isfile(c):
            return rel(c)
        for ext in exts:
            if ext and os.path.isfile(c + ext):
                return rel(c + ext)
        for ext in exts:
            idx = os.path.join(c, "__init__" + ext) if ext == ".py" else os.path.join(c, "index" + ext)
            if ext and os.path.isfile(idx):
                return rel(idx)
    return None


def read_text(path):
    try:
        return Path(path).read_text(encoding="utf-8")
    except UnicodeDecodeError:
        return Path(path).read_text(errors="ignore")
    except OSError:
        return ""


def scan_js(path):
    text = read_text(path)
    specs = []
    pats = [
        r"\bimport\s+(?:[^'\"\n]+?\s+from\s+)?['\"]([^'\"]+)['\"]",
        r"\bexport\s+[^'\"\n]+?\s+from\s+['\"]([^'\"]+)['\"]",
        r"\brequire\s*\(\s*['\"]([^'\"]+)['\"]\s*\)",
    ]
    for pat in pats:
        specs.extend(re.findall(pat, text))
    return [r for s in specs if (r := resolve_file(path, s))]


class ImportVisitor(ast.NodeVisitor):
    def __init__(self, path, exclude_conditional=False):
        self.path = path
        self.deps = []
        self.depth = 0
        self.exclude_conditional = exclude_conditional

    def visit_If(self, node):
        self.depth += 1
        self.generic_visit(node)
        self.depth -= 1

    def visit_Try(self, node):
        self.depth += 1
        self.generic_visit(node)
        self.depth -= 1

    def visit_FunctionDef(self, node):
        self.depth += 1
        self.generic_visit(node)
        self.depth -= 1

    visit_AsyncFunctionDef = visit_FunctionDef

    def allowed(self):
        return not (self.exclude_conditional and self.depth > 0)

    def visit_Import(self, node):
        if self.allowed():
            for alias in node.names:
                add = resolve_file(self.path, alias.name)
                if add:
                    self.deps.append(add)

    def visit_ImportFrom(self, node):
        if not self.allowed():
            return
        mod = node.module or ""
        if node.level:
            parts = os.path.dirname(self.path).split("/")
            base = "/".join(parts[: max(0, len(parts) - node.level + 1)])
            spec = (base + "/" + mod.replace(".", "/")).strip("/")
            add = resolve_file(self.path, spec)
        else:
            add = resolve_file(self.path, mod)
        if add:
            self.deps.append(add)
        for alias in node.names:
            if alias.name == "*":
                continue
            sub = (mod + "." + alias.name).strip(".")
            add2 = resolve_file(self.path, sub)
            if add2:
                self.deps.append(add2)


def scan_py(path, opts):
    try:
        tree = ast.parse(read_text(path))
    except SyntaxError:
        return []
    v = ImportVisitor(path, opts.get("py_exclude_conditional", False))
    v.visit(tree)
    return v.deps


def scan_go(path):
    text = read_text(path)
    module = ""
    if os.path.exists("go.mod"):
        m = re.search(r"(?m)^\s*module\s+(\S+)", read_text("go.mod"))
        if m:
            module = m.group(1)
    specs = []
    specs.extend(re.findall(r'import\s+(?:[._A-Za-z][\w.]*\s+)?"([^"]+)"', text))
    for block in re.findall(r'import\s*\((.*?)\)', text, re.S):
        specs.extend(re.findall(r'"([^"]+)"', block))
    deps = []
    for s in specs:
        if module and s.startswith(module + "/"):
            d = s[len(module) + 1 :]
            files = sorted(glob.glob(os.path.join(d, "*.go")))
            deps.extend(rel(f) for f in files if not f.endswith("_test.go"))
        elif s.startswith("./") or s.startswith("../"):
            files = sorted(glob.glob(os.path.normpath(os.path.join(os.path.dirname(path), s, "*.go"))))
            deps.extend(rel(f) for f in files if not f.endswith("_test.go"))
    return deps


def scan_rs(path):
    text = read_text(path)
    deps = []
    for m in re.findall(r"(?m)^\s*(?:pub\s+)?mod\s+([A-Za-z_][A-Za-z0-9_]*)\s*;", text):
        base = os.path.dirname(path)
        for c in (os.path.join(base, m + ".rs"), os.path.join(base, m, "mod.rs")):
            if os.path.exists(c):
                deps.append(rel(c))
                break
    for u in re.findall(r"\buse\s+crate::([A-Za-z_][A-Za-z0-9_]*)", text):
        for c in (os.path.join("src", u + ".rs"), os.path.join("src", u, "mod.rs"), u + ".rs"):
            if os.path.exists(c):
                deps.append(rel(c))
                break
    return deps


def scan_file(path, opts):
    ext = Path(path).suffix
    if ext in (".js", ".jsx", ".ts", ".tsx"):
        return scan_js(path)
    if ext == ".py":
        return scan_py(path, opts)
    if ext == ".go":
        return scan_go(path)
    if ext == ".rs":
        return scan_rs(path)
    return []


def build_graph(entries, opts, cfg=None):
    allowed = set(filter_files(all_code_files(), opts, cfg))
    graph = {}
    errors = {}
    visiting = []
    circular = []

    def dfs(f):
        f = rel(f)
        if f in visiting:
            cyc = visiting[visiting.index(f) :] + [f]
            if cyc not in circular:
                circular.append(cyc)
            return
        if f in graph:
            return
        if f not in allowed and os.path.exists(f):
            graph[f] = []
            return
        visiting.append(f)
        deps = []
        for d in scan_file(f, opts):
            if d in allowed and d != f:
                deps.append(d)
        deps = sorted(set(deps))
        graph[f] = deps
        for d in deps:
            dfs(d)
        visiting.pop()

    for e in entries:
        if not os.path.exists(e):
            eprint(f"Error: {e} does not match with any existing file")
            sys.exit(1)
        dfs(e)
    return graph, circular, errors


def nested_tree(root, graph, seen=None):
    seen = seen or set()
    root = rel(root)
    if root in seen or not graph.get(root):
        return None
    seen.add(root)
    return {d: nested_tree(d, graph, set(seen)) for d in graph[root]}


def cmd_tree(args, opts):
    as_json = False
    args2 = []
    for a in args:
        if a == "--json":
            as_json = True
        elif a in ("-h", "--help"):
            cmd_help("tree")
            return 0
        else:
            args2.append(a)
    if len(args2) != 1:
        eprint(f"Error: accepts 1 arg(s), received {len(args2)}")
        return 1
    cfg = simple_yaml(opts["config"])
    graph, circular, errors = build_graph([args2[0]], opts, cfg)
    data = {"tree": {rel(args2[0]): nested_tree(args2[0], graph)}, "circularDependencies": circular, "errors": errors}
    if as_json:
        print(json.dumps(data, indent=2))
    else:
        print_tree(rel(args2[0]), graph)
    return 0


def print_tree(root, graph, indent=""):
    print(indent + root)
    deps = graph.get(root) or []
    for d in deps:
        print_tree(d, graph, indent + "  ")


def cmd_explain(args, opts):
    left_overlap = False
    right_overlap = False
    rest = []
    for a in args:
        if a in ("-h", "--help"):
            cmd_help("explain")
            return 0
        if a in ("-l", "--overlap-left"):
            left_overlap = True
        elif a in ("-r", "--overlap-right"):
            right_overlap = True
        else:
            rest.append(a)
    if len(rest) != 2:
        eprint(f"Error: accepts 2 arg(s), received {len(rest)}")
        return 1
    left = set(glob_files(rest[0]))
    right = set(glob_files(rest[1]))
    both = left & right
    if left_overlap:
        right -= both
    if right_overlap:
        left -= both
    cfg = simple_yaml(opts["config"])
    graph, _, _ = build_graph(sorted(left), opts, cfg)
    for src in sorted(left):
        for dst in sorted(graph.get(src, [])):
            if dst in right:
                print(f"{src} -> {dst}")
    return 0


def expand_aliases(patterns, aliases):
    out = []
    for p in patterns:
        if isinstance(p, dict):
            p = p.get("to", "")
        if p in aliases:
            out.extend(aliases[p])
        elif p:
            out.append(p)
    return out


def cmd_check(args, opts):
    if any(a in ("-h", "--help") for a in args):
        cmd_help("check")
        return 0
    cfg = simple_yaml(opts["config"])
    check = cfg.get("check") or {}
    entries = check.get("entrypoints") or []
    if not entries:
        eprint("Error: no entrypoints configured")
        return 1
    graph, circular, _ = build_graph(entries, opts, cfg)
    aliases = check.get("aliases") or {}
    violations = []
    allow = check.get("allow") or {}
    deny = check.get("deny") or {}
    for src, deps in graph.items():
        for src_pat, rule in allow.items():
            if match_any(src, [src_pat]):
                allowed = rule.get("to", []) if isinstance(rule, dict) else rule
                allowed = expand_aliases(allowed or [], aliases)
                for dst in deps:
                    if not match_any(dst, allowed):
                        reason = rule.get("reason", "") if isinstance(rule, dict) else ""
                        violations.append((src, dst, reason))
        for src_pat, rules in deny.items():
            if match_any(src, [src_pat]):
                rules = rules if isinstance(rules, list) else [rules]
                for rule in rules:
                    pats = [rule.get("to", "")] if isinstance(rule, dict) else [rule]
                    pats = expand_aliases(pats, aliases)
                    for dst in deps:
                        if match_any(dst, pats):
                            reason = rule.get("reason", "") if isinstance(rule, dict) else ""
                            violations.append((src, dst, reason))
    allow_circ = bool(check.get("allowCircularDependencies", False))
    if violations or (circular and not allow_circ):
        eprint("Error: Check failed, the following dependencies are not allowed:")
        eprint("")
        if violations:
            eprint("detected dependency rule violations:")
            for src, dst, reason in violations:
                suffix = f" ({reason})" if reason else ""
                eprint(f"- {src} -> {dst}{suffix}")
            eprint("")
        if circular and not allow_circ:
            eprint("detected circular dependencies:")
            for cyc in circular:
                eprint("- " + " -> ".join(cyc))
        return 1
    return 0


def cmd_config(opts):
    path = opts["config"]
    if os.path.exists(path):
        eprint(f"Error: cannot generate config file, as one already exists in {path}")
        return 1
    Path(path).write_text(SAMPLE_CONFIG, encoding="utf-8")
    os.chmod(path, stat.S_IRUSR | stat.S_IWUSR)
    return 0


def cmd_entropy(args, opts):
    targets = [a for a in args if not a.startswith("-")]
    if not targets:
        eprint("Error: accepts at least 1 arg(s), received 0")
        return 1
    for t in targets:
        if not glob_files(t) and not os.path.exists(t):
            eprint(f"Error: {t} does not match with any existing file")
            return 1
    print("Opening browser with dependency graph...")
    return 0


def main(argv):
    opts, rest = clean_arg_parse(argv)
    if not rest or rest[0] in ("-h", "--help", "help"):
        if len(rest) >= 2 and rest[0] == "help":
            cmd_help(rest[1])
        else:
            main_help()
        return 0
    if rest[0] in ("-v", "--version"):
        print(f"dep-tree version {VERSION}")
        return 0
    cmd, args = rest[0], rest[1:]
    if cmd in ("config", "init"):
        if any(a in ("-h", "--help") for a in args):
            cmd_help("config")
            return 0
        return cmd_config(opts)
    if cmd == "tree":
        return cmd_tree(args, opts)
    if cmd == "explain":
        return cmd_explain(args, opts)
    if cmd == "check":
        return cmd_check(args, opts)
    if cmd == "entropy":
        return cmd_entropy(args, opts)
    # Default command is entropy with the first positional as an entrypoint.
    if os.path.exists(cmd) or glob_files(cmd):
        return cmd_entropy(rest, opts)
    eprint(f"Error: {cmd} does not match with any existing file")
    return 1


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
