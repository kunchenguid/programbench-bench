package main

import (
    "bytes"
    "flag"
    "fmt"
    "go/ast"
    "go/format"
    "go/parser"
    "go/token"
    "io/fs"
    "os"
    "path/filepath"
    "regexp"
    "sort"
    "strings"
)

type options struct{ all, exported, named, nosub, parallel, inputs, write, version, useCmp, ai bool; only, excl string }
type param struct{ name, typ string; variadic bool }
type ret struct{ name, typ string; isErr bool }
type fninfo struct{ name, testName, recvName, recvType, recvBase, recvDisplay string; recvPtr bool; typeParams []string; params []param; returns []ret }

func main(){
    var o options
    flag.BoolVar(&o.all,"all",false,"generate tests for all functions and methods")
    flag.BoolVar(&o.exported,"exported",false,"generate tests for exported functions and methods. Takes precedence over -only and -all")
    flag.BoolVar(&o.named,"named",false,"switch table tests from using slice to map (with test name for the key)")
    flag.BoolVar(&o.nosub,"nosubtests",false,"disable generating tests using the Go 1.7 subtests feature")
    flag.BoolVar(&o.parallel,"parallel",false,"enable generating parallel subtests using the Go 1.7 feature")
    flag.BoolVar(&o.inputs,"i",false,"print test inputs in error messages")
    flag.BoolVar(&o.write,"w",false,"write output to (test) files instead of stdout")
    flag.BoolVar(&o.version,"version",false,"print version information and exit")
    flag.BoolVar(&o.useCmp,"use_go_cmp",false,"use cmp.Equal (google/go-cmp) instead of reflect.DeepEqual")
    flag.BoolVar(&o.ai,"ai",false,"generate test cases using AI (requires Ollama)")
    flag.StringVar(&o.only,"only","","regexp. generate tests for functions and methods that match only. Takes precedence over -all")
    flag.StringVar(&o.excl,"excl","","regexp. generate tests for functions and methods that don't match. Takes precedence over -only, -exported, and -all")
    flag.String("template","","optional. Specify custom test code templates, e.g. testify. This can also be set via environment variable GOTESTS_TEMPLATE")
    flag.String("template_dir","","optional. Path to a directory containing custom test code templates. Takes precedence over -template. This can also be set via environment variable GOTESTS_TEMPLATE_DIR")
    flag.String("template_params","","read external parameters to template by json with stdin")
    flag.String("template_params_file","","read external parameters to template by json with file")
    flag.String("ai-model","qwen2.5-coder:0.5b","AI model to use for test generation")
    flag.String("ai-endpoint","http://localhost:11434","Ollama API endpoint")
    flag.Int("ai-min-cases",3,"minimum number of test cases to generate with AI")
    flag.Int("ai-max-cases",10,"maximum number of test cases to generate with AI")
    flag.Parse()
    if o.version { fmt.Println("gotests v0.0.0-20260303205902-f3b63d74369a"); fmt.Println("Go version: go1.24.5"); fmt.Println("Git commit: f3b63d74369a8c405a9a3990a656a278a4f9096f"); fmt.Println("Build time: 2026-03-03T20:59:02Z"); return }
    if !o.all && !o.exported && o.only=="" && o.excl=="" { fmt.Fprintln(os.Stderr,"Please specify either the -only, -excl, -exported, or -all flag"); os.Exit(1) }
    paths:=expand(flag.Args()); if len(paths)==0 { fmt.Fprintln(os.Stderr,"Please specify a path"); os.Exit(1) }
    for _,p:= range paths { if err:=process(p,o); err!=nil { fmt.Fprintln(os.Stderr,err); os.Exit(1) } }
}

func expand(args []string) []string { var out []string; for _,a:= range args { if strings.HasSuffix(a,"/...") { root:=strings.TrimSuffix(a,"/..."); if root=="" {root="."}; filepath.WalkDir(root, func(path string,d fs.DirEntry,err error) error { if err==nil && d.IsDir() { ms,_:=filepath.Glob(filepath.Join(path,"*.go")); has:=false; for _,m:=range ms { if !strings.HasSuffix(m,"_test.go") {has=true} }; if has { out=append(out,path) } }; return nil }); } else { ms,err:=filepath.Glob(a); if err==nil && len(ms)>0 {out=append(out,ms...)} else {out=append(out,a)} } }; return out }

func process(path string,o options) error { st,err:=os.Stat(path); if err!=nil {return err}; var files []string; outPath:=""; if st.IsDir(){ ms,_:=filepath.Glob(filepath.Join(path,"*.go")); for _,m:=range ms{ if !strings.HasSuffix(m,"_test.go"){files=append(files,m)} }; outPath=filepath.Join(path,filepath.Base(path)+"_test.go") } else { files=[]string{path}; outPath=strings.TrimSuffix(path,".go")+"_test.go" }
    if len(files)==0 { return nil }
    code, names, err:=generate(files,o); if err!=nil {return err}; if len(names)==0 { return nil }
    for _,n:= range names { fmt.Println("Generated "+n) }
    if o.write { return os.WriteFile(outPath, code, 0644) }
    os.Stdout.Write(code); return nil }

func generate(paths []string,o options)([]byte,[]string,error){ fset:=token.NewFileSet(); var asts []*ast.File; pkg:=""; imports:=map[string]string{}; for _,p:=range paths{ f,err:=parser.ParseFile(fset,p,nil,parser.ParseComments); if err!=nil{return nil,nil,err}; asts=append(asts,f); if pkg==""{pkg=f.Name.Name}; for _,im:=range f.Imports{ path:=strings.Trim(im.Path.Value,"\""); name:=""; if im.Name!=nil{name=im.Name.Name}; imports[path]=name } }
    var funcs []fninfo; for _,f:=range asts{ for _,d:=range f.Decls{ fd,ok:=d.(*ast.FuncDecl); if !ok || fd.Name.Name=="init" {continue}; info:=buildInfo(fset,fd); if include(info,o){ funcs=append(funcs,info) } } }
    var names []string; var body bytes.Buffer; needReflect:=false; needCmp:=false; for _,fn:= range funcs{ names=append(names,fn.testName); if fnNeedsDeep(fn){ if o.useCmp {needCmp=true}else{needReflect=true} }; body.WriteString(render(fn,o)); body.WriteByte('\n') }
    var buf bytes.Buffer; fmt.Fprintf(&buf,"package %s\n\n",pkg); impSet:=map[string]string{"testing":""}; bodyText := body.String(); for p,n:= range imports { q:=n; if q=="" { base:=filepath.Base(p); q=strings.Split(base,"-")[0] }; if q=="." || q=="_" || strings.Contains(bodyText, q+".") { impSet[p]=n } }; if needReflect {impSet["reflect"]=""}; if needCmp {impSet["github.com/google/go-cmp/cmp"]=""}
    writeImports(&buf,impSet); buf.WriteByte('\n'); buf.Write(body.Bytes()); formatted,err:=format.Source(buf.Bytes()); if err!=nil{return buf.Bytes(),names,nil}; return formatted,names,nil }

func include(fn fninfo,o options) bool { target:=fn.name; if fn.recvBase!=""{target=fn.recvBase+"."+fn.name}; if o.excl!=""{ re,_:=regexp.Compile(o.excl); return re==nil || !re.MatchString(target) }; if o.exported { return ast.IsExported(fn.name) && (fn.recvBase=="" || ast.IsExported(fn.recvBase)) }; if o.only!=""{ re,_:=regexp.Compile(o.only); return re!=nil && re.MatchString(target) }; return o.all }
func expr(fset *token.FileSet,e ast.Expr) string { var b bytes.Buffer; format.Node(&b,fset,e); return b.String() }
func buildInfo(fset *token.FileSet,fd *ast.FuncDecl) fninfo { fn:=fninfo{name:fd.Name.Name}; if fd.Type.TypeParams!=nil { for _,field:=range fd.Type.TypeParams.List{ typ:=concrete(expr(fset,field.Type)); for range field.Names{ fn.typeParams=append(fn.typeParams,typ) } } }
    if fd.Recv!=nil && len(fd.Recv.List)>0{ r:=fd.Recv.List[0]; rt:=expr(fset,r.Type); fn.recvType=instantiateRecv(rt); fn.recvBase=baseRecv(rt); fn.recvPtr=strings.HasPrefix(rt,"*"); fn.recvDisplay=displayRecv(rt); recvMap:=recvTypeMap(rt); _=recvMap; if len(r.Names)>0{fn.recvName=r.Names[0].Name}else{fn.recvName=strings.ToLower(fn.recvBase[:1])}; if fn.recvName=="t"{fn.recvName="tr"}; fn.testName="Test"+fn.recvBase+"_"+fd.Name.Name } else { if ast.IsExported(fd.Name.Name){fn.testName="Test"+fd.Name.Name}else{fn.testName="Test_"+fd.Name.Name} }
    addParams:=func(list *ast.FieldList, variadic bool){ if list==nil{return}; idx:=0; for i,field:=range list.List{ typ:=expr(fset,field.Type); isVar:=false; if strings.HasPrefix(typ,"..."){typ="[]"+strings.TrimPrefix(typ,"..."); isVar=true}; typ=replaceTypeParams(typ, fd.Type.TypeParams); if fd.Recv!=nil { typ=replaceMap(typ, recvTypeMap(expr(fset,fd.Recv.List[0].Type))) }; names:=field.Names; if len(names)==0{ names=[]*ast.Ident{ast.NewIdent(fmt.Sprintf("arg%d",idx))} }; for _,n:=range names{ p:=param{name:n.Name,typ:typ,variadic:isVar && i==len(list.List)-1}; fn.params=append(fn.params,p); idx++ } } }
    addParams(fd.Type.Params,false); if fd.Type.Results!=nil{ ri:=0; for _,field:=range fd.Type.Results.List{ typ:=replaceTypeParams(expr(fset,field.Type), fd.Type.TypeParams); if fd.Recv!=nil { typ=replaceMap(typ, recvTypeMap(expr(fset,fd.Recv.List[0].Type))) }; names:=field.Names; if len(names)==0{names=[]*ast.Ident{ast.NewIdent("")}}; for _,n:=range names{ name:=n.Name; r:=ret{name:name,typ:typ,isErr:typ=="error"}; if r.isErr{name="err"}; if name==""{ if ri==0{ name="want" } else { name=fmt.Sprintf("want%d",ri)} } else { name="want"+strings.ToUpper(name[:1])+name[1:] }; r.name=name; fn.returns=append(fn.returns,r); ri++ } } }
    return fn }
func replaceTypeParams(s string,tp *ast.FieldList) string { if tp==nil{return s}; for _,f:=range tp.List{ c:=concrete(simplifyConstraint(s)); _=c; for _,n:= range f.Names{ s=regexp.MustCompile(`\b`+regexp.QuoteMeta(n.Name)+`\b`).ReplaceAllString(s, concreteType(expr(token.NewFileSet(),f.Type))) } }; return s }
func simplifyConstraint(s string) string{return s}
func concreteType(s string) string {return concrete(s)}
func concrete(s string) string { s=strings.TrimSpace(s); s=strings.TrimPrefix(s,"~"); if strings.Contains(s,"|"){s=strings.TrimSpace(strings.Split(s,"|")[0]); s=strings.TrimPrefix(s,"~")}; if s=="any"{return "int"}; if s=="comparable"{return "string"}; return s }
func instantiateRecv(s string) string { ptr:=strings.HasPrefix(s,"*"); s=strings.TrimPrefix(s,"*"); if i:=strings.Index(s,"["); i>=0 { base:=s[:i]; inside:=strings.TrimSuffix(s[i+1:],"]"); parts:=strings.Split(inside,","); for i:= range parts{ parts[i]="string" }; s=base+"["+strings.Join(parts,", ")+"]" }; if ptr{return "*"+s}; return s }
func baseRecv(s string) string { s=strings.TrimPrefix(s,"*"); if i:=strings.Index(s,"["); i>=0{s=s[:i]}; return s }
func displayRecv(s string) string { s=strings.TrimPrefix(s,"*"); return s }


func recvTypeMap(s string) map[string]string { m:=map[string]string{}; s=strings.TrimPrefix(s,"*"); i:=strings.Index(s,"["); if i<0{return m}; inside:=strings.TrimSuffix(s[i+1:],"]"); for _,part:=range strings.Split(inside,","){ name:=strings.TrimSpace(part); if name!=""{m[name]="string"} }; return m }
func replaceMap(s string,m map[string]string) string { for k,v:=range m{ s=regexp.MustCompile(`\b`+regexp.QuoteMeta(k)+`\b`).ReplaceAllString(s,v) }; return s }
func writeImports(buf *bytes.Buffer, im map[string]string){ keys:=make([]string,0,len(im)); for k:=range im{keys=append(keys,k)}; sort.Strings(keys); if len(keys)==1{ k:=keys[0]; n:=im[k]; if n!=""{fmt.Fprintf(buf,"import %s %q\n",n,k)}else{fmt.Fprintf(buf,"import %q\n",k)}; return}; buf.WriteString("import (\n"); for _,k:=range keys{ if im[k]!=""{fmt.Fprintf(buf,"\t%s %q\n",im[k],k)}else{fmt.Fprintf(buf,"\t%q\n",k)} }; buf.WriteString(")\n") }

func render(fn fninfo,o options) string { var b bytes.Buffer; fmt.Fprintf(&b,"func %s(t *testing.T) {\n",fn.testName); if o.parallel{b.WriteString("t.Parallel()\n")}; if len(fn.params)>0{b.WriteString("type args struct {\n"); for _,p:=range fn.params{fmt.Fprintf(&b,"%s %s\n",p.name,p.typ)}; b.WriteString("}\n")}
    if o.named{ b.WriteString("tests := map[string]struct {\n") } else { b.WriteString("tests := []struct {\nname string\n") }
    if fn.recvBase!=""{ fmt.Fprintf(&b,"%s %s\n",fn.recvName,fn.recvType) }; if len(fn.params)>0{b.WriteString("args args\n")}; for _,r:=range fn.returns{ if r.isErr{b.WriteString("wantErr bool\n")}else{fmt.Fprintf(&b,"%s %s\n",r.name,r.typ)} }; b.WriteString("}{\n// TODO: Add test cases.\n}\n")
    if o.named{ b.WriteString("for name, tt := range tests {\n") } else { b.WriteString("for _, tt := range tests {\n") }
    inner:=renderInner(fn,o,"tt"); if o.nosub{ b.WriteString(inner) } else { runName:="tt.name"; if o.named{runName="name"}; fmt.Fprintf(&b,"t.Run(%s, func(t *testing.T) {\n",runName); if o.parallel{b.WriteString("t.Parallel()\n")}; b.WriteString(inner); b.WriteString("})\n") }; b.WriteString("}\n}\n"); return b.String() }
func renderInner(fn fninfo,o options,tt string) string { var b bytes.Buffer; call:=callExpr(fn,tt,o); assign:=gotAssign(fn); if fn.recvBase!="" && !useTTRecv(o){ base:=strings.TrimPrefix(fn.recvType,"*"); if strings.HasPrefix(fn.recvType,"*"){ fmt.Fprintf(&b,"%s := &%s{}\n",fn.recvName,base) } else { fmt.Fprintf(&b,"%s := %s{}\n",fn.recvName,base) } }
    nonErr:=nonErrReturns(fn); if len(fn.returns)==0{ fmt.Fprintf(&b,"%s\n",call); return b.String() }
    errIdx:=errorIndex(fn); if len(fn.returns)==1 && errIdx<0{ r:=nonErr[0]; cmp:=cmpExpr("got",tt+"."+r.name,r.typ,o); fmt.Fprintf(&b,"if got := %s; %s {\n",call,cmp); fmt.Fprintf(&b,"t.Errorf(%s)\n",errArgs(fn,"", "got", tt+"."+r.name,o)); b.WriteString("}\n"); return b.String() }
    fmt.Fprintf(&b,"%s := %s\n",assign,call); if errIdx>=0{ fname:=fmtName(fn,o); fail:="Fatalf"; cont:="return"; if o.nosub{fail="Errorf"; cont="continue"}; if o.inputs{ fmt.Fprintf(&b,"if (err != nil) != tt.wantErr {\nt.%s(\"%s error = %%v, wantErr %%v\", %s err, tt.wantErr)\n%s\n}\n",fail,fname,inputValues(fn),cont) } else { pref:=""; args:="err, tt.wantErr"; if o.nosub{pref="%q. "; args="tt.name, err, tt.wantErr"}; fmt.Fprintf(&b,"if (err != nil) != tt.wantErr {\nt.%s(\"%s%s() error = %%v, wantErr %%v\", %s)\n%s\n}\n",fail,pref,displayCallName(fn),args,cont) }; b.WriteString("if tt.wantErr {\nreturn\n}\n") }
    for _,r:=range nonErr{ idx:=origIndex(fn,r); got:="got"; if idx>0 { got=fmt.Sprintf("got%d",idx) }; cmp:=cmpExpr(got,tt+"."+r.name,r.typ,o); fmt.Fprintf(&b,"if %s {\n",cmp); label:=""; if len(nonErr)>1{ if idx==0{label=" got"}else{label=fmt.Sprintf(" got%d",idx)} }; fmt.Fprintf(&b,"t.Errorf(%s)\n",errArgs(fn,label,got,tt+"."+r.name,o)); b.WriteString("}\n") }
    return b.String() }
func useTTRecv(o options) bool { return !o.all }
func callExpr(fn fninfo,tt string,o options) string { args:=[]string{}; for _,p:= range fn.params{ a:=tt+".args."+p.name; if p.variadic{a+="..."}; args=append(args,a)}; name:=fn.name; if len(fn.typeParams)>0{name+="["+strings.Join(fn.typeParams,", ")+"]"}; if fn.recvBase!=""{ recv:=fn.recvName; if useTTRecv(o) {recv=tt+"."+fn.recvName}; return recv+"."+name+"("+strings.Join(args,", ")+")"}; return name+"("+strings.Join(args,", ")+")" }
func displayCallName(fn fninfo) string { if fn.recvBase!=""{return fn.recvDisplay+"."+fn.name}; return fn.name }
func fmtName(fn fninfo,o options) string { if o.inputs{ vals:=[]string{}; for range fn.params{vals=append(vals,"%v")}; return displayCallName(fn)+"("+strings.Join(vals,", ")+")"}; return displayCallName(fn)+"()" }
func inputValues(fn fninfo) string { vals:=[]string{}; for _,p:= range fn.params{vals=append(vals,"tt.args."+p.name+",")}; if len(vals)==0{return ""}; return strings.Join(vals," ")+" " }
func gotAssign(fn fninfo) string { parts:=[]string{}; for i,r:=range fn.returns{ if r.isErr{parts=append(parts,"err")}else if i==0{parts=append(parts,"got")}else{parts=append(parts,fmt.Sprintf("got%d",i))} }; return strings.Join(parts,", ") }
func nonErrReturns(fn fninfo) []ret { var rs []ret; for _,r:=range fn.returns{if !r.isErr{rs=append(rs,r)}}; return rs }
func errorIndex(fn fninfo) int { for i,r:=range fn.returns{if r.isErr{return i}}; return -1 }
func origIndex(fn fninfo,r ret) int { for i,x:=range fn.returns{ if x.name==r.name && x.typ==r.typ{return i} }; return 0 }
func cmpExpr(got,want,typ string,o options) string { if simpleComparable(typ) { return got+" != "+want }; if o.useCmp { return "!cmp.Equal("+got+", "+want+")"}; return "!reflect.DeepEqual("+got+", "+want+")" }
func simpleComparable(t string) bool { switch t {case "bool","string","int","int8","int16","int32","int64","uint","uint8","uint16","uint32","uint64","uintptr","byte","rune","float32","float64","complex64","complex128": return true}; return strings.HasPrefix(t,"*") }
func fnNeedsDeep(fn fninfo) bool { for _,r:=range fn.returns{ if !r.isErr && !simpleComparable(r.typ){return true} }; return false }
func errArgs(fn fninfo,label,got,want string,o options) string { pref:=""; prefixArg:=""; if o.nosub{pref="%q. "; prefixArg="tt.name, "}; fname:=fmtName(fn,o); if o.inputs{ vals:=[]string{}; for _,p:=range fn.params{vals=append(vals,"tt.args."+p.name)}; args:=append(vals,got,want); return fmt.Sprintf("\"%s%s = %%v, want %%v\", %s",fname,label,strings.Join(args,", ")) }; return fmt.Sprintf("\"%s%s()%s = %%v, want %%v\", %s%s, %s",pref,displayCallName(fn),label,prefixArg,got,want) }
