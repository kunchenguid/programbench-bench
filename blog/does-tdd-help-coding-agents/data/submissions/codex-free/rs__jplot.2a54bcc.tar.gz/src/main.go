package main

import (
    "errors"
    "flag"
    "fmt"
    "os"
    "strconv"
    "time"
)

const usageText = `Usage: jplot [OPTIONS] FIELD_SPEC [FIELD_SPEC...]:

OPTIONS:
  -interval duration
    	When url is provided, defines the interval between fetches. Note that counter fields are computed based on this interval. (default 1s)
  -rows int
    	Limits the height of the graph output.
  -steps int
    	Number of values to plot. (default 100)
  -url string
    	URL to fetch every second. Read JSON objects from stdin if not specified.

FIELD_SPEC: [<option>[,<option>...]:]path
  option:
    - counter: Computes the difference with the last value. The value must increase monotonically.
    - marker: When the value is none-zero, a vertical line is drawn.
  path:
    JSON field path (eg: field.sub-field).
`

type parseInt struct{ p *int }

func (v parseInt) String() string {
    if v.p == nil {
        return ""
    }
    return strconv.Itoa(*v.p)
}

func (v parseInt) Set(s string) error {
    n, err := strconv.Atoi(s)
    if err != nil {
        return errors.New("parse error")
    }
    *v.p = n
    return nil
}

type parseDuration struct{ p *time.Duration }

func (v parseDuration) String() string {
    if v.p == nil {
        return ""
    }
    return v.p.String()
}

func (v parseDuration) Set(s string) error {
    d, err := time.ParseDuration(s)
    if err != nil {
        return errors.New("parse error")
    }
    *v.p = d
    return nil
}

func main() {
    fmt.Print("\x1b[c")

    fs := flag.NewFlagSet("jplot", flag.ContinueOnError)
    fs.SetOutput(os.Stderr)
    fs.Usage = func() { fmt.Fprint(os.Stderr, usageText) }

    interval := time.Second
    rows := 0
    steps := 100
    url := ""
    fs.Var(parseDuration{&interval}, "interval", "")
    fs.Var(parseInt{&rows}, "rows", "")
    fs.Var(parseInt{&steps}, "steps", "")
    fs.StringVar(&url, "url", "", "")

    err := fs.Parse(os.Args[1:])
    if err != nil {
        if err == flag.ErrHelp {
            os.Exit(0)
        }
        os.Exit(2)
    }

    fmt.Println("jplot:  iTerm2, Kitty, or DRCS Sixel graphics required")
    _ = interval
    _ = rows
    _ = steps
    _ = url
    os.Exit(1)
}
