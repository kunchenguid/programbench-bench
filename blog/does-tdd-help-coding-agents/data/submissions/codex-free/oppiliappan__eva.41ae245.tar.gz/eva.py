#!/usr/bin/env python3
import math
import sys


VERSION = "eva 0.3.1"


class CalcError(Exception):
    def __init__(self, msg, code=1):
        super().__init__(msg)
        self.code = code


class Token:
    def __init__(self, typ, val):
        self.typ = typ
        self.val = val


FUNCS1 = {
    "sin", "cos", "tan", "csc", "sec", "cot",
    "sinh", "cosh", "tanh", "asin", "acos", "atan",
    "acsc", "asec", "acot", "ln", "log2", "log10",
    "sqrt", "ceil", "floor", "abs",
}
FUNCS2 = {"log", "nroot"}
CONSTS = {"pi": math.pi, "e": math.e}


def help_text():
    return """Calculator REPL similar to bc(1)

Usage: executable [OPTIONS] [INPUT]

Arguments:
  [INPUT]  Optional expression string to run eva in command mode

Options:
  -f, --fix <FIX>                Number of decimal places in output (1 - 64) [default: 10]
  -b, --base <RADIX>             Radix of calculation output (1 - 36) [default: 10]
  -a, --angle_unit <angle_unit>  Angle unit [default: degree] [possible values: degree, radian, gradian]
  -h, --help                     Print help
  -V, --version                  Print version"""


def parse_args(argv):
    fix = 10
    base = 10
    angle = "degree"
    inp = None
    i = 0
    stop_opts = False
    while i < len(argv):
        a = argv[i]
        if not stop_opts and a == "--":
            stop_opts = True
            i += 1
            continue
        if not stop_opts and a in ("-h", "--help"):
            print(help_text())
            sys.exit(0)
        if not stop_opts and a in ("-V", "--version"):
            print(VERSION)
            sys.exit(0)
        if not stop_opts and a in ("-f", "--fix"):
            if i + 1 >= len(argv):
                clap_error(f"a value is required for '{a} <FIX>' but none was supplied")
            try:
                fix = int(argv[i + 1])
            except ValueError:
                clap_error(f"invalid value '{argv[i+1]}' for '--fix <FIX>': invalid digit found in string")
            if fix < 1 or fix > 64:
                clap_error(f"invalid value '{argv[i+1]}' for '--fix <FIX>': {fix} is not in 1..=64", usage=False)
            i += 2
            continue
        if not stop_opts and a in ("-b", "--base"):
            if i + 1 >= len(argv):
                clap_error(f"a value is required for '{a} <RADIX>' but none was supplied")
            try:
                base = int(argv[i + 1])
            except ValueError:
                clap_error(f"invalid value '{argv[i+1]}' for '--base <RADIX>': invalid digit found in string")
            if base < 1 or base > 36:
                clap_error(f"invalid value '{argv[i+1]}' for '--base <RADIX>': {base} is not in 1..=36", usage=False)
            i += 2
            continue
        if not stop_opts and a in ("-a", "--angle_unit"):
            if i + 1 >= len(argv):
                clap_error(f"a value is required for '{a} <angle_unit>' but none was supplied")
            angle = argv[i + 1]
            if angle not in ("degree", "radian", "gradian"):
                clap_error("invalid value for '--angle_unit <angle_unit>'", usage=False)
            i += 2
            continue
        if not stop_opts and a.startswith("-"):
            clap_error(f"unexpected argument '{a}' found\n\n  tip: to pass '{a}' as a value, use '-- {a}'")
        if inp is None:
            inp = a
        else:
            inp += " " + a
        i += 1
    return fix, base, angle, inp


def clap_error(msg, usage=True):
    print(f"error: {msg}", file=sys.stderr)
    print(file=sys.stderr)
    if usage:
        print("Usage: executable [OPTIONS] [INPUT]", file=sys.stderr)
        print(file=sys.stderr)
    print("For more information, try '--help'.", file=sys.stderr)
    sys.exit(2)


def tokenize(expr):
    toks = []
    i = 0
    while i < len(expr):
        c = expr[i]
        if c.isspace():
            i += 1
            continue
        if c.isdigit() or c == ".":
            j = i
            dots = 0
            while j < len(expr) and (expr[j].isdigit() or expr[j] == "."):
                if expr[j] == ".":
                    dots += 1
                j += 1
            if dots > 1 or expr[i:j] == ".":
                raise CalcError("Parser Error: Invalid number")
            toks.append(Token("num", float(expr[i:j])))
            i = j
            continue
        if c.isalpha() or c == "_":
            j = i
            while j < len(expr) and (expr[j].isalpha() or expr[j] == "_"):
                j += 1
            toks.append(Token("id", expr[i:j]))
            i = j
            continue
        if c == "*" and i + 1 < len(expr) and expr[i + 1] == "*":
            toks.append(Token("op", "^"))
            i += 2
            continue
        if c in "+-*/^(),":
            toks.append(Token("op" if c in "+-*/^" else c, c))
            i += 1
            continue
        raise CalcError("Parser Error: Unknown token")
    return insert_implicit_mul(toks)


def starts_value(t):
    return t.typ == "num" or t.typ == "id" or t.typ == "("


def ends_value(t):
    return t.typ == "num" or t.typ == "id" or t.typ == ")"


def insert_implicit_mul(toks):
    out = []
    for i, t in enumerate(toks):
        if out and ends_value(out[-1]) and starts_value(t):
            # Do not split a function name from its argument list.
            if not (out[-1].typ == "id" and t.typ == "(" and out[-1].val in FUNCS1 | FUNCS2):
                out.append(Token("op", "*"))
        out.append(t)
    return out


class Parser:
    def __init__(self, toks, angle, prev):
        self.toks = toks
        self.pos = 0
        self.angle = angle
        self.prev = prev

    def peek(self):
        if self.pos < len(self.toks):
            return self.toks[self.pos]
        return Token("eof", "")

    def take(self):
        t = self.peek()
        self.pos += 1
        return t

    def parse(self):
        if not self.toks:
            return 0.0
        v = self.expr()
        if self.peek().typ not in ("eof", ")"):
            raise CalcError("Parser Error: Too many operators, too few operands")
        return v

    def expr(self):
        v = self.term()
        while self.peek().typ == "op" and self.peek().val in "+-":
            op = self.take().val
            r = self.term()
            v = v + r if op == "+" else v - r
        return v

    def term(self):
        v = self.power()
        while self.peek().typ == "op" and self.peek().val in "*/":
            op = self.take().val
            r = self.power()
            if op == "/":
                if r == 0:
                    raise CalcError("Math Error: Divide by zero error!")
                v /= r
            else:
                v *= r
        return v

    def power(self):
        v = self.unary()
        if self.peek().typ == "op" and self.peek().val == "^":
            self.take()
            r = self.power()
            try:
                v = math.pow(v, r)
            except ValueError:
                raise CalcError("Domain Error: Out of bounds!")
        return v

    def unary(self):
        if self.peek().typ == "op" and self.peek().val in "+-":
            op = self.take().val
            v = self.unary()
            return v if op == "+" else -v
        return self.primary()

    def primary(self):
        t = self.take()
        if t.typ == "num":
            return t.val
        if t.typ == "(":
            v = self.expr()
            if self.peek().typ == ")":
                self.take()
            return v
        if t.typ == "id":
            name = t.val
            if name == "_":
                return self.prev
            if name in CONSTS:
                return CONSTS[name]
            if name in FUNCS1 or name in FUNCS2:
                return self.call(name)
            raise CalcError("Parser Error: Too many operators, too few operands")
        raise CalcError("Parser Error: Too many operators, too few operands")

    def call(self, name):
        if self.peek().typ != "(":
            raise CalcError("Parser Error: Too many operators, too few operands")
        self.take()
        args = []
        if self.peek().typ != ")":
            args.append(self.expr())
            while self.peek().typ == ",":
                self.take()
                args.append(self.expr())
        if self.peek().typ == ")":
            self.take()
        need = 2 if name in FUNCS2 else 1
        if len(args) < need:
            raise CalcError(f"Parser Error: To few arguments for function, need {need}")
        return apply_func(name, args[:need], self.angle)


def to_rad(x, angle):
    if angle == "degree" or angle == "gradian":
        return x * math.pi / 180.0
    return x


def safe_unary(fn, x):
    try:
        return fn(x)
    except (ValueError, OverflowError):
        raise CalcError("Domain Error: Out of bounds!")


def apply_func(name, args, angle):
    x = args[0]
    if name == "sin":
        return math.sin(to_rad(x, angle))
    if name == "cos":
        return math.cos(to_rad(x, angle))
    if name == "tan":
        return math.tan(to_rad(x, angle))
    if name == "csc":
        return 1.0 / math.sin(to_rad(x, angle))
    if name == "sec":
        return 1.0 / math.cos(to_rad(x, angle))
    if name == "cot":
        return 1.0 / math.tan(to_rad(x, angle))
    if name == "sinh":
        return safe_unary(math.sinh, x)
    if name == "cosh":
        return safe_unary(math.cosh, x)
    if name == "tanh":
        return math.tanh(x)
    if name == "asin":
        return safe_unary(math.asin, x)
    if name == "acos":
        return safe_unary(math.acos, x)
    if name == "atan":
        return math.atan(x)
    if name == "acsc":
        return safe_unary(math.asin, 1.0 / x)
    if name == "asec":
        return safe_unary(math.acos, 1.0 / x)
    if name == "acot":
        return math.atan(1.0 / x)
    if name == "ln":
        return safe_unary(math.log, x)
    if name == "log2":
        return safe_unary(math.log2, x)
    if name == "log10":
        return safe_unary(math.log10, x)
    if name == "sqrt":
        return safe_unary(math.sqrt, x)
    if name == "ceil":
        return float(math.ceil(x))
    if name == "floor":
        return float(math.floor(x))
    if name == "abs":
        return abs(x)
    if name == "log":
        return safe_unary(lambda y: math.log(y, args[1]), x)
    if name == "nroot":
        return safe_unary(lambda y: math.pow(y, 1.0 / args[1]), x)
    raise CalcError("Parser Error: Unknown function")


def eval_expr(expr, angle, prev=0.0):
    return Parser(tokenize(expr), angle, prev).parse()


def digit(n):
    return "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ"[n]


def fmt_base(v, base, fix):
    if base == 10:
        return f"{v:.{fix}f}"
    v = float(f"{v:.{fix}f}")
    sign = "-" if v < 0 else ""
    v = abs(v)
    whole = int(math.floor(v))
    frac = v - whole
    digs = []
    if whole == 0:
        digs.append("0")
    else:
        while whole:
            digs.append(digit(whole % base))
            whole //= base
        digs.reverse()
    fd = []
    for _ in range(fix):
        frac *= base
        d = int(math.floor(frac + 1e-15))
        if d >= base:
            d = base - 1
        fd.append(digit(d))
        frac -= d
    while abs(frac) < 1e-14 and len(fd) > 1 and fd[-1] == "0":
        fd.pop()
    s = sign + "".join(digs) + "." + "".join(fd)
    groups = s.split(".")[0].rjust(10)
    rest = s[len(s.split(".")[0]):]
    neg = groups.lstrip().startswith("-")
    if neg:
        groups = groups.replace("-", " ", 1)
    parts = []
    while groups:
        parts.append(groups[-3:])
        groups = groups[:-3]
    left = ",".join(reversed(parts))
    if neg:
        left = "-" + left[1:]
    return left + rest


def run_command(inp, fix, base, angle):
    try:
        print(fmt_base(eval_expr(inp, angle), base, fix))
        return 0
    except CalcError as e:
        print(str(e))
        return e.code
    except ZeroDivisionError:
        print("Math Error: Divide by zero error!")
        return 1


def repl(fix, base, angle):
    print("No previous history.")
    prev = 0.0
    status = 0
    for line in sys.stdin:
        line = line.rstrip("\n")
        try:
            prev = eval_expr(line, angle, prev)
            print(fmt_base(prev, base, fix))
        except CalcError as e:
            print(str(e))
            status = e.code
        except ZeroDivisionError:
            print("Math Error: Divide by zero error!")
            status = 1
    return status


def main():
    fix, base, angle, inp = parse_args(sys.argv[1:])
    if inp is None:
        sys.exit(repl(fix, base, angle))
    sys.exit(run_command(inp, fix, base, angle))


if __name__ == "__main__":
    main()
