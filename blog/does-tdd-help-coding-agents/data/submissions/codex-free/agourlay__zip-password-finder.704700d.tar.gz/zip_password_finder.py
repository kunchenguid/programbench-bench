#!/usr/bin/env python3
import argparse
import binascii
import hashlib
import itertools
import os
import struct
import sys
import time
import zlib


VERSION = "zip-password-finder 0.10.3"

CHARSETS = {
    "l": "abcdefghijklmnopqrstuvwxyz",
    "u": "ABCDEFGHIJKLMNOPQRSTUVWXYZ",
    "d": "0123456789",
    "h": "0123456789abcdef",
    "H": "0123456789ABCDEF",
    "s": " !\"#$%&'()*+,-./:;<=>?@[\\]^_`{|}~",
}


class CliError(Exception):
    pass


class ZipError(Exception):
    pass


class Entry:
    def __init__(self, name, flag, method, crc, comp_size, uncomp_size, extra, data):
        self.name = name
        self.flag = flag
        self.method = method
        self.crc = crc
        self.comp_size = comp_size
        self.uncomp_size = uncomp_size
        self.extra = extra
        self.data = data


def print_help():
    print("""Find the password of protected ZIP files

Usage: executable [OPTIONS] --inputFile <inputFile>

Options:
  -i, --inputFile <inputFile>                    path to zip input file
  -w, --workers <workers>                        number of workers
  -p, --passwordDictionary <passwordDictionary>  path to a password dictionary file
  -c, --charset <charset>                        charset to use to generate password [default: lud]
      --charsetFile <charsetFile>                path to a charset file
      --minPasswordLen <minPasswordLen>          minimum password length [default: 1]
      --maxPasswordLen <maxPasswordLen>          maximum password length [default: 10]
      --fileNumber <fileNumber>                  file number in the zip archive [default: 0]
  -s, --startingPassword <startingPassword>      password to start from
  -h, --help                                     Print help
  -V, --version                                  Print version""")


def parse_args(argv):
    if "--help" in argv or "-h" in argv:
        print_help()
        raise SystemExit(0)
    if "--version" in argv or "-V" in argv:
        print(VERSION)
        raise SystemExit(0)

    p = argparse.ArgumentParser(
        prog="executable",
        description="Find the password of protected ZIP files",
        add_help=False,
        allow_abbrev=False,
    )
    p.add_argument("-i", "--inputFile")
    p.add_argument("-w", "--workers", type=int)
    p.add_argument("-p", "--passwordDictionary")
    p.add_argument("-c", "--charset", default="lud")
    p.add_argument("--charsetFile")
    p.add_argument("--minPasswordLen", type=int, default=1)
    p.add_argument("--maxPasswordLen", type=int, default=10)
    p.add_argument("--fileNumber", type=int, default=0)
    p.add_argument("-s", "--startingPassword")

    try:
        ns = p.parse_args(argv)
    except SystemExit as e:
        raise SystemExit(e.code)

    if ns.inputFile is None:
        print("error: the following required arguments were not provided:", file=sys.stderr)
        print("  --inputFile <inputFile>", file=sys.stderr)
        print(file=sys.stderr)
        print("Usage: executable --inputFile <inputFile>", file=sys.stderr)
        print(file=sys.stderr)
        print("For more information, try '--help'.", file=sys.stderr)
        raise SystemExit(2)
    if not os.path.exists(ns.inputFile):
        raise CliError("'inputFile' does not exist")
    if ns.passwordDictionary is not None and not os.path.exists(ns.passwordDictionary):
        raise CliError("'passwordDictionary' does not exist")
    if ns.charsetFile is not None and not os.path.exists(ns.charsetFile):
        raise CliError("'charsetFile' does not exist")
    if ns.maxPasswordLen < ns.minPasswordLen:
        raise CliError("'maxPasswordLen' must be equal or greater than 'minPasswordLen'")
    return ns


def read_zip(path):
    b = open(path, "rb").read()
    entries = []
    off = 0
    while off + 4 <= len(b) and b[off:off + 4] == b"PK\x03\x04":
        if off + 30 > len(b):
            raise ZipError("Invalid zip file")
        sig, ver, flag, method, mtime, mdate, crc, csize, usize, nlen, elen = struct.unpack_from("<IHHHHHIIIHH", b, off)
        name_start = off + 30
        name = b[name_start:name_start + nlen].decode("utf-8", "replace")
        extra_start = name_start + nlen
        extra = b[extra_start:extra_start + elen]
        data_start = extra_start + elen
        data = b[data_start:data_start + csize]
        entries.append(Entry(name, flag, method, crc, csize, usize, extra, data))
        off = data_start + csize
    if not entries:
        raise ZipError("Invalid zip file")
    return entries


CRC_TABLE = []
for n in range(256):
    c = n
    for _ in range(8):
        c = 0xedb88320 ^ (c >> 1) if c & 1 else c >> 1
    CRC_TABLE.append(c)


def crc32_byte(old, b):
    return ((old >> 8) ^ CRC_TABLE[(old ^ b) & 0xff]) & 0xffffffff


class ZipCrypto:
    def __init__(self, password):
        self.k0 = 305419896
        self.k1 = 591751049
        self.k2 = 878082192
        for ch in password:
            self.update(ch)

    def update(self, b):
        self.k0 = crc32_byte(self.k0, b)
        self.k1 = (self.k1 + (self.k0 & 0xff)) & 0xffffffff
        self.k1 = (self.k1 * 134775813 + 1) & 0xffffffff
        self.k2 = crc32_byte(self.k2, self.k1 >> 24)

    def decrypt_byte(self):
        t = (self.k2 | 2) & 0xffffffff
        return ((t * (t ^ 1)) >> 8) & 0xff

    def decrypt(self, data):
        out = bytearray()
        for c in data:
            p = c ^ self.decrypt_byte()
            self.update(p)
            out.append(p)
        return bytes(out)


def decompress_payload(method, payload):
    if method == 0:
        return payload
    if method == 8:
        return zlib.decompress(payload, -15)
    if method == 99:
        return payload
    raise ZipError(f"Unsupported compression method error - '{method}'")


def aes_info(entry):
    i = 0
    while i + 4 <= len(entry.extra):
        hid, size = struct.unpack_from("<HH", entry.extra, i)
        body = entry.extra[i + 4:i + 4 + size]
        if hid == 0x9901 and len(body) >= 7:
            ver, vendor, strength, actual = struct.unpack_from("<H2sBH", body, 0)
            return strength, actual
        i += 4 + size
    return None


def check_aes(entry, password):
    info = aes_info(entry)
    if info is None:
        return False
    strength, actual_method = info
    key_len = {1: 16, 2: 24, 3: 32}.get(strength)
    salt_len = {1: 8, 2: 12, 3: 16}.get(strength)
    if key_len is None or len(entry.data) < salt_len + 12:
        return False
    salt = entry.data[:salt_len]
    verifier = entry.data[salt_len:salt_len + 2]
    material = hashlib.pbkdf2_hmac("sha1", password, salt, 1000, key_len * 2 + 2)
    return material[-2:] == verifier


def check_zipcrypto(entry, password):
    if len(entry.data) < 12:
        return False
    zc = ZipCrypto(password)
    plain = zc.decrypt(entry.data)
    check_byte = (entry.crc >> 24) & 0xff
    if entry.flag & 0x08:
        # With data descriptors, ZIP uses the high byte of the modification time.
        check_byte = None
    if check_byte is not None and plain[11] != check_byte:
        return False
    body = plain[12:]
    try:
        out = decompress_payload(entry.method, body)
    except Exception:
        return False
    if entry.crc and (binascii.crc32(out) & 0xffffffff) != entry.crc:
        return False
    return True


def is_password(entry, password_text):
    password = password_text.encode()
    if entry.method == 99:
        return check_aes(entry, password)
    return check_zipcrypto(entry, password)


def build_charset(ns):
    if ns.charsetFile:
        return open(ns.charsetFile, "r", encoding="utf-8", errors="ignore").read().rstrip("\n")
    chars = []
    for opt in ns.charset:
        if opt not in CHARSETS:
            raise CliError(f"Unknown charset option '{opt}'")
        chars.append(CHARSETS[opt])
    return "".join(chars)


def dictionary_words(path):
    with open(path, "r", encoding="utf-8", errors="ignore") as f:
        for line in f:
            yield line.rstrip("\r\n")


def brute_words(chars, min_len, max_len, starting=None):
    started = starting is None
    for n in range(min_len, max_len + 1):
        for tup in itertools.product(chars, repeat=n):
            s = "".join(tup)
            if not started:
                if s == starting:
                    started = True
                else:
                    continue
            yield s


def elapsed_text(start):
    ns = time.monotonic_ns() - start
    ms, rem = divmod(ns, 1_000_000)
    us, ns2 = divmod(rem, 1_000)
    parts = []
    if ms:
        parts.append(f"{ms}ms")
    if us:
        parts.append(f"{us}us")
    if ns2 or not parts:
        parts.append(f"{ns2}ns")
    return " ".join(parts)


def main(argv):
    try:
        ns = parse_args(argv)
        entries = read_zip(ns.inputFile)
        if ns.fileNumber < 0 or ns.fileNumber >= len(entries):
            print(f"File number not found within archive error - '{ns.fileNumber}'")
            return 1
        entry = entries[ns.fileNumber]
        if not (entry.flag & 1):
            print(f"Invalid zip file error - the selected file in the archive is not encrypted (file_number:{ns.fileNumber} file_name:{entry.name})")
            return 1
        if entry.method != 99:
            build_charset(ns)
        start = time.monotonic_ns()
        if ns.passwordDictionary:
            words = dictionary_words(ns.passwordDictionary)
        else:
            words = brute_words(build_charset(ns), ns.minPasswordLen, ns.maxPasswordLen, ns.startingPassword)
        for word in words:
            if is_password(entry, word):
                print(f"Time elapsed: {elapsed_text(start)}")
                print(f"Password found:{word}")
                return 0
        print(f"Time elapsed: {elapsed_text(start)}")
        print("Password not found")
        return 0
    except CliError as e:
        print(f'CLI argument error - "{e}"')
        return 1
    except ZipError as e:
        print(str(e))
        return 1
    except KeyboardInterrupt:
        return 130


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
