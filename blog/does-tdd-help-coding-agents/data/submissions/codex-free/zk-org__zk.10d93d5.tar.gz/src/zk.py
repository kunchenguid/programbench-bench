#!/usr/bin/env python3
import json
import os
import random
import re
import string
import sys
from datetime import datetime
from pathlib import Path


CONFIG = """# zk configuration file
#
# Uncomment the properties you want to customize.

# NOTE SETTINGS
#
# Defines the default options used when generating new notes.
[note]

# Language used when writing notes.
# This is used to generate slugs or with date formats.
#language = "en"

# The default title used for new note, if no `--title` flag is provided.
#default-title = "Untitled"

# Template used to generate a note's filename, without extension.
#filename = "{{id}}"

# The file extension used for the notes.
#extension = "md"

# Template used to generate a note's content.
# If not an absolute path or "~/unix/path", it's relative to .zk/templates/
template = "default.md"

# Path globs ignored while indexing existing notes.
#exclude = [
#    "drafts/*",
#    "log.md"
#]

[extra]

[format.markdown]
link-format = "wiki"
hashtags = true
colon-tags = false
multiword-tags = false

[tool]

[lsp]

[lsp.diagnostics]
dead-link = "error"

[lsp.completion]

[filter]
"""


MAIN_HELP = """Usage: zk <command>

Commands:

NOTEBOOK
  A notebook is a directory containing a collection of notes

  init     Create a new notebook in the given directory.
  index    Index the notes to be searchable.

NOTES
  Edit or browse your notes

  new      Create a new note in the given notebook directory.
  list     List notes matching the given criteria.
  graph    Produce a graph of the notes matching the given criteria.
  edit     Edit notes matching the given criteria.
  tag      Manage the note tags.

Flags:
  -h, --help                 Show context-sensitive help.
      --notebook-dir=PATH    Turn off notebook auto-discovery and set manually
                             the notebook where commands are run.
  -W, --working-dir=PATH     Run as if zk was started in <PATH> instead of the
                             current working directory.
      --no-input             Never prompt or ask for confirmation.

Run "zk <command> --help" for more information on a command."""

HELP = {
    "init": """Usage: zk init [<directory>]

Create a new notebook in the given directory.

Arguments:
  [<directory>]    Directory containing the notebook.

Flags:
  -h, --help                 Show context-sensitive help.
      --notebook-dir=PATH    Turn off notebook auto-discovery and set manually
                             the notebook where commands are run.
  -W, --working-dir=PATH     Run as if zk was started in <PATH> instead of the
                             current working directory.
      --no-input             Never prompt or ask for confirmation.""",
    "index": """Usage: zk index

Index the notes to be searchable.

You usually do not need to run `zk index` manually, as notes are indexed
automatically when needed.

Flags:
  -h, --help                 Show context-sensitive help.
      --notebook-dir=PATH    Turn off notebook auto-discovery and set manually
                             the notebook where commands are run.
  -W, --working-dir=PATH     Run as if zk was started in <PATH> instead of the
                             current working directory.
      --no-input             Never prompt or ask for confirmation.

  -f, --force                Force indexing all the notes.
  -v, --verbose              Print detailed information about the indexing
                             process.
  -q, --quiet                Do not print statistics nor progress.""",
    "new": """Usage: zk new [<directory>]

Create a new note in the given notebook directory.

Arguments:
  [<directory>]    Directory in which to create the note.

Flags:
  -h, --help                   Show context-sensitive help.
      --notebook-dir=PATH      Turn off notebook auto-discovery and set manually
                               the notebook where commands are run.
  -W, --working-dir=PATH       Run as if zk was started in <PATH> instead of the
                               current working directory.
      --no-input               Never prompt or ask for confirmation.

  -i, --interactive            Read contents from standard input.
  -t, --title=TITLE            Title of the new note.
      --date=DATE              Set the current date.
  -g, --group=NAME             Name of the config group this note belongs to.
                               Takes precedence over the config of the
                               directory.
      --extra=KEY=VALUE,...    Extra variables passed to the templates.
      --template=PATH          Custom template used to render the note.
  -p, --print-path             Print the path of the created note instead of
                               editing it.
  -n, --dry-run                Don't actually create the note. Instead, prints
                               its content on stdout and the generated path on
                               stderr.
      --id=ID                  Skip id generation and use provided value.""",
    "tag": """Usage: zk tag <command>

Manage the note tags.

Commands:
  tag list    List all the note tags.

Flags:
  -h, --help                 Show context-sensitive help.
      --notebook-dir=PATH    Turn off notebook auto-discovery and set manually
                             the notebook where commands are run.
  -W, --working-dir=PATH     Run as if zk was started in <PATH> instead of the
                             current working directory.
      --no-input             Never prompt or ask for confirmation.""",
    "tag list": """Usage: zk tag list

List all the note tags.

Flags:
  -h, --help                 Show context-sensitive help.
      --notebook-dir=PATH    Turn off notebook auto-discovery and set manually
                             the notebook where commands are run.
  -W, --working-dir=PATH     Run as if zk was started in <PATH> instead of the
                             current working directory.
      --no-input             Never prompt or ask for confirmation.

Formatting
  -f, --format=TEMPLATE    Pretty print the list using a custom template or one
                           of the predefined formats: name, full, json, jsonl.
      --header=STRING      Arbitrary text printed at the start of the list.
      --footer="\\n"       Arbitrary text printed at the end of the list.
  -d, --delimiter="\\n"     Print tags delimited by the given separator.
  -0, --delimiter0         Print tags delimited by ASCII NUL characters. This is
                           useful when used in conjunction with `xargs -0`.
  -P, --no-pager           Do not pipe output into a pager.
  -q, --quiet              Do not print the total number of tags found.

Sorting
  -s, --sort=TERM,...    Order the tags by the given criterion.""",
}

FILTER_HELP = """
Filtering
  -i, --interactive                Select notes interactively with fzf.
  -n, --limit=COUNT                Limit the number of notes found.
  -m, --match=QUERY,...            Terms to search for in the notes.
  -M, --match-strategy=STRATEGY    Text matching strategy among: fts, re, exact.
  -x, --exclude=PATH,...           Ignore notes matching the given path,
                                   including its descendants.
  -t, --tag=TAG,...                Find notes tagged with the given tags.
      --mention=PATH,...           Find notes mentioning the title of the given
                                   ones.
      --mentioned-by=PATH,...      Find notes whose title is mentioned in the
                                   given ones.
  -l, --link-to=PATH,...           Find notes which are linking to the given
                                   ones.
      --no-link-to=PATH,...        Find notes which are not linking to the given
                                   notes.
  -L, --linked-by=PATH,...         Find notes which are linked by the given
                                   ones.
      --no-linked-by=PATH,...      Find notes which are not linked by the given
                                   ones.
      --orphan                     Find notes which are not linked by any other
                                   note.
      --tagless                    Find notes which have no tags.
      --missing-backlink           Find notes with at least one missing
                                   backlink.
      --related=PATH,...           Find notes which might be related to the
                                   given ones.
      --max-distance=COUNT         Maximum distance between two linked notes.
  -r, --recursive                  Follow links recursively.
      --created=DATE
      --created-before=DATE        Find notes created before the given date.
      --created-after=DATE         Find notes created after the given date.
      --modified=DATE              Find notes modified on the given date.
      --modified-before=DATE       Find notes modified before the given date.
      --modified-after=DATE        Find notes modified after the given date.

Sorting
  -s, --sort=TERM,...    Order the notes by the given criterion."""

HELP["list"] = """Usage: zk list [<path> ...]

List notes matching the given criteria.

Arguments:
  [<path> ...]    Find notes matching the given path, including its descendants.

Flags:
  -h, --help                 Show context-sensitive help.
      --notebook-dir=PATH    Turn off notebook auto-discovery and set manually
                             the notebook where commands are run.
  -W, --working-dir=PATH     Run as if zk was started in <PATH> instead of the
                             current working directory.
      --no-input             Never prompt or ask for confirmation.

Formatting
  -f, --format=TEMPLATE    Pretty print the list using a custom template or one
                           of the predefined formats: oneline, short, medium,
                           long, full, json, jsonl.
      --header=STRING      Arbitrary text printed at the start of the list.
      --footer="\\n"       Arbitrary text printed at the end of the list.
  -d, --delimiter="\\n"     Print notes delimited by the given separator.
  -0, --delimiter0         Print notes delimited by ASCII NUL characters. This
                           is useful when used in conjunction with `xargs -0`.
  -P, --no-pager           Do not pipe output into a pager.
  -q, --quiet              Do not print the total number of notes found.""" + FILTER_HELP

HELP["graph"] = """Usage: zk graph --format=STRING [<path> ...]

Produce a graph of the notes matching the given criteria.

Arguments:
  [<path> ...]    Find notes matching the given path, including its descendants.

Flags:
  -h, --help                 Show context-sensitive help.
      --notebook-dir=PATH    Turn off notebook auto-discovery and set manually
                             the notebook where commands are run.
  -W, --working-dir=PATH     Run as if zk was started in <PATH> instead of the
                             current working directory.
      --no-input             Never prompt or ask for confirmation.

Formatting
  -f, --format=STRING    Format of the graph among: json.
  -q, --quiet            Do not print the total number of notes found.""" + FILTER_HELP

HELP["edit"] = """Usage: zk edit [<path> ...]

Edit notes matching the given criteria.

Arguments:
  [<path> ...]    Find notes matching the given path, including its descendants.

Flags:
  -h, --help                 Show context-sensitive help.
      --notebook-dir=PATH    Turn off notebook auto-discovery and set manually
                             the notebook where commands are run.
  -W, --working-dir=PATH     Run as if zk was started in <PATH> instead of the
                             current working directory.
      --no-input             Never prompt or ask for confirmation.

  -f, --force                Do not confirm before editing many notes at the
                             same time.""" + FILTER_HELP


def fail(msg):
    print(f"zk: error: {msg}", file=sys.stderr)
    return 1


def split_value(arg, args, i):
    if "=" in arg:
        return arg.split("=", 1)[1], i
    if i + 1 >= len(args):
        return None, i
    return args[i + 1], i + 1


def parse_global(argv):
    cwd = Path.cwd()
    notebook = None
    rest = []
    i = 0
    while i < len(argv):
        a = argv[i]
        if a in ("-W", "--working-dir") or a.startswith("--working-dir="):
            val, i = split_value(a, argv, i)
            if val is None:
                return None, None, None, fail(f"{a}: missing value")
            cwd = Path(val).resolve()
        elif a == "--notebook-dir" or a.startswith("--notebook-dir="):
            val, i = split_value(a, argv, i)
            if val is None:
                return None, None, None, fail("--notebook-dir: missing value")
            notebook = Path(val).resolve()
        elif a == "--no-input":
            pass
        else:
            rest.append(a)
        i += 1
    return cwd, notebook, rest, 0


def find_notebook(cwd, explicit):
    if explicit:
        return explicit
    p = cwd
    while True:
        if (p / ".zk" / "config.toml").exists():
            return p
        if p.parent == p:
            break
        p = p.parent
    raise FileNotFoundError(f"no notebook found in {cwd} or a parent directory")


def note_files(nb):
    files = []
    for p in nb.rglob("*.md"):
        if ".zk" in p.relative_to(nb).parts:
            continue
        files.append(p)
    return sorted(files, key=lambda p: str(p.relative_to(nb)))


def read_note(nb, p):
    rel = str(p.relative_to(nb))
    try:
        text = p.read_text(errors="replace")
    except Exception:
        text = ""
    title = ""
    for line in text.splitlines():
        m = re.match(r"\s*#\s+(.+?)\s*$", line)
        if m:
            title = m.group(1)
            break
    tags = sorted(set(t.strip("#") for t in re.findall(r"(?<!\w)#([A-Za-z0-9_/-]+)", text)))
    links = []
    for m in re.findall(r"\[\[([^\]]+)\]\]", text):
        links.append(m.split("|", 1)[0])
    for m in re.findall(r"\[[^\]]+\]\(([^)]+)\)", text):
        links.append(m)
    st = p.stat()
    return {
        "path": rel,
        "absPath": str(p),
        "title": title,
        "content": text,
        "tags": tags,
        "links": links,
        "created": datetime.fromtimestamp(st.st_ctime).isoformat(timespec="seconds"),
        "modified": datetime.fromtimestamp(st.st_mtime).isoformat(timespec="seconds"),
    }


def parse_options(args):
    opts = {"paths": [], "format": None, "delimiter": "\n", "header": "", "footer": "", "quiet": False,
            "limit": None, "match": [], "tag": [], "exclude": [], "sort": []}
    i = 0
    while i < len(args):
        a = args[i]
        if a in ("-h", "--help"):
            opts["help"] = True
        elif a in ("-q", "--quiet", "-P", "--no-pager", "-i", "--interactive", "-r", "--recursive",
                   "--orphan", "--tagless", "--missing-backlink"):
            if a in ("-q", "--quiet"):
                opts["quiet"] = True
            if a in ("--tagless",):
                opts["tagless"] = True
        elif a == "-0" or a == "--delimiter0":
            opts["delimiter"] = "\0"
        elif a in ("-n", "--limit") or a.startswith("--limit="):
            val, i = split_value(a, args, i)
            opts["limit"] = int(val)
        elif a in ("-m", "--match") or a.startswith("--match="):
            val, i = split_value(a, args, i)
            opts["match"] += [x for x in val.split(",") if x]
        elif a in ("-t", "--tag") or a.startswith("--tag="):
            val, i = split_value(a, args, i)
            opts["tag"] += [x.lstrip("#") for x in val.split(",") if x]
        elif a in ("-x", "--exclude") or a.startswith("--exclude="):
            val, i = split_value(a, args, i)
            opts["exclude"] += [x for x in val.split(",") if x]
        elif a in ("-s", "--sort") or a.startswith("--sort="):
            val, i = split_value(a, args, i)
            opts["sort"] += [x for x in val.split(",") if x]
        elif a in ("-f", "--format") or a.startswith("--format="):
            val, i = split_value(a, args, i)
            opts["format"] = val
        elif a in ("-d", "--delimiter") or a.startswith("--delimiter="):
            val, i = split_value(a, args, i)
            opts["delimiter"] = val.encode().decode("unicode_escape")
        elif a == "--header" or a.startswith("--header="):
            val, i = split_value(a, args, i)
            opts["header"] = val.encode().decode("unicode_escape")
        elif a == "--footer" or a.startswith("--footer="):
            val, i = split_value(a, args, i)
            opts["footer"] = val.encode().decode("unicode_escape")
        elif a.startswith("-"):
            raise ValueError(f"unknown flag {a}")
        else:
            opts["paths"].append(a)
        i += 1
    return opts


def filtered_notes(nb, opts):
    notes = [read_note(nb, p) for p in note_files(nb)]
    if opts.get("paths"):
        paths = [x.rstrip("/") for x in opts["paths"]]
        notes = [n for n in notes if any(n["path"] == p or n["path"].startswith(p + "/") for p in paths)]
    for ex in opts.get("exclude", []):
        ex = ex.rstrip("/")
        notes = [n for n in notes if not (n["path"] == ex or n["path"].startswith(ex + "/"))]
    for t in opts.get("tag", []):
        notes = [n for n in notes if t in n["tags"]]
    if opts.get("tagless"):
        notes = [n for n in notes if not n["tags"]]
    for q in opts.get("match", []):
        notes = [n for n in notes if q.lower() in n["content"].lower() or q.lower() in n["title"].lower()]
    for s in reversed(opts.get("sort", [])):
        rev = s.endswith("-")
        key = s.rstrip("+-")
        if key in ("title", "path", "created", "modified"):
            notes.sort(key=lambda n: n.get(key, ""), reverse=rev)
    if opts.get("limit") is not None:
        notes = notes[:opts["limit"]]
    return notes


def cmd_init(args, cwd):
    if any(a in ("-h", "--help") for a in args):
        print(HELP["init"])
        return 0
    positional = [a for a in args if not a.startswith("-")]
    if len(positional) > 1:
        return fail(f"unexpected argument {positional[1]}")
    target = (cwd / positional[0]).resolve() if positional else cwd
    (target / ".zk" / "templates").mkdir(parents=True, exist_ok=True)
    default = target / ".zk" / "templates" / "default.md"
    if not default.exists():
        default.write_text("# {{title}}\n\n{{content}}")
    cfg = target / ".zk" / "config.toml"
    if not cfg.exists():
        cfg.write_text(CONFIG)
    db = target / ".zk" / "notebook.db"
    db.touch(exist_ok=True)
    return 0


def command_needs_nb(cwd, explicit):
    try:
        return find_notebook(cwd, explicit), 0
    except FileNotFoundError as e:
        return None, fail(f"failed to open notebook: {e}")


def render_template(tpl, vals):
    out = tpl
    for k, v in vals.items():
        out = out.replace("{{" + k + "}}", v)
    out = re.sub(r"{{\s*extra\.([A-Za-z0-9_-]+)\s*}}", lambda m: vals.get("extra." + m.group(1), ""), out)
    out = re.sub(r"{{[^}]+}}", "", out)
    return out


def cmd_new(args, cwd, explicit):
    if any(a in ("-h", "--help") for a in args):
        print(HELP["new"])
        return 0
    nb, code = command_needs_nb(cwd, explicit)
    if code:
        return code
    title = "Untitled"
    ident = None
    dry = False
    print_path = False
    use_stdin = False
    template_path = None
    extra = {}
    positional = []
    i = 0
    while i < len(args):
        a = args[i]
        if a in ("-t", "--title") or a.startswith("--title="):
            title, i = split_value(a, args, i)
        elif a == "--id" or a.startswith("--id="):
            ident, i = split_value(a, args, i)
        elif a in ("-p", "--print-path"):
            print_path = True
        elif a in ("-n", "--dry-run"):
            dry = True
        elif a in ("-i", "--interactive"):
            use_stdin = True
        elif a == "--template" or a.startswith("--template="):
            template_path, i = split_value(a, args, i)
        elif a == "--extra" or a.startswith("--extra="):
            val, i = split_value(a, args, i)
            for part in val.split(","):
                if "=" not in part:
                    return fail(f'--extra: expected "<key>=<value>" but got "{part}"')
                k, v = part.split("=", 1)
                extra["extra." + k] = v
        elif a in ("--date", "-g", "--group") or a.startswith("--date=") or a.startswith("--group="):
            if "=" not in a:
                _, i = split_value(a, args, i)
        elif a.startswith("-"):
            return fail(f"unknown flag {a}")
        else:
            positional.append(a)
        i += 1
    if len(positional) > 1:
        return fail(f"unexpected argument {positional[1]}")
    ident = ident or "".join(random.choice(string.ascii_lowercase + string.digits) for _ in range(4))
    directory = Path(positional[0]) if positional else Path(".")
    rel = directory / (ident + ".md")
    full = (nb / rel).resolve()
    content_in = sys.stdin.read() if use_stdin else ""
    if template_path:
        tp = Path(template_path)
        if not tp.is_absolute():
            tp = cwd / tp
    else:
        tp = nb / ".zk" / "templates" / "default.md"
    tpl = tp.read_text() if tp.exists() else "# {{title}}\n\n{{content}}"
    body = render_template(tpl, {"title": title, "content": content_in, "id": ident, **extra})
    if dry:
        sys.stdout.write(body)
        print(str(rel), file=sys.stderr)
        return 0
    full.parent.mkdir(parents=True, exist_ok=True)
    if full.exists():
        return fail(f"file already exists: {rel}")
    full.write_text(body)
    if print_path:
        print(str(rel))
    return 0


def format_note(n, fmt):
    if fmt in (None, "oneline"):
        return n["path"]
    if fmt == "short":
        return f"{n['path']}\t{n['title']}" if n["title"] else n["path"]
    if fmt == "medium":
        return f"{n['path']}\n  {n['title']}" if n["title"] else n["path"]
    if fmt == "long":
        return f"{n['path']}\nTitle: {n['title']}\nTags: {', '.join(n['tags'])}"
    if fmt == "full":
        return n["content"]
    return fmt.replace("{{path}}", n["path"]).replace("{{title}}", n["title"])


def cmd_list(args, cwd, explicit):
    if any(a in ("-h", "--help") for a in args):
        print(HELP["list"])
        return 0
    nb, code = command_needs_nb(cwd, explicit)
    if code:
        return code
    try:
        opts = parse_options(args)
    except Exception as e:
        return fail(str(e))
    notes = filtered_notes(nb, opts)
    fmt = opts["format"]
    if fmt == "json":
        print(json.dumps([{k: v for k, v in n.items() if k != "content"} for n in notes], separators=(",", ":")))
    elif fmt == "jsonl":
        for n in notes:
            print(json.dumps({k: v for k, v in n.items() if k != "content"}, separators=(",", ":")))
    else:
        sys.stdout.write(opts["header"])
        sys.stdout.write(opts["delimiter"].join(format_note(n, fmt) for n in notes))
        if notes:
            sys.stdout.write(opts["delimiter"] if opts["delimiter"] != "\0" else "\0")
        sys.stdout.write(opts["footer"])
    if not opts["quiet"]:
        print(f"{len(notes)} notes found", file=sys.stderr)
    return 0


def cmd_tag_list(args, cwd, explicit):
    if any(a in ("-h", "--help") for a in args):
        print(HELP["tag list"])
        return 0
    nb, code = command_needs_nb(cwd, explicit)
    if code:
        return code
    try:
        opts = parse_options(args)
    except Exception as e:
        return fail(str(e))
    counts = {}
    for n in [read_note(nb, p) for p in note_files(nb)]:
        for t in n["tags"]:
            counts[t] = counts.get(t, 0) + 1
    rows = sorted(counts.items())
    fmt = opts["format"] or "name"
    if fmt == "json":
        print(json.dumps([{"name": k, "count": v} for k, v in rows], separators=(",", ":")))
    elif fmt == "jsonl":
        for k, v in rows:
            print(json.dumps({"name": k, "count": v}, separators=(",", ":")))
    else:
        vals = [k if fmt == "name" else f"{k}\t{v}" for k, v in rows]
        sys.stdout.write(opts["header"] + opts["delimiter"].join(vals))
        if vals:
            sys.stdout.write(opts["delimiter"] if opts["delimiter"] != "\0" else "\0")
        sys.stdout.write(opts["footer"])
    if not opts["quiet"]:
        print(f"{len(rows)} tags found", file=sys.stderr)
    return 0


def cmd_graph(args, cwd, explicit):
    if any(a in ("-h", "--help") for a in args):
        print(HELP["graph"])
        return 0
    if "--format" not in args and "-f" not in args and not any(a.startswith("--format=") for a in args):
        return fail("missing flags: --format=STRING")
    nb, code = command_needs_nb(cwd, explicit)
    if code:
        return code
    opts = parse_options(args)
    if opts["format"] != "json":
        return fail("unsupported graph format")
    notes = filtered_notes(nb, opts)
    nodes = [{"id": n["path"], "path": n["path"], "title": n["title"]} for n in notes]
    known = {n["path"]: n for n in notes}
    edges = []
    for n in notes:
        for l in n["links"]:
            target = l if l.endswith(".md") else l + ".md"
            if target in known:
                edges.append({"source": n["path"], "target": target})
    print(json.dumps({"nodes": nodes, "edges": edges}, separators=(",", ":")))
    return 0


def cmd_index(args, cwd, explicit):
    if any(a in ("-h", "--help") for a in args):
        print(HELP["index"])
        return 0
    nb, code = command_needs_nb(cwd, explicit)
    if code:
        return code
    quiet = "-q" in args or "--quiet" in args
    verbose = "-v" in args or "--verbose" in args
    n = len(note_files(nb))
    if verbose:
        for p in note_files(nb):
            print(str(p.relative_to(nb)))
    if not quiet:
        print(f"{n} notes indexed")
    return 0


def main(argv):
    cwd, explicit, args, code = parse_global(argv)
    if code:
        return code
    if not args or args[0] in ("-h", "--help"):
        print(MAIN_HELP)
        return 0
    if args[0] == "--version":
        print("zk dev")
        return 0
    cmd, rest = args[0], args[1:]
    if cmd == "init":
        return cmd_init(rest, cwd)
    if cmd == "index":
        return cmd_index(rest, cwd, explicit)
    if cmd == "new":
        return cmd_new(rest, cwd, explicit)
    if cmd == "list":
        return cmd_list(rest, cwd, explicit)
    if cmd == "graph":
        return cmd_graph(rest, cwd, explicit)
    if cmd == "edit":
        if any(a in ("-h", "--help") for a in rest):
            print(HELP["edit"])
            return 0
        nb, c = command_needs_nb(cwd, explicit)
        if c:
            return c
        return cmd_list(["--quiet"] + [a for a in rest if a not in ("-f", "--force")], cwd, explicit)
    if cmd == "tag":
        if not rest:
            nb, c = command_needs_nb(cwd, explicit)
            if c:
                return c
            return fail("expected command")
        if rest[0] in ("-h", "--help"):
            print(HELP["tag"])
            return 0
        if rest[0] != "list":
            return fail(f"unexpected argument {rest[0]}")
        return cmd_tag_list(rest[1:], cwd, explicit)
    if cmd.startswith("-"):
        return fail(f"unknown flag {cmd}")
    return fail(f"unexpected argument {cmd}")


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
