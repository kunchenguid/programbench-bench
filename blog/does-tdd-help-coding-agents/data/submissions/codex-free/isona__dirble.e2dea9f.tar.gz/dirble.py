#!/usr/bin/env python3
import base64
import json
import os
import random
import re
import ssl
import string
import sys
import time
import urllib.error
import urllib.parse
import urllib.request
import xml.sax.saxutils

HELP = """Fast directory scanning and scraping tool

Usage: executable [OPTIONS] <uri|--uri-file <uri-file>|--uri <uri>>

Arguments:
  [uri]
          The URI of the host to scan, optionally supports basic auth with
          http://user:pass@host:port

Options:
  -u, --uri <uri>
          Additional hosts to scan [aliases: url]
  -U, --uri-file <uri-file>
          The filename of a file containing a list of URIs to scan - cookies and
          headers set will be applied to all URIs [aliases: url-file]
      --verb <http_verb>
          Specify which HTTP verb to use
           [default: get] [possible values: get, head, post]
  -w, --wordlist <wordlist>
          Sets which wordlist to use, defaults to dirble_wordlist.txt in the same
          folder as the executable
  -p, --prefixes <prefixes>...
          Provides comma separated prefixes to extend queries with
  -P, --prefix-file <prefix-file>
          The name of a file containing extensions to extend queries with, one
          per line
  -x, --extensions <extensions>...
          Provides comma separated extensions to extend queries with
  -X, --extension-file <extension-file>
          The name of a file containing extensions to extend queries with, one
          per line
      --ext-sub
          Indicates whether the string "%EXT%" in a wordlist file should be 
          substituted with the current extension
  -f, --force-extension
          Only scan with provided extensions
  -k, --ignore-cert
          Ignore the certificate validity for HTTPS
      --show-htaccess
          Enable display of items containing .ht when they return 403 responses
      --timeout <timeout>
          Maximum time to wait for a response before giving up, given in seconds
           [default: 5]
      --max-errors <max_errors>
          The number of consecutive errors a thread can have before it exits,
          set to 0 to disable [default: 5]
      --json-file <json_file>
          Sets a file to write JSON output to [aliases: oJ]
      --no-color
          Disable coloring of terminal output
  -o, --output-file <output_file>
          Sets the file to write the report to [aliases: oN]
      --xml-file <xml_file>
          Sets a file to write XML output to [aliases: oX]
      --hide-lengths <length_blacklist>...
          Specify length ranges to hide, e.g. --hide-lengths 348,500-700
      --output-all <output_all>
          Stores all output types respectively as .txt, .json and .xml [aliases: oA]
      --burp
          Sets the proxy to use the default burp proxy values
          (http://localhost:8080)
      --no-proxy
          Disables proxy use even if there is a system proxy
      --proxy <proxy>
          The proxy address to use, including type and port, can also include a
          username and password in the form 
          "http://username:password@proxy_url:proxy_port"
  -t, --max-threads <max-threads>
          Sets the maximum number of request threads that will be spawned [default: 10]
  -T, --wordlist-split <wordlist_split>
          The number of threads to run for each folder/extension combo [default: 3]
  -z, --throttle <milliseconds>
          Time each thread will wait between requests, given in milliseconds
      --username <username>
          Sets the username to authenticate with
      --password <password>
          Sets the password to authenticate with
  -l, --scan-listable
          Scan listable directories
      --max-recursion-depth <max_recursion_depth>
          Sets the maximum directory depth to recurse to, 0 will disable
          recursion
  -r, --disable-recursion
          Disable discovered subdirectory scanning
      --scrape-listable
          Enable scraping of listable directories for urls, often produces large
          amounts of output
  -a, --user-agent <user_agent>
          Set the user-agent provided with requests, by default it isn't set
  -c, --cookie <cookie>
          Provide a cookie in the form "name=value", can be used multiple times
  -H, --header <header>
          Provide an arbitrary header in the form "header:value" - headers with
          no value must end in a semicolon
  -S, --silent
          Don't output information during the scan, only output the report at
          the end.
  -v, --verbose...
          Increase the verbosity level. Use twice for full verbosity.
  -B, --code-blacklist <code_blacklist>...
          Provide a comma separated list of response codes to not show in output
      --disable-validator
          Disable automatic detection of not found codes
  -W, --code-whitelist <code_whitelist>...
          Provide a comma separated list of response codes to show in output,
          also disables detection of not found codes
      --scan-401
          Scan folders even if they return 401 - Unauthorized frequently
      --scan-403
          Scan folders if they return 403 - Forbidden frequently
  -h, --help
          Print help
  -V, --version
          Print version

OUTPUT FORMAT:
    + [url] - File
    D [url] - Directory
    L [url] - Listable Directory

EXAMPLE USE:
    - Run against a website using the default dirble_wordlist.txt from the
      current directory:
        dirble [address]

    - Run with a different wordlist and including .php and .html extensions:
        dirble [address] -w example_wordlist.txt -x .php,.html

    - With listable directory scraping enabled:
        dirble [address] --scrape-listable

    - Providing a list of extensions and a list of URIs:
        dirble [address] -X wordlists/web.lst -U uri-list.txt

    - Providing multiple hosts to scan via command line:
        dirble [address] -u [address] -u [address]"""

VERSION = "Dirble 1.4.2 (commit d520c82, build 2026-04-17)"

def die(msg, code=2):
    print(msg, file=sys.stderr)
    sys.exit(code)

def split_values(vals):
    out = []
    for v in vals:
        for part in v.split(","):
            part = part.strip()
            if part:
                out.append(part)
    return out

def read_lines(path):
    try:
        with open(path, "r", encoding="utf-8", errors="ignore") as f:
            return [line.strip() for line in f if line.strip()]
    except FileNotFoundError:
        print("\nthread 'main' (1) panicked at src/wordlist.rs:112:37:", file=sys.stderr)
        print('called `Result::unwrap()` on an `Err` value: Os { code: 2, kind: NotFound, message: "No such file or directory" }', file=sys.stderr)
        print("note: run with `RUST_BACKTRACE=1` environment variable to display a backtrace", file=sys.stderr)
        sys.exit(101)

def parse(argv):
    cfg = {
        "uris": [], "uri_file": None, "verb": "get", "wordlist": None,
        "prefixes": [], "extensions": [], "ext_sub": False, "force_ext": False,
        "ignore_cert": False, "show_htaccess": False, "timeout": 5.0,
        "json_file": None, "output_file": None, "xml_file": None, "output_all": None,
        "hide_lengths": [], "no_proxy": False, "proxy": None, "threads": 10,
        "split": 3, "throttle": 0, "username": None, "password": None,
        "scan_listable": False, "disable_recursion": False, "max_depth": None,
        "scrape_listable": False, "user_agent": None, "cookies": [], "headers": [],
        "silent": False, "verbose": 0, "blacklist": [], "whitelist": None,
        "disable_validator": False,
    }
    if not argv:
        print(HELP)
        sys.exit(2)
    i = 0
    positional = []
    value_opts = {
        "-u":"uris", "--uri":"uris", "--url":"uris", "-U":"uri_file", "--uri-file":"uri_file",
        "--url-file":"uri_file", "--verb":"verb", "-w":"wordlist", "--wordlist":"wordlist",
        "-P":"prefix_file", "--prefix-file":"prefix_file", "-X":"extension_file",
        "--extension-file":"extension_file", "--timeout":"timeout", "--max-errors":"max_errors",
        "--json-file":"json_file", "--oJ":"json_file", "-o":"output_file",
        "--output-file":"output_file", "--oN":"output_file", "--xml-file":"xml_file",
        "--oX":"xml_file", "--output-all":"output_all", "--oA":"output_all",
        "--proxy":"proxy", "-t":"threads", "--max-threads":"threads", "-T":"split",
        "--wordlist-split":"split", "-z":"throttle", "--throttle":"throttle",
        "--username":"username", "--password":"password", "--max-recursion-depth":"max_depth",
        "-a":"user_agent", "--user-agent":"user_agent",
    }
    multi_opts = {"-p":"prefixes", "--prefixes":"prefixes", "-x":"extensions",
                  "--extensions":"extensions", "--hide-lengths":"hide_lengths",
                  "-B":"blacklist", "--code-blacklist":"blacklist",
                  "-W":"whitelist", "--code-whitelist":"whitelist"}
    flag_opts = {
        "--ext-sub":"ext_sub", "-f":"force_ext", "--force-extension":"force_ext",
        "-k":"ignore_cert", "--ignore-cert":"ignore_cert", "--show-htaccess":"show_htaccess",
        "--no-color":"no_color", "--burp":"burp", "--no-proxy":"no_proxy",
        "-l":"scan_listable", "--scan-listable":"scan_listable",
        "-r":"disable_recursion", "--disable-recursion":"disable_recursion",
        "--scrape-listable":"scrape_listable", "-S":"silent", "--silent":"silent",
        "--disable-validator":"disable_validator", "--scan-401":"scan_401", "--scan-403":"scan_403",
    }
    while i < len(argv):
        a = argv[i]
        if a in ("-h", "--help"):
            print(HELP); sys.exit(0)
        if a in ("-V", "--version"):
            print(VERSION); sys.exit(0)
        if a.startswith("--") and "=" in a:
            a, val = a.split("=", 1)
            argv = argv[:i+1] + [val] + argv[i+1:]
        if a in ("-v", "--verbose"):
            cfg["verbose"] += 1; i += 1; continue
        if a.startswith("-v") and set(a[1:]) == {"v"}:
            cfg["verbose"] += len(a) - 1; i += 1; continue
        if a in ("-c", "--cookie", "-H", "--header"):
            if i + 1 >= len(argv): die(f"error: a value is required for '{a} <{a.lstrip('-')}>'")
            cfg["cookies" if a in ("-c", "--cookie") else "headers"].append(argv[i+1])
            i += 2; continue
        if a in value_opts:
            if i + 1 >= len(argv): die(f"error: a value is required for '{a}'")
            key = value_opts[a]; val = argv[i+1]
            if key == "uris": cfg["uris"].append(val)
            elif key == "prefix_file": cfg["prefixes"].extend(read_lines(val))
            elif key == "extension_file": cfg["extensions"].extend(read_lines(val))
            elif key in ("timeout",): cfg[key] = float(val)
            elif key in ("threads", "split", "throttle", "max_depth"): cfg[key] = int(val)
            else: cfg[key] = val
            i += 2; continue
        if a in multi_opts:
            key = multi_opts[a]; vals = []
            i += 1
            while i < len(argv) and not argv[i].startswith("-"):
                vals.append(argv[i]); i += 1
            if not vals: die(f"error: a value is required for '{a}'")
            parts = split_values(vals)
            if key == "whitelist": cfg[key] = parts
            else: cfg[key].extend(parts)
            continue
        if a in flag_opts:
            if a == "--burp":
                cfg["proxy"] = "http://localhost:8080"
            else:
                cfg[flag_opts[a]] = True
            i += 1; continue
        if a.startswith("-"):
            print(f"error: unexpected argument '{a}' found\n\n  tip: to pass '{a}' as a value, use '-- {a}'\n", file=sys.stderr)
            print("Usage: executable [OPTIONS] <uri|--uri-file <uri-file>|--uri <uri>>\n", file=sys.stderr)
            print("For more information, try '--help'.", file=sys.stderr)
            sys.exit(2)
        positional.append(a); i += 1
    if positional:
        cfg["uris"].insert(0, positional[0])
    if cfg["uri_file"]:
        cfg["uris"].extend(read_lines(cfg["uri_file"]))
    if cfg["verb"] not in ("get", "head", "post"):
        die(f"error: invalid value '{cfg['verb']}' for '--verb <http_verb>'\n  [possible values: get, head, post]\n\nFor more information, try '--help'.")
    if not cfg["uris"]:
        print(HELP); sys.exit(2)
    return cfg

def normalize_uri(u):
    parsed = urllib.parse.urlsplit(u)
    if not parsed.scheme or not parsed.netloc:
        die(f"error: invalid value '{u}' for '[uri]': relative URL without a base\n\nFor more information, try '--help'.")
    if not u.endswith("/"):
        u += "/"
    return u

def make_opener(cfg):
    handlers = []
    if cfg.get("no_proxy"):
        handlers.append(urllib.request.ProxyHandler({}))
    elif cfg.get("proxy"):
        handlers.append(urllib.request.ProxyHandler({"http": cfg["proxy"], "https": cfg["proxy"]}))
    if cfg.get("ignore_cert"):
        handlers.append(urllib.request.HTTPSHandler(context=ssl._create_unverified_context()))
    return urllib.request.build_opener(*handlers)

def auth_from_url(url, headers, cfg):
    p = urllib.parse.urlsplit(url)
    username = cfg.get("username") or urllib.parse.unquote(p.username or "")
    password = cfg.get("password") or urllib.parse.unquote(p.password or "")
    if username or password:
        token = base64.b64encode(f"{username}:{password}".encode()).decode()
        headers["Authorization"] = "Basic " + token
    if p.username or p.password:
        netloc = p.hostname or ""
        if p.port: netloc += f":{p.port}"
        url = urllib.parse.urlunsplit((p.scheme, netloc, p.path, p.query, p.fragment))
    return url, headers

def fetch(opener, url, cfg):
    headers = {}
    if cfg.get("user_agent"): headers["User-Agent"] = cfg["user_agent"]
    if cfg["cookies"]: headers["Cookie"] = "; ".join(cfg["cookies"])
    for h in cfg["headers"]:
        if ":" in h:
            k, v = h.split(":", 1); headers[k.strip()] = v.strip()
        elif h.endswith(";"):
            headers[h[:-1]] = ""
    url, headers = auth_from_url(url, headers, cfg)
    method = cfg["verb"].upper()
    data = b"" if method == "POST" else None
    req = urllib.request.Request(url, headers=headers, method=method.upper(), data=data)
    try:
        with opener.open(req, timeout=cfg["timeout"]) as r:
            body = b"" if method == "HEAD" else r.read()
            return r.getcode(), dict(r.headers), body, r.geturl(), None
    except urllib.error.HTTPError as e:
        body = b"" if method == "HEAD" else e.read()
        return e.code, dict(e.headers), body, e.geturl(), None
    except Exception as e:
        return None, {}, b"", url, e

def content_len(headers, body):
    if "Content-Length" in headers:
        try: return int(headers["Content-Length"])
        except Exception: pass
    return len(body)

def is_listable(body):
    text = body[:4096].decode("utf-8", "ignore").lower()
    return "directory listing for" in text or "<title>index of" in text or "parent directory" in text

def code_set(values):
    s = set()
    for v in values or []:
        try: s.add(int(v))
        except Exception: pass
    return s

def hidden_by_length(n, specs):
    for spec in specs:
        if "-" in spec:
            a, b = spec.split("-", 1)
            try:
                if int(a) <= n <= int(b): return True
            except Exception: pass
        else:
            try:
                if n == int(spec): return True
            except Exception: pass
    return False

def candidate_paths(words, cfg):
    exts = cfg["extensions"]
    prefixes = cfg["prefixes"] or [""]
    seen = set()
    for raw in words:
        base_words = []
        if cfg["ext_sub"] and "%EXT%" in raw and exts:
            for ext in exts:
                base_words.append(raw.replace("%EXT%", ext))
        else:
            base_words.append(raw)
        for w in base_words:
            for pre in prefixes:
                q = pre + w
                names = []
                if not cfg["force_ext"] and "%EXT%" not in q:
                    names.append(q)
                if exts and not cfg["ext_sub"]:
                    for ext in exts:
                        e = ext if ext.startswith(".") else "." + ext
                        names.append(q + e)
                elif cfg["force_ext"] and not exts:
                    names.append(q)
                for name in names:
                    if name and name not in seen:
                        seen.add(name); yield name

def result_line(r):
    mark = "L" if r["is_listable"] else ("D" if r["is_directory"] else "+")
    extra = f"|REDIR:{r['redirect_url']}" if r.get("redirect_url") else ""
    return f"{mark} {r['url']} (CODE:{r['code']}|SIZE:{r['size']}{extra})"

def scan_base(base, words, cfg, opener):
    results = []
    not_found = {404}
    if not cfg["disable_validator"] and cfg["whitelist"] is None:
        seen_codes = set()
        for _ in range(3):
            rnd = "".join(random.choice(string.ascii_letters + string.digits) for _ in range(random.randint(10, 30)))
            code, headers, body, final, err = fetch(opener, urllib.parse.urljoin(base, rnd), cfg)
            if code is not None: seen_codes.add(code)
        not_found = seen_codes or {404}
        if not cfg["silent"]:
            codes = ",".join(f"CODE:{c}" for c in sorted(not_found))
            print(f"[INFO] Detected nonexistent paths for {base} are ({codes})")
    blacklist = code_set(cfg["blacklist"]) | (set() if cfg["whitelist"] is not None else not_found)
    whitelist = code_set(cfg["whitelist"]) if cfg["whitelist"] is not None else None
    for name in candidate_paths(words, cfg):
        if cfg.get("throttle"):
            time.sleep(cfg["throttle"] / 1000.0)
        urls = []
        if not cfg["force_ext"] and "." not in os.path.basename(name.rstrip("/")):
            urls.append(urllib.parse.urljoin(base, name.rstrip("/") + "/"))
        urls.append(urllib.parse.urljoin(base, name))
        for url in urls:
            code, headers, body, final, err = fetch(opener, url, cfg)
            if err or code is None:
                if cfg["verbose"]:
                    print(f"Curl error after requesting {url} : {err}")
                continue
            size = content_len(headers, body)
            show = (code in whitelist) if whitelist is not None else (code not in blacklist and code < 500)
            if hidden_by_length(size, cfg["hide_lengths"]): show = False
            if ".ht" in url and code == 403 and not cfg["show_htaccess"]: show = False
            if not show: continue
            directory = url.endswith("/") or (300 <= code < 400 and final.endswith("/"))
            listable = directory and is_listable(body)
            r = {"url": url, "code": code, "size": size, "is_directory": directory,
                 "is_listable": listable, "redirect_url": "" if final == url else final,
                 "found_from_listable": False}
            results.append(r)
            if not cfg["silent"]:
                print(result_line(r))
            break
    return results

def text_report(base, results):
    files = [r for r in results if not r["is_directory"]]
    dirs = [r for r in results if r["is_directory"]]
    lines = [f"Dirble Scan Report for {base}:"]
    for r in files:
        lines.append(result_line(r))
    lines.append("")
    for r in dirs:
        lines.append(result_line(r))
    lines.append("")
    return "\n".join(lines)

def write_outputs(cfg, all_results, bases):
    if cfg["output_all"]:
        cfg["output_file"] = cfg["output_all"] + ".txt"
        cfg["json_file"] = cfg["output_all"] + ".json"
        cfg["xml_file"] = cfg["output_all"] + ".xml"
    flat = []
    for _, rs in all_results:
        flat.extend([r for r in rs if not r["is_directory"]])
        flat.extend([r for r in rs if r["is_directory"]])
    if cfg["output_file"]:
        with open(cfg["output_file"], "w") as f:
            for base, rs in all_results:
                f.write(text_report(base, rs))
    if cfg["json_file"]:
        arr = []
        for r in flat:
            arr.append({"url": r["url"], "code": r["code"], "size": r["size"],
                        "is_directory": r["is_directory"], "is_listable": r["is_listable"],
                        "redirect_url": r["redirect_url"], "found_from_listable": False})
        with open(cfg["json_file"], "w") as f:
            if not arr: f.write("[]")
            else:
                f.write("[")
                f.write(",\n".join(json.dumps(x, separators=(",", ":")) for x in arr))
                f.write("]")
    if cfg["xml_file"]:
        with open(cfg["xml_file"], "w") as f:
            f.write('<?xml version="1.0" encoding="UTF-8"?>\n<dirble_scan>\n')
            for r in flat:
                f.write('<path url="%s" code="%s" content_len="%s" is_directory="%s" is_listable="%s" redirect_url="%s" found_from_listable="false"/>\n' % (
                    xml.sax.saxutils.escape(r["url"], {'"': '&quot;'}), r["code"], r["size"],
                    str(r["is_directory"]).lower(), str(r["is_listable"]).lower(),
                    xml.sax.saxutils.escape(r["redirect_url"], {'"': '&quot;'})))
            f.write("</dirble_scan>")

def main():
    cfg = parse(sys.argv[1:])
    bases = [normalize_uri(u) for u in cfg["uris"]]
    if not cfg["wordlist"]:
        cfg["wordlist"] = os.path.join(os.path.dirname(os.path.abspath(sys.argv[0])), "dirble_wordlist.txt")
    words = read_lines(cfg["wordlist"])
    opener = make_opener(cfg)
    all_results = []
    for base in bases:
        all_results.append((base, scan_base(base, words, cfg, opener)))
    write_outputs(cfg, all_results, bases)

if __name__ == "__main__":
    main()
