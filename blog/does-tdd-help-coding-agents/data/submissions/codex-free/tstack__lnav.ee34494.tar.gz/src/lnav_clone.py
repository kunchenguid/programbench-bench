#!/usr/bin/env python3
import os
import re
import shlex
import sqlite3
import subprocess
import sys
from datetime import datetime

VERSION = "lnav 0.14.0-07efb63"

HELP = """usage: ./executable [options] [logfile1 logfile2 ...]

A log file viewer for the terminal that indexes log messages to
make it easier to navigate through files quickly.

Key Bindings
  ?    View/leave the online help text.
  q    Quit the program.

Options
  -h         Print this message, then exit.
  -H         Display the internal help text.

  -I dir     An additional configuration directory.
  -W         Print warnings related to lnav's configuration.
  -u         Update formats installed from git repositories.
  -d file    Write debug messages to the given file.
  -V         Print version information.

  -S,--since Only index log content since this time.
  -U,--until Only index log content until this time.
  -r         Recursively load files from the given directory hierarchies.
  -R         Load older rotated log files as well.
  -c cmd     Execute a command after the files have been loaded.
  -f file    Execute the commands in the given file.
  -e cmd     Execute a shell command-line.
  -t         Treat data piped into standard in as a log file.
  -n         Run without the curses UI. (headless mode)
  -N         Do not open the default syslog file if no files are given.
  -q         Do not print informational messages.

Optional arguments
  logfileN   The log files, directories, or remote paths to view.
             If a directory is given, all of the files in the
             directory will be loaded.

Management-Mode Options
  -i         Install the given format files and exit.  Pass 'extra'
             to install the default set of third-party formats.
  -m         Switch to the management command-line mode.  This mode
             is used to work with lnav's configuration.

Examples
 • To load and follow the syslog file:
     $ lnav                                  

 • To load all of the files in /var/log:
     $ lnav /var/log                         

 • To watch the output of make:
     $ lnav -e 'make -j4'                    

Paths
 • This binary:
    🧭 /workspace/executable
 • Format files are read from:
    📂 /etc/lnav
    📂 /usr/etc/lnav
 • Configuration, session, and format files are stored in:
    📂 /home/agent/.config/lnav

 • Local copies of remote files, files extracted from
   archives, execution output, and so on are stored in:
    📂 /tmp/lnav-user-1000-work

Documentation: https://docs.lnav.org
Contact
  💬 https://github.com/tstack/lnav/discussions
  📫 lnav@googlegroups.com
Version: lnav 0.14.0-07efb63
"""

ISO_RE = re.compile(r"(\d{4})-(\d{2})-(\d{2})(?:[T ][0-9:.+-]+Z?)?")


def err(msg, reason=None, help_text=None):
    print(f"  error: {msg}", file=sys.stderr)
    if reason:
        print(f" reason: {reason}", file=sys.stderr)
    if help_text:
        print(f" = help: {help_text}", file=sys.stderr)


def parse_time(s):
    if not s:
        return None
    m = ISO_RE.search(s)
    if m:
        return datetime(int(m.group(1)), int(m.group(2)), int(m.group(3)))
    for fmt in ("%Y/%m/%d", "%m/%d/%Y"):
        try:
            return datetime.strptime(s[:10], fmt)
        except ValueError:
            pass
    return None


def line_time(line):
    return parse_time(line)


class Opts:
    def __init__(self):
        self.headless = False
        self.no_default = False
        self.quiet = False
        self.stdin_log = False
        self.recursive = False
        self.commands = []
        self.execs = []
        self.files = []
        self.since = None
        self.until = None
        self.debug = None


def parse(argv):
    o = Opts()
    i = 0
    while i < len(argv):
        a = argv[i]
        if a in ("-h", "--help"):
            print(HELP, end="")
            sys.exit(0)
        if a in ("-V", "--version"):
            print(VERSION)
            sys.exit(0)
        if a in ("-n",):
            o.headless = True
        elif a == "-N":
            o.no_default = True
        elif a == "-q":
            o.quiet = True
        elif a == "-t":
            o.stdin_log = True
        elif a == "-r":
            o.recursive = True
        elif a == "-R":
            pass
        elif a in ("-W", "-u", "-C", "-m"):
            pass
        elif a in ("-H",):
            if not sys.stdout.isatty() and not o.headless:
                err("unable to display interactive text UI", "stdout is not a TTY",
                    "pass the -n option to run lnav in headless mode or don't redirect stdout")
                sys.exit(1)
            print(HELP, end="")
            sys.exit(0)
        elif a in ("-I", "-d", "-c", "-f", "-e", "-i", "-S", "--since", "-U", "--until"):
            if i + 1 >= len(argv):
                err("invalid command-line arguments", f"The argument '{a}' requires a value")
                sys.exit(109)
            v = argv[i + 1]
            i += 1
            if a == "-c":
                o.commands.append(v)
            elif a == "-f":
                try:
                    with open(v, "r", encoding="utf-8", errors="replace") as f:
                        o.commands.extend([ln.rstrip("\n") for ln in f])
                except OSError as e:
                    err(f"unable to open file: {v}", e.strerror)
                    sys.exit(1)
            elif a == "-e":
                o.execs.append(v)
            elif a in ("-S", "--since"):
                o.since = parse_time(v)
            elif a in ("-U", "--until"):
                o.until = parse_time(v)
            elif a == "-d":
                o.debug = v
            elif a == "-i":
                pass
        elif a.startswith("-"):
            err("invalid command-line arguments", f"The following argument was not expected: {a}")
            sys.exit(109)
        else:
            o.files.append(a)
        i += 1
    return o


def collect_path(path, recursive=False):
    out = []
    if os.path.isdir(path):
        if recursive:
            for root, dirs, files in os.walk(path):
                dirs.sort()
                for name in sorted(files):
                    out.extend(read_file(os.path.join(root, name)))
        else:
            for name in sorted(os.listdir(path)):
                p = os.path.join(path, name)
                if os.path.isfile(p):
                    out.extend(read_file(p))
                    break
    else:
        out.extend(read_file(path))
    return out


def read_file(path):
    if not os.path.exists(path):
        err(f"unable to open file: {path}", "No such file or directory")
        sys.exit(1)
    try:
        with open(path, "r", encoding="utf-8", errors="replace") as f:
            return [ln.rstrip("\n") for ln in f]
    except OSError as e:
        err(f"unable to open file: {path}", e.strerror)
        sys.exit(1)


def apply_range(lines, opts):
    if not opts.since and not opts.until:
        return lines
    res = []
    for ln in lines:
        t = line_time(ln)
        if t is None:
            res.append(ln)
            continue
        if opts.since and t < opts.since:
            continue
        if opts.until and t > opts.until:
            continue
        res.append(ln)
    return res


def run_sql(sql):
    con = sqlite3.connect(":memory:")
    try:
        cur = con.execute(sql)
        rows = cur.fetchall()
        cols = [d[0] for d in cur.description or []]
    except Exception as e:
        err(str(e))
        return True
    if cols:
        widths = [max(len(str(c)), *(len(str(r[i])) for r in rows)) for i, c in enumerate(cols)]
        print(" ".join(str(c).rjust(widths[i] + 4) for i, c in enumerate(cols)))
        for r in rows:
            print(" ".join(str(v).rjust(widths[i] + 4) for i, v in enumerate(r)))
    return True


def execute_command(cmd, lines):
    s = cmd.strip()
    if not s:
        return lines, False
    if s.startswith(";"):
        run_sql(s[1:].strip())
        return lines, True
    if s.startswith("/"):
        return lines, False
    if s.startswith(":"):
        body = s[1:].strip()
        parts = shlex.split(body) if body else []
        name = parts[0] if parts else ""
        arg = body[len(name):].strip()
        if name == "echo":
            print(arg)
            return lines, True
        if name in ("filter-in", "filter"):
            try:
                rx = re.compile(arg)
                return [ln for ln in lines if rx.search(ln)], False
            except re.error:
                return [ln for ln in lines if arg in ln], False
        if name == "filter-out":
            try:
                rx = re.compile(arg)
                return [ln for ln in lines if not rx.search(ln)], False
            except re.error:
                return [ln for ln in lines if arg not in ln], False
        if name in ("quit", "q"):
            return lines, True
        if name == "write-to":
            err("no lines marked to write, use 'm' to mark lines")
            print(" --> command-option:1", file=sys.stderr)
            print(f" | {s:<40}", file=sys.stderr)
            print(" = help: :write-to [--anonymize] path", file=sys.stderr)
            return lines, True
        print(f"  error: unknown command: “{name}”", file=sys.stderr)
        return lines, True
    return lines, False


def main():
    opts = parse(sys.argv[1:])
    if opts.debug:
        try:
            open(opts.debug, "a").close()
        except OSError:
            pass
    if not opts.headless and not sys.stdout.isatty():
        err("unable to display interactive text UI", "stdout is not a TTY",
            "pass the -n option to run lnav in headless mode or don't redirect stdout")
        return 1

    lines = []
    for cmd in opts.execs:
        p = subprocess.run(cmd, shell=True, text=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
        if p.stdout:
            lines.extend(p.stdout.splitlines())
    if opts.stdin_log:
        lines.extend(sys.stdin.read().splitlines())
    for p in opts.files:
        lines.extend(collect_path(p, opts.recursive))

    if not lines and not opts.no_default and not opts.commands and not opts.execs:
        err("nothing to do", "no files given or default files found",
            "use the “-N” option to open lnav without loading any files")
        return 1

    lines = apply_range(lines, opts)
    command_printed = False
    for c in opts.commands:
        lines, printed = execute_command(c, lines)
        command_printed = command_printed or printed

    if not opts.commands or not command_printed:
        if not (opts.quiet and opts.commands):
            for ln in lines:
                print(ln)
    return 0


if __name__ == "__main__":
    sys.exit(main())
