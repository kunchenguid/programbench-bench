#!/usr/bin/env python3
import sys, os, glob, re
from urllib.parse import urljoin

for pat in ("/opt/deps/python/wheels/beautifulsoup4-*.whl", "/opt/deps/python/wheels/soupsieve-*.whl"):
    sys.path[:0] = glob.glob(pat)

from bs4 import BeautifulSoup, NavigableString, Comment, Doctype

VERSION = "htmlq 0.4.0"
HELP = """htmlq 0.4.0
Michael Maclean <michael@mgdm.net>
Runs CSS selectors on HTML

USAGE:
    executable [FLAGS] [OPTIONS] [--] [selector]...

FLAGS:
    -B, --detect-base          Try to detect the base URL from the <base> tag in the document. If not found, default to
                               the value of --base, if supplied
    -h, --help                 Prints help information
    -w, --ignore-whitespace    When printing text nodes, ignore those that consist entirely of whitespace
    -p, --pretty               Pretty-print the serialised output
    -t, --text                 Output only the contents of text nodes inside selected elements
    -V, --version              Prints version information

OPTIONS:
    -a, --attribute <attribute>         Only return this attribute (if present) from selected elements
    -b, --base <base>                   Use this URL as the base for links
    -f, --filename <FILE>               The input file. Defaults to stdin
    -o, --output <FILE>                 The output file. Defaults to stdout
    -r, --remove-nodes <SELECTOR>...    Remove nodes matching this expression before output. May be specified multiple
                                        times

ARGS:
    <selector>...    The CSS expression to select [default: html]
"""

VOID_TAGS = set("area base br col embed hr img input link meta param source track wbr".split())

class Opts:
    def __init__(self):
        self.detect_base = False
        self.ignore_ws = False
        self.pretty = False
        self.text = False
        self.attribute = None
        self.base = None
        self.filename = None
        self.output = None
        self.removes = []
        self.selector_parts = []


def die(msg, code=1):
    print(msg, file=sys.stderr)
    sys.exit(code)


def parse_args(argv):
    o = Opts(); i = 0; after_dash = False
    while i < len(argv):
        a = argv[i]
        if after_dash:
            o.selector_parts.append(a); i += 1; continue
        if a == "--":
            after_dash = True; i += 1; continue
        if a in ("-h", "--help"):
            print(HELP, end=""); sys.exit(0)
        if a in ("-V", "--version"):
            print(VERSION); sys.exit(0)
        if a in ("-B", "--detect-base"):
            o.detect_base = True; i += 1; continue
        if a in ("-w", "--ignore-whitespace"):
            o.ignore_ws = True; i += 1; continue
        if a in ("-p", "--pretty"):
            o.pretty = True; i += 1; continue
        if a in ("-t", "--text"):
            o.text = True; i += 1; continue
        if a in ("-a", "--attribute", "-b", "--base", "-f", "--filename", "-o", "--output"):
            if i + 1 >= len(argv): die("error: The argument requires a value")
            val = argv[i+1]
            if a in ("-a", "--attribute"): o.attribute = val
            elif a in ("-b", "--base"): o.base = val
            elif a in ("-f", "--filename"): o.filename = val
            else: o.output = val
            i += 2; continue
        if a in ("-r", "--remove-nodes"):
            i += 1
            vals = []
            while i < len(argv) and not argv[i].startswith('-'):
                vals.append(argv[i]); i += 1
            if not vals: die("error: The argument '--remove-nodes <SELECTOR>...' requires a value")
            o.removes.append(" ".join(vals))
            continue
        if a.startswith("--attribute="):
            o.attribute = a.split("=",1)[1]; i += 1; continue
        if a.startswith("--base="):
            o.base = a.split("=",1)[1]; i += 1; continue
        if a.startswith("--filename="):
            o.filename = a.split("=",1)[1]; i += 1; continue
        if a.startswith("--output="):
            o.output = a.split("=",1)[1]; i += 1; continue
        if a.startswith('-'):
            # support compact common flags like -tw
            if len(a) > 2 and all(c in "Bwpt" for c in a[1:]):
                for c in a[1:]:
                    if c == 'B': o.detect_base = True
                    elif c == 'w': o.ignore_ws = True
                    elif c == 'p': o.pretty = True
                    elif c == 't': o.text = True
                i += 1; continue
            die("error: Found argument '%s' which wasn't expected" % a)
        o.selector_parts.append(a); i += 1
    return o


def ensure_document(html):
    if re.search(r"<\s*html(?:\s|>)", html, re.I):
        return html
    return "<html><head></head><body>" + html + "</body></html>"


def esc_text(s):
    return s.replace('&', '&amp;').replace('\xa0', '&nbsp;').replace('<', '&lt;').replace('>', '&gt;')


def esc_attr(s):
    return str(s).replace('&', '&amp;').replace('\xa0', '&nbsp;').replace('"', '&quot;').replace('<', '&lt;').replace('>', '&gt;')


def attrs_for(tag, base_url):
    pieces = []
    for k in sorted(tag.attrs.keys()):
        v = tag.attrs[k]
        if isinstance(v, list):
            v = " ".join(str(x) for x in v)
        elif v is None:
            v = ""
        else:
            v = str(v)
        if base_url and k.lower() == "href":
            v = urljoin(base_url, v)
        pieces.append(f'{k}="{esc_attr(v)}"')
    return (" " + " ".join(pieces)) if pieces else ""


def serialize(node, base_url=None):
    if isinstance(node, Doctype):
        return "<!DOCTYPE %s>" % str(node)
    if isinstance(node, Comment):
        return "<!--%s-->" % str(node)
    if isinstance(node, NavigableString):
        return esc_text(str(node))
    if getattr(node, 'name', None) is None:
        return ''.join(serialize(c, base_url) for c in getattr(node, 'contents', []))
    name = node.name
    start = f"<{name}{attrs_for(node, base_url)}>"
    if name.lower() in VOID_TAGS:
        return start
    return start + ''.join(serialize(c, base_url) for c in node.contents) + f"</{name}>"


def pretty_serialize(node, base_url=None):
    # BeautifulSoup's formatter is close enough for pretty output; normalize void tags.
    s = node.prettify(formatter="html")
    s = re.sub(r"<(br|img|input|meta|link|hr)([^>]*)/>", r"<\1\2>", s)
    return s.rstrip('\n')


def text_nodes(node):
    for c in node.descendants:
        if isinstance(c, NavigableString) and not isinstance(c, (Comment, Doctype)):
            yield str(c)


def main(argv):
    opts = parse_args(argv)
    try:
        data = open(opts.filename, 'r', encoding='utf-8', errors='replace').read() if opts.filename else sys.stdin.read()
    except OSError as e:
        die(str(e))
    soup = BeautifulSoup(ensure_document(data), 'html.parser')

    base_url = opts.base
    if opts.detect_base:
        b = soup.find('base')
        if b and b.has_attr('href'):
            base_url = b.get('href')

    for r in opts.removes:
        for n in list(soup.select(r)):
            n.decompose()

    selector = ' '.join(opts.selector_parts).strip() or 'html'
    try:
        selected = soup.select(selector)
    except Exception as e:
        print("Failed to parse CSS selector: %s" % e, file=sys.stderr)
        sys.exit(101)

    out_lines = []
    if opts.attribute is not None:
        for n in selected:
            if n.has_attr(opts.attribute):
                v = n.get(opts.attribute)
                if isinstance(v, list): v = " ".join(v)
                if base_url and opts.attribute.lower() == 'href':
                    v = urljoin(base_url, str(v))
                out_lines.append(str(v))
    elif opts.text:
        if opts.ignore_ws:
            for n in selected:
                for t in text_nodes(n):
                    if t.strip() != '': out_lines.append(t)
                out_lines.append('')
        else:
            for n in selected:
                out_lines.append(''.join(text_nodes(n)))
    else:
        for n in selected:
            out_lines.append(pretty_serialize(n, base_url) if opts.pretty else serialize(n, base_url))

    out = ''.join(x + '\n' for x in out_lines)
    if opts.output:
        with open(opts.output, 'w', encoding='utf-8') as f: f.write(out)
    else:
        sys.stdout.write(out)

if __name__ == '__main__':
    main(sys.argv[1:])
