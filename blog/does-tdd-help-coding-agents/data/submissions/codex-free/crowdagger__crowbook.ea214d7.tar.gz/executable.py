#!/usr/bin/env python3
import argparse
import html
import os
import re
import sys
import zipfile
from pathlib import Path

VERSION = "crowbook 0.17.0"

HELP = """crowbook 0.17.0 by Élisabeth Henry <liz.henry@ouvaton.org>
Render a Markdown book in EPUB, PDF or HTML.
  
USAGE:
    executable [OPTIONS] [BOOK]

OPTIONS:
  -f, --force-emoji
          Force emoji usage even if it might not work on your system
  -s, --single
          Use a single Markdown file instead of a book configuration file
  -n, --no-fancy
          Disably fancy UI
  -v, --verbose
          Print warnings in parsing/rendering
  -a, --autograph
          Prompts for an autograph for this book
  -q, --quiet
          Don't print info/error messages
  -c, --create <files>...
          Create a new book with existing Markdown files
  -o, --output <output>
          Specify output file
  -t, --to <to>
          Generate specific format
      --set <set> <set>...
          Set a list of book options
  -l, --list-options
          List all possible options
  -L, --lang <lang>
          Set the runtime language used by Crowbook
      --print-template <print-template>
          Prints the default content of a template
  -S, --stats
          Print some project statistics
  -h, --help
          Print help
  -V, --version
          Print version

ARGS:
  [BOOK]  File containing the book configuration file, or a Markdown file when called with --single"""

CREATE_TEMPLATE = '''"author: Your name"
"title: Your title"
"lang: en"

"## Output formats"

"# Uncomment and fill to generate files"
"# output.html: some_file.html"
"# output.epub: some_file.epub"
"# output.pdf: some_file.pdf"

"# Or uncomment the following to generate PDF, HTML and EPUB files based on this file's name"
"# output: [pdf, epub, html]"

"# Uncomment and fill to set cover image (for EPUB)"
"# cover: some_cover.png"

## List of chapters'''

CSS = '''body {
    font-family: "Linux Libertine", "Georgia", serif;
    text-align: justify;
    font-size: 100%;
}
p { text-indent: 1.25em; margin:0; hyphens: auto; }
h1, h2, h3, h4, h5, h6 {
    text-align: left;
    font-family: Linux Biolinum, sans-serif;
    font-variant: small-caps;
}
span.chapter-header { font-size: 75%; }
h1.title { text-align: center; font-size: 300%; }
h2.author { text-align: right; font-size: 200%; }
li:before { content: none; }
'''

JS = '''function on(name) {
    var elements = document.getElementsByClassName(name);
    for (var i = 0; i < elements.length; i++) {
        var elem = elements[i];
        elem.style.backgroundColor = "pink";
    }
}
function off(name) {
    var elements = document.getElementsByClassName(name);
    for (var i = 0; i < elements.length; i++) {
        var elem = elements[i];
        elem.style.backgroundColor = "white";
    }
}
'''

def crow(msg=None, quiet=False):
    if not quiet:
        print("CROWBOOK 0.17.0")
        if msg:
            print(msg)

def eprint(s):
    print(s, file=sys.stderr)

def parse_args(argv):
    if any(a in ("-h", "--help") for a in argv):
        print(HELP)
        sys.exit(0)
    if any(a in ("-V", "--version") for a in argv):
        print(VERSION)
        sys.exit(0)
    known_flags = {"-f","--force-emoji","-s","--single","-n","--no-fancy","-v","--verbose","-a","--autograph","-q","--quiet","-l","--list-options","-S","--stats"}
    takes_one = {"-o","--output","-t","--to","-L","--lang","--print-template"}
    out = {"single":False,"quiet":False,"create":None,"output":None,"to":None,"list_options":False,"print_template":None,"stats":False,"set":[],"book":None,"lang":None}
    i = 0
    positional = []
    while i < len(argv):
        a = argv[i]
        if a in known_flags:
            if a in ("-s","--single"): out["single"] = True
            elif a in ("-q","--quiet"): out["quiet"] = True
            elif a in ("-l","--list-options"): out["list_options"] = True
            elif a in ("-S","--stats"): out["stats"] = True
            i += 1
        elif a in takes_one:
            if i + 1 >= len(argv):
                eprint(f"error: a value is required for '{a}' but none was supplied")
                sys.exit(2)
            v = argv[i+1]
            if a in ("-o","--output"): out["output"] = v
            elif a in ("-t","--to"): out["to"] = v
            elif a in ("-L","--lang"): out["lang"] = v
            else: out["print_template"] = v
            i += 2
        elif a == "--set":
            i += 1
            while i < len(argv) and argv[i].startswith("-") is False:
                out["set"].append(argv[i]); i += 1
        elif a in ("-c","--create"):
            out["create"] = argv[i+1:]
            break
        elif a.startswith("-"):
            eprint(f"error: unexpected argument '{a}' found\n\n  tip: to pass '{a}' as a value, use '-- {a}'\n\nUsage: executable [OPTIONS] [BOOK]\n\nFor more information, try '--help'.")
            sys.exit(2)
        else:
            positional.append(a); i += 1
    if positional:
        out["book"] = positional[0]
    return out

def load_list_options():
    p = Path(__file__).with_name("listopts.txt")
    if p.exists():
        return p.read_text()
    return """CROWBOOK 0.17.0
METADATA
author
  type: metadata (default: "")
  Author of the book
title
  type: metadata (default: "")
  Title of the book
lang
  type: metadata (default: en)
  Language of the book

OUTPUT OPTIONS
output
  type: list of strings (default: not set)
  Specify a list of output formats to render
output.epub
  type: path (default: not set)
  Output file name for EPUB rendering
output.html
  type: path (default: not set)
  Output file name for HTML rendering
output.pdf
  type: path (default: not set)
  Output file name for PDF rendering
"""

def parse_config(path):
    opts = {"title":"","author":"","lang":"en"}
    chapters = []
    base = Path(path).parent
    for no, line in enumerate(Path(path).read_text(errors="replace").splitlines(), 1):
        s = line.strip()
        if not s or s.startswith("#"): continue
        if s[0] in "+-!":
            chap = s[1:].strip()
            chapters.append((chap, no))
        elif ":" in s:
            k, v = s.split(":", 1)
            opts[k.strip()] = v.strip().strip('"')
    return opts, chapters, base

def parse_single(path):
    text = Path(path).read_text(errors="replace")
    opts = {"title":"","author":"","lang":"en"}
    if text.startswith("---"):
        parts = text.split("---", 2)
        if len(parts) >= 3:
            for line in parts[1].splitlines():
                if ":" in line:
                    k, v = line.split(":", 1)
                    opts[k.strip()] = v.strip().strip('"')
            text = parts[2]
    return opts, [(path, 1, text)], Path(path).parent

def inline_md(s):
    s = html.escape(s)
    s = re.sub(r"\*\*(.+?)\*\*", r"<b>\1</b>", s)
    s = re.sub(r"\*(.+?)\*", r"<em>\1</em>", s)
    s = re.sub(r"`(.+?)`", r"<code>\1</code>", s)
    s = re.sub(r"\[(.*?)\]\((.*?)\)", r'<a href="\2">\1</a>', s)
    return s

def md_to_html(text, chapter_num=1, start_para=1):
    out = []
    para = []
    pid = start_para
    first_h1 = True
    in_ul = False
    def flush():
        nonlocal para, pid
        if para:
            out.append(f'<p id = "para-{pid}">' + inline_md(" ".join(para).strip()) + "</p>")
            pid += 1
            para = []
    for raw in text.splitlines():
        line = raw.rstrip()
        if not line.strip():
            flush()
            if in_ul:
                out.append("</ul>"); in_ul=False
            continue
        if line.startswith("#"):
            flush()
            if in_ul:
                out.append("</ul>"); in_ul=False
            level = len(line) - len(line.lstrip("#"))
            title = inline_md(line[level:].strip())
            if level == 1 and first_h1:
                out.append(f"<h1 id = 'link-{chapter_num}'><span class = 'chapter-header'>Chapter {chapter_num}</span><br />{title}</h1>")
                first_h1 = False
            else:
                out.append(f'<h{level} id = "link-{chapter_num+1}">{title}</h{level}>')
        elif line.lstrip().startswith(("- ", "* ")):
            flush()
            if not in_ul:
                out.append("<ul>"); in_ul=True
            out.append(f'<li><p id = "para-{pid}">{inline_md(line.lstrip()[2:].strip())}</p>')
            pid += 1
        else:
            para.append(line.strip())
    flush()
    if in_ul:
        out.append("</ul>")
    return "\n".join(out), pid

def html_doc(opts, chapter_html):
    lang = html.escape(opts.get("lang") or "en")
    title = html.escape(opts.get("title") or "")
    author = html.escape(opts.get("author") or "")
    return f'''<!DOCTYPE html>
<html lang="{lang}">
  <head>
    <meta charset="utf-8">
    <meta name="generator" content="crowbook">
    <meta name="viewport" content="width=device-width">
    <meta name="author" content="{author}">
    
    <title>{title}</title>
    <style type = "text/css">
      {CSS}
    </style>
   <script>
    {JS}
   </script>
  </head>
  <body>
<script type = 'application/ld+json'>
{{
    "@context": "http://schema.org/",
    "@type": "Book",
    "author": "{author}",
    "name": "{title}",
    "inLanguage": "{lang}"
}}
</script>
    <div id = "content">
      <div id = "page">
        <header>
          <div id = "menu">
          </div>
          <h2 class="author">{author}</h2>
          <h1 id = "link-0" class="title" >{title}</h1>
        </header>
{chapter_html}
      </div>
    </div>
  </body>
</html>
'''

def collect_chapters(opts, chapters, base, source_label=None):
    result = []
    if chapters and len(chapters[0]) == 3:
        return [(Path(chapters[0][0]).name, chapters[0][2])]
    for chap, no in chapters:
        p = base / chap
        if not p.exists():
            if source_label:
                crow(f"ERROR {source_label}:{no}: Could not find file '{p.as_posix()}' for book chapter")
            else:
                crow(f"ERROR {chap}: Could not find file '{chap}' for book chapter")
            return None
        result.append((chap, p.read_text(errors="replace")))
    return result

def render_html(opts, chaps):
    blocks = []
    para = 1
    for i, (_, text) in enumerate(chaps, 1):
        body, para = md_to_html(text, i, para)
        blocks.append(f'<div id = "chapter-{i-1}" class = "chapter">\n  {body}\n\n</div>')
    return html_doc(opts, "\n".join(blocks))

def write_epub(path, opts, chaps):
    body = render_html(opts, chaps)
    with zipfile.ZipFile(path, "w") as z:
        z.writestr("mimetype", "application/epub+zip")
        z.writestr("META-INF/container.xml", '<?xml version="1.0"?><container version="1.0" xmlns="urn:oasis:names:tc:opendocument:xmlns:container"><rootfiles><rootfile full-path="content.opf" media-type="application/oebps-package+xml"/></rootfiles></container>')
        z.writestr("content.opf", f'<package version="3.0" xmlns="http://www.idpf.org/2007/opf"><metadata><dc:title xmlns:dc="http://purl.org/dc/elements/1.1/">{html.escape(opts.get("title",""))}</dc:title></metadata><manifest><item id="html" href="index.html" media-type="application/xhtml+xml"/></manifest><spine><itemref idref="html"/></spine></package>')
        z.writestr("index.html", body)

def stats(chaps):
    rows = []
    total_chars = total_words = 0
    for name, text in chaps:
        words = re.findall(r"\b[\w']+\b", text)
        chars = sum(len(w) for w in words)
        total_chars += chars; total_words += len(words)
        rows.append((name, chars, len(words), (chars / len(words) if words else 0)))
    print("Chapter    Chars      Words  Chars/Word")
    print("---------")
    for name, chars, words, avg in rows:
        print(f"{name:<9}{chars:>7}{words:>11}{avg:>12.2f}")
    print("---------")
    avg = total_chars / total_words if total_words else 0
    print(f"TOTAL:{total_chars:>10}{total_words:>11}{avg:>12.2f}")
    print()

def render(args):
    if not args["book"]:
        crow("ERROR You must pass the name of a book configuration file.\nFor more information try --help.\n", args["quiet"])
        return
    if args["single"]:
        if not Path(args["book"]).exists():
            crow(f"ERROR {args['book']}: Could not find file '{args['book']}' for book chapter", args["quiet"])
            return
        opts, chapters, base = parse_single(args["book"])
        chaps = collect_chapters(opts, chapters, base)
    else:
        if not Path(args["book"]).exists():
            crow(f"ERROR Could not open file '{args['book']}'", args["quiet"])
            return
        opts, chapters, base = parse_config(args["book"])
        chaps = collect_chapters(opts, chapters, base, args["book"])
    if chaps is None:
        return
    if args["lang"]: opts["lang"] = args["lang"]
    for item in args["set"]:
        if ":" in item:
            k,v = item.split(":",1); opts[k.strip()] = v.strip()
    crow(quiet=args["quiet"])
    if args["stats"]:
        stats(chaps)
        return
    fmt = args["to"]
    out = args["output"]
    outputs = []
    if fmt:
        outputs.append((fmt, out))
    else:
        base_out = opts.get("output.base_path", "")
        for key, val in opts.items():
            if key.startswith("output.") and val and key not in ("output.base_path",):
                fmt_key = key.split(".",1)[1]
                if fmt_key == "html.dir":
                    outputs.append(("html.dir", val))
                elif fmt_key in ("html", "epub", "pdf", "tex", "odt"):
                    outputs.append((fmt_key, val))
        if "output" in opts and opts["output"].startswith("["):
            base = Path(args["book"]).stem
            for f in re.findall(r"[A-Za-z]+", opts["output"]):
                outputs.append((f, f"{base}.{f}"))
        if base_out:
            adjusted = []
            for fmt, dest in outputs:
                if dest and dest != "-" and not Path(dest).is_absolute():
                    dest = str(Path(base_out) / dest)
                adjusted.append((fmt, dest))
            outputs = adjusted
    if not outputs:
        if args["single"] and fmt == "html":
            print(render_html(opts, chaps), end="")
        elif args["single"] and not fmt:
            return
        return
    for fmt, dest in outputs:
        fmt = (fmt or "html").lower()
        if not dest:
            dest = "-" if fmt == "html" else f"{Path(args['book']).stem}.{fmt}"
        if fmt == "html":
            content = render_html(opts, chaps)
            if dest == "-":
                print(content, end="")
            else:
                Path(dest).parent.mkdir(parents=True, exist_ok=True)
                Path(dest).write_text(content)
        elif fmt == "html.dir":
            Path(dest).mkdir(parents=True, exist_ok=True)
            Path(dest, "index.html").write_text(render_html(opts, chaps))
        elif fmt == "epub":
            Path(dest).parent.mkdir(parents=True, exist_ok=True)
            write_epub(dest, opts, chaps)
            print("WARNING Crowbook exited successfully, but the following errors occurred:")
            print("WARNING Could not run zip command, falling back to zip library")
        elif fmt in ("tex","pdf","odt"):
            Path(dest).parent.mkdir(parents=True, exist_ok=True)
            Path(dest).write_text(render_html(opts, chaps))

def main():
    args = parse_args(sys.argv[1:])
    if args["list_options"]:
        print(load_list_options(), end="" if load_list_options().endswith("\n") else "\n")
        return
    if args["print_template"]:
        crow()
        name = args["print_template"]
        if name in ("html.css","epub.css"):
            print(CSS)
        elif name == "html.js":
            print(JS)
        else:
            print(f"ERROR {name} is not a valid template name")
        return
    if args["create"] is not None:
        crow()
        print(CREATE_TEMPLATE)
        for f in args["create"]:
            print(f"+ {f}")
        return
    render(args)

if __name__ == "__main__":
    main()
