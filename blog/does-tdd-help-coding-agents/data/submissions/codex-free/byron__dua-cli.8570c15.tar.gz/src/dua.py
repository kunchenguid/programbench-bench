#!/usr/bin/env python3
import os
import sys
import stat

VERSION = "dua 2.32.2"
FORMATS = {"metric", "binary", "bytes", "gb", "gib", "mb", "mib"}
SHELLS = {"bash", "elvish", "fish", "powershell", "zsh"}
GREEN = "\033[32m"
CYAN = "\033[36m"
RESET = "\033[39m"

HELP = """A tool to learn about disk usage, fast!

Usage: dua [FLAGS] [OPTIONS] [SUBCOMMAND] [INPUT]...

Commands:
  interactive  Launch the terminal user interface [aliases: i]
  aggregate    Aggregate the consumed space of one or more directories or files [aliases: a]
  completions  Generate shell completions
  help         Print this message or the help of the given subcommand(s)

Arguments:
  [INPUT]...
          One or more input files or directories. If unset, we will use all entries in the current working directory

Options:
  -t, --threads <THREADS>
          The amount of threads to use. Defaults to 0, indicating the amount of logical processors. Set to 1 to use only a single thread
          
          [default: 0]

  -f, --format <FORMAT>
          The format with which to print byte counts
          
          [default: binary]
          [possible values: metric, binary, bytes, gb, gib, mb, mib]

  -A, --apparent-size
          Display apparent size instead of disk usage

  -l, --count-hard-links
          Count hard-linked files each time they are seen

  -x, --stay-on-filesystem
          If set, we will not cross filesystems or traverse mount points

  -i, --ignore-dirs <IGNORE_DIRS>
          One or more absolute directories to ignore. Note that these are not ignored if they are passed as input path.
          
          Hence, they will only be ignored if they are eventually reached as part of the traversal.
          
          [default: /proc /dev /sys /run]

      --log-file <LOG_FILE>
          Write a log file with debug information, including panics

  -h, --help
          Print help (see a summary with '-h')

  -V, --version
          Print version"""

AGG_HELP = """Aggregate the consumed space of one or more directories or files

Usage: executable aggregate [OPTIONS] [INPUT]...

Arguments:
  [INPUT]...  One or more input files or directories. If unset, we will use all entries in the current working directory

Options:
      --stats     If set, print additional statistics about the file traversal to stderr
      --no-sort   If set, paths will be printed in their order of occurrence on the command-line. Otherwise they are sorted by their size in bytes, ascending
      --no-total  If set, no total column will be computed for multiple inputs
  -h, --help      Print help"""

INT_HELP = """Launch the terminal user interface

Usage: executable interactive [OPTIONS] [INPUT]...

Arguments:
  [INPUT]...  One or more input files or directories. If unset, we will use all entries in the current working directory

Options:
  -e, --no-entry-check  Do not check entries for presence when listing a directory to avoid slugging performance on slow filesystems
  -h, --help            Print help"""

COMP_HELP = """Generate shell completions

Usage: executable completions <SHELL>

Arguments:
  <SHELL>  The shell to generate a completions-script for [possible values: bash, elvish, fish, powershell, zsh]

Options:
  -h, --help  Print help"""

class Ctx:
    def __init__(self):
        self.apparent = False
        self.count_hard = False
        self.fmt = "binary"
        self.ignore = {"/proc", "/dev", "/sys", "/run"}
        self.stay = False
        self.seen = set()
        self.errors = 0
        self.entries = 0
        self.smallest = None
        self.largest = 0


def die(msg, code=2):
    print(msg, file=sys.stderr)
    sys.exit(code)


def base_size(st, apparent):
    return int(st.st_size if apparent else getattr(st, "st_blocks", 0) * 512)


def should_count(st, ctx):
    if ctx.count_hard or st.st_nlink <= 1:
        return True
    key = (st.st_dev, st.st_ino)
    if key in ctx.seen:
        return False
    ctx.seen.add(key)
    return True


def scan(path, ctx, root=False, parent_dev=None):
    try:
        st = os.lstat(path)
    except OSError:
        ctx.errors += 1
        return 0, False
    is_dir = stat.S_ISDIR(st.st_mode)
    is_link = stat.S_ISLNK(st.st_mode)
    if is_link:
        return (base_size(st, ctx.apparent) if ctx.apparent else 0), False
    if not should_count(st, ctx):
        return 0, is_dir
    size = base_size(st, ctx.apparent)
    if is_dir:
        if (not root) and os.path.abspath(path) in ctx.ignore:
            return 0, True
        if ctx.stay and parent_dev is not None and st.st_dev != parent_dev:
            return 0, True
        try:
            names = os.listdir(path)
        except OSError:
            ctx.errors += 1
            return size, True
        for name in names:
            child = os.path.join(path, name)
            child_size, _ = scan(child, ctx, False, st.st_dev)
            size += child_size
    ctx.entries += 1
    ctx.smallest = size if ctx.smallest is None else min(ctx.smallest, size)
    ctx.largest = max(ctx.largest, size)
    return size, is_dir


def fmt_size(n, fmt):
    n = float(n)
    if fmt == "bytes":
        return f"{int(n):10d} b"
    if fmt in ("gb", "gib", "mb", "mib"):
        div = {"gb":1_000_000_000, "gib":1024**3, "mb":1_000_000, "mib":1024**2}[fmt]
        unit = {"gb":"GB", "gib":"GiB", "mb":"MB", "mib":"MiB"}[fmt]
        width = 7 if fmt in ("gb", "gib") else 8
        return f"{n/div:{width}.2f} {unit}"
    units = [("B", 1), ("KB" if fmt == "metric" else "KiB", 1000 if fmt == "metric" else 1024), ("MB" if fmt == "metric" else "MiB", (1000 if fmt == "metric" else 1024)**2), ("GB" if fmt == "metric" else "GiB", (1000 if fmt == "metric" else 1024)**3)]
    if n <= units[1][1]:
        unit = "B"
        return f"{int(n):7d} {unit:>3}"
    div = units[1][1]
    unit = units[1][0]
    for u, d in units[1:]:
        if n >= d:
            div = d; unit = u
    return f"{n/div:7.2f} {unit}"


def print_row(size, path, is_dir=False, suffix=""):
    p = f"{CYAN}{path}{RESET}" if is_dir else path
    print(f"{GREEN}{fmt_size(size, CTX.fmt)}{RESET} {p}{suffix}")


def default_inputs():
    try:
        names = os.listdir(".")
    except OSError:
        return []
    # dua avoids symlink roots for implicit input.
    out = []
    for n in names:
        try:
            if stat.S_ISLNK(os.lstat(n).st_mode):
                continue
        except OSError:
            pass
        out.append(n)
    return out


def aggregate(args, ctx):
    stats = False; no_sort = False; no_total = False
    inputs = []
    i = 0
    while i < len(args):
        a = args[i]
        if a in ("-h", "--help"):
            print(AGG_HELP); return 0
        if a == "--stats": stats = True
        elif a == "--no-sort": no_sort = True
        elif a == "--no-total": no_total = True
        elif a.startswith("-") and a != "-":
            die(f"error: unexpected argument '{a}' found\n\n  tip: to pass '{a}' as a value, use '-- {a}'\n\nUsage: executable aggregate [OPTIONS] [INPUT]...\n\nFor more information, try '--help'.")
        else:
            inputs.append(a)
        i += 1
    implicit = not inputs
    if implicit:
        inputs = default_inputs()
    rows = []
    total = 0
    if len(inputs) == 1 and os.path.isdir(inputs[0]) and not os.path.islink(inputs[0]):
        root = inputs[0]
        try:
            children = os.listdir(root)
        except OSError:
            children = []
        root_st = os.lstat(root)
        total = 0
        for name in children:
            full = os.path.join(root, name)
            sz, is_dir = scan(full, ctx, False, root_st.st_dev)
            total += sz
            rows.append((sz, name, is_dir, ""))
    else:
        for p in inputs:
            if not os.path.exists(p) and not os.path.islink(p):
                ctx.errors += 1
                rows.append((0, p, True, f"  <{ctx.errors} IO Error>"))
                continue
            sz, is_dir = scan(p, ctx, True, None)
            total += sz
            rows.append((sz, p, is_dir, ""))
    if not no_sort:
        rows.sort(key=lambda r: (r[0], r[1]))
    for r in rows:
        print_row(*r)
    if len(rows) != 1 and not no_total:
        suffix = f"  <{ctx.errors} IO Error>" if ctx.errors else ""
        print_row(total, "total", False, suffix)
    if stats:
        small = ctx.smallest if ctx.smallest is not None else 0
        print(f"Statistics {{ entries_traversed: {ctx.entries}, smallest_file_in_bytes: {small}, largest_file_in_bytes: {ctx.largest} }}", file=sys.stderr)
    return 1 if ctx.errors else 0


def completions(args):
    if not args or args[0] in ("-h", "--help"):
        print(COMP_HELP); return 0
    sh = args[0]
    if sh not in SHELLS:
        die(f"error: invalid value '{sh}' for '<SHELL>'\n  [possible values: bash, elvish, fish, powershell, zsh]\n\nFor more information, try '--help'.")
    if sh == "bash":
        print("_dua() {\n    COMPREPLY=()\n}\ncomplete -F _dua -o bashdefault -o default dua")
    elif sh == "fish":
        print("complete -c dua -s h -l help -d 'Print help'\ncomplete -c dua -f -a 'interactive aggregate completions help'")
    elif sh == "zsh":
        print("#compdef dua\n_arguments '*:path:_files'")
    elif sh == "powershell":
        print("Register-ArgumentCompleter -Native -CommandName dua -ScriptBlock { param($wordToComplete) } ")
    else:
        print("edit:completion:arg-completer[dua] = {|@words| put interactive aggregate completions help }")
    return 0


def parse_global(argv, ctx):
    out = []
    i = 0
    while i < len(argv):
        a = argv[i]
        if a in ("aggregate", "a", "interactive", "i", "completions", "help"):
            out.extend(argv[i:]); return out
        if a in ("-h", "--help"):
            print(HELP); sys.exit(0)
        if a in ("-V", "--version"):
            print(VERSION); sys.exit(0)
        if a in ("-A", "--apparent-size"):
            ctx.apparent = True
        elif a in ("-l", "--count-hard-links"):
            ctx.count_hard = True
        elif a in ("-x", "--stay-on-filesystem"):
            ctx.stay = True
        elif a in ("-f", "--format"):
            i += 1
            if i >= len(argv): die("error: a value is required for '--format <FORMAT>'")
            ctx.fmt = argv[i]
            if ctx.fmt not in FORMATS:
                die(f"error: invalid value '{ctx.fmt}' for '--format <FORMAT>'\n  [possible values: metric, binary, bytes, gb, gib, mb, mib]\n\nFor more information, try '--help'.")
        elif a.startswith("--format="):
            ctx.fmt = a.split("=",1)[1]
        elif a in ("-t", "--threads", "-i", "--ignore-dirs", "--log-file"):
            i += 1
            if a in ("-i", "--ignore-dirs") and i < len(argv):
                ctx.ignore.add(os.path.abspath(argv[i]))
        elif a.startswith("-") and a != "-":
            die(f"error: unexpected argument '{a}' found\n\n  tip: to pass '{a}' as a value, use '-- {a}'\n\nUsage: dua [FLAGS] [OPTIONS] [SUBCOMMAND] [INPUT]...\n\nFor more information, try '--help'.")
        else:
            out.append(a)
        i += 1
    return out


def main():
    global CTX
    CTX = Ctx()
    args = parse_global(sys.argv[1:], CTX)
    if args and args[0] == "help":
        sub = args[1] if len(args) > 1 else ""
        print({"aggregate":AGG_HELP,"a":AGG_HELP,"interactive":INT_HELP,"i":INT_HELP,"completions":COMP_HELP}.get(sub, HELP)); return 0
    if args and args[0] in ("interactive", "i"):
        if any(a in ("-h", "--help") for a in args[1:]): print(INT_HELP); return 0
        print("error: interactive terminal user interface is not available in this reimplementation", file=sys.stderr); return 1
    if args and args[0] == "completions":
        return completions(args[1:])
    if args and args[0] in ("aggregate", "a"):
        return aggregate(args[1:], CTX)
    return aggregate(args, CTX)

if __name__ == "__main__":
    sys.exit(main())
