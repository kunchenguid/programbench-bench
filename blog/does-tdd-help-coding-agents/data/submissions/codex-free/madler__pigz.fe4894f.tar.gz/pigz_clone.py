#!/usr/bin/env python3
import os, sys, zlib, struct, time, stat, zipfile, io, shlex, binascii

VERSION = "pigz 2.8"
LICENSE = "pigz 2.8\nCopyright (C) 2007-2023 Mark Adler\nSubject to the terms of the zlib license.\nNo warranty is provided or implied.\n"
HELP = """Usage: pigz [options] [files ...]
  will compress files in place, adding the suffix '.gz'. If no files are
  specified, stdin will be compressed to stdout. pigz does what gzip does,
  but spreads the work over multiple processors and cores when compressing.

Options:
  -0 to -9, -11        Compression level (level 11, zopfli, is much slower)
  --fast, --best       Compression levels 1 and 9 respectively
  -A, --alias xxx      Use xxx as the name for any --zip entry from stdin
  -b, --blocksize mmm  Set compression block size to mmmK (default 128K)
  -c, --stdout         Write all processed output to stdout (won't delete)
  -C, --comment ccc    Put comment ccc in the gzip or zip header
  -d, --decompress     Decompress the compressed input
  -f, --force          Force overwrite, compress .gz, links, and to terminal
  -F  --first          Do iterations first, before block split for -11
  -h, --help           Display a help screen and quit
  -H, --huffman        Use only Huffman coding for compression
  -i, --independent    Compress blocks independently for damage recovery
  -I, --iterations n   Number of iterations for -11 optimization
  -J, --maxsplits n    Maximum number of split blocks for -11
  -k, --keep           Do not delete original file after processing
  -K, --zip            Compress to PKWare zip (.zip) single entry format
  -l, --list           List the contents of the compressed input
  -L, --license        Display the pigz license and quit
  -m, --no-time        Do not store or restore mod time
  -M, --time           Store or restore mod time
  -n, --no-name        Do not store or restore file name or mod time
  -N, --name           Store or restore file name and mod time
  -O  --oneblock       Do not split into smaller blocks for -11
  -p, --processes n    Allow up to n compression threads (default is the
                       number of online processors, or 8 if unknown)
  -q, --quiet          Print no messages, even on error
  -r, --recursive      Process the contents of all subdirectories
  -R, --rsyncable      Input-determined block locations for rsync
  -S, --suffix .sss    Use suffix .sss instead of .gz (for compression)
  -t, --test           Test the integrity of the compressed input
  -U, --rle            Use run-length encoding for compression
  -v, --verbose        Provide more verbose output
  -V  --version        Show the version of pigz
  -Y  --synchronous    Force output file write to permanent storage
  -z, --zlib           Compress to zlib (.zz) instead of gzip format
  --                   All arguments after "--" are treated as files
"""

class Opt:
    def __init__(self):
        self.decompress = os.path.basename(sys.argv[0]).startswith('un')
        self.stdout = False; self.keep = False; self.force = False; self.quiet = False
        self.recursive = False; self.test = False; self.list = False; self.verbose = False
        self.zlibfmt = False; self.zipfmt = False; self.level = 6; self.suffix = '.gz'
        self.name = True; self.mtime = True; self.alias = '-'; self.comment = None
        self.files = []

def err(o, msg):
    if not o.quiet:
        print(f"executable: {msg}", file=sys.stderr)

def need_arg(args, i, opt):
    if i + 1 >= len(args):
        raise SystemExit(f"executable: abort: option {opt} requires an argument")
    return args[i+1]

def parse_tokens(tokens):
    o = Opt(); args = []
    # Parse option-bearing env vars plus argv supplied by caller.
    i = 0; after = False
    while i < len(tokens):
        a = tokens[i]
        if after:
            o.files.append(a); i += 1; continue
        if a == '--': after = True; i += 1; continue
        if not a.startswith('-') or a == '-': o.files.append(a); i += 1; continue
        if a.startswith('--'):
            name = a[2:]; val = None
            if '=' in name: name, val = name.split('=',1)
            def arg():
                nonlocal i, val
                if val is not None: return val
                val = need_arg(tokens, i, '--'+name); i += 1; return val
            if name in ('help',): print(HELP, end=''); raise SystemExit(0)
            elif name == 'version': print(VERSION); raise SystemExit(0)
            elif name == 'license': print(LICENSE, end=''); raise SystemExit(0)
            elif name in ('stdout','to-stdout'): o.stdout = True
            elif name in ('decompress','uncompress'): o.decompress = True
            elif name in ('force',): o.force = True
            elif name in ('keep',): o.keep = True
            elif name in ('quiet','silent'): o.quiet = True
            elif name == 'recursive': o.recursive = True
            elif name == 'test': o.test = True; o.decompress = True
            elif name == 'list': o.list = True; o.decompress = True
            elif name == 'verbose': o.verbose = True
            elif name == 'zlib': o.zlibfmt = True; o.suffix = '.zz'
            elif name == 'zip': o.zipfmt = True; o.suffix = '.zip'
            elif name == 'fast': o.level = 1
            elif name == 'best': o.level = 9
            elif name == 'no-name': o.name = False; o.mtime = False
            elif name == 'name': o.name = True; o.mtime = True
            elif name == 'no-time': o.mtime = False
            elif name == 'time': o.mtime = True
            elif name == 'suffix': o.suffix = arg()
            elif name in ('alias','comment','blocksize','processes','iterations','maxsplits'):
                v = arg()
                if name == 'alias': o.alias = v
                if name == 'comment': o.comment = v
            elif name in ('huffman','independent','rsyncable','rle','first','oneblock','synchronous'):
                pass
            else:
                raise SystemExit(f"executable: abort: invalid option: --{name}")
            i += 1; continue
        # short options, clustered; -11 special
        j = 1
        if a == '-11': o.level = 9; i += 1; continue
        while j < len(a):
            c = a[j]
            if c.isdigit(): o.level = int(c); j += 1; continue
            if c == 'h': print(HELP, end=''); raise SystemExit(0)
            if c == 'V': print(VERSION); raise SystemExit(0)
            if c == 'L': print(LICENSE, end=''); raise SystemExit(0)
            if c == 'c': o.stdout = True
            elif c == 'd': o.decompress = True
            elif c == 'f': o.force = True
            elif c == 'k': o.keep = True
            elif c == 'q': o.quiet = True
            elif c == 'r': o.recursive = True
            elif c == 't': o.test = True; o.decompress = True
            elif c == 'l': o.list = True; o.decompress = True
            elif c == 'v': o.verbose = True
            elif c == 'z': o.zlibfmt = True; o.suffix = '.zz'
            elif c == 'K': o.zipfmt = True; o.suffix = '.zip'
            elif c == 'n': o.name = False; o.mtime = False
            elif c == 'N': o.name = True; o.mtime = True
            elif c == 'm': o.mtime = False
            elif c == 'M': o.mtime = True
            elif c in 'HFiORUY': pass
            elif c in 'AbCISpJ':
                if j + 1 < len(a): v = a[j+1:]; j = len(a)
                else: v = need_arg(tokens, i, '-'+c); i += 1
                if c == 'A': o.alias = v
                elif c == 'C': o.comment = v
                elif c == 'S': o.suffix = v
            else:
                raise SystemExit(f"executable: abort: invalid option: -{c}")
            j += 1
        i += 1
    return o

def parse_all():
    toks = []
    for env in ('GZIP','PIGZ'):
        if os.environ.get(env):
            try: toks += shlex.split(os.environ[env])
            except ValueError: pass
    toks += sys.argv[1:]
    return parse_tokens(toks)

def raw_deflate(data, level):
    co = zlib.compressobj(level, zlib.DEFLATED, -15)
    return co.compress(data) + co.flush()

def gzip_compress(data, o, src=None):
    mtime = 0; fname = None
    if src and src != '-':
        st = os.stat(src)
        if o.mtime: mtime = int(st.st_mtime)
        if o.name: fname = os.path.basename(src).encode('latin-1','replace')
    flags = (8 if fname else 0) | (16 if o.comment is not None else 0)
    xfl = 4 if o.level == 1 else (2 if o.level >= 9 else 0)
    out = bytearray(b'\x1f\x8b\x08' + bytes([flags]) + struct.pack('<LBB', mtime, xfl, 3))
    if fname: out += fname + b'\0'
    if o.comment is not None: out += o.comment.encode('latin-1','replace') + b'\0'
    comp = raw_deflate(data, o.level)
    out += comp + struct.pack('<LL', zlib.crc32(data) & 0xffffffff, len(data) & 0xffffffff)
    return bytes(out)

def zlib_compress(data, o):
    return zlib.compress(data, o.level)

def zip_compress(data, o, src=None):
    name = o.alias if not src or src == '-' else os.path.basename(src)
    bio = io.BytesIO()
    zi = zipfile.ZipInfo(name)
    zi.compress_type = zipfile.ZIP_DEFLATED
    if src and src != '-' and o.mtime:
        zi.date_time = time.localtime(os.stat(src).st_mtime)[:6]
    else:
        zi.date_time = (1980,1,1,0,0,0)
    if o.comment: zi.comment = o.comment.encode('latin-1','replace')
    with zipfile.ZipFile(bio, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=o.level) as zf:
        zf.writestr(zi, data)
    return bio.getvalue()

def gzip_decompress(data):
    out = bytearray(); rest = data
    while rest:
        d = zlib.decompressobj(16 + zlib.MAX_WBITS)
        chunk = d.decompress(rest) + d.flush()
        out += chunk
        rest = d.unused_data
        if not rest: break
    return bytes(out)

def decompress_data(data, o, path=None):
    if o.zipfmt or (path and path.endswith('.zip')) or data[:4] == b'PK\x03\x04':
        with zipfile.ZipFile(io.BytesIO(data)) as zf:
            names = zf.namelist()
            return zf.read(names[0]) if names else b''
    if o.zlibfmt or (path and path.endswith('.zz')):
        return zlib.decompress(data)
    return gzip_decompress(data)

def gzip_meta(path, data):
    if len(data) < 18 or data[:2] != b'\x1f\x8b':
        raise ValueError('not gzip')
    flg = data[3]; mtime = struct.unpack('<L', data[4:8])[0]; pos = 10; name = None
    if flg & 4:
        xlen = struct.unpack('<H', data[pos:pos+2])[0]; pos += 2 + xlen
    if flg & 8:
        end = data.index(0, pos); name = data[pos:end].decode('latin-1','replace'); pos = end + 1
    if flg & 16:
        end = data.index(0, pos); pos = end + 1
    if flg & 2: pos += 2
    crc, size = struct.unpack('<LL', data[-8:])
    return pos, len(data)-pos-8, size, crc, mtime, name or strip_suffix(os.path.basename(path), '.gz')

def strip_suffix(p, suff):
    return p[:-len(suff)] if suff and p.endswith(suff) else p[:-3] if p.endswith('.gz') else p + '.out'

def output_path_for_compress(path, o):
    return path + o.suffix

def output_path_for_decompress(path, o, data=None):
    base = path
    for s in (o.suffix, '.gz', '.zz', '.zip', '.z', '-gz'):
        if s and base.endswith(s): return base[:-len(s)]
    return base + '.out'

def write_out(path, data, o, remove_src=False):
    if o.stdout:
        sys.stdout.buffer.write(data); return True
    if os.path.exists(path) and not o.force:
        err(o, f"skipping: {path} exists")
        return False
    with open(path, 'wb') as f: f.write(data)
    if remove_src and not o.keep:
        try: os.unlink(remove_src)
        except OSError: pass
    return True

def expand_files(files, o):
    if not files: return []
    res = []
    for p in files:
        if p == '-': res.append(p); continue
        if os.path.isdir(p):
            if not o.recursive:
                err(o, f"skipping: {p} is a directory")
            else:
                for root, dirs, names in os.walk(p):
                    for n in names: res.append(os.path.join(root,n))
        else: res.append(p)
    return res

def do_list(paths, o):
    if o.verbose:
        print("method    check    timestamp    compressed   original reduced  name")
    else:
        print("compressed   original reduced  name")
    rc = 0; totals_c = totals_o = 0
    for p in paths or ['-']:
        try:
            data = sys.stdin.buffer.read() if p == '-' else open(p,'rb').read()
            if data[:2] == b'\x1f\x8b':
                h, c, orig, crc, mt, name = gzip_meta(p, data)
                comp = c
                meth = 'gzip 8'
            elif data[:4] == b'PK\x03\x04':
                with zipfile.ZipFile(io.BytesIO(data)) as zf:
                    info = zf.infolist()[0]; comp = info.compress_size; orig = info.file_size; crc = info.CRC; name = info.filename; mt = 0; meth = 'zip 8 '
            else:
                out = zlib.decompress(data); comp = len(data); orig = len(out); crc = zlib.adler32(out)&0xffffffff; name = p; mt = 0; meth = 'zlib 8'
            red = 0.0 if orig == 0 else 100.0 * (orig - comp) / orig
            totals_c += comp; totals_o += orig
            if o.verbose:
                ts = time.strftime('%b %d %H:%M', time.localtime(mt)) if mt else '--- -- --:--'
                print(f"{meth:<8} {crc:08x}  {ts:>12} {comp:11d} {orig:10d} {red:6.1f}%  {name}")
            else:
                print(f"{comp:10d} {orig:10d} {red:6.1f}%  {name}")
        except Exception as e:
            rc = 1; err(o, f"skipping: {p}: {e}")
    return rc

def process_one(p, o):
    if p != '-' and not os.path.exists(p):
        err(o, f"skipping: {p} does not exist"); return 1
    if not o.decompress and p != '-' and p.endswith(o.suffix) and not o.force:
        err(o, f"skipping: {p} ends with {o.suffix}"); return 0
    try:
        data = sys.stdin.buffer.read() if p == '-' else open(p,'rb').read()
        if o.decompress:
            out = decompress_data(data, o, None if p == '-' else p)
            if o.test: return 0
            outp = None if p == '-' else output_path_for_decompress(p, o, data)
            return 0 if write_out(outp, out, o, None if p == '-' else p) else 1
        else:
            if o.zipfmt: out = zip_compress(data, o, None if p == '-' else p)
            elif o.zlibfmt: out = zlib_compress(data, o)
            else: out = gzip_compress(data, o, None if p == '-' else p)
            outp = None if p == '-' else output_path_for_compress(p, o)
            return 0 if write_out(outp, out, o, None if p == '-' else p) else 1
    except Exception as e:
        err(o, f"abort: {p}: {e}"); return 1

def main():
    try:
        o = parse_all()
    except SystemExit as e:
        if isinstance(e.code, str): print(e.code, file=sys.stderr); sys.exit(22)
        raise
    files = expand_files(o.files, o)
    if o.list:
        sys.exit(do_list(files, o))
    if not files:
        files = ['-']; o.stdout = True
    rc = 0
    for p in files:
        rc |= process_one(p, o)
    sys.exit(rc)

if __name__ == '__main__': main()
