#!/usr/bin/env python3
import sys, math, os

REL = "Rel. 9.9.0, September 15th, 2026"
USAGE = "usage: executable [-bdeEfiIlmorsStTvVwW [args]] [+opt[=arg] ...] [file ...]"

ELLPS = {
    "WGS84": (6378137.0, 298.257223563),
    "GRS80": (6378137.0, 298.257222101),
    "clrk66": (6378206.4, None, 6356583.8),
    "sphere": (6370997.0, 0.0),
    "airy": (6377563.396, 299.3249646),
    "bessel": (6377397.155, 299.1528128),
    "intl": (6378388.0, 297.0),
}

PROJ_DESCR = [
    ("aea", "Albers Equal Area"),
    ("aeqd", "Azimuthal Equidistant"),
    ("eqc", "Equidistant Cylindrical"),
    ("equi", "Equidistant Cylindrical"),
    ("laea", "Lambert Azimuthal Equal Area"),
    ("lcc", "Lambert Conformal Conic"),
    ("merc", "Mercator"),
    ("moll", "Mollweide"),
    ("ortho", "Orthographic"),
    ("stere", "Stereographic"),
    ("tmerc", "Transverse Mercator"),
    ("utm", "Universal Transverse Mercator (UTM)"),
]

def die(msg=None, code=1):
    print(REL, file=sys.stderr)
    print("<executable>: ", file=sys.stderr)
    if msg:
        print(msg, file=sys.stderr)
    print("program abnormally terminated", file=sys.stderr)
    sys.exit(code)

def usage(code=0):
    print(REL, file=sys.stderr if code else sys.stdout)
    print(USAGE, file=sys.stderr if code else sys.stdout)
    sys.exit(code)

def parse_dms(s):
    t = s.strip()
    if not t:
        return 0.0
    sign = -1 if t[0] == '-' else 1
    if t[0] in '+-':
        t = t[1:]
    hemi = t[-1:].upper()
    if hemi in "WS":
        sign = -1
        t = t[:-1]
    elif hemi in "EN":
        t = t[:-1]
    if 'd' in t or "'" in t or '"' in t:
        t = t.replace('d', ' ').replace("'", ' ').replace('"', ' ')
        parts = [p for p in t.split() if p]
        val = 0.0
        if parts:
            val += float(parts[0])
        if len(parts) > 1:
            val += float(parts[1]) / 60.0
        if len(parts) > 2:
            val += float(parts[2]) / 3600.0
        return sign * val
    return sign * float(t)

def dms(deg, ew=True, decimals=0):
    hemi = ("W" if deg < 0 else "E") if ew else ("S" if deg < 0 else "N")
    v = abs(deg)
    d = int(math.floor(v + 1e-12))
    rem = (v - d) * 60.0
    m = int(math.floor(rem + 1e-12))
    sec = (rem - m) * 60.0
    if decimals <= 0:
        if m == 0 and abs(sec) < 0.5:
            return f"{d}d{hemi}"
        sec_i = int(round(sec))
        if sec_i == 60:
            sec_i = 0; m += 1
        if m == 60:
            m = 0; d += 1
        if sec_i:
            return f"{d}d{m}'{sec_i}\"{hemi}"
        return f"{d}d{m}'{hemi}"
    fmt = f"{{:.{decimals}f}}"
    return f"{d}d{m}'{fmt.format(sec)}\"{hemi}"

def ellipsoid(params):
    if "R" in params:
        a = float(params["R"]); return a, 0.0, a
    if "a" in params:
        a = float(params["a"])
        if "b" in params:
            b = float(params["b"])
            e2 = 1 - (b*b)/(a*a)
        elif "rf" in params:
            rf = float(params["rf"]); f = 0 if rf == 0 else 1/rf; e2 = 2*f - f*f; b = a*(1-f)
        else:
            e2 = 0.0; b = a
        return a, e2, b
    name = params.get("ellps", "WGS84")
    ent = ELLPS.get(name, ELLPS["WGS84"])
    a = ent[0]
    if len(ent) == 3:
        b = ent[2]; e2 = 1 - b*b/(a*a)
    else:
        rf = ent[1]
        if rf == 0:
            e2 = 0.0; b = a
        else:
            f = 1/rf; e2 = 2*f - f*f; b = a*(1-f)
    return a, e2, b

def rad(params, key, default=0.0):
    return math.radians(float(params.get(key, default)))

def meridional_arc(phi, a, e2):
    e4 = e2*e2; e6 = e4*e2
    return a*((1 - e2/4 - 3*e4/64 - 5*e6/256)*phi
        - (3*e2/8 + 3*e4/32 + 45*e6/1024)*math.sin(2*phi)
        + (15*e4/256 + 45*e6/1024)*math.sin(4*phi)
        - (35*e6/3072)*math.sin(6*phi))

def inv_meridional_arc(M, a, e2):
    mu = M/(a*(1 - e2/4 - 3*e2*e2/64 - 5*e2**3/256))
    e1 = (1 - math.sqrt(1-e2))/(1 + math.sqrt(1-e2)) if e2 else 0
    return (mu + (3*e1/2 - 27*e1**3/32)*math.sin(2*mu)
        + (21*e1*e1/16 - 55*e1**4/32)*math.sin(4*mu)
        + (151*e1**3/96)*math.sin(6*mu)
        + (1097*e1**4/512)*math.sin(8*mu))

def transform(lon_deg, lat_deg, params, inv=False):
    proj = params.get("proj")
    a, e2, b = ellipsoid(params)
    e = math.sqrt(max(e2, 0.0))
    x0 = float(params.get("x_0", params.get("x0", 0.0)))
    y0 = float(params.get("y_0", params.get("y0", 0.0)))
    k0 = float(params.get("k_0", params.get("k", 1.0)))
    if proj == "utm":
        zone = int(params.get("zone", 31))
        params = dict(params)
        params["proj"] = "tmerc"; params["lon_0"] = str(zone*6 - 183)
        params["lat_0"] = "0"; params["x_0"] = "500000"; params["k_0"] = "0.9996"
        if "south" in params and "y_0" not in params:
            params["y_0"] = "10000000"
        return transform(lon_deg, lat_deg, params, inv)
    if proj in (None, "latlong", "longlat"):
        if not inv:
            die("can't initialize operations that produce angular output coordinates")
        return lon_deg, lat_deg
    if inv:
        x = lon_deg; y = lat_deg
    else:
        lam = math.radians(lon_deg); phi = math.radians(lat_deg)
    lam0 = rad(params, "lon_0", 0.0); phi0 = rad(params, "lat_0", 0.0)
    if proj == "merc":
        if inv:
            xx = (x-x0)/(a*k0) + lam0
            t = math.exp(-(y-y0)/(a*k0))
            phi = math.pi/2 - 2*math.atan(t)
            for _ in range(8):
                phi = math.pi/2 - 2*math.atan(t*((1-e*math.sin(phi))/(1+e*math.sin(phi)))**(e/2)) if e else phi
            return math.degrees(xx), math.degrees(phi)
        lat_ts = rad(params, "lat_ts", None) if "lat_ts" in params else None
        k = math.cos(lat_ts)/math.sqrt(1-e2*math.sin(lat_ts)**2) if lat_ts is not None and e2 else k0
        if e:
            yy = a*k*math.log(math.tan(math.pi/4+phi/2)*((1-e*math.sin(phi))/(1+e*math.sin(phi)))**(e/2))
        else:
            yy = a*k*math.log(math.tan(math.pi/4+phi/2))
        return x0 + a*k*(lam-lam0), y0 + yy
    if proj == "tmerc":
        ep2 = e2/(1-e2) if e2 != 1 else 0
        if inv:
            M = (y-y0)/k0 + meridional_arc(phi0, a, e2)
            fp = inv_meridional_arc(M, a, e2)
            C1 = ep2*math.cos(fp)**2; T1 = math.tan(fp)**2
            N1 = a/math.sqrt(1-e2*math.sin(fp)**2); R1 = a*(1-e2)/(1-e2*math.sin(fp)**2)**1.5
            D = (x-x0)/(N1*k0)
            phi = fp - (N1*math.tan(fp)/R1)*(D*D/2 - (5+3*T1+10*C1-4*C1*C1-9*ep2)*D**4/24 + (61+90*T1+298*C1+45*T1*T1-252*ep2-3*C1*C1)*D**6/720)
            lam = lam0 + (D - (1+2*T1+C1)*D**3/6 + (5-2*C1+28*T1-3*C1*C1+8*ep2+24*T1*T1)*D**5/120)/math.cos(fp)
            return math.degrees(lam), math.degrees(phi)
        N = a/math.sqrt(1-e2*math.sin(phi)**2); T = math.tan(phi)**2; C = ep2*math.cos(phi)**2; A = (lam-lam0)*math.cos(phi)
        M = meridional_arc(phi, a, e2) - meridional_arc(phi0, a, e2)
        x = x0 + k0*N*(A + (1-T+C)*A**3/6 + (5-18*T+T*T+72*C-58*ep2)*A**5/120
                       + (61-479*T+179*T*T-T*T*T)*A**7/5040)
        y = y0 + k0*(M + N*math.tan(phi)*(A*A/2 + (5-T+9*C+4*C*C)*A**4/24
                       + (61-58*T+T*T+600*C-330*ep2)*A**6/720
                       + (1385-3111*T+543*T*T-T*T*T)*A**8/40320))
        return x, y
    R = a
    if proj in ("eqc", "equi"):
        lat_ts = rad(params, "lat_ts", 0.0)
        if inv:
            lon = math.degrees((x-x0)/(a*k0*math.cos(lat_ts)) + lam0)
            if e2:
                M0 = meridional_arc(phi0, a, e2)
                lat = math.degrees(inv_meridional_arc((y-y0)/k0 + M0, a, e2))
            else:
                lat = math.degrees((y-y0)/(a*k0) + phi0)
            return lon, lat
        yy = meridional_arc(phi, a, e2) - meridional_arc(phi0, a, e2) if e2 else a*(phi-phi0)
        return x0 + a*k0*(lam-lam0)*math.cos(lat_ts), y0 + k0*yy
    if proj == "lcc":
        p1 = rad(params, "lat_1", params.get("lat_0", 0)); p2 = rad(params, "lat_2", math.degrees(p1))
        def mfun(p): return math.cos(p)/math.sqrt(1-e2*math.sin(p)**2) if e2 else math.cos(p)
        def tfun(p):
            if e:
                return math.tan(math.pi/4-p/2)/(((1-e*math.sin(p))/(1+e*math.sin(p)))**(e/2))
            return math.tan(math.pi/4-p/2)
        t1, t2, t0 = tfun(p1), tfun(p2), tfun(phi0)
        m1, m2 = mfun(p1), mfun(p2)
        n = math.sin(p1) if abs(p1-p2) < 1e-12 else math.log(m1/m2)/math.log(t1/t2)
        F = m1/(n*(t1**n))
        rho0 = a*F*(t0**n)
        if inv:
            rho = math.hypot(x-x0, rho0-(y-y0)); theta = math.atan2(x-x0, rho0-(y-y0))
            if n < 0: rho = -rho
            t = (rho/(a*F))**(1/n)
            ph = math.pi/2 - 2*math.atan(t)
            for _ in range(8):
                ph = math.pi/2 - 2*math.atan(t*((1-e*math.sin(ph))/(1+e*math.sin(ph)))**(e/2)) if e else ph
            return math.degrees(lam0 + theta/n), math.degrees(ph)
        rho = a*F*(tfun(phi)**n); th = n*(lam-lam0)
        return x0 + rho*math.sin(th), y0 + rho0 - rho*math.cos(th)
    if proj == "aea":
        p1 = rad(params, "lat_1", 0); p2 = rad(params, "lat_2", 0)
        if e:
            def qfun(p):
                s = math.sin(p)
                return (1-e2)*(s/(1-e2*s*s) - (1/(2*e))*math.log((1-e*s)/(1+e*s)))
            def mfun(p): return math.cos(p)/math.sqrt(1-e2*math.sin(p)**2)
            q1, q2, q0 = qfun(p1), qfun(p2), qfun(phi0)
            m1, m2 = mfun(p1), mfun(p2)
            n = (m1*m1-m2*m2)/(q2-q1) if abs(p1-p2) > 1e-12 else math.sin(p1)
            C = m1*m1 + n*q1
            rho0 = a*math.sqrt(max(0, C-n*q0))/n
            if inv:
                rho = math.hypot(x-x0, rho0-(y-y0)); th = math.atan2(x-x0, rho0-(y-y0))
                qv = (C-(rho*n/a)**2)/n
                lo, hi = -math.pi/2, math.pi/2
                for _ in range(60):
                    mid = (lo+hi)/2
                    if qfun(mid) < qv: lo = mid
                    else: hi = mid
                return math.degrees(lam0 + th/n), math.degrees((lo+hi)/2)
            rho = a*math.sqrt(max(0, C-n*qfun(phi)))/n; th = n*(lam-lam0)
            return x0 + rho*math.sin(th), y0 + rho0 - rho*math.cos(th)
        n = 0.5*(math.sin(p1)+math.sin(p2)); C = math.cos(p1)**2 + 2*n*math.sin(p1)
        rho0 = R*math.sqrt(max(0, C-2*n*math.sin(phi0)))/n
        if inv:
            rho = math.hypot(x-x0, rho0-(y-y0)); th = math.atan2(x-x0, rho0-(y-y0))
            return math.degrees(lam0 + th/n), math.degrees(math.asin((C-(rho*n/R)**2)/(2*n)))
        rho = R*math.sqrt(max(0, C-2*n*math.sin(phi)))/n; th = n*(lam-lam0)
        return x0 + rho*math.sin(th), y0 + rho0 - rho*math.cos(th)
    if proj == "sinu":
        if inv:
            if e2:
                phi = inv_meridional_arc(y-y0 + meridional_arc(phi0, a, e2), a, e2)
                N = a/math.sqrt(1-e2*math.sin(phi)**2)
                lam = lam0 + (x-x0)/(N*math.cos(phi))
            else:
                phi = (y-y0)/R + phi0
                lam = lam0 + (x-x0)/(R*math.cos(phi))
            return math.degrees(lam), math.degrees(phi)
        if e2:
            N = a/math.sqrt(1-e2*math.sin(phi)**2)
            yy = meridional_arc(phi, a, e2)-meridional_arc(phi0, a, e2)
            return x0 + N*(lam-lam0)*math.cos(phi), y0 + yy
        return x0 + R*(lam-lam0)*math.cos(phi), y0 + R*(phi-phi0)
    if proj == "moll":
        # PROJ uses a spherical form for Mollweide with the current semimajor radius.
        if inv:
            th = math.asin(max(-1,min(1,(y-y0)/(math.sqrt(2)*R))))
            phi = math.asin((2*th + math.sin(2*th))/math.pi)
            lam = lam0 + (x-x0)*math.pi/(2*math.sqrt(2)*R*math.cos(th))
            return math.degrees(lam), math.degrees(phi)
        th = phi
        for _ in range(12):
            den = 2 + 2*math.cos(2*th)
            if abs(den) < 1e-14: break
            th -= (2*th + math.sin(2*th) - math.pi*math.sin(phi))/den
        return x0 + 2*math.sqrt(2)*R*(lam-lam0)*math.cos(th)/math.pi, y0 + math.sqrt(2)*R*math.sin(th)
    if proj == "ortho":
        if inv:
            xx=(x-x0)/R; yy=(y-y0)/R; rho=math.hypot(xx,yy); c=math.asin(min(1,rho))
            phi=math.asin(math.cos(c)*math.sin(phi0)+yy*math.sin(c)*math.cos(phi0)/(rho or 1))
            lam=lam0+math.atan2(xx*math.sin(c), rho*math.cos(phi0)*math.cos(c)-yy*math.sin(phi0)*math.sin(c))
            return math.degrees(lam), math.degrees(phi)
        return x0 + R*math.cos(phi)*math.sin(lam-lam0), y0 + R*(math.cos(phi0)*math.sin(phi)-math.sin(phi0)*math.cos(phi)*math.cos(lam-lam0))
    if proj == "aeqd":
        c = math.acos(max(-1,min(1, math.sin(phi0)*math.sin(phi)+math.cos(phi0)*math.cos(phi)*math.cos(lam-lam0))))
        k = c/math.sin(c) if abs(c)>1e-12 else 1
        return x0+R*k*math.cos(phi)*math.sin(lam-lam0), y0+R*k*(math.cos(phi0)*math.sin(phi)-math.sin(phi0)*math.cos(phi)*math.cos(lam-lam0))
    if proj == "laea":
        den = 1 + math.sin(phi0)*math.sin(phi)+math.cos(phi0)*math.cos(phi)*math.cos(lam-lam0)
        k = math.sqrt(2/max(1e-15, den))
        return x0+R*k*math.cos(phi)*math.sin(lam-lam0), y0+R*k*(math.cos(phi0)*math.sin(phi)-math.sin(phi0)*math.cos(phi)*math.cos(lam-lam0))
    if proj == "stere":
        den = 1 + math.sin(phi0)*math.sin(phi)+math.cos(phi0)*math.cos(phi)*math.cos(lam-lam0)
        k = 2*R/max(1e-15, den)
        return x0+k*math.cos(phi)*math.sin(lam-lam0), y0+k*(math.cos(phi0)*math.sin(phi)-math.sin(phi0)*math.cos(phi)*math.cos(lam-lam0))
    die("projection initialization failure\ncause: Unknown error (code 2)")

def list_things(kind):
    if kind == "e":
        for name, ent in ELLPS.items():
            if len(ent) == 3:
                print(f"{name:>9} a={ent[0]:<13g} b={ent[2]:<13g}")
            else:
                print(f"{name:>9} a={ent[0]:<13g} rf={ent[1]:<13g}")
    else:
        for p, d in PROJ_DESCR:
            print(f"{p} : {d}")

def main(argv):
    opts = {"fmt": "%.2f", "inverse": False, "echo": False, "rin": False, "sout": False, "w": 0, "raw": False}
    params = {}
    files = []
    i = 1
    while i < len(argv):
        a = argv[i]
        if a.startswith("+"):
            item = a[1:]
            if "=" in item:
                k,v=item.split("=",1); params[k]=v
            else:
                params[item]="true"
        elif a.startswith("-") and a != "-":
            if a.startswith("--"):
                die("invalid option: --")
            j = 1
            while j < len(a):
                c = a[j]
                if c == "I": opts["inverse"] = True
                elif c == "E": opts["echo"] = True
                elif c == "r": opts["rin"] = True
                elif c == "s": opts["sout"] = True
                elif c == "d": opts["raw"] = True; opts["fmt"] = "%.10f"
                elif c in ("f","e","m","w","W"):
                    val = a[j+1:] if j+1 < len(a) else (argv[i+1] if i+1 < len(argv) else "")
                    if j+1 >= len(a): i += 1
                    if c == "f" and val: opts["fmt"] = val
                    if c in ("w","W"):
                        try: opts["w"] = int(val)
                        except: opts["w"] = 0
                    break
                elif c == "l":
                    kind = a[j+1:] or (argv[i+1] if i+1 < len(argv) else "P")
                    list_things(kind[-1]); return 0
                elif c == "V":
                    opts["verbose"] = True
                elif c in "bimorsStTv":
                    pass
                else:
                    die(f"invalid option: -{c}")
                j += 1
        else:
            files.append(a)
        i += 1
    if "proj" not in params:
        usage(0)
    if opts["inverse"] and params.get("proj") in ("latlong","longlat"):
        pass
    elif params.get("proj") in ("latlong","longlat"):
        die("can't initialize operations that produce angular output coordinates")
    if opts.get("verbose"):
        pname = params.get("proj", "unknown")
        descr = dict(PROJ_DESCR).get(pname, pname)
        print(f"#{descr}")
        print("#\t")
        shown = " ".join("+"+k+(("=" + v) if v != "true" else "") for k, v in params.items())
        print(f"# {shown} +break_cs2cs_recursion")
        a, e2, b = ellipsoid(params)
        if e2:
            rf = 1/(1-b/a)
            print("#Final Earth figure: ellipsoid")
            print(f"#  Major axis (a): {a:.3f}")
            print(f"#  1/flattening: {rf:.6f}")
            print(f"#  squared eccentricity: {e2:.12f}")
        else:
            print("#Final Earth figure: sphere")
            print(f"#  Radius: {a:.3f}")
    streams = [open(f) for f in files] if files else [sys.stdin]
    for fp in streams:
        for line in fp:
            rawline = line.rstrip("\n")
            if rawline.startswith("#"):
                print(rawline); continue
            parts = rawline.split()
            rest = ""
            echo_text = rawline
            try:
                x = parse_dms(parts[0]); y = parse_dms(parts[1])
                echo_text = parts[0] + " " + parts[1]
                if len(parts) > 2:
                    rest = " " + " ".join(parts[2:])
            except Exception:
                x = 0.0; y = 0.0; rest = rawline
            if opts["rin"]:
                x, y = y, x
            try:
                ox, oy = transform(x, y, params, opts["inverse"])
            except SystemExit:
                raise
            except Exception:
                ox, oy = float("inf"), float("inf")
            if opts["sout"]:
                ox, oy = oy, ox
            if opts["inverse"] and not opts["raw"]:
                out1, out2 = dms(ox, True, opts["w"]), dms(oy, False, opts["w"])
            else:
                fmt = opts["fmt"]
                out1 = fmt % ox if math.isfinite(ox) else "*"
                out2 = fmt % oy if math.isfinite(oy) else "*"
            prefix = echo_text + "\t" if opts["echo"] else ""
            print(f"{prefix}{out1}\t{out2}{rest}")
    return 0

if __name__ == "__main__":
    sys.exit(main(sys.argv))
