#!/usr/bin/env python3
import json
import os
import re
import subprocess
import sys
import uuid
from datetime import datetime, timezone
from pathlib import Path


ZERO = "0001-01-01T00:00:00Z"
COMMANDS = {
    "next", "add", "template", "log", "start", "note", "stop", "done",
    "context", "modify", "edit", "undo", "sync", "open", "git", "remove",
    "show-projects", "show-tags", "show-active", "show-paused", "show-open",
    "show-resolved", "show-templates", "show-unorganised", "bash-completion",
    "fish-completion", "zsh-completion", "powershell-completion", "help",
    "version",
}


HELP = """Usage: dstask [id...] <cmd> [task summary/filter]

Where [task summary] is text with tags/project/priority specified. Tags are
specified with + (or - for filtering) eg: +work. The project is specified with
a project:g prefix eg: project:dstask -- no quotes. Priorities run from P3
(low), P2 (default) to P1 (high) and P0 (critical). Text can also be specified
for a substring search of description and notes.

Cmd and IDs can be swapped, multiple IDs can be specified for batch
operations.

run "dstask help <cmd>" for command specific help.

Available commands:

next              : Show most important tasks (priority, creation date -- truncated and default)
add               : Add a task
template          : Add a task template
log               : Log a task (already resolved)
start             : Change task status to active
note              : Append to or edit note for a task
stop              : Change task status to pending
done              : Resolve a task
context           : Set global context for task list and new tasks (use "none" to set no context)
modify            : Change task attributes specified on command line
edit              : Edit task with text editor
undo              : Undo last n commits
sync              : Pull then push to git repository, automatic merge commit.
open              : Open all URLs found in summary/annotations
git               : Pass a command to git in the repository. Used for push/pull.
remove            : Remove a task (use to remove tasks added by mistake)
show-projects     : List projects with completion status
show-tags         : List tags in use
show-active       : Show tasks that have been started
show-paused       : Show tasks that have been started then stopped
show-open         : Show all non-resolved tasks (without truncation)
show-resolved     : Show resolved tasks
show-templates    : Show task templates
show-unorganised  : Show untagged tasks with no projects (global context)
bash-completion   : Print bash completion script to stdout
fish-completion   : Print fish completion script to stdout
zsh-completion    : Print zsh completion script to stdout
help              : Get help on any command or show this message
version           : Show dstask version information
"""


HELP_TOPICS = {
    "add": "Usage: dstask add [template:<id>] [task summary] [--]\nExample: dstask add Fix main web page 500 error +bug P1 project:website\n\nAdd a task, returning the git commit output which contains the task ID, used\nlater to reference the task.\n\nTags, project and priority can be added anywhere within the task summary.\n\nAdd -- to ignore the current context. / can be used when adding tasks to note\nany words after.\n",
    "next": "Usage: dstask next [filter] [--]\nUsage: dstask [filter] [--]\nExample: dstask +work +bug --\n\nDisplay list of non-resolved tasks in the current context, most recent last,\noptional filter. It is the default command, so \"next\" is unnecessary.\n",
    "modify": "Usage: dstask <id...> modify <filter>\nUsage: dstask modify <filter>\nExample: dstask 34 modify -work +home project:workbench -project:website\n\nModify the attributes of the given tasks, specified by ID. If no ID is given,\nthe operation will be performed to all tasks in the current context subject to\nconfirmation.\n\nModifiable attributes: tags, project and priority.\n",
    "context": "Usage: dstask context <filter>\nExample: dstask context +work -bug\nExample: dstask context none\n\nSet a global filter consisting of a project, tags or antitags. Subsequent new\ntasks and most commands will then have this filter applied automatically.\n\nTo reset to no context, run: dstask context none\n",
    "note": "Usage: dstask note <id>\nUsage: dstask note <id> <text>\nExample task 13 note problem is faulty hardware\n\nEdit or append text to the markdown notes attached to a particular task.\n",
}


def now():
    return datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")


def repo():
    return Path(os.environ.get("DSTASK_GIT_REPO") or (Path.home() / ".dstask"))


def db_path():
    return repo() / "tasks.json"


def ensure():
    r = repo()
    r.mkdir(parents=True, exist_ok=True)
    if not (r / ".git").exists():
        try:
            subprocess.run(["git", "-C", str(r), "init"], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        except Exception:
            pass
    if not db_path().exists():
        save({"tasks": [], "context": "", "next_id": 1})


def load():
    ensure()
    try:
        return json.loads(db_path().read_text())
    except Exception:
        return {"tasks": [], "context": "", "next_id": 1}


def save(data):
    repo().mkdir(parents=True, exist_ok=True)
    db_path().write_text(json.dumps(data, indent=2, sort_keys=True))


def emit_json(obj):
    print(json.dumps(obj, indent=2))


def parse_attrs(words):
    tags_add, tags_rem, summary = [], [], []
    project = None
    priority = None
    due = None
    template_id = None
    notes = []
    in_note = False
    for w in words:
        if in_note:
            notes.append(w)
            continue
        if w == "/":
            in_note = True
        elif re.fullmatch(r"P[0-3]", w):
            priority = w
        elif w.startswith("+") and len(w) > 1:
            tags_add.append(w[1:])
        elif w.startswith("-") and len(w) > 1:
            tags_rem.append(w[1:])
        elif w.startswith("project:"):
            project = w.split(":", 1)[1]
        elif w.startswith("-project:"):
            project = ""
        elif w.startswith("due:"):
            due = w.split(":", 1)[1] + "T00:00:00Z"
        elif w.startswith("template:"):
            try:
                template_id = int(w.split(":", 1)[1])
            except ValueError:
                pass
        else:
            summary.append(w)
    return {
        "summary": " ".join(summary).strip(),
        "tags_add": tags_add,
        "tags_rem": tags_rem,
        "project": project,
        "priority": priority,
        "due": due,
        "template_id": template_id,
        "notes": " ".join(notes).strip(),
    }


def context_words(data):
    env = os.environ.get("DSTASK_CONTEXT")
    c = env if env is not None else data.get("context", "")
    return [] if c in ("", "none", "--") else c.split()


def apply_context_to_new(task, data, ignore=False):
    if ignore:
        return
    attrs = parse_attrs(context_words(data))
    for t in attrs["tags_add"]:
        if t not in task["tags"]:
            task["tags"].append(t)
    for t in attrs["tags_rem"]:
        if t in task["tags"]:
            task["tags"].remove(t)
    if attrs["project"] is not None:
        task["project"] = attrs["project"]
    if attrs["priority"]:
        task["priority"] = attrs["priority"]


def task_sort_key(t):
    return ({"P0": 0, "P1": 1, "P2": 2, "P3": 3}.get(t["priority"], 2), t["created"])


def matches(t, words):
    attrs = parse_attrs(words)
    for tag in attrs["tags_add"]:
        if tag not in t.get("tags", []):
            return False
    for tag in attrs["tags_rem"]:
        if tag in t.get("tags", []):
            return False
    if attrs["project"] not in (None, "") and t.get("project") != attrs["project"]:
        return False
    if attrs["project"] == "" and t.get("project"):
        return False
    if attrs["priority"] and t.get("priority") != attrs["priority"]:
        return False
    text = " ".join([attrs["summary"]]).strip().lower()
    if text and text not in (t.get("summary", "") + "\n" + t.get("notes", "")).lower():
        return False
    return True


def visible_task(t):
    return {
        "uuid": t["uuid"],
        "status": t["status"],
        "id": 0 if t["status"] == "resolved" else t["id"],
        "summary": t["summary"],
        "notes": t.get("notes", ""),
        "tags": t.get("tags", []),
        "project": t.get("project", ""),
        "priority": t.get("priority", "P2"),
        "created": t.get("created", ZERO),
        "resolved": t.get("resolved", ZERO),
        "due": t.get("due", ZERO),
    }


def find_ids(data, ids):
    out = []
    for i in ids:
        for t in data["tasks"]:
            if t["status"] != "resolved" and t["id"] == i:
                out.append(t)
                break
        else:
            print(f"\033[31mno open task with ID {i} exists\033[0m", file=sys.stderr)
    return out


def add_task(data, words, status="pending", template=False):
    ignore = "--" in words
    words = [w for w in words if w != "--"]
    attrs = parse_attrs(words)
    base = {}
    if attrs["template_id"]:
        base = next((t for t in data["tasks"] if t["id"] == attrs["template_id"]), {})
    task = {
        "uuid": str(uuid.uuid4()),
        "status": "template" if template else status,
        "id": data.get("next_id", 1),
        "summary": attrs["summary"] or base.get("summary", ""),
        "notes": attrs["notes"] or base.get("notes", ""),
        "tags": list(base.get("tags", [])),
        "project": base.get("project", ""),
        "priority": base.get("priority", "P2"),
        "created": now(),
        "resolved": ZERO,
        "due": base.get("due", ZERO),
    }
    for tag in attrs["tags_add"]:
        if tag not in task["tags"]:
            task["tags"].append(tag)
    for tag in attrs["tags_rem"]:
        if tag in task["tags"]:
            task["tags"].remove(tag)
    if attrs["project"] is not None:
        task["project"] = attrs["project"]
    if attrs["priority"]:
        task["priority"] = attrs["priority"]
    if attrs["due"]:
        task["due"] = attrs["due"]
    if not template and status != "resolved":
        apply_context_to_new(task, data, ignore)
    if status == "resolved":
        task["resolved"] = now()
    data["next_id"] = task["id"] + 1
    data["tasks"].append(task)
    save(data)
    if template:
        print(f"Created Template {task['id']}: {task['summary']}")
    elif status == "resolved":
        print(f"Logged {task['summary']}")
    else:
        print(f"Added {task['id']}: {task['summary']}")


def show(data, status, words, use_context=True, ids=None):
    ignore = "--" in words
    words = [w for w in words if w != "--"]
    flt = []
    if use_context and not ignore:
        flt += context_words(data)
    flt += words
    tasks = [t for t in data["tasks"] if matches(t, flt)]
    if status == "open":
        tasks = [t for t in tasks if t["status"] in ("pending", "active", "paused")]
    elif status:
        tasks = [t for t in tasks if t["status"] == status]
    if ids:
        tasks = [t for t in tasks if t.get("id") in ids]
    tasks.sort(key=task_sort_key)
    emit_json([visible_task(t) for t in tasks])


def modify(data, tasks, words):
    attrs = parse_attrs(words)
    for t in tasks:
        for tag in attrs["tags_add"]:
            if tag not in t["tags"]:
                t["tags"].append(tag)
        for tag in attrs["tags_rem"]:
            if tag in t["tags"]:
                t["tags"].remove(tag)
        if attrs["project"] is not None:
            t["project"] = attrs["project"]
        if attrs["priority"]:
            t["priority"] = attrs["priority"]
        if attrs["due"]:
            t["due"] = attrs["due"]
        print(f"Modified {t['id']}: {t['summary']}")
    save(data)


def split_command(argv):
    ids, rest = [], []
    cmd = None
    for a in argv:
        if cmd is None and a.isdigit():
            ids.append(int(a))
        elif cmd is None and a in COMMANDS:
            cmd = a
        else:
            rest.append(a)
    if cmd is None:
        cmd = "next"
        rest = [a for a in argv if not a.isdigit()]
    else:
        # IDs may also follow command for note/remove-like forms.
        newrest = []
        for a in rest:
            if a.isdigit() and cmd in {"note", "start", "stop", "done", "remove", "modify", "open", "edit"}:
                ids.append(int(a))
            else:
                newrest.append(a)
        rest = newrest
    return ids, cmd, rest


def main():
    argv = sys.argv[1:]
    ids, cmd, rest = split_command(argv)
    if cmd == "help":
        print(HELP_TOPICS.get(rest[0], HELP) if rest else HELP)
        return
    if cmd == "version":
        print("Version: Unknown\nGit commit: Unknown\nBuild date: Unknown")
        return
    if cmd.endswith("-completion"):
        print("# completion unavailable in this reimplementation")
        return

    data = load()
    if cmd in ("next", "show-open"):
        show(data, "open", rest, ids=ids)
    elif cmd == "show-active":
        show(data, "active", rest)
    elif cmd == "show-paused":
        show(data, "paused", rest)
    elif cmd == "show-resolved":
        show(data, "resolved", rest, use_context=False)
    elif cmd == "show-templates":
        show(data, "template", rest, use_context=False)
    elif cmd == "show-unorganised":
        emit_json([visible_task(t) for t in sorted(data["tasks"], key=task_sort_key) if t["status"] in ("pending", "active", "paused") and not t.get("tags") and not t.get("project")])
    elif cmd == "show-tags":
        tags = []
        for t in data["tasks"]:
            if t["status"] != "resolved":
                for tag in t.get("tags", []):
                    if tag not in tags:
                        tags.append(tag)
        print("\n".join(tags))
    elif cmd == "show-projects":
        projects = []
        for name in sorted({t.get("project", "") for t in data["tasks"] if t.get("project")}):
            ts = [t for t in data["tasks"] if t.get("project") == name]
            unresolved = [t for t in ts if t["status"] != "resolved"]
            sample = sorted(unresolved or ts, key=task_sort_key)[0]
            projects.append({
                "name": name,
                "taskCount": len(ts),
                "resolvedCount": len([t for t in ts if t["status"] == "resolved"]),
                "active": any(t["status"] == "active" for t in ts),
                "created": sample["created"],
                "resolved": sample.get("resolved", ZERO),
                "priority": sample.get("priority", "P2"),
            })
        emit_json(projects)
    elif cmd == "add":
        add_task(data, rest)
    elif cmd == "template":
        add_task(data, rest, template=True)
    elif cmd == "log":
        add_task(data, rest, status="resolved")
    elif cmd == "context":
        ctx = " ".join(rest).strip()
        data["context"] = "" if ctx in ("", "none", "--") else ctx
        save(data)
        if data["context"]:
            print(f"\033[33mActive context: {data['context']}\033[0m")
    elif cmd in ("start", "stop", "done"):
        tasks = find_ids(data, ids)
        for t in tasks:
            t["status"] = {"start": "active", "stop": "paused", "done": "resolved"}[cmd]
            if cmd == "done":
                t["resolved"] = now()
                print(f"Resolved {t['id']}: {t['summary']}")
            elif cmd == "start":
                print(f"Started {t['id']}: {t['summary']}")
            else:
                print(f"Stopped {t['id']}: {t['summary']}")
        save(data)
    elif cmd == "modify":
        tasks = find_ids(data, ids) if ids else [t for t in data["tasks"] if t["status"] != "resolved" and matches(t, context_words(data))]
        modify(data, tasks, rest)
    elif cmd == "note":
        tasks = find_ids(data, ids)
        text = " ".join(rest).strip()
        for t in tasks:
            if text:
                t["notes"] = (t.get("notes", "") + ("\n" if t.get("notes") else "") + text)
                print(f"Noted {t['id']}: {t['summary']}")
            else:
                print(t.get("notes", ""))
        save(data)
    elif cmd == "remove":
        for t in find_ids(data, ids):
            print(f"{t['id']}: {t['summary']}\n")
            data["tasks"].remove(t)
            print(f"Removed: {t['id']}: {t['summary']}")
        save(data)
    elif cmd == "open":
        targets = find_ids(data, ids) if ids else data["tasks"]
        urls = []
        for t in targets:
            urls += re.findall(r"https?://\\S+", t.get("summary", "") + "\n" + t.get("notes", ""))
        print("\n".join(urls))
    elif cmd == "git":
        raise SystemExit(subprocess.call(["git", "-C", str(repo())] + rest))
    elif cmd in ("sync", "undo"):
        print("No git operation performed")
    else:
        print(HELP)


if __name__ == "__main__":
    main()
