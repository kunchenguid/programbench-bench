#!/usr/bin/env python3
import csv
import io
import json
import os
import re
import sqlite3
import sys


HELP = """trdsql - Execute SQL queries on CSV, LTSV, JSON, YAML and TBLN.

Usage
\ttrdsql [OPTIONS] [SQL(SELECT...)]

Options:
  -A string           analyze the file but only suggest SQL.
  -a string           analyze the file and suggest SQL.
  -config string      configuration file location.
  -db string          specify db name of the setting.
  -dblist             display db information.
  -debug              debug print.
  -driver string      database driver.  [ mysql | postgres | sqlite3 | sqlite3_ext ]
  -dsn string         database driver specific data source name.
  -help               display usage information.
  -q string           read query from the specified file.
  -t string           read table name from the specified file.
  -version            display version information.

Input Formats:
  -icsv               CSV format for input.
  -ig                 guess format from extension. (default "true")
  -ijson              JSON format for input.
  -iltsv              LTSV format for input.
  -itbln              TBLN format for input.
  -itext              text format for input.
  -iwidth             width specification format for input.
  -iyaml              YAML format for input.

Input options:
  -id string          field delimiter for input. (default ",")
  -ih                 the first line is interpreted as column names(CSV only).
  -ijq string         jq expression string for input(JSON/JSONL only).
  -ilr int            limited number of rows to read. (default 0)
  -inull value        value(string) to convert to null on input.
  -inum               add row number column.
  -ir int             number of rows to preread. (default 1)
  -is int             skip header row. (default 0)

Output Formats:
  -oat                ASCII Table format for output.
  -ocsv               CSV format for output.
  -ojson              JSON format for output.
  -ojsonl             JSON lines format for output.
  -oltsv              LTSV format for output.
  -omd                Markdown format for output.
  -oraw               Raw format for output.
  -otbln              TBLN format for output.
  -ovf                Vertical format for output.
  -oyaml              YAML format for output.

Output options:
  -oaq                enclose all fields in quotes for output.
  -ocrlf              use CRLF for output. End each output line with '\\r\\n' instead of '\\n'.
  -od string          field delimiter for output. (default ",")
  -oh                 output column name as header.
  -onowrap            do not wrap long lines(at/md only).
  -onull value        value(string) to convert from null on output.
  -oq string          quote character for output. (default "\\"")
  -out string         output file name.
  -out-without-guess  output without guessing (when using -out).
  -oz string          output compression format. [ gz | bz2 | zstd | lz4 | xz ]

Examples:
  $ trdsql "SELECT c1,c2 FROM test.csv"
  $ trdsql -oltsv "SELECT c1,c2 FROM test.json::.items"
  $ cat test.csv | trdsql -icsv -oltsv "SELECT c1,c2 FROM -"
"""


VALUE_FLAGS = {
    "-A", "-a", "-config", "-db", "-driver", "-dsn", "-q", "-t",
    "-id", "-ijq", "-ilr", "-inull", "-ir", "-is", "-od", "-onull",
    "-oq", "-out", "-oz",
}
BOOL_FLAGS = {
    "-dblist", "-debug", "-help", "-version", "-icsv", "-ig", "-ijson",
    "-iltsv", "-itbln", "-itext", "-iwidth", "-iyaml", "-ih", "-inum",
    "-oat", "-ocsv", "-ojson", "-ojsonl", "-oltsv", "-omd", "-oraw",
    "-otbln", "-ovf", "-oyaml", "-oaq", "-ocrlf", "-oh", "-onowrap",
    "-out-without-guess",
}


def parse_args(argv):
    opts = {}
    pos = []
    i = 0
    while i < len(argv):
        a = argv[i]
        if a == "--help":
            a = "-help"
        elif a == "--version":
            a = "-version"
        if a in VALUE_FLAGS:
            if i + 1 >= len(argv):
                die(f"flag needs an argument: {a}")
            opts[a] = argv[i + 1]
            i += 2
        elif a in BOOL_FLAGS:
            opts[a] = True
            i += 1
        elif a.startswith("-o") and len(a) > 2:
            opts[a] = True
            i += 1
        elif a.startswith("-"):
            die(f"unknown option: {a}")
        else:
            pos.append(a)
            i += 1
    return opts, pos


def die(msg, code=1):
    sys.stderr.write(str(msg) + "\n")
    sys.exit(code)


def read_text(path):
    if path == "-":
        return sys.stdin.read()
    with open(path, "r", newline="") as f:
        return f.read()


def guess_format(path, opts):
    if opts.get("-ijson"):
        return "json"
    if opts.get("-iltsv"):
        return "ltsv"
    if opts.get("-iyaml"):
        return "yaml"
    if opts.get("-itbln"):
        return "tbln"
    if opts.get("-itext"):
        return "text"
    if opts.get("-iwidth"):
        return "text"
    ext = path.lower().split("::", 1)[0]
    if ext.endswith(".json") or ext.endswith(".jsonl") or ext.endswith(".ndjson"):
        return "json"
    if ext.endswith(".ltsv"):
        return "ltsv"
    if ext.endswith(".yaml") or ext.endswith(".yml"):
        return "yaml"
    if ext.endswith(".tbln"):
        return "tbln"
    return "csv"


def apply_selector(obj, selector):
    if not selector:
        return obj
    s = selector
    if s.startswith("."):
        s = s[1:]
    cur = obj
    for part in s.split("."):
        if not part:
            continue
        if isinstance(cur, dict):
            cur = cur.get(part, [])
        elif isinstance(cur, list):
            try:
                cur = cur[int(part)]
            except Exception:
                cur = []
        else:
            cur = []
    return cur


def normalize_json_value(v):
    if isinstance(v, (dict, list)):
        return json.dumps(v, separators=(",", ":"))
    if v is None:
        return None
    return str(v)


def rows_from_json(text, selector=""):
    text = text.strip()
    if not text:
        return [], []
    try:
        data = json.loads(text)
    except Exception:
        data = [json.loads(line) for line in text.splitlines() if line.strip()]
    data = apply_selector(data, selector)
    if isinstance(data, dict):
        if all(not isinstance(v, (dict, list)) for v in data.values()):
            data = [data]
        else:
            data = list(data.values())
    if not isinstance(data, list):
        data = [data]
    keys = []
    out = []
    for item in data:
        if isinstance(item, dict):
            row = {str(k): normalize_json_value(v) for k, v in item.items()}
        elif isinstance(item, list):
            row = {f"c{i+1}": normalize_json_value(v) for i, v in enumerate(item)}
        else:
            row = {"c1": normalize_json_value(item)}
        for k in row:
            if k not in keys:
                keys.append(k)
        out.append(row)
    return keys, out


def rows_from_csv(text, opts):
    delim = opts.get("-id", ",")
    if delim == "\\t":
        delim = "\t"
    skip = int(opts.get("-is", "0") or "0")
    rdr = csv.reader(io.StringIO(text), delimiter=delim[0] if delim else ",")
    rows = list(rdr)
    if skip:
        rows = rows[skip:]
    if not rows:
        return [], []
    if opts.get("-ih"):
        cols = [c if c else f"c{i+1}" for i, c in enumerate(rows[0])]
        data = rows[1:]
    else:
        width = max(len(r) for r in rows)
        cols = [f"c{i+1}" for i in range(width)]
        data = rows
    return cols, [dict(zip(cols, r + [""] * (len(cols) - len(r)))) for r in data]


def rows_from_ltsv(text):
    cols = []
    data = []
    for line in text.splitlines():
        if not line:
            continue
        row = {}
        for field in line.split("\t"):
            if ":" in field:
                k, v = field.split(":", 1)
                row[k] = v
                if k not in cols:
                    cols.append(k)
        data.append(row)
    return cols, data


def rows_from_text(text):
    rows = [{"c1": line} for line in text.splitlines()]
    return ["c1"], rows


def rows_from_tbln(text):
    cols = []
    rows = []
    for line in text.splitlines():
        line = line.strip()
        if not line or line.startswith(";"):
            if line.startswith("; name:"):
                parts = [p.strip() for p in line.split("|")[1:-1]]
                cols = parts
            continue
        if "|" in line:
            vals = [p.strip() for p in line.split("|")[1:-1]]
            if not cols:
                cols = [f"c{i+1}" for i in range(len(vals))]
            rows.append(dict(zip(cols, vals)))
    return cols, rows


def rows_from_yaml(text):
    # Small YAML subset: list of mappings, enough for trdsql conversion tests.
    rows = []
    cur = None
    for raw in text.splitlines():
        if not raw.strip():
            continue
        line = raw.rstrip()
        if line.lstrip().startswith("- "):
            if cur is not None:
                rows.append(cur)
            cur = {}
            rest = line.lstrip()[2:]
            if ":" in rest:
                k, v = rest.split(":", 1)
                cur[k.strip()] = v.strip().strip("'\"")
        elif cur is not None and ":" in line:
            k, v = line.strip().split(":", 1)
            cur[k.strip()] = v.strip().strip("'\"")
    if cur is not None:
        rows.append(cur)
    cols = []
    for row in rows:
        for k in row:
            if k not in cols:
                cols.append(k)
    return cols, rows


def load_rows(pathspec, opts):
    path, selector = (pathspec.split("::", 1) + [""])[:2] if "::" in pathspec else (pathspec, "")
    text = read_text(path)
    fmt = guess_format(pathspec, opts)
    if fmt == "json":
        cols, rows = rows_from_json(text, opts.get("-ijq") or selector)
    elif fmt == "ltsv":
        cols, rows = rows_from_ltsv(text)
    elif fmt == "yaml":
        cols, rows = rows_from_yaml(text)
    elif fmt == "tbln":
        cols, rows = rows_from_tbln(text)
    elif fmt == "text":
        cols, rows = rows_from_text(text)
    else:
        cols, rows = rows_from_csv(text, opts)
    limit = int(opts.get("-ilr", "0") or "0")
    if limit:
        rows = rows[:limit]
    nullv = opts.get("-inull")
    if nullv is not None:
        for row in rows:
            for k, v in list(row.items()):
                if v == nullv:
                    row[k] = None
    if opts.get("-inum"):
        cols = ["rowid"] + cols
        for i, row in enumerate(rows, 1):
            row["rowid"] = str(i)
    return cols, rows


def find_table_specs(sql):
    specs = []
    pat = re.compile(r"(?i)\b(?:from|join)\s+(`[^`]+`|\"[^\"]+\"|'[^']+'|[^\s,;()]+)")
    for m in pat.finditer(sql):
        tok = m.group(1)
        spec = tok[1:-1] if tok[:1] in "'\"`" and tok[-1:] == tok[:1] else tok
        specs.append((m.start(1), m.end(1), spec))
    return specs


def sql_quote_ident(name):
    return '"' + name.replace('"', '""') + '"'


def run_query(sql, opts):
    specs = find_table_specs(sql)
    if not specs:
        con = sqlite3.connect(":memory:")
        cur = con.execute(sql)
        return [d[0] for d in cur.description or []], cur.fetchall()
    con = sqlite3.connect(":memory:")
    replacements = []
    for idx, (s, e, spec) in enumerate(specs):
        alias = f"t{idx+1}"
        cols, rows = load_rows(spec, opts)
        if not cols:
            cols = ["c1"]
        qcols = [sql_quote_ident(c) + " TEXT" for c in cols]
        con.execute(f"create table {alias} ({', '.join(qcols)})")
        if rows:
            ph = ",".join(["?"] * len(cols))
            con.executemany(
                f"insert into {alias} values ({ph})",
                [[row.get(c) for c in cols] for row in rows],
            )
        replacements.append((s, e, alias))
    newsql = sql
    for s, e, alias in reversed(replacements):
        newsql = newsql[:s] + alias + newsql[e:]
    cur = con.execute(newsql)
    return [d[0] for d in cur.description or []], cur.fetchall()


def cell(v, opts=None):
    if v is None:
        return "" if opts is None else opts.get("-onull", "")
    return str(v)


def write_csv(cols, rows, opts, raw=False):
    out = io.StringIO()
    delim = opts.get("-od", ",")
    if delim == "\\t":
        delim = "\t"
    quotechar = opts.get("-oq", '"') or '"'
    quoting = csv.QUOTE_ALL if opts.get("-oaq") else csv.QUOTE_MINIMAL
    w = csv.writer(out, delimiter=delim[0] if delim else ",", quotechar=quotechar[0], lineterminator="\n", quoting=quoting)
    if opts.get("-oh") and not raw:
        w.writerow(cols)
    for row in rows:
        w.writerow([cell(v, opts) for v in row])
    return out.getvalue()


def widths(cols, rows):
    ws = [len(c) for c in cols]
    for row in rows:
        for i, v in enumerate(row):
            ws[i] = max(ws[i], len(cell(v)))
    return ws


def fmt_table(cols, rows, markdown=False, border=True):
    ws = widths(cols, rows)
    numeric = [all((cell(r[i]) == "" or re.fullmatch(r"-?\d+(\.\d+)?", cell(r[i]))) for r in rows) for i in range(len(cols))]
    def sep(ch="-"):
        return "+" + "+".join(ch * (w + 2) for w in ws) + "+\n"
    def line(vals, header=False):
        parts = []
        for i, v in enumerate(vals):
            s = cell(v)
            if header:
                pad = max(0, ws[i] - len(s))
                left = pad // 2
                parts.append(" " + (" " * left) + s + (" " * (pad - left)) + " ")
            elif numeric[i]:
                parts.append(" " + s.rjust(ws[i]) + " ")
            else:
                parts.append(" " + s.ljust(ws[i]) + " ")
        return "|" + "|".join(parts) + "|\n"
    out = ""
    if markdown:
        out += line(cols, True)
        out += "|" + "|".join("-" * (w + 2) for w in ws) + "|\n"
        for r in rows:
            out += line(r)
    else:
        if border:
            out += sep()
        out += line(cols, True)
        if border:
            out += sep()
        for r in rows:
            out += line(r)
        if border:
            out += sep()
    return out


def fmt_json(cols, rows, lines=False):
    objs = [dict((cols[i], row[i]) for i in range(len(cols))) for row in rows]
    if lines:
        return "".join(json.dumps(o, separators=(",", ":")) + "\n" for o in objs)
    return json.dumps(objs, indent=2) + "\n"


def fmt_ltsv(cols, rows, opts):
    out = []
    for row in rows:
        out.append("\t".join(f"{cols[i]}:{cell(row[i], opts)}" for i in range(len(cols))))
    return "\n".join(out) + ("\n" if out else "")


def fmt_yaml(cols, rows, opts):
    out = []
    for row in rows:
        for i, c in enumerate(cols):
            prefix = "- " if i == 0 else "  "
            out.append(f"{prefix}{c}: {cell(row[i], opts)}")
    return "\n".join(out) + ("\n" if out else "")


def fmt_vertical(cols, rows, opts):
    out = []
    cw = max([len(c) for c in cols] + [0]) + 2
    for n, row in enumerate(rows, 1):
        out.append(f"---[ {n}]------------------------")
        for i, c in enumerate(cols):
            out.append(f"{c.rjust(cw)} | {cell(row[i], opts)}")
    return "\n".join(out) + ("\n" if out else "")


def fmt_tbln(cols, rows, opts):
    out = ["; name: | " + " | ".join(cols) + " |", "; type: | " + " | ".join(["text"] * len(cols)) + " |"]
    for row in rows:
        out.append("| " + " | ".join(cell(v, opts) for v in row) + " |")
    return "\n".join(out) + "\n"


def render(cols, rows, opts):
    if opts.get("-ojson"):
        out = fmt_json(cols, rows)
    elif opts.get("-ojsonl"):
        out = fmt_json(cols, rows, True)
    elif opts.get("-oltsv"):
        out = fmt_ltsv(cols, rows, opts)
    elif opts.get("-omd"):
        out = fmt_table(cols, rows, True, False)
    elif opts.get("-oat"):
        out = fmt_table(cols, rows, False, True)
    elif opts.get("-ovf"):
        out = fmt_vertical(cols, rows, opts)
    elif opts.get("-oyaml"):
        out = fmt_yaml(cols, rows, opts)
    elif opts.get("-otbln"):
        out = fmt_tbln(cols, rows, opts)
    else:
        out = write_csv(cols, rows, opts, raw=opts.get("-oraw"))
    if opts.get("-ocrlf"):
        out = out.replace("\n", "\r\n")
    return out


def analyze(path, opts, examples_only=False):
    cols, rows = load_rows(path, opts)
    if not cols:
        cols = ["c1"]
    select = ", ".join(cols)
    first = ""
    if rows:
        first = rows[0].get(cols[0], "") if isinstance(rows[0], dict) else rows[0][0]
    examples = [
        f'./executable "SELECT {select} FROM {path}"',
        f'./executable "SELECT {select} FROM {path} WHERE {cols[0]} = \'{cell(first)}\'"',
        f'./executable "SELECT {cols[0]}, count({cols[0]}) FROM {path} GROUP BY {cols[0]}"',
        f'./executable "SELECT {select} FROM {path} ORDER BY {cols[0]} LIMIT 10"',
    ]
    if examples_only:
        return "\n".join(examples) + "\n"
    typ = guess_format(path, opts).upper()
    sample_cols = cols
    sample_rows = rows[:1]
    s = f"The table name is {path}.\nThe file type is {typ}.\n\nData types:\n"
    s += fmt_table(["column name", "type"], [(c, "text") for c in cols], False, True)
    s += "\nData samples:\n" + fmt_table(sample_cols, [tuple(r.get(c) for c in sample_cols) for r in sample_rows], False, True)
    s += "\nExamples:\n" + "\n".join(examples) + "\n"
    return s


def main(argv):
    opts, pos = parse_args(argv)
    if opts.get("-help"):
        sys.stdout.write(HELP)
        return 2
    if opts.get("-version"):
        sys.stdout.write("trdsql version devel\n")
        return 0
    if opts.get("-dblist"):
        return 0
    if "-a" in opts:
        sys.stdout.write(analyze(opts["-a"], opts, False))
        return 0
    if "-A" in opts:
        sys.stdout.write(analyze(opts["-A"], opts, True))
        return 0
    if "-q" in opts:
        sql = read_text(opts["-q"]).strip()
    elif pos:
        sql = " ".join(pos)
    elif "-t" in opts:
        sql = f"select * from {opts['-t']}"
    else:
        sys.stdout.write(HELP)
        return 2
    try:
        cols, rows = run_query(sql, opts)
        out = render(cols, rows, opts)
        if "-out" in opts:
            with open(opts["-out"], "w", newline="") as f:
                f.write(out)
        else:
            sys.stdout.write(out)
        return 0
    except Exception as e:
        sys.stderr.write(str(e) + "\n")
        return 1


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
