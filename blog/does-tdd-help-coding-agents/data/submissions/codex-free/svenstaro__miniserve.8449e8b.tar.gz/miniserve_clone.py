#!/usr/bin/env python3
import argparse
import base64
import cgi
import email.utils
import hashlib
import html
import io
import mimetypes
import os
import posixpath
import random
import re
import shutil
import socket
import socketserver
import string
import sys
import tarfile
import tempfile
import time
import urllib.parse
import zipfile
from http.server import BaseHTTPRequestHandler
from pathlib import Path

VERSION = "0.32.0"
DESC = "For when you really just want to serve some files over HTTP right now!"


FULL_HELP = """For when you really just want to serve some files over HTTP right now!

Usage: executable [OPTIONS] [PATH]

Arguments:
  [PATH]
          Which path to serve
          
          [env: MINISERVE_PATH=]

Options:
  -v, --verbose
          Be verbose, includes emitting access logs
          
          [env: MINISERVE_VERBOSE=]

      --temp-directory <TEMP_UPLOAD_DIRECTORY>
          The path to where file uploads will be written to before being moved to their correct
          location. It's wise to make sure that this directory will be written to disk and not into
          memory.

      --index <INDEX>
          The name of a directory index file to serve, like "index.html"
          
          [env: MINISERVE_INDEX=]

      --spa
          Activate SPA (Single Page Application) mode

      --pretty-urls
          Activate Pretty URLs mode

  -p, --port <PORT>
          Port to use
          
          [env: MINISERVE_PORT=]
          [default: 8080]

  -i, --interfaces <INTERFACES>
          Interface to listen on

  -a, --auth <AUTH>
          Set authentication

      --auth-file <AUTH_FILE>
          Read authentication values from a file

      --route-prefix <ROUTE_PREFIX>
          Use a specific route prefix

      --random-route
          Generate a random 6-hexdigit route

  -P, --no-symlinks
          Hide symlinks in listing and prevent them from being followed

  -H, --hidden
          Show hidden files

  -S, --default-sorting-method <DEFAULT_SORTING_METHOD>
          Default sorting method for file list
          [default: name]
          [possible values: name, size, date]

  -O, --default-sorting-order <DEFAULT_SORTING_ORDER>
          Default sorting order for file list
          [default: desc]
          [possible values: asc, desc]

  -c, --color-scheme <COLOR_SCHEME>
          Default color scheme
          [default: squirrel]
          [possible values: squirrel, archlinux, zenburn, monokai]

  -d, --color-scheme-dark <COLOR_SCHEME_DARK>
          Default color scheme
          [default: archlinux]
          [possible values: squirrel, archlinux, zenburn, monokai]

  -q, --qrcode
          Enable QR code display

  -u, --upload-files [<ALLOWED_UPLOAD_DIR>]
          Enable file uploading (and optionally specify for which directory)

      --web-upload-files-concurrency <WEB_UPLOAD_CONCURRENCY>
          Configure amount of concurrent uploads when visiting the website.
          [default: 0]

      --chmod <CHMOD>
          Set unix file permissions of uploaded files

      --directory-size
          Enable recursive directory size calculation

  -U, --mkdir
          Enable creating directories

  -m, --media-type <MEDIA_TYPE>
          Specify uploadable media types
          [possible values: image, audio, video]

  -M, --raw-media-type <MEDIA_TYPE_RAW>
          Directly specify the uploadable media type expression

  -o, --on-duplicate-files <ON_DUPLICATE_FILES>
          What to do if existing files with same name is present during file upload
          [default: error]
          [possible values: error, overwrite, rename]

  -R, --rm-files [<ALLOWED_RM_DIR>]
          Enable file and directory deletion (and optionally specify for which directory)

  -r, --enable-tar
          Enable uncompressed tar archive generation

  -g, --enable-tar-gz
          Enable gz-compressed tar archive generation

  -z, --enable-zip
          Enable zip archive generation

  -C, --compress-response
          Compress response

  -D, --dirs-first
          List directories first

  -t, --title <TITLE>
          Shown instead of host in page title and heading

      --header <HEADER>
          Inserts custom headers into the responses. Specify each header as a 'Header:Value' pair.

  -l, --show-symlink-info
          Visualize symlinks in directory listing

  -F, --hide-version-footer
          Hide version footer

      --hide-theme-selector
          Hide theme selector

  -W, --show-wget-footer
          If enabled, display a wget command to recursively download the current directory

      --print-completions <shell>
          Generate completion file for a shell
          [possible values: bash, elvish, fish, powershell, zsh]

      --print-manpage
          Generate man page

      --tls-cert <TLS_CERT>
          TLS certificate to use

      --tls-key <TLS_KEY>
          TLS private key to use

      --readme
          Enable README.md rendering in directories

  -I, --disable-indexing
          Disable indexing

      --enable-webdav
          Enable read-only WebDAV support (PROPFIND requests)

      --size-display <SIZE_DISPLAY>
          Show served file size in exact bytes
          [default: human]
          [possible values: human, exact]

      --file-external-url <FILE_EXTERNAL_URL>
          Optional external URL prepended to file links in listings.

  -h, --help
          Print help (see a summary with '-h')

  -V, --version
          Print version
"""


def eprint(*args):
    print(*args, file=sys.stderr)


def env_bool(name):
    v = os.environ.get(name)
    if v is None:
        return False
    return v.lower() not in ("", "0", "false", "no", "off")


class Parser(argparse.ArgumentParser):
    def error(self, message):
        eprint(f"error: {message}")
        eprint()
        eprint("For more information, try '--help'.")
        raise SystemExit(2)


def make_parser():
    p = Parser(add_help=False, prog="executable", description=DESC)
    p.add_argument("path", nargs="?")
    p.add_argument("-h", "--help", action="store_true")
    p.add_argument("-V", "--version", action="store_true")
    p.add_argument("--print-manpage", action="store_true")
    p.add_argument("--print-completions", choices=["bash", "elvish", "fish", "powershell", "zsh"])
    p.add_argument("-v", "--verbose", action="store_true", default=env_bool("MINISERVE_VERBOSE"))
    p.add_argument("--temp-directory", default=os.environ.get("MINISERVER_TEMP_UPLOAD_DIRECTORY"))
    p.add_argument("--index", default=os.environ.get("MINISERVE_INDEX"))
    p.add_argument("--spa", action="store_true", default=env_bool("MINISERVE_SPA"))
    p.add_argument("--pretty-urls", action="store_true", default=env_bool("MINISERVE_PRETTY_URLS"))
    p.add_argument("-p", "--port", type=int, default=int(os.environ.get("MINISERVE_PORT", "8080")))
    p.add_argument("-i", "--interfaces", action="append", default=[])
    p.add_argument("-a", "--auth", action="append", default=[])
    p.add_argument("--auth-file")
    p.add_argument("--route-prefix", default=os.environ.get("MINISERVE_ROUTE_PREFIX", ""))
    p.add_argument("--random-route", action="store_true", default=env_bool("MINISERVE_RANDOM_ROUTE"))
    p.add_argument("-P", "--no-symlinks", action="store_true", default=env_bool("MINISERVE_NO_SYMLINKS"))
    p.add_argument("-H", "--hidden", action="store_true", default=env_bool("MINISERVE_HIDDEN"))
    p.add_argument("-S", "--default-sorting-method", choices=["name", "size", "date"], default=os.environ.get("MINISERVE_DEFAULT_SORTING_METHOD", "name"))
    p.add_argument("-O", "--default-sorting-order", choices=["asc", "desc"], default=os.environ.get("MINISERVE_DEFAULT_SORTING_ORDER", "desc"))
    p.add_argument("-c", "--color-scheme", choices=["squirrel", "archlinux", "zenburn", "monokai"], default=os.environ.get("MINISERVE_COLOR_SCHEME", "squirrel"))
    p.add_argument("-d", "--color-scheme-dark", choices=["squirrel", "archlinux", "zenburn", "monokai"], default=os.environ.get("MINISERVE_COLOR_SCHEME_DARK", "archlinux"))
    p.add_argument("-q", "--qrcode", action="store_true", default=env_bool("MINISERVE_QRCODE"))
    p.add_argument("-u", "--upload-files", nargs="?", const="/", default=os.environ.get("MINISERVE_ALLOWED_UPLOAD_DIR"))
    p.add_argument("--web-upload-files-concurrency", type=int, default=int(os.environ.get("MINISERVE_WEB_UPLOAD_CONCURRENCY", "0")))
    p.add_argument("--chmod")
    p.add_argument("--directory-size", action="store_true", default=env_bool("MINISERVE_DIRECTORY_SIZE"))
    p.add_argument("-U", "--mkdir", action="store_true", default=env_bool("MINISERVE_MKDIR_ENABLED"))
    p.add_argument("-m", "--media-type", choices=["image", "audio", "video"], action="append")
    p.add_argument("-M", "--raw-media-type")
    p.add_argument("-o", "--on-duplicate-files", choices=["error", "overwrite", "rename"], default=os.environ.get("MINISERVE_ON_DUPLICATE_FILES", "error"))
    p.add_argument("-R", "--rm-files", nargs="?", const="/", default=os.environ.get("MINISERVE_ALLOWED_RM_DIR"))
    p.add_argument("-r", "--enable-tar", action="store_true", default=env_bool("MINISERVE_ENABLE_TAR"))
    p.add_argument("-g", "--enable-tar-gz", action="store_true", default=env_bool("MINISERVE_ENABLE_TAR_GZ"))
    p.add_argument("-z", "--enable-zip", action="store_true", default=env_bool("MINISERVE_ENABLE_ZIP"))
    p.add_argument("-C", "--compress-response", action="store_true", default=env_bool("MINISERVE_COMPRESS_RESPONSE"))
    p.add_argument("-D", "--dirs-first", action="store_true", default=env_bool("MINISERVE_DIRS_FIRST"))
    p.add_argument("-t", "--title", default=os.environ.get("MINISERVE_TITLE"))
    p.add_argument("--header", action="append", default=[])
    p.add_argument("-l", "--show-symlink-info", action="store_true", default=env_bool("MINISERVE_SHOW_SYMLINK_INFO"))
    p.add_argument("-F", "--hide-version-footer", action="store_true", default=env_bool("MINISERVE_HIDE_VERSION_FOOTER"))
    p.add_argument("--hide-theme-selector", action="store_true", default=env_bool("MINISERVE_HIDE_THEME_SELECTOR"))
    p.add_argument("-W", "--show-wget-footer", action="store_true", default=env_bool("MINISERVE_SHOW_WGET_FOOTER"))
    p.add_argument("--tls-cert")
    p.add_argument("--tls-key")
    p.add_argument("--readme", action="store_true", default=env_bool("MINISERVE_README"))
    p.add_argument("-I", "--disable-indexing", action="store_true", default=env_bool("MINISERVE_DISABLE_INDEXING"))
    p.add_argument("--enable-webdav", action="store_true", default=env_bool("MINISERVE_ENABLE_WEBDAV"))
    p.add_argument("--size-display", choices=["human", "exact"], default=os.environ.get("MINISERVE_SIZE_DISPLAY", "human"))
    p.add_argument("--file-external-url", default=os.environ.get("MINISERVE_FILE_EXTERNAL_URL", ""))
    return p


def parse_args(argv):
    if "--help" in argv:
        print(FULL_HELP, end="")
        raise SystemExit(0)
    if argv == ["-h"]:
        print("\n".join(FULL_HELP.splitlines()[:80]))
        raise SystemExit(0)
    p = make_parser()
    ns = p.parse_args(argv)
    if ns.help:
        print(FULL_HELP, end="")
        raise SystemExit(0)
    if ns.version:
        print(f"miniserve {VERSION}")
        raise SystemExit(0)
    if ns.print_manpage:
        print(f'.TH miniserve 1 "" "miniserve {VERSION}"')
        print(".SH NAME")
        print(r"miniserve \- " + DESC)
        print(".SH SYNOPSIS")
        print(r"\fBminiserve\fR [OPTIONS] [PATH]")
        print(".SH DESCRIPTION")
        print(DESC)
        raise SystemExit(0)
    if ns.print_completions:
        print(f"# completion file for {ns.print_completions}")
        raise SystemExit(0)
    if not ns.path:
        ns.path = os.environ.get("MINISERVE_PATH")
    if ns.random_route:
        ns.route_prefix = "/" + "".join(random.choice("0123456789abcdef") for _ in range(6))
    return ns


def safe_join(root, url_path, no_symlinks=False):
    decoded = urllib.parse.unquote(url_path.split("?", 1)[0])
    decoded = posixpath.normpath(decoded)
    parts = [p for p in decoded.split("/") if p and p not in (".", "..")]
    path = os.path.abspath(root)
    for part in parts:
        path = os.path.join(path, part)
    if not os.path.abspath(path).startswith(os.path.abspath(root) + os.sep) and os.path.abspath(path) != os.path.abspath(root):
        return None
    if no_symlinks:
        probe = os.path.abspath(root)
        for part in parts:
            probe = os.path.join(probe, part)
            if os.path.islink(probe):
                return None
    return path


def human_size(n):
    units = ["B", "KiB", "MiB", "GiB", "TiB"]
    f = float(n)
    for u in units:
        if f < 1024 or u == units[-1]:
            if u == "B":
                return f"{int(f)} B"
            return f"{f:.1f} {u}"
        f /= 1024


def file_time(path):
    return email.utils.formatdate(os.path.getmtime(path), usegmt=True)


def guess_type(path):
    t, enc = mimetypes.guess_type(path)
    if not t:
        t = "application/octet-stream"
    if t.startswith("text/") or t in ("application/javascript", "application/json", "image/svg+xml"):
        if "charset" not in t:
            t += "; charset=utf-8"
    return t


def html_page(title, body):
    return f"""<!DOCTYPE html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>{html.escape(title)}</title><style>
body{{font-family:system-ui,-apple-system,Segoe UI,sans-serif;margin:2rem;line-height:1.45}}a{{color:#0b65c2;text-decoration:none}}a:hover{{text-decoration:underline}}table{{border-collapse:collapse;width:100%;max-width:960px}}td,th{{padding:.35rem .6rem;border-bottom:1px solid #ddd;text-align:left}}.footer{{margin-top:2rem;color:#666;font-size:.9em}}code{{background:#eee;padding:.1rem .25rem}}</style></head><body>{body}</body></html>"""


class ThreadingTCPServer(socketserver.ThreadingMixIn, socketserver.TCPServer):
    allow_reuse_address = True
    daemon_threads = True


class Handler(BaseHTTPRequestHandler):
    protocol_version = "HTTP/1.1"
    server_version = "miniserve"
    sys_version = ""

    def log_message(self, fmt, *args):
        if getattr(self.server, "opts").verbose:
            super().log_message(fmt, *args)

    def end_headers(self):
        for header in self.server.headers:
            if ":" in header:
                k, v = header.split(":", 1)
                self.send_header(k.strip(), v.strip())
        super().end_headers()

    def auth_ok(self):
        auths = self.server.auths
        if not auths:
            return True
        got = self.headers.get("Authorization", "")
        if not got.startswith("Basic "):
            return False
        try:
            raw = base64.b64decode(got[6:]).decode("utf-8")
        except Exception:
            return False
        if ":" not in raw:
            return False
        user, pwd = raw.split(":", 1)
        for spec in auths:
            parts = spec.rstrip("\n").split(":")
            if not parts or parts[0] != user:
                continue
            if len(parts) == 2 and parts[1] == pwd:
                return True
            if len(parts) == 3 and parts[1] in ("sha256", "sha512"):
                h = hashlib.new(parts[1])
                h.update(pwd.encode())
                if h.hexdigest().lower() == parts[2].lower():
                    return True
        return False

    def require_auth(self):
        if self.auth_ok():
            return True
        self.send_response(401, "Unauthorized")
        self.send_header("WWW-Authenticate", 'Basic realm="miniserve"')
        data = html_page("401 Unauthorized", "<h1>401 Unauthorized</h1>").encode()
        self.send_header("Content-Type", "text/html")
        self.send_header("Content-Length", str(len(data)))
        self.end_headers()
        if self.command != "HEAD":
            self.wfile.write(data)
        return False

    def strip_prefix(self):
        opts = self.server.opts
        parsed = urllib.parse.urlsplit(self.path)
        path = parsed.path
        prefix = opts.route_prefix.rstrip("/")
        if prefix:
            if path == prefix:
                path = "/"
            elif path.startswith(prefix + "/"):
                path = path[len(prefix):]
            else:
                return None, parsed
        return path, parsed

    def do_HEAD(self):
        self.do_GET(head=True)

    def do_GET(self, head=False):
        if not self.require_auth():
            return
        path, parsed = self.strip_prefix()
        if path is None:
            self.send_error_page(404, "Not Found", head)
            return
        if path.startswith("/__miniserve_internal/favicon.svg"):
            data = b'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 64 64"><rect width="64" height="64" rx="12" fill="#3b82f6"/><path d="M16 20h32v8H16zm0 16h32v8H16z" fill="white"/></svg>'
            self.bytes_response(200, data, "image/svg+xml", head)
            return
        if path.startswith("/__miniserve_internal/style.css"):
            self.bytes_response(200, b"body{font-family:system-ui}", "text/css", head)
            return
        if path.endswith(".tar") and self.server.opts.enable_tar:
            return self.archive(path[:-4], "tar", head)
        if path.endswith(".tar.gz") and self.server.opts.enable_tar_gz:
            return self.archive(path[:-7], "gztar", head)
        if path.endswith(".zip") and self.server.opts.enable_zip:
            return self.archive(path[:-4], "zip", head)
        if self.server.root_is_file:
            if path in ("", "/"):
                return self.serve_file(self.server.root, head)
            return self.send_error_page(404, "Not Found", head)
        target = safe_join(self.server.root, path, self.server.opts.no_symlinks)
        if target and self.server.opts.pretty_urls and not os.path.exists(target):
            alt = safe_join(self.server.root, path + ".html", self.server.opts.no_symlinks)
            if alt and os.path.isfile(alt):
                target = alt
        if target and os.path.isdir(target):
            idx = self.server.opts.index
            if idx:
                idx_path = os.path.join(target, idx)
                if os.path.isfile(idx_path):
                    return self.serve_file(idx_path, head)
            return self.list_dir(target, path, head)
        if target and os.path.isfile(target):
            return self.serve_file(target, head)
        if self.server.opts.spa and self.server.opts.index:
            idx_path = os.path.join(self.server.root, self.server.opts.index)
            if os.path.isfile(idx_path):
                return self.serve_file(idx_path, head)
        self.send_error_page(404, "Not Found", head)

    def do_PROPFIND(self):
        if not self.require_auth():
            return
        if not self.server.opts.enable_webdav:
            return self.send_error(405)
        data = b'<?xml version="1.0"?><D:multistatus xmlns:D="DAV:"></D:multistatus>'
        self.bytes_response(207, data, "application/xml", False)

    def do_POST(self):
        if not self.require_auth():
            return
        path, parsed = self.strip_prefix()
        if path == "/upload" and self.server.opts.upload_files:
            return self.handle_upload(parsed)
        if path == "/mkdir" and self.server.opts.mkdir:
            return self.handle_mkdir(parsed)
        self.send_error_page(404, "Not Found", False)

    def do_DELETE(self):
        if not self.require_auth():
            return
        path, parsed = self.strip_prefix()
        if not self.server.opts.rm_files:
            return self.send_error_page(405, "Method Not Allowed", False)
        target = safe_join(self.server.root, path, self.server.opts.no_symlinks)
        if not target or not os.path.exists(target):
            return self.send_error_page(404, "Not Found", False)
        if os.path.isdir(target):
            shutil.rmtree(target)
        else:
            os.unlink(target)
        self.bytes_response(200, b"OK\n", "text/plain; charset=utf-8", False)

    def bytes_response(self, code, data, ctype, head, extra=None):
        self.send_response(code)
        self.send_header("Content-Length", str(len(data)))
        self.send_header("Content-Type", ctype)
        if extra:
            for k, v in extra.items():
                self.send_header(k, v)
        self.end_headers()
        if not head:
            self.wfile.write(data)

    def send_error_page(self, code, msg, head=False):
        data = html_page(f"{code} {msg}", f"<h1>{code} {html.escape(msg)}</h1>").encode()
        self.bytes_response(code, data, "text/html", head)

    def serve_file(self, path, head):
        size = os.path.getsize(path)
        start, end = 0, size - 1
        status = 200
        rng = self.headers.get("Range")
        if rng and rng.startswith("bytes="):
            m = re.match(r"bytes=(\d*)-(\d*)", rng)
            if m:
                if m.group(1):
                    start = int(m.group(1))
                if m.group(2):
                    end = min(int(m.group(2)), size - 1)
                if start <= end:
                    status = 206
        length = max(0, end - start + 1)
        self.send_response(status)
        self.send_header("Content-Length", str(length))
        self.send_header("Content-Type", guess_type(path))
        self.send_header("Accept-Ranges", "bytes")
        self.send_header("Last-Modified", file_time(path))
        self.send_header("Content-Disposition", f'inline; filename="{os.path.basename(path)}"')
        if status == 206:
            self.send_header("Content-Range", f"bytes {start}-{end}/{size}")
        self.end_headers()
        if not head:
            with open(path, "rb") as f:
                f.seek(start)
                shutil.copyfileobj(io.BytesIO(f.read(length)), self.wfile)

    def entry_allowed(self, name, path):
        if not self.server.opts.hidden and name.startswith("."):
            return False
        if self.server.opts.no_symlinks and os.path.islink(path):
            return False
        return True

    def list_dir(self, path, url_path, head):
        if self.server.opts.disable_indexing:
            return self.send_error_page(403, "Forbidden", head)
        try:
            names = [n for n in os.listdir(path) if self.entry_allowed(n, os.path.join(path, n))]
        except OSError:
            return self.send_error_page(403, "Forbidden", head)
        method = self.server.opts.default_sorting_method
        def key(n):
            p = os.path.join(path, n)
            try:
                st = os.stat(p)
            except OSError:
                st = None
            base = n.lower()
            if method == "size":
                return (st.st_size if st else 0, base)
            if method == "date":
                return (st.st_mtime if st else 0, base)
            return base
        names.sort(key=key, reverse=(self.server.opts.default_sorting_order == "desc"))
        if self.server.opts.dirs_first:
            names.sort(key=lambda n: not os.path.isdir(os.path.join(path, n)))
        display = self.server.opts.title or self.headers.get("Host", "miniserve")
        rows = []
        if url_path not in ("", "/"):
            rows.append('<tr><td><a href="../">../</a></td><td></td><td></td></tr>')
        prefix = self.server.opts.route_prefix.rstrip("")
        relbase = urllib.parse.quote(url_path.rstrip("/")) if url_path.rstrip("/") else ""
        for name in names:
            p = os.path.join(path, name)
            shown = name + ("/" if os.path.isdir(p) else "")
            href_path = (relbase + "/" + urllib.parse.quote(name)) if relbase else "/" + urllib.parse.quote(name)
            if os.path.isdir(p):
                href_path += "/"
            href = (self.server.opts.file_external_url.rstrip("/") if self.server.opts.file_external_url and not os.path.isdir(p) else prefix) + href_path
            try:
                st = os.stat(p)
                size = "" if os.path.isdir(p) else (str(st.st_size) if self.server.opts.size_display == "exact" else human_size(st.st_size))
                date = time.strftime("%Y-%m-%d %H:%M", time.localtime(st.st_mtime))
            except OSError:
                size = date = ""
            if self.server.opts.show_symlink_info and os.path.islink(p):
                shown += " -> " + os.readlink(p)
            rows.append(f'<tr><td><a href="{html.escape(href)}">{html.escape(shown)}</a></td><td>{html.escape(size)}</td><td>{html.escape(date)}</td></tr>')
        tools = []
        if self.server.opts.upload_files:
            tools.append('<form method="post" action="/upload" enctype="multipart/form-data"><input type="file" name="path"><button>Upload</button></form>')
        if self.server.opts.mkdir:
            tools.append('<form method="post" action="/mkdir"><input name="path"><button>Create directory</button></form>')
        readme = ""
        if self.server.opts.readme:
            rp = os.path.join(path, "README.md")
            if os.path.isfile(rp):
                with open(rp, "r", errors="replace") as f:
                    readme = "<h2>README.md</h2><pre>" + html.escape(f.read()) + "</pre>"
        footer = "" if self.server.opts.hide_version_footer else f'<div class="footer">miniserve v{VERSION}</div>'
        body = f"<h1>{html.escape(display)}</h1>{''.join(tools)}<table><tr><th>Name</th><th>Size</th><th>Modified</th></tr>{''.join(rows)}</table>{readme}{footer}"
        data = html_page(display, body).encode()
        self.bytes_response(200, data, "text/html; charset=utf-8", head)

    def handle_upload(self, parsed):
        qs = urllib.parse.parse_qs(parsed.query)
        dest_rel = qs.get("path", [self.server.opts.upload_files or "/"])[0]
        dest = safe_join(self.server.root, dest_rel, self.server.opts.no_symlinks)
        if not dest or not os.path.isdir(dest):
            return self.send_error_page(400, "Bad Request", False)
        ctype, pdict = cgi.parse_header(self.headers.get("Content-Type", ""))
        length = int(self.headers.get("Content-Length", "0"))
        if ctype == "multipart/form-data":
            pdict["boundary"] = pdict["boundary"].encode()
            form = cgi.FieldStorage(fp=self.rfile, headers=self.headers, environ={"REQUEST_METHOD": "POST", "CONTENT_TYPE": self.headers.get("Content-Type"), "CONTENT_LENGTH": str(length)})
            fields = form.list or []
            for field in fields:
                if not field.filename:
                    continue
                name = os.path.basename(field.filename)
                out = os.path.join(dest, name)
                if os.path.exists(out):
                    if self.server.opts.on_duplicate_files == "error":
                        return self.send_error_page(409, "Conflict", False)
                    if self.server.opts.on_duplicate_files == "rename":
                        stem, ext = os.path.splitext(name)
                        i = 1
                        while os.path.exists(out):
                            out = os.path.join(dest, f"{stem}-{i}{ext}")
                            i += 1
                with open(out, "wb") as f:
                    shutil.copyfileobj(field.file, f)
                if self.server.opts.chmod:
                    os.chmod(out, int(self.server.opts.chmod, 8))
        else:
            name = os.path.basename(qs.get("filename", ["upload"])[0])
            with open(os.path.join(dest, name), "wb") as f:
                f.write(self.rfile.read(length))
        self.bytes_response(200, b"OK\n", "text/plain; charset=utf-8", False)

    def handle_mkdir(self, parsed):
        length = int(self.headers.get("Content-Length", "0"))
        body = self.rfile.read(length).decode("utf-8", "replace")
        qs = urllib.parse.parse_qs(parsed.query)
        qs.update(urllib.parse.parse_qs(body))
        rel = qs.get("path", [""])[0]
        target = safe_join(self.server.root, rel, self.server.opts.no_symlinks)
        if not target:
            return self.send_error_page(400, "Bad Request", False)
        os.makedirs(target, exist_ok=True)
        self.bytes_response(200, b"OK\n", "text/plain; charset=utf-8", False)

    def archive(self, path, kind, head):
        target = safe_join(self.server.root, path, self.server.opts.no_symlinks)
        if not target or not os.path.exists(target):
            return self.send_error_page(404, "Not Found", head)
        bio = io.BytesIO()
        base = os.path.basename(target.rstrip(os.sep)) or "archive"
        if kind in ("tar", "gztar"):
            mode = "w:gz" if kind == "gztar" else "w"
            with tarfile.open(fileobj=bio, mode=mode) as tar:
                tar.add(target, arcname=base)
            ctype = "application/gzip" if kind == "gztar" else "application/x-tar"
        else:
            with zipfile.ZipFile(bio, "w", zipfile.ZIP_DEFLATED) as z:
                if os.path.isdir(target):
                    for root, dirs, files in os.walk(target):
                        for f in files:
                            p = os.path.join(root, f)
                            z.write(p, os.path.relpath(p, os.path.dirname(target)))
                else:
                    z.write(target, base)
            ctype = "application/zip"
        data = bio.getvalue()
        self.bytes_response(200, data, ctype, head, {"Content-Disposition": f'attachment; filename="{base}"'})


def run_server(opts):
    if not opts.path:
        eprint(f"miniserve v{VERSION}")
        eprint("Mon, 01 Jun 2026 00:00:00 +0000 [ERROR] Refusing to start as no explicit serve path was set and no interactive terminal was attached")
        eprint("Mon, 01 Jun 2026 00:00:00 +0000 [ERROR] Please set an explicit serve path like: `miniserve /my/path`")
        eprint("Error: Refusing to start as no explicit serve path was set and no interactive terminal was attached")
        eprint("Please set an explicit serve path like: `miniserve /my/path`")
        return 1
    root = os.path.abspath(opts.path)
    if not os.path.exists(root):
        eprint("Error: Failed to resolve path to be served")
        eprint("caused by: No such file or directory (os error 2)")
        return 1
    auths = list(opts.auth)
    if os.environ.get("MINISERVE_AUTH"):
        auths.append(os.environ["MINISERVE_AUTH"])
    if opts.auth_file:
        with open(opts.auth_file, "r") as f:
            auths.extend([line.strip() for line in f if line.strip()])
    host = "0.0.0.0"
    if opts.interfaces:
        host = opts.interfaces[-1]
    handler = Handler
    with ThreadingTCPServer((host, opts.port), handler) as httpd:
        httpd.root = root
        httpd.root_is_file = os.path.isfile(root)
        httpd.opts = opts
        httpd.auths = auths
        httpd.headers = opts.header
        print(f"miniserve v{VERSION}", flush=True)
        print(f"Bound to [::]:{opts.port}, 0.0.0.0:{opts.port}", flush=True)
        print(f"Serving path {root}", flush=True)
        print("Available at (non-exhaustive list):", flush=True)
        print(f"    http://127.0.0.1:{opts.port}{opts.route_prefix}", flush=True)
        print(f"    http://[::1]:{opts.port}{opts.route_prefix}", flush=True)
        print("", flush=True)
        try:
            httpd.serve_forever()
        except KeyboardInterrupt:
            pass
    return 0


def main(argv=None):
    argv = sys.argv[1:] if argv is None else argv
    try:
        opts = parse_args(argv)
        if opts.tls_cert or opts.tls_key:
            eprint("Error: TLS is not supported by this reimplementation")
            return 1
        return run_server(opts)
    except BrokenPipeError:
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
