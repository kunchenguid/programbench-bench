#!/usr/bin/env python3
import json
import math
import os
import sys
from dataclasses import dataclass, field

VERSION = "0.21.1"
SCHEMA = "2024-11-02"


SHORT_HELP = """Summarize disk usage of the set of files, recursively for directories.

Usage: executable [OPTIONS] [FILES]...

Arguments:
  [FILES]...  List of files and/or directories

Options:
      --json-input
          Read JSON data from stdin
      --json-output
          Print JSON data instead of an ASCII chart
  -b, --bytes-format <BYTES_FORMAT>
          How to display the numbers of bytes [default: metric] [possible values: plain, metric, binary]
  -H, --deduplicate-hardlinks
          Detect and subtract the sizes of hardlinks from their parent directory totals [aliases: --detect-links, --dedupe-links]
      --top-down
          Print the tree top-down instead of bottom-up
      --align-right
          Set the root of the bars to the right
  -q, --quantity <QUANTITY>
          Aspect of the files/directories to be measured [default: block-size] [possible values: apparent-size, block-size, block-count]
  -d, --max-depth <MAX_DEPTH>
          Maximum depth to display the data. Could be either "inf" or a positive integer [default: 10] [aliases: --depth]
  -w, --total-width <TOTAL_WIDTH>
          Width of the visualization [aliases: --width]
      --column-width <TREE_WIDTH> <BAR_WIDTH>
          Maximum widths of the tree column and width of the bar column
  -m, --min-ratio <MIN_RATIO>
          Minimal size proportion required to appear [default: 0.01]
      --no-sort
          Do not sort the branches in the tree
  -s, --silent-errors
          Prevent filesystem error messages from appearing in stderr [aliases: --no-errors]
  -p, --progress
          Report progress being made at the expense of performance
      --threads <THREADS>
          Set the maximum number of threads to spawn. Could be either "auto", "max", or a positive integer [default: auto]
      --omit-json-shared-details
          Do not output `.shared.details` in the JSON output
      --omit-json-shared-summary
          Do not output `.shared.summary` in the JSON output
  -h, --help
          Print help (see more with '--help')
  -V, --version
          Print version

Examples:
    $ pdu
    $ pdu path/to/file/or/directory
    $ pdu file.txt dir/
    $ pdu --quantity=apparent-size
    $ pdu --deduplicate-hardlinks
    $ pdu --bytes-format=plain
    $ pdu --bytes-format=binary
    $ pdu --min-ratio=0
    $ pdu --min-ratio=0.05
    $ pdu --min-ratio=0 --max-depth=inf --json-output | jq
    $ pdu --json-input < disk-usage.json
"""

LONG_HELP = """Summarize disk usage of the set of files, recursively for directories.

Copyright: Apache-2.0 © 2021 Hoàng Văn Khải <https://github.com/KSXGitHub/>
Sponsor: https://github.com/sponsors/KSXGitHub

Usage: executable [OPTIONS] [FILES]...

Arguments:
  [FILES]...
          List of files and/or directories

Options:
      --json-input
          Read JSON data from stdin

      --json-output
          Print JSON data instead of an ASCII chart

  -b, --bytes-format <BYTES_FORMAT>
          How to display the numbers of bytes

          Possible values:
          - plain:  Display plain number of bytes without units
          - metric: Use metric scale, i.e. 1K = 1000B, 1M = 1000K, and so on
          - binary: Use binary scale, i.e. 1K = 1024B, 1M = 1024K, and so on
          
          [default: metric]

  -H, --deduplicate-hardlinks
          Detect and subtract the sizes of hardlinks from their parent directory totals
          
          [aliases: --detect-links, --dedupe-links]

      --top-down
          Print the tree top-down instead of bottom-up

      --align-right
          Set the root of the bars to the right

  -q, --quantity <QUANTITY>
          Aspect of the files/directories to be measured

          Possible values:
          - apparent-size: Measure apparent sizes
          - block-size:    Measure block sizes (block-count * 512B)
          - block-count:   Count numbers of blocks
          
          [default: block-size]

  -d, --max-depth <MAX_DEPTH>
          Maximum depth to display the data. Could be either "inf" or a positive integer
          
          [default: 10]
          [aliases: --depth]

  -w, --total-width <TOTAL_WIDTH>
          Width of the visualization
          
          [aliases: --width]

      --column-width <TREE_WIDTH> <BAR_WIDTH>
          Maximum widths of the tree column and width of the bar column

  -m, --min-ratio <MIN_RATIO>
          Minimal size proportion required to appear
          
          [default: 0.01]

      --no-sort
          Do not sort the branches in the tree

  -s, --silent-errors
          Prevent filesystem error messages from appearing in stderr
          
          [aliases: --no-errors]

  -p, --progress
          Report progress being made at the expense of performance

      --threads <THREADS>
          Set the maximum number of threads to spawn. Could be either "auto", "max", or a positive integer
          
          [default: auto]

      --omit-json-shared-details
          Do not output `.shared.details` in the JSON output

      --omit-json-shared-summary
          Do not output `.shared.summary` in the JSON output

  -h, --help
          Print help (see a summary with '-h')

  -V, --version
          Print version

Examples:
    Show disk usage chart of current working directory
    $ pdu

    Show disk usage chart of a single file or directory
    $ pdu path/to/file/or/directory

    Compare disk usages of multiple files and/or directories
    $ pdu file.txt dir/

    Show chart in apparent sizes instead of block sizes
    $ pdu --quantity=apparent-size

    Detect and subtract the sizes of hardlinks from their parent nodes
    $ pdu --deduplicate-hardlinks

    Show sizes in plain numbers instead of metric units
    $ pdu --bytes-format=plain

    Show sizes in base 2¹⁰ units (binary) instead of base 10³ units (metric)
    $ pdu --bytes-format=binary

    Show disk usage chart of all entries regardless of size
    $ pdu --min-ratio=0

    Only show disk usage chart of entries whose size is at least 5% of total
    $ pdu --min-ratio=0.05

    Show disk usage data as JSON instead of chart
    $ pdu --min-ratio=0 --max-depth=inf --json-output | jq

    Visualize existing JSON representation of disk usage data
    $ pdu --json-input < disk-usage.json
"""


@dataclass
class Node:
    name: str
    size: int = 0
    is_dir: bool = False
    children: list = field(default_factory=list)
    dev: int = 0
    ino: int = 0
    nlink: int = 1


class Opt:
    def __init__(self):
        self.json_input = False
        self.json_output = False
        self.bytes_format = "metric"
        self.dedupe = False
        self.top_down = False
        self.align_right = False
        self.quantity = "block-size"
        self.max_depth = 10
        self.total_width = None
        self.column_width = None
        self.min_ratio = 0.01
        self.no_sort = False
        self.silent = False
        self.progress = False
        self.threads = "auto"
        self.omit_details = False
        self.omit_summary = False
        self.files = []


def die(msg, code=2):
    print(msg, file=sys.stderr)
    sys.exit(code)


def parse_value(args, i, flag):
    if i + 1 >= len(args):
        die(f"error: a value is required for '{flag} <VALUE>' but none was supplied\n\nFor more information, try '--help'.")
    return args[i + 1], i + 1


def parse_args(argv):
    opt = Opt()
    i = 0
    positional = False
    while i < len(argv):
        a = argv[i]
        if positional:
            opt.files.append(a)
            i += 1
            continue
        if a == "--":
            positional = True
            i += 1
            continue
        if a in ("-h", "--help"):
            print(SHORT_HELP if a == "-h" else LONG_HELP, end="")
            sys.exit(0)
        if a in ("-V", "--version"):
            print(f"pdu {VERSION}")
            sys.exit(0)
        if a == "--json-input":
            opt.json_input = True
        elif a == "--json-output":
            opt.json_output = True
        elif a in ("-H", "--deduplicate-hardlinks", "--detect-links", "--dedupe-links"):
            opt.dedupe = True
        elif a == "--top-down":
            opt.top_down = True
        elif a == "--align-right":
            opt.align_right = True
        elif a == "--no-sort":
            opt.no_sort = True
        elif a in ("-s", "--silent-errors", "--no-errors"):
            opt.silent = True
        elif a in ("-p", "--progress"):
            opt.progress = True
        elif a in ("-b", "--bytes-format", "-q", "--quantity", "-d", "--max-depth", "--depth", "-w", "--total-width", "--width", "-m", "--min-ratio", "--threads"):
            val, i = parse_value(argv, i, a)
            set_option(opt, a, val)
        elif a == "--column-width":
            if i + 2 >= len(argv):
                die("error: 2 values required for '--column-width <TREE_WIDTH> <BAR_WIDTH>'")
            opt.column_width = (
                positive_int(argv[i + 1], "--column-width", "TREE_WIDTH"),
                positive_int(argv[i + 2], "--column-width", "BAR_WIDTH"),
            )
            i += 2
        elif a.startswith("--bytes-format="):
            set_option(opt, "--bytes-format", a.split("=", 1)[1])
        elif a.startswith("--quantity="):
            set_option(opt, "--quantity", a.split("=", 1)[1])
        elif a.startswith("--max-depth=") or a.startswith("--depth="):
            set_option(opt, "--max-depth", a.split("=", 1)[1])
        elif a.startswith("--total-width=") or a.startswith("--width="):
            set_option(opt, "--total-width", a.split("=", 1)[1])
        elif a.startswith("--min-ratio="):
            set_option(opt, "--min-ratio", a.split("=", 1)[1])
        elif a.startswith("--threads="):
            set_option(opt, "--threads", a.split("=", 1)[1])
        elif a.startswith("-"):
            die(f"error: unexpected argument '{a}' found\n\n  tip: to pass '{a}' as a value, use '-- {a}'\n\nUsage: executable [OPTIONS] [FILES]...\n\nFor more information, try '--help'.")
        else:
            opt.files.append(a)
        i += 1
    if not opt.files and not opt.json_input:
        opt.files = ["."]
    return opt


def positive_int(s, flag, metavar="VALUE"):
    try:
        n = int(s)
    except Exception:
        die(f"error: invalid value '{s}' for '{flag} <{metavar}>': invalid digit found in string\n\nFor more information, try '--help'.")
    if n <= 0:
        die(f"error: invalid value '{s}' for '{flag} <{metavar}>': Value is neither \"inf\" nor a positive integer: number would be zero for non-zero type\n\nFor more information, try '--help'.")
    return n


def set_option(opt, flag, val):
    if flag in ("-b", "--bytes-format"):
        if val not in ("plain", "metric", "binary"):
            die(f"error: invalid value '{val}' for '--bytes-format <BYTES_FORMAT>'\n  [possible values: plain, metric, binary]\n\nFor more information, try '--help'.")
        opt.bytes_format = val
    elif flag in ("-q", "--quantity"):
        if val not in ("apparent-size", "block-size", "block-count"):
            die(f"error: invalid value '{val}' for '--quantity <QUANTITY>'\n  [possible values: apparent-size, block-size, block-count]\n\nFor more information, try '--help'.")
        opt.quantity = val
    elif flag in ("-d", "--max-depth", "--depth"):
        if val == "inf":
            opt.max_depth = 10**9
        else:
            opt.max_depth = positive_int(val, "--max-depth", "MAX_DEPTH")
    elif flag in ("-w", "--total-width", "--width"):
        opt.total_width = positive_int(val, "--total-width", "TOTAL_WIDTH")
    elif flag in ("-m", "--min-ratio"):
        try:
            opt.min_ratio = float(val)
        except Exception:
            die(f"error: invalid value '{val}' for '--min-ratio <MIN_RATIO>'\n\nFor more information, try '--help'.")
    elif flag == "--threads":
        if val in ("auto", "max"):
            opt.threads = val
        else:
            try:
                if int(val) <= 0:
                    raise ValueError
            except Exception:
                die(f"error: invalid value '{val}' for '--threads <THREADS>': Value is neither \"auto\", \"max\", nor a number: number would be zero for non-zero type\n\nFor more information, try '--help'.")
            opt.threads = val


def own_size(st, quantity):
    if quantity == "apparent-size":
        return int(st.st_size)
    if quantity == "block-count":
        return int(getattr(st, "st_blocks", 0))
    return int(getattr(st, "st_blocks", 0)) * 512


def scan(path, name, opt, hardlinks):
    try:
        st = os.lstat(path)
    except OSError as e:
        if not opt.silent:
            print(f'[error] symlink_metadata "{path}": {e.strerror} (os error {e.errno})', file=sys.stderr)
        return Node(name=name, size=0)
    node = Node(name=name, size=own_size(st, opt.quantity), is_dir=os.path.isdir(path) and not os.path.islink(path),
                dev=st.st_dev, ino=st.st_ino, nlink=st.st_nlink)
    if st.st_nlink > 1:
        hardlinks.setdefault((st.st_dev, st.st_ino), {"size": own_size(st, opt.quantity), "links": st.st_nlink, "paths": []})["paths"].append(path)
    if node.is_dir:
        try:
            names = os.listdir(path)
        except OSError as e:
            if not opt.silent:
                print(f'[error] read_dir "{path}": {e.strerror} (os error {e.errno})', file=sys.stderr)
            names = []
        for child in names:
            cpath = os.path.join(path, child)
            cnode = scan(cpath, child, opt, hardlinks)
            node.children.append(cnode)
            node.size += cnode.size
        if not opt.no_sort:
            sort_children(node)
    return node


def sort_children(node):
    node.children.sort(key=lambda c: (-c.size, not c.is_dir, c.name))
    for c in node.children:
        sort_children(c)


def apply_depth_and_ratio(node, max_depth, min_ratio, total, depth=1):
    out = Node(node.name, node.size, node.is_dir, [], node.dev, node.ino, node.nlink)
    if depth >= max_depth:
        return out
    for c in node.children:
        if total == 0 or min_ratio <= 0 or c.size / total >= min_ratio:
            out.children.append(apply_depth_and_ratio(c, max_depth, min_ratio, total, depth + 1))
    return out


def from_json_tree(d):
    n = Node(str(d.get("name", "")), int(d.get("size", 0)), bool(d.get("children")), [])
    n.children = [from_json_tree(c) for c in d.get("children", [])]
    return n


def to_json_tree(node):
    return {"name": node.name, "size": node.size, "children": [to_json_tree(c) for c in node.children]}


def fmt_size(n, mode):
    if mode == "plain":
        return str(n)
    base = 1024 if mode == "binary" else 1000
    units = ["", "K", "M", "G", "T", "P", "E"]
    x = float(n)
    idx = 0
    while abs(x) >= base and idx < len(units) - 1:
        x /= base
        idx += 1
    if idx == 0:
        return str(int(n))
    return f"{x:.1f}{units[idx]}"


def flatten(node, top_down=False, prefix="", is_last=True, root=True):
    rows = []
    kids = node.children
    if top_down:
        if root:
            connector = "└─┬" if kids else "└──"
        elif kids:
            connector = "└─┬" if is_last else "├─┬"
        else:
            connector = "└──" if is_last else "├──"
        rows.append((node, prefix + connector))
        for idx, c in enumerate(kids):
            child_prefix = prefix + ("  " if root or is_last else "│ ")
            rows.extend(flatten(c, True, child_prefix, idx == len(kids) - 1, False))
    else:
        for idx, c in enumerate(reversed(kids)):
            orig_idx = len(kids) - 1 - idx
            child_prefix = prefix + ("  " if root else ("  " if is_last else "│ "))
            rows.extend(flatten(c, False, child_prefix, orig_idx == len(kids) - 1, False))
        if root:
            conn = "┌─┴" if kids else "┌──"
        else:
            conn = "┌─┴" if kids else "┌──"
            if not is_last:
                conn = "├─┴" if kids else "├──"
        rows.append((node, prefix + conn))
    return rows


def chart(node, opt, unit):
    total = max(node.size, 0)
    rows = flatten(node, opt.top_down)
    sizes = [fmt_size(n.size, opt.bytes_format if unit == "bytes" else "plain") for n, _ in rows]
    size_w = max([len(s) for s in sizes] + [1])
    tree_labels = [conn + n.name for n, conn in rows]
    tree_w = max([len(s) for s in tree_labels] + [1])
    if opt.column_width:
        tree_w = min(tree_w, opt.column_width[0])
        bar_w = opt.column_width[1]
    else:
        width = opt.total_width or 140
        bar_w = max(10, width - size_w - tree_w - 12)
    out = []
    for (n, conn), s, label in zip(rows, sizes, tree_labels):
        shown = label[:tree_w].ljust(tree_w)
        ratio = 0 if total == 0 else n.size / total
        pct = int(math.floor(ratio * 100 + 0.5))
        filled = min(bar_w, max(0, int(math.floor(ratio * bar_w + 0.5))))
        bar = "█" * filled + " " * (bar_w - filled)
        out.append(f"{s.rjust(size_w)} {shown}│{bar}│{pct:3d}%")
    print("\n".join(out))


def dedupe_summary(root, hardlinks, opt):
    groups = []
    for (_dev, ino), info in hardlinks.items():
        paths = info["paths"]
        if len(paths) > 1:
            paths.sort(key=lambda p: (-p.count(os.sep), p))
            groups.append((ino, info["size"], info["links"], paths))
    if not groups:
        return None
    # Match the visible behavior for common cases: report duplicate sets and
    # subtract one shared copy from the aggregate root.
    subtract = sum(size * (len(paths) - 1) for _ino, size, _links, paths in groups)
    root.size = max(0, root.size - subtract)
    shared = {}
    if not opt.omit_details:
        details = []
        for ino, size, links, paths in groups:
            details.append({"ino": ino, "size": size, "links": links, "paths": paths})
        shared["details"] = details
    if not opt.omit_summary:
        shared["summary"] = {
            "inodes": len(groups),
            "exclusive_inodes": len(groups),
            "all_links": sum(g[2] for g in groups),
            "detected_links": sum(len(g[3]) for g in groups),
            "exclusive_links": sum(len(g[3]) for g in groups),
            "shared_size": sum(g[1] for g in groups),
            "exclusive_shared_size": sum(g[1] for g in groups),
        }
    return shared or None


def main(argv):
    opt = parse_args(argv)
    unit = "blocks" if opt.quantity == "block-count" else "bytes"
    shared = None
    if opt.json_input:
        data = json.load(sys.stdin)
        root = from_json_tree(data["tree"])
        unit = data.get("unit", unit)
        # The original renders charts for json-input even if --json-output is present.
        opt.json_output = False
    else:
        hardlinks = {}
        roots = [scan(p, p, opt, hardlinks) for p in opt.files]
        if len(roots) == 1:
            root = roots[0]
        else:
            root = Node("(total)", sum(r.size for r in roots), True, roots)
            if not opt.no_sort:
                sort_children(root)
        if opt.dedupe:
            shared = dedupe_summary(root, hardlinks, opt)
    view = apply_depth_and_ratio(root, opt.max_depth, opt.min_ratio, root.size)
    if opt.json_output:
        obj = {"schema-version": SCHEMA, "pdu": VERSION, "unit": unit, "tree": to_json_tree(view)}
        if shared:
            obj["shared"] = shared
        print(json.dumps(obj, separators=(",", ":")))
    else:
        chart(view, opt, unit)


if __name__ == "__main__":
    main(sys.argv[1:])
