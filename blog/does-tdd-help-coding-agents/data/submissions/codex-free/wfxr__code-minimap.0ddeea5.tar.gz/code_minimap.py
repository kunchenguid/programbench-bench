#!/usr/bin/env python3
import argparse
import math
import os
import sys


VERSION = "code-minimap 0.6.8"

DOTS = [
    [0x01, 0x08],
    [0x02, 0x10],
    [0x04, 0x20],
    [0x40, 0x80],
]


HELP = """A high performance code minimap generator

Usage: executable [OPTIONS] [FILE] [COMMAND]

Commands:
  completion
          Generate shell completion file
  help
          Print this message or the help of the given subcommand(s)

Arguments:
  [FILE]
          File to read

Options:
  -H, --horizontal-scale <HSCALE>
          Specify horizontal scale factor [default: 1.0]
  -V, --vertical-scale <VSCALE>
          Specify vertical scale factor [default: 1.0]
      --padding <PADDING>
          Specify padding width
      --encoding <ENCODING>
          Specify input encoding [default: utf8-lossy] [possible values: utf8-lossy, utf8]
      --version
          Print version
  -h, --help
          Print help
"""


COMPLETION_HELP = """Generate shell completion file

Usage: executable completion <SHELL>

Arguments:
  <SHELL>
          Target shell name [possible values: bash, elvish, fish, powershell, zsh]

Options:
  -h, --help
          Print help
"""


def die(message, status=1):
    sys.stderr.write(message)
    if not message.endswith("\n"):
        sys.stderr.write("\n")
    sys.exit(status)


def parse_float(value, option):
    try:
        return float(value)
    except ValueError:
        die(
            f"error: invalid value '{value}' for '{option}': invalid float literal\n\n"
            "For more information, try '--help'.",
            2,
        )


def read_input(path, encoding):
    try:
        if path is None:
            data = sys.stdin.buffer.read()
        else:
            with open(path, "rb") as fh:
                data = fh.read()
    except OSError as exc:
        die(f"code-minimap: {exc.strerror} (os error {exc.errno})", 1)
    if encoding == "utf8":
        try:
            return data.decode("utf-8")
        except UnicodeDecodeError:
            die("code-minimap: stream did not contain valid UTF-8", 1)
    return data.decode("utf-8", "replace")


def visible_span(line):
    end = len(line.rstrip(" \t\r\n"))
    if end == 0:
        return None
    start = 0
    while start < end and line[start] in " \t":
        start += 1
    if start >= end:
        return None
    return start, end


def scaled_range(start, end, scale):
    if scale <= 0:
        return 0, 0
    return int(math.floor(start * scale)), int(math.floor(end * scale))


def render(text, hscale=1.0, vscale=1.0, padding=None):
    if text == "":
        return ""
    lines = text.splitlines()
    if text.endswith("\n") and len(lines) == 0:
        lines = [""]
    if not lines and text:
        lines = [text]

    rows = {}
    collapsed_rows = {}
    collapsed = False
    collapsed_x = 0
    max_x = 0
    any_line = bool(lines)
    for y, line in enumerate(lines):
        span = visible_span(line)
        if span is None:
            continue
        x0, x1 = scaled_range(span[0], span[1], hscale)
        if vscale < 1.0:
            yy = int(math.floor(y * max(vscale, 0.0)))
        else:
            yy = y
        if x1 <= x0:
            collapsed = True
            collapsed_x = max(collapsed_x, x0)
            collapsed_rows[yy] = max(collapsed_rows.get(yy, 0), x0)
            continue
        row = rows.setdefault(yy, [])
        row.append((x0, x1))
        max_x = max(max_x, x1)

    if vscale < 1.0:
        merged = {}
        for yy, spans in rows.items():
            if spans:
                merged[yy] = [(min(s[0] for s in spans), max(s[1] for s in spans))]
        rows = merged
        max_x = max((span[1] for spans in rows.values() for span in spans), default=0)

    if max_x:
        base_cells = (max_x + 1) // 2
    elif collapsed_x:
        base_cells = (collapsed_x + 1) // 2
    elif any_line and not collapsed and hscale >= 1.0:
        base_cells = 1
    else:
        base_cells = 0
    if max_x == 0:
        cell_width = base_cells if hscale > 0 else 0
    else:
        cell_width = (max_x + 1) // 2
    if padding is not None:
        cell_width = max(cell_width, padding)
    if cell_width == 0:
        if not any_line:
            return ""
        return "\n" * max(1, (len(lines) + 3) // 4)

    max_y = max(rows.keys(), default=0)
    scaled_line_count = int(math.ceil(len(lines) * max(vscale, 0.0))) if vscale < 1.0 else len(lines)
    cell_height = max(1, max_y // 4 + 1, (scaled_line_count + 3) // 4)
    out_lines = []
    for cy in range(cell_height):
        chars = []
        for cx in range(cell_width):
            bits = 0
            for ry in range(4):
                py = cy * 4 + ry
                for x0, x1 in rows.get(py, []):
                    for rx in range(2):
                        px = cx * 2 + rx
                        if x0 <= px < x1:
                            bits |= DOTS[ry][rx]
            if bits:
                chars.append(chr(0x2800 + bits))
            else:
                chars.append(" " if padding is not None and cx >= base_cells else chr(0x2800))
        line = "".join(chars)
        if padding is None:
            line = line.rstrip(chr(0x2800))
            if line == "" and cell_width > 0:
                has_collapsed = any(collapsed_rows.get(cy * 4 + ry, 0) > 0 for ry in range(4))
                line = "" if hscale < 1.0 and not has_collapsed else chr(0x2800)
        else:
            blank = chr(0x2800)
            last = max((idx for idx, ch in enumerate(line) if ch != blank), default=-1)
            target = max(padding or 0, last + 1 if last >= 0 else 1)
            if last == -1:
                line = blank + (" " * max(0, target - 1))
            else:
                line = line[: last + 1] + (" " * max(0, target - last - 1))
        out_lines.append(line)
    return "\n".join(out_lines) + "\n"


def completion(shell):
    if shell == "bash":
        return """_code-minimap() {
    local i cur prev opts cmd
    COMPREPLY=()
    cur="${COMP_WORDS[COMP_CWORD]}"
    prev="${COMP_WORDS[COMP_CWORD-1]}"
    opts="-H --horizontal-scale -V --vertical-scale --padding --encoding --version -h --help completion help"
}
complete -F _code-minimap code-minimap executable
"""
    if shell == "fish":
        return "complete -c code-minimap -f -a 'completion help'\n"
    if shell == "zsh":
        return "#compdef code-minimap executable\n_arguments '*: :_files'\n"
    if shell == "elvish":
        return "edit:completion:arg-completer[code-minimap] = {|@words| }\n"
    if shell == "powershell":
        return "Register-ArgumentCompleter -Native -CommandName code-minimap -ScriptBlock { }\n"
    die(
        f"error: invalid value '{shell}' for '<SHELL>'\n"
        "  [possible values: bash, elvish, fish, powershell, zsh]\n\n"
        "For more information, try '--help'.",
        2,
    )


def main(argv):
    if len(argv) >= 2 and argv[1] == "help":
        if len(argv) >= 3 and argv[2] == "completion":
            sys.stdout.write(COMPLETION_HELP)
        else:
            sys.stdout.write(HELP)
        return 0
    if len(argv) >= 2 and argv[1] == "completion":
        if len(argv) == 2 or argv[2] in ("-h", "--help"):
            sys.stdout.write(COMPLETION_HELP)
            return 0
        sys.stdout.write(completion(argv[2]))
        return 0

    hscale = 1.0
    vscale = 1.0
    padding = None
    encoding = "utf8-lossy"
    file_arg = None
    i = 1
    while i < len(argv):
        arg = argv[i]
        if arg in ("-h", "--help"):
            sys.stdout.write(HELP)
            return 0
        if arg == "--version":
            print(VERSION)
            return 0
        if arg in ("-H", "--horizontal-scale"):
            i += 1
            if i >= len(argv):
                die(f"error: a value is required for '{arg} <HSCALE>' but none was supplied", 2)
            hscale = parse_float(argv[i], "--horizontal-scale <HSCALE>")
        elif arg in ("-V", "--vertical-scale"):
            i += 1
            if i >= len(argv):
                die(f"error: a value is required for '{arg} <VSCALE>' but none was supplied", 2)
            vscale = parse_float(argv[i], "--vertical-scale <VSCALE>")
        elif arg == "--padding":
            i += 1
            if i >= len(argv):
                die("error: a value is required for '--padding <PADDING>' but none was supplied", 2)
            try:
                padding = int(argv[i])
            except ValueError:
                die(
                    f"error: invalid value '{argv[i]}' for '--padding <PADDING>': invalid digit found in string\n\n"
                    "For more information, try '--help'.",
                    2,
                )
        elif arg == "--encoding":
            i += 1
            if i >= len(argv):
                die("error: a value is required for '--encoding <ENCODING>' but none was supplied", 2)
            encoding = argv[i]
            if encoding not in ("utf8-lossy", "utf8"):
                die(
                    f"error: invalid value '{encoding}' for '--encoding <ENCODING>'\n"
                    "  [possible values: utf8-lossy, utf8]\n\n"
                    "For more information, try '--help'.",
                    2,
                )
        elif arg.startswith("-"):
            die(
                f"error: unexpected argument '{arg}' found\n\n"
                f"  tip: to pass '{arg}' as a value, use '-- {arg}'\n\n"
                "Usage: executable [OPTIONS] [FILE] [COMMAND]\n\n"
                "For more information, try '--help'.",
                2,
            )
        elif file_arg is None:
            file_arg = arg
        else:
            die(f"error: unexpected argument '{arg}' found", 2)
        i += 1

    text = read_input(file_arg, encoding)
    sys.stdout.write(render(text, hscale, vscale, padding))
    return 0


if __name__ == "__main__":
    raise SystemExit(main(sys.argv))
