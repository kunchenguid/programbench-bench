package main

import (
	"bytes"
	"encoding/json"
	"flag"
	"fmt"
	"go/ast"
	"go/format"
	"go/parser"
	"go/token"
	"io/fs"
	"os"
	"os/exec"
	"path/filepath"
	"regexp"
	"sort"
	"strings"
)

var defaultIgnores = []string{
	".Errorf(",
	"errors.New(",
	"errors.Unwrap(",
	"errors.Join(",
	".Wrap(",
	".Wrapf(",
	".WithMessage(",
	".WithMessagef(",
	".WithStack(",
}

type config struct {
	IgnoreSigs             []string `json:"ignoreSigs"`
	ExtraIgnoreSigs        []string `json:"extraIgnoreSigs"`
	IgnoreSigRegexps       []string `json:"ignoreSigRegexps"`
	IgnorePackageGlobs     []string `json:"ignorePackageGlobs"`
	IgnoreInterfaceRegexps []string `json:"ignoreInterfaceRegexps"`
	ReportInternalErrors   bool     `json:"reportInternalErrors"`
}

type pkgInfo struct {
	ImportPath string
	Dir        string
	GoFiles    []string
	TestGoFiles []string
	Analyze   bool
}

type sigInfo struct {
	Sig     string
	Pkg     string
	RecvPkg string
	Recv    string
}

type finding struct {
	Package string
	Pos     string
	File    string
	Line    int
	Column  int
	Message string
}

type flags struct {
	jsonOut bool
	flagsOut bool
	version string
	test bool
	context int
}

func main() {
	f := parseFlags()
	if f.flagsOut {
		printFlags()
		return
	}
	if f.version != "" {
		if f.version == "full" {
			fmt.Println("wrapcheck unknown")
			return
		}
		fmt.Fprintf(os.Stderr, "wrapcheck: unsupported flag value: -V=%s (use -V=full)\n", f.version)
		os.Exit(1)
	}
	args := flag.Args()
	if len(args) == 0 {
		usage()
		os.Exit(1)
	}
	pkgs, err := goList(args, f.test)
	if err != nil {
		fmt.Fprintf(os.Stderr, "wrapcheck: err: %v\n", err)
		os.Exit(1)
	}
	cfg := readConfig()
	findings := analyze(pkgs, cfg, f.test)
	if f.jsonOut {
		printJSON(findings)
		return
	}
	for _, d := range findings {
		fmt.Printf("%s: %s\n", d.Pos, d.Message)
	}
	if len(findings) > 0 {
		os.Exit(3)
	}
}

func parseFlags() flags {
	var f flags
	flag.BoolVar(&f.flagsOut, "flags", false, "print analyzer flags in JSON")
	flag.BoolVar(&f.jsonOut, "json", false, "emit JSON output")
	flag.Bool("all", false, "no effect (deprecated)")
	flag.IntVar(&f.context, "c", -1, "display offending line with this many lines of context")
	flag.Bool("diff", false, "with -fix, don't update the files, but print a unified diff")
	flag.Bool("fix", false, "apply all suggested fixes")
	flag.String("cpuprofile", "", "write CPU profile to this file")
	flag.String("memprofile", "", "write memory profile to this file")
	flag.String("trace", "", "write trace log to this file")
	flag.String("debug", "", "debug flags, any subset of \"fpstv\"")
	flag.Bool("source", false, "no effect (deprecated)")
	flag.String("tags", "", "no effect (deprecated)")
	flag.Bool("v", false, "no effect (deprecated)")
	flag.BoolVar(&f.test, "test", true, "indicates whether test files should be analyzed, too")
	flag.Var((*versionFlag)(&f.version), "V", "print version and exit")
	flag.Usage = usage
	flag.Parse()
	return f
}

type versionFlag string

func (v *versionFlag) Set(s string) error {
	*v = versionFlag(s)
	return nil
}

func (v *versionFlag) String() string { return string(*v) }

func (v *versionFlag) IsBoolFlag() bool { return true }

func usage() {
	fmt.Fprintln(os.Stderr, "wrapcheck: Checks that errors returned from external packages are wrapped")
	fmt.Fprintln(os.Stderr)
	fmt.Fprintln(os.Stderr, "Usage: wrapcheck [-flag] [package]")
	fmt.Fprintln(os.Stderr)
	fmt.Fprintln(os.Stderr)
	fmt.Fprintln(os.Stderr, "Flags:")
	flag.PrintDefaults()
}

func printFlags() {
	type flagInfo struct {
		Name  string
		Bool  bool
		Usage string
	}
	items := []flagInfo{
		{"V", true, "print version and exit"},
		{"all", true, "no effect (deprecated)"},
		{"c", false, "display offending line with this many lines of context"},
		{"diff", true, "with -fix, don't update the files, but print a unified diff"},
		{"flags", true, "print analyzer flags in JSON"},
		{"json", true, "emit JSON output"},
		{"source", true, "no effect (deprecated)"},
		{"tags", false, "no effect (deprecated)"},
		{"test", true, "indicates whether test files should be analyzed, too"},
		{"v", true, "no effect (deprecated)"},
	}
	b, _ := json.MarshalIndent(items, "", "\t")
	fmt.Println(string(b))
}

func goList(args []string, includeTests bool) ([]pkgInfo, error) {
	targets, err := runGoList(append([]string{"list", "-json"}, args...))
	if err != nil {
		return nil, err
	}
	targetSet := map[string]bool{}
	for _, p := range targets {
		targetSet[p.ImportPath] = true
	}
	deps, err := runGoList(append([]string{"list", "-deps", "-json"}, args...))
	if err != nil {
		return nil, err
	}
	for i := range deps {
		deps[i].Analyze = targetSet[deps[i].ImportPath]
	}
	return deps, nil
}

func runGoList(cmdArgs []string) ([]pkgInfo, error) {
	cmd := exec.Command("go", cmdArgs...)
	var out, er bytes.Buffer
	cmd.Stdout = &out
	cmd.Stderr = &er
	if err := cmd.Run(); err != nil {
		return nil, fmt.Errorf("%v: stderr: %s", err, strings.TrimSpace(er.String()))
	}
	dec := json.NewDecoder(&out)
	var pkgs []pkgInfo
	for dec.More() {
		var p pkgInfo
		if err := dec.Decode(&p); err != nil {
			return nil, err
		}
		pkgs = append(pkgs, p)
	}
	return pkgs, nil
}

func readConfig() config {
	var cfg config
	for _, path := range []string{".wrapcheck.yaml", filepath.Join(os.Getenv("HOME"), ".wrapcheck.yaml")} {
		b, err := os.ReadFile(path)
		if err == nil {
			parseYAMLish(string(b), &cfg)
			return cfg
		}
	}
	return cfg
}

func parseYAMLish(s string, cfg *config) {
	var key string
	for _, raw := range strings.Split(s, "\n") {
		line := strings.TrimSpace(strings.Split(raw, "#")[0])
		if line == "" {
			continue
		}
		if strings.HasSuffix(line, ":") {
			key = strings.TrimSuffix(line, ":")
			continue
		}
		if strings.Contains(line, ":") && !strings.HasPrefix(line, "-") {
			parts := strings.SplitN(line, ":", 2)
			key = strings.TrimSpace(parts[0])
			val := strings.TrimSpace(parts[1])
			if key == "reportInternalErrors" {
				cfg.ReportInternalErrors = val == "true"
			}
			continue
		}
		if strings.HasPrefix(line, "-") {
			val := strings.Trim(strings.TrimSpace(strings.TrimPrefix(line, "-")), `"'`)
			switch key {
			case "ignoreSigs":
				cfg.IgnoreSigs = append(cfg.IgnoreSigs, val)
			case "extraIgnoreSigs":
				cfg.ExtraIgnoreSigs = append(cfg.ExtraIgnoreSigs, val)
			case "ignoreSigRegexps":
				cfg.IgnoreSigRegexps = append(cfg.IgnoreSigRegexps, val)
			case "ignorePackageGlobs":
				cfg.IgnorePackageGlobs = append(cfg.IgnorePackageGlobs, val)
			case "ignoreInterfaceRegexps":
				cfg.IgnoreInterfaceRegexps = append(cfg.IgnoreInterfaceRegexps, val)
			}
		}
	}
}

func analyze(pkgs []pkgInfo, cfg config, includeTests bool) []finding {
	allSigs := map[string]sigInfo{}
	for _, p := range pkgs {
		for k, v := range collectPackageSigs(p, includeTests) {
			allSigs[k] = v
		}
	}
	var out []finding
	for _, p := range pkgs {
		if p.Analyze {
			out = append(out, analyzePackage(p, allSigs, cfg, includeTests)...)
		}
	}
	sort.Slice(out, func(i, j int) bool {
		if out[i].File != out[j].File {
			return out[i].File < out[j].File
		}
		if out[i].Line != out[j].Line {
			return out[i].Line < out[j].Line
		}
		return out[i].Column < out[j].Column
	})
	return out
}

func collectPackageSigs(p pkgInfo, includeTests bool) map[string]sigInfo {
	res := map[string]sigInfo{}
	files := append([]string{}, p.GoFiles...)
	if includeTests {
		files = append(files, p.TestGoFiles...)
	}
	fset := token.NewFileSet()
	for _, name := range files {
		path := filepath.Join(p.Dir, name)
		file, err := parser.ParseFile(fset, path, nil, 0)
		if err != nil {
			continue
		}
		for _, d := range file.Decls {
			fn, ok := d.(*ast.FuncDecl)
			if !ok || fn.Type.Results == nil || !returnsError(fn.Type.Results) {
				continue
			}
			if fn.Recv == nil {
				sig := "func " + p.ImportPath + "." + fn.Name.Name + signatureSuffix(fn.Type, p.ImportPath)
				res[p.ImportPath+"."+fn.Name.Name] = sigInfo{Sig: sig, Pkg: p.ImportPath}
			} else if len(fn.Recv.List) > 0 {
				rt := recvType(fn.Recv.List[0].Type)
				if rt != "" {
					sig := "func (" + p.ImportPath + "." + rt + ")." + fn.Name.Name + signatureSuffix(fn.Type, p.ImportPath)
					res[p.ImportPath+"."+rt+"."+fn.Name.Name] = sigInfo{Sig: sig, Pkg: p.ImportPath, RecvPkg: p.ImportPath, Recv: rt}
				}
			}
		}
	}
	return res
}

func analyzePackage(p pkgInfo, sigs map[string]sigInfo, cfg config, includeTests bool) []finding {
	var findings []finding
	files := append([]string{}, p.GoFiles...)
	if includeTests {
		files = append(files, p.TestGoFiles...)
	}
	for _, name := range files {
		path := filepath.Join(p.Dir, name)
		fset := token.NewFileSet()
		file, err := parser.ParseFile(fset, path, nil, parser.ParseComments)
		if err != nil {
			continue
		}
		imports := importsOf(file)
		for _, d := range file.Decls {
			fn, ok := d.(*ast.FuncDecl)
			if !ok || fn.Body == nil {
				continue
			}
			env := map[string]sigInfo{}
			types := map[string]string{}
			ast.Inspect(fn.Body, func(n ast.Node) bool {
				switch x := n.(type) {
				case *ast.ValueSpec:
					for i, nm := range x.Names {
						if x.Type != nil {
							if t := typeName(x.Type, imports); t != "" {
								types[nm.Name] = t
							}
						}
							if i < len(x.Values) {
								if si, ok := callSig(x.Values[i], imports, types, sigs); ok {
									env[nm.Name] = si
								} else if t := exprType(x.Values[i], imports); t != "" {
									types[nm.Name] = t
								}
							}
						}
					case *ast.AssignStmt:
						if len(x.Rhs) == 1 {
						if si, ok := callSig(x.Rhs[0], imports, types, sigs); ok {
							for _, lhs := range x.Lhs {
								if id, ok := lhs.(*ast.Ident); ok && id.Name != "_" {
										env[id.Name] = si
									}
								}
							} else if t := exprType(x.Rhs[0], imports); t != "" {
								for _, lhs := range x.Lhs {
									if id, ok := lhs.(*ast.Ident); ok && id.Name != "_" {
										types[id.Name] = t
									}
								}
							}
						} else {
							for i, lhs := range x.Lhs {
								id, ok := lhs.(*ast.Ident)
								if !ok || i >= len(x.Rhs) {
								continue
								}
								if si, ok := callSig(x.Rhs[i], imports, types, sigs); ok {
									env[id.Name] = si
								} else if t := exprType(x.Rhs[i], imports); t != "" {
									types[id.Name] = t
								}
							}
						}
				case *ast.ReturnStmt:
					for _, e := range x.Results {
						if si, ok := callSig(e, imports, types, sigs); ok {
							addFinding(&findings, p, fset.Position(e.Pos()), si, cfg)
						} else if id, ok := e.(*ast.Ident); ok {
							if si, ok := env[id.Name]; ok {
								addFinding(&findings, p, fset.Position(e.Pos()), si, cfg)
							}
						}
					}
				}
				return true
			})
		}
	}
	return findings
}

func addFinding(out *[]finding, p pkgInfo, pos token.Position, si sigInfo, cfg config) {
	if !cfg.ReportInternalErrors && si.Pkg == p.ImportPath {
		return
	}
	for _, glob := range cfg.IgnorePackageGlobs {
		if ok, _ := filepath.Match(glob, si.Pkg); ok {
			return
		}
	}
	for _, ign := range ignoreList(cfg) {
		if strings.Contains(si.Sig+"(", ign) || strings.Contains(si.Sig, strings.TrimSuffix(ign, "(")) {
			return
		}
	}
	for _, pat := range cfg.IgnoreSigRegexps {
		if re, err := regexp.Compile(pat); err == nil && re.MatchString(si.Sig+"(") {
			return
		}
	}
	*out = append(*out, finding{
		Package: p.ImportPath,
		Pos:     fmt.Sprintf("%s:%d:%d", pos.Filename, pos.Line, pos.Column),
		File:    pos.Filename,
		Line:    pos.Line,
		Column:  pos.Column,
		Message: "error returned from external package is unwrapped: sig: " + si.Sig,
	})
}

func ignoreList(cfg config) []string {
	if len(cfg.IgnoreSigs) > 0 {
		return append(append([]string{}, cfg.IgnoreSigs...), cfg.ExtraIgnoreSigs...)
	}
	return append(append([]string{}, defaultIgnores...), cfg.ExtraIgnoreSigs...)
}

func callSig(e ast.Expr, imports map[string]string, types map[string]string, sigs map[string]sigInfo) (sigInfo, bool) {
	call, ok := e.(*ast.CallExpr)
	if !ok {
		return sigInfo{}, false
	}
	switch fun := call.Fun.(type) {
	case *ast.SelectorExpr:
		if id, ok := fun.X.(*ast.Ident); ok {
			if pkg, ok := imports[id.Name]; ok {
				si, ok := sigs[pkg+"."+fun.Sel.Name]
				return si, ok
			}
			if typ, ok := types[id.Name]; ok {
				if si, ok := sigs[typ+"."+fun.Sel.Name]; ok {
					return si, true
				}
			}
		}
		if typ := exprType(fun.X, imports); typ != "" {
			if si, ok := sigs[typ+"."+fun.Sel.Name]; ok {
				return si, true
			}
		}
	}
	return sigInfo{}, false
}

func exprType(e ast.Expr, imports map[string]string) string {
	switch x := e.(type) {
	case *ast.CompositeLit:
		return typeName(x.Type, imports)
	case *ast.UnaryExpr:
		if x.Op == token.AND {
			return exprType(x.X, imports)
		}
	}
	return ""
}

func importsOf(f *ast.File) map[string]string {
	m := map[string]string{}
	for _, im := range f.Imports {
		path := strings.Trim(im.Path.Value, `"`)
		name := filepath.Base(path)
		if im.Name != nil && im.Name.Name != "." && im.Name.Name != "_" {
			name = im.Name.Name
		}
		m[name] = path
	}
	return m
}

func typeName(e ast.Expr, imports map[string]string) string {
	switch t := e.(type) {
	case *ast.SelectorExpr:
		if id, ok := t.X.(*ast.Ident); ok {
			if pkg, ok := imports[id.Name]; ok {
				return pkg + "." + t.Sel.Name
			}
		}
	case *ast.StarExpr:
		return typeName(t.X, imports)
	}
	return ""
}

func recvType(e ast.Expr) string {
	switch t := e.(type) {
	case *ast.Ident:
		return t.Name
	case *ast.StarExpr:
		return recvType(t.X)
	}
	return ""
}

func returnsError(fl *ast.FieldList) bool {
	for _, f := range fl.List {
		switch t := f.Type.(type) {
		case *ast.Ident:
			if t.Name == "error" {
				return true
			}
		}
	}
	return false
}

func signatureSuffix(ft *ast.FuncType, pkg string) string {
	ps := fieldList(ft.Params, pkg)
	rs := fieldList(ft.Results, pkg)
	if len(rs) == 1 {
		return "(" + strings.Join(ps, ", ") + ") " + rs[0]
	}
	return "(" + strings.Join(ps, ", ") + ") (" + strings.Join(rs, ", ") + ")"
}

func fieldList(fl *ast.FieldList, pkg string) []string {
	if fl == nil {
		return nil
	}
	var out []string
	for _, f := range fl.List {
		typ := exprString(f.Type, pkg)
		if len(f.Names) == 0 {
			out = append(out, typ)
			continue
		}
		for _, n := range f.Names {
			out = append(out, n.Name+" "+typ)
		}
	}
	return out
}

func exprString(e ast.Expr, pkg string) string {
	switch t := e.(type) {
	case *ast.Ident:
		if isBuiltin(t.Name) {
			return t.Name
		}
		return pkg + "." + t.Name
	case *ast.StarExpr:
		return "*" + exprString(t.X, pkg)
	case *ast.ArrayType:
		return "[]" + exprString(t.Elt, pkg)
	case *ast.SelectorExpr:
		var b bytes.Buffer
		_ = format.Node(&b, token.NewFileSet(), t)
		return b.String()
	case *ast.Ellipsis:
		return "..." + exprString(t.Elt, pkg)
	default:
		var b bytes.Buffer
		_ = format.Node(&b, token.NewFileSet(), e)
		return b.String()
	}
}

func isBuiltin(s string) bool {
	switch s {
	case "error", "string", "bool", "byte", "rune", "any", "int", "int8", "int16", "int32", "int64", "uint", "uint8", "uint16", "uint32", "uint64", "uintptr", "float32", "float64", "complex64", "complex128":
		return true
	}
	return false
}

func printJSON(findings []finding) {
	type jd struct {
		Posn    string `json:"posn"`
		Message string `json:"message"`
	}
	res := map[string]map[string][]jd{}
	for _, f := range findings {
		if _, ok := res[f.Package]; !ok {
			res[f.Package] = map[string][]jd{"wrapcheck": nil}
		}
		res[f.Package]["wrapcheck"] = append(res[f.Package]["wrapcheck"], jd{Posn: f.Pos, Message: f.Message})
	}
	b, _ := json.MarshalIndent(res, "", "\t")
	if len(res) == 0 {
		fmt.Println("{}")
		return
	}
	fmt.Println(string(b))
}

func init() {
	_ = fs.ValidPath
}
