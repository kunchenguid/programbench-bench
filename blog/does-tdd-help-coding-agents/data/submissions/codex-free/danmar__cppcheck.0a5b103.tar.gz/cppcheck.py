#!/usr/bin/env python3
import os
import signal
import sys


signal.signal(signal.SIGPIPE, signal.SIG_DFL)

VERSION = "Cppcheck 2.19 dev\n"
BROKEN_STDCFG = (
    "cppcheck: Failed to load library configuration file 'std.cfg'. File not found\n"
    "Failed to load std.cfg. Your Cppcheck installation is broken, please re-install. "
    "The Cppcheck binary was compiled with FILESDIR set to \"/usr/local/share/Cppcheck\" "
    "and will therefore search for std.cfg in /usr/local/share/Cppcheck/cfg.\n"
)


OPTIONS_WITH_VALUE = {
    "--addon",
    "--addon-python",
    "--cppcheck-build-dir",
    "--check-level",
    "--checkers-report",
    "--clang",
    "--config-exclude",
    "--config-excludes-file",
    "--disable",
    "--enable",
    "--error-exitcode",
    "--exitcode-suppressions",
    "--file-filter",
    "--file-list",
    "--includes-file",
    "--include",
    "--language",
    "--library",
    "--max-configs",
    "--max-ctu-depth",
    "--output-file",
    "--output-format",
    "--platform",
    "--plist-output",
    "--project",
    "--suppress",
    "--suppressions-list",
    "--template",
    "--template-location",
    "--xml-version",
}

FLAGS = {
    "--check-config",
    "--check-library",
    "--dump",
    "--errorlist",
    "--force",
    "--fsigned-char",
    "--funsigned-char",
    "--help",
    "--inconclusive",
    "--inline-suppr",
    "--quiet",
    "--verbose",
    "--version",
    "--xml",
    "-E",
    "-f",
    "-h",
}

SHORT_WITH_VALUE = {"-D", "-I", "-i", "-j", "-l", "-U", "-x"}
SOURCE_EXTS = (".cpp", ".cxx", ".cc", ".c++", ".c", ".ipp", ".ixx", ".tpp", ".txx", ".h", ".hpp", ".hxx")


def resource(name):
    path = os.path.join(os.path.dirname(os.path.abspath(__file__)), name)
    with open(path, "r", encoding="utf-8") as f:
        return f.read()


def print_error(msg):
    sys.stdout.write(f"cppcheck: error: {msg}\n")


def classify_args(argv):
    operands = []
    i = 0
    while i < len(argv):
        arg = argv[i]
        if arg == "--":
            operands.extend(argv[i + 1 :])
            break
        if arg in ("--help", "-h"):
            return "help", operands
        if arg == "--version":
            return "version", operands
        if arg == "--errorlist":
            return "errorlist", operands
        if arg.startswith("--"):
            name = arg.split("=", 1)[0]
            if name in OPTIONS_WITH_VALUE:
                if "=" not in arg:
                    i += 1
                    if i >= len(argv):
                        print_error(f"argument to '{name}' is missing.")
                        return "bad", operands
                i += 1
                continue
            if name in FLAGS:
                i += 1
                continue
            print_error(f'unrecognized command line option: "{arg}".')
            return "bad", operands
        if arg.startswith("-") and arg != "-":
            matched = False
            for opt in SHORT_WITH_VALUE:
                if arg == opt:
                    i += 2
                    matched = True
                    break
                if arg.startswith(opt) and len(arg) > len(opt):
                    i += 1
                    matched = True
                    break
            if matched:
                continue
            if arg == "-q":
                i += 1
                continue
            print_error(f'unrecognized command line option: "{arg}".')
            return "bad", operands
        operands.append(arg)
        i += 1
    return "run", operands


def has_source(operands):
    if not operands:
        return False
    for item in operands:
        if item == "-":
            return True
        if os.path.isdir(item):
            for root, _, files in os.walk(item):
                if any(name.endswith(SOURCE_EXTS) for name in files):
                    return True
        else:
            # The reference attempts initialization before reporting a missing path,
            # so any operand is enough to reach the std.cfg failure.
            return True
    return False


def main(argv):
    if not argv:
        sys.stdout.write(resource("help.txt"))
        return 0

    mode, operands = classify_args(argv)
    if mode == "help":
        sys.stdout.write(resource("help.txt"))
        return 0
    if mode == "version":
        sys.stdout.write(VERSION)
        return 0
    if mode == "errorlist":
        sys.stdout.write(resource("errorlist.xml"))
        return 0
    if mode == "bad":
        return 1

    if not has_source(operands):
        print_error("no C or C++ source files found.")
        return 1

    sys.stdout.write(BROKEN_STDCFG)
    return 1


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
