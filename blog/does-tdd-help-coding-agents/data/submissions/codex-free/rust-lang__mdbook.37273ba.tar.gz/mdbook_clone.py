#!/usr/bin/env python3
import html
import os
import re
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path

VERSION = "mdbook v0.5.0-alpha.1"
COMMANDS = ["init", "build", "test", "clean", "completions", "watch", "serve", "help"]


HELP = {
    "top": """Creates a book from markdown files

Usage: executable [COMMAND]

Commands:
  init         Creates the boilerplate structure and files for a new book
  build        Builds a book from its markdown files
  test         Tests that a book's Rust code samples compile
  clean        Deletes a built book
  completions  Generate shell completions for your shell to stdout
  watch        Watches a book's files and rebuilds it on changes
  serve        Serves a book at http://localhost:3000, and rebuilds it on changes
  help         Print this message or the help of the given subcommand(s)

Options:
  -h, --help     Print help
  -V, --version  Print version

For more information about a specific command, try `mdbook <command> --help`
The source code for mdBook is available at: https://github.com/rust-lang/mdBook""",
    "init": """Creates the boilerplate structure and files for a new book

Usage: executable init [OPTIONS] [dir]

Arguments:
  [dir]  Directory to create the book in
         (Defaults to the current directory when omitted)

Options:
      --theme            Copies the default theme into your source folder
      --force            Skips confirmation prompts
      --title <title>    Sets the book title
      --ignore <ignore>  Creates a VCS ignore file (i.e. .gitignore) [possible values: none, git]
  -h, --help             Print help
  -V, --version          Print version""",
    "build": """Builds a book from its markdown files

Usage: executable build [OPTIONS] [dir]

Arguments:
  [dir]  Root directory for the book
         (Defaults to the current directory when omitted)

Options:
  -d, --dest-dir <dest-dir>  Output directory for the book
                             Relative paths are interpreted relative to the book's root directory.
                             If omitted, mdBook uses build.build-dir from book.toml or defaults to
                             `./book`.
  -o, --open                 Opens the compiled book in a web browser
  -h, --help                 Print help
  -V, --version              Print version""",
    "test": """Tests that a book's Rust code samples compile

Usage: executable test [OPTIONS] [dir]

Arguments:
  [dir]  Root directory for the book
         (Defaults to the current directory when omitted)

Options:
  -d, --dest-dir <dest-dir>  Output directory for the book
                             Relative paths are interpreted relative to the book's root directory.
                             If omitted, mdBook uses build.build-dir from book.toml or defaults to
                             `./book`.
  -c, --chapter <chapter>    
  -L, --library-path <dir>   A comma-separated list of directories to add to the crate search path
                             when building tests
  -h, --help                 Print help
  -V, --version              Print version""",
    "clean": """Deletes a built book

Usage: executable clean [OPTIONS] [dir]

Arguments:
  [dir]  Root directory for the book
         (Defaults to the current directory when omitted)

Options:
  -d, --dest-dir <dest-dir>  Output directory for the book
                             Relative paths are interpreted relative to the book's root directory.
                             If omitted, mdBook uses build.build-dir from book.toml or defaults to
                             `./book`.
  -h, --help                 Print help
  -V, --version              Print version""",
    "completions": """Generate shell completions for your shell to stdout

Usage: executable completions <SHELL>

Arguments:
  <SHELL>  the shell to generate completions for [possible values: bash, elvish, fish, powershell,
           zsh]

Options:
  -h, --help     Print help
  -V, --version  Print version""",
    "watch": """Watches a book's files and rebuilds it on changes

Usage: executable watch [OPTIONS] [dir]

Arguments:
  [dir]  Root directory for the book
         (Defaults to the current directory when omitted)

Options:
  -d, --dest-dir <dest-dir>  Output directory for the book
                             Relative paths are interpreted relative to the book's root directory.
                             If omitted, mdBook uses build.build-dir from book.toml or defaults to
                             `./book`.
  -o, --open                 Opens the compiled book in a web browser
      --watcher <watcher>    The filesystem watching technique [default: poll] [possible values:
                             poll, native]
  -h, --help                 Print help
  -V, --version              Print version""",
    "serve": """Serves a book at http://localhost:3000, and rebuilds it on changes

Usage: executable serve [OPTIONS] [dir]

Arguments:
  [dir]  Root directory for the book
         (Defaults to the current directory when omitted)

Options:
  -d, --dest-dir <dest-dir>  Output directory for the book
                             Relative paths are interpreted relative to the book's root directory.
                             If omitted, mdBook uses build.build-dir from book.toml or defaults to
                             `./book`.
  -n, --hostname <hostname>  Hostname to listen on for HTTP connections [default: localhost]
  -p, --port <port>          Port to use for HTTP connections [default: 3000]
  -o, --open                 Opens the compiled book in a web browser
      --watcher <watcher>    The filesystem watching technique [default: poll] [possible values:
                             poll, native]
  -h, --help                 Print help
  -V, --version              Print version""",
}


def eprint(msg):
    print(msg, file=sys.stderr)


def log(level, module, msg):
    eprint(f"2026-06-01 00:00:00 [{level}] ({module}): {msg}")


def fail(msg, code=101):
    log("ERROR", "mdbook_core::utils", f"Error: {msg}")
    sys.exit(code)


def print_help(name="top"):
    print(HELP[name])


def parse_options(args, specs):
    opts, pos = {}, []
    i = 0
    while i < len(args):
        a = args[i]
        if a == "--":
            pos.extend(args[i + 1 :])
            break
        if a in ("-h", "--help"):
            opts["help"] = True
        elif a in ("-V", "--version"):
            opts["version"] = True
        elif a in specs:
            takes = specs[a]
            key = a.lstrip("-").replace("-", "_")
            if takes:
                if i + 1 >= len(args):
                    eprint(f"error: a value is required for '{a} <{key}>'")
                    sys.exit(2)
                opts[key] = args[i + 1]
                i += 1
            else:
                opts[key] = True
        elif a.startswith("-"):
            eprint(f"error: unexpected argument '{a}' found\n")
            eprint(f"  tip: to pass '{a}' as a value, use '-- {a}'\n")
            sys.exit(2)
        else:
            pos.append(a)
        i += 1
    return opts, pos


def read_config(root):
    cfg = {"title": None, "src": "src", "build_dir": "book", "language": "en"}
    p = root / "book.toml"
    section = ""
    if not p.exists():
        return cfg
    for raw in p.read_text(errors="replace").splitlines():
        line = raw.split("#", 1)[0].strip()
        if not line:
            continue
        m = re.match(r"\[([^\]]+)\]", line)
        if m:
            section = m.group(1)
            continue
        if "=" not in line:
            continue
        k, v = [x.strip() for x in line.split("=", 1)]
        if v.startswith('"') and v.endswith('"'):
            v = v[1:-1]
        if section == "book":
            if k == "title":
                cfg["title"] = v
            elif k == "src":
                cfg["src"] = v
            elif k == "language":
                cfg["language"] = v
        elif section == "build" and k == "build-dir":
            cfg["build_dir"] = v
    return cfg


def slug_to_html(path):
    s = str(path).replace("\\", "/")
    if s in ("README.md", "./README.md"):
        return "index.html"
    if s.endswith(".md"):
        s = s[:-3] + ".html"
    return s.lstrip("./")


def parse_summary(src):
    p = src / "SUMMARY.md"
    if not p.exists():
        fail(f"Couldn't open SUMMARY.md in \"{src}\" directory\n\tCaused By: No such file or directory (os error 2)")
    chapters = []
    part = None
    for line in p.read_text(errors="replace").splitlines():
        stripped = line.strip()
        if not stripped:
            continue
        if stripped.startswith("#") and not stripped.lower().startswith("# summary"):
            part = stripped.lstrip("#").strip()
            continue
        m = re.search(r"\[([^\]]+)\]\(([^)]*)\)", stripped)
        if not m or m.group(2).strip() == "":
            continue
        indent = len(line) - len(line.lstrip(" "))
        chapters.append({"title": m.group(1), "path": m.group(2), "level": indent // 2, "part": part})
    return chapters


def inline_md(s):
    s = html.escape(s)
    s = re.sub(r"`([^`]+)`", r"<code>\1</code>", s)
    s = re.sub(r"\*\*([^*]+)\*\*", r"<strong>\1</strong>", s)
    s = re.sub(r"\*([^*]+)\*", r"<em>\1</em>", s)

    def link(m):
        href = m.group(2)
        if href.endswith(".md") or href == "README.md":
            href = slug_to_html(href)
        return f'<a href="{html.escape(href)}">{m.group(1)}</a>'

    s = re.sub(r"\[([^\]]+)\]\(([^)]+)\)", link, s)
    return s


def markdown_to_html(text):
    out, para, in_code, code_lang, list_open = [], [], False, "", False

    def close_para():
        nonlocal para
        if para:
            out.append("<p>" + inline_md(" ".join(para)) + "</p>")
            para = []

    def close_list():
        nonlocal list_open
        if list_open:
            out.append("</ul>")
            list_open = False

    for raw in text.splitlines():
        line = raw.rstrip("\n")
        if line.strip().startswith("```"):
            close_para()
            close_list()
            if not in_code:
                in_code = True
                code_lang = line.strip()[3:].strip().split(",", 1)[0]
                cls = f' class="language-{html.escape(code_lang)}"' if code_lang else ""
                out.append(f"<pre><code{cls}>")
            else:
                out.append("</code></pre>")
                in_code = False
            continue
        if in_code:
            out.append(html.escape(line))
            continue
        if not line.strip():
            close_para()
            close_list()
            continue
        m = re.match(r"^(#{1,6})\s+(.*)$", line)
        if m:
            close_para()
            close_list()
            lvl = len(m.group(1))
            title = inline_md(m.group(2).strip())
            ident = re.sub(r"[^a-z0-9]+", "-", html.unescape(re.sub(r"<[^>]+>", "", title)).lower()).strip("-")
            out.append(f'<h{lvl} id="{ident}">{title}</h{lvl}>')
            continue
        m = re.match(r"^\s*[-*+]\s+(.*)$", line)
        if m:
            close_para()
            if not list_open:
                out.append("<ul>")
                list_open = True
            out.append(f"<li>{inline_md(m.group(1).strip())}</li>")
            continue
        para.append(line.strip())
    close_para()
    close_list()
    if in_code:
        out.append("</code></pre>")
    return "\n".join(out)


def page_template(book_title, page_title, body, toc, prev_href=None, next_href=None, lang="en"):
    title = page_title if not book_title or page_title == book_title else f"{page_title} - {book_title}"
    nav = []
    if prev_href:
        nav.append(f'<a class="nav-chapters previous" href="{prev_href}">Previous</a>')
    if next_href:
        nav.append(f'<a class="nav-chapters next" href="{next_href}">Next</a>')
    return f"""<!DOCTYPE HTML>
<html lang="{html.escape(lang)}" class="light sidebar-visible" dir="ltr">
<head>
    <meta charset="UTF-8">
    <title>{html.escape(title)}</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="css/general.css">
    <link rel="stylesheet" href="css/chrome.css">
</head>
<body>
<nav id="sidebar" class="sidebar">{toc}</nav>
<main class="content">
{body}
</main>
<nav class="nav-wrapper">{" ".join(nav)}</nav>
<script src="book.js"></script>
</body>
</html>
"""


def make_toc(chapters):
    parts_seen = set()
    items = ['<ol class="chapter">']
    for idx, ch in enumerate(chapters, 1):
        if ch.get("part") and ch["part"] not in parts_seen:
            parts_seen.add(ch["part"])
            items.append(f'<li class="part-title">{html.escape(ch["part"])}</li>')
        href = slug_to_html(ch["path"])
        items.append(f'<li class="chapter-item"><a href="{html.escape(href)}">{idx}. {html.escape(ch["title"])}</a></li>')
    items.append("</ol>")
    return "".join(items)


def ensure_assets(dest):
    (dest / "css").mkdir(parents=True, exist_ok=True)
    css = """body{margin:0;font-family:Arial,Helvetica,sans-serif;line-height:1.55;color:#222;background:#fff}.sidebar{position:fixed;left:0;top:0;bottom:0;width:260px;overflow:auto;background:#f7f7f7;border-right:1px solid #ddd;padding:1rem}.content{max-width:820px;margin-left:300px;padding:2rem}pre{background:#f3f3f3;padding:1rem;overflow:auto}code{font-family:monospace}.nav-wrapper{margin-left:300px;padding:1rem 2rem}.nav-chapters.next{float:right}@media(max-width:800px){.sidebar{position:static;width:auto}.content,.nav-wrapper{margin-left:0}}"""
    for name in ["general.css", "chrome.css", "print.css", "variables.css"]:
        (dest / "css" / name).write_text(css)
    for name, content in {
        ".nojekyll": "",
        "book.js": "",
        "toc.js": "",
        "searchindex.js": "Object.assign(window, {search: {}});",
        "searcher.js": "",
        "highlight.js": "",
        "clipboard.min.js": "",
        "elasticlunr.min.js": "",
        "mark.min.js": "",
        "highlight.css": "",
        "tomorrow-night.css": "",
        "ayu-highlight.css": "",
        "favicon.svg": '<svg xmlns="http://www.w3.org/2000/svg"/>',
        "favicon.png": "",
    }.items():
        mode = "wb" if name.endswith(".png") else "w"
        with open(dest / name, mode) as f:
            f.write(content.encode() if mode == "wb" else content)


def build_book(args, quiet=False):
    opts, pos = parse_options(args, {"-d": True, "--dest-dir": True, "-o": False, "--open": False})
    if opts.get("help"):
        print_help("build")
        return
    if opts.get("version"):
        print(VERSION)
        return
    root = Path(pos[0] if pos else ".").resolve()
    cfg = read_config(root)
    src = root / cfg["src"]
    chapters = parse_summary(src)
    dest = Path(opts.get("d") or opts.get("dest_dir") or cfg["build_dir"])
    if not dest.is_absolute():
        dest = root / dest
    if dest.exists():
        shutil.rmtree(dest)
    dest.mkdir(parents=True)
    ensure_assets(dest)
    toc = make_toc(chapters)
    book_title = cfg["title"] or ""
    hrefs = [slug_to_html(c["path"]) for c in chapters]
    for i, ch in enumerate(chapters):
        md_path = src / ch["path"]
        if not md_path.exists():
            continue
        content = markdown_to_html(md_path.read_text(errors="replace"))
        body = f'<div id="content" class="content-inner">\n{content}\n</div>'
        out = dest / hrefs[i]
        out.parent.mkdir(parents=True, exist_ok=True)
        prev_href = hrefs[i - 1] if i > 0 else None
        next_href = hrefs[i + 1] if i + 1 < len(hrefs) else None
        out.write_text(page_template(book_title, ch["title"], body, toc, prev_href, next_href, cfg["language"]))
        if i == 0 and out.name != "index.html" and not (dest / "index.html").exists():
            (dest / "index.html").write_text(out.read_text())
    for path in src.rglob("*"):
        if path.is_file() and path.suffix.lower() != ".md":
            rel = path.relative_to(src)
            target = dest / rel
            target.parent.mkdir(parents=True, exist_ok=True)
            shutil.copyfile(path, target)
    (dest / "toc.html").write_text(page_template(book_title, "Table of Contents", toc, toc, lang=cfg["language"]))
    combined = "\n".join(markdown_to_html((src / c["path"]).read_text(errors="replace")) for c in chapters if (src / c["path"]).exists())
    (dest / "print.html").write_text(page_template(book_title, book_title or "Print", combined, toc, lang=cfg["language"]))
    (dest / "404.html").write_text(page_template(book_title, "Page not found", "<h1>Page not found</h1>", toc, lang=cfg["language"]))
    if not quiet:
        log("INFO", "mdbook_driver::mdbook", "Book building has started")
        log("INFO", "mdbook_driver::mdbook", "Running the html backend")
        log("INFO", "mdbook_html::html_handlebars::hbs_renderer", f"HTML book written to `{dest}`")


def cmd_init(args):
    opts, pos = parse_options(args, {"--theme": False, "--force": False, "--title": True, "--ignore": True})
    if opts.get("help"):
        print_help("init")
        return
    if opts.get("version"):
        print(VERSION)
        return
    ignore = opts.get("ignore")
    if ignore and ignore not in ("none", "git"):
        eprint("error: invalid value for '--ignore <ignore>'")
        sys.exit(2)
    title = opts.get("title")
    if not opts.get("force") and ignore is None:
        print("\nDo you want a .gitignore to be created? (y/n)")
        ans = sys.stdin.readline().strip().lower()
        ignore = "git" if ans.startswith("y") else "none"
    if not opts.get("force") and title is None:
        print("What title would you like to give the book? ")
        title = sys.stdin.readline().strip() or None
    root = Path(pos[0] if pos else ".")
    src = root / "src"
    src.mkdir(parents=True, exist_ok=True)
    lines = ['[book]', 'authors = []', 'language = "en"', 'src = "src"']
    if title:
        lines.append(f'title = "{title}"')
    (root / "book.toml").write_text("\n".join(lines) + "\n")
    (src / "chapter_1.md").write_text("# Chapter 1\n")
    (src / "SUMMARY.md").write_text("# Summary\n\n- [Chapter 1](./chapter_1.md)\n")
    if ignore == "git":
        (root / ".gitignore").write_text("book\n")
    if opts.get("theme"):
        (src / "theme").mkdir(exist_ok=True)
    log("INFO", "mdbook_driver::init", "Creating a new book with stub content")
    print("\nAll done, no errors...")


def cmd_clean(args):
    opts, pos = parse_options(args, {"-d": True, "--dest-dir": True})
    if opts.get("help"):
        print_help("clean")
        return
    if opts.get("version"):
        print(VERSION)
        return
    root = Path(pos[0] if pos else ".").resolve()
    cfg = read_config(root)
    dest = Path(opts.get("d") or opts.get("dest_dir") or cfg["build_dir"])
    if not dest.is_absolute():
        dest = root / dest
    if dest.exists():
        shutil.rmtree(dest)


def extract_rust_blocks(text):
    blocks, in_code, lang, cur = [], False, "", []
    for line in text.splitlines():
        if line.strip().startswith("```"):
            if not in_code:
                in_code = True
                lang = line.strip()[3:].strip()
                cur = []
            else:
                if lang.startswith("rust") or lang in ("", "should_panic", "ignore", "no_run"):
                    blocks.append("\n".join(cur))
                in_code = False
            continue
        if in_code:
            cur.append(line)
    return blocks


def cmd_test(args):
    opts, pos = parse_options(args, {"-d": True, "--dest-dir": True, "-c": True, "--chapter": True, "-L": True, "--library-path": True})
    if opts.get("help"):
        print_help("test")
        return
    if opts.get("version"):
        print(VERSION)
        return
    root = Path(pos[0] if pos else ".").resolve()
    cfg = read_config(root)
    src = root / cfg["src"]
    chapters = parse_summary(src)
    blocks = []
    only = opts.get("c") or opts.get("chapter")
    for ch in chapters:
        if only and only not in ch["title"] and only not in ch["path"]:
            continue
        p = src / ch["path"]
        if p.exists():
            blocks.extend(extract_rust_blocks(p.read_text(errors="replace")))
    for idx, code in enumerate(blocks):
        with tempfile.TemporaryDirectory() as td:
            f = Path(td) / "test.rs"
            body = code if "fn main" in code or "#[test]" in code else f"fn main() {{\n{code}\n}}\n"
            f.write_text(body)
            cmd = ["rustc", str(f), "-o", str(Path(td) / "out")]
            if opts.get("L") or opts.get("library_path"):
                for d in (opts.get("L") or opts.get("library_path")).split(","):
                    cmd += ["-L", d]
            res = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
            if res.returncode != 0:
                sys.stderr.write(res.stderr)
                sys.exit(res.returncode)


def cmd_completions(args):
    if not args or args[0] in ("-h", "--help"):
        print_help("completions")
        return
    if args[0] in ("-V", "--version"):
        print(VERSION)
        return
    shell = args[0]
    valid = ["bash", "elvish", "fish", "powershell", "zsh"]
    if shell not in valid:
        eprint(f"error: invalid value '{shell}' for '<SHELL>'")
        eprint("  [possible values: bash, elvish, fish, powershell, zsh]\n")
        eprint("For more information, try '--help'.")
        sys.exit(2)
    if shell == "bash":
        print("_mdbook() {\n    COMPREPLY=( $(compgen -W \"-h -V --help --version init build test clean completions watch serve help\" -- \"${COMP_WORDS[COMP_CWORD]}\") )\n}\ncomplete -F _mdbook mdbook")
    else:
        print(f"# {shell} completions for mdbook")


def cmd_watch(args):
    opts, pos = parse_options(args, {"-d": True, "--dest-dir": True, "-o": False, "--open": False, "--watcher": True})
    if opts.get("help"):
        print_help("watch")
        return
    if opts.get("version"):
        print(VERSION)
        return
    build_args = []
    if opts.get("d"):
        build_args += ["-d", opts["d"]]
    if opts.get("dest_dir"):
        build_args += ["--dest-dir", opts["dest_dir"]]
    build_args += pos
    build_book(build_args)
    log("INFO", "mdbook_driver::watch", "Watching for changes")


def cmd_serve(args):
    opts, pos = parse_options(args, {"-d": True, "--dest-dir": True, "-n": True, "--hostname": True, "-p": True, "--port": True, "-o": False, "--open": False, "--watcher": True})
    if opts.get("help"):
        print_help("serve")
        return
    if opts.get("version"):
        print(VERSION)
        return
    build_args = []
    if opts.get("d"):
        build_args += ["-d", opts["d"]]
    if opts.get("dest_dir"):
        build_args += ["--dest-dir", opts["dest_dir"]]
    build_args += pos
    build_book(build_args)
    host = opts.get("n") or opts.get("hostname") or "localhost"
    port = opts.get("p") or opts.get("port") or "3000"
    log("INFO", "mdbook_driver::serve", f"Serving on http://{host}:{port}")


def main():
    args = sys.argv[1:]
    if not args or args[0] in ("-h", "--help"):
        print_help("top")
        return
    if args[0] in ("-V", "--version"):
        print(VERSION)
        return
    cmd, rest = args[0], args[1:]
    if cmd == "help":
        if rest and rest[0] in HELP:
            print_help(rest[0])
        else:
            print_help("top")
    elif cmd == "init":
        cmd_init(rest)
    elif cmd == "build":
        build_book(rest)
    elif cmd == "clean":
        cmd_clean(rest)
    elif cmd == "test":
        cmd_test(rest)
    elif cmd == "completions":
        cmd_completions(rest)
    elif cmd == "watch":
        cmd_watch(rest)
    elif cmd == "serve":
        cmd_serve(rest)
    else:
        eprint(f"error: unrecognized subcommand '{cmd}'\n")
        eprint("Usage: executable [COMMAND]\n")
        eprint("For more information, try '--help'.")
        sys.exit(2)


if __name__ == "__main__":
    main()
