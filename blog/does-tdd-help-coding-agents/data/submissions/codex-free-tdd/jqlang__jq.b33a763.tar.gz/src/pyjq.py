#!/usr/bin/env python3
import json, sys, re
from collections import OrderedDict

class JQError(Exception): pass
class CompileError(JQError):
    def __init__(self, name): self.name=name
class RuntimeJQError(JQError): pass

TOK_RE=re.compile(r'''\s*(?:(//|==|!=|>=|<=|\.\.|[.\[\]{}(),:|+\-*/<>])|("(?:\\.|[^"\\])*"|-?\d+(?:\.\d+)?(?:[eE][+-]?\d+)?)|(\$?[A-Za-z_][A-Za-z0-9_]*))''')

def toks(s):
    out=[]; i=0
    while i<len(s):
        m=TOK_RE.match(s,i)
        if not m: raise CompileError(s[i:].split()[0] if s[i:].split() else s[i:])
        op,lit,ident=m.groups(); i=m.end()
        out.append(op or lit or ident)
    out.append('EOF'); return out

class Parser:
    def __init__(self,s): self.t=toks(s); self.i=0
    def peek(self): return self.t[self.i]
    def pop(self,x=None):
        v=self.peek()
        if x is not None and v!=x: raise CompileError(v)
        self.i+=1; return v
    def parse(self):
        e=self.parse_pipe()
        if self.peek()!='EOF': raise CompileError(self.peek())
        return e
    def parse_pipe(self):
        e=self.parse_comma()
        while self.peek()=='|': self.pop('|'); e=('pipe',e,self.parse_comma())
        return e
    def parse_pipe_item(self):
        e=self.parse_cmp()
        while self.peek()=='|': self.pop('|'); e=('pipe',e,self.parse_cmp())
        return e
    def parse_comma(self):
        e=self.parse_alt()
        while self.peek()==',': self.pop(','); e=('comma',e,self.parse_alt())
        return e
    def parse_alt(self):
        e=self.parse_cmp()
        while self.peek()=='//': self.pop('//'); e=('alt',e,self.parse_cmp())
        return e
    def parse_cmp(self):
        e=self.parse_add()
        while self.peek() in ('==','!=','>','<','>=','<='):
            op=self.pop(); e=('bin',op,e,self.parse_add())
        return e
    def parse_add(self):
        e=self.parse_mul()
        while self.peek() in ('+','-'):
            op=self.pop(); e=('bin',op,e,self.parse_mul())
        return e
    def parse_mul(self):
        e=self.parse_postfix()
        while self.peek() in ('*','/'):
            op=self.pop(); e=('bin',op,e,self.parse_postfix())
        return e
    def parse_postfix(self):
        e=self.parse_primary()
        while True:
            if self.peek()=='.':
                self.pop('.')
                if self.peek()!='EOF' and re.match(r'[A-Za-z_]', self.peek()): e=('field',e,self.pop())
                else: e=('identity',) if e is None else e
            elif self.peek()=='[':
                self.pop('[')
                if self.peek()==']': self.pop(']'); e=('iter',e)
                else:
                    idx=self.parse_alt()
                    if self.peek()==':':
                        self.pop(':')
                        end=None if self.peek()==']' else self.parse_alt()
                        self.pop(']'); e=('slice',e,idx,end)
                    else:
                        self.pop(']'); e=('index',e,idx)
            else: break
        return e
    def parse_primary(self):
        v=self.peek()
        if v=='if':
            self.pop('if')
            cond=self.parse_cmp()
            self.pop('then')
            yes=self.parse_pipe_item()
            self.pop('else')
            no=self.parse_pipe_item()
            self.pop('end')
            return ('if',cond,yes,no)
        if v=='(':
            self.pop('('); e=self.parse_pipe(); self.pop(')'); return e
        if v=='.':
            self.pop('.')
            if self.peek()!='EOF' and re.match(r'[A-Za-z_]', self.peek()):
                return ('field', ('identity',), self.pop())
            return ('identity',)
        if v=='[':
            self.pop('[')
            if self.peek()==']': self.pop(']'); return ('lit',[])
            e=self.parse_pipe(); self.pop(']'); return ('array',e)
        if v=='{':
            self.pop('{'); pairs=[]
            if self.peek()!='}':
                while True:
                    k=self.pop()
                    if k.startswith('"'): key=json.loads(k)
                    else: key=k
                    if self.peek()==':': self.pop(':'); val=self.parse_pipe_item()
                    else: val=('field',('identity',),key)
                    pairs.append((key,val))
                    if self.peek()!=',': break
                    self.pop(',')
            self.pop('}'); return ('object',pairs)
        if v.startswith('"'): self.pop(); return ('lit',json.loads(v))
        if re.match(r'-?\d',v):
            self.pop(); return ('lit', float(v) if any(c in v for c in '.eE') else int(v))
        if v in ('true','false','null'):
            self.pop(); return ('lit', {'true':True,'false':False,'null':None}[v])
        if v.startswith('$'):
            self.pop(); return ('var',v[1:])
        if re.match(r'[A-Za-z_]',v):
            name=self.pop()
            if self.peek()=='(':
                self.pop('('); args=[]
                if self.peek()!=')':
                    while True:
                        args.append(self.parse_pipe())
                        if self.peek()!=',': break
                        self.pop(',')
                self.pop(')'); return ('call',name,args)
            return ('call',name,[])
        raise CompileError(v)

def truthy(x): return not (x is False or x is None)

def jq_type(x):
    if x is None: return 'null'
    if isinstance(x,bool): return 'boolean'
    if isinstance(x,(int,float)) and not isinstance(x,bool): return 'number'
    if isinstance(x,str): return 'string'
    if isinstance(x,list): return 'array'
    if isinstance(x,dict): return 'object'
    return 'unknown'

def eval_ast(ast, inp, env):
    k=ast[0]
    if k=='identity': return [inp]
    if k=='lit': return [ast[1]]
    if k=='var': return [env.get(ast[1], None)]
    if k=='pipe':
        out=[]
        for v in eval_ast(ast[1], inp, env): out += eval_ast(ast[2], v, env)
        return out
    if k=='comma': return eval_ast(ast[1],inp,env)+eval_ast(ast[2],inp,env)
    if k=='field':
        vals=eval_ast(ast[1],inp,env); out=[]
        for v in vals:
            out.append(v.get(ast[2]) if isinstance(v,dict) else None)
        return out
    if k=='index':
        out=[]
        for base in eval_ast(ast[1],inp,env):
            idxs=eval_ast(ast[2],inp,env)
            for idx in idxs:
                try:
                    if isinstance(base,list) and isinstance(idx,int): out.append(base[idx] if -len(base)<=idx<len(base) else None)
                    elif isinstance(base,dict) and isinstance(idx,str): out.append(base.get(idx))
                    elif isinstance(base,str) and isinstance(idx,int): out.append(base[idx] if -len(base)<=idx<len(base) else None)
                    else: out.append(None)
                except Exception: out.append(None)
        return out
    if k=='iter':
        out=[]
        for v in eval_ast(ast[1],inp,env):
            if isinstance(v,list): out+=v
            elif isinstance(v,dict): out+=list(v.values())
            elif v is None: pass
            else: raise RuntimeJQError('Cannot iterate over '+jq_type(v))
        return out
    if k=='array': return [eval_ast(ast[1],inp,env)]
    if k=='object':
        obj=OrderedDict()
        for key, expr in ast[1]:
            vals=eval_ast(expr,inp,env); obj[key]= vals[-1] if vals else None
        return [obj]
    if k=='alt':
        left=eval_ast(ast[1],inp,env)
        if left and left[-1] is not None and left[-1] is not False: return left
        return eval_ast(ast[2],inp,env)
    if k=='if':
        return eval_ast(ast[2] if any(truthy(x) for x in eval_ast(ast[1],inp,env)) else ast[3], inp, env)
    if k=='slice':
        out=[]
        for base in eval_ast(ast[1],inp,env):
            starts=eval_ast(ast[2],inp,env); ends=eval_ast(ast[3],inp,env) if ast[3] is not None else [None]
            for st in starts:
                for en in ends:
                    out.append(base[st:en])
        return out
    if k=='bin':
        av=eval_ast(ast[2],inp,env); bv=eval_ast(ast[3],inp,env); out=[]
        for a in av:
            for b in bv:
                op=ast[1]
                if op=='+': out.append(jq_add(a,b))
                elif op=='-': out.append(a-b)
                elif op=='*': out.append(a*b)
                elif op=='/':
                    q=a/b
                    out.append(int(q) if isinstance(q,float) and q.is_integer() else q)
                elif op=='==': out.append(a==b)
                elif op=='!=': out.append(a!=b)
                elif op=='>': out.append(a>b)
                elif op=='<': out.append(a<b)
                elif op=='>=': out.append(a>=b)
                elif op=='<=': out.append(a<=b)
        return out
    if k=='call': return call(ast[1],ast[2],inp,env)
    raise CompileError(k)

def jq_add(a,b):
    if a is None: return b
    if b is None: return a
    if isinstance(a,(int,float)) and isinstance(b,(int,float)): return a+b
    if isinstance(a,str) and isinstance(b,str): return a+b
    if isinstance(a,list) and isinstance(b,list): return a+b
    if isinstance(a,dict) and isinstance(b,dict):
        r=OrderedDict(a); r.update(b); return r
    raise RuntimeJQError('cannot add')

def jq_contains(hay, needle):
    if isinstance(hay, dict) and isinstance(needle, dict):
        return all(k in hay and jq_contains(hay[k], v) for k,v in needle.items())
    if isinstance(hay, list):
        if isinstance(needle, list): return all(any(jq_contains(h, n) for h in hay) for n in needle)
        return any(jq_contains(h, needle) for h in hay)
    if isinstance(hay, str) and isinstance(needle, str): return needle in hay
    return hay == needle

def call(name,args,inp,env):
    if name=='length':
        if inp is None: return [0]
        if isinstance(inp,(str,list,dict)): return [len(inp)]
        if isinstance(inp,(int,float)): return [abs(inp)]
    if name=='type': return [jq_type(inp)]
    if name=='keys':
        if isinstance(inp,dict): return [sorted(inp.keys())]
        if isinstance(inp,list): return [list(range(len(inp)))]
    if name=='contains' and len(args)==1:
        vals=eval_ast(args[0], inp, env)
        needle=vals[-1] if vals else None
        return [jq_contains(inp, needle)]
    if name=='has' and len(args)==1:
        vals=eval_ast(args[0], inp, env)
        key=vals[-1] if vals else None
        if isinstance(inp,dict): return [key in inp]
        if isinstance(inp,list) and isinstance(key,int): return [0 <= key < len(inp)]
        return [False]
    if name=='add':
        if not isinstance(inp,list) or not inp: return [None]
        acc=inp[0]
        for x in inp[1:]: acc=jq_add(acc,x)
        return [acc]
    if name=='map' and len(args)==1:
        if not isinstance(inp,list): raise RuntimeJQError('Cannot iterate over '+jq_type(inp))
        return [[y for x in inp for y in eval_ast(args[0],x,env)]]
    if name=='select' and len(args)==1:
        return [inp] if any(truthy(x) for x in eval_ast(args[0],inp,env)) else []
    if name=='range':
        vals=[eval_ast(a,inp,env)[-1] for a in args]
        if len(vals)==1: start,end,step=0,vals[0],1
        elif len(vals)==2: start,end,step=vals[0],vals[1],1
        elif len(vals)==3: start,end,step=vals
        else: raise CompileError(name)
        return list(range(int(start),int(end),int(step)))
    if name=='tostring': return [inp if isinstance(inp,str) else dumps(inp, compact=True)]
    if name=='tonumber': return [json.loads(inp) if isinstance(inp,str) else inp]
    if name=='not': return [not truthy(inp)]
    if name=='empty': return []
    if name=='values': return [] if inp is None else [inp]
    if name=='arrays': return [inp] if isinstance(inp,list) else []
    if name=='objects': return [inp] if isinstance(inp,dict) else []
    if name=='strings': return [inp] if isinstance(inp,str) else []
    if name=='numbers': return [inp] if isinstance(inp,(int,float)) and not isinstance(inp,bool) else []
    if name=='booleans': return [inp] if isinstance(inp,bool) else []
    if name=='nulls': return [inp] if inp is None else []
    raise CompileError(name)

def dumps(v, compact=False, ascii_only=False, sort_keys=False, indent=2):
    if compact:
        return json.dumps(v, ensure_ascii=ascii_only, sort_keys=sort_keys, separators=(',',':'))
    return json.dumps(v, ensure_ascii=ascii_only, sort_keys=sort_keys, indent=indent)

def parse_json_stream(text):
    dec=json.JSONDecoder(object_pairs_hook=OrderedDict); i=0; vals=[]; n=len(text)
    while True:
        while i<n and text[i].isspace(): i+=1
        if i>=n: break
        try: v,j=dec.raw_decode(text,i)
        except json.JSONDecodeError as e:
            raise ValueError(f"{e.msg} at line {e.lineno}, column {e.colno}")
        vals.append(v); i=j
    return vals

def parse_args(argv):
    opt={'null':False,'raw':False,'slurp':False,'compact':False,'rawout':False,'join':False,'ascii':False,'sort':False,'indent':2,'filter':None,'files':[],'env':{},'pos':[],'exit_status':False,'argmode':None}
    i=0
    while i<len(argv):
        a=argv[i]
        if a in ('-h','--help'): print_help(); sys.exit(0)
        if a in ('-V','--version'): print('jq-build-2b77eb1'); sys.exit(0)
        if a=='--build-configuration': print('--disable-docs --with-oniguruma=builtin --enable-static --enable-all-static --prefix=/usr/local'); sys.exit(0)
        if a=='--': i+=1; break
        if a.startswith('-') and opt['filter'] is None:
            if a in ('-n','--null-input'): opt['null']=True
            elif a in ('-R','--raw-input'): opt['raw']=True
            elif a in ('-s','--slurp'): opt['slurp']=True
            elif a in ('-c','--compact-output'): opt['compact']=True
            elif a in ('-r','--raw-output'): opt['rawout']=True
            elif a in ('-j','--join-output'): opt['rawout']=True; opt['join']=True
            elif a in ('-a','--ascii-output'): opt['ascii']=True
            elif a in ('-S','--sort-keys'): opt['sort']=True
            elif a in ('-e','--exit-status'): opt['exit_status']=True
            elif a in ('-f','--from-file'):
                i+=1
                with open(argv[i], encoding='utf-8') as fh: opt['filter']=fh.read().strip()
            elif a=='--indent': i+=1; opt['indent']=max(0,min(7,int(argv[i])))
            elif a=='--tab': opt['indent']='\t'
            elif a=='--rawfile':
                i+=1; name=argv[i]; i+=1
                with open(argv[i], encoding='utf-8') as fh: opt['env'][name]=fh.read()
            elif a=='--slurpfile':
                i+=1; name=argv[i]; i+=1
                with open(argv[i], encoding='utf-8') as fh: opt['env'][name]=parse_json_stream(fh.read())
            elif a=='--arg': i+=1; name=argv[i]; i+=1; val=argv[i]; opt['env'][name]=val
            elif a=='--argjson': i+=1; name=argv[i]; i+=1; opt['env'][name]=json.loads(argv[i])
            elif a in ('--args','--jsonargs'):
                opt['argmode']='json' if a=='--jsonargs' else 'str'
            else:
                # support combined short flags such as -rc
                if len(a)>2 and all(ch in 'nRscrjaSe' for ch in a[1:]):
                    argv=argv[:i]+['-'+ch for ch in a[1:]]+argv[i+1:]; i-=1
                else: raise SystemExit(2)
        else:
            if opt['filter'] is None:
                opt['filter']=a
                if opt.get('argmode'):
                    rest=argv[i+1:]
                    opt['pos']=[json.loads(x) for x in rest] if opt['argmode']=='json' else rest
                    i=len(argv); break
            else: opt['files'].append(a)
        i+=1
    if opt['filter'] is None and i<len(argv): opt['filter']=argv[i]; opt['files']=argv[i+1:]
    if opt['filter'] is None: opt['filter']='.'
    named=OrderedDict((k,opt['env'][k]) for k in opt['env'])
    opt['env']['ARGS']=OrderedDict([('positional', opt['pos']), ('named', named)])
    return opt

def print_help():
    print('jq - commandline JSON processor [version build-2b77eb1]\n')
    print('Usage:\tjq [options] <jq filter> [file...]')

def read_inputs(opt):
    data=''
    if opt['files']:
        for f in opt['files']:
            with open(f,encoding='utf-8') as fh: data+=fh.read()
    else: data=sys.stdin.read()
    if opt['null']: return [None]
    if opt['raw']:
        if opt['slurp']: return [data]
        return data.splitlines()
    vals=parse_json_stream(data)
    return [vals] if opt['slurp'] else vals

def main(argv):
    try: opt=parse_args(argv)
    except Exception as e:
        print(f'jq: error: {e}', file=sys.stderr); return 2
    try: ast=Parser(opt['filter']).parse()
    except CompileError as e:
        name=e.name if getattr(e,'name','')!='EOF' else ''
        print(f'jq: error: {name}/0 is not defined at <top-level>, line 1, column 1:', file=sys.stderr)
        print(f'    {name}', file=sys.stderr); print('    '+'^'*max(1,len(name)), file=sys.stderr)
        print('jq: 1 compile error', file=sys.stderr); return 3
    try: inputs=read_inputs(opt)
    except ValueError as e:
        print(f'jq: parse error: {e}', file=sys.stderr); return 5
    last=None; anyout=False
    try:
        for inp in inputs:
            for val in eval_ast(ast,inp,opt['env']):
                anyout=True; last=val
                if opt['rawout'] and isinstance(val,str): s=val
                else: s=dumps(val, compact=opt['compact'], ascii_only=opt['ascii'], sort_keys=opt['sort'], indent=opt['indent'])
                sys.stdout.write(s)
                if not opt['join']: sys.stdout.write('\n')
    except CompileError as e:
        print(f'jq: error: {e.name}/0 is not defined', file=sys.stderr); return 3
    except Exception as e:
        print(f'jq: error (at <stdin>): {e}', file=sys.stderr); return 5
    if opt['exit_status']:
        if not anyout: return 4
        return 0 if truthy(last) else 1
    return 0

if __name__=='__main__': sys.exit(main(sys.argv[1:]))
