#!/usr/bin/env python3
import fnmatch
import math
import os
import re
import stat
import sys
from pathlib import Path


VERSION = "ripsecrets 0.1.11"
HOOK = "ripsecrets --strict-ignore `git diff --cached --name-only --diff-filter=ACM`\n"


SHORT_HELP = """A command-line tool to prevent committing secret keys into your source code

Usage: executable [OPTIONS] [Source files]...

Arguments:
  [Source files]...  Source files. Can be files or directories. Defaults to '.'

Options:
      --install-pre-commit
          Install `ripsecrets` as a pre-commit hook automatically in git directory provided
      --strict-ignore
          If you pass a path as an argument that's ignored by .secretsignore it will be scanned by default. --strict-ignore will override this behavior and not search the paths passed as arguments that are excluded by the .secretsignore file. This is useful when invoking secrets as a pre-commit
      --only-matching
          Print only the matched (non-empty) parts of a matching line, with each such part on a separate output line
      --additional-pattern <ADDITIONAL_PATTERNS>
          Additional regex patterns used to find secrets. If there is a matching group in the regex the matched group will be tested for randomness before being reported as a secret
  -h, --help
          Print help (see more with '--help')
  -V, --version
          Print version
"""


LONG_HELP = """ripsecrets searches files and directories recursively for secret API keys.
It's primarily designed to be used as a pre-commit to prevent committing
secrets into version control.

Usage: executable [OPTIONS] [Source files]...

Arguments:
  [Source files]...
          Source files. Can be files or directories. Defaults to '.'

Options:
      --install-pre-commit
          Install `ripsecrets` as a pre-commit hook automatically in git directory provided

      --strict-ignore
          If you pass a path as an argument that's ignored by .secretsignore it will be scanned by default. --strict-ignore will override this behavior and not search the paths passed as arguments that are excluded by the .secretsignore file. This is useful when invoking secrets as a pre-commit

      --only-matching
          Print only the matched (non-empty) parts of a matching line, with each such part on a separate output line

      --additional-pattern <ADDITIONAL_PATTERNS>
          Additional regex patterns used to find secrets. If there is a matching group in the regex the matched group will be tested for randomness before being reported as a secret

  -h, --help
          Print help (see a summary with '-h')

  -V, --version
          Print version
"""


BUILTINS = [
    re.compile(r"gh[pousr]_[A-Za-z0-9_]{36}"),
    re.compile(r"xox[baprs]-[A-Za-z0-9-]{20,80}"),
    re.compile(r"[rs]k_live_[A-Za-z0-9]{24,80}"),
    re.compile(r"AIzaSy[A-Za-z0-9_-]{33}"),
    re.compile(r"-----BEGIN [A-Z0-9 ]*PRIVATE KEY-----"),
]


def entropy(value):
    if not value:
        return 0.0
    total = len(value)
    counts = {}
    for char in value:
        counts[char] = counts.get(char, 0) + 1
    return -sum((count / total) * math.log2(count / total) for count in counts.values())


def is_random_enough(value):
    alnum = re.sub(r"[^A-Za-z0-9]", "", value)
    return len(alnum) >= 16 and entropy(alnum) >= 3.5


def parse_args(argv):
    opts = {
        "strict": False,
        "only": False,
        "install": False,
        "additional": [],
        "paths": [],
    }
    i = 0
    while i < len(argv):
        arg = argv[i]
        if arg == "--":
            opts["paths"].extend(argv[i + 1 :])
            break
        if arg in ("-h", "--help"):
            print(SHORT_HELP if arg == "-h" else LONG_HELP, end="")
            raise SystemExit(0)
        if arg in ("-V", "--version"):
            print(VERSION)
            raise SystemExit(0)
        if arg == "--strict-ignore":
            opts["strict"] = True
        elif arg == "--only-matching":
            opts["only"] = True
        elif arg == "--install-pre-commit":
            opts["install"] = True
        elif arg == "--additional-pattern":
            if i + 1 >= len(argv):
                print("error: a value is required for '--additional-pattern <ADDITIONAL_PATTERNS>'", file=sys.stderr)
                raise SystemExit(2)
            i += 1
            opts["additional"].append(argv[i])
        elif arg.startswith("--additional-pattern="):
            opts["additional"].append(arg.split("=", 1)[1])
        elif arg.startswith("-"):
            print(f"error: unexpected argument '{arg}' found", file=sys.stderr)
            print("", file=sys.stderr)
            print(f"  tip: to pass '{arg}' as a value, use '-- {arg}'", file=sys.stderr)
            print("", file=sys.stderr)
            print("Usage: executable [OPTIONS] [Source files]...", file=sys.stderr)
            print("", file=sys.stderr)
            print("For more information, try '--help'.", file=sys.stderr)
            raise SystemExit(2)
        else:
            opts["paths"].append(arg)
        i += 1
    if not opts["paths"]:
        opts["paths"] = ["."]
    return opts


def load_ignore(cwd):
    path_patterns = []
    secret_values = []
    ignore = Path(cwd) / ".secretsignore"
    if not ignore.exists():
        return path_patterns, secret_values
    in_secrets = False
    try:
        lines = ignore.read_text(errors="ignore").splitlines()
    except OSError:
        return path_patterns, secret_values
    for raw in lines:
        line = raw.strip()
        if not line or line.startswith("#"):
            continue
        if line == "[secrets]":
            in_secrets = True
            continue
        if in_secrets:
            secret_values.append(line)
        else:
            path_patterns.append(line)
    return path_patterns, secret_values


def rel_to_cwd(path):
    try:
        return os.path.relpath(path, os.getcwd()).replace(os.sep, "/")
    except ValueError:
        return str(path).replace(os.sep, "/")


def is_ignored(path, patterns):
    rel = rel_to_cwd(path)
    rel_no_dot = rel[2:] if rel.startswith("./") else rel
    for pattern in patterns:
        pat = pattern.replace(os.sep, "/")
        if pat.endswith("/"):
            prefix = pat.rstrip("/") + "/"
            if rel_no_dot.startswith(prefix) or ("/" + prefix) in ("/" + rel_no_dot):
                return True
        elif fnmatch.fnmatch(rel_no_dot, pat) or fnmatch.fnmatch(os.path.basename(rel_no_dot), pat):
            return True
    return False


def compile_additional(patterns):
    compiled = []
    for pattern in patterns:
        try:
            compiled.append(re.compile(pattern))
        except re.error as exc:
            print(f"Invalid regex: {exc}", file=sys.stderr)
    return compiled


def iter_files(paths, ignore_patterns, strict):
    for raw in paths:
        path = Path(raw)
        if not path.exists():
            print(f"{raw}: No such file or directory (os error 2)", file=sys.stderr)
            continue
        if path.is_file():
            if strict and is_ignored(path, ignore_patterns):
                continue
            yield path, str(path)
            continue
        if path.is_dir():
            for root, dirs, files in os.walk(path):
                dirs[:] = [
                    d for d in dirs
                    if d != ".git" and not is_ignored(Path(root) / d / "dummy", ignore_patterns)
                ]
                for name in files:
                    current = Path(root) / name
                    if is_ignored(current, ignore_patterns):
                        continue
                    display = str(current)
                    if raw == "." and not display.startswith("./"):
                        display = "./" + display
                    yield current, display


def matches_for_line(line, additional):
    found = []
    for pattern in BUILTINS:
        found.extend(match.group(0) for match in pattern.finditer(line))
    for pattern in additional:
        for match in pattern.finditer(line):
            if match.groups():
                candidate = next((group for group in match.groups() if group), "")
                if candidate and is_random_enough(candidate):
                    found.append(candidate)
            else:
                found.append(match.group(0))
    return found


def scan_file(path, display_path, additional, only_matching, ignored_secrets):
    reports = []
    try:
        with open(path, "r", encoding="utf-8", errors="ignore") as handle:
            for line_no, raw in enumerate(handle, 1):
                line = raw.rstrip("\n\r")
                matches = [
                    match for match in matches_for_line(line, additional)
                    if match and match not in ignored_secrets
                ]
                if not matches:
                    continue
                if only_matching:
                    for match in matches:
                        reports.append(f"{display_path}:{line_no}:{match}")
                else:
                    reports.append(f"{display_path}:{line_no}:{line}")
    except OSError:
        pass
    return reports


def install_pre_commit(target):
    gitdir = Path(target) / ".git"
    if not gitdir.is_dir():
        print("Error: .git directory not found", file=sys.stderr)
        return 2
    hooks = gitdir / "hooks"
    hooks.mkdir(parents=True, exist_ok=True)
    hook = hooks / "pre-commit"
    hook.write_text(HOOK)
    mode = hook.stat().st_mode
    hook.chmod(mode | stat.S_IXUSR)
    return 0


def main(argv):
    opts = parse_args(argv)
    if opts["install"]:
        return install_pre_commit(opts["paths"][0])
    ignore_patterns, ignored_secrets = load_ignore(os.getcwd())
    additional = compile_additional(opts["additional"])
    any_report = False
    for path, display_path in iter_files(opts["paths"], ignore_patterns, opts["strict"]):
        for report in scan_file(path, display_path, additional, opts["only"], ignored_secrets):
            any_report = True
            print(report)
    return 1 if any_report else 0


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
