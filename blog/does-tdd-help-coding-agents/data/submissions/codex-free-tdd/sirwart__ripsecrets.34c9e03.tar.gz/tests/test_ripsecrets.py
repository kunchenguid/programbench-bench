import os
import shutil
import stat
import subprocess
import tempfile
import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
BIN = ROOT / "ripsecrets.py"


def run_cmd(args, cwd=None):
    return subprocess.run(
        ["python3", str(BIN), *args],
        cwd=cwd or ROOT,
        text=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
    )


class RipSecretsTests(unittest.TestCase):
    def setUp(self):
        self.tmp = Path(tempfile.mkdtemp(prefix="ripsecrets-test-"))

    def tearDown(self):
        shutil.rmtree(self.tmp)

    def write(self, rel, text):
        path = self.tmp / rel
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(text)
        return path

    def test_reports_matching_line_and_nonzero_status(self):
        sample = self.write("sample.txt", "plain\napi=sk_live_abcdefghijklmnopqrstuvwxyz1234567890\n")

        result = run_cmd([str(sample)])

        self.assertEqual(result.returncode, 1)
        self.assertEqual(result.stdout, f"{sample}:2:api=sk_live_abcdefghijklmnopqrstuvwxyz1234567890\n")
        self.assertEqual(result.stderr, "")

    def test_only_matching_prints_secret_fragment(self):
        sample = self.write("tokens.txt", "gh=ghp_abcdefghijklmnopqrstuvwxyz1234567890ABCD\n")

        result = run_cmd(["--only-matching", str(sample)])

        self.assertEqual(result.returncode, 1)
        self.assertEqual(result.stdout, f"{sample}:1:ghp_abcdefghijklmnopqrstuvwxyz1234567890\n")

    def test_additional_pattern_without_group_reports_any_matching_line(self):
        sample = self.write("extra.txt", "foo my-secret-abc bar\n")

        result = run_cmd(["--additional-pattern", "my-secret-[A-Za-z]+", str(sample)])

        self.assertEqual(result.returncode, 1)
        self.assertEqual(result.stdout, f"{sample}:1:foo my-secret-abc bar\n")

    def test_additional_pattern_with_group_requires_randomness(self):
        sample = self.write(
            "extra.txt",
            "foo my-secret-abc bar\nfoo token-AbCdEf1234567890QrStUvWxYz987654 bar\n",
        )

        result = run_cmd(["--additional-pattern", "token-([A-Za-z0-9]+)", str(sample)])

        self.assertEqual(result.returncode, 1)
        self.assertEqual(result.stdout, f"{sample}:2:foo token-AbCdEf1234567890QrStUvWxYz987654 bar\n")

    def test_secretsignore_skips_traversal_but_not_explicit_file_unless_strict(self):
        self.write(".secretsignore", "ignored/\n")
        ignored = self.write("ignored/token.txt", "sk_live_abcdefghijklmnopqrstuvwxyz1234567890\n")
        kept = self.write("kept.txt", "sk_live_abcdefghijklmnopqrstuvwxyz1234567890\n")

        directory_result = run_cmd(["."], cwd=self.tmp)
        explicit_result = run_cmd(["ignored/token.txt"], cwd=self.tmp)
        strict_result = run_cmd(["--strict-ignore", "ignored/token.txt"], cwd=self.tmp)

        self.assertEqual(directory_result.returncode, 1)
        self.assertIn("./kept.txt:1:", directory_result.stdout)
        self.assertNotIn("ignored/token.txt", directory_result.stdout)
        self.assertEqual(explicit_result.returncode, 1)
        self.assertEqual(strict_result.returncode, 0)
        self.assertEqual(strict_result.stdout, "")

    def test_secrets_section_suppresses_exact_secret_value(self):
        self.write(
            ".secretsignore",
            "[secrets]\nsk_live_abcdefghijklmnopqrstuvwxyz1234567890\n",
        )
        sample = self.write("token.txt", "sk_live_abcdefghijklmnopqrstuvwxyz1234567890\n")

        result = run_cmd([str(sample)], cwd=self.tmp)

        self.assertEqual(result.returncode, 0)
        self.assertEqual(result.stdout, "")

    def test_install_pre_commit_writes_hook(self):
        gitdir = self.tmp / ".git"
        hooks = gitdir / "hooks"
        hooks.mkdir(parents=True)

        result = run_cmd(["--install-pre-commit", str(self.tmp)])

        hook = hooks / "pre-commit"
        self.assertEqual(result.returncode, 0)
        self.assertEqual(result.stdout, "")
        self.assertEqual(result.stderr, "")
        self.assertEqual(
            hook.read_text(),
            "ripsecrets --strict-ignore `git diff --cached --name-only --diff-filter=ACM`\n",
        )
        self.assertTrue(hook.stat().st_mode & stat.S_IXUSR)


if __name__ == "__main__":
    unittest.main()
