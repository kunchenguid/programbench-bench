#!/usr/bin/env python3
import argparse
import json
import os
import sys
from dataclasses import dataclass, field


VERSION = "0.21.1"
SCHEMA = "2024-11-02"


@dataclass
class Node:
    name: str
    path: str
    size: int
    raw_size: int
    children: list = field(default_factory=list)
    inodes: dict = field(default_factory=dict)


def measure(st, quantity):
    if quantity == "apparent-size":
        return int(st.st_size)
    if quantity == "block-count":
        return int(getattr(st, "st_blocks", 0))
    return int(getattr(st, "st_blocks", 0)) * 512


def display_name(path):
    return path


def child_name(parent_arg, child_path):
    return os.path.basename(child_path)


def merge_inode_maps(target, source):
    for key, value in source.items():
        target.setdefault(key, []).extend(value)


def scan(path, quantity, base_arg, errors, silent):
    try:
        st = os.lstat(path)
    except OSError as exc:
        if not silent:
            print(f'[error] symlink_metadata "{path}": {exc.strerror} (os error {exc.errno})', file=sys.stderr)
        return Node(display_name(path), path, 0, 0)

    own = measure(st, quantity)
    node = Node(display_name(path), path, own, own)
    if not os.path.isdir(path) or os.path.islink(path):
        if getattr(st, "st_nlink", 1) > 1 and not os.path.isdir(path):
            rel = path if os.path.isabs(base_arg) else os.path.relpath(path, os.getcwd())
            if not rel.startswith(".") and not os.path.isabs(rel):
                rel = f"./{rel}"
            node.inodes[(getattr(st, "st_dev", 0), st.st_ino)] = [(rel, own, st.st_nlink, st.st_ino)]
        return node

    try:
        entries = [entry.path for entry in os.scandir(path)]
    except OSError as exc:
        if not silent:
            print(f'[error] read_dir "{path}": {exc.strerror} (os error {exc.errno})', file=sys.stderr)
        entries = []

    for entry_path in entries:
        child = scan(entry_path, quantity, base_arg, errors, silent)
        child.name = child_name(path, entry_path)
        node.raw_size += child.raw_size
        node.size += child.size
        node.children.append(child)
        merge_inode_maps(node.inodes, child.inodes)
    return node


def apply_dedupe(node, groups):
    for child in node.children:
        apply_dedupe(child, groups)
    total_subtract = 0
    for key, paths in node.inodes.items():
        if len(paths) > 1:
            total_subtract += (len(paths) - 1) * paths[0][1]
    node.size = max(0, node.raw_size - total_subtract)


def sort_tree(node):
    node.children.sort(key=lambda child: child.size, reverse=True)
    for child in node.children:
        sort_tree(child)


def prune_to_json(node, max_depth, min_ratio, total_size, depth=1):
    children = []
    if max_depth == "inf" or depth < max_depth:
        for child in node.children:
            if total_size == 0 or min_ratio <= 0 or (child.size / total_size) >= min_ratio:
                children.append(prune_to_json(child, max_depth, min_ratio, total_size, depth + 1))
    return {"name": node.name, "size": int(node.size), "children": children}


def format_shared(root, omit_details, omit_summary):
    groups = []
    for paths in root.inodes.values():
        if len(paths) > 1:
            groups.append(paths)
    if not groups:
        return None
    shared = {}
    if not omit_details:
        details = []
        for paths in groups:
            first = paths[0]
            details.append(
                {
                    "ino": int(first[3]),
                    "size": int(first[1]),
                    "links": int(first[2]),
                    "paths": [p[0] for p in paths],
                }
            )
        shared["details"] = details
    if not omit_summary:
        inodes = len(groups)
        all_links = sum(group[0][2] for group in groups)
        detected_links = sum(len(group) for group in groups)
        exclusive_links = sum(len(group) for group in groups if len(group) == group[0][2])
        shared_size = sum((len(group) - 1) * group[0][1] for group in groups)
        exclusive_shared_size = sum((len(group) - 1) * group[0][1] for group in groups if len(group) == group[0][2])
        shared["summary"] = {
            "inodes": inodes,
            "exclusive_inodes": sum(1 for group in groups if len(group) == group[0][2]),
            "all_links": int(all_links),
            "detected_links": int(detected_links),
            "exclusive_links": int(exclusive_links),
            "shared_size": int(shared_size),
            "exclusive_shared_size": int(exclusive_shared_size),
        }
    return shared


def build_data(args):
    files = args.files or ["."]
    errors = []
    nodes = [scan(path, args.quantity, path, errors, args.silent_errors) for path in files]
    for node, path in zip(nodes, files):
        node.name = display_name(path)
    if len(nodes) == 1:
        root = nodes[0]
    else:
        root = Node("(total)", "(total)", sum(n.size for n in nodes), sum(n.raw_size for n in nodes), nodes, {})
        for node in nodes:
            merge_inode_maps(root.inodes, node.inodes)
    if args.deduplicate_hardlinks:
        apply_dedupe(root, root.inodes)
    if not args.no_sort:
        sort_tree(root)
    unit = "blocks" if args.quantity == "block-count" else "bytes"
    data = {
        "schema-version": SCHEMA,
        "pdu": VERSION,
        "unit": unit,
        "tree": prune_to_json(root, args.max_depth, args.min_ratio, root.size),
    }
    if args.deduplicate_hardlinks:
        shared = format_shared(root, args.omit_json_shared_details, args.omit_json_shared_summary)
        if shared:
            data["shared"] = shared
    return data


def human_size(size, fmt):
    if fmt == "plain":
        return str(size)
    base = 1024 if fmt == "binary" else 1000
    units = ["", "K", "M", "G", "T", "P"]
    value = float(size)
    idx = 0
    while abs(value) >= base and idx < len(units) - 1:
        value /= base
        idx += 1
    if idx == 0:
        return str(size)
    return f"{value:.1f}{units[idx]}"


def render_chart(data, bytes_format, top_down=False, align_right=False):
    root = data["tree"]
    lines = []

    def walk(node, prefix="", is_last=True):
        pct = 100 if root["size"] == 0 else round(node["size"] * 100 / root["size"])
        bar_len = max(0, min(40, pct * 40 // 100))
        bar = "█" * bar_len
        connector = "└──" if is_last else "├──"
        lines.append(f"{human_size(node['size'], bytes_format):>6} {prefix}{connector}{node['name']} │{bar:<40}│{pct:>3}%")
        next_prefix = prefix + ("   " if is_last else "│  ")
        for index, child in enumerate(node.get("children", [])):
            walk(child, next_prefix, index == len(node.get("children", [])) - 1)

    if top_down:
        walk(root)
    else:
        def walk_bottom(node, prefix="", is_last=True):
            next_prefix = prefix + ("   " if is_last else "│  ")
            for index, child in enumerate(node.get("children", [])):
                walk_bottom(child, next_prefix, index == len(node.get("children", [])) - 1)
            pct = 100 if root["size"] == 0 else round(node["size"] * 100 / root["size"])
            bar_len = max(0, min(40, pct * 40 // 100))
            bar = "█" * bar_len
            connector = "└──" if is_last else "├──"
            lines.append(f"{human_size(node['size'], bytes_format):>6} {prefix}{connector}{node['name']} │{bar:<40}│{pct:>3}%")
        walk_bottom(root)
    return "\n".join(lines) + ("\n" if lines else "")


def positive_depth(value):
    if value == "inf":
        return value
    try:
        number = int(value)
    except ValueError:
        raise argparse.ArgumentTypeError('Value is neither "inf" nor a positive integer')
    if number <= 0:
        raise argparse.ArgumentTypeError('Value is neither "inf" nor a positive integer')
    return number


def nonnegative_float(value):
    number = float(value)
    if number < 0:
        raise argparse.ArgumentTypeError("less than 0")
    return number


def threads_value(value):
    if value in ("auto", "max"):
        return value
    try:
        number = int(value)
    except ValueError:
        raise argparse.ArgumentTypeError('Value is neither "auto", "max", nor a number')
    if number <= 0:
        raise argparse.ArgumentTypeError('Value is neither "auto", "max", nor a number')
    return number


def make_parser():
    parser = argparse.ArgumentParser(
        prog="executable",
        description="Summarize disk usage of the set of files, recursively for directories.",
        formatter_class=argparse.RawTextHelpFormatter,
    )
    parser.add_argument("--json-input", action="store_true", help="Read JSON data from stdin")
    parser.add_argument("--json-output", action="store_true", help="Print JSON data instead of an ASCII chart")
    parser.add_argument("-b", "--bytes-format", choices=["plain", "metric", "binary"], default="metric")
    parser.add_argument("-H", "--deduplicate-hardlinks", "--detect-links", "--dedupe-links", action="store_true")
    parser.add_argument("--top-down", action="store_true")
    parser.add_argument("--align-right", action="store_true")
    parser.add_argument("-q", "--quantity", choices=["apparent-size", "block-size", "block-count"], default="block-size")
    parser.add_argument("-d", "--max-depth", "--depth", type=positive_depth, default=10)
    parser.add_argument("-w", "--total-width", "--width")
    parser.add_argument("--column-width", nargs=2)
    parser.add_argument("-m", "--min-ratio", type=nonnegative_float, default=0.01)
    parser.add_argument("--no-sort", action="store_true")
    parser.add_argument("-s", "--silent-errors", "--no-errors", action="store_true")
    parser.add_argument("-p", "--progress", action="store_true")
    parser.add_argument("--threads", type=threads_value, default="auto")
    parser.add_argument("--omit-json-shared-details", action="store_true")
    parser.add_argument("--omit-json-shared-summary", action="store_true")
    parser.add_argument("-V", "--version", action="store_true")
    parser.add_argument("files", nargs="*")
    return parser


def main(argv=None):
    parser = make_parser()
    args = parser.parse_args(argv)
    if args.version:
        print(f"pdu {VERSION}")
        return 0
    if args.json_input:
        try:
            data = json.load(sys.stdin)
        except Exception as exc:
            print(f"error: {exc}", file=sys.stderr)
            return 1
    else:
        data = build_data(args)
    if args.json_output:
        sys.stdout.write(json.dumps(data, separators=(",", ":")))
    else:
        print(render_chart(data, args.bytes_format, args.top_down, args.align_right), end="")
    return 0


if __name__ == "__main__":
    sys.exit(main())
