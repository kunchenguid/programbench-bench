#!/usr/bin/env python3
import argparse
import json
import os
import re
import sys
from dataclasses import dataclass, field


@dataclass
class Heading:
    level: int
    title: str
    line: int
    index: int
    children: list = field(default_factory=list)
    parent: object = None
    start: int = 0
    end: int = 0


@dataclass
class CodeBlock:
    lang: str
    content: str


def slugify(text):
    s = re.sub(r"[^a-z0-9]+", "-", text.lower()).strip("-")
    return s


def read_input(paths):
    if paths and paths[0] == "-":
        return sys.stdin.read(), None
    if paths:
        path = paths[0]
        try:
            with open(path, "r", encoding="utf-8") as f:
                return f.read(), path
        except OSError as e:
            print(f"Error reading input: I/O error: {e}", file=sys.stderr)
            sys.exit(1)
    if not sys.stdin.isatty():
        return "# Select a file\n", None
    return "", None


def parse_doc(text):
    lines = text.splitlines()
    headings = []
    in_code = False
    for i, line in enumerate(lines, 1):
        if line.startswith("```"):
            in_code = not in_code
            continue
        if in_code:
            continue
        m = re.match(r"^(#{1,6})\s+(.+?)\s*$", line)
        if m:
            headings.append(Heading(len(m.group(1)), m.group(2).strip(), i, len(headings), start=i))

    for idx, h in enumerate(headings):
        h.end = len(lines) + 1
        for nxt in headings[idx + 1:]:
            if nxt.level <= h.level:
                h.end = nxt.line
                break

    roots = []
    stack = []
    for h in headings:
        while stack and stack[-1].level >= h.level:
            stack.pop()
        if stack:
            h.parent = stack[-1]
            stack[-1].children.append(h)
        else:
            roots.append(h)
        stack.append(h)

    return lines, headings, roots


def heading_line(h):
    return "#" * h.level + " " + h.title


def filtered_headings(headings, pattern=None, level=None):
    out = headings
    if pattern:
        p = pattern.lower()
        out = [h for h in out if p in h.title.lower()]
    if level:
        out = [h for h in out if h.level == level]
    return out


def render_tree(nodes, prefix=""):
    rows = []
    for i, node in enumerate(nodes):
        last = i == len(nodes) - 1
        rows.append(f"{prefix}{'└──' if last else '├──'}{heading_line(node)}")
        child_prefix = prefix + ("   " if last else "│  ")
        rows.extend(render_tree(node.children, child_prefix))
    return rows


def section_text(lines, h):
    return "\n".join(lines[h.line - 1:h.end - 1]).rstrip("\n") + "\n"


def count_words(text):
    return len(re.findall(r"\b\w+\b", text))


def list_json(lines, headings, roots, source):
    def build(h):
        raw = "\n".join(lines[h.line:h.end - 1]).strip()
        return {
            "id": slugify(h.title),
            "level": h.level,
            "title": h.title,
            "slug": slugify(h.title),
            "position": {"line": h.line + 1, "offset": 0},
            "content": {"raw": raw, "blocks": []},
            "children": [build(c) for c in h.children],
        }
    obj = {
        "document": {
            "metadata": {
                "source": None,
                "headingCount": len(headings),
                "maxDepth": max([h.level for h in headings], default=0),
                "wordCount": count_words("\n".join(lines)),
            },
            "sections": [build(h) for h in roots],
        }
    }
    return json.dumps(obj, indent=2)


def extract_code_blocks(lines):
    blocks = []
    in_code = False
    lang = ""
    buf = []
    for line in lines:
        m = re.match(r"^```(.*)$", line)
        if m:
            if in_code:
                blocks.append(CodeBlock(lang, "\n".join(buf)))
                buf = []
                in_code = False
            else:
                lang = m.group(1).strip()
                in_code = True
            continue
        if in_code:
            buf.append(line)
    return blocks


def extract_links(lines):
    links = []
    for line in lines:
        for m in re.finditer(r"(?<!!)\[([^\]]+)\]\(([^)]+)\)", line):
            links.append((m.group(1), m.group(2)))
    return links


def extract_tables(lines):
    tables = []
    i = 0
    while i < len(lines) - 1:
        if "|" in lines[i] and re.match(r"^\s*\|?\s*:?-{3,}:?\s*(\|\s*:?-{3,}:?\s*)+\|?\s*$", lines[i + 1]):
            rows = [lines[i], lines[i + 1]]
            i += 2
            while i < len(lines) and "|" in lines[i] and lines[i].strip():
                rows.append(lines[i])
                i += 1
            tables.append(rows)
        else:
            i += 1
    return tables


def normalize_table(rows):
    parsed = []
    for row in rows:
        cells = [c.strip() for c in row.strip().strip("|").split("|")]
        parsed.append(cells)
    out = ["| " + " | ".join(parsed[0]) + " |"]
    out.append("| " + " | ".join(["---"] * len(parsed[0])) + " |")
    for cells in parsed[2:]:
        out.append("| " + " | ".join(cells) + " |")
    return "\n".join(out)


def extract_lists(lines):
    groups = []
    cur = []
    for line in lines:
        if re.match(r"^\s*[-*+]\s+", line):
            cur.append(line.strip())
        else:
            if cur:
                groups.append(cur)
                cur = []
    if cur:
        groups.append(cur)
    return groups


def query_items(expr, lines, headings):
    expr = expr.strip()
    if expr.startswith("[") and "] | " in expr:
        inner, func = expr[1:].split("] | ", 1)
        items = query_items(inner.strip(), lines, headings)
        func = func.strip()
        if func in ("count", "length", "len", "size"):
            return [str(len(items))]
        m = re.match(r"(limit|take)\((\d+)\)", func)
        if m:
            return items[:int(m.group(2))]
    if "|" in expr:
        left, func = [p.strip() for p in expr.split("|", 1)]
        items = query_items(left, lines, headings)
        if func == "text":
            return [i.title if isinstance(i, Heading) else str(i) for i in items]
        if func == "lang":
            return [i.lang for i in items if isinstance(i, CodeBlock)]
        if func in ("url", "href", "src"):
            return [i[1] for i in items if isinstance(i, tuple)]
        if func == "stats":
            return stats_lines(lines, headings)
    if expr in (".h", ".heading"):
        return headings
    m = re.match(r"^\.h([1-6])(?:\[(.+)\])?$", expr)
    if m:
        selected = [h for h in headings if h.level == int(m.group(1))]
        filt = m.group(2)
        if filt is not None:
            if re.fullmatch(r"-?\d+", filt):
                idx = int(filt)
                return [selected[idx]] if -len(selected) <= idx < len(selected) else []
            filt = filt.strip('"')
            selected = [h for h in selected if filt.lower() in h.title.lower()]
        return selected
    if expr.startswith(".code"):
        blocks = extract_code_blocks(lines)
        m = re.match(r"^\.code\[(.+)\]$", expr)
        if m:
            wanted = m.group(1).strip('"')
            blocks = [b for b in blocks if b.lang == wanted]
        return blocks
    if expr in (".link", ".a"):
        return extract_links(lines)
    if expr == ".table":
        return [normalize_table(t) for t in extract_tables(lines)]
    if expr == ".list":
        return ["\n".join(g) for g in extract_lists(lines)]
    if expr == ". | stats":
        return stats_lines(lines, headings)
    return []


def stats_lines(lines, headings):
    text = "\n".join(lines)
    return [
        f"headings: {len(headings)}",
        f"code_blocks: {len(extract_code_blocks(lines))}",
        f"links: {len(extract_links(lines))}",
        "images: 0",
        f"tables: {len(extract_tables(lines))}",
        f"lists: {len(extract_lists(lines))}",
        f"words: {count_words(text)}",
    ]


def run_query(expr, fmt, lines, headings):
    items = query_items(expr, lines, headings)
    if fmt in ("json", "jsonp", "json-pretty", "jsonl"):
        def enc(item):
            if isinstance(item, Heading):
                return {"type": "heading", "level": item.level, "text": item.title, "line": item.line}
            if isinstance(item, CodeBlock):
                return {"type": "code", "language": item.lang, "content": item.content}
            if isinstance(item, tuple):
                return {"type": "link", "text": item[0], "url": item[1]}
            return item
        data = [enc(i) for i in items]
        if fmt == "jsonl":
            return "\n".join(json.dumps(x, separators=(",", ":")) for x in data) + ("\n" if data else "")
        return json.dumps(data, indent=2 if fmt in ("jsonp", "json-pretty") else None, separators=None if fmt in ("jsonp", "json-pretty") else (",", ":")) + "\n"
    out = []
    for item in items:
        if isinstance(item, Heading):
            out.append(heading_line(item))
        elif isinstance(item, CodeBlock):
            out.append("```" + item.lang + "\n" + item.content + "\n```")
        elif isinstance(item, tuple):
            out.append(f"[{item[0]}]({item[1]})")
        else:
            out.append(str(item))
    return "\n".join(out) + ("\n" if out else "")


def query_help():
    return """treemd Query Language (tql)

A jq-like query language for navigating and extracting markdown structure.

ELEMENT SELECTORS
    .h, .heading    All headings (any level)
    .h1 - .h6       Headings by level
    .code           All code blocks
    .link, .a       All links
"""


def main_help():
    return """treemd - A modern markdown viewer combining tree-based navigation with interactive TUI.

Launch without flags for interactive mode with dual-pane interface, vim-style navigation,
syntax highlighting, and real-time search. Use flags for CLI mode to extract, filter,
and analyze markdown structure.

Examples:
  treemd README.md              # Interactive TUI mode
  treemd -l README.md           # List all headings
  treemd --tree README.md       # Show heading tree
  treemd -s Installation doc.md # Extract section
  treemd --setup-completions    # Set up shell completions

Usage: executable [OPTIONS] [FILE]... [COMMAND]

Commands:
  at-line  Show heading at specific line number
  help     Print this message or the help of the given subcommand(s)

Arguments:
  [FILE]...
          Markdown file(s) to view (.md or .markdown), directory, or '-' for stdin

Options:
  -l, --list
          List all headings in the document (non-interactive)

      --tree
          Show heading tree structure with box-drawing characters (non-interactive)

      --filter <PATTERN>
          Filter headings by text pattern (case-insensitive)

  -L, --level <LEVEL>
          Show only headings at specific level (1-6)

  -o, --output <OUTPUT>
          Output format for --list and --tree modes

          Possible values:
          - plain: Plain text output
          - json:  JSON output
          - tree:  Tree format with box-drawing

          [default: plain]

  -s, --section <HEADING>
          Extract specific section by heading name

      --count
          Count headings by level (shows statistics)

      --setup-completions
          Set up shell completions interactively

      --theme <THEME>
          Set theme for TUI mode

      --color-mode <MODE>
          Force color mode (auto, rgb, 256)

      --no-images
          Disable image rendering in TUI mode

      --images
          Enable image rendering in TUI mode (override config)

  -q, --query <EXPR>
          Query expression for selecting/filtering document elements

      --query-help
          Show query language documentation and examples

      --query-output <FORMAT>
          Output format for query results

  -h, --help
          Print help (see a summary with '-h')

  -V, --version
          Print version
"""


def at_line_help():
    return """Show heading at specific line number

Finds and displays the heading that appears at or before the given line number. Useful for jumping to a specific location in the document structure.

Usage: executable at-line <LINE>

Arguments:
  <LINE>
          Line number in the markdown file

Options:
  -h, --help
          Print help (see a summary with '-h')
"""


def main(argv=None):
    argv = list(sys.argv[1:] if argv is None else argv)
    if not argv:
        return 0
    if argv in (["--help"], ["-h"], ["help"]):
        sys.stdout.write(main_help())
        return 0
    if argv[:2] == ["help", "at-line"] or (argv and argv[0] == "at-line" and any(a in ("-h", "--help") for a in argv[1:])):
        sys.stdout.write(at_line_help())
        return 0
    if argv and argv[0] == "at-line":
        return 0
    p = argparse.ArgumentParser(
        prog="executable",
        description="treemd - A modern markdown viewer combining tree-based navigation with interactive TUI.",
        add_help=False,
    )
    p.add_argument("files", nargs="*")
    p.add_argument("-l", "--list", action="store_true")
    p.add_argument("--tree", action="store_true")
    p.add_argument("--filter")
    p.add_argument("-L", "--level", type=int)
    p.add_argument("-o", "--output", default="plain", choices=["plain", "json", "tree"])
    p.add_argument("-s", "--section")
    p.add_argument("--count", action="store_true")
    p.add_argument("--setup-completions", action="store_true")
    p.add_argument("--theme")
    p.add_argument("--color-mode", choices=["auto", "rgb", "256"])
    p.add_argument("--no-images", action="store_true")
    p.add_argument("--images", action="store_true")
    p.add_argument("-q", "--query")
    p.add_argument("--query-help", action="store_true")
    p.add_argument("--query-output", default="plain")
    p.add_argument("-V", "--version", action="store_true")
    args = p.parse_args(argv)

    if args.version:
        print("treemd 0.5.7")
        return 0
    if args.query_help:
        sys.stdout.write(query_help())
        return 0
    if args.setup_completions:
        print("Shell completions setup is not available in this reimplementation.")
        return 0

    text, source = read_input(args.files)
    lines, headings, roots = parse_doc(text)

    if args.query:
        sys.stdout.write(run_query(args.query, args.query_output, lines, headings))
        return 0

    selected = filtered_headings(headings, args.filter, args.level)
    if args.count:
        counts = {}
        for h in selected:
            counts[h.level] = counts.get(h.level, 0) + 1
        print("Heading counts:")
        for level in sorted(counts):
            print(f"  {'#' * level}: {counts[level]}")
        print()
        print(f"Total: {sum(counts.values())}")
        return 0

    if args.section:
        needle = args.section.lower()
        for h in headings:
            if h.title.lower() == needle:
                sys.stdout.write(section_text(lines, h))
                return 0
        print(f"Section '{args.section}' not found")
        return 1

    if args.output == "json":
        if args.list:
            print(list_json(lines, headings, roots, source))
        else:
            print(json.dumps([{"level": h.level, "text": h.title} for h in selected], indent=2))
        return 0

    if args.tree or args.output == "tree":
        if selected != headings:
            tree_lines = [heading_line(h) for h in selected]
        else:
            tree_lines = render_tree(roots)
        sys.stdout.write("\n".join(tree_lines) + ("\n" if tree_lines else ""))
        return 0

    if args.list or args.files or text:
        rows = [heading_line(h) for h in selected]
        sys.stdout.write("\n".join(rows) + ("\n" if rows else ""))
        return 0

    return 0


if __name__ == "__main__":
    sys.exit(main())
