#!/usr/bin/env python3
import os
import sys


VERSION = "bat 0.26.1 (610b77c)"

SHORT_HELP = """A cat(1) clone with wings.

Usage: bat [OPTIONS] [FILE]...
       bat <COMMAND>

Arguments:
  [FILE]...  File(s) to print / concatenate. Use '-' for standard input.

Options:
  -A, --show-all
          Show non-printable characters (space, tab, newline, ..).
      --nonprintable-notation <notation>
          Set notation for non-printable characters.
      --binary <behavior>
          How to treat binary content. (default: no-printing)
  -p, --plain...
          Show plain style (alias for '--style=plain').
  -l, --language <language>
          Set the language for syntax highlighting.
      --fallback-syntax <fallback-syntax>
          Set a fallback language for undetected syntaxes. [aliases: --fallback-language]
  -H, --highlight-line <N:M>
          Highlight lines N through M.
      --file-name <name>
          Specify the name to display for a file.
  -d, --diff
          Only show lines that have been added/removed/modified.
      --tabs <T>
          Set the tab width to T spaces.
      --wrap <mode>
          Specify the text-wrapping mode (*auto*, never, character, word).
  -S, --chop-long-lines
          Truncate all lines longer than screen width. Alias for '--wrap=never'.
  -n, --number
          Show line numbers (alias for '--style=numbers').
      --color <when>
          When to use colors (*auto*, never, always).
      --decorations <when>
          When to show the decorations (*auto*, never, always).
      --paging <when>
          Specify when to use the pager, or use `-P` to disable (*auto*, never, always).
  -s, --squeeze-blank
          Squeeze consecutive empty lines.
      --style <components>
          Comma-separated list of style elements to display (*default*, auto, full, plain, changes,
          header, header-filename, header-filesize, grid, rule, numbers, snip).
  -r, --line-range <N:M>
          Only print the lines from N to M.
  -L, --list-languages
          Display all supported languages.
  -u, --unbuffered
          Enable unbuffered input reading for streaming use cases.
      --completion <SHELL>
          Show shell completion for a certain shell. [possible values: bash, fish, zsh, ps1]
  -E, --quiet-empty
          Produce no output when the input is empty.
  -h, --help
          Print help (see more with '--help')
  -V, --version
          Print version
"""

LANGUAGES = """ActionScript:as
Ada:adb,ads,gpr
Apache Conf:envvars,htaccess,HTACCESS,htgroups,HTGROUPS,htpasswd,HTPASSWD,.htaccess,.HTACCESS,.htgroups,.HTGROUPS,.htpasswd,.HTPASSWD,httpd.conf
Bourne Again Shell (bash):sh,bash,zsh,ash,.bashrc,.profile
C:c
C#:cs,csx
C++:cpp,cc,cp,cxx,c++,h,hh,hpp,hxx,h++,inl,ipp,*.h
CSS:css
Diff:diff,patch,*.debdiff
Dockerfile:Dockerfile,dockerfile,.Dockerfile,Containerfile
Go:go
HTML:html,htm
INI:ini,INI,inf,INF
Java:java
JavaScript (Babel):js,mjs,jsx,babel,es6,cjs
JSON:json,jsonl,jsonc
Makefile:make,GNUmakefile,makefile,Makefile,mk
Markdown:md,markdown,mdown,mkdn
Python:py,py3,pyw
Rust:rs
TOML:toml,Cargo.lock
TypeScript:ts,tsx
XML:xml,xsd,svg
YAML:yaml,yml
"""

THEMES = """1337
Catppuccin Frappe
Catppuccin Latte
Catppuccin Macchiato
Catppuccin Mocha
Coldark-Cold
Coldark-Dark
DarkNeon
Dracula
GitHub
Monokai Extended
Monokai Extended Bright
Monokai Extended Light
Monokai Extended Origin
Nord
OneHalfDark
OneHalfLight
Solarized (dark)
Solarized (light)
Sublime Snazzy
TwoDark
Visual Studio Dark+
ansi
base16
base16-256
gruvbox-dark
gruvbox-light
zenburn
"""


class Options:
    def __init__(self):
        self.files = []
        self.plain_count = 0
        self.number = False
        self.show_all = False
        self.notation = "unicode"
        self.squeeze = False
        self.squeeze_limit = 1
        self.ranges = []
        self.quiet_empty = False
        self.decorations = "auto"
        self.color = "auto"
        self.tabs = 4
        self.style = None
        self.file_name = None
        self.wrap = None
        self.binary = "no-printing"


def eprint(msg):
    sys.stderr.write(msg)


def bat_error(msg):
    eprint(f"\033[31m[bat error]\033[0m: {msg}\n")


def parse_value(argv, i, opt):
    arg = argv[i]
    if arg == opt:
        if i + 1 >= len(argv):
            eprint(f"error: a value is required for '{opt} <value>' but none was supplied\n")
            sys.exit(2)
        return argv[i + 1], i + 2
    return arg.split("=", 1)[1], i + 1


def validate_choice(name, value, choices):
    if value not in choices:
        vals = ", ".join(choices)
        eprint(f"error: invalid value '{value}' for '{name}'\n  [possible values: {vals}]\n")
        sys.exit(2)


def parse_args(argv):
    opts = Options()
    i = 0
    positional_only = False
    while i < len(argv):
        arg = argv[i]
        if positional_only:
            opts.files.append(arg)
            i += 1
        elif arg == "--":
            positional_only = True
            i += 1
        elif arg in ("-h", "--help"):
            print(SHORT_HELP, end="")
            sys.exit(0)
        elif arg in ("-V", "--version"):
            print(VERSION)
            sys.exit(0)
        elif arg in ("-L", "--list-languages"):
            print(LANGUAGES, end="")
            sys.exit(0)
        elif arg == "--list-themes":
            print(THEMES, end="")
            sys.exit(0)
        elif arg == "--config-file":
            print(os.path.expanduser("~/.config/bat/config"))
            sys.exit(0)
        elif arg == "--config-dir":
            print(os.path.expanduser("~/.config/bat"))
            sys.exit(0)
        elif arg == "--diagnostic":
            print(f"#### Software version\n\n{VERSION}\n")
            sys.exit(0)
        elif arg == "--acknowledgements":
            print("bat is built on free and open source software.")
            sys.exit(0)
        elif arg in ("-A", "--show-all"):
            opts.show_all = True
            opts.plain_count += 1
            i += 1
        elif arg == "-n" or arg == "--number":
            opts.number = True
            i += 1
        elif arg.startswith("-p") and arg != "-P":
            if set(arg) == {"-", "p"}:
                opts.plain_count += len(arg) - 1
                i += 1
            else:
                unexpected(arg)
        elif arg == "--plain":
            opts.plain_count += 1
            i += 1
        elif arg in ("-s", "--squeeze-blank"):
            opts.squeeze = True
            i += 1
        elif arg == "--squeeze-limit" or arg.startswith("--squeeze-limit="):
            val, i = parse_value(argv, i, "--squeeze-limit")
            opts.squeeze_limit = int(val)
        elif arg in ("-r", "--line-range") or arg.startswith("--line-range="):
            if arg == "-r":
                if i + 1 >= len(argv):
                    eprint("error: a value is required for '--line-range <N:M>' but none was supplied\n")
                    sys.exit(2)
                val, i = argv[i + 1], i + 2
            else:
                val, i = parse_value(argv, i, "--line-range")
            opts.ranges.append(val)
        elif arg in ("-l", "--language", "--fallback-syntax", "--fallback-language", "-H", "--highlight-line", "-m", "--map-syntax", "--theme", "--theme-light", "--theme-dark", "--pager", "--ignored-suffix") or any(arg.startswith(x + "=") for x in ("--language", "--fallback-syntax", "--fallback-language", "--highlight-line", "--map-syntax", "--theme", "--theme-light", "--theme-dark", "--pager", "--ignored-suffix")):
            if "=" in arg and arg.startswith("--"):
                i += 1
            else:
                i += 2
        elif arg == "--file-name" or arg.startswith("--file-name="):
            opts.file_name, i = parse_value(argv, i, "--file-name")
        elif arg == "--nonprintable-notation" or arg.startswith("--nonprintable-notation="):
            opts.notation, i = parse_value(argv, i, "--nonprintable-notation")
            validate_choice("--nonprintable-notation <notation>", opts.notation, ["unicode", "caret"])
        elif arg == "--binary" or arg.startswith("--binary="):
            opts.binary, i = parse_value(argv, i, "--binary")
            validate_choice("--binary <behavior>", opts.binary, ["no-printing", "as-text"])
        elif arg == "--tabs" or arg.startswith("--tabs="):
            val, i = parse_value(argv, i, "--tabs")
            try:
                opts.tabs = int(val)
            except ValueError:
                eprint(f"error: invalid value '{val}' for '--tabs <T>': must be a number\n")
                sys.exit(2)
        elif arg == "--color" or arg.startswith("--color="):
            opts.color, i = parse_value(argv, i, "--color")
            validate_choice("--color <when>", opts.color, ["auto", "never", "always"])
        elif arg == "--decorations" or arg.startswith("--decorations="):
            opts.decorations, i = parse_value(argv, i, "--decorations")
            validate_choice("--decorations <when>", opts.decorations, ["auto", "never", "always"])
        elif arg == "--paging" or arg.startswith("--paging="):
            _, i = parse_value(argv, i, "--paging")
        elif arg == "-P":
            i += 1
        elif arg == "--style" or arg.startswith("--style="):
            opts.style, i = parse_value(argv, i, "--style")
            if "bogus" in opts.style:
                eprint("error: invalid value 'bogus' for '--style <components>': Unknown style 'bogus'\n")
                sys.exit(2)
            if "numbers" in opts.style:
                opts.number = True
            if opts.style == "plain":
                opts.plain_count += 1
        elif arg == "--wrap" or arg.startswith("--wrap="):
            opts.wrap, i = parse_value(argv, i, "--wrap")
        elif arg == "-S" or arg == "--chop-long-lines" or arg == "-u" or arg == "--unbuffered" or arg == "-d" or arg == "--diff" or arg == "-f" or arg == "--force-colorization" or arg == "--set-terminal-title":
            i += 1
        elif arg == "-E" or arg == "--quiet-empty":
            opts.quiet_empty = True
            i += 1
        elif arg == "--completion" or arg.startswith("--completion="):
            shell, i = parse_value(argv, i, "--completion")
            print(f"# completion for {shell}")
            sys.exit(0)
        elif arg.startswith("-") and arg != "-":
            unexpected(arg)
        else:
            opts.files.append(arg)
            i += 1
    return opts


def unexpected(arg):
    eprint(f"error: unexpected argument '{arg}' found\n\n")
    eprint(f"  tip: to pass '{arg}' as a value, use '-- {arg}'\n\n")
    eprint("Usage: executable [OPTIONS] [FILE]...\n       executable <COMMAND>\n")
    sys.exit(2)


def parse_range(spec, total):
    try:
        parts = spec.split(":")
        if len(parts) == 1:
            n = int(parts[0])
            return max(1, n), min(total, n)
        start_s = parts[0]
        end_s = parts[1] if len(parts) > 1 else ""
        context = int(parts[2]) if len(parts) > 2 and parts[2] else 0
        if start_s == "":
            start = 1
        else:
            start = int(start_s)
            if start < 0:
                start = total + start + 1
        if end_s == "":
            end = total
        elif end_s.startswith("+"):
            end = start + int(end_s[1:])
        else:
            end = int(end_s)
        start -= context
        end += context
        return max(1, start), min(total, end)
    except ValueError as exc:
        bat_error(str(exc))
        sys.exit(1)


def select_ranges(lines, ranges):
    if not ranges:
        return lines
    selected = []
    total = len(lines)
    for spec in ranges:
        start, end = parse_range(spec, total)
        if start <= end:
            selected.extend(lines[start - 1 : end])
    return selected


def is_blank(line):
    return line in (b"\n", b"\r\n", b"")


def squeeze_lines(lines, limit):
    out = []
    blanks = 0
    for line in lines:
        if is_blank(line):
            blanks += 1
            if blanks <= limit:
                out.append(line)
        else:
            blanks = 0
            out.append(line)
    return out


def show_byte(b, notation, tabs):
    if b == 9:
        if notation == "unicode" and tabs in (1, 2):
            return "↹"
        return "├" + ("─" * max(0, tabs - 3)) + "┤" if notation == "unicode" else "^I"
    if b == 10:
        return ("␊" if notation == "unicode" else "^J") + "\n"
    if b == 13:
        return "␍" if notation == "unicode" else "^M"
    if b == 32:
        return "·"
    if b < 32:
        return chr(0x2400 + b) if notation == "unicode" else "^" + chr(b + 64)
    if b == 127:
        return "␡" if notation == "unicode" else "^?"
    return bytes([b]).decode("utf-8", "replace")


def render_show_all(data, opts):
    return "".join(show_byte(b, opts.notation, opts.tabs) for b in data).encode()


def read_input(name):
    if name == "-":
        return sys.stdin.buffer.read(), None
    try:
        with open(name, "rb") as f:
            return f.read(), None
    except OSError as exc:
        return b"", exc


def decorated_number_lines(lines):
    return [f"{idx:4d} ".encode() + line for idx, line in enumerate(lines, 1)]


def wants_full_decorations(opts):
    if opts.decorations != "always" or opts.plain_count:
        return False
    if opts.number and opts.style is None:
        return False
    if opts.style is None:
        return True
    parts = set(opts.style.split(","))
    return "grid" in parts or "header" in parts or "header-filename" in parts or "full" in parts or "default" in parts


def rule(junction):
    return ("─" * 5 + junction + "─" * 74 + "\n").encode()


def decorated_file(data, display_name, opts):
    if opts.show_all:
        rendered = render_show_all(data, opts)
        lines = rendered.splitlines(True)
    else:
        lines = data.splitlines(True)
    lines = select_ranges(lines, opts.ranges)
    if opts.squeeze:
        lines = squeeze_lines(lines, opts.squeeze_limit)

    out = bytearray()
    out.extend(rule("┬"))
    out.extend(f"     │ File: {display_name}\n".encode())
    if opts.style and ("header-filesize" in opts.style or "full" in opts.style):
        out.extend(f"     │ Size: {format_size(len(data))}\n".encode())
    out.extend(rule("┼"))
    for idx, line in enumerate(lines, 1):
        out.extend(f"{idx:4d} │ ".encode())
        out.extend(line)
    out.extend(rule("┴"))
    return bytes(out)


def format_size(size):
    if size == 1:
        return "1 B"
    if size < 1000:
        return f"{size} B"
    return f"{size / 1000:.1f} KB"


def process_data(data, opts):
    if opts.quiet_empty and data == b"":
        return b""
    if opts.show_all:
        rendered = render_show_all(data, opts)
        lines = rendered.splitlines(True)
    else:
        lines = data.splitlines(True)
    lines = select_ranges(lines, opts.ranges)
    if opts.squeeze:
        lines = squeeze_lines(lines, opts.squeeze_limit)
    if opts.number:
        lines = decorated_number_lines(lines)
    return b"".join(lines)


def main(argv):
    if argv[:1] == ["cache"]:
        if len(argv) > 1 and argv[1] in ("-h", "--help"):
            print("Modify the syntax-definition and theme cache.")
            return 0
        print("bat cache: nothing to do")
        return 0
    opts = parse_args(argv)
    files = opts.files or ["-"]
    status = 0
    output = bytearray()
    for name in files:
        data, err = read_input(name)
        if err:
            bat_error(f"'{name}': {err.strerror} (os error {err.errno})")
            status = 1
            continue
        if wants_full_decorations(opts):
            display_name = opts.file_name or ("STDIN" if name == "-" else name)
            output.extend(decorated_file(data, display_name, opts))
        else:
            output.extend(process_data(data, opts))
    sys.stdout.buffer.write(output)
    return status


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
