import os
import subprocess
import tempfile
import unittest


ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
REF = os.path.join(ROOT, "reference_executable")
NEW = os.path.join(ROOT, "executable")


def run(cmd, *, data=None, cwd=None):
    return subprocess.run(
        cmd,
        input=data,
        cwd=cwd,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        check=False,
    )


class BatBehaviorTests(unittest.TestCase):
    def assert_matches_reference(self, args, *, files=None, stdin=None):
        with tempfile.TemporaryDirectory() as tmp:
            if files:
                for name, content in files.items():
                    mode = "wb" if isinstance(content, bytes) else "w"
                    with open(os.path.join(tmp, name), mode) as f:
                        f.write(content)

            ref = run([REF] + args, data=stdin, cwd=tmp)
            new = run([NEW] + args, data=stdin, cwd=tmp)
            self.assertEqual(new.returncode, ref.returncode)
            self.assertEqual(new.stdout, ref.stdout)
            self.assertEqual(new.stderr, ref.stderr)

    def test_plain_file_output_matches_cat(self):
        self.assert_matches_reference(
            ["-p", "sample.txt"],
            files={"sample.txt": b"one\n\ntwo\n\n\nthree\n"},
        )

    def test_stdin_dash_is_concatenated_between_files(self):
        self.assert_matches_reference(
            ["-p", "a.txt", "-", "a.txt"],
            files={"a.txt": b"file\n"},
            stdin=b"in\n",
        )

    def test_numbered_output_when_decorations_are_forced(self):
        self.assert_matches_reference(
            ["-n", "--decorations=always", "--color=never", "sample.txt"],
            files={"sample.txt": b"one\n\ntwo\n"},
        )

    def test_default_decorations_when_forced(self):
        self.assert_matches_reference(
            ["--decorations=always", "--color=never", "sample.txt"],
            files={"sample.txt": b"one\ntwo\n"},
        )

    def test_squeeze_blank_and_line_ranges(self):
        self.assert_matches_reference(
            ["-s", "-p", "sample.txt"],
            files={"sample.txt": b"one\n\ntwo\n\n\nthree\n"},
        )
        self.assert_matches_reference(
            ["-p", "-r", "2:4", "sample.txt"],
            files={"sample.txt": b"one\n\ntwo\n\n\nthree\n"},
        )

    def test_show_all_unicode_and_caret_notation(self):
        self.assert_matches_reference(
            ["-A", "--color=never", "--decorations=never", "ws.txt"],
            files={"ws.txt": b"a\tb \n"},
        )
        self.assert_matches_reference(
            [
                "-A",
                "--nonprintable-notation=caret",
                "--color=never",
                "--decorations=never",
                "ctl.txt",
            ],
            files={"ctl.txt": b"A\x01B\x7fC\n"},
        )

    def test_show_all_respects_small_and_large_tab_widths(self):
        self.assert_matches_reference(
            ["-A", "--tabs", "1", "--color=never", "--decorations=never", "ws.txt"],
            files={"ws.txt": b"a\tb\n"},
        )
        self.assert_matches_reference(
            ["-A", "--tabs", "8", "--color=never", "--decorations=never", "ws.txt"],
            files={"ws.txt": b"a\tb\n"},
        )

    def test_squeeze_limit_controls_blank_lines(self):
        self.assert_matches_reference(
            ["-p", "--squeeze-blank", "--squeeze-limit", "0", "sample.txt"],
            files={"sample.txt": b"a\n\n\n\nb\n"},
        )
        self.assert_matches_reference(
            ["-p", "--squeeze-blank", "--squeeze-limit", "2", "sample.txt"],
            files={"sample.txt": b"a\n\n\n\nb\n"},
        )

    def test_error_for_missing_file(self):
        self.assert_matches_reference(["-p", "missing.txt"])

    def test_version_and_short_help(self):
        version = run([NEW, "--version"])
        self.assertEqual(version.returncode, 0)
        self.assertEqual(version.stdout, b"bat 0.26.1 (610b77c)\n")
        help_result = run([NEW, "-h"])
        self.assertEqual(help_result.returncode, 0)
        self.assertIn(b"A cat(1) clone with wings.", help_result.stdout)
        self.assertIn(b"Usage: bat [OPTIONS] [FILE]...", help_result.stdout)


if __name__ == "__main__":
    unittest.main()
