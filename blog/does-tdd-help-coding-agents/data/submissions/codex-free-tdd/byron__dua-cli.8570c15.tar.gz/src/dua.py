#!/usr/bin/env python3
import os
import stat
import sys
from dataclasses import dataclass


GREEN = "\033[32m"
CYAN = "\033[36m"
RESET = "\033[39m"
VERSION = "dua 2.32.2"
FORMATS = {"metric", "binary", "bytes", "gb", "gib", "mb", "mib"}


@dataclass
class Options:
    fmt: str = "binary"
    apparent: bool = False
    count_hard_links: bool = False
    no_sort: bool = False
    no_total: bool = False
    stats: bool = False
    ignore_dirs: tuple[str, ...] = ("/proc", "/dev", "/sys", "/run")


@dataclass
class Entry:
    path: str
    display: str
    size: int
    is_dir: bool
    errors: int = 0


class ParserError(Exception):
    def __init__(self, message: str, code: int = 2):
        super().__init__(message)
        self.code = code


class Traversal:
    def __init__(self, opts: Options):
        self.opts = opts
        self.seen: set[tuple[int, int]] = set()
        self.entries = 0
        self.smallest = None
        self.largest = 0

    def size_of(self, path: str, is_root: bool = False) -> tuple[int, int]:
        try:
            st = os.lstat(path)
        except OSError:
            return 0, 1

        self.entries += 1
        mode = st.st_mode
        if stat.S_ISLNK(mode):
            self._note_entry_size(0)
            return 0, 0

        key = (st.st_dev, st.st_ino)
        if not self.opts.count_hard_links and not stat.S_ISDIR(mode):
            if key in self.seen:
                self._note_entry_size(0)
                return 0, 0
            self.seen.add(key)

        own = st.st_size if self.opts.apparent else st.st_blocks * 512
        self._note_entry_size(own)
        total = own
        errors = 0
        if stat.S_ISDIR(mode):
            real = os.path.realpath(path)
            if not is_root and os.path.abspath(path) in self.opts.ignore_dirs:
                return total, 0
            try:
                names = os.listdir(path)
            except OSError:
                return total, 1
            for name in names:
                child = os.path.join(path, name)
                size, child_errors = self.size_of(child)
                total += size
                errors += child_errors
        return total, errors

    def _note_entry_size(self, size: int) -> None:
        self.smallest = size if self.smallest is None else min(self.smallest, size)
        self.largest = max(self.largest, size)


def visible_entries(paths: list[str], opts: Options, aggregate: bool) -> tuple[list[Entry], Traversal]:
    trav = Traversal(opts)
    entries: list[Entry] = []
    if not paths:
        paths = [os.getcwd()]

    expand_single_dir = len(paths) == 1 and os.path.isdir(paths[0]) and not os.path.islink(paths[0])
    if expand_single_dir:
        root = paths[0]
        try:
            names = os.listdir(root)
        except OSError:
            names = []
        for name in names:
            child = os.path.join(root, name)
            if os.path.islink(child):
                continue
            size, errors = trav.size_of(child, is_root=True)
            entries.append(Entry(child, name, size, os.path.isdir(child) and not os.path.islink(child), errors))
    else:
        for path in paths:
            exists = os.path.lexists(path)
            is_dir = os.path.isdir(path) and not os.path.islink(path)
            size, errors = trav.size_of(path, is_root=True)
            entries.append(Entry(path, path, size, is_dir or not exists, errors))

    if not opts.no_sort:
        entries.sort(key=lambda e: (e.size, e.display))
    return entries, trav


def format_size(size: int, fmt: str) -> str:
    if fmt == "bytes":
        return f"{size:10d} b"
    units = {
        "binary": (1024.0, ["B", "KiB", "MiB", "GiB", "TiB"]),
        "metric": (1000.0, ["B", "KB", "MB", "GB", "TB"]),
    }
    fixed = {
        "gib": (1024.0**3, "GiB", 6),
        "gb": (1000.0**3, "GB", 7),
        "mib": (1024.0**2, "MiB", 8),
        "mb": (1000.0**2, "MB", 9),
    }
    if fmt in fixed:
        div, unit, width = fixed[fmt]
        return f"{size / div:{width}.2f} {unit}"
    base, names = units[fmt]
    val = float(size)
    unit = names[0]
    for unit in names:
        if abs(val) < base or unit == names[-1]:
            break
        val /= base
    if unit == "B":
        return f"{int(val):7d}   B" if fmt == "binary" else f"{int(val):7d}  B"
    width = 7 if fmt == "binary" else 7
    return f"{val:{width}.2f} {unit}"


def color_line(size: int, name: str, is_dir: bool, errors: int, opts: Options) -> str:
    label = f"{CYAN}{name}{RESET}" if is_dir else name
    suffix = f"  <{errors} IO Error{'s' if errors != 1 else ''}>" if errors else ""
    return f"{GREEN}{format_size(size, opts.fmt)}{RESET} {label}{suffix}\n"


def print_entries(paths: list[str], opts: Options, aggregate: bool) -> int:
    entries, trav = visible_entries(paths, opts, aggregate)
    total = 0
    status = 0
    out = []
    for entry in entries:
        total += entry.size
        if entry.errors:
            status = 1
        out.append(color_line(entry.size, entry.display, entry.is_dir, entry.errors, opts))
    if len(entries) > 1 and not opts.no_total:
        out.append(color_line(total, "total", False, 0, opts))
    sys.stdout.write("".join(out))
    if opts.stats:
        smallest = 0 if trav.smallest is None else trav.smallest
        print(
            f"Statistics {{ entries_traversed: {trav.entries}, "
            f"smallest_file_in_bytes: {smallest}, largest_file_in_bytes: {trav.largest} }}",
            file=sys.stderr,
        )
    return status


def help_text(program: str) -> str:
    return f"""A tool to learn about disk usage, fast!

Usage: dua [FLAGS] [OPTIONS] [SUBCOMMAND] [INPUT]...

Commands:
  interactive  Launch the terminal user interface [aliases: i]
  aggregate    Aggregate the consumed space of one or more directories or files [aliases: a]
  completions  Generate shell completions
  help         Print this message or the help of the given subcommand(s)

Arguments:
  [INPUT]...
          One or more input files or directories. If unset, we will use all entries in the current working directory

Options:
  -t, --threads <THREADS>
          The amount of threads to use
  -f, --format <FORMAT>
          The format with which to print byte counts
  -A, --apparent-size
          Display apparent size instead of disk usage
  -l, --count-hard-links
          Count hard-linked files each time they are seen
  -x, --stay-on-filesystem
          If set, we will not cross filesystems or traverse mount points
  -i, --ignore-dirs <IGNORE_DIRS>
          One or more absolute directories to ignore
      --log-file <LOG_FILE>
          Write a log file with debug information, including panics
  -h, --help
          Print help (see a summary with '-h')
  -V, --version
          Print version
"""


def aggregate_help() -> str:
    return """Aggregate the consumed space of one or more directories or files

Usage: executable aggregate [OPTIONS] [INPUT]...

Arguments:
  [INPUT]...  One or more input files or directories. If unset, we will use all entries in the current working directory

Options:
      --stats     If set, print additional statistics about the file traversal to stderr
      --no-sort   If set, paths will be printed in their order of occurrence on the command-line. Otherwise they are sorted by their size in bytes, ascending
      --no-total  If set, no total column will be computed for multiple inputs
  -h, --help      Print help
"""


def completions(shell: str) -> str:
    if shell not in {"bash", "elvish", "fish", "powershell", "zsh"}:
        raise ParserError(f"error: invalid value '{shell}' for '<SHELL>'\n  [possible values: bash, elvish, fish, powershell, zsh]\n\nFor more information, try '--help'.")
    if shell == "bash":
        return "_dua() {\n    local i cur prev opts cmd\n    COMPREPLY=()\n}\ncomplete -F _dua -o bashdefault -o default dua\n"
    return f"# completion script for dua ({shell})\n"


def parse(argv: list[str]) -> tuple[str, Options, list[str]]:
    opts = Options()
    cmd = "main"
    paths: list[str] = []
    i = 0
    while i < len(argv):
        arg = argv[i]
        if arg in ("aggregate", "a"):
            cmd = "aggregate"
        elif arg in ("interactive", "i"):
            cmd = "interactive"
        elif arg == "completions":
            cmd = "completions"
        elif arg == "help":
            cmd = "help"
        elif arg in ("-h", "--help"):
            cmd = f"{cmd}-help"
        elif arg in ("-V", "--version"):
            cmd = "version"
        elif arg in ("-A", "--apparent-size"):
            opts.apparent = True
        elif arg in ("-l", "--count-hard-links"):
            opts.count_hard_links = True
        elif arg in ("-x", "--stay-on-filesystem"):
            pass
        elif arg == "--stats":
            opts.stats = True
        elif arg == "--no-sort":
            opts.no_sort = True
        elif arg == "--no-total":
            opts.no_total = True
        elif arg in ("-f", "--format"):
            i += 1
            if i >= len(argv):
                raise ParserError("error: a value is required for '--format <FORMAT>' but none was supplied\n\nFor more information, try '--help'.")
            opts.fmt = argv[i]
            if opts.fmt not in FORMATS:
                raise ParserError(f"error: invalid value '{opts.fmt}' for '--format <FORMAT>'\n  [possible values: metric, binary, bytes, gb, gib, mb, mib]\n\nFor more information, try '--help'.")
        elif arg.startswith("--format="):
            opts.fmt = arg.split("=", 1)[1]
            if opts.fmt not in FORMATS:
                raise ParserError(f"error: invalid value '{opts.fmt}' for '--format <FORMAT>'\n  [possible values: metric, binary, bytes, gb, gib, mb, mib]\n\nFor more information, try '--help'.")
        elif arg in ("-t", "--threads", "--log-file"):
            i += 1
            if i >= len(argv):
                raise ParserError(f"error: a value is required for '{arg}' but none was supplied\n\nFor more information, try '--help'.")
            if arg in ("-t", "--threads"):
                try:
                    int(argv[i])
                except ValueError:
                    raise ParserError(f"error: invalid value '{argv[i]}' for '--threads <THREADS>': invalid digit found in string\n\nFor more information, try '--help'.")
        elif arg in ("-i", "--ignore-dirs"):
            vals = []
            i += 1
            while i < len(argv) and not argv[i].startswith("-"):
                vals.append(os.path.abspath(argv[i]))
                i += 1
            i -= 1
            opts.ignore_dirs = tuple(vals)
        elif arg.startswith("-"):
            raise ParserError(f"error: unexpected argument '{arg}' found\n\nFor more information, try '--help'.")
        else:
            paths.append(arg)
        i += 1
    return cmd, opts, paths


def main(argv: list[str]) -> int:
    try:
        cmd, opts, paths = parse(argv)
        if cmd == "version":
            print(VERSION)
            return 0
        if cmd in ("main-help", "help", "help-help"):
            print(help_text(os.path.basename(sys.argv[0])), end="")
            return 0
        if cmd == "aggregate-help":
            print(aggregate_help(), end="")
            return 0
        if cmd == "completions":
            if not paths:
                raise ParserError("error: the following required arguments were not provided:\n  <SHELL>\n\nUsage: executable completions <SHELL>\n\nFor more information, try '--help'.")
            print(completions(paths[0]), end="")
            return 0
        if cmd == "completions-help":
            print("Generate shell completions\n\nUsage: executable completions <SHELL>\n")
            return 0
        if cmd.startswith("interactive"):
            return print_entries(paths, opts, False)
        return print_entries(paths, opts, cmd == "aggregate")
    except ParserError as err:
        print(str(err), file=sys.stderr)
        return err.code


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
