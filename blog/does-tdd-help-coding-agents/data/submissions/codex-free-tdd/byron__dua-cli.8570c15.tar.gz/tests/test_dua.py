import os
import re
import shutil
import subprocess
import tempfile
import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
BIN = ROOT / "executable"


ANSI_RE = re.compile(r"\x1b\[[0-9;]*m")


def run_dua(args, cwd=None):
    proc = subprocess.run(
        [str(BIN), *args],
        cwd=cwd,
        text=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
    )
    return proc.returncode, ANSI_RE.sub("", proc.stdout), ANSI_RE.sub("", proc.stderr)


class DuaCliTests(unittest.TestCase):
    def setUp(self):
        self.tmp = Path(tempfile.mkdtemp(prefix="dua-test-"))
        (self.tmp / "dir" / "sub").mkdir(parents=True)
        (self.tmp / "emptydir").mkdir()
        (self.tmp / "a.txt").write_text("abc")
        (self.tmp / "dir" / "b.bin").write_bytes(b"\0" * 12345)
        (self.tmp / "dir" / "sub" / "c").write_text("x")
        os.link(self.tmp / "a.txt", self.tmp / "hard.txt")
        os.symlink("a.txt", self.tmp / "sym.txt")

    def tearDown(self):
        shutil.rmtree(self.tmp)

    def test_default_lists_directory_entries_by_disk_usage_with_total(self):
        code, out, err = run_dua([str(self.tmp)])

        self.assertEqual(code, 0, err)
        self.assertEqual(
            out,
            "      0   B hard.txt\n"
            "   4.00 KiB a.txt\n"
            "   4.00 KiB emptydir\n"
            "  28.00 KiB dir\n"
            "  36.00 KiB total\n",
        )
        self.assertEqual(err, "")

    def test_apparent_size_and_bytes_formats_are_supported(self):
        code, out, err = run_dua(["-A", "-f", "bytes", str(self.tmp)])
        dir_size = (
            os.lstat(self.tmp / "dir").st_size
            + os.lstat(self.tmp / "dir" / "sub").st_size
            + os.lstat(self.tmp / "dir" / "b.bin").st_size
            + os.lstat(self.tmp / "dir" / "sub" / "c").st_size
        )
        total = os.lstat(self.tmp / "a.txt").st_size + os.lstat(self.tmp / "emptydir").st_size + dir_size

        self.assertEqual(code, 0, err)
        self.assertEqual(
            out,
            "         0 b hard.txt\n"
            "         3 b a.txt\n"
            "      4096 b emptydir\n"
            f"{dir_size:10d} b dir\n"
            f"{total:10d} b total\n",
        )

    def test_aggregate_honors_no_sort_and_no_total(self):
        code, out, err = run_dua(
            ["aggregate", "--no-sort", "--no-total", str(self.tmp / "dir"), str(self.tmp / "a.txt")]
        )

        self.assertEqual(code, 0, err)
        self.assertEqual(
            out,
            f"  28.00 KiB {self.tmp / 'dir'}\n"
            f"   4.00 KiB {self.tmp / 'a.txt'}\n",
        )

    def test_missing_path_is_reported_and_sets_failure_status(self):
        missing = self.tmp / "missing"

        code, out, err = run_dua([str(missing)])

        self.assertEqual(code, 1)
        self.assertEqual(out, f"      0   B {missing}  <1 IO Error>\n")
        self.assertEqual(err, "")

    def test_stats_report_traversed_entries_and_largest_single_entry(self):
        code, out, err = run_dua(["aggregate", "--stats", str(self.tmp)])

        self.assertEqual(code, 0, out)
        self.assertIn("entries_traversed: 7", err)
        self.assertIn("smallest_file_in_bytes: 0", err)
        self.assertIn("largest_file_in_bytes: 16384", err)


if __name__ == "__main__":
    unittest.main()
