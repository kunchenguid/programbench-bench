import os
import subprocess
import sys
import tempfile
import textwrap
import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
CANDIDATE = [sys.executable, str(ROOT / "src" / "yq.py")]
ORIGINAL = os.environ.get("ORIGINAL_YQ", "/workspace/executable")


class YqBehaviorTests(unittest.TestCase):
    def run_cmd(self, argv, cwd, stdin=None, candidate=True):
        cmd = CANDIDATE if candidate else [ORIGINAL]
        return subprocess.run(
            cmd + argv,
            cwd=cwd,
            input=stdin,
            text=True,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
        )

    def assert_matches_original(self, argv, files, stdin=None):
        with tempfile.TemporaryDirectory() as td:
            cwd = Path(td)
            for name, content in files.items():
                (cwd / name).write_text(textwrap.dedent(content).lstrip(), encoding="utf-8")
            expected = self.run_cmd(argv, cwd, stdin=stdin, candidate=False)
            actual = self.run_cmd(argv, cwd, stdin=stdin, candidate=True)
            self.assertEqual(actual.returncode, expected.returncode)
            self.assertEqual(actual.stdout, expected.stdout)

    def test_reads_nested_scalar_path_from_yaml_file(self):
        self.assert_matches_original(
            [".a.b[0].c", "sample.yml"],
            {
                "sample.yml": """
                    a:
                      b:
                        - c: cool
                """,
            },
        )

    def test_expands_array_member_values(self):
        self.assert_matches_original(
            [".items[].name", "sample.yml"],
            {
                "sample.yml": """
                    items:
                      - type: fruit
                        name: apple
                      - type: veg
                        name: carrot
                """,
            },
        )

    def test_selects_array_items_by_equality(self):
        self.assert_matches_original(
            ['.items[] | select(.type == "fruit")', "sample.yml"],
            {
                "sample.yml": """
                    items:
                      - type: fruit
                        name: apple
                      - type: veg
                        name: carrot
                """,
            },
        )

    def test_collects_selected_array_items(self):
        self.assert_matches_original(
            ['[.items[] | select(.type == "fruit")]', "sample.yml"],
            {
                "sample.yml": """
                    items:
                      - type: fruit
                        name: apple
                      - type: veg
                        name: carrot
                """,
            },
        )

    def test_outputs_yaml_as_pretty_json(self):
        self.assert_matches_original(
            ["-o=json", ".", "sample.yml"],
            {
                "sample.yml": """
                    stuff: foo
                    num: 3
                    flag: true
                    empty: null
                """,
            },
        )

    def test_creates_nested_document_with_null_input_assignment(self):
        self.assert_matches_original(["-n", '.a.b.c = "cat"'], {})

    def test_updates_file_in_place_with_string_literal(self):
        with tempfile.TemporaryDirectory() as td:
            expected_dir = Path(td) / "expected"
            actual_dir = Path(td) / "actual"
            expected_dir.mkdir()
            actual_dir.mkdir()
            content = "a: old\n"
            (expected_dir / "sample.yml").write_text(content, encoding="utf-8")
            (actual_dir / "sample.yml").write_text(content, encoding="utf-8")
            expected = self.run_cmd(["-i", '.a = "cool"', "sample.yml"], expected_dir, candidate=False)
            actual = self.run_cmd(["-i", '.a = "cool"', "sample.yml"], actual_dir, candidate=True)
            self.assertEqual(actual.returncode, expected.returncode)
            self.assertEqual(actual.stdout, expected.stdout)
            self.assertEqual((actual_dir / "sample.yml").read_text(), (expected_dir / "sample.yml").read_text())

    def test_updates_file_in_place_with_strenv(self):
        with tempfile.TemporaryDirectory() as td:
            expected_dir = Path(td) / "expected"
            actual_dir = Path(td) / "actual"
            expected_dir.mkdir()
            actual_dir.mkdir()
            content = "a:\n  b:\n    - c: old\n"
            (expected_dir / "sample.yml").write_text(content, encoding="utf-8")
            (actual_dir / "sample.yml").write_text(content, encoding="utf-8")
            old = os.environ.get("NAME")
            os.environ["NAME"] = "mike"
            try:
                expected = self.run_cmd(["-i", '.a.b[0].c = strenv(NAME)', "sample.yml"], expected_dir, candidate=False)
                actual = self.run_cmd(["-i", '.a.b[0].c = strenv(NAME)', "sample.yml"], actual_dir, candidate=True)
            finally:
                if old is None:
                    os.environ.pop("NAME", None)
                else:
                    os.environ["NAME"] = old
            self.assertEqual(actual.returncode, expected.returncode)
            self.assertEqual(actual.stdout, expected.stdout)
            self.assertEqual((actual_dir / "sample.yml").read_text(), (expected_dir / "sample.yml").read_text())

    def test_reads_json_from_stdin_dash(self):
        self.assert_matches_original([".a", "-"], {}, stdin='{"a":1}\n')

    def test_outputs_json_file_as_yaml_with_short_format_flag(self):
        self.assert_matches_original(
            ["-oy", ".", "sample.json"],
            {"sample.json": '{"a":{"b":[1,2]},"name":"bob"}\n'},
        )


if __name__ == "__main__":
    unittest.main()
