#!/usr/bin/env python3
import json
import os
import re
import sys
from pathlib import Path


MISSING = object()


def parse_scalar(text):
    text = text.strip()
    env_match = re.fullmatch(r"strenv\(([^)]+)\)", text)
    if env_match:
        return os.environ.get(env_match.group(1), "")
    if text in ("", "null", "~"):
        return None
    if text == "true":
        return True
    if text == "false":
        return False
    if (text.startswith('"') and text.endswith('"')) or (text.startswith("'") and text.endswith("'")):
        return text[1:-1]
    try:
        return int(text)
    except ValueError:
        pass
    return text


def parse_yaml(text):
    lines = [line.rstrip("\n") for line in text.splitlines() if line.strip() and not line.lstrip().startswith("#")]

    def parse_block(index, indent):
        is_list = False
        items = []
        mapping = {}
        while index < len(lines):
            line = lines[index]
            cur_indent = len(line) - len(line.lstrip(" "))
            if cur_indent < indent:
                break
            if cur_indent > indent:
                break
            stripped = line.strip()
            if stripped.startswith("- "):
                is_list = True
                rest = stripped[2:].strip()
                if rest and ":" in rest and not rest.startswith(('"', "'")):
                    key, val = rest.split(":", 1)
                    item = {key.strip(): parse_scalar(val)}
                    index += 1
                    if index < len(lines):
                        next_indent = len(lines[index]) - len(lines[index].lstrip(" "))
                        if next_indent > cur_indent:
                            child, index = parse_block(index, next_indent)
                            if isinstance(child, dict):
                                item.update(child)
                    items.append(item)
                elif rest:
                    items.append(parse_scalar(rest))
                    index += 1
                else:
                    child, index = parse_block(index + 1, cur_indent + 2)
                    items.append(child)
            else:
                key, sep, val = stripped.partition(":")
                if not sep:
                    index += 1
                    continue
                if val.strip():
                    mapping[key.strip()] = parse_scalar(val)
                    index += 1
                else:
                    child, index = parse_block(index + 1, cur_indent + 2)
                    mapping[key.strip()] = child
        return (items if is_list else mapping), index

    if not lines:
        return None
    doc, _ = parse_block(0, len(lines[0]) - len(lines[0].lstrip(" ")))
    return doc


def tokenize_path(expr):
    expr = expr.strip()
    if expr == ".":
        return []
    if not expr.startswith("."):
        raise ValueError("unsupported expression")
    out = []
    i = 1
    while i < len(expr):
        if expr[i] == ".":
            i += 1
            continue
        match = re.match(r"[A-Za-z_][A-Za-z0-9_-]*", expr[i:])
        if not match:
            break
        out.append(match.group(0))
        i += len(match.group(0))
        while i < len(expr) and expr[i] == "[":
            end = expr.index("]", i)
            inside = expr[i + 1:end]
            out.append("*" if inside == "" else int(inside))
            i = end + 1
    return out


def evaluate_path(data, expr):
    values = [data]
    for token in tokenize_path(expr):
        next_values = []
        for value in values:
            if token == "*":
                if isinstance(value, list):
                    next_values.extend(value)
            elif isinstance(token, int):
                if isinstance(value, list) and token < len(value):
                    next_values.append(value[token])
            else:
                if isinstance(value, dict) and token in value:
                    next_values.append(value[token])
        values = next_values
    if not values:
        return MISSING
    if "*" in tokenize_path(expr):
        return values
    return values[0]


def evaluate(data, expr):
    expr = expr.strip()
    if expr.startswith("[") and expr.endswith("]"):
        inner = expr[1:-1].strip()
        result = evaluate(data, inner)
        if result is MISSING:
            return []
        return result if isinstance(result, list) else [result]
    if "|" in expr:
        left, right = [part.strip() for part in expr.split("|", 1)]
        left_value = evaluate_path(data, left)
        values = left_value if isinstance(left_value, list) else [left_value]
        match = re.fullmatch(r"""select\((\.[^) ]+)\s*==\s*("([^"]*)"|'([^']*)'|[^)]+)\)""", right)
        if match:
            path = match.group(1)
            wanted = match.group(3) if match.group(3) is not None else match.group(4)
            if wanted is None:
                wanted = parse_scalar(match.group(2))
            return [item for item in values if evaluate_path(item, path) == wanted]
    if expr.startswith("{") or expr.startswith("["):
        try:
            return json.loads(expr)
        except json.JSONDecodeError:
            pass
    return evaluate_path(data, expr)


def assign_path(expr):
    left, right = expr.split("=", 1)
    tokens = tokenize_path(left.strip())
    value = parse_scalar(right.strip())
    root = {}
    cur = root
    for token in tokens[:-1]:
        nxt = {}
        cur[token] = nxt
        cur = nxt
    if tokens:
        cur[tokens[-1]] = value
    return root


def set_path(data, expr):
    left, right = expr.split("=", 1)
    tokens = tokenize_path(left.strip())
    value = parse_scalar(right.strip())
    if data is None:
        data = {}
    cur = data
    for idx, token in enumerate(tokens[:-1]):
        nxt_token = tokens[idx + 1]
        if isinstance(token, int):
            while len(cur) <= token:
                cur.append({} if not isinstance(nxt_token, int) else [])
            if cur[token] is None:
                cur[token] = {} if not isinstance(nxt_token, int) else []
            cur = cur[token]
        else:
            if token not in cur or cur[token] is None:
                cur[token] = [] if isinstance(nxt_token, int) else {}
            cur = cur[token]
    if tokens:
        last = tokens[-1]
        if isinstance(last, int):
            while len(cur) <= last:
                cur.append(None)
            cur[last] = value
        else:
            cur[last] = value
    return data


def parse_input(text, filename):
    stripped = text.lstrip()
    if filename.endswith(".json") or stripped.startswith("{") or stripped.startswith("["):
        return json.loads(text)
    return parse_yaml(text)


def dump_yaml(value, indent=0):
    sp = " " * indent
    if isinstance(value, dict):
        lines = []
        for key, val in value.items():
            if isinstance(val, (dict, list)):
                lines.append(f"{sp}{key}:")
                lines.append(dump_yaml(val, indent + 2))
            else:
                lines.append(f"{sp}{key}: {format_scalar(val)}")
        return "\n".join(lines)
    if isinstance(value, list):
        lines = []
        for item in value:
            if isinstance(item, dict):
                first = True
                for key, val in item.items():
                    if first:
                        if isinstance(val, (dict, list)):
                            lines.append(f"{sp}- {key}:")
                            lines.append(dump_yaml(val, indent + 2))
                        else:
                            lines.append(f"{sp}- {key}: {format_scalar(val)}")
                        first = False
                    else:
                        if isinstance(val, (dict, list)):
                            lines.append(f"{sp}  {key}:")
                            lines.append(dump_yaml(val, indent + 4))
                        else:
                            lines.append(f"{sp}  {key}: {format_scalar(val)}")
            else:
                lines.append(f"{sp}- {format_scalar(item)}")
        return "\n".join(lines)
    return format_scalar(value)


def format_scalar(value):
    if value is None:
        return "null"
    if value is True:
        return "true"
    if value is False:
        return "false"
    return str(value)


def main(argv):
    if not argv or argv[0] in ("--help", "-h", "help"):
        print("yq is a portable command-line data file processor (https://github.com/mikefarah/yq/) ")
        print("Usage:\n  yq [flags]\n  yq [command]")
        return 0
    if argv[0] in ("--version", "-V"):
        print("yq (https://github.com/mikefarah/yq/) version v4.52.5")
        return 0
    if argv[0] in ("eval", "e", "eval-all", "ea"):
        argv = argv[1:]
    output_format = "auto"
    null_input = False
    inplace = False
    filtered = []
    i = 0
    while i < len(argv):
        arg = argv[i]
        if arg in ("-n", "--null-input"):
            null_input = True
        elif arg in ("-i", "--inplace"):
            inplace = True
        elif arg in ("-o", "--output-format"):
            i += 1
            output_format = argv[i]
        elif arg.startswith("-o="):
            output_format = arg.split("=", 1)[1]
        elif arg.startswith("-o") and len(arg) > 2:
            output_format = arg[2:]
        elif arg in ("-p", "--input-format"):
            i += 1
        elif arg.startswith("-p=") or (arg.startswith("-p") and len(arg) > 2):
            pass
        elif arg in ("-P", "--prettyPrint", "-M", "--no-colors"):
            pass
        else:
            filtered.append(arg)
        i += 1
    expr = filtered[0] if filtered else "."
    filename = filtered[1] if len(filtered) > 1 else "-"
    if null_input:
        data = None
    else:
        text = sys.stdin.read() if filename == "-" else Path(filename).read_text(encoding="utf-8")
        data = parse_input(text, filename)
    if inplace and "=" in expr:
        result = set_path(data, expr)
        Path(filename).write_text(dump_yaml(result) + "\n", encoding="utf-8")
        return 0
    result = assign_path(expr) if null_input and "=" in expr else evaluate(data, expr)
    if output_format in ("auto", "a"):
        output_format = "json" if filename.endswith(".json") else "yaml"
    if output_format in ("y", "yaml"):
        output_format = "yaml"
    if result is MISSING:
        print("null")
    elif output_format in ("json", "j"):
        print(json.dumps(result, indent=2))
    elif isinstance(result, (dict, list)):
        if isinstance(result, list) and "[]" in expr and not expr.strip().startswith("["):
            print("\n".join(dump_yaml(item) if isinstance(item, (dict, list)) else format_scalar(item) for item in result))
        else:
            print(dump_yaml(result))
    else:
        print(format_scalar(result))
    return 0


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
