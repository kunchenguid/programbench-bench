package main

import (
	"bytes"
	"encoding/json"
	"flag"
	"fmt"
	"go/ast"
	"go/importer"
	"go/parser"
	"go/printer"
	"go/token"
	"go/types"
	"os"
	"os/exec"
	"path/filepath"
	"regexp"
	"sort"
	"strings"
)

type multiFlag []string

func (m *multiFlag) String() string     { return strings.Join(*m, ",") }
func (m *multiFlag) Set(s string) error { *m = append(*m, s); return nil }

type options struct {
	asserts, blank, abspath, excludeOnly, ignoreTests, ignoreGenerated, verbose bool
	exclude, ignorepkg, mod                                                     string
	ignore, tags                                                                multiFlag
}

type pkgJSON struct {
	ImportPath, Dir                              string
	GoFiles, CgoFiles, TestGoFiles, XTestGoFiles []string
}

type ignoreRule struct {
	pkg string
	rx  *regexp.Regexp
}
type finding struct {
	file           string
	line, col, idx int
	text           string
}

type checker struct {
	opt         options
	fset        *token.FileSet
	lines       map[string][]string
	findings    []finding
	info        *types.Info
	ignorePkgs  map[string]bool
	ignoreRules []ignoreRule
	excludes    map[string]bool
}

func main() {
	flag.CommandLine.Init(os.Args[0], flag.ContinueOnError)
	var opt options
	flag.BoolVar(&opt.abspath, "abspath", false, "print absolute paths to files")
	flag.BoolVar(&opt.asserts, "asserts", false, "if true, check for ignored type assertion results")
	flag.BoolVar(&opt.blank, "blank", false, "if true, check for errors assigned to blank identifier")
	flag.StringVar(&opt.exclude, "exclude", "", "Path to a file containing a list of functions to exclude from checking")
	flag.BoolVar(&opt.excludeOnly, "excludeonly", false, "Use only excludes from -exclude file")
	flag.Var(&opt.ignore, "ignore", "[deprecated] comma-separated list of pairs of the form pkg:regex\n            the regex is used to ignore names within pkg.")
	flag.BoolVar(&opt.ignoreGenerated, "ignoregenerated", false, "if true, checking of files with generated code is disabled")
	flag.StringVar(&opt.ignorepkg, "ignorepkg", "", "comma-separated list of package paths to ignore")
	flag.BoolVar(&opt.ignoreTests, "ignoretests", false, "if true, checking of _test.go files is disabled")
	flag.StringVar(&opt.mod, "mod", "", "module download mode to use: readonly or vendor. See 'go help modules' for more.")
	flag.Var(&opt.tags, "tags", "comma or space-separated list of build tags to include")
	flag.BoolVar(&opt.verbose, "verbose", false, "produce more verbose logging")
	if err := flag.CommandLine.Parse(os.Args[1:]); err != nil {
		os.Exit(2)
	}
	if flag.NArg() == 0 {
		os.Exit(0)
	}

	pkgs, err := loadPackages(flag.Args(), opt)
	if err != nil {
		fmt.Fprintf(os.Stderr, "error: failed to check packages: %v\n", err)
		os.Exit(2)
	}
	ex, err := readExcludes(opt.exclude)
	if err != nil {
		fmt.Fprintf(os.Stderr, "error: failed to read exclude file: %v\n", err)
		os.Exit(2)
	}
	c := &checker{opt: opt, fset: token.NewFileSet(), lines: map[string][]string{}, excludes: ex}
	c.initIgnores()
	for _, p := range pkgs {
		if err := c.checkPackage(p); err != nil {
			fmt.Fprintf(os.Stderr, "error: failed to check packages: %v\n", err)
			os.Exit(2)
		}
	}
	sort.SliceStable(c.findings, func(i, j int) bool { return c.findings[i].idx < c.findings[j].idx })
	wd, _ := os.Getwd()
	for _, f := range c.findings {
		name := f.file
		if c.opt.abspath {
			if abs, err := filepath.Abs(name); err == nil {
				name = abs
			}
		} else if rel, err := filepath.Rel(wd, name); err == nil && !strings.HasPrefix(rel, "..") {
			name = rel
		}
		fmt.Printf("%s:%d:%d:\t%s\n", filepath.ToSlash(name), f.line, f.col, f.text)
	}
	if len(c.findings) > 0 {
		os.Exit(1)
	}
}

func loadPackages(args []string, opt options) ([]pkgJSON, error) {
	cmdArgs := []string{"list", "-json"}
	if opt.mod != "" {
		cmdArgs = append(cmdArgs, "-mod="+opt.mod)
	}
	if len(opt.tags) > 0 {
		cmdArgs = append(cmdArgs, "-tags", strings.Join(opt.tags, " "))
	}
	cmdArgs = append(cmdArgs, args...)
	cmd := exec.Command("go", cmdArgs...)
	var out, er bytes.Buffer
	cmd.Stdout, cmd.Stderr = &out, &er
	if err := cmd.Run(); err != nil {
		return nil, fmt.Errorf("err: %v: stderr: %s", err, strings.TrimSpace(er.String()))
	}
	dec := json.NewDecoder(&out)
	var pkgs []pkgJSON
	for dec.More() {
		var p pkgJSON
		if err := dec.Decode(&p); err != nil {
			return nil, err
		}
		pkgs = append(pkgs, p)
	}
	return pkgs, nil
}

func readExcludes(path string) (map[string]bool, error) {
	m := map[string]bool{}
	if path == "" {
		return m, nil
	}
	b, err := os.ReadFile(path)
	if err != nil {
		return m, err
	}
	for _, line := range strings.Split(string(b), "\n") {
		line = strings.TrimSpace(line)
		if line != "" && !strings.HasPrefix(line, "//") {
			m[line] = true
		}
	}
	return m, nil
}

func (c *checker) initIgnores() {
	c.ignorePkgs = map[string]bool{}
	for _, p := range strings.Split(c.opt.ignorepkg, ",") {
		p = strings.TrimSpace(p)
		if p != "" {
			c.ignorePkgs[p] = true
		}
	}
	for _, raw := range c.opt.ignore {
		for _, part := range strings.Split(raw, ",") {
			part = strings.TrimSpace(part)
			if part == "" {
				continue
			}
			pkg, re, ok := strings.Cut(part, ":")
			if !ok {
				pkg, re = "", part
			}
			if rx, err := regexp.Compile(re); err == nil {
				c.ignoreRules = append(c.ignoreRules, ignoreRule{pkg, rx})
			}
		}
	}
}

func (c *checker) checkPackage(p pkgJSON) error {
	var base []string
	for _, f := range append(p.GoFiles, p.CgoFiles...) {
		base = append(base, filepath.Join(p.Dir, f))
	}
	if !c.opt.ignoreTests {
		for _, f := range p.TestGoFiles {
			base = append(base, filepath.Join(p.Dir, f))
		}
	}
	if err := c.checkFiles(p.ImportPath, base); err != nil {
		return err
	}
	if !c.opt.ignoreTests && len(p.XTestGoFiles) > 0 {
		var xt []string
		for _, f := range p.XTestGoFiles {
			xt = append(xt, filepath.Join(p.Dir, f))
		}
		if err := c.checkFiles(p.ImportPath+"_test", xt); err != nil {
			return err
		}
	}
	return nil
}

func (c *checker) checkFiles(importPath string, paths []string) error {
	var files []*ast.File
	for _, path := range paths {
		if c.opt.ignoreGenerated && isGenerated(path) {
			continue
		}
		src, err := os.ReadFile(path)
		if err != nil {
			return err
		}
		c.lines[path] = strings.Split(string(src), "\n")
		f, err := parser.ParseFile(c.fset, path, src, parser.ParseComments)
		if err != nil {
			return err
		}
		files = append(files, f)
	}
	if len(files) == 0 {
		return nil
	}
	c.info = &types.Info{Types: map[ast.Expr]types.TypeAndValue{}, Uses: map[*ast.Ident]types.Object{}, Selections: map[*ast.SelectorExpr]*types.Selection{}}
	conf := types.Config{Importer: importer.ForCompiler(c.fset, "source", nil)}
	if _, err := conf.Check(importPath, c.fset, files, c.info); err != nil {
		return err
	}
	for _, f := range files {
		c.walkFile(f)
	}
	return nil
}

func isGenerated(path string) bool {
	b, err := os.ReadFile(path)
	if err != nil {
		return false
	}
	s := string(b)
	if len(s) > 2048 {
		s = s[:2048]
	}
	return strings.Contains(s, "Code generated") && strings.Contains(s, "DO NOT EDIT")
}

func (c *checker) walkFile(f *ast.File) {
	ast.Inspect(f, func(n ast.Node) bool {
		switch s := n.(type) {
		case *ast.ExprStmt:
			if call, ok := s.X.(*ast.CallExpr); ok && c.callReturnsError(call) && !c.ignoredCall(call) {
				c.add(call.Lparen, s)
			}
		case *ast.GoStmt:
			if c.callReturnsError(s.Call) && !c.ignoredCall(s.Call) {
				c.add(s.Call.Lparen, s)
			}
		case *ast.DeferStmt:
			if c.callReturnsError(s.Call) && !c.ignoredCall(s.Call) {
				c.add(s.Call.Lparen, s)
			}
		case *ast.AssignStmt:
			c.checkAssign(s)
			if c.opt.asserts {
				c.checkAssertAssign(s)
			}
		case *ast.ValueSpec:
			if c.opt.asserts {
				c.checkAssertValues(s)
			}
		}
		return true
	})
}

func (c *checker) checkAssign(s *ast.AssignStmt) {
	if !c.opt.blank {
		return
	}
	for ri, rhs := range s.Rhs {
		call, ok := rhs.(*ast.CallExpr)
		if !ok || c.ignoredCall(call) {
			continue
		}
		for _, ei := range c.errorResultPositions(call) {
			li := ri
			if len(s.Rhs) == 1 {
				li = ei
			}
			if li < len(s.Lhs) {
				if id, ok := s.Lhs[li].(*ast.Ident); ok && id.Name == "_" {
					c.add(id.Pos(), s)
					break
				}
			}
		}
	}
}

func (c *checker) checkAssertAssign(s *ast.AssignStmt) {
	if len(s.Rhs) == 1 {
		if ta, ok := s.Rhs[0].(*ast.TypeAssertExpr); ok && len(s.Lhs) != 2 {
			c.add(ta.X.Pos(), s)
		}
	}
}
func (c *checker) checkAssertValues(s *ast.ValueSpec) {
	for _, v := range s.Values {
		if ta, ok := v.(*ast.TypeAssertExpr); ok {
			c.add(ta.X.Pos(), s)
		}
	}
}

func (c *checker) callReturnsError(call *ast.CallExpr) bool {
	return len(c.errorResultPositions(call)) > 0
}
func (c *checker) errorResultPositions(call *ast.CallExpr) []int {
	tv, ok := c.info.Types[call]
	if !ok || tv.Type == nil {
		return nil
	}
	errT := types.Universe.Lookup("error").Type().Underlying().(*types.Interface)
	var out []int
	if tup, ok := tv.Type.(*types.Tuple); ok {
		for i := 0; i < tup.Len(); i++ {
			if implementsError(tup.At(i).Type(), errT) {
				out = append(out, i)
			}
		}
	} else if implementsError(tv.Type, errT) {
		out = append(out, 0)
	}
	return out
}
func implementsError(t types.Type, errT *types.Interface) bool {
	return t != nil && (types.Implements(t, errT) || types.Implements(types.NewPointer(t), errT))
}

func (c *checker) ignoredCall(call *ast.CallExpr) bool {
	pkg, name, full := c.callName(call)
	if full != "" && c.excludes[full] && isSelectorCall(call) {
		return true
	}
	if c.ignorePkgs[pkg] {
		return true
	}
	for _, r := range c.ignoreRules {
		if (r.pkg == "" || r.pkg == pkg) && r.rx.MatchString(name) {
			return true
		}
	}
	if !c.opt.excludeOnly && pkg == "fmt" {
		return true
	}
	return false
}

func isSelectorCall(call *ast.CallExpr) bool { _, ok := call.Fun.(*ast.SelectorExpr); return ok }

func (c *checker) callName(call *ast.CallExpr) (pkg, name, full string) {
	switch fun := call.Fun.(type) {
	case *ast.SelectorExpr:
		name = fun.Sel.Name
		if sel := c.info.Selections[fun]; sel != nil {
			if obj := sel.Obj(); obj != nil && obj.Pkg() != nil {
				pkg = obj.Pkg().Path()
				full = pkg + "." + obj.Name()
			}
		} else if obj := c.info.Uses[fun.Sel]; obj != nil && obj.Pkg() != nil {
			pkg = obj.Pkg().Path()
			full = pkg + "." + obj.Name()
		}
		if pkg == "" {
			if id, ok := fun.X.(*ast.Ident); ok {
				pkg = id.Name
			}
		}
	case *ast.Ident:
		name = fun.Name
		if obj := c.info.Uses[fun]; obj != nil && obj.Pkg() != nil {
			pkg = obj.Pkg().Path()
			full = pkg + "." + obj.Name()
		}
	}
	return
}

func (c *checker) add(pos token.Pos, node ast.Node) {
	p := c.fset.Position(pos)
	c.findings = append(c.findings, finding{file: p.Filename, line: p.Line, col: p.Column, text: c.lineText(p.Filename, p.Line, node), idx: int(pos)})
}
func (c *checker) lineText(file string, line int, node ast.Node) string {
	if ls := c.lines[file]; line > 0 && line <= len(ls) {
		return strings.TrimSpace(ls[line-1])
	}
	var b bytes.Buffer
	_ = printer.Fprint(&b, c.fset, node)
	return b.String()
}
