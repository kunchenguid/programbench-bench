module errcheckclone

go 1.21
