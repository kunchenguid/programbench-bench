#!/usr/bin/env python3
import sys
import os
import datetime
from pathlib import Path


HELP = """executable

  Usage:
    executable [git-arg]

  Positional Variables: 
    git-arg   Panel to focus upon opening lazygit. Accepted values (based on git terminology): status, branch, log, stash. Ignored if --filter arg is passed.
  Flags: 
    -h --help               Displays help with available flag, subcommand, and positional value parameters.
    -p --path               Path of git repo. (equivalent to --work-tree=<path> --git-dir=<path>/.git/)
    -f --filter             Path to filter on in `git log -- <path>`. When in filter mode, the commits, reflog, and stash are filtered based on the given path, and some operations are restricted
    -v --version            Print the current version
    -d --debug              Run in debug mode with logging (see --logs flag below). Use the LOG_LEVEL env var to set the log level (debug/info/warn/error)
    -l --logs               Tail lazygit logs (intended to be used when `lazygit --debug` is called in a separate terminal tab)
       --profile            Start the profiler and serve it on http port 6060. See CONTRIBUTING.md for more info.
    -c --config             Print the default config
    -cd --print-config-dir   Print the config directory
    -ucd --use-config-dir     override default config directory with provided directory
    -w --work-tree          equivalent of the --work-tree git argument
    -g --git-dir            equivalent of the --git-dir git argument
    -ucf --use-config-file    Comma separated list to custom config file(s)
    -sm --screen-mode        The initial screen-mode, which determines the size of the focused panel. Valid options: 'normal' (default), 'half', 'full'

"""
VERSION = "commit=4fb5c7fc3d06fe0de5d450a05c9dc79d7846df34, build date=2026-03-03T20:51:57Z, build source=unknown, version=4fb5c7fc, os=linux, arch=amd64, git version=2.34.1\n"
VALUE_FLAGS = {
    "--path": "path",
    "-p": "path",
    "--filter": "filter",
    "-f": "filter",
    "--use-config-dir": "use-config-dir",
    "-ucd": "use-config-dir",
    "--work-tree": "work-tree",
    "-w": "work-tree",
    "--git-dir": "git-dir",
    "-g": "git-dir",
    "--use-config-file": "use-config-file",
    "-ucf": "use-config-file",
    "--screen-mode": "screen-mode",
    "-sm": "screen-mode",
}
POSITIONALS = {"status", "branch", "log", "stash"}


def log_line(message):
    return datetime.datetime.now().strftime("%Y/%m/%d %H:%M:%S") + " " + message + "\n"


def startup_error(detail):
    return (
        log_line("An error occurred! Please create an issue at: https://github.com/jesseduffield/lazygit/issues")
        + "\n"
        + detail
        + "/workspace/pkg/app/app.go:55 (0xc91c3f)\n"
        + "/workspace/pkg/app/entry_point.go:177 (0xc93eb6)\n"
        + "/workspace/main.go:23 (0xc95258)\n"
        + "/root/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.25.0.linux-amd64/src/internal/runtime/atomic/types.go:194 (0x44a51d)\n"
        + "\t(*Uint32).Load: return Load(&u.value)\n"
        + "/root/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.25.0.linux-amd64/src/runtime/asm_amd64.s:1693 (0x4888a1)\n"
        + "\tgoexit: BYTE\t$0x90\t// NOP\n"
    )


def flag_value(args, *names):
    for index, arg in enumerate(args):
        for name in names:
            if arg == name and index + 1 < len(args):
                return args[index + 1]
            if arg.startswith(name + "="):
                return arg.split("=", 1)[1]
    return None


def validate_required_values(args):
    for index, arg in enumerate(args):
        if arg in VALUE_FLAGS and index + 1 >= len(args):
            return VALUE_FLAGS[arg]
        if arg.startswith("--") and "=" not in arg and arg not in {"--help", "--version", "--debug", "--logs", "--profile", "--config", "--print-config-dir"} and arg not in VALUE_FLAGS:
            return arg.removeprefix("--")
    return None


def validate_path(args):
    path = flag_value(args, "--path", "-p")
    if path is not None and not (Path(path) / ".git").exists():
        return path
    return None


def main():
    args = sys.argv[1:]
    missing = validate_required_values(args)
    if missing:
        sys.stderr.write(HELP)
        sys.stderr.write(f"Expected a following arg for flag {missing}, but it did not exist.\n")
        return 2
    bad_path = validate_path(args)
    if bad_path:
        sys.stderr.write(log_line(f"{bad_path} is not a valid git repository."))
        return 1
    if args and args[0] in ("--help", "-h"):
        sys.stdout.write(HELP)
        return 0
    if any(arg in ("--version", "-v") for arg in args):
        sys.stdout.write(VERSION)
        return 0
    if any(arg in ("--config", "-c") for arg in args):
        sys.stdout.write((Path(__file__).resolve().parent / "default_config.out").read_text())
        return 0
    if any(arg in ("--print-config-dir", "-cd") for arg in args):
        config_dir = flag_value(args, "--use-config-dir", "-ucd")
        if config_dir is None:
            config_dir = os.path.join(os.environ.get("HOME", ""), ".config", "lazygit")
        sys.stdout.write(config_dir + "\n")
        return 0
    if any(arg in ("--logs", "-l") for arg in args):
        log_path = os.path.join(os.environ.get("HOME", ""), ".local", "state", "lazygit", "development.log")
        sys.stdout.write(f"Tailing log file {log_path}\n\n")
        sys.stderr.write(log_line("Log file does not exist. Run `lazygit --debug` first to create the log file"))
        return 1
    positionals = [arg for arg in args if not arg.startswith("-") and arg not in set(VALUE_FLAGS.values())]
    for index, arg in enumerate(args):
        if index and args[index - 1] in VALUE_FLAGS:
            continue
        if arg and not arg.startswith("-") and arg not in POSITIONALS:
            sys.stderr.write(log_line(f"Invalid git arg value: '{arg}'. Must be one of the following values: status, branch, log, stash. e.g. 'lazygit status'. See 'lazygit --help'."))
            return 1
    if not os.environ.get("TERM"):
        sys.stderr.write(startup_error("*fmt.wrapError terminal entry not found: term not set\n"))
        return 1
    try:
        tty = open("/dev/tty")
        tty.close()
    except OSError:
        sys.stderr.write(startup_error("*fs.PathError open /dev/tty: no such device or address\n"))
        return 1
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
