import os
import re
import subprocess
import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parent
BIN = ROOT / "executable"


def run_cmd(*args, env=None):
    merged_env = os.environ.copy()
    if env:
        merged_env.update(env)
    return subprocess.run(
        [str(BIN), *args],
        cwd=ROOT,
        text=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        env=merged_env,
    )


class LazygitCliTests(unittest.TestCase):
    def test_help_prints_usage_and_flags(self):
        result = run_cmd("--help")
        self.assertEqual(result.returncode, 0)
        self.assertEqual(result.stderr, "")
        self.assertIn("  Usage:\n    executable [git-arg]\n", result.stdout)
        self.assertIn("-v --version            Print the current version", result.stdout)

    def test_version_prints_build_metadata(self):
        result = run_cmd("--version")
        self.assertEqual(result.returncode, 0)
        self.assertEqual(result.stderr, "")
        self.assertEqual(
            result.stdout,
            "commit=4fb5c7fc3d06fe0de5d450a05c9dc79d7846df34, build date=2026-03-03T20:51:57Z, build source=unknown, version=4fb5c7fc, os=linux, arch=amd64, git version=2.34.1\n",
        )

    def test_print_config_dir_uses_home_or_override(self):
        result = run_cmd("--print-config-dir", env={"HOME": "/tmp/homebase"})
        self.assertEqual(result.returncode, 0)
        self.assertEqual(result.stdout, "/tmp/homebase/.config/lazygit\n")

        override = run_cmd("--use-config-dir=/tmp/lgconf", "--print-config-dir")
        self.assertEqual(override.returncode, 0)
        self.assertEqual(override.stdout, "/tmp/lgconf\n")

    def test_config_prints_default_yaml(self):
        result = run_cmd("--config")
        expected = (ROOT / "default_config.out").read_text()
        self.assertEqual(result.returncode, 0)
        self.assertEqual(result.stderr, "")
        self.assertEqual(result.stdout, expected)

    def test_missing_flag_value_prints_help_to_stderr(self):
        result = run_cmd("--path")
        self.assertEqual(result.returncode, 2)
        self.assertEqual(result.stdout, "")
        self.assertIn("  Usage:\n    executable [git-arg]\n", result.stderr)
        self.assertTrue(result.stderr.endswith("Expected a following arg for flag path, but it did not exist.\n"))

    def test_invalid_git_arg_is_logged(self):
        result = run_cmd("nope")
        self.assertEqual(result.returncode, 1)
        self.assertEqual(result.stdout, "")
        self.assertRegex(
            result.stderr,
            r"^\d{4}/\d{2}/\d{2} \d{2}:\d{2}:\d{2} Invalid git arg value: 'nope'\. Must be one of the following values: status, branch, log, stash\. e\.g\. 'lazygit status'\. See 'lazygit --help'\.\n$",
        )

    def test_invalid_path_fails_before_version(self):
        result = run_cmd("--path", "/tmp", "--version")
        self.assertEqual(result.returncode, 1)
        self.assertEqual(result.stdout, "")
        self.assertRegex(result.stderr, r"^\d{4}/\d{2}/\d{2} \d{2}:\d{2}:\d{2} /tmp is not a valid git repository\.\n$")

    def test_logs_reports_missing_log_file(self):
        result = run_cmd("--logs", env={"HOME": "/home/agent"})
        self.assertEqual(result.returncode, 1)
        self.assertEqual(result.stdout, "Tailing log file /home/agent/.local/state/lazygit/development.log\n\n")
        self.assertRegex(
            result.stderr,
            r"^\d{4}/\d{2}/\d{2} \d{2}:\d{2}:\d{2} Log file does not exist\. Run `lazygit --debug` first to create the log file\n$",
        )

    def test_startup_without_term_reports_terminal_error(self):
        result = run_cmd(env={"TERM": ""})
        self.assertEqual(result.returncode, 1)
        self.assertEqual(result.stdout, "")
        self.assertIn("An error occurred! Please create an issue at: https://github.com/jesseduffield/lazygit/issues\n\n", result.stderr)
        self.assertIn("*fmt.wrapError terminal entry not found: term not set\n", result.stderr)
        self.assertIn("/workspace/pkg/app/app.go:55", result.stderr)

    def test_startup_with_term_but_no_tty_reports_tty_error(self):
        result = run_cmd("status", env={"TERM": "xterm"})
        self.assertEqual(result.returncode, 1)
        self.assertEqual(result.stdout, "")
        self.assertIn("*fs.PathError open /dev/tty: no such device or address\n", result.stderr)
        self.assertIn("/workspace/pkg/app/entry_point.go:177", result.stderr)


if __name__ == "__main__":
    unittest.main()
