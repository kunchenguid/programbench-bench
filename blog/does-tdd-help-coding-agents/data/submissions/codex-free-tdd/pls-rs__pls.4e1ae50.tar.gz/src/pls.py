#!/usr/bin/env python3
import fnmatch
import grp
import os
import pwd
import stat
import sys
from datetime import datetime


VERSION = "pls 0.0.1-beta.9"
PROG = "executable"
DETAILS = [
    "dev", "ino", "nlink", "typ", "perm", "oct", "user", "uid", "group", "gid",
    "size", "blocks", "btime", "ctime", "mtime", "atime", "git", "none", "std", "all",
]
TYPES = ["dir", "symlink", "fifo", "socket", "block-device", "char-device", "file", "none", "all"]
BOOLS = ["true", "false"]
SORTS = [
    "dev", "ino", "nlink", "typ", "cat", "user", "uid", "group", "gid", "size", "blocks",
    "btime", "ctime", "mtime", "atime", "name", "cname", "ext", "inode_", "nlinks_", "typ_",
    "cat_", "user_", "uid_", "group_", "gid_", "size_", "blocks_", "btime_", "ctime_",
    "mtime_", "atime_", "name_", "cname_", "ext_", "none",
]

HELP = """pls is a prettier and powerful ls(1) for the pros.

Read docs: https://pls.cli.rs/
Get source: https://github.com/pls-rs/pls/
Sponsor: https://github.com/sponsors/dhruvkb/

Usage: executable [OPTIONS] [PATHS]...

Arguments:
  [PATHS]...
          the paths to list, each of which may be a file or directory
          
          [default: .]

Options:
  -h, --help
          Print help (see a summary with '-h')

  -V, --version
          Print version

Detail view:
  -d, --det <DETAILS>
          the data points to show about each node
          
          [default: none]
          [possible values: dev, ino, nlink, typ, perm, oct, user, uid, group, gid, size, blocks,
          btime, ctime, mtime, atime, git, none, std, all]

  -H, --header <HEADER>
          show headers above columnar data
          
          [default: true]
          [possible values: true, false]

  -u, --unit <UNIT>
          the type of units to use for the node sizes
          
          [default: binary]
          [possible values: binary, decimal, none]

Grid view:
  -g, --grid <GRID>
          display node names in multiple columns
          
          [default: false]
          [possible values: true, false]

  -D, --down <DOWN>
          display node names column-first
          
          [default: false]
          [possible values: true, false]

Presentation:
  -i, --icon <ICON>
          display icons next to node names
          
          [default: true]
          [possible values: true, false]

  -S, --suffix <SUFFIX>
          display node type suffixes after the node name
          
          [default: true]
          [possible values: true, false]

  -l, --sym <SYM>
          show symlink targets
          
          [default: true]
          [possible values: true, false]

  -c, --collapse <COLLAPSE>
          show dependent nodes as children of their principal nodes
          
          [default: true]
          [possible values: true, false]

  -a, --align <ALIGN>
          align items accounting for leading dots
          
          [default: true]
          [possible values: true, false]

Filtering:
  -t, --typ <TYPES>
          the set of node types to include in the output
          
          [default: all]
          [possible values: dir, symlink, fifo, socket, block-device, char-device, file, none, all]

  -I, --imp <IMP>
          the importance cutoff to dim or hide unimportant files
          
          [default: 0]

  -e, --exclude <EXCLUDE>
          the pattern of files to selectively hide from the output

  -o, --only <ONLY>
          the pattern of files to exclusively show in the output

Sorting:
  -s, --sort <SORT_BASES>
          the set of fields to sort by, trailing `_` reverses the direction
          
          [default: cat cname]
          [possible values: dev, ino, nlink, typ, cat, user, uid, group, gid, size, blocks, btime,
          ctime, mtime, atime, name, cname, ext, inode_, nlinks_, typ_, cat_, user_, uid_, group_,
          gid_, size_, blocks_, btime_, ctime_, mtime_, atime_, name_, cname_, ext_, none]
"""

SHORT_HELP = """pls is a prettier and powerful ls(1) for the pros.

Usage: {prog} [OPTIONS] [PATHS]...

Arguments:
  [PATHS]...  the paths to list, each of which may be a file or directory [default: .]

Options:
  -h, --help     Print help (see more with '--help')
  -V, --version  Print version

Detail view:
  -d, --det <DETAILS>    the data points to show about each node [default: none] [possible values:
                         dev, ino, nlink, typ, perm, oct, user, uid, group, gid, size, blocks,
                         btime, ctime, mtime, atime, git, none, std, all]
  -H, --header <HEADER>  show headers above columnar data [default: true] [possible values: true,
                         false]
  -u, --unit <UNIT>      the type of units to use for the node sizes [default: binary] [possible
                         values: binary, decimal, none]

Grid view:
  -g, --grid <GRID>  display node names in multiple columns [default: false] [possible values: true,
                     false]
  -D, --down <DOWN>  display node names column-first [default: false] [possible values: true, false]

Presentation:
  -i, --icon <ICON>          display icons next to node names [default: true] [possible values:
                             true, false]
  -S, --suffix <SUFFIX>      display node type suffixes after the node name [default: true]
                             [possible values: true, false]
  -l, --sym <SYM>            show symlink targets [default: true] [possible values: true, false]
  -c, --collapse <COLLAPSE>  show dependent nodes as children of their principal nodes [default:
                             true] [possible values: true, false]
  -a, --align <ALIGN>        align items accounting for leading dots [default: true] [possible
                             values: true, false]

Filtering:
  -t, --typ <TYPES>        the set of node types to include in the output [default: all] [possible
                           values: dir, symlink, fifo, socket, block-device, char-device, file,
                           none, all]
  -I, --imp <IMP>          the importance cutoff to dim or hide unimportant files [default: 0]
  -e, --exclude <EXCLUDE>  the pattern of files to selectively hide from the output
  -o, --only <ONLY>        the pattern of files to exclusively show in the output

Sorting:
  -s, --sort <SORT_BASES>  the set of fields to sort by, trailing `_` reverses the direction
                           [default: cat cname] [possible values: dev, ino, nlink, typ, cat, user,
                           uid, group, gid, size, blocks, btime, ctime, mtime, atime, name, cname,
                           ext, inode_, nlinks_, typ_, cat_, user_, uid_, group_, gid_, size_,
                           blocks_, btime_, ctime_, mtime_, atime_, name_, cname_, ext_, none]
"""


class UsageError(Exception):
    def __init__(self, text):
        self.text = text


def die(text):
    sys.stderr.write(text)
    raise SystemExit(2)


def invalid_value(value, opt, metav, values, tip=None):
    msg = f"error: invalid value '{value}' for '{opt} <{metav}>'\n  [possible values: {', '.join(values)}]\n"
    if tip:
        msg += f"\n  tip: a similar value exists: '{tip}'\n"
    msg += "\nFor more information, try '--help'.\n"
    die(msg)


def parse(argv):
    cfg = {
        "det": "none", "header": True, "unit": "binary", "grid": False, "down": False,
        "icon": True, "suffix": True, "sym": True, "collapse": True, "align": True,
        "typ": "all", "imp": "0", "exclude": None, "only": None, "sort": "cat cname",
        "paths": [],
    }
    optmap = {
        "-d": ("det", "--det", "DETAILS", DETAILS), "--det": ("det", "--det", "DETAILS", DETAILS),
        "-H": ("header", "--header", "HEADER", BOOLS), "--header": ("header", "--header", "HEADER", BOOLS),
        "-u": ("unit", "--unit", "UNIT", ["binary", "decimal", "none"]), "--unit": ("unit", "--unit", "UNIT", ["binary", "decimal", "none"]),
        "-g": ("grid", "--grid", "GRID", BOOLS), "--grid": ("grid", "--grid", "GRID", BOOLS),
        "-D": ("down", "--down", "DOWN", BOOLS), "--down": ("down", "--down", "DOWN", BOOLS),
        "-i": ("icon", "--icon", "ICON", BOOLS), "--icon": ("icon", "--icon", "ICON", BOOLS),
        "-S": ("suffix", "--suffix", "SUFFIX", BOOLS), "--suffix": ("suffix", "--suffix", "SUFFIX", BOOLS),
        "-l": ("sym", "--sym", "SYM", BOOLS), "--sym": ("sym", "--sym", "SYM", BOOLS),
        "-c": ("collapse", "--collapse", "COLLAPSE", BOOLS), "--collapse": ("collapse", "--collapse", "COLLAPSE", BOOLS),
        "-a": ("align", "--align", "ALIGN", BOOLS), "--align": ("align", "--align", "ALIGN", BOOLS),
        "-t": ("typ", "--typ", "TYPES", TYPES), "--typ": ("typ", "--typ", "TYPES", TYPES),
        "-s": ("sort", "--sort", "SORT_BASES", SORTS), "--sort": ("sort", "--sort", "SORT_BASES", SORTS),
    }
    i = 0
    while i < len(argv):
        a = argv[i]
        if a in ("-h", "--help"):
            text = SHORT_HELP.format(prog=PROG) if a == "-h" else HELP.replace("executable", PROG)
            sys.stdout.write(text)
            raise SystemExit(0)
        if a in ("-V", "--version"):
            print(VERSION)
            raise SystemExit(0)
        if a == "--":
            cfg["paths"].extend(argv[i + 1 :])
            break
        if a in ("-e", "--exclude", "-o", "--only", "-I", "--imp"):
            if i + 1 >= len(argv):
                die(f"error: a value is required for '{a} <VALUE>' but none was supplied\n\nFor more information, try '--help'.\n")
            key = {"-e": "exclude", "--exclude": "exclude", "-o": "only", "--only": "only", "-I": "imp", "--imp": "imp"}[a]
            cfg[key] = argv[i + 1]
            i += 2
            continue
        if a in optmap:
            if i + 1 >= len(argv):
                die(f"error: a value is required for '{a}' but none was supplied\n\nFor more information, try '--help'.\n")
            key, longopt, metav, values = optmap[a]
            val = argv[i + 1]
            if val not in values:
                invalid_value(val, longopt, metav, values, "blocks" if key == "det" and val == "bogus" else None)
            cfg[key] = (val == "true") if values == BOOLS else val
            i += 2
            continue
        if a.startswith("-"):
            die(f"error: unexpected argument '{a}' found\n\n  tip: to pass '{a}' as a value, use '-- {a}'\n\nUsage: {PROG} [OPTIONS] [PATHS]...\n\nFor more information, try '--help'.\n")
        cfg["paths"].append(a)
        i += 1
    if not cfg["paths"]:
        cfg["paths"] = ["."]
    return cfg


def node_type(st):
    m = st.st_mode
    if stat.S_ISDIR(m):
        return "dir", "d"
    if stat.S_ISLNK(m):
        return "symlink", "l"
    if stat.S_ISFIFO(m):
        return "fifo", "p"
    if stat.S_ISSOCK(m):
        return "socket", "s"
    if stat.S_ISBLK(m):
        return "block-device", "b"
    if stat.S_ISCHR(m):
        return "char-device", "c"
    return "file", "f"


def clean_name(name):
    return name[1:].lower() if name.startswith(".") else name.lower()


def ext_name(name):
    base = name[1:] if name.startswith(".") else name
    return os.path.splitext(base)[1].lower().lstrip(".")


def sort_nodes(nodes, sortspec):
    if sortspec == "none":
        return nodes
    reverse = sortspec.endswith("_")
    key = sortspec[:-1] if reverse else sortspec
    if key in ("name",):
        return sorted(nodes, key=lambda n: n["name"], reverse=reverse)
    if key in ("cname", "cat cname"):
        return sorted(nodes, key=lambda n: (0 if n["type"] == "dir" else 1, clean_name(n["name"])), reverse=reverse)
    if key == "ext":
        return sorted(nodes, key=lambda n: (ext_name(n["name"]), clean_name(n["name"])), reverse=reverse)
    if key in ("size", "blocks", "mtime", "ctime", "atime", "ino", "dev", "nlink", "uid", "gid"):
        field = {"ino": "st_ino", "dev": "st_dev", "nlink": "st_nlink", "uid": "st_uid", "gid": "st_gid", "mtime": "st_mtime", "ctime": "st_ctime", "atime": "st_atime"}.get(key)
        if key == "size":
            return sorted(nodes, key=lambda n: n["st"].st_size, reverse=reverse)
        if key == "blocks":
            return sorted(nodes, key=lambda n: getattr(n["st"], "st_blocks", 0), reverse=reverse)
        return sorted(nodes, key=lambda n: getattr(n["st"], field), reverse=reverse)
    return sorted(nodes, key=lambda n: (0 if n["type"] == "dir" else 1, clean_name(n["name"])))


def perms(mode):
    triples = []
    for shift in (6, 3, 0):
        val = (mode >> shift) & 7
        triples.append(("r" if val & 4 else "-") + ("w" if val & 2 else "-") + ("x" if val & 1 else "-"))
    return " ".join(triples)


def username(uid):
    try:
        return pwd.getpwuid(uid).pw_name
    except KeyError:
        return str(uid)


def groupname(gid):
    try:
        return grp.getgrgid(gid).gr_name
    except KeyError:
        return str(gid)


def timefmt(ts):
    return datetime.fromtimestamp(ts).strftime("%Y-%b-%d %I:%M%p").replace("AM", "am").replace("PM", "pm")


def sizefmt(n, typ, unit):
    if typ == "dir":
        return ""
    if unit == "none":
        return f"{n} B"
    base = 1000 if unit == "decimal" else 1024
    units = ["B", "kB" if unit == "decimal" else "KiB", "MB" if unit == "decimal" else "MiB", "GB" if unit == "decimal" else "GiB"]
    val = float(n)
    idx = 0
    while val >= base and idx < len(units) - 1:
        val /= base
        idx += 1
    if idx == 0 and unit in ("binary", "decimal"):
        gap = "   " if unit == "binary" else "  "
        return f"{val:.1f}{gap}{units[idx]}"
    return f"{val:.1f} {units[idx]}"


def icon_for(n):
    if n["type"] == "file":
        return "" if (n["st"].st_mode & 0o111) else " "
    return {"dir": "", "symlink": "󰌹", "fifo": "󰟥", "socket": "󰆨"}.get(n["type"], " ")


def suffix_for(typ):
    return {"dir": "/", "symlink": "@", "fifo": "|", "socket": "="}.get(typ, "")


def display_name(n, cfg, fullpath=False):
    if fullpath:
        s = n["path"]
    else:
        lead = " " if cfg["align"] and not n["name"].startswith(".") else ""
        s = lead + n["name"]
    if cfg["suffix"]:
        s += suffix_for(n["type"])
    if cfg["icon"] and not fullpath:
        s = f"{icon_for(n)} {s}"
    if cfg["sym"] and n["type"] == "symlink":
        try:
            target = os.readlink(n["path"])
            target_path = target if os.path.isabs(target) else os.path.join(os.path.dirname(n["path"]), target)
            arrow = "󰁔" if os.path.exists(target_path) else "󱞣"
            s += f" {arrow} {target}"
        except OSError:
            pass
    return s


def collect(path):
    st = os.lstat(path)
    typ, letter = node_type(st)
    return {"path": path, "name": os.path.basename(path.rstrip("/")) or path, "st": st, "type": typ, "letter": letter}


def listed_nodes(path, cfg):
    entries = []
    for name in os.listdir(path):
        try:
            n = collect(os.path.join(path, name))
        except OSError:
            continue
        if cfg["typ"] == "none":
            continue
        if cfg["typ"] != "all" and n["type"] != cfg["typ"]:
            continue
        if cfg["exclude"] and fnmatch.fnmatch(name, cfg["exclude"]):
            continue
        if cfg["only"] and not fnmatch.fnmatch(name, cfg["only"]):
            continue
        entries.append(n)
    return sort_nodes(entries, cfg["sort"])


def detail_fields(det):
    if det == "none":
        return []
    if det == "std":
        return ["nlink", "typ", "perm", "user", "group", "size", "mtime"]
    if det == "all":
        return ["dev", "ino", "nlink", "typ", "perm", "oct", "user", "uid", "group", "gid", "size", "blocks", "btime", "ctime", "mtime", "atime", "git"]
    return [det]


HEADERS = {
    "dev": "Device", "ino": "inode", "nlink": "Link#", "typ": "T", "perm": "Permissions",
    "oct": "SUGO", "user": "User", "uid": "UID", "group": "Group", "gid": "GID",
    "size": "Size", "blocks": "Blocks", "btime": "Created", "ctime": "Changed",
    "mtime": "Modified", "atime": "Accessed", "git": "Git",
}


def value(n, field, cfg):
    st = n["st"]
    if field == "dev":
        return str(st.st_dev)
    if field == "ino":
        return str(st.st_ino)
    if field == "nlink":
        return str(st.st_nlink)
    if field == "typ":
        return n["letter"]
    if field == "perm":
        return perms(st.st_mode)
    if field == "oct":
        return f"{stat.S_IMODE(st.st_mode):03o}"
    if field == "user":
        return username(st.st_uid)
    if field == "uid":
        return str(st.st_uid)
    if field == "group":
        return groupname(st.st_gid)
    if field == "gid":
        return str(st.st_gid)
    if field == "size":
        return sizefmt(st.st_size, n["type"], cfg["unit"])
    if field == "blocks":
        return "" if n["type"] == "dir" else str(getattr(st, "st_blocks", 0))
    if field == "btime":
        return timefmt(getattr(st, "st_birthtime", st.st_ctime))
    if field == "ctime":
        return timefmt(st.st_ctime)
    if field == "mtime":
        return timefmt(st.st_mtime)
    if field == "atime":
        return timefmt(st.st_atime)
    if field == "git":
        return ""
    return ""


def print_nodes(nodes, cfg, fullpath=False):
    fields = detail_fields(cfg["det"])
    if not fields:
        for n in nodes:
            print(display_name(n, cfg, fullpath))
        return
    rows = [[value(n, f, cfg) for f in fields] + [display_name(n, cfg, fullpath)] for n in nodes]
    if not cfg["header"]:
        raw_rows = []
        for row in rows:
            raw = []
            for i, text in enumerate(row[:-1]):
                field = fields[i]
                if field == "oct":
                    text = " " + text
                raw.append(text)
            raw_rows.append(raw + [row[-1]])
        widths = []
        for idx in range(len(fields)):
            widths.append(max([0, *[len(r[idx]) for r in raw_rows]]))
        left_fields = {"perm", "user", "group", "btime", "ctime", "mtime", "atime", "git"}
        for row in raw_rows:
            parts = []
            for i, text in enumerate(row[:-1]):
                parts.append(text.ljust(widths[i]) if fields[i] in left_fields else text.rjust(widths[i]))
            print(" ".join(parts) + " " + row[-1])
        return
    headers = [HEADERS[f] for f in fields] + ["Name"]
    widths = []
    for idx, h in enumerate(headers):
        vals = [r[idx] for r in rows]
        widths.append(max([len(h), *map(len, vals)]))
    left_fields = {"perm", "user", "group", "btime", "ctime", "mtime", "atime", "git"}

    def fmt(text, width, field):
        return text.ljust(width) if field in left_fields else text.rjust(width)

    if cfg["header"]:
        print(" ".join(fmt(h, widths[i], fields[i]) for i, h in enumerate(headers[:-1])) + " " + headers[-1])
    for row in rows:
        parts = [fmt(row[i], widths[i], fields[i]) for i in range(len(fields))]
        print(" ".join(parts) + " " + row[-1])


def main(argv):
    cfg = parse(argv)
    multi = len(cfg["paths"]) > 1
    first_section = True
    direct_nodes = []
    dirs = []
    for path in cfg["paths"]:
        try:
            n = collect(path)
        except OSError as e:
            sys.stdout.write(f"{path}:\n\terror: {e.strerror} (os error {e.errno})\n")
            continue
        if n["type"] == "dir":
            dirs.append(path)
        else:
            direct_nodes.append(n)
    if direct_nodes:
        print_nodes(direct_nodes, cfg, fullpath=True)
        first_section = False
    for path in dirs:
        if multi:
            if first_section:
                print()
            else:
                print()
            print(f"{path}:")
        nodes = listed_nodes(path, cfg)
        print_nodes(nodes, cfg)
        first_section = False
    return 0


if __name__ == "__main__":
    PROG = os.path.basename(sys.argv[0])
    try:
        raise SystemExit(main(sys.argv[1:]))
    except BrokenPipeError:
        raise SystemExit(0)
