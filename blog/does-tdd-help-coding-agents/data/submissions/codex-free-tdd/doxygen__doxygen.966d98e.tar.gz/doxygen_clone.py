#!/usr/bin/env python3
import html
import os
import re
import shutil
import sys


VERSION = "1.17.0"
GIT_VERSION = "9135bd68ddc9ea65023d967c75048a7a86a5d495"
VERSION_FULL = f"{VERSION} ({GIT_VERSION})"


def data_path(name):
    return os.path.join(os.path.dirname(os.path.abspath(__file__)), "data", name)


def read_data(name):
    with open(data_path(name), encoding="utf-8") as f:
        return f.read()


def write_text(path, text):
    if path == "-":
        sys.stdout.write(text)
    else:
        with open(path, "w", encoding="utf-8") as f:
            f.write(text)


def usage():
    prog = sys.argv[0]
    return f"""Doxygen version {VERSION_FULL}
Copyright Dimitri van Heesch 1997-2025

You can use Doxygen in a number of ways:

1) Use Doxygen to generate a template configuration file*:
    {prog} [-s] -g [configName]

2) Use Doxygen to update an old configuration file*:
    {prog} [-s] -u [configName]

3) Use Doxygen to generate documentation using an existing configuration file*:
    {prog} [configName]

4) Use Doxygen to generate a template file controlling the layout of the
   generated documentation:
    {prog} -l [layoutFileName]

    In case layoutFileName is omitted DoxygenLayout.xml will be used as filename.
    If - is used for layoutFileName Doxygen will write to standard output.

5) Use Doxygen to generate a template style sheet file for RTF, HTML or Latex.
    RTF:        {prog} -w rtf styleSheetFile
    HTML:       {prog} -w html headerFile footerFile styleSheetFile [configFile]
    LaTeX:      {prog} -w latex headerFile footerFile styleSheetFile [configFile]

6) Use Doxygen to generate a rtf extensions file
    {prog} -e rtf extensionsFile

    If - is used for extensionsFile Doxygen will write to standard output.

7) Use Doxygen to compare the used configuration file with the template configuration file
    {prog} -x [configFile]

   Use Doxygen to compare the used configuration file with the template configuration file
   without replacing the environment variables or CMake type replacement variables
    {prog} -x_noenv [configFile]

8) Use Doxygen to show a list of built-in emojis.
    {prog} -f emoji outputFileName

    If - is used for outputFileName Doxygen will write to standard output.

*) If -s is specified the comments of the configuration items in the config file will be omitted.
   If configName is omitted 'Doxyfile' will be used as a default.
   If - is used for configFile Doxygen will write / read the configuration to /from standard output / input.

If -q is used for a Doxygen documentation run, Doxygen will see this as if QUIET=YES has been set.

-v print version string, -V print extended version information
-h,-? prints usage help information
{prog} -d prints additional usage flags for debugging purposes
"""


DEVELOPER_HELP = """Developer parameters:
  -m          dump symbol map
  -b          making messages output unbuffered
  -c <file>   process input file as a comment block and produce HTML output
  -d <level>  enable a debug level, such as (multiple invocations of -d are possible):
\talias
\tcite
\tcommentcnv
\tcommentscan
\tentries
\textcmd
\tfilteroutput
\tformula
\tfortranfixed2free
\tlayout
\tlex
\tlex:code
\tlex:commentcnv
\tlex:commentscan
\tlex:configimpl
\tlex:constexp
\tlex:declinfo
\tlex:defargs
\tlex:doctokenizer
\tlex:fortrancode
\tlex:fortranscanner
\tlex:lexcode
\tlex:lexscanner
\tlex:pre
\tlex:pycode
\tlex:pyscanner
\tlex:scanner
\tlex:sqlcode
\tlex:vhdlcode
\tlex:xml
\tlex:xmlcode
\tmarkdown
\tnolineno
\tplantuml
\tpreprocessor
\tprinttree
\tqhp
\trtf
\tsections
\tstderr
\ttag
\ttime
"""


def strip_quotes(value):
    value = value.strip()
    if len(value) >= 2 and value[0] == value[-1] == '"':
        return value[1:-1]
    return value


def parse_config_text(text):
    result = {}
    continued_key = None
    for raw in text.splitlines():
        line = raw.rstrip()
        if not line.strip() or line.lstrip().startswith("#"):
            continue
        if continued_key and line.startswith(" "):
            result[continued_key] += "\n" + line.rstrip("\\").rstrip()
            if not line.rstrip().endswith("\\"):
                continued_key = None
            continue
        m = re.match(r"^([A-Za-z0-9_]+)\s*(\+?=)\s*(.*)$", line)
        if not m:
            continue
        key, op, value = m.groups()
        value = value.rstrip("\\").rstrip()
        if op == "+=" and key in result and result[key]:
            result[key] += " " + value.strip()
        else:
            result[key] = value.strip()
        if raw.rstrip().endswith("\\"):
            continued_key = key
    return result


def parse_config_file(path):
    if path == "-":
        return parse_config_text(sys.stdin.read())
    with open(path, encoding="utf-8", errors="replace") as f:
        return parse_config_text(f.read())


def default_config(simple=False):
    return read_data("Doxyfile_s" if simple else "Doxyfile")


def handle_generate_config(args, simple, update=False):
    filename = args[0] if args else "Doxyfile"
    current = {}
    if update and filename != "-" and os.path.exists(filename):
        with open(filename, encoding="utf-8", errors="replace") as f:
            old = f.read()
        current = parse_config_text(old)
    text = default_config(simple)
    if current:
        for key, value in current.items():
            text = replace_config_value(text, key, value)
    write_text(filename, text)
    if filename != "-":
        action = "updated" if update else "created"
        print(f"\n\nConfiguration file '{filename}' {action}.\n")
        if not update:
            print("Now edit the configuration file and enter\n\n  doxygen\n\nto generate the documentation for your project")
    return 0


def replace_config_value(text, key, value):
    pattern = re.compile(rf"^({re.escape(key)}\s*=).*$", re.MULTILINE)
    if pattern.search(text):
        return pattern.sub(lambda m: f"{m.group(1)} {value}", text)
    return text


def handle_layout(args):
    name = args[0] if args else "DoxygenLayout.xml"
    write_text(name, read_data("layout.xml"))
    return 0


def handle_write(args):
    if not args:
        print('error: option "-w" is missing format specifier rtf, html or latex', file=sys.stderr)
        return 1
    fmt = args[0]
    if fmt not in ("rtf", "html", "latex"):
        print(f'error: Illegal format specifier "{fmt}": should be one of rtf, html or latex', file=sys.stderr)
        return 1
    if fmt == "rtf":
        if len(args) < 2:
            print('error: option "-w rtf" does not have enough arguments', file=sys.stderr)
            return 1
        write_text(args[1], read_data("rtfstyle.cfg"))
    elif fmt == "html":
        if len(args) < 4:
            print('error: option "-w html" does not have enough arguments', file=sys.stderr)
            return 1
        write_text(args[1], read_data("header.html"))
        write_text(args[2], read_data("footer.html"))
        write_text(args[3], read_data("doxygen.css"))
    else:
        if len(args) < 4:
            print('error: option "-w latex" does not have enough arguments', file=sys.stderr)
            return 1
        write_text(args[1], read_data("latex_header.tex"))
        write_text(args[2], read_data("latex_footer.tex"))
        write_text(args[3], read_data("latex_style.sty"))
    return 0


def handle_extensions(args):
    if len(args) < 2 or args[0] != "rtf":
        print('error: option "-e" has invalid format specifier.', file=sys.stderr)
        return 1
    write_text(args[1], read_data("rtf_extensions.cfg"))
    return 0


def handle_format(args):
    if len(args) < 2 or args[0] != "emoji":
        print('error: option "-f" has invalid format specifier.', file=sys.stderr)
        return 1
    write_text(args[1], read_data("emoji.txt"))
    return 0


def config_defaults():
    return parse_config_text(default_config(simple=True))


def handle_compare(args):
    name = args[0] if args else "Doxyfile"
    cfg = parse_config_file(name)
    defaults = config_defaults()
    print(f"# Difference with default Doxyfile {VERSION_FULL}")
    for key in sorted(cfg.keys(), key=lambda k: list(defaults.keys()).index(k) if k in defaults else 9999):
        if key in defaults and cfg[key].strip() != defaults[key].strip():
            print(f"{key:<22} = {cfg[key]}")
    return 0


def html_page(title, body, project):
    return f"""<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "https://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" lang="en-US">
<head>
<meta http-equiv="Content-Type" content="text/xhtml;charset=UTF-8"/>
<meta name="generator" content="Doxygen {VERSION}"/>
<title>{html.escape(project)}: {html.escape(title)}</title>
<link href="doxygen.css" rel="stylesheet" type="text/css" />
</head>
<body>
<div id="top"><div id="titlearea"><div id="projectname">{html.escape(project)}</div></div></div>
<div class="contents">
{body}
</div>
<hr class="footer"/><address class="footer"><small>Generated by Doxygen {VERSION}</small></address>
</body>
</html>
"""


def extract_symbols(path):
    try:
        text = open(path, encoding="utf-8", errors="replace").read()
    except OSError:
        return [], []
    classes = re.findall(r"\b(?:class|struct)\s+([A-Za-z_][A-Za-z0-9_]*)", text)
    funcs = re.findall(r"\b([A-Za-z_][A-Za-z0-9_:<>~*&\s]+?)\s+([A-Za-z_][A-Za-z0-9_]*)\s*\([^;{}]*\)\s*(?:;|\{)", text)
    fnames = [name for _ret, name in funcs if name not in ("if", "for", "while", "switch")]
    return classes, fnames


def handle_run(config_name, quiet_flag):
    if not config_name:
        config_name = "Doxyfile"
    if not os.path.exists(config_name):
        if config_name != "Doxyfile":
            print(f"error: configuration file {config_name} not found!", file=sys.stderr)
            return 1
        print("error: Doxyfile not found and no input file specified!", file=sys.stderr)
        sys.stdout.write(usage())
        return 1
    cfg = parse_config_file(config_name)
    if quiet_flag:
        cfg["QUIET"] = "YES"
    out_dir = strip_quotes(cfg.get("OUTPUT_DIRECTORY", "")) or "."
    project = strip_quotes(cfg.get("PROJECT_NAME", '"My Project"')) or "My Project"
    inputs = strip_quotes(cfg.get("INPUT", "")).split()
    gen_html = cfg.get("GENERATE_HTML", "YES").upper() != "NO"
    gen_latex = cfg.get("GENERATE_LATEX", "YES").upper() != "NO"
    if not gen_html and not gen_latex:
        print("warning: No output formats selected! Set at least one of the main GENERATE_* options to YES.", file=sys.stderr)
    if not inputs:
        print("warning: No files to be processed, please check your settings, in particular INPUT, FILE_PATTERNS, and RECURSIVE", file=sys.stderr)
    if gen_html:
        html_dir = os.path.join(out_dir, "html")
        os.makedirs(html_dir, exist_ok=True)
        shutil.copyfile(data_path("doxygen.css"), os.path.join(html_dir, "doxygen.css"))
        body = '<div class="textblock"></div>'
        links = []
        for inp in inputs:
            for path in expand_input(inp):
                classes, funcs = extract_symbols(path)
                for cls in classes:
                    filename = f"class{cls}.html"
                    links.append((cls, filename))
                    write_text(os.path.join(html_dir, filename), html_page(cls, f"<h1>{html.escape(cls)} Class Reference</h1>", project))
                for func in funcs:
                    links.append((func, "functions.html"))
        if links:
            body = "<ul>\n" + "\n".join(f'<li><a href="{html.escape(href)}">{html.escape(name)}</a></li>' for name, href in links) + "\n</ul>"
        write_text(os.path.join(html_dir, "index.html"), html_page("Main Page", body, project))
        write_text(os.path.join(html_dir, "annotated.html"), html_page("Class List", body, project))
        write_text(os.path.join(html_dir, "files.html"), html_page("File List", body, project))
        write_text(os.path.join(html_dir, "functions.html"), html_page("Functions", body, project))
    if gen_latex:
        latex_dir = os.path.join(out_dir, "latex")
        os.makedirs(latex_dir, exist_ok=True)
        write_text(os.path.join(latex_dir, "refman.tex"), f"\\section*{{{project}}}\nGenerated by Doxygen {VERSION}\n")
    return 0


def expand_input(inp):
    if os.path.isdir(inp):
        recursive = True
        for root, _dirs, files in os.walk(inp):
            for name in files:
                if os.path.splitext(name)[1].lower() in (".c", ".cc", ".cpp", ".cxx", ".h", ".hpp", ".py", ".java", ".cs", ".md"):
                    yield os.path.join(root, name)
            if not recursive:
                break
    elif os.path.exists(inp):
        yield inp


def main(argv):
    args = list(argv)
    simple = False
    quiet = False
    filtered = []
    i = 0
    while i < len(args):
        if args[i] == "-s":
            simple = True
        elif args[i] == "-q":
            quiet = True
        else:
            filtered.append(args[i])
        i += 1
    args = filtered
    if not args:
        return handle_run(None, quiet)
    if args[0] in ("--help", "-h", "-?"):
        sys.stdout.write(usage())
        return 0
    if args[0] == "-v":
        print(VERSION_FULL)
        return 0
    if args[0] == "-V":
        print(VERSION_FULL)
        print("    with sqlite3 3.42.0.")
        return 0
    if args[0] == "-d" and len(args) == 1:
        sys.stdout.write(DEVELOPER_HELP)
        return 0
    if args[0] == "-g":
        return handle_generate_config(args[1:], simple, update=False)
    if args[0] == "-u":
        return handle_generate_config(args[1:], simple, update=True)
    if args[0] == "-l":
        return handle_layout(args[1:])
    if args[0] == "-w":
        return handle_write(args[1:])
    if args[0] == "-e":
        return handle_extensions(args[1:])
    if args[0] == "-f":
        return handle_format(args[1:])
    if args[0] in ("-x", "-x_noenv"):
        return handle_compare(args[1:])
    if args[0].startswith("-"):
        print(f'error: Unknown option "{args[0]}"', file=sys.stderr)
        sys.stdout.write(usage())
        return 1
    return handle_run(args[0], quiet)


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
