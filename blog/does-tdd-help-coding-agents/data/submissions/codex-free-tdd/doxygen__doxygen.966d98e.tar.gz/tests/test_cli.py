import os
import subprocess
import tempfile
import unittest


ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
EXE = os.path.join(ROOT, "executable")


def run_cmd(args, cwd=None, input_text=None):
    return subprocess.run(
        [EXE] + args,
        cwd=cwd,
        input=input_text,
        text=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
    )


class DoxygenCliTests(unittest.TestCase):
    def test_version_flags_match_documented_version(self):
        result = run_cmd(["-v"])
        self.assertEqual(result.returncode, 0)
        self.assertEqual(result.stdout, "1.17.0 (9135bd68ddc9ea65023d967c75048a7a86a5d495)\n")
        self.assertEqual(result.stderr, "")

    def test_help_contains_usage_sections(self):
        result = run_cmd(["--help"])
        self.assertEqual(result.returncode, 0)
        self.assertIn("Doxygen version 1.17.0", result.stdout)
        self.assertIn("executable [-s] -g [configName]", result.stdout)
        self.assertIn("-v print version string", result.stdout)

    def test_generate_default_config_file(self):
        with tempfile.TemporaryDirectory() as td:
            result = run_cmd(["-g", "Doxyfile"], cwd=td)
            self.assertEqual(result.returncode, 0, result.stderr)
            self.assertIn("Configuration file 'Doxyfile' created.", result.stdout)
            with open(os.path.join(td, "Doxyfile"), encoding="utf-8") as f:
                text = f.read()
            self.assertTrue(text.startswith("# Doxyfile 1.17.0\n"))
            self.assertIn('PROJECT_NAME           = "My Project"', text)
            self.assertIn("GENERATE_HTML          = YES", text)

    def test_developer_help_lists_vhdl_debug_level(self):
        result = run_cmd(["-d"])
        self.assertEqual(result.returncode, 0)
        self.assertIn("\tlex:vhdlcode\n", result.stdout)

    def test_compare_uses_reference_alignment(self):
        with tempfile.TemporaryDirectory() as td:
            with open(os.path.join(td, "Doxyfile"), "w", encoding="utf-8") as f:
                f.write("PROJECT_NAME = Test\nGENERATE_LATEX = NO\n")
            result = run_cmd(["-x", "Doxyfile"], cwd=td)
            self.assertEqual(result.returncode, 0, result.stderr)
            self.assertIn("PROJECT_NAME           = Test\n", result.stdout)
            self.assertIn("GENERATE_LATEX         = NO\n", result.stdout)

    def test_write_without_format_reports_missing_specifier(self):
        result = run_cmd(["-w"])
        self.assertEqual(result.returncode, 1)
        self.assertIn('error: option "-w" is missing format specifier rtf, html or latex', result.stderr)

    def test_named_missing_config_reports_config_not_found(self):
        with tempfile.TemporaryDirectory() as td:
            result = run_cmd(["missing"], cwd=td)
            self.assertEqual(result.returncode, 1)
            self.assertEqual(result.stdout, "")
            self.assertEqual(result.stderr, "error: configuration file missing not found!\n")


if __name__ == "__main__":
    unittest.main()
