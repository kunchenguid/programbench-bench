import os
import subprocess
import sys
import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
SCRIPT = ROOT / "src" / "igrep.py"


def run_cmd(*args, stdin=None):
    return subprocess.run(
        [sys.executable, str(SCRIPT), *args],
        input=stdin,
        text=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
    )


class IgrepCliTests(unittest.TestCase):
    def test_version_prints_igrep_version(self):
        result = run_cmd("--version")
        self.assertEqual(result.returncode, 0)
        self.assertEqual(result.stdout, "igrep 1.3.0\n")
        self.assertEqual(result.stderr, "")

    def test_help_matches_documented_clap_shape(self):
        result = run_cmd("--help")
        self.assertEqual(result.returncode, 0)
        self.assertIn("Interactive Grep\n\nUsage: executable [OPTIONS] --type-list <PATTERN> [PATHS]...\n", result.stdout)
        self.assertIn("  -., --hidden\n          Search hidden files and directories.", result.stdout)
        self.assertIn("      --context-viewer <CONTEXT_VIEWER>", result.stdout)
        self.assertEqual(result.stderr, "")

    def test_type_list_prints_known_file_types(self):
        result = run_cmd("--type-list")
        self.assertEqual(result.returncode, 0)
        self.assertIn("rust: *.rs\n", result.stdout)
        self.assertIn("python: *.py, *.pyi\n", result.stdout)
        self.assertIn("zstd: *.zst, *.zstd\n", result.stdout)
        self.assertEqual(result.stderr, "")

    def test_type_list_cannot_be_used_with_pattern(self):
        result = run_cmd("--type-list", "foo")
        self.assertEqual(result.returncode, 2)
        self.assertEqual(result.stdout, "")
        self.assertIn("error: the argument '--type-list' cannot be used with '<PATTERN>'\n", result.stderr)
        self.assertIn("Usage: executable --type-list <PATTERN> [PATHS]...\n", result.stderr)

    def test_unexpected_argument_after_type_list_uses_group_usage(self):
        result = run_cmd("--type-list", "--bad")
        self.assertEqual(result.returncode, 2)
        self.assertEqual(result.stdout, "")
        self.assertIn("error: unexpected argument '--bad' found\n", result.stderr)
        self.assertIn("Usage: executable <PATTERN|--type-list> [PATHS]...\n", result.stderr)

    def test_missing_arguments_reports_required_type_list_and_pattern(self):
        result = run_cmd()
        self.assertEqual(result.returncode, 2)
        self.assertEqual(result.stdout, "")
        self.assertIn("error: the following required arguments were not provided:\n  --type-list\n  <PATTERN>\n", result.stderr)
        self.assertIn("Usage: executable --type-list <PATTERN> [PATHS]...\n", result.stderr)

    def test_invalid_editor_reports_possible_values(self):
        result = run_cmd("--editor", "bad", "foo")
        self.assertEqual(result.returncode, 2)
        self.assertIn("error: invalid value 'bad' for '--editor <EDITOR>'", result.stderr)
        self.assertIn("[possible values: vim, neovim, nvim, nano, code", result.stderr)

    def test_bad_custom_command_requires_line_number_token(self):
        result = run_cmd("--custom-command", "echo {file_name}", "foo")
        self.assertEqual(result.returncode, 1)
        self.assertEqual(result.stderr, "Error: Incorrect editor command: 'echo {file_name}'\n\nCaused by:\n    Expected one occurrence of '{line_number}'.\n")
        self.assertEqual(result.stdout, "")

    def test_non_tty_pattern_search_reports_resource_error(self):
        result = run_cmd("foo")
        self.assertEqual(result.returncode, 1)
        self.assertEqual(result.stderr, "Error: Resource temporarily unavailable (os error 11)\n")
        self.assertEqual(result.stdout, "")


if __name__ == "__main__":
    unittest.main()
