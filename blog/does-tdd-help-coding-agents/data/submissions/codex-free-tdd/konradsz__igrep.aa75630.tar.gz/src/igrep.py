#!/usr/bin/env python3
import fnmatch
import os
import re
import stat
import sys
from pathlib import Path


VERSION = "igrep 1.3.0"
EDITORS = [
    "vim", "neovim", "nvim", "nano", "code", "vscode", "code-insiders",
    "emacs", "emacsclient", "hx", "helix", "subl", "sublime-text",
    "micro", "intellij", "goland", "pycharm", "less", "fresh",
]
THEMES = ["light", "dark"]
CONTEXT_VIEWERS = ["none", "vertical", "horizontal"]
SORTS = ["path", "modified", "created", "accessed"]
KNOWN_TYPES = {
    "c": ["*.c", "*.h", "*.H", "*.cats", "*.c.in", "*.h.in", "*.H.in"],
    "cpp": ["*.cpp", "*.hpp", "*.cc", "*.hh", "*.cxx", "*.hxx", "*.C", "*.H", "*.inl"],
    "go": ["*.go"],
    "js": ["*.js", "*.jsx", "*.mjs", "*.cjs", "*.vue"],
    "json": ["*.json", "*.sarif", "composer.lock"],
    "markdown": ["*.md", "*.markdown", "*.mdown", "*.mdwn", "*.mdx", "*.mkd", "*.mkdn"],
    "md": ["*.md", "*.markdown", "*.mdown", "*.mdwn", "*.mdx", "*.mkd", "*.mkdn"],
    "py": ["*.py", "*.pyi"],
    "python": ["*.py", "*.pyi"],
    "rs": ["*.rs"],
    "rust": ["*.rs"],
    "sh": ["*.sh", "*.bash", "*.zsh", ".bashrc", ".zshrc"],
    "txt": ["*.txt"],
    "ts": ["*.ts", "*.tsx", "*.mts", "*.cts"],
    "typescript": ["*.ts", "*.tsx", "*.mts", "*.cts"],
}


HELP = """Interactive Grep

Usage: executable [OPTIONS] --type-list <PATTERN> [PATHS]...

Arguments:
  <PATTERN>   Regular expression used for searching
  [PATHS]...  Files or directories to search. Directories are searched recursively. If not specified, searching starts from current directory

Options:
      --editor <EDITOR>
          Text editor used to open selected match [possible values: vim, neovim, nvim, nano, code, vscode, code-insiders, emacs, emacsclient, hx, helix, subl, sublime-text, micro, intellij, goland, pycharm, less, fresh]
      --custom-command <CUSTOM_COMMAND>
          Custom command used to open selected match. Must contain {file_name} and {line_number} tokens [env: IGREP_CUSTOM_EDITOR=]
      --theme <THEME>
          UI color theme [default: dark] [possible values: light, dark]
  -i, --ignore-case
          Searches case insensitively
  -S, --smart-case
          Searches case insensitively if the pattern is all lowercase. Search case sensitively otherwise
  -., --hidden
          Search hidden files and directories. By default, hidden files and directories are skipped
  -L, --follow
          Follow symbolic links while traversing directories
  -w, --word-regexp
          Only show matches surrounded by word boundaries
  -F, --fixed-strings
          Exact matches with no regex. Useful when searching for a string full of delimiters
  -U, --multiline
          Search with pattern contains newline character ('\\n')
  -g, --glob <GLOB>
          Include files and directories for searching that match the given glob. Multiple globs may be provided
      --type-list
          Show all supported file types and their corresponding globs
  -t, --type <TYPE_MATCHING>
          Only search files matching TYPE. Multiple types may be provided
  -T, --type-not <TYPE_NOT>
          Do not search files matching TYPE-NOT. Multiple types-not may be provided
      --context-viewer <CONTEXT_VIEWER>
          Context viewer position at startup [default: none] [possible values: none, vertical, horizontal]
      --sort <SORT_BY>
          Sort results, see ripgrep for details [possible values: path, modified, created, accessed]
      --sortr <SORT_BY_REVERSE>
          Sort results reverse, see ripgrep for details [possible values: path, modified, created, accessed]
  -h, --help
          Print help
  -V, --version
          Print version
"""


class CliError(Exception):
    def __init__(self, message, code=2):
        super().__init__(message)
        self.code = code


def data_path(name):
    candidates = [
        Path(__file__).resolve().parent / name,
        Path.cwd() / "src" / name,
    ]
    for candidate in candidates:
        if candidate.exists():
            return candidate
    return candidates[-1]


def type_list():
    return data_path("type_list.txt").read_text()


def usage_for_error(needs_options=True):
    if needs_options:
        return "Usage: executable [OPTIONS] --type-list <PATTERN> [PATHS]..."
    return "Usage: executable --type-list <PATTERN> [PATHS]..."


def group_usage():
    return "Usage: executable <PATTERN|--type-list> [PATHS]..."


def clap_error(message, usage=None):
    if usage:
        return f"error: {message}\n\n{usage}\n\nFor more information, try '--help'.\n"
    return f"error: {message}\n\nFor more information, try '--help'.\n"


def parse(argv):
    opts = {
        "ignore_case": False,
        "smart_case": False,
        "hidden": False,
        "follow": False,
        "word": False,
        "fixed": False,
        "multiline": False,
        "globs": [],
        "types": [],
        "type_nots": [],
        "sort": None,
        "sortr": None,
        "editor": None,
        "custom": os.environ.get("IGREP_CUSTOM_EDITOR"),
        "theme": "dark",
        "context": "none",
        "type_list": False,
        "positionals": [],
    }
    i = 0
    while i < len(argv):
        arg = argv[i]
        if arg == "--":
            opts["positionals"].extend(argv[i + 1:])
            break
        if arg in ("-h", "--help"):
            return "help", opts
        if arg in ("-V", "--version"):
            return "version", opts
        if arg == "--type-list":
            opts["type_list"] = True
        elif arg in ("-i", "--ignore-case"):
            opts["ignore_case"] = True
        elif arg in ("-S", "--smart-case"):
            opts["smart_case"] = True
        elif arg in ("-.", "--hidden"):
            opts["hidden"] = True
        elif arg in ("-L", "--follow"):
            opts["follow"] = True
        elif arg in ("-w", "--word-regexp"):
            opts["word"] = True
        elif arg in ("-F", "--fixed-strings"):
            opts["fixed"] = True
        elif arg in ("-U", "--multiline"):
            opts["multiline"] = True
        elif arg in ("-g", "--glob"):
            i += 1
            if i >= len(argv):
                raise CliError(clap_error("a value is required for '--glob <GLOB>' but none was supplied"))
            opts["globs"].append(argv[i])
        elif arg in ("-t", "--type"):
            i += 1
            if i >= len(argv):
                raise CliError(clap_error("a value is required for '--type <TYPE_MATCHING>' but none was supplied"))
            opts["types"].append(argv[i])
        elif arg in ("-T", "--type-not"):
            i += 1
            if i >= len(argv):
                raise CliError(clap_error("a value is required for '--type-not <TYPE_NOT>' but none was supplied"))
            opts["type_nots"].append(argv[i])
        elif arg == "--editor":
            i += 1
            if i >= len(argv):
                raise CliError(clap_error("a value is required for '--editor <EDITOR>' but none was supplied"))
            value = argv[i]
            if value not in EDITORS:
                vals = ", ".join(EDITORS)
                raise CliError(clap_error(f"invalid value '{value}' for '--editor <EDITOR>'\n  [possible values: {vals}]"))
            opts["editor"] = value
        elif arg == "--theme":
            i += 1
            if i >= len(argv):
                raise CliError(clap_error("a value is required for '--theme <THEME>' but none was supplied"))
            value = argv[i]
            if value not in THEMES:
                raise CliError(clap_error(f"invalid value '{value}' for '--theme <THEME>'\n  [possible values: light, dark]"))
            opts["theme"] = value
        elif arg == "--context-viewer":
            i += 1
            if i >= len(argv):
                raise CliError(clap_error("a value is required for '--context-viewer <CONTEXT_VIEWER>' but none was supplied"))
            value = argv[i]
            if value not in CONTEXT_VIEWERS:
                raise CliError(clap_error(f"invalid value '{value}' for '--context-viewer <CONTEXT_VIEWER>'\n  [possible values: none, vertical, horizontal]"))
            opts["context"] = value
        elif arg == "--sort":
            i += 1
            if i >= len(argv):
                raise CliError(clap_error("a value is required for '--sort <SORT_BY>' but none was supplied"))
            value = argv[i]
            if value not in SORTS:
                raise CliError(clap_error(f"invalid value '{value}' for '--sort <SORT_BY>'\n  [possible values: path, modified, created, accessed]"))
            opts["sort"] = value
        elif arg == "--sortr":
            i += 1
            if i >= len(argv):
                raise CliError(clap_error("a value is required for '--sortr <SORT_BY_REVERSE>' but none was supplied"))
            value = argv[i]
            if value not in SORTS:
                raise CliError(clap_error(f"invalid value '{value}' for '--sortr <SORT_BY_REVERSE>'\n  [possible values: path, modified, created, accessed]"))
            opts["sortr"] = value
        elif arg == "--custom-command":
            i += 1
            if i >= len(argv):
                raise CliError(clap_error("a value is required for '--custom-command <CUSTOM_COMMAND>' but none was supplied"))
            opts["custom"] = argv[i]
        elif arg.startswith("--"):
            usage = group_usage() if opts["type_list"] else usage_for_error(True)
            raise CliError(clap_error(f"unexpected argument '{arg}' found\n\n  tip: to pass '{arg}' as a value, use '-- {arg}'", usage))
        elif arg.startswith("-") and arg != "-":
            raise CliError(clap_error(f"unexpected argument '{arg}' found", usage_for_error(True)))
        else:
            opts["positionals"].append(arg)
        i += 1
    return "run", opts


def validate(opts):
    custom = opts.get("custom")
    if custom:
        if custom.count("{file_name}") != 1:
            sys.stderr.write(f"Error: Incorrect editor command: '{custom}'\n\nCaused by:\n    Expected one occurrence of '{{file_name}}'.\n")
            return 1
        if custom.count("{line_number}") != 1:
            sys.stderr.write(f"Error: Incorrect editor command: '{custom}'\n\nCaused by:\n    Expected one occurrence of '{{line_number}}'.\n")
            return 1
    for typ in opts["types"] + opts["type_nots"]:
        if typ not in KNOWN_TYPES:
            sys.stderr.write(f"Error: unrecognized file type: {typ}\n")
            return 1
    return 0


def type_matches(path, typ):
    name = path.name
    return any(fnmatch.fnmatch(name, pat) for pat in KNOWN_TYPES.get(typ, []))


def iter_files(paths, opts):
    if not paths:
        paths = ["."]
    for raw in paths:
        path = Path(raw)
        if path.is_dir():
            for root, dirs, files in os.walk(path, followlinks=opts["follow"]):
                if not opts["hidden"]:
                    dirs[:] = [d for d in dirs if not d.startswith(".")]
                    files = [f for f in files if not f.startswith(".")]
                for file_name in files:
                    yield Path(root) / file_name
        elif path.exists():
            if opts["hidden"] or not path.name.startswith("."):
                yield path


def included(path, opts):
    if opts["globs"] and not any(fnmatch.fnmatch(str(path), g) or fnmatch.fnmatch(path.name, g) for g in opts["globs"]):
        return False
    if opts["types"] and not any(type_matches(path, typ) for typ in opts["types"]):
        return False
    if opts["type_nots"] and any(type_matches(path, typ) for typ in opts["type_nots"]):
        return False
    try:
        mode = path.stat().st_mode
    except OSError:
        return False
    return stat.S_ISREG(mode)


def grep(pattern, paths, opts):
    flags = 0
    effective_ignore = opts["ignore_case"] or (opts["smart_case"] and pattern.lower() == pattern)
    if effective_ignore:
        flags |= re.IGNORECASE
    source = re.escape(pattern) if opts["fixed"] else pattern
    if opts["word"]:
        source = r"\b(?:" + source + r")\b"
    try:
        regex = re.compile(source, flags)
    except re.error as exc:
        sys.stderr.write(f"Error: {exc}\n")
        return 1
    matches = []
    for path in iter_files(paths, opts):
        if not included(path, opts):
            continue
        try:
            lines = path.read_text(errors="replace").splitlines()
        except OSError:
            continue
        for num, line in enumerate(lines, 1):
            if regex.search(line):
                matches.append((path, num, line))
    key = opts["sort"] or opts["sortr"]
    if key == "path":
        matches.sort(key=lambda item: str(item[0]))
    if opts["sortr"]:
        matches.reverse()
    for path, num, line in matches:
        print(f"{path}:{num}:{line}")
    return 0


def main(argv):
    try:
        action, opts = parse(argv)
    except CliError as exc:
        sys.stderr.write(str(exc))
        return exc.code
    if action == "help":
        sys.stdout.write(HELP)
        return 0
    if action == "version":
        print(VERSION)
        return 0
    if opts["type_list"]:
        if opts["positionals"]:
            sys.stderr.write(clap_error("the argument '--type-list' cannot be used with '<PATTERN>'", usage_for_error(False)))
            return 2
        sys.stdout.write(type_list())
        return 0
    if not opts["positionals"]:
        sys.stderr.write(clap_error("the following required arguments were not provided:\n  --type-list\n  <PATTERN>", usage_for_error(False)))
        return 2
    code = validate(opts)
    if code:
        return code
    pattern = opts["positionals"][0]
    paths = opts["positionals"][1:]
    if not sys.stdin.isatty() or not sys.stdout.isatty():
        sys.stderr.write("Error: Resource temporarily unavailable (os error 11)\n")
        return 1
    return grep(pattern, paths, opts)


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
