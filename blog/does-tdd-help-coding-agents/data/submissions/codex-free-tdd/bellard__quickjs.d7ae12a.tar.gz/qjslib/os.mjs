import fs from 'node:fs';

export const platform = process.platform;
export const O_RDONLY = fs.constants.O_RDONLY;
export const O_WRONLY = fs.constants.O_WRONLY;
export const O_RDWR = fs.constants.O_RDWR;
export const O_CREAT = fs.constants.O_CREAT;
export const O_TRUNC = fs.constants.O_TRUNC;

export function open(name, flags, mode) { return [fs.openSync(String(name), flags ?? 'r', mode), 0]; }
export function close(fd) { fs.closeSync(fd); return 0; }
export function read(fd, buf, offset, len) { return fs.readSync(fd, buf, offset, len, null); }
export function write(fd, buf, offset, len) { return fs.writeSync(fd, buf, offset, len); }
export function seek(fd, off) { return [off, 0]; }
export function isatty(fd) { return [Boolean(process.stdout.isTTY && fd === 1), 0]; }
export function ttyGetWinSize() { return [[80, 24], 0]; }
export function ttySetRaw() { return 0; }
export function remove(p) { fs.unlinkSync(String(p)); return 0; }
export function rename(a, b) { fs.renameSync(String(a), String(b)); return 0; }
export function realpath(p) { return [fs.realpathSync(String(p)), 0]; }
export function getcwd() { return [process.cwd(), 0]; }
export function chdir(p) { process.chdir(String(p)); return 0; }
export function mkdir(p, mode) { fs.mkdirSync(String(p), {mode}); return 0; }
export function stat(p) { return [statObj(fs.statSync(String(p))), 0]; }
export function lstat(p) { return [statObj(fs.lstatSync(String(p))), 0]; }
export function utimes(p, at, mt) { fs.utimesSync(String(p), at, mt); return 0; }
export function symlink(a, b) { fs.symlinkSync(String(a), String(b)); return 0; }
export function readlink(p) { return [fs.readlinkSync(String(p)), 0]; }
export function readdir(p) { return [[ '..', '.', ...fs.readdirSync(String(p)) ], 0]; }
export function waitpid() { return [0, 0]; }
export function pipe() { return [-1, -1]; }
export function kill(pid, sig) { process.kill(pid, sig); return 0; }
export function sleep(ms) { Atomics.wait(new Int32Array(new SharedArrayBuffer(4)), 0, 0, Math.max(0, Number(ms))); return 0; }
export const setTimeout = globalThis.setTimeout;
export const clearTimeout = globalThis.clearTimeout;
export function signal() {}
export function setReadHandler() {}
export function setWriteHandler() {}
export const Worker = globalThis.Worker;

function statObj(st) {
  return {
    dev: st.dev, ino: st.ino, mode: st.mode, nlink: st.nlink, uid: st.uid,
    gid: st.gid, rdev: st.rdev, size: st.size, blocks: st.blocks,
    atime: st.atimeMs / 1000, mtime: st.mtimeMs / 1000, ctime: st.ctimeMs / 1000,
  };
}
