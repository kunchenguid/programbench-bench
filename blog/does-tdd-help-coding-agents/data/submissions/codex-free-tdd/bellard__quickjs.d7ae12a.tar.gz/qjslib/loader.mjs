import { pathToFileURL } from 'node:url';

export async function resolve(specifier, context, nextResolve) {
  if (specifier === 'std') {
    return { url: pathToFileURL(new URL('./std.mjs', import.meta.url).pathname).href, shortCircuit: true };
  }
  if (specifier === 'os') {
    return { url: pathToFileURL(new URL('./os.mjs', import.meta.url).pathname).href, shortCircuit: true };
  }
  return nextResolve(specifier, context);
}
