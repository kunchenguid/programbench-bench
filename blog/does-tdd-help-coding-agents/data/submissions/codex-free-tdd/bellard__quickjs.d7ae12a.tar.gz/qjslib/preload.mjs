import * as stdModule from './std.mjs';
import * as osModule from './os.mjs';
import util from 'node:util';

function qjsFormat(args) {
  return args.map((v) => typeof v === 'string' ? v : util.inspect(v, {
    depth: Infinity,
    colors: false,
    compact: true,
    breakLength: Infinity,
    maxArrayLength: Infinity,
    maxStringLength: Infinity,
  }).replace(/'/g, '"')).join(' ');
}

globalThis.print = (...args) => process.stdout.write(qjsFormat(args) + '\n');
console.log = (...args) => process.stdout.write(qjsFormat(args) + '\n');
globalThis.scriptArgs = JSON.parse(process.env.QJS_SCRIPT_ARGS || '[]');

if (process.env.QJS_EXPOSE_STD === '1') {
  globalThis.std = stdModule;
  globalThis.os = osModule;
}
