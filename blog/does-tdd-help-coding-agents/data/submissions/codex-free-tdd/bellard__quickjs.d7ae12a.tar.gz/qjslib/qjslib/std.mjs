import fs from 'node:fs';
import { inspect } from 'node:util';

export const SEEK_SET = 0;
export const SEEK_CUR = 1;
export const SEEK_END = 2;
const StdError = Error;
export { StdError as Error };

export function sprintf(fmt, ...args) {
  let i = 0;
  return String(fmt).replace(/%([0 +#-]*)(\d+)?(?:\.(\d+))?([%sdifxX])/g, (m, flags, width, prec, type) => {
    if (type === '%') return '%';
    const v = args[i++];
    let out;
    if (type === 's') out = String(v);
    else if (type === 'f') out = Number(v).toFixed(prec === undefined ? 6 : Number(prec));
    else if (type === 'x' || type === 'X') {
      out = Number(v).toString(16);
      if (type === 'X') out = out.toUpperCase();
    } else {
      out = String(Number(v) | 0);
    }
    if (width) {
      const ch = flags.includes('0') && !flags.includes('-') ? '0' : ' ';
      out = flags.includes('-') ? out.padEnd(Number(width), ch) : out.padStart(Number(width), ch);
    }
    return out;
  });
}

export function printf(fmt, ...args) {
  const s = sprintf(fmt, ...args);
  process.stdout.write(s);
  return s.length;
}

export function puts(s) {
  process.stdout.write(String(s));
  return 0;
}

export function getenv(k) { return process.env[k]; }
export function setenv(k, v) { process.env[k] = String(v); return 0; }
export function unsetenv(k) { delete process.env[k]; return 0; }
export function getenviron() { return {...process.env}; }
export function exit(code = 0) { process.exit(Number(code)); }
export function gc() { if (global.gc) global.gc(); }
export function strerror(e) { return String(e); }
export function loadFile(name) { return fs.readFileSync(String(name), 'utf8'); }
export function readFile(name, flags) { return flags === 'b' ? fs.readFileSync(String(name)) : fs.readFileSync(String(name), 'utf8'); }
export function parseExtJSON(text) { return Function(`return (${text});`)(); }
export function popen() { return null; }
export function tmpfile() { return null; }
export function open(name, flags) {
  const fd = fs.openSync(String(name), flags && flags.includes('w') ? 'w+' : 'r');
  return {
    close() { fs.closeSync(fd); return 0; },
    puts(s) { fs.writeSync(fd, String(s)); return 0; },
    printf(fmt, ...args) { fs.writeSync(fd, sprintf(fmt, ...args)); return 0; },
    getline() { return undefined; },
  };
}

export default {
  SEEK_SET, SEEK_CUR, SEEK_END, Error: StdError, sprintf, printf, puts, getenv, setenv,
  unsetenv, getenviron, exit, gc, strerror, loadFile, readFile, parseExtJSON,
  popen, tmpfile, open,
};
