#!/usr/bin/env node
const fs = require('fs');
const path = require('path');
const osmod = require('os');
const util = require('util');
const vm = require('vm');
const child_process = require('child_process');

const VERSION = 'QuickJS version 2025-09-13';
const HELP = `${VERSION}
usage: qjs [options] [file [args]]
-h  --help         list options
-e  --eval EXPR    evaluate EXPR
-i  --interactive  go to interactive mode
-m  --module       load as ES6 module (default=autodetect)
    --script       load as ES6 script (default=autodetect)
    --strict       force strict mode
-I  --include file include an additional file
    --std          make 'std' and 'os' available to the loaded script
-T  --trace        trace memory allocation
-d  --dump         dump the memory usage stats
    --memory-limit n  limit the memory usage to 'n' bytes (SI suffixes allowed)
    --stack-size n    limit the stack size to 'n' bytes (SI suffixes allowed)
    --no-unhandled-rejection  ignore unhandled promise rejections
-s                    strip all the debug info
    --strip-source    strip the source code
-q  --quit         just instantiate the interpreter and quit`;

function write(s) { process.stdout.write(String(s)); }

function qjsFormat(args) {
  return args.map((v) => typeof v === 'string' ? v : util.inspect(v, {
    depth: Infinity,
    colors: false,
    compact: true,
    breakLength: Infinity,
    maxArrayLength: Infinity,
    maxStringLength: Infinity,
  }).replace(/'/g, '"')).join(' ');
}

globalThis.print = (...args) => write(qjsFormat(args) + '\n');
console.log = (...args) => write(qjsFormat(args) + '\n');

function sprintf(fmt, ...args) {
  let i = 0;
  return String(fmt).replace(/%([0 +#-]*)(\d+)?(?:\.(\d+))?([%sdifxX])/g, (m, flags, width, prec, type) => {
    if (type === '%') return '%';
    const v = args[i++];
    let out;
    if (type === 's') out = String(v);
    else if (type === 'f') out = Number(v).toFixed(prec === undefined ? 6 : Number(prec));
    else if (type === 'x' || type === 'X') {
      out = Number(v).toString(16);
      if (type === 'X') out = out.toUpperCase();
    } else {
      out = String(Number(v) | 0);
    }
    if (width) {
      const ch = flags.includes('0') && !flags.includes('-') ? '0' : ' ';
      out = flags.includes('-') ? out.padEnd(Number(width), ch) : out.padStart(Number(width), ch);
    }
    return out;
  });
}

const std = {
  SEEK_SET: 0,
  SEEK_CUR: 1,
  SEEK_END: 2,
  Error,
  sprintf,
  printf: (fmt, ...args) => { const s = sprintf(fmt, ...args); write(s); return s.length; },
  puts: (s) => { write(s); return 0; },
  getenv: (k) => process.env[k],
  setenv: (k, v) => { process.env[k] = String(v); return 0; },
  unsetenv: (k) => { delete process.env[k]; return 0; },
  getenviron: () => ({...process.env}),
  exit: (code = 0) => process.exit(Number(code)),
  gc: () => { if (global.gc) global.gc(); },
  strerror: (e) => String(e),
  loadFile: (name) => fs.readFileSync(String(name), 'utf8'),
  readFile: (name, flags) => flags === 'b' ? fs.readFileSync(String(name)) : fs.readFileSync(String(name), 'utf8'),
  open: (name, flags) => makeFile(fs.openSync(String(name), flags && flags.includes('w') ? 'w+' : 'r')),
  popen: () => null,
  tmpfile: () => null,
  parseExtJSON: (text) => Function(`return (${text});`)(),
};

function makeFile(fd) {
  return {
    fd,
    close() { fs.closeSync(fd); return 0; },
    puts(s) { fs.writeSync(fd, String(s)); return 0; },
    printf(fmt, ...args) { fs.writeSync(fd, sprintf(fmt, ...args)); return 0; },
    getline() { return undefined; },
  };
}

const os = {
  platform: process.platform,
  O_RDONLY: fs.constants.O_RDONLY,
  O_WRONLY: fs.constants.O_WRONLY,
  O_RDWR: fs.constants.O_RDWR,
  O_CREAT: fs.constants.O_CREAT,
  O_TRUNC: fs.constants.O_TRUNC,
  open: (name, flags, mode) => [fs.openSync(String(name), flags ?? 'r', mode), 0],
  close: (fd) => { fs.closeSync(fd); return 0; },
  read: (fd, buf, offset, len) => fs.readSync(fd, buf, offset, len, null),
  write: (fd, buf, offset, len) => fs.writeSync(fd, buf, offset, len),
  seek: (fd, off) => [off, 0],
  isatty: (fd) => [Boolean(process.stdout.isTTY && fd === 1), 0],
  ttyGetWinSize: () => [[80, 24], 0],
  ttySetRaw: () => 0,
  remove: (p) => { fs.unlinkSync(String(p)); return 0; },
  rename: (a, b) => { fs.renameSync(String(a), String(b)); return 0; },
  realpath: (p) => [fs.realpathSync(String(p)), 0],
  getcwd: () => [process.cwd(), 0],
  chdir: (p) => { process.chdir(String(p)); return 0; },
  mkdir: (p, mode) => { fs.mkdirSync(String(p), {mode}); return 0; },
  stat: (p) => [statArray(fs.statSync(String(p))), 0],
  lstat: (p) => [statArray(fs.lstatSync(String(p))), 0],
  utimes: (p, at, mt) => { fs.utimesSync(String(p), at, mt); return 0; },
  symlink: (a, b) => { fs.symlinkSync(String(a), String(b)); return 0; },
  readlink: (p) => [fs.readlinkSync(String(p)), 0],
  readdir: (p) => [[ '..', '.', ...fs.readdirSync(String(p)) ], 0],
  exec: (args) => child_process.spawnSync(args[0], args.slice(1), {stdio: 'inherit'}).status ?? 0,
  waitpid: () => [0, 0],
  pipe: () => [-1, -1],
  kill: (pid, sig) => { process.kill(pid, sig); return 0; },
  sleep: (ms) => Atomics.wait(new Int32Array(new SharedArrayBuffer(4)), 0, 0, Math.max(0, Number(ms))),
  setTimeout,
  clearTimeout,
  signal: () => undefined,
  setReadHandler: () => undefined,
  setWriteHandler: () => undefined,
  Worker: globalThis.Worker,
};

function statArray(st) {
  return {
    dev: st.dev, ino: st.ino, mode: st.mode, nlink: st.nlink, uid: st.uid, gid: st.gid,
    rdev: st.rdev, size: st.size, blocks: st.blocks, atime: st.atimeMs / 1000,
    mtime: st.mtimeMs / 1000, ctime: st.ctimeMs / 1000,
  };
}

function parse(argv) {
  const opts = { includes: [], module: false, script: false, std: false, eval: null, args: [] };
  for (let i = 0; i < argv.length; i++) {
    const a = argv[i];
    if (a === '-h' || a === '--help') return {...opts, help: true};
    if (a === '-q' || a === '--quit') return {...opts, quit: true};
    if (a === '-e' || a === '--eval') {
      if (i + 1 >= argv.length) return {...opts, error: 'qjs: missing expression for -e', errorCode: 2};
      opts.eval = argv[++i];
      opts.args = argv.slice(i + 1);
      return opts;
    }
    if (a === '-I' || a === '--include') {
      if (i + 1 >= argv.length) return {...opts, error: 'qjs: missing filename for -I', errorCode: 2};
      opts.includes.push(argv[++i]);
      continue;
    }
    if (a === '-m' || a === '--module') { opts.module = true; continue; }
    if (a === '--script') { opts.script = true; continue; }
    if (a === '--strict') { opts.strict = true; continue; }
    if (a === '--std') { opts.std = true; continue; }
    if (a === '-T' || a === '--trace' || a === '-d' || a === '--dump' || a === '-s' || a === '--strip-source' || a === '--no-unhandled-rejection') continue;
    if (a === '--memory-limit' || a === '--stack-size') { i++; continue; }
    if (a.startsWith('-')) return {...opts, error: `qjs: unknown option '${a}'`, showHelp: true, errorCode: 1};
    opts.file = a;
    opts.args = argv.slice(i + 1);
    return opts;
  }
  return opts;
}

function installGlobals(scriptArgs, exposeStd) {
  globalThis.scriptArgs = scriptArgs;
  if (exposeStd) {
    globalThis.std = std;
    globalThis.os = os;
  }
}

function runScriptSource(src, filename, opts) {
  installGlobals(opts.scriptArgs, opts.std);
  for (const f of opts.includes) vm.runInThisContext(fs.readFileSync(f, 'utf8'), {filename: f});
  vm.runInThisContext((opts.strict ? '"use strict";\n' : '') + src, {filename});
}

function runModule(entry, opts) {
  const env = {...process.env, QJS_SCRIPT_ARGS: JSON.stringify(opts.scriptArgs), QJS_EXPOSE_STD: opts.std ? '1' : '0'};
  const args = [
    '--no-warnings',
    '--experimental-loader', path.join(__dirname, 'qjslib', 'loader.mjs'),
    '--import', path.join(__dirname, 'qjslib', 'preload.mjs'),
    entry,
  ];
  const r = child_process.spawnSync(process.execPath, args, {stdio: 'inherit', cwd: process.cwd(), env});
  process.exit(r.status ?? 1);
}

function main() {
  const opts = parse(process.argv.slice(2));
  if (opts.error) {
    process.stderr.write(opts.error + '\n');
    if (opts.showHelp) process.stdout.write(HELP + '\n');
    process.exit(opts.errorCode);
  }
  if (opts.help) { process.stdout.write(HELP + '\n'); process.exit(1); }
  if (opts.quit) return;

  try {
    if (opts.eval !== null) {
      opts.scriptArgs = opts.args;
      if (opts.module) {
        const tmp = path.join(osmod.tmpdir(), `qjs-eval-${process.pid}.mjs`);
        fs.writeFileSync(tmp, opts.eval);
        runModule(tmp, opts);
      } else {
        runScriptSource(opts.eval, '<cmdline>', opts);
      }
      return;
    }
    if (opts.file) {
      opts.scriptArgs = [opts.file, ...opts.args];
      const isModule = opts.module || (!opts.script && /\.mjs$/.test(opts.file));
      if (isModule) runModule(path.resolve(opts.file), opts);
      else runScriptSource(fs.readFileSync(opts.file, 'utf8'), opts.file, opts);
      return;
    }
  } catch (e) {
    if (opts.eval !== null && e && e.name && e.message) {
      const m = opts.eval.match(/new\s+\w+\s*\(/);
      const col = m ? m.index + m[0].length : 1;
      process.stderr.write(`${e.name}: ${e.message}\n    at <eval> (<cmdline>:1:${col})\n`);
      process.exit(1);
    }
    const stack = String(e && e.stack || e);
    const lines = stack.split('\n');
    process.stderr.write(lines.slice(0, 2).join('\n').replace(/evalmachine\.<anonymous>/g, '<cmdline>') + '\n');
    process.exit(1);
  }
}

main();
