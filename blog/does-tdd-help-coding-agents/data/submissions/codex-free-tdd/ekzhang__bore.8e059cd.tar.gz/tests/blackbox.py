#!/usr/bin/env python3
import os
import socket
import subprocess
import sys
import time
import unittest


ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
EXE = os.path.join(ROOT, "executable")


def run_cmd(*args, env=None, timeout=5):
    merged = os.environ.copy()
    if env:
        merged.update(env)
    return subprocess.run(
        [EXE, *args],
        cwd=ROOT,
        text=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        env=merged,
        timeout=timeout,
    )


def wait_port(port, timeout=5):
    deadline = time.time() + timeout
    last_error = None
    while time.time() < deadline:
        try:
            sock = socket.create_connection(("127.0.0.1", port), timeout=0.2)
            sock.close()
            return
        except OSError as exc:
            last_error = exc
            time.sleep(0.05)
    raise AssertionError(f"port {port} did not open: {last_error}")


class BlackBoxTests(unittest.TestCase):
    def test_version_matches_documented_binary(self):
        result = run_cmd("--version")
        self.assertEqual(result.returncode, 0)
        self.assertEqual(result.stdout, "bore-cli 0.6.0\n")
        self.assertEqual(result.stderr, "")

    def test_top_level_help_lists_local_and_server_commands(self):
        result = run_cmd("--help")
        self.assertEqual(result.returncode, 0)
        self.assertIn("Usage: executable <COMMAND>", result.stdout)
        self.assertIn("  local   Starts a local proxy to the remote server", result.stdout)
        self.assertIn("  server  Runs the remote proxy server", result.stdout)

    def test_missing_local_to_argument_is_a_cli_error(self):
        result = run_cmd("local", "1234")
        self.assertEqual(result.returncode, 2)
        self.assertIn("required arguments were not provided", result.stderr)
        self.assertIn("--to <TO>", result.stderr)

    def test_equals_style_options_work_for_server_and_local(self):
        server = subprocess.Popen(
            [EXE, "server", "--min-port=25001", "--max-port=25001", "--bind-addr=127.0.0.1"],
            cwd=ROOT,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            text=True,
        )
        try:
            time.sleep(0.2)
            local = subprocess.Popen(
                [EXE, "local", "--to=127.0.0.1", "--port=25001", "9"],
                cwd=ROOT,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                text=True,
            )
            time.sleep(0.3)
            self.assertIsNone(local.poll())
            local.terminate()
            _, stderr = local.communicate(timeout=2)
            self.assertNotIn("unexpected argument", stderr)
        finally:
            server.terminate()
            server.wait(timeout=2)

    def test_local_and_server_forward_tcp_bytes(self):
        echo_ready = socket.socket()
        echo_ready.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        echo_ready.bind(("127.0.0.1", 19001))
        echo_ready.listen()

        stop_echo = False

        def serve_echo():
            while not stop_echo:
                try:
                    conn, _ = echo_ready.accept()
                except OSError:
                    return
                with conn:
                    data = conn.recv(4096)
                    if data:
                        conn.sendall(b"ECHO:" + data)

        import threading

        thread = threading.Thread(target=serve_echo, daemon=True)
        thread.start()

        server = subprocess.Popen(
            [EXE, "server", "--min-port", "25000", "--max-port", "25000", "--bind-addr", "127.0.0.1"],
            cwd=ROOT,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            text=True,
        )
        try:
            time.sleep(0.2)
            local = subprocess.Popen(
                [EXE, "local", "--to", "127.0.0.1", "--port", "25000", "19001"],
                cwd=ROOT,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
                text=True,
            )
            try:
                wait_port(25000)
                with socket.create_connection(("127.0.0.1", 25000), timeout=2) as sock:
                    sock.sendall(b"hello")
                    self.assertEqual(sock.recv(1024), b"ECHO:hello")
            finally:
                local.terminate()
                local.wait(timeout=2)
        finally:
            stop_echo = True
            server.terminate()
            server.wait(timeout=2)
            echo_ready.close()


if __name__ == "__main__":
    unittest.main()
