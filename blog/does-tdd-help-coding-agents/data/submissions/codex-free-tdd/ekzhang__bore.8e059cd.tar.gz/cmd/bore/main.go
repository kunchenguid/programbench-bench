package main

import (
	"bufio"
	"crypto/rand"
	"encoding/hex"
	"errors"
	"fmt"
	"io"
	"net"
	"os"
	"strconv"
	"strings"
	"sync"
	"time"
)

const controlPort = "7835"

type serverConfig struct {
	minPort     int
	maxPort     int
	secret      string
	bindAddr    string
	bindTunnels string
}

type localConfig struct {
	localPort int
	localHost string
	to        string
	port      int
	secret    string
}

type serverState struct {
	cfg     serverConfig
	mu      sync.Mutex
	waiting map[string]chan net.Conn
}

func main() {
	if err := run(os.Args[1:]); err != nil {
		fmt.Fprintln(os.Stderr, err)
		os.Exit(1)
	}
}

func run(args []string) error {
	if len(args) == 0 {
		printTopHelp()
		return nil
	}
	switch args[0] {
	case "-h", "--help", "help":
		if len(args) >= 2 {
			switch args[1] {
			case "local":
				printLocalHelp()
			case "server":
				printServerHelp()
			default:
				printTopHelp()
			}
		} else {
			printTopHelp()
		}
		return nil
	case "-V", "--version":
		fmt.Println("bore-cli 0.6.0")
		return nil
	case "local":
		cfg, code, err := parseLocal(args[1:])
		if err != nil {
			fmt.Fprint(os.Stderr, err.Error())
			os.Exit(code)
		}
		return runLocal(cfg)
	case "server":
		cfg, code, err := parseServer(args[1:])
		if err != nil {
			fmt.Fprint(os.Stderr, err.Error())
			os.Exit(code)
		}
		return runServer(cfg)
	default:
		fmt.Fprintf(os.Stderr, "error: unrecognized subcommand '%s'\n\nUsage: executable <COMMAND>\n\nFor more information, try '--help'.\n", args[0])
		os.Exit(2)
	}
	return nil
}

func printTopHelp() {
	fmt.Print(`A modern, simple TCP tunnel in Rust that exposes local ports to a remote server, bypassing standard NAT connection firewalls.

Usage: executable <COMMAND>

Commands:
  local   Starts a local proxy to the remote server
  server  Runs the remote proxy server
  help    Print this message or the help of the given subcommand(s)

Options:
  -h, --help     Print help
  -V, --version  Print version
`)
}

func printLocalHelp() {
	fmt.Print(`Starts a local proxy to the remote server

Usage: executable local [OPTIONS] --to <TO> <LOCAL_PORT>

Arguments:
  <LOCAL_PORT>  The local port to expose [env: BORE_LOCAL_PORT=]

Options:
  -l, --local-host <HOST>  The local host to expose [default: localhost]
  -t, --to <TO>            Address of the remote server to expose local ports to [env: BORE_SERVER=]
  -p, --port <PORT>        Optional port on the remote server to select [default: 0]
  -s, --secret <SECRET>    Optional secret for authentication [env: BORE_SECRET]
  -h, --help               Print help
`)
}

func printServerHelp() {
	fmt.Print(`Runs the remote proxy server

Usage: executable server [OPTIONS]

Options:
      --min-port <MIN_PORT>          Minimum accepted TCP port number [env: BORE_MIN_PORT=] [default: 1024]
      --max-port <MAX_PORT>          Maximum accepted TCP port number [env: BORE_MAX_PORT=] [default: 65535]
  -s, --secret <SECRET>              Optional secret for authentication [env: BORE_SECRET]
      --bind-addr <BIND_ADDR>        IP address to bind to, clients must reach this [default: 0.0.0.0]
      --bind-tunnels <BIND_TUNNELS>  IP address where tunnels will listen on, defaults to --bind-addr
  -h, --help                         Print help
`)
}

func parseLocal(args []string) (localConfig, int, error) {
	cfg := localConfig{localHost: "localhost", port: 0, to: os.Getenv("BORE_SERVER"), secret: os.Getenv("BORE_SECRET")}
	localPortText := os.Getenv("BORE_LOCAL_PORT")
	for i := 0; i < len(args); i++ {
		arg := args[i]
		if name, value, ok := strings.Cut(arg, "="); ok {
			switch name {
			case "-l", "--local-host":
				cfg.localHost = value
				continue
			case "-t", "--to":
				cfg.to = value
				continue
			case "-p", "--port":
				port, err := parsePort(value, "--port <PORT>")
				if err != nil {
					return cfg, 2, err
				}
				cfg.port = port
				continue
			case "-s", "--secret":
				cfg.secret = value
				continue
			}
		}
		switch arg {
		case "-h", "--help":
			printLocalHelp()
			os.Exit(0)
		case "-l", "--local-host":
			i++
			if i >= len(args) {
				return cfg, 2, cliMissingValue(arg)
			}
			cfg.localHost = args[i]
		case "-t", "--to":
			i++
			if i >= len(args) {
				return cfg, 2, cliMissingValue(arg)
			}
			cfg.to = args[i]
		case "-p", "--port":
			i++
			if i >= len(args) {
				return cfg, 2, cliMissingValue(arg)
			}
			port, err := parsePort(args[i], "--port <PORT>")
			if err != nil {
				return cfg, 2, err
			}
			cfg.port = port
		case "-s", "--secret":
			i++
			if i >= len(args) {
				return cfg, 2, cliMissingValue(arg)
			}
			cfg.secret = args[i]
		default:
			if strings.HasPrefix(arg, "-") {
				return cfg, 2, fmt.Errorf("error: unexpected argument '%s' found\n\nFor more information, try '--help'.\n", arg)
			}
			localPortText = arg
		}
	}
	if cfg.to == "" {
		return cfg, 2, errors.New("error: the following required arguments were not provided:\n  --to <TO>\n\nUsage: executable local --to <TO> <LOCAL_PORT>\n\nFor more information, try '--help'.\n")
	}
	if localPortText == "" {
		return cfg, 2, errors.New("error: the following required arguments were not provided:\n  <LOCAL_PORT>\n\nUsage: executable local --to <TO> <LOCAL_PORT>\n\nFor more information, try '--help'.\n")
	}
	port, err := parsePort(localPortText, "<LOCAL_PORT>")
	if err != nil {
		return cfg, 2, err
	}
	cfg.localPort = port
	return cfg, 0, nil
}

func parseServer(args []string) (serverConfig, int, error) {
	cfg := serverConfig{minPort: 1024, maxPort: 65535, secret: os.Getenv("BORE_SECRET"), bindAddr: "0.0.0.0"}
	if v := os.Getenv("BORE_MIN_PORT"); v != "" {
		p, err := parsePort(v, "--min-port <MIN_PORT>")
		if err != nil {
			return cfg, 2, err
		}
		cfg.minPort = p
	}
	if v := os.Getenv("BORE_MAX_PORT"); v != "" {
		p, err := parsePort(v, "--max-port <MAX_PORT>")
		if err != nil {
			return cfg, 2, err
		}
		cfg.maxPort = p
	}
	for i := 0; i < len(args); i++ {
		arg := args[i]
		if name, value, ok := strings.Cut(arg, "="); ok {
			switch name {
			case "--min-port":
				p, err := parsePort(value, "--min-port <MIN_PORT>")
				if err != nil {
					return cfg, 2, err
				}
				cfg.minPort = p
				continue
			case "--max-port":
				p, err := parsePort(value, "--max-port <MAX_PORT>")
				if err != nil {
					return cfg, 2, err
				}
				cfg.maxPort = p
				continue
			case "-s", "--secret":
				cfg.secret = value
				continue
			case "--bind-addr":
				cfg.bindAddr = value
				continue
			case "--bind-tunnels":
				cfg.bindTunnels = value
				continue
			}
		}
		switch arg {
		case "-h", "--help":
			printServerHelp()
			os.Exit(0)
		case "--min-port":
			i++
			if i >= len(args) {
				return cfg, 2, cliMissingValue(arg)
			}
			p, err := parsePort(args[i], "--min-port <MIN_PORT>")
			if err != nil {
				return cfg, 2, err
			}
			cfg.minPort = p
		case "--max-port":
			i++
			if i >= len(args) {
				return cfg, 2, cliMissingValue(arg)
			}
			p, err := parsePort(args[i], "--max-port <MAX_PORT>")
			if err != nil {
				return cfg, 2, err
			}
			cfg.maxPort = p
		case "-s", "--secret":
			i++
			if i >= len(args) {
				return cfg, 2, cliMissingValue(arg)
			}
			cfg.secret = args[i]
		case "--bind-addr":
			i++
			if i >= len(args) {
				return cfg, 2, cliMissingValue(arg)
			}
			cfg.bindAddr = args[i]
		case "--bind-tunnels":
			i++
			if i >= len(args) {
				return cfg, 2, cliMissingValue(arg)
			}
			cfg.bindTunnels = args[i]
		default:
			return cfg, 2, fmt.Errorf("error: unexpected argument '%s' found\n\nFor more information, try '--help'.\n", arg)
		}
	}
	if cfg.bindTunnels == "" {
		cfg.bindTunnels = cfg.bindAddr
	}
	if cfg.minPort > cfg.maxPort {
		return cfg, 2, errors.New("Error: minimum port cannot be greater than maximum port\n")
	}
	return cfg, 0, nil
}

func cliMissingValue(flag string) error {
	return fmt.Errorf("error: a value is required for '%s <VALUE>' but none was supplied\n\nFor more information, try '--help'.\n", flag)
}

func parsePort(text, label string) (int, error) {
	p, err := strconv.Atoi(text)
	if err != nil {
		return 0, fmt.Errorf("error: invalid value '%s' for '%s': invalid digit found in string\n\nFor more information, try '--help'.\n", text, label)
	}
	if p < 0 || p > 65535 {
		return 0, fmt.Errorf("error: invalid value '%s' for '%s': port number out of range\n\nFor more information, try '--help'.\n", text, label)
	}
	return p, nil
}

func runServer(cfg serverConfig) error {
	ln, err := net.Listen("tcp", net.JoinHostPort(cfg.bindAddr, controlPort))
	if err != nil {
		return fmt.Errorf("Error: %v", err)
	}
	fmt.Fprintf(os.Stderr, "server listening addr=%s\n", cfg.bindAddr)
	state := &serverState{cfg: cfg, waiting: make(map[string]chan net.Conn)}
	for {
		conn, err := ln.Accept()
		if err != nil {
			continue
		}
		go state.handleControl(conn)
	}
}

func (s *serverState) handleControl(conn net.Conn) {
	reader := bufio.NewReader(conn)
	line, err := reader.ReadString('\n')
	if err != nil {
		conn.Close()
		return
	}
	parts := strings.Fields(line)
	if len(parts) < 1 {
		conn.Close()
		return
	}
	switch parts[0] {
	case "LISTEN":
		if len(parts) < 3 || parts[2] != wireSecret(s.cfg.secret) {
			fmt.Fprintln(conn, "ERR unauthorized")
			conn.Close()
			return
		}
		requested, _ := strconv.Atoi(parts[1])
		s.handleListen(conn, requested)
	case "PROXY":
		if len(parts) < 3 || parts[2] != wireSecret(s.cfg.secret) {
			conn.Close()
			return
		}
		s.handleProxy(conn, parts[1])
	default:
		conn.Close()
	}
}

func (s *serverState) handleListen(control net.Conn, requested int) {
	port, tunnel, err := s.listenTunnel(requested)
	if err != nil {
		fmt.Fprintf(control, "ERR %v\n", err)
		control.Close()
		return
	}
	fmt.Fprintf(control, "OK %d\n", port)
	defer control.Close()
	defer tunnel.Close()
	for {
		remote, err := tunnel.Accept()
		if err != nil {
			return
		}
		id := randomID()
		ch := make(chan net.Conn, 1)
		s.mu.Lock()
		s.waiting[id] = ch
		s.mu.Unlock()
		if _, err := fmt.Fprintf(control, "CONN %s\n", id); err != nil {
			remote.Close()
			s.forget(id)
			return
		}
		go func() {
			select {
			case proxy := <-ch:
				pipeBoth(remote, proxy)
			case <-time.After(10 * time.Second):
				remote.Close()
				s.forget(id)
			}
		}()
	}
}

func (s *serverState) listenTunnel(requested int) (int, net.Listener, error) {
	if requested != 0 {
		if requested < s.cfg.minPort || requested > s.cfg.maxPort {
			return 0, nil, fmt.Errorf("requested port %d is outside allowed range", requested)
		}
		ln, err := net.Listen("tcp", net.JoinHostPort(s.cfg.bindTunnels, strconv.Itoa(requested)))
		return requested, ln, err
	}
	for port := s.cfg.minPort; port <= s.cfg.maxPort; port++ {
		ln, err := net.Listen("tcp", net.JoinHostPort(s.cfg.bindTunnels, strconv.Itoa(port)))
		if err == nil {
			return port, ln, nil
		}
	}
	return 0, nil, errors.New("no available ports")
}

func (s *serverState) handleProxy(conn net.Conn, id string) {
	s.mu.Lock()
	ch := s.waiting[id]
	delete(s.waiting, id)
	s.mu.Unlock()
	if ch == nil {
		conn.Close()
		return
	}
	ch <- conn
}

func (s *serverState) forget(id string) {
	s.mu.Lock()
	delete(s.waiting, id)
	s.mu.Unlock()
}

func runLocal(cfg localConfig) error {
	control, err := net.Dial("tcp", net.JoinHostPort(cfg.to, controlPort))
	if err != nil {
		return fmt.Errorf("Error: %v", err)
	}
	fmt.Fprintf(control, "LISTEN %d %s\n", cfg.port, wireSecret(cfg.secret))
	reader := bufio.NewReader(control)
	line, err := reader.ReadString('\n')
	if err != nil {
		return fmt.Errorf("Error: %v", err)
	}
	parts := strings.Fields(line)
	if len(parts) < 2 || parts[0] != "OK" {
		return fmt.Errorf("Error: %s", strings.TrimSpace(line))
	}
	remotePort, _ := strconv.Atoi(parts[1])
	fmt.Fprintf(os.Stderr, "connected to server remote_port=%d\n", remotePort)
	fmt.Fprintf(os.Stderr, "listening at %s:%d\n", cfg.to, remotePort)
	for {
		line, err := reader.ReadString('\n')
		if err != nil {
			return nil
		}
		parts := strings.Fields(line)
		if len(parts) == 2 && parts[0] == "CONN" {
			go proxyLocal(cfg, parts[1])
		}
	}
}

func proxyLocal(cfg localConfig, id string) {
	local, err := net.Dial("tcp", net.JoinHostPort(cfg.localHost, strconv.Itoa(cfg.localPort)))
	if err != nil {
		return
	}
	remote, err := net.Dial("tcp", net.JoinHostPort(cfg.to, controlPort))
	if err != nil {
		local.Close()
		return
	}
	fmt.Fprintf(remote, "PROXY %s %s\n", id, wireSecret(cfg.secret))
	pipeBoth(local, remote)
}

func wireSecret(secret string) string {
	if secret == "" {
		return "-"
	}
	return secret
}

func pipeBoth(a, b net.Conn) {
	var wg sync.WaitGroup
	wg.Add(2)
	go func() {
		io.Copy(a, b)
		a.Close()
		wg.Done()
	}()
	go func() {
		io.Copy(b, a)
		b.Close()
		wg.Done()
	}()
	wg.Wait()
}

func randomID() string {
	var b [16]byte
	if _, err := rand.Read(b[:]); err != nil {
		return strconv.FormatInt(time.Now().UnixNano(), 16)
	}
	return hex.EncodeToString(b[:])
}
