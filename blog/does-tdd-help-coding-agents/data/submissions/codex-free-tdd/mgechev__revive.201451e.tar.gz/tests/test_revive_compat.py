import json
import os
import subprocess
import textwrap
import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
BIN = ROOT / "executable"


class ReviveCompatTests(unittest.TestCase):
    maxDiff = None

    @classmethod
    def setUpClass(cls):
        subprocess.run([str(ROOT / "compile.sh")], cwd=ROOT, check=True)

    def run_cmd(self, *args, cwd=None):
        proc = subprocess.run(
            [str(BIN), *args],
            cwd=cwd or ROOT,
            text=True,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
        )
        return proc.returncode, proc.stdout

    def write(self, rel, content):
        path = ROOT / rel
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(textwrap.dedent(content).lstrip(), encoding="utf-8")
        return path

    def test_version_matches_documented_binary(self):
        code, out = self.run_cmd("-version")
        self.assertEqual(code, 0)
        self.assertEqual(
            out,
            "Version:\ta75b67b\n"
            "Commit:\t\ta75b67b73b9edb91dfc9f302dd108fa9d3ea5b05\n"
            "Built\t\t2026-04-17 19:59 UTC by build.sh\n",
        )

    def test_default_formatter_reports_core_rules_in_original_order(self):
        source = self.write(
            "tmp/bad.go",
            """
            // Package tmp does things.
            package tmp

            import _ "fmt"

            const Bad_name = 1

            type MyType struct{}
            func (m *MyType) Bad_name() {}
            """,
        )
        code, out = self.run_cmd(str(source))
        self.assertEqual(code, 0)
        self.assertEqual(
            out,
            f"{source}:4:8: a blank import should be only in a main or test package, or have a comment justifying it\n"
            f"{source}:6:7: exported const Bad_name should have comment or be unexported\n"
            f"{source}:8:6: exported type MyType should have comment or be unexported\n"
            f"{source}:9:1: exported method MyType.Bad_name should have comment or be unexported\n"
            f"{source}:6:7: don't use underscores in Go names; const Bad_name should be BadName\n"
            f"{source}:9:18: don't use underscores in Go names; method Bad_name should be BadName\n",
        )

    def test_unix_formatter_sorts_by_source_position_and_includes_rule(self):
        source = self.write(
            "tmp/unix.go",
            """
            // Package tmp does things.
            package tmp

            func bad_name() {}

            var Foo int
            """,
        )
        code, out = self.run_cmd("-formatter", "unix", str(source))
        self.assertEqual(code, 0)
        self.assertEqual(
            out,
            f"{source}:4:6: [var-naming] don't use underscores in Go names; func bad_name should be badName\n"
            f"{source}:6:5: [exported] exported var Foo should have comment or be unexported\n",
        )

    def test_json_formatter_has_revive_shape(self):
        source = self.write(
            "tmp/json.go",
            """
            package tmp
            """,
        )
        code, out = self.run_cmd("-formatter", "json", str(source))
        self.assertEqual(code, 0)
        payload = json.loads(out)
        self.assertEqual(payload[0]["RuleName"], "package-comments")
        self.assertEqual(payload[0]["Position"]["Start"]["Filename"], str(source))
        self.assertEqual(payload[0]["Position"]["Start"]["Line"], 1)
        self.assertEqual(payload[0]["Position"]["Start"]["Column"], 1)

    def test_json_exported_position_spans_declaration_keyword_and_name(self):
        source = self.write(
            "tmp/exported_json.go",
            """
            // Package tmp does things.
            package tmp

            var Foo int
            """,
        )
        code, out = self.run_cmd("-formatter", "json", str(source))
        self.assertEqual(code, 0)
        payload = json.loads(out)
        self.assertEqual(payload[0]["Position"]["Start"]["Column"], 5)
        self.assertEqual(payload[0]["Position"]["End"]["Column"], 12)

    def test_checkstyle_uses_reference_apostrophe_escape(self):
        source = self.write(
            "tmp/checkstyle.go",
            """
            // Package tmp does things.
            package tmp

            func bad_name() {}
            """,
        )
        code, out = self.run_cmd("-formatter", "checkstyle", str(source))
        self.assertEqual(code, 0)
        self.assertIn("don&#39;t use underscores", out)
        self.assertNotIn("don&#x27;t use underscores", out)

    def test_config_can_disable_a_rule(self):
        source = self.write("tmp/nopkg.go", "package tmp\n")
        config = self.write(
            "tmp/revive.toml",
            """
            [rule.package-comments]
              Disabled = true
            """,
        )
        code, out = self.run_cmd("-config", str(config), str(source))
        self.assertEqual(code, 0)
        self.assertEqual(out, "")

    def test_directives_suppress_named_rules(self):
        source = self.write(
            "tmp/directives.go",
            """
            package tmp

            //revive:disable:var-naming
            func bad_name() {}
            //revive:enable:var-naming

            //revive:disable-next-line:exported
            var Foo int
            var Bar int
            """,
        )
        code, out = self.run_cmd(str(source))
        self.assertEqual(code, 0)
        self.assertEqual(
            out,
            f"{source}:1:1: should have a package comment\n"
            f"{source}:9:5: exported var Bar should have comment or be unexported\n",
        )

    def test_set_exit_status_returns_one_when_findings_exist(self):
        source = self.write("tmp/exit.go", "package tmp\n")
        code, out = self.run_cmd("-set_exit_status", str(source))
        self.assertEqual(code, 1)
        self.assertEqual(out, f"{source}:1:1: should have a package comment\n")


if __name__ == "__main__":
    unittest.main()
