#!/usr/bin/env python3
import fnmatch
import html
import json
import os
import re
import sys
from dataclasses import dataclass


BANNER = r"""
 _ __ _____   _(_)__  _____
| '__/ _ \ \ / / \ \ / / _ \
| | |  __/\ V /| |\ V /  __/
|_|  \___| \_/ |_| \_/ \___|
""".strip("\n")

VERSION = (
    "Version:\ta75b67b\n"
    "Commit:\t\ta75b67b73b9edb91dfc9f302dd108fa9d3ea5b05\n"
    "Built\t\t2026-04-17 19:59 UTC by build.sh\n"
)

FORMATTERS = {
    "",
    "default",
    "json",
    "ndjson",
    "friendly",
    "stylish",
    "checkstyle",
    "sarif",
    "plain",
    "unix",
}


@dataclass
class Finding:
    filename: str
    line: int
    col: int
    end_col: int
    offset: int
    end_offset: int
    rule: str
    category: str
    confidence: float
    message: str
    severity: str = "warning"


def usage(exit_code=0, prefix=None):
    if prefix:
        print(prefix)
    print("Usage of ./executable:\n")
    print(BANNER)
    print(
        "\nExample:\n"
        "  revive -config c.toml -formatter friendly -exclude a.go -exclude b.go ./...\n"
    )
    print("  -config string")
    print(
        "\tpath to the configuration TOML file, defaults to $XDG_CONFIG_HOME/revive.toml or $HOME/revive.toml, if present (i.e. -config myconf.toml)"
    )
    print("  -exclude value")
    print("\tlist of globs which specify files to be excluded (i.e. -exclude foo/...)")
    print("  -formatter string")
    print("\tformatter to be used for the output (i.e. -formatter stylish)")
    print("  -max_open_files int")
    print("\tmaximum number of open files at the same time")
    print("  -set_exit_status")
    print("\tset exit status to 1 if any issues are found, overwrites errorCode and warningCode in config")
    print("  -version")
    print("\tget revive version")
    return exit_code


def parse_args(argv):
    opts = {
        "config": None,
        "exclude": [],
        "formatter": "default",
        "set_exit_status": False,
        "version": False,
    }
    targets = []
    i = 0
    while i < len(argv):
        arg = argv[i]
        if arg == "--help" or arg == "-h":
            opts["help"] = True
        elif arg == "-version":
            opts["version"] = True
        elif arg == "-set_exit_status":
            opts["set_exit_status"] = True
        elif arg in ("-config", "-formatter", "-exclude", "-max_open_files"):
            if i + 1 >= len(argv):
                return None, None, usage(2, f"flag needs an argument: {arg}")
            value = argv[i + 1]
            if arg == "-config":
                opts["config"] = value
            elif arg == "-formatter":
                opts["formatter"] = value
            elif arg == "-exclude":
                opts["exclude"].append(value)
            i += 1
        elif arg.startswith("-"):
            return None, None, usage(2, f"flag provided but not defined: {arg}")
        else:
            targets.append(arg)
        i += 1
    return opts, targets, None


def load_config(path):
    disabled = set()
    if not path:
        for base in (os.environ.get("XDG_CONFIG_HOME"), os.environ.get("HOME")):
            if not base:
                continue
            candidate = os.path.join(base, "revive.toml")
            if os.path.exists(candidate):
                path = candidate
                break
    if not path:
        return disabled, None
    try:
        lines = open(path, encoding="utf-8").read().splitlines()
    except OSError:
        return disabled, "cannot read the config file"
    current = None
    for raw in lines:
        line = raw.strip()
        m = re.match(r"\[rule\.([A-Za-z0-9_-]+)\]", line)
        if m:
            current = m.group(1)
            continue
        if current and re.match(r"(?i)disabled\s*=\s*true", line):
            disabled.add(current)
    return disabled, None


def expand_targets(targets, excludes):
    if not targets:
        targets = ["."]
    files = []
    for target in targets:
        if target.endswith("/..."):
            root = target[:-4] or "."
            files.extend(walk_go(root))
        elif target == "./...":
            files.extend(walk_go("."))
        elif os.path.isdir(target):
            files.extend(walk_go(target))
        else:
            files.append(target)
    result = []
    seen = set()
    for path in files:
        if not path.endswith(".go"):
            continue
        norm = os.path.normpath(path)
        if is_excluded(norm, excludes):
            continue
        if norm not in seen:
            seen.add(norm)
            result.append(norm if os.path.isabs(path) else path)
    return result


def walk_go(root):
    out = []
    for cur, dirs, names in os.walk(root):
        dirs[:] = [d for d in dirs if d not in {".git", "vendor"}]
        for name in sorted(names):
            if name.endswith(".go"):
                out.append(os.path.join(cur, name))
    return sorted(out)


def is_excluded(path, excludes):
    for pattern in excludes:
        pat = pattern.replace("/...", "/*")
        if fnmatch.fnmatch(path, pat) or fnmatch.fnmatch(os.path.basename(path), pat):
            return True
    return False


def line_offsets(text):
    starts = []
    pos = 0
    for line in text.splitlines(True):
        starts.append(pos)
        pos += len(line)
    if not starts:
        starts.append(0)
    return starts


def offset_for(starts, line, col):
    return starts[line - 1] + col - 1


def go_public(name):
    return bool(name) and name[0].isupper()


def camel(name):
    parts = [p for p in name.split("_") if p]
    if not parts:
        return name.replace("_", "")
    first = parts[0]
    rest = [p[:1].upper() + p[1:] for p in parts[1:]]
    return first + "".join(rest)


def previous_comment(lines, line_index):
    i = line_index - 1
    while i >= 0 and lines[i].strip() == "":
        i -= 1
    if i >= 0 and lines[i].lstrip().startswith("//"):
        return lines[i].strip()[2:].strip()
    return ""


def directives(lines):
    disabled_ranges = []
    next_line_disabled = {}
    active = {}
    for idx, line in enumerate(lines, start=1):
        for m in re.finditer(r"//\s*revive:(disable-next-line|disable|enable)(?::([A-Za-z0-9_-]+))?", line):
            op, rule = m.group(1), m.group(2) or "*"
            if op == "disable-next-line":
                next_line_disabled.setdefault(idx + 1, set()).add(rule)
            elif op == "disable":
                active[rule] = idx
            elif op == "enable":
                start = active.pop(rule, None)
                if start is not None:
                    disabled_ranges.append((start, idx, rule))
    for rule, start in active.items():
        disabled_ranges.append((start, 10**9, rule))
    return disabled_ranges, next_line_disabled


def suppressed(finding, ranges, next_line):
    rules = next_line.get(finding.line, set())
    if "*" in rules or finding.rule in rules:
        return True
    for start, end, rule in ranges:
        if start <= finding.line <= end and (rule == "*" or rule == finding.rule):
            return True
    return False


def add_finding(findings, filename, starts, line, col, length, rule, category, confidence, message):
    start = offset_for(starts, line, col)
    findings.append(
        Finding(
            filename=filename,
            line=line,
            col=col,
            end_col=col + length,
            offset=start,
            end_offset=start + length,
            rule=rule,
            category=category,
            confidence=confidence,
            message=message,
        )
    )


def lint_file(path, disabled_rules):
    try:
        text = open(path, encoding="utf-8").read()
    except OSError:
        print(f"cannot read {path}")
        return []
    lines = text.splitlines()
    starts = line_offsets(text)
    ranges, next_line = directives(lines)
    findings = []
    package = None
    package_line = None

    for idx, line in enumerate(lines, start=1):
        m = re.match(r"\s*package\s+([A-Za-z_][A-Za-z0-9_]*)", line)
        if m:
            package = m.group(1)
            package_line = idx
            if "package-comments" not in disabled_rules:
                comment = previous_comment(lines, idx - 1)
                expected = f"Package {package}"
                if not comment.startswith(expected):
                    col = line.index("package") + 1
                    add_finding(
                        findings,
                        path,
                        starts,
                        idx,
                        col,
                        len(m.group(0).strip()),
                        "package-comments",
                        "comments",
                        1,
                        "should have a package comment",
                    )
            break

    if "blank-imports" not in disabled_rules:
        for idx, line in enumerate(lines, start=1):
            m = re.search(r'\bimport\s+_\s+"[^"]+"', line)
            if m and package != "main" and not path.endswith("_test.go"):
                if "//" not in line[m.end() :] and not previous_comment(lines, idx - 1):
                    col = line.index("_") + 1
                    add_finding(
                        findings,
                        path,
                        starts,
                        idx,
                        col,
                        1,
                        "blank-imports",
                        "imports",
                        1,
                        "a blank import should be only in a main or test package, or have a comment justifying it",
                    )

    exported_findings = []
    naming_findings = []
    if "exported" not in disabled_rules or "var-naming" not in disabled_rules:
        type_names = set()
        for idx, line in enumerate(lines, start=1):
            stripped = line.strip()
            if not stripped or stripped.startswith("//"):
                continue
            decls = [
                (r"^(func)\s+\(\s*\w+\s+\*?([A-Za-z_][A-Za-z0-9_]*)\s*\)\s*([A-Za-z_][A-Za-z0-9_]*)", "method"),
                (r"^(func)\s+([A-Za-z_][A-Za-z0-9_]*)", "func"),
                (r"^(var)\s+([A-Za-z_][A-Za-z0-9_]*)", "var"),
                (r"^(const)\s+([A-Za-z_][A-Za-z0-9_]*)", "const"),
                (r"^(type)\s+([A-Za-z_][A-Za-z0-9_]*)", "type"),
            ]
            for pattern, kind in decls:
                m = re.match(pattern, stripped)
                if not m:
                    continue
                if kind == "method":
                    recv, name = m.group(2), m.group(3)
                    display = f"{recv}.{name}"
                    col = line.index(name) + 1
                    export_kind = "method"
                    var_kind = "method"
                else:
                    name = m.group(2)
                    display = name
                    col = line.index(name) + 1
                    export_kind = kind
                    var_kind = kind
                    if kind == "type":
                        type_names.add(name)
                if "exported" not in disabled_rules and go_public(name):
                    comment = previous_comment(lines, idx - 1)
                    if not comment.startswith(name):
                        target_col = 1 if kind == "method" else col
                        target_len = len(stripped) if kind == "method" else len(f"{export_kind} {display}")
                        add_finding(
                            exported_findings,
                            path,
                            starts,
                            idx,
                            target_col,
                            target_len,
                            "exported",
                            "comments",
                            1,
                            f"exported {export_kind} {display} should have comment or be unexported",
                        )
                if "var-naming" not in disabled_rules and "_" in name:
                    add_finding(
                        naming_findings,
                        path,
                        starts,
                        idx,
                        col,
                        len(name),
                        "var-naming",
                        "naming",
                        0.9,
                        f"don't use underscores in Go names; {var_kind} {name} should be {camel(name)}",
                    )
                break
    findings.extend(exported_findings)
    findings.extend(naming_findings)

    kept = []
    for finding in findings:
        if finding.rule in disabled_rules:
            continue
        if not suppressed(finding, ranges, next_line):
            kept.append(finding)
    return kept


def json_obj(f):
    return {
        "Severity": f.severity,
        "Failure": f.message,
        "RuleName": f.rule,
        "Category": f.category,
        "Position": {
            "Start": {
                "Filename": f.filename,
                "Offset": f.offset,
                "Line": f.line,
                "Column": f.col,
            },
            "End": {
                "Filename": f.filename,
                "Offset": f.end_offset,
                "Line": f.line,
                "Column": f.end_col,
            },
        },
        "Confidence": int(f.confidence) if f.confidence == int(f.confidence) else f.confidence,
        "ReplacementLine": "",
    }


def ordered(findings, formatter):
    if formatter in {"unix", "sarif"}:
        return sorted(findings, key=lambda f: (f.filename, f.line, f.col, f.rule))
    return findings


def render(findings, formatter):
    formatter = formatter or "default"
    findings = ordered(findings, formatter)
    if formatter == "default":
        return "".join(f"{f.filename}:{f.line}:{f.col}: {f.message}\n" for f in findings)
    if formatter == "plain":
        return "".join(f"{f.filename}:{f.line}:{f.col}: {f.message} https://revive.run/r#{f.rule}\n" for f in findings)
    if formatter == "unix":
        return "".join(f"{f.filename}:{f.line}:{f.col}: [{f.rule}] {f.message}\n" for f in findings)
    if formatter == "json":
        return json.dumps([json_obj(f) for f in findings], separators=(",", ":")) + "\n"
    if formatter == "ndjson":
        return "".join(json.dumps(json_obj(f), separators=(",", ":")) + "\n" for f in findings)
    if formatter == "checkstyle":
        by_file = {}
        for f in findings:
            by_file.setdefault(f.filename, []).append(f)
        out = ["<?xml version='1.0' encoding='UTF-8'?>", '<checkstyle version="5.0">']
        for filename, group in by_file.items():
            out.append(f'    <file name="{html.escape(filename, quote=True)}">')
            for f in group:
                conf = int(f.confidence) if f.confidence == int(f.confidence) else f.confidence
                msg = html.escape(f"{f.message} (confidence {conf})", quote=True).replace("&#x27;", "&#39;")
                out.append(
                    f'      <error line="{f.line}" column="{f.col}" message="{msg}" severity="{f.severity}" source="revive/{f.rule}"/>'
                )
            out.append("    </file>")
        out.append("</checkstyle>")
        return "\n".join(out) + "\n"
    if formatter == "friendly":
        out = []
        counts = {}
        for f in findings:
            out.append(f"  \u26a0  https://revive.run/r#{f.rule}  {f.message}")
            out.append(f"  {f.filename}:{f.line}:{f.col}\n")
            counts[f.rule] = counts.get(f.rule, 0) + 1
        out.append(f"\u26a0 {len(findings)} problems (0 errors, {len(findings)} warnings)\n")
        if findings:
            out.append("Warnings:")
            for rule in sorted(counts):
                out.append(f"  {counts[rule]}  {rule}")
            out.append("")
        return "\n".join(out) + ("\n" if out else "")
    if formatter == "stylish":
        by_file = {}
        for f in findings:
            by_file.setdefault(f.filename, []).append(f)
        out = []
        for filename, group in by_file.items():
            out.append(filename)
            for f in group:
                out.append(f"  ({f.line}, {f.col})  https://revive.run/r#{f.rule}  {f.message}")
            out.append("")
        out.append(f"\n \u2716 {len(findings)} problems (0 errors) ({len(findings)} warnings)")
        return "\n".join(out) + "\n"
    if formatter == "sarif":
        results = [
            {
                "level": f.severity,
                "locations": [
                    {
                        "physicalLocation": {
                            "artifactLocation": {"uri": f.filename},
                            "region": {"startColumn": f.col, "startLine": f.line},
                        }
                    }
                ],
                "message": {"text": f.message},
                "ruleId": f.rule,
            }
            for f in findings
        ]
        payload = {
            "runs": [
                {
                    "results": results,
                    "tool": {
                        "driver": {
                            "informationUri": "https://revive.run",
                            "name": "revive",
                            "rules": [
                                {
                                    "helpUri": "https://revive.run/r#time-naming",
                                    "id": "time-naming",
                                    "properties": {"severity": "warning"},
                                }
                            ],
                        }
                    },
                }
            ],
            "version": "2.1.0",
        }
        return json.dumps(payload, indent=2) + "\n"
    return ""


def main(argv):
    opts, targets, early = parse_args(argv)
    if early is not None:
        return early
    if opts.get("help"):
        return usage(0)
    if opts["version"]:
        sys.stdout.write(VERSION)
        return 0
    formatter = opts["formatter"] or "default"
    if formatter not in FORMATTERS:
        print(f"formatting - getting formatter: unknown formatter {formatter}")
        return 1
    disabled, err = load_config(opts["config"])
    if err:
        print(err)
        return 1
    findings = []
    for path in expand_targets(targets, opts["exclude"]):
        findings.extend(lint_file(path, disabled))
    sys.stdout.write(render(findings, formatter))
    if opts["set_exit_status"] and findings:
        return 1
    return 0


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
