#include <ctype.h>
#include <errno.h>
#include <math.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <strings.h>

#ifndef M_PI
#define M_PI 3.14159265358979323846
#endif

typedef struct {
    int channels;
    int rate;
    int bits;
    int encoding; /* 1 PCM, 3 float */
    int64_t frames;
    unsigned char *data;
    size_t data_size;
} Audio;

typedef struct {
    int rate;
    int channels;
    int bits;
    int null_input;
    int info;
    int info_total;
    char encoding[64];
} Opts;

static const char *prog;

static void die(const char *where, const char *path) {
    fprintf(stderr, "%s FAIL formats: can't open %s file `%s': %s\n", prog, where, path, strerror(errno));
    exit(1);
}

static void put_u16(FILE *f, uint16_t v) { fputc(v & 255, f); fputc((v >> 8) & 255, f); }
static void put_u32(FILE *f, uint32_t v) {
    fputc(v & 255, f); fputc((v >> 8) & 255, f); fputc((v >> 16) & 255, f); fputc((v >> 24) & 255, f);
}
static uint16_t rd16(const unsigned char *p) { return (uint16_t)p[0] | ((uint16_t)p[1] << 8); }
static uint32_t rd32(const unsigned char *p) { return (uint32_t)p[0] | ((uint32_t)p[1] << 8) | ((uint32_t)p[2] << 16) | ((uint32_t)p[3] << 24); }

static int ends_with(const char *s, const char *suffix) {
    size_t n = strlen(s), m = strlen(suffix);
    return n >= m && strcasecmp(s + n - m, suffix) == 0;
}

static double parse_time(const char *s) {
    int parts = 0;
    for (const char *p = s; *p; ++p) if (*p == ':') parts++;
    if (parts == 0) return atof(s);
    double a = 0, b = 0, c = 0;
    if (parts == 1) { sscanf(s, "%lf:%lf", &a, &b); return a * 60 + b; }
    sscanf(s, "%lf:%lf:%lf", &a, &b, &c);
    return a * 3600 + b * 60 + c;
}

static void format_duration(double sec, char *buf, size_t sz) {
    int hours = (int)(sec / 3600);
    sec -= hours * 3600;
    int mins = (int)(sec / 60);
    sec -= mins * 60;
    int whole = (int)sec;
    int hundred = (int)floor((sec - whole) * 100 + 0.5);
    if (hundred >= 100) { whole++; hundred -= 100; }
    snprintf(buf, sz, "%02d:%02d:%02d.%02d", hours, mins, whole, hundred);
}

static const char *encoding_name(const Audio *a) {
    if (a->encoding == 3) return "Floating Point PCM";
    if (a->bits == 8) return "Unsigned Integer PCM";
    return "Signed Integer PCM";
}

static void free_audio(Audio *a) {
    free(a->data);
    memset(a, 0, sizeof(*a));
}

static int read_wav(const char *path, Audio *a) {
    FILE *f = fopen(path, "rb");
    if (!f) die("input", path);
    unsigned char hdr[12];
    if (fread(hdr, 1, 12, f) != 12 || memcmp(hdr, "RIFF", 4) || memcmp(hdr + 8, "WAVE", 4)) {
        fclose(f);
        fprintf(stderr, "%s FAIL formats: can't open input file `%s': WAVE: RIFF header not found\n", prog, path);
        return 0;
    }
    int have_fmt = 0, have_data = 0;
    memset(a, 0, sizeof(*a));
    while (!have_data) {
        unsigned char ch[8];
        if (fread(ch, 1, 8, f) != 8) break;
        uint32_t size = rd32(ch + 4);
        long next = ftell(f) + (long)size + (size & 1u);
        if (!memcmp(ch, "fmt ", 4)) {
            unsigned char buf[64];
            size_t n = size < sizeof(buf) ? size : sizeof(buf);
            if (fread(buf, 1, n, f) != n) break;
            a->encoding = rd16(buf);
            a->channels = rd16(buf + 2);
            a->rate = (int)rd32(buf + 4);
            a->bits = rd16(buf + 14);
            have_fmt = 1;
        } else if (!memcmp(ch, "data", 4)) {
            if (!have_fmt) break;
            a->data = malloc(size ? size : 1);
            if (!a->data) exit(2);
            if (fread(a->data, 1, size, f) != size) break;
            a->data_size = size;
            int bytes = a->channels * ((a->bits + 7) / 8);
            a->frames = bytes ? (int64_t)(size / bytes) : 0;
            have_data = 1;
        }
        fseek(f, next, SEEK_SET);
    }
    fclose(f);
    return have_fmt && have_data;
}

static void write_wav(const char *path, const Audio *a) {
    FILE *f = strcmp(path, "-") == 0 ? stdout : fopen(path, "wb");
    if (!f) die("output", path);
    uint32_t data_size = (uint32_t)a->data_size;
    uint16_t block = (uint16_t)(a->channels * ((a->bits + 7) / 8));
    uint32_t byte_rate = (uint32_t)(a->rate * block);
    fwrite("RIFF", 1, 4, f);
    put_u32(f, 36 + data_size);
    fwrite("WAVEfmt ", 1, 8, f);
    put_u32(f, 16);
    put_u16(f, (uint16_t)a->encoding);
    put_u16(f, (uint16_t)a->channels);
    put_u32(f, (uint32_t)a->rate);
    put_u32(f, byte_rate);
    put_u16(f, block);
    put_u16(f, (uint16_t)a->bits);
    fwrite("data", 1, 4, f);
    put_u32(f, data_size);
    if (data_size) fwrite(a->data, 1, data_size, f);
    if (strcmp(path, "-") != 0) fclose(f);
}

static void load_raw(const char *path, const Opts *o, Audio *a) {
    FILE *f = fopen(path, "rb");
    if (!f) die("input", path);
    fseek(f, 0, SEEK_END);
    long n = ftell(f);
    fseek(f, 0, SEEK_SET);
    a->data = malloc(n > 0 ? (size_t)n : 1);
    if (!a->data) exit(2);
    if (n > 0 && fread(a->data, 1, (size_t)n, f) != (size_t)n) exit(2);
    fclose(f);
    a->channels = o->channels > 0 ? o->channels : 1;
    a->rate = o->rate > 0 ? o->rate : 8000;
    a->bits = o->bits > 0 ? o->bits : 8;
    a->encoding = 1;
    a->data_size = (size_t)n;
    int bytes = a->channels * ((a->bits + 7) / 8);
    a->frames = bytes ? n / bytes : 0;
}

static int32_t get_sample(const Audio *a, int64_t frame, int ch) {
    if (frame < 0) frame = 0;
    if (frame >= a->frames) frame = a->frames - 1;
    if (ch >= a->channels) ch = a->channels - 1;
    int bps = (a->bits + 7) / 8;
    unsigned char *p = a->data + (frame * a->channels + ch) * bps;
    if (a->bits == 8) return ((int)p[0] - 128) << 24;
    if (a->bits == 16) return (int16_t)rd16(p);
    if (a->bits == 24) {
        int32_t v = p[0] | (p[1] << 8) | (p[2] << 16);
        if (v & 0x800000) v |= ~0xffffff;
        return v >> 8;
    }
    return (int32_t)rd32(p);
}

static void put_sample(Audio *a, int64_t frame, int ch, int32_t v) {
    int bps = (a->bits + 7) / 8;
    unsigned char *p = a->data + (frame * a->channels + ch) * bps;
    if (a->bits == 8) {
        int x = (v >> 24) + 128; if (x < 0) x = 0; if (x > 255) x = 255; p[0] = (unsigned char)x;
    } else if (a->bits == 16) {
        if (v > 32767) v = 32767;
        if (v < -32768) v = -32768;
        p[0] = v & 255; p[1] = (v >> 8) & 255;
    } else if (a->bits == 24) {
        v <<= 8; p[0] = v & 255; p[1] = (v >> 8) & 255; p[2] = (v >> 16) & 255;
    } else {
        p[0] = v & 255; p[1] = (v >> 8) & 255; p[2] = (v >> 16) & 255; p[3] = (v >> 24) & 255;
    }
}

static void convert_audio(Audio *a, int out_rate, int out_channels, int out_bits) {
    if (out_rate <= 0) out_rate = a->rate;
    if (out_channels <= 0) out_channels = a->channels;
    if (out_bits <= 0) out_bits = a->bits;
    if (out_rate == a->rate && out_channels == a->channels && out_bits == a->bits) return;
    int64_t out_frames = a->rate ? (int64_t)llround((double)a->frames * out_rate / a->rate) : a->frames;
    if (out_frames < 0) out_frames = 0;
    Audio b = {.channels = out_channels, .rate = out_rate, .bits = out_bits, .encoding = 1, .frames = out_frames};
    int bps = (out_bits + 7) / 8;
    b.data_size = (size_t)(out_frames * out_channels * bps);
    b.data = calloc(1, b.data_size ? b.data_size : 1);
    if (!b.data) exit(2);
    for (int64_t i = 0; i < out_frames; ++i) {
        int64_t src = out_rate ? (int64_t)floor((double)i * a->rate / out_rate) : i;
        for (int ch = 0; ch < out_channels; ++ch) {
            int32_t v;
            if (out_channels < a->channels) {
                int64_t sum = 0;
                for (int c = 0; c < a->channels; ++c) sum += get_sample(a, src, c);
                v = (int32_t)(sum / a->channels);
            } else {
                v = get_sample(a, src, ch % a->channels);
            }
            put_sample(&b, i, ch, v);
        }
    }
    free_audio(a);
    *a = b;
}

static void trim_audio(Audio *a, double start, double len) {
    int64_t s = (int64_t)llround(start * a->rate);
    int64_t n = len >= 0 ? (int64_t)llround(len * a->rate) : (a->frames - s);
    if (s < 0) s = 0;
    if (s > a->frames) s = a->frames;
    if (n < 0) n = 0;
    if (s + n > a->frames) n = a->frames - s;
    int bytes = a->channels * ((a->bits + 7) / 8);
    memmove(a->data, a->data + s * bytes, (size_t)(n * bytes));
    a->frames = n;
    a->data_size = (size_t)(n * bytes);
}

static void append_audio(Audio *dst, const Audio *src) {
    size_t old_size = dst->data_size;
    size_t new_size = old_size + src->data_size;
    unsigned char *p = realloc(dst->data, new_size ? new_size : 1);
    if (!p) exit(2);
    dst->data = p;
    if (src->data_size) memcpy(dst->data + old_size, src->data, src->data_size);
    dst->data_size = new_size;
    dst->frames += src->frames;
}

static Audio make_synth(int rate, int channels, int bits, double dur, double freq) {
    if (rate <= 0) rate = 48000;
    if (channels <= 0) channels = 1;
    if (bits <= 0) bits = 32;
    int64_t frames = (int64_t)llround(dur * rate);
    Audio a = {.channels = channels, .rate = rate, .bits = bits, .encoding = 1, .frames = frames};
    int bps = (bits + 7) / 8;
    a.data_size = (size_t)(frames * channels * bps);
    a.data = calloc(1, a.data_size ? a.data_size : 1);
    if (!a.data) exit(2);
    for (int64_t i = 0; i < frames; ++i) {
        double s = sin(2.0 * M_PI * freq * i / rate) * 0.705;
        int32_t v = bits == 16 ? (int32_t)(s * 32767) : (int32_t)(s * 2147483647.0);
        for (int c = 0; c < channels; ++c) put_sample(&a, i, c, v);
    }
    return a;
}

static void print_help(void) {
    printf("%s:      SoX v14.4.2\n\n", prog);
    printf("Usage summary: [gopts] [[fopts] infile]... [fopts] outfile [effect [effopt]]...\n\n");
    printf("SPECIAL FILENAMES (infile, outfile):\n-                        Pipe/redirect input/output (stdin/stdout); may need -t\n-d, --default-device     Use the default audio device (where available)\n-n, --null               Use the `null' file handler; e.g. with synth effect\n-p, --sox-pipe           Alias for `-t sox -'\n\n");
    printf("GLOBAL OPTIONS (gopts) (can be specified at any point before the first effect):\n--buffer BYTES           Set the size of all processing buffers (default 8192)\n--clobber                Don't prompt to overwrite output file (default)\n--combine concatenate    Concatenate all input files (default for sox, rec)\n-D, --no-dither          Don't dither automatically\n-G, --guard              Use temporary files to guard against clipping\n-h, --help               Display version number and usage information\n--help-effect NAME       Show usage of effect NAME, or NAME=all for all\n--help-format NAME       Show info on format NAME, or NAME=all for all\n--i, --info              Behave as soxi(1)\n-m, --combine mix        Mix multiple input files (instead of concatenating)\n-M, --combine merge      Merge multiple input files (instead of concatenating)\n-q, --no-show-progress   Run in quiet mode; opposite of -S\n--version                Display version number of SoX and exit\n-V[LEVEL]                Increment or set verbosity level (default 2)\n");
    printf("FORMAT OPTIONS (fopts):\n-t|--type FILETYPE       File type of audio\n-e|--encoding ENCODING   Set encoding\n-b|--bits BITS           Encoded sample size in bits\n-c|--channels CHANNELS   Number of channels of audio data; e.g. 2 = stereo\n-r|--rate RATE           Sample rate of audio\n\n");
    printf("AUDIO FILE FORMATS: au raw s8 u8 s16 u16 s24 s32 wav wavpcm\nPLAYLIST FORMATS: m3u pls\nAUDIO DEVICE DRIVERS: oss ossdsp\n\n");
    printf("EFFECTS: channels fade gain norm rate remix repeat reverse silence speed stat stats synth tempo trim vol\n");
    printf("  * Deprecated effect    + Experimental effect    # LibSoX-only effect\nEFFECT OPTIONS (effopts): effect dependent; see --help-effect\n");
}

static int help_effect(const char *name) {
    printf("%s:      SoX v14.4.2\n\nEffect usage:\n\n", prog);
    if (!strcmp(name, "synth")) printf("synth [-j KEY] [-n] [length [offset [phase [p1 [p2 [p3]]]]]]] {type [combine] [[%%]freq[k][:|+|/|-[%%]freq2[k]] [offset [phase [p1 [p2 [p3]]]]]]}\n\n");
    else if (!strcmp(name, "trim")) printf("trim {position}\n\n");
    else if (!strcmp(name, "rate")) printf("rate [override-options] RATE[k]\n\n");
    else printf("%s [options]\n\n", name);
    return 1;
}

static void print_info(const char *path, const Audio *a, const char *field) {
    double sec = a->rate ? (double)a->frames / a->rate : 0;
    char dur[64]; format_duration(sec, dur, sizeof(dur));
    if (field) {
        if (!strcmp(field, "-t")) printf("wav\n");
        else if (!strcmp(field, "-r")) printf("%d\n", a->rate);
        else if (!strcmp(field, "-c")) printf("%d\n", a->channels);
        else if (!strcmp(field, "-s")) printf("%lld\n", (long long)a->frames);
        else if (!strcmp(field, "-d")) printf("%s\n", dur);
        else if (!strcmp(field, "-D")) printf("%.6f\n", sec);
        else if (!strcmp(field, "-b")) printf("%d\n", a->bits);
        else if (!strcmp(field, "-e")) printf("%s\n", encoding_name(a));
        else if (!strcmp(field, "-B")) {
            double kbps = sec > 0 ? (a->data_size + 44) * 8.0 / sec / 1000.0 : 0;
            if (kbps >= 100) printf("%.0fk\n", kbps); else printf("%.1fk\n", kbps);
        } else if (!strcmp(field, "-p")) printf("%d\n", a->bits);
        else if (!strcmp(field, "-a")) {}
        return;
    }
    double sectors = a->rate ? (double)a->frames / (a->rate / 75.0) : 0;
    double size = a->data_size + 44;
    char sizebuf[32];
    if (size >= 1000) snprintf(sizebuf, sizeof(sizebuf), "%.3gk", size / 1000.0);
    else snprintf(sizebuf, sizeof(sizebuf), "%.0f", size);
    double kbps = sec > 0 ? (a->data_size + 44) * 8.0 / sec / 1000.0 : 0;
    printf("\nInput File     : '%s'\n", path);
    printf("Channels       : %d\nSample Rate    : %d\nPrecision      : %d-bit\n", a->channels, a->rate, a->bits);
    printf("Duration       : %s = %lld samples ~ %.5g CDDA sectors\n", dur, (long long)a->frames, sectors);
    printf("File Size      : %s\nBit Rate       : %s%.1fk\nSample Encoding: %d-bit %s\n\n",
           sizebuf, kbps >= 100 ? "" : "", kbps, a->bits, encoding_name(a));
}

static int is_effect(const char *s) {
    const char *effects[] = {"trim","rate","channels","vol","gain","norm","fade","speed","tempo","reverse","synth","stat","stats",NULL};
    for (int i = 0; effects[i]; ++i) if (!strcmp(s, effects[i])) return 1;
    return 0;
}

int main(int argc, char **argv) {
    prog = argv[0];
    Opts o = {.rate = 0, .channels = 0, .bits = 0, .null_input = 0, .info = 0, .info_total = 0};
    strcpy(o.encoding, "signed-integer");
    if (argc == 1) { print_help(); return 0; }
    for (int i = 1; i < argc; ++i) {
        if (!strcmp(argv[i], "--version")) { printf("%s:      SoX v14.4.2\n", prog); return 0; }
        if (!strcmp(argv[i], "-h") || !strcmp(argv[i], "--help")) { print_help(); return 0; }
        if (!strcmp(argv[i], "--help-effect") && i + 1 < argc) return help_effect(argv[i + 1]);
        if (!strcmp(argv[i], "--i") || !strcmp(argv[i], "--info")) o.info = 1;
    }
    const char *field = NULL;
    if (o.info) {
        const char *files[128]; int nf = 0;
        for (int i = 1; i < argc; ++i) {
            char *a = argv[i];
            if (!strcmp(a, "--i") || !strcmp(a, "--info") || !strncmp(a, "-V", 2)) continue;
            if (!strcmp(a, "-T")) { o.info_total = 1; continue; }
            if ((!strcmp(a, "-t") || !strcmp(a, "-r") || !strcmp(a, "-c") || !strcmp(a, "-s") || !strcmp(a, "-d") || !strcmp(a, "-D") || !strcmp(a, "-b") || !strcmp(a, "-B") || !strcmp(a, "-p") || !strcmp(a, "-e") || !strcmp(a, "-a")) && !field) { field = a; continue; }
            files[nf++] = a;
        }
        if (!nf) return 1;
        int64_t total_frames = 0; double total_sec = 0;
        for (int i = 0; i < nf; ++i) {
            Audio au;
            if (!read_wav(files[i], &au)) return 1;
            if (o.info_total && field && (!strcmp(field, "-s") || !strcmp(field, "-d") || !strcmp(field, "-D"))) {
                total_frames += au.frames; total_sec += au.rate ? (double)au.frames / au.rate : 0; free_audio(&au); continue;
            }
            print_info(files[i], &au, field);
            free_audio(&au);
        }
        if (o.info_total && field) {
            if (!strcmp(field, "-s")) printf("%lld\n", (long long)total_frames);
            else if (!strcmp(field, "-D")) printf("%.6f\n", total_sec);
            else if (!strcmp(field, "-d")) { char d[64]; format_duration(total_sec, d, sizeof(d)); printf("%s\n", d); }
        }
        return 0;
    }

    const char *tokens[256]; int nt = 0;
    int in_effects = 0;
    for (int i = 1; i < argc; ++i) {
        char *a = argv[i];
        if (!strcmp(a, "-q") || !strcmp(a, "-S") || !strcmp(a, "-D") || !strcmp(a, "-G") || !strcmp(a, "--norm") || !strncmp(a, "-V", 2)) continue;
        if ((!strcmp(a, "-r") || !strcmp(a, "--rate")) && i + 1 < argc) { o.rate = (int)atof(argv[++i]); continue; }
        if ((!strcmp(a, "-c") || !strcmp(a, "--channels")) && i + 1 < argc) { o.channels = atoi(argv[++i]); continue; }
        if ((!strcmp(a, "-b") || !strcmp(a, "--bits")) && i + 1 < argc) { o.bits = atoi(argv[++i]); continue; }
        if ((!strcmp(a, "-e") || !strcmp(a, "--encoding")) && i + 1 < argc) { strncpy(o.encoding, argv[++i], sizeof(o.encoding) - 1); continue; }
        if ((!strcmp(a, "-t") || !strcmp(a, "--type") || !strcmp(a, "-C") || !strcmp(a, "-v") || !strcmp(a, "--volume") || !strcmp(a, "--comment") || !strcmp(a, "--add-comment")) && i + 1 < argc) { i++; continue; }
        if (!strcmp(a, "-n") || !strcmp(a, "--null")) { o.null_input = 1; continue; }
        if (!in_effects && is_effect(a)) in_effects = 1;
        tokens[nt++] = a;
    }
    const char *infile = NULL, *outfile = NULL;
    int effect_start = nt;
    for (int i = 0; i < nt; ++i) if (is_effect(tokens[i])) { effect_start = i; break; }
    if (o.null_input) {
        if (effect_start < 1) return 1;
        outfile = tokens[0];
    } else {
        if (effect_start < 2) return 1;
        infile = tokens[0]; outfile = tokens[effect_start - 1];
    }
    Audio au;
    if (o.null_input) {
        double dur = 0, freq = 440;
        for (int i = effect_start; i < nt; ++i) {
            if (!strcmp(tokens[i], "synth") && i + 1 < nt) {
                dur = parse_time(tokens[i + 1]);
                if (i + 3 < nt) freq = atof(tokens[i + 3]);
            }
        }
        au = make_synth(o.rate, o.channels, o.bits, dur > 0 ? dur : 1.0, freq > 0 ? freq : 440);
    } else {
        if (ends_with(infile, ".wav") || ends_with(infile, ".wave")) {
            if (!read_wav(infile, &au)) return 1;
        } else {
            load_raw(infile, &o, &au);
        }
        for (int j = 1; j < effect_start - 1; ++j) {
            Audio extra;
            if (ends_with(tokens[j], ".wav") || ends_with(tokens[j], ".wave")) {
                if (!read_wav(tokens[j], &extra)) return 1;
            } else {
                load_raw(tokens[j], &o, &extra);
            }
            convert_audio(&extra, au.rate, au.channels, au.bits);
            append_audio(&au, &extra);
            free_audio(&extra);
        }
    }
    int out_rate = o.rate > 0 ? o.rate : au.rate;
    int out_channels = o.channels > 0 ? o.channels : au.channels;
    int out_bits = o.bits > 0 ? o.bits : au.bits;
    for (int i = effect_start; i < nt; ++i) {
        if (!strcmp(tokens[i], "trim") && i + 1 < nt) {
            double start = parse_time(tokens[++i]);
            double len = -1;
            if (i + 1 < nt && !is_effect(tokens[i + 1])) len = parse_time(tokens[++i]);
            trim_audio(&au, start, len);
        } else if (!strcmp(tokens[i], "rate") && i + 1 < nt) {
            out_rate = (int)atof(tokens[++i]);
        } else if (!strcmp(tokens[i], "channels") && i + 1 < nt) {
            out_channels = atoi(tokens[++i]);
        } else if (!strcmp(tokens[i], "vol") || !strcmp(tokens[i], "gain") || !strcmp(tokens[i], "fade") || !strcmp(tokens[i], "norm") || !strcmp(tokens[i], "speed") || !strcmp(tokens[i], "tempo")) {
            while (i + 1 < nt && !is_effect(tokens[i + 1])) i++;
        }
    }
    convert_audio(&au, out_rate, out_channels, out_bits);
    write_wav(outfile, &au);
    free_audio(&au);
    return 0;
}
