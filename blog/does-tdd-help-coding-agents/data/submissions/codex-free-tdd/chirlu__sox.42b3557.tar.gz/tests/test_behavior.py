#!/usr/bin/env python3
import math
import os
import shutil
import struct
import subprocess
import sys
import tempfile
import wave


ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
EXE = os.path.join(ROOT, "executable")


def run(args, cwd):
    return subprocess.run([EXE] + args, cwd=cwd, text=True, capture_output=True)


def make_wav(path, channels=1, rate=8000, seconds=0.1):
    n = int(rate * seconds)
    with wave.open(path, "wb") as w:
        w.setnchannels(channels)
        w.setsampwidth(2)
        w.setframerate(rate)
        frames = []
        for i in range(n):
            sample = int(12000 * math.sin(2 * math.pi * 440 * i / rate))
            for _ in range(channels):
                frames.append(struct.pack("<h", sample))
        w.writeframes(b"".join(frames))


def assert_ok(proc):
    assert proc.returncode == 0, (proc.returncode, proc.stdout, proc.stderr)


def test_version_and_help():
    with tempfile.TemporaryDirectory() as td:
        p = run(["--version"], td)
        assert_ok(p)
        assert p.stdout.strip() == f"{EXE}:      SoX v14.4.2"
        p = run(["--help"], td)
        assert_ok(p)
        assert "Usage summary:" in p.stdout
        assert "AUDIO FILE FORMATS:" in p.stdout
        assert "EFFECTS:" in p.stdout


def test_soxi_wav_fields():
    with tempfile.TemporaryDirectory() as td:
        wav_path = os.path.join(td, "tone.wav")
        make_wav(wav_path)
        expectations = {
            "-t": "wav",
            "-r": "8000",
            "-c": "1",
            "-s": "800",
            "-d": "00:00:00.10",
            "-D": "0.100000",
            "-b": "16",
            "-e": "Signed Integer PCM",
        }
        for opt, expected in expectations.items():
            p = run(["--i", opt, wav_path], td)
            assert_ok(p)
            assert p.stdout.strip() == expected
        p = run(["--i", wav_path], td)
        assert_ok(p)
        assert "Input File     : '" in p.stdout
        assert "Channels       : 1" in p.stdout
        assert "Sample Rate    : 8000" in p.stdout
        assert "Duration       : 00:00:00.10 = 800 samples" in p.stdout
        assert "Sample Encoding: 16-bit Signed Integer PCM" in p.stdout


def test_wav_copy_trim_rate_channels_and_raw_import():
    with tempfile.TemporaryDirectory() as td:
        src = os.path.join(td, "tone.wav")
        make_wav(src)
        for args, out, expected in [
            ([src, "copy.wav"], "copy.wav", (1, 8000, 800)),
            ([src, "trim.wav", "trim", "0", "0.05"], "trim.wav", (1, 8000, 400)),
            ([src, "-r", "4000", "rate.wav"], "rate.wav", (1, 4000, 400)),
            ([src, "-c", "2", "stereo.wav"], "stereo.wav", (2, 8000, 800)),
        ]:
            p = run(args, td)
            assert_ok(p)
            with wave.open(os.path.join(td, out), "rb") as w:
                assert (w.getnchannels(), w.getframerate(), w.getnframes()) == expected
        raw = os.path.join(td, "raw.u8")
        with open(raw, "wb") as f:
            f.write(bytes([0, 64, 128, 192, 255]) * 100)
        p = run(["-r", "8000", "-e", "unsigned-integer", "-b", "8", "-c", "1", raw, "raw.wav"], td)
        assert_ok(p)
        with wave.open(os.path.join(td, "raw.wav"), "rb") as w:
            assert (w.getnchannels(), w.getsampwidth(), w.getframerate(), w.getnframes()) == (1, 1, 8000, 500)


def test_synth_creates_expected_header():
    with tempfile.TemporaryDirectory() as td:
        p = run(["-n", "-r", "8000", "-c", "1", "synth.wav", "synth", "0.1", "sine", "440"], td)
        assert_ok(p)
        with wave.open(os.path.join(td, "synth.wav"), "rb") as w:
            assert (w.getnchannels(), w.getsampwidth(), w.getframerate(), w.getnframes()) == (1, 4, 8000, 800)


def test_multiple_wav_inputs_concatenate():
    with tempfile.TemporaryDirectory() as td:
        first = os.path.join(td, "first.wav")
        second = os.path.join(td, "second.wav")
        make_wav(first, seconds=0.1)
        make_wav(second, seconds=0.05)
        p = run([first, second, "joined.wav"], td)
        assert_ok(p)
        with wave.open(os.path.join(td, "joined.wav"), "rb") as w:
            assert (w.getnchannels(), w.getframerate(), w.getnframes()) == (1, 8000, 1200)


def main():
    tests = [
        test_version_and_help,
        test_soxi_wav_fields,
        test_wav_copy_trim_rate_channels_and_raw_import,
        test_synth_creates_expected_header,
        test_multiple_wav_inputs_concatenate,
    ]
    for test in tests:
        test()
    print(f"{len(tests)} tests passed")


if __name__ == "__main__":
    main()
