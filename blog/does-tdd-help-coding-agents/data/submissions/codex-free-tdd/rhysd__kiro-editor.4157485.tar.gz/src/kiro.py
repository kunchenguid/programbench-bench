#!/usr/bin/env python3
import codecs
import os
import sys
import termios
import tty


VERSION = "0.4.3"
HELP = """{prog}: A tiny UTF-8 terminal text editor

Kiro is a tiny UTF-8 text editor on terminals for Unix-like systems.
Specify file paths to edit as a command argument or run without argument to
start to write a new text.
Help can show up with key mapping Ctrl-?.

Usage:
    {prog} [options] [FILES...]

Mappings:
    Ctrl-Q                        : Quit
    Ctrl-S                        : Save to file
    Ctrl-O                        : Open text buffer
    Ctrl-X                        : Next text buffer
    Alt-X                         : Previous text buffer
    Ctrl-P or UP                  : Move cursor up
    Ctrl-N or DOWN                : Move cursor down
    Ctrl-F or RIGHT               : Move cursor right
    Ctrl-B or LEFT                : Move cursor left
    Ctrl-A or Alt-LEFT or HOME    : Move cursor to head of line
    Ctrl-E or Alt-RIGHT or END    : Move cursor to end of line
    Ctrl-[ or Ctrl-V or PAGE DOWN : Next page
    Ctrl-] or Alt-V or PAGE UP    : Previous page
    Alt-F or Ctrl-RIGHT           : Move cursor to next word
    Alt-B or Ctrl-LEFT            : Move cursor to previous word
    Alt-N or Ctrl-DOWN            : Move cursor to next paragraph
    Alt-P or Ctrl-UP              : Move cursor to previous paragraph
    Alt-<                         : Move cursor to top of file
    Alt->                         : Move cursor to bottom of file
    Ctrl-H or BACKSPACE           : Delete character
    Ctrl-D or DELETE              : Delete next character
    Ctrl-W                        : Delete a word
    Ctrl-J                        : Delete until head of line
    Ctrl-K                        : Delete until end of line
    Ctrl-U                        : Undo last change
    Ctrl-R                        : Redo last undo change
    Ctrl-G                        : Search text
    Ctrl-M                        : New line
    Ctrl-L                        : Refresh screen
    Ctrl-?                        : Show this help

Options:
    -v, --version       Print version
    -h, --help          Print this help
"""


class UsageError(Exception):
    pass


def parse_args(argv):
    files = []
    help_seen = False
    version_seen = False
    for arg in argv:
        if arg == "--help":
            help_seen = True
        elif arg == "--version":
            if version_seen:
                raise UsageError("Option 'version' given more than once. Please see --help for more details")
            version_seen = True
        elif arg.startswith("--") and arg != "--":
            raise UsageError(f"Unrecognized option: '{arg[2:]}'. Please see --help for more details")
        elif arg.startswith("-") and len(arg) > 1 and arg != "--":
            for ch in arg[1:]:
                if ch == "h":
                    help_seen = True
                elif ch == "v":
                    if version_seen:
                        raise UsageError("Option 'version' given more than once. Please see --help for more details")
                    version_seen = True
                else:
                    raise UsageError(f"Unrecognized option: '{ch}'. Please see --help for more details")
        else:
            files.append(arg)
    return help_seen, version_seen, files


class Editor:
    def __init__(self, files):
        self.files = files[:] or [None]
        self.index = 0
        self.buffers = []
        for path in self.files:
            self.buffers.append(self.load(path))
        size = os.get_terminal_size(0)
        self.cols, self.rows = size.columns, size.lines
        self.cx = 0
        self.cy = 0
        self.rowoff = 0
        self.message = "Ctrl-? for help"
        self.decoder = codecs.getincrementaldecoder("utf-8")()
        self.running = True

    def load(self, path):
        if path is None:
            return {"name": None, "lines": [""], "modified": False, "undo": [], "redo": []}
        try:
            with open(path, "r", encoding="utf-8") as f:
                data = f.read()
        except FileNotFoundError:
            return {"name": path, "lines": [""], "modified": False, "undo": [], "redo": []}
        lines = data.splitlines()
        if not lines:
            lines = [""]
        return {"name": path, "lines": lines, "modified": False, "undo": [], "redo": []}

    @property
    def buf(self):
        return self.buffers[self.index]

    def write(self, s):
        os.write(1, s.encode("utf-8", "replace"))

    def refresh(self):
        b = self.buf
        self.write("\x1b[?25l\x1b[39;0m")
        screen_rows = max(1, self.rows - 2)
        for y in range(screen_rows):
            self.write(f"\x1b[{y+1}H")
            filerow = y + self.rowoff
            if filerow < len(b["lines"]) and not (len(b["lines"]) == 1 and b["lines"][0] == "" and b["name"] is None):
                self.write("\x1b[39;0m")
                self.write(b["lines"][filerow][: self.cols])
            else:
                self.write("\x1b[37m~")
                if b["name"] is None and len(b["lines"]) == 1 and b["lines"][0] == "" and y == screen_rows // 3:
                    welcome = f"Kiro editor -- version {VERSION}"
                    if len(welcome) < self.cols:
                        self.write("\x1b[39;0m" + " " * ((self.cols - len(welcome)) // 2) + welcome)
            self.write("\x1b[K")
        self.draw_status()
        self.write(f"\x1b[{self.rows}H{self.message[:self.cols]}\x1b[K")
        cur_y = min(self.cy - self.rowoff + 1, screen_rows)
        cur_x = min(self.cx + 1, self.cols)
        self.write(f"\x1b[{cur_y};{cur_x}H\x1b[?25h")

    def draw_status(self):
        b = self.buf
        name = b["name"] if b["name"] else "[No Name]"
        left = f'"{name}" - {self.index+1}/{len(self.buffers)}'
        if b["modified"]:
            left += " (modified)"
        right = f"plain {self.cy+1}/{max(1, len(b['lines']))}"
        room = max(1, self.cols - len(left) - len(right))
        status = (left + " " * room + right)[: self.cols]
        self.write(f"\x1b[{self.rows-1}H\x1b[7m{status}\x1b[39;0m")

    def insert_char(self, ch):
        self.record_change()
        line = self.buf["lines"][self.cy]
        self.buf["lines"][self.cy] = line[: self.cx] + ch + line[self.cx :]
        self.cx += 1
        self.buf["modified"] = True

    def newline(self):
        self.record_change()
        line = self.buf["lines"][self.cy]
        self.buf["lines"][self.cy] = line[: self.cx]
        self.buf["lines"].insert(self.cy + 1, line[self.cx :])
        self.cy += 1
        self.cx = 0
        self.buf["modified"] = True

    def backspace(self):
        if self.cx:
            self.record_change()
            line = self.buf["lines"][self.cy]
            self.buf["lines"][self.cy] = line[: self.cx - 1] + line[self.cx :]
            self.cx -= 1
            self.buf["modified"] = True
        elif self.cy:
            self.record_change()
            prev_len = len(self.buf["lines"][self.cy - 1])
            self.buf["lines"][self.cy - 1] += self.buf["lines"].pop(self.cy)
            self.cy -= 1
            self.cx = prev_len
            self.buf["modified"] = True

    def delete(self):
        line = self.buf["lines"][self.cy]
        if self.cx < len(line):
            self.record_change()
            self.buf["lines"][self.cy] = line[: self.cx] + line[self.cx + 1 :]
            self.buf["modified"] = True
        elif self.cy + 1 < len(self.buf["lines"]):
            self.record_change()
            self.buf["lines"][self.cy] += self.buf["lines"].pop(self.cy + 1)
            self.buf["modified"] = True

    def move(self, key):
        if key == "left":
            if self.cx:
                self.cx -= 1
            elif self.cy:
                self.cy -= 1
                self.cx = len(self.buf["lines"][self.cy])
        elif key == "right":
            if self.cx < len(self.buf["lines"][self.cy]):
                self.cx += 1
            elif self.cy + 1 < len(self.buf["lines"]):
                self.cy += 1
                self.cx = 0
        elif key == "up" and self.cy:
            self.cy -= 1
        elif key == "down" and self.cy + 1 < len(self.buf["lines"]):
            self.cy += 1
        self.cx = min(self.cx, len(self.buf["lines"][self.cy]))
        if self.cy < self.rowoff:
            self.rowoff = self.cy
        elif self.cy >= self.rowoff + self.rows - 2:
            self.rowoff = self.cy - (self.rows - 3)

    def switch_buffer(self, delta):
        if not self.buffers:
            return
        self.index = (self.index + delta) % len(self.buffers)
        self.cx = 0
        self.cy = 0
        self.rowoff = 0
        self.message = "Ctrl-? for help"

    def save(self):
        if not self.buf["name"]:
            name = self.prompt("Save as: ")
            if not name:
                self.message = "Save cancelled"
                return
            self.buf["name"] = name
        data = "\n".join(self.buf["lines"]) + "\n"
        with open(self.buf["name"], "w", encoding="utf-8") as f:
            f.write(data)
        self.buf["modified"] = False
        self.message = f"{len(data.encode('utf-8'))} bytes written to {self.buf['name']}"

    def snapshot(self):
        return ([line for line in self.buf["lines"]], self.cx, self.cy)

    def restore(self, snap):
        lines, self.cx, self.cy = snap
        self.buf["lines"] = [line for line in lines] or [""]
        self.cy = min(self.cy, len(self.buf["lines"]) - 1)
        self.cx = min(self.cx, len(self.buf["lines"][self.cy]))
        self.buf["modified"] = True

    def record_change(self):
        self.buf["undo"].append(self.snapshot())
        self.buf["redo"].clear()

    def undo(self):
        if not self.buf["undo"]:
            return
        self.buf["redo"].append(self.snapshot())
        self.restore(self.buf["undo"].pop())

    def redo(self):
        if not self.buf["redo"]:
            return
        self.buf["undo"].append(self.snapshot())
        self.restore(self.buf["redo"].pop())

    def prompt(self, label):
        s = ""
        while True:
            self.message = f"{label}{s} (^G or ESC to cancel)"
            self.refresh()
            ch = self.read_key()
            if ch in ("\r", "\n"):
                return s
            if ch in ("\x1b", "\x07"):
                return None
            if ch in ("\x7f", "\x08"):
                s = s[:-1]
            elif ch and ord(ch) >= 32:
                s += ch

    def read_key(self):
        b = os.read(0, 1)
        if not b:
            return ""
        if b == b"\x1b":
            seq = b""
            for _ in range(5):
                r, _, _ = select_timeout(0.001)
                if not r:
                    break
                seq += os.read(0, 1)
            mapping = {b"[A": "up", b"[B": "down", b"[C": "right", b"[D": "left", b"[H": "home", b"[F": "end"}
            return mapping.get(seq, "\x1b")
        try:
            ch = self.decoder.decode(b)
            while ch == "":
                ch = self.decoder.decode(os.read(0, 1))
            return ch
        except UnicodeDecodeError:
            self.decoder.reset()
            return ""

    def handle(self, ch):
        if ch in ("",):
            self.running = False
        elif ch == "\x11":
            self.running = False
        elif ch == "\x13":
            self.save()
        elif ch == "\x18":
            self.switch_buffer(1)
        elif ch == "\r":
            self.newline()
        elif ch in ("\x7f", "\x08"):
            self.backspace()
        elif ch == "\x04":
            self.delete()
        elif ch == "\x01":
            self.cx = 0
        elif ch == "\x05":
            self.cx = len(self.buf["lines"][self.cy])
        elif ch == "\x02":
            self.move("left")
        elif ch == "\x06":
            self.move("right")
        elif ch == "\x10":
            self.move("up")
        elif ch == "\x0e":
            self.move("down")
        elif ch == "\x0b":
            self.record_change()
            self.buf["lines"][self.cy] = self.buf["lines"][self.cy][: self.cx]
            self.buf["modified"] = True
        elif ch == "\x0a":
            self.record_change()
            self.buf["lines"][self.cy] = self.buf["lines"][self.cy][self.cx :]
            self.cx = 0
            self.buf["modified"] = True
        elif ch == "\x0c":
            pass
        elif ch == "\x7f":
            self.backspace()
        elif ch == "\x1f":
            self.message = "Ctrl-? for help"
        elif ch == "\x15":
            self.undo()
        elif ch == "\x12":
            self.redo()
        elif ch in ("left", "right", "up", "down"):
            self.move(ch)
        elif len(ch) == 1 and ord(ch) >= 32:
            self.insert_char(ch)

    def run(self):
        old = termios.tcgetattr(0)
        try:
            tty.setraw(0)
            self.write("\x1b[?1049h")
            self.refresh()
            while self.running:
                self.handle(self.read_key())
                if self.running:
                    self.refresh()
        finally:
            termios.tcsetattr(0, termios.TCSAFLUSH, old)
            self.write("\x1b[?1049l\x1b[H")


def select_timeout(seconds):
    import select

    return select.select([0], [], [], seconds)


def main(argv):
    prog = sys.argv[0]
    try:
        show_help, show_version, files = parse_args(argv)
    except UsageError as e:
        print(f"Error: {e}", file=sys.stderr)
        return 1
    if show_version:
        print(VERSION)
        return 0
    if show_help:
        print(HELP.format(prog=prog))
        return 0
    try:
        Editor(files).run()
        return 0
    except termios.error:
        print("Error: Inappropriate ioctl for device (os error 25)", file=sys.stderr)
        return 1
    except OSError as e:
        print(f"Error: {e}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
