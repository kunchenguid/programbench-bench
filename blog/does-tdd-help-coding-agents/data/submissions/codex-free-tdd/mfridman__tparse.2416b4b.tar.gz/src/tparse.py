#!/usr/bin/env python3
import argparse
import json
import os
import re
import sys
from dataclasses import dataclass, field


HELP = """Usage:
    go test ./... -json | tparse [options...]
    go test [packages...] -json | tparse [options...]
    go test [packages...] -json > pkgs.out ; tparse [options...] -file pkgs.out

Options:
    -h                 Show help.
    -v                 Show version.
    -all               Display table event for pass and skip. (Failed items always displayed)
    -pass              Display table for passed tests.
    -skip              Display table for skipped tests.
    -notests           Display packages containing no test files or empty test files.
    -smallscreen       Split subtest names vertically to fit on smaller screens.
    -slow              Number of slowest tests to display. Default is 0, display all.
    -sort              Sort table output by attribute [name, elapsed, cover]. Default is name.
    -nocolor           Disable all colors. (NO_COLOR also supported)
    -format            The output format for tables [basic, plain, markdown]. Default is basic.
    -file              Read test output from a file.
    -follow            Follow raw output from go test to stdout.
    -follow-output     Write raw output from go test to a file (takes precedence over -follow).
    -include-timestamp Include timestamps in follow output. 
    -progress          Print a single summary line for each package. Useful for long running test suites.
    -compare           Compare against a previous test output file. (experimental)
    -trimpath          Remove path prefix from package names in output, simplifying their display.
"""


@dataclass
class TestEvent:
    package: str
    test: str
    status: str
    elapsed: float = 0.0


@dataclass
class Package:
    name: str
    status: str = ""
    elapsed: float = 0.0
    cover: str = "--"
    output: list[str] = field(default_factory=list)
    test_output: dict[str, list[str]] = field(default_factory=dict)
    tests: list[TestEvent] = field(default_factory=list)
    no_test_reason: str | None = None


def parse_args(argv):
    if "-h" in argv or "--help" in argv:
        print(HELP, end="")
        raise SystemExit(0)
    if "-v" in argv or "--version" in argv:
        print("tparse version: (devel)")
        raise SystemExit(0)

    parser = argparse.ArgumentParser(add_help=False)
    parser.add_argument("-all", action="store_true")
    parser.add_argument("-pass", dest="show_pass", action="store_true")
    parser.add_argument("-skip", dest="show_skip", action="store_true")
    parser.add_argument("-notests", action="store_true")
    parser.add_argument("-smallscreen", action="store_true")
    parser.add_argument("-slow", type=int, default=0)
    parser.add_argument("-sort", choices=["name", "elapsed", "cover"], default="name")
    parser.add_argument("-nocolor", action="store_true")
    parser.add_argument("-format", default="basic")
    parser.add_argument("-file")
    parser.add_argument("-follow", action="store_true")
    parser.add_argument("-follow-output")
    parser.add_argument("-include-timestamp", action="store_true")
    parser.add_argument("-progress", action="store_true")
    parser.add_argument("-compare")
    parser.add_argument("-trimpath", default="")
    ns, _ = parser.parse_known_args(argv)
    if ns.format not in ("basic", "plain", "markdown"):
        print(f'invalid option:"{ns.format}". The -format flag must be one of: basic, plain or markdown')
        raise SystemExit(0)
    return ns


def package_for(packages, name):
    if name not in packages:
        packages[name] = Package(name)
    return packages[name]


def read_lines(opts):
    if opts.file:
        with open(opts.file, "r", encoding="utf-8") as handle:
            lines = handle.readlines()
    else:
        lines = sys.stdin.readlines()
    if opts.follow_output:
        with open(opts.follow_output, "w", encoding="utf-8") as handle:
            for line in lines:
                try:
                    event = json.loads(line)
                    out = event.get("Output", "")
                    if out:
                        if opts.include_timestamp and event.get("Time"):
                            handle.write(f"{event['Time']} {out}")
                        else:
                            handle.write(out)
                except json.JSONDecodeError:
                    handle.write(line)
    elif opts.follow:
        for line in lines:
            try:
                event = json.loads(line)
                out = event.get("Output", "")
                if out:
                    if opts.include_timestamp and event.get("Time"):
                        sys.stdout.write(f"{event['Time']} {out}")
                    else:
                        sys.stdout.write(out)
            except json.JSONDecodeError:
                sys.stdout.write(line)
    return lines


def parse_events(lines, trimpath=""):
    packages = {}
    coverage_re = re.compile(r"coverage: ([0-9.]+%) of statements")
    no_test_re = re.compile(r"\[(no test files|no tests to run)\]")
    for raw in lines:
        if not raw.strip():
            continue
        try:
            event = json.loads(raw)
        except json.JSONDecodeError:
            continue
        package_name = event.get("Package", "")
        if trimpath and package_name.startswith(trimpath):
            package_name = package_name[len(trimpath):]
        if not package_name:
            continue
        pkg = package_for(packages, package_name)
        action = event.get("Action", "")
        test = event.get("Test", "")
        output = event.get("Output", "")
        if output:
            cover = coverage_re.search(output)
            if cover:
                pkg.cover = cover.group(1)
            no_test = no_test_re.search(output)
            if no_test:
                pkg.no_test_reason = f"[{no_test.group(1)}]"
            if test:
                pkg.test_output.setdefault(test, []).append(output)
            else:
                pkg.output.append(output)
        if action in ("pass", "fail", "skip"):
            elapsed = float(event.get("Elapsed", 0) or 0)
            if test:
                status = action.upper()
                pkg.tests.append(TestEvent(package_name, test, status, elapsed))
            else:
                pkg.status = action.upper()
                pkg.elapsed = elapsed
    for pkg in packages.values():
        if not pkg.status:
            pkg.status = "PASS" if not any(t.status == "FAIL" for t in pkg.tests) else "FAIL"
        if pkg.no_test_reason and not pkg.tests:
            pkg.status = "NOTEST"
    return list(packages.values())


def sort_key(kind):
    if kind == "elapsed":
        return lambda item: (-getattr(item, "elapsed", 0.0), getattr(item, "name", getattr(item, "test", "")))
    if kind == "cover":
        def key(item):
            cover = getattr(item, "cover", "--")
            try:
                return (-float(cover.rstrip("%")), getattr(item, "name", ""))
            except ValueError:
                return (1, getattr(item, "name", ""))
        return key
    return lambda item: getattr(item, "name", getattr(item, "test", ""))


def counts(pkg):
    return (
        sum(1 for t in pkg.tests if t.status == "PASS"),
        sum(1 for t in pkg.tests if t.status == "FAIL"),
        sum(1 for t in pkg.tests if t.status == "SKIP"),
    )


def fmt_elapsed(value, suffix=False):
    return f"{value:.2f}{'s' if suffix else ''}"


def center_left_bias(text, width):
    text = str(text)
    total = max(0, width - len(text))
    left = total // 2
    right = total - left
    return " " * left + text + " " * right


def cell(text, width, align="center"):
    text = str(text)
    if align == "left":
        inner = text.ljust(width)
    elif align == "right":
        inner = text.rjust(width)
    else:
        inner = center_left_bias(text, width)
    return " " + inner + " "


def alignments(headers):
    return ["left" if h in ("Test", "Package") else "center" for h in headers]


def basic_table(headers, rows):
    widths = [len(h) for h in headers]
    for row in rows:
        for i, value in enumerate(row):
            for part in str(value).split("\n"):
                widths[i] = max(widths[i], len(part))
    top = "╭" + "┬".join("─" * (w + 2) for w in widths) + "╮"
    mid = "├" + "┼".join("─" * (w + 2) for w in widths) + "┤"
    bot = "╰" + "┴".join("─" * (w + 2) for w in widths) + "╯"
    aligns = alignments(headers)
    lines = [top, "│" + "│".join(cell(h, widths[i]) for i, h in enumerate(headers)) + "│", mid]
    for row in rows:
        parts = [str(v).split("\n") for v in row]
        height = max(len(p) for p in parts)
        for n in range(height):
            vals = [p[n] if n < len(p) else "" for p in parts]
            lines.append("│" + "│".join(cell(v, widths[i], aligns[i]) for i, v in enumerate(vals)) + "│")
    lines.append(bot)
    return "\n".join(lines) + "\n"


def plain_table(headers, rows):
    widths = [len(h) for h in headers]
    for row in rows:
        for i, value in enumerate(row):
            widths[i] = max(widths[i], len(str(value)))
    aligns = alignments(headers)

    def plain_cell(value, width, align="center"):
        if align == "left":
            inner = str(value).ljust(width)
        else:
            inner = center_left_bias(value, width)
        return "  " + inner + "  "

    lines = ["".join(plain_cell(h, widths[i]) for i, h in enumerate(headers)), " " * sum(w + 4 for w in widths)]
    for row in rows:
        lines.append("".join(plain_cell(v, widths[i], aligns[i]) for i, v in enumerate(row)))
    return "\n".join(lines) + "\n"


def markdown_table(headers, rows):
    widths = [len(h) for h in headers]
    for row in rows:
        for i, value in enumerate(row):
            widths[i] = max(widths[i], len(str(value)))
    lines = [
        "| " + " | ".join(center_left_bias(h, widths[i]) for i, h in enumerate(headers)) + " |",
        "|-" + "-|-".join("-" * widths[i] for i in range(len(headers))) + "-|",
    ]
    for row in rows:
        lines.append("| " + " | ".join(center_left_bias(v, widths[i]) for i, v in enumerate(row)) + " |")
    return "\n".join(lines) + "\n"


def table(fmt, headers, rows):
    if fmt == "plain":
        return plain_table(headers, rows)
    if fmt == "markdown":
        return markdown_table(headers, rows)
    return basic_table(headers, rows)


def test_rows(packages, opts):
    rows = []
    show_pass = opts.all or opts.show_pass
    show_skip = opts.all or opts.show_skip
    for pkg in sorted(packages, key=sort_key(opts.sort)):
        for test in pkg.tests:
            if test.status == "FAIL" or (test.status == "PASS" and show_pass) or (test.status == "SKIP" and show_skip):
                rows.append([test.status, fmt_elapsed(test.elapsed), test.test, pkg.name])
    if opts.sort == "elapsed":
        rows.sort(key=lambda row: (-float(row[1]), row[3], row[2]))
    else:
        rows.sort(key=lambda row: (row[3], row[2]))
    return rows


def package_rows(packages, opts):
    rows = []
    for pkg in sorted(packages, key=sort_key(opts.sort)):
        if pkg.status == "NOTEST" and not opts.notests:
            continue
        passed, failed, skipped = counts(pkg)
        if pkg.status == "NOTEST":
            rows.append(["NOTEST", fmt_elapsed(pkg.elapsed, True), f"{pkg.name}\n{pkg.no_test_reason}", "--", "--", "--", "--"])
        else:
            rows.append([pkg.status, fmt_elapsed(pkg.elapsed, True), pkg.name, pkg.cover, passed, failed, skipped])
    return rows


def fail_block(pkg):
    title = f"   FAIL  package: {pkg.name}   "
    line = "━" * len(title)
    chunks = [f"┏{line}┓\n┃{title}┃\n┗{line}┛\n\n\n"]
    for test in pkg.tests:
        if test.status == "FAIL":
            outs = pkg.test_output.get(test.test, [])
            body = "".join(o for o in outs if not o.startswith("=== RUN") and not o.startswith("--- FAIL") and not o.startswith("--- PASS"))
            if body:
                chunks.append(body)
    return "".join(chunks)


def render_markdown(packages, opts):
    out = []
    rows = test_rows(packages, opts)
    if rows:
        by_pkg = {}
        for row in rows:
            by_pkg.setdefault(row[3], []).append(row[:3])
        for pkg in sorted(packages, key=lambda p: p.name):
            if pkg.name in by_pkg:
                passed, failed, skipped = counts(pkg)
                out.append(f"## 📦 Package **`{pkg.name}`**\n\n")
                out.append(f"Tests: ✓ {passed} passed | {skipped} skipped | {failed} failed\n\n")
                out.append("<details>\n\n<summary>Click for test summary</summary>\n\n")
                out.append(markdown_table(["Status", "Elapsed", "Test"], by_pkg[pkg.name]))
                out.append("</details>\n\n\n")
    for pkg in packages:
        if pkg.status == "FAIL":
            out.append(f"## FAIL • {pkg.name}\n\n```\n\n")
            for test in pkg.tests:
                if test.status == "FAIL":
                    out.append("".join(o for o in pkg.test_output.get(test.test, []) if not o.startswith("=== RUN")))
            out.append("\n```\n\n")
    rows = package_rows(packages, opts)
    if rows:
        out.append(markdown_table(["Status", "Elapsed", "Package", "Cover", "Pass", "Fail", "Skip"], rows))
    return "".join(out)


def render(packages, opts):
    out = []
    if opts.progress:
        for pkg in sorted(packages, key=lambda p: p.name):
            if pkg.status != "NOTEST":
                out.append(f"[{pkg.status}]\t     {fmt_elapsed(pkg.elapsed, True)}\t{pkg.name}\n")
    if opts.format == "markdown":
        return "".join(out) + render_markdown(packages, opts)
    rows = test_rows(packages, opts)
    if rows:
        out.append(table(opts.format, ["Status", "Elapsed", "Test", "Package"], rows))
    for pkg in sorted(packages, key=lambda p: p.name):
        if pkg.status == "FAIL":
            out.append(fail_block(pkg))
    rows = package_rows(packages, opts)
    if rows:
        out.append(table(opts.format, ["Status", "Elapsed", "Package", "Cover", "Pass", "Fail", "Skip"], rows))
    return "".join(out)


def main(argv):
    opts = parse_args(argv)
    try:
        lines = read_lines(opts)
    except OSError as exc:
        print(exc, file=sys.stderr)
        return 1
    packages = parse_events(lines, opts.trimpath)
    sys.stdout.write(render(packages, opts))
    return 1 if any(pkg.status == "FAIL" for pkg in packages) else 0


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
