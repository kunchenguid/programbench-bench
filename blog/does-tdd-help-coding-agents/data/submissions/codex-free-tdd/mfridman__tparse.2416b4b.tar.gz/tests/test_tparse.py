import json
import subprocess
import sys
import unittest
from pathlib import Path
import tempfile


ROOT = Path(__file__).resolve().parents[1]
CMD = [sys.executable, str(ROOT / "src" / "tparse.py")]


def run_tparse(args, events=None):
    data = ""
    if events is not None:
        data = "\n".join(json.dumps(event) for event in events) + "\n"
    return subprocess.run(
        CMD + args,
        input=data,
        text=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
    )


class TparseBehavior(unittest.TestCase):
    def test_help_and_version_match_documented_cli(self):
        help_result = run_tparse(["--help"])
        self.assertEqual(help_result.returncode, 0)
        self.assertIn("Usage:\n    go test ./... -json | tparse [options...]", help_result.stdout)
        self.assertIn("-format            The output format for tables [basic, plain, markdown]. Default is basic.", help_result.stdout)

        version_result = run_tparse(["-v"])
        self.assertEqual(version_result.returncode, 0)
        self.assertEqual(version_result.stdout, "tparse version: (devel)\n")

    def test_failed_package_is_reported_with_failure_output_and_summary(self):
        events = [
            {"Action": "run", "Package": "example.com/pkg", "Test": "TestPass"},
            {"Action": "pass", "Package": "example.com/pkg", "Test": "TestPass", "Elapsed": 0.01},
            {"Action": "run", "Package": "example.com/pkg", "Test": "TestFail"},
            {"Action": "output", "Package": "example.com/pkg", "Test": "TestFail", "Output": "=== RUN   TestFail\n"},
            {"Action": "output", "Package": "example.com/pkg", "Test": "TestFail", "Output": "    file_test.go:10: got bad\n"},
            {"Action": "fail", "Package": "example.com/pkg", "Test": "TestFail", "Elapsed": 0.03},
            {"Action": "output", "Package": "example.com/pkg", "Output": "coverage: 77.7% of statements\n"},
            {"Action": "fail", "Package": "example.com/pkg", "Elapsed": 0.06},
        ]

        result = run_tparse(["-nocolor"], events)

        self.assertEqual(result.returncode, 1)
        self.assertIn("FAIL  package: example.com/pkg", result.stdout)
        self.assertIn("    file_test.go:10: got bad", result.stdout)
        self.assertIn("│  FAIL  │  0.06s  │ example.com/pkg │ 77.7% │  1   │  1   │  0   │", result.stdout)

    def test_all_file_and_notests_modes_report_observed_summaries(self):
        events = [
            {"Action": "run", "Package": "b/pkg", "Test": "TestB"},
            {"Action": "pass", "Package": "b/pkg", "Test": "TestB", "Elapsed": 1.2},
            {"Action": "output", "Package": "b/pkg", "Output": "coverage: 80.0% of statements\n"},
            {"Action": "pass", "Package": "b/pkg", "Elapsed": 1.23},
            {"Action": "run", "Package": "a/pkg", "Test": "TestA"},
            {"Action": "pass", "Package": "a/pkg", "Test": "TestA", "Elapsed": 0.5},
            {"Action": "pass", "Package": "a/pkg", "Elapsed": 0.55},
            {"Action": "output", "Package": "empty/pkg", "Output": "?   \tempty/pkg\t[no test files]\n"},
            {"Action": "skip", "Package": "empty/pkg", "Elapsed": 0},
        ]
        with tempfile.NamedTemporaryFile("w", delete=False) as handle:
            handle.write("\n".join(json.dumps(event) for event in events) + "\n")
            file_name = handle.name

        result = run_tparse(["-nocolor", "-all", "-file", file_name])

        self.assertEqual(result.returncode, 0)
        self.assertIn("│  PASS  │  0.50   │ TestA │ a/pkg   │", result.stdout)
        self.assertIn("│  PASS  │  1.23s  │ b/pkg   │ 80.0% │  1   │  0   │  0   │", result.stdout)
        self.assertNotIn("empty/pkg", result.stdout)

        notests = run_tparse(["-nocolor", "-notests", "-file", file_name])
        self.assertIn("│ NOTEST │  0.00s  │ empty/pkg", notests.stdout)
        self.assertIn("│        │         │ [no test files]", notests.stdout)

    def test_plain_markdown_and_follow_output_modes(self):
        events = [
            {"Time": "2024-01-01T00:00:00Z", "Action": "run", "Package": "pkg", "Test": "TestPass"},
            {"Time": "2024-01-01T00:00:01Z", "Action": "output", "Package": "pkg", "Test": "TestPass", "Output": "=== RUN   TestPass\n"},
            {"Time": "2024-01-01T00:00:02Z", "Action": "pass", "Package": "pkg", "Test": "TestPass", "Elapsed": 0.25},
            {"Time": "2024-01-01T00:00:03Z", "Action": "pass", "Package": "pkg", "Elapsed": 0.3},
        ]

        plain = run_tparse(["-nocolor", "-format", "plain", "-all"], events)
        self.assertEqual(plain.returncode, 0)
        self.assertIn("PASS", plain.stdout)
        self.assertIn("0.25", plain.stdout)
        self.assertIn("TestPass", plain.stdout)
        self.assertNotIn("│", plain.stdout)

        markdown = run_tparse(["-nocolor", "-format", "markdown", "-all"], events)
        self.assertEqual(markdown.returncode, 0)
        self.assertIn("## 📦 Package **`pkg`**", markdown.stdout)
        self.assertIn("|  PASS  |  0.25   | TestPass |", markdown.stdout)

        with tempfile.NamedTemporaryFile("r", delete=False) as out_file:
            out_name = out_file.name
        followed = run_tparse(["-follow-output", out_name, "-include-timestamp"], events)
        self.assertEqual(followed.returncode, 0)
        self.assertEqual(Path(out_name).read_text(), "2024-01-01T00:00:01Z === RUN   TestPass\n")


if __name__ == "__main__":
    unittest.main()
