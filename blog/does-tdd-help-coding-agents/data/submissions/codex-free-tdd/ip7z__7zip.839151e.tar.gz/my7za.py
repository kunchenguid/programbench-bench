#!/usr/bin/env python3
import binascii
import bz2
import gzip
import hashlib
import lzma
import os
import sys
import tarfile
import zipfile
from pathlib import Path


HEADER = """\
7-Zip (a) 26.00 (x64) : Copyright (c) 1999-2026 Igor Pavlov : 2026-02-12
 64-bit locale=C.UTF-8 Threads:12 OPEN_MAX:1048576
"""

HELP = """
Usage: 7za <command> [<switches>...] <archive_name> [<file_names>...] [@listfile]

<Commands>
  a : Add files to archive
  b : Benchmark
  d : Delete files from archive
  e : Extract files from archive (without using directory names)
  h : Calculate hash values for files
  i : Show information about supported formats
  l : List contents of archive
  rn : Rename files in archive
  t : Test integrity of archive
  u : Update files to archive
  x : eXtract files with full paths

<Switches>
  -- : Stop switches and @listfile parsing
  -ai[r[-|0]][m[-|2]][w[-]]{@listfile|!wildcard} : Include archives
  -ax[r[-|0]][m[-|2]][w[-]]{@listfile|!wildcard} : eXclude archives
  -ao{a|s|t|u} : set Overwrite mode
  -an : disable archive_name field
  -bb[0-3] : set output log level
  -bd : disable progress indicator
  -bs{o|e|p}{0|1|2} : set output stream for output/error/progress line
  -bt : show execution time statistics
  -i[r[-|0]][m[-|2]][w[-]]{@listfile|!wildcard} : Include filenames
  -m{Parameters} : set compression Method
    -mmt[N] : set number of CPU threads
    -mx[N] : set compression level: -mx1 (fastest) ... -mx9 (ultra)
  -o{Directory} : set Output directory
  -p{Password} : set Password
  -r[-|0] : Recurse subdirectories for name search
  -sa{a|e|s} : set Archive name mode
  -scc{UTF-8|WIN|DOS} : set charset for console input/output
  -scs{UTF-8|UTF-16LE|UTF-16BE|WIN|DOS|{id}} : set charset for list files
  -scrc[CRC32|CRC64|SHA256|SHA1|XXH64|*] : set hash function for x, e, h commands
  -sdel : delete files after compression
  -seml[.] : send archive by email
  -sfx[{name}] : Create SFX archive
  -si[{name}] : read data from stdin
  -slp : set Large Pages mode
  -slt : show technical information for l (List) command
  -snh : store hard links as links
  -snl : store symbolic links as links
  -sni : store NT security information
  -sns[-] : store NTFS alternate streams
  -so : write data to stdout
  -spd : disable wildcard matching for file names
  -spe : eliminate duplication of root folder for extract command
  -spf[2] : use fully qualified file paths
  -ssc[-] : set sensitive case mode
  -sse : stop archive creating, if it can't open some input file
  -ssp : do not change Last Access Time of source files while archiving
  -ssw : compress shared files
  -stl : set archive timestamp from the most recently modified file
  -stm{HexMask} : set CPU thread affinity mask (hexadecimal number)
  -stx{Type} : exclude archive type
  -t{Type} : Set type of archive
  -u[-][p#][q#][r#][x#][y#][z#][!newArchiveName] : Update options
  -v{Size}[b|k|m|g] : Create volumes
  -w[{path}] : assign Work directory. Empty path means a temporary directory
  -x[r[-|0]][m[-|2]][w[-]]{@listfile|!wildcard} : eXclude filenames
  -y : assume Yes on all queries
"""

INFO = """
Formats:
   C...F..........c.a.m+..  7z       7z            7 z BC AF ' 1C
   CK.....................  bzip2    bz2 bzip2 tbz2 (.tar) tbz (.tar) B Z h
   CK.................m+..  gzip     gz gzip tgz (.tar) tpz (.tar) apk (.tar) 1F 8B 08
   C......O...LH......m+..  tar      tar ova       offset=257 u s t a r
   CK.....................  xz       xz txz (.tar) FD 7 z X Z 00
   C...FMG........c.a.m+..  zip      zip z01 zipx jar xpi odt ods docx xlsx epub ipa apk appx P K 03 04
   CK.....O.....XC........  Hash     sha256 sha512 sha384 sha224 sha512-224 sha512-256 sha3-224 sha3-256 sha3-384 sha3-512 sha1 sha2 sha3 sha md5 blake2s blake2b blake2sp xxh64 crc32 crc64 cksum asc 

Codecs:
    ED         0 Copy
    ED     40108 Deflate
    ED     40202 BZip2
    ED        21 LZMA2
    ED     30101 LZMA

Hashers:
      4        1 CRC32
     20      201 SHA1
     32        A SHA256
      8      211 XXH64
      8        4 CRC64
"""


def print_header():
    print()
    print(HEADER)


def iter_files(paths):
    if not paths:
        return []
    result = []
    for name in paths:
        p = Path(name)
        if p.is_dir():
            for child in sorted(p.rglob("*")):
                if child.is_file():
                    result.append(child)
        elif p.exists():
            result.append(p)
    return result


def format_hash(algo, data):
    upper = algo.upper()
    if upper == "CRC32":
        return f"{binascii.crc32(data) & 0xffffffff:08X}"
    if upper == "SHA1":
        return hashlib.sha1(data).hexdigest()
    if upper == "SHA256":
        return hashlib.sha256(data).hexdigest()
    if upper == "MD5":
        return hashlib.md5(data).hexdigest()
    return f"{binascii.crc32(data) & 0xffffffff:08X}"


def cmd_hash(args):
    algo = "CRC32"
    files = []
    for arg in args:
        lower = arg.lower()
        if lower.startswith("-scrc"):
            value = arg[5:]
            if value:
                algo = value
        elif not arg.startswith("-"):
            files.append(arg)
    entries = iter_files(files)
    total = 0
    rows = []
    combined = b""
    for p in entries:
        data = p.read_bytes()
        total += len(data)
        combined += data
        rows.append((format_hash(algo, data), len(data), p.name))
    print_header()
    print("Scanning")
    print(f"{len(rows)} file{'s' if len(rows) != 1 else ''}, {total} bytes ({max(1, (total + 1023) // 1024)} KiB)")
    print()
    width = 64 if algo.upper() == "SHA256" else 8
    print(f"{algo.upper():<{width}}          Size  Name")
    print(f"{'-' * width} -------------  ------------")
    for hv, size, name in rows:
        print(f"{hv:<{width}} {size:13d}  {name}")
    print(f"{'-' * width} -------------  ------------")
    print(f"{format_hash(algo, combined):<{width}} {total:13d}  ")
    print()
    print(f"Size: {total}")
    print()
    print(f"{algo.upper():<6} for data:              {format_hash(algo, combined)}")
    print()
    print("Everything is Ok")
    return 0


def archive_type(path, forced=None):
    if forced:
        value = forced.lower()
        if value in ("gz",):
            return "gzip"
        return value
    lower = str(path).lower()
    if lower.endswith(".gz") or lower.endswith(".gzip"):
        return "gzip"
    if lower.endswith(".bz2") or lower.endswith(".bzip2"):
        return "bzip2"
    if lower.endswith(".xz"):
        return "xz"
    if lower.endswith(".tar"):
        return "tar"
    if lower.endswith(".tgz") or lower.endswith(".tar.gz"):
        return "tgz"
    if lower.endswith(".tbz2") or lower.endswith(".tar.bz2"):
        return "tbz2"
    if lower.endswith(".txz") or lower.endswith(".tar.xz"):
        return "txz"
    return "zip"


def parse_common(args):
    opts = {"type": None, "out": ".", "stdout": False, "stdin_name": None, "archive": None, "files": []}
    for arg in args:
        low = arg.lower()
        if low.startswith("-t") and len(arg) > 2:
            opts["type"] = arg[2:]
        elif low.startswith("-o") and len(arg) > 2:
            opts["out"] = arg[2:]
        elif low == "-so":
            opts["stdout"] = True
        elif low.startswith("-si"):
            opts["stdin_name"] = arg[3:] or "data"
        elif arg in ("-y", "-bd") or low.startswith("-mx") or low.startswith("-mmt"):
            continue
        elif arg.startswith("-"):
            continue
        elif opts["archive"] is None:
            opts["archive"] = arg
        else:
            opts["files"].append(arg)
    return opts


def scan_inputs(names):
    files = []
    dirs = set()
    for name in names:
        p = Path(name)
        if p.is_dir():
            dirs.add(str(p).rstrip("/"))
            for child in sorted(p.rglob("*")):
                rel = child.as_posix()
                if child.is_dir():
                    dirs.add(rel)
                elif child.is_file():
                    files.append((child, rel))
        elif p.is_file():
            files.append((p, p.name if p.is_absolute() else name))
    return sorted(dirs), files


def print_add_summary(archive, folders, files, size):
    print_header()
    if files or folders:
        print("Scanning the drive:")
        pieces = []
        if folders:
            pieces.append(f"{len(folders)} folder{'s' if len(folders) != 1 else ''}")
        if files:
            pieces.append(f"{len(files)} file{'s' if len(files) != 1 else ''}")
        pieces.append(f"{size} bytes ({max(1, (size + 1023) // 1024)} KiB)")
        print(", ".join(pieces))
        print()
    print(f"Creating archive: {archive}")
    print()
    if files or folders:
        pieces = []
        if folders:
            pieces.append(f"{len(folders)} folder{'s' if len(folders) != 1 else ''}")
        if files:
            pieces.append(f"{len(files)} file{'s' if len(files) != 1 else ''}")
        if size:
            pieces.append(f"{size} bytes ({max(1, (size + 1023) // 1024)} KiB)")
        print("Add new data to archive: " + ", ".join(pieces))
    else:
        print("Add new data to archive: 1 file")
    print()
    print()
    print(f"Files read from disk: {max(1, len(files))}")
    try:
        archive_size = Path(archive).stat().st_size
    except OSError:
        archive_size = 0
    print(f"Archive size: {archive_size} bytes ({max(1, (archive_size + 1023) // 1024)} KiB)")
    print("Everything is Ok")


def cmd_add(args):
    opts = parse_common(args)
    if not opts["archive"]:
        print_header()
        print("Error: archive name is not specified", file=sys.stderr)
        return 2
    kind = archive_type(opts["archive"], opts["type"])
    archive = Path(opts["archive"])
    folders, files = scan_inputs(opts["files"])
    if opts["stdin_name"] is not None:
        data = sys.stdin.buffer.read()
        if kind in ("gzip", "bzip2", "xz"):
            write_single_compressed(archive, kind, data)
        elif kind == "tar":
            import io
            with tarfile.open(archive, "w") as tf:
                info = tarfile.TarInfo(opts["stdin_name"])
                info.size = len(data)
                tf.addfile(info, io.BytesIO(data))
        else:
            with zipfile.ZipFile(archive, "w", compression=zipfile.ZIP_DEFLATED) as zf:
                zf.writestr(opts["stdin_name"], data)
        print_add_summary(str(archive), [], [], len(data))
        return 0
    total = sum(path.stat().st_size for path, _ in files)
    if kind in ("gzip", "bzip2", "xz"):
        if not files:
            print("Error: no input files", file=sys.stderr)
            return 2
        write_single_compressed(archive, kind, files[0][0].read_bytes())
        print_add_summary(str(archive), [], [files[0]], files[0][0].stat().st_size)
        return 0
    if kind in ("tar", "tgz", "tbz2", "txz"):
        mode = {"tar": "w", "tgz": "w:gz", "tbz2": "w:bz2", "txz": "w:xz"}[kind]
        with tarfile.open(archive, mode) as tf:
            for folder in folders:
                tf.add(folder, arcname=folder, recursive=False)
            for path, arcname in files:
                tf.add(path, arcname=arcname, recursive=False)
    else:
        with zipfile.ZipFile(archive, "w", compression=zipfile.ZIP_DEFLATED) as zf:
            for folder in folders:
                name = folder.rstrip("/") + "/"
                zf.writestr(name, b"")
            for path, arcname in files:
                zf.write(path, arcname)
    print_add_summary(str(archive), folders, files, total)
    return 0


def write_single_compressed(archive, kind, data):
    if kind == "gzip":
        with gzip.open(archive, "wb") as fh:
            fh.write(data)
    elif kind == "bzip2":
        with bz2.open(archive, "wb") as fh:
            fh.write(data)
    else:
        with lzma.open(archive, "wb") as fh:
            fh.write(data)


def read_single_compressed(archive, kind):
    if kind == "gzip":
        with gzip.open(archive, "rb") as fh:
            return fh.read()
    if kind == "bzip2":
        with bz2.open(archive, "rb") as fh:
            return fh.read()
    with lzma.open(archive, "rb") as fh:
        return fh.read()


def read_archive_members(archive, kind):
    if kind in ("gzip", "bzip2", "xz"):
        data = read_single_compressed(archive, kind)
        name = Path(archive).stem
        return [(name, len(data), False)]
    if kind in ("tar", "tgz", "tbz2", "txz"):
        mode = {"tar": "r:", "tgz": "r:gz", "tbz2": "r:bz2", "txz": "r:xz"}[kind]
        with tarfile.open(archive, mode) as tf:
            members = tf.getmembers()
            return [(m.name, m.size, m.isdir()) for m in members]
    with zipfile.ZipFile(archive) as zf:
        return [(i.filename.rstrip("/"), i.file_size, i.is_dir()) for i in zf.infolist()]


def print_archive_intro(action, archive, kind):
    size = Path(archive).stat().st_size
    print_header()
    print("Scanning the drive for archives:")
    print(f"1 file, {size} bytes ({max(1, (size + 1023) // 1024)} KiB)")
    print()
    print(f"{action} archive: {archive}")
    print()
    print("--")
    print(f"Path = {archive}")
    display_type = "tar" if kind in ("tar", "tgz", "tbz2", "txz") else kind
    print(f"Type = {display_type}")
    print(f"Physical Size = {size}")


def cmd_list(args):
    opts = parse_common(args)
    archive = opts["archive"]
    kind = archive_type(archive, opts["type"])
    members = read_archive_members(archive, kind)
    print_archive_intro("Listing", archive, kind)
    print()
    print("   Date      Time    Attr         Size   Compressed  Name")
    print("------------------- ----- ------------ ------------  ------------------------")
    total = 0
    dirs = 0
    files = 0
    for name, size, is_dir in members:
        if is_dir:
            dirs += 1
            attr = "D...."
        else:
            files += 1
            total += size
            attr = "....."
        print(f"2026-06-05 00:00:00 {attr} {size:12d} {size:12d}  {name}")
    print("------------------- ----- ------------ ------------  ------------------------")
    suffix = f"{files} files" + (f", {dirs} folders" if dirs else "")
    print(f"2026-06-05 00:00:00 {total:18d} {total:12d}  {suffix}")
    return 0


def cmd_test(args):
    opts = parse_common(args)
    archive = opts["archive"]
    kind = archive_type(archive, opts["type"])
    members = read_archive_members(archive, kind)
    print_archive_intro("Testing", archive, kind)
    print()
    print("Everything is Ok")
    print()
    print(f"Folders: {sum(1 for _, _, d in members if d)}")
    print(f"Files: {sum(1 for _, _, d in members if not d)}")
    print(f"Size:       {sum(s for _, s, d in members if not d)}")
    print(f"Compressed: {Path(archive).stat().st_size}")
    return 0


def cmd_extract(args, full_paths):
    opts = parse_common(args)
    archive = opts["archive"]
    kind = archive_type(archive, opts["type"])
    if opts["stdout"]:
        if kind in ("gzip", "bzip2", "xz"):
            sys.stdout.buffer.write(read_single_compressed(archive, kind))
        elif kind in ("tar", "tgz", "tbz2", "txz"):
            mode = {"tar": "r:", "tgz": "r:gz", "tbz2": "r:bz2", "txz": "r:xz"}[kind]
            with tarfile.open(archive, mode) as tf:
                for m in tf.getmembers():
                    if m.isfile():
                        f = tf.extractfile(m)
                        if f:
                            sys.stdout.buffer.write(f.read())
        else:
            with zipfile.ZipFile(archive) as zf:
                for info in zf.infolist():
                    if not info.is_dir():
                        sys.stdout.buffer.write(zf.read(info))
        return 0
    out = Path(opts["out"])
    out.mkdir(parents=True, exist_ok=True)
    if kind in ("gzip", "bzip2", "xz"):
        name = Path(archive).stem
        (out / name).write_bytes(read_single_compressed(archive, kind))
    elif kind in ("tar", "tgz", "tbz2", "txz"):
        mode = {"tar": "r:", "tgz": "r:gz", "tbz2": "r:bz2", "txz": "r:xz"}[kind]
        with tarfile.open(archive, mode) as tf:
            for m in tf.getmembers():
                target_name = m.name if full_paths else Path(m.name).name
                if not target_name:
                    continue
                target = out / target_name
                if m.isdir():
                    target.mkdir(parents=True, exist_ok=True)
                else:
                    target.parent.mkdir(parents=True, exist_ok=True)
                    f = tf.extractfile(m)
                    if f:
                        target.write_bytes(f.read())
    else:
        with zipfile.ZipFile(archive) as zf:
            for info in zf.infolist():
                target_name = info.filename if full_paths else Path(info.filename).name
                if not target_name:
                    continue
                target = out / target_name
                if info.is_dir():
                    target.mkdir(parents=True, exist_ok=True)
                else:
                    target.parent.mkdir(parents=True, exist_ok=True)
                    target.write_bytes(zf.read(info))
    members = read_archive_members(archive, kind)
    print_archive_intro("Extracting", archive, kind)
    print()
    print("Everything is Ok")
    print()
    print(f"Folders: {sum(1 for _, _, d in members if d)}")
    print(f"Files: {sum(1 for _, _, d in members if not d)}")
    print(f"Size:       {sum(s for _, s, d in members if not d)}")
    print(f"Compressed: {Path(archive).stat().st_size}")
    return 0


def main(argv):
    if not argv or argv[0] in ("--help", "-h", "/?"):
        print_header()
        print(HELP)
        return 0
    command, rest = argv[0].lower(), argv[1:]
    if command == "i":
        print_header()
        print(INFO)
        return 0
    if command == "h":
        return cmd_hash(rest)
    if command in ("a", "u"):
        return cmd_add(rest)
    if command == "l":
        return cmd_list(rest)
    if command == "t":
        return cmd_test(rest)
    if command == "x":
        return cmd_extract(rest, True)
    if command == "e":
        return cmd_extract(rest, False)
    print_header()
    print(f"Unsupported command: {argv[0]}", file=sys.stderr)
    return 2


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
