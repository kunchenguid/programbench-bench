import subprocess
import textwrap
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
EXE = ROOT / "executable"


def run_cmd(args, cwd=None):
    return subprocess.run([str(EXE), *args], cwd=cwd or ROOT, text=True, capture_output=True)


class CliTests(unittest.TestCase):
    def test_version_matches_reference(self):
        p = run_cmd(["--version"])
        self.assertEqual(p.returncode, 0)
        self.assertEqual(p.stdout.strip(), "Cppcheck 2.19 dev")
        self.assertEqual(p.stderr, "")

    def test_unknown_option_reports_cppcheck_error_on_stdout(self):
        p = run_cmd(["--bad"])
        self.assertEqual(p.returncode, 1)
        self.assertEqual(p.stdout, 'cppcheck: error: unrecognized command line option: "--bad".\n')
        self.assertEqual(p.stderr, "")

    def test_readme_array_bounds_example_is_reported(self):
        tmp = ROOT / "tmp_test_array"
        tmp.mkdir(exist_ok=True)
        src = tmp / "file1.c"
        src.write_text(textwrap.dedent("""
            int main()
            {
                char a[10];
                a[10] = 0;
                return 0;
            }
        """).lstrip())
        p = run_cmd([str(src)])
        combined = p.stdout + p.stderr
        self.assertEqual(p.returncode, 0)
        self.assertIn(f"Checking {src}...", combined)
        self.assertIn(f"[{src}:4]: (error) Array 'a[10]'", combined)
        self.assertIn("out of bounds", combined)

    def test_single_line_array_bounds_is_reported(self):
        tmp = ROOT / "tmp_test_single_line_array"
        tmp.mkdir(exist_ok=True)
        src = tmp / "bad.c"
        src.write_text("int main(){ char a[2]; a[2]=0; return 0; }\\n")
        p = run_cmd([str(src)])
        self.assertIn("Array 'a[2]' accessed at index 2", p.stdout + p.stderr)

    def test_error_exitcode_is_used_when_errors_found(self):
        tmp = ROOT / "tmp_test_div"
        tmp.mkdir(exist_ok=True)
        src = tmp / "bad.c"
        src.write_text("int main(){ int x = 1 / 0; return x; }\n")
        p = run_cmd(["--error-exitcode=7", str(src)])
        self.assertEqual(p.returncode, 7)
        self.assertIn("Division by zero", p.stdout + p.stderr)

    def test_file_list_checks_paths_from_file(self):
        tmp = ROOT / "tmp_test_file_list"
        tmp.mkdir(exist_ok=True)
        src = tmp / "listed.c"
        src.write_text("int main(){ int x = 1 / 0; return x; }\n")
        listing = tmp / "files.txt"
        listing.write_text(str(src) + "\n")
        p = run_cmd(["--file-list=" + str(listing)])
        self.assertEqual(p.returncode, 0)
        self.assertIn(f"Checking {src}...", p.stdout + p.stderr)
        self.assertIn("Division by zero", p.stdout + p.stderr)

    def test_output_file_receives_diagnostics(self):
        tmp = ROOT / "tmp_test_output_file"
        tmp.mkdir(exist_ok=True)
        src = tmp / "bad.c"
        out = tmp / "report.txt"
        src.write_text("int main(){ int x = 1 / 0; return x; }\n")
        p = run_cmd(["--output-file=" + str(out), str(src)])
        self.assertEqual(p.returncode, 0)
        self.assertIn(f"Checking {src}...", p.stdout)
        self.assertEqual(p.stderr, "")
        self.assertIn("Division by zero", out.read_text())


if __name__ == "__main__":
    unittest.main()
