#!/usr/bin/env python3
import os
import re
import sys
from pathlib import Path

VERSION = "Cppcheck 2.19 dev"
SOURCE_EXTS = {".cpp", ".cxx", ".cc", ".c++", ".c", ".ipp", ".ixx", ".tpp", ".txx", ".h", ".hpp"}

HELP = """Cppcheck - A tool for static C/C++ code analysis

Syntax:
    cppcheck [OPTIONS] [files or paths]

If a directory is given instead of a filename, *.cpp, *.cxx, *.cc, *.c++, *.c, *.ipp,
*.ixx, *.tpp, and *.txx files are checked recursively from the given directory.

Options:
    -h, --help           Print this help.
    --version            Print out version number.
    --enable=<severity>  Enable additional checks: warning, performance, portability,
                         information, style, unusedFunction, missingInclude, all.
    --disable=<severity> Disable checks with the given severity.
    --error-exitcode=<n> If errors are found, integer [n] is returned instead of 0.
    --errorlist          Print a list of all the error messages in XML format.
    --xml                Write results in xml format to error stream (stderr).
    --output-format=<format>
                         Specify the output format: text, sarif, xml, xmlv2, xmlv3.
    --template='<text>'  Format the error messages.
    --quiet              Do not show progress reports.
    -q                   Do not show progress reports.
    -I <dir>             Give path to search for include files.
    -D<ID>               Define preprocessor symbol.
    -U<ID>               Undefine preprocessor symbol.

Example usage:
  cppcheck file.c
  cppcheck --enable=all --inconclusive test.cpp
"""

KNOWN_ENABLE = {"warning", "performance", "portability", "information", "style", "unusedFunction", "missingInclude", "all"}

class Finding:
    def __init__(self, path, line, severity, message, fid):
        self.path = path
        self.line = line
        self.severity = severity
        self.message = message
        self.id = fid

    def text(self, template=None):
        if template:
            s = template
            fields = {
                "file": self.path,
                "line": str(self.line),
                "column": "0",
                "severity": self.severity,
                "message": self.message,
                "id": self.id,
            }
            for k, v in fields.items():
                s = s.replace("{" + k + "}", v)
            return s.replace("\\n", "\n").replace("\\t", "\t")
        return f"[{self.path}:{self.line}]: ({self.severity}) {self.message}"


def strip_comments_and_strings(line):
    out = []
    i = 0
    in_str = False
    quote = ''
    while i < len(line):
        c = line[i]
        if not in_str and c == '/' and i + 1 < len(line) and line[i+1] == '/':
            break
        if not in_str and c in ('\"', "'"):
            in_str = True
            quote = c
            out.append(' ')
        elif in_str:
            if c == '\\':
                out.append(' ')
                i += 1
                if i < len(line):
                    out.append(' ')
            elif c == quote:
                in_str = False
                out.append(' ')
            else:
                out.append(' ')
        else:
            out.append(c)
        i += 1
    return ''.join(out)


def enabled(severity, fid, opts):
    if severity == "error" or severity == "warning":
        return True
    ens = opts["enable"]
    if "all" in ens or severity in ens or fid in ens:
        return True
    return False


def analyze_file(path, opts):
    findings = []
    try:
        raw_lines = Path(path).read_text(errors="ignore").splitlines()
    except OSError:
        return [Finding(path, 0, "error", f"Failed to open {path}. No such file or directory", "missingFile")]

    arrays = {}
    null_ptrs = set()
    malloc_vars = {}
    freed = set()
    var_decl = {}
    var_reads = {}
    functions = []

    for lineno, raw in enumerate(raw_lines, 1):
        code = strip_comments_and_strings(raw)
        for m in re.finditer(r"\b(?:char|int|long|short|float|double|bool|unsigned\s+char|size_t)\s+([A-Za-z_]\w*)\s*\[\s*(-?\d+)\s*\]", code):
            name, size = m.group(1), int(m.group(2))
            arrays[name] = (size, lineno)
            if size < 0:
                findings.append(Finding(path, lineno, "error", f"Declaration of array '{name}' with negative size is undefined behaviour", "negativeArraySize"))
        for m in re.finditer(r"\b([A-Za-z_]\w*)\s*\[\s*(-?\d+)\s*\]", code):
            name, idx = m.group(1), int(m.group(2))
            prefix = code[max(0, m.start() - 40):m.start()]
            is_decl = re.search(r"(?:char|int|long|short|float|double|bool|unsigned\s+char|size_t)\s+$", prefix) is not None
            if name in arrays and not is_decl:
                size, _decl_line = arrays[name]
                if idx < 0:
                    findings.append(Finding(path, lineno, "error", "Negative array index", "negativeIndex"))
                elif idx >= size:
                    findings.append(Finding(path, lineno, "error", f"Array '{name}[{size}]' accessed at index {idx}, which is out of bounds.", "arrayIndexOutOfBounds"))

        if re.search(r"/(\s*0)(?![0-9])", code):
            findings.append(Finding(path, lineno, "error", "Division by zero.", "zerodiv"))
        if re.search(r"%\s*0(?![0-9])", code):
            findings.append(Finding(path, lineno, "error", "Modulo division by zero.", "zerodiv"))

        for m in re.finditer(r"\b(?:int|char|long|short|float|double|void|bool)\s*\*\s*([A-Za-z_]\w*)\s*=\s*(?:0|NULL|nullptr)\b", code):
            null_ptrs.add(m.group(1))
        for name in list(null_ptrs):
            if re.search(r"\*\s*" + re.escape(name) + r"\s*=", code) or re.search(re.escape(name) + r"\s*->", code):
                findings.append(Finding(path, lineno, "error", "Null pointer dereference", "nullPointer"))

        for m in re.finditer(r"\b(?:int|char|long|short|float|double|void)\s*\*\s*([A-Za-z_]\w*)\s*=\s*(?:malloc|calloc|realloc)\s*\(", code):
            malloc_vars[m.group(1)] = lineno
        for m in re.finditer(r"\bfree\s*\(\s*([A-Za-z_]\w*)\s*\)", code):
            freed.add(m.group(1))

        for m in re.finditer(r"\b(?:int|char|long|short|float|double|bool|size_t)\s+([A-Za-z_]\w*)\s*(?:;|=)", code):
            var_decl.setdefault(m.group(1), lineno)
        tokens = re.findall(r"\b[A-Za-z_]\w*\b", code)
        for tok in tokens:
            var_reads[tok] = var_reads.get(tok, 0) + 1

        fm = re.match(r"\s*(?:static\s+)?(?:int|void|char|long|short|float|double|bool)\s+([A-Za-z_]\w*)\s*\([^;]*\)\s*\{?", code)
        if fm and fm.group(1) not in {"if", "for", "while", "switch"}:
            functions.append((fm.group(1), lineno))

    for name, line in malloc_vars.items():
        if name not in freed and enabled("style", "memleak", opts):
            findings.append(Finding(path, line, "style", f"Memory leak: {name}", "memleak"))
    for name, line in var_decl.items():
        if enabled("style", "unusedVariable", opts) and var_reads.get(name, 0) <= 1:
            findings.append(Finding(path, line, "style", f"Unused variable: {name}", "unusedVariable"))
    if "all" in opts["enable"] or "unusedFunction" in opts["enable"]:
        text = "\n".join(raw_lines)
        for name, line in functions:
            if name != "main" and len(re.findall(r"\b" + re.escape(name) + r"\s*\(", text)) <= 1:
                findings.append(Finding(path, line, "style", f"The function '{name}' is never used.", "unusedFunction"))

    if opts["inline_suppr"]:
        filtered = []
        for f in findings:
            prev = raw_lines[f.line-2] if f.line >= 2 else ""
            cur = raw_lines[f.line-1] if f.line >= 1 else ""
            if "cppcheck-suppress" in prev or "cppcheck-suppress" in cur:
                continue
            filtered.append(f)
        findings = filtered
    return findings


def collect_files(paths):
    files = []
    for p in paths:
        pp = Path(p)
        if pp.is_dir():
            for child in sorted(pp.rglob("*")):
                if child.is_file() and child.suffix in SOURCE_EXTS:
                    files.append(str(child))
        else:
            files.append(p)
    return files


def errorlist():
    ids = [
        ("arrayIndexOutOfBounds", "error", "Array 'arr[16]' accessed at index 16, which is out of bounds."),
        ("negativeIndex", "error", "Negative array index"),
        ("zerodiv", "error", "Division by zero."),
        ("nullPointer", "error", "Null pointer dereference"),
        ("memleak", "style", "Memory leak: varname"),
        ("unusedVariable", "style", "Unused variable: varname"),
        ("unusedFunction", "style", "The function 'funcName' is never used."),
        ("missingFile", "error", "message"),
    ]
    print('<?xml version="1.0" encoding="UTF-8"?>')
    print('<results version="2">')
    print('    <cppcheck version="2.19 dev"/>')
    print('    <errors>')
    for fid, sev, msg in ids:
        esc = msg.replace("'", "&apos;").replace('"', '&quot;')
        print(f'        <error id="{fid}" severity="{sev}" msg="{esc}" verbose="{esc}"/>')
    print('    </errors>')
    print('</results>')


def parse(argv):
    opts = {"enable": set(), "quiet": False, "error_exitcode": 0, "xml": False, "output_format": "text", "template": None, "inline_suppr": False, "output_file": None}
    files = []
    i = 0
    while i < len(argv):
        a = argv[i]
        if a in ("-h", "--help"):
            print(HELP)
            raise SystemExit(0)
        if a == "--version":
            print(VERSION)
            raise SystemExit(0)
        if a == "--errorlist":
            errorlist()
            raise SystemExit(0)
        if a in ("-q", "--quiet"):
            opts["quiet"] = True
        elif a == "--xml":
            opts["xml"] = True
            opts["output_format"] = "xml"
        elif a.startswith("--output-format="):
            fmt = a.split("=", 1)[1]
            if fmt not in {"text", "sarif", "xml", "xmlv2", "xmlv3"}:
                print(f"cppcheck: error: unknown output format: '{fmt}'")
                raise SystemExit(1)
            opts["output_format"] = fmt
            opts["xml"] = fmt.startswith("xml")
        elif a.startswith("--template="):
            opts["template"] = a.split("=", 1)[1].strip("'")
        elif a.startswith("--output-file="):
            opts["output_file"] = a.split("=", 1)[1]
        elif a == "--output-file":
            i += 1
            if i < len(argv):
                opts["output_file"] = argv[i]
        elif a.startswith("--file-list="):
            list_path = a.split("=", 1)[1]
            try:
                with open(list_path, errors="ignore") as fh:
                    files.extend([line.strip() for line in fh if line.strip()])
            except OSError:
                files.append(list_path)
        elif a == "--file-list":
            i += 1
            if i < len(argv):
                try:
                    with open(argv[i], errors="ignore") as fh:
                        files.extend([line.strip() for line in fh if line.strip()])
                except OSError:
                    files.append(argv[i])
        elif a.startswith("--error-exitcode="):
            val = a.split("=", 1)[1]
            try:
                opts["error_exitcode"] = int(val)
            except ValueError:
                print("cppcheck: error: argument to '--error-exitcode=' is not valid - not an integer.")
                raise SystemExit(1)
        elif a.startswith("--enable="):
            vals = [v for v in a.split("=", 1)[1].split(",") if v]
            for v in vals:
                if v not in KNOWN_ENABLE:
                    print(f"cppcheck: error: --enable parameter with the unknown name '{v}'")
                    raise SystemExit(1)
                opts["enable"].add(v)
        elif a.startswith("--disable="):
            pass
        elif a == "--inline-suppr":
            opts["inline_suppr"] = True
        elif a in ("-I", "-D", "-U", "-j", "-l", "-x"):
            i += 1
        elif a.startswith(('-I', '-D', '-U')) and len(a) > 2:
            pass
        elif a.startswith("--"):
            known_prefixes = ("--library=", "--platform=", "--std=", "--suppress=", "--suppressions-list=", "--include=", "--includes-file=", "--file-list=", "--file-filter=", "--project=", "--cppcheck-build-dir=", "--check-level=", "--max-configs=", "--max-ctu-depth=", "--output-file=", "--relative-paths", "--addon", "--addon-python", "--rule", "--rule-file", "--checkers-report", "--clang", "--config-exclude")
            flag = a.split("=", 1)[0]
            bare_known = {"--check-config", "--check-library", "--dump", "--force", "--fsigned-char", "--funsigned-char", "--inconclusive", "--report-progress", "--safety", "--verbose"}
            if a.startswith(known_prefixes) or flag in bare_known:
                pass
            else:
                print(f'cppcheck: error: unrecognized command line option: "{a}".')
                raise SystemExit(1)
        elif a.startswith("-") and a != "-":
            print(f'cppcheck: error: unrecognized command line option: "{a}".')
            raise SystemExit(1)
        else:
            files.append(a)
        i += 1
    return opts, files


def main(argv):
    opts, inputs = parse(argv)
    if not inputs:
        print(HELP)
        return 0
    files = collect_files(inputs)
    if opts["xml"]:
        print('<?xml version="1.0" encoding="UTF-8"?>', file=sys.stderr)
        print('<results version="2">', file=sys.stderr)
        print('    <cppcheck version="2.19 dev"/>', file=sys.stderr)
        print('    <errors>', file=sys.stderr)
    out_handle = None
    if opts["output_file"]:
        out_handle = open(opts["output_file"], "w")
    diag_stream = out_handle if out_handle is not None else sys.stderr
    all_findings = []
    for idx, f in enumerate(files, 1):
        if not opts["quiet"] and not opts["xml"]:
            print(f"Checking {f}...")
        findings = analyze_file(f, opts)
        all_findings.extend(findings)
        for finding in findings:
            if opts["xml"]:
                msg = finding.message.replace("&", "&amp;").replace('"', "&quot;").replace("'", "&apos;")
                print(f'        <error id="{finding.id}" severity="{finding.severity}" msg="{msg}" verbose="{msg}">', file=sys.stderr)
                print(f'            <location file="{finding.path}" line="{finding.line}"/>', file=sys.stderr)
                print('        </error>', file=sys.stderr)
            else:
                print(finding.text(opts["template"]), file=diag_stream)
        if not opts["quiet"] and not opts["xml"] and len(files) > 1:
            pct = int(idx * 100 / len(files))
            print(f"{idx}/{len(files)} files checked {pct}% done")
    if opts["xml"]:
        print('    </errors>', file=sys.stderr)
        print('</results>', file=sys.stderr)
    if out_handle is not None:
        out_handle.close()
    has_error = any(f.severity == "error" for f in all_findings)
    if has_error and opts["error_exitcode"]:
        return opts["error_exitcode"] & 255
    return 0

if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
