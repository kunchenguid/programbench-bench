#!/usr/bin/env python3
import os
import json
import subprocess
import sys


COMMANDS = [
    ("completion", "Generate the autocompletion script for the specified shell"),
    ("delete", "Delete a secret, including all versions"),
    ("env", "Print the secrets from the parameter store in a format to export as environment variables"),
    ("exec", "Executes a command with secrets loaded into the environment"),
    ("export", "Exports parameters in the specified format"),
    ("find", "Find the given secret across all services"),
    ("help", "Help about any command"),
    ("history", "View the history of a secret"),
    ("import", "import secrets from json or yaml"),
    ("list", "List the secrets set for a service"),
    ("list-services", "List services"),
    ("read", "Read a specific secret from the parameter store"),
    ("tag", "work with tags on secrets"),
    ("version", "print version"),
    ("write", "write a secret"),
]


GLOBAL_FLAGS = """Global Flags:
  -b, --backend string             Backend to use; AKA $CHAMBER_SECRET_BACKEND
                                    \tnull: no-op
                                    \tssm: SSM Parameter Store
                                    \tsecretsmanager: Secrets Manager
                                    \ts3: S3; requires --backend-s3-bucket
                                    \ts3-kms: S3 using AWS-KMS encryption; requires --backend-s3-bucket and --kms-key-alias set (if you want to write or delete keys). (default "ssm")
      --backend-s3-bucket string   bucket for S3 backend; AKA $CHAMBER_S3_BUCKET
      --kms-key-alias string       KMS Key Alias for writing and deleting secrets; AKA $CHAMBER_KMS_KEY_ALIAS. This option is currently only supported for the S3-KMS backend. (default "alias/parameter_store_key")
  -r, --retries int                For SSM or Secrets Manager, the number of retries we'll make before giving up; AKA $CHAMBER_RETRIES (default 10)
      --retry-mode string          For SSM, the model used to retry requests
                                     standard
                                     adaptive (default "standard")
      --verbose                    Print more information to STDERR"""


HELP = {
    "list": """List the secrets set for a service

Usage:
  chamber list <service> [flags]

Flags:
  -e, --expand    Expand parameter list with values
  -h, --help      help for list
  -t, --time      Sort by modified time
  -u, --user      Sort by user
  -v, --version   Sort by version""",
    "read": """Read a specific secret from the parameter store

Usage:
  chamber read <service> <key> [flags]

Flags:
  -h, --help          help for read
  -q, --quiet         Only print the secret
  -v, --version int   The version number of the secret. Defaults to latest. (default -1)""",
    "write": """write a secret

Usage:
  chamber write <service> <key> [--] <value|-> [flags]

Flags:
  -h, --help                  help for write
  -s, --singleline            Insert single line parameter (end with \\n)
      --skip-unchanged        Skip writing secret if value is unchanged
  -t, --tags stringToString   Add tags to the secret; new secrets only (default [])""",
    "delete": """Delete a secret, including all versions

Usage:
  chamber delete <service> <key> [flags]

Flags:
      --exact-key   Prevent normalization of the provided key in order to delete any keys that match the exact provided casing.
  -h, --help        help for delete""",
    "env": """Print the secrets from the parameter store in a format to export as environment variables

Usage:
  chamber env <service> [flags]

Flags:
  -p, --preserve-case    preserve variable name case
  -e, --escape-strings   escape special characters in values
  -h, --help             help for env""",
    "export": """Exports parameters in the specified format

Usage:
  chamber export <service...> [flags]

Flags:
  -f, --format string        Output format (json, yaml, java-properties, csv, tsv, dotenv, tfvars) (default "json")
  -o, --output-file string   Output file (default is standard output)
  -h, --help                 help for export""",
    "history": """View the history of a secret

Usage:
  chamber history <service> <key> [flags]

Flags:
  -h, --help   help for history""",
    "find": """Find the given secret across all services

Usage:
  chamber find <secret name> [flags]

Flags:
  -v, --by-value   Find parameters by value
  -h, --help       help for find""",
    "import": """import secrets from json or yaml

Usage:
  chamber import <service> <file|-> [flags]

Flags:
  -h, --help                           help for import
      --normalize-keys chamber write   Normalize keys to match how chamber write would handle them. If not specified, keys will be written exactly how they are defined in the import source.""",
    "list-services": """List services

Usage:
  chamber list-services <service> [flags]

Flags:
  -h, --help      help for list-services
  -s, --secrets   Include secret names in the list""",
    "version": """print version

Usage:
  chamber version [flags]

Flags:
  -h, --help   help for version""",
}

TAG_HELP = """work with tags on secrets

Usage:
  chamber tag [command]

Available Commands:
  delete      Delete tags for a specific secret
  read        Read tags for a specific secret
  write       Write tags for a specific secret

Flags:
  -h, --help   help for tag"""

TAG_SUB_HELP = {
    "read": """Read tags for a specific secret

Usage:
  chamber tag read <service> <key> [flags]

Flags:
  -h, --help   help for read""",
    "write": """Write tags for a specific secret

Usage:
  chamber tag write <service> <key> <tag>... [flags]

Flags:
      --delete-other-tags   Delete tags not specified in the command
  -h, --help                help for write""",
    "delete": """Delete tags for a specific secret

Usage:
  chamber tag delete <service> <key> <tag key>... [flags]

Flags:
  -h, --help   help for delete""",
}

EXEC_HELP = """Executes a command with secrets loaded into the environment

Usage:
  chamber exec <service...> -- <command> [<arg...>] [flags]

Examples:

Given a secret store like this:

\t$ echo '{"db_username": "root", "db_password": "hunter22"}' | chamber import - 

--strict will fail with unfilled env vars

\t$ HOME=/tmp DB_USERNAME=chamberme DB_PASSWORD=chamberme EXTRA=chamberme chamber exec --strict service exec -- env
\tchamber: extra unfilled env var EXTRA
\texit 1

--pristine takes effect after checking for --strict values

\t$ HOME=/tmp DB_USERNAME=chamberme DB_PASSWORD=chamberme chamber exec --strict --pristine service exec -- env
\tDB_USERNAME=root
\tDB_PASSWORD=hunter22


Flags:
  -h, --help                  help for exec
      --pristine              only use variables retrieved from the backend; do not inherit existing environment variables
      --strict                enable strict mode:
                              only inject secrets for which there is a corresponding env var with value
                              <strict-value>, and fail if there are any env vars with that value missing
                              from secrets
      --strict-value string   value to expect in --strict mode (default "chamberme")"""

COMPLETION_HELP = """Generate the autocompletion script for chamber for the specified shell.
See each sub-command's help for details on how to use the generated script.

Usage:
  chamber completion [command]

Available Commands:
  bash        Generate the autocompletion script for bash
  fish        Generate the autocompletion script for fish
  powershell  Generate the autocompletion script for powershell
  zsh         Generate the autocompletion script for zsh

Flags:
  -h, --help   help for completion"""


def root_help():
    lines = ["CLI for storing secrets", "", "Usage:", "  chamber [command]", "", "Available Commands:"]
    for name, desc in COMMANDS:
        lines.append(f"  {name:<13} {desc}")
    lines.extend(["", "Flags:", "  -b, --backend string             Backend to use; AKA $CHAMBER_SECRET_BACKEND",
                  "                                   \tnull: no-op",
                  "                                   \tssm: SSM Parameter Store",
                  "                                   \tsecretsmanager: Secrets Manager",
                  "                                   \ts3: S3; requires --backend-s3-bucket",
                  '                                   \ts3-kms: S3 using AWS-KMS encryption; requires --backend-s3-bucket and --kms-key-alias set (if you want to write or delete keys). (default "ssm")',
                  "      --backend-s3-bucket string   bucket for S3 backend; AKA $CHAMBER_S3_BUCKET",
                  "  -h, --help                       help for chamber",
                  '      --kms-key-alias string       KMS Key Alias for writing and deleting secrets; AKA $CHAMBER_KMS_KEY_ALIAS. This option is currently only supported for the S3-KMS backend. (default "alias/parameter_store_key")',
                  "  -r, --retries int                For SSM or Secrets Manager, the number of retries we'll make before giving up; AKA $CHAMBER_RETRIES (default 10)",
                  "      --retry-mode string          For SSM, the model used to retry requests",
                  "                                     standard",
                  '                                     adaptive (default "standard")',
                  "      --verbose                    Print more information to STDERR",
                  "",
                  'Use "chamber [command] --help" for more information about a command.'])
    return "\n".join(lines) + "\n"


def with_global(text):
    return text + "\n\n" + GLOBAL_FLAGS + "\n"


def emit(text):
    sys.stdout.write(text)


def error(msg, code=1):
    emit(f"Error: {msg}\n")
    return code


def normalize_global_args(argv):
    backend = os.environ.get("CHAMBER_SECRET_BACKEND", "ssm")
    out = []
    stop = False
    i = 0
    while i < len(argv):
        a = argv[i]
        if a == "--":
            out.extend(argv[i:])
            break
        if a in ("--backend", "-b"):
            if i + 1 >= len(argv):
                return backend, out, "flag needs an argument: --backend"
            backend = argv[i + 1]
            i += 2
            continue
        if a.startswith("--backend="):
            backend = a.split("=", 1)[1]
            i += 1
            continue
        if a in ("--backend-s3-bucket", "--kms-key-alias", "--retry-mode", "--retries", "-r"):
            i += 2
            continue
        if a.startswith("--backend-s3-bucket=") or a.startswith("--kms-key-alias=") or a.startswith("--retry-mode=") or a.startswith("--retries="):
            i += 1
            continue
        if a == "--verbose":
            i += 1
            continue
        out.append(a)
        i += 1
    return backend, out, None


def strip_flags(args, takes_value=(), bools=()):
    clean = []
    opts = {}
    i = 0
    while i < len(args):
        a = args[i]
        if a == "--":
            clean.extend(args[i + 1:])
            break
        if a in ("-h", "--help"):
            opts["help"] = True
            i += 1
        elif a in takes_value:
            if i + 1 >= len(args):
                opts["flag_error"] = f"flag needs an argument: {a}"
                i += 1
            else:
                opts[a] = args[i + 1]
                i += 2
        elif any(a.startswith(f + "=") for f in takes_value if f.startswith("--")):
            f = a.split("=", 1)[0]
            opts[f] = a.split("=", 1)[1]
            i += 1
        elif a in bools:
            opts[a] = True
            i += 1
        elif a != "-" and a.startswith("-"):
            opts.setdefault("unknown", a)
            i += 1
        else:
            clean.append(a)
            i += 1
    return clean, opts


def validate_exact(cmd, args, n):
    if len(args) != n:
        emit(f"Error: accepts {n} arg(s), received {len(args)}\n")
        emit(with_global(HELP[cmd]))
        return False
    return True


def validate_min(cmd, args, n):
    if len(args) < n:
        emit(f"Error: requires at least {n} arg(s), only received {len(args)}\n")
        emit(with_global(HELP[cmd] if cmd != "exec" else EXEC_HELP))
        return False
    return True


def ensure_backend(backend):
    valid = {"null", "ssm", "secretsmanager", "s3", "s3-kms"}
    if backend.lower() not in valid:
        emit(f"Error: Failed to get secret store: invalid backend `{backend.upper()}`\n")
        return False
    return True


def null_or_default_error(backend, message):
    if not ensure_backend(backend):
        return 1
    return error(message)


def command_exec(args, backend):
    if "-h" in args or "--help" in args:
        emit(with_global(EXEC_HELP))
        return 0
    strict = False
    pristine = False
    strict_value = "chamberme"
    services = []
    command = []
    saw_separator = False
    i = 0
    while i < len(args):
        a = args[i]
        if a == "--":
            saw_separator = True
            command = args[i + 1:]
            break
        if a == "--strict":
            strict = True
        elif a == "--pristine":
            pristine = True
        elif a == "--strict-value":
            strict_value = args[i + 1] if i + 1 < len(args) else strict_value
            i += 1
        elif a.startswith("--strict-value="):
            strict_value = a.split("=", 1)[1]
        else:
            services.append(a)
        i += 1
    if not services:
        emit("Error: requires at least 1 arg(s), only received 0\n")
        emit(with_global(EXEC_HELP))
        return 1
    if not saw_separator:
        emit("Error: please separate services and command with '--'. See usage\n")
        emit(with_global(EXEC_HELP))
        return 1
    if not command:
        emit("Error: must specify command to run. See usage: requires at least 1 arg(s), only received 0\n")
        emit(with_global(EXEC_HELP))
        return 1
    if not ensure_backend(backend):
        return 1
    if strict:
        for k, v in os.environ.items():
            if v == strict_value:
                emit(f"Error: parent env was expecting {k}={strict_value}, but was not in store\n")
                return 1
    env = {} if pristine else os.environ.copy()
    try:
        proc = subprocess.run(command, env=env)
        return proc.returncode
    except FileNotFoundError:
        emit(f"Error: fork/exec {command[0]}: no such file or directory\n")
        return 1


def command_export(args, backend):
    clean, opts = strip_flags(args, takes_value=("-f", "--format", "-o", "--output-file"), bools=())
    if opts.get("help"):
        emit(with_global(HELP["export"]))
        return 0
    if not validate_min("export", clean, 1):
        return 1
    if not ensure_backend(backend):
        return 1
    fmt = opts.get("-f") or opts.get("--format") or "json"
    if fmt not in {"json", "yaml", "java-properties", "csv", "tsv", "dotenv", "tfvars"}:
        return error(f"Unable to export parameters: Unsupported export format: {fmt}")
    text = "{}\n" if fmt in {"json", "yaml"} else ""
    output_file = opts.get("-o") or opts.get("--output-file")
    if output_file:
        with open(output_file, "w", encoding="utf-8") as f:
            f.write(text)
    else:
        emit(text)
    return 0


def main(argv):
    backend, args, global_error = normalize_global_args(argv)
    if global_error:
        return error(global_error)
    if not args or args[0] in ("-h", "--help"):
        emit(root_help())
        return 0
    if args[0] == "--version":
        return error("unknown flag: --version")
    if args[0] == "help":
        if len(args) == 1:
            emit(root_help())
            return 0
        args = [args[1], "--help", *args[2:]]
    cmd = args[0]
    rest = args[1:]
    if cmd == "version":
        if "-h" in rest or "--help" in rest:
            emit(with_global(HELP["version"]))
            return 0
        emit("chamber dev\n")
        return 0
    if cmd == "completion":
        emit(with_global(COMPLETION_HELP) + '\nUse "chamber completion [command] --help" for more information about a command.\n')
        return 0
    if cmd == "tag":
        if not rest or rest[0] in ("-h", "--help"):
            emit(with_global(TAG_HELP) + '\nUse "chamber tag [command] --help" for more information about a command.\n')
            return 0
        sub = rest[0]
        subrest = rest[1:]
        if sub in TAG_SUB_HELP and ("-h" in subrest or "--help" in subrest):
            emit(with_global(TAG_SUB_HELP[sub]))
            return 0
        if sub == "read":
            clean, _ = strip_flags(subrest)
            if len(clean) != 2:
                emit(f"Error: accepts 2 arg(s), received {len(clean)}\n")
                emit(with_global(TAG_SUB_HELP["read"]))
                return 1
            return null_or_default_error(backend, "Failed to read tags: Not implemented for Null Store")
        if sub == "write":
            clean, _ = strip_flags(subrest, bools=("--delete-other-tags",))
            if len(clean) < 3:
                emit(f"Error: requires at least 3 arg(s), only received {len(clean)}\n")
                emit(with_global(TAG_SUB_HELP["write"]))
                return 1
            return null_or_default_error(backend, "Failed to write tags: Not implemented for Null Store")
        if sub == "delete":
            clean, _ = strip_flags(subrest)
            if len(clean) < 3:
                emit(f"Error: requires at least 3 arg(s), only received {len(clean)}\n")
                emit(with_global(TAG_SUB_HELP["delete"]))
                return 1
            return null_or_default_error(backend, "Failed to delete tags: Not implemented for Null Store")
        return error(f'unknown command "{sub}" for "chamber tag"')
    if cmd == "exec":
        return command_exec(rest, backend)
    if cmd == "export":
        return command_export(rest, backend)
    if cmd not in HELP:
        emit(f'Error: unknown command "{cmd}" for "chamber"\n')
        emit("Run 'chamber --help' for usage.\n")
        return 1
    if "-h" in rest or "--help" in rest:
        emit(with_global(HELP[cmd]))
        return 0
    if cmd == "list":
        clean, opts = strip_flags(rest, bools=("-e", "--expand", "-t", "--time", "-u", "--user", "-v", "--version"))
        if not validate_exact("list", clean, 1):
            return 1
        if not ensure_backend(backend):
            return 1
        emit("Key\tVersion\t\tLastModified\tUser" + ("\tValue" if opts.get("-e") or opts.get("--expand") else "") + "\n")
        return 0
    if cmd == "read":
        clean, _ = strip_flags(rest, takes_value=("-v", "--version"), bools=("-q", "--quiet"))
        if not validate_exact("read", clean, 2):
            return 1
        return null_or_default_error(backend, "Failed to read: Not implemented for Null Store")
    if cmd == "write":
        clean, _ = strip_flags(rest, takes_value=("-t", "--tags"), bools=("-s", "--singleline", "--skip-unchanged"))
        if len(clean) != 3:
            emit(f"Error: accepts 3 arg(s), received {len(clean)}\n")
            emit(with_global(HELP["write"]))
            return 1
        if clean[2] == "-":
            sys.stdin.read()
        return null_or_default_error(backend, "Write is not implemented for Null Store")
    if cmd == "delete":
        clean, _ = strip_flags(rest, bools=("--exact-key",))
        if not validate_exact("delete", clean, 2):
            return 1
        return null_or_default_error(backend, "Not implemented for Null Store")
    if cmd == "env":
        clean, _ = strip_flags(rest, bools=("-p", "--preserve-case", "-e", "--escape-strings"))
        if not validate_exact("env", clean, 1):
            return 1
        if not ensure_backend(backend):
            return 1
        return 0
    if cmd == "history":
        clean, _ = strip_flags(rest)
        if not validate_exact("history", clean, 2):
            return 1
        if not ensure_backend(backend):
            return 1
        emit("Event\tVersion\t\tDate\tUser\n")
        return 0
    if cmd == "find":
        clean, opts = strip_flags(rest, bools=("-v", "--by-value"))
        if not validate_exact("find", clean, 1):
            return 1
        if not ensure_backend(backend):
            return 1
        emit("Service\t\tKey\n" if opts.get("-v") or opts.get("--by-value") else "Service\n")
        return 0
    if cmd == "list-services":
        clean, _ = strip_flags(rest, bools=("-s", "--secrets"))
        if not ensure_backend(backend):
            return 1
        emit("Service\n")
        return 0
    if cmd == "import":
        clean, _ = strip_flags(rest, bools=("--normalize-keys",))
        if not validate_exact("import", clean, 2):
            return 1
        data = ""
        if clean[1] == "-":
            data = sys.stdin.read()
        else:
            try:
                with open(clean[1], encoding="utf-8") as f:
                    data = f.read()
            except OSError as e:
                return error(f"Failed to read input file: {e}")
        if data == "":
            return error("Failed to decode input as json: EOF")
        stripped = data.strip()
        if stripped == "{}":
            emit("Successfully imported 0 secrets\n")
            return 0
        try:
            parsed = json.loads(data)
        except Exception:
            parsed = {"_": stripped} if ":" in stripped else None
        if isinstance(parsed, dict) and len(parsed) == 0:
            emit("Successfully imported 0 secrets\n")
            return 0
        return null_or_default_error(backend, "Write is not implemented for Null Store")
    return 1


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
