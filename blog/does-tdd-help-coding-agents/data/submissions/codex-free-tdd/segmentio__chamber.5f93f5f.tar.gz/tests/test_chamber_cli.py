#!/usr/bin/env python3
import os
import subprocess
import unittest


ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
EXE = os.environ.get("CANDIDATE_EXE", os.path.join(ROOT, "candidate-executable"))


def run_cmd(*args, env=None, input_data=None):
    merged_env = os.environ.copy()
    if env:
        merged_env.update(env)
    return subprocess.run(
        [EXE, *args],
        input=input_data,
        text=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        env=merged_env,
    )


class ChamberCliTest(unittest.TestCase):
    def test_root_help_and_version_match_observed_cli(self):
        help_result = run_cmd("--help")
        self.assertEqual(help_result.returncode, 0)
        self.assertIn("CLI for storing secrets\n\nUsage:\n  chamber [command]\n", help_result.stdout)
        self.assertIn("list-services List services", help_result.stdout)
        self.assertIn('s3-kms: S3 using AWS-KMS encryption; requires --backend-s3-bucket', help_result.stdout)

        version_result = run_cmd("version")
        self.assertEqual(version_result.returncode, 0)
        self.assertEqual(version_result.stdout, "chamber dev\n")

        bad_version_result = run_cmd("--version")
        self.assertEqual(bad_version_result.returncode, 1)
        self.assertEqual(bad_version_result.stdout, "Error: unknown flag: --version\n")

    def test_argument_validation_uses_cobra_style_messages(self):
        result = run_cmd("read", "svc")
        self.assertEqual(result.returncode, 1)
        self.assertIn("Error: accepts 2 arg(s), received 1\n", result.stdout)
        self.assertIn("Usage:\n  chamber read <service> <key> [flags]\n", result.stdout)
        self.assertIn("-q, --quiet         Only print the secret", result.stdout)

        result = run_cmd("export")
        self.assertEqual(result.returncode, 1)
        self.assertIn("Error: requires at least 1 arg(s), only received 0\n", result.stdout)
        self.assertIn("Usage:\n  chamber export <service...> [flags]\n", result.stdout)

    def test_subcommand_help_global_flag_indentation_and_completion_hint(self):
        result = run_cmd("list", "--help")
        self.assertEqual(result.returncode, 0)
        self.assertIn("                                    \tnull: no-op\n", result.stdout)
        self.assertNotIn("                                     \tnull: no-op\n", result.stdout)

        result = run_cmd("completion", "--help")
        self.assertEqual(result.returncode, 0)
        self.assertTrue(result.stdout.endswith('Use "chamber completion [command] --help" for more information about a command.\n'))

    def test_null_backend_read_write_delete_and_listing_outputs(self):
        result = run_cmd("--backend", "null", "list", "svc")
        self.assertEqual(result.returncode, 0)
        self.assertEqual(result.stdout, "Key\tVersion\t\tLastModified\tUser\n")

        result = run_cmd("--backend", "null", "list", "-e", "svc")
        self.assertEqual(result.returncode, 0)
        self.assertEqual(result.stdout, "Key\tVersion\t\tLastModified\tUser\tValue\n")

        result = run_cmd("--backend", "null", "read", "svc", "key")
        self.assertEqual(result.returncode, 1)
        self.assertEqual(result.stdout, "Error: Failed to read: Not implemented for Null Store\n")

        result = run_cmd("--backend", "null", "write", "svc", "key", "val")
        self.assertEqual(result.returncode, 1)
        self.assertEqual(result.stdout, "Error: Write is not implemented for Null Store\n")

        result = run_cmd("--backend", "null", "delete", "svc", "key")
        self.assertEqual(result.returncode, 1)
        self.assertEqual(result.stdout, "Error: Not implemented for Null Store\n")

    def test_null_backend_export_find_history_and_services(self):
        for fmt, expected in {
            "json": "{}\n",
            "yaml": "{}\n",
            "dotenv": "",
            "csv": "",
            "tsv": "",
            "java-properties": "",
            "tfvars": "",
        }.items():
            with self.subTest(fmt=fmt):
                result = run_cmd("--backend", "null", "export", "-f", fmt, "svc")
                self.assertEqual(result.returncode, 0)
                self.assertEqual(result.stdout, expected)

        result = run_cmd("--backend", "null", "export", "-f", "bogus", "svc")
        self.assertEqual(result.returncode, 1)
        self.assertEqual(result.stdout, "Error: Unable to export parameters: Unsupported export format: bogus\n")

        result = run_cmd("--backend", "null", "history", "svc", "key")
        self.assertEqual(result.returncode, 0)
        self.assertEqual(result.stdout, "Event\tVersion\t\tDate\tUser\n")

        result = run_cmd("--backend", "null", "find", "key")
        self.assertEqual(result.returncode, 0)
        self.assertEqual(result.stdout, "Service\n")

        result = run_cmd("--backend", "null", "find", "-v", "key")
        self.assertEqual(result.returncode, 0)
        self.assertEqual(result.stdout, "Service\t\tKey\n")

        result = run_cmd("--backend", "null", "list-services")
        self.assertEqual(result.returncode, 0)
        self.assertEqual(result.stdout, "Service\n")

        result = run_cmd("--backend", "null", "list-services", "ignored")
        self.assertEqual(result.returncode, 0)
        self.assertEqual(result.stdout, "Service\n")

    def test_tag_null_backend_errors(self):
        cases = [
            (("tag", "read", "svc", "key"), "Error: Failed to read tags: Not implemented for Null Store\n"),
            (("tag", "write", "svc", "key", "a=b"), "Error: Failed to write tags: Not implemented for Null Store\n"),
            (("tag", "delete", "svc", "key", "a"), "Error: Failed to delete tags: Not implemented for Null Store\n"),
        ]
        for args, expected in cases:
            with self.subTest(args=args):
                result = run_cmd("--backend", "null", *args)
                self.assertEqual(result.returncode, 1)
                self.assertEqual(result.stdout, expected)

    def test_exec_null_backend_runs_command_with_environment_options(self):
        result = run_cmd("--backend", "null", "exec", "svc", "--", "sh", "-c", "printf x:$EXTRA")
        self.assertEqual(result.returncode, 0)
        self.assertEqual(result.stdout, "x:")

        result = run_cmd(
            "--backend",
            "null",
            "exec",
            "--strict",
            "svc",
            "--",
            "sh",
            "-c",
            "printf should-not-run",
            env={"EXTRA": "chamberme"},
        )
        self.assertEqual(result.returncode, 1)
        self.assertEqual(result.stdout, "Error: parent env was expecting EXTRA=chamberme, but was not in store\n")

        result = run_cmd(
            "--backend",
            "null",
            "exec",
            "--pristine",
            "svc",
            "--",
            "sh",
            "-c",
            "printf x:${EXTRA-unset}",
            env={"EXTRA": "present"},
        )
        self.assertEqual(result.returncode, 0)
        self.assertEqual(result.stdout, "x:unset")

    def test_exec_reports_reference_usage_errors_for_missing_separator_or_command(self):
        result = run_cmd("--backend", "null", "exec", "svc")
        self.assertEqual(result.returncode, 1)
        self.assertIn("Error: please separate services and command with '--'. See usage\n", result.stdout)
        self.assertIn("Usage:\n  chamber exec <service...> -- <command> [<arg...>] [flags]\n", result.stdout)

        result = run_cmd("--backend", "null", "exec", "svc", "--")
        self.assertEqual(result.returncode, 1)
        self.assertIn("Error: must specify command to run. See usage: requires at least 1 arg(s), only received 0\n", result.stdout)
        self.assertIn("Usage:\n  chamber exec <service...> -- <command> [<arg...>] [flags]\n", result.stdout)

    def test_import_stdin_dash_is_an_argument(self):
        result = run_cmd("--backend", "null", "import", "svc", "-", input_data="")
        self.assertEqual(result.returncode, 1)
        self.assertEqual(result.stdout, "Error: Failed to decode input as json: EOF\n")

        result = run_cmd("--backend", "null", "import", "svc", "-", input_data="{}")
        self.assertEqual(result.returncode, 0)
        self.assertEqual(result.stdout, "Successfully imported 0 secrets\n")


if __name__ == "__main__":
    unittest.main()
