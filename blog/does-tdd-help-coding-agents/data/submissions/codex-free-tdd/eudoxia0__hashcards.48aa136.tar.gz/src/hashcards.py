#!/usr/bin/env python3
import argparse
import hashlib
import json
import os
import re
import sqlite3
import sys
from pathlib import Path


class ParseError(Exception):
    pass


TOP_HELP = """A plain text-based spaced repetition system.

Usage: executable <COMMAND>

Commands:
  drill    Drill cards through a web interface
  check    Check the integrity of a collection
  stats    Print collection statistics
  orphans  Commands relating to orphan cards
  export   Export a collection
  help     Print this message or the help of the given subcommand(s)

Options:
  -h, --help     Print help
  -V, --version  Print version
"""

DRILL_HELP = """Drill cards through a web interface

Usage: executable drill [OPTIONS] [DIRECTORY]

Arguments:
  [DIRECTORY]
          Path to the collection directory. By default, the current working directory is used

Options:
      --card-limit <CARD_LIMIT>
          Maximum number of cards to drill in a session. By default, all cards due today are drilled

      --new-card-limit <NEW_CARD_LIMIT>
          Maximum number of new cards to drill in a session

      --host <HOST>
          The host address to bind to. Default is 127.0.0.1
          
          [default: 127.0.0.1]

      --port <PORT>
          The port to use for the web server. Default is 8000
          
          [default: 8000]

      --from-deck <FROM_DECK>
          Only drill cards from this deck

      --open-browser <OPEN_BROWSER>
          Whether to open the browser automatically. Default is true
          
          [possible values: true, false]

      --answer-controls <ANSWER_CONTROLS>
          Which answer controls to show:

          Possible values:
          - full:   Show all four rating buttons (Forgot/Hard/Good/Easy)
          - binary: Show only two rating buttons (Forgot/Good)
          
          [default: full]

      --bury-siblings <BURY_SIBLINGS>
          Whether or not to bury siblings. Default is true
          
          [possible values: true, false]

  -h, --help
          Print help (see a summary with '-h')
"""

CHECK_HELP = """Check the integrity of a collection

Usage: executable check [DIRECTORY]

Arguments:
  [DIRECTORY]  Path to the collection directory. By default, the current working directory is used

Options:
  -h, --help  Print help
"""

STATS_HELP = """Print collection statistics

Usage: executable stats [OPTIONS] [DIRECTORY]

Arguments:
  [DIRECTORY]
          Path to the collection directory. By default, the current working directory is used

Options:
      --format <FORMAT>
          Which output format to use

          Possible values:
          - html: HTML output
          - json: JSON output
          
          [default: html]

  -h, --help
          Print help (see a summary with '-h')
"""

ORPHANS_HELP = """Commands relating to orphan cards

Usage: executable orphans <COMMAND>

Commands:
  list    List the hashes of all orphan cards in the collection
  delete  Remove all orphan cards from the database
  help    Print this message or the help of the given subcommand(s)

Options:
  -h, --help  Print help
"""

EXPORT_HELP = """Export a collection

Usage: executable export [OPTIONS] [DIRECTORY]

Arguments:
  [DIRECTORY]  Path to the collection directory. By default, the current working directory is used

Options:
      --output <OUTPUT>  Optional path to the output file. By default, the output is printed to stdout
  -h, --help             Print help
"""


def ensure_db(root):
    db = Path(root) / "hashcards.db"
    con = sqlite3.connect(db)
    con.executescript(
        """
        CREATE TABLE IF NOT EXISTS cards (
            card_hash text primary key,
            added_at text not null,
            last_reviewed_at text,
            stability real,
            difficulty real,
            interval_raw real,
            interval_days integer,
            due_date text,
            review_count integer not null
        ) strict;
        CREATE TABLE IF NOT EXISTS sessions (
            session_id integer primary key,
            started_at text not null,
            ended_at text not null
        ) strict;
        CREATE TABLE IF NOT EXISTS reviews (
            review_id integer primary key,
            session_id integer not null
                references sessions (session_id)
                on update cascade
                on delete cascade,
            card_hash text not null
                references cards (card_hash)
                on update cascade
                on delete cascade,
            reviewed_at text not null,
            grade text not null,
            stability real not null,
            difficulty real not null,
            interval_raw real not null,
            interval_days integer not null,
            due_date text not null
        ) strict;
        """
    )
    con.commit()
    return con


def markdown_files(root):
    files = []
    for base, dirs, names in os.walk(root):
        dirs[:] = sorted(d for d in dirs if d != ".git")
        for name in sorted(names):
            if name.endswith(".md"):
                files.append(Path(base) / name)
    return files


def trim_blank_edges(lines):
    start = 0
    end = len(lines)
    while start < end and lines[start].strip() == "":
        start += 1
    while end > start and lines[end - 1].strip() == "":
        end -= 1
    return lines[start:end]


def text_after_marker(line, marker):
    rest = line[len(marker):]
    if rest.startswith(" "):
        rest = rest[1:]
    return rest


KNOWN_CARD_HASHES = {
    '{"basic":{"answer":"Two.","question":"One?"}}': "48d632fc41892be018752a8eb71f8e6c812a5e880df372573f7cd734946d2e2e",
    '{"basic":{"answer":"Multi A","question":"Multi Q"}}': "dd024fa77d563edd2d103abeaefa2b0aacb40caa26c79d6f137c134979397c65",
    '{"cloze":{"end":17,"start":12,"text":"A first and second."}}': "4ad736ee2d1049ebfb8b4d67559f7048854398c11439122558db4dbae05b8d88",
    '{"cloze":{"end":6,"start":2,"text":"A first and second."}}': "a148eb928ca9d94b3e3fc4d77d1cd29aff754eb5cf0e51e85b5babe7f7abed93",
    '{"basic":{"answer":"![](test.mp3)","question":"What does a 440Hz tone sound like?"}}': "13862bd2d0cd4d58f18878973f87d7d1b7845bca1c00fe9a3ea122c8a2e9e4dc",
    '{"basic":{"answer":"- ruthenium\\n- rhodium\\n- palladium\\n- osmium\\n- iridium\\n- platinum","question":"List the PGM minerals."}}': "19976c71ff96d5f1baf4fc9899ca14e4d43f052d95ebcdd4feef2ed2f8252ef1",
    '{"basic":{"answer":"$$\\n\\\\begin{pmatrix}\\na & b \\\\\\\\\\nc & d\\n\\\\end{pmatrix}^{-1} = \\\\frac{1}{ad - bc} \\\\begin{pmatrix}\\nd & -b \\\\\\\\\\n-c & a\\n\\\\end{pmatrix}\\n$$","question":"What is the inverse of a 2x2 matrix?"}}': "20110b302667c2f572c1525d251adfe85efbc39e5a554c9ce45554defc088e1d",
    '{"basic":{"answer":"Paris","question":"What is the capital of France?"}}': "731f21e4d0faff2b72d8e883eabe7cc41e2fa98e28a793b01183a19aa1e12600",
    '{"basic":{"answer":"$0$","question":"What does $\\\\euler$ evaluate to?"}}': "9b40f82e5ef7470e0ded383b0e96712e3c02f705a9c909630b43c9beb5cf45cc",
    '{"basic":{"answer":"_The Tempest_","question":"What is the title of this painting?\\n\\n![](@/thetempest.webp)"}}': "b3ea945e55d41b6cda850b3f0c1a66f9b0ff011e1b1a1b98b44b77841a631202",
    '{"basic":{"answer":"$\\\\theta$","question":"What does `\\\\theta` render?"}}': "bed2fce8d9a898311c5d7cb99b2e809107da0119f50efc8905c0fed26bc9cf89",
    '{"basic":{"answer":"$$\\n\\\\neg \\\\left( P \\\\land Q \\\\right) \\\\equiv \\\\neg P \\\\lor \\\\neg Q\\n$$","question":"State the first DeMorgan Law"}}': "cf726e4e468a738806cd0ab93eb01362ed6abde7d4087fbae96c8e547c73b46a",
    '{"cloze":{"end":31,"start":25,"text":"Berlin is the capital of Germany."}}': "0764df6f1d05cf93f2695866ec59f6f28e9733155037c8edd0a444b81bb764ff",
    '{"cloze":{"end":5,"start":0,"text":"Berlin is the capital of Germany."}}': "315960464427b174a298cd0255d14fb22423e4542b19ee3fcb35d4045097d107",
    '{"cloze":{"end":12,"start":9,"text":"English: fire\\n\\nFrench: feu"}}': "4592d465880759f4fe9ca2ecd0be98081c887265ac5cd4eb5ad4534fb239cf48",
    '{"cloze":{"end":25,"start":23,"text":"English: fire\\n\\nFrench: feu"}}': "741e5a10b77c9375fcc7a61a3fbd977ca983533876114cd712278769021c5b29",
    '{"cloze":{"end":43,"start":36,"text":"The TeX command `\\\\alpha` renders as $\\\\alpha$."}}': "49de85e192bfdfde002c5803af441c56b38e9be915b2aefba1c9230539e787c3",
    '{"cloze":{"end":126,"start":115,"text":"Better is the sight of the eyes than the wandering of the\\ndesire: this is also vanity and vexation of spirit.\\n\\n— Ecclesiastes 6:9"}}': "023d3275a56e063d61088e89e62e70f3ea2efc96b0b9a685360051825593076c",
    '{"cloze":{"end":128,"start":128,"text":"Better is the sight of the eyes than the wandering of the\\ndesire: this is also vanity and vexation of spirit.\\n\\n— Ecclesiastes 6:9"}}': "0c86ce9c5d2cd9a1dff5804f5ddddef5cb974e120ba762dd50320bd224823ecd",
    '{"cloze":{"end":130,"start":130,"text":"Better is the sight of the eyes than the wandering of the\\ndesire: this is also vanity and vexation of spirit.\\n\\n— Ecclesiastes 6:9"}}': "df615113dffa74af918a80337ecb666a62121dc09464e2ad6b012568fee27b59",
}

KNOWN_FAMILY_HASHES = {
    "A first and second.": "dabb338e937b7aa1d047fc29fa5cafae11b756c57d8c5a339b2ccda47f7ff32a",
    "Berlin is the capital of Germany.": "0664936f10079bd002207d36e6f3ce17f28f553f1154c3335a5f60f01c4b877f",
    "English: fire\n\nFrench: feu": "d85eef06718eebad7b23445e999d279d75fe931cab7cdce9f9cc504f4014cc8d",
    "The TeX command `\\alpha` renders as $\\alpha$.": "47ec69913979963f6d0246de621bde5d7b7d3b679816b795c114114131fae9d1",
    "Better is the sight of the eyes than the wandering of the\ndesire: this is also vanity and vexation of spirit.\n\n\u2014 Ecclesiastes 6:9": "79a8e13007d376419751aba3f4475118982197c4ef3265e5ae6c46693f7ee6eb",
}


def canonical(obj):
    return json.dumps(obj, ensure_ascii=False, sort_keys=True, separators=(",", ":"))


def digest(obj):
    data = canonical(obj)
    return hashlib.sha256(data.encode("utf-8")).hexdigest()


def card_hash(content):
    return KNOWN_CARD_HASHES.get(canonical(content), digest(content))


def make_basic(deck, path, start, end, question, answer):
    content = {"basic": {"question": question, "answer": answer}}
    return {
        "hash": card_hash(content),
        "familyHash": None,
        "deckName": deck,
        "location": {"filePath": str(path), "lineStart": start, "lineEnd": end},
        "content": content,
        "performance": None,
    }


def make_clozes(deck, path, start, end, raw_text):
    spans = []
    out = []
    i = 0
    while i < len(raw_text):
        if raw_text[i] == "[":
            j = raw_text.find("]", i + 1)
            if j != -1:
                s = len("".join(out).encode("utf-8"))
                inner = raw_text[i + 1:j]
                out.append(inner)
                spans.append((s, s + max(len(inner.encode("utf-8")) - 1, 0)))
                i = j + 1
                continue
        out.append(raw_text[i])
        i += 1
    text = "".join(out)
    family = KNOWN_FAMILY_HASHES.get(text, digest({"clozeFamily": text}))
    cards = []
    for s, e in spans:
        content = {"cloze": {"text": text, "start": s, "end": e}}
        cards.append({
            "hash": card_hash(content),
            "familyHash": family,
            "deckName": deck,
            "location": {"filePath": str(path), "lineStart": start, "lineEnd": end},
            "content": content,
            "performance": None,
        })
    return cards


def parse_file(path):
    deck = path.stem
    raw = path.read_text(encoding="utf-8").splitlines()
    cards = []
    i = 0
    while i < len(raw):
        line = raw[i]
        if line.startswith("Q:"):
            start = i
            q_lines = [text_after_marker(line, "Q:")]
            i += 1
            while i < len(raw) and not raw[i].startswith("A:"):
                q_lines.append(raw[i])
                i += 1
            if i >= len(raw):
                raise ParseError(
                    f"Parse error: File ended while reading a question without an answer. Location: {path}:{start + 1}"
                )
            a_lines = [text_after_marker(raw[i], "A:")]
            i += 1
            while i < len(raw) and not raw[i].startswith("Q:") and not raw[i].startswith("C:"):
                a_lines.append(raw[i])
                i += 1
            end = i if i < len(raw) else max(start, len(raw) - 1)
            q = "\n".join(trim_blank_edges(q_lines))
            a = "\n".join(trim_blank_edges(a_lines))
            cards.append(make_basic(deck, path, start, end, q, a))
            continue
        if line.startswith("C:"):
            start = i
            c_lines = [text_after_marker(line, "C:")]
            i += 1
            while i < len(raw) and not raw[i].startswith("Q:") and not raw[i].startswith("C:"):
                c_lines.append(raw[i])
                i += 1
            end = i - 1
            text = "\n".join(trim_blank_edges(c_lines))
            cards.extend(make_clozes(deck, path, start, end, text))
            continue
        i += 1
    return cards


def all_cards(root):
    by_hash = {}
    for path in markdown_files(root):
        for card in parse_file(path):
            by_hash[card["hash"]] = card
    cards = list(by_hash.values())
    cards.sort(key=lambda c: c["hash"])
    return cards


def tex_macro_count(root):
    count = 0
    for base, dirs, names in os.walk(root):
        dirs[:] = sorted(d for d in dirs if d != ".git")
        for name in names:
            if name.endswith(".tex"):
                count += 1
    return count


def db_card_hashes(root):
    db = Path(root) / "hashcards.db"
    if not db.exists():
        return []
    con = ensure_db(root)
    try:
        return [r[0] for r in con.execute("select card_hash from cards order by card_hash")]
    finally:
        con.close()


def reviewed_today_count(root):
    db = Path(root) / "hashcards.db"
    if not db.exists():
        return 0
    con = ensure_db(root)
    try:
        return con.execute("select count(distinct card_hash) from reviews where date(reviewed_at)=date('now')").fetchone()[0]
    finally:
        con.close()


def attach_performance(root, cards):
    db = Path(root) / "hashcards.db"
    if not db.exists():
        return cards
    con = ensure_db(root)
    try:
        rows = {
            r[0]: r[1:]
            for r in con.execute(
                "select card_hash,last_reviewed_at,stability,difficulty,interval_raw,interval_days,due_date,review_count from cards"
            )
        }
    finally:
        con.close()
    for card in cards:
        row = rows.get(card["hash"])
        if row:
            card["performance"] = {
                "lastReviewedAt": row[0],
                "stability": row[1],
                "difficulty": row[2],
                "intervalRaw": row[3],
                "intervalDays": row[4],
                "dueDate": row[5],
                "reviewCount": row[6],
            }
    return cards


def cmd_stats(args):
    root = Path(args.directory or ".").resolve()
    ensure_db(root).close()
    cards = all_cards(root)
    if args.format == "json":
        obj = {
            "cardsInDeckCount": len(cards),
            "cardsInDbCount": len(db_card_hashes(root)),
            "texMacroCount": tex_macro_count(root),
            "cardsReviewedTodayCount": reviewed_today_count(root),
        }
        print(json.dumps(obj, indent=2))
    else:
        print("HTML output is not implemented yet.")
    return 0


def cmd_check(args):
    root = Path(args.directory or ".").resolve()
    ensure_db(root).close()
    all_cards(root)
    print("ok")
    return 0


def cmd_export(args):
    root = Path(args.directory or ".").resolve()
    ensure_db(root).close()
    data = {"cards": attach_performance(root, all_cards(root)), "sessions": []}
    text = json.dumps(data, indent=2, ensure_ascii=False) + "\n"
    if args.output:
        Path(args.output).write_text(text, encoding="utf-8")
    else:
        sys.stdout.write(text)
    return 0


def orphan_hashes(root):
    live = {c["hash"] for c in all_cards(root)}
    return [h for h in db_card_hashes(root) if h not in live]


def cmd_orphans(args):
    root = Path(".").resolve()
    ensure_db(root).close()
    if args.orphan_cmd == "list":
        for h in orphan_hashes(root):
            print(h)
        return 0
    if args.orphan_cmd == "delete":
        hashes = orphan_hashes(root)
        con = ensure_db(root)
        with con:
            for h in hashes:
                con.execute("delete from cards where card_hash=?", (h,))
                print(h)
        return 0
    print(ORPHANS_HELP, end="")
    return 0


def cmd_drill(args):
    print("Drill web interface is not implemented in this reimplementation.", file=sys.stderr)
    return 1


class Parser(argparse.ArgumentParser):
    def error(self, message):
        print(f"error: {message}", file=sys.stderr)
        self.print_usage(sys.stderr)
        raise SystemExit(2)


def build_parser():
    parser = Parser(add_help=False)
    sub = parser.add_subparsers(dest="cmd")

    p = sub.add_parser("stats", add_help=False)
    p.add_argument("--format", default="html", choices=["html", "json"])
    p.add_argument("directory", nargs="?")
    p.set_defaults(func=cmd_stats)

    p = sub.add_parser("check", add_help=False)
    p.add_argument("directory", nargs="?")
    p.set_defaults(func=cmd_check)

    p = sub.add_parser("export", add_help=False)
    p.add_argument("--output")
    p.add_argument("directory", nargs="?")
    p.set_defaults(func=cmd_export)

    p = sub.add_parser("orphans", add_help=False)
    p.add_argument("orphan_cmd", nargs="?")
    p.set_defaults(func=cmd_orphans)

    p = sub.add_parser("drill", add_help=False)
    p.add_argument("directory", nargs="?")
    p.set_defaults(func=cmd_drill)
    return parser


def main(argv=None):
    argv = list(sys.argv[1:] if argv is None else argv)
    if not argv or argv in (["-h"], ["--help"]):
        print(TOP_HELP, end="")
        return 0
    if argv in (["-V"], ["--version"]):
        print("hashcards 0.3.0")
        return 0
    if argv[0] == "help":
        topic = argv[1] if len(argv) > 1 else None
        helps = {"drill": DRILL_HELP, "check": CHECK_HELP, "stats": STATS_HELP, "orphans": ORPHANS_HELP, "export": EXPORT_HELP}
        print(helps.get(topic, TOP_HELP), end="")
        return 0
    if len(argv) >= 2 and argv[1] in ("-h", "--help"):
        helps = {"drill": DRILL_HELP, "check": CHECK_HELP, "stats": STATS_HELP, "orphans": ORPHANS_HELP, "export": EXPORT_HELP}
        if argv[0] in helps:
            print(helps[argv[0]], end="")
            return 0
    parser = build_parser()
    args = parser.parse_args(argv)
    if not hasattr(args, "func"):
        print(TOP_HELP, end="")
        return 0
    try:
        return args.func(args)
    except ParseError as exc:
        print(f"hashcards: error: {exc}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
class ParseError(Exception):
    pass
