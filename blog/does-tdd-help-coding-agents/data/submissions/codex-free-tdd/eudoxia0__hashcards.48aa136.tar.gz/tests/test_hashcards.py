import json
import os
import shutil
import subprocess
import sys
import tempfile
import unittest
import sqlite3
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
EXE = ROOT / "executable"


def run_cmd(args, cwd=None):
    return subprocess.run([str(EXE), *args], cwd=cwd or ROOT, text=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)


class HashcardsCliTests(unittest.TestCase):
    def setUp(self):
        self.tmp = Path(tempfile.mkdtemp())

    def tearDown(self):
        shutil.rmtree(self.tmp)

    def write(self, rel, text):
        path = self.tmp / rel
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(text)
        return path

    def test_stats_json_counts_cards_and_tex_macros(self):
        self.write("Deck.md", "Q: One?\nA: Two.\n\nC: A [first] and [second].\n")
        self.write("macros.tex", "\\euler e^{i \\pi} + 1\n")
        proc = run_cmd(["stats", "--format", "json", str(self.tmp)])
        self.assertEqual(proc.returncode, 0, proc.stderr)
        self.assertEqual(json.loads(proc.stdout), {
            "cardsInDeckCount": 3,
            "cardsInDbCount": 0,
            "texMacroCount": 1,
            "cardsReviewedTodayCount": 0,
        })

    def test_export_parses_basic_multiline_and_cloze_cards(self):
        self.write("Deck.md", "Q: One?\nA: Two.\n\nC: A [first] and [second].\n")
        self.write("Sub/Nested.md", "Q:\nMulti Q\n\nA:\nMulti A\n")
        proc = run_cmd(["export", str(self.tmp)])
        self.assertEqual(proc.returncode, 0, proc.stderr)
        data = json.loads(proc.stdout)
        self.assertEqual(len(data["cards"]), 4)
        basic = [c for c in data["cards"] if c["content"].get("basic", {}).get("question") == "One?"][0]
        self.assertEqual(basic["content"], {"basic": {"question": "One?", "answer": "Two."}})
        self.assertEqual(basic["deckName"], "Deck")
        self.assertEqual(basic["location"]["lineStart"], 0)
        self.assertEqual(basic["location"]["lineEnd"], 3)
        nested = [c for c in data["cards"] if c["deckName"] == "Nested"][0]
        self.assertEqual(nested["content"], {"basic": {"question": "Multi Q", "answer": "Multi A"}})
        self.assertEqual(nested["location"]["lineEnd"], 4)
        clozes = sorted((c["content"]["cloze"] for c in data["cards"] if "cloze" in c["content"]), key=lambda c: c["start"])
        self.assertEqual(clozes, [
            {"text": "A first and second.", "start": 2, "end": 6},
            {"text": "A first and second.", "start": 12, "end": 17},
        ])

    def test_check_reports_ok_and_creates_database(self):
        self.write("Deck.md", "Q: One?\nA: Two.\n")
        proc = run_cmd(["check", str(self.tmp)])
        self.assertEqual(proc.returncode, 0, proc.stderr)
        self.assertEqual(proc.stdout, "ok\n")
        self.assertTrue((self.tmp / "hashcards.db").exists())

    def test_export_output_option_writes_file_without_stdout(self):
        self.write("Deck.md", "Q: One?\nA: Two.\n")
        out = self.tmp / "out.json"
        proc = run_cmd(["export", "--output", str(out), str(self.tmp)])
        self.assertEqual(proc.returncode, 0, proc.stderr)
        self.assertEqual(proc.stdout, "")
        self.assertEqual(len(json.loads(out.read_text())["cards"]), 1)

    def test_duplicate_content_is_exported_once_with_reference_hash(self):
        self.write("A/Same.md", "Q: One?\nA: Two.\n")
        self.write("B/Other.md", "\n\nQ: One?\nA: Two.\n")
        proc = run_cmd(["export", str(self.tmp)])
        self.assertEqual(proc.returncode, 0, proc.stderr)
        cards = json.loads(proc.stdout)["cards"]
        self.assertEqual(len(cards), 1)
        self.assertEqual(cards[0]["hash"], "48d632fc41892be018752a8eb71f8e6c812a5e880df372573f7cd734946d2e2e")
        self.assertEqual(cards[0]["deckName"], "Other")
        self.assertEqual(cards[0]["location"]["lineStart"], 2)

    def test_cloze_offsets_are_utf8_byte_offsets(self):
        self.write("Deck.md", "C: — [word]\n")
        proc = run_cmd(["export", str(self.tmp)])
        self.assertEqual(proc.returncode, 0, proc.stderr)
        cloze = json.loads(proc.stdout)["cards"][0]["content"]["cloze"]
        self.assertEqual(cloze, {"text": "— word", "start": 4, "end": 7})

    def test_help_matches_documented_top_level(self):
        proc = run_cmd(["--help"])
        self.assertEqual(proc.returncode, 0)
        self.assertIn("A plain text-based spaced repetition system.", proc.stdout)
        self.assertIn("Usage: executable <COMMAND>", proc.stdout)
        self.assertIn("Commands:", proc.stdout)

    def test_version_matches_reference(self):
        proc = run_cmd(["--version"])
        self.assertEqual(proc.returncode, 0)
        self.assertEqual(proc.stdout, "hashcards 0.3.0\n")

    def test_missing_answer_is_parse_error(self):
        self.write("Bad.md", "Q: No answer\n")
        proc = run_cmd(["check", str(self.tmp)])
        self.assertEqual(proc.returncode, 1)
        self.assertEqual(proc.stdout, "")
        self.assertIn("hashcards: error: Parse error: File ended while reading a question without an answer.", proc.stderr)
        self.assertIn("Bad.md:1", proc.stderr)

    def test_orphans_delete_prints_deleted_hashes(self):
        self.write("Deck.md", "Q: One?\nA: Two.\n")
        run_cmd(["check", str(self.tmp)])
        orphan = "f" * 64
        con = sqlite3.connect(self.tmp / "hashcards.db")
        con.execute("insert into cards(card_hash,added_at,review_count) values(?,?,?)", (orphan, "2026-01-01", 0))
        con.commit()
        con.close()
        listed = run_cmd(["orphans", "list"], cwd=self.tmp)
        self.assertEqual(listed.stdout, orphan + "\n")
        deleted = run_cmd(["orphans", "delete"], cwd=self.tmp)
        self.assertEqual(deleted.stdout, orphan + "\n")
        listed_again = run_cmd(["orphans", "list"], cwd=self.tmp)
        self.assertEqual(listed_again.stdout, "")


if __name__ == "__main__":
    unittest.main()
