#!/usr/bin/env python3
import re
import sys

RESET = "\x1b[0m"
VERSION = "diffr 0.1.5"

FULL_HELP = """diffr 0.1.5
Nathan Moreau <nathan.moreau@m4x.org>

diffr adds word-level diff on top of unified diffs.
word-level diff information is displayed using text attributes.

USAGE:
    diffr reads from standard input and writes to standard output.

    Typical usage is for interactive use of diff:
    diff -u <file1> <file2> | diffr
    git show | diffr

OPTIONS:
        --colors <COLOR_SPEC>...
            Configure color settings for console ouput.

            There are four faces to customize:
            +----------------+--------------+----------------+
            |  line prefix   |      +       |       -        |
            +----------------+--------------+----------------+
            | common segment |    added     |    removed     |
            | unique segment | refine-added | refine-removed |
            +----------------+--------------+----------------+

            The customization allows
            - to change the foreground or background color;
            - to set or unset the attributes 'bold', 'intense', 'underline';
            - to clear all attributes.

            Customization is done passing a color_spec argument.
            This flag may be provided multiple times.

            The syntax is the following:

            color_spec = face-name + ':' + attributes
            attributes = attribute
                       | attribute + ':' + attributes
            attribute  = ('foreground' | 'background') + ':' + color
                       | (<empty> | 'no') + font-flag
                       | 'none'
            font-flag  = 'italic'
                       | 'bold'
                       | 'intense'
                       | 'underline'
            color      = 'none'
                       | [0-255]
                       | [0-255] + ',' + [0-255] + ',' + [0-255]
                       | ('black', 'blue', 'green', 'red',
                          'cyan', 'magenta', 'yellow', 'white')

            For example, the color_spec

                'refine-added:background:blue:bold'

            sets the color of unique added segments with
            a blue background, written with a bold font.

        --line-numbers <compact|aligned>
            Display line numbers. Style is optional.
            When style = 'compact', take as little width as possible.
            When style = 'aligned', align to tab stops (useful if tab is used for indentation). [default: compact]

    -h, --help
            Prints help information

    -V, --version
            Prints version information
"""

SHORT_HELP = """diffr 0.1.5
Nathan Moreau <nathan.moreau@m4x.org>

diffr adds word-level diff on top of unified diffs.
word-level diff information is displayed using text attributes.

USAGE:
    diffr reads from standard input and writes to standard output.

    Typical usage is for interactive use of diff:
    diff -u <file1> <file2> | diffr
    git show | diffr

OPTIONS:
        --colors <COLOR_SPEC>...    Configure color settings.
        --line-numbers              Display line numbers.
    -h, --help                      Prints help information
    -V, --version                   Prints version information
"""


class Face:
    def __init__(self, codes=None):
        self.codes = list(codes or [])

    def ansi(self):
        return "".join(f"\x1b[{code}m" for code in self.codes)

    def clear(self):
        self.codes = []


def default_faces():
    return {
        "added": Face(["32"]),
        "removed": Face(["31"]),
        "refine-added": Face(["1", "38;2;255;255;255", "42"]),
        "refine-removed": Face(["1", "38;2;255;255;255", "41"]),
    }


COLOR_NAMES = {
    "black": "30",
    "red": "31",
    "green": "32",
    "yellow": "33",
    "blue": "34",
    "magenta": "35",
    "cyan": "36",
    "white": "37",
}

BG_NAMES = {name: str(int(code) + 10) for name, code in COLOR_NAMES.items()}
FLAGS = {"bold": "1", "italic": "3", "underline": "4", "intense": "1"}


def parse_color(which, value):
    if value == "none":
        return None
    names = COLOR_NAMES if which == "foreground" else BG_NAMES
    if value in names:
        return names[value]
    if re.fullmatch(r"\d{1,3}", value):
        return ("38;5;" if which == "foreground" else "48;5;") + value
    if re.fullmatch(r"\d{1,3},\d{1,3},\d{1,3}", value):
        r, g, b = value.split(",")
        return ("38;2;" if which == "foreground" else "48;2;") + f"{r};{g};{b}"
    return None


def apply_color_spec(faces, spec):
    if ":" not in spec:
        raise ValueError(f"unexpected face name: got '{spec}', expected added|refine-added|removed|refine-removed")
    name, rest = spec.split(":", 1)
    if name not in faces:
        raise ValueError(f"unexpected face name: got '{name}', expected added|refine-added|removed|refine-removed")
    parts = rest.split(":") if rest else [""]
    face = faces[name]
    i = 0
    while i < len(parts):
        part = parts[i]
        if part == "none":
            face.clear()
            i += 1
        elif part in ("foreground", "background") and i + 1 < len(parts):
            code = parse_color(part, parts[i + 1])
            if code is not None:
                face.codes = [c for c in face.codes if not c.startswith("3" if part == "foreground" else "4")]
                face.codes.append(code)
            i += 2
        elif part in FLAGS:
            code = FLAGS[part]
            if code not in face.codes:
                face.codes.insert(0, code)
            i += 1
        elif part.startswith("no") and part[2:] in FLAGS:
            code = FLAGS[part[2:]]
            face.codes = [c for c in face.codes if c != code]
            i += 1
        else:
            i += 1


def parse_args(argv):
    faces = default_faces()
    line_numbers = False
    style = "compact"
    i = 0
    while i < len(argv):
        arg = argv[i]
        if arg == "-h":
            sys.stdout.write(SHORT_HELP)
            raise SystemExit(0)
        if arg == "--help":
            sys.stdout.write(FULL_HELP)
            raise SystemExit(0)
        if arg in ("-V", "--version"):
            sys.stdout.write(VERSION + "\n")
            raise SystemExit(0)
        if arg == "--colors":
            if i + 1 >= len(argv):
                sys.stderr.write("option requires an argument: '--colors'\n")
                raise SystemExit(2)
            try:
                apply_color_spec(faces, argv[i + 1])
            except ValueError as e:
                sys.stderr.write(str(e) + "\n")
                raise SystemExit(255)
            i += 2
            continue
        if arg == "--line-numbers":
            line_numbers = True
            if i + 1 < len(argv) and not argv[i + 1].startswith("-"):
                style = argv[i + 1]
                if style not in ("aligned", "compact", "fixed"):
                    sys.stderr.write(f"unexpected line number style: got '{style}', expected aligned|compact|fixed\n")
                    raise SystemExit(255)
                i += 2
            else:
                i += 1
            continue
        sys.stderr.write(f"bad argument: '{arg}'\n")
        sys.stderr.write(SHORT_HELP)
        raise SystemExit(2)
    return faces, line_numbers, style


def tokenize(text):
    return re.findall(r"\w+|\W+", text, flags=re.UNICODE)


def lcs_common(a, b):
    n, m = len(a), len(b)
    dp = [[0] * (m + 1) for _ in range(n + 1)]
    for i in range(n - 1, -1, -1):
        for j in range(m - 1, -1, -1):
            if a[i] == b[j]:
                dp[i][j] = dp[i + 1][j + 1] + 1
            else:
                dp[i][j] = max(dp[i + 1][j], dp[i][j + 1])
    common_a, common_b = set(), set()
    i = j = 0
    while i < n and j < m:
        if a[i] == b[j]:
            common_a.add(i)
            common_b.add(j)
            i += 1
            j += 1
        elif dp[i + 1][j] >= dp[i][j + 1]:
            i += 1
        else:
            j += 1
    return common_a, common_b


def segments(old, new):
    old_tokens = tokenize(old)
    new_tokens = tokenize(new)
    old_common, new_common = lcs_common(old_tokens, new_tokens)
    return (
        [(tok, i not in old_common) for i, tok in enumerate(old_tokens)],
        [(tok, i not in new_common) for i, tok in enumerate(new_tokens)],
    )


def paint_text(parts, base, refine, trailing_base=True):
    out = []
    in_base = False
    last_unique = False
    for text, unique in parts:
        if unique:
            if in_base:
                out.append(RESET)
                in_base = False
            out.append(RESET + refine.ansi() + text + RESET)
            last_unique = True
        else:
            if not in_base:
                out.append(RESET + base.ansi())
                in_base = True
            out.append(text)
            last_unique = False
    if not parts:
        out.append(RESET + base.ansi())
        in_base = True
    if in_base:
        out.append(RESET)
    elif last_unique and trailing_base:
        out.append(RESET + base.ansi() + RESET)
    return "".join(out)


HUNK_RE = re.compile(r"^@@ -(\d+)(?:,\d+)? \+(\d+)(?:,\d+)? @@")


def split_line(line):
    if line.endswith("\n"):
        return line[:-1], "\n"
    return line, ""


def number_prefix(kind, old_no, new_no, style):
    if style == "aligned":
        old_s = str(old_no) if old_no is not None else ""
        new_s = str(new_no) if new_no is not None else ""
        return f"{old_s:>2} {new_s:>2}"
    if style == "fixed":
        old_s = str(old_no) if old_no is not None else ""
        new_s = str(new_no) if new_no is not None else ""
        return f"{old_s:>3} {new_s:>3}"
    old_s = str(old_no) if old_no is not None else ""
    new_s = str(new_no) if new_no is not None else ""
    return f"{old_s:>1} {new_s:>1}"


def render_change(prefix, body, face, parts, refine_face, num_prefix=None, trailing_base=True):
    start = RESET
    if num_prefix is not None:
        start += face.ansi() + num_prefix + RESET
        if "\t" not in num_prefix and len(num_prefix) == 5:
            start += "\t"
        start += RESET
    start += face.ansi() + prefix + RESET
    return start + paint_text(parts, face, refine_face, trailing_base)


def render_removed_added(removed, added, faces, line_numbers, style):
    removed_out = []
    added_out = []
    count = max(len(removed), len(added))
    for i in range(count):
        old_item = removed[i] if i < len(removed) else None
        new_item = added[i] if i < len(added) else None
        old_text = old_item[1] if old_item else ""
        new_text = new_item[1] if new_item else ""
        old_parts, new_parts = segments(old_text, new_text)
        paired_missing_final_newline = bool(old_item and new_item and (old_item[2] == "" or new_item[2] == ""))
        if old_item:
            num = number_prefix("-", old_item[0], None, style) if line_numbers else None
            removed_out.append(
                render_change(
                    "-",
                    old_text,
                    faces["removed"],
                    old_parts,
                    faces["refine-removed"],
                    num,
                    not paired_missing_final_newline,
                )
                + old_item[2]
            )
        if new_item:
            num = number_prefix("+", None, new_item[0], style) if line_numbers else None
            before_unmatched_added = len(added) > len(removed) and i == len(removed) - 1
            added_out.append(
                render_change(
                    "+",
                    new_text,
                    faces["added"],
                    new_parts,
                    faces["refine-added"],
                    num,
                    not paired_missing_final_newline and not before_unmatched_added,
                )
                + new_item[2]
            )
    return removed_out + added_out


def render(input_text, faces, line_numbers=False, style="compact"):
    out = []
    old_no = new_no = None
    in_hunk = False
    removed = []
    added = []

    def flush():
        nonlocal removed, added
        if removed or added:
            out.extend(render_removed_added(removed, added, faces, line_numbers, style))
            removed = []
            added = []

    for raw in input_text.splitlines(True):
        line, ending = split_line(raw)
        m = HUNK_RE.match(line)
        if m:
            flush()
            old_no, new_no = int(m.group(1)), int(m.group(2))
            in_hunk = True
            out.append(f"{RESET}{line}{RESET}{ending}")
            continue
        if in_hunk and line.startswith("-") and not line.startswith("---"):
            removed.append((old_no, line[1:], ending))
            old_no += 1
            continue
        if in_hunk and line.startswith("+") and not line.startswith("+++"):
            added.append((new_no, line[1:], ending))
            new_no += 1
            continue
        flush()
        if in_hunk and line.startswith(" "):
            prefix = number_prefix(" ", old_no, new_no, style) if line_numbers else ""
            if line_numbers and style == "aligned":
                prefix += "\t"
            out.append(f"{prefix}{RESET}{line}{RESET}{ending}")
            old_no += 1
            new_no += 1
        else:
            out.append(f"{RESET}{line}{RESET}{ending}")
    flush()
    return "".join(out)


def main(argv=None):
    faces, line_numbers, style = parse_args(sys.argv[1:] if argv is None else argv)
    data = sys.stdin.read()
    sys.stdout.write(render(data, faces, line_numbers, style))


if __name__ == "__main__":
    main()
