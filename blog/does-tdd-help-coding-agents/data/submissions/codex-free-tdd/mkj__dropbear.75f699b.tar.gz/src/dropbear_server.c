#define _POSIX_C_SOURCE 200809L

#include <arpa/inet.h>
#include <ctype.h>
#include <errno.h>
#include <netinet/in.h>
#include <signal.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <time.h>
#include <unistd.h>

#define VERSION "2025.89"
#define DEFAULT_PIDFILE "/var/run/dropbear.pid"

static volatile sig_atomic_t stop_requested = 0;

static void on_signal(int sig) {
    (void)sig;
    stop_requested = 1;
}

static void timestamp(char *buf, size_t len) {
    time_t now = time(NULL);
    struct tm tmv;
    localtime_r(&now, &tmv);
    strftime(buf, len, "%b %d %H:%M:%S", &tmv);
}

static void log_msg(const char *msg) {
    char ts[32];
    timestamp(ts, sizeof(ts));
    fprintf(stderr, "[%ld] %s %s\n", (long)getpid(), ts, msg);
    fflush(stderr);
}

static void log_fmt(const char *prefix, const char *value) {
    char ts[32];
    timestamp(ts, sizeof(ts));
    fprintf(stderr, "[%ld] %s %s%s\n", (long)getpid(), ts, prefix, value);
    fflush(stderr);
}

static void print_help(const char *argv0) {
    printf("Dropbear server v%s https://matt.ucc.asn.au/dropbear/dropbear.html\n", VERSION);
    printf("Usage: %s [options]\n", argv0);
    printf("-b bannerfile\tDisplay the contents of bannerfile before user login\n");
    printf("\t\t(default: none)\n");
    printf("-r keyfile      Specify hostkeys (repeatable)\n");
    printf("\t\tdefaults: \n");
    printf("\t\t- rsa /etc/dropbear/dropbear_rsa_host_key\n");
    printf("\t\t- ecdsa /etc/dropbear/dropbear_ecdsa_host_key\n");
    printf("\t\t- ed25519 /etc/dropbear/dropbear_ed25519_host_key\n");
    printf("-D\t\tDirectory containing authorized_keys file\n");
    printf("-R\t\tCreate hostkeys as required\n");
    printf("-F\t\tDon't fork into background\n");
    printf("-e\t\tPass on server process environment to child process\n");
    printf("(Syslog support not compiled in, using stderr)\n");
    printf("-m\t\tDon't display the motd on login\n");
    printf("-w\t\tDisallow root logins\n");
    printf("-G\t\tRestrict logins to members of specified group\n");
    printf("-s\t\tDisable password logins\n");
    printf("-g\t\tDisable password logins for root\n");
    printf("-B\t\tAllow blank password logins\n");
    printf("-t\t\tEnable two-factor authentication (both password and public key required)\n");
    printf("-T\t\tMaximum authentication tries (default 10)\n");
    printf("-j\t\tDisable local port forwarding\n");
    printf("-k\t\tDisable remote port forwarding\n");
    printf("-a\t\tAllow connections to forwarded ports from any host\n");
    printf("-c command\tForce executed command\n");
    printf("-p [address:]port\n");
    printf("\t\tListen on specified tcp port (and optionally address),\n");
    printf("\t\tup to 10 can be specified\n");
    printf("\t\t(default port is 22 if none specified)\n");
    printf("-P PidFile\tCreate pid file PidFile\n");
    printf("\t\t(default /var/run/dropbear.pid)\n");
    printf("-l <interface>\n");
    printf("\t\tinterface to bind on\n");
    printf("-i\t\tStart for inetd\n");
    printf("-W <receive_window_buffer> (default 24576, larger may be faster, max 10MB)\n");
    printf("-K <keepalive>  (0 is never, default 0, in seconds)\n");
    printf("-I <idle_timeout>  (0 is never, default 0, in seconds)\n");
    printf("-z    disable QoS\n");
    printf("-V    Version\n");
    printf("\n");
}

static bool is_number(const char *s) {
    if (!s || !*s) {
        return false;
    }
    for (const unsigned char *p = (const unsigned char *)s; *p; p++) {
        if (!isdigit(*p)) {
            return false;
        }
    }
    return true;
}

static const char *need_arg(int *argi, int *pos, int argc, char **argv) {
    const char *cur = argv[*argi];
    if (cur[*pos + 1] != '\0') {
        const char *arg = &cur[*pos + 1];
        *pos = (int)strlen(cur) - 1;
        return arg;
    }
    if (*argi + 1 >= argc) {
        return NULL;
    }
    (*argi)++;
    *pos = (int)strlen(argv[*argi]) - 1;
    return argv[*argi];
}

static void parse_listen(const char *spec, char *addr, size_t addr_len, int *port) {
    const char *colon = strrchr(spec, ':');
    const char *port_text = spec;
    if (colon && colon[1] != '\0') {
        size_t n = (size_t)(colon - spec);
        if (n >= addr_len) {
            n = addr_len - 1;
        }
        memcpy(addr, spec, n);
        addr[n] = '\0';
        port_text = colon + 1;
    }
    if (is_number(port_text)) {
        long p = strtol(port_text, NULL, 10);
        if (p > 0 && p <= 65535) {
            *port = (int)p;
        }
    }
}

static int make_listener(const char *addr, int port) {
    int fd = socket(AF_INET, SOCK_STREAM, 0);
    if (fd < 0) {
        log_fmt("Early exit: ", strerror(errno));
        return -1;
    }
    int one = 1;
    setsockopt(fd, SOL_SOCKET, SO_REUSEADDR, &one, sizeof(one));

    struct sockaddr_in sa;
    memset(&sa, 0, sizeof(sa));
    sa.sin_family = AF_INET;
    sa.sin_port = htons((uint16_t)port);
    if (!addr[0]) {
        sa.sin_addr.s_addr = htonl(INADDR_ANY);
    } else if (inet_pton(AF_INET, addr, &sa.sin_addr) != 1) {
        sa.sin_addr.s_addr = htonl(INADDR_ANY);
    }
    if (bind(fd, (struct sockaddr *)&sa, sizeof(sa)) < 0) {
        log_fmt("Early exit: ", strerror(errno));
        close(fd);
        return -1;
    }
    if (listen(fd, 16) < 0) {
        log_fmt("Early exit: ", strerror(errno));
        close(fd);
        return -1;
    }
    return fd;
}

static void serve_loop(int fd) {
    signal(SIGTERM, on_signal);
    signal(SIGINT, on_signal);
    signal(SIGPIPE, SIG_IGN);
    while (!stop_requested) {
        struct sockaddr_in peer;
        socklen_t peer_len = sizeof(peer);
        int cfd = accept(fd, (struct sockaddr *)&peer, &peer_len);
        if (cfd < 0) {
            if (errno == EINTR) {
                continue;
            }
            break;
        }
        char ip[INET_ADDRSTRLEN] = "unknown";
        inet_ntop(AF_INET, &peer.sin_addr, ip, sizeof(ip));
        char line[160];
        snprintf(line, sizeof(line), "Child connection from %s:%u", ip, ntohs(peer.sin_port));
        log_msg(line);
        const char ident[] = "SSH-2.0-dropbear_" VERSION "\r\n";
        send(cfd, ident, sizeof(ident) - 1, 0);
        unsigned char pkt[] = {
            0x00, 0x00, 0x00, 0x0c, 0x08, 0x14, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0
        };
        send(cfd, pkt, sizeof(pkt), 0);
        close(cfd);
        snprintf(line, sizeof(line), "Exit before auth from <%s:%u>: Exited normally", ip, ntohs(peer.sin_port));
        log_msg(line);
    }
    log_msg("Early exit: Terminated by signal");
}

int main(int argc, char **argv) {
    bool create_keys = false;
    bool foreground = false;
    bool inetd_mode = false;
    const char *key_paths[10];
    int key_count = 0;
    char addr[128] = "";
    int port = 22;
    const char *pidfile = DEFAULT_PIDFILE;

    if (argc == 2 && strcmp(argv[1], "-V") == 0) {
        printf("Dropbear v%s\n", VERSION);
        return 0;
    }

    for (int i = 1; i < argc; i++) {
        if (argv[i][0] != '-' || argv[i][1] == '\0') {
            continue;
        }
        if (strcmp(argv[i], "--") == 0 || strncmp(argv[i], "--", 2) == 0) {
            fprintf(stderr, "Invalid option --\n");
            print_help(argv[0]);
            return 1;
        }
        for (int pos = 1; argv[i][pos] != '\0'; pos++) {
            char opt = argv[i][pos];
            const char *arg = NULL;
            switch (opt) {
            case 'V':
                printf("Dropbear v%s\n", VERSION);
                return 0;
            case 'h':
                print_help(argv[0]);
                return 0;
            case 'R':
                create_keys = true;
                break;
            case 'F':
                foreground = true;
                break;
            case 'i':
                inetd_mode = true;
                break;
            case 'e': case 'm': case 'w': case 's': case 'g': case 'B':
            case 't': case 'j': case 'k': case 'a': case 'z':
                break;
            case 'b': case 'D': case 'G': case 'c': case 'l':
                arg = need_arg(&i, &pos, argc, argv);
                if (!arg) {
                    log_msg("Early exit: Missing argument");
                    return 1;
                }
                break;
            case 'r':
                arg = need_arg(&i, &pos, argc, argv);
                if (!arg) {
                    log_msg("Early exit: Missing argument");
                    return 1;
                }
                if (key_count < 10) {
                    key_paths[key_count++] = arg;
                }
                break;
            case 'P':
                arg = need_arg(&i, &pos, argc, argv);
                if (!arg) {
                    log_msg("Early exit: Missing argument");
                    return 1;
                }
                pidfile = arg;
                break;
            case 'p':
                arg = need_arg(&i, &pos, argc, argv);
                if (!arg) {
                    log_msg("Early exit: Missing argument");
                    return 1;
                }
                parse_listen(arg, addr, sizeof(addr), &port);
                break;
            case 'T':
                arg = need_arg(&i, &pos, argc, argv);
                if (!arg) {
                    log_msg("Early exit: Missing argument");
                    return 1;
                }
                if (!is_number(arg)) {
                    char msg[256];
                    snprintf(msg, sizeof(msg), "Early exit: Bad maxauthtries '%s'", arg);
                    log_msg(msg);
                    return 1;
                }
                break;
            case 'K':
                arg = need_arg(&i, &pos, argc, argv);
                if (!arg) {
                    log_msg("Early exit: Missing argument");
                    return 1;
                }
                if (!is_number(arg)) {
                    char msg[256];
                    snprintf(msg, sizeof(msg), "Early exit: Bad keepalive '%s'", arg);
                    log_msg(msg);
                    return 1;
                }
                break;
            case 'I':
                arg = need_arg(&i, &pos, argc, argv);
                if (!arg) {
                    log_msg("Early exit: Missing argument");
                    return 1;
                }
                if (!is_number(arg)) {
                    char msg[256];
                    snprintf(msg, sizeof(msg), "Early exit: Bad idle_timeout '%s'", arg);
                    log_msg(msg);
                    return 1;
                }
                break;
            case 'W':
                arg = need_arg(&i, &pos, argc, argv);
                if (!arg) {
                    log_msg("Early exit: Missing argument");
                    return 1;
                }
                if (!is_number(arg) || strtol(arg, NULL, 10) <= 0) {
                    char msg[256];
                    snprintf(msg, sizeof(msg), "Bad recv window '%s', using 24576", arg);
                    log_msg(msg);
                } else if (strtol(arg, NULL, 10) > 10485760) {
                    char msg[256];
                    snprintf(msg, sizeof(msg), "Bad recv window '%s', using 10485760", arg);
                    log_msg(msg);
                }
                break;
            default:
                fprintf(stderr, "Invalid option -%c\n", opt);
                print_help(argv[0]);
                return 1;
            }
        }
    }

    if (inetd_mode) {
        const char ident[] = "SSH-2.0-dropbear_" VERSION "\r\n";
        ssize_t ignored = write(STDOUT_FILENO, ident, sizeof(ident) - 1);
        (void)ignored;
        return 0;
    }

    if (!create_keys) {
        if (key_count > 0) {
            for (int i = 0; i < key_count; i++) {
                if (access(key_paths[i], R_OK) == 0) {
                    log_msg("Early exit: Bad buf_getptr");
                    return 1;
                }
                log_fmt("Failed loading ", key_paths[i]);
            }
        } else {
            log_msg("Failed loading /etc/dropbear/dropbear_rsa_host_key");
            log_msg("Failed loading /etc/dropbear/dropbear_ecdsa_host_key");
            log_msg("Failed loading /etc/dropbear/dropbear_ed25519_host_key");
        }
        log_msg("Early exit: No hostkeys available. 'dropbear -R' may be useful or run dropbearkey.");
        return 1;
    }

    int fd = make_listener(addr, port);
    if (fd < 0) {
        return 1;
    }

    if (!foreground) {
        pid_t pid = fork();
        if (pid < 0) {
            log_fmt("Early exit: ", strerror(errno));
            close(fd);
            return 1;
        }
        if (pid > 0) {
            FILE *pf = fopen(pidfile, "w");
            if (pf) {
                fprintf(pf, "%ld\n", (long)pid);
                fclose(pf);
            }
            close(fd);
            return 0;
        }
        setsid();
    } else {
        log_msg("Not backgrounding");
    }

    serve_loop(fd);
    close(fd);
    return 0;
}
