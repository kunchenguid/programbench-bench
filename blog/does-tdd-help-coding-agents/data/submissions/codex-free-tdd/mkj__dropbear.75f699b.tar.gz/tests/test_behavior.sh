#!/bin/bash
set -euo pipefail

cd "$(dirname "$0")/.."
rm -f executable
chmod +x ./compile.sh
./compile.sh

fail() {
  echo "FAIL: $*" >&2
  exit 1
}

out="$(./executable -V)"
[[ "$out" == "Dropbear v2025.89" ]] || fail "version output: $out"

set +e
help_out="$(./executable --help 2>&1)"
help_status=$?
set -e
[[ "$help_status" -eq 1 ]] || fail "--help status $help_status"
[[ "$help_out" == *"Invalid option --"* ]] || fail "--help missing invalid-option line"
[[ "$help_out" == *"Dropbear server v2025.89 https://matt.ucc.asn.au/dropbear/dropbear.html"* ]] || fail "help missing banner"
[[ "$help_out" == *"-W <receive_window_buffer> (default 24576, larger may be faster, max 10MB)"* ]] || fail "help missing -W line"

set +e
missing="$(./executable -p 2>&1)"
missing_status=$?
set -e
[[ "$missing_status" -eq 1 ]] || fail "missing arg status $missing_status"
[[ "$missing" =~ Early\ exit:\ Missing\ argument ]] || fail "missing arg output: $missing"

set +e
bad_t="$(./executable -T abc 2>&1)"
bad_t_status=$?
set -e
[[ "$bad_t_status" -eq 1 ]] || fail "bad -T status $bad_t_status"
[[ "$bad_t" =~ Early\ exit:\ Bad\ maxauthtries\ \'abc\' ]] || fail "bad -T output: $bad_t"

set +e
no_keys="$(./executable -F 2>&1)"
no_keys_status=$?
set -e
[[ "$no_keys_status" -eq 1 ]] || fail "no keys status $no_keys_status"
[[ "$no_keys" == *"Failed loading /etc/dropbear/dropbear_rsa_host_key"* ]] || fail "missing rsa load failure"
[[ "$no_keys" == *"No hostkeys available. 'dropbear -R' may be useful or run dropbearkey."* ]] || fail "missing no-hostkeys message"

set +e
custom_key="$(./executable -r /tmp/definitely-missing-dropbear-key -F 2>&1)"
custom_key_status=$?
set -e
[[ "$custom_key_status" -eq 1 ]] || fail "custom key status $custom_key_status"
[[ "$custom_key" == *"Failed loading /tmp/definitely-missing-dropbear-key"* ]] || fail "custom key output: $custom_key"
[[ "$custom_key" != *"dropbear_rsa_host_key"* ]] || fail "custom key should suppress default key paths"

bad_key_file="$(mktemp)"
printf 'not a dropbear host key\n' > "$bad_key_file"
set +e
bad_key="$(./executable -r "$bad_key_file" -F 2>&1)"
bad_key_status=$?
set -e
rm -f "$bad_key_file"
[[ "$bad_key_status" -eq 1 ]] || fail "bad key status $bad_key_status"
[[ "$bad_key" =~ Early\ exit:\ Bad\ buf_getptr ]] || fail "bad key output: $bad_key"

port=22989
rm -f /tmp/reimpl-dropbear.log
./executable -R -F -p 127.0.0.1:${port} >/tmp/reimpl-dropbear.log 2>&1 &
pid=$!
cleanup() {
  kill "$pid" 2>/dev/null || true
  wait "$pid" 2>/dev/null || true
}
trap cleanup EXIT
for _ in {1..30}; do
  if (echo >/dev/tcp/127.0.0.1/${port}) >/dev/null 2>&1; then
    break
  fi
  sleep 0.1
done
banner="$(timeout 2 bash -lc "exec 3<>/dev/tcp/127.0.0.1/${port}; IFS= read -r line <&3; printf '%s' \"\$line\"" || true)"
[[ "$banner" == $'SSH-2.0-dropbear_2025.89\r' ]] || fail "server banner: $(printf '%q' "$banner")"
grep -q "Not backgrounding" /tmp/reimpl-dropbear.log || fail "server log missing foreground line"

echo "all behavior tests passed"
