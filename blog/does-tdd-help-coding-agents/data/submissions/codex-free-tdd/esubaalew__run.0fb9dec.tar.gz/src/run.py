#!/usr/bin/env python3
import os
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path


HELP = """Universal multi-language runner and REPL

Usage: executable [OPTIONS] [ARGS]...

Arguments:
  [ARGS]...  Positional arguments (language, code, or file)

Options:
  -V, --version      Print version information and exit
  -l, --lang <LANG>  Explicitly choose the language to execute
  -f, --file <PATH>  Execute code from the provided file path
  -c, --code <CODE>  Execute the provided code snippet
      --no-detect    Disable heuristic language detection
  -h, --help         Print help
"""

VERSION = """run-kit 0.3.2
Universal multi-language runner and smart REPL
author: Esubalew Chekol <esubalewchekol6@gmail.com>
homepage: https://esubalew.et
repository: https://github.com/Esubaalew/run
license: Apache-2.0
commit: 0050c88 (2026-03-03T12:39:28-08:00, dirty: dirty)
built: 2026-04-17T19:59:44.418829299+00:00 [release for x86_64-unknown-linux-gnu]
rustc: rustc 1.92.0 (ded5c06cf 2025-12-08)
"""

AVAILABLE = (
    "bash, c, cpp, crystal, csharp, dart, elixir, go, groovy, haskell, java, "
    "javascript, julia, kotlin, lua, nim, perl, php, python, r, ruby, rust, "
    "swift, typescript, zig"
)

ALIASES = {
    "py": "python",
    "python": "python",
    "python3": "python",
    "js": "javascript",
    "javascript": "javascript",
    "node": "javascript",
    "ts": "typescript",
    "typescript": "typescript",
    "bash": "bash",
    "sh": "bash",
    "shell": "bash",
    "ruby": "ruby",
    "rb": "ruby",
    "go": "go",
    "golang": "go",
    "rust": "rust",
    "rs": "rust",
    "c": "c",
    "cpp": "cpp",
    "c++": "cpp",
    "cc": "cpp",
    "lua": "lua",
    "perl": "perl",
    "php": "php",
}

EXT_LANG = {
    ".py": "python",
    ".js": "javascript",
    ".mjs": "javascript",
    ".ts": "typescript",
    ".sh": "bash",
    ".bash": "bash",
    ".rb": "ruby",
    ".go": "go",
    ".rs": "rust",
    ".c": "c",
    ".h": "c",
    ".cpp": "cpp",
    ".cc": "cpp",
    ".cxx": "cpp",
    ".lua": "lua",
    ".pl": "perl",
    ".php": "php",
}


def eprint(text):
    sys.stderr.write(text)


def normalize(lang):
    key = (lang or "").lower()
    return ALIASES.get(key)


def parse(argv):
    opts = {"lang": None, "file": None, "code": None, "no_detect": False}
    pos = []
    i = 0
    while i < len(argv):
        arg = argv[i]
        if arg == "--":
            pos.extend(argv[i + 1 :])
            break
        if arg in ("-h", "--help"):
            print(HELP, end="")
            raise SystemExit(0)
        if arg in ("-V", "--version"):
            print(VERSION, end="")
            raise SystemExit(0)
        if arg in ("-l", "--lang", "-f", "--file", "-c", "--code"):
            if i + 1 >= len(argv):
                names = {
                    "-l": "--lang <LANG>",
                    "--lang": "--lang <LANG>",
                    "-f": "--file <PATH>",
                    "--file": "--file <PATH>",
                    "-c": "--code <CODE>",
                    "--code": "--code <CODE>",
                }
                eprint(
                    f"error: a value is required for '{names[arg]}' but none was supplied\n\n"
                    "For more information, try '--help'.\n"
                )
                raise SystemExit(2)
            key = {"-l": "lang", "--lang": "lang", "-f": "file", "--file": "file", "-c": "code", "--code": "code"}[arg]
            opts[key] = argv[i + 1]
            i += 2
            continue
        if arg == "--no-detect":
            opts["no_detect"] = True
            i += 1
            continue
        if arg.startswith("-"):
            eprint(
                f"error: unexpected argument '{arg}' found\n\n"
                f"  tip: to pass '{arg}' as a value, use '-- {arg}'\n\n"
                "Usage: executable [OPTIONS] [ARGS]...\n\n"
                "For more information, try '--help'.\n"
            )
            raise SystemExit(2)
        pos.append(arg)
        i += 1
    return opts, pos


def choose_lang_for_file(path):
    suffix = Path(path).suffix.lower()
    if suffix in EXT_LANG:
        return EXT_LANG[suffix]
    return "python"


def detect_snippet(code):
    stripped = code.lstrip()
    if stripped.startswith("console.") or "console.log" in stripped:
        return "javascript"
    if stripped.startswith("echo ") or stripped.startswith("printf ") or stripped.startswith("#!/bin/sh") or stripped.startswith("#!/usr/bin/env bash"):
        return "bash"
    if stripped.startswith("puts ") or stripped.startswith("p "):
        return "ruby"
    if stripped.startswith("print("):
        return "lua"
    if stripped.startswith("package main"):
        return "go"
    if stripped.startswith("fn main") or stripped.startswith("use "):
        return "rust"
    if stripped.startswith("#include"):
        return "c"
    return "python"


def run_subprocess(cmd):
    try:
        return subprocess.call(cmd)
    except FileNotFoundError:
        eprint(f"Error: executable '{cmd[0]}' not found\n")
        return 1


def run_temp_compiler(lang, code):
    with tempfile.TemporaryDirectory(prefix=f"run-{lang}") as tmp:
        tmp_path = Path(tmp)
        if lang == "c":
            source = tmp_path / "main.c"
            program = tmp_path / "main"
            if "main(" in code:
                source.write_text(code)
            else:
                source.write_text("#include <stdio.h>\nint main(void) {\n    " + code + "\n    return 0;\n}\n")
            rc = run_subprocess(["gcc", str(source), "-o", str(program)])
            return rc if rc else run_subprocess([str(program)])
        if lang == "cpp":
            source = tmp_path / "main.cpp"
            program = tmp_path / "main"
            source.write_text(code)
            rc = run_subprocess(["g++", str(source), "-o", str(program)])
            return rc if rc else run_subprocess([str(program)])
        if lang == "rust":
            source = tmp_path / "main.rs"
            program = tmp_path / "main"
            source.write_text(code)
            rc = run_subprocess(["rustc", str(source), "-o", str(program)])
            return rc if rc else run_subprocess([str(program)])
        if lang == "go":
            source = tmp_path / "main.go"
            source.write_text(code)
            return run_subprocess(["go", "run", str(source)])
    return 1


def execute(lang, code=None, file_path=None):
    if not lang:
        lang = choose_lang_for_file(file_path) if file_path else detect_snippet(code or "")
    lang = normalize(lang) or lang
    if normalize(lang) is None and lang not in set(ALIASES.values()):
        eprint(f"Error: Unknown language '{lang}'. Available languages: {AVAILABLE}\n")
        return 1
    if lang == "lua":
        if shutil.which("lua") is None:
            eprint("Error: Lua support requires the `lua` executable. Install it from https://www.lua.org/download.html and ensure it is on your PATH.\n")
            return 1
        return run_subprocess(["lua", file_path] if file_path else ["lua", "-e", code])
    if lang == "python":
        return run_subprocess(["python3", file_path] if file_path else ["python3", "-c", code or ""])
    if lang == "javascript":
        return run_subprocess(["node", file_path] if file_path else ["node", "-e", code or ""])
    if lang == "typescript":
        return run_subprocess(["ts-node", file_path] if file_path else ["ts-node", "-e", code or ""])
    if lang == "bash":
        return run_subprocess(["bash", file_path] if file_path else ["bash", "-c", code or ""])
    if lang == "ruby":
        return run_subprocess(["ruby", file_path] if file_path else ["ruby", "-e", code or ""])
    if lang == "perl":
        return run_subprocess(["perl", file_path] if file_path else ["perl", "-e", code or ""])
    if lang == "php":
        return run_subprocess(["php", file_path] if file_path else ["php", "-r", code or ""])
    if file_path and lang in ("c", "cpp", "go", "rust"):
        return run_temp_compiler(lang, Path(file_path).read_text())
    if lang in ("c", "cpp", "go", "rust"):
        return run_temp_compiler(lang, code or "")
    eprint(f"Error: Unknown language '{lang}'. Available languages: {AVAILABLE}\n")
    return 1


def main(argv):
    opts, pos = parse(argv)
    lang = normalize(opts["lang"]) if opts["lang"] else None
    if opts["lang"] and not lang:
        eprint(f"Error: Unknown language '{opts['lang']}'. Available languages: {AVAILABLE}\n")
        return 1
    if opts["code"] is not None:
        if pos:
            eprint("Error: Unexpected positional arguments after specifying --code\n")
            return 1
        return execute(lang, code=opts["code"])
    if opts["file"] is not None:
        if pos:
            eprint("Error: Unexpected positional arguments when --file is present\n")
            return 1
        return execute(lang, file_path=opts["file"])
    if not pos:
        return 0
    first_lang = normalize(pos[0])
    if first_lang:
        return execute(first_lang, code=" ".join(pos[1:]))
    if len(pos) == 1:
        candidate = pos[0]
        suffix = Path(candidate).suffix.lower()
        if suffix in EXT_LANG or Path(candidate).exists():
            return execute(lang, file_path=candidate)
    return execute(lang, code=" ".join(pos))


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
