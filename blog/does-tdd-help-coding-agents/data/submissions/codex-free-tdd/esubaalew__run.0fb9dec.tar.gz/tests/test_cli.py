#!/usr/bin/env python3
import os
import subprocess
import tempfile
import textwrap
import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
EXE = ROOT / "executable"


def run_cmd(*args, input_text=None):
    return subprocess.run(
        [str(EXE), *args],
        input=input_text,
        text=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        cwd=ROOT,
    )


class RunCliTests(unittest.TestCase):
    def test_help_matches_documented_options(self):
        result = run_cmd("--help")
        self.assertEqual(result.returncode, 0)
        self.assertIn("Universal multi-language runner and REPL", result.stdout)
        self.assertIn("Usage: executable [OPTIONS] [ARGS]...", result.stdout)
        self.assertIn("-l, --lang <LANG>", result.stdout)
        self.assertIn("-c, --code <CODE>", result.stdout)

    def test_version_prints_metadata(self):
        result = run_cmd("--version")
        self.assertEqual(result.returncode, 0)
        self.assertIn("run-kit 0.3.2", result.stdout)
        self.assertIn("license: Apache-2.0", result.stdout)

    def test_python_code_receives_stdin(self):
        result = run_cmd(
            "--lang",
            "python",
            "--code",
            "import sys; print(sys.stdin.read().strip().upper())",
            input_text="Hello\n",
        )
        self.assertEqual(result.returncode, 0)
        self.assertEqual(result.stdout, "HELLO\n")
        self.assertEqual(result.stderr, "")

    def test_first_positional_language_executes_code(self):
        result = run_cmd("python", "print(456)")
        self.assertEqual(result.returncode, 0)
        self.assertEqual(result.stdout, "456\n")

    def test_file_extension_dispatches_python_and_javascript(self):
        with tempfile.TemporaryDirectory() as tmp:
            py_file = Path(tmp) / "sample.py"
            js_file = Path(tmp) / "sample.js"
            py_file.write_text('print("pyfile")\n')
            js_file.write_text('console.log("jsfile")\n')

            py_result = run_cmd(str(py_file))
            js_result = run_cmd(str(js_file))

        self.assertEqual(py_result.returncode, 0)
        self.assertEqual(py_result.stdout, "pyfile\n")
        self.assertEqual(js_result.returncode, 0)
        self.assertEqual(js_result.stdout, "jsfile\n")

    def test_unknown_language_reports_available_languages(self):
        result = run_cmd("--lang", "bogus", "--code", "x")
        self.assertEqual(result.returncode, 1)
        self.assertIn("Error: Unknown language 'bogus'.", result.stderr)
        self.assertIn("Available languages: bash, c, cpp", result.stderr)

    def test_positional_args_after_code_are_rejected(self):
        result = run_cmd("--lang", "python", "--code", "print(1)", "extra")
        self.assertEqual(result.returncode, 1)
        self.assertEqual(
            result.stderr, "Error: Unexpected positional arguments after specifying --code\n"
        )


if __name__ == "__main__":
    unittest.main()
