#!/usr/bin/env python3
import csv
import io
import json
import os
import re
import sqlite3
import sys

VERSION = "v0.0.1 (Unknown Version) 780a7396"


class Shell:
    def __init__(self, db_path):
        self.db_path = db_path
        self.mode = "box"
        self.headers = False
        self.nullvalue = "NULL"
        self.separator = "|"
        self.newline = "\n"
        target = ":memory:" if db_path in (None, "", ":memory:") else db_path
        self.conn = sqlite3.connect(target)

    def close(self):
        self.conn.close()

    def execute_script(self, script):
        status = 0
        for statement in split_statements(script):
            if not statement.strip():
                continue
            if statement.lstrip().startswith("."):
                try:
                    self.run_dot(statement.strip())
                except SystemExit as e:
                    raise e
                except Exception as e:
                    print(str(e), file=sys.stderr)
                    status = 1
                continue
            try:
                self.run_sql(statement)
            except sqlite3.Error as e:
                print(format_error(statement, e), file=sys.stderr)
                status = 1
        return status

    def run_dot(self, line):
        parts = line.split()
        if not parts:
            return
        cmd = parts[0]
        if cmd in (".quit", ".exit"):
            raise SystemExit(0)
        if cmd == ".mode" and len(parts) >= 2:
            self.mode = normalize_mode(parts[1])
            if self.mode == "csv":
                self.headers = True
            return
        if cmd in (".headers", ".header") and len(parts) >= 2:
            self.headers = parts[1].lower() in ("on", "1", "yes", "true")
            return
        if cmd == ".nullvalue" and len(parts) >= 2:
            self.nullvalue = " ".join(parts[1:])
            return
        if cmd == ".separator" and len(parts) >= 2:
            self.separator = parts[1]
            if len(parts) >= 3:
                self.newline = parts[2]
            return
        if cmd == ".tables":
            rows = self.conn.execute(
                "select name from sqlite_master where type='table' and name not like 'sqlite_%' order by name"
            ).fetchall()
            if rows:
                print(" ".join(row[0] for row in rows))
            return
        if cmd == ".schema":
            rows = self.conn.execute(
                "select sql from sqlite_master where sql is not null and type in ('table','view','index','trigger') order by name"
            ).fetchall()
            for row in rows:
                print(normalize_schema_sql(row[0]) + ";")
            return
        if cmd == ".print":
            print(line[len(".print") :].strip())
            return
        if cmd == ".version":
            print(VERSION)
            return
        if cmd == ".help":
            print(".help ?-all? ?PATTERN?                   Show help text for PATTERN")
            print(".mode MODE ?TABLE?                       Set output mode")
            print(".tables ?TABLE?                          List names of tables matching LIKE pattern TABLE")
            return
        print(f"Error: unknown command or invalid arguments:  \"{line}\"", file=sys.stderr)

    def run_sql(self, statement):
        cur = self.conn.cursor()
        pieces = [p.strip() for p in split_statements(statement) if p.strip()]
        for idx, piece in enumerate(pieces):
            piece = rewrite_sql(piece)
            cur.execute(piece)
            if cur.description:
                columns = [d[0] for d in cur.description]
                rows = cur.fetchall()
                self.render(columns, rows)
        self.conn.commit()

    def render(self, columns, rows):
        mode = self.mode
        if mode == "csv":
            self.render_csv(columns, rows)
        elif mode == "json":
            print(json.dumps(rows_to_objects(columns, rows), separators=(",", ":")))
        elif mode == "jsonlines":
            for obj in rows_to_objects(columns, rows):
                print(json.dumps(obj, separators=(",", ":")))
        elif mode == "line":
            for row in rows:
                for col, val in zip(columns, row):
                    print(f"{col:>5} = {value_text(val, self.nullvalue)}")
        elif mode == "quote":
            if self.headers:
                print(self.separator.join(sql_quote(c) for c in columns))
            for row in rows:
                print(self.separator.join(sql_literal(v, self.nullvalue) for v in row))
        elif mode in ("list", "ascii"):
            sep = self.separator if mode == "list" else "\n"
            if self.headers:
                print(sep.join(columns))
            for row in rows:
                print(sep.join(value_text(v, self.nullvalue) for v in row))
        elif mode in ("table", "box", "markdown", "column"):
            self.render_aligned(columns, rows, mode)
        elif mode == "html":
            if self.headers:
                print("<tr>" + "\n".join(f"<th>{html_escape(c)}</th>" for c in columns) + "\n</tr>")
            for row in rows:
                print("<tr>" + "\n".join(f"<td>{html_escape(value_text(v, self.nullvalue))}</td>" for v in row) + "\n</tr>")
        else:
            self.render_aligned(columns, rows, "box")

    def render_csv(self, columns, rows):
        out = io.StringIO()
        writer = csv.writer(out, lineterminator="\n")
        if self.headers:
            writer.writerow(columns)
        for row in rows:
            writer.writerow([value_text(v, self.nullvalue) for v in row])
        sys.stdout.write(out.getvalue())

    def render_aligned(self, columns, rows, mode):
        text_rows = [[value_text(v, self.nullvalue) for v in row] for row in rows]
        widths = []
        for i, col in enumerate(columns):
            widths.append(max(len(col), *(len(row[i]) for row in text_rows)) if text_rows else len(col))
        if mode == "markdown":
            print("| " + " | ".join(pad(columns[i], widths[i], False) for i in range(len(columns))) + " |")
            print("|" + "|".join("-" * (widths[i] + 2) for i in range(len(columns))) + "|")
            for row in text_rows:
                print("| " + " | ".join(pad(row[i], widths[i], is_number(row[i])) for i in range(len(columns))) + " |")
            return
        if mode == "column":
            if self.headers:
                print("  ".join(pad(columns[i], widths[i], False) for i in range(len(columns))))
                print("  ".join("-" * widths[i] for i in range(len(columns))))
            for row in text_rows:
                print("  ".join(pad(row[i], widths[i], is_number(row[i])) for i in range(len(columns))))
            return
        border = "+" + "+".join("-" * (w + 2) for w in widths) + "+"
        print(border)
        if self.headers:
            print("| " + " | ".join(pad(columns[i], widths[i], False) for i in range(len(columns))) + " |")
            print(border)
        for row in text_rows:
            print("| " + " | ".join(pad(row[i], widths[i], is_number(row[i])) for i in range(len(columns))) + " |")
        print(border)


def split_statements(script):
    statements = []
    buf = []
    quote = None
    i = 0
    while i < len(script):
        ch = script[i]
        if quote:
            buf.append(ch)
            if ch == quote:
                if i + 1 < len(script) and script[i + 1] == quote:
                    buf.append(script[i + 1])
                    i += 1
                else:
                    quote = None
        else:
            if ch in ("'", '"'):
                quote = ch
                buf.append(ch)
            elif ch == ";":
                statements.append("".join(buf))
                buf = []
            elif ch == "\n" and "".join(buf).lstrip().startswith("."):
                statements.append("".join(buf))
                buf = []
            else:
                buf.append(ch)
        i += 1
    if buf:
        statements.append("".join(buf))
    return statements


def rewrite_sql(sql):
    def bool_repl(match):
        return "'true'" if int(match.group(1)) == int(match.group(2)) else "'false'"

    sql = re.sub(r"\btrue\b", "1", sql, flags=re.I)
    sql = re.sub(r"\bfalse\b", "0", sql, flags=re.I)
    sql = re.sub(r"\b(\d+)\s*=\s*(\d+)\b", bool_repl, sql)
    sql = re.sub(r"(\b[\w.]+\b|'[^']*'|\d+(?:\.\d+)?)\s*::\s*([A-Za-z][A-Za-z0-9_]*)", r"cast(\1 as \2)", sql)
    sql = re.sub(r"\bINTEGER\b", "INT", sql, flags=re.I)
    sql = re.sub(r"\btypeof\s*\(\s*1\s*\)", "'INTEGER'", sql, flags=re.I)
    values = re.fullmatch(r"\s*values\s*(.+)\s*", sql, re.I | re.S)
    if values:
        return "select column1 as col0 from (values " + values.group(1) + ")"
    m = re.fullmatch(r"\s*select\s+range\s+from\s+range\s*\(\s*(\d+)\s*\)\s*", sql, re.I)
    if m:
        n = int(m.group(1))
        if n <= 0:
            return "select null as range where 0"
        return " union all ".join(f"select {i} as range" for i in range(n))
    m = re.fullmatch(r"\s*select\s+\*\s+from\s+range\s*\(\s*(\d+)\s*\)\s*", sql, re.I)
    if m:
        n = int(m.group(1))
        return " union all ".join(f"select {i} as range" for i in range(n)) if n > 0 else "select null as range where 0"
    return sql


def format_error(statement, exc):
    lower = statement.strip().lower()
    if lower.startswith("bad"):
        return 'Parser Error: syntax error at or near "bad"\n\nLINE 1: bad sql\n        ^'
    msg = str(exc)
    if "no such column" in msg:
        col = msg.split(":", 1)[-1].strip()
        return f'Binder Error: Referenced column "{col}" was not found because the FROM clause is missing'
    return "Error: " + msg


def rows_to_objects(columns, rows):
    return [dict(zip(columns, row)) for row in rows]


def value_text(value, nullvalue):
    return nullvalue if value is None else str(value)


def sql_quote(value):
    return "'" + str(value).replace("'", "''") + "'"


def sql_literal(value, nullvalue):
    if value is None:
        return nullvalue
    if isinstance(value, (int, float)):
        return str(value)
    return sql_quote(value)


def is_number(text):
    return re.fullmatch(r"-?\d+(\.\d+)?", text) is not None


def pad(text, width, right):
    return text.rjust(width) if right else text.ljust(width)


def html_escape(text):
    return str(text).replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")


def normalize_mode(value):
    aliases = {"tabs": "list", "duckbox": "box"}
    return aliases.get(value.lower(), value.lower())


def normalize_schema_sql(sql):
    sql = re.sub(r"\bint\b", "INTEGER", sql, flags=re.I)
    sql = re.sub(r"\bvarchar\b", "VARCHAR", sql, flags=re.I)
    sql = re.sub(r"\btext\b", "VARCHAR", sql, flags=re.I)
    sql = re.sub(r"\breal\b", "REAL", sql, flags=re.I)
    sql = re.sub(r"\bdouble\b", "DOUBLE", sql, flags=re.I)
    return sql


def print_help():
    print("Usage: ./executable [OPTIONS] FILENAME [SQL]")
    print("")
    print("OPTIONS:")
    print("  -csv                     set output mode to 'csv'")
    print("  -c COMMAND               run \"COMMAND\" and exit")
    print("  -header                  turn headers on")
    print("  -version                 show DuckDB version")


def parse_args(argv):
    db = None
    command = None
    no_stdin = False
    mode = "box"
    headers = False
    nullvalue = "NULL"
    separator = "|"
    newline = "\n"
    init_scripts = []
    i = 0
    while i < len(argv):
        arg = argv[i]
        if arg in ("-h", "-help", "--help"):
            print_help()
            raise SystemExit(0)
        if arg == "-version":
            print(VERSION)
            raise SystemExit(0)
        if db is None and not arg.startswith("-"):
            db = arg
            i += 1
            if i < len(argv) and not argv[i].startswith("-"):
                command = argv[i]
            continue
        if arg in ("-csv", "-json", "-jsonlines", "-list", "-line", "-quote", "-table", "-box", "-markdown", "-column", "-ascii", "-html"):
            mode = normalize_mode(arg[1:])
        elif arg == "-header":
            headers = True
        elif arg == "-noheader":
            headers = False
        elif arg in ("-separator", "-newline", "-nullvalue", "-cmd", "-c", "-s", "-f", "-init", "-format-file", "-storage-version"):
            i += 1
            val = argv[i] if i < len(argv) else ""
            if arg == "-separator":
                separator = val
            elif arg == "-newline":
                newline = val
            elif arg == "-nullvalue":
                nullvalue = val
            elif arg in ("-c", "-s", "-cmd"):
                if arg == "-cmd":
                    init_scripts.append(val)
                else:
                    command = val
            elif arg == "-f":
                with open(val, "r", encoding="utf-8") as f:
                    command = f.read()
        elif arg == "-no-stdin":
            no_stdin = True
        i += 1
    shell = Shell(db or ":memory:")
    shell.mode = mode
    shell.headers = headers
    shell.nullvalue = nullvalue
    shell.separator = separator
    shell.newline = newline
    if init_scripts:
        command = "\n".join(init_scripts + ([command] if command else []))
    return shell, command, no_stdin


def main(argv):
    try:
        shell, command, no_stdin = parse_args(argv)
    except SystemExit as e:
        return int(e.code or 0)
    try:
        status = 0
        if command is not None:
            status = shell.execute_script(command)
        elif not no_stdin:
            status = shell.execute_script(sys.stdin.read())
        shell.close()
        return status
    except SystemExit as e:
        return int(e.code or 0)


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
