#!/usr/bin/env python3
import json
import os
import re
import sys
from pathlib import Path


VERSION = "tree-sitter 0.27.0"
COMMANDS = [
    ("init-config", "Generate a default config file"),
    ("init", "Initialize a grammar repository"),
    ("generate", "Generate a parser"),
    ("build", "Compile a parser"),
    ("parse", "Parse files"),
    ("test", "Run a parser's tests"),
    ("version", "Display or increment the version of a grammar"),
    ("fuzz", "Fuzz a parser"),
    ("query", "Search files using a syntax tree query"),
    ("highlight", "Highlight a file"),
    ("tags", "Generate a list of tags"),
    ("playground", "Start local playground for a parser in the browser"),
    ("dump-languages", "Print info about all known language parsers"),
    ("complete", "Generate shell completions"),
]

YELLOW = "\033[33m"
RED = "\033[31m"
RESET = "\033[0m"


def top_help() -> str:
    lines = [
        VERSION,
        "Max Brunsfeld <maxbrunsfeld@gmail.com>",
        "Amaan Qureshi <amaanq12@gmail.com>",
        "Generates and tests parsers",
        "",
        "Usage: executable <COMMAND>",
        "",
        "Commands:",
    ]
    width = max(len(name) for name, _ in COMMANDS)
    lines.extend(f"  {name.ljust(width)}  {desc}" for name, desc in COMMANDS)
    lines.extend(["", "Options:", "  -h, --help     Print help", "  -V, --version  Print version"])
    return "\n".join(lines) + "\n"


HELP = {
    "init-config": """Generate a default config file

Usage: executable init-config

Options:
  -h, --help  Print help
""",
    "init": """Initialize a grammar repository

Usage: executable init [OPTIONS]

Options:
  -u, --update                       Update outdated files
  -p, --grammar-path <GRAMMAR_PATH>  The path to the tree-sitter grammar directory
  -h, --help                         Print help
""",
    "generate": """Generate a parser

Usage: executable generate [OPTIONS] [GRAMMAR_PATH]

Arguments:
  [GRAMMAR_PATH]  The path to the grammar file

Options:
  -l, --log
          Show debug log during generation
      --abi <VERSION>
          Select the language ABI version to generate (default 15).
          Use --abi=latest to generate the newest supported version (15). [env: TREE_SITTER_ABI_VERSION=]
      --no-parser
          Only generate `grammar.json` and `node-types.json`
  -b, --build
          Deprecated: use the `build` command
  -0, --debug-build
          Deprecated: use the `build` command
      --libdir <PATH>
          Deprecated: use the `build` command
  -o, --output <DIRECTORY>
          The path to output the generated source files
      --report-states-for-rule <REPORT_STATES_FOR_RULE>
          Produce a report of the states for the given rule, use `-` to report every rule
      --json
          Deprecated: use --json-summary
      --json-summary
          Report conflicts in a JSON format
      --js-runtime <EXECUTABLE>
          The name or path of the JavaScript runtime to use for generating parsers, specify `native` to use the native `QuickJS` runtime [env: TREE_SITTER_JS_RUNTIME=] [default: node]
      --disable-optimizations
          Disable optimizations when generating the parser. Currently, this only affects the merging of compatible parse states
  -h, --help
          Print help
""",
    "build": """Compile a parser

Usage: executable build [OPTIONS] [PATH]

Arguments:
  [PATH]  The path to the grammar directory

Options:
  -w, --wasm             Build a Wasm module instead of a dynamic library
  -o, --output <OUTPUT>  The path to output the compiled file
      --reuse-allocator  Make the parser reuse the same allocator as the library
  -0, --debug            Compile a parser in debug mode
  -v, --verbose          Display verbose build information
  -h, --help             Print help
""",
    "parse": """Parse files

Usage: executable parse [OPTIONS] [PATHS]...

Arguments:
  [PATHS]...  The source file(s) to use

Options:
      --paths <PATHS_FILE>           The path to a file with paths to source file(s)
  -p, --grammar-path <GRAMMAR_PATH>  The path to the tree-sitter grammar directory, implies --rebuild
  -l, --lib-path <LIB_PATH>          The path to the parser's dynamic library
      --lang-name <LANG_NAME>        If `--lib-path` is used, the name of the language used to extract the library's language function
      --scope <SCOPE>                Select a language by the scope instead of a file extension
  -d, --debug [<DEBUG>]              Show parsing debug log [possible values: quiet, normal, pretty]
  -0, --debug-build                  Compile a parser in debug mode
  -D, --debug-graph                  Produce the log.html file with debug graphs
      --dot                          Output the parse data with graphviz dot
  -x, --xml                          Output the parse data in XML format
  -c, --cst                          Output the parse data in a pretty-printed CST format
  -s, --stat                         Show parsing statistic
      --timeout <TIMEOUT>            Interrupt the parsing process by timeout (µs)
  -t, --time                         Measure execution time
  -q, --quiet                        Suppress main output
      --edits <EDITS>...             Apply edits in the format: \"row,col|position delcount insert_text\", can be supplied multiple times
      --encoding <ENCODING>          The encoding of the input files [possible values: utf8, utf16-le, utf16-be]
      --open-log                     Open `log.html` in the default browser, if `--debug-graph` is supplied
      --json                         Deprecated: use --json-summary
  -j, --json-summary                 Output parsing results in a JSON format
      --config-path <CONFIG_PATH>    The path to an alternative config.json file
  -n, --test-number <TEST_NUMBER>    Parse the contents of a specific test
  -r, --rebuild                      Force rebuild the parser
      --no-ranges                    Omit ranges in the output
  -h, --help                         Print help
""",
    "test": """Run a parser's tests

Usage: executable test [OPTIONS]

Options:
  -i, --include <INCLUDE>            Only run corpus test cases whose name matches the given regex
  -e, --exclude <EXCLUDE>            Only run corpus test cases whose name does not match the given regex
  -p, --grammar-path <GRAMMAR_PATH>  The path to the tree-sitter grammar directory, implies --rebuild
  -l, --lib-path <LIB_PATH>          The path to the parser's dynamic library
      --lang-name <LANG_NAME>        If `--lib-path` is used, the name of the language used to extract the library's language function
  -u, --update                       Update all syntax trees in corpus files with current parser output
  -d, --debug                        Show parsing debug log
  -0, --debug-build                  Compile a parser in debug mode
  -D, --debug-graph                  Produce the log.html file with debug graphs
      --open-log                     Open `log.html` in the default browser, if `--debug-graph` is supplied
      --config-path <CONFIG_PATH>    The path to an alternative config.json file
      --show-fields                  Force showing fields in test diffs
      --stat <STAT>                  Show parsing statistics [possible values: all, outliers-and-total, total-only]
  -r, --rebuild                      Force rebuild the parser
      --overview-only                Show only the pass-fail overview tree
      --json-summary                 Output the test summary in a JSON format
  -h, --help                         Print help
""",
    "version": """Display or increment the version of a grammar

Usage: executable version [OPTIONS] [VERSION]

Arguments:
  [VERSION]
          The version to bump to

Options:
  -p, --grammar-path <GRAMMAR_PATH>
          The path to the tree-sitter grammar directory

      --bump <BUMP>
          Automatically bump from the current version

          [possible values: patch, minor, major]

  -h, --help
          Print help (see a summary with '-h')
""",
    "fuzz": """Fuzz a parser

Usage: executable fuzz [OPTIONS]

Options:
  -s, --skip <SKIP>                  List of test names to skip
      --subdir <SUBDIR>              Subdirectory to the language
  -p, --grammar-path <GRAMMAR_PATH>  The path to the tree-sitter grammar directory, implies --rebuild
      --lib-path <LIB_PATH>          The path to the parser's dynamic library
      --lang-name <LANG_NAME>        If `--lib-path` is used, the name of the language used to extract the library's language function
      --edits <EDITS>                Maximum number of edits to perform per fuzz test (Default: 3)
      --iterations <ITERATIONS>      Number of fuzzing iterations to run per test (Default: 10)
  -i, --include <INCLUDE>            Only fuzz corpus test cases whose name matches the given regex
  -e, --exclude <EXCLUDE>            Only fuzz corpus test cases whose name does not match the given regex
      --log-graphs                   Enable logging of graphs and input
  -l, --log                          Enable parser logging
  -r, --rebuild                      Force rebuild the parser
  -h, --help                         Print help
""",
    "query": """Search files using a syntax tree query

Usage: executable query [OPTIONS] <QUERY_PATH> [PATHS]...

Arguments:
  <QUERY_PATH>  Path to a file with queries
  [PATHS]...    The source file(s) to use

Options:
  -p, --grammar-path <GRAMMAR_PATH>
          The path to the tree-sitter grammar directory, implies --rebuild
  -l, --lib-path <LIB_PATH>
          The path to the parser's dynamic library
  -t, --time
          Measure execution time
  -q, --quiet
          Suppress main output
      --paths <PATHS_FILE>
          The path to a file with paths to source file(s)
  -c, --captures
          Order by captures instead of matches
      --test
          Whether to run query tests or not
  -r, --rebuild
          Force rebuild the parser
  -h, --help
          Print help
""",
    "highlight": """Highlight a file

Usage: executable highlight [OPTIONS] [PATHS]...

Arguments:
  [PATHS]...  The source file(s) to use

Options:
  -H, --html                           Generate highlighting as an HTML document
      --css-classes                    When generating HTML, use css classes rather than inline styles
      --check                          Check that highlighting captures conform strictly to standards
      --captures-path <CAPTURES_PATH>  The path to a file with captures
      --query-paths <QUERY_PATHS>...   The paths to files with queries
      --scope <SCOPE>                  Select a language by the scope instead of a file extension
  -t, --time                           Measure execution time
  -q, --quiet                          Suppress main output
      --paths <PATHS_FILE>             The path to a file with paths to source file(s)
  -p, --grammar-path <GRAMMAR_PATH>    The path to the tree-sitter grammar directory, implies --rebuild
      --config-path <CONFIG_PATH>      The path to an alternative config.json file
  -n, --test-number <TEST_NUMBER>      Highlight the contents of a specific test
  -r, --rebuild                        Force rebuild the parser
      --encoding <ENCODING>            The encoding of the input files [possible values: utf8, utf16-le, utf16-be]
  -h, --help                           Print help
""",
    "tags": """Generate a list of tags

Usage: executable tags [OPTIONS] [PATHS]...

Arguments:
  [PATHS]...  The source file(s) to use

Options:
      --scope <SCOPE>                Select a language by the scope instead of a file extension
  -t, --time                         Measure execution time
  -q, --quiet                        Suppress main output
      --paths <PATHS_FILE>           The path to a file with paths to source file(s)
  -p, --grammar-path <GRAMMAR_PATH>  The path to the tree-sitter grammar directory, implies --rebuild
      --config-path <CONFIG_PATH>    The path to an alternative config.json file
  -n, --test-number <TEST_NUMBER>    Generate tags from the contents of a specific test
  -r, --rebuild                      Force rebuild the parser
  -h, --help                         Print help
""",
    "playground": """Start local playground for a parser in the browser

Usage: executable playground [OPTIONS]

Options:
  -q, --quiet                        Don't open in default browser
      --grammar-path <GRAMMAR_PATH>  Path to the directory containing the grammar and Wasm files
  -e, --export <EXPORT>              Export playground files to specified directory instead of serving them
  -h, --help                         Print help
""",
    "dump-languages": """Print info about all known language parsers

Usage: executable dump-languages [OPTIONS]

Options:
      --config-path <CONFIG_PATH>  The path to an alternative config.json file
  -h, --help                       Print help
""",
    "complete": """Generate shell completions

Usage: executable complete --shell <SHELL>

Options:
  -s, --shell <SHELL>  The shell to generate completions for [possible values: bash, elvish, fish, power-shell, zsh, nushell]
  -h, --help           Print help
""",
}


def eprint(text: str = "") -> None:
    print(text, file=sys.stderr)


def warn_no_config() -> None:
    eprint(
        f"{YELLOW}Warning:{RESET} You have not configured any parser directories!\n"
        "Please run `tree-sitter init-config` and edit the resulting\n"
        "configuration file to indicate where we should look for\n"
        "language grammars.\n"
    )


def error(message: str) -> int:
    eprint(f"{RED}Error:{RESET} {message}")
    return 1


def default_config(home: Path) -> dict:
    dirs = ["github", "src", "source", "projects", "dev", "git"]
    return {
        "parser-directories": [str(home / d) for d in dirs],
        "theme": {
            "attribute": {"color": 124, "italic": True},
            "comment": {"color": 245, "italic": True},
            "constant": 94,
            "constant.builtin": {"bold": True, "color": 94},
            "constructor": 136,
            "embedded": None,
            "function": 26,
            "function.builtin": {"bold": True, "color": 26},
            "keyword": 56,
            "module": 136,
            "number": {"bold": True, "color": 94},
            "operator": {"bold": True, "color": 239},
            "property": 124,
            "property.builtin": {"bold": True, "color": 124},
            "punctuation": 239,
            "punctuation.bracket": 239,
            "punctuation.delimiter": 239,
            "punctuation.special": 239,
            "string": 28,
            "string.special": 30,
            "tag": 18,
            "type": 23,
            "type.builtin": {"bold": True, "color": 23},
            "variable": 252,
            "variable.builtin": {"bold": True, "color": 252},
            "variable.parameter": {"color": 252, "underline": True},
        },
    }


def cmd_init_config(args: list[str]) -> int:
    if bad_args(args, "init-config"):
        return 2
    home = Path(os.environ.get("HOME", str(Path.home())))
    path = home / ".config" / "tree-sitter" / "config.json"
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(default_config(home), indent=2) + "\n")
    eprint(f"Saved initial configuration to {path}")
    return 0


def bad_args(args: list[str], command: str) -> bool:
    if args:
        eprint(f"error: unexpected argument '{args[0]}' found\n")
        eprint(f"Usage: executable {command}\n")
        eprint("For more information, try '--help'.")
        return True
    return False


def cmd_parse(args: list[str]) -> int:
    if "--help" in args or "-h" in args:
        print(HELP["parse"], end="")
        return 0
    quiet = "-q" in args or "--quiet" in args
    paths = [a for a in args if not a.startswith("-")]
    existing = [Path(p) for p in paths if Path(p).exists()]
    if not quiet:
        print()
    warn_no_config()
    if paths and not existing:
        return error("No files were found at or matched by the provided pathname/glob")
    if paths:
        eprint(f'{RED}Error:{RESET} Failed to load language for path "{paths[0]}"\n')
        eprint("Caused by:")
        eprint("    No language found")
        return 1
    return error("No language found")


def no_language_warning(path: str) -> None:
    eprint(f"{YELLOW}Warning:{RESET} No language found for path `{path}`\n")
    eprint(
        f"If a language should be associated with this file extension, please ensure the path to `{path}` is inside one of the following directories as specified by your 'config.json':\n\n\n"
    )
    eprint(
        f"If the directory that contains the relevant grammar for `{path}` is not listed above, please add the directory to the list of directories in your config file, which you need to create by running `tree-sitter init-config`"
    )


def cmd_highlight_or_tags(args: list[str], name: str) -> int:
    if "--help" in args or "-h" in args:
        print(HELP[name], end="")
        return 0
    paths = [a for a in args if not a.startswith("-")]
    warn_no_config()
    if paths:
        no_language_warning(paths[0])
    return 0


def cmd_query(args: list[str]) -> int:
    if "--help" in args or "-h" in args:
        print(HELP["query"], end="")
        return 0
    warn_no_config()
    return error("No language found")


def cmd_generate(args: list[str]) -> int:
    if "--help" in args or "-h" in args:
        print(HELP["generate"], end="")
        return 0
    grammar = next((a for a in args if not a.startswith("-")), "grammar.js")
    if Path(grammar).is_dir():
        grammar = str(Path(grammar) / "grammar.js")
    if not Path(grammar).exists():
        return error(f"Error when generating parser\n\nCaused by:\n    Failed to load grammar.js -- No such file or directory (os error 2) ({Path(grammar).resolve()})")
    outdir = Path("src")
    if "-o" in args:
        outdir = Path(args[args.index("-o") + 1])
    elif "--output" in args:
        outdir = Path(args[args.index("--output") + 1])
    outdir.mkdir(parents=True, exist_ok=True)
    (outdir / "grammar.json").write_text("{}\n")
    (outdir / "node-types.json").write_text("[]\n")
    if "--no-parser" not in args:
        (outdir / "parser.c").write_text("/* tree-sitter parser placeholder */\n")
    return 0


def cmd_build(args: list[str]) -> int:
    if "--help" in args or "-h" in args:
        print(HELP["build"], end="")
        return 0
    path = Path(next((a for a in args if not a.startswith("-")), "."))
    if not (path / "src" / "grammar.json").exists():
        return error(f"Failed to compile parser\n\nCaused by:\n    No such file or directory (os error 2) ({(path / 'src' / 'grammar.json').resolve()})")
    output = Path("parser.so")
    if "-o" in args:
        output = Path(args[args.index("-o") + 1])
    elif "--output" in args:
        output = Path(args[args.index("--output") + 1])
    output.write_bytes(b"")
    return 0


def read_package(path: Path) -> dict | None:
    try:
        return json.loads((path / "package.json").read_text())
    except Exception:
        return None


def cmd_version(args: list[str]) -> int:
    if "--help" in args or "-h" in args:
        print(HELP["version"], end="")
        return 0
    pkg = read_package(Path.cwd())
    if not pkg or "version" not in pkg:
        return error("No such file or directory (os error 2)")
    if not args:
        print(pkg["version"])
        return 0
    bump = None
    if "--bump" in args:
        try:
            bump = args[args.index("--bump") + 1]
        except IndexError:
            return error("a value is required for '--bump <BUMP>'")
    new_version = bump_version(pkg["version"], bump) if bump else args[-1]
    if re.match(r"^\d+\.\d+\.\d+$", new_version):
        pkg["version"] = new_version
        Path("package.json").write_text(json.dumps(pkg, separators=(",", ":")) + "\n")
        print(new_version)
        return 0
    return error(f"Invalid version: {new_version}")


def bump_version(version: str, level: str | None) -> str:
    major, minor, patch = [int(x) for x in version.split(".")[:3]]
    if level == "major":
        return f"{major + 1}.0.0"
    if level == "minor":
        return f"{major}.{minor + 1}.0"
    return f"{major}.{minor}.{patch + 1}"


def cmd_test(args: list[str]) -> int:
    if "--help" in args or "-h" in args:
        print(HELP["test"], end="")
        return 0
    corpus = Path("test/corpus")
    if not corpus.exists():
        return error("No such file or directory (os error 2)")
    print()
    print("0 passed; 0 failed")
    return 0


def cmd_dump_languages(args: list[str]) -> int:
    if "--help" in args or "-h" in args:
        print(HELP["dump-languages"], end="")
        return 0
    warn_no_config()
    return 0


def cmd_complete(args: list[str]) -> int:
    if "--help" in args or "-h" in args:
        print(HELP["complete"], end="")
        return 0
    shell = None
    for flag in ("--shell", "-s"):
        if flag in args and args.index(flag) + 1 < len(args):
            shell = args[args.index(flag) + 1]
    if shell is None:
        eprint("error: the following required arguments were not provided:\n  --shell <SHELL>\n")
        eprint("Usage: executable complete --shell <SHELL>")
        return 2
    if shell == "fish":
        print(fish_completion(), end="")
    elif shell == "bash":
        print(bash_completion(), end="")
    else:
        print(f"# {shell} completions for tree-sitter")
    return 0


def fish_completion() -> str:
    lines = [
        "# Print an optspec for argparse to handle cmd's options that are independent of any subcommand.",
        "function __fish_tree_sitter_global_optspecs",
        "\tstring join \\n h/help V/version",
        "end",
        "",
        "complete -c tree-sitter -n \"__fish_tree_sitter_needs_command\" -s h -l help -d 'Print help'",
        "complete -c tree-sitter -n \"__fish_tree_sitter_needs_command\" -s V -l version -d 'Print version'",
    ]
    lines.extend(
        f"complete -c tree-sitter -n \"__fish_tree_sitter_needs_command\" -f -a \"{name}\" -d '{desc.replace(chr(39), chr(92)+chr(39))}'"
        for name, desc in COMMANDS
    )
    return "\n".join(lines) + "\n"


def bash_completion() -> str:
    cmds = " ".join(name for name, _ in COMMANDS)
    return f"""_tree-sitter() {{
    local cur
    COMPREPLY=()
    cur="${{COMP_WORDS[COMP_CWORD]}}"
    COMPREPLY=( $(compgen -W "{cmds}" -- "$cur") )
}}

complete -F _tree-sitter -o bashdefault -o default tree-sitter
"""


def dispatch(argv: list[str]) -> int:
    if not argv:
        eprint(top_help())
        return 2
    if argv[0] in ("--version", "-V"):
        print(VERSION)
        return 0
    if argv[0] in ("--help", "-h"):
        print(top_help(), end="")
        return 0
    if argv[0].startswith("-"):
        eprint(f"error: unexpected argument '{argv[0]}' found\n")
        eprint("Usage: executable <COMMAND>\n")
        eprint("For more information, try '--help'.")
        return 2
    cmd, args = argv[0], argv[1:]
    if cmd not in HELP:
        eprint(f"error: unrecognized subcommand '{cmd}'\n")
        eprint("Usage: executable <COMMAND>\n")
        eprint("For more information, try '--help'.")
        return 2
    if "--help" in args or "-h" in args:
        print(HELP[cmd], end="")
        return 0
    if cmd == "init-config":
        return cmd_init_config(args)
    if cmd == "init":
        return error("IO error: not a terminal")
    if cmd == "parse":
        return cmd_parse(args)
    if cmd in ("highlight", "tags"):
        return cmd_highlight_or_tags(args, cmd)
    if cmd == "query":
        return cmd_query(args)
    if cmd == "generate":
        return cmd_generate(args)
    if cmd == "build":
        return cmd_build(args)
    if cmd == "version":
        return cmd_version(args)
    if cmd == "test":
        return cmd_test(args)
    if cmd == "dump-languages":
        return cmd_dump_languages(args)
    if cmd == "complete":
        return cmd_complete(args)
    if cmd == "playground":
        return error("IO error: not a terminal")
    if cmd == "fuzz":
        return cmd_test(args)
    return 0


if __name__ == "__main__":
    raise SystemExit(dispatch(sys.argv[1:]))
