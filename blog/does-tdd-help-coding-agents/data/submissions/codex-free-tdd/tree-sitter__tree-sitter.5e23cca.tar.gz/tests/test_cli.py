import json
import os
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
CLI = ROOT / "src" / "tree_sitter_cli.py"


def run_cli(*args, cwd=None, home=None):
    env = os.environ.copy()
    if home is not None:
        env["HOME"] = str(home)
    return subprocess.run(
        [sys.executable, str(CLI), *args],
        cwd=cwd,
        env=env,
        text=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
    )


class TreeSitterCliTests(unittest.TestCase):
    def test_version_flag_prints_program_version(self):
        result = run_cli("--version")
        self.assertEqual(result.returncode, 0)
        self.assertEqual(result.stdout, "tree-sitter 0.27.0\n")
        self.assertEqual(result.stderr, "")

    def test_no_arguments_prints_help_to_stderr_and_fails_like_clap(self):
        result = run_cli()
        self.assertEqual(result.returncode, 2)
        self.assertIn("tree-sitter 0.27.0", result.stderr)
        self.assertIn("Usage: executable <COMMAND>", result.stderr)
        self.assertIn("dump-languages  Print info about all known language parsers", result.stderr)
        self.assertEqual(result.stdout, "")

    def test_init_config_writes_default_config_under_home(self):
        with tempfile.TemporaryDirectory() as tmp:
            home = Path(tmp)
            result = run_cli("init-config", home=home)
            self.assertEqual(result.returncode, 0)
            self.assertEqual(result.stdout, "")
            self.assertIn("Saved initial configuration to", result.stderr)
            config_path = home / ".config" / "tree-sitter" / "config.json"
            config = json.loads(config_path.read_text())
            self.assertEqual(config["parser-directories"][0], f"{home}/github")
            self.assertEqual(config["theme"]["comment"]["color"], 245)

    def test_parse_without_config_reports_missing_language(self):
        with tempfile.TemporaryDirectory() as tmp:
            home = Path(tmp) / "home"
            home.mkdir()
            result = run_cli("parse", cwd=tmp, home=home)
            self.assertEqual(result.returncode, 1)
            self.assertEqual(result.stdout, "\n")
            self.assertIn("Warning:", result.stderr)
            self.assertIn("You have not configured any parser directories", result.stderr)
            self.assertIn("Error:", result.stderr)
            self.assertIn("No language found", result.stderr)

    def test_fish_completion_contains_subcommands(self):
        result = run_cli("complete", "--shell", "fish")
        self.assertEqual(result.returncode, 0)
        self.assertIn("complete -c tree-sitter", result.stdout)
        self.assertIn('-a "init-config"', result.stdout)
        self.assertEqual(result.stderr, "")

    def test_subcommand_help_includes_observed_specific_options(self):
        expectations = {
            "parse": ["--debug-build", "--debug-graph", "--encoding <ENCODING>", "--no-ranges"],
            "test": ["--show-fields", "--stat <STAT>", "--json-summary"],
            "highlight": ["--test-number <TEST_NUMBER>", "--encoding <ENCODING>"],
            "tags": ["--test-number <TEST_NUMBER>"],
        }
        for command, snippets in expectations.items():
            with self.subTest(command=command):
                result = run_cli(command, "--help")
                self.assertEqual(result.returncode, 0)
                for snippet in snippets:
                    self.assertIn(snippet, result.stdout)

    def test_compile_script_creates_runnable_executable(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            subprocess.run(["cp", "-R", str(ROOT / "src"), str(root / "src")], check=True)
            subprocess.run(["cp", str(ROOT / "compile.sh"), str(root / "compile.sh")], check=True)
            result = subprocess.run(
                ["bash", "-lc", "chmod +x ./compile.sh && ./compile.sh && ./executable --version"],
                cwd=root,
                text=True,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
            )
            self.assertEqual(result.returncode, 0, result.stderr)
            self.assertEqual(result.stdout, "tree-sitter 0.27.0\n")


if __name__ == "__main__":
    unittest.main()
