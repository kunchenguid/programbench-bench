import os
import subprocess
import sys
import unittest


ROOT = os.path.dirname(os.path.dirname(__file__))
BIN = [sys.executable, os.path.join(ROOT, "rustowl.py")]


def run_cli(*args, input_data=None):
    return subprocess.run(
        BIN + list(args),
        input=input_data,
        text=True,
        capture_output=True,
        cwd=ROOT,
        timeout=3,
    )


class RustOwlCliTests(unittest.TestCase):
    def test_compile_script_creates_runnable_executable(self):
        subprocess.run(["rm", "-f", os.path.join(ROOT, "executable")], check=True)
        result = subprocess.run(
            ["bash", os.path.join(ROOT, "compile.sh")],
            text=True,
            capture_output=True,
            cwd=ROOT,
            timeout=3,
        )
        self.assertEqual(result.returncode, 0, result.stderr)
        built = os.path.join(ROOT, "executable")
        self.assertTrue(os.access(built, os.X_OK))
        version = subprocess.run(
            [built, "--version"],
            text=True,
            capture_output=True,
            cwd=ROOT,
            timeout=3,
        )
        self.assertEqual(version.stdout, "RustOwl v1.0.0-rc.1\n")

    def test_version_prints_full_name_by_default(self):
        result = run_cli("--version")
        self.assertEqual(result.returncode, 0)
        self.assertEqual(result.stdout, "RustOwl v1.0.0-rc.1\n")
        self.assertEqual(result.stderr, "")

    def test_quiet_version_prints_short_version(self):
        result = run_cli("-q", "--version")
        self.assertEqual(result.returncode, 0)
        self.assertEqual(result.stdout, "v1.0.0-rc.1\n")
        self.assertEqual(result.stderr, "")

    def test_root_help_lists_commands_and_options(self):
        result = run_cli("--help")
        self.assertEqual(result.returncode, 0)
        self.assertIn("Usage: executable [OPTIONS] [COMMAND]\n", result.stdout)
        self.assertIn("  check        Check availability\n", result.stdout)
        self.assertIn("  -q, --quiet...  Suppress output\n", result.stdout)
        self.assertEqual(result.stderr, "")

    def test_no_arguments_prints_lsp_message_to_stderr(self):
        result = run_cli()
        self.assertEqual(result.returncode, 0)
        self.assertEqual(result.stdout, "")
        self.assertEqual(
            result.stderr,
            "RustOwl v1.0.0-rc.1\n"
            "This is an LSP server. You can use --help flag to show help.\n",
        )

    def test_invalid_root_argument_matches_clap_style_error(self):
        result = run_cli("--bad")
        self.assertEqual(result.returncode, 2)
        self.assertEqual(result.stdout, "")
        self.assertIn("error: unexpected argument '--bad' found\n", result.stderr)
        self.assertIn("Usage: executable [OPTIONS] [COMMAND]\n", result.stderr)

    def test_check_help_documents_flags(self):
        result = run_cli("check", "--help")
        self.assertEqual(result.returncode, 0)
        self.assertIn("Check availability\n\nUsage: executable check [OPTIONS] [path]\n", result.stdout)
        self.assertIn("      --all-targets   Run the check for all targets instead of current only\n", result.stdout)
        self.assertIn("      --all-features  Run the check for all features instead of the current active ones only\n", result.stdout)

    def test_check_invalid_path_fails_with_analysis_message(self):
        result = run_cli("check", "/tmp/no-such")
        self.assertEqual(result.returncode, 1)
        self.assertEqual(result.stdout, "")
        self.assertIn("Invalid analysis target: /tmp/no-such\n", result.stderr)
        self.assertIn("ERROR [rustowl] Analyze failed\n", result.stderr)

    def test_toolchain_install_help_documents_options(self):
        result = run_cli("toolchain", "install", "--help")
        self.assertEqual(result.returncode, 0)
        self.assertIn("Install the toolchain\n\nUsage: executable toolchain install [OPTIONS]\n", result.stdout)
        self.assertIn("      --path <path>             Runtime directory path to install RustOwl toolchain\n", result.stdout)

    def test_completion_for_fish_contains_subcommands(self):
        result = run_cli("completions", "fish")
        self.assertEqual(result.returncode, 0)
        self.assertIn("complete -c rustowl -n \"__fish_rustowl_needs_command\" -f -a \"check\" -d 'Check availability'\n", result.stdout)
        self.assertIn("complete -c rustowl -n \"__fish_rustowl_using_subcommand toolchain; and not __fish_seen_subcommand_from install uninstall help\" -f -a \"install\" -d 'Install the toolchain'\n", result.stdout)

    def test_stdio_empty_input_prints_lsp_message(self):
        result = run_cli("--stdio", input_data="")
        self.assertEqual(result.returncode, 0)
        self.assertEqual(result.stdout, "")
        self.assertEqual(
            result.stderr,
            "RustOwl v1.0.0-rc.1\n"
            "This is an LSP server. You can use --help flag to show help.\n",
        )


if __name__ == "__main__":
    unittest.main()
