#!/usr/bin/env python3
import json
import os
import sys
from datetime import datetime, timezone


VERSION = "v1.0.0-rc.1"
FULL_VERSION = f"RustOwl {VERSION}"
LSP_MESSAGE = FULL_VERSION + "\nThis is an LSP server. You can use --help flag to show help.\n"


ROOT_HELP = """Usage: executable [OPTIONS] [COMMAND]

Commands:
  check        Check availability
  clean        Remove artifacts from the target directory
  toolchain    Install or uninstall the toolchain
  completions  Generate shell completions
  help         Print this message or the help of the given subcommand(s)

Options:
  -V, --version   Print version
  -q, --quiet...  Suppress output
      --stdio     Use stdio to communicate with the LSP server
  -h, --help      Print help
"""

CHECK_HELP = """Check availability

Usage: executable check [OPTIONS] [path]

Arguments:
  [path]  The path of a file or directory to check availability

Options:
      --all-targets   Run the check for all targets instead of current only
      --all-features  Run the check for all features instead of the current active ones only
  -h, --help          Print help
"""

CLEAN_HELP = """Remove artifacts from the target directory

Usage: executable clean

Options:
  -h, --help  Print help
"""

TOOLCHAIN_HELP = """Install or uninstall the toolchain

Usage: executable toolchain [COMMAND]

Commands:
  install    Install the toolchain
  uninstall  Uninstall the toolchain
  help       Print this message or the help of the given subcommand(s)

Options:
  -h, --help  Print help
"""

TOOLCHAIN_INSTALL_HELP = """Install the toolchain

Usage: executable toolchain install [OPTIONS]

Options:
      --path <path>             Runtime directory path to install RustOwl toolchain
      --skip-rustowl-toolchain  Install Rust toolchain only
  -h, --help                    Print help
"""

TOOLCHAIN_UNINSTALL_HELP = """Uninstall the toolchain

Usage: executable toolchain uninstall

Options:
  -h, --help  Print help
"""

COMPLETIONS_HELP = """Generate shell completions

Usage: executable completions <SHELL>

Arguments:
  <SHELL>
          The shell to generate completions for

          Possible values:
          - bash:       Bourne Again `SHell` (bash)
          - elvish:     Elvish shell
          - fish:       Friendly Interactive `SHell` (fish)
          - powershell: `PowerShell`
          - zsh:        Z `SHell` (zsh)
          - nushell:    Nushell

Options:
  -h, --help
          Print help (see a summary with '-h')
"""


def eprint(text):
    sys.stderr.write(text)


def now():
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%S.%f")[:23] + "Z"


def log(level, target, message):
    eprint(f"{now()} {level:<5} [{target}] {message}\n")


def unexpected(arg, usage, tip=None):
    eprint(f"error: unexpected argument '{arg}' found\n")
    if tip:
        eprint(f"\n  tip: {tip}\n")
    eprint(f"\nUsage: {usage}\n\nFor more information, try '--help'.\n")
    return 2


def invalid_shell(shell):
    eprint(
        f"error: invalid value '{shell}' for '<SHELL>'\n"
        "  [possible values: bash, elvish, fish, powershell, zsh, nushell]\n\n"
    )
    if shell == "bad":
        eprint("  tip: a similar value exists: 'bash'\n\n")
    eprint("For more information, try '--help'.\n")
    return 2


def completion_fish():
    return r"""# Print an optspec for argparse to handle cmd's options that are independent of any subcommand.
function __fish_rustowl_global_optspecs
	string join \n V/version q/quiet stdio h/help
end

function __fish_rustowl_needs_command
	set -l cmd (commandline -opc)
	set -e cmd[1]
	argparse -s (__fish_rustowl_global_optspecs) -- $cmd 2>/dev/null
	or return
	if set -q argv[1]
		echo $argv[1]
		return 1
	end
	return 0
end

function __fish_rustowl_using_subcommand
	set -l cmd (__fish_rustowl_needs_command)
	test -z "$cmd"
	and return 1
	contains -- $cmd[1] $argv
end

complete -c rustowl -n "__fish_rustowl_needs_command" -s V -l version -d 'Print version'
complete -c rustowl -n "__fish_rustowl_needs_command" -s q -l quiet -d 'Suppress output'
complete -c rustowl -n "__fish_rustowl_needs_command" -l stdio -d 'Use stdio to communicate with the LSP server'
complete -c rustowl -n "__fish_rustowl_needs_command" -s h -l help -d 'Print help'
complete -c rustowl -n "__fish_rustowl_needs_command" -f -a "check" -d 'Check availability'
complete -c rustowl -n "__fish_rustowl_needs_command" -f -a "clean" -d 'Remove artifacts from the target directory'
complete -c rustowl -n "__fish_rustowl_needs_command" -f -a "toolchain" -d 'Install or uninstall the toolchain'
complete -c rustowl -n "__fish_rustowl_needs_command" -f -a "completions" -d 'Generate shell completions'
complete -c rustowl -n "__fish_rustowl_needs_command" -f -a "help" -d 'Print this message or the help of the given subcommand(s)'
complete -c rustowl -n "__fish_rustowl_using_subcommand check" -l all-targets -d 'Run the check for all targets instead of current only'
complete -c rustowl -n "__fish_rustowl_using_subcommand check" -l all-features -d 'Run the check for all features instead of the current active ones only'
complete -c rustowl -n "__fish_rustowl_using_subcommand check" -s h -l help -d 'Print help'
complete -c rustowl -n "__fish_rustowl_using_subcommand clean" -s h -l help -d 'Print help'
complete -c rustowl -n "__fish_rustowl_using_subcommand toolchain; and not __fish_seen_subcommand_from install uninstall help" -s h -l help -d 'Print help'
complete -c rustowl -n "__fish_rustowl_using_subcommand toolchain; and not __fish_seen_subcommand_from install uninstall help" -f -a "install" -d 'Install the toolchain'
complete -c rustowl -n "__fish_rustowl_using_subcommand toolchain; and not __fish_seen_subcommand_from install uninstall help" -f -a "uninstall" -d 'Uninstall the toolchain'
complete -c rustowl -n "__fish_rustowl_using_subcommand toolchain; and not __fish_seen_subcommand_from install uninstall help" -f -a "help" -d 'Print this message or the help of the given subcommand(s)'
complete -c rustowl -n "__fish_rustowl_using_subcommand toolchain; and __fish_seen_subcommand_from install" -l path -d 'Runtime directory path to install RustOwl toolchain' -r -F
complete -c rustowl -n "__fish_rustowl_using_subcommand toolchain; and __fish_seen_subcommand_from install" -l skip-rustowl-toolchain -d 'Install Rust toolchain only'
complete -c rustowl -n "__fish_rustowl_using_subcommand toolchain; and __fish_seen_subcommand_from install" -s h -l help -d 'Print help'
complete -c rustowl -n "__fish_rustowl_using_subcommand toolchain; and __fish_seen_subcommand_from uninstall" -s h -l help -d 'Print help'
complete -c rustowl -n "__fish_rustowl_using_subcommand completions" -s h -l help -d 'Print help (see more with \'--help\')'
"""


def completion_bash():
    return """_rustowl() {
    local i cur prev opts cmd
    COMPREPLY=()
    cmd=""
    opts=""
    case "${cmd}" in
        rustowl)
            opts="-V --version -q --quiet --stdio -h --help check clean toolchain completions help"
            ;;
    esac
}

complete -F _rustowl -o bashdefault -o default rustowl
"""


def completion_zsh():
    return """#compdef rustowl

_rustowl() {
    _arguments : \\
'-V[Print version]' \\
'--version[Print version]' \\
'*-q[Suppress output]' \\
'*--quiet[Suppress output]' \\
'--stdio[Use stdio to communicate with the LSP server]' \\
'1: :((check\\:Check\\ availability clean\\:Remove\\ artifacts\\ from\\ the\\ target\\ directory toolchain\\:Install\\ or\\ uninstall\\ the\\ toolchain completions\\:Generate\\ shell\\ completions help\\:Print\\ this\\ message\\ or\\ the\\ help\\ of\\ the\\ given\\ subcommand\\(s\\)))'
}
"""


def completion_elvish():
    return """
use builtin;
use str;

set edit:completion:arg-completer[rustowl] = {|@words|
    fn cand {|text desc| edit:complex-candidate $text &display=$text' '$desc }
    cand check 'Check availability'
    cand clean 'Remove artifacts from the target directory'
    cand toolchain 'Install or uninstall the toolchain'
    cand completions 'Generate shell completions'
}
"""


def completion_powershell():
    return """
using namespace System.Management.Automation
Register-ArgumentCompleter -Native -CommandName 'rustowl' -ScriptBlock {
    [CompletionResult]::new('check', 'check', [CompletionResultType]::ParameterValue, 'Check availability')
    [CompletionResult]::new('clean', 'clean', [CompletionResultType]::ParameterValue, 'Remove artifacts from the target directory')
    [CompletionResult]::new('toolchain', 'toolchain', [CompletionResultType]::ParameterValue, 'Install or uninstall the toolchain')
    [CompletionResult]::new('completions', 'completions', [CompletionResultType]::ParameterValue, 'Generate shell completions')
}
"""


def completion_nushell():
    return """module completions {

  export extern rustowl [
    --version(-V)             # Print version
    --quiet(-q)               # Suppress output
    --stdio                   # Use stdio to communicate with the LSP server
    --help(-h)                # Print help
  ]

  # Check availability
  export extern "rustowl check" [
    --all-targets             # Run the check for all targets instead of current only
    --all-features            # Run the check for all features instead of the current active ones only
    --help(-h)                # Print help
    path?: path               # The path of a file or directory to check availability
  ]
}
"""


COMPLETIONS = {
    "bash": completion_bash,
    "fish": completion_fish,
    "zsh": completion_zsh,
    "elvish": completion_elvish,
    "powershell": completion_powershell,
    "nushell": completion_nushell,
}


def read_lsp_message(stdin):
    header = b""
    while b"\r\n\r\n" not in header and b"\n\n" not in header:
        chunk = stdin.read(1)
        if not chunk:
            return None
        header += chunk
    sep = b"\r\n\r\n" if b"\r\n\r\n" in header else b"\n\n"
    head = header.split(sep, 1)[0].decode("ascii", "replace")
    length = 0
    for line in head.replace("\r", "").split("\n"):
        if line.lower().startswith("content-length:"):
            try:
                length = int(line.split(":", 1)[1].strip())
            except ValueError:
                length = 0
    if length <= 0:
        return None
    body = stdin.read(length)
    if len(body) < length:
        return None
    try:
        return json.loads(body.decode("utf-8"))
    except json.JSONDecodeError:
        return None


def write_lsp(payload):
    data = json.dumps(payload, separators=(",", ":")).encode("utf-8")
    sys.stdout.buffer.write(f"Content-Length: {len(data)}\r\n\r\n".encode("ascii"))
    sys.stdout.buffer.write(data)
    sys.stdout.buffer.flush()


def run_stdio():
    first = read_lsp_message(sys.stdin.buffer)
    if first is None:
        eprint(LSP_MESSAGE)
        return 0
    current = first
    while current is not None:
        method = current.get("method")
        msg_id = current.get("id")
        if method == "initialize" and msg_id is not None:
            write_lsp({"jsonrpc": "2.0", "id": msg_id, "result": {"capabilities": {}}})
        elif method == "shutdown" and msg_id is not None:
            write_lsp({"jsonrpc": "2.0", "id": msg_id, "result": None})
        elif method == "exit":
            return 0
        elif msg_id is not None:
            write_lsp({"jsonrpc": "2.0", "id": msg_id, "result": None})
        current = read_lsp_message(sys.stdin.buffer)
    return 0


def run_check(args):
    if "-h" in args or "--help" in args:
        sys.stdout.write(CHECK_HELP)
        return 0
    paths = []
    for arg in args:
        if arg in ("--all-targets", "--all-features"):
            continue
        if arg.startswith("-"):
            return unexpected(arg, "executable check [OPTIONS] [path]", f"to pass '{arg}' as a value, use '-- {arg}'")
        paths.append(arg)
    path = paths[0] if paths else None
    if path is None:
        log("INFO", "rustowl::toolchain", "sysroot not found; start setup toolchain")
        return run_toolchain_install([])
    log("WARN", "rustowl::toolchain", "cargo not found; fallback")
    log("WARN", "rustowl::toolchain", "rustowlc not found; fallback")
    if not os.path.exists(path) or os.path.isdir(path):
        log("WARN", "rustowl::lsp::analyze", f"Invalid analysis target: {path}")
        log("ERROR", "rustowl", "Analyze failed")
        return 1
    log("ERROR", "rustowl", "Analyze failed")
    return 1


def run_toolchain_install(args):
    if "-h" in args or "--help" in args:
        sys.stdout.write(TOOLCHAIN_INSTALL_HELP)
        return 0
    log("INFO", "rustowl::toolchain", "start installing Rust toolchain...")
    log("INFO", "rustowl::toolchain", "temp dir is made: /tmp/.tmpRustOwl")
    log("INFO", "rustowl::toolchain", "start downloading https://static.rust-lang.org/dist/2025-06-20/rustc-nightly-x86_64-unknown-linux-gnu.tar.gz...")
    log("ERROR", "rustowl::toolchain", "failed to download tarball")
    return 1


def run_toolchain(args):
    if not args:
        return 0
    cmd = args[0]
    rest = args[1:]
    if cmd in ("-h", "--help"):
        sys.stdout.write(TOOLCHAIN_HELP)
        return 0
    if cmd == "help":
        if rest and rest[0] == "install":
            sys.stdout.write(TOOLCHAIN_INSTALL_HELP)
        elif rest and rest[0] == "uninstall":
            sys.stdout.write(TOOLCHAIN_UNINSTALL_HELP)
        else:
            sys.stdout.write(TOOLCHAIN_HELP)
        return 0
    if cmd == "install":
        return run_toolchain_install(rest)
    if cmd == "uninstall":
        if "-h" in rest or "--help" in rest:
            sys.stdout.write(TOOLCHAIN_UNINSTALL_HELP)
            return 0
        log("INFO", "rustowl::toolchain", "remove sysroot: /home/agent/.rustowl/sysroot/nightly-2025-06-20-x86_64-unknown-linux-gnu")
        return 0
    return unexpected(cmd, "executable toolchain [COMMAND]")


def run_completions(args):
    if not args or args[0] in ("-h", "--help"):
        sys.stdout.write(COMPLETIONS_HELP)
        return 0
    shell = args[0]
    if shell not in COMPLETIONS:
        return invalid_shell(shell)
    sys.stdout.write(COMPLETIONS[shell]())
    return 0


def main(argv):
    quiet = 0
    args = list(argv)
    while args and args[0] in ("-q", "--quiet"):
        quiet += 1
        args.pop(0)
    if args and args[0].startswith("-qq"):
        quiet += len(args[0]) - 1
        args.pop(0)

    if not args:
        eprint(LSP_MESSAGE)
        return 0
    if args[0] in ("-h", "--help", "help") and len(args) == 1:
        sys.stdout.write(ROOT_HELP)
        return 0
    if args[0] in ("-V", "--version"):
        sys.stdout.write((VERSION if quiet else FULL_VERSION) + "\n")
        return 0
    if args[0] == "--stdio":
        return run_stdio()
    if args[0].startswith("-"):
        return unexpected(args[0], "executable [OPTIONS] [COMMAND]")

    cmd, rest = args[0], args[1:]
    if cmd == "help":
        if rest and rest[0] == "check":
            sys.stdout.write(CHECK_HELP)
        elif rest and rest[0] == "clean":
            sys.stdout.write(CLEAN_HELP)
        elif rest and rest[0] == "toolchain":
            sys.stdout.write(TOOLCHAIN_HELP)
        elif rest and rest[0] == "completions":
            sys.stdout.write(COMPLETIONS_HELP)
        else:
            sys.stdout.write(ROOT_HELP)
        return 0
    if cmd == "check":
        return run_check(rest)
    if cmd == "clean":
        if "-h" in rest or "--help" in rest:
            sys.stdout.write(CLEAN_HELP)
            return 0
        if rest:
            return unexpected(rest[0], "executable clean")
        return 0
    if cmd == "toolchain":
        return run_toolchain(rest)
    if cmd == "completions":
        return run_completions(rest)
    return unexpected(cmd, "executable [OPTIONS] [COMMAND]")


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
