#!/usr/bin/env python3
import json
import os
import re
import sys


HELP = """tuc 1.3.0
Cut text (or bytes) where a delimiter matches, then keep the desired parts.

USAGE:
    tuc [FLAGS] [OPTIONS] < input
    tuc [FLAGS] [OPTIONS] filepath

FLAGS:
    -g, --greedy-delimiter        Match consecutive delimiters as if it was one
    -p, --compress-delimiter      Print only the first delimiter of a sequence
    -s, --only-delimited          Print only lines containing the delimiter
    -V, --version                 Print version information
    -z, --zero-terminated         Line delimiter is NUL (\\0), not LF (\\n)
    -h, --help                    Print this help and exit
    -m, --complement              Invert fields (e.g. '2' becomes '1,3:')
    -j, --(no-)join               Print selected parts with delimiter in between
    --json                        Print fields as a JSON array of strings
    --no-mmap                     Disable memory mapping

OPTIONS:
    -f, --fields <bounds>         Fields to keep, 1-indexed, comma separated.
    -b, --bytes <bounds>          Same as --fields, but it keeps bytes
    -c, --characters <bounds>     Same as --fields, but it keeps characters
    -l, --lines <bounds>          Same as --fields, but it keeps lines
    -d, --delimiter <delimiter>   Delimiter used by --fields to cut the text
                                  [default: \\t]
"""


class TucError(Exception):
    def __init__(self, message, code=1):
        super().__init__(message)
        self.code = code


class PartialTucError(TucError):
    def __init__(self, message, partial, code=1):
        super().__init__(message, code)
        self.partial = partial


def parse_args(argv):
    opts = {
        "mode": "fields",
        "bounds": "1:",
        "delimiter": "\t",
        "regex": None,
        "greedy": False,
        "compress": False,
        "only_delimited": False,
        "zero": False,
        "complement": False,
        "join": None,
        "json": False,
        "replace": None,
        "trim": None,
        "fallback": None,
        "file": None,
    }
    i = 0
    while i < len(argv):
        a = argv[i]
        eq_value = None
        if a.startswith("--") and "=" in a:
            a, eq_value = a.split("=", 1)
        if a in ("-h", "--help"):
            sys.stdout.write(HELP)
            raise SystemExit(0)
        if a in ("-V", "--version"):
            sys.stdout.write("tuc 1.3.0\n")
            raise SystemExit(0)
        if a in ("-g", "--greedy-delimiter"):
            opts["greedy"] = True
        elif a in ("-p", "--compress-delimiter"):
            opts["compress"] = True
        elif a in ("-s", "--only-delimited"):
            opts["only_delimited"] = True
        elif a in ("-z", "--zero-terminated"):
            opts["zero"] = True
        elif a in ("-m", "--complement"):
            opts["complement"] = True
        elif a in ("-j", "--join"):
            opts["join"] = True
        elif a == "--no-join":
            opts["join"] = False
        elif a == "--json":
            opts["json"] = True
        elif a == "--no-mmap":
            pass
        elif a in ("-f", "--fields", "-b", "--bytes", "-c", "--characters", "-l", "--lines",
                   "-d", "--delimiter", "-e", "--regex", "-r", "--replace-delimiter",
                   "-t", "--trim", "--fallback-oob", "-M", "--fixed-memory"):
            if eq_value is None and i + 1 >= len(argv):
                raise TucError(f"error: The argument '{a}' requires a value", 2)
            if eq_value is None:
                v = argv[i + 1]
                i += 1
            else:
                v = eq_value
            if a in ("-f", "--fields"):
                opts["mode"], opts["bounds"] = "fields", v
            elif a in ("-b", "--bytes"):
                opts["mode"], opts["bounds"] = "bytes", v
            elif a in ("-c", "--characters"):
                opts["mode"], opts["bounds"] = "chars", v
            elif a in ("-l", "--lines"):
                opts["mode"], opts["bounds"] = "lines", v
                if opts["join"] is None:
                    opts["join"] = True
            elif a in ("-d", "--delimiter"):
                opts["delimiter"] = v
            elif a in ("-e", "--regex"):
                opts["regex"] = v
            elif a in ("-r", "--replace-delimiter"):
                opts["replace"] = v
                opts["join"] = True
            elif a in ("-t", "--trim"):
                opts["trim"] = v.lower()[:1]
            elif a == "--fallback-oob":
                opts["fallback"] = v
            else:
                pass
        elif a.startswith("--"):
            raise TucError(f"error: Found argument '{a}' which wasn't expected", 2)
        else:
            opts["file"] = a
        i += 1
    if opts["join"] is None:
        opts["join"] = False
    if opts["regex"] and opts["join"] and opts["replace"] is None:
        raise TucError("tuc: runtime error. Cannot use --regex and --join without --replace-delimiter")
    return opts


def split_commas(s):
    parts, cur, depth = [], [], 0
    for ch in s:
        if ch == "{" and depth >= 0:
            depth += 1
        elif ch == "}" and depth > 0:
            depth -= 1
        if ch == "," and depth == 0:
            parts.append("".join(cur))
            cur = []
        else:
            cur.append(ch)
    parts.append("".join(cur))
    return parts


def parse_num(text, whole):
    if text == "":
        return None
    try:
        n = int(text)
    except ValueError:
        raise TucError(f"failed to parse '{text}': Not a number `{text}`")
    if n == 0:
        raise TucError(f"failed to parse '0': Zero is not a valid field")
    return n if n > 0 else whole + n + 1


def parse_selector_piece(piece, whole):
    fallback = None
    if "=" in piece:
        piece, fallback = piece.split("=", 1)
    if ":" in piece:
        left, right = piece.split(":", 1)
        start = parse_num(left, whole) if left else 1
        end = parse_num(right, whole) if right else whole
        return ("range", start, end, fallback)
    idx = parse_num(piece, whole)
    return ("one", idx, idx, fallback)


def has_format(bounds):
    return "{" in bounds or "}" in bounds


def get_item(items, idx, fallback):
    if 1 <= idx <= len(items):
        return items[idx - 1]
    if fallback is not None:
        return fallback
    raise TucError(f"Error: Out of bounds: {idx}")


def render_format(fmt, items, generic_fallback):
    out = []
    i = 0
    while i < len(fmt):
        if fmt.startswith("{{", i):
            out.append("{")
            i += 2
        elif fmt.startswith("}}", i):
            out.append("}")
            i += 2
        elif fmt[i] == "{":
            j = fmt.find("}", i + 1)
            if j < 0:
                raise TucError(f"failed to parse '{fmt}': Invalid format")
            spec = fmt[i + 1:j]
            parsed = parse_selector_piece(spec, len(items))
            if parsed[0] != "one":
                raise TucError(f"failed to parse '{spec}': Invalid format field")
            try:
                out.append(get_item(items, parsed[1], parsed[3] if parsed[3] is not None else generic_fallback))
            except TucError as e:
                raise PartialTucError(str(e), "".join(out), e.code)
            i = j + 1
        else:
            out.append(fmt[i])
            i += 1
    return "".join(out)


def split_fields(line, opts):
    delim = opts["delimiter"]
    if opts["regex"]:
        fields = re.split(opts["regex"], line)
        delims = re.findall(opts["regex"], line)
        return fields, delims
    if opts["greedy"] and delim:
        pattern = re.escape(delim) + "+"
        fields = re.split(pattern, line)
        delims = re.findall(pattern, line)
    else:
        fields = line.split(delim)
        delims = [delim] * (len(fields) - 1)
    if opts["compress"] and delim:
        fields = re.split(re.escape(delim) + "+", line)
        raw = re.findall(re.escape(delim) + "+", line)
        delims = [x[:len(delim)] for x in raw]
    if opts["trim"] in ("r", "b"):
        while len(fields) > 1 and fields[-1] == "":
            fields.pop()
            if delims:
                delims.pop()
    if opts["trim"] in ("l", "b"):
        while len(fields) > 1 and fields[0] == "":
            fields.pop(0)
            if delims:
                delims.pop(0)
    return fields, delims


def delimiter_for(opts):
    if opts["replace"] is not None:
        return opts["replace"]
    return opts["delimiter"]


def render_selected(items, delims, bounds, opts):
    if has_format(bounds):
        return render_format(bounds, items, opts["fallback"])
    pieces = [parse_selector_piece(p, len(items)) for p in split_commas(bounds)]
    ranges = [(p[1], p[2], p[3]) for p in pieces]
    if opts["complement"]:
        selected = set()
        for start, end, _ in ranges:
            if start <= end:
                selected.update(range(max(1, start), min(len(items), end) + 1))
        ranges = []
        cur = 1
        for idx in sorted(selected):
            if cur < idx:
                ranges.append((cur, idx - 1, None))
            cur = idx + 1
        if cur <= len(items):
            ranges.append((cur, len(items), None))
    rendered = []
    json_values = []
    for start, end, fallback in ranges:
        if start > end:
            seq = range(start, end - 1, -1)
        else:
            seq = range(start, end + 1)
        chunk = []
        for pos, idx in enumerate(seq):
            value = get_item(items, idx, fallback if fallback is not None else opts["fallback"])
            json_values.append(value)
            if opts["join"] and chunk:
                chunk.append(delimiter_for(opts))
            elif not opts["join"] and pos and abs(idx - prev_idx) == 1:
                dpos = min(idx, prev_idx) - 1
                if 0 <= dpos < len(delims):
                    chunk.append(delims[dpos] if opts["replace"] is None else opts["replace"])
            chunk.append(value)
            prev_idx = idx
        rendered.append("".join(chunk))
    if opts["json"]:
        return json.dumps(json_values, ensure_ascii=False, separators=(",", ":"))
    return (delimiter_for(opts).join(rendered) if opts["join"] else "".join(rendered))


def each_record(data, sep):
    parts = data.split(sep)
    for i, part in enumerate(parts):
        if i == len(parts) - 1 and part == "":
            continue
        yield part, (i < len(parts) - 1)


def process_text_records(text, opts):
    sep = "\0" if opts["zero"] else "\n"
    out = []
    code = 0
    for rec, had_sep in each_record(text, sep):
        fields, delims = split_fields(rec, opts)
        if opts["only_delimited"] and len(fields) == 1:
            continue
        try:
            rendered = render_selected(fields, delims, opts["bounds"], opts)
        except PartialTucError as e:
            out.append(e.partial)
            sys.stderr.write(str(e) + "\n")
            code = e.code
            break
        except TucError as e:
            sys.stderr.write(str(e) + "\n")
            code = e.code
            break
        out.append(rendered)
        if had_sep:
            out.append(sep)
    sys.stdout.write("".join(out))
    return code


def process_units(text, opts):
    if opts["mode"] == "bytes":
        raw = text.encode("latin1")
        units = [bytes([b]).decode("latin1") for b in raw]
        opts = dict(opts)
        opts["delimiter"] = ""
    elif opts["mode"] == "chars":
        sep = "\0" if opts["zero"] else "\n"
        body = text[:-1] if text.endswith(sep) else text
        units = list(body)
        opts = dict(opts)
        opts["delimiter"] = ""
    else:
        sep = "\0" if opts["zero"] else "\n"
        parts = text.split(sep)
        units = parts[:-1] if parts and parts[-1] == "" else parts
        opts = dict(opts)
        opts["delimiter"] = sep
    rendered = render_selected(units, [opts["delimiter"]] * max(0, len(units) - 1), opts["bounds"], opts)
    if opts["mode"] == "bytes":
        sys.stdout.buffer.write(rendered.encode("latin1"))
    else:
        if opts["mode"] == "lines" and rendered and text.endswith(opts["delimiter"]):
            rendered += opts["delimiter"]
        if opts["mode"] == "chars" and rendered and text.endswith(("\0" if opts["zero"] else "\n")):
            rendered += "\0" if opts["zero"] else "\n"
        sys.stdout.write(rendered)
    return 0


def main(argv):
    try:
        opts = parse_args(argv)
        if opts["file"]:
            with open(opts["file"], "rb") as f:
                data = f.read()
        else:
            data = sys.stdin.buffer.read()
        if opts["mode"] == "bytes":
            text = data.decode("latin1")
        else:
            text = data.decode("utf-8", "surrogateescape")
        if opts["mode"] == "fields":
            return process_text_records(text, opts)
        return process_units(text, opts)
    except TucError as e:
        sys.stderr.write(str(e) + "\n")
        return e.code
    except BrokenPipeError:
        return 1


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
