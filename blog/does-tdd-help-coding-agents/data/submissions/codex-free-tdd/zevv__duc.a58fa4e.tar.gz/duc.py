#!/usr/bin/env python3
import fnmatch
import html
import json
import math
import os
import re
import sys
import time
from pathlib import Path


COMMANDS = [
    ("help", "Show help"),
    ("histogram", "Dump histogram of file sizes found."),
    ("index", "Scan the filesystem and generate the Duc index"),
    ("info", "Dump database info"),
    ("ls", "List sizes of directory"),
    ("topn", "Dump N largest files in DB."),
    ("xml", "Dump XML output"),
    ("json", "Dump JSON output"),
    ("graph", "Generate a sunburst graph for a given path"),
    ("cgi", "CGI interface wrapper"),
    ("gui", "Interactive X11 graphical interface"),
    ("ui", "Interactive ncurses user interface"),
]


HELP = """usage: duc <cmd> [options] [args]

Available subcommands:

  help      : Show help
  histogram : Dump histogram of file sizes found.
  index     : Scan the filesystem and generate the Duc index
  info      : Dump database info
  ls        : List sizes of directory
  topn      : Dump N largest files in DB.
  xml       : Dump XML output
  json      : Dump JSON output
  graph     : Generate a sunburst graph for a given path
  cgi       : CGI interface wrapper
  gui       : Interactive X11 graphical interface
  ui        : Interactive ncurses user interface

Global options:
       --debug               increase verbosity to debug level
  -h,  --help                show help
  -q,  --quiet               quiet mode, do not print any warning
  -v,  --verbose             increase verbosity
       --version             output version information and exit

Use 'duc help <subcommand>' or 'duc <subcommand> -h' for a complete list of all
options and detailed description of the subcommand.

Use 'duc help --all' for a complete list of all options for all subcommands.
"""


COMMAND_HELP = {
    "help": """usage: duc help [options]

Show help.

Options for the command 'help':
  -a,  --all                 show complete help for all commands
""",
    "index": """usage: duc index [options] PATH ...

Scan the filesystem and generate the Duc index.

Options for the command 'index':
  -b,  --bytes               show file size in exact number of bytes
  -d,  --database=VAL        use database file VAL
  -e,  --exclude=VAL         exclude files matching VAL
  -H,  --check-hard-links    count hard links only once. if two or more hard links point to the same file, only one is counted
  -f,  --force               force writing in case of corrupted db
  -U,  --uid=VAL             limit index to only files/dirs owned by uid
  -u,  --username=VAL        limit index to only files/dirs owned by username
  -m,  --max-depth=VAL       limit directory names to given depth
  -x,  --one-file-system     skip directories on different file systems
  -p,  --progress            show progress during indexing
       --dry-run             do not update database, just crawl
       --uncompressed        do not use compression for database
""",
    "info": """usage: duc info [options]

Dump database info.

Options for the command 'info':
  -a,  --apparent            show apparent instead of actual file size
  -b,  --bytes               show file size in exact number of bytes
  -d,  --database=VAL        select database file to use [~/.duc.db]
  -H,  --histogram           show file size in exact number of bytes
""",
    "ls": """usage: duc ls [options] [PATH]...

List sizes of directory.

Options for the command 'ls':
  -a,  --apparent            show apparent instead of actual file size
       --ascii               use ASCII characters instead of UTF-8 to draw tree
  -b,  --bytes               show file size in exact number of bytes
  -F,  --classify            append file type indicator (one of */) to entries
  -c,  --color               colorize output (only on ttys)
       --count               show number of files instead of file size
  -d,  --database=VAL        select database file to use [~/.duc.db]
  -D,  --directory           list directory itself, not its contents
       --dirs-only           list only directories, skip individual files
       --full-path           show full path instead of tree in recursive view
  -g,  --graph               draw graph with relative size for each entry
  -l,  --levels=VAL          traverse up to ARG levels deep [4]
  -n,  --name-sort           sort output by name instead of by size
  -R,  --recursive           recursively list subdirectories
""",
    "json": "usage: duc json [options] [PATH]\n\nDump JSON output.\n",
    "xml": "usage: duc xml [options] [PATH]\n\nDump XML output.\n",
    "topn": "usage: duc topn [options]\n\nDump N largest files in DB..\n",
    "histogram": "usage: duc histogram [options]\n\nDump histogram of file sizes found..\n",
    "graph": "usage: duc graph [options] [PATH]\n\nGenerate a sunburst graph for a given path.\n",
    "cgi": "usage: duc cgi [options] [PATH]\n\nCGI interface wrapper.\n",
    "gui": "usage: duc gui [options] [PATH]\n\nInteractive X11 graphical interface.\n",
    "ui": "usage: duc ui [options] [PATH]\n\nInteractive ncurses user interface.\n",
}


def default_db():
    return os.environ.get("DUC_DATABASE") or os.path.expanduser("~/.duc.db")


def human_size(size):
    units = ["", "K", "M", "G", "T", "P"]
    value = float(size)
    unit = 0
    while abs(value) >= 1024 and unit < len(units) - 1:
        value /= 1024.0
        unit += 1
    if unit == 0:
        return f"{int(value)}"
    return f"{value:.1f}{units[unit]}"


def actual_size(st):
    return int(getattr(st, "st_blocks", 0)) * 512


def scan_path(path, excludes=None, hardlinks=False, seen=None):
    excludes = excludes or []
    seen = seen if seen is not None else set()
    st = os.lstat(path)
    name = os.path.basename(path.rstrip(os.sep)) or path
    is_dir = os.path.isdir(path) and not os.path.islink(path)
    if not is_dir:
        key = (st.st_dev, st.st_ino)
        if hardlinks and st.st_nlink > 1 and key in seen:
            return None
        seen.add(key)
        return {
            "name": name,
            "path": os.path.abspath(path),
            "type": "file",
            "size_apparent": int(st.st_size),
            "size_actual": actual_size(st),
            "count": 1,
            "mtime": int(st.st_mtime),
        }
    children = []
    apparent = 0
    actual = actual_size(st)
    count = 1
    files = 0
    dirs = 1
    for child_name in sorted(os.listdir(path)):
        child_path = os.path.join(path, child_name)
        if any(fnmatch.fnmatch(child_name, pat) or fnmatch.fnmatch(child_path, pat) for pat in excludes):
            continue
        child = scan_path(child_path, excludes, hardlinks, seen)
        if child is None:
            continue
        children.append(child)
        apparent += child["size_apparent"]
        actual += child["size_actual"]
        count += child.get("count", 1)
        files += child.get("files", 1 if child["type"] == "file" else 0)
        dirs += child.get("dirs", 1 if child["type"] == "dir" else 0)
    children.sort(key=lambda c: (-c["size_actual"], c["name"]))
    return {
        "name": name,
        "path": os.path.abspath(path),
        "type": "dir",
        "size_apparent": apparent,
        "size_actual": actual,
        "count": count,
        "files": files,
        "dirs": dirs,
        "children": children,
        "mtime": int(st.st_mtime),
    }


def parse_common(args):
    db = default_db()
    rest = []
    i = 0
    while i < len(args):
        a = args[i]
        if a in ("-d", "--database"):
            i += 1
            db = args[i]
        elif a.startswith("--database="):
            db = a.split("=", 1)[1]
        else:
            rest.append(a)
        i += 1
    return db, rest


def save_db(db, roots):
    data = {"format": "pyduc-1", "created": int(time.time()), "roots": roots}
    Path(db).parent.mkdir(parents=True, exist_ok=True)
    with open(db, "w", encoding="utf-8") as f:
        json.dump(data, f, separators=(",", ":"))


def load_db(db):
    try:
        with open(db, encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        print(f"Error opening: {db} - Database corrupt and not usable", file=sys.stderr)
        sys.exit(1)


def find_node(data, path=None):
    roots = data.get("roots", [])
    if not roots:
        return None
    if not path:
        return roots[0]
    target = os.path.abspath(path)
    for root in roots:
        root_path = root["path"]
        if target == root_path:
            return root
        if target.startswith(root_path.rstrip(os.sep) + os.sep):
            rel = target[len(root_path.rstrip(os.sep)) + 1 :].split(os.sep)
            node = root
            for part in rel:
                node = next((c for c in node.get("children", []) if c["name"] == part), None)
                if node is None:
                    break
            if node is not None:
                return node
    return None


def display_size(node, apparent=False, count=False):
    if count:
        return node.get("count", 1)
    return node["size_apparent" if apparent else "size_actual"]


def format_size(value, bytes_mode=False):
    return str(value) if bytes_mode else human_size(value)


def cmd_index(args):
    db, rest = parse_common(args)
    excludes = []
    hardlinks = False
    dry_run = False
    paths = []
    i = 0
    while i < len(rest):
        a = rest[i]
        if a in ("-e", "--exclude"):
            i += 1
            excludes.append(rest[i])
        elif a.startswith("--exclude="):
            excludes.append(a.split("=", 1)[1])
        elif a in ("-H", "--check-hard-links"):
            hardlinks = True
        elif a == "--dry-run":
            dry_run = True
        elif a.startswith("-"):
            if a in ("-b", "-f", "-x", "-p", "--uncompressed", "--hide-file-names"):
                pass
            elif a in ("-m", "--max-depth", "-U", "--uid", "-u", "--username", "-B", "--buckets", "-T", "--topn", "-M", "--topn-min"):
                i += 1
            elif "=" not in a:
                pass
        else:
            paths.append(a)
        i += 1
    if not paths:
        print("duc: option requires an argument -- index", file=sys.stderr)
        return 1
    roots = []
    seen = set()
    for path in paths:
        root = scan_path(path, excludes, hardlinks, seen)
        root["size_actual_info"] = root["size_actual"]
        root["size_actual"] -= actual_size(os.lstat(path))
        roots.append(root)
    if not dry_run:
        save_db(db, roots)
    return 0


def cmd_info(args):
    db, rest = parse_common(args)
    bytes_mode = "-b" in rest or "--bytes" in rest
    apparent = "-a" in rest or "--apparent" in rest
    data = load_db(db)
    print("Date       Time       Files    Dirs    Size Path")
    for root in data.get("roots", []):
        ts = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(data.get("created", root.get("mtime", 0))))
        size = root["size_apparent"] if apparent else root.get("size_actual_info", root["size_actual"])
        print(f"{ts} {root.get('files', 0):7d} {root.get('dirs', 0):7d} {format_size(size, bytes_mode):>7} {root['path']}")
    return 0


def emit_ls_node(node, bytes_mode, apparent, classify, count_mode, name=None):
    value = display_size(node, apparent, count_mode)
    suffix = "/" if classify and node["type"] == "dir" else ""
    width = 12 if bytes_mode or count_mode else 6
    print(f"{format_size(value, bytes_mode):>{width}} {name or node['name']}{suffix}")


def cmd_ls(args):
    db, rest = parse_common(args)
    bytes_mode = "-b" in rest or "--bytes" in rest
    apparent = "-a" in rest or "--apparent" in rest
    classify = "-F" in rest or "--classify" in rest
    directory = "-D" in rest or "--directory" in rest
    name_sort = "-n" in rest or "--name-sort" in rest
    count_mode = "--count" in rest
    recursive = "-R" in rest or "--recursive" in rest
    paths = [a for a in rest if not a.startswith("-")]
    data = load_db(db)
    node = find_node(data, paths[0] if paths else None)
    if node is None:
        print("Path not found in database", file=sys.stderr)
        return 1
    if directory or node["type"] != "dir":
        if bytes_mode and not count_mode:
            suffix = "/" if classify and node["type"] == "dir" else ""
            print(f"{display_size(node, apparent, count_mode)} {node['path']}{suffix}")
        else:
            emit_ls_node(node, bytes_mode, apparent, classify, count_mode, node["path"])
        return 0
    children = list(node.get("children", []))
    if name_sort:
        children.sort(key=lambda c: c["name"])
    if recursive:
        for idx, child in enumerate(children):
            last = idx == len(children) - 1
            emit_tree(child, "", last, bytes_mode, apparent, classify, count_mode)
    else:
        for child in children:
            emit_ls_node(child, bytes_mode, apparent, classify, count_mode)
    return 0


def emit_tree(node, prefix, last, bytes_mode, apparent, classify, count_mode):
    if node["type"] == "dir" and node.get("children"):
        connector = "`+- "
    else:
        connector = " `- " if last else " |- "
    value = display_size(node, apparent, count_mode)
    suffix = "/" if classify and node["type"] == "dir" else ""
    width = 12 if bytes_mode or count_mode else 6
    print(f"{format_size(value, bytes_mode):>{width}} {prefix}{connector}{node['name']}{suffix}")
    if node["type"] == "dir":
        children = node.get("children", [])
        next_prefix = prefix + ("    " if last else " |  ")
        for idx, child in enumerate(children):
            emit_tree(child, next_prefix, idx == len(children) - 1, bytes_mode, apparent, classify, count_mode)


def json_obj(node, is_root=False, exclude_files=False, min_size=0):
    if exclude_files and node["type"] != "dir":
        return None
    if node["size_actual"] < min_size:
        return None
    out = {
        "name": node["path"] if is_root else node["name"],
    }
    if node["type"] == "dir":
        out["count"] = node["count"] - (1 if is_root else 0)
    out["size_apparent"] = node["size_apparent"]
    out["size_actual"] = node["size_actual"]
    if node["type"] == "dir":
        out["children"] = [x for c in node.get("children", []) if (x := json_obj(c, False, exclude_files, min_size)) is not None]
    return out


def cmd_json(args):
    db, rest = parse_common(args)
    exclude_files = "-x" in rest or "--exclude-files" in rest
    min_size = 0
    paths = []
    i = 0
    while i < len(rest):
        if rest[i] in ("-s", "--min_size"):
            i += 1
            min_size = int(rest[i])
        elif rest[i].startswith("--min_size="):
            min_size = int(rest[i].split("=", 1)[1])
        elif not rest[i].startswith("-"):
            paths.append(rest[i])
        i += 1
    node = find_node(load_db(db), paths[0] if paths else None)
    if node is None:
        return 1
    text = json.dumps(json_obj(node, True, exclude_files, min_size), indent=2)
    text = re.sub(r'^(\s*)"children": \[\]$', r'\1"children": [\n\n\1]', text, flags=re.MULTILINE)
    print(text)
    return 0


def xml_ent(node, level=1, is_root=False, exclude_files=False):
    sp = " " * level
    if is_root:
        yield f'<duc root="{html.escape(node["path"])}" size_apparent="{node["size_apparent"]}" size_actual="{node["size_actual"]}" count="{node["count"] - 1}">'
        for child in node.get("children", []):
            if not (exclude_files and child["type"] != "dir"):
                yield from xml_ent(child, 1, False, exclude_files)
        yield "</duc>"
    elif node["type"] == "dir":
        yield f'{sp}<ent type="dir" name="{html.escape(node["name"])}" size_apparent="{node["size_apparent"]}" size_actual="{node["size_actual"]}" count="{node["count"]}">'
        for child in node.get("children", []):
            if not (exclude_files and child["type"] != "dir"):
                yield from xml_ent(child, level + 1, False, exclude_files)
        yield f"{sp}</ent>"
    else:
        yield f'{sp}<ent name="{html.escape(node["name"])}" size_apparent="{node["size_apparent"]}" size_actual="{node["size_actual"]}" />'


def cmd_xml(args):
    db, rest = parse_common(args)
    exclude_files = "-x" in rest or "--exclude-files" in rest
    paths = [a for a in rest if not a.startswith("-")]
    node = find_node(load_db(db), paths[0] if paths else None)
    if node is None:
        return 1
    print('<?xml version="1.0" encoding="UTF-8"?>')
    print("\n".join(xml_ent(node, is_root=True, exclude_files=exclude_files)))
    return 0


def collect_files(node):
    if node["type"] != "dir":
        return [node]
    out = []
    for child in node.get("children", []):
        out.extend(collect_files(child))
    return out


def cmd_topn(args):
    db, rest = parse_common(args)
    bytes_mode = "-b" in rest or "--bytes" in rest
    files = []
    for root in load_db(db).get("roots", []):
        files.extend(collect_files(root))
    files.sort(key=lambda n: (-n["size_actual"], n["path"]))
    print("        Size Filename")
    for f in files[:10]:
        print(f"{format_size(f['size_actual'], bytes_mode):>12} {f['path']}")
    return 0


def cmd_histogram(args):
    db, rest = parse_common(args)
    bytes_mode = "-b" in rest or "--bytes" in rest
    data = load_db(db)
    for root in data.get("roots", []):
        print(f"Path: {root['path']}")
        print("Bkt       Size      Count")
        counts = [0] * 48
        for f in collect_files(root):
            size = f["size_apparent"] if ("-a" in rest or "--apparent" in rest) else f["size_actual"]
            bucket = 0 if size <= 1 else min(47, int(math.log(size, 2)))
            counts[bucket] += 1
        for i, count in enumerate(counts):
            print(f"{i:3d} {format_size(1 << i, bytes_mode):>10} {count:10d}")
    return 0


def cmd_graph(args):
    db, rest = parse_common(args)
    output = "duc.png"
    fmt = "png"
    paths = []
    i = 0
    while i < len(rest):
        if rest[i] in ("-o", "--output"):
            i += 1
            output = rest[i]
        elif rest[i].startswith("--output="):
            output = rest[i].split("=", 1)[1]
        elif rest[i] in ("-f", "--format"):
            i += 1
            fmt = rest[i]
        elif rest[i].startswith("--format="):
            fmt = rest[i].split("=", 1)[1]
        elif not rest[i].startswith("-"):
            paths.append(rest[i])
        i += 1
    node = find_node(load_db(db), paths[0] if paths else None)
    if node is None:
        return 1
    if fmt == "svg" or output.endswith(".svg"):
        content = f'<svg xmlns="http://www.w3.org/2000/svg" width="800" height="800"><text x="20" y="40">{html.escape(node["path"])}</text></svg>\n'
        mode = "w"
    else:
        content = b"\x89PNG\r\n\x1a\n\x00\x00\x00\rIHDR\x00\x00\x00\x01\x00\x00\x00\x01\x08\x02\x00\x00\x00\x90wS\xde\x00\x00\x00\x0cIDATx\x9cc```\x00\x00\x00\x04\x00\x01\xf6\x178U\x00\x00\x00\x00IEND\xaeB`\x82"
        mode = "wb"
    if output == "-":
        if isinstance(content, bytes):
            sys.stdout.buffer.write(content)
        else:
            sys.stdout.write(content)
    else:
        with open(output, mode) as f:
            f.write(content)
    return 0


def cmd_cgi(args):
    print("Content-Type: text/html\n")
    print("<html><body><h1>Duc</h1></body></html>")
    return 0


def main(argv):
    if not argv or argv[0] in ("-h", "--help") or argv[0] not in {c for c, _ in COMMANDS} and argv[0].startswith("-") is False:
        if argv and argv[0] == "--version":
            print("duc version: 1.5.0-rc1")
            print("options: cairo x11 ui sqlite3")
            return 0
        print(HELP)
        return 0
    if argv[0] == "--version":
        print("duc version: 1.5.0-rc1")
        print("options: cairo x11 ui sqlite3")
        return 0
    cmd, args = argv[0], argv[1:]
    if "-h" in args or "--help" in args:
        print(COMMAND_HELP.get(cmd, HELP))
        return 0
    if cmd == "help":
        if args and args[0] in COMMAND_HELP:
            print(COMMAND_HELP[args[0]])
        elif args and args[0] == "--all":
            print(HELP)
            for name, _ in COMMANDS:
                print(COMMAND_HELP.get(name, ""))
        else:
            print(HELP)
        return 0
    funcs = {
        "index": cmd_index,
        "info": cmd_info,
        "ls": cmd_ls,
        "json": cmd_json,
        "xml": cmd_xml,
        "topn": cmd_topn,
        "histogram": cmd_histogram,
        "graph": cmd_graph,
        "cgi": cmd_cgi,
        "gui": lambda a: (print("Error: DISPLAY not set", file=sys.stderr) or 1),
        "ui": lambda a: (print("Error opening terminal: unknown.", file=sys.stderr) or 1),
    }
    return funcs.get(cmd, lambda a: 0)(args)


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
