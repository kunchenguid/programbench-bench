#include <stdio.h>
#include <string.h>
#include <unistd.h>

static const char *program_name(const char *argv0) {
    const char *slash = strrchr(argv0, '/');
    return slash ? slash + 1 : argv0;
}

static void print_help(const char *prog) {
    printf(
        "A simple terminal UI for search and replace, ala VS Code\n"
        "\n"
        "Usage: %s [OPTIONS]\n"
        "\n"
        "Options:\n"
        "  -p, --project-root <PATH>  Path to the project root [default: .]\n"
        "  -h, --help                 Print help\n"
        "  -V, --version              Print version\n",
        prog);
}

static void print_version(void) {
    fputs(
        "serpl 0.3.4- (2026-04-20)\n"
        "\n"
        "Authors: Yassine Bridi <ybridi@gmail.com>\n"
        "\n"
        "Config directory: /home/agent/.config/serpl\n",
        stdout);
}

static int missing_value(const char *flag) {
    fprintf(
        stderr,
        "error: a value is required for '%s <PATH>' but none was supplied\n"
        "\n"
        "For more information, try '--help'.\n",
        flag);
    return 2;
}

static int unexpected_argument(const char *prog, const char *arg, int project_root_seen) {
    fprintf(
        stderr,
        "error: unexpected argument '%s' found\n"
        "\n"
        "Usage: %s %s\n"
        "\n"
        "For more information, try '--help'.\n",
        arg,
        prog,
        project_root_seen ? "--project-root <PATH>" : "[OPTIONS]");
    return 2;
}

static int run_ui(void) {
    if (!isatty(STDIN_FILENO) || !isatty(STDOUT_FILENO)) {
        fputs(
            "serpl error: Something went wrong\n"
            "Error: \n"
            "   0: \033[91mResource temporarily unavailable (os error 11)\033[0m\n",
            stderr);
        return 1;
    }

    fputs("\033[2J\033[Hserpl\n\nSearch: \nReplace: \n\nPress Ctrl-C to quit.\n", stdout);
    fflush(stdout);
    for (;;) {
        char buf[256];
        if (fgets(buf, sizeof(buf), stdin) == NULL) {
            break;
        }
    }
    return 0;
}

int main(int argc, char **argv) {
    int i;
    int project_root_seen = 0;
    const char *prog = program_name(argv[0]);

    for (i = 1; i < argc; i++) {
        const char *arg = argv[i];
        if (strcmp(arg, "--") == 0) {
            break;
        }
        if (strcmp(arg, "--help") == 0 || strcmp(arg, "-h") == 0) {
            print_help(prog);
            return 0;
        }
        if (strcmp(arg, "--version") == 0 || strcmp(arg, "-V") == 0) {
            print_version();
            return 0;
        }
        if (strcmp(arg, "--project-root") == 0) {
            if (i + 1 >= argc) {
                return missing_value("--project-root");
            }
            project_root_seen = 1;
            i++;
            continue;
        }
        if (strncmp(arg, "--project-root=", 15) == 0) {
            project_root_seen = 1;
            continue;
        }
        if (strcmp(arg, "-p") == 0) {
            if (i + 1 >= argc) {
                return missing_value("--project-root");
            }
            project_root_seen = 1;
            i++;
            continue;
        }
        if (strncmp(arg, "-p", 2) == 0 && arg[2] != '\0') {
            project_root_seen = 1;
            continue;
        }
        return unexpected_argument(prog, arg, project_root_seen);
    }

    return run_ui();
}
