#!/usr/bin/env python3
import json
import os
import re
import shutil
import subprocess
import sys
import uuid
from datetime import datetime, timezone
from pathlib import Path


ZERO_TIME = "0001-01-01T00:00:00Z"
STATUSES = ("pending", "active", "paused", "resolved", "template")
COMMANDS = {
    "next", "add", "template", "log", "start", "note", "stop", "done", "context",
    "modify", "edit", "undo", "sync", "open", "git", "remove", "show-projects",
    "show-tags", "show-active", "show-paused", "show-open", "show-resolved",
    "show-templates", "show-unorganised", "bash-completion", "fish-completion",
    "zsh-completion", "powershell-completion", "help", "version",
}


HELP = """Usage: dstask [id...] <cmd> [task summary/filter]

Where [task summary] is text with tags/project/priority specified. Tags are
specified with + (or - for filtering) eg: +work. The project is specified with
a project:g prefix eg: project:dstask -- no quotes. Priorities run from P3
(low), P2 (default) to P1 (high) and P0 (critical). Text can also be specified
for a substring search of description and notes.

Available commands:

next              : Show most important tasks (priority, creation date -- truncated and default)
add               : Add a task
template          : Add a task template
log               : Log a task (already resolved)
start             : Change task status to active
note              : Append to or edit note for a task
stop              : Change task status to pending
done              : Resolve a task
context           : Set global context for task list and new tasks (use "none" to set no context)
modify            : Change task attributes specified on command line
show-open         : Show all non-resolved tasks (without truncation)
show-resolved     : Show resolved tasks
version           : Show dstask version information
"""


def now():
    return datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")


def date_time(value):
    if re.fullmatch(r"\d{4}-\d{2}-\d{2}", value):
        return value + "T00:00:00Z"
    return value


def repo_path():
    path = os.environ.get("DSTASK_GIT_REPO")
    if not path:
        path = str(Path.home() / ".dstask")
    repo = Path(path)
    repo.mkdir(parents=True, exist_ok=True)
    if not (repo / ".git").exists() and shutil.which("git"):
        subprocess.run(["git", "-C", str(repo), "init"], stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    for status in STATUSES:
        (repo / status).mkdir(exist_ok=True)
    return repo


def parse_scalar(value):
    value = value.strip()
    if value == '""':
        return ""
    if len(value) >= 2 and value[0] == '"' and value[-1] == '"':
        try:
            return json.loads(value)
        except json.JSONDecodeError:
            return value[1:-1]
    return value


def read_task(path, status):
    data = {
        "summary": "",
        "notes": "",
        "tags": [],
        "project": "",
        "priority": "P2",
        "created": ZERO_TIME,
        "resolved": ZERO_TIME,
        "due": ZERO_TIME,
    }
    lines = path.read_text().splitlines()
    i = 0
    while i < len(lines):
        line = lines[i]
        if line.startswith("summary: "):
            data["summary"] = parse_scalar(line.split(": ", 1)[1])
        elif line.startswith("notes: "):
            data["notes"] = parse_scalar(line.split(": ", 1)[1])
        elif line == "tags:":
            tags = []
            i += 1
            while i < len(lines) and lines[i].startswith("- "):
                tags.append(lines[i][2:])
                i += 1
            data["tags"] = tags
            continue
        elif line.startswith("project: "):
            data["project"] = parse_scalar(line.split(": ", 1)[1])
        elif line.startswith("priority: "):
            data["priority"] = parse_scalar(line.split(": ", 1)[1])
        elif line.startswith("created: "):
            data["created"] = parse_scalar(line.split(": ", 1)[1])
        elif line.startswith("resolved: "):
            data["resolved"] = parse_scalar(line.split(": ", 1)[1])
        elif line.startswith("due: "):
            data["due"] = parse_scalar(line.split(": ", 1)[1])
        i += 1
    data["uuid"] = path.stem
    data["status"] = status
    data["path"] = path
    return data


def yaml_quote(value):
    if value == "":
        return '""'
    if "\n" in value or value.startswith(" ") or value.endswith(" ") or ":" in value:
        return json.dumps(value)
    return value


def write_task(repo, task):
    for status in STATUSES:
        old = repo / status / f"{task['uuid']}.yml"
        if old.exists() and status != task["status"]:
            old.unlink()
    path = repo / task["status"] / f"{task['uuid']}.yml"
    tags = "".join(f"- {t}\n" for t in sorted(set(task.get("tags", []))))
    text = (
        f"summary: {yaml_quote(task.get('summary', ''))}\n"
        f"notes: {yaml_quote(task.get('notes', ''))}\n"
        "tags:\n"
        f"{tags}"
        f"project: {yaml_quote(task.get('project', ''))}\n"
        f"priority: {task.get('priority', 'P2')}\n"
        'delegatedto: ""\n'
        "subtasks: []\n"
        "dependencies: []\n"
        f"created: {task.get('created', ZERO_TIME)}\n"
        f"resolved: {task.get('resolved', ZERO_TIME)}\n"
        f"due: {task.get('due', ZERO_TIME)}\n"
    )
    path.write_text(text)
    task["path"] = path


def load_id_map(repo):
    path = repo / ".dstask_ids.json"
    if path.exists():
        try:
            return json.loads(path.read_text())
        except json.JSONDecodeError:
            pass
    return {}


def save_id_map(repo, ids):
    (repo / ".dstask_ids.json").write_text(json.dumps(ids, sort_keys=True))


def load_tasks(repo):
    tasks = []
    for status in STATUSES:
        for path in sorted((repo / status).glob("*.yml")):
            tasks.append(read_task(path, status))
    tasks.sort(key=lambda t: (t.get("created", ZERO_TIME), t["uuid"]))
    ids = load_id_map(repo)
    changed = False
    next_id = max([int(v) for v in ids.values()] + [0]) + 1
    for task in tasks:
        if task["status"] == "resolved":
            task["id"] = 0
            continue
        if task["uuid"] not in ids:
            ids[task["uuid"]] = next_id
            next_id += 1
            changed = True
        task["id"] = int(ids[task["uuid"]])
    if changed:
        save_id_map(repo, ids)
    return tasks


def public_task(task):
    return {
        "uuid": task["uuid"],
        "status": task["status"],
        "id": task.get("id", 0),
        "summary": task.get("summary", ""),
        "notes": task.get("notes", ""),
        "tags": sorted(set(task.get("tags", []))),
        "project": task.get("project", ""),
        "priority": task.get("priority", "P2"),
        "created": task.get("created", ZERO_TIME),
        "resolved": task.get("resolved", ZERO_TIME),
        "due": task.get("due", ZERO_TIME),
    }


def split_ids_and_command(argv):
    ids = []
    rest = list(argv)
    while rest and rest[0].isdigit():
        ids.append(int(rest.pop(0)))
    if rest and rest[0] in COMMANDS:
        cmd = rest.pop(0)
    elif not ids and rest and rest[0] not in COMMANDS:
        cmd = "next"
    elif ids:
        cmd = rest.pop(0) if rest else "next"
    else:
        cmd = "next"
    while rest and rest[0].isdigit() and cmd in COMMANDS:
        ids.append(int(rest.pop(0)))
    return ids, cmd, rest


def parse_context(repo):
    env = os.environ.get("DSTASK_CONTEXT")
    if env is not None:
        return env.split()
    path = repo / ".dstask_context"
    return path.read_text().split() if path.exists() else []


def parse_attrs(words, include_context=None):
    attrs = {"tags_add": [], "tags_remove": [], "summary": [], "notes": []}
    in_note = False
    for word in (include_context or []) + list(words):
        if word == "--":
            continue
        if word == "/":
            in_note = True
            continue
        if in_note:
            attrs["notes"].append(word)
        elif re.fullmatch(r"P[0-3]", word):
            attrs["priority"] = word
        elif word.startswith("project:"):
            attrs["project"] = word.split(":", 1)[1]
        elif word.startswith("-project:"):
            attrs["project"] = ""
        elif word.startswith("due:"):
            attrs["due"] = date_time(word.split(":", 1)[1])
        elif word.startswith("+") and len(word) > 1:
            attrs["tags_add"].append(word[1:])
        elif word.startswith("-") and len(word) > 1:
            attrs["tags_remove"].append(word[1:])
        else:
            attrs["summary"].append(word)
    return attrs


def apply_attrs(task, attrs, replace_summary=False):
    tags = set(task.get("tags", []))
    tags.update(attrs.get("tags_add", []))
    tags.difference_update(attrs.get("tags_remove", []))
    task["tags"] = sorted(tags)
    if "project" in attrs:
        task["project"] = attrs["project"]
    if "priority" in attrs:
        task["priority"] = attrs["priority"]
    if "due" in attrs:
        task["due"] = attrs["due"]
    if replace_summary and attrs.get("summary"):
        task["summary"] = " ".join(attrs["summary"])
    if attrs.get("notes"):
        append_note(task, " ".join(attrs["notes"]))


def append_note(task, text):
    if not text:
        return
    task["notes"] = (task.get("notes", "") + ("\n\n" if task.get("notes") else "") + text)


def matches(task, attrs):
    tags = set(task.get("tags", []))
    for tag in attrs.get("tags_add", []):
        if tag not in tags:
            return False
    for tag in attrs.get("tags_remove", []):
        if tag in tags:
            return False
    if "project" in attrs and task.get("project", "") != attrs["project"]:
        return False
    for word in attrs.get("summary", []):
        needle = word.lower()
        if needle not in task.get("summary", "").lower() and needle not in task.get("notes", "").lower():
            return False
    return True


def find_by_ids(tasks, ids):
    return [task for task in tasks if task.get("id") in ids]


def priority_key(task):
    return ({"P0": 0, "P1": 1, "P2": 2, "P3": 3}.get(task.get("priority", "P2"), 2), task.get("created", ""))


def report(tasks, statuses, filter_words, repo):
    ignore_context = "--" in filter_words
    words = [w for w in filter_words if w != "--"]
    context = [] if ignore_context else parse_context(repo)
    attrs = parse_attrs(words, context)
    selected = [t for t in tasks if t["status"] in statuses and matches(t, attrs)]
    selected.sort(key=priority_key)
    print(json.dumps([public_task(t) for t in selected], indent=2))
    return 0


def git_commit(repo, message):
    if not shutil.which("git") or not (repo / ".git").exists():
        return 0
    subprocess.run(["git", "-C", str(repo), "add", "-A"], stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    proc = subprocess.run(["git", "-C", str(repo), "commit", "-m", message], text=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    if proc.stdout:
        print("\033[38;5;245m" + proc.stdout + "\033[0m", end="")
    return proc.returncode


def add_task(repo, words, status="pending"):
    ignore_context = "--" in words
    words = [w for w in words if w != "--"]
    context = [] if ignore_context else parse_context(repo)
    attrs = parse_attrs(words, context)
    task = {
        "uuid": str(uuid.uuid4()),
        "status": status,
        "summary": " ".join(attrs.get("summary", [])),
        "notes": " ".join(attrs.get("notes", [])),
        "tags": [],
        "project": "",
        "priority": "P2",
        "created": now(),
        "resolved": now() if status == "resolved" else ZERO_TIME,
        "due": ZERO_TIME,
    }
    apply_attrs(task, attrs, replace_summary=False)
    write_task(repo, task)
    tasks = load_tasks(repo)
    task = next(t for t in tasks if t["uuid"] == task["uuid"])
    verb = "Resolved" if status == "resolved" else "Added"
    message = f"{verb} {task['id']}: {task['summary']}"
    print(message)
    return git_commit(repo, message)


def change_status(repo, tasks, ids, status, words):
    selected = find_by_ids(tasks, ids)
    verb = {"active": "Started", "paused": "Stopped", "resolved": "Resolved", "pending": "Stopped"}[status]
    rc = 0
    for task in selected:
        append_note(task, " ".join(words))
        task["status"] = status
        if status == "resolved":
            task["resolved"] = now()
        write_task(repo, task)
        message = f"{verb} {task['id']}: {task['summary']}"
        print(message)
        rc = git_commit(repo, message) or rc
    return rc


def modify(repo, tasks, ids, words):
    attrs = parse_attrs(words)
    selected = find_by_ids(tasks, ids)
    rc = 0
    for task in selected:
        apply_attrs(task, attrs, replace_summary=False)
        write_task(repo, task)
        message = f"Modified {task['id']}: {task['summary']}"
        print(message)
        rc = git_commit(repo, message) or rc
    return rc


def remove(repo, tasks, ids):
    rc = 0
    for task in find_by_ids(tasks, ids):
        if task["path"].exists():
            task["path"].unlink()
        message = f"Removed {task['id']}: {task['summary']}"
        print(message)
        rc = git_commit(repo, message) or rc
    return rc


def show_tags(tasks):
    tags = sorted({tag for t in tasks if t["status"] != "resolved" for tag in t.get("tags", [])})
    print("\n".join(tags))
    return 0


def show_projects(tasks):
    projects = []
    for name in sorted({t.get("project", "") for t in tasks if t.get("project")}):
        group = [t for t in tasks if t.get("project") == name]
        open_group = [t for t in group if t["status"] != "resolved"]
        base = open_group[0] if open_group else group[0]
        projects.append({
            "name": name,
            "taskCount": len(open_group),
            "resolvedCount": len([t for t in group if t["status"] == "resolved"]),
            "active": any(t["status"] == "active" for t in group),
            "created": base.get("created", ZERO_TIME),
            "resolved": ZERO_TIME,
            "priority": base.get("priority", "P2"),
        })
    print(json.dumps(projects, indent=2))
    return 0


def set_context(repo, words):
    if not words or words == ["none"] or words == ["--"]:
        text = ""
    else:
        text = " ".join(words)
    (repo / ".dstask_context").write_text(text)
    if text:
        print(f"Context set to: {text}")
    else:
        print("Context cleared")
    return 0


def main(argv=None):
    argv = list(sys.argv[1:] if argv is None else argv)
    repo = repo_path()
    if argv in (["help"], ["--help"], ["-h"]):
        print(HELP)
        return 0
    if argv == ["version"]:
        print("Version: Unknown\nGit commit: Unknown\nBuild date: Unknown")
        return 0
    ids, cmd, words = split_ids_and_command(argv)
    tasks = load_tasks(repo)
    if cmd == "help":
        print(HELP)
        return 0
    if cmd == "version":
        print("Version: Unknown\nGit commit: Unknown\nBuild date: Unknown")
        return 0
    if cmd == "add":
        return add_task(repo, words, "pending")
    if cmd == "log":
        return add_task(repo, words, "resolved")
    if cmd == "template":
        return add_task(repo, words, "template")
    if cmd == "start" and not ids:
        return add_task(repo, words, "active")
    if cmd == "start":
        return change_status(repo, tasks, ids, "active", words)
    if cmd == "stop":
        return change_status(repo, tasks, ids, "paused", words)
    if cmd == "done":
        return change_status(repo, tasks, ids, "resolved", words)
    if cmd == "modify":
        return modify(repo, tasks, ids, words)
    if cmd == "note":
        return change_status(repo, tasks, ids, tasks[0]["status"] if tasks else "pending", words)
    if cmd == "remove":
        return remove(repo, tasks, ids)
    if cmd == "context":
        return set_context(repo, words)
    if cmd in ("show-tags",):
        return show_tags(tasks)
    if cmd == "show-projects":
        return show_projects(tasks)
    if cmd == "show-active":
        return report(tasks, {"active"}, words, repo)
    if cmd == "show-paused":
        return report(tasks, {"paused"}, words, repo)
    if cmd == "show-resolved":
        return report(tasks, {"resolved"}, words + ["--"], repo)
    if cmd == "show-templates":
        return report(tasks, {"template"}, words, repo)
    if cmd == "show-unorganised":
        return report(tasks, {"pending", "active", "paused"}, words + ["--"], repo)
    if cmd in ("show-open", "next"):
        return report(tasks, {"pending", "active", "paused"}, words, repo)
    if cmd.endswith("-completion"):
        return 0
    if cmd == "git":
        proc = subprocess.run(["git", "-C", str(repo), *words])
        return proc.returncode
    print(json.dumps([]))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
