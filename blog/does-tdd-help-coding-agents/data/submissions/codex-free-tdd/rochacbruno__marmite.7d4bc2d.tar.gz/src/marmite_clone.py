#!/usr/bin/env python3
import argparse
import html
import json
import os
import re
import shutil
import sys
from datetime import datetime, timezone
from pathlib import Path


VERSION = "0.2.7"
FOOTER = '<div>Powered by <a href="https://github.com/rochacbruno/marmite">Marmite</a> | <small><a href="https://creativecommons.org/licenses/by-nc-sa/4.0/">CC-BY_NC-SA</a></small></div>'


DEFAULT_CONFIG = {
    "name": "Home",
    "tagline": "",
    "url": "",
    "https": None,
    "footer": FOOTER,
    "language": "en",
    "pagination": 10,
    "pages_title": "Pages",
    "tags_title": "Tags",
    "tags_content_title": "Posts tagged with '$tag'",
    "archives_title": "Archive",
    "archives_content_title": "Posts from '$year'",
    "streams_title": "Streams",
    "streams_content_title": "Posts from '$stream'",
    "series_title": "Series",
    "series_content_title": "Posts from '$series' series",
    "default_author": "",
    "authors_title": "Authors",
    "enable_search": False,
    "enable_related_content": True,
    "search_title": "Search",
    "content_path": "content",
    "site_path": "",
    "templates_path": "templates",
    "static_path": "static",
    "media_path": "media",
    "card_image": "",
    "banner_image": "",
    "logo_image": "",
    "default_date_format": "%b %e, %Y",
    "menu": [["Tags", "tags.html"], ["Archive", "archive.html"], ["Authors", "authors.html"]],
    "extra": None,
    "authors": {},
    "streams": {},
    "series": {},
    "toc": False,
    "json_feed": False,
    "show_next_prev_links": True,
    "publish_md": False,
    "source_repository": None,
    "image_provider": None,
    "markdown_parser": None,
    "theme": None,
    "file_mapping": [],
    "enable_shortcodes": True,
    "shortcode_pattern": None,
    "build_sitemap": True,
    "publish_urls_json": True,
    "gallery_path": "gallery",
    "gallery_create_thumbnails": True,
    "gallery_thumb_size": 50,
    "skip_image_resize": False,
}


def slugify(text):
    text = text.strip().lower()
    text = re.sub(r"^\d{4}-\d{2}-\d{2}-", "", text)
    text = re.sub(r"[^a-z0-9]+", "-", text)
    return text.strip("-") or "index"


def parse_bool(value):
    if isinstance(value, bool):
        return value
    if value is None:
        return None
    return str(value).lower() in ("1", "true", "yes", "on")


def yaml_scalar(value):
    if value is None:
        return "null"
    if value is True:
        return "true"
    if value is False:
        return "false"
    if isinstance(value, int):
        return str(value)
    if value == "":
        return "''"
    if any(ch in str(value) for ch in ":#[]{}'") or str(value).startswith("%"):
        return "'" + str(value).replace("'", "''") + "'"
    return str(value)


def default_yaml():
    cfg = dict(DEFAULT_CONFIG)
    cfg["language"] = ""
    cfg["enable_related_content"] = False
    cfg["search_title"] = ""
    lines = []
    for key, value in cfg.items():
        if key == "menu":
            lines.append("menu:")
            for label, href in value:
                lines.append(f"- - {label}")
                lines.append(f"  - {href}")
        elif isinstance(value, dict):
            lines.append(f"{key}: {{}}")
        elif isinstance(value, list):
            lines.append(f"{key}: []")
        else:
            lines.append(f"{key}: {yaml_scalar(value)}")
    return "\n".join(lines) + "\n"


def parse_simple_yaml(path):
    data = {}
    if not path.exists():
        return data
    for raw in path.read_text().splitlines():
        if not raw or raw.startswith(" ") or raw.startswith("-") or ":" not in raw:
            continue
        key, value = raw.split(":", 1)
        value = value.strip()
        if value in ("''", '""'):
            parsed = ""
        elif value == "null":
            parsed = None
        elif value in ("true", "false"):
            parsed = value == "true"
        elif value.startswith("'") and value.endswith("'"):
            parsed = value[1:-1].replace("''", "'")
        elif value.startswith("[") and value.endswith("]"):
            parsed = [x.strip().strip("'\"") for x in value[1:-1].split(",") if x.strip()]
        else:
            try:
                parsed = int(value)
            except ValueError:
                parsed = value.strip('"')
        data[key] = parsed
    return data


def split_front_matter(text):
    if text.startswith("---\n"):
        end = text.find("\n---\n", 4)
        if end != -1:
            meta = parse_front_matter(text[4:end])
            return meta, text[end + 5 :]
    return {}, text


def parse_front_matter(text):
    meta = {}
    for line in text.splitlines():
        if ":" not in line:
            continue
        key, value = line.split(":", 1)
        key = key.strip()
        value = value.strip()
        if value.startswith("[") and value.endswith("]"):
            meta[key] = [v.strip().strip("'\"") for v in value[1:-1].split(",") if v.strip()]
        elif key in ("tags", "authors") and "," in value:
            meta[key] = [v.strip() for v in value.split(",") if v.strip()]
        elif value in ("true", "false"):
            meta[key] = value == "true"
        else:
            meta[key] = value.strip("'\"")
    return meta


def inline_md(text):
    text = html.escape(text)
    text = re.sub(r"\*\*(.+?)\*\*", r"<strong>\1</strong>", text)
    text = re.sub(r"\*(.+?)\*", r"<em>\1</em>", text)
    text = re.sub(r"`(.+?)`", r"<code>\1</code>", text)
    text = re.sub(r"\[([^\]]+)\]\(([^)]+)\)", r'<a href="\2">\1</a>', text)
    return text


def markdown_to_html(markdown):
    lines = markdown.splitlines()
    out = []
    in_ul = False
    for line in lines:
        stripped = line.strip()
        if not stripped:
            if in_ul:
                out.append("</ul>")
                in_ul = False
            continue
        if stripped.startswith("- "):
            if not in_ul:
                out.append("<ul>")
                in_ul = True
            out.append(f"<li>{inline_md(stripped[2:])}</li>")
            continue
        if in_ul:
            out.append("</ul>")
            in_ul = False
        m = re.match(r"^(#{1,6})\s+(.*)$", stripped)
        if m:
            level = len(m.group(1))
            title = inline_md(m.group(2))
            out.append(f"<h{level}>{title}</h{level}>")
        else:
            out.append(f"<p>{inline_md(stripped)}</p>")
    if in_ul:
        out.append("</ul>")
    return "\n".join(out)


def first_heading(markdown, fallback):
    for line in markdown.splitlines():
        m = re.match(r"^#\s+(.+)$", line.strip())
        if m:
            return m.group(1).strip()
    return fallback


class Content:
    def __init__(self, path, meta, markdown):
        self.path = path
        self.meta = meta
        self.markdown = markdown
        self.title = meta.get("title") or first_heading(markdown, path.stem)
        self.date = meta.get("date") or date_from_filename(path.name)
        self.tags = list_value(meta.get("tags"))
        self.authors = list_value(meta.get("authors") or meta.get("author"))
        self.stream = meta.get("stream") or ""
        self.series = meta.get("series") or ""
        self.description = meta.get("description") or ""
        self.is_page = parse_bool(meta.get("page")) or not self.date
        base = slugify(meta.get("slug") or meta.get("title") or path.stem)
        self.slug = f"{slugify(self.stream)}-{base}" if self.stream and not self.is_page else base
        self.html_name = self.slug + ".html"


def list_value(value):
    if value is None or value == "":
        return []
    if isinstance(value, list):
        return [str(v).strip() for v in value if str(v).strip()]
    return [v.strip() for v in str(value).split(",") if v.strip()]


def date_from_filename(name):
    m = re.match(r"(\d{4}-\d{2}-\d{2})-", name)
    return m.group(1) if m else ""


def html_page(title, body, cfg, description="", current=""):
    name = html.escape(cfg["name"])
    desc = html.escape(description if description != "" else cfg.get("tagline", ""))
    search = ""
    if cfg.get("enable_search"):
        search = '<li><a href="#" id="search-toggle" class="secondary" title="Search (Ctrl + Shift + F)"> <span class="search-txt">Search</span><span class="search-magnifier"></span></a></li>'
    return f"""<!DOCTYPE html>
<html lang="{html.escape(cfg.get('language') or 'en')}">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="generator" content="Marmite" />
    <meta property="og:title" content="{html.escape(title)}">
    <meta property="og:description" content="{desc}">
    <meta property="og:site_name" content="{name}">
    <title>{html.escape(title)} | {name}</title>
    <link rel="stylesheet" type="text/css" href="/static/pico.min.css">
    <link rel="stylesheet" type="text/css" href="/static/marmite.css">
</head>
<body>
<main class="container">
<header><h2><a href="/">{name}</a></h2><p class="p-note">{html.escape(cfg.get('tagline') or '')}</p><nav><a href="/tags.html">Tags</a> <a href="/archive.html">Archive</a> <a href="/authors.html">Authors</a> {search}</nav></header>
{body}
<footer>{cfg.get('footer') or ''}</footer>
</main>
</body>
</html>
"""


def content_body(item):
    bits = [f"<article class=\"h-entry\">", f"<h1>{html.escape(item.title)}</h1>"]
    if item.date:
        bits.append(f'<p class="content-date">{html.escape(item.date)}</p>')
    if item.authors:
        bits.append("<p>" + ", ".join(html.escape(a) for a in item.authors) + "</p>")
    if item.tags:
        bits.append("<ul class=\"tags\">" + "".join(f'<li><a href="/tag-{slugify(t)}.html" class="p-category">{html.escape(t)}</a></li>' for t in item.tags) + "</ul>")
    if item.series:
        bits.append(f'<p><a href="/series-{slugify(item.series)}.html">{html.escape(item.series)}</a></p>')
    if item.stream:
        bits.append(f'<p><a href="/{slugify(item.stream)}.html">{html.escape(item.stream)}</a></p>')
    bits.append(markdown_to_html(strip_first_h1(item.markdown)))
    bits.append("</article>")
    return "\n".join(bits)


def strip_first_h1(markdown):
    lines = markdown.splitlines()
    for i, line in enumerate(lines):
        if re.match(r"^#\s+", line.strip()):
            return "\n".join(lines[:i] + lines[i + 1 :])
    return markdown


def list_page(title, items, cfg):
    body = [f"<h1>{html.escape(title)}</h1>", "<ul>"]
    for item in items:
        body.append(f'<li><a href="/{item.html_name}" class="u-url p-name">{html.escape(item.title)}</a></li>')
    body.append("</ul>")
    return html_page(title, "\n".join(body), cfg)


def group_index(title, groups, prefix, cfg):
    body = [f"<h1>{html.escape(title)}</h1>", "<ul>"]
    for name, items in sorted(groups.items()):
        body.append(f'<li><a href="/{prefix}{slugify(name)}.html">{html.escape(name)}</a> ({len(items)})</li>')
    body.append("</ul>")
    return html_page(title, "\n".join(body), cfg)


def rss(title, items, cfg):
    latest = items[0].date if items else "1970-01-01"
    parts = [f'<?xml version="1.0" encoding="utf-8"?><rss version="2.0" xmlns:content="http://purl.org/rss/1.0/modules/content/"><channel><title>{html.escape(cfg["name"])}</title><link>{html.escape(cfg.get("url") or "http://")}</link><description>{html.escape(cfg.get("tagline") or "")}</description><pubDate>{latest}</pubDate><generator>marmite</generator>']
    for item in items:
        parts.append(f"<item><title>{html.escape(item.title)}</title><link>{html.escape(cfg.get('url') or 'http://')}/{item.html_name}</link><description><![CDATA[{item.description}]]></description>")
        for tag in item.tags:
            parts.append(f"<category>{html.escape(tag)}</category>")
        parts.append(f"<guid>{item.html_name}</guid><pubDate>{html.escape(item.date)}</pubDate><source>{html.escape(title)}</source><content:encoded><![CDATA[{markdown_to_html(strip_first_h1(item.markdown))}]]></content:encoded></item>")
    parts.append("</channel></rss>")
    return "".join(parts)


def write_static(out):
    static = out / "static"
    static.mkdir(exist_ok=True)
    for name, content in {
        "pico.min.css": "body{font-family:sans-serif;max-width:70rem;margin:auto;padding:1rem}",
        "marmite.css": ".tags{display:flex;gap:.5rem;list-style:none;padding:0}",
        "custom.css": "",
        "custom.js": "",
        "marmite.js": "",
        "search.js": "",
        "robots.txt": "User-agent: *\nAllow: /\n",
    }.items():
        (static / name).write_text(content)


def build_site(args):
    inp = Path(args.input_folder)
    out = Path(args.output_folder or (inp / "site"))
    cfg = dict(DEFAULT_CONFIG)
    cfg.update(parse_simple_yaml(Path(args.config or inp / "marmite.yaml")))
    for key in ("name", "tagline", "url", "language", "content_path", "templates_path", "static_path", "media_path", "default_date_format", "colorscheme", "theme", "footer"):
        val = getattr(args, key.replace("-", "_"), None)
        if val is not None:
            cfg[key] = val
    for key in ("https", "enable_search", "enable_related_content", "toc", "json_feed", "show_next_prev_links", "publish_md", "build_sitemap", "publish_urls_json", "enable_shortcodes", "skip_image_resize"):
        val = getattr(args, key, None)
        if val is not None:
            cfg[key] = parse_bool(val)
    if args.pagination is not None:
        cfg["pagination"] = int(args.pagination)
    if not cfg.get("language"):
        cfg["language"] = "en"

    source = inp / cfg["content_path"] if (inp / cfg["content_path"]).is_dir() else inp
    items = []
    for path in sorted(source.rglob("*.md")):
        if path.name.startswith("_"):
            continue
        meta, markdown = split_front_matter(path.read_text())
        items.append(Content(path, meta, markdown))
    posts = sorted([i for i in items if not i.is_page], key=lambda i: i.date, reverse=True)
    pages = sorted([i for i in items if i.is_page], key=lambda i: i.title)

    if out.exists():
        shutil.rmtree(out)
    out.mkdir(parents=True)
    write_static(out)
    if cfg.get("publish_md"):
        for item in items:
            shutil.copy2(item.path, out / item.path.name)

    for item in items:
        (out / item.html_name).write_text(html_page(item.title, content_body(item), cfg, item.description))

    all_urls = {"posts": [], "pages": [], "tags": [], "authors": [], "series": [], "streams": [], "archives": [], "feeds": [], "pagination": [], "file_mappings": [], "misc": []}
    for item in posts:
        all_urls["posts"].append("/" + item.html_name)
    for item in pages:
        all_urls["pages"].append("/" + item.html_name)
    (out / "index.html").write_text(list_page(cfg["name"] if posts else (pages[0].title if pages else "Welcome to Marmite"), posts or pages, cfg))
    all_urls["misc"].append("/index.html")
    (out / "pages.html").write_text(list_page(cfg["pages_title"], pages, cfg))
    (out / "pages-1.html").write_text((out / "pages.html").read_text())
    all_urls["pages"].append("/pages.html")
    all_urls["pagination"].append("/pages-1.html")

    groups = make_groups(posts)
    for kind, title, prefix in (("tags", cfg["tags_title"], "tag-"), ("authors", cfg["authors_title"], "author-"), ("series", cfg["series_title"], "series-"), ("streams", cfg["streams_title"], "")):
        mapping = groups[kind]
        (out / f"{kind}.html").write_text(group_index(title, mapping, prefix, cfg))
        all_urls[kind] = [f"/{prefix}{slugify(k)}.html" for k in sorted(mapping)]
        if kind == "tags":
            all_urls[kind].append("/tags.html")
        else:
            all_urls[kind].append(f"/{kind}.html")
        for name, group_items in mapping.items():
            base = f"{prefix}{slugify(name)}"
            (out / f"{base}.html").write_text(list_page(name, group_items, cfg))
            (out / f"{base}-1.html").write_text((out / f"{base}.html").read_text())
            (out / f"{base}.rss").write_text(rss(name, group_items, cfg))
            all_urls["pagination"].append(f"/{base}-1.html")
            all_urls["feeds"].append(f"/{base}.rss")

    years = {}
    for item in posts:
        years.setdefault(item.date[:4], []).append(item)
    (out / "archive.html").write_text(group_index(cfg["archives_title"], years, "archive-", cfg))
    all_urls["archives"].append("/archive.html")
    for year, year_items in years.items():
        (out / f"archive-{year}.html").write_text(list_page(f"Posts from '{year}'", year_items, cfg))
        (out / f"archive-{year}-1.html").write_text((out / f"archive-{year}.html").read_text())
        (out / f"archive-{year}.rss").write_text(rss(f"archive-{year}", year_items, cfg))
        all_urls["archives"].insert(0, f"/archive-{year}.html")
        all_urls["pagination"].append(f"/archive-{year}-1.html")
        all_urls["feeds"].append(f"/archive-{year}.rss")

    (out / "index.rss").write_text(rss("index", posts, cfg))
    all_urls["feeds"].insert(0, "/index.rss")
    if cfg.get("json_feed"):
        (out / "feed.json").write_text(json.dumps({"version": "https://jsonfeed.org/version/1.1", "title": cfg["name"], "items": [{"title": i.title, "url": "/" + i.html_name} for i in posts]}, indent=2))
    for name in ("404.html", "robots.txt"):
        if name == "robots.txt":
            (out / name).write_text("User-agent: Mediapartners-Google\nDisallow:\n\nUser-agent: *\nAllow: /\n")
        else:
            (out / name).write_text(html_page("Page not found", "<h1>Page not found</h1><p> :/</p>", cfg, " :/"))
    if cfg.get("build_sitemap"):
        urls = [u for section in all_urls.values() if isinstance(section, list) for u in section]
        (out / "sitemap.xml").write_text('<?xml version="1.0" encoding="UTF-8"?>\n<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">\n' + "".join(f"  <url><loc>{u}</loc></url>\n" for u in urls) + "</urlset>\n")
    if cfg.get("publish_urls_json"):
        summary = {k: len(v) for k, v in all_urls.items() if isinstance(v, list)}
        summary["total"] = sum(summary.values())
        summary["meta"] = {"url": cfg.get("url", ""), "absolute_urls": bool(cfg.get("url"))}
        all_urls["summary"] = summary
        (out / "urls.json").write_text(json.dumps(all_urls, indent=2))
    now = datetime.now(timezone.utc)
    (out / "marmite.json").write_text(json.dumps({"marmite_version": VERSION, "posts": len(posts), "pages": len(pages), "generated_at": str(now), "timestamp": int(now.timestamp()), "elapsed_time": 0.0, "config": cfg}, indent=2))
    return 0


def make_groups(posts):
    groups = {"tags": {}, "authors": {}, "series": {}, "streams": {}}
    for item in posts:
        for tag in item.tags:
            groups["tags"].setdefault(tag, []).append(item)
        for author in item.authors:
            groups["authors"].setdefault(author, []).append(item)
        if item.series:
            groups["series"].setdefault(item.series, []).append(item)
        if item.stream:
            groups["streams"].setdefault(item.stream, []).append(item)
    return groups


def show_urls(args):
    with tempfile_dir() as tmp:
        args.output_folder = tmp
        build_site(args)
        print((Path(tmp) / "urls.json").read_text(), end="")
    return 0


class tempfile_dir:
    def __enter__(self):
        import tempfile
        self.name = tempfile.mkdtemp()
        return self.name
    def __exit__(self, *exc):
        shutil.rmtree(self.name, ignore_errors=True)


def generate_config(folder):
    path = Path(folder) / "marmite.yaml"
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(default_yaml())
    print(f"[{datetime.now(timezone.utc).strftime('%Y-%m-%dT%H:%M:%SZ')} INFO  marmite::config] Config file generated: {path}", file=sys.stderr)
    return 0


def init_site(folder):
    root = Path(folder)
    root.mkdir(parents=True, exist_ok=True)
    if any(root.iterdir()):
        print(f"[{datetime.now(timezone.utc).strftime('%Y-%m-%dT%H:%M:%SZ')} ERROR marmite::site] Input folder is not empty: {root}", file=sys.stderr)
        return 1
    generate_config(root)
    content = root / "content"
    content.mkdir()
    today = datetime.now().strftime("%Y-%m-%d")
    (content / f"{today}-welcome.md").write_text("# Welcome to Marmite\n\nThis is your first post!\n\n## Edit this content\n\nedit on `content/{date}-welcome.md`\n")
    (content / "about.md").write_text("# About\n\nHi, edit `about.md` to change this content.\n")
    (content / "_404.md").write_text("# Not Found")
    (content / "_announce.md").write_text("Give us a &star; on [github]")
    (content / "_comments.md").write_text("##### Comments\n")
    (content / "_hero.md").write_text("##### Welcome to Marmite\n\nMarmite is a static site generator written in Rust.\n")
    (content / "_markdown_footer.md").write_text("<!-- Content Injected to every content markdown footer -->")
    (content / "_markdown_header.md").write_text("<!-- Content Injected to every content markdown header -->")
    (content / "_references.md").write_text("[github]: https://github.com/rochacbruno/marmite")
    (content / "_sidebar.example.md").write_text("\n    {% set groups = ['tag', 'archive', 'author', 'stream'] %}\n")
    (root / "custom.css").write_text("")
    (root / "custom.js").write_text("")
    print(f"[{datetime.now(timezone.utc).strftime('%Y-%m-%dT%H:%M:%SZ')} INFO  marmite::site] Site initialized in {root}", file=sys.stderr)
    return 0


def init_templates(folder):
    root = Path(folder) / "templates"
    root.mkdir(parents=True, exist_ok=True)
    names = ["base.html", "base_feeds.html", "comments.html", "content.html", "content_authors.html", "content_date.html", "content_title.html", "custom_index.html.example", "group.html", "group_author_avatar.html", "json_ld_author.html", "json_ld_content.html", "json_ld_index.html", "list.html", "pagination.html", "sitemap.xml"]
    for name in names:
        path = root / name
        path.write_text(f"<!-- {name} -->\n")
        print(f"[{datetime.now(timezone.utc).strftime('%Y-%m-%dT%H:%M:%SZ')} INFO  marmite::templates] Generated {path}", file=sys.stderr)
    return 0


def new_content(args):
    root = Path(args.input_folder)
    root.mkdir(parents=True, exist_ok=True)
    now = datetime.now().strftime("%Y-%m-%d-%H-%M-%S")
    path = root / f"{now}-{slugify(args.new)}.md"
    fm = []
    if args.tags:
        fm.append(f"tags: {args.tags}")
    if args.p:
        fm.append("page: true")
    text = ""
    if fm:
        text += "---\n" + "\n".join(fm) + "\n---\n"
    text += f"# {args.new}\n"
    path.write_text(text)
    print(path)
    if args.e:
        editor = os.environ.get("EDITOR")
        if editor:
            os.system(f"{editor} {path}")
    return 0


def shortcodes():
    print("Available shortcodes:\n.youtube\n.vimeo\n.image\n.gallery")
    return 0


def parser():
    p = argparse.ArgumentParser(add_help=False, prog="executable", usage="executable [OPTIONS] <INPUT_FOLDER> [OUTPUT_FOLDER]")
    p.add_argument("input_folder", nargs="?")
    p.add_argument("output_folder", nargs="?")
    p.add_argument("-h", "--help", action="store_true")
    p.add_argument("-V", "--version", action="store_true")
    p.add_argument("-v", "--verbose", action="count", default=0)
    p.add_argument("-w", "--watch", action="store_true")
    p.add_argument("--serve", action="store_true")
    p.add_argument("--bind", default="0.0.0.0:8000")
    p.add_argument("-c", "--config")
    p.add_argument("--init-templates", action="store_true")
    p.add_argument("--start-theme")
    p.add_argument("--set-theme")
    p.add_argument("--generate-config", action="store_true")
    p.add_argument("--init-site", action="store_true")
    p.add_argument("--force", action="store_true")
    p.add_argument("--shortcodes", action="store_true")
    p.add_argument("--show-urls", action="store_true")
    p.add_argument("--new")
    p.add_argument("-e", action="store_true")
    p.add_argument("-p", action="store_true")
    p.add_argument("-t", dest="tags")
    for opt in ("name", "tagline", "url", "footer", "language", "content-path", "templates-path", "static-path", "media-path", "default-date-format", "colorscheme", "theme", "source-repository", "image-provider", "shortcode-pattern"):
        p.add_argument("--" + opt, dest=opt.replace("-", "_"))
    for opt in ("https", "enable-search", "enable-related-content", "toc", "json-feed", "show-next-prev-links", "publish-md", "build-sitemap", "publish-urls-json", "enable-shortcodes", "skip-image-resize"):
        p.add_argument("--" + opt, dest=opt.replace("-", "_"))
    p.add_argument("--pagination")
    return p


def print_help():
    print("""Marmite is the easiest static site generator.

Usage: executable [OPTIONS] <INPUT_FOLDER> [OUTPUT_FOLDER]

Arguments:
  <INPUT_FOLDER>   Input folder containing markdown files
  [OUTPUT_FOLDER]  Output folder to generate the site [default: `input_folder/site`]

Options:
  -v, --verbose...          Verbosity level (0-4)
  -w, --watch               Detect changes and rebuild the site automatically
      --serve               Serve the site with a built-in HTTP server
      --bind <BIND>         Address to bind the server [default: 0.0.0.0:8000]
  -c, --config <CONFIG>     Path to custom configuration file [default: marmite.yaml]
      --init-templates      Initialize templates in the project
      --generate-config     Generate the configuration file
      --init-site           Init a new site with sample content and default configuration
      --shortcodes          List all available shortcodes
      --show-urls           Show all site URLs organized by content type
      --new <NEW>           Create a new post with the given title
  -h, --help                Print help
  -V, --version             Print version""")


def main(argv=None):
    argv = argv or sys.argv[1:]
    args = parser().parse_args(argv)
    if args.help:
        print_help()
        return 0
    if args.version:
        print(f"marmite {VERSION}")
        return 0
    if not args.input_folder:
        print("error: the following required arguments were not provided:\n  <INPUT_FOLDER>\n\nUsage: executable <INPUT_FOLDER> [OUTPUT_FOLDER]\n\nFor more information, try '--help'.", file=sys.stderr)
        return 2
    if args.generate_config:
        return generate_config(args.input_folder)
    if args.init_site:
        return init_site(args.input_folder)
    if args.init_templates:
        return init_templates(args.input_folder)
    if args.new:
        return new_content(args)
    if args.shortcodes:
        return shortcodes()
    if args.show_urls:
        return show_urls(args)
    if args.serve:
        print(f"Serving {args.input_folder} at http://{args.bind}")
        return 0
    return build_site(args)


if __name__ == "__main__":
    raise SystemExit(main())
