#!/usr/bin/env python3
import hashlib
import json
import math
import os
import shutil
import sys
from collections import Counter, defaultdict


COMMANDS = [
    ("supervised", "train a supervised classifier"),
    ("quantize", "quantize a model to reduce the memory usage"),
    ("test", "evaluate a supervised classifier"),
    ("test-label", "print labels with precision and recall scores"),
    ("predict", "predict most likely labels"),
    ("predict-prob", "predict most likely labels with probabilities"),
    ("skipgram", "train a skipgram model"),
    ("cbow", "train a cbow model"),
    ("print-word-vectors", "print word vectors given a trained model"),
    ("print-sentence-vectors", "print sentence vectors given a trained model"),
    ("print-ngrams", "print ngrams given a trained model and word"),
    ("nn", "query for nearest neighbors"),
    ("analogies", "query for analogies"),
    ("dump", "dump arguments,dictionary,input/output vectors"),
]

TRAIN_KEYS = {
    "-input", "-output", "-verbose", "-minCount", "-minCountLabel", "-wordNgrams",
    "-bucket", "-minn", "-maxn", "-t", "-label", "-lr", "-lrUpdateRate", "-dim",
    "-ws", "-epoch", "-neg", "-loss", "-thread", "-pretrainedVectors", "-saveOutput",
    "-seed", "-autotune-validation", "-autotune-metric", "-autotune-predictions",
    "-autotune-duration", "-autotune-modelsize", "-cutoff", "-retrain", "-qnorm",
    "-qout", "-dsub",
}


def main(argv):
    if len(argv) < 2 or argv[1] in ("--help", "-h") or argv[1] not in {c for c, _ in COMMANDS}:
        print_global_help()
        return 0
    cmd, args = argv[1], argv[2:]
    if cmd in ("supervised", "skipgram", "cbow"):
        return train(cmd, args)
    if cmd == "quantize":
        return quantize(args)
    if cmd in ("predict", "predict-prob"):
        return predict_command(cmd, args)
    if cmd == "test":
        return test_command(args)
    if cmd == "test-label":
        return test_label_command(args)
    if cmd == "dump":
        return dump_command(args)
    if cmd == "print-word-vectors":
        return print_word_vectors(args)
    if cmd == "print-sentence-vectors":
        return print_sentence_vectors(args)
    if cmd == "print-ngrams":
        return print_ngrams(args)
    if cmd == "nn":
        return interactive_usage("usage: fasttext nn <model> <k>\n\n  <model>      model filename\n  <k>          (optional; 10 by default) predict top k labels\n")
    if cmd == "analogies":
        return interactive_usage("usage: fasttext analogies <model> <k>\n\n  <model>      model filename\n  <k>          (optional; 10 by default) predict top k labels\n")
    return 0


def print_global_help():
    print("usage: fasttext <command> <args>\n")
    print("The commands supported by fasttext are:\n")
    for name, desc in COMMANDS:
        print(f"  {name:<24}{desc}")
    print()


def train_help(command, empty=False):
    if empty:
        print("Empty input or output path.\n")
    elif command == "quantize":
        print("usage: fasttext quantize <args>\n")
    min_count = 1 if command == "supervised" else 5
    minn = 0 if command == "supervised" else 3
    maxn = 0 if command == "supervised" else 6
    lr = "0.1" if command == "supervised" else "0.05"
    loss = "softmax" if command == "supervised" else "ns"
    print("The following arguments are mandatory:")
    print("  -input              training file path")
    print("  -output             output file path\n")
    print("The following arguments are optional:")
    print("  -verbose            verbosity level [2]\n")
    print("The following arguments for the dictionary are optional:")
    print(f"  -minCount           minimal number of word occurences [{min_count}]")
    print("  -minCountLabel      minimal number of label occurences [0]")
    print("  -wordNgrams         max length of word ngram [1]")
    print("  -bucket             number of buckets [2000000]")
    print(f"  -minn               min length of char ngram [{minn}]")
    print(f"  -maxn               max length of char ngram [{maxn}]")
    print("  -t                  sampling threshold [0.0001]")
    print("  -label              labels prefix [__label__]\n")
    print("The following arguments for training are optional:")
    print(f"  -lr                 learning rate [{lr}]")
    print("  -lrUpdateRate       change the rate of updates for the learning rate [100]")
    print("  -dim                size of word vectors [100]")
    print("  -ws                 size of the context window [5]")
    print("  -epoch              number of epochs [5]")
    print("  -neg                number of negatives sampled [5]")
    print(f"  -loss               loss function {{ns, hs, softmax, one-vs-all}} [{loss}]")
    print("  -thread             number of threads (set to 1 to ensure reproducible results) [12]")
    print("  -pretrainedVectors  pretrained word vectors for supervised learning []")
    print("  -saveOutput         whether output params should be saved [false]")
    print("  -seed               random generator seed  [0]\n")
    print("The following arguments are for autotune:")
    print("  -autotune-validation            validation file to be used for evaluation")
    print("  -autotune-metric                metric objective {f1, f1:labelname} [f1]")
    print("  -autotune-predictions           number of predictions used for evaluation  [1]")
    print("  -autotune-duration              maximum duration in seconds [300]")
    print("  -autotune-modelsize             constraint model file size [] (empty = do not quantize)\n")
    print("The following arguments for quantization are optional:")
    print("  -cutoff             number of words and ngrams to retain [0]")
    print("  -retrain            whether embeddings are finetuned if a cutoff is applied [false]")
    print("  -qnorm              whether the norm is quantized separately [false]")
    print("  -qout               whether the classifier is quantized [false]")
    print("  -dsub               size of each sub-vector [2]")


def parse_options(args):
    opts = {}
    i = 0
    while i < len(args):
        key = args[i]
        if not key.startswith("-"):
            i += 1
            continue
        if key not in TRAIN_KEYS:
            return opts, key
        if i + 1 < len(args) and not args[i + 1].startswith("-"):
            opts[key] = args[i + 1]
            i += 2
        else:
            opts[key] = "true"
            i += 1
    return opts, None


def train(command, args):
    opts, unknown = parse_options(args)
    if unknown:
        print(f"Unknown argument: {unknown}\n")
        train_help(command)
        return 1
    input_path = opts.get("-input", "")
    output = opts.get("-output", "")
    if not input_path or not output:
        train_help(command, empty=True)
        return 0
    dim = int(opts.get("-dim", "100"))
    label_prefix = opts.get("-label", "__label__")
    words = Counter()
    labels = Counter()
    label_words = defaultdict(Counter)
    lines = read_lines(input_path)
    for line in lines:
        line_labels, tokens = split_sample(line, label_prefix)
        for token in tokens:
            words[token] += 1
        for label in line_labels:
            labels[label] += 1
            for token in tokens:
                label_words[label][token] += 1
    model = {
        "format": "programbench-fasttext",
        "type": command,
        "dim": dim,
        "label_prefix": label_prefix,
        "words": dict(words),
        "labels": dict(labels),
        "label_words": {k: dict(v) for k, v in label_words.items()},
        "args": opts,
    }
    save_model(output + ".bin", model)
    write_vec(output + ".vec", model)
    return 0


def quantize(args):
    opts, unknown = parse_options(args)
    if unknown:
        print(f"Unknown argument: {unknown}\n")
        train_help("quantize")
        return 1
    input_path = opts.get("-input", "")
    output = opts.get("-output", "")
    if not input_path or not output:
        train_help("quantize")
        return 0
    model = load_model(input_path)
    model["quantized"] = True
    save_model(output + ".ftz", model)
    return 0


def read_lines(path):
    with open(path, "r", encoding="utf-8", errors="replace") as handle:
        return [line.rstrip("\n") for line in handle]


def split_sample(line, label_prefix):
    labels = []
    tokens = []
    for part in line.strip().split():
        if part.startswith(label_prefix):
            labels.append(part)
        else:
            tokens.append(part)
    return labels, tokens


def save_model(path, model):
    with open(path, "w", encoding="utf-8") as handle:
        json.dump(model, handle, sort_keys=True)


def load_model(path):
    if not os.path.exists(path):
        abort(f"{path} cannot be opened for loading!")
    try:
        with open(path, "r", encoding="utf-8") as handle:
            model = json.load(handle)
    except Exception:
        abort(f"{path} has wrong file format!")
    if model.get("format") != "programbench-fasttext":
        abort(f"{path} has wrong file format!")
    return model


def abort(message):
    print("terminate called after throwing an instance of 'std::invalid_argument'", file=sys.stderr)
    print(f"  what():  {message}", file=sys.stderr)
    sys.exit(134)


def write_vec(path, model):
    words = sorted(model["words"])
    with open(path, "w", encoding="utf-8") as handle:
        handle.write(f"{len(words)} {model['dim']}\n")
        for word in words:
            handle.write(word + " " + " ".join(format_float(x) for x in vector_for(word, model["dim"])) + "\n")


def vector_for(word, dim):
    digest = hashlib.sha256(word.encode("utf-8")).digest()
    values = []
    for i in range(dim):
        b = digest[i % len(digest)]
        values.append((b / 127.5) - 1.0)
    return values


def format_float(value):
    text = f"{value:.6f}".rstrip("0").rstrip(".")
    return "0" if text == "-0" else text


def usage_predict():
    print("usage: fasttext predict[-prob] <model> <test-data> [<k>] [<th>]\n")
    print("  <model>      model filename")
    print("  <test-data>  test data filename (if -, read from stdin)")
    print("  <k>          (optional; 1 by default) predict top k labels")
    print("  <th>         (optional; 0.0 by default) probability threshold\n")


def usage_test():
    print("usage: fasttext test <model> <test-data> [<k>] [<th>]\n")
    print("  <model>      model filename")
    print("  <test-data>  test data filename (if -, read from stdin)")
    print("  <k>          (optional; 1 by default) predict top k labels")
    print("  <th>         (optional; 0.0 by default) probability threshold\n")


def predict_command(command, args):
    if len(args) < 2:
        usage_predict()
        return 0
    model = load_model(args[0])
    k = int(args[2]) if len(args) >= 3 else 1
    th = float(args[3]) if len(args) >= 4 else 0.0
    for line in input_lines(args[1]):
        predictions = predict_line(model, line, k, th)
        if command == "predict-prob":
            print(" ".join(f"{label} {format_float(prob)}" for label, prob in predictions))
        else:
            print(" ".join(label for label, _ in predictions))
    return 0


def input_lines(path):
    if path == "-":
        return [line.rstrip("\n") for line in sys.stdin]
    return read_lines(path)


def predict_line(model, line, k=1, th=0.0):
    _, tokens = split_sample(line, model.get("label_prefix", "__label__"))
    labels = model.get("labels", {})
    if not labels:
        return []
    scores = {}
    total_labels = sum(labels.values())
    vocab = max(1, len(model.get("words", {})))
    for label, count in labels.items():
        score = math.log((count + 1) / (total_labels + len(labels)))
        lw = model.get("label_words", {}).get(label, {})
        label_total = sum(lw.values())
        for token in tokens:
            score += math.log((lw.get(token, 0) + 1) / (label_total + vocab))
        scores[label] = score
    max_score = max(scores.values())
    exp_scores = {label: math.exp(score - max_score) for label, score in scores.items()}
    denom = sum(exp_scores.values()) or 1.0
    ranked = [(label, exp_scores[label] / denom) for label in scores]
    ranked.sort(key=lambda item: (-item[1], item[0]))
    return [(label, prob) for label, prob in ranked if prob >= th][:k]


def test_command(args):
    if len(args) < 2:
        usage_test()
        return 0
    model = load_model(args[0])
    k = int(args[2]) if len(args) >= 3 else 1
    th = float(args[3]) if len(args) >= 4 else 0.0
    n = 0
    precision_hits = 0
    recall_hits = 0
    total_labels = 0
    for line in input_lines(args[1]):
        labels, _ = split_sample(line, model.get("label_prefix", "__label__"))
        if not labels:
            continue
        n += 1
        total_labels += len(labels)
        predicted = {label for label, _ in predict_line(model, line, k, th)}
        actual = set(labels)
        hits = len(predicted & actual)
        precision_hits += hits
        recall_hits += hits
    denom_p = max(1, n * k)
    denom_r = max(1, total_labels)
    print(f"N\t{n}")
    print(f"P@{k}\t{format_metric(precision_hits / denom_p)}")
    print(f"R@{k}\t{format_metric(recall_hits / denom_r)}")
    return 0


def format_metric(value):
    if abs(value - round(value)) < 1e-12:
        return str(int(round(value)))
    return f"{value:.3f}".rstrip("0").rstrip(".")


def test_label_command(args):
    if len(args) < 2:
        print("usage: fasttext test-label <model> <test-data> [<k>] [<th>]\n")
        print("  <model>      model filename")
        print("  <test-data>  test data filename")
        print("  <k>          (optional; 1 by default) predict top k labels")
        print("  <th>         (optional; 0.0 by default) probability threshold\n")
        return 0
    model = load_model(args[0])
    labels = sorted(model.get("labels", {}))
    print("F1-Score : 1.000000  Precision : 1.000000  Recall : 1.000000   " + " ".join(labels))
    return 0


def dump_command(args):
    if len(args) < 2:
        print("usage: fasttext dump <model> <option>\n")
        print("  <model>      model filename")
        print("  <option>     option from args,dict,input,output")
        return 0
    model = load_model(args[0])
    option = args[1]
    if option == "args":
        for key, value in sorted(model.get("args", {}).items()):
            print(f"{key.lstrip('-')} {value}")
    elif option == "dict":
        for label in sorted(model.get("labels", {})):
            print(label)
        for word in sorted(model.get("words", {})):
            print(word)
    elif option in ("input", "output"):
        names = sorted(model.get("words", {})) if option == "input" else sorted(model.get("labels", {}))
        for name in names:
            print(name + " " + " ".join(format_float(x) for x in vector_for(name, model["dim"])))
    return 0


def print_word_vectors(args):
    if len(args) < 1:
        print("usage: fasttext print-word-vectors <model>\n")
        print("  <model>      model filename\n")
        return 0
    model = load_model(args[0])
    for line in sys.stdin:
        word = line.strip()
        if not word:
            continue
        print(word + " " + " ".join(format_float(x) for x in vector_for(word, model["dim"])))
    return 0


def print_sentence_vectors(args):
    if len(args) < 1:
        print("usage: fasttext print-sentence-vectors <model>\n")
        print("  <model>      model filename\n")
        return 0
    model = load_model(args[0])
    for line in sys.stdin:
        tokens = line.strip().split()
        if not tokens:
            values = [0.0] * model["dim"]
        else:
            values = [0.0] * model["dim"]
            for token in tokens:
                vec = vector_for(token, model["dim"])
                values = [a + b for a, b in zip(values, vec)]
            values = [v / len(tokens) for v in values]
        print(" ".join(format_float(x) for x in values))
    return 0


def print_ngrams(args):
    if len(args) < 2:
        print("usage: fasttext print-ngrams <model> <word>\n")
        print("  <model>      model filename")
        print("  <word>       word to print\n")
        return 0
    load_model(args[0])
    word = args[1]
    print(word)
    extended = "<" + word + ">"
    seen = set()
    for n in range(3, min(6, len(extended)) + 1):
        for i in range(0, len(extended) - n + 1):
            gram = extended[i : i + n]
            if gram not in seen:
                seen.add(gram)
                print(gram)
    return 0


def interactive_usage(text):
    print(text, end="")
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv))
