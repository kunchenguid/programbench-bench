import os
import subprocess
import tempfile
import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
BIN = ROOT / "executable"


class FastTextCliTests(unittest.TestCase):
    def run_cmd(self, args, input_text=None, cwd=None):
        return subprocess.run(
            [str(BIN)] + args,
            input=input_text,
            text=True,
            cwd=cwd or ROOT,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            check=False,
        )

    def test_top_level_help_lists_supported_commands(self):
        result = self.run_cmd(["--help"])
        self.assertEqual(result.returncode, 0)
        self.assertIn("usage: fasttext <command> <args>", result.stdout)
        self.assertIn("supervised              train a supervised classifier", result.stdout)
        self.assertIn("print-sentence-vectors  print sentence vectors given a trained model", result.stdout)

    def test_supervised_without_paths_prints_training_options(self):
        result = self.run_cmd(["supervised"])
        self.assertEqual(result.returncode, 0)
        self.assertIn("Empty input or output path.", result.stdout)
        self.assertIn("-input              training file path", result.stdout)
        self.assertIn("-loss               loss function {ns, hs, softmax, one-vs-all} [softmax]", result.stdout)

    def test_unknown_training_argument_fails_with_message(self):
        result = self.run_cmd(["supervised", "-input", "x", "-output", "m", "-bogus", "1"])
        self.assertEqual(result.returncode, 1)
        self.assertIn("Unknown argument: -bogus", result.stdout)

    def test_supervised_train_predict_test_and_dump(self):
        with tempfile.TemporaryDirectory() as td:
            work = Path(td)
            (work / "train.txt").write_text(
                "__label__pos good nice excellent\n"
                "__label__neg bad awful terrible\n"
                "__label__pos good great nice\n"
                "__label__neg bad poor awful\n",
                encoding="utf-8",
            )
            (work / "test.txt").write_text(
                "__label__pos good nice\n"
                "__label__neg bad awful\n"
                "__label__pos excellent great\n",
                encoding="utf-8",
            )
            train = self.run_cmd(
                [
                    "supervised",
                    "-input",
                    "train.txt",
                    "-output",
                    "model",
                    "-epoch",
                    "1",
                    "-dim",
                    "4",
                    "-thread",
                    "1",
                    "-verbose",
                    "0",
                ],
                cwd=work,
            )
            self.assertEqual(train.returncode, 0, train.stderr)
            self.assertTrue((work / "model.bin").exists())
            self.assertTrue((work / "model.vec").exists())

            pred = self.run_cmd(["predict", "model.bin", "test.txt"], cwd=work)
            self.assertEqual(pred.returncode, 0)
            self.assertEqual(pred.stdout.splitlines(), ["__label__pos", "__label__neg", "__label__pos"])

            prob = self.run_cmd(["predict-prob", "model.bin", "test.txt", "2"], cwd=work)
            self.assertEqual(prob.returncode, 0)
            self.assertRegex(prob.stdout.splitlines()[0], r"^__label__pos 0\.\d+ __label__neg 0\.\d+$")

            test = self.run_cmd(["test", "model.bin", "test.txt"], cwd=work)
            self.assertEqual(test.returncode, 0)
            self.assertIn("N\t3", test.stdout)
            self.assertIn("P@1\t1", test.stdout)
            self.assertIn("R@1\t1", test.stdout)

            dump = self.run_cmd(["dump", "model.bin", "dict"], cwd=work)
            self.assertEqual(dump.returncode, 0)
            self.assertIn("__label__pos", dump.stdout)
            self.assertIn("good", dump.stdout)

    def test_vectors_ngrams_and_quantize(self):
        with tempfile.TemporaryDirectory() as td:
            work = Path(td)
            (work / "train.txt").write_text("alpha beta gamma\nalpha beta\n", encoding="utf-8")
            train = self.run_cmd(
                ["skipgram", "-input", "train.txt", "-output", "vec", "-dim", "3", "-minCount", "1", "-verbose", "0"],
                cwd=work,
            )
            self.assertEqual(train.returncode, 0, train.stderr)

            vectors = self.run_cmd(["print-word-vectors", "vec.bin"], input_text="alpha\nomega\n", cwd=work)
            self.assertEqual(vectors.returncode, 0)
            rows = vectors.stdout.splitlines()
            self.assertEqual(len(rows), 2)
            self.assertEqual(rows[0].split()[0], "alpha")
            self.assertEqual(len(rows[0].split()), 4)

            sent = self.run_cmd(["print-sentence-vectors", "vec.bin"], input_text="alpha beta\n", cwd=work)
            self.assertEqual(sent.returncode, 0)
            self.assertEqual(len(sent.stdout.split()), 3)

            ngrams = self.run_cmd(["print-ngrams", "vec.bin", "alpha"], cwd=work)
            self.assertEqual(ngrams.returncode, 0)
            self.assertIn("alpha", ngrams.stdout)

            quant = self.run_cmd(["quantize", "-input", "vec.bin", "-output", "small"], cwd=work)
            self.assertEqual(quant.returncode, 0)
            self.assertTrue((work / "small.ftz").exists())


if __name__ == "__main__":
    unittest.main()
