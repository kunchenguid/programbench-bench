#!/usr/bin/env python3
import csv
import itertools
import json
import math
import os
import shlex
import statistics
import subprocess
import sys
import time
from pathlib import Path


VERSION = "hyperfine 1.20.0"
WARNING_FAST = (
    "  Warning: Command took less than 5 ms to complete. Note that the results might be "
    "inaccurate because hyperfine can not calibrate the shell startup time much more precise "
    "than this limit. You can try to use the `-N`/`--shell=none` option to disable the shell "
    "completely."
)


HELP = """A command-line benchmarking tool.

Usage: executable [OPTIONS] <command>...

Arguments:
  <command>...
          The command to benchmark. This can be the name of an executable, a
          command line like "grep -i todo" or a shell command like "sleep 0.5 &&
          echo test". The latter is only available if the shell is not
          explicitly disabled via '--shell=none'. If multiple commands are
          given, hyperfine will show a comparison of the respective runtimes.

Options:
  -w, --warmup <NUM>
          Perform NUM warmup runs before the actual benchmark.
  -m, --min-runs <NUM>
          Perform at least NUM runs for each command (default: 10).
  -M, --max-runs <NUM>
          Perform at most NUM runs for each command.
  -r, --runs <NUM>
          Perform exactly NUM runs for each command.
  -s, --setup <CMD>
          Execute CMD before each set of timing runs.
      --reference <CMD>
          The reference command for the relative comparison of results.
      --reference-name <CMD>
          Give a meaningful name to the reference command.
  -p, --prepare <CMD>
          Execute CMD before each timing run.
  -C, --conclude <CMD>
          Execute CMD after each timing run.
  -c, --cleanup <CMD>
          Execute CMD after the completion of all benchmarking runs.
  -P, --parameter-scan <VAR> <MIN> <MAX>
          Perform benchmark runs for each value in the range MIN..MAX.
  -D, --parameter-step-size <DELTA>
          This argument requires --parameter-scan to be specified as well.
  -L, --parameter-list <VAR> <VALUES>
          Perform benchmark runs for each value in the comma-separated list VALUES.
  -S, --shell <SHELL>
          Set the shell to use for executing benchmarked commands.
  -N
          An alias for '--shell=none'.
  -i, --ignore-failure[=<MODE>]
          Ignore failures of the benchmarked programs.
      --style <TYPE>
          Set output style type (default: auto).
      --sort <METHOD>
          Specify the sort order of the speed comparison summary and exported tables.
  -u, --time-unit <UNIT>
          Set the time unit to be used. Possible values: microsecond, millisecond, second.
      --export-asciidoc <FILE>
          Export the timing summary statistics as an AsciiDoc table to the given FILE.
      --export-csv <FILE>
          Export the timing summary statistics as CSV to the given FILE.
      --export-json <FILE>
          Export the timing summary statistics and timings of individual runs as JSON.
      --export-markdown <FILE>
          Export the timing summary statistics as a Markdown table to the given FILE.
      --export-orgmode <FILE>
          Export the timing summary statistics as an Emacs org-mode table.
      --show-output
          Print the stdout and stderr of the benchmark instead of suppressing it.
      --output <WHERE>
          Control where the output of the benchmark is redirected.
      --input <WHERE>
          Control where the input of the benchmark comes from.
  -n, --command-name <NAME>
          Give a meaningful name to a command.
  -h, --help
          Print help
  -V, --version
          Print version
"""


class Options:
    def __init__(self):
        self.warmup = 0
        self.min_runs = 10
        self.max_runs = None
        self.runs = None
        self.setup = None
        self.prepare = []
        self.conclude = []
        self.cleanup = None
        self.parameter_scan = None
        self.parameter_step = None
        self.parameter_lists = []
        self.shell = "default"
        self.ignore_failure = None
        self.style = "auto"
        self.style_was_set = False
        self.sort = "auto"
        self.time_unit = None
        self.exports = {}
        self.show_output = False
        self.outputs = []
        self.input = "null"
        self.command_names = []
        self.reference = None
        self.reference_name = None
        self.commands = []


def err(msg, usage="Usage: executable [OPTIONS] <command>..."):
    sys.stderr.write(msg + "\n\n" + usage + "\n\nFor more information, try '--help'.\n")
    return 2


def need_value(args, i, opt):
    if i + 1 >= len(args):
        raise ValueError(f"error: a value is required for '{opt} <VALUE>' but none was supplied")
    return args[i + 1], i + 2


def parse_args(argv):
    opts = Options()
    i = 0
    while i < len(argv):
        arg = argv[i]
        if arg == "--":
            opts.commands.extend(argv[i + 1 :])
            break
        if not arg.startswith("-") or arg == "-":
            opts.commands.extend(argv[i:])
            break
        if arg in ("-h", "--help"):
            print(HELP, end="")
            sys.exit(0)
        if arg in ("-V", "--version"):
            print(VERSION)
            sys.exit(0)
        name, eq, inline = arg.partition("=")
        try:
            if name in ("-w", "--warmup"):
                v, i = (inline, i + 1) if eq else need_value(argv, i, arg)
                opts.warmup = int(v)
            elif name in ("-m", "--min-runs"):
                v, i = (inline, i + 1) if eq else need_value(argv, i, arg)
                opts.min_runs = int(v)
            elif name in ("-M", "--max-runs"):
                v, i = (inline, i + 1) if eq else need_value(argv, i, arg)
                opts.max_runs = int(v)
            elif name in ("-r", "--runs"):
                v, i = (inline, i + 1) if eq else need_value(argv, i, arg)
                opts.runs = int(v)
            elif name in ("-s", "--setup"):
                opts.setup, i = (inline, i + 1) if eq else need_value(argv, i, arg)
            elif name == "--reference":
                opts.reference, i = (inline, i + 1) if eq else need_value(argv, i, arg)
            elif name == "--reference-name":
                opts.reference_name, i = (inline, i + 1) if eq else need_value(argv, i, arg)
            elif name in ("-p", "--prepare"):
                v, i = (inline, i + 1) if eq else need_value(argv, i, arg)
                opts.prepare.append(v)
            elif name in ("-C", "--conclude"):
                v, i = (inline, i + 1) if eq else need_value(argv, i, arg)
                opts.conclude.append(v)
            elif name in ("-c", "--cleanup"):
                opts.cleanup, i = (inline, i + 1) if eq else need_value(argv, i, arg)
            elif name in ("-P", "--parameter-scan"):
                if i + 3 >= len(argv):
                    raise ValueError("error: the following required arguments were not provided:\n  <VAR> <MIN> <MAX>")
                opts.parameter_scan = (argv[i + 1], argv[i + 2], argv[i + 3])
                i += 4
            elif name in ("-D", "--parameter-step-size"):
                opts.parameter_step, i = (inline, i + 1) if eq else need_value(argv, i, arg)
            elif name in ("-L", "--parameter-list"):
                if i + 2 >= len(argv):
                    raise ValueError("error: the following required arguments were not provided:\n  <VAR> <VALUES>")
                opts.parameter_lists.append((argv[i + 1], argv[i + 2].split(",")))
                i += 3
            elif name in ("-S", "--shell"):
                opts.shell, i = (inline, i + 1) if eq else need_value(argv, i, arg)
            elif arg == "-N":
                opts.shell = "none"
                i += 1
            elif name in ("-i", "--ignore-failure"):
                opts.ignore_failure = inline if eq else "all-non-zero"
                i += 1
            elif name == "--style":
                opts.style, i = (inline, i + 1) if eq else need_value(argv, i, arg)
                opts.style_was_set = True
            elif name == "--sort":
                opts.sort, i = (inline, i + 1) if eq else need_value(argv, i, arg)
            elif name in ("-u", "--time-unit"):
                opts.time_unit, i = (inline, i + 1) if eq else need_value(argv, i, arg)
            elif name.startswith("--export-"):
                key = name[len("--export-") :]
                opts.exports[key], i = (inline, i + 1) if eq else need_value(argv, i, arg)
            elif name == "--show-output":
                opts.show_output = True
                i += 1
            elif name == "--output":
                v, i = (inline, i + 1) if eq else need_value(argv, i, arg)
                opts.outputs.append(v)
            elif name == "--input":
                opts.input, i = (inline, i + 1) if eq else need_value(argv, i, arg)
            elif name in ("-n", "--command-name"):
                v, i = (inline, i + 1) if eq else need_value(argv, i, arg)
                opts.command_names.append(v)
            else:
                tip = ""
                if arg.startswith("--"):
                    tip = f"\n\n  tip: to pass '{arg}' as a value, use '-- {arg}'"
                raise ValueError(f"error: unexpected argument '{arg}' found{tip}")
        except ValueError as exc:
            return opts, str(exc)
    return opts, None


def decimalish_values(start, stop, step):
    if any("." in x for x in (start, stop, step)):
        a, b, d = float(start), float(stop), float(step)
        values = []
        x = a
        epsilon = abs(d) / 1_000_000
        while (d > 0 and x <= b + epsilon) or (d < 0 and x >= b - epsilon):
            values.append(("%g" % x))
            x += d
        return values
    a, b, d = int(start), int(stop), int(step)
    return [str(x) for x in range(a, b + (1 if d > 0 else -1), d)]


def expand_commands(opts):
    params = []
    if opts.parameter_scan:
        var, start, stop = opts.parameter_scan
        params.append((var, decimalish_values(start, stop, opts.parameter_step or "1")))
    params.extend(opts.parameter_lists)
    combos = [({}, opts.commands)] if not params else []
    if params:
        for values in itertools.product(*[p[1] for p in params]):
            mapping = {params[i][0]: values[i] for i in range(len(params))}
            expanded = []
            for cmd in opts.commands:
                for key, val in mapping.items():
                    cmd = cmd.replace("{" + key + "}", val)
                expanded.append(cmd)
            combos.append((mapping, expanded))
    benchmarks = []
    for mapping, commands in combos:
        for index, cmd in enumerate(commands):
            display = opts.command_names[index] if index < len(opts.command_names) else cmd
            benchmarks.append({"command": cmd, "display": display, "parameters": dict(mapping)})
    return benchmarks


def replaced(text, params):
    if text is None:
        return None
    for key, val in params.items():
        text = text.replace("{" + key + "}", val)
    return text


def run_command(command, opts, params, iteration=0, timed=False, visible=False):
    env = os.environ.copy()
    env["HYPERFINE_ITERATION"] = str(iteration)
    stdin = subprocess.DEVNULL if opts.input == "null" else open(opts.input, "rb")
    stdout_target = stderr_target = subprocess.DEVNULL
    opened = []
    if visible or opts.show_output:
        stdout_target = None
        stderr_target = None
    else:
        where = opts.outputs[0] if opts.outputs else "null"
        if where == "pipe":
            stdout_target = subprocess.PIPE
        elif where == "inherit":
            stdout_target = None
            stderr_target = None
        elif where != "null":
            f = open(where, "ab")
            opened.append(f)
            stdout_target = f
            stderr_target = f
    shell_mode = opts.shell not in ("none",)
    if opts.shell == "default":
        popen_arg = command
        shell_arg = True
        executable = None
    elif opts.shell == "none":
        popen_arg = shlex.split(command)
        shell_arg = False
        executable = None
    else:
        shell_parts = shlex.split(opts.shell)
        popen_arg = shell_parts + ["-c", command]
        shell_arg = False
        executable = None
    start = time.perf_counter()
    try:
        proc = subprocess.run(
            popen_arg,
            shell=shell_arg,
            executable=executable,
            stdin=stdin,
            stdout=stdout_target,
            stderr=stderr_target,
            env=env,
        )
    finally:
        if stdin is not subprocess.DEVNULL:
            stdin.close()
        for f in opened:
            f.close()
    elapsed = time.perf_counter() - start
    return proc.returncode, max(elapsed, 0.0)


def should_ignore(code, mode):
    if code == 0:
        return True
    if mode in (None, ""):
        return False
    if mode == "all-non-zero":
        return True
    try:
        return code in {int(x) for x in mode.split(",") if x}
    except ValueError:
        return False


def bench_one(bench, opts, ordinal):
    params = bench["parameters"]
    if opts.style != "none":
        print(f"Benchmark {ordinal}: {bench['display']}")
    if opts.setup:
        run_command(replaced(opts.setup, params), opts, params, visible=opts.show_output)
    for _ in range(opts.warmup):
        run_command(bench["command"], opts, params)
    runs = opts.runs if opts.runs is not None else opts.min_runs
    if opts.max_runs is not None:
        runs = min(runs, opts.max_runs)
    times = []
    codes = []
    for i in range(1, runs + 1):
        if opts.prepare:
            run_command(replaced(opts.prepare[min(len(opts.prepare) - 1, ordinal - 1)], params), opts, params, i, visible=opts.show_output)
        code, elapsed = run_command(bench["command"], opts, params, i, timed=True, visible=opts.show_output)
        times.append(elapsed)
        codes.append(code)
        if opts.conclude:
            run_command(replaced(opts.conclude[min(len(opts.conclude) - 1, ordinal - 1)], params), opts, params, i, visible=opts.show_output)
        if code != 0 and not should_ignore(code, opts.ignore_failure):
            sys.stderr.write(
                f"Error: Command terminated with non-zero exit code {code} in the first benchmark run. "
                "Use the '-i'/'--ignore-failure' option if you want to ignore this. "
                "Alternatively, use the '--show-output' option to debug what went wrong.\n"
            )
            return None, 1
    if opts.cleanup:
        run_command(replaced(opts.cleanup, params), opts, params, visible=opts.show_output)
    result = summarize(bench, times, codes)
    if opts.style != "none":
        print_summary(result, opts)
    if any(code != 0 for code in codes) and opts.ignore_failure:
        sys.stderr.write("  Warning: Ignoring non-zero exit code.\n")
    if min(times or [0]) < 0.005:
        sys.stderr.write(" \n" + WARNING_FAST + "\n \n")
    return result, 0


def summarize(bench, times, codes):
    mean = statistics.fmean(times) if times else 0.0
    stddev = statistics.stdev(times) if len(times) > 1 else None
    result = {
        "command": bench["command"],
        "mean": mean,
        "stddev": stddev,
        "median": statistics.median(times) if times else 0.0,
        "user": 0.0,
        "system": 0.0,
        "min": min(times) if times else 0.0,
        "max": max(times) if times else 0.0,
        "times": times,
        "memory_usage_byte": [0 for _ in times],
        "exit_codes": codes,
    }
    if bench["parameters"]:
        result["parameters"] = bench["parameters"]
    if bench["display"] != bench["command"]:
        result["command"] = bench["display"]
    return result


def unit_scale(opts, results):
    unit = opts.time_unit
    if not unit:
        maxv = max([r["mean"] for r in results] + [0.0])
        if maxv < 0.001:
            unit = "microsecond"
        elif maxv < 1.0:
            unit = "millisecond"
        else:
            unit = "second"
    if unit.startswith("micro"):
        return "µs", 1_000_000.0
    if unit.startswith("milli"):
        return "ms", 1_000.0
    return "s", 1.0


def fmt_num(x):
    if x is None:
        return ""
    if x == 0:
        return "0"
    return f"{x:.12g}"


def fmt_table_num(x):
    return f"{x:.1f}" if abs(x) >= 10 or x == 0 else f"{x:.3f}".rstrip("0").rstrip(".")


def print_summary(result, opts):
    label, scale = unit_scale(opts, [result])
    std = result["stddev"]
    if std is None:
        print(f"  Time (abs ≡):          {fmt_table_num(result['mean'] * scale)} {label}               [User: 0.0 {label}, System: 0.0 {label}]")
    else:
        print(f"  Time (mean ± σ):     {fmt_table_num(result['mean'] * scale)} {label} ± {fmt_table_num(std * scale)} {label}    [User: 0.0 {label}, System: 0.0 {label}]")
        print(f"  Range (min … max):     {fmt_table_num(result['min'] * scale)} {label} … {fmt_table_num(result['max'] * scale)} {label}    {len(result['times'])} runs")


def ordered_for_tables(results, opts):
    if opts.sort == "mean-time":
        return sorted(results, key=lambda r: r["mean"])
    return list(results)


def relative_values(results):
    best = min([r["mean"] for r in results] + [0.0])
    if best <= 0:
        best = min([r["mean"] for r in results if r["mean"] > 0] + [1.0])
    return [r["mean"] / best if best else 1.0 for r in results]


def write_exports(results, opts):
    if not results:
        return
    if "json" in opts.exports:
        Path(opts.exports["json"]).write_text(json.dumps({"results": results}, indent=2) + "\n")
    if "csv" in opts.exports:
        with open(opts.exports["csv"], "w", newline="") as f:
            writer = csv.writer(f)
            fields = ["command", "mean", "stddev", "median", "user", "system", "min", "max"]
            writer.writerow(fields)
            for r in results:
                writer.writerow([r["command"], fmt_num(r["mean"]), fmt_num(r["stddev"]), fmt_num(r["median"]), fmt_num(r["user"]), fmt_num(r["system"]), fmt_num(r["min"]), fmt_num(r["max"])])
    table_results = ordered_for_tables(results, opts)
    label, scale = unit_scale(opts, table_results)
    rels = relative_values(table_results)
    if "markdown" in opts.exports:
        lines = [f"| Command | Mean [{label}] | Min [{label}] | Max [{label}] | Relative |", "|:---|---:|---:|---:|---:|"]
        for r, rel in zip(table_results, rels):
            std = 0.0 if r["stddev"] is None else r["stddev"]
            lines.append(f"| `{r['command']}` | {fmt_table_num(r['mean']*scale)} ± {fmt_table_num(std*scale)} | {fmt_table_num(r['min']*scale)} | {fmt_table_num(r['max']*scale)} | {rel:.2f} |")
        Path(opts.exports["markdown"]).write_text("\n".join(lines) + "\n")
    if "asciidoc" in opts.exports:
        lines = ['[cols="<,>,>,>,>"]', "|===", "| Command ", f"| Mean [{label}] ", f"| Min [{label}] ", f"| Max [{label}] ", "| Relative ", ""]
        for r, rel in zip(table_results, rels):
            std = 0.0 if r["stddev"] is None else r["stddev"]
            lines += [f"| `{r['command']}` ", f"| {fmt_table_num(r['mean']*scale)} ± {fmt_table_num(std*scale)} ", f"| {fmt_table_num(r['min']*scale)} ", f"| {fmt_table_num(r['max']*scale)} ", f"| {rel:.2f} "]
        lines.append("|===")
        Path(opts.exports["asciidoc"]).write_text("\n".join(lines) + "\n")
    if "orgmode" in opts.exports:
        lines = [f"| Command  |  Mean [{label}] |  Min [{label}] |  Max [{label}] |  Relative |", "|--+--+--+--+--|"]
        for r, rel in zip(table_results, rels):
            std = 0.0 if r["stddev"] is None else r["stddev"]
            lines.append(f"| ={r['command']}=  |  {fmt_table_num(r['mean']*scale)} ± {fmt_table_num(std*scale)} |  {fmt_table_num(r['min']*scale)} |  {fmt_table_num(r['max']*scale)} |  {rel:.2f} |")
        Path(opts.exports["orgmode"]).write_text("\n".join(lines) + "\n")


def main(argv):
    opts, parse_error = parse_args(argv)
    if parse_error:
        return err(parse_error)
    if opts.show_output and opts.style_was_set:
        return err("error: the argument '--style <TYPE>' cannot be used with '--show-output'", "Usage: executable --style <TYPE> --runs <NUM> --setup <CMD> --prepare <CMD> --conclude <CMD> --cleanup <CMD> <command>...")
    if not opts.commands:
        return err("error: the following required arguments were not provided:\n  <command>...", "Usage: executable <command>...")
    if opts.parameter_step and not opts.parameter_scan:
        return err("error: the argument '--parameter-step-size <DELTA>' requires '--parameter-scan <VAR> <MIN> <MAX>'")
    results = []
    for idx, bench in enumerate(expand_commands(opts), 1):
        result, code = bench_one(bench, opts, idx)
        if code:
            return code
        results.append(result)
    write_exports(results, opts)
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
