import json
import os
import subprocess
import tempfile
import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]


class HyperfineTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        subprocess.run(["bash", "compile.sh"], cwd=ROOT, check=True)
        cls.exe = ROOT / "executable"

    def run_hf(self, *args):
        return subprocess.run(
            [str(self.exe), *args],
            cwd=ROOT,
            text=True,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
        )

    def test_version_matches_reference(self):
        result = self.run_hf("--version")
        self.assertEqual(result.returncode, 0)
        self.assertEqual(result.stdout.strip(), "hyperfine 1.20.0")

    def test_no_command_reports_required_argument_error(self):
        result = self.run_hf()
        self.assertEqual(result.returncode, 2)
        self.assertIn("error: the following required arguments were not provided:", result.stderr)
        self.assertIn("<command>...", result.stderr)

    def test_json_export_contains_timing_results_and_exit_codes(self):
        with tempfile.TemporaryDirectory() as tmp:
            output = Path(tmp) / "result.json"
            result = self.run_hf("--style", "none", "-r", "1", "--export-json", str(output), "true")
            self.assertEqual(result.returncode, 0)
            data = json.loads(output.read_text())
        self.assertEqual(len(data["results"]), 1)
        entry = data["results"][0]
        self.assertEqual(entry["command"], "true")
        self.assertEqual(entry["exit_codes"], [0])
        self.assertEqual(len(entry["times"]), 1)
        self.assertIsInstance(entry["mean"], float)

    def test_parameter_list_expands_commands_and_records_parameters(self):
        with tempfile.TemporaryDirectory() as tmp:
            output = Path(tmp) / "result.json"
            result = self.run_hf("--style", "none", "-r", "1", "-L", "x", "a,b", "--export-json", str(output), "echo {x}")
            self.assertEqual(result.returncode, 0)
            commands = json.loads(output.read_text())["results"]
        self.assertEqual([item["command"] for item in commands], ["echo a", "echo b"])
        self.assertEqual([item["parameters"]["x"] for item in commands], ["a", "b"])

    def test_show_output_runs_hooks_in_reference_order(self):
        result = self.run_hf(
            "-r",
            "1",
            "--show-output",
            "--setup",
            "echo setup",
            "--prepare",
            "echo prep",
            "--conclude",
            "echo conc",
            "--cleanup",
            "echo clean",
            "echo cmd",
        )
        self.assertEqual(result.returncode, 0)
        combined = result.stdout + result.stderr
        positions = [combined.index(text) for text in ["setup", "prep", "cmd", "conc", "clean"]]
        self.assertEqual(positions, sorted(positions))

    def test_nonzero_command_fails_unless_ignored(self):
        result = self.run_hf("--style", "none", "-r", "1", "false")
        self.assertEqual(result.returncode, 1)
        self.assertIn("Command terminated with non-zero exit code 1", result.stderr)

        ignored = self.run_hf("--style", "none", "-r", "1", "--ignore-failure", "false")
        self.assertEqual(ignored.returncode, 0)
        self.assertIn("Warning: Ignoring non-zero exit code.", ignored.stderr)

    def test_shell_command_line_is_used_to_execute_benchmark(self):
        result = self.run_hf("--style", "none", "-r", "1", "--shell", "bash --norc", "echo $BASH_VERSION")
        self.assertEqual(result.returncode, 0)


if __name__ == "__main__":
    unittest.main()
