#!/usr/bin/env python3
import os, subprocess, tempfile, textwrap, pathlib, sys
ROOT = pathlib.Path(__file__).resolve().parents[1]
BIN = ROOT/"src"/"dupl.py"

def run(args, cwd=None, input_text=None):
    return subprocess.run([sys.executable, str(BIN), *args], cwd=cwd or ROOT, input=input_text, text=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)

def write(p, s):
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(textwrap.dedent(s).lstrip(), encoding="utf-8")

def test_normal_output_for_duplicate_functions():
    with tempfile.TemporaryDirectory() as d:
        p = pathlib.Path(d)/"a.go"
        write(p, """
            package main
            func A() {
                x := 1
                y := 2
                z := x + y
                println(z)
            }
            func B() {
                x := 1
                y := 2
                z := x + y
                println(z)
            }
        """)
        r = run(["-t", "5", str(p)])
        assert r.returncode == 0
        assert r.stderr == ""
        assert r.stdout == f"found 2 clones:\n  {p}:2,7\n  {p}:8,13\n\nFound total 1 clone groups.\n"

def test_plumbing_outputs_bidirectional_duplicate_lines():
    with tempfile.TemporaryDirectory() as d:
        p = pathlib.Path(d)/"a.go"
        write(p, """
            package main
            func A() { x := 1; y := 2; z := x + y; println(z) }
            func B() { x := 1; y := 2; z := x + y; println(z) }
        """)
        r = run(["-plumbing", "-t", "5", str(p)])
        assert r.returncode == 0
        assert r.stdout == f"{p}:2-2: duplicate of {p}:3-3\n{p}:3-3: duplicate of {p}:2-2\n"

def test_html_escapes_duplicate_fragments():
    with tempfile.TemporaryDirectory() as d:
        p = pathlib.Path(d)/"a.go"
        write(p, """
            package main
            func A() { if 1 < 2 { println("x&y") } }
            func B() { if 3 < 4 { println("a&b") } }
        """)
        r = run(["-html", "-t", "5", str(p)])
        assert r.returncode == 0
        assert "<h1>#1 found 2 clones</h1>" in r.stdout
        assert "&lt;" in r.stdout
        assert "&amp;" in r.stdout

def test_directory_skips_vendor_until_vendor_flag():
    with tempfile.TemporaryDirectory() as d:
        root = pathlib.Path(d)
        write(root/"main.go", """
            package main
            func A() { x := 1; y := 2; z := x + y; println(z) }
            func B() { x := 1; y := 2; z := x + y; println(z) }
        """)
        write(root/"vendor"/"v.go", (root/"main.go").read_text())
        r = run(["-t", "5", str(root)])
        assert str(root/"vendor"/"v.go") not in r.stdout
        r2 = run(["-vendor", "-t", "5", str(root)])
        assert str(root/"vendor"/"v.go") in r2.stdout

def test_plumbing_cycles_three_clone_groups():
    with tempfile.TemporaryDirectory() as d:
        p = pathlib.Path(d)/"a.go"
        write(p, """
            package main
            func A() { x := 1; y := 2; println(x+y) }
            func B() { a := 3; b := 4; println(a+b) }
            func C() { p := 5; q := 6; println(p+q) }
        """)
        r = run(["-plumbing", "-t", "5", str(p)])
        assert r.stdout == (
            f"{p}:2-2: duplicate of {p}:3-3\n"
            f"{p}:3-3: duplicate of {p}:4-4\n"
            f"{p}:4-4: duplicate of {p}:2-2\n"
        )

def test_help_goes_to_stderr_with_status_2():
    r = run(["-h"])
    assert r.returncode == 2
    assert r.stdout == ""
    assert r.stderr.startswith("Usage: dupl [flags] [paths]\n\nPaths:\n")

def test_bad_flag_message_precedes_usage():
    r = run(["-badflag"])
    assert r.returncode == 2
    assert r.stdout == ""
    assert r.stderr.startswith("flag provided but not defined: -badflag\nUsage: dupl [flags] [paths]\n")

def test_identical_files_also_report_more_frequent_inner_clones():
    with tempfile.TemporaryDirectory() as d:
        root = pathlib.Path(d)
        body = """
            package main
            func A() {
                x := 1
                y := 2
                z := x + y
                println(z)
            }
            func B() {
                x := 1
                y := 2
                z := x + y
                println(z)
            }
        """
        write(root/"a.go", body)
        write(root/"b.go", body)
        r = run(["-t", "5", str(root)])
        assert "found 4 clones:" in r.stdout
        assert "found 2 clones:" in r.stdout

if __name__ == "__main__":
    import pytest
    raise SystemExit(pytest.main([__file__]))
