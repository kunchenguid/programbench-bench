#!/usr/bin/env python3
import html
import os
import re
import sys


KEYWORDS = {
    "break", "default", "func", "interface", "select", "case", "defer", "go",
    "map", "struct", "chan", "else", "goto", "package", "switch", "const",
    "fallthrough", "if", "range", "type", "continue", "for", "import",
    "return", "var",
}

OPS = [
    "<<=", ">>=", "&^=", "...", ":=", "++", "--", "==", "!=", "<=", ">=",
    "&&", "||", "<-", "+=", "-=", "*=", "/=", "%=", "&=", "|=", "^=", "<<",
    ">>", "&^",
]

USAGE = """Usage: dupl [flags] [paths]

Paths:
  If the given path is a file, dupl will use it regardless of
  the file extension. If it is a directory, it will recursively
  search for *.go files in that directory.

  If no path is given, dupl will recursively search for *.go
  files in the current directory.

Flags:
  -files
\tread file names from stdin one at each line
  -html
\toutput the results as HTML, including duplicate code fragments
  -plumbing
\tplumbing (easy-to-parse) output for consumption by scripts or tools
  -t, -threshold size
\tminimum token sequence size as a clone (default 15)
  -vendor
\tcheck files in vendor directory
  -v, -verbose
\texplain what is being done

Examples:
  dupl -t 100
\tSearch clones in the current directory of size at least
\t100 tokens.
  dupl $(find app/ -name '*_test.go')
\tSearch for clones in tests in the app directory.
  find app/ -name '*_test.go' |dupl -files
\tThe same as above.
"""


class Token:
    __slots__ = ("value", "file", "line")

    def __init__(self, value, file, line):
        self.value = value
        self.file = file
        self.line = line


def discover(paths, from_stdin=False, include_vendor=False):
    if from_stdin:
        return [line.strip() for line in sys.stdin if line.strip()]
    if not paths:
        paths = ["."]
    files = []
    for path in paths:
        if not os.path.exists(path):
            raise FileNotFoundError(f"lstat {path}: no such file or directory")
        if os.path.isfile(path):
            files.append(path)
            continue
        for root, dirs, names in os.walk(path):
            if not include_vendor:
                dirs[:] = [d for d in dirs if d != "vendor"]
            for name in sorted(names):
                if name.endswith(".go"):
                    files.append(os.path.join(root, name))
    return sorted(files)


def strip_comments(src):
    out = []
    i = 0
    n = len(src)
    in_block = False
    while i < n:
        if in_block:
            if src.startswith("*/", i):
                out.append("  ")
                i += 2
                in_block = False
            else:
                out.append("\n" if src[i] == "\n" else " ")
                i += 1
            continue
        if src.startswith("//", i):
            while i < n and src[i] != "\n":
                out.append(" ")
                i += 1
            continue
        if src.startswith("/*", i):
            out.append("  ")
            i += 2
            in_block = True
            continue
        out.append(src[i])
        i += 1
    return "".join(out)


def tokenize_file(path):
    try:
        src = open(path, encoding="utf-8").read()
    except UnicodeDecodeError:
        src = open(path, encoding="latin1").read()
    src = strip_comments(src)
    tokens = []
    i = 0
    line = 1
    n = len(src)
    while i < n:
        c = src[i]
        if c.isspace():
            if c == "\n":
                line += 1
            i += 1
            continue
        start_line = line
        if c.isalpha() or c == "_":
            j = i + 1
            while j < n and (src[j].isalnum() or src[j] == "_"):
                j += 1
            word = src[i:j]
            tokens.append(Token(word if word in KEYWORDS else "IDENT", path, start_line))
            i = j
            continue
        if c.isdigit():
            j = i + 1
            while j < n and (src[j].isalnum() or src[j] in "._"):
                j += 1
            tokens.append(Token("LIT", path, start_line))
            i = j
            continue
        if c in "\"'`":
            quote = c
            i += 1
            while i < n:
                if src[i] == "\n":
                    line += 1
                if quote != "`" and src[i] == "\\":
                    i += 2
                    continue
                if src[i] == quote:
                    i += 1
                    break
                i += 1
            tokens.append(Token("LIT", path, start_line))
            continue
        matched = None
        for op in OPS:
            if src.startswith(op, i):
                matched = op
                break
        if matched:
            tokens.append(Token(matched, path, start_line))
            i += len(matched)
        else:
            tokens.append(Token(c, path, start_line))
            i += 1
    return tokens


def line_fragment(path, start, end):
    lines = open(path, encoding="utf-8", errors="replace").read().splitlines()
    return "\n".join(lines[start - 1:end])


def find_clones(tokens, threshold):
    vals = [t.value for t in tokens]
    pairs = []
    by_first = {}
    for i, v in enumerate(vals):
        by_first.setdefault(v, []).append(i)
    seen = set()
    for positions in by_first.values():
        for ai, i in enumerate(positions):
            for j in positions[ai + 1:]:
                if tokens[i].file == tokens[j].file and abs(i - j) < threshold:
                    continue
                if i and j and vals[i - 1] == vals[j - 1]:
                    continue
                l = 0
                while i + l < len(vals) and j + l < len(vals) and vals[i + l] == vals[j + l]:
                    l += 1
                if l < threshold:
                    continue
                key = (tuple(vals[i:i + l]), tokens[i].file, tokens[i].line, tokens[i + l - 1].line,
                       tokens[j].file, tokens[j].line, tokens[j + l - 1].line)
                if key not in seen:
                    seen.add(key)
                    pairs.append((i, j, l))
    groups = []
    used_ranges = set()
    for i, j, l in sorted(pairs, key=lambda p: (tokens[p[0]].file, tokens[p[0]].line, -p[2])):
        seq = tuple(vals[i:i + l])
        occ = []
        k = 0
        while k <= len(vals) - l:
            if tuple(vals[k:k + l]) == seq:
                occ.append((k, k + l - 1))
                k += l
            else:
                k += 1
        clones = []
        for a, b in occ:
            item = (tokens[a].file, tokens[a].line, tokens[b].line)
            if item not in clones:
                clones.append(item)
        if len(clones) >= 2:
            sig = tuple(clones)
            if sig not in used_ranges:
                used_ranges.add(sig)
                groups.append(clones)
    maximal = []
    for clones in sorted(groups, key=lambda g: -sum(e - s for _, s, e in g)):
        containing_size = 0
        contained = True
        for path, start, end in clones:
            matches = [len(mg) for mg in maximal for mp, ms, me in mg if path == mp and ms <= start and end <= me]
            if matches:
                containing_size = max(containing_size, max(matches))
            else:
                contained = False
                break
        if not contained or len(clones) > containing_size:
            maximal.append(clones)
    return sorted(maximal, key=lambda g: (-len(g), g[0][0], g[0][1], g[0][2]))


def print_normal(groups):
    for clones in groups:
        print(f"found {len(clones)} clones:")
        for path, start, end in clones:
            print(f"  {path}:{start},{end}")
    if groups:
        print()
    print(f"Found total {len(groups)} clone groups.")


def print_plumbing(groups):
    for clones in groups:
        for i, (path, start, end) in enumerate(clones):
            op, os_, oe = clones[(i + 1) % len(clones)]
            print(f"{path}:{start}-{end}: duplicate of {op}:{os_}-{oe}")


def print_html(groups):
    print("""<!DOCTYPE html>
<meta charset="utf-8"/>
<title>Duplicates</title>
<style>
\tpre {
\t\tbackground-color: #FFD;
\t\tborder: 1px solid #E2E2E2;
\t\tpadding: 1ex;
\t}
</style>""")
    for idx, clones in enumerate(groups, 1):
        print(f"<h1>#{idx} found {len(clones)} clones</h1>")
        for path, start, end in clones:
            print(f"<h2>{html.escape(path)}:{start}</h2>")
            print(f"<pre>{html.escape(line_fragment(path, start, end))}</pre>")


class Args:
    def __init__(self):
        self.files = False
        self.html = False
        self.plumbing = False
        self.threshold = 15
        self.vendor = False
        self.verbose = False
        self.paths = []


def parse_args(argv):
    ns = Args()
    i = 0
    while i < len(argv):
        arg = argv[i]
        if arg in ("-h", "--help"):
            sys.stderr.write(USAGE)
            return ns, 2
        if arg == "-files":
            ns.files = True
        elif arg == "-html":
            ns.html = True
        elif arg == "-plumbing":
            ns.plumbing = True
        elif arg in ("-t", "-threshold"):
            i += 1
            if i >= len(argv):
                sys.stderr.write(f"flag needs an argument: {arg}\n" + USAGE)
                return ns, 2
            ns.threshold = int(argv[i])
        elif arg == "-vendor":
            ns.vendor = True
        elif arg in ("-v", "-verbose"):
            ns.verbose = True
        elif arg.startswith("-"):
            sys.stderr.write(f"flag provided but not defined: {arg}\n" + USAGE)
            return ns, 2
        else:
            ns.paths.append(arg)
        i += 1
    return ns, 0


def main(argv=None):
    if argv is None:
        argv = sys.argv[1:]
    ns, early = parse_args(argv)
    if early:
        return early
    try:
        files = discover(ns.paths, ns.files, ns.vendor)
    except FileNotFoundError as e:
        print(f"dupl: {e}", file=sys.stderr)
        return 1
    toks = []
    for path in files:
        try:
            toks.extend(tokenize_file(path))
        except OSError as e:
            print(f"dupl: {e}", file=sys.stderr)
    groups = find_clones(toks, ns.threshold)
    if ns.html:
        print_html(groups)
    elif ns.plumbing:
        print_plumbing(groups)
    else:
        print_normal(groups)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
