#!/usr/bin/env python3
import base64
import html
import os
import subprocess
import sys
import textwrap
import zlib
from pathlib import Path


VERSION = "codesnap-cli 0.13.1"


HELP = """CLI tools for generating beautiful code snapshots

Usage: codesnap [OPTIONS] --output <OUTPUT>

Options:
  -f, --from-file <FROM_FILE>
          Path to the file to snapshot

  -c, --from-code [<Code>]
          Code snippet for snapshot

  -i, --from-image [<Image>]

      --from-clipboard

  -o, --output <OUTPUT>
          Output path for the snapshot. Available value:

          - clipboard: Copy the snapshot to clipboard - file path: Save the snapshot to the file path

          Currently CodeSnap supports SVG format and PNG format If output is directory, CodeSnap will generate a temporary file name to save the snapshot to the directory.

      --silent

  -e, --execute <EXECUTE>...
          Executing a command and taking the output as the code snippet

      --skip
          Skip run the command to get output, just take the command as the input

      --range <RANGE>
          You can set the range of the code snippet to display

      --code-font-family <CODE_FONT_FAMILY>
          Font family for the code snippet

      --code-theme <CODE_THEME>
          Code theme for the code snippet

      --has-breadcrumbs <HAS_BREADCRUMBS>
          [default: false]
          [possible values: true, false]

      --has-line-number

      --breadcrumbs-separator <BREADCRUMBS_SEPARATOR>

      --breadcrumbs-font-family <BREADCRUMBS_FONT_FAMILY>

      --breadcrumbs-color <BREADCRUMBS_COLOR>

      --start-line-number <START_LINE_NUMBER>

      --line-number-color <LINE_NUMBER_COLOR>
          [default: #495162]

  -d, --delete-line <DELETE_LINE>...

      --delete-line-color <DELETE_LINE_COLOR>
          [default: #ff6b6b30]

  -a, --add-line <ADD_LINE>...

      --add-line-color <ADD_LINE_COLOR>
          [default: #2ecc7130]

      --highlight-range <HIGHLIGHT_RANGE>

      --relative-highlight-range

      --highlight-range-color <HIGHLIGHT_RANGE_COLOR>
          [default: #ffffff10]

      --raw-highlight-lines <RAW_HIGHLIGHT_LINES>

  -l, --language <LANGUAGE>

      --file-path <FILE_PATH>

  -w, --watermark <WATERMARK>

      --watermark-font-family <WATERMARK_FONT_FAMILY>

      --watermark-color <WATERMARK_COLOR>

      --shadow-radius <SHADOW_RADIUS>

      --shadow-color <SHADOW_COLOR>

      --mac-window-bar <MAC_WINDOW_BAR>
          [possible values: true, false]

      --has-border

      --border-color <BORDER_COLOR>
          [default: #ffffff30]

      --margin-x <MARGIN_X>

      --margin-y <MARGIN_Y>

      --title <TITLE>

      --scale-factor <SCALE_FACTOR>
          [default: 3]

      --title-font-family <TITLE_FONT_FAMILY>

      --title-color <TITLE_COLOR>

      --background <BACKGROUND>

      --type <TYPE>
          [default: image]
          [possible values: ascii, image]

      --config <CONFIG>

  -h, --help
          Print help (see a summary with '-h')

  -V, --version
          Print version
"""


VALUE_OPTIONS = {
    "--range",
    "--code-font-family",
    "--code-theme",
    "--has-breadcrumbs",
    "--breadcrumbs-separator",
    "--breadcrumbs-font-family",
    "--breadcrumbs-color",
    "--start-line-number",
    "--line-number-color",
    "--delete-line-color",
    "--add-line-color",
    "--highlight-range",
    "--highlight-range-color",
    "--raw-highlight-lines",
    "-l",
    "--language",
    "--file-path",
    "-w",
    "--watermark",
    "--watermark-font-family",
    "--watermark-color",
    "--shadow-radius",
    "--shadow-color",
    "--mac-window-bar",
    "--border-color",
    "--margin-x",
    "--margin-y",
    "--title",
    "--scale-factor",
    "--title-font-family",
    "--title-color",
    "--background",
    "--type",
    "--config",
}

MULTI_OPTIONS = {"-d", "--delete-line", "-a", "--add-line"}
BOOL_OPTIONS = {"--silent", "--skip", "--from-clipboard", "--has-line-number", "--relative-highlight-range", "--has-border"}
TOP_OPTIONS = (
    VALUE_OPTIONS
    | MULTI_OPTIONS
    | BOOL_OPTIONS
    | {"-h", "--help", "-V", "--version", "-o", "--output", "-f", "--from-file", "-c", "--from-code", "-i", "--from-image", "-e", "--execute"}
)


def is_option(value):
    return value.startswith("-") and value != "-"


def parse_args(argv):
    opts = {
        "from_file": None,
        "from_code": None,
        "from_image": None,
        "from_clipboard": False,
        "output": None,
        "silent": False,
        "execute": None,
        "skip": False,
        "range": None,
        "type": "image",
        "title": None,
        "watermark": None,
        "has_line_number": False,
        "has_breadcrumbs": False,
        "file_path": None,
    }
    extras = []
    i = 0
    while i < len(argv):
        arg = argv[i]
        if arg in ("-h", "--help"):
            opts["help"] = True
            i += 1
        elif arg in ("-V", "--version"):
            opts["version"] = True
            i += 1
        elif arg in ("-o", "--output"):
            if i + 1 >= len(argv):
                raise ValueError("missing output")
            opts["output"] = argv[i + 1]
            i += 2
        elif arg in ("-f", "--from-file"):
            if i + 1 >= len(argv):
                raise ValueError("missing from-file")
            opts["from_file"] = argv[i + 1]
            i += 2
        elif arg in ("-c", "--from-code"):
            if i + 1 < len(argv) and not is_option(argv[i + 1]):
                opts["from_code"] = argv[i + 1]
                i += 2
            else:
                opts["from_code"] = ""
                i += 1
        elif arg in ("-i", "--from-image"):
            if i + 1 < len(argv) and not is_option(argv[i + 1]):
                opts["from_image"] = argv[i + 1]
                i += 2
            else:
                opts["from_image"] = ""
                i += 1
        elif arg in ("-e", "--execute"):
            values = []
            i += 1
            while i < len(argv) and argv[i] not in TOP_OPTIONS:
                values.append(argv[i])
                i += 1
            opts["execute"] = values
        elif arg == "--range":
            opts["range"] = argv[i + 1] if i + 1 < len(argv) else ""
            i += 2
        elif arg == "--type":
            opts["type"] = argv[i + 1] if i + 1 < len(argv) else "image"
            i += 2
        elif arg == "--title":
            opts["title"] = argv[i + 1] if i + 1 < len(argv) else ""
            i += 2
        elif arg in ("-w", "--watermark"):
            opts["watermark"] = argv[i + 1] if i + 1 < len(argv) else ""
            i += 2
        elif arg == "--file-path":
            opts["file_path"] = argv[i + 1] if i + 1 < len(argv) else ""
            i += 2
        elif arg == "--has-line-number":
            opts["has_line_number"] = True
            i += 1
        elif arg == "--has-breadcrumbs":
            if i + 1 < len(argv) and not is_option(argv[i + 1]):
                opts["has_breadcrumbs"] = argv[i + 1].lower() == "true"
                i += 2
            else:
                opts["has_breadcrumbs"] = True
                i += 1
        elif arg in BOOL_OPTIONS:
            key = arg.lstrip("-").replace("-", "_")
            opts[key] = True
            i += 1
        elif arg in VALUE_OPTIONS:
            i += 2
        elif arg in MULTI_OPTIONS:
            i += 1
            while i < len(argv) and not is_option(argv[i]):
                i += 1
        else:
            extras.append(arg)
            i += 1
    opts["extras"] = extras
    return opts


def clap_missing_output(argv):
    usage = "Usage: codesnap --output <OUTPUT>"
    if "-c" in argv or "--from-code" in argv:
        usage += " --from-code [<Code>]"
    return textwrap.dedent(
        f"""\
        error: the following required arguments were not provided:
          --output <OUTPUT>

        {usage}

        For more information, try '--help'.
        """
    )


def status_line(kind, text):
    colors = {"SUCCESS": "\033[32m", "ERROR": "\033[31m", "WARN": "\033[33m"}
    return f"{colors[kind]}[{kind}]\033[0m {text}"


def apply_range(code, spec):
    if not spec:
        return code
    parts = spec.split(":")
    if len(parts) != 2:
        int(spec)
        return code
    start_s, end_s = parts
    if start_s:
        start = int(start_s)
    else:
        start = 1
    if end_s:
        end = int(end_s)
    else:
        end = None
    lines = code.splitlines()
    lo = max(start - 1, 0)
    hi = end if end is not None else len(lines)
    if hi < lo:
        lo, hi = hi - 1, lo + 1
        lo = max(lo, 0)
    return "\n".join(lines[lo:hi]) + ("\n" if code.endswith("\n") and lines[lo:hi] else "")


def load_code(opts):
    if opts["from_clipboard"]:
        raise RuntimeError("clipboard")
    if opts["from_file"] is not None:
        try:
            code = Path(opts["from_file"]).read_text()
        except FileNotFoundError:
            raise FileNotFoundError("No such file or directory (os error 2)")
        source_path = opts["from_file"]
    elif opts["execute"] is not None:
        command = opts["execute"]
        if opts["skip"]:
            code = " ".join(command)
        elif not command:
            code = ""
        else:
            completed = subprocess.run(command, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
            code = completed.stdout
        source_path = None
    elif opts["from_code"] is not None:
        code = opts["from_code"]
        source_path = None
    elif opts["from_image"] is not None:
        code = opts["from_image"]
        source_path = None
    else:
        code = ""
        source_path = None
    if opts["range"]:
        code = apply_range(code, opts["range"])
    return code, source_path


def png_bytes(text):
    width = 640
    line_count = max(1, len(text.splitlines()) or 1)
    height = max(160, min(1200, 80 + 24 * line_count))
    raw_rows = []
    for y in range(height):
        row = bytearray([0])
        for x in range(width):
            if x < 16 or y < 16 or x > width - 17 or y > height - 17:
                row.extend((42, 48, 64, 255))
            else:
                row.extend((245, 247, 250, 255))
        raw_rows.append(bytes(row))
    data = zlib.compress(b"".join(raw_rows), 6)

    def chunk(kind, payload):
        crc = zlib.crc32(kind + payload) & 0xFFFFFFFF
        return len(payload).to_bytes(4, "big") + kind + payload + crc.to_bytes(4, "big")

    header = width.to_bytes(4, "big") + height.to_bytes(4, "big") + bytes([8, 6, 0, 0, 0])
    note = ("CodeSnap\x00" + text[:4096]).encode("latin-1", "replace")
    return b"\x89PNG\r\n\x1a\n" + chunk(b"IHDR", header) + chunk(b"tEXt", note) + chunk(b"IDAT", data) + chunk(b"IEND", b"")


def svg_text(code, opts, source_path):
    lines = code.splitlines() or [""]
    width = max(420, min(1400, 120 + max(len(line) for line in lines) * 9))
    height = max(140, 90 + len(lines) * 24 + (30 if opts["title"] else 0) + (28 if opts["watermark"] else 0))
    encoded_png = base64.b64encode(png_bytes(code)).decode()
    safe_title = html.escape(opts["title"] or "")
    safe_watermark = html.escape(opts["watermark"] or "")
    breadcrumb = html.escape(opts["file_path"] or source_path or "")
    body = [
        f'<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" width="{width}" height="{height}" viewBox="0 0 {width} {height}">',
        f'<image href="data:image/png;base64,{encoded_png}" width="{width}" height="{height}"/>',
        '<rect x="24" y="24" width="{}" height="{}" rx="8" fill="#1f2430"/>'.format(width - 48, height - 48),
    ]
    y = 58
    if safe_title:
        body.append(f'<text x="44" y="{y}" fill="#f8fafc" font-family="monospace" font-size="18">{safe_title}</text>')
        y += 30
    if opts["has_breadcrumbs"] and breadcrumb:
        body.append(f'<text x="44" y="{y}" fill="#94a3b8" font-family="monospace" font-size="13">{breadcrumb}</text>')
        y += 26
    start_line = 1
    for idx, line in enumerate(lines, start=start_line):
        safe = html.escape(line)
        if opts["has_line_number"]:
            body.append(f'<text x="44" y="{y}" fill="#64748b" font-family="monospace" font-size="15">{idx}</text>')
            x = 82
        else:
            x = 44
        body.append(f'<text x="{x}" y="{y}" fill="#e5e7eb" font-family="monospace" font-size="15">{safe}</text>')
        y += 24
    if safe_watermark:
        body.append(f'<text x="{width - 44}" y="{height - 38}" fill="#94a3b8" text-anchor="end" font-family="monospace" font-size="13">{safe_watermark}</text>')
    body.append("</svg>")
    return "".join(body)


def write_output(output, code, opts, source_path):
    if output == "clipboard":
        raise RuntimeError("clipboard")
    path = Path(output)
    if path.exists() and path.is_dir():
        raise ValueError("Unsupported output format")
    suffix = path.suffix.lower()
    path.parent.mkdir(parents=True, exist_ok=True)
    if suffix == ".png":
        path.write_bytes(png_bytes(code))
    elif suffix == ".svg":
        path.write_text(svg_text(code, opts, source_path))
    else:
        raise ValueError("Unsupported output format")


def main(argv):
    try:
        opts = parse_args(argv)
    except Exception as exc:
        print(status_line("ERROR", str(exc)))
        return 1
    if opts.get("help"):
        print(HELP, end="")
        return 0
    if opts.get("version"):
        print(VERSION)
        return 0
    if not opts["output"]:
        sys.stderr.write(clap_missing_output(argv))
        return 2

    if opts["type"] == "ascii" and opts["output"] != "clipboard":
        if not opts["silent"]:
            print(status_line("WARN", "ASCII snapshot only supports copying to clipboard"))
        return 0

    try:
        code, source_path = load_code(opts)
        write_output(opts["output"], code, opts, source_path)
    except FileNotFoundError as exc:
        print(status_line("ERROR", str(exc)))
        return 1
    except RuntimeError as exc:
        if str(exc) == "clipboard":
            print(status_line("ERROR", "Unknown error while interacting with the clipboard: X11 server connection timed out because it was unreachable"))
            return 1
        print(status_line("ERROR", str(exc)))
        return 1
    except Exception as exc:
        print(status_line("ERROR", str(exc)))
        return 1

    if not opts["silent"]:
        print(status_line("SUCCESS", f"Snapshot saved to {opts['output']} successful!"))
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
