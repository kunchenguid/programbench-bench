import json
import os
import subprocess
import textwrap
import unittest
from pathlib import Path
from tempfile import TemporaryDirectory


ROOT = Path(__file__).resolve().parents[1]
SCRIPT = ROOT / "dep_tree.py"


def write(path: Path, body: str = ""):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(textwrap.dedent(body).lstrip(), encoding="utf-8")


class DepTreeCliTests(unittest.TestCase):
    def run_cli(self, cwd: Path, *args: str):
        return subprocess.run(
            ["python3", str(SCRIPT), *args],
            cwd=cwd,
            text=True,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
        )

    def test_python_tree_json_resolves_imports(self):
        with TemporaryDirectory() as td:
            root = Path(td)
            write(root / "main.py", """
                import pkg.a
                from pkg import b
                from pkg.c import C
            """)
            write(root / "pkg" / "__init__.py")
            write(root / "pkg" / "a.py", "from . import b\n")
            write(root / "pkg" / "b.py")
            write(root / "pkg" / "c.py")

            res = self.run_cli(root, "tree", "main.py", "--json")

            self.assertEqual(res.returncode, 0, res.stderr)
            self.assertEqual(json.loads(res.stdout), {
                "tree": {
                    "main.py": {
                        "pkg/a.py": {"pkg/b.py": None},
                        "pkg/b.py": None,
                        "pkg/c.py": None,
                    }
                },
                "circularDependencies": [],
                "errors": {},
            })

    def test_cycle_is_reported_and_not_expanded_forever(self):
        with TemporaryDirectory() as td:
            root = Path(td)
            write(root / "a.py", "import b\n")
            write(root / "b.py", "import a\n")

            res = self.run_cli(root, "tree", "a.py", "--json")

            self.assertEqual(res.returncode, 0, res.stderr)
            payload = json.loads(res.stdout)
            self.assertEqual(payload["tree"], {"a.py": {"b.py": None}})
            self.assertEqual(payload["circularDependencies"], [["a.py", "b.py", "a.py"]])

    def test_explain_prints_matching_dependencies(self):
        with TemporaryDirectory() as td:
            root = Path(td)
            write(root / "src" / "products" / "p.py", "from users import u\nfrom helpers import h\n")
            write(root / "src" / "users" / "__init__.py")
            write(root / "src" / "users" / "u.py")
            write(root / "src" / "helpers" / "__init__.py")
            write(root / "src" / "helpers" / "h.py")

            res = self.run_cli(root, "explain", "src/products/*.py", "src/users/*.py")

            self.assertEqual(res.returncode, 0, res.stderr)
            self.assertEqual(res.stdout.strip(), "src/products/p.py -> src/users/u.py")

    def test_check_fails_on_denied_dependency_and_cycles(self):
        with TemporaryDirectory() as td:
            root = Path(td)
            write(root / "a.py", "import b\n")
            write(root / "b.py", "import forbidden\nimport a\n")
            write(root / "forbidden.py")
            write(root / ".dep-tree.yml", """
                check:
                  entrypoints:
                    - a.py
                  deny:
                    "b.py":
                      - "forbidden.py"
            """)

            res = self.run_cli(root, "check")

            self.assertEqual(res.returncode, 1)
            self.assertIn("Check failed", res.stderr)
            self.assertIn("b.py -> forbidden.py", res.stderr)
            self.assertIn("a.py -> b.py -> a.py", res.stderr)

    def test_config_creates_sample_once(self):
        with TemporaryDirectory() as td:
            root = Path(td)
            first = self.run_cli(root, "config")
            second = self.run_cli(root, "config")

            self.assertEqual(first.returncode, 0, first.stderr)
            self.assertTrue((root / ".dep-tree.yml").exists())
            self.assertEqual(second.returncode, 1)
            self.assertIn("cannot generate config file", second.stderr)

    def test_entrypoint_without_command_renders_tree(self):
        with TemporaryDirectory() as td:
            root = Path(td)
            write(root / "main.py", "import dep\n")
            write(root / "dep.py")

            res = self.run_cli(root, "main.py")

            self.assertEqual(res.returncode, 0, res.stderr)
            self.assertIn("main.py", res.stdout)
            self.assertIn("dep.py", res.stdout)


if __name__ == "__main__":
    unittest.main()
