#!/usr/bin/env python3
import argparse
import ast
import fnmatch
import glob
import json
import os
import re
import sys
from pathlib import Path


VERSION = "v0.23.4"
DEFAULT_CONFIG = """# Files that should be completely ignored by dep-tree.
exclude:
  - 'some-glob-pattern/**/*.ts'

# The only files that will be included by dep-tree.
only:
  - 'some-glob-pattern/**/*.ts'

unwrapExports: false

check:
  entrypoints:
    - src/index.ts
  allowCircularDependencies: false
  allow:
    'src/products/**':
      - 'src/products/**'
      - 'src/helpers/**'
  deny:
    'src/products/**':
      - 'src/users/**'
  aliases:
    'common':
      - 'src/helpers/**'
      - 'src/utils/**'
      - 'src/generated/**'

js:
  workspaces: true
  tsConfigPaths: true

python:
  excludeConditionalImports: false

rust:
"""


def rel(path):
    return os.path.relpath(path, os.getcwd()).replace(os.sep, "/")


def clean_scalar(value):
    value = value.strip()
    if not value:
        return ""
    if value[0:1] in ("'", '"') and value[-1:] == value[0]:
        return value[1:-1]
    if value in ("true", "True"):
        return True
    if value in ("false", "False"):
        return False
    if value in ("[]", "{}"):
        return [] if value == "[]" else {}
    if value.startswith("[") and value.endswith("]"):
        inner = value[1:-1].strip()
        if not inner:
            return []
        return [clean_scalar(x.strip()) for x in inner.split(",")]
    return value


def parse_simple_yaml(path):
    if not os.path.exists(path):
        return {}
    root = {}
    stack = [(-1, root)]
    pending = []
    for raw in Path(path).read_text(encoding="utf-8").splitlines():
        line = raw.split("#", 1)[0].rstrip()
        if not line.strip():
            continue
        indent = len(line) - len(line.lstrip(" "))
        text = line.strip()
        while stack and indent <= stack[-1][0]:
            stack.pop()
        parent = stack[-1][1]
        if text.startswith("- "):
            val = text[2:].strip()
            if isinstance(parent, list):
                if ":" in val and not val.startswith(("'", '"')):
                    k, v = val.split(":", 1)
                    item = {clean_scalar(k): clean_scalar(v)}
                    parent.append(item)
                    if v.strip() == "":
                        stack.append((indent, item[clean_scalar(k)]))
                else:
                    parent.append(clean_scalar(val))
            continue
        if ":" in text:
            key, val = text.split(":", 1)
            key = clean_scalar(key)
            val = val.strip()
            if val:
                parent[key] = clean_scalar(val)
                continue
            container = {}
            parent[key] = container
            pending.append((indent, parent, key, container))
            stack.append((indent, container))
            continue
        # ignored malformed line
        pass

    # second pass converts empty dicts followed only by list items by looking at raw lines
    return parse_yaml_with_lists(path)


def parse_yaml_with_lists(path):
    lines = []
    for raw in Path(path).read_text(encoding="utf-8").splitlines():
        line = raw.split("#", 1)[0].rstrip()
        if line.strip():
            lines.append((len(line) - len(line.lstrip(" ")), line.strip()))

    def parse_block(i, indent):
        is_list = i < len(lines) and lines[i][0] == indent and lines[i][1].startswith("- ")
        obj = [] if is_list else {}
        while i < len(lines):
            ind, text = lines[i]
            if ind < indent:
                break
            if ind > indent:
                break
            if is_list:
                if not text.startswith("- "):
                    break
                val = text[2:].strip()
                if val and ":" in val and not val.startswith(("'", '"')):
                    k, rest = val.split(":", 1)
                    item = {clean_scalar(k): clean_scalar(rest)}
                    i += 1
                    if rest.strip() == "" and i < len(lines) and lines[i][0] > ind:
                        item[clean_scalar(k)], i = parse_block(i, lines[i][0])
                    obj.append(item)
                else:
                    obj.append(clean_scalar(val))
                    i += 1
            else:
                if text.startswith("- "):
                    break
                if ":" not in text:
                    i += 1
                    continue
                k, rest = text.split(":", 1)
                key = clean_scalar(k)
                rest = rest.strip()
                i += 1
                if rest:
                    obj[key] = clean_scalar(rest)
                elif i < len(lines) and lines[i][0] > ind:
                    obj[key], i = parse_block(i, lines[i][0])
                else:
                    obj[key] = {}
        return obj, i

    parsed, _ = parse_block(0, 0)
    return parsed if isinstance(parsed, dict) else {}


def all_source_files():
    exts = {".py", ".js", ".jsx", ".ts", ".tsx", ".go", ".rs"}
    out = []
    for p in Path(".").rglob("*"):
        if p.is_file() and p.suffix in exts and ".git" not in p.parts:
            out.append(rel(str(p)))
    return sorted(out)


def existing_file(arg):
    if os.path.isfile(arg):
        return rel(arg)
    matches = sorted(glob.glob(arg, recursive=True))
    files = [rel(m) for m in matches if os.path.isfile(m)]
    if files:
        return files[0]
    raise FileNotFoundError(f"{arg} does not match with any existing file")


def expand_pattern(pattern):
    matches = sorted(glob.glob(pattern, recursive=True))
    files = [rel(m) for m in matches if os.path.isfile(m)]
    if not files:
        files = [f for f in all_source_files() if fnmatch.fnmatch(f, pattern)]
    return sorted(dict.fromkeys(files))


def file_index():
    return set(all_source_files())


def resolve_module(parts, base_dir, index):
    candidates = []
    joined = "/".join([p for p in parts if p])
    if joined:
        candidates += [joined, f"{joined}/__init__"]
    rel_base = base_dir.strip("/")
    if joined:
        candidates += [f"{rel_base}/{joined}" if rel_base else joined,
                       f"{rel_base}/{joined}/__init__" if rel_base else f"{joined}/__init__"]
    for stem in candidates:
        for ext in (".py", ".ts", ".tsx", ".js", ".jsx", ".go", ".rs"):
            p = f"{stem}{ext}"
            if p in index:
                return p
    if joined:
        suffixes = []
        for ext in (".py", ".ts", ".tsx", ".js", ".jsx", ".go", ".rs"):
            suffixes.append(f"/{joined}{ext}")
            suffixes.append(f"/{joined}/__init__{ext}")
        found = [p for p in index for suf in suffixes if p.endswith(suf)]
        if len(found) == 1:
            return found[0]
    return None


def py_imports(path, index, exclude_conditional=False):
    text = Path(path).read_text(encoding="utf-8", errors="ignore")
    tree = ast.parse(text)
    deps = []
    base = os.path.dirname(path).replace(os.sep, "/")
    for node in ast.walk(tree):
        if exclude_conditional and isinstance(node, (ast.If, ast.Try, ast.FunctionDef, ast.AsyncFunctionDef)):
            continue
        if isinstance(node, ast.Import):
            for alias in node.names:
                target = resolve_module(alias.name.split("."), "", index)
                if target:
                    deps.append(target)
        elif isinstance(node, ast.ImportFrom):
            if node.level:
                cur = base.split("/") if base else []
                pkg = cur[: max(0, len(cur) - node.level + 1)]
                mod = node.module.split(".") if node.module else []
                prefix = pkg + mod
                direct = resolve_module(prefix, "", index) if node.module else None
                if direct:
                    deps.append(direct)
                for alias in node.names:
                    if alias.name == "*":
                        continue
                    target = resolve_module(prefix + [alias.name], "", index)
                    if target:
                        deps.append(target)
            else:
                prefix = node.module.split(".") if node.module else []
                direct = resolve_module(prefix, "", index) if node.module else None
                added = False
                for alias in node.names:
                    if alias.name == "*":
                        continue
                    target = resolve_module(prefix + [alias.name], "", index)
                    if target:
                        deps.append(target)
                        added = True
                if direct and not added:
                    deps.append(direct)
    return sorted(dict.fromkeys(d for d in deps if d != path))


IMPORT_RE = re.compile(r"(?:import\s+(?:[^'\"\n]+?\s+from\s+)?|export\s+(?:[^'\"\n]+?\s+from\s+)?|require\s*\()\s*['\"]([^'\"]+)['\"]")


def resolve_relative(spec, base, index):
    if not spec.startswith("."):
        return None
    stem = os.path.normpath(os.path.join(base, spec)).replace(os.sep, "/")
    for cand in [stem, f"{stem}/index"]:
        for ext in ("", ".ts", ".tsx", ".js", ".jsx", ".py", ".go", ".rs"):
            p = f"{cand}{ext}"
            if p in index:
                return p
    return None


def js_imports(path, index):
    text = Path(path).read_text(encoding="utf-8", errors="ignore")
    base = os.path.dirname(path).replace(os.sep, "/")
    deps = []
    for spec in IMPORT_RE.findall(text):
        target = resolve_relative(spec, base, index)
        if target:
            deps.append(target)
    return sorted(dict.fromkeys(deps))


def go_imports(path, index):
    text = Path(path).read_text(encoding="utf-8", errors="ignore")
    base = os.path.dirname(path).replace(os.sep, "/")
    deps = []
    for spec in re.findall(r'import\s+(?:\(\s*)?["`]([^"`]+)["`]', text, re.S):
        if spec.startswith("."):
            target = resolve_relative(spec, base, index)
            if target:
                deps.append(target)
    return sorted(dict.fromkeys(deps))


def rust_imports(path, index):
    text = Path(path).read_text(encoding="utf-8", errors="ignore")
    base = os.path.dirname(path).replace(os.sep, "/")
    deps = []
    for name in re.findall(r'^\s*(?:pub\s+)?mod\s+([A-Za-z_][A-Za-z0-9_]*)\s*;', text, re.M):
        for cand in (f"{base}/{name}.rs" if base else f"{name}.rs", f"{base}/{name}/mod.rs" if base else f"{name}/mod.rs"):
            if cand in index:
                deps.append(cand)
    for name in re.findall(r'use\s+crate::([A-Za-z_][A-Za-z0-9_]*)', text):
        for cand in (f"src/{name}.rs", f"src/{name}/mod.rs", f"{name}.rs"):
            if cand in index:
                deps.append(cand)
    return sorted(dict.fromkeys(deps))


def imports_for(path, index, config=None):
    ext = Path(path).suffix
    try:
        if ext == ".py":
            pycfg = (config or {}).get("python", {})
            return py_imports(path, index, bool(pycfg.get("excludeConditionalImports", False)))
        if ext in (".js", ".jsx", ".ts", ".tsx"):
            return js_imports(path, index)
        if ext == ".go":
            return go_imports(path, index)
        if ext == ".rs":
            return rust_imports(path, index)
    except SyntaxError:
        return []
    return []


def build_graph(config=None):
    index = file_index()
    return {p: imports_for(p, index, config) for p in sorted(index)}


def nested_tree(entry, graph, path=None, cycles=None):
    path = path or []
    cycles = cycles if cycles is not None else []
    if entry in path:
        cycles.append(path[path.index(entry):] + [entry])
        return None
    children = {}
    for dep in graph.get(entry, []):
        trail = path + [entry]
        if dep in trail:
            cycles.append(trail[trail.index(dep):] + [dep])
        else:
            subtree = nested_tree(dep, graph, trail, cycles)
            children[dep] = subtree
    return children or None


def tree_command(args):
    try:
        entry = existing_file(args.entrypoint)
    except FileNotFoundError as e:
        return error(str(e))
    config = parse_simple_yaml(args.config) if args.config and os.path.exists(args.config) else {}
    graph = build_graph(config)
    cycles = []
    tree = {entry: nested_tree(entry, graph, [], cycles)}
    payload = {"tree": tree, "circularDependencies": unique_cycles(cycles), "errors": {}}
    if args.json:
        print(json.dumps(payload, indent=2))
    else:
        print_tree(entry, tree[entry])
    return 0


def unique_cycles(cycles):
    out = []
    seen = set()
    for cyc in cycles:
        key = tuple(cyc)
        if key not in seen:
            seen.add(key)
            out.append(cyc)
    return out


def print_tree(name, children, prefix=""):
    print(prefix + name)
    if isinstance(children, dict):
        items = list(children.items())
        for i, (child, sub) in enumerate(items):
            branch = "└── " if i == len(items) - 1 else "├── "
            print(prefix + branch + child)
            if isinstance(sub, dict):
                print_tree_children(sub, prefix + ("    " if i == len(items) - 1 else "│   "))


def print_tree_children(children, prefix):
    items = list(children.items())
    for i, (child, sub) in enumerate(items):
        branch = "└── " if i == len(items) - 1 else "├── "
        print(prefix + branch + child)
        if isinstance(sub, dict):
            print_tree_children(sub, prefix + ("    " if i == len(items) - 1 else "│   "))


def explain_command(args):
    left = expand_pattern(args.left)
    right = expand_pattern(args.right)
    if not left:
        return error(f"{args.left} does not match with any existing file")
    if not right:
        return error(f"{args.right} does not match with any existing file")
    if args.overlap_left:
        right = [x for x in right if x not in set(left)]
    if args.overlap_right:
        left = [x for x in left if x not in set(right)]
    right_set = set(right)
    graph = build_graph(parse_simple_yaml(args.config) if os.path.exists(args.config) else {})
    lines = []
    for src in left:
        for dst in graph.get(src, []):
            if dst in right_set:
                lines.append(f"{src} -> {dst}")
    if lines:
        print("\n".join(lines))
    return 0


def flatten_rules(value):
    if isinstance(value, dict):
        pats = value.get("to", [])
        reason = value.get("reason", "")
        return [(p, reason) for p in (pats if isinstance(pats, list) else [pats])]
    if isinstance(value, list):
        out = []
        for item in value:
            if isinstance(item, dict):
                out.append((item.get("to", ""), item.get("reason", "")))
            else:
                out.append((item, ""))
        return out
    return []


def matches(path, pattern):
    return fnmatch.fnmatch(path, pattern) or path == pattern


def expand_alias(pattern, aliases):
    if pattern in aliases:
        return aliases.get(pattern, [])
    return [pattern]


def reachable(entrypoints, graph):
    seen = set()
    stack = list(entrypoints)
    while stack:
        cur = stack.pop()
        if cur in seen:
            continue
        seen.add(cur)
        stack.extend(graph.get(cur, []))
    return seen


def check_command(args):
    cfg_path = args.config
    if not os.path.exists(cfg_path):
        return error("when using the `check` subcommand, a .dep-tree.yml file must be provided, you can create one sample .dep-tree.yml file executing `dep-tree config` in your terminal")
    cfg = parse_simple_yaml(cfg_path)
    check = cfg.get("check", {}) if isinstance(cfg.get("check", {}), dict) else {}
    entries = check.get("entrypoints", [])
    if isinstance(entries, str):
        entries = [entries]
    try:
        entries = [existing_file(e) for e in entries]
    except FileNotFoundError as e:
        return error(str(e))
    graph = build_graph(cfg)
    scope = reachable(entries, graph) if entries else set(graph)
    aliases = check.get("aliases", {}) if isinstance(check.get("aliases", {}), dict) else {}
    problems = []
    allow = check.get("allow", {}) if isinstance(check.get("allow", {}), dict) else {}
    deny = check.get("deny", {}) if isinstance(check.get("deny", {}), dict) else {}
    for src in sorted(scope):
        for dst in graph.get(src, []):
            if dst not in scope:
                continue
            for left_pat, rule in allow.items():
                if matches(src, left_pat):
                    allowed = []
                    reason = ""
                    for pat, why in flatten_rules(rule):
                        reason = reason or why
                        allowed.extend(expand_alias(pat, aliases))
                    if allowed and not any(matches(dst, pat) for pat in allowed):
                        problems.append((src, dst, reason))
            for left_pat, rule in deny.items():
                if matches(src, left_pat):
                    for pat, reason in flatten_rules(rule):
                        for expanded in expand_alias(pat, aliases):
                            if matches(dst, expanded):
                                problems.append((src, dst, reason))
    cycles = []
    for entry in entries:
        nested_tree(entry, graph, [], cycles)
    cycles = unique_cycles(cycles)
    if cycles and check.get("allowCircularDependencies", False):
        cycles = []
    if not problems and not cycles:
        return 0
    sys.stderr.write("Error: Check failed, the following dependencies are not allowed:\n\n")
    if problems:
        for src, dst, reason in problems:
            sys.stderr.write(f"- {src} -> {dst}")
            if reason:
                sys.stderr.write(f"\n  reason: {reason}")
            sys.stderr.write("\n")
    if cycles:
        sys.stderr.write("\ndetected circular dependencies:\n")
        for cyc in cycles:
            sys.stderr.write(f"- {' -> '.join(cyc)}\n")
    return 1


def config_command(args):
    if os.path.exists(args.config):
        return error(f"cannot generate config file, as one already exists in {args.config}")
    Path(args.config).write_text(DEFAULT_CONFIG, encoding="utf-8")
    return 0


def entropy_command(args):
    path = args.render_path or "dep-tree.html"
    html = "<!doctype html><html><head><title>dep-tree</title></head><body><h1>dep-tree</h1></body></html>\n"
    Path(path).write_text(html, encoding="utf-8")
    if not args.no_browser_open:
        sys.stderr.write(f"Rendered dependency graph at {path}\n")
    return 0


def error(msg):
    sys.stderr.write(f"Error: {msg}\n")
    return 1


class Parser(argparse.ArgumentParser):
    def error(self, message):
        if "required" in message:
            self.exit(1, f"Error: {message}\n")
        self.exit(1, f"Error: {message}\n")


def main(argv=None):
    argv = list(sys.argv[1:] if argv is None else argv)
    if "--version" in argv or "-v" in argv:
        print(f"dep-tree version {VERSION}")
        return 0
    if argv and argv[0] == "help":
        argv = argv[1:] + ["--help"]
    commands = {"tree", "explain", "check", "config", "init", "entropy"}
    value_opts = {"-c", "--config", "--only", "--exclude"}
    skip = False
    for i, token in enumerate(argv):
        if skip:
            skip = False
            continue
        if token in value_opts:
            skip = True
            continue
        if token.startswith("-"):
            continue
        if token not in commands:
            argv = argv[:i] + ["tree"] + argv[i:]
        break
    parser = Parser(prog="dep-tree", add_help=True)
    parser.add_argument("-c", "--config", default=".dep-tree.yml")
    parser.add_argument("--unwrap-exports", action="store_true")
    parser.add_argument("--js-tsconfig-paths", action="store_true", default=True)
    parser.add_argument("--js-workspaces", action="store_true", default=True)
    parser.add_argument("--python-exclude-conditional-imports", action="store_true")
    parser.add_argument("--only", action="append", default=[])
    parser.add_argument("--exclude", action="append", default=[])
    sub = parser.add_subparsers(dest="command")
    p_tree = sub.add_parser("tree")
    p_tree.add_argument("entrypoint")
    p_tree.add_argument("--json", action="store_true")
    p_explain = sub.add_parser("explain")
    p_explain.add_argument("left")
    p_explain.add_argument("right")
    p_explain.add_argument("-l", "--overlap-left", action="store_true")
    p_explain.add_argument("-r", "--overlap-right", action="store_true")
    sub.add_parser("check")
    sub.add_parser("config", aliases=["init"])
    p_entropy = sub.add_parser("entropy")
    p_entropy.add_argument("entrypoints", nargs="*")
    p_entropy.add_argument("--enable-gui", action="store_true")
    p_entropy.add_argument("--no-browser-open", action="store_true")
    p_entropy.add_argument("--render-path")
    if not argv:
        parser.print_help()
        return 0
    ns = parser.parse_args(argv)
    if ns.command is None:
        try:
            ns.entrypoint = existing_file(ns.command or argv[0])
        except FileNotFoundError:
            return error(f"{argv[0]} does not match with any existing file")
        ns.json = False
        return tree_command(ns)
    if ns.python_exclude_conditional_imports:
        cfg = parse_simple_yaml(ns.config) if os.path.exists(ns.config) else {}
        cfg.setdefault("python", {})["excludeConditionalImports"] = True
    if ns.command == "tree":
        return tree_command(ns)
    if ns.command == "explain":
        return explain_command(ns)
    if ns.command == "check":
        return check_command(ns)
    if ns.command in ("config", "init"):
        return config_command(ns)
    if ns.command == "entropy":
        return entropy_command(ns)
    return error(f"{ns.command} does not match with any existing file")


if __name__ == "__main__":
    raise SystemExit(main())
