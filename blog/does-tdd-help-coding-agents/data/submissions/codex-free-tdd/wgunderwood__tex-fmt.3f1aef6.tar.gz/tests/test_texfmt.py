import subprocess
import tempfile
import textwrap
import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
EXE = ROOT / "texfmt.py"


class TexFmtTests(unittest.TestCase):
    def run_cmd(self, args, cwd, stdin=None):
        return subprocess.run(
            ["python3", str(EXE), *args],
            cwd=cwd,
            input=stdin,
            text=True,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
        )

    def test_formats_readme_example_to_stdout(self):
        with tempfile.TemporaryDirectory() as td:
            tmp = Path(td)
            source = textwrap.dedent(
                r"""
                \documentclass{article}

                \begin{document}

                \begin{itemize}
                \item Lists with items
                over multiple lines
                \end{itemize}

                \begin{equation}
                E = m c^2
                \end{equation}

                \end{document}
                """
            ).lstrip()
            expected = textwrap.dedent(
                r"""
                \documentclass{article}

                \begin{document}

                \begin{itemize}
                  \item Lists with items
                    over multiple lines
                \end{itemize}

                \begin{equation}
                  E = m c^2
                \end{equation}

                \end{document}
                """
            ).lstrip()
            path = tmp / "sample.tex"
            path.write_text(source)

            result = self.run_cmd(["--print", str(path)], tmp)

            self.assertEqual(result.returncode, 0)
            self.assertEqual(result.stdout, expected)
            self.assertEqual(result.stderr, "")
            self.assertEqual(path.read_text(), source)

    def test_check_reports_incorrect_formatting_without_rewrite(self):
        with tempfile.TemporaryDirectory() as td:
            tmp = Path(td)
            path = tmp / "bad.tex"
            path.write_text("\\begin{document}\n\\begin{equation}\nx=1\n\\end{equation}\n\\end{document}\n")

            result = self.run_cmd(["--check", str(path)], tmp)

            self.assertEqual(result.returncode, 1)
            self.assertEqual(result.stdout, "")
            self.assertEqual(result.stderr, f"ERROR: tex-fmt {path}: Incorrect formatting. \n")
            self.assertEqual(path.read_text().splitlines()[2], "x=1")

    def test_fail_on_change_rewrites_and_exits_one(self):
        with tempfile.TemporaryDirectory() as td:
            tmp = Path(td)
            path = tmp / "bad.tex"
            path.write_text("\\begin{document}\n\\begin{equation}\nx=1\n\\end{equation}\n\\end{document}\n")

            result = self.run_cmd(["--fail-on-change", str(path)], tmp)

            self.assertEqual(result.returncode, 1)
            self.assertEqual(result.stdout, "")
            self.assertEqual(result.stderr, "")
            self.assertIn("  x=1\n", path.read_text())

    def test_stdin_formats_to_stdout(self):
        with tempfile.TemporaryDirectory() as td:
            result = self.run_cmd(
                ["--stdin"],
                Path(td),
                stdin="\\begin{document}\n\\begin{equation}\nx=1\n\\end{equation}\n\\end{document}\n",
            )

            self.assertEqual(result.returncode, 0)
            self.assertEqual(
                result.stdout,
                "\\begin{document}\n\\begin{equation}\n  x=1\n\\end{equation}\n\\end{document}\n",
            )
            self.assertEqual(result.stderr, "")

    def test_config_can_disable_wrapping_and_change_indent(self):
        with tempfile.TemporaryDirectory() as td:
            tmp = Path(td)
            (tmp / "tex-fmt.toml").write_text('tabsize = 4\nwrap = false\nlists = ["customlist"]\n')
            path = tmp / "cfg.tex"
            path.write_text(
                "\\begin{document}\n\\begin{customlist}\n\\item item\ncont\n\\end{customlist}\n"
                "This is a very long line with many words that should not wrap even with the default margin applied.\n"
                "\\end{document}\n"
            )

            result = self.run_cmd(["--print", str(path)], tmp)

            self.assertEqual(result.returncode, 0)
            self.assertIn("    \\item item\n        cont\n", result.stdout)
            self.assertIn("should not wrap even with the default margin applied.\n", result.stdout)

    def test_nested_list_closers_return_to_outer_indentation(self):
        with tempfile.TemporaryDirectory() as td:
            tmp = Path(td)
            path = tmp / "list.tex"
            path.write_text(
                "\\begin{document}\n\\begin{enumerate}\n\\item one\ncontinued\n\\begin{itemize}\n"
                "\\item inner\nmore\n\\end{itemize}\n\\end{enumerate}\n\\end{document}\n"
            )

            result = self.run_cmd(["--print", str(path)], tmp)

            self.assertEqual(result.returncode, 0)
            self.assertEqual(
                result.stdout,
                "\\begin{document}\n\\begin{enumerate}\n  \\item one\n    continued\n"
                "    \\begin{itemize}\n      \\item inner\n        more\n    \\end{itemize}\n"
                "\\end{enumerate}\n\\end{document}\n",
            )

    def test_wraplen_uses_reference_breaks_for_plain_text(self):
        with tempfile.TemporaryDirectory() as td:
            tmp = Path(td)
            path = tmp / "wrap.tex"
            path.write_text(
                "\\begin{document}\n"
                "This is a very long line with many words that should be wrapped somewhere before the configured margin and continue with indentation.\n"
                "\\end{document}\n"
            )

            result = self.run_cmd(["--print", "--wraplen", "50", str(path)], tmp)

            self.assertEqual(result.returncode, 0)
            self.assertEqual(
                result.stdout,
                "\\begin{document}\nThis is a very long line with many\n"
                "words that should be wrapped somewhere\nbefore the configured margin and\n"
                "continue with indentation.\n\\end{document}\n",
            )

    def test_bibtex_entry_fields_are_indented(self):
        with tempfile.TemporaryDirectory() as td:
            tmp = Path(td)
            path = tmp / "ref.bib"
            path.write_text("@article{key,\ntitle={A Title},\nauthor={Me},\nyear={2024}\n}\n")

            result = self.run_cmd(["--print", str(path)], tmp)

            self.assertEqual(result.returncode, 0)
            self.assertEqual(
                result.stdout,
                "@article{key,\n  title={A Title},\n  author={Me},\n  year={2024}\n}\n",
            )

    def test_args_output_matches_reference_alignment(self):
        with tempfile.TemporaryDirectory() as td:
            result = self.run_cmd(["--args", "--check", "--print", "foo.tex"], Path(td))

            self.assertEqual(result.returncode, 0)
            self.assertIn("  fail-on-change:          true\n", result.stdout)
            self.assertIn("  verbatims:               verbatim\n", result.stdout)
            self.assertIn("  no-indent-envs:          document\n", result.stdout)
            self.assertIn("  wrap-chars:               \n", result.stdout)


if __name__ == "__main__":
    unittest.main()
