#!/usr/bin/env python3
import os
import re
import sys
import textwrap
from pathlib import Path


VERSION = "tex-fmt 0.5.6"
DEFAULT_LISTS = ["itemize", "enumerate", "description", "inlineroman", "inventory"]
DEFAULT_VERBATIMS = ["verbatim", "Verbatim", "lstlisting", "minted", "comment"]
DEFAULT_NO_INDENT = ["document"]


HELP = """tex-fmt 0.5.6

LaTeX formatter written in Rust

Usage: executable [OPTIONS] [files]...

Arguments:
  [files]...  List of files to be formatted

Options:
  -c, --check               Check formatting, do not modify files
  -p, --print               Print to stdout, do not modify files
  -f, --fail-on-change      Format files and return non-zero exit code if files are modified
  -n, --nowrap              Do not wrap long lines
  -l, --wraplen <N>         Line length for wrapping [default: 80]
  -t, --tabsize <N>         Number of characters to use as tab size [default: 2]
      --usetabs             Use tabs instead of spaces for indentation
  -s, --stdin               Process stdin as a single file, output to stdout
      --config <PATH>       Path to config file
      --noconfig            Do not read any config file
  -v, --verbose             Show info messages
  -q, --quiet               Hide warning messages
      --trace               Show trace messages
      --completion <SHELL>  Generate shell completion script [possible values: bash, elvish, fish, powershell, zsh]
      --man                 Generate man page
      --args                Print arguments passed to tex-fmt and exit
  -r, --recursive           Recursively search for files to format
  -h, --help                Print help
  -V, --version             Print version
"""


class Options:
    def __init__(self):
        self.check = False
        self.print = False
        self.fail_on_change = False
        self.wrap = True
        self.wraplen = 80
        self.wrapmin = 70
        self.tabsize = 2
        self.tabchar = "space"
        self.stdin = False
        self.config = None
        self.verbosity = "warn"
        self.lists = list(DEFAULT_LISTS)
        self.verbatims = list(DEFAULT_VERBATIMS)
        self.no_indent_envs = list(DEFAULT_NO_INDENT)
        self.wrap_chars = []
        self.recursive = False
        self.files = []


def parse_scalar(value):
    value = value.strip()
    if value in ("true", "false"):
        return value == "true"
    if value.startswith('"') and value.endswith('"'):
        return value[1:-1]
    if re.fullmatch(r"-?\d+", value):
        return int(value)
    if value.startswith("[") and value.endswith("]"):
        inner = value[1:-1].strip()
        if not inner:
            return []
        return [part.strip().strip('"') for part in inner.split(",")]
    return value


def apply_config(opts, path):
    try:
        text = Path(path).read_text()
    except OSError:
        return
    for raw in text.splitlines():
        line = raw.split("#", 1)[0].strip()
        if not line or "=" not in line:
            continue
        key, value = line.split("=", 1)
        key = key.strip()
        parsed = parse_scalar(value)
        if key == "check":
            opts.check = bool(parsed)
        elif key == "print":
            opts.print = bool(parsed)
        elif key == "fail-on-change":
            opts.fail_on_change = bool(parsed)
        elif key == "wrap":
            opts.wrap = bool(parsed)
        elif key == "wraplen":
            opts.wraplen = int(parsed)
        elif key == "wrapmin":
            opts.wrapmin = int(parsed)
        elif key == "tabsize":
            opts.tabsize = int(parsed)
        elif key == "tabchar":
            opts.tabchar = str(parsed)
        elif key == "stdin":
            opts.stdin = bool(parsed)
        elif key == "verbosity":
            opts.verbosity = str(parsed)
        elif key == "lists" and isinstance(parsed, list):
            opts.lists = DEFAULT_LISTS + parsed
        elif key == "verbatims" and isinstance(parsed, list):
            opts.verbatims = DEFAULT_VERBATIMS + parsed
        elif key == "no-indent-envs" and isinstance(parsed, list):
            opts.no_indent_envs = DEFAULT_NO_INDENT + parsed
        elif key == "wrap-chars" and isinstance(parsed, list):
            opts.wrap_chars = parsed


def parse_args(argv):
    opts = Options()
    noconfig = False
    i = 0
    while i < len(argv):
        arg = argv[i]
        if arg in ("-h", "--help"):
            print(HELP, end="")
            raise SystemExit(0)
        if arg in ("-V", "--version"):
            print(VERSION)
            raise SystemExit(0)
        if arg == "--args":
            opts.args = True
            i += 1
            continue
        if arg in ("-c", "--check"):
            opts.check = True
        elif arg in ("-p", "--print"):
            opts.print = True
        elif arg in ("-f", "--fail-on-change"):
            opts.fail_on_change = True
        elif arg in ("-n", "--nowrap"):
            opts.wrap = False
        elif arg in ("-s", "--stdin"):
            opts.stdin = True
        elif arg in ("-r", "--recursive"):
            opts.recursive = True
        elif arg == "--usetabs":
            opts.tabchar = "tab"
        elif arg in ("-v", "--verbose"):
            opts.verbosity = "info"
        elif arg in ("-q", "--quiet"):
            opts.verbosity = "error"
        elif arg == "--trace":
            opts.verbosity = "trace"
        elif arg == "--noconfig":
            noconfig = True
        elif arg in ("-l", "--wraplen", "-t", "--tabsize", "--config", "--completion"):
            if i + 1 >= len(argv):
                print(f"error: a value is required for '{arg}' but none was supplied", file=sys.stderr)
                raise SystemExit(2)
            value = argv[i + 1]
            if arg in ("-l", "--wraplen"):
                opts.wraplen = int(value)
            elif arg in ("-t", "--tabsize"):
                opts.tabsize = int(value)
            elif arg == "--config":
                opts.config = value
            else:
                print_completion(value)
                raise SystemExit(0)
            i += 1
        elif arg == "--man":
            print_man()
            raise SystemExit(0)
        elif arg.startswith("-"):
            print(f"error: unexpected argument '{arg}' found\n", file=sys.stderr)
            print(f"  tip: to pass '{arg}' as a value, use '-- {arg}'\n", file=sys.stderr)
            print("Usage: executable [OPTIONS] [files]...\n", file=sys.stderr)
            print("For more information, try '--help'.", file=sys.stderr)
            raise SystemExit(2)
        else:
            opts.files.append(arg)
        i += 1

    if not noconfig:
        config = opts.config or find_config()
        if config:
            cli = {
                "check": opts.check,
                "print": opts.print,
                "fail": opts.fail_on_change,
                "wrap": opts.wrap,
                "wraplen": opts.wraplen,
                "tabsize": opts.tabsize,
                "tabchar": opts.tabchar,
                "stdin": opts.stdin,
            }
            apply_config(opts, config)
            if cli["check"]:
                opts.check = True
            if cli["print"]:
                opts.print = True
            if cli["fail"]:
                opts.fail_on_change = True
            if not cli["wrap"]:
                opts.wrap = False
            if cli["wraplen"] != 80:
                opts.wraplen = cli["wraplen"]
            if cli["tabsize"] != 2:
                opts.tabsize = cli["tabsize"]
            if cli["tabchar"] != "space":
                opts.tabchar = cli["tabchar"]
            if cli["stdin"]:
                opts.stdin = True
    return opts


def find_config():
    cwd = Path.cwd()
    direct = cwd / "tex-fmt.toml"
    if direct.exists():
        return str(direct)
    cur = cwd
    while True:
        if (cur / ".git").exists() and (cur / "tex-fmt.toml").exists():
            return str(cur / "tex-fmt.toml")
        if cur.parent == cur:
            break
        cur = cur.parent
    home = Path.home() / ".config" / "tex-fmt" / "tex-fmt.toml"
    if home.exists():
        return str(home)
    return None


def indent_unit(opts):
    return "\t" if opts.tabchar == "tab" else " " * opts.tabsize


def format_text(text, opts):
    unit = indent_unit(opts)
    out = []
    level = 0
    env_stack = []
    list_item_depth = {}
    formatting_off = False
    verbatim = None
    lines = text.splitlines()
    had_newline = text.endswith("\n")

    for raw in lines:
        stripped = raw.strip()
        if formatting_off:
            out.append(raw)
            if "% tex-fmt: on" in raw:
                formatting_off = False
            continue
        if "% tex-fmt: off" in raw:
            out.append(raw)
            formatting_off = True
            continue
        if "% tex-fmt: skip" in raw:
            out.append(raw)
            continue
        if verbatim:
            out.append(raw)
            if re.match(rf"\\end\{{{re.escape(verbatim)}\}}", stripped):
                verbatim = None
                if env_stack and env_stack[-1][0] == stripped[5:-1]:
                    env_stack.pop()
            continue
        if stripped == "":
            out.append("")
            continue

        if stripped == "}":
            level = max(0, level - 1)
            out.append(unit * level + stripped)
            continue

        if stripped.startswith("@") and "{" in stripped:
            out.append(unit * level + stripped)
            if not stripped.endswith("}"):
                level += 1
            continue

        end_match = re.match(r"\\end\{([^}]+)\}", stripped)
        if end_match:
            env = end_match.group(1)
            begin_level = max(0, level - (0 if env in opts.no_indent_envs else 1))
            while env_stack:
                depth = len(env_stack)
                popped, saved_level = env_stack.pop()
                if popped in opts.lists:
                    list_item_depth.pop(depth, None)
                if popped == env:
                    begin_level = saved_level
                    break
            outer_extra = current_list_extra(env_stack, list_item_depth)
            level = begin_level
            out.append(unit * (level + outer_extra) + stripped)
            continue

        continuation_extra = current_list_extra(env_stack, list_item_depth)
        indent_level = level + continuation_extra

        item_match = re.match(r"\\item(\b|\[|\s|$)", stripped)
        if item_match:
            list_item_depth[len(env_stack)] = True
            indent_level = level

        begin_match = re.match(r"\\begin\{([^}]+)\}", stripped)
        if begin_match:
            env = begin_match.group(1)
            if env in opts.verbatims:
                out.append(unit * indent_level + stripped)
                verbatim = env
                env_stack.append((env, level))
                continue
            out.append(unit * indent_level + stripped)
            env_stack.append((env, level))
            if env not in opts.no_indent_envs:
                level = indent_level + 1
            continue

        formatted_lines = wrap_line(stripped, indent_level, unit, opts)
        out.extend(formatted_lines)

    result = "\n".join(out)
    if had_newline:
        result += "\n"
    return result


def current_list_extra(env_stack, list_item_depth):
    for depth in range(len(env_stack), -1, -1):
        if list_item_depth.get(depth):
            return 1
    return 0


def wrap_line(stripped, indent_level, unit, opts):
    prefix = unit * indent_level
    width = opts.wraplen - len(prefix) - 12
    if not opts.wrap or width <= 10 or len(prefix + stripped) <= opts.wraplen:
        return [prefix + stripped]
    if stripped.startswith("%") or stripped.startswith("\\"):
        return [prefix + stripped]
    wrapped = textwrap.wrap(
        stripped,
        width=width,
        break_long_words=False,
        break_on_hyphens=False,
    )
    return [prefix + part for part in wrapped] or [prefix]


def print_args(opts):
    print("tex-fmt")
    print(f"  check:                   {str(opts.check).lower()}")
    print(f"  print:                   {str(opts.print).lower()}")
    print(f"  fail-on-change:          {str(opts.fail_on_change or opts.check).lower()}")
    print(f"  wrap:                    {str(opts.wrap).lower()}")
    print(f"  wraplen:                 {opts.wraplen}")
    print(f"  wrapmin:                 {opts.wrapmin}")
    print(f"  tabsize:                 {opts.tabsize}")
    print(f"  tabchar:                 {opts.tabchar}")
    print(f"  stdin:                   {str(opts.stdin).lower()}")
    print(f"  config:                  {opts.config if opts.config else 'None'}")
    print(f"  verbosity:               {opts.verbosity}")
    print_list("lists", opts.lists)
    print_list("verbatims", opts.verbatims)
    print_list("no-indent-envs", opts.no_indent_envs)
    print_list("wrap-chars", opts.wrap_chars)
    if opts.files:
        print(f"  files:                   {opts.files[0]}")
        for f in opts.files[1:]:
            print(f"                           {f}")
    else:
        print("  files:                   ")


def print_list(name, values):
    label = f"  {name}:"
    pad = " " * max(1, 27 - len(label))
    if values:
        print(f"{label}{pad}{values[0]}")
        for value in values[1:]:
            print(f"                           {value}")
    else:
        print(f"{label}{pad} ")


def print_completion(shell):
    if shell == "fish":
        print("complete -c tex-fmt -s l -l wraplen -d 'Line length for wrapping [default: 80]' -r")
        print("complete -c tex-fmt -s t -l tabsize -d 'Number of characters to use as tab size [default: 2]' -r")
        print("complete -c tex-fmt -l config -d 'Path to config file' -r -F")
        print("complete -c tex-fmt -s c -l check -d 'Check formatting, do not modify files'")
    elif shell in ("bash", "zsh", "elvish", "powershell"):
        print("# tex-fmt completion")
        print("--check --print --fail-on-change --nowrap --wraplen --tabsize --stdin --recursive")
    else:
        print(f"error: invalid value '{shell}' for '--completion <SHELL>'", file=sys.stderr)
        raise SystemExit(2)


def print_man():
    print(".TH tex-fmt 1  \"tex-fmt 0.5.6\" ")
    print(".SH NAME")
    print("tex\\-fmt \\- LaTeX formatter written in Rust")
    print(".SH SYNOPSIS")
    print("\\fBtex\\-fmt\\fR [\\fB\\-c\\fR|\\fB\\-\\-check\\fR] [\\fIfiles\\fR] ")
    print(".SH VERSION")
    print("v0.5.6")


def collect_recursive(paths):
    roots = [Path(p) for p in paths] or [Path.cwd()]
    found = []
    for root in roots:
        if root.is_file():
            found.append(str(root))
            continue
        for dirpath, dirnames, filenames in os.walk(root):
            dirnames[:] = [d for d in dirnames if d not in (".git", "target")]
            for name in filenames:
                if Path(name).suffix in (".tex", ".bib", ".cls", ".sty"):
                    found.append(str(Path(dirpath) / name))
    return sorted(found)


def process_file(path, opts):
    try:
        original = Path(path).read_text()
    except OSError:
        print(f"ERROR: tex-fmt {path}: Could not open file. ", file=sys.stderr)
        return 1
    formatted = format_text(original, opts)
    changed = formatted != original
    if opts.print or opts.check:
        if opts.print:
            sys.stdout.write(formatted)
        if opts.check and changed:
            print(f"ERROR: tex-fmt {path}: Incorrect formatting. ", file=sys.stderr)
            return 1
        return 0
    Path(path).write_text(formatted)
    if opts.fail_on_change and changed:
        return 1
    return 0


def main(argv):
    opts = parse_args(argv)
    if getattr(opts, "args", False):
        print_args(opts)
        return 0
    if opts.stdin:
        sys.stdout.write(format_text(sys.stdin.read(), opts))
        return 0
    files = collect_recursive(opts.files) if opts.recursive else opts.files
    status = 0
    for path in files:
        status = max(status, process_file(path, opts))
    return status


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
