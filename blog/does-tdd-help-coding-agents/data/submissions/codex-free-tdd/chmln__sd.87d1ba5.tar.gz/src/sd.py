#!/usr/bin/env python3
import re
import sys
from dataclasses import dataclass


HELP = """sd v1.0.0
An intuitive find & replace CLI

Usage: executable [OPTIONS] <FIND> <REPLACE_WITH> [FILES]...

Arguments:
  <FIND>          The regexp or string (if using `-F`) to search for
  <REPLACE_WITH>  What to replace each match with. Unless in string mode, you may use captured
                  values like $1, $2, etc
  [FILES]...      The path to file(s). This is optional - sd can also read from STDIN

Options:
  -p, --preview                   Display changes in a human reviewable format (the specifics of the
                                  format are likely to change in the future)
  -F, --fixed-strings             Treat FIND and REPLACE_WITH args as literal strings
  -n, --max-replacements <LIMIT>  Limit the number of replacements that can occur per file. 0
                                  indicates unlimited replacements [default: 0]
  -f, --flags <FLAGS>             Regex flags. May be combined (like `-f mc`).
  -h, --help                      Print help (see more with '--help')
  -V, --version                   Print version
"""


@dataclass
class Options:
    preview: bool = False
    fixed: bool = False
    max_replacements: int = 0
    flags: str = ""
    find: str = ""
    replace: str = ""
    files: list[str] = None


def usage_error(message: str) -> int:
    sys.stderr.write(f"error: {message}\n\n")
    sys.stderr.write("Usage: executable [OPTIONS] <FIND> <REPLACE_WITH> [FILES]...\n\n")
    sys.stderr.write("For more information, try '--help'.\n")
    return 2


def parse_args(argv: list[str]):
    opts = Options(files=[])
    positional = []
    i = 0
    end_flags = False
    while i < len(argv):
        arg = argv[i]
        if not end_flags and arg == "--":
            end_flags = True
            i += 1
        elif not end_flags and arg in ("-h", "--help"):
            print(HELP, end="")
            return None, 0
        elif not end_flags and arg in ("-V", "--version"):
            print("sd 1.0.0")
            return None, 0
        elif not end_flags and arg in ("-p", "--preview"):
            opts.preview = True
            i += 1
        elif not end_flags and arg in ("-F", "--fixed-strings"):
            opts.fixed = True
            i += 1
        elif not end_flags and arg in ("-n", "--max-replacements"):
            if i + 1 >= len(argv):
                return None, usage_error("a value is required for '--max-replacements <LIMIT>'")
            try:
                opts.max_replacements = int(argv[i + 1])
            except ValueError:
                sys.stderr.write(f"error: invalid value '{argv[i + 1]}' for '--max-replacements <LIMIT>': invalid digit found in string\n\n")
                sys.stderr.write("For more information, try '--help'.\n")
                return None, 2
            i += 2
        elif not end_flags and arg.startswith("--max-replacements="):
            try:
                opts.max_replacements = int(arg.split("=", 1)[1])
            except ValueError:
                return None, usage_error(f"invalid value '{arg.split('=', 1)[1]}' for '--max-replacements <LIMIT>'")
            i += 1
        elif not end_flags and arg in ("-f", "--flags"):
            if i + 1 >= len(argv):
                return None, usage_error("a value is required for '--flags <FLAGS>'")
            opts.flags += argv[i + 1]
            i += 2
        elif not end_flags and arg.startswith("--flags="):
            opts.flags += arg.split("=", 1)[1]
            i += 1
        elif not end_flags and arg.startswith("-"):
            return None, usage_error(f"unexpected argument '{arg}' found\n\n  tip: to pass '{arg}' as a value, use '-- {arg}'")
        else:
            positional.append(arg)
            i += 1
    if len(positional) < 2:
        sys.stderr.write("error: the following required arguments were not provided:\n")
        if len(positional) == 0:
            sys.stderr.write("  <FIND>\n  <REPLACE_WITH>\n\n")
        else:
            sys.stderr.write("  <REPLACE_WITH>\n\n")
        sys.stderr.write("Usage: executable <FIND> <REPLACE_WITH> [FILES]...\n\n")
        sys.stderr.write("For more information, try '--help'.\n")
        return None, 2
    opts.find, opts.replace, opts.files = positional[0], positional[1], positional[2:]
    return opts, None


def compile_pattern(opts: Options):
    flags = re.MULTILINE
    for flag in opts.flags:
        if flag == "i":
            flags |= re.IGNORECASE
        elif flag == "c":
            flags &= ~re.IGNORECASE
        elif flag == "s":
            flags |= re.DOTALL
        elif flag == "m":
            flags |= re.MULTILINE
        elif flag == "e":
            flags &= ~re.MULTILINE
    pattern = re.escape(opts.find) if opts.fixed else opts.find
    if "w" in opts.flags:
        pattern = r"\b(?:" + pattern + r")\b"
    try:
        return re.compile(pattern, flags)
    except re.error as exc:
        sys.stderr.write(f"error: invalid regex {exc}\n")
        return None


def make_replacer(replacement: str, fixed: bool):
    replacement = unescape_replacement(replacement)
    if fixed:
        return lambda match: replacement

    def replace_match(match: re.Match):
        out = []
        i = 0
        while i < len(replacement):
            ch = replacement[i]
            if ch != "$":
                out.append(ch)
                i += 1
                continue
            if i + 1 >= len(replacement):
                out.append("$")
                i += 1
                continue
            nxt = replacement[i + 1]
            if nxt == "$":
                out.append("$")
                i += 2
                continue
            if nxt == "{":
                end = replacement.find("}", i + 2)
                if end == -1:
                    out.append("$")
                    i += 1
                    continue
                name = replacement[i + 2:end]
                out.append(group_value(match, name))
                i = end + 1
                continue
            if nxt.isdigit():
                j = i + 1
                while j < len(replacement) and replacement[j].isdigit():
                    j += 1
                if j < len(replacement) and (replacement[j].isalpha() or replacement[j] == "_"):
                    raise ValueError(ambiguous_error(replacement, i + 1, j))
                out.append(group_value(match, replacement[i + 1:j]))
                i = j
                continue
            if nxt.isalpha() or nxt == "_":
                j = i + 1
                while j < len(replacement) and (replacement[j].isalnum() or replacement[j] == "_"):
                    j += 1
                out.append(group_value(match, replacement[i + 1:j]))
                i = j
                continue
            out.append("$")
            i += 1
        return "".join(out)

    return replace_match


def group_value(match: re.Match, name: str) -> str:
    try:
        key = int(name) if name.isdigit() else name
        value = match.group(key)
        return "" if value is None else value
    except (IndexError, KeyError):
        return ""


def unescape_replacement(text: str) -> str:
    out = []
    i = 0
    previous_hex_escape = False
    while i < len(text):
        if text[i] != "\\" or i + 1 >= len(text):
            out.append(text[i])
            i += 1
            previous_hex_escape = False
            continue
        code = text[i + 1]
        if previous_hex_escape and code in ("x", "u"):
            out.append(code)
            i += 2
            previous_hex_escape = False
            continue
        if code == "n":
            out.append("\n")
            i += 2
            previous_hex_escape = False
        elif code == "t":
            out.append("\t")
            i += 2
            previous_hex_escape = False
        elif code == "r":
            out.append("\r")
            i += 2
            previous_hex_escape = False
        elif code == "\\":
            out.append("\\")
            i += 2
            previous_hex_escape = False
        elif code == "x" and i + 3 < len(text) and all(c in "0123456789abcdefABCDEF" for c in text[i + 2:i + 4]):
            out.append(chr(int(text[i + 2:i + 4], 16)))
            i += 4
            previous_hex_escape = True
        elif code == "u" and i + 5 < len(text) and all(c in "0123456789abcdefABCDEF" for c in text[i + 2:i + 6]):
            out.append(chr(int(text[i + 2:i + 6], 16)))
            i += 6
            previous_hex_escape = True
        else:
            out.append("\\")
            out.append(code)
            i += 2
            previous_hex_escape = False
    return "".join(out)


def ambiguous_error(replacement: str, start: int, end: int) -> str:
    rest = replacement[end:]
    return (
        f"error: The numbered capture group `${replacement[start:end]}` in the replacement text is ambiguous.\n"
        f"hint: Use curly braces to disambiguate it `${{{replacement[start:end]}}}{rest}`.\n"
        f"{replacement}\n"
        f"{' ' * start}{'^' * (end - start + 1)}"
    )


def replace_text(pattern, repl_func, text: str, limit: int):
    return pattern.sub(repl_func, text, 0 if limit == 0 else limit)


def main(argv=None):
    opts, status = parse_args(list(sys.argv[1:] if argv is None else argv))
    if status is not None:
        return status

    pattern = compile_pattern(opts)
    if pattern is None:
        return 1
    repl_func = make_replacer(opts.replace, opts.fixed)
    try:
        if opts.files:
            for name in opts.files:
                try:
                    with open(name, "r", encoding="utf-8") as fh:
                        text = fh.read()
                except OSError:
                    sys.stderr.write(f"error: invalid path: {name}\n")
                    return 1
                changed = replace_text(pattern, repl_func, text, opts.max_replacements)
                if opts.preview:
                    sys.stdout.write(changed)
                else:
                    with open(name, "w", encoding="utf-8") as fh:
                        fh.write(changed)
        else:
            sys.stdout.write(replace_text(pattern, repl_func, sys.stdin.read(), opts.max_replacements))
    except ValueError as exc:
        sys.stderr.write(str(exc) + "\n")
        return 1
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
