import os, subprocess, sys, tempfile, pathlib

ROOT = pathlib.Path(__file__).resolve().parents[1]
SD = ROOT / "src" / "sd.py"


def run_sd(args, input_text=""):
    return subprocess.run([sys.executable, str(SD), *args], input=input_text, text=True, capture_output=True)


def run_sd_bytes(args, input_bytes=b""):
    return subprocess.run([sys.executable, str(SD), *args], input=input_bytes, capture_output=True)


def test_replaces_regex_on_stdin():
    r = run_sd([r"\s+$", ""], "lorem ipsum 23   ")
    assert r.returncode == 0
    assert r.stdout == "lorem ipsum 23"
    assert r.stderr == ""


def test_fixed_strings_treats_find_and_replacement_literally():
    r = run_sd(["-F", "((([])))", "$1"], "lots((([]))) of special chars")
    assert r.returncode == 0
    assert r.stdout == "lots$1 of special chars"


def test_max_replacements_limits_each_input():
    r = run_sd(["-n", "1", "a", "X"], "abcabc")
    assert r.returncode == 0
    assert r.stdout == "Xbcabc"


def test_flags_control_case_word_multiline_and_dotall():
    assert run_sd(["-f", "i", "a", "X"], "Ab aB").stdout == "Xb XB"
    assert run_sd(["-f", "w", "cat", "dog"], "cat scatter concatenate").stdout == "dog scatter concatenate"
    assert run_sd(["-f", "e", "^b", "X"], "a\nb").stdout == "a\nb"
    assert run_sd(["-f", "s", "a.b", "X"], "a\nb").stdout == "X"


def test_replacement_expands_numbered_named_whole_and_escaped_dollar():
    assert run_sd([r"foo(\d+)bar", r"x${1}y"], "foo123bar").stdout == "x123y"
    assert run_sd([r"(?P<dollars>\d+)\.(?P<cents>\d+)", r"${dollars}_dollars and $cents cents"], "123.45").stdout == "123_dollars and 45 cents"
    assert run_sd([r"foo(\d+)bar", r"$0 $$"], "foo123bar").stdout == "foo123bar $"
    assert run_sd_bytes(["foo", r"\u0042"], b"foo").stdout == b"B"
    assert run_sd_bytes(["foo", r"\n\t\r\x41\u0042"], b"foo").stdout == b"\n\t\rAu0042"


def test_ambiguous_numbered_capture_is_an_error():
    r = run_sd([r"foo(\d+)bar", r"x$1y"], "foo123bar")
    assert r.returncode == 1
    assert "hint: Use curly braces to disambiguate it `${1}y`." in r.stderr
    assert "  ^^" in r.stderr
    assert r.stdout == ""


def test_files_are_modified_in_place_and_preview_writes_changed_text(tmp_path):
    path = tmp_path / "a.txt"
    path.write_text("one two one\nthree one\n")
    r = run_sd(["one", "X", str(path)])
    assert r.returncode == 0
    assert r.stdout == ""
    assert path.read_text() == "X two X\nthree X\n"

    path.write_text("one two one\n")
    r = run_sd(["-p", "one", "X", str(path)])
    assert r.returncode == 0
    assert r.stdout == "X two X\n"
    assert path.read_text() == "one two one\n"


def test_help_version_and_missing_args():
    version = run_sd(["-V"])
    assert version.returncode == 0
    assert version.stdout == "sd 1.0.0\n"

    help_result = run_sd(["--help"])
    assert help_result.returncode == 0
    assert "sd v1.0.0" in help_result.stdout
    assert "Usage: executable" in help_result.stdout

    missing = run_sd([])
    assert missing.returncode == 2
    assert "required arguments" in missing.stderr
