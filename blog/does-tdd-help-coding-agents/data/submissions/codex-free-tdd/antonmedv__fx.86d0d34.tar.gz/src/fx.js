#!/usr/bin/env node

const fs = require("fs");

const VERSION = "39.2.0";

function help() {
  return `
  fx ${VERSION}
    Terminal JSON viewer

  Usage
    fx data.json
    fx data.json .field
    curl ... | fx

  Flags
    -h, --help            print help
    -v, --version         print version
    --themes              print themes
    --comp <shell>        print completion script
    -r, --raw             treat input as a raw string
    -s, --slurp           read all inputs into an array
    --yaml                parse input as YAML
    --toml                parse input as TOML
    --strict              strict mode
    --no-inline           disable inlining in output
    --game-of-life        play the game of life

  More info
    https://fx.wtf

  Author
    Anton Medvedev <anton@medv.io>
`;
}

function parseArgs(argv) {
  const opts = { raw: false, slurp: false, yaml: false, toml: false, filters: [], files: [] };
  for (let i = 0; i < argv.length; i++) {
    const arg = argv[i];
    if (arg === "-h" || arg === "--help") opts.help = true;
    else if (arg === "-v" || arg === "--version") opts.version = true;
    else if (arg === "--themes") opts.themes = true;
    else if (arg === "--game-of-life") opts.game = true;
    else if (arg === "--comp") opts.comp = argv[++i] || "";
    else if (arg === "-r" || arg === "--raw") opts.raw = true;
    else if (arg === "-s" || arg === "--slurp") opts.slurp = true;
    else if (arg === "--yaml") opts.yaml = true;
    else if (arg === "--toml") opts.toml = true;
    else if (arg === "--strict" || arg === "--no-inline") {}
    else if (fs.existsSync(arg) && fs.statSync(arg).isFile()) opts.files.push(arg);
    else opts.filters.push(arg);
  }
  return opts;
}

function splitJsonInputs(text) {
  const trimmed = text.trim();
  if (!trimmed) return [];
  try {
    return [JSON.parse(trimmed)];
  } catch (_) {
    const values = [];
    for (const line of trimmed.split(/\r?\n/)) {
      if (line.trim()) values.push(JSON.parse(line));
    }
    return values;
  }
}

function parseScalar(s) {
  const t = s.trim();
  if (/^-?\d+(\.\d+)?$/.test(t)) return Number(t);
  if (t === "true") return true;
  if (t === "false") return false;
  if (t === "null") return null;
  return t.replace(/^["']|["']$/g, "");
}

function parseToml(text) {
  const out = {};
  for (const line of text.split(/\r?\n/)) {
    const m = line.match(/^\s*([A-Za-z_][\w-]*)\s*=\s*(.*?)\s*$/);
    if (m) out[m[1]] = parseScalar(m[2]);
  }
  return out;
}

function parseYaml(text) {
  const lines = text.split(/\r?\n/);
  const out = {};
  for (let i = 0; i < lines.length; i++) {
    let m = lines[i].match(/^\s*([A-Za-z_][\w-]*):\s*(.*?)\s*$/);
    if (!m) continue;
    const key = m[1];
    if (m[2] !== "") {
      out[key] = parseScalar(m[2]);
      continue;
    }
    const arr = [];
    while (i + 1 < lines.length) {
      const item = lines[i + 1].match(/^\s*-\s*(.*?)\s*$/);
      if (!item) break;
      arr.push(parseScalar(item[1]));
      i++;
    }
    out[key] = arr;
  }
  return out;
}

function readInputs(opts) {
  const text = opts.files.length
    ? opts.files.map((file) => fs.readFileSync(file, "utf8")).join("\n")
    : fs.readFileSync(0, "utf8");
  if (opts.raw) {
    const lines = text.replace(/\n$/, "").split(/\r?\n/);
    return opts.slurp ? [lines] : lines;
  }
  if (opts.toml) return [parseToml(text)];
  if (opts.yaml) return [parseYaml(text)];
  const values = splitJsonInputs(text);
  return opts.slurp ? [values] : values;
}

function expressionFor(filter) {
  if (filter === "" || filter === ".") return "input";
  if (filter === "keys") return "Object.keys(input)";
  if (filter === "values") return "Object.values(input)";
  if (filter.startsWith(".")) return "input" + filter;
  return filter;
}

function evaluate(input, filter) {
  const expr = expressionFor(filter);
  const fn = new Function("input", `return (${expr});`);
  return fn.call(input, input);
}

function format(value) {
  if (value === undefined) return "undefined";
  if (typeof value === "string") return value;
  if (typeof value === "number" || typeof value === "boolean" || value === null) return String(value);
  return JSON.stringify(value, null, 2);
}

function printThemes() {
  const sample = {
    string: "Fox jumps over the lazy dog",
    number: 1234567890,
    boolean: true,
    null: null,
    collapsed: { preview: "..." },
  };
  const chunks = [];
  for (let i = 0; i < 16; i++) chunks.push(`export FX_THEME="${i}"\n` + JSON.stringify(sample, null, 2));
  return chunks.join("\n\n");
}

function completion(shell) {
  if (shell === "bash") return "complete -o filenames -C fx fx";
  if (shell === "fish") return "complete --command fx --arguments '(COMP_FISH=(commandline -cp) fx)'";
  if (shell === "zsh") return "#compdef fx\n\n_fx() {\n    local -a reply\n}\ncompdef _fx fx";
  return "unknown shell type";
}

function main() {
  const opts = parseArgs(process.argv.slice(2));
  if (opts.help) return process.stdout.write(help() + "\n");
  if (opts.version) return process.stdout.write(VERSION + "\n");
  if (opts.themes) return process.stdout.write(printThemes() + "\n");
  if (opts.comp !== undefined) return process.stdout.write(completion(opts.comp) + "\n");
  if (opts.game) return process.stdout.write("\x1b[2J\x1b[?25l\x1b[H");

  const filter = opts.filters.join(" ") || "";
  const values = readInputs(opts);
  if (!filter) {
    process.stderr.write("panic: could not open a new TTY: open /dev/tty: no such device or address\n\n");
    process.exit(2);
  }

  const output = values.map((value) => format(evaluate(value, filter))).join("\n");
  process.stdout.write(output + (output ? "\n" : ""));
}

try {
  main();
} catch (err) {
  const msg = err && err.message ? err.message : String(err);
  process.stderr.write(msg + "\n");
  process.exit(1);
}
