#!/usr/bin/env python3
import html
import os
import struct
import sys
from pathlib import Path


USAGE = "Usage: elfcat <filename>\nWrites <filename>.html to CWD.\n"

PT_TYPES = {
    0: "NULL", 1: "LOAD", 2: "DYNAMIC", 3: "INTERP", 4: "NOTE",
    5: "SHLIB", 6: "PHDR", 7: "TLS", 0x6474E550: "GNU_EH_FRAME (OS-specific)",
    0x6474E551: "GNU_STACK (OS-specific)", 0x6474E552: "GNU_RELRO (OS-specific)",
    0x6474E553: "GNU_PROPERTY (OS-specific)",
}

SH_TYPES = {
    0: "NULL", 1: "PROGBITS", 2: "SYMTAB", 3: "STRTAB", 4: "RELA", 5: "HASH",
    6: "DYNAMIC", 7: "NOTE", 8: "NOBITS", 9: "REL", 10: "SHLIB", 11: "DYNSYM",
    14: "INIT_ARRAY", 15: "FINI_ARRAY", 16: "PREINIT_ARRAY", 17: "GROUP",
    18: "SYMTAB_SHNDX", 0x6ffffff6: "GNU_HASH (OS-specific)",
    0x6fffffff: "VER_NEED (OS-specific)", 0x6ffffffe: "VER_DEF (OS-specific)",
    0x6ffffffe + 1: "HIOS",
}


class ElfError(Exception):
    pass


def cstr(buf, off):
    if off < 0 or off >= len(buf):
        return ""
    end = buf.find(b"\0", off)
    if end < 0:
        end = len(buf)
    return buf[off:end].decode("utf-8", "replace")


def read_struct(fmt, data, off, what):
    size = struct.calcsize(fmt)
    if off < 0 or off + size > len(data):
        raise ElfError(f"file is smaller than {what}")
    return struct.unpack_from(fmt, data, off)


def parse_elf(data):
    if len(data) < 16:
        raise ElfError("file is smaller than ELF header's e_ident")
    if data[:4] != b"\x7fELF":
        raise ElfError("mismatched magic: not an ELF file")
    elf_class = data[4]
    endian_id = data[5]
    if elf_class not in (1, 2):
        raise ElfError(f"unknown ELF class: {elf_class}")
    if endian_id == 1:
        endian = "<"
    elif endian_id == 2:
        endian = ">"
    else:
        raise ElfError(f"unknown ELF endianness: {endian_id}")

    if elf_class == 2:
        hdr_vals = read_struct(endian + "16sHHIQQQIHHHHHH", data, 0, "ELF header")
        (_, e_type, e_machine, e_version, e_entry, e_phoff, e_shoff, e_flags,
         e_ehsize, e_phentsize, e_phnum, e_shentsize, e_shnum, e_shstrndx) = hdr_vals
        ph_fmt = endian + "IIQQQQQQ"
        sh_fmt = endian + "IIQQQQIIQQ"
    else:
        hdr_vals = read_struct(endian + "16sHHIIIIIHHHHHH", data, 0, "ELF header")
        (_, e_type, e_machine, e_version, e_entry, e_phoff, e_shoff, e_flags,
         e_ehsize, e_phentsize, e_phnum, e_shentsize, e_shnum, e_shstrndx) = hdr_vals
        ph_fmt = endian + "IIIIIIII"
        sh_fmt = endian + "IIIIIIIIII"

    phdrs = []
    ph_size = struct.calcsize(ph_fmt)
    for i in range(e_phnum):
        off = e_phoff + i * e_phentsize
        vals = read_struct(ph_fmt, data, off, "program header")
        if elf_class == 2:
            p_type, p_flags, p_offset, p_vaddr, p_paddr, p_filesz, p_memsz, p_align = vals
        else:
            p_type, p_offset, p_vaddr, p_paddr, p_filesz, p_memsz, p_flags, p_align = vals
        phdrs.append(dict(index=i, type=p_type, flags=p_flags, offset=p_offset,
                          vaddr=p_vaddr, filesz=p_filesz, memsz=p_memsz,
                          align=p_align, raw_off=off, raw_size=min(e_phentsize, ph_size)))

    shdrs = []
    sh_size = struct.calcsize(sh_fmt)
    for i in range(e_shnum):
        off = e_shoff + i * e_shentsize
        vals = read_struct(sh_fmt, data, off, "section header")
        sh_name, sh_type, sh_flags, sh_addr, sh_offset, sh_size_v, sh_link, sh_info, sh_addralign, sh_entsize = vals
        shdrs.append(dict(index=i, name_off=sh_name, name="", type=sh_type, flags=sh_flags,
                          addr=sh_addr, offset=sh_offset, size=sh_size_v, link=sh_link,
                          info=sh_info, align=sh_addralign, entsize=sh_entsize,
                          raw_off=off, raw_size=min(e_shentsize, sh_size)))

    if 0 <= e_shstrndx < len(shdrs):
        tab_hdr = shdrs[e_shstrndx]
        tab = data[tab_hdr["offset"]:tab_hdr["offset"] + tab_hdr["size"]]
        for sh in shdrs:
            sh["name"] = cstr(tab, sh["name_off"])

    return dict(bits=64 if elf_class == 2 else 32, endian=endian, header=dict(
        type=e_type, machine=e_machine, version=e_version, entry=e_entry,
        phoff=e_phoff, shoff=e_shoff, flags=e_flags, ehsize=e_ehsize,
        phentsize=e_phentsize, phnum=e_phnum, shentsize=e_shentsize,
        shnum=e_shnum, shstrndx=e_shstrndx), phdrs=phdrs, shdrs=shdrs)


def type_name(value, table):
    if value in table:
        return table[value]
    return f"Unknown: {value}"


def ph_flags(flags):
    out = ""
    if flags & 4:
        out += "R"
    if flags & 2:
        out += "W"
    if flags & 1:
        out += "X"
    return out or "0"


def sh_flags(flags):
    names = [(1, "W"), (2, "A"), (4, "X"), (0x10, "M"), (0x20, "S"), (0x40, "I"),
             (0x80, "L"), (0x100, "O"), (0x200, "G"), (0x400, "T"), (0x800, "C")]
    s = "".join(name for bit, name in names if flags & bit)
    return s or "0"


def fmt_num(n, title_hex=False):
    title = hex(n) if title_hex else str(n)
    text = f"0x{n:x}"
    return f"<span class='number' title='{title}'>{text}</span>"


def fmt_size(n):
    if n >= 1024:
        kib = n / 1024
        human = f"{kib:.1f} KiB" if abs(kib - round(kib)) > 0.05 else f"{int(round(kib))} KiB"
        body = f"{n} ({human})"
    else:
        body = str(n)
    return f"<span class='number' title='0x{n:x}'>{body}</span>"


def escape(s):
    return html.escape(str(s), quote=False)


def hexdump(data):
    offs, bytes_lines, ascii_lines = [], [], []
    for off in range(0, len(data), 16):
        chunk = data[off:off + 16]
        offs.append(f"{off:08x}")
        bytes_lines.append(" ".join(f"{b:02x}" for b in chunk))
        ascii_lines.append("".join(chr(b) if 32 <= b < 127 else "." for b in chunk))
    return "\n".join(offs), "\n".join(bytes_lines), "\n".join(ascii_lines)


def note_rows(data, offset, size, endian):
    rows = []
    pos = offset
    end = min(len(data), offset + size)
    while pos + 12 <= end:
        namesz, descsz, ntype = struct.unpack_from(endian + "III", data, pos)
        pos += 12
        if pos + namesz > end:
            break
        name_raw = data[pos:pos + namesz]
        pos += (namesz + 3) & ~3
        if pos + descsz > end:
            break
        desc = data[pos:pos + descsz]
        pos += (descsz + 3) & ~3
        name = name_raw.rstrip(b"\0").decode("utf-8", "replace")
        rows.append("<tr><td><br></td></tr>")
        rows.append(f"<tr> <td>Name:</td> <td>{escape(name)}</td> </tr>")
        rows.append(f"<tr> <td>Type:</td> <td>0x{ntype:x}</td> </tr>")
        if name == "GNU" and ntype == 3:
            rows.append(f"<tr> <td>Build ID:</td> <td>{desc.hex()}</td> </tr>")
        else:
            desc_html = " ".join(f"<b>{b:02x}</b>" for b in desc)
            rows.append(f"<tr> <td>Desc:</td> <td>{desc_html} </td> </tr>")
    return rows


def render_report(filename, data, elf):
    title = Path(filename).name
    offsets, hexbytes, asciis = hexdump(data)
    h = []
    h.append("<!doctype html>")
    h.append("<html>")
    h.append("  <head>")
    h.append("    <meta charset='utf-8'>")
    h.append("    <meta name='viewport' content='width=900, initial-scale=1'>")
    h.append(f"    <title>{escape(title)}</title>")
    h.append("    <style>")
    h.append("      html { font-family: monospace; }")
    h.append("      #headertable { width: 100%; } #rightmenu { vertical-align: top; text-align: right; float: right; }")
    h.append("      .textbutton { color: #222; cursor: pointer; background: none; border: none; padding: 0; margin: 0 0 0.5em 0; }")
    h.append("      .textbutton::before { content: '['; } .textbutton::after { content: ']'; }")
    h.append("      .legend_rect { float: left; margin-right: 0.4em; width: 3em; height: 1.5em; border: 1px solid rgba(0,0,0,.2); }")
    h.append("      ul { list-style: none; padding: 0; } li { clear: left; height: 2em; display: flex; align-items: center; }")
    h.append("      .number { text-decoration: underline dotted #888; } #desc { width: 250px; }")
    h.append("      .conceal { display: none; border: 1px solid #000; max-width: 650px; margin-bottom: 1em; }")
    h.append("      .phdr_itable::before { content: 'Program header'; } .shdr_itable::before { content: 'Section header'; }")
    h.append("      .segment_itable::before { content: 'Segment'; } .section_itable::before { content: 'Section'; }")
    h.append("      #offsets { display: inline-block; text-align: right; white-space: pre; }")
    h.append("      #bytes { border: 1px solid; display: inline-block; word-break: break-word; width: 47ch; white-space: pre; }")
    h.append("      #ascii { border: 1px solid; display: inline-block; width: 16ch; white-space: pre; }")
    h.append("      .ident { background:#ffb; } .ehdr { background:#fdd; } .phdr { background:#dfd; } .shdr { background:#ddf; }")
    h.append("      .segment { background:#eee; } .section { background:#def; }")
    h.append("    </style>")
    h.append("  </head>")
    h.append("  <body>")
    h.append("    <table id='headertable'><tr><td><h1>elfcat</h1></td><td id='rightmenu'><a id='credits'>elfcat 0.1.10</a><button class='textbutton' id='settings_toggle'>Settings</button><button class='textbutton' id='help_toggle'>Help</button></td></tr></table>")
    h.append("    <div id='help'>")
    h.append("      <p>The leftmost column shows offsets within the file. The middle column is the file dump. It has ELF structs, sections and segments highlighted. Some fields that reference areas in the file are clickable and connected with arrows. The rightmost column shows printable ASCII characters corresponding to the file bytes.</p>")
    h.append("      <ul>")
    h.append("        <li><span class='legend_rect ident'></span>ELF Identification</li>")
    h.append("        <li><span class='legend_rect ehdr'></span>ELF Header</li>")
    h.append("        <li><span class='legend_rect phdr'></span>Program Header</li>")
    h.append("        <li><span class='legend_rect shdr'></span>Section Header</li>")
    h.append("        <li><span class='legend_rect segment'></span>Segment</li>")
    h.append("        <li><span class='legend_rect section'></span>Section</li>")
    h.append("      </ul>")
    h.append("    </div>")
    h.append(f"    <div id='offsets'>{escape(offsets)}</div>")
    h.append(f"    <div id='bytes'>{escape(hexbytes)}</div>")
    h.append(f"    <div id='ascii'>{escape(asciis)}</div>")
    h.append("    <table id='sticky_table' cellspacing='0'><tr><td id='desc'></td><td class='infotables'>")

    hdr = elf["header"]
    h.append("      <table class='conceal itable' id='info_ehdr'><th colspan='2' class='ehdr_itable'>ELF Header</th>")
    h.append(f"        <tr> <td>Class:</td> <td>ELF{elf['bits']}</td> </tr>")
    h.append(f"        <tr> <td>Entry point:</td> <td>{fmt_num(hdr['entry'])}</td> </tr>")
    h.append(f"        <tr> <td>Program headers:</td> <td>{hdr['phnum']}</td> </tr>")
    h.append(f"        <tr> <td>Section headers:</td> <td>{hdr['shnum']}</td> </tr>")
    h.append("      </table>")

    for ph in elf["phdrs"]:
        h.append(f"      <table class='conceal itable' id='info_phdr{ph['index']}'>")
        h.append("      <th colspan='2' class='phdr_itable'></th>")
        h.append(f"        <tr> <td>Type:</td> <td>{type_name(ph['type'], PT_TYPES)}</td> </tr>")
        h.append(f"        <tr> <td>Flags:</td> <td>{ph_flags(ph['flags'])}</td> </tr>")
        h.append(f"        <tr> <td>Offset in file:</td> <td>{fmt_num(ph['offset'])}</td> </tr>")
        h.append(f"        <tr> <td>Size in file:</td> <td>{fmt_size(ph['filesz'])}</td> </tr>")
        h.append(f"        <tr> <td>Vaddr in memory:</td> <td>{fmt_num(ph['vaddr'])}</td> </tr>")
        h.append(f"        <tr> <td>Size in memory:</td> <td>{fmt_size(ph['memsz'])}</td> </tr>")
        h.append(f"        <tr> <td>Alignment:</td> <td>{fmt_num(ph['align'])}</td> </tr>")
        h.append("      </table>")

    for sh in elf["shdrs"]:
        h.append(f"      <table class='conceal itable' id='info_shdr{sh['index']}'>")
        h.append("      <th colspan='2' class='shdr_itable'></th>")
        h.append(f"        <tr> <td>Index:</td> <td>{sh['index']}</td> </tr>")
        h.append(f"        <tr> <td>Name:</td> <td>{escape(sh['name'])}</td> </tr>")
        h.append(f"        <tr> <td>Type:</td> <td>{type_name(sh['type'], SH_TYPES)}</td> </tr>")
        h.append(f"        <tr> <td>Flags:</td> <td>{sh_flags(sh['flags'])}</td> </tr>")
        h.append(f"        <tr> <td>Vaddr in memory:</td> <td>{fmt_num(sh['addr'])}</td> </tr>")
        h.append(f"        <tr> <td>Offset in file:</td> <td>{fmt_num(sh['offset'])}</td> </tr>")
        h.append(f"        <tr> <td>Size in file:</td> <td>{fmt_size(sh['size'])}</td> </tr>")
        h.append(f"        <tr> <td>Linked section:</td> <td>{sh['link']}</td> </tr>")
        h.append(f"        <tr> <td>Extra info:</td> <td>{fmt_num(sh['info'], title_hex=True)}</td> </tr>")
        h.append(f"        <tr> <td>Alignment:</td> <td>{fmt_num(sh['align'])}</td> </tr>")
        h.append(f"        <tr> <td>Size of entries:</td> <td>{fmt_size(sh['entsize'])}</td> </tr>")
        h.append("      </table>")

    h.append("    </td><td class='infotables'>")
    for ph in elf["phdrs"]:
        h.append(f"      <table class='conceal itable' id='info_segment{ph['index']}'>")
        h.append("      <th colspan='2' class='segment_itable'></th>")
        h.append(f"        <tr> <td>Type:</td> <td>{type_name(ph['type'], PT_TYPES)}</td> </tr>")
        h.append(f"        <tr> <td>Size in file:</td> <td>{fmt_size(ph['filesz'])}</td> </tr>")
        h.append(f"        <tr> <td>Size in memory:</td> <td>{fmt_size(ph['memsz'])}</td> </tr>")
        if ph["type"] == 3:
            interp = data[ph["offset"]:ph["offset"] + ph["filesz"]].split(b"\0", 1)[0].decode("utf-8", "replace")
            h.append("        <tr><td><br></td></tr>")
            h.append(f"        <tr> <td>Interpreter:</td> <td>{escape(interp)}</td> </tr>")
        if ph["type"] == 4:
            h.extend("        " + row for row in note_rows(data, ph["offset"], ph["filesz"], elf["endian"]))
        h.append("      </table>")

    for sh in elf["shdrs"]:
        h.append(f"      <table class='conceal itable' id='info_section{sh['index']}'>")
        h.append("      <th colspan='2' class='section_itable'></th>")
        h.append(f"        <tr> <td>Name:</td> <td>{escape(sh['name'])}</td> </tr>")
        h.append(f"        <tr> <td>Size in file:</td> <td>{fmt_size(sh['size'])}</td> </tr>")
        h.append("      </table>")

    h.append("    </td></tr></table>")
    h.append("    <script type='text/javascript'>")
    h.append("      function connect(a,b){} function pushArrowElems(){}")
    for ph in elf["phdrs"]:
        h.append(f"      connect('.bin_phdr{ph['index']} > .p_offset', '.bin_segment{ph['index']}');")
    for sh in elf["shdrs"]:
        h.append(f"      connect('.bin_shdr{sh['index']} > .sh_offset', '.bin_section{sh['index']}');")
        if sh["link"]:
            h.append(f"      connect('.bin_shdr{sh['index']} > .sh_link', '.bin_shdr{sh['link']}');")
    h.append("      pushArrowElems();")
    h.append("    </script>")
    h.append("  </body>")
    h.append("</html>")
    return "\n".join(h) + "\n"


def main(argv):
    if argv == ["--version"]:
        print("elfcat 0.1.10")
        return 0
    if argv == ["--help"]:
        sys.stdout.write(USAGE)
        return 0
    if len(argv) != 1:
        sys.stdout.write(USAGE)
        return 1
    filename = argv[0]
    try:
        data = Path(filename).read_bytes()
    except OSError as e:
        msg = e.strerror or str(e)
        sys.stderr.write(f'Failed to read file "{filename}": {msg}')
        if e.errno is not None:
            sys.stderr.write(f" (os error {e.errno})")
        sys.stderr.write("\n")
        return 1
    try:
        elf = parse_elf(data)
    except ElfError as e:
        sys.stderr.write(f"Failed to parse ELF: {e}\n")
        return 1
    out_name = Path(filename).name + ".html"
    Path(out_name).write_text(render_report(filename, data, elf), encoding="utf-8")
    return 0


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
