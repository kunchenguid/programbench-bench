import subprocess
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
ELFCAT = ROOT / "src" / "elfcat.py"


def run_cmd(args, cwd=None):
    return subprocess.run(["python3", str(ELFCAT), *args], cwd=cwd or ROOT, text=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)


class ElfcatCliTests(unittest.TestCase):
    def test_help_and_arg_count_match_documented_cli(self):
        usage = "Usage: elfcat <filename>\nWrites <filename>.html to CWD.\n"
        for args in ([], ["--help"], ["a", "b"]):
            with self.subTest(args=args):
                proc = run_cmd(args)
                self.assertEqual(proc.stdout, usage)
                self.assertEqual(proc.stderr, "")
                self.assertEqual(proc.returncode, 0 if args == ["--help"] else 1)

    def test_version(self):
        proc = run_cmd(["--version"])
        self.assertEqual(proc.returncode, 0)
        self.assertEqual(proc.stdout, "elfcat 0.1.10\n")
        self.assertEqual(proc.stderr, "")

    def test_read_and_parse_errors(self):
        with tempfile.TemporaryDirectory() as td:
            td = Path(td)
            (td / "notelf").write_bytes(b"NOPE1234567890123456")
            proc = run_cmd(["missing"], cwd=td)
            self.assertEqual(proc.returncode, 1)
            self.assertEqual(proc.stdout, "")
            self.assertIn('Failed to read file "missing":', proc.stderr)
            self.assertIn("No such file or directory", proc.stderr)

            proc = run_cmd([str(td / "notelf")], cwd=td)
            self.assertEqual(proc.returncode, 1)
            self.assertEqual(proc.stdout, "")
            self.assertEqual(proc.stderr, "Failed to parse ELF: mismatched magic: not an ELF file\n")

    def test_generates_report_for_elf_in_current_directory_using_basename(self):
        with tempfile.TemporaryDirectory() as td:
            td = Path(td)
            c = td / "hello.c"
            c.write_text("int main(){return 42;}\n")
            subprocess.check_call(["gcc", "-o", str(td / "hello"), str(c)])
            proc = run_cmd([str(td / "hello")], cwd=td)
            self.assertEqual(proc.returncode, 0, proc.stderr)
            html_path = td / "hello.html"
            self.assertTrue(html_path.exists())
            html = html_path.read_text()
            self.assertIn("<!doctype html>", html)
            self.assertIn("<title>hello</title>", html)
            self.assertIn("ELF Identification", html)
            self.assertIn("Program header", html)
            self.assertIn("Section header", html)
            self.assertIn("<td>LOAD</td>", html)
            self.assertIn("<td>.text</td>", html)
            self.assertIn("<div id='offsets'>", html)
            self.assertIn("<div id='bytes'>", html)
            self.assertIn("<div id='ascii'>", html)


if __name__ == "__main__":
    unittest.main()
