import os
import json
import subprocess
import tempfile
import unittest


ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))


def build():
    subprocess.run(["bash", "compile.sh"], cwd=ROOT, check=True)


class CliTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        build()

    def run_cli(self, *args):
        return subprocess.run(
            [os.path.join(ROOT, "executable"), *args],
            cwd=ROOT,
            text=True,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
        )

    def test_schema_only_reports_valid_schema(self):
        with tempfile.TemporaryDirectory() as td:
            schema = os.path.join(td, "schema.json")
            with open(schema, "w", encoding="utf-8") as f:
                f.write('{"type":"object"}')

            result = self.run_cli(schema)

        self.assertEqual(result.returncode, 0)
        self.assertEqual(result.stdout, "Schema is valid\n")
        self.assertEqual(result.stderr, "")

    def test_text_output_reports_valid_and_invalid_instances(self):
        with tempfile.TemporaryDirectory() as td:
            schema = os.path.join(td, "schema.json")
            good = os.path.join(td, "good.json")
            bad = os.path.join(td, "bad.json")
            with open(schema, "w", encoding="utf-8") as f:
                f.write('{"type":"object","properties":{"age":{"type":"integer"}},"required":["age"]}')
            with open(good, "w", encoding="utf-8") as f:
                f.write('{"age":5}')
            with open(bad, "w", encoding="utf-8") as f:
                f.write('{"age":"x"}')

            valid = self.run_cli(schema, "-i", good)
            invalid = self.run_cli(schema, "-i", bad)

        self.assertEqual(valid.returncode, 0)
        self.assertEqual(valid.stdout, f"{good} - VALID\n")
        self.assertEqual(invalid.returncode, 1)
        self.assertEqual(
            invalid.stdout,
            f'{bad} - INVALID. Errors:\n1. "x" is not of type "integer"\n',
        )

    def test_flag_output_is_compact_json(self):
        with tempfile.TemporaryDirectory() as td:
            schema = os.path.join(td, "schema.json")
            inst = os.path.join(td, "bad.json")
            with open(schema, "w", encoding="utf-8") as f:
                f.write('{"type":"integer"}')
            with open(inst, "w", encoding="utf-8") as f:
                f.write('"x"')

            result = self.run_cli("--output", "flag", schema, "-i", inst)

        self.assertEqual(result.returncode, 1)
        self.assertEqual(
            result.stdout,
            json.dumps(
                {
                    "instance": inst,
                    "output": "flag",
                    "payload": {"valid": False},
                    "schema": schema,
                },
                separators=(",", ":"),
            )
            + "\n",
        )

    def test_common_keywords_report_reference_messages(self):
        cases = [
            ('{"enum":[1,2,"x"]}', "3", '3 is not one of 1, 2 or "x"'),
            ('{"const":{"a":1}}', '{"a":2}', '{"a":1} was expected'),
            ('{"type":"string","minLength":3,"pattern":"^[A-Z]+$"}', '"ab"', '"ab" is shorter than 3 characters\n2. "ab" does not match "^[A-Z]+$"'),
            ('{"type":"number","minimum":3}', "2", "2 is less than the minimum of 3"),
            ('{"type":"object","properties":{"a":{}},"additionalProperties":false}', '{"a":1,"b":2}', "Additional properties are not allowed ('b' was unexpected)"),
            ('{"anyOf":[{"type":"string"},{"type":"integer"}]}', "true", "true is not valid under any of the schemas listed in the 'anyOf' keyword"),
            ('{"oneOf":[{"type":"number"},{"type":"integer"}]}', "1", "1 is valid under more than one of the schemas listed in the 'oneOf' keyword"),
            ('{"not":{"type":"null"}}', "null", '{"type":"null"} is not allowed for null'),
        ]
        with tempfile.TemporaryDirectory() as td:
            for idx, (schema_text, instance_text, expected) in enumerate(cases):
                schema = os.path.join(td, f"s{idx}.json")
                inst = os.path.join(td, f"i{idx}.json")
                with open(schema, "w", encoding="utf-8") as f:
                    f.write(schema_text)
                with open(inst, "w", encoding="utf-8") as f:
                    f.write(instance_text)

                result = self.run_cli(schema, "-i", inst)

                self.assertEqual(result.returncode, 1, schema_text)
                self.assertIn(expected, result.stdout)

    def test_format_and_cardinality_messages(self):
        cases = [
            ('{"type":"string","format":"email"}', '"bad"', ["--assert-format"], '"bad" is not a "email"'),
            ('{"type":"array","minItems":2}', "[1]", [], "[1] has less than 2 items"),
            ('{"type":"array","maxItems":1}', "[1,2]", [], "[1,2] has more than 1 item"),
            ('{"type":"object","minProperties":2}', '{"a":1}', [], '{"a":1} has less than 2 properties'),
            ('{"type":"object","maxProperties":1}', '{"a":1,"b":2}', [], '{"a":1,"b":2} has more than 1 property'),
        ]
        with tempfile.TemporaryDirectory() as td:
            for idx, (schema_text, instance_text, opts, expected) in enumerate(cases):
                schema = os.path.join(td, f"s{idx}.json")
                inst = os.path.join(td, f"i{idx}.json")
                with open(schema, "w", encoding="utf-8") as f:
                    f.write(schema_text)
                with open(inst, "w", encoding="utf-8") as f:
                    f.write(instance_text)

                result = self.run_cli(*opts, schema, "-i", inst)

                self.assertEqual(result.returncode, 1, schema_text)
                self.assertIn(expected, result.stdout)

            no_format = self.run_cli(schema, "-i", inst)
            self.assertNotIn('is not a "email"', no_format.stdout)

    def test_invalid_schema_and_bad_option_messages(self):
        with tempfile.TemporaryDirectory() as td:
            schema = os.path.join(td, "schema.json")
            with open(schema, "w", encoding="utf-8") as f:
                f.write('{"type":"nonesuch"}')

            invalid_schema = self.run_cli(schema)
            bad_draft = self.run_cli("--draft", "5", schema)

        self.assertEqual(invalid_schema.returncode, 1)
        self.assertEqual(
            invalid_schema.stdout,
            'Schema is invalid. Error: "nonesuch" is not valid under any of the schemas listed in the \'anyOf\' keyword\n',
        )
        self.assertEqual(bad_draft.returncode, 2)
        self.assertIn("error: invalid value '5' for '--draft <DRAFT>'", bad_draft.stderr)

    def test_json_parse_error_wording(self):
        with tempfile.TemporaryDirectory() as td:
            schema = os.path.join(td, "schema.json")
            inst = os.path.join(td, "bad.json")
            with open(schema, "w", encoding="utf-8") as f:
                f.write('{"type":"integer"}')
            with open(inst, "w", encoding="utf-8") as f:
                f.write("x")

            result = self.run_cli(schema, "-i", inst)

        self.assertEqual(result.returncode, 1)
        self.assertEqual(result.stdout, "Error: expected value at line 1 column 1\n")

    def test_local_ref_pattern_properties_and_property_names(self):
        cases = [
            ('{"definitions":{"pos":{"type":"integer","minimum":0}},"properties":{"x":{"$ref":"#/definitions/pos"}}}', '{"x":-1}', "-1 is less than the minimum of 0"),
            ('{"type":"object","patternProperties":{"^x":{"type":"integer"}},"additionalProperties":false}', '{"xa":"s","y":1}', '"s" is not of type "integer"'),
            ('{"type":"object","propertyNames":{"pattern":"^[a-z]+$"}}', '{"A":1}', '"A" does not match "^[a-z]+$"'),
        ]
        with tempfile.TemporaryDirectory() as td:
            for idx, (schema_text, instance_text, expected) in enumerate(cases):
                schema = os.path.join(td, f"s{idx}.json")
                inst = os.path.join(td, f"i{idx}.json")
                with open(schema, "w", encoding="utf-8") as f:
                    f.write(schema_text)
                with open(inst, "w", encoding="utf-8") as f:
                    f.write(instance_text)

                result = self.run_cli(schema, "-i", inst)

                self.assertEqual(result.returncode, 1, schema_text)
                self.assertIn(expected, result.stdout)


if __name__ == "__main__":
    unittest.main()
