#!/usr/bin/env python3
import argparse
import json
import os
import re
import sys


VERSION = "0.41.0"
VALID_TYPES = {"array", "boolean", "integer", "null", "number", "object", "string"}


def display(value):
    return json.dumps(value, separators=(",", ":"))


def human(value):
    if isinstance(value, bool):
        return "true" if value else "false"
    if value is None:
        return "null"
    return display(value)


def human_list(values):
    parts = [human(v) for v in values]
    if len(parts) <= 1:
        return "".join(parts)
    return ", ".join(parts[:-1]) + " or " + parts[-1]


def type_name(value):
    if value is None:
        return "null"
    if isinstance(value, bool):
        return "boolean"
    if isinstance(value, int) and not isinstance(value, bool):
        return "integer"
    if isinstance(value, (int, float)) and not isinstance(value, bool):
        return "number"
    if isinstance(value, str):
        return "string"
    if isinstance(value, list):
        return "array"
    if isinstance(value, dict):
        return "object"
    return "unknown"


def type_matches(value, expected):
    if isinstance(expected, list):
        return any(type_matches(value, item) for item in expected)
    if expected == "integer":
        return isinstance(value, int) and not isinstance(value, bool)
    if expected == "number":
        return isinstance(value, (int, float)) and not isinstance(value, bool)
    return type_name(value) == expected


def validates_format(fmt, value):
    if not isinstance(value, str):
        return True
    if fmt == "email":
        return "@" in value and "." in value.rsplit("@", 1)[-1]
    if fmt == "ipv4":
        parts = value.split(".")
        return len(parts) == 4 and all(p.isdigit() and 0 <= int(p) <= 255 for p in parts)
    if fmt == "uri":
        return re.match(r"^[A-Za-z][A-Za-z0-9+.-]*:", value) is not None
    if fmt in ("date", "date-time"):
        return re.match(r"^\d{4}-\d{2}-\d{2}", value) is not None
    return True


def resolve_ref(root, ref):
    if not isinstance(ref, str) or not ref.startswith("#"):
        return None
    node = root
    pointer = ref[1:]
    if pointer.startswith("/"):
        for raw in pointer.split("/")[1:]:
            part = raw.replace("~1", "/").replace("~0", "~")
            if isinstance(node, dict) and part in node:
                node = node[part]
            else:
                return None
    return node


def validate(schema, instance, assert_format=False, root=None):
    if root is None:
        root = schema
    errors = []
    if isinstance(schema, bool):
        return [] if schema else [f"False schema does not allow {display(instance)}"]
    if not isinstance(schema, dict):
        return []
    if "$ref" in schema:
        target = resolve_ref(root, schema["$ref"])
        if target is not None and target is not schema:
            return validate(target, instance, assert_format, root)
    if "type" in schema and not type_matches(instance, schema["type"]):
        expected = schema["type"]
        if isinstance(expected, list):
            quoted = " or ".join(f'"{x}"' for x in expected)
        else:
            quoted = f'"{expected}"'
        errors.append(f"{display(instance)} is not of type {quoted}")
    if "enum" in schema and not any(instance == v for v in schema["enum"]):
        errors.append(f"{human(instance)} is not one of {human_list(schema['enum'])}")
    if "const" in schema and instance != schema["const"]:
        errors.append(f"{human(schema['const'])} was expected")
    if isinstance(instance, (int, float)) and not isinstance(instance, bool):
        if "minimum" in schema and instance < schema["minimum"]:
            errors.append(f"{human(instance)} is less than the minimum of {human(schema['minimum'])}")
        if "maximum" in schema and instance > schema["maximum"]:
            errors.append(f"{human(instance)} is greater than the maximum of {human(schema['maximum'])}")
        if "exclusiveMinimum" in schema and instance <= schema["exclusiveMinimum"]:
            errors.append(f"{human(instance)} is less than or equal to the minimum of {human(schema['exclusiveMinimum'])}")
        if "exclusiveMaximum" in schema and instance >= schema["exclusiveMaximum"]:
            errors.append(f"{human(instance)} is greater than or equal to the maximum of {human(schema['exclusiveMaximum'])}")
        if "multipleOf" in schema:
            divisor = schema["multipleOf"]
            quotient = instance / divisor
            if abs(quotient - round(quotient)) > 1e-12:
                errors.append(f"{human(instance)} is not a multiple of {human(divisor)}")
    if isinstance(instance, str):
        if "minLength" in schema and len(instance) < schema["minLength"]:
            errors.append(f'{display(instance)} is shorter than {schema["minLength"]} characters')
        if "maxLength" in schema and len(instance) > schema["maxLength"]:
            errors.append(f'{display(instance)} is longer than {schema["maxLength"]} characters')
        if "pattern" in schema:
            try:
                if re.search(schema["pattern"], instance) is None:
                    errors.append(f'{display(instance)} does not match "{schema["pattern"]}"')
            except re.error:
                pass
        if assert_format and "format" in schema and not validates_format(schema["format"], instance):
            errors.append(f'{display(instance)} is not a "{schema["format"]}"')
    if isinstance(instance, list):
        if "minItems" in schema and len(instance) < schema["minItems"]:
            count = schema["minItems"]
            noun = "item" if count == 1 else "items"
            errors.append(f"{display(instance)} has less than {count} {noun}")
        if "maxItems" in schema and len(instance) > schema["maxItems"]:
            count = schema["maxItems"]
            noun = "item" if count == 1 else "items"
            errors.append(f"{display(instance)} has more than {count} {noun}")
        if schema.get("uniqueItems") is True:
            seen = []
            for item in instance:
                if any(item == old for old in seen):
                    errors.append(f"{display(instance)} has non-unique elements")
                    break
                seen.append(item)
        if "items" in schema:
            if isinstance(schema["items"], list):
                for item, subschema in zip(instance, schema["items"]):
                    errors.extend(validate(subschema, item, assert_format, root))
            else:
                for item in instance:
                    errors.extend(validate(schema["items"], item, assert_format, root))
    if isinstance(instance, dict):
        for req in schema.get("required", []):
            if req not in instance:
                errors.append(f'"{req}" is a required property')
        for name, subschema in schema.get("properties", {}).items():
            if name in instance:
                errors.extend(validate(subschema, instance[name], assert_format, root))
        pattern_matched = set()
        for pattern, subschema in schema.get("patternProperties", {}).items():
            try:
                cre = re.compile(pattern)
            except re.error:
                continue
            for name, value in instance.items():
                if cre.search(name):
                    pattern_matched.add(name)
                    errors.extend(validate(subschema, value, assert_format, root))
        if isinstance(schema.get("propertyNames"), dict):
            for name in instance.keys():
                errors.extend(validate(schema["propertyNames"], name, assert_format, root))
        if "minProperties" in schema and len(instance) < schema["minProperties"]:
            count = schema["minProperties"]
            noun = "property" if count == 1 else "properties"
            errors.append(f"{display(instance)} has less than {count} {noun}")
        if "maxProperties" in schema and len(instance) > schema["maxProperties"]:
            count = schema["maxProperties"]
            noun = "property" if count == 1 else "properties"
            errors.append(f"{display(instance)} has more than {count} {noun}")
        if schema.get("additionalProperties") is False:
            allowed = set(schema.get("properties", {}).keys())
            allowed.update(pattern_matched)
            extras = [k for k in instance.keys() if k not in allowed]
            if extras:
                if len(extras) == 1:
                    errors.append(f"Additional properties are not allowed ('{extras[0]}' was unexpected)")
                else:
                    quoted = ", ".join(f"'{x}'" for x in extras[:-1]) + f" and '{extras[-1]}'"
                    errors.append(f"Additional properties are not allowed ({quoted} were unexpected)")
        elif isinstance(schema.get("additionalProperties"), dict):
            allowed = set(schema.get("properties", {}).keys())
            allowed.update(pattern_matched)
            for key, value in instance.items():
                if key not in allowed:
                    errors.extend(validate(schema["additionalProperties"], value, assert_format, root))
    if "allOf" in schema:
        for subschema in schema["allOf"]:
            errors.extend(validate(subschema, instance, assert_format, root))
    if "anyOf" in schema:
        if not any(not validate(subschema, instance, assert_format, root) for subschema in schema["anyOf"]):
            errors.append(f"{human(instance)} is not valid under any of the schemas listed in the 'anyOf' keyword")
    if "oneOf" in schema:
        matches = sum(1 for subschema in schema["oneOf"] if not validate(subschema, instance, assert_format, root))
        if matches == 0:
            errors.append(f"{human(instance)} is not valid under any of the schemas listed in the 'oneOf' keyword")
        elif matches > 1:
            errors.append(f"{human(instance)} is valid under more than one of the schemas listed in the 'oneOf' keyword")
    if "not" in schema:
        if not validate(schema["not"], instance, assert_format, root):
            errors.append(f"{display(schema['not'])} is not allowed for {human(instance)}")
    return errors


def load_json(path):
    try:
        with open(path, "r", encoding="utf-8") as f:
            return json.load(f)
    except json.JSONDecodeError as exc:
        msg = exc.msg.lower()
        if msg == "expecting value":
            msg = "expected value"
        raise ValueError(f"{msg} at line {exc.lineno} column {exc.colno}") from None


def schema_error(schema):
    if isinstance(schema, bool):
        return None
    if not isinstance(schema, dict):
        return None
    if "type" in schema:
        values = schema["type"] if isinstance(schema["type"], list) else [schema["type"]]
        for value in values:
            if value not in VALID_TYPES:
                return f'"{value}" is not valid under any of the schemas listed in the \'anyOf\' keyword'
    for key in ("properties", "patternProperties", "definitions", "$defs"):
        if isinstance(schema.get(key), dict):
            for subschema in schema[key].values():
                err = schema_error(subschema)
                if err:
                    return err
    for key in ("items", "additionalProperties", "not"):
        if isinstance(schema.get(key), (dict, bool)):
            err = schema_error(schema[key])
            if err:
                return err
    for key in ("allOf", "anyOf", "oneOf"):
        if isinstance(schema.get(key), list):
            for subschema in schema[key]:
                err = schema_error(subschema)
                if err:
                    return err
    return None


class Parser(argparse.ArgumentParser):
    def error(self, message):
        self.print_usage(sys.stderr)
        self.exit(2, f"{self.prog}: error: {message}\n")


def parse_args(argv):
    parser = Parser(prog="executable", add_help=False)
    parser.add_argument("-i", "--instance", dest="instances", action="append", default=[])
    parser.add_argument("-d", "--draft")
    parser.add_argument("--assert-format", action="store_true")
    parser.add_argument("--no-assert-format", action="store_true")
    parser.add_argument("--output", default="text")
    parser.add_argument("-v", "--version", action="store_true")
    parser.add_argument("--errors-only", action="store_true")
    parser.add_argument("--connect-timeout")
    parser.add_argument("--timeout")
    parser.add_argument("-k", "--insecure", action="store_true")
    parser.add_argument("--cacert")
    parser.add_argument("-h", "--help", action="store_true")
    parser.add_argument("schema", nargs="?")
    args = parser.parse_args(argv)
    return args


HELP = """Usage: executable [OPTIONS] [SCHEMA]

Arguments:
  [SCHEMA]  The JSON Schema to validate with (i.e. schema.json)

Options:
  -i, --instance <INSTANCES>       A path to a JSON instance (i.e. filename.json) to validate (may be specified multiple times)
  -d, --draft <DRAFT>              Enforce a specific JSON Schema draft [possible values: 4, 6, 7, 2019, 2020]
      --assert-format              Turn ON format validation
      --no-assert-format           Turn OFF format validation
      --output <OUTPUT>            Select output style: text (default), flag, list, hierarchical [default: text] [possible values: text, flag, list, hierarchical]
  -v, --version                    Show program's version number and exit
      --errors-only                Only show validation errors
      --connect-timeout <SECONDS>  Timeout for establishing connections (in seconds)
      --timeout <SECONDS>          Total timeout for HTTP requests (in seconds)
  -k, --insecure                   Skip TLS certificate verification (dangerous!)
      --cacert <FILE>              Path to a custom CA certificate file (PEM format)
  -h, --help                       Print help
"""


def main(argv):
    if "--help" in argv or "-h" in argv:
        sys.stdout.write(HELP)
        return 0
    args = parse_args(argv)
    if args.draft and args.draft not in ["4", "6", "7", "2019", "2020"]:
        print(f"error: invalid value '{args.draft}' for '--draft <DRAFT>'\n  [possible values: 4, 6, 7, 2019, 2020]\n\nFor more information, try '--help'.", file=sys.stderr)
        return 2
    if args.output not in ["text", "flag", "list", "hierarchical"]:
        print(f"error: invalid value '{args.output}' for '--output <OUTPUT>'\n  [possible values: text, flag, list, hierarchical]\n\nFor more information, try '--help'.", file=sys.stderr)
        return 2
    if args.version:
        print(f"Version: {VERSION}")
        return 0
    if not args.schema:
        print("error: the following required arguments were not provided:\n  <SCHEMA>\n\nUsage: executable <SCHEMA>\n\nFor more information, try '--help'.", file=sys.stderr)
        return 2
    try:
        schema = load_json(args.schema)
        err = schema_error(schema)
        if err:
            print(f"Schema is invalid. Error: {err}")
            return 1
        if not args.instances:
            print("Schema is valid")
            return 0
        ok = True
        for instance_path in args.instances:
            inst = load_json(instance_path)
            errors = validate(schema, inst, args.assert_format and not args.no_assert_format)
            valid = not errors
            if errors:
                ok = False
            if args.output == "flag":
                print(json.dumps({"instance": instance_path, "output": "flag", "payload": {"valid": valid}, "schema": args.schema}, separators=(",", ":")))
            elif args.output in ("list", "hierarchical"):
                print(json.dumps({"instance": instance_path, "output": args.output, "payload": {"valid": valid}, "schema": args.schema}, separators=(",", ":")))
            else:
                if errors:
                    print(f"{instance_path} - INVALID. Errors:")
                    for i, err in enumerate(errors, 1):
                        print(f"{i}. {err}")
                elif not args.errors_only:
                    print(f"{instance_path} - VALID")
        return 0 if ok else 1
    except FileNotFoundError:
        print("Error: No such file or directory (os error 2)")
        return 1
    except Exception as exc:
        print(f"Error: {exc}")
        return 1


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
