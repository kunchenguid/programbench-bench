#!/usr/bin/env python3
import fnmatch
import os
import re
import stat
import sys
from dataclasses import dataclass, field
from pathlib import Path


HELP = """Usage: ag [FILE-TYPE] [OPTIONS] PATTERN [PATH]

  Recursively search for PATTERN in PATH.
  Like grep or ack, but faster.

Example:
  ag -i foo /bar/

Output Options:
     --ackmate            Print results in AckMate-parseable format
  -A --after [LINES]      Print lines after match (Default: 2)
  -B --before [LINES]     Print lines before match (Default: 2)
     --[no]break          Print newlines between matches in different files
                          (Enabled by default)
  -c --count              Only print the number of matches in each file.
  -l --files-with-matches Only print filenames that contain matches
  -L --files-without-matches
                          Only print filenames that don't contain matches
  -g --filename-pattern PATTERN
                          Print filenames matching PATTERN
  -o --only-matching      Prints only the matching part of the lines
  -0 --null --print0      Separate filenames with null (for 'xargs -0')

Search Options:
  -a --all-types          Search all files
  -f --follow             Follow symlinks
  -F --fixed-strings      Alias for --literal for compatibility with grep
  -G --file-search-regex  PATTERN Limit search to filenames matching PATTERN
     --hidden             Search hidden files
  -i --ignore-case        Match case insensitively
  -Q --literal            Don't parse PATTERN as a regular expression
  -s --case-sensitive     Match case sensitively
  -S --smart-case         Match case insensitively unless PATTERN contains
                          uppercase characters (Enabled by default)
  -u --unrestricted       Search all files
  -v --invert-match
  -w --word-regexp        Only match whole words

For a list of supported file types run:
  ag --list-file-types
"""

FILE_TYPES = {
    "cc": [".c", ".h", ".xs"],
    "cpp": [".cpp", ".cc", ".C", ".cxx", ".m", ".hpp", ".hh", ".h", ".H", ".hxx", ".tpp"],
    "css": [".css"],
    "go": [".go"],
    "html": [".htm", ".html", ".shtml", ".xhtml"],
    "java": [".java", ".properties"],
    "js": [".js", ".jsx", ".vue"],
    "json": [".json"],
    "md": [".md", ".markdown"],
    "perl": [".pl", ".pm", ".pod", ".t"],
    "php": [".php", ".phpt", ".php3", ".php4", ".php5", ".phtml"],
    "python": [".py"],
    "ruby": [".rb", ".rhtml", ".rjs", ".rxml", ".erb", ".rake", ".spec"],
    "rust": [".rs"],
    "shell": [".sh", ".bash", ".csh", ".tcsh", ".ksh", ".zsh"],
    "txt": [".txt"],
    "xml": [".xml", ".dtd", ".xsl", ".xslt", ".ent"],
    "yaml": [".yaml", ".yml"],
}


@dataclass
class Options:
    after: int = 0
    all_types: bool = False
    before: int = 0
    column: bool = False
    count: bool = False
    files_with_matches: bool = False
    files_without_matches: bool = False
    filename: bool | None = None
    file_name_pattern: str | None = None
    file_search_regex: str | None = None
    heading: bool = False
    hidden: bool = False
    ignore_case: bool | None = None
    invert: bool = False
    literal: bool = False
    max_count: int = 0
    no_recurse: bool = False
    numbers: bool = True
    only_matching: bool = False
    passthrough: bool = False
    print0: bool = False
    search_binary: bool = False
    type_exts: list[str] | None = None
    unrestricted: bool = False
    word: bool = False
    width: int | None = None
    paths: list[str] = field(default_factory=list)
    pattern: str | None = None
    extra_ignores: list[str] = field(default_factory=list)


def parse_num(args, i, default):
    if i + 1 < len(args) and not args[i + 1].startswith("-"):
        try:
            return int(args[i + 1]), i + 2
        except ValueError:
            return default, i + 1
    return default, i + 1


def parse_args(argv):
    opts = Options()
    positional = []
    i = 0
    stop = False
    while i < len(argv):
        arg = argv[i]
        if stop or not arg.startswith("-") or arg == "-":
            positional.append(arg)
            i += 1
            continue
        compact = re.match(r"^-(A|B|C|m|W)(-?\d+)$", arg)
        if compact:
            key, value = compact.group(1), int(compact.group(2))
            if key == "A":
                opts.after = value
            elif key == "B":
                opts.before = value
            elif key == "C":
                opts.before = opts.after = value
            elif key == "m":
                opts.max_count = value
            elif key == "W":
                opts.width = value
            i += 1
            continue
        if arg == "--":
            stop = True
            i += 1
        elif arg in ("--help", "-h"):
            print(HELP)
            raise SystemExit(0)
        elif arg in ("--version", "-V"):
            print("ag version 2.2.0\n\nFeatures:\n  +jit +lzma +zlib")
            raise SystemExit(0)
        elif arg == "--list-file-types":
            print_file_types()
            raise SystemExit(0)
        elif arg in ("--nocolor", "--color", "--ackmate", "--stats", "--silent", "--debug", "-D", "--mmap", "--nommap", "--multiline", "--nomultiline", "--break", "--nobreak", "--pager", "--nopager", "--parallel", "--workers", "--affinity", "--noaffinity", "--one-device", "--search-zip", "-z", "--print-long-lines", "--stats-only", "--all-text", "-t", "--skip-vcs-ignores", "-U"):
            if arg in ("--pager", "--workers") and i + 1 < len(argv):
                i += 1
            i += 1
        elif arg in ("--search-binary",):
            opts.search_binary = True
            i += 1
        elif arg in ("--all-types", "-a"):
            opts.all_types = True
            opts.search_binary = True
            i += 1
        elif arg in ("--hidden",):
            opts.hidden = True
            i += 1
        elif arg in ("-u", "--unrestricted"):
            opts.unrestricted = True
            opts.hidden = True
            opts.search_binary = True
            i += 1
        elif arg in ("-i", "--ignore-case"):
            opts.ignore_case = True
            i += 1
        elif arg in ("-s", "--case-sensitive"):
            opts.ignore_case = False
            i += 1
        elif arg in ("-S", "--smart-case"):
            opts.ignore_case = None
            i += 1
        elif arg in ("-Q", "--literal", "-F", "--fixed-strings"):
            opts.literal = True
            i += 1
        elif arg in ("-w", "--word-regexp"):
            opts.word = True
            i += 1
        elif arg in ("-v", "--invert-match"):
            opts.invert = True
            i += 1
        elif arg in ("-c", "--count"):
            opts.count = True
            i += 1
        elif arg in ("-l", "--files-with-matches"):
            opts.files_with_matches = True
            i += 1
        elif arg in ("-L", "--files-without-matches"):
            opts.files_without_matches = True
            i += 1
        elif arg in ("-o", "--only-matching"):
            opts.only_matching = True
            i += 1
        elif arg in ("--column",):
            opts.column = True
            i += 1
        elif arg in ("--numbers", "-n"):
            opts.numbers = True
            i += 1
        elif arg in ("--nonumbers", "--no-numbers"):
            opts.numbers = False
            i += 1
        elif arg in ("--filename",):
            opts.filename = True
            i += 1
        elif arg in ("--nofilename", "--no-filename"):
            opts.filename = False
            i += 1
        elif arg in ("--heading", "-H"):
            opts.heading = True
            i += 1
        elif arg in ("--noheading", "--no-heading", "--nogroup", "--no-group"):
            opts.heading = False
            i += 1
        elif arg in ("--group",):
            opts.heading = True
            i += 1
        elif arg in ("--passthrough", "--passthru"):
            opts.passthrough = True
            i += 1
        elif arg in ("-0", "--null", "--print0"):
            opts.print0 = True
            i += 1
        elif arg in ("-r", "--recurse"):
            opts.no_recurse = False
            i += 1
        elif arg in ("--norecurse",):
            opts.no_recurse = True
            i += 1
        elif arg in ("-A", "--after"):
            opts.after, i = parse_num(argv, i, 2)
        elif arg in ("-B", "--before"):
            opts.before, i = parse_num(argv, i, 2)
        elif arg in ("-C", "--context"):
            n, i = parse_num(argv, i, 2)
            opts.before = opts.after = n
        elif arg in ("-m", "--max-count", "--depth", "-W", "--width"):
            if i + 1 < len(argv):
                if arg in ("-m", "--max-count"):
                    opts.max_count = int(argv[i + 1])
                elif arg in ("-W", "--width"):
                    opts.width = int(argv[i + 1])
            i += 2
        elif arg in ("-g", "--filename-pattern"):
            opts.file_name_pattern = argv[i + 1]
            i += 2
        elif arg in ("-G", "--file-search-regex"):
            opts.file_search_regex = argv[i + 1]
            i += 2
        elif arg in ("--ignore", "--ignore-dir"):
            opts.extra_ignores.append(argv[i + 1])
            i += 2
        elif arg == "--path-to-ignore" or arg == "-p":
            if i + 1 < len(argv):
                opts.extra_ignores.extend(read_ignore_file(Path(argv[i + 1])))
            i += 2
        elif arg.startswith("--") and arg[2:] in FILE_TYPES:
            opts.type_exts = FILE_TYPES[arg[2:]]
            i += 1
        else:
            positional.append(arg)
            i += 1
    if opts.file_name_pattern is None:
        if not positional:
            print("ERR: What do you want to search for?", file=sys.stderr)
            raise SystemExit(1)
        opts.pattern = positional[0]
        opts.paths = positional[1:]
    else:
        opts.pattern = opts.file_name_pattern
        opts.paths = positional
    return opts


def print_file_types():
    print("The following file types are supported:")
    for name in sorted(FILE_TYPES):
        print(f"  --{name}")
        print("      " + "  ".join(FILE_TYPES[name]))
        print()


def read_ignore_file(path):
    try:
        return [
            line.strip()
            for line in path.read_text(encoding="utf-8", errors="ignore").splitlines()
            if line.strip() and not line.lstrip().startswith("#")
        ]
    except OSError:
        return []


def is_hidden(path):
    return any(part.startswith(".") and part not in (".", "..") for part in path.parts)


def match_ignore(rel, name, patterns):
    s = rel.as_posix()
    for pat in patterns:
        p = pat.strip()
        if not p:
            continue
        neg = p.startswith("!")
        if neg:
            p = p[1:]
        hit = False
        if p.endswith("/"):
            base = p.rstrip("/")
            hit = name == base or s == base or s.startswith(base + "/") or ("/" + base + "/") in ("/" + s + "/")
        elif "/" in p:
            hit = fnmatch.fnmatch(s, p)
        else:
            hit = fnmatch.fnmatch(name, p) or name == p
        if hit:
            return not neg
    return False


def discover_files(paths, opts):
    if not paths:
        paths = ["."]
    files = []
    for raw in paths:
        p = Path(raw)
        if p.is_file():
            files.append(p)
            continue
        if not p.exists():
            if not opts.extra_ignores:
                print(f"ERR: Error opening directory {raw}: No such file or directory", file=sys.stderr)
            continue
        base = p
        inherited = opts.extra_ignores[:]
        for root, dirs, names in os.walk(p, followlinks=False):
            rootp = Path(root)
            relroot = rootp.relative_to(base) if rootp != base else Path(".")
            patterns = inherited[:]
            if not opts.unrestricted and not opts.all_types:
                patterns += read_ignore_file(rootp / ".ignore")
                patterns += read_ignore_file(rootp / ".gitignore")
                patterns += read_ignore_file(rootp / ".hgignore")
            kept_dirs = []
            for d in sorted(dirs):
                child_rel = (relroot / d) if relroot != Path(".") else Path(d)
                if (not opts.hidden and d.startswith(".")) or (not opts.unrestricted and not opts.all_types and match_ignore(child_rel, d, patterns)):
                    continue
                kept_dirs.append(d)
            dirs[:] = [] if opts.no_recurse else kept_dirs
            for name in sorted(names):
                fp = rootp / name
                rel = (relroot / name) if relroot != Path(".") else Path(name)
                if not opts.hidden and name.startswith("."):
                    continue
                if not opts.unrestricted and not opts.all_types and match_ignore(rel, name, patterns):
                    continue
                if opts.type_exts is not None and fp.suffix not in opts.type_exts:
                    continue
                if opts.file_search_regex and not re.search(opts.file_search_regex, str(fp)):
                    continue
                files.append(fp)
    return files


def compile_pattern(opts):
    pat = re.escape(opts.pattern or "") if opts.literal else (opts.pattern or "")
    if opts.word:
        pat = r"\b(?:" + pat + r")\b"
    flags = re.MULTILINE
    ignore = opts.ignore_case
    if ignore is None:
        ignore = not any(ch.isupper() for ch in (opts.pattern or ""))
    if ignore:
        flags |= re.IGNORECASE
    try:
        return re.compile(pat, flags)
    except re.error as e:
        print(f"ERR: Error in regex: {e}", file=sys.stderr)
        raise SystemExit(1)


def is_binary(data):
    return b"\0" in data[:4096]


def display_path(path):
    return str(path)


def line_matches(regex, line, invert):
    matches = list(regex.finditer(line))
    if invert:
        return [] if matches else [None]
    return matches


def search_stream(regex, opts):
    found = False
    for line in sys.stdin.read().splitlines(True):
        text = line[:-1] if line.endswith("\n") else line
        matches = line_matches(regex, text, opts.invert)
        if matches:
            found = True
            if opts.only_matching and matches[0] is not None:
                for m in matches:
                    print(m.group(0))
            else:
                print(text)
        elif opts.passthrough:
            print(text)
    return found


def search_file(path, regex, opts):
    data = path.read_bytes()
    if is_binary(data):
        if opts.search_binary:
            text = data.decode("utf-8", errors="ignore")
            if regex.search(text):
                return {"path": path, "binary": True, "found": True, "lines": [], "count": 1}
        return {"path": path, "binary": True, "found": False, "lines": [], "count": 0}
    text = data.decode("utf-8", errors="replace")
    raw_lines = text.splitlines()
    context_lines = raw_lines + ([""] if text.endswith("\n") and raw_lines else [])
    matched_rows = []
    count = 0
    limit_hit = False
    for lineno, line in enumerate(raw_lines, 1):
        matches = line_matches(regex, line, opts.invert)
        if not matches:
            continue
        if opts.only_matching and not opts.invert:
            for m in matches:
                count += 1
                matched_rows.append((lineno, m.start() + 1, m.group(0), True))
                if opts.max_count and count >= opts.max_count:
                    limit_hit = True
                    break
        else:
            count += 1 if opts.invert else len(matches)
            col = 1 if matches[0] is None else matches[0].start() + 1
            shown = line if opts.width is None else line[: opts.width]
            matched_rows.append((lineno, col, shown, True))
        if opts.max_count and count >= opts.max_count:
            if lineno < len(raw_lines):
                limit_hit = True
            break
    out = matched_rows
    if (opts.before or opts.after) and matched_rows and not opts.only_matching:
        selected = {}
        match_lines = {row[0] for row in matched_rows}
        for lineno, _col, _text, _match in matched_rows:
            start = max(1, lineno - opts.before)
            end = min(len(context_lines), lineno + opts.after)
            for n in range(start, end + 1):
                line = context_lines[n - 1]
                selected[n] = (n, 1, line if opts.width is None else line[: opts.width], n in match_lines)
        out = [selected[n] for n in sorted(selected)]
    if limit_hit and opts.max_count:
        print(f"ERR: Too many matches in {path}. Skipping the rest of this file.", file=sys.stderr)
    return {"path": path, "binary": False, "found": bool(out), "lines": out, "count": count}


def emit_file_result(result, opts, show_filename):
    path = display_path(result["path"])
    sep = "\0" if opts.print0 else "\n"
    if result["binary"]:
        if result["found"] and not (opts.count or opts.files_with_matches or opts.files_without_matches):
            sys.stdout.write(f"Binary file {path} matches.\n")
        elif opts.files_with_matches and result["found"]:
            sys.stdout.write(path + sep)
        elif opts.count and result["found"]:
            sys.stdout.write(f"{path}:1\n" if show_filename else "1\n")
        return
    if opts.files_with_matches:
        if result["found"]:
            sys.stdout.write(path + sep)
        return
    if opts.files_without_matches:
        if not result["found"]:
            sys.stdout.write(path + sep)
        return
    if opts.count:
        if result["found"]:
            sys.stdout.write(f"{path}:{result['count']}\n" if show_filename else f"{result['count']}\n")
        return
    if not result["found"]:
        return
    if opts.heading and show_filename:
        print(path)
    last_lineno = None
    for lineno, col, text, is_match in result["lines"]:
        if (opts.before or opts.after) and last_lineno is not None and lineno > last_lineno + 1:
            print("--")
        last_lineno = lineno
        pieces = []
        if show_filename and not opts.heading:
            pieces.append(path)
        if opts.numbers:
            pieces.append(str(lineno))
        if opts.column:
            pieces.append(str(col))
        if pieces:
            sep = ":" if is_match else "-"
            prefix = ":".join(pieces) + sep
        else:
            prefix = ""
        print(prefix + text)
    if opts.heading and show_filename:
        print()


def main(argv):
    opts = parse_args(argv)
    regex = compile_pattern(opts)
    if not opts.paths and not sys.stdin.isatty() and opts.file_name_pattern is None:
        return 0 if search_stream(regex, opts) else 1
    files = discover_files(opts.paths, opts)
    if opts.file_name_pattern is not None:
        name_re = compile_pattern(opts)
        matches = [f for f in files if name_re.search(str(f))]
        sep = "\0" if opts.print0 else "\n"
        for f in matches:
            sys.stdout.write(display_path(f) + sep)
        return 0 if matches else 1
    show_filename = opts.filename if opts.filename is not None else len(opts.paths) != 1 or (opts.paths and Path(opts.paths[0]).is_dir())
    found = False
    for f in files:
        try:
            result = search_file(f, regex, opts)
        except OSError as e:
            print(f"ERR: {e}", file=sys.stderr)
            continue
        if result["found"]:
            found = True
        if opts.files_without_matches and not result["found"]:
            found = True
        emit_file_result(result, opts, show_filename)
    return 0 if found else 1


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
