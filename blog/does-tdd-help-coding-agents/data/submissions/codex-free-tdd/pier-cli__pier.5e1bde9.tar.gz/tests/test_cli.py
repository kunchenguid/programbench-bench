import os
import subprocess
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
EXE = ROOT / "src" / "pier.py"

class PierCliTests(unittest.TestCase):
    def run_cli(self, *args, cwd=None, env=None):
        full_env = os.environ.copy()
        if env:
            full_env.update(env)
        return subprocess.run([str(EXE), *args], cwd=cwd, env=full_env, text=True,
                              stdout=subprocess.PIPE, stderr=subprocess.PIPE)

    def temp_workspace(self, config_text=""):
        tmp = tempfile.TemporaryDirectory()
        path = Path(tmp.name)
        if config_text:
            (path / "pier.toml").write_text(config_text)
        return tmp, path

    def test_missing_config_reports_error(self):
        tmp, path = self.temp_workspace()
        self.addCleanup(tmp.cleanup)
        res = self.run_cli("list", cwd=path, env={"HOME": str(path / "home"), "XDG_CONFIG_HOME": str(path / "xdg")})
        self.assertEqual(res.returncode, 1)
        self.assertEqual(res.stdout, "")
        self.assertIn("error: No default config file found. See help for more info.", res.stderr)

    def test_list_show_and_run_from_pier_toml(self):
        cfg = """
[scripts.alpha]
command = "echo Alpha"
description = "first command"
tags = ["demo", "shell"]

[scripts.beta]
command = 'printf "<%s>\\n" "$1"'
""".lstrip()
        tmp, path = self.temp_workspace(cfg)
        self.addCleanup(tmp.cleanup)
        aliases = self.run_cli("list", "-q", cwd=path)
        self.assertEqual(aliases.returncode, 0)
        self.assertEqual(aliases.stdout, "alpha\nbeta\n")
        shown = self.run_cli("show", "alpha", cwd=path)
        self.assertEqual(shown.stdout, "echo Alpha\n")
        ran = self.run_cli("run", "beta", "value", cwd=path)
        self.assertEqual(ran.returncode, 0)
        self.assertEqual(ran.stdout, "<value>\n")

    def test_add_copy_move_remove_update_config(self):
        tmp, path = self.temp_workspace("[default]\n")
        self.addCleanup(tmp.cleanup)
        add = self.run_cli("add", "-a", "hello", "-d", "say hi", "-t", "demo", "-t", "shell", "--", "echo Hello", cwd=path)
        self.assertEqual(add.returncode, 0)
        self.assertEqual(add.stdout, "Added hello\n")
        self.assertEqual(self.run_cli("run", "hello", cwd=path).stdout, "Hello\n")
        self.assertEqual(self.run_cli("copy", "hello", "hello2", cwd=path).stdout, "Copy from alias hello to new alias hello2\n")
        self.assertEqual(self.run_cli("move", "hello2", "hi", cwd=path).stdout, "Move from alias hello2 to new alias hi\n")
        self.assertEqual(self.run_cli("remove", "hi", cwd=path).stdout, "Removed hi\n")
        aliases = self.run_cli("list", "-q", cwd=path).stdout
        self.assertEqual(aliases, "hello\n")

    def test_top_level_alias_runs_when_not_a_subcommand(self):
        tmp, path = self.temp_workspace("[scripts.args]\ncommand = 'printf \"<%s> <%s>\\n\" \"$1\" \"$2\"'\n")
        self.addCleanup(tmp.cleanup)
        res = self.run_cli("args", "one", "two", cwd=path)
        self.assertEqual(res.returncode, 0)
        self.assertEqual(res.stdout, "<one> <two>\n")

    def test_equals_form_options_are_accepted(self):
        tmp, path = self.temp_workspace("[default]\n")
        self.addCleanup(tmp.cleanup)
        add = self.run_cli("add", "--alias=eq", "--", "echo EQ", cwd=path)
        self.assertEqual(add.returncode, 0)
        cfg = path / "pier.toml"
        listed = self.run_cli(f"--config-file={cfg}", "list", "-q", cwd=path)
        self.assertEqual(listed.returncode, 0)
        self.assertEqual(listed.stdout, "eq\n")

    def test_config_init_fails_when_xdg_base_is_missing(self):
        tmp, path = self.temp_workspace()
        self.addCleanup(tmp.cleanup)
        res = self.run_cli("config-init", cwd=path, env={"HOME": str(path / "home"), "XDG_CONFIG_HOME": str(path / "missing-xdg")})
        self.assertEqual(res.returncode, 1)
        self.assertIn("error: Failed to create directory.", res.stderr)

if __name__ == "__main__":
    unittest.main()
