#!/usr/bin/env python3
import os
import shlex
import subprocess
import sys
from pathlib import Path

VERSION = "pier 0.1.6"
SUBCOMMANDS = {
    "add", "config-init", "init", "copy", "cp", "edit", "list", "ls",
    "move", "mv", "rename", "remove", "rm", "run", "show", "help",
}


def unquote(value):
    value = value.strip()
    if len(value) >= 2 and value[0] == value[-1] and value[0] in "\"'":
        body = value[1:-1]
        if value[0] == '"':
            return bytes(body, "utf-8").decode("unicode_escape")
        return body
    return value


def quote(value):
    return "'" + value.replace("\\", "\\\\").replace("'", "\\'") + "'"


def parse_array(value):
    value = value.strip()
    if not (value.startswith("[") and value.endswith("]")):
        return []
    inner = value[1:-1].strip()
    if not inner:
        return []
    lexer = shlex.shlex(inner, posix=True)
    lexer.whitespace = ","
    lexer.whitespace_split = True
    return [part.strip() for part in lexer if part.strip()]


def load_config(path):
    scripts = {}
    current = None
    pending_array = None
    for raw in path.read_text().splitlines():
        line = raw.strip()
        if not line or line.startswith("#"):
            continue
        if pending_array:
            key, values = pending_array
            if line.startswith("]"):
                scripts[current][key] = values
                pending_array = None
                continue
            item = line.rstrip(",").strip()
            if item:
                values.append(unquote(item))
            continue
        if line.startswith("[") and line.endswith("]"):
            section = line[1:-1].strip()
            if section.startswith("scripts."):
                current = section[len("scripts."):]
                scripts.setdefault(current, {})
            else:
                current = None
            continue
        if current and "=" in line:
            key, value = [part.strip() for part in line.split("=", 1)]
            if value == "[":
                pending_array = (key, [])
            elif value.startswith("["):
                scripts[current][key] = parse_array(value)
            else:
                scripts[current][key] = unquote(value)
    return scripts


def save_config(path, scripts, parents=True):
    path.parent.mkdir(parents=parents, exist_ok=True)
    lines = []
    for alias in sorted(scripts):
        data = scripts[alias]
        lines.append(f"[scripts.{alias}]")
        lines.append(f"command = {quote(data.get('command', ''))}")
        if data.get("description"):
            lines.append(f"description = {quote(data['description'])}")
        if data.get("tags"):
            lines.append("tags = [")
            for tag in data["tags"]:
                lines.append(f"    {quote(tag)},")
            lines.append("]")
        lines.append("")
    lines.append("[default]")
    path.write_text("\n".join(lines) + "\n")


def default_xdg_config_home():
    return os.environ.get("XDG_CONFIG_HOME") or str(Path.home() / ".config")


def find_config(explicit=None, for_create=False):
    if explicit:
        return Path(explicit)
    env_path = os.environ.get("PIER_CONFIG_PATH")
    if env_path:
        return Path(env_path)
    cwd = Path.cwd() / "pier.toml"
    if cwd.exists() or for_create:
        return cwd
    candidates = [
        Path(default_xdg_config_home()) / "pier" / "config.toml",
        Path(default_xdg_config_home()) / "pier" / "config",
        Path(default_xdg_config_home()) / "pier.toml",
        Path.home() / ".pier.toml",
        Path.home() / ".pier",
    ]
    for candidate in candidates:
        if candidate.exists():
            return candidate
    return None


def split_global_args(argv):
    rest = []
    explicit = None
    verbose = False
    i = 0
    while i < len(argv):
        arg = argv[i]
        if arg in ("-c", "--config-file"):
            if i + 1 >= len(argv):
                die("error: The argument '--config-file <path>' requires a value")
            explicit = argv[i + 1]
            i += 2
        elif arg.startswith("--config-file="):
            explicit = arg.split("=", 1)[1]
            i += 1
        elif arg in ("-v", "--verbose"):
            verbose = True
            i += 1
        else:
            rest.extend(argv[i:])
            break
    return explicit, verbose, rest


def die(message, code=1):
    print(message, file=sys.stderr)
    raise SystemExit(code)


def require_config(explicit=None):
    path = find_config(explicit)
    if not path or not path.exists():
        die("error: No default config file found. See help for more info.")
    return path, load_config(path)


def print_main_help():
    print(f"""{VERSION}
Benjamin Scholtz, Isak Johansson
A simple script management CLI

USAGE:
    executable [FLAGS] [OPTIONS] <alias> [args]...
    executable [FLAGS] [OPTIONS] <SUBCOMMAND>

FLAGS:
    -h, --help       Prints help information
    -V, --version    Prints version information
    -v, --verbose    The level of verbosity

OPTIONS:
    -c, --config-file <path>    Sets a custom config file.

SUBCOMMANDS:
    add            Add a new script to config.
    config-init    alias: init - Add a config file.
    copy           alias: cp - Copy existing alias to the new one
    edit           Edit a script matching alias.
    help           Prints this message or the help of the given subcommand(s)
    list           alias: ls - List scripts
    move           alias: mv, rename - Move/rename existing alias to the new one
    remove         alias: rm - Remove a script matching alias.
    run            Run a script matching alias.
    show           Show a script matching alias.""")


def sub_help(name):
    helps = {
        "add": "USAGE:\n    executable add [FLAGS] [OPTIONS] --alias <alias> [--] [command]",
        "list": "USAGE:\n    executable list [FLAGS] [OPTIONS]",
        "run": "USAGE:\n    executable run <alias> [args]...",
        "show": "USAGE:\n    executable show <alias>",
        "remove": "USAGE:\n    executable remove <alias>",
        "copy": "USAGE:\n    executable copy <from-alias> <to-alias>",
        "move": "USAGE:\n    executable move [FLAGS] <from-alias> <to-alias>",
        "config-init": "USAGE:\n    executable config-init",
    }
    canonical = {"ls": "list", "rm": "remove", "cp": "copy", "mv": "move", "rename": "move", "init": "config-init"}.get(name, name)
    print(f"executable-{canonical} 0.1.6")
    print(helps.get(canonical, ""))


def parse_add(args):
    alias = None
    desc = None
    tags = []
    force = False
    command = None
    i = 0
    while i < len(args):
        arg = args[i]
        if arg in ("-f", "--force"):
            force = True
            i += 1
        elif arg in ("-a", "--alias"):
            alias = args[i + 1] if i + 1 < len(args) else None
            i += 2
        elif arg.startswith("--alias="):
            alias = arg.split("=", 1)[1]
            i += 1
        elif arg in ("-d", "--description"):
            desc = args[i + 1] if i + 1 < len(args) else None
            i += 2
        elif arg in ("-t", "--tag"):
            if i + 1 < len(args):
                tags.append(args[i + 1])
            i += 2
        elif arg == "--command":
            command = args[i + 1] if i + 1 < len(args) else ""
            i += 2
        elif arg == "--":
            command = " ".join(args[i + 1:])
            break
        else:
            command = " ".join(args[i:])
            break
    if not alias:
        die("error: The following required arguments were not provided:\n    --alias <alias>", 1)
    if command is None:
        editor = os.environ.get("EDITOR")
        if not editor:
            die("error: No command provided and $EDITOR is not set.")
        command = ""
    return alias, command, desc, tags, force


def cmd_config_init(explicit):
    path = find_config(explicit)
    if not path:
        path = Path(default_xdg_config_home()) / "pier" / "config.toml"
    if path.exists():
        scripts = load_config(path)
    else:
        scripts = {}
    scripts["hello-pier"] = {
        "command": "echo Hello, Pier!",
        "description": "This is an example command.",
    }
    try:
        save_config(path, scripts, parents=False)
    except OSError as exc:
        die(f"error: Failed to create directory. {exc.strerror} (os error {exc.errno})")
    print("Added hello-pier")


def cmd_add(args, explicit):
    alias, command, desc, tags, force = parse_add(args)
    path = find_config(explicit, for_create=True) if explicit else find_config(explicit)
    if not path:
        die("error: No default config file found. See help for more info.")
    scripts = load_config(path) if path.exists() else {}
    if alias in scripts and not force:
        die(f"error: Script matching alias {alias} already exists")
    scripts[alias] = {"command": command}
    if desc:
        scripts[alias]["description"] = desc
    if tags:
        scripts[alias]["tags"] = tags
    save_config(path, scripts)
    print(f"Added {alias}")


def filtered_aliases(scripts, tags):
    aliases = sorted(scripts)
    if tags:
        required = set(tags)
        aliases = [a for a in aliases if required.intersection(set(scripts[a].get("tags", [])))]
    return aliases


def cmd_list(args, explicit):
    list_aliases = False
    cmd_full = False
    cmd_width = 16
    tags = []
    i = 0
    while i < len(args):
        arg = args[i]
        if arg in ("-q", "--list_aliases"):
            list_aliases = True
            i += 1
        elif arg in ("-l", "--cmd_full"):
            cmd_full = True
            i += 1
        elif arg in ("-c", "--cmd_width"):
            cmd_width = int(args[i + 1])
            i += 2
        elif arg in ("-t", "--tag"):
            tags.append(args[i + 1])
            i += 2
        else:
            i += 1
    _, scripts = require_config(explicit)
    aliases = filtered_aliases(scripts, tags)
    if list_aliases:
        for alias in aliases:
            print(alias)
        return
    rows = []
    for alias in aliases:
        data = scripts[alias]
        command = data.get("command", "")
        if not cmd_full and len(command) > cmd_width:
            command = command[:cmd_width]
        rows.append((alias, ",".join(data.get("tags", [])), command, data.get("description", "")))
    widths = [max([len(h)] + [len(row[i]) for row in rows]) for i, h in enumerate(("Alias", "Tags", "Command", "Description"))]
    widths = [max(widths[0], 5), max(widths[1], 4), max(widths[2], 7), max(widths[3], 11)]
    line = "≖" * (sum(widths) + 15)
    print(line)
    print("⋮ " + " ⋮ ".join(h.ljust(widths[i]) for i, h in enumerate(("Alias", "Tags", "Command", "Description"))) + " ⋮")
    print(line)
    for row in rows:
        print("⋮ " + " ⋮ ".join(row[i].ljust(widths[i]) for i in range(4)) + " ⋮")
    print(line)


def cmd_show(alias, explicit):
    _, scripts = require_config(explicit)
    if alias not in scripts:
        die(f"error: No script matching alias {alias}")
    print(scripts[alias].get("command", ""))


def run_alias(alias, run_args, explicit):
    _, scripts = require_config(explicit)
    if alias not in scripts:
        die(f"error: No script matching alias {alias}")
    command = scripts[alias].get("command", "")
    proc = subprocess.run(["sh", "-c", command, alias, *run_args])
    raise SystemExit(proc.returncode)


def cmd_remove(alias, explicit):
    path, scripts = require_config(explicit)
    if alias not in scripts:
        die(f"error: No script matching alias {alias}")
    del scripts[alias]
    save_config(path, scripts)
    print(f"Removed {alias}")


def cmd_copy(from_alias, to_alias, explicit):
    path, scripts = require_config(explicit)
    if from_alias not in scripts:
        die(f"error: No script matching alias {from_alias}")
    if to_alias in scripts:
        die(f"error: Script matching alias {to_alias} already exists")
    scripts[to_alias] = dict(scripts[from_alias])
    if "tags" in scripts[from_alias]:
        scripts[to_alias]["tags"] = list(scripts[from_alias]["tags"])
    save_config(path, scripts)
    print(f"Copy from alias {from_alias} to new alias {to_alias}")


def cmd_move(args, explicit):
    force = False
    rest = []
    for arg in args:
        if arg in ("-f", "--force"):
            force = True
        else:
            rest.append(arg)
    if len(rest) < 2:
        die("error: Missing required arguments")
    from_alias, to_alias = rest[0], rest[1]
    path, scripts = require_config(explicit)
    if from_alias not in scripts:
        die(f"error: No script matching alias {from_alias}")
    if to_alias in scripts and not force:
        die(f"error: Script matching alias {to_alias} already exists")
    scripts[to_alias] = scripts.pop(from_alias)
    save_config(path, scripts)
    print(f"Move from alias {from_alias} to new alias {to_alias}")


def main(argv):
    explicit, _verbose, args = split_global_args(argv)
    if not args or args[0] in ("-h", "--help"):
        print_main_help()
        return 0
    if args[0] in ("-V", "--version"):
        print(VERSION)
        return 0
    if args[0] == "help":
        if len(args) > 1:
            sub_help(args[1])
        else:
            print_main_help()
        return 0
    cmd = args[0]
    if cmd in ("config-init", "init"):
        cmd_config_init(explicit)
    elif cmd == "add":
        cmd_add(args[1:], explicit)
    elif cmd in ("list", "ls"):
        cmd_list(args[1:], explicit)
    elif cmd == "show":
        if len(args) < 2:
            die("error: Missing required argument <alias>")
        cmd_show(args[1], explicit)
    elif cmd == "run":
        if len(args) < 2:
            die("error: Missing required argument <alias>")
        run_alias(args[1], args[2:], explicit)
    elif cmd in ("remove", "rm"):
        if len(args) < 2:
            die("error: Missing required argument <alias>")
        cmd_remove(args[1], explicit)
    elif cmd in ("copy", "cp"):
        if len(args) < 3:
            die("error: Missing required arguments")
        cmd_copy(args[1], args[2], explicit)
    elif cmd in ("move", "mv", "rename"):
        cmd_move(args[1:], explicit)
    elif cmd == "edit":
        die("error: edit is not available in this reimplementation")
    else:
        run_alias(cmd, args[1:], explicit)
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main(sys.argv[1:]))
    except BrokenPipeError:
        raise SystemExit(1)
