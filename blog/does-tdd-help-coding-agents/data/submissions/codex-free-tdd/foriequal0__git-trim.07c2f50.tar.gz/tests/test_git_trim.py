import os
import shutil
import subprocess
import tempfile
import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
PROGRAM = ROOT / "src" / "git_trim.py"


def run_program(args, cwd=None, input_text=None):
    return subprocess.run(
        ["python3", str(PROGRAM), *args],
        cwd=cwd,
        input=input_text,
        text=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
    )


def git(cwd, *args):
    subprocess.run(["git", *args], cwd=cwd, check=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)


class GitTrimTests(unittest.TestCase):
    def setUp(self):
        self.tmp = Path(tempfile.mkdtemp(prefix="git-trim-test-"))
        subprocess.run(["git", "config", "--global", "user.email", "agent@example.test"], check=True)
        subprocess.run(["git", "config", "--global", "user.name", "Agent"], check=True)

    def tearDown(self):
        shutil.rmtree(self.tmp)

    def make_repo_with_merged_and_stray(self):
        bare = self.tmp / "origin.git"
        work = self.tmp / "work"
        git(self.tmp, "init", "--bare", "--initial-branch=main", str(bare))
        git(self.tmp, "clone", str(bare), str(work))
        (work / "f").write_text("base\n")
        git(work, "add", "f")
        git(work, "commit", "-m", "base")
        git(work, "push", "-u", "origin", "main")
        git(work, "remote", "set-head", "origin", "-a")

        git(work, "checkout", "-b", "merged")
        (work / "m").write_text("merged\n")
        git(work, "add", "m")
        git(work, "commit", "-m", "merged")
        git(work, "push", "-u", "origin", "merged")
        git(work, "checkout", "main")
        git(work, "merge", "--no-ff", "merged", "-m", "merge")
        git(work, "push")

        git(work, "checkout", "-b", "stray")
        (work / "s").write_text("stray\n")
        git(work, "add", "s")
        git(work, "commit", "-m", "stray")
        git(work, "push", "-u", "origin", "stray")
        git(work, "checkout", "main")
        git(work, "push", "origin", "--delete", "stray")
        return work

    def test_version_matches_documented_binary(self):
        result = run_program(["--version"])
        self.assertEqual(result.returncode, 0)
        self.assertEqual(result.stdout, "git-trim 0.4.4\n")

    def test_not_a_repository_reports_libgit_style_error(self):
        empty = self.tmp / "empty"
        empty.mkdir()
        result = run_program(["--dry-run"], cwd=empty)
        self.assertEqual(result.returncode, 1)
        self.assertEqual(
            result.stdout,
            "Error: could not find repository at '.'; class=Repository (6); code=NotFound (-3)\n",
        )

    def test_default_dry_run_reports_merged_tracking_branches(self):
        work = self.make_repo_with_merged_and_stray()
        result = run_program(["--dry-run", "--no-update", "--no-confirm"], cwd=work)
        self.assertEqual(result.returncode, 0)
        self.assertIn("Branches that will remain:\n", result.stdout)
        self.assertIn("    main [base]\n", result.stdout)
        self.assertIn("    stray [stray, but: delete range `stray` was not given]\n", result.stdout)
        self.assertIn("Delete merged local branches:\n  - merged\n", result.stdout)
        self.assertIn("Delete merged remote refs:\n  - origin, refs/heads/merged\n", result.stdout)
        self.assertIn("Delete branch merged (dry run).\n", result.stdout)

    def test_stray_delete_range_reports_stray_only(self):
        work = self.make_repo_with_merged_and_stray()
        result = run_program(["--dry-run", "--no-update", "--no-confirm", "-d", "stray"], cwd=work)
        self.assertEqual(result.returncode, 0)
        self.assertIn("    merged [merged, but: delete range `merged-local` was not given]\n", result.stdout)
        self.assertIn("Delete stray local branches:\n  - stray\n", result.stdout)
        self.assertIn("Delete branch stray (dry run).\n", result.stdout)

    def test_repository_without_remote_is_rejected_even_with_explicit_base(self):
        work = self.tmp / "solo"
        git(self.tmp, "init", "--initial-branch=main", str(work))
        (work / "f").write_text("base\n")
        git(work, "add", "f")
        git(work, "commit", "-m", "base")
        result = run_program(["--dry-run", "--no-update", "--no-confirm", "-b", "main"], cwd=work)
        self.assertEqual(result.returncode, 1)
        self.assertEqual(result.stdout, "Error: git-trim requires at least one remote\n")

    def test_local_delete_range_reports_merged_non_tracking_branch(self):
        bare = self.tmp / "origin.git"
        work = self.tmp / "work"
        git(self.tmp, "init", "--bare", "--initial-branch=main", str(bare))
        git(self.tmp, "clone", str(bare), str(work))
        (work / "f").write_text("base\n")
        git(work, "add", "f")
        git(work, "commit", "-m", "base")
        git(work, "push", "-u", "origin", "main")
        git(work, "checkout", "-b", "feat")
        (work / "feat").write_text("feat\n")
        git(work, "add", "feat")
        git(work, "commit", "-m", "feat")
        git(work, "checkout", "main")
        git(work, "merge", "--no-ff", "feat", "-m", "merge")

        result = run_program(["--dry-run", "--no-update", "--no-confirm", "-b", "main", "-d", "local"], cwd=work)
        self.assertEqual(result.returncode, 0)
        self.assertIn("Delete merged local branches:\n  - feat (non-tracking)\n", result.stdout)
        self.assertIn("Delete branch feat (dry run).\n", result.stdout)


if __name__ == "__main__":
    unittest.main()
