#!/usr/bin/env python3
import argparse
import fnmatch
import os
import subprocess
import sys
from dataclasses import dataclass


VERSION = "git-trim 0.4.4"
DESCRIPTION = "Automatically trims your tracking branches whose upstream branches are merged or stray."


class GitError(Exception):
    pass


def git(args, cwd=None, check=True):
    proc = subprocess.run(
        ["git", *args],
        cwd=cwd,
        text=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
    )
    if check and proc.returncode != 0:
        raise GitError(proc.stderr.strip() or proc.stdout.strip())
    return proc


def in_repo():
    return git(["rev-parse", "--show-toplevel"], check=False).returncode == 0


def git_bool(args):
    return git(args, check=False).returncode == 0


def git_out(args):
    return git(args).stdout.strip()


@dataclass
class LocalBranch:
    name: str
    upstream: str
    current: bool


@dataclass
class RemoteRef:
    remote: str
    branch: str

    @property
    def short(self):
        return f"{self.remote}/{self.branch}"

    @property
    def full_remote_ref(self):
        return f"refs/heads/{self.branch}"


def split_csv(value):
    if not value:
        return []
    return [part.strip() for part in value.split(",") if part.strip()]


def read_config(name):
    proc = git(["config", "--get", name], check=False)
    if proc.returncode == 0:
        return proc.stdout.strip()
    return None


def default_bases():
    proc = git(
        ["for-each-ref", "--format=%(refname:short) %(symref:short)", "refs/remotes"],
        check=False,
    )
    bases = []
    for line in proc.stdout.splitlines():
        parts = line.split()
        if len(parts) == 2 and parts[0].endswith("/HEAD"):
            branch = parts[1].split("/", 1)[1] if "/" in parts[1] else parts[1]
            if branch not in bases:
                bases.append(branch)
    return bases


def base_error():
    print("I can't detect base branch! Try following any resolution:")
    print("You also can set bases manually with any of following commands:")
    print(" * `git remote set-head origin --auto` will help `git-trim` to automatically")
    print("   detect the base branch.")
    print("   If you see `origin/HEAD set to <base branch>` in the output of the previous")
    print("   command, then `git branch --set-upstream origin/<base branch> <base branch>`")
    print("   to set an upstream branch for <base branch> if exists.")
    print(" * `git config trim.bases develop,master` for a repository.")
    print(" * `git config --global trim.bases develop,master` to set globally.")
    print(" * `git trim --bases develop,master` to set temporarily.")
    print("Error: No base branch is found!")


def local_branches():
    fmt = "%(refname:short)\t%(upstream:short)\t%(HEAD)"
    out = git_out(["for-each-ref", f"--format={fmt}", "refs/heads"])
    branches = []
    for line in out.splitlines():
        name, upstream, head = (line.split("\t") + ["", ""])[:3]
        branches.append(LocalBranch(name=name, upstream=upstream, current=head == "*"))
    return branches


def remote_refs():
    out = git_out(["for-each-ref", "--format=%(refname:short)", "refs/remotes"])
    refs = []
    for short in out.splitlines():
        if short.endswith("/HEAD") or "/" not in short:
            continue
        remote, branch = short.split("/", 1)
        refs.append(RemoteRef(remote, branch))
    return refs


def ref_exists(ref):
    return git(["rev-parse", "--verify", "--quiet", ref], check=False).returncode == 0


def upstream_gone(branch):
    if not branch.upstream:
        return False
    return not ref_exists(branch.upstream)


def is_ancestor(ref, base_refs):
    for base_ref in base_refs:
        if ref_exists(ref) and ref_exists(base_ref) and git_bool(["merge-base", "--is-ancestor", ref, base_ref]):
            return True
    return False


def configured_base_refs(bases):
    refs = []
    for base in bases:
        if ref_exists(base):
            refs.append(base)
    for branch in local_branches():
        if branch.name in bases and branch.upstream and ref_exists(branch.upstream):
            refs.append(branch.upstream)
    if not refs:
        for remote_ref in remote_refs():
            if remote_ref.branch in bases:
                refs.append(remote_ref.short)
    return refs


def parse_delete_ranges(value):
    if value is None:
        value = read_config("trim.delete") or "merged:origin"
    enabled = {
        "merged_local": False,
        "merged_remote": set(),
        "stray": False,
        "local": False,
        "remote": set(),
        "diverged": set(),
    }
    valid = {"merged", "merged-local", "merged-remote", "stray", "diverged", "local", "remote"}
    for raw in split_csv(value):
        name, _, remote = raw.partition(":")
        if name not in valid:
            print(
                f"error: invalid value '{value}' for '--delete <DELETE>': Invalid delete range format `{raw}`\n",
                file=sys.stderr,
            )
            print("For more information, try '--help'.", file=sys.stderr)
            sys.exit(2)
        if name == "merged":
            enabled["merged_local"] = True
            enabled["merged_remote"].add(remote or "origin")
        elif name == "merged-local":
            enabled["merged_local"] = True
        elif name == "merged-remote":
            enabled["merged_remote"].add(remote or "origin")
        elif name == "stray":
            enabled["stray"] = True
        elif name == "local":
            enabled["local"] = True
        elif name == "remote":
            enabled["remote"].add(remote or "origin")
        elif name == "diverged":
            enabled["diverged"].add(remote or "origin")
            enabled["merged_local"] = True
    return enabled


def remote_allowed(allowed, remote):
    return "*" in allowed or remote in allowed


def protect_match(name, protected):
    return any(fnmatch.fnmatch(name, pat) for pat in protected)


def classify(args):
    bases = split_csv(args.bases or read_config("trim.bases"))
    if not bases:
        bases = default_bases()
    if not bases:
        base_error()
        return 1

    delete = parse_delete_ranges(args.delete)
    protected = split_csv(args.protected or read_config("trim.protected"))
    base_refs = configured_base_refs(bases)
    if not base_refs:
        base_error()
        return 1

    locals_ = local_branches()
    remotes = remote_refs()
    current = next((b.name for b in locals_ if b.current), "")

    delete_merged_local = []
    delete_stray = []
    delete_local = []
    remain_locals = []
    for branch in locals_:
        label = None
        is_base = branch.name in bases
        stray = upstream_gone(branch)
        merged = (not is_base) and is_ancestor(branch.name, base_refs)
        untracked_local_merged = (not branch.upstream) and merged
        if protect_match(branch.name, protected):
            label = "protected"
        elif is_base:
            label = "base"
        elif stray:
            if delete["stray"]:
                delete_stray.append(branch.name)
                continue
            label = "stray, but: delete range `stray` was not given"
        elif branch.upstream and merged:
            if delete["merged_local"]:
                delete_merged_local.append((branch.name, ""))
                continue
            label = "merged, but: delete range `merged-local` was not given"
        elif untracked_local_merged:
            if delete["local"]:
                delete_merged_local.append((branch.name, " (non-tracking)"))
                continue
        suffix = ""
        if label:
            suffix = f" [{label}]"
        if branch.current and not suffix:
            suffix = " *1"
        remain_locals.append(f"    {branch.name}{suffix}")

    delete_merged_remote = []
    remain_remotes = []
    for remote in remotes:
        is_base = remote.branch in bases
        merged = (not is_base) and is_ancestor(remote.short, base_refs)
        label = None
        if protect_match(remote.branch, protected) or protect_match(remote.short, protected):
            label = "protected"
        elif is_base:
            label = "base"
        elif merged:
            if remote_allowed(delete["merged_remote"], remote.remote):
                delete_merged_remote.append(remote)
                continue
            label = f"merged, but: delete range `merged-remote:{remote.remote}` was not given"
        suffix = f" [{label}]" if label else ""
        remain_remotes.append(f"    {remote.short}{suffix}")

    print("Branches that will remain:")
    print("  local branches:")
    for line in remain_locals:
        print(line)
    print("  remote references:")
    for line in remain_remotes:
        print(line)
    skipped = any(line.endswith(" *1") for line in remain_locals)
    if skipped:
        print("  Some branches are skipped. Consider following to scan them:")
        print("    *1: Add `--delete 'merged:*'` flag.")
    print()

    if delete_merged_local:
        print("Delete merged local branches:")
        for name, suffix in delete_merged_local:
            print(f"  - {name}{suffix}")
    if delete_merged_remote:
        print("Delete merged remote refs:")
        for ref in delete_merged_remote:
            print(f"  - {ref.remote}, {ref.full_remote_ref}")
    if delete_stray:
        print("Delete stray local branches:")
        for name in delete_stray:
            print(f"  - {name}")
    if delete_local:
        print("Delete local branches:")
        for name in delete_local:
            print(f"  - {name}")

    for ref in delete_merged_remote:
        if args.dry_run:
            continue
        git(["push", ref.remote, "--delete", ref.branch], check=False)
    local_delete_names = [name for name, _ in delete_merged_local] + delete_stray + delete_local
    for name in local_delete_names:
        if args.dry_run:
            print(f"Delete branch {name} (dry run).")
        else:
            proc = git(["branch", "-D", name], check=False)
            sys.stdout.write(proc.stdout)
            sys.stderr.write(proc.stderr)
    return 0


def help_text(long=False):
    extra = """
          
          The default value is a branch that tracks `git symbolic-ref refs/remotes/*/HEAD`. They might not be reflected correctly when the HEAD branch of your remote repository is changed. You can see the changed HEAD branch name with `git remote show <remote>` and apply it to your local repository with `git remote set-head <remote> --auto`.
"""
    delete_extra = """
          
          `merged` implies `merged-local,merged-remote`.
          
          `merged-local` will delete merged tracking local branches. `merged-remote:<remote>` will delete merged upstream branches from `<remote>`. `stray` will delete tracking local branches, which is not merged, but the upstream is gone. `diverged:<remote>` will delete merged tracking local branches, and their upstreams from `<remote>` even if the upstreams are not merged and diverged from local ones. `local` will delete non-tracking merged local branches. `remote:<remote>` will delete non-upstream merged remote tracking branches. Use with caution when you are using other than `merged`. It might lose changes, and even nuke repositories.
"""
    print(DESCRIPTION)
    print("`git-trim` is a missing companion to the `git fetch --prune` and a proper, safer, faster alternative to your `<bash oneliner HERE>`.")
    print()
    print("Usage: executable [OPTIONS]")
    print()
    print("Options:")
    print("  -b, --bases <BASES>")
    print("          Comma separated multiple names of branches. All the other branches are compared with the upstream branches of those branches. [default: branches that tracks `git symbolic-ref refs/remotes/*/HEAD`] [config: trim.bases]")
    if long:
        print(extra, end="")
    print("  -p, --protected <PROTECTED>")
    print("          Comma separated multiple glob patterns (e.g. `release-*`, `feature/*`) of branches that should never be deleted. [config: trim.protected]")
    print()
    print("      --no-update")
    print("          Do not update remotes [config: trim.update]")
    print()
    print("      --update-interval <UPDATE_INTERVAL>")
    print("          Prevents too frequent updates. Seconds between updates in seconds. 0 to disable. [default: 5] [config: trim.updateInterval]")
    print()
    print("      --no-confirm")
    print("          Do not ask confirm [config: trim.confirm]")
    print()
    print("      --no-detach")
    print("          Do not detach when HEAD is about to be deleted [config: trim.detach]")
    print()
    print("  -d, --delete <DELETE>")
    print("          Comma separated values of `<delete range>[:<remote name>]`. Delete range is one of the `merged, merged-local, merged-remote, stray, diverged, local, remote`. `:<remote name>` is only necessary to a `<delete range>` when the range is applied to remote branches. You can use `*` as `<remote name>` to delete a range of branches from all remotes. [default : `merged:origin`] [config: trim.delete]")
    if long:
        print(delete_extra, end="")
    print("      --dry-run")
    print("          Do not delete branches, show what branches will be deleted")
    print()
    print("  -h, --help")
    print("          Print help (see more with '--help')" if not long else "          Print help (see a summary with '-h')")
    print()
    print("  -V, --version")
    print("          Print version")


def make_parser():
    parser = argparse.ArgumentParser(add_help=False)
    parser.add_argument("-b", "--bases")
    parser.add_argument("-p", "--protected")
    parser.add_argument("--no-update", dest="update", action="store_false", default=True)
    parser.add_argument("--update", dest="update", action="store_true")
    parser.add_argument("--update-interval", type=int, default=5)
    parser.add_argument("--no-confirm", dest="confirm", action="store_false", default=True)
    parser.add_argument("--confirm", dest="confirm", action="store_true")
    parser.add_argument("--no-detach", dest="detach", action="store_false", default=True)
    parser.add_argument("--detach", dest="detach", action="store_true")
    parser.add_argument("-d", "--delete")
    parser.add_argument("--dry-run", action="store_true")
    parser.add_argument("-h", "--help", action="store_true")
    parser.add_argument("-V", "--version", action="store_true")
    return parser


def main(argv):
    if "-h" in argv and "--help" not in argv:
        help_text(long=False)
        return 0
    if "--help" in argv:
        help_text(long=True)
        return 0
    if "-V" in argv or "--version" in argv:
        print(VERSION)
        return 0
    parser = make_parser()
    try:
        args = parser.parse_args(argv)
    except SystemExit as exc:
        return int(exc.code)
    if not in_repo():
        print("Error: could not find repository at '.'; class=Repository (6); code=NotFound (-3)")
        return 1
    if not git_out(["remote"]):
        print("Error: git-trim requires at least one remote")
        return 1
    if args.update:
        git(["fetch", "--prune", "--all"], check=False)
    return classify(args)


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
