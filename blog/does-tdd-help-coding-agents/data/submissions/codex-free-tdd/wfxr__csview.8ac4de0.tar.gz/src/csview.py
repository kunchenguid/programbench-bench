#!/usr/bin/env python3
import argparse
import csv
import io
import sys
import unicodedata


HELP_TEXT = """A high performance csv viewer with cjk/emoji support.

Usage: executable [OPTIONS] [FILE]

Arguments:
  [FILE]
          File to view

Options:
  -H, --no-headers
          Specify that the input has no header row
  -n, --number
          Prepend a column of line numbers to the table
  -t, --tsv
          Use '\\t' as delimiter for tsv
  -d, --delimiter <DELIMITER>
          Specify the field delimiter [default: ,]
  -s, --style <STYLE>
          Specify the border style [default: sharp] [possible values: none, ascii, ascii2, sharp,
          rounded, reinforced, markdown, grid]
  -p, --padding <PADDING>
          Specify padding for table cell [default: 1]
  -i, --indent <INDENT>
          Specify global indent for table [default: 0]
      --sniff <LIMIT>
          Limit column widths sniffing to the specified number of rows. Specify "0" to cancel limit
          [default: 1000]
      --header-align <HEADER_ALIGN>
          Specify the alignment of the table header [default: center] [possible values: left,
          center, right]
      --body-align <BODY_ALIGN>
          Specify the alignment of the table body [default: left] [possible values: left, center,
          right]
  -P, --disable-pager
          Disable pager
  -h, --help
          Print help
  -V, --version
          Print version
"""

VALID_STYLES = ["none", "ascii", "ascii2", "sharp", "rounded", "reinforced", "markdown", "grid"]
VALID_ALIGNS = ["left", "center", "right"]


STYLES = {
    "ascii": {
        "top": ("+", "+", "+", "+"),
        "mid": ("+", "+", "+", "+"),
        "bottom": ("+", "+", "+", "+"),
        "h": "-",
        "v": "|",
    },
    "sharp": {
        "top": ("┌", "┬", "┐", "┬"),
        "mid": ("├", "┼", "┤", "┼"),
        "bottom": ("└", "┴", "┘", "┴"),
        "h": "─",
        "v": "│",
    },
    "rounded": {
        "top": ("╭", "┬", "╮", "┬"),
        "mid": ("├", "┼", "┤", "┼"),
        "bottom": ("╰", "┴", "╯", "┴"),
        "h": "─",
        "v": "│",
    },
    "reinforced": {
        "top": ("┏", "┬", "┓", "┬"),
        "mid": ("├", "┼", "┤", "┼"),
        "bottom": ("┗", "┴", "┛", "┴"),
        "h": "─",
        "v": "│",
    },
}


def cell_width(text):
    width = 0
    for ch in text:
        if unicodedata.combining(ch):
            continue
        if unicodedata.east_asian_width(ch) in ("W", "F"):
            width += 2
        elif ord(ch) >= 0x1F000:
            width += 2
        else:
            width += 1
    return width


def pad_display(text, target, align):
    missing = max(0, target - cell_width(text))
    if align == "right":
        return " " * missing + text
    if align == "center":
        left = missing // 2
        return " " * left + text + " " * (missing - left)
    return text + " " * missing


def read_rows(path, delimiter):
    if path:
        fh = open(path, newline="")
        close = True
    else:
        fh = sys.stdin
        close = False
    try:
        return list(csv.reader(fh, delimiter=delimiter))
    finally:
        if close:
            fh.close()


def validate_rows(rows, original_text=None):
    if not rows:
        return
    expected = len(rows[0])
    byte = 0
    if original_text is not None:
        lines = original_text.splitlines(True)
    else:
        lines = []
    for idx, row in enumerate(rows[1:], 1):
        if len(row) != expected:
            line_no = idx + 1
            if lines:
                byte = sum(len(line.encode()) for line in lines[:idx])
            else:
                byte = 0
            raise ValueError(
                f"record {idx} (line: {line_no}, byte: {byte}): found record "
                f"with {len(row)} fields, but the previous record has {expected} fields"
            )


def split_header(rows, no_headers):
    if not rows:
        return [""], []
    if no_headers:
        return None, rows
    return rows[0], rows[1:]


def with_numbers(header, body):
    if header is None:
        body = [[str(i + 1), *row] for i, row in enumerate(body)]
        return None, body
    return ["#", *header], [[str(i + 1), *row] for i, row in enumerate(body)]


def table_widths(header, body, padding):
    rows = []
    if header is not None:
        rows.append(header)
    rows.extend(body)
    cols = max((len(r) for r in rows), default=1)
    widths = []
    for col in range(cols):
        content = max((cell_width(row[col]) for row in rows if col < len(row)), default=0)
        widths.append(content + padding * 2)
    return widths


def format_cell(text, width, padding, align):
    content_width = width - padding * 2
    return " " * padding + pad_display(text, content_width, align) + " " * padding


def border(widths, style, part):
    spec = STYLES[style]
    left, sep, right, _ = spec[part]
    return left + sep.join(spec["h"] * width for width in widths) + right


def row_line(row, widths, style, padding, align):
    spec = STYLES[style]
    cells = [format_cell(row[i] if i < len(row) else "", widths[i], padding, align) for i in range(len(widths))]
    return spec["v"] + spec["v"].join(cells) + spec["v"]


def render_box(header, body, widths, style, padding, header_align, body_align, grid=False):
    lines = [border(widths, style, "top")]
    if header is not None:
        lines.append(row_line(header, widths, style, padding, header_align))
        lines.append(border(widths, style, "mid"))
    for idx, row in enumerate(body):
        lines.append(row_line(row, widths, style, padding, body_align))
        if grid and idx != len(body) - 1:
            lines.append(border(widths, style, "mid"))
    lines.append(border(widths, style, "bottom"))
    return lines


def render_none(header, body, widths, padding, header_align, body_align):
    rows = []
    if header is not None:
        rows.append((header, header_align))
    rows.extend((row, body_align) for row in body)
    lines = []
    for row, align in rows:
        cells = [format_cell(row[i] if i < len(row) else "", widths[i], padding, align) for i in range(len(widths))]
        lines.append("".join(cells))
    return lines


def render_ascii2(header, body, widths, padding, header_align, body_align):
    lines = []
    if header is not None:
        lines.append(" " + "|".join(format_cell(header[i], widths[i], padding, header_align) for i in range(len(widths))) + " ")
        lines.append(" " + "+".join("-" * width for width in widths) + " ")
    for row in body:
        lines.append(" " + "|".join(format_cell(row[i], widths[i], padding, body_align) for i in range(len(widths))) + " ")
    return lines


def render_markdown(header, body, widths, padding, header_align, body_align):
    lines = []
    if header is not None:
        lines.append("|" + "|".join(format_cell(header[i], widths[i], padding, header_align) for i in range(len(widths))) + "|")
        lines.append("|" + "|".join("-" * width for width in widths) + "|")
    for row in body:
        lines.append("|" + "|".join(format_cell(row[i], widths[i], padding, body_align) for i in range(len(widths))) + "|")
    return lines


def render(rows, args):
    if not rows:
        empty = {
            "ascii": ["++", "||", "++"],
            "sharp": ["┌┐", "││", "└┘"],
            "grid": ["┌┐", "││", "└┘"],
            "rounded": ["╭╮", "││", "╰╯"],
            "reinforced": ["┏┓", "││", "┗┛"],
            "none": [""],
            "ascii2": ["  "],
            "markdown": ["||"],
        }
        prefix = " " * args.indent
        return "".join(prefix + line + "\n" for line in empty[args.style])
        rows = [[""]]
    header, body = split_header(rows, args.no_headers)
    if args.number:
        header, body = with_numbers(header, body)
    widths = table_widths(header, body, args.padding)
    if args.style in STYLES:
        lines = render_box(header, body, widths, args.style, args.padding, args.header_align, args.body_align, args.style == "grid")
    elif args.style == "grid":
        lines = render_box(header, body, widths, "sharp", args.padding, args.header_align, args.body_align, True)
    elif args.style == "none":
        lines = render_none(header, body, widths, args.padding, args.header_align, args.body_align)
    elif args.style == "ascii2":
        lines = render_ascii2(header, body, widths, args.padding, args.header_align, args.body_align)
    elif args.style == "markdown":
        lines = render_markdown(header, body, widths, args.padding, args.header_align, args.body_align)
    else:
        lines = []
    prefix = " " * args.indent
    return "".join(prefix + line + "\n" for line in lines)


def build_parser():
    parser = argparse.ArgumentParser(
        prog="executable",
        description="A high performance csv viewer with cjk/emoji support.",
        add_help=False,
    )
    parser.add_argument("file", nargs="?")
    parser.add_argument("-h", "--help", action="store_true")
    parser.add_argument("-H", "--no-headers", action="store_true")
    parser.add_argument("-n", "--number", action="store_true")
    parser.add_argument("-t", "--tsv", action="store_true")
    parser.add_argument("-d", "--delimiter", default=",")
    parser.add_argument("-s", "--style", default="sharp")
    parser.add_argument("-p", "--padding", default="1")
    parser.add_argument("-i", "--indent", default="0")
    parser.add_argument("--sniff", default="1000")
    parser.add_argument("--header-align", default="center")
    parser.add_argument("--body-align", default="left")
    parser.add_argument("-P", "--disable-pager", action="store_true")
    parser.add_argument("-V", "--version", action="store_true")
    return parser


def clap_error(message):
    print(message, file=sys.stderr)
    print(file=sys.stderr)
    print("For more information, try '--help'.", file=sys.stderr)
    return 2


def parse_nonnegative_int(value, flag):
    try:
        parsed = int(value)
    except ValueError:
        raise ValueError(f"error: invalid value '{value}' for '{flag}': invalid digit found in string")
    if parsed < 0:
        raise ValueError(f"error: invalid value '{value}' for '{flag}': invalid digit found in string")
    return parsed


def main(argv=None):
    parser = build_parser()
    args = parser.parse_args(argv)
    if args.help:
        sys.stdout.write(HELP_TEXT)
        return 0
    if args.version:
        print("csview 1.3.4")
        return 0
    if args.style not in VALID_STYLES:
        hint = "\n\n  tip: a similar value exists: 'none'" if args.style and args.style[0] == "n" else ""
        return clap_error(
            f"error: invalid value '{args.style}' for '--style <STYLE>'\n"
            "  [possible values: none, ascii, ascii2, sharp, rounded, reinforced, markdown, grid]"
            f"{hint}"
        )
    if args.header_align not in VALID_ALIGNS:
        return clap_error(
            f"error: invalid value '{args.header_align}' for '--header-align <HEADER_ALIGN>'\n"
            "  [possible values: left, center, right]"
        )
    if args.body_align not in VALID_ALIGNS:
        return clap_error(
            f"error: invalid value '{args.body_align}' for '--body-align <BODY_ALIGN>'\n"
            "  [possible values: left, center, right]"
        )
    try:
        args.padding = parse_nonnegative_int(args.padding, "--padding <PADDING>")
        args.indent = parse_nonnegative_int(args.indent, "--indent <INDENT>")
    except ValueError as exc:
        return clap_error(str(exc))
    delimiter = "\t" if args.tsv else args.delimiter
    if len(delimiter) != 1:
        print("csview: delimiter must be a single character", file=sys.stderr)
        return 1
    try:
        if args.file:
            with open(args.file, newline="") as fh:
                text = fh.read()
        else:
            text = sys.stdin.read()
        rows = list(csv.reader(io.StringIO(text), delimiter=delimiter))
        validate_rows(rows, text)
        sys.stdout.write(render(rows, args))
        return 0
    except ValueError as exc:
        print(f"csview: CSV error: {exc}", file=sys.stderr)
        return 1
    except OSError as exc:
        print(f"csview: {exc}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
