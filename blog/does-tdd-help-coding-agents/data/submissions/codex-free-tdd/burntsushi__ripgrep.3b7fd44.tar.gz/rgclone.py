#!/usr/bin/env python3
import os, sys, re, fnmatch, json, stat
from pathlib import Path

VERSION = "ripgrep 14.1.1 (rev 719e15af5e)"
STDIN_DATA = None
SHORT_HELP = """ripgrep 14.1.1 (rev 719e15af5e)
Andrew Gallant <jamslam@gmail.com>

ripgrep (rg) recursively searches the current directory for lines matching
a regex pattern. By default, ripgrep will respect gitignore rules and
automatically skip hidden files/directories and binary files.

Use -h for short descriptions and --help for more details.

Project home page: https://github.com/BurntSushi/ripgrep

USAGE:
  rg [OPTIONS] PATTERN [PATH ...]
"""

TYPE_GLOBS = {
    'py':['*.py'], 'python':['*.py'], 'rs':['*.rs'], 'rust':['*.rs'], 'js':['*.js','*.jsx'],
    'ts':['*.ts','*.tsx'], 'go':['*.go'], 'c':['*.c','*.h'], 'cpp':['*.cc','*.cpp','*.cxx','*.hpp','*.hh'],
    'md':['*.md','*.markdown'], 'txt':['*.txt'], 'json':['*.json'], 'html':['*.html','*.htm'], 'css':['*.css'],
    'sh':['*.sh','*.bash'], 'java':['*.java'], 'rb':['*.rb'], 'toml':['*.toml'], 'yaml':['*.yaml','*.yml'],
}

class Opt:
    def __init__(self):
        self.patterns=[]; self.pattern_files=[]; self.paths=[]; self.files=False; self.type_list=False
        self.fixed=False; self.ignore_case=False; self.smart_case=False; self.invert=False; self.word=False; self.line=False
        self.line_number=False; self.no_line_number=False; self.with_filename=False; self.no_filename=False; self.column=False
        self.only_matching=False; self.vimgrep=False; self.count=False; self.count_matches=False; self.files_with_matches=False; self.files_without_match=False
        self.after=0; self.before=0; self.max_count=None; self.quiet=False; self.hidden=False; self.no_ignore=False; self.text=False; self.follow=False
        self.globs=[]; self.iglob=[]; self.types=[]; self.type_nots=[]; self.max_depth=None; self.sort=None; self.reverse_sort=False
        self.null=False; self.trim=False; self.passthru=False; self.include_zero=False; self.replace=None; self.json=False
        self.color='never'; self.unrestricted=0; self.max_filesize=None; self.path_separator=None

def need_arg(args, i, name):
    if i+1 >= len(args):
        print(f"rg: error: a value is required for '{name} <{name.upper()}>' but none was supplied", file=sys.stderr); sys.exit(2)
    return args[i+1], i+1

def parse_num(s):
    try: return int(s)
    except Exception: return 0

def parse_size(s):
    mult=1; t=s.strip()
    if t and t[-1].lower() in 'kmg':
        mult={'k':1024,'m':1024*1024,'g':1024*1024*1024}[t[-1].lower()]; t=t[:-1]
    try: return int(float(t)*mult)
    except Exception: return None

def parse(argv):
    o=Opt(); positionals=[]; stop=False; i=0
    while i < len(argv):
        a=argv[i]
        if stop or not a.startswith('-') or a == '-':
            positionals.append(a); i+=1; continue
        if a == '--': stop=True; i+=1; continue
        if a.startswith('--'):
            name,val=(a[2:].split('=',1)+[None])[:2] if '=' in a else (a[2:], None)
            def valnext():
                nonlocal i,val
                if val is None: val,i=need_arg(argv,i,'--'+name)
                return val
            if name in ('help',): print(SHORT_HELP, end=''); sys.exit(0)
            elif name in ('version',): print(VERSION+'\n\nfeatures:-pcre2\nsimd(compile):+SSE2,-SSSE3,-AVX2\nsimd(runtime):+SSE2,+SSSE3,+AVX2\n\nPCRE2 is not available in this build of ripgrep.'); sys.exit(0)
            elif name=='files': o.files=True
            elif name=='type-list': o.type_list=True
            elif name in ('regexp','file','glob','iglob','type','type-not','after-context','before-context','context','max-count','max-depth','max-filesize','sort','sortr','replace','color','path-separator'):
                v=valnext()
                if name=='regexp': o.patterns.append(v)
                elif name=='file': o.pattern_files.append(v)
                elif name=='glob': o.globs.append(v)
                elif name=='iglob': o.iglob.append(v)
                elif name=='type': o.types.append(v)
                elif name=='type-not': o.type_nots.append(v)
                elif name=='after-context': o.after=parse_num(v)
                elif name=='before-context': o.before=parse_num(v)
                elif name=='context': o.before=o.after=parse_num(v)
                elif name=='max-count': o.max_count=parse_num(v)
                elif name=='max-depth': o.max_depth=parse_num(v)
                elif name=='max-filesize': o.max_filesize=parse_size(v)
                elif name=='sort': o.sort=v
                elif name=='sortr': o.sort=v; o.reverse_sort=True
                elif name=='replace': o.replace=v
                elif name=='color': o.color=v
                elif name=='path-separator': o.path_separator=v
            elif name in ('fixed-strings',): o.fixed=True
            elif name in ('ignore-case',): o.ignore_case=True
            elif name in ('smart-case',): o.smart_case=True
            elif name in ('case-sensitive',): o.ignore_case=False; o.smart_case=False
            elif name in ('invert-match',): o.invert=True
            elif name in ('word-regexp',): o.word=True
            elif name in ('line-regexp',): o.line=True
            elif name in ('line-number',): o.line_number=True
            elif name in ('no-line-number',): o.no_line_number=True
            elif name in ('with-filename',): o.with_filename=True
            elif name in ('no-filename',): o.no_filename=True
            elif name=='column': o.column=True; o.line_number=True
            elif name=='only-matching': o.only_matching=True
            elif name=='vimgrep': o.vimgrep=True; o.line_number=True; o.column=True; o.with_filename=True
            elif name=='count': o.count=True
            elif name=='count-matches': o.count_matches=True
            elif name=='files-with-matches': o.files_with_matches=True
            elif name=='files-without-match': o.files_without_match=True
            elif name=='quiet': o.quiet=True
            elif name=='hidden': o.hidden=True
            elif name=='no-ignore': o.no_ignore=True
            elif name in ('text','binary'): o.text=True
            elif name=='follow': o.follow=True
            elif name=='null': o.null=True
            elif name=='trim': o.trim=True
            elif name=='passthru': o.passthru=True
            elif name=='include-zero': o.include_zero=True
            elif name=='json': o.json=True
            elif name in ('pcre2-version',): print('PCRE2 is not available in this build of ripgrep.'); sys.exit(0)
            elif name.startswith('no-') or name in ('debug','trace','stats','mmap','multiline','multiline-dotall','crlf','null-data','no-config','search-zip','pre','pre-glob','encoding','engine','threads','dfa-size-limit','regex-size-limit','no-unicode','auto-hybrid-regex','no-pcre2-unicode','pcre2','glob-case-insensitive','ignore-file','ignore-file-case-insensitive','no-ignore-dot','no-ignore-exclude','no-ignore-files','no-ignore-global','no-ignore-parent','no-ignore-vcs','no-require-git','one-file-system','type-add','type-clear','block-buffered','colors','context-separator','field-context-separator','field-match-separator','heading','hostname-bin','hyperlink-format','line-buffered','max-columns','max-columns-preview','pretty','sort-files'):
                if name in ('pre','pre-glob','encoding','engine','threads','dfa-size-limit','regex-size-limit','ignore-file','type-add','type-clear','colors','context-separator','field-context-separator','field-match-separator','hostname-bin','hyperlink-format','max-columns') and val is None and i+1 < len(argv) and not argv[i+1].startswith('-'):
                    i+=1
            else:
                pass
            i+=1; continue
        # short options, possibly grouped
        j=1
        while j < len(a):
            c=a[j]
            rest=a[j+1:]
            if c in 'efgABCmMdtTrEjq':
                if rest: v=rest; j=len(a)
                else: v,i=need_arg(argv,i,'-'+c); j=len(a)
                if c=='e': o.patterns.append(v)
                elif c=='f': o.pattern_files.append(v)
                elif c=='g': o.globs.append(v)
                elif c=='A': o.after=parse_num(v)
                elif c=='B': o.before=parse_num(v)
                elif c=='C': o.before=o.after=parse_num(v)
                elif c=='m': o.max_count=parse_num(v)
                elif c=='M': pass
                elif c=='d': o.max_depth=parse_num(v)
                elif c=='t': o.types.append(v)
                elif c=='T': o.type_nots.append(v)
                elif c=='r': o.replace=v
                elif c=='E': pass
                elif c=='j': pass
                elif c=='q': o.quiet=True
                break
            elif c=='h': print(SHORT_HELP, end=''); sys.exit(0)
            elif c=='V': print(VERSION); sys.exit(0)
            elif c=='F': o.fixed=True
            elif c=='i': o.ignore_case=True
            elif c=='S': o.smart_case=True
            elif c=='s': o.ignore_case=False; o.smart_case=False
            elif c=='v': o.invert=True
            elif c=='w': o.word=True
            elif c=='x': o.line=True
            elif c=='n': o.line_number=True
            elif c=='N': o.no_line_number=True
            elif c=='H': o.with_filename=True
            elif c=='I': o.no_filename=True
            elif c=='o': o.only_matching=True
            elif c=='c': o.count=True
            elif c=='l': o.files_with_matches=True
            elif c=='.': o.hidden=True
            elif c=='u': o.unrestricted+=1
            elif c=='a': o.text=True
            elif c=='L': o.follow=True
            elif c=='0': o.null=True
            elif c=='p': o.line_number=True
            elif c=='b': pass
            elif c=='U': pass
            elif c=='P': pass
            j+=1
        i+=1
    if o.unrestricted>=1: o.no_ignore=True
    if o.unrestricted>=2: o.hidden=True
    if o.unrestricted>=3: o.text=True
    if not o.files and not o.type_list and not (o.patterns or o.pattern_files):
        if positionals: o.patterns.append(positionals.pop(0))
    o.paths=positionals
    return o

def load_patterns(o):
    pats=list(o.patterns)
    for pf in o.pattern_files:
        data = sys.stdin.read().splitlines() if pf=='-' else Path(pf).read_text(errors='replace').splitlines()
        pats.extend(data)
    return pats

def rel(path):
    s=os.path.relpath(path, os.getcwd())
    return s if s!='.' else './'

def is_hidden(path):
    return any(part.startswith('.') and part not in ('.','..') for part in Path(path).parts)

def has_git_root(start):
    p=Path(start).resolve()
    for q in [p]+list(p.parents):
        if (q/'.git').exists(): return True
    return False

def read_ignore_patterns(root):
    pats=[]
    for name in ('.ignore','.rgignore'):
        f=Path(root)/name
        if f.exists(): pats += [x.strip() for x in f.read_text(errors='replace').splitlines() if x.strip() and not x.startswith('#')]
    if has_git_root(root):
        f=Path(root)/'.gitignore'
        if f.exists(): pats += [x.strip() for x in f.read_text(errors='replace').splitlines() if x.strip() and not x.startswith('#')]
    return pats

def glob_match(pat, path, casefold=False):
    path=path.replace(os.sep,'/')
    base=os.path.basename(path)
    pat=pat.replace(os.sep,'/')
    if casefold: path=path.lower(); base=base.lower(); pat=pat.lower()
    if pat.endswith('/'):
        return path.startswith(pat[:-1]) or ('/'+pat[:-1]+'/') in ('/'+path+'/')
    return fnmatch.fnmatch(path, pat) or fnmatch.fnmatch(base, pat)

def should_ignore(path, o, ignore_pats):
    rp=rel(path).replace(os.sep,'/')
    if not o.hidden and is_hidden(rp): return True
    if not o.no_ignore:
        for pat in ignore_pats:
            neg=pat.startswith('!'); pp=pat[1:] if neg else pat
            if glob_match(pp, rp):
                if not neg: return True
    included=None
    for pat in o.globs:
        neg=pat.startswith('!'); pp=pat[1:] if neg else pat
        if glob_match(pp, rp): included = not neg
    for pat in o.iglob:
        neg=pat.startswith('!'); pp=pat[1:] if neg else pat
        if glob_match(pp, rp, True): included = not neg
    if included is False: return True
    if o.globs or o.iglob:
        positive=any(not g.startswith('!') for g in o.globs+o.iglob)
        if positive and included is not True: return True
    if o.types:
        if not any(glob_match(g, rp) for t in o.types for g in TYPE_GLOBS.get(t, [f'*.{t}'])): return True
    if o.type_nots:
        if any(glob_match(g, rp) for t in o.type_nots for g in TYPE_GLOBS.get(t, [f'*.{t}'])): return True
    if o.max_filesize is not None:
        try:
            if os.path.getsize(path) > o.max_filesize: return True
        except OSError: return True
    return False

def is_binary_file(path):
    try:
        with open(path, 'rb') as f:
            return b'\0' in f.read(8192)
    except OSError:
        return False

def iter_files(paths, o):
    if not paths: paths=['.']
    out=[]; ignore=read_ignore_patterns(os.getcwd())
    def walk_dir(d, base_depth):
        try:
            entries=list(os.scandir(d))
        except OSError:
            return
        current_depth=len(Path(d).resolve().parts)-len(base_depth)
        dirs=[e for e in entries if e.is_dir(follow_symlinks=o.follow)]
        files=[e for e in entries if e.is_file(follow_symlinks=o.follow)]
        for e in dirs:
            full=e.path
            if should_ignore(full,o,ignore): continue
            if o.max_depth is not None:
                depth=len(Path(full).resolve().parts)-len(base_depth)
                if depth >= o.max_depth: continue
            walk_dir(full, base_depth)
        if o.max_depth is not None and current_depth >= o.max_depth:
            return
        for e in files:
            full=e.path
            if not should_ignore(full,o,ignore) and (o.files or o.text or not is_binary_file(full)): out.append(full)
    for p in paths:
        if p=='-': out.append('-'); continue
        if os.path.isfile(p):
            if not should_ignore(p,o,ignore): out.append(p)
        elif os.path.isdir(p):
            walk_dir(p, Path(p).resolve().parts)
    if o.sort in ('path','modified','created','accessed') or o.sort is None:
        pass
    if o.sort:
        out.sort(reverse=o.reverse_sort)
    return out

def compile_regex(pats, o):
    flags=re.MULTILINE
    if o.ignore_case or (o.smart_case and not any(any(ch.isupper() for ch in p) for p in pats)):
        flags |= re.IGNORECASE
    parts=[]
    for p in pats:
        if o.fixed: p=re.escape(p)
        if o.word: p=r'\b(?:'+p+r')\b'
        if o.line: p=r'^(?:'+p+r')$'
        parts.append(p)
    try:
        return re.compile('|'.join(parts) if parts else r'(?!)', flags)
    except re.error as e:
        print(f"rg: regex parse error:\n    {pats[0] if pats else ''}\n    {'^'}\nerror: {e}", file=sys.stderr)
        sys.exit(2)

def rg_replacement_to_python(rep):
    rep = rep.replace('$$', '\0')
    rep = re.sub(r'\$(\d+)', r'\\g<\1>', rep)
    return rep.replace('\0', '$')

def read_lines(path, o):
    if path=='-':
        global STDIN_DATA
        data = STDIN_DATA if STDIN_DATA is not None else sys.stdin.buffer.read()
    else:
        try: data=Path(path).read_bytes()
        except OSError as e:
            print(f"rg: {path}: {e.strerror} (os error {e.errno})", file=sys.stderr); return None
    if not o.text and b'\0' in data: return []
    text=data.decode('utf-8', errors='replace')
    return text.splitlines(True)

def line_text(line, trim=False):
    s=line[:-1] if line.endswith('\n') else line
    if s.endswith('\r'): s=s[:-1]
    return s.lstrip() if trim else s

def format_prefix(path, lno, col, show_file, show_line, show_col, sep=':', ctx=False):
    parts=[]; fieldsep='-' if ctx else ':'
    if show_file: parts.append(path)
    if show_line: parts.append(str(lno))
    if show_col: parts.append(str(col))
    if not parts: return ''
    if ctx and len(parts)>0:
        return fieldsep.join(parts)+fieldsep
    return sep.join(parts)+sep

def render_match(path, lno, col, text, o, show_file, ctx=False):
    if o.vimgrep:
        return f"{path}:{lno}:{col}:{text}\n"
    return format_prefix(path,lno,col,show_file,o.line_number and not o.no_line_number,o.column,ctx=ctx)+text+'\n'

def search_file(path, regex, o, show_file):
    if path != '-' and not o.text:
        try:
            data = Path(path).read_bytes()
        except OSError as e:
            print(f"rg: {path}: {e.strerror} (os error {e.errno})", file=sys.stderr); return False,0,''
        nul = data.find(b'\0')
        if nul >= 0:
            txt = data.decode('utf-8', errors='replace')
            if regex.search(txt):
                pref = (path + ': ') if show_file else ''
                return True, 1, f'{pref}binary file matches (found "\\0" byte around offset {nul})\n'
            return False, 0, ''
    lines=read_lines(path,o)
    if lines is None: return False,0,''
    matches=[]; match_count=0
    for idx,line in enumerate(lines,1):
        txt=line_text(line,o.trim)
        ms=list(regex.finditer(txt))
        ok=bool(ms)
        if o.invert: ok=not ok; ms=[]
        if ok:
            match_count += (len(ms) if o.count_matches else 1)
            matches.append((idx,txt,ms))
            if o.max_count and len(matches)>=o.max_count: break
    if o.quiet: return bool(matches), match_count, ''
    if o.files_with_matches: return bool(matches), match_count, ((path+'\0') if o.null else (path+'\n')) if matches else ''
    if o.files_without_match: return bool(matches), match_count, ((path+'\0') if o.null else (path+'\n')) if not matches else ''
    if o.count or o.count_matches:
        if match_count or o.include_zero:
            pref=(path+':') if show_file else ''
            return bool(matches), match_count, f"{pref}{match_count}\n"
        return bool(matches), match_count, ''
    out=[]
    if o.json:
        for idx,txt,ms in matches:
            out.append(json.dumps({'type':'match','data':{'path':{'text':path},'lines':{'text':txt+'\n'},'line_number':idx}})+'\n')
        return bool(matches), match_count, ''.join(out)
    if o.passthru:
        selected=set(range(1,len(lines)+1))
    else:
        selected=set()
        for idx,_,_ in matches:
            for j in range(max(1,idx-o.before), min(len(lines),idx+o.after)+1): selected.add(j)
    match_map={idx:(txt,ms) for idx,txt,ms in matches}
    for idx in sorted(selected) if selected else [m[0] for m in matches]:
        if idx in match_map:
            txt,ms=match_map[idx]
            if o.only_matching and not o.invert:
                for m in ms:
                    val=m.group(0)
                    if o.replace is not None: val=m.expand(rg_replacement_to_python(o.replace))
                    out.append(render_match(path,idx,m.start()+1,val,o,show_file,False))
            else:
                val=txt
                if o.replace is not None and not o.invert: val=regex.sub(rg_replacement_to_python(o.replace), txt)
                out.append(render_match(path,idx,(ms[0].start()+1 if ms else 1),val,o,show_file,False))
        else:
            txt=line_text(lines[idx-1],o.trim)
            out.append(render_match(path,idx,1,txt,o,show_file,True))
    return bool(matches), match_count, ''.join(out)

def main(argv):
    global STDIN_DATA
    o=parse(argv)
    if o.type_list:
        for k in sorted(TYPE_GLOBS): print(f"{k}: {', '.join(TYPE_GLOBS[k])}")
        return 0
    files=iter_files(o.paths,o)
    if o.files:
        end='\0' if o.null else '\n'
        for f in files: sys.stdout.write(rel(f)+end)
        return 0 if files else 1
    pats=load_patterns(o)
    if not pats:
        print('rg: ripgrep requires at least one pattern to execute a search', file=sys.stderr); return 2
    regex=compile_regex(pats,o)
    if not o.paths and not sys.stdin.isatty():
        STDIN_DATA = sys.stdin.buffer.read()
        if STDIN_DATA:
            files=['-']
    display_files=[rel(f) if f!='-' else '' for f in files]
    show_file = (o.with_filename or len(files)>1 or any(os.path.isdir(p) for p in (o.paths or []))) and not o.no_filename
    any_match=False; any_success=False; total_out=[]; binary_out=[]
    for f,disp in zip(files,display_files):
        m,c,out=search_file(f if f=='-' else f, regex, o, show_file)
        any_match = any_match or m
        any_success = any_success or m or (o.files_without_match and bool(out))
        rendered = out.replace(f,disp,1) if f!='-' and disp!=f and out.startswith(f) else out
        if 'binary file matches' in rendered:
            binary_out.append(rendered)
        else:
            total_out.append(rendered)
    if not o.quiet: sys.stdout.write(''.join(total_out + binary_out))
    return 0 if any_success else 1

if __name__ == '__main__':
    sys.exit(main(sys.argv[1:]))
