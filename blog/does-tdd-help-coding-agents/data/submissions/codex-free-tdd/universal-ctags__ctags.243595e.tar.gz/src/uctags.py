#!/usr/bin/env python3
import json
import os
import re
import sys
from dataclasses import dataclass, field


VERSION = """Universal Ctags 6.2.0(d922013), Copyright (C) 2015-2025 Universal Ctags Team
Universal Ctags is derived from Exuberant Ctags.
Exuberant Ctags 5.8, Copyright (C) 1996-2009 Darren Hiebert
  Compiled: Apr 20 2026, 16:52:56
  URL: https://ctags.io/
  Output version: 1.1
  Optional compiled features: +wildcards, +regex, +iconv, +option-directory, +xpath, +json, +interactive, +sandbox, +yaml, +packcc, +optscript
"""

HELP = VERSION + """
Usage: executable [options] [file(s)]

Input/Output Options
  --filter[=(yes|no)]
       Behave as a filter, reading file names from standard input and
       writing tags to standard output [no].
  --recurse[=(yes|no)]
       Recurse into directories supplied on command line [no].
  -R   Equivalent to --recurse.
  -L <file>
       A list of input file names is read from the specified <file>.
  -f <tagfile>
       Write tags to specified <tagfile>. Value of "-" writes tags to stdout
       ["tags"; or "TAGS" when -e supplied].
  -o   Alternative for -f.

Output Format Options
  --output-format=(u-ctags|e-ctags|etags|xref|json)
      Specify the output format. [u-ctags]
  -x   Print a tabular cross reference file to standard output.
  --sort=(yes|no|foldcase)
       Should tags be sorted (optionally ignoring case) [yes]?
  -u   Equivalent to --sort=no.

Miscellaneous Options
  --help
       Print this option summary.
  --version[=<language>]
       Print version identifier of the program to standard output.
"""

LANGS = [
    "C", "C++", "C#", "Go", "HTML", "Java", "JavaScript", "JSON", "Lua",
    "Make", "Markdown", "PHP", "Python", "Ruby", "Rust", "Sh", "Tcl",
    "TypeScript", "Yaml",
]

KIND_NAMES = {
    "c": "class", "C": "constant", "d": "macro", "e": "enumerator",
    "f": "function", "g": "enum", "i": "module", "m": "member",
    "n": "namespace", "p": "prototype", "s": "struct", "t": "typedef",
    "u": "union", "v": "variable",
}


@dataclass
class Tag:
    name: str
    path: str
    line: str
    kind: str
    line_no: int
    fields: list[str] = field(default_factory=list)
    scope: str | None = None
    scope_kind: str | None = None

    def pattern(self) -> str:
        text = self.line.rstrip("\n").replace("\\", "\\\\").replace("/", "\\/")
        if self.kind == "d" and text.startswith("#define "):
            parts = text.split()
            if len(parts) >= 2:
                text = "#define " + parts[1] + " "
                return f"/^{text}/"
        return f"/^{text}$/"

    def uctags(self) -> str:
        cols = [self.name, self.path, self.pattern() + ';\"', self.kind]
        cols.extend(self.fields)
        return "\t".join(cols)

    def xref(self) -> str:
        return f"{self.name:<16} {KIND_NAMES.get(self.kind, self.kind):<12} {self.line_no} {self.path:<16} {self.line.rstrip()}"

    def as_json(self) -> str:
        obj = {
            "_type": "tag",
            "name": self.name,
            "path": self.path,
            "pattern": self.pattern(),
            "kind": KIND_NAMES.get(self.kind, self.kind),
        }
        if self.scope:
            obj["scope"] = self.scope
            obj["scopeKind"] = self.scope_kind or "class"
        return json.dumps(obj, ensure_ascii=False)


def language_for(path: str, forced: str | None = None) -> str | None:
    if forced and forced.lower() != "auto":
        return forced
    base = os.path.basename(path)
    ext = os.path.splitext(base)[1].lower()
    if ext in (".c", ".h"):
        return "C"
    if ext in (".cc", ".cpp", ".cxx", ".hpp", ".hh"):
        return "C++"
    if ext == ".py":
        return "Python"
    if ext in (".js", ".jsx", ".mjs", ".cjs"):
        return "JavaScript"
    if ext in (".ts", ".tsx"):
        return "TypeScript"
    if ext == ".java":
        return "Java"
    if ext == ".go":
        return "Go"
    if ext == ".rs":
        return "Rust"
    if ext == ".rb":
        return "Ruby"
    if ext in (".sh", ".bash", ".zsh"):
        return "Sh"
    if base == "Makefile" or ext in (".mk",):
        return "Make"
    return None


def parse_python(path: str, lines: list[str]) -> list[Tag]:
    tags: list[Tag] = []
    classes: list[tuple[int, str]] = []
    for i, line in enumerate(lines, 1):
        stripped = line.strip()
        if not stripped or stripped.startswith("#"):
            continue
        indent = len(line) - len(line.lstrip(" "))
        while classes and indent <= classes[-1][0] and not stripped.startswith("def "):
            classes.pop()
        m = re.match(r"\s*class\s+([A-Za-z_]\w*)", line)
        if m:
            name = m.group(1)
            tags.append(Tag(name, path, line, "c", i))
            classes.append((indent, name))
            continue
        m = re.match(r"\s*(?:async\s+def|def)\s+([A-Za-z_]\w*)\s*\(", line)
        if m:
            if classes and indent > classes[-1][0]:
                tags.append(Tag(m.group(1), path, line, "m", i, [f"class:{classes[-1][1]}"], classes[-1][1], "class"))
            else:
                tags.append(Tag(m.group(1), path, line, "f", i))
            continue
        m = re.match(r"\s*([A-Za-z_]\w*)\s*(?::[^=]+)?=", line)
        if m and not stripped.startswith(("if ", "while ", "for ")):
            if classes and indent > classes[-1][0]:
                tags.append(Tag(m.group(1), path, line, "v", i, [f"class:{classes[-1][1]}"], classes[-1][1], "class"))
            elif indent == 0:
                tags.append(Tag(m.group(1), path, line, "v", i))
    return tags


def parse_c(path: str, lines: list[str]) -> list[Tag]:
    tags: list[Tag] = []
    for i, line in enumerate(lines, 1):
        s = line.strip()
        if not s or s.startswith("//"):
            continue
        m = re.match(r"#\s*define\s+([A-Za-z_]\w*)", s)
        if m:
            tags.append(Tag(m.group(1), path, line, "d", i, ["file:"]))
        m = re.search(r"\benum\s+([A-Za-z_]\w*)\s*\{([^}]*)\}", line)
        if m:
            en = m.group(1)
            tags.append(Tag(en, path, line, "g", i, ["file:"]))
            for item in m.group(2).split(","):
                nm = re.match(r"\s*([A-Za-z_]\w*)", item)
                if nm:
                    tags.append(Tag(nm.group(1), path, line, "e", i, [f"enum:{en}", "file:"]))
        m = re.search(r"\btypedef\s+struct\s+([A-Za-z_]\w*)?\s*\{([^}]*)\}\s*([A-Za-z_]\w*)\s*;", line)
        if m:
            struct_name = m.group(1) or m.group(3)
            typedef_name = m.group(3)
            tags.append(Tag(struct_name, path, line, "s", i, ["file:"]))
            tags.append(Tag(typedef_name, path, line, "t", i, [f"typeref:struct:{struct_name}", "file:"]))
            for member in m.group(2).split(";"):
                mm = re.search(r"([A-Za-z_][\w\s\*]*?)\s+(\*?\s*[A-Za-z_]\w*)\s*$", member.strip())
                if mm:
                    typ = " ".join(mm.group(1).replace("*", " *").split())
                    name = mm.group(2).replace(" ", "").lstrip("*")
                    if "*" in mm.group(2) and not typ.endswith("*"):
                        typ += " *"
                    tags.append(Tag(name, path, line, "m", i, [f"struct:{struct_name}", f"typeref:typename:{typ}", "file:"]))
        fm = re.match(r"\s*(?:static\s+|extern\s+|inline\s+)?([A-Za-z_][\w\s\*]*?)\s+([A-Za-z_]\w*)\s*\([^;]*\)\s*\{", line)
        if fm:
            typ = " ".join(fm.group(1).split())
            fields = [f"typeref:typename:{typ}"]
            if "static" in line.split("(")[0].split():
                fields.append("file:")
            tags.append(Tag(fm.group(2), path, line, "f", i, fields))
            continue
        vm = re.match(r"\s*(?:static\s+)?([A-Za-z_][\w\s\*]*?)\s+([A-Za-z_]\w*)\s*(?:=.*)?;", line)
        if vm and "(" not in line:
            typ = " ".join(vm.group(1).split())
            fields = [f"typeref:typename:{typ}"]
            if s.startswith("static "):
                fields.append("file:")
            tags.append(Tag(vm.group(2), path, line, "v", i, fields))
    return tags


def parse_js(path: str, lines: list[str]) -> list[Tag]:
    tags: list[Tag] = []
    for i, line in enumerate(lines, 1):
        m = re.search(r"\bclass\s+([A-Za-z_$][\w$]*)", line)
        if m:
            cls = m.group(1)
            tags.append(Tag(cls, path, line, "c", i))
            for meth in re.finditer(r"\b([A-Za-z_$][\w$]*)\s*\([^)]*\)\s*\{", line):
                if meth.group(1) not in ("if", "for", "while", "switch", "function"):
                    tags.append(Tag(meth.group(1), path, line, "m", i, [f"class:{cls}"], cls, "class"))
        m = re.match(r"\s*function\s+([A-Za-z_$][\w$]*)\s*\(", line)
        if m:
            tags.append(Tag(m.group(1), path, line, "f", i))
        m = re.match(r"\s*(?:const|let|var)\s+([A-Za-z_$][\w$]*)\s*=\s*(?:async\s*)?(?:\([^)]*\)|[A-Za-z_$][\w$]*)\s*=>", line)
        if m:
            tags.append(Tag(m.group(1), path, line, "f", i))
            continue
        m = re.match(r"\s*const\s+([A-Za-z_$][\w$]*)\s*=", line)
        if m:
            tags.append(Tag(m.group(1), path, line, "C", i))
        elif (m := re.match(r"\s*(?:let|var)\s+([A-Za-z_$][\w$]*)\s*=", line)):
            tags.append(Tag(m.group(1), path, line, "v", i))
    return tags


def parse_generic(path: str, lines: list[str], lang: str) -> list[Tag]:
    tags: list[Tag] = []
    for i, line in enumerate(lines, 1):
        patterns = [
            (r"\s*(?:public|private|protected|static|\s)*class\s+([A-Za-z_]\w*)", "c"),
            (r"\s*(?:func|fn)\s+([A-Za-z_]\w*)\s*\(", "f"),
            (r"\s*def\s+([A-Za-z_]\w*)\s*(?:\(|$)", "f"),
            (r"\s*function\s+([A-Za-z_]\w*)\s*\(", "f"),
            (r"\s*(?:var|let|const)\s+([A-Za-z_]\w*)", "v"),
        ]
        for pat, kind in patterns:
            m = re.match(pat, line)
            if m:
                tags.append(Tag(m.group(1), path, line, kind, i))
                break
    return tags


def parse_file(path: str, forced_lang: str | None = None) -> list[Tag]:
    lang = language_for(path, forced_lang)
    try:
        with open(path, encoding="utf-8", errors="replace") as f:
            lines = f.readlines()
    except OSError as e:
        print(f'executable: Warning: cannot open input file "{path}" : {e.strerror}', file=sys.stderr)
        return []
    if lang == "Python":
        return parse_python(path, lines)
    if lang in ("C", "C++"):
        return parse_c(path, lines)
    if lang in ("JavaScript", "TypeScript"):
        return parse_js(path, lines)
    return parse_generic(path, lines, lang or "")


def collect_files(paths: list[str], recurse: bool) -> list[str]:
    out: list[str] = []
    for p in paths:
        if os.path.isdir(p):
            if recurse:
                for root, dirs, files in os.walk(p):
                    dirs[:] = [d for d in dirs if not d.startswith(".")]
                    for name in files:
                        if not name.startswith("."):
                            out.append(os.path.join(root, name))
            else:
                print(f'executable: Warning: "{p}" is not a regular file', file=sys.stderr)
        else:
            out.append(p)
    return out


def pseudo_header(tags: list[Tag]) -> str:
    langs = sorted({language_for(t.path) or "NONE" for t in tags})
    lines = [
        "!_TAG_FILE_FORMAT\t2\t/extended format; --format=1 will not append ;\" to lines/",
        "!_TAG_FILE_SORTED\t1\t/0=unsorted, 1=sorted, 2=foldcase/",
        "!_TAG_OUTPUT_MODE\tu-ctags\t/u-ctags or e-ctags/",
        "!_TAG_OUTPUT_VERSION\t1.1\t/current.age/",
        "!_TAG_PROGRAM_NAME\tUniversal Ctags\t/Derived from Exuberant Ctags/",
        "!_TAG_PROGRAM_URL\thttps://ctags.io/\t/official site/",
        "!_TAG_PROGRAM_VERSION\t6.2.0\t/d922013/",
    ]
    for lang in langs:
        lines.append(f"!_TAG_PARSER_VERSION!{lang}\t1.1\t/current.age/")
    return "\n".join(lines) + "\n"


def main(argv: list[str]) -> int:
    out_file = "tags"
    output = "u-ctags"
    recurse = False
    sort = True
    append = False
    filter_mode = False
    filter_terminator = None
    forced_lang = None
    print_lang = False
    files: list[str] = []
    i = 0
    while i < len(argv):
        a = argv[i]
        if a in ("--help", "-?"):
            print(HELP, end="")
            return 0
        if a.startswith("--version"):
            print(VERSION, end="")
            return 0
        if a == "--license":
            print("Universal Ctags is distributed under the GNU General Public License.")
            return 0
        if a == "--list-languages":
            print("\n".join(LANGS))
            return 0
        if a == "--list-features":
            print("#NAME             DESCRIPTION")
            for n in "iconv interactive json option-directory optscript packcc regex sandbox wildcards xpath yaml".split():
                print(f"{n:<17} supports {n}")
            return 0
        if a.startswith("--list-kinds"):
            lang = a.split("=", 1)[1] if "=" in a else "all"
            if lang.lower() == "python":
                print("c  classes\nf  functions\nm  class members\nv  variables")
            elif lang.lower() in ("javascript", "typescript"):
                print("C  constants\nc  classes\nf  functions\nm  methods\nv  variables")
            else:
                print("d  macro definitions\ne  enumerators (values inside an enumeration)\nf  function definitions\ng  enumeration names\nm  struct, and union members\ns  structure names\nt  typedefs\nv  variable definitions")
            return 0
        if a == "--list-output-formats":
            print("#OFORMAT DEFAULT AVAILABLE NULLTAG ")
            print("e-ctags       no       yes      no ")
            print("etags         no       yes      no ")
            print("json          no       yes     yes ")
            print("u-ctags      yes       yes      no ")
            print("xref          no       yes     yes ")
            return 0
        if a == "--print-language":
            print_lang = True
        elif a in ("-R", "--recurse", "--recurse=yes"):
            recurse = True
        elif a == "--recurse=no":
            recurse = False
        elif a in ("-x",):
            output = "xref"
            out_file = "-"
        elif a in ("-a", "--append", "--append=yes"):
            append = True
        elif a == "--append=no":
            append = False
        elif a.startswith("--output-format="):
            output = a.split("=", 1)[1]
        elif a in ("-f", "-o"):
            i += 1
            if i < len(argv):
                out_file = argv[i]
        elif a.startswith("-f") and len(a) > 2:
            out_file = a[2:]
        elif a in ("-u", "--sort=no"):
            sort = False
        elif a.startswith("--sort="):
            sort = a.split("=", 1)[1] != "no"
        elif a.startswith("--language-force="):
            forced_lang = a.split("=", 1)[1]
        elif a == "-L":
            i += 1
            listfile = argv[i]
            data = sys.stdin.read().splitlines() if listfile == "-" else open(listfile).read().splitlines()
            files.extend([x for x in data if x.strip()])
        elif a.startswith("--filter-terminator="):
            filter_terminator = a.split("=", 1)[1]
        elif a.startswith("--filter"):
            filter_mode = True
            out_file = "-"
            files.extend([x for x in sys.stdin.read().splitlines() if x.strip()])
        elif a.startswith("-"):
            pass
        else:
            files.append(a)
        i += 1

    if print_lang:
        for f in files:
            lang = language_for(f, forced_lang) or "NONE"
            print(f"{f}: {lang}")
        return 0
    if not files:
        print('executable: No files specified. Try "executable --help".', file=sys.stderr)
        return 1
    if filter_mode:
        for f in files:
            tags = []
            for path in collect_files([f], recurse):
                tags.extend(parse_file(path, forced_lang))
            if sort:
                tags.sort(key=lambda t: t.uctags())
            if output == "json":
                sys.stdout.write("".join(t.as_json() + "\n" for t in tags))
            elif output == "xref":
                sys.stdout.write("".join(t.xref() + "\n" for t in tags))
            else:
                sys.stdout.write("".join(t.uctags() + "\n" for t in tags))
            if filter_terminator is not None:
                sys.stdout.write(filter_terminator + "\n")
        return 0
    tags: list[Tag] = []
    for f in collect_files(files, recurse):
        tags.extend(parse_file(f, forced_lang))
    if sort:
        tags.sort(key=lambda t: t.uctags())
    if output == "json":
        text = "".join(t.as_json() + "\n" for t in tags)
    elif output == "xref":
        text = "".join(t.xref() + "\n" for t in tags)
    else:
        text = "".join(t.uctags() + "\n" for t in tags)
        if out_file != "-":
            text = pseudo_header(tags) + text
    if out_file == "-":
        sys.stdout.write(text)
    else:
        mode = "a" if append else "w"
        with open(out_file, mode, encoding="utf-8") as f:
            f.write(text)
    return 0


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
