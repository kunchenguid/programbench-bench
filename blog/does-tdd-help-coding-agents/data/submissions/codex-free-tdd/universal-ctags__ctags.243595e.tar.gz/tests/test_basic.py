import os
import subprocess
import tempfile
import textwrap
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
EXE = ROOT / "executable"

class CtagsBasicTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        subprocess.run(["bash", "compile.sh"], cwd=ROOT, check=True)

    def run_cmd(self, args, cwd=None, input_text=None):
        return subprocess.run([str(EXE)] + args, cwd=cwd or ROOT, input=input_text,
                              text=True, capture_output=True)

    def test_version_matches_universal_ctags_banner(self):
        res = self.run_cmd(["--version"])
        self.assertEqual(res.returncode, 0)
        self.assertIn("Universal Ctags 6.2.0(d922013)", res.stdout)
        self.assertIn("Optional compiled features: +wildcards", res.stdout)

    def test_generates_sorted_tags_for_c_python_and_javascript_stdout(self):
        with tempfile.TemporaryDirectory() as td:
            p = Path(td)
            (p / "sample.c").write_text(textwrap.dedent('''\
                #include <stdio.h>
                #define MAX 10
                int global = 1;
                typedef struct Person { int age; char *name; } Person;
                enum Color { RED, GREEN=2 };
                static int add(int a, int b) { return a+b; }
                int main(void) { return add(global, MAX); }
            '''))
            (p / "sample.py").write_text(textwrap.dedent('''\
                X = 3
                class Foo:
                    y = 2
                    def method(self, a):
                        pass
                def top(x, y=1):
                    return x+y
            '''))
            (p / "sample.js").write_text(textwrap.dedent('''\
                const x = 1;
                function foo(a) { return a; }
                class Bar { method() {} }
                const arrow = (b) => b;
            '''))
            res = self.run_cmd(["-f", "-", "sample.c", "sample.py", "sample.js"], cwd=p)
            self.assertEqual(res.returncode, 0, res.stderr)
            lines = res.stdout.strip().splitlines()
            self.assertIn('MAX\tsample.c\t/^#define MAX /;"\td\tfile:', lines)
            self.assertIn('Foo\tsample.py\t/^class Foo:$/;"\tc', lines)
            self.assertIn('method\tsample.py\t/^    def method(self, a):$/;"\tm\tclass:Foo', lines)
            self.assertIn('arrow\tsample.js\t/^const arrow = (b) => b;$/;"\tf', lines)
            self.assertEqual(lines, sorted(lines))

    def test_json_output_for_python_scope(self):
        with tempfile.TemporaryDirectory() as td:
            p = Path(td)
            (p / "m.py").write_text("class Foo:\n    def method(self):\n        pass\n")
            res = self.run_cmd(["--output-format=json", "-f", "-", "m.py"], cwd=p)
            self.assertEqual(res.returncode, 0, res.stderr)
            self.assertIn('"name": "Foo"', res.stdout)
            self.assertIn('"kind": "class"', res.stdout)
            self.assertIn('"name": "method"', res.stdout)
            self.assertIn('"scope": "Foo"', res.stdout)

    def test_file_list_recurse_xref_and_diagnostics(self):
        with tempfile.TemporaryDirectory() as td:
            p = Path(td)
            (p / "pkg").mkdir()
            (p / "pkg" / "a.py").write_text("def alpha():\n    pass\n")
            (p / "pkg" / "b.js").write_text("function beta() { return 1; }\n")
            (p / "files.txt").write_text("pkg/a.py\n")

            res = self.run_cmd([], cwd=p)
            self.assertEqual(res.returncode, 1)
            self.assertIn('executable: No files specified. Try "executable --help".', res.stderr)

            res = self.run_cmd(["--print-language", "pkg/a.py", "pkg/b.js"], cwd=p)
            self.assertEqual(res.stdout, "pkg/a.py: Python\npkg/b.js: JavaScript\n")

            res = self.run_cmd(["-L", "files.txt", "-f", "-"], cwd=p)
            self.assertEqual(res.stdout, 'alpha\tpkg/a.py\t/^def alpha():$/;"\tf\n')

            res = self.run_cmd(["-R", "-f", "-", "pkg"], cwd=p)
            self.assertIn('alpha\tpkg/a.py\t/^def alpha():$/;"\tf', res.stdout)
            self.assertIn('beta\tpkg/b.js\t/^function beta() { return 1; }$/;"\tf', res.stdout)

            res = self.run_cmd(["-x", "pkg/a.py"], cwd=p)
            self.assertIn("alpha            function     1 pkg/a.py", res.stdout)

            res = self.run_cmd(["pkg/a.py"], cwd=p)
            self.assertEqual(res.returncode, 0)
            tags = (p / "tags").read_text()
            self.assertIn("!_TAG_FILE_FORMAT\t2", tags)
            self.assertIn('alpha\tpkg/a.py\t/^def alpha():$/;"\tf', tags)

    def test_append_sort_no_and_filter_terminator(self):
        with tempfile.TemporaryDirectory() as td:
            p = Path(td)
            (p / "one.py").write_text("def zed():\n    pass\n")
            (p / "two.py").write_text("def alpha():\n    pass\n")

            res = self.run_cmd(["--sort=no", "-f", "-", "one.py", "two.py"], cwd=p)
            self.assertEqual(res.stdout.splitlines()[0], 'zed\tone.py\t/^def zed():$/;"\tf')

            (p / "tags").write_text("existing\n")
            res = self.run_cmd(["-a", "one.py"], cwd=p)
            self.assertEqual(res.returncode, 0, res.stderr)
            self.assertTrue((p / "tags").read_text().startswith("existing\n"))
            self.assertIn('zed\tone.py\t/^def zed():$/;"\tf', (p / "tags").read_text())

            res = self.run_cmd(["--filter", "--filter-terminator=--END--"], cwd=p, input_text="one.py\ntwo.py\n")
            self.assertEqual(res.returncode, 0, res.stderr)
            self.assertIn('zed\tone.py\t/^def zed():$/;"\tf\n--END--\n', res.stdout)
            self.assertIn('alpha\ttwo.py\t/^def alpha():$/;"\tf\n--END--\n', res.stdout)

if __name__ == "__main__":
    unittest.main()
