#!/usr/bin/env python3
import hashlib
import itertools
import os
import struct
import sys
import time
import zipfile


HELP = """Find the password of protected ZIP files

Usage: executable [OPTIONS] --inputFile <inputFile>

Options:
  -i, --inputFile <inputFile>                    path to zip input file
  -w, --workers <workers>                        number of workers
  -p, --passwordDictionary <passwordDictionary>  path to a password dictionary file
  -c, --charset <charset>                        charset to use to generate password [default: lud]
      --charsetFile <charsetFile>                path to a charset file
      --minPasswordLen <minPasswordLen>          minimum password length [default: 1]
      --maxPasswordLen <maxPasswordLen>          maximum password length [default: 10]
      --fileNumber <fileNumber>                  file number in the zip archive [default: 0]
  -s, --startingPassword <startingPassword>      password to start from
  -h, --help                                     Print help
  -V, --version                                  Print version
"""

CHARSETS = {
    "l": "abcdefghijklmnopqrstuvwxyz",
    "u": "ABCDEFGHIJKLMNOPQRSTUVWXYZ",
    "d": "0123456789",
    "h": "0123456789abcdef",
    "H": "0123456789ABCDEF",
    "s": " !\"#$%&'()*+,-./:;<=>?@[\\]^_`{|}~",
}


def main(argv=None):
    argv = list(sys.argv[1:] if argv is None else argv)
    if "-h" in argv or "--help" in argv:
        print(HELP, end="")
        return 0
    if "-V" in argv or "--version" in argv:
        print("zip-password-finder 0.10.3")
        return 0

    try:
        opts = parse_args(argv)
        validate_args(opts)
    except ValueError as exc:
        print(f'CLI argument error - "{exc}"')
        return 1

    start = time.monotonic()
    try:
        found = find_password(opts)
    except IndexError:
        print(f"File number not found within archive error - '{opts['fileNumber']}'")
        return 1
    except (zipfile.BadZipFile, OSError) as exc:
        print(f"Zip archive error - '{exc}'")
        return 1

    print(f"Time elapsed: {format_elapsed(time.monotonic() - start)}")
    if found is None:
        print("Password not found")
    else:
        print(f"Password found:{found}")
    return 0


def parse_args(argv):
    opts = {
        "inputFile": None,
        "workers": None,
        "passwordDictionary": None,
        "charset": "lud",
        "charsetFile": None,
        "minPasswordLen": 1,
        "maxPasswordLen": 10,
        "fileNumber": 0,
        "startingPassword": None,
    }
    needs_value = {
        "-i": "inputFile",
        "--inputFile": "inputFile",
        "-w": "workers",
        "--workers": "workers",
        "-p": "passwordDictionary",
        "--passwordDictionary": "passwordDictionary",
        "-c": "charset",
        "--charset": "charset",
        "--charsetFile": "charsetFile",
        "--minPasswordLen": "minPasswordLen",
        "--maxPasswordLen": "maxPasswordLen",
        "--fileNumber": "fileNumber",
        "-s": "startingPassword",
        "--startingPassword": "startingPassword",
    }
    int_fields = {"workers", "minPasswordLen", "maxPasswordLen", "fileNumber"}
    i = 0
    while i < len(argv):
        arg = argv[i]
        if arg not in needs_value:
            raise ValueError(f"unexpected argument '{arg}'")
        if i + 1 >= len(argv):
            raise ValueError(f"a value is required for '{arg}'")
        key = needs_value[arg]
        value = argv[i + 1]
        if key in int_fields:
            try:
                value = int(value)
            except ValueError:
                raise ValueError(f"invalid digit found in string")
        opts[key] = value
        i += 2
    return opts


def validate_args(opts):
    if not opts["inputFile"]:
        print("error: the following required arguments were not provided:")
        print("  --inputFile <inputFile>")
        print()
        print("Usage: executable --inputFile <inputFile>")
        print()
        print("For more information, try '--help'.")
        raise SystemExit(2)
    if not os.path.exists(opts["inputFile"]):
        raise ValueError("'inputFile' does not exist")
    if opts["passwordDictionary"] and not os.path.exists(opts["passwordDictionary"]):
        raise ValueError("'passwordDictionary' does not exist")
    if opts["startingPassword"] and opts["passwordDictionary"]:
        raise ValueError("'startingPassword' cannot be used with a dictionary file")
    if opts["minPasswordLen"] <= 0:
        raise ValueError("'minPasswordLen' must be positive")
    if opts["maxPasswordLen"] < opts["minPasswordLen"]:
        raise ValueError("'maxPasswordLen' must be equal or greater than 'minPasswordLen'")
    if opts["charsetFile"] and not os.path.exists(opts["charsetFile"]):
        raise ValueError("'charsetFile' does not exist")
    if not opts["charsetFile"]:
        for ch in opts["charset"]:
            if ch not in CHARSETS:
                raise ValueError(f"Unknown charset option '{ch}'")


def find_password(opts):
    for candidate in candidates(opts):
        if password_matches_zip(opts["inputFile"], opts["fileNumber"], candidate):
            return candidate
    return None


def candidates(opts):
    if opts["passwordDictionary"]:
        with open(opts["passwordDictionary"], "r", encoding="utf-8", errors="ignore") as f:
            for line in f:
                yield line.rstrip("\r\n")
        return

    chars = load_charset(opts)
    start = opts["startingPassword"]
    for length in range(opts["minPasswordLen"], opts["maxPasswordLen"] + 1):
        skipping = bool(start and len(start) == length)
        for item in itertools.product(chars, repeat=length):
            password = "".join(item)
            if skipping:
                if password == start:
                    skipping = False
                else:
                    continue
            yield password


def load_charset(opts):
    if opts["charsetFile"]:
        with open(opts["charsetFile"], "r", encoding="utf-8", errors="ignore") as f:
            return f.read().rstrip("\r\n")
    out = []
    for key in opts["charset"]:
        for ch in CHARSETS[key]:
            if ch not in out:
                out.append(ch)
    return "".join(out)


def password_matches_zip(path, file_number, password):
    with zipfile.ZipFile(path) as zf:
        infos = zf.infolist()
        if file_number < 0 or file_number >= len(infos):
            raise IndexError(file_number)
        info = infos[file_number]
        if info.compress_type == 99 or has_aes_extra(info.extra):
            return aes_password_verifier_matches(path, info, password)
        if not (info.flag_bits & 1):
            return False
        try:
            with zf.open(info, "r", pwd=password.encode("utf-8")) as f:
                while f.read(65536):
                    pass
            return True
        except Exception:
            return False


def has_aes_extra(extra):
    return find_extra(extra, 0x9901) is not None


def find_extra(extra, header_id):
    pos = 0
    while pos + 4 <= len(extra):
        hid, size = struct.unpack_from("<HH", extra, pos)
        pos += 4
        data = extra[pos : pos + size]
        if hid == header_id:
            return data
        pos += size
    return None


def aes_password_verifier_matches(path, info, password):
    aes = find_extra(info.extra, 0x9901)
    if not aes or len(aes) < 7:
        return False
    strength = aes[4]
    salt_len_by_strength = {1: 8, 2: 12, 3: 16}
    key_len_by_strength = {1: 16, 2: 24, 3: 32}
    salt_len = salt_len_by_strength.get(strength)
    key_len = key_len_by_strength.get(strength)
    if not salt_len:
        return False
    with open(path, "rb") as f:
        f.seek(info.header_offset)
        header = f.read(30)
        if len(header) != 30 or header[:4] != b"PK\x03\x04":
            return False
        name_len, extra_len = struct.unpack_from("<HH", header, 26)
        f.seek(name_len + extra_len, os.SEEK_CUR)
        salt = f.read(salt_len)
        verifier = f.read(2)
    if len(salt) != salt_len or len(verifier) != 2:
        return False
    derived = hashlib.pbkdf2_hmac("sha1", password.encode("utf-8"), salt, 1000, 2 * key_len + 2)
    return derived[-2:] == verifier


def format_elapsed(seconds):
    total_ns = int(seconds * 1_000_000_000)
    ms, rem = divmod(total_ns, 1_000_000)
    us, ns = divmod(rem, 1_000)
    if ms >= 1000:
        s, ms = divmod(ms, 1000)
        return f"{s}s {ms}ms {us}us {ns}ns"
    return f"{ms}ms {us}us {ns}ns"


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except SystemExit as exc:
        raise
