package main

import (
	"flag"
	"fmt"
	"io/fs"
	"os"
	"path/filepath"
	"strings"

	"gotests-reimpl/generator"
)

func main() {
	var opts generator.Options
	var version bool
	flag.BoolVar(&opts.All, "all", false, "generate tests for all functions and methods")
	flag.StringVar(&opts.Exclude, "excl", "", "regexp. generate tests for functions and methods that don't match. Takes precedence over -only, -exported, and -all")
	flag.BoolVar(&opts.Exported, "exported", false, "generate tests for exported functions and methods. Takes precedence over -only and -all")
	flag.BoolVar(&opts.PrintInputs, "i", false, "print test inputs in error messages")
	flag.BoolVar(&opts.Named, "named", false, "switch table tests from using slice to map (with test name for the key)")
	flag.StringVar(&opts.Only, "only", "", "regexp. generate tests for functions and methods that match only. Takes precedence over -all")
	flag.BoolVar(&opts.NoSubtests, "nosubtests", false, "disable generating tests using the Go 1.7 subtests feature")
	flag.BoolVar(&opts.Parallel, "parallel", false, "enable generating parallel subtests using the Go 1.7 feature")
	flag.StringVar(&opts.TemplateDir, "template_dir", os.Getenv("GOTESTS_TEMPLATE_DIR"), "optional. Path to a directory containing custom test code templates. Takes precedence over -template. This can also be set via environment variable GOTESTS_TEMPLATE_DIR")
	flag.StringVar(&opts.Template, "template", os.Getenv("GOTESTS_TEMPLATE"), "optional. Specify custom test code templates, e.g. testify. This can also be set via environment variable GOTESTS_TEMPLATE")
	flag.StringVar(&opts.TemplateData, "template_params_file", "", "read external parameters to template by json with file")
	flag.StringVar(&opts.TemplateData, "template_params", "", "read external parameters to template by json with stdin")
	flag.BoolVar(&opts.UseGoCmp, "use_go_cmp", false, "use cmp.Equal (google/go-cmp) instead of reflect.DeepEqual")
	flag.Bool("ai", false, "generate test cases using AI (requires Ollama)")
	flag.String("ai-model", "qwen2.5-coder:0.5b", "AI model to use for test generation")
	flag.String("ai-endpoint", "http://localhost:11434", "Ollama API endpoint")
	flag.Int("ai-min-cases", 3, "minimum number of test cases to generate with AI")
	flag.Int("ai-max-cases", 10, "maximum number of test cases to generate with AI")
	write := flag.Bool("w", false, "write output to (test) files instead of stdout")
	flag.BoolVar(&version, "version", false, "print version information and exit")
	flag.Parse()

	if version {
		fmt.Println("gotests v0.0.0-20260303205902-f3b63d74369a")
		fmt.Println("Go version: go1.24.5")
		fmt.Println("Git commit: f3b63d74369a8c405a9a3990a656a278a4f9096f")
		fmt.Println("Build time: 2026-03-03T20:59:02Z")
		return
	}
	if missingSelection(opts) {
		fmt.Println("Please specify either the -only, -excl, -exported, or -all flag")
		return
	}
	paths := expandPaths(flag.Args())
	if len(paths) == 0 {
		flag.Usage()
		os.Exit(1)
	}
	for _, path := range paths {
		if err := process(path, opts, *write); err != nil {
			fmt.Fprintln(os.Stderr, err)
			os.Exit(1)
		}
	}
}

func expandPaths(args []string) []string {
	var out []string
	for _, arg := range args {
		if strings.HasSuffix(arg, "/...") {
			root := strings.TrimSuffix(arg, "/...")
			filepath.WalkDir(root, func(path string, d fs.DirEntry, err error) error {
				if err == nil && !d.IsDir() && isSource(path) {
					out = append(out, path)
				}
				return nil
			})
			continue
		}
		info, err := os.Stat(arg)
		if err == nil && info.IsDir() {
			entries, _ := os.ReadDir(arg)
			for _, e := range entries {
				path := filepath.Join(arg, e.Name())
				if !e.IsDir() && isSource(path) {
					out = append(out, path)
				}
			}
			continue
		}
		matches, err := filepath.Glob(arg)
		if err == nil && len(matches) > 0 {
			for _, m := range matches {
				if isSource(m) {
					out = append(out, m)
				}
			}
		} else if isSource(arg) {
			out = append(out, arg)
		}
	}
	sortStrings(out)
	return out
}

func isSource(path string) bool {
	return strings.HasSuffix(path, ".go") && !strings.HasSuffix(path, "_test.go")
}

func process(path string, opts generator.Options, write bool) error {
	data, err := os.ReadFile(path)
	if err != nil {
		return err
	}
	out, logs, err := generator.Generate(path, string(data), opts)
	if err != nil {
		return err
	}
	if out == "" && logs == "" {
		fmt.Printf("No tests generated for %s\n", path)
		return nil
	}
	fmt.Print(logs)
	if write {
		testPath := strings.TrimSuffix(path, ".go") + "_test.go"
		return os.WriteFile(testPath, []byte(out), 0644)
	}
	fmt.Print(out)
	return nil
}

func missingSelection(opts generator.Options) bool {
	return !opts.All && !opts.Exported && opts.Only == "" && opts.Exclude == ""
}

func sortStrings(s []string) {
	for i := 0; i < len(s); i++ {
		for j := i + 1; j < len(s); j++ {
			if s[j] < s[i] {
				s[i], s[j] = s[j], s[i]
			}
		}
	}
}
