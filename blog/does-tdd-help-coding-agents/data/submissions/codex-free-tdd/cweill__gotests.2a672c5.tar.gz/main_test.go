package main

import (
	"testing"

	"gotests-reimpl/generator"
)

func TestMissingSelectionRequiresMessage(t *testing.T) {
	if !missingSelection(generator.Options{}) {
		t.Fatal("missingSelection(empty options) = false, want true")
	}
	if missingSelection(generator.Options{All: true}) {
		t.Fatal("missingSelection(All) = true, want false")
	}
	if missingSelection(generator.Options{Only: "Add"}) {
		t.Fatal("missingSelection(Only) = true, want false")
	}
	if missingSelection(generator.Options{Exclude: "helper"}) {
		t.Fatal("missingSelection(Exclude) = true, want false")
	}
	if missingSelection(generator.Options{Exported: true}) {
		t.Fatal("missingSelection(Exported) = true, want false")
	}
}
