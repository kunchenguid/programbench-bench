package generator

import (
	"bytes"
	"fmt"
	"go/ast"
	"go/format"
	"go/parser"
	"go/printer"
	"go/token"
	"path/filepath"
	"regexp"
	"sort"
	"strings"
	"unicode"
)

type Options struct {
	All          bool
	Exported     bool
	Only         string
	Exclude      string
	Named        bool
	NoSubtests   bool
	Parallel     bool
	PrintInputs  bool
	UseGoCmp     bool
	Template     string
	TemplateDir  string
	TemplateData string
}

type function struct {
	name       string
	testName   string
	callName   string
	params     []field
	results    []field
	receiver   *receiver
	typeArgs   []string
	typeMap    map[string]string
	hasErr     bool
	errIndex   int
	sourceName string
}

type receiver struct {
	varName      string
	typeName     string
	displayName  string
	construct    string
	fields       []field
	includeTable bool
}

type field struct {
	name string
	typ  string
}

type typeInfo struct {
	fields     []field
	typeParams map[string]string
}

func Generate(filename, src string, opts Options) (string, string, error) {
	fset := token.NewFileSet()
	file, err := parser.ParseFile(fset, filename, src, parser.ParseComments)
	if err != nil {
		return "", "", err
	}
	typeFields := collectTypeInfo(fset, file)

	var funcs []function
	for _, decl := range file.Decls {
		fn, ok := decl.(*ast.FuncDecl)
		if !ok || fn.Name == nil {
			continue
		}
		if !selected(fn.Name.Name, opts) {
			continue
		}
		typeMap := typeParamMap(fset, fn.Type.TypeParams)
		if fn.Recv != nil && len(fn.Recv.List) > 0 {
			for k, v := range receiverTypeMap(fset, fn.Recv.List[0], typeFields) {
				typeMap[k] = v
			}
		}
		f := function{
			name:       fn.Name.Name,
			callName:   fn.Name.Name,
			testName:   testNameForFunction(fn.Name.Name),
			typeMap:    typeMap,
			sourceName: fn.Name.Name,
		}
		f.typeArgs = typeArgsFromMap(fn.Type.TypeParams, f.typeMap)
		f.params = fieldsFromList(fset, fn.Type.Params, f.typeMap)
		f.results = resultFields(fset, fn.Type.Results, f.typeMap)
		if fn.Recv != nil && len(fn.Recv.List) > 0 {
			r := buildReceiver(fset, fn.Recv.List[0], f.typeMap, typeFields)
			f.receiver = &r
			f.testName = "Test" + r.typeName + "_" + fn.Name.Name
			f.callName = r.varName + "." + fn.Name.Name
		}
		for i, r := range f.results {
			if r.typ == "error" {
				f.hasErr = true
				f.errIndex = i
				break
			}
		}
		funcs = append(funcs, f)
	}
	if len(funcs) == 0 {
		return "", "", nil
	}
	sourceImports := referencedImports(file, funcs)
	var out strings.Builder
	fmt.Fprintf(&out, "package %s\n\n", file.Name.Name)
	imports := importsFor(funcs, opts, sourceImports)
	writeImports(&out, imports)
	for i, fn := range funcs {
		if i > 0 {
			out.WriteString("\n")
		}
		out.WriteString(renderFunction(fn, opts))
	}
	formatted, err := format.Source([]byte(out.String()))
	if err != nil {
		return out.String(), "", nil
	}
	var logs strings.Builder
	for _, fn := range funcs {
		fmt.Fprintf(&logs, "Generated %s\n", fn.testName)
	}
	return string(formatted), logs.String(), nil
}

func selected(name string, opts Options) bool {
	if opts.Exclude != "" {
		re, err := regexp.Compile(opts.Exclude)
		return err == nil && !re.MatchString(name)
	}
	if opts.Exported {
		return ast.IsExported(name)
	}
	if opts.Only != "" {
		re, err := regexp.Compile(opts.Only)
		return err == nil && re.MatchString(name)
	}
	return opts.All
}

func testNameForFunction(name string) string {
	if ast.IsExported(name) {
		return "Test" + name
	}
	return "Test_" + name
}

func collectTypeInfo(fset *token.FileSet, file *ast.File) map[string]typeInfo {
	types := map[string]typeInfo{}
	for _, decl := range file.Decls {
		gen, ok := decl.(*ast.GenDecl)
		if !ok || gen.Tok != token.TYPE {
			continue
		}
		for _, spec := range gen.Specs {
			ts, ok := spec.(*ast.TypeSpec)
			if !ok {
				continue
			}
			st, ok := ts.Type.(*ast.StructType)
			if !ok {
				continue
			}
			subst := typeParamMap(fset, ts.TypeParams)
			types[ts.Name.Name] = typeInfo{
				fields:     fieldsFromList(fset, st.Fields, subst),
				typeParams: subst,
			}
		}
	}
	return types
}

func receiverTypeMap(fset *token.FileSet, item *ast.Field, types map[string]typeInfo) map[string]string {
	rawType := exprString(fset, item.Type)
	typeName := strings.TrimPrefix(rawType, "*")
	if idx := strings.Index(typeName, "["); idx >= 0 {
		typeName = typeName[:idx]
	}
	out := map[string]string{}
	for k, v := range types[typeName].typeParams {
		out[k] = v
	}
	return out
}

func typeParamMap(fset *token.FileSet, list *ast.FieldList) map[string]string {
	m := map[string]string{}
	if list == nil {
		return m
	}
	for _, item := range list.List {
		concrete := concreteType(exprString(fset, item.Type))
		for _, name := range item.Names {
			m[name.Name] = concrete
		}
	}
	return m
}

func typeArgsFromMap(list *ast.FieldList, m map[string]string) []string {
	var args []string
	if list == nil {
		return args
	}
	for _, item := range list.List {
		for _, name := range item.Names {
			args = append(args, m[name.Name])
		}
	}
	return args
}

func concreteType(constraint string) string {
	constraint = strings.TrimSpace(constraint)
	constraint = strings.TrimPrefix(constraint, "~")
	if strings.Contains(constraint, "|") {
		constraint = strings.TrimSpace(strings.Split(constraint, "|")[0])
		constraint = strings.TrimPrefix(constraint, "~")
	}
	switch constraint {
	case "comparable":
		return "string"
	case "any", "interface{}":
		return "int"
	default:
		return constraint
	}
}

func fieldsFromList(fset *token.FileSet, list *ast.FieldList, subst map[string]string) []field {
	var out []field
	if list == nil {
		return out
	}
	for _, item := range list.List {
		typ := substituteType(exprString(fset, item.Type), subst)
		if len(item.Names) == 0 {
			out = append(out, field{name: lowerTypeName(typ), typ: typ})
			continue
		}
		for _, name := range item.Names {
			out = append(out, field{name: name.Name, typ: typ})
		}
	}
	return out
}

func resultFields(fset *token.FileSet, list *ast.FieldList, subst map[string]string) []field {
	raw := fieldsFromList(fset, list, subst)
	for i := range raw {
		if raw[i].name == "" || raw[i].name == lowerTypeName(raw[i].typ) {
			if i == 0 {
				raw[i].name = "want"
			} else {
				raw[i].name = fmt.Sprintf("want%d", i)
			}
		}
	}
	return raw
}

func buildReceiver(fset *token.FileSet, item *ast.Field, subst map[string]string, structs map[string]typeInfo) receiver {
	rawType := substituteType(exprString(fset, item.Type), subst)
	display := strings.TrimPrefix(rawType, "*")
	typeName := display
	if idx := strings.Index(typeName, "["); idx >= 0 {
		typeName = typeName[:idx]
	}
	varName := lowerTypeName(typeName)
	if len(item.Names) > 0 && item.Names[0].Name != "_" {
		varName = item.Names[0].Name
	}
	r := receiver{varName: varName, typeName: typeName, displayName: display, construct: rawType}
	r.fields = structs[typeName].fields
	if len(r.fields) > 0 && !strings.Contains(display, "[") {
		r.includeTable = true
	}
	return r
}

func substituteType(typ string, subst map[string]string) string {
	if len(subst) == 0 {
		return typ
	}
	for k, v := range subst {
		typ = regexp.MustCompile(`\b`+regexp.QuoteMeta(k)+`\b`).ReplaceAllString(typ, v)
	}
	return typ
}

func exprString(fset *token.FileSet, expr ast.Expr) string {
	var b bytes.Buffer
	_ = printer.Fprint(&b, fset, expr)
	return b.String()
}

func referencedImports(file *ast.File, funcs []function) []string {
	byName := map[string]string{}
	for _, imp := range file.Imports {
		path := strings.Trim(imp.Path.Value, "\"")
		name := filepath.Base(path)
		if imp.Name != nil && imp.Name.Name != "_" && imp.Name.Name != "." {
			name = imp.Name.Name
		}
		byName[name] = path
	}
	used := map[string]bool{}
	for _, fn := range funcs {
		for _, f := range append(append([]field{}, fn.params...), fn.results...) {
			for name, path := range byName {
				if regexp.MustCompile(`\b`+regexp.QuoteMeta(name)+`\.`).MatchString(f.typ) {
					used[path] = true
				}
			}
		}
		if fn.receiver != nil {
			for _, f := range fn.receiver.fields {
				for name, path := range byName {
					if regexp.MustCompile(`\b`+regexp.QuoteMeta(name)+`\.`).MatchString(f.typ) {
						used[path] = true
					}
				}
			}
		}
	}
	var out []string
	for path := range used {
		out = append(out, path)
	}
	return out
}

func importsFor(funcs []function, opts Options, extra []string) []string {
	needReflect := false
	for _, fn := range funcs {
		for _, r := range fn.results {
			if r.typ != "error" && needsDeepEqual(r.typ) {
				needReflect = true
			}
		}
	}
	importSet := map[string]bool{"testing": true}
	for _, imp := range extra {
		importSet[imp] = true
	}
	if needReflect {
		if opts.UseGoCmp {
			importSet["github.com/google/go-cmp/cmp"] = true
		} else {
			importSet["reflect"] = true
		}
	}
	var imports []string
	for imp := range importSet {
		imports = append(imports, imp)
	}
	sort.Strings(imports)
	return imports
}

func writeImports(out *strings.Builder, imports []string) {
	if len(imports) == 1 {
		fmt.Fprintf(out, "import %q\n\n", imports[0])
		return
	}
	out.WriteString("import (\n")
	for _, imp := range imports {
		fmt.Fprintf(out, "\t%q\n", imp)
	}
	out.WriteString(")\n\n")
}

func renderFunction(fn function, opts Options) string {
	var b strings.Builder
	fmt.Fprintf(&b, "func %s(t *testing.T) {\n", fn.testName)
	if opts.Parallel {
		b.WriteString("\tt.Parallel()\n")
	}
	if fn.receiver != nil && fn.receiver.includeTable {
		b.WriteString("\ttype fields struct {\n")
		for _, f := range fn.receiver.fields {
			fmt.Fprintf(&b, "\t\t%s %s\n", f.name, f.typ)
		}
		b.WriteString("\t}\n")
	}
	if len(fn.params) > 0 {
		b.WriteString("\ttype args struct {\n")
		for _, p := range fn.params {
			fmt.Fprintf(&b, "\t\t%s %s\n", p.name, p.typ)
		}
		b.WriteString("\t}\n")
	}
	writeTestsStruct(&b, fn, opts)
	writeLoop(&b, fn, opts)
	b.WriteString("}\n")
	return b.String()
}

func writeTestsStruct(b *strings.Builder, fn function, opts Options) {
	if opts.Named {
		b.WriteString("\ttests := map[string]struct {\n")
	} else {
		b.WriteString("\ttests := []struct {\n\t\tname string\n")
	}
	if fn.receiver != nil {
		if fn.receiver.includeTable {
			b.WriteString("\t\tfields fields\n")
		} else if strings.Contains(fn.receiver.displayName, "[") {
			fmt.Fprintf(b, "\t\t%s %s\n", fn.receiver.varName, fn.receiver.construct)
		}
	}
	if len(fn.params) > 0 {
		b.WriteString("\t\targs args\n")
	}
	for i, r := range fn.results {
		if r.typ == "error" {
			b.WriteString("\t\twantErr bool\n")
			continue
		}
		name := "want"
		if i > 0 {
			name = fmt.Sprintf("want%d", i)
		}
		fmt.Fprintf(b, "\t\t%s %s\n", name, r.typ)
	}
	b.WriteString("\t}{\n\t\t// TODO: Add test cases.\n\t}\n")
}

func writeLoop(b *strings.Builder, fn function, opts Options) {
	if opts.Named {
		b.WriteString("\tfor name, tt := range tests {\n")
	} else if opts.NoSubtests && len(fn.params) == 0 && len(fn.results) == 0 && fn.receiver == nil {
		b.WriteString("\tfor range tests {\n")
	} else {
		b.WriteString("\tfor _, tt := range tests {\n")
	}
	if opts.NoSubtests {
		writeBody(b, fn, opts, "\t\t")
		b.WriteString("\t}\n")
		return
	}
	runName := "tt.name"
	if opts.Named {
		runName = "name"
	}
	fmt.Fprintf(b, "\t\tt.Run(%s, func(t *testing.T) {\n", runName)
	if opts.Parallel {
		b.WriteString("\t\t\tt.Parallel()\n")
	}
	writeBody(b, fn, opts, "\t\t\t")
	b.WriteString("\t\t})\n\t}\n")
}

func writeBody(b *strings.Builder, fn function, opts Options, ind string) {
	if fn.receiver != nil {
		if fn.receiver.includeTable {
			prefix := "&"
			if !strings.HasPrefix(fn.receiver.construct, "*") {
				prefix = ""
			}
			fmt.Fprintf(b, "%s%s := %s%s{\n", ind, fn.receiver.varName, prefix, fn.receiver.displayName)
			for _, f := range fn.receiver.fields {
				fmt.Fprintf(b, "%s\t%s: tt.fields.%s,\n", ind, f.name, f.name)
			}
			fmt.Fprintf(b, "%s}\n", ind)
		} else if strings.Contains(fn.receiver.displayName, "[") {
			prefix := "&"
			if !strings.HasPrefix(fn.receiver.construct, "*") {
				prefix = ""
			}
			fmt.Fprintf(b, "%s%s := %s%s{}\n", ind, fn.receiver.varName, prefix, fn.receiver.displayName)
		}
	}
	call := callExpr(fn)
	nonErrResults := nonErrorResults(fn)
	if len(fn.results) == 0 {
		fmt.Fprintf(b, "%s%s\n", ind, call)
		return
	}
	if len(fn.results) == 1 && !fn.hasErr {
		r := nonErrResults[0]
		cmp := compareExpr("got", "tt.want", r.typ, opts)
		fmt.Fprintf(b, "%sif got := %s; %s {\n", ind, call, cmp)
		fmt.Fprintf(b, "%s\tt.Errorf(%q, %s)\n", ind, errorMessage(fn, "", opts), errorArgs(fn, []string{"got", "tt.want"}, opts))
		fmt.Fprintf(b, "%s}\n", ind)
		return
	}
	assigns := resultAssigns(fn)
	fmt.Fprintf(b, "%s%s := %s\n", ind, strings.Join(assigns, ", "), call)
	if fn.hasErr {
		fail := "Fatalf"
		after := ""
		if opts.NoSubtests {
			fail = "Errorf"
			after = "continue"
		}
		fmt.Fprintf(b, "%sif (err != nil) != tt.wantErr {\n", ind)
		fmt.Fprintf(b, "%s\tt.%s(%q, %s)\n", ind, fail, errorMessage(fn, " error", opts), errorArgs(fn, []string{"err", "tt.wantErr"}, opts))
		if after != "" {
			fmt.Fprintf(b, "%s\t%s\n", ind, after)
		}
		fmt.Fprintf(b, "%s}\n", ind)
		fmt.Fprintf(b, "%sif tt.wantErr {\n%s\treturn\n%s}\n", ind, ind, ind)
	}
	for i, r := range nonErrResults {
		got := "got"
		want := "tt.want"
		if i > 0 {
			got = fmt.Sprintf("got%d", i)
			want = fmt.Sprintf("tt.want%d", i)
		}
		cmp := compareExpr(got, want, r.typ, opts)
		fmt.Fprintf(b, "%sif %s {\n", ind, cmp)
		label := ""
		if len(nonErrResults) > 1 {
			label = " " + got
		}
		fmt.Fprintf(b, "%s\tt.Errorf(%q, %s)\n", ind, errorMessage(fn, label, opts), errorArgs(fn, []string{got, want}, opts))
		fmt.Fprintf(b, "%s}\n", ind)
	}
}

func callExpr(fn function) string {
	name := fn.callName
	if fn.receiver == nil && len(fn.typeArgs) > 0 {
		name += "[" + strings.Join(fn.typeArgs, ", ") + "]"
	}
	var args []string
	for _, p := range fn.params {
		args = append(args, "tt.args."+p.name)
	}
	return fmt.Sprintf("%s(%s)", name, strings.Join(args, ", "))
}

func resultAssigns(fn function) []string {
	var out []string
	gotIndex := 0
	for _, r := range fn.results {
		if r.typ == "error" {
			out = append(out, "err")
		} else if gotIndex == 0 {
			out = append(out, "got")
			gotIndex++
		} else {
			out = append(out, fmt.Sprintf("got%d", gotIndex))
			gotIndex++
		}
	}
	return out
}

func nonErrorResults(fn function) []field {
	var out []field
	for _, r := range fn.results {
		if r.typ != "error" {
			out = append(out, r)
		}
	}
	return out
}

func compareExpr(got, want, typ string, opts Options) string {
	if needsDeepEqual(typ) {
		if opts.UseGoCmp {
			return fmt.Sprintf("!cmp.Equal(%s, %s)", got, want)
		}
		return fmt.Sprintf("!reflect.DeepEqual(%s, %s)", got, want)
	}
	return fmt.Sprintf("%s != %s", got, want)
}

func needsDeepEqual(typ string) bool {
	typ = strings.TrimSpace(typ)
	return strings.HasPrefix(typ, "[]") || strings.HasPrefix(typ, "map[") || strings.HasPrefix(typ, "[") || strings.HasPrefix(typ, "struct {") || strings.Contains(typ, ".")
}

func errorMessage(fn function, suffix string, opts Options) string {
	display := fn.name
	if fn.receiver != nil {
		display = fn.receiver.typeName + "." + fn.name
	}
	inputs := ""
	if opts.PrintInputs && len(fn.params) > 0 {
		inputs = strings.TrimPrefix(callExpr(function{name: fn.name, callName: display, params: fn.params}), display)
		inputs = strings.ReplaceAll(inputs, "tt.args.", "%v:")
		parts := strings.Split(strings.Trim(inputs, "()"), ", ")
		for i := range parts {
			parts[i] = "%v"
		}
		inputs = "(" + strings.Join(parts, ", ") + ")"
	} else {
		inputs = "()"
	}
	if suffix == " error" {
		msg := display + inputs + " error = %v, wantErr %v"
		if opts.NoSubtests {
			msg = "%q. " + msg
		}
		return msg
	}
	msg := display + inputs + suffix + " = %v, want %v"
	if opts.NoSubtests {
		msg = "%q. " + msg
	}
	return msg
}

func errorArgs(fn function, args []string, opts Options) string {
	var all []string
	if opts.NoSubtests {
		all = append(all, "tt.name")
	}
	if opts.PrintInputs && len(fn.params) > 0 {
		for _, p := range fn.params {
			all = append(all, "tt.args."+p.name)
		}
	}
	all = append(all, args...)
	return strings.Join(all, ", ")
}

func lowerTypeName(typ string) string {
	typ = strings.TrimPrefix(typ, "*")
	typ = strings.TrimPrefix(typ, "[]")
	if i := strings.Index(typ, "["); i >= 0 {
		typ = typ[:i]
	}
	base := filepath.Base(typ)
	if base == "" {
		return "arg"
	}
	runes := []rune(base)
	runes[0] = unicode.ToLower(runes[0])
	return string(runes)
}
