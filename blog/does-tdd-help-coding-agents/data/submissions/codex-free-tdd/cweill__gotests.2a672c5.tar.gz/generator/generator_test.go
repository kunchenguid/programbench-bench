package generator

import (
	"strings"
	"testing"
)

func TestGenerateCreatesTableTestForSimpleFunction(t *testing.T) {
	src := `package math

func Add(a, b int) int { return a + b }
`

	got, logs, err := Generate("math.go", src, Options{Only: "Add"})
	if err != nil {
		t.Fatalf("Generate() error = %v", err)
	}
	if !strings.Contains(logs, "Generated TestAdd\n") {
		t.Fatalf("logs = %q, want generated test log", logs)
	}
	wantParts := []string{
		"package math\n\nimport \"testing\"",
		"func TestAdd(t *testing.T)",
		"type args struct {\n\t\ta int\n\t\tb int\n\t}",
		"tests := []struct {\n\t\tname string\n\t\targs args\n\t\twant int\n\t}{",
		"if got := Add(tt.args.a, tt.args.b); got != tt.want {",
		"t.Errorf(\"Add() = %v, want %v\", got, tt.want)",
	}
	for _, part := range wantParts {
		if !strings.Contains(got, part) {
			t.Fatalf("generated output missing %q:\n%s", part, got)
		}
	}
}

func TestGenerateHandlesMethodsErrorsAndDeepEqual(t *testing.T) {
	src := `package sample

type User struct { Name string }

func Multi(a string, b []int) (int, error) { return 0, nil }
func Slice(a []int) []int { return a }
func (u *User) Greet(prefix string) string { return prefix + u.Name }
`

	got, _, err := Generate("sample.go", src, Options{All: true})
	if err != nil {
		t.Fatalf("Generate() error = %v", err)
	}
	wantParts := []string{
		"import (\n\t\"reflect\"\n\t\"testing\"\n)",
		"wantErr bool",
		"got, err := Multi(tt.args.a, tt.args.b)",
		"if (err != nil) != tt.wantErr {",
		"if got := Slice(tt.args.a); !reflect.DeepEqual(got, tt.want) {",
		"type fields struct {\n\t\tName string\n\t}",
		"u := &User{\n\t\t\t\tName: tt.fields.Name,\n\t\t\t}",
		"if got := u.Greet(tt.args.prefix); got != tt.want {",
	}
	for _, part := range wantParts {
		if !strings.Contains(got, part) {
			t.Fatalf("generated output missing %q:\n%s", part, got)
		}
	}
}

func TestGenerateSupportsNamedParallelAndInputPrinting(t *testing.T) {
	src := `package sample

func Multi(a string, b []int) (int, error) { return 0, nil }
`

	got, _, err := Generate("sample.go", src, Options{All: true, Named: true, Parallel: true, PrintInputs: true})
	if err != nil {
		t.Fatalf("Generate() error = %v", err)
	}
	wantParts := []string{
		"t.Parallel()",
		"tests := map[string]struct {",
		"for name, tt := range tests {",
		"t.Run(name, func(t *testing.T) {",
		"t.Fatalf(\"Multi(%v, %v) error = %v, wantErr %v\", tt.args.a, tt.args.b, err, tt.wantErr)",
	}
	for _, part := range wantParts {
		if !strings.Contains(got, part) {
			t.Fatalf("generated output missing %q:\n%s", part, got)
		}
	}
}

func TestGenerateInstantiatesSimpleGenericParameters(t *testing.T) {
	src := `package gen

func FindFirst[T comparable](slice []T, target T) (int, error) { return 0, nil }
`

	got, _, err := Generate("gen.go", src, Options{All: true})
	if err != nil {
		t.Fatalf("Generate() error = %v", err)
	}
	wantParts := []string{
		"slice  []string",
		"target string",
		"got, err := FindFirst[string](tt.args.slice, tt.args.target)",
	}
	for _, part := range wantParts {
		if !strings.Contains(got, part) {
			t.Fatalf("generated output missing %q:\n%s", part, got)
		}
	}
}

func TestGenerateNamesUnexportedFunctionWithUnderscore(t *testing.T) {
	src := `package sample

func unexported() bool { return false }
`

	got, logs, err := Generate("sample.go", src, Options{All: true})
	if err != nil {
		t.Fatalf("Generate() error = %v", err)
	}
	if !strings.Contains(logs, "Generated Test_unexported\n") {
		t.Fatalf("logs = %q, want underscore test name", logs)
	}
	if !strings.Contains(got, "func Test_unexported(t *testing.T)") {
		t.Fatalf("generated output missing underscore test name:\n%s", got)
	}
}

func TestGenerateDoesNotReturnAfterFatalErrorCheckInSubtests(t *testing.T) {
	src := `package sample

func Multi(a string) (int, error) { return 0, nil }
`

	got, _, err := Generate("sample.go", src, Options{All: true})
	if err != nil {
		t.Fatalf("Generate() error = %v", err)
	}
	bad := "t.Fatalf(\"Multi() error = %v, wantErr %v\", err, tt.wantErr)\n\t\t\t\treturn"
	if strings.Contains(got, bad) {
		t.Fatalf("generated output has unexpected return after Fatalf:\n%s", got)
	}
}

func TestGenerateInstantiatesGenericReceiverMethods(t *testing.T) {
	src := `package gen

type Set[T comparable] struct { m map[T]struct{} }
func (s *Set[T]) Add(v T) {}
`

	got, _, err := Generate("gen.go", src, Options{All: true})
	if err != nil {
		t.Fatalf("Generate() error = %v", err)
	}
	wantParts := []string{
		"type args struct {\n\t\tv string\n\t}",
		"s    *Set[string]",
		"s := &Set[string]{}",
		"s.Add(tt.args.v)",
	}
	for _, part := range wantParts {
		if !strings.Contains(got, part) {
			t.Fatalf("generated output missing %q:\n%s", part, got)
		}
	}
}

func TestGeneratePrefixesNoSubtestErrorsWithCaseName(t *testing.T) {
	src := `package sample

func Multi(a string) (int, error) { return 0, nil }
`

	got, _, err := Generate("sample.go", src, Options{All: true, NoSubtests: true})
	if err != nil {
		t.Fatalf("Generate() error = %v", err)
	}
	wantParts := []string{
		"t.Errorf(\"%q. Multi() error = %v, wantErr %v\", tt.name, err, tt.wantErr)",
		"t.Errorf(\"%q. Multi() = %v, want %v\", tt.name, got, tt.want)",
	}
	for _, part := range wantParts {
		if !strings.Contains(got, part) {
			t.Fatalf("generated output missing %q:\n%s", part, got)
		}
	}
}

func TestGenerateReturnsEmptyOutputWhenNoFunctionsMatch(t *testing.T) {
	src := `package sample

func Multi(a string) (int, error) { return 0, nil }
`

	got, logs, err := Generate("sample.go", src, Options{Only: "ZZZ"})
	if err != nil {
		t.Fatalf("Generate() error = %v", err)
	}
	if got != "" || logs != "" {
		t.Fatalf("Generate() = output %q logs %q, want both empty", got, logs)
	}
}

func TestGenerateImportsReferencedPackagesFromSignatures(t *testing.T) {
	src := `package imp

import "time"

func When(t time.Time) time.Time { return t }
`

	got, _, err := Generate("imp.go", src, Options{All: true})
	if err != nil {
		t.Fatalf("Generate() error = %v", err)
	}
	wantParts := []string{
		"import (\n\t\"reflect\"\n\t\"testing\"\n\t\"time\"\n)",
		"t time.Time",
		"want time.Time",
		"if got := When(tt.args.t); !reflect.DeepEqual(got, tt.want) {",
	}
	for _, part := range wantParts {
		if !strings.Contains(got, part) {
			t.Fatalf("generated output missing %q:\n%s", part, got)
		}
	}
}
