module batclone

go 1.20
