package main

import (
	"bytes"
	"crypto/tls"
	"encoding/base64"
	"encoding/json"
	"flag"
	"fmt"
	"io"
	"log"
	"mime"
	"net/http"
	"net/url"
	"os"
	"sort"
	"strings"
)

const version = "0.1.0"

var helpText = `bat is a Go implemented CLI cURL-like tool for humans.

Usage:

	bat [flags] [METHOD] URL [ITEM [ITEM]]

flags:
  -a, -auth=USER[:PASS]       Pass a username:password pair as the argument
  -b, -bench=false            Sends bench requests to URL
  -b.N=1000                   Number of requests to run
  -b.C=100                    Number of requests to run concurrently
  -body=""                    Send RAW data as body
  -f, -form=false             Submitting the data as a form
  -j, -json=true              Send the data in a JSON object
  -p, -pretty=true            Print Json Pretty Format
  -i, -insecure=false         Allow connections to SSL sites without certs
  -proxy=PROXY_URL            Proxy with host and port
  -print="A"                  String specifying what the output should contain, default will print all information
         "H" request headers
         "B" request body
         "h" response headers
         "b" response body
  -v, -version=true           Show Version Number

METHOD:
  bat defaults to either GET (if there is no request data) or POST (with request data).

URL:
  The only information needed to perform a request is a URL. The default scheme is http://,
  which can be omitted from the argument; example.org works just fine.

ITEM:
  Can be any of:
    Query string   key=value
    Header         key:value
    Post data      key=value
    File upload    key@/path/file

Example:

	bat beego.me

more help information please refer to https://github.com/astaxie/bat

`

type config struct {
	auth     string
	bench    bool
	benchN   int
	benchC   int
	body     string
	hasBody  bool
	form     bool
	jsonMode bool
	pretty   bool
	insecure bool
	proxy    string
	print    string
	download bool
	version  bool
}

func main() {
	log.SetFlags(log.LstdFlags | log.Lmicroseconds | log.Lshortfile)
	cfg, args, help, err := parse(os.Args[1:])
	if help {
		fmt.Print(helpText)
		os.Exit(2)
	}
	if err != nil {
		fmt.Fprintln(os.Stderr, err)
		fmt.Print(helpText)
		os.Exit(2)
	}
	if cfg.version {
		fmt.Println("Version:", version)
		os.Exit(2)
	}
	if len(args) == 0 {
		fmt.Print(helpText)
		os.Exit(2)
	}
	if cfg.bench {
		runBench(cfg, args)
		return
	}
	if err := runOnce(cfg, args); err != nil {
		log.Println("can't get the url", err)
		os.Exit(1)
	}
}

func parse(argv []string) (config, []string, bool, error) {
	cfg := config{benchN: 1000, benchC: 100, jsonMode: true, pretty: true, print: "A"}
	fs := flag.NewFlagSet("bat", flag.ContinueOnError)
	fs.SetOutput(io.Discard)
	fs.StringVar(&cfg.auth, "auth", "", "")
	fs.StringVar(&cfg.auth, "a", "", "")
	fs.BoolVar(&cfg.bench, "bench", false, "")
	fs.BoolVar(&cfg.bench, "b", false, "")
	fs.IntVar(&cfg.benchN, "b.N", 1000, "")
	fs.IntVar(&cfg.benchC, "b.C", 100, "")
	fs.StringVar(&cfg.body, "body", "", "")
	fs.BoolVar(&cfg.form, "form", false, "")
	fs.BoolVar(&cfg.form, "f", false, "")
	fs.BoolVar(&cfg.jsonMode, "json", true, "")
	fs.BoolVar(&cfg.jsonMode, "j", true, "")
	fs.BoolVar(&cfg.pretty, "pretty", true, "")
	fs.BoolVar(&cfg.pretty, "p", true, "")
	fs.BoolVar(&cfg.insecure, "insecure", false, "")
	fs.BoolVar(&cfg.insecure, "i", false, "")
	fs.StringVar(&cfg.proxy, "proxy", "", "")
	fs.StringVar(&cfg.print, "print", "A", "")
	fs.BoolVar(&cfg.download, "download", false, "")
	fs.BoolVar(&cfg.version, "version", false, "")
	fs.BoolVar(&cfg.version, "v", false, "")
	for _, a := range argv {
		if a == "-h" || a == "--help" {
			return cfg, nil, true, nil
		}
		if a == "-body" || strings.HasPrefix(a, "-body=") || strings.HasPrefix(a, "--body=") {
			cfg.hasBody = true
		}
	}
	err := fs.Parse(argv)
	if err == flag.ErrHelp {
		return cfg, nil, true, nil
	}
	return cfg, fs.Args(), false, err
}

func runOnce(cfg config, args []string) error {
	method, rawURL, items, err := splitArgs(args)
	if err != nil {
		log.Println(err)
		os.Exit(1)
	}
	headers, data := parseItems(items)
	if method == "" {
		if len(data) > 0 || cfg.hasBody {
			method = "POST"
		} else {
			method = "GET"
		}
	}
	u, err := normalizeURL(rawURL)
	if err != nil {
		return err
	}
	var body io.Reader
	if cfg.hasBody {
		body = strings.NewReader(cfg.body)
	} else if len(data) > 0 && methodAllowsBody(method) {
		if cfg.form {
			encoded := encodeForm(data)
			body = strings.NewReader(encoded)
			headers["Content-Type"] = "application/x-www-form-urlencoded"
		} else {
			payload, _ := json.Marshal(data)
			body = bytes.NewReader(append(payload, '\n'))
			headers["Content-Type"] = "application/json"
		}
	} else if len(data) > 0 {
		q := u.Query()
		for _, k := range sortedKeys(data) {
			q.Add(k, data[k])
		}
		u.RawQuery = q.Encode()
	}
	req, err := http.NewRequest(method, u.String(), body)
	if err != nil {
		return err
	}
	req.Header.Set("User-Agent", "bat/"+version)
	req.Header.Set("Accept", "application/json")
	req.Header.Set("Accept-Encoding", "gzip, deflate")
	for k, v := range headers {
		req.Header.Set(k, v)
	}
	if cfg.auth != "" {
		req.Header.Set("Authorization", "Basic "+base64.StdEncoding.EncodeToString([]byte(cfg.auth)))
	}
	client := http.Client{Transport: transport(cfg)}
	resp, err := client.Do(req)
	if err != nil {
		return err
	}
	defer resp.Body.Close()
	respBody, err := io.ReadAll(resp.Body)
	if err != nil {
		return err
	}
	printBody(resp.Header.Get("Content-Type"), respBody, cfg.pretty)
	return nil
}

func splitArgs(args []string) (string, string, []string, error) {
	if len(args) == 0 {
		return "", "", nil, fmt.Errorf("Miss the URL")
	}
	method := ""
	first := strings.ToUpper(args[0])
	if isMethod(first) {
		method = first
		args = args[1:]
	}
	if len(args) == 0 {
		return "", "", nil, fmt.Errorf("Miss the URL")
	}
	return method, args[0], args[1:], nil
}

func isMethod(s string) bool {
	switch s {
	case "GET", "POST", "PUT", "DELETE", "PATCH", "HEAD", "OPTIONS":
		return true
	}
	return false
}

func normalizeURL(raw string) (*url.URL, error) {
	if !strings.Contains(raw, "://") {
		raw = "http://" + raw
	}
	return url.Parse(raw)
}

func parseItems(items []string) (map[string]string, map[string]string) {
	headers := map[string]string{}
	data := map[string]string{}
	for _, item := range items {
		if i := strings.Index(item, ":"); i >= 0 {
			headers[item[:i]] = item[i+1:]
			continue
		}
		if i := strings.Index(item, "="); i >= 0 {
			key, val := item[:i], item[i+1:]
			if strings.HasPrefix(val, "@/") || strings.HasPrefix(val, "@.") {
				if b, err := os.ReadFile(val[1:]); err == nil {
					val = string(b)
				}
			}
			data[key] = val
		}
	}
	return headers, data
}

func methodAllowsBody(method string) bool {
	return method != "GET" && method != "HEAD"
}

func sortedKeys(m map[string]string) []string {
	keys := make([]string, 0, len(m))
	for k := range m {
		keys = append(keys, k)
	}
	sort.Strings(keys)
	return keys
}

func encodeForm(data map[string]string) string {
	v := url.Values{}
	for _, k := range sortedKeys(data) {
		v.Add(k, data[k])
	}
	return v.Encode()
}

func transport(cfg config) http.RoundTripper {
	tr := &http.Transport{}
	if cfg.insecure {
		tr.TLSClientConfig = &tls.Config{InsecureSkipVerify: true}
	}
	if cfg.proxy != "" {
		if p, err := normalizeURL(cfg.proxy); err == nil {
			tr.Proxy = http.ProxyURL(p)
		}
	}
	return tr
}

func printBody(contentType string, body []byte, pretty bool) {
	fmt.Println()
	if pretty && isJSON(contentType, body) {
		var out bytes.Buffer
		if json.Indent(&out, body, "", "  ") == nil {
			fmt.Print(out.String())
			return
		}
	}
	fmt.Print(string(body))
}

func isJSON(contentType string, body []byte) bool {
	if contentType != "" {
		mt, _, err := mime.ParseMediaType(contentType)
		if err == nil && (mt == "application/json" || strings.HasSuffix(mt, "+json")) {
			return true
		}
	}
	trimmed := strings.TrimSpace(string(body))
	return strings.HasPrefix(trimmed, "{") || strings.HasPrefix(trimmed, "[")
}

func runBench(cfg config, args []string) {
	n := cfg.benchN
	if n < 1 {
		n = 1
	}
	for i := 0; i < n; i++ {
		_ = runOnce(config{pretty: false, jsonMode: cfg.jsonMode, form: cfg.form, auth: cfg.auth, insecure: cfg.insecure, proxy: cfg.proxy, print: cfg.print}, args)
	}
}
