#!/usr/bin/env python3
import os
import re
import sys
import urllib.parse
import urllib.request
import xml.etree.ElementTree as ET


CLOVER = "\U0001f340"


def local(tag):
    return tag.rsplit("}", 1)[-1] if "}" in tag else tag


def children(node, name=None):
    out = [c for c in list(node) if name is None or local(c.tag) == name]
    return out


def descendants(node, name):
    return [e for e in node.iter() if local(e.tag) == name]


def split_qname(value):
    if not value:
        return ""
    return value.split(":", 1)[-1]


def exported(name):
    parts = re.split(r"[^A-Za-z0-9]+", name or "")
    if len(parts) == 1:
        s = parts[0]
        if not s:
            return "Value"
        return s[:1].upper() + s[1:]
    return "".join(p[:1].upper() + p[1:] for p in parts if p)


def unexported(name):
    e = exported(name)
    return e[:1].lower() + e[1:]


def go_type(xsd_type):
    t = split_qname(xsd_type)
    table = {
        "string": "string",
        "normalizedString": "string",
        "token": "string",
        "anyURI": "string",
        "date": "time.Time",
        "dateTime": "time.Time",
        "time": "time.Time",
        "boolean": "bool",
        "bool": "bool",
        "byte": "int8",
        "unsignedByte": "uint8",
        "short": "int16",
        "unsignedShort": "uint16",
        "int": "int32",
        "integer": "int32",
        "positiveInteger": "int32",
        "nonNegativeInteger": "int32",
        "long": "int64",
        "unsignedInt": "uint",
        "unsignedLong": "uint64",
        "float": "float32",
        "double": "float64",
        "decimal": "float64",
        "base64Binary": "[]byte",
        "hexBinary": "[]byte",
        "anyType": "AnyType",
        "anySimpleType": "string",
        "NCName": "NCName",
    }
    return table.get(t, exported(t))


def is_array(el):
    max_occurs = el.attrib.get("maxOccurs", "")
    return max_occurs == "unbounded" or (max_occurs.isdigit() and int(max_occurs) > 1)


class Wsdl:
    def __init__(self, xml_text):
        self.xml_text = xml_text
        self.root = ET.fromstring(xml_text)
        self.target_ns = self.root.attrib.get("targetNamespace", "")
        self.elements = {}
        self.complex_types = {}
        self.simple_types = {}
        self.messages = {}
        self.port_types = []
        self.bind_actions = {}
        self._parse()

    def _is_builtin(self, xsd_type):
        t = split_qname(xsd_type)
        return go_type(t) != exported(t) or t in ("AnyType", "AnyURI", "NCName")

    def _field_type(self, typ, el):
        raw = split_qname(typ or "string")
        gt = go_type(raw)
        if raw in self.simple_types:
            gt = exported(raw)
        elif raw in self.complex_types and not is_array(el):
            gt = "*" + exported(raw)
        if is_array(el):
            gt = "[]" + gt.lstrip("*")
        return gt

    def _parse_fields_from_complex(self, complex_node):
        fields = []
        if complex_node is None:
            return fields
        containers = []
        for c in complex_node.iter():
            if local(c.tag) in ("sequence", "all", "choice"):
                containers.append(c)
        if not containers:
            containers = [complex_node]
        seen = set()
        for container in containers:
            for el in children(container, "element"):
                name = el.attrib.get("name") or split_qname(el.attrib.get("ref", ""))
                if not name or name in seen:
                    continue
                seen.add(name)
                typ = el.attrib.get("type")
                if not typ:
                    st = next((x for x in children(el, "simpleType")), None)
                    ct = next((x for x in children(el, "complexType")), None)
                    restriction = next((x for x in descendants(st, "restriction")), None) if st is not None else None
                    typ = restriction.attrib.get("base") if restriction is not None else None
                    if not typ and ct is not None:
                        typ = name
                fields.append((name, exported(name), self._field_type(typ, el)))
        for attr in children(complex_node, "attribute"):
            name = attr.attrib.get("name")
            if name:
                fields.append((name, exported(name), go_type(attr.attrib.get("type", "string"))))
        return fields

    def _parse(self):
        schemas = descendants(self.root, "schema")
        for schema in schemas:
            ns = schema.attrib.get("targetNamespace", self.target_ns)
            for st in children(schema, "simpleType"):
                name = st.attrib.get("name")
                restriction = next((x for x in descendants(st, "restriction")), None)
                enums = []
                if restriction is not None:
                    for enum in children(restriction, "enumeration"):
                        if "value" in enum.attrib:
                            enums.append(enum.attrib["value"])
                if name:
                    self.simple_types[name] = (go_type(restriction.attrib.get("base", "string")) if restriction is not None else "string", enums)
            for ct in children(schema, "complexType"):
                name = ct.attrib.get("name")
                if name:
                    self.complex_types[name] = (ns, self._parse_fields_from_complex(ct))
            for el in children(schema, "element"):
                name = el.attrib.get("name")
                if not name:
                    continue
                typ = split_qname(el.attrib.get("type", ""))
                if not typ:
                    st = next((x for x in children(el, "simpleType")), None)
                    restriction = next((x for x in descendants(st, "restriction")), None) if st is not None else None
                    if st is not None and restriction is not None:
                        enums = [enum.attrib["value"] for enum in children(restriction, "enumeration") if "value" in enum.attrib]
                        if enums:
                            self.simple_types[name] = (go_type(restriction.attrib.get("base", "string")), enums)
                ct = next((x for x in children(el, "complexType")), None)
                fields = self._parse_fields_from_complex(ct) if ct is not None else []
                self.elements[name] = (ns, typ, fields)

        for msg in children(self.root, "message"):
            name = msg.attrib.get("name")
            part = next((p for p in children(msg, "part")), None)
            if name and part is not None:
                self.messages[name] = split_qname(part.attrib.get("element") or part.attrib.get("type") or "")

        for binding in children(self.root, "binding"):
            for op in children(binding, "operation"):
                op_name = op.attrib.get("name")
                action = ""
                for c in children(op):
                    if local(c.tag) == "operation":
                        action = c.attrib.get("soapAction", "")
                        break
                if op_name:
                    self.bind_actions[op_name] = action

        for pt in children(self.root, "portType"):
            ops = []
            for op in children(pt, "operation"):
                name = op.attrib.get("name")
                inp = next((x for x in children(op, "input")), None)
                out = next((x for x in children(op, "output")), None)
                in_msg = split_qname(inp.attrib.get("message", "")) if inp is not None else ""
                out_msg = split_qname(out.attrib.get("message", "")) if out is not None else ""
                req = self.messages.get(in_msg, name or "")
                resp = self.messages.get(out_msg, (name or "") + "Response")
                if name:
                    ops.append((name, req, resp, self.bind_actions.get(name, "")))
            self.port_types.append((pt.attrib.get("name", "Service"), ops))

    def all_types(self):
        result = []
        seen = set()
        for name, (ns, typ, fields) in self.elements.items():
            if name in seen:
                continue
            seen.add(name)
            if typ and not fields and typ in self.complex_types:
                cns, cfields = self.complex_types[typ]
                result.append((name, cns, cfields))
            else:
                result.append((name, ns, fields))
        for name, (ns, fields) in self.complex_types.items():
            if name not in seen:
                seen.add(name)
                result.append((name, ns, fields))
        return result


def load_wsdl(path, insecure=False):
    parsed = urllib.parse.urlparse(path)
    if parsed.scheme in ("http", "https"):
        with urllib.request.urlopen(path) as r:
            return r.read().decode("utf-8")
    with open(os.path.abspath(path), encoding="utf-8") as f:
        return f.read()


def generate_client(wsdl, package):
    lines = [
        "// Code generated by gowsdl DO NOT EDIT.",
        "",
        f"package {package}",
        "",
        "import (",
        '\t"context"',
        '\t"encoding/xml"',
        '\t"github.com/hooklift/gowsdl/soap"',
        '\t"time"',
        ")",
        "",
        "// against \"unused imports\"",
        "var _ time.Time",
        "var _ xml.Name",
        "",
        "type AnyType struct {",
        '\tInnerXML string `xml:",innerxml"`',
        "}",
        "",
        "type AnyURI string",
        "",
        "type NCName string",
        "",
    ]
    for name, (base, enums) in wsdl.simple_types.items():
        gname = exported(name)
        lines += [f"type {gname} {base}", ""]
        if enums:
            lines += ["const ("]
            for value in enums:
                cname = exported(gname + "_" + value)
                lines += [f'\t{cname} {gname} = "{value}"', ""]
            if lines[-1] == "":
                lines.pop()
            lines += [")", ""]
    for name, ns, fields in wsdl.all_types():
        if name in wsdl.simple_types:
            continue
        gname = exported(name)
        lines += [f"type {gname} struct {{", f'\tXMLName xml.Name `xml:"{ns} {name}"`']
        for xml_name, field_name, typ in fields:
            lines += ["", f'\t{field_name} {typ} `xml:"{xml_name},omitempty" json:"{xml_name},omitempty"`']
        lines += ["}", ""]
    for pt_name, ops in wsdl.port_types:
        iface = exported(pt_name)
        recv = unexported(pt_name)
        lines += [f"type {iface} interface {{"]
        for name, req, resp, _ in ops:
            lines += [f"\t{exported(name)}(request *{exported(req)}) (*{exported(resp)}, error)", "", f"\t{exported(name)}Context(ctx context.Context, request *{exported(req)}) (*{exported(resp)}, error)", ""]
        if lines[-1] == "":
            lines.pop()
        lines += ["}", "", f"type {recv} struct {{", "\tclient *soap.Client", "}", "", f"func New{iface}(client *soap.Client) {iface} {{", f"\treturn &{recv}{{", "\t\tclient: client,", "\t}", "}", ""]
        for name, req, resp, action in ops:
            m = exported(name)
            lines += [
                f"func (service *{recv}) {m}Context(ctx context.Context, request *{exported(req)}) (*{exported(resp)}, error) {{",
                f"\tresponse := new({exported(resp)})",
                f'\terr := service.client.CallContext(ctx, "{action}", request, response)',
                "\tif err != nil {",
                "\t\treturn nil, err",
                "\t}",
                "",
                "\treturn response, nil",
                "}",
                "",
                f"func (service *{recv}) {m}(request *{exported(req)}) (*{exported(resp)}, error) {{",
                f"\treturn service.{m}Context(",
                "\t\tcontext.Background(),",
                "\t\trequest,",
                "\t)",
                "}",
                "",
            ]
    return "\n".join(lines).rstrip() + "\n"


def generate_server(wsdl, package):
    ops = []
    for _, port_ops in wsdl.port_types:
        ops.extend(port_ops)
    lines = [
        "// Code generated by gowsdl DO NOT EDIT.",
        "",
        f"package {package}",
        "",
        "import (",
        '\t"encoding/xml"',
        '\t"errors"',
        '\t"fmt"',
        '\t"net/http"',
        '\t"reflect"',
        '\t"strings"',
        ")",
        "",
        "var wsdl = `" + wsdl.xml_text.replace("`", "` + \"`\" + `") + "`",
        "",
        'var WSDLUndefinedError = errors.New("Server was unable to process request. --> Object reference not set to an instance of an object.")',
        "",
        "type SOAPEnvelopeRequest struct {",
        '\tXMLName xml.Name `xml:"http://schemas.xmlsoap.org/soap/envelope/ Envelope"`',
        "\tBody    SOAPBodyRequest",
        "}",
        "",
        "type SOAPBodyRequest struct {",
        '\tXMLName xml.Name `xml:"http://schemas.xmlsoap.org/soap/envelope/ Body"`',
        "",
    ]
    for name, req, _, _ in ops:
        lines += [f'\t{exported(req)} *{exported(req)} `xml:,omitempty`', ""]
    lines += [
        "}",
        "",
        "type SOAPEnvelopeResponse struct {",
        '\tXMLName    xml.Name `xml:"soap:Envelope"`',
        '\tPrefixSoap string   `xml:"xmlns:soap,attr"`',
        '\tPrefixXsi  string   `xml:"xmlns:xsi,attr"`',
        '\tPrefixXsd  string   `xml:"xmlns:xsd,attr"`',
        "",
        "\tBody SOAPBodyResponse",
        "}",
        "",
        "func NewSOAPEnvelopResponse() *SOAPEnvelopeResponse {",
        "\treturn &SOAPEnvelopeResponse{",
        '\t\tPrefixSoap: "http://schemas.xmlsoap.org/soap/envelope/",',
        '\t\tPrefixXsd:  "http://www.w3.org/2001/XMLSchema",',
        '\t\tPrefixXsi:  "http://www.w3.org/2001/XMLSchema-instance",',
        "\t}",
        "}",
        "",
        "type Fault struct {",
        '\tXMLName xml.Name `xml:"SOAP-ENV:Fault"`',
        '\tSpace   string   `xml:"xmlns:SOAP-ENV,omitempty,attr"`',
        "",
        '\tCode   string `xml:"faultcode,omitempty"`',
        '\tString string `xml:"faultstring,omitempty"`',
        '\tActor  string `xml:"faultactor,omitempty"`',
        '\tDetail string `xml:"detail,omitempty"`',
        "}",
        "",
        "type SOAPBodyResponse struct {",
        '\tXMLName xml.Name `xml:"soap:Body"`',
        '\tFault   *Fault   `xml:",omitempty"`',
        "",
    ]
    for name, req, resp, _ in ops:
        lines += [f'\t{exported(req)} *{exported(resp)} `xml:",omitempty"`', ""]
    lines += ["}", ""]
    for name, req, resp, _ in ops:
        lines += [f"func (service *SOAPBodyRequest) {exported(req)}Func(request *{exported(req)}) (*{exported(resp)}, error) {{", "\treturn nil, WSDLUndefinedError", "}", ""]
    lines += [
        "func (service *SOAPEnvelopeRequest) call(w http.ResponseWriter, r *http.Request) {",
        '\tw.Header().Add("Content-Type", "text/xml; charset=utf-8")',
        "\tval := reflect.ValueOf(&service.Body).Elem()",
        "\tn := val.NumField()",
        "\tvar field reflect.Value",
        "\tvar name string",
        "\tfind := false",
        "",
        "\tif r.Method == http.MethodGet {",
        "\t\tw.Write([]byte(wsdl))",
        "\t\treturn",
        "\t}",
        "",
        "\tresp := NewSOAPEnvelopResponse()",
        "\tdefer func() {",
        "\t\tif r := recover(); r != nil {",
        "\t\t\tresp.Body.Fault = &Fault{}",
        '\t\t\tresp.Body.Fault.Space = "http://schemas.xmlsoap.org/soap/envelope/"',
        '\t\t\tresp.Body.Fault.Code = "soap:Server"',
        "\t\t\tresp.Body.Fault.Detail = fmt.Sprintf(\"%v\", r)",
        "\t\t\tresp.Body.Fault.String = fmt.Sprintf(\"%v\", r)",
        "\t\t}",
        "\t\txml.NewEncoder(w).Encode(resp)",
        "\t}()",
        "",
        '\theader := r.Header.Get("Content-Type")',
        '\tif strings.Index(header, "application/soap+xml") >= 0 {',
        '\t\tpanic("Could not find an appropriate Transport Binding to invoke.")',
        "\t}",
        "",
        "\terr := xml.NewDecoder(r.Body).Decode(service)",
        "\tif err != nil {",
        "\t\tpanic(err)",
        "\t}",
        "",
        "\tfor i := 0; i < n; i++ {",
        "\t\tfield = val.Field(i)",
        "\t\tname = val.Type().Field(i).Name",
        "\t\tif field.Kind() != reflect.Ptr {",
        "\t\t\tcontinue",
        "\t\t}",
        "\t\tif field.IsNil() {",
        "\t\t\tcontinue",
        "\t\t}",
        "\t\tif field.IsValid() {",
        "\t\t\tfind = true",
        "\t\t\tbreak",
        "\t\t}",
        "\t}",
        "",
        "\tif !find {",
        "\t\tpanic(WSDLUndefinedError)",
        "\t} else {",
        '\t\tm := val.Addr().MethodByName(name + "Func")',
        "\t\tif !m.IsValid() {",
        "\t\t\tpanic(WSDLUndefinedError)",
        "\t\t}",
        "",
        "\t\tvals := m.Call([]reflect.Value{field})",
        "\t\tif vals[1].IsNil() {",
        "\t\t\treflect.ValueOf(&resp.Body).Elem().FieldByName(name).Set(vals[0])",
        "\t\t} else {",
        "\t\t\tpanic(vals[1].Interface())",
        "\t\t}",
        "\t}",
        "",
        "}",
        "",
        "func Endpoint(w http.ResponseWriter, r *http.Request) {",
        "\trequest := SOAPEnvelopeRequest{}",
        "\trequest.call(w, r)",
        "}",
    ]
    return "\n".join(lines).rstrip() + "\n"


def usage():
    text = """Usage: ./executable [options] myservice.wsdl
  -d string
\t\tDirectory under which package directory will be created (default "./")
  -i\tSkips TLS Verification
  -make-public
\t\tMake the generated types public/exported (default true)
  -o string
\t\tFile where the generated code will be saved (default "myservice.go")
  -p string
\t\tPackage under which code will be generated (default "myservice")
  -v\tShows gowsdl version
"""
    sys.stdout.write(text)


class Args:
    def __init__(self):
        self.d = "./"
        self.i = False
        self.make_public = "true"
        self.o = "myservice.go"
        self.p = "myservice"
        self.v = False
        self.wsdl = None


def parse_args(argv):
    args = Args()
    positionals = []
    i = 0
    string_flags = {"-d": "d", "-o": "o", "-p": "p"}
    while i < len(argv):
        a = argv[i]
        if a == "--help" or a == "-h":
            return "help", args
        if a.startswith("-"):
            name, eq, value = a.partition("=")
            if name in string_flags:
                if not eq:
                    i += 1
                    if i >= len(argv):
                        sys.stdout.write(f"flag needs an argument: {name}\n")
                        usage()
                        return 2, args
                    value = argv[i]
                setattr(args, string_flags[name], value)
            elif name == "-i":
                args.i = True
            elif name == "-v":
                args.v = True
            elif name == "-make-public":
                args.make_public = value if eq else "true"
            else:
                sys.stdout.write(f"flag provided but not defined: {name}\n")
                usage()
                return 2, args
        else:
            positionals.append(a)
        i += 1
    args.wsdl = positionals[0] if positionals else None
    return 0, args


def main(argv):
    status, args = parse_args(argv)
    if status == "help":
        usage()
        return 0
    if status:
        return status
    if args.v:
        print(f"{CLOVER}  v0.5.0")
        return 0
    if not args.wsdl:
        usage()
        return 0
    path_display = args.wsdl if urllib.parse.urlparse(args.wsdl).scheme else os.path.abspath(args.wsdl)
    print(f"{CLOVER}  Reading file {path_display}")
    try:
        text = load_wsdl(args.wsdl, args.i)
        model = Wsdl(text)
        outdir = os.path.join(args.d, args.p)
        if not os.path.isdir(outdir):
            os.mkdir(outdir)
        with open(os.path.join(outdir, args.o), "w", encoding="utf-8") as f:
            f.write(generate_client(model, args.p))
        with open(os.path.join(outdir, "server" + args.o), "w", encoding="utf-8") as f:
            f.write(generate_server(model, args.p))
    except FileNotFoundError as e:
        missing = e.filename or ""
        print(f"{CLOVER}  open {missing}: no such file or directory")
        return 1
    except Exception as e:
        print(f"{CLOVER}  {e}")
        return 1
    print(f"{CLOVER}  Done \U0001f44d")
    return 0


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
