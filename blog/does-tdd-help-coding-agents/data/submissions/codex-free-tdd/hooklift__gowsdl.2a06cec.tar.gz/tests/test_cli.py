import os
import subprocess
import tempfile
import unittest


ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
WORKSPACE = os.environ.get("WORKSPACE", "/workspace")


class GowsdlCliTest(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        subprocess.run(["bash", "compile.sh"], cwd=ROOT, check=True)
        cls.exe = os.path.join(ROOT, "executable")

    def run_exe(self, *args, cwd=None):
        return subprocess.run(
            [self.exe, *args],
            cwd=cwd or ROOT,
            text=True,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
        )

    def test_version_matches_reference(self):
        result = self.run_exe("-v")
        self.assertEqual(result.returncode, 0)
        self.assertEqual(result.stdout, "\U0001f340  v0.5.0\n")

    def test_stock_wsdl_generates_client_and_server_files(self):
        with tempfile.TemporaryDirectory() as tmp:
            wsdl = os.path.join(WORKSPACE, "assets", "stock.wsdl")
            result = self.run_exe("-p", "stock", "-o", "stock.go", "-d", tmp, wsdl)
            self.assertEqual(result.returncode, 0, result.stdout)
            self.assertEqual(
                result.stdout,
                f"\U0001f340  Reading file {wsdl}\n\U0001f340  Done \U0001f44d\n",
            )

            with open(os.path.join(tmp, "stock", "stock.go"), encoding="utf-8") as f:
                client = f.read()
            with open(os.path.join(tmp, "stock", "serverstock.go"), encoding="utf-8") as f:
                server = f.read()

        self.assertIn("package stock", client)
        self.assertIn("type TradePriceRequest struct", client)
        self.assertIn('TickerSymbol string `xml:"tickerSymbol,omitempty" json:"tickerSymbol,omitempty"`', client)
        self.assertIn("type StockQuotePortType interface", client)
        self.assertIn('CallContext(ctx, "http://example.com/GetLastTradePrice", request, response)', client)
        self.assertIn("var wsdl = `<definitions name=\"StockQuote\"", server)
        self.assertIn("func Endpoint(w http.ResponseWriter, r *http.Request)", server)

    def test_ferry_wsdl_generates_enums_and_pointer_custom_fields(self):
        with tempfile.TemporaryDirectory() as tmp:
            wsdl = os.path.join(WORKSPACE, "assets", "ferry.wsdl")
            result = self.run_exe("-p", "ferry", "-o", "ferry.go", "-d", tmp, wsdl)
            self.assertEqual(result.returncode, 0, result.stdout)
            with open(os.path.join(tmp, "ferry", "ferry.go"), encoding="utf-8") as f:
                client = f.read()

        self.assertIn("type Season string", client)
        self.assertIn('SeasonSpring Season = "Spring"', client)
        self.assertIn(
            'GetActiveScheduledSeasonsResult *ArrayOfSchedBriefResponse `xml:"GetActiveScheduledSeasonsResult,omitempty" json:"GetActiveScheduledSeasonsResult,omitempty"`',
            client,
        )
        self.assertIn('ScheduleID int32 `xml:"ScheduleID,omitempty" json:"ScheduleID,omitempty"`', client)

    def test_missing_parent_output_directory_is_an_error(self):
        with tempfile.TemporaryDirectory() as tmp:
            missing = os.path.join(tmp, "missing")
            wsdl = os.path.join(WORKSPACE, "assets", "stock.wsdl")
            result = self.run_exe("-p", "stock", "-d", missing, wsdl)

        self.assertEqual(result.returncode, 1)
        self.assertIn(f"{CLOVER if False else chr(0x1f340)}  Reading file {wsdl}", result.stdout)
        self.assertIn("no such file or directory", result.stdout)

    def test_unknown_flag_uses_go_flag_error_format(self):
        result = self.run_exe("-bad")
        self.assertEqual(result.returncode, 2)
        self.assertTrue(result.stdout.startswith("flag provided but not defined: -bad\nUsage: ./executable [options] myservice.wsdl\n"))
        self.assertNotIn("argparse", result.stdout)


if __name__ == "__main__":
    unittest.main()
