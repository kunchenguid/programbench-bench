#!/usr/bin/env python3
import gzip
import os
import subprocess
import tempfile
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
EXE = ROOT / "executable"


def run_hck(args, data=b"", cwd=None):
    return subprocess.run(
        [str(EXE), *args],
        input=data,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        cwd=cwd or ROOT,
    )


def test_default_whitespace_and_reordered_fields():
    res = run_hck(["-f", "3,1"], b"a b c\n1  2  3\n")
    assert res.returncode == 0
    assert res.stdout == b"c\ta\n3\t1\n"


def test_literal_delimiter_preserves_empty_fields_and_use_input_delimiter():
    res = run_hck(["-L", "-d", ",", "-I", "-f", "1-4"], b"a,,c,\n")
    assert res.returncode == 0
    assert res.stdout == b"a,,c,\n"


def test_compact_literal_delimiter_option_from_examples():
    res = run_hck(["-Ld,", "-f2,1"], b"a,b,c\n1,2,3\n")
    assert res.returncode == 0
    assert res.stdout == b"b\ta\n2\t1\n"


def test_open_ended_ranges_are_evaluated_per_row():
    res = run_hck(["-f", "2-"], b"a b\nc d e\n")
    assert res.returncode == 0
    assert res.stdout == b"b\nd\te\n"


def test_missing_selected_fields_are_omitted_without_extra_delimiters():
    res = run_hck(["-f", "2,1,3"], b"a\n\nb c\n")
    assert res.returncode == 0
    assert res.stdout == b"a\n\nc\tb\n"


def test_regex_delimiter_and_exclude_range():
    res = run_hck(["-d", "[0-9]+", "-f", "1-", "-e", "2"], b"a1b22c\n")
    assert res.returncode == 0
    assert res.stdout == b"a\tc\n"


def test_regex_delimiter_captures_are_not_output_fields():
    res = run_hck(["-d", "([0-9])"], b"a1b2c\n")
    assert res.returncode == 0
    assert res.stdout == b"a\tb\tc\n"


def test_header_literal_regex_and_exclude():
    data = b"USER PID CPU CMD\na 1 9 x\n"
    res = run_hck(["-r", "-F", "^C", "-F", "^U", "-E", "CMD"], data)
    assert res.returncode == 0
    assert res.stdout == b"CPU\tUSER\n9\ta\n"


def test_files_output_and_gzip(tmp_path):
    plain = tmp_path / "plain.txt"
    gz = tmp_path / "plain.txt.gz"
    out = tmp_path / "out.txt"
    plain.write_bytes(b"a b\nc d\n")
    gz.write_bytes(gzip.compress(b"e f\n"))

    res = run_hck(["-z", "-f", "2", str(plain), str(gz), "-o", str(out)])
    assert res.returncode == 0
    assert res.stdout == b""
    assert out.read_bytes() == b"b\nd\nf\n"


def test_long_options_with_equals():
    res = run_hck(["--delimiter=,", "--delim-is-literal", "--fields=2", "--output-delimiter=|"], b"a,b\n")
    assert res.returncode == 0
    assert res.stdout == b"b\n"


def test_bzip2_and_xz_decompression(tmp_path):
    import bz2
    import lzma

    bz = tmp_path / "data.bz2"
    xz = tmp_path / "data.xz"
    bz.write_bytes(bz2.compress(b"a b\n"))
    xz.write_bytes(lzma.compress(b"c d\n"))
    res = run_hck(["-z", "-f2", str(bz), str(xz)])
    assert res.returncode == 0
    assert res.stdout == b"b\nd\n"


def test_invalid_field_zero_is_error():
    res = run_hck(["-f", "0"], b"a b\n")
    assert res.returncode == 1
    assert b"Fields and positions are numbered from 1: 0" in res.stderr


if __name__ == "__main__":
    tests = [
        test_default_whitespace_and_reordered_fields,
        test_literal_delimiter_preserves_empty_fields_and_use_input_delimiter,
        test_compact_literal_delimiter_option_from_examples,
        test_open_ended_ranges_are_evaluated_per_row,
        test_missing_selected_fields_are_omitted_without_extra_delimiters,
        test_regex_delimiter_and_exclude_range,
        test_regex_delimiter_captures_are_not_output_fields,
        test_header_literal_regex_and_exclude,
        lambda: test_files_output_and_gzip(Path(tempfile.mkdtemp())),
        test_long_options_with_equals,
        lambda: test_bzip2_and_xz_decompression(Path(tempfile.mkdtemp())),
        test_invalid_field_zero_is_error,
    ]
    failures = 0
    for test in tests:
        try:
            test()
            print(f"PASS {getattr(test, '__name__', 'test_files_output_and_gzip')}")
        except Exception as exc:
            failures += 1
            print(f"FAIL {getattr(test, '__name__', 'test_files_output_and_gzip')}: {exc}")
    raise SystemExit(1 if failures else 0)
