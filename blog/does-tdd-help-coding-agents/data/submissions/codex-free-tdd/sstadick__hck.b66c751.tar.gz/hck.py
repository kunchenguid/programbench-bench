#!/usr/bin/env python3
import bz2
import gzip
import lzma
import os
import re
import sys


VERSION = "hck git:23bebe8-modified"
LONG_HELP = """* `delimiter` is a regex by default and a fixed substring with `-L` * `header-fields` allows for specifying a literal or a regex to match header names to select columns * both `header-fields` and `fields` order dictate the order of the output columns * input files (not stdin) are automatically compressed * the output delimiter can specified with `-D`

Usage: executable [OPTIONS] [INPUT]...

Arguments:
  [INPUT]...  Input files to parse, defaults to stdin

Options:
  -o, --output <OUTPUT>
          Output file to write to, defaults to stdout
  -d, --delimiter <DELIMITER>
          Delimiter to use on input files, this is a substring literal by default. To treat it as a literal add the `-L` flag [default: \\s+]
  -L, --delim-is-literal
          Treat the delimiter as a string literal. This can significantly improve performance, especially for single byte delimiters
  -I, --use-input-delim
          Use the input delimiter as the output delimiter if the input is literal and no other output delimiter has been set
  -D, --output-delimiter <OUTPUT_DELIMITER>
          Delimiter string to use on outputs [default: "\\t"]
  -f, --fields <FIELDS>
          Fields to keep in the output, ex: 1,2-,-5,2-5. Fields are 1-based and inclusive
  -e, --exclude <EXCLUDE>
          Fields to exclude from the output, ex: 3,9-11,15-. Exclude fields are 1 based and inclusive. Exclude fields take precedence over `fields`
  -E, --exclude-header <EXCLUDE_HEADER>
          Headers to exclude from the output, ex: '^badfield.*$`. This is a string literal by default. Add the `-r` flag to treat as a regex
  -F, --header-field <HEADER_FIELD>
          A string literal or regex to select headers, ex: '^is_.*$`. This is a string literal by default. add the `-r` flag to treat it as a regex
  -r, --header-is-regex
          Treat the header_fields as regexs instead of string literals
  -z, --try-decompress
          Try to find the correct decompression method based on the file extensions
  -Z, --try-compress
          Try to gzip compress the output
  -t, --compression-threads <COMPRESSION_THREADS>
          Threads to use for compression, 0 will result in `hck` staying single threaded [default: 4]
  -l, --compression-level <COMPRESSION_LEVEL>
          Compression level [default: 6]
      --no-mmap
          Disallow the possibility of using mmap
      --crlf
          Support CRLF newlines
  -h, --help
          Print help (see more with '--help')
  -V, --version
          Print version
"""


def error(message, status=1):
    sys.stderr.write(f"[2026-06-05T07:07:00Z ERROR hck] {message}\n")
    raise SystemExit(status)


def parse_args(argv):
    opts = {
        "delimiter": r"\s+",
        "literal": False,
        "use_input_delim": False,
        "out_delim": "\t",
        "fields": None,
        "exclude": None,
        "header_fields": [],
        "exclude_headers": [],
        "header_regex": False,
        "decompress": False,
        "compress": False,
        "output": None,
        "crlf": False,
        "inputs": [],
    }
    i = 0
    while i < len(argv):
        arg = argv[i]
        if arg.startswith("--") and "=" in arg:
            name, val = arg.split("=", 1)
            argv = argv[:i] + [name, val] + argv[i + 1 :]
            arg = argv[i]
        if arg == "--":
            opts["inputs"].extend(argv[i + 1 :])
            break
        if arg in ("-h", "--help"):
            print(LONG_HELP, end="")
            raise SystemExit(0)
        if arg in ("-V", "--version"):
            print(VERSION)
            raise SystemExit(0)
        if arg in ("-L", "--delim-is-literal"):
            opts["literal"] = True
        elif arg in ("-I", "--use-input-delim"):
            opts["use_input_delim"] = True
        elif arg in ("-r", "--header-is-regex"):
            opts["header_regex"] = True
        elif arg in ("-z", "--try-decompress"):
            opts["decompress"] = True
        elif arg in ("-Z", "--try-compress"):
            opts["compress"] = True
        elif arg in ("--no-mmap",):
            pass
        elif arg == "--crlf":
            opts["crlf"] = True
        elif arg in ("-d", "--delimiter", "-D", "--output-delimiter", "-f", "--fields",
                     "-e", "--exclude", "-F", "--header-field", "-E", "--exclude-header",
                     "-o", "--output", "-t", "--compression-threads", "-l", "--compression-level"):
            if i + 1 >= len(argv):
                sys.stderr.write(f"error: a value is required for '{arg}' but none was supplied\n")
                raise SystemExit(2)
            val = argv[i + 1]
            i += 1
            if arg in ("-d", "--delimiter"):
                opts["delimiter"] = val
            elif arg in ("-D", "--output-delimiter"):
                opts["out_delim"] = val
            elif arg in ("-f", "--fields"):
                opts["fields"] = val
            elif arg in ("-e", "--exclude"):
                opts["exclude"] = val
            elif arg in ("-F", "--header-field"):
                opts["header_fields"].append(val)
            elif arg in ("-E", "--exclude-header"):
                opts["exclude_headers"].append(val)
            elif arg in ("-o", "--output"):
                opts["output"] = val
        elif arg.startswith("-Ld") and arg != "-Ld":
            opts["literal"] = True
            opts["delimiter"] = arg[3:]
        elif arg.startswith("-LD") and arg != "-LD":
            opts["literal"] = True
            opts["out_delim"] = arg[3:]
        elif arg.startswith("-d") and arg != "-d":
            opts["delimiter"] = arg[2:]
        elif arg.startswith("-D") and arg != "-D":
            opts["out_delim"] = arg[2:]
        elif arg.startswith("-f") and arg != "-f":
            opts["fields"] = arg[2:]
        elif arg.startswith("-e") and arg != "-e":
            opts["exclude"] = arg[2:]
        elif arg.startswith("-F") and arg != "-F":
            opts["header_fields"].append(arg[2:])
        elif arg.startswith("-E") and arg != "-E":
            opts["exclude_headers"].append(arg[2:])
        elif arg.startswith("-o") and arg != "-o":
            opts["output"] = arg[2:]
        elif arg.startswith("-"):
            sys.stderr.write(f"error: unexpected argument '{arg}' found\n")
            raise SystemExit(2)
        else:
            opts["inputs"].append(arg)
        i += 1
    return opts


def parse_spec(spec):
    if spec is None:
        return None
    ranges = []
    for part in spec.split(","):
        if part == "":
            error("Failed to parse field: ")
        if "-" in part:
            lo_s, hi_s = part.split("-", 1)
            lo = int(lo_s) if lo_s else 1
            hi = int(hi_s) if hi_s else None
        else:
            lo = hi = int(part)
        if lo < 1 or (hi is not None and hi < 1):
            bad = "0" if lo < 1 else str(hi)
            error(f"Fields and positions are numbered from 1: {bad}")
        if hi is not None and hi < lo:
            error(f"High end of range less than low end of range: {part}")
        ranges.append((lo, hi))
    return ranges


def expand(ranges, count):
    if ranges is None:
        return list(range(count))
    seen = set()
    out = []
    for lo, hi in ranges:
        end = count if hi is None else min(hi, count)
        for idx1 in range(lo, end + 1):
            idx = idx1 - 1
            if 0 <= idx < count and idx not in seen:
                seen.add(idx)
                out.append(idx)
    return out


def split_line(line, opts):
    if opts["literal"]:
        return line.split(opts["delimiter"])
    try:
        regex = re.compile(opts["delimiter"])
        out = []
        last = 0
        for match in regex.finditer(line):
            out.append(line[last:match.start()])
            last = match.end()
            if match.start() == match.end():
                last = match.end()
        out.append(line[last:])
        return out
    except re.error as exc:
        sys.stderr.write(f"Error: regex parse error:\n    {opts['delimiter']}\n    ^\nerror: {exc}\n")
        raise SystemExit(1)


def header_indexes(headers, opts):
    selected = []
    seen = set()
    if opts["fields"]:
        for idx in expand(parse_spec(opts["fields"]), len(headers)):
            if idx not in seen:
                seen.add(idx)
                selected.append(idx)
    for pat in opts["header_fields"]:
        try:
            matches = [
                i for i, h in enumerate(headers)
                if (re.search(pat, h) if opts["header_regex"] else h == pat)
            ]
        except re.error:
            sys.stderr.write(f"error: invalid value '{pat}' for '--header-field <HEADER_FIELD>': regex parse error\n")
            raise SystemExit(2)
        for idx in matches:
            if idx not in seen:
                seen.add(idx)
                selected.append(idx)
    if opts["header_fields"] and not selected:
        error("No headers matched")
    if not opts["fields"] and not opts["header_fields"]:
        selected = list(range(len(headers)))
        seen = set(selected)
    excluded = set(expand(parse_spec(opts["exclude"]), len(headers))) if opts["exclude"] else set()
    for pat in opts["exclude_headers"]:
        try:
            for i, h in enumerate(headers):
                if (re.search(pat, h) if opts["header_regex"] else h == pat):
                    excluded.add(i)
        except re.error:
            sys.stderr.write(f"error: invalid value '{pat}' for '--exclude-header <EXCLUDE_HEADER>': regex parse error\n")
            raise SystemExit(2)
    return [i for i in selected if i not in excluded]


def read_inputs(opts):
    if not opts["inputs"]:
        data = sys.stdin.buffer.read()
        return data.decode("utf-8", errors="replace")
    chunks = []
    for path in opts["inputs"]:
        if opts["decompress"] and path.endswith(".gz"):
            with gzip.open(path, "rb") as fh:
                chunks.append(fh.read().decode("utf-8", errors="replace"))
        elif opts["decompress"] and (path.endswith(".bz2") or path.endswith(".bzip2")):
            with bz2.open(path, "rb") as fh:
                chunks.append(fh.read().decode("utf-8", errors="replace"))
        elif opts["decompress"] and path.endswith(".xz"):
            with lzma.open(path, "rb") as fh:
                chunks.append(fh.read().decode("utf-8", errors="replace"))
        else:
            with open(path, "rb") as fh:
                chunks.append(fh.read().decode("utf-8", errors="replace"))
    return "".join(chunks)


def process(opts):
    out_delim = opts["delimiter"] if opts["literal"] and opts["use_input_delim"] else opts["out_delim"]
    data = read_inputs(opts)
    newline = "\r\n" if opts["crlf"] else "\n"
    lines = data.splitlines()
    if data.endswith("\n") or data.endswith("\r\n"):
        pass
    elif data:
        pass
    rows = []
    indexes = None
    headers_seen = False
    fields_ranges = parse_spec(opts["fields"]) if opts["fields"] else None
    exclude_ranges = parse_spec(opts["exclude"]) if opts["exclude"] else None
    use_header = bool(opts["header_fields"] or opts["exclude_headers"])
    for line in lines:
        if not opts["crlf"] and line.endswith("\r"):
            line = line[:-1]
        parts = split_line(line, opts)
        if use_header and not headers_seen:
            indexes = header_indexes(parts, opts)
            headers_seen = True
        elif not use_header:
            indexes = expand(fields_ranges, len(parts))
            excluded = set(expand(exclude_ranges, len(parts))) if exclude_ranges else set()
            indexes = [i for i in indexes if i not in excluded]
        vals = [parts[i] if i < len(parts) else "" for i in indexes]
        rows.append(out_delim.join(vals) + newline)
    return "".join(rows).encode("utf-8")


def main(argv):
    opts = parse_args(argv)
    output = process(opts)
    if opts["compress"]:
        output = gzip.compress(output, compresslevel=6)
    if opts["output"]:
        with open(opts["output"], "wb") as fh:
            fh.write(output)
    else:
        sys.stdout.buffer.write(output)


if __name__ == "__main__":
    try:
        main(sys.argv[1:])
    except ValueError as exc:
        error(f"Failed to parse field: {exc}")
