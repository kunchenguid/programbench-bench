package main

import (
	"bufio"
	"database/sql"
	"encoding/csv"
	"encoding/json"
	"fmt"
	"io"
	"os"
	"path/filepath"
	"strconv"
	"strings"
	"unicode"

	sqlite3 "github.com/mattn/go-sqlite3"
)

const versionText = "3.54.0 2026-04-14 20:02:49 49b3bac482c831f503c7f90c35959e7ea731950e991baba86b2ab95987d2539b (64-bit)"
const driverName = "pbsqlite3"

func init() {
	sql.Register(driverName, &sqlite3.SQLiteDriver{
		ConnectHook: func(conn *sqlite3.SQLiteConn) error {
			return conn.RegisterFunc("sqlite_version", func() string { return "3.54.0" }, true)
		},
	})
}

type shell struct {
	db        *sql.DB
	out       io.Writer
	err       io.Writer
	mode      string
	headers   bool
	nullValue string
	separator string
	rowSep    string
	echo      bool
	bail      bool
}

type options struct {
	dbName   string
	sqlText  string
	commands []string
	noInit   bool
	sawDB    bool
}

func main() {
	code := run(os.Args[1:], os.Stdin, os.Stdout, os.Stderr)
	os.Exit(code)
}

func run(args []string, in io.Reader, out, errw io.Writer) int {
	opts := options{dbName: ":memory:"}
	sh := &shell{out: out, err: errw, mode: "list", separator: "|", rowSep: "\n"}

	if code, done := parseArgs(args, sh, &opts, out, errw); done {
		return code
	}

	dsn := opts.dbName
	if dsn == "" {
		dsn = ":memory:"
	}
	db, err := sql.Open(driverName, dsn)
	if err != nil {
		fmt.Fprintf(errw, "Error: %v\n", err)
		return 1
	}
	defer db.Close()
	sh.db = db

	for _, cmd := range opts.commands {
		if sh.processLine(cmd, "<cmd>") != 0 && sh.bail {
			return 1
		}
	}
	if opts.sqlText != "" {
		if err := sh.execSQL(opts.sqlText, "command line argument"); err != nil {
			sh.reportError(err, opts.sqlText, "command line argument")
			return 1
		}
		return 0
	}
	if err := sh.processReader(in, "stdin"); err != nil {
		return 1
	}
	return 0
}

func parseArgs(args []string, sh *shell, opts *options, out, errw io.Writer) (int, bool) {
	stopOptions := false
	for i := 0; i < len(args); i++ {
		a := args[i]
		if !stopOptions && strings.HasPrefix(a, "-") && a != "-" {
			switch a {
			case "--":
				stopOptions = true
			case "-help", "--help":
				printHelp(out)
				return 0, true
			case "-version", "--version":
				fmt.Fprintln(out, versionText)
				return 0, true
			case "-csv":
				sh.mode, sh.separator, sh.headers = "csv", ",", false
			case "-ascii":
				sh.mode, sh.separator, sh.rowSep = "ascii", string(rune(0x1f)), string(rune(0x1e))
			case "-tabs":
				sh.mode, sh.separator = "list", "\t"
			case "-list":
				sh.mode = "list"
			case "-line":
				sh.mode = "line"
			case "-column", "-table":
				sh.mode = "column"
			case "-box":
				sh.mode = "box"
			case "-html":
				sh.mode = "html"
			case "-json":
				sh.mode = "json"
			case "-quote":
				sh.mode = "quote"
			case "-header", "-headers":
				sh.headers = true
			case "-noheader", "-noheaders":
				sh.headers = false
			case "-echo":
				sh.echo = true
			case "-bail":
				sh.bail = true
			case "-batch", "-interactive", "-noinit", "-unsafe-testing":
			case "-separator":
				i++
				if i >= len(args) {
					fmt.Fprintf(errw, "Error: missing argument to %s\n", a)
					return 1, true
				}
				sh.separator = unescapeArg(args[i])
			case "-newline":
				i++
				if i >= len(args) {
					fmt.Fprintf(errw, "Error: missing argument to %s\n", a)
					return 1, true
				}
				sh.rowSep = unescapeArg(args[i])
			case "-nullvalue":
				i++
				if i >= len(args) {
					fmt.Fprintf(errw, "Error: missing argument to %s\n", a)
					return 1, true
				}
				sh.nullValue = args[i]
			case "-cmd":
				i++
				if i >= len(args) {
					fmt.Fprintf(errw, "Error: missing argument to %s\n", a)
					return 1, true
				}
				opts.commands = append(opts.commands, args[i])
			default:
				if takesValue(a) {
					i++
					continue
				}
				fmt.Fprintf(errw, "%s: Error: unknown option: %s\n", os.Args[0], a)
				return 1, true
			}
			continue
		}
		if !opts.sawDB {
			opts.dbName = a
			opts.sawDB = true
		} else {
			rest := args[i:]
			opts.sqlText = strings.Join(rest, " ")
			break
		}
	}
	return 0, false
}

func takesValue(opt string) bool {
	switch opt {
	case "-init", "-lookaside", "-maxsize", "-mmap", "-pagecache", "-screenwidth", "-vfs", "-escape", "-A":
		return true
	}
	return false
}

func printHelp(out io.Writer) {
	fmt.Fprint(out, `Usage: ./executable [OPTIONS] [FILENAME [SQL...]]
FILENAME is the name of an SQLite database. A new database is created
if the file does not previously exist. Defaults to :memory:.
OPTIONS include:
   --                   treat no subsequent arguments as options
   -A ARGS...           run ".archive ARGS" and exit
   -append              append the database to the end of the file
   -ascii               set output mode to 'ascii'
   -bail                stop after hitting an error
   -batch               force batch I/O
   -csv                 set output mode to 'csv'
   -box                 set output mode to 'box'
   -cmd COMMAND         run "COMMAND" before reading stdin
   -column              set output mode to 'column'
   -deserialize         open the database using sqlite3_deserialize()
   -echo                print inputs before execution
   -escape T            ctrl-char escape; T is one of: symbol, ascii, off
   -init FILENAME       read/process named file
   -[no]header          turn headers on or off
   -help                show this message
   -html                set output mode to HTML
   -ifexists            only open if database already exists
   -interactive         force interactive I/O
   -json                set output mode to 'json'
   -line                set output mode to 'line'
   -list                set output mode to 'list'
   -lookaside SIZE N    use N entries of SZ bytes for lookaside memory
   -markdown            set output mode to 'markdown'
   -maxsize N           maximum size for a --deserialize database
   -memtrace            trace all memory allocations and deallocations
   -mmap N              default mmap size set to N
   -newline SEP         set output row separator. Default: '\n'
   -nofollow            refuse to open symbolic links to database files
   -noinit              Do not read the ~/.sqliterc file at startup
   -nonce STRING        set the safe-mode escape nonce
   -no-rowid-in-view    Disable rowid-in-view using sqlite3_config()
   -nullvalue TEXT      set text string for NULL values. Default ''
   -pagecache SIZE N    use N slots of SZ bytes each for page cache memory
   -pcachetrace         trace all page cache operations
   -quote               set output mode to 'quote'
   -readonly            open the database read-only
   -safe                enable safe-mode
   -screenwidth N       use N as the default screenwidth 
   -separator SEP       set output column separator. Default: '|'
   -stats               print memory stats before each finalize
   -table               set output mode to 'table'
   -tabs                set output mode to 'tabs'
   -unsafe-testing      allow unsafe commands and modes for testing
   -version             show SQLite version
   -vfs NAME            use NAME as the default VFS
   -vfstrace            enable tracing of all VFS calls
   -zip                 open the file as a ZIP Archive
`)
}

func (sh *shell) processReader(r io.Reader, source string) error {
	scanner := bufio.NewScanner(r)
	scanner.Buffer(make([]byte, 0, 4096), 1024*1024)
	var sqlBuf strings.Builder
	for scanner.Scan() {
		line := scanner.Text()
		trim := strings.TrimSpace(line)
		if trim == "" && sqlBuf.Len() == 0 {
			continue
		}
		if sqlBuf.Len() == 0 && strings.HasPrefix(trim, ".") {
			if sh.echo {
				fmt.Fprintln(sh.out, line)
			}
			if code := sh.processLine(trim, source); code != 0 && sh.bail {
				return fmt.Errorf("dot command failed")
			}
			continue
		}
		if sh.echo {
			fmt.Fprintln(sh.out, line)
		}
		sqlBuf.WriteString(line)
		sqlBuf.WriteByte('\n')
		if sqlComplete(sqlBuf.String()) {
			text := sqlBuf.String()
			if err := sh.execSQL(text, source); err != nil {
				sh.reportError(err, text, source)
				if sh.bail {
					return err
				}
			}
			sqlBuf.Reset()
		}
	}
	if sqlBuf.Len() > 0 {
		text := sqlBuf.String()
		if err := sh.execSQL(text, source); err != nil {
			sh.reportError(err, text, source)
			if sh.bail {
				return err
			}
		}
	}
	return scanner.Err()
}

func (sh *shell) processLine(line, source string) int {
	if strings.HasPrefix(line, ".") {
		return sh.dotCommand(line, source)
	}
	if err := sh.execSQL(line, source); err != nil {
		sh.reportError(err, line, source)
		return 1
	}
	return 0
}

func (sh *shell) dotCommand(line, source string) int {
	args := splitWords(line)
	if len(args) == 0 {
		return 0
	}
	cmd := strings.TrimPrefix(args[0], ".")
	switch cmd {
	case "quit", "exit":
		os.Exit(0)
	case "help":
		fmt.Fprintln(sh.out, ".tables                 List names of tables")
		fmt.Fprintln(sh.out, ".schema ?PATTERN?       Show CREATE statements")
		fmt.Fprintln(sh.out, ".mode MODE              Set output mode")
		return 0
	case "headers", "header":
		if len(args) > 1 {
			sh.headers = onOff(args[1])
		} else {
			sh.headers = !sh.headers
		}
	case "mode":
		if len(args) < 2 {
			fmt.Fprintln(sh.err, "Error: mode should be one of: ascii box column csv html json line list quote tabs")
			return 1
		}
		sh.setMode(args[1])
	case "separator":
		if len(args) > 1 {
			sh.separator = unescapeArg(args[1])
		}
		if len(args) > 2 {
			sh.rowSep = unescapeArg(args[2])
		}
	case "nullvalue":
		if len(args) > 1 {
			sh.nullValue = args[1]
		}
	case "tables":
		pattern := ""
		if len(args) > 1 {
			pattern = args[1]
		}
		if err := sh.showTables(pattern); err != nil {
			sh.reportError(err, line, source)
			return 1
		}
	case "schema":
		pattern := ""
		if len(args) > 1 {
			pattern = args[1]
		}
		if err := sh.showSchema(pattern); err != nil {
			sh.reportError(err, line, source)
			return 1
		}
	case "dump":
		if err := sh.dumpDatabase(); err != nil {
			sh.reportError(err, line, source)
			return 1
		}
	case "read":
		if len(args) < 2 {
			fmt.Fprintln(sh.err, "Usage: .read FILE")
			return 1
		}
		f, err := os.Open(args[1])
		if err != nil {
			fmt.Fprintf(sh.err, "Error: cannot open \"%s\"\n", args[1])
			return 1
		}
		defer f.Close()
		if err := sh.processReader(f, args[1]); err != nil {
			return 1
		}
	case "databases":
		return sh.processLine("PRAGMA database_list;", source)
	default:
		fmt.Fprintf(sh.err, "Error: unknown command or invalid arguments:  \"%s\". Enter \".help\" for help\n", line)
		return 1
	}
	return 0
}

func (sh *shell) setMode(mode string) {
	switch mode {
	case "tabs":
		sh.mode, sh.separator = "list", "\t"
	case "csv":
		sh.mode, sh.separator = "csv", ","
	case "ascii":
		sh.mode, sh.separator, sh.rowSep = "ascii", string(rune(0x1f)), string(rune(0x1e))
	default:
		sh.mode = mode
	}
}

func (sh *shell) showTables(pattern string) error {
	query := "SELECT name FROM sqlite_schema WHERE type IN ('table','view') AND name NOT LIKE 'sqlite_%'"
	var args []any
	if pattern != "" {
		query += " AND name LIKE ?"
		args = append(args, strings.ReplaceAll(pattern, "*", "%"))
	}
	query += " ORDER BY name"
	rows, err := sh.db.Query(query, args...)
	if err != nil {
		return err
	}
	defer rows.Close()
	first := true
	for rows.Next() {
		var name string
		if err := rows.Scan(&name); err != nil {
			return err
		}
		if !first {
			fmt.Fprint(sh.out, " ")
		}
		first = false
		fmt.Fprint(sh.out, name)
	}
	if !first {
		fmt.Fprintln(sh.out)
	}
	return rows.Err()
}

func (sh *shell) dumpDatabase() error {
	fmt.Fprintln(sh.out, "PRAGMA foreign_keys=OFF;")
	fmt.Fprintln(sh.out, "BEGIN TRANSACTION;")
	rows, err := sh.db.Query("SELECT name, sql FROM sqlite_schema WHERE type='table' AND name NOT LIKE 'sqlite_%' AND sql IS NOT NULL ORDER BY tbl_name, name")
	if err != nil {
		return err
	}
	defer rows.Close()
	var tables []string
	for rows.Next() {
		var name, sqlText string
		if err := rows.Scan(&name, &sqlText); err != nil {
			return err
		}
		tables = append(tables, name)
		fmt.Fprintln(sh.out, strings.TrimRight(sqlText, ";")+";")
	}
	if err := rows.Err(); err != nil {
		return err
	}
	for _, table := range tables {
		if err := sh.dumpTable(table); err != nil {
			return err
		}
	}
	fmt.Fprintln(sh.out, "COMMIT;")
	return nil
}

func (sh *shell) dumpTable(table string) error {
	rows, err := sh.db.Query("SELECT * FROM " + quoteIdentifier(table))
	if err != nil {
		return err
	}
	defer rows.Close()
	cols, err := rows.Columns()
	if err != nil {
		return err
	}
	values := make([]any, len(cols))
	ptrs := make([]any, len(cols))
	for i := range values {
		ptrs[i] = &values[i]
	}
	for rows.Next() {
		if err := rows.Scan(ptrs...); err != nil {
			return err
		}
		fmt.Fprintf(sh.out, "INSERT INTO %s VALUES(", quoteIdentifier(table))
		for i, v := range values {
			if i > 0 {
				fmt.Fprint(sh.out, ",")
			}
			fmt.Fprint(sh.out, quoteDBValue(v))
		}
		fmt.Fprintln(sh.out, ");")
	}
	return rows.Err()
}

func (sh *shell) showSchema(pattern string) error {
	query := "SELECT sql FROM sqlite_schema WHERE sql IS NOT NULL"
	var args []any
	if pattern != "" {
		query += " AND name LIKE ?"
		args = append(args, strings.ReplaceAll(pattern, "*", "%"))
	}
	query += " ORDER BY tbl_name, type DESC, name"
	rows, err := sh.db.Query(query, args...)
	if err != nil {
		return err
	}
	defer rows.Close()
	for rows.Next() {
		var sqlText string
		if err := rows.Scan(&sqlText); err != nil {
			return err
		}
		sqlText = strings.TrimRight(sqlText, ";")
		fmt.Fprintln(sh.out, sqlText+";")
	}
	return rows.Err()
}

func (sh *shell) execSQL(text, source string) error {
	for _, stmt := range splitSQL(text) {
		if strings.TrimSpace(stmt) == "" {
			continue
		}
		if !isQuery(stmt) {
			if _, err := sh.db.Exec(stmt); err != nil {
				return err
			}
			continue
		}
		rows, err := sh.db.Query(stmt)
		if err != nil {
			return err
		}
		cols, err := rows.Columns()
		if err != nil {
			rows.Close()
			return err
		}
		if len(cols) == 0 {
			rows.Close()
			continue
		}
		if err := sh.outputRows(cols, rows); err != nil {
			rows.Close()
			return err
		}
		rows.Close()
	}
	return nil
}

func isQuery(stmt string) bool {
	first := strings.ToLower(firstWord(stmt))
	switch first {
	case "select", "with", "pragma", "values", "explain":
		return true
	default:
		return false
	}
}

func firstWord(s string) string {
	s = strings.TrimSpace(s)
	for i, r := range s {
		if unicode.IsSpace(r) || r == '(' {
			return s[:i]
		}
	}
	return s
}

func (sh *shell) outputRows(cols []string, rows *sql.Rows) error {
	values := make([]any, len(cols))
	ptrs := make([]any, len(cols))
	for i := range values {
		ptrs[i] = &values[i]
	}
	var allText [][]string
	var allRaw [][]any
	for rows.Next() {
		if err := rows.Scan(ptrs...); err != nil {
			return err
		}
		raw := make([]any, len(cols))
		rec := make([]string, len(cols))
		for i, v := range values {
			raw[i] = copyDBValue(v)
			rec[i] = sh.formatValue(v)
		}
		allRaw = append(allRaw, raw)
		allText = append(allText, rec)
	}
	if err := rows.Err(); err != nil {
		return err
	}
	switch sh.mode {
	case "column", "box":
		sh.outputColumn(cols, allText)
	case "json":
		sh.outputJSON(cols, allRaw)
	case "quote":
		sh.outputQuote(allRaw)
	default:
		sh.outputRecords(cols, allText)
	}
	return nil
}

func copyDBValue(v any) any {
	if b, ok := v.([]byte); ok {
		cp := make([]byte, len(b))
		copy(cp, b)
		return cp
	}
	return v
}

func (sh *shell) formatValue(v any) string {
	if v == nil {
		return sh.nullValue
	}
	switch x := v.(type) {
	case []byte:
		return string(x)
	case string:
		return x
	case int64:
		return strconv.FormatInt(x, 10)
	case float64:
		return strconv.FormatFloat(x, 'g', -1, 64)
	default:
		return fmt.Sprint(x)
	}
}

func (sh *shell) outputRecords(cols []string, records [][]string) {
	switch sh.mode {
	case "csv":
		w := csv.NewWriter(sh.out)
		w.UseCRLF = true
		if sh.headers {
			_ = w.Write(cols)
		}
		for _, rec := range records {
			_ = w.Write(rec)
		}
		w.Flush()
	case "line":
		for _, rec := range records {
			for i, col := range cols {
				fmt.Fprintf(sh.out, "%s: %s\n", col, rec[i])
			}
		}
	case "html":
		for _, rec := range records {
			fmt.Fprint(sh.out, "<TR>")
			for _, v := range rec {
				fmt.Fprintf(sh.out, "<TD>%s</TD>", htmlEscape(v))
			}
			fmt.Fprintln(sh.out, "</TR>")
		}
	default:
		if sh.headers {
			fmt.Fprint(sh.out, strings.Join(cols, sh.separator))
			fmt.Fprint(sh.out, sh.rowSep)
		}
		for _, rec := range records {
			fmt.Fprint(sh.out, strings.Join(rec, sh.separator))
			fmt.Fprint(sh.out, sh.rowSep)
		}
	}
}

func (sh *shell) outputColumn(cols []string, all [][]string) {
	widths := make([]int, len(cols))
	if sh.headers {
		for i, c := range cols {
			widths[i] = len(c)
		}
	}
	for _, rec := range all {
		for i, v := range rec {
			if len(v) > widths[i] {
				widths[i] = len(v)
			}
		}
	}
	if sh.headers {
		printPaddedRow(sh.out, cols, widths)
		dashes := make([]string, len(cols))
		for i, w := range widths {
			if w < 1 {
				w = 1
			}
			dashes[i] = strings.Repeat("-", w)
		}
		printPaddedRow(sh.out, dashes, widths)
	}
	for _, rec := range all {
		printPaddedRow(sh.out, rec, widths)
	}
}

func printPaddedRow(out io.Writer, rec []string, widths []int) {
	for i, v := range rec {
		if i > 0 {
			fmt.Fprint(out, "  ")
		}
		if i == len(rec)-1 {
			fmt.Fprint(out, v)
		} else {
			fmt.Fprintf(out, "%-*s", widths[i], v)
		}
	}
	fmt.Fprintln(out)
}

func (sh *shell) outputJSON(cols []string, all [][]any) {
	arr := make([]map[string]any, 0, len(all))
	for _, rec := range all {
		obj := map[string]any{}
		for i, c := range cols {
			obj[c] = jsonValue(rec[i])
		}
		arr = append(arr, obj)
	}
	b, _ := json.Marshal(arr)
	fmt.Fprintln(sh.out, string(b))
}

func (sh *shell) outputQuote(all [][]any) {
	for _, rec := range all {
		for i, v := range rec {
			if i > 0 {
				fmt.Fprint(sh.out, ",")
			}
			fmt.Fprint(sh.out, quoteDBValue(v))
		}
		fmt.Fprintln(sh.out)
	}
}

func jsonValue(v any) any {
	if b, ok := v.([]byte); ok {
		return string(b)
	}
	return v
}

func (sh *shell) reportError(err error, sqlText, source string) {
	msg := err.Error()
	if strings.Contains(source, "command line argument") {
		fmt.Fprintf(sh.err, "Error: in prepare, %s\n", msg)
		return
	}
	fmt.Fprintf(sh.err, "Parse error near line 1: %s\n", msg)
}

func sqlComplete(s string) bool {
	for _, stmt := range splitSQL(s) {
		if strings.TrimSpace(stmt) == "" {
			continue
		}
	}
	return strings.HasSuffix(strings.TrimSpace(s), ";")
}

func splitSQL(s string) []string {
	var stmts []string
	var b strings.Builder
	var quote rune
	escape := false
	for _, r := range s {
		b.WriteRune(r)
		if quote != 0 {
			if r == quote && !escape {
				quote = 0
			}
			escape = r == '\\' && !escape
			if r != '\\' {
				escape = false
			}
			continue
		}
		if r == '\'' || r == '"' || r == '`' {
			quote = r
			continue
		}
		if r == ';' {
			stmts = append(stmts, b.String())
			b.Reset()
		}
	}
	if strings.TrimSpace(b.String()) != "" {
		stmts = append(stmts, b.String())
	}
	return stmts
}

func splitWords(s string) []string {
	var out []string
	var b strings.Builder
	var quote rune
	for _, r := range s {
		if quote != 0 {
			if r == quote {
				quote = 0
			} else {
				b.WriteRune(r)
			}
			continue
		}
		if r == '\'' || r == '"' {
			quote = r
			continue
		}
		if unicode.IsSpace(r) {
			if b.Len() > 0 {
				out = append(out, b.String())
				b.Reset()
			}
			continue
		}
		b.WriteRune(r)
	}
	if b.Len() > 0 {
		out = append(out, b.String())
	}
	return out
}

func onOff(s string) bool {
	switch strings.ToLower(s) {
	case "on", "yes", "true", "1":
		return true
	default:
		return false
	}
}

func unescapeArg(s string) string {
	return strings.ReplaceAll(strings.ReplaceAll(s, "\\n", "\n"), "\\t", "\t")
}

func quoteSQL(s string) string {
	return "'" + strings.ReplaceAll(s, "'", "''") + "'"
}

func quoteDBValue(v any) string {
	switch x := v.(type) {
	case nil:
		return "NULL"
	case int64:
		return strconv.FormatInt(x, 10)
	case float64:
		return strconv.FormatFloat(x, 'g', -1, 64)
	case []byte:
		return quoteSQL(string(x))
	case string:
		return quoteSQL(x)
	default:
		return quoteSQL(fmt.Sprint(x))
	}
}

func quoteIdentifier(s string) string {
	if isBareIdentifier(s) {
		return s
	}
	return `"` + strings.ReplaceAll(s, `"`, `""`) + `"`
}

func isBareIdentifier(s string) bool {
	if s == "" {
		return false
	}
	for i, r := range s {
		if i == 0 {
			if !(r == '_' || unicode.IsLetter(r)) {
				return false
			}
			continue
		}
		if !(r == '_' || unicode.IsLetter(r) || unicode.IsDigit(r)) {
			return false
		}
	}
	return true
}

func htmlEscape(s string) string {
	s = strings.ReplaceAll(s, "&", "&amp;")
	s = strings.ReplaceAll(s, "<", "&lt;")
	s = strings.ReplaceAll(s, ">", "&gt;")
	return s
}

func absPath(path string) string {
	if filepath.IsAbs(path) {
		return path
	}
	wd, _ := os.Getwd()
	return filepath.Join(wd, path)
}
