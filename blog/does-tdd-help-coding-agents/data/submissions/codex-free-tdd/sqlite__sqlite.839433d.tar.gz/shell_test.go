package main

import (
	"os"
	"os/exec"
	"path/filepath"
	"strings"
	"testing"
)

func runShell(t *testing.T, args []string, stdin string) (string, string, int) {
	t.Helper()
	cmd := exec.Command("go", append([]string{"run", "."}, args...)...)
	cmd.Stdin = strings.NewReader(stdin)
	cmd.Env = append(os.Environ(), "CGO_ENABLED=1")
	out, err := cmd.CombinedOutput()
	if err == nil {
		return string(out), "", 0
	}
	if exit, ok := err.(*exec.ExitError); ok {
		return string(out), "", exit.ExitCode()
	}
	t.Fatalf("unexpected command error: %v", err)
	return "", "", 0
}

func TestExecutesCommandLineSQLInListMode(t *testing.T) {
	out, _, code := runShell(t, []string{":memory:", "select 1 as a, 2+3 as b;"}, "")
	if code != 0 {
		t.Fatalf("exit code = %d, output:\n%s", code, out)
	}
	if out != "1|5\n" {
		t.Fatalf("output = %q", out)
	}
}

func TestHeadersCsvAndNullHandling(t *testing.T) {
	out, _, code := runShell(t, []string{"-csv", "-header", ":memory:", "select 1 as a, NULL as b, 'x,y' as c;"}, "")
	if code != 0 {
		t.Fatalf("exit code = %d, output:\n%s", code, out)
	}
	if out != "a,b,c\r\n1,,\"x,y\"\r\n" {
		t.Fatalf("output = %q", out)
	}
}

func TestDotCommandsAndPersistence(t *testing.T) {
	db := filepath.Join(t.TempDir(), "sample.db")
	stdin := strings.Join([]string{
		"create table t(a int, b text);",
		"insert into t values(1, 'x'),(2, 'y');",
		".tables",
		".schema",
		".mode column",
		".headers on",
		"select * from t;",
		"",
	}, "\n")
	out, _, code := runShell(t, []string{db}, stdin)
	if code != 0 {
		t.Fatalf("exit code = %d, output:\n%s", code, out)
	}
	want := "t\nCREATE TABLE t(a int, b text);\na  b\n-  -\n1  x\n2  y\n"
	if out != want {
		t.Fatalf("output mismatch\nwant:\n%q\ngot:\n%q", want, out)
	}
}

func TestReadCommandExecutesFile(t *testing.T) {
	dir := t.TempDir()
	script := filepath.Join(dir, "input.sql")
	if err := os.WriteFile(script, []byte("create table r(x); insert into r values(7);\nselect x from r;\n"), 0644); err != nil {
		t.Fatal(err)
	}
	out, _, code := runShell(t, []string{":memory:"}, ".read "+script+"\n")
	if code != 0 {
		t.Fatalf("exit code = %d, output:\n%s", code, out)
	}
	if out != "7\n" {
		t.Fatalf("output = %q", out)
	}
}

func TestCsvHeaderAppearsOnceForMultipleRows(t *testing.T) {
	out, _, code := runShell(t, []string{"-csv", "-header", ":memory:", "select 1 as a union all select 2;"}, "")
	if code != 0 {
		t.Fatalf("exit code = %d, output:\n%s", code, out)
	}
	if out != "a\r\n1\r\n2\r\n" {
		t.Fatalf("output = %q", out)
	}
}

func TestLineJsonAndQuoteModesMatchShellFormatting(t *testing.T) {
	line, _, code := runShell(t, []string{"-line", ":memory:", "select 1 as a, NULL as b, 'x,y' as c;"}, "")
	if code != 0 {
		t.Fatalf("line exit code = %d, output:\n%s", code, line)
	}
	if line != "a: 1\nb: \nc: x,y\n" {
		t.Fatalf("line output = %q", line)
	}

	jsonOut, _, code := runShell(t, []string{"-json", ":memory:", "select 1 as a, NULL as b, 'x' as c;"}, "")
	if code != 0 {
		t.Fatalf("json exit code = %d, output:\n%s", code, jsonOut)
	}
	if jsonOut != "[{\"a\":1,\"b\":null,\"c\":\"x\"}]\n" {
		t.Fatalf("json output = %q", jsonOut)
	}

	quote, _, code := runShell(t, []string{"-quote", ":memory:", "select 1 as a, NULL as b, 'x' as c;"}, "")
	if code != 0 {
		t.Fatalf("quote exit code = %d, output:\n%s", code, quote)
	}
	if quote != "1,NULL,'x'\n" {
		t.Fatalf("quote output = %q", quote)
	}
}

func TestDumpEmitsTransactionScript(t *testing.T) {
	db := filepath.Join(t.TempDir(), "dump.db")
	_, _, code := runShell(t, []string{db, "create table t(a int, b text); insert into t values(1, 'x');"}, "")
	if code != 0 {
		t.Fatalf("setup exit code = %d", code)
	}
	out, _, code := runShell(t, []string{db}, ".dump\n")
	if code != 0 {
		t.Fatalf("dump exit code = %d, output:\n%s", code, out)
	}
	want := "PRAGMA foreign_keys=OFF;\nBEGIN TRANSACTION;\nCREATE TABLE t(a int, b text);\nINSERT INTO t VALUES(1,'x');\nCOMMIT;\n"
	if out != want {
		t.Fatalf("dump output mismatch\nwant:\n%q\ngot:\n%q", want, out)
	}
}

func TestHelpShowsReferenceOptionList(t *testing.T) {
	out, _, code := runShell(t, []string{"--help"}, "")
	if code != 0 {
		t.Fatalf("exit code = %d, output:\n%s", code, out)
	}
	for _, want := range []string{
		"Usage: ./executable [OPTIONS] [FILENAME [SQL...]]\n",
		"   -box                 set output mode to 'box'\n",
		"   -deserialize         open the database using sqlite3_deserialize()\n",
		"   -safe                enable safe-mode\n",
		"   -zip                 open the file as a ZIP Archive\n",
	} {
		if !strings.Contains(out, want) {
			t.Fatalf("help missing %q\n%s", want, out)
		}
	}
}

func TestSQLiteVersionScalarMatchesReferenceBuild(t *testing.T) {
	out, _, code := runShell(t, []string{":memory:", "select sqlite_version();"}, "")
	if code != 0 {
		t.Fatalf("exit code = %d, output:\n%s", code, out)
	}
	if out != "3.54.0\n" {
		t.Fatalf("version output = %q", out)
	}
}
