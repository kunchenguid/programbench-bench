package main

import (
	"bytes"
	"context"
	"crypto/tls"
	"encoding/json"
	"encoding/xml"
	"fmt"
	"io"
	"net/http"
	"net/url"
	"os"
	"regexp"
	"sort"
	"strconv"
	"strings"
	"time"
)

const helpText = `Usage:
  executable [options] <url>

Application Options:
      --accepted-status-codes=<codes>       Accepted HTTP response status codes
                                            (e.g. '200..300,403') (default:
                                            200..300)
  -b, --buffer-size=<size>                  HTTP response buffer size in bytes
                                            (default: 4096)
  -c, --max-connections=<count>             Maximum number of HTTP connections
                                            (default: 512)
      --max-connections-per-host=<count>    Maximum number of HTTP connections
                                            per host (default: 512)
      --max-response-body-size=<size>       Maximum response body size to read
                                            (default: 10000000)
  -e, --exclude=<pattern>...                Exclude URLs matched with given
                                            regular expressions
  -i, --include=<pattern>...                Include URLs matched with given
                                            regular expressions
      --follow-robots-txt                   Follow robots.txt when scraping
                                            pages
      --follow-sitemap-xml                  Scrape only pages listed in
                                            sitemap.xml (deprecated)
      --header=<header>...                  Custom headers
  -f, --ignore-fragments                    Ignore URL fragments
      --max-retries=<count>                 Maximum retry count for network
                                            errors (default: 0)
      --dns-resolver=<address>              Custom DNS resolver
      --format=[text|json|junit]            Output format (default: text)
      --json                                Output results in JSON (deprecated)
      --experimental-verbose-json           Include successful results in JSON
                                            (deprecated)
      --junit                               Output results as JUnit XML file
                                            (deprecated)
  -r, --max-redirections=<count>            Maximum number of redirections
                                            (default: 64)
      --rate-limit=<rate>                   Max requests per second
  -t, --timeout=<seconds>                   Timeout for HTTP requests in
                                            seconds (default: 10)
  -v, --verbose                             Show successful results too
      --proxy=<host>                        HTTP proxy host
      --skip-tls-verification               Skip TLS certificate verification
      --one-page-only                       Only check links found in the given
                                            URL
      --color=[auto|always|never]           Color output (default: auto)
  -h, --help                                Show this help
      --version                             Show version
`

type options struct {
	accepted       acceptSet
	format         string
	verbose        bool
	verboseJSON    bool
	ignoreFragment bool
	onePage        bool
	skipTLS        bool
	timeout        time.Duration
	maxBody        int64
	headers        []string
	includes       []*regexp.Regexp
	excludes       []*regexp.Regexp
	url            string
}

type acceptSet []statusRange

type statusRange struct{ lo, hi int }

func (a acceptSet) ok(code int) bool {
	for _, r := range a {
		if code >= r.lo && code < r.hi {
			return true
		}
	}
	return false
}

type linkResult struct {
	URL    string `json:"url"`
	Status string `json:"status,omitempty"`
	Error  string `json:"error,omitempty"`
}

type pageResult struct {
	URL   string       `json:"url"`
	Links []linkResult `json:"links"`
}

type fetched struct {
	status int
	body   []byte
	ctype  string
	err    error
}

func main() {
	code := run(os.Args[1:], os.Stdout)
	os.Exit(code)
}

func run(args []string, out io.Writer) int {
	opt, immediate, code, msg := parseArgs(args)
	if immediate {
		if msg != "" {
			fmt.Fprint(out, msg)
			if !strings.HasSuffix(msg, "\n") {
				fmt.Fprintln(out)
			}
		}
		return code
	}

	results, failed := crawl(opt)
	switch opt.format {
	case "json":
		writeJSON(out, results, opt.verboseJSON)
	case "junit":
		writeJUnit(out, results)
	default:
		writeText(out, results, opt.verbose)
	}
	if failed {
		return 1
	}
	return 0
}

func parseArgs(args []string) (options, bool, int, string) {
	opt := options{accepted: acceptSet{{200, 300}}, format: "text", timeout: 10 * time.Second, maxBody: 10000000}
	var positionals []string
	for i := 0; i < len(args); i++ {
		arg := args[i]
		switch {
		case arg == "-h" || arg == "--help":
			return opt, true, 0, helpText
		case arg == "--version":
			return opt, true, 0, "2.11.1"
		case arg == "-v" || arg == "--verbose":
			opt.verbose = true
		case arg == "-f" || arg == "--ignore-fragments":
			opt.ignoreFragment = true
		case arg == "--one-page-only":
			opt.onePage = true
		case arg == "--skip-tls-verification":
			opt.skipTLS = true
		case arg == "--json":
			opt.format = "json"
		case arg == "--junit":
			opt.format = "junit"
		case arg == "--experimental-verbose-json":
			opt.format = "json"
			opt.verboseJSON = true
		case arg == "-i" || arg == "--include" || arg == "-e" || arg == "--exclude" || arg == "--header" || arg == "--format" || arg == "--accepted-status-codes" || arg == "-t" || arg == "--timeout" || arg == "--max-response-body-size" || arg == "-b" || arg == "--buffer-size" || arg == "-c" || arg == "--max-connections" || arg == "--max-connections-per-host" || arg == "-r" || arg == "--max-redirections" || arg == "--rate-limit" || arg == "--proxy" || arg == "--dns-resolver":
			if i+1 >= len(args) {
				return opt, true, 1, "expected argument for flag `" + strings.TrimLeft(arg, "-") + "'"
			}
			i++
			if err := applyFlag(&opt, arg, args[i]); err != "" {
				return opt, true, 1, err
			}
		case strings.HasPrefix(arg, "--"):
			name, val, has := strings.Cut(arg[2:], "=")
			if has {
				if err := applyLongFlag(&opt, name, val); err != "" {
					return opt, true, 1, err
				}
			} else if name == "follow-robots-txt" || name == "follow-sitemap-xml" {
				// Parsed for compatibility. The simplified crawler does not enforce them.
			} else if name == "color" {
				if i+1 < len(args) {
					i++
				}
			} else {
				return opt, true, 1, "unknown flag `" + name + "'"
			}
		case strings.HasPrefix(arg, "-") && len(arg) > 1:
			return opt, true, 1, "unknown flag `" + strings.TrimLeft(arg, "-") + "'"
		default:
			positionals = append(positionals, arg)
		}
	}
	if len(positionals) != 1 {
		return opt, true, 1, "invalid number of arguments"
	}
	opt.url = positionals[0]
	if _, err := url.ParseRequestURI(opt.url); err != nil {
		return opt, true, 1, err.Error()
	}
	return opt, false, 0, ""
}

func applyFlag(opt *options, flag, val string) string {
	switch flag {
	case "--format":
		return applyLongFlag(opt, "format", val)
	case "--accepted-status-codes":
		return applyLongFlag(opt, "accepted-status-codes", val)
	case "--header":
		opt.headers = append(opt.headers, val)
	case "-i", "--include":
		return addRegexp(&opt.includes, val)
	case "-e", "--exclude":
		return addRegexp(&opt.excludes, val)
	case "-t", "--timeout":
		sec, err := strconv.Atoi(val)
		if err != nil {
			return err.Error()
		}
		opt.timeout = time.Duration(sec) * time.Second
	case "--max-response-body-size":
		n, err := strconv.ParseInt(val, 10, 64)
		if err != nil {
			return err.Error()
		}
		opt.maxBody = n
	default:
		// Resource-tuning flags are accepted and ignored.
	}
	return ""
}

func applyLongFlag(opt *options, name, val string) string {
	switch name {
	case "format":
		if val != "text" && val != "json" && val != "junit" {
			return "invalid choice `" + val + "' for option `format'"
		}
		opt.format = val
	case "accepted-status-codes":
		a, err := parseAccept(val)
		if err != nil {
			return err.Error()
		}
		opt.accepted = a
	case "include":
		return addRegexp(&opt.includes, val)
	case "exclude":
		return addRegexp(&opt.excludes, val)
	case "header":
		opt.headers = append(opt.headers, val)
	case "timeout":
		return applyFlag(opt, "--timeout", val)
	case "max-response-body-size":
		return applyFlag(opt, "--max-response-body-size", val)
	case "color", "buffer-size", "max-connections", "max-connections-per-host", "max-redirections", "rate-limit", "proxy", "dns-resolver":
	default:
		return "unknown flag `" + name + "'"
	}
	return ""
}

func addRegexp(list *[]*regexp.Regexp, pattern string) string {
	re, err := regexp.Compile(pattern)
	if err != nil {
		return err.Error()
	}
	*list = append(*list, re)
	return ""
}

func parseAccept(s string) (acceptSet, error) {
	var out acceptSet
	for _, part := range strings.Split(s, ",") {
		if lo, hi, ok := strings.Cut(part, ".."); ok {
			a, err := strconv.Atoi(lo)
			if err != nil {
				return nil, err
			}
			b, err := strconv.Atoi(hi)
			if err != nil {
				return nil, err
			}
			out = append(out, statusRange{a, b})
		} else {
			n, err := strconv.Atoi(part)
			if err != nil {
				return nil, err
			}
			out = append(out, statusRange{n, n + 1})
		}
	}
	return out, nil
}

func crawl(opt options) ([]pageResult, bool) {
	base, _ := url.Parse(opt.url)
	client := &http.Client{Timeout: opt.timeout}
	client.Transport = &http.Transport{TLSClientConfig: &tls.Config{InsecureSkipVerify: opt.skipTLS}}
	cache := map[string]fetched{}
	visited := map[string]bool{}
	var results []pageResult
	failed := false

	var fetch func(string) fetched
	fetch = func(raw string) fetched {
		check := raw
		if u, err := url.Parse(raw); err == nil {
			u.Fragment = ""
			check = u.String()
		}
		if f, ok := cache[check]; ok {
			return f
		}
		ctx, cancel := context.WithTimeout(context.Background(), opt.timeout)
		defer cancel()
		req, err := http.NewRequestWithContext(ctx, http.MethodGet, check, nil)
		if err != nil {
			f := fetched{err: err}
			cache[check] = f
			return f
		}
		for _, h := range opt.headers {
			if k, v, ok := strings.Cut(h, ":"); ok {
				req.Header.Set(strings.TrimSpace(k), strings.TrimSpace(v))
			}
		}
		resp, err := client.Do(req)
		if err != nil {
			f := fetched{err: err}
			cache[check] = f
			return f
		}
		defer resp.Body.Close()
		body, _ := io.ReadAll(io.LimitReader(resp.Body, opt.maxBody))
		f := fetched{status: resp.StatusCode, body: body, ctype: resp.Header.Get("Content-Type")}
		cache[check] = f
		return f
	}

	var walk func(string)
	walk = func(pageURL string) {
		pageURL = stripFragment(pageURL)
		if visited[pageURL] {
			return
		}
		visited[pageURL] = true
		pf := fetch(pageURL)
		if pf.err != nil || !isHTML(pf.ctype, pf.body) {
			return
		}
		links := extractLinks(pageURL, pf.body)
		var pageLinks []linkResult
		for _, link := range links {
			if !allowedByPatterns(opt, link) {
				continue
			}
			res := checkLink(opt, fetch, link)
			if res.Error != "" {
				failed = true
			}
			pageLinks = append(pageLinks, res)
		}
		sort.SliceStable(pageLinks, func(i, j int) bool {
			if (pageLinks[i].Error == "") != (pageLinks[j].Error == "") {
				return pageLinks[i].Error == ""
			}
			return pageLinks[i].URL < pageLinks[j].URL
		})
		if len(pageLinks) > 0 {
			results = append(results, pageResult{URL: pageURL, Links: pageLinks})
		}
		if !opt.onePage {
			for _, link := range links {
				if sameSite(base, link) && allowedByPatterns(opt, link) {
					if u, err := url.Parse(link); err == nil && (u.Scheme == "http" || u.Scheme == "https") {
						if u.Fragment != "" && !opt.ignoreFragment {
							continue
						}
						walk(link)
					}
				}
			}
		}
	}

	walk(opt.url)
	return results, failed
}

func checkLink(opt options, fetch func(string) fetched, raw string) linkResult {
	display := raw
	check := raw
	if opt.ignoreFragment {
		check = stripFragment(raw)
	}
	f := fetch(check)
	res := linkResult{URL: display}
	if f.err != nil {
		res.Error = f.err.Error()
		return res
	}
	if !opt.accepted.ok(f.status) {
		res.Error = strconv.Itoa(f.status)
		return res
	}
	if !opt.ignoreFragment {
		if u, err := url.Parse(raw); err == nil && u.Fragment != "" {
			if !hasFragment(f.body, u.Fragment) {
				res.Error = "id #" + u.Fragment + " not found"
				return res
			}
		}
	}
	res.Status = strconv.Itoa(f.status)
	return res
}

func allowedByPatterns(opt options, s string) bool {
	for _, re := range opt.excludes {
		if re.MatchString(s) {
			return false
		}
	}
	if len(opt.includes) == 0 {
		return true
	}
	for _, re := range opt.includes {
		if re.MatchString(s) {
			return true
		}
	}
	return false
}

func sameSite(base *url.URL, raw string) bool {
	u, err := url.Parse(raw)
	if err != nil {
		return false
	}
	return (u.Scheme == "http" || u.Scheme == "https") && strings.EqualFold(u.Host, base.Host)
}

func stripFragment(raw string) string {
	u, err := url.Parse(raw)
	if err != nil {
		return raw
	}
	u.Fragment = ""
	return u.String()
}

func isHTML(ctype string, body []byte) bool {
	if strings.Contains(strings.ToLower(ctype), "html") {
		return true
	}
	return bytes.Contains(bytes.ToLower(body[:min(len(body), 256)]), []byte("<html"))
}

func min(a, b int) int {
	if a < b {
		return a
	}
	return b
}

var attrRE = regexp.MustCompile(`(?is)\b(?:href|src|action)\s*=\s*("[^"]*"|'[^']*'|[^\s>]+)`)

func extractLinks(pageURL string, body []byte) []string {
	base, err := url.Parse(pageURL)
	if err != nil {
		return nil
	}
	seen := map[string]bool{}
	var out []string
	for _, m := range attrRE.FindAllSubmatch(body, -1) {
		v := strings.TrimSpace(string(m[1]))
		v = strings.Trim(v, `"'`)
		if v == "" || strings.HasPrefix(strings.ToLower(v), "javascript:") || strings.HasPrefix(strings.ToLower(v), "mailto:") || strings.HasPrefix(strings.ToLower(v), "tel:") {
			continue
		}
		u, err := url.Parse(v)
		if err != nil {
			continue
		}
		abs := base.ResolveReference(u)
		abs.RawQuery = strings.ReplaceAll(abs.RawQuery, "&amp;", "&")
		s := abs.String()
		if !seen[s] {
			seen[s] = true
			out = append(out, s)
		}
	}
	return out
}

func hasFragment(body []byte, id string) bool {
	q := regexp.QuoteMeta(id)
	re := regexp.MustCompile(`(?is)\b(?:id|name)\s*=\s*["']?` + q + `(?:["'\s>])`)
	return re.Match(body)
}

func writeText(out io.Writer, results []pageResult, verbose bool) {
	for _, page := range results {
		visible := 0
		for _, link := range page.Links {
			if verbose || link.Error != "" {
				visible++
			}
		}
		if visible == 0 {
			continue
		}
		fmt.Fprintln(out, page.URL)
		for _, link := range page.Links {
			if link.Error != "" {
				fmt.Fprintf(out, "\t%s\t%s\n", link.Error, link.URL)
			} else if verbose {
				fmt.Fprintf(out, "\t%s\t%s\n", link.Status, link.URL)
			}
		}
	}
}

func writeJSON(out io.Writer, results []pageResult, verbose bool) {
	if !verbose {
		var filtered []pageResult
		for _, page := range results {
			var links []linkResult
			for _, link := range page.Links {
				if link.Error != "" {
					links = append(links, linkResult{URL: link.URL, Error: link.Error})
				}
			}
			if len(links) > 0 {
				sort.Slice(links, func(i, j int) bool { return links[i].URL < links[j].URL })
				filtered = append(filtered, pageResult{URL: page.URL, Links: links})
			}
		}
		results = filtered
	}
	b, _ := json.Marshal(results)
	fmt.Fprintln(out, string(b))
}

type testsuites struct {
	XMLName xml.Name    `xml:"testsuites"`
	Suites  []testsuite `xml:"testsuite"`
}

type testsuite struct {
	Name     string     `xml:"name,attr"`
	Tests    int        `xml:"tests,attr"`
	Failures int        `xml:"failures,attr"`
	Skipped  int        `xml:"skipped,attr"`
	Cases    []testcase `xml:"testcase"`
}

type testcase struct {
	Name      string   `xml:"name,attr"`
	Classname string   `xml:"classname,attr"`
	Failure   *failure `xml:"failure,omitempty"`
}

type failure struct {
	Message string `xml:"message,attr"`
}

func writeJUnit(out io.Writer, results []pageResult) {
	var suites testsuites
	for _, page := range results {
		ts := testsuite{Name: page.URL, Tests: len(page.Links), Skipped: 0}
		for _, link := range page.Links {
			tc := testcase{Name: link.URL, Classname: page.URL}
			if link.Error != "" {
				ts.Failures++
				tc.Failure = &failure{Message: link.Error}
			}
			ts.Cases = append(ts.Cases, tc)
		}
		suites.Suites = append(suites.Suites, ts)
	}
	b, _ := xml.MarshalIndent(suites, "", "  ")
	fmt.Fprintln(out, xml.Header+string(b))
}
