module muffetclone

go 1.20
