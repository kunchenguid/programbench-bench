#!/bin/bash
set -euo pipefail
BIN=${BIN:-./executable.new}
fail() { echo "FAIL: $1" >&2; exit 1; }
run_capture() {
  local name=$1; shift
  set +e
  "$BIN" "$@" >"/tmp/${name}.out" 2>"/tmp/${name}.err"
  local status=$?
  set -e
  echo "$status" >"/tmp/${name}.status"
}
assert_status() {
  local name=$1 expected=$2
  local got; got=$(cat "/tmp/${name}.status")
  [[ "$got" == "$expected" ]] || fail "$name status: expected $expected got $got"
}
assert_stdout_eq() {
  local name=$1 expected=$2
  local got; got=$(cat "/tmp/${name}.out")
  [[ "$got" == "$expected" ]] || fail "$name stdout mismatch: got [$got]"
}
assert_stderr_eq() {
  local name=$1 expected=$2
  local got; got=$(cat "/tmp/${name}.err")
  [[ "$got" == "$expected" ]] || fail "$name stderr mismatch: got [$got]"
}
assert_stdout_contains() {
  local name=$1 needle=$2
  grep -Fq "$needle" "/tmp/${name}.out" || fail "$name stdout missing [$needle]"
}

run_capture help --help
assert_status help 0
assert_stderr_eq help ""
assert_stdout_contains help "Usage:"
assert_stdout_contains help "  pingu [OPTIONS] HOST"
assert_stdout_contains help "  -c, --count=     Stop after <count> replies (default: 20)"
[[ $(wc -l </tmp/help.out) == "13" ]] || fail "help line count mismatch"
python3 - <<'PY' || fail "help should end with a blank line"
from pathlib import Path
raise SystemExit(0 if Path("/tmp/help.out").read_bytes().endswith(b"\n\n") else 1)
PY

run_capture short_help -h
assert_status short_help 0
cmp -s /tmp/help.out /tmp/short_help.out || fail "-h differs from --help"

run_capture version --version
assert_status version 0
assert_stdout_eq version "pingu: v-rev9c2e3df"
assert_stderr_eq version ""

run_capture missing
assert_status missing 1
assert_stdout_eq missing ""
assert_stderr_eq missing "[ ERROR ] must requires an argument"

run_capture bogus --bogus
assert_status bogus 1
assert_stdout_eq bogus ""
bogus_expected=$(printf 'unknown flag `bogus'\''\n[ ERROR ] parse error: unknown flag `bogus'\''')
assert_stderr_eq bogus "$bogus_expected"

run_capture too_many 127.0.0.1 extra
assert_status too_many 1
assert_stdout_eq too_many ""
assert_stderr_eq too_many "[ ERROR ] too many arguments"

run_capture bad_count -c abc 127.0.0.1
assert_status bad_count 1
assert_stdout_eq bad_count ""
bad_count_expected=$(printf 'invalid argument for flag `-c, --count'\'' (expected int): strconv.ParseInt: parsing "abc": invalid syntax\n[ ERROR ] parse error: invalid argument for flag `-c, --count'\'' (expected int): strconv.ParseInt: parsing "abc": invalid syntax')
assert_stderr_eq bad_count "$bad_count_expected"

run_capture local_once -c 1 127.0.0.1
assert_status local_once 0
assert_stderr_eq local_once ""
assert_stdout_contains local_once "PING 127.0.0.1 (127.0.0.1) type \`Ctrl-C\` to abort"
assert_stdout_contains local_once "seq=0 32bytes from 127.0.0.1: ttl=64 time="
assert_stdout_contains local_once "───────── 127.0.0.1 ping statistics ─────────"
assert_stdout_contains local_once "PACKET STATISTICS: 1 transmitted => 1 received (0% loss)"
assert_stdout_contains local_once "ROUND TRIP: min="

run_capture localhost_once -c 1 localhost
assert_status localhost_once 0
assert_stdout_contains localhost_once "PING localhost (127.0.0.1) type \`Ctrl-C\` to abort"

run_capture local_twice --count=2 127.0.0.1
assert_status local_twice 0
assert_stdout_contains local_twice "seq=0 32bytes from 127.0.0.1: ttl=64 time="
assert_stdout_contains local_twice "seq=1 32bytes from 127.0.0.1: ttl=64 time="
assert_stdout_contains local_twice "PACKET STATISTICS: 2 transmitted => 2 received (0% loss)"

run_capture privileged -P -c 1 127.0.0.1
assert_status privileged 2
assert_stdout_eq privileged "PING 127.0.0.1 (127.0.0.1) type \`Ctrl-C\` to abort"
assert_stderr_eq privileged "[ ERROR ] an error occurred when running ping: listen ip4:icmp : socket: operation not permitted"

run_capture short_count_joined -c1 127.0.0.1
assert_status short_count_joined 0
assert_stdout_contains short_count_joined "PACKET STATISTICS: 1 transmitted => 1 received (0% loss)"

run_capture short_count_equals -c=1 127.0.0.1
assert_status short_count_equals 0
assert_stdout_contains short_count_equals "PACKET STATISTICS: 1 transmitted => 1 received (0% loss)"

run_capture unresolved -c 1 invalid.invalid
assert_status unresolved 0
assert_stdout_eq unresolved ""
grep -Fq "[ ERROR ] an error occurred while initializing pinger: failed to init pinger lookup invalid.invalid" /tmp/unresolved.err || fail "unresolved stderr missing init error"
