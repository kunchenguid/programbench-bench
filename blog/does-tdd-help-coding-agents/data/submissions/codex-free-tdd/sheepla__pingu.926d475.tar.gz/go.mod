module pingu-reimplementation

go 1.20
