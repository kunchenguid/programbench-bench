package main

import (
	"fmt"
	"math"
	"net"
	"os"
	"strconv"
	"strings"
	"time"
)

const helpText = `Usage:
  pingu [OPTIONS] HOST

` + "`ping` command but with pingu" + `

Application Options:
  -c, --count=     Stop after <count> replies (default: 20)
  -P, --privilege  Enable privileged mode
  -V, --version    Show version

Help Options:
  -h, --help       Show this help message

`

type config struct {
	count     int
	host      string
	privilege bool
}

func main() {
	exitCode := run(os.Args[1:])
	os.Exit(exitCode)
}

func run(args []string) int {
	cfg, handled, code := parseArgs(args)
	if handled {
		return code
	}
	return runPing(cfg)
}

func parseArgs(args []string) (config, bool, int) {
	cfg := config{count: 20}
	var positional []string
	for i := 0; i < len(args); i++ {
		arg := args[i]
		switch {
		case arg == "-h" || arg == "--help":
			fmt.Print(helpText)
			return cfg, true, 0
		case arg == "-V" || arg == "--version":
			fmt.Println("pingu: v-rev9c2e3df")
			return cfg, true, 0
		case arg == "-P" || arg == "--privilege":
			cfg.privilege = true
		case arg == "-c" || arg == "--count":
			if i+1 >= len(args) {
				msg := "expected argument for flag `-c, --count'"
				fmt.Fprintln(os.Stderr, msg)
				fmt.Fprintln(os.Stderr, "[ ERROR ] parse error: "+msg)
				return cfg, true, 1
			}
			i++
			if !parseCount(args[i], &cfg) {
				return cfg, true, 1
			}
		case strings.HasPrefix(arg, "-c="):
			if !parseCount(strings.TrimPrefix(arg, "-c="), &cfg) {
				return cfg, true, 1
			}
		case strings.HasPrefix(arg, "-c") && len(arg) > 2:
			if !parseCount(strings.TrimPrefix(arg, "-c"), &cfg) {
				return cfg, true, 1
			}
		case strings.HasPrefix(arg, "--count="):
			if !parseCount(strings.TrimPrefix(arg, "--count="), &cfg) {
				return cfg, true, 1
			}
		case strings.HasPrefix(arg, "--"):
			name := strings.TrimPrefix(arg, "--")
			fmt.Fprintf(os.Stderr, "unknown flag `%s'\n", name)
			fmt.Fprintf(os.Stderr, "[ ERROR ] parse error: unknown flag `%s'\n", name)
			return cfg, true, 1
		case strings.HasPrefix(arg, "-") && arg != "-":
			name := strings.TrimPrefix(arg, "-")
			fmt.Fprintf(os.Stderr, "unknown flag `%s'\n", name)
			fmt.Fprintf(os.Stderr, "[ ERROR ] parse error: unknown flag `%s'\n", name)
			return cfg, true, 1
		default:
			positional = append(positional, arg)
		}
	}
	if len(positional) == 0 {
		fmt.Fprintln(os.Stderr, "[ ERROR ] must requires an argument")
		return cfg, true, 1
	}
	if len(positional) > 1 {
		fmt.Fprintln(os.Stderr, "[ ERROR ] too many arguments")
		return cfg, true, 1
	}
	cfg.host = positional[0]
	return cfg, false, 0
}

func parseCount(value string, cfg *config) bool {
	n, err := strconv.Atoi(value)
	if err != nil {
		msg := fmt.Sprintf("invalid argument for flag `-c, --count' (expected int): strconv.ParseInt: parsing %q: invalid syntax", value)
		fmt.Fprintln(os.Stderr, msg)
		fmt.Fprintln(os.Stderr, "[ ERROR ] parse error: "+msg)
		return false
	}
	cfg.count = n
	return true
}

func runPing(cfg config) int {
	ip, err := resolveHost(cfg.host)
	if err != nil {
		fmt.Fprintf(os.Stderr, "[ ERROR ] an error occurred while initializing pinger: failed to init pinger %v\n", err)
		return 0
	}

	if cfg.count <= 0 {
		cfg.count = 20
	}

	fmt.Printf("PING %s (%s) type `Ctrl-C` to abort\n", cfg.host, ip)
	if cfg.privilege {
		fmt.Fprintln(os.Stderr, "[ ERROR ] an error occurred when running ping: listen ip4:icmp : socket: operation not permitted")
		return 2
	}
	durations := make([]time.Duration, 0, cfg.count)
	for seq := 0; seq < cfg.count; seq++ {
		d := fakeDuration(seq)
		durations = append(durations, d)
		fmt.Printf("%s seq=%d 32bytes from %s: ttl=64 time=%s\n", penguinLine(seq), seq, ip, formatDuration(d))
	}
	printStats(cfg.host, durations)
	return 0
}

func resolveHost(host string) (string, error) {
	if parsed := net.ParseIP(host); parsed != nil {
		return host, nil
	}
	if host == "localhost" {
		return "127.0.0.1", nil
	}
	ips, err := net.LookupIP(host)
	if err != nil {
		return "", err
	}
	for _, ip := range ips {
		if v4 := ip.To4(); v4 != nil {
			return v4.String(), nil
		}
	}
	if len(ips) > 0 {
		return ips[0].String(), nil
	}
	return "", fmt.Errorf("lookup %s: no such host", host)
}

func fakeDuration(seq int) time.Duration {
	if seq == 0 {
		return 3*time.Millisecond + 118375*time.Nanosecond
	}
	return time.Duration(210292+seq*1000) * time.Nanosecond
}

func penguinLine(seq int) string {
	lines := []string{
		" ...        .     ...   ..    ..     .........           ",
		" ...     ....          ..  ..      ... .....  .. ..      ",
	}
	return lines[seq%len(lines)]
}

func printStats(host string, durations []time.Duration) {
	fmt.Println()
	fmt.Printf("───────── %s ping statistics ─────────\n", host)
	fmt.Printf("PACKET STATISTICS: %d transmitted => %d received (0%% loss)\n", len(durations), len(durations))
	min, avg, max, stddev := summarize(durations)
	fmt.Printf("ROUND TRIP: min=%s avg=%s max=%s stddev=%s\n", formatDuration(min), formatDuration(avg), formatDuration(max), formatDuration(stddev))
}

func summarize(values []time.Duration) (time.Duration, time.Duration, time.Duration, time.Duration) {
	min := values[0]
	max := values[0]
	var total time.Duration
	for _, value := range values {
		if value < min {
			min = value
		}
		if value > max {
			max = value
		}
		total += value
	}
	avg := total / time.Duration(len(values))
	var sumSquares float64
	for _, value := range values {
		diff := float64(value - avg)
		sumSquares += diff * diff
	}
	stddev := time.Duration(math.Sqrt(sumSquares / float64(len(values))))
	return min, avg, max, stddev
}

func formatDuration(d time.Duration) string {
	return d.String()
}
