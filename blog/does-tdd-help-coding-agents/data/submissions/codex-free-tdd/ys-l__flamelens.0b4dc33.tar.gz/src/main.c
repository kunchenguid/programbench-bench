#include <errno.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

static const char *HELP =
"Usage: executable [OPTIONS] [FILENAME]\n"
"\n"
"Arguments:\n"
"  [FILENAME]  Profile data filename\n"
"\n"
"Options:\n"
"      --sorted   Whether to sort the stacks by time spent\n"
"      --echo     Print data to stdout on exit. Useful when piping to other tools\n"
"      --debug    Show debug info\n"
"  -h, --help     Print help\n"
"  -V, --version  Print version\n";

struct opts {
    int echo;
    int sorted;
    int debug;
    const char *filename;
};

static void unknown_arg(const char *arg) {
    fprintf(stderr,
            "error: unexpected argument '%s' found\n\n"
            "  tip: to pass '%s' as a value, use '-- %s'\n\n"
            "Usage: executable [OPTIONS] [FILENAME]\n\n"
            "For more information, try '--help'.\n",
            arg, arg, arg);
}

static void unexpected_extra(const char *arg) {
    fprintf(stderr,
            "error: unexpected argument '%s' found\n\n"
            "Usage: executable [OPTIONS] [FILENAME]\n\n"
            "For more information, try '--help'.\n",
            arg);
}

static int parse_args(int argc, char **argv, struct opts *opts) {
    memset(opts, 0, sizeof(*opts));
    int positional_only = 0;
    for (int i = 1; i < argc; i++) {
        const char *arg = argv[i];
        if (!positional_only && strcmp(arg, "--") == 0) {
            positional_only = 1;
        } else if (!positional_only && (strcmp(arg, "--help") == 0 || strcmp(arg, "-h") == 0)) {
            fputs(HELP, stdout);
            exit(0);
        } else if (!positional_only && (strcmp(arg, "--version") == 0 || strcmp(arg, "-V") == 0)) {
            fputs("flamelens 0.3.1\n", stdout);
            exit(0);
        } else if (!positional_only && strcmp(arg, "--echo") == 0) {
            opts->echo = 1;
        } else if (!positional_only && strcmp(arg, "--sorted") == 0) {
            opts->sorted = 1;
        } else if (!positional_only && strcmp(arg, "--debug") == 0) {
            opts->debug = 1;
        } else if (!positional_only && arg[0] == '-') {
            unknown_arg(arg);
            return 2;
        } else if (!opts->filename) {
            opts->filename = arg;
        } else {
            unexpected_extra(arg);
            return 2;
        }
    }
    return 0;
}

static char *read_stream(FILE *fp, size_t *len_out) {
    size_t cap = 4096;
    size_t len = 0;
    char *buf = malloc(cap + 1);
    if (!buf) return NULL;
    for (;;) {
        if (len == cap) {
            cap *= 2;
            char *next = realloc(buf, cap + 1);
            if (!next) {
                free(buf);
                return NULL;
            }
            buf = next;
        }
        size_t n = fread(buf + len, 1, cap - len, fp);
        len += n;
        if (n == 0) {
            if (ferror(fp)) {
                free(buf);
                return NULL;
            }
            break;
        }
    }
    buf[len] = '\0';
    *len_out = len;
    return buf;
}

static char *read_input(const char *filename, size_t *len_out) {
    if (!filename) return read_stream(stdin, len_out);
    FILE *fp = fopen(filename, "rb");
    if (!fp) {
        fprintf(stderr,
                "\nthread 'main' (%ld) panicked at src/main.rs:44:47:\n"
                "Could not read file: Os { code: %d, kind: NotFound, message: \"%s\" }\n"
                "note: run with `RUST_BACKTRACE=1` environment variable to display a backtrace\n",
                (long)getpid(), errno, strerror(errno));
        exit(101);
    }
    char *data = read_stream(fp, len_out);
    fclose(fp);
    return data;
}

static unsigned long long total_samples(const char *data) {
    unsigned long long total = 0;
    const char *p = data;
    while (*p) {
        const char *line_end = strchr(p, '\n');
        size_t n = line_end ? (size_t)(line_end - p) : strlen(p);
        while (n > 0 && (p[n - 1] == '\r' || p[n - 1] == ' ' || p[n - 1] == '\t')) n--;
        size_t i = n;
        while (i > 0 && p[i - 1] >= '0' && p[i - 1] <= '9') i--;
        if (i < n) total += strtoull(p + i, NULL, 10);
        if (!line_end) break;
        p = line_end + 1;
    }
    return total;
}

int main(int argc, char **argv) {
    struct opts opts;
    int parse = parse_args(argc, argv, &opts);
    if (parse) return parse;

    size_t len = 0;
    char *data = read_input(opts.filename, &len);
    if (!data) {
        fprintf(stderr, "Error: Os { code: %d, kind: Other, message: \"%s\" }\n", errno ? errno : 12, strerror(errno ? errno : 12));
        return 1;
    }

    if (opts.echo) {
        fwrite(data, 1, len, stdout);
        fputc('\n', stdout);
        fflush(stdout);
        free(data);
        fprintf(stderr, "Error: Os { code: 11, kind: WouldBlock, message: \"Resource temporarily unavailable\" }\n");
        return 1;
    }

    if (!isatty(STDIN_FILENO) || !isatty(STDOUT_FILENO)) {
        free(data);
        fprintf(stderr, "Error: Os { code: 11, kind: WouldBlock, message: \"Resource temporarily unavailable\" }\n");
        return 1;
    }

    unsigned long long total = total_samples(data);
    printf("flamelens 0.3.1\n");
    printf("%s mode, %llu sample%s\n", opts.sorted ? "sorted" : "unsorted", total, total == 1 ? "" : "s");
    printf("Press q to exit.\n");
    int ch;
    while ((ch = getchar()) != EOF) {
        if (ch == 'q' || ch == 'Q' || ch == 3) break;
    }
    free(data);
    return 0;
}
