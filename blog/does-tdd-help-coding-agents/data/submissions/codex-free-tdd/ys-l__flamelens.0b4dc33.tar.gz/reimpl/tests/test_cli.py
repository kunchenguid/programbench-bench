import os
import subprocess
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
BIN = ROOT / "executable"


def run_cmd(args, input_data=None):
    return subprocess.run([str(BIN), *args], input=input_data, text=True, capture_output=True)


def test_help_matches_shipped_cli_contract():
    result = run_cmd(["--help"])
    assert result.returncode == 0
    assert result.stderr == ""
    assert result.stdout == """Usage: executable [OPTIONS] [FILENAME]\n\nArguments:\n  [FILENAME]  Profile data filename\n\nOptions:\n      --sorted   Whether to sort the stacks by time spent\n      --echo     Print data to stdout on exit. Useful when piping to other tools\n      --debug    Show debug info\n  -h, --help     Print help\n  -V, --version  Print version\n"""


def test_version_matches_original():
    result = run_cmd(["--version"])
    assert result.returncode == 0
    assert result.stdout == "flamelens 0.3.1\n"
    assert result.stderr == ""


def test_unknown_flag_uses_clap_style_error():
    result = run_cmd(["--nope"])
    assert result.returncode == 2
    assert result.stdout == ""
    assert result.stderr == """error: unexpected argument '--nope' found\n\n  tip: to pass '--nope' as a value, use '-- --nope'\n\nUsage: executable [OPTIONS] [FILENAME]\n\nFor more information, try '--help'.\n"""


def test_echo_preserves_stdin_folded_data_and_trailing_blank_line():
    result = run_cmd(["--echo"], "a;b;c 3\na;b;d 2\n")
    assert result.returncode == 1
    assert result.stdout == "a;b;c 3\na;b;d 2\n\n"
    assert "Error: Os { code:" in result.stderr


def test_echo_preserves_file_folded_data_and_trailing_blank_line(tmp_path):
    sample = tmp_path / "sample.folded"
    sample.write_text("a;b;c 3\nx 5\n")
    result = run_cmd(["--echo", str(sample)])
    assert result.returncode == 1
    assert result.stdout == "a;b;c 3\nx 5\n\n"
    assert "Error: Os { code:" in result.stderr


def test_double_dash_allows_dash_prefixed_filename():
    result = run_cmd(["--", "--nope"])
    assert result.returncode == 101
    assert result.stdout == ""
    assert "panicked at src/main.rs:44:47:" in result.stderr
    assert "Could not read file: Os { code: 2, kind: NotFound, message: \"No such file or directory\" }" in result.stderr


def test_second_positional_is_unexpected_without_tip():
    result = run_cmd(["one", "two"])
    assert result.returncode == 2
    assert result.stderr == """error: unexpected argument 'two' found\n\nUsage: executable [OPTIONS] [FILENAME]\n\nFor more information, try '--help'.\n"""
