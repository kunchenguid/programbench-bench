#define _POSIX_C_SOURCE 199309L

#include <ctype.h>
#include <errno.h>
#include <fcntl.h>
#include <signal.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/ioctl.h>
#include <termios.h>
#include <time.h>
#include <unistd.h>

typedef struct {
    int async;
    int bold;
    int all_bold;
    int no_bold;
    int old_style;
    int screensaver;
    int lambda;
    int rainbow;
    int change;
    int shadow;
    int lock;
    int xwindow;
    int linux_mode;
    int force_linux;
    int delay;
    int color_code;
    const char *message;
    const char *tty;
} Options;

static volatile sig_atomic_t stop_requested = 0;
static struct termios saved_termios;
static int termios_saved = 0;

static const char *usage_text =
" Usage: cmatrix -[abBcfhlsmVxk] [-u delay] [-C color] [-t tty] [-M message]\n"
" -a: Asynchronous scroll\n"
" -b: Bold characters on\n"
" -B: All bold characters (overrides -b)\n"
" -c: Use Japanese characters as seen in the original matrix. Requires appropriate fonts\n"
" -f: Force the linux $TERM type to be on\n"
" -l: Linux mode (uses matrix console font)\n"
" -L: Lock mode (can be closed from another terminal)\n"
" -o: Use old-style scrolling\n"
" -h: Print usage and exit\n"
" -n: No bold characters (overrides -b and -B, default)\n"
" -s: \"Screensaver\" mode, exits on first keystroke\n"
" -x: X window mode, use if your xterm is using mtx.pcf\n"
" -V: Print version information and exit\n"
" -M [message]: Prints your message in the center of the screen. Overrides -L's default message.\n"
" -u delay (0 - 10, default 4): Screen update delay\n"
" -C [color]: Use this color for matrix (default green)\n"
" -r: rainbow mode\n"
" -m: lambda mode\n"
" -k: Characters change while scrolling. (Works without -o opt.)\n"
" -t [tty]: Set tty to use\n";

static void print_usage(void) {
    fputs(usage_text, stdout);
}

static void print_version(void) {
    printf(" CMatrix version 2.0 (compiled %s, %s)\n", __TIME__, __DATE__);
    puts("Email: abishekvashok@gmail.com");
    puts("Web: https://github.com/abishekvashok/cmatrix");
}

static int color_code_for(const char *name) {
    char lower[32];
    size_t len = strlen(name);
    if (len >= sizeof(lower)) return -1;
    for (size_t i = 0; i <= len; i++) {
        lower[i] = (char)tolower((unsigned char)name[i]);
    }
    if (strcmp(lower, "green") == 0) return 32;
    if (strcmp(lower, "red") == 0) return 31;
    if (strcmp(lower, "blue") == 0) return 34;
    if (strcmp(lower, "white") == 0) return 37;
    if (strcmp(lower, "yellow") == 0) return 33;
    if (strcmp(lower, "cyan") == 0) return 36;
    if (strcmp(lower, "magenta") == 0) return 35;
    if (strcmp(lower, "black") == 0) return 30;
    return -1;
}

static int need_arg(int *i, int argc) {
    if (*i + 1 >= argc) {
        print_usage();
        return 0;
    }
    (*i)++;
    return 1;
}

static int parse_args(int argc, char **argv, Options *opt) {
    opt->delay = 4;
    opt->color_code = 32;

    for (int i = 1; i < argc; i++) {
        char *arg = argv[i];
        if (arg[0] != '-' || arg[1] == '\0') {
            print_usage();
            return 0;
        }
        if (strcmp(arg, "--help") == 0) {
            print_usage();
            return 0;
        }
        if (strcmp(arg, "--version") == 0) {
            print_usage();
            return 0;
        }

        for (int j = 1; arg[j] != '\0'; j++) {
            switch (arg[j]) {
            case 'a': opt->async = 1; break;
            case 'b': opt->bold = 1; break;
            case 'B': opt->all_bold = 1; break;
            case 'c': opt->shadow = 1; break;
            case 'f': opt->force_linux = 1; break;
            case 'l': opt->linux_mode = 1; break;
            case 'L': opt->lock = 1; break;
            case 'o': opt->old_style = 1; break;
            case 'n': opt->no_bold = 1; break;
            case 's': opt->screensaver = 1; break;
            case 'x': opt->xwindow = 1; break;
            case 'r': opt->rainbow = 1; break;
            case 'm': opt->lambda = 1; break;
            case 'k': opt->change = 1; break;
            case 'h':
            case '?':
                print_usage();
                return 0;
            case 'V':
                print_version();
                return 0;
            case 'u':
                if (arg[j + 1] != '\0' || !need_arg(&i, argc)) return 0;
                opt->delay = atoi(argv[i]);
                j = (int)strlen(arg) - 1;
                break;
            case 'C': {
                if (arg[j + 1] != '\0' || !need_arg(&i, argc)) return 0;
                int code = color_code_for(argv[i]);
                if (code < 0) {
                    puts(" Invalid color selection");
                    puts(" Valid colors are green, red, blue, white, yellow, cyan, magenta and black.");
                    return 0;
                }
                opt->color_code = code;
                j = (int)strlen(arg) - 1;
                break;
            }
            case 'M':
                if (arg[j + 1] != '\0' || !need_arg(&i, argc)) return 0;
                opt->message = argv[i];
                j = (int)strlen(arg) - 1;
                break;
            case 't':
                if (arg[j + 1] != '\0' || !need_arg(&i, argc)) return 0;
                opt->tty = argv[i];
                j = (int)strlen(arg) - 1;
                break;
            default:
                print_usage();
                return 0;
            }
        }
    }
    return 1;
}

static void on_signal(int sig) {
    (void)sig;
    stop_requested = 1;
}

static void restore_terminal(void) {
    if (termios_saved) {
        tcsetattr(STDIN_FILENO, TCSANOW, &saved_termios);
    }
    fputs("\033[39;49m\033(B\033[m\033[?25h\033[?1049l", stdout);
    fflush(stdout);
}

static void setup_terminal_input(void) {
    if (tcgetattr(STDIN_FILENO, &saved_termios) == 0) {
        struct termios raw = saved_termios;
        termios_saved = 1;
        raw.c_lflag &= (tcflag_t)~(ICANON | ECHO);
        raw.c_cc[VMIN] = 0;
        raw.c_cc[VTIME] = 0;
        tcsetattr(STDIN_FILENO, TCSANOW, &raw);
    }
    int flags = fcntl(STDIN_FILENO, F_GETFL, 0);
    if (flags >= 0) fcntl(STDIN_FILENO, F_SETFL, flags | O_NONBLOCK);
}

static void terminal_size(int *rows, int *cols) {
    struct winsize ws;
    *rows = 24;
    *cols = 80;
    if (ioctl(STDOUT_FILENO, TIOCGWINSZ, &ws) == 0) {
        if (ws.ws_row > 0) *rows = ws.ws_row;
        if (ws.ws_col > 0) *cols = ws.ws_col;
    }
}

static char matrix_char(const Options *opt) {
    static const char glyphs[] =
        "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789"
        "@#$%^&*+-=<>[]{}";
    if (opt->lambda) return '\\';
    return glyphs[rand() % (int)(sizeof(glyphs) - 1)];
}

static int rainbow_code(void) {
    static const int colors[] = {31, 32, 33, 34, 35, 36, 37};
    return colors[rand() % 7];
}

static void draw_message(const char *msg, int rows, int cols) {
    if (!msg || !*msg) return;
    int len = (int)strlen(msg);
    int col = (cols - len) / 2;
    if (col < 0) col = 0;
    printf("\033[%d;%dH\033[37m%s", rows / 2, col + 1, msg);
}

static int read_key(void) {
    unsigned char ch;
    ssize_t n = read(STDIN_FILENO, &ch, 1);
    if (n == 1) return ch;
    return -1;
}

static void run_animation(const Options *opt) {
    int rows, cols;
    terminal_size(&rows, &cols);
    int *heads = calloc((size_t)cols, sizeof(int));
    int *speed = calloc((size_t)cols, sizeof(int));
    if (!heads || !speed) {
        free(heads);
        free(speed);
        return;
    }
    for (int c = 0; c < cols; c++) {
        heads[c] = -(rand() % rows);
        speed[c] = 1 + (rand() % 4);
    }

    fputs("\033[?1049h\033[22;0;0t\033[1;24r\033(B\033[m\033[4l\033[?7h"
          "\033[?25l\033[39;49m\033[H\033[2J", stdout);
    fflush(stdout);

    setup_terminal_input();
    atexit(restore_terminal);
    signal(SIGINT, on_signal);
    signal(SIGTERM, on_signal);
    signal(SIGHUP, on_signal);

    const char *lock_message = opt->message ? opt->message : "Computer locked.";
    int frame = 0;
    while (!stop_requested) {
        int key = read_key();
        if (key >= 0) {
            if (opt->screensaver) break;
            if (key == 'q' && !opt->lock) break;
        }

        for (int c = 0; c < cols; c++) {
            if (opt->async && (frame % speed[c]) != 0) continue;
            int row = heads[c];
            if (row >= 0 && row < rows) {
                int code = opt->rainbow ? rainbow_code() : opt->color_code;
                if (opt->all_bold || (opt->bold && (rand() % 3 == 0))) {
                    printf("\033[%d;%dH\033[1;%dm%c", row + 1, c + 1, code, matrix_char(opt));
                } else if (opt->shadow) {
                    printf("\033[%d;%dH\033[2;%dm%c", row + 1, c + 1, code, matrix_char(opt));
                } else {
                    printf("\033[%d;%dH\033[%dm%c", row + 1, c + 1, code, matrix_char(opt));
                }
            }
            int tail = row - 8 - (rand() % 10);
            if (tail >= 0 && tail < rows) {
                printf("\033[%d;%dH ", tail + 1, c + 1);
            }
            heads[c]++;
            if (heads[c] > rows + 20) heads[c] = -(rand() % rows);
        }
        if (opt->message || opt->lock) draw_message(opt->lock ? lock_message : opt->message, rows, cols);
        fflush(stdout);
        int delay = opt->delay;
        if (delay < 0) delay = 0;
        if (delay > 10) delay = 10;
        struct timespec pause_for;
        long micros = 20000L + delay * 15000L;
        pause_for.tv_sec = micros / 1000000L;
        pause_for.tv_nsec = (micros % 1000000L) * 1000L;
        nanosleep(&pause_for, NULL);
        frame++;
    }

    free(heads);
    free(speed);
}

int main(int argc, char **argv) {
    Options opt;
    memset(&opt, 0, sizeof(opt));

    if (!parse_args(argc, argv, &opt)) return 0;

    if (opt.tty) {
        int fd = open(opt.tty, O_WRONLY);
        if (fd < 0) return 1;
        if (dup2(fd, STDOUT_FILENO) < 0) return 1;
        close(fd);
    }

    const char *term = getenv("TERM");
    if (!term || strcmp(term, "unknown") == 0 || strcmp(term, "dumb") == 0) {
        fprintf(stderr, "Error opening terminal: %s.\n", term ? term : "unknown");
        return 1;
    }

    srand((unsigned int)(time(NULL) ^ getpid()));
    run_animation(&opt);
    return 0;
}
