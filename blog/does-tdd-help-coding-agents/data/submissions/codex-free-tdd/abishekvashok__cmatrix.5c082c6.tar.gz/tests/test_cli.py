#!/usr/bin/env python3
import os
import re
import subprocess
import unittest


ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
BIN = os.path.join(ROOT, "executable")

USAGE = """ Usage: cmatrix -[abBcfhlsmVxk] [-u delay] [-C color] [-t tty] [-M message]
 -a: Asynchronous scroll
 -b: Bold characters on
 -B: All bold characters (overrides -b)
 -c: Use Japanese characters as seen in the original matrix. Requires appropriate fonts
 -f: Force the linux $TERM type to be on
 -l: Linux mode (uses matrix console font)
 -L: Lock mode (can be closed from another terminal)
 -o: Use old-style scrolling
 -h: Print usage and exit
 -n: No bold characters (overrides -b and -B, default)
 -s: "Screensaver" mode, exits on first keystroke
 -x: X window mode, use if your xterm is using mtx.pcf
 -V: Print version information and exit
 -M [message]: Prints your message in the center of the screen. Overrides -L's default message.
 -u delay (0 - 10, default 4): Screen update delay
 -C [color]: Use this color for matrix (default green)
 -r: rainbow mode
 -m: lambda mode
 -k: Characters change while scrolling. (Works without -o opt.)
 -t [tty]: Set tty to use
"""


class CMatrixCliTests(unittest.TestCase):
    def run_cmd(self, args, env=None, timeout=2):
        merged = os.environ.copy()
        if env:
            merged.update(env)
        return subprocess.run(
            [BIN] + args,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            env=merged,
            timeout=timeout,
            check=False,
        )

    def run_timed_cmd(self, args, env=None, seconds="0.25"):
        merged = os.environ.copy()
        if env:
            merged.update(env)
        return subprocess.run(
            ["timeout", seconds, BIN] + args,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            env=merged,
            check=False,
        )

    def test_help_flag_prints_reference_usage(self):
        result = self.run_cmd(["--help"])
        self.assertEqual(result.returncode, 0)
        self.assertEqual(result.stderr, b"")
        self.assertEqual(result.stdout.decode(), USAGE)

    def test_unknown_option_prints_usage_and_exits_successfully(self):
        result = self.run_cmd(["-Z"])
        self.assertEqual(result.returncode, 0)
        self.assertEqual(result.stdout.decode(), USAGE)

    def test_version_banner_matches_cmatrix_2(self):
        result = self.run_cmd(["-V"])
        self.assertEqual(result.returncode, 0)
        text = result.stdout.decode()
        self.assertRegex(text, r"^ CMatrix version 2\.0 \(compiled .+\)\n")
        self.assertIn("Email: abishekvashok@gmail.com\n", text)
        self.assertIn("Web: https://github.com/abishekvashok/cmatrix\n", text)

    def test_invalid_color_message(self):
        result = self.run_cmd(["-C", "purple"])
        self.assertEqual(result.returncode, 0)
        self.assertEqual(
            result.stdout.decode(),
            " Invalid color selection\n"
            " Valid colors are green, red, blue, white, yellow, cyan, magenta and black.\n",
        )

    def test_color_names_are_case_insensitive(self):
        result = self.run_cmd(["-C", "RED"], env={"TERM": "unknown"})
        self.assertEqual(result.returncode, 1)
        self.assertEqual(result.stdout, b"")
        self.assertEqual(result.stderr.decode(), "Error opening terminal: unknown.\n")

    def test_unknown_terminal_reports_curses_style_error(self):
        result = self.run_cmd([], env={"TERM": "unknown"})
        self.assertEqual(result.returncode, 1)
        self.assertEqual(result.stdout, b"")
        self.assertEqual(result.stderr.decode(), "Error opening terminal: unknown.\n")

    def test_xterm_run_starts_alternate_screen_and_draws_green(self):
        result = self.run_timed_cmd([], env={"TERM": "xterm"})
        combined = result.stdout + result.stderr
        self.assertIn(b"\x1b[?1049h", combined)
        self.assertIn(b"\x1b[32m", combined)


if __name__ == "__main__":
    unittest.main()
