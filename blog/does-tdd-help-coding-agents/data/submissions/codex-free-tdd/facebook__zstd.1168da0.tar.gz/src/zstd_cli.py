#!/usr/bin/env python3
import gzip
import os
import pathlib
import sys


VERSION = "*** Zstandard CLI (64-bit) v1.6.0, by Yann Collet ***"
MAGIC = b"\x28\xb5\x2f\xfd"
CONTENT_UNKNOWN = (1 << 64) - 1
CONTENT_ERROR = (1 << 64) - 2
P1 = 11400714785074694791
P2 = 14029467366897019727
P3 = 1609587929392839161
P4 = 9650029242287828579
P5 = 2870177450012600261
MASK = (1 << 64) - 1


SHORT_HELP = """Compress or decompress the INPUT file(s); reads from STDIN if INPUT is `-` or not provided.

Usage: executable [OPTIONS...] [INPUT... | -] [-o OUTPUT]

Options:
  -o OUTPUT                     Write output to a single file, OUTPUT.
  -k, --keep                    Preserve INPUT file(s). [Default] 
  --rm                          Remove INPUT file(s) after successful (de)compression to file.

  -#                            Desired compression level, where `#` is a number between 1 and 19;
                                lower numbers provide faster compression, higher numbers yield
                                better compression ratios. [Default: 3]

  -d, --decompress              Perform decompression.
  -D DICT                       Use DICT as the dictionary for compression or decompression.

  -f, --force                   Disable input and output checks. Allows overwriting existing files,
                                receiving input from the console, printing output to STDOUT, and
                                operating on links, block devices, etc. Unrecognized formats will be
                                passed-through through as-is.

  -h                            Display short usage and exit.
  -H, --help                    Display full help and exit.
  -V, --version                 Display the program version and exit.
"""

FULL_HELP = VERSION + "\n\n" + SHORT_HELP + """
Advanced options:
  -c, --stdout                  Write to STDOUT (even if it is a console) and keep the INPUT file(s).

  -v, --verbose                 Enable verbose output; pass multiple times to increase verbosity.
  -q, --quiet                   Suppress warnings; pass twice to suppress errors.
  --trace LOG                   Log tracing information to LOG.

  --[no-]progress               Forcibly show/hide the progress counter. NOTE: Any (de)compressed
                                output to terminal will mix with progress counter text.

  -r                            Operate recursively on directories.
  --filelist LIST               Read a list of files to operate on from LIST.
  --output-dir-flat DIR         Store processed files in DIR.
  --output-dir-mirror DIR       Store processed files in DIR, respecting original directory structure.
  --[no-]asyncio                Use asynchronous IO. [Default: Enabled]

  --[no-]check                  Add XXH64 integrity checksums during compression. [Default: Add, Validate]
                                If `-d` is present, ignore/validate checksums during decompression.

Advanced compression options:
  --ultra                       Enable levels beyond 19, up to 22; requires more memory.
  --fast[=#]                    Use to very fast compression levels. [Default: 1]
  --format=zstd                 Compress files to the `.zst` format. [Default]
  --format=gzip                 Compress files to the `.gz` format.

Advanced decompression options:
  -l                            Print information about Zstandard-compressed files.
  --test                        Test compressed file integrity.
"""


class Zstd:
    def __init__(self):
        pass

    def compress(self, data, level):
        header = bytearray(MAGIC)
        size = len(data)
        if size <= 255:
            header.extend([0x24, size])
        elif size <= 65535 + 256:
            header.append(0x64)
            header.extend((size - 256).to_bytes(2, "little"))
        elif size <= 0xffffffff:
            header.append(0xa4)
            header.extend(size.to_bytes(4, "little"))
        else:
            header.append(0xe4)
            header.extend(size.to_bytes(8, "little"))
        pos = 0
        while pos < len(data) or (len(data) == 0 and pos == 0):
            chunk = data[pos:pos + 131072]
            pos += len(chunk)
            last = 1 if pos >= len(data) else 0
            bh = (len(chunk) << 3) | last
            header.extend(bh.to_bytes(3, "little"))
            header.extend(chunk)
            if len(data) == 0:
                break
        header.extend((xxh64(data) & 0xffffffff).to_bytes(4, "little"))
        return bytes(header)

    def frame_size(self, data):
        try:
            _, size, _, _ = parse_frame_header(data)
            return size if size is not None else CONTENT_UNKNOWN
        except Exception:
            return CONTENT_ERROR

    def decompress(self, data):
        return decompress_frame(data)


def rotl(x, n):
    return ((x << n) | (x >> (64 - n))) & MASK


def round64(acc, lane):
    acc = (acc + lane * P2) & MASK
    acc = rotl(acc, 31)
    return (acc * P1) & MASK


def merge_round(acc, val):
    acc ^= round64(0, val)
    return (acc * P1 + P4) & MASK


def xxh64(data):
    i = 0
    ln = len(data)
    if ln >= 32:
        v1 = (P1 + P2) & MASK
        v2 = P2
        v3 = 0
        v4 = (-P1) & MASK
        limit = ln - 32
        while i <= limit:
            v1 = round64(v1, int.from_bytes(data[i:i+8], "little")); i += 8
            v2 = round64(v2, int.from_bytes(data[i:i+8], "little")); i += 8
            v3 = round64(v3, int.from_bytes(data[i:i+8], "little")); i += 8
            v4 = round64(v4, int.from_bytes(data[i:i+8], "little")); i += 8
        h = (rotl(v1, 1) + rotl(v2, 7) + rotl(v3, 12) + rotl(v4, 18)) & MASK
        h = merge_round(h, v1)
        h = merge_round(h, v2)
        h = merge_round(h, v3)
        h = merge_round(h, v4)
    else:
        h = P5
    h = (h + ln) & MASK
    while i + 8 <= ln:
        k1 = round64(0, int.from_bytes(data[i:i+8], "little"))
        h ^= k1
        h = (rotl(h, 27) * P1 + P4) & MASK
        i += 8
    if i + 4 <= ln:
        h ^= (int.from_bytes(data[i:i+4], "little") * P1) & MASK
        h = (rotl(h, 23) * P2 + P3) & MASK
        i += 4
    while i < ln:
        h ^= (data[i] * P5) & MASK
        h = (rotl(h, 11) * P1) & MASK
        i += 1
    h ^= h >> 33
    h = (h * P2) & MASK
    h ^= h >> 29
    h = (h * P3) & MASK
    h ^= h >> 32
    return h & MASK


def parse_frame_header(data):
    if not data.startswith(MAGIC) or len(data) < 6:
        raise RuntimeError("Unknown frame descriptor")
    desc = data[4]
    if desc & 0x08:
        raise RuntimeError("Unsupported frame parameter")
    single = bool(desc & 0x20)
    checksum = bool(desc & 0x04)
    dict_flag = desc & 0x03
    fcs_flag = desc >> 6
    pos = 5
    if dict_flag:
        dsz = [0, 1, 2, 4][dict_flag]
        pos += dsz
    size = None
    if single:
        if fcs_flag == 0:
            size = data[pos]; pos += 1
        elif fcs_flag == 1:
            size = int.from_bytes(data[pos:pos+2], "little") + 256; pos += 2
        elif fcs_flag == 2:
            size = int.from_bytes(data[pos:pos+4], "little"); pos += 4
        else:
            size = int.from_bytes(data[pos:pos+8], "little"); pos += 8
    else:
        if pos >= len(data):
            raise RuntimeError("Src size is incorrect")
        window_desc = data[pos]
        pos += 1
        if fcs_flag == 1:
            size = int.from_bytes(data[pos:pos+2], "little") + 256; pos += 2
        elif fcs_flag == 2:
            size = int.from_bytes(data[pos:pos+4], "little"); pos += 4
        elif fcs_flag == 3:
            size = int.from_bytes(data[pos:pos+8], "little"); pos += 8
        _ = window_desc
    return pos, size, checksum, desc


def decompress_frame(data):
    pos, expected, checksum, _ = parse_frame_header(data)
    out = bytearray()
    while True:
        if pos + 3 > len(data):
            raise RuntimeError("Src size is incorrect")
        bh = int.from_bytes(data[pos:pos+3], "little")
        pos += 3
        last = bh & 1
        btype = (bh >> 1) & 3
        bsize = bh >> 3
        if btype == 0:
            if pos + bsize > len(data):
                raise RuntimeError("Src size is incorrect")
            out.extend(data[pos:pos+bsize])
            pos += bsize
        elif btype == 1:
            if pos >= len(data):
                raise RuntimeError("Src size is incorrect")
            out.extend(bytes([data[pos]]) * bsize)
            pos += 1
        else:
            raise RuntimeError("Compressed blocks are not supported by this reimplementation")
        if last:
            break
    if expected is not None and len(out) != expected:
        raise RuntimeError("Destination size is too small")
    if checksum:
        if pos + 4 > len(data):
            raise RuntimeError("Src size is incorrect")
        got = int.from_bytes(data[pos:pos+4], "little")
        want = xxh64(out) & 0xffffffff
        if got != want:
            raise RuntimeError("Restored data doesn't match checksum")
    return bytes(out)


def parse(argv):
    opts = {
        "decompress": False, "stdout": False, "force": False, "quiet": 0,
        "level": 3, "output": None, "rm": False, "list": False, "test": False,
        "format": "zstd", "files": [], "filelists": [], "recursive": False,
        "out_flat": None, "out_mirror": None,
    }
    i = 0
    literal = False
    while i < len(argv):
        a = argv[i]
        if literal:
            opts["files"].append(a)
        elif a == "--":
            literal = True
        elif a in ("-H", "--help"):
            opts["help"] = "full"
        elif a == "-h":
            opts["help"] = "short"
        elif a in ("-V", "--version"):
            opts["version"] = True
        elif a in ("-d", "--decompress", "--uncompress"):
            opts["decompress"] = True
        elif a in ("-c", "--stdout", "--to-stdout"):
            opts["stdout"] = True
        elif a in ("-f", "--force"):
            opts["force"] = True
        elif a in ("-k", "--keep"):
            opts["rm"] = False
        elif a == "--rm":
            opts["rm"] = True
        elif a in ("-q", "--quiet"):
            opts["quiet"] += 1
        elif a in ("-v", "--verbose"):
            pass
        elif a in ("-l", "--list"):
            opts["list"] = True
        elif a in ("-t", "--test"):
            opts["test"] = True
            opts["decompress"] = True
        elif a == "-r":
            opts["recursive"] = True
        elif a == "-o":
            i += 1
            if i >= len(argv):
                usage_error("zstd: option requires an argument -- 'o'")
            opts["output"] = argv[i]
        elif a.startswith("-o") and len(a) > 2:
            opts["output"] = a[2:]
        elif a == "-D":
            i += 1
        elif a.startswith("-D") and len(a) > 2:
            pass
        elif a.startswith("-T") or a.startswith("-b") or a.startswith("-e") or a.startswith("-i") or a.startswith("-M"):
            pass
        elif a.startswith("--format="):
            opts["format"] = a.split("=", 1)[1]
        elif a.startswith("--fast"):
            opts["level"] = 1
        elif a in ("--ultra", "--adapt", "--long", "--rsyncable", "--single-thread",
                   "--no-check", "--check", "--no-progress", "--progress",
                   "--no-asyncio", "--asyncio", "--exclude-compressed",
                   "--patch-apply", "--no-dictID", "--mmap-dict", "--no-mmap-dict",
                   "--compress-literals", "--no-compress-literals",
                   "--row-match-finder", "--no-row-match-finder",
                   "--sparse", "--no-sparse", "--pass-through", "--no-pass-through"):
            pass
        elif a.startswith("--filelist"):
            val = value_arg(a, argv, i)
            if val[1]:
                i += 1
            opts["filelists"].append(val[0])
        elif a.startswith("--output-dir-flat"):
            val = value_arg(a, argv, i)
            if val[1]:
                i += 1
            opts["out_flat"] = val[0]
        elif a.startswith("--output-dir-mirror"):
            val = value_arg(a, argv, i)
            if val[1]:
                i += 1
            opts["out_mirror"] = val[0]
        elif a.startswith("--"):
            pass
        elif a.startswith("-") and len(a) > 2 and all(ch in "dcfqvlt" for ch in a[1:]):
            for ch in a[1:]:
                if ch == "d":
                    opts["decompress"] = True
                elif ch == "c":
                    opts["stdout"] = True
                elif ch == "f":
                    opts["force"] = True
                elif ch == "q":
                    opts["quiet"] += 1
                elif ch == "l":
                    opts["list"] = True
                elif ch == "t":
                    opts["test"] = True
                    opts["decompress"] = True
        elif a.startswith("-") and a[1:].isdigit():
            opts["level"] = int(a[1:])
        else:
            opts["files"].append(a)
        i += 1
    for fl in opts["filelists"]:
        with open(fl, "r", encoding="utf-8", errors="surrogateescape") as f:
            opts["files"].extend(line.rstrip("\n") for line in f if line.rstrip("\n"))
    return opts


def value_arg(arg, argv, i):
    if "=" in arg:
        return arg.split("=", 1)[1], False
    if i + 1 >= len(argv):
        usage_error(f"zstd: {arg} requires an argument")
    return argv[i + 1], True


def usage_error(msg):
    print(msg, file=sys.stderr)
    raise SystemExit(1)


def out_name(path, opts):
    p = pathlib.Path(path)
    if opts["output"]:
        return pathlib.Path(opts["output"])
    if opts["out_flat"]:
        base = pathlib.Path(opts["out_flat"]) / p.name
    elif opts["out_mirror"]:
        base = pathlib.Path(opts["out_mirror"]) / p
    else:
        base = p
    if opts["decompress"]:
        s = str(base)
        for suf in (".zst", ".tzst", ".gz", ".tgz"):
            if s.endswith(suf):
                repl = ".tar" if suf in (".tzst", ".tgz") else ""
                return pathlib.Path(s[:-len(suf)] + repl)
        print("zstd: {}: unknown suffix (.zst/.tzst/.gz/.tgz expected). Can't derive the output file name. Specify it with -o dstFileName. Ignoring.".format(path), file=sys.stderr)
        return None
    suffix = ".gz" if opts["format"] == "gzip" else ".zst"
    return pathlib.Path(str(base) + suffix)


def read_input(name):
    if name in (None, "-"):
        return sys.stdin.buffer.read()
    with open(name, "rb") as f:
        return f.read()


def write_output(dest, data, force):
    dest.parent.mkdir(parents=True, exist_ok=True)
    if dest.exists() and not force:
        print(f"zstd: {dest} already exists; overwrite (y/n) ? Not overwritten  ", file=sys.stderr)
        return False
    with open(dest, "wb") as f:
        f.write(data)
    return True


def collect_files(files, recursive):
    if not files:
        return [None]
    out = []
    for name in files:
        if name == "-":
            out.append(name)
        elif os.path.isdir(name) and recursive:
            for root, _, names in os.walk(name):
                for n in names:
                    out.append(os.path.join(root, n))
        else:
            out.append(name)
    return out


def status_compress(src, in_len, out_len, dest):
    ratio = (out_len / in_len * 100) if in_len else 0
    print(f"{src:<20} :{ratio:6.2f}%   ({in_len:6d} B => {out_len:6d} B, {dest}) ", file=sys.stderr)


def status_decompress(src, out_len):
    print(f"{src:<20}: {out_len} bytes ", file=sys.stderr)


def process_one(name, opts, zstd):
    data = read_input(name)
    src_label = name if name is not None else "stdin"
    is_gzip = (opts["format"] == "gzip") or (name and str(name).endswith((".gz", ".tgz")))
    try:
        if opts["list"]:
            size = gzip_decompressed_len(data) if is_gzip else zstd.frame_size(data)
            if size in (CONTENT_ERROR, CONTENT_UNKNOWN):
                raise RuntimeError("unsupported frame parameter")
            print("Frames  Skips  Compressed  Uncompressed  Ratio  Check  Filename")
            ratio = (size / len(data)) if data else 0
            print(f"{1:6d} {0:6d} {len(data):7d}   B {size:9d}   B {ratio:5.3f}  XXH64  {src_label}")
            return 0
        if opts["decompress"]:
            out = gzip.decompress(data) if is_gzip else zstd.decompress(data)
            if opts["test"]:
                if opts["quiet"] == 0:
                    status_decompress(src_label, len(out))
                return 0
        else:
            out = gzip.compress(data) if opts["format"] == "gzip" else zstd.compress(data, opts["level"])
    except Exception as exc:
        if opts["quiet"] < 2:
            print(f"zstd: {src_label}: {exc}", file=sys.stderr)
        return 1

    if opts["stdout"] or name is None or name == "-":
        sys.stdout.buffer.write(out)
    else:
        dest = out_name(name, opts)
        if dest is None:
            return 1
        if not write_output(dest, out, opts["force"]):
            return 1
        if opts["rm"]:
            try:
                os.remove(name)
            except OSError:
                pass
        if opts["quiet"] == 0:
            if opts["decompress"]:
                status_decompress(src_label, len(out))
            else:
                status_compress(src_label, len(data), len(out), dest)
    return 0


def gzip_decompressed_len(data):
    return len(gzip.decompress(data))


def main(argv):
    opts = parse(argv)
    if opts.get("version"):
        print(VERSION)
        return 0
    if opts.get("help") == "short":
        sys.stdout.write(SHORT_HELP)
        return 0
    if opts.get("help") == "full":
        sys.stderr.write(FULL_HELP)
        return 0
    zstd = Zstd()
    rc = 0
    for name in collect_files(opts["files"], opts["recursive"]):
        rc = max(rc, process_one(name, opts, zstd))
    return rc


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
