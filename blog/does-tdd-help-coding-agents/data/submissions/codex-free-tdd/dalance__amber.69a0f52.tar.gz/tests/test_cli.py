import os
import shutil
import subprocess
import tempfile
import time
import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]


def build_in_tmp():
    tmp = Path(tempfile.mkdtemp(prefix="ambr-test-"))
    for item in ROOT.iterdir():
        if item.name == "tests":
            continue
        dest = tmp / item.name
        if item.is_dir():
            shutil.copytree(item, dest)
        else:
            shutil.copy2(item, dest)
    subprocess.run(["bash", "compile.sh"], cwd=tmp, check=True)
    return tmp


def run_cmd(args, cwd):
    return subprocess.run(
        args,
        cwd=cwd,
        text=True,
        input="",
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
    )


def run_cmd_input(args, cwd, user_input):
    return subprocess.run(
        args,
        cwd=cwd,
        text=True,
        input=user_input,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
    )


class CliTests(unittest.TestCase):
    def test_help_and_version_match_public_cli(self):
        tmp = build_in_tmp()

        help_result = run_cmd([str(tmp / "executable"), "--help"], tmp)
        version_result = run_cmd([str(tmp / "executable"), "--version"], tmp)

        self.assertEqual(help_result.returncode, 0)
        self.assertIn("ambr 0.6.0", help_result.stdout)
        self.assertIn("USAGE:", help_result.stdout)
        self.assertIn("--key-from-file", help_result.stdout)
        self.assertEqual(version_result.returncode, 0)
        self.assertEqual(version_result.stdout, "ambr 0.6.0\n")

    def test_no_interactive_replaces_literal_matches_in_file(self):
        tmp = build_in_tmp()
        work = tmp / "work"
        work.mkdir()
        target = work / "a.txt"
        target.write_text("hello world\nhello again\n", encoding="utf-8")

        result = run_cmd([str(tmp / "executable"), "--no-interactive", "hello", "HI", "a.txt"], work)

        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertEqual(result.stdout, "")
        self.assertEqual(result.stderr, "")
        self.assertEqual(target.read_text(encoding="utf-8"), "HI world\nHI again\n")

    def test_no_path_recurses_from_current_directory_and_skips_git(self):
        tmp = build_in_tmp()
        work = tmp / "work"
        (work / "src").mkdir(parents=True)
        (work / ".git").mkdir()
        src = work / "src" / "a.txt"
        vcs = work / ".git" / "config"
        src.write_text("token\n", encoding="utf-8")
        vcs.write_text("token\n", encoding="utf-8")

        result = run_cmd([str(tmp / "executable"), "--no-interactive", "token", "value"], work)

        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertEqual(src.read_text(encoding="utf-8"), "value\n")
        self.assertEqual(vcs.read_text(encoding="utf-8"), "token\n")

    def test_regex_supports_numbered_and_named_capture_replacements(self):
        tmp = build_in_tmp()
        work = tmp / "work"
        work.mkdir()
        target = work / "r.txt"
        target.write_text("aaa bbb\n", encoding="utf-8")

        result = run_cmd(
            [
                str(tmp / "executable"),
                "--no-interactive",
                "--regex",
                "(aaa) (?P<pat>bbb)",
                "$1 $pat ${1} ${pat}",
                "r.txt",
            ],
            work,
        )

        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertEqual(target.read_text(encoding="utf-8"), "aaa bbb aaa bbb\n")

    def test_keyword_and_replacement_can_come_from_files(self):
        tmp = build_in_tmp()
        work = tmp / "work"
        work.mkdir()
        (work / "key.txt").write_text("TOKEN", encoding="utf-8")
        (work / "rep.txt").write_text("value", encoding="utf-8")
        target = work / "target.txt"
        target.write_text("TOKEN and TOKEN\n", encoding="utf-8")

        result = run_cmd(
            [
                str(tmp / "executable"),
                "--no-interactive",
                "--key-from-file",
                "--rep-from-file",
                "key.txt",
                "rep.txt",
                "target.txt",
            ],
            work,
        )

        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertEqual(target.read_text(encoding="utf-8"), "value and value\n")

    def test_binary_files_are_skipped_unless_binary_flag_is_set(self):
        tmp = build_in_tmp()
        work = tmp / "work"
        work.mkdir()
        target = work / "bin.dat"
        target.write_bytes(b"abc\x00abc\n")

        skipped = run_cmd([str(tmp / "executable"), "--no-interactive", "abc", "XYZ", "bin.dat"], work)
        self.assertEqual(skipped.returncode, 0, skipped.stderr)
        self.assertEqual(target.read_bytes(), b"abc\x00abc\n")

        replaced = run_cmd([str(tmp / "executable"), "--no-interactive", "--binary", "abc", "XYZ", "bin.dat"], work)

        self.assertEqual(replaced.returncode, 0, replaced.stderr)
        self.assertEqual(target.read_bytes(), b"XYZ\x00XYZ\n")

    def test_interactive_no_skips_and_yes_replaces(self):
        tmp = build_in_tmp()
        work = tmp / "work"
        work.mkdir()
        target = work / "a.txt"
        target.write_text("cat cat\n", encoding="utf-8")

        no_result = run_cmd_input([str(tmp / "executable"), "cat", "dog", "a.txt"], work, "n\n")
        yes_result = run_cmd_input([str(tmp / "executable"), "cat", "dog", "a.txt"], work, "y\n")

        self.assertIn("Replace keyword?", no_result.stdout)
        self.assertEqual(no_result.returncode, 0, no_result.stderr)
        self.assertEqual(yes_result.returncode, 0, yes_result.stderr)
        self.assertEqual(target.read_text(encoding="utf-8"), "dog dog\n")

    def test_no_recursive_and_no_skip_vcs_flags_control_traversal(self):
        tmp = build_in_tmp()
        work = tmp / "work"
        (work / "sub").mkdir(parents=True)
        (work / ".git").mkdir()
        top = work / "top.txt"
        nested = work / "sub" / "nested.txt"
        vcs = work / ".git" / "config"
        top.write_text("mark\n", encoding="utf-8")
        nested.write_text("mark\n", encoding="utf-8")
        vcs.write_text("mark\n", encoding="utf-8")

        shallow = run_cmd([str(tmp / "executable"), "--no-interactive", "--no-recursive", "mark", "done", "."], work)
        self.assertEqual(shallow.returncode, 0, shallow.stderr)
        self.assertEqual(top.read_text(encoding="utf-8"), "done\n")
        self.assertEqual(nested.read_text(encoding="utf-8"), "mark\n")
        self.assertEqual(vcs.read_text(encoding="utf-8"), "mark\n")

        vcs_allowed = run_cmd([str(tmp / "executable"), "--no-interactive", "--no-skip-vcs", "mark", "done", "."], work)
        self.assertEqual(vcs_allowed.returncode, 0, vcs_allowed.stderr)
        self.assertEqual(vcs.read_text(encoding="utf-8"), "done\n")

    def test_gitignore_is_honored_unless_disabled(self):
        tmp = build_in_tmp()
        work = tmp / "work"
        work.mkdir()
        (work / ".gitignore").write_text("ignored.txt\n", encoding="utf-8")
        ignored = work / "ignored.txt"
        ignored.write_text("needle\n", encoding="utf-8")

        skipped = run_cmd([str(tmp / "executable"), "--no-interactive", "needle", "value", "."], work)
        self.assertEqual(skipped.returncode, 0, skipped.stderr)
        self.assertEqual(ignored.read_text(encoding="utf-8"), "needle\n")

        included = run_cmd(
            [str(tmp / "executable"), "--no-interactive", "--no-skip-gitignore", "needle", "value", "."],
            work,
        )
        self.assertEqual(included.returncode, 0, included.stderr)
        self.assertEqual(ignored.read_text(encoding="utf-8"), "value\n")

    def test_preserve_time_restores_modified_timestamp(self):
        tmp = build_in_tmp()
        work = tmp / "work"
        work.mkdir()
        target = work / "a.txt"
        target.write_text("old\n", encoding="utf-8")
        old_time = time.time() - 3600
        os.utime(target, (old_time, old_time))

        result = run_cmd([str(tmp / "executable"), "--no-interactive", "--preserve-time", "old", "new", "a.txt"], work)

        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertEqual(target.read_text(encoding="utf-8"), "new\n")
        self.assertAlmostEqual(target.stat().st_mtime, old_time, delta=1.0)


if __name__ == "__main__":
    unittest.main()
