#!/usr/bin/env python3
import sys
import re
import fnmatch
import os
from pathlib import Path


VCS_DIRS = {".git", ".hg", ".svn", ".bzr"}

HELP = """ambr 0.6.0

USAGE:
    executable [FLAGS] [OPTIONS] <KEYWORD> <REPLACEMENT> [PATHS]...

FLAGS:
        --key-from-file        Use file contents of KEYWORD as keyword for search
        --rep-from-file        Use file contents of REPLACEMENT as keyword for replacement
        --verbose              Verbose message
    -r, --regex                Enable regular expression search
        --column               Enable column output
        --row                  Enable row output
        --binary               Enable binary file search
        --statistics           Enable statistics output
        --skipped              Enable skipped file output
        --preserve-time        Enable timestamp preserve
        --no-interactive       Disable interactive replace
        --no-recursive         Disable recursive directory search
        --no-symlink           Disable symbolic link follow
        --no-color             Disable colored output
        --no-file              Disable filename output
        --no-skip-vcs          Disable vcs directory ( .hg/.git/.svn ) skip
        --no-skip-gitignore    Disable .gitignore skip
        --no-fixed-order       Disable output order guarantee
        --no-parent-ignore     Disable .*ignore file search at parent directories
        --tbm                  [Experimental] Enable TBM matcher
        --sse                  [Experimental] Enable SSE 4.2
    -h, --help                 Prints help information
    -V, --version              Prints version information

OPTIONS:
        --max-threads <NUM>          Number of max threads [default: 4]
        --size-per-thread <BYTES>    File size per one thread [default: 1048576]
        --bin-check-bytes <BYTES>    Read size for checking binary [default: 256]
        --mmap-bytes <BYTES>         [Experimental] Minimum size for using mmap [default: 1048576]

ARGS:
    <KEYWORD>        Keyword for search
    <REPLACEMENT>    Keyword for replace
    <PATHS>...       Search paths
"""


def load_ignore_patterns(root):
    ignore = root / ".gitignore"
    patterns = []
    if ignore.is_file():
        for line in ignore.read_text(encoding="utf-8", errors="ignore").splitlines():
            line = line.strip()
            if not line or line.startswith("#"):
                continue
            patterns.append(line)
    return patterns


def ignored_by_patterns(path, root, patterns):
    if not patterns:
        return False
    try:
        rel = path.relative_to(root).as_posix()
    except ValueError:
        rel = path.name
    ignored = False
    for pattern in patterns:
        negate = pattern.startswith("!")
        pat = pattern[1:] if negate else pattern
        pat = pat.lstrip("/")
        if pat.endswith("/"):
            matched = rel.startswith(pat.rstrip("/") + "/")
        elif "/" in pat:
            matched = fnmatch.fnmatch(rel, pat)
        else:
            matched = any(fnmatch.fnmatch(part, pat) for part in rel.split("/"))
        if matched:
            ignored = not negate
    return ignored


def iter_files(paths, recursive=True, skip_vcs=True, skip_gitignore=True):
    if not paths:
        paths = ["."]
    for raw_path in paths:
        path = Path(raw_path)
        if path.is_file():
            yield path
        elif path.is_dir():
            root = path
            patterns = load_ignore_patterns(root) if skip_gitignore else []
            children = path.rglob("*") if recursive else path.glob("*")
            for child in children:
                if skip_vcs and any(part in VCS_DIRS for part in child.parts):
                    continue
                if skip_gitignore and ignored_by_patterns(child, root, patterns):
                    continue
                if child.is_file():
                    yield child


def parse_args(argv):
    opts = {
        "regex": False,
        "key_from_file": False,
        "rep_from_file": False,
        "binary": False,
        "interactive": True,
        "recursive": True,
        "skip_vcs": True,
        "skip_gitignore": True,
        "preserve_time": False,
    }
    positional = []
    skip_value = False
    value_options = {
        "--max-threads",
        "--size-per-thread",
        "--bin-check-bytes",
        "--mmap-bytes",
    }
    ignored_flags = {
        "--verbose",
        "--column",
        "--row",
        "--statistics",
        "--skipped",
        "--no-symlink",
        "--no-color",
        "--no-file",
        "--no-fixed-order",
        "--no-parent-ignore",
        "--tbm",
        "--sse",
    }
    for arg in argv:
        if skip_value:
            skip_value = False
            continue
        if arg in value_options:
            skip_value = True
        elif arg == "--no-interactive":
            opts["interactive"] = False
        elif arg == "--no-recursive":
            opts["recursive"] = False
        elif arg == "--no-skip-vcs":
            opts["skip_vcs"] = False
        elif arg == "--no-skip-gitignore":
            opts["skip_gitignore"] = False
        elif arg == "--preserve-time":
            opts["preserve_time"] = True
        elif arg in ("-r", "--regex"):
            opts["regex"] = True
        elif arg == "--binary":
            opts["binary"] = True
        elif arg == "--key-from-file":
            opts["key_from_file"] = True
        elif arg == "--rep-from-file":
            opts["rep_from_file"] = True
        elif arg in ignored_flags:
            continue
        else:
            positional.append(arg)
    return opts, positional


def expand_replacement(match, template):
    out = []
    i = 0
    while i < len(template):
        ch = template[i]
        if ch != "$" or i + 1 >= len(template):
            out.append(ch)
            i += 1
            continue
        if template[i + 1] == "{":
            end = template.find("}", i + 2)
            if end == -1:
                out.append(ch)
                i += 1
                continue
            name = template[i + 2 : end]
            i = end + 1
        else:
            j = i + 1
            while j < len(template) and (template[j].isalnum() or template[j] == "_"):
                j += 1
            name = template[i + 1 : j]
            i = j
        if not name:
            out.append("$")
        elif name.isdigit():
            out.append(match.group(int(name)) or "")
        else:
            out.append(match.groupdict().get(name) or "")
    return "".join(out)


def is_binary(raw):
    return b"\x00" in raw[:256]


def replace_data(data, keyword, replacement, regex):
    if regex:
        pattern = re.compile(keyword)
        return pattern.sub(lambda m: expand_replacement(m, replacement), data)
    return data.replace(keyword, replacement)


def ask_replace():
    sys.stdout.write("Replace keyword? ( Yes[Y], No[N], All[A], Quit[Q] ):")
    sys.stdout.flush()
    try:
        answer = sys.stdin.readline()
    except KeyboardInterrupt:
        return "q"
    normalized = answer.strip().lower()
    if normalized in ("y", "yes"):
        return "y"
    if normalized in ("a", "all"):
        return "a"
    if normalized in ("q", "quit"):
        return "q"
    return "n"


def main(argv):
    if any(arg in ("-h", "--help") for arg in argv):
        sys.stdout.write(HELP)
        return 0
    if any(arg in ("-V", "--version") for arg in argv):
        sys.stdout.write("ambr 0.6.0\n")
        return 0
    opts, args = parse_args(argv)
    if len(args) < 2:
        return 1

    keyword, replacement = args[0], args[1]
    if opts["key_from_file"]:
        keyword = Path(keyword).read_text(encoding="utf-8")
    if opts["rep_from_file"]:
        replacement = Path(replacement).read_text(encoding="utf-8")
    replace_all = not opts["interactive"]
    for path in iter_files(args[2:], opts["recursive"], opts["skip_vcs"], opts["skip_gitignore"]):
        raw = path.read_bytes()
        if not opts["binary"] and is_binary(raw):
            continue
        data = raw.decode("utf-8", errors="surrogateescape")
        updated = replace_data(data, keyword, replacement, opts["regex"])
        if updated == data:
            continue
        if not replace_all:
            decision = ask_replace()
            if decision == "q":
                break
            if decision == "a":
                replace_all = True
            elif decision != "y":
                continue
        stat = path.stat() if opts["preserve_time"] else None
        path.write_bytes(updated.encode("utf-8", errors="surrogateescape"))
        if stat is not None:
            os.utime(path, (stat.st_atime, stat.st_mtime))
    return 0


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
