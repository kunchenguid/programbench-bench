#!/usr/bin/env python3
import json
import os
import re
import sys
from pathlib import Path


VERSION = "ast-grep 0.42.1"
LANG_NAMES = {
    "js": "JavaScript",
    "javascript": "JavaScript",
    "ts": "TypeScript",
    "typescript": "TypeScript",
    "tsx": "Tsx",
    "py": "Python",
    "python": "Python",
    "rs": "Rust",
    "rust": "Rust",
    "go": "Go",
    "java": "Java",
    "c": "C",
    "cpp": "Cpp",
    "json": "Json",
    "yaml": "Yaml",
}
EXT_LANG = {
    ".js": "JavaScript",
    ".mjs": "JavaScript",
    ".cjs": "JavaScript",
    ".ts": "TypeScript",
    ".tsx": "Tsx",
    ".py": "Python",
    ".rs": "Rust",
    ".go": "Go",
    ".java": "Java",
    ".c": "C",
    ".h": "C",
    ".cpp": "Cpp",
    ".cc": "Cpp",
    ".hpp": "Cpp",
    ".json": "Json",
    ".yml": "Yaml",
    ".yaml": "Yaml",
}


def print_top_help():
    print("""Search and Rewrite code at large scale using AST pattern.

Usage: executable [OPTIONS] <COMMAND>

Commands:
  run          Run one time search or rewrite in command line. (default command)
  scan         Scan and rewrite code by configuration
  test         Test ast-grep rules
  new          Create new ast-grep project or items like rules/tests
  lsp          Start language server
  completions  Generate shell completion script
  help         Print this message or the help of the given subcommand(s)

Options:
  -c, --config <CONFIG_FILE>
          Path to ast-grep root config, default is sgconfig.yml

  -h, --help
          Print help (see a summary with '-h')

  -V, --version
          Print version""")


def print_run_help():
    print("""Run one time search or rewrite in command line. (default command)

Usage: executable run [OPTIONS] --pattern <PATTERN> [PATHS]...

Options:
  -p, --pattern <PATTERN>  AST pattern to match
  -r, --rewrite <FIX>      String to replace the matched AST node
  -l, --lang <LANG>        The language of the pattern
      --stdin              Enable search code from StdIn.
      --files-with-matches Print only the paths with at least one match
      --json[=<STYLE>]     Output matches in structured JSON
  -U, --update-all         Apply all rewrite without confirmation if true
  -A, --after <NUM>        Show NUM lines after each match.
  -B, --before <NUM>       Show NUM lines before each match.
  -C, --context <NUM>      Show NUM lines around each match.
  -h, --help               Print help""")


def print_scan_help():
    print("""Scan and rewrite code by configuration

Usage: executable scan [OPTIONS] [PATHS]...

Options:
  -r, --rule <RULE_FILE>       Scan the codebase with the single rule
      --inline-rules <TEXT>    Scan with an inline rule
      --report-style <STYLE>   Possible values: rich, medium, short
      --json[=<STYLE>]         Output matches in structured JSON
  -h, --help                   Print help""")


def line_col(text, offset):
    line = text.count("\n", 0, offset)
    last = text.rfind("\n", 0, offset)
    col = offset if last < 0 else offset - last - 1
    return {"line": line, "column": col}


def line_bounds(text, offset):
    start = text.rfind("\n", 0, offset) + 1
    end = text.find("\n", offset)
    if end < 0:
        end = len(text)
    return start, end


def compile_pattern(pattern):
    pieces = []
    groups = []
    seen = set()
    i = 0
    while i < len(pattern):
        if pattern[i] == "$":
            j = i + 1
            while j < len(pattern) and (pattern[j].isalnum() or pattern[j] == "_"):
                j += 1
            name = pattern[i + 1:j]
            if name and name[0].isalpha() and name.upper() == name:
                groups.append(name)
                if name in seen:
                    pieces.append(f"(?P={name})")
                else:
                    pieces.append(f"(?P<{name}>.+?)")
                    seen.add(name)
                i = j
                continue
        if pattern[i].isspace():
            while i < len(pattern) and pattern[i].isspace():
                i += 1
            pieces.append(r"\s+")
            continue
        pieces.append(re.escape(pattern[i]))
        i += 1
    return re.compile("".join(pieces), re.MULTILINE | re.DOTALL), groups


def language_name(lang, path=None):
    if lang:
        return LANG_NAMES.get(lang.lower(), lang)
    if path:
        return EXT_LANG.get(Path(path).suffix.lower(), "Unknown")
    return "Unknown"


def make_match(text, match, file_name, lang, groups):
    start, end = match.span()
    ls, le = line_bounds(text, start)
    line_text = text[ls:le]
    meta = {}
    for name in dict.fromkeys(groups):
        if name not in match.groupdict() or match.group(name) is None:
            continue
        gs, ge = match.span(name)
        if groups.count(name) > 1:
            local = match.group(0).rfind(match.group(name))
            if local >= 0:
                gs = start + local
                ge = gs + len(match.group(name))
        meta[name] = {
            "text": match.group(name),
            "range": {
                "byteOffset": {"start": gs, "end": ge},
                "start": line_col(text, gs),
                "end": line_col(text, ge),
            },
        }
    return {
        "text": match.group(0),
        "range": {
            "byteOffset": {"start": start, "end": end},
            "start": line_col(text, start),
            "end": line_col(text, end),
        },
        "file": file_name,
        "lines": line_text,
        "charCount": {"leading": start - ls, "trailing": le - end},
        "language": language_name(lang, file_name),
        "metaVariables": {"single": meta, "multi": {}},
        "transformed": {},
    }


def iter_files(paths, lang=None):
    if not paths:
        paths = ["."]
    wanted = None
    if lang:
        wanted = language_name(lang)
    for raw in paths:
        path = Path(raw)
        if path.is_file():
            yield path
        elif path.is_dir():
            for root, dirs, files in os.walk(path):
                dirs[:] = [d for d in dirs if not d.startswith(".")]
                for name in sorted(files):
                    if name.startswith("."):
                        continue
                    p = Path(root) / name
                    if wanted and EXT_LANG.get(p.suffix.lower()) not in (wanted, None):
                        if p.suffix.lower() in EXT_LANG:
                            continue
                    yield p


def find_matches(pattern, content, file_name, lang):
    regex, groups = compile_pattern(pattern)
    return [make_match(content, m, file_name, lang, groups) for m in regex.finditer(content)], regex, groups


def parse_common(argv):
    opts = {
        "pattern": None,
        "rewrite": None,
        "lang": None,
        "json": None,
        "stdin": False,
        "files": False,
        "update": False,
        "after": 0,
        "before": 0,
        "paths": [],
    }
    i = 0
    while i < len(argv):
        a = argv[i]
        if a in ("-p", "--pattern"):
            i += 1; opts["pattern"] = argv[i]
        elif a in ("-r", "--rewrite"):
            i += 1; opts["rewrite"] = argv[i]
        elif a in ("-l", "--lang"):
            i += 1; opts["lang"] = argv[i]
        elif a == "--stdin":
            opts["stdin"] = True
        elif a == "--files-with-matches":
            opts["files"] = True
        elif a in ("-U", "--update-all"):
            opts["update"] = True
        elif a == "--json":
            opts["json"] = "pretty"
        elif a.startswith("--json="):
            opts["json"] = a.split("=", 1)[1] or "pretty"
        elif a in ("-A", "--after"):
            i += 1; opts["after"] = int(argv[i])
        elif a in ("-B", "--before"):
            i += 1; opts["before"] = int(argv[i])
        elif a in ("-C", "--context"):
            i += 1; opts["after"] = opts["before"] = int(argv[i])
        elif a.startswith("-"):
            if a in ("-c", "--config", "-j", "--threads", "--color", "--heading", "--inspect", "--globs", "--no-ignore", "--strictness", "--selector", "--debug-query"):
                if "=" not in a and i + 1 < len(argv) and not argv[i + 1].startswith("-"):
                    i += 1
            pass
        else:
            opts["paths"].append(a)
        i += 1
    return opts


def render_json(matches, style):
    if style == "stream":
        return "".join(json.dumps(m, separators=(",", ":")) + "\n" for m in matches)
    if style == "compact":
        return json.dumps(matches, separators=(",", ":"))
    return json.dumps(matches, indent=2)


def replacement_from_match(template, match_obj):
    out = template
    for name, data in match_obj["metaVariables"]["single"].items():
        out = out.replace("$" + name, data["text"])
    return out


def command_run(argv):
    if any(a in ("-h", "--help") for a in argv):
        print_run_help(); return 0
    opts = parse_common(argv)
    if not opts["pattern"]:
        print("error: the following required arguments were not provided:\n  --pattern <PATTERN>", file=sys.stderr)
        return 2
    all_matches = []
    changed = 0
    if opts["stdin"]:
        content = sys.stdin.read()
        matches, _, _ = find_matches(opts["pattern"], content, "STDIN", opts["lang"])
        all_matches.extend(matches)
    else:
        for path in iter_files(opts["paths"], opts["lang"]):
            try:
                content = path.read_text()
            except UnicodeDecodeError:
                continue
            rel = str(path)
            matches, regex, _ = find_matches(opts["pattern"], content, rel, opts["lang"])
            if opts["rewrite"] is not None and opts["update"] and matches:
                new = content
                for m in reversed(matches):
                    s = m["range"]["byteOffset"]["start"]
                    e = m["range"]["byteOffset"]["end"]
                    new = new[:s] + replacement_from_match(opts["rewrite"], m) + new[e:]
                path.write_text(new)
                changed += len(matches)
            all_matches.extend(matches)
    if opts["rewrite"] is not None and opts["update"]:
        print(f"Applied {changed} changes", file=sys.stderr)
        return 0
    if opts["json"]:
        sys.stdout.write(render_json(all_matches, opts["json"]))
        if opts["json"] != "compact":
            pass
        return 0
    if opts["files"]:
        for f in dict.fromkeys(m["file"] for m in all_matches):
            print(f)
        return 0
    printed = set()
    for m in all_matches:
        line_no = m["range"]["start"]["line"]
        file_name = m["file"]
        if opts["before"] or opts["after"]:
            try:
                lines = Path(file_name).read_text().splitlines()
            except Exception:
                lines = m["lines"].splitlines()
            s = max(0, line_no - opts["before"])
            e = min(len(lines), line_no + opts["after"] + 1)
            for idx in range(s, e):
                key = (file_name, idx)
                if key not in printed:
                    print(f"{file_name}:{idx + 1}:{lines[idx]}")
                    printed.add(key)
        else:
            print(f"{file_name}:{line_no + 1}:{m['lines']}")
    return 0


def parse_rule_file(path):
    data = {"id": Path(path).stem, "language": None, "pattern": None, "message": "", "severity": "warning", "fix": None}
    for raw in Path(path).read_text().splitlines():
        line = raw.strip()
        if not line or line.startswith("#") or ":" not in line:
            continue
        key, val = line.split(":", 1)
        val = val.strip().strip("'\"")
        if key in data:
            data[key] = val
        elif key == "pattern":
            data["pattern"] = val
    return data


def command_scan(argv):
    if any(a in ("-h", "--help") for a in argv):
        print_scan_help(); return 0
    rule_file = None
    json_style = None
    report_style = "rich"
    paths = []
    i = 0
    while i < len(argv):
        a = argv[i]
        if a in ("-r", "--rule"):
            i += 1; rule_file = argv[i]
        elif a == "--json":
            json_style = "pretty"
        elif a.startswith("--json="):
            json_style = a.split("=", 1)[1] or "pretty"
        elif a == "--report-style":
            i += 1; report_style = argv[i]
        elif a.startswith("--report-style="):
            report_style = a.split("=", 1)[1]
        elif a.startswith("-"):
            if a in ("-c", "--config", "--format", "--filter", "-j", "--threads", "--color", "--globs", "--no-ignore", "--max-results"):
                if i + 1 < len(argv) and not argv[i + 1].startswith("-"):
                    i += 1
        else:
            paths.append(a)
        i += 1
    if not rule_file:
        print("error: scan requires --rule in this reimplementation", file=sys.stderr)
        return 2
    rule = parse_rule_file(rule_file)
    matches = []
    for path in iter_files(paths, rule["language"]):
        try:
            content = Path(path).read_text()
        except UnicodeDecodeError:
            continue
        found, _, _ = find_matches(rule["pattern"], content, str(path), rule["language"])
        for m in found:
            m.update({
                "ruleId": rule["id"],
                "severity": rule["severity"] or "warning",
                "note": None,
                "message": rule["message"] or "",
                "labels": [{"text": m["text"], "range": m["range"], "style": "primary"}],
            })
        matches.extend(found)
    if json_style:
        sys.stdout.write(render_json(matches, json_style))
        return 0
    for m in matches:
        line = m["range"]["start"]["line"] + 1
        col = m["range"]["start"]["column"] + 1
        print(f"{m['file']}:{line}:{col}: {m['severity']}[{m['ruleId']}]: {m['message']}")
    return 0


def command_new(argv):
    if any(a in ("-h", "--help") for a in argv):
        print("""Create new ast-grep project or items like rules/tests

Usage: executable new [OPTIONS] [NAME] [COMMAND]""")
        return 0
    kind = next((a for a in argv if not a.startswith("-")), "project")
    if kind == "project":
        print("Creating a new ast-grep project...")
        Path("rules").mkdir(exist_ok=True)
        Path("rule-tests").mkdir(exist_ok=True)
        Path("utils").mkdir(exist_ok=True)
        Path("rules/.gitkeep").write_text("")
        Path("rule-tests/.gitkeep").write_text("")
        Path("utils/.gitkeep").write_text("")
        Path("sgconfig.yml").write_text("ruleDirs:\n- rules\n")
        print("Your new ast-grep project has been created!")
    elif kind in ("rule", "util"):
        name = next((a for a in argv[1:] if not a.startswith("-")), "new-rule")
        directory = "rules" if kind == "rule" else "utils"
        Path(directory).mkdir(exist_ok=True)
        Path(directory, f"{name}.yml").write_text(f"id: {name}\nlanguage: JavaScript\nrule:\n  pattern: $A\nmessage: TODO\n")
    elif kind == "test":
        Path("rule-tests").mkdir(exist_ok=True)
    return 0


def command_completions(argv):
    shell = next((a for a in argv if not a.startswith("-")), "bash")
    print(f"# completion script for {shell}")
    return 0


def main(argv):
    if not argv or argv[0] in ("-h", "--help", "help"):
        print_top_help(); return 0
    if argv[0] in ("-V", "--version"):
        print(VERSION); return 0
    cmd = argv[0]
    rest = argv[1:]
    if cmd not in {"run", "scan", "test", "new", "lsp", "completions"}:
        return command_run(argv)
    if cmd == "run":
        return command_run(rest)
    if cmd == "scan":
        return command_scan(rest)
    if cmd == "new":
        return command_new(rest)
    if cmd == "lsp":
        if any(a in ("-h", "--help") for a in rest):
            print("Start language server\n\nUsage: executable lsp [OPTIONS]")
            return 0
        print("error: language server is not available in this reimplementation", file=sys.stderr)
        return 1
    if cmd == "completions":
        return command_completions(rest)
    if cmd == "test":
        print("No rule tests discovered")
        return 0
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
