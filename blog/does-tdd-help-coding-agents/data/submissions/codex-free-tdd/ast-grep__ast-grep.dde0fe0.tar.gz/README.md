<p align=center>
  <img src="https://ast-grep.github.io/logo.svg" alt="ast-grep"/>
</p>

# ast-grep(sg)

ast-grep(sg) is a CLI tool for code structural search, lint, and rewriting.

## What is ast-grep?

ast-grep is an [abstract syntax tree](https://dev.to/balapriya/abstract-syntax-tree-ast-explained-in-plain-english-1h38) based tool to search code by pattern code. Think of it as your old-friend [`grep`](https://en.wikipedia.org/wiki/Grep), but matching AST nodes instead of text.

You can write patterns as if you are writing ordinary code. It will match all code that has the same syntactical structure. You can use `$` sign + upper case letters as a [wildcard](https://en.wikipedia.org/wiki/Wildcard_character), e.g. `$MATCH`, to match any single AST node. Think of it as [regular expression dot](https://regexone.com/lesson/wildcards_dot) `.`, except it is not textual.

Try the [online playground](https://ast-grep.github.io/playground.html) for a taste!

## Screenshot
![demo](https://ast-grep.github.io/image/search-replace.png)

See more screenshots on the [website](https://ast-grep.github.io/).

## Installation

You can install ast-grep from npm, pip, cargo, cargo-binstall, homebrew, scoop, mise, or MacPorts:

```bash
npm install --global @ast-grep/cli
# `pnpm approve-builds` may be needed
pip install ast-grep-cli
brew install ast-grep
cargo install ast-grep --locked
cargo binstall ast-grep

# install via scoop
scoop install main/ast-grep

# install via MacPorts
sudo port install ast-grep

# try ast-grep in nix-shell
nix-shell -p ast-grep

# try ast-grep with mise
mise use -g ast-grep
```

[Packages](https://repology.org/project/ast-grep/versions) are available on other platforms too.

## Command line usage

ast-grep has the following form:

```bash
ast-grep --pattern 'var code = $PATTERN' --rewrite 'let code = new $PATTERN' --lang ts
```

### Examples

* Rewrite code using null coalescing operator:

```bash
ast-grep -p '$A && $A()' -l ts -r '$A?.()'
```

* Rewrite Zodios code:

```bash
ast-grep -p 'new Zodios($URL,  $CONF as const,)' -l ts -r 'new Zodios($URL, $CONF)' -i
```

## Features

ast-grep helps you search and replace code based on abstract syntax trees. It can help you do lightweight static analysis and massive scale code manipulation in an intuitive way.

Key features:

* **Intuitive pattern syntax**: Write patterns that look like ordinary code you would write every day (the pattern is isomorphic to code).

* **jQuery-like API**: For AST traversal and manipulation.

* **YAML configuration**: Write new linting rules or code modifications using YAML.

* **Fast and scalable**: Utilizes multiple cores for performance.

* **Beautiful CLI**: User-friendly command line interface.

## Use Cases

* **Open-source library authors**: Help your library users adopt breaking changes more easily.
* **Tech leads**: Enforce code best practices tailored to your business needs.
* **Security researchers**: Write security rules much faster.

## More Information

Visit the [official website](https://ast-grep.github.io/) for complete documentation and tutorials.

## Schemas

JSON schemas for ast-grep rule configuration are available in the `schemas/` directory. These schemas help you write valid ast-grep rules with IDE support.
