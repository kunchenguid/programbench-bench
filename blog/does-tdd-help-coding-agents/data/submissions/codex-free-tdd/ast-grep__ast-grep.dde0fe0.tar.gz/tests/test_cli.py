#!/usr/bin/env python3
import json
import os
import shutil
import subprocess
import tempfile
import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
BIN = ROOT / "executable"


class CliTests(unittest.TestCase):
    def setUp(self):
        self.tmp = Path(tempfile.mkdtemp(prefix="sg-test-"))
        self.addCleanup(lambda: shutil.rmtree(self.tmp, ignore_errors=True))

    def run_cli(self, *args, input_text=None, cwd=None):
        return subprocess.run(
            [str(BIN), *args],
            input=input_text,
            text=True,
            cwd=cwd or self.tmp,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
        )

    def test_search_prints_file_line_and_match(self):
        (self.tmp / "a.js").write_text("console.log(123);\nlet x = 1;\n")
        result = self.run_cli("run", "-p", "console.log($A)", "-l", "js", "a.js")
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertEqual(result.stdout, "a.js:1:console.log(123);\n")

    def test_json_compact_includes_match_ranges_and_meta_variables(self):
        (self.tmp / "a.js").write_text("let x = foo(1);\nfoo(2);\n")
        result = self.run_cli("run", "-p", "foo($A)", "-l", "js", "a.js", "--json=compact")
        self.assertEqual(result.returncode, 0, result.stderr)
        data = json.loads(result.stdout)
        self.assertEqual([m["text"] for m in data], ["foo(1)", "foo(2)"])
        self.assertEqual(data[0]["range"]["start"], {"line": 0, "column": 8})
        self.assertEqual(data[0]["metaVariables"]["single"]["A"]["text"], "1")
        self.assertEqual(data[1]["file"], "a.js")

    def test_update_all_rewrites_files_and_reports_count_on_stderr(self):
        path = self.tmp / "a.js"
        path.write_text("let x = foo(1);\nfoo(2);\n")
        result = self.run_cli("run", "-p", "foo($A)", "-l", "js", "-r", "bar($A)", "-U", "a.js")
        self.assertEqual(result.returncode, 0)
        self.assertEqual(result.stdout, "")
        self.assertEqual(result.stderr, "Applied 2 changes\n")
        self.assertEqual(path.read_text(), "let x = bar(1);\nbar(2);\n")

    def test_repeated_meta_variable_requires_same_text(self):
        (self.tmp / "a.js").write_text("foo && foo();\nfoo && bar();\na && a();\n")
        result = self.run_cli("run", "-p", "$A && $A()", "-l", "js", "a.js", "--json=compact")
        self.assertEqual(result.returncode, 0, result.stderr)
        data = json.loads(result.stdout)
        self.assertEqual([m["text"] for m in data], ["foo && foo()", "a && a()"])
        self.assertEqual(data[0]["metaVariables"]["single"]["A"]["range"]["start"], {"line": 0, "column": 7})

    def test_scan_single_rule_json_and_short_report(self):
        (self.tmp / "rule.yml").write_text(
            "id: no-console\n"
            "language: JavaScript\n"
            "rule:\n"
            "  pattern: console.log($A)\n"
            "message: Do not log\n"
            "severity: warning\n"
        )
        (self.tmp / "a.js").write_text("console.log(123);\n")
        result = self.run_cli("scan", "-r", "rule.yml", "a.js", "--report-style=short")
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertEqual(result.stdout, "a.js:1:1: warning[no-console]: Do not log\n")

        result = self.run_cli("scan", "-r", "rule.yml", "a.js", "--json=compact")
        self.assertEqual(result.returncode, 0, result.stderr)
        data = json.loads(result.stdout)
        self.assertEqual(data[0]["ruleId"], "no-console")
        self.assertEqual(data[0]["message"], "Do not log")
        self.assertEqual(data[0]["severity"], "warning")

    def test_new_project_scaffolds_default_layout(self):
        result = self.run_cli("new", "project", "-y")
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertIn("Creating a new ast-grep project", result.stdout)
        self.assertTrue((self.tmp / "sgconfig.yml").exists())
        self.assertTrue((self.tmp / "rules" / ".gitkeep").exists())
        self.assertTrue((self.tmp / "rule-tests" / ".gitkeep").exists())


if __name__ == "__main__":
    unittest.main()
