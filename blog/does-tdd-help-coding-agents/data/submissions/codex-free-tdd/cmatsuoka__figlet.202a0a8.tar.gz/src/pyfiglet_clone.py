#!/usr/bin/env python3
import os
import shutil
import sys
from pathlib import Path

USAGE = "Usage: executable [ -cklnoprstvxDELNRSWX ] [ -d fontdirectory ]\n              [ -f fontfile ] [ -m smushmode ] [ -w outputwidth ]\n              [ -C controlfile ] [ -I infocode ] [ message ]\n"
VERSION_TEXT = """FIGlet Copyright (C) 1991-2012 Glenn Chappell, Ian Chai, John Cowan,
Christiaan Keet and Claudio Matsuoka
Internet: <info@figlet.org> Version: 2.2.5, date: 31 May 2012

FIGlet, along with the various FIGlet fonts and documentation, may be
freely copied and distributed.

If you use FIGlet, please send an e-mail message to <info@figlet.org>.

The latest version of FIGlet is available from the web site,
	http://www.figlet.org/

"""


def eprint(text):
    sys.stderr.write(text)


class Font:
    def __init__(self, path):
        self.path = path
        with open(path, "r", encoding="latin-1") as f:
            lines = f.read().splitlines()
        header = lines[0].split()
        sig = header[0]
        if not sig.startswith("flf2a"):
            raise ValueError("bad font")
        self.hardblank = sig[-1]
        self.height = int(header[1])
        self.old_layout = int(header[4]) if len(header) > 4 else 0
        self.comment_lines = int(header[5]) if len(header) > 5 else 0
        self.print_direction = int(header[6]) if len(header) > 6 else 0
        self.full_layout = int(header[7]) if len(header) > 7 else self.old_layout
        glyph_lines = lines[1 + self.comment_lines:]
        self.glyphs = {}
        index = 0
        for code in range(32, 127):
            chunk = glyph_lines[index:index + self.height]
            index += self.height
            if len(chunk) < self.height:
                break
            self.glyphs[chr(code)] = [self._strip_endmark(line) for line in chunk]
        # Some fonts have a literal DEL glyph after ASCII; not needed for normal text.

    @staticmethod
    def _strip_endmark(line):
        if not line:
            return line
        marker = line[-1]
        while line.endswith(marker):
            line = line[:-1]
        return line

    def glyph(self, ch):
        if ch == "\t":
            ch = " "
        return self.glyphs.get(ch, self.glyphs.get("?", self.glyphs.get(" ", [""] * self.height)))


def find_font(font_name, font_dir):
    names = [font_name]
    if not (font_name.endswith(".flf") or font_name.endswith(".tlf")):
        names.extend([font_name + ".flf", font_name + ".tlf"])
    candidates = []
    p = Path(font_name)
    if p.is_absolute() or "/" in font_name:
        candidates.extend(Path(n) for n in names)
    else:
        candidates.extend(Path(font_dir) / n for n in names)
        candidates.extend(Path.cwd() / n for n in names)
        candidates.extend(Path.cwd() / "fonts" / n for n in names)
    for c in candidates:
        if c.is_file():
            return c
    return None


HIERARCHY = "|/\\[]{}()<>"
OPPOSITES = {("[", "]"), ("{", "}"), ("(", ")")}
BIGX = {("/", "\\"): "|", ("\\", "/"): "Y", (">", "<"): "X"}


def smush_pair(left, right, hardblank):
    if left == " ":
        return right
    if right == " ":
        return left
    if left == hardblank and right == hardblank:
        return None
    if left == right:
        return left
    if left in HIERARCHY and right in HIERARCHY:
        return left if HIERARCHY.index(left) > HIERARCHY.index(right) else right
    if (left, right) in OPPOSITES:
        return "|"
    if (left, right) in BIGX:
        return BIGX[(left, right)]
    # The observed default layout keeps underscore/hierarchy pairs separate.
    return None


def can_overlay(left, right, hardblank, mode):
    if left == " " or right == " ":
        return True
    if mode == "kern":
        return False
    return smush_pair(left, right, hardblank) is not None


def merge_glyph(current, glyph, font, mode):
    if mode == "full" or not any(current):
        return [a + b for a, b in zip(current, glyph)]
    max_overlap = max(0, min(max(map(len, current)), max(map(len, glyph))) - 1)
    best = 0
    for overlap in range(max_overlap, 0, -1):
        ok = True
        for row in range(font.height):
            a = current[row]
            b = glyph[row]
            for i in range(overlap):
                ai = len(a) - overlap + i
                if ai < 0 or i >= len(b):
                    continue
                if not can_overlay(a[ai], b[i], font.hardblank, mode):
                    ok = False
                    break
            if not ok:
                break
        if ok:
            best = overlap
            break
    if best == 0:
        return [a + b for a, b in zip(current, glyph)]
    out = []
    for row in range(font.height):
        a = current[row]
        b = glyph[row]
        prefix = a[:-best]
        middle = []
        for i in range(best):
            ai = len(a) - best + i
            if ai < 0:
                middle.append(b[i])
                continue
            left = a[ai]
            right = b[i] if i < len(b) else " "
            if left == " ":
                middle.append(right)
            elif right == " ":
                middle.append(left)
            elif mode == "kern":
                middle.append(left)
            else:
                middle.append(smush_pair(left, right, font.hardblank) or left)
        out.append(prefix + "".join(middle) + b[best:])
    return out


def trim_left_fitting(glyph):
    rows = list(glyph)
    while rows and all(row.startswith(" ") or row == "" for row in rows):
        rows = [row[1:] if row else row for row in rows]
    return rows


def render_line(text, font, mode, direction):
    chars = list(text)
    if direction == "rtl":
        chars.reverse()
    rows = [""] * font.height
    for ch in chars:
        glyph = font.glyph(ch)
        if mode != "full":
            glyph = trim_left_fitting(glyph)
        rows = merge_glyph(rows, glyph, font, mode)
    return [r.replace(font.hardblank, " ") for r in rows]


def justify(rows, width, justify_mode):
    if justify_mode == "left":
        return rows
    out = []
    for r in rows:
        pad = max(0, width - len(r))
        if justify_mode == "right":
            out.append(" " * max(0, pad - 1) + r)
        elif justify_mode == "center":
            out.append(" " * (pad // 2) + r)
        else:
            out.append(r)
    return out


def render_text(text, font, mode="smush", width=80, justify_mode="left", direction="ltr", paragraph=False):
    logical_lines = text.splitlines()
    if text.endswith("\n"):
        pass
    if paragraph:
        combined = []
        para = []
        for line in logical_lines:
            if line.strip():
                para.append(line.strip())
            else:
                if para:
                    combined.append(" ".join(para))
                    para = []
                combined.append("")
        if para:
            combined.append(" ".join(para))
        logical_lines = combined
    if not logical_lines:
        logical_lines = [""]
    output = []
    for line in logical_lines:
        if width == 1:
            for ch in line:
                if ch == " ":
                    output.extend(render_line(ch, font, mode, direction))
                else:
                    output.extend(render_line(ch, font, mode, direction))
            continue
        rows = render_line(line, font, mode, direction)
        rows = justify(rows, width, justify_mode)
        output.extend(rows)
    return "\n".join(output) + "\n"


def parse_args(argv):
    opts = {
        "font": "standard",
        "font_dir": "/usr/local/share/figlet",
        "mode": "smush",
        "width": 80,
        "justify": "auto",
        "direction": "ltr",
        "paragraph": False,
        "info": None,
        "version": False,
        "messages": [],
    }
    i = 0
    while i < len(argv):
        arg = argv[i]
        if arg == "--":
            opts["messages"].extend(argv[i + 1:])
            break
        if arg.startswith("--"):
            eprint("./executable: invalid option -- '-'\n")
            eprint(USAGE)
            return None, 1
        if arg.startswith("-") and arg != "-":
            j = 1
            while j < len(arg):
                ch = arg[j]
                needs_value = ch in "dfmwCI"
                if needs_value:
                    if j + 1 < len(arg):
                        val = arg[j + 1:]
                        j = len(arg)
                    else:
                        i += 1
                        if i >= len(argv):
                            eprint(f"./executable: option requires an argument -- '{ch}'\n")
                            eprint(USAGE)
                            return None, 1
                        val = argv[i]
                    if ch == "d":
                        opts["font_dir"] = val
                    elif ch == "f":
                        opts["font"] = val
                    elif ch == "w":
                        try:
                            opts["width"] = int(val)
                        except ValueError:
                            opts["width"] = 80
                    elif ch == "m":
                        try:
                            modeval = int(val)
                            opts["mode"] = "full" if modeval == -1 else "smush"
                        except ValueError:
                            pass
                    elif ch == "I":
                        opts["info"] = val
                    # -C accepted but ignored
                    break
                elif ch == "v":
                    opts["version"] = True
                elif ch == "c":
                    opts["justify"] = "center"
                elif ch == "l":
                    opts["justify"] = "left"
                elif ch == "r":
                    opts["justify"] = "right"
                elif ch == "x":
                    opts["justify"] = "auto"
                elif ch == "L":
                    opts["direction"] = "ltr"
                elif ch == "R":
                    opts["direction"] = "rtl"
                elif ch == "W" or ch == "n":
                    opts["mode"] = "full"
                elif ch == "k":
                    opts["mode"] = "kern"
                elif ch == "s" or ch == "S":
                    opts["mode"] = "smush"
                elif ch == "p":
                    opts["paragraph"] = True
                elif ch == "t":
                    opts["width"] = shutil.get_terminal_size((opts["width"], 24)).columns
                elif ch in "oDENX":
                    pass
                else:
                    eprint(f"./executable: invalid option -- '{ch}'\n")
                    eprint(USAGE)
                    return None, 1
                j += 1
        else:
            opts["messages"].extend(argv[i:])
            break
        i += 1
    return opts, 0


def print_info(code):
    if code == "0":
        sys.stdout.write(VERSION_TEXT + USAGE)
    elif code == "1":
        sys.stdout.write("20205\n")
    elif code == "2":
        sys.stdout.write("/usr/local/share/figlet\n")
    elif code == "3":
        sys.stdout.write("standard\n")
    elif code == "4":
        sys.stdout.write("80\n")
    elif code == "5":
        sys.stdout.write("flf2 tlf2\n")
    else:
        return 1
    return 0


def main(argv):
    opts, status = parse_args(argv)
    if status:
        return status
    if opts is None:
        return 1
    if opts["version"]:
        sys.stdout.write(VERSION_TEXT + USAGE)
        return 0
    if opts["info"] is not None:
        return print_info(opts["info"])
    font_path = find_font(opts["font"], opts["font_dir"])
    if not font_path:
        eprint(f"./executable: {opts['font']}: Unable to open font file\n")
        return 1
    font = Font(font_path)
    if opts["messages"]:
        text = " ".join(opts["messages"])
    else:
        text = sys.stdin.read()
    justify_mode = opts["justify"]
    if justify_mode == "auto":
        justify_mode = "right" if opts["direction"] == "rtl" else "left"
    sys.stdout.write(render_text(text, font, opts["mode"], opts["width"], justify_mode, opts["direction"], opts["paragraph"]))
    return 0


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
