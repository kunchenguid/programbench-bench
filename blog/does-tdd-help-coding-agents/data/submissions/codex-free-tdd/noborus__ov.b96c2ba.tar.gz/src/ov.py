#!/usr/bin/env python3
import os
import sys
from pathlib import Path


HELP = """ov is a feature rich pager(such as more/less).
It supports various compressed files(gzip, bzip2, zstd, lz4, and xz).

Usage:
  ov [flags] [FILE]...

Flags:
Short   Long                                    Purpose
  -l, --align                                   align the output columns for better readability
  -C, --alternate-rows                          alternately change the line color
      --caption string                          custom caption
  -i, --case-sensitive                          case-sensitive in search
  -d, --column-delimiter character              column delimiter character (default ",")
  -c, --column-mode                             column mode
      --column-rainbow                          column mode to rainbow
      --column-width                            column mode for width
      --completion string                       generate completion script [bash|zsh|fish|powershell]
      --config file                             config file (default is $XDG_CONFIG_HOME/ov/config.yaml)
      --converter string                        converter [es|raw|align] (default "es")
      --debug                                   debug mode
      --disable-column-cycle                    disable column cycling
      --disable-mouse                           disable mouse support
  -e, --exec                                    command execution result instead of file
  -X, --exit-write                              output the current screen when exiting
  -a, --exit-write-after int                    number after the current lines when exiting
  -b, --exit-write-before int                   number before the current lines when exiting
      --filter string                           filter search pattern
  -A, --follow-all                              follow multiple files and show the most recently updated one
  -f, --follow-mode                             monitor file and display new content as it is written
      --follow-name                             follow mode to monitor by file name
      --follow-section                          section-by-section follow mode
      --force-screen                            display screen even when redirecting output
  -H, --header int                              number of header lines to be displayed constantly
  -Y, --header-column int                       number of columns to display as a vertical header
  -h, --help                                    help for ov
      --help-key                                display key bind information
      --hide-other-section                      hide other section
      --hscroll-width [int|int%|.int]           width to scroll horizontally [int|int%|.int] (default "10%")
      --incsearch[=true|false]                  incremental search (default true)
  -j, --jump-target [int|int%|.int|'section']   jump target [int|int%|.int|'section']
  -n, --line-number                             line number mode
      --list-view-modes                         list available view modes defined in the configuration file
      --memory-limit int                        number of chunks to limit in memory (default -1)
      --memory-limit-file int                   number of chunks to limit in memory for the file (default 100)
  -M, --multi-color strings                     comma separated words(regexp) to color .e.g. "ERROR,WARNING"
      --non-match-filter string                 filter non match search pattern
      --notify-eof int                          notify at the end of the file
      --pattern string                          search pattern
  -p, --plain                                   disable original decoration
  -F, --quit-if-one-screen                      quit if the output fits on one screen
  -r, --raw                                     raw escape sequences without processing
      --regexp-search                           regular expression search
      --ruler int                               display ruler (=0: none, =1: relative, =2: absolute)
      --section-delimiter regexp                regexp for section delimiter .e.g. "^#"
      --section-header                          enable section-delimiter line as Header
      --section-header-num int                  number of section header lines (default 1)
      --section-start int                       section start position
      --set-terminal-title                      set terminal title
      --skip-extract                            skip extracting compressed files
      --skip-lines int                          skip the number of lines
      --smart-case-sensitive                    smart case-sensitive in search
      --status-line[=true|false]                status line (default true)
  -x, --tab-width int                           tab stop width (default 8)
  -v, --version                                 display version information
  -y, --vertical-header int                     number of characters to display as a vertical header
  -m, --view-mode string                        apply predefined settings for a specific mode
  -T, --watch seconds                           watch mode interval(seconds)
  -w, --wrap[=true|false]                       wrap mode (default true)
"""

BOOL_FLAGS = {
    "-l", "--align", "-C", "--alternate-rows", "-i", "--case-sensitive",
    "-c", "--column-mode", "--column-rainbow", "--column-width", "--debug",
    "--disable-column-cycle", "--disable-mouse", "-e", "--exec", "-X",
    "--exit-write", "-A", "--follow-all", "-f", "--follow-mode",
    "--follow-name", "--follow-section", "--force-screen", "--help-key",
    "--hide-other-section", "-n", "--line-number", "--list-view-modes",
    "-p", "--plain", "-F", "--quit-if-one-screen", "-r", "--raw",
    "--regexp-search", "--section-header", "--set-terminal-title",
    "--skip-extract", "--smart-case-sensitive",
}

VALUE_FLAGS = {
    "--caption", "-d", "--column-delimiter", "--completion", "--config",
    "--converter", "-a", "--exit-write-after", "-b", "--exit-write-before",
    "--filter", "-H", "--header", "-Y", "--header-column", "--hscroll-width",
    "-j", "--jump-target", "--memory-limit", "--memory-limit-file", "-M",
    "--multi-color", "--non-match-filter", "--notify-eof", "--pattern",
    "--ruler", "--section-delimiter", "--section-header-num",
    "--section-start", "--skip-lines", "-x", "--tab-width", "-y",
    "--vertical-header", "-m", "--view-mode", "-T", "--watch",
}

OPTIONAL_BOOL_FLAGS = {"--incsearch", "--status-line", "-w", "--wrap"}


def parse_args(argv):
    files = []
    i = 0
    while i < len(argv):
        arg = argv[i]
        if arg == "--":
            files.extend(argv[i + 1 :])
            break
        if arg in ("-h", "--help"):
            return "help", []
        if arg in ("-v", "--version"):
            return "version", []
        if arg.startswith("--completion="):
            return "completion", [arg.split("=", 1)[1]]
        if arg == "--completion":
            if i + 1 >= len(argv):
                return "error", ["flag needs an argument: --completion"]
            return "completion", [argv[i + 1]]
        if arg in ("--help-key",):
            return "help-key", []
        if arg == "--list-view-modes":
            return "view-modes", []
        if arg.startswith("-") and "=" in arg:
            name = arg.split("=", 1)[0]
            if name in OPTIONAL_BOOL_FLAGS or name in VALUE_FLAGS:
                i += 1
                continue
        if arg in BOOL_FLAGS or arg in OPTIONAL_BOOL_FLAGS:
            i += 1
            continue
        if arg in VALUE_FLAGS:
            i += 2
            continue
        if arg.startswith("-"):
            return "error", [f"unknown flag: {arg}"]
        files.append(arg)
        i += 1
    return "cat", files


def copy_path(path):
    try:
        with open(path, "rb") as handle:
            while True:
                chunk = handle.read(1024 * 1024)
                if not chunk:
                    break
                sys.stdout.buffer.write(chunk)
    except FileNotFoundError:
        sys.stderr.write(f"Error: open {path}: no such file or directory\n")
        return 1
    except IsADirectoryError:
        sys.stderr.write(f"Error: read {path}: is a directory\n")
        return 1
    except PermissionError:
        sys.stderr.write(f"Error: open {path}: permission denied\n")
        return 1
    return 0


def main(argv=None):
    argv = list(sys.argv[1:] if argv is None else argv)
    mode, values = parse_args(argv)
    if mode == "version":
        sys.stdout.write("ov version dev rev:HEAD\n")
        return 0
    if mode == "help":
        sys.stdout.write(HELP)
        return 0
    if mode == "error":
        sys.stderr.write(f"Error: {values[0]}\n")
        return 1
    if mode == "view-modes":
        sys.stdout.write("general\n")
        return 0
    if mode == "help-key":
        sys.stdout.write(data_file("help-key.txt"))
        return 0
    if mode == "completion":
        shell = values[0]
        if shell not in ("bash", "zsh", "fish", "powershell"):
            sys.stderr.write("Error: requires one of the arguments bash/zsh/fish/powershell\n")
            return 1
        sys.stdout.write(completion(shell))
        return 0
    if values:
        status = 0
        for path in values:
            code = copy_path(path)
            if code:
                status = code
                break
        return status
    data = sys.stdin.buffer.read()
    sys.stdout.buffer.write(data)
    return 0


def completion(shell):
    return data_file("completions", f"{shell}.txt")


def data_file(*parts):
    base = Path(__file__).resolve().parent
    candidates = [
        base.joinpath(*parts),
        base / "src" / Path(*parts),
    ]
    for path in candidates:
        if path.exists():
            return path.read_text()
    raise FileNotFoundError(str(candidates[0]))


if __name__ == "__main__":
    raise SystemExit(main())
