#!/usr/bin/env python3
import argparse
import json
import os
import re
import sys
from datetime import datetime, timezone


BOLD = "\033[1m"
DIM = "\033[2m"
RESET = "\033[0m"

DEFAULTS = {
    "message_keys": ["short_message", "msg", "message"],
    "time_keys": ["timestamp", "time", "@timestamp"],
    "level_keys": ["level", "severity", "log.level", "loglevel"],
    "dump_all_exclude": [],
    "always_print_fields": [],
    "level_map": {},
}

HELP_TEXT = """json log viewer

Usage: executable [OPTIONS] [INPUT]

Arguments:
  [INPUT]  Sets the input file to use, otherwise assumes stdin [default: -]

Options:
  -a, --additional-value <additional-value>
          adds additional values
      --config-file <config-file>
          configuration file to load
  -m, --message-key <message-key>
          Adds an additional key to detect the message in the log entry. The first matching key will be assigned to `fblog_message`.
      --print-lua
          Prints lua init expressions. Used for fblog debugging.
  -t, --time-key <time-key>
          Adds an additional key to detect the time in the log entry. The first matching key will be assigned to `fblog_timestamp`.
  -l, --level-key <level-key>
          Adds an additional key to detect the level in the log entry. The first matching key will be assigned to `fblog_level`.
      --map-level <from=to>
          Rewrite the log level from one value to another.
  -d, --dump-all
          dumps all values
  -x, --excluded-value <excluded-value>
          Excludes values (--dump-all is enabled implicitly)
  -p, --with-prefix
          consider all text before opening curly brace as prefix
  -f, --filter <filter>
          lua expression to filter log entries. `message ~= nil and string.find(message, "text.*") ~= nil`
      --no-implicit-filter-return-statement
          if you pass a filter expression 'return' is automatically prepended. Pass this switch to disable the implicit return.
      --main-line-format <main-line-format>
          Formats the main fblog output. All log values can be used. fblog provides sanitized variables starting with `fblog_`.
      --additional-value-format <additional-value-format>
          Formats the additional value fblog output.
  -s, --substitute
          Enable substitution of placeholders in the log messages with their corresponding values from the context.
  -c, --context-key <context-key>
          Use this key as the source of substitutions for the message. Value can either be an array ({1}) or an object ({key}).
  -F, --placeholder-format <placeholder-format>
          The format that should be used for substituting values in the message, where the key is the literal word `key`. Example: [[key]] or ${key}.
  -h, --help
          Print help
  -V, --version
          Print version
"""


def c(code, text):
    return f"\033[{code}m{text}{RESET}"


def bold(text):
    return BOLD + text + RESET


def rgb(r, g, b, text):
    return f"\033[38;2;{r};{g};{b}m{text}{RESET}"


def parse_args():
    if "--help" in sys.argv[1:] or "-h" in sys.argv[1:]:
        print(HELP_TEXT, end="")
        raise SystemExit(0)
    p = argparse.ArgumentParser(
        prog="executable",
        description="json log viewer",
        formatter_class=argparse.RawTextHelpFormatter,
        add_help=False,
    )
    p.add_argument("input", nargs="?", default="-", help="Sets the input file to use, otherwise assumes stdin [default: -]")
    p.add_argument("-a", "--additional-value", action="append", default=[])
    p.add_argument("--config-file")
    p.add_argument("-m", "--message-key", action="append", default=[])
    p.add_argument("--print-lua", action="store_true")
    p.add_argument("-t", "--time-key", action="append", default=[])
    p.add_argument("-l", "--level-key", action="append", default=[])
    p.add_argument("--map-level", action="append", default=[])
    p.add_argument("-d", "--dump-all", action="store_true")
    p.add_argument("-x", "--excluded-value", action="append", default=[])
    p.add_argument("-p", "--with-prefix", action="store_true")
    p.add_argument("-f", "--filter")
    p.add_argument("--no-implicit-filter-return-statement", action="store_true")
    p.add_argument("--main-line-format")
    p.add_argument("--additional-value-format")
    p.add_argument("-s", "--substitute", action="store_true")
    p.add_argument("-c", "--context-key")
    p.add_argument("-F", "--placeholder-format", default="{key}")
    p.add_argument("-V", "--version", action="store_true")
    return p.parse_args()


def parse_toml(path):
    cfg = {k: (v.copy() if isinstance(v, list) else v.copy() if isinstance(v, dict) else v) for k, v in DEFAULTS.items()}
    if not path or not os.path.exists(path):
        return cfg
    section = None
    for raw in open(path, encoding="utf-8"):
        line = raw.strip()
        if not line or line.startswith("#"):
            continue
        if line.startswith("[") and line.endswith("]"):
            section = line[1:-1]
            continue
        if "=" not in line:
            continue
        key, val = [x.strip() for x in line.split("=", 1)]
        if section == "level_map":
            cfg["level_map"][key.strip('"')] = val.strip().strip('"')
        elif val.startswith("["):
            cfg[key] = re.findall(r'"([^"]*)"', val)
        else:
            cfg[key] = val.strip('"')
    return cfg


def get_path(obj, path):
    if isinstance(obj, dict) and path in obj:
        return obj[path]
    if " > " in path:
        path = path.replace(" > ", ".")
    elif "." in path:
        return None
    cur = obj
    for part in path.split("."):
        if isinstance(cur, dict) and part in cur:
            cur = cur[part]
        else:
            return None
    return cur


def first_value(obj, keys):
    for k in keys:
        v = get_path(obj, k)
        if v is not None:
            return v
    return None


def timestamp_text(v):
    if v is None:
        return "???"
    s = str(v)
    if re.fullmatch(r"\d{12,}", s):
        try:
            return datetime.fromtimestamp(int(s) / 1000, tz=timezone.utc).strftime("%Y-%m-%dT%H:%M:%S")
        except Exception:
            pass
    if len(s) >= 19:
        return s[:19]
    return s


def level_color(level):
    l = str(level or "unknown").lower()
    if l in ("info", "information", "30"):
        return "1;32"
    if l in ("warn", "warning", "40"):
        return "1;33" if l == "warn" else "1;35"
    if l in ("error", "err", "50"):
        return "1;31"
    if l in ("debug", "20"):
        return "1;34"
    return "1;35"


def level_text(level):
    s = str(level if level is not None else "unknown").upper()
    return s[:5].rjust(5)


def simple_value(v, quote_nested_string=False):
    if isinstance(v, bool):
        return "true" if v else "false"
    if v is None:
        return "null"
    if isinstance(v, (int, float)):
        return str(v)
    if isinstance(v, str):
        return json.dumps(v) if quote_nested_string else v
    return json.dumps(v, separators=(",", ":"))


def styled_value(v):
    if isinstance(v, bool):
        return c("1;32" if v else "1;31", "true" if v else "false")
    if isinstance(v, (int, float)):
        return c("1;36", str(v))
    if isinstance(v, str):
        return c("1;33", v)
    if isinstance(v, list):
        parts = [DIM + "[" + RESET]
        for i, item in enumerate(v):
            if i:
                parts.append(DIM + ", " + RESET)
            parts.append(styled_value(item))
        parts.append(DIM + "]" + RESET)
        return "".join(parts)
    if isinstance(v, dict):
        parts = [DIM + "{" + RESET]
        for i, k in enumerate(sorted(v.keys())):
            if i:
                parts.append(DIM + ", " + RESET)
            parts.append(c("35", str(k)) + DIM + ": " + RESET + styled_value(v[k]))
        parts.append(DIM + "}" + RESET)
        return "".join(parts)
    return str(v)


def substitute_message(msg, ctx, fmt):
    if ctx is None:
        return msg
    def replacement(key):
        val = None
        if isinstance(ctx, list) and key.isdigit():
            idx = int(key)
            if 0 <= idx < len(ctx):
                val = ctx[idx]
        elif isinstance(ctx, dict) and key in ctx:
            val = ctx[key]
        if val is None:
            return DIM + "{" + RESET + c("1;31", key) + DIM + "}" + RESET
        return styled_value(val)
    pattern = re.escape(fmt).replace("key", r"([^{}#$\[\]]+)")
    return re.sub(pattern, lambda m: replacement(m.group(1)), msg)


def flatten(name, val, out, depth=0, parent_list=False):
    if isinstance(val, dict):
        for k in sorted(val.keys()):
            flatten(f"{name} > {k}", val[k], out, depth, False)
    elif isinstance(val, list):
        for i, item in enumerate(val):
            idx = i if depth == 0 else i + 1
            flatten(f"{name}[{idx}]", item, out, depth + 1, True)
    else:
        out.append((name, simple_value(val, quote_nested_string=parent_list and isinstance(val, str))))


def additional_line(key, value):
    padded = key.rjust(25)
    return bold(rgb(150, 150, 150, padded)) + ": " + value


def render_template(tpl, values):
    def repl(m):
        expr = m.group(1).strip()
        return str(values.get(expr, ""))
    return re.sub(r"\{\{\s*([^{}]+?)\s*\}\}", repl, tpl)


def filter_match(expr, obj):
    if not expr:
        return True
    expr = expr.strip()
    m = re.fullmatch(r'([\w.@-]+)\s*(==|~=|!=|>=|<=|>|<)\s*"([^"]*)"', expr)
    if not m:
        m = re.fullmatch(r'([\w.@-]+)\s*(==|~=|!=|>=|<=|>|<)\s*([0-9.]+)', expr)
    if not m:
        return True
    key, op, rhs = m.group(1), m.group(2), m.group(3)
    lhs = get_path(obj, key)
    if lhs is None:
        return True
    if op in ("==", "~=", "!="):
        res = str(lhs) == rhs
        return res if op == "==" else not res
    try:
        a, b = float(lhs), float(rhs)
    except Exception:
        return True
    return {">": a > b, "<": a < b, ">=": a >= b, "<=": a <= b}[op]


def process_json(obj, prefix, args, cfg):
    if not filter_match(args.filter, obj):
        return []
    message = first_value(obj, args.message_key + cfg["message_keys"])
    ts = timestamp_text(first_value(obj, args.time_key + cfg["time_keys"]))
    level = first_value(obj, args.level_key + cfg["level_keys"])
    if level is not None:
        level = cfg["level_map"].get(str(level), str(level))
    for mp in args.map_level:
        if "=" in mp:
            a, b = mp.split("=", 1)
            if str(level) == a:
                level = b
    if args.substitute:
        message = substitute_message(str(message), get_path(obj, args.context_key or "context"), args.placeholder_format)
    else:
        message = "" if message is None else str(message)
    raw_level = str(level if level is not None else "unknown").upper()
    if args.main_line_format:
        line = render_template(args.main_line_format, {
            "fblog_timestamp": ts,
            "fblog_level": raw_level,
            "fblog_message": message,
            "fblog_prefix": prefix,
        })
    else:
        line = f"{bold(ts)} {c(level_color(level), level_text(level))}:"
        if prefix:
            line += " " + bold(c("36", prefix))
        line += " " + message
    lines = [line]
    keys = list(args.additional_value) + list(cfg.get("always_print_fields", []))
    if args.dump_all or args.excluded_value:
        keys = [k for k in sorted(obj.keys()) if k not in set(args.excluded_value + cfg.get("dump_all_exclude", []))]
    for key in keys:
        val = get_path(obj, key)
        if val is None:
            continue
        flat = []
        flatten(key, val, flat)
        for k, v in flat:
            if args.additional_value_format:
                lines.append(render_template(args.additional_value_format, {"key": k, "value": v}))
            else:
                lines.append(additional_line(k, v))
    return lines


def process_line(raw, args, cfg):
    line = raw.rstrip("\n")
    prefix = ""
    payload = line
    if args.with_prefix:
        idx = line.find("{")
        if idx > 0:
            prefix, payload = line[:idx].rstrip(), line[idx:]
    try:
        obj = json.loads(payload)
        if not isinstance(obj, dict):
            raise ValueError
    except Exception:
        color = "1;38;2;255;135;22"
        return [c(color, "??? >") + " " + line]
    return process_json(obj, prefix, args, cfg)


def main():
    args = parse_args()
    if args.version:
        print("fblog 4.17.0")
        return 0
    if args.print_lua:
        return 0
    cfg = parse_toml(args.config_file)
    try:
        if args.input == "-":
            data = sys.stdin.buffer.read().splitlines()
            for b in data:
                try:
                    raw = b.decode("utf-8")
                except UnicodeDecodeError:
                    print(c("1;31", "??? >") + " Could not read line: stream did not contain valid UTF-8")
                    continue
                for out in process_line(raw, args, cfg):
                    print(out)
        else:
            with open(args.input, "rb") as fh:
                for b in fh.read().splitlines():
                    try:
                        raw = b.decode("utf-8")
                    except UnicodeDecodeError:
                        print(c("1;31", "??? >") + " Could not read line: stream did not contain valid UTF-8")
                        continue
                    for out in process_line(raw, args, cfg):
                        print(out)
    except BrokenPipeError:
        return 0
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
