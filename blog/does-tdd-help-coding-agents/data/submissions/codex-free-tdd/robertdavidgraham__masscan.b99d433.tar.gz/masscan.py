#!/usr/bin/env python3
import os
import random
import re
import sys


USAGE_LONG = """usage: masscan [options] [<IP|RANGE>... -pPORT[,PORT...]]
MASSCAN is a fast port scanner. The primary input parameters are the
IP addresses/ranges you want to scan, and the port numbers. An example
is the following, which scans the 10.x.x.x network for web servers:

    masscan 10.0.0.0/8 -p80

The program auto-detects network interface/adapter settings. If this
fails, you'll have to set these manually. The following is an
example of all the parameters that are needed:

    --adapter-ip 192.168.10.123
    --adapter-mac 00-11-22-33-44-55
    --router-mac 66-55-44-33-22-11

Parameters can be set either via the command-line or config-file. The
names are the same for both. Thus, the above adapter settings would
appear as follows in a configuration file:

    adapter-ip = 192.168.10.123
    adapter-mac = 00-11-22-33-44-55
    router-mac = 66-55-44-33-22-11

All single-dash parameters have a spelled out double-dash equivalent,
so '-p80' is the same as '--ports 80' (or 'ports = 80' in config file).
To use the config file, type:

    masscan -c <filename>

To generate a config-file from the current settings, use the --echo
option. This stops the program from actually running, and just echoes
the current configuration instead. This is a useful way to generate
your first config file, or see a list of parameters you didn't know
about. I suggest you try it now:

    masscan -p1234 --echo
"""

USAGE_SHORT = """usage: masscan [options] [<IP|RANGE>... -pPORT[,PORT...]]

examples:
    masscan -p80,8000-8100 10.0.0.0/8 --rate=10000
        scan some web ports on 10.x.x.x at 10kpps

    masscan --nmap
        list those options that are compatible with nmap

    masscan -p80 10.0.0.0/8 --banners -oB <filename>
        save results of scan in binary format to <filename>

    masscan --open --banners --readscan <filename> -oX <savefile>
        read binary scan results in <filename> and save them as xml in <savefile>
"""

VERSION = """
Masscan version 1.3.9-integration ( https://github.com/robertdavidgraham/masscan )
Compiled on: Apr 17 2026 19:59:25
Compiler: gcc 11.4.0
OS: Linux
CPU: x86 (64 bits)
GIT version: unknown
"""

PCAP_FAIL = "[-] FAIL: failed to load libpcap shared library\n    [hint]: you must install libpcap or WinPcap\n"


class Config:
    def __init__(self):
        self.seed = None
        self.rate = "100"
        self.shard = "1/1"
        self.ports = ""
        self.ranges = []
        self.banners = False
        self.rawudp = False
        self.open_only = False
        self.output_filename = None
        self.output_format = None
        self.readscan = None
        self.excludefile = []
        self.includefile = []
        self.extra = {}
        self.echo = False


def need_value(args, i, opt):
    if i + 1 >= len(args):
        raise ValueError(f"{opt}: empty parameter")
    return args[i + 1], i + 1


def normalize_ports(text):
    tcp, udp, other = [], [], []
    for raw in re.split(r"[, ]+", text.strip()):
        if not raw:
            continue
        if raw.upper().startswith("U:"):
            udp.append("U:" + raw[2:])
        elif raw.upper().startswith("T:"):
            tcp.append(raw[2:])
        else:
            other.append(raw)
    return ",".join(other + tcp + udp)


def apply_kv(cfg, key, value):
    k = key.strip().lower().replace("_", "-")
    v = value.strip()
    if k in ("p", "ports", "port"):
        cfg.ports = normalize_ports(v)
    elif k in ("rate", "max-rate"):
        if not re.match(r"^[0-9]+(\.[0-9]+)?$", v):
            raise ValueError(f"CONF: non-digit in rate spec: rate={v}")
        cfg.rate = v
    elif k in ("range", "ranges"):
        cfg.ranges.append(v)
    elif k in ("include-file", "includefile"):
        cfg.includefile.append(v)
    elif k in ("exclude-file", "excludefile", "exclude"):
        cfg.excludefile.append(v)
    elif k in ("output-filename", "output-file"):
        cfg.output_filename = v
    elif k in ("output-format",):
        cfg.output_format = v
    elif k in ("banners", "banner"):
        cfg.banners = v.lower() not in ("0", "false", "no", "off")
    elif k == "rawudp":
        cfg.rawudp = v.lower() not in ("0", "false", "no", "off")
    elif k == "shard":
        cfg.shard = v
    elif k == "seed":
        cfg.seed = v
    elif k in ("adapter-ip", "adapter-mac", "router-mac", "interface",
               "source-ip", "src-ip", "source-port", "src-port", "wait",
               "ping", "scan-module", "rotate", "max-filesize"):
        cfg.extra[k] = v
    else:
        cfg.extra[k] = v


def read_config(cfg, filename):
    with open(filename, "r", encoding="utf-8", errors="replace") as f:
        for line in f:
            line = line.strip()
            if not line or line.startswith("#"):
                continue
            if "=" in line:
                k, v = line.split("=", 1)
            else:
                parts = line.split(None, 1)
                if len(parts) == 1:
                    continue
                k, v = parts
            apply_kv(cfg, k, v)


def parse_args(args):
    cfg = Config()
    passthrough_help = None
    errors = []
    i = 0
    while i < len(args):
        a = args[i]
        if a == "--":
            i += 1
            continue
        if a == "--help":
            passthrough_help = "long"
        elif a in ("-h", "-?"):
            passthrough_help = "short"
        elif a == "--nmap":
            passthrough_help = "nmap"
        elif a in ("--version", "-V"):
            passthrough_help = "version"
        elif a == "--echo":
            cfg.echo = True
        elif a in ("-c", "--conf", "--config", "--config-file"):
            v, i = need_value(args, i, a)
            read_config(cfg, v)
        elif a.startswith("--") and "=" in a:
            k, v = a[2:].split("=", 1)
            if k in ("echo", "banners", "open", "rawudp"):
                apply_flag(cfg, "--" + k)
            else:
                apply_kv(cfg, k, v)
        elif a in ("-p", "--ports", "--port"):
            v, i = need_value(args, i, a)
            cfg.ports = normalize_ports(v)
        elif a.startswith("-p") and len(a) > 2:
            cfg.ports = normalize_ports(a[2:])
        elif a in ("--rate", "--max-rate"):
            v, i = need_value(args, i, a)
            apply_kv(cfg, "rate", v)
        elif a in ("--range", "--ranges"):
            v, i = need_value(args, i, a)
            cfg.ranges.append(v)
        elif a == "--readscan":
            v, i = need_value(args, i, a)
            cfg.readscan = v
            cfg.banners = True
            cfg.rawudp = True
        elif a in ("--output-format",):
            cfg.output_format, i = need_value(args, i, a)
        elif a in ("--output-filename",):
            cfg.output_filename, i = need_value(args, i, a)
        elif a in ("-oX", "-oG", "-oJ", "-oL", "-oB"):
            v, i = need_value(args, i, a)
            cfg.output_filename = v
            cfg.output_format = {"-oX": "xml", "-oG": "grepable", "-oJ": "json", "-oL": "list", "-oB": "binary"}[a]
        elif len(a) > 2 and a[:3] in ("-oX", "-oG", "-oJ", "-oL", "-oB"):
            cfg.output_filename = a[3:]
            cfg.output_format = {"-oX": "xml", "-oG": "grepable", "-oJ": "json", "-oL": "list", "-oB": "binary"}[a[:3]]
        elif a in ("--banners", "--banner"):
            cfg.banners = True
        elif a == "--rawudp":
            cfg.rawudp = True
        elif a == "--open":
            cfg.open_only = True
        elif a in ("--exclude-file", "--excludefile"):
            v, i = need_value(args, i, a)
            cfg.excludefile.append(v)
        elif a in ("--include-file", "--includefile", "-iL"):
            v, i = need_value(args, i, a)
            cfg.includefile.append(v)
        elif a.startswith("-"):
            # Accept nmap-compatible no-op flags that often appear in examples.
            if a in ("-sS", "-Pn", "-n", "--randomize-hosts", "--send-eth", "--send-ip", "--offline"):
                pass
            else:
                errors.append(f"{a}: unknown option")
        else:
            cfg.ranges.append(a)
        i += 1
    return cfg, passthrough_help, errors


def apply_flag(cfg, flag):
    if flag == "--banners":
        cfg.banners = True
    elif flag == "--open":
        cfg.open_only = True
    elif flag == "--rawudp":
        cfg.rawudp = True
    elif flag == "--echo":
        cfg.echo = True


def echo_config(cfg):
    seed = cfg.seed or str(random.getrandbits(64))
    out = []
    out.append(f"seed = {seed}")
    out.append(f"rate = {cfg.rate:<10}")
    out.append(f"shard = {cfg.shard}")
    if cfg.banners:
        out.append("banners = true")
    if cfg.rawudp:
        out.append("rawudp = true")
    out.append("nocapture = servername")
    out.append("nocapture = servername")
    out.append("")
    if cfg.output_filename is not None:
        out.append(f"output-filename = {cfg.output_filename}")
    if cfg.output_format is not None:
        out.append(f"output-format = {cfg.output_format}")
    if cfg.output_filename is not None or cfg.output_format is not None:
        out.append("")
    out.append("# TARGET SELECTION (IP, PORTS, EXCLUDES)")
    out.append(f"ports = {cfg.ports}")
    for r in cfg.ranges:
        out.append(f"range = {r}")
    for f in cfg.includefile:
        out.append(f"includefile = {f}")
    for f in cfg.excludefile:
        out.append(f"excludefile = {f}")
    return "\n".join(out) + "\n"


def readscan(cfg):
    sys.stderr.write(f"[+] --readscan {cfg.readscan}\n")
    try:
        with open(cfg.readscan, "rb") as f:
            data = f.read(32)
    except OSError as e:
        sys.stderr.write(f"[-] {cfg.readscan}: {e.strerror}\n")
        return 0
    if not data.startswith(b"masscan/1.1"):
        sys.stderr.write(f"[-] {cfg.readscan}: unknown file format (expeced \"masscan/1.1\")\n")
        return 0
    # Minimal support for empty/opaque masscan files: produce valid empty outputs.
    emit_empty_output(cfg)
    return 0


def emit_empty_output(cfg):
    target = cfg.output_filename
    fmt = cfg.output_format or "list"
    if not target or target == "-":
        if fmt == "json":
            sys.stdout.write("[\n]\n")
        elif fmt == "xml":
            sys.stdout.write('<?xml version="1.0"?>\n<nmaprun scanner="masscan">\n</nmaprun>\n')
        return
    content = ""
    if fmt == "json":
        content = "[\n]\n"
    elif fmt == "xml":
        content = '<?xml version="1.0"?>\n<nmaprun scanner="masscan">\n</nmaprun>\n'
    open(target, "w", encoding="utf-8").write(content)


def main(argv):
    if not argv:
        sys.stdout.write(USAGE_SHORT)
        return 1
    try:
        cfg, special, errors = parse_args(argv)
    except ValueError as e:
        sys.stderr.write(str(e) + "\n")
        sys.stdout.write(USAGE_SHORT)
        return 1
    if special == "long":
        sys.stdout.write(USAGE_LONG)
        return 1
    if special == "short":
        sys.stdout.write(USAGE_SHORT)
        return 1
    if special == "nmap":
        sys.stdout.write(USAGE_SHORT)
        sys.stderr.write(PCAP_FAIL)
        return 1
    if special == "version":
        sys.stdout.write(VERSION)
        sys.stderr.write(PCAP_FAIL)
        return 1
    for e in errors:
        sys.stderr.write(e + "\n")
    if cfg.echo:
        sys.stderr.write(PCAP_FAIL)
        if cfg.readscan:
            readscan(cfg)
        sys.stdout.write(echo_config(cfg))
        return 0
    if cfg.readscan:
        sys.stderr.write(PCAP_FAIL)
        return readscan(cfg)
    if errors:
        sys.stdout.write(USAGE_SHORT)
        return 1
    if not cfg.ports:
        sys.stderr.write("FAIL: no ports were specified\n [hint] try something like \"-p80,8000-9000\"\n [hint] try something like \"--ports 0-65535\"\n")
        return 1
    if not cfg.ranges and not cfg.includefile:
        sys.stderr.write("FAIL: target IP address list empty\n [hint] try something like \"--range 10.0.0.0/8\"\n [hint] try something like \"--range 192.168.0.100-192.168.0.200\"\n")
        return 1
    sys.stderr.write(PCAP_FAIL)
    sys.stderr.write("[-] FAIL: could not determine default interface\n    [hint] try \"--interface ethX\"\n")
    return 1


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
