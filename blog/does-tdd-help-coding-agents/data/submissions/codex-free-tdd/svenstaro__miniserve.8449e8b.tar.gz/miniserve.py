#!/usr/bin/env python3
import base64
import cgi
import gzip
import hashlib
import html
import http.server
import io
import mimetypes
import os
import posixpath
import random
import shutil
import socket
import socketserver
import ssl
import string
import sys
import tarfile
import tempfile
import urllib.parse
import zipfile
from pathlib import Path


VERSION = "miniserve 0.32.0"

SHORT_HELP = """For when you really just want to serve some files over HTTP right now!

Usage: executable [OPTIONS] [PATH]

Arguments:
  [PATH]  Which path to serve [env: MINISERVE_PATH=]

Options:
  -v, --verbose          Be verbose, includes emitting access logs [env: MINISERVE_VERBOSE=]
      --temp-directory <TEMP_UPLOAD_DIRECTORY>
          The path to where file uploads will be written to before being moved to their correct
          location. It's wise to make sure that this directory will be written to disk and not into
          memory [env: MINISERVER_TEMP_UPLOAD_DIRECTORY=]
      --index <INDEX>    The name of a directory index file to serve, like "index.html" [env: MINISERVE_INDEX=]
      --spa              Activate SPA (Single Page Application) mode [env: MINISERVE_SPA=]
      --pretty-urls      Activate Pretty URLs mode [env: MINISERVE_PRETTY_URLS=]
  -p, --port <PORT>      Port to use [env: MINISERVE_PORT=] [default: 8080]
  -i, --interfaces <INTERFACES>
          Interface to listen on [env: MINISERVE_INTERFACE=]
  -a, --auth <AUTH>      Set authentication [env: MINISERVE_AUTH=]
      --auth-file <AUTH_FILE>
          Read authentication values from a file [env: MINISERVE_AUTH_FILE=]
      --route-prefix <ROUTE_PREFIX>
          Use a specific route prefix [env: MINISERVE_ROUTE_PREFIX=]
      --random-route     Generate a random 6-hexdigit route [env: MINISERVE_RANDOM_ROUTE=]
  -P, --no-symlinks      Hide symlinks in listing and prevent them from being followed [env: MINISERVE_NO_SYMLINKS=]
  -H, --hidden           Show hidden files [env: MINISERVE_HIDDEN=]
  -S, --default-sorting-method <DEFAULT_SORTING_METHOD>
          Default sorting method for file list [env: MINISERVE_DEFAULT_SORTING_METHOD=] [default: name] [possible values: name, size, date]
  -O, --default-sorting-order <DEFAULT_SORTING_ORDER>
          Default sorting order for file list [env: MINISERVE_DEFAULT_SORTING_ORDER=] [default: desc] [possible values: asc, desc]
  -c, --color-scheme <COLOR_SCHEME>
          Default color scheme [env: MINISERVE_COLOR_SCHEME=] [default: squirrel] [possible values: squirrel, archlinux, zenburn, monokai]
  -d, --color-scheme-dark <COLOR_SCHEME_DARK>
          Default color scheme [env: MINISERVE_COLOR_SCHEME_DARK=] [default: archlinux] [possible values: squirrel, archlinux, zenburn, monokai]
  -q, --qrcode           Enable QR code display [env: MINISERVE_QRCODE=]
  -u, --upload-files [<ALLOWED_UPLOAD_DIR>]
          Enable file uploading (and optionally specify for which directory) [env: MINISERVE_ALLOWED_UPLOAD_DIR=]
      --web-upload-files-concurrency <WEB_UPLOAD_CONCURRENCY>
          Configure amount of concurrent uploads when visiting the website. Must have upload-files option enabled for this setting to matter [env: MINISERVE_WEB_UPLOAD_CONCURRENCY=] [default: 0]
      --chmod <CHMOD>    Set unix file permissions of uploaded files [env: MINISERVE_CHMOD=]
      --directory-size   Enable recursive directory size calculation [env: MINISERVE_DIRECTORY_SIZE=]
  -U, --mkdir            Enable creating directories [env: MINISERVE_MKDIR_ENABLED=]
  -m, --media-type <MEDIA_TYPE>
          Specify uploadable media types [env: MINISERVE_MEDIA_TYPE=] [possible values: image, audio, video]
  -M, --raw-media-type <MEDIA_TYPE_RAW>
          Directly specify the uploadable media type expression [env: MINISERVE_RAW_MEDIA_TYPE=]
  -o, --on-duplicate-files <ON_DUPLICATE_FILES>
          What to do if existing files with same name is present during file upload [env: MINISERVE_ON_DUPLICATE_FILES=] [default: error] [possible values: error, overwrite, rename]
  -R, --rm-files [<ALLOWED_RM_DIR>]
          Enable file and directory deletion (and optionally specify for which directory) [env: MINISERVE_ALLOWED_RM_DIR=]
  -r, --enable-tar       Enable uncompressed tar archive generation [env: MINISERVE_ENABLE_TAR=]
  -g, --enable-tar-gz    Enable gz-compressed tar archive generation [env: MINISERVE_ENABLE_TAR_GZ=]
  -z, --enable-zip       Enable zip archive generation [env: MINISERVE_ENABLE_ZIP=]
  -C, --compress-response
          Compress response [env: MINISERVE_COMPRESS_RESPONSE=]
  -D, --dirs-first       List directories first [env: MINISERVE_DIRS_FIRST=]
  -t, --title <TITLE>    Shown instead of host in page title and heading [env: MINISERVE_TITLE=]
      --header <HEADER>  Inserts custom headers into the responses. Specify each header as a 'Header:Value' pair. This parameter can be used multiple times to add multiple headers [env: MINISERVE_HEADER=]
  -l, --show-symlink-info
          Visualize symlinks in directory listing [env: MINISERVE_SHOW_SYMLINK_INFO=]
  -F, --hide-version-footer
          Hide version footer [env: MINISERVE_HIDE_VERSION_FOOTER=]
      --hide-theme-selector
          Hide theme selector [env: MINISERVE_HIDE_THEME_SELECTOR=]
  -W, --show-wget-footer
          If enabled, display a wget command to recursively download the current directory [env: MINISERVE_SHOW_WGET_FOOTER=]
      --print-completions <shell>
          Generate completion file for a shell [possible values: bash, elvish, fish, powershell, zsh]
      --print-manpage    Generate man page
      --tls-cert <TLS_CERT>
          TLS certificate to use [env: MINISERVE_TLS_CERT=]
      --tls-key <TLS_KEY>
          TLS private key to use [env: MINISERVE_TLS_KEY=]
      --readme           Enable README.md rendering in directories [env: MINISERVE_README=]
  -I, --disable-indexing Disable indexing [env: MINISERVE_DISABLE_INDEXING=]
      --enable-webdav    Enable read-only WebDAV support (PROPFIND requests) [env: MINISERVE_ENABLE_WEBDAV=]
      --size-display <SIZE_DISPLAY>
          Show served file size in exact bytes [env: MINISERVE_SIZE_DISPLAY=] [default: human] [possible values: human, exact]
      --file-external-url <FILE_EXTERNAL_URL>
          Optional external URL (e.g., 'http://external.example.com:8081') prepended to file links in listings [env: MINISERVE_FILE_EXTERNAL_URL=]
  -h, --help             Print help (see more with '--help')
  -V, --version          Print version
"""


VALUE_OPTS = {
    "-p": "port", "--port": "port", "-i": "interfaces", "--interfaces": "interfaces",
    "-a": "auth", "--auth": "auth", "--auth-file": "auth_file", "--route-prefix": "route_prefix",
    "--index": "index", "--temp-directory": "temp_directory", "-S": "sort_method",
    "--default-sorting-method": "sort_method", "-O": "sort_order", "--default-sorting-order": "sort_order",
    "-c": "color_scheme", "--color-scheme": "color_scheme", "-d": "color_scheme_dark",
    "--color-scheme-dark": "color_scheme_dark", "--web-upload-files-concurrency": "web_upload_concurrency",
    "--chmod": "chmod", "-m": "media_type", "--media-type": "media_type", "-M": "raw_media_type",
    "--raw-media-type": "raw_media_type", "-o": "duplicate", "--on-duplicate-files": "duplicate",
    "-t": "title", "--title": "title", "--header": "header", "--print-completions": "print_completions",
    "--tls-cert": "tls_cert", "--tls-key": "tls_key", "--size-display": "size_display",
    "--file-external-url": "file_external_url",
}
FLAG_OPTS = {
    "-v": "verbose", "--verbose": "verbose", "--spa": "spa", "--pretty-urls": "pretty",
    "--random-route": "random_route", "-P": "no_symlinks", "--no-symlinks": "no_symlinks",
    "-H": "hidden", "--hidden": "hidden", "-q": "qrcode", "--qrcode": "qrcode",
    "--directory-size": "directory_size", "-U": "mkdir", "--mkdir": "mkdir",
    "-r": "tar", "--enable-tar": "tar", "-g": "targz", "--enable-tar-gz": "targz",
    "-z": "zip", "--enable-zip": "zip", "-C": "compress", "--compress-response": "compress",
    "-D": "dirs_first", "--dirs-first": "dirs_first", "-l": "show_symlink_info",
    "--show-symlink-info": "show_symlink_info", "-F": "hide_version_footer",
    "--hide-version-footer": "hide_version_footer", "--hide-theme-selector": "hide_theme_selector",
    "-W": "show_wget_footer", "--show-wget-footer": "show_wget_footer", "--print-manpage": "print_manpage",
    "--readme": "readme", "-I": "disable_indexing", "--disable-indexing": "disable_indexing",
    "--enable-webdav": "webdav",
}


def default_config():
    return {
        "port": os.getenv("MINISERVE_PORT", "8080"),
        "interfaces": os.getenv("MINISERVE_INTERFACE", ""),
        "path": os.getenv("MINISERVE_PATH", ".") or ".",
        "index": os.getenv("MINISERVE_INDEX", ""),
        "spa": truthy(os.getenv("MINISERVE_SPA")),
        "pretty": truthy(os.getenv("MINISERVE_PRETTY_URLS")),
        "auth": os.getenv("MINISERVE_AUTH", ""),
        "auth_file": os.getenv("MINISERVE_AUTH_FILE", ""),
        "route_prefix": os.getenv("MINISERVE_ROUTE_PREFIX", ""),
        "random_route": truthy(os.getenv("MINISERVE_RANDOM_ROUTE")),
        "hidden": truthy(os.getenv("MINISERVE_HIDDEN")),
        "no_symlinks": truthy(os.getenv("MINISERVE_NO_SYMLINKS")),
        "sort_method": os.getenv("MINISERVE_DEFAULT_SORTING_METHOD", "name"),
        "sort_order": os.getenv("MINISERVE_DEFAULT_SORTING_ORDER", "desc"),
        "dirs_first": truthy(os.getenv("MINISERVE_DIRS_FIRST")),
        "title": os.getenv("MINISERVE_TITLE", ""),
        "upload": bool(os.getenv("MINISERVE_ALLOWED_UPLOAD_DIR")),
        "upload_dir": os.getenv("MINISERVE_ALLOWED_UPLOAD_DIR", ""),
        "rm": bool(os.getenv("MINISERVE_ALLOWED_RM_DIR")),
        "rm_dir": os.getenv("MINISERVE_ALLOWED_RM_DIR", ""),
        "mkdir": truthy(os.getenv("MINISERVE_MKDIR_ENABLED")),
        "duplicate": os.getenv("MINISERVE_ON_DUPLICATE_FILES", "error"),
        "chmod": os.getenv("MINISERVE_CHMOD", ""),
        "tar": truthy(os.getenv("MINISERVE_ENABLE_TAR")),
        "targz": truthy(os.getenv("MINISERVE_ENABLE_TAR_GZ")),
        "zip": truthy(os.getenv("MINISERVE_ENABLE_ZIP")),
        "compress": truthy(os.getenv("MINISERVE_COMPRESS_RESPONSE")),
        "headers": [],
        "readme": truthy(os.getenv("MINISERVE_README")),
        "disable_indexing": truthy(os.getenv("MINISERVE_DISABLE_INDEXING")),
        "webdav": truthy(os.getenv("MINISERVE_ENABLE_WEBDAV")),
        "size_display": os.getenv("MINISERVE_SIZE_DISPLAY", "human"),
        "file_external_url": os.getenv("MINISERVE_FILE_EXTERNAL_URL", ""),
        "tls_cert": os.getenv("MINISERVE_TLS_CERT", ""),
        "tls_key": os.getenv("MINISERVE_TLS_KEY", ""),
        "verbose": truthy(os.getenv("MINISERVE_VERBOSE")),
    }


def truthy(value):
    return str(value or "").lower() in {"1", "true", "yes", "on"}


def cli_error(message):
    sys.stderr.write(f"error: {message}\n\nUsage: executable [OPTIONS] [PATH]\n\nFor more information, try '--help'.\n")
    sys.exit(2)


def parse_args(argv):
    if any(a in ("-h", "--help") for a in argv):
        print(SHORT_HELP)
        sys.exit(0)
    if any(a in ("-V", "--version") for a in argv):
        print(VERSION)
        sys.exit(0)
    cfg = default_config()
    positionals = []
    i = 0
    while i < len(argv):
        arg = argv[i]
        if arg == "--":
            positionals.extend(argv[i + 1:])
            break
        if arg in VALUE_OPTS:
            if i + 1 >= len(argv):
                cli_error(f"a value is required for '{arg} <{VALUE_OPTS[arg].upper()}>'")
            key = VALUE_OPTS[arg]
            value = argv[i + 1]
            if key == "header":
                cfg["headers"].append(value)
            else:
                cfg[key] = value
            i += 2
            continue
        if arg in FLAG_OPTS:
            cfg[FLAG_OPTS[arg]] = True
            i += 1
            continue
        if arg in ("-u", "--upload-files"):
            cfg["upload"] = True
            if i + 1 < len(argv) and not argv[i + 1].startswith("-"):
                cfg["upload_dir"] = argv[i + 1]
                i += 2
            else:
                i += 1
            continue
        if arg in ("-R", "--rm-files"):
            cfg["rm"] = True
            if i + 1 < len(argv) and not argv[i + 1].startswith("-"):
                cfg["rm_dir"] = argv[i + 1]
                i += 2
            else:
                i += 1
            continue
        if arg.startswith("-"):
            cli_error(f"unexpected argument '{arg}' found")
        positionals.append(arg)
        i += 1
    if len(positionals) > 1:
        cli_error(f"unexpected argument '{positionals[1]}' found")
    if positionals:
        cfg["path"] = positionals[0]
    if cfg["random_route"]:
        cfg["route_prefix"] = "/" + "".join(random.choice("0123456789abcdef") for _ in range(6))
    cfg["route_prefix"] = normalize_prefix(cfg.get("route_prefix", ""))
    cfg["auths"] = parse_auths(cfg)
    return cfg


def normalize_prefix(prefix):
    if not prefix:
        return ""
    if not prefix.startswith("/"):
        prefix = "/" + prefix
    return prefix.rstrip("/")


def parse_auths(cfg):
    values = []
    if cfg.get("auth"):
        values.append(cfg["auth"])
    if cfg.get("auth_file"):
        with open(cfg["auth_file"], "r", encoding="utf-8") as f:
            values += [line.strip() for line in f if line.strip()]
    return values


def check_auth(header, auths):
    if not auths:
        return True
    if not header.startswith("Basic "):
        return False
    try:
        decoded = base64.b64decode(header.split(None, 1)[1]).decode("utf-8")
    except Exception:
        return False
    user, _, password = decoded.partition(":")
    for entry in auths:
        parts = entry.split(":")
        if len(parts) == 2 and parts[0] == user and parts[1] == password:
            return True
        if len(parts) == 3 and parts[0] == user:
            algo, expected = parts[1], parts[2]
            if algo in ("sha256", "sha512"):
                digest = getattr(hashlib, algo)(password.encode()).hexdigest()
                if digest == expected:
                    return True
    return False


class ReusableTCPServer(socketserver.ThreadingTCPServer):
    allow_reuse_address = True
    address_family = socket.AF_INET6 if socket.has_ipv6 else socket.AF_INET


def make_handler(cfg):
    root = Path(cfg["path"]).resolve()

    class Handler(http.server.BaseHTTPRequestHandler):
        server_version = "miniserve"
        sys_version = ""

        def log_message(self, fmt, *args):
            if cfg.get("verbose"):
                super().log_message(fmt, *args)

        def end_headers(self):
            for header in cfg.get("headers", []):
                if ":" in header:
                    k, v = header.split(":", 1)
                    self.send_header(k.strip(), v.strip())
            super().end_headers()

        def do_HEAD(self):
            self.handle_request(head=True)

        def do_GET(self):
            self.handle_request(head=False)

        def do_POST(self):
            if not self.authorized():
                return
            if self.path_no_prefix().startswith("/upload") and cfg.get("upload"):
                self.handle_upload()
            elif self.path_no_prefix().startswith("/mkdir") and cfg.get("mkdir"):
                self.handle_mkdir()
            else:
                self.error_page(404, "Not Found")

        def do_DELETE(self):
            if not self.authorized():
                return
            if not cfg.get("rm"):
                self.error_page(405, "Method Not Allowed")
                return
            path = self.fs_path()
            if not self.allowed(path, cfg.get("rm_dir", "")):
                self.error_page(403, "Forbidden")
                return
            if path.is_dir():
                shutil.rmtree(path)
            elif path.exists():
                path.unlink()
            else:
                self.error_page(404, "Not Found")
                return
            self.send_response(200)
            self.end_headers()

        def do_PROPFIND(self):
            if not cfg.get("webdav"):
                self.error_page(405, "Method Not Allowed")
                return
            if not self.authorized():
                return
            path = self.fs_path()
            if not path.exists():
                self.error_page(404, "Not Found")
                return
            body = self.webdav_xml(path)
            self.send_response(207, "Multi-Status")
            self.send_header("Content-Type", "application/xml; charset=utf-8")
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self.wfile.write(body)

        def authorized(self):
            if check_auth(self.headers.get("Authorization", ""), cfg.get("auths", [])):
                return True
            self.send_response(401)
            self.send_header("WWW-Authenticate", "Basic")
            self.send_header("Content-Length", "0")
            self.end_headers()
            return False

        def path_no_prefix(self):
            parsed = urllib.parse.urlsplit(self.path)
            path = urllib.parse.unquote(parsed.path)
            prefix = cfg.get("route_prefix", "")
            if prefix:
                if path == prefix:
                    return "/"
                if not path.startswith(prefix + "/"):
                    return None
                path = path[len(prefix):]
            return path or "/"

        def handle_request(self, head=False):
            if not self.authorized():
                return
            rel = self.path_no_prefix()
            if rel is None:
                self.redirect(cfg.get("route_prefix", "") + "/")
                return
            if rel.startswith("/__miniserve_internal/"):
                self.internal(rel, head)
                return
            if rel.endswith(".tar") and cfg.get("tar"):
                return self.archive("tar", head)
            if rel.endswith(".tar.gz") and cfg.get("targz"):
                return self.archive("targz", head)
            if rel.endswith(".zip") and cfg.get("zip"):
                return self.archive("zip", head)
            path = self.fs_path(rel)
            if not self.visible(path):
                self.error_page(400, "Bad Request", head)
                return
            if not path.exists() and cfg.get("pretty"):
                pretty = self.fs_path(rel.rstrip("/") + ".html")
                if pretty.exists():
                    path = pretty
            if not path.exists() and cfg.get("spa") and cfg.get("index"):
                spa = root / cfg["index"]
                if spa.exists():
                    path = spa
            if path.is_dir():
                if not rel.endswith("/"):
                    self.redirect(self.prefix_url(rel + "/"))
                    return
                index = cfg.get("index")
                if index and (path / index).is_file():
                    self.send_file(path / index, head)
                elif cfg.get("disable_indexing"):
                    self.error_page(404, "Not Found", head)
                else:
                    self.listing(path, rel, head)
            elif path.is_file():
                self.send_file(path, head)
            else:
                self.error_page(404, "Not Found", head)

        def fs_path(self, rel=None):
            if rel is None:
                rel = self.path_no_prefix() or "/"
            rel = urllib.parse.urlsplit(rel).path
            rel = posixpath.normpath(urllib.parse.unquote(rel)).lstrip("/")
            path = (root / rel).resolve()
            try:
                path.relative_to(root)
            except ValueError:
                return root / "__forbidden__"
            return path

        def visible(self, path):
            try:
                rel = path.relative_to(root)
            except ValueError:
                return False
            if cfg.get("no_symlinks"):
                current = path
                while True:
                    if current.is_symlink():
                        return False
                    if current == root:
                        break
                    current = current.parent
            return cfg.get("hidden") or not any(part.startswith(".") for part in rel.parts)

        def allowed(self, path, allowed_dir):
            if not allowed_dir:
                return True
            allowed_path = (root / allowed_dir.lstrip("/")).resolve()
            try:
                path.resolve().relative_to(allowed_path)
                return True
            except ValueError:
                return False

        def redirect(self, location):
            self.send_response(307)
            self.send_header("Location", location)
            self.send_header("Content-Length", "0")
            self.end_headers()

        def prefix_url(self, rel):
            return cfg.get("route_prefix", "") + rel

        def send_file(self, path, head=False):
            size = path.stat().st_size
            ctype = mimetypes.guess_type(str(path))[0] or "application/octet-stream"
            disposition = "inline" if (ctype.startswith("text/") or ctype in {"image/svg+xml", "application/pdf"}) else "attachment"
            start, end = 0, size - 1
            status = 200
            range_header = self.headers.get("Range", "")
            if range_header.startswith("bytes="):
                spec = range_header[6:].split(",", 1)[0]
                a, _, b = spec.partition("-")
                try:
                    if a:
                        start = int(a)
                        end = int(b) if b else size - 1
                    else:
                        n = int(b)
                        start = max(0, size - n)
                    end = min(end, size - 1)
                    if start <= end:
                        status = 206
                    else:
                        start, end = 0, size - 1
                except ValueError:
                    start, end = 0, size - 1
            length = max(0, end - start + 1) if size else 0
            self.send_response(status)
            self.send_header("Content-Length", str(length))
            self.send_header("Content-Type", ctype + ("; charset=utf-8" if ctype.startswith("text/") or ctype == "image/svg+xml" else ""))
            self.send_header("Content-Disposition", f'{disposition}; filename="{path.name}"')
            self.send_header("Accept-Ranges", "bytes")
            if status == 206:
                self.send_header("Content-Range", f"bytes {start}-{end}/{size}")
            self.end_headers()
            if not head:
                with open(path, "rb") as f:
                    f.seek(start)
                    self.wfile.write(f.read(length))

        def listing(self, path, rel, head=False):
            entries = []
            for child in path.iterdir():
                if not cfg.get("hidden") and child.name.startswith("."):
                    continue
                if cfg.get("no_symlinks") and child.is_symlink():
                    continue
                entries.append(child)
            method = cfg.get("sort_method", "name")
            reverse = cfg.get("sort_order", "desc") == "desc"
            if method == "size":
                entries.sort(key=lambda p: (p.stat().st_size if p.exists() else 0, p.name.lower()), reverse=reverse)
            elif method == "date":
                entries.sort(key=lambda p: (p.stat().st_mtime if p.exists() else 0, p.name.lower()), reverse=reverse)
            else:
                entries.sort(key=lambda p: p.name.lower(), reverse=reverse)
            if cfg.get("dirs_first"):
                entries.sort(key=lambda p: not p.is_dir())
            title = cfg.get("title") or self.headers.get("Host", "miniserve")
            rows = []
            if rel != "/":
                rows.append('<li><a href="../">..</a></li>')
            for child in entries:
                name = child.name + ("/" if child.is_dir() else "")
                href_base = cfg.get("file_external_url", "") if child.is_file() and cfg.get("file_external_url") else cfg.get("route_prefix", "")
                href = href_base + urllib.parse.quote(posixpath.join(rel, name))
                size = child.stat().st_size if child.exists() and child.is_file() else ""
                rows.append(f'<li><a href="{html.escape(href)}">{html.escape(name)}</a> <span>{size}</span></li>')
            extras = ""
            if cfg.get("upload"):
                extras += '<form action="/upload?path=/" method="post" enctype="multipart/form-data"><input type="file" name="path"><button>upload</button></form>'
            if cfg.get("readme") and (path / "README.md").exists():
                extras += f"<pre>{html.escape((path / 'README.md').read_text(errors='ignore'))}</pre>"
            footer = "" if cfg.get("hide_version_footer") else '<footer><a href="https://github.com/svenstaro/miniserve">miniserve</a></footer>'
            body = f'<!DOCTYPE html><html><head><meta charset="utf-8"><title>{html.escape(title)}</title></head><body><h1>{html.escape(title)}</h1>{extras}<ul>{"".join(rows)}</ul>{footer}</body></html>'.encode()
            self.send_body(200, "text/html; charset=utf-8", body, head)

        def send_body(self, status, ctype, body, head=False):
            if cfg.get("compress") and "gzip" in self.headers.get("Accept-Encoding", ""):
                body = gzip.compress(body)
                encoding = "gzip"
            else:
                encoding = None
            self.send_response(status)
            self.send_header("Content-Length", str(len(body)))
            self.send_header("Content-Type", ctype)
            if encoding:
                self.send_header("Content-Encoding", encoding)
            self.end_headers()
            if not head:
                self.wfile.write(body)

        def error_page(self, status, text, head=False):
            body = f'<!DOCTYPE html><html><head><title>{status} {html.escape(text)}</title></head><body><h1>{status} {html.escape(text)}</h1></body></html>'.encode()
            self.send_body(status, "text/html", body, head)

        def internal(self, rel, head=False):
            if rel.endswith("favicon.svg"):
                body = b'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 8 8"><rect width="8" height="8" fill="#333"/></svg>'
                self.send_body(200, "image/svg+xml", body, head)
            elif rel.endswith("style.css"):
                self.send_body(200, "text/css", b"body{font-family:sans-serif;max-width:960px;margin:2rem auto}", head)
            else:
                self.send_body(200, "application/json", b"{}", head)

        def handle_upload(self):
            query = urllib.parse.parse_qs(urllib.parse.urlsplit(self.path).query)
            target_dir = self.fs_path(query.get("path", ["/"])[0])
            if not self.allowed(target_dir, cfg.get("upload_dir", "")):
                self.error_page(403, "Forbidden")
                return
            ctype, pdict = cgi.parse_header(self.headers.get("Content-Type", ""))
            if ctype != "multipart/form-data":
                self.error_page(400, "Bad Request")
                return
            pdict["boundary"] = pdict["boundary"].encode()
            form = cgi.FieldStorage(fp=self.rfile, headers=self.headers, environ={"REQUEST_METHOD": "POST", "CONTENT_TYPE": self.headers.get("Content-Type", "")})
            for item in form.list or []:
                if not item.filename:
                    continue
                dest = (target_dir / os.path.basename(item.filename)).resolve()
                if not self.allowed(dest, cfg.get("upload_dir", "")):
                    continue
                if dest.exists():
                    if cfg.get("duplicate") == "error":
                        self.error_page(409, "Conflict")
                        return
                    if cfg.get("duplicate") == "rename":
                        stem, suffix = dest.stem, dest.suffix
                        n = 1
                        while dest.exists():
                            dest = target_dir / f"{stem}-{n}{suffix}"
                            n += 1
                with open(dest, "wb") as f:
                    shutil.copyfileobj(item.file, f)
                if cfg.get("chmod"):
                    os.chmod(dest, int(str(cfg["chmod"]), 8))
            self.send_response(303)
            self.send_header("Location", self.prefix_url("/"))
            self.send_header("Content-Length", "0")
            self.end_headers()

        def handle_mkdir(self):
            query = urllib.parse.parse_qs(urllib.parse.urlsplit(self.path).query)
            name = query.get("name", [""])[0] or query.get("path", [""])[0]
            if not name:
                self.error_page(400, "Bad Request")
                return
            dest = self.fs_path(name)
            dest.mkdir(parents=True, exist_ok=True)
            self.send_response(303)
            self.send_header("Location", self.prefix_url("/"))
            self.end_headers()

        def archive(self, kind, head=False):
            bio = io.BytesIO()
            if kind == "zip":
                with zipfile.ZipFile(bio, "w", zipfile.ZIP_DEFLATED) as z:
                    for p in root.rglob("*"):
                        if p.is_file() and self.visible(p):
                            z.write(p, p.relative_to(root))
                ctype = "application/zip"
            else:
                mode = "w:gz" if kind == "targz" else "w"
                with tarfile.open(fileobj=bio, mode=mode) as t:
                    for p in root.rglob("*"):
                        if self.visible(p):
                            t.add(p, p.relative_to(root))
                ctype = "application/gzip" if kind == "targz" else "application/x-tar"
            self.send_body(200, ctype, bio.getvalue(), head)

        def webdav_xml(self, path):
            href = html.escape(urllib.parse.urlsplit(self.path).path)
            is_dir = path.is_dir()
            size = 0 if is_dir else path.stat().st_size
            collection = "<D:collection/>" if is_dir else ""
            return f'''<?xml version="1.0" encoding="utf-8"?>
<D:multistatus xmlns:D="DAV:"><D:response><D:href>{href}</D:href><D:propstat><D:prop><D:resourcetype>{collection}</D:resourcetype><D:getcontentlength>{size}</D:getcontentlength></D:prop><D:status>HTTP/1.1 200 OK</D:status></D:propstat></D:response></D:multistatus>'''.encode()

    return Handler


def print_completions(shell):
    print(f"# completion file for {shell}\ncomplete -c executable")


def print_manpage():
    print(".TH MINISERVE 1\n.SH NAME\nminiserve \\- serve files and directories over HTTP\n.SH SYNOPSIS\n.B executable [OPTIONS] [PATH]")


def main(argv):
    cfg = parse_args(argv)
    if cfg.get("print_completions"):
        print_completions(cfg["print_completions"])
        return
    if cfg.get("print_manpage"):
        print_manpage()
        return
    root = Path(cfg["path"])
    if not root.exists():
        sys.stderr.write(f"Error: Path does not exist: {root}\n")
        sys.exit(1)
    host = cfg.get("interfaces") or "::"
    port = int(cfg.get("port") or 8080)
    try:
        httpd = ReusableTCPServer((host, port), make_handler(cfg))
    except Exception:
        httpd = socketserver.ThreadingTCPServer(("0.0.0.0", port), make_handler(cfg))
    if cfg.get("tls_cert") and cfg.get("tls_key"):
        httpd.socket = ssl.wrap_socket(httpd.socket, certfile=cfg["tls_cert"], keyfile=cfg["tls_key"], server_side=True)
    actual = httpd.server_address[1]
    print("miniserve v0.32.0", flush=True)
    print(f"Bound to [::]:{actual}, 0.0.0.0:{actual}", flush=True)
    print(f"Serving path {Path(cfg['path']).resolve()}", flush=True)
    prefix = cfg.get("route_prefix", "")
    print("Available at (non-exhaustive list):", flush=True)
    print(f"    http://127.0.0.1:{actual}{prefix}", flush=True)
    try:
        httpd.serve_forever()
    except KeyboardInterrupt:
        pass


if __name__ == "__main__":
    main(sys.argv[1:])
