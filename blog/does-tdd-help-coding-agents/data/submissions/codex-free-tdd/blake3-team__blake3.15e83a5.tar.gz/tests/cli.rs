use std::fs;
use std::io::Write;
use std::process::{Command, Stdio};

fn bin() -> &'static str {
    env!("CARGO_BIN_EXE_executable")
}

fn run(args: &[&str], stdin: &[u8], dir: Option<&std::path::Path>) -> std::process::Output {
    let mut cmd = Command::new(bin());
    cmd.args(args).stdin(Stdio::piped()).stdout(Stdio::piped()).stderr(Stdio::piped());
    if let Some(dir) = dir {
        cmd.current_dir(dir);
    }
    let mut child = cmd.spawn().unwrap();
    child.stdin.as_mut().unwrap().write_all(stdin).unwrap();
    child.wait_with_output().unwrap()
}

fn tempdir(name: &str) -> std::path::PathBuf {
    let path = std::env::temp_dir().join(format!("pb_b3sum_{}_{}", name, std::process::id()));
    let _ = fs::remove_dir_all(&path);
    fs::create_dir_all(&path).unwrap();
    path
}

#[test]
fn hashes_stdin_with_default_name() {
    let output = run(&[], b"abc", None);
    assert!(output.status.success());
    assert_eq!(
        String::from_utf8(output.stdout).unwrap(),
        "6437b3ac38465133ffb63b75273a8db548c558465d79db03fd359c6cd5bd9d85  -\n"
    );
}

#[test]
fn hashes_files_and_formats_names() {
    let dir = tempdir("files");
    fs::write(dir.join("a.txt"), b"abc").unwrap();
    fs::write(dir.join("sp ace"), b"x\ny").unwrap();
    let output = run(&["a.txt", "sp ace"], b"", Some(&dir));
    assert!(output.status.success());
    assert_eq!(
        String::from_utf8(output.stdout).unwrap(),
        concat!(
            "6437b3ac38465133ffb63b75273a8db548c558465d79db03fd359c6cd5bd9d85  a.txt\n",
            "78b04ae00b427f2e2fd6d0c79309393413e7d3ddd9fd8d269355fb506b798ae1  sp ace\n",
        )
    );
}

#[test]
fn supports_xof_length_seek_raw_and_tag() {
    let dir = tempdir("xof");
    fs::write(dir.join("a.txt"), b"abc").unwrap();
    let no_names = run(&["--length", "8", "--seek", "1", "--no-names", "a.txt"], b"", Some(&dir));
    assert!(no_names.status.success());
    assert_eq!(String::from_utf8(no_names.stdout).unwrap(), "37b3ac38465133ff\n");

    let raw = run(&["-l", "4", "--raw", "a.txt"], b"", Some(&dir));
    assert!(raw.status.success());
    assert_eq!(raw.stdout, vec![0x64, 0x37, 0xb3, 0xac]);

    let tag = run(&["--tag", "a.txt"], b"", Some(&dir));
    assert!(tag.status.success());
    assert_eq!(
        String::from_utf8(tag.stdout).unwrap(),
        "BLAKE3 (a.txt) = 6437b3ac38465133ffb63b75273a8db548c558465d79db03fd359c6cd5bd9d85\n"
    );
}

#[test]
fn hashes_inputs_longer_than_one_chunk() {
    let dir = tempdir("chunks");
    fs::write(dir.join("z1024"), vec![0u8; 1024]).unwrap();
    fs::write(dir.join("z1025"), vec![0u8; 1025]).unwrap();
    let output = run(&["--no-names", "z1024", "z1025"], b"", Some(&dir));
    assert!(output.status.success());
    assert_eq!(
        String::from_utf8(output.stdout).unwrap(),
        concat!(
            "d6fd9de5bccf223f523b316c9cd1cf9a9d87ea42473d68e011dad13f09bf8917\n",
            "d2beb49d87e59db174cb3ff1440f1899422968df670d060fd7ce759e8cc160e7\n",
        )
    );
}

#[test]
fn supports_keyed_and_derive_key_modes() {
    let dir = tempdir("modes");
    fs::write(dir.join("msg"), b"abc").unwrap();
    let keyed = run(&["--keyed", "msg"], b"0123456789abcdef0123456789abcdef", Some(&dir));
    assert!(keyed.status.success());
    assert_eq!(
        String::from_utf8(keyed.stdout).unwrap(),
        "d1190deec27dc438906e12070c5098ce46256ad7c3cb8f725eb3402e8c786aab  msg\n"
    );

    let derived = run(&["--derive-key", "ctx", "--no-names"], b"abc", None);
    assert!(derived.status.success());
    assert_eq!(
        String::from_utf8(derived.stdout).unwrap(),
        "51b03b2a289e3f32acf87f00c3620dd6cc2c29706de6f8184386550dab656d36\n"
    );
}

#[test]
fn check_mode_reports_ok_and_failures() {
    let dir = tempdir("check");
    fs::write(dir.join("a.txt"), b"abc").unwrap();
    fs::write(
        dir.join("sums"),
        b"6437b3ac38465133ffb63b75273a8db548c558465d79db03fd359c6cd5bd9d85  a.txt\n",
    )
    .unwrap();
    let ok = run(&["-c", "sums"], b"", Some(&dir));
    assert!(ok.status.success());
    assert_eq!(String::from_utf8(ok.stdout).unwrap(), "a.txt: OK\n");

    fs::write(dir.join("a.txt"), b"bad").unwrap();
    let bad = run(&["-c", "sums"], b"", Some(&dir));
    assert!(!bad.status.success());
    assert_eq!(String::from_utf8(bad.stdout).unwrap(), "a.txt: FAILED\n");
    assert!(String::from_utf8(bad.stderr).unwrap().contains("WARNING: 1 computed checksum did NOT match"));
}

#[test]
fn escapes_backslash_and_newline_in_filenames() {
    let dir = tempdir("escapes");
    fs::write(dir.join("back\\slash"), b"abc").unwrap();
    fs::write(dir.join("line\nbreak"), b"abc").unwrap();
    let output = run(&["back\\slash", "line\nbreak"], b"", Some(&dir));
    assert!(output.status.success());
    assert_eq!(
        String::from_utf8(output.stdout).unwrap(),
        concat!(
            "\\6437b3ac38465133ffb63b75273a8db548c558465d79db03fd359c6cd5bd9d85  back\\\\slash\n",
            "\\6437b3ac38465133ffb63b75273a8db548c558465d79db03fd359c6cd5bd9d85  line\\nbreak\n",
        )
    );
}

#[test]
fn rejects_raw_check_combination() {
    let output = run(&["--check", "--raw"], b"", None);
    assert!(!output.status.success());
    assert!(String::from_utf8(output.stderr)
        .unwrap()
        .contains("the argument '--check' cannot be used with '--raw'"));
}

#[test]
fn check_mode_resolves_names_from_current_directory() {
    let dir = tempdir("check_cwd");
    fs::create_dir(dir.join("sub")).unwrap();
    fs::write(dir.join("sub").join("a"), b"abc").unwrap();
    fs::write(
        dir.join("sub").join("sums"),
        b"6437b3ac38465133ffb63b75273a8db548c558465d79db03fd359c6cd5bd9d85  a\n",
    )
    .unwrap();
    let output = run(&["-c", "sub/sums"], b"", Some(&dir));
    assert!(!output.status.success());
    assert_eq!(
        String::from_utf8(output.stdout).unwrap(),
        "a: FAILED (No such file or directory (os error 2))\n"
    );
}

#[test]
fn derive_key_xof_can_seek_past_first_output_block() {
    let dir = tempdir("derive_xof");
    fs::write(dir.join("a"), b"abc").unwrap();
    let output = run(
        &["--derive-key", "ctx", "--length", "80", "--seek", "17", "--no-names", "a"],
        b"",
        Some(&dir),
    );
    assert!(output.status.success());
    assert_eq!(
        String::from_utf8(output.stdout).unwrap(),
        "2c29706de6f8184386550dab656d36ab65cbf4802691c77d0dd839b0c0f48b38818ad981675596155290e17615a06ce28bc4d807ecbec70268c31dca3fe896365b87b2fe3ff3a823b33be91c6dc8dc82\n"
    );
}
