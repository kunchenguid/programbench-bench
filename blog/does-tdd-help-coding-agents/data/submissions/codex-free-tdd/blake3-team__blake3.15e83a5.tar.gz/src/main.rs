use std::fs;
use std::io::{self, Read, Write};
use std::path::Path;

const IV: [u32; 8] = [
    0x6A09E667, 0xBB67AE85, 0x3C6EF372, 0xA54FF53A, 0x510E527F, 0x9B05688C, 0x1F83D9AB,
    0x5BE0CD19,
];
const MSG_SCHEDULE: [[usize; 16]; 7] = [
    [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15],
    [2, 6, 3, 10, 7, 0, 4, 13, 1, 11, 12, 5, 9, 14, 15, 8],
    [3, 4, 10, 12, 13, 2, 7, 14, 6, 5, 9, 0, 11, 15, 8, 1],
    [10, 7, 12, 9, 14, 3, 13, 15, 4, 0, 11, 2, 5, 8, 1, 6],
    [12, 13, 9, 11, 15, 10, 14, 8, 7, 2, 5, 3, 0, 1, 6, 4],
    [9, 14, 11, 5, 8, 12, 15, 1, 13, 3, 0, 10, 2, 6, 4, 7],
    [11, 15, 5, 0, 1, 9, 8, 6, 14, 10, 2, 12, 3, 4, 7, 13],
];
const CHUNK_LEN: usize = 1024;
const BLOCK_LEN: usize = 64;
const CHUNK_START: u32 = 1;
const CHUNK_END: u32 = 2;
const PARENT: u32 = 4;
const ROOT: u32 = 8;
const KEYED_HASH: u32 = 16;
const DERIVE_KEY_CONTEXT: u32 = 32;
const DERIVE_KEY_MATERIAL: u32 = 64;

#[derive(Clone)]
struct Output {
    input_cv: [u32; 8],
    block: [u8; 64],
    counter: u64,
    block_len: u32,
    flags: u32,
}

#[derive(Clone)]
struct Options {
    keyed: bool,
    derive_key: Option<String>,
    length: usize,
    seek: u64,
    no_names: bool,
    raw: bool,
    tag: bool,
    check: bool,
    quiet: bool,
    files: Vec<String>,
}

fn g(state: &mut [u32; 16], a: usize, b: usize, c: usize, d: usize, mx: u32, my: u32) {
    state[a] = state[a].wrapping_add(state[b]).wrapping_add(mx);
    state[d] = (state[d] ^ state[a]).rotate_right(16);
    state[c] = state[c].wrapping_add(state[d]);
    state[b] = (state[b] ^ state[c]).rotate_right(12);
    state[a] = state[a].wrapping_add(state[b]).wrapping_add(my);
    state[d] = (state[d] ^ state[a]).rotate_right(8);
    state[c] = state[c].wrapping_add(state[d]);
    state[b] = (state[b] ^ state[c]).rotate_right(7);
}

fn words_from_block(block: &[u8; 64]) -> [u32; 16] {
    let mut words = [0u32; 16];
    for (i, word) in words.iter_mut().enumerate() {
        let j = i * 4;
        *word = u32::from_le_bytes([block[j], block[j + 1], block[j + 2], block[j + 3]]);
    }
    words
}

fn compress(
    cv: [u32; 8],
    block: &[u8; 64],
    counter: u64,
    block_len: u32,
    flags: u32,
) -> [u32; 16] {
    let m = words_from_block(block);
    let mut state = [
        cv[0],
        cv[1],
        cv[2],
        cv[3],
        cv[4],
        cv[5],
        cv[6],
        cv[7],
        IV[0],
        IV[1],
        IV[2],
        IV[3],
        counter as u32,
        (counter >> 32) as u32,
        block_len,
        flags,
    ];
    for schedule in MSG_SCHEDULE {
        g(&mut state, 0, 4, 8, 12, m[schedule[0]], m[schedule[1]]);
        g(&mut state, 1, 5, 9, 13, m[schedule[2]], m[schedule[3]]);
        g(&mut state, 2, 6, 10, 14, m[schedule[4]], m[schedule[5]]);
        g(&mut state, 3, 7, 11, 15, m[schedule[6]], m[schedule[7]]);
        g(&mut state, 0, 5, 10, 15, m[schedule[8]], m[schedule[9]]);
        g(&mut state, 1, 6, 11, 12, m[schedule[10]], m[schedule[11]]);
        g(&mut state, 2, 7, 8, 13, m[schedule[12]], m[schedule[13]]);
        g(&mut state, 3, 4, 9, 14, m[schedule[14]], m[schedule[15]]);
    }
    let mut out = [0u32; 16];
    for i in 0..8 {
        out[i] = state[i] ^ state[i + 8];
        out[i + 8] = state[i + 8] ^ cv[i];
    }
    out
}

fn first_cv(words: [u32; 16]) -> [u32; 8] {
    let mut cv = [0u32; 8];
    cv.copy_from_slice(&words[..8]);
    cv
}

fn block_from_slice(input: &[u8]) -> [u8; 64] {
    let mut block = [0u8; 64];
    block[..input.len()].copy_from_slice(input);
    block
}

fn chunk_output(chunk: &[u8], chunk_counter: u64, key: [u32; 8], flags: u32) -> Output {
    let mut cv = key;
    let blocks = std::cmp::max(1, (chunk.len() + BLOCK_LEN - 1) / BLOCK_LEN);
    for block_index in 0..blocks {
        let start = block_index * BLOCK_LEN;
        let end = std::cmp::min(start + BLOCK_LEN, chunk.len());
        let block = block_from_slice(&chunk[start..end]);
        let mut block_flags = flags;
        if block_index == 0 {
            block_flags |= CHUNK_START;
        }
        if block_index == blocks - 1 {
            block_flags |= CHUNK_END;
            return Output {
                input_cv: cv,
                block,
                counter: chunk_counter,
                block_len: (end - start) as u32,
                flags: block_flags,
            };
        }
        cv = first_cv(compress(cv, &block, chunk_counter, BLOCK_LEN as u32, block_flags));
    }
    unreachable!()
}

fn output_chaining_value(output: &Output) -> [u32; 8] {
    first_cv(compress(
        output.input_cv,
        &output.block,
        output.counter,
        output.block_len,
        output.flags,
    ))
}

fn parent_output(left: [u32; 8], right: [u32; 8], key: [u32; 8], flags: u32) -> Output {
    let mut block = [0u8; 64];
    for (i, word) in left.iter().chain(right.iter()).enumerate() {
        block[i * 4..i * 4 + 4].copy_from_slice(&word.to_le_bytes());
    }
    Output {
        input_cv: key,
        block,
        counter: 0,
        block_len: BLOCK_LEN as u32,
        flags: flags | PARENT,
    }
}

fn parent_cv(left: [u32; 8], right: [u32; 8], key: [u32; 8], flags: u32) -> [u32; 8] {
    output_chaining_value(&parent_output(left, right, key, flags))
}

fn subtree_cv(cvs: &[[u32; 8]], key: [u32; 8], flags: u32) -> [u32; 8] {
    if cvs.len() == 1 {
        return cvs[0];
    }
    let split = cvs.len().next_power_of_two() / 2;
    let left = subtree_cv(&cvs[..split], key, flags);
    let right = subtree_cv(&cvs[split..], key, flags);
    parent_cv(left, right, key, flags)
}

fn root_output(input: &[u8], key: [u32; 8], flags: u32) -> Output {
    let chunk_count = std::cmp::max(1, (input.len() + CHUNK_LEN - 1) / CHUNK_LEN);
    if chunk_count == 1 {
        return chunk_output(input, 0, key, flags);
    }
    let mut cvs = Vec::with_capacity(chunk_count);
    for (i, chunk) in input.chunks(CHUNK_LEN).enumerate() {
        cvs.push(output_chaining_value(&chunk_output(chunk, i as u64, key, flags)));
    }
    let split = cvs.len().next_power_of_two() / 2;
    let left = subtree_cv(&cvs[..split], key, flags);
    let right = subtree_cv(&cvs[split..], key, flags);
    parent_output(left, right, key, flags)
}

fn output_bytes(output: &Output, seek: u64, len: usize) -> Vec<u8> {
    let mut result = Vec::with_capacity(len);
    let mut block_counter = seek / 64;
    let mut offset = (seek % 64) as usize;
    while result.len() < len {
        let words = compress(
            output.input_cv,
            &output.block,
            block_counter,
            output.block_len,
            output.flags | ROOT,
        );
        let mut block = [0u8; 64];
        for (i, word) in words.iter().enumerate() {
            block[i * 4..i * 4 + 4].copy_from_slice(&word.to_le_bytes());
        }
        let take = std::cmp::min(len - result.len(), 64 - offset);
        result.extend_from_slice(&block[offset..offset + take]);
        block_counter += 1;
        offset = 0;
    }
    result
}

fn hash_with_key(input: &[u8], key: [u32; 8], flags: u32, seek: u64, len: usize) -> Vec<u8> {
    output_bytes(&root_output(input, key, flags), seek, len)
}

fn derive_key_words(context: &str) -> [u32; 8] {
    let bytes = hash_with_key(context.as_bytes(), IV, DERIVE_KEY_CONTEXT, 0, 32);
    let mut key = [0u32; 8];
    for i in 0..8 {
        key[i] = u32::from_le_bytes([
            bytes[i * 4],
            bytes[i * 4 + 1],
            bytes[i * 4 + 2],
            bytes[i * 4 + 3],
        ]);
    }
    key
}

fn hex(bytes: &[u8]) -> String {
    const DIGITS: &[u8; 16] = b"0123456789abcdef";
    let mut out = String::with_capacity(bytes.len() * 2);
    for &byte in bytes {
        out.push(DIGITS[(byte >> 4) as usize] as char);
        out.push(DIGITS[(byte & 0xf) as usize] as char);
    }
    out
}

fn print_help(long: bool) {
    let extra = if long {
        "\n          When no file is given, or when - is given, read standard input.\n"
    } else {
        ""
    };
    println!(
        "Usage: executable [OPTIONS] [FILE]...\n\nArguments:\n  [FILE]...\n          Files to hash, or checkfiles to check{extra}\nOptions:\n      --keyed\n          Use the keyed mode, reading the 32-byte key from stdin\n\n      --derive-key <CONTEXT>\n          Use the key derivation mode, with the given context string\n          \n          Cannot be used with --keyed.\n\n  -l, --length <LEN>\n          The number of output bytes, before hex encoding\n          \n          [default: 32]\n\n      --seek <SEEK>\n          The starting output byte offset, before hex encoding\n          \n          [default: 0]\n\n      --num-threads <NUM>\n          The maximum number of threads to use\n\n      --no-mmap\n          Disable memory mapping\n          \n          Currently this also disables multithreading.\n\n      --no-names\n          Omit filenames in the output\n\n      --raw\n          Write raw output bytes to stdout, rather than hex\n          \n          --no-names is implied. In this case, only a single input is allowed.\n\n      --tag\n          Output BSD-style checksums: BLAKE3 ([FILE]) = [HASH]\n\n  -c, --check\n          Read BLAKE3 sums from the [FILE]s and check them\n\n      --quiet\n          Skip printing OK for each checked file\n          \n          Must be used with --check.\n\n  -h, --help\n          Print help (see a summary with '-h')\n\n  -V, --version\n          Print version"
    );
}

fn parse_usize(value: Option<String>, flag: &str) -> Result<usize, String> {
    value
        .ok_or_else(|| format!("error: a value is required for '{flag}'"))
        .and_then(|v| v.parse::<usize>().map_err(|_| format!("error: invalid value '{v}' for '{flag}'")))
}

fn parse_u64(value: Option<String>, flag: &str) -> Result<u64, String> {
    value
        .ok_or_else(|| format!("error: a value is required for '{flag}'"))
        .and_then(|v| v.parse::<u64>().map_err(|_| format!("error: invalid value '{v}' for '{flag}'")))
}

fn parse_args() -> Result<Option<Options>, String> {
    let mut args = std::env::args().skip(1).peekable();
    let mut opts = Options {
        keyed: false,
        derive_key: None,
        length: 32,
        seek: 0,
        no_names: false,
        raw: false,
        tag: false,
        check: false,
        quiet: false,
        files: Vec::new(),
    };
    while let Some(arg) = args.next() {
        match arg.as_str() {
            "--help" => {
                print_help(true);
                return Ok(None);
            }
            "-h" => {
                print_help(false);
                return Ok(None);
            }
            "--version" | "-V" => {
                println!("b3sum 1.8.4");
                return Ok(None);
            }
            "--keyed" => opts.keyed = true,
            "--derive-key" => opts.derive_key = Some(args.next().ok_or_else(|| "error: a value is required for '--derive-key <CONTEXT>'".to_string())?),
            "-l" | "--length" => opts.length = parse_usize(args.next(), "--length <LEN>")?,
            "--seek" => opts.seek = parse_u64(args.next(), "--seek <SEEK>")?,
            "--num-threads" => {
                let _ = args.next().ok_or_else(|| "error: a value is required for '--num-threads <NUM>'".to_string())?;
            }
            "--no-mmap" => {}
            "--no-names" => opts.no_names = true,
            "--raw" => {
                opts.raw = true;
                opts.no_names = true;
            }
            "--tag" => opts.tag = true,
            "-c" | "--check" => opts.check = true,
            "--quiet" => opts.quiet = true,
            "--" => {
                opts.files.extend(args);
                break;
            }
            _ if arg.starts_with("--length=") => {
                opts.length = arg[9..]
                    .parse()
                    .map_err(|_| format!("error: invalid value '{}' for '--length <LEN>'", &arg[9..]))?;
            }
            _ if arg.starts_with("--seek=") => {
                opts.seek = arg[7..]
                    .parse()
                    .map_err(|_| format!("error: invalid value '{}' for '--seek <SEEK>'", &arg[7..]))?;
            }
            _ if arg.starts_with("--derive-key=") => opts.derive_key = Some(arg[13..].to_string()),
            _ if arg.starts_with('-') && arg != "-" => return Err(format!("error: unexpected argument '{arg}'")),
            _ => opts.files.push(arg),
        }
    }
    if opts.keyed && opts.derive_key.is_some() {
        return Err("error: the argument '--keyed' cannot be used with '--derive-key <CONTEXT>'".to_string());
    }
    if opts.raw && opts.files.len() > 1 {
        return Err("Error: Only one filename can be provided when using --raw".to_string());
    }
    if opts.raw && opts.check {
        return Err("error: the argument '--check' cannot be used with '--raw'".to_string());
    }
    if opts.quiet && !opts.check {
        return Err("error: the argument '--quiet' requires '--check'".to_string());
    }
    Ok(Some(opts))
}

fn read_input(path: &str) -> io::Result<Vec<u8>> {
    if path == "-" {
        let mut bytes = Vec::new();
        io::stdin().read_to_end(&mut bytes)?;
        Ok(bytes)
    } else {
        fs::read(path)
    }
}

fn mode_key(opts: &Options) -> Result<([u32; 8], u32), String> {
    if opts.keyed {
        let mut key_bytes = Vec::new();
        io::stdin()
            .read_to_end(&mut key_bytes)
            .map_err(|e| format!("Error: {e}"))?;
        if key_bytes.len() != 32 {
            if key_bytes.len() < 32 {
                return Err(format!("Error: expected 32 key bytes from stdin, found {}", key_bytes.len()));
            }
            return Err("Error: read more than 32 key bytes from stdin".to_string());
        }
        let mut key = [0u32; 8];
        for i in 0..8 {
            key[i] = u32::from_le_bytes([
                key_bytes[i * 4],
                key_bytes[i * 4 + 1],
                key_bytes[i * 4 + 2],
                key_bytes[i * 4 + 3],
            ]);
        }
        Ok((key, KEYED_HASH))
    } else if let Some(context) = &opts.derive_key {
        Ok((derive_key_words(context), DERIVE_KEY_MATERIAL))
    } else {
        Ok((IV, 0))
    }
}

fn hash_one(bytes: &[u8], opts: &Options, key: [u32; 8], flags: u32) -> Vec<u8> {
    hash_with_key(bytes, key, flags, opts.seek, opts.length)
}

fn display_name(path: &str) -> &str {
    if path.is_empty() {
        "-"
    } else {
        path
    }
}

fn escaped_name(path: &str) -> (bool, String) {
    let name = display_name(path);
    if !name.contains('\\') && !name.contains('\n') {
        return (false, name.to_string());
    }
    let mut out = String::with_capacity(name.len());
    for ch in name.chars() {
        match ch {
            '\\' => out.push_str("\\\\"),
            '\n' => out.push_str("\\n"),
            _ => out.push(ch),
        }
    }
    (true, out)
}

fn unescape_name(name: &str) -> String {
    let mut out = String::with_capacity(name.len());
    let mut chars = name.chars();
    while let Some(ch) = chars.next() {
        if ch == '\\' {
            match chars.next() {
                Some('n') => out.push('\n'),
                Some('\\') => out.push('\\'),
                Some(other) => {
                    out.push('\\');
                    out.push(other);
                }
                None => out.push('\\'),
            }
        } else {
            out.push(ch);
        }
    }
    out
}

fn run_hash(opts: Options) -> Result<(), String> {
    let (key, flags) = mode_key(&opts)?;
    let files = if opts.files.is_empty() {
        vec!["-".to_string()]
    } else {
        opts.files.clone()
    };
    let mut stdout = io::stdout();
    for file in files {
        let input = read_input(&file).map_err(|e| format!("Error: {file}: {e}"))?;
        let digest = hash_one(&input, &opts, key, flags);
        if opts.raw {
            stdout.write_all(&digest).map_err(|e| e.to_string())?;
        } else if opts.tag {
            let (_, name) = escaped_name(&file);
            writeln!(stdout, "BLAKE3 ({name}) = {}", hex(&digest)).map_err(|e| e.to_string())?;
        } else if opts.no_names {
            writeln!(stdout, "{}", hex(&digest)).map_err(|e| e.to_string())?;
        } else {
            let (escaped, name) = escaped_name(&file);
            writeln!(
                stdout,
                "{}{}  {}",
                if escaped { "\\" } else { "" },
                hex(&digest),
                name
            )
            .map_err(|e| e.to_string())?;
        }
    }
    Ok(())
}

fn parse_check_line(line: &str) -> Option<(String, String)> {
    let (escaped, line) = if let Some(line) = line.strip_prefix('\\') {
        (true, line)
    } else {
        (false, line)
    };
    if let Some(rest) = line.strip_prefix("BLAKE3 (") {
        let (name, hash) = rest.rsplit_once(") = ")?;
        return Some((
            hash.to_string(),
            if escaped { unescape_name(name) } else { name.to_string() },
        ));
    }
    let (hash, name) = line.split_once("  ")?;
    Some((
        hash.to_string(),
        if escaped { unescape_name(name) } else { name.to_string() },
    ))
}

fn run_check(opts: Options) -> Result<i32, String> {
    let (key, flags) = mode_key(&opts)?;
    let files = if opts.files.is_empty() {
        vec!["-".to_string()]
    } else {
        opts.files.clone()
    };
    let mut total_failures = 0usize;
    for checkfile in files {
        let contents = read_input(&checkfile).map_err(|e| format!("Error: {checkfile}: {e}"))?;
        let text = String::from_utf8_lossy(&contents);
        for line in text.lines().filter(|l| !l.trim().is_empty()) {
            let Some((expected, name)) = parse_check_line(line) else {
                eprintln!("b3sum: {checkfile}: improperly formatted checksum line");
                total_failures += 1;
                continue;
            };
            let path = Path::new(&name);
            let input = match fs::read(path) {
                Ok(input) => input,
                Err(e) => {
                    println!("{name}: FAILED ({e})");
                    total_failures += 1;
                    continue;
                }
            };
            let actual = hex(&hash_with_key(&input, key, flags, 0, expected.len() / 2));
            if actual == expected.to_ascii_lowercase() {
                if !opts.quiet {
                    println!("{name}: OK");
                }
            } else {
                println!("{name}: FAILED");
                total_failures += 1;
            }
        }
    }
    if total_failures > 0 {
        eprintln!(
            "b3sum: WARNING: {total_failures} computed checksum{} did NOT match",
            if total_failures == 1 { "" } else { "s" }
        );
        Ok(1)
    } else {
        Ok(0)
    }
}

fn main() {
    let exit = match parse_args() {
        Ok(None) => 0,
        Ok(Some(opts)) if opts.check => match run_check(opts) {
            Ok(code) => code,
            Err(e) => {
                eprintln!("{e}");
                1
            }
        },
        Ok(Some(opts)) => match run_hash(opts) {
            Ok(()) => 0,
            Err(e) => {
                eprintln!("{e}");
                1
            }
        },
        Err(e) => {
            eprintln!("{e}");
            if e.starts_with("Error:") { 1 } else { 2 }
        }
    };
    std::process::exit(exit);
}
