import os
import subprocess
import unittest
from pathlib import Path

ROOT = Path('/workspace')
BIN = ROOT / 'src' / 'samtools_py.py'


def run_cmd(*args, input_data=None):
    env = dict(os.environ)
    p = subprocess.run(['python3', str(BIN), *args], input=input_data, text=True,
                       stdout=subprocess.PIPE, stderr=subprocess.PIPE, cwd=ROOT, env=env)
    return p


class SamtoolsCliTests(unittest.TestCase):
    def test_help_lists_program_and_commands(self):
        p = run_cmd('--help')
        self.assertEqual(p.returncode, 0, p.stderr)
        self.assertIn('Program: samtools (Tools for alignments in the SAM format)', p.stdout)
        self.assertIn('Usage:   samtools <command> [options]', p.stdout)
        self.assertIn('     view           SAM<->BAM<->CRAM conversion', p.stdout)

    def test_flags_decodes_decimal_and_names(self):
        p = run_cmd('flags', '99', 'UNMAP,MUNMAP')
        self.assertEqual(p.returncode, 0, p.stderr)
        self.assertEqual(p.stdout.splitlines(), [
            '0x63\t99\tPAIRED,PROPER_PAIR,MREVERSE,READ1',
            '0xc\t12\tUNMAP,MUNMAP',
        ])

    def test_faidx_creates_index_and_extracts_region(self):
        fai = ROOT / 'examples' / 'toy.fa.fai'
        if fai.exists():
            fai.unlink()
        p = run_cmd('faidx', 'examples/toy.fa')
        self.assertEqual(p.returncode, 0, p.stderr)
        self.assertTrue(fai.exists())
        self.assertEqual(fai.read_text().splitlines()[:2], ['ref\t45\t5\t45\t46', 'ref2\t40\t57\t40\t41'])
        p = run_cmd('faidx', 'examples/toy.fa', 'ref:2-6')
        self.assertEqual(p.returncode, 0, p.stderr)
        self.assertEqual(p.stdout, '>ref:2-6\nGCATG\n')

    def test_dict_outputs_sequence_dictionary(self):
        p = run_cmd('dict', 'examples/toy.fa')
        self.assertEqual(p.returncode, 0, p.stderr)
        self.assertEqual(p.stdout.splitlines(), [
            '@HD\tVN:1.0\tSO:unsorted',
            '@SQ\tSN:ref\tLN:45\tM5:7a66cae8ab14aef8d635bc80649e730b\tUR:file:///workspace/examples/toy.fa',
            '@SQ\tSN:ref2\tLN:40\tM5:1636753510ec27476fdd109a6684680e\tUR:file:///workspace/examples/toy.fa',
        ])

    def test_view_filters_headers_and_regions_for_sam(self):
        p = run_cmd('view', 'examples/toy.sam', 'ref2:10-12')
        self.assertEqual(p.returncode, 0, p.stderr)
        self.assertEqual([line.split('\t')[0] for line in p.stdout.splitlines()], ['x1', 'x2', 'x3', 'x4', 'x5'])
        p = run_cmd('view', '-H', 'examples/toy.sam')
        self.assertEqual(p.stdout.splitlines(), ['@SQ\tSN:ref\tLN:45', '@SQ\tSN:ref2\tLN:40'])

    def test_flagstat_counts_basic_sam_records(self):
        p = run_cmd('flagstat', 'examples/toy.sam')
        self.assertEqual(p.returncode, 0, p.stderr)
        self.assertIn('12 + 0 in total (QC-passed reads + QC-failed reads)', p.stdout)
        self.assertIn('2 + 0 paired in sequencing', p.stdout)
        self.assertIn('2 + 0 properly paired (100.00% : N/A)', p.stdout)

    def test_fastq_and_fasta_convert_records(self):
        p = run_cmd('fastq', 'examples/toy.sam')
        self.assertEqual(p.returncode, 0, p.stderr)
        self.assertTrue(p.stdout.startswith('@r001\nTTAGATAAAGAGGATACTG\n+\n*******************\n'))
        p = run_cmd('fasta', 'examples/toy.sam')
        self.assertEqual(p.returncode, 0, p.stderr)
        self.assertTrue(p.stdout.startswith('>r001\nTTAGATAAAGAGGATACTG\n'))

    def test_depth_does_not_count_deletion_or_ref_skip_as_covered(self):
        p = run_cmd('depth', 'examples/toy.sam')
        self.assertEqual(p.returncode, 0, p.stderr)
        rows = p.stdout.splitlines()
        self.assertIn('ref\t19\t1', rows)
        self.assertIn('ref\t23\t0', rows)
        self.assertIn('ref\t24\t0', rows)


if __name__ == '__main__':
    unittest.main()
