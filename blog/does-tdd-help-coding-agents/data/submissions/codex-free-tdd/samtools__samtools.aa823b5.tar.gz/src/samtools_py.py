#!/usr/bin/env python3
import gzip
import hashlib
import os
import re
import sys
from pathlib import Path

VERSION = "be7a51c"

FLAGS = [
    (0x1, "PAIRED", "paired-end / multiple-segment sequencing technology"),
    (0x2, "PROPER_PAIR", "each segment properly aligned according to aligner"),
    (0x4, "UNMAP", "segment unmapped"),
    (0x8, "MUNMAP", "next segment in the template unmapped"),
    (0x10, "REVERSE", "SEQ is reverse complemented"),
    (0x20, "MREVERSE", "SEQ of next segment in template is rev.complemented"),
    (0x40, "READ1", "the first segment in the template"),
    (0x80, "READ2", "the last segment in the template"),
    (0x100, "SECONDARY", "secondary alignment"),
    (0x200, "QCFAIL", "not passing quality controls or other filters"),
    (0x400, "DUP", "PCR or optical duplicate"),
    (0x800, "SUPPLEMENTARY", "supplementary alignment"),
]
FLAG_BY_NAME = {name: value for value, name, _ in FLAGS}

HELP = f"""
Program: samtools (Tools for alignments in the SAM format)
Version: {VERSION} (using htslib 1.23.1)

Usage:   samtools <command> [options]

Commands:
  -- Indexing
     dict           create a sequence dictionary file
     faidx          index/extract FASTA
     fqidx          index/extract FASTQ
     index          index alignment

  -- Editing
     calmd          recalculate MD/NM tags and '=' bases
     fixmate        fix mate information
     reheader       replace BAM header
     targetcut      cut fosmid regions (for fosmid pool only)
     addreplacerg   adds or replaces RG tags
     markdup        mark duplicates
     ampliconclip   clip oligos from the end of reads

  -- File operations
     collate        shuffle and group alignments by name
     cat            concatenate BAMs
     consensus      produce a consensus Pileup/FASTA/FASTQ
     merge          merge sorted alignments
     mpileup        multi-way pileup
     sort           sort alignment file
     split          splits a file by read group
     quickcheck     quickly check if SAM/BAM/CRAM file appears intact
     fastq          converts a BAM to a FASTQ
     fasta          converts a BAM to a FASTA
     import         Converts FASTA or FASTQ files to SAM/BAM/CRAM
     reference      Generates a reference from aligned data
     reset          Reverts aligner changes in reads

  -- Statistics
     bedcov         read depth per BED region
     coverage       alignment depth and percent coverage
     depth          compute the depth
     flagstat       simple stats
     idxstats       BAM index stats
     cram-size      list CRAM Content-ID and Data-Series sizes
     phase          phase heterozygotes
     stats          generate stats (former bamcheck)
     ampliconstats  generate amplicon specific stats
     checksum       produce order-agnostic checksums of sequence content

  -- Viewing
     flags          explain BAM flags
     head           header viewer
     tview          text alignment viewer
     view           SAM<->BAM<->CRAM conversion
     depad          convert padded BAM to unpadded BAM
     samples        list the samples in a set of SAM/BAM/CRAM files

  -- Misc
     help [cmd]     display this help message or help for [cmd]
     version        detailed version information
""".lstrip()


def eprint(msg):
    print(msg, file=sys.stderr)


def open_text(path):
    if path == "-":
        return sys.stdin
    if path.endswith(".gz"):
        return gzip.open(path, "rt")
    return open(path, "rt", newline="")


def sam_lines(path):
    with open_text(path) as fh:
        for line in fh:
            yield line.rstrip("\n")


def split_sam(path):
    headers, records = [], []
    for line in sam_lines(path):
        if not line:
            continue
        if line.startswith("@"):
            headers.append(line)
        else:
            records.append(line.split("\t"))
    return headers, records


def parse_region(s):
    if not s or ":" not in s:
        return None
    name, rest = s.split(":", 1)
    rest = rest.replace(",", "")
    if "-" in rest:
        a, b = rest.split("-", 1)
        return name, int(a), int(b)
    pos = int(rest)
    return name, pos, pos


def cigar_ref_len(cigar):
    if cigar == "*":
        return 0
    total = 0
    for n, op in re.findall(r"(\d+)([MIDNSHP=X])", cigar):
        if op in "MDN=X":
            total += int(n)
    return total


def record_overlaps(fields, region):
    if region is None:
        return True
    rname, start, end = region
    if len(fields) < 6 or fields[2] != rname:
        return False
    try:
        pos = int(fields[3])
    except ValueError:
        return False
    if pos <= 0:
        return False
    ref_len = cigar_ref_len(fields[5]) or 1
    return pos <= end and pos + ref_len - 1 >= start


def cmd_help(args):
    if args:
        return main(args + ["--help"])
    print(HELP, end="")
    return 0


def cmd_version(_args):
    print(f"samtools {VERSION}")
    print("Using htslib 1.23.1")
    print("Copyright (C) 2025 Genome Research Ltd.")
    print()
    print("Samtools compilation details:")
    print("    Features:       build=configure curses=yes ")
    print("    CC:             gcc")
    print("    CPPFLAGS:       ")
    print("    CFLAGS:         -Wall -g -O2")
    print("    LDFLAGS:        ")
    print("    HTSDIR:         htslib")
    print("    LIBS:           ")
    print("    CURSES_LIB:     -lncursesw")
    return 0


def flags_usage():
    print("About: Convert between textual and numeric flag representation")
    print("Usage: samtools flags FLAGS...")
    print()
    print("Each FLAGS argument is either an INT (in decimal/hexadecimal/octal) representing")
    print("a combination of the following numeric flag values, or a comma-separated string")
    print("NAME,...,NAME representing a combination of the following flag names:")
    print()
    for value, name, desc in FLAGS:
        print(f"{value:#6x} {value:5d}  {name:<14} {desc}")


def cmd_flags(args):
    if not args or args == ["--help"]:
        flags_usage()
        return 0
    for arg in args:
        if re.fullmatch(r"[+-]?(0[xX][0-9a-fA-F]+|0[0-7]*|[0-9]+)", arg):
            value = int(arg, 0)
        else:
            value = 0
            for part in arg.split(","):
                key = part.strip().upper()
                if key:
                    value |= FLAG_BY_NAME.get(key, 0)
        names = ",".join(name for bit, name, _ in FLAGS if value & bit)
        print(f"{value:#x}\t{value}\t{names}")
    return 0


def parse_fasta_with_index(path):
    seqs = []
    name = None
    parts = []
    seq_start = None
    line_bases = None
    line_width = None
    offset = 0
    with open(path, "rb") as fh:
        for raw in fh:
            text = raw.decode("utf-8", errors="replace").rstrip("\r\n")
            if text.startswith(">"):
                if name is not None:
                    seqs.append((name, "".join(parts), seq_start, line_bases or 0, line_width or 0))
                name = text[1:].split()[0]
                parts = []
                seq_start = offset + len(raw)
                line_bases = None
                line_width = None
            else:
                if name is not None:
                    parts.append(text)
                    if line_bases is None:
                        line_bases = len(text)
                        line_width = len(raw)
            offset += len(raw)
    if name is not None:
        seqs.append((name, "".join(parts), seq_start, line_bases or 0, line_width or 0))
    return seqs


def write_fai(path, seqs):
    with open(path + ".fai", "w") as out:
        for name, seq, off, lb, lw in seqs:
            out.write(f"{name}\t{len(seq)}\t{off}\t{lb}\t{lw}\n")


def wrap(seq, width=60):
    if not seq:
        return ""
    return "\n".join(seq[i:i + width] for i in range(0, len(seq), width)) + "\n"


def cmd_faidx(args):
    if not args or args[0] == "--help":
        print("Usage: samtools faidx <file.fa|file.fa.gz> [<reg> [...]]")
        return 0 if args else 1
    fasta = args[0]
    seqs = parse_fasta_with_index(fasta)
    by_name = {name: seq for name, seq, *_ in seqs}
    write_fai(fasta, seqs)
    for reg in args[1:]:
        region = parse_region(reg)
        if region:
            name, start, end = region
            seq = by_name.get(name, "")[max(0, start - 1):end]
            print(f">{reg}")
            print(wrap(seq), end="")
        elif reg in by_name:
            print(f">{reg}")
            print(wrap(by_name[reg]), end="")
    return 0


def cmd_dict(args):
    if not args:
        eprint("Usage: samtools dict <file.fa|file.fa.gz>")
        return 1
    fasta = os.path.abspath(args[-1])
    print("@HD\tVN:1.0\tSO:unsorted")
    for name, seq, *_ in parse_fasta_with_index(args[-1]):
        m5 = hashlib.md5(seq.upper().encode()).hexdigest()
        print(f"@SQ\tSN:{name}\tLN:{len(seq)}\tM5:{m5}\tUR:file://{fasta}")
    return 0


def is_option_filename(args):
    for a in reversed(args):
        if not a.startswith("-"):
            return a
    return "-"


def cmd_view(args):
    include_header = False
    header_only = False
    count_only = False
    outfile = None
    min_mapq = None
    flag_include = 0
    flag_exclude = 0
    positional = []
    i = 0
    while i < len(args):
        a = args[i]
        if a in ("-h", "--with-header"):
            include_header = True
        elif a in ("-H", "--header-only"):
            header_only = True
        elif a == "-c":
            count_only = True
        elif a == "-q" and i + 1 < len(args):
            i += 1
            min_mapq = int(args[i])
        elif a in ("-f", "--require-flags") and i + 1 < len(args):
            i += 1
            flag_include = int(args[i], 0)
        elif a in ("-F", "--excl-flags", "--exclude-flags") and i + 1 < len(args):
            i += 1
            flag_exclude = int(args[i], 0)
        elif a == "-o" and i + 1 < len(args):
            i += 1
            outfile = args[i]
        elif a.startswith("-"):
            pass
        else:
            positional.append(a)
        i += 1
    if not positional:
        eprint('[main_samview] fail to read the header from "-".')
        return 1
    path = positional[0]
    region = parse_region(positional[1]) if len(positional) > 1 else None
    headers, records = split_sam(path)
    lines = []
    if include_header or header_only:
        lines.extend(headers)
    if not header_only:
        for rec in records:
            if len(rec) < 11:
                continue
            flag = int(rec[1])
            if flag_include and (flag & flag_include) != flag_include:
                continue
            if flag_exclude and (flag & flag_exclude):
                continue
            if min_mapq is not None and int(rec[4]) < min_mapq:
                continue
            if record_overlaps(rec, region):
                lines.append("\t".join(rec))
    if count_only:
        text = f"{len(lines) if not (include_header or header_only) else len([x for x in lines if not x.startswith('@')])}\n"
    else:
        text = "".join(line + "\n" for line in lines)
    if outfile:
        Path(outfile).write_text(text)
    else:
        sys.stdout.write(text)
    return 0


def cmd_head(args):
    n = 0
    positional = []
    i = 0
    while i < len(args):
        if args[i] == "-n" and i + 1 < len(args):
            i += 1
            n = int(args[i])
        elif not args[i].startswith("-"):
            positional.append(args[i])
        i += 1
    if not positional:
        return 1
    headers, records = split_sam(positional[0])
    for h in headers:
        print(h)
    for rec in records[:n]:
        print("\t".join(rec))
    return 0


def cmd_sort(args):
    name_sort = False
    outfile = None
    positional = []
    i = 0
    while i < len(args):
        if args[i] == "-n":
            name_sort = True
        elif args[i] == "-o" and i + 1 < len(args):
            i += 1
            outfile = args[i]
        elif not args[i].startswith("-"):
            positional.append(args[i])
        i += 1
    if not positional:
        return 1
    headers, records = split_sam(positional[-1])
    if name_sort:
        records.sort(key=lambda r: r[0])
    else:
        order = {}
        for h in headers:
            if h.startswith("@SQ\t"):
                fields = dict(part.split(":", 1) for part in h.split("\t")[1:] if ":" in part)
                if "SN" in fields:
                    order[fields["SN"]] = len(order)
        records.sort(key=lambda r: (order.get(r[2], 10**9), int(r[3]) if r[3].isdigit() else 0, r[0]))
    text = "".join(h + "\n" for h in headers) + "".join("\t".join(r) + "\n" for r in records)
    if outfile:
        Path(outfile).write_text(text)
    else:
        sys.stdout.write(text)
    return 0


def flagstat_line(passn, failn, label, pct=None):
    if pct is None:
        return f"{passn} + {failn} {label}"
    return f"{passn} + {failn} {label} ({pct} : N/A)"


def pct(num, den):
    if den == 0:
        return "N/A"
    return f"{100.0 * num / den:.2f}%"


def cmd_flagstat(args):
    if not args:
        return 1
    _headers, records = split_sam(args[-1])
    pass_recs = [r for r in records if not (int(r[1]) & 0x200)]
    fail_recs = [r for r in records if int(r[1]) & 0x200]
    def count(mask, recs=pass_recs):
        return sum(1 for r in recs if int(r[1]) & mask)
    def primary(recs=pass_recs):
        return [r for r in recs if not (int(r[1]) & 0x900)]
    mapped = sum(1 for r in pass_recs if not (int(r[1]) & 0x4))
    primary_pass = primary()
    primary_mapped = sum(1 for r in primary_pass if not (int(r[1]) & 0x4))
    paired = count(0x1)
    proper = count(0x2)
    mate_mapped = sum(1 for r in pass_recs if (int(r[1]) & 0x1) and not (int(r[1]) & 0x4) and not (int(r[1]) & 0x8))
    singletons = sum(1 for r in pass_recs if (int(r[1]) & 0x1) and not (int(r[1]) & 0x4) and (int(r[1]) & 0x8))
    diffchr = sum(1 for r in pass_recs if len(r) > 6 and r[6] not in ("*", "=", r[2]) and not (int(r[1]) & 0x4) and not (int(r[1]) & 0x8))
    diffchr5 = sum(1 for r in pass_recs if len(r) > 6 and r[6] not in ("*", "=", r[2]) and not (int(r[1]) & 0x4) and not (int(r[1]) & 0x8) and int(r[4]) >= 5)
    lines = [
        flagstat_line(len(pass_recs), len(fail_recs), "in total (QC-passed reads + QC-failed reads)"),
        flagstat_line(len(primary_pass), len(primary(fail_recs)), "primary"),
        flagstat_line(count(0x100), count(0x100, fail_recs), "secondary"),
        flagstat_line(count(0x800), count(0x800, fail_recs), "supplementary"),
        flagstat_line(count(0x400), count(0x400, fail_recs), "duplicates"),
        flagstat_line(sum(1 for r in primary_pass if int(r[1]) & 0x400), 0, "primary duplicates"),
        flagstat_line(mapped, sum(1 for r in fail_recs if not (int(r[1]) & 0x4)), "mapped", pct(mapped, len(pass_recs))),
        flagstat_line(primary_mapped, 0, "primary mapped", pct(primary_mapped, len(primary_pass))),
        flagstat_line(paired, count(0x1, fail_recs), "paired in sequencing"),
        flagstat_line(count(0x40), count(0x40, fail_recs), "read1"),
        flagstat_line(count(0x80), count(0x80, fail_recs), "read2"),
        flagstat_line(proper, count(0x2, fail_recs), "properly paired", pct(proper, paired)),
        flagstat_line(mate_mapped, 0, "with itself and mate mapped"),
        flagstat_line(singletons, 0, "singletons", pct(singletons, paired)),
        flagstat_line(diffchr, 0, "with mate mapped to a different chr"),
        flagstat_line(diffchr5, 0, "with mate mapped to a different chr (mapQ>=5)"),
    ]
    print("\n".join(lines))
    return 0


def reference_lengths(headers):
    refs = []
    for h in headers:
        if h.startswith("@SQ\t"):
            data = {}
            for part in h.split("\t")[1:]:
                if ":" in part:
                    k, v = part.split(":", 1)
                    data[k] = v
            if "SN" in data:
                refs.append((data["SN"], int(data.get("LN", "0"))))
    return refs


def cmd_idxstats(args):
    if not args:
        return 1
    headers, records = split_sam(args[-1])
    refs = reference_lengths(headers)
    mapped = {name: 0 for name, _ in refs}
    unmapped = {name: 0 for name, _ in refs}
    no_coord = 0
    for r in records:
        flag = int(r[1])
        if r[2] == "*":
            no_coord += 1
        elif flag & 0x4:
            unmapped[r[2]] = unmapped.get(r[2], 0) + 1
        else:
            mapped[r[2]] = mapped.get(r[2], 0) + 1
    for name, length in refs:
        print(f"{name}\t{length}\t{mapped.get(name, 0)}\t{unmapped.get(name, 0)}")
    print(f"*\t0\t0\t{no_coord}")
    return 0


def qual_for(seq, qual):
    if qual == "*" or len(qual) != len(seq):
        return "*" * len(seq)
    return qual


def cmd_fastx(args, fasta=False):
    if not args:
        return 1
    _headers, records = split_sam(args[-1])
    for r in records:
        if len(r) < 11 or r[9] == "*":
            continue
        if fasta:
            print(f">{r[0]}")
            print(wrap(r[9]), end="")
        else:
            print(f"@{r[0]}")
            print(r[9])
            print("+")
            print(qual_for(r[9], r[10]))
    return 0


def cmd_depth(args):
    positional = [a for a in args if not a.startswith("-")]
    if not positional:
        return 1
    _headers, records = split_sam(positional[-1])
    cov = {}
    spans = {}
    for r in records:
        if len(r) < 6 or int(r[1]) & 0x4:
            continue
        ref = r[2]
        pos = int(r[3])
        cur = pos
        if r[5] == "*":
            continue
        for n_s, op in re.findall(r"(\d+)([MIDNSHP=X])", r[5]):
            n = int(n_s)
            if op in "M=X":
                for p in range(cur, cur + n):
                    cov[(ref, p)] = cov.get((ref, p), 0) + 1
                cur += n
            elif op in "DN":
                cur += n
            elif op in "ISH P".replace(" ", ""):
                pass
        if cur > pos:
            old = spans.get(ref)
            spans[ref] = (pos, cur - 1) if old is None else (min(old[0], pos), max(old[1], cur - 1))
    for ref in sorted(spans):
        start, end = spans[ref]
        for p in range(start, end + 1):
            print(f"{ref}\t{p}\t{cov.get((ref, p), 0)}")
    return 0


def unsupported(cmd):
    eprint(f"[samtools] command '{cmd}' is not implemented in this cleanroom reimplementation")
    return 1


def main(argv):
    if not argv or argv[0] in ("--help", "-h"):
        print(HELP, end="")
        return 0
    cmd, args = argv[0], argv[1:]
    table = {
        "help": cmd_help,
        "version": cmd_version,
        "--version": cmd_version,
        "flags": cmd_flags,
        "faidx": cmd_faidx,
        "fqidx": cmd_faidx,
        "dict": cmd_dict,
        "view": cmd_view,
        "head": cmd_head,
        "sort": cmd_sort,
        "flagstat": cmd_flagstat,
        "idxstats": cmd_idxstats,
        "fastq": lambda a: cmd_fastx(a, False),
        "fasta": lambda a: cmd_fastx(a, True),
        "depth": cmd_depth,
    }
    if cmd in table:
        return table[cmd](args)
    return unsupported(cmd)


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
