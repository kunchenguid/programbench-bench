#!/usr/bin/env python3
import colorsys
import math
import random
import re
import sys


CSS = {
    "black": (0, 0, 0), "silver": (192, 192, 192), "gray": (128, 128, 128),
    "white": (255, 255, 255), "maroon": (128, 0, 0), "red": (255, 0, 0),
    "purple": (128, 0, 128), "fuchsia": (255, 0, 255), "green": (0, 128, 0),
    "lime": (0, 255, 0), "olive": (128, 128, 0), "yellow": (255, 255, 0),
    "navy": (0, 0, 128), "blue": (0, 0, 255), "teal": (0, 128, 128),
    "aqua": (0, 255, 255), "orange": (255, 165, 0), "aliceblue": (240, 248, 255),
    "antiquewhite": (250, 235, 215), "aquamarine": (127, 255, 212),
    "azure": (240, 255, 255), "beige": (245, 245, 220), "bisque": (255, 228, 196),
    "blanchedalmond": (255, 235, 205), "blueviolet": (138, 43, 226),
    "brown": (165, 42, 42), "burlywood": (222, 184, 135), "cadetblue": (95, 158, 160),
    "chartreuse": (127, 255, 0), "chocolate": (210, 105, 30), "coral": (255, 127, 80),
    "cornflowerblue": (100, 149, 237), "cornsilk": (255, 248, 220),
    "crimson": (220, 20, 60), "cyan": (0, 255, 255), "darkblue": (0, 0, 139),
    "darkcyan": (0, 139, 139), "darkgoldenrod": (184, 134, 11),
    "darkgray": (169, 169, 169), "darkgreen": (0, 100, 0), "darkgrey": (169, 169, 169),
    "darkkhaki": (189, 183, 107), "darkmagenta": (139, 0, 139),
    "darkolivegreen": (85, 107, 47), "darkorange": (255, 140, 0),
    "darkorchid": (153, 50, 204), "darkred": (139, 0, 0), "darksalmon": (233, 150, 122),
    "darkseagreen": (143, 188, 143), "darkslateblue": (72, 61, 139),
    "darkslategray": (47, 79, 79), "darkslategrey": (47, 79, 79),
    "darkturquoise": (0, 206, 209), "darkviolet": (148, 0, 211),
    "deeppink": (255, 20, 147), "deepskyblue": (0, 191, 255),
    "dimgray": (105, 105, 105), "dimgrey": (105, 105, 105), "dodgerblue": (30, 144, 255),
    "firebrick": (178, 34, 34), "floralwhite": (255, 250, 240),
    "forestgreen": (34, 139, 34), "gainsboro": (220, 220, 220),
    "ghostwhite": (248, 248, 255), "gold": (255, 215, 0), "goldenrod": (218, 165, 32),
    "greenyellow": (173, 255, 47), "grey": (128, 128, 128), "honeydew": (240, 255, 240),
    "hotpink": (255, 105, 180), "indianred": (205, 92, 92), "indigo": (75, 0, 130),
    "ivory": (255, 255, 240), "khaki": (240, 230, 140), "lavender": (230, 230, 250),
    "lavenderblush": (255, 240, 245), "lawngreen": (124, 252, 0),
    "lemonchiffon": (255, 250, 205), "lightblue": (173, 216, 230),
    "lightcoral": (240, 128, 128), "lightcyan": (224, 255, 255),
    "lightgoldenrodyellow": (250, 250, 210), "lightgray": (211, 211, 211),
    "lightgreen": (144, 238, 144), "lightgrey": (211, 211, 211),
    "lightpink": (255, 182, 193), "lightsalmon": (255, 160, 122),
    "lightseagreen": (32, 178, 170), "lightskyblue": (135, 206, 250),
    "lightslategray": (119, 136, 153), "lightslategrey": (119, 136, 153),
    "lightsteelblue": (176, 196, 222), "lightyellow": (255, 255, 224),
    "limegreen": (50, 205, 50), "linen": (250, 240, 230), "magenta": (255, 0, 255),
    "mediumaquamarine": (102, 205, 170), "mediumblue": (0, 0, 205),
    "mediumorchid": (186, 85, 211), "mediumpurple": (147, 112, 219),
    "mediumseagreen": (60, 179, 113), "mediumslateblue": (123, 104, 238),
    "mediumspringgreen": (0, 250, 154), "mediumturquoise": (72, 209, 204),
    "mediumvioletred": (199, 21, 133), "midnightblue": (25, 25, 112),
    "mintcream": (245, 255, 250), "mistyrose": (255, 228, 225),
    "moccasin": (255, 228, 181), "navajowhite": (255, 222, 173),
    "oldlace": (253, 245, 230), "olivedrab": (107, 142, 35),
    "orangered": (255, 69, 0), "orchid": (218, 112, 214),
    "palegoldenrod": (238, 232, 170), "palegreen": (152, 251, 152),
    "paleturquoise": (175, 238, 238), "palevioletred": (219, 112, 147),
    "papayawhip": (255, 239, 213), "peachpuff": (255, 218, 185),
    "peru": (205, 133, 63), "pink": (255, 192, 203), "plum": (221, 160, 221),
    "powderblue": (176, 224, 230), "rebeccapurple": (102, 51, 153),
    "rosybrown": (188, 143, 143), "royalblue": (65, 105, 225),
    "saddlebrown": (139, 69, 19), "salmon": (250, 128, 114),
    "sandybrown": (244, 164, 96), "seagreen": (46, 139, 87), "seashell": (255, 245, 238),
    "sienna": (160, 82, 45), "skyblue": (135, 206, 235), "slateblue": (106, 90, 205),
    "slategray": (112, 128, 144), "slategrey": (112, 128, 144), "snow": (255, 250, 250),
    "springgreen": (0, 255, 127), "steelblue": (70, 130, 180), "tan": (210, 180, 140),
    "thistle": (216, 191, 216), "tomato": (255, 99, 71), "turquoise": (64, 224, 208),
    "violet": (238, 130, 238), "wheat": (245, 222, 179), "whitesmoke": (245, 245, 245),
    "yellowgreen": (154, 205, 50),
}
REV = {v: k for k, v in CSS.items() if k not in ("grey", "darkgrey", "lightgrey", "slategrey", "darkslategrey", "lightslategrey", "cyan", "magenta")}
LIST_ORDER = """black palevioletred pink lightpink snow rosybrown lightcoral crimson indianred mistyrose brown salmon firebrick maroon tomato darkred red darksalmon orangered coral lightsalmon sienna chocolate saddlebrown sandybrown darkorange seashell peru peachpuff orange linen burlywood bisque tan antiquewhite navajowhite darkgoldenrod blanchedalmond goldenrod moccasin papayawhip wheat oldlace floralwhite gold cornsilk khaki darkkhaki olive yellow palegoldenrod lemonchiffon lightgoldenrodyellow lightyellow beige ivory olivedrab yellowgreen darkolivegreen greenyellow chartreuse lawngreen darkgreen green lime limegreen forestgreen palegreen lightgreen darkseagreen honeydew springgreen seagreen mediumseagreen mediumspringgreen mintcream mediumaquamarine aquamarine turquoise lightseagreen mediumturquoise aqua darkcyan teal darkslategray paleturquoise darkturquoise lightcyan azure cadetblue powderblue lightblue skyblue deepskyblue lightskyblue aliceblue slategray lightslategray steelblue lightsteelblue dodgerblue cornflowerblue ghostwhite lavender royalblue darkgray dimgray gainsboro gray lightgray silver white whitesmoke darkslateblue slateblue mediumslateblue midnightblue blue darkblue mediumblue navy mediumpurple rebeccapurple blueviolet indigo darkorchid darkviolet mediumorchid thistle plum violet orchid darkmagenta fuchsia purple mediumvioletred hotpink lavenderblush deeppink""".split()


class Color:
    def __init__(self, r, g, b, a=1.0, hsl_override=None):
        self.r = int(max(0, min(255, round(r))))
        self.g = int(max(0, min(255, round(g))))
        self.b = int(max(0, min(255, round(b))))
        self.a = max(0.0, min(1.0, float(a)))
        self._hsl = hsl_override

    def hsl(self):
        if self._hsl is not None:
            return self._hsl
        h, l, s = colorsys.rgb_to_hls(self.r / 255, self.g / 255, self.b / 255)
        return h * 360, s, l

    @staticmethod
    def from_hsl(h, s, l, a=1.0):
        r, g, b = colorsys.hls_to_rgb((h % 360) / 360, l, max(0, min(1, s)))
        return Color(r * 255, g * 255, b * 255, a, ((h % 360), max(0, min(1, s)), max(0, min(1, l))))


def pct_value(s):
    s = str(s).strip()
    if s.endswith("%"):
        return float(s[:-1]) / 100
    v = float(s)
    return v / 100 if abs(v) > 1 else v


def parse_color(s):
    s = s.strip()
    low = s.lower().replace(" ", "")
    if low in CSS:
        return Color(*CSS[low])
    if low.startswith("#"):
        low = low[1:]
    if re.fullmatch(r"[0-9a-f]{3,4}", low):
        vals = [int(c * 2, 16) for c in low]
        return Color(vals[0], vals[1], vals[2], vals[3] / 255 if len(vals) == 4 else 1)
    if re.fullmatch(r"[0-9a-f]{6}([0-9a-f]{2})?", low):
        return Color(int(low[0:2], 16), int(low[2:4], 16), int(low[4:6], 16), int(low[6:8], 16) / 255 if len(low) == 8 else 1)
    m = re.fullmatch(r"rgba?\((.*)\)", s.strip(), re.I)
    if m:
        parts = [p.strip().rstrip("%") for p in m.group(1).split(",")]
        a = pct_value(parts[3]) if len(parts) > 3 else 1
        return Color(float(parts[0]), float(parts[1]), float(parts[2]), a)
    if re.fullmatch(r"\d+(\.\d+)?,\d+(\.\d+)?,\d+(\.\d+)?", low):
        p = [float(x) for x in low.split(",")]
        return Color(p[0], p[1], p[2])
    m = re.fullmatch(r"hsla?\((.*)\)", s.strip(), re.I)
    if m:
        parts = [p.strip() for p in m.group(1).split(",")]
        a = pct_value(parts[3]) if len(parts) > 3 else 1
        return Color.from_hsl(float(parts[0]), pct_value(parts[1]), pct_value(parts[2]), a)
    m = re.fullmatch(r"gray\((.*)\)", s.strip(), re.I)
    if m:
        v = pct_value(m.group(1)) * 255
        return Color(v, v, v)
    raise ValueError(f"Could not parse color: {s}")


def read_colors(args):
    if not args:
        data = sys.stdin.read().splitlines()
        return [parse_color(x) for x in data if x.strip()]
    out = []
    for a in args:
        if a == "-":
            line = sys.stdin.readline()
            out.append(parse_color(line))
        else:
            out.append(parse_color(a))
    return out


def luminance(c):
    def f(v):
        v /= 255
        return v / 12.92 if v <= 0.03928 else ((v + 0.055) / 1.055) ** 2.4
    return 0.2126 * f(c.r) + 0.7152 * f(c.g) + 0.0722 * f(c.b)


def brightness(c):
    return (0.299 * c.r + 0.587 * c.g + 0.114 * c.b) / 255


def fmt_num(x, digits=1):
    return f"{x:.{digits}f}"


def output_color(c, typ="hsl"):
    h, s, l = c.hsl()
    if typ == "hex":
        if c.a < 0.9995:
            return f"#{c.r:02x}{c.g:02x}{c.b:02x}{round(c.a*255):02x}"
        return f"#{c.r:02x}{c.g:02x}{c.b:02x}"
    if typ == "rgb":
        if c.a < 0.9995:
            return f"rgba({c.r}, {c.g}, {c.b}, {c.a:.3f})"
        return f"rgb({c.r}, {c.g}, {c.b})"
    if typ == "rgb-float":
        if c.a < 0.9995:
            return f"rgba({c.r/255:.3f}, {c.g/255:.3f}, {c.b/255:.3f}, {c.a:.3f})"
        return f"rgb({c.r/255:.3f}, {c.g/255:.3f}, {c.b/255:.3f})"
    if typ == "rgb-r":
        return str(c.r)
    if typ == "rgb-g":
        return str(c.g)
    if typ == "rgb-b":
        return str(c.b)
    if typ == "hsl":
        if c.a < 0.9995:
            return f"hsla({round(h)},{s*100:.1f}%,{l*100:.1f}%,{c.a:.3g})"
        return f"hsl({round(h)},{s*100:.1f}%,{l*100:.1f}%)"
    if typ == "hsl-format":
        if c.a < 0.9995:
            return f"hsla({round(h)}, {s*100:.1f}%, {l*100:.1f}%, {c.a:.3f})"
        return f"hsl({round(h)}, {s*100:.1f}%, {l*100:.1f}%)"
    if typ == "hsl-hue":
        return str(round(h))
    if typ == "hsl-saturation":
        return f"{s:.4f}"
    if typ == "hsl-lightness":
        return f"{l:.4f}"
    if typ == "hsv":
        hh, ss, vv = colorsys.rgb_to_hsv(c.r / 255, c.g / 255, c.b / 255)
        return f"hsv({round(hh*360)}, {ss*100:.1f}%, {vv*100:.1f}%)"
    if typ == "hsv-hue":
        hh, _, _ = colorsys.rgb_to_hsv(c.r / 255, c.g / 255, c.b / 255)
        return str(round(hh * 360))
    if typ == "hsv-saturation":
        _, ss, _ = colorsys.rgb_to_hsv(c.r / 255, c.g / 255, c.b / 255)
        return f"{ss:.4f}"
    if typ == "hsv-value":
        _, _, vv = colorsys.rgb_to_hsv(c.r / 255, c.g / 255, c.b / 255)
        return f"{vv:.4f}"
    if typ == "cmyk":
        if (c.r, c.g, c.b) == (0, 0, 0):
            return "cmyk(0, 0, 0, 100)"
        rr, gg, bb = c.r / 255, c.g / 255, c.b / 255
        k = 1 - max(rr, gg, bb)
        cy = (1 - rr - k) / (1 - k)
        ma = (1 - gg - k) / (1 - k)
        ye = (1 - bb - k) / (1 - k)
        return f"cmyk({round(cy*100)}, {round(ma*100)}, {round(ye*100)}, {round(k*100)})"
    if typ == "name":
        if (c.r, c.g, c.b) in REV:
            return REV[(c.r, c.g, c.b)]
        best = min(((sum((a - b) ** 2 for a, b in zip((c.r, c.g, c.b), rgb)), name) for name, rgb in CSS.items()), key=lambda x: x[0])
        return best[1]
    if typ == "ansi-24bit-escapecode":
        return f"\x1b[38;2;{c.r};{c.g};{c.b}m"
    if typ == "ansi-24bit":
        return f"\x1b[48;2;{c.r};{c.g};{c.b}m  \x1b[0m"
    if typ in ("luminance", "brightness"):
        return f"{(luminance(c) if typ == 'luminance' else brightness(c)):.3f}"
    if typ in ("lab", "lch", "oklab", "oklch"):
        return output_color(c, "hex")
    if typ.startswith("ansi-8bit"):
        val = ansi8(c)
        if typ == "ansi-8bit-value":
            return str(val)
        if typ == "ansi-8bit-escapecode":
            return f"\x1b[38;5;{val}m"
        return f"\\x1b[38;5;{val}m"
    return output_color(c, "hex")


def ansi8(c):
    if c.r == c.g == c.b:
        if c.r < 8:
            return 16
        if c.r > 248:
            return 231
        return round(((c.r - 8) / 247) * 24) + 232
    return 16 + 36 * min(5, int(c.r / 51)) + 6 * min(5, int(c.g / 51)) + min(5, int(c.b / 51))


def srgb_to_linear(v):
    v /= 255
    return v / 12.92 if v <= 0.04045 else ((v + 0.055) / 1.055) ** 2.4


def linear_to_srgb(v):
    v = max(0, min(1, v))
    return 255 * (12.92 * v if v <= 0.0031308 else 1.055 * (v ** (1 / 2.4)) - 0.055)


def xyz_to_lab(x, y, z):
    x /= 0.95047
    z /= 1.08883
    def f(t):
        return t ** (1 / 3) if t > 0.008856 else 7.787 * t + 16 / 116
    fx, fy, fz = f(x), f(y), f(z)
    return 116 * fy - 16, 500 * (fx - fy), 200 * (fy - fz)


def lab_to_xyz(L, a, b):
    fy = (L + 16) / 116
    fx = a / 500 + fy
    fz = fy - b / 200
    def finv(t):
        return t ** 3 if t ** 3 > 0.008856 else (t - 16 / 116) / 7.787
    return finv(fx) * 0.95047, finv(fy), finv(fz) * 1.08883


def to_lab(c):
    r, g, b = srgb_to_linear(c.r), srgb_to_linear(c.g), srgb_to_linear(c.b)
    x = r * 0.4124564 + g * 0.3575761 + b * 0.1804375
    y = r * 0.2126729 + g * 0.7151522 + b * 0.0721750
    z = r * 0.0193339 + g * 0.1191920 + b * 0.9503041
    return xyz_to_lab(x, y, z)


def from_lab(L, a, b):
    x, y, z = lab_to_xyz(L, a, b)
    r = x * 3.2404542 + y * -1.5371385 + z * -0.4985314
    g = x * -0.9692660 + y * 1.8760108 + z * 0.0415560
    bl = x * 0.0556434 + y * -0.2040259 + z * 1.0572252
    return Color(linear_to_srgb(r), linear_to_srgb(g), linear_to_srgb(bl))


def print_lines(lines):
    sys.stdout.write("\n".join(lines))
    if lines:
        sys.stdout.write("\n")


HELP = """A command-line tool to generate, analyze, convert and manipulate colors

Usage: executable [OPTIONS] <COMMAND>

Commands:
  color       Display information about the given color
  colorblind  Simulate a color under a certain colorblindness profile
  colorcheck  Check if your terminal emulator supports 24-bit colors.
  complement  Get the complementary color (hue rotated by 180°)
  darken      Darken color by a specified amount
  desaturate  Decrease color saturation by a specified amount
  distinct    Generate a set of visually distinct colors
  format      Convert a color to the given format
  gradient    Generate an interpolating sequence of colors
  gray        Create a gray tone from a given lightness
  help        Print this message or the help of the given subcommand(s)
  lighten     Lighten color by a specified amount
  list        Show a list of available color names
  mix         Mix two colors in the given colorspace
  paint       Print colored text using ANSI escape sequences
  pick        Interactively pick a color from the screen (pipette)
  random      Generate a list of random colors
  rotate      Rotate the hue channel by the specified angle
  saturate    Increase color saturation by a specified amount
  set         Set a color property to a specific value
  sort-by     Sort colors by the given property
  textcolor   Get a readable text color for the given background color
  to-gray     Completely desaturate a color (preserving luminance)

Options:
  -f, --force-color                  Alias for --mode=24bit
  -h, --help                         Print help
  -m, --color-mode <mode>            Specify the terminal color mode: 24bit, 8bit, off, *auto*
  -V, --version                      Print version
"""


def split_opts(args):
    opts = {}
    rest = []
    i = 0
    while i < len(args):
        a = args[i]
        if a in ("-n", "--number") and i + 1 < len(args):
            opts["number"] = int(args[i + 1]); i += 2
        elif a.startswith("--number="):
            opts["number"] = int(a.split("=", 1)[1]); i += 1
        elif a in ("-s", "--colorspace", "--strategy", "--sort") and i + 1 < len(args):
            opts[a.lstrip("-")] = args[i + 1]; i += 2
        elif a.startswith("--colorspace="):
            opts["colorspace"] = a.split("=", 1)[1]; i += 1
        elif a in ("-f", "--fraction") and i + 1 < len(args):
            opts["fraction"] = float(args[i + 1]); i += 2
        elif a.startswith("--fraction="):
            opts["fraction"] = float(a.split("=", 1)[1]); i += 1
        elif a in ("-r", "--reverse"):
            opts["reverse"] = True; i += 1
        elif a in ("-u", "--unique"):
            opts["unique"] = True; i += 1
        elif a in ("-b", "--bold"):
            opts["bold"] = True; i += 1
        elif a in ("-i", "--italic"):
            opts["italic"] = True; i += 1
        elif a in ("-u", "--underline"):
            opts["underline"] = True; i += 1
        elif a in ("-o", "--on") and i + 1 < len(args):
            opts["on"] = args[i + 1]; i += 2
        elif a == "--no-newline" or a == "-n":
            opts["no_newline"] = True; i += 1
        else:
            rest.append(a); i += 1
    return opts, rest


def interp(c1, c2, t, space="RGB"):
    if space.upper() == "HSL":
        h1, s1, l1 = c1.hsl(); h2, s2, l2 = c2.hsl()
        dh = ((h2 - h1 + 180) % 360) - 180
        return Color.from_hsl(h1 + dh * t, s1 + (s2 - s1) * t, l1 + (l2 - l1) * t)
    if space.upper() == "LAB":
        L1, a1, b1 = to_lab(c1); L2, a2, b2 = to_lab(c2)
        return from_lab(L1 + (L2 - L1) * t, a1 + (a2 - a1) * t, b1 + (b2 - b1) * t)
    return Color(c1.r + (c2.r - c1.r) * t, c1.g + (c2.g - c1.g) * t, c1.b + (c2.b - c1.b) * t)


def relative_gray(c):
    y = luminance(c)
    v = 12.92 * y if y <= 0.0031308 else 1.055 * (y ** (1 / 2.4)) - 0.055
    vv = round(v * 255) / 255
    h, _, _ = c.hsl()
    return Color(v * 255, v * 255, v * 255, c.a, (h, 0, vv))


def main(argv):
    force = False
    cleaned = []
    i = 0
    while i < len(argv):
        if argv[i] in ("-f", "--force-color"):
            force = True; i += 1
        elif argv[i] in ("-m", "--color-mode") and i + 1 < len(argv):
            force = argv[i + 1] == "24bit"; i += 2
        elif argv[i].startswith("--color-mode="):
            force = argv[i].split("=", 1)[1] == "24bit"; i += 1
        else:
            cleaned.append(argv[i]); i += 1
    argv = cleaned
    if not argv or argv[0] in ("--help", "-h", "help"):
        print(HELP, end="")
        return 2 if not argv else 0
    if argv[0] in ("--version", "-V"):
        print("pastel 0.11.0")
        return 0
    cmd, args = argv[0], argv[1:]
    if args and args[0] in ("--help", "-h"):
        print(HELP, end="")
        return 0
    try:
        if cmd == "format":
            formats = {"rgb","rgb-float","rgb-r","rgb-g","rgb-b","hex","hsl","hsl-hue","hsl-saturation","hsl-lightness","hsv","hsv-hue","hsv-saturation","hsv-value","cmyk","name","ansi-24bit-escapecode","ansi-24bit","ansi-8bit","ansi-8bit-value","ansi-8bit-escapecode","luminance","brightness","lab","lch","oklab","oklch"}
            typ = args[0] if args and args[0] in formats else "hex"
            colors = read_colors(args[1:] if args and args[0] in formats else args)
            if typ in ("ansi-24bit-escapecode", "ansi-8bit-escapecode"):
                sys.stdout.write("".join(output_color(c, typ) for c in colors))
            else:
                actual = "hsl-format" if typ == "hsl" else typ
                print_lines([output_color(c, actual) for c in colors])
        elif cmd == "gray":
            v = pct_value(args[0])
            print(output_color(Color.from_hsl(0, 0, v)))
        elif cmd in ("lighten", "darken", "saturate", "desaturate", "rotate", "complement"):
            if cmd == "complement":
                amt, rest = 180.0, args
            else:
                amt, rest = float(args[0]), args[1:]
            colors = read_colors(rest)
            out = []
            for c in colors:
                h, s, l = c.hsl()
                if cmd in ("lighten", "darken"):
                    l = max(0, min(1, l + (amt if cmd == "lighten" else -amt)))
                elif cmd in ("saturate", "desaturate"):
                    s = max(0, min(1, s + (amt if cmd == "saturate" else -amt)))
                else:
                    h += amt
                out.append(output_color(Color.from_hsl(h, s, l, c.a)))
            print_lines(out)
        elif cmd == "textcolor":
            print_lines([output_color(Color(0, 0, 0) if luminance(c) > 0.179 else Color(255, 255, 255)) for c in read_colors(args)])
        elif cmd == "to-gray":
            print_lines([output_color(relative_gray(c)) for c in read_colors(args)])
        elif cmd == "set":
            prop, val = args[0], float(args[1])
            out = []
            for c in read_colors(args[2:]):
                h, s, l = c.hsl()
                if prop in ("red", "green", "blue"):
                    out.append(Color(val if prop == "red" else c.r, val if prop == "green" else c.g, val if prop == "blue" else c.b, c.a))
                elif prop in ("hsl-hue", "hue"):
                    out.append(Color.from_hsl(val, s, l, c.a))
                elif prop in ("hsl-saturation",):
                    out.append(Color.from_hsl(h, val, l, c.a))
                elif prop in ("hsl-lightness", "lightness"):
                    out.append(Color.from_hsl(h, s, val, c.a))
                elif prop == "alpha":
                    nc = Color(c.r, c.g, c.b, pct_value(val)); out.append(nc)
                else:
                    out.append(c)
            print_lines([output_color(c) for c in out])
        elif cmd == "mix":
            opts, rest = split_opts(args)
            base = parse_color(rest[0])
            frac = opts.get("fraction", 0.5)
            space = opts.get("colorspace", "Lab")
            print_lines([output_color(interp(parse_color(x), base, frac, space)) for x in rest[1:]])
        elif cmd == "gradient":
            opts, rest = split_opts(args)
            n = opts.get("number", 10)
            space = opts.get("colorspace", "Lab")
            stops = [parse_color(x) for x in rest]
            out = []
            for i in range(n):
                p = 0 if n == 1 else i / (n - 1)
                segf = p * (len(stops) - 1)
                j = min(len(stops) - 2, int(math.floor(segf)))
                out.append(output_color(interp(stops[j], stops[j + 1], segf - j, space)))
            print_lines(out)
        elif cmd == "sort-by":
            opts, rest = split_opts(args)
            order = rest[0] if rest and rest[0] in ("brightness", "luminance", "hue", "chroma", "random") else "hue"
            color_args = rest[1:] if rest and rest[0] in ("brightness", "luminance", "hue", "chroma", "random") else rest
            colors = read_colors(color_args)
            key = lambda c: {"brightness": brightness(c), "luminance": luminance(c), "hue": c.hsl()[0], "chroma": c.hsl()[1], "random": random.random()}[order]
            if opts.get("unique"):
                seen = set(); colors = [c for c in colors if not ((c.r,c.g,c.b) in seen or seen.add((c.r,c.g,c.b)))]
            colors.sort(key=key, reverse=opts.get("reverse", False))
            print_lines([output_color(c) for c in colors])
        elif cmd == "paint":
            opts, rest = split_opts(args)
            c = parse_color(rest[0])
            text = " ".join(rest[1:]) if len(rest) > 1 else sys.stdin.read()
            if force:
                codes = []
                codes.append(f"38;2;{c.r};{c.g};{c.b}")
                if "on" in opts:
                    bg = parse_color(opts["on"]); codes.append(f"48;2;{bg.r};{bg.g};{bg.b}")
                if opts.get("bold"): codes.append("1")
                if opts.get("italic"): codes.append("3")
                if opts.get("underline"): codes.append("4")
                sys.stdout.write(f"\x1b[{';'.join(codes)}m{text}\x1b[0m")
            else:
                sys.stdout.write(text)
            if not opts.get("no_newline"):
                sys.stdout.write("\n")
        elif cmd == "list":
            print_lines(LIST_ORDER)
        elif cmd == "random":
            opts, rest = split_opts(args)
            n = opts.get("number", 10)
            print_lines([output_color(Color(random.randrange(256), random.randrange(256), random.randrange(256)), "hex") for _ in range(n)])
        elif cmd == "distinct":
            n = int(args[0]) if args and args[0].isdigit() else 10
            print_lines([output_color(Color.from_hsl(i * 360 / n, 1, 0.5)) for i in range(n)])
        elif cmd == "colorblind":
            exact = {
                "prot": {
                    (255,0,0):(126,111,0), (0,128,0):(129,115,4), (0,0,255):(0,4,255),
                    (255,255,255):(255,250,255), (0,0,0):(0,0,0), (255,128,0):(175,155,0),
                },
                "deuter": {
                    (255,0,0):(167,150,0), (0,128,0):(114,102,20), (0,0,255):(0,8,255),
                    (255,255,255):(255,246,255), (0,0,0):(0,0,0), (255,128,0):(197,177,0),
                },
                "trit": {
                    (255,0,0):(255,0,25), (0,128,0):(45,121,117), (0,0,255):(0,100,97),
                    (255,255,255):(254,255,250), (0,0,0):(0,0,0), (255,128,0):(255,120,120),
                },
            }
            matrices = {
                "prot": ((0.567,0.433,0),(0.558,0.442,0),(0,0.242,0.758)),
                "deuter": ((0.625,0.375,0),(0.7,0.3,0),(0,0.3,0.7)),
                "trit": ((0.95,0.05,0),(0,0.433,0.567),(0,0.475,0.525)),
            }
            m = matrices.get(args[0], matrices["prot"])
            out = []
            for c in read_colors(args[1:]):
                if (c.r, c.g, c.b) in exact.get(args[0], {}):
                    out.append(Color(*exact[args[0]][(c.r, c.g, c.b)]))
                else:
                    out.append(Color(c.r*m[0][0]+c.g*m[0][1]+c.b*m[0][2], c.r*m[1][0]+c.g*m[1][1]+c.b*m[1][2], c.r*m[2][0]+c.g*m[2][1]+c.b*m[2][2]))
            print_lines([output_color(c) for c in out])
        elif cmd == "color":
            for c in read_colors(args):
                print(output_color(c, "hex"))
                print(output_color(c, "rgb"))
                print(output_color(c, "hsl"))
        elif cmd == "colorcheck":
            print("24-bit color test")
        elif cmd == "pick":
            print("No suitable color picker has been found")
            return 1
        else:
            sys.stderr.write(f"error: unrecognized subcommand '{cmd}'\n")
            return 2
    except Exception as e:
        sys.stderr.write(f"error: {e}\n")
        return 1
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
