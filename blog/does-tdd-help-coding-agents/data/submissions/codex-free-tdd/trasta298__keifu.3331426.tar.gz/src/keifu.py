#!/usr/bin/env python3
import os
import select
import shutil
import subprocess
import sys
import termios
import tty
from dataclasses import dataclass


HELP = """A TUI tool to visualize Git commit graphs with branch genealogy

Usage: executable

Options:
  -h, --help     Print help
  -V, --version  Print version
"""


def in_git_repository() -> bool:
    result = subprocess.run(
        ["git", "rev-parse", "--git-dir"],
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL,
    )
    return result.returncode == 0


@dataclass
class Commit:
    full_hash: str
    short_hash: str
    date: str
    author: str
    email: str
    subject: str
    refs: str


def git_output(args):
    return subprocess.check_output(["git", *args], text=True, stderr=subprocess.DEVNULL)


def current_branch():
    try:
        branch = git_output(["branch", "--show-current"]).strip()
        if branch:
            return branch
    except subprocess.CalledProcessError:
        pass
    try:
        return git_output(["rev-parse", "--short", "HEAD"]).strip()
    except subprocess.CalledProcessError:
        return "detached"


def repo_name():
    try:
        root = git_output(["rev-parse", "--show-toplevel"]).strip()
        return os.path.basename(root) or root
    except subprocess.CalledProcessError:
        return os.path.basename(os.getcwd())


def list_commits():
    fmt = "%H%x1f%h%x1f%ad%x1f%an%x1f%ae%x1f%s%x1f%D"
    raw = git_output(["log", "--all", "--date=short", f"--pretty=format:{fmt}", "-n", "500"])
    commits = []
    for line in raw.splitlines():
        parts = line.split("\x1f")
        if len(parts) < 7:
            continue
        commits.append(Commit(*parts[:7]))
    try:
        head = git_output(["rev-parse", "HEAD"]).strip()
    except subprocess.CalledProcessError:
        head = ""
    commits.sort(key=lambda commit: 0 if commit.full_hash == head else 1)
    return commits


def clean_ref_name(ref):
    ref = ref.strip()
    for prefix in ("HEAD -> ", "tag: ", "origin/"):
        if ref.startswith(prefix):
            ref = ref[len(prefix) :]
    return ref


def labels_for(commit):
    labels = []
    for ref in commit.refs.split(","):
        ref = clean_ref_name(ref)
        if ref and ref != "HEAD":
            labels.append(ref)
    return labels


def changed_files(commit_hash):
    try:
        raw = git_output(["show", "--numstat", "--format=", "--find-renames", commit_hash])
    except subprocess.CalledProcessError:
        return []
    files = []
    for line in raw.splitlines():
        parts = line.split("\t")
        if len(parts) >= 3 and parts[0] != "-" and parts[1] != "-":
            files.append((int(parts[0]), int(parts[1]), parts[2]))
    return files[:50]


def full_commit_date(commit_hash):
    try:
        return git_output(["show", "-s", "--date=format:%Y-%m-%d %H:%M:%S", "--format=%ad", commit_hash]).strip()
    except subprocess.CalledProcessError:
        return ""


def parent_summary(commit_hash):
    try:
        parents = git_output(["show", "-s", "--format=%P", commit_hash]).strip().split()
    except subprocess.CalledProcessError:
        return ""
    return ", ".join(parent[:7] for parent in parents) if parents else "None"


def has_uncommitted_changes():
    try:
        raw = git_output(["status", "--porcelain"])
    except subprocess.CalledProcessError:
        return False
    return any(line and not line.startswith("??") for line in raw.splitlines())


def fit(text, width):
    if width <= 0:
        return ""
    return text if len(text) <= width else text[: max(0, width - 1)] + "…"


def frame_line(title, width):
    label = f" {title} "
    return "┌" + label + "─" * max(0, width - len(label) - 2) + "┐"


def bottom_line(width):
    left = f" {repo_name()}  {current_branch()}  j/k move  Enter checkout  b branch  f fetch  ? help  q quit"
    return fit(left, width)


def render_screen():
    width, height = shutil.get_terminal_size((120, 30))
    commits = list_commits()
    selected = commits[0] if commits else None
    lines = [frame_line("Commits", width)]

    if has_uncommitted_changes():
        lines.append("│ ◉    uncommitted changes".ljust(width - 1) + "│")

    colors = ["◉", "●", "●", "◆", "■"]
    for idx, commit in enumerate(commits[: max(1, height - 11)]):
        labels = labels_for(commit)
        label_text = ""
        if labels:
            label_text = f"[{labels[0]}]"
            if len(labels) > 1:
                label_text += f" +{len(labels) - 1}"
        graph = colors[idx % len(colors)]
        row = f"│ {graph}    {label_text} {commit.subject}"
        meta = f"{commit.date}  {commit.author[:7]:<7}  {commit.short_hash}"
        row = fit(row, max(1, width - len(meta) - 2)).ljust(max(1, width - len(meta) - 1)) + meta + "│"
        lines.append(row[:width])

    while len(lines) < max(6, height - 10):
        lines.append("│" + " " * (width - 2) + "│")
    lines.append("└" + "─" * (width - 2) + "┘")

    half = max(30, width // 2)
    lines.append("┌ Commit Detail " + "─" * max(0, half - 17) + "┐" + "┌ Changed Files " + "─" * max(0, width - half - 17) + "┐")
    if selected:
        files = changed_files(selected.full_hash)
        plus = sum(f[0] for f in files)
        minus = sum(f[1] for f in files)
        detail = [
            f"Commit: {selected.full_hash}",
            f"Author: {selected.author} <{selected.email}>",
            f"Date:   {full_commit_date(selected.full_hash)}",
            f"Parent: {parent_summary(selected.full_hash)}",
            "",
            selected.subject,
        ]
        changed = [f"{len(files)} files changed  +{plus} -{minus}", ""]
        for add, delete, path in files[:8]:
            changed.append(f" A {path} +{add} -{delete}")
    else:
        detail = ["No commits"]
        changed = []
    panel_rows = max(7, min(10, height - len(lines) - 2))
    for i in range(panel_rows):
        left_text = detail[i] if i < len(detail) else ""
        right_text = changed[i] if i < len(changed) else ""
        left = "│" + fit(left_text, half - 2).ljust(half - 2) + "│"
        right_width = width - len(left) - 1
        right = "│" + fit(right_text, right_width - 1).ljust(max(0, right_width - 1)) + "│"
        lines.append((left + right)[:width])
    lines.append("└" + "─" * (half - 2) + "┘" + "└" + "─" * max(0, width - half - 2) + "┘")
    lines.append(bottom_line(width))
    return "\n".join(lines) + "\n"


def run_tui():
    use_alt = sys.stdin.isatty() and sys.stdout.isatty()
    if use_alt:
        sys.stdout.write("\033[?1049h\033[?25l\033[1;1H")
    sys.stdout.write(render_screen())
    sys.stdout.flush()

    if use_alt:
        old = termios.tcgetattr(sys.stdin.fileno())
        try:
            tty.setcbreak(sys.stdin.fileno())
            while True:
                ready, _, _ = select.select([sys.stdin], [], [], 10)
                if ready:
                    ch = sys.stdin.read(1)
                    if ch in ("q", "\x1b"):
                        break
                    if ch == "?":
                        sys.stdout.write("\033[1;1H" + render_screen() + "Help  q/Esc quit\n")
                        sys.stdout.flush()
        finally:
            termios.tcsetattr(sys.stdin.fileno(), termios.TCSADRAIN, old)
            sys.stdout.write("\033[?1049l\033[?25h")
            sys.stdout.flush()
    else:
        try:
            ready, _, _ = select.select([sys.stdin], [], [], 0.05)
            if ready:
                sys.stdin.read(1)
        except Exception:
            pass
    return 0


def main(argv):
    if argv in (["-h"], ["--help"]):
        sys.stdout.write(HELP)
        return 0
    if argv in (["-V"], ["--version"]):
        sys.stdout.write("keifu 0.2.3\n")
        return 0
    if argv:
        sys.stdout.write(
            f"error: unexpected argument '{argv[0]}' found\n"
            "\n"
            "Usage: executable\n"
            "\n"
            "For more information, try '--help'.\n"
        )
        return 2

    if not in_git_repository():
        sys.stdout.write(
            "Error: Git repository not found. Please run inside a Git repository.\n"
            "\n"
            "Caused by:\n"
            "    could not find repository at '.'; class=Repository (6); code=NotFound (-3)\n"
        )
        return 1
    return run_tui()


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
