import os
import subprocess
import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
APP = ROOT / "src" / "keifu.py"


def run_app(args=(), cwd=None, env=None):
    merged_env = os.environ.copy()
    if env:
        merged_env.update(env)
    return subprocess.run(
        ["python3", str(APP), *args],
        cwd=cwd or ROOT,
        env=merged_env,
        text=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
    )


class CliTests(unittest.TestCase):
    def test_help_matches_documented_cli(self):
        result = run_app(["--help"])

        self.assertEqual(result.returncode, 0)
        self.assertEqual(
            result.stdout,
            "A TUI tool to visualize Git commit graphs with branch genealogy\n"
            "\n"
            "Usage: executable\n"
            "\n"
            "Options:\n"
            "  -h, --help     Print help\n"
            "  -V, --version  Print version\n",
        )

    def test_version_matches_reference(self):
        result = run_app(["--version"])

        self.assertEqual(result.returncode, 0)
        self.assertEqual(result.stdout, "keifu 0.2.3\n")

    def test_unexpected_argument_uses_clap_style_message(self):
        result = run_app(["foo"])

        self.assertEqual(result.returncode, 2)
        self.assertEqual(
            result.stdout,
            "error: unexpected argument 'foo' found\n"
            "\n"
            "Usage: executable\n"
            "\n"
            "For more information, try '--help'.\n",
        )

    def test_outside_git_repository_reports_not_found(self):
        import tempfile

        with tempfile.TemporaryDirectory() as tmp:
            result = run_app(cwd=tmp)

        self.assertEqual(result.returncode, 1)
        self.assertIn(
            "Error: Git repository not found. Please run inside a Git repository.",
            result.stdout,
        )
        self.assertIn("could not find repository at '.'", result.stdout)


if __name__ == "__main__":
    unittest.main()
