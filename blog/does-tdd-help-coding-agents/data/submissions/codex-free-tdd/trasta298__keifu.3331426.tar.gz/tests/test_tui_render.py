import os
import subprocess
import tempfile
import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
APP = ROOT / "src" / "keifu.py"


def git(repo, *args):
    subprocess.run(["git", *args], cwd=repo, check=True, stdout=subprocess.PIPE)


def make_repo():
    tmp = tempfile.TemporaryDirectory()
    repo = Path(tmp.name)
    git(repo, "init", "-q")
    git(repo, "config", "user.email", "a@example.com")
    git(repo, "config", "user.name", "Alice")
    (repo / "a.txt").write_text("one\n")
    git(repo, "add", "a.txt")
    git(repo, "commit", "-q", "-m", "initial commit")
    (repo / "a.txt").write_text("one\ntwo\n")
    git(repo, "commit", "-am", "second commit", "-q")
    git(repo, "checkout", "-q", "-b", "feature")
    (repo / "f.txt").write_text("feature\n")
    git(repo, "add", "f.txt")
    git(repo, "commit", "-q", "-m", "feature work")
    git(repo, "checkout", "-q", "master")
    (repo / "m.txt").write_text("main\n")
    git(repo, "add", "m.txt")
    git(repo, "commit", "-q", "-m", "main work")
    return tmp, repo


class TuiRenderTests(unittest.TestCase):
    def test_repository_view_lists_commits_and_selected_commit_details(self):
        tmp, repo = make_repo()
        self.addCleanup(tmp.cleanup)
        env = os.environ.copy()
        env["TERM"] = "xterm-256color"

        result = subprocess.run(
            ["python3", str(APP)],
            cwd=repo,
            env=env,
            input="q",
            text=True,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            timeout=5,
        )

        self.assertEqual(result.returncode, 0)
        output = result.stdout
        self.assertIn("┌ Commits ", output)
        self.assertIn("[master]", output)
        self.assertIn("[feature]", output)
        self.assertIn("main work", output)
        self.assertIn("feature work", output)
        self.assertIn("Commit Detail", output)
        self.assertIn("Author: Alice <a@example.com>", output)
        self.assertIn("Changed Files", output)
        self.assertIn("m.txt", output)
        self.assertIn("j/k", output)
        self.assertIn("checkout", output)


if __name__ == "__main__":
    unittest.main()
