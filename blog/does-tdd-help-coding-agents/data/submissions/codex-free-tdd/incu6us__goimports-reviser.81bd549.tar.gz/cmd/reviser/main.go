package main

import (
	"bytes"
	"flag"
	"fmt"
	"go/ast"
	"go/format"
	"go/parser"
	"go/token"
	"io/fs"
	"log"
	"os"
	"path/filepath"
	"regexp"
	"sort"
	"strconv"
	"strings"
)

type config struct {
	projectName           string
	companyPrefixes       []string
	importsOrder          []string
	output                string
	filePath              string
	excludes              []string
	recursive             bool
	format                bool
	rmUnused              bool
	setAlias              bool
	listDiff              bool
	setExitStatus         bool
	separateNamed         bool
	applyGenerated        bool
	useCache              bool
	version               bool
	versionOnly           bool
}

type importSpec struct {
	alias   string
	path    string
	comment string
	named   bool
}

func main() {
	log.SetFlags(log.LstdFlags)
	cfg := parseFlags()
	if cfg.versionOnly {
		fmt.Println("3.0.0-20260303205914-9926ea38658f")
		return
	}
	if cfg.version {
		fmt.Println("version: 3.0.0-20260303205914-9926ea38658f")
		fmt.Println("built with: go1.26.0")
		fmt.Println("tag: v3.0.0-20260303205914-9926ea38658f")
		fmt.Println("commit: n/a")
		fmt.Println("source: github.com/incu6us/goimports-reviser/v3")
		return
	}
	targets := flag.Args()
	if cfg.filePath != "" {
		targets = append(targets, cfg.filePath)
	}
	if len(targets) == 0 {
		flag.Usage()
		return
	}
	paths, err := collectPaths(targets, cfg)
	if err != nil {
		log.Fatal(err)
	}
	log.Printf("Paths: %v", targets)
	changed := false
	for _, path := range paths {
		log.Printf("Processing %s", path)
		didChange, err := processFile(path, cfg)
		if err != nil {
			log.Fatalf("Failed to fix file: %v", err)
		}
		if didChange {
			changed = true
			if cfg.listDiff {
				fmt.Println(path)
			}
		}
	}
	if changed && cfg.setExitStatus {
		os.Exit(1)
	}
}

func parseFlags() config {
	cfg := config{importsOrder: []string{"std", "general", "company", "project"}, output: "file"}
	var company, order, excludes, local string
	flag.StringVar(&company, "company-prefixes", "", "Company package prefixes which will be placed after 3rd-party group by default(if defined). Values should be comma-separated. Optional parameters.")
	flag.StringVar(&excludes, "excludes", "", "Exclude files or dirs, example: '.git/,proto/*.go'.")
	flag.StringVar(&cfg.filePath, "file-path", "", "Deprecated. Put file name as an argument(last item) of command line.")
	flag.BoolVar(&cfg.format, "format", false, "Option will perform additional formatting. Optional parameter.")
	flag.StringVar(&order, "imports-order", "std,general,company,project", "Your imports groups can be sorted in your way.")
	flag.StringVar(&local, "local", "", "Deprecated")
	flag.StringVar(&cfg.output, "output", "file", `Can be "file", "write" or "stdout". Whether to write the formatted content back to the file or to stdout.`)
	flag.StringVar(&cfg.projectName, "project-name", "", "Your project name(ex.: github.com/incu6us/goimports-reviser). Optional parameter.")
	flag.BoolVar(&cfg.recursive, "recursive", false, "Apply rules recursively if target is a directory.")
	flag.BoolVar(&cfg.rmUnused, "rm-unused", false, "Remove unused imports. Optional parameter.")
	flag.BoolVar(&cfg.separateNamed, "separate-named", false, "Option will separate named imports from the rest of the imports, per group. Optional parameter.")
	flag.BoolVar(&cfg.setAlias, "set-alias", false, "Set alias for versioned package names.")
	flag.BoolVar(&cfg.setExitStatus, "set-exit-status", false, "set the exit status to 1 if a change is needed/made. Optional parameter.")
	flag.BoolVar(&cfg.useCache, "use-cache", false, "Use cache to improve performance. Optional parameter.")
	flag.BoolVar(&cfg.listDiff, "list-diff", false, "Option will list files whose formatting differs from goimports-reviser. Optional parameter.")
	flag.BoolVar(&cfg.applyGenerated, "apply-to-generated-files", false, "Apply imports sorting and formatting(if the option is set) to generated files.")
	flag.BoolVar(&cfg.version, "version", false, "Show version information")
	flag.BoolVar(&cfg.versionOnly, "version-only", false, "Show only the version string")
	flag.Parse()
	_ = local
	cfg.companyPrefixes = splitCSV(company)
	cfg.importsOrder = splitCSV(order)
	cfg.excludes = splitCSV(excludes)
	return cfg
}

func splitCSV(s string) []string {
	var out []string
	for _, p := range strings.Split(s, ",") {
		p = strings.TrimSpace(p)
		if p != "" {
			out = append(out, p)
		}
	}
	return out
}

func collectPaths(targets []string, cfg config) ([]string, error) {
	seen := map[string]bool{}
	var paths []string
	add := func(p string) {
		if !seen[p] && strings.HasSuffix(p, ".go") && !isExcluded(p, cfg.excludes) {
			seen[p] = true
			paths = append(paths, p)
		}
	}
	for _, target := range targets {
		if target == "./..." {
			target = "."
			cfg.recursive = true
		} else if strings.HasSuffix(target, "/...") {
			target = strings.TrimSuffix(target, "/...")
			cfg.recursive = true
		}
		info, err := os.Stat(target)
		if err != nil {
			add(target)
			continue
		}
		if !info.IsDir() {
			add(target)
			continue
		}
		if cfg.recursive {
			err = filepath.WalkDir(target, func(path string, d fs.DirEntry, err error) error {
				if err != nil {
					return err
				}
				if d.IsDir() {
					base := filepath.Base(path)
					if base == ".git" || base == "vendor" || isExcluded(path+"/", cfg.excludes) {
						return filepath.SkipDir
					}
					return nil
				}
				add(path)
				return nil
			})
			if err != nil {
				return nil, err
			}
		} else {
			matches, err := filepath.Glob(filepath.Join(target, "*.go"))
			if err != nil {
				return nil, err
			}
			for _, m := range matches {
				add(m)
			}
		}
	}
	sort.Strings(paths)
	return paths, nil
}

func isExcluded(path string, patterns []string) bool {
	clean := filepath.ToSlash(path)
	for _, p := range patterns {
		p = filepath.ToSlash(p)
		if strings.HasSuffix(p, "/") && strings.Contains(clean+"/", p) {
			return true
		}
		if ok, _ := filepath.Match(p, clean); ok {
			return true
		}
		if strings.Contains(clean, p) {
			return true
		}
	}
	return false
}

func processFile(path string, cfg config) (bool, error) {
	src, err := os.ReadFile(path)
	if err != nil {
		return false, err
	}
	if !cfg.applyGenerated && isGenerated(src) {
		if cfg.output == "stdout" {
			_, err = os.Stdout.Write(src)
			return false, err
		}
		return false, nil
	}
	out, err := revise(src, cfg)
	if err != nil {
		return false, err
	}
	changed := !bytes.Equal(src, out)
	if cfg.output == "stdout" {
		_, err = os.Stdout.Write(out)
		return changed, err
	}
	if changed && !cfg.listDiff {
		if err := os.WriteFile(path, out, 0644); err != nil {
			return false, err
		}
	}
	if changed && cfg.listDiff && cfg.output == "write" {
		if err := os.WriteFile(path, out, 0644); err != nil {
			return false, err
		}
	}
	return changed, nil
}

func isGenerated(src []byte) bool {
	for _, line := range strings.Split(string(src), "\n") {
		t := strings.TrimSpace(line)
		if t == "" {
			continue
		}
		return strings.HasPrefix(t, "// Code generated")
	}
	return false
}

func revise(src []byte, cfg config) ([]byte, error) {
	fset := token.NewFileSet()
	file, err := parser.ParseFile(fset, "src.go", src, parser.ParseComments)
	if err != nil {
		if cfg.format {
			return format.Source(src)
		}
		return nil, err
	}
	var decls []*ast.GenDecl
	for _, decl := range file.Decls {
		if g, ok := decl.(*ast.GenDecl); ok && g.Tok == token.IMPORT {
			decls = append(decls, g)
		}
	}
	out := src
	if len(decls) > 0 {
		specs := extractImports(src, fset, decls)
		if cfg.rmUnused {
			specs = filterUnused(specs, src, fset, decls)
		}
		for i := range specs {
			if cfg.setAlias && specs[i].alias == "" {
				if alias := versionAlias(specs[i].path); alias != "" {
					specs[i].alias = alias
					specs[i].named = true
				}
			}
		}
		start := fset.Position(decls[0].Pos()).Offset
		end := fset.Position(decls[len(decls)-1].End()).Offset
		block := renderImportBlock(specs, cfg, forceImportBlock(decls))
		replaced := make([]byte, 0, len(src)+len(block))
		replaced = append(replaced, src[:start]...)
		replaced = append(replaced, block...)
		if end < len(src) && src[end] == '\n' && (end+1 >= len(src) || src[end+1] != '\n') {
			replaced = append(replaced, '\n')
		}
		replaced = append(replaced, src[end:]...)
		out = replaced
	}
	if cfg.format {
		if formatted, err := format.Source(out); err == nil {
			out = formatted
		}
		out = separateTopLevelFuncs(out)
	}
	return out, nil
}

func separateTopLevelFuncs(src []byte) []byte {
	re := regexp.MustCompile(`(?m)^}\nfunc `)
	return re.ReplaceAll(src, []byte("}\n\nfunc "))
}

func extractImports(src []byte, fset *token.FileSet, decls []*ast.GenDecl) []importSpec {
	var specs []importSpec
	for _, decl := range decls {
		for _, raw := range decl.Specs {
			s := raw.(*ast.ImportSpec)
			path, _ := strconv.Unquote(s.Path.Value)
			alias := ""
			named := false
			if s.Name != nil {
				alias = s.Name.Name
				named = alias != "_" && alias != "."
			}
			comment := ""
			if s.Comment != nil {
				var parts []string
				for _, c := range s.Comment.List {
					start := fset.Position(c.Pos()).Offset
					end := fset.Position(c.End()).Offset
					if start >= 0 && end <= len(src) && start < end {
						parts = append(parts, string(src[start:end]))
					}
				}
				comment = strings.Join(parts, " ")
			}
			specs = append(specs, importSpec{alias: alias, path: path, comment: comment, named: named})
		}
	}
	return specs
}

func filterUnused(specs []importSpec, src []byte, fset *token.FileSet, decls []*ast.GenDecl) []importSpec {
	start := fset.Position(decls[0].Pos()).Offset
	end := fset.Position(decls[len(decls)-1].End()).Offset
	body := string(src[:start]) + string(src[end:])
	used := map[string]bool{}
	ast.Inspect(mustParseBody(body), func(n ast.Node) bool {
		if id, ok := n.(*ast.Ident); ok {
			used[id.Name] = true
		}
		return true
	})
	var out []importSpec
	for _, s := range specs {
		if s.alias == "_" || s.alias == "." {
			out = append(out, s)
			continue
		}
		name := s.alias
		if name == "" {
			name = defaultPackageName(s.path)
		}
		if used[name] {
			out = append(out, s)
		}
	}
	return out
}

func mustParseBody(src string) *ast.File {
	f, _ := parser.ParseFile(token.NewFileSet(), "body.go", []byte(src), 0)
	if f == nil {
		return &ast.File{}
	}
	return f
}

func forceImportBlock(decls []*ast.GenDecl) bool {
	if len(decls) != 1 {
		return true
	}
	return decls[0].Lparen.IsValid()
}

func renderImportBlock(specs []importSpec, cfg config, forceBlock bool) []byte {
	if len(specs) == 0 {
		return nil
	}
	groups := map[string][]importSpec{}
	for _, s := range specs {
		groups[classify(s, cfg)] = append(groups[classify(s, cfg)], s)
	}
	var ordered [][]importSpec
	for _, name := range cfg.importsOrder {
		group := groups[name]
		delete(groups, name)
		if len(group) == 0 {
			continue
		}
		sortImports(group)
		if cfg.separateNamed {
			plain, named := splitNamed(group)
			if len(plain) > 0 {
				ordered = append(ordered, plain)
			}
			if len(named) > 0 {
				ordered = append(ordered, named)
			}
		} else {
			ordered = append(ordered, group)
		}
	}
	for _, name := range []string{"std", "general", "company", "project", "blanked", "dotted"} {
		if group := groups[name]; len(group) > 0 {
			sortImports(group)
			ordered = append(ordered, group)
		}
	}
	if len(specs) == 1 && !forceBlock {
		return []byte("import " + renderSpec(specs[0]))
	}
	var b strings.Builder
	b.WriteString("import (\n")
	for gi, group := range ordered {
		if gi > 0 {
			b.WriteString("\n")
		}
		for _, s := range group {
			b.WriteString("\t")
			b.WriteString(renderSpec(s))
			b.WriteString("\n")
		}
	}
	b.WriteString(")")
	return []byte(b.String())
}

func classify(s importSpec, cfg config) string {
	if s.alias == "_" {
		return "blanked"
	}
	if s.alias == "." {
		return "dotted"
	}
	first := strings.Split(s.path, "/")[0]
	if !strings.Contains(first, ".") {
		return "std"
	}
	if cfg.projectName != "" && (s.path == cfg.projectName || strings.HasPrefix(s.path, cfg.projectName+"/")) {
		return "project"
	}
	for _, prefix := range cfg.companyPrefixes {
		if s.path == prefix || strings.HasPrefix(s.path, prefix+"/") {
			return "company"
		}
	}
	return "general"
}

func splitNamed(group []importSpec) ([]importSpec, []importSpec) {
	var plain, named []importSpec
	for _, s := range group {
		if s.named {
			named = append(named, s)
		} else {
			plain = append(plain, s)
		}
	}
	return plain, named
}

func sortImports(specs []importSpec) {
	sort.SliceStable(specs, func(i, j int) bool {
		return specs[i].path < specs[j].path
	})
}

func renderSpec(s importSpec) string {
	prefix := ""
	if s.alias != "" {
		prefix = s.alias + " "
	}
	line := prefix + strconv.Quote(s.path)
	if s.comment != "" {
		line += " " + strings.TrimSpace(s.comment)
	}
	return line
}

func versionAlias(path string) string {
	parts := strings.Split(path, "/")
	if len(parts) < 2 {
		return ""
	}
	last := parts[len(parts)-1]
	if matched, _ := regexp.MatchString(`^v[0-9]+$`, last); !matched {
		return ""
	}
	return defaultPackageName(parts[len(parts)-2])
}

func defaultPackageName(path string) string {
	base := path
	if strings.Contains(base, "/") {
		parts := strings.Split(base, "/")
		base = parts[len(parts)-1]
	}
	if matched, _ := regexp.MatchString(`^v[0-9]+$`, base); matched && strings.Contains(path, "/") {
		parts := strings.Split(path, "/")
		base = parts[len(parts)-2]
	}
	base = strings.ReplaceAll(base, "-", "_")
	return strings.Trim(base, ".")
}
