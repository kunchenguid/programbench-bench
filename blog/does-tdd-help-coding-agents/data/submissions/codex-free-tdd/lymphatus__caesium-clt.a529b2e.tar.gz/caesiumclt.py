#!/usr/bin/env python3
import os
import shutil
import sys
from io import BytesIO
from pathlib import Path


VERSION = "caesiumclt 1.3.0"
FORMATS = {"jpeg", "png", "gif", "webp", "tiff", "original"}
OVERWRITE = {"all", "never", "bigger"}
CHROMA = {"4:4:4", "4:2:2", "4:2:0", "4:1:1", "auto"}


def eprint(text):
    sys.stdout.write(text)
    if not text.endswith("\n"):
        sys.stdout.write("\n")


def usage(full=False):
    if full:
        return """A fast and efficient lossy and/or lossless image compression tool

Usage: executable [OPTIONS] <--quality <QUALITY>|--lossless|--max-size <MAX_SIZE>> <--output <OUTPUT>|--same-folder-as-input> [FILES]...

Arguments:
  [FILES]...  Input files or directories to process

Options:
  -q, --quality <QUALITY>
          Compression quality [0-100], higher values mean better quality
      --lossless
          Use lossless compression (may increase file size for some formats)
      --max-size <MAX_SIZE>
          Target maximum file size in bytes or human-readable format (e.g., 100KB, 0.5MB)
      --width <WIDTH>
          Output image width in pixels (preserves the aspect ratio if height not set)
      --height <HEIGHT>
          Output image height in pixels (preserves the aspect ratio if width not set)
      --long-edge <LONG_EDGE>
          Size in pixels for the longest edge of the image
      --short-edge <SHORT_EDGE>
          Size in pixels for the shortest edge of the image
      --no-upscale
          Prevents upscaling of the image when resizing
  -o, --output <OUTPUT>
          Output directory path
      --same-folder-as-input
          Use input file's directory as output (WARNING: may overwrite originals)
      --format <FORMAT>
          Convert to the selected output format or keep the original [default: original] [possible values: jpeg, png, gif, webp, tiff, original]
      --png-opt-level <PNG_OPT_LEVEL>
          PNG optimization level [0-6], higher values provide better compression [default: 3]
      --jpeg-chroma-subsampling <JPEG_CHROMA_SUBSAMPLING>
          Chroma subsampling for JPEG files [default: auto] [possible values: 4:4:4, 4:2:2, 4:2:0, 4:1:1, auto]
      --jpeg-baseline
          Output baseline JPEG instead of progressive (default)
      --zopfli
          Use zopfli for PNG optimization (significantly slower but better compression)
  -e, --exif
          Keep EXIF metadata during compression
      --keep-dates
          Preserve original file timestamps
      --strip-icc
          Strips ICC profile info on JPG files, ignoring the -e flag
      --suffix <SUFFIX>
          Add suffix to output filenames
  -R, --recursive
          Scan subfolders recursively when input is a directory
  -S, --keep-structure
          Preserve directory structure (requires -R/--recursive)
  -d, --dry-run
          Simulate compression without writing files
      --threads <THREADS>
          Number of parallel jobs (0 = auto-detect, max = available processors) [default: 0]
  -O, --overwrite <OVERWRITE>
          Policy for handling existing output files [default: all] [possible values: all, never, bigger]
      --min-savings <MIN_SAVINGS>
          Minimum compression savings required to write an output file. Use percentage (e.g., '10%', '1.5%'), absolute size (e.g., '100KB', '1MB'), or plain number as bytes
  -Q, --quiet
          Suppress all output
      --verbose <VERBOSE>
          Verbosity level: 0 = quiet, 1 = progress only, 2 = errors only, 3 = all [default: 1]
  -h, --help
          Print help (see more with '--help')
  -V, --version
          Print version
"""
    return """A fast and efficient lossy and/or lossless image compression tool

Usage: executable [OPTIONS] <--quality <QUALITY>|--lossless|--max-size <MAX_SIZE>> <--output <OUTPUT>|--same-folder-as-input> [FILES]...
"""


def die_clap(message, usage_line=None):
    eprint(f"error: {message}\n")
    if usage_line:
        eprint(f"Usage: executable {usage_line}\n")
    eprint("For more information, try '--help'.")
    return 2


def parse_int(name, value):
    try:
        if value.startswith("-"):
            raise ValueError
        return int(value)
    except Exception:
        raise ValueError(f"invalid value '{value}' for '{name}'")


def parse_args(argv):
    opts = {
        "quality": None,
        "lossless": False,
        "max_size": None,
        "output": None,
        "same_folder": False,
        "format": "original",
        "suffix": "",
        "recursive": False,
        "keep_structure": False,
        "dry_run": False,
        "quiet": False,
        "verbose": "1",
        "overwrite": "all",
        "width": None,
        "height": None,
        "long_edge": None,
        "short_edge": None,
        "no_upscale": False,
        "png_opt_level": 3,
        "jpeg_baseline": False,
        "jpeg_chroma": "auto",
        "zopfli": False,
        "exif": False,
        "keep_dates": False,
        "strip_icc": False,
        "threads": 0,
        "min_savings": None,
        "files": [],
    }
    i = 0
    while i < len(argv):
        a = argv[i]
        if a in ("-h", "--help"):
            eprint(usage(a == "--help").rstrip("\n"))
            raise SystemExit(0)
        if a in ("-V", "--version"):
            eprint(VERSION)
            raise SystemExit(0)
        if a in ("-q", "--quality"):
            i += 1
            if i >= len(argv):
                return None, die_clap("a value is required for '--quality <QUALITY>'")
            try:
                q = parse_int("--quality <QUALITY>", argv[i])
            except ValueError:
                return None, die_clap(f"unexpected argument '{argv[i]}' found")
            if not 0 <= q <= 100:
                return None, die_clap(f"invalid value '{argv[i]}' for '--quality <QUALITY>': Quality must be between 0 and 100, but got {argv[i]}")
            opts["quality"] = q
        elif a == "--lossless":
            opts["lossless"] = True
        elif a == "--max-size":
            i += 1
            if i >= len(argv):
                return None, die_clap("a value is required for '--max-size <MAX_SIZE>'")
            opts["max_size"] = argv[i]
        elif a in ("-o", "--output"):
            i += 1
            if i >= len(argv):
                return None, die_clap("a value is required for '--output <OUTPUT>'")
            opts["output"] = argv[i]
        elif a == "--same-folder-as-input":
            opts["same_folder"] = True
        elif a == "--format":
            i += 1
            if i >= len(argv):
                return None, die_clap("a value is required for '--format <FORMAT>'")
            if argv[i] not in FORMATS:
                return None, die_clap(f"invalid value '{argv[i]}' for '--format <FORMAT>'\n  [possible values: jpeg, png, gif, webp, tiff, original]")
            opts["format"] = argv[i]
        elif a == "--suffix":
            i += 1
            if i >= len(argv):
                return None, die_clap("a value is required for '--suffix <SUFFIX>'")
            opts["suffix"] = argv[i]
        elif a in ("-R", "--recursive"):
            opts["recursive"] = True
        elif a in ("-S", "--keep-structure"):
            opts["keep_structure"] = True
        elif a in ("-d", "--dry-run"):
            opts["dry_run"] = True
        elif a in ("-Q", "--quiet"):
            opts["quiet"] = True
        elif a == "--verbose":
            i += 1
            if i >= len(argv):
                return None, die_clap("a value is required for '--verbose <VERBOSE>'")
            opts["verbose"] = argv[i]
        elif a in ("-O", "--overwrite"):
            i += 1
            if i >= len(argv):
                return None, die_clap("a value is required for '--overwrite <OVERWRITE>'")
            if argv[i] not in OVERWRITE:
                return None, die_clap(f"invalid value '{argv[i]}' for '--overwrite <OVERWRITE>'\n  [possible values: all, never, bigger]")
            opts["overwrite"] = argv[i]
        elif a in ("--width", "--height", "--long-edge", "--short-edge", "--threads", "--png-opt-level"):
            i += 1
            if i >= len(argv):
                return None, die_clap(f"a value is required for '{a}'")
            key = a[2:].replace("-", "_")
            try:
                opts[key] = parse_int(a, argv[i])
            except ValueError as exc:
                return None, die_clap(str(exc))
        elif a == "--jpeg-chroma-subsampling":
            i += 1
            if i >= len(argv):
                return None, die_clap("a value is required for '--jpeg-chroma-subsampling <JPEG_CHROMA_SUBSAMPLING>'")
            if argv[i] not in CHROMA:
                return None, die_clap(f"invalid value '{argv[i]}' for '--jpeg-chroma-subsampling <JPEG_CHROMA_SUBSAMPLING>'")
            opts["jpeg_chroma"] = argv[i]
        elif a == "--min-savings":
            i += 1
            if i >= len(argv):
                return None, die_clap("a value is required for '--min-savings <MIN_SAVINGS>'")
            opts["min_savings"] = argv[i]
        elif a == "--no-upscale":
            opts["no_upscale"] = True
        elif a == "--jpeg-baseline":
            opts["jpeg_baseline"] = True
        elif a == "--zopfli":
            opts["zopfli"] = True
        elif a in ("-e", "--exif"):
            opts["exif"] = True
        elif a == "--keep-dates":
            opts["keep_dates"] = True
        elif a == "--strip-icc":
            opts["strip_icc"] = True
        elif a.startswith("-"):
            return None, die_clap(f"unexpected argument '{a}' found")
        else:
            opts["files"].append(a)
        i += 1
    return opts, validate(opts)


def validate(opts):
    modes = int(opts["quality"] is not None) + int(opts["lossless"]) + int(opts["max_size"] is not None)
    dests = int(opts["output"] is not None) + int(opts["same_folder"])
    if modes != 1:
        if modes == 0:
            return die_clap("the following required arguments were not provided:\n  <--quality <QUALITY>|--lossless|--max-size <MAX_SIZE>>" + ("\n  <--output <OUTPUT>|--same-folder-as-input>" if dests == 0 else ""), "<--quality <QUALITY>|--lossless|--max-size <MAX_SIZE>> <--output <OUTPUT>|--same-folder-as-input> [FILES]...")
        return die_clap("the argument '--lossless' cannot be used with '--max-size <MAX_SIZE>'", "<--quality <QUALITY>|--lossless|--max-size <MAX_SIZE>> <--output <OUTPUT>|--same-folder-as-input> <FILES>...")
    if dests != 1:
        if dests == 0:
            return die_clap("the following required arguments were not provided:\n  <--output <OUTPUT>|--same-folder-as-input>", "<--quality <QUALITY>|--lossless|--max-size <MAX_SIZE>> <--output <OUTPUT>|--same-folder-as-input> [FILES]...")
        return die_clap("the argument '--output <OUTPUT>' cannot be used with '--same-folder-as-input'")
    if opts["width"] and opts["long_edge"]:
        return die_clap("the argument '--width <WIDTH>' cannot be used with '--long-edge <LONG_EDGE>'", "--width <WIDTH> <--quality <QUALITY>|--lossless|--max-size <MAX_SIZE>> <--output <OUTPUT>|--same-folder-as-input> <FILES>...")
    if opts["height"] and opts["long_edge"]:
        return die_clap("the argument '--height <HEIGHT>' cannot be used with '--long-edge <LONG_EDGE>'")
    if opts["width"] and opts["short_edge"]:
        return die_clap("the argument '--width <WIDTH>' cannot be used with '--short-edge <SHORT_EDGE>'")
    if opts["height"] and opts["short_edge"]:
        return die_clap("the argument '--height <HEIGHT>' cannot be used with '--short-edge <SHORT_EDGE>'")
    if opts["long_edge"] and opts["short_edge"]:
        return die_clap("the argument '--long-edge <LONG_EDGE>' cannot be used with '--short-edge <SHORT_EDGE>'")
    if not 0 <= opts["png_opt_level"] <= 6:
        return die_clap(f"invalid value '{opts['png_opt_level']}' for '--png-opt-level <PNG_OPT_LEVEL>'")
    return 0


def import_pillow():
    try:
        from PIL import Image
        return Image
    except Exception:
        eprint("Pillow is required. Run ./compile.sh first.")
        raise SystemExit(1)


def is_image(path):
    return path.suffix.lower() in {".jpg", ".jpeg", ".png", ".gif", ".webp", ".tif", ".tiff"}


def collect_files(inputs, recursive):
    files = []
    for item in inputs:
        p = Path(item)
        if p.is_dir():
            iterator = p.rglob("*") if recursive else p.iterdir()
            for child in iterator:
                if child.is_file() and is_image(child):
                    files.append(child)
        elif p.is_file() and is_image(p):
            files.append(p)
        elif not p.exists():
            return None
    return files


def extension_for(src, fmt):
    if fmt == "original":
        return src.suffix
    return ".jpg" if fmt == "jpeg" else "." + fmt


def output_path(src, opts, base_input=None):
    ext = extension_for(src, opts["format"])
    name = src.stem + opts["suffix"] + ext
    if opts["same_folder"]:
        return src.with_name(name)
    root = Path(opts["output"])
    if opts["keep_structure"] and base_input:
        try:
            rel_parent = src.parent.relative_to(base_input)
        except ValueError:
            rel_parent = Path()
        return root / rel_parent / name
    return root / name


def resize_image(img, opts):
    w, h = img.size
    nw, nh = w, h
    if opts["width"] and opts["height"]:
        nw, nh = opts["width"], opts["height"]
    elif opts["width"]:
        nw = opts["width"]
        nh = max(1, round(h * nw / w))
    elif opts["height"]:
        nh = opts["height"]
        nw = max(1, round(w * nh / h))
    elif opts["long_edge"]:
        scale = opts["long_edge"] / max(w, h)
        nw, nh = max(1, round(w * scale)), max(1, round(h * scale))
    elif opts["short_edge"]:
        scale = opts["short_edge"] / min(w, h)
        nw, nh = max(1, round(w * scale)), max(1, round(h * scale))
    if opts["no_upscale"] and (nw > w or nh > h):
        return img
    if (nw, nh) != (w, h):
        return img.resize((nw, nh))
    return img


def save_image(src, dest, opts):
    Image = import_pillow()
    if opts["format"] == "original" and not any([opts["width"], opts["height"], opts["long_edge"], opts["short_edge"]]) and opts["lossless"] and src.suffix.lower() == dest.suffix.lower():
        shutil.copyfile(src, dest)
        return
    with Image.open(src) as img:
        img = resize_image(img, opts)
        fmt = opts["format"]
        if fmt == "original":
            fmt = "jpeg" if src.suffix.lower() in {".jpg", ".jpeg"} else src.suffix.lower().lstrip(".")
            if fmt == "tif":
                fmt = "tiff"
        save_kwargs = {}
        if fmt in {"jpeg", "webp"}:
            if img.mode in ("RGBA", "LA", "P"):
                img = img.convert("RGB")
            save_kwargs["quality"] = opts["quality"] if opts["quality"] is not None else 100
            if fmt == "jpeg":
                save_kwargs["progressive"] = not opts["jpeg_baseline"]
        if fmt == "png":
            save_kwargs["optimize"] = opts["png_opt_level"] > 0
            save_kwargs["compress_level"] = min(9, max(0, opts["png_opt_level"] + 3))
        target = parse_byte_size(opts["max_size"]) if opts["max_size"] else None
        if target and fmt in {"jpeg", "webp"}:
            best = None
            for quality in range(95, 0, -5):
                trial_kwargs = dict(save_kwargs)
                trial_kwargs["quality"] = quality
                buf = BytesIO()
                img.save(buf, format=fmt.upper(), **trial_kwargs)
                data = buf.getvalue()
                best = data
                if len(data) <= target:
                    break
            with open(dest, "wb") as fh:
                fh.write(best or b"")
            return
        img.save(dest, format=fmt.upper(), **save_kwargs)


def parse_savings(value, original_size):
    if not value:
        return None


def parse_byte_size(value):
    if value is None:
        return None
    v = str(value).strip().lower()
    try:
        units = [("kib", 1024), ("kb", 1000), ("mib", 1024 * 1024), ("mb", 1000 * 1000)]
        for suffix, mult in units:
            if v.endswith(suffix):
                return int(float(v[:-len(suffix)]) * mult)
        return int(float(v))
    except Exception:
        return None
    v = value.strip().lower()
    try:
        if v.endswith("%"):
            return original_size * (float(v[:-1]) / 100.0)
        units = [("kib", 1024), ("kb", 1000), ("mib", 1024 * 1024), ("mb", 1000 * 1000)]
        for suffix, mult in units:
            if v.endswith(suffix):
                return float(v[:-len(suffix)]) * mult
        return float(v)
    except Exception:
        return None


def human(n):
    sign = "-" if n < 0 else ""
    n = abs(float(n))
    if n < 1024:
        return f"{sign}{int(n)} B"
    return f"{sign}{n / 1024:.1f} KiB"


def run(opts):
    if not opts["files"]:
        if not opts["quiet"]:
            eprint("No files to compress")
        return 0
    files = collect_files(opts["files"], opts["recursive"])
    if files is None:
        if not opts["quiet"]:
            eprint("Unable to compute the base path for the files.")
        return 255
    if not files:
        if not opts["quiet"]:
            eprint("No files to compress")
        return 0
    base_input = None
    dirs = [Path(f) for f in opts["files"] if Path(f).is_dir()]
    if opts["keep_structure"] and dirs:
        base_input = dirs[0]
    success = skipped = errors = 0
    original_total = 0
    output_total = 0
    for src in files:
        try:
            original = src.stat().st_size
            original_total += original
            dest = output_path(src, opts, base_input)
            temp = dest
            if opts["dry_run"]:
                output_total += original
                success += 1
                continue
            dest.parent.mkdir(parents=True, exist_ok=True)
            if dest.exists() and opts["overwrite"] == "never":
                skipped += 1
                output_total += original
                continue
            if dest.exists() and opts["overwrite"] == "bigger" and dest.stat().st_size <= original:
                skipped += 1
                output_total += original
                continue
            save_image(src, temp, opts)
            new_size = dest.stat().st_size
            min_save = parse_savings(opts["min_savings"], original)
            if min_save is not None and original - new_size < min_save:
                try:
                    dest.unlink()
                except OSError:
                    pass
                skipped += 1
                output_total += original
            else:
                success += 1
                output_total += new_size
                if opts["keep_dates"]:
                    st = src.stat()
                    os.utime(dest, (st.st_atime, st.st_mtime))
        except Exception:
            errors += 1
    if not opts["quiet"]:
        total = len(files)
        diff = output_total - original_total
        pct = 0 if original_total == 0 else diff * 100 / original_total
        sign = "+" if diff > 0 else "-"
        eprint(f"Compressed {total} files ({success} success, {skipped} skipped, {errors} errors)")
        eprint(f"{human(original_total)} -> {human(output_total)} [{sign}{human(abs(diff))} | {sign}{abs(pct):.2f}%]")
    return 0


def main(argv):
    try:
        opts, code = parse_args(argv)
    except SystemExit as exc:
        return int(exc.code or 0)
    if opts is None:
        return code
    if code != 0:
        return code
    return run(opts)


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
