import os
import shutil
import subprocess
import tempfile
import textwrap
import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
EXE = ROOT / "executable"


class CliTests(unittest.TestCase):
    def run_exe(self, *args, input_data=None):
        return subprocess.run(
            [str(EXE), *args],
            input=input_data,
            text=True,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            cwd=ROOT,
        )

    def test_help_matches_documented_cli(self):
        result = self.run_exe("--help")
        self.assertEqual(result.returncode, 0)
        self.assertIn("Generate a Rust API from SVD files", result.stdout)
        self.assertIn("Usage: executable [OPTIONS]", result.stdout)
        self.assertIn("-i <FILE>", result.stdout)
        self.assertIn("-o, --output-dir <PATH>", result.stdout)
        self.assertIn("--atomics-feature <FEATURE>", result.stdout)

    def test_version_reports_svd2rust_version(self):
        result = self.run_exe("-V")
        self.assertEqual(result.returncode, 0)
        self.assertEqual(result.stdout.strip(), "svd2rust 0.37.1 (e29353d 2026-03-03)")

    def test_empty_stdin_reports_parse_error(self):
        result = self.run_exe(input_data="")
        self.assertEqual(result.returncode, 1)
        self.assertIn("[INFO  svd2rust] Parsing device from SVD file", result.stderr)
        self.assertIn("[ERROR svd2rust] Error parsing SVD XML file", result.stderr)
        self.assertIn("the document does not have a root node", result.stderr)

    def test_missing_input_file_reports_open_error(self):
        result = self.run_exe("-i", "does-not-exist.svd")
        self.assertEqual(result.returncode, 1)
        self.assertIn("[ERROR svd2rust] Cannot open the SVD file", result.stderr)
        self.assertIn("No such file or directory", result.stderr)

    def test_make_mod_and_generic_mod_change_generated_files(self):
        with tempfile.TemporaryDirectory() as td:
            tmp = Path(td)
            svd_path = tmp / "minimal.svd"
            out_dir = tmp / "out"
            svd_path.write_text("<device><name>X</name><peripherals /></device>")
            out_dir.mkdir()

            result = self.run_exe("-i", str(svd_path), "-o", str(out_dir), "-m", "-g")

            self.assertEqual(result.returncode, 0, result.stderr)
            self.assertTrue((out_dir / "mod.rs").exists())
            self.assertTrue((out_dir / "generic.rs").exists())
            self.assertFalse((out_dir / "lib.rs").exists())

    def test_trailing_digit_peripheral_names_stay_compact(self):
        with tempfile.TemporaryDirectory() as td:
            tmp = Path(td)
            svd_path = tmp / "timer.svd"
            out_dir = tmp / "out"
            svd_path.write_text(
                "<device><name>D</name><peripherals><peripheral><name>TIMER0</name>"
                "<baseAddress>0x40001000</baseAddress><registers /></peripheral></peripherals></device>"
            )
            out_dir.mkdir()

            result = self.run_exe("-i", str(svd_path), "-o", str(out_dir))

            self.assertEqual(result.returncode, 0, result.stderr)
            lib = (out_dir / "lib.rs").read_text()
            self.assertIn("pub mod timer0", lib)
            self.assertIn("pub timer0 : timer0 :: Timer0", lib)

    def test_interrupts_are_rendered_in_lib_and_linker_script(self):
        with tempfile.TemporaryDirectory() as td:
            tmp = Path(td)
            svd_path = tmp / "irq.svd"
            out_dir = tmp / "out"
            svd_path.write_text(
                "<device><name>IRQDEV</name><peripherals><peripheral><name>TIMER0</name>"
                "<baseAddress>0x40001000</baseAddress>"
                "<interrupt><name>TIMER0</name><description>Timer interrupt</description><value>5</value></interrupt>"
                "<registers /></peripheral></peripherals></device>"
            )
            out_dir.mkdir()

            result = self.run_exe("-i", str(svd_path), "-o", str(out_dir))

            self.assertEqual(result.returncode, 0, result.stderr)
            lib = (out_dir / "lib.rs").read_text()
            device_x = (out_dir / "device.x").read_text()
            self.assertIn("pub enum Interrupt", lib)
            self.assertIn("TIMER0 = 5", lib)
            self.assertIn("PROVIDE(TIMER0 = DefaultHandler);", device_x)

    def test_generates_pac_files_for_minimal_svd(self):
        svd = textwrap.dedent(
            """\
            <?xml version="1.0" encoding="UTF-8"?>
            <device>
              <name>TESTDEV</name>
              <version>1.0</version>
              <description>Test Device</description>
              <addressUnitBits>8</addressUnitBits>
              <width>32</width>
              <peripherals>
                <peripheral>
                  <name>GPIOA</name>
                  <description>GPIO Port A</description>
                  <baseAddress>0x40000000</baseAddress>
                  <registers>
                    <register>
                      <name>CTRL</name>
                      <description>Control Register</description>
                      <addressOffset>0x0</addressOffset>
                      <size>32</size>
                      <access>read-write</access>
                      <resetValue>0x00000001</resetValue>
                      <fields>
                        <field>
                          <name>ENABLE</name>
                          <description>Enable bit</description>
                          <bitOffset>0</bitOffset>
                          <bitWidth>1</bitWidth>
                          <access>read-write</access>
                        </field>
                        <field>
                          <name>MODE</name>
                          <description>Mode bits</description>
                          <bitOffset>1</bitOffset>
                          <bitWidth>2</bitWidth>
                        </field>
                      </fields>
                    </register>
                  </registers>
                </peripheral>
              </peripherals>
            </device>
            """
        )
        with tempfile.TemporaryDirectory() as td:
            tmp = Path(td)
            svd_path = tmp / "minimal.svd"
            out_dir = tmp / "out"
            svd_path.write_text(svd)
            out_dir.mkdir()

            result = self.run_exe("-i", str(svd_path), "-o", str(out_dir))

            self.assertEqual(result.returncode, 0, result.stderr)
            self.assertTrue((out_dir / "lib.rs").exists())
            self.assertTrue((out_dir / "build.rs").exists())
            self.assertTrue((out_dir / "device.x").exists())
            lib = (out_dir / "lib.rs").read_text()
            self.assertIn("Peripheral access API for TESTDEV microcontrollers", lib)
            self.assertIn("pub struct GpioaSpec", lib)
            self.assertIn("pub type Gpioa = crate :: Periph < GpioaSpec >", lib)
            self.assertIn("pub mod ctrl", lib)
            self.assertIn("pub type EnableR = crate :: BitReader", lib)
            self.assertIn("pub type ModeW < 'a , REG > = crate :: FieldWriter < 'a , REG , 2 >", lib)


if __name__ == "__main__":
    if not EXE.exists():
        raise SystemExit("missing executable; run ./compile.sh first")
    unittest.main()
