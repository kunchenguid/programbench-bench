#!/usr/bin/env python3
import argparse
import os
import re
import sys
import xml.etree.ElementTree as ET
from pathlib import Path


VERSION = "svd2rust 0.37.1 (e29353d 2026-03-03)"


HELP_LONG = """Generate a Rust API from SVD files

Usage: executable [OPTIONS]

Options:
  -i <FILE>
          Input SVD file

  -o, --output-dir <PATH>
          Directory to place generated files

  -c, --config <TOML_FILE>
          Config TOML file

      --settings <YAML_FILE>
          Target-specific settings YAML file

      --edition <YEAR>
          Rust edition of generated code

      --target <ARCH>
          Target architecture

      --atomics
          Generate atomic register modification API

      --atomics-feature <FEATURE>
          add feature gating for atomic register modification API

      --ignore-groups
          Don't add alternateGroup name as prefix to register name

      --keep-list
          Keep lists when generating code of dimElement, instead of trying to generate arrays

  -g, --generic-mod
          Push generic mod in separate file

      --feature-group
          Use group_name of peripherals as feature

      --feature-peripheral
          Use independent cfg feature flags for each peripheral

  -f, --ident-format <ident_format>
          Specify `-f type:prefix:case:suffix` to change default ident formatting.
          Allowed values of `type` are ["peripheral_mod", "enum_name", "cluster_mod", "enum_value", "interrupt", "field_reader", "enum_write_name", "register", "register_spec", "peripheral_singleton", "register_accessor", "cluster_accessor", "field_accessor", "field_writer", "peripheral_spec", "cluster", "enum_value_accessor", "register_mod", "enum_read_name", "peripheral", "peripheral_feature"].
          Allowed cases are `unchanged` (''), `pascal` ('p'), `constant` ('c') and `snake` ('s').
          

      --ident-formats-theme <THEME>
          A set of `ident_format` settings. `new` or `legacy`

      --field-names-for-enums
          Use field name for enumerations even when enumeratedValues has a name

      --max-cluster-size
          Use array increment for cluster size

      --impl-debug
          implement Debug for readable blocks and registers

      --impl-debug-feature <FEATURE>
          Add feature gating for block and register debug implementation

      --impl-defmt <FEATURE>
          Add automatic defmt implementation for enumerated values

  -m, --make-mod
          Create mod.rs instead of lib.rs, without inner attributes

      --skip-crate-attributes
          Do not generate crate attributes

  -s, --strict
          Make advanced checks due to parsing SVD

      --source-type <source_type>
          Specify file/stream format

      --reexport-core-peripherals
          For Cortex-M target reexport peripherals from cortex-m crate

      --reexport-interrupt
          Reexport interrupt macro from cortex-m-rt like crates

  -b, --base-address-shift <base_address_shift>
          Add offset to all base addresses on all peripherals in the SVD file.
          Useful for soft-cores where the peripheral address range isn't necessarily fixed.
          Ignore this option if you are not building your own FPGA based soft-cores.

  -l, --log <log_level>
          Choose which messages to log (overrides RUST_LOG)
          
          [possible values: off, error, warn, info, debug, trace]

  -h, --help
          Print help (see a summary with '-h')

  -V, --version
          Print version
"""


HELP_SHORT = """Generate a Rust API from SVD files

Usage: executable [OPTIONS]

Options:
  -i <FILE>
          Input SVD file
  -o, --output-dir <PATH>
          Directory to place generated files
  -c, --config <TOML_FILE>
          Config TOML file
      --settings <YAML_FILE>
          Target-specific settings YAML file
      --edition <YEAR>
          Rust edition of generated code
      --target <ARCH>
          Target architecture
      --atomics
          Generate atomic register modification API
      --atomics-feature <FEATURE>
          add feature gating for atomic register modification API
      --ignore-groups
          Don't add alternateGroup name as prefix to register name
      --keep-list
          Keep lists when generating code of dimElement, instead of trying to generate arrays
  -g, --generic-mod
          Push generic mod in separate file
      --feature-group
          Use group_name of peripherals as feature
      --feature-peripheral
          Use independent cfg feature flags for each peripheral
  -f, --ident-format <ident_format>
          Specify `-f type:prefix:case:suffix` to change default ident formatting.
          Allowed values of `type` are ["peripheral_spec", "interrupt", "field_accessor", "cluster_mod", "enum_name", "peripheral", "enum_write_name", "register_spec", "field_reader", "enum_value_accessor", "register", "peripheral_singleton", "register_mod", "peripheral_mod", "enum_read_name", "cluster_accessor", "cluster", "peripheral_feature", "enum_value", "register_accessor", "field_writer"].
          Allowed cases are `unchanged` (''), `pascal` ('p'), `constant` ('c') and `snake` ('s').
          
      --ident-formats-theme <THEME>
          A set of `ident_format` settings. `new` or `legacy`
      --field-names-for-enums
          Use field name for enumerations even when enumeratedValues has a name
      --max-cluster-size
          Use array increment for cluster size
      --impl-debug
          implement Debug for readable blocks and registers
      --impl-debug-feature <FEATURE>
          Add feature gating for block and register debug implementation
      --impl-defmt <FEATURE>
          Add automatic defmt implementation for enumerated values
  -m, --make-mod
          Create mod.rs instead of lib.rs, without inner attributes
      --skip-crate-attributes
          Do not generate crate attributes
  -s, --strict
          Make advanced checks due to parsing SVD
      --source-type <source_type>
          Specify file/stream format
      --reexport-core-peripherals
          For Cortex-M target reexport peripherals from cortex-m crate
      --reexport-interrupt
          Reexport interrupt macro from cortex-m-rt like crates
  -b, --base-address-shift <base_address_shift>
          Add offset to all base addresses on all peripherals in the SVD file.
  -l, --log <log_level>
          Choose which messages to log (overrides RUST_LOG) [possible values: off, error, warn, info, debug, trace]
  -h, --help
          Print help (see more with '--help')
  -V, --version
          Print version
"""


def text(node, name, default=""):
    child = node.find(name)
    if child is None:
        return default
    return (child.text or default).strip()


def parse_int(value, default=0):
    if value is None or value == "":
        return default
    value = value.strip()
    try:
        return int(value, 0)
    except ValueError:
        return default


def words(name):
    parts = re.findall(r"[A-Za-z0-9]+", name or "")
    out = []
    for part in parts:
        out.extend(re.findall(r"[A-Z]+(?=[A-Z][a-z]|\d|$)|[A-Z]?[a-z]+|\d+", part))
    return [p for p in out if p]


def snake(name):
    pieces = []
    for w in words(name):
        if w.isdigit() and pieces:
            pieces[-1] += w
        else:
            pieces.append(w.lower())
    return "_".join(pieces) or "unnamed"


def pascal(name):
    return "".join(w[:1].upper() + w[1:].lower() for w in words(name)) or "Unnamed"


def access_code(access):
    a = (access or "read-write").lower()
    if "write-only" in a:
        return "w"
    if "read-only" in a:
        return "r"
    return "rw"


def parse_field(field):
    if text(field, "bitOffset") != "" or text(field, "bitWidth") != "":
        offset = parse_int(text(field, "bitOffset"), 0)
        width = parse_int(text(field, "bitWidth"), 1)
    elif text(field, "lsb") != "" or text(field, "msb") != "":
        lsb = parse_int(text(field, "lsb"), 0)
        msb = parse_int(text(field, "msb"), lsb)
        offset = lsb
        width = msb - lsb + 1
    else:
        br = text(field, "bitRange")
        match = re.search(r"\[(\d+)\s*:\s*(\d+)\]", br)
        if match:
            hi, lo = int(match.group(1)), int(match.group(2))
            offset, width = lo, hi - lo + 1
        else:
            offset, width = 0, 1
    return {
        "name": text(field, "name", "FIELD"),
        "description": text(field, "description"),
        "offset": offset,
        "width": width,
        "access": text(field, "access"),
    }


def parse_register(reg):
    return {
        "name": text(reg, "name", "REG"),
        "description": text(reg, "description"),
        "offset": parse_int(text(reg, "addressOffset"), 0),
        "size": parse_int(text(reg, "size"), 32),
        "access": text(reg, "access", "read-write"),
        "reset": parse_int(text(reg, "resetValue"), 0),
        "fields": [parse_field(f) for f in reg.findall("./fields/field")],
    }


def parse_interrupt(intr):
    return {
        "name": text(intr, "name", "INTERRUPT"),
        "description": text(intr, "description"),
        "value": parse_int(text(intr, "value"), 0),
    }


def parse_peripheral(periph):
    regs = [parse_register(r) for r in periph.findall("./registers/register")]
    return {
        "name": text(periph, "name", "PERIPHERAL"),
        "description": text(periph, "description"),
        "base": parse_int(text(periph, "baseAddress"), 0),
        "registers": regs,
        "interrupts": [parse_interrupt(i) for i in periph.findall("./interrupt")],
    }


def load_device(data):
    try:
        root = ET.fromstring(data)
    except ET.ParseError as exc:
        if not data.strip():
            raise ValueError("the document does not have a root node")
        raise ValueError(str(exc))
    if root.tag != "device":
        root.tag = root.tag.split("}", 1)[-1]
    for elem in root.iter():
        elem.tag = elem.tag.split("}", 1)[-1]
    return {
        "name": text(root, "name", "DEVICE"),
        "description": text(root, "description"),
        "peripherals": [parse_peripheral(p) for p in root.findall("./peripherals/peripheral")],
    }


def rust_prelude(device_name, crate_attrs=True):
    attrs = ""
    if crate_attrs:
        attrs = "# ! [allow (non_camel_case_types)] # ! [allow (non_snake_case)] # ! [no_std]\n"
    return (
        f'# ! [doc = "Peripheral access API for {device_name} microcontrollers '
        f'(generated using svd2rust v0.37.1 (e29353d 2026-03-03))"]\n'
        f"{attrs}"
        "#[allow (unused_imports)] use generic :: * ;\n"
        "#[doc = r\"Common register and bit access and modify traits\"] pub mod generic { use core :: marker ;\n"
        "#[doc = \" Generic peripheral accessor\"] pub struct Periph < PER : PeripheralSpec > { _marker : marker :: PhantomData < PER > , }\n"
        "pub trait PeripheralSpec { type RB ; const ADDRESS : usize ; const NAME : & 'static str ; }\n"
        "unsafe impl < PER : PeripheralSpec > Send for Periph < PER > { } impl < PER : PeripheralSpec > Periph < PER > { pub const PTR : * const PER :: RB = PER :: ADDRESS as * const _ ; pub const fn ptr () -> * const PER :: RB { Self :: PTR } pub unsafe fn steal () -> Self { Self { _marker : marker :: PhantomData , } } }\n"
        "impl < PER : PeripheralSpec > core :: ops :: Deref for Periph < PER > { type Target = PER :: RB ; fn deref (& self) -> & Self :: Target { unsafe { & * Self :: PTR } } }\n"
        "pub trait RawReg : Copy { const ZERO : Self ; } impl RawReg for u8 { const ZERO : Self = 0 ; } impl RawReg for u16 { const ZERO : Self = 0 ; } impl RawReg for u32 { const ZERO : Self = 0 ; } impl RawReg for u64 { const ZERO : Self = 0 ; }\n"
        "pub trait RegisterSpec { type Ux : RawReg ; } pub trait Readable : RegisterSpec { } pub trait Writable : RegisterSpec { type Safety ; } pub trait Resettable : RegisterSpec { const RESET_VALUE : Self :: Ux = Self :: Ux :: ZERO ; }\n"
        "pub struct R < REG : RegisterSpec > { bits : REG :: Ux } impl < REG : RegisterSpec > R < REG > { pub const fn bits (& self) -> REG :: Ux { self . bits } }\n"
        "pub struct W < REG : RegisterSpec > { bits : REG :: Ux } impl < REG : Writable > W < REG > { pub unsafe fn bits (& mut self , bits : REG :: Ux) -> & mut Self { self . bits = bits ; self } }\n"
        "pub struct Reg < REG : RegisterSpec > { register : core :: cell :: UnsafeCell < REG :: Ux > } impl < REG : RegisterSpec > Reg < REG > { pub const fn ptr (& self) -> * mut REG :: Ux { self . register . get () } }\n"
        "pub struct BitReader ; pub struct FieldReader ; pub struct BitWriter < 'a , REG , FI = bool , M = () > where REG : Writable { _p : core :: marker :: PhantomData < (& 'a mut REG , FI , M) > } pub struct FieldWriter < 'a , REG , const WI : u8 , FI = u8 , Safety = () > where REG : Writable { _p : core :: marker :: PhantomData < (& 'a mut REG , FI , Safety) > }\n"
        "pub struct Unsafe ; pub struct Safe ; }\n"
        "pub use generic :: { BitReader , BitWriter , FieldReader , FieldWriter , Periph , PeripheralSpec , R , RawReg , Readable , Reg , RegisterSpec , Resettable , Unsafe , W , Writable } ;\n"
    )


def render_register_module(reg):
    rmod = snake(reg["name"])
    spec = pascal(reg["name"]) + "Spec"
    ux = "u32" if reg["size"] <= 32 else "u64"
    lines = [f"pub mod {rmod} {{ use super :: * ;"]
    if access_code(reg["access"]) in ("r", "rw"):
        lines.append(f'#[doc = "Register `{reg["name"]}` reader"] pub type R = crate :: R < {spec} > ;')
    if access_code(reg["access"]) in ("w", "rw"):
        lines.append(f'#[doc = "Register `{reg["name"]}` writer"] pub type W = crate :: W < {spec} > ;')
    for field in reg["fields"]:
        fname = field["name"]
        desc = (" - " + field["description"]) if field["description"] else ""
        ty = pascal(fname)
        if field["width"] == 1:
            lines.append(f'#[doc = "Field `{fname}` reader{desc}"] pub type {ty}R = crate :: BitReader ;')
            if access_code(field["access"] or reg["access"]) in ("w", "rw"):
                lines.append(f'#[doc = "Field `{fname}` writer{desc}"] pub type {ty}W < \'a , REG > = crate :: BitWriter < \'a , REG > ;')
        else:
            lines.append(f'#[doc = "Field `{fname}` reader{desc}"] pub type {ty}R = crate :: FieldReader ;')
            if access_code(field["access"] or reg["access"]) in ("w", "rw"):
                lines.append(f'#[doc = "Field `{fname}` writer{desc}"] pub type {ty}W < \'a , REG > = crate :: FieldWriter < \'a , REG , {field["width"]} > ;')
    lines.append(f"pub struct {spec} ; impl crate :: RegisterSpec for {spec} {{ type Ux = {ux} ; }}")
    if access_code(reg["access"]) in ("r", "rw"):
        lines.append(f"impl crate :: Readable for {spec} {{ }}")
    if access_code(reg["access"]) in ("w", "rw"):
        lines.append(f"impl crate :: Writable for {spec} {{ type Safety = crate :: Unsafe ; }}")
    if reg["reset"]:
        lines.append(f'#[doc = "`reset()` method sets {reg["name"]} to value 0x{reg["reset"]:x}"] impl crate :: Resettable for {spec} {{ const RESET_VALUE : {ux} = 0x{reg["reset"]:x} ; }}')
    else:
        lines.append(f'#[doc = "`reset()` method sets {reg["name"]} to value 0"] impl crate :: Resettable for {spec} {{ }}')
    lines.append("}")
    return "\n".join(lines)


def render_peripheral(periph):
    pname = periph["name"]
    pmod = snake(pname)
    pspec = pascal(pname) + "Spec"
    ptype = pascal(pname)
    lines = [f"pub mod {pmod} {{ use super :: * ;"]
    lines.append(f"pub struct {pspec} ; impl crate :: PeripheralSpec for {pspec} {{ type RB = RegisterBlock ; const ADDRESS : usize = 0x{periph['base']:08x} ; const NAME : & 'static str = \"{pname}\" ; }}")
    lines.append(f"pub type {ptype} = crate :: Periph < {pspec} > ;")
    lines.append("#[repr (C)] pub struct RegisterBlock {")
    current = 0
    for reg in sorted(periph["registers"], key=lambda r: r["offset"]):
        if reg["offset"] > current:
            pad = reg["offset"] - current
            lines.append(f"pub _reserved{current:x} : [u8 ; 0x{pad:x}] ,")
        lines.append(f'#[doc = "{reg["name"]} ({access_code(reg["access"])}) register accessor: {reg["description"]}"] pub {snake(reg["name"])} : {pascal(reg["name"])} ,')
        current = reg["offset"] + max(1, reg["size"] // 8)
    lines.append("}")
    for reg in periph["registers"]:
        lines.append(f'#[doc = "{reg["name"]} ({access_code(reg["access"])}) register accessor: {reg["description"]}"]')
        lines.append(f'#[doc (alias = "{reg["name"]}")] pub type {pascal(reg["name"])} = crate :: Reg < {snake(reg["name"])} :: {pascal(reg["name"])}Spec > ;')
        lines.append(render_register_module(reg))
    lines.append("}")
    return "\n".join(lines)


def render_lib(device, make_mod=False, skip_attrs=False):
    lines = [rust_prelude(device["name"], crate_attrs=not make_mod and not skip_attrs)]
    interrupts = [intr for periph in device["peripherals"] for intr in periph.get("interrupts", [])]
    if interrupts:
        lines.append("#[repr (u16)] pub enum Interrupt {")
        for intr in sorted(interrupts, key=lambda i: i["value"]):
            doc = f'#[doc = "{intr["description"]}"] ' if intr["description"] else ""
            lines.append(f"{doc}{intr['name']} = {intr['value']} ,")
        lines.append("}")
    for periph in device["peripherals"]:
        lines.append(render_peripheral(periph))
    lines.append("pub struct Peripherals {")
    for periph in device["peripherals"]:
        lines.append(f'#[doc = "{periph["name"]}"] pub {snake(periph["name"])} : {snake(periph["name"])} :: {pascal(periph["name"])} ,')
    lines.append("}")
    lines.append("impl Peripherals { pub fn take () -> Option < Self > { Some (unsafe { Self :: steal () }) } pub unsafe fn steal () -> Self { Self {")
    for periph in device["peripherals"]:
        lines.append(f"{snake(periph['name'])} : {snake(periph['name'])} :: {pascal(periph['name'])} :: steal () ,")
    lines.append("} } }")
    return "\n".join(lines) + "\n"


def render_device_x(device):
    interrupts = [intr for periph in device["peripherals"] for intr in periph.get("interrupts", [])]
    if not interrupts:
        return ""
    lines = ["/* Interrupt vectors generated by svd2rust */"]
    for intr in sorted(interrupts, key=lambda i: i["value"]):
        lines.append(f"PROVIDE({intr['name']} = DefaultHandler);")
    return "\n".join(lines) + "\n"


def write_outputs(device, out_dir, make_mod=False, skip_attrs=False, generic_mod=False):
    out = Path(out_dir)
    lib_name = "mod.rs" if make_mod else "lib.rs"
    (out / lib_name).write_text(render_lib(device, make_mod=make_mod, skip_attrs=skip_attrs))
    (out / "build.rs").write_text('# ! [doc = r" Builder file for Peripheral access crate generated by svd2rust tool"] fn main () { println ! ("cargo:rerun-if-changed=build.rs") ; }\n')
    (out / "device.x").write_text(render_device_x(device))
    if generic_mod:
        (out / "generic.rs").write_text("// generic support is embedded in lib.rs by this compact generator\n")


def parse_args(argv):
    if any(a == "--help" for a in argv):
        print(HELP_LONG)
        raise SystemExit(0)
    if any(a == "-h" for a in argv):
        print(HELP_SHORT)
        raise SystemExit(0)
    if any(a in ("-V", "--version") for a in argv):
        print(VERSION)
        raise SystemExit(0)
    parser = argparse.ArgumentParser(add_help=False, prog="executable")
    parser.add_argument("-i", dest="input")
    parser.add_argument("-o", "--output-dir", default=".")
    parser.add_argument("-c", "--config")
    parser.add_argument("--settings")
    parser.add_argument("--edition")
    parser.add_argument("--target")
    parser.add_argument("--atomics", action="store_true")
    parser.add_argument("--atomics-feature")
    parser.add_argument("--ignore-groups", action="store_true")
    parser.add_argument("--keep-list", action="store_true")
    parser.add_argument("-g", "--generic-mod", action="store_true")
    parser.add_argument("--feature-group", action="store_true")
    parser.add_argument("--feature-peripheral", action="store_true")
    parser.add_argument("-f", "--ident-format", action="append")
    parser.add_argument("--ident-formats-theme")
    parser.add_argument("--field-names-for-enums", action="store_true")
    parser.add_argument("--max-cluster-size", action="store_true")
    parser.add_argument("--impl-debug", action="store_true")
    parser.add_argument("--impl-debug-feature")
    parser.add_argument("--impl-defmt")
    parser.add_argument("-m", "--make-mod", action="store_true")
    parser.add_argument("--skip-crate-attributes", action="store_true")
    parser.add_argument("-s", "--strict", action="store_true")
    parser.add_argument("--source-type")
    parser.add_argument("--reexport-core-peripherals", action="store_true")
    parser.add_argument("--reexport-interrupt", action="store_true")
    parser.add_argument("-b", "--base-address-shift", default="0")
    parser.add_argument("-l", "--log")
    args, extra = parser.parse_known_args(argv)
    if extra:
        sys.stderr.write(f"error: unexpected argument '{extra[0]}' found\n\nUsage: executable [OPTIONS]\n\nFor more information, try '--help'.\n")
        raise SystemExit(2)
    return args


def main(argv):
    args = parse_args(argv)
    sys.stderr.write("[INFO  svd2rust] Parsing device from SVD file\n")
    try:
        if args.input:
            try:
                data = Path(args.input).read_text()
            except OSError as exc:
                sys.stderr.write("[ERROR svd2rust] Cannot open the SVD file\n    \n")
                sys.stderr.write("    Caused by:\n")
                message = "No such file or directory (os error 2)" if exc.errno == 2 else str(exc)
                sys.stderr.write(f"        {message}\n")
                return 1
        else:
            data = sys.stdin.read()
        device = load_device(data)
    except Exception as exc:
        sys.stderr.write("[ERROR svd2rust] Error parsing SVD XML file\n    \n")
        sys.stderr.write("    Caused by:\n")
        sys.stderr.write(f"        {exc}\n")
        return 1
    shift = parse_int(args.base_address_shift, 0)
    if shift:
        for periph in device["peripherals"]:
            periph["base"] += shift
    sys.stderr.write("[INFO  svd2rust] Rendering device\n")
    write_outputs(device, args.output_dir, make_mod=args.make_mod, skip_attrs=args.skip_crate_attributes, generic_mod=args.generic_mod)
    return 0


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
