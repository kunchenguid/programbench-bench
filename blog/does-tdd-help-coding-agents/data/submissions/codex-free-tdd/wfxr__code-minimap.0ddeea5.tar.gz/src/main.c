#include <errno.h>
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef struct {
    int first;
    int last;
    int width;
} Line;

typedef struct {
    Line *items;
    size_t len;
    size_t cap;
} Lines;

static int parse_float_value(const char *s, double *out) {
    char *end = NULL;
    errno = 0;
    double v = strtod(s, &end);
    if (errno || end == s || *end != '\0') return 0;
    *out = v;
    return 1;
}

static int parse_padding_value(const char *s, int *out) {
    if (*s == '\0') return 0;
    for (const char *p = s; *p; p++) {
        if (*p < '0' || *p > '9') return 0;
    }
    *out = atoi(s);
    return 1;
}

static void print_help(void) {
    puts("A high performance code minimap generator\n");
    puts("Usage: executable [OPTIONS] [FILE] [COMMAND]\n");
    puts("Commands:");
    puts("  completion");
    puts("          Generate shell completion file");
    puts("  help");
    puts("          Print this message or the help of the given subcommand(s)\n");
    puts("Arguments:");
    puts("  [FILE]");
    puts("          File to read\n");
    puts("Options:");
    puts("  -H, --horizontal-scale <HSCALE>");
    puts("          Specify horizontal scale factor [default: 1.0]");
    puts("  -V, --vertical-scale <VSCALE>");
    puts("          Specify vertical scale factor [default: 1.0]");
    puts("      --padding <PADDING>");
    puts("          Specify padding width");
    puts("      --encoding <ENCODING>");
    puts("          Specify input encoding [default: utf8-lossy] [possible values: utf8-lossy, utf8]");
    puts("      --version");
    puts("          Print version");
    puts("  -h, --help");
    puts("          Print help");
}

static void print_completion_help(void) {
    puts("Generate shell completion file\n");
    puts("Usage: executable completion <SHELL>\n");
    puts("Arguments:");
    puts("  <SHELL>");
    puts("          Target shell name [possible values: bash, elvish, fish, powershell, zsh]\n");
    puts("Options:");
    puts("  -h, --help");
    puts("          Print help");
}

static void emit_completion(const char *shell) {
    if (strcmp(shell, "bash") == 0) {
        puts("_code-minimap() {\n    local i cur prev opts cmd\n    COMPREPLY=()\n}\ncomplete -F _code-minimap code-minimap");
    } else if (strcmp(shell, "zsh") == 0) {
        puts("#compdef code-minimap\n\n_arguments '*::arg:->args'");
    } else if (strcmp(shell, "fish") == 0) {
        puts("# Print an optspec for argparse to handle cmd's options that are independent of any subcommand.");
        puts("function __fish_code_minimap_global_optspecs\n\tstring join \\n H/horizontal-scale= V/vertical-scale= padding= encoding= version h/help\nend");
    } else if (strcmp(shell, "elvish") == 0) {
        puts("use builtin;\nuse str;");
    } else if (strcmp(shell, "powershell") == 0) {
        puts("using namespace System.Management.Automation\nusing namespace System.Management.Automation.Language");
    }
}

static int is_ws(unsigned char c) {
    return c == ' ' || c == '\t' || c == '\r';
}

static int valid_utf8(const unsigned char *s, size_t n) {
    size_t i = 0;
    while (i < n) {
        unsigned char c = s[i];
        if (c < 0x80) {
            i++;
        } else if ((c & 0xe0) == 0xc0) {
            if (i + 1 >= n || (s[i + 1] & 0xc0) != 0x80 || c < 0xc2) return 0;
            i += 2;
        } else if ((c & 0xf0) == 0xe0) {
            if (i + 2 >= n || (s[i + 1] & 0xc0) != 0x80 || (s[i + 2] & 0xc0) != 0x80) return 0;
            if (c == 0xe0 && s[i + 1] < 0xa0) return 0;
            if (c == 0xed && s[i + 1] >= 0xa0) return 0;
            i += 3;
        } else if ((c & 0xf8) == 0xf0) {
            if (i + 3 >= n || (s[i + 1] & 0xc0) != 0x80 || (s[i + 2] & 0xc0) != 0x80 || (s[i + 3] & 0xc0) != 0x80) return 0;
            if (c == 0xf0 && s[i + 1] < 0x90) return 0;
            if (c > 0xf4 || (c == 0xf4 && s[i + 1] >= 0x90)) return 0;
            i += 4;
        } else {
            return 0;
        }
    }
    return 1;
}

static void push_line(Lines *lines, const unsigned char *buf, size_t n) {
    if (lines->len == lines->cap) {
        size_t nc = lines->cap ? lines->cap * 2 : 64;
        Line *p = realloc(lines->items, nc * sizeof(Line));
        if (!p) exit(2);
        lines->items = p;
        lines->cap = nc;
    }
    while (n && (buf[n - 1] == '\n')) n--;
    size_t width = n;
    while (width && is_ws(buf[width - 1])) width--;
    if (width == 0 && n > 0) width = 1;

    int first = -1;
    int last = -1;
    for (size_t i = 0; i < width; i++) {
        if (!is_ws(buf[i])) {
            if (first < 0) first = (int)i;
            last = (int)i;
        }
    }
    lines->items[lines->len++] = (Line){first, last, (int)width};
}

static int read_all(FILE *f, unsigned char **out, size_t *outn) {
    size_t cap = 8192, len = 0;
    unsigned char *buf = malloc(cap);
    if (!buf) return 0;
    for (;;) {
        if (len == cap) {
            cap *= 2;
            unsigned char *p = realloc(buf, cap);
            if (!p) {
                free(buf);
                return 0;
            }
            buf = p;
        }
        size_t n = fread(buf + len, 1, cap - len, f);
        len += n;
        if (n == 0) break;
    }
    *out = buf;
    *outn = len;
    return 1;
}

static void utf8_put(unsigned int cp) {
    if (cp < 0x800) {
        putchar(0xc0 | (cp >> 6));
        putchar(0x80 | (cp & 0x3f));
    } else {
        putchar(0xe0 | (cp >> 12));
        putchar(0x80 | ((cp >> 6) & 0x3f));
        putchar(0x80 | (cp & 0x3f));
    }
}

static int scaled_width(Line *l, double h) {
    if (l->width <= 0) return 0;
    int w = (int)floor((double)l->width * h + 1e-9);
    if (w < 1) w = 1;
    return w;
}

static int filled_at(Line *l, int sx, double h) {
    if (l->first < 0 || l->last < 0) return 0;
    int start = (int)floor((double)l->first * h + 1e-9);
    int span = l->last - l->first + 1;
    int w = (int)floor((double)span * h + 1e-9);
    if (w < 1) w = 1;
    return sx >= start && sx < start + w;
}

static void render(Lines *lines, double h, double v, int padding) {
    if (h <= 0.0 || lines->len == 0) return;
    if (v <= 0.0 || v > 1.0) v = 1.0;
    int out_rows = (int)ceil((double)lines->len * v - 1e-9);
    if (out_rows <= 0) return;

    for (int brow = 0; brow * 4 < out_rows; brow++) {
        int group_width = 0;
        for (int r = 0; r < 4; r++) {
            int sy = (int)floor((double)(brow * 4 + r) / v + 1e-9);
            if (sy >= 0 && (size_t)sy < lines->len) {
                int w = scaled_width(&lines->items[sy], h);
                if (w > group_width) group_width = w;
            }
        }
        int cells = (group_width + 1) / 2;
        if (cells < padding) cells = padding;
        if (cells == 0 && padding == 0) continue;
        for (int cell = 0; cell < cells; cell++) {
            int dots = 0;
            for (int r = 0; r < 4; r++) {
                int sy = (int)floor((double)(brow * 4 + r) / v + 1e-9);
                if (sy < 0 || (size_t)sy >= lines->len) continue;
                for (int c = 0; c < 2; c++) {
                    int sx = cell * 2 + c;
                    if (!filled_at(&lines->items[sy], sx, h)) continue;
                    static const int bit[4][2] = {{0, 3}, {1, 4}, {2, 5}, {6, 7}};
                    dots |= 1 << bit[r][c];
                }
            }
            if (cell >= (group_width + 1) / 2) putchar(' ');
            else utf8_put(0x2800 + dots);
        }
        putchar('\n');
    }
}

static int parse_lines(const unsigned char *data, size_t n, int strict, Lines *lines) {
    if (strict && !valid_utf8(data, n)) return 0;
    size_t start = 0;
    for (size_t i = 0; i < n; i++) {
        if (data[i] == '\n') {
            push_line(lines, data + start, i + 1 - start);
            start = i + 1;
        }
    }
    if (start < n) push_line(lines, data + start, n - start);
    return 1;
}

int main(int argc, char **argv) {
    double h = 1.0, v = 1.0;
    int padding = 0;
    int strict_utf8 = 0;
    const char *file = NULL;

    for (int i = 1; i < argc; i++) {
        const char *a = argv[i];
        if (strcmp(a, "--help") == 0 || strcmp(a, "-h") == 0 || strcmp(a, "help") == 0) {
            print_help();
            return 0;
        } else if (strcmp(a, "--version") == 0) {
            puts("code-minimap 0.6.8");
            return 0;
        } else if (strcmp(a, "completion") == 0) {
            if (i + 1 >= argc || strcmp(argv[i + 1], "--help") == 0 || strcmp(argv[i + 1], "-h") == 0) {
                print_completion_help();
                return 0;
            }
            const char *sh = argv[i + 1];
            if (strcmp(sh, "bash") && strcmp(sh, "elvish") && strcmp(sh, "fish") && strcmp(sh, "powershell") && strcmp(sh, "zsh")) {
                fprintf(stderr, "error: invalid value '%s' for '<SHELL>'\n  [possible values: bash, elvish, fish, powershell, zsh]\n\nFor more information, try '--help'.\n", sh);
                return 2;
            }
            emit_completion(sh);
            return 0;
        } else if ((strcmp(a, "-H") == 0 || strcmp(a, "--horizontal-scale") == 0) && i + 1 < argc) {
            const char *val = argv[++i];
            if (!parse_float_value(val, &h)) {
                fprintf(stderr, "error: invalid value '%s' for '--horizontal-scale <HSCALE>': invalid float literal\n\nFor more information, try '--help'.\n", val);
                return 2;
            }
        } else if ((strcmp(a, "-V") == 0 || strcmp(a, "--vertical-scale") == 0) && i + 1 < argc) {
            const char *val = argv[++i];
            if (!parse_float_value(val, &v)) {
                fprintf(stderr, "error: invalid value '%s' for '--vertical-scale <VSCALE>': invalid float literal\n\nFor more information, try '--help'.\n", val);
                return 2;
            }
        } else if (strncmp(a, "--horizontal-scale=", 19) == 0) {
            const char *val = a + 19;
            if (!parse_float_value(val, &h)) {
                fprintf(stderr, "error: invalid value '%s' for '--horizontal-scale <HSCALE>': invalid float literal\n\nFor more information, try '--help'.\n", val);
                return 2;
            }
        } else if (strncmp(a, "--vertical-scale=", 17) == 0) {
            const char *val = a + 17;
            if (!parse_float_value(val, &v)) {
                fprintf(stderr, "error: invalid value '%s' for '--vertical-scale <VSCALE>': invalid float literal\n\nFor more information, try '--help'.\n", val);
                return 2;
            }
        } else if (strcmp(a, "--padding") == 0 && i + 1 < argc) {
            const char *val = argv[++i];
            if (!parse_padding_value(val, &padding)) {
                fprintf(stderr, "error: invalid value '%s' for '--padding <PADDING>': invalid digit found in string\n\nFor more information, try '--help'.\n", val);
                return 2;
            }
        } else if (strncmp(a, "--padding=", 10) == 0) {
            const char *val = a + 10;
            if (!parse_padding_value(val, &padding)) {
                fprintf(stderr, "error: invalid value '%s' for '--padding <PADDING>': invalid digit found in string\n\nFor more information, try '--help'.\n", val);
                return 2;
            }
        } else if (strcmp(a, "--encoding") == 0 && i + 1 < argc) {
            const char *e = argv[++i];
            if (strcmp(e, "utf8") == 0) strict_utf8 = 1;
            else if (strcmp(e, "utf8-lossy") == 0) strict_utf8 = 0;
            else {
                fprintf(stderr, "error: invalid value '%s' for '--encoding <ENCODING>'\n  [possible values: utf8-lossy, utf8]\n\nFor more information, try '--help'.\n", e);
                return 2;
            }
        } else if (strncmp(a, "--encoding=", 11) == 0) {
            const char *e = a + 11;
            if (strcmp(e, "utf8") == 0) strict_utf8 = 1;
            else if (strcmp(e, "utf8-lossy") == 0) strict_utf8 = 0;
            else {
                fprintf(stderr, "error: invalid value '%s' for '--encoding <ENCODING>'\n  [possible values: utf8-lossy, utf8]\n\nFor more information, try '--help'.\n", e);
                return 2;
            }
        } else if (a[0] == '-') {
            fprintf(stderr, "error: unexpected argument '%s' found\n\nUsage: executable [OPTIONS] [FILE] [COMMAND]\n\nFor more information, try '--help'.\n", a);
            return 2;
        } else if (!file) {
            file = a;
        }
    }

    FILE *f = stdin;
    if (file) {
        f = fopen(file, "rb");
        if (!f) {
            fprintf(stderr, "code-minimap: %s (os error %d)\n", strerror(errno), errno);
            return 1;
        }
    }
    unsigned char *data = NULL;
    size_t n = 0;
    if (!read_all(f, &data, &n)) return 2;
    if (file) fclose(f);

    Lines lines = {0};
    if (!parse_lines(data, n, strict_utf8, &lines)) {
        fprintf(stderr, "code-minimap: stream did not contain valid UTF-8\n");
        free(data);
        return 1;
    }
    render(&lines, h, v, padding);
    free(lines.items);
    free(data);
    return 0;
}
