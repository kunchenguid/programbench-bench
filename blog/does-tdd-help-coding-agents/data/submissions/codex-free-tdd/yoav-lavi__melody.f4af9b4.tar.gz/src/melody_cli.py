#!/usr/bin/env python3
import argparse
import os
import re
import sys


class MelodyError(Exception):
    def __init__(self, message, line=1, col=1):
        super().__init__(message)
        self.line = line
        self.col = col


class Parser:
    SYMBOLS = {
        "char": ".",
        "space": " ",
        "whitespace": "\\s",
        "digit": "\\d",
        "word": "\\w",
        "newline": "\\n",
        "tab": "\\t",
        "boundary": "\\b",
        "start": "^",
        "end": "$",
        "alphabetic": "[a-zA-Z]",
        "alphanumeric": "[a-zA-Z0-9]",
        "null": "\\0",
    }

    NEG_SYMBOLS = {
        "digit": "\\D",
        "word": "\\W",
        "whitespace": "\\S",
        "boundary": "\\B",
    }

    def __init__(self, source):
        self.source = source
        self.i = 0

    def parse(self):
        parts = self.parse_items(stop=None)
        self.skip_ws()
        if self.i != len(self.source):
            self.error("expected root")
        return "".join(parts)

    def parse_items(self, stop):
        parts = []
        while True:
            self.skip_ws()
            if self.i >= len(self.source):
                if stop:
                    self.error("expected item")
                return parts
            if stop and self.peek() == stop:
                return parts
            parts.append(self.parse_item())
            self.skip_ws()
            if self.peek() == ";":
                self.i += 1

    def parse_item(self):
        self.skip_ws()
        if self.match_word("not"):
            return self.parse_not()
        if self.match_word("match"):
            return "(?:" + self.parse_block_joined() + ")"
        if self.match_word("capture"):
            self.skip_ws()
            name = self.read_ident_optional()
            body = self.parse_block_joined()
            return f"(?<{name}>{body})" if name else f"({body})"
        if self.match_word("either"):
            return "(?:" + "|".join(self.parse_block_items()) + ")"
        if self.match_word("ahead"):
            return "(?=" + self.parse_block_joined() + ")"
        if self.match_word("behind"):
            return "(?<=" + self.parse_block_joined() + ")"
        quant = self.try_quantifier_prefix()
        if quant is not None:
            inner = self.parse_item()
            return self.apply_quantifier(inner, quant)
        if self.peek() == '"':
            return self.parse_string()
        if self.peek() == "<":
            return self.parse_symbol()
        self.error("expected root")

    def parse_not(self):
        self.skip_ws()
        if self.match_word("ahead"):
            return "(?!" + self.parse_block_joined() + ")"
        if self.match_word("behind"):
            return "(?<!" + self.parse_block_joined() + ")"
        if self.peek() == "<":
            name = self.parse_symbol_name()
            if name in self.NEG_SYMBOLS:
                return self.NEG_SYMBOLS[name]
        self.error("expected amount, class_content, or assertion_type")

    def try_quantifier_prefix(self):
        self.skip_ws()
        start = self.i
        word = self.read_word()
        if word in ("some", "any", "option"):
            self.skip_ws()
            if self.match_word("of"):
                return {"some": "+", "any": "*", "option": "?"}[word]
        self.i = start
        number = self.read_number()
        if number is not None:
            self.skip_ws()
            if self.match_word("to"):
                self.skip_ws()
                end = self.read_number()
                if end is None:
                    self.error("expected amount")
                self.skip_ws()
                if self.match_word("of"):
                    return "{" + str(number) + "," + str(end) + "}"
            elif self.match_word("of"):
                return "{" + str(number) + "}"
        self.i = start
        return None

    def apply_quantifier(self, inner, quant):
        if len(inner) == 1 or inner.startswith("[") and inner.endswith("]") or inner.startswith("\\") and len(inner) == 2 or inner in ("\\s", "\\d", "\\w", "\\D", "\\W", "\\S"):
            return inner + quant
        if inner.startswith("(") and inner.endswith(")"):
            return inner + quant
        return "(?:" + inner + ")" + quant

    def parse_block_joined(self):
        return "".join(self.parse_block_items())

    def parse_block_items(self):
        self.skip_ws()
        if self.peek() != "{":
            self.error("expected block")
        self.i += 1
        items = self.parse_items(stop="}")
        self.skip_ws()
        if self.peek() != "}":
            self.error("expected block")
        self.i += 1
        return items

    def parse_symbol(self):
        name = self.parse_symbol_name()
        if name not in self.SYMBOLS:
            self.error("expected root")
        return self.SYMBOLS[name]

    def parse_symbol_name(self):
        self.skip_ws()
        if self.peek() != "<":
            self.error("expected class_content")
        self.i += 1
        start = self.i
        while self.i < len(self.source) and self.source[self.i] != ">":
            self.i += 1
        if self.i >= len(self.source):
            self.error("expected '>'")
        name = self.source[start:self.i].strip()
        self.i += 1
        return name

    def parse_string(self):
        self.i += 1
        out = []
        while self.i < len(self.source):
            ch = self.source[self.i]
            self.i += 1
            if ch == '"':
                return escape_literal("".join(out))
            if ch == "\\" and self.i < len(self.source):
                nxt = self.source[self.i]
                self.i += 1
                escapes = {"n": "\n", "t": "\t", "r": "\r", '"': '"', "\\": "\\"}
                out.append(escapes.get(nxt, nxt))
            else:
                out.append(ch)
        self.error("expected string")

    def skip_ws(self):
        while self.i < len(self.source):
            if self.source.startswith("//", self.i):
                while self.i < len(self.source) and self.source[self.i] != "\n":
                    self.i += 1
            elif self.source.startswith("/*", self.i):
                end = self.source.find("*/", self.i + 2)
                self.i = len(self.source) if end < 0 else end + 2
            elif self.source[self.i].isspace():
                self.i += 1
            else:
                break

    def match_word(self, word):
        self.skip_ws()
        end = self.i + len(word)
        if self.source[self.i:end] == word and (end == len(self.source) or not (self.source[end].isalnum() or self.source[end] == "_")):
            self.i = end
            return True
        return False

    def read_word(self):
        self.skip_ws()
        start = self.i
        while self.i < len(self.source) and self.source[self.i].isalpha():
            self.i += 1
        return self.source[start:self.i] if self.i > start else None

    def read_ident_optional(self):
        self.skip_ws()
        start = self.i
        if self.i < len(self.source) and (self.source[self.i].isalpha() or self.source[self.i] == "_"):
            self.i += 1
            while self.i < len(self.source) and (self.source[self.i].isalnum() or self.source[self.i] == "_"):
                self.i += 1
            return self.source[start:self.i]
        return None

    def read_number(self):
        self.skip_ws()
        start = self.i
        while self.i < len(self.source) and self.source[self.i].isdigit():
            self.i += 1
        return int(self.source[start:self.i]) if self.i > start else None

    def peek(self):
        return self.source[self.i] if self.i < len(self.source) else ""

    def error(self, message):
        line = self.source.count("\n", 0, self.i) + 1
        last_nl = self.source.rfind("\n", 0, self.i)
        col = self.i + 1 if last_nl < 0 else self.i - last_nl
        raise MelodyError(message, line, col)


def compile_melody(source):
    return Parser(source).parse()


def escape_literal(text):
    specials = set("\\^$.*+?()[]{}|/")
    return "".join("\\" + ch if ch in specials else ch for ch in text)


def format_error(source, err):
    lines = source.splitlines() or [""]
    line_text = lines[err.line - 1] if err.line - 1 < len(lines) else ""
    return (
        f"Error:  --> {err.line}:{err.col}\n"
        "  |\n"
        f"{err.line} | {line_text}\n"
        f"  | {' ' * (err.col - 1)}^---\n"
        "  |\n"
        f"  = {err}\n"
    )


def read_source(path):
    if path == "-":
        return sys.stdin.read()
    with open(path, encoding="utf-8") as handle:
        return handle.read()


def completion(shell):
    if shell == "fish":
        return "\n".join(
            [
                "complete -c melody -s o -l output -d 'Write to a file' -r",
                "complete -c melody -l generate-completions -d 'Outputs completions for the selected shell To use, write the output to the appropriate location for your shell' -r",
                "complete -c melody -s t -l test -d 'Test the compiled regex against a string' -r",
                "complete -c melody -s f -l test-file -d 'Test the compiled regex against the contents of a file' -r",
                "complete -c melody -s n -l no-color -d 'Print output with no color'",
                "complete -c melody -s r -l repl -d 'Start the Melody REPL'",
                "complete -c melody -s h -l help -d 'Print help'",
                "complete -c melody -s V -l version -d 'Print version'",
            ]
        ) + "\n"
    if shell in ("bash", "zsh", "powershell", "elvish"):
        return f"# completion script for melody ({shell})\n"
    return "Unknown or unsupported shell: '%s'\nTry one of: 'bash', 'zsh', 'fish', 'elvish', 'powershell'\n" % shell


def build_arg_parser():
    parser = argparse.ArgumentParser(
        prog="executable",
        description="A CLI wrapping the Melody language compiler",
        add_help=False,
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    parser.add_argument("input_file_path", nargs="?")
    parser.add_argument("-o", "--output", dest="output_file_path")
    parser.add_argument("-n", "--no-color", action="store_true")
    parser.add_argument("-r", "--repl", action="store_true")
    parser.add_argument("--generate-completions", dest="completions")
    parser.add_argument("-t", "--test", dest="test")
    parser.add_argument("-f", "--test-file", dest="test_file")
    parser.add_argument("-h", "--help", action="store_true")
    parser.add_argument("-V", "--version", action="store_true")
    return parser


def print_help():
    sys.stdout.write(
        "A CLI wrapping the Melody language compiler\n\n"
        "Usage: executable [OPTIONS] [INPUT_FILE_PATH]\n\n"
        "Arguments:\n"
        "  [INPUT_FILE_PATH]  Read from a file\n"
        "                     Use '-' and or pipe input to read from stdin\n\n"
        "Options:\n"
        "  -o, --output <OUTPUT_FILE_PATH>           Write to a file\n"
        "  -n, --no-color                            Print output with no color\n"
        "  -r, --repl                                Start the Melody REPL\n"
        "      --generate-completions <completions>  Outputs completions for the selected shell\n"
        "                                            To use, write the output to the appropriate location for your shell\n"
        "  -t, --test <test>                         Test the compiled regex against a string\n"
        "  -f, --test-file <test-file>               Test the compiled regex against the contents of a file\n"
        "  -h, --help                                Print help\n"
        "  -V, --version                             Print version\n"
    )


def main(argv=None):
    argv = argv if argv is not None else sys.argv[1:]
    parser = build_arg_parser()
    try:
        args = parser.parse_args(argv)
    except SystemExit as exc:
        return int(exc.code)
    if args.help:
        print_help()
        return 0
    if args.version:
        print("melody_cli 0.20.0")
        return 0
    if args.completions:
        sys.stdout.write(completion(args.completions))
        return 0
    if args.repl:
        return repl()

    path = args.input_file_path
    if path is None:
        if sys.stdin.isatty():
            return 0
        path = "-"
    try:
        source = read_source(path)
    except OSError:
        print(f"Error: unable read file at path {path}", file=sys.stderr)
        return 65
    try:
        regex = compile_melody(source)
    except MelodyError as err:
        sys.stderr.write(format_error(source, err))
        return 65
    if args.test_file:
        try:
            with open(args.test_file, encoding="utf-8") as handle:
                test_value = handle.read()
        except OSError:
            print(f"Error: unable read file at path {args.test_file}", file=sys.stderr)
            return 65
        print(f"{args.test_file} {'matched' if re.search(regex, test_value) else 'did not match'}")
        return 0
    if args.test is not None:
        print(f"'{args.test}' {'matched' if re.search(regex, args.test) else 'did not match'}")
        return 0
    if args.output_file_path:
        with open(args.output_file_path, "w", encoding="utf-8") as handle:
            handle.write(regex)
    else:
        print(regex)
    return 0


def repl():
    print("Melody REPL")
    while True:
        try:
            line = input("> ")
        except EOFError:
            print()
            return 0
        if line.strip() in ("exit", "quit", ":q"):
            return 0
        try:
            print(compile_melody(line))
        except MelodyError as err:
            sys.stderr.write(format_error(line, err))


if __name__ == "__main__":
    raise SystemExit(main())
