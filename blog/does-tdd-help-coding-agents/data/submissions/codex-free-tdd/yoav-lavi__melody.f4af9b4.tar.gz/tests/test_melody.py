import os
import subprocess
import sys
import tempfile
import unittest


ROOT = os.path.dirname(os.path.dirname(__file__))
CLI = os.path.join(ROOT, "src", "melody_cli.py")


def run_cli(args=None, input_text=None):
    args = args or []
    return subprocess.run(
        [sys.executable, CLI, *args],
        input=input_text,
        text=True,
        capture_output=True,
        cwd=ROOT,
    )


class MelodyCliTest(unittest.TestCase):
    def test_compiles_readme_examples_from_stdin(self):
        result = run_cli(["-"], '"#";\nsome of <word>;')
        self.assertEqual(result.returncode, 0)
        self.assertEqual(result.stdout, "#\\w+\n")
        self.assertEqual(result.stderr, "")

        result = run_cli(["-"], '16 of "na";')
        self.assertEqual(result.returncode, 0)
        self.assertEqual(result.stdout, "(?:na){16}\n")

        result = run_cli(["-"], '2 of match {\n  <space>;\n  "batman";\n}')
        self.assertEqual(result.returncode, 0)
        self.assertEqual(result.stdout, "(?: batman){2}\n")

    def test_compiles_symbols_quantifiers_groups_assertions_and_alternation(self):
        source = "\n".join(
            [
                "<char>;",
                "<space>;",
                "<whitespace>;",
                "<digit>;",
                "<word>;",
                "not <digit>;",
                "<start>;",
                'capture name { "x"; }',
                'either { "a"; "b"; }',
                'not ahead { "z"; }',
                "<end>;",
            ]
        )
        result = run_cli(["-"], source)
        self.assertEqual(result.returncode, 0)
        self.assertEqual(result.stdout, ". \\s\\d\\w\\D^(?<name>x)(?:a|b)(?!z)$\n")

    def test_writes_output_file_and_test_result_messages(self):
        with tempfile.TemporaryDirectory() as tmp:
            source_path = os.path.join(tmp, "hash.mel")
            out_path = os.path.join(tmp, "out.txt")
            with open(source_path, "w", encoding="utf-8") as handle:
                handle.write('"#";\nsome of <word>;')

            result = run_cli([source_path, "-o", out_path])
            self.assertEqual(result.returncode, 0)
            self.assertEqual(result.stdout, "")
            with open(out_path, encoding="utf-8") as handle:
                self.assertEqual(handle.read(), "#\\w+")

            result = run_cli([source_path, "--test", "#abc"])
            self.assertEqual(result.returncode, 0)
            self.assertEqual(result.stdout, "'#abc' matched\n")

            result = run_cli([source_path, "--test", "abc"])
            self.assertEqual(result.returncode, 0)
            self.assertEqual(result.stdout, "'abc' did not match\n")

    def test_error_for_invalid_source_uses_exit_65(self):
        result = run_cli(["-"], "abc")
        self.assertEqual(result.returncode, 65)
        self.assertIn("Error:  --> 1:1", result.stderr)
        self.assertEqual(result.stdout, "")

    def test_additional_observed_constructs(self):
        source = "\n".join(
            [
                "// ignored",
                '2 to 5 of "ab";',
                'option of "x";',
                'some of capture { "a"; }',
                'any of either { "b"; "c"; }',
                'behind { "pre"; }',
                'not behind { "bad"; }',
                "<boundary>;",
                "not <boundary>;",
                "<newline>;",
                "<tab>;",
            ]
        )
        result = run_cli(["-"], source)
        self.assertEqual(result.returncode, 0)
        self.assertEqual(
            result.stdout,
            "(?:ab){2,5}x?(a)+(?:b|c)*(?<=pre)(?<!bad)\\b\\B\\n\\t\n",
        )

    def test_test_file_reports_path(self):
        with tempfile.TemporaryDirectory() as tmp:
            source_path = os.path.join(tmp, "hash.mel")
            test_path = os.path.join(tmp, "value.txt")
            with open(source_path, "w", encoding="utf-8") as handle:
                handle.write('"#"; some of <word>;')
            with open(test_path, "w", encoding="utf-8") as handle:
                handle.write("#abc")
            result = run_cli([source_path, "--test-file", test_path])
            self.assertEqual(result.returncode, 0)
            self.assertEqual(result.stdout, f"{test_path} matched\n")

    def test_block_comments_and_alphabetic_symbol(self):
        result = run_cli(["-"], '/* ignore this */\nsome of <alphabetic>;\n<alphanumeric>;\n<null>;')
        self.assertEqual(result.returncode, 0)
        self.assertEqual(result.stdout, "[a-zA-Z]+[a-zA-Z0-9]\\0\n")


if __name__ == "__main__":
    unittest.main()
