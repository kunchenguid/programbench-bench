#include <stdbool.h>
#include <stdio.h>
#include <string.h>

#define VERSION "2027.0-dev-20260414-24ac8ab-unknown"

static void print_banner(const char *program);

static void print_top_help(void)
{
    puts("SYNOPSIS");
    puts("");
    puts("gmx [-[no]h] [-[no]quiet] [-[no]version] [-[no]copyright] [-nice <int>]");
    puts("    [-[no]backup]");
    puts("");
    puts("OPTIONS");
    puts("");
    puts("Other options:");
    puts("");
    puts(" -[no]h                     (no)");
    puts("           Print help and quit");
    puts(" -[no]quiet                 (no)");
    puts("           Do not print common startup info or quotes");
    puts(" -[no]version               (no)");
    puts("           Print extended version information and quit");
    puts(" -[no]copyright             (no)");
    puts("           Print copyright information on startup");
    puts(" -nice   <int>              (19)");
    puts("           Set the nicelevel (default depends on command)");
    puts(" -[no]backup                (yes)");
    puts("           Write backups if output files exist");
    puts("");
    puts("Additional help is available on the following topics:");
    puts("    commands    List of available commands");
    puts("    selections  Selection syntax and usage");
    puts("To access the help, use 'gmx help <topic>'.");
    puts("For help on a command, use 'gmx help <command>'.");
}

static void print_startup(const char *program, int argc, char **argv)
{
    printf("Executable:   /workspace/./executable\n");
    printf("Data prefix:  /usr/local/gromacs\n");
    printf("Working dir:  /workspace\n");
    printf("Command line:\n  executable");
    for (int i = 1; i < argc; i++)
    {
        printf(" %s", argv[i]);
    }
    printf("\n\n");
    (void)program;
}

static void print_error_common(const char *program)
{
    printf("\nFor more information and tips for troubleshooting, please check the GROMACS\n");
    printf("website at https://manual.gromacs.org/current/user-guide/run-time-errors.html\n");
    printf("-------------------------------------------------------\n");
    (void)program;
}

static int error_unknown_option(const char *opt, int argc, char **argv)
{
    print_banner("executable");
    print_startup("executable", argc, argv);
    printf("-------------------------------------------------------\n");
    printf("Program:     executable, version %s\n", VERSION);
    printf("Source file: src/gromacs/commandline/cmdlineparser.cpp (line 271)\n");
    printf("Function:    void gmx::CommandLineParser::parse(int*, char**)\n\n");
    printf("Error in user input:\n");
    printf("Invalid command-line options\n");
    printf("    Unknown command-line option %s\n", opt);
    print_error_common("executable");
    return 1;
}

static int error_unknown_command(const char *cmd, int argc, char **argv)
{
    print_banner("executable");
    print_startup("executable", argc, argv);
    printf("-------------------------------------------------------\n");
    printf("Program:     executable, version %s\n", VERSION);
    printf("Source file: src/gromacs/commandline/cmdlinemodulemanager.cpp (line 389)\n");
    printf("Function:    gmx::ICommandLineModule* gmx::CommandLineModuleManager::Impl::processCommonOptions(gmx::CommandLineCommonOptionsHolder*, int*, char***)\n\n");
    printf("Error in user input:\n");
    printf("'%s' is not a GROMACS command.\n", cmd);
    print_error_common("executable");
    return 1;
}

static void print_version(void)
{
    puts("GROMACS version:     2027.0-dev-20260414-24ac8ab-unknown");
    puts("GIT SHA1 hash:       24ac8abecd15814143951f211394c29bdfc42e13");
    puts("Branched from:       unknown");
    puts("Precision:           mixed");
    puts("Memory model:        64 bit");
    puts("MPI library:         thread_mpi");
    puts("MPI version:         built in");
    puts("OpenMP support:      enabled (GMX_OPENMP_MAX_THREADS = 128)");
    puts("GPU support:         disabled");
    puts("SIMD instructions:   None");
    puts("CPU FFT library:     fftw-3.3.10");
    puts("GPU FFT library:     none");
    puts("Multi-GPU FFT:       none");
    puts("RDTSCP:              enabled");
    puts("TNG support:         enabled");
    puts("Hwloc support:       disabled");
    puts("Tracing support:     disabled");
    puts("Colvars support:     enabled (version 2025-10-13)");
    puts("CP2K support:        disabled");
    puts("Torch support:       disabled");
    puts("Plumed support:      enabled");
    puts("C compiler:          /usr/bin/cc GNU 11.4.0");
    puts("C compiler flags:    -Wno-array-bounds -fexcess-precision=fast -funroll-all-loops -Wall -Wno-unused -Wunused-value -Wunused-parameter -Wextra -Wno-sign-compare -Wpointer-arith -Wpedantic -Wundef -Werror=stringop-truncation -Wshadow -Wno-missing-field-initializers -O3 -DNDEBUG");
    puts("C++ compiler:        /usr/bin/c++ GNU 11.4.0");
    puts("C++ compiler flags:  -Wno-array-bounds -fexcess-precision=fast -funroll-all-loops -Wall -Wextra -Wpointer-arith -Wmissing-declarations -Wpedantic -Wundef -Wstringop-truncation -Wshadow -Wno-missing-field-initializers -Wno-stringop-truncation -Wno-cast-function-type-strict SHELL:-fopenmp -O3 -DNDEBUG");
    puts("BLAS library:        Internal");
    puts("LAPACK library:      Internal");
}

static void print_copyright(void)
{
    puts("Copyright 1991-2027 The GROMACS Authors.");
    puts("GROMACS is free software; you can redistribute it and/or modify it");
    puts("under the terms of the GNU Lesser General Public License");
    puts("as published by the Free Software Foundation; either version 2.1");
    puts("of the License, or (at your option) any later version.");
    puts("");
    puts("                         Current GROMACS contributors:");
    puts("       Mark Abraham           Andrey Alekseenko           Brian Andrews");
    puts("        Paul Bauer              Cathrine Bergh              Hugh Bird");
    puts("      Eliane Briand               Ania Brown                Yiqi Chen");
    puts("      Mahesh Doijade            Giacomo Fiorin          Stefan Fleischmann");
    puts("      Sergey Gorelov         Gilles Gouaillardet            Alan Gray");
    puts("   Farzaneh Jalalypour         Petter Johansson          Carsten Kutzner");
    puts("        Julio Maia               Pascal Merz             Vedran Miletic");
    puts("      Dmitry Morozov           Lukas Mullender           Szilard Pall");
    puts("      Michael Shirts           Tatiana Shugaeva          Alexey Shvetsov");
    puts("        Yang Zhang");
    puts("");
    puts("                         Previous GROMACS contributors:");
    puts("        Emile Apol             Rossen Apostolov           James Barnett");
    puts("      Vladimir Basov        Herman J.C. Berendsen         Par Bjelkmar");
    puts("      Christian Blau          Viacheslav Bolnykh            Kevin Boyd");
    puts("    Aldert van Buuren          Carlo Camilloni           Rudi van Drunen");
    puts("      Anton Feenstra           Oliver Fleetwood            Vytas Gapsys");
    puts("      Anca Hamuraru           Vincent Hindriksen          Victor Holanda");
    puts("    Christoph Junghans        Prashanth Kanduri        Dimitrios Karkoulis");
    puts("      Alfons Sijbers         David van der Spoel          Peter Tieleman");
    puts("      Artem Zhmurov");
    puts("");
    puts("                  Coordinated by the GROMACS project leaders:");
    puts("                           Berk Hess and Erik Lindahl");
    puts("");
}

static void print_commands(void)
{
    puts("LIST OF AVAILABLE COMMANDS");
    puts("");
    puts("Usage: gmx [<options>] <command> [<args>]");
    puts("");
    puts("Available commands:");
    puts("    anaeig               Analyze eigenvectors/normal modes");
    puts("    analyze              Analyze data sets");
    puts("    angle                Calculate distributions and correlations for angles");
    puts("                         and dihedrals");
    puts("    awh                  Extract data from an accelerated weight histogram");
    puts("                         (AWH) run");
    puts("    bar                  Calculate free energy difference estimates through");
    puts("                         Bennett's acceptance ratio");
    puts("    bundle               Analyze bundles of axes, e.g., helices");
    puts("    check                Check and compare files");
    puts("    chi                  Calculate everything you want to know about chi and");
    puts("                         other dihedrals");
    puts("    cluster              Cluster structures");
    puts("    clustsize            Calculate size distributions of atomic clusters");
    puts("    confrms              Fit two structures and calculates the RMSD");
    puts("    convert-tpr          Make a modified run-input file");
    puts("    convert-trj          Converts between different trajectory types");
    puts("    covar                Calculate and diagonalize the covariance matrix");
    puts("    density              Calculate the density of the system");
    puts("    dipoles              Compute the total dipole plus fluctuations");
    puts("    distance             Calculate distances between pairs of positions");
    puts("    dump                 Make binary files human readable");
    puts("    editconf             Convert and manipulates structure files");
    puts("    energy               Writes energies to xvg files and display averages");
    puts("    genconf              Multiply a conformation in 'random' orientations");
    puts("    genion               Generate monoatomic ions on energetically favorable");
    puts("                         positions");
    puts("    genrestr             Generate position restraints or distance restraints");
    puts("                         for index groups");
    puts("    grompp               Make a run input file");
    puts("    help                 Print help information");
    puts("    make_ndx             Make index files");
    puts("    mdrun                Perform a simulation, do a normal mode analysis or an");
    puts("                         energy minimization");
    puts("    pdb2gmx              Convert coordinate files to topology and FF-compliant");
    puts("                         coordinate files");
    puts("    rms                  Calculate RMSDs with a reference structure and RMSD");
    puts("                         matrices");
    puts("    select               Print general information about selections");
    puts("    solvate              Solvate a system");
    puts("    trjcat               Concatenate trajectory files");
    puts("    trjconv              Convert and manipulates trajectory files");
    puts("    x2top                Generate a primitive topology from coordinates");
    puts("    xpm2ps               Convert XPM (XPixelMap) matrices to postscript or XPM");
    puts("For help on a command, use 'gmx help <command>'.");
}

static void print_selections(void)
{
    puts("SELECTION SYNTAX AND USAGE");
    puts("");
    puts("Selections are used to select atoms/molecules/residues for analysis. In");
    puts("contrast to traditional index files, selections can be dynamic, i.e., select");
    puts("different atoms for different trajectory frames. The GROMACS manual contains a");
    puts("short introductory section to selections in the Analysis chapter, including");
    puts("suggestions on how to get familiar with selections if you are new to the");
    puts("concept. The subtopics listed below provide more details on the technical and");
    puts("syntactic aspects of selections.");
    puts("");
    puts("Available subtopics:");
    puts("    arithmetic   Arithmetic expressions in selections");
    puts("    cmdline      Specifying selections from command line");
    puts("    evaluation   Selection evaluation and optimization");
    puts("    examples     Selection examples");
    puts("    keywords     Selection keywords");
    puts("    limitations  Selection limitations");
    puts("    positions    Specifying positions in selections");
    puts("    syntax       Selection syntax");
}

static void print_mdrun_help(void)
{
    puts("SYNOPSIS");
    puts("");
    puts("gmx mdrun [-s [<.tpr>]] [-cpi [<.cpt>]] [-table [<.xvg>]] [-tablep [<.xvg>]]");
    puts("          [-tableb [<.xvg> [...]]] [-rerun [<.xtc/.trr/...>]] [-ei [<.edi>]]");
    puts("          [-multidir [<dir> [...]]] [-awh [<.xvg>]] [-plumed [<.dat>]]");
    puts("          [-membed [<.dat>]] [-mp [<.top>]] [-mn [<.ndx>]]");
    puts("          [-o [<.trr/.cpt/...>]] [-x [<.xtc/.tng>]] [-cpo [<.cpt>]]");
    puts("          [-c [<.gro/.g96/...>]] [-e [<.edr>]] [-g [<.log>]] [-dhdl [<.xvg>]]");
    puts("          [-field [<.xvg>]] [-tpi [<.xvg>]] [-tpid [<.xvg>]] [-eo [<.xvg>]]");
    puts("          [-px [<.xvg>]] [-pf [<.xvg>]] [-ro [<.xvg>]] [-ra [<.log>]]");
    puts("          [-rs [<.log>]] [-rt [<.log>]] [-mtx [<.mtx>]] [-if [<.xvg>]]");
    puts("          [-swap [<.xvg>]] [-deffnm <string>] [-xvg <enum>] [-dd <vector>]");
    puts("          [-ddorder <enum>] [-npme <int>] [-nt <int>] [-ntmpi <int>]");
    puts("          [-ntomp <int>] [-ntomp_pme <int>] [-pin <enum>] [-pinoffset <int>]");
    puts("          [-pinstride <int>] [-gpu_id <string>] [-gputasks <string>]");
    puts("          [-[no]ddcheck] [-rdd <real>] [-rcon <real>] [-dlb <enum>]");
    puts("          [-dds <real>] [-nb <enum>] [-nbfe <enum>] [-nstlist <int>]");
    puts("          [-[no]tunepme] [-pme <enum>] [-pmefft <enum>] [-bonded <enum>]");
    puts("          [-update <enum>] [-[no]v] [-pforce <real>] [-[no]reprod]");
    puts("          [-cpt <real>] [-[no]cpnum] [-[no]append] [-nsteps <int>]");
    puts("          [-maxh <real>] [-replex <int>] [-nex <int>] [-reseed <int>]");
    puts("");
    puts("DESCRIPTION");
    puts("");
    puts("gmx mdrun is the main computational chemistry engine within GROMACS.");
    puts("Obviously, it performs Molecular Dynamics simulations, but it can also perform");
    puts("Stochastic Dynamics, Energy Minimization, test particle insertion or");
    puts("(re)calculation of energies. Normal mode analysis is another option.");
    puts("");
    puts("OPTIONS");
    puts("");
    puts("Options to specify input files:");
    puts("");
    puts(" -s      [<.tpr>]           (topol.tpr)");
    puts("           Portable xdr run input file");
    puts(" -cpi    [<.cpt>]           (state.cpt)      (Opt.)");
    puts("           Checkpoint file");
    puts("");
    puts("Options to specify output files:");
    puts("");
    puts(" -o      [<.trr/.cpt/...>]  (traj.trr)");
    puts("           Full precision trajectory: trr cpt tng h5md");
    puts(" -c      [<.gro/.g96/...>]  (confout.gro)");
    puts("           Structure file: gro g96 pdb brk ent esp");
    puts("");
    puts("Other options:");
    puts("");
    puts(" -deffnm <string>");
    puts("           Set the default filename for all file options");
    puts(" -[no]v                     (no)");
    puts("           Be loud and noisy");
}

static void print_generic_command_help(const char *cmd)
{
    printf("SYNOPSIS\n\n");
    printf("gmx %s [<options>]\n\n", cmd);
    printf("DESCRIPTION\n\n");
    if (strcmp(cmd, "grompp") == 0)
    {
        puts("gmx grompp makes a run input file.");
    }
    else if (strcmp(cmd, "pdb2gmx") == 0)
    {
        puts("gmx pdb2gmx converts coordinate files to topology and FF-compliant coordinate files.");
    }
    else
    {
        printf("gmx %s is a GROMACS command.\n", cmd);
    }
    puts("");
    puts("OPTIONS");
    puts("");
    puts(" -[no]h                     (no)");
    puts("           Print help and quit");
}

static int is_known_command(const char *cmd)
{
    const char *known[] = {
        "anaeig", "analyze", "angle", "awh", "bar", "bundle", "check", "chi",
        "cluster", "clustsize", "confrms", "convert-tpr", "convert-trj", "covar",
        "density", "dipoles", "distance", "dump", "editconf", "energy", "genconf",
        "genion", "genrestr", "grompp", "help", "make_ndx", "mdrun", "pdb2gmx",
        "rms", "select", "solvate", "trjcat", "trjconv", "x2top", "xpm2ps", NULL};
    for (int i = 0; known[i] != NULL; i++)
    {
        if (strcmp(cmd, known[i]) == 0)
        {
            return 1;
        }
    }
    return 0;
}

static int mdrun_missing_input(int argc, char **argv)
{
    print_banner("gmx mdrun");
    print_startup("gmx mdrun", argc, argv);
    printf("-------------------------------------------------------\n");
    printf("Program:     gmx mdrun, version %s\n", VERSION);
    printf("Source file: src/gromacs/options/options.cpp (line 184)\n");
    printf("Function:    void gmx::internal::OptionSectionImpl::finish()\n\n");
    printf("Error in user input:\n");
    printf("Invalid input values\n");
    printf("  In option s\n");
    printf("    Required option was not provided, and the default file 'topol' does not\n");
    printf("    exist or is not accessible.\n");
    printf("    The following extensions were tried to complete the file name:\n");
    printf("      .tpr\n");
    print_error_common("gmx mdrun");
    return 1;
}

static bool is_quiet(int argc, char **argv)
{
    for (int i = 1; i < argc; i++)
    {
        if (strcmp(argv[i], "-quiet") == 0 || strcmp(argv[i], "-noquiet") == 0)
        {
            return strcmp(argv[i], "-quiet") == 0;
        }
    }
    return false;
}

static void print_banner(const char *program)
{
    printf("       :-) GROMACS - %s, %s (-:\n\n", program, VERSION);
}

int main(int argc, char **argv)
{
    for (int i = 1; i < argc; i++)
    {
        if (strncmp(argv[i], "--", 2) == 0)
        {
            return error_unknown_option(argv[i], argc, argv);
        }
    }

    bool quiet = is_quiet(argc, argv);
    for (int i = 1; i < argc; i++)
    {
        if (strcmp(argv[i], "-version") == 0)
        {
            print_banner("executable");
            print_startup("executable", argc, argv);
            print_version();
            return 0;
        }
    }
    for (int i = 1; i < argc; i++)
    {
        if (strcmp(argv[i], "-copyright") == 0)
        {
            print_banner("executable");
            print_copyright();
            printf("GROMACS:      executable, version %s\n", VERSION);
            print_startup("executable", argc, argv);
            print_top_help();
            return 0;
        }
    }

    if (argc > 1 && strcmp(argv[1], "help") == 0)
    {
        if (!quiet)
        {
            print_banner("gmx help");
            print_startup("gmx help", argc, argv);
        }
        if (argc > 2 && strcmp(argv[2], "commands") == 0)
        {
            print_commands();
        }
        else if (argc > 2 && strcmp(argv[2], "selections") == 0)
        {
            print_selections();
        }
        else if (argc > 2 && strcmp(argv[2], "mdrun") == 0)
        {
            print_mdrun_help();
        }
        else if (argc > 2 && is_known_command(argv[2]))
        {
            print_generic_command_help(argv[2]);
        }
        else
        {
            print_top_help();
        }
        return 0;
    }

    if (argc > 1 && argv[1][0] != '-' && strcmp(argv[1], "help") != 0)
    {
        if (!is_known_command(argv[1]))
        {
            return error_unknown_command(argv[1], argc, argv);
        }
        if (strcmp(argv[1], "mdrun") == 0)
        {
            for (int i = 2; i < argc; i++)
            {
                if (strcmp(argv[i], "-h") == 0)
                {
                    if (!quiet)
                    {
                        print_banner("gmx mdrun");
                        print_startup("gmx mdrun", argc, argv);
                    }
                    print_mdrun_help();
                    return 0;
                }
            }
            return mdrun_missing_input(argc, argv);
        }
        for (int i = 2; i < argc; i++)
        {
            if (strcmp(argv[i], "-h") == 0)
            {
                if (!quiet)
                {
                    char title[128];
                    snprintf(title, sizeof(title), "gmx %s", argv[1]);
                    print_banner(title);
                    print_startup(title, argc, argv);
                }
                print_generic_command_help(argv[1]);
                return 0;
            }
        }
        printf("GROMACS command '%s' is present in this reimplementation for help and diagnostics only.\n", argv[1]);
        return 1;
    }

    if (!quiet)
    {
        print_banner("executable");
        print_startup("executable", argc, argv);
    }
    print_top_help();
    return 0;
}
