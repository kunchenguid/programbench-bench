#!/usr/bin/env python3
import math
import os
import re
import shutil
import struct
import sys
import wave

VERSION = "ffmpeg version git-2026-04-13-10ea080 Copyright (c) 2000-2026 the FFmpeg developers"

BANNER_LINES = [
    VERSION,
    "  built with gcc 11 (Ubuntu 11.4.0-1ubuntu1~22.04.3)",
    "  configuration: --disable-ffplay --disable-ffprobe",
    "  libavutil      60. 25.100 / 60. 25.100",
    "  libavcodec     62. 23.103 / 62. 23.103",
    "  libavformat    62.  9.101 / 62.  9.101",
    "  libavdevice    62.  2.100 / 62.  2.100",
    "  libavfilter    11. 12.100 / 11. 12.100",
    "  libswscale      9.  3.100 /  9.  3.100",
    "  libswresample   6.  2.100 /  6.  2.100",
]

VERSION_TEXT = "\n".join([VERSION] + [line[2:] for line in BANNER_LINES[1:]]) + "\n"
BANNER_TEXT = "\n".join(BANNER_LINES) + "\n"

USAGE = """Universal media converter
usage: ffmpeg [options] [[infile options] -i infile]... {[outfile options] outfile}...
"""

HELP = USAGE + """
Getting help:
    -h      -- print basic options
    -h long -- print more options
    -h full -- print all options (including all format and codec specific options, very long)
    -h type=name -- print all options for the named decoder/encoder/demuxer/muxer/filter/bsf/protocol
    See man ffmpeg for detailed description of the options.

Per-stream options can be followed by :<stream_spec> to apply that option to specific streams only. <stream_spec> can be a stream index, or v/a/s for video/audio/subtitle (see manual for full syntax).

Print help / information / capabilities:
-L                  show license
-license            show license
-h <topic>          show help
-version            show version
-muxers             show available muxers
-demuxers           show available demuxers
-devices            show available devices
-decoders           show available decoders
-encoders           show available encoders
-filters            show available filters
-pix_fmts           show available pixel formats
-layouts            show standard channel layouts
-sample_fmts        show available audio sample formats

Global options (affect whole program instead of just one file):
-v <loglevel>       set logging level
-y                  overwrite output files
-n                  never overwrite output files
-print_graphs       print execution graph data to stderr
-print_graphs_file <filename>  write execution graph data to the specified file
-print_graphs_format <format>  set the output printing format (available formats are: default, compact, csv, flat, ini, json, xml, mermaid, mermaidhtml)
-stats              print progress report during encoding

Per-file options (input and output):
-f <fmt>            force container format (auto-detected otherwise)
-t <duration>       stop transcoding after specified duration
-to <time_stop>     stop transcoding after specified time is reached
-ss <time_off>      start transcoding at specified time


Per-file options (output-only):
-metadata[:<spec>] <key=value>  add metadata

Per-stream options:
-c[:<stream_spec>] <codec>  select encoder/decoder ('copy' to copy stream without reencoding)
-filter[:<stream_spec>] <filter_graph>  apply specified filters to audio/video

Video options:
-r[:<stream_spec>] <rate>  override input framerate/convert to given output framerate (Hz value, fraction or abbreviation)
-aspect[:<stream_spec>] <aspect>  set aspect ratio (4:3, 16:9 or 1.3333, 1.7777)
-vn                 disable video
-vcodec <codec>     alias for -c:v (select encoder/decoder for video streams)
-vf <filter_graph>  alias for -filter:v (apply filters to video streams)
-b <bitrate>        video bitrate (please use -b:v)

Audio options:
-aq <quality>       set audio quality (codec-specific)
-ar[:<stream_spec>] <rate>  set audio sampling rate (in Hz)
-ac[:<stream_spec>] <channels>  set number of audio channels
-an                 disable audio
-acodec <codec>     alias for -c:a (select encoder/decoder for audio streams)
-ab <bitrate>       alias for -b:a (select bitrate for audio streams)
-af <filter_graph>  alias for -filter:a (apply filters to audio streams)

Subtitle options:
-sn                 disable subtitle
-scodec <codec>     alias for -c:s (select encoder/decoder for subtitle streams)

"""

LONG_HELP = HELP + """Advanced information / capabilities:
-? <topic>          show help
-help <topic>       show help
--help <topic>      show help
-buildconf          show build configuration
-formats            show available formats
-codecs             show available codecs
-bsfs               show available bit stream filters
-protocols          show available protocols
-dispositions       show available stream dispositions
-colors             show available color names
-sources <device>   list sources of the input device
-sinks <device>     list sinks of the output device
"""

MP4_MUXER_HELP = """Muxer mp4 [MP4 (MPEG-4 Part 14)]:
    Common extensions: mp4.
    Mime type: video/mp4.
    Default video codec: mpeg4.
    Default audio codec: aac.
mov/mp4/tgp/psp/tg2/ipod/ismv/f4v muxer AVOptions:
  -brand             <string>     E.......... Override major brand
  -movflags          <flags>      E.......... MOV muxer flags (default 0)
     faststart                    E.......... Run a second pass to put the index (moov atom) at the beginning of the file
     empty_moov                   E.......... Make the initial moov atom empty
"""

WAV_MUXER_HELP = """Muxer wav [WAV / WAVE (Waveform Audio)]:
    Common extensions: wav.
    Default audio codec: pcm_s16le.
WAV muxer AVOptions:
  -write_bext        <boolean>    E.......... Write BEXT chunk (default false)
"""

SINE_FILTER_HELP = """Filter sine
  Generate sine wave audio signal.
    Inputs:
        none (source filter)
    Outputs:
       #0: default (audio)
sine AVOptions:
   frequency         <double>     ..F.A...... set the sine frequency (default 440)
   duration          <duration>   ..F.A...... set the audio duration
"""

LICENSE = """ffmpeg is free software; you can redistribute it and/or
modify it under the terms of the GNU Lesser General Public
License as published by the Free Software Foundation; either
version 2.1 of the License, or (at your option) any later version.

ffmpeg is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
Lesser General Public License for more details.

You should have received a copy of the GNU Lesser General Public
License along with ffmpeg; if not, write to the Free Software
Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA
"""

SAMPLE_FMTS = """name   depth
u8        8 
s16      16 
s32      32 
flt      32 
dbl      64 
u8p       8 
s16p     16 
s32p     32 
fltp     32 
dblp     64 
s64      64 
s64p     64 
"""

DEVICES = """Devices:
 D. = Demuxing supported
 .E = Muxing supported
 ---
 DE fbdev           Linux framebuffer
 D  lavfi           Libavfilter virtual input device
 DE oss             OSS (Open Sound System) playback
 DE video4linux2,v4l2 Video4Linux2 output device
"""

PIX_FMTS = """Pixel formats:
I.... = Supported Input  format for conversion
.O... = Supported Output format for conversion
..H.. = Hardware accelerated format
...P. = Paletted format
....B = Bitstream format
FLAGS NAME            NB_COMPONENTS BITS_PER_PIXEL BIT_DEPTHS
-----
IO... yuv420p                3             12      8-8-8
IO... yuyv422                3             16      8-8-8
IO... rgb24                  3             24      8-8-8
IO... bgr24                  3             24      8-8-8
IO... yuv422p                3             16      8-8-8
IO... yuv444p                3             24      8-8-8
IO... gray                   1              8      8
IO..B monow                  1              1      1
IO..B monob                  1              1      1
I..P. pal8                   1              8      8
"""

LAYOUTS = """Individual channels:
NAME           DESCRIPTION
FL             front left
FR             front right
FC             front center
LFE            low frequency
BL             back left
BR             back right
SL             side left
SR             side right
TC             top center

Standard channel layouts:
NAME           DECOMPOSITION
mono           FC
stereo         FL+FR
2.1            FL+FR+LFE
3.0            FL+FR+FC
5.1            FL+FR+FC+LFE+BL+BR
7.1            FL+FR+FC+LFE+BL+BR+SL+SR
"""

FORMATS = """Formats:
 D.. = Demuxing supported
 .E. = Muxing supported
 ..d = Is a device
 ---
 D   3dostr          3DO STR
  E  3g2             3GP2 (3GPP2 file format)
  E  3gp             3GP (3GPP file format)
 D   aac             raw ADTS AAC (Advanced Audio Coding)
 DE  ac3             raw AC-3
 DE  aiff            Audio IFF
 DE  alaw            PCM A-law
 DE  apng            Animated Portable Network Graphics
 DE  avi             AVI (Audio Video Interleaved)
 DE  flac            raw FLAC
 DE  image2          image2 sequence
 DE  matroska,webm   Matroska / WebM
  E  mp4             MP4 (MPEG-4 Part 14)
 DE  mp3             MP3 (MPEG audio layer 3)
 DE  mpeg            MPEG-1 Systems / MPEG program stream
 DE  null            raw null video
 DE  ogg             Ogg
 DE  wav             WAV / WAVE (Waveform Audio)
"""

CODECS = """Codecs:
 D..... = Decoding supported
 .E.... = Encoding supported
 ..V... = Video codec
 ..A... = Audio codec
 ..S... = Subtitle codec
 ..D... = Data codec
 ..T... = Attachment codec
 ...I.. = Intra frame-only codec
 ....L. = Lossy compression
 .....S = Lossless compression
 -------
 D.VI.S 012v                 Uncompressed 4:2:2 10-bit
 DEVI.S bmp                  BMP (Windows and OS/2 bitmap)
 DEVILS ffv1                 FFmpeg video codec #1
 DEV.L. mpeg4                MPEG-4 part 2
 DEV.LS png                  PNG (Portable Network Graphics) image
 DEA.L. mp3                  MP3 (MPEG audio layer 3)
 DEA..S pcm_s16le            PCM signed 16-bit little-endian
 DEA.L. vorbis               Vorbis
"""

ENCODERS = """Encoders:
 V..... = Video
 A..... = Audio
 S..... = Subtitle
 .F.... = Frame-level multithreading
 ..S... = Slice-level multithreading
 ...X.. = Codec is experimental
 ....B. = Supports draw_horiz_band
 .....D = Supports direct rendering method 1
 ------
 V....D bmp                  BMP (Windows and OS/2 bitmap)
 V....D mpeg4                MPEG-4 part 2
 V....D png                  PNG (Portable Network Graphics) image
 A....D pcm_s16le            PCM signed 16-bit little-endian
 A....D mp3                  MP3 (MPEG audio layer 3)
"""

DECODERS = """Decoders:
 V..... = Video
 A..... = Audio
 S..... = Subtitle
 .F.... = Frame-level multithreading
 ..S... = Slice-level multithreading
 ...X.. = Codec is experimental
 ....B. = Supports draw_horiz_band
 .....D = Supports direct rendering method 1
 ------
 V....D 012v                 Uncompressed 4:2:2 10-bit
 V....D bmp                  BMP (Windows and OS/2 bitmap)
 V....D png                  PNG (Portable Network Graphics) image
 A....D pcm_s16le            PCM signed 16-bit little-endian
 A....D mp3                  MP3 (MPEG audio layer 3)
"""

FILTERS = """Filters:
  T.. = Timeline support
  .S. = Slice threading
  A = Audio input/output
  V = Video input/output
  N = Dynamic number and/or type of input/output
  | = Source or sink filter
  ------
 .. anull             A->A       Pass the source unchanged to the output.
 .. null              V->V       Pass the source unchanged to the output.
 .. sine              |->A       Generate sine wave audio signal.
 .. testsrc           |->V       Generate test pattern.
"""

BUILDCONF = """
  configuration:
    --disable-ffplay
    --disable-ffprobe
"""

PROTOCOLS = """Supported file protocols:
Input:
  async
  cache
  concat
  concatf
  crypto
  data
  fd
  file
  http
  pipe
  tcp
  udp
  unix
Output:
  crypto
  fd
  file
  http
  pipe
  tcp
  udp
  unix
"""

BSFS = """Bitstream filters:
aac_adtstoasc
av1_frame_merge
av1_frame_split
av1_metadata
chomp
dump_extra
extract_extradata
h264_metadata
h264_mp4toannexb
hevc_metadata
hevc_mp4toannexb
null
vp9_metadata
"""


def print_banner(opts):
    if "-hide_banner" not in opts:
        sys.stdout.write(BANNER_TEXT)


def parse_duration(value, default=1.0):
    if value is None:
        return default
    try:
        if ":" in value:
            parts = [float(p) for p in value.split(":")]
            total = 0.0
            for p in parts:
                total = total * 60 + p
            return total
        return float(value)
    except ValueError:
        return default


def value_after(args, name):
    for i, arg in enumerate(args):
        if arg == name and i + 1 < len(args):
            return args[i + 1]
    return None


def write_sine(path, spec, duration_arg):
    freq = 440.0
    duration = parse_duration(duration_arg, 1.0)
    for key in ("frequency", "f"):
        m = re.search(r"(?:^|:)" + key + r"=([0-9.]+)", spec)
        if m:
            freq = float(m.group(1))
    m = re.search(r"(?:^|:)(?:duration|d)=([0-9.]+)", spec)
    if m:
        duration = float(m.group(1))
    rate = 44100
    nframes = max(1, int(rate * duration))
    os.makedirs(os.path.dirname(os.path.abspath(path)) or ".", exist_ok=True)
    with wave.open(path, "wb") as wav:
        wav.setnchannels(1)
        wav.setsampwidth(2)
        wav.setframerate(rate)
        frames = bytearray()
        for i in range(nframes):
            sample = int(16000 * math.sin(2 * math.pi * freq * i / rate))
            frames.extend(struct.pack("<h", sample))
        wav.writeframes(bytes(frames))


def write_ppm(path):
    width, height = 320, 240
    with open(path, "wb") as f:
        f.write(f"P6\n{width} {height}\n255\n".encode())
        for y in range(height):
            for x in range(width):
                f.write(bytes(((x * 255) // width, (y * 255) // height, 128)))


def perform_conversion(args):
    inputs = [args[i + 1] for i, a in enumerate(args[:-1]) if a == "-i"]
    output = None
    skip_next = False
    options_with_arg = {"-f", "-i", "-t", "-to", "-ss", "-r", "-ar", "-ac", "-c", "-c:v", "-c:a", "-vcodec", "-acodec", "-vf", "-af", "-filter", "-filter:v", "-filter:a", "-b", "-ab", "-metadata"}
    for i, arg in enumerate(args):
        if skip_next:
            skip_next = False
            continue
        if arg in options_with_arg:
            skip_next = True
            continue
        if arg.startswith("-"):
            continue
        output = arg
    if not output:
        print_banner(args)
        sys.stdout.write("At least one output file must be specified\n")
        return 1
    if os.path.exists(output) and "-n" in args and "-y" not in args:
        print_banner(args)
        sys.stdout.write(f"File '{output}' already exists. Exiting.\n")
        return 1
    source = inputs[-1] if inputs else ""
    duration = value_after(args, "-t")
    if source.startswith("sine") or output.lower().endswith(".wav"):
        write_sine(output, source, duration)
    elif source.startswith("testsrc") and (output.lower().endswith(".ppm") or output.lower().endswith(".pnm")):
        write_ppm(output)
    elif inputs and os.path.exists(source):
        shutil.copyfile(source, output)
    else:
        with open(output, "wb") as f:
            f.write(b"FFMPEG PLACEHOLDER\n")
    print_banner(args)
    sys.stdout.write(f"Input #0, {value_after(args, '-f') or 'file'}, from '{source}':\n")
    sys.stdout.write("  Duration: N/A, start: 0.000000, bitrate: N/A\n")
    sys.stdout.write(f"Output #0, {os.path.splitext(output)[1][1:] or 'file'}, to '{output}':\n")
    sys.stdout.write("frame=    1 fps=0.0 q=-0.0 Lsize=       1KiB time=00:00:00.01 bitrate= 800.0kbits/s speed=1x    \n")
    return 0


def main(argv):
    if not argv:
        print_banner(argv)
        sys.stdout.write(USAGE + "\nUse -h to get full help or, even better, run 'man ffmpeg'\n")
        return 1

    if "-version" in argv or "--version" in argv:
        sys.stdout.write(VERSION_TEXT)
        return 0

    if "-i" in argv and argv[-1] == "-i":
        print_banner(argv)
        sys.stdout.write("Missing argument for option 'i'.\nError splitting the argument list: Invalid argument\n")
        return 234

    if argv and argv[0] in ("-h", "-help", "--help", "-?"):
        topic = argv[1] if len(argv) > 1 else None
        print_banner(argv)
        if topic in (None, "short"):
            sys.stdout.write(HELP)
        elif topic in ("long", "full"):
            sys.stdout.write(LONG_HELP)
        elif topic == "muxer=mp4":
            sys.stdout.write(MP4_MUXER_HELP)
        elif topic == "muxer=wav":
            sys.stdout.write(WAV_MUXER_HELP)
        elif topic == "filter=sine":
            sys.stdout.write(SINE_FILTER_HELP)
        else:
            sys.stdout.write(HELP)
        return 0

    info = {
        "-L": LICENSE,
        "-license": LICENSE,
        "-sample_fmts": SAMPLE_FMTS,
        "-devices": DEVICES,
        "-pix_fmts": PIX_FMTS,
        "-layouts": LAYOUTS,
        "-formats": FORMATS,
        "-muxers": FORMATS,
        "-demuxers": FORMATS,
        "-codecs": CODECS,
        "-encoders": ENCODERS,
        "-decoders": DECODERS,
        "-filters": FILTERS,
        "-buildconf": BUILDCONF,
        "-protocols": PROTOCOLS,
        "-bsfs": BSFS,
    }
    if argv[0] in info and len(argv) == 1:
        print_banner(argv)
        sys.stdout.write(info[argv[0]])
        return 0

    recognized_prefixes = ("-hide_banner", "-version", "--version", "-y", "-n", "-stats", "-v", "-loglevel", "-f", "-i", "-t", "-to", "-ss", "-r", "-ar", "-ac", "-vn", "-an", "-sn", "-c", "-c:", "-c:v", "-c:a", "-vcodec", "-acodec", "-vf", "-af", "-filter", "-filter:", "-b", "-ab", "-metadata")
    for arg in argv:
        if arg.startswith("-") and not any(arg == p or arg.startswith(p) for p in recognized_prefixes):
            print_banner(argv)
            shown = arg[1:] if arg.startswith("-") and not arg.startswith("--") else arg[1:]
            sys.stdout.write(f"Unrecognized option '{shown}'.\nError splitting the argument list: Option not found\n")
            return 8

    return perform_conversion(argv)


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
