import os
import subprocess
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
EXE = Path(os.environ.get("CANDIDATE", ROOT / "candidate"))


def run_cmd(args, cwd=None):
    return subprocess.run([str(EXE), *args], cwd=cwd or ROOT, text=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)


def test_version_matches_documented_build_identity():
    r = run_cmd(["-version"])
    assert r.returncode == 0
    assert r.stdout.startswith("ffmpeg version git-2026-04-13-10ea080 Copyright (c) 2000-2026 the FFmpeg developers\n")
    assert "configuration: --disable-ffplay --disable-ffprobe" in r.stdout
    assert "libavformat    62.  9.101 / 62.  9.101" in r.stdout


def test_no_args_prints_short_usage_and_fails():
    r = run_cmd([])
    assert r.returncode == 1
    assert "Universal media converter" in r.stdout
    assert "usage: ffmpeg [options] [[infile options] -i infile]... {[outfile options] outfile}..." in r.stdout
    assert "Use -h to get full help or, even better, run 'man ffmpeg'" in r.stdout


def test_basic_help_lists_core_option_groups():
    r = run_cmd(["-h"])
    assert r.returncode == 0
    for text in ["Getting help:", "Print help / information / capabilities:", "Global options", "Video options", "Audio options", "Subtitle options"]:
        assert text in r.stdout
    assert "-sample_fmts        show available audio sample formats" in r.stdout


def test_unknown_option_uses_ffmpeg_error_wording():
    r = run_cmd(["--bogus"])
    assert r.returncode == 8
    assert "Unrecognized option '-bogus'." in r.stdout
    assert "Error splitting the argument list: Option not found" in r.stdout


def test_lavfi_sine_can_write_a_wav_file():
    with tempfile.TemporaryDirectory() as td:
        out = Path(td) / "tone.wav"
        r = run_cmd(["-f", "lavfi", "-i", "sine=frequency=440:duration=0.05", str(out)])
        assert r.returncode == 0
        data = out.read_bytes()
        assert data[:4] == b"RIFF"
        assert data[8:12] == b"WAVE"
        assert len(data) > 100


def test_hide_banner_version_still_prints_plain_version():
    r = run_cmd(["-hide_banner", "-version"])
    assert r.returncode == 0
    assert r.stdout.startswith("ffmpeg version git-2026-04-13-10ea080")
    assert "  built with" not in r.stdout
    assert "built with gcc 11" in r.stdout


def test_sample_formats_and_devices_include_expected_tables():
    sample = run_cmd(["-sample_fmts"])
    assert sample.returncode == 0
    assert "name   depth" in sample.stdout
    assert "s16      16" in sample.stdout
    devices = run_cmd(["-devices"])
    assert devices.returncode == 0
    assert "Devices:" in devices.stdout
    assert "D  lavfi           Libavfilter virtual input device" in devices.stdout


def test_file_input_copy_creates_output_bytes():
    with tempfile.TemporaryDirectory() as td:
        src = Path(td) / "in.bin"
        out = Path(td) / "out.bin"
        src.write_bytes(b"abc123")
        r = run_cmd(["-i", str(src), "-c", "copy", str(out)])
        assert r.returncode == 0
        assert out.read_bytes() == b"abc123"


def test_buildconf_protocols_and_bsfs_are_reported():
    build = run_cmd(["-buildconf"])
    assert build.returncode == 0
    assert "configuration:" in build.stdout
    assert "--disable-ffplay" in build.stdout
    protocols = run_cmd(["-protocols"])
    assert protocols.returncode == 0
    assert "Supported file protocols:" in protocols.stdout
    assert "Input:" in protocols.stdout
    assert "  file" in protocols.stdout
    bsfs = run_cmd(["-bsfs"])
    assert bsfs.returncode == 0
    assert "Bitstream filters:" in bsfs.stdout
    assert "aac_adtstoasc" in bsfs.stdout


def test_topic_help_accepts_long_and_muxer_queries():
    long_help = run_cmd(["-h", "long"])
    assert long_help.returncode == 0
    assert "Advanced information / capabilities:" in long_help.stdout
    muxer = run_cmd(["-h", "muxer=mp4"])
    assert muxer.returncode == 0
    assert "Muxer mp4 [MP4 (MPEG-4 Part 14)]:" in muxer.stdout
    assert "Default video codec: mpeg4." in muxer.stdout
