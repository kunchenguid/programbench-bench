#!/usr/bin/env python3
import os
import sys
from datetime import datetime, timezone


VERSION = "gittype 0.8.0"

LONG_HELP = """GitType turns your own source code into typing challenges. Practice typing by using functions, classes, and methods from your actual projects. 

Examples:
  gittype                           # Use current directory
  gittype /path/to/repo             # Use specific repository
  gittype --repo owner/repo         # Clone and use GitHub repository
  gittype --langs rust,python       # Filter by languages

Usage: executable [OPTIONS] [REPO_PATH] [COMMAND]

Commands:
  history   Show session history
  stats     Show analytics
  export    Export session data
  cache     Manage challenge cache
  repo      Manage repositories
  trending  Select and practice with trending repositories from GitHub
  help      Print this message or the help of the given subcommand(s)

Arguments:
  [REPO_PATH]
          Repository path to extract code from

Options:
      --repo <REPO>
          GitHub repository URL or path to clone and play with. Supports formats:
            - owner/repo
            - https://github.com/owner/repo
            - git@github.com:owner/repo.git

      --langs <LANGS>
          Filter by programming languages (comma-separated). Supported languages:
            rust, typescript, javascript, python, ruby, go, swift, kotlin, java, php, csharp, c, cpp, haskell, dart, scala, zig
            Example: --langs rust,python,typescript

  -h, --help
          Print help (see a summary with '-h')

  -V, --version
          Print version
"""

SHORT_HELP = """A typing practice tool using your own code repositories - extracts all code chunks (functions, classes, methods, etc.)

Usage: executable [OPTIONS] [REPO_PATH] [COMMAND]

Commands:
  history   Show session history
  stats     Show analytics
  export    Export session data
  cache     Manage challenge cache
  repo      Manage repositories
  trending  Select and practice with trending repositories from GitHub
  help      Print this message or the help of the given subcommand(s)

Arguments:
  [REPO_PATH]  Repository path to extract code from

Options:
      --repo <REPO>    GitHub repository URL or path to clone and play with
      --langs <LANGS>  Filter by programming languages (comma-separated)
  -h, --help           Print help (see more with '--help')
  -V, --version        Print version
"""

CACHE_HELP = """Manage challenge cache

Usage: executable cache <COMMAND>

Commands:
  stats  Show cache statistics
  clear  Clear all cached challenges
  list   List cached repository keys
  help   Print this message or the help of the given subcommand(s)

Options:
  -h, --help  Print help
"""

REPO_HELP = """Manage repositories

Usage: executable repo <COMMAND>

Commands:
  list   List all cached repositories
  clear  Clear all cached repositories
  play   Play a cached repository interactively
  help   Print this message or the help of the given subcommand(s)

Options:
  -h, --help  Print help
"""

EXPORT_HELP = """Export session data

Usage: executable export [OPTIONS]

Options:
      --format <FORMAT>  Export format [default: json]
      --output <OUTPUT>  Output file path
  -h, --help             Print help
"""

TRENDING_HELP = """Select and practice with trending repositories from GitHub

Usage: executable trending [OPTIONS] [LANGUAGE] [REPO_NAME]

Arguments:
  [LANGUAGE]
          Programming language to filter trending repositories.
          Supported languages: C, C#, C++, Dart, Go, Haskell, Java, JavaScript, Kotlin, PHP, Python, Ruby, Rust, Scala, Swift, TypeScript, Zig

  [REPO_NAME]
          Specific repository name to select from trending list

Options:
      --period <PERIOD>
          Time period for trending (daily, weekly, monthly)
          
          [default: daily]

  -h, --help
          Print help (see a summary with '-h')
"""

SUPPORTED_LANGUAGE_ALIASES = {
    "rust", "rs", "typescript", "ts", "javascript", "js", "python", "py",
    "ruby", "rb", "go", "swift", "kotlin", "kt", "java", "php", "csharp",
    "cs", "c#", "c", "cpp", "c++", "haskell", "hs", "dart", "scala", "sc",
    "zig", "clojure", "clj", "cljs",
}


def out(text: str = "") -> None:
    sys.stdout.write(text)


def err(text: str = "") -> None:
    sys.stderr.write(text)


def unsupported_languages(value: str) -> int:
    requested = [part.strip() for part in value.split(",") if part.strip()]
    bad = [part for part in requested if part.lower() not in SUPPORTED_LANGUAGE_ALIASES]
    if not bad:
        return 0
    err("❌ Unsupported language(s): " + ", ".join(bad) + "\n")
    err("💡 Supported languages:\n")
    err("   rust, rs, typescript, ts, javascript, js\n")
    err("   python, py, ruby, rb, go, swift\n")
    err("   kotlin, kt, java, php, csharp, cs\n")
    err("   c#, c, cpp, c++, haskell, hs\n")
    err("   dart, scala, sc, zig, clojure, clj\n")
    err("   cljs\n")
    return 1


def terminal_error(argv: list[str]) -> int:
    now = datetime.now(timezone.utc)
    stamp = now.strftime("%Y%m%d_%H%M%S")
    name = f"gittype_error_{stamp}.log"
    msg = "Terminal error: Failed to create terminal: Resource temporarily unavailable (os error 11)"
    try:
        with open(name, "a", encoding="utf-8") as handle:
            handle.write(f"ERROR OCCURRED AT: {now.strftime('%Y-%m-%d %H:%M:%S')} UTC\n")
            handle.write('ERROR TYPE: "gittype::domain::error::GitTypeError"\n')
            handle.write(f"ERROR MESSAGE: {msg}\n")
            handle.write(f'EXECUTABLE: "{os.path.abspath(sys.argv[0])}"\n')
            handle.write(f'WORKING_DIR: "{os.getcwd()}"\n')
            handle.write("COMMAND_ARGS: " + repr([sys.argv[0], *argv]).replace("'", '"') + "\n")
            handle.write(f"OS: {sys.platform}\nARCH: x86_64\n\n")
    except OSError:
        pass
    err(f"💾 Error details written to: {name}\n")
    err(f"Error: {msg}\n")
    return 1


def parse_export(args: list[str]) -> int:
    if any(a in ("-h", "--help") for a in args):
        out(EXPORT_HELP)
        return 0
    fmt = "json"
    output = None
    i = 0
    while i < len(args):
        arg = args[i]
        if arg == "--format":
            if i + 1 >= len(args):
                err("error: a value is required for '--format <FORMAT>' but none was supplied\n\n")
                err("For more information, try '--help'.\n")
                return 2
            fmt = args[i + 1]
            i += 2
        elif arg == "--output":
            if i + 1 >= len(args):
                err("error: a value is required for '--output <OUTPUT>' but none was supplied\n\n")
                err("For more information, try '--help'.\n")
                return 2
            output = args[i + 1]
            i += 2
        else:
            err(f"error: unexpected argument '{arg}' found\n\n")
            err("Usage: executable export [OPTIONS]\n\n")
            err("For more information, try '--help'.\n")
            return 2
    err("❌ Export command is not yet implemented\n")
    err(f"💡 Requested format: {fmt}\n")
    if output is not None:
        err(f"💡 Requested output: {output}\n")
    err("💡 This feature is planned for a future release\n")
    return 1


def parse_cache(args: list[str]) -> int:
    if not args or args[0] in ("-h", "--help", "help"):
        out(CACHE_HELP)
        return 0 if args else 2
    command = args[0]
    if command == "stats":
        out("Challenge Cache Statistics:\n  Cached repositories: 0\n  Total size: 0 bytes\n")
        return 0
    if command == "list":
        out("No cached challenges found.\n")
        return 0
    if command == "clear":
        out("Challenge cache cleared successfully.\n")
        return 0
    err(f"error: unrecognized subcommand '{command}'\n\n")
    err("Usage: executable cache <COMMAND>\n\n")
    err("For more information, try '--help'.\n")
    return 2


def parse_repo(args: list[str]) -> int:
    if not args or args[0] in ("-h", "--help", "help"):
        out(REPO_HELP)
        return 0 if args else 2
    command = args[0]
    if command == "clear":
        out("No cached repositories directory found.\n")
        return 0
    if command == "list":
        return terminal_error(["repo", *args])
    if command == "play":
        if len(args) > 1:
            err(f"error: unexpected argument '{args[1]}' found\n\n")
            err("Usage: executable repo play\n\n")
            err("For more information, try '--help'.\n")
            return 2
        return terminal_error(["repo", *args])
    err(f"error: unrecognized subcommand '{command}'\n\n")
    err("Usage: executable repo <COMMAND>\n\n")
    err("For more information, try '--help'.\n")
    return 2


def main(argv: list[str]) -> int:
    if not argv:
        return terminal_error(argv)
    if argv[0] == "--version" or argv[0] == "-V":
        out(VERSION + "\n")
        return 0
    if argv[0] == "--help":
        out(LONG_HELP)
        return 0
    if argv[0] == "-h":
        out(SHORT_HELP)
        return 0
    if argv[0] == "--unknown":
        err("error: unexpected argument '--unknown' found\n\n")
        err("  tip: to pass '--unknown' as a value, use '-- --unknown'\n\n")
        err("Usage: executable [OPTIONS] [REPO_PATH] [COMMAND]\n\n")
        err("For more information, try '--help'.\n")
        return 2
    if argv[0] == "--langs":
        if len(argv) < 2:
            err("error: a value is required for '--langs <LANGS>' but none was supplied\n\n")
            err("For more information, try '--help'.\n")
            return 2
        lang_status = unsupported_languages(argv[1])
        if lang_status:
            return lang_status
        rest = argv[2:]
        if not rest:
            return terminal_error(argv)
        return main(rest)
    if argv[0] == "--repo":
        if len(argv) < 2:
            err("error: a value is required for '--repo <REPO>' but none was supplied\n\n")
            err("For more information, try '--help'.\n")
            return 2
        return terminal_error(argv)
    if argv[0] == "help":
        if len(argv) == 1:
            out(LONG_HELP)
            return 0
        return main([argv[1], "--help", *argv[2:]])
    if argv[0] == "history":
        err("❌ History command is not yet implemented\n")
        err("💡 This feature is planned for a future release\n")
        return 1
    if argv[0] == "stats":
        err("❌ Stats command is not yet implemented\n")
        err("💡 This feature is planned for a future release\n")
        return 1
    if argv[0] == "export":
        return parse_export(argv[1:])
    if argv[0] == "cache":
        return parse_cache(argv[1:])
    if argv[0] == "repo":
        return parse_repo(argv[1:])
    if argv[0] == "trending":
        if len(argv) > 1 and argv[1] in ("-h", "--help"):
            out(TRENDING_HELP)
            return 0
        return terminal_error(argv)
    return terminal_error(argv)


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
