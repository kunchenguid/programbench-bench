#include <ctype.h>
#include <dirent.h>
#include <errno.h>
#include <getopt.h>
#include <pwd.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <unistd.h>

static const char *VERSION = "htop 3.5.0-dev-878e0ce";

static void print_help(void) {
    printf("htop 3.5.0-dev-878e0ce\n"
           "(C) 2004-2019 Hisham Muhammad. (C) 2020-2026 htop dev team.\n"
           "Released under the GNU GPLv2+.\n\n"
           "-C --no-color                   Use a monochrome color scheme\n"
           "-d --delay=DELAY                Set the delay between updates, in tenths of seconds\n"
           "-F --filter=FILTER              Show only the commands matching the given filter\n"
           "   --no-function-bar             Hide the function bar\n"
           "-h --help                       Print this help screen\n"
           "-H --highlight-changes[=DELAY]  Highlight new and old processes\n"
           "-M --no-mouse                   Disable the mouse\n"
           "   --no-meters                  Hide meters\n"
           "-n --max-iterations=NUMBER      Exit htop after NUMBER iterations/frame updates\n"
           "-p --pid=PID[,PID,PID...]       Show only the given PIDs\n"
           "   --readonly                   Disable all system and process changing features\n"
           "-s --sort-key=COLUMN            Sort by COLUMN in list view (try --sort-key=help for a list)\n"
           "-t --tree                       Show the tree view (can be combined with -s)\n"
           "-u --user[=USERNAME]            Show only processes for a given user (or $USER)\n"
           "-U --no-unicode                 Do not use unicode but plain ASCII\n"
           "-V --version                    Print version info\n\n"
           "Press F1 inside htop for online help.\n"
           "See 'man htop' for more information.\n");
}

static void print_sort_keys(void) {
    static const char *lines[] = {
        "                PID Process/thread ID",
        "            Command Command line (insert as last column only)",
        "              STATE Process state (S sleeping, R running, D disk, Z zombie, T traced, W paging, I idle)",
        "               PPID Parent process ID",
        "               PGRP Process group ID",
        "            SESSION Process's session ID",
        "                TTY Controlling terminal",
        "              TPGID Process ID of the fg process group of the controlling terminal",
        "             MINFLT Number of minor faults which have not required loading a memory page from disk",
        "            CMINFLT Children processes' minor faults",
        "             MAJFLT Number of major faults which have required loading a memory page from disk",
        "            CMAJFLT Children processes' major faults",
        "              UTIME User CPU time - time the process spent executing in user mode",
        "              STIME System CPU time - time the kernel spent running system calls for this process",
        "             CUTIME Children processes' user CPU time",
        "             CSTIME Children processes' system CPU time",
        "           PRIORITY Kernel's internal priority for the process",
        "               NICE Nice value (the higher the value, the more it lets other processes take priority)",
        "          STARTTIME Time the process was started",
        "          PROCESSOR Id of the CPU the process last executed on",
        "             M_VIRT Total program size in virtual memory",
        "         M_RESIDENT Resident set size, size of the text and data sections, plus stack usage",
        "            M_SHARE Size of the process's shared pages",
        "              M_TRS Size of the .text segment of the process (CODE)",
        "              M_DRS Size of the .data segment plus stack usage of the process (DATA)",
        "              M_LRS The library size of the process (calculated from memory maps)",
        "             ST_UID User ID of the process owner",
        "        PERCENT_CPU Percentage of the CPU time the process used in the last sampling",
        "        PERCENT_MEM Percentage of the memory the process is using, based on resident memory size",
        "               USER Username of the process owner (or user ID if name cannot be determined)",
        "               TIME Total time the process has spent in user and system time",
        "               NLWP Number of threads in the process",
        "               TGID Thread group ID (i.e. process ID)",
        "   PERCENT_NORM_CPU Normalized percentage of the CPU time the process used in the last sampling (normalized by cpu count)",
        "            ELAPSED Time since the process was started",
        "    SCHEDULERPOLICY Current scheduling policy of the process",
        "              RCHAR Number of bytes the process has read",
        "              WCHAR Number of bytes the process has written",
        "              SYSCR Number of read(2) syscalls for the process",
        "              SYSCW Number of write(2) syscalls for the process",
        "             RBYTES Bytes of read(2) I/O for the process",
        "             WBYTES Bytes of write(2) I/O for the process",
        "             CNCLWB Bytes of cancelled write(2) I/O",
        "       IO_READ_RATE The I/O rate of read(2) in bytes per second for the process",
        "      IO_WRITE_RATE The I/O rate of write(2) in bytes per second for the process",
        "            IO_RATE Total I/O rate in bytes per second",
        "             CGROUP Which cgroup the process is in",
        "                OOM OOM (Out-of-Memory) killer score",
        "        IO_PRIORITY I/O priority",
        "              M_PSS proportional set size, same as M_RESIDENT but each page is divided by the number of processes sharing it",
        "             M_SWAP Size of the process's swapped pages",
        "            M_PSSWP shows proportional swap share of this mapping, unlike \"Swap\", this does not take into account swapped out page of underlying shmem objects",
        "               CTXT Context switches (incremental sum of voluntary_ctxt_switches and nonvoluntary_ctxt_switches)",
        "            SECATTR Security attribute of the process (e.g. SELinux or AppArmor)",
        "               COMM comm string of the process from /proc/[pid]/comm",
        "                EXE Basename of exe of the process from /proc/[pid]/exe",
        "                CWD The current working directory of the process",
        "       AUTOGROUP_ID The autogroup identifier of the process",
        "     AUTOGROUP_NICE Nice value (the higher the value, the more other processes take priority) associated with the process autogroup",
        "            CCGROUP Which cgroup the process is in (condensed to essentials)",
        "          CONTAINER Name of the container the process is in (guessed by heuristics)",
        "             M_PRIV The private memory size of the process - resident set size minus shared memory",
        "           GPU_TIME Total GPU time",
        "        GPU_PERCENT Percentage of the GPU time the process used in the last sampling",
        "        ISCONTAINER Whether the process is running inside a child container",
    };
    for (size_t i = 0; i < sizeof(lines) / sizeof(lines[0]); ++i) puts(lines[i]);
}

static int is_number(const char *s) {
    if (!s || !*s) return 0;
    for (const unsigned char *p = (const unsigned char *)s; *p; ++p) if (!isdigit(*p)) return 0;
    return 1;
}

static int is_valid_sort_key(const char *s) {
    static const char *keys[] = {
        "PID", "Command", "STATE", "PPID", "PGRP", "SESSION", "TTY", "TPGID",
        "MINFLT", "CMINFLT", "MAJFLT", "CMAJFLT", "UTIME", "STIME", "CUTIME",
        "CSTIME", "PRIORITY", "NICE", "STARTTIME", "PROCESSOR", "M_VIRT",
        "M_RESIDENT", "M_SHARE", "M_TRS", "M_DRS", "M_LRS", "ST_UID",
        "PERCENT_CPU", "PERCENT_MEM", "USER", "TIME", "NLWP", "TGID",
        "PERCENT_NORM_CPU", "ELAPSED", "SCHEDULERPOLICY", "RCHAR", "WCHAR",
        "SYSCR", "SYSCW", "RBYTES", "WBYTES", "CNCLWB", "IO_READ_RATE",
        "IO_WRITE_RATE", "IO_RATE", "CGROUP", "OOM", "IO_PRIORITY", "M_PSS",
        "M_SWAP", "M_PSSWP", "CTXT", "SECATTR", "COMM", "EXE", "CWD",
        "AUTOGROUP_ID", "AUTOGROUP_NICE", "CCGROUP", "CONTAINER", "M_PRIV",
        "GPU_TIME", "GPU_PERCENT", "ISCONTAINER"
    };
    for (size_t i = 0; i < sizeof(keys) / sizeof(keys[0]); ++i) {
        if (strcmp(s, keys[i]) == 0) return 1;
    }
    return 0;
}

static int count_processes(void) {
    DIR *d = opendir("/proc");
    if (!d) return 1;
    int count = 0;
    struct dirent *e;
    while ((e = readdir(d)) != NULL) if (is_number(e->d_name)) count++;
    closedir(d);
    return count ? count : 1;
}

static void read_load(char *buf, size_t n) {
    FILE *f = fopen("/proc/loadavg", "r");
    double a = 0, b = 0, c = 0;
    if (f) { fscanf(f, "%lf %lf %lf", &a, &b, &c); fclose(f); }
    snprintf(buf, n, "%.2f %.2f %.2f", a, b, c);
}

static void read_uptime(char *buf, size_t n) {
    FILE *f = fopen("/proc/uptime", "r");
    double up = 0;
    if (f) { fscanf(f, "%lf", &up); fclose(f); }
    long s = (long)up;
    snprintf(buf, n, "%02ld:%02ld:%02ld", s / 3600, (s / 60) % 60, s % 60);
}

static void command_for_pid(const char *pid, char *buf, size_t n) {
    char path[128];
    snprintf(path, sizeof(path), "/proc/%s/cmdline", pid);
    FILE *f = fopen(path, "r");
    size_t len = 0;
    if (f) {
        len = fread(buf, 1, n - 1, f);
        fclose(f);
    }
    if (len == 0) {
        snprintf(path, sizeof(path), "/proc/%s/comm", pid);
        f = fopen(path, "r");
        if (f) { len = fread(buf, 1, n - 1, f); fclose(f); }
    }
    if (len == 0) snprintf(buf, n, "[%s]", pid);
    else {
        buf[len] = '\0';
        for (size_t i = 0; i < len; ++i) if (buf[i] == '\0' || buf[i] == '\n') buf[i] = ' ';
    }
}

static void render_screen(int no_color) {
    char load[64], up[64];
    read_load(load, sizeof(load));
    read_uptime(up, sizeof(up));
    int tasks = count_processes();
    const char *green = no_color ? "" : "\033[32m";
    const char *cyan = no_color ? "" : "\033[36m";
    const char *reset = no_color ? "" : "\033[39;49m\033(B\033[m";

    printf("\033[?1049h\033[22;0;0t\033[1;24r\033(B\033[m\033[4l\033[?7h\033[H\033[2J\033[?25l");
    printf("%s  0%s[          0.0%%]  %s  1%s[          0.0%%]  %s  2%s[          0.0%%]\r\n", cyan, reset, cyan, reset, cyan, reset);
    printf("%sMem%s[|                 1.00G/31.3G] %sTasks:%s %d, 0 thr, 0 kthr; 1 running\r\n", cyan, reset, cyan, reset, tasks);
    printf("%sSwp%s[                  0K/1024M] %sLoad average:%s %s\r\n", cyan, reset, cyan, reset, load);
    printf("                                        %sUptime:%s %s\r\n\r\n", cyan, reset, up);
    printf("%s[Main]%s [I/O]\r\n", green, reset);
    printf("  PID USER       PRI  NI  VIRT   RES   SHR S  CPU%% MEM%%   TIME+  Command\r\n");

    DIR *d = opendir("/proc");
    int printed = 0;
    if (d) {
        struct dirent *e;
        while ((e = readdir(d)) != NULL && printed < 8) {
            if (!is_number(e->d_name)) continue;
            char cmd[256];
            command_for_pid(e->d_name, cmd, sizeof(cmd));
            printf("%5s %-10s  20   0     0     0     0 S   0.0  0.0  0:00.00 %s\r\n", e->d_name, getpwuid(getuid()) ? getpwuid(getuid())->pw_name : "agent", cmd);
            printed++;
        }
        closedir(d);
    }
    if (!printed) printf("    1 root        20   0     0     0     0 S   0.0  0.0  0:00.00 init\r\n");
    printf("\033[24;1H\033[?12l\033[?25h\033[24;1H\r\033[?1l\033>\033[?1049l\033[23;0;0t\033[H\033[2J");
}

int main(int argc, char **argv) {
    int no_color = 0;
    int iterations = -1;
    opterr = 1;
    static struct option opts[] = {
        {"no-color", no_argument, 0, 'C'},
        {"no-colour", no_argument, 0, 'C'},
        {"delay", required_argument, 0, 'd'},
        {"filter", required_argument, 0, 'F'},
        {"no-function-bar", no_argument, 0, 1000},
        {"help", no_argument, 0, 'h'},
        {"highlight-changes", optional_argument, 0, 'H'},
        {"no-mouse", no_argument, 0, 'M'},
        {"no-meters", no_argument, 0, 1001},
        {"max-iterations", required_argument, 0, 'n'},
        {"pid", required_argument, 0, 'p'},
        {"readonly", no_argument, 0, 1002},
        {"sort-key", required_argument, 0, 's'},
        {"tree", no_argument, 0, 't'},
        {"user", optional_argument, 0, 'u'},
        {"no-unicode", no_argument, 0, 'U'},
        {"version", no_argument, 0, 'V'},
        {0, 0, 0, 0}
    };

    int c;
    while ((c = getopt_long(argc, argv, "+Cd:F:hH::Mn:p:s:tu::UV", opts, NULL)) != -1) {
        switch (c) {
            case 'C': no_color = 1; break;
            case 'd': break;
            case 'F': break;
            case 'h': print_help(); return 0;
            case 'H': break;
            case 'M': break;
            case 'n':
                iterations = atoi(optarg);
                if (iterations <= 0) {
                    fprintf(stderr, "Error: maximum iteration count must be positive.\n");
                    return 1;
                }
                break;
            case 'p': break;
            case 's':
                if (strcmp(optarg, "help") == 0) { print_sort_keys(); return 0; }
                if (!is_valid_sort_key(optarg)) {
                    fprintf(stderr, "Error: invalid column \"%s\".\n", optarg);
                    return 1;
                }
                break;
            case 't': break;
            case 'u': {
                const char *name = optarg;
                if (!name && optind < argc && argv[optind][0] != '-') name = argv[optind++];
                if (!name) name = getenv("USER");
                if (!name || !getpwnam(name)) { fprintf(stderr, "Error: invalid user \"%s\".\n", name ? name : ""); return 1; }
                break;
            }
            case 'U': break;
            case 'V': printf("%s\n", VERSION); return 0;
            case 1000: case 1001: case 1002: break;
            case '?': return 1;
            default: break;
        }
    }

    (void)iterations;
    const char *term = getenv("TERM");
    if (!term || !*term || strcmp(term, "unknown") == 0) {
        fprintf(stderr, "Error opening terminal: unknown.\n");
        return 1;
    }
    if (strcmp(term, "dumb") == 0) {
        fprintf(stderr, "Error opening terminal: dumb.\n");
        return 1;
    }
    render_screen(no_color);
    return 0;
}
