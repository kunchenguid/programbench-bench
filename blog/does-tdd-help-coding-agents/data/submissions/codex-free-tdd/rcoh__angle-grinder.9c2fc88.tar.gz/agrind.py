#!/usr/bin/env python3
import argparse
import fnmatch
import json
import math
import re
import shlex
import sys
from collections import OrderedDict
from pathlib import Path


MISSING = object()


def convert(value):
    if value is None:
        return None
    if isinstance(value, (int, float, bool, list, dict)):
        return value
    s = str(value)
    if s == "null":
        return None
    if s == "true":
        return True
    if s == "false":
        return False
    if re.fullmatch(r"[-+]?\d+", s):
        try:
            return int(s)
        except ValueError:
            return s
    if re.fullmatch(r"[-+]?(?:\d+\.\d*|\d*\.\d+)(?:[eE][-+]?\d+)?", s):
        try:
            return float(s)
        except ValueError:
            return s
    return s


def split_pipeline(query):
    parts, buf, quote, esc = [], [], None, False
    for ch in query:
        if esc:
            buf.append(ch)
            esc = False
        elif ch == "\\":
            buf.append(ch)
            esc = True
        elif quote:
            buf.append(ch)
            if ch == quote:
                quote = None
        elif ch in ("'", '"'):
            buf.append(ch)
            quote = ch
        elif ch == "|":
            parts.append("".join(buf).strip())
            buf = []
        else:
            buf.append(ch)
    if buf or query.endswith("|"):
        parts.append("".join(buf).strip())
    return parts


def split_commas(text):
    parts, buf, quote, depth, esc = [], [], None, 0, False
    for ch in text:
        if esc:
            buf.append(ch)
            esc = False
        elif ch == "\\":
            buf.append(ch)
            esc = True
        elif quote:
            buf.append(ch)
            if ch == quote:
                quote = None
        elif ch in ("'", '"'):
            buf.append(ch)
            quote = ch
        elif ch in "([":
            depth += 1
            buf.append(ch)
        elif ch in ")]":
            depth -= 1
            buf.append(ch)
        elif ch == "," and depth == 0:
            parts.append("".join(buf).strip())
            buf = []
        else:
            buf.append(ch)
    if buf or text.strip():
        parts.append("".join(buf).strip())
    return [p for p in parts if p]


def get_field(row, path):
    if path.startswith('["') and path.endswith('"]'):
        path = path[2:-2]
    cur = row
    for name, idx in re.findall(r"([A-Za-z_][\w.-]*|\[[^\]]+\])(?:\[(\-?\d+)\])?", path):
        if name.startswith("[") and name.endswith("]"):
            name = name[1:-1].strip('"')
        if isinstance(cur, dict) and name in cur:
            cur = cur[name]
        else:
            return None
        if idx:
            try:
                cur = cur[int(idx)]
            except Exception:
                return None
    return cur


def set_field(row, name, value):
    row[name.strip()] = value


def row_value(row, expr):
    expr = expr.strip()
    if expr.startswith('"') and expr.endswith('"'):
        return bytes(expr[1:-1], "utf-8").decode("unicode_escape")
    if expr.startswith("'") and expr.endswith("'"):
        return expr[1:-1]
    if re.fullmatch(r"[-+]?\d+(?:\.\d+)?", expr):
        return convert(expr)
    return get_field(row, expr)


def filter_match(line, filt):
    filt = filt.strip()
    if not filt or filt == "*":
        return True
    def atom(tok):
        tok = tok.strip()
        if tok.startswith('"') and tok.endswith('"'):
            return tok[1:-1] in line
        return fnmatch.fnmatch(line.lower(), tok.lower())
    if filt.startswith("NOT "):
        return not filter_match(line, filt[4:])
    if " OR " in filt:
        return any(filter_match(line, p) for p in filt.split(" OR "))
    if " AND " in filt:
        return all(filter_match(line, p) for p in filt.split(" AND "))
    return atom(filt)


def parse_logfmt(text):
    try:
        tokens = shlex.split(text)
    except ValueError:
        tokens = text.split()
    row = OrderedDict()
    for tok in tokens:
        if "=" in tok:
            k, v = tok.split("=", 1)
            row[k] = convert(v)
        elif tok:
            row[tok] = None
    return row


def pattern_to_regex(pattern):
    out = ["^"]
    stars = pattern.count("*")
    seen = 0
    i = 0
    while i < len(pattern):
        if pattern[i] == "*":
            seen += 1
            out.append("(.*)" if seen == stars else "(.*?)")
            i += 1
        elif pattern[i].isspace():
            while i < len(pattern) and pattern[i].isspace():
                i += 1
            out.append(r"\s+")
        else:
            out.append(re.escape(pattern[i]))
            i += 1
    out.append("$")
    return re.compile("".join(out))


def parse_parse_op(op):
    m = re.match(r'parse\s+regex\s+"((?:\\"|[^"])*)"(?:\s+from\s+(\S+))?(?:\s+(nodrop))?$', op)
    if m:
        return ("regex", m.group(1).replace('\\"', '"'), m.group(2), bool(m.group(3)), False)
    m = re.match(r'parse\s+"((?:\\"|[^"])*)"(?:\s+from\s+(\S+))?\s+as\s+(.+)', op)
    if not m:
        return None
    pattern = m.group(1).replace('\\"', '"')
    source = m.group(2)
    rest = m.group(3)
    nodrop = bool(re.search(r"\bnodrop\b", rest))
    noconvert = bool(re.search(r"\bnoconvert\b", rest))
    rest = re.sub(r"\b(?:nodrop|noconvert)\b", "", rest).strip()
    names = [x.strip() for x in rest.split(",") if x.strip()]
    return ("glob", pattern, source, names, nodrop, noconvert)


def op_json(rows, source, errors):
    out = []
    for raw, row in rows:
        text = raw if source is None else get_field(row, source)
        try:
            val = json.loads(text)
            if isinstance(val, dict):
                out.append((raw, OrderedDict(val)))
        except Exception:
            errors.append(f"error: Expected JSON, found {text}\n")
    return out


def op_logfmt(rows, source):
    out = []
    for raw, row in rows:
        text = raw if source is None else get_field(row, source)
        out.append((raw, parse_logfmt(str(text or ""))))
    return out


def op_parse(rows, parsed):
    if parsed[0] == "regex":
        _, pattern, source, nodrop, _ = parsed
        regex = re.compile(pattern)
        names = list(regex.groupindex.keys())
        noconvert = False
    else:
        _, pattern, source, names, nodrop, noconvert = parsed
        regex = pattern_to_regex(pattern)
    out = []
    for raw, row in rows:
        text = raw if source is None else str(get_field(row, source) or "")
        match = regex.match(text)
        if not match and not nodrop:
            continue
        new = OrderedDict(row)
        groups = match.groups() if match else []
        for i, name in enumerate(names):
            value = groups[i] if i < len(groups) else None
            new[name] = value if noconvert else convert(value)
        out.append((raw, new))
    return out


def op_split(rows, op):
    m = re.match(r"split(?:\(([^)]+)\))?(?:\s+on\s+\"((?:\\\"|[^\"])*)\")?(?:\s+as\s+(\S+))?$", op)
    if not m:
        return rows
    source, sep, dest = m.group(1), m.group(2), m.group(3)
    sep = "," if sep is None else sep.replace('\\"', '"')
    dest = dest or source or "_split"
    out = []
    for raw, row in rows:
        text = raw if source is None else str(get_field(row, source) or "")
        new = OrderedDict(row)
        new[dest] = [convert(part) for part in text.split(sep)]
        out.append((raw, new))
    return out


def op_fields(rows, spec):
    spec = spec.strip()
    mode = "except"
    for prefix, value in (("+", "only"), ("only ", "only"), ("-", "except"), ("except ", "except")):
        if spec.startswith(prefix):
            mode = value
            spec = spec[len(prefix):].strip()
            break
    wanted = [x.strip() for x in spec.split(",") if x.strip()]
    out = []
    for raw, row in rows:
        if mode == "only":
            out.append((raw, OrderedDict((k, row[k]) for k in wanted if k in row)))
        else:
            out.append((raw, OrderedDict((k, v) for k, v in row.items() if k not in wanted)))
    return out


def compare_values(a, op, b):
    try:
        if isinstance(a, str) and isinstance(b, (int, float)):
            a = convert(a)
        if isinstance(b, str) and isinstance(a, (int, float)):
            b = convert(b)
        if op == "==":
            return a == b
        if op in ("!=", "<>"):
            return a != b
        if op == "<":
            return a < b
        if op == ">":
            return a > b
        if op == "<=":
            return a <= b
        if op == ">=":
            return a >= b
    except Exception:
        return False
    return bool(a)


def eval_condition(row, expr):
    expr = expr.strip()
    if expr.startswith("!"):
        return not eval_condition(row, expr[1:])
    m = re.match(r"(.+?)\s*(==|!=|<>|<=|>=|<|>)\s*(.+)", expr)
    if m:
        return compare_values(row_value(row, m.group(1)), m.group(2), row_value(row, m.group(3)))
    return bool(row_value(row, expr))


def op_where(rows, expr):
    return [(raw, row) for raw, row in rows if eval_condition(row, expr)]


def op_limit(rows, n):
    return rows[:n] if n >= 0 else rows[n:]


def aggregate(rows, op):
    if " by " in op:
        left, by = op.split(" by ", 1)
        keys = split_commas(by)
    else:
        left, keys = op, []
    specs = split_commas(left)
    groups = OrderedDict()
    for raw, row in rows:
        keyvals = tuple(row_value(row, k) for k in keys)
        groups.setdefault(keyvals, []).append(row)
    result = []
    for keyvals, grows in groups.items():
        out = OrderedDict()
        for k, v in zip(keys, keyvals):
            out[k] = v
        for spec in specs:
            name, value = aggregate_one(grows, spec)
            out[name] = value
        result.append(("", out))
    return result


def aggregate_one(rows, spec):
    alias = None
    if " as " in spec:
        spec, alias = spec.rsplit(" as ", 1)
        alias = alias.strip()
    spec = spec.strip()
    if spec == "count":
        return alias or "_count", len(rows)
    m = re.match(r"count\((.+)\)$", spec)
    if m:
        return alias or "_count", sum(1 for r in rows if eval_condition(r, m.group(1)))
    m = re.match(r"(\w+)\((.+)\)$", spec)
    if not m:
        return alias or spec, None
    fn, field = m.group(1), m.group(2).strip()
    vals = [row_value(r, field) for r in rows]
    nums = [v for v in vals if isinstance(v, (int, float))]
    if fn == "sum":
        return alias or "_sum", sum(nums)
    if fn in ("average", "avg"):
        return alias or "_average", (sum(nums) / len(nums)) if nums else None
    if fn == "min":
        return alias or "_min", min(nums) if nums else None
    if fn == "max":
        return alias or "_max", max(nums) if nums else None
    if fn in ("count_distinct", "countDistinct"):
        return alias or "_countDistinct", len(set(json.dumps(v, sort_keys=True) for v in vals))
    pm = re.fullmatch(r"p(?:ct)?(\d+)", fn)
    if pm:
        pct = int(pm.group(1))
        if not nums:
            return alias or f"p{pct}", None
        nums = sorted(nums)
        idx = int(math.ceil((pct / 100) * len(nums))) - 1
        idx = max(0, min(idx, len(nums) - 1))
        return alias or f"p{pct}", nums[idx]
    return alias or fn, None


def op_sort(rows, spec):
    m = re.match(r"sort\s+by\s+(.+?)(?:\s+(asc|desc))?$", spec)
    if not m:
        return rows
    keys = split_commas(m.group(1))
    reverse = m.group(2) == "desc"
    return sorted(rows, key=lambda rr: tuple(row_value(rr[1], k) for k in keys), reverse=reverse)


def assign_expr(rows, op):
    if " as " not in op:
        return rows
    expr, name = op.rsplit(" as ", 1)
    out = []
    for raw, row in rows:
        new = OrderedDict(row)
        new[name.strip()] = eval_arith(row, expr)
        out.append((raw, new))
    return out


def eval_arith(row, expr):
    funcs = {
        "abs": abs, "ceil": math.ceil, "floor": math.floor, "round": round,
        "sqrt": math.sqrt, "length": lambda x: len(str(x)),
        "concat": lambda *xs: "".join("" if x is None else str(x) for x in xs),
        "contains": lambda a, b: str(b) in str(a),
        "toLowerCase": lambda x: str(x).lower(),
        "toUpperCase": lambda x: str(x).upper(),
        "num": convert,
        "isNull": lambda x: x is None,
        "isEmpty": lambda x: x is None or str(x) == "",
        "isBlank": lambda x: x is None or str(x).strip() == "",
        "isNumeric": lambda x: isinstance(convert(str(x)), (int, float)),
    }
    names = {k: v for k, v in row.items() if re.fullmatch(r"[A-Za-z_]\w*", k)}
    try:
        return eval(expr, {"__builtins__": {}}, {**funcs, **names})
    except Exception:
        return row_value(row, expr)


def load_aliases(alias_dir):
    aliases = {}
    dirs = []
    if alias_dir:
        dirs.append(Path(alias_dir))
    else:
        cwd = Path.cwd()
        dirs = [p / ".agrind-aliases" for p in [cwd, *cwd.parents]]
    for d in dirs:
        if not d.is_dir():
            continue
        for path in d.glob("*.toml"):
            try:
                text = path.read_text(encoding="utf-8")
            except OSError:
                continue
            km = re.search(r'keyword\s*=\s*"([^"]+)"', text)
            tm = re.search(r'template\s*=\s*"""(.*?)"""', text, re.S)
            if km and tm:
                aliases[km.group(1)] = tm.group(1).strip()
    return aliases


def expand_aliases(parts, aliases, no_alias):
    if no_alias:
        return parts
    out = []
    for i, part in enumerate(parts):
        if i > 0 and part in aliases:
            out.extend(split_pipeline(aliases[part]))
        else:
            out.append(part)
    return out


def process(query, input_text, alias_dir=None, no_alias=False):
    parts = split_pipeline(query)
    parts = expand_aliases(parts, load_aliases(alias_dir), no_alias)
    filt = parts[0] if parts else "*"
    rows = [(line, OrderedDict()) for line in input_text.splitlines() if filter_match(line, filt)]
    errors = []
    aggregate_seen = False
    for op in parts[1:]:
        if op == "json" or op.startswith("json from "):
            rows = op_json(rows, op[10:].strip() if op.startswith("json from ") else None, errors)
        elif op == "logfmt" or op.startswith("logfmt from "):
            rows = op_logfmt(rows, op[12:].strip() if op.startswith("logfmt from ") else None)
        elif op.startswith("parse "):
            parsed = parse_parse_op(op)
            if parsed:
                rows = op_parse(rows, parsed)
        elif op.startswith("split"):
            rows = op_split(rows, op)
        elif op.startswith("fields "):
            rows = op_fields(rows, op[7:])
        elif op.startswith("where "):
            rows = op_where(rows, op[6:])
        elif op.startswith("limit "):
            rows = op_limit(rows, int(op[6:].strip()))
        elif op.startswith("sort by "):
            rows = op_sort(rows, op)
        elif re.match(r"^(?:count|sum|average|avg|min|max|p\d+|pct\d+|count_distinct)\b", op):
            rows = aggregate(rows, op)
            aggregate_seen = True
        elif " as " in op:
            rows = assign_expr(rows, op)
    return rows, errors, aggregate_seen


def compact_json(value):
    value = normalize_json(value)
    return json.dumps(value, separators=(",", ":"), ensure_ascii=False)


def normalize_json(value):
    if isinstance(value, float) and value.is_integer():
        return int(value)
    if isinstance(value, list):
        return [normalize_json(v) for v in value]
    if isinstance(value, dict):
        return OrderedDict((k, normalize_json(v)) for k, v in value.items())
    return value


def fmt_value(v):
    if v is None:
        return "None"
    if isinstance(v, float):
        return f"{v:.2f}" if not v.is_integer() else str(int(v))
    if isinstance(v, list):
        return "[" + ", ".join(fmt_value(x) for x in v) + "]"
    return str(v)


def render(rows, output, aggregate_seen):
    data = [row for _, row in rows]
    if output == "json":
        if aggregate_seen:
            return compact_json(data) + "\n"
        return "".join(compact_json(row) + "\n" for row in data)
    if output == "logfmt":
        lines = []
        for row in data:
            parts = []
            for k, v in row.items():
                val = "null" if v is None else str(v)
                if any(c.isspace() for c in val):
                    val = json.dumps(val)
                parts.append(f"{k}={val}")
            lines.append(" ".join(parts))
        return "\n".join(lines) + ("\n" if lines else "")
    if output.startswith("format="):
        template = output[7:]
        return "".join(template.format(**row) + "\n" for row in data)
    if aggregate_seen:
        if not data:
            return ""
        headers = list(data[0].keys())
        widths = [max(len(h), *(len(fmt_value(r.get(h))) for r in data)) for h in headers]
        header = "        ".join(h.ljust(w) for h, w in zip(headers, widths)).rstrip()
        sep = "-" * max(14, len(header) + 8)
        lines = [header, sep]
        for row in data:
            lines.append("        ".join(fmt_value(row.get(h)).ljust(w) for h, w in zip(headers, widths)).rstrip())
        return "\n".join(lines) + "\n"
    return "".join("        ".join(f"[{k}={fmt_value(v)}]" for k, v in row.items()) + "\n" for row in data)


def main(argv=None):
    parser = argparse.ArgumentParser(
        prog="executable",
        description=None,
        add_help=False,
        formatter_class=argparse.RawTextHelpFormatter,
    )
    parser.add_argument("-f", "--file")
    parser.add_argument("-m", "--format", dest="old_format")
    parser.add_argument("-o", "--output", default="legacy")
    parser.add_argument("-a", "--alias-dir")
    parser.add_argument("--no-alias", action="store_true")
    parser.add_argument("-h", "--help", action="store_true")
    parser.add_argument("-V", "--version", action="store_true")
    parser.add_argument("query", nargs="?")
    args = parser.parse_args(argv)
    if args.help:
        sys.stdout.write(HELP)
        return 0
    if args.version:
        sys.stdout.write("ag 0.19.6\n")
        return 0
    if not args.query:
        sys.stderr.write("error: the following required arguments were not provided: <QUERY>\n")
        return 2
    output = "format=" + args.old_format if args.old_format else args.output
    if args.file:
        with open(args.file, "r", encoding="utf-8") as f:
            input_text = f.read()
    else:
        input_text = sys.stdin.read()
    rows, errors, aggregate_seen = process(args.query, input_text, args.alias_dir, args.no_alias)
    for e in errors:
        sys.stderr.write(e)
    sys.stdout.write(render(rows, output, aggregate_seen))
    return 0


HELP = """Usage: executable [OPTIONS] [QUERY]

Arguments:
  [QUERY]
          The query

Options:
  -f, --file <FILE>
          Optionally reads from a file instead of Stdin

  -m, --format <FORMAT>
          DEPRECATED. Use -o format=... instead. Provide a Rust std::fmt string to format output

  -o, --output <OUTPUT>
          Set output format. Options: 
          - `json`,
          - `logfmt`
          - `format=<rust format string>` (eg. -o format='{src} => {dst}'
          - `legacy` The original output format, auto aligning [k=v]

  -a, --alias-dir <ALIAS_DIR>
          Specifies an alternative directory to use for aliases. Defaults to `.agrind-aliases` in all parent directories.

      --no-alias
          Disables aliases

  -h, --help
          Print help (see a summary with '-h')

  -V, --version
          Print version

For more details + docs, see https://github.com/rcoh/angle-grinder
"""


if __name__ == "__main__":
    raise SystemExit(main())
