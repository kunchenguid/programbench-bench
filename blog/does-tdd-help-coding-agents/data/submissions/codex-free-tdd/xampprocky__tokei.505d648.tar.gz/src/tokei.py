#!/usr/bin/env python3
import json
import os
import re
import sys
from dataclasses import dataclass, field
from pathlib import Path


LANGS = {
    ".rs": ("Rust", ("//",), (("/*", "*/"),)),
    ".py": ("Python", ("#",), ()),
    ".js": ("JavaScript", ("//",), (("/*", "*/"),)),
    ".jsx": ("JSX", ("//",), (("/*", "*/"),)),
    ".ts": ("TypeScript", ("//",), (("/*", "*/"),)),
    ".tsx": ("TSX", ("//",), (("/*", "*/"),)),
    ".json": ("JSON", (), ()),
    ".md": ("Markdown", (), ()),
    ".markdown": ("Markdown", (), ()),
    ".c": ("C", ("//",), (("/*", "*/"),)),
    ".h": ("C Header", ("//",), (("/*", "*/"),)),
    ".cpp": ("C++", ("//",), (("/*", "*/"),)),
    ".cc": ("C++", ("//",), (("/*", "*/"),)),
    ".hpp": ("C++ Header", ("//",), (("/*", "*/"),)),
    ".java": ("Java", ("//",), (("/*", "*/"),)),
    ".go": ("Go", ("//",), (("/*", "*/"),)),
    ".rb": ("Ruby", ("#",), ()),
    ".sh": ("Shell", ("#",), ()),
    ".bash": ("BASH", ("#",), ()),
    ".css": ("CSS", (), (("/*", "*/"),)),
    ".html": ("HTML", (), (("<!--", "-->"),)),
    ".xml": ("XML", (), (("<!--", "-->"),)),
    ".toml": ("TOML", ("#",), ()),
    ".yaml": ("YAML", ("#",), ()),
    ".yml": ("YAML", ("#",), ()),
}

NAME_LANGS = {
    "makefile": ("Makefile", ("#",), ()),
    "dockerfile": ("Dockerfile", ("#",), ()),
}

LANG_EXTS = [
    ("ABNF", "abnf"), ("AWK", "awk"), ("ABAP", "abap"),
    ("ActionScript", "as"), ("Ada", "ada, adb, ads, pad"),
    ("Agda", "agda"), ("Alex", "x"), ("Alloy", "als"), ("APL", "apl"),
    ("BASH", "bash"), ("Batch", "bat, btm, cmd"), ("C", "c, ec, pgc"),
    ("C Header", "h"), ("CMake", "cmake"), ("C#", "cs, csx"),
    ("C++", "cc, cpp, cxx, c++, pcc, tpp"), ("C++ Header", "hh, hpp, hxx, inl, ipp"),
    ("CSS", "css"), ("Dart", "dart"), ("Dockerfile", "dockerfile, dockerignore"),
    ("Go", "go"), ("HTML", "html, htm"), ("Java", "java"),
    ("JavaScript", "js, mjs, cjs"), ("JSON", "json"), ("JSX", "jsx"),
    ("Lua", "lua"), ("Makefile", "makefile, mk"), ("Markdown", "md, markdown"),
    ("PHP", "php"), ("Python", "py, pyw"), ("Ruby", "rb"),
    ("Rust", "rs"), ("Shell", "sh"), ("TOML", "toml"),
    ("TSX", "tsx"), ("TypeScript", "ts"), ("XML", "xml"),
    ("YAML", "yaml, yml"), ("Zig", "zig"),
]


@dataclass
class Stats:
    blanks: int = 0
    code: int = 0
    comments: int = 0
    blobs: dict = field(default_factory=dict)

    @property
    def lines(self):
        return self.blanks + self.code + self.comments

    def add(self, other):
        self.blanks += other.blanks
        self.code += other.code
        self.comments += other.comments


@dataclass
class Report:
    name: str
    language: str
    stats: Stats


def help_text():
    return """Count your code, quickly.
Support this project on GitHub Sponsors: https://github.com/sponsors/XAMPPRocky

Usage: executable [OPTIONS] [input]...

Arguments:
  [input]...  The path(s) to the file or directory to be counted. (default current directory)

Options:
  -c, --columns <columns>              Sets a strict column width of the output, only available for
                                       terminal output.
  -e, --exclude <exclude>              Ignore all files & directories matching the pattern.
  -f, --files                          Will print out statistics on individual files.
  -i, --input <file_input>             Gives statistics from a previous tokei run.
  --hidden                             Count hidden files.
  -l, --languages                      Prints out supported languages and their extensions.
      --no-ignore                      Don't respect ignore files (.gitignore, .ignore, etc.).
  -o, --output <output>                Outputs Tokei in a specific format.
      --streaming <streaming>          prints the (language, path, lines, blanks, code, comments)
                                       records as simple lines or as Json for batch processing
                                       [possible values: simple, json]
  -s, --sort <sort>                    Sort languages based on column [possible values: files,
                                       lines, blanks, code, comments]
  -r, --rsort <rsort>                  Reverse sort languages based on column [possible values:
                                       files, lines, blanks, code, comments]
  -t, --types <types>                  Filters output by language type, separated by a comma.
  -C, --compact                        Do not print statistics about embedded languages.
  -n, --num-format <num_format_style>  Format of printed numbers.
  -v, --verbose...                     Set log output level.
  -h, --help                           Print help
  -V, --version                        Print version
"""


def language_for(path):
    name = path.name.lower()
    if name in NAME_LANGS:
        return NAME_LANGS[name]
    return LANGS.get(path.suffix.lower())


def strip_strings_for_comments(line):
    out = []
    quote = None
    esc = False
    for ch in line:
        if quote:
            if esc:
                esc = False
            elif ch == "\\":
                esc = True
            elif ch == quote:
                quote = None
            out.append(" ")
        else:
            if ch in ("'", '"'):
                quote = ch
                out.append(" ")
            else:
                out.append(ch)
    return "".join(out)


def count_code_file(text, line_markers, block_markers):
    stats = Stats()
    in_block = None
    for raw in text.splitlines():
        line = raw.rstrip("\n")
        if not line.strip():
            stats.blanks += 1
            continue
        work = strip_strings_for_comments(line)
        i = 0
        has_code = False
        has_comment = False
        while i < len(work):
            if in_block:
                end = work.find(in_block, i)
                has_comment = True
                if end == -1:
                    i = len(work)
                else:
                    i = end + len(in_block)
                    in_block = None
                continue
            starts = [(a, b) for a, b in block_markers if work.startswith(a, i)]
            if starts:
                start, end = starts[0]
                has_comment = True
                in_block = end
                i += len(start)
                continue
            if any(work.startswith(marker, i) for marker in line_markers):
                has_comment = True
                break
            if not work[i].isspace():
                has_code = True
            i += 1
        if has_code:
            stats.code += 1
        elif has_comment:
            stats.comments += 1
        else:
            stats.code += 1
    return stats


def count_python(text):
    stats = Stats()
    in_triple = None
    for raw in text.splitlines():
        line = raw.rstrip("\n")
        stripped = line.strip()
        if not stripped:
            stats.blanks += 1
            continue
        if in_triple:
            stats.code += 1
            if in_triple in stripped:
                in_triple = None
            continue
        if stripped.startswith("#"):
            stats.comments += 1
            continue
        stats.code += 1
        for q in ('"""', "'''"):
            if q in stripped and stripped.count(q) % 2 == 1:
                in_triple = q
                break
    return stats


FENCE_RE = re.compile(r"^```\s*([A-Za-z0-9_+#.-]+)?")


def normalize_lang(name):
    if not name:
        return None
    lowered = name.lower()
    aliases = {
        "rust": "Rust", "rs": "Rust", "python": "Python", "py": "Python",
        "json": "JSON", "javascript": "JavaScript", "js": "JavaScript",
        "typescript": "TypeScript", "ts": "TypeScript", "sh": "Shell",
        "bash": "BASH", "c": "C", "cpp": "C++", "c++": "C++",
        "java": "Java", "go": "Go",
    }
    return aliases.get(lowered)


def count_markdown(text):
    md = Stats()
    in_fence = False
    fence_lang = None
    fence_lines = []
    for line in text.splitlines():
        m = FENCE_RE.match(line.strip())
        if m:
            if not in_fence:
                in_fence = True
                fence_lang = normalize_lang(m.group(1))
                fence_lines = []
            else:
                if fence_lang:
                    child = count_by_language(fence_lang, "\n".join(fence_lines))
                    md.blobs[fence_lang] = child
                in_fence = False
                fence_lang = None
            md.comments += 1
        elif in_fence:
            fence_lines.append(line)
        elif not line.strip():
            md.blanks += 1
        else:
            md.comments += 1
    return md


def count_by_language(language, text):
    if language == "Markdown":
        return count_markdown(text)
    if language == "Python":
        return count_python(text)
    for _ext, (name, line, block) in LANGS.items():
        if name == language:
            return count_code_file(text, line, block)
    return count_code_file(text, (), ())


def load_ignore_patterns(root):
    patterns = []
    gitignore = root / ".gitignore"
    if gitignore.exists():
        for raw in gitignore.read_text(errors="ignore").splitlines():
            line = raw.strip()
            if line and not line.startswith("#"):
                patterns.append(line)
    return patterns


def matches_pattern(path, root, pattern):
    import fnmatch
    try:
        rel = path.relative_to(root)
    except ValueError:
        rel = path
    text = rel.as_posix()
    if pattern.endswith("/"):
        prefix = pattern.rstrip("/")
        return text == prefix or text.startswith(prefix + "/")
    if "/" in pattern:
        return fnmatch.fnmatch(text, pattern)
    return fnmatch.fnmatch(path.name, pattern)


def should_skip(path, hidden, excludes, root=None, ignore_patterns=None):
    parts = path.parts
    if not hidden and any(part.startswith(".") for part in parts if part not in (".", "..")):
        return True
    if any(part in (".git", "target", "node_modules", "__pycache__") for part in parts):
        return True
    import fnmatch
    text = str(path)
    if any(fnmatch.fnmatch(path.name, pat) or fnmatch.fnmatch(text, pat) for pat in excludes):
        return True
    if root and ignore_patterns:
        return any(matches_pattern(path, root, pat) for pat in ignore_patterns)
    return False


def collect(paths, hidden=False, excludes=None, no_ignore=False):
    excludes = excludes or []
    reports = []
    for input_path in paths:
        path = Path(input_path)
        if not path.exists():
            raise FileNotFoundError(str(input_path))
        if path.is_file():
            candidates = [path]
            root = path.parent
        else:
            root = path
            candidates = sorted(p for p in path.rglob("*") if p.is_file())
        ignore_patterns = [] if no_ignore else load_ignore_patterns(root)
        for file_path in candidates:
            rel = file_path if not file_path.is_absolute() else file_path
            if should_skip(rel, hidden, excludes, root, ignore_patterns):
                continue
            info = language_for(file_path)
            if not info:
                continue
            language = info[0]
            try:
                text = file_path.read_text(errors="ignore")
            except OSError:
                continue
            reports.append(Report(str(file_path), language, count_by_language(language, text)))
    return reports


def grouped(reports, type_filter=None):
    groups = {}
    for report in reports:
        if type_filter and report.language not in type_filter:
            continue
        groups.setdefault(report.language, []).append(report)
    return groups


def lang_total(reports):
    total = Stats()
    for report in reports:
        total.add(report.stats)
    return total


def inclusive_stats(stats):
    total = Stats(stats.blanks, stats.code, stats.comments)
    for child in stats.blobs.values():
        total.add(inclusive_stats(child))
    return total


def report_to_json(report):
    return {"stats": stats_to_json(report.stats), "name": report.name}


def stats_to_json(stats):
    return {"blanks": stats.blanks, "code": stats.code, "comments": stats.comments, "blobs": {k: stats_to_json(v) for k, v in stats.blobs.items()}}


def output_json(groups):
    data = {}
    total = Stats()
    children = {}
    for language in sorted(groups):
        reports = groups[language]
        st = lang_total(reports)
        for report in reports:
            total.add(inclusive_stats(report.stats))
        lang_children = {}
        for report in reports:
            for child_lang, child_stats in report.stats.blobs.items():
                lang_children.setdefault(child_lang, []).append({"stats": stats_to_json(child_stats), "name": report.name})
        data[language] = {
            "blanks": st.blanks,
            "code": st.code,
            "comments": st.comments,
            "reports": [report_to_json(r) for r in reports],
            "children": lang_children,
            "inaccurate": False,
        }
        children[language] = [report_to_json(r) for r in reports]
    data["Total"] = {
        "blanks": total.blanks,
        "code": total.code,
        "comments": total.comments,
        "reports": [],
        "children": children,
        "inaccurate": False,
    }
    print(json.dumps(data, separators=(",", ":")))


def sort_languages(items, key, reverse=False):
    if key in (None, ""):
        return sorted(items)
    def val(lang):
        reports = items[lang]
        st = lang_total(reports)
        return {"files": len(reports), "lines": st.lines, "blanks": st.blanks, "code": st.code, "comments": st.comments}.get(key, 0)
    return sorted(items, key=lambda lang: (-val(lang), lang) if not reverse else (val(lang), lang))


def fmt_row(name, files, stats):
    files_text = "" if files is None else str(files)
    return f" {name:<20}{files_text:>8}{stats.lines:>13}{stats.code:>13}{stats.comments:>13}{stats.blanks:>12}"


def output_table(groups, show_files=False, sort_key=None, reverse=False, compact=False):
    width = 81
    top = "━" * width
    mid = "─" * width
    print(top)
    print(f" {'Language':<20}{'Files':>8}{'Lines':>13}{'Code':>13}{'Comments':>13}{'Blanks':>12}")
    print(top)
    grand = Stats()
    file_count = 0
    for language in sort_languages(groups, sort_key, reverse):
        reports = groups[language]
        st = lang_total(reports)
        for report in reports:
            grand.add(inclusive_stats(report.stats))
        file_count += len(reports)
        has_blobs = any(r.stats.blobs for r in reports)
        if has_blobs:
            print(mid)
        print(fmt_row(language, len(reports), st))
        if has_blobs and not compact:
            child_totals = {}
            for report in reports:
                for child_lang, child in report.stats.blobs.items():
                    child_totals.setdefault(child_lang, Stats()).add(child)
            total_with = Stats(st.blanks, st.code, st.comments)
            for child in child_totals.values():
                total_with.add(child)
            for child_lang in sorted(child_totals):
                print(fmt_row(f"|- {child_lang}", len(reports), child_totals[child_lang]))
            print(fmt_row("(Total)", None, total_with))
        if show_files:
            print(mid)
            for report in reports:
                print(fmt_row(report.name, None, report.stats))
    print(top)
    print(fmt_row("Total", file_count, grand))
    print(top)


def output_stream(groups, mode):
    reports = [r for lang in sorted(groups) for r in groups[lang]]
    if mode == "json":
        for r in reports:
            print(json.dumps({"language": r.language, "stats": report_to_json(r)}, separators=(",", ":")))
    else:
        print("# language                                        path                                          lines         code       comments      blanks   ")
        print("########## ################################################################################ ############ ############ ############ ############")
        for r in reports:
            print(f"{r.language:>10} {r.name:<80}{r.stats.lines:>13}{r.stats.code:>13}{r.stats.comments:>13}{r.stats.blanks:>13}")


def output_languages():
    print("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━")
    print("┃ Language                              Extensions                     ┃")
    print("┃━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┃")
    for lang, exts in LANG_EXTS:
        print(f"┃ {lang:<37} {exts:<30} ┃")


def parse_args(argv):
    opts = {"paths": [], "exclude": [], "types": None}
    i = 0
    while i < len(argv):
        arg = argv[i]
        if arg in ("-h", "--help"):
            opts["help"] = True
        elif arg in ("-V", "--version"):
            opts["version"] = True
        elif arg in ("-l", "--languages"):
            opts["languages"] = True
        elif arg in ("-f", "--files"):
            opts["files"] = True
        elif arg == "--hidden":
            opts["hidden"] = True
        elif arg in ("--no-ignore", "--no-ignore-parent", "--no-ignore-dot", "--no-ignore-vcs"):
            opts["no_ignore"] = True
        elif arg in ("-C", "--compact"):
            opts["compact"] = True
        elif arg in ("-o", "--output", "--streaming", "-s", "--sort", "-r", "--rsort", "-t", "--types", "-e", "--exclude", "-c", "--columns", "-n", "--num-format", "-i", "--input"):
            if i + 1 >= len(argv):
                raise ValueError(f"error: a value is required for '{arg}'")
            val = argv[i + 1]
            i += 1
            if arg in ("-o", "--output"):
                opts["output"] = val
            elif arg == "--streaming":
                opts["streaming"] = val
            elif arg in ("-s", "--sort"):
                opts["sort"] = val
            elif arg in ("-r", "--rsort"):
                opts["rsort"] = val
            elif arg in ("-t", "--types"):
                opts["types"] = set(x.strip() for x in val.split(",") if x.strip())
            elif arg in ("-e", "--exclude"):
                opts["exclude"].append(val)
        elif arg.startswith("-"):
            raise ValueError(f"error: unexpected argument '{arg}' found")
        else:
            opts["paths"].append(arg)
        i += 1
    if not opts["paths"]:
        opts["paths"] = ["."]
    return opts


def main(argv):
    try:
        opts = parse_args(argv)
    except ValueError as exc:
        print(str(exc), file=sys.stderr)
        print("\nUsage: executable [OPTIONS] [input]...\n\nFor more information, try '--help'.", file=sys.stderr)
        return 2
    if opts.get("help"):
        print(help_text(), end="")
        return 0
    if opts.get("version"):
        print("tokei 14.0.0 compiled with serialization support: json")
        return 0
    if opts.get("languages"):
        output_languages()
        return 0
    if opts.get("output") and opts["output"] != "json":
        print(f"error: invalid value '{opts['output']}' for '--output <output>': This version of tokei was compiled without any '{opts['output']}' serialization support, to enable serialization, reinstall tokei with the features flag.", file=sys.stderr)
        return 2
    try:
        reports = collect(opts["paths"], opts.get("hidden", False), opts["exclude"], opts.get("no_ignore", False))
    except FileNotFoundError as exc:
        print(f"Error: '{exc.args[0]}' not found.", file=sys.stderr)
        return 1
    groups = grouped(reports, opts.get("types"))
    if opts.get("output") == "json":
        output_json(groups)
    elif opts.get("streaming"):
        output_stream(groups, opts["streaming"])
    else:
        output_table(groups, opts.get("files", False), opts.get("sort") or opts.get("rsort"), bool(opts.get("rsort")), opts.get("compact", False))
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
