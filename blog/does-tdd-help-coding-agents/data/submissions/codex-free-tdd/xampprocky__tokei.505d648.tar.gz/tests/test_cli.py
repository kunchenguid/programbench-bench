import json
import os
import re
import subprocess
import sys
import tempfile
import textwrap
import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
TOOL = [sys.executable, str(ROOT / "src" / "tokei.py")]


def run_tool(*args, cwd=None, input_text=None):
    return subprocess.run(
        TOOL + list(args),
        cwd=cwd or ROOT,
        input=input_text,
        text=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
    )


class CliTests(unittest.TestCase):
    def make_project(self):
        tmp = tempfile.TemporaryDirectory()
        root = Path(tmp.name)
        (root / "src").mkdir()
        (root / "docs").mkdir()
        (root / ".hidden").mkdir()
        (root / "src" / "main.rs").write_text(
            textwrap.dedent(
                """\
                // hello
                fn main() {
                    println!("hi"); // inline
                    /* block
                       comment */
                    let x = 1;
                }

                """
            )
        )
        (root / "src" / "app.py").write_text(
            textwrap.dedent(
                '''\
                # py comment

                def f():
                    """doc
                    string"""
                    return 1 # inline
                '''
            )
        )
        (root / "docs" / "readme.md").write_text(
            "# Title\n\nSome text\n\n```rust\nfn x() {}\n```\n"
        )
        (root / "data.json").write_text('{"a":1,\n "b":2}\n')
        (root / ".hidden" / "secret.js").write_text("// nope\nlet x = 1;\n")
        self.addCleanup(tmp.cleanup)
        return root

    def test_help_and_version_match_documented_cli(self):
        help_result = run_tool("--help")
        self.assertEqual(help_result.returncode, 0)
        self.assertIn("Count your code, quickly.", help_result.stdout)
        self.assertIn("Usage: executable [OPTIONS] [input]...", help_result.stdout)
        self.assertIn("--streaming <streaming>", help_result.stdout)

        version = run_tool("--version")
        self.assertEqual(version.returncode, 0)
        self.assertEqual(
            version.stdout.strip(),
            "tokei 14.0.0 compiled with serialization support: json",
        )

    def test_counts_common_languages_and_markdown_code_fences(self):
        project = self.make_project()
        result = run_tool(str(project))
        self.assertEqual(result.returncode, 0, result.stderr)
        rows = result.stdout
        self.assertRegex(rows, r"JSON\s+1\s+2\s+2\s+0\s+0")
        self.assertRegex(rows, r"Python\s+1\s+6\s+4\s+1\s+1")
        self.assertRegex(rows, r"Rust\s+1\s+8\s+4\s+3\s+1")
        self.assertRegex(rows, r"Markdown\s+1\s+6\s+0\s+4\s+2")
        self.assertRegex(rows, r"Total\s+4\s+23\s+11\s+8\s+4")
        self.assertNotIn("JavaScript", rows)

    def test_json_output_has_tokei_shape(self):
        project = self.make_project()
        result = run_tool("-o", "json", str(project))
        self.assertEqual(result.returncode, 0, result.stderr)
        data = json.loads(result.stdout)
        self.assertEqual(data["Rust"]["code"], 4)
        self.assertEqual(data["Rust"]["comments"], 3)
        self.assertEqual(data["Markdown"]["children"]["Rust"][0]["stats"]["code"], 1)
        self.assertEqual(data["Total"]["code"], 11)
        self.assertEqual(data["Total"]["comments"], 8)

    def test_type_filter_and_hidden_flag(self):
        project = self.make_project()
        filtered = run_tool("-t", "Rust,Python", str(project))
        self.assertEqual(filtered.returncode, 0, filtered.stderr)
        self.assertRegex(filtered.stdout, r"Total\s+2\s+14\s+8\s+4\s+2")
        self.assertNotIn("JSON", filtered.stdout)

        hidden = run_tool("--hidden", str(project))
        self.assertEqual(hidden.returncode, 0, hidden.stderr)
        self.assertRegex(hidden.stdout, r"JavaScript\s+1\s+2\s+1\s+1\s+0")
        self.assertRegex(hidden.stdout, r"Total\s+5\s+25\s+12\s+9\s+4")

    def test_errors_for_missing_path_and_bad_output_format(self):
        missing = run_tool("no_such_path")
        self.assertEqual(missing.returncode, 1)
        self.assertEqual(missing.stderr.strip(), "Error: 'no_such_path' not found.")

        yaml = run_tool("-o", "yaml")
        self.assertEqual(yaml.returncode, 2)
        self.assertIn("compiled without any 'yaml' serialization support", yaml.stderr)

    def test_gitignore_no_ignore_exclude_files_and_streaming_json(self):
        tmp = tempfile.TemporaryDirectory()
        self.addCleanup(tmp.cleanup)
        root = Path(tmp.name)
        (root / "a").mkdir()
        (root / "skip").mkdir()
        (root / ".gitignore").write_text("skip/\n*.json\n")
        (root / "a" / "one.rs").write_text("fn main() {}\n")
        (root / "skip" / "two.py").write_text("print(1)\n")
        (root / "data.json").write_text("{}\n")

        base = run_tool(str(root))
        self.assertEqual(base.returncode, 0, base.stderr)
        self.assertRegex(base.stdout, r"Rust\s+1\s+1\s+1\s+0\s+0")
        self.assertRegex(base.stdout, r"Total\s+1\s+1\s+1\s+0\s+0")
        self.assertNotIn("Python", base.stdout)
        self.assertNotIn("JSON", base.stdout)

        no_ignore = run_tool("--no-ignore", str(root))
        self.assertEqual(no_ignore.returncode, 0, no_ignore.stderr)
        self.assertRegex(no_ignore.stdout, r"Total\s+3\s+3\s+3\s+0\s+0")

        excluded = run_tool("--no-ignore", "-e", "*.py", str(root))
        self.assertEqual(excluded.returncode, 0, excluded.stderr)
        self.assertRegex(excluded.stdout, r"Total\s+2\s+2\s+2\s+0\s+0")
        self.assertNotIn("Python", excluded.stdout)

        files = run_tool("-f", str(root))
        self.assertEqual(files.returncode, 0, files.stderr)
        self.assertIn(str(root / "a" / "one.rs"), files.stdout)

        stream = run_tool("--streaming", "json", str(root))
        self.assertEqual(stream.returncode, 0, stream.stderr)
        lines = [json.loads(line) for line in stream.stdout.splitlines()]
        self.assertEqual(lines[0]["language"], "Rust")
        self.assertEqual(lines[0]["stats"]["stats"]["code"], 1)


if __name__ == "__main__":
    unittest.main()
