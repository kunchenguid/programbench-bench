import os
import subprocess
import sys
import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
CLI = ROOT / "src" / "pueue_cli.py"


def run_cli(*args):
    env = os.environ.copy()
    env.pop("RUST_BACKTRACE", None)
    return subprocess.run(
        [sys.executable, str(CLI), *args],
        text=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        env=env,
    )


class CliTests(unittest.TestCase):
    def test_version_matches_documented_binary(self):
        result = run_cli("--version")
        self.assertEqual(result.returncode, 0)
        self.assertEqual(result.stdout, "pueue 4.0.4\n")

    def test_top_level_short_help_matches_clap_summary(self):
        result = run_cli("-h")
        self.assertEqual(result.returncode, 0)
        self.assertIn("Interact with the Pueue daemon\n\n", result.stdout)
        self.assertIn("Usage: executable [OPTIONS] [COMMAND]\n", result.stdout)
        self.assertIn("  add          Enqueue a task for execution\n", result.stdout)
        self.assertIn(
            "  -h, --help               Print help (see more with '--help')\n",
            result.stdout,
        )

    def test_add_long_help_contains_full_contract(self):
        result = run_cli("help", "add")
        self.assertEqual(result.returncode, 0)
        self.assertTrue(result.stdout.startswith("Enqueue a task for execution.\n\n"))
        self.assertIn("Usage: executable add [OPTIONS] <COMMAND>...\n", result.stdout)
        self.assertIn("  -w, --working-directory <working-directory>\n", result.stdout)
        self.assertIn("  -p, --print-task-id\n", result.stdout)

    def test_missing_required_argument_uses_clap_error_shape(self):
        result = run_cli("remove")
        self.assertEqual(result.returncode, 2)
        self.assertEqual(
            result.stdout,
            "error: the following required arguments were not provided:\n"
            "  <TASK_IDS>...\n\n"
            "Usage: executable remove <TASK_IDS>...\n\n"
            "For more information, try '--help'.\n",
        )

    def test_send_with_only_task_id_reports_missing_input(self):
        result = run_cli("send", "1")
        self.assertEqual(result.returncode, 2)
        self.assertEqual(
            result.stdout,
            "error: the following required arguments were not provided:\n"
            "  <INPUT>\n\n"
            "Usage: executable send <TASK_ID> <INPUT>\n\n"
            "For more information, try '--help'.\n",
        )

    def test_runtime_commands_report_missing_config(self):
        result = run_cli("--color", "never", "status")
        self.assertEqual(result.returncode, 1)
        self.assertIn(
            "Couldn't find a configuration file. Did you start the daemon yet?",
            result.stdout,
        )
        self.assertIn("pueue/src/bin/pueue.rs", result.stdout)

    def test_enqueue_help_includes_delay_format_examples(self):
        result = run_cli("enqueue", "--help")
        self.assertEqual(result.returncode, 0)
        self.assertIn("Usage: executable enqueue [OPTIONS] [TASK_IDS]...\n", result.stdout)
        self.assertIn("DELAY FORMAT:\n", result.stdout)
        self.assertIn("    2020-04-01T18:30:00   // RFC 3339 timestamp\n", result.stdout)
        self.assertIn("    3600s                 // 3600 seconds from now\n", result.stdout)

    def test_nested_env_and_group_help_match_observed_usage(self):
        env_set = run_cli("env", "set", "--help")
        self.assertEqual(env_set.returncode, 0)
        self.assertIn("Usage: executable env set <TASK_ID> <KEY> <VALUE>\n", env_set.stdout)

        group_add = run_cli("group", "add", "--help")
        self.assertEqual(group_add.returncode, 0)
        self.assertIn("Usage: executable group add [OPTIONS] <NAME>\n", group_add.stdout)
        self.assertIn("  -p, --parallel <PARALLEL>\n", group_add.stdout)

    def test_log_and_completions_help_include_observed_options(self):
        log = run_cli("help", "log")
        self.assertEqual(log.returncode, 0)
        self.assertIn("Usage: executable log [OPTIONS] [TASK_IDS]...\n", log.stdout)
        self.assertIn("  -j, --json\n", log.stdout)
        self.assertIn("  -f, --full\n", log.stdout)

        completions = run_cli("completions", "--help")
        self.assertEqual(completions.returncode, 0)
        self.assertIn("Usage: executable completions <SHELL> [OUTPUT_DIRECTORY]\n", completions.stdout)
        self.assertIn("[possible values: bash, elvish, fish, power-shell, zsh, nushell]\n", completions.stdout)


if __name__ == "__main__":
    unittest.main()
