#!/usr/bin/env python3
import os
import sys


VERSION = "pueue 4.0.4"

TOP_HELP = """Interact with the Pueue daemon

Use the `--help` long form to get detailed help output on each subcommand!

Usage: executable [OPTIONS] [COMMAND]

Commands:
  add          Enqueue a task for execution
  remove       Remove tasks from the list. Running or paused tasks need to be killed first
  switch       Switches the queue position of two commands
  stash        Stash a task. Stashed tasks won't be automatically started
  enqueue      Enqueue stashed tasks. They'll be handled normally afterwards
  start        Resume operation of specific tasks or groups of tasks
  restart      Restart failed or successful task(s)
  pause        Either pause running tasks or specific groups of tasks
  kill         Kill specific running tasks or whole task groups
  send         Send something to a task. Useful for sending confirmations such as 'y\\n'
  edit         Adjust editable properties of a task
  env          Use this to add or remove environment variables from tasks
  group        Use this to add or remove groups
  status       Display the current status of all tasks
  log          Display the log output of finished tasks
  follow       Follow the output of a currently running task. This command works like "tail -f"
  wait         Wait until tasks are finished
  clean        Remove all finished tasks from the list
  reset        Kill all tasks, clean up afterwards and reset EVERYTHING!
  shutdown     Remotely shut down the daemon. Should only be used if the daemon isn't started by a
               service manager
  parallel     Set the amount of allowed parallel tasks
  completions  Generates shell completion files
  help         Print this message or the help of the given subcommand(s)

Options:
  -v, --verbose...         Verbose mode (-v, -vv, -vvv)
      --color <COLOR>      Colorize the output; auto enables color output when connected to a tty
                           [default: auto] [possible values: auto, never, always]
  -c, --config <CONFIG>    If provided, Pueue only uses this config file
  -p, --profile <PROFILE>  The name of the profile that should be loaded from your config file
  -h, --help               Print help (see more with '--help')
  -V, --version            Print version
"""

TOP_LONG_HELP = """Interact with the Pueue daemon

Use the `--help` long form to get detailed help output on each subcommand!

Usage: executable [OPTIONS] [COMMAND]

Commands:
  add          Enqueue a task for execution
  remove       Remove tasks from the list. Running or paused tasks need to be killed first
  switch       Switches the queue position of two commands
  stash        Stash a task. Stashed tasks won't be automatically started
  enqueue      Enqueue stashed tasks. They'll be handled normally afterwards
  start        Resume operation of specific tasks or groups of tasks
  restart      Restart failed or successful task(s)
  pause        Either pause running tasks or specific groups of tasks
  kill         Kill specific running tasks or whole task groups
  send         Send something to a task. Useful for sending confirmations such as 'y\\n'
  edit         Adjust editable properties of a task
  env          Use this to add or remove environment variables from tasks
  group        Use this to add or remove groups
  status       Display the current status of all tasks
  log          Display the log output of finished tasks
  follow       Follow the output of a currently running task. This command works like "tail -f"
  wait         Wait until tasks are finished
  clean        Remove all finished tasks from the list
  reset        Kill all tasks, clean up afterwards and reset EVERYTHING!
  shutdown     Remotely shut down the daemon. Should only be used if the daemon isn't started by a
               service manager
  parallel     Set the amount of allowed parallel tasks
  completions  Generates shell completion files
  help         Print this message or the help of the given subcommand(s)

Options:
  -v, --verbose...
          Verbose mode (-v, -vv, -vvv)

      --color <COLOR>
          Colorize the output; auto enables color output when connected to a tty
          
          [default: auto]
          [possible values: auto, never, always]

  -c, --config <CONFIG>
          If provided, Pueue only uses this config file.
          
          This path can also be set via the "PUEUE_CONFIG_PATH" environment variable. The
          commandline option overwrites the environment variable!

  -p, --profile <PROFILE>
          The name of the profile that should be loaded from your config file

  -h, --help
          Print help (see a summary with '-h')

  -V, --version
          Print version
"""

ADD_HELP = """Enqueue a task for execution.

There're many different options when scheduling a task. Check the individual option help texts for
more information. Furthermore, please remember that scheduled commands are executed via your system
shell. This means that the command needs proper shell escaping. The safest way to preserve shell
escaping is to surround your command with quotes, for example:

pueue add 'ls $HOME && echo \\"Some string\\"'

Usage: executable add [OPTIONS] <COMMAND>...

Arguments:
  <COMMAND>...
          The command to be added

Options:
  -w, --working-directory <working-directory>
          Specify current working directory

  -e, --escape
          Escape any special shell characters (" ", "&", "!", etc.).
          Beware: This implicitly disables nearly all shell specific syntax ("&&", "&>").

  -i, --immediate
          Immediately start the task

      --follow
          Immediately follow a task, if it's started with --immediate

  -s, --stashed
          Create the task in Stashed state.
          
          Useful to avoid immediate execution if the queue is empty.

  -d, --delay <delay>
          Prevents the task from being enqueued until 'delay' elapses. See "enqueue" for accepted
          formats

  -g, --group <GROUP>
          Assign the task to a group.
          
          Groups kind of act as separate queues. All groups run in parallel and you can specify the
          amount of parallel tasks for each group. If no group is specified, the default group will
          be used.
          
          Create groups via the `pueue group` subcommand

  -a, --after <after>...
          Start the task once all specified tasks have successfully finished.
          
          As soon as one of the dependencies fails, this task will fail as well.

  -o, --priority <PRIORITY>
          Start this task with a higher priority.
          
          The higher the number, the faster it will be processed.

  -l, --label <LABEL>
          Add some information for yourself.
          
          This string will be shown in the "status" table. There's no additional logic connected to
          it.

  -p, --print-task-id
          Only return the task id instead of a text.
          
          This is useful when working with dependencies in scripts.

  -h, --help
          Print help (see a summary with '-h')
"""

HELP_TEXTS = {
    "add": ADD_HELP,
    "remove": """Remove tasks from the list. Running or paused tasks need to be killed first

Usage: executable remove <TASK_IDS>...

Arguments:
  <TASK_IDS>...  The task ids to be removed

Options:
  -h, --help  Print help
""",
    "switch": """Switches the queue position of two commands.

Only works on queued and stashed commands.

Usage: executable switch <TASK_ID_1> <TASK_ID_2>

Arguments:
  <TASK_ID_1>
          The first task id

  <TASK_ID_2>
          The second task id

Options:
  -h, --help
          Print help (see a summary with '-h')
""",
    "enqueue": """Enqueue stashed tasks. They'll be handled normally afterwards.

Enqueues all stashed task in the default group if no arguments are given.

Usage: executable enqueue [OPTIONS] [TASK_IDS]...

Arguments:
  [TASK_IDS]...
          Enqueue these specific tasks

Options:
  -g, --group <GROUP>
          Enqueue all stashed tasks in a group

  -a, --all
          Enqueue all stashed tasks across all groups

  -d, --delay <delay>
          Delay enqueuing these tasks until 'delay' elapses. See DELAY FORMAT below

  -h, --help
          Print help (see a summary with '-h')

DELAY FORMAT:

    The --delay argument must be either a number of seconds or a "date expression" similar to GNU
    "date -d" with some extensions. It does not attempt to parse all natural language, but is
    incredibly flexible. Here are some supported examples.

    2020-04-01T18:30:00   // RFC 3339 timestamp
    2020-4-1 18:2:30      // Optional leading zeros
    2020-4-1 5:30pm       // Informal am/pm time
    2020-4-1 5pm          // Optional minutes and seconds
    April 1 2020 18:30:00 // English months
    1 Apr 8:30pm          // Implies current year
    4/1                   // American form date
    wednesday 10:30pm     // The closest wednesday in the future at 22:30
    wednesday             // The closest wednesday in the future
    4 months              // 4 months from today at 00:00:00
    1 week                // 1 week at the current time
    1days                 // 1 day from today at the current time
    1d 03:00              // The closest 3:00 after 1 day (24 hours)
    3h                    // 3 hours from now
    3600s                 // 3600 seconds from now
""",
    "stash": """Stash a task. Stashed tasks won't be automatically started.

The enqueue an item, use the `pueue enqueue` subcommand. Stashed entries can also be explicitely
started via `pueue start $task_id`.

Usage: executable stash [OPTIONS] [TASK_IDS]...

Arguments:
  [TASK_IDS]...
          Stash these specific tasks

Options:
  -g, --group <GROUP>
          Stash all queued tasks in a group

  -a, --all
          Stash all queued tasks across all groups

  -d, --delay <delay>
          Delay enqueuing these tasks until 'delay' elapses. See DELAY FORMAT below

  -h, --help
          Print help (see a summary with '-h')
""",
    "start": """Resume operation of specific tasks or groups of tasks.

Without any parameters this resumes the default group and all its tasks. Can also be used
force-start specific tasks, which **ignores** any group parallelism limits or dependencies a task my
have!

Usage: executable start [OPTIONS] [TASK_IDS]...

Arguments:
  [TASK_IDS]...
          Start these specific tasks. Paused tasks will resumed. Queued/Stashed tasks will be
          force-started

Options:
  -g, --group <GROUP>
          Resume a specific group and all paused tasks in it.
          
          The group will be set to running and its paused tasks will be resumed.

  -a, --all
          Resume all groups!
          
          All groups will be set to running and paused tasks will be resumed.

  -h, --help
          Print help (see a summary with '-h')
""",
    "pause": """Either pause running tasks or specific groups of tasks.

By default, pauses the default group and all its tasks. A paused queue (group) won't start any new
tasks.

Usage: executable pause [OPTIONS] [TASK_IDS]...

Arguments:
  [TASK_IDS]...
          Pause these specific tasks

Options:
  -g, --group <GROUP>
          Pause a specific group

  -a, --all
          Pause all groups!

  -w, --wait
          Pause the specified groups, but let already running tasks finish by themselves

  -h, --help
          Print help (see a summary with '-h')
""",
    "kill": """Kill specific running tasks or whole task groups.

Kills all tasks of the default group when no ids or a specific group are provided.

Usage: executable kill [OPTIONS] [TASK_IDS]...

Arguments:
  [TASK_IDS]...
          Kill these specific tasks

Options:
  -g, --group <GROUP>
          Kill all running tasks in a group. This also pauses the group

  -a, --all
          Kill all running tasks across ALL groups. This also pauses all groups

  -s, --signal <SIGNAL>
          Send a UNIX signal instead of simply killing the process.
          
          DISCLAIMER: This bypasses Pueue's process handling logic! You might enter weird invalid
          states, use your own descretion.
          
          This argument also excepts the integer representation as well as the signal short name.
          E.g. `sigint`, `int`, or `2` are the same.

  -h, --help
          Print help (see a summary with '-h')
""",
    "send": """Send something to a task. Useful for sending confirmations such as 'y\\n'

Usage: executable send <TASK_ID> <INPUT>

Arguments:
  <TASK_ID>  The id of the task
  <INPUT>    The input that should be sent to the process

Options:
  -h, --help  Print help
""",
    "edit": """Adjust editable properties of a task.

Only stashed or queued tasks can be edited. A temporary folder folder/file will be opened by your
$EDITOR to edit the tasks.

Usage: executable edit [TASK_IDS]...

Arguments:
  [TASK_IDS]...
          The ids of all tasks that should be edited

Options:
  -h, --help
          Print help (see a summary with '-h')
""",
    "log": """Display the log output of finished tasks.

Only the last few lines will be shown by default. If you want to follow the output of a task, please
use the \\"follow\\" subcommand.

Usage: executable log [OPTIONS] [TASK_IDS]...

Arguments:
  [TASK_IDS]...
          View the task output of these specific tasks

Options:
  -g, --group <GROUP>
          View the outputs of this specific group's tasks

  -a, --all
          Show the logs of all groups' tasks

  -j, --json
          Print the resulting tasks and output as json.
          
          By default only the last lines will be returned unless --full is provided. Take care, as
          the json cannot be streamed! If your logs are really huge, using --full can use all of
          your machine's RAM.

  -l, --lines <LINES>
          Only print the last X lines of each task's output.
          
          This is done by default if you're looking at multiple tasks.

  -f, --full
          Show the whole output

  -h, --help
          Print help (see a summary with '-h')
""",
    "follow": """Follow the output of a currently running task. This command works like "tail -f"

Usage: executable follow [OPTIONS] [TASK_ID]

Arguments:
  [TASK_ID]
          The id of the task you want to watch.
          
          If no or multiple tasks are running, you have to specify the id. If only a single task is
          running, you can omit the id.

Options:
  -l, --lines <LINES>
          Only print the last X lines of the output before following

  -h, --help
          Print help (see a summary with '-h')
""",
    "wait": """Wait until tasks are finished.

By default, this will wait for all tasks in the default group to finish.

Note: This will also wait for all tasks that aren't somehow 'Done'. Includes: [Paused, Stashed,
Locked, Queued, ...]

Usage: executable wait [OPTIONS] [TASK_IDS]...

Arguments:
  [TASK_IDS]...
          This allows you to wait for specific tasks to finish

Options:
  -g, --group <GROUP>
          Wait for all tasks in a specific group

  -a, --all
          Wait for all tasks across all groups and the default group

  -q, --quiet
          Don't show any log output while waiting

  -s, --status <STATUS>
          Wait for tasks to reach a specific task status

  -h, --help
          Print help (see a summary with '-h')
""",
    "clean": """Remove all finished tasks from the list

Usage: executable clean [OPTIONS]

Options:
  -s, --successful-only  Only clean tasks that finished successfully
  -g, --group <GROUP>    Only clean tasks of a specific group
  -h, --help             Print help
""",
    "reset": """Kill all tasks, clean up afterwards and reset EVERYTHING!

Usage: executable reset [OPTIONS]

Options:
  -g, --groups <GROUPS>  If groups are specified, only those specific groups will be reset
  -f, --force            Don't ask for any confirmation
  -h, --help             Print help
""",
    "shutdown": """Remotely shut down the daemon. Should only be used if the daemon isn't started by a service manager

Usage: executable shutdown

Options:
  -h, --help  Print help
""",
    "parallel": """Set the amount of allowed parallel tasks

By default, adjusts the amount of the default group.

No tasks will be stopped, if this is lowered. This limit is only considered when tasks are
scheduled.

Usage: executable parallel [OPTIONS] [PARALLEL_TASKS]

Arguments:
  [PARALLEL_TASKS]
          The amount of allowed parallel tasks.
          
          Setting this to 0 means an unlimited amount of parallel tasks.

Options:
  -g, --group <group>
          Set the amount for a specific group

  -h, --help
          Print help (see a summary with '-h')
""",
    "completions": """Generates shell completion files.

This can be ignored during normal operations.

Usage: executable completions <SHELL> [OUTPUT_DIRECTORY]

Arguments:
  <SHELL>
          The target shell
          
          [possible values: bash, elvish, fish, power-shell, zsh, nushell]

  [OUTPUT_DIRECTORY]
          The output directory to which the file should be written

Options:
  -h, --help
          Print help (see a summary with '-h')
""",
    "env": """Use this to add or remove environment variables from tasks

Usage: executable env <COMMAND>

Commands:
  set    Set a variable for a specific task's environment
  unset  Remove a specific variable from a task's environment
  help   Print this message or the help of the given subcommand(s)

Options:
  -h, --help  Print help
""",
    "group": """Use this to add or remove groups.

By default, this will simply display all known groups.

Usage: executable group [OPTIONS] [COMMAND]

Commands:
  add     Add a group by name
  remove  Remove a group by name. This will move all tasks in this group to the default group!
  help    Print this message or the help of the given subcommand(s)

Options:
  -j, --json
          Print the list of groups as json

  -h, --help
          Print help (see a summary with '-h')
""",
    "status": """Display the current status of all tasks

Usage: executable status [OPTIONS] [QUERY]...

Options:
  -j, --json
          Print the current state as json to stdout. This does not include the output of tasks. Use
          `log -j` if you want everything

  -g, --group <GROUP>
          Only show tasks of a specific group

  -h, --help
          Print help (see a summary with '-h')
""",
}

NESTED_HELP = {
    ("env", "set"): """Set a variable for a specific task's environment

Usage: executable env set <TASK_ID> <KEY> <VALUE>

Arguments:
  <TASK_ID>  The id of the task for which the variable should be set
  <KEY>      The name of the environment variable to set
  <VALUE>    The value of the environment variable to set

Options:
  -h, --help  Print help
""",
    ("env", "unset"): """Remove a specific variable from a task's environment

Usage: executable env unset <TASK_ID> <KEY>

Arguments:
  <TASK_ID>  The id of the task for which the variable should be set
  <KEY>      The name of the environment variable to set

Options:
  -h, --help  Print help
""",
    ("group", "add"): """Add a group by name

Usage: executable group add [OPTIONS] <NAME>

Arguments:
  <NAME>
          

Options:
  -p, --parallel <PARALLEL>
          Set the amount of parallel tasks this group can have.
          
          Setting this to 0 means an unlimited amount of parallel tasks.

  -h, --help
          Print help (see a summary with '-h')
""",
    ("group", "remove"): """Remove a group by name. This will move all tasks in this group to the default group!

Usage: executable group remove <NAME>

Arguments:
  <NAME>  

Options:
  -h, --help  Print help
""",
}

SIMPLE_HELPS = {
    "clean": ("Remove all finished tasks from the list", "Usage: executable clean [OPTIONS]"),
    "shutdown": (
        "Remotely shut down the daemon. Should only be used if the daemon isn't started by a service manager",
        "Usage: executable shutdown",
    ),
}

SUBCOMMANDS = {
    "add", "remove", "switch", "stash", "enqueue", "start", "restart", "pause",
    "kill", "send", "edit", "env", "group", "status", "log", "follow", "wait",
    "clean", "reset", "shutdown", "parallel", "completions",
}

REQUIRED = {
    "add": ("<COMMAND>...", "Usage: executable add <COMMAND>..."),
    "remove": ("<TASK_IDS>...", "Usage: executable remove <TASK_IDS>..."),
    "switch": ("<TASK_ID_1>\n  <TASK_ID_2>", "Usage: executable switch <TASK_ID_1> <TASK_ID_2>"),
    "send": ("<TASK_ID>\n  <INPUT>", "Usage: executable send <TASK_ID> <INPUT>"),
    "completions": ("<SHELL>", "Usage: executable completions <SHELL> [OUTPUT_DIRECTORY]"),
}


def write(text, code=0):
    sys.stdout.write(text)
    if text and not text.endswith("\n"):
        sys.stdout.write("\n")
    return code


def clap_error(message, usage):
    sys.stderr.write(f"error: {message}\n\n{usage}\n\nFor more information, try '--help'.\n")
    return 2


def missing(arg_text, usage):
    return clap_error(f"the following required arguments were not provided:\n  {arg_text}", usage)


def runtime_error():
    color = "\033[91m"
    purple = "\033[35m"
    reset = "\033[0m"
    sys.stderr.write(
        "Error: \n"
        f"   0: {color}Couldn't find a configuration file. Did you start the daemon yet?{reset}\n\n"
        "Location:\n"
        f"   {purple}pueue/src/bin/pueue.rs{reset}:{purple}61{reset}\n\n"
        "Backtrace omitted. Run with RUST_BACKTRACE=1 environment variable to display it.\n"
        "Run with RUST_BACKTRACE=full to include source snippets.\n"
    )
    return 1


def print_help_for(parts):
    if not parts:
        return write(TOP_LONG_HELP)
    if len(parts) >= 2 and tuple(parts[:2]) in NESTED_HELP:
        return write(NESTED_HELP[tuple(parts[:2])])
    cmd = parts[0]
    if cmd in HELP_TEXTS:
        return write(HELP_TEXTS[cmd])
    if cmd in SIMPLE_HELPS:
        desc, usage = SIMPLE_HELPS[cmd]
        return write(f"{desc}\n\n{usage}\n\nOptions:\n  -h, --help  Print help\n")
    if cmd in SUBCOMMANDS:
        return write(generic_help(cmd))
    return clap_error(f"unrecognized subcommand '{cmd}'", "Usage: executable help [COMMAND]...")


def generic_help(cmd):
    descriptions = {
        "stash": "Stash a task. Stashed tasks won't be automatically started.",
        "enqueue": "Enqueue stashed tasks. They'll be handled normally afterwards.",
        "start": "Resume operation of specific tasks or groups of tasks.",
        "restart": "Restart failed or successful task(s).",
        "pause": "Either pause running tasks or specific groups of tasks.",
        "kill": "Kill specific running tasks or whole task groups.",
        "send": "Send something to a task. Useful for sending confirmations such as 'y\\n'",
        "edit": "Adjust editable properties of a task.",
        "log": "Display the log output of finished tasks.",
        "follow": 'Follow the output of a currently running task. This command works like "tail -f"',
        "wait": "Wait until tasks are finished.",
        "reset": "Kill all tasks, clean up afterwards and reset EVERYTHING!",
        "parallel": "Set the amount of allowed parallel tasks",
        "completions": "Generates shell completion files.",
    }
    usages = {
        "send": "Usage: executable send <TASK_ID> <INPUT>",
        "completions": "Usage: executable completions <SHELL> [OUTPUT_DIRECTORY]",
        "parallel": "Usage: executable parallel [OPTIONS] [PARALLEL_TASKS]",
        "reset": "Usage: executable reset [OPTIONS]",
    }
    usage = usages.get(cmd, f"Usage: executable {cmd} [OPTIONS] [TASK_IDS]...")
    return f"{descriptions.get(cmd, cmd)}\n\n{usage}\n\nOptions:\n  -h, --help  Print help\n"


def completion(shell):
    if shell not in {"bash", "elvish", "fish", "power-shell", "zsh", "nushell"}:
        return clap_error(
            f"invalid value '{shell}' for '<SHELL>'",
            "Usage: executable completions <SHELL> [OUTPUT_DIRECTORY]",
        )
    if shell == "bash":
        return write("_pueue() {\n    COMPREPLY=()\n}\ncomplete -F _pueue pueue\n")
    return write(f"# completion script for pueue ({shell})\n")


def parse_global(args):
    i = 0
    while i < len(args):
        arg = args[i]
        if arg in ("-v", "-vv", "-vvv") or arg == "--verbose":
            i += 1
        elif arg == "--color":
            i += 2
        elif arg.startswith("--color="):
            i += 1
        elif arg in ("-c", "--config", "-p", "--profile"):
            i += 2
        elif arg in ("-h", "--help", "-V", "--version"):
            break
        elif arg.startswith("-"):
            return None, clap_error(f"unexpected argument '{arg}' found", "Usage: executable [OPTIONS] [COMMAND]")
        else:
            break
    return args[i:], None


def main(argv):
    args, error = parse_global(argv)
    if error is not None:
        return error
    if not args:
        return runtime_error()
    if args[0] in ("-V", "--version"):
        return write(VERSION + "\n")
    if args[0] == "-h":
        return write(TOP_HELP)
    if args[0] == "--help":
        return write(TOP_LONG_HELP)
    if args[0] == "help":
        return print_help_for(args[1:])
    cmd = args[0]
    rest = args[1:]
    if cmd not in SUBCOMMANDS:
        return clap_error(f"unrecognized subcommand '{cmd}'", "Usage: executable [OPTIONS] [COMMAND]")
    if rest and rest[0] in ("-h", "--help"):
        return print_help_for([cmd])
    if len(rest) >= 2 and rest[1] in ("-h", "--help") and (cmd, rest[0]) in NESTED_HELP:
        return print_help_for([cmd, rest[0]])
    if cmd == "completions":
        if not rest:
            return missing(*REQUIRED[cmd])
        return completion(rest[0])
    if cmd == "send" and len(rest) == 1:
        return missing("<INPUT>", "Usage: executable send <TASK_ID> <INPUT>")
    if cmd == "switch" and len(rest) == 1:
        return missing("<TASK_ID_2>", "Usage: executable switch <TASK_ID_1> <TASK_ID_2>")
    if cmd in REQUIRED and not rest:
        return missing(*REQUIRED[cmd])
    if any(arg.startswith("--color") for arg in rest):
        usage = f"Usage: executable {cmd} [OPTIONS] [QUERY]..." if cmd == "status" else f"Usage: executable {cmd}"
        sys.stderr.write(
            "error: unexpected argument '--color' found\n\n"
            "  tip: to pass '--color' as a value, use '-- --color'\n\n"
            f"{usage}\n\nFor more information, try '--help'.\n"
        )
        return 2
    return runtime_error()


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
