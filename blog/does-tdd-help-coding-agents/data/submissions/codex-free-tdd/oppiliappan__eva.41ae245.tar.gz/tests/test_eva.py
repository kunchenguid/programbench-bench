import os
import subprocess
import sys
import unittest


ROOT = os.path.dirname(os.path.dirname(__file__))
EVA = os.path.join(ROOT, "src", "eva.py")


def run_eva(*args, input_text=None):
    return subprocess.run(
        [sys.executable, EVA, *args],
        input=input_text,
        text=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
    )


class EvaCommandModeTests(unittest.TestCase):
    def test_arithmetic_precedence_and_fixed_output(self):
        result = run_eva("2 + 3 * 4")
        self.assertEqual(result.returncode, 0)
        self.assertEqual(result.stdout, "14.0000000000\n")

    def test_degree_trigonometry_and_functions(self):
        result = run_eva("1 + sin(30)")
        self.assertEqual(result.returncode, 0)
        self.assertEqual(result.stdout, "1.5000000000\n")

    def test_implicit_multiplication_and_balanced_parentheses(self):
        result = run_eva("2(3+4")
        self.assertEqual(result.returncode, 0)
        self.assertEqual(result.stdout, "14.0000000000\n")

    def test_options_control_precision_angle_and_base(self):
        result = run_eva("-f", "2", "-a", "radian", "-b", "16", "255.5")
        self.assertEqual(result.returncode, 0)
        self.assertEqual(result.stdout, " ,   ,   , FF.8\n")

    def test_domain_error_uses_reference_wording(self):
        result = run_eva("sqrt(-1)")
        self.assertEqual(result.returncode, 1)
        self.assertEqual(result.stdout, "Domain Error: Out of bounds!\n")

    def test_log_nroot_and_right_associative_power(self):
        self.assertEqual(run_eva("log(8,2)").stdout, "3.0000000000\n")
        self.assertEqual(run_eva("nroot(8,3)").stdout, "2.0000000000\n")
        self.assertEqual(run_eva("2^3^2").stdout, "512.0000000000\n")

    def test_unary_minus_binds_before_power_after_separator(self):
        result = run_eva("--", "-2^2")
        self.assertEqual(result.returncode, 0)
        self.assertEqual(result.stdout, "4.0000000000\n")

    def test_inverse_trig_returns_radians_and_gradian_matches_reference(self):
        self.assertEqual(run_eva("acsc(2)").stdout, "0.5235987756\n")
        self.assertEqual(run_eva("--angle_unit", "gradian", "sin(100)").stdout, "0.9848077530\n")

    def test_version(self):
        result = run_eva("--version")
        self.assertEqual(result.returncode, 0)
        self.assertEqual(result.stdout, "eva 0.3.1\n")


class EvaReplTests(unittest.TestCase):
    def test_repl_stdin_uses_previous_answer(self):
        result = run_eva(input_text="1+2\n_+4\n")
        self.assertEqual(result.returncode, 0)
        self.assertEqual(result.stdout, "No previous history.\n3.0000000000\n7.0000000000\n")


if __name__ == "__main__":
    unittest.main()
