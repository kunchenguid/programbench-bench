#!/usr/bin/env python3
import argparse
import math
import sys


class EvaError(Exception):
    def __init__(self, message, code=1):
        super().__init__(message)
        self.code = code


class ParserError(EvaError):
    pass


class Token:
    def __init__(self, kind, value):
        self.kind = kind
        self.value = value


def tokenize(text):
    tokens = []
    i = 0
    while i < len(text):
        ch = text[i]
        if ch.isspace():
            i += 1
        elif ch.isdigit() or ch == ".":
            start = i
            dot_count = 0
            while i < len(text) and (text[i].isdigit() or text[i] == "."):
                if text[i] == ".":
                    dot_count += 1
                i += 1
            if dot_count > 1 or text[start:i] == ".":
                raise ParserError("Parser Error: Invalid number")
            tokens.append(Token("num", float(text[start:i])))
        elif ch.isalpha() or ch == "_":
            start = i
            while i < len(text) and (text[i].isalnum() or text[i] == "_"):
                i += 1
            tokens.append(Token("name", text[start:i]))
        elif ch == "*" and i + 1 < len(text) and text[i + 1] == "*":
            tokens.append(Token("op", "^"))
            i += 2
        elif ch in "+-*/^(),":
            tokens.append(Token("op", ch))
            i += 1
        else:
            raise ParserError("Parser Error: Unknown token")
    return insert_implicit_multiplication(balance_parentheses(tokens))


def balance_parentheses(tokens):
    depth = 0
    for token in tokens:
        if token.value == "(":
            depth += 1
        elif token.value == ")":
            depth -= 1
            if depth < 0:
                raise ParserError("Parser Error: Too many closing parentheses")
    return tokens + [Token("op", ")") for _ in range(depth)]


def insert_implicit_multiplication(tokens):
    out = []
    for token in tokens:
        if out and needs_mul(out[-1], token):
            out.append(Token("op", "*"))
        out.append(token)
    return out


def needs_mul(left, right):
    left_value = left.value
    right_value = right.value
    left_end = left.kind == "num" or left.kind == "name" or left_value == ")"
    right_start = right.kind == "num" or right_value == "("
    if left.kind == "name" and right_value == "(":
        return False
    if right.kind == "name":
        return left.kind == "num" or left_value == ")"
    return left_end and right_start


class Parser:
    def __init__(self, tokens, angle_unit, previous):
        self.tokens = tokens
        self.pos = 0
        self.angle_unit = angle_unit
        self.previous = previous

    def parse(self):
        if not self.tokens:
            raise ParserError("Parser Error: Empty expression")
        value = self.expression()
        if self.pos != len(self.tokens):
            raise ParserError("Parser Error: Too many values, too few operators")
        return value

    def peek(self):
        if self.pos < len(self.tokens):
            return self.tokens[self.pos]
        return None

    def take(self, value=None):
        token = self.peek()
        if token is None:
            return None
        if value is not None and token.value != value:
            return None
        self.pos += 1
        return token

    def expression(self):
        value = self.term()
        while True:
            if self.take("+"):
                value += self.term()
            elif self.take("-"):
                value -= self.term()
            else:
                return value

    def term(self):
        value = self.power()
        while True:
            if self.take("*"):
                value *= self.power()
            elif self.take("/"):
                rhs = self.power()
                if rhs == 0:
                    raise EvaError("Math Error: Divide by zero error!")
                value /= rhs
            else:
                return value

    def power(self):
        value = self.unary()
        if self.take("^"):
            value = value ** self.power()
        return checked(value)

    def unary(self):
        if self.take("+"):
            return self.unary()
        if self.take("-"):
            return -self.unary()
        return self.primary()

    def primary(self):
        token = self.peek()
        if token is None:
            raise ParserError("Parser Error: Too many operators, too few operands")
        if token.kind == "num":
            self.pos += 1
            return token.value
        if token.value == "(":
            self.pos += 1
            value = self.expression()
            if not self.take(")"):
                raise ParserError("Parser Error: Missing closing parenthesis")
            return value
        if token.kind == "name":
            self.pos += 1
            name = token.value
            if self.take("("):
                args = []
                if not self.take(")"):
                    while True:
                        args.append(self.expression())
                        if self.take(")"):
                            break
                        if not self.take(","):
                            raise ParserError("Parser Error: Missing comma")
                return call_function(name, args, self.angle_unit)
            return constant(name, self.previous)
        raise ParserError("Parser Error: Too many operators, too few operands")


def checked(value):
    if isinstance(value, complex) or math.isnan(value):
        raise EvaError("Domain Error: Out of bounds!")
    if math.isinf(value):
        raise EvaError("Math Error: Infinite result!")
    return value


def to_radians(x, unit):
    if unit == "degree":
        return math.radians(x)
    if unit == "gradian":
        return math.radians(x)
    return x


def constant(name, previous):
    if name == "pi":
        return math.pi
    if name == "e":
        return math.e
    if name == "_":
        if previous is None:
            raise EvaError("No previous history.", 0)
        return previous
    raise ParserError("Parser Error: Unknown identifier")


def require_args(name, args, count):
    if len(args) != count:
        raise ParserError("Parser Error: Wrong number of arguments")


def call_function(name, args, angle_unit):
    try:
        if name in ("sin", "cos", "tan", "csc", "sec", "cot"):
            require_args(name, args, 1)
            x = to_radians(args[0], angle_unit)
            table = {
                "sin": math.sin,
                "cos": math.cos,
                "tan": math.tan,
                "csc": lambda y: 1.0 / math.sin(y),
                "sec": lambda y: 1.0 / math.cos(y),
                "cot": lambda y: 1.0 / math.tan(y),
            }
            return checked(table[name](x))
        if name in ("asin", "acos", "atan", "acsc", "asec", "acot"):
            require_args(name, args, 1)
            table = {
                "asin": math.asin,
                "acos": math.acos,
                "atan": math.atan,
                "acsc": lambda y: math.asin(1.0 / y),
                "asec": lambda y: math.acos(1.0 / y),
                "acot": lambda y: math.atan(1.0 / y),
            }
            return checked(table[name](args[0]))
        if name in ("sinh", "cosh", "tanh"):
            require_args(name, args, 1)
            return checked(getattr(math, name)(args[0]))
        if name == "ln":
            require_args(name, args, 1)
            return checked(math.log(args[0]))
        if name == "log2":
            require_args(name, args, 1)
            return checked(math.log2(args[0]))
        if name == "log10":
            require_args(name, args, 1)
            return checked(math.log10(args[0]))
        if name == "sqrt":
            require_args(name, args, 1)
            return checked(math.sqrt(args[0]))
        if name == "ceil":
            require_args(name, args, 1)
            return float(math.ceil(args[0]))
        if name == "floor":
            require_args(name, args, 1)
            return float(math.floor(args[0]))
        if name == "abs":
            require_args(name, args, 1)
            return abs(args[0])
        if name == "log":
            require_args(name, args, 2)
            return checked(math.log(args[0], args[1]))
        if name == "nroot":
            require_args(name, args, 2)
            return checked(args[0] ** (1.0 / args[1]))
    except (ValueError, OverflowError):
        raise EvaError("Domain Error: Out of bounds!")
    except ZeroDivisionError:
        raise EvaError("Math Error: Divide by zero error!")
    raise ParserError("Parser Error: Unknown function")


def evaluate(text, angle_unit="degree", previous=None):
    return Parser(tokenize(text), angle_unit, previous).parse()


def digit(n):
    if n < 10:
        return chr(ord("0") + n)
    return chr(ord("A") + n - 10)


def convert_base(value, base):
    sign = "-" if value < 0 else ""
    value = abs(value)
    whole = int(math.floor(value))
    frac = value - whole
    if whole == 0:
        whole_s = "0"
    else:
        chars = []
        while whole:
            chars.append(digit(whole % base))
            whole //= base
        whole_s = "".join(reversed(chars))
    frac_digit = digit(int(math.floor(frac * base + 1e-12)))
    grouped = group_commas(sign + whole_s)
    return f"{grouped}.{frac_digit}"


def group_commas(text):
    sign = ""
    if text.startswith("-"):
        sign, text = "-", text[1:]
    parts = []
    while text:
        parts.append(text[-3:])
        text = text[:-3]
    groups = list(reversed(parts))
    if len(groups) < 4:
        groups = [""] * (4 - len(groups)) + groups
    rendered = []
    for idx, part in enumerate(groups):
        width = 1 if idx == 0 and part == "" else 3
        rendered.append(part.rjust(width))
    return sign + ",".join(rendered)


def format_value(value, fix, base):
    value = checked(value)
    if abs(value) < 0.5 * 10 ** (-fix):
        value = 0.0
    if base == 10:
        return f"{value:.{fix}f}"
    return f"{convert_base(value, base):>13}"


def parse_args(argv):
    parser = argparse.ArgumentParser(
        prog="executable",
        description="Calculator REPL similar to bc(1)",
        add_help=False,
    )
    parser.add_argument("-f", "--fix", type=int, default=10)
    parser.add_argument("-b", "--base", type=int, default=10)
    parser.add_argument("-a", "--angle_unit", choices=["degree", "radian", "gradian"], default="degree")
    parser.add_argument("-h", "--help", action="store_true")
    parser.add_argument("-V", "--version", action="store_true")
    parser.add_argument("input", nargs="?")
    ns = parser.parse_args(argv)
    if ns.help:
        print_help()
        raise SystemExit(0)
    if ns.version:
        print("eva 0.3.1")
        raise SystemExit(0)
    if not 1 <= ns.fix <= 64:
        print(f"error: invalid value '{ns.fix}' for '--fix <FIX>': {ns.fix} is not in 1..=64", file=sys.stderr)
        print("\nFor more information, try '--help'.", file=sys.stderr)
        raise SystemExit(2)
    if not 1 <= ns.base <= 36:
        print(f"error: invalid value '{ns.base}' for '--base <RADIX>': {ns.base} is not in 1..=36", file=sys.stderr)
        print("\nFor more information, try '--help'.", file=sys.stderr)
        raise SystemExit(2)
    return ns


def print_help():
    print("""Calculator REPL similar to bc(1)

Usage: executable [OPTIONS] [INPUT]

Arguments:
  [INPUT]  Optional expression string to run eva in command mode

Options:
  -f, --fix <FIX>                Number of decimal places in output (1 - 64) [default: 10]
  -b, --base <RADIX>             Radix of calculation output (1 - 36) [default: 10]
  -a, --angle_unit <angle_unit>  Angle unit [default: degree] [possible values: degree, radian, gradian]
  -h, --help                     Print help
  -V, --version                  Print version""")


def run(argv):
    ns = parse_args(argv)
    previous = None
    if ns.input is not None:
        value = evaluate(ns.input, ns.angle_unit, previous)
        print(format_value(value, ns.fix, ns.base))
        return 0
    print("No previous history.")
    for line in sys.stdin:
        line = line.strip()
        if not line:
            continue
        value = evaluate(line, ns.angle_unit, previous)
        previous = value
        print(format_value(value, ns.fix, ns.base))
    return 0


def main():
    try:
        raise SystemExit(run(sys.argv[1:]))
    except EvaError as exc:
        if str(exc):
            print(str(exc))
        raise SystemExit(exc.code)


if __name__ == "__main__":
    main()
