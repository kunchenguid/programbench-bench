import os
import pty
import select
import subprocess
import tempfile
import time
import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
EXE = ROOT / "executable"


def run(args, stdin=subprocess.DEVNULL):
    return subprocess.run(
        [str(EXE), *args],
        stdin=stdin,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        text=True,
    )


def run_pty(cwd, keys=b"q"):
    master, slave = pty.openpty()
    env = os.environ.copy()
    env.update({"TERM": "xterm", "COLUMNS": "80", "LINES": "24"})
    proc = subprocess.Popen(
        [str(EXE)],
        cwd=cwd,
        env=env,
        stdin=slave,
        stdout=slave,
        stderr=slave,
    )
    os.close(slave)
    time.sleep(0.2)
    os.write(master, keys)
    data = b""
    deadline = time.time() + 2
    while time.time() < deadline:
        readable, _, _ = select.select([master], [], [], 0.05)
        if readable:
            try:
                chunk = os.read(master, 4096)
            except OSError:
                break
            if not chunk:
                break
            data += chunk
        if proc.poll() is not None:
            break
    if proc.poll() is None:
        proc.terminate()
        proc.wait(timeout=1)
    os.close(master)
    return proc.returncode, data.decode("utf-8", "replace")


class WalkCliTest(unittest.TestCase):
    def test_help_goes_to_stderr_and_exits_one(self):
        result = run(["--help"])
        self.assertEqual(result.returncode, 1)
        self.assertEqual(result.stdout, "")
        self.assertIn("  walk v1.13.0\n", result.stderr)
        self.assertIn("  Usage: walk [path]\n", result.stderr)
        self.assertIn("    --hide-hidden  hide hidden files\n", result.stderr)

    def test_version_aliases_write_stdout(self):
        for flag in ("--version", "-v"):
            with self.subTest(flag=flag):
                result = run([flag])
                self.assertEqual(result.returncode, 0)
                self.assertEqual(result.stdout, "v1.13.0\n")
                self.assertEqual(result.stderr, "")

    def test_normal_non_tty_run_panics_like_original(self):
        result = run(["."])
        self.assertEqual(result.returncode, 2)
        self.assertEqual(result.stdout, "")
        self.assertIn("panic: could not open a new TTY: open /dev/tty", result.stderr)
        self.assertIn("main.main()", result.stderr)

    def test_q_in_tty_outputs_current_directory(self):
        with tempfile.TemporaryDirectory() as tmp:
            Path(tmp, ".hidden").write_text("hidden")
            Path(tmp, "a.txt").write_text("alpha")
            Path(tmp, "dirA").mkdir()
            status, output = run_pty(tmp, b"q")
            self.assertEqual(status, 0)
            self.assertIn(".hidden", output)
            self.assertIn("a.txt", output)
            self.assertTrue(output.rstrip().endswith(tmp))


if __name__ == "__main__":
    unittest.main()
