#!/usr/bin/env python3
import os
import sys
import termios
import tty


VERSION = "v1.13.0"

HELP = """
  walk v1.13.0

  Usage: walk [path]

    arrows, hjkl  Move cursor
    enter         Enter directory
    backspace     Exit directory
    space         Toggle preview
    esc, q        Exit with cd
    ctrl+c        Exit without cd
    /             Fuzzy search
    d, delete     Delete file or dir
    y             Copy to clipboard
    .             Hide hidden files
    ?             Show help

  Flags:

    --icons        display icons
    --dir-only     show dirs only
    --hide-hidden  hide hidden files
    --preview      display preview
    --with-border  preview with border
    --fuzzy        fuzzy mode
"""


def go_panic(message):
    sys.stderr.write(f"panic: {message}\n\n")
    sys.stderr.write("goroutine 1 [running]:\n")
    sys.stderr.write("main.main()\n")
    sys.stderr.write("\t/workspace/main.go:135 +0x87d\n")
    return 2


def parse_args(argv):
    flags = {
        "hide_hidden": False,
        "dir_only": False,
    }
    path = "."
    for arg in argv:
        if arg in ("--version", "-v"):
            print(VERSION)
            raise SystemExit(0)
        if arg in ("--help", "-h"):
            sys.stderr.write(HELP)
            raise SystemExit(1)
        if arg == "--hide-hidden":
            flags["hide_hidden"] = True
        elif arg == "--dir-only":
            flags["dir_only"] = True
        elif arg in ("--icons", "--preview", "--with-border", "--fuzzy"):
            pass
        elif not arg.startswith("-") and path == ".":
            path = arg
    return os.path.abspath(path), flags


def entries_for(path, flags):
    try:
        names = sorted(os.listdir(path))
    except OSError:
        return []
    out = []
    for name in names:
        if flags["hide_hidden"] and name.startswith("."):
            continue
        full = os.path.join(path, name)
        is_dir = os.path.isdir(full)
        if flags["dir_only"] and not is_dir:
            continue
        out.append(name + ("/" if is_dir else ""))
    return out


def render(path, flags, selected):
    sys.stdout.write("\x1b[?25l\x1b[?2004h\r")
    items = entries_for(path, flags)
    if not items:
        sys.stdout.write("\r\n")
    else:
        start = max(0, min(selected, max(0, len(items) - 2)))
        for item in items[start : start + 2]:
            sys.stdout.write("\r\n" + item.ljust(7))
    if items:
        sys.stdout.write("\x1b[D\x1b[2A")
    sys.stdout.flush()
    return items


def restore_and_print(path):
    sys.stdout.write("\n\n\n\x1b[D\x1b[2K\r")
    sys.stdout.write("\x1b[?2004l\x1b[?25h\x1b[?1002l\x1b[?1003l\x1b[?1006l")
    sys.stdout.write(path + "\r\n")
    sys.stdout.flush()


def interactive(path, flags):
    selected = 0
    old = None
    try:
        old = termios.tcgetattr(sys.stdin.fileno())
        tty.setraw(sys.stdin.fileno())
        items = render(path, flags, selected)
        while True:
            ch = os.read(sys.stdin.fileno(), 1)
            if not ch:
                break
            if ch in (b"q", b"\x1b"):
                restore_and_print(path)
                return 0
            if ch == b"\x03":
                sys.stdout.write("\x1b[?2004l\x1b[?25h")
                sys.stdout.flush()
                return 0
            if ch in (b"j", b"\x0e"):
                selected = min(selected + 1, max(0, len(items) - 1))
                items = render(path, flags, selected)
            elif ch in (b"k", b"\x10"):
                selected = max(0, selected - 1)
                items = render(path, flags, selected)
            elif ch == b".":
                flags["hide_hidden"] = not flags["hide_hidden"]
                selected = 0
                items = render(path, flags, selected)
            elif ch in (b"\r", b"\n"):
                if items and selected < len(items):
                    name = items[selected].rstrip("/")
                    full = os.path.join(path, name)
                    if os.path.isdir(full):
                        path = os.path.abspath(full)
                        selected = 0
                        items = render(path, flags, selected)
            elif ch in (b"\x7f", b"\b"):
                parent = os.path.dirname(path)
                if parent and parent != path:
                    path = parent
                    selected = 0
                    items = render(path, flags, selected)
    finally:
        if old is not None:
            termios.tcsetattr(sys.stdin.fileno(), termios.TCSADRAIN, old)
    restore_and_print(path)
    return 0


def main(argv):
    path, flags = parse_args(argv)
    if not sys.stdin.isatty():
        return go_panic("could not open a new TTY: open /dev/tty: no such device or address")
    return interactive(path, flags)


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
