module reimplementation/go-mod-outdated

go 1.20
