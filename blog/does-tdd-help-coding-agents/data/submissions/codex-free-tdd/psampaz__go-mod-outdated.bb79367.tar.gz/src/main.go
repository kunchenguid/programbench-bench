package main

import (
	"encoding/json"
	"flag"
	"fmt"
	"io"
	"log"
	"os"
	"strings"
	"time"

	"reimplementation/go-mod-outdated/internal/mod"
)

type row struct {
	module          string
	version         string
	newVersion      string
	direct          string
	validTimestamps string
	hasUpdate       bool
}

var headers = []string{"MODULE", "VERSION", "NEW VERSION", "DIRECT", "VALID TIMESTAMPS"}

func main() {
	ci := flag.Bool("ci", false, "Non-zero exit code when at least one outdated dependency was found")
	directOnly := flag.Bool("direct", false, "List only direct modules")
	style := flag.String("style", "default", "Output style, pass 'markdown' for a Markdown table")
	updateOnly := flag.Bool("update", false, "List only modules with updates")
	flag.Parse()

	rows := readRows(os.Stdin, *directOnly, *updateOnly)
	if len(rows) > 0 {
		fmt.Print(render(rows, *style))
	}

	if *ci && containsUpdate(rows) {
		os.Exit(1)
	}
}

func readRows(r io.Reader, directOnly bool, updateOnly bool) []row {
	dec := json.NewDecoder(r)
	var rows []row

	for {
		var m mod.Module
		err := dec.Decode(&m)
		if err == io.EOF {
			break
		}
		if err != nil {
			log.Println(err)
			break
		}

		if m.Main {
			continue
		}

		hasUpdate := m.Update != nil
		if updateOnly && !hasUpdate {
			continue
		}
		if directOnly && m.Indirect {
			continue
		}

		newVersion := ""
		if hasUpdate {
			newVersion = m.Update.Version
		}

		rows = append(rows, row{
			module:          m.Path,
			version:         m.Version,
			newVersion:      newVersion,
			direct:          boolString(!m.Indirect),
			validTimestamps: boolString(validTimestamps(m)),
			hasUpdate:       hasUpdate,
		})
	}

	return rows
}

func boolString(v bool) string {
	if v {
		return "true"
	}
	return "false"
}

func validTimestamps(m mod.Module) bool {
	if m.Update == nil || m.Time == "" || m.Update.Time == "" {
		return true
	}
	current, err := time.Parse(time.RFC3339, m.Time)
	if err != nil {
		return true
	}
	update, err := time.Parse(time.RFC3339, m.Update.Time)
	if err != nil {
		return true
	}
	return !update.Before(current)
}

func containsUpdate(rows []row) bool {
	for _, r := range rows {
		if r.hasUpdate {
			return true
		}
	}
	return false
}

func render(rows []row, style string) string {
	widths := columnWidths(rows)
	var b strings.Builder

	if style == "markdown" {
		writeHeader(&b, widths)
		writeMarkdownSeparator(&b, widths)
		for _, r := range rows {
			writeRow(&b, widths, rowCells(r))
		}
		return b.String()
	}

	writeBorder(&b, widths)
	writeHeader(&b, widths)
	writeBorder(&b, widths)
	for _, r := range rows {
		writeRow(&b, widths, rowCells(r))
	}
	writeBorder(&b, widths)
	return b.String()
}

func columnWidths(rows []row) []int {
	widths := make([]int, len(headers))
	for i, h := range headers {
		widths[i] = len(h)
	}
	for _, r := range rows {
		for i, cell := range rowCells(r) {
			if len(cell) > widths[i] {
				widths[i] = len(cell)
			}
		}
	}
	return widths
}

func rowCells(r row) []string {
	return []string{r.module, r.version, r.newVersion, r.direct, r.validTimestamps}
}

func writeBorder(b *strings.Builder, widths []int) {
	b.WriteByte('+')
	for _, w := range widths {
		b.WriteString(strings.Repeat("-", w+2))
		b.WriteByte('+')
	}
	b.WriteByte('\n')
}

func writeMarkdownSeparator(b *strings.Builder, widths []int) {
	b.WriteByte('|')
	for _, w := range widths {
		b.WriteString(strings.Repeat("-", w+2))
		b.WriteByte('|')
	}
	b.WriteByte('\n')
}

func writeHeader(b *strings.Builder, widths []int) {
	b.WriteByte('|')
	for i, h := range headers {
		b.WriteByte(' ')
		b.WriteString(center(h, widths[i]))
		b.WriteByte(' ')
		b.WriteByte('|')
	}
	b.WriteByte('\n')
}

func writeRow(b *strings.Builder, widths []int, cells []string) {
	b.WriteByte('|')
	for i, c := range cells {
		b.WriteByte(' ')
		b.WriteString(c)
		b.WriteString(strings.Repeat(" ", widths[i]-len(c)))
		b.WriteByte(' ')
		b.WriteByte('|')
	}
	b.WriteByte('\n')
}

func center(s string, width int) string {
	padding := width - len(s)
	if padding <= 0 {
		return s
	}
	left := padding / 2
	right := padding - left
	return strings.Repeat(" ", left) + s + strings.Repeat(" ", right)
}
