#!/usr/bin/env python3
import os
import subprocess
import textwrap
import unittest


ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
BIN = os.path.join(ROOT, "build", "gomodoutdated")


INPUT = textwrap.dedent(
    """\
    {
      "Path": "example.com/root",
      "Main": true,
      "Dir": "/tmp/root"
    }
    {
      "Path": "github.com/direct/old",
      "Version": "v1.0.0",
      "Time": "2020-01-01T00:00:00Z",
      "Update": {"Path":"github.com/direct/old", "Version":"v1.1.0", "Time":"2020-02-01T00:00:00Z"}
    }
    {
      "Path": "github.com/indirect/new",
      "Version": "v2.0.0",
      "Time": "2021-03-01T00:00:00Z",
      "Indirect": true
    }
    {
      "Path": "github.com/indirect/oldbadtime",
      "Version": "v0.9.0",
      "Time": "2023-01-01T00:00:00Z",
      "Indirect": true,
      "Update": {"Path":"github.com/indirect/oldbadtime", "Version":"v1.0.0", "Time":"2022-01-01T00:00:00Z"}
    }
    """
)


class GoModOutdatedBehavior(unittest.TestCase):
    def run_bin(self, *args, stdin=INPUT):
        return subprocess.run(
            [BIN, *args],
            input=stdin,
            text=True,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
        )

    def test_default_table_skips_main_and_marks_direct_and_timestamps(self):
        result = self.run_bin()

        self.assertEqual(result.returncode, 0)
        self.assertEqual(result.stderr, "")
        self.assertEqual(
            result.stdout,
            textwrap.dedent(
                """\
                +--------------------------------+---------+-------------+--------+------------------+
                |             MODULE             | VERSION | NEW VERSION | DIRECT | VALID TIMESTAMPS |
                +--------------------------------+---------+-------------+--------+------------------+
                | github.com/direct/old          | v1.0.0  | v1.1.0      | true   | true             |
                | github.com/indirect/new        | v2.0.0  |             | false  | true             |
                | github.com/indirect/oldbadtime | v0.9.0  | v1.0.0      | false  | false            |
                +--------------------------------+---------+-------------+--------+------------------+
                """
            ),
        )

    def test_markdown_style_omits_outer_borders(self):
        result = self.run_bin("-style", "markdown", "-update")

        self.assertEqual(result.returncode, 0)
        self.assertEqual(
            result.stdout,
            textwrap.dedent(
                """\
                |             MODULE             | VERSION | NEW VERSION | DIRECT | VALID TIMESTAMPS |
                |--------------------------------|---------|-------------|--------|------------------|
                | github.com/direct/old          | v1.0.0  | v1.1.0      | true   | true             |
                | github.com/indirect/oldbadtime | v0.9.0  | v1.0.0      | false  | false            |
                """
            ),
        )

    def test_direct_filter_excludes_indirect_modules(self):
        result = self.run_bin("-direct")

        self.assertEqual(result.returncode, 0)
        self.assertEqual(
            result.stdout,
            textwrap.dedent(
                """\
                +-----------------------+---------+-------------+--------+------------------+
                |        MODULE         | VERSION | NEW VERSION | DIRECT | VALID TIMESTAMPS |
                +-----------------------+---------+-------------+--------+------------------+
                | github.com/direct/old | v1.0.0  | v1.1.0      | true   | true             |
                +-----------------------+---------+-------------+--------+------------------+
                """
            ),
        )

    def test_update_filter_with_no_rows_prints_nothing(self):
        result = self.run_bin(
            "-update",
            stdin='{"Path":"x/y","Version":"v1","Time":"2020-01-01T00:00:00Z"}\n',
        )

        self.assertEqual(result.returncode, 0)
        self.assertEqual(result.stdout, "")
        self.assertEqual(result.stderr, "")

    def test_ci_fails_when_filtered_result_contains_update(self):
        self.assertEqual(self.run_bin("-ci").returncode, 1)
        self.assertEqual(self.run_bin("-ci", "-direct").returncode, 1)
        self.assertEqual(
            self.run_bin(
                "-ci",
                "-direct",
                stdin='{"Path":"x/y","Version":"v1","Time":"2020-01-01T00:00:00Z"}\n',
            ).returncode,
            0,
        )

    def test_array_input_logs_reference_decoder_type_and_exits_zero(self):
        result = self.run_bin(stdin='[{"Path":"x/y","Version":"v1"}]\n')

        self.assertEqual(result.returncode, 0)
        self.assertEqual(result.stdout, "")
        self.assertIn(
            "json: cannot unmarshal array into Go value of type mod.Module",
            result.stderr,
        )


if __name__ == "__main__":
    unittest.main()
