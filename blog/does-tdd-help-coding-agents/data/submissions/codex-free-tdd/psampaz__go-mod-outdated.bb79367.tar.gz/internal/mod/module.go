package mod

type Module struct {
	Path     string  `json:"Path"`
	Version  string  `json:"Version"`
	Main     bool    `json:"Main"`
	Indirect bool    `json:"Indirect"`
	Time     string  `json:"Time"`
	Update   *Module `json:"Update"`
}
