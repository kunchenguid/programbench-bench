#!/usr/bin/env python3
import os
import random
import select
import subprocess
import sys
import time
from dataclasses import dataclass


HELP = """
USAGE: 

   ./executable  [-i <path to directory>] [-s <positive integer>] [-d <a
                 string containing two space-seprated positive integers>]
                 [-n <{1,2,3,4,5,6}>] [-r] [-t] [-o] [-q] [--] [--version]
                 [-h] <Array of strings> ...


Where: 

   -i <path to directory>,  --replaydirectory <path to directory>
     The path to directory for replay output.

   -s <positive integer>,  --seed <positive integer>
     The seed for the map generator.

   -d <a string containing two space-seprated positive integers>, 
      --dimensions <a string containing two space-seprated positive
      integers>
     The dimensions of the map.

   -n <{1,2,3,4,5,6}>,  --nplayers <{1,2,3,4,5,6}>
     Create a map that will accommodate n players [SINGLE PLAYER MODE
     ONLY].

   -r,  --noreplay
     Turns off the replay generation.

   -t,  --timeout
     Causes game environment to ignore timeouts (give all bots infinite
     time).

   -o,  --override
     Overrides player-sent names using cmd args [SERVER ONLY].

   -q,  --quiet
     Runs game in quiet mode, producing machine-parsable output.

   --,  --ignore_rest
     Ignores the rest of the labeled arguments following this flag.

   --version
     Displays version information and exits.

   -h,  --help
     Displays usage information and exits.

   <Array of strings>  (accepted multiple times)
     Start commands for bots.


   Halite Game Environment
"""


BRIEF = """Brief USAGE: 
   ./executable  [-i <path to directory>] [-s <positive integer>] [-d <a
                 string containing two space-seprated positive integers>]
                 [-n <{1,2,3,4,5,6}>] [-r] [-t] [-o] [-q] [--] [--version]
                 [-h] <Array of strings> ...

For complete USAGE and HELP type: 
   ./executable --help
"""


@dataclass
class Options:
    replay_dir: str = "."
    seed: int | None = None
    dimensions: tuple[int, int] | None = None
    nplayers: int | None = None
    noreplay: bool = False
    ignore_timeouts: bool = False
    override_names: bool = False
    quiet: bool = False
    commands: list[str] = None


def normalize_dimensions(dimensions):
    width, height = dimensions
    if width > 1:
        width -= width % 2
    if height > 1:
        height -= height % 2
    return width, height


def encode_frame(owners, strengths):
    if not owners:
        return ""
    parts = []
    current = owners[0]
    count = 1
    for owner in owners[1:]:
        if owner == current:
            count += 1
        else:
            parts.extend([str(count), str(current)])
            current = owner
            count = 1
    parts.extend([str(count), str(current)])
    parts.extend(str(int(value)) for value in strengths)
    return " ".join(parts) + " "


def nonnegative_int(text, flag):
    try:
        value = int(text)
    except ValueError:
        parse_error(flag, text)
    if value < 0:
        parse_error(flag, text)
    return value


def positive_int(text, flag):
    value = nonnegative_int(text, flag)
    if value <= 0:
        parse_error(flag, text)
    return value


def parse_error(flag, text):
    names = {
        "-s": "-s (--seed)",
        "--seed": "-s (--seed)",
        "-d": "-d (--dimensions)",
        "--dimensions": "-d (--dimensions)",
        "-n": "-n (--nplayers)",
        "--nplayers": "-n (--nplayers)",
    }
    sys.stdout.write(
        f"PARSE ERROR: Argument: {names.get(flag, flag)}\n"
        f"             Couldn't read argument value from string '{text}'\n\n"
        f"{BRIEF}\n"
    )
    raise SystemExit(1)


def parse_args(argv):
    opts = Options(commands=[])
    i = 0
    while i < len(argv):
        arg = argv[i]
        if arg in ("-h", "--help"):
            sys.stdout.write(HELP)
            raise SystemExit(0)
        if arg == "--version":
            sys.stdout.write("\n./executable  version: 1.2\n\n")
            raise SystemExit(0)
        if arg in ("-q", "--quiet"):
            opts.quiet = True
            i += 1
        elif arg in ("-r", "--noreplay"):
            opts.noreplay = True
            i += 1
        elif arg in ("-t", "--timeout"):
            opts.ignore_timeouts = True
            i += 1
        elif arg in ("-o", "--override"):
            opts.override_names = True
            i += 1
        elif arg in ("-i", "--replaydirectory"):
            i += 1
            if i >= len(argv):
                parse_error(arg, "")
            opts.replay_dir = argv[i]
            i += 1
        elif arg in ("-s", "--seed"):
            i += 1
            if i >= len(argv):
                parse_error(arg, "")
            opts.seed = nonnegative_int(argv[i], arg)
            i += 1
        elif arg in ("-d", "--dimensions"):
            i += 1
            if i >= len(argv):
                parse_error(arg, "")
            pieces = argv[i].split()
            if len(pieces) != 2:
                parse_error(arg, argv[i])
            try:
                dims = (int(pieces[0]), int(pieces[1]))
            except ValueError:
                parse_error(arg, argv[i])
            if dims[0] <= 0 or dims[1] <= 0:
                parse_error(arg, argv[i])
            opts.dimensions = dims
            i += 1
        elif arg in ("-n", "--nplayers"):
            i += 1
            if i >= len(argv):
                parse_error(arg, "")
            opts.nplayers = positive_int(argv[i], arg)
            i += 1
        elif arg in ("--", "--ignore_rest"):
            opts.commands.extend(argv[i + 1 :])
            break
        else:
            opts.commands.append(arg)
            i += 1
    return opts


def choose_dimensions(opts, player_count):
    if opts.dimensions:
        return normalize_dimensions(opts.dimensions)
    accommodated = opts.nplayers or player_count
    defaults = {1: (34, 34), 2: (40, 40), 3: (40, 40), 4: (40, 40), 5: (44, 44), 6: (48, 48)}
    return defaults.get(accommodated, (40, 40))


def make_map(width, height, player_count, seed):
    rng = random.Random(seed)
    total = width * height
    production = [rng.randint(1, 12) for _ in range(total)]
    owners = [0] * total
    strengths = [rng.randint(32, 220) for _ in range(total)]
    starts = start_positions(width, height, player_count)
    for pid, idx in enumerate(starts, start=1):
        owners[idx] = pid
        strengths[idx] = 1
    return production, owners, strengths


def start_positions(width, height, player_count):
    coords_by_count = {
        1: [(width // 2, height // 2)],
        2: [(width // 2 - 1, height // 2), (width // 2, height // 2)],
        3: [(width // 2, height // 3), (width // 3, 2 * height // 3), (2 * width // 3, 2 * height // 3)],
        4: [(width // 3, height // 3), (2 * width // 3, height // 3), (width // 3, 2 * height // 3), (2 * width // 3, 2 * height // 3)],
        5: [(width // 2, height // 2), (width // 3, height // 3), (2 * width // 3, height // 3), (width // 3, 2 * height // 3), (2 * width // 3, 2 * height // 3)],
        6: [(width // 3, height // 4), (2 * width // 3, height // 4), (width // 4, height // 2), (3 * width // 4, height // 2), (width // 3, 3 * height // 4), (2 * width // 3, 3 * height // 4)],
    }
    result = []
    for x, y in coords_by_count.get(player_count, coords_by_count[2])[:player_count]:
        result.append((y % height) * width + (x % width))
    return result


def line_with_timeout(pipe, timeout):
    if timeout is None:
        return pipe.readline()
    ready, _, _ = select.select([pipe], [], [], timeout)
    if not ready:
        return None
    return pipe.readline()


def send_line(proc, line):
    try:
        proc.stdin.write(line + "\n")
        proc.stdin.flush()
        return True
    except Exception:
        return False


def parse_moves(text, width, height):
    if not text:
        return {}
    parts = text.split()
    moves = {}
    for i in range(0, len(parts) - 2, 3):
        try:
            x, y, direction = int(parts[i]), int(parts[i + 1]), int(parts[i + 2])
        except ValueError:
            continue
        if 0 <= x < width and 0 <= y < height and 0 <= direction <= 4:
            moves[y * width + x] = direction
    return moves


def apply_turn(width, height, production, owners, strengths, player_moves):
    destinations = {}
    for idx, owner in enumerate(owners):
        if owner == 0:
            continue
        direction = player_moves.get(owner, {}).get(idx, 0)
        dest = destination(idx, direction, width, height)
        destinations.setdefault(dest, []).append(idx)
    new_owners = owners[:]
    new_strengths = strengths[:]
    for idx, owner in enumerate(owners):
        if owner and player_moves.get(owner, {}).get(idx, 0) == 0:
            new_strengths[idx] = min(255, strengths[idx] + production[idx])
    for dest, sources in destinations.items():
        if len(sources) == 1 and sources[0] == dest:
            continue
        power = {}
        for src in sources:
            power[owners[src]] = power.get(owners[src], 0) + strengths[src]
            if src != dest:
                new_owners[src] = 0
                new_strengths[src] = 0
        if owners[dest] not in power:
            power[owners[dest]] = power.get(owners[dest], 0) + strengths[dest]
        winner, win_power = max(power.items(), key=lambda item: (item[1], item[0]))
        opposing = sum(value for key, value in power.items() if key != winner)
        if win_power > opposing:
            new_owners[dest] = winner
            new_strengths[dest] = min(255, win_power - opposing)
        else:
            new_owners[dest] = 0
            new_strengths[dest] = 0
    return new_owners, new_strengths


def destination(idx, direction, width, height):
    x = idx % width
    y = idx // width
    if direction == 1:
        y = (y - 1) % height
    elif direction == 2:
        x = (x + 1) % width
    elif direction == 3:
        y = (y + 1) % height
    elif direction == 4:
        x = (x - 1) % width
    return y * width + x


def run_game(opts):
    if opts.nplayers is not None and (opts.nplayers < 1 or opts.nplayers > 6):
        for command in opts.commands:
            print(command)
        print("\nA map can only accommodate between 1 and 6 players.\n")
        return 1
    if opts.nplayers is not None and len(opts.commands) > 1:
        for command in opts.commands:
            print(command)
        print("\nOnly single-player mode enables specified n-player maps.  When entering multiple bots, please do not try to specify n.\n")
        return 1
    if not opts.commands:
        print("Please provide the launch command string for at least one bot.")
        print("Use the --help flag for usage details.")
        return 1
    player_count = len(opts.commands)
    width, height = choose_dimensions(opts, player_count)
    seed = opts.seed if opts.seed is not None else random.randint(1, 2**32 - 1)
    production, owners, strengths = make_map(width, height, player_count, seed)
    production_line = " ".join(str(x) for x in production) + " "
    frame = encode_frame(owners, strengths)
    for command in opts.commands:
        print(command)
    procs = []
    names = {}
    alive = {}
    for pid, command in enumerate(opts.commands, start=1):
        try:
            proc = subprocess.Popen(
                command,
                shell=True,
                stdin=subprocess.PIPE,
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                text=True,
                bufsize=1,
            )
        except Exception:
            proc = None
        procs.append(proc)
        alive[pid] = proc is not None
        if proc is None:
            names[pid] = command
            continue
        for line in (str(pid), f"{width} {height} ", production_line, frame):
            if not send_line(proc, line):
                alive[pid] = False
                break
        timeout = None if opts.ignore_timeouts else 1.0
        name = line_with_timeout(proc.stdout, timeout) if alive[pid] else None
        if name is None or name == "":
            alive[pid] = False
            names[pid] = command
        else:
            names[pid] = command if opts.override_names else name.rstrip("\n")
    max_turns = max(1, min(max(width, height) * 10, width * height))
    last_alive = {pid: 0 for pid in range(1, player_count + 1)}
    active = {pid for pid, ok in alive.items() if ok}
    turn = 0
    if len(active) > 1:
        for turn in range(1, max_turns + 1):
            if not opts.quiet:
                print(f"Turn {turn}")
            moves_by_player = {}
            frame = encode_frame(owners, strengths)
            for pid in list(active):
                proc = procs[pid - 1]
                if proc.poll() is not None or not send_line(proc, frame):
                    active.discard(pid)
                    continue
                move_line = line_with_timeout(proc.stdout, None if opts.ignore_timeouts else 1.0)
                if move_line is None or move_line == "":
                    active.discard(pid)
                    continue
                moves_by_player[pid] = parse_moves(move_line, width, height)
                last_alive[pid] = turn
            if not active:
                break
            owners, strengths = apply_turn(width, height, production, owners, strengths, moves_by_player)
            present = {owner for owner in owners if owner}
            for pid in present:
                last_alive[pid] = turn
            if len(present) <= 1 and turn > 0:
                active &= present
                break
    for proc in procs:
        if proc is not None:
            try:
                proc.stdin.close()
            except Exception:
                pass
            try:
                proc.terminate()
            except Exception:
                pass
    if not opts.noreplay:
        path = os.path.join(opts.replay_dir, f"{int(time.time())}-{seed}.hlt")
        try:
            os.makedirs(opts.replay_dir, exist_ok=True)
            with open(path, "w", encoding="utf-8") as handle:
                handle.write(f"{width} {height}\n{seed}\n")
            if opts.quiet:
                print(path, seed)
            else:
                print(f"Map seed was {seed}")
                print(f"Opening a file at {path}")
        except OSError:
            pass
    scores = []
    for pid in range(1, player_count + 1):
        cells = sum(1 for owner in owners if owner == pid)
        strength = sum(strengths[i] for i, owner in enumerate(owners) if owner == pid)
        scores.append((pid, cells, strength, last_alive.get(pid, 0)))
    ordered = sorted(scores, key=lambda row: (row[1], row[2], row[3], -row[0]), reverse=True)
    ranks = {pid: rank for rank, (pid, *_rest) in enumerate(ordered, start=1)}
    if opts.quiet:
        print(f"{width} {height}")
        for pid, _cells, _strength, alive_turn in scores:
            print(f"{pid} {ranks[pid]} {alive_turn}")
        print(" ")
    else:
        for pid, _cells, _strength, alive_turn in scores:
            print(f"Player #{pid}, {names.get(pid, opts.commands[pid-1])}, came in rank #{ranks[pid]} and was last alive on frame #{alive_turn}!")
    return 0


def main(argv=None):
    argv = sys.argv[1:] if argv is None else argv
    try:
        opts = parse_args(argv)
        return run_game(opts)
    except BrokenPipeError:
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
