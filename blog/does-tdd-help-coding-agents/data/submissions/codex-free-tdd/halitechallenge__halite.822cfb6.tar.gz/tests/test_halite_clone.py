import os
import subprocess
import sys
import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]


def run_cli(*args, timeout=5):
    return subprocess.run(
        [sys.executable, str(ROOT / "src" / "halite_clone.py"), *args],
        text=True,
        capture_output=True,
        timeout=timeout,
    )


def make_passive_bot(tmp_path):
    bot = tmp_path / "passive.py"
    bot.write_text(
        """#!/usr/bin/env python3
import sys
for _ in range(4):
    if not sys.stdin.readline():
        sys.exit(0)
print("Passive", flush=True)
while sys.stdin.readline():
    print("", flush=True)
""",
        encoding="utf-8",
    )
    bot.chmod(0o755)
    return bot


class HaliteCloneTests(unittest.TestCase):
    def test_help_matches_documented_usage(self):
        result = run_cli("--help")
        self.assertEqual(result.returncode, 0)
        self.assertIn("Halite Game Environment", result.stdout)
        self.assertIn("--dimensions <a string containing two space-seprated positive", result.stdout)
        self.assertEqual(result.stderr, "")

    def test_version_is_1_2(self):
        result = run_cli("--version")
        self.assertEqual(result.returncode, 0)
        self.assertEqual(result.stdout, "\n./executable  version: 1.2\n\n")

    def test_odd_dimensions_are_floored_to_even_values(self):
        from halite_clone import normalize_dimensions

        self.assertEqual(normalize_dimensions((31, 31)), (30, 30))
        self.assertEqual(normalize_dimensions((5, 5)), (4, 4))
        self.assertEqual(normalize_dimensions((10, 8)), (10, 8))

    def test_frame_encoding_uses_owner_run_lengths_then_strengths(self):
        from halite_clone import encode_frame

        owners = [0, 0, 1, 1, 1, 0]
        strengths = [5, 6, 7, 8, 9, 10]
        self.assertEqual(encode_frame(owners, strengths), "2 0 3 1 1 0 5 6 7 8 9 10 ")

    def test_quiet_two_passive_bot_game_prints_protocol_summary(self):
        import tempfile

        with tempfile.TemporaryDirectory() as tmp:
            bot = make_passive_bot(Path(tmp))
            cmd = f"{sys.executable} {bot}"
            result = run_cli("-q", "-r", "-s", "1", "-d", "5 5", cmd, cmd)
        self.assertEqual(result.returncode, 0)
        lines = result.stdout.splitlines()
        self.assertEqual(lines[:3], [cmd, cmd, "4 4"])
        self.assertTrue(lines[3].startswith("1 "))
        self.assertTrue(lines[4].startswith("2 "))

    def test_tiny_dimensions_are_not_clamped(self):
        import tempfile

        with tempfile.TemporaryDirectory() as tmp:
            bot = make_passive_bot(Path(tmp))
            cmd = f"{sys.executable} {bot}"
            result = run_cli("-q", "-r", "-d", "1 1", cmd)
        self.assertEqual(result.returncode, 0)
        self.assertEqual(result.stdout.splitlines()[:2], [cmd, "1 1"])

    def test_seed_zero_is_accepted(self):
        import tempfile

        with tempfile.TemporaryDirectory() as tmp:
            bot = make_passive_bot(Path(tmp))
            cmd = f"{sys.executable} {bot}"
            result = run_cli("-q", "-r", "-s", "0", "-d", "1 1", cmd)
        self.assertEqual(result.returncode, 0)
        self.assertIn("1 1", result.stdout)

    def test_nplayers_rejected_with_multiple_bot_commands(self):
        result = run_cli("-q", "-r", "-n", "2", "bot-a", "bot-b")
        self.assertEqual(result.returncode, 1)
        self.assertIn("Only single-player mode enables specified n-player maps.", result.stdout)


if __name__ == "__main__":
    unittest.main()
