#!/bin/bash
set -euo pipefail

ROOT="$(cd "$(dirname "$0")/.." && pwd)"
REF=/workspace/executable
IMPL="$ROOT/src/ninja.py"

run_case() {
  local name="$1"
  shift
  local tmp
  tmp="$(mktemp -d)"
  local ref_out impl_out
  ref_out="$tmp/ref"
  impl_out="$tmp/impl"
  set +e
  "$REF" "$@" >"$ref_out" 2>&1
  local ref_status=$?
  python3 "$IMPL" "$@" >"$impl_out" 2>&1
  local impl_status=$?
  set -e
  if [[ "$ref_status" != "$impl_status" ]]; then
    echo "$name: status mismatch: ref=$ref_status impl=$impl_status" >&2
    diff -u "$ref_out" "$impl_out" || true
    exit 1
  fi
  if ! diff -u "$ref_out" "$impl_out"; then
    echo "$name: output mismatch" >&2
    exit 1
  fi
}

run_case_in_dirs() {
  local name="$1"
  local fixture="$2"
  shift 2
  local tmp ref_dir impl_dir ref_out impl_out
  tmp="$(mktemp -d)"
  ref_dir="$tmp/refdir"
  impl_dir="$tmp/impldir"
  cp -R "$fixture" "$ref_dir"
  cp -R "$fixture" "$impl_dir"
  ref_out="$tmp/ref"
  impl_out="$tmp/impl"
  set +e
  (cd "$ref_dir" && "$REF" "$@") >"$ref_out" 2>&1
  local ref_status=$?
  (cd "$impl_dir" && python3 "$IMPL" "$@") >"$impl_out" 2>&1
  local impl_status=$?
  set -e
  if [[ "$ref_status" != "$impl_status" ]]; then
    echo "$name: status mismatch: ref=$ref_status impl=$impl_status" >&2
    diff -u "$ref_out" "$impl_out" || true
    exit 1
  fi
  if ! diff -u "$ref_out" "$impl_out"; then
    echo "$name: output mismatch" >&2
    exit 1
  fi
  REF_LAST_DIR="$ref_dir"
  IMPL_LAST_DIR="$impl_dir"
}

run_case "version" --version
run_case "help" --help

tmp="$(mktemp -d)"
(
  cd "$tmp"
  run_case "missing build file"
)

tmp="$(mktemp -d)"
cat >"$tmp/build.ninja" <<'NINJA'
rule touch
  command = touch $out

build output.txt: touch
NINJA
run_case_in_dirs "simple dry run" "$tmp" -n
if [[ -e "$REF_LAST_DIR/output.txt" || -e "$IMPL_LAST_DIR/output.txt" ]]; then
  echo "simple dry run: output should not exist" >&2
  exit 1
fi
run_case_in_dirs "simple build" "$tmp"
if [[ ! -e "$REF_LAST_DIR/output.txt" || ! -e "$IMPL_LAST_DIR/output.txt" ]]; then
  echo "simple build: output should exist" >&2
  exit 1
fi
run_case_in_dirs "simple no work" "$REF_LAST_DIR"

tmp="$(mktemp -d)"
cat >"$tmp/build.ninja" <<'NINJA'
cc = gcc
rule cc
  command = $cc -c $in -o $out
  description = Compiling $in

rule link
  command = $cc $in -o $out
  description = Linking $out

build main.o: cc main.c
build helper.o: cc helper.c
build app: link main.o helper.o

default app
NINJA
touch "$tmp/main.c" "$tmp/helper.c"
run_case_in_dirs "descriptions dry run default" "$tmp" -n
run_case_in_dirs "rules tool" "$tmp" -t rules
run_case_in_dirs "targets tool" "$tmp" -t targets
run_case_in_dirs "query tool" "$tmp" -t query app
run_case_in_dirs "commands tool" "$tmp" -t commands app

run_case_in_dirs "change directory and file" "$tmp" -C "$tmp" -f build.ninja -n

tmp="$(mktemp -d)"
cat >"$tmp/build.ninja" <<'NINJA'
rule fail
  command = sh -c "echo oops; exit 7"

build x: fail
NINJA
run_case_in_dirs "failing command" "$tmp"
