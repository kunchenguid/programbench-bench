#!/usr/bin/env python3
import json
import os
import shlex
import subprocess
import sys
from dataclasses import dataclass, field

VERSION = "1.14.0.git"
HELP = """usage: ninja [options] [targets...]

if targets are unspecified, builds the 'default' target (see manual).

options:
  --version      print ninja version ("1.14.0.git")
  -v, --verbose  show all command lines while building
  --quiet        don't show progress status, just command output

  -C DIR   change to DIR before doing anything else
  -f FILE  specify input build file [default=build.ninja]

  -j N     run N jobs in parallel (0 means infinity) [default=6 on this system]
  -k N     keep going until N jobs fail (0 means infinity) [default=1]
  -l N     do not start new jobs if the load average is greater than N
  -n       dry run (don't run commands but act like they succeeded)

  -d MODE  enable debugging (use '-d list' to list modes)
  -t TOOL  run a subtool (use '-t list' to list subtools)
    terminates toplevel options; further flags are passed to the tool
  -w FLAG  adjust warnings (use '-w list' to list warnings)"""

TOOLS = """ninja subtools:
     browse  browse dependency graph in a web browser
      clean  clean built files
   commands  list all commands required to rebuild given targets
     inputs  list all inputs required to rebuild given targets
multi-inputs  print one or more sets of inputs required to build targets
       deps  show dependencies stored in the deps log
missingdeps  check deps log dependencies on generated files
      graph  output graphviz dot file for targets
      query  show inputs/outputs for a path
    targets  list targets by their rule or depth in the DAG
     compdb  dump JSON compilation database to stdout
compdb-targets  dump JSON compilation database for a given list of targets to stdout
  recompact  recompacts ninja-internal data structures
     restat  restats all outputs in the build log
      rules  list all rules
  cleandead  clean built files that are no longer produced by the manifest"""


@dataclass
class Rule:
    name: str
    vars: dict = field(default_factory=dict)


@dataclass
class Edge:
    outputs: list
    rule: str
    explicit: list
    implicit: list = field(default_factory=list)
    order_only: list = field(default_factory=list)
    vars: dict = field(default_factory=dict)


class Manifest:
    def __init__(self):
        self.vars = {}
        self.rules = {"phony": Rule("phony", {})}
        self.edges = []
        self.by_output = {}
        self.defaults = []


def unescape_path(s):
    out = ""
    i = 0
    while i < len(s):
        if s[i] == "$" and i + 1 < len(s):
            nxt = s[i + 1]
            if nxt in " :$":
                out += nxt
                i += 2
                continue
            if nxt == "\n":
                i += 2
                continue
        out += s[i]
        i += 1
    return out


def split_words(s):
    return [unescape_path(x) for x in s.split() if x]


def expand(s, env):
    out = ""
    i = 0
    while i < len(s):
        c = s[i]
        if c != "$":
            out += c
            i += 1
            continue
        if i + 1 >= len(s):
            out += "$"
            i += 1
            continue
        n = s[i + 1]
        if n == "$":
            out += "$"
            i += 2
        elif n == " ":
            out += " "
            i += 2
        elif n == ":":
            out += ":"
            i += 2
        elif n == "{":
            j = s.find("}", i + 2)
            if j == -1:
                i += 1
            else:
                out += env.get(s[i + 2:j], "")
                i = j + 1
        elif n.isalnum() or n == "_":
            j = i + 1
            while j < len(s) and (s[j].isalnum() or s[j] == "_"):
                j += 1
            out += env.get(s[i + 1:j], "")
            i = j
        else:
            out += n
            i += 2
    return out


def read_logical_lines(path):
    result = []
    current = ""
    with open(path, "r", encoding="utf-8") as f:
        for raw in f:
            line = raw.rstrip("\n")
            if line.endswith("$"):
                current += line[:-1]
                continue
            result.append(current + line)
            current = ""
    if current:
        result.append(current)
    return result


def parse_manifest(path):
    m = Manifest()
    lines = read_logical_lines(path)
    i = 0
    while i < len(lines):
        line = lines[i]
        stripped = line.strip()
        if not stripped or stripped.startswith("#"):
            i += 1
            continue
        if not line.startswith((" ", "\t")) and "=" in line and not stripped.startswith(("rule ", "build ")):
            k, v = line.split("=", 1)
            m.vars[k.strip()] = expand(v.strip(), m.vars)
            i += 1
            continue
        if stripped.startswith("rule "):
            name = stripped.split(None, 1)[1]
            rule = Rule(name, {})
            i += 1
            while i < len(lines) and lines[i].startswith((" ", "\t")):
                if "=" in lines[i]:
                    k, v = lines[i].split("=", 1)
                    rule.vars[k.strip()] = v.strip()
                i += 1
            m.rules[name] = rule
            continue
        if stripped.startswith("build "):
            rest = stripped[6:]
            if ":" not in rest:
                fatal(f"{path}: parse error")
            outs_part, rhs = rest.split(":", 1)
            rhs_words = rhs.split()
            if not rhs_words:
                fatal(f"{path}: parse error")
            rule_name = rhs_words[0]
            explicit, implicit, order_only = [], [], []
            bucket = explicit
            for word in rhs_words[1:]:
                if word == "|":
                    bucket = implicit
                elif word == "||":
                    bucket = order_only
                elif word.startswith("|@"):
                    bucket = order_only
                else:
                    bucket.append(unescape_path(expand(word, m.vars)))
            edge = Edge(split_words(expand(outs_part, m.vars)), rule_name, explicit, implicit, order_only, {})
            i += 1
            while i < len(lines) and lines[i].startswith((" ", "\t")):
                if "=" in lines[i]:
                    k, v = lines[i].split("=", 1)
                    edge.vars[k.strip()] = v.strip()
                i += 1
            m.edges.append(edge)
            for out in edge.outputs:
                m.by_output[out] = edge
            continue
        if stripped.startswith("default "):
            m.defaults.extend(split_words(expand(stripped[8:], m.vars)))
            i += 1
            continue
        if stripped.startswith(("include ", "subninja ")):
            inc = expand(stripped.split(None, 1)[1], m.vars)
            sub = parse_manifest(inc)
            m.vars.update(sub.vars)
            m.rules.update(sub.rules)
            for e in sub.edges:
                m.edges.append(e)
                for out in e.outputs:
                    m.by_output[out] = e
            m.defaults.extend(sub.defaults)
            i += 1
            continue
        i += 1
    return m


def fatal(msg):
    print(f"ninja: error: {msg}", file=sys.stderr)
    raise SystemExit(1)


def edge_env(m, edge):
    env = dict(m.vars)
    env.update(m.rules.get(edge.rule, Rule(edge.rule)).vars)
    env.update(edge.vars)
    env["in"] = " ".join(edge.explicit + edge.implicit)
    env["in_newline"] = "\n".join(edge.explicit + edge.implicit)
    env["out"] = " ".join(edge.outputs)
    return env


def command_for(m, edge):
    return expand(m.rules.get(edge.rule, Rule(edge.rule)).vars.get("command", ""), edge_env(m, edge))


def description_for(m, edge, verbose):
    env = edge_env(m, edge)
    if verbose:
        return expand(m.rules.get(edge.rule, Rule(edge.rule)).vars.get("command", ""), env)
    desc = edge.vars.get("description", m.rules.get(edge.rule, Rule(edge.rule)).vars.get("description"))
    return expand(desc, env) if desc else expand(m.rules.get(edge.rule, Rule(edge.rule)).vars.get("command", ""), env)


def dirty(m, edge):
    if edge.rule == "phony":
        return False
    if not edge.outputs:
        return False
    out_times = []
    for out in edge.outputs:
        if not os.path.exists(out):
            return True
        out_times.append(os.path.getmtime(out))
    oldest_out = min(out_times)
    for inp in edge.explicit + edge.implicit:
        if inp in m.by_output:
            if dirty(m, m.by_output[inp]):
                return True
        elif os.path.exists(inp) and os.path.getmtime(inp) > oldest_out:
            return True
        elif not os.path.exists(inp):
            return True
    return False


def visit(m, target, seen, order):
    if target not in m.by_output:
        if os.path.exists(target):
            return
        fatal(f"'{target}', needed by 'default', missing and no known rule to make it")
    edge = m.by_output[target]
    if id(edge) in seen:
        return
    seen.add(id(edge))
    for inp in edge.explicit + edge.implicit + edge.order_only:
        if inp in m.by_output:
            visit(m, inp, seen, order)
    if dirty(m, edge):
        order.append(edge)


def build(m, targets, opts):
    if not targets:
        targets = m.defaults or ([m.edges[0].outputs[0]] if m.edges else [])
    order = []
    for t in targets:
        if t.endswith("^"):
            src = t[:-1]
            for e in m.edges:
                if src in e.explicit:
                    t = e.outputs[0]
                    break
        visit(m, t, set(), order)
    unique = []
    seen = set()
    for e in order:
        if id(e) not in seen:
            unique.append(e)
            seen.add(id(e))
    if not unique:
        if not opts.get("quiet"):
            print("ninja: no work to do.")
        return 0
    total = len(unique)
    for idx, edge in enumerate(unique, 1):
        text = description_for(m, edge, opts.get("verbose"))
        if not opts.get("quiet"):
            print(f"[{idx}/{total}] {text}", flush=True)
        cmd = command_for(m, edge)
        if opts.get("dry_run") or not cmd:
            continue
        for out in edge.outputs:
            d = os.path.dirname(out)
            if d:
                os.makedirs(d, exist_ok=True)
        proc = subprocess.run(cmd, shell=True, text=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
        if proc.returncode:
            print(f"FAILED: [code={proc.returncode}] {' '.join(edge.outputs)} ")
            print(cmd)
            if proc.stdout:
                print(proc.stdout, end="")
            print(f"ninja: build stopped: subcommand failed.")
            return proc.returncode
        if proc.stdout:
            print(proc.stdout, end="")
    return 0


def tool(m, name, args):
    if name == "list":
        print(TOOLS)
        return 0
    if name == "rules":
        for r in sorted([r for r in m.rules if r != "phony"]):
            print(r)
        print("phony")
        return 0
    if name == "targets":
        if args and args[0] == "all":
            edges = m.edges
        elif args and args[0] == "rule" and len(args) > 1:
            for e in m.edges:
                if e.rule == args[1]:
                    for inp in e.explicit:
                        print(inp)
            return 0
        else:
            wanted = set(m.defaults or ([m.edges[-1].outputs[0]] if m.edges else []))
            edges = [m.by_output[t] for t in wanted if t in m.by_output]
        for e in edges:
            if e.outputs:
                print(f"{e.outputs[0]}: {e.rule}")
        return 0
    if name == "commands":
        targets = args or m.defaults or ([m.edges[0].outputs[0]] if m.edges else [])
        order = []
        for t in targets:
            visit(m, t, set(), order)
        for e in order:
            cmd = command_for(m, e)
            if cmd:
                print(cmd)
        return 0
    if name == "query":
        for target in args:
            print(f"{target}:")
            e = m.by_output.get(target)
            if not e:
                print("  input: unknown")
                print("  outputs:")
                continue
            print(f"  input: {e.rule}")
            for inp in e.explicit + e.implicit:
                print(f"    {inp}")
            print("  outputs:")
            for out in e.outputs:
                if out != target:
                    print(f"    {out}")
        return 0
    if name == "compdb":
        rules = set(args)
        entries = []
        for e in m.edges:
            if rules and e.rule not in rules:
                continue
            cmd = command_for(m, e)
            if not cmd:
                continue
            for out in e.outputs:
                entries.append({"directory": os.getcwd(), "command": cmd, "file": (e.explicit[0] if e.explicit else out), "output": out})
        print(json.dumps(entries, indent=2))
        return 0
    if name == "clean":
        count = 0
        for e in m.edges:
            for out in e.outputs:
                if os.path.exists(out):
                    os.remove(out)
                    count += 1
        print(f"Cleaning... {count} files.")
        return 0
    if name in ("recompact", "restat", "cleandead", "deps", "missingdeps"):
        return 0
    fatal(f"unknown tool '{name}'")


def main(argv):
    opts = {"file": "build.ninja"}
    targets = []
    i = 0
    if argv == ["--version"]:
        print(VERSION)
        return 0
    if argv in (["--help"], ["-h"]):
        print(HELP)
        return 1
    while i < len(argv):
        a = argv[i]
        if a == "--version":
            print(VERSION)
            return 0
        if a in ("--help", "-h"):
            print(HELP)
            return 1
        if a in ("-n", "--dry-run"):
            opts["dry_run"] = True
        elif a in ("-v", "--verbose"):
            opts["verbose"] = True
        elif a == "--quiet":
            opts["quiet"] = True
        elif a == "-C":
            i += 1
            print(f"ninja: Entering directory `{argv[i]}'")
            os.chdir(argv[i])
        elif a.startswith("-C") and len(a) > 2:
            print(f"ninja: Entering directory `{a[2:]}'")
            os.chdir(a[2:])
        elif a == "-f":
            i += 1
            opts["file"] = argv[i]
        elif a.startswith("-f") and len(a) > 2:
            opts["file"] = a[2:]
        elif a in ("-j", "-k", "-l", "-d", "-w"):
            i += 1
        elif a[:2] in ("-j", "-k", "-l", "-d", "-w") and len(a) > 2:
            pass
        elif a == "-t":
            i += 1
            tool_name = argv[i] if i < len(argv) else "list"
            if tool_name != "list":
                if not os.path.exists(opts["file"]):
                    fatal(f"loading '{opts['file']}': No such file or directory")
                m = parse_manifest(opts["file"])
            else:
                m = Manifest()
            return tool(m, tool_name, argv[i + 1:])
        else:
            targets.append(a)
        i += 1
    if not os.path.exists(opts["file"]):
        fatal(f"loading '{opts['file']}': No such file or directory")
    return build(parse_manifest(opts["file"]), targets, opts)


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
