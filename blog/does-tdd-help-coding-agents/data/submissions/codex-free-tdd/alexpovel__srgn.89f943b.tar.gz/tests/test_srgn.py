import subprocess
import tempfile
import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
BIN = ROOT / "executable"


def run(args, input_text=None, cwd=None):
    return subprocess.run(
        [str(BIN), *args],
        input=input_text,
        text=True,
        cwd=cwd or ROOT,
        capture_output=True,
    )


class SrgnTests(unittest.TestCase):
    def test_replaces_regex_matches_from_stdin(self):
        result = run(["[wW]orld", "--", "there"], "Hello World!\n")
        self.assertEqual(result.returncode, 0)
        self.assertEqual(result.stdout, "Hello there!\n")

    def test_composes_replacement_before_uppercase(self):
        result = run(["--upper", "[wW]orld", "--", "you"], "Hello World!\n")
        self.assertEqual(result.returncode, 0)
        self.assertEqual(result.stdout, "Hello YOU!\n")

    def test_literal_string_scope_is_not_regex(self):
        result = run(["-L", "a+b", "--", "X"], "a+b aab\n")
        self.assertEqual(result.returncode, 0)
        self.assertEqual(result.stdout, "X aab\n")

    def test_delete_requires_explicit_scope_and_removes_matches(self):
        result = run(["-d", "a"], "aaabbb\n")
        self.assertEqual(result.returncode, 0)
        self.assertEqual(result.stdout, "bbb\n")

    def test_symbols_german_and_uppercase_are_composable(self):
        result = run(["-Sgu"], "Koeffizienten != Bruecken...\n")
        self.assertEqual(result.returncode, 0)
        self.assertEqual(result.stdout, "KOEFFIZIENTEN ≠ BRÜCKEN...\n")

    def test_fail_none_returns_one_when_scope_absent(self):
        result = run(["z", "--fail-none"], "abc\n")
        self.assertEqual(result.returncode, 1)
        self.assertIn("No input was in scope", result.stderr)

    def test_only_matching_prints_matching_line_with_ranges(self):
        result = run(["a", "--only-matching"], "a b a\n")
        self.assertEqual(result.returncode, 0)
        self.assertEqual(result.stdout, "(stdin):0-1;4-5:a b a\n")

    def test_line_numbers_adds_line_number_to_search_output(self):
        result = run(["a", "--line-numbers"], "a b a\n")
        self.assertEqual(result.returncode, 0)
        self.assertEqual(result.stdout, "(stdin):1:0-1;4-5:a b a\n")

    def test_squeeze_collapses_consecutive_scope_occurrences(self):
        result = run(["a", "-s"], "aaabbb\n")
        self.assertEqual(result.returncode, 0)
        self.assertEqual(result.stdout, "abbb\n")

    def test_inverted_symbols_leave_unicode_ellipsis_unchanged(self):
        result = run(["-S", "-i"], "x … y ≠ z\n")
        self.assertEqual(result.returncode, 0)
        self.assertEqual(result.stdout, "x … y != z\n")

    def test_glob_replacement_modifies_files_and_prints_names(self):
        with tempfile.TemporaryDirectory() as directory:
            tmp_path = Path(directory)
            (tmp_path / "a.txt").write_text("Hello World\n")
            (tmp_path / "b.txt").write_text("Bye World\n")
            result = run(["-G", "*.txt", "World", "--", "X"], cwd=tmp_path)
            self.assertEqual(result.returncode, 0)
            self.assertEqual(set(result.stdout.splitlines()), {"a.txt", "b.txt"})
            self.assertEqual((tmp_path / "a.txt").read_text(), "Hello X\n")
            self.assertEqual((tmp_path / "b.txt").read_text(), "Bye X\n")

    def test_python_class_scope_reports_regex_matches_with_locations(self):
        source = """import os
# age comment
class Bird:
    age: int
    def fly(self):
        print("age")
"""
        result = run(["--python", "class", "age"], source)
        self.assertEqual(result.returncode, 0)
        self.assertEqual(
            result.stdout,
            "(stdin):4:4-7:    age: int\n"
            '(stdin):6:15-18:        print("age")\n',
        )


if __name__ == "__main__":
    unittest.main()
