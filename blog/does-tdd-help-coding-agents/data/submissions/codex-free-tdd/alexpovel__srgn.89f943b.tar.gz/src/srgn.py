#!/usr/bin/env python3
import fnmatch
import glob
import os
import re
import sys
import unicodedata
from dataclasses import dataclass, field


VERSION = "srgn 0.14.1"


HELP = """A grep-like tool which understands source code syntax and allows for manipulation in
addition to search

Usage: executable [OPTIONS] [SCOPE] [-- <REPLACEMENT>]

Arguments:
  [SCOPE]  Scope to apply to, as a regular expression pattern. [default: .*]

Options:
      --completions <SHELL>  Print shell completions for the given shell. [possible values: bash, elvish, fish, powershell, zsh]
  -h, --help                 Print help (see more with '--help')
  -V, --version              Print version

Composable Actions:
  -u, --upper        Uppercase anything in scope. [env: UPPER=]
  -l, --lower        Lowercase anything in scope. [env: LOWER=]
  -t, --titlecase    Titlecase anything in scope. [env: TITLECASE=]
  -n, --normalize    Normalize (Normalization Form D) anything in scope, and throw away marks. [env: NORMALIZE=]
  -g, --german       Perform substitutions on German words, such as 'Abenteuergruesse' to 'Abenteuergrüße', for anything in scope.
  -S, --symbols      Perform substitutions on symbols, such as '!=' to '≠', '->' to '→', on anything in scope.
  [REPLACEMENT]  Replace anything in scope with this value. [env: REPLACE=]

Standalone Actions (only usable alone):
  -d, --delete   Delete anything in scope.
  -s, --squeeze  Squeeze consecutive occurrences of scope into one. [env: SQUEEZE=]

Options (global):
  -G, --glob <GLOB>          Glob of files to work on (instead of reading stdin).
      --fail-no-files        Fail if working on files but none are found.
      --dry-run              Do not destructively overwrite files, instead print diff only.
  -i, --invert               Undo the effects of passed actions, where applicable. [env: INVERT=]
  -L, --literal-string       Do not interpret the scope as a regex.
      --fail-any             If anything at all is found to be in scope, fail.
      --fail-none            If nothing is found to be in scope, fail.
  -j, --join-language-scopes Join multiple language scopes.
  -H, --hidden               Do not ignore hidden files and directories.
      --gitignored           Do not ignore `.gitignore`d files and directories.
      --sorted               Process files in lexicographically sorted order.
      --stdin-detection <STDIN_DETECTION>   Control stdin detection.
      --stdout-detection <STDOUT_DETECTION> Control stdout detection.
      --threads <THREADS>    Number of threads to run processing on.
  -v, --verbose...           Increase log verbosity level.

Language scopes:
      --python <PYTHON>      Scope Python code using a prepared query. [aliases: py]
      --rust <RUST>          Scope Rust code using a prepared query. [aliases: rs]
      --go <GO>              Scope Go code using a prepared query.
      --typescript <TYPESCRIPT> Scope TypeScript code using a prepared query. [aliases: ts]
      --c <C>                Scope C code using a prepared query.
      --csharp <CSHARP>      Scope C# code using a prepared query. [aliases: cs]
      --hcl <HCL>            Scope HashiCorp Configuration Language code using a prepared query.
"""


@dataclass
class Config:
    scope: str = ".*"
    scope_given: bool = False
    replacement: str | None = None
    upper: bool = False
    lower: bool = False
    titlecase: bool = False
    normalize: bool = False
    german: bool = False
    german_naive: bool = False
    symbols: bool = False
    delete: bool = False
    squeeze: bool = False
    invert: bool = False
    literal: bool = False
    fail_any: bool = False
    fail_none: bool = False
    fail_no_files: bool = False
    dry_run: bool = False
    sorted: bool = False
    glob_pattern: str | None = None
    stdin_detection: str = "auto"
    language_scopes: list[tuple[str, str]] = field(default_factory=list)
    only_matching: bool = False
    line_numbers: bool = False
    files: bool = False
    files_with_matches: bool = False
    query_files: list[str] = field(default_factory=list)
    action_order: list[str] = field(default_factory=list)


def die(message: str, code: int = 1) -> int:
    sys.stderr.write(message + "\n")
    return code


def parse(argv: list[str]) -> Config | int:
    cfg = Config()
    if not argv:
        return cfg
    if argv in (["-h"], ["--help"]):
        print(HELP)
        return 0
    if argv == ["-V"] or argv == ["--version"]:
        print(VERSION)
        return 0
    positionals: list[str] = []
    i = 0
    languages = {
        "--python": "python", "--py": "python", "--rust": "rust", "--rs": "rust",
        "--go": "go", "--typescript": "typescript", "--ts": "typescript",
        "--c": "c", "--csharp": "csharp", "--cs": "csharp", "--hcl": "hcl",
    }
    ignored_value_opts = {
        "--threads", "--stdin-detection", "--stdout-detection", "--completions",
        "--c-query", "--c-query-file", "--csharp-query", "--csharp-query-file",
        "--go-query", "--go-query-file", "--hcl-query", "--hcl-query-file",
        "--python-query", "--python-query-file", "--rust-query", "--rust-query-file",
        "--typescript-query", "--typescript-query-file",
    }
    while i < len(argv):
        arg = argv[i]
        if arg == "--":
            if i + 1 < len(argv):
                cfg.replacement = argv[i + 1]
            break
        if arg in ("-h", "--help"):
            print(HELP)
            return 0
        if arg in ("-V", "--version"):
            print(VERSION)
            return 0
        if arg in languages:
            if i + 1 >= len(argv):
                return die(f"error: a value is required for '{arg}'", 2)
            cfg.language_scopes.append((languages[arg], argv[i + 1]))
            i += 2
            continue
        if arg in ignored_value_opts:
            if arg == "--completions":
                shell = argv[i + 1] if i + 1 < len(argv) else ""
                print(f"# {shell} completions for srgn")
                return 0
            if arg == "--stdin-detection" and i + 1 < len(argv):
                cfg.stdin_detection = argv[i + 1]
            i += 2
            continue
        if arg in ("-G", "--glob"):
            cfg.glob_pattern = argv[i + 1] if i + 1 < len(argv) else ""
            i += 2
            continue
        if arg == "--german-naive":
            cfg.german_naive = True
        elif arg == "--german-prefer-original":
            pass
        elif arg == "--fail-no-files":
            cfg.fail_no_files = True
        elif arg == "--dry-run":
            cfg.dry_run = True
        elif arg == "--fail-any":
            cfg.fail_any = True
        elif arg == "--fail-none":
            cfg.fail_none = True
        elif arg == "--sorted":
            cfg.sorted = True
        elif arg == "--files":
            cfg.files = True
        elif arg == "--files-with-matches":
            cfg.files_with_matches = True
        elif arg == "--only-matching":
            cfg.only_matching = True
        elif arg == "--line-numbers":
            cfg.line_numbers = True
        elif arg in ("--upper",):
            cfg.upper = True
            cfg.action_order.append("upper")
        elif arg in ("--lower",):
            cfg.lower = True
            cfg.action_order.append("lower")
        elif arg in ("--titlecase",):
            cfg.titlecase = True
            cfg.action_order.append("titlecase")
        elif arg in ("--normalize",):
            cfg.normalize = True
            cfg.action_order.append("normalize")
        elif arg in ("--german",):
            cfg.german = True
            cfg.action_order.append("german")
        elif arg in ("--symbols",):
            cfg.symbols = True
            cfg.action_order.append("symbols")
        elif arg in ("--delete",):
            cfg.delete = True
        elif arg in ("--squeeze", "--squeeze-repeats"):
            cfg.squeeze = True
        elif arg in ("--invert",):
            cfg.invert = True
        elif arg in ("--literal-string",):
            cfg.literal = True
        elif arg.startswith("--"):
            return die(f"error: unexpected argument '{arg}' found", 2)
        elif arg.startswith("-") and arg != "-":
            for ch in arg[1:]:
                if ch == "u":
                    cfg.upper = True
                    cfg.action_order.append("upper")
                elif ch == "l":
                    cfg.lower = True
                    cfg.action_order.append("lower")
                elif ch == "t":
                    cfg.titlecase = True
                    cfg.action_order.append("titlecase")
                elif ch == "n":
                    cfg.normalize = True
                    cfg.action_order.append("normalize")
                elif ch == "g":
                    cfg.german = True
                    cfg.action_order.append("german")
                elif ch == "S":
                    cfg.symbols = True
                    cfg.action_order.append("symbols")
                elif ch == "d":
                    cfg.delete = True
                elif ch == "s":
                    cfg.squeeze = True
                elif ch == "i":
                    cfg.invert = True
                elif ch == "L":
                    cfg.literal = True
                elif ch == "H" or ch == "v" or ch == "j":
                    pass
                else:
                    return die(f"error: unexpected argument '-{ch}' found", 2)
        else:
            positionals.append(arg)
        i += 1
    if positionals:
        cfg.scope = positionals[0]
        cfg.scope_given = True
    if len(positionals) > 1 and cfg.replacement is None:
        cfg.replacement = positionals[1]
    if (cfg.delete or cfg.squeeze or cfg.literal) and not cfg.scope_given:
        return die("error: the following required arguments were not provided:\n  <SCOPE>", 2)
    return cfg


SYMBOLS = [
    ("=>", "⇒"), ("->", "→"), ("<-", "←"), ("<=", "≤"), (">=", "≥"),
    ("!=", "≠"),
]


def apply_symbols(text: str, invert: bool) -> str:
    pairs = [(b, a) for a, b in SYMBOLS]
    if not invert:
        pairs = SYMBOLS
    for a, b in pairs:
        text = text.replace(a, b)
    return text


def apply_german(text: str) -> str:
    protected: dict[str, str] = {}
    for word in ("Koeffizient", "Koeffizienten", "Koeffiziente"):
        token = f"\0{len(protected)}\0"
        protected[token] = word
        text = text.replace(word, token)
    pairs = [
        ("Ae", "Ä"), ("Oe", "Ö"), ("Ue", "Ü"), ("ae", "ä"), ("oe", "ö"),
        ("ue", "ü"), ("ss", "ß"),
    ]
    for a, b in pairs:
        text = text.replace(a, b)
    for token, word in protected.items():
        text = text.replace(token, word)
    return text


def strip_marks(text: str) -> str:
    return "".join(
        ch for ch in unicodedata.normalize("NFD", text)
        if unicodedata.category(ch) != "Mn"
    )


def expand_replacement(template: str, match: re.Match[str]) -> str:
    def repl(m: re.Match[str]) -> str:
        key = m.group(1) or m.group(2)
        try:
            if key.isdigit():
                return match.group(int(key)) or ""
            return match.group(key) or ""
        except (IndexError, KeyError):
            return ""
    return re.sub(r"\$(\d+)|\$([A-Za-z_][A-Za-z0-9_]*)", repl, template)


def compile_scope(cfg: Config) -> re.Pattern[str]:
    pattern = re.escape(cfg.scope) if cfg.literal else cfg.scope
    return re.compile(pattern, re.MULTILINE)


def transform_piece(piece: str, cfg: Config, match: re.Match[str] | None = None) -> str:
    if cfg.replacement is not None:
        piece = expand_replacement(cfg.replacement, match) if match else cfg.replacement
    order = cfg.action_order or [
        name for name, enabled in [
            ("upper", cfg.upper), ("lower", cfg.lower), ("titlecase", cfg.titlecase),
            ("normalize", cfg.normalize), ("german", cfg.german), ("symbols", cfg.symbols),
        ] if enabled
    ]
    for action in order:
        if action == "upper":
            piece = piece.upper()
        elif action == "lower":
            piece = piece.lower()
        elif action == "titlecase":
            piece = piece.title()
        elif action == "normalize":
            piece = strip_marks(piece)
        elif action == "german":
            piece = apply_german(piece)
        elif action == "symbols":
            piece = apply_symbols(piece, cfg.invert)
    return piece


def has_action(cfg: Config) -> bool:
    return any([
        cfg.replacement is not None, cfg.upper, cfg.lower, cfg.titlecase,
        cfg.normalize, cfg.german, cfg.symbols, cfg.delete, cfg.squeeze,
    ])


def apply_transform(text: str, cfg: Config) -> tuple[str, bool]:
    regex = compile_scope(cfg)
    found = bool(regex.search(text))
    if cfg.delete:
        return regex.sub("", text), found
    if cfg.squeeze:
        pattern = re.escape(cfg.scope) if cfg.literal else cfg.scope
        run_regex = re.compile(f"(?:{pattern})+", re.MULTILINE)
        return run_regex.sub(lambda m: regex.match(m.group(0)).group(0), text), found
    if not has_action(cfg):
        return text, found
    if not cfg.scope_given and cfg.scope == ".*":
        return transform_piece(text, cfg), bool(text)
    return regex.sub(lambda m: transform_piece(m.group(0), cfg, m), text), found


def line_offsets(text: str) -> list[int]:
    offsets = []
    pos = 0
    for line in text.splitlines(True):
        offsets.append(pos)
        pos += len(line)
    if not offsets:
        offsets.append(0)
    return offsets


def line_for_pos(offsets: list[int], pos: int) -> int:
    lo = 0
    for i, off in enumerate(offsets):
        if off <= pos:
            lo = i
        else:
            break
    return lo


def indentation(line: str) -> int:
    return len(line) - len(line.lstrip(" "))


def block_ranges_by_indent(text: str, header_re: str) -> list[tuple[int, int]]:
    lines = text.splitlines(True)
    ranges = []
    pos = 0
    starts = []
    for idx, line in enumerate(lines):
        if re.match(header_re, line):
            starts.append((idx, pos, indentation(line)))
        pos += len(line)
    starts_set = {idx for idx, _, _ in starts}
    for idx, start, indent in starts:
        end = len(text)
        p = sum(len(x) for x in lines[:idx + 1])
        for j in range(idx + 1, len(lines)):
            stripped = lines[j].strip()
            if stripped and indentation(lines[j]) <= indent and j not in starts_set:
                end = p
                break
            p += len(lines[j])
        ranges.append((start, end))
    return ranges


def regex_ranges(text: str, pattern: str, flags: int = re.MULTILINE) -> list[tuple[int, int]]:
    return [(m.start(), m.end()) for m in re.finditer(pattern, text, flags)]


def language_ranges(lang: str, scope: str, text: str) -> list[tuple[int, int]]:
    base = scope.split("~", 1)[0]
    if lang == "python":
        if base == "class":
            return block_ranges_by_indent(text, r"^\s*class\s+\w+")
        if base in ("def", "methods", "async-def"):
            return block_ranges_by_indent(text, r"^\s*(async\s+def|def)\s+\w+")
        if base == "comments":
            return regex_ranges(text, r"#[^\n]*")
        if base in ("strings", "doc-strings"):
            return regex_ranges(text, r"(?s)(\"\"\".*?\"\"\"|'''.*?'''|\"(?:\\.|[^\"])*\"|'(?:\\.|[^'])*')")
        if base == "imports":
            return regex_ranges(text, r"(?m)^\s*(?:from\s+[\w.]+|import\s+[\w., ]+)")
        if base == "function-names":
            return regex_ranges(text, r"(?m)(?<=def\s)[A-Za-z_][A-Za-z0-9_]*")
        if base == "function-calls":
            return regex_ranges(text, r"\b[A-Za-z_][A-Za-z0-9_]*(?=\s*\()")
        if base in ("identifiers", "variable-identifiers", "types", "globals"):
            return regex_ranges(text, r"\b[A-Za-z_][A-Za-z0-9_]*\b")
    comment_pat = r"//[^\n]*|/\*.*?\*/|#[^\n]*"
    string_pat = r'(?s)"(?:\\.|[^"])*"|`[^`]*`|\'(?:\\.|[^\'])*\''
    if base in ("comments", "doc-comments"):
        return regex_ranges(text, comment_pat, re.MULTILINE | re.DOTALL)
    if base in ("strings", "struct-tags"):
        return regex_ranges(text, string_pat, re.MULTILINE | re.DOTALL)
    if base in ("imports", "uses", "includes", "usings"):
        return regex_ranges(text, r"(?m)^\s*(?:use|import|from|#include|using)\b[^\n;]*;?")
    if base in ("class", "struct", "enum", "interface", "trait", "impl", "mod", "namespace", "function", "func", "fn", "method", "def", "free-func", "function-def", "function-decl"):
        words = {
            "class": "class", "struct": "struct", "enum": "enum", "interface": "interface",
            "trait": "trait", "impl": "impl", "mod": "mod", "namespace": "namespace",
            "func": "func", "fn": "fn", "function": "function", "method": "func|function|fn",
            "free-func": "func", "function-def": r"\w+\s+\w+\s*\(", "function-decl": r"\w+\s+\w+\s*\(",
        }
        word = words.get(base, base)
        return regex_ranges(text, rf"(?ms)\b(?:{word})\b.*?(?=^\S|\Z)")
    if base in ("identifier", "identifiers", "type-identifier"):
        return regex_ranges(text, r"\b[A-Za-z_][A-Za-z0-9_]*\b")
    return [(0, len(text))]


def merge_ranges(ranges: list[tuple[int, int]]) -> list[tuple[int, int]]:
    if not ranges:
        return []
    ranges = sorted(ranges)
    merged = [ranges[0]]
    for start, end in ranges[1:]:
        ls, le = merged[-1]
        if start <= le:
            merged[-1] = (ls, max(le, end))
        else:
            merged.append((start, end))
    return merged


def scoped_search(text: str, cfg: Config, name: str = "(stdin)") -> tuple[str, bool]:
    regex = compile_scope(cfg)
    ranges = merge_ranges([r for lang, sc in cfg.language_scopes for r in language_ranges(lang, sc, text)])
    offsets = line_offsets(text)
    out = []
    found = False
    for start, end in ranges:
        for match in regex.finditer(text, start, end):
            if match.start() == match.end():
                continue
            line_idx = line_for_pos(offsets, match.start())
            line_start = offsets[line_idx]
            line = text.splitlines()[line_idx] if text.splitlines() else ""
            a = match.start() - line_start
            b = match.end() - line_start
            if cfg.only_matching:
                out.append(match.group(0))
            else:
                prefix = f"{name}:"
                if cfg.line_numbers or cfg.language_scopes:
                    prefix += f"{line_idx + 1}:"
                prefix += f"{a}-{b}:"
                out.append(prefix + line)
            found = True
    return ("\n".join(out) + ("\n" if out else "")), found


def regex_search(text: str, cfg: Config, name: str = "(stdin)") -> tuple[str, bool]:
    regex = compile_scope(cfg)
    out = []
    found = False
    for line_no, line in enumerate(text.splitlines(), start=1):
        matches = [m for m in regex.finditer(line) if m.start() != m.end()]
        if not matches:
            continue
        ranges = ";".join(f"{m.start()}-{m.end()}" for m in matches)
        prefix = f"{name}:"
        if cfg.line_numbers:
            prefix += f"{line_no}:"
        out.append(f"{prefix}{ranges}:{line}")
        found = True
    return ("\n".join(out) + ("\n" if out else "")), found


def discover_files(cfg: Config) -> list[str]:
    if cfg.glob_pattern:
        files = [p for p in glob.glob(cfg.glob_pattern, recursive=True) if os.path.isfile(p)]
    else:
        exts = ("*.py", "*.rs", "*.go", "*.ts", "*.tsx", "*.c", "*.h", "*.cs", "*.tf", "*.hcl")
        files = []
        for root, dirs, names in os.walk("."):
            dirs[:] = [d for d in dirs if d != ".git" and (not d.startswith(".") or False)]
            for name in names:
                if any(fnmatch.fnmatch(name, ext) for ext in exts):
                    files.append(os.path.join(root, name).removeprefix("./"))
    return sorted(files) if cfg.sorted else files


def process_text(text: str, cfg: Config, name: str = "(stdin)") -> tuple[str, bool]:
    if cfg.language_scopes and not has_action(cfg):
        return scoped_search(text, cfg, name)
    if not has_action(cfg) and (cfg.only_matching or cfg.line_numbers):
        return regex_search(text, cfg, name)
    output, found = apply_transform(text, cfg)
    return output, found


def main(argv: list[str]) -> int:
    parsed = parse(argv)
    if isinstance(parsed, int):
        return parsed
    cfg = parsed
    if cfg.glob_pattern or cfg.files or cfg.files_with_matches or (
        cfg.stdin_detection == "force-unreadable" and not sys.stdin.isatty()
    ):
        files = discover_files(cfg)
        if not files:
            if cfg.fail_no_files:
                return die("Error: No files found", 1)
            return 0
        any_found = False
        for path in files:
            text = open(path, encoding="utf-8").read()
            if cfg.files:
                print(path)
                continue
            out, found = process_text(text, cfg, path)
            any_found = any_found or found
            if cfg.files_with_matches:
                if found:
                    print(path)
                continue
            if has_action(cfg):
                if out != text and not cfg.dry_run:
                    open(path, "w", encoding="utf-8").write(out)
                print(path)
            elif out:
                sys.stdout.write(out)
        if cfg.fail_any and any_found:
            return die("Error: Error applying: Some input was in scope", 1)
        if cfg.fail_none and not any_found:
            return die("Error: Error applying: No input was in scope", 1)
        return 0
    text = sys.stdin.read()
    out, found = process_text(text, cfg)
    if cfg.fail_any and found:
        return die("Error: Error applying: Some input was in scope", 1)
    if cfg.fail_none and not found:
        return die("Error: Error applying: No input was in scope", 1)
    if not has_action(cfg) and not cfg.language_scopes:
        sys.stderr.write("[2026-06-04T00:00:00Z ERROR srgn] No actions specified, and not in search mode. Will return input unchanged, if any.\n")
    sys.stdout.write(out)
    return 0


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
