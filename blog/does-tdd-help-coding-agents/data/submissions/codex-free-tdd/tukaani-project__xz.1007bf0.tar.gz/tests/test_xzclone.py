import subprocess
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
PROG = ["python3", str(ROOT / "src" / "xzclone.py")]
REF = str(ROOT / "executable")


def run(cmd, cwd=None, data=None):
    return subprocess.run(cmd, cwd=cwd, input=data, stdout=subprocess.PIPE, stderr=subprocess.PIPE)


class XzCloneTests(unittest.TestCase):
    def test_help_matches_key_lines(self):
        p = run(PROG + ["--help"])
        self.assertEqual(p.returncode, 0)
        text = p.stdout.decode()
        self.assertIn("Usage:", text)
        self.assertIn("Compress or decompress FILEs in the .xz format.", text)
        self.assertIn("--decompress", text)
        self.assertEqual(p.stderr, b"")

    def test_stdout_roundtrip_can_be_read_by_reference(self):
        data = (b"hello world\n" * 1000) + bytes(range(256))
        ours = run(PROG + ["-c"], data=data)
        self.assertEqual(ours.returncode, 0, ours.stderr)
        ref = run([REF, "-dc"], data=ours.stdout)
        self.assertEqual(ref.returncode, 0, ref.stderr)
        self.assertEqual(ref.stdout, data)

    def test_stored_reference_xz_can_be_decompressed_to_stdout(self):
        data = b"hello"
        ref_xz = run([REF, "--check=none", "-0", "-c"], data=data)
        self.assertEqual(ref_xz.returncode, 0, ref_xz.stderr)
        ours = run(PROG + ["-dc"], data=ref_xz.stdout)
        self.assertEqual(ours.returncode, 0, ours.stderr)
        self.assertEqual(ours.stdout, data)

    def test_file_compress_and_decompress_delete_inputs_by_default(self):
        with tempfile.TemporaryDirectory() as td:
            path = Path(td) / "sample.txt"
            path.write_bytes(b"file payload" * 50)
            p = run(PROG + [str(path)])
            self.assertEqual(p.returncode, 0, p.stderr)
            xz = Path(str(path) + ".xz")
            self.assertTrue(xz.exists())
            self.assertFalse(path.exists())
            p = run(PROG + ["-d", str(xz)])
            self.assertEqual(p.returncode, 0, p.stderr)
            self.assertEqual(path.read_bytes(), b"file payload" * 50)
            self.assertFalse(xz.exists())

    def test_keep_preserves_input_and_force_overwrites_output(self):
        with tempfile.TemporaryDirectory() as td:
            path = Path(td) / "a.txt"
            path.write_bytes(b"abc")
            self.assertEqual(run(PROG + ["-k", str(path)]).returncode, 0)
            path.write_bytes(b"def")
            p = run(PROG + ["-k", str(path)])
            self.assertNotEqual(p.returncode, 0)
            self.assertIn(b"File exists", p.stderr)
            p = run(PROG + ["-kf", str(path)])
            self.assertEqual(p.returncode, 0, p.stderr)
            out = run(PROG + ["-dc", str(path) + ".xz"])
            self.assertEqual(out.stdout, b"def")

    def test_test_mode_validates_without_output(self):
        data = b"check me" * 20
        xz = run(PROG + ["-c"], data=data).stdout
        p = run(PROG + ["-t"], data=xz)
        self.assertEqual(p.returncode, 0, p.stderr)
        self.assertEqual(p.stdout, b"")


if __name__ == "__main__":
    unittest.main()

class XzCloneUnsupportedTests(unittest.TestCase):
    def test_regular_reference_compressed_stream_reports_unsupported(self):
        ref_xz = run([REF, "-c"], data=b"alpha beta gamma\n" * 200)
        self.assertEqual(ref_xz.returncode, 0, ref_xz.stderr)
        ours = run(PROG + ["-dc"], data=ref_xz.stdout)
        self.assertNotEqual(ours.returncode, 0)
        self.assertIn(b"Compressed LZMA2 chunks", ours.stderr)

