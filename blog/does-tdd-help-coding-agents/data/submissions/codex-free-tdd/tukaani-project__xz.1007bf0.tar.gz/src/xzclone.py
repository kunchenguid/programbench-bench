#!/usr/bin/env python3
import os
import struct
import sys
import zlib
from pathlib import Path

MAGIC = b"\xfd7zXZ\x00"
FOOTER_MAGIC = b"YZ"
PROG = "xz"

HELP = """Usage: ./executable [OPTION]... [FILE]...
Compress or decompress FILEs in the .xz format.

Mandatory arguments to long options are mandatory for short options too.

  -z, --compress      force compression
  -d, --decompress    force decompression
  -t, --test          test compressed file integrity
  -l, --list          list information about .xz files
  -k, --keep          keep (don't delete) input files
  -f, --force         force overwrite of output file and (de)compress links
  -c, --stdout        write to standard output and don't delete input files
  -0 ... -9           compression preset; default is 6; take compressor *and*
                      decompressor memory usage into account before using 7-9!
  -e, --extreme       try to improve compression ratio by using more CPU time;
                      does not affect decompressor memory requirements
  -T, --threads=NUM   use at most NUM threads; the default is 0 which uses as
                      many threads as there are processor cores
  -q, --quiet         suppress warnings; specify twice to suppress errors too
  -v, --verbose       be verbose; specify twice for even more verbose
  -h, --help          display this short help and exit
  -H, --long-help     display the long help (lists also the advanced options)
  -V, --version       display the version number and exit

With no FILE, or when FILE is -, read standard input.

Report bugs to <xz@tukaani.org> (in English or Finnish).
XZ Utils home page: <https://tukaani.org/xz/>
"""

LONG_HELP = HELP.replace("display this short help", "display the short help")
VERSION = "xz (XZ Utils) 5.8.2\nliblzma 5.8.2\n"


def crc32(data):
    return zlib.crc32(data) & 0xFFFFFFFF


def vli(n):
    if n < 0:
        raise ValueError("negative VLI")
    out = bytearray()
    while True:
        b = n & 0x7F
        n >>= 7
        if n:
            out.append(b | 0x80)
        else:
            out.append(b)
            return bytes(out)


def read_vli(buf, pos):
    shift = 0
    val = 0
    for _ in range(9):
        if pos >= len(buf):
            raise ValueError("truncated VLI")
        b = buf[pos]
        pos += 1
        val |= (b & 0x7F) << shift
        if not (b & 0x80):
            return val, pos
        shift += 7
    raise ValueError("VLI too long")


def pad4(data):
    return data + b"\x00" * ((4 - len(data) % 4) % 4)


def stream_header(flags=b"\x00\x00"):
    return MAGIC + flags + struct.pack("<I", crc32(flags))


def stream_footer(index_len, flags=b"\x00\x00"):
    body = struct.pack("<I", index_len // 4 - 1) + flags
    return struct.pack("<I", crc32(body)) + body + FOOTER_MAGIC


def lzma2_uncompressed(data):
    out = bytearray()
    first = True
    pos = 0
    while pos < len(data):
        chunk = data[pos:pos + 65536]
        pos += len(chunk)
        out.append(0x01 if first else 0x02)
        first = False
        out += struct.pack(">H", len(chunk) - 1)
        out += chunk
    out.append(0x00)
    return bytes(out)


def make_block(data):
    payload = lzma2_uncompressed(data)
    body = bytearray()
    body.append(0xC0)  # one filter, compressed and uncompressed sizes present
    body += vli(len(payload))
    body += vli(len(data))
    body += vli(0x21)  # LZMA2
    body += vli(1)
    body.append(0x0C)  # 4 MiB dictionary property, valid for stored chunks
    header_size = 1 + len(body) + 4
    total_header = ((header_size + 3) // 4) * 4
    header = bytes([total_header // 4 - 1]) + bytes(body)
    header = header + b"\x00" * (total_header - 4 - len(header))
    header += struct.pack("<I", crc32(header))
    return header + pad4(payload), len(header) + len(payload), len(data)


def make_index(unpadded, uncomp):
    body = b"\x00" + vli(1) + vli(unpadded) + vli(uncomp)
    body = pad4(body)
    return body + struct.pack("<I", crc32(body))


def compress_xz(data):
    block, unpadded, uncomp = make_block(data)
    index = make_index(unpadded, uncomp)
    return stream_header() + block + index + stream_footer(len(index))


def parse_lzma2_stored(payload):
    out = bytearray()
    pos = 0
    while True:
        if pos >= len(payload):
            raise ValueError("Unexpected end of input")
        control = payload[pos]
        pos += 1
        if control == 0x00:
            return bytes(out), pos
        if control not in (0x01, 0x02):
            raise ValueError("Compressed LZMA2 chunks are not supported by this reimplementation")
        if pos + 2 > len(payload):
            raise ValueError("Unexpected end of input")
        size = struct.unpack(">H", payload[pos:pos + 2])[0] + 1
        pos += 2
        if pos + size > len(payload):
            raise ValueError("Unexpected end of input")
        out += payload[pos:pos + size]
        pos += size


def decompress_xz(data):
    if not data.startswith(MAGIC) or len(data) < 24:
        raise ValueError("File format not recognized")
    flags = data[6:8]
    if data[8:12] != struct.pack("<I", crc32(flags)):
        raise ValueError("Corrupt input data")
    check_type = flags[1] & 0x0F
    check_sizes = {0: 0, 1: 4, 4: 8, 10: 32}
    check_size = check_sizes.get(check_type)
    if check_size is None:
        raise ValueError("Unsupported integrity check")
    pos = 12
    result = bytearray()
    while pos < len(data):
        if data[pos] == 0x00:
            break
        hsize = (data[pos] + 1) * 4
        header = data[pos:pos + hsize]
        if len(header) != hsize or struct.pack("<I", crc32(header[:-4])) != header[-4:]:
            raise ValueError("Corrupt input data")
        p = 1
        flags_b = header[p]
        p += 1
        has_comp = bool(flags_b & 0x40)
        has_uncomp = bool(flags_b & 0x80)
        filters = (flags_b & 0x03) + 1
        if filters != 1:
            raise ValueError("Unsupported filter chain")
        comp_size = None
        uncomp_size = None
        if has_comp:
            comp_size, p = read_vli(header, p)
        if has_uncomp:
            uncomp_size, p = read_vli(header, p)
        fid, p = read_vli(header, p)
        props_len, p = read_vli(header, p)
        props = header[p:p + props_len]
        if fid != 0x21 or props_len != 1:
            raise ValueError("Unsupported filter chain")
        pos += hsize
        if comp_size is None:
            # Only needed for streams made by this clone; scan to LZMA2 end marker.
            scan = pos
            while scan < len(data) and data[scan] != 0x00:
                c = data[scan]
                if c not in (1, 2):
                    raise ValueError("Compressed LZMA2 chunks are not supported by this reimplementation")
                if scan + 3 > len(data):
                    raise ValueError("Unexpected end of input")
                sz = struct.unpack(">H", data[scan + 1:scan + 3])[0] + 1
                scan += 3 + sz
            comp_size = scan - pos + 1
        payload = data[pos:pos + comp_size]
        block_out, used = parse_lzma2_stored(payload)
        if used > len(payload):
            raise ValueError("Corrupt input data")
        if uncomp_size is not None and len(block_out) != uncomp_size:
            raise ValueError("Corrupt input data")
        result += block_out
        pos += comp_size
        while pos % 4:
            if pos >= len(data) or data[pos] != 0:
                raise ValueError("Corrupt input data")
            pos += 1
        pos += check_size
    return bytes(result)


class Options:
    def __init__(self):
        self.mode = "compress"
        self.keep = False
        self.force = False
        self.stdout = False
        self.suffix = ".xz"
        self.files = []
        self.quiet = 0
        self.listing = False


def parse_args(argv):
    opt = Options()
    i = 0
    while i < len(argv):
        a = argv[i]
        if a == "--":
            opt.files.extend(argv[i + 1:])
            break
        if a in ("-h", "--help"):
            sys.stdout.write(HELP)
            raise SystemExit(0)
        if a in ("-H", "--long-help"):
            sys.stdout.write(LONG_HELP)
            raise SystemExit(0)
        if a in ("-V", "--version"):
            sys.stdout.write(VERSION)
            raise SystemExit(0)
        if a.startswith("--suffix="):
            opt.suffix = a.split("=", 1)[1]
        elif a == "-S":
            i += 1; opt.suffix = argv[i]
        elif a.startswith("--threads") or a.startswith("-T") or a.startswith("--memlimit") or a.startswith("-M"):
            if a in ("-T", "-M", "--threads", "--memlimit"):
                i += 1
        elif a in ("--compress",):
            opt.mode = "compress"
        elif a in ("--decompress", "--uncompress"):
            opt.mode = "decompress"
        elif a == "--test":
            opt.mode = "test"
        elif a == "--list":
            opt.mode = "list"; opt.listing = True
        elif a in ("--keep",):
            opt.keep = True
        elif a in ("--force",):
            opt.force = True
        elif a in ("--stdout", "--to-stdout"):
            opt.stdout = True; opt.keep = True
        elif a in ("--quiet",):
            opt.quiet += 1
        elif a in ("--verbose", "--extreme", "--no-sync", "--no-sparse", "--single-stream", "--robot", "--no-warn", "--ignore-check"):
            pass
        elif a.startswith("--format") or a.startswith("--check") or a.startswith("--block") or a.startswith("--flush") or a.startswith("--filters") or a.startswith("--lzma") or a.startswith("--x86") or a.startswith("--arm") or a.startswith("--power") or a.startswith("--sparc") or a.startswith("--riscv") or a.startswith("--delta"):
            if "=" not in a and a in ("--format", "--check", "--block-size", "--block-list", "--flush-timeout", "--filters"):
                i += 1
        elif a.startswith("-") and len(a) > 1:
            for ch in a[1:]:
                if ch == "z": opt.mode = "compress"
                elif ch == "d": opt.mode = "decompress"
                elif ch == "t": opt.mode = "test"
                elif ch == "l": opt.mode = "list"; opt.listing = True
                elif ch == "k": opt.keep = True
                elif ch == "f": opt.force = True
                elif ch == "c": opt.stdout = True; opt.keep = True
                elif ch == "q": opt.quiet += 1
                elif ch in "ve0123456789": pass
                else:
                    raise ValueError(f"Unsupported option: -{ch}")
        else:
            opt.files.append(a)
        i += 1
    return opt


def err(msg):
    sys.stderr.write(f"./executable: {msg}\n")


def read_input(name):
    if name == "-":
        return sys.stdin.buffer.read()
    return Path(name).read_bytes()


def write_output(path, data, force):
    p = Path(path)
    if p.exists() and not force:
        raise FileExistsError(str(path))
    p.write_bytes(data)


def out_name_for_decompress(name, suffix):
    if suffix and name.endswith(suffix):
        return name[:-len(suffix)]
    if name.endswith(".txz"):
        return name[:-4] + ".tar"
    if name.endswith(".xz"):
        return name[:-3]
    raise ValueError(f"{name}: Filename has an unknown suffix, skipping")


def process(opt, name):
    data = read_input(name)
    if opt.mode == "compress":
        out = compress_xz(data)
        if opt.stdout or name == "-":
            sys.stdout.buffer.write(out)
        else:
            dest = name + opt.suffix
            write_output(dest, out, opt.force)
            if not opt.keep:
                Path(name).unlink()
    elif opt.mode in ("decompress", "test"):
        out = decompress_xz(data)
        if opt.mode == "decompress":
            if opt.stdout or name == "-":
                sys.stdout.buffer.write(out)
            else:
                dest = out_name_for_decompress(name, opt.suffix)
                write_output(dest, out, opt.force)
                if not opt.keep:
                    Path(name).unlink()
    elif opt.mode == "list":
        out = decompress_xz(data)
        sys.stdout.write("Strms  Blocks   Compressed Uncompressed  Ratio  Check   Filename\n")
        sys.stdout.write(f"    1       1 {len(data):12} {len(out):12}  1.000  None    {name}\n")


def main(argv):
    try:
        opt = parse_args(argv)
        files = opt.files or ["-"]
        status = 0
        for name in files:
            try:
                process(opt, name)
            except FileExistsError as e:
                err(f"{e.filename}: File exists")
                status = 1
            except Exception as e:
                if opt.quiet < 2:
                    err(str(e))
                status = 1
        return status
    except BrokenPipeError:
        return 1
    except ValueError as e:
        err(str(e))
        return 1


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
