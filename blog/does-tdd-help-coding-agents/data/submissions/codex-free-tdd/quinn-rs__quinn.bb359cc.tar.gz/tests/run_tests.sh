#!/bin/bash
set -euo pipefail

ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"

fail() {
  echo "FAIL: $*" >&2
  exit 1
}

assert_status() {
  local expected="$1"
  local actual="$2"
  local label="$3"
  [[ "$actual" == "$expected" ]] || fail "$label: expected status $expected, got $actual"
}

assert_contains() {
  local file="$1"
  local needle="$2"
  local label="$3"
  grep -Fq -- "$needle" "$file" || {
    echo "--- $label output ---" >&2
    cat "$file" >&2
    fail "$label: missing '$needle'"
  }
}

assert_not_contains() {
  local file="$1"
  local needle="$2"
  local label="$3"
  if grep -Fq -- "$needle" "$file"; then
    echo "--- $label output ---" >&2
    cat "$file" >&2
    fail "$label: unexpectedly contained '$needle'"
  fi
}

run_capture() {
  local outfile="$1"
  shift
  set +e
  "$@" >"$outfile" 2>&1
  RUN_STATUS=$?
  set -e
}

./compile.sh

tmp="$(mktemp -d)"
trap 'rm -rf "$tmp"; kill ${server_pid:-} 2>/dev/null || true' EXIT

run_capture "$tmp/top_help" ./executable --help; st=$RUN_STATUS
assert_status 0 "$st" "top help"
assert_contains "$tmp/top_help" "Usage: executable <COMMAND>" "top help"
assert_contains "$tmp/top_help" "server  Run as a perf server" "top help"
assert_contains "$tmp/top_help" "-h, --help  Print help" "top help"

run_capture "$tmp/no_args" ./executable; st=$RUN_STATUS
assert_status 2 "$st" "no args"
assert_contains "$tmp/no_args" "Usage: executable <COMMAND>" "no args"

run_capture "$tmp/client_short" ./executable client -h; st=$RUN_STATUS
assert_status 0 "$st" "client short help"
assert_contains "$tmp/client_short" "Usage: executable client [OPTIONS] [HOST]" "client short help"
assert_contains "$tmp/client_short" "[HOST]  Host to connect to [default: localhost:4433]" "client short help"
assert_contains "$tmp/client_short" "Print help (see more with '--help')" "client short help"
assert_not_contains "$tmp/client_short" "This can use SI suffixes" "client short help"

run_capture "$tmp/server_long" ./executable server --help; st=$RUN_STATUS
assert_status 0 "$st" "server long help"
assert_contains "$tmp/server_long" "Run as a perf server" "server long help"
assert_contains "$tmp/server_long" "This can use SI suffixes for sizes. For example, 1M will request 1MiB, 10G will request 10GiB." "server long help"

run_capture "$tmp/bad_cmd" ./executable bogus; st=$RUN_STATUS
assert_status 2 "$st" "bad command"
assert_contains "$tmp/bad_cmd" "error: unrecognized subcommand 'bogus'" "bad command"

run_capture "$tmp/bad_cong" ./executable client --congestion foo; st=$RUN_STATUS
assert_status 2 "$st" "bad congestion"
assert_contains "$tmp/bad_cong" "error: invalid value 'foo' for '--congestion <CONG_ALG>'" "bad congestion"
assert_contains "$tmp/bad_cong" "[possible values: cubic, bbr, new-reno]" "bad congestion"

run_capture "$tmp/bad_size" ./executable client --download-size 1m; st=$RUN_STATUS
assert_status 2 "$st" "bad lowercase size"
assert_contains "$tmp/bad_size" "invalid value '1m' for '--download-size <DOWNLOAD_SIZE>': invalid digit found in string" "bad lowercase size"

run_capture "$tmp/missing" ./executable server --listen; st=$RUN_STATUS
assert_status 2 "$st" "missing listen value"
assert_contains "$tmp/missing" "a value is required for '--listen <LISTEN>' but none was supplied" "missing listen value"

port=46789
timeout 8 ./executable server --listen "127.0.0.1:$port" --no-protection >"$tmp/server.log" 2>&1 &
server_pid=$!
sleep 0.3
run_capture "$tmp/client.log" ./executable client --no-protection --duration 1 --interval 1 --download-size 10 --upload-size 5 --json "$tmp/out.json" "127.0.0.1:$port"; st=$RUN_STATUS
assert_status 0 "$st" "client/server"
assert_contains "$tmp/client.log" "Overall stats:" "client/server"
assert_contains "$tmp/client.log" "RPS:" "client/server"
assert_contains "$tmp/client.log" "Stream metrics:" "client/server"
assert_contains "$tmp/out.json" "\"start\"" "json output"
assert_contains "$tmp/out.json" "\"intervals\"" "json output"
assert_contains "$tmp/out.json" "\"bytes\":5" "json output"
assert_contains "$tmp/out.json" "\"bytes\":10" "json output"
kill "$server_pid" 2>/dev/null || true
wait "$server_pid" 2>/dev/null || true
server_pid=

run_capture "$tmp/json_stdout" ./executable client --duration 0 --json - --download-size 1 --upload-size 2 127.0.0.1:9; st=$RUN_STATUS
assert_status 0 "$st" "json stdout offline"
assert_contains "$tmp/json_stdout" "\"intervals\"" "json stdout offline"

echo "all tests passed"
