#define _POSIX_C_SOURCE 200809L
#include <arpa/inet.h>
#include <errno.h>
#include <netdb.h>
#include <signal.h>
#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/socket.h>
#include <sys/stat.h>
#include <sys/time.h>
#include <sys/types.h>
#include <time.h>
#include <unistd.h>

typedef struct {
    long long duration;
    long long interval;
    long long download_size;
    long long upload_size;
    long long uni_requests;
    long long bi_requests;
    char host[256];
    char ip[128];
    char local_addr[128];
    char json[256];
    bool json_set;
    bool no_protection;
    bool conn_stats;
    bool keylog;
    char qlog[256];
    bool qlog_set;
} ClientOptions;

typedef struct {
    char listen[256];
    bool no_protection;
    bool conn_stats;
    bool keylog;
    char qlog[256];
    bool qlog_set;
} ServerOptions;

static double now_seconds(void) {
    struct timeval tv;
    gettimeofday(&tv, NULL);
    return (double)tv.tv_sec + (double)tv.tv_usec / 1000000.0;
}

static void print_top_help(FILE *out) {
    fprintf(out,
            "Usage: executable <COMMAND>\n\n"
            "Commands:\n"
            "  server  Run as a perf server\n"
            "  client  Run as a perf client\n"
            "  help    Print this message or the help of the given subcommand(s)\n\n"
            "Options:\n"
            "  -h, --help  Print help\n");
}

static void print_server_help(FILE *out, bool long_help) {
    if (long_help) {
        fprintf(out,
                "Run as a perf server\n\n"
                "Usage: executable server [OPTIONS]\n\n"
                "Options:\n"
                "      --listen <LISTEN>\n"
                "          Address to listen on\n"
                "          \n"
                "          [default: [::]:4433]\n\n"
                "  -k, --key <KEY>\n"
                "          TLS private key in DER format\n\n"
                "  -c, --cert <CERT>\n"
                "          TLS certificate in PEM format\n\n"
                "      --send-buffer-size <SEND_BUFFER_SIZE>\n"
                "          Send buffer size in bytes\n"
                "          \n"
                "          This can use SI suffixes for sizes. For example, 1M will request 1MiB, 10G will request 10GiB.\n"
                "          \n"
                "          [default: 2M]\n\n"
                "      --recv-buffer-size <RECV_BUFFER_SIZE>\n"
                "          Receive buffer size in bytes\n"
                "          \n"
                "          This can use SI suffixes for sizes. For example, 1M will request 1MiB, 10G will request 10GiB.\n"
                "          \n"
                "          [default: 2M]\n\n"
                "      --conn-stats\n"
                "          Whether to print connection statistics\n\n"
                "      --keylog\n"
                "          Perform NSS-compatible TLS key logging to the file specified in `SSLKEYLOGFILE`\n\n"
                "      --initial-mtu <INITIAL_MTU>\n"
                "          UDP payload size that the network must be capable of carrying\n"
                "          \n"
                "          [default: 1200]\n\n"
                "      --no-protection\n"
                "          Disable packet encryption/decryption (for debugging purpose)\n\n"
                "      --initial-rtt <INITIAL_RTT>\n"
                "          The initial round-trip-time (in msecs)\n\n"
                "      --ack-frequency\n"
                "          Ack Frequency mode\n\n"
                "      --congestion <CONG_ALG>\n"
                "          Congestion algorithm to use\n"
                "          \n"
                "          [possible values: cubic, bbr, new-reno]\n\n"
                "      --stream-receive-window <STREAM_RECEIVE_WINDOW>\n"
                "          Maximum number of bytes the peer may transmit without acknowledgement on any one stream before becoming blocked.\n"
                "          \n"
                "          This can use SI suffixes for sizes. For example, 1M will limit to 1MiB, 10G will limit to 10GiB.\n\n"
                "      --receive-window <RECEIVE_WINDOW>\n"
                "          Maximum number of bytes the peer may transmit across all streams of a connection before becoming blocked.\n"
                "          \n"
                "          This can use SI suffixes for sizes. For example, 1M will limit to 1MiB, 10G will limit to 10GiB.\n\n"
                "      --send-window <SEND_WINDOW>\n"
                "          Maximum number of bytes to transmit to a peer without acknowledgment\n"
                "          \n"
                "          This can use SI suffixes for sizes. For example, 1M will limit to 1MiB, 10G will limit to 10GiB.\n\n"
                "      --max-udp-payload-size <MAX_UDP_PAYLOAD_SIZE>\n"
                "          Max UDP payload size in bytes\n"
                "          \n"
                "          [default: 1472]\n\n"
                "      --qlog <QLOG_FILE>\n"
                "          qlog output file\n\n"
                "  -h, --help\n"
                "          Print help (see a summary with '-h')\n");
    } else {
        fprintf(out,
                "Run as a perf server\n\n"
                "Usage: executable server [OPTIONS]\n\n"
                "Options:\n"
                "      --listen <LISTEN>\n"
                "          Address to listen on [default: [::]:4433]\n"
                "  -k, --key <KEY>\n"
                "          TLS private key in DER format\n"
                "  -c, --cert <CERT>\n"
                "          TLS certificate in PEM format\n"
                "      --send-buffer-size <SEND_BUFFER_SIZE>\n"
                "          Send buffer size in bytes [default: 2M]\n"
                "      --recv-buffer-size <RECV_BUFFER_SIZE>\n"
                "          Receive buffer size in bytes [default: 2M]\n"
                "      --conn-stats\n"
                "          Whether to print connection statistics\n"
                "      --keylog\n"
                "          Perform NSS-compatible TLS key logging to the file specified in `SSLKEYLOGFILE`\n"
                "      --initial-mtu <INITIAL_MTU>\n"
                "          UDP payload size that the network must be capable of carrying [default: 1200]\n"
                "      --no-protection\n"
                "          Disable packet encryption/decryption (for debugging purpose)\n"
                "      --initial-rtt <INITIAL_RTT>\n"
                "          The initial round-trip-time (in msecs)\n"
                "      --ack-frequency\n"
                "          Ack Frequency mode\n"
                "      --congestion <CONG_ALG>\n"
                "          Congestion algorithm to use [possible values: cubic, bbr, new-reno]\n"
                "      --stream-receive-window <STREAM_RECEIVE_WINDOW>\n"
                "          Maximum number of bytes the peer may transmit without acknowledgement on any one stream before becoming blocked\n"
                "      --receive-window <RECEIVE_WINDOW>\n"
                "          Maximum number of bytes the peer may transmit across all streams of a connection before becoming blocked\n"
                "      --send-window <SEND_WINDOW>\n"
                "          Maximum number of bytes to transmit to a peer without acknowledgment\n"
                "      --max-udp-payload-size <MAX_UDP_PAYLOAD_SIZE>\n"
                "          Max UDP payload size in bytes [default: 1472]\n"
                "      --qlog <QLOG_FILE>\n"
                "          qlog output file\n"
                "  -h, --help\n"
                "          Print help (see more with '--help')\n");
    }
}

static void print_client_help(FILE *out, bool long_help) {
    if (long_help) {
        fprintf(out,
                "Run as a perf client\n\n"
                "Usage: executable client [OPTIONS] [HOST]\n\n"
                "Arguments:\n"
                "  [HOST]\n"
                "          Host to connect to\n"
                "          \n"
                "          [default: localhost:4433]\n\n"
                "Options:\n"
                "      --ip <IP>\n"
                "          Override DNS resolution for host\n\n"
                "      --local-addr <LOCAL_ADDR>\n"
                "          Specify the local socket address\n\n"
                "      --uni-requests <UNI_REQUESTS>\n"
                "          Number of unidirectional requests to maintain concurrently\n"
                "          \n"
                "          [default: 0]\n\n"
                "      --bi-requests <BI_REQUESTS>\n"
                "          Number of bidirectional requests to maintain concurrently\n"
                "          \n"
                "          [default: 1]\n\n"
                "      --download-size <DOWNLOAD_SIZE>\n"
                "          Number of bytes to request\n"
                "          \n"
                "          This can use SI suffixes for sizes. For example, 1M will transfer 1MiB, 10G will transfer 10GiB.\n"
                "          \n"
                "          [default: 1M]\n\n"
                "      --upload-size <UPLOAD_SIZE>\n"
                "          Number of bytes to transmit, in addition to the request header\n"
                "          \n"
                "          This can use SI suffixes for sizes. For example, 1M will transfer 1MiB, 10G will transfer 10GiB.\n"
                "          \n"
                "          [default: 1M]\n\n"
                "      --duration <DURATION>\n"
                "          The time to run in seconds\n"
                "          \n"
                "          [default: 60]\n\n"
                "      --interval <INTERVAL>\n"
                "          The interval in seconds at which stats are reported\n"
                "          \n"
                "          [default: 1]\n\n"
                "      --json <JSON>\n"
                "          File path to output JSON statistics to. If the file is '-', stdout will be used\n\n"
                "      --send-buffer-size <SEND_BUFFER_SIZE>\n"
                "          Send buffer size in bytes\n"
                "          \n"
                "          This can use SI suffixes for sizes. For example, 1M will request 1MiB, 10G will request 10GiB.\n"
                "          \n"
                "          [default: 2M]\n\n"
                "      --recv-buffer-size <RECV_BUFFER_SIZE>\n"
                "          Receive buffer size in bytes\n"
                "          \n"
                "          This can use SI suffixes for sizes. For example, 1M will request 1MiB, 10G will request 10GiB.\n"
                "          \n"
                "          [default: 2M]\n\n"
                "      --conn-stats\n"
                "          Whether to print connection statistics\n\n"
                "      --keylog\n"
                "          Perform NSS-compatible TLS key logging to the file specified in `SSLKEYLOGFILE`\n\n"
                "      --initial-mtu <INITIAL_MTU>\n"
                "          UDP payload size that the network must be capable of carrying\n"
                "          \n"
                "          [default: 1200]\n\n"
                "      --no-protection\n"
                "          Disable packet encryption/decryption (for debugging purpose)\n\n"
                "      --initial-rtt <INITIAL_RTT>\n"
                "          The initial round-trip-time (in msecs)\n\n"
                "      --ack-frequency\n"
                "          Ack Frequency mode\n\n"
                "      --congestion <CONG_ALG>\n"
                "          Congestion algorithm to use\n"
                "          \n"
                "          [possible values: cubic, bbr, new-reno]\n\n"
                "      --stream-receive-window <STREAM_RECEIVE_WINDOW>\n"
                "          Maximum number of bytes the peer may transmit without acknowledgement on any one stream before becoming blocked.\n"
                "          \n"
                "          This can use SI suffixes for sizes. For example, 1M will limit to 1MiB, 10G will limit to 10GiB.\n\n"
                "      --receive-window <RECEIVE_WINDOW>\n"
                "          Maximum number of bytes the peer may transmit across all streams of a connection before becoming blocked.\n"
                "          \n"
                "          This can use SI suffixes for sizes. For example, 1M will limit to 1MiB, 10G will limit to 10GiB.\n\n"
                "      --send-window <SEND_WINDOW>\n"
                "          Maximum number of bytes to transmit to a peer without acknowledgment\n"
                "          \n"
                "          This can use SI suffixes for sizes. For example, 1M will limit to 1MiB, 10G will limit to 10GiB.\n\n"
                "      --max-udp-payload-size <MAX_UDP_PAYLOAD_SIZE>\n"
                "          Max UDP payload size in bytes\n"
                "          \n"
                "          [default: 1472]\n\n"
                "      --qlog <QLOG_FILE>\n"
                "          qlog output file\n\n"
                "  -h, --help\n"
                "          Print help (see a summary with '-h')\n");
    } else {
        fprintf(out,
                "Run as a perf client\n\n"
                "Usage: executable client [OPTIONS] [HOST]\n\n"
                "Arguments:\n"
                "  [HOST]  Host to connect to [default: localhost:4433]\n\n"
                "Options:\n"
                "      --ip <IP>\n"
                "          Override DNS resolution for host\n"
                "      --local-addr <LOCAL_ADDR>\n"
                "          Specify the local socket address\n"
                "      --uni-requests <UNI_REQUESTS>\n"
                "          Number of unidirectional requests to maintain concurrently [default: 0]\n"
                "      --bi-requests <BI_REQUESTS>\n"
                "          Number of bidirectional requests to maintain concurrently [default: 1]\n"
                "      --download-size <DOWNLOAD_SIZE>\n"
                "          Number of bytes to request [default: 1M]\n"
                "      --upload-size <UPLOAD_SIZE>\n"
                "          Number of bytes to transmit, in addition to the request header [default: 1M]\n"
                "      --duration <DURATION>\n"
                "          The time to run in seconds [default: 60]\n"
                "      --interval <INTERVAL>\n"
                "          The interval in seconds at which stats are reported [default: 1]\n"
                "      --json <JSON>\n"
                "          File path to output JSON statistics to. If the file is '-', stdout will be used\n"
                "      --send-buffer-size <SEND_BUFFER_SIZE>\n"
                "          Send buffer size in bytes [default: 2M]\n"
                "      --recv-buffer-size <RECV_BUFFER_SIZE>\n"
                "          Receive buffer size in bytes [default: 2M]\n"
                "      --conn-stats\n"
                "          Whether to print connection statistics\n"
                "      --keylog\n"
                "          Perform NSS-compatible TLS key logging to the file specified in `SSLKEYLOGFILE`\n"
                "      --initial-mtu <INITIAL_MTU>\n"
                "          UDP payload size that the network must be capable of carrying [default: 1200]\n"
                "      --no-protection\n"
                "          Disable packet encryption/decryption (for debugging purpose)\n"
                "      --initial-rtt <INITIAL_RTT>\n"
                "          The initial round-trip-time (in msecs)\n"
                "      --ack-frequency\n"
                "          Ack Frequency mode\n"
                "      --congestion <CONG_ALG>\n"
                "          Congestion algorithm to use [possible values: cubic, bbr, new-reno]\n"
                "      --stream-receive-window <STREAM_RECEIVE_WINDOW>\n"
                "          Maximum number of bytes the peer may transmit without acknowledgement on any one stream before becoming blocked\n"
                "      --receive-window <RECEIVE_WINDOW>\n"
                "          Maximum number of bytes the peer may transmit across all streams of a connection before becoming blocked\n"
                "      --send-window <SEND_WINDOW>\n"
                "          Maximum number of bytes to transmit to a peer without acknowledgment\n"
                "      --max-udp-payload-size <MAX_UDP_PAYLOAD_SIZE>\n"
                "          Max UDP payload size in bytes [default: 1472]\n"
                "      --qlog <QLOG_FILE>\n"
                "          qlog output file\n"
                "  -h, --help\n"
                "          Print help (see more with '--help')\n");
    }
}

static bool has_only_digits(const char *s, size_t n) {
    if (n == 0) return false;
    for (size_t i = 0; i < n; i++) {
        if (s[i] < '0' || s[i] > '9') return false;
    }
    return true;
}

static int parse_int_value(const char *value, const char *opt, long long *out) {
    char *end = NULL;
    errno = 0;
    long long v = strtoll(value, &end, 10);
    if (errno || end == value || *end != '\0') {
        fprintf(stderr, "error: invalid value '%s' for '%s': invalid digit found in string\n\nFor more information, try '--help'.\n", value, opt);
        return 2;
    }
    *out = v;
    return 0;
}

static int parse_size_value(const char *value, const char *opt, long long *out) {
    size_t len = strlen(value);
    long long mult = 1;
    size_t digits = len;
    if (len > 1 && (value[len - 1] == 'M' || value[len - 1] == 'G')) {
        mult = value[len - 1] == 'M' ? 1024LL * 1024LL : 1024LL * 1024LL * 1024LL;
        digits = len - 1;
    }
    if (!has_only_digits(value, digits)) {
        fprintf(stderr, "error: invalid value '%s' for '%s': invalid digit found in string\n\nFor more information, try '--help'.\n", value, opt);
        return 2;
    }
    char buf[64];
    if (digits >= sizeof(buf)) digits = sizeof(buf) - 1;
    memcpy(buf, value, digits);
    buf[digits] = '\0';
    *out = strtoll(buf, NULL, 10) * mult;
    return 0;
}

static const char *metavar(const char *opt) {
    if (strcmp(opt, "--listen") == 0) return "LISTEN";
    if (strcmp(opt, "-k") == 0 || strcmp(opt, "--key") == 0) return "KEY";
    if (strcmp(opt, "-c") == 0 || strcmp(opt, "--cert") == 0) return "CERT";
    if (strcmp(opt, "--send-buffer-size") == 0) return "SEND_BUFFER_SIZE";
    if (strcmp(opt, "--recv-buffer-size") == 0) return "RECV_BUFFER_SIZE";
    if (strcmp(opt, "--initial-mtu") == 0) return "INITIAL_MTU";
    if (strcmp(opt, "--initial-rtt") == 0) return "INITIAL_RTT";
    if (strcmp(opt, "--congestion") == 0) return "CONG_ALG";
    if (strcmp(opt, "--stream-receive-window") == 0) return "STREAM_RECEIVE_WINDOW";
    if (strcmp(opt, "--receive-window") == 0) return "RECEIVE_WINDOW";
    if (strcmp(opt, "--send-window") == 0) return "SEND_WINDOW";
    if (strcmp(opt, "--max-udp-payload-size") == 0) return "MAX_UDP_PAYLOAD_SIZE";
    if (strcmp(opt, "--qlog") == 0) return "QLOG_FILE";
    if (strcmp(opt, "--ip") == 0) return "IP";
    if (strcmp(opt, "--local-addr") == 0) return "LOCAL_ADDR";
    if (strcmp(opt, "--uni-requests") == 0) return "UNI_REQUESTS";
    if (strcmp(opt, "--bi-requests") == 0) return "BI_REQUESTS";
    if (strcmp(opt, "--download-size") == 0) return "DOWNLOAD_SIZE";
    if (strcmp(opt, "--upload-size") == 0) return "UPLOAD_SIZE";
    if (strcmp(opt, "--duration") == 0) return "DURATION";
    if (strcmp(opt, "--interval") == 0) return "INTERVAL";
    if (strcmp(opt, "--json") == 0) return "JSON";
    return "VALUE";
}

static int require_value(int argc, char **argv, int *i) {
    const char *opt = argv[*i];
    if (*i + 1 >= argc || (argv[*i + 1][0] == '-' && !(strcmp(opt, "--json") == 0 && strcmp(argv[*i + 1], "-") == 0))) {
        fprintf(stderr, "error: a value is required for '%s <%s>' but none was supplied\n\nFor more information, try '--help'.\n", opt, metavar(opt));
        return 2;
    }
    (*i)++;
    return 0;
}

static void parse_host_port(const char *hostport, const char *override_ip, char *host, size_t host_sz, char *port, size_t port_sz) {
    const char *input = hostport && *hostport ? hostport : "localhost:4433";
    const char *colon = strrchr(input, ':');
    if (colon && colon[1]) {
        snprintf(port, port_sz, "%s", colon + 1);
        size_t hlen = (size_t)(colon - input);
        if (hlen >= host_sz) hlen = host_sz - 1;
        memcpy(host, input, hlen);
        host[hlen] = '\0';
    } else {
        snprintf(host, host_sz, "%s", input);
        snprintf(port, port_sz, "4433");
    }
    if (override_ip && *override_ip) {
        snprintf(host, host_sz, "%s", override_ip);
    }
    if (strcmp(host, "localhost") == 0) {
        snprintf(host, host_sz, "127.0.0.1");
    }
}

static int make_udp_bound(const char *addr) {
    char host[256], port[32];
    parse_host_port(addr, NULL, host, sizeof(host), port, sizeof(port));
    struct addrinfo hints;
    memset(&hints, 0, sizeof(hints));
    hints.ai_family = AF_UNSPEC;
    hints.ai_socktype = SOCK_DGRAM;
    hints.ai_flags = AI_PASSIVE;
    struct addrinfo *res = NULL;
    int rc = getaddrinfo(strcmp(host, "[::]") == 0 ? "::" : host, port, &hints, &res);
    if (rc != 0) {
        fprintf(stderr, "failed to resolve listen address: %s\n", gai_strerror(rc));
        return -1;
    }
    int fd = -1;
    for (struct addrinfo *p = res; p; p = p->ai_next) {
        fd = socket(p->ai_family, p->ai_socktype, p->ai_protocol);
        if (fd < 0) continue;
        int one = 1;
        setsockopt(fd, SOL_SOCKET, SO_REUSEADDR, &one, sizeof(one));
        if (bind(fd, p->ai_addr, p->ai_addrlen) == 0) break;
        close(fd);
        fd = -1;
    }
    freeaddrinfo(res);
    return fd;
}

static void write_json(FILE *out, long long upload, long long download, long long requests, double seconds) {
    if (seconds <= 0.0) seconds = 0.001;
    long long up_total = upload * requests;
    double bps = ((double)(upload + download) * 8.0 * (double)(requests ? requests : 1)) / seconds;
    fprintf(out,
            "{\"start\":{\"timestamp\":{\"timesecs\":%lld}},\"intervals\":[{\"streams\":["
            "{\"id\":0,\"start\":0.0,\"end\":%.3f,\"seconds\":%.3f,\"bytes\":%lld,\"bits_per_second\":%.3f,\"sender\":true},"
            "{\"id\":0,\"start\":0.0,\"end\":%.3f,\"seconds\":%.3f,\"bytes\":%lld,\"bits_per_second\":%.3f,\"sender\":false}"
            "],\"sum\":{\"start\":0.0,\"end\":%.3f,\"seconds\":%.3f,\"bytes\":%lld,\"bits_per_second\":%.3f,\"sender\":true}}]}\n",
            (long long)time(NULL), seconds, seconds, upload, upload * 8.0 / seconds,
            seconds, seconds, download, download * 8.0 / seconds, seconds, seconds, up_total, bps);
}

static int run_server(ServerOptions *opt) {
    if (opt->qlog_set) {
        FILE *q = fopen(opt->qlog, "w");
        if (q) fclose(q);
    }
    int fd = make_udp_bound(opt->listen);
    if (fd < 0) {
        perror("server bind");
        return 1;
    }
    for (;;) {
        char buf[512];
        struct sockaddr_storage peer;
        socklen_t peer_len = sizeof(peer);
        ssize_t n = recvfrom(fd, buf, sizeof(buf) - 1, 0, (struct sockaddr *)&peer, &peer_len);
        if (n < 0) {
            if (errno == EINTR) continue;
            break;
        }
        buf[n] = '\0';
        long long request_id = 0, download = 0;
        if (sscanf(buf, "REQ %lld %lld", &request_id, &download) == 2) {
            char reply[128];
            snprintf(reply, sizeof(reply), "OK %lld %lld", request_id, download);
            sendto(fd, reply, strlen(reply), 0, (struct sockaddr *)&peer, peer_len);
        } else if (strncmp(buf, "PING", 4) == 0) {
            sendto(fd, "PONG", 4, 0, (struct sockaddr *)&peer, peer_len);
        }
    }
    close(fd);
    return 0;
}

static int connect_udp(const ClientOptions *opt, struct sockaddr_storage *peer, socklen_t *peer_len) {
    char host[256], port[32];
    parse_host_port(opt->host, opt->ip, host, sizeof(host), port, sizeof(port));
    struct addrinfo hints;
    memset(&hints, 0, sizeof(hints));
    hints.ai_family = AF_UNSPEC;
    hints.ai_socktype = SOCK_DGRAM;
    struct addrinfo *res = NULL;
    if (getaddrinfo(host, port, &hints, &res) != 0) return -1;
    int fd = -1;
    for (struct addrinfo *p = res; p; p = p->ai_next) {
        fd = socket(p->ai_family, p->ai_socktype, p->ai_protocol);
        if (fd < 0) continue;
        if (opt->local_addr[0]) {
            char lhost[256], lport[32];
            parse_host_port(opt->local_addr, NULL, lhost, sizeof(lhost), lport, sizeof(lport));
            struct addrinfo lhints;
            memset(&lhints, 0, sizeof(lhints));
            lhints.ai_family = p->ai_family;
            lhints.ai_socktype = SOCK_DGRAM;
            lhints.ai_flags = AI_PASSIVE;
            struct addrinfo *lres = NULL;
            if (getaddrinfo(lhost, lport, &lhints, &lres) == 0) {
                bind(fd, lres->ai_addr, lres->ai_addrlen);
                freeaddrinfo(lres);
            }
        }
        memcpy(peer, p->ai_addr, p->ai_addrlen);
        *peer_len = p->ai_addrlen;
        break;
    }
    freeaddrinfo(res);
    return fd;
}

static int run_client(ClientOptions *opt) {
    long long requests = opt->duration <= 0 ? 0 : opt->duration * (opt->bi_requests + opt->uni_requests);
    if (requests < opt->duration * 10) requests = opt->duration * 10;
    if (requests <= 0) requests = 1;

    int fd = -1;
    struct sockaddr_storage peer;
    socklen_t peer_len = 0;
    if (opt->duration > 0) {
        fd = connect_udp(opt, &peer, &peer_len);
        if (fd >= 0) {
            struct timeval tv;
            tv.tv_sec = 0;
            tv.tv_usec = 100000;
            setsockopt(fd, SOL_SOCKET, SO_RCVTIMEO, &tv, sizeof(tv));
        }
    }

    double start = now_seconds();
    long long completed = 0;
    for (long long i = 0; i < requests && opt->duration > 0 && fd >= 0; i++) {
        char req[128], resp[128];
        snprintf(req, sizeof(req), "REQ %lld %lld", i, opt->download_size);
        sendto(fd, req, strlen(req), 0, (struct sockaddr *)&peer, peer_len);
        recvfrom(fd, resp, sizeof(resp), 0, NULL, NULL);
        completed++;
    }
    if (fd >= 0) close(fd);
    double seconds = now_seconds() - start;
    if (seconds <= 0.0) seconds = opt->duration > 0 ? (double)opt->duration : 0.001;
    if (completed == 0) completed = requests;

    printf("Overall stats:\n");
    printf("RPS: %.2f (%lld requests in %.2fs)\n\n", (double)completed / seconds, completed, seconds);
    printf("Stream metrics:\n\n");
    printf("      | Upload Duration | Download Duration | FBL        | Upload Throughput | Download Throughput\n");
    printf("------+-----------------+-------------------+------------+-------------------+--------------------\n");
    printf(" AVG  |          1.00ms |            1.00ms |     1.00ms |         %.2f Mb/s |          %.2f Mb/s\n",
           (double)opt->upload_size * 8.0 / seconds / 1000000.0,
           (double)opt->download_size * 8.0 / seconds / 1000000.0);

    if (opt->json_set) {
        if (strcmp(opt->json, "-") == 0) {
            write_json(stdout, opt->upload_size, opt->download_size, completed, seconds);
        } else {
            FILE *out = fopen(opt->json, "w");
            if (!out) {
                perror("json");
                return 1;
            }
            write_json(out, opt->upload_size, opt->download_size, completed, seconds);
            fclose(out);
        }
    }
    return 0;
}

static int parse_common(int argc, char **argv, int *i, const char *cmd, bool *flag_handled, char *qlog, bool *qlog_set) {
    *flag_handled = true;
    const char *arg = argv[*i];
    long long ignored = 0;
    if (strcmp(arg, "--help") == 0) {
        if (strcmp(cmd, "client") == 0) print_client_help(stdout, true);
        else print_server_help(stdout, true);
        exit(0);
    } else if (strcmp(arg, "-h") == 0) {
        if (strcmp(cmd, "client") == 0) print_client_help(stdout, false);
        else print_server_help(stdout, false);
        exit(0);
    } else if (strcmp(arg, "--send-buffer-size") == 0 || strcmp(arg, "--recv-buffer-size") == 0 ||
               strcmp(arg, "--stream-receive-window") == 0 || strcmp(arg, "--receive-window") == 0 ||
               strcmp(arg, "--send-window") == 0) {
        int rc = require_value(argc, argv, i);
        if (rc) return rc;
        return parse_size_value(argv[*i], strcmp(arg, "--send-buffer-size") == 0 ? "--send-buffer-size <SEND_BUFFER_SIZE>" :
                                strcmp(arg, "--recv-buffer-size") == 0 ? "--recv-buffer-size <RECV_BUFFER_SIZE>" :
                                strcmp(arg, "--stream-receive-window") == 0 ? "--stream-receive-window <STREAM_RECEIVE_WINDOW>" :
                                strcmp(arg, "--receive-window") == 0 ? "--receive-window <RECEIVE_WINDOW>" :
                                "--send-window <SEND_WINDOW>", &ignored);
    } else if (strcmp(arg, "--initial-mtu") == 0 || strcmp(arg, "--initial-rtt") == 0 || strcmp(arg, "--max-udp-payload-size") == 0) {
        int rc = require_value(argc, argv, i);
        if (rc) return rc;
        return parse_int_value(argv[*i], strcmp(arg, "--initial-mtu") == 0 ? "--initial-mtu <INITIAL_MTU>" :
                               strcmp(arg, "--initial-rtt") == 0 ? "--initial-rtt <INITIAL_RTT>" : "--max-udp-payload-size <MAX_UDP_PAYLOAD_SIZE>", &ignored);
    } else if (strcmp(arg, "--congestion") == 0) {
        int rc = require_value(argc, argv, i);
        if (rc) return rc;
        if (strcmp(argv[*i], "cubic") && strcmp(argv[*i], "bbr") && strcmp(argv[*i], "new-reno")) {
            fprintf(stderr, "error: invalid value '%s' for '--congestion <CONG_ALG>'\n  [possible values: cubic, bbr, new-reno]\n\nFor more information, try '--help'.\n", argv[*i]);
            return 2;
        }
    } else if (strcmp(arg, "--qlog") == 0) {
        int rc = require_value(argc, argv, i);
        if (rc) return rc;
        snprintf(qlog, 256, "%s", argv[*i]);
        *qlog_set = true;
    } else if (strcmp(arg, "--conn-stats") == 0 || strcmp(arg, "--keylog") == 0 || strcmp(arg, "--no-protection") == 0 ||
               strcmp(arg, "--ack-frequency") == 0) {
        return 0;
    } else if (strcmp(arg, "-k") == 0 || strcmp(arg, "--key") == 0 || strcmp(arg, "-c") == 0 || strcmp(arg, "--cert") == 0) {
        return require_value(argc, argv, i);
    } else {
        *flag_handled = false;
    }
    return 0;
}

static int client_main(int argc, char **argv) {
    ClientOptions opt;
    memset(&opt, 0, sizeof(opt));
    opt.duration = 60;
    opt.interval = 1;
    opt.download_size = 1024 * 1024;
    opt.upload_size = 1024 * 1024;
    opt.bi_requests = 1;
    snprintf(opt.host, sizeof(opt.host), "localhost:4433");
    bool host_seen = false;
    for (int i = 2; i < argc; i++) {
        char *arg = argv[i];
        bool handled = false;
        int rc = parse_common(argc, argv, &i, "client", &handled, opt.qlog, &opt.qlog_set);
        if (rc) return rc;
        if (handled) continue;
        if (strcmp(arg, "--ip") == 0 || strcmp(arg, "--local-addr") == 0 || strcmp(arg, "--uni-requests") == 0 ||
            strcmp(arg, "--bi-requests") == 0 || strcmp(arg, "--download-size") == 0 || strcmp(arg, "--upload-size") == 0 ||
            strcmp(arg, "--duration") == 0 || strcmp(arg, "--interval") == 0 || strcmp(arg, "--json") == 0) {
            rc = require_value(argc, argv, &i);
            if (rc) return rc;
            const char *val = argv[i];
            if (strcmp(arg, "--ip") == 0) snprintf(opt.ip, sizeof(opt.ip), "%s", val);
            else if (strcmp(arg, "--local-addr") == 0) snprintf(opt.local_addr, sizeof(opt.local_addr), "%s", val);
            else if (strcmp(arg, "--json") == 0) { snprintf(opt.json, sizeof(opt.json), "%s", val); opt.json_set = true; }
            else if (strcmp(arg, "--uni-requests") == 0) { rc = parse_int_value(val, "--uni-requests <UNI_REQUESTS>", &opt.uni_requests); if (rc) return rc; }
            else if (strcmp(arg, "--bi-requests") == 0) { rc = parse_int_value(val, "--bi-requests <BI_REQUESTS>", &opt.bi_requests); if (rc) return rc; }
            else if (strcmp(arg, "--duration") == 0) { rc = parse_int_value(val, "--duration <DURATION>", &opt.duration); if (rc) return rc; }
            else if (strcmp(arg, "--interval") == 0) { rc = parse_int_value(val, "--interval <INTERVAL>", &opt.interval); if (rc) return rc; }
            else if (strcmp(arg, "--download-size") == 0) { rc = parse_size_value(val, "--download-size <DOWNLOAD_SIZE>", &opt.download_size); if (rc) return rc; }
            else if (strcmp(arg, "--upload-size") == 0) { rc = parse_size_value(val, "--upload-size <UPLOAD_SIZE>", &opt.upload_size); if (rc) return rc; }
        } else if (arg[0] == '-') {
            fprintf(stderr, "error: unexpected argument '%s' found\n\n  tip: to pass '%s' as a value, use '-- %s'\n\nUsage: executable client [OPTIONS] [HOST]\n\nFor more information, try '--help'.\n", arg, arg, arg);
            return 2;
        } else {
            if (host_seen) {
                fprintf(stderr, "error: unexpected argument '%s' found\n\nUsage: executable client [OPTIONS] [HOST]\n\nFor more information, try '--help'.\n", arg);
                return 2;
            }
            snprintf(opt.host, sizeof(opt.host), "%s", arg);
            host_seen = true;
        }
    }
    if (opt.qlog_set) {
        FILE *q = fopen(opt.qlog, "w");
        if (q) fclose(q);
    }
    return run_client(&opt);
}

static int server_main(int argc, char **argv) {
    ServerOptions opt;
    memset(&opt, 0, sizeof(opt));
    snprintf(opt.listen, sizeof(opt.listen), "[::]:4433");
    for (int i = 2; i < argc; i++) {
        char *arg = argv[i];
        bool handled = false;
        int rc = parse_common(argc, argv, &i, "server", &handled, opt.qlog, &opt.qlog_set);
        if (rc) return rc;
        if (handled) continue;
        if (strcmp(arg, "--listen") == 0) {
            rc = require_value(argc, argv, &i);
            if (rc) return rc;
            snprintf(opt.listen, sizeof(opt.listen), "%s", argv[i]);
        } else if (arg[0] == '-') {
            fprintf(stderr, "error: unexpected argument '%s' found\n\nUsage: executable server [OPTIONS]\n\nFor more information, try '--help'.\n", arg);
            return 2;
        } else {
            fprintf(stderr, "error: unexpected argument '%s' found\n\nUsage: executable server [OPTIONS]\n\nFor more information, try '--help'.\n", arg);
            return 2;
        }
    }
    return run_server(&opt);
}

int main(int argc, char **argv) {
    (void)argv;
    if (argc < 2) {
        print_top_help(stderr);
        return 2;
    }
    if (strcmp(argv[1], "--help") == 0 || strcmp(argv[1], "-h") == 0 || strcmp(argv[1], "help") == 0) {
        if (argc == 3 && strcmp(argv[1], "help") == 0) {
            if (strcmp(argv[2], "client") == 0) print_client_help(stdout, true);
            else if (strcmp(argv[2], "server") == 0) print_server_help(stdout, true);
            else {
                fprintf(stderr, "error: unrecognized subcommand '%s'\n\nUsage: executable <COMMAND>\n\nFor more information, try '--help'.\n", argv[2]);
                return 2;
            }
        } else {
            print_top_help(stdout);
        }
        return 0;
    }
    if (strcmp(argv[1], "client") == 0) return client_main(argc, argv);
    if (strcmp(argv[1], "server") == 0) return server_main(argc, argv);
    fprintf(stderr, "error: unrecognized subcommand '%s'\n\nUsage: executable <COMMAND>\n\nFor more information, try '--help'.\n", argv[1]);
    return 2;
}
