#!/usr/bin/env python3
import argparse
import gzip
import json
import os
import re
import sys
from collections import Counter, defaultdict
from dataclasses import dataclass
from datetime import datetime, time
from pathlib import Path


MONTHS = {
    "Jan": 1, "Feb": 2, "Mar": 3, "Apr": 4, "May": 5, "Jun": 6,
    "Jul": 7, "Aug": 8, "Sep": 9, "Oct": 10, "Nov": 11, "Dec": 12,
}

LOG_RE = re.compile(
    r'^(?P<ip>\S+) \S+ \S+ \[(?P<stamp>[^\]]+)\] '
    r'"(?P<request>[^"]*)" (?P<status>\d{3}) (?P<bytes>\S+) '
    r'"(?P<referer>[^"]*)" "(?P<agent>[^"]*)"'
)


@dataclass
class Hit:
    raw: str
    date: str
    time: str
    remote_addr: str
    method: str
    path: str
    status: str
    bytes_sent: int
    referer: str
    dt: datetime


def parse_hit(line):
    m = LOG_RE.match(line.rstrip("\n"))
    if not m:
        return None
    stamp = m.group("stamp").split()[0]
    try:
        day_s, mon_s, rest = stamp.split("/", 2)
        year_s, hh, mm, ss = re.match(r"(\d+):(\d+):(\d+):(\d+)", rest).groups()
        dt = datetime(int(year_s), MONTHS[mon_s], int(day_s), int(hh), int(mm), int(ss))
    except Exception:
        return None
    request = m.group("request")
    parts = request.split()
    if len(parts) >= 2 and re.match(r"^[A-Z]+$", parts[0]):
        method, path = parts[0], parts[1].split("?", 1)[0]
    else:
        method, path = "none", request
    sent = m.group("bytes")
    return Hit(
        raw=line if line.endswith("\n") else line + "\n",
        date=f"{dt.year:04d}/{dt.month:02d}/{dt.day:02d}",
        time=f"{dt.hour:02d}:{dt.minute:02d}:{dt.second:02d}",
        remote_addr=m.group("ip"),
        method=method,
        path=path,
        status=m.group("status"),
        bytes_sent=0 if sent == "-" else int(sent),
        referer=m.group("referer"),
        dt=dt,
    )


def parse_args(argv):
    parser = argparse.ArgumentParser(
        prog="rhit",
        add_help=False,
        usage="rhit [options] [FILES]",
    )
    parser.add_argument("files", nargs="*")
    parser.add_argument("--help", action="store_true")
    parser.add_argument("--version", action="store_true")
    parser.add_argument("--color", choices=["auto", "yes", "no"], default="auto")
    parser.add_argument("-k", "--key", default="hits")
    parser.add_argument("-l", "--length", default="1")
    parser.add_argument("-f", "--fields", default="date,status,ref,path")
    parser.add_argument("-c", "--changes", action="store_true")
    parser.add_argument("-d", "--date")
    parser.add_argument("-i", "--ip")
    parser.add_argument("-m", "--method")
    parser.add_argument("-p", "--path")
    parser.add_argument("-r", "--referer")
    parser.add_argument("-s", "--status")
    parser.add_argument("-t", "--time")
    parser.add_argument("-a", "--all", action="store_true")
    parser.add_argument("--no-name-check", action="store_true")
    parser.add_argument("-o", "--output", default="tables")
    parser.add_argument("--silent-load", action="store_true")
    return parser.parse_args(argv)


def print_help():
    print("rhit 2.0.4")
    print()
    print("Rhit analyzes your nginx logs.")
    print()
    print("Usage: rhit [options] [FILES]")
    print()
    print("Options:")
    print("  --help                 Print help information")
    print("  --version              Print the version")
    print("  --color <color>        Possible values: auto, yes, no")
    print("  -k, --key <KEY>        Key used in sorting: hits or bytes")
    print("  -l, --length <LENGTH>  Detail level, from 0 to 6")
    print("  -f, --fields <FIELDS>  Fields: date,time,method,status,ip,ref,path")
    print("  -c, --changes          Add change tables")
    print("  -d, --date <DATE>      Filter dates")
    print("  -i, --ip <IP>          Ip address filter")
    print("  -m, --method <METHOD>  HTTP method filter")
    print("  -p, --path <PATH>      Path filter")
    print("  -r, --referer <REF>    Referer filter")
    print("  -s, --status <STATUS>  Status filter")
    print("  -t, --time <TIME>      Time of day filter")
    print("  -a, --all              Show all paths")
    print("      --no-name-check    Try to open all files")
    print("  -o, --output <OUTPUT>  tables, raw, csv, or json")
    print("      --silent-load      Don't print during load")


def candidate_files(paths, no_name_check=False):
    if not paths:
        paths = ["/var/log/nginx"]
    files = []
    for name in paths:
        p = Path(name)
        if not p.exists():
            raise FileNotFoundError(name)
        if p.is_dir():
            for child in sorted(p.rglob("*")):
                if child.is_file() and (no_name_check or is_log_name(child.name)):
                    files.append(child)
        elif no_name_check or is_log_name(p.name):
            files.append(p)
    if not files:
        raise RuntimeError("NoLogFileFound")
    return files


def is_log_name(name):
    return (
        name == "access.log"
        or name.startswith("access.log.")
        or name.endswith(".access.log")
        or name.endswith(".access.log.gz")
    )


def open_text(path):
    if str(path).endswith(".gz"):
        return gzip.open(path, "rt", encoding="utf-8", errors="replace")
    return open(path, "rt", encoding="utf-8", errors="replace")


def load_hits(files):
    hits = []
    for path in files:
        with open_text(path) as f:
            for line in f:
                hit = parse_hit(line)
                if hit is not None:
                    hits.append(hit)
    return hits


def regex_filter(value, expr):
    if expr is None:
        return True
    expr = expr.strip()
    if not expr:
        return True
    if "," in expr:
        return all(regex_filter(value, part) for part in expr.split(","))
    neg = expr.startswith("!")
    if neg:
        expr = expr[1:]
    try:
        ok = re.search(expr, value) is not None
    except re.error:
        ok = expr in value
    return not ok if neg else ok


def method_filter(value, expr):
    if expr is None:
        return True
    neg = expr.startswith("!")
    wanted = expr[1:] if neg else expr
    ok = value.lower() == wanted.lower()
    return not ok if neg else ok


def status_token_match(status, token):
    if re.fullmatch(r"\dxx", token):
        return status.startswith(token[0])
    if re.fullmatch(r"\d{3}-\d{3}", token):
        lo, hi = map(int, token.split("-"))
        return lo <= int(status) <= hi
    return status == token


def status_filter(status, expr):
    if expr is None:
        return True
    positives = []
    negatives = []
    for token in [t.strip() for t in expr.split(",") if t.strip()]:
        if token.startswith("!"):
            negatives.append(token[1:])
        else:
            positives.append(token)
    if positives and not any(status_token_match(status, t) for t in positives):
        return False
    return not any(status_token_match(status, t) for t in negatives)


def parse_date_piece(piece, end=False):
    if "T" in piece:
        d, t = piece.split("T", 1)
    else:
        d, t = piece, None
    parts = [int(x) for x in d.split("/") if x]
    if len(parts) == 1:
        y, mo, da = parts[0], (12 if end else 1), (31 if end else 1)
    elif len(parts) == 2:
        y, mo, da = parts[0], parts[1], (31 if end else 1)
    else:
        y, mo, da = parts[0], parts[1], parts[2]
    if t:
        ts = [int(x) for x in t.split(":")]
        while len(ts) < 3:
            ts.append(59 if end else 0)
    else:
        ts = [23, 59, 59] if end else [0, 0, 0]
    return datetime(y, mo, da, ts[0], ts[1], ts[2])


def date_filter(dt, expr):
    if expr is None:
        return True
    neg = expr.startswith("!")
    if neg:
        expr = expr[1:]
    if expr.startswith(">"):
        ok = dt > parse_date_piece(expr[1:], True)
    elif expr.startswith("<"):
        ok = dt < parse_date_piece(expr[1:], False)
    elif "-" in expr:
        lo, hi = expr.split("-", 1)
        ok = parse_date_piece(lo, False) <= dt <= parse_date_piece(hi, True)
    else:
        ok = parse_date_piece(expr, False) <= dt <= parse_date_piece(expr, True)
    return not ok if neg else ok


def parse_time_value(s, end=False):
    parts = [int(x) for x in s.split(":")]
    while len(parts) < 3:
        parts.append(59 if end else 0)
    return time(parts[0], parts[1], parts[2])


def time_filter(value, expr):
    if expr is None:
        return True
    cur = parse_time_value(value)
    if expr.startswith(">"):
        return cur > parse_time_value(expr[1:], True)
    if expr.startswith("<"):
        return cur < parse_time_value(expr[1:], False)
    if "-" in expr:
        lo, hi = expr.split("-", 1)
        return parse_time_value(lo) <= cur <= parse_time_value(hi, True)
    return cur == parse_time_value(expr)


def filtered(hits, args):
    out = []
    for h in hits:
        if not date_filter(h.dt, args.date):
            continue
        if not time_filter(h.time, args.time):
            continue
        if not regex_filter(h.remote_addr, args.ip):
            continue
        if not method_filter(h.method, args.method):
            continue
        if not regex_filter(h.path, args.path):
            continue
        if not regex_filter(h.referer, args.referer):
            continue
        if not status_filter(h.status, args.status):
            continue
        out.append(h)
    return out


def write_csv(hits):
    print("date,time,remote address,method,path,status,bytes sent,referer")
    for h in hits:
        print(
            f"{h.date},{h.time},{h.remote_addr},{h.method},"
            f"\"{csv_escape(h.path)}\",{h.status},{h.bytes_sent},\"{csv_escape(h.referer)}\""
        )


def csv_escape(value):
    return value.replace('"', '""')


def write_json(hits):
    rows = [
        {
            "date": h.date,
            "time": h.time,
            "remote_addr": h.remote_addr,
            "method": h.method,
            "path": h.path,
            "status": h.status,
            "bytes_sent": h.bytes_sent,
            "referer": h.referer,
        }
        for h in hits
    ]
    print(json.dumps(rows, indent=2))


def parse_fields(expr):
    default = ["date", "status", "ref", "path"]
    all_fields = ["date", "time", "method", "status", "ip", "ref", "path"]
    aliases = {
        "d": "date", "date": "date",
        "t": "time", "time": "time",
        "m": "method", "method": "method",
        "s": "status", "status": "status",
        "i": "ip", "ip": "ip",
        "r": "ref", "ref": "ref", "referer": "ref",
        "p": "path", "path": "path",
        "a": "all", "all": "all",
    }
    if not expr:
        return default
    tokens = re.findall(r"[+-]?[^,+-]+", expr.replace(",", "+"))
    fields = default[:] if tokens and tokens[0][0] in "+-" else []
    for token in tokens:
        op = token[0] if token[0] in "+-" else "+"
        name = aliases.get(token[1:] if token[0] in "+-" else token, token)
        additions = all_fields if name == "all" else [name]
        if op == "-":
            fields = [f for f in fields if f not in additions]
        else:
            for f in additions:
                if f in fields:
                    fields.remove(f)
                fields.append(f)
    return fields


def value_for(h, field):
    return {
        "date": h.date,
        "time": h.time[:2] + ":00",
        "method": h.method,
        "status": h.status,
        "ip": h.remote_addr,
        "ref": h.referer,
        "path": h.path,
    }[field]


def write_tables(hits, args):
    total_bytes = sum(h.bytes_sent for h in hits)
    if hits:
        print(f"{len(hits)} hits and {total_bytes} from {hits[0].date} to {hits[-1].date}")
    else:
        print("0 hits and 0")
    limit = max(1, min(200, (int(args.length) + 1) * 4 if str(args.length).isdigit() else 8))
    for field in parse_fields(args.fields):
        counts = defaultdict(lambda: [0, 0])
        for h in hits:
            if field == "path" and not args.all and is_resource(h.path):
                continue
            item = value_for(h, field)
            counts[item][0] += 1
            counts[item][1] += h.bytes_sent
        title = {"ref": "referers", "ip": "remote addresses"}.get(field, field + "s")
        suffix = " (excluding resources like images, css, etc.)." if field == "path" and not args.all else "."
        print(f"{len(counts)} {title}{suffix}")
        print("#\t" + field + "\thits\t%\tbytes")
        rows = sorted(counts.items(), key=lambda kv: (-kv[1][0], kv[0]))[:limit]
        for idx, (name, (count, sent)) in enumerate(rows, 1):
            pct = (count * 100.0 / len(hits)) if hits else 0.0
            print(f"{idx}\t{name}\t{count}\t{pct:.1f}%\t{sent}")


def is_resource(path):
    return re.search(r"\.(?:png|jpe?g|gif|webp|svg|ico|css|js|map|woff2?|ttf|eot)(?:$|\?)", path, re.I) is not None


def main(argv=None):
    args = parse_args(sys.argv[1:] if argv is None else argv)
    if args.help:
        print_help()
        return 0
    if args.version:
        print("rhit 2.0.4")
        return 0
    output_aliases = {"t": "tables", "r": "raw", "c": "csv", "j": "json"}
    args.output = output_aliases.get(args.output, args.output)
    outputs = {"tables", "raw", "csv", "json"}
    if args.output not in outputs:
        print(f"error: invalid value '{args.output}' for '--output <OUTPUT>': unrecognized output \"{args.output}\"", file=sys.stderr)
        return 2
    try:
        files = candidate_files(args.files, args.no_name_check)
        hits = filtered(load_hits(files), args)
    except FileNotFoundError as e:
        print(f'Error: PathNotFound("{e.args[0]}")', file=sys.stderr)
        return 1
    except RuntimeError as e:
        print(f"Error: {e}", file=sys.stderr)
        return 1
    if args.output == "raw":
        for h in hits:
            sys.stdout.write(h.raw)
    elif args.output == "csv":
        write_csv(hits)
    elif args.output == "json":
        write_json(hits)
    else:
        write_tables(hits, args)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
