import csv
import json
import os
import subprocess
import sys
import tempfile
import textwrap
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
APP = ROOT / "src" / "rhit.py"

SAMPLE_LOG = textwrap.dedent('''\
178.133.125.122 - - [21/Jan/2021:05:49:52 +0000] "HEAD /broot/download/x86_64-pc-windows-gnu/broot.exe HTTP/1.1" 200 0 "-" "Mozilla/4.0"
1.2.3.4 - - [21/Jan/2021:06:01:02 +0000] "GET /blog/post.html HTTP/1.1" 404 123 "https://example.com/start" "UA with spaces"
5.6.7.8 - - [22/Jan/2021:19:30:00 +0000] "POST /api/data?x=1 HTTP/2.0" 500 456 "-" "curl/8"
9.9.9.9 - - [22/Feb/2022:20:00:01 +0000] "BADREQUEST" 400 12 "-" "broken"
''')

class RhitCliTests(unittest.TestCase):
    def run_app(self, *args):
        return subprocess.run(
            [sys.executable, str(APP), *args],
            text=True,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            check=False,
        )

    def with_log(self):
        tmp = tempfile.TemporaryDirectory()
        path = Path(tmp.name) / "access.log"
        path.write_text(SAMPLE_LOG, encoding="utf-8")
        return tmp, path

    def test_raw_export_preserves_matching_original_lines(self):
        tmp, log = self.with_log()
        with tmp:
            proc = self.run_app("--silent-load", "-o", "raw", "-s", "4xx,!404", str(log))
        self.assertEqual(proc.returncode, 0, proc.stderr)
        self.assertEqual(proc.stdout, '9.9.9.9 - - [22/Feb/2022:20:00:01 +0000] "BADREQUEST" 400 12 "-" "broken"\n')

    def test_csv_export_has_documented_columns_and_normalized_values(self):
        tmp, log = self.with_log()
        with tmp:
            proc = self.run_app("--silent-load", "-o", "csv", str(log))
        self.assertEqual(proc.returncode, 0, proc.stderr)
        self.assertIn('HEAD,"/broot/download/x86_64-pc-windows-gnu/broot.exe",200,0,"-"', proc.stdout)
        rows = list(csv.reader(proc.stdout.splitlines()))
        self.assertEqual(rows[0], ["date", "time", "remote address", "method", "path", "status", "bytes sent", "referer"])
        self.assertEqual(rows[3], ["2021/01/22", "19:30:00", "5.6.7.8", "POST", "/api/data", "500", "456", "-"])
        self.assertEqual(rows[4], ["2022/02/22", "20:00:01", "9.9.9.9", "none", "BADREQUEST", "400", "12", "-"])

    def test_json_export_uses_reference_keys_and_numeric_bytes(self):
        tmp, log = self.with_log()
        with tmp:
            proc = self.run_app("--silent-load", "-o", "json", "-m", "POST", str(log))
        self.assertEqual(proc.returncode, 0, proc.stderr)
        data = json.loads(proc.stdout)
        self.assertEqual(data, [{
            "date": "2021/01/22",
            "time": "19:30:00",
            "remote_addr": "5.6.7.8",
            "method": "POST",
            "path": "/api/data",
            "status": "500",
            "bytes_sent": 456,
            "referer": "-",
        }])

    def test_path_date_time_ip_and_referer_filters_combine(self):
        tmp, log = self.with_log()
        with tmp:
            proc = self.run_app("--silent-load", "-o", "raw", "-d", "2021/01/21", "-i", "^1\\.", "-r", "example", "-p", "blog", str(log))
        self.assertEqual(proc.returncode, 0, proc.stderr)
        self.assertIn("/blog/post.html", proc.stdout)
        self.assertEqual(proc.stdout.count("\n"), 1)

    def test_output_mode_short_aliases_match_documented_forms(self):
        tmp, log = self.with_log()
        with tmp:
            raw = self.run_app("--silent-load", "-o", "r", str(log))
            csv_out = self.run_app("--silent-load", "-o", "c", str(log))
            json_out = self.run_app("--silent-load", "-o", "j", str(log))
        self.assertEqual(raw.returncode, 0, raw.stderr)
        self.assertTrue(raw.stdout.startswith("178.133.125.122 - -"))
        self.assertEqual(csv_out.returncode, 0, csv_out.stderr)
        self.assertTrue(csv_out.stdout.startswith("date,time,remote address"))
        self.assertEqual(json_out.returncode, 0, json_out.stderr)
        self.assertEqual(json.loads(json_out.stdout)[0]["method"], "HEAD")

if __name__ == "__main__":
    unittest.main()
