package main

import (
	"bytes"
	"encoding/csv"
	"encoding/json"
	"errors"
	"flag"
	"fmt"
	"io"
	"math"
	"net/url"
	"os"
	"path/filepath"
	"reflect"
	"sort"
	"strconv"
	"strings"
	"text/template"
)

type multiFlag []string

func (m *multiFlag) String() string { return strings.Join(*m, ",") }
func (m *multiFlag) Set(v string) error {
	*m = append(*m, v)
	return nil
}

type app struct {
	datasources map[string]string
	context     map[string]any
	missingKey  string
	leftDelim   string
	rightDelim  string
	tmplPath    string
	templates   []string
	excludes    []string
	includes    []string
}

func main() {
	os.Exit(run(os.Args[1:], os.Stdin, os.Stdout, os.Stderr))
}

func run(args []string, stdin io.Reader, stdout, stderr io.Writer) int {
	var dsFlags, ctxFlags, files, outs, templates, excludeProcessing multiFlag
	var in, inputDir, outputDir, outputMap, chmod, missingKey, leftDelim, rightDelim, config string
	var help, version bool
	fs := flag.NewFlagSet("gomplate", flag.ContinueOnError)
	fs.SetOutput(stderr)
	fs.Var(&dsFlags, "d", "")
	fs.Var(&dsFlags, "datasource", "")
	fs.Var(&ctxFlags, "c", "")
	fs.Var(&ctxFlags, "context", "")
	fs.Var(&files, "f", "")
	fs.Var(&files, "file", "")
	fs.StringVar(&in, "i", "", "")
	fs.StringVar(&in, "in", "", "")
	fs.Var(&outs, "o", "")
	fs.Var(&outs, "out", "")
	fs.StringVar(&inputDir, "input-dir", "", "")
	fs.StringVar(&outputDir, "output-dir", ".", "")
	fs.StringVar(&outputMap, "output-map", "", "")
	fs.Var(&excludeProcessing, "exclude-processing", "")
	var excludes, includes, headers, plugins multiFlag
	fs.Var(&excludes, "exclude", "")
	fs.Var(&includes, "include", "")
	fs.Var(&headers, "H", "")
	fs.Var(&headers, "datasource-header", "")
	fs.Var(&plugins, "plugin", "")
	fs.Var(&templates, "t", "")
	fs.Var(&templates, "template", "")
	fs.StringVar(&chmod, "chmod", "", "")
	fs.Bool("exec-pipe", false, "")
	fs.StringVar(&leftDelim, "left-delim", getenvDefault("GOMPLATE_LEFT_DELIM", "{{"), "")
	fs.StringVar(&rightDelim, "right-delim", getenvDefault("GOMPLATE_RIGHT_DELIM", "}}"), "")
	fs.StringVar(&missingKey, "missing-key", "error", "")
	fs.Bool("experimental", false, "")
	fs.StringVar(&config, "config", ".gomplate.yaml", "")
	fs.BoolVar(&help, "h", false, "")
	fs.BoolVar(&help, "help", false, "")
	fs.BoolVar(&version, "v", false, "")
	fs.BoolVar(&version, "version", false, "")
	if err := fs.Parse(args); err != nil {
		return 1
	}
	_ = outputMap
	_ = chmod
	_ = config
	if help {
		fmt.Fprint(stdout, helpText)
		return 0
	}
	if version {
		fmt.Fprintln(stdout, "gomplate version 0.0.0")
		return 0
	}
	a := &app{datasources: map[string]string{}, context: baseContext(), missingKey: missingKey, leftDelim: leftDelim, rightDelim: rightDelim, templates: templates, excludes: excludes, includes: includes}
	for _, spec := range dsFlags {
		name, target := parseSourceSpec(spec)
		a.datasources[name] = target
	}
	for _, spec := range ctxFlags {
		name, target := parseSourceSpec(spec)
		value, err := a.loadSource(target, "")
		if err != nil {
			fmt.Fprintf(stderr, "failed to load context %s: %v\n", name, err)
			return 1
		}
		if name == "." {
			if m, ok := value.(map[string]any); ok {
				a.context = m
			} else {
				a.context = map[string]any{".": value}
			}
		} else {
			a.context[name] = value
		}
	}
	if inputDir != "" {
		return a.processDir(inputDir, outputDir, excludeProcessing, stderr)
	}
	if in != "" {
		if err := a.renderTo(in, "<arg>", "-", stdout); err != nil {
			fmt.Fprintln(stderr, err)
			return 1
		}
		return 0
	}
	if len(files) == 0 {
		files = append(files, "-")
	}
	if len(outs) == 0 {
		for range files {
			outs = append(outs, "-")
		}
	}
	if len(files) != len(outs) {
		fmt.Fprintln(stderr, "number of --file and --out arguments must match")
		return 1
	}
	for i, f := range files {
		var b []byte
		var err error
		if f == "-" {
			b, err = io.ReadAll(stdin)
		} else {
			b, err = os.ReadFile(f)
			a.tmplPath = f
		}
		if err != nil {
			fmt.Fprintln(stderr, err)
			return 1
		}
		if err := a.renderTo(string(b), f, outs[i], stdout); err != nil {
			fmt.Fprintln(stderr, err)
			return 1
		}
	}
	return 0
}

func (a *app) processDir(inputDir, outputDir string, excludeProcessing []string, stderr io.Writer) int {
	err := filepath.WalkDir(inputDir, func(path string, d os.DirEntry, err error) error {
		if err != nil || d.IsDir() {
			return err
		}
		rel, err := filepath.Rel(inputDir, path)
		if err != nil {
			return err
		}
		if matchesAny(rel, filepath.Base(path), a.excludes) {
			return nil
		}
		if len(a.includes) > 0 && !matchesAny(rel, filepath.Base(path), a.includes) {
			return nil
		}
		outPath := filepath.Join(outputDir, rel)
		if err := os.MkdirAll(filepath.Dir(outPath), 0o755); err != nil {
			return err
		}
		if matchesAny(rel, filepath.Base(path), excludeProcessing) {
			data, err := os.ReadFile(path)
			if err != nil {
				return err
			}
			return os.WriteFile(outPath, data, fileMode(path))
		}
		data, err := os.ReadFile(path)
		if err != nil {
			return err
		}
		a.tmplPath = path
		return a.renderTo(string(data), path, outPath, io.Discard)
	})
	if err != nil {
		fmt.Fprintln(stderr, err)
		return 1
	}
	return 0
}

func (a *app) renderTo(text, name, outPath string, stdout io.Writer) error {
	text = rewriteDottedFuncs(text)
	t := template.New(name).Option("missingkey=" + normalizeMissing(a.missingKey)).Delims(a.leftDelim, a.rightDelim).Funcs(a.funcs())
	for _, spec := range a.templates {
		tname, path := parseTemplateSpec(spec)
		data, err := os.ReadFile(path)
		if err != nil {
			return err
		}
		body := rewriteDottedFuncs(string(data))
		if !strings.Contains(body, "{{ define") && tname != "" {
			body = fmt.Sprintf("{{ define %q }}%s{{ end }}", tname, body)
		}
		if _, err := t.Parse(body); err != nil {
			return err
		}
	}
	t, err := t.Parse(text)
	if err != nil {
		return err
	}
	var buf bytes.Buffer
	if err := t.Execute(&buf, a.context); err != nil {
		return err
	}
	if outPath == "-" || outPath == "" {
		_, err = stdout.Write(buf.Bytes())
		return err
	}
	if err := os.MkdirAll(filepath.Dir(outPath), 0o755); err != nil {
		return err
	}
	return os.WriteFile(outPath, buf.Bytes(), 0o644)
}

func (a *app) funcs() template.FuncMap {
	return template.FuncMap{
		"getenv": getenvFunc, "env_Getenv": getenvFunc, "env_HasEnv": hasEnv, "env_Env": envMap, "env_ExpandEnv": expandEnv,
		"add": add, "math_Add": add, "mul": mul, "math_Mul": mul, "div": div, "math_Div": div, "seq": seq, "math_Seq": seq,
		"math_Abs": abs, "math_Ceil": ceil, "math_Floor": floor,
		"default": defaultFunc, "conv_Default": defaultFunc, "bool": boolFunc, "join": join, "conv_Join": join,
		"dict": dict, "coll_Dict": dict, "slice": sliceAny, "coll_Slice": sliceAny, "has": has, "coll_Has": has,
		"json": parseJSON, "data_JSON": parseJSON, "toJSON": toJSON, "data_ToJSON": toJSON, "toYAML": toYAML, "data_ToYAML": toYAML,
		"ds": a.datasource, "datasource": a.datasource, "datasourceExists": a.datasourceExists, "listDatasources": a.listDatasources, "include": a.include,
		"file_Exists": fileExists, "file_IsDir": fileIsDir, "file_Read": fileRead, "file_ReadDir": fileReadDir, "file_Stat": os.Stat,
		"strings_Contains": strings.Contains, "strings_HasPrefix": strings.HasPrefix, "strings_HasSuffix": strings.HasSuffix,
		"strings_ToUpper": strings.ToUpper, "strings_ToLower": strings.ToLower, "strings_Title": strings.Title,
		"strings_ReplaceAll": strings.ReplaceAll, "strings_TrimSpace": strings.TrimSpace, "indent": indent, "strings_Indent": indent,
		"tmpl_Path": func() string { return a.tmplPath }, "tmpl_PathDir": func() string { return filepath.Dir(a.tmplPath) },
		"urlParse": url.Parse, "conv_URL": url.Parse,
	}
}

func rewriteDottedFuncs(s string) string {
	repl := strings.NewReplacer(
		"env.Getenv", "env_Getenv", "env.HasEnv", "env_HasEnv", "env.Env", "env_Env", "env.ExpandEnv", "env_ExpandEnv",
		"math.Add", "math_Add", "math.Mul", "math_Mul", "math.Div", "math_Div", "math.Seq", "math_Seq", "math.Abs", "math_Abs", "math.Ceil", "math_Ceil", "math.Floor", "math_Floor",
		"conv.Default", "conv_Default", "conv.Join", "conv_Join", "conv.URL", "conv_URL",
		"coll.Dict", "coll_Dict", "coll.Slice", "coll_Slice", "coll.Has", "coll_Has",
		"data.JSON", "data_JSON", "data.ToJSON", "data_ToJSON", "data.ToYAML", "data_ToYAML",
		"file.Exists", "file_Exists", "file.IsDir", "file_IsDir", "file.ReadDir", "file_ReadDir", "file.Read", "file_Read", "file.Stat", "file_Stat",
		"strings.Contains", "strings_Contains", "strings.HasPrefix", "strings_HasPrefix", "strings.HasSuffix", "strings_HasSuffix",
		"strings.ToUpper", "strings_ToUpper", "strings.ToLower", "strings_ToLower", "strings.Title", "strings_Title", "strings.ReplaceAll", "strings_ReplaceAll", "strings.TrimSpace", "strings_TrimSpace", "strings.Indent", "strings_Indent",
		"tmpl.PathDir", "tmpl_PathDir", "tmpl.Path", "tmpl_Path",
	)
	return repl.Replace(s)
}

func baseContext() map[string]any {
	return map[string]any{"Env": envMap()}
}

func parseSourceSpec(spec string) (string, string) {
	if strings.Contains(spec, "=") {
		parts := strings.SplitN(spec, "=", 2)
		return parts[0], parts[1]
	}
	base := filepath.Base(spec)
	ext := filepath.Ext(base)
	return strings.TrimSuffix(base, ext), spec
}

func parseTemplateSpec(spec string) (string, string) {
	if strings.Contains(spec, "=") {
		parts := strings.SplitN(spec, "=", 2)
		return parts[0], parts[1]
	}
	base := filepath.Base(spec)
	return strings.TrimSuffix(base, filepath.Ext(base)), spec
}

func (a *app) datasource(alias string, subpath ...string) (any, error) {
	target, ok := a.datasources[alias]
	if !ok && looksLikeSource(alias) {
		target = alias
		ok = true
	}
	if !ok {
		return nil, fmt.Errorf("datasource %q not defined", alias)
	}
	sp := ""
	if len(subpath) > 0 {
		sp = subpath[0]
	}
	return a.loadSource(target, sp)
}

func (a *app) include(alias string, subpath ...string) (string, error) {
	target, ok := a.datasources[alias]
	if !ok {
		target = alias
	}
	if len(subpath) > 0 {
		target = joinSourcePath(target, subpath[0])
	}
	data, err := readSourceBytes(target)
	if err != nil {
		return "", err
	}
	return string(data), nil
}

func (a *app) datasourceExists(alias string) bool {
	_, ok := a.datasources[alias]
	return ok
}

func (a *app) listDatasources() []string {
	keys := make([]string, 0, len(a.datasources))
	for k := range a.datasources {
		keys = append(keys, k)
	}
	sort.Strings(keys)
	return keys
}

func (a *app) loadSource(target, subpath string) (any, error) {
	if subpath != "" {
		target = joinSourcePath(target, subpath)
	}
	if strings.HasPrefix(target, "env://") {
		name := strings.TrimPrefix(target, "env://")
		name = strings.TrimPrefix(name, "/")
		return os.Getenv(name), nil
	}
	data, err := readSourceBytes(target)
	if err != nil {
		return nil, err
	}
	ext := strings.ToLower(filepath.Ext(strings.Split(target, "?")[0]))
	switch ext {
	case ".json":
		return parseJSON(string(data))
	case ".yaml", ".yml":
		return parseYAML(string(data)), nil
	case ".csv":
		return csv.NewReader(strings.NewReader(string(data))).ReadAll()
	case ".env":
		return parseEnvFile(string(data)), nil
	default:
		trim := strings.TrimSpace(string(data))
		if strings.HasPrefix(trim, "{") || strings.HasPrefix(trim, "[") {
			return parseJSON(trim)
		}
		return string(data), nil
	}
}

func readSourceBytes(target string) ([]byte, error) {
	if strings.HasPrefix(target, "file://") {
		u, err := url.Parse(target)
		if err != nil {
			return nil, err
		}
		return os.ReadFile(u.Path)
	}
	if target == "-" || target == "stdin:" || target == "stdin://" {
		return io.ReadAll(os.Stdin)
	}
	return os.ReadFile(target)
}

func joinSourcePath(target, sub string) string {
	if strings.HasPrefix(target, "file://") {
		return strings.TrimRight(target, "/") + "/" + strings.TrimLeft(sub, "/")
	}
	return filepath.Join(target, sub)
}

func looksLikeSource(s string) bool {
	return strings.Contains(s, "://") || strings.HasPrefix(s, ".") || strings.Contains(s, "/")
}

func envMap() map[string]string {
	m := map[string]string{}
	for _, kv := range os.Environ() {
		parts := strings.SplitN(kv, "=", 2)
		m[parts[0]] = parts[1]
	}
	return m
}

func getenvFunc(key string, def ...string) string {
	if v, ok := os.LookupEnv(key); ok {
		return v
	}
	if p, ok := os.LookupEnv(key + "_FILE"); ok {
		if b, err := os.ReadFile(p); err == nil {
			return string(bytes.TrimRight(b, "\r\n"))
		}
	}
	if len(def) > 0 {
		return def[0]
	}
	return ""
}

func hasEnv(key string) bool { _, ok := os.LookupEnv(key); return ok }
func expandEnv(s string) string {
	return os.Expand(s, func(k string) string { return getenvFunc(k) })
}
func getenvDefault(k, d string) string {
	if v := os.Getenv(k); v != "" {
		return v
	}
	return d
}

func parseJSON(s string) (any, error) {
	var v any
	dec := json.NewDecoder(strings.NewReader(s))
	dec.UseNumber()
	if err := dec.Decode(&v); err != nil {
		return nil, err
	}
	return normalizeJSON(v), nil
}

func normalizeJSON(v any) any {
	switch x := v.(type) {
	case map[string]any:
		for k, v := range x {
			x[k] = normalizeJSON(v)
		}
		return x
	case []any:
		for i, v := range x {
			x[i] = normalizeJSON(v)
		}
		return x
	case json.Number:
		if strings.ContainsAny(string(x), ".eE") {
			f, _ := x.Float64()
			return f
		}
		i, _ := x.Int64()
		return i
	default:
		return v
	}
}

func parseYAML(s string) map[string]any {
	root := map[string]any{}
	type frame struct {
		indent int
		m      map[string]any
	}
	stack := []frame{{-1, root}}
	for _, line := range strings.Split(s, "\n") {
		if strings.TrimSpace(line) == "" || strings.HasPrefix(strings.TrimSpace(line), "#") {
			continue
		}
		indent := len(line) - len(strings.TrimLeft(line, " "))
		trim := strings.TrimSpace(line)
		parts := strings.SplitN(trim, ":", 2)
		if len(parts) != 2 {
			continue
		}
		for len(stack) > 1 && indent <= stack[len(stack)-1].indent {
			stack = stack[:len(stack)-1]
		}
		key := strings.TrimSpace(parts[0])
		val := strings.TrimSpace(parts[1])
		cur := stack[len(stack)-1].m
		if val == "" {
			child := map[string]any{}
			cur[key] = child
			stack = append(stack, frame{indent, child})
		} else {
			cur[key] = parseScalar(val)
		}
	}
	return root
}

func parseScalar(s string) any {
	s = strings.Trim(s, `"'`)
	if i, err := strconv.ParseInt(s, 0, 64); err == nil {
		return i
	}
	if f, err := strconv.ParseFloat(s, 64); err == nil && strings.ContainsAny(s, ".eE") {
		return f
	}
	if s == "true" {
		return true
	}
	if s == "false" {
		return false
	}
	return s
}

func parseEnvFile(s string) map[string]string {
	m := map[string]string{}
	for _, line := range strings.Split(s, "\n") {
		line = strings.TrimSpace(line)
		if line == "" || strings.HasPrefix(line, "#") {
			continue
		}
		line = strings.TrimPrefix(line, "export ")
		parts := strings.SplitN(line, "=", 2)
		if len(parts) == 2 {
			m[strings.TrimSpace(parts[0])] = strings.Trim(strings.TrimSpace(parts[1]), `"'`)
		}
	}
	return m
}

func toJSON(v any) (string, error) {
	b, err := json.Marshal(v)
	return string(b), err
}

func toYAML(v any) string {
	var b strings.Builder
	writeYAML(&b, v, 0)
	return b.String()
}

func writeYAML(b *strings.Builder, v any, indent int) {
	pad := strings.Repeat(" ", indent)
	switch x := v.(type) {
	case map[string]any:
		keys := make([]string, 0, len(x))
		for k := range x {
			keys = append(keys, k)
		}
		sort.Strings(keys)
		for _, k := range keys {
			switch x[k].(type) {
			case map[string]any, []any:
				fmt.Fprintf(b, "%s%s:\n", pad, k)
				writeYAML(b, x[k], indent+2)
			default:
				fmt.Fprintf(b, "%s%s: %v\n", pad, k, x[k])
			}
		}
	case []any:
		for _, item := range x {
			fmt.Fprintf(b, "%s- %v\n", pad, item)
		}
	default:
		fmt.Fprintf(b, "%s%v\n", pad, x)
	}
}

func number(v any) (float64, bool) {
	switch x := v.(type) {
	case int:
		return float64(x), false
	case int64:
		return float64(x), false
	case float64:
		return x, true
	case string:
		if i, err := strconv.ParseInt(x, 0, 64); err == nil && !strings.ContainsAny(x, ".eE") {
			return float64(i), false
		}
		f, _ := strconv.ParseFloat(x, 64)
		return f, true
	default:
		r := reflect.ValueOf(v)
		if r.IsValid() {
			switch r.Kind() {
			case reflect.Int, reflect.Int8, reflect.Int16, reflect.Int32, reflect.Int64:
				return float64(r.Int()), false
			case reflect.Float32, reflect.Float64:
				return r.Float(), true
			}
		}
	}
	return 0, false
}

func add(vals ...any) any {
	var sum float64
	isFloat := false
	for _, v := range vals {
		n, f := number(v)
		sum += n
		isFloat = isFloat || f
	}
	if isFloat {
		return sum
	}
	return int64(sum)
}

func mul(vals ...any) any {
	prod := float64(1)
	isFloat := false
	for _, v := range vals {
		n, f := number(v)
		prod *= n
		isFloat = isFloat || f
	}
	if isFloat {
		return prod
	}
	return int64(prod)
}

func div(a, b any) (float64, error) {
	x, _ := number(a)
	y, _ := number(b)
	if y == 0 {
		return 0, errors.New("division by zero")
	}
	return x / y, nil
}

func seq(start, end int64, stepOpt ...int64) []int64 {
	step := int64(1)
	if len(stepOpt) > 0 {
		step = stepOpt[0]
	}
	if step == 0 {
		return []int64{}
	}
	if end < start && step > 0 {
		step = -step
	}
	if end > start && step < 0 {
		step = -step
	}
	end -= (end - start) % step
	out := []int64{start}
	for out[len(out)-1] != end {
		out = append(out, out[len(out)-1]+step)
	}
	return out
}

func abs(v any) any {
	n, f := number(v)
	if f {
		return math.Abs(n)
	}
	if n < 0 {
		n = -n
	}
	return int64(n)
}
func ceil(v any) float64  { n, _ := number(v); return math.Ceil(n) }
func floor(v any) float64 { n, _ := number(v); return math.Floor(n) }

func defaultFunc(def, in any) any {
	if isEmpty(in) {
		return def
	}
	return in
}

func isEmpty(v any) bool {
	if v == nil {
		return true
	}
	r := reflect.ValueOf(v)
	switch r.Kind() {
	case reflect.String, reflect.Array, reflect.Slice, reflect.Map:
		return r.Len() == 0
	case reflect.Bool:
		return !r.Bool()
	case reflect.Int, reflect.Int8, reflect.Int16, reflect.Int32, reflect.Int64:
		return r.Int() == 0
	case reflect.Uint, reflect.Uint8, reflect.Uint16, reflect.Uint32, reflect.Uint64:
		return r.Uint() == 0
	case reflect.Float32, reflect.Float64:
		return r.Float() == 0
	}
	return false
}

func boolFunc(v any) bool {
	s := strings.ToLower(fmt.Sprint(v))
	return s == "true" || s == "1" || s == "yes" || s == "y" || s == "on"
}

func join(a any, b any) string {
	in, sep := a, fmt.Sprint(b)
	if isList(b) && !isList(a) {
		in, sep = b, fmt.Sprint(a)
	}
	r := reflect.ValueOf(in)
	if r.Kind() != reflect.Slice && r.Kind() != reflect.Array {
		return fmt.Sprint(in)
	}
	parts := make([]string, r.Len())
	for i := 0; i < r.Len(); i++ {
		parts[i] = fmt.Sprint(r.Index(i).Interface())
	}
	return strings.Join(parts, sep)
}

func isList(v any) bool {
	if v == nil {
		return false
	}
	k := reflect.ValueOf(v).Kind()
	return k == reflect.Slice || k == reflect.Array
}

func dict(vals ...any) map[string]any {
	m := map[string]any{}
	for i := 0; i < len(vals); i += 2 {
		key := fmt.Sprint(vals[i])
		val := any("")
		if i+1 < len(vals) {
			val = vals[i+1]
		}
		m[key] = val
	}
	return m
}

func sliceAny(vals ...any) []any { return vals }

func has(in, item any) bool {
	r := reflect.ValueOf(in)
	switch r.Kind() {
	case reflect.Map:
		return r.MapIndex(reflect.ValueOf(fmt.Sprint(item))).IsValid()
	case reflect.Slice, reflect.Array:
		for i := 0; i < r.Len(); i++ {
			if reflect.DeepEqual(r.Index(i).Interface(), item) {
				return true
			}
		}
	}
	return false
}

func fileExists(path string) bool { _, err := os.Stat(path); return err == nil }
func fileIsDir(path string) bool {
	st, err := os.Stat(path)
	return err == nil && st.IsDir()
}
func fileRead(path string) (string, error) {
	b, err := os.ReadFile(path)
	return string(b), err
}
func fileReadDir(path string) ([]string, error) {
	ents, err := os.ReadDir(path)
	if err != nil {
		return nil, err
	}
	names := make([]string, len(ents))
	for i, e := range ents {
		names[i] = e.Name()
	}
	sort.Strings(names)
	return names, nil
}
func fileMode(path string) os.FileMode {
	if st, err := os.Stat(path); err == nil {
		return st.Mode()
	}
	return 0o644
}

func indent(args ...any) (string, error) {
	if len(args) == 0 {
		return "", nil
	}
	input := fmt.Sprint(args[len(args)-1])
	prefix := " "
	if len(args) == 2 {
		prefix = fmt.Sprint(args[0])
	} else if len(args) >= 3 {
		n, _ := strconv.Atoi(fmt.Sprint(args[0]))
		prefix = strings.Repeat(fmt.Sprint(args[1]), n)
	}
	lines := strings.Split(input, "\n")
	for i := range lines {
		if lines[i] != "" {
			lines[i] = prefix + lines[i]
		}
	}
	return strings.Join(lines, "\n"), nil
}

func matchesAny(rel, base string, patterns []string) bool {
	for _, p := range patterns {
		if ok, _ := filepath.Match(p, rel); ok {
			return true
		}
		if ok, _ := filepath.Match(p, base); ok {
			return true
		}
	}
	return false
}

func normalizeMissing(v string) string {
	switch v {
	case "default", "invalid":
		return "default"
	case "zero":
		return "zero"
	default:
		return "error"
	}
}

const helpText = `Process text files with Go templates

Usage:
  gomplate [flags]

Flags:
  -d, --datasource datasource        datasource in alias=URL form. Specify multiple times to add multiple sources.
  -c, --context datasource           pre-load a datasource into the context, in alias=URL form. Use the special alias '.' to set the root context.
  -f, --file file                    Template file to process. Omit to use standard input, or use --in or --input-dir (default [-])
  -i, --in string                    Template string to process (alternative to --file and --input-dir)
      --input-dir directory          directory which is examined recursively for templates (alternative to --file and --in)
  -o, --out file                     output file name. Omit to use standard output. (default [-])
  -h, --help                         help for gomplate
  -v, --version                      version for gomplate
`
