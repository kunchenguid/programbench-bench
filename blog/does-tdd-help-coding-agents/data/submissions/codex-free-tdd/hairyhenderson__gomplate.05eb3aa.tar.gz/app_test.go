package main

import (
	"os"
	"path/filepath"
	"strings"
	"testing"
)

func TestInlineTemplateEnvAndMath(t *testing.T) {
	t.Setenv("USER", "alice")
	var out, errOut strings.Builder
	code := run([]string{"-i", `Hello, {{ .Env.USER }} {{ env.Getenv "USER" }} {{ getenv "NONE" "def" }} {{ add 1 2 3 }} {{ mul 6 7 }} {{ div 3 2 }} {{ seq 1 3 }}`}, nil, &out, &errOut)
	if code != 0 {
		t.Fatalf("exit %d stderr %q", code, errOut.String())
	}
	want := "Hello, alice alice def 6 42 1.5 [1 2 3]"
	if out.String() != want {
		t.Fatalf("out = %q, want %q", out.String(), want)
	}
}

func TestDatasourceAndContextFiles(t *testing.T) {
	dir := t.TempDir()
	mustWrite(t, filepath.Join(dir, "person.json"), `{"foo":{"bar":7},"name":"Dave"}`)
	mustWrite(t, filepath.Join(dir, "config.yaml"), "x: 9\ny:\n  z: hi\n")
	oldwd, _ := os.Getwd()
	defer os.Chdir(oldwd)
	if err := os.Chdir(dir); err != nil {
		t.Fatal(err)
	}
	var out, errOut strings.Builder
	code := run([]string{"-d", "person.json", "-c", "cfg=config.yaml", "-i", `{{ (ds "person").name }} {{ (datasource "person").foo.bar }} {{ .cfg.x }} {{ .cfg.y.z }}`}, nil, &out, &errOut)
	if code != 0 {
		t.Fatalf("exit %d stderr %q", code, errOut.String())
	}
	if out.String() != "Dave 7 9 hi" {
		t.Fatalf("out = %q", out.String())
	}
}

func TestFileOutputAndMissingKey(t *testing.T) {
	dir := t.TempDir()
	in := filepath.Join(dir, "in.t")
	outPath := filepath.Join(dir, "out.txt")
	mustWrite(t, in, `Hi {{ .name | default "Alex" }}`)
	var out, errOut strings.Builder
	code := run([]string{"--missing-key", "zero", "-f", in, "-o", outPath}, nil, &out, &errOut)
	if code != 0 {
		t.Fatalf("exit %d stderr %q", code, errOut.String())
	}
	got, err := os.ReadFile(outPath)
	if err != nil {
		t.Fatal(err)
	}
	if string(got) != "Hi Alex" {
		t.Fatalf("file = %q", string(got))
	}
	if out.String() != "" {
		t.Fatalf("stdout = %q", out.String())
	}
}

func TestInputDirectoryCopiesAndRenders(t *testing.T) {
	dir := t.TempDir()
	inDir := filepath.Join(dir, "src")
	outDir := filepath.Join(dir, "dst")
	if err := os.MkdirAll(filepath.Join(inDir, "sub"), 0o755); err != nil {
		t.Fatal(err)
	}
	mustWrite(t, filepath.Join(inDir, "a.txt"), `hi {{ getenv "X" }}`)
	mustWrite(t, filepath.Join(inDir, "sub", "b.bin"), "raw")
	t.Setenv("X", "Y")
	var out, errOut strings.Builder
	code := run([]string{"--input-dir", inDir, "--output-dir", outDir, "--exclude-processing", "*.bin"}, nil, &out, &errOut)
	if code != 0 {
		t.Fatalf("exit %d stderr %q", code, errOut.String())
	}
	assertFile(t, filepath.Join(outDir, "a.txt"), "hi Y")
	assertFile(t, filepath.Join(outDir, "sub", "b.bin"), "raw")
}

func TestStdinDelimitersAndHelperFunctions(t *testing.T) {
	dir := t.TempDir()
	dataPath := filepath.Join(dir, "data.json")
	textPath := filepath.Join(dir, "note.txt")
	mustWrite(t, dataPath, `{"name":"Dave","items":["a","b"]}`)
	mustWrite(t, textPath, "hello\n")
	oldwd, _ := os.Getwd()
	defer os.Chdir(oldwd)
	if err := os.Chdir(dir); err != nil {
		t.Fatal(err)
	}
	input := `Hi << strings.ToUpper ((ds "data").name) >> << join ((ds "data").items) "," >> << if file.Exists "note.txt" >><< file.Read "note.txt" | strings.TrimSpace >><< end >> << listDatasources | join ":" >>`
	var out, errOut strings.Builder
	code := run([]string{"--left-delim", "<<", "--right-delim", ">>", "-d", "data.json"}, strings.NewReader(input), &out, &errOut)
	if code != 0 {
		t.Fatalf("exit %d stderr %q", code, errOut.String())
	}
	want := "Hi DAVE a,b hello data"
	if out.String() != want {
		t.Fatalf("out = %q, want %q", out.String(), want)
	}
}

func TestEnvNamespaceAndExternalTemplate(t *testing.T) {
	dir := t.TempDir()
	tpl := filepath.Join(dir, "greet.t")
	mustWrite(t, tpl, `{{ define "greet" }}Hello {{ . }}{{ end }}`)
	t.Setenv("USER", "carol")
	var out, errOut strings.Builder
	code := run([]string{"-t", "greet=" + tpl, "-i", `{{ env.Env.USER }} {{ template "greet" "world" }}`}, nil, &out, &errOut)
	if code != 0 {
		t.Fatalf("exit %d stderr %q", code, errOut.String())
	}
	if out.String() != "carol Hello world" {
		t.Fatalf("out = %q", out.String())
	}
}

func TestInputDirectoryExcludeAndInclude(t *testing.T) {
	dir := t.TempDir()
	inDir := filepath.Join(dir, "src")
	outDir := filepath.Join(dir, "dst")
	if err := os.MkdirAll(inDir, 0o755); err != nil {
		t.Fatal(err)
	}
	mustWrite(t, filepath.Join(inDir, "a.tmpl"), `A{{ getenv "X" }}`)
	mustWrite(t, filepath.Join(inDir, "b.txt"), `B{{ getenv "X" }}`)
	mustWrite(t, filepath.Join(inDir, "skip.tmpl"), `S{{ getenv "X" }}`)
	t.Setenv("X", "1")
	var out, errOut strings.Builder
	code := run([]string{"--input-dir", inDir, "--output-dir", outDir, "--include", "*.tmpl", "--exclude", "skip.tmpl"}, nil, &out, &errOut)
	if code != 0 {
		t.Fatalf("exit %d stderr %q", code, errOut.String())
	}
	assertFile(t, filepath.Join(outDir, "a.tmpl"), "A1")
	if _, err := os.Stat(filepath.Join(outDir, "b.txt")); !os.IsNotExist(err) {
		t.Fatalf("b.txt should not be written, stat err=%v", err)
	}
	if _, err := os.Stat(filepath.Join(outDir, "skip.tmpl")); !os.IsNotExist(err) {
		t.Fatalf("skip.tmpl should not be written, stat err=%v", err)
	}
}

func mustWrite(t *testing.T, path, content string) {
	t.Helper()
	if err := os.WriteFile(path, []byte(content), 0o644); err != nil {
		t.Fatal(err)
	}
}

func assertFile(t *testing.T, path, want string) {
	t.Helper()
	got, err := os.ReadFile(path)
	if err != nil {
		t.Fatal(err)
	}
	if string(got) != want {
		t.Fatalf("%s = %q, want %q", path, string(got), want)
	}
}
