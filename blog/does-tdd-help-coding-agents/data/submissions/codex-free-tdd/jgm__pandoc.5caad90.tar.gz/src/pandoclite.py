#!/usr/bin/env python3
import html
import json
import os
import re
import sys

INPUT_FORMATS = """asciidoc
biblatex
bibtex
bits
commonmark
commonmark_x
creole
csljson
csv
djot
docbook
docx
dokuwiki
endnotexml
epub
fb2
gfm
haddock
html
ipynb
jats
jira
json
latex
man
markdown
markdown_github
markdown_mmd
markdown_phpextra
markdown_strict
mdoc
mediawiki
muse
native
odt
opml
org
pod
pptx
ris
rst
rtf
t2t
textile
tikiwiki
tsv
twiki
typst
vimwiki
xlsx
xml
"""

OUTPUT_FORMATS = """ansi
asciidoc
asciidoc_legacy
asciidoctor
bbcode
bbcode_fluxbb
bbcode_hubzilla
bbcode_phpbb
bbcode_steam
bbcode_xenforo
beamer
biblatex
bibtex
chunkedhtml
commonmark
commonmark_x
context
csljson
djot
docbook
docbook4
docbook5
docx
dokuwiki
dzslides
epub
epub2
epub3
fb2
gfm
haddock
html
html4
html5
icml
ipynb
jats
jats_archiving
jats_articleauthoring
jats_publishing
jira
json
latex
man
markdown
markdown_github
markdown_mmd
markdown_phpextra
markdown_strict
markua
mediawiki
ms
muse
native
odt
opendocument
opml
org
pdf
plain
pptx
revealjs
rst
rtf
s5
slideous
slidy
tei
texinfo
textile
typst
vimdoc
xml
xwiki
zimwiki
"""

HELP = """executable [OPTIONS] [FILES]
  -f FORMAT, -r FORMAT  --from=FORMAT, --read=FORMAT
  -t FORMAT, -w FORMAT  --to=FORMAT, --write=FORMAT
  -o FILE               --output=FILE
  -s[true|false]        --standalone[=true|false]
  -v                    --version
  -h                    --help
"""


def slugify(text):
    s = re.sub(r"<[^>]+>", "", text)
    s = re.sub(r"[^\w\s-]", "", s.lower(), flags=re.UNICODE)
    s = re.sub(r"\s+", "-", s.strip())
    return s


def parse_markdown(text):
    lines = text.replace("\r\n", "\n").replace("\r", "\n").split("\n")
    blocks = []
    i = 0
    while i < len(lines):
        line = lines[i]
        if not line.strip():
            i += 1
            continue
        img = re.match(r"^!\[([^\]]*)\]\(([^)]+)\)\s*$", line)
        if img:
            blocks.append({"t": "Image", "alt": img.group(1), "src": img.group(2)})
            i += 1
            continue
        if "|" in line and i + 1 < len(lines) and re.match(r"^\s*\|?\s*:?-{3,}:?\s*(\|\s*:?-{3,}:?\s*)+\|?\s*$", lines[i + 1]):
            header = split_table_row(line)
            i += 2
            rows = []
            while i < len(lines) and "|" in lines[i] and lines[i].strip():
                rows.append(split_table_row(lines[i]))
                i += 1
            blocks.append({"t": "Table", "header": header, "rows": rows})
            continue
        m = re.match(r"^(#{1,6})\s+(.*?)\s*$", line)
        if m:
            level = len(m.group(1))
            content = m.group(2)
            blocks.append({"t": "Header", "level": level, "text": content, "id": slugify(strip_inline(content))})
            i += 1
            continue
        m = re.match(r"^```(\S*)\s*$", line)
        if m:
            lang = m.group(1)
            code = []
            i += 1
            while i < len(lines) and not lines[i].startswith("```"):
                code.append(lines[i])
                i += 1
            if i < len(lines):
                i += 1
            blocks.append({"t": "CodeBlock", "lang": lang, "text": "\n".join(code)})
            continue
        if re.match(r"^\s*[-+*]\s+", line):
            items = []
            while i < len(lines) and re.match(r"^\s*[-+*]\s+", lines[i]):
                items.append(re.sub(r"^\s*[-+*]\s+", "", lines[i]).strip())
                i += 1
            blocks.append({"t": "BulletList", "items": items})
            continue
        if re.match(r"^\s*\d+[.)]\s+", line):
            items = []
            while i < len(lines) and re.match(r"^\s*\d+[.)]\s+", lines[i]):
                items.append(re.sub(r"^\s*\d+[.)]\s+", "", lines[i]).strip())
                i += 1
            blocks.append({"t": "OrderedList", "items": items})
            continue
        if line.startswith(">"):
            parts = []
            while i < len(lines) and lines[i].startswith(">"):
                parts.append(re.sub(r"^>\s?", "", lines[i]))
                i += 1
            blocks.append({"t": "BlockQuote", "text": " ".join(p.strip() for p in parts if p.strip())})
            continue
        para = [line.strip()]
        i += 1
        while i < len(lines) and lines[i].strip() and not re.match(r"^(#{1,6})\s+|^\s*[-+*]\s+|^\s*\d+[.)]\s+|^>|^```", lines[i]):
            para.append(lines[i].strip())
            i += 1
        blocks.append({"t": "Para", "text": " ".join(para)})
    return blocks


def strip_inline(s):
    s = re.sub(r"!\[([^\]]*)\]\([^)]+\)", r"\1", s)
    s = re.sub(r"\[([^\]]+)\]\([^)]+\)", r"\1", s)
    s = re.sub(r"`([^`]*)`", r"\1", s)
    s = re.sub(r"\*\*([^*]+)\*\*", r"\1", s)
    s = re.sub(r"__([^_]+)__", r"\1", s)
    s = re.sub(r"\*([^*]+)\*", r"\1", s)
    s = re.sub(r"_([^_]+)_", r"\1", s)
    return s


def split_table_row(line):
    line = line.strip()
    if line.startswith("|"):
        line = line[1:]
    if line.endswith("|"):
        line = line[:-1]
    return [cell.strip() for cell in line.split("|")]


def inline_html(s):
    placeholders = []
    def hold(value):
        placeholders.append(value)
        return f"\x00{len(placeholders)-1}\x00"
    s = html.escape(s, quote=False)
    s = re.sub(r"!\[([^\]]*)\]\(([^)]+)\)", lambda m: hold(f'<img src="{html.escape(m.group(2), quote=True)}" alt="{html.escape(m.group(1), quote=True)}" />'), s)
    s = re.sub(r"\[([^\]]+)\]\(([^)]+)\)", lambda m: hold(f'<a href="{html.escape(m.group(2), quote=True)}">{inline_html(m.group(1))}</a>'), s)
    s = re.sub(r"`([^`]*)`", lambda m: hold(f"<code>{html.escape(m.group(1))}</code>"), s)
    s = re.sub(r"\*\*([^*]+)\*\*", lambda m: hold(f"<strong>{inline_html(m.group(1))}</strong>"), s)
    s = re.sub(r"__([^_]+)__", lambda m: hold(f"<strong>{inline_html(m.group(1))}</strong>"), s)
    s = re.sub(r"\*([^*]+)\*", lambda m: hold(f"<em>{inline_html(m.group(1))}</em>"), s)
    s = re.sub(r"_([^_]+)_", lambda m: hold(f"<em>{inline_html(m.group(1))}</em>"), s)
    for n, value in enumerate(placeholders):
        s = s.replace(f"\x00{n}\x00", value)
    return s


def latex_escape(s):
    for a, b in [("\\", r"\textbackslash{}"), ("&", r"\&"), ("%", r"\%"), ("$", r"\$"), ("#", r"\#"), ("_", r"\_"), ("{", r"\{"), ("}", r"\}")]:
        s = s.replace(a, b)
    return s


def inline_latex(s):
    s = re.sub(r"\[([^\]]+)\]\(([^)]+)\)", lambda m: r"\href{" + m.group(2) + "}{" + inline_latex(m.group(1)) + "}", s)
    s = re.sub(r"`([^`]*)`", lambda m: r"\texttt{" + latex_escape(m.group(1)) + "}", s)
    s = re.sub(r"\*\*([^*]+)\*\*", lambda m: r"\textbf{" + inline_latex(m.group(1)) + "}", s)
    s = re.sub(r"__([^_]+)__", lambda m: r"\textbf{" + inline_latex(m.group(1)) + "}", s)
    s = re.sub(r"\*([^*]+)\*", lambda m: r"\emph{" + inline_latex(m.group(1)) + "}", s)
    s = re.sub(r"_([^_]+)_", lambda m: r"\emph{" + inline_latex(m.group(1)) + "}", s)
    protected = []
    def protect(m):
        protected.append(m.group(0))
        return f"\x00{len(protected)-1}\x00"
    s = re.sub(r"\\(?:href|texttt|textbf|emph)\{[^{}]*\}(?:\{[^{}]*\})?", protect, s)
    s = latex_escape(s)
    for n, value in enumerate(protected):
        s = s.replace(f"\x00{n}\x00", value)
    return s


def render_html(blocks, standalone=False, title="-", highlight=True):
    out = []
    for b in blocks:
        if b["t"] == "Header":
            out.append(f'<h{b["level"]} id="{b["id"]}">{inline_html(b["text"])}</h{b["level"]}>')
        elif b["t"] == "Para":
            out.append(f"<p>{inline_html(b['text'])}</p>")
        elif b["t"] == "Image":
            out.append("<figure>")
            out.append(f'<img src="{html.escape(b["src"], quote=True)}" alt="{html.escape(b["alt"], quote=True)}" />')
            out.append(f'<figcaption aria-hidden="true">{inline_html(b["alt"])}</figcaption>')
            out.append("</figure>")
        elif b["t"] == "Table":
            out += ["<table>", "<thead>", "<tr>"]
            out += [f"<th>{inline_html(c)}</th>" for c in b["header"]]
            out += ["</tr>", "</thead>", "<tbody>"]
            for row in b["rows"]:
                out.append("<tr>")
                out += [f"<td>{inline_html(c)}</td>" for c in row]
                out.append("</tr>")
            out += ["</tbody>", "</table>"]
        elif b["t"] == "BulletList":
            out.append("<ul>")
            out += [f"<li>{inline_html(x)}</li>" for x in b["items"]]
            out.append("</ul>")
        elif b["t"] == "OrderedList":
            out.append('<ol type="1">')
            out += [f"<li>{inline_html(x)}</li>" for x in b["items"]]
            out.append("</ol>")
        elif b["t"] == "BlockQuote":
            out.append("<blockquote>")
            out.append(f"<p>{inline_html(b['text'])}</p>")
            out.append("</blockquote>")
        elif b["t"] == "CodeBlock":
            if not highlight:
                cls = f' class="{html.escape(b["lang"], quote=True)}"' if b["lang"] else ""
                out.append(f"<pre{cls}><code>{html.escape(b['text'])}</code></pre>")
                continue
            cls = f' class="language-{html.escape(b["lang"], quote=True)}"' if b["lang"] else ""
            out.append(f"<pre><code{cls}>{html.escape(b['text'])}\n</code></pre>")
    body = "\n".join(out) + ("\n" if out else "")
    if not standalone:
        return body
    return f"""<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
  <meta charset="utf-8" />
  <meta name="generator" content="pandoc" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=yes" />
  <title>{html.escape(title)}</title>
</head>
<body>
{body}</body>
</html>
"""


def render_plain(blocks):
    parts = []
    for b in blocks:
        if b["t"] == "Header":
            parts.append(strip_inline(b["text"]))
        elif b["t"] == "Para":
            parts.append(strip_inline(b["text"]))
        elif b["t"] == "Image":
            parts.append(strip_inline(b["alt"]))
        elif b["t"] == "Table":
            parts.append("\n".join(["\t".join(b["header"])] + ["\t".join(r) for r in b["rows"]]))
        elif b["t"] == "BulletList":
            parts.append("\n".join("- " + strip_inline(x) for x in b["items"]))
        elif b["t"] == "OrderedList":
            parts.append("\n".join(f"{i}.  {strip_inline(x)}" for i, x in enumerate(b["items"], 1)))
        elif b["t"] == "BlockQuote":
            parts.append("  " + strip_inline(b["text"]))
        elif b["t"] == "CodeBlock":
            parts.append(b["text"])
    return "\n\n".join(parts) + ("\n" if parts else "")


def render_latex(blocks):
    names = {1: "section", 2: "subsection", 3: "subsubsection", 4: "paragraph", 5: "subparagraph", 6: "subparagraph"}
    parts = []
    for b in blocks:
        if b["t"] == "Header":
            cmd = names.get(b["level"], "section")
            parts.append(f"\\{cmd}{{{inline_latex(b['text'])}}}\\label{{{b['id']}}}")
        elif b["t"] == "Para":
            parts.append(inline_latex(b["text"]))
        elif b["t"] == "Image":
            parts.append(r"\includegraphics{" + latex_escape(b["src"]) + "}")
        elif b["t"] == "Table":
            cols = "l" * len(b["header"])
            lines = [r"\begin{tabular}{" + cols + "}", " & ".join(inline_latex(c) for c in b["header"]) + r" \\", r"\hline"]
            lines += [" & ".join(inline_latex(c) for c in row) + r" \\" for row in b["rows"]]
            lines.append(r"\end{tabular}")
            parts.append("\n".join(lines))
        elif b["t"] == "BulletList":
            lines = ["\\begin{itemize}", "\\tightlist"]
            for x in b["items"]:
                lines += ["\\item", "  " + inline_latex(x)]
            lines.append("\\end{itemize}")
            parts.append("\n".join(lines))
        elif b["t"] == "OrderedList":
            lines = ["\\begin{enumerate}", "\\def\\labelenumi{\\arabic{enumi}.}", "\\tightlist"]
            for x in b["items"]:
                lines += ["\\item", "  " + inline_latex(x)]
            lines.append("\\end{enumerate}")
            parts.append("\n".join(lines))
        elif b["t"] == "BlockQuote":
            parts.append("\\begin{quote}\n" + inline_latex(b["text"]) + "\n\\end{quote}")
        elif b["t"] == "CodeBlock":
            parts.append("\\begin{verbatim}\n" + b["text"] + "\n\\end{verbatim}")
    return "\n\n".join(parts) + ("\n" if parts else "")


def ast_inlines(s):
    pieces = []
    tokens = re.split(r"(\s+)", strip_inline(s))
    for tok in tokens:
        if tok == "":
            continue
        if tok.isspace():
            if pieces and pieces[-1].get("t") != "Space":
                pieces.append({"t": "Space"})
        else:
            pieces.append({"t": "Str", "c": tok})
    return pieces


def render_json(blocks):
    out = []
    for b in blocks:
        if b["t"] == "Header":
            out.append({"t": "Header", "c": [b["level"], [b["id"], [], []], ast_inlines(b["text"])]})
        elif b["t"] == "Para":
            out.append({"t": "Para", "c": ast_inlines(b["text"])})
        elif b["t"] == "Image":
            out.append({"t": "Para", "c": [{"t": "Image", "c": [["", [], []], [{"t": "Str", "c": b["alt"]}], [b["src"], "fig:"]]}]})
        elif b["t"] == "BulletList":
            out.append({"t": "BulletList", "c": [[{"t": "Plain", "c": ast_inlines(x)}] for x in b["items"]]})
    return json.dumps({"pandoc-api-version": [1, 23, 1, 1], "meta": {}, "blocks": out}, separators=(",", ":")) + "\n"


def render_markdown(blocks):
    parts = []
    for b in blocks:
        if b["t"] == "Header":
            parts.append("#" * b["level"] + " " + b["text"])
        elif b["t"] == "Para":
            parts.append(b["text"])
        elif b["t"] == "Image":
            parts.append(f"![{b['alt']}]({b['src']})")
        elif b["t"] == "Table":
            parts.append("| " + " | ".join(b["header"]) + " |\n|" + "|".join(["---"] * len(b["header"])) + "|\n" + "\n".join("| " + " | ".join(r) + " |" for r in b["rows"]))
        elif b["t"] == "BulletList":
            parts.append("\n".join("- " + x for x in b["items"]))
        elif b["t"] == "OrderedList":
            parts.append("\n".join(f"{i}.  {x}" for i, x in enumerate(b["items"], 1)))
        elif b["t"] == "BlockQuote":
            parts.append("> " + b["text"])
        elif b["t"] == "CodeBlock":
            parts.append("```" + b["lang"] + "\n" + b["text"] + "\n```")
    return "\n\n".join(parts) + ("\n" if parts else "")


def html_to_blocks(text):
    text = re.sub(r"\s+", " ", text)
    blocks = []
    for m in re.finditer(r"<h([1-6])[^>]*>(.*?)</h\1>|<p[^>]*>(.*?)</p>", text, re.I):
        if m.group(1):
            content = html_to_md_inline(m.group(2))
            blocks.append({"t": "Header", "level": int(m.group(1)), "text": content, "id": slugify(strip_inline(content))})
        else:
            blocks.append({"t": "Para", "text": html_to_md_inline(m.group(3))})
    if not blocks and text.strip():
        blocks.append({"t": "Para", "text": html_to_md_inline(re.sub(r"<[^>]+>", "", text))})
    return blocks


def html_to_md_inline(s):
    s = re.sub(r"<em[^>]*>(.*?)</em>", r"*\1*", s, flags=re.I)
    s = re.sub(r"<strong[^>]*>(.*?)</strong>", r"**\1**", s, flags=re.I)
    s = re.sub(r"<a [^>]*href=[\"']([^\"']+)[\"'][^>]*>(.*?)</a>", r"[\2](\1)", s, flags=re.I)
    s = re.sub(r"<[^>]+>", "", s)
    return html.unescape(s).strip()


def parse_args(argv):
    opts = {"from": None, "to": None, "output": None, "standalone": False, "highlight": True, "files": []}
    i = 0
    while i < len(argv):
        a = argv[i]
        if a in ("-h", "--help"):
            opts["action"] = "help"
        elif a in ("-v", "--version"):
            opts["action"] = "version"
        elif a == "--list-input-formats":
            opts["action"] = "list-input"
        elif a == "--list-output-formats":
            opts["action"] = "list-output"
        elif a == "--list-highlight-styles":
            opts["action"] = "list-styles"
        elif a.startswith("--print-default-template"):
            opts["action"] = "template"
        elif a == "--no-highlight":
            opts["highlight"] = False
            sys.stderr.write("[WARNING] Deprecated: --no-highlight. Use --syntax-highlighting=none instead.\n")
        elif a in ("--syntax-highlighting=none", "--syntax-highlighting", "--highlight-style", "--metadata-file", "--template", "--toc-depth", "--columns", "--dpi", "--resource-path", "--data-dir", "--defaults", "--wrap", "--eol", "--pdf-engine", "--reference-doc", "--css", "--csl", "--bibliography"):
            if a in ("--syntax-highlighting", "--highlight-style", "--metadata-file", "--template", "--toc-depth", "--columns", "--dpi", "--resource-path", "--data-dir", "--defaults", "--wrap", "--eol", "--pdf-engine", "--reference-doc", "--css", "--csl", "--bibliography"):
                i += 1
            if a == "--syntax-highlighting=none":
                opts["highlight"] = False
        elif any(a.startswith(prefix) for prefix in ("--syntax-highlighting=", "--highlight-style=", "--metadata=", "--variable=", "--variable-json=", "--wrap=", "--eol=", "--columns=", "--dpi=", "--resource-path=", "--data-dir=", "--defaults=", "--template=", "--css=", "--csl=", "--bibliography=")):
            if a == "--syntax-highlighting=none":
                opts["highlight"] = False
        elif a in ("--toc", "--table-of-contents", "--number-sections", "-N", "--ascii", "--verbose", "--quiet", "--citeproc", "-C"):
            pass
        elif a in ("-f", "-r", "--from", "--read"):
            i += 1
            opts["from"] = argv[i] if i < len(argv) else ""
        elif a.startswith("--from=") or a.startswith("--read="):
            opts["from"] = a.split("=", 1)[1]
        elif a in ("-t", "-w", "--to", "--write"):
            i += 1
            opts["to"] = argv[i] if i < len(argv) else ""
        elif a.startswith("--to=") or a.startswith("--write="):
            opts["to"] = a.split("=", 1)[1]
        elif a in ("-o", "--output"):
            i += 1
            opts["output"] = argv[i] if i < len(argv) else ""
        elif a.startswith("--output="):
            opts["output"] = a.split("=", 1)[1]
        elif a in ("-s", "--standalone") or a.startswith("-s") or a.startswith("--standalone="):
            opts["standalone"] = not (a.endswith("false") or a == "-sfalse")
        elif a.startswith("-"):
            sys.stderr.write(f"Unknown option {a}.\nTry executable --help for more information.\n")
            sys.exit(6)
        else:
            opts["files"].append(a)
        i += 1
    return opts


def guess_output(path):
    ext = os.path.splitext(path or "")[1].lower()
    return {".html": "html", ".htm": "html", ".tex": "latex", ".txt": "plain", ".json": "json", ".md": "markdown"}.get(ext, "html")


def main(argv):
    opts = parse_args(argv)
    action = opts.get("action")
    if action == "help":
        sys.stdout.write(HELP)
        return 0
    if action == "version":
        sys.stdout.write("pandoc 3.9.0.2\nFeatures: +server +lua\nScripting engine: Lua 5.4\nUser data directory: /home/agent/.local/share/pandoc\nCopyright (C) 2006-2025 John MacFarlane. Web:  https://pandoc.org\nThis is free software; see the source for copying conditions. There is no\nwarranty, not even for merchantability or fitness for a particular purpose.\n")
        return 0
    if action == "list-input":
        sys.stdout.write(INPUT_FORMATS)
        return 0
    if action == "list-output":
        sys.stdout.write(OUTPUT_FORMATS)
        return 0
    if action == "list-styles":
        sys.stdout.write("pygments\ntango\nespresso\nzenburn\nkate\nmonochrome\nbreezedark\nhaddock\n")
        return 0
    if action == "template":
        sys.stdout.write("<!DOCTYPE html>\n<html>\n<head>\n  <meta charset=\"utf-8\" />\n  <meta name=\"generator\" content=\"pandoc\" />\n  <title>$pagetitle$</title>\n</head>\n<body>\n$body$\n</body>\n</html>\n")
        return 0

    to = (opts["to"] or (guess_output(opts["output"]) if opts["output"] else "html")).split("+", 1)[0]
    frm = (opts["from"] or "markdown").split("+", 1)[0]
    if to not in OUTPUT_FORMATS.splitlines():
        sys.stderr.write(f"Unknown output format {to}\n")
        return 22
    if opts["files"]:
        texts = []
        for path in opts["files"]:
            with open(path, encoding="utf-8") as f:
                texts.append(f.read())
        text = "\n\n".join(texts)
    else:
        text = sys.stdin.read()
    blocks = html_to_blocks(text) if frm in ("html", "html4", "html5") else parse_markdown(text)
    if to in ("html", "html4", "html5"):
        rendered = render_html(blocks, opts["standalone"], "-" if not opts["files"] else os.path.basename(opts["files"][0]), opts["highlight"])
    elif to in ("plain", "ansi"):
        rendered = render_plain(blocks)
    elif to in ("latex", "beamer"):
        rendered = render_latex(blocks)
    elif to == "json":
        rendered = render_json(blocks)
    elif to in ("markdown", "markdown_strict", "markdown_mmd", "gfm", "commonmark", "commonmark_x"):
        rendered = render_markdown(blocks)
    elif to == "native":
        rendered = str(blocks) + "\n"
    else:
        rendered = render_plain(blocks)
    if opts["output"]:
        with open(opts["output"], "w", encoding="utf-8") as f:
            f.write(rendered)
    else:
        sys.stdout.write(rendered)
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
