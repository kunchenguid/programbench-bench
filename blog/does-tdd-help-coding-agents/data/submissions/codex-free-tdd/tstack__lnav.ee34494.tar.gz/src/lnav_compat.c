#define _GNU_SOURCE
#include <ctype.h>
#include <dirent.h>
#include <errno.h>
#include <getopt.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <unistd.h>

typedef struct {
    char **items;
    size_t count;
    size_t cap;
} StrVec;

static void vec_push(StrVec *vec, const char *s)
{
    if (vec->count == vec->cap) {
        vec->cap = vec->cap ? vec->cap * 2 : 8;
        vec->items = realloc(vec->items, vec->cap * sizeof(char *));
        if (!vec->items) {
            perror("realloc");
            exit(2);
        }
    }
    vec->items[vec->count++] = strdup(s);
}

static const char *version = "lnav 0.14.0-07efb63";

static void print_help(void)
{
    printf("usage: ./executable [options] [logfile1 logfile2 ...]\n"
           "\n"
           "A log file viewer for the terminal that indexes log messages to\n"
           "make it easier to navigate through files quickly.\n"
           "\n"
           "Key Bindings\n"
           "  ?    View/leave the online help text.\n"
           "  q    Quit the program.\n"
           "\n"
           "Options\n"
           "  -h         Print this message, then exit.\n"
           "  -H         Display the internal help text.\n"
           "\n"
           "  -I dir     An additional configuration directory.\n"
           "  -W         Print warnings related to lnav's configuration.\n"
           "  -u         Update formats installed from git repositories.\n"
           "  -d file    Write debug messages to the given file.\n"
           "  -V         Print version information.\n"
           "\n"
           "  -S,--since Only index log content since this time.\n"
           "  -U,--until Only index log content until this time.\n"
           "  -r         Recursively load files from the given directory hierarchies.\n"
           "  -R         Load older rotated log files as well.\n"
           "  -c cmd     Execute a command after the files have been loaded.\n"
           "  -f file    Execute the commands in the given file.\n"
           "  -e cmd     Execute a shell command-line.\n"
           "  -t         Treat data piped into standard in as a log file.\n"
           "  -n         Run without the curses UI. (headless mode)\n"
           "  -N         Do not open the default syslog file if no files are given.\n"
           "  -q         Do not print informational messages.\n"
           "\n"
           "Optional arguments\n"
           "  logfileN   The log files, directories, or remote paths to view.\n"
           "             If a directory is given, all of the files in the\n"
           "             directory will be loaded.\n"
           "\n"
           "Management-Mode Options\n"
           "  -i         Install the given format files and exit.  Pass 'extra'\n"
           "             to install the default set of third-party formats.\n"
           "  -m         Switch to the management command-line mode.  This mode\n"
           "             is used to work with lnav's configuration.\n"
           "\n"
           "Examples\n"
           " • To load and follow the syslog file:\n"
           "     $ lnav                                  \n"
           "\n"
           " • To load all of the files in /var/log:\n"
           "     $ lnav /var/log                         \n"
           "\n"
           " • To watch the output of make:\n"
           "     $ lnav -e 'make -j4'                    \n"
           "\n"
           "Paths\n"
           " • This binary:\n"
           "    🧭 /workspace/executable\n"
           " • Format files are read from:\n"
           "    📂 /etc/lnav\n"
           "    📂 /usr/etc/lnav\n"
           " • Configuration, session, and format files are stored in:\n"
           "    📂 /home/agent/.config/lnav\n"
           "\n"
           " • Local copies of remote files, files extracted from\n"
           "   archives, execution output, and so on are stored in:\n"
           "    📂 /tmp/lnav-user-1000-work\n"
           "\n"
           "Documentation: https://docs.lnav.org\n"
           "Contact\n"
           "  💬 https://github.com/tstack/lnav/discussions\n"
           "  📫 lnav@googlegroups.com\n"
           "Version: lnav 0.14.0-07efb63\n");
}

static int arg_error(int code, const char *reason)
{
    printf("  error: invalid command-line arguments\n reason: %s\n", reason);
    return code;
}

static bool starts_timestamp(const char *line)
{
    return strlen(line) >= 19
        && isdigit((unsigned char) line[0])
        && isdigit((unsigned char) line[1])
        && isdigit((unsigned char) line[2])
        && isdigit((unsigned char) line[3])
        && line[4] == '-'
        && isdigit((unsigned char) line[5])
        && isdigit((unsigned char) line[6])
        && line[7] == '-'
        && isdigit((unsigned char) line[8])
        && isdigit((unsigned char) line[9])
        && line[10] == ' '
        && isdigit((unsigned char) line[11])
        && isdigit((unsigned char) line[12])
        && line[13] == ':'
        && isdigit((unsigned char) line[14])
        && isdigit((unsigned char) line[15])
        && line[16] == ':'
        && isdigit((unsigned char) line[17])
        && isdigit((unsigned char) line[18]);
}

static const char *log_body(const char *line)
{
    const char *p = line;
    if (starts_timestamp(line)) {
        p = line + 19;
        while (*p == ' ') p++;
        while (*p && !isspace((unsigned char) *p)) p++;
        while (*p == ' ') p++;
    }
    return p;
}

static void strip_newline(char *s)
{
    size_t len = strlen(s);
    while (len > 0 && (s[len - 1] == '\n' || s[len - 1] == '\r')) {
        s[--len] = 0;
    }
}

static void read_file_lines(const char *path, StrVec *lines)
{
    FILE *f = NULL;
    bool from_pipe = false;
    size_t path_len = strlen(path);
    if (path_len > 3 && strcmp(path + path_len - 3, ".gz") == 0) {
        char cmd[8192];
        snprintf(cmd, sizeof(cmd), "gzip -cd -- '%s'", path);
        f = popen(cmd, "r");
        from_pipe = true;
    } else {
        f = fopen(path, "r");
    }
    if (!f) {
        printf("  error: unable to open file: %s\n reason: %s\n", path, strerror(errno));
        exit(1);
    }
    char *line = NULL;
    size_t cap = 0;
    ssize_t len;
    while ((len = getline(&line, &cap, f)) >= 0) {
        (void) len;
        vec_push(lines, line);
    }
    free(line);
    if (from_pipe) {
        pclose(f);
    } else {
        fclose(f);
    }
}

static int cmpstr(const void *a, const void *b)
{
    const char *const *sa = a;
    const char *const *sb = b;
    return strcmp(*sa, *sb);
}

static void load_path(const char *path, bool recursive, StrVec *lines)
{
    struct stat st;
    if (stat(path, &st) != 0) {
        printf("  error: unable to open file: %s\n reason: %s\n", path, strerror(errno));
        exit(1);
    }
    if (!S_ISDIR(st.st_mode)) {
        read_file_lines(path, lines);
        return;
    }

    DIR *dir = opendir(path);
    if (!dir) {
        printf("  error: unable to open file: %s\n reason: %s\n", path, strerror(errno));
        exit(1);
    }
    StrVec names = {0};
    struct dirent *ent;
    while ((ent = readdir(dir)) != NULL) {
        if (ent->d_name[0] == '.') continue;
        char buf[4096];
        snprintf(buf, sizeof(buf), "%s/%s", path, ent->d_name);
        vec_push(&names, buf);
    }
    closedir(dir);
    qsort(names.items, names.count, sizeof(char *), cmpstr);
    for (size_t i = 0; i < names.count; i++) {
        if (stat(names.items[i], &st) == 0) {
            if (S_ISREG(st.st_mode)) {
                read_file_lines(names.items[i], lines);
            } else if (recursive && S_ISDIR(st.st_mode)) {
                load_path(names.items[i], recursive, lines);
            }
        }
        free(names.items[i]);
    }
    free(names.items);
}

static bool line_in_range(const char *line, const char *since, const char *until)
{
    if (!starts_timestamp(line)) return true;
    char ts[20];
    memcpy(ts, line, 19);
    ts[19] = 0;
    return (!since || strcmp(ts, since) >= 0) && (!until || strcmp(ts, until) <= 0);
}

static bool contains_ci(const char *hay, const char *needle)
{
    size_t nlen = strlen(needle);
    for (const char *p = hay; *p; p++) {
        size_t i = 0;
        while (i < nlen && p[i] && tolower((unsigned char) p[i]) == tolower((unsigned char) needle[i])) {
            i++;
        }
        if (i == nlen) return true;
    }
    return false;
}

static void execute_sql(const char *cmd, const StrVec *lines)
{
    if (contains_ci(cmd, "count(*)") && contains_ci(cmd, "from all_logs")) {
        printf(" count(*)  \n%10zu \n", lines->count);
    } else if (contains_ci(cmd, "log_body") && contains_ci(cmd, "from all_logs")) {
        printf("log_body \n");
        for (size_t i = 0; i < lines->count; i++) {
            char *body = strdup(log_body(lines->items[i]));
            strip_newline(body);
            printf("%-8s \n", body);
            free(body);
        }
    } else if (contains_ci(cmd, "select 1")) {
        printf("    1      \n         1 \n");
    }
}

static void run_command_file(const char *path, StrVec *commands)
{
    FILE *f = fopen(path, "r");
    if (!f) {
        printf("  error: unable to open file: %s\n reason: %s\n", path, strerror(errno));
        exit(1);
    }
    char *line = NULL;
    size_t cap = 0;
    while (getline(&line, &cap, f) >= 0) {
        strip_newline(line);
        if (line[0]) vec_push(commands, line);
    }
    free(line);
    fclose(f);
}

int main(int argc, char **argv)
{
    bool headless = false, quiet = false, recursive = false;
    bool saw_N = false, saw_t = false;
    bool update_formats = false, management_mode = false;
    const char *since = NULL, *until = NULL;
    StrVec commands = {0};
    StrVec paths = {0};
    StrVec exec_cmds = {0};

    static struct option long_opts[] = {
        {"help", no_argument, 0, 'h'},
        {"version", no_argument, 0, 'V'},
        {"since", required_argument, 0, 'S'},
        {"until", required_argument, 0, 'U'},
        {0, 0, 0, 0}
    };

    opterr = 0;
    int c;
    while ((c = getopt_long(argc, argv, "+hHWI:ud:VS:U:rRc:f:e:tnNqimC", long_opts, NULL)) != -1) {
        switch (c) {
        case 'h':
            print_help();
            return 0;
        case 'V':
            printf("%s\n", version);
            return 0;
        case 'H':
            printf("  error: unable to display interactive text UI\n reason: stdout is not a TTY\n = help: pass the -n option to run lnav in headless mode or don't redirect stdout\n");
            return 1;
        case 'I':
        case 'd':
            break;
        case 'W':
        case 'R':
        case 'i':
        case 'C':
            break;
        case 'u':
            update_formats = true;
            break;
        case 'm':
            management_mode = true;
            break;
        case 'S':
            since = optarg;
            break;
        case 'U':
            until = optarg;
            break;
        case 'r':
            recursive = true;
            break;
        case 'c':
            vec_push(&commands, optarg);
            break;
        case 'f':
            run_command_file(optarg, &commands);
            break;
        case 'e':
            vec_push(&exec_cmds, optarg);
            break;
        case 't':
            saw_t = true;
            break;
        case 'n':
            headless = true;
            break;
        case 'N':
            saw_N = true;
            break;
        case 'q':
            quiet = true;
            break;
        case '?':
            if (optopt == 'd') return arg_error(114, "-d: 1 required FILE missing");
            if (optopt == 'c') return arg_error(114, "-c: 1 required  missing");
            if (optopt == 'f') return arg_error(114, "-f: 1 required  missing");
            if (optopt == 'I') return arg_error(114, "-I: 1 required TEXT:DIR missing");
            if (optopt == 'S') return arg_error(114, "--since: 1 required TEXT missing");
            if (optopt == 'U') return arg_error(114, "--until: 1 required TEXT missing");
            {
                char buf[256];
                snprintf(buf, sizeof(buf), "The following argument was not expected: %s", argv[optind - 1]);
                return arg_error(109, buf);
            }
        default:
            return arg_error(109, "invalid option");
        }
    }

    (void) saw_N;
    (void) saw_t;

    for (int i = optind; i < argc; i++) {
        vec_push(&paths, argv[i]);
    }

    if (update_formats) {
        printf("No formats from git repositories found, use 'lnav -i extra' to install third-party formats\n");
        return 0;
    }
    if (management_mode && paths.count == 0) {
        printf("  error: expecting an operation to perform\n"
               " = help: the available operations are:\n"
               "          • apps: manage lnav apps\n"
               "          • config: perform operations on the lnav configuration\n"
               "          • format: perform operations on log file formats\n"
               "          • piper: perform operations on piper storage\n"
               "          • regex101: create and edit log message regular expressions using regex101.com\n"
               "          • crash: manage crash logs\n");
        return 1;
    }

    if (!headless && !isatty(STDOUT_FILENO)) {
        printf("  error: unable to display interactive text UI\n reason: stdout is not a TTY\n = help: pass the -n option to run lnav in headless mode or don't redirect stdout\n");
        return 1;
    }

    StrVec lines = {0};
    for (size_t i = 0; i < paths.count; i++) {
        load_path(paths.items[i], recursive, &lines);
    }
    for (size_t i = 0; i < exec_cmds.count; i++) {
        FILE *p = popen(exec_cmds.items[i], "r");
        if (p) {
            char *line = NULL;
            size_t cap = 0;
            while (getline(&line, &cap, p) >= 0) vec_push(&lines, line);
            free(line);
            pclose(p);
        }
    }

    if (since || until) {
        StrVec filtered = {0};
        for (size_t i = 0; i < lines.count; i++) {
            if (line_in_range(lines.items[i], since, until)) vec_push(&filtered, lines.items[i]);
        }
        lines = filtered;
    }

    if (commands.count > 0) {
        for (size_t i = 0; i < commands.count; i++) {
            const char *cmd = commands.items[i];
            if (strncmp(cmd, ":echo", 5) == 0) {
                const char *msg = cmd + 5;
                while (*msg == ' ') msg++;
                printf("%s\n", msg);
            } else if (cmd[0] == ';') {
                execute_sql(cmd + 1, &lines);
            } else if (cmd[0] == ':') {
                printf("  error: unknown command: “%s”\n", cmd + 1);
            }
        }
        return 0;
    }

    if (!quiet) {
        for (size_t i = 0; i < lines.count; i++) {
            fputs(lines.items[i], stdout);
        }
    }
    return 0;
}
