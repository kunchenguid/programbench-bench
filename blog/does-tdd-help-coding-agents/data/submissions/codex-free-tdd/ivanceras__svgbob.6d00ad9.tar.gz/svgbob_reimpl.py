#!/usr/bin/env python3
import glob
import html
import os
import re
import sys


HELP = """svgbob 0.7.6
SvgBobRus is an ascii to svg converter

USAGE:
    executable [FLAGS] [OPTIONS] [input] [SUBCOMMAND]

FLAGS:
    -h, --help       Prints help information
    -s               parse an inline string
    -V, --version    Prints version information

OPTIONS:
        --background <background>        backdrop background will be filled with this color (default: 'white')
        --fill-color <fill-color>        solid shapes will be filled with this color (default: 'black')
        --font-family <font-family>      text will be rendered with this font (default: 'arial')
        --font-size <font-size>          text will be rendered with this font size (default: 14)
    -o, --output <output>                where to write svg output [default: STDOUT]
        --scale <scale>                  scale the entire svg (dimensions, font size, stroke width) by this factor
                                         (default: 1)
        --stroke-color <stroke-color>    stroke color for all lines (default: 'black')
        --stroke-width <stroke-width>    stroke width for all lines (default: 2)

ARGS:
    <input>    svgbob text file or inline string to parse [default: STDIN]

SUBCOMMANDS:
    build    Batch convert files to svg.
    help     Prints this message or the help of the given subcommand(s)
"""

BUILD_HELP = """executable-build 0.0.1
Batch convert files to svg.

USAGE:
    executable build [OPTIONS]

FLAGS:
    -h, --help       Prints help information
    -V, --version    Prints version information

OPTIONS:
    -i, --input <input>      set input file pattern like: *.bob or dir/*.bob
    -o, --outdir <outdir>    set dir of svg files
"""


def defaults():
    return {
        "background": "white",
        "fill_color": "black",
        "font_family": "Iosevka Fixed, monospace",
        "font_size": "14",
        "stroke_color": "black",
        "stroke_width": "2",
        "scale": 1.0,
        "output": None,
        "inline": False,
    }


def fmt_num(value):
    value = float(value)
    if abs(value - round(value)) < 1e-9:
        return str(int(round(value)))
    return ("%g" % value)


def style(opts):
    bg = opts["background"]
    fill = opts["fill_color"]
    stroke = opts["stroke_color"]
    return f"""  <style>.svgbob line, .svgbob path, .svgbob circle, .svgbob rect, .svgbob polygon {{
  stroke: {stroke};
  stroke-width: {opts["stroke_width"]};
  stroke-opacity: 1;
  fill-opacity: 1;
  stroke-linecap: round;
  stroke-linejoin: miter;
}}

.svgbob text {{
  white-space: pre;
  fill: {stroke};
  font-family: {opts["font_family"]};
  font-size: {opts["font_size"]}px;
}}

.svgbob rect.backdrop {{
  stroke: none;
  fill: {bg};
}}

.svgbob .broken {{
  stroke-dasharray: 8;
}}

.svgbob .filled {{
  fill: {fill};
}}

.svgbob .bg_filled {{
  fill: {bg};
  stroke-width: 1;
}}

.svgbob .nofill {{
  fill: {bg};
}}

.svgbob .end_marked_arrow {{
  marker-end: url(#arrow);
}}

.svgbob .start_marked_arrow {{
  marker-start: url(#arrow);
}}

.svgbob .end_marked_diamond {{
  marker-end: url(#diamond);
}}

.svgbob .start_marked_diamond {{
  marker-start: url(#diamond);
}}

.svgbob .end_marked_circle {{
  marker-end: url(#circle);
}}

.svgbob .start_marked_circle {{
  marker-start: url(#circle);
}}

.svgbob .end_marked_open_circle {{
  marker-end: url(#open_circle);
}}

.svgbob .start_marked_open_circle {{
  marker-start: url(#open_circle);
}}

.svgbob .end_marked_big_open_circle {{
  marker-end: url(#big_open_circle);
}}

.svgbob .start_marked_big_open_circle {{
  marker-start: url(#big_open_circle);
}}

</style>"""


DEFS = """  <defs>
    <marker id="arrow" viewBox="-2 -2 8 8" refX="4" refY="2" markerWidth="7" markerHeight="7" orient="auto-start-reverse">
      <polygon points="0,0 0,4 4,2 0,0"></polygon>
    </marker>
    <marker id="diamond" viewBox="-2 -2 8 8" refX="4" refY="2" markerWidth="7" markerHeight="7" orient="auto-start-reverse">
      <polygon points="0,2 2,0 4,2 2,4 0,2"></polygon>
    </marker>
    <marker id="circle" viewBox="0 0 8 8" refX="4" refY="4" markerWidth="7" markerHeight="7" orient="auto-start-reverse">
      <circle cx="4" cy="4" r="2" class="filled"></circle>
    </marker>
    <marker id="open_circle" viewBox="0 0 8 8" refX="4" refY="4" markerWidth="7" markerHeight="7" orient="auto-start-reverse">
      <circle cx="4" cy="4" r="2" class="bg_filled"></circle>
    </marker>
    <marker id="big_open_circle" viewBox="0 0 8 8" refX="4" refY="4" markerWidth="7" markerHeight="7" orient="auto-start-reverse">
      <circle cx="4" cy="4" r="3" class="bg_filled"></circle>
    </marker>
  </defs>"""


def split_lines(text):
    text = text.replace("\r\n", "\n").replace("\r", "\n")
    if text.endswith("\n"):
        text = text[:-1]
    if text == "":
        return [""]
    return text.split("\n")


def grid(lines):
    width = max([len(line) for line in lines] + [0])
    padded = [list(line.ljust(width)) for line in lines]
    used = [[False] * width for _ in lines]
    return padded, used, width, len(lines)


def mark(used, r1, c1, r2, c2):
    for r in range(r1, r2 + 1):
        if 0 <= r < len(used):
            for c in range(c1, c2 + 1):
                if 0 <= c < len(used[r]):
                    used[r][c] = True


def add_line(elems, x1, y1, x2, y2, cls="solid"):
    elems.append(f'  <line x1="{fmt_num(x1)}" y1="{fmt_num(y1)}" x2="{fmt_num(x2)}" y2="{fmt_num(y2)}" class="{cls}"></line>')


def add_text(elems, x, y, text):
    elems.append(f'  <text x="{fmt_num(x)}" y="{fmt_num(y)}" >{html.escape(text)}</text>')


def render_shapes(lines, scale):
    chars, used, width, height = grid(lines)
    elems = []

    # Rectangles of the common +---+/|   |/+---+ form.
    for r1 in range(height):
        for c1 in range(width):
            if chars[r1][c1] != "+":
                continue
            for c2 in range(c1 + 2, width):
                if chars[r1][c2] != "+":
                    continue
                if any(chars[r1][c] not in "-=+" for c in range(c1 + 1, c2)):
                    continue
                for r2 in range(r1 + 2, height):
                    if chars[r2][c1] == "+" and chars[r2][c2] == "+":
                        if any(chars[r2][c] not in "-=+" for c in range(c1 + 1, c2)):
                            continue
                        if all(chars[r][c1] == "|" and chars[r][c2] == "|" for r in range(r1 + 1, r2)):
                            x = (c1 * 8 + 4) * scale
                            y = (r1 * 16 + 8) * scale
                            w = (c2 - c1) * 8 * scale
                            h = (r2 - r1) * 16 * scale
                            elems.append(f'  <rect x="{fmt_num(x)}" y="{fmt_num(y)}" width="{fmt_num(w)}" height="{fmt_num(h)}" class="solid nofill" rx="0"></rect>')
                            mark(used, r1, c1, r2, c2)
                            break

    for r, line in enumerate(chars):
        c = 0
        while c < width:
            if used[r][c]:
                c += 1
                continue
            # Horizontal arrows and open-circle endpoints.
            if line[c] == "<" and c + 2 < width and line[c + 1] == "-" and line[c + 2] == "-":
                end = c + 2
                while end + 1 < width and line[end + 1] == "-":
                    end += 1
                y = (r * 16 + 8) * scale
                elems.append(f'  <polygon points="{fmt_num((c+1)*8*scale)},{fmt_num((r*16+4)*scale)} {fmt_num(c*8*scale)},{fmt_num(y)} {fmt_num((c+1)*8*scale)},{fmt_num((r*16+12)*scale)}" class="filled"></polygon>')
                add_line(elems, (c + 1) * 8 * scale, y, (end + 1) * 8 * scale, y)
                mark(used, r, c, r, end)
                c = end + 1
                continue
            if line[c] == "o" and c + 1 < width and line[c + 1] == "-":
                end = c + 1
                while end + 1 < width and line[end + 1] == "-":
                    end += 1
                y = (r * 16 + 8) * scale
                add_line(elems, end * 8 * scale, y, (c * 8 + 4) * scale, y, "solid end_marked_open_circle")
                if end + 1 > c + 1:
                    add_line(elems, end * 8 * scale, y, (end + 1) * 8 * scale, y)
                mark(used, r, c, r, end)
                c = end + 1
                continue
            if line[c] == "-" and c + 1 < width and line[c + 1] == "-":
                end = c
                while end + 1 < width and line[end + 1] == "-":
                    end += 1
                y = (r * 16 + 8) * scale
                if end + 1 < width and line[end + 1] == ">":
                    add_line(elems, c * 8 * scale, y, (end + 1) * 8 * scale, y)
                    elems.append(f'  <polygon points="{fmt_num((end+1)*8*scale)},{fmt_num((r*16+4)*scale)} {fmt_num((end+2)*8*scale)},{fmt_num(y)} {fmt_num((end+1)*8*scale)},{fmt_num((r*16+12)*scale)}" class="filled"></polygon>')
                    mark(used, r, c, r, end + 1)
                    c = end + 2
                    continue
                if end + 1 < width and line[end + 1] == "o":
                    add_line(elems, c * 8 * scale, y, (end * 8 + 4) * scale, y, "solid end_marked_open_circle")
                    mark(used, r, c, r, end + 1)
                    c = end + 2
                    continue
                add_line(elems, c * 8 * scale, y, (end + 1) * 8 * scale, y)
                mark(used, r, c, r, end)
                c = end + 1
                continue
            if line[c] == "/":
                add_line(elems, (c + 1) * 8 * scale, r * 16 * scale, c * 8 * scale, (r + 1) * 16 * scale)
                mark(used, r, c, r, c)
                c += 1
                continue
            if line[c] == "\\":
                add_line(elems, c * 8 * scale, r * 16 * scale, (c + 1) * 8 * scale, (r + 1) * 16 * scale)
                mark(used, r, c, r, c)
                c += 1
                continue
            c += 1

    for c in range(width):
        r = 0
        while r < height:
            if used[r][c] or chars[r][c] != "|":
                r += 1
                continue
            end = r
            while end + 1 < height and not used[end + 1][c] and chars[end + 1][c] == "|":
                end += 1
            x = (c * 8 + 4) * scale
            add_line(elems, x, r * 16 * scale, x, (end + 1) * 16 * scale)
            mark(used, r, c, end, c)
            r = end + 1

    for r, line in enumerate(chars):
        c = 0
        while c < width:
            while c < width and (used[r][c] or line[c] == " "):
                c += 1
            start = c
            text = []
            while c < width and not used[r][c] and line[c] != " ":
                text.append(line[c])
                c += 1
            if text:
                add_text(elems, (start * 8 + 2) * scale, (r * 16 + 12) * scale, "".join(text))
    return sorted(elems, key=element_key)


def element_key(elem):
    nums = [float(n) for n in re.findall(r'(?:x|y|x1|y1|x2|y2|points)="(-?\d+(?:\.\d+)?)', elem)]
    if "<polygon" in elem:
        m = re.search(r'points="([^"]+)"', elem)
        coords = [float(n) for n in re.findall(r'-?\d+(?:\.\d+)?', m.group(1))] if m else []
        xs = coords[0::2]
        ys = coords[1::2]
        center_y = (min(ys) + max(ys)) / 2 if ys else 0
        return (int(center_y // 16), min(xs) if xs else 0)
    attrs = dict((k, float(v)) for k, v in re.findall(r'(x1|y1|x2|y2|x|y)="(-?\d+(?:\.\d+)?)', elem))
    xs = [attrs[k] for k in ("x", "x1", "x2") if k in attrs]
    ys = [attrs[k] for k in ("y", "y1", "y2") if k in attrs]
    center_y = (min(ys) + max(ys)) / 2 if ys else 0
    return (int(center_y // 16), min(xs) if xs else 0, nums)


def render_svg(text, opts):
    lines = split_lines(text)
    scale = opts["scale"]
    cols = max([len(line) for line in lines] + [0])
    rows = len(lines)
    w = (cols + 1) * 8 * scale
    h = (rows + 1) * 16 * scale
    out = [f'<svg xmlns="http://www.w3.org/2000/svg" width="{fmt_num(w)}" height="{fmt_num(h)}" class="svgbob">']
    out.append(style(opts))
    out.append(DEFS)
    out.append(f'  <rect class="backdrop" x="0" y="0" width="{fmt_num(w)}" height="{fmt_num(h)}"></rect>')
    out.extend(render_shapes(lines, scale))
    out.append("</svg>")
    return "\n".join(out) + "\n"


def parse_options(args):
    opts = defaults()
    positional = []
    i = 0
    passthrough = False
    while i < len(args):
        a = args[i]
        if passthrough:
            positional.append(a)
        elif a == "--":
            passthrough = True
        elif a in ("-h", "--help"):
            print(HELP, end="")
            raise SystemExit(0)
        elif a in ("-V", "--version"):
            print("svgbob 0.7.6")
            raise SystemExit(0)
        elif a == "-s":
            opts["inline"] = True
        elif a in ("-o", "--output"):
            i += 1
            opts["output"] = args[i]
        elif a.startswith("--"):
            key = a[2:].replace("-", "_")
            if key in opts and key != "inline":
                i += 1
                opts[key] = args[i]
                if key == "scale":
                    opts[key] = float(opts[key])
            else:
                sys.stderr.write(f"error: Found argument '{a}' which wasn't expected\n")
                raise SystemExit(1)
        else:
            positional.append(a)
        i += 1
    return opts, positional


def read_input(opts, positional):
    if positional:
        value = positional[0]
        if opts["inline"]:
            return value
        with open(value, "r", encoding="utf-8") as f:
            return f.read()
    return sys.stdin.read()


def build_main(args):
    if not args or "-h" in args or "--help" in args:
        print(BUILD_HELP, end="")
        return 0
    if "-V" in args or "--version" in args:
        print("executable-build 0.0.1")
        return 0
    pattern = None
    outdir = None
    i = 0
    while i < len(args):
        if args[i] in ("-i", "--input"):
            i += 1
            pattern = args[i]
        elif args[i] in ("-o", "--outdir"):
            i += 1
            outdir = args[i]
        i += 1
    if not pattern or not outdir:
        sys.stderr.write(BUILD_HELP)
        return 1
    os.makedirs(outdir, exist_ok=True)
    opts = defaults()
    for src in glob.glob(pattern):
        dst = os.path.join(outdir, os.path.splitext(os.path.basename(src))[0] + ".svg")
        with open(src, "r", encoding="utf-8") as f:
            svg = render_svg(f.read(), opts)
        with open(dst, "w", encoding="utf-8") as f:
            f.write(svg)
        print(f"{src} => {dst}")
    return 0


def main(argv):
    if len(argv) > 1 and argv[1] == "help":
        if len(argv) > 2 and argv[2] == "build":
            print(BUILD_HELP, end="")
        else:
            print(HELP, end="")
        return 0
    if len(argv) > 1 and argv[1] == "build":
        return build_main(argv[2:])
    opts, positional = parse_options(argv[1:])
    svg = render_svg(read_input(opts, positional), opts)
    if opts["output"]:
        with open(opts["output"], "w", encoding="utf-8") as f:
            f.write(svg)
    else:
        sys.stdout.write(svg)
    return 0


if __name__ == "__main__":
    raise SystemExit(main(sys.argv))
