#!/usr/bin/env python3
import calendar
import os
import sys
import time
from datetime import date
from pathlib import Path


VERSION = "commit-93cc85d16ab60ba8d646458fe0233778317b22a3"
DEFAULT_CONFIG = "/home/agent/.caps-log/config.ini"
DEFAULT_LOG_DIR = "/home/agent/.caps-log/day/"
DEFAULT_LOG_FORMAT = "d%y_%m_%d.md"


HELP = """Captain's Log (caps-log)! A CLI journalig tool.
Version: commit-93cc85d16ab60ba8d646458fe0233778317b22a3
Allowed options:
  -h [ --help ]         show this message
  -c [ --config ] arg   override the default config file path 
                        (/home/agent/.caps-log/config.ini)
  --log-dir-path arg    path where log files are stored
  --log-name-format arg format in which log entry markdown files are saved
  --sunday-start        have the calendar display sunday as first day of the 
                        week
  --first-line-section  override the default behaviour of ignoring sections 
                        (lines starting with `#`) in the first line of a log 
                        entry file
  --password arg        password for encrypted log repositories or to be used 
                        with --encrypt/--decrypt
  --encrypt             apply encryption to all logs in log dir path (needs 
                        --password)
  --decrypt             apply decryption to all logs in log dir path (needs 
                        --password)
"""


VALUE_OPTIONS = {
    "--config": "config",
    "-c": "config",
    "--log-dir-path": "log_dir_path",
    "--log-name-format": "log_name_format",
    "--password": "password",
}

FLAG_OPTIONS = {
    "--help": "help",
    "-h": "help",
    "--sunday-start": "sunday_start",
    "--first-line-section": "first_line_section",
    "--encrypt": "encrypt",
    "--decrypt": "decrypt",
}


class CliError(Exception):
    pass


def error(message):
    sys.stdout.write(f"Captain's log encountered an error: \n {message}\n")
    return 1


def parse_args(argv):
    opts = {
        "config": DEFAULT_CONFIG,
        "log_dir_path": None,
        "log_name_format": None,
        "password": None,
        "help": False,
        "sunday_start": False,
        "first_line_section": False,
        "encrypt": False,
        "decrypt": False,
    }
    i = 0
    while i < len(argv):
        arg = argv[i]
        if arg in VALUE_OPTIONS:
            if i + 1 >= len(argv) or argv[i + 1].startswith("-"):
                raise CliError(f"the required argument for option '{arg}' is missing")
            opts[VALUE_OPTIONS[arg]] = argv[i + 1]
            i += 2
            continue
        if arg in FLAG_OPTIONS:
            opts[FLAG_OPTIONS[arg]] = True
            i += 1
            continue
        raise CliError(f"unrecognised option '{arg}'")
    return opts


def read_config(path):
    try:
        lines = Path(path).read_text().splitlines()
    except OSError:
        raise CliError(f"Failed to open file: {path}")
    values = {}
    section = None
    for raw in lines:
        line = raw.split("#", 1)[0].strip()
        if not line:
            continue
        if line.startswith("[") and line.endswith("]"):
            section = line[1:-1].strip()
            continue
        if "=" not in line:
            continue
        key, value = [part.strip() for part in line.split("=", 1)]
        full_key = f"{section}.{key}" if section else key
        values[full_key] = value
        values[key] = value
    return values


def bool_value(value):
    return str(value).strip().lower() in {"1", "true", "yes", "on"}


def strftime_from_caps_format(fmt, day):
    return day.strftime(fmt)


def count_logs(log_dir, fmt, year):
    root = Path(log_dir)
    if not root.is_dir():
        return 0
    count = 0
    for child in root.iterdir():
        if not child.is_file():
            continue
        for month in range(1, 13):
            for dom in range(1, calendar.monthrange(year, month)[1] + 1):
                if child.name == date(year, month, dom).strftime(fmt):
                    count += 1
                    break
            else:
                continue
            break
    return count


def apply_crypto(log_dir, encrypt):
    marker = Path(log_dir) / ".cle"
    sys.stdout.write("Applying crypto...\n")
    if encrypt:
        marker.parent.mkdir(parents=True, exist_ok=True)
        marker.write_bytes(bytes.fromhex("7fa09037ddfe2aa6fea02681d7b60dba70db"))
    else:
        try:
            marker.unlink()
        except FileNotFoundError:
            pass


def validate_repository_password(log_dir, password):
    marker = Path(log_dir) / ".cle"
    if password and not marker.exists():
        raise CliError("Password provided for a non encrypted repository!")
    if password and marker.exists():
        data = marker.read_bytes()
        expected = bytes.fromhex("7fa09037ddfe2aa6fea02681d7b60dba70db")
        if data != expected:
            raise CliError("Invalid password provided!")


def render_tui(log_dir, log_format, sunday_start):
    today = date.today()
    entries = count_logs(log_dir, log_format, today.year)
    sys.stdout.write("\x00\x1bP$q q\x1b\\\x1b[?1049h\x1b[?7l")
    sys.stdout.write(
        f"\r\x1b[2K       \x1b[1m\x1b[4mToday is: {today:%d. %m. %Y.}  | "
        f"There are {entries} log entries for year {today.year}.\x1b[22m\x1b[24m        \r\n"
    )
    sys.stdout.write("Sections\nTags\n")
    sys.stdout.write(f"{today.year}\n")
    firstweekday = 6 if sunday_start else 0
    cal = calendar.TextCalendar(firstweekday)
    sys.stdout.write(cal.formatyear(today.year, w=2, l=1, c=2, m=3))
    sys.stdout.flush()
    while True:
        time.sleep(60)


def main(argv):
    try:
        opts = parse_args(argv)
        if opts["help"]:
            sys.stdout.write(HELP)
            return 0
        config = read_config(opts["config"])
        log_dir = opts["log_dir_path"] or config.get("log-dir-path") or DEFAULT_LOG_DIR
        log_format = opts["log_name_format"] or config.get("log-name-format") or config.get("log-filename-format") or DEFAULT_LOG_FORMAT
        sunday_start = opts["sunday_start"] or bool_value(config.get("sunday-start", "false"))
        if opts["first_line_section"] or bool_value(config.get("first-line-section", "false")):
            pass
        password = opts["password"] or config.get("password")
        if opts["encrypt"] or opts["decrypt"]:
            if not password:
                action = "encrypting" if opts["encrypt"] else "decrypting"
                raise CliError(f"Password must be provided when {action} logs!")
            apply_crypto(log_dir, opts["encrypt"])
            return 0
        validate_repository_password(log_dir, password)
        render_tui(log_dir, log_format, sunday_start)
        return 0
    except CliError as exc:
        return error(str(exc))


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
