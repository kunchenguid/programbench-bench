import os
import shutil
import subprocess
import tempfile
import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]


def run_cmd(args, timeout=3, env=None):
    merged_env = os.environ.copy()
    if env:
        merged_env.update(env)
    return subprocess.run(
        args,
        cwd=ROOT,
        text=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        timeout=timeout,
        env=merged_env,
    )


class CapsLogCliTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        run_cmd(["bash", "-lc", "rm -f executable && chmod +x compile.sh && ./compile.sh"])

    def test_help_matches_documented_options(self):
        result = run_cmd(["./executable", "--help"])
        self.assertEqual(result.returncode, 0)
        self.assertIn("Captain's Log (caps-log)! A CLI journalig tool.", result.stdout)
        self.assertIn("Version: commit-93cc85d16ab60ba8d646458fe0233778317b22a3", result.stdout)
        self.assertIn("-c [ --config ] arg", result.stdout)
        self.assertIn("--first-line-section", result.stdout)
        self.assertIn("--decrypt", result.stdout)

    def test_unknown_option_reports_captains_log_error(self):
        result = run_cmd(["./executable", "--badflag"])
        self.assertEqual(result.returncode, 1)
        self.assertEqual(
            result.stdout,
            "Captain's log encountered an error: \n unrecognised option '--badflag'\n",
        )

    def test_missing_required_argument_reports_option_name(self):
        result = run_cmd(["./executable", "--log-dir-path"])
        self.assertEqual(result.returncode, 1)
        self.assertEqual(
            result.stdout,
            "Captain's log encountered an error: \n the required argument for option '--log-dir-path' is missing\n",
        )

    def test_missing_config_fails_before_using_log_dir_override(self):
        with tempfile.TemporaryDirectory() as td:
            log_dir = Path(td) / "logs"
            log_dir.mkdir()
            result = run_cmd(["./executable", "--log-dir-path", str(log_dir)])
        self.assertEqual(result.returncode, 1)
        self.assertEqual(
            result.stdout,
            "Captain's log encountered an error: \n Failed to open file: /home/agent/.caps-log/config.ini\n",
        )

    def test_empty_config_enters_tui_and_prints_annual_header(self):
        with tempfile.TemporaryDirectory() as td:
            config = Path(td) / "config.ini"
            config.write_text("")
            result = run_cmd(["timeout", "1", "./executable", "--config", str(config)], timeout=2, env={"TERM": "xterm"})
        self.assertEqual(result.returncode, 124)
        self.assertIn("Today is: 05. 06. 2026.  | There are 0 log entries for year 2026.", result.stdout)
        self.assertIn("Sections", result.stdout)
        self.assertIn("Tags", result.stdout)
        self.assertIn("2026", result.stdout)

    def test_encrypt_and_decrypt_require_password_and_toggle_marker(self):
        with tempfile.TemporaryDirectory() as td:
            config = Path(td) / "config.ini"
            config.write_text("")
            log_dir = Path(td) / "logs"
            log_dir.mkdir()
            (log_dir / "d26_06_05.md").write_text("Hello\n")

            missing_password = run_cmd([
                "./executable",
                "--config",
                str(config),
                "--log-dir-path",
                str(log_dir),
                "--encrypt",
            ])
            self.assertEqual(missing_password.returncode, 1)
            self.assertEqual(
                missing_password.stdout,
                "Captain's log encountered an error: \n Password must be provided when encrypting logs!\n",
            )

            encrypted = run_cmd([
                "./executable",
                "--config",
                str(config),
                "--log-dir-path",
                str(log_dir),
                "--encrypt",
                "--password",
                "pw",
            ])
            self.assertEqual(encrypted.returncode, 0)
            self.assertEqual(encrypted.stdout, "Applying crypto...\n")
            self.assertTrue((log_dir / ".cle").exists())
            self.assertEqual((log_dir / "d26_06_05.md").read_text(), "Hello\n")

            decrypted = run_cmd([
                "./executable",
                "--config",
                str(config),
                "--log-dir-path",
                str(log_dir),
                "--decrypt",
                "--password",
                "pw",
            ])
            self.assertEqual(decrypted.returncode, 0)
            self.assertEqual(decrypted.stdout, "Applying crypto...\n")
            self.assertFalse((log_dir / ".cle").exists())

    def test_password_for_plain_repository_is_rejected(self):
        with tempfile.TemporaryDirectory() as td:
            config = Path(td) / "config.ini"
            config.write_text("")
            log_dir = Path(td) / "logs"
            log_dir.mkdir()
            result = run_cmd([
                "./executable",
                "--config",
                str(config),
                "--log-dir-path",
                str(log_dir),
                "--password",
                "pw",
            ])
        self.assertEqual(result.returncode, 1)
        self.assertEqual(
            result.stdout,
            "Captain's log encountered an error: \n Password provided for a non encrypted repository!\n",
        )

    def test_password_for_unrecognized_encrypted_marker_is_invalid(self):
        with tempfile.TemporaryDirectory() as td:
            config = Path(td) / "config.ini"
            config.write_text("")
            log_dir = Path(td) / "logs"
            log_dir.mkdir()
            (log_dir / ".cle").write_text("")
            result = run_cmd([
                "./executable",
                "--config",
                str(config),
                "--log-dir-path",
                str(log_dir),
                "--password",
                "pw",
            ])
        self.assertEqual(result.returncode, 1)
        self.assertEqual(
            result.stdout,
            "Captain's log encountered an error: \n Invalid password provided!\n",
        )


if __name__ == "__main__":
    unittest.main()
