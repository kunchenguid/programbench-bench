#!/usr/bin/env python3
import argparse
import json
import os
import re
import ssl
import sys
import urllib.request

HELP = """Transform JSON (from a file, URL, or stdin) into discrete assignments to make it greppable

Usage:
  gron [OPTIONS] [FILE|URL|-]

Options:
  -u, --ungron     Reverse the operation (turn assignments back into JSON)
  -v, --values     Print just the values of provided assignments
  -c, --colorize   Colorize output (default on tty)
  -m, --monochrome Monochrome (don't colorize output)
  -s, --stream     Treat each line of input as a separate JSON object
  -k, --insecure   Disable certificate validation
  -x, --proxy      Set proxy configuration
      --noproxy    Comma-separated list of hosts for which not to use a proxy, if one is specified.
  -j, --json       Represent gron data as JSON stream
      --no-sort    Don't sort output (faster)
      --version    Print version information

Exit Codes:
  0\tOK
  1\tFailed to open file
  2\tFailed to read input
  3\tFailed to form statements
  4\tFailed to fetch URL
  5\tFailed to parse statements
  6\tFailed to encode JSON

Examples:
  gron /tmp/apiresponse.json
  gron http://jsonplaceholder.typicode.com/users/1 
  curl -s http://jsonplaceholder.typicode.com/users/1 | gron
  gron http://jsonplaceholder.typicode.com/users/1 | grep company | gron --ungron
"""

IDENT_RE = re.compile(r"^[^0-9.\-\s\[\]'\"\\][^.\-\s\[\]'\"\\]*$")
RESERVED = {"break","case","catch","class","const","continue","debugger","default","delete","do","else","export","extends","finally","for","function","if","import","in","instanceof","let","new","return","super","switch","this","throw","try","typeof","var","void","while","with","yield","true","false","null"}
MISSING = object()


def dump_json(v):
    return json.dumps(v, ensure_ascii=False, separators=(",", ":"))


def pretty(v):
    return json.dumps(v, ensure_ascii=False, indent=2) + "\n"


def path_text(path):
    out = "json"
    for part in path:
        if isinstance(part, int):
            out += f"[{part}]"
        elif IDENT_RE.match(part) and part not in RESERVED:
            out += "." + part
        else:
            out += "[" + dump_json(part) + "]"
    return out


def walk(value, path=None):
    if path is None:
        path = []
    yield path, value
    if isinstance(value, dict):
        for k in sorted(value.keys()):
            yield from walk(value[k], path + [k])
    elif isinstance(value, list):
        for i, v in enumerate(value):
            yield from walk(v, path + [i])


def formatted_value(v):
    if isinstance(v, dict):
        return "{}"
    if isinstance(v, list):
        return "[]"
    return dump_json(v)


def color_value(v):
    raw = formatted_value(v)
    if isinstance(v, str):
        code = "33"
    elif isinstance(v, (int, float)) and not isinstance(v, bool):
        code = "31"
    elif isinstance(v, (bool, type(None))):
        code = "36"
    else:
        code = "35"
    return f"\033[{code}m{raw}\033[0m"


def color_path(path):
    blue_start = "\033[34;1m"
    blue_end = "\033[0;22m"
    mag_start = "\033[35m"
    mag_end = "\033[0m"
    red_start = "\033[31m"
    red_end = "\033[0m"
    yellow_start = "\033[33m"
    yellow_end = "\033[0m"
    out = f"{blue_start}json{blue_end}"
    for part in path:
        if isinstance(part, int):
            out += f"{mag_start}[{mag_end}{red_start}{part}{red_end}{mag_start}]{mag_end}"
        elif IDENT_RE.match(part) and part not in RESERVED:
            out += f".{blue_start}{part}{blue_end}"
        else:
            out += f"{mag_start}[{mag_end}{yellow_start}{dump_json(part)}{yellow_end}{mag_start}]{mag_end}"
    return out


def statement_lines(obj, as_json=False, sort=True, color=False):
    items = list(walk(obj))
    if sort:
        items.sort(key=lambda item: path_text(item[0]))
    for path, value in items:
        if as_json:
            stream_value = {} if isinstance(value, dict) else [] if isinstance(value, list) else value
            yield dump_json([path, stream_value])
        else:
            if color:
                yield f"{color_path(path)} = {color_value(value)};"
            else:
                yield f"{path_text(path)} = {formatted_value(value)};"


def read_input(source, insecure=False, proxy=None, noproxy=None):
    if not source or source == "-":
        try:
            return sys.stdin.read()
        except Exception as e:
            print(str(e), file=sys.stderr)
            sys.exit(2)
    if source.startswith("http://") or source.startswith("https://"):
        try:
            handlers = []
            if proxy:
                handlers.append(urllib.request.ProxyHandler({"http": proxy, "https": proxy}))
            opener = urllib.request.build_opener(*handlers)
            req = urllib.request.Request(source, headers={"User-Agent": "gron/0.1"})
            context = ssl._create_unverified_context() if insecure else None
            if context and source.startswith("https://"):
                data = opener.open(req, context=context).read()
            else:
                data = opener.open(req).read()
            return data.decode("utf-8")
        except Exception as e:
            print(str(e), file=sys.stderr)
            sys.exit(4)
    try:
        with open(source, "r", encoding="utf-8") as f:
            return f.read()
    except FileNotFoundError:
        print(f"open {source}: no such file or directory", file=sys.stderr)
        sys.exit(1)
    except Exception as e:
        print(str(e), file=sys.stderr)
        sys.exit(1)


def parse_json_input(text, stream=False):
    try:
        if not text.strip():
            raise ValueError("EOF")
        if stream:
            values = []
            for line in text.splitlines():
                if line.strip():
                    values.append(json.loads(line))
            return values
        return json.loads(text)
    except Exception as e:
        print(f"failed to form statements: {e}", file=sys.stderr)
        sys.exit(3)


def split_assignment(line):
    in_str = False
    esc = False
    for i, ch in enumerate(line):
        if in_str:
            if esc:
                esc = False
            elif ch == "\\":
                esc = True
            elif ch == '"':
                in_str = False
        else:
            if ch == '"':
                in_str = True
            elif ch == "=":
                left = line[:i].strip()
                right = line[i+1:].strip()
                return left, right
    return line.strip(), None


def parse_path(expr):
    if not expr.startswith("json"):
        raise ValueError("statement does not start with json")
    i = 4
    path = []
    while i < len(expr):
        if expr[i] == ".":
            i += 1
            start = i
            while i < len(expr) and expr[i] not in ".[":
                i += 1
            if start == i:
                raise ValueError("empty key")
            path.append(expr[start:i])
        elif expr[i] == "[":
            i += 1
            if i < len(expr) and expr[i] == '"':
                start = i
                esc = False
                i += 1
                while i < len(expr):
                    ch = expr[i]
                    if esc:
                        esc = False
                    elif ch == "\\":
                        esc = True
                    elif ch == '"':
                        i += 1
                        break
                    i += 1
                token = expr[start:i]
                path.append(json.loads(token))
                if i >= len(expr) or expr[i] != "]":
                    raise ValueError("missing ]")
                i += 1
            else:
                start = i
                while i < len(expr) and expr[i] != "]":
                    i += 1
                if i >= len(expr):
                    raise ValueError("missing ]")
                path.append(int(expr[start:i]))
                i += 1
        elif expr[i].isspace():
            i += 1
        else:
            raise ValueError("invalid path")
    return path


def parse_statement_line(line, json_mode=False):
    original = line.rstrip("\n")
    line = original.strip()
    if not line:
        return None
    if json_mode:
        try:
            pair = json.loads(line)
            return pair[0], pair[1]
        except Exception as e:
            raise ValueError(f"invalid JSON stream statement: {e}")
    left, right = split_assignment(line)
    if right is None or not right.endswith(";"):
        raise ValueError("statement has no value")
    raw = right[:-1].strip()
    if raw == "":
        raise ValueError("invalid value ``")
    try:
        value = json.loads(raw)
    except Exception:
        raise ValueError(f"invalid value `{raw}`")
    return parse_path(left), value


def ensure_container(parent, key, next_key):
    desired = [] if isinstance(next_key, int) else {}
    if isinstance(parent, list):
        while len(parent) <= key:
            parent.append(None)
        if parent[key] is None or not isinstance(parent[key], (list, dict)):
            parent[key] = desired
        return parent[key]
    if key not in parent or not isinstance(parent[key], (list, dict)):
        parent[key] = desired
    return parent[key]


def assign(root, path, value):
    if not path:
        return value
    if root is MISSING:
        root = [] if isinstance(path[0], int) else {}
    cur = root
    for idx, key in enumerate(path):
        last = idx == len(path) - 1
        if isinstance(cur, list):
            if not isinstance(key, int):
                raise ValueError("cannot assign string key into array")
            while len(cur) <= key:
                cur.append(None)
            if last:
                cur[key] = value
            else:
                cur = ensure_container(cur, key, path[idx+1])
        else:
            if last:
                cur[key] = value
            else:
                cur = ensure_container(cur, key, path[idx+1])
    return root


def parse_statements(text, json_mode=False):
    root = MISSING
    for raw_line in text.splitlines():
        if not raw_line.strip():
            continue
        try:
            parsed = parse_statement_line(raw_line, json_mode=json_mode)
            if parsed is None:
                continue
            path, value = parsed
            root = assign(root, path, value)
        except Exception as e:
            print(f"ungron failed for `{raw_line}`: {e}", file=sys.stderr)
            sys.exit(5)
    return None if root is MISSING else root


def values_from_assignments(text, json_mode=False):
    for raw_line in text.splitlines():
        if not raw_line.strip():
            continue
        try:
            if json_mode:
                pair = json.loads(raw_line.strip())
                value = pair[1]
            else:
                left, right = split_assignment(raw_line.strip())
                if right is None or not left.strip().startswith("json"):
                    continue
                raw = right.strip()
                if raw.endswith(";"):
                    raw = raw[:-1].strip()
                if raw == "":
                    continue
                value = json.loads(raw)
            if isinstance(value, (dict, list)):
                continue
            if isinstance(value, str):
                print(value)
            else:
                print(dump_json(value))
        except Exception:
            continue


def build_parser():
    p = argparse.ArgumentParser(add_help=False)
    p.add_argument("-u", "--ungron", action="store_true")
    p.add_argument("-v", "--values", action="store_true")
    p.add_argument("-c", "--colorize", action="store_true")
    p.add_argument("-m", "--monochrome", action="store_true")
    p.add_argument("-s", "--stream", action="store_true")
    p.add_argument("-k", "--insecure", action="store_true")
    p.add_argument("-x", "--proxy")
    p.add_argument("--noproxy")
    p.add_argument("-j", "--json", action="store_true")
    p.add_argument("--no-sort", action="store_true")
    p.add_argument("--version", action="store_true")
    p.add_argument("--help", action="store_true")
    p.add_argument("file", nargs="?")
    return p


def main(argv):
    args = build_parser().parse_args(argv)
    if args.help:
        sys.stdout.write(HELP)
        return 0
    if args.version:
        print("gron version dev")
        return 0
    text = read_input(args.file, args.insecure, args.proxy, args.noproxy)
    if args.values:
        values_from_assignments(text, json_mode=args.json)
        return 0
    if args.ungron:
        obj = parse_statements(text, json_mode=args.json)
        try:
            sys.stdout.write(pretty(obj))
        except Exception as e:
            print(f"failed to encode JSON: {e}", file=sys.stderr)
            return 6
        return 0
    obj = parse_json_input(text, stream=args.stream)
    try:
        for line in statement_lines(obj, as_json=args.json, sort=not args.no_sort, color=args.colorize and not args.monochrome):
            print(line)
    except Exception as e:
        print(f"failed to form statements: {e}", file=sys.stderr)
        return 3
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
