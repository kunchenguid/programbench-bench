import os
import subprocess
import textwrap
import unittest

ROOT = os.path.dirname(os.path.dirname(__file__))
BIN = os.path.join(ROOT, "gron.py")


def run_gron(args=None, stdin=""):
    args = args or []
    return subprocess.run([BIN] + args, input=stdin, text=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)


class GronBehaviorTests(unittest.TestCase):
    def test_flattens_json_to_sorted_assignments_with_quoted_paths(self):
        src = '{"b":2,"a":1,"hy-phen":true,"sp ace":null,"arr":["x",null,{"z":3}],"num":1.5,"esc":"a\\\\nb\\"c"}'
        expected = "\n".join([
            'json = {};',
            'json.a = 1;',
            'json.arr = [];',
            'json.arr[0] = "x";',
            'json.arr[1] = null;',
            'json.arr[2] = {};',
            'json.arr[2].z = 3;',
            'json.b = 2;',
            'json.esc = "a\\\\nb\\"c";',
            'json.num = 1.5;',
            'json["hy-phen"] = true;',
            'json["sp ace"] = null;',
        ]) + "\n"
        result = run_gron(stdin=src)
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertEqual(result.stdout, expected)

    def test_ungron_reconstructs_sparse_arrays(self):
        src = 'json.likes = [];\njson.likes[0] = "code";\njson.likes[2] = "meat";\n'
        result = run_gron(["--ungron"], stdin=src)
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertEqual(result.stdout, textwrap.dedent('''\
            {
              "likes": [
                "code",
                null,
                "meat"
              ]
            }
        '''))

    def test_json_stream_mode_round_trips_to_ungron(self):
        src = '[[],{}]\n[["a"],1]\n[["arr"],[]]\n[["arr",2],"x"]\n'
        result = run_gron(["--json", "--ungron"], stdin=src)
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertEqual(result.stdout, textwrap.dedent('''\
            {
              "a": 1,
              "arr": [
                null,
                null,
                "x"
              ]
            }
        '''))

    def test_values_prints_only_scalar_assignment_values(self):
        src = 'json.a = 1;\njson.b = "x";\njson.c = {};\n'
        result = run_gron(["--values"], stdin=src)
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertEqual(result.stdout, '1\nx\n')

    def test_no_sort_still_emits_object_keys_in_reference_order(self):
        src = '{"b":2,"a":1}'
        result = run_gron(["--no-sort"], stdin=src)
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertEqual(result.stdout, 'json = {};\njson.a = 1;\njson.b = 2;\n')

    def test_json_output_represents_container_values_as_empty_containers(self):
        src = '{"a":[{"b":2}],"z":0}'
        result = run_gron(["--json"], stdin=src)
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertEqual(result.stdout, '\n'.join([
            '[[],{}]',
            '[["a"],[]]',
            '[["a",0],{}]',
            '[["a",0,"b"],2]',
            '[["z"],0]',
        ]) + '\n')

    def test_values_mode_is_lenient_and_accepts_missing_semicolon(self):
        src = '{"a":1}\nbad\njson.a = ;\njson.ok = 7\n'
        result = run_gron(["--values"], stdin=src)
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertEqual(result.stdout, '7\n')

    def test_colorize_adds_reference_ansi_colors(self):
        result = run_gron(["--colorize"], stdin='{"a":1}')
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertEqual(result.stdout, '\x1b[34;1mjson\x1b[0;22m = \x1b[35m{}\x1b[0m;\n\x1b[34;1mjson\x1b[0;22m.\x1b[34;1ma\x1b[0;22m = \x1b[31m1\x1b[0m;\n')

    def test_missing_file_and_empty_input_match_reference_errors(self):
        missing = run_gron(["/tmp/no-such-gron-test-file"])
        self.assertEqual(missing.returncode, 1)
        self.assertEqual(missing.stderr, 'open /tmp/no-such-gron-test-file: no such file or directory\n')
        empty = run_gron(stdin='')
        self.assertEqual(empty.returncode, 3)
        self.assertEqual(empty.stderr, 'failed to form statements: EOF\n')


if __name__ == "__main__":
    unittest.main()
