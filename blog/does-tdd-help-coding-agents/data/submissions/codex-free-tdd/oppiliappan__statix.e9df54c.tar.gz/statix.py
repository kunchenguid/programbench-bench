#!/usr/bin/env python3
import difflib
import os
import re
import sys


VERSION = "statix 0.5.8"

LINTS = [
    ("W01", "bool_comparison"),
    ("W02", "empty_let_in"),
    ("W03", "manual_inherit"),
    ("W04", "manual_inherit_from"),
    ("W05", "legacy_let_syntax"),
    ("W06", "collapsible_let_in"),
    ("W07", "eta_reduction"),
    ("W08", "useless_parens"),
    ("W10", "empty_pattern"),
    ("W11", "redundant_pattern_bind"),
    ("W12", "unquoted_uri"),
    ("W14", "empty_inherit"),
    ("W17", "deprecated_to_path"),
    ("W18", "bool_simplification"),
    ("W19", "useless_has_attr"),
    ("W20", "repeated_keys"),
    ("W23", "empty_list_concat"),
]

NAME_TO_CODE = {name: int(code[1:]) for code, name in LINTS}

EXPLAINS = {
    "W01": "## What it does\nChecks for expressions of the form `x == true`, `x != true` and\nsuggests using the variable directly.\n",
    "W02": "## What it does\nChecks for `let-in` expressions which create no new bindings.\n",
    "W03": "## What it does\nChecks for bindings of the form `a = a`.\n",
    "W04": "## What it does\nChecks for bindings of the form `a = someAttr.a`.\n",
    "W05": "## What it does\nChecks for legacy-let syntax that was never formalized.\n",
    "W06": "## What it does\nChecks for `let-in` expressions whose body is another `let-in`\nexpression.\n",
    "W07": "## What it does\nChecks for eta-reducible functions, i.e.: converts lambda\nexpressions into free standing functions where applicable.\n",
    "W08": "## What it does\nChecks for unnecessary parentheses.\n",
    "W10": "## What it does\nChecks for an empty variadic pattern: `{...}`, in a function\nargument.\n",
    "W11": "## What it does\nChecks for binds of the form `inputs @ { ... }` in function\narguments.\n",
    "W12": "## What it does\nChecks for URI expressions that are not quoted.\n",
    "W14": "## What it does\nChecks for empty inherit statements.\n",
    "W17": "## What it does\nChecks for usage of the `toPath` function.\n",
    "W18": "## What it does\nChecks for boolean expressions that can be simplified.\n",
    "W19": "## What it does\nChecks for expressions that use the \"has attribute\" operator: `?`,\nwhere the `or` operator would suffice.\n",
    "W20": "## What it does\nChecks for keys in attribute sets with repetitive keys, and suggests using\nan attribute set instead.\n",
    "W23": "## What it does\nChecks for concatenations to empty lists\n",
}


def top_help():
    return """statix 0.5.8

Akshay <nerdy@peppe.rs>

Lints and suggestions for the Nix programming language

USAGE:
    executable <SUBCOMMAND>

OPTIONS:
    -h, --help       Print help information
    -V, --version    Print version information

SUBCOMMANDS:
    check      Lints and suggestions for the nix programming language
    dump       Dump a sample config to stdout
    explain    Print detailed explanation for a lint warning
    fix        Find and fix issues raised by statix-check
    help       Print this message or the help of the given subcommand(s)
    list       List all available lints
    single     Fix exactly one issue at provided position
"""


def sub_help(name):
    if name == "check":
        return """executable-check 

Lints and suggestions for the nix programming language

USAGE:
    executable check [OPTIONS] [--] [TARGET]

ARGS:
    <TARGET>    File or directory to run check on [default: .]

OPTIONS:
    -c, --config <CONF_PATH>    Path to statix.toml or its parent directory [default: .]
    -h, --help                  Print help information
    -i, --ignore <IGNORE>...    Globs of file patterns to skip
    -o, --format <FORMAT>       Output format. Supported values: stderr, errfmt [default: stderr]
    -s, --stdin                 Enable "streaming" mode, accept file on stdin, output diagnostics on
                                stdout
    -u, --unrestricted          Don't respect .gitignore files
"""
    if name == "fix":
        return """executable-fix 

Find and fix issues raised by statix-check

USAGE:
    executable fix [OPTIONS] [--] [TARGET]

ARGS:
    <TARGET>    File or directory to run fix on [default: .]

OPTIONS:
    -c, --config <CONF_PATH>    Path to statix.toml or its parent directory [default: .]
    -d, --dry-run               Do not fix files in place, display a diff instead
    -h, --help                  Print help information
    -i, --ignore <IGNORE>...    Globs of file patterns to skip
    -s, --stdin                 Enable "streaming" mode, accept file on stdin, output diagnostics on
                                stdout
    -u, --unrestricted          Don't respect .gitignore files
"""
    if name == "single":
        return """executable-single 

Fix exactly one issue at provided position

USAGE:
    executable single [OPTIONS] --position <POSITION> [TARGET]

ARGS:
    <TARGET>    File to run single-fix on

OPTIONS:
    -c, --config <CONF_PATH>     Path to statix.toml or its parent directory [default: .]
    -d, --dry-run                Do not fix files in place, display a diff instead
    -h, --help                   Print help information
    -p, --position <POSITION>    Position to attempt a fix at
    -s, --stdin                  Enable "streaming" mode, accept file on stdin, output diagnostics
                                 on stdout
"""
    one = {
        "dump": ("executable-dump ", "Dump a sample config to stdout", "executable dump"),
        "explain": ("executable-explain ", "Print detailed explanation for a lint warning", "executable explain <TARGET>"),
        "list": ("executable-list ", "List all available lints", "executable list"),
    }.get(name)
    if one:
        title, desc, usage = one
        return f"{title}\n\n{desc}\n\nUSAGE:\n    {usage}\n\nOPTIONS:\n    -h, --help    Print help information\n"
    return top_help()


class Finding:
    def __init__(self, line, col, code, msg):
        self.line = line
        self.col = col
        self.code = code
        self.msg = msg


def is_word_char(c):
    return c.isalnum() or c in "_-'"


IDENT = r"[A-Za-z_][A-Za-z0-9_'-]*"
EXPR = r"[A-Za-z_][A-Za-z0-9_'.-]*"


def analyze(text, disabled=None):
    disabled = disabled or set()
    findings = []
    for ln, line in enumerate(text.splitlines(), 1):
        add_line_findings(findings, ln, line)
    return [f for f in findings if f.code not in disabled]


def add_finding(findings, line, col, code, msg):
    findings.append(Finding(line, col, code, msg))


def add_line_findings(findings, ln, line):
    for m in re.finditer(rf"(?<![=!])\b({EXPR})\s*(==|!=)\s*(true|false)\b", line):
        add_finding(findings, ln, m.start() + 1, 1, f"Comparing `{m.group(1)}` with boolean literal `{m.group(3)}`")
    for m in re.finditer(r"\blet\s+in\b", line):
        add_finding(findings, ln, m.start() + 1, 2, "This let-in expression has no entries")
    for m in re.finditer(rf"\b({IDENT})\s*=\s*\1\s*;", line):
        add_finding(findings, ln, m.start() + 1, 3, "This assignment is better written with `inherit`")
    for m in re.finditer(rf"\b({IDENT})\s*=\s*({EXPR})\.([A-Za-z_][A-Za-z0-9_'-]*)\s*;", line):
        if m.group(1) == m.group(3) and "." not in m.group(2):
            add_finding(findings, ln, m.start() + 1, 4, "This assignment is better written with `inherit`")
    for m in re.finditer(r"\blet\s*\{", line):
        add_finding(findings, ln, m.start() + 1, 5, "Prefer `rec` over undocumented `let` syntax")
    for m in re.finditer(rf"\(\s*({IDENT})\s*:\s*({IDENT})\s+\1\s*\)", line):
        add_finding(findings, ln, m.start() + 1, 7, f"Found eta-reduction: `{m.group(2)}`")
    for m in re.finditer(r"=\s*\(([^(){};]+)\)\s*;", line):
        add_finding(findings, ln, m.start(1), 8, "Useless parentheses around value in binding")
    for m in re.finditer(r"\{\s*\.\.\.\s*\}\s*:", line):
        add_finding(findings, ln, m.start() + 1, 10, "This pattern is empty, use `_` instead")
    for m in re.finditer(rf"\b({IDENT})\s*@\s*\{{\s*\.\.\.\s*\}}\s*:", line):
        add_finding(findings, ln, m.start() + 1, 11, f"This pattern bind is redundant, use `{m.group(1)}` instead")
    for m in re.finditer(r"(?<![\w\"/])([A-Za-z][A-Za-z0-9+.-]*:[A-Za-z0-9_./?=&%+#~:-]+)", line):
        if m.group(1).split(":", 1)[0] not in {"if", "then", "else"}:
            add_finding(findings, ln, m.start() + 1, 12, "Consider quoting this URI expression")
    for m in re.finditer(r"\binherit\s*;", line):
        add_finding(findings, ln, m.start() + 1, 14, "Remove this empty `inherit` statement")
    for m in re.finditer(r"\bbuiltins\.toPath\b", line):
        add_finding(findings, ln, m.start() + 1, 17, "`builtins.toPath` is deprecated, see `:doc builtins.toPath` within the REPL for more")
    for m in re.finditer(rf"!\(\s*({EXPR})\s*==\s*({EXPR})\s*\)", line):
        add_finding(findings, ln, m.start() + 1, 18, "Try `!=` instead of `!(... == ...)`")
    for m in re.finditer(rf"if\s+({EXPR})\s*\?\s*({IDENT})\s+then\s+\1\.\2\s+else\s+([^;]+)", line):
        add_finding(findings, ln, m.start() + 1, 19, f"Consider using `{m.group(1)}.{m.group(2)} or {m.group(3).strip()}` instead of this `if` expression")
    for m in re.finditer(r"\[\]\s*\+\+|\+\+\s*\[\]", line):
        add_finding(findings, ln, m.start() + 1, 23, "Concatenation with the empty list, `[]`, is a no-op")


def apply_fixes(text):
    out = text
    out = re.sub(rf"\b({EXPR})\s*==\s*true\b", r"\1", out)
    out = re.sub(rf"\b({EXPR})\s*!=\s*false\b", r"\1", out)
    out = re.sub(rf"\b({EXPR})\s*!=\s*true\b", r"!\1", out)
    out = re.sub(rf"\b({EXPR})\s*==\s*false\b", r"!\1", out)
    out = re.sub(r"\blet\s+in\s+", "", out)
    out = re.sub(rf"\b({IDENT})\s*=\s*\1\s*;", r"inherit \1;", out)
    out = re.sub(rf"\b({IDENT})\s*=\s*({EXPR})\.([A-Za-z_][A-Za-z0-9_'-]*)\s*;", manual_inherit_from, out)
    out = re.sub(r"\blet\s*\{\s*body\s*=\s*([^;]+);\s*([^{}]*)\}", legacy_let, out)
    out = re.sub(rf"\(\s*({IDENT})\s*:\s*({IDENT})\s+\1\s*\)", r"\2", out)
    out = re.sub(r"=\s*\(([^(){};]+)\)\s*;", lambda m: "= " + m.group(1).strip() + ";", out)
    out = re.sub(rf"\(\s*({IDENT})\s*@\s*\{{\s*\.\.\.\s*\}}\s*:\s*([^;\n]+)\)\s*;", r"\1: \2;", out)
    out = re.sub(rf"\b({IDENT})\s*@\s*\{{\s*\.\.\.\s*\}}\s*:\s*", r"\1: ", out)
    out = re.sub(r"\(\s*\{\s*\.\.\.\s*\}\s*:\s*([^;\n]+)\)\s*;", r"_: \1;", out)
    out = re.sub(r"\{\s*\.\.\.\s*\}\s*:\s*", "_: ", out)
    out = re.sub(r"(?<![\w\"/])([A-Za-z][A-Za-z0-9+.-]*:[A-Za-z0-9_./?=&%+#~:-]+)", quote_uri, out)
    out = re.sub(r"(?m)^[ \t]*inherit\s*;\n?", "", out)
    out = re.sub(rf"!\(\s*({EXPR})\s*==\s*({EXPR})\s*\)", r"\1 != \2", out)
    out = re.sub(rf"if\s+({EXPR})\s*\?\s*({IDENT})\s+then\s+\1\.\2\s+else\s+([^;\n]+)", r"\1.\2 or \3", out)
    out = re.sub(r"\[\]\s*\+\+\s*", "", out)
    out = re.sub(r"\s*\+\+\s*\[\]", "", out)
    return out


def manual_inherit_from(m):
    name, prefix, last = m.group(1), m.group(2), m.group(3)
    if name == last and "." not in prefix:
        return f"inherit ({prefix}) {name};"
    return m.group(0)


def legacy_let(m):
    body = m.group(1).strip()
    rest = m.group(2).strip()
    if rest:
        rest = "\n  " + rest.replace("; ", ";\n  ")
    return f"rec {{{rest}\n}}.body".replace("body = " + body + ";", "")


def quote_uri(m):
    s = m.group(1)
    if s.startswith(("http:", "https:", "github:", "gitlab:", "sourcehut:")):
        return f'"{s}"'
    return s


def iter_files(target):
    if not target:
        target = "."
    if os.path.isdir(target):
        for root, dirs, files in os.walk(target):
            dirs[:] = [d for d in dirs if d not in {".git", ".direnv"}]
            for name in files:
                if name.endswith(".nix"):
                    yield os.path.join(root, name)
    else:
        yield target


def parse_common(args):
    opts = {"stdin": False, "dry": False, "format": "stderr", "target": ".", "config": "."}
    i = 0
    rest = []
    while i < len(args):
        a = args[i]
        if a in ("-s", "--stdin"):
            opts["stdin"] = True
        elif a in ("-d", "--dry-run"):
            opts["dry"] = True
        elif a in ("-o", "--format"):
            i += 1
            opts["format"] = args[i] if i < len(args) else ""
        elif a.startswith("--format="):
            opts["format"] = a.split("=", 1)[1]
        elif a in ("-c", "--config"):
            i += 1
            if i < len(args):
                opts["config"] = args[i]
        elif a in ("-i", "--ignore", "-p", "--position"):
            i += 1
        elif a == "--":
            rest.extend(args[i + 1:])
            break
        elif a.startswith("-"):
            pass
        else:
            rest.append(a)
        i += 1
    if rest:
        opts["target"] = rest[-1]
    return opts


def disabled_from_config(conf_path):
    path = conf_path or "."
    if os.path.isdir(path):
        path = os.path.join(path, "statix.toml")
    if not os.path.exists(path):
        return set()
    try:
        data = open(path, encoding="utf-8").read()
    except OSError:
        return set()
    m = re.search(r"disabled\s*=\s*\[([^\]]*)\]", data, re.S)
    if not m:
        return set()
    disabled = set()
    for item in re.findall(r'"([^"]+)"|\'([^\']+)\'', m.group(1)):
        value = (item[0] or item[1]).strip()
        if value in NAME_TO_CODE:
            disabled.add(NAME_TO_CODE[value])
    return disabled


def cmd_check(args):
    if any(a in ("-h", "--help") for a in args):
        print(sub_help("check"), end="")
        return 0
    opts = parse_common(args)
    disabled = disabled_from_config(opts["config"])
    if opts["format"] not in ("stderr", "errfmt"):
        sys.stderr.write(f"error: Invalid value for '--format <FORMAT>': statix was not compiled with the `{opts['format']}` feature flag\n\nFor more information try --help\n")
        return 2
    if opts["stdin"]:
        text = sys.stdin.read()
        findings = analyze(text, disabled)
        emit_findings(findings, "<stdin>", opts["format"])
        return 1 if findings else 0
    any_findings = False
    for path in iter_files(opts["target"]):
        try:
            with open(path, encoding="utf-8") as f:
                text = f.read()
        except OSError as e:
            sys.stderr.write(f"error: {e}\n")
            return 1
        findings = analyze(text, disabled)
        emit_findings(findings, path, opts["format"])
        any_findings = any_findings or bool(findings)
    return 1 if any_findings else 0


def emit_findings(findings, path, fmt):
    for f in findings:
        if fmt == "errfmt":
            print(f"{path}>{f.line}:{f.col}:W:{f.code}:{f.msg}")
        else:
            print(f"[W{f.code:02d}] Warning: {f.msg}")


def cmd_fix(args):
    if any(a in ("-h", "--help") for a in args):
        print(sub_help("fix"), end="")
        return 0
    opts = parse_common(args)
    if opts["stdin"]:
        sys.stdout.write(apply_fixes(sys.stdin.read()))
        return 0
    for path in iter_files(opts["target"]):
        try:
            with open(path, encoding="utf-8") as f:
                old = f.read()
        except OSError:
            continue
        new = apply_fixes(old)
        if new == old:
            continue
        if opts["dry"]:
            sys.stdout.writelines(difflib.unified_diff(
                old.splitlines(True),
                new.splitlines(True),
                fromfile=path,
                tofile=path + " [fixed]",
            ))
            print()
        else:
            with open(path, "w", encoding="utf-8") as f:
                f.write(new)
    return 0


def cmd_single(args):
    if any(a in ("-h", "--help") for a in args):
        print(sub_help("single"), end="")
        return 0
    return cmd_fix(args)


def main(argv):
    if not argv or argv[0] in ("-h", "--help", "help"):
        print(top_help(), end="")
        return 0
    if argv[0] in ("-V", "--version"):
        print(VERSION)
        return 0
    cmd, args = argv[0], argv[1:]
    if cmd == "list":
        if any(a in ("-h", "--help") for a in args):
            print(sub_help("list"), end="")
        else:
            for code, name in LINTS:
                print(code, name)
        return 0
    if cmd == "dump":
        if any(a in ("-h", "--help") for a in args):
            print(sub_help("dump"), end="")
        else:
            print("disabled = []\nignore = ['.direnv']\n")
        return 0
    if cmd == "explain":
        if any(a in ("-h", "--help") for a in args) or not args:
            print(sub_help("explain"), end="")
            return 0
        target = args[0].upper()
        if not re.match(r"^W?\d+$", target):
            print("syntax error")
        else:
            if not target.startswith("W"):
                target = "W" + target.zfill(2)
            text = EXPLAINS.get(target)
            if text:
                print(text, end="")
            else:
                print(f"explain error: lint with code `{int(target[1:])}` not found")
        return 0
    if cmd == "check":
        return cmd_check(args)
    if cmd == "fix":
        return cmd_fix(args)
    if cmd == "single":
        return cmd_single(args)
    sys.stderr.write(f"error: Found argument '{cmd}' which wasn't expected, or isn't valid in this context\n\nUSAGE:\n    executable <SUBCOMMAND>\n\nFor more information try --help\n")
    return 2


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
