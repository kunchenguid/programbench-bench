#!/usr/bin/env python3
import os
import subprocess
import tempfile
import textwrap
import unittest


ROOT = os.path.dirname(os.path.abspath(__file__))
BIN = os.path.join(ROOT, "statix.py")


def run_cmd(args, input_text=None, cwd=None):
    return subprocess.run(
        ["python3", BIN] + args,
        input=input_text,
        text=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        cwd=cwd,
    )


class StatixCliTests(unittest.TestCase):
    def test_list_outputs_lint_catalog(self):
        proc = run_cmd(["list"])
        self.assertEqual(proc.returncode, 0)
        self.assertIn("W01 bool_comparison\n", proc.stdout)
        self.assertIn("W23 empty_list_concat\n", proc.stdout)

    def test_dump_outputs_default_config(self):
        proc = run_cmd(["dump"])
        self.assertEqual(proc.returncode, 0)
        self.assertEqual(proc.stdout, "disabled = []\nignore = ['.direnv']\n\n")

    def test_errfmt_check_reports_common_lints(self):
        with tempfile.TemporaryDirectory() as td:
            path = os.path.join(td, "sample.nix")
            with open(path, "w", encoding="utf-8") as f:
                f.write(textwrap.dedent("""\
                    {
                      a = x == true;
                      b = let in pkgs.statix;
                      x = y.x;
                    }
                    """))
            proc = run_cmd(["check", "--format", "errfmt", path])
        self.assertEqual(proc.returncode, 1)
        self.assertIn(">2:7:W:1:Comparing `x` with boolean literal `true`", proc.stdout)
        self.assertIn(">3:7:W:2:This let-in expression has no entries", proc.stdout)
        self.assertIn(">4:3:W:4:This assignment is better written with `inherit`", proc.stdout)

    def test_stdin_fix_rewrites_core_patterns(self):
        source = textwrap.dedent("""\
            {
              a = x == true;
              b = x != false;
              c = [] ++ something;
              d = if x ? a then x.a else def;
            }
            """)
        proc = run_cmd(["fix", "--stdin"], input_text=source)
        self.assertEqual(proc.returncode, 0)
        self.assertEqual(
            proc.stdout,
            textwrap.dedent("""\
                {
                  a = x;
                  b = x;
                  c = something;
                  d = x.a or def;
                }
                """),
        )

    def test_fix_dry_run_prints_unified_diff(self):
        with tempfile.TemporaryDirectory() as td:
            path = os.path.join(td, "sample.nix")
            with open(path, "w", encoding="utf-8") as f:
                f.write("let in pkgs.statix\n")
            proc = run_cmd(["fix", "--dry-run", path])
        self.assertEqual(proc.returncode, 0)
        self.assertIn("--- ", proc.stdout)
        self.assertIn("+++ ", proc.stdout)
        self.assertIn("-let in pkgs.statix", proc.stdout)
        self.assertIn("+pkgs.statix", proc.stdout)
        self.assertTrue(proc.stdout.endswith("\n\n"))

    def test_config_disables_lints_by_name(self):
        with tempfile.TemporaryDirectory() as td:
            with open(os.path.join(td, "statix.toml"), "w", encoding="utf-8") as f:
                f.write('disabled = ["bool_comparison", "manual_inherit_from"]\n')
            path = os.path.join(td, "sample.nix")
            with open(path, "w", encoding="utf-8") as f:
                f.write("{\n  a = x == true;\n  x = y.x;\n}\n")
            proc = run_cmd(["check", "--format", "errfmt", "--config", td, path])
        self.assertEqual(proc.returncode, 0)
        self.assertEqual(proc.stdout, "")

    def test_stdin_fix_rewrites_patterns_from_lint_catalog(self):
        source = textwrap.dedent("""\
            {
              f = let { body = x + y; x = 2; y = 3; };
              g = map (x: double x) [ 1 2 3 ];
              h = (2 + 3);
              i = ({ ... }: 1);
              j = (inputs @ { ... }: inputs.nixpkgs);
              k = github:hercules-ci/gitignore.nix;
              n = !(x == y);
            }
            """)
        proc = run_cmd(["fix", "--stdin"], input_text=source)
        self.assertEqual(proc.returncode, 0)
        self.assertIn("f = rec {", proc.stdout)
        self.assertIn("g = map double [ 1 2 3 ];", proc.stdout)
        self.assertIn("h = 2 + 3;", proc.stdout)
        self.assertIn("i = _: 1;", proc.stdout)
        self.assertIn("j = inputs: inputs.nixpkgs;", proc.stdout)
        self.assertIn('k = "github:hercules-ci/gitignore.nix";', proc.stdout)
        self.assertIn("n = x != y;", proc.stdout)


if __name__ == "__main__":
    unittest.main()
