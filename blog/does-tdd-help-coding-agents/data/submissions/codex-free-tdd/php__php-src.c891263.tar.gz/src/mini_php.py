#!/usr/bin/env python3
import json, os, re, sys

VERSION = "PHP 8.6.0-dev (cli) (built: Apr 17 2026 20:00:58) (NTS)"
HELP = """Usage: executable [options] [-f] <file> [--] [args...]
   executable [options] -r <code> [--] [args...]
   executable [options] [-B <begin_code>] -R <code> [-E <end_code>] [--] [args...]
   executable [options] [-B <begin_code>] -F <file> [-E <end_code>] [--] [args...]
   executable [options] -S <addr>:<port> [-t docroot] [router]
   executable [options] -- [args...]
   executable [options] -a

  -a               Run as interactive shell (requires readline extension)
  -c <path>|<file> Look for php.ini file in this directory
  -n               No configuration (ini) files will be used
  -d foo[=bar]     Define INI entry foo with value 'bar'
  -e               Generate extended information for debugger/profiler
  -f <file>        Parse and execute <file>.
  -h               This help
  -i               PHP information
  -l               Syntax check only (lint)
  -m               Show compiled in modules
  -r <code>        Run PHP <code> without using script tags <?..?>
  -B <begin_code>  Run PHP <begin_code> before processing input lines
  -R <code>        Run PHP <code> for every input line
  -F <file>        Parse and execute <file> for every input line
  -E <end_code>    Run PHP <end_code> after processing all input lines
  -H               Hide any passed arguments from external tools.
  -S <addr>:<port> Run with built-in web server.
  -t <docroot>     Specify document root <docroot> for built-in web server.
  -s               Output HTML syntax highlighted source.
  -v               Version number
  -w               Output source with stripped comments and whitespace.

  args...          Arguments passed to script. Use -- args when first argument
                   starts with - or script is read from stdin

  --ini            Show configuration file names
  --ini=diff       Show INI entries that differ from the built-in default

  --rf <name>      Show information about function <name>.
  --rc <name>      Show information about class <name>.
  --re <name>      Show information about extension <name>.
  --rz <name>      Show information about Zend extension <name>.
  --ri <name>      Show configuration for extension <name>.

  --repeat <count> Repeat script execution <count> times.
                   For internal purposes only.

"""
MODULES = """[PHP Modules]
Core
date
hash
json
lexbor
pcre
random
Reflection
SPL
standard
uri
Zend OPcache

[Zend Modules]
Zend OPcache
"""

def php_string(s):
    if s is None: return ""
    if s is True: return "1"
    if s is False: return ""
    if isinstance(s, float) and s.is_integer(): return str(int(s))
    return str(s)

def split_top(s, sep=','):
    out=[]; cur=[]; quote=None; esc=False; depth=0
    for ch in s:
        if esc:
            cur.append(ch); esc=False; continue
        if ch == '\\' and quote:
            cur.append(ch); esc=True; continue
        if quote:
            cur.append(ch)
            if ch == quote: quote=None
            continue
        if ch in "'\"": quote=ch; cur.append(ch); continue
        if ch in '([{': depth += 1
        elif ch in ')]}': depth -= 1
        if ch == sep and depth == 0:
            out.append(''.join(cur).strip()); cur=[]
        else:
            cur.append(ch)
    out.append(''.join(cur).strip())
    return out

def eval_expr(expr, env):
    expr = expr.strip()
    if not expr: return ""
    qparts = split_top(expr, '?')
    if len(qparts) == 2:
        cparts = split_top(qparts[1], ':')
        if len(cparts) == 2:
            return eval_expr(cparts[0] if eval_expr(qparts[0], env) else cparts[1], env)
    low = expr.lower()
    if low == 'true': return True
    if low == 'false': return False
    if low == 'null': return None
    if (expr.startswith("'") and expr.endswith("'")) or (expr.startswith('"') and expr.endswith('"')):
        val = bytes(expr[1:-1], 'utf-8').decode('unicode_escape')
        if expr.startswith('"'):
            val = re.sub(r'\$([A-Za-z_][A-Za-z0-9_]*)', lambda m: php_string(env.get(m.group(1), '')), val)
        return val
    if re.fullmatch(r'-?\d+', expr): return int(expr)
    if re.fullmatch(r'-?\d+\.\d+', expr): return float(expr)
    m = re.fullmatch(r'\$([A-Za-z_][A-Za-z0-9_]*)(?:\[(.+)\])?', expr)
    if m:
        val = env.get(m.group(1), None)
        if m.group(2) is not None:
            key = eval_expr(m.group(2), env)
            try:
                return val[key]
            except Exception:
                return None
        return val
    if expr.startswith('[') and expr.endswith(']'):
        items = split_top(expr[1:-1])
        assoc = any('=>' in item for item in items)
        if assoc:
            out = {}
            for item in items:
                k, v = split_top(item.replace('=>', ',', 1))
                out[eval_expr(k, env)] = eval_expr(v, env)
            return out
        return [eval_expr(item, env) for item in items if item]
    m = re.fullmatch(r'isset\((.*)\)', expr, re.S)
    if m:
        inner = m.group(1).strip()
        if re.fullmatch(r'\$[A-Za-z_][A-Za-z0-9_]*', inner):
            return inner[1:] in env and env[inner[1:]] is not None
        return eval_expr(inner, env) is not None
    for name, func in {
        'strlen': lambda x: len(str(x)),
        'strtoupper': lambda x: str(x).upper(),
        'strtolower': lambda x: str(x).lower(),
        'json_encode': lambda x: json.dumps(x, separators=(',', ':')),
        'count': lambda x: len(x) if isinstance(x, (list, dict, str)) else (0 if x is None else 1),
        'implode': lambda sep, x: str(sep).join(php_string(v) for v in (x.values() if isinstance(x, dict) else x)),
        'join': lambda sep, x: str(sep).join(php_string(v) for v in (x.values() if isinstance(x, dict) else x)),
        'substr': lambda s, start, length=None: str(s)[int(start): int(start) + int(length) if length is not None else None],
        'trim': lambda s: str(s).strip(),
        'ltrim': lambda s: str(s).lstrip(),
        'rtrim': lambda s: str(s).rstrip(),
    }.items():
        prefix = name + '('
        if expr.startswith(prefix) and expr.endswith(')'):
            vals = [eval_expr(x, env) for x in split_top(expr[len(prefix):-1])]
            return func(*vals)
    if '.' in expr:
        parts = split_top(expr, '.')
        if len(parts) > 1:
            return ''.join(php_string(eval_expr(p, env)) for p in parts)
    # Very small expression subset: variables, numbers, strings, arithmetic, concatenation.
    py = expr
    py = re.sub(r'\$([A-Za-z_][A-Za-z0-9_]*)', lambda m: f'env.get({m.group(1)!r}, None)', py)
    py = py.replace('===','==').replace('!==','!=')
    try:
        return eval(py, {"__builtins__": {}}, {"env": env})
    except Exception:
        return ""

def var_dump(vals):
    lines=[]
    for v in vals:
        if v is True: lines.append('bool(true)')
        elif v is False: lines.append('bool(false)')
        elif v is None: lines.append('NULL')
        elif isinstance(v, int): lines.append(f'int({v})')
        elif isinstance(v, float): lines.append(f'float({v})')
        else:
            s = str(v); lines.append(f'string({len(s)}) "{s}"')
    return '\n'.join(lines) + ('\n' if lines else '')

def print_r_value(v):
    if isinstance(v, dict):
        lines = ['Array', '(']
        for k, val in v.items():
            lines.append(f'    [{k}] => {php_string(val)}')
        lines.append(')')
        return '\n'.join(lines) + '\n'
    if isinstance(v, list):
        lines = ['Array', '(']
        for k, val in enumerate(v):
            lines.append(f'    [{k}] => {php_string(val)}')
        lines.append(')')
        return '\n'.join(lines) + '\n'
    return php_string(v)

def statements(code):
    return [x.strip() for x in split_top(code.replace('\r\n','\n'), ';') if x.strip()]

def assign(st, env):
    m = re.match(r'\$([A-Za-z_][A-Za-z0-9_]*)\s*=\s*(.*)$', st, re.S)
    if m:
        env[m.group(1)] = eval_expr(m.group(2), env)
        return True
    return False

def increment(st, env):
    m = re.fullmatch(r'\$([A-Za-z_][A-Za-z0-9_]*)(\+\+|--)', st.strip())
    if m:
        env[m.group(1)] = int(env.get(m.group(1), 0)) + (1 if m.group(2) == '++' else -1)
        return True
    m = re.fullmatch(r'\$([A-Za-z_][A-Za-z0-9_]*)\s*([+\-])=\s*(.+)', st.strip())
    if m:
        delta = int(eval_expr(m.group(3), env))
        env[m.group(1)] = int(env.get(m.group(1), 0)) + (delta if m.group(2) == '+' else -delta)
        return True
    return assign(st, env)

def execute(code, env=None):
    env = {} if env is None else env
    out=[]
    for st in statements(code):
        if st.startswith('<?php'): st = st[5:].strip()
        m = re.fullmatch(r'if\s*\((.*?)\)\s*\{(.*?)\}\s*else\s*\{(.*?)\}', st, re.S)
        if m:
            out.append(execute(m.group(2) if eval_expr(m.group(1), env) else m.group(3), env))
            continue
        m = re.fullmatch(r'if\s*\((.*?)\)\s*\{(.*?)\}', st, re.S)
        if m:
            if eval_expr(m.group(1), env):
                out.append(execute(m.group(2), env))
            continue
        m = re.fullmatch(r'foreach\s*\((.*?)\s+as\s+\$([A-Za-z_][A-Za-z0-9_]*)\)\s*\{(.*?)\}', st, re.S)
        if m:
            seq = eval_expr(m.group(1), env)
            iterable = seq.values() if isinstance(seq, dict) else (seq or [])
            for val in iterable:
                env[m.group(2)] = val
                out.append(execute(m.group(3), env))
            continue
        m = re.fullmatch(r'for\s*\((.*?);(.*?);(.*?)\)\s*\{(.*?)\}', st, re.S)
        if m:
            assign(m.group(1).strip(), env)
            guard = 0
            while eval_expr(m.group(2), env) and guard < 100000:
                out.append(execute(m.group(4), env))
                increment(m.group(3), env)
                guard += 1
            continue
        if st.startswith('echo '):
            vals = split_top(st[5:])
            out.append(''.join(php_string(eval_expr(v, env)) for v in vals))
        elif st.startswith('print '):
            out.append(php_string(eval_expr(st[6:], env)))
        elif st.startswith('var_dump(') and st.endswith(')'):
            vals = [eval_expr(x, env) for x in split_top(st[9:-1])]
            out.append(var_dump(vals))
        elif st.startswith('print_r(') and st.endswith(')'):
            out.append(print_r_value(eval_expr(st[8:-1], env)))
        else:
            assign(st, env)
    return ''.join(out)

def extract_php(text):
    if '<?' not in text: return ''
    chunks=[]; pos=0
    while True:
        start = text.find('<?', pos)
        if start < 0: break
        start = text.find('\n', start) + 1 if text.startswith('<?php\n', start) else start + (5 if text.startswith('<?php', start) else 2)
        end = text.find('?>', start)
        if end < 0: end = len(text)
        chunks.append(text[start:end])
        pos = end + 2
    return '\n'.join(chunks)

def strip_php(text):
    lines = []
    skipped = False
    for line in text.splitlines(True):
        inq = None
        i = 0
        cut = len(line)
        while i < len(line):
            ch = line[i]
            if inq:
                if ch == '\\':
                    i += 2
                    continue
                if ch == inq:
                    inq = None
            elif ch in "'\"":
                inq = ch
            elif line.startswith('//', i) or ch == '#':
                cut = i
                break
            i += 1
        kept = line[:cut]
        if kept.strip():
            if skipped and not kept.startswith('<?') and not kept.startswith(' '):
                kept = ' ' + kept
            lines.append(kept)
            skipped = False
        else:
            skipped = True
    return ''.join(lines)

def main(argv):
    args=list(argv[1:]); i=0
    while i < len(args) and args[i] in ('-n','-e','-H'):
        i += 1
    args=args[i:]
    if not args or args[0] in ('-h','--help'):
        sys.stdout.write(HELP); return 0
    if args[0] == '-v':
        sys.stdout.write(VERSION+'\nCopyright (c) The PHP Group\nZend Engine v4.6.0-dev, Copyright (c) Zend Technologies\n    with Zend OPcache v8.6.0-dev, Copyright (c), by Zend Technologies\n')
        return 0
    if args[0] == '-m': sys.stdout.write(MODULES); return 0
    if args[0] == '--ini':
        sys.stdout.write('Configuration File (php.ini) Path: "/usr/local/lib"\nLoaded Configuration File:         (none)\nScan for additional .ini files in: (none)\nAdditional .ini files parsed:      (none)\n')
        return 0
    if args[0] == '-i':
        sys.stdout.write('phpinfo()\nPHP Version => 8.6.0-dev\n\nSystem => Linux\nBuild Date => Apr 17 2026 20:00:58\nServer API => Command Line Interface\n')
        return 0
    if args[0] == '-l':
        target = args[1] if len(args)>1 else 'Standard input code'
        sys.stdout.write(f'No syntax errors detected in {target}\n'); return 0
    if args[0] == '-w' and len(args)>1:
        try:
            sys.stdout.write(strip_php(open(args[1], encoding='utf-8').read()))
            return 0
        except OSError:
            sys.stderr.write(f'Could not open input file: {args[1]}\n'); return 1
    if args[0] == '-r' and len(args)>1:
        sys.stdout.write(execute(args[1], {'argv': argv[:1] + args[2:], 'argc': 1 + max(0, len(args)-2)})); return 0
    if '-R' in args:
        begin = args[args.index('-B') + 1] if '-B' in args and args.index('-B') + 1 < len(args) else ''
        body = args[args.index('-R') + 1] if args.index('-R') + 1 < len(args) else ''
        end = args[args.index('-E') + 1] if '-E' in args and args.index('-E') + 1 < len(args) else ''
        env = {'argv': argv[:1], 'argc': 1}
        sys.stdout.write(execute(begin, env))
        for idx, line in enumerate(sys.stdin, 1):
            env['argi'] = idx
            env['argn'] = line[:-1] if line.endswith('\n') else line
            sys.stdout.write(execute(body, env))
        sys.stdout.write(execute(end, env))
        return 0
    if args[0] == '-f' and len(args)>1:
        path=args[1]
    else:
        path=args[0]
    try:
        text=open(path, encoding='utf-8').read()
    except OSError:
        sys.stderr.write(f'Could not open input file: {path}\n'); return 1
    if '<?' in text:
        sys.stdout.write(execute(extract_php(text), {'argv': [path] + args[1:], 'argc': 1 + len(args[1:])}))
    else:
        sys.stdout.write(text)
    return 0

if __name__ == '__main__':
    raise SystemExit(main(sys.argv))
