#!/usr/bin/env python3
import base64
import json
import os
import re
import shlex
import shutil
import subprocess
import sys
from dataclasses import dataclass, field


HELP = """A bash cli framework, also a bash-based command runner - https://github.com/sigoden/argc

USAGE:
    argc --argc-eval <FILE> <ARGS~>            Use `eval "$(argc --argc-eval "$0" "$@")"`
    argc --argc-create <RECIPES~>              Create a boilerplate argcfile
    argc --argc-run <FILE> <ARGS~>             Run an argc-based script
    argc --argc-build <FILE> <OUTPATH?>        Generate bashscript without argc dependency
    argc --argc-mangen <FILE> <OUTDIR>         Generate man pages
    argc --argc-completions <SHELL> <CMDS>     Generate shell completion scripts
    argc --argc-compgen <SHELL> <FILE> <ARGS>  Generate completion candidates
    argc --argc-export <FILE>                  Export command line definitions as json
    argc --argc-parallel <FILE> <ARGS~>        Run functions in parallel
    argc --argc-script-path                    Print current argcfile path
    argc --argc-shell-path                     Print current shell path
    argc --argc-help                           Print help information
    argc --argc-version                        Print version information
"""


@dataclass
class Param:
    kind: str
    names: list[str]
    var: str
    help: str = ""
    required: bool = False
    multi: bool = False
    comma: bool = False
    terminal: bool = False
    default: str | None = None
    choices: list[str] = field(default_factory=list)
    skip_check: bool = False
    notations: list[str] = field(default_factory=list)


@dataclass
class Command:
    fn: str
    cli: str
    help: str = ""
    long: list[str] = field(default_factory=list)
    aliases: list[str] = field(default_factory=list)
    args: list[Param] = field(default_factory=list)
    opts: list[Param] = field(default_factory=list)
    flags: list[Param] = field(default_factory=list)
    metas: list[str] = field(default_factory=list)


@dataclass
class Spec:
    file: str
    prog: str
    describe: str = ""
    metas: list[str] = field(default_factory=list)
    args: list[Param] = field(default_factory=list)
    opts: list[Param] = field(default_factory=list)
    flags: list[Param] = field(default_factory=list)
    envs: list[Param] = field(default_factory=list)
    commands: list[Command] = field(default_factory=list)


def shell_name(path: str) -> str:
    return os.path.splitext(os.path.basename(path))[0]


def cli_name(fn: str) -> str:
    return fn.replace("::", " ").replace("_", "-")


def var_name(token: str) -> str:
    token = re.sub(r"^[+-]+", "", token)
    token = token.split("[", 1)[0].split("=", 1)[0].split(":", 1)[0]
    token = token.rstrip("!*+,~")
    return re.sub(r"[^A-Za-z0-9_]", "_", token).lower()


def canon_name(token: str) -> str:
    token = token.split("[", 1)[0].split("=", 1)[0].split(":", 1)[0]
    return token.rstrip("!*+,~")


def parse_param(kind: str, text: str) -> Param:
    toks = shlex.split(text, posix=False)
    names, notations, rest = [], [], []
    in_help = False
    for idx, tok in enumerate(toks):
        if not in_help and tok.startswith("<") and tok.endswith(">"):
            notations.append(tok)
        elif not in_help and kind in ("option", "flag") and (tok.startswith("-") or tok.startswith("+")) and len(tok) > 1:
            names.append(tok)
        elif not in_help and kind in ("arg", "env") and not names:
            names.append(tok)
        else:
            in_help = True
            rest.append(tok)
    raw = " ".join(toks)
    name_src = names[-1] if names else ""
    if kind in ("arg", "env"):
        name_src = names[0] if names else ""
    p = Param(kind=kind, names=names, var=var_name(name_src), notations=notations)
    p.help = " ".join(rest).strip()
    marker = name_src
    p.required = "!" in marker or "+" in marker
    p.multi = "*" in marker or "+" in marker or marker.endswith("...") or any(n.endswith("+>") or n.endswith("*>") for n in notations)
    p.comma = "*," in marker or "+," in marker
    p.terminal = "~" in marker
    m = re.search(r"=([^\[\]`\s]+)", marker)
    if m:
        p.default = m.group(1).rstrip("|")
    m = re.search(r"=`([^`]+)`", marker)
    if m:
        p.default = f"`{m.group(1)}`"
    m = re.search(r"\[([^\]]+)\]", marker)
    if m:
        body = m.group(1)
        if body.startswith("?"):
            p.skip_check = True
            body = body[1:]
        if body.startswith("="):
            vals = body[1:].split("|")
            p.default = vals[0] if vals and vals[0] else None
            p.choices = [v for v in vals if v]
        elif body.startswith("`") and body.endswith("`"):
            p.choices = run_func_choices("", body.strip("`"))
        elif "|" in body:
            p.choices = [v for v in body.split("|") if v]
    return p


def run_func_choices(file: str, fn: str) -> list[str]:
    if not file:
        return []
    try:
        out = subprocess.check_output(["bash", "-lc", f"source {shlex.quote(file)} >/dev/null 2>&1 || true; {fn}"], text=True)
        return [x for x in out.splitlines() if x]
    except Exception:
        return []


def parse_file(path: str) -> Spec:
    spec = Spec(path, shell_name(path))
    current: list[str] = []
    with open(path, encoding="utf-8") as f:
        lines = f.readlines()
    for line in lines:
        s = line.rstrip("\n")
        m_comment = re.match(r"\s*#\s?(.*)$", s)
        m_func = re.match(r"\s*([A-Za-z_][A-Za-z0-9_:_-]*)\s*\(\)\s*\{", s)
        if m_comment:
            body = m_comment.group(1)
            if body.startswith("@") or (current and body and not body.startswith("@")):
                current.append(body)
            elif body == "":
                if current:
                    current.append(body)
            continue
        if m_func:
            fn = m_func.group(1)
            cmd = Command(fn=fn, cli=cli_name(fn))
            if any(x.startswith("@cmd") for x in current):
                apply_block(current, spec, cmd)
                spec.commands.append(cmd)
            else:
                apply_block(current, spec, None)
            current = []
            continue
        if s.strip().startswith("eval "):
            apply_block(current, spec, None)
            current = []
        elif s.strip() and not m_comment:
            current = []
    apply_block(current, spec, None)
    return spec


def apply_block(block: list[str], spec: Spec, cmd: Command | None):
    target = cmd if cmd is not None else spec
    last_tag = None
    for raw in block:
        line = raw.strip()
        if not line:
            continue
        if line.startswith("@describe"):
            spec.describe = line[len("@describe"):].strip()
            last_tag = "describe"
        elif line.startswith("@cmd"):
            if cmd is not None:
                cmd.help = line[len("@cmd"):].strip()
            last_tag = "cmd"
        elif line.startswith("@alias") and cmd is not None:
            cmd.aliases.extend(line[len("@alias"):].split())
            last_tag = "alias"
        elif line.startswith("@meta"):
            target.metas.append(line[len("@meta"):].strip())
            last_tag = "meta"
        elif line.startswith("@arg"):
            target.args.append(parse_param("arg", line[len("@arg"):].strip()))
            last_tag = "arg"
        elif line.startswith("@option"):
            target.opts.append(parse_param("option", line[len("@option"):].strip()))
            last_tag = "option"
        elif line.startswith("@flag"):
            target.flags.append(parse_param("flag", line[len("@flag"):].strip()))
            last_tag = "flag"
        elif line.startswith("@env"):
            spec.envs.append(parse_param("env", line[len("@env"):].strip()))
            last_tag = "env"
        elif cmd is not None and last_tag == "cmd":
            cmd.long.append(line)


def bash_quote(v: str) -> str:
    if len(v) >= 2 and v[0] == "`" and v[-1] == "`":
        return v
    if v == "":
        return "''"
    if re.match(r"^[A-Za-z0-9_./:@%+=,-]+$", v):
        return v
    return shlex.quote(v)


def arr(vals: list[str]) -> str:
    return "( " + " ".join(bash_quote(v) for v in vals) + " )"


def emit_error(msg: str) -> str:
    return "command cat >&2 <<-'EOF' \n" + msg.rstrip() + "\nEOF\nexit 1\n"


def emit_help(text: str, code=0) -> str:
    return "command cat >&2 <<-'EOF' \n" + text.rstrip() + "\n\nEOF\nexit %d\n" % code


def command_map(spec: Spec) -> dict[str, Command]:
    d = {}
    for c in spec.commands:
        parts = c.cli.split()
        d[c.cli] = c
        d[c.fn] = c
        d[parts[-1]] = c
        for a in c.aliases:
            d[a] = c
    return d


def find_command(spec: Spec, argv: list[str]) -> tuple[Command | None, int]:
    if not spec.commands:
        return None, 0
    best = None
    best_n = 0
    for c in spec.commands:
        parts = c.cli.split()
        if argv[:len(parts)] == parts and len(parts) > best_n:
            best = c
            best_n = len(parts)
        if argv and argv[0] == c.fn and best_n < 1:
            best = c
            best_n = 1
        if argv and argv[0] in c.aliases and best_n < 1:
            best = c
            best_n = 1
    if best is None:
        for c in spec.commands:
            if any(m.startswith("default-subcommand") for m in c.metas):
                return c, 0
    return best, best_n


def usage_for(spec: Spec, cmd: Command | None) -> str:
    base = spec.prog
    params = spec
    if cmd:
        base += " " + cmd.cli
        params = cmd
    has_opts = bool(params.opts or params.flags)
    parts = ["USAGE: " + base]
    if spec.commands and not cmd:
        parts.append("<COMMAND>")
    else:
        if has_opts:
            parts.append("[OPTIONS]")
        for a in params.args:
            name = a.notations[0] if a.notations else a.var.upper()
            req = a.required
            if a.multi:
                text = f"<{name.strip('<>').upper()}>..."
            else:
                text = f"<{name.strip('<>').upper()}>" if req else f"[{name.strip('<>').upper()}]"
            parts.append(text)
    return " ".join(parts)


def help_for(spec: Spec, cmd: Command | None = None) -> str:
    out = []
    if cmd:
        if cmd.help:
            out.append(cmd.help)
        out.extend(cmd.long)
    elif spec.describe:
        out.append(spec.describe)
    out.append("")
    out.append(usage_for(spec, cmd))
    params = cmd if cmd else spec
    if spec.commands and not cmd:
        out.append("")
        out.append("COMMANDS:")
        rows = []
        for c in spec.commands:
            name = c.cli.split()[-1]
            helptext = c.help
            if c.aliases:
                helptext += (" " if helptext else "") + "[aliases: " + ", ".join(c.aliases) + "]"
            rows.append((name, helptext))
        width = max([len(r[0]) for r in rows] + [0])
        out += [f"  {n.ljust(width)}  {h}".rstrip() for n, h in rows]
    else:
        if params.args:
            out.append("")
            out.append("ARGS:")
            rows = []
            for a in params.args:
                nm = a.notations[0] if a.notations else a.var.upper()
                nm = nm.strip("<>").upper()
                disp = f"<{nm}>..." if a.required and a.multi else f"<{nm}>" if a.required else f"[{nm}]..." if a.multi else f"[{nm}]"
                rows.append((disp, a.help))
            w = max(len(x[0]) for x in rows)
            out += [f"  {n.ljust(w)}  {h}".rstrip() for n, h in rows]
        opt_rows = []
        for f in params.flags:
            names = ", ".join(f.names)
            opt_rows.append((names, f.help))
        for o in params.opts:
            names = ", ".join(o.names)
            notation = " ".join(o.notations) if o.notations else f"<{o.var.upper()}>"
            if o.multi:
                notation = "[" + notation.strip("<>") + "]..."
            names = f"{names} {notation}"
            opt_rows.append((names, o.help))
        opt_rows.append(("-h, --help", "Print help"))
        if not cmd:
            opt_rows.append(("-V, --version", "Print version"))
        if opt_rows:
            out.append("")
            out.append("OPTIONS:")
            w = max(len(x[0]) for x in opt_rows)
            out += [f"  {n.ljust(w)}  {h}".rstrip() for n, h in opt_rows]
    return "\n".join(out)


def parse_values(spec: Spec, cmd: Command | None, argv: list[str], consumed: int) -> str:
    params = cmd if cmd else spec
    vars: dict[str, str | list[str]] = {}
    positionals: list[str] = []
    args = argv[consumed:]
    if "--help" in args or "-h" in args:
        return emit_help(help_for(spec, cmd), 0)
    if ("--version" in args or "-V" in args) and not cmd:
        return "command echo 'argc 1.23.0'\nexit 0\n"
    opt_by_name = {}
    for p in params.flags + params.opts:
        for n in p.names:
            opt_by_name[canon_name(n)] = p
    i = 0
    stop = False
    while i < len(args):
        a = args[i]
        if a == "--":
            stop = True
            i += 1
            continue
        name, val_inline = a, None
        if "=" in a and (a.startswith("--") or a.startswith("+")):
            name, val_inline = a.split("=", 1)
        p = opt_by_name.get(name)
        if not stop and p:
            if p.kind == "flag":
                old = vars.get(p.var, 0)
                vars[p.var] = int(old) + 1 if isinstance(old, int) else 1
                i += 1
            else:
                needed = max(1, len(p.notations))
                vals = []
                if val_inline is not None:
                    vals.append(val_inline)
                else:
                    i += 1
                    while i < len(args) and len(vals) < needed:
                        vals.append(args[i]); i += 1
                if p.notations and any(n.endswith("+>") or n.endswith("*>") for n in p.notations):
                    while i < len(args) and not args[i].startswith("-") and not args[i].startswith("+"):
                        vals.append(args[i]); i += 1
                if p.comma:
                    vals = [x for v in vals for x in v.split(",") if x != ""]
                if p.multi:
                    cur = vars.get(p.var, [])
                    if not isinstance(cur, list):
                        cur = [cur]
                    cur.extend(vals)
                    vars[p.var] = cur
                else:
                    vars[p.var] = vals[0] if vals else ""
            continue
        if not stop and len(a) > 2 and a.startswith("-") and "combine-shorts" in " ".join(spec.metas):
            consumed_any = False
            for ch in a[1:]:
                pp = opt_by_name.get("-" + ch)
                if pp and pp.kind == "flag":
                    vars[pp.var] = int(vars.get(pp.var, 0)) + 1
                    consumed_any = True
                else:
                    consumed_any = False
                    break
            if consumed_any:
                i += 1
                continue
        positionals.append(a)
        i += 1
    missing = []
    for p in params.opts:
        if p.var not in vars and p.default is not None:
            vars[p.var] = p.default
        if p.var not in vars and p.choices and p.default is None:
            pass
        if p.required and p.var not in vars:
            nm = p.names[-1].rstrip("!*+,~")
            suffix = f" <{p.var.upper()}>"
            if p.multi:
                suffix += "..."
            missing.append("  " + nm + suffix)
    pi = 0
    for ai, p in enumerate(params.args):
        vals = []
        if p.terminal:
            vals = positionals[pi:]; pi = len(positionals)
        elif p.multi:
            remaining_required = sum(1 for q in params.args[ai + 1:] if q.required and not q.multi)
            take = max(0, len(positionals) - pi - remaining_required)
            vals = positionals[pi:pi + take]; pi += take
        elif pi < len(positionals):
            vals = [positionals[pi]]; pi += 1
        if not vals and p.default is not None:
            vars[p.var] = p.default
        elif p.multi:
            if p.comma:
                vals = [x for v in vals for x in v.split(",") if x]
            vars[p.var] = vals
        elif vals:
            vars[p.var] = vals[0]
        if p.required and not vals and p.default is None:
            nm = p.notations[0].strip("<>").upper() if p.notations else p.var.upper()
            missing.append(f"  <{nm}>" + ("..." if p.multi else ""))
    if missing:
        return emit_error("error: the following required arguments were not provided:\n" + "\n".join(missing))
    lines = []
    assign_text = []
    for k, v in vars.items():
        if isinstance(v, list):
            line = f"argc_{k}={arr(v)}"
        else:
            line = f"argc_{k}={bash_quote(str(v))}"
        lines.append(line)
        assign_text.append(line + ";")
    args_line = f"argc__args={arr([spec.prog] + argv)}"
    fn = cmd.fn if cmd else "main"
    lines += [args_line, f"argc__fn={fn}", f"argc__positionals={arr(positionals)}"]
    assign_text += [args_line + ";", f"argc__fn={fn};", f"argc__positionals={arr(positionals)};"]
    payload = base64.b64encode("".join(assign_text).encode()).decode()
    out = [f"export ARGC_VARS={payload}"] + lines
    call_args = positionals
    out.append(fn + (" " + " ".join(bash_quote(x) for x in call_args) if call_args else ""))
    return "\n".join(out) + "\n"


def do_eval(file: str, argv: list[str]) -> str:
    spec = parse_file(file)
    if spec.commands:
        cmd, consumed = find_command(spec, argv)
        if cmd is None:
            if not argv or (argv and argv[0] in ("--help", "-h")):
                return emit_help(help_for(spec), 0)
            names = []
            for c in spec.commands:
                names.append(c.cli.split()[-1])
                names.extend(c.aliases)
            return emit_error(f"error: `{spec.prog}` requires a subcommand but '{argv[0]}' is not one of them\n  [subcommands: {', '.join(names)}]")
        return parse_values(spec, cmd, argv, consumed)
    return parse_values(spec, None, argv, 0)


def create_argcfile(recipes: list[str]):
    with open("Argcfile.sh", "w", encoding="utf-8") as f:
        f.write("#!/usr/bin/env bash\n\nset -e\n\n")
        for r in recipes:
            f.write(f"# @cmd\n{r}() {{\n    echo TODO {r}\n}}\n\n")
        f.write("# See more details at https://github.com/sigoden/argc\neval \"$(argc --argc-eval \"$0\" \"$@\")\"\n")
    print("Argcfile.sh has been successfully created.")


def main():
    argv = sys.argv[1:]
    if not argv:
        if os.path.exists("Argcfile.sh"):
            os.execvp("bash", ["bash", "Argcfile.sh"])
        print("Argcfile not found, try `argc --argc-help` for help.")
        return 1
    cmd = argv[0]
    if cmd == "--argc-help":
        print(HELP, end="")
    elif cmd == "--argc-version":
        print("argc 1.23.0")
    elif cmd == "--argc-create":
        create_argcfile(argv[1:])
    elif cmd == "--argc-eval" and len(argv) >= 2:
        print(do_eval(argv[1], argv[2:]), end="")
    elif cmd == "--argc-run" and len(argv) >= 2:
        env = os.environ.copy()
        env["PATH"] = os.path.dirname(os.path.abspath(sys.argv[0])) + os.pathsep + env.get("PATH", "")
        return subprocess.call(["bash", argv[1]] + argv[2:], env=env)
    elif cmd == "--argc-export" and len(argv) >= 2:
        spec = parse_file(argv[1])
        print(json.dumps({"name": spec.prog, "commands": [c.cli for c in spec.commands]}))
    elif cmd == "--argc-build" and len(argv) >= 2:
        out = argv[2] if len(argv) > 2 else "."
        os.makedirs(out, exist_ok=True)
        shutil.copy(argv[1], os.path.join(out, os.path.basename(argv[1])))
    elif cmd == "--argc-script-path":
        print(os.path.abspath("Argcfile.sh"))
    elif cmd == "--argc-shell-path":
        print(shutil.which("bash") or "/bin/bash")
    elif cmd == "--argc-completions":
        print("")
    elif cmd == "--argc-compgen" and len(argv) >= 3:
        spec = parse_file(argv[2])
        for c in spec.commands:
            print(c.cli.split()[-1] + ("\t" + c.help if c.help else ""))
    elif cmd == "--argc-parallel" and len(argv) >= 3:
        # Sequential fallback that preserves argv enough for example scripts.
        file = argv[1]
        for a in argv[2:]:
            if a != ":::":
                subprocess.call(["bash", "-lc", f"source {shlex.quote(file)}; {a}"])
    else:
        print("Argcfile not found, try `argc --argc-help` for help.")
        return 1
    return 0


if __name__ == "__main__":
    sys.exit(main())
