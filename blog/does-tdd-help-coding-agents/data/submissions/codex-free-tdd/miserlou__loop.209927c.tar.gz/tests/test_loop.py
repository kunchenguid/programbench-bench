import os
import subprocess
import sys
import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
LOOP = ROOT / "src" / "loop.py"


def run_loop(*args, input_text=None):
    env = os.environ.copy()
    env.pop("COUNT", None)
    env.pop("ITEM", None)
    return subprocess.run(
        [sys.executable, str(LOOP), *args],
        input=input_text,
        text=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        env=env,
    )


class LoopCliTests(unittest.TestCase):
    def test_help_and_version_match_public_cli(self):
        help_result = run_loop("--help")
        self.assertEqual(help_result.returncode, 0)
        self.assertIn("loop 0.6.1", help_result.stdout)
        self.assertIn("USAGE:", help_result.stdout)
        self.assertIn("-n, --num <num>", help_result.stdout)

        version_result = run_loop("--version")
        self.assertEqual(version_result.returncode, 0)
        self.assertEqual(version_result.stdout, "loop 0.6.1\n")

    def test_no_command_prints_message_and_exits_successfully(self):
        result = run_loop()
        self.assertEqual(result.returncode, 0)
        self.assertEqual(result.stdout, "No command supplied, exiting.\n")

    def test_num_repeats_shell_command_and_injects_count(self):
        result = run_loop("-n", "3", "-o", "5", "-b", "2", "echo COUNT=$COUNT")
        self.assertEqual(result.returncode, 0)
        self.assertEqual(result.stdout, "COUNT=5\nCOUNT=7\nCOUNT=9\n")

    def test_command_stderr_is_merged_into_printed_output(self):
        result = run_loop("-n", "1", "echo out; echo err >&2; exit 4")
        self.assertEqual(result.returncode, 0)
        self.assertEqual(result.stdout, "out\nerr\n")

    def test_for_and_stdin_iterate_items(self):
        for_result = run_loop("--for", "red,green", "echo $ITEM/$COUNT")
        self.assertEqual(for_result.stdout, "red/0\ngreen/1\n")

        stdin_result = run_loop("--stdin", "echo $ITEM/$COUNT", input_text="a\nb\n")
        self.assertEqual(stdin_result.stdout, "a/0\nb/1\n")

    def test_until_status_and_output_conditions_include_final_run(self):
        success = run_loop(
            "--until-success",
            "test $COUNT -ge 2 && echo yes || (echo no; exit 1)",
        )
        self.assertEqual(success.stdout, "no\nno\nyes\n")

        fail = run_loop(
            "--until-fail",
            "test $COUNT -lt 2 && echo yes || (echo no; exit 1)",
        )
        self.assertEqual(fail.stdout, "yes\nyes\nno\n")

        contains = run_loop(
            "--until-contains",
            "hit",
            "if [ $COUNT -eq 2 ]; then echo hit; else echo miss; fi",
        )
        self.assertEqual(contains.stdout, "miss\nmiss\nhit\n")

    def test_only_last_and_summary(self):
        only_last = run_loop("-n", "3", "--only-last", "echo A$COUNT")
        self.assertEqual(only_last.stdout, "A2\n")

        summary = run_loop("-n", "2", "--summary", "echo ok")
        self.assertEqual(
            summary.stdout,
            "ok\nok\nTotal runs:\t2\nSuccesses:\t2\nFailures:\t0\n",
        )

    def test_invalid_options_use_clap_like_errors(self):
        result = run_loop("--bad")
        self.assertEqual(result.returncode, 1)
        self.assertIn("error: Found argument '--bad' which wasn't expected", result.stdout)

        bad_num = run_loop("-n", "x", "echo hi")
        self.assertEqual(bad_num.returncode, 1)
        self.assertEqual(
            bad_num.stdout,
            "error: Invalid value for '--num <num>': invalid float literal\n",
        )


if __name__ == "__main__":
    unittest.main()
