#!/usr/bin/env python3
import os
import re
import subprocess
import sys
import time
from datetime import datetime, timezone


HELP = """loop 0.6.1
Rich Jones <miserlou@gmail.com>
UNIX's missing `loop` command

USAGE:
    executable [FLAGS] [OPTIONS] [input]...

FLAGS:
    -D, --error-duration    Exit with timeout error code on duration
    -h, --help              Prints help information
    -l, --only-last         Only print the output of the last execution of the command
    -i, --stdin             Read from standard input
        --summary           Provide a summary
    -C, --until-changes     Keep going until the output changes
    -f, --until-fail        Keep going until the command exit status is non-zero
    -S, --until-same        Keep going until the output changes
    -s, --until-success     Keep going until the command exit status is zero
    -V, --version           Prints version information

OPTIONS:
    -b, --count-by <count_by>                Amount to increment the counter by [default: 1]
    -e, --every <every>                      How often to iterate. ex., 5s, 1h1m1s1ms1us [default: 1us]
        --for <ffor>                         A comma-separated list of values, placed into 4ITEM. ex., red,green,blue
    -d, --for-duration <for_duration>        Keep going until the duration has elapsed (example 1m30s)
    -n, --num <num>                          Number of iterations to execute
    -o, --offset <offset>                    Amount to offset the initial counter by [default: 0]
    -c, --until-contains <until_contains>    Keep going until the output contains this string
    -r, --until-error <until_error>          Keep going until the command exit status is the value given
    -m, --until-match <until_match>          Keep going until the output matches this regular expression
    -t, --until-time <until_time>            Keep going until a future time, ex. "2018-04-20 04:20:00" (Times in UTC.)

ARGS:
    <input>...    The command to be looped
"""


VALUE_OPTIONS = {
    "-b": ("count_by", "--count-by <count_by>"),
    "--count-by": ("count_by", "--count-by <count_by>"),
    "-e": ("every", "--every <every>"),
    "--every": ("every", "--every <every>"),
    "--for": ("for_values", "--for <ffor>"),
    "-d": ("for_duration", "--for-duration <for_duration>"),
    "--for-duration": ("for_duration", "--for-duration <for_duration>"),
    "-n": ("num", "--num <num>"),
    "--num": ("num", "--num <num>"),
    "-o": ("offset", "--offset <offset>"),
    "--offset": ("offset", "--offset <offset>"),
    "-c": ("until_contains", "--until-contains <until_contains>"),
    "--until-contains": ("until_contains", "--until-contains <until_contains>"),
    "-r": ("until_error", "--until-error <until_error>"),
    "--until-error": ("until_error", "--until-error <until_error>"),
    "-m": ("until_match", "--until-match <until_match>"),
    "--until-match": ("until_match", "--until-match <until_match>"),
    "-t": ("until_time", "--until-time <until_time>"),
    "--until-time": ("until_time", "--until-time <until_time>"),
}

FLAG_OPTIONS = {
    "-D": "error_duration",
    "--error-duration": "error_duration",
    "-l": "only_last",
    "--only-last": "only_last",
    "-i": "stdin",
    "--stdin": "stdin",
    "--summary": "summary",
    "-C": "until_changes",
    "--until-changes": "until_changes",
    "-f": "until_fail",
    "--until-fail": "until_fail",
    "-S": "until_same",
    "--until-same": "until_same",
    "-s": "until_success",
    "--until-success": "until_success",
}


def error(message):
    sys.stdout.write(message)
    return 1


def parse_number(value, label):
    try:
        return int(value)
    except ValueError:
        try:
            number = float(value)
        except ValueError:
            raise ValueError(f"error: Invalid value for '{label}': invalid float literal\n")
        return int(number)


def parse_duration(value, label):
    total = 0.0
    index = 0
    matches = list(re.finditer(r"(\d+(?:\.\d+)?)(h|m|s|ms|us)", value))
    # Prefer longest suffixes where they overlap.
    matches = list(re.finditer(r"(\d+(?:\.\d+)?)(ms|us|h|m|s)", value))
    if not matches:
        raise ValueError(f"error: Invalid value for '{label}': expected number at 0\n")
    for match in matches:
        if match.start() != index:
            raise ValueError(f"error: Invalid value for '{label}': expected number at {index}\n")
        amount = float(match.group(1))
        unit = match.group(2)
        if unit == "h":
            total += amount * 3600
        elif unit == "m":
            total += amount * 60
        elif unit == "s":
            total += amount
        elif unit == "ms":
            total += amount / 1000
        elif unit == "us":
            total += amount / 1000000
        index = match.end()
    if index != len(value):
        raise ValueError(f"error: Invalid value for '{label}': expected number at {index}\n")
    return total


def parse_until_time(value):
    for fmt in ("%Y-%m-%d %H:%M:%S", "%Y-%m-%dT%H:%M:%S"):
        try:
            return datetime.strptime(value, fmt).replace(tzinfo=timezone.utc).timestamp()
        except ValueError:
            pass
    raise ValueError("error: Invalid value for '--until-time <until_time>': input contains invalid characters\n")


def parse_args(argv):
    opts = {
        "count_by": "1",
        "every": "1us",
        "offset": "0",
        "input": [],
    }
    i = 0
    positional = False
    while i < len(argv):
        arg = argv[i]
        if positional:
            opts["input"].append(arg)
        elif arg == "--":
            positional = True
        elif arg in ("-h", "--help"):
            opts["help"] = True
        elif arg in ("-V", "--version"):
            opts["version"] = True
        elif arg in FLAG_OPTIONS:
            opts[FLAG_OPTIONS[arg]] = True
        elif arg in VALUE_OPTIONS:
            key, _label = VALUE_OPTIONS[arg]
            if i + 1 >= len(argv):
                return None, f"error: The argument '{arg}' requires a value but none was supplied\n"
            opts[key] = argv[i + 1]
            i += 1
        elif arg.startswith("-"):
            return None, (
                f"error: Found argument '{arg}' which wasn't expected, or isn't valid in this context\n\n"
                "USAGE:\n"
                "    executable [FLAGS] [OPTIONS] [input]...\n\n"
                "For more information try --help\n"
            )
        else:
            opts["input"].append(arg)
        i += 1
    return opts, None


def command_output(command, count, item):
    env = os.environ.copy()
    env["COUNT"] = str(count)
    if item is not None:
        env["ITEM"] = item
    else:
        env.pop("ITEM", None)
    proc = subprocess.run(
        command,
        shell=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        text=True,
        env=env,
    )
    return proc.returncode, proc.stdout


def print_block(text):
    if text:
        sys.stdout.write(text)
        if not text.endswith("\n"):
            sys.stdout.write("\n")
        sys.stdout.flush()


def main(argv):
    opts, parse_error = parse_args(argv)
    if parse_error:
        return error(parse_error)
    if opts.get("help"):
        sys.stdout.write(HELP)
        return 0
    if opts.get("version"):
        sys.stdout.write("loop 0.6.1\n")
        return 0

    try:
        count_by = parse_number(opts.get("count_by", "1"), "--count-by <count_by>")
        offset = parse_number(opts.get("offset", "0"), "--offset <offset>")
        every = parse_duration(opts.get("every", "1us"), "--every <every>")
        num = None if "num" not in opts else parse_number(opts["num"], "--num <num>")
        duration = None
        if "for_duration" in opts:
            duration = parse_duration(opts["for_duration"], "--for-duration <for_duration>")
        until_error = None
        if "until_error" in opts:
            until_error = parse_number(opts["until_error"], "--until-error <until_error>")
        until_timestamp = None
        if "until_time" in opts:
            until_timestamp = parse_until_time(opts["until_time"])
    except ValueError as exc:
        return error(str(exc))

    if not opts["input"]:
        sys.stdout.write("No command supplied, exiting.\n")
        return 0

    command = " ".join(opts["input"])
    if opts.get("stdin"):
        items = sys.stdin.read().splitlines()
    elif "for_values" in opts:
        items = opts["for_values"].split(",")
    else:
        items = None
    if items is not None and num is None:
        num = len(items)

    count = offset
    runs = successes = failures = 0
    last_output = ""
    previous_output = None
    start = time.monotonic()

    while True:
        if num is not None and runs >= num:
            break
        if duration is not None and time.monotonic() - start >= duration:
            if opts.get("error_duration"):
                return 124
            break
        if until_timestamp is not None and time.time() >= until_timestamp:
            break

        item = None
        if items is not None:
            if runs >= len(items):
                break
            item = items[runs]

        status, output = command_output(command, count, item)
        runs += 1
        if status == 0:
            successes += 1
        else:
            failures += 1
        last_output = output

        if not opts.get("only_last"):
            print_block(output)

        stop = False
        if opts.get("until_success") and status == 0:
            stop = True
        if opts.get("until_fail") and status != 0:
            stop = True
        if until_error is not None and status == until_error:
            stop = True
        if "until_contains" in opts and opts["until_contains"] in output:
            stop = True
        if "until_match" in opts and re.search(opts["until_match"], output):
            stop = True
        if opts.get("until_changes") and previous_output is not None and output != previous_output:
            stop = True
        if opts.get("until_same") and previous_output is not None and output == previous_output:
            stop = True
        previous_output = output
        count += count_by
        if stop:
            break
        if every > 0:
            time.sleep(every)

    if opts.get("only_last"):
        print_block(last_output)
    if opts.get("summary"):
        sys.stdout.write(f"Total runs:\t{runs}\nSuccesses:\t{successes}\nFailures:\t{failures}\n")
    return 0


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
