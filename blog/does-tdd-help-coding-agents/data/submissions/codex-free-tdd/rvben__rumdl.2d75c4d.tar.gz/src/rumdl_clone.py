#!/usr/bin/env python3
import argparse
import fnmatch
import json
import os
import re
import sys
import time
from dataclasses import dataclass
from pathlib import Path


VERSION = "rumdl 0.1.13"


RULES = [
    ("MD001", "Heading levels should only increment by one level at a time"),
    ("MD003", "Heading style"),
    ("MD004", "Use consistent style for unordered list markers"),
    ("MD005", "List indentation should be consistent"),
    ("MD007", "Unordered list indentation"),
    ("MD009", "Trailing spaces should be removed"),
    ("MD010", "No tabs"),
    ("MD011", "Reversed link syntax"),
    ("MD012", "Multiple consecutive blank lines"),
    ("MD013", "Line length should not be excessive"),
    ("MD014", "Commands in code blocks should show output"),
    ("MD018", "No space after hash in heading"),
    ("MD019", "Multiple spaces after hash in heading"),
    ("MD020", "No space inside hashes on closed heading"),
    ("MD021", "Multiple spaces inside hashes on closed heading"),
    ("MD022", "Headings should be surrounded by blank lines"),
    ("MD023", "Headings must start at the beginning of the line"),
    ("MD024", "Multiple headings with the same content"),
    ("MD025", "Multiple top-level headings in the same document"),
    ("MD026", "Trailing punctuation in heading"),
    ("MD027", "Multiple spaces after quote marker (>)"),
    ("MD028", "Blank line inside blockquote"),
    ("MD029", "Ordered list marker value"),
    ("MD030", "Spaces after list markers should be consistent"),
    ("MD031", "Fenced code blocks should be surrounded by blank lines"),
    ("MD032", "Lists should be surrounded by blank lines"),
    ("MD033", "Inline HTML is not allowed"),
    ("MD034", "No bare URLs - wrap URLs in angle brackets"),
    ("MD035", "Horizontal rule style"),
    ("MD036", "Emphasis should not be used instead of a heading"),
    ("MD037", "Spaces inside emphasis markers"),
    ("MD038", "Spaces inside code span elements"),
    ("MD039", "Spaces inside link text"),
    ("MD040", "Code blocks should have a language specified"),
    ("MD041", "First line in file should be a top level heading"),
    ("MD042", "No empty links"),
    ("MD043", "Required heading structure"),
    ("MD044", "Proper names should have the correct capitalization"),
    ("MD045", "Images should have alternate text (alt text)"),
    ("MD046", "Code blocks should use a consistent style"),
    ("MD047", "Files should end with a single newline character"),
    ("MD048", "Code fence style should be consistent"),
    ("MD049", "Emphasis style should be consistent"),
    ("MD050", "Strong emphasis style should be consistent"),
    ("MD051", "Link fragments should reference valid headings"),
    ("MD052", "Reference links and images should use a reference that exists"),
    ("MD053", "Link and image reference definitions should be needed"),
    ("MD054", "Link and image style should be consistent"),
    ("MD055", "Table pipe style should be consistent"),
    ("MD056", "Table column count should be consistent"),
    ("MD057", "Relative links should point to existing files"),
    ("MD058", "Tables should be surrounded by blank lines"),
    ("MD059", "Link text should be descriptive"),
    ("MD060", "Table columns should be consistently aligned"),
    ("MD061", "Forbidden terms"),
    ("MD062", "Link destination should not have leading or trailing whitespace"),
    ("MD063", "Heading capitalization"),
    ("MD064", "Multiple consecutive spaces"),
    ("MD065", "Horizontal rules should be surrounded by blank lines"),
    ("MD066", "Footnote validation"),
    ("MD067", "Footnote definitions should appear in order of first reference"),
    ("MD068", "Footnote definitions should not be empty"),
    ("MD069", "Duplicate list markers"),
    ("MD070", "Nested code fence collision - use longer fence to avoid premature closure"),
    ("MD071", "Blank line after frontmatter"),
    ("MD072", "Frontmatter keys should be sorted alphabetically"),
    ("MD073", "Table of Contents should match document headings"),
]

RULE_TEXT = dict(RULES)
ERROR_RULES = {"MD001", "MD011", "MD024", "MD025", "MD042", "MD045", "MD051", "MD057", "MD066", "MD068"}
OPT_IN = {"MD060", "MD063", "MD072", "MD073"}


@dataclass
class Diagnostic:
    path: str
    line: int
    column: int
    rule: str
    message: str
    fixable: bool = False

    @property
    def severity(self):
        return "error" if self.rule in ERROR_RULES else "warning"


def split_csv(value):
    if not value:
        return []
    out = []
    for part in value:
        out.extend(x.strip().upper() for x in part.split(",") if x.strip())
    return out


def split_patterns(value):
    if not value:
        return []
    out = []
    for part in value:
        out.extend(x.strip() for x in part.split(",") if x.strip())
    return out


def is_enabled(rule, enabled, disabled):
    if enabled and rule not in enabled:
        return False
    if rule in disabled:
        return False
    if not enabled and rule in OPT_IN:
        return False
    return True


def add(diags, path, line, col, rule, msg, fixable=False, enabled=None, disabled=None):
    if is_enabled(rule, enabled or set(), disabled or set()):
        diags.append(Diagnostic(path, line, col, rule, msg, fixable))


def is_heading(line):
    return re.match(r"^(#{1,6})(?:\s+|$)(.*?)(?:\s+#+\s*)?$", line)


def heading_text(line):
    m = is_heading(line)
    if not m:
        return ""
    return re.sub(r"\s+#+\s*$", "", m.group(2)).strip().lower()


def in_code_flags(lines):
    flags = []
    in_code = False
    fence = ""
    for line in lines:
        stripped = line.lstrip()
        if stripped.startswith("```") or stripped.startswith("~~~"):
            marker = stripped[:3]
            if not in_code:
                in_code = True
                fence = marker
                flags.append(False)
            elif marker == fence:
                flags.append(False)
                in_code = False
                fence = ""
            else:
                flags.append(in_code)
            continue
        flags.append(in_code)
    return flags


def lint_text(text, display_path, base_dir, enabled=None, disabled=None, line_length=80):
    enabled = enabled or set()
    disabled = disabled or set()
    diags = []
    lines = text.splitlines()
    keepends = text.splitlines(True)
    code = in_code_flags(lines)
    content_lines = [ln for ln in lines if ln.strip()]

    if text and not text.endswith("\n"):
        add(diags, display_path, len(lines) or 1, len(lines[-1]) + 1 if lines else 1, "MD047",
            "Files should end with a single newline character", True, enabled, disabled)

    first_content = next((i for i, ln in enumerate(lines, 1) if ln.strip()), None)
    if first_content is not None and not re.match(r"^#\s+", lines[first_content - 1]):
        add(diags, display_path, first_content, 1, "MD041",
            "First line in file should be a level 1 heading", False, enabled, disabled)

    blank_run = 0
    last_heading_level = 0
    seen_h1 = False
    seen_headings = set()
    ul_marker = None
    hr_style = None
    fence_style = None
    table_cols = None
    in_frontmatter = False
    frontmatter_end = None
    if lines and lines[0].strip() in ("---", "+++", "{"):
        in_frontmatter = True
    base_disabled = set(disabled)
    inline_disabled = set()

    for idx, line in enumerate(lines, 1):
        raw = line
        stripped = raw.strip()
        inside_code = code[idx - 1] if idx - 1 < len(code) else False
        disable_match = re.search(r"<!--\s*rumdl-disable(?:\s+([^>]*?))?\s*-->", raw)
        if disable_match:
            listed = [r.upper() for r in re.findall(r"MD\d{3}", disable_match.group(1) or "")]
            if listed:
                inline_disabled.update(listed)
            else:
                inline_disabled.update(rule for rule, _ in RULES)
        enable_match = re.search(r"<!--\s*rumdl-enable(?:\s+([^>]*?))?\s*-->", raw)
        if enable_match:
            listed = [r.upper() for r in re.findall(r"MD\d{3}", enable_match.group(1) or "")]
            if listed:
                inline_disabled.difference_update(listed)
            else:
                inline_disabled.clear()
        disabled = base_disabled | inline_disabled

        if in_frontmatter and idx > 1 and stripped in ("---", "+++", "}"):
            frontmatter_end = idx
            in_frontmatter = False
            continue

        if not inside_code:
            if raw.endswith(" ") and not raw.endswith("  "):
                add(diags, display_path, idx, len(raw.rstrip(" ")) + 1, "MD009",
                    "Trailing spaces", True, enabled, disabled)
            if "\t" in raw:
                col = raw.index("\t") + 1
                msg = "Found leading tab, use 4 spaces instead" if raw.startswith("\t") else "Found tab, use spaces instead"
                add(diags, display_path, idx, col, "MD010", msg, True, enabled, disabled)
            if len(raw) > line_length:
                add(diags, display_path, idx, line_length + 1, "MD013",
                    f"Line length [{len(raw)}] exceeds configured line length [{line_length}]", False, enabled, disabled)
            if re.search(r"https?://[^\s)>]+", raw) and not re.search(r"<https?://[^\s>]+>", raw):
                add(diags, display_path, idx, raw.find("http") + 1, "MD034",
                    "Bare URL used", False, enabled, disabled)
            for m in re.finditer(r"<([A-Za-z][A-Za-z0-9-]*)(?:\s|>|/)", raw):
                tag = m.group(0).rstrip(" >/") + ">"
                add(diags, display_path, idx, m.start() + 1, "MD033",
                    f"Inline HTML found: {tag}", False, enabled, disabled)
                break
            for m in re.finditer(r"\[([^\]]*)\]\(([^)]*)\)", raw):
                text_part, dest = m.group(1), m.group(2)
                if text_part.strip() != text_part:
                    add(diags, display_path, idx, m.start() + 1, "MD039",
                        "Spaces inside link text", True, enabled, disabled)
                if dest == "":
                    add(diags, display_path, idx, m.start() + 1, "MD042",
                        f"Empty link found: {m.group(0)}", False, enabled, disabled)
                if dest.strip() != dest:
                    add(diags, display_path, idx, m.start(2) + 1, "MD062",
                        "Link destination has leading or trailing whitespace", True, enabled, disabled)
                if dest and not re.match(r"^(https?:|mailto:|#|/)", dest) and not dest.startswith("<"):
                    target = dest.split("#", 1)[0].strip()
                    if target and not (Path(base_dir) / target).exists():
                        add(diags, display_path, idx, m.start(2) + 1, "MD057",
                            f"Relative link '{target}' does not exist", False, enabled, disabled)
            for m in re.finditer(r"!\[([^\]]*)\]\(([^)]*)\)", raw):
                if not m.group(1).strip():
                    add(diags, display_path, idx, m.start() + 1, "MD045",
                        "Image missing alt text (add description for accessibility: ![description](url))", True, enabled, disabled)
            for m in re.finditer(r"`([^`]+)`", raw):
                if m.group(1).strip() != m.group(1):
                    add(diags, display_path, idx, m.start() + 1, "MD038",
                        "Spaces inside code span elements", True, enabled, disabled)
            if re.search(r"(^|\s)(\*{1,2}|_{1,2})\s+[^*_].*?\s+(\2)(\s|$)", raw):
                add(diags, display_path, idx, 1, "MD037", "Spaces inside emphasis markers", True, enabled, disabled)
            if re.search(r"\S {2,}\S", raw) and not raw.endswith("  "):
                add(diags, display_path, idx, re.search(r" {2,}", raw).start() + 1, "MD064",
                    "Multiple consecutive spaces (2) found", True, enabled, disabled)

        if stripped == "":
            blank_run += 1
            if blank_run > 1:
                add(diags, display_path, idx, 1, "MD012",
                    "Multiple consecutive blank lines between content", True, enabled, disabled)
            continue
        blank_run = 0

        if frontmatter_end == idx - 1 and stripped:
            add(diags, display_path, idx, 1, "MD071", "Blank line missing after frontmatter", True, enabled, disabled)

        if inside_code:
            continue

        if re.match(r"^\s+#{1,6}\s+", raw):
            add(diags, display_path, idx, len(raw) - len(raw.lstrip()) + 1, "MD023",
                "Headings must start at the beginning of the line", True, enabled, disabled)

        if re.match(r"^#{1,6}\S", raw):
            add(diags, display_path, idx, raw.find("#") + raw.count("#") + 1, "MD018",
                "No space after # in heading", True, enabled, disabled)
        if re.match(r"^#{1,6} {2,}\S", raw):
            hashes = len(re.match(r"^(#+)", raw).group(1))
            spaces = len(re.match(r"^#+( +)", raw).group(1))
            add(diags, display_path, idx, hashes + 1, "MD019",
                f"Multiple spaces ({spaces}) after # in heading", True, enabled, disabled)

        h = is_heading(raw)
        if h:
            level = len(h.group(1))
            if last_heading_level and level > last_heading_level + 1:
                add(diags, display_path, idx, 1, "MD001",
                    f"Expected heading level {last_heading_level + 1}, but found heading level {level}", True, enabled, disabled)
            last_heading_level = level
            if idx > 1 and lines[idx - 2].strip() != "":
                add(diags, display_path, idx, 1, "MD022", "Expected 1 blank line above heading", True, enabled, disabled)
            if idx < len(lines) and lines[idx].strip() != "":
                add(diags, display_path, idx, 1, "MD022", "Expected 1 blank line below heading", True, enabled, disabled)
            normalized = heading_text(raw)
            if normalized in seen_headings:
                add(diags, display_path, idx, len(h.group(1)) + 2, "MD024",
                    f"Duplicate heading: '{h.group(2).strip()}'.", False, enabled, disabled)
            seen_headings.add(normalized)
            if level == 1:
                if seen_h1:
                    add(diags, display_path, idx, len(h.group(1)) + 2, "MD025",
                        "Multiple top-level headings (level 1) in the same document", True, enabled, disabled)
                seen_h1 = True
            if re.search(r"[.,;:!?]$", h.group(2).strip()):
                add(diags, display_path, idx, len(raw), "MD026",
                    "Trailing punctuation in heading", True, enabled, disabled)
            if re.match(r"^(\*{1,2}|_{1,2}).+\1$", h.group(2).strip()):
                add(diags, display_path, idx, len(h.group(1)) + 2, "MD036",
                    "Emphasis used instead of a heading", False, enabled, disabled)

        lm = re.match(r"^(\s*)([-+*])\s+", raw)
        if lm:
            if ul_marker is None:
                ul_marker = lm.group(2)
            elif lm.group(2) != ul_marker:
                add(diags, display_path, idx, len(lm.group(1)) + 1, "MD004",
                    f"Unordered list style [Expected: {ul_marker}; Actual: {lm.group(2)}]", True, enabled, disabled)
            if idx > 1 and lines[idx - 2].strip() and not re.match(r"^\s*([-+*]|\d+\.)\s+", lines[idx - 2]):
                add(diags, display_path, idx, 1, "MD032", "List should be preceded by blank line", True, enabled, disabled)
            if idx < len(lines) and lines[idx].strip() and not re.match(r"^\s*([-+*]|\d+\.)\s+", lines[idx]):
                add(diags, display_path, idx, 1, "MD032", "List should be followed by blank line", True, enabled, disabled)
            if re.match(r"^\s*[-+*]\s+[-+*]\s+", raw):
                add(diags, display_path, idx, 1, "MD069", "Duplicate list marker found", True, enabled, disabled)
        om = re.match(r"^(\s*)(\d+)\.\s+", raw)
        if om and int(om.group(2)) != 1:
            prev = lines[idx - 2] if idx > 1 else ""
            if not re.match(r"^\s*\d+\.\s+", prev):
                add(diags, display_path, idx, len(om.group(1)) + 1, "MD029",
                    "Ordered list item prefix", True, enabled, disabled)

        if re.match(r"^(\*\s*){3,}$|^(-\s*){3,}$|^(_\s*){3,}$", stripped):
            style = stripped.replace(" ", "")
            if hr_style is None:
                hr_style = style
            elif style != hr_style:
                add(diags, display_path, idx, 1, "MD035", "Horizontal rule style", True, enabled, disabled)
            if idx > 1 and lines[idx - 2].strip():
                add(diags, display_path, idx, 1, "MD065", "Horizontal rule should be preceded by blank line", True, enabled, disabled)
            if idx < len(lines) and lines[idx].strip():
                add(diags, display_path, idx, 1, "MD065", "Horizontal rule should be followed by blank line", True, enabled, disabled)

        fm = re.match(r"^(```|~~~)(.*)$", raw.lstrip())
        if fm:
            marker = fm.group(1)
            if fence_style is None:
                fence_style = marker
            elif marker != fence_style:
                add(diags, display_path, idx, 1, "MD048", "Code fence style should be consistent", True, enabled, disabled)
            if not fm.group(2).strip() and not (idx > 1 and code[idx - 2]):
                add(diags, display_path, idx, len(marker) + 1, "MD040",
                    "Fenced code blocks should have a language specified", False, enabled, disabled)
            if idx > 1 and lines[idx - 2].strip() and not code[idx - 2]:
                add(diags, display_path, idx, 1, "MD031", "Fenced code blocks should be preceded by blank line", True, enabled, disabled)
            if idx < len(lines) and lines[idx].strip() and code[idx - 1]:
                add(diags, display_path, idx, 1, "MD031", "Fenced code blocks should be followed by blank line", True, enabled, disabled)

        if "|" in raw and stripped.startswith("|"):
            cols = len([c for c in raw.strip().strip("|").split("|")])
            if table_cols is None:
                table_cols = cols
                if idx > 1 and lines[idx - 2].strip():
                    add(diags, display_path, idx, 1, "MD058", "Table should be preceded by blank line", True, enabled, disabled)
            elif cols != table_cols:
                add(diags, display_path, idx, 1, "MD056", "Table column count should be consistent", False, enabled, disabled)
        elif table_cols is not None:
            if stripped and idx > 1:
                add(diags, display_path, idx - 1, 1, "MD058", "Table should be followed by blank line", True, enabled, disabled)
            table_cols = None

    diags.sort(key=lambda d: (d.path, d.line, d.column, d.rule))
    return diags


def fix_text(text):
    lines = text.splitlines()
    out = []
    blank_run = 0
    for line in lines:
        line = line.replace("\t", "    ")
        line = re.sub(r"^(#{1,6})(\S)", r"\1 \2", line)
        line = re.sub(r"^(#{1,6}) {2,}", r"\1 ", line)
        if not line.endswith("  "):
            line = line.rstrip(" ")
        if line.strip() == "":
            blank_run += 1
            if blank_run > 1:
                continue
        else:
            blank_run = 0
        out.append(line)
    fixed = "\n".join(out)
    return fixed + "\n" if fixed or text.endswith("\n") else fixed


def collect_paths(paths, include=None, exclude=None, force_exclude=False):
    include = include or []
    exclude = exclude or []
    if not paths:
        paths = ["."]
    files = []
    for arg in paths:
        if arg == "-":
            files.append(("-", True))
            continue
        p = Path(arg)
        if p.is_dir():
            for root, dirs, names in os.walk(p):
                dirs[:] = [d for d in dirs if d not in {".git", ".rumdl_cache", "node_modules"}]
                for name in names:
                    if name.lower().endswith((".md", ".markdown")):
                        files.append((str(Path(root) / name), False))
        elif p.exists():
            files.append((str(p), True))
        else:
            print(f"Error: Path not found: {arg}", file=sys.stderr)
    filtered = []
    for f, explicit in files:
        rel = f
        if include and not any(fnmatch.fnmatch(rel, pat) for pat in include):
            continue
        if exclude and (force_exclude or not explicit) and any(fnmatch.fnmatch(rel, pat) or rel.startswith(pat.rstrip("/") + "/") for pat in exclude):
            continue
        filtered.append(f)
    return filtered


def parse_config(path):
    enabled, disabled = set(), set()
    line_length = 80
    if not path:
        for name in [".rumdl.toml", "rumdl.toml", "pyproject.toml"]:
            if Path(name).exists():
                path = name
                break
    if not path or not Path(path).exists():
        return enabled, disabled, line_length
    text = Path(path).read_text(encoding="utf-8", errors="replace")
    for key, target in [("enable", enabled), ("disable", disabled)]:
        m = re.search(rf"^\s*{key}\s*=\s*\[([^\]]*)\]", text, re.M)
        if m:
            for item in re.findall(r'"([^"]+)"|\'([^\']+)\'', m.group(1)):
                target.add((item[0] or item[1]).upper())
    m = re.search(r"^\s*(?:line_length|line-length)\s*=\s*(\d+)", text, re.M)
    if m:
        line_length = int(m.group(1))
    return enabled, disabled, line_length


def render_text(diags, total_files, elapsed_ms, fixed=False):
    lines = []
    for d in diags:
        suffix = " [fixed]" if fixed and d.fixable else (" [*]" if d.fixable else "")
        lines.append(f"{d.path}:{d.line}:{d.column}: [{d.rule}] {d.message}{suffix}")
    if diags:
        lines.append("")
        if fixed:
            fixed_count = sum(1 for d in diags if d.fixable)
            lines.append(f"Fixed: Fixed {fixed_count}/{len(diags)} issues in {total_files} file{'s' if total_files != 1 else ''} ({elapsed_ms}ms)")
        else:
            lines.append(f"Issues: Found {len(diags)} issue{'s' if len(diags) != 1 else ''} in {total_files} file{'s' if total_files != 1 else ''} ({elapsed_ms}ms)")
            fixable = sum(1 for d in diags if d.fixable)
            if fixable:
                lines.append(f"Run `rumdl fmt` to automatically fix {fixable} of the {len(diags)} issue{'s' if len(diags) != 1 else ''}")
    else:
        lines.append(f"Success: No issues found in {total_files} file{'s' if total_files != 1 else ''} ({elapsed_ms}ms)")
    return "\n".join(lines) + "\n"


def render_json(diags):
    return json.dumps([
        {
            "file": d.path,
            "line": d.line,
            "column": d.column,
            "rule": d.rule,
            "message": d.message,
            "severity": d.severity,
            "fixable": d.fixable,
            "fix": None,
        }
        for d in diags
    ], indent=2) + "\n"


def command_check(argv, fmt_alias=False):
    parser = argparse.ArgumentParser(prog="executable fmt" if fmt_alias else "executable check")
    parser.add_argument("paths", nargs="*")
    parser.add_argument("-f", "--fix", action="store_true")
    parser.add_argument("--diff", action="store_true")
    parser.add_argument("--check", action="store_true")
    parser.add_argument("-l", "--list-rules", action="store_true")
    parser.add_argument("-d", "--disable", action="append")
    parser.add_argument("-e", "--enable", "--rules", action="append")
    parser.add_argument("--extend-enable", action="append")
    parser.add_argument("--extend-disable", action="append")
    parser.add_argument("--exclude", action="append")
    parser.add_argument("--include", action="append")
    parser.add_argument("--no-exclude", action="store_true")
    parser.add_argument("--respect-gitignore", nargs="?", const="true")
    parser.add_argument("-v", "--verbose", action="store_true")
    parser.add_argument("--color", default="auto")
    parser.add_argument("--profile", action="store_true")
    parser.add_argument("--config")
    parser.add_argument("--statistics", action="store_true")
    parser.add_argument("--no-config", action="store_true")
    parser.add_argument("-q", "--quiet", action="store_true")
    parser.add_argument("--isolated", action="store_true")
    parser.add_argument("-o", "--output", default=None)
    parser.add_argument("--output-format", default=None)
    parser.add_argument("--show-full-path", action="store_true")
    parser.add_argument("--flavor")
    parser.add_argument("--stdin", action="store_true")
    parser.add_argument("--stdin-filename", default="stdin.md")
    parser.add_argument("--stderr", action="store_true")
    parser.add_argument("-s", "--silent", action="store_true")
    parser.add_argument("-w", "--watch", action="store_true")
    parser.add_argument("--force-exclude", action="store_true")
    parser.add_argument("--no-cache", action="store_true")
    parser.add_argument("--cache-dir")
    parser.add_argument("--fail-on", default="any", choices=["any", "warning", "error", "never"])
    args = parser.parse_args(argv)
    if args.list_rules:
        print_rules()
        return 0
    start = time.time()
    cfg_enable, cfg_disable, line_length = (set(), set(), 80) if (args.no_config or args.isolated) else parse_config(args.config)
    enabled = set(split_csv(args.enable)) or cfg_enable
    disabled = cfg_disable | set(split_csv(args.disable)) | set(split_csv(args.extend_disable))
    enabled |= set(split_csv(args.extend_enable))
    include = split_patterns(args.include)
    exclude = [] if args.no_exclude else split_patterns(args.exclude)
    diags = []
    file_count = 0
    fix_mode = fmt_alias or args.fix

    if args.stdin or args.paths == ["-"]:
        text = sys.stdin.read()
        file_count = 1
        diags.extend(lint_text(text, args.stdin_filename, ".", enabled, disabled, line_length))
    else:
        files = collect_paths(args.paths, include, exclude, args.force_exclude)
        for f in files:
            p = Path(f)
            text = p.read_text(encoding="utf-8", errors="replace")
            display = str(p.resolve()) if args.show_full_path else str(p)
            file_count += 1
            before = lint_text(text, display, str(p.parent), enabled, disabled, line_length)
            diags.extend(before)
            if fix_mode:
                fixed = fix_text(text)
                if fixed != text and not args.diff and not args.check:
                    p.write_text(fixed, encoding="utf-8")

    elapsed = max(0, int((time.time() - start) * 1000))
    outfmt = args.output_format or args.output or "text"
    if args.silent:
        pass
    elif outfmt in ("json",):
        print(render_json(diags), end="")
    elif outfmt == "json-lines":
        for d in diags:
            print(json.dumps({"file": d.path, "line": d.line, "column": d.column, "rule": d.rule, "message": d.message, "severity": d.severity}))
    elif outfmt in ("github",):
        for d in diags:
            print(f"::{d.severity} file={d.path},line={d.line},col={d.column},title={d.rule}::{d.message}")
    elif outfmt in ("pylint",):
        for d in diags:
            print(f"{d.path}:{d.line}:{d.column}: {d.rule}: {d.message}")
    else:
        print(render_text(diags, file_count, elapsed, fixed=fix_mode), end="")

    if args.fail_on == "never" or fix_mode:
        return 0
    if not diags:
        return 0
    if args.fail_on == "error":
        return 1 if any(d.severity == "error" for d in diags) else 0
    if args.fail_on == "warning":
        return 1 if any(d.severity in ("warning", "error") for d in diags) else 0
    return 1


def print_rules():
    print("Available rules:")
    for rule, desc in RULES:
        print(f"  {rule} - {desc}")
    print()
    print(f"Total: {len(RULES)} rules")


def command_rule(argv):
    if not argv:
        print_rules()
        return 0
    rule = argv[0].upper()
    if rule in RULE_TEXT:
        name = {
            "MD009": "no-trailing-spaces",
            "MD010": "no-hard-tabs",
            "MD013": "line-length",
        }.get(rule, RULE_TEXT[rule].lower().replace(" ", "-"))
        print(f"{rule} - {RULE_TEXT[rule]}")
        print()
        print(f"Name: {name}")
        print("Category: whitespace" if rule in {"MD009", "MD010", "MD012", "MD013", "MD047"} else "Category: general")
        print("Fix: Fix is always available." if rule not in {"MD024", "MD033", "MD042", "MD057"} else "Fix: No automatic fix available.")
        print(f"Documentation: https://rumdl.dev/{rule.lower()}/")
        return 0
    print(f"Error: Unknown rule '{argv[0]}'", file=sys.stderr)
    return 1


def command_explain(argv):
    rule = argv[0].upper() if argv else ""
    if rule not in RULE_TEXT:
        print(f"Error: Unknown rule '{rule}'", file=sys.stderr)
        return 1
    print(f"{rule} - {RULE_TEXT[rule]}")
    print()
    print("What this rule does")
    print()
    print(RULE_TEXT[rule])
    print()
    print("Automatic fixes")
    print()
    print("This clone implements the common behavior for this rule where practical.")
    print()
    print("Default Configuration:")
    print(f"[{rule}]")
    return 0


def command_init(argv):
    parser = argparse.ArgumentParser(prog="executable init")
    parser.add_argument("--pyproject", action="store_true")
    parser.add_argument("--color", default="auto")
    parser.add_argument("--config")
    parser.add_argument("--no-config", action="store_true")
    parser.add_argument("--isolated", action="store_true")
    args = parser.parse_args(argv)
    if args.pyproject:
        path = Path("pyproject.toml")
        content = "[tool.rumdl]\nline_length = 80\n\n"
    else:
        path = Path(".rumdl.toml")
        content = "[global]\nline_length = 80\n\n"
    if path.exists():
        print(f"Configuration file already exists: {path}", file=sys.stderr)
        return 1
    path.write_text(content, encoding="utf-8")
    print(f"Created configuration file: {path}")
    return 0


def command_config(argv):
    if argv and argv[0] == "get":
        key = argv[1] if len(argv) > 1 else ""
        if key in ("global.line_length", "line_length", "global.line-length"):
            print("80")
        elif key in ("global.cache", "cache"):
            print("true")
        else:
            print("")
        return 0
    if argv and argv[0] == "file":
        for name in [".rumdl.toml", "rumdl.toml", "pyproject.toml"]:
            if Path(name).exists():
                print(str(Path(name).resolve()))
                return 0
        return 1
    print("[global]")
    print("line_length = 80")
    print("cache = true")
    return 0


def print_top_help():
    print("A fast Markdown linter written in Rust (Ru(st) MarkDown Linter)")
    print()
    print("Usage: executable [OPTIONS] <COMMAND>")
    print()
    print("Commands:")
    for name, desc in [
        ("check", "Lint Markdown files and print warnings/errors"),
        ("fmt", "Format Markdown files (alias for check --fix)"),
        ("init", "Initialize a new configuration file"),
        ("rule", "Show information about a rule or list all rules"),
        ("explain", "Explain a rule with detailed information and examples"),
        ("config", "Show configuration or query a specific key"),
        ("server", "Start the Language Server Protocol server"),
        ("schema", "Generate or check JSON schema for rumdl.toml"),
        ("import", "Import and convert markdownlint configuration files"),
        ("vscode", "Install the rumdl VS Code extension"),
        ("completions", "Generate shell completion scripts"),
        ("clean", "Clear the cache"),
        ("version", "Show version information"),
        ("help", "Print this message or the help of the given subcommand(s)"),
    ]:
        print(f"  {name:<12} {desc}")
    print()
    print("Options:")
    print("      --color <COLOR>    Control colored output: auto, always, never [default: auto] [possible values: auto, always, never]")
    print("      --config <CONFIG>  Path to configuration file")
    print("      --no-config        Ignore all configuration files and use built-in defaults")
    print("      --isolated         Ignore all configuration files (alias for --no-config)")
    print("  -h, --help             Print help")
    print("  -V, --version          Print version")


def main(argv=None):
    argv = list(sys.argv[1:] if argv is None else argv)
    if not argv or argv[0] in ("-h", "--help", "help"):
        print_top_help()
        return 0
    if argv[0] in ("-V", "--version", "version"):
        print(VERSION)
        return 0
    global_opts = {"--color", "--config"}
    while argv and (argv[0] in ("--no-config", "--isolated") or argv[0] in global_opts):
        if argv[0] in global_opts and len(argv) > 1:
            del argv[:2]
        else:
            del argv[0]
    cmd = argv.pop(0) if argv else "help"
    if cmd == "check":
        return command_check(argv, False)
    if cmd == "fmt":
        return command_check(argv, True)
    if cmd == "rule":
        return command_rule(argv)
    if cmd == "explain":
        return command_explain(argv)
    if cmd == "init":
        return command_init(argv)
    if cmd == "config":
        return command_config(argv)
    if cmd == "clean":
        cache = Path(".rumdl_cache")
        if cache.exists():
            for p in sorted(cache.rglob("*"), reverse=True):
                if p.is_file():
                    p.unlink()
                elif p.is_dir():
                    p.rmdir()
            cache.rmdir()
        print("Cache cleared")
        return 0
    if cmd in ("schema", "completions", "server", "vscode", "import"):
        if "--help" in argv or "-h" in argv:
            print(f"Usage: executable {cmd} [OPTIONS]")
            return 0
        print(f"{cmd} command is not available in this reimplementation", file=sys.stderr)
        return 1
    print(f"error: unrecognized subcommand '{cmd}'", file=sys.stderr)
    return 2


if __name__ == "__main__":
    raise SystemExit(main())
