import json
import os
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
SCRIPT = ROOT / "src" / "rumdl_clone.py"


def run_cmd(args, cwd=None, input_text=None):
    return subprocess.run(
        [sys.executable, str(SCRIPT), *args],
        cwd=cwd,
        input=input_text,
        text=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
    )


class RumdlCloneTests(unittest.TestCase):
    def test_version_command_prints_rumdl_version(self):
        result = run_cmd(["version"])
        self.assertEqual(result.returncode, 0)
        self.assertEqual(result.stdout.strip(), "rumdl 0.1.13")

    def test_clean_file_reports_success(self):
        with tempfile.TemporaryDirectory() as d:
            Path(d, "good.md").write_text("# Good\n", encoding="utf-8")
            result = run_cmd(["check", "--no-config", "--color", "never", "good.md"], cwd=d)
        self.assertEqual(result.returncode, 0)
        self.assertIn("Success: No issues found in 1 file", result.stdout)

    def test_common_markdown_violations_are_reported(self):
        text = "Title\n\n## Skip\n# Second\ntext  \n\n\n- item\n\tbad\n[bad]()\n![](x.png)\n<div>x</div>\n"
        with tempfile.TemporaryDirectory() as d:
            Path(d, "bad.md").write_text(text, encoding="utf-8")
            result = run_cmd(["check", "--no-config", "--color", "never", "bad.md"], cwd=d)
        self.assertEqual(result.returncode, 1)
        for expected in [
            "bad.md:1:1: [MD041] First line in file should be a level 1 heading",
            "bad.md:7:1: [MD012] Multiple consecutive blank lines between content [*]",
            "bad.md:9:1: [MD010] Found leading tab, use 4 spaces instead [*]",
            "bad.md:10:1: [MD042] Empty link found: [bad]()",
            "bad.md:11:1: [MD045] Image missing alt text",
            "bad.md:12:1: [MD033] Inline HTML found: <div>",
        ]:
            self.assertIn(expected, result.stdout)
        self.assertIn("Issues: Found", result.stdout)

    def test_json_output_is_machine_readable(self):
        with tempfile.TemporaryDirectory() as d:
            Path(d, "bad.md").write_text("[bad]()\n", encoding="utf-8")
            result = run_cmd(["check", "--no-config", "--color", "never", "--output", "json", "bad.md"], cwd=d)
        self.assertEqual(result.returncode, 1)
        data = json.loads(result.stdout)
        self.assertTrue(any(item["rule"] == "MD042" and item["severity"] == "error" for item in data))

    def test_fmt_applies_simple_fixes(self):
        with tempfile.TemporaryDirectory() as d:
            p = Path(d, "f.md")
            p.write_text("line  \n\n\n#H\n", encoding="utf-8")
            result = run_cmd(["fmt", "--no-config", "--color", "never", "f.md"], cwd=d)
            fixed = p.read_text(encoding="utf-8")
        self.assertEqual(result.returncode, 0)
        self.assertIn("Fixed: Fixed", result.stdout)
        self.assertEqual(fixed, "line  \n\n# H\n")

    def test_stdin_uses_stdin_filename(self):
        result = run_cmd(
            ["check", "--stdin", "--stdin-filename", "stdin.md", "--no-config", "--color", "never"],
            input_text="[bad]()\n",
        )
        self.assertEqual(result.returncode, 1)
        self.assertIn("stdin.md:1:1: [MD042] Empty link found: [bad]()", result.stdout)

    def test_disable_and_fail_on_match_cli_contract(self):
        with tempfile.TemporaryDirectory() as d:
            Path(d, "bad.md").write_text("[bad]()\n", encoding="utf-8")
            disabled = run_cmd(["check", "--no-config", "--disable", "MD042,MD041", "bad.md"], cwd=d)
            never = run_cmd(["check", "--no-config", "--fail-on", "never", "bad.md"], cwd=d)
        self.assertEqual(disabled.returncode, 0)
        self.assertIn("Success: No issues found", disabled.stdout)
        self.assertEqual(never.returncode, 0)
        self.assertIn("[MD042]", never.stdout)

    def test_config_file_controls_line_length(self):
        with tempfile.TemporaryDirectory() as d:
            Path(d, ".rumdl.toml").write_text("[global]\nline_length = 120\n", encoding="utf-8")
            Path(d, "line.md").write_text("# Good\n\n" + ("x" * 100) + "\n", encoding="utf-8")
            result = run_cmd(["check", "--color", "never", "line.md"], cwd=d)
        self.assertEqual(result.returncode, 0)
        self.assertNotIn("[MD013]", result.stdout)

    def test_inline_disable_comments_suppress_rules_until_enabled(self):
        text = "<!-- rumdl-disable MD042 -->\n[bad]()\n<!-- rumdl-enable MD042 -->\n[bad]()\n"
        with tempfile.TemporaryDirectory() as d:
            Path(d, "inline.md").write_text(text, encoding="utf-8")
            result = run_cmd(["check", "--no-config", "--color", "never", "--disable", "MD041", "inline.md"], cwd=d)
        self.assertEqual(result.returncode, 1)
        self.assertEqual(result.stdout.count("[MD042]"), 1)
        self.assertIn("inline.md:4:1: [MD042] Empty link found: [bad]()", result.stdout)

    def test_rule_command_lists_known_rules(self):
        result = run_cmd(["rule"])
        self.assertEqual(result.returncode, 0)
        self.assertIn("MD001 - Heading levels should only increment", result.stdout)
        self.assertIn("Total: 67 rules", result.stdout)

    def test_init_creates_default_config(self):
        with tempfile.TemporaryDirectory() as d:
            result = run_cmd(["init"], cwd=d)
            config = Path(d, ".rumdl.toml").read_text(encoding="utf-8")
        self.assertEqual(result.returncode, 0)
        self.assertIn("Created configuration file: .rumdl.toml", result.stdout)
        self.assertIn("[global]", config)

    def test_explicit_files_ignore_exclude_unless_force_exclude(self):
        with tempfile.TemporaryDirectory() as d:
            Path(d, "bad.md").write_text("[bad]()\n", encoding="utf-8")
            explicit = run_cmd(["check", "--no-config", "--exclude", "bad.md", "--disable", "MD041", "bad.md"], cwd=d)
            forced = run_cmd(["check", "--no-config", "--exclude", "bad.md", "--force-exclude", "bad.md"], cwd=d)
        self.assertEqual(explicit.returncode, 1)
        self.assertIn("[MD042]", explicit.stdout)
        self.assertEqual(forced.returncode, 0)
        self.assertIn("Success: No issues found in 0 files", forced.stdout)


if __name__ == "__main__":
    unittest.main()
