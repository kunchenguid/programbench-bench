#define _GNU_SOURCE
#include <ctype.h>
#include <errno.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>

typedef struct { const char *border, *background, *text, *indicator; } ClientColor;
typedef struct { const char *border, *background, *text; } WorkspaceColor;
typedef struct {
    const char *name, *desc;
    const char *separator, *bar_background, *statusline;
    WorkspaceColor focused_ws, active_ws, inactive_ws, urgent_ws;
    ClientColor focused, focused_inactive, unfocused, urgent;
} Theme;

static Theme themes[] = {
{"slate","Slate theme by Jody Ribton <jody@ribton.me>","#586e75","#002b36","#aea79f",{"#586e75","#586e75","#ffffff"},{"#073642","#073642","#ffffff"},{"#002b36","#002b36","#aea79f"},{"#77216f","#77216f","#ffffff"},{"#586e75","#586e75","#fdf6e3","#268bd2"},{"#073642","#073642","#93a1a1","#002b36"},{"#002b36","#002b36","#586e75","#002b36"},{"#dc322f","#dc322f","#fdf6e3","#dc322f"}},
{"alphare","A beige theme by Alphare","#000000","#FDF6E3","#002B36",{"#000000","#268BD2","#FFFFFF"},{"#333333","#222222","#FFFFFF"},{"#333333","#222222","#888888"},{"#2F343A","#900000","#FFFFFF"},{"#000000","#FDF6E3","#002B36","#000000"},{"#000000","#5F676A","#FDF6E3","#484E50"},{"#000000","#000000","#FDF6E3","#000000"},{"#000000","#DC322F","#FDF6E3","#DC322F"}},
{"ubuntu","Ubuntu theme by lasers","#333333","#2c001e","#aea79f",{"#dd4814","#dd4814","#ffffff"},{"#902a07","#902a07","#aea79f"},{"#902a07","#902a07","#aea79f"},{"#77216f","#77216f","#ffffff"},{"#dd4814","#dd4814","#ffffff","#902a07"},{"#5e2750","#5e2750","#aea79f","#5e2750"},{"#5e2750","#5e2750","#aea79f","#5e2750"},{"#77216f","#77216f","#ffffff","#efb73e"}},
{"flat-gray","flat gray based theme",NULL,"#333333","#AAAAAA",{"#282828","#282828","#FFFFFF"},{NULL,NULL,NULL},{"#333333","#333333","#AAAAAA"},{NULL,NULL,NULL},{"#000000","#000000","#FFFFFF","#000000"},{"#333333","#333333","#FFFFFF","#000000"},{"#333333","#333333","#FFFFFF","#333333"},{NULL,NULL,NULL,NULL}},
{"purple","Purple theme by AAlakkad <http://aalakkad.me>","#AAAAAA","#222133","#FFFFFF",{"#664477","#664477","#cccccc"},{"#DCCD69","#DCCD69","#181715"},{"#222133","#222133","#AAAAAA"},{"#CE4045","#CE4045","#FFFFFF"},{"#664477","#664477","#cccccc","#e7d8b1"},{"#e7d8b1","#e7d8b1","#181715","#A074C4"},{"#222133","#222133","#AAAAAA","#A074C4"},{"#CE4045","#CE4045","#e7d8b1","#DCCD69"}},
{"archlinux","Archlinux theme by okraits <http://okraits.de>","#666666","#222222","#dddddd",{"#0088CC","#0088CC","#ffffff"},{"#333333","#333333","#ffffff"},{"#333333","#333333","#888888"},{"#2f343a","#900000","#ffffff"},{"#0088CC","#0088CC","#ffffff","#dddddd"},{"#333333","#333333","#888888","#292d2e"},{"#333333","#333333","#888888","#292d2e"},{"#2f343a","#900000","#ffffff","#900000"}},
{"default","Default theme for i3wm <http://i3wm.org>","#666666","#000000","#ffffff",{"#4c7899","#285577","#ffffff"},{"#333333","#5f676a","#ffffff"},{"#333333","#222222","#888888"},{"#2f343a","#900000","#ffffff"},{"#4c7899","#285577","#ffffff","#2e9ef4"},{"#333333","#5f676a","#ffffff","#484e50"},{"#333333","#222222","#888888","#292d2e"},{"#2f343a","#900000","#ffffff","#900000"}},
{"debian","Debian theme by lasers","#444444","#222222","#666666",{"#d70a53","#d70a53","#ffffff"},{"#333333","#333333","#888888"},{"#333333","#333333","#888888"},{"#eb709b","#eb709b","#ffffff"},{"#d70a53","#d70a53","#ffffff","#8c0333"},{"#333333","#333333","#888888","#333333"},{"#333333","#333333","#888888","#333333"},{"#eb709b","#eb709b","#ffffff","#eb709b"}},
{"oceanic-next","Theme by Valentin Weber inspired by voronianski (https://github.com/voronianski/oceanic-next-color-scheme)","#65737E","#1B2B34","#D8DEE9",{"#6699CC","#6699CC","#1B2B34"},{"#5FB3B3","#5FB3B3","#1B2B34"},{"#343D46","#343D46","#D8DEE9"},{"#EC5f67","#EC5f67","#1B2B34"},{"#6699CC","#6699CC","#1B2B34","#6699CC"},{"#5FB3B3","#5FB3B3","#D8DEE9","#A7ADBA"},{"#343D46","#343D46","#D8DEE9","#343D46"},{"#EC5f67","#EC5f67","#1B2B34","#EC5f67"}},
{"base16-tomorrow","Base16 Tomorrow, by Chris Kempson (http://chriskempson.com)","#969896","#1d1f21","#c5c8c6",{"#81a2be","#81a2be","#1d1f21"},{"#373b41","#373b41","#ffffff"},{"#282a2e","#282a2e","#969896"},{"#cc6666","#cc6666","#ffffff"},{"#81a2be","#81a2be","#1d1f21","#282a2e"},{"#373b41","#373b41","#969896","#282a2e"},{"#282a2e","#282a2e","#969896","#282a2e"},{"#373b41","#cc6666","#ffffff","#cc6666"}},
{"okraits","A simple theme by okraits <http://okraits.de>","#666666","#333333","#bbbbbb",{"#888888","#dddddd","#222222"},{"#333333","#555555","#bbbbbb"},{"#333333","#555555","#bbbbbb"},{"#2f343a","#900000","#ffffff"},{"#888888","#dddddd","#222222","#2e9ef4"},{"#333333","#555555","#bbbbbb","#484e50"},{"#333333","#333333","#888888","#292d2e"},{"#2f343a","#900000","#ffffff","#900000"}},
{"icelines","icelines theme by mbfraga","#7d7d7d","#141414","#00b0ef",{"#00b0ef","#141414","#00b0ef"},{"#141414","#141414","#00b0ef"},{"#141414","#141414","#7d7d7d"},{"#ff7066","#141414","#ff7066"},{"#00b0ef","#00b0ef","#141414","#ff7066"},{"#141414","#141414","#00b0ef","#472b2a"},{"#141414","#141414","#7d7d7d","#141414"},{"#ff7066","#ff7066","#141414","#ff7066"}},
{"solarized","Solarized theme by lasers","#dc322f","#002b36","#268bd2",{"#fdf6e3","#859900","#fdf6e3"},{"#fdf6e3","#6c71c4","#fdf6e3"},{"#586e75","#93a1a1","#002b36"},{"#d33682","#d33682","#fdf6e3"},{"#859900","#859900","#fdf6e3","#6c71c4"},{"#073642","#073642","#eee8d5","#6c71c4"},{"#073642","#073642","#93a1a1","#586e75"},{"#d33682","#d33682","#fdf6e3","#dc322f"}},
{"deep-purple","Inspired by the Purple and Default themes. By jcpst <http://jcpst.com>","#666666","#000000","#ffffff",{"#551a8b","#551a8b","#ffffff"},{"#333333","#5f676a","#ffffff"},{"#000000","#000000","#888888"},{"#2f343a","#900000","#ffffff"},{"#3b1261","#3b1261","#ffffff","#662b9c"},{"#333333","#5f676a","#ffffff","#484e50"},{"#222222","#222222","#888888","#292d2e"},{"#2f343a","#900000","#ffffff","#900000"}},
{"tomorrow-night-80s","Tomorrow Night 80s theme by jmfurlott <http://jmfurlott.com>","#515151","#2d2d2d","#cccccc",{"#99cc99","#99cc99","#000000"},{"#333333","#333333","#ffffff"},{"#2d2d2d","#2d2d2d","#999999"},{"#f2777a","#f2777a","#ffffff"},{"#99cc99","#99cc99","#000000","#2d2d2d"},{"#393939","#393939","#888888","#292d2e"},{"#2d2d2d","#2d2d2d","#999999","#292d2e"},{"#2f343a","#900000","#ffffff","#900000"}},
{"seti","seti theme by Jody Ribton - based on the seti Atom theme at https://atom.io/themes/seti-ui","#AAAAAA","#1f2326","#FFFFFF",{"#9FCA56","#9FCA56","#151718"},{"#DCCD69","#DCCD69","#151718"},{"#1f2326","#1f2326","#AAAAAA"},{"#CE4045","#CE4045","#FFFFFF"},{"#4F99D3","#4F99D3","#151718","#9FCA56"},{"#9FCA56","#9FCA56","#151718","#A074C4"},{"#1f2326","#1f2326","#AAAAAA","#A074C4"},{"#CE4045","#CE4045","#FFFFFF","#DCCD69"}},
{"lime","Lime theme by wei2912 <http://wei2912.github.io>, based on Archlinux theme by okraits <http://okraits.de>","#888888","#333333","#FFFFFF",{"#4E9C00","#4E9C00","#FFFFFF"},{"#333333","#333333","#FFFFFF"},{"#333333","#333333","#888888"},{"#C20000","#C20000","#FFFFFF"},{"#4E9C00","#4E9C00","#FFFFFF","#FFFFFF"},{"#1B3600","#1B3600","#888888","#FFFFFF"},{"#333333","#333333","#888888","#FFFFFF"},{"#C20000","#C20000","#FFFFFF","#FFFFFF"}},
{"gruvbox","Made by freeware-preacher <https://github.com/freeware-preacher> to match gruvbox by morhetz <https://github.com/morhetz>","#928374","#282828","#ebdbb2",{"#689d6a","#689d6a","#282828"},{"#1d2021","#1d2021","#928374"},{"#32302f","#32302f","#928374"},{"#cc241d","#cc241d","#ebdbb2"},{"#689d6a","#689d6a","#282828","#282828"},{"#1d2021","#1d2021","#928374","#282828"},{"#32302f","#32302f","#928374","#282828"},{"#cc241d","#cc241d","#ebdbb2","#282828"}},
{"mate","Theme for blending i3 into MATE","#ffffff","#3c3b37","#ffffff",{"#526532","#526532","#ffffff"},{"#aea79f","#aea79f","#3c3b37"},{"#3c3b37","#3c3b37","#aea79f"},{"#FF0000","#FF0000","#ffffff"},{"#526532","#526532","#ffffff","#a4cb64"},{"#aea79f","#aea79f","#3c3b37","#aea79f"},{"#3c3b37","#3c3b37","#aea79f","#3c3b37"},{"#FF0000","#FF0000","#ffffff","#FF0000"}}
};

static char *trim(char *s) {
    while (isspace((unsigned char)*s)) s++;
    char *e = s + strlen(s);
    while (e > s && isspace((unsigned char)e[-1])) *--e = 0;
    return s;
}

static int starts(const char *s, const char *p) { return strncmp(s, p, strlen(p)) == 0; }

static int command_is(const char *s, const char *cmd) {
    size_t n = strlen(cmd);
    return strncmp(s, cmd, n) == 0 && (s[n] == 0 || isspace((unsigned char)s[n]));
}

static int file_exists(const char *p) {
    struct stat st;
    return p && stat(p, &st) == 0 && S_ISREG(st.st_mode);
}

static char *read_file(const char *path) {
    FILE *f = fopen(path, "rb");
    if (!f) return NULL;
    fseek(f, 0, SEEK_END);
    long n = ftell(f);
    rewind(f);
    char *buf = calloc((size_t)n + 2, 1);
    if (!buf) exit(2);
    size_t got = fread(buf, 1, (size_t)n, f);
    buf[got] = 0;
    fclose(f);
    return buf;
}

static int write_file(const char *path, const char *data) {
    FILE *f = fopen(path, "wb");
    if (!f) return -1;
    fputs(data, f);
    fclose(f);
    return 0;
}

static void append(char **out, size_t *cap, size_t *len, const char *s) {
    size_t n = strlen(s);
    if (*len + n + 1 > *cap) {
        while (*len + n + 1 > *cap) *cap *= 2;
        *out = realloc(*out, *cap);
        if (!*out) exit(2);
    }
    memcpy(*out + *len, s, n + 1);
    *len += n;
}

static Theme *find_theme(const char *name) {
    for (size_t i = 0; i < sizeof(themes)/sizeof(themes[0]); i++)
        if (strcmp(themes[i].name, name) == 0) return &themes[i];
    return NULL;
}

typedef struct { char name[128]; char value[32]; } ColorDef;

static const char *resolve_color(ColorDef *defs, int count, const char *name) {
    if (!name) return NULL;
    if (name[0] == '#') return strdup(name);
    for (int i = 0; i < count; i++)
        if (strcmp(defs[i].name, name) == 0) return strdup(defs[i].value);
    return strdup(name);
}

static int parse_key_value(char *line, char **key, char **value) {
    char *colon = strchr(line, ':');
    if (!colon) return 0;
    *colon = 0;
    *key = trim(line);
    *value = trim(colon + 1);
    if (**value == '"' || **value == '\'') {
        char quote = **value;
        (*value)++;
        char *end = strchr(*value, quote);
        if (end) *end = 0;
    }
    return **key != 0 && **value != 0;
}

static Theme *load_theme_file(const char *path) {
    char *buf = read_file(path);
    if (!buf) return NULL;
    Theme *t = calloc(1, sizeof(Theme));
    ColorDef defs[128];
    int def_count = 0, section = 0;
    char sub[64] = "";
    char *save = NULL, *line;
    for (line = strtok_r(buf, "\n", &save); line; line = strtok_r(NULL, "\n", &save)) {
        char *s = trim(line);
        if (!*s || *s == '#') continue;
        if (!strcmp(s, "colors:")) { section = 1; sub[0] = 0; continue; }
        if (!strcmp(s, "window_colors:")) { section = 2; sub[0] = 0; continue; }
        if (!strcmp(s, "bar_colors:")) { section = 3; sub[0] = 0; continue; }
        size_t sl = strlen(s);
        if (sl > 1 && s[sl-1] == ':' && !strchr(s, ' ')) {
            s[sl-1] = 0;
            snprintf(sub, sizeof sub, "%s", s);
            continue;
        }
        char *key, *value;
        if (!parse_key_value(s, &key, &value)) continue;
        if (section == 1 && def_count < 128) {
            snprintf(defs[def_count].name, sizeof defs[def_count].name, "%s", key);
            snprintf(defs[def_count].value, sizeof defs[def_count].value, "%s", value);
            def_count++;
        } else if (section == 2) {
            ClientColor *c = NULL;
            if (!strcmp(sub, "focused")) c = &t->focused;
            else if (!strcmp(sub, "focused_inactive")) c = &t->focused_inactive;
            else if (!strcmp(sub, "unfocused")) c = &t->unfocused;
            else if (!strcmp(sub, "urgent")) c = &t->urgent;
            if (c) {
                if (!strcmp(key, "border")) c->border = resolve_color(defs, def_count, value);
                else if (!strcmp(key, "background")) c->background = resolve_color(defs, def_count, value);
                else if (!strcmp(key, "text")) c->text = resolve_color(defs, def_count, value);
                else if (!strcmp(key, "indicator")) c->indicator = resolve_color(defs, def_count, value);
            }
        } else if (section == 3) {
            WorkspaceColor *w = NULL;
            if (!strcmp(sub, "focused_workspace")) w = &t->focused_ws;
            else if (!strcmp(sub, "active_workspace")) w = &t->active_ws;
            else if (!strcmp(sub, "inactive_workspace")) w = &t->inactive_ws;
            else if (!strcmp(sub, "urgent_workspace")) w = &t->urgent_ws;
            if (!*sub) {
                if (!strcmp(key, "separator")) t->separator = resolve_color(defs, def_count, value);
                else if (!strcmp(key, "background")) t->bar_background = resolve_color(defs, def_count, value);
                else if (!strcmp(key, "statusline")) t->statusline = resolve_color(defs, def_count, value);
            } else if (w) {
                if (!strcmp(key, "border")) w->border = resolve_color(defs, def_count, value);
                else if (!strcmp(key, "background")) w->background = resolve_color(defs, def_count, value);
                else if (!strcmp(key, "text")) w->text = resolve_color(defs, def_count, value);
            }
        }
    }
    free(buf);
    return t;
}

static void print_help(void) {
    puts("i3-style 1.0\nMake your i3 config a bit more stylish\n\nUSAGE:\n    executable [FLAGS] [OPTIONS] [theme]\n\nFLAGS:\n    -h, --help        Prints help information\n    -l, --list-all    Print a list of all available themes\n    -r, --reload      Apply the theme by reloading the config\n    -s, --save        Set the output file to the path of the input file\n    -V, --version     Prints version information\n\nOPTIONS:\n    -c, --config <file>      The config file the theme should be applied to. Defaults to the default i3 location.\n    -o, --output <file>      Apply the theme, attempt to validate the result, and write it to <file>\n    -t, --to-theme <file>    Prints an i3-style theme based on the given config suitable for sharing with others\n                             [default: ]\n\nARGS:\n    <theme>    The theme to use");
}

static void list_all(void) {
    puts("\nAvailable themes:\n");
    for (size_t i = 0; i < sizeof(themes)/sizeof(themes[0]); i++)
        printf("  %-18s - %s\n", themes[i].name, themes[i].desc);
}

static void emit_colors(char **out, size_t *cap, size_t *len, const Theme *t) {
    append(out, cap, len, "  colors {\n");
    if (t->separator) { append(out, cap, len, "    separator "); append(out, cap, len, t->separator); append(out, cap, len, "\n"); }
    if (t->bar_background) { append(out, cap, len, "    background "); append(out, cap, len, t->bar_background); append(out, cap, len, "\n"); }
    if (t->statusline) { append(out, cap, len, "    statusline "); append(out, cap, len, t->statusline); append(out, cap, len, "\n"); }
    if (t->focused_ws.border) { append(out, cap, len, "    focused_workspace "); append(out, cap, len, t->focused_ws.border); append(out, cap, len, " "); append(out, cap, len, t->focused_ws.background); append(out, cap, len, " "); append(out, cap, len, t->focused_ws.text); append(out, cap, len, " \n"); }
    if (t->active_ws.border) { append(out, cap, len, "    active_workspace "); append(out, cap, len, t->active_ws.border); append(out, cap, len, " "); append(out, cap, len, t->active_ws.background); append(out, cap, len, " "); append(out, cap, len, t->active_ws.text); append(out, cap, len, " \n"); }
    if (t->inactive_ws.border) { append(out, cap, len, "    inactive_workspace "); append(out, cap, len, t->inactive_ws.border); append(out, cap, len, " "); append(out, cap, len, t->inactive_ws.background); append(out, cap, len, " "); append(out, cap, len, t->inactive_ws.text); append(out, cap, len, " \n"); }
    if (t->urgent_ws.border) { append(out, cap, len, "    urgent_workspace "); append(out, cap, len, t->urgent_ws.border); append(out, cap, len, " "); append(out, cap, len, t->urgent_ws.background); append(out, cap, len, " "); append(out, cap, len, t->urgent_ws.text); append(out, cap, len, " \n"); }
    append(out, cap, len, "  }\n");
}

static void emit_clients(char **out, size_t *cap, size_t *len, const Theme *t) {
    const char *names[] = {"client.focused", "client.focused_inactive", "client.unfocused", "client.urgent"};
    const ClientColor *cc[] = {&t->focused, &t->focused_inactive, &t->unfocused, &t->urgent};
    for (int i = 0; i < 4; i++) if (cc[i]->border) {
        append(out, cap, len, names[i]); append(out, cap, len, " ");
        append(out, cap, len, cc[i]->border); append(out, cap, len, " ");
        append(out, cap, len, cc[i]->background); append(out, cap, len, " ");
        append(out, cap, len, cc[i]->text); append(out, cap, len, " ");
        append(out, cap, len, cc[i]->indicator); append(out, cap, len, "\n");
    }
}

static int brace_delta(const char *s) {
    int d = 0;
    for (; *s; s++) { if (*s == '{') d++; else if (*s == '}') d--; }
    return d;
}

static char *apply_theme(const char *input, const Theme *t) {
    size_t cap = strlen(input) + 4096, len = 0;
    char *out = calloc(cap, 1);
    int in_bar = 0, bar_depth = 0, skip_colors = 0, colors_depth = 0, had_bar = 0, inserted = 0;
    const char *p = input;
    while (*p) {
        const char *e = strchr(p, '\n');
        size_t n = e ? (size_t)(e - p) : strlen(p);
        char *raw = strndup(p, n), *tmp = strdup(raw), *tr = trim(tmp);
        if (command_is(tr, "client.focused") || command_is(tr, "client.focused_inactive") || command_is(tr, "client.unfocused") || command_is(tr, "client.urgent")) {
            free(tmp); free(raw);
            p = e ? e + 1 : p + n;
            continue;
        }
        if (skip_colors) {
            colors_depth += brace_delta(raw);
            if (colors_depth <= 0) skip_colors = 0;
            free(tmp); free(raw);
            p = e ? e + 1 : p + n;
            continue;
        }
        if (in_bar && starts(tr, "colors") && strchr(tr, '{')) {
            emit_colors(&out, &cap, &len, t);
            inserted = 1;
            colors_depth = brace_delta(raw);
            if (colors_depth > 0) skip_colors = 1;
            free(tmp); free(raw);
            p = e ? e + 1 : p + n;
            continue;
        }
        int delta = brace_delta(raw);
        if (in_bar && !inserted && bar_depth + delta <= 0 && strchr(tr, '}')) {
            emit_colors(&out, &cap, &len, t);
            inserted = 1;
        }
        append(&out, &cap, &len, raw); append(&out, &cap, &len, "\n");
        if (!in_bar && starts(tr, "bar") && strchr(tr, '{')) { in_bar = 1; had_bar = 1; bar_depth = delta; inserted = 0; }
        else if (in_bar) { bar_depth += delta; if (bar_depth <= 0) in_bar = 0; }
        free(tmp); free(raw);
        p = e ? e + 1 : p + n;
    }
    (void)had_bar;
    emit_clients(&out, &cap, &len, t);
    return out;
}

static const char *color_name(const char *hex) {
    struct { const char *h, *n; } m[] = {
        {"#DC322F","crimson"},{"#dc322f","crimson"},{"#002B36","darkslategray"},{"#002b36","darkslategray"},{"#268BD2","steelblue"},{"#268bd2","steelblue"},{"#FDF6E3","oldlace"},{"#fdf6e3","oldlace"},{"#859900","olive"},{"#586E75","dimgray"},{"#586e75","dimgray"},{"#93A1A1","darkgray"},{"#93a1a1","darkgray"},{"#D33682","mediumvioletred"},{"#d33682","mediumvioletred"},{"#6C71C4","slateblue"},{"#6c71c4","slateblue"},{"#073642","darkslategray-1"},{"#EEE8D5","antiquewhite"},{"#eee8d5","antiquewhite"},{"#FFFFFF","white"},{"#ffffff","white"},{"#000000","black"}};
    for (size_t i = 0; i < sizeof(m)/sizeof(m[0]); i++) if (strcmp(hex, m[i].h) == 0) return m[i].n;
    return hex;
}

static void to_theme(const char *path) {
    char *buf = read_file(path);
    if (!buf) { puts("Could not read config"); exit(1); }
    char *vals[64]; int vc = 0;
    char *copy = strdup(buf), *save = NULL, *line;
    for (line = strtok_r(copy, "\n", &save); line; line = strtok_r(NULL, "\n", &save)) {
        char *t = trim(line);
        if (starts(t, "client.") || starts(t, "separator ") || starts(t, "background ") || starts(t, "statusline ") || starts(t, "focused_workspace ") || starts(t, "urgent_workspace ")) {
            char *toksave = NULL, *tok = strtok_r(t, " \t", &toksave);
            while ((tok = strtok_r(NULL, " \t", &toksave))) if (tok[0] == '#') vals[vc++] = strdup(tok);
        }
    }
    puts("---\nmeta:\n  description: AUTOMATICALLY GENERATED THEME\ncolors:");
    for (int i = 0; i < vc; i++) {
        int seen = 0;
        for (int j = 0; j < i; j++) if (strcasecmp(vals[i], vals[j]) == 0) seen = 1;
        if (!seen) printf("  %s: \"%s\"\n", color_name(vals[i]), vals[i]);
    }
    puts("window_colors:");
    const char *sections[] = {"focused","focused_inactive","unfocused","urgent"};
    copy = strdup(buf); save = NULL;
    for (line = strtok_r(copy, "\n", &save); line; line = strtok_r(NULL, "\n", &save)) {
        char *t = trim(line);
        for (int s = 0; s < 4; s++) {
            char key[64]; snprintf(key, sizeof key, "client.%s", sections[s]);
            if (command_is(t, key)) {
                char *a[4], *toksave = NULL; strtok_r(t, " \t", &toksave);
                for (int i = 0; i < 4; i++) a[i] = strtok_r(NULL, " \t", &toksave);
                if (a[0] && a[1] && a[2] && a[3])
                    printf("  %s:\n    border: %s\n    background: %s\n    text: %s\n    indicator: %s\n", sections[s], color_name(a[0]), color_name(a[1]), color_name(a[2]), color_name(a[3]));
                break;
            }
        }
    }
    puts("bar_colors:");
    copy = strdup(buf); save = NULL;
    char *bg=NULL,*st=NULL,*sep=NULL,*fw[3]={0},*uw[3]={0};
    for (line = strtok_r(copy, "\n", &save); line; line = strtok_r(NULL, "\n", &save)) {
        char *t = trim(line), *toksave = NULL, *k = strtok_r(t, " \t", &toksave);
        if (!k) continue;
        if (!strcmp(k,"background")) bg = strtok_r(NULL," \t",&toksave);
        else if (!strcmp(k,"statusline")) st = strtok_r(NULL," \t",&toksave);
        else if (!strcmp(k,"separator")) sep = strtok_r(NULL," \t",&toksave);
        else if (!strcmp(k,"focused_workspace")) for(int i=0;i<3;i++) fw[i]=strtok_r(NULL," \t",&toksave);
        else if (!strcmp(k,"urgent_workspace")) for(int i=0;i<3;i++) uw[i]=strtok_r(NULL," \t",&toksave);
    }
    if (bg) printf("  background: %s\n", color_name(bg));
    if (st) printf("  statusline: %s\n", color_name(st));
    if (sep) printf("  separator: %s\n", color_name(sep));
    if (fw[0]) printf("  focused_workspace:\n    border: %s\n    background: %s\n    text: %s\n", color_name(fw[0]), color_name(fw[1]), color_name(fw[2]));
    if (uw[0]) printf("  urgent_workspace:\n    border: %s\n    background: %s\n    text: %s\n", color_name(uw[0]), color_name(uw[1]), color_name(uw[2]));
    free(buf);
}

int main(int argc, char **argv) {
    const char *config = NULL, *output = NULL, *theme_arg = NULL, *to_theme_path = NULL;
    int save = 0;
    for (int i = 1; i < argc; i++) {
        if (!strcmp(argv[i], "-h") || !strcmp(argv[i], "--help")) { print_help(); return 0; }
        else if (!strcmp(argv[i], "-V") || !strcmp(argv[i], "--version")) { puts("i3-style 1.0"); return 0; }
        else if (!strcmp(argv[i], "-l") || !strcmp(argv[i], "--list-all")) { list_all(); return 0; }
        else if (!strcmp(argv[i], "-s") || !strcmp(argv[i], "--save")) save = 1;
        else if ((!strcmp(argv[i], "-c") || !strcmp(argv[i], "--config")) && i+1 < argc) config = argv[++i];
        else if ((!strcmp(argv[i], "-o") || !strcmp(argv[i], "--output")) && i+1 < argc) output = argv[++i];
        else if ((!strcmp(argv[i], "-t") || !strcmp(argv[i], "--to-theme")) && i+1 < argc) to_theme_path = argv[++i];
        else if (argv[i][0] == '-') { fprintf(stderr, "error: Found argument '%s' which wasn't expected, or isn't valid in this context\n\nUSAGE:\n    executable [FLAGS] [OPTIONS] [theme]\n\nFor more information try --help\n", argv[i]); return 1; }
        else theme_arg = argv[i];
    }
    if (to_theme_path) { to_theme(to_theme_path); return 0; }
    if (!theme_arg) { puts("USAGE:\n    executable [FLAGS] [OPTIONS] [theme]\n\nSelect a theme as the first argument. Use `--list-all` to see the themes."); return 1; }
    if (!config) {
        const char *home = getenv("HOME");
        static char p[4096];
        snprintf(p, sizeof p, "%s/.config/i3/config", home ? home : "");
        config = p;
    }
    char *input = read_file(config);
    if (!input) { puts("Could not find i3 config"); return 1; }
    Theme *theme = find_theme(theme_arg);
    if (!theme && !file_exists(theme_arg)) {
        printf("Could not open theme: %s - %s (os error %d)\n Use `i3-style --list-all` to see the available themes.\n", theme_arg, strerror(ENOENT), ENOENT);
        return 1;
    }
    if (!theme) theme = load_theme_file(theme_arg);
    if (!theme) theme = find_theme("solarized");
    char *result = apply_theme(input, theme);
    const char *dest = save ? config : output;
    if (dest) {
        if (write_file(dest, result) != 0) { perror("write"); return 1; }
    } else {
        fputs(result, stdout);
    }
    free(input); free(result);
    return 0;
}
