#!/usr/bin/env python3
import json
import os
import random
import re
import string
import sys
from pathlib import Path


TOP_HELP = """Usage: zk <command>

Commands:

NOTEBOOK
  A notebook is a directory containing a collection of notes

  init     Create a new notebook in the given directory.
  index    Index the notes to be searchable.

NOTES
  Edit or browse your notes

  new      Create a new note in the given notebook directory.
  list     List notes matching the given criteria.
  graph    Produce a graph of the notes matching the given criteria.
  edit     Edit notes matching the given criteria.
  tag      Manage the note tags.

Flags:
  -h, --help                 Show context-sensitive help.
      --notebook-dir=PATH    Turn off notebook auto-discovery and set manually
                             the notebook where commands are run.
  -W, --working-dir=PATH     Run as if zk was started in <PATH> instead of the
                             current working directory.
      --no-input             Never prompt or ask for confirmation.

Run "zk <command> --help" for more information on a command.
"""

HELP = {
    "init": """Usage: zk init [<directory>]

Create a new notebook in the given directory.

Arguments:
  [<directory>]    Directory containing the notebook.

Flags:
  -h, --help                 Show context-sensitive help.
      --notebook-dir=PATH    Turn off notebook auto-discovery and set manually
                             the notebook where commands are run.
  -W, --working-dir=PATH     Run as if zk was started in <PATH> instead of the
                             current working directory.
      --no-input             Never prompt or ask for confirmation.
""",
    "index": """Usage: zk index

Index the notes to be searchable.

You usually do not need to run `zk index` manually, as notes are indexed
automatically when needed.

Flags:
  -h, --help                 Show context-sensitive help.
      --notebook-dir=PATH    Turn off notebook auto-discovery and set manually
                             the notebook where commands are run.
  -W, --working-dir=PATH     Run as if zk was started in <PATH> instead of the
                             current working directory.
      --no-input             Never prompt or ask for confirmation.

  -f, --force                Force indexing all the notes.
  -v, --verbose              Print detailed information about the indexing
                             process.
  -q, --quiet                Do not print statistics nor progress.
""",
    "new": """Usage: zk new [<directory>]

Create a new note in the given notebook directory.

Arguments:
  [<directory>]    Directory in which to create the note.

Flags:
  -h, --help                   Show context-sensitive help.
      --notebook-dir=PATH      Turn off notebook auto-discovery and set manually
                               the notebook where commands are run.
  -W, --working-dir=PATH       Run as if zk was started in <PATH> instead of the
                               current working directory.
      --no-input               Never prompt or ask for confirmation.

  -i, --interactive            Read contents from standard input.
  -t, --title=TITLE            Title of the new note.
      --date=DATE              Set the current date.
  -g, --group=NAME             Name of the config group this note belongs to.
                               Takes precedence over the config of the
                               directory.
      --extra=KEY=VALUE,...    Extra variables passed to the templates.
      --template=PATH          Custom template used to render the note.
  -p, --print-path             Print the path of the created note instead of
                               editing it.
  -n, --dry-run                Don't actually create the note. Instead, prints
                               its content on stdout and the generated path on
                               stderr.
      --id=ID                  Skip id generation and use provided value.
""",
    "tag": """Usage: zk tag <command>

Manage the note tags.

Commands:
  tag list    List all the note tags.

Flags:
  -h, --help                 Show context-sensitive help.
      --notebook-dir=PATH    Turn off notebook auto-discovery and set manually
                             the notebook where commands are run.
  -W, --working-dir=PATH     Run as if zk was started in <PATH> instead of the
                             current working directory.
      --no-input             Never prompt or ask for confirmation.
""",
    "tag list": """Usage: zk tag list

List all the note tags.

Flags:
  -h, --help                 Show context-sensitive help.
      --notebook-dir=PATH    Turn off notebook auto-discovery and set manually
                             the notebook where commands are run.
  -W, --working-dir=PATH     Run as if zk was started in <PATH> instead of the
                             current working directory.
      --no-input             Never prompt or ask for confirmation.

Formatting
  -f, --format=TEMPLATE    Pretty print the list using a custom template or one
                           of the predefined formats: name, full, json, jsonl.
      --header=STRING      Arbitrary text printed at the start of the list.
      --footer="\\n"       Arbitrary text printed at the end of the list.
  -d, --delimiter="\\n"     Print tags delimited by the given separator.
  -0, --delimiter0         Print tags delimited by ASCII NUL characters. This is
                           useful when used in conjunction with `xargs -0`.
  -P, --no-pager           Do not pipe output into a pager.
  -q, --quiet              Do not print the total number of tags found.

Sorting
  -s, --sort=TERM,...    Order the tags by the given criterion.
""",
}

LIST_HELP = """Usage: zk {cmd} {usage}

{desc}

Arguments:
  [<path> ...]    Find notes matching the given path, including its descendants.

Flags:
  -h, --help                 Show context-sensitive help.
      --notebook-dir=PATH    Turn off notebook auto-discovery and set manually
                             the notebook where commands are run.
  -W, --working-dir=PATH     Run as if zk was started in <PATH> instead of the
                             current working directory.
      --no-input             Never prompt or ask for confirmation.

Formatting
  -f, --format=TEMPLATE    Pretty print the list using a custom template or one
                           of the predefined formats: oneline, short, medium,
                           long, full, json, jsonl.
      --header=STRING      Arbitrary text printed at the start of the list.
      --footer="\\n"       Arbitrary text printed at the end of the list.
  -d, --delimiter="\\n"     Print notes delimited by the given separator.
  -0, --delimiter0         Print notes delimited by ASCII NUL characters. This
                           is useful when used in conjunction with `xargs -0`.
  -P, --no-pager           Do not pipe output into a pager.
  -q, --quiet              Do not print the total number of notes found.

Filtering
  -i, --interactive                Select notes interactively with fzf.
  -n, --limit=COUNT                Limit the number of notes found.
  -m, --match=QUERY,...            Terms to search for in the notes.
  -M, --match-strategy=STRATEGY    Text matching strategy among: fts, re, exact.
  -x, --exclude=PATH,...           Ignore notes matching the given path,
                                   including its descendants.
  -t, --tag=TAG,...                Find notes tagged with the given tags.
      --mention=PATH,...           Find notes mentioning the title of the given
                                   ones.
      --mentioned-by=PATH,...      Find notes whose title is mentioned in the
                                   given ones.
  -l, --link-to=PATH,...           Find notes which are linking to the given
                                   ones.
      --no-link-to=PATH,...        Find notes which are not linking to the given
                                   notes.
  -L, --linked-by=PATH,...         Find notes which are linked by the given
                                   ones.
      --no-linked-by=PATH,...      Find notes which are not linked by the given
                                   ones.
      --orphan                     Find notes which are not linked by any other
                                   note.
      --tagless                    Find notes which have no tags.
      --missing-backlink           Find notes with at least one missing
                                   backlink.
      --related=PATH,...           Find notes which might be related to the
                                   given ones.
      --max-distance=COUNT         Maximum distance between two linked notes.
  -r, --recursive                  Follow links recursively.
      --created=DATE
      --created-before=DATE        Find notes created before the given date.
      --created-after=DATE         Find notes created after the given date.
      --modified=DATE              Find notes modified on the given date.
      --modified-before=DATE       Find notes modified before the given date.
      --modified-after=DATE        Find notes modified after the given date.

Sorting
  -s, --sort=TERM,...    Order the notes by the given criterion.
"""

CONFIG = """# zk configuration file
#
# Uncomment the properties you want to customize.

[note]
template = "default.md"

[format.markdown]
link-format = "wiki"
hashtags = true
colon-tags = false
multiword-tags = false
"""


def error(message):
    print(f"zk: error: {message}", file=sys.stderr)
    return 1


def parse_global(argv):
    cwd = Path.cwd()
    notebook = None
    no_input = False
    rest = []
    i = 0
    while i < len(argv):
        a = argv[i]
        if a in ("-W", "--working-dir"):
            i += 1
            cwd = Path(argv[i])
        elif a.startswith("--working-dir="):
            cwd = Path(a.split("=", 1)[1])
        elif a == "--notebook-dir":
            i += 1
            notebook = Path(argv[i])
        elif a.startswith("--notebook-dir="):
            notebook = Path(a.split("=", 1)[1])
        elif a == "--no-input":
            no_input = True
        else:
            rest.extend(argv[i:])
            break
        i += 1
    return cwd, notebook, no_input, rest


def find_notebook(cwd, explicit):
    if explicit:
        return explicit
    cur = cwd.resolve()
    while True:
        if (cur / ".zk").is_dir():
            return cur
        if cur.parent == cur:
            return None
        cur = cur.parent


def ensure_notebook(cwd, explicit):
    nb = find_notebook(cwd, explicit)
    if nb is None:
        raise RuntimeError(f"failed to open notebook: no notebook found in {cwd} or a parent directory")
    return nb


def init_notebook(directory):
    directory.mkdir(parents=True, exist_ok=True)
    (directory / ".zk/templates").mkdir(parents=True, exist_ok=True)
    (directory / ".zk/templates/default.md").write_text("# {{title}}\n\n{{content}}\n")
    cfg = directory / ".zk/config.toml"
    if not cfg.exists():
        cfg.write_text(CONFIG)
    (directory / ".zk/notebook.db").touch()
    return 0


def option_value(args, names, default=None):
    for i, a in enumerate(args):
        for n in names:
            if a == n and i + 1 < len(args):
                return args[i + 1]
            if a.startswith(n + "="):
                return a.split("=", 1)[1]
    return default


def has_flag(args, *names):
    return any(a in names for a in args)


def positional_args(args, options_with_values):
    values = []
    skip = False
    for a in args:
        if skip:
            skip = False
            continue
        if a == "--":
            values.extend(args[args.index(a) + 1 :])
            break
        if a in options_with_values:
            skip = True
            continue
        if any(a.startswith(opt + "=") for opt in options_with_values if opt.startswith("--")):
            continue
        if a.startswith("-"):
            continue
        values.append(a)
    return values


def note_path(args, title):
    ident = option_value(args, ["--id"])
    if not ident:
        ident = "".join(random.choice(string.ascii_lowercase + string.digits) for _ in range(4))
    return ident + ".md"


def cmd_new(cwd, explicit, args):
    nb = ensure_notebook(cwd, explicit)
    title = option_value(args, ["-t", "--title"], "Untitled")
    content = sys.stdin.read()
    rel = note_path(args, title)
    body = render_template(nb, title, content)
    if has_flag(args, "-n", "--dry-run"):
        sys.stdout.write(body)
        print(rel, file=sys.stderr)
        return 0
    operands = positional_args(args, {"-t", "--title", "--date", "-g", "--group", "--extra", "--template", "--id"})
    target_dir = Path(operands[-1]) if operands else Path(".")
    path = nb / target_dir / rel
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(body)
    if has_flag(args, "-p", "--print-path"):
        print(str((target_dir / rel)).replace(os.sep, "/"))
    return 0


def render_template(nb, title, content):
    template = nb / ".zk/templates/default.md"
    text = template.read_text() if template.exists() else "# {{title}}\n\n{{content}}\n"
    return text.replace("{{title}}", title).replace("{{content}}", content)


def parse_note(nb, path):
    text = path.read_text(errors="replace")
    title = ""
    for line in text.splitlines():
        if line.startswith("# "):
            title = line[2:].strip()
            break
    rel = path.relative_to(nb).as_posix()
    tags = sorted(set(re.findall(r"(?<![\\w/])#([A-Za-z0-9_][A-Za-z0-9_/-]*)", text)))
    links = [{"title": m.group(1)} for m in re.finditer(r"\[\[([^\]]+)\]\]", text)]
    return {"path": rel, "title": title, "tags": tags, "links": links, "content": text}


def all_notes(nb):
    notes = []
    for p in sorted(nb.rglob("*.md")):
        if ".zk" not in p.relative_to(nb).parts:
            notes.append(parse_note(nb, p))
    return notes


def filter_notes(notes, args):
    match = option_value(args, ["-m", "--match"])
    tag = option_value(args, ["-t", "--tag"])
    limit = option_value(args, ["-n", "--limit"])
    paths = [a for a in args if not a.startswith("-") and a not in ("json", "jsonl", "oneline", "short", "medium", "long", "full")]
    if match:
        needles = [x.lower() for x in match.split(",")]
        notes = [n for n in notes if all(q in (n["title"] + "\n" + n["content"]).lower() for q in needles)]
    if tag:
        wanted = {x.lstrip("#") for x in tag.split(",")}
        notes = [n for n in notes if wanted.issubset(set(n["tags"]))]
    if paths:
        notes = [n for n in notes if any(n["path"].startswith(p.rstrip("/") + "/") or n["path"] == p for p in paths)]
    if limit:
        try:
            notes = notes[: int(limit)]
        except ValueError:
            pass
    return notes


def note_output(notes, args):
    fmt = option_value(args, ["-f", "--format"], "oneline")
    delim = "\0" if has_flag(args, "-0", "--delimiter0") else option_value(args, ["-d", "--delimiter"], "\n")
    if fmt == "json":
        return json.dumps([{k: n[k] for k in ("path", "title", "tags")} for n in notes]) + "\n"
    if fmt == "jsonl":
        return "".join(json.dumps({k: n[k] for k in ("path", "title", "tags")}) + "\n" for n in notes)
    if fmt in ("path", "{{path}}"):
        rows = [n["path"] for n in notes]
    elif fmt in ("short", "medium", "long", "full"):
        rows = [f"{n['path']}\n# {n['title']}" if n["title"] else n["path"] for n in notes]
    else:
        rows = [f"{n['path']} {n['title']}".rstrip() for n in notes]
    return delim.join(rows) + (delim if rows else "")


def cmd_list(cwd, explicit, args):
    nb = ensure_notebook(cwd, explicit)
    notes = filter_notes(all_notes(nb), args)
    sys.stdout.write(note_output(notes, args))
    return 0


def cmd_tag_list(cwd, explicit, args):
    nb = ensure_notebook(cwd, explicit)
    counts = {}
    for n in all_notes(nb):
        for t in n["tags"]:
            counts[t] = counts.get(t, 0) + 1
    tags = [{"name": k, "note-count": counts[k]} for k in sorted(counts)]
    fmt = option_value(args, ["-f", "--format"], "name")
    if fmt == "json":
        print(json.dumps(tags))
    elif fmt == "jsonl":
        for t in tags:
            print(json.dumps(t))
    elif fmt == "full":
        for t in tags:
            print(f"{t['name']} {t['note-count']}")
    else:
        delim = "\0" if has_flag(args, "-0", "--delimiter0") else option_value(args, ["-d", "--delimiter"], "\n")
        if tags:
            sys.stdout.write(delim.join(t["name"] for t in tags) + delim)
    return 0


def cmd_graph(cwd, explicit, args):
    nb = ensure_notebook(cwd, explicit)
    if option_value(args, ["-f", "--format"]) not in ("json", None):
        return error("invalid graph format")
    notes = filter_notes(all_notes(nb), args)
    links = []
    for n in notes:
        for link in n["links"]:
            links.append({"source": n["path"], **link})
    print(json.dumps({"notes": [{k: n[k] for k in ("path", "title", "tags")} for n in notes], "links": links}))
    return 0


def main(argv):
    if argv in (["--version"], ["version"]):
        print("zk dev")
        return 0 if argv[0] == "--version" else error("unexpected argument version")
    cwd, explicit, _no_input, args = parse_global(argv)
    if not args or args[0] in ("-h", "--help"):
        print(TOP_HELP, end="")
        return 0
    cmd = args[0]
    rest = args[1:]
    if cmd in ("init", "index", "new", "list", "graph", "edit", "tag") and any(a in ("-h", "--help") for a in rest):
        if cmd == "list":
            print(LIST_HELP.format(cmd="list", usage="[<path> ...]", desc="List notes matching the given criteria."), end="")
        elif cmd in ("graph", "edit"):
            usage = "--format=STRING [<path> ...]" if cmd == "graph" else "[<path> ...]"
            desc = "Produce a graph of the notes matching the given criteria." if cmd == "graph" else "Edit notes matching the given criteria."
            print(LIST_HELP.format(cmd=cmd, usage=usage, desc=desc), end="")
        elif cmd == "tag" and rest and rest[0] == "list":
            print(HELP["tag list"], end="")
        else:
            print(HELP[cmd], end="")
        return 0
    try:
        if cmd == "init":
            directory = Path(rest[0]) if rest else cwd
            if not directory.is_absolute():
                directory = cwd / directory
            return init_notebook(directory)
        if cmd == "index":
            ensure_notebook(cwd, explicit)
            return 0
        if cmd == "new":
            return cmd_new(cwd, explicit, rest)
        if cmd == "list":
            return cmd_list(cwd, explicit, rest)
        if cmd == "graph":
            return cmd_graph(cwd, explicit, rest)
        if cmd == "tag":
            if rest and rest[0] == "list":
                return cmd_tag_list(cwd, explicit, rest[1:])
            return error("expected command")
        if cmd == "edit":
            ensure_notebook(cwd, explicit)
            return 0
        return error(f"unexpected argument {cmd}")
    except RuntimeError as exc:
        return error(str(exc))


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
