#!/usr/bin/env python3
import base64
import datetime as _dt
import html
import mimetypes
import os
import re
import sys
import urllib.parse
import urllib.request
from html.parser import HTMLParser


VERSION = "monolith 2.11.0"
BANNER = r""" _____    _____________   __________     ___________________    ___
|     \  /             \ |          |   |                   |  |   |
|      \/       __      \|    __    |   |    ___     ___    |__|   |
|              |  |          |  |   |   |   |   |   |   |          |
|   |\    /|   |__|          |__|   |___|   |   |   |   |    __    |
|   | \__/ |          |\                    |   |   |   |   |  |   |
|___|      |__________| \___________________|   |___|   |___|  |___|
"""

HELP = BANNER + """
monolith 2.11.0

CLI tool and library for saving web pages as a single HTML file

Usage: executable [OPTIONS] <TARGET>

Arguments:
  <TARGET>  URL or file path, use - for STDIN

Options:
  -a, --no-audio                      Remove audio sources
  -b, --base-url <http://localhost/>  Set custom base URL
  -B, --blacklist-domains             Treat specified domains as blacklist
  -c, --no-css                        Remove CSS
  -C, --cookie-file <cookies.txt>     Specify cookie file
  -d, --domain <example.com>          Specify domains to use for white/black-listing
  -e, --ignore-errors                 Ignore network errors
  -E, --encoding <UTF-8>              Enforce custom charset
  -f, --no-frames                     Remove frames and iframes
  -F, --no-fonts                      Remove fonts
  -i, --no-images                     Remove images
  -I, --isolate                       Cut off document from the Internet
  -j, --no-js                         Remove JavaScript
  -k, --insecure                      Allow invalid X.509 (TLS) certificates
  -m, --mhtml                         Use MHTML as output format
  -M, --no-metadata                   Exclude timestamp and source information
  -n, --unwrap-noscript               Replace NOSCRIPT elements with their contents
  -o, --output <result.html>          File to write to, use - for STDOUT
  -q, --quiet                         Suppress verbosity
  -t, --timeout <60>                  Adjust network request timeout
  -u, --user-agent <Firefox>          Set custom User-Agent string
  -v, --no-video                      Remove video sources
  -h, --help                          Print help
  -V, --version                       Print version
"""


class Options:
    def __init__(self):
        self.no_audio = False
        self.base_url = None
        self.blacklist = False
        self.no_css = False
        self.cookie_file = None
        self.domains = []
        self.ignore_errors = False
        self.encoding = "utf-8"
        self.no_frames = False
        self.no_fonts = False
        self.no_images = False
        self.isolate = False
        self.no_js = False
        self.insecure = False
        self.mhtml = False
        self.no_metadata = False
        self.unwrap_noscript = False
        self.output = None
        self.quiet = False
        self.timeout = 60
        self.user_agent = "Mozilla/5.0"
        self.no_video = False
        self.target = None
        self.local_file = False


def parse_args(argv):
    opts = Options()
    value_flags = {
        "-b": "base_url",
        "--base-url": "base_url",
        "-C": "cookie_file",
        "--cookie-file": "cookie_file",
        "-d": "domains",
        "--domain": "domains",
        "-E": "encoding",
        "--encoding": "encoding",
        "-o": "output",
        "--output": "output",
        "-t": "timeout",
        "--timeout": "timeout",
        "-u": "user_agent",
        "--user-agent": "user_agent",
    }
    bool_flags = {
        "-a": "no_audio", "--no-audio": "no_audio",
        "-B": "blacklist", "--blacklist-domains": "blacklist",
        "-c": "no_css", "--no-css": "no_css",
        "-e": "ignore_errors", "--ignore-errors": "ignore_errors",
        "-f": "no_frames", "--no-frames": "no_frames",
        "-F": "no_fonts", "--no-fonts": "no_fonts",
        "-i": "no_images", "--no-images": "no_images",
        "-I": "isolate", "--isolate": "isolate",
        "-j": "no_js", "--no-js": "no_js",
        "-k": "insecure", "--insecure": "insecure",
        "-m": "mhtml", "--mhtml": "mhtml",
        "-M": "no_metadata", "--no-metadata": "no_metadata",
        "-n": "unwrap_noscript", "--unwrap-noscript": "unwrap_noscript",
        "-q": "quiet", "--quiet": "quiet",
        "-v": "no_video", "--no-video": "no_video",
    }
    i = 0
    positional = []
    while i < len(argv):
        arg = argv[i]
        if arg in ("-h", "--help"):
            print(HELP, end="")
            raise SystemExit(0)
        if arg in ("-V", "--version"):
            print(VERSION)
            raise SystemExit(0)
        if arg in value_flags:
            i += 1
            if i >= len(argv):
                usage_error(f"a value is required for '{arg}'", "[OPTIONS] <TARGET>")
            name = value_flags[arg]
            if name == "domains":
                opts.domains.append(argv[i])
            elif name == "timeout":
                try:
                    opts.timeout = int(argv[i])
                except ValueError:
                    opts.timeout = 60
            else:
                setattr(opts, name, argv[i])
        elif arg in bool_flags:
            setattr(opts, bool_flags[arg], True)
        elif arg.startswith("-") and arg != "-":
            usage_error(f"unexpected argument '{arg}' found\n\n  tip: to pass '{arg}' as a value, use '-- {arg}'", "[OPTIONS] <TARGET>")
        else:
            positional.append(arg)
        i += 1
    if not positional:
        usage_error("the following required arguments were not provided:\n  <TARGET>", "<TARGET>")
    if len(positional) > 1:
        usage_error(f"unexpected argument '{positional[1]}' found", "[OPTIONS] <TARGET>")
    opts.target = positional[0]
    return opts


def usage_error(message, usage):
    sys.stderr.write(f"error: {message}\n\nUsage: executable {usage}\n\nFor more information, try '--help'.\n")
    raise SystemExit(2)


def is_url(value):
    return urllib.parse.urlparse(value).scheme in ("http", "https", "file", "data")


def file_url(path):
    return Pathish(path).as_uri()


class Pathish:
    def __init__(self, path):
        self.path = os.path.abspath(path)

    def as_uri(self):
        return "file://" + urllib.request.pathname2url(self.path)


def fetch_resource(url, opts, logs):
    if url.startswith("data:"):
        return None, None
    try:
        parsed = urllib.parse.urlparse(url)
        if parsed.scheme == "file":
            path = urllib.request.url2pathname(parsed.path)
            with open(path, "rb") as f:
                data = f.read()
        elif parsed.scheme in ("http", "https"):
            req = urllib.request.Request(url, headers={"User-Agent": opts.user_agent})
            with urllib.request.urlopen(req, timeout=opts.timeout) as resp:
                data = resp.read()
        else:
            with open(url, "rb") as f:
                data = f.read()
        logs.append(url)
        return data, guess_mime(url)
    except Exception:
        logs.append(f"{url} (file not found)" if url.startswith("file:") else f"{url} (failed)")
        return None, None


def guess_mime(url):
    path = urllib.parse.urlparse(url).path
    mime, _ = mimetypes.guess_type(path)
    return mime or "text/plain"


def data_url(data, mime, prefer_base64=True):
    if prefer_base64:
        return f"data:{mime};base64,{base64.b64encode(data).decode('ascii')}"
    safe = "!$&'()*+,;=:@/?"
    return "data:" + mime + "," + urllib.parse.quote_from_bytes(data, safe=safe)


def absolutize(ref, base):
    if not ref or ref.startswith("#") or ref.startswith("data:") or ref.startswith("mailto:") or ref.startswith("javascript:"):
        return ref
    return urllib.parse.urljoin(base, ref)


def encode_css(css_bytes, base_url, opts, logs):
    text = css_bytes.decode(opts.encoding or "utf-8", errors="replace")

    def repl(match):
        raw = match.group(1).strip().strip("'\"")
        if raw.startswith("data:") or raw.startswith("#"):
            return match.group(0)
        url = absolutize(raw, base_url)
        data, mime = fetch_resource(url, opts, logs)
        if data is None:
            return 'url("")'
        return f'url("{data_url(data, mime)}")'

    return re.sub(r"url\(([^)]+)\)", repl, text).encode("utf-8")


def attrs_to_text(attrs):
    if not attrs:
        return ""
    parts = []
    for key, value in attrs:
        if value is None:
            parts.append(key)
        else:
            parts.append(f'{key}="{escape_attr(value)}"')
    return " " + " ".join(parts)


def escape_attr(value):
    return str(value).replace("&", "&amp;").replace('"', "&quot;").replace("<", "&lt;")


def set_attr(attrs, name, value):
    new = []
    done = False
    for key, old in attrs:
        if key.lower() == name:
            if value is not None:
                new.append((key, value))
            done = True
        else:
            new.append((key, old))
    if not done and value is not None:
        new.append((name, value))
    return new


def remove_attr(attrs, name):
    return [(k, v) for k, v in attrs if k.lower() != name]


def get_attr(attrs, name):
    for key, value in attrs:
        if key.lower() == name:
            return value or ""
    return None


class Rewriter(HTMLParser):
    def __init__(self, opts, base_url):
        super().__init__(convert_charrefs=False)
        self.opts = opts
        self.base_url = base_url
        self.out = []
        self.logs = []
        self.in_head = False
        self.seen_head = False
        self.injected_head = False
        self.injected_robots = False
        self.skip_until = None
        self.pending_script = None
        self.in_style = False
        self.style_buf = []
        self.in_noscript = False
        self.noscript_buf = []

    def inject_head_bits(self):
        if self.injected_head:
            return
        self.injected_head = True
        csp = None
        if self.opts.no_css:
            csp = "style-src 'none';"
        elif self.opts.no_js:
            csp = "script-src 'none';"
        elif self.opts.no_frames:
            csp = "frame-src 'none'; child-src 'none';"
        elif self.opts.no_images:
            csp = "img-src data:;"
        elif self.opts.isolate:
            csp = "default-src 'unsafe-eval' 'unsafe-inline' data:;"
        if csp:
            self.out.append(f'<meta http-equiv="Content-Security-Policy" content="{escape_attr(csp)}"></meta>')
        if self.opts.base_url:
            self.out.append(f'<base href="{escape_attr(self.opts.base_url)}"></base>')

    def inject_robots(self):
        if not self.injected_robots:
            self.injected_robots = True
            self.out.append('<meta name="robots" content="none"></meta>')

    def handle_starttag(self, tag, attrs):
        tag = tag.lower()
        if self.in_noscript and self.opts.unwrap_noscript:
            self.noscript_buf.append(self.get_starttag_text() or f"<{tag}{attrs_to_text(attrs)}>")
            return
        if self.pending_script is not None:
            return
        if tag == "html":
            self.out.append(f"<html{attrs_to_text(attrs)}>")
            return
        if tag == "head":
            self.seen_head = True
            self.in_head = True
            self.out.append(f"<head{attrs_to_text(attrs)}>")
            self.inject_head_bits()
            return
        if tag == "body" and not self.seen_head:
            self.out.append("<head>")
            self.inject_head_bits()
            self.inject_robots()
            self.out.append("</head>")
            self.seen_head = True
        if tag == "style":
            self.in_style = True
            self.style_buf = []
            self.out.append(f"<style{attrs_to_text(attrs)}>")
            return
        if tag == "noscript":
            self.in_noscript = True
            self.noscript_buf = []
            if self.opts.unwrap_noscript:
                self.out.append("<!--noscript-->")
            else:
                self.out.append(f"<noscript{attrs_to_text(attrs)}>")
            return
        if tag == "link" and (get_attr(attrs, "href") is not None):
            rel = (get_attr(attrs, "rel") or "").lower()
            href = get_attr(attrs, "href")
            if self.opts.no_css and "stylesheet" in rel:
                attrs = remove_attr(attrs, "href")
            elif "stylesheet" in rel:
                url = absolutize(href, self.base_url)
                data, mime = fetch_resource(url, self.opts, self.logs)
                if data is not None:
                    css = encode_css(data, url, self.opts, self.logs)
                    attrs = set_attr(attrs, "href", data_url(css, "text/css"))
                else:
                    attrs = remove_attr(attrs, "href")
            else:
                attrs = set_attr(attrs, "href", absolutize(href, self.base_url))
            self.out.append(f"<link{attrs_to_text(attrs)}>")
            return
        if tag == "script":
            src = get_attr(attrs, "src")
            if self.opts.no_js:
                self.pending_script = ""
                self.out.append("<script>")
                return
            if src is not None:
                url = absolutize(src, self.base_url)
                data, _ = fetch_resource(url, self.opts, self.logs)
                self.pending_script = data.decode(self.opts.encoding, errors="replace") if data is not None else ""
                self.out.append(f"<script{attrs_to_text(remove_attr(attrs, 'src'))}>")
                return
            self.out.append(f"<script{attrs_to_text(attrs)}>")
            return
        if tag == "img":
            src = get_attr(attrs, "src")
            if src is not None and not self.opts.no_images:
                url = absolutize(src, self.base_url)
                data, mime = fetch_resource(url, self.opts, self.logs)
                attrs = set_attr(attrs, "src", data_url(data, mime) if data is not None else None)
            elif src is not None and self.opts.no_images:
                attrs = remove_attr(attrs, "src")
            self.out.append(f"<img{attrs_to_text(attrs)}>")
            return
        if tag in ("iframe", "frame"):
            src = get_attr(attrs, "src")
            if src is not None and self.opts.no_frames:
                attrs = set_attr(attrs, "src", "")
            elif src is not None:
                url = absolutize(src, self.base_url)
                data, _ = fetch_resource(url, self.opts, self.logs)
                if data is not None:
                    inner = data.decode(self.opts.encoding, errors="replace")
                    if "<html" not in inner.lower():
                        inner = f"<html><head></head><body>{inner}</body></html>"
                    attrs = set_attr(attrs, "src", data_url(inner.encode("utf-8"), "text/html"))
                else:
                    attrs = remove_attr(attrs, "src")
            self.out.append(f"<{tag}{attrs_to_text(attrs)}>")
            return
        if tag in ("audio", "video", "source"):
            src = get_attr(attrs, "src")
            blocked = (tag == "audio" and self.opts.no_audio) or (tag == "video" and self.opts.no_video)
            if src is not None and blocked:
                attrs = remove_attr(attrs, "src")
            elif src is not None:
                url = absolutize(src, self.base_url)
                data, mime = fetch_resource(url, self.opts, self.logs)
                attrs = set_attr(attrs, "src", data_url(data, mime) if data is not None else None)
            self.out.append(f"<{tag}{attrs_to_text(attrs)}>")
            return
        attrs = self.rewrite_generic_attrs(tag, attrs)
        self.out.append(f"<{tag}{attrs_to_text(attrs)}>")

    def rewrite_generic_attrs(self, tag, attrs):
        new = []
        for key, value in attrs:
            if value is not None and key.lower() in ("href", "src", "poster", "action"):
                new.append((key, absolutize(value, self.base_url)))
            else:
                new.append((key, value))
        return new

    def handle_endtag(self, tag):
        tag = tag.lower()
        if self.in_noscript and self.opts.unwrap_noscript:
            if tag == "noscript":
                self.out.append("".join(self.noscript_buf))
                self.out.append("<!--/noscript-->")
                self.in_noscript = False
            else:
                self.noscript_buf.append(f"</{tag}>")
            return
        if tag == "head":
            if not self.injected_head:
                self.inject_head_bits()
            self.inject_robots()
            self.out.append("</head>")
            self.in_head = False
            return
        if tag == "style":
            content = "" if self.opts.no_css else "".join(self.style_buf)
            self.out.append(content)
            self.out.append("</style>")
            self.in_style = False
            return
        if tag == "script" and self.pending_script is not None:
            self.out.append(self.pending_script)
            self.out.append("</script>")
            self.pending_script = None
            return
        if self.pending_script is not None:
            return
        self.out.append(f"</{tag}>")

    def handle_data(self, data):
        if self.in_noscript and self.opts.unwrap_noscript:
            self.noscript_buf.append(data)
        elif self.pending_script is not None:
            if not self.opts.no_js and self.pending_script == "":
                self.pending_script += data
        elif self.in_style:
            self.style_buf.append(data)
        else:
            self.out.append(data)

    def handle_entityref(self, name):
        self.handle_data(f"&{name};")

    def handle_charref(self, name):
        self.handle_data(f"&#{name};")

    def handle_comment(self, data):
        if self.in_noscript and self.opts.unwrap_noscript:
            self.noscript_buf.append(f"<!--{data}-->")
        else:
            self.out.append(f"<!--{data}-->")

    def close_output(self):
        if not self.seen_head:
            self.out.insert(0, "<head>")
            self.inject_head_bits()
            self.inject_robots()
            self.out.insert(1, "</head>")
        return "".join(self.out)


def read_target(opts):
    if opts.target == "-":
        data = sys.stdin.buffer.read()
        base = opts.base_url or ""
        return data, base, None
    if is_url(opts.target):
        logs = []
        data, _ = fetch_resource(opts.target, opts, logs)
        return data or b"", opts.base_url or opts.target, logs
    path = os.path.abspath(opts.target)
    with open(path, "rb") as f:
        data = f.read()
    opts.local_file = True
    return data, opts.base_url or file_url(path), [file_url(path)]


def render_mhtml(html_text, source):
    boundary = "----=_NextPart_000_0000_monolith"
    return (
        f"From: <Saved by Monolith>\n"
        f"Subject: {source or 'Saved page'}\n"
        f"MIME-Version: 1.0\n"
        f"Content-Type: multipart/related; boundary=\"{boundary}\"; type=\"text/html\"\n\n"
        f"--{boundary}\nContent-Type: text/html; charset=\"utf-8\"\nContent-Location: {source or 'index.html'}\n\n"
        f"{html_text}\n--{boundary}--\n"
    )


def main(argv):
    opts = parse_args(argv)
    data, base_url, initial_logs = read_target(opts)
    source = base_url if opts.target != "-" else None
    text = data.decode(opts.encoding or "utf-8", errors="replace")
    if not re.search(r"<\s*(html|head|body)\b", text, flags=re.I):
        text = f"<html><body>{text}</body></html>"
    rewriter = Rewriter(opts, base_url)
    rewriter.feed(text)
    html_text = rewriter.close_output()
    logs = (initial_logs or []) + rewriter.logs

    if not opts.no_metadata:
        stamp = _dt.datetime.utcnow().strftime("%Y-%m-%dT%H:%M:%SZ")
        if opts.local_file or not source:
            comment = f"<!-- Saved from local source at {stamp} using monolith v2.11.0 -->\n"
        else:
            comment = f"<!-- Saved from {source} at {stamp} using monolith v2.11.0 -->\n"
        html_text = comment + html_text
    output_text = render_mhtml(html_text, source) if opts.mhtml else html_text + "\n"

    if not opts.quiet:
        for line in logs:
            sys.stderr.write(line + "\n")
    if opts.output and opts.output != "-":
        out = opts.output
        title = re.search(r"<title>(.*?)</title>", html_text, flags=re.I | re.S)
        if "%title%" in out:
            out = out.replace("%title%", re.sub(r"\s+", " ", title.group(1)).strip() if title else "Untitled")
        if "%timestamp%" in out:
            out = out.replace("%timestamp%", _dt.datetime.utcnow().strftime("%Y%m%d%H%M%S"))
        with open(out, "w", encoding="utf-8") as f:
            f.write(output_text)
    else:
        sys.stdout.write(output_text)
    return 0


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
