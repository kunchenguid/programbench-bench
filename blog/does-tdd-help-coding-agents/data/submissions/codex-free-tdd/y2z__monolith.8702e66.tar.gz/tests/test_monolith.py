import os
import re
import subprocess
import tempfile
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
BIN = ROOT / "executable"


def run_cmd(args, *, cwd=None, stdin=None):
    return subprocess.run(
        [str(BIN), *args],
        cwd=cwd,
        input=stdin,
        text=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
    )


def test_version_prints_monolith_version():
    result = run_cmd(["--version"])
    assert result.returncode == 0
    assert result.stdout == "monolith 2.11.0\n"
    assert result.stderr == ""


def test_missing_target_reports_clap_style_error():
    result = run_cmd([])
    assert result.returncode == 2
    assert "error: the following required arguments were not provided:\n  <TARGET>" in result.stderr
    assert "Usage: executable <TARGET>" in result.stderr
    assert result.stdout == ""


def test_local_html_adds_robots_metadata_and_logs_source():
    with tempfile.TemporaryDirectory() as tmp:
        page = Path(tmp) / "a.html"
        page.write_text("<html><head><title>T</title></head><body><p>Hello</p></body></html>")

        result = run_cmd(["-M", str(page)])

    assert result.returncode == 0
    assert result.stdout == '<html><head><title>T</title><meta name="robots" content="none"></meta></head><body><p>Hello</p></body></html>\n'
    assert re.fullmatch(r"file:///.*/a\.html\n", result.stderr)


def test_stdin_uses_base_url_and_does_not_log_source():
    result = run_cmd(["-M", "-", "-b", "http://example.com/path/"], stdin="<html><body>x</body></html>")
    assert result.returncode == 0
    assert result.stdout == '<html><head><base href="http://example.com/path/"></base><meta name="robots" content="none"></meta></head><body>x</body></html>\n'
    assert result.stderr == ""


def test_embeds_local_css_js_image_and_rewrites_links():
    with tempfile.TemporaryDirectory() as tmp:
        root = Path(tmp)
        (root / "img.png").write_bytes(b"PNGDATA")
        (root / "s.css").write_text("body{color:red;background:url(bg.txt)}")
        (root / "bg.txt").write_text("BG")
        (root / "app.js").write_text("console.log(1)")
        (root / "a.html").write_text(
            "<html><head><title>X</title><link rel=stylesheet href=s.css>"
            "<script src=app.js></script></head><body><img src=img.png>"
            "<a href=other.html>O</a></body></html>"
        )

        result = run_cmd(["-M", str(root / "a.html")])

    assert result.returncode == 0
    assert '<link rel="stylesheet" href="data:text/css;base64,' in result.stdout
    assert "Ym9keXtjb2xvcjpyZWQ7YmFja2dyb3VuZDp1cmwoImRhdGE6dGV4dC9wbGFpbjtiYXNlNjQsUWtjPSIpfQ==" in result.stdout
    assert "<script>console.log(1)</script>" in result.stdout
    assert '<img src="data:image/png;base64,UE5HREFUQQ==">' in result.stdout
    assert re.search(r'<a href="file:///.*/other\.html">O</a>', result.stdout)
    assert "s.css" in result.stderr and "bg.txt" in result.stderr and "app.js" in result.stderr and "img.png" in result.stderr


def test_removal_flags_insert_csp_and_blank_relevant_sources():
    with tempfile.TemporaryDirectory() as tmp:
        root = Path(tmp)
        (root / "s.css").write_text("x")
        (root / "i.png").write_text("x")
        (root / "a.js").write_text("x")
        (root / "f.html").write_text("x")
        (root / "a.html").write_text(
            "<html><head><style>.x{color:red}</style><link rel=stylesheet href=s.css></head>"
            "<body><img src=i.png><script>alert(1)</script><script src=a.js></script>"
            "<iframe src=f.html></iframe><noscript><b>N</b></noscript></body></html>"
        )

        css = run_cmd(["-M", "-c", str(root / "a.html")]).stdout
        js = run_cmd(["-M", "-j", str(root / "a.html")]).stdout
        frames = run_cmd(["-M", "-f", str(root / "a.html")]).stdout
        noscript = run_cmd(["-M", "-n", str(root / "a.html")]).stdout

    assert 'content="style-src \'none\';"' in css
    assert "<style></style>" in css
    assert '<link rel="stylesheet">' in css
    assert 'content="script-src \'none\';"' in js
    assert "<script></script><script></script>" in js
    assert 'content="frame-src \'none\'; child-src \'none\';"' in frames
    assert '<iframe src=""></iframe>' in frames
    assert "<!--noscript--><b>N</b><!--/noscript-->" in noscript


def test_plain_text_input_is_wrapped_as_html_body():
    with tempfile.TemporaryDirectory() as tmp:
        page = Path(tmp) / "a.html"
        page.write_text("hello")

        result = run_cmd(["-M", str(page)])

    assert result.returncode == 0
    assert result.stdout == '<html><head><meta name="robots" content="none"></meta></head><body>hello</body></html>\n'


def test_metadata_for_file_says_local_source():
    with tempfile.TemporaryDirectory() as tmp:
        page = Path(tmp) / "a.html"
        page.write_text("<html><head><title>T</title></head><body>x</body></html>")

        result = run_cmd([str(page)])

    assert result.returncode == 0
    assert result.stdout.startswith("<!-- Saved from local source at ")
    assert " using monolith v2.11.0 -->\n<html>" in result.stdout


def test_output_option_writes_file_and_suppresses_stdout():
    with tempfile.TemporaryDirectory() as tmp:
        root = Path(tmp)
        page = root / "a.html"
        out = root / "saved.html"
        page.write_text("<html><head><title>My Page</title></head><body>x</body></html>")

        result = run_cmd(["-M", "-o", str(out), str(page)])

        assert result.returncode == 0
        assert result.stdout == ""
        assert out.read_text() == '<html><head><title>My Page</title><meta name="robots" content="none"></meta></head><body>x</body></html>\n'
        assert re.fullmatch(r"file:///.*/a\.html\n", result.stderr)
