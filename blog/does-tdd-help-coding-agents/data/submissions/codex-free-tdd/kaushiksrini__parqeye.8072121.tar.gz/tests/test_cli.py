import os
import pty
import select
import subprocess
import sys
import time
import unittest


ROOT = os.path.dirname(os.path.dirname(__file__))
CLI = os.path.join(ROOT, "parqeye.py")


def run_cli(*args):
    return subprocess.run(
        [sys.executable, CLI, *args],
        text=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
    )


def run_cli_in_pty(*args, input_bytes=b"", timeout=2):
    master, slave = pty.openpty()
    try:
        proc = subprocess.Popen(
            [sys.executable, CLI, *args],
            stdin=slave,
            stdout=slave,
            stderr=slave,
            text=False,
            close_fds=True,
        )
        os.close(slave)
        chunks = []
        sent_input = False
        deadline = time.monotonic() + timeout
        try:
            while True:
                if time.monotonic() > deadline:
                    proc.kill()
                    break
                ready, _, _ = select.select([master], [], [], 0.05)
                if not ready:
                    if proc.poll() is not None:
                        break
                    continue
                try:
                    chunk = os.read(master, 4096)
                except OSError:
                    break
                if not chunk:
                    break
                chunks.append(chunk)
                if input_bytes and not sent_input:
                    os.write(master, input_bytes)
                    sent_input = True
                if proc.poll() is not None:
                    break
        finally:
            try:
                proc.wait(timeout=timeout)
            except subprocess.TimeoutExpired:
                proc.kill()
                proc.wait()
        return proc.returncode, b"".join(chunks).decode("utf-8", "replace")
    finally:
        try:
            os.close(master)
        except OSError:
            pass


class CliContractTests(unittest.TestCase):
    def test_help_matches_observed_clap_output(self):
        result = run_cli("--help")

        self.assertEqual(result.returncode, 0)
        self.assertEqual(result.stderr, "")
        self.assertEqual(
            result.stdout,
            "Command line tool to visualize parquet files\n"
            "\n"
            "Usage: executable <PATH>\n"
            "\n"
            "Arguments:\n"
            "  <PATH>  Path to the parquet file\n"
            "\n"
            "Options:\n"
            "  -h, --help     Print help\n"
            "  -V, --version  Print version\n",
        )

    def test_version_matches_observed_output(self):
        result = run_cli("--version")

        self.assertEqual(result.returncode, 0)
        self.assertEqual(result.stderr, "")
        self.assertEqual(result.stdout, "parqeye 0.0.2\n")

    def test_missing_path_reports_required_argument(self):
        result = run_cli()

        self.assertEqual(result.returncode, 2)
        self.assertEqual(result.stdout, "")
        self.assertEqual(
            result.stderr,
            "error: the following required arguments were not provided:\n"
            "  <PATH>\n"
            "\n"
            "Usage: executable <PATH>\n"
            "\n"
            "For more information, try '--help'.\n",
        )

    def test_unexpected_option_reports_tip(self):
        result = run_cli("--bad")

        self.assertEqual(result.returncode, 2)
        self.assertEqual(result.stdout, "")
        self.assertEqual(
            result.stderr,
            "error: unexpected argument '--bad' found\n"
            "\n"
            "  tip: to pass '--bad' as a value, use '-- --bad'\n"
            "\n"
            "Usage: executable <PATH>\n"
            "\n"
            "For more information, try '--help'.\n",
        )

    def test_path_without_tty_matches_terminal_initialization_panic_shape(self):
        result = run_cli("assets/alltypes_plain.parquet")

        self.assertEqual(result.returncode, 101)
        self.assertEqual(result.stdout, "\x1b[?1049l")
        self.assertIn("thread 'main' (", result.stderr)
        self.assertIn("panicked at ", result.stderr)
        self.assertIn("ratatui-0.29.0/src/terminal/init.rs:52:16", result.stderr)
        self.assertIn(
            'failed to initialize terminal: Os { code: 6, kind: Uncategorized, message: "No such device or address" }',
            result.stderr,
        )
        self.assertTrue(
            result.stderr.endswith(
                "note: run with `RUST_BACKTRACE=1` environment variable to display a backtrace\n"
            )
        )

    def test_missing_file_inside_tty_reports_custom_error(self):
        code, output = run_cli_in_pty("/no/such/file")

        self.assertEqual(code, 1)
        self.assertEqual(
            output,
            '\x1b[?1049hError: Custom { kind: Other, error: "No such file or directory (os error 2)" }\r\n',
        )

    def test_existing_file_inside_tty_draws_tabs_and_quits_on_q(self):
        fixture = os.path.relpath(__file__, ROOT)
        code, output = run_cli_in_pty(fixture, input_bytes=b"q\n")

        self.assertEqual(code, 0)
        self.assertIn("\x1b[?1049h", output)
        self.assertIn("Visualize", output)
        self.assertIn("Schema", output)
        self.assertIn("Metadata", output)
        self.assertIn("Row Groups", output)
        self.assertIn(fixture, output)
        self.assertIn("\x1b[?1049l", output)

    def test_compile_script_creates_executable(self):
        built = os.path.join(ROOT, "executable")
        if os.path.exists(built):
            os.unlink(built)

        result = subprocess.run(
            ["bash", "compile.sh"],
            cwd=ROOT,
            text=True,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
        )

        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertTrue(os.path.exists(built))
        self.assertTrue(os.access(built, os.X_OK))
        help_result = subprocess.run(
            [built, "--version"],
            text=True,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
        )
        self.assertEqual(help_result.stdout, "parqeye 0.0.2\n")


if __name__ == "__main__":
    unittest.main()
