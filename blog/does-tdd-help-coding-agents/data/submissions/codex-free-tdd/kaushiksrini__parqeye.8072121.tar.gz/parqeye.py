#!/usr/bin/env python3
import sys
import os
import select
import termios
import tty


HELP = """Command line tool to visualize parquet files

Usage: executable <PATH>

Arguments:
  <PATH>  Path to the parquet file

Options:
  -h, --help     Print help
  -V, --version  Print version
"""


def parquet_summary(path):
    try:
        with open(path, "rb") as fh:
            data = fh.read()
    except OSError:
        return "Unable to read file"
    if len(data) >= 8 and data[:4] == b"PAR1" and data[-4:] == b"PAR1":
        footer_len = int.from_bytes(data[-8:-4], "little", signed=False)
        return f"Parquet file detected | footer {footer_len} bytes | size {len(data)} bytes"
    return f"File size {len(data)} bytes"


def run_tui(path):
    fd = sys.stdin.fileno()
    old = termios.tcgetattr(fd)
    try:
        tty.setcbreak(fd)
        sys.stdout.write("\x1b[2J\x1b[H")
        sys.stdout.write("parqeye\n")
        sys.stdout.write("[ Visualize ]  Schema  Metadata  Row Groups\n")
        sys.stdout.write(f"Path: {path}\n")
        sys.stdout.write(f"{parquet_summary(path)}\n")
        sys.stdout.write("Press q to quit\n")
        sys.stdout.flush()
        while True:
            ready, _, _ = select.select([fd], [], [], 0.25)
            if not ready:
                continue
            ch = os.read(fd, 1)
            if ch in (b"q", b"Q", b"\x03", b"\x1b"):
                break
    finally:
        termios.tcsetattr(fd, termios.TCSADRAIN, old)


def main(argv):
    if argv in (["--help"], ["-h"]):
        sys.stdout.write(HELP)
        return 0
    if argv in (["--version"], ["-V"]):
        sys.stdout.write("parqeye 0.0.2\n")
        return 0
    if not argv:
        sys.stderr.write(
            "error: the following required arguments were not provided:\n"
            "  <PATH>\n"
            "\n"
            "Usage: executable <PATH>\n"
            "\n"
            "For more information, try '--help'.\n"
        )
        return 2
    if len(argv) > 1 or argv[0].startswith("-"):
        bad = argv[0] if argv[0].startswith("-") else argv[1]
        sys.stderr.write(f"error: unexpected argument '{bad}' found\n\n")
        if bad.startswith("-"):
            sys.stderr.write(f"  tip: to pass '{bad}' as a value, use '-- {bad}'\n\n")
        sys.stderr.write("Usage: executable <PATH>\n\nFor more information, try '--help'.\n")
        return 2
    path = argv[0]
    if not sys.stdin.isatty() or not sys.stdout.isatty():
        sys.stdout.write("\x1b[?1049l")
        sys.stderr.write(
            f"\nthread 'main' ({os.getpid()}) panicked at "
            "/usr/local/cargo/registry/src/index.crates.io-1949cf8c6b5b557f/"
            "ratatui-0.29.0/src/terminal/init.rs:52:16:\n"
            'failed to initialize terminal: Os { code: 6, kind: Uncategorized, message: "No such device or address" }\n'
            "note: run with `RUST_BACKTRACE=1` environment variable to display a backtrace\n"
        )
        return 101
    sys.stdout.write("\x1b[?1049h")
    try:
        with open(path, "rb"):
            pass
    except OSError as exc:
        if exc.errno == 2:
            msg = "No such file or directory (os error 2)"
        else:
            msg = str(exc)
        sys.stdout.write(f'Error: Custom {{ kind: Other, error: "{msg}" }}\n')
        return 1
    run_tui(path)
    sys.stdout.write("\x1b[?1049l\x1b[?25h")
    sys.stdout.flush()
    return 0


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
