import os
import stat
import subprocess
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
PROG = ROOT / "fselect.py"


def run_query(cwd, query):
    return subprocess.run(["python3", str(PROG), "--nocolor", query], cwd=cwd, text=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)


class FselectBehaviorTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.root = Path(self.tmp.name) / "probe"
        (self.root / "sub").mkdir(parents=True)
        (self.root / ".hidden_dir").mkdir()
        (self.root / "a.txt").write_text("abc")
        (self.root / "sub" / "b.rs").write_text("hello\nworld\n")
        (self.root / "empty.bin").write_bytes(b"")
        (self.root / ".hidden").write_text("hidden")
        os.symlink("a.txt", self.root / "link.txt")
        os.chmod(self.root / "sub" / "b.rs", 0o755)

    def tearDown(self):
        self.tmp.cleanup()

    def assert_ok(self, query, out):
        res = run_query(Path(self.tmp.name), query)
        self.assertEqual(res.returncode, 0, res.stderr)
        self.assertEqual(res.stdout, out)

    def test_default_breadth_first_paths_include_dirs_and_symlinks(self):
        self.assert_ok("path from probe", ".hidden\na.txt\nsub\n.hidden_dir\nlink.txt\nempty.bin\nsub/b.rs\n")

    def test_file_name_columns_and_tabs(self):
        self.assert_ok(
            "name,filename,ext,path,dir from probe",
            ".hidden\t.hidden\t\t.hidden\t\n"
            "a.txt\ta\ttxt\ta.txt\t\n"
            "sub\tsub\t\tsub\t\n"
            ".hidden_dir\t.hidden_dir\t\t.hidden_dir\t\n"
            "link.txt\tlink\ttxt\tlink.txt\t\n"
            "empty.bin\tempty\tbin\tempty.bin\t\n"
            "b.rs\tb\trs\tsub/b.rs\tsub\n",
        )

    def test_where_sort_limit_offset_and_size_units(self):
        self.assert_ok("path from probe mindepth 2 order by path", "sub/b.rs\n")
        self.assert_ok("path from probe depth 1 order by path", ".hidden\n.hidden_dir\na.txt\nempty.bin\nlink.txt\nsub\n")
        self.assert_ok("path from probe where size between 1 and 5 order by path", "a.txt\nlink.txt\n")
        self.assert_ok("path from probe order by path desc limit 2", "sub/b.rs\nsub\n")
        self.assert_ok("path from probe where ext != txt order by path limit 5 offset 1", ".hidden_dir\nempty.bin\nsub\nsub/b.rs\n")
        self.assert_ok("fsize,hsize,path from probe where path = sub order by path", "4KiB\t4KiB\tsub\n")

    def test_booleans_permissions_and_text_columns(self):
        self.assert_ok("path from probe where is_file order by path", ".hidden\na.txt\nempty.bin\nsub/b.rs\n")
        self.assert_ok("path from probe where not is_dir order by path", ".hidden\na.txt\nempty.bin\nlink.txt\nsub/b.rs\n")
        self.assert_ok("mode,user_read,user_write,user_exec,other_exec,path from probe where path = sub/b.rs", "-rwxr-xr-x\ttrue\ttrue\ttrue\ttrue\tsub/b.rs\n")
        self.assert_ok("is_source,is_text,line_count,path from probe where path = sub/b.rs", "true\ttrue\t2\tsub/b.rs\n")

    def test_glob_like_regex_in_and_string_functions(self):
        self.assert_ok("path from probe where name = *.txt order by path", "a.txt\nlink.txt\n")
        self.assert_ok("path from probe where path like %.rs", "sub/b.rs\n")
        self.assert_ok("path from probe where name regexp .*\\.txt order by path", "a.txt\nlink.txt\n")
        self.assert_ok("path from probe where ext in (txt,rs) order by path", "a.txt\nlink.txt\nsub/b.rs\n")
        self.assert_ok("lower(name),upper(ext),length(name) from probe where path = a.txt", "a.txt\tTXT\t5\n")

    def test_aggregates_arithmetic_and_formats(self):
        self.assert_ok("count(*) from probe", "7\n")
        self.assert_ok("min(size),max(size),sum(size),avg(size) from probe where is_file", "0\t12\t21\t5.25\n")
        self.assert_ok("size+1,path from probe where path = a.txt", "4\ta.txt\n")
        self.assert_ok("path,size from probe order by path into csv", ".hidden,6\n.hidden_dir,4096\na.txt,3\nempty.bin,0\nlink.txt,5\nsub,4096\nsub/b.rs,12\n")
        self.assert_ok("path,size from probe order by path into json", '[{"Path":".hidden","Size":"6"},{"Path":".hidden_dir","Size":"4096"},{"Path":"a.txt","Size":"3"},{"Path":"empty.bin","Size":"0"},{"Path":"link.txt","Size":"5"},{"Path":"sub","Size":"4096"},{"Path":"sub/b.rs","Size":"12"}]\n')

    def test_parse_and_io_errors(self):
        res = run_query(Path(self.tmp.name), "path from /no/such/place")
        self.assertEqual(res.returncode, 1)
        self.assertIn("could not canonicalize path", res.stderr)
        res = run_query(Path(self.tmp.name), "path from probe where")
        self.assertEqual(res.returncode, 2)
        self.assertEqual(res.stderr, "query: Error parsing expression, expecting string\n")


if __name__ == "__main__":
    unittest.main()
