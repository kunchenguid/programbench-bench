#!/usr/bin/env python3
import base64, csv, fnmatch, hashlib, html, json, math, os, pwd, grp, re, stat, sys
from collections import deque
from datetime import datetime

ARCHIVE={"7z","bz2","bzip2","gz","gzip","lz","rar","tar","xz","zip"}
AUDIO={"aac","aiff","amr","flac","gsm","m4a","m4b","m4p","mp3","ogg","wav","wma"}
BOOK={"azw3","chm","djv","djvu","epub","fb2","mobi","pdf"}
DOC={"accdb","doc","docm","docx","dot","dotm","dotx","mdb","odp","ods","odt","pdf","potm","potx","ppt","pptm","pptx","rtf","xlm","xls","xlsm","xlsx","xlt","xltm","xltx","xps"}
FONT={"eot","fon","otc","otf","ttc","ttf","woff","woff2"}
IMAGE={"bmp","exr","gif","heic","jpeg","jpg","jxl","png","psb","psd","svg","tga","tiff","webp"}
SOURCE={"asm","awk","bas","c","cc","ceylon","clj","coffee","cpp","cs","d","dart","elm","erl","go","gradle","groovy","h","hh","hpp","java","jl","js","jsp","jsx","kt","kts","lua","nim","pas","php","pl","pm","py","rb","rs","scala","sol","swift","tcl","ts","tsx","vala","vb","zig"}
VIDEO={"3gp","avi","flv","m4p","m4v","mkv","mov","mp4","mpeg","mpg","webm","wmv"}
HELP = """fselect \x1b[33m0.10.0\x1b[0m
Find files with SQL-like queries.
\x1b[4;36mhttps://github.com/jhspetersson/fselect\x1b[0m

Usage: fselect [ARGS] COLUMN[, COLUMN...] [from PATH[, PATH...]] [where EXPR] [group by COLUMN, ...] [order by COLUMN (asc|desc), ...] [limit N] [offset N] [into FORMAT]
"""
class QueryError(Exception): pass
class IOErrorExit(Exception): pass

def stripq(s):
    s=s.strip()
    if len(s)>=2 and s[0]==s[-1] and s[0] in "'\"`": return s[1:-1]
    return s

def split_top(s, sep=','):
    out=[]; cur=[]; depth=0; quote=None
    for c in s:
        if quote:
            cur.append(c)
            if c==quote: quote=None
        else:
            if c in "'\"`": quote=c; cur.append(c)
            elif c in '({': depth+=1; cur.append(c)
            elif c in ')}': depth=max(0,depth-1); cur.append(c)
            elif c==sep and depth==0:
                part=''.join(cur).strip()
                if part: out.append(part)
                cur=[]
            else: cur.append(c)
    part=''.join(cur).strip()
    if part: out.append(part)
    return out

def words_top(s):
    out=[]; cur=[]; depth=0; quote=None
    for c in s:
        if quote:
            cur.append(c)
            if c==quote: quote=None
        else:
            if c in "'\"`": quote=c; cur.append(c)
            elif c in '({': depth+=1; cur.append(c)
            elif c in ')}': depth=max(0,depth-1); cur.append(c)
            elif c.isspace() and depth==0:
                if cur: out.append(''.join(cur)); cur=[]
            else: cur.append(c)
    if cur: out.append(''.join(cur))
    return out

def find_kw(s, kws):
    low=s.lower(); depth=0; quote=None
    for i,c in enumerate(s):
        if quote:
            if c==quote: quote=None
        else:
            if c in "'\"`": quote=c
            elif c in '({': depth+=1
            elif c in ')}': depth=max(0,depth-1)
            elif depth==0:
                for kw in kws:
                    if low.startswith(kw.strip(), i):
                        before=i==0 or not (low[i-1].isalnum() or low[i-1]=='_')
                        j=i+len(kw.strip())
                        after=j>=len(s) or not (low[j].isalnum() or low[j]=='_')
                        if before and after: return i, kw.strip()
    return -1,None

def parse_query(q):
    q=q.strip()
    if q.lower().startswith('select '): q=q[7:].strip()
    order=['where','group by','order by','limit','offset','into']
    pos,kw=find_kw(q,['from'])
    if pos>=0: cols=q[:pos].strip(); rest=q[pos+4:].strip()
    else: cols=q.strip(); rest=''
    if not cols: raise QueryError('Error parsing expression, expecting string')
    root='.'; clauses={}
    if rest:
        npos,nkw=find_kw(rest,order)
        if npos>=0: root=rest[:npos].strip(); tail=rest[npos:].strip()
        else: root=rest.strip(); tail=''
    else: tail=''
    while tail:
        low=tail.lower(); matched=None
        for kw2,name in [('group by','group'),('order by','order'),('where','where'),('limit','limit'),('offset','offset'),('into','into')]:
            if low.startswith(kw2): matched=(kw2,name); break
        if not matched: break
        kw2,name=matched; body=tail[len(kw2):].strip()
        npos,nkw=find_kw(body,order)
        if npos>=0: clauses[name]=body[:npos].strip(); tail=body[npos:].strip()
        else: clauses[name]=body.strip(); tail=''
    columns=split_top(cols)
    if len(columns)==1 and ',' not in cols:
        parts=words_top(cols)
        if len(parts)>1: columns=parts
    return columns, root or '.', clauses

class Entry:
    def __init__(self,root,rel): self.root=os.path.abspath(root); self.rel=rel; self.full=os.path.join(self.root,rel); self.st=os.lstat(self.full)
    def name(self): return os.path.basename(self.rel)
    def ext(self):
        n=self.name()
        if n.startswith('.') and n.count('.')==1: return ''
        return n.rsplit('.',1)[1] if '.' in n else ''
    def filename(self):
        n=self.name()
        if n.startswith('.') and n.count('.')==1: return n
        return n.rsplit('.',1)[0] if '.' in n else n
    def isdir(self): return stat.S_ISDIR(self.st.st_mode)
    def isfile(self): return stat.S_ISREG(self.st.st_mode)
    def issym(self): return stat.S_ISLNK(self.st.st_mode)

def parse_roots(s):
    roots=[]
    for spec in split_top(s):
        parts=words_top(spec)
        if not parts: continue
        opts={'mindepth':0,'maxdepth':None,'symlinks':False}
        i=1
        while i<len(parts):
            p=parts[i].lower()
            if p in ('mindepth','maxdepth','depth') and i+1<len(parts): opts['mindepth' if p=='mindepth' else 'maxdepth']=int(stripq(parts[i+1])); i+=2
            elif p in ('symlinks','sym'): opts['symlinks']=True; i+=1
            else: i+=1
        roots.append((stripq(parts[0]),opts))
    return roots or [('.',{'mindepth':0,'maxdepth':None,'symlinks':False})]

def walk_root(path,opts):
    if not os.path.exists(path): raise IOErrorExit(f"{path}: could not canonicalize path: No such file or directory (os error 2)")
    root=os.path.abspath(path); q=deque([(root,0)])
    while q:
        d,depth=q.popleft()
        try: items=list(os.scandir(d))
        except OSError as e: raise IOErrorExit(f"{d}: {e}")
        dirs=[]
        for it in items:
            rel=os.path.relpath(it.path,root); ent=Entry(root,rel); edepth=depth+1
            if edepth>=opts.get('mindepth',0): yield ent
            if it.is_dir(follow_symlinks=opts.get('symlinks',False)) and (opts.get('maxdepth') is None or edepth<opts.get('maxdepth')): dirs.append((it.path,edepth))
        q.extend(dirs)

def mode_str(m):
    t='d' if stat.S_ISDIR(m) else 'l' if stat.S_ISLNK(m) else 'p' if stat.S_ISFIFO(m) else 's' if stat.S_ISSOCK(m) else 'c' if stat.S_ISCHR(m) else 'b' if stat.S_ISBLK(m) else '-'
    bits=''
    for r,w,x in [(stat.S_IRUSR,stat.S_IWUSR,stat.S_IXUSR),(stat.S_IRGRP,stat.S_IWGRP,stat.S_IXGRP),(stat.S_IROTH,stat.S_IWOTH,stat.S_IXOTH)]: bits+=('r' if m&r else '-')+('w' if m&w else '-')+('x' if m&x else '-')
    return t+bits

def hsize(n):
    x=float(n)
    for u in ['B','KiB','MiB','GiB','TiB']:
        if abs(x)<1024 or u=='TiB': return (str(int(x)) if x.is_integer() else f"{x:.1f}".rstrip('0').rstrip('.'))+u
        x/=1024

def text_info(ent):
    if ent.isdir(): return False,''
    try: data=open(ent.full,'rb').read()
    except Exception: return False,0
    if b'\0' in data: return False,0
    try: data.decode('utf-8')
    except UnicodeDecodeError: return False,0
    return True,data.count(b'\n')

def col_value(ent,c):
    c=c.lower(); m=ent.st.st_mode; ext=ent.ext().lower()
    if c=='name': return ent.name()
    if c in ('filename','fname'): return ent.filename()
    if c in ('ext','extension'): return ent.ext()
    if c=='path': return ent.rel
    if c=='abspath': return ent.full
    if c in ('dir','directory','dirname'): return os.path.dirname(ent.rel) if os.path.dirname(ent.rel)!='.' else ''
    if c=='absdir': return os.path.dirname(ent.full)
    if c=='size': return ent.st.st_size
    if c in ('fsize','hsize'): return hsize(ent.st.st_size)
    if c=='uid': return ent.st.st_uid
    if c=='gid': return ent.st.st_gid
    if c=='user':
        try: return pwd.getpwuid(ent.st.st_uid).pw_name
        except KeyError: return str(ent.st.st_uid)
    if c=='group':
        try: return grp.getgrgid(ent.st.st_gid).gr_name
        except KeyError: return str(ent.st.st_gid)
    if c in ('modified','accessed','created'):
        ts={'modified':ent.st.st_mtime,'accessed':ent.st.st_atime,'created':getattr(ent.st,'st_birthtime',ent.st.st_ctime)}[c]
        return datetime.fromtimestamp(ts).strftime('%Y-%m-%d %H:%M:%S')
    if c=='mtime': return int(ent.st.st_mtime)
    if c=='atime': return int(ent.st.st_atime)
    if c=='ctime': return int(ent.st.st_ctime)
    if c=='mode': return mode_str(m)
    if c=='is_dir': return ent.isdir()
    if c=='is_file': return ent.isfile()
    if c=='is_symlink': return ent.issym()
    if c in ('is_pipe','is_fifo'): return stat.S_ISFIFO(m)
    if c in ('is_char','is_character'): return stat.S_ISCHR(m)
    if c=='is_block': return stat.S_ISBLK(m)
    if c=='is_socket': return stat.S_ISSOCK(m)
    if c=='is_hidden': return ent.name().startswith('.')
    if c=='is_empty':
        if ent.isdir():
            try: return len(os.listdir(ent.full))==0
            except Exception: return False
        return ent.st.st_size==0
    if c=='is_shebang':
        try: return open(ent.full,'rb').read(2)==b'#!'
        except Exception: return False
    perms={'user_read':stat.S_IRUSR,'user_write':stat.S_IWUSR,'user_exec':stat.S_IXUSR,'group_read':stat.S_IRGRP,'group_write':stat.S_IWGRP,'group_exec':stat.S_IXGRP,'other_read':stat.S_IROTH,'other_write':stat.S_IWOTH,'other_exec':stat.S_IXOTH}
    if c in perms: return bool(m&perms[c])
    if c in ('user_all','user_rwx'): return bool(m&stat.S_IRUSR and m&stat.S_IWUSR and m&stat.S_IXUSR)
    if c in ('group_all','group_rwx'): return bool(m&stat.S_IRGRP and m&stat.S_IWGRP and m&stat.S_IXGRP)
    if c in ('other_all','other_rwx'): return bool(m&stat.S_IROTH and m&stat.S_IWOTH and m&stat.S_IXOTH)
    if c in ('suid','is_suid'): return bool(m&stat.S_ISUID)
    if c in ('sgid','is_sgid'): return bool(m&stat.S_ISGID)
    if c in ('sticky','is_sticky'): return bool(m&stat.S_ISVTX)
    if c=='device': return ent.st.st_dev
    if c=='rdev': return ent.st.st_rdev
    if c=='inode': return ent.st.st_ino
    if c=='blocks': return getattr(ent.st,'st_blocks',0)*2
    if c=='hardlinks': return ent.st.st_nlink
    if c=='is_archive': return ext in ARCHIVE
    if c=='is_audio': return ext in AUDIO
    if c=='is_book': return ext in BOOK
    if c=='is_doc': return ext in DOC
    if c=='is_font': return ext in FONT
    if c=='is_image': return ext in IMAGE
    if c=='is_source': return ext in SOURCE
    if c=='is_video': return ext in VIDEO
    if c in ('is_text','line_count','is_binary'):
        t,lc=text_info(ent)
        return t if c=='is_text' else (not t if c=='is_binary' and not ent.isdir() else False if c=='is_binary' else lc)
    if c=='mime': return 'text/plain' if text_info(ent)[0] else 'inode/directory' if ent.isdir() else 'application/octet-stream'
    if c in ('sha1','sha2_256','sha256','sha2_512','sha512'):
        if ent.isdir(): return ''
        h={'sha1':hashlib.sha1,'sha2_256':hashlib.sha256,'sha256':hashlib.sha256,'sha2_512':hashlib.sha512,'sha512':hashlib.sha512}[c]()
        try:
            with open(ent.full,'rb') as f:
                for b in iter(lambda:f.read(65536),b''): h.update(b)
            return h.hexdigest()
        except Exception: return ''
    return c

def literal(s):
    s=stripq(str(s).strip()); low=s.lower()
    if low=='true': return True
    if low=='false': return False
    m=re.fullmatch(r'(-?\d+(?:\.\d+)?)([a-zA-Z]+)?',s)
    if m:
        n=float(m.group(1)) if '.' in m.group(1) else int(m.group(1)); mult={'k':1024,'kib':1024,'kb':1000,'m':1024**2,'mib':1024**2,'mb':1000**2,'g':1024**3,'gib':1024**3,'gb':1000**3,'t':1024**4,'tib':1024**4,'tb':1000**4}.get((m.group(2) or '').lower(),1)
        return n*mult
    return s

def eval_expr(expr,ent):
    expr=expr.strip()
    for op in [' plus ',' minus ',' mul ',' div ',' mod ','+','-','*','/','%']:
        if op in expr and not expr.startswith(('-', '+')):
            a,b=expr.split(op,1); x=eval_expr(a,ent); y=eval_expr(b,ent)
            try:
                k=op.strip(); return {'plus':x+y,'+':x+y,'minus':x-y,'-':x-y,'mul':x*y,'*':x*y,'div':x/y,'/':x/y,'mod':x%y,'%':x%y}[k]
            except Exception: return ''
    m=re.match(r'([A-Za-z_][\w]*)\s*[({](.*)[)}]$',expr)
    if m:
        fn=m.group(1).lower(); vals=[eval_expr(a,ent) for a in split_top(m.group(2))]
        try:
            if fn in ('lower','lowercase','lcase'): return str(vals[0]).lower()
            if fn in ('upper','uppercase','ucase'): return str(vals[0]).upper()
            if fn in ('length','len'): return len(str(vals[0]))
            if fn=='initcap': return str(vals[0]).title()
            if fn in ('to_base64','base64'): return base64.b64encode(str(vals[0]).encode()).decode()
            if fn=='from_base64': return base64.b64decode(str(vals[0])).decode()
            if fn=='concat': return ''.join(str(v) for v in vals)
            if fn=='concat_ws': return str(vals[0]).join(str(v) for v in vals[1:])
            if fn in ('substr','substring'):
                s=str(vals[0]); start=int(vals[1])-1; return s[start:] if len(vals)<3 else s[start:start+int(vals[2])]
            if fn=='replace': return str(vals[0]).replace(str(vals[1]),str(vals[2]))
            if fn=='trim': return str(vals[0]).strip()
            if fn=='ltrim': return str(vals[0]).lstrip()
            if fn=='rtrim': return str(vals[0]).rstrip()
            if fn=='abs': return abs(vals[0])
            if fn in ('pow','power'): return vals[0]**vals[1]
            if fn=='sqrt': return math.sqrt(vals[0])
            if fn=='floor': return math.floor(vals[0])
            if fn in ('ceil','ceiling'): return math.ceil(vals[0])
            if fn=='round': return round(vals[0],int(vals[1]) if len(vals)>1 else 0)
            if fn=='hex': return format(int(vals[0]),'x')
            if fn=='bin': return format(int(vals[0]),'b')
            if fn=='oct': return format(int(vals[0]),'o')
            if fn=='year': return int(str(vals[0])[:4])
            if fn=='month': return int(str(vals[0])[5:7])
            if fn=='day': return int(str(vals[0])[8:10])
        except Exception: return ''
    return col_value(ent,expr) if re.fullmatch(r'[A-Za-z_][\w]*',expr) else literal(expr)

def split_bool(expr,sep):
    low=expr.lower(); depth=0; quote=None; needle=' '+sep+' '
    for i,c in enumerate(expr):
        if quote:
            if c==quote: quote=None
        else:
            if c in "'\"`": quote=c
            elif c in '({': depth+=1
            elif c in ')}': depth=max(0,depth-1)
            elif depth==0 and low.startswith(needle,i): return expr[:i],expr[i+len(needle):]
    return None

def compare(a,op,b):
    if isinstance(a,bool): b=b if isinstance(b,bool) else str(b).lower() in ('1','true','yes')
    if op in ('=','==','eq'):
        if isinstance(a,str) and isinstance(b,str) and any(ch in b for ch in '*?['): return fnmatch.fnmatchcase(a,b)
        return str(a)==str(b) if isinstance(a,str) or isinstance(b,str) else a==b
    if op in ('===','eeq'): return str(a)==str(b)
    if op in ('!=','<>','ne'): return not compare(a,'=',b)
    if op in ('!==','ene'): return str(a)!=str(b)
    if op in ('=~','~=','regexp','rx'): return re.search(str(b),str(a)) is not None
    if op in ('!=~','!~=','notrx'): return re.search(str(b),str(a)) is None
    if op=='like': return fnmatch.fnmatchcase(str(a),str(b).replace('%','*').replace('_','?'))
    if op=='notlike': return not compare(a,'like',b)
    try: aa=float(a); bb=float(b)
    except Exception: aa=str(a); bb=str(b)
    return {'>':aa>bb,'gt':aa>bb,'>=':aa>=bb,'gte':aa>=bb,'ge':aa>=bb,'<':aa<bb,'lt':aa<bb,'<=':aa<=bb,'lte':aa<=bb,'le':aa<=bb}.get(op,False)

def eval_where(expr,ent):
    expr=expr.strip()
    if not expr: raise QueryError('Error parsing expression, expecting string')
    if expr.startswith('(') and expr.endswith(')'): return eval_where(expr[1:-1],ent)
    m=re.match(r'(.+?)\s+between\s+(.+?)\s+and\s+(.+)$',expr,re.I)
    if m: return float(literal(m.group(2))) <= float(eval_expr(m.group(1),ent)) <= float(literal(m.group(3)))
    sp=split_bool(expr,'or')
    if sp: return eval_where(sp[0],ent) or eval_where(sp[1],ent)
    sp=split_bool(expr,'and')
    if sp: return eval_where(sp[0],ent) and eval_where(sp[1],ent)
    if expr.lower().startswith('not '): return not eval_where(expr[4:],ent)
    m=re.match(r'(.+?)\s+in\s*[({](.*)[)}]$',expr,re.I)
    if m:
        v=eval_expr(m.group(1),ent); return any(str(v)==str(literal(x)) for x in split_top(m.group(2)))
    wordops=['regexp','notrx','notlike','like','gte','ge','lte','le','gt','lt','eq','ne','eeq','ene','rx']
    for op in ['!=~','!~=','===','!==','>=','<=','<>','=~','~=','==','!=','>','<','=']:
        if op in expr:
            a,b=expr.split(op,1); return compare(eval_expr(a,ent),op,literal(b))
    for op in wordops:
        pat=' '+op+' '; idx=expr.lower().find(pat)
        if idx>=0: return compare(eval_expr(expr[:idx],ent),op,literal(expr[idx+len(pat):]))
    return bool(eval_expr(expr,ent))

def aggregate(cols,rows):
    out=[]
    for c in cols:
        m=re.match(r'(count|min|max|sum|avg|stddev_pop|stddev|std|var_pop|variance)\s*[({](.*)[)}]$',c,re.I)
        if not m: return None
        fn=m.group(1).lower(); arg=m.group(2).strip(); vals=[]
        for e in rows: vals.append(1 if arg=='*' else eval_expr(arg,e))
        if fn=='count': out.append(len(vals)); continue
        nums=[float(v) for v in vals if v!='']
        if not nums: out.append('')
        elif fn=='min': out.append(min(nums))
        elif fn=='max': out.append(max(nums))
        elif fn=='sum': out.append(sum(nums))
        elif fn=='avg': out.append(sum(nums)/len(nums))
        elif fn in ('stddev_pop','stddev','std'):
            mu=sum(nums)/len(nums); out.append(math.sqrt(sum((x-mu)**2 for x in nums)/len(nums)))
        elif fn in ('var_pop','variance'):
            mu=sum(nums)/len(nums); out.append(sum((x-mu)**2 for x in nums)/len(nums))
    return [out]

def fmt(v):
    if isinstance(v,bool): return 'true' if v else 'false'
    if isinstance(v,float): return str(int(v)) if v.is_integer() else str(v).rstrip('0').rstrip('.')
    return str(v)

def title_col(c): return ''.join(w.capitalize() for w in re.sub(r'\W+',' ',c.replace('_',' ')).split()) or c

def main(argv):
    args=[]; no_errors=False; i=0
    while i<len(argv):
        a=argv[i]
        if a in ('--help','-h','/?','/h'): sys.stdout.write(HELP); return 0
        if a in ('--nocolor','--no-color','/nocolor'): i+=1; continue
        if a=='--no-errors': no_errors=True; i+=1; continue
        if a in ('--config','-c','/config'): i+=2; continue
        if a in ('--interactive','-i','/i'): return repl()
        args.append(a); i+=1
    try:
        cols,rootstr,clauses=parse_query(' '.join(args) if args else 'path')
        outfmt=clauses.get('into','tabs').lower() or 'tabs'
        if outfmt not in ('tabs','lines','list','csv','json','html'): raise QueryError('Unknown output format')
        rows=[]
        for r,o in parse_roots(rootstr): rows.extend(walk_root(r,o))
        if 'where' in clauses: rows=[e for e in rows if eval_where(clauses['where'],e)]
        if 'order' in clauses:
            for spec in reversed(split_top(clauses['order'])):
                parts=words_top(spec); desc=parts and parts[-1].lower()=='desc'; key=' '.join(parts[:-1] if parts and parts[-1].lower() in ('asc','desc') else parts)
                if key.isdigit(): key=cols[int(key)-1]
                rows.sort(key=lambda e: eval_expr(key,e), reverse=desc)
        data=aggregate(cols,rows)
        if data is None:
            data=[[eval_expr(c,e) for c in cols] for e in rows]
            off=int(clauses.get('offset',0) or 0); data=data[off:]
            if 'limit' in clauses: data=data[:int(clauses['limit'])]
        if outfmt=='json': sys.stdout.write(json.dumps([{title_col(cols[i]):fmt(row[i]) for i in range(len(cols))} for row in data],separators=(',',':'))+'\n')
        elif outfmt=='csv':
            w=csv.writer(sys.stdout,lineterminator='\n'); [w.writerow([fmt(v) for v in row]) for row in data]
        elif outfmt=='lines':
            for row in data:
                for v in row: sys.stdout.write(fmt(v)+'\n')
        elif outfmt=='list':
            for row in data: sys.stdout.write('\0'.join(fmt(v) for v in row)+'\0')
            sys.stdout.write('\n')
        elif outfmt=='html':
            sys.stdout.write('<html><body><table>')
            for row in data: sys.stdout.write('<tr>'+''.join('<td>'+html.escape(fmt(v))+'</td>' for v in row)+'</tr>')
            sys.stdout.write('</table></body></html>\n')
        else:
            for row in data: sys.stdout.write('\t'.join(fmt(v) for v in row)+'\n')
        return 0
    except IOErrorExit as e:
        if not no_errors: sys.stderr.write(str(e)+'\n')
        return 1
    except QueryError as e:
        if not no_errors: sys.stderr.write('query: '+str(e)+'\n')
        return 2
    except Exception as e:
        if not no_errors: sys.stderr.write('query: '+str(e)+'\n')
        return 2

def repl():
    while True:
        try: q=input('fselect> ')
        except EOFError: break
        if q.strip().lower() in ('quit','exit'): break
        main(['--nocolor',q])
    return 0
if __name__=='__main__': sys.exit(main(sys.argv[1:]))
