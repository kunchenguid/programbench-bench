#!/usr/bin/env python3
import os
import re
import sys
import hashlib
from dataclasses import dataclass, field
from datetime import datetime, date, time, timedelta
from pathlib import Path


HELP = """Usage:
calcurse [-D <directory>] [-C <directory>] [-c <calendar file>]
calcurse -Q [--from <date>] [--to <date>] [--days <number>]
calcurse -a | -d <date> | -d <number> | -n | -r[<number>] | -s[<date>] | -t[<number>]
calcurse -h | -v | --status | -G | -P | -g | -i <file> | -x[<format>] | --daemon

Operations in command line mode:
  -Q, --query   Print items in a given query range
  -G, --grep    Grep items from the data files
  -P, --purge   Read items and write them back
Query short forms:
-a, -d <date>|<number>, -n, -r[<number>], -s[<date>], -t<number>

Note that filter, format and day-range options affect input or output:
  --filter-*              Filter items loaded by -Q, -G, -P and -x
  --format-*              Rewrite output from -Q, -G and --dump-imported
  --from <date>           Limit day range of -Q.
  --to <date>             Limit day range of -Q.
  --days <number>         Limit day range of -Q.

  --limit, -l <number>    Limit number of query results
  --search, -S <regexp>   Match regular expression in queries
Consult the man page for details.

Miscellaneous:
  -c, --calendar <file>   The calendar data file to use
  -C, --confdir <dir>     The configuration directory to use
  --daemon                Run notification daemon in the background
  -D, --datadir <dir>     The data directory to use
  -g, --gc                Run the garbage collector
  -h, --help              Show this help text
  -i, --import <file>     Import iCal data from file
  -q, --quiet             Suppress import/export result message
  --read-only             Do not save configuration or data files
  --status                Display status of running instances
  -v, --version           Show version information
  -x, --export[<format>]  Export to stdout in ical (default) or pcal format

For more information, type '?' from within calcurse, or read the manpage.
Submit feature requests and suggestions to <misc@calcurse.org>.
Submit bug reports to <bugs@calcurse.org>.
"""


@dataclass
class CalItem:
    kind: str
    raw: str
    msg: str
    start: datetime | None = None
    end: datetime | None = None
    days: int = 1
    repeat: dict = field(default_factory=dict)
    note: str = ""


@dataclass
class Todo:
    raw: str
    msg: str
    priority: int
    completed: bool = False
    note: str = ""


def datadir(opts):
    if opts.get("datadir"):
        return Path(opts["datadir"])
    home = Path(os.environ.get("HOME", "."))
    return home / ".calcurse"


def ensure_files(d):
    d.mkdir(parents=True, exist_ok=True)
    for name in ("conf", "todo", "apts"):
        (d / name).touch(exist_ok=True)


def unescape_ical(s):
    return s.replace("\\n", "\n").replace("\\,", ",").replace("\\;", ";").replace("\\\\", "\\")


def escape_ical(s):
    return s.replace("\\", "\\\\").replace(",", "\\,").replace(";", "\\;").replace("\n", "\\n")


def parse_dt(s):
    s = s.strip()
    if s.endswith("Z"):
        s = s[:-1]
    if "T" in s:
        return datetime.strptime(s[:15], "%Y%m%dT%H%M%S")
    return datetime.combine(datetime.strptime(s[:8], "%Y%m%d").date(), time())


def parse_duration(s):
    m = re.fullmatch(r"P(?:(\d+)D)?(?:T(?:(\d+)H)?(?:(\d+)M)?(?:(\d+)S)?)?", s.strip())
    if not m:
        return timedelta(0)
    d, h, mi, sec = (int(x or 0) for x in m.groups())
    return timedelta(days=d, hours=h, minutes=mi, seconds=sec)


def dur_ical(delta):
    total = int(delta.total_seconds())
    days, rem = divmod(total, 86400)
    h, rem = divmod(rem, 3600)
    m, s = divmod(rem, 60)
    if days:
        return f"P{days}DT{h}H{m}M{s}S"
    return f"PT{h}H{m}M{s}S"


def date_out(d):
    return d.strftime("%m/%d/%y")


def full_date(d):
    return d.strftime("%m/%d/%Y")


def parse_user_date(s, fmt=1):
    low = s.lower()
    today = date.today()
    if low in ("today", "now"):
        return today
    if low == "tomorrow":
        return today + timedelta(days=1)
    if low == "yesterday":
        return today - timedelta(days=1)
    weekdays = ["mon", "tue", "wed", "thu", "fri", "sat", "sun"]
    if low[:3] in weekdays:
        target = weekdays.index(low[:3])
        delta = (target - today.weekday()) % 7
        return today + timedelta(days=delta)
    if fmt == 4 or re.match(r"\d{4}-\d{1,2}-\d{1,2}$", s):
        y, m, d = map(int, s.split("-"))
        return date(y, m, d)
    parts = re.split(r"[/-]", s)
    if len(parts) == 3:
        a, b, c = map(int, parts)
        if fmt == 2:
            return date(c, b, a)
        if fmt == 3:
            return date(a, b, c)
        return date(c, a, b)
    raise ValueError(s)


def parse_apts_line(line):
    raw = line.rstrip("\n")
    msg = raw
    note = ""
    raw_no_note = raw
    note_m = re.search(r"\s>(\S+)\s", raw)
    if note_m:
        note = note_m.group(1)
        raw_no_note = raw[:note_m.start()] + " " + raw[note_m.end():]
    rep = {}
    rep_m = re.search(r"\{([^}]*)\}", raw)
    if rep_m:
        body = rep_m.group(1)
        bits = body.split()
        if bits:
            interval = bits[0]
            rep["freq"] = interval[-1]
            rep["interval"] = int(interval[:-1] or "1")
        if "->" in bits:
            idx = bits.index("->")
            if idx + 1 < len(bits):
                rep["until"] = datetime.strptime(bits[idx + 1], "%m/%d/%Y").date()
        rep["except"] = [datetime.strptime(x[1:], "%m/%d/%Y").date() for x in bits if x.startswith("!")]
    line_clean = re.sub(r"\s*\{[^}]*\}", "", raw_no_note)
    m = re.match(r"(\d\d/\d\d/\d{4}) @ (\d\d:\d\d) -> (\d\d/\d\d/\d{4}) @ (\d\d:\d\d)\|(.*)", line_clean)
    if m:
        sd, st, ed, et, msg = m.groups()
        start = datetime.strptime(sd + " " + st, "%m/%d/%Y %H:%M")
        end = datetime.strptime(ed + " " + et, "%m/%d/%Y %H:%M")
        return CalItem("apt" if not rep else "recur-apt", raw, msg, start, end, repeat=rep, note=note)
    m = re.match(r"(\d\d/\d\d/\d{4}) \[(\d+)\] (.*)", line_clean)
    if m:
        sd, days, msg = m.groups()
        start = datetime.combine(datetime.strptime(sd, "%m/%d/%Y").date(), time())
        return CalItem("event" if not rep else "recur-event", raw, msg, start, None, int(days), rep, note)
    return None


def parse_todo_line(line):
    raw = line.rstrip("\n")
    m = re.match(r"\[(-?)(\d+)\](?: >(\S+))? (.*)", raw)
    if not m:
        return None
    done, pri, note, msg = m.groups()
    return Todo(raw, msg, int(pri), done == "-", note or "")


def load_data(opts):
    d = datadir(opts)
    ensure_files(d)
    items, todos = [], []
    calfile = Path(opts["calendar"]) if opts.get("calendar") else d / "apts"
    if calfile.exists():
        for line in calfile.read_text(errors="ignore").splitlines():
            if line.strip():
                it = parse_apts_line(line)
                if it:
                    items.append(it)
    tfile = d / "todo"
    if tfile.exists():
        for line in tfile.read_text(errors="ignore").splitlines():
            if line.strip():
                td = parse_todo_line(line)
                if td:
                    todos.append(td)
    return items, todos


def occurrence_dates(item):
    if item.kind in ("event", "apt"):
        if item.kind == "event":
            for i in range(item.days):
                yield item.start.date() + timedelta(days=i), item.start, item.end
        else:
            cur = item.start.date()
            end_day = item.end.date()
            while cur <= end_day:
                yield cur, item.start, item.end
                cur += timedelta(days=1)
        return
    freq = item.repeat.get("freq", "D")
    interval = item.repeat.get("interval", 1)
    until = item.repeat.get("until") or item.start.date()
    exceptions = set(item.repeat.get("except", []))
    cur = item.start.date()
    count = 0
    while cur <= until and count < 5000:
        if cur not in exceptions:
            yield cur, datetime.combine(cur, item.start.time()), datetime.combine(cur, item.end.time()) if item.end else None
        count += 1
        if freq == "D":
            cur += timedelta(days=interval)
        elif freq == "W":
            cur += timedelta(days=7 * interval)
        elif freq == "M":
            month = cur.month - 1 + interval
            y = cur.year + month // 12
            m = month % 12 + 1
            maxd = [31, 29 if y % 4 == 0 and (y % 100 != 0 or y % 400 == 0) else 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31][m - 1]
            cur = date(y, m, min(cur.day, maxd))
        elif freq == "Y":
            cur = date(cur.year + interval, cur.month, cur.day)
        else:
            break


def type_matches(obj, type_filter):
    if not type_filter:
        return True
    expanded = set()
    for part in type_filter.split(","):
        if part == "cal":
            expanded.update(["event", "apt", "recur-event", "recur-apt"])
        elif part == "recur":
            expanded.update(["recur-event", "recur-apt"])
        else:
            expanded.add(part)
    kind = obj.kind if isinstance(obj, CalItem) else "todo"
    return kind in expanded


def apply_filters(items, todos, opts):
    pat = opts.get("pattern")
    if opts.get("search"):
        pat = opts["search"]
    rx = re.compile(pat) if pat else None
    out_i = [i for i in items if type_matches(i, opts.get("filter_type")) and (not rx or rx.search(i.msg))]
    out_t = [t for t in todos if type_matches(t, opts.get("filter_type")) and (not rx or rx.search(t.msg))]
    if opts.get("priority") is not None:
        p = opts["priority"]
        out_t = [t for t in out_t if t.priority == p]
    if opts.get("completed"):
        out_t = [t for t in out_t if t.completed]
    if opts.get("uncompleted"):
        out_t = [t for t in out_t if not t.completed]
    return out_i, out_t


def fmt_item(fmt, item, occ_start=None, occ_end=None):
    s = fmt.encode("utf-8").decode("unicode_escape")
    rawhash = hashlib.sha1(item.raw.encode()).hexdigest()
    if isinstance(item, Todo):
        return s.replace("%(raw)", item.raw + "\n").replace("%(hash)", rawhash).replace("%m", item.msg).replace("%p", str(item.priority)).replace("%n", item.note)
    st = occ_start or item.start
    en = occ_end or item.end
    dur = int(((en or st) - st).total_seconds()) if en else 0
    rep = {
        "%(raw)": item.raw + "\n",
        "%(hash)": rawhash,
        "%m": item.msg,
        "%S": st.strftime("%H:%M"),
        "%E": en.strftime("%H:%M") if en else "..:..",
        "%s": str(int(st.timestamp())),
        "%e": str(int(en.timestamp())) if en else "0",
        "%d": str(dur),
        "%n": item.note,
    }
    for k, v in rep.items():
        s = s.replace(k, v)
    return s


def query(opts):
    items, todos = apply_filters(*load_data(opts), opts)
    today = date.today()
    start = opts.get("from") or today
    if opts.get("to"):
        end = opts["to"]
    elif opts.get("days"):
        n = opts["days"]
        if n < 0:
            start = start + timedelta(days=n + 1)
            end = opts.get("from") or today
        else:
            end = start + timedelta(days=max(0, n - 1))
    else:
        end = start
    byday = {}
    for item in items:
        for d, st, en in occurrence_dates(item):
            if start <= d <= end:
                byday.setdefault(d, []).append((item, st, en))
    out = []
    for d in sorted(byday):
        out.append(f"{date_out(d)}:\n")
        day_items = sorted(byday[d], key=lambda x: (0 if x[0].kind.endswith("event") else 1, x[1].time(), x[0].msg))
        for item, st, en in day_items:
            if item.kind.endswith("event"):
                out.append(fmt_item(opts.get("format_event") or " * %m\n", item, st, en))
            else:
                out.append(fmt_item(opts.get("format_apt") or " - %S -> %E\n\t%m\n", item, st, en))
        out.append("\n")
    if todos:
        out.append("to do:\n")
        for t in todos:
            out.append(fmt_item(opts.get("format_todo") or "%p. %m\n", t))
    sys.stdout.write("".join(out))


def grep(opts):
    items, todos = apply_filters(*load_data(opts), opts)
    out = []
    for t in todos:
        out.append(fmt_item(opts.get("format_todo") or "%(raw)", t))
    for item in items:
        fmt = opts.get("format_event" if item.kind.endswith("event") else "format_apt") or "%(raw)"
        out.append(fmt_item(fmt, item))
    sys.stdout.write("".join(out))


def write_import(opts, path):
    d = datadir(opts)
    ensure_files(d)
    text = Path(path).read_text(errors="ignore").replace("\r\n", "\n")
    unfolded = []
    for line in text.splitlines():
        if line.startswith((" ", "\t")) and unfolded:
            unfolded[-1] += line[1:]
        else:
            unfolded.append(line)
    apts, todos = [], []
    errors = 0
    block = []
    kind = None
    for line in unfolded:
        if line == "BEGIN:VEVENT":
            block, kind = [], "event"
        elif line == "BEGIN:VTODO":
            block, kind = [], "todo"
        elif line in ("END:VEVENT", "END:VTODO"):
            try:
                props = {}
                malformed = False
                for b in block:
                    if ":" not in b:
                        if b.startswith(("SUMMARY", "DESCRIPTION", "EXDATE")):
                            malformed = True
                        continue
                    k, v = b.split(":", 1)
                    props.setdefault(k.split(";", 1)[0], v)
                if malformed:
                    raise ValueError("malformed property")
                if kind == "todo":
                    pri = int(props.get("PRIORITY", "0") or 0)
                    summary = unescape_ical(props.get("SUMMARY", "")).replace("\n", " ")
                    if 0 <= pri <= 9 and summary and "," not in summary:
                        todos.append(f"[{pri}] {summary}\n")
                    else:
                        raise ValueError("bad todo")
                else:
                    summary = unescape_ical(props.get("SUMMARY", "")).replace("\n", " ")
                    dtstart_line = next((b for b in block if b.startswith("DTSTART")), "")
                    if not dtstart_line or not summary or ":" not in dtstart_line:
                        raise ValueError("bad event")
                    if sum(1 for b in block if b.startswith("LOCATION")) > 1:
                        raise ValueError("duplicate location")
                    if "VALUE=" in dtstart_line and "VALUE=DATE" not in dtstart_line:
                        raise ValueError("bad dtstart value")
                    if "DESCRIPTION" in props and ";" in props["DESCRIPTION"]:
                        raise ValueError("bad description")
                    val = dtstart_line.split(":", 1)[1]
                    start = parse_dt(val)
                    is_date = "VALUE=DATE" in dtstart_line
                    if not is_date and "T" not in val:
                        raise ValueError("bad dtstart value")
                    rrule = props.get("RRULE")
                    if rrule and "FREQ=HOURLY" in rrule:
                        raise ValueError("unsupported recurrence")
                    if any(b.startswith("EXDATE") and ":" not in b for b in block):
                        raise ValueError("bad exdate")
                    if any(b.startswith("EXDATE:") for b in block) and not rrule:
                        raise ValueError("exdate without rrule")
                    if is_date:
                        days = 1
                        if "DURATION" in props and "T" in props["DURATION"]:
                            raise ValueError("bad all-day duration")
                        dtend_line = next((b for b in block if b.startswith("DTEND")), "")
                        if dtend_line and "VALUE=DATE" not in dtend_line:
                            raise ValueError("bad dtend value")
                        if rrule and re.search(r"UNTIL=\d{8}T", rrule):
                            raise ValueError("bad until")
                        for exline in (b for b in block if b.startswith("EXDATE")):
                            if "VALUE=DATE" not in exline or re.search(r":\d{8}T", exline):
                                raise ValueError("bad exdate")
                        if "DTEND" in props:
                            days = max(1, (parse_dt(props["DTEND"]).date() - start.date()).days)
                        if rrule:
                            rep = parse_rrule(rrule, start.date(), block)
                            apts.append(f"{full_date(start.date())} [1] {rep} >{hashlib.sha1(summary.encode()).hexdigest()} {summary}\n")
                        elif days > 1:
                            until = start.date() + timedelta(days=days - 1)
                            apts.append(f"{full_date(start.date())} [1] {{1D -> {full_date(until)}}} >{hashlib.sha1(summary.encode()).hexdigest()} {summary}\n")
                        else:
                            apts.append(f"{full_date(start.date())} [1] {summary}\n")
                    else:
                        if "DTEND" in props and "DURATION" in props:
                            raise ValueError("ambiguous end")
                        if "DTEND" in props:
                            end = parse_dt(props["DTEND"])
                        else:
                            end = start + parse_duration(props.get("DURATION", "PT0S"))
                        if end < start:
                            raise ValueError("end before start")
                        line = f"{full_date(start.date())} @ {start:%H:%M} -> {full_date(end.date())} @ {end:%H:%M}"
                        if rrule:
                            rep = parse_rrule(rrule, start.date(), block)
                            line += f" {rep}"
                        desc = unescape_ical(props.get("DESCRIPTION", ""))
                        if "DESCRIPTION" in props:
                            line += f">{hashlib.sha1(desc.encode()).hexdigest()} "
                        line += f"|{summary}\n"
                        apts.append(line)
            except Exception:
                errors += 1
            kind = None
        elif kind:
            block.append(line)
    (d / "apts").write_text("".join(apts))
    (d / "todo").write_text("".join(todos))
    if errors:
        print("\nSome items could not be imported.", file=sys.stderr)
        print("See /tmp/calcurse_log.XXXXXX for details.", file=sys.stderr)
    return errors


def parse_rrule(rrule, start_date, block):
    parts = dict(p.split("=", 1) for p in rrule.split(";") if "=" in p)
    freqmap = {"DAILY": "D", "WEEKLY": "W", "MONTHLY": "M", "YEARLY": "Y"}
    interval = int(parts.get("INTERVAL", "1"))
    freq = freqmap.get(parts.get("FREQ", "DAILY"), "D")
    until = None
    if "UNTIL" in parts:
        until = parse_dt(parts["UNTIL"]).date()
    elif "COUNT" in parts:
        n = int(parts["COUNT"])
        if freq == "D":
            until = start_date + timedelta(days=(n - 1) * interval)
        elif freq == "W":
            until = start_date + timedelta(days=7 * (n - 1) * interval)
        elif freq == "M":
            until = date(start_date.year, start_date.month, start_date.day)
            for _ in range(n - 1):
                month = until.month - 1 + interval
                until = date(until.year + month // 12, month % 12 + 1, min(until.day, 28))
        else:
            until = date(start_date.year + n - 1, start_date.month, start_date.day)
    until = until or start_date
    ex = []
    for b in block:
        if b.startswith("EXDATE:"):
            for x in b.split(":", 1)[1].split(","):
                ex.append(" !" + full_date(parse_dt(x).date()))
    return "{" + f"{interval}{freq} -> {full_date(until)}" + "".join(ex) + "}"


def export(opts):
    items, todos = apply_filters(*load_data(opts), opts)
    out = ["BEGIN:VCALENDAR\n", "VERSION:2.0\n", "PRODID:-//calcurse//NONSGML v4.8.2//EN\n"]
    for item in items:
        out.append("BEGIN:VEVENT\n")
        if item.kind.endswith("event"):
            out.append(f"DTSTART;VALUE=DATE:{item.start:%Y%m%d}\n")
            if item.repeat:
                out.append(f"RRULE:FREQ=DAILY;UNTIL={(item.start.date()+timedelta(days=item.days-1)):%Y%m%d}\n")
        else:
            out.append(f"DTSTART:{item.start:%Y%m%dT%H%M%S}\n")
            out.append(f"DURATION:{dur_ical(item.end - item.start)}\n")
        out.append(f"SUMMARY:{escape_ical(item.msg)}\nEND:VEVENT\n")
    for t in todos:
        out.append("BEGIN:VTODO\n")
        out.append(f"PRIORITY:{t.priority}\n")
        out.append(f"SUMMARY:{escape_ical(t.msg)}\nEND:VTODO\n")
    out.append("END:VCALENDAR\n")
    sys.stdout.write("".join(out))


def parse_args(argv):
    opts = {"input_fmt": 1}
    op = None
    i = 0
    while i < len(argv):
        a = argv[i]
        def val():
            nonlocal i
            i += 1
            return argv[i]
        if a in ("-h", "--help"): op = "help"
        elif a in ("-v", "--version"): op = "version"
        elif a == "--status": op = "status"
        elif a in ("-D", "--datadir"): opts["datadir"] = val()
        elif a in ("-C", "--confdir"): opts["confdir"] = val()
        elif a in ("-c", "--calendar"): opts["calendar"] = val()
        elif a in ("-q", "--quiet", "--read-only"): pass
        elif a == "--input-datefmt": opts["input_fmt"] = int(val())
        elif a == "--output-datefmt": opts["output_fmt"] = val()
        elif a in ("-Q", "--query"): op = "query"
        elif a in ("-G", "--grep"): op = "grep"
        elif a in ("-P", "--purge"): op = "purge"
        elif a in ("-x", "--export") or a.startswith("-x"): op = "export"
        elif a in ("-i", "--import"): op = "import"; opts["import_file"] = val()
        elif a in ("--from",): opts["from_s"] = val()
        elif a in ("--to",): opts["to_s"] = val()
        elif a == "--days": opts["days"] = int(val())
        elif a in ("-l", "--limit"): opts["limit"] = int(val())
        elif a in ("-S", "--search", "--filter-pattern"): opts["pattern"] = val()
        elif a == "--filter-type": opts["filter_type"] = val()
        elif a == "--filter-priority": opts["priority"] = int(val())
        elif a == "--filter-completed": opts["completed"] = True
        elif a == "--filter-uncompleted": opts["uncompleted"] = True
        elif a == "--format-apt": opts["format_apt"] = val()
        elif a == "--format-recur-apt": opts["format_apt"] = val()
        elif a == "--format-event": opts["format_event"] = val()
        elif a == "--format-recur-event": opts["format_event"] = val()
        elif a == "--format-todo": opts["format_todo"] = val()
        elif a in ("-a", "--appointment"): op = "query"; opts["filter_type"] = "cal"; opts["from"] = date.today()
        elif a in ("-n", "--next"): op = "query"; opts["filter_type"] = "apt"; opts["days"] = 1
        elif a.startswith("-r") and a != "-r":
            op = "query"; opts["filter_type"] = "cal"; opts["days"] = int(a[2:] or "1")
        elif a in ("-r", "--range"):
            op = "query"; opts["filter_type"] = "cal"; opts["days"] = int(argv[i+1]) if i + 1 < len(argv) and not argv[i+1].startswith("-") else 1
            if i + 1 < len(argv) and not argv[i+1].startswith("-"): i += 1
        elif a.startswith("-t") and a != "-t":
            op = "query"; opts["filter_type"] = "todo"; opts["priority"] = int(a[2:])
        elif a in ("-t", "--todo"):
            op = "query"; opts["filter_type"] = "todo"
        elif a in ("-d", "--day"):
            op = "query"; opts["filter_type"] = "cal"; x = val()
            if re.fullmatch(r"-?\d+", x): opts["days"] = int(x)
            else: opts["from_s"] = x
        elif a.startswith("-s") and a != "-s":
            op = "query"; opts["filter_type"] = "cal"; opts["from_s"] = a[2:]
        elif a in ("-s", "--startday"):
            op = "query"; opts["filter_type"] = "cal"
            if i + 1 < len(argv) and not argv[i+1].startswith("-"):
                opts["from_s"] = val()
        i += 1
    for k in ("from", "to"):
        if opts.get(k + "_s"):
            try:
                opts[k] = parse_user_date(opts[k + "_s"], opts["input_fmt"])
            except Exception:
                print(f"args.c: 797: invalid date: {opts[k + '_s']}", file=sys.stderr)
                sys.exit(1)
    return op, opts


def main(argv):
    op, opts = parse_args(argv)
    if op == "help" or not op:
        sys.stdout.write(HELP)
    elif op == "version":
        sys.stdout.write("calcurse 4.8.2 -- text-based organizer\n\nCopyright (c) 2004-2023 calcurse Development Team.\nThis is free software; see the source for copying conditions.\n")
    elif op == "status":
        sys.stdout.write("calcurse is not running\n")
    elif op == "import":
        return 1 if write_import(opts, opts["import_file"]) else 0
    elif op == "export":
        export(opts)
    elif op == "grep":
        grep(opts)
    elif op == "purge":
        load_data(opts)
    elif op == "query":
        query(opts)
    return 0


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
