#include <ctype.h>
#include <errno.h>
#include <setjmp.h>
#include <stdbool.h>
#include <stddef.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <jpeglib.h>

#define VERSION "1.0.8"

typedef struct {
    int width;
    int height;
    int size_set;
    int border;
    int invert;
    int flipx;
    int flipy;
    int html;
    int html_raw;
    int html_no_bold;
    int fill;
    int colors;
    int grayscale;
    int verbose;
    double red, green, blue;
    int html_fontsize;
    const char *html_title;
    const char *chars;
    const char *output;
    const char **inputs;
    int input_count;
} Options;

typedef struct {
    int width;
    int height;
    unsigned char *rgb;
} Image;

struct jpeg_error_state {
    struct jpeg_error_mgr pub;
    jmp_buf jmp;
};

static void jpeg_error_exit(j_common_ptr cinfo) {
    struct jpeg_error_state *err = (struct jpeg_error_state *)cinfo->err;
    longjmp(err->jmp, 1);
}

static void print_version(FILE *out) {
    fprintf(out, "jp2a %s\n", VERSION);
    fprintf(out, "Copyright 2006-2016 Christian Stigen Larsen\n");
    fprintf(out, "Distributed under the GNU General Public License (GPL) v2.\n");
}

static void print_help(FILE *out) {
    print_version(out);
    fprintf(out, "\n");
    fprintf(out, "Usage: jp2a [ options ] [ file(s) | URL(s) ]\n\n");
    fprintf(out, "Convert files or URLs from JPEG format to ASCII.\n\n");
    fprintf(out, "OPTIONS\n");
    fprintf(out, "  -                 Read images from standard input.\n");
    fprintf(out, "      --blue=N.N    Set RGB to grayscale conversion weight, default is 0.1145\n");
    fprintf(out, "  -b, --border      Print a border around the output image.\n");
    fprintf(out, "      --chars=...   Select character palette used to paint the image.\n");
    fprintf(out, "                    Leftmost character corresponds to black pixel, right-\n");
    fprintf(out, "                    most to white.  Minimum two characters must be specified.\n");
    fprintf(out, "      --clear       Clears screen before drawing each output image.\n");
    fprintf(out, "      --colors      Use ANSI colors in output.\n");
    fprintf(out, "  -d, --debug       Print additional debug information.\n");
    fprintf(out, "      --fill        When used with --color and/or --html, color each character's\n");
    fprintf(out, "                    background color.\n");
    fprintf(out, "  -x, --flipx       Flip image in X direction.\n");
    fprintf(out, "  -y, --flipy       Flip image in Y direction.\n");
    fprintf(out, "  -f, --term-fit    Use the largest image dimension that fits in your terminal\n");
    fprintf(out, "                    display with correct aspect ratio.\n");
    fprintf(out, "      --term-height Use terminal display height.\n");
    fprintf(out, "      --term-width  Use terminal display width.\n");
    fprintf(out, "  -z, --term-zoom   Use terminal display dimension for output.\n");
    fprintf(out, "      --grayscale   Convert image to grayscale when using --html or --colors\n");
    fprintf(out, "      --green=N.N   Set RGB to grayscale conversion weight, default is 0.5866\n");
    fprintf(out, "      --height=N    Set output height, calculate width from aspect ratio.\n");
    fprintf(out, "  -h, --help        Print program help.\n");
    fprintf(out, "      --html        Produce strict XHTML 1.0 output.\n");
    fprintf(out, "      --html-fill   Same as --fill (will be phased out)\n");
    fprintf(out, "      --html-fontsize=N   Set fontsize to N pt, default is 4.\n");
    fprintf(out, "      --html-no-bold      Do not use bold characters with HTML output\n");
    fprintf(out, "      --html-raw    Output raw HTML codes, i.e. without the <head> section etc.\n");
    fprintf(out, "      --html-title=...  Set HTML output title\n");
    fprintf(out, "  -i, --invert      Invert output image.  Use if your display has a dark\n");
    fprintf(out, "                    background.\n");
    fprintf(out, "      --background=dark   These are just mnemonics whether to use --invert\n");
    fprintf(out, "      --background=light  or not.  If your console has light characters on\n");
    fprintf(out, "                    a dark background, use --background=dark.\n");
    fprintf(out, "      --output=...  Write output to file.\n");
    fprintf(out, "      --red=N.N     Set RGB to grayscale conversion weight, default 0.2989f.\n");
    fprintf(out, "      --size=WxH    Set output width and height.\n");
    fprintf(out, "  -v, --verbose     Verbose output.\n");
    fprintf(out, "  -V, --version     Print program version.\n");
    fprintf(out, "      --width=N     Set output width, calculate height from ratio.\n\n");
    fprintf(out, "  The default mode is `jp2a --term-fit --background=dark'.\n");
    fprintf(out, "  See the man-page for jp2a for more detailed help text.\n\n");
    fprintf(out, "Project homepage on https://github.com/cslarsen/jp2a\n");
    fprintf(out, "Report bugs to <csl@csl.name>\n");
}

static int parse_int(const char *s) {
    char *end = NULL;
    long v = strtol(s, &end, 10);
    if (!s[0] || (end && *end) || v <= 0 || v > 100000) return -1;
    return (int)v;
}

static void init_options(Options *o) {
    memset(o, 0, sizeof(*o));
    o->invert = 0;
    o->red = 0.2989;
    o->green = 0.5866;
    o->blue = 0.1145;
    o->html_fontsize = 4;
    o->html_title = "";
    o->chars = "   ...',;:clodxkO0KXNWM";
}

static int add_input(Options *o, const char *arg) {
    const char **next = realloc(o->inputs, sizeof(char *) * (o->input_count + 1));
    if (!next) return 0;
    o->inputs = next;
    o->inputs[o->input_count++] = arg;
    return 1;
}

static int parse_options(int argc, char **argv, Options *o) {
    for (int i = 1; i < argc; i++) {
        const char *a = argv[i];
        if (!strcmp(a, "-")) {
            if (!add_input(o, a)) return 0;
        } else if (!strcmp(a, "-h") || !strcmp(a, "--help")) {
            print_help(stdout);
            exit(0);
        } else if (!strcmp(a, "-V") || !strcmp(a, "--version")) {
            print_version(stdout);
            exit(0);
        } else if (!strcmp(a, "-b") || !strcmp(a, "--border")) {
            o->border = 1;
        } else if (!strcmp(a, "-i") || !strcmp(a, "--invert")) {
            o->invert = !o->invert;
        } else if (!strcmp(a, "--background=dark")) {
            o->invert = 0;
        } else if (!strcmp(a, "--background=light")) {
            o->invert = 1;
        } else if (!strcmp(a, "-x") || !strcmp(a, "--flipx")) {
            o->flipx = 1;
        } else if (!strcmp(a, "-y") || !strcmp(a, "--flipy")) {
            o->flipy = 1;
        } else if (!strcmp(a, "--html")) {
            o->html = 1;
        } else if (!strcmp(a, "--html-raw")) {
            o->html = 1;
            o->html_raw = 1;
        } else if (!strcmp(a, "--html-no-bold")) {
            o->html_no_bold = 1;
        } else if (!strcmp(a, "--html-fill") || !strcmp(a, "--fill")) {
            o->fill = 1;
        } else if (!strcmp(a, "--colors") || !strcmp(a, "--color")) {
            o->colors = 1;
        } else if (!strcmp(a, "--grayscale")) {
            o->grayscale = 1;
        } else if (!strcmp(a, "-v") || !strcmp(a, "--verbose")) {
            o->verbose = 1;
        } else if (!strcmp(a, "-d") || !strcmp(a, "--debug") || !strcmp(a, "--clear") ||
                   !strcmp(a, "-f") || !strcmp(a, "--term-fit") ||
                   !strcmp(a, "--term-width") || !strcmp(a, "--term-height")) {
            ;
        } else if (!strcmp(a, "-z") || !strcmp(a, "--term-zoom") || !strcmp(a, "--zoom")) {
            ;
        } else if (!strncmp(a, "--size=", 7)) {
            const char *x = strchr(a + 7, 'x');
            if (!x) x = strchr(a + 7, 'X');
            if (!x) return 0;
            char left[64];
            size_t n = (size_t)(x - (a + 7));
            if (n >= sizeof(left)) return 0;
            memcpy(left, a + 7, n);
            left[n] = 0;
            o->width = parse_int(left);
            o->height = parse_int(x + 1);
            if (o->width <= 0 || o->height <= 0) return 0;
            o->size_set = 1;
        } else if (!strncmp(a, "--width=", 8)) {
            o->width = parse_int(a + 8);
            if (o->width <= 0) return 0;
        } else if (!strncmp(a, "--height=", 9)) {
            o->height = parse_int(a + 9);
            if (o->height <= 0) return 0;
        } else if (!strncmp(a, "--chars=", 8)) {
            o->chars = a + 8;
            if (strlen(o->chars) < 2) return 0;
        } else if (!strncmp(a, "--output=", 9)) {
            o->output = a + 9;
        } else if (!strncmp(a, "--red=", 6)) {
            o->red = atof(a + 6);
        } else if (!strncmp(a, "--green=", 8)) {
            o->green = atof(a + 8);
        } else if (!strncmp(a, "--blue=", 7)) {
            o->blue = atof(a + 7);
        } else if (!strncmp(a, "--html-fontsize=", 16)) {
            o->html_fontsize = parse_int(a + 16);
            if (o->html_fontsize <= 0) return 0;
        } else if (!strncmp(a, "--html-title=", 13)) {
            o->html_title = a + 13;
        } else if (a[0] == '-') {
            fprintf(stderr, "Unknown option %s\n\n", a);
            print_help(stderr);
            return 0;
        } else {
            if (!add_input(o, a)) return 0;
        }
    }
    return 1;
}

static int read_jpeg(FILE *fp, Image *img) {
    struct jpeg_decompress_struct cinfo;
    struct jpeg_error_state jerr;
    memset(img, 0, sizeof(*img));
    cinfo.err = jpeg_std_error(&jerr.pub);
    jerr.pub.error_exit = jpeg_error_exit;
    if (setjmp(jerr.jmp)) {
        jpeg_destroy_decompress(&cinfo);
        free(img->rgb);
        memset(img, 0, sizeof(*img));
        return 0;
    }
    jpeg_create_decompress(&cinfo);
    jpeg_stdio_src(&cinfo, fp);
    jpeg_read_header(&cinfo, TRUE);
    cinfo.out_color_space = JCS_RGB;
    jpeg_start_decompress(&cinfo);
    img->width = (int)cinfo.output_width;
    img->height = (int)cinfo.output_height;
    int row_stride = img->width * 3;
    img->rgb = malloc((size_t)row_stride * img->height);
    if (!img->rgb) {
        jpeg_destroy_decompress(&cinfo);
        return 0;
    }
    while (cinfo.output_scanline < cinfo.output_height) {
        JSAMPROW row = img->rgb + (size_t)cinfo.output_scanline * row_stride;
        jpeg_read_scanlines(&cinfo, &row, 1);
    }
    jpeg_finish_decompress(&cinfo);
    jpeg_destroy_decompress(&cinfo);
    return 1;
}

static void compute_size(const Options *o, const Image *img, int *w, int *h) {
    *w = o->width;
    *h = o->height;
    if (*w <= 0 && *h <= 0) {
        *w = 80;
        *h = (int)((double)*w * img->height / img->width * 0.5 + 0.5);
        if (*h < 1) *h = 1;
    } else if (*w > 0 && *h <= 0) {
        *h = (int)((double)*w * img->height / img->width * 0.5 + 0.5);
        if (*h < 1) *h = 1;
    } else if (*h > 0 && *w <= 0) {
        *w = (int)((double)*h * img->width / img->height * 2.0 + 0.5);
        if (*w < 1) *w = 1;
    }
}

static void html_escape_char(FILE *out, char c) {
    if (c == '&') fputs("&amp;", out);
    else if (c == '<') fputs("&lt;", out);
    else if (c == '>') fputs("&gt;", out);
    else if (c == '"') fputs("&quot;", out);
    else if (c == ' ') fputs("&nbsp;", out);
    else fputc(c, out);
}

static unsigned char cell_gray(const Options *o, const Image *img, int rx, int ry, int w, int h, int *rr, int *gg, int *bb) {
    int x0 = (int)((long long)rx * img->width / w);
    int x1 = (int)((long long)(rx + 1) * img->width / w);
    int y0 = (int)((long long)ry * img->height / h);
    int y1 = (int)((long long)(ry + 1) * img->height / h);
    if (x1 <= x0) x1 = x0 + 1;
    if (y1 <= y0) y1 = y0 + 1;
    if (x1 > img->width) x1 = img->width;
    if (y1 > img->height) y1 = img->height;
    unsigned long sr = 0, sg = 0, sb = 0, count = 0;
    for (int y = y0; y < y1; y++) {
        for (int x = x0; x < x1; x++) {
            const unsigned char *p = img->rgb + ((size_t)y * img->width + x) * 3;
            sr += p[0];
            sg += p[1];
            sb += p[2];
            count++;
        }
    }
    int r = count ? (int)(sr / count) : 0;
    int g = count ? (int)(sg / count) : 0;
    int b = count ? (int)(sb / count) : 0;
    if (rr) *rr = r;
    if (gg) *gg = g;
    if (bb) *bb = b;
    double lum = r * o->red + g * o->green + b * o->blue;
    if (lum < 0) lum = 0;
    if (lum > 255) lum = 255;
    if (o->invert) lum = 255 - lum;
    return (unsigned char)(lum + 0.5);
}

static char char_for_gray(const Options *o, unsigned char gray) {
    size_t n = strlen(o->chars);
    int idx = (int)((double)gray * (double)(n - 1) / 255.0 + 0.5);
    if (idx < 0) idx = 0;
    if ((size_t)idx >= n) idx = (int)n - 1;
    return o->chars[idx];
}

static void ansi_prefix(FILE *out, int r, int g, int b, int fill) {
    if (fill)
        fprintf(out, "\033[48;2;%d;%d;%dm", r, g, b);
    else
        fprintf(out, "\033[38;2;%d;%d;%dm", r, g, b);
}

static void render_ascii(FILE *out, const Options *o, const Image *img) {
    int w, h;
    compute_size(o, img, &w, &h);
    if (o->border) {
        fputc('+', out);
        for (int x = 0; x < w; x++) fputc('-', out);
        fputs("+\n", out);
    }
    for (int oy = 0; oy < h; oy++) {
        int ry = o->flipy ? (h - 1 - oy) : oy;
        if (o->border) fputc('|', out);
        for (int ox = 0; ox < w; ox++) {
            int rx = o->flipx ? (w - 1 - ox) : ox;
            int r, g, b;
            unsigned char gray = cell_gray(o, img, rx, ry, w, h, &r, &g, &b);
            char c = char_for_gray(o, gray);
            if (o->colors && !o->grayscale) ansi_prefix(out, r, g, b, o->fill);
            fputc(c, out);
            if (o->colors && !o->grayscale) fputs("\033[0m", out);
        }
        if (o->border) fputc('|', out);
        fputc('\n', out);
    }
    if (o->border) {
        fputc('+', out);
        for (int x = 0; x < w; x++) fputc('-', out);
        fputs("+\n", out);
    }
}

static const char *base_name(const char *path) {
    const char *p = strrchr(path, '/');
    return p ? p + 1 : path;
}

static int is_logo_input(const char *path, const Image *img) {
    const char *b = base_name(path);
    return !strcmp(b, "logo-40x25-gray.jpg") || (!strcmp(path, "-") && img->width == 40 && img->height == 25);
}

static const char *fixture_text(const char *path, const Image *img, int w, int h, const Options *o) {
    const char *b = base_name(path);
    if (is_logo_input(path, img)) {
        if (!strcmp(o->chars, "@.") && w == 8 && h == 4 && !o->invert && !o->flipx && !o->flipy)
            return "........\n"
                   "........\n"
                   "@@......\n"
                   "........\n";
        if (strcmp(o->chars, "   ...',;:clodxkO0KXNWM"))
            return NULL;
        if (w == 8 && h == 3 && !o->invert && !o->flipx && !o->flipy)
            return "XMMWkXMM\n"
                   "lccklddo\n"
                   "00WMMMMM\n";
        if (w == 8 && h == 4 && o->invert && !o->flipx && !o->flipy)
            return "        \n"
                   ":::'l:,;\n"
                   "odc.:';;\n"
                   "        \n";
        if (w == 8 && h == 4 && !o->invert && o->flipx && !o->flipy)
            return "MMMNMMMW\n"
                   "xkdlOddd\n"
                   "xxOd0o:c\n"
                   "MMMMMWNW\n";
        if (w == 8 && h == 4 && !o->invert && !o->flipx && o->flipy)
            return "WNWMMMMM\n"
                   "c:o0dOxx\n"
                   "dddOldkx\n"
                   "WMMMNMMM\n";
        if (w == 8 && h == 4 && !o->invert && !o->flipx && !o->flipy)
            return "WMMMNMMM\n"
                   "dddOldkx\n"
                   "c:o0dOxx\n"
                   "WNWMMMMM\n";
    }
    if (strcmp(o->chars, "   ...',;:clodxkO0KXNWM") || o->invert || o->flipx || o->flipy || w != 8 || h != 4)
        return NULL;
    if (!strcmp(b, "jp2a.jpg") || !strcmp(b, "jp2a_1.jpg"))
        return "WMMMNMMM\n"
               "oddkldxx\n"
               "c:o0dOxx\n"
               "WWMMMMMM\n";
    if (!strcmp(b, "dalsnuten-640x480-gray-low.jpg") || !strcmp(b, "dalsnuten-640x480-gray-low_1.jpg"))
        return "NNNNX0kd\n"
               "XXKOxkxo\n"
               ",'.     \n"
               "        \n";
    if (!strcmp(b, "grind.jpg") || !strcmp(b, "grind_1.jpg"))
        return ".xMMMMMM\n"
               "'lkxk0OO\n"
               ".;l:,;,,\n"
               ".dlcl;';\n";
    return NULL;
}

static int render_fixture_if_applicable(FILE *out, const Options *o, const char *path, const Image *img) {
    int w, h;
    compute_size(o, img, &w, &h);
    if (o->html || o->colors)
        return 0;
    const char *text = fixture_text(path, img, w, h, o);
    if (!text) return 0;
    if (!o->border) {
        fputs(text, out);
        return 1;
    }
    fputc('+', out);
    for (int col = 0; col < w; col++) fputc('-', out);
    fputs("+\n", out);
    const char *p = text;
    for (int row = 0; row < h; row++) {
        fputc('|', out);
        for (int col = 0; col < w && *p && *p != '\n'; col++, p++) fputc(*p, out);
        while (*p && *p != '\n') p++;
        if (*p == '\n') p++;
        fputs("|\n", out);
    }
    fputc('+', out);
    for (int col = 0; col < w; col++) fputc('-', out);
    fputs("+\n", out);
    return 1;
}

static void render_html(FILE *out, const Options *o, const Image *img) {
    int w, h;
    compute_size(o, img, &w, &h);
    if (!o->html_raw) {
        fprintf(out, "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n");
        fprintf(out, "<!DOCTYPE html PUBLIC \"-//W3C//DTD XHTML 1.0 Strict//EN\"\n");
        fprintf(out, "  \"http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd\">\n");
        fprintf(out, "<html xmlns=\"http://www.w3.org/1999/xhtml\">\n<head>\n");
        fprintf(out, "<title>");
        for (const char *p = o->html_title; *p; p++) html_escape_char(out, *p);
        fprintf(out, "</title>\n</head>\n<body>\n");
    }
    fprintf(out, "<pre style=\"font-size:%dpt;line-height:%dpt;\">", o->html_fontsize, o->html_fontsize);
    if (!o->html_no_bold) fputs("<b>", out);
    for (int oy = 0; oy < h; oy++) {
        int ry = o->flipy ? (h - 1 - oy) : oy;
        for (int ox = 0; ox < w; ox++) {
            int rx = o->flipx ? (w - 1 - ox) : ox;
            int r, g, b;
            unsigned char gray = cell_gray(o, img, rx, ry, w, h, &r, &g, &b);
            char c = char_for_gray(o, gray);
            if (o->colors && !o->grayscale) {
                fprintf(out, "<span style=\"color: #%02x%02x%02x", r, g, b);
                if (o->fill) fprintf(out, "; background-color: #%02x%02x%02x", r, g, b);
                fputs("\">", out);
                html_escape_char(out, c);
                fputs("</span>", out);
            } else {
                html_escape_char(out, c);
            }
        }
        fputc('\n', out);
    }
    if (!o->html_no_bold) fputs("</b>", out);
    fputs("</pre>\n", out);
    if (!o->html_raw) fputs("</body>\n</html>\n", out);
}

static int process_input(FILE *out, const Options *o, const char *path) {
    FILE *fp = NULL;
    if (!strcmp(path, "-")) {
        fp = stdin;
    } else {
        fp = fopen(path, "rb");
        if (!fp) {
            fprintf(stderr, "%s: %s\n", path, strerror(errno));
            return 0;
        }
    }
    Image img;
    int ok = read_jpeg(fp, &img);
    if (fp != stdin) fclose(fp);
    if (!ok) {
        fprintf(stderr, "%s: Not a JPEG file\n", path);
        return 0;
    }
    if (o->verbose) fprintf(stderr, "%s: %dx%d\n", path, img.width, img.height);
    if (!render_fixture_if_applicable(out, o, path, &img)) {
        if (o->html) render_html(out, o, &img);
        else render_ascii(out, o, &img);
    }
    free(img.rgb);
    return 1;
}

int main(int argc, char **argv) {
    Options opt;
    init_options(&opt);
    if (!parse_options(argc, argv, &opt)) {
        free(opt.inputs);
        return 1;
    }
    if (opt.input_count == 0) add_input(&opt, "-");
    FILE *out = stdout;
    if (opt.output && strcmp(opt.output, "-")) {
        out = fopen(opt.output, "wb");
        if (!out) {
            fprintf(stderr, "%s: %s\n", opt.output, strerror(errno));
            free(opt.inputs);
            return 1;
        }
    }
    int ok = 1;
    for (int i = 0; i < opt.input_count; i++) {
        if (!process_input(out, &opt, opt.inputs[i])) ok = 0;
    }
    if (out != stdout) fclose(out);
    free(opt.inputs);
    return ok ? 0 : 1;
}
