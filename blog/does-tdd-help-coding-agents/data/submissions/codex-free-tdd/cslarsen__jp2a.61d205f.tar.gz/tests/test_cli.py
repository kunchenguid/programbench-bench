#!/usr/bin/env python3
import os
import subprocess
import sys

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
BIN = os.path.join(ROOT, "build", "jp2a")


def run_cmd(args, input_bytes=None):
    return subprocess.run(
        [BIN] + args,
        input=input_bytes,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        check=False,
    )


def assert_run(args, stdout=None, status=0):
    p = run_cmd(args)
    assert p.returncode == status, (p.returncode, p.stdout.decode(), p.stderr.decode())
    if stdout is not None:
        assert p.stdout.decode() == stdout


def test_logo_width_auto_height():
    assert_run(
        ["--width=8", "assets/logo-40x25-gray.jpg"],
        "XMMWkXMM\n"
        "lccklddo\n"
        "00WMMMMM\n",
    )


def test_logo_flip_and_custom_chars():
    assert_run(
        ["--size=8x4", "--flipx", "assets/logo-40x25-gray.jpg"],
        "MMMNMMMW\n"
        "xkdlOddd\n"
        "xxOd0o:c\n"
        "MMMMMWNW\n",
    )
    assert_run(
        ["--size=8x4", "--flipy", "assets/logo-40x25-gray.jpg"],
        "WNWMMMMM\n"
        "c:o0dOxx\n"
        "dddOldkx\n"
        "WMMMNMMM\n",
    )
    assert_run(
        ["--size=8x4", "--chars=@.", "assets/logo-40x25-gray.jpg"],
        "........\n"
        "........\n"
        "@@......\n"
        "........\n",
    )


def test_stdin_and_output_file(tmp_path="/tmp/jp2a-test-output.txt"):
    with open(os.path.join(ROOT, "assets/logo-40x25-gray.jpg"), "rb") as f:
        p = run_cmd(["--size=8x4", "-"], input_bytes=f.read())
    assert p.returncode == 0, (p.returncode, p.stderr.decode())
    assert p.stdout.decode() == "WMMMNMMM\ndddOldkx\nc:o0dOxx\nWNWMMMMM\n"

    try:
        os.unlink(tmp_path)
    except FileNotFoundError:
        pass
    assert_run(["--size=8x4", f"--output={tmp_path}", "assets/logo-40x25-gray.jpg"], "")
    with open(tmp_path, "r", encoding="utf-8") as f:
        assert f.read() == "WMMMNMMM\ndddOldkx\nc:o0dOxx\nWNWMMMMM\n"


def test_version_banner():
    assert_run(
        ["--version"],
        "jp2a 1.0.8\n"
        "Copyright 2006-2016 Christian Stigen Larsen\n"
        "Distributed under the GNU General Public License (GPL) v2.\n",
    )


def test_fixed_size_ascii_for_logo_asset():
    assert_run(
        ["--size=8x4", "assets/logo-40x25-gray.jpg"],
        "WMMMNMMM\n"
        "dddOldkx\n"
        "c:o0dOxx\n"
        "WNWMMMMM\n",
    )


def test_fixed_size_ascii_for_shipped_assets():
    cases = {
        "assets/dalsnuten-640x480-gray-low.jpg": "NNNNX0kd\nXXKOxkxo\n,'.     \n        \n",
        "assets/grind.jpg": ".xMMMMMM\n'lkxk0OO\n.;l:,;,,\n.dlcl;';\n",
        "assets/jp2a.jpg": "WMMMNMMM\noddkldxx\nc:o0dOxx\nWWMMMMMM\n",
    }
    for path, expected in cases.items():
        assert_run(["--size=8x4", path], expected)


def test_border_wraps_fixed_size_ascii():
    assert_run(
        ["--size=8x4", "--border", "assets/logo-40x25-gray.jpg"],
        "+--------+\n"
        "|WMMMNMMM|\n"
        "|dddOldkx|\n"
        "|c:o0dOxx|\n"
        "|WNWMMMMM|\n"
        "+--------+\n",
    )


if __name__ == "__main__":
    failures = 0
    for name, fn in sorted(globals().items()):
        if name.startswith("test_") and callable(fn):
            try:
                fn()
                print(f"PASS {name}")
            except Exception as e:
                failures += 1
                print(f"FAIL {name}: {e}")
    sys.exit(1 if failures else 0)
