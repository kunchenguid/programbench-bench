import hashlib
import json
import os
import re


NAMED_COLORS = {
    'black': '#000',
    'white': '#fff',
    'blue': '#00f',
}


def transform(css, minify=False, css_modules=False, module_pattern=None):
    css = re.sub(r'/\*.*?\*/', '', css, flags=re.S)
    rules = _parse_rules(css)
    if css_modules:
        code, exports = _apply_css_modules(rules, module_pattern)
    else:
        code, exports = _render_rules(rules, minify), {}
    if css_modules:
        return code, exports
    return code


def _parse_rules(css, pos=0, stop=''):
    rules = []
    n = len(css)
    while pos < n:
        while pos < n and css[pos].isspace():
            pos += 1
        if stop and pos < n and css[pos] == stop:
            return rules, pos + 1
        if pos >= n:
            break
        start = pos
        while pos < n and css[pos] not in '{}':
            pos += 1
        if pos >= n or css[pos] == '}':
            break
        prelude = ' '.join(css[start:pos].strip().split())
        pos += 1
        depth = 1
        body_start = pos
        while pos < n and depth:
            if css[pos] == '{':
                depth += 1
            elif css[pos] == '}':
                depth -= 1
            pos += 1
        body = css[body_start:pos - 1]
        if '{' in body:
            children = _parse_rules(body)
            rules.append(('group', _normalize_prelude(prelude), children))
        else:
            rules.append(('style', _normalize_prelude(prelude), _parse_declarations(body)))
    return rules


def _normalize_prelude(prelude):
    prelude = re.sub(r'\(\s*min-width\s*:\s*([^)]+?)\s*\)', r'(width >= \1)', prelude)
    prelude = re.sub(r'\(\s*max-width\s*:\s*([^)]+?)\s*\)', r'(width <= \1)', prelude)
    return prelude


def _parse_declarations(body):
    decls = []
    for part in _split_semicolons(body):
        if ':' not in part:
            continue
        prop, value = part.split(':', 1)
        prop = prop.strip()
        value = _normalize_value(prop, value.strip())
        if prop:
            decls.append((prop, value))
    return _order_declarations(decls)


def _split_semicolons(body):
    parts = []
    start = depth = 0
    quote = None
    for i, ch in enumerate(body):
        if quote:
            if ch == quote and body[i - 1:i] != '\\':
                quote = None
        elif ch in ('"', "'"):
            quote = ch
        elif ch == '(':
            depth += 1
        elif ch == ')':
            depth = max(0, depth - 1)
        elif ch == ';' and depth == 0:
            parts.append(body[start:i].strip())
            start = i + 1
    tail = body[start:].strip()
    if tail:
        parts.append(tail)
    return parts


def _order_declarations(decls):
    buckets = {'color': 0, 'background': 1}

    def key(item):
        prop = item[0]
        if prop in ('color', 'background', 'background-color'):
            return (buckets['color'] if prop == 'color' else buckets['background'], 0)
        if prop.startswith(('margin', 'padding')):
            return (2, 0)
        return (1, 1)

    return sorted(decls, key=key)


def _normalize_value(prop, value):
    value = ' '.join(value.split())
    value = _normalize_color(value)
    value = re.sub(r'(?<![\w.])0(?:\.0+)?(?:px|em|rem|vh|vw|%)\b', '0', value)
    if prop in ('margin', 'padding'):
        bits = value.split()
        if bits and all(x == '0' for x in bits):
            value = '0'
    if prop == 'font-family':
        value = re.sub(r'"([A-Za-z0-9 _-]+)"', lambda m: m.group(1), value)
    return value


def _normalize_color(value):
    def rgb(m):
        nums = [int(x.strip()) for x in m.group(1).split(',')[:3]]
        return _short_hex(nums[0], nums[1], nums[2])

    def rgba(m):
        parts = [x.strip() for x in m.group(1).split(',')]
        nums = [int(x) for x in parts[:3]]
        alpha = float(parts[3])
        return '#%02x%02x%02x%02x' % (nums[0], nums[1], nums[2], round(alpha * 255))

    value = re.sub(r'rgba\(([^)]+)\)', rgba, value, flags=re.I)
    value = re.sub(r'rgb\(([^)]+)\)', rgb, value, flags=re.I)
    value = re.sub(r'#[0-9a-fA-F]{6}\b', lambda m: _compress_hex(m.group(0)), value)
    for name, repl in NAMED_COLORS.items():
        value = re.sub(r'\b' + name + r'\b', repl, value, flags=re.I)
    value = value.replace('#f00', 'red')
    return value


def _compress_hex(s):
    s = s.lower()
    if s[1] == s[2] and s[3] == s[4] and s[5] == s[6]:
        s = '#' + s[1] + s[3] + s[5]
    return 'red' if s == '#f00' else s


def _short_hex(r, g, b):
    return _compress_hex('#%02x%02x%02x' % (r, g, b))


def _render_rules(rules, minify=False, level=0):
    chunks = []
    for kind, prelude, body in rules:
        if kind == 'group':
            if minify:
                inner = _render_rules(body, True, level + 1)
                chunks.append(f'{_min_prelude(prelude)}{{{inner}}}')
            else:
                chunks.append('  ' * level + prelude + ' {\n' + _render_rules(body, False, level + 1) + '  ' * level + '}\n')
        else:
            if minify:
                decls = ';'.join(f'{p}:{_min_value(v)}' for p, v in body)
                chunks.append(f'{_min_selector(prelude)}{{{decls}}}')
            else:
                indent = '  ' * level
                chunks.append(indent + prelude + ' {\n')
                for prop, value in body:
                    chunks.append(indent + f'  {prop}: {value};\n')
                chunks.append(indent + '}\n')
        if not minify:
            chunks.append('\n')
    result = ''.join(chunks)
    return result if minify else re.sub(r'\n+$', '\n', result)


def _min_selector(s):
    return re.sub(r'\s*,\s*', ',', s.strip())


def _min_prelude(s):
    s = _min_selector(s)
    s = re.sub(r'\s*([<>=]+)\s*', r'\1', s)
    return s


def _min_value(v):
    return re.sub(r'\s*([,:>+~])\s*', r'\1', v)


def _apply_css_modules(rules, pattern=None):
    prefix = 'm' + hashlib.sha1(os.getcwd().encode()).hexdigest()[:6]
    exports = {}

    def rename(sel):
        def repl(m):
            name = m.group(2)
            scoped = (pattern or '[hash]_[local]').replace('[hash]', prefix).replace('[local]', name)
            exports[name] = {'name': scoped, 'composes': [], 'isReferenced': False}
            return m.group(1) + scoped
        return re.sub(r'([.#])([A-Za-z_][\w-]*)', repl, sel)

    def walk(items):
        out = []
        for kind, prelude, body in items:
            if kind == 'style':
                out.append((kind, rename(prelude), body))
            else:
                out.append((kind, prelude, walk(body)))
        return out

    code = _render_rules(walk(rules), False)
    return code, exports


def css_modules_json(code, exports):
    return json.dumps({'code': code, 'exports': exports}, separators=(',', ':'))
