import os
import subprocess
import sys
import tempfile
import unittest

sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))

import csslite


class CssLiteTests(unittest.TestCase):
    def test_minifies_common_declarations(self):
        css = 'body, html { margin: 0px 0px; color: blue; background: rgb(255, 255, 255); }'
        self.assertEqual(
            csslite.transform(css, minify=True),
            'body,html{color:#00f;background:#fff;margin:0}',
        )

    def test_formats_nested_media_query(self):
        css = '@media screen and (min-width: 500px) { .foo:hover { padding: 10px 20px; } }'
        self.assertEqual(
            csslite.transform(css, minify=False),
            '@media screen and (width >= 500px) {\n'
            '  .foo:hover {\n'
            '    padding: 10px 20px;\n'
            '  }\n'
            '}\n',
        )

    def test_cli_writes_output_file(self):
        with tempfile.TemporaryDirectory() as tmp:
            src = os.path.join(tmp, 'a.css')
            out = os.path.join(tmp, 'out.css')
            with open(src, 'w', encoding='utf-8') as f:
                f.write('.a { color: blue; margin: 0px; }\n')
            subprocess.run(['python3', 'main.py', '-m', src, '-o', out], check=True)
            with open(out, encoding='utf-8') as f:
                self.assertEqual(f.read(), '.a{color:#00f;margin:0}')

    def test_cli_exposes_reference_help_and_multi_input_message(self):
        help_out = subprocess.run(['python3', 'main.py', '--help'], check=True, text=True, stdout=subprocess.PIPE).stdout
        self.assertIn('lightningcss 1.0.0-alpha.70', help_out)
        self.assertIn('USAGE:\n    executable [OPTIONS] [INPUT_FILE]...', help_out)

        with tempfile.TemporaryDirectory() as tmp:
            a = os.path.join(tmp, 'a.css')
            b = os.path.join(tmp, 'b.css')
            with open(a, 'w', encoding='utf-8') as f:
                f.write('.a{color:red}')
            with open(b, 'w', encoding='utf-8') as f:
                f.write('.b{color:blue}')
            proc = subprocess.run(['python3', 'main.py', a, b], text=True, stderr=subprocess.PIPE)
            self.assertEqual(proc.stderr, 'Cannot output to stdout with multiple inputs. Use --output-dir instead.\n')

    def test_minified_stdout_has_trailing_newline(self):
        proc = subprocess.run(
            ['python3', 'main.py', '-m'],
            input='a { color: red; }',
            text=True,
            check=True,
            stdout=subprocess.PIPE,
        )
        self.assertEqual(proc.stdout, 'a{color:red}\n')


if __name__ == '__main__':
    unittest.main()
