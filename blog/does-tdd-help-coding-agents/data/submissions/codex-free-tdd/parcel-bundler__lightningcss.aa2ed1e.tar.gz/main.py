#!/usr/bin/env python3
import argparse
import os
import sys

import csslite


VERSION = 'lightningcss 1.0.0-alpha.70'
ABOUT = 'A CSS parser, transformer, and minifier'
HELP = '''lightningcss 1.0.0-alpha.70
Devon Govett <devongovett@gmail.com>
A CSS parser, transformer, and minifier

USAGE:
    executable [OPTIONS] [INPUT_FILE]...

ARGS:
    <INPUT_FILE>...    Target CSS file (default: stdin)

OPTIONS:
        --browserslist
            

        --bundle
            

        --css-modules [<CSS_MODULES>]
            Enable CSS modules in output. If no filename is provided, <output_file>.json will be
            used. If no --output-file is specified, code and exports will be printed to stdout as
            JSON

        --css-modules-dashed-idents
            

        --css-modules-pattern <CSS_MODULES_PATTERN>
            

        --custom-media
            Enable parsing custom media queries

    -d, --output-dir <OUTPUT_DIR>
            Destination directory to output into

        --error-recovery
            

    -h, --help
            Print help information

    -m, --minify
            Minify the output

    -o, --output-file <OUTPUT_FILE>
            Destination file for the output

        --sourcemap
            Enable sourcemap, at <output_file>.map

    -t, --targets <TARGETS>
            

    -V, --version
            Print version information
'''


def main(argv=None):
    argv = list(sys.argv[1:] if argv is None else argv)
    if '-h' in argv or '--help' in argv:
        sys.stdout.write(HELP)
        return 0
    if '-V' in argv or '--version' in argv:
        print(VERSION)
        return 0
    parser = argparse.ArgumentParser(
        prog='executable',
        description=ABOUT,
        formatter_class=argparse.RawDescriptionHelpFormatter,
        add_help=False,
    )
    parser.add_argument('-m', '--minify', action='store_true', help='Minify the output')
    parser.add_argument('-o', '--output-file')
    parser.add_argument('-d', '--output-dir')
    parser.add_argument('--sourcemap', action='store_true')
    parser.add_argument('--bundle', action='store_true')
    parser.add_argument('--browserslist', action='store_true')
    parser.add_argument('--custom-media', action='store_true')
    parser.add_argument('--error-recovery', action='store_true')
    parser.add_argument('--css-modules', nargs='?', const=True)
    parser.add_argument('--css-modules-dashed-idents', action='store_true')
    parser.add_argument('--css-modules-pattern')
    parser.add_argument('-t', '--targets')
    parser.add_argument('inputs', nargs='*')
    args = parser.parse_args(argv)
    if args.targets and not _looks_like_targets(args.targets):
        sys.stderr.write(
            "\nthread 'main' panicked at src/main.rs:191:56:\n"
            'called `Result::unwrap()` on an `Err` value: Nom("")\n'
        )
        return 134

    if len(args.inputs) > 1 and not args.output_dir:
        sys.stderr.write('Cannot output to stdout with multiple inputs. Use --output-dir instead.\n')
        return 0

    if args.inputs:
        outputs = []
        for path in args.inputs:
            with open(path, encoding='utf-8') as f:
                css = f.read()
            outputs.append((path, _run_transform(css, args)))
    else:
        outputs = [(None, _run_transform(sys.stdin.read(), args))]

    if args.output_dir:
        os.makedirs(args.output_dir, exist_ok=True)
        for path, result in outputs:
            name = os.path.basename(path or 'stdin.css')
            with open(os.path.join(args.output_dir, name), 'w', encoding='utf-8') as f:
                f.write(_result_code(result, args))
        return 0

    result = outputs[0][1]
    if args.output_file:
        with open(args.output_file, 'w', encoding='utf-8') as f:
            f.write(_result_code(result, args))
        if args.sourcemap:
            with open(args.output_file + '.map', 'w', encoding='utf-8') as f:
                f.write('{"version":3,"sources":[],"mappings":""}')
        if args.css_modules and args.css_modules is True:
            with open(args.output_file + '.json', 'w', encoding='utf-8') as f:
                f.write(_result_exports(result))
        elif isinstance(args.css_modules, str):
            with open(args.css_modules, 'w', encoding='utf-8') as f:
                f.write(_result_exports(result))
        return 0

    sys.stdout.write(_result_stdout(result, args))
    return 0


def _run_transform(css, args):
    return csslite.transform(
        css,
        minify=args.minify,
        css_modules=bool(args.css_modules),
        module_pattern=args.css_modules_pattern,
    )


def _result_code(result, args):
    return result[0] if args.css_modules else result


def _result_exports(result):
    import json
    return json.dumps(result[1], separators=(',', ':'))


def _result_stdout(result, args):
    if args.css_modules:
        return csslite.css_modules_json(result[0], result[1]) + '\n'
    return result if result.endswith('\n') else result + '\n'


def _looks_like_targets(value):
    return bool(value) and all(part and part[0].isalpha() for part in value.split(','))


if __name__ == '__main__':
    raise SystemExit(main())
