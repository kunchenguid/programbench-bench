#!/usr/bin/env node
const fs = require('fs');
const zlib = require('zlib');

const HELP = `Usage: executable [OPTION]... [FILE]...
Options:
  -#                          compression level (0-9)
  -c, --stdout                write on standard output
  -d, --decompress            decompress
  -f, --force                 force output file overwrite
  -h, --help                  display this help and exit
  -j, --rm                    remove source file(s)
  -s, --squash                remove destination file if larger than source
  -k, --keep                  keep source file(s) (default)
  -n, --no-copy-stat          do not copy source file(s) attributes
  -o FILE, --output=FILE      output file (only if 1 input file)
  -q NUM, --quality=NUM       compression level (0-11)
  -t, --test                  test compressed file integrity
  -v, --verbose               verbose mode
  -w NUM, --lgwin=NUM         set LZ77 window size (0, 10-24)
                              window size = 2**NUM - 16
                              0 lets compressor choose the optimal value
  --large_window=NUM          use incompatible large-window brotli
                              bitstream with window size (0, 10-30)
                              WARNING: this format is not compatible
                              with brotli RFC 7932 and may not be
                              decodable with regular brotli decoders
  -C B64, --comment=B64       set comment; argument is base64-decoded first;
                              (maximal decoded length: 80)
                              when decoding: check stream comment;
                              when encoding: embed comment (fingerprint)
  -D FILE, --dictionary=FILE  use FILE as raw (LZ77) dictionary
  -K, --concatenated          allows concatenated brotli streams as input
  -S SUF, --suffix=SUF        output file suffix (default:'.br')
  -V, --version               display version and exit
  -Z, --best                  use best compression level (11) (default)
Simple options could be coalesced, i.e. '-9kf' is equivalent to '-9 -k -f'.
With no FILE, or when FILE is -, read standard input.
All arguments after '--' are treated as files.
`;

function die(msg, usageToStdout = false) {
  if (usageToStdout) process.stdout.write(HELP);
  console.error(msg);
  process.exitCode = 1;
  throw new Error('__exit__');
}

function parseNum(s, lo, hi, name) {
  if (!/^-?\d+$/.test(s)) die(`error parsing ${name} value [${s}]`);
  const n = Number(s);
  if (n < lo || n > hi) die(`error parsing ${name} value [${s}]`);
  return n;
}

function parseComment(s) {
  if (!s) die('invalid base64-encoded comment', false);
  if (!/^[A-Za-z0-9+/]*={0,2}$/.test(s) || s.length % 4 !== 0) {
    process.stderr.write('invalid base64-encoded comment\n' + HELP);
    process.exit(1);
  }
  const b = Buffer.from(s, 'base64');
  if (b.length < 1 || b.length > 80 || b.toString('base64') !== s) {
    process.stderr.write('invalid base64-encoded comment\n' + HELP);
    process.exit(1);
  }
  return b;
}

function parseArgs(argv) {
  const o = {
    decompress: false, test: false, stdout: false, force: false,
    remove: false, keepSeen: false, rmSeen: false, quality: 11, lgwin: 22,
    verbose: 0, suffix: '.br', output: null, comment: null, files: []
  };
  const need = (i, opt) => {
    if (i + 1 >= argv.length || argv[i + 1] === '') {
      process.stderr.write(`expected parameter for argument ${opt}\n` + HELP);
      process.exit(1);
    }
    return argv[i + 1];
  };
  for (let i = 0; i < argv.length; i++) {
    const a = argv[i];
    if (a === '--') {
      o.files.push(...argv.slice(i + 1));
      break;
    }
    if (!a.startsWith('-') || a === '-') {
      o.files.push(a);
      continue;
    }
    if (a.startsWith('--')) {
      const eq = a.indexOf('=');
      const key = eq >= 0 ? a.slice(0, eq) : a;
      const val = eq >= 0 ? a.slice(eq + 1) : null;
      if (key === '--help' && val === null) { process.stdout.write(HELP); process.exit(0); }
      else if (key === '--version' && val === null) { console.log('brotli 1.2.0'); process.exit(0); }
      else if (key === '--stdout' && val === null) o.stdout = true;
      else if (key === '--decompress' && val === null) o.decompress = true;
      else if (key === '--test' && val === null) { o.test = true; o.decompress = true; o.stdout = true; }
      else if (key === '--force' && val === null) o.force = true;
      else if ((key === '--rm' || key === '--keep') && val === null) {
        if (o.keepSeen || o.rmSeen) die('argument --rm / -j or --keep / -k already set', true);
        if (key === '--rm') { o.rmSeen = true; o.remove = true; } else o.keepSeen = true;
      } else if (key === '--no-copy-stat' && val === null) {}
      else if (key === '--concatenated' && val === null) {}
      else if (key === '--quality' && val !== null) o.quality = parseNum(val, 0, 11, 'quality');
      else if ((key === '--lgwin' || key === '--large_window') && val !== null) o.lgwin = parseNum(val, 0, key === '--large_window' ? 30 : 24, 'lgwin');
      else if (key === '--output' && val !== null) o.output = val;
      else if (key === '--suffix' && val !== null) o.suffix = val;
      else if (key === '--comment' && val !== null) o.comment = parseComment(val);
      else if (key === '--dictionary' && val !== null) {}
      else die(val === null ? `must pass the parameter as ${a}=value` : `unknown option [${a}]`, true);
      continue;
    }
    for (let j = 1; j < a.length; j++) {
      const c = a[j];
      if (/[0-9]/.test(c)) o.quality = Number(c);
      else if (c === 'c') o.stdout = true;
      else if (c === 'd') o.decompress = true;
      else if (c === 'f') o.force = true;
      else if (c === 'h') { process.stdout.write(HELP); process.exit(0); }
      else if (c === 'j' || c === 'k') {
        if (o.keepSeen || o.rmSeen) die('argument --rm / -j or --keep / -k already set', true);
        if (c === 'j') { o.rmSeen = true; o.remove = true; } else o.keepSeen = true;
      } else if (c === 'n' || c === 's' || c === 'K') {}
      else if (c === 't') { o.test = true; o.decompress = true; o.stdout = true; }
      else if (c === 'v') o.verbose++;
      else if (c === 'V') { console.log('brotli 1.2.0'); process.exit(0); }
      else if (c === 'Z') o.quality = 11;
      else if ('oqwSCD'.includes(c)) {
        const opt = '-' + c;
        const val = j + 1 < a.length ? a.slice(j + 1) : need(i++, opt);
        if (c === 'o') o.output = val;
        else if (c === 'S') o.suffix = val;
        else if (c === 'D') {}
        else if (c === 'q') o.quality = parseNum(val, 0, 11, 'quality');
        else if (c === 'w') o.lgwin = parseNum(val, 0, 24, 'lgwin');
        else if (c === 'C') o.comment = parseComment(val);
        break;
      } else die(`unknown option [-${c}]`, true);
    }
  }
  if (o.files.length === 0) o.files.push('-');
  return o;
}

function readInput(name) {
  if (name === '-') return fs.readFileSync(0);
  try { return fs.readFileSync(name); }
  catch (e) {
    console.error(`failed to open input file [${name}]: ${e.message.split(': ').pop()}`);
    process.exitCode = 1;
    return null;
  }
}

function metadata(comment) {
  const n = comment.length - 1;
  return Buffer.concat([Buffer.from([0x21, 0x0b | ((n & 7) << 5), n >> 3]), comment]);
}

function commentMatches(buf, comment) {
  if (!comment) return true;
  if (buf.length < 3 || buf[0] !== 0x21 || (buf[1] & 0x1f) !== 0x0b) return false;
  const len = (buf[1] >> 5) + 1 + (buf[2] << 3);
  return len === comment.length && buf.length >= 3 + len && buf.subarray(3, 3 + len).equals(comment);
}

function stripInitialMetadata(buf) {
  if (buf.length < 3 || buf[0] !== 0x21 || (buf[1] & 0x1f) !== 0x0b) return buf;
  const len = (buf[1] >> 5) + 1 + (buf[2] << 3);
  if (buf.length < 3 + len) return buf;
  return buf.subarray(3 + len);
}

function outName(o, name) {
  if (o.output) return o.output;
  if (o.decompress || o.test) {
    if (!name.endsWith(o.suffix)) {
      console.error(`input file [${name}] suffix mismatch`);
      process.exitCode = 1;
      return null;
    }
    return name.slice(0, -o.suffix.length);
  }
  return name + o.suffix;
}

function writeOutput(o, name, buf) {
  if (o.test) return true;
  if (o.stdout || name === '-') {
    fs.writeSync(1, buf);
    return true;
  }
  const dest = outName(o, name);
  if (!dest) return false;
  try {
    const flag = o.force ? 'w' : 'wx';
    fs.writeFileSync(dest, buf, { flag });
    return true;
  } catch (e) {
    console.error(`failed to open output file [${dest}]: ${e.code === 'EEXIST' ? 'File exists' : e.message.split(': ').pop()}`);
    process.exitCode = 1;
    return false;
  }
}

function processOne(o, name) {
  const input = readInput(name);
  if (input === null) return false;
  const start = Date.now();
  let output;
  try {
    if (o.decompress || o.test) {
      if (!commentMatches(input, o.comment)) throw new Error('bad comment');
      output = zlib.brotliDecompressSync(stripInitialMetadata(input));
    } else {
      const params = {};
      params[zlib.constants.BROTLI_PARAM_QUALITY] = o.quality;
      if (o.lgwin !== 0) params[zlib.constants.BROTLI_PARAM_LGWIN] = o.lgwin;
      output = zlib.brotliCompressSync(input, { params });
      if (o.comment) output = Buffer.concat([metadata(o.comment), output]);
    }
  } catch (_) {
    console.error(`corrupt input [${name === '-' ? '[stdin]' : name}]`);
    process.exitCode = 1;
    return false;
  }
  if (!writeOutput(o, name, output)) return false;
  if (o.remove && name !== '-') {
    try { fs.unlinkSync(name); } catch (_) {}
  }
  if (o.verbose) {
    const verb = (o.decompress || o.test) ? 'Decompressed' : 'Compressed';
    process.stderr.write(`${verb} [${name}]: ${input.length} B -> ${output.length} B in ${((Date.now() - start) / 1000).toFixed(2)} sec\n`);
  }
  return true;
}

try {
  const opts = parseArgs(process.argv.slice(2));
  let ok = true;
  for (const f of opts.files) if (!processOne(opts, f)) ok = false;
  process.exit(ok ? 0 : (process.exitCode || 1));
} catch (e) {
  if (e.message !== '__exit__') throw e;
  process.exit(process.exitCode || 1);
}
