#!/bin/bash
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
BUILD="$(mktemp -d)"
trap 'rm -rf "$BUILD"' EXIT

cp "$ROOT/compile.sh" "$BUILD/"
cp -R "$ROOT/src" "$BUILD/"
cd "$BUILD"
chmod +x ./compile.sh
./compile.sh >/tmp/pb-test-build.log 2>&1

fail() {
  echo "FAIL: $*" >&2
  exit 1
}

assert_eq() {
  local got="$1" want="$2" msg="$3"
  [[ "$got" == "$want" ]] || fail "$msg: got [$got], want [$want]"
}

assert_file_eq() {
  cmp -s "$1" "$2" || fail "$3"
}

help_out="$(./executable --help)"
[[ "$help_out" == Usage:* ]] || fail "help starts with Usage"
[[ "$help_out" == *"--comment=B64"* ]] || fail "help includes comment option"
assert_eq "$(./executable --version)" "brotli 1.2.0" "version output"

printf 'hello hello hello\n' > plain.txt
./executable -c plain.txt > compressed.br
./executable -dc compressed.br > decoded.txt
assert_file_eq plain.txt decoded.txt "stdout round trip"

./executable plain.txt
[[ -s plain.txt.br ]] || fail "file compression creates .br"
set +e
err="$(./executable plain.txt 2>&1 >/dev/null)"
st=$?
set -e
assert_eq "$st" "1" "existing output status"
assert_eq "$err" "failed to open output file [plain.txt.br]: File exists" "existing output error"

rm -f plain.txt
./executable -d plain.txt.br
assert_file_eq decoded.txt plain.txt "file decompression restores suffix-stripped file"

set +e
err="$(printf 'not brotli' | ./executable -dc 2>&1 >/dev/null)"
st=$?
set -e
assert_eq "$st" "1" "invalid stream status"
assert_eq "$err" "corrupt input [[stdin]]" "invalid stream error"

printf payload > c.txt
./executable -C SGVsbG8= -c c.txt > c.br
./executable -d -C SGVsbG8= -c c.br > c.out
assert_file_eq c.txt c.out "commented stream round trip"
set +e
err="$(./executable -d -C V29ybGQ= -c c.br 2>&1 >/dev/null)"
st=$?
set -e
assert_eq "$st" "1" "wrong comment status"
assert_eq "$err" "corrupt input [c.br]" "wrong comment error"
