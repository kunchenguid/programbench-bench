#!/usr/bin/env python3
import os
import subprocess
import tempfile
import unittest


ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
BIN = os.path.join(ROOT, "executable")


class CurlieTranslationTests(unittest.TestCase):
    maxDiff = None

    def run_cmd(self, *args):
        proc = subprocess.run(
            [BIN, *args],
            input="",
            text=True,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            check=False,
        )
        return proc.returncode, proc.stdout, proc.stderr

    def assert_curl(self, args, expected_stdout):
        code, stdout, stderr = self.run_cmd("--curl", *args)
        self.assertEqual(code, 0, stderr)
        self.assertEqual(stdout, expected_stdout)

    def test_empty_get_translation(self):
        self.assert_curl(
            ["example.com"],
            'http://example.com\n'
            'curl example.com -s -S -d@- -H "Content-Type: application/json" -H "Accept: application/json, */*"\n',
        )

    def test_explicit_method_translation(self):
        self.assert_curl(
            ["PUT", "example.com", "a=1"],
            'http://example.com\n'
            'curl -X PUT -d {"a":"1"} example.com -s -S -H "Content-Type: application/json" -H "Accept: application/json, */*"\n',
        )

    def test_json_headers_and_query_translation(self):
        self.assert_curl(
            ["example.com", "foo=bar", "baz:=123", "X-Test:abc", "q==term"],
            'http://example.com?q=term\n'
            'curl -H X-Test:abc -d {"baz":123,"foo":"bar"} example.com?q=term -s -S -H "Content-Type: application/json" -H "Accept: application/json, */*"\n',
        )

    def test_form_mode_translation(self):
        self.assert_curl(
            ["--form", "example.com", "a=1"],
            'http://example.com\n'
            'curl -F a=1 example.com -s -S -d@- -H "Accept: application/json, */*"\n',
        )

    def test_curl_option_with_value_before_method(self):
        self.assert_curl(
            ["-u", "bob:secret", "GET", "example.com"],
            'http://example.com\n'
            'curl -u bob:secret -X GET example.com -s -S -d@- -H "Content-Type: application/json" -H "Accept: application/json, */*"\n',
        )

    def test_help_starts_with_wrapper_usage(self):
        code, stdout, stderr = self.run_cmd("--help")

        self.assertEqual(code, 0, stderr)
        self.assertTrue(stdout.startswith("Usage: executable [options...] [METHOD] URL"))

    def test_pretty_formats_json_response(self):
        with tempfile.NamedTemporaryFile("w", delete=False) as handle:
            handle.write('{"b":2,"a":1}')
            path = handle.name
        self.addCleanup(lambda: os.path.exists(path) and os.unlink(path))

        code, stdout, stderr = self.run_cmd("--pretty", "file://" + path)

        self.assertEqual(code, 0, stderr)
        self.assertEqual(stdout, '{\n  "a": 1,\n  "b": 2\n}\n')


if __name__ == "__main__":
    unittest.main()
