#!/usr/bin/env python3
import json
import os
import subprocess
import sys
from urllib.parse import quote


METHODS = {
    "GET",
    "POST",
    "PUT",
    "PATCH",
    "DELETE",
    "HEAD",
    "OPTIONS",
    "TRACE",
    "CONNECT",
}

OPTIONS_WITH_VALUE = {
    "-A",
    "--user-agent",
    "-b",
    "--cookie",
    "-d",
    "--data",
    "--data-raw",
    "--data-binary",
    "-e",
    "--referer",
    "-F",
    "--form",
    "-H",
    "--header",
    "-o",
    "--output",
    "-u",
    "--user",
    "-X",
    "--request",
}


def display_url(url, query_items):
    out = url
    if "://" not in out:
        out = "http://" + out
    if query_items:
        sep = "&" if "?" in out else "?"
        out += sep + "&".join(f"{quote(k)}={quote(v)}" for k, v in query_items)
    return out


def command_url(url, query_items):
    if not query_items:
        return url
    sep = "&" if "?" in url else "?"
    return url + sep + "&".join(f"{quote(k)}={quote(v)}" for k, v in query_items)


def split_request_item(item):
    for marker in (":=", "==", "="):
        if marker in item:
            left, right = item.split(marker, 1)
            if left:
                return marker, left, right
    if ":" in item:
        left, right = item.split(":", 1)
        return ":", left, right
    return None, None, None


def parse_args(argv):
    curl_mode = False
    form_mode = False
    pretty = False
    curl_options = []
    rest = []
    i = 0
    while i < len(argv):
        arg = argv[i]
        if arg == "--curl":
            curl_mode = True
        elif arg == "--form":
            form_mode = True
        elif arg == "--pretty":
            pretty = True
        elif arg.startswith("-") and not rest:
            curl_options.append(arg)
            if arg in OPTIONS_WITH_VALUE and i + 1 < len(argv):
                i += 1
                curl_options.append(argv[i])
        else:
            rest.append(arg)
        i += 1

    method = None
    if rest and rest[0] in METHODS and len(rest) >= 2:
        method = rest.pop(0)
    url = rest.pop(0) if rest else ""
    return {
        "curl_mode": curl_mode,
        "form_mode": form_mode,
        "pretty": pretty,
        "curl_options": curl_options,
        "method": method,
        "url": url,
        "items": rest,
    }


def parse_items(items, form_mode):
    headers = []
    query = []
    data = {}
    forms = []
    passthrough = []

    for item in items:
        marker, key, value = split_request_item(item)
        if marker == "==":
            query.append((key, value))
        elif form_mode and marker in ("=", ":="):
            forms.append(f"{key}={value}")
        elif marker == "=":
            data[key] = value
        elif marker == ":=":
            try:
                data[key] = json.loads(value)
            except json.JSONDecodeError:
                data[key] = None
        elif marker == ":":
            headers.append(f"{key}:{value}")
        else:
            passthrough.append(item)
    return headers, query, data, forms, passthrough


def build_curl_args(parsed):
    headers, query, data, forms, passthrough = parse_items(parsed["items"], parsed["form_mode"])
    url = command_url(parsed["url"], query)
    args = ["curl"]
    args.extend(parsed["curl_options"])
    args.extend(passthrough)
    if parsed["method"]:
        args.extend(["-X", parsed["method"]])
    for header in headers:
        args.extend(["-H", header])
    for form in forms:
        args.extend(["-F", form])
    has_json_data = bool(data)
    if has_json_data:
        args.extend(["-d", json.dumps(data, separators=(",", ":"), sort_keys=True)])
    if url:
        args.append(url)
    args.extend(["-s", "-S"])
    if parsed["pretty"]:
        args.append("-v")
    if not has_json_data:
        args.append("-d@-")
    if not parsed["form_mode"]:
        args.extend(["-H", "Content-Type: application/json"])
    args.extend(["-H", "Accept: application/json, */*"])
    return args, display_url(parsed["url"], query)


def shell_join_for_curl(args):
    rendered = []
    for arg in args:
        if arg in ("curl", "-s", "-S", "-v", "-X", "-H", "-d", "-F", "-d@-"):
            rendered.append(arg)
        elif arg in ("Content-Type: application/json", "Accept: application/json, */*"):
            rendered.append(f'"{arg}"')
        else:
            rendered.append(arg)
    return " ".join(rendered)


def main(argv):
    if any(a == "--version" for a in argv):
        return subprocess.call(["curl", "--version"])
    if any(a == "--help" for a in argv):
        print(
            f"Usage: {os.path.basename(sys.argv[0])} [options...] [METHOD] URL [REQUEST_ITEM [REQUEST_ITEM ...]]",
            flush=True,
        )
        return subprocess.call(["curl", "--help"])

    parsed = parse_args(argv)
    args, shown_url = build_curl_args(parsed)
    if parsed["curl_mode"]:
        print(shown_url)
        print(shell_join_for_curl(args))
        return 0

    if parsed["pretty"]:
        proc = subprocess.run(args, input=sys.stdin.buffer.read(), stdout=subprocess.PIPE)
        try:
            parsed_json = json.loads(proc.stdout.decode("utf-8"))
        except (json.JSONDecodeError, UnicodeDecodeError):
            sys.stdout.buffer.write(proc.stdout)
        else:
            print(json.dumps(parsed_json, indent=2, sort_keys=True))
        return proc.returncode

    return subprocess.call(args)


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
