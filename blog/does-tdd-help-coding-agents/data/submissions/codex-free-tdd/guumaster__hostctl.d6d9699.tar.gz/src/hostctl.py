#!/usr/bin/env python3
import argparse
import datetime
import json
import os
import shutil
import sys


MARKER = [
    "##################################################################",
    "# Content under this line is handled by hostctl. DO NOT EDIT.",
    "##################################################################",
]


def info(msg):
    print(f"[ℹ] {msg}")


def ok(msg):
    print(f"[✔] {msg}")


def err(msg):
    print(f"[✖] error: {msg}")


class Hosts:
    def __init__(self, path):
        self.path = path
        self.base = []
        self.profiles = []
        self.load()

    def load(self):
        try:
            lines = open(self.path, encoding="utf-8").read().splitlines()
        except FileNotFoundError:
            lines = []
        marker_idx = None
        for i in range(len(lines) - 2):
            if lines[i : i + 3] == MARKER:
                marker_idx = i
                break
        if marker_idx is None:
            self.base = lines
            self.profiles = []
            return
        self.base = lines[:marker_idx]
        i = marker_idx + 3
        profiles = []
        while i < len(lines):
            line = lines[i].strip()
            if not line:
                i += 1
                continue
            if line.startswith("# profile."):
                parts = line.split(maxsplit=2)
                status = parts[1].split(".", 1)[1]
                name = parts[2] if len(parts) > 2 else ""
                rows = []
                i += 1
                while i < len(lines) and lines[i].strip() != "# end":
                    raw = lines[i]
                    disabled = raw.lstrip().startswith("#")
                    text = raw.lstrip()
                    if text.startswith("#"):
                        text = text[1:].strip()
                    fields = text.split()
                    if len(fields) >= 2:
                        rows.append((fields[0], fields[1]))
                    i += 1
                profiles.append({"name": name, "status": status, "rows": rows})
            i += 1
        self.profiles = profiles

    def save(self):
        out = []
        for line in self.base:
            text = line.strip()
            if not text or text.startswith("#"):
                out.append(line)
                continue
            fields = text.split()
            if len(fields) >= 2:
                out.append(f"{fields[0]} {fields[1]}")
            else:
                out.append(line)
        while out and out[-1] == "":
            out.pop()
        out.append("")
        out.extend(MARKER)
        if self.profiles:
            out.append("")
        for idx, profile in enumerate(self.profiles):
            if idx:
                out.append("")
            out.append(f"# profile.{profile['status']} {profile['name']}")
            prefix = "" if profile["status"] == "on" else "# "
            for ip, host in profile["rows"]:
                out.append(f"{prefix}{ip} {host}")
            out.append("# end")
        data = "\n".join(out) + "\n"
        with open(self.path, "w", encoding="utf-8") as fh:
            fh.write(data)

    def get(self, name):
        for profile in self.profiles:
            if profile["name"] == name:
                return profile
        return None

    def ensure(self, name):
        profile = self.get(name)
        if profile is None:
            profile = {"name": name, "status": "on", "rows": []}
            self.profiles.append(profile)
        return profile

    def remove_profile(self, name):
        before = len(self.profiles)
        self.profiles = [p for p in self.profiles if p["name"] != name]
        return len(self.profiles) != before

    def default_rows(self):
        rows = []
        for line in self.base:
            text = line.strip()
            if not text or text.startswith("#"):
                continue
            fields = text.split()
            if len(fields) >= 2:
                rows.append(("default", "on", fields[0], fields[1]))
        return rows

    def profile_rows(self, names=None, status=None, include_default=False):
        rows = self.default_rows() if include_default else []
        wanted = set(names or [])
        for p in self.profiles:
            if wanted and p["name"] not in wanted:
                continue
            if status and p["status"] != status:
                continue
            for ip, host in p["rows"]:
                rows.append((p["name"], p["status"], ip, host))
        return rows


def read_entries(path):
    entries = []
    with open(path, encoding="utf-8") as fh:
        for line in fh:
            text = line.strip()
            if not text or text.startswith("#"):
                continue
            fields = text.split()
            if len(fields) >= 2:
                ip = fields[0]
                for host in fields[1:]:
                    entries.append((ip, host))
    return entries


def parse_global(argv):
    opts = {"host_file": "/etc/hosts", "out": "table", "quiet": False, "columns": None, "raw": False}
    rest = []
    i = 0
    while i < len(argv):
        a = argv[i]
        if a in ("--host-file",):
            opts["host_file"] = argv[i + 1]
            i += 2
        elif a in ("-o", "--out"):
            opts["out"] = argv[i + 1]
            i += 2
        elif a == "--raw":
            opts["out"] = "raw"
            i += 1
        elif a in ("-q", "--quiet"):
            opts["quiet"] = True
            i += 1
        elif a in ("-c", "--column"):
            opts["columns"] = argv[i + 1].split(",")
            i += 2
        elif a == "--no-color":
            i += 1
        else:
            rest.append(a)
            i += 1
    return opts, rest


def maybe_header(opts):
    if not opts["quiet"] and opts["out"] != "json":
        info(f"Using hosts file: {opts['host_file']}")
        print()


def selected_columns(opts, status_only=False):
    cols = ["PROFILE", "STATUS"] if status_only else ["PROFILE", "STATUS", "IP", "DOMAIN"]
    if opts["columns"]:
        mapping = {"profile": "PROFILE", "status": "STATUS", "ip": "IP", "domain": "DOMAIN", "host": "DOMAIN"}
        cols = [mapping.get(c.lower(), c.upper()) for c in opts["columns"]]
    return cols


def row_dict(row):
    return {"PROFILE": row[0], "STATUS": row[1], "IP": row[2], "DOMAIN": row[3]}


def print_rows(rows, opts, status_only=False):
    cols = selected_columns(opts, status_only)
    if opts["quiet"]:
        return
    if opts["out"] == "json":
        if status_only:
            data = [{"Profile": r[0], "Status": r[1], "IP": "", "Host": ""} for r in rows]
        else:
            data = [{"Profile": r[0], "Status": r[1], "IP": r[2], "Host": r[3]} for r in rows]
        print(json.dumps(data, separators=(",", ":")))
        return
    data_rows = [[row_dict(r).get(c, "") for c in cols] for r in rows]
    widths = [len(c) for c in cols]
    for r in data_rows:
        for i, cell in enumerate(r):
            widths[i] = max(widths[i], len(cell))
    if opts["out"] == "raw":
        print("\t".join(c.ljust(widths[i]) for i, c in enumerate(cols)))
        for r in data_rows:
            print("\t".join(r[i].ljust(widths[i]) for i in range(len(cols))) + "\t")
        return
    if opts["out"] == "markdown":
        print("| " + " | ".join(cols[i].center(widths[i]) for i in range(len(cols))) + " |")
        print("|" + "|".join("-" * (widths[i] + 2) for i in range(len(cols))) + "|")
        for r in data_rows:
            print("| " + " | ".join(r[i].ljust(widths[i]) for i in range(len(cols))) + " |")
        return
    sep = "+" + "+".join("-" * (w + 2) for w in widths) + "+"
    print(sep)
    print("| " + " | ".join(cols[i].center(widths[i]) for i in range(len(cols))) + " |")
    print(sep)
    last_profile = None
    for r in data_rows:
        if last_profile is not None and r[0] != last_profile and len(data_rows) > 1:
            print(sep)
        print("| " + " | ".join(r[i].ljust(widths[i]) for i in range(len(cols))) + " |")
        last_profile = r[0]
    print(sep)


def usage():
    print(
        """
hostctl is a CLI tool to manage your hosts file with ease.
You can have multiple profiles, enable/disable exactly what
you need each time with a simple interface.

Usage:
  hostctl [command]

Available Commands:
  add         Add content to a profile in your hosts file.
  backup      Creates a backup copy of your hosts file
  disable     Disable a profile from your hosts file.
  enable      Enable a profile on your hosts file.
  help        Help about any command
  list        Shows a detailed list of profiles on your hosts file.
  remove      Remove a profile from your hosts file.
  replace     Replace content to a profile in your hosts file.
  restore     Restore hosts file content from a backup file.
  status      Shows a list of profile names and statuses on your hosts file.
  sync        Sync some system IPs with a profile.
  toggle      Change status of a profile on your hosts file.
"""
    )


def require_profile(args):
    if not args:
        err("missing profile name")
        return None
    return args[0]


def cmd_add(hosts, args, opts):
    if args and args[0] in ("domains", "domain"):
        if len(args) < 3:
            err("missing profile name")
            return 1
        name = args[1]
        ip = "127.0.0.1"
        domains = []
        i = 2
        while i < len(args):
            if args[i] == "--ip":
                ip = args[i + 1]
                i += 2
            else:
                domains.append(args[i])
                i += 1
        p = hosts.ensure(name)
        p["rows"].extend((ip, d) for d in domains)
        hosts.save()
        maybe_header(opts)
        if not opts["quiet"]:
            ok(f"Domains '{', '.join(domains)}' added.")
            print()
        print_rows(hosts.profile_rows([name]), opts)
        return 0
    name = require_profile(args)
    if not name:
        return 1
    src = None
    if "-f" in args:
        src = args[args.index("-f") + 1]
    elif "--from" in args:
        src = args[args.index("--from") + 1]
    if not src:
        err("missing file to read")
        return 1
    try:
        entries = read_entries(src)
    except OSError as e:
        maybe_header(opts)
        err(str(e))
        return 1
    p = hosts.ensure(name)
    p["rows"].extend(entries)
    hosts.save()
    maybe_header(opts)
    print_rows(hosts.profile_rows([name]), opts)
    return 0


def cmd_replace(hosts, args, opts):
    name = require_profile(args)
    if not name:
        return 1
    src = args[args.index("-f") + 1] if "-f" in args else args[args.index("--from") + 1] if "--from" in args else None
    try:
        entries = read_entries(src)
    except OSError as e:
        maybe_header(opts)
        err(str(e))
        return 1
    p = hosts.ensure(name)
    p["status"] = "on"
    p["rows"] = entries
    hosts.save()
    maybe_header(opts)
    print_rows(hosts.profile_rows([name]), opts)
    return 0


def set_status(hosts, names, status, only=False, all_profiles=False):
    changed = []
    target = set(names)
    for p in hosts.profiles:
        if all_profiles or p["name"] in target:
            p["status"] = status
            changed.append(p["name"])
        elif only:
            p["status"] = "off" if status == "on" else "on"
    return changed


def cmd_enable_disable(hosts, args, opts, status):
    all_profiles = "--all" in args
    only = "--only" in args
    names = [a for a in args if not a.startswith("-") and a not in ("--all", "--only")]
    if not names and not all_profiles:
        err("missing profile name")
        return 1
    changed = set_status(hosts, names, status, only, all_profiles)
    if not changed and names:
        maybe_header(opts)
        err("unknown profile name")
        return 1
    hosts.save()
    maybe_header(opts)
    print_rows(hosts.profile_rows(names if names else None, status=status if not all_profiles else None), opts)
    return 0


def cmd_toggle(hosts, args, opts):
    names = [a for a in args if not a.startswith("-")]
    if not names:
        err("missing profile name")
        return 1
    rows = []
    for name in names:
        p = hosts.get(name)
        if not p:
            maybe_header(opts)
            err("unknown profile name")
            return 1
        p["status"] = "off" if p["status"] == "on" else "on"
        rows.extend((p["name"], p["status"], ip, host) for ip, host in p["rows"])
    hosts.save()
    maybe_header(opts)
    print_rows(rows, opts)
    return 0


def cmd_list(hosts, args, opts):
    status = None
    include_default = True
    names = []
    if args and args[0] in ("enabled", "on"):
        status = "on"
        include_default = True
    elif args and args[0] in ("disabled", "off"):
        status = "off"
        include_default = True
    else:
        names = [a for a in args if not a.startswith("-")]
        include_default = not names
    maybe_header(opts)
    print_rows(hosts.profile_rows(names, status, include_default), opts)
    return 0


def cmd_status(hosts, args, opts):
    names = [a for a in args if not a.startswith("-")]
    rows = []
    for p in hosts.profiles:
        if names and p["name"] not in names:
            continue
        rows.append((p["name"], p["status"], "", ""))
    if names and not rows:
        maybe_header(opts)
        err("missing profile name")
        return 1
    maybe_header(opts)
    print_rows(rows, opts, status_only=True)
    return 0


def cmd_remove(hosts, args, opts):
    if args and args[0] in ("domains", "domain"):
        if len(args) < 3:
            err("missing profile name")
            return 1
        name, domains = args[1], set(args[2:])
        p = hosts.get(name)
        if not p:
            maybe_header(opts)
            err("unknown profile name")
            return 1
        p["rows"] = [r for r in p["rows"] if r[1] not in domains]
        if not p["rows"]:
            hosts.remove_profile(name)
            hosts.save()
            maybe_header(opts)
            if not opts["quiet"]:
                ok(f"Profile '{name}' removed.")
            return 0
        hosts.save()
        maybe_header(opts)
        print_rows(hosts.profile_rows([name]), opts)
        return 0
    all_profiles = "--all" in args
    names = [a for a in args if not a.startswith("-")]
    if not names and not all_profiles:
        err("missing profile name")
        return 1
    if all_profiles:
        hosts.profiles = []
        hosts.save()
        return 0
    removed = False
    for name in names:
        removed = hosts.remove_profile(name) or removed
    hosts.save()
    maybe_header(opts)
    if removed:
        for name in names:
            if not opts["quiet"]:
                ok(f"Profile '{name}' removed.")
    else:
        err("unknown profile name")
        return 1
    return 0


def cmd_backup(opts, args):
    path = "/workspace"
    if "--path" in args:
        path = args[args.index("--path") + 1]
    dest = os.path.join(path, os.path.basename(opts["host_file"]) + "." + datetime.date.today().strftime("%Y%m%d"))
    shutil.copyfile(opts["host_file"], dest)
    maybe_header(opts)
    if not opts["quiet"]:
        ok(f"Backup '{dest}' created.")
    return 0


def cmd_restore(opts, args):
    src = args[args.index("--from") + 1] if "--from" in args else None
    if not src:
        err("missing file to restore")
        return 1
    shutil.copyfile(src, opts["host_file"])
    maybe_header(opts)
    if not opts["quiet"]:
        ok(f"File '{src}' restored.")
    return 0


def main(argv):
    if not argv or argv[0] in ("-h", "--help", "help"):
        usage()
        return 0
    if argv[0] in ("-v", "--version"):
        print("hostctl version dev")
        return 0
    opts, args = parse_global(argv)
    if not args:
        usage()
        return 0
    cmd, rest = args[0], args[1:]
    if "--help" in rest or "-h" in rest:
        usage()
        return 0
    try:
        if cmd == "backup":
            return cmd_backup(opts, rest)
        if cmd == "restore":
            return cmd_restore(opts, rest)
        hosts = Hosts(opts["host_file"])
        if cmd == "add":
            return cmd_add(hosts, rest, opts)
        if cmd == "replace":
            return cmd_replace(hosts, rest, opts)
        if cmd == "enable":
            return cmd_enable_disable(hosts, rest, opts, "on")
        if cmd == "disable":
            return cmd_enable_disable(hosts, rest, opts, "off")
        if cmd == "toggle":
            return cmd_toggle(hosts, rest, opts)
        if cmd == "list":
            return cmd_list(hosts, rest, opts)
        if cmd == "status":
            return cmd_status(hosts, rest, opts)
        if cmd == "remove":
            return cmd_remove(hosts, rest, opts)
        if cmd == "sync":
            maybe_header(opts)
            err("docker sync is not available")
            return 1
        err(f'unknown command "{cmd}" for "hostctl"')
        return 1
    except (IndexError, TypeError):
        err("missing required flag value")
        return 1
    except OSError as e:
        err(str(e))
        return 1


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
