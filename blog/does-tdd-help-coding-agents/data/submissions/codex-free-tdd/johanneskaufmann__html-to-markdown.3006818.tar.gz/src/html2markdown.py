#!/usr/bin/env python3
import argparse
import glob
import os
import re
import sys
from html.parser import HTMLParser
from pathlib import Path
from urllib.parse import urljoin


BLOCK_TAGS = {
    "address", "article", "aside", "blockquote", "body", "dd", "div", "dl",
    "dt", "fieldset", "figcaption", "figure", "footer", "form", "h1", "h2",
    "h3", "h4", "h5", "h6", "header", "hr", "html", "li", "main", "nav",
    "ol", "p", "pre", "section", "table", "tbody", "td", "tfoot", "th",
    "thead", "tr", "ul",
}


class Node:
    def __init__(self, tag=None, attrs=None, data=None):
        self.tag = tag
        self.attrs = dict(attrs or [])
        self.data = data
        self.children = []


class Parser(HTMLParser):
    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.root = Node("root")
        self.stack = [self.root]
        self.skip = 0

    def handle_starttag(self, tag, attrs):
        tag = tag.lower()
        node = Node(tag, attrs)
        self.stack[-1].children.append(node)
        if tag in ("script", "style"):
            self.skip += 1
        if tag not in ("br", "hr", "img", "input", "meta", "link"):
            self.stack.append(node)

    def handle_endtag(self, tag):
        tag = tag.lower()
        if tag in ("script", "style") and self.skip:
            self.skip -= 1
        for i in range(len(self.stack) - 1, 0, -1):
            if self.stack[i].tag == tag:
                del self.stack[i:]
                break

    def handle_data(self, data):
        if not self.skip:
            self.stack[-1].children.append(Node(data=data))


def parse_bool(value):
    if value is None:
        return True
    return str(value).lower() not in ("false", "0", "no")


class Renderer:
    def __init__(self, opts):
        self.opts = opts

    def render(self, root):
        root = self.apply_selectors(root)
        text = self.render_children(root, block=True)
        return self.finish(text)

    def finish(self, text):
        text = re.sub(r"\n{3,}", "\n\n", text)
        return text.strip() + "\n" if text.strip() else ""

    def apply_selectors(self, root):
        if self.opts.include_selector:
            selected = Node("root")
            for n in walk(root):
                if n is not root and matches(n, self.opts.include_selector):
                    selected.children.extend(clone(c) for c in n.children)
            root = selected
        if self.opts.exclude_selector:
            root = clone_without(root, self.opts.exclude_selector)
        return root

    def render_children(self, node, block=False):
        parts = [self.render_node(c) for c in node.children]
        if block:
            return "".join(parts)
        return normalize_inline("".join(parts))

    def render_node(self, node):
        if node.data is not None:
            return self.escape_text(node.data)
        tag = node.tag
        if tag in ("script", "style"):
            return ""
        if tag in ("h1", "h2", "h3", "h4", "h5", "h6"):
            level = int(tag[1])
            return "\n\n" + "#" * level + " " + self.render_children(node).strip() + "\n\n"
        if tag in ("p", "div", "section", "article", "header", "footer", "main", "nav", "dd", "dt"):
            body = self.render_children(node).strip()
            return ("\n\n" + body + "\n\n") if body else ""
        if tag in ("strong", "b"):
            d = self.opts.opt_strong_delimiter
            return d + self.render_children(node).strip() + d
        if tag in ("em", "i"):
            return "*" + self.render_children(node).strip() + "*"
        if tag == "code":
            return "`" + raw_text(node).replace("`", "\\`").strip() + "`"
        if tag == "pre":
            txt = raw_text(node).strip("\n")
            return "\n\n```\n" + txt + "\n```\n\n"
        if tag == "a":
            label = self.render_children(node).strip()
            href = absolutize(node.attrs.get("href", ""), self.opts.domain)
            title = node.attrs.get("title")
            dest = href + (f' "{title}"' if title else "")
            return f"[{label}]({dest})"
        if tag == "img":
            alt = self.escape_text(node.attrs.get("alt", ""))
            src = absolutize(node.attrs.get("src", ""), self.opts.domain)
            title = node.attrs.get("title")
            dest = src + (f' "{title}"' if title else "")
            return f"![{alt}]({dest})"
        if tag == "br":
            return "  \n"
        if tag == "hr":
            return "\n\n* * *\n\n"
        if tag == "blockquote":
            inner = self.finish(self.render_children(node, block=True)).rstrip("\n")
            quoted = "\n".join("> " + line if line else ">" for line in inner.splitlines())
            return "\n\n" + quoted + "\n\n"
        if tag in ("ul", "ol"):
            return self.render_list(node, ordered=(tag == "ol"))
        if tag == "li":
            return self.render_children(node, block=True)
        if tag in ("del", "s", "strike"):
            inner = self.render_children(node).strip()
            return f"~~{inner}~~" if self.opts.plugin_strikethrough else inner
        if tag == "table" and self.opts.plugin_table:
            return "\n\n" + self.render_table(node) + "\n\n"
        return self.render_children(node, block=(tag in BLOCK_TAGS))

    def render_list(self, node, ordered=False):
        out = []
        idx = 1
        has_nested = False
        for child in node.children:
            if child.tag != "li":
                continue
            has_nested = has_nested or any(c.tag in ("ul", "ol") for c in child.children)
            content = self.render_children(child, block=True).strip()
            lines = content.splitlines() or [""]
            marker = f"{idx}. " if ordered else "- "
            out.append(marker + lines[0])
            for line in lines[1:]:
                indent = "   " if ordered else "  "
                out.append(indent + line if line else indent.rstrip(" ") if ordered else indent)
            idx += 1
        tail = "\n\n<!--THE END-->\n\n" if has_nested else "\n\n"
        return "\n\n" + "\n".join(out) + tail

    def render_table(self, table):
        rows = []
        for tr in find_tags(table, "tr"):
            row = []
            for cell in [c for c in tr.children if c.tag in ("td", "th")]:
                text = self.render_children(cell).strip().replace("\n", " ")
                span = int(cell.attrs.get("colspan", "1") or "1")
                row.append(text)
                if self.opts.opt_table_span_cell_behavior == "mirror":
                    row.extend([text] * (span - 1))
                else:
                    row.extend([""] * (span - 1))
            if row or not parse_bool(self.opts.opt_table_skip_empty_rows):
                rows.append(row)
        if not rows:
            return ""
        width = max(len(r) for r in rows)
        rows = [r + [""] * (width - len(r)) for r in rows]
        has_th = any(c.tag == "th" for tr in find_tags(table, "tr")[:1] for c in tr.children)
        promote = parse_bool(self.opts.opt_table_header_promotion)
        if has_th or promote:
            header, body = rows[0], rows[1:]
        else:
            header, body = ["" for _ in range(width)], rows
        if self.opts.opt_table_cell_padding_behavior == "none":
            return self.format_table_none(header, body)
        if self.opts.opt_table_cell_padding_behavior == "minimal":
            return self.format_table_minimal(header, body)
        return self.format_table_aligned(header, body)

    def format_table_none(self, header, body):
        lines = ["|" + "|".join(header) + "|", "|" + "|".join(["---"] * len(header)) + "|"]
        lines += ["|" + "|".join(r) + "|" for r in body]
        return "\n".join(lines)

    def format_table_minimal(self, header, body):
        def row(r): return "| " + " | ".join(r) + " |"
        sep = "|" + "|".join(["---"] * len(header)) + "|"
        return "\n".join([row(header), sep] + [row(r) for r in body])

    def format_table_aligned(self, header, body):
        rows = [header] + body
        widths = [max(1, *(len(r[i]) for r in rows)) for i in range(len(header))]
        def row(r):
            return "| " + " | ".join(r[i].ljust(widths[i]) for i in range(len(r))) + " |"
        sep = "|" + "|".join("-" * (w + 2) for w in widths) + "|"
        return "\n".join([row(header), sep] + [row(r) for r in body])

    def escape_text(self, text):
        text = text.replace("\r\n", "\n")
        text = re.sub(r"[ \t\n\f\v]+", " ", text)
        text = text.replace("\\", "\\\\")
        text = text.replace("<", "&lt;").replace(">", "&gt;")
        text = text.replace("*", "\\*").replace("_", "\\_")
        text = re.sub(r"\\\*\\\*(?=($|\s|[.,;:!?]))", r"\\**", text)
        text = text.replace("[", "\\[").replace("]", "\\]")
        text = re.sub(r"(^|\n)([ \t]*)([#>-])", lambda m: m.group(1) + m.group(2) + "\\" + m.group(3), text)
        return text


def normalize_inline(text):
    text = re.sub(r"[ \t\n\f\v]+", " ", text)
    text = re.sub(r" *\n *", "\n", text)
    return text


def raw_text(node):
    if node.data is not None:
        return node.data
    return "".join(raw_text(c) for c in node.children)


def find_tags(node, tag):
    found = []
    for c in node.children:
        if c.tag == tag:
            found.append(c)
        found.extend(find_tags(c, tag))
    return found


def walk(node):
    yield node
    for c in node.children:
        yield from walk(c)


def clone(node):
    n = Node(node.tag, node.attrs, node.data)
    n.children = [clone(c) for c in node.children]
    return n


def clone_without(node, selector):
    if matches(node, selector):
        return Node("root")
    n = Node(node.tag, node.attrs, node.data)
    for c in node.children:
        if c.data is not None:
            n.children.append(clone(c))
        elif not matches(c, selector):
            n.children.append(clone_without(c, selector))
    return n


def matches(node, selector):
    if node.data is not None:
        return False
    selector = selector.strip()
    if selector.startswith("."):
        classes = node.attrs.get("class", "").split()
        return selector[1:] in classes
    if selector.startswith("#"):
        return node.attrs.get("id") == selector[1:]
    return node.tag == selector.lower()


def absolutize(url, domain):
    if not domain or not url:
        return url
    return urljoin(domain, url)


def convert(html, opts):
    parser = Parser()
    parser.feed(html)
    parser.close()
    return Renderer(opts).render(parser.root)


def build_arg_parser():
    p = argparse.ArgumentParser(add_help=False)
    p.add_argument("--help", action="store_true")
    p.add_argument("-v", "--version", action="store_true")
    p.add_argument("--input")
    p.add_argument("--output")
    p.add_argument("--output-overwrite", action="store_true")
    p.add_argument("--domain")
    p.add_argument("--exclude-selector")
    p.add_argument("--include-selector")
    p.add_argument("--opt-strong-delimiter", default="**")
    p.add_argument("--opt-table-cell-padding-behavior", default="aligned")
    p.add_argument("--opt-table-header-promotion", nargs="?", const="true", default="true")
    p.add_argument("--opt-table-newline-behavior", default="skip")
    p.add_argument("--opt-table-presentation-tables", nargs="?", const="true", default="false")
    p.add_argument("--opt-table-skip-empty-rows", nargs="?", const="true", default="false")
    p.add_argument("--opt-table-span-cell-behavior", default="empty")
    p.add_argument("--plugin-strikethrough", action="store_true")
    p.add_argument("--plugin-table", action="store_true")
    return p


HELP = """
# html2markdown - convert html to markdown [version dev]

Convert HTML to Markdown. Even works with entire websites!

## Basics

By default the "Commonmark" Plugin will be enabled. You can customize the options,
for example changing the appearance of bold with --opt-strong-delimiter="__"

Other Plugins can also be enabled. For example "GitHub Flavored Markdown" (GFM)
extends Commonmark with more features.

## Relative / Absolute Links

Use --domain="https://example.com" to convert *relative* links to *absolute* links.
The same also works for images.

## Escaping

Some characters have a special meaning in markdown. The library escapes these — if necessary.
See the documentation for more info.

## Security

Once you convert this markdown *back* to HTML you need to be careful of malicious content. 
Use a HTML sanitizer before displaying the HTML in the browser!


## Examples

    echo "<strong>important</strong>" | html2markdown

    curl --no-progress-meter http://example.com | html2markdown


    html2markdown --input file.html --output file.md

    html2markdown --input "src/*.html" --output "dist/"


## Flags

    -v, --version
        show the version of html2markdown and exit

    --help

    --input PATH
        Input file, directory, or glob pattern (instead of stdin)

    --output PATH
        Output file or directory (instead of stdout)

    --output-overwrite
        Replace existing files

    If --input is a directory or glob pattern, --output must be a directory.



    --domain
        The url of the web page, used to convert relative links to absolute links.

    --exclude-selector
        css query selector to exclude parts of the input

    --include-selector
        css query selector to only include parts of the input

    --opt-strong-delimiter
        Make bold text. Should <strong> be indicated by two asterisks or two underscores?
        "**" or "__" (default: "**")

    --opt-table-cell-padding-behavior
        [for --plugin-table] whether cells in the tables should include extra padding for visual continuity: "aligned", "minimal", or "none"

    --opt-table-header-promotion
        [for --plugin-table] first row should be treated as a header

    --opt-table-newline-behavior
        [for --plugin-table] how tables containing newlines should be handled: "skip" or "preserve"

    --opt-table-presentation-tables
        [for --plugin-table] whether tables with role="presentation" should be converted

    --opt-table-skip-empty-rows
        [for --plugin-table] omit empty rows from the output

    --opt-table-span-cell-behavior
        [for --plugin-table] how colspan/rowspan should be rendered: "empty" or "mirror"

    --plugin-strikethrough
        enable the plugin ~~strikethrough~~

    --plugin-table
        enable the plugin table



For more information visit the documentation:
https://github.com/Johanneskaufmann/html-to-markdown

"""


VERSION = """html2markdown

GitVersion:  dev
GitCommit:   none
BuildDate:   unknown
"""


def main(argv=None):
    argv = argv if argv is not None else sys.argv[1:]
    parser = build_arg_parser()
    try:
        opts, rest = parser.parse_known_args(argv)
    except SystemExit:
        return 1
    if rest:
        sys.stderr.write(f"\nerror: unknown flag: {rest[0]}\n\n")
        return 1
    if opts.help:
        sys.stdout.write(HELP)
        return 0
    if opts.version:
        sys.stdout.write(VERSION)
        return 0

    if opts.input:
        paths = []
        if any(ch in opts.input for ch in "*?["):
            paths = sorted(glob.glob(opts.input))
        elif os.path.isdir(opts.input):
            sys.stderr.write(
                f'\nerror: input path "{opts.input}" is a directory, not a file\n\n'
                "Here is how you can use a glob to match multiple files:\n\n"
                '    html2markdown --input "src/*.html" --output "dist/"\n\n'
            )
            return 1
        elif os.path.exists(opts.input):
            paths = [opts.input]
        if not paths:
            sys.stderr.write(
                f'\nerror: no files found matching pattern "{opts.input}"\n\n'
                "Here is how you can use a glob to match multiple files:\n\n"
                '    html2markdown --input "src/*.html" --output "dist/"\n\n'
            )
            return 1
        if len(paths) > 1:
            if not opts.output:
                sys.stderr.write(
                    "\nerror: when processing multiple input files --output needs to be a directory\n\n"
                    "Here is how you can use a glob to match multiple files:\n\n"
                    '    html2markdown --input "src/*.html" --output "dist/"\n\n'
                )
                return 1
            if not opts.output.endswith(("/", os.sep)):
                sys.stderr.write(
                    f'\nerror: when processing multiple input files, --output "{Path(opts.output).name}" '
                    f'must end with "{Path(opts.output).name}/" to indicate a directory\n\n'
                )
                return 1
        outputs = [(p, convert(Path(p).read_text(), opts)) for p in paths if os.path.isfile(p)]
        if opts.output:
            out_path = Path(opts.output)
            if len(outputs) > 1 or os.path.isdir(opts.output):
                out_path.mkdir(parents=True, exist_ok=True)
                for src, md in outputs:
                    target = out_path / (Path(src).stem + ".md")
                    if target.exists() and not opts.output_overwrite:
                        sys.stderr.write(
                            f'\nerror: output path "{target}" already exists. '
                            "Use --output-overwrite to replace existing files\n\n"
                        )
                        return 1
                    target.write_text(md.rstrip("\n"))
            else:
                if out_path.exists() and not opts.output_overwrite:
                    sys.stderr.write(
                        f'\nerror: output path "{out_path}" already exists. '
                        "Use --output-overwrite to replace existing files\n\n"
                    )
                    return 1
                out_path.write_text(outputs[0][1].rstrip("\n"))
        else:
            sys.stdout.write("".join(md for _, md in outputs))
        return 0

    html = sys.stdin.read()
    md = convert(html, opts)
    if opts.output:
        out_path = Path(opts.output)
        if out_path.exists() and not opts.output_overwrite:
            sys.stderr.write(
                f'\nerror: output path "{out_path}" already exists. '
                "Use --output-overwrite to replace existing files\n\n"
            )
            return 1
        out_path.write_text(md.rstrip("\n"))
    else:
        sys.stdout.write(md)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
