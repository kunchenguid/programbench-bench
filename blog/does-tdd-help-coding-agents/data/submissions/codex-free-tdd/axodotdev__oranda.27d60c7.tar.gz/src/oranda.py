#!/usr/bin/env python3
import html
import json
import os
import re
import sys
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path


VERSION = "oranda 0.6.5"


TOP_HELP_LONG = """🎁 generate beautiful landing pages for your projects

Usage: executable [OPTIONS] <COMMAND>

Commands:
  build     Build an oranda site
  dev       Start a local development server that recompiles your oranda site if a file changes
  serve     Start a file server to access your oranda site in a browser
  generate  Generate infrastructure files for oranda sites
  help      Print this message or the help of the given subcommand(s)

Options:
  -h, --help
          Print help (see a summary with '-h')

  -V, --version
          Print version

GLOBAL OPTIONS:
  -v, --verbose
          Whether to output more detailed debug information

      --output-format <OUTPUT_FORMAT>
          The format of the output
          
          [default: human]

          Possible values:
          - human: Human-readable output
          - json:  Machine-readable JSON output
"""

TOP_HELP_SHORT = """🎁 generate beautiful landing pages for your projects

Usage: executable [OPTIONS] <COMMAND>

Commands:
  build     Build an oranda site
  dev       Start a local development server that recompiles your oranda site if a file changes
  serve     Start a file server to access your oranda site in a browser
  generate  Generate infrastructure files for oranda sites
  help      Print this message or the help of the given subcommand(s)

Options:
  -h, --help     Print help (see more with '--help')
  -V, --version  Print version

GLOBAL OPTIONS:
  -v, --verbose                        Whether to output more detailed debug information
      --output-format <OUTPUT_FORMAT>  The format of the output [default: human] [possible values:
                                       human, json]
"""

BUILD_HELP = """Build an oranda site

Usage: executable build [OPTIONS]

Options:
      --json-only
          Only build the artifacts JSON file (if applicable) and other files that may be used to
          support it, such as installer source files

  -h, --help
          Print help (see a summary with '-h')

GLOBAL OPTIONS:
  -v, --verbose
          Whether to output more detailed debug information

      --output-format <OUTPUT_FORMAT>
          The format of the output
          
          [default: human]

          Possible values:
          - human: Human-readable output
          - json:  Machine-readable JSON output
"""

DEV_HELP = """Start a local development server that recompiles your oranda site if a file changes

Usage: executable dev [OPTIONS]

Options:
      --port <PORT>
          The port for the file server to be launched on

      --no-first-build
          Skip the first build before starting to watch for changes

  -i, --include-paths <INCLUDE_PATHS>
          List of extra paths to watch

  -h, --help
          Print help (see a summary with '-h')

GLOBAL OPTIONS:
  -v, --verbose
          Whether to output more detailed debug information

      --output-format <OUTPUT_FORMAT>
          The format of the output
          
          [default: human]

          Possible values:
          - human: Human-readable output
          - json:  Machine-readable JSON output
"""

SERVE_HELP = """Start a file server to access your oranda site in a browser

Usage: executable serve [OPTIONS]

Options:
      --port <PORT>
          [default: 7979]

  -h, --help
          Print help (see a summary with '-h')

GLOBAL OPTIONS:
  -v, --verbose
          Whether to output more detailed debug information

      --output-format <OUTPUT_FORMAT>
          The format of the output
          
          [default: human]

          Possible values:
          - human: Human-readable output
          - json:  Machine-readable JSON output
"""

GENERATE_HELP = """Generate infrastructure files for oranda sites

Usage: executable generate [OPTIONS] <COMMAND>

Commands:
  ci    Generates a CI file that can be used to deploy your site
  help  Print this message or the help of the given subcommand(s)

Options:
  -o, --output-path <OUTPUT_PATH>
          Path to the output file

  -s, --site-path <SITE_PATH>
          Path to your oranda site

  -h, --help
          Print help (see a summary with '-h')

GLOBAL OPTIONS:
  -v, --verbose
          Whether to output more detailed debug information

      --output-format <OUTPUT_FORMAT>
          The format of the output
          
          [default: human]

          Possible values:
          - human: Human-readable output
          - json:  Machine-readable JSON output
"""

CI_HELP = """Generates a CI file that can be used to deploy your site

Usage: executable generate ci [OPTIONS]

Options:
      --ci <CI>
          What CI to generate a file for
          
          [default: github]

          Possible values:
          - github: Deploy to GitHub Pages using GitHub Actions

  -o, --output-path <OUTPUT_PATH>
          Path to the output file

  -s, --site-path <SITE_PATH>
          Path to your oranda site

  -h, --help
          Print help (see a summary with '-h')

GLOBAL OPTIONS:
  -v, --verbose
          Whether to output more detailed debug information

      --output-format <OUTPUT_FORMAT>
          The format of the output
          
          [default: human]

          Possible values:
          - human: Human-readable output
          - json:  Machine-readable JSON output
"""


def eprint(text):
    sys.stderr.write(text)


def fail(message, usage=None):
    eprint(f"error: {message}\n")
    if usage:
        eprint(f"\n{usage}\n")
    eprint("\nFor more information, try '--help'.\n")
    return 2


def split_global(args):
    output_format = "human"
    verbose = False
    rest = []
    i = 0
    while i < len(args):
        arg = args[i]
        if arg == "--output-format":
            if i + 1 >= len(args):
                return None, None, None, fail("a value is required for '--output-format <OUTPUT_FORMAT>' but none was supplied")
            output_format = args[i + 1]
            if output_format not in ("human", "json"):
                return None, None, None, fail(f"invalid value '{output_format}' for '--output-format <OUTPUT_FORMAT>'\n  [possible values: human, json]")
            i += 2
        elif arg == "-v" or arg == "--verbose":
            verbose = True
            i += 1
        else:
            rest.extend(args[i:])
            break
    return output_format, verbose, rest, None


def read_project():
    title = None
    body_lines = []
    readme = Path("README.md")
    if readme.exists():
        for line in readme.read_text(errors="replace").splitlines():
            if title is None:
                match = re.match(r"^#\s+(.+?)\s*$", line)
                if match:
                    title = match.group(1)
                    continue
            body_lines.append(line)
    if not title:
        title = Path.cwd().name or "oranda"
    description = "\n".join(body_lines).strip()

    config = Path("oranda.json")
    if config.exists():
        try:
            data = json.loads(config.read_text())
            title = str(data.get("name") or data.get("title") or title)
            description = str(data.get("description") or description)
        except Exception:
            pass
    return title, description


def markdown_to_html(text):
    blocks = []
    para = []
    for raw in text.splitlines():
        line = raw.rstrip()
        if not line:
            if para:
                blocks.append(f"<p>{html.escape(' '.join(para))}</p>")
                para = []
            continue
        if line.startswith("## "):
            if para:
                blocks.append(f"<p>{html.escape(' '.join(para))}</p>")
                para = []
            blocks.append(f"<h2>{html.escape(line[3:].strip())}</h2>")
        elif line.startswith("# "):
            continue
        else:
            para.append(line)
    if para:
        blocks.append(f"<p>{html.escape(' '.join(para))}</p>")
    return "\n".join(blocks)


def build_site(json_only=False):
    if json_only:
        print("✓ >o_o< SUCCESS: Your site build is located in `public`.")
        return 0

    title, description = read_project()
    public = Path("public")
    public.mkdir(exist_ok=True)
    (public / "oranda.css").write_text(
        "body{margin:0;font-family:system-ui,-apple-system,Segoe UI,sans-serif;background:#f8fafc;color:#111827}"
        "main{max-width:860px;margin:0 auto;padding:64px 24px}h1{font-size:3rem;margin:0 0 1rem}p{line-height:1.6}"
    )
    content = markdown_to_html(description)
    html_doc = f"""<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>{html.escape(title)}</title>
  <link rel="stylesheet" href="oranda.css">
</head>
<body>
  <main>
    <h1>{html.escape(title)}</h1>
    {content}
  </main>
</body>
</html>
"""
    (public / "index.html").write_text(html_doc)
    print("✓ >o_o< SUCCESS: Your site build is located in `public`.")
    return 0


def generate_ci(args):
    if "-h" in args or "--help" in args:
        print(CI_HELP, end="")
        return 0
    print("↪ >o_o< INFO: Generating a CI deploy workflow for your site...")
    eprint("  × oranda panicked.\n")
    eprint("  ├─▶ at src/generate.rs:56:14\n")
    eprint("  ╰─▶ Error while prompting!: NotTTY\n")
    eprint("  help: set the `RUST_BACKTRACE=1` environment variable to display a backtrace.\n")
    return 255


def serve(port):
    directory = "public" if Path("public").is_dir() else "."

    class Handler(SimpleHTTPRequestHandler):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, directory=directory, **kwargs)

    server = ThreadingHTTPServer(("", port), Handler)
    print(f"↪ >o_o< INFO: Serving `{directory}` on http://127.0.0.1:{port}")
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        return 0


def parse_port(args, default):
    port = default
    i = 0
    while i < len(args):
        if args[i] == "--port":
            if i + 1 >= len(args):
                return None, fail("a value is required for '--port <PORT>' but none was supplied")
            try:
                port = int(args[i + 1])
            except ValueError:
                return None, fail(f"invalid value '{args[i + 1]}' for '--port <PORT>'")
            i += 2
        elif args[i] in ("-h", "--help"):
            i += 1
        else:
            i += 1
    return port, None


def main(argv):
    output_format, _verbose, args, parse_error = split_global(argv)
    if parse_error is not None:
        return parse_error

    if not args:
        eprint(TOP_HELP_SHORT)
        return 2
    if args[0] in ("--version", "-V"):
        print(VERSION)
        return 0
    if args[0] == "--help":
        print(TOP_HELP_LONG, end="")
        return 0
    if args[0] == "-h":
        print(TOP_HELP_SHORT, end="")
        return 0
    if args[0] == "help":
        if len(args) == 1:
            print(TOP_HELP_LONG, end="")
        elif args[1] == "build":
            print(BUILD_HELP, end="")
        elif args[1] == "dev":
            print(DEV_HELP, end="")
        elif args[1] == "serve":
            print(SERVE_HELP, end="")
        elif args[1] == "generate" and len(args) > 2 and args[2] == "ci":
            print(CI_HELP, end="")
        elif args[1] == "generate":
            print(GENERATE_HELP, end="")
        else:
            return fail(f"unrecognized subcommand '{args[1]}'", "Usage: executable [OPTIONS] <COMMAND>")
        return 0

    cmd = args[0]
    rest = args[1:]
    if cmd == "build":
        if "-h" in rest or "--help" in rest:
            print(BUILD_HELP, end="")
            return 0
        allowed = {"--json-only"}
        for arg in rest:
            if arg not in allowed and arg not in ("-v", "--verbose", "--output-format", "human", "json"):
                return fail(f"unexpected argument '{arg}' found", "Usage: executable build [OPTIONS]")
        return build_site("--json-only" in rest)
    if cmd == "dev":
        if "-h" in rest or "--help" in rest:
            print(DEV_HELP, end="")
            return 0
        if "--no-first-build" not in rest:
            code = build_site(False)
            if code:
                return code
        port, err = parse_port(rest, 7979)
        if err is not None:
            return err
        return serve(port)
    if cmd == "serve":
        if "-h" in rest or "--help" in rest:
            print(SERVE_HELP, end="")
            return 0
        port, err = parse_port(rest, 7979)
        if err is not None:
            return err
        return serve(port)
    if cmd == "generate":
        if not rest or rest[0] in ("-h", "--help"):
            print(GENERATE_HELP, end="")
            return 0
        if rest[0] == "help":
            if len(rest) > 1 and rest[1] == "ci":
                print(CI_HELP, end="")
            else:
                print(GENERATE_HELP, end="")
            return 0
        if rest[0] == "ci":
            return generate_ci(rest[1:])
        return fail(f"unrecognized subcommand '{rest[0]}'", "Usage: executable generate [OPTIONS] <COMMAND>")

    return fail(f"unrecognized subcommand '{cmd}'", "Usage: executable [OPTIONS] <COMMAND>")


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
