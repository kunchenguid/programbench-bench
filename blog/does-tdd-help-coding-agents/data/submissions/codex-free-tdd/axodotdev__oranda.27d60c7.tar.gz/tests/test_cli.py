import os
import shutil
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
EXE = ROOT / "executable"


def run_cmd(args, cwd=None):
    return subprocess.run(
        [str(EXE), *args],
        cwd=cwd,
        text=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
    )


class CliTests(unittest.TestCase):
    def setUp(self):
        self.tmp = Path(tempfile.mkdtemp())

    def tearDown(self):
        shutil.rmtree(self.tmp)

    def test_version_matches_documented_binary(self):
        result = run_cmd(["--version"])
        self.assertEqual(result.returncode, 0)
        self.assertEqual(result.stdout, "oranda 0.6.5\n")
        self.assertEqual(result.stderr, "")

    def test_top_level_help_contains_commands_and_global_options(self):
        result = run_cmd(["--help"])
        self.assertEqual(result.returncode, 0)
        self.assertIn("🎁 generate beautiful landing pages for your projects", result.stdout)
        self.assertIn("Usage: executable [OPTIONS] <COMMAND>", result.stdout)
        self.assertIn("build     Build an oranda site", result.stdout)
        self.assertIn("--output-format <OUTPUT_FORMAT>", result.stdout)

    def test_unknown_subcommand_uses_clap_style_error(self):
        result = run_cmd(["nope"])
        self.assertEqual(result.returncode, 2)
        self.assertEqual(result.stdout, "")
        self.assertIn("error: unrecognized subcommand 'nope'", result.stderr)
        self.assertIn("Usage: executable [OPTIONS] <COMMAND>", result.stderr)

    def test_json_only_build_reports_success_without_emitting_site(self):
        (self.tmp / "README.md").write_text("# My Project\n\nA tiny test project.\n")
        result = run_cmd(["build", "--json-only"], cwd=self.tmp)
        self.assertEqual(result.returncode, 0)
        self.assertEqual(result.stdout, "✓ >o_o< SUCCESS: Your site build is located in `public`.\n")
        self.assertEqual(result.stderr, "")

    def test_build_creates_basic_static_site_from_readme(self):
        (self.tmp / "README.md").write_text("# My Project\n\nA tiny test project.\n")
        result = run_cmd(["build"], cwd=self.tmp)
        self.assertEqual(result.returncode, 0, result.stderr)
        html = (self.tmp / "public" / "index.html").read_text()
        self.assertIn("<title>My Project</title>", html)
        self.assertIn("<h1>My Project</h1>", html)
        self.assertIn("A tiny test project.", html)

    def test_generate_ci_panics_when_noninteractive(self):
        result = run_cmd(["generate", "ci", "--output-path", "ci.yml", "--site-path", "."], cwd=self.tmp)
        self.assertEqual(result.returncode, 255)
        self.assertIn("↪ >o_o< INFO: Generating a CI deploy workflow for your site...", result.stdout)
        self.assertIn("× oranda panicked.", result.stderr)
        self.assertFalse((self.tmp / "ci.yml").exists())


if __name__ == "__main__":
    unittest.main()
