import re
import shutil
import subprocess
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
BIN = ["python3", str(ROOT / "src" / "atlas_cli.py")]


def run(args, cwd=None):
    return subprocess.run(
        BIN + args,
        cwd=cwd or ROOT,
        text=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
    )


class AtlasCliTests(unittest.TestCase):
    def test_version_output_matches_observed_community_build(self):
        r = run(["version"])
        self.assertEqual(r.returncode, 0)
        self.assertEqual(r.stderr, "")
        self.assertEqual(
            r.stdout,
            "atlas unofficial version - development\n"
            "https://github.com/ariga/atlas/releases/latest\n"
            "To download an official version, visit: https://atlasgo.io/getting-started#installation\n",
        )


    def test_unknown_command_uses_atlas_error_footer(self):
        r = run(["nosuch"])
        self.assertEqual(r.returncode, 1)
        self.assertIn('Error: unknown command "nosuch" for "atlas"', r.stderr)
        self.assertIn("Run 'atlas --help' for usage.", r.stderr)
        self.assertIn("You're running the community build of Atlas", r.stderr)


    def test_migrate_new_creates_timestamped_sql_and_sum_file(self):
        with tempfile.TemporaryDirectory() as td:
            r = run(["migrate", "new", "add_users"], cwd=td)
            self.assertEqual(r.returncode, 0, r.stderr)
            self.assertEqual(r.stdout, "")
            files = sorted(Path(td, "migrations").iterdir())
            names = [p.name for p in files]
            self.assertIn("atlas.sum", names)
            sql = [n for n in names if re.match(r"^\d{14}_add_users\.sql$", n)]
            self.assertEqual(len(sql), 1)
            self.assertEqual(Path(td, "migrations", sql[0]).read_text(), "")
            sum_text = Path(td, "migrations", "atlas.sum").read_text()
            self.assertIn(sql[0], sum_text)
            self.assertTrue(sum_text.startswith("h1:"))


    def test_migrate_validate_detects_edited_file_after_hash(self):
        with tempfile.TemporaryDirectory() as td:
            mig = Path(td, "migrations")
            mig.mkdir()
            (mig / "20240101010101_a.sql").write_text("CREATE TABLE t(id int);\n")
            ok = run(["migrate", "hash"], cwd=td)
            self.assertEqual(ok.returncode, 0, ok.stderr)
            valid = run(["migrate", "validate"], cwd=td)
            self.assertEqual(valid.returncode, 0, valid.stderr)
            (mig / "20240101010101_a.sql").write_text("CREATE TABLE t(id int);\nx\n")
            bad = run(["migrate", "validate"], cwd=td)
            self.assertEqual(bad.returncode, 1)
            self.assertIn("You have a checksum error in your migration directory.", bad.stderr)
            self.assertIn("20240101010101_a.sql was edited", bad.stderr)
            self.assertIn("Error: checksum mismatch", bad.stderr)

    def test_migrate_hash_matches_reference_for_simple_directory(self):
        with tempfile.TemporaryDirectory() as td:
            mig = Path(td, "migrations")
            mig.mkdir()
            (mig / "20240101010101_a.sql").write_text("CREATE TABLE t(id int);\n")
            (mig / "20240102020202_b.sql").write_text("ALTER TABLE t ADD name text;\n")
            r = run(["migrate", "hash"], cwd=td)
            self.assertEqual(r.returncode, 0, r.stderr)
            self.assertEqual(
                (mig / "atlas.sum").read_text(),
                "h1:0XeOIdn/GFrR2U50rP33hNtPvA7vtUUwxvg4LJ3MfRE=\n"
                "20240101010101_a.sql h1:bOJLTdm3+MJOxnwh5caIGUZ6Je7DqCo2no4VX9R+kpA=\n"
                "20240102020202_b.sql h1:ajXnnXv2SfVnLBhKlh/+xGeNaRsQESSfhRpnLItPtZo=\n",
            )

    def test_schema_fmt_matches_shipped_fixture(self):
        with tempfile.TemporaryDirectory() as td:
            src = ROOT / "assets" / "unformatted.hcl"
            expected = (ROOT / "assets" / "formatted.hcl").read_text()
            target = Path(td, "schema.hcl")
            shutil.copyfile(src, target)
            r = run(["schema", "fmt", "schema.hcl"], cwd=td)
            self.assertEqual(r.returncode, 0, r.stderr)
            self.assertEqual(r.stdout, "schema.hcl\n")
            self.assertEqual(target.read_text(), expected)
