locals {
  common_dev = "sqlite://dev?mode=memory"
  env_name = atlas.env
}

env "local" {
  url = "sqlite://local.db"
  dev = local.common_dev
  env_field = local.env_name
}
