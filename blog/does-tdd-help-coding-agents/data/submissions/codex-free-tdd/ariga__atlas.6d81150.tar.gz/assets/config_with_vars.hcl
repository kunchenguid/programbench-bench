variable "db_name" {
  type = string
  default = "default.db"
}

variable "schema_name" {
  type = string
  default = "main"
}

env "test" {
  url = "sqlite://${var.db_name}"
  dev = "sqlite://dev?mode=memory"
  schemas = [var.schema_name]
}
