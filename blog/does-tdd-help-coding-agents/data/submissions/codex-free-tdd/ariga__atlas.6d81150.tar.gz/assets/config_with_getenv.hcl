env "test" {
  url = "sqlite://test.db"
  dev = "sqlite://dev?mode=memory"
  custom_value = getenv("ATLAS_TEST_VAR")
  empty_value = getenv("ATLAS_NONEXISTENT_VAR")
}
