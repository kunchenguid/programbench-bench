env "dev" {
  url = "sqlite://test.db"
  dev = "sqlite://dev?mode=memory"
  schemas = ["main"]
}

env "prod" {
  url = "sqlite://prod.db"
  dev = "sqlite://dev?mode=memory"
  schemas = ["main"]
}
