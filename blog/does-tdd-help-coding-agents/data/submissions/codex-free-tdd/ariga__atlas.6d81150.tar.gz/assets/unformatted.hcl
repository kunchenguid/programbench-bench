schema   "test"   {
  charset =    "utf8mb4"
  collate   = "utf8mb4_general_ci"
}

table   "users"   {
  schema = schema.test
  column   "id"   {
    type = int
    null = false
  }
  column   "name"   {
    type = varchar(255)
  }
  primary_key   {
    columns = [column.id]
  }
}

table   "posts"   {
  schema = schema.test
  column   "id"   {
    type = int
  }
  column   "user_id"   {
    type = int
  }
}
