env "bad" {
  url = "sqlite://test.db"
  invalid syntax here {{
}
