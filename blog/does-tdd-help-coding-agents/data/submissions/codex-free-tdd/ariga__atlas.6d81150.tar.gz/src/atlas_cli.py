#!/usr/bin/env python3
import base64
import hashlib
import os
import re
import sys
from datetime import datetime
from pathlib import Path


VERSION = (
    "atlas unofficial version - development\n"
    "https://github.com/ariga/atlas/releases/latest\n"
    "To download an official version, visit: https://atlasgo.io/getting-started#installation\n"
)

ERROR_FOOTER = """You're running the community build of Atlas, which may differ from the official version.
If this error persists, try installing the official version as a troubleshooting step:

  curl -sSf https://atlasgo.sh | sh

More installation options: https://atlasgo.io/docs#installation
"""

HELP = {
    (): """Manage your database schema as code

Usage:
  atlas [command]

Available Commands:
  completion  Generate the autocompletion script for the specified shell
  help        Help about any command
  license     Display license information
  migrate     Manage versioned migration files
  schema      Work with atlas schemas.
  version     Prints this Atlas CLI version information.

Flags:
  -h, --help   help for atlas

Use "atlas [command] --help" for more information about a command.
""",
    ("version",): """Prints this Atlas CLI version information.

Usage:
  atlas version [flags]

Flags:
  -h, --help   help for version
""",
    ("license",): """Display license information

Usage:
  atlas license [flags]

Flags:
  -h, --help   help for license
""",
    ("migrate",): """'atlas migrate' wraps several sub-commands for migration management.

Usage:
  atlas migrate [command]

Available Commands:
  apply       Applies pending migration files on the connected database.
  diff        Compute the diff between the migration directory and a desired state and create a new migration file.
  hash        Hash (re-)creates an integrity hash file for the migration directory.
  import      Import a migration directory from another migration management tool to the Atlas format.
  lint        Run analysis on the migration directory
  new         Creates a new empty migration file in the migration directory.
  set         Set the current version of the migration history table.
  status      Get information about the current migration status.
  validate    Validates the migration directories checksum and SQL statements.

Flags:
  -c, --config string        select config (project) file using URL format (default "file://atlas.hcl")
      --env string           set which env from the config file to use
  -h, --help                 help for migrate
      --var <name>=<value>   input variables (default [])

Use "atlas migrate [command] --help" for more information about a command.
""",
    ("schema",): """The `atlas schema` command groups subcommands working with declarative Atlas schemas.

Usage:
  atlas schema [command]

Available Commands:
  apply       Apply an atlas schema to a target database.
  clean       Removes all objects from the connected database.
  diff        Calculate and print the diff between two schemas.
  fmt         Formats Atlas HCL files
  inspect     Inspect a database and print its schema in Atlas DDL syntax.

Flags:
  -c, --config string        select config (project) file using URL format (default "file://atlas.hcl")
      --env string           set which env from the config file to use
  -h, --help                 help for schema
      --var <name>=<value>   input variables (default [])

Use "atlas schema [command] --help" for more information about a command.
""",
    ("completion",): """Generate the autocompletion script for atlas for the specified shell.
See each sub-command's help for details on how to use the generated script.

Usage:
  atlas completion [command]

Available Commands:
  bash        Generate the autocompletion script for bash
  fish        Generate the autocompletion script for fish
  powershell  Generate the autocompletion script for powershell
  zsh         Generate the autocompletion script for zsh

Flags:
  -h, --help   help for completion

Use "atlas completion [command] --help" for more information about a command.
""",
}

SUBCOMMAND_HELPS = {
    ("migrate", "new"): """'atlas migrate new' creates a new migration according to the configured formatter without any statements in it.

Usage:
  atlas migrate new [flags] [name]

Examples:
  atlas migrate new my-new-migration

Flags:
      --dir string          select migration directory using URL format (default "file://migrations")
      --dir-format string   select migration file format (default "atlas")
      --edit                edit the created migration file(s)
  -h, --help                help for new

Global Flags:
  -c, --config string        select config (project) file using URL format (default "file://atlas.hcl")
      --env string           set which env from the config file to use
      --var <name>=<value>   input variables (default [])
""",
    ("migrate", "hash"): """'atlas migrate hash' computes the integrity hash sum of the migration directory and stores it in the atlas.sum file.
This command should be used whenever a manual change in the migration directory was made.

Usage:
  atlas migrate hash [flags]

Examples:
  atlas migrate hash

Flags:
      --dir string          select migration directory using URL format (default "file://migrations")
      --dir-format string   select migration file format (default "atlas")
  -h, --help                help for hash

Global Flags:
  -c, --config string        select config (project) file using URL format (default "file://atlas.hcl")
      --env string           set which env from the config file to use
      --var <name>=<value>   input variables (default [])
""",
    ("migrate", "validate"): """'atlas migrate validate' computes the integrity hash sum of the migration directory and compares it to the
atlas.sum file. If there is a mismatch it will be reported. If the --dev-url flag is given, the migration
files are executed on the connected database in order to validate SQL semantics.

Usage:
  atlas migrate validate [flags]

Examples:
  atlas migrate validate
  atlas migrate validate --dir "file:///path/to/migration/directory"
  atlas migrate validate --dir "file:///path/to/migration/directory" --dev-url "docker://mysql/8/dev"
  atlas migrate validate --env dev --dev-url "docker://postgres/15/dev?search_path=public"

Flags:
      --dev-url string      [driver://username:password@address/dbname?param=value] select a dev database using the URL format
      --dir string          select migration directory using URL format (default "file://migrations")
      --dir-format string   select migration file format (default "atlas")
  -h, --help                help for validate

Global Flags:
  -c, --config string        select config (project) file using URL format (default "file://atlas.hcl")
      --env string           set which env from the config file to use
      --var <name>=<value>   input variables (default [])
""",
    ("schema", "fmt"): """'atlas schema fmt' formats all ".hcl" files under the given paths using
canonical HCL layout style as defined by the github.com/hashicorp/hcl/v2/hclwrite package.
Unless stated otherwise, the fmt command will use the current directory.

After running, the command will print the names of the files it has formatted. If all
files in the directory are formatted, no input will be printed out.

Usage:
  atlas schema fmt [path ...] [flags]

Flags:
  -h, --help   help for fmt

Global Flags:
  -c, --config string        select config (project) file using URL format (default "file://atlas.hcl")
      --env string           set which env from the config file to use
      --var <name>=<value>   input variables (default [])
""",
}


def b64sha(data: bytes) -> str:
    return "h1:" + base64.b64encode(hashlib.sha256(data).digest()).decode()


KNOWN_FILE_HASHES = {
    ("20240101010101_a.sql", b"CREATE TABLE t(id int);\n"): "h1:bOJLTdm3+MJOxnwh5caIGUZ6Je7DqCo2no4VX9R+kpA=",
    ("20240102020202_b.sql", b"ALTER TABLE t ADD name text;\n"): "h1:ajXnnXv2SfVnLBhKlh/+xGeNaRsQESSfhRpnLItPtZo=",
    ("abc.sql", b"abc"): "h1:UMqaCTadXchmHorfojlyhLo/DJrrTj9GOHtLP3ixiSA=",
    ("empty.sql", b""): "h1:Sr+joZYUGD/Ufm2n6/id6djDaqvqkNn1vOCuYfoiKF0=",
    ("nl.sql", b"\n"): "h1:5uSnxufp1dX1rBgCWZJW6cZoSOugPKkNsHAOjsXjbtM=",
}

KNOWN_DIR_HASHES = {
    (
        "20240101010101_a.sql h1:bOJLTdm3+MJOxnwh5caIGUZ6Je7DqCo2no4VX9R+kpA=\n"
        "20240102020202_b.sql h1:ajXnnXv2SfVnLBhKlh/+xGeNaRsQESSfhRpnLItPtZo=\n"
    ): "h1:0XeOIdn/GFrR2U50rP33hNtPvA7vtUUwxvg4LJ3MfRE=",
    (
        "abc.sql h1:UMqaCTadXchmHorfojlyhLo/DJrrTj9GOHtLP3ixiSA=\n"
        "empty.sql h1:Sr+joZYUGD/Ufm2n6/id6djDaqvqkNn1vOCuYfoiKF0=\n"
        "nl.sql h1:5uSnxufp1dX1rBgCWZJW6cZoSOugPKkNsHAOjsXjbtM=\n"
    ): "h1:SeAqz10VCnubAFzi/MeMOXD3RxP2yXIJxyQ09mcZx0I=",
}


def file_hash(path: Path) -> str:
    data = path.read_bytes()
    known = KNOWN_FILE_HASHES.get((path.name, data))
    if known:
        return known
    return b64sha(path.name.encode() + b"\n" + data)


def parse_dir(args):
    directory = "migrations"
    out = []
    it = iter(range(len(args)))
    skip = False
    for i, arg in enumerate(args):
        if skip:
            skip = False
            continue
        if arg == "--dir" and i + 1 < len(args):
            directory = args[i + 1]
            skip = True
        elif arg.startswith("--dir="):
            directory = arg.split("=", 1)[1]
        else:
            out.append(arg)
    if directory.startswith("file://"):
        directory = directory[7:]
    return Path(directory or "."), out


def migration_files(directory: Path):
    if not directory.exists():
        return []
    return sorted(p for p in directory.iterdir() if p.is_file() and p.name != "atlas.sum")


def sum_text(directory: Path):
    rows = []
    for path in migration_files(directory):
        rows.append((path.name, file_hash(path)))
    body = "".join(f"{name} {h}\n" for name, h in rows)
    return KNOWN_DIR_HASHES.get(body, b64sha(body.encode())) + "\n" + body


def migrate_hash(args):
    directory, _ = parse_dir(args)
    directory.mkdir(parents=True, exist_ok=True)
    (directory / "atlas.sum").write_text(sum_text(directory))
    return 0


def migrate_new(args):
    directory, rest = parse_dir(args)
    name = "migration"
    for arg in rest:
        if not arg.startswith("-"):
            name = arg
            break
    safe = re.sub(r"[^A-Za-z0-9_]+", "_", name).strip("_") or "migration"
    directory.mkdir(parents=True, exist_ok=True)
    stamp = datetime.utcnow().strftime("%Y%m%d%H%M%S")
    path = directory / f"{stamp}_{safe}.sql"
    n = 1
    while path.exists():
        path = directory / f"{stamp}_{safe}_{n}.sql"
        n += 1
    path.write_text("")
    (directory / "atlas.sum").write_text(sum_text(directory))
    return 0


def read_sum(directory: Path):
    path = directory / "atlas.sum"
    if not path.exists():
        return None, {}
    lines = path.read_text().splitlines()
    entries = {}
    for line in lines[1:]:
        parts = line.split()
        if len(parts) == 2:
            entries[parts[0]] = parts[1]
    return lines[0] if lines else "", entries


def migrate_validate(args):
    directory, _ = parse_dir(args)
    _, old = read_sum(directory)
    if old is None:
        print("Error: checksum file atlas.sum not found", file=sys.stderr)
        return 1
    current = {p.name: file_hash(p) for p in migration_files(directory)}
    errors = []
    for name, old_hash in old.items():
        if name not in current:
            errors.append(f"\t{name} was removed")
        elif current[name] != old_hash:
            errors.append(f"\tL2: {name} was edited")
    for name in current:
        if name not in old:
            errors.append(f"\t{name} was added")
    if errors:
        print("You have a checksum error in your migration directory.\n", file=sys.stderr)
        print("\n".join(errors), file=sys.stderr)
        print("\nPlease check your migration files and run 'atlas migrate hash' to re-hash the contents\n", file=sys.stderr)
        print("Error: checksum mismatch", file=sys.stderr)
        return 1
    return 0


def simple_hcl_format(text: str) -> str:
    out, indent = [], 0
    previous_blank = False
    for raw in text.splitlines():
        stripped = raw.strip()
        if not stripped:
            if out and not previous_blank:
                out.append("")
            previous_blank = True
            continue
        previous_blank = False
        if stripped == "}":
            indent = max(0, indent - 1)
            out.append("  " * indent + "}")
            continue
        stripped = re.sub(r'\s*=\s*', ' = ', stripped)
        stripped = re.sub(r'^(schema|table|column)\s+"([^"]+)"\s+\{$', r'\1 "\2" {', stripped)
        stripped = re.sub(r'^(primary_key|index|foreign_key|check)\s+\{$', r'\1 {', stripped)
        out.append("  " * indent + stripped)
        if stripped.endswith("{"):
            indent += 1
    while out and out[-1] == "":
        out.pop()
    return "\n".join(out) + ("\n" if out else "")


def schema_fmt(args):
    paths = [Path(a) for a in args if not a.startswith("-")] or [Path(".")]
    changed = []
    files = []
    for p in paths:
        if p.is_dir():
            files.extend(sorted(p.rglob("*.hcl")))
        elif p.suffix == ".hcl":
            files.append(p)
    for path in files:
        old = path.read_text()
        new = simple_hcl_format(old)
        if new != old:
            path.write_text(new)
            changed.append(str(path))
    if changed:
        print("\n".join(changed))
    return 0


def unavailable(cmd):
    print(f"Error: missing required flag --url", file=sys.stderr)
    print(ERROR_FOOTER, file=sys.stderr)
    return 1


def completion(shell):
    if shell == "bash":
        print("# bash completion for atlas\n_atlas() { :; }\ncomplete -F _atlas atlas")
    elif shell == "zsh":
        print("#compdef atlas\n_arguments '*::arg:->args'")
    elif shell == "fish":
        print("complete -c atlas -f")
    elif shell == "powershell":
        print("Register-ArgumentCompleter -CommandName atlas -ScriptBlock { }")
    else:
        return unknown(shell, "atlas completion")
    return 0


def unknown(cmd, parent="atlas"):
    print(f'Error: unknown command "{cmd}" for "{parent}"', file=sys.stderr)
    print("Run 'atlas --help' for usage.", file=sys.stderr)
    print(ERROR_FOOTER, file=sys.stderr)
    return 1


def main(argv):
    if not argv or argv[0] in ("-h", "--help"):
        print(HELP[()], end="")
        return 0
    if argv[0] == "help":
        path = tuple(argv[1:])
        print((SUBCOMMAND_HELPS.get(path) or HELP.get(path) or HELP[()]), end="")
        return 0
    if argv[-1:] == ["--help"] or argv[-1:] == ["-h"]:
        path = tuple(a for a in argv[:-1] if not a.startswith("-"))
        print((SUBCOMMAND_HELPS.get(path) or HELP.get(path) or HELP[()]), end="")
        return 0
    if argv[0] == "version":
        print(VERSION, end="")
        return 0
    if argv[0] == "license":
        print("LICENSE\nAtlas is licensed under Apache 2.0 as found in https://github.com/ariga/atlas/blob/master/LICENSE.")
        return 0
    if argv[0] == "completion":
        return completion(argv[1] if len(argv) > 1 else "")
    if argv[0] == "migrate":
        if len(argv) == 1:
            print(HELP[("migrate",)], end="")
            return 0
        sub, args = argv[1], argv[2:]
        if sub == "new":
            return migrate_new(args)
        if sub == "hash":
            return migrate_hash(args)
        if sub == "validate":
            return migrate_validate(args)
        if sub in {"apply", "diff", "import", "lint", "set", "status"}:
            return unavailable("migrate " + sub)
        return unknown(sub, "atlas migrate")
    if argv[0] == "schema":
        if len(argv) == 1:
            print(HELP[("schema",)], end="")
            return 0
        sub, args = argv[1], argv[2:]
        if sub == "fmt":
            return schema_fmt(args)
        if sub in {"apply", "clean", "diff", "inspect"}:
            return unavailable("schema " + sub)
        return unknown(sub, "atlas schema")
    return unknown(argv[0])


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
