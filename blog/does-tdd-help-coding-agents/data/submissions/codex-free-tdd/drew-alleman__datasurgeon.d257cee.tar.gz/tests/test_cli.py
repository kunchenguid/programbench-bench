import os
import shutil
import subprocess
import tempfile
import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
BIN = ROOT / "executable"


class CliTests(unittest.TestCase):
    def setUp(self):
        self.tmp = Path(tempfile.mkdtemp(prefix="ds-test-"))
        self.sample = self.tmp / "sample.txt"
        self.sample.write_text(
            "\n".join(
                [
                    "Contact alice@example.com or bob.smith+tag@sub.example.co.uk, call (555) 123-4567 or 555-987-6543.",
                    "Hash md5 d41d8cd98f00b204e9800998ecf8427e sha1 da39a3ee5e6b4b0d3255bfef95601890afd80709 sha256 e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855.",
                    "Visit https://example.com/path?q=1 and http://sub.domain.org/a-b.txt, file report.pdf and archive.tar.gz and notes.txt.",
                    "IP 192.168.1.1 999.999.999.999 IPv6 2001:0db8:85a3:0000:0000:8a2e:0370:7334 MAC aa:bb:cc:dd:ee:ff SSN 123-45-6789 CC 4111-1111-1111-1111",
                    "bitcoin 1BoatSLRHtKNngkdXEeobR76b53LETtpyT google abcdef1234567890abcdef1234567890abcdef12",
                ]
            )
            + "\n"
        )

    def tearDown(self):
        shutil.rmtree(self.tmp)

    def run_cmd(self, args, input_text=None):
        env = os.environ.copy()
        env["HOME"] = str(self.tmp / "home")
        return subprocess.run(
            [str(BIN), *args],
            input=input_text,
            text=True,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            cwd=ROOT,
            env=env,
        )

    def test_version_prints_datasurgeon_version(self):
        result = self.run_cmd(["--version"])
        self.assertEqual(result.returncode, 0)
        self.assertIn("DataSurgeon: https://github.com/Drew-Alleman/DataSurgeon 1.2.8", result.stdout)

    def test_clean_email_returns_first_match_with_label(self):
        result = self.run_cmd(["-f", str(self.sample), "-eC"])
        self.assertEqual(result.returncode, 0)
        self.assertIn("Failed to open plugins.json file. PLUGIN_PATH:", result.stdout)
        self.assertIn("email: alice@example.com\n", result.stdout)
        self.assertNotIn("bob.smith", result.stdout)

    def test_thorough_clean_email_returns_all_matches(self):
        result = self.run_cmd(["-f", str(self.sample), "-T", "-C", "-e"])
        self.assertEqual(result.returncode, 0)
        self.assertIn("email: alice@example.com\n", result.stdout)
        self.assertIn("email: bob.smith+tag@sub.example.co.uk\n", result.stdout)

    def test_hide_line_and_display_format(self):
        result = self.run_cmd(["-f", str(self.sample), "-eClDX"])
        self.assertEqual(result.returncode, 0)
        self.assertIn(f"file: {self.sample} alice@example.com, line: 1\n", result.stdout)

    def test_stdin_warning_and_suppress(self):
        result = self.run_cmd(["-eC"], "x a@b.com y\n")
        self.assertEqual(result.returncode, 0)
        self.assertIn("[*] Reading standard input. If you meant to analyze a file use 'ds -f <FILE>' (ctrl+c to exit)", result.stdout)
        self.assertIn("email: a@b.com\n", result.stdout)
        suppressed = self.run_cmd(["-eCS"], "x a@b.com y\n")
        self.assertEqual(suppressed.returncode, 0)
        self.assertNotIn("Reading standard input", suppressed.stdout)
        self.assertIn("email: a@b.com\n", suppressed.stdout)

    def test_output_writes_csv_and_stdout_only_warning(self):
        output = self.tmp / "out.csv"
        result = self.run_cmd(["-f", str(self.sample), "-eC", "-o", str(output)])
        self.assertEqual(result.returncode, 0)
        self.assertIn("Failed to open plugins.json file. PLUGIN_PATH:", result.stdout)
        self.assertNotIn("email: alice", result.stdout)
        self.assertEqual(output.read_text(), "content_type, data\nemail, alice@example.com\n")

    def test_bad_file_status_and_ignore(self):
        result = self.run_cmd(["-f", str(self.tmp / "missing.txt"), "-eC"])
        self.assertEqual(result.returncode, 1)
        self.assertIn("[-] File not found:", result.stdout)
        ignored = self.run_cmd(["--ignore", "-f", str(self.tmp / "missing.txt"), "-eC"])
        self.assertEqual(ignored.returncode, 1)
        self.assertNotIn("[-] File not found:", ignored.stdout)


if __name__ == "__main__":
    unittest.main()
