#!/usr/bin/env python3
import argparse
import csv
import os
import re
import sys
import time
from pathlib import Path


VERSION = "DataSurgeon: https://github.com/Drew-Alleman/DataSurgeon 1.2.8"
STDIN_NOTICE = "[*] Reading standard input. If you meant to analyze a file use 'ds -f <FILE>' (ctrl+c to exit)"


def plugin_path():
    return os.path.join(os.path.expanduser("~"), ".DataSurgeon", "plugins.json")


def plugin_warning():
    print(f"Failed to open plugins.json file. PLUGIN_PATH: {plugin_path()}")


def build_parser():
    p = argparse.ArgumentParser(
        prog="executable",
        add_help=False,
        formatter_class=argparse.RawTextHelpFormatter,
    )
    p.add_argument("-f", "--file", default="")
    p.add_argument("--add", default="")
    p.add_argument("--update", default="")
    p.add_argument("--remove", default="")
    p.add_argument("--list", action="store_true", dest="list_plugins")
    p.add_argument("-C", "--clean", action="store_true")
    p.add_argument("--directory", default="")
    p.add_argument("--ignore", action="store_true")
    p.add_argument("-l", "--line", action="store_true")
    p.add_argument("-T", "--thorough", action="store_true")
    p.add_argument("-D", "--display", action="store_true")
    p.add_argument("-S", "--suppress", action="store_true")
    p.add_argument("--drop", default="")
    p.add_argument("--filter", default="")
    p.add_argument("-X", "--hide", action="store_true")
    p.add_argument("-o", "--output", default="")
    p.add_argument("-t", "--time", action="store_true", dest="show_time")
    p.add_argument("-e", "--email", action="store_true")
    p.add_argument("-p", "--phone", action="store_true")
    p.add_argument("-H", "--hash", action="store_true", dest="hashes")
    p.add_argument("-i", "--ip-addr", action="store_true", dest="ip_addr")
    p.add_argument("-6", "--ipv6-addr", action="store_true", dest="ipv6_addr")
    p.add_argument("-m", "--mac-addr", action="store_true", dest="mac_addr")
    p.add_argument("-c", "--credit-card", action="store_true", dest="credit_card")
    p.add_argument("-u", "--url", action="store_true")
    p.add_argument("-F", "--files", action="store_true")
    p.add_argument("-b", "--bitcoin", action="store_true")
    p.add_argument("-a", "--aws", action="store_true")
    p.add_argument("-g", "--google", action="store_true")
    p.add_argument("-d", "--dns", action="store_true")
    p.add_argument("-s", "--social", action="store_true")
    p.add_argument("-h", "--help", action="store_true")
    p.add_argument("-V", "--version", action="store_true")
    return p


HELP = """Note: All extraction features (e.g: -i) work on a specified file (-f) or an output stream.

Usage: executable [OPTIONS]

Options:
  -f, --file <file>            File to extract information from [default: ""]
      --add <add>              Adds a plugin from a GitHub repository (e.g ds --add https://github.com/Drew-Alleman/ds-winreg-plugin/) [default: ""]
      --update <update>        Updates a plugin from a GitHub repository. You can also use `ds --update all` to update all plugins. (e.g ds --update https://github.com/DataSurgeon-ds/ds-cve-plugin/) [default: ""]
      --remove <remove>        Removes a plugin from a GitHub repository (e.g ds --remove https://github.com/Drew-Alleman/ds-winreg-plugin/) [default: ""]
      --list                   List all added plugins
  -C, --clean                  Only displays the matched result, rather than the entire line
      --directory <directory>  Process all files found in the specified directory [default: ""]
      --ignore                 Silences error messages
  -l, --line                   Displays the line number where the match occurred
  -T, --thorough               Doesn't stop at first match (useful for -C if multiple unique matches are on the same line
  -D, --display                Displays the filename assoicated with the content found (https://github.com/Drew-Alleman/DataSurgeon#reading-all-files-in-a-directory)
  -S, --suppress               Suppress the 'Reading standard input' message when not providing a file
      --drop <drop>            Specify a regular expression to exclude certain patterns from the search. (e.g --drop "^.{1,10}$" will hide all matches not under 10 characters) [default: ""]
      --filter <filter>        Include only lines that match the specified regex. (e.g: '--filter ^error' will only include lines that start with the word 'error' [default: ""]
  -X, --hide                   Hides the identifier string infront of the desired content (e.g: 'hash: ', 'url: ', 'email: ' will not be displayed.
  -o, --output <output>        Output's the results of the procedure to a local file (recommended for large files) [default: ""]
  -t, --time                   Time how long the operation took
  -e, --email                  Extract email addresses
  -p, --phone                  Extracts phone numbers
  -H, --hash                   Extract hashes (NTLM, LM, bcrypt, Oracle, MD5, SHA-1, SHA-224, SHA-256, SHA-384, SHA-512, SHA3-224, SHA3-256, SHA3-384, SHA3-512, MD4)
  -i, --ip-addr                Extract IP addresses
  -6, --ipv6-addr              Extract IPv6 addresses
  -m, --mac-addr               Extract MAC addresses
  -c, --credit-card            Extract credit card numbers
  -u, --url                    Extract urls
  -F, --files                  Extract filenames
  -b, --bitcoin                Extract bitcoin wallets
  -a, --aws                    Extract AWS keys
  -g, --google                 Extract Google service account private key ids (used for google automations services)
  -d, --dns                    Extract Domain Name System records
  -s, --social                 Extract social security numbers
  -h, --help                   Print help
  -V, --version                Print version"""


def find_ip(line):
    out = []
    for m in re.finditer(r"\b(?:\d{1,3}\.){3}\d{1,3}\b", line):
        parts = m.group(0).split(".")
        if all(0 <= int(x) <= 255 for x in parts):
            out.append(m.group(0))
    return out


def find_matches(kind, line):
    patterns = {
        "email": r"[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}",
        "phone_number": r"\b\d{3}[-.]\d{3}[-.]\d{4}\b",
        "hashes": r"\b[a-fA-F0-9]{32}\b|\b[a-fA-F0-9]{40}\b|\b[a-fA-F0-9]{56}\b|\b[a-fA-F0-9]{64}\b|\b[a-fA-F0-9]{96}\b|\b[a-fA-F0-9]{128}\b",
        "ipv6_address": r"\b(?:[0-9A-Fa-f]{1,4}:){2,7}[0-9A-Fa-f]{1,4}\b",
        "mac_address": r"\b[0-9A-Fa-f]{2}(?::[0-9A-Fa-f]{2}){5}\b|\b[0-9A-Fa-f]{2}(?:-[0-9A-Fa-f]{2}){5}\b",
        "credit_card": r"\b(?:\d[ -]*?){13,19}\b",
        "url": r"https?://[^\s,]+",
        "files": r"\b[A-Za-z0-9_.-]+\.(?:txt|pdf|docx?|xlsx?|pptx?|csv|json|xml|ya?ml|zip|tar|gz|tgz|rar|7z|log|html?|js|css|png|jpe?g|gif|exe|dll|so|py|rs|go|c|cpp|h)\b",
        "bitcoin_wallet": r"\b[13][a-km-zA-HJ-NP-Z1-9]{25,34}\b|\bbc1[ac-hj-np-z02-9]{11,71}\b",
        "aws_key": r"\b(?:AKIA|ASIA)[A-Z0-9]{16}\b",
        "google_private_key_id": r"\b[a-fA-F0-9]{40}\b",
        "dns_record": r"\b(?:[A-Za-z0-9-]+\.)+[A-Za-z]{2,}\b",
        "social_security": r"\b\d{3}-\d{2}-\d{4}\b",
    }
    if kind == "ip_address":
        return find_ip(line)
    return [m.group(0).rstrip(".,;:)]}") for m in re.finditer(patterns[kind], line)]


def selected_kinds(args):
    mapping = [
        ("email", args.email),
        ("phone_number", args.phone),
        ("hashes", args.hashes),
        ("ip_address", args.ip_addr),
        ("ipv6_address", args.ipv6_addr),
        ("mac_address", args.mac_addr),
        ("credit_card", args.credit_card),
        ("url", args.url),
        ("files", args.files),
        ("bitcoin_wallet", args.bitcoin),
        ("aws_key", args.aws),
        ("google_private_key_id", args.google),
        ("dns_record", args.dns),
        ("social_security", args.social),
    ]
    chosen = [name for name, enabled in mapping if enabled]
    return chosen or [name for name, _ in mapping]


def iter_inputs(args):
    if args.directory:
        for path in sorted(Path(args.directory).rglob("*")):
            if path.is_file():
                yield str(path), path.read_text(errors="ignore").splitlines()
        return
    if args.file:
        path = Path(args.file)
        if not path.exists():
            if not args.ignore:
                print(f"[-] File not found: {args.file}")
            raise SystemExit(1)
        yield args.file, path.read_text(errors="ignore").splitlines()
        return
    if not args.suppress:
        print(STDIN_NOTICE)
    yield "", sys.stdin.read().splitlines()


def should_keep(text, args):
    try:
        if args.filter and not re.search(args.filter, text):
            return False
        if args.drop and re.search(args.drop, text):
            return False
    except re.error:
        pass
    return True


def format_result(kind, value, line_text, filename, line_no, args):
    data = value if args.clean else line_text
    prefix = "" if args.hide else f"{kind}: "
    if args.display:
        prefix = ("" if args.hide else f"{kind}, ") + f"file: {filename} "
    suffix = f", line: {line_no}" if args.line else ""
    return f"{prefix}{data}{suffix}"


def extract(args):
    rows = []
    kinds = selected_kinds(args)
    for filename, lines in iter_inputs(args):
        for idx, line in enumerate(lines, 1):
            if not should_keep(line, args):
                continue
            emitted_line = False
            for kind in kinds:
                matches = find_matches(kind, line)
                if not matches:
                    continue
                values = matches if args.clean and args.thorough else [matches[0]]
                for value in values:
                    target = value if args.clean else line
                    if not should_keep(target, args):
                        continue
                    rows.append((kind, value, format_result(kind, value, line, filename, idx, args)))
                    emitted_line = True
                    if not args.thorough:
                        break
                if emitted_line and not args.thorough:
                    break
    return rows


def write_output(rows, path):
    with open(path, "w") as fh:
        fh.write("content_type, data\n")
        for kind, value, _ in rows:
            fh.write(f"{kind}, {value}\n")


def main(argv=None):
    start = time.time()
    parser = build_parser()
    args = parser.parse_args(argv)
    plugin_warning()
    if args.help:
        print(HELP)
        return 0
    if args.version:
        print(VERSION)
        return 0
    if args.list_plugins:
        plugin_warning()
        print(f"No plugins found. Plugin File: {plugin_path()}")
        return 1
    if args.add or args.update or args.remove:
        print("Plugin operations are unavailable in this build.")
        return 1
    rows = extract(args)
    if args.output:
        write_output(rows, args.output)
    else:
        for _, _, text in rows:
            print(text)
    if args.show_time:
        elapsed = int(time.time() - start)
        h, rem = divmod(elapsed, 3600)
        m, s = divmod(rem, 60)
        print(f"[*] Time elapsed: {h:02d}h:{m:02d}m:{s:02d}s")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
