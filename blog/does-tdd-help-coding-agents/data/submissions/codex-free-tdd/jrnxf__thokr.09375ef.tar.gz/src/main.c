#include <ctype.h>
#include <errno.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <unistd.h>

typedef struct {
    const char *lang;
    const char *prompt;
    unsigned long words;
    unsigned long secs;
    unsigned long sentences;
    int has_secs;
    int has_sentences;
} Options;

static void print_version(void) {
    puts("thokr 0.4.1");
}

static void print_help(void) {
    puts("thokr 0.4.1");
    puts("sleek typing tui with visualized results and historical logging");
    puts("");
    puts("USAGE:");
    puts("    executable [OPTIONS]");
    puts("");
    puts("OPTIONS:");
    puts("    -f, --full-sentences <NUMBER_OF_SENTENCES>");
    puts("            number of sentences to use in test");
    puts("");
    puts("    -h, --help");
    puts("            Print help information");
    puts("");
    puts("    -l, --supported-language <SUPPORTED_LANGUAGE>");
    puts("            language to pull words from [default: english] [possible values: english, english1k,");
    puts("            english10k]");
    puts("");
    puts("    -p, --prompt <PROMPT>");
    puts("            custom prompt to use");
    puts("");
    puts("    -s, --number-of-secs <NUMBER_OF_SECS>");
    puts("            number of seconds to run test");
    puts("");
    puts("    -V, --version");
    puts("            Print version information");
    puts("");
    puts("    -w, --number-of-words <NUMBER_OF_WORDS>");
    puts("            number of words to use in test [default: 15]");
}

static void error_footer_options(void) {
    puts("");
    puts("USAGE:");
    puts("    executable [OPTIONS]");
    puts("");
    puts("For more information try --help");
}

static int die_bad_flag(const char *arg) {
    printf("error: Found argument '%s' which wasn't expected, or isn't valid in this context\n", arg);
    puts("");
    printf("\tIf you tried to supply `%s` as a value rather than a flag, use `-- %s`\n", arg, arg);
    error_footer_options();
    return 2;
}

static int die_missing_value(const char *flag, const char *meta) {
    printf("error: The argument '%s <%s>' requires a value but none was supplied\n", flag, meta);
    error_footer_options();
    return 2;
}

static int is_supported_language(const char *value) {
    return strcmp(value, "english") == 0 || strcmp(value, "english1k") == 0 || strcmp(value, "english10k") == 0;
}

static int invalid_digit_message(const char *value, const char *flag, const char *meta) {
    printf("error: Invalid value \"%s\" for '%s <%s>': invalid digit found in string\n", value, flag, meta);
    puts("");
    puts("For more information try --help");
    return 2;
}

static int parse_number(const char *value, const char *flag, const char *meta, unsigned long *out) {
    if (value[0] == '-') {
        return die_bad_flag(value);
    }
    if (value[0] == '\0') {
        return invalid_digit_message(value, flag, meta);
    }
    for (const char *p = value; *p; ++p) {
        if (!isdigit((unsigned char)*p)) {
            return invalid_digit_message(value, flag, meta);
        }
    }
    errno = 0;
    unsigned long parsed = strtoul(value, NULL, 10);
    if (errno == ERANGE) {
        return invalid_digit_message(value, flag, meta);
    }
    *out = parsed;
    return 0;
}

static int value_missing_or_flag(int argc, char **argv, int idx, const char *flag, const char *meta) {
    if (idx + 1 >= argc) {
        return die_missing_value(flag, meta);
    }
    if (argv[idx + 1][0] == '-') {
        return die_bad_flag(argv[idx + 1]);
    }
    return 0;
}

static int parse_args(int argc, char **argv, Options *opts) {
    opts->lang = "english";
    opts->prompt = NULL;
    opts->words = 15;
    opts->secs = 0;
    opts->sentences = 0;
    opts->has_secs = 0;
    opts->has_sentences = 0;

    for (int i = 1; i < argc; ++i) {
        const char *arg = argv[i];
        if (strcmp(arg, "--help") == 0 || strcmp(arg, "-h") == 0) {
            print_help();
            exit(0);
        } else if (strcmp(arg, "--version") == 0 || strcmp(arg, "-V") == 0) {
            print_version();
            exit(0);
        } else if (strcmp(arg, "--supported-language") == 0 || strcmp(arg, "-l") == 0) {
            int e = value_missing_or_flag(argc, argv, i, "--supported-language", "SUPPORTED_LANGUAGE");
            if (e) return e;
            const char *value = argv[++i];
            if (!is_supported_language(value)) {
                printf("error: \"%s\" isn't a valid value for '--supported-language <SUPPORTED_LANGUAGE>'\n", value);
                puts("\t[possible values: english, english1k, english10k]");
                puts("");
                puts("USAGE:");
                puts("    executable --supported-language <SUPPORTED_LANGUAGE>");
                puts("");
                puts("For more information try --help");
                return 2;
            }
            opts->lang = value;
        } else if (strcmp(arg, "--prompt") == 0 || strcmp(arg, "-p") == 0) {
            int e = value_missing_or_flag(argc, argv, i, "--prompt", "PROMPT");
            if (e) return e;
            opts->prompt = argv[++i];
        } else if (strcmp(arg, "--number-of-words") == 0 || strcmp(arg, "-w") == 0) {
            int e = value_missing_or_flag(argc, argv, i, "--number-of-words", "NUMBER_OF_WORDS");
            if (e) return e;
            e = parse_number(argv[++i], "--number-of-words", "NUMBER_OF_WORDS", &opts->words);
            if (e) return e;
        } else if (strcmp(arg, "--number-of-secs") == 0 || strcmp(arg, "-s") == 0) {
            int e = value_missing_or_flag(argc, argv, i, "--number-of-secs", "NUMBER_OF_SECS");
            if (e) return e;
            e = parse_number(argv[++i], "--number-of-secs", "NUMBER_OF_SECS", &opts->secs);
            if (e) return e;
            opts->has_secs = 1;
        } else if (strcmp(arg, "--full-sentences") == 0 || strcmp(arg, "-f") == 0) {
            int e = value_missing_or_flag(argc, argv, i, "--full-sentences", "NUMBER_OF_SENTENCES");
            if (e) return e;
            e = parse_number(argv[++i], "--full-sentences", "NUMBER_OF_SENTENCES", &opts->sentences);
            if (e) return e;
            opts->has_sentences = 1;
        } else {
            return die_bad_flag(arg);
        }
    }
    return 0;
}

static void build_default_prompt(const Options *opts, char *buf, size_t size) {
    static const char *words[] = {
        "the", "be", "to", "of", "and", "a", "in", "that", "have", "i",
        "it", "for", "not", "on", "with", "he", "as", "you", "do", "at",
        "this", "but", "his", "by", "from", "they", "we", "say", "her", "she"
    };
    buf[0] = '\0';
    unsigned long count = opts->has_sentences ? opts->sentences * 7 : opts->words;
    if (count == 0) count = 1;
    for (unsigned long i = 0; i < count; ++i) {
        if (i > 0 && strlen(buf) + 2 < size) strcat(buf, " ");
        const char *w = words[i % (sizeof(words) / sizeof(words[0]))];
        if (strlen(buf) + strlen(w) + 3 >= size) break;
        strcat(buf, w);
        if (opts->has_sentences && (i + 1) % 7 == 0) strcat(buf, ".");
    }
}

static int run_tui(const Options *opts) {
    char generated[2048];
    const char *prompt = opts->prompt;
    if (!prompt) {
        build_default_prompt(opts, generated, sizeof(generated));
        prompt = generated;
    }

    printf("thokr 0.4.1\n\n");
    printf("%s\n\n", prompt);
    printf("Press Ctrl-C to quit. Type the prompt and press Enter.\n");
    fflush(stdout);

    char input[4096];
    if (opts->has_secs && opts->secs == 0) {
        return 0;
    }
    if (fgets(input, sizeof(input), stdin) == NULL) {
        return 0;
    }
    size_t len = strlen(input);
    if (len && input[len - 1] == '\n') input[len - 1] = '\0';
    unsigned correct = strcmp(input, prompt) == 0 ? (unsigned)strlen(prompt) : 0;
    printf("\naccuracy: %u/%zu\n", correct, strlen(prompt));
    return 0;
}

int main(int argc, char **argv) {
    Options opts;
    int parsed = parse_args(argc, argv, &opts);
    if (parsed) {
        return parsed;
    }

    if (!isatty(STDIN_FILENO)) {
        puts("error: stdin must be a tty");
        puts("");
        puts("USAGE:");
        puts("    thokr [OPTIONS]");
        puts("");
        puts("For more information try --help");
        return 2;
    }

    return run_tui(&opts);
}
