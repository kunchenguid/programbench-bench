#!/bin/bash
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT"

rm -f executable
chmod +x ./compile.sh
./compile.sh >/tmp/thokr-compile.out

pass=0

run_case() {
  local name="$1"
  local expected_status="$2"
  local expected_file="$3"
  shift 3

  set +e
  "$@" >"/tmp/thokr-${name}.out" 2>&1
  local status=$?
  set -e

  if [[ "$status" != "$expected_status" ]]; then
    echo "FAIL $name: expected status $expected_status, got $status"
    cat "/tmp/thokr-${name}.out"
    exit 1
  fi

  if ! diff -u "$expected_file" "/tmp/thokr-${name}.out"; then
    echo "FAIL $name: output mismatch"
    exit 1
  fi

  pass=$((pass + 1))
}

mkdir -p /tmp/thokr-expected

cat > /tmp/thokr-expected/version <<'EOF'
thokr 0.4.1
EOF

cat > /tmp/thokr-expected/help <<'EOF'
thokr 0.4.1
sleek typing tui with visualized results and historical logging

USAGE:
    executable [OPTIONS]

OPTIONS:
    -f, --full-sentences <NUMBER_OF_SENTENCES>
            number of sentences to use in test

    -h, --help
            Print help information

    -l, --supported-language <SUPPORTED_LANGUAGE>
            language to pull words from [default: english] [possible values: english, english1k,
            english10k]

    -p, --prompt <PROMPT>
            custom prompt to use

    -s, --number-of-secs <NUMBER_OF_SECS>
            number of seconds to run test

    -V, --version
            Print version information

    -w, --number-of-words <NUMBER_OF_WORDS>
            number of words to use in test [default: 15]
EOF

cat > /tmp/thokr-expected/badflag <<'EOF'
error: Found argument '--bad' which wasn't expected, or isn't valid in this context

	If you tried to supply `--bad` as a value rather than a flag, use `-- --bad`

USAGE:
    executable [OPTIONS]

For more information try --help
EOF

cat > /tmp/thokr-expected/badlang <<'EOF'
error: "bogus" isn't a valid value for '--supported-language <SUPPORTED_LANGUAGE>'
	[possible values: english, english1k, english10k]

USAGE:
    executable --supported-language <SUPPORTED_LANGUAGE>

For more information try --help
EOF

cat > /tmp/thokr-expected/badnum <<'EOF'
error: Invalid value "abc" for '--number-of-words <NUMBER_OF_WORDS>': invalid digit found in string

For more information try --help
EOF

cat > /tmp/thokr-expected/missingprompt <<'EOF'
error: The argument '--prompt <PROMPT>' requires a value but none was supplied

USAGE:
    executable [OPTIONS]

For more information try --help
EOF

cat > /tmp/thokr-expected/notty <<'EOF'
error: stdin must be a tty

USAGE:
    thokr [OPTIONS]

For more information try --help
EOF

run_case version 0 /tmp/thokr-expected/version ./executable --version
run_case shortversion 0 /tmp/thokr-expected/version ./executable -V
run_case help 0 /tmp/thokr-expected/help ./executable --help
run_case badflag 2 /tmp/thokr-expected/badflag ./executable --bad
run_case badlang 2 /tmp/thokr-expected/badlang ./executable -l bogus
run_case badnum 2 /tmp/thokr-expected/badnum ./executable -w abc
run_case missingprompt 2 /tmp/thokr-expected/missingprompt ./executable -p
run_case notty 2 /tmp/thokr-expected/notty ./executable -w 1

echo "$pass tests passed"
