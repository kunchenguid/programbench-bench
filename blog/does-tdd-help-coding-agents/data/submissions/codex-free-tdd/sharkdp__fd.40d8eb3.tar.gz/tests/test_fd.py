import os
import shutil
import stat
import subprocess
import tempfile
import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
EXE = ROOT / "executable"


def run_fd(args, cwd):
    return subprocess.run(
        [str(EXE), *args],
        cwd=cwd,
        text=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
    )


def make_fixture(path):
    (path / ".git").mkdir()
    (path / "src").mkdir()
    (path / "emptydir").mkdir()
    (path / ".hidden").mkdir()
    (path / "vendor").mkdir()
    (path / "src" / "alpha.txt").write_text("alpha")
    (path / "src" / "Beta.TXT").write_text("Beta")
    (path / "src" / "drop.tmp").write_text("tmp")
    (path / ".hidden" / "secret").write_text("hidden")
    (path / "vendor" / "skip.log").write_text("ignore")
    (path / ".gitignore").write_text("vendor/\n*.tmp\n")
    os.symlink("src/alpha.txt", path / "link-alpha")
    exe = path / "runme"
    exe.write_text("#!/bin/sh\n")
    exe.chmod(exe.stat().st_mode | stat.S_IXUSR)


class FdBehaviorTests(unittest.TestCase):
    def setUp(self):
        self.tmp = Path(tempfile.mkdtemp(prefix="fd-tests-"))
        make_fixture(self.tmp)

    def tearDown(self):
        shutil.rmtree(self.tmp)

    def test_default_search_lists_visible_nonignored_entries(self):
        result = run_fd(["."], self.tmp)
        self.assertEqual(result.returncode, 0)
        self.assertEqual(result.stderr, "")
        self.assertEqual(
            result.stdout,
            "emptydir/\n"
            "link-alpha\n"
            "runme\n"
            "src/\n"
            "src/Beta.TXT\n"
            "src/alpha.txt\n",
        )

    def test_hidden_and_unrestricted_control_ignored_entries(self):
        hidden = run_fd(["-H", "."], self.tmp)
        self.assertIn(".hidden/\n", hidden.stdout)
        self.assertNotIn("vendor/skip.log\n", hidden.stdout)

        unrestricted = run_fd(["-u", "."], self.tmp)
        self.assertIn(".gitignore\n", unrestricted.stdout)
        self.assertIn(".hidden/secret\n", unrestricted.stdout)
        self.assertIn("src/drop.tmp\n", unrestricted.stdout)
        self.assertIn("vendor/skip.log\n", unrestricted.stdout)

    def test_pattern_matching_modes_and_filters(self):
        self.assertEqual(run_fd(["alpha"], self.tmp).stdout, "link-alpha\nsrc/alpha.txt\n")
        self.assertEqual(run_fd(["Beta"], self.tmp).stdout, "src/Beta.TXT\n")
        self.assertEqual(run_fd(["beta"], self.tmp).stdout, "src/Beta.TXT\n")
        self.assertEqual(run_fd(["-g", "*.txt"], self.tmp).stdout, "src/alpha.txt\n")
        self.assertEqual(
            run_fd(["-e", "txt", "-tf", "."], self.tmp).stdout,
            "src/Beta.TXT\nsrc/alpha.txt\n",
        )
        self.assertEqual(run_fd(["-td", "."], self.tmp).stdout, "emptydir/\nsrc/\n")
        self.assertEqual(run_fd(["-tx", "."], self.tmp).stdout, "runme\n")

    def test_depth_print0_quiet_and_absolute_path(self):
        self.assertEqual(
            run_fd(["-d", "1", "."], self.tmp).stdout,
            "emptydir/\nlink-alpha\nrunme\nsrc/\n",
        )
        raw = subprocess.run(
            [str(EXE), "-0", "alpha"],
            cwd=self.tmp,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
        )
        self.assertEqual(raw.stdout, b"./link-alpha\x00./src/alpha.txt\x00")
        self.assertEqual(raw.returncode, 0)

        found = run_fd(["-q", "alpha"], self.tmp)
        missing = run_fd(["-q", "nomatch"], self.tmp)
        self.assertEqual(found.stdout, "")
        self.assertEqual(missing.stdout, "")
        self.assertEqual(found.returncode, 0)
        self.assertEqual(missing.returncode, 1)

        absolute = run_fd(["-a", "alpha"], self.tmp)
        self.assertEqual(
            absolute.stdout,
            f"{self.tmp}/link-alpha\n{self.tmp}/src/alpha.txt\n",
        )

    def test_exec_batch_and_format_placeholders(self):
        per = run_fd(["alpha", "-x", "printf", "X:%s:%s\n", "{}", "{/}"], self.tmp)
        self.assertEqual(
            per.stdout,
            "X:./link-alpha:link-alpha\nX:./src/alpha.txt:alpha.txt\n",
        )

        batch = run_fd(["alpha", "-X", "printf", "B:%s\n", "{}"], self.tmp)
        self.assertEqual(batch.stdout, "B:./link-alpha\nB:./src/alpha.txt\n")

        fmt = run_fd(["--format", "{//}|{/}|{.}|{/.}|{}", "alpha"], self.tmp)
        self.assertEqual(
            fmt.stdout,
            ".|link-alpha|link-alpha|link-alpha|link-alpha\n"
            "src|alpha.txt|src/alpha|alpha|src/alpha.txt\n",
        )

    def test_common_path_and_matching_options(self):
        self.assertEqual(
            run_fd([".", str(self.tmp / "src")], self.tmp).stdout,
            f"{self.tmp}/src/Beta.TXT\n{self.tmp}/src/alpha.txt\n",
        )
        self.assertEqual(run_fd(["src/alpha"], self.tmp).stdout, "")
        self.assertEqual(run_fd(["-p", "src/alpha"], self.tmp).stdout, "src/alpha.txt\n")
        self.assertEqual(
            run_fd(["-E", "src", "."], self.tmp).stdout,
            "emptydir/\nlink-alpha\nrunme\n",
        )
        self.assertEqual(
            run_fd(["--min-depth", "2", "."], self.tmp).stdout,
            "src/Beta.TXT\nsrc/alpha.txt\n",
        )
        self.assertEqual(
            run_fd(["--exact-depth", "1", "."], self.tmp).stdout,
            "emptydir/\nlink-alpha\nrunme\nsrc/\n",
        )
        self.assertEqual(run_fd(["-F", "alpha."], self.tmp).stdout, "src/alpha.txt\n")
        self.assertEqual(
            run_fd([".", "--and", "alpha"], self.tmp).stdout,
            "link-alpha\nsrc/alpha.txt\n",
        )
        self.assertEqual(
            run_fd(["--search-path", "src", "alpha"], self.tmp).stdout,
            "src/alpha.txt\n",
        )
        self.assertEqual(
            run_fd(["--base-directory", str(self.tmp), "alpha"], Path("/")).stdout,
            "link-alpha\nsrc/alpha.txt\n",
        )

    def test_size_and_owner_filters(self):
        user = subprocess.check_output(["id", "-un"], text=True).strip()
        group = subprocess.check_output(["id", "-gn"], text=True).strip()
        self.assertEqual(
            run_fd(["-tf", "-S", "5b", "."], self.tmp).stdout,
            "src/alpha.txt\n",
        )
        self.assertEqual(
            run_fd(["-tf", "-S", "-4b", "."], self.tmp).stdout,
            "src/Beta.TXT\n",
        )
        self.assertEqual(run_fd(["-o", user, "alpha"], self.tmp).stdout, "link-alpha\nsrc/alpha.txt\n")
        self.assertEqual(run_fd(["-o", f":{group}", "alpha"], self.tmp).stdout, "link-alpha\nsrc/alpha.txt\n")
        self.assertEqual(run_fd(["-o", f"!{user}", "alpha"], self.tmp).stdout, "")


if __name__ == "__main__":
    unittest.main()
