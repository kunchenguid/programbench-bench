#!/usr/bin/env python3
import fnmatch
import grp
import os
import pwd
import re
import shutil
import stat
import subprocess
import sys
import time
from dataclasses import dataclass, field
from pathlib import Path


HELP_SHORT = """A program to find entries in your filesystem

Usage: executable [OPTIONS] [pattern] [path]...

Arguments:
  [pattern]  the search pattern (a regular expression, unless '--glob' is used; optional)
  [path]...  the root directories for the filesystem search (optional)

Options:
  -H, --hidden                     Search hidden files and directories
  -I, --no-ignore                  Do not respect .(git|fd)ignore files
  -s, --case-sensitive             Case-sensitive search (default: smart case)
  -i, --ignore-case                Case-insensitive search (default: smart case)
  -g, --glob                       Glob-based search (default: regular expression)
  -a, --absolute-path              Show absolute instead of relative paths
  -l, --list-details               Use a long listing format with file metadata
  -L, --follow                     Follow symbolic links
  -p, --full-path                  Search full abs. path (default: filename only)
  -d, --max-depth <depth>          Set maximum search depth (default: none)
  -E, --exclude <pattern>          Exclude entries that match the given glob pattern
  -t, --type <filetype>            Filter by type: file (f), directory (d/dir), symlink (l),
                                   executable (x), empty (e), socket (s), pipe (p), char-device
                                   (c), block-device (b)
  -e, --extension <ext>            Filter by file extension
  -S, --size <size>                Limit results based on the size of files
      --changed-within <date|dur>  Filter by file modification time (newer than)
      --changed-before <date|dur>  Filter by file modification time (older than)
  -o, --owner <user:group>         Filter by owning user and/or group
      --format <fmt>               Print results according to template
  -x, --exec <cmd>...              Execute a command for each search result
  -X, --exec-batch <cmd>...        Execute a command with all search results at once
  -c, --color <when>               When to use colors [default: auto] [possible values: auto,
                                   always, never]
      --hyperlink[=<when>]         Add hyperlinks to output paths [default: never] [possible
                                   values: auto, always, never]
      --ignore-contain <name>      Ignore directories containing the named entry
  -h, --help                       Print help (see more with '--help')
  -V, --version                    Print version
"""


@dataclass
class Options:
    hidden: bool = False
    no_ignore: bool = False
    case: str = "smart"
    glob: bool = False
    fixed: bool = False
    absolute: bool = False
    follow: bool = False
    full_path: bool = False
    print0: bool = False
    max_depth: int | None = None
    min_depth: int = 1
    excludes: list[str] = field(default_factory=list)
    types: set[str] = field(default_factory=set)
    extensions: list[str] = field(default_factory=list)
    max_results: int | None = None
    quiet: bool = False
    format: str | None = None
    exec_cmd: list[str] | None = None
    batch_cmd: list[str] | None = None
    search_paths: list[str] = field(default_factory=list)
    base_directory: str | None = None
    size_filter: tuple[str, int] | None = None
    changed_within: float | None = None
    changed_before: float | None = None
    owner_filter: str | None = None
    and_patterns: list[str] = field(default_factory=list)
    strip_cwd_prefix: str = "auto"
    path_separator: str = os.sep


def fail(msg, code=2):
    print(f"error: {msg}", file=sys.stderr)
    return code


def read_value(argv, i, opt):
    if i + 1 >= len(argv):
        raise ValueError(f"a value is required for '{opt}'")
    return argv[i + 1], i + 2


def parse_args(argv):
    opts = Options()
    positional = []
    i = 0
    stop_opts = False
    while i < len(argv):
        a = argv[i]
        if opts.exec_cmd is not None:
            opts.exec_cmd = argv[i:]
            break
        if opts.batch_cmd is not None:
            opts.batch_cmd = argv[i:]
            break
        if not stop_opts and a == "--":
            stop_opts = True
            i += 1
            continue
        if not stop_opts and a in ("-h", "--help"):
            print(HELP_SHORT, end="")
            raise SystemExit(0)
        if not stop_opts and a in ("-V", "--version"):
            print("fd 10.3.0")
            raise SystemExit(0)
        if not stop_opts and a in ("-x", "--exec"):
            opts.exec_cmd = []
            i += 1
            continue
        if not stop_opts and a in ("-X", "--exec-batch"):
            opts.batch_cmd = []
            i += 1
            continue
        if not stop_opts and a.startswith("--"):
            name, eq, value = a.partition("=")
            if name == "--hidden":
                opts.hidden = True
            elif name == "--no-hidden":
                opts.hidden = False
            elif name == "--no-ignore":
                opts.no_ignore = True
            elif name in ("--ignore",):
                opts.no_ignore = False
            elif name in ("--no-ignore-vcs", "--no-require-git", "--no-ignore-parent",
                          "--require-git", "--ignore-vcs", "--one-file-system", "--mount",
                          "--xdev", "--show-errors"):
                pass
            elif name == "--unrestricted":
                opts.hidden = True
                opts.no_ignore = True
            elif name == "--case-sensitive":
                opts.case = "sensitive"
            elif name == "--ignore-case":
                opts.case = "insensitive"
            elif name == "--glob":
                opts.glob = True
                opts.fixed = False
            elif name == "--regex":
                opts.glob = False
            elif name == "--fixed-strings":
                opts.fixed = True
                opts.glob = False
            elif name == "--absolute-path":
                opts.absolute = True
            elif name == "--relative-path":
                opts.absolute = False
            elif name == "--list-details":
                opts.batch_cmd = ["ls", "-l"]
            elif name == "--follow":
                opts.follow = True
            elif name == "--no-follow":
                opts.follow = False
            elif name == "--full-path":
                opts.full_path = True
            elif name == "--print0":
                opts.print0 = True
            elif name in ("--max-depth", "--min-depth", "--exact-depth", "--exclude",
                          "--type", "--extension", "--max-results", "--size", "--owner",
                          "--format", "--search-path", "--base-directory", "--path-separator",
                          "--changed-within", "--change-newer-than", "--newer",
                          "--changed-after", "--changed-before", "--change-older-than",
                          "--older", "--and", "--ignore-file", "--threads",
                          "--batch-size", "--ignore-contain", "--color"):
                if not eq:
                    value, i = read_value(argv, i, name)
                    step_done = True
                else:
                    step_done = False
                if name == "--max-depth":
                    opts.max_depth = int(value)
                elif name == "--min-depth":
                    opts.min_depth = int(value)
                elif name == "--exact-depth":
                    opts.min_depth = int(value)
                    opts.max_depth = int(value)
                elif name == "--exclude":
                    opts.excludes.append(value)
                elif name == "--type":
                    add_type(opts, value)
                elif name == "--extension":
                    opts.extensions.append(value.lstrip(".").lower())
                elif name == "--max-results":
                    opts.max_results = int(value)
                elif name == "--size":
                    opts.size_filter = parse_size(value)
                elif name == "--owner":
                    opts.owner_filter = value
                elif name == "--format":
                    opts.format = value
                elif name == "--search-path":
                    opts.search_paths.append(value)
                elif name == "--base-directory":
                    opts.base_directory = value
                elif name == "--path-separator":
                    opts.path_separator = value
                elif name in ("--changed-within", "--change-newer-than", "--newer", "--changed-after"):
                    opts.changed_within = parse_time_arg(value)
                elif name in ("--changed-before", "--change-older-than", "--older"):
                    opts.changed_before = parse_time_arg(value)
                elif name == "--and":
                    opts.and_patterns.append(value)
                if not step_done:
                    i += 1
                continue
            elif name == "--quiet" or name == "--has-results":
                opts.quiet = True
            elif name.startswith("--strip-cwd-prefix"):
                opts.strip_cwd_prefix = value if eq and value else "always"
            elif name.startswith("--hyperlink"):
                pass
            elif name == "--prune":
                pass
            else:
                raise ValueError(f"unexpected argument '{a}'")
            i += 1
            continue
        if not stop_opts and a.startswith("-") and a != "-":
            if a.startswith("-d") and len(a) > 2:
                opts.max_depth = int(a[2:])
                i += 1
                continue
            if a.startswith("-e") and len(a) > 2:
                opts.extensions.append(a[2:].lstrip(".").lower())
                i += 1
                continue
            if a.startswith("-t") and len(a) > 2:
                add_type(opts, a[2:])
                i += 1
                continue
            if a.startswith("-E") and len(a) > 2:
                opts.excludes.append(a[2:])
                i += 1
                continue
            chars = a[1:]
            consumed = False
            for idx, ch in enumerate(chars):
                rest = chars[idx + 1:]
                if ch == "H":
                    opts.hidden = True
                elif ch == "I":
                    opts.no_ignore = True
                elif ch == "u":
                    opts.hidden = True
                    opts.no_ignore = True
                elif ch == "s":
                    opts.case = "sensitive"
                elif ch == "i":
                    opts.case = "insensitive"
                elif ch == "g":
                    opts.glob = True
                    opts.fixed = False
                elif ch == "F":
                    opts.fixed = True
                    opts.glob = False
                elif ch == "a":
                    opts.absolute = True
                elif ch == "l":
                    opts.batch_cmd = ["ls", "-l"]
                elif ch == "L":
                    opts.follow = True
                elif ch == "p":
                    opts.full_path = True
                elif ch == "0":
                    opts.print0 = True
                elif ch == "1":
                    opts.max_results = 1
                elif ch == "q":
                    opts.quiet = True
                elif ch in ("d", "E", "t", "e", "S", "o", "c", "j"):
                    if rest:
                        value = rest
                        consumed = True
                    else:
                        value, i = read_value(argv, i, "-" + ch)
                    if ch == "d":
                        opts.max_depth = int(value)
                    elif ch == "E":
                        opts.excludes.append(value)
                    elif ch == "t":
                        add_type(opts, value)
                    elif ch == "e":
                        opts.extensions.append(value.lstrip(".").lower())
                    elif ch == "S":
                        opts.size_filter = parse_size(value)
                    elif ch == "o":
                        opts.owner_filter = value
                    consumed = True
                    break
                else:
                    raise ValueError(f"unexpected argument '-{ch}'")
            if not consumed:
                i += 1
            continue
        positional.append(a)
        i += 1
    pattern = None
    paths = []
    if opts.search_paths:
        paths = opts.search_paths
        if positional:
            pattern = positional[0]
    elif positional:
        pattern = positional[0]
        paths = positional[1:] or ["."]
    else:
        paths = ["."]
    if opts.exec_cmd == []:
        raise ValueError("The argument '--exec <cmd>...' requires at least one value")
    if opts.batch_cmd == []:
        raise ValueError("The argument '--exec-batch <cmd>...' requires at least one value")
    return opts, pattern, paths


def add_type(opts, t):
    aliases = {
        "f": "file", "file": "file",
        "d": "dir", "dir": "dir", "directory": "dir",
        "l": "symlink", "symlink": "symlink",
        "x": "executable", "executable": "executable",
        "e": "empty", "empty": "empty",
        "s": "socket", "socket": "socket",
        "p": "pipe", "pipe": "pipe",
        "b": "block", "block-device": "block",
        "c": "char", "char-device": "char",
    }
    if t not in aliases:
        raise ValueError(f"invalid value '{t}' for '--type <filetype>'")
    opts.types.add(aliases[t])


def parse_size(value):
    m = re.fullmatch(r"([+-]?)(\d+)([A-Za-z]*)", value)
    if not m:
        raise ValueError(f"Invalid size: {value}")
    sign, num, unit = m.groups()
    mults = {
        "": 1, "b": 1, "k": 1000, "m": 1000 ** 2, "g": 1000 ** 3, "t": 1000 ** 4,
        "ki": 1024, "mi": 1024 ** 2, "gi": 1024 ** 3, "ti": 1024 ** 4,
    }
    unit = unit.lower()
    if unit not in mults:
        raise ValueError(f"Invalid size unit: {unit}")
    return sign or "=", int(num) * mults[unit]


def parse_time_arg(value):
    now = time.time()
    m = re.fullmatch(r"(\d+)(sec|secs|second|seconds|s|min|mins|minute|minutes|h|hour|hours|d|day|days|week|weeks|w)", value)
    if m:
        n = int(m.group(1))
        unit = m.group(2)
        if unit.startswith("s"):
            return now - n
        if unit.startswith("min"):
            return now - n * 60
        if unit.startswith("h"):
            return now - n * 3600
        if unit.startswith("d"):
            return now - n * 86400
        return now - n * 7 * 86400
    if value.startswith("@"):
        return float(value[1:])
    for fmt in ("%Y-%m-%d %H:%M:%S", "%Y-%m-%d"):
        try:
            return time.mktime(time.strptime(value, fmt))
        except ValueError:
            pass
    raise ValueError(f"Invalid date or duration: {value}")


def parse_owner_piece(value, is_group=False):
    neg = value.startswith("!")
    raw = value[1:] if neg else value
    if raw == "":
        return neg, None
    try:
        ident = int(raw)
    except ValueError:
        if is_group:
            ident = grp.getgrnam(raw).gr_gid
        else:
            ident = pwd.getpwnam(raw).pw_uid
    return neg, ident


def owner_matches(spec, st):
    user_part, sep, group_part = spec.partition(":")
    checks = []
    if user_part:
        neg, uid = parse_owner_piece(user_part, False)
        checks.append((neg, st.st_uid == uid))
    if sep:
        neg, gid = parse_owner_piece(group_part, True)
        if gid is not None:
            checks.append((neg, st.st_gid == gid))
    for neg, matched in checks:
        if neg and matched:
            return False
        if not neg and not matched:
            return False
    return True


def load_ignore_file(path):
    rules = []
    try:
        for line in Path(path).read_text().splitlines():
            line = line.strip()
            if not line or line.startswith("#") or line.startswith("!"):
                continue
            rules.append(line)
    except OSError:
        pass
    return rules


def is_hidden(rel):
    return any(part.startswith(".") and part not in (".", "..") for part in Path(rel).parts)


def match_glob(pattern, rel, name, is_dir):
    rel_dir = rel + ("/" if is_dir and not rel.endswith("/") else "")
    if "/" in pattern:
        return fnmatch.fnmatchcase(rel, pattern) or fnmatch.fnmatchcase(rel_dir, pattern)
    return fnmatch.fnmatchcase(name, pattern.rstrip("/")) or fnmatch.fnmatchcase(rel, pattern.rstrip("/"))


def ignored_by_rules(rules, rel, name, is_dir):
    for rule in rules:
        r = rule[1:] if rule.startswith("/") else rule
        dir_rule = r.endswith("/")
        r = r.rstrip("/")
        if dir_rule and not is_dir and not rel.startswith(r + "/"):
            continue
        if "/" in r:
            if fnmatch.fnmatchcase(rel, r) or rel.startswith(r + "/"):
                return True
        elif fnmatch.fnmatchcase(name, r) or fnmatch.fnmatchcase(rel, r):
            return True
    return False


def iter_entries(root, opts):
    root = Path(root)
    root_abs = root.resolve()
    ignore_rules = []
    if not opts.no_ignore:
        chain = list(root_abs.parents)[::-1] + [root_abs]
        for parent in chain:
            ignore_rules.extend(load_ignore_file(parent / ".gitignore"))
            ignore_rules.extend(load_ignore_file(parent / ".ignore"))
            ignore_rules.extend(load_ignore_file(parent / ".fdignore"))

    def walk(dir_path, depth):
        try:
            entries = sorted(os.scandir(dir_path), key=lambda e: e.name)
        except OSError:
            return
        for entry in entries:
            full = Path(entry.path)
            try:
                rel = full.relative_to(root_abs).as_posix()
            except ValueError:
                rel = os.path.relpath(full, root).replace(os.sep, "/")
            try:
                is_dir = entry.is_dir(follow_symlinks=False)
                is_link = entry.is_symlink()
            except OSError:
                continue
            display_dir = is_dir or (opts.follow and is_link and full.is_dir())
            if not opts.hidden and is_hidden(rel):
                continue
            if ignored_by_rules(opts.excludes, rel, entry.name, display_dir):
                if display_dir:
                    continue
                continue
            if not opts.no_ignore and ignored_by_rules(ignore_rules, rel, entry.name, display_dir):
                if display_dir:
                    continue
                continue
            yield full, rel, depth, display_dir
            should_descend = is_dir or (opts.follow and is_link and full.is_dir())
            if should_descend and (opts.max_depth is None or depth < opts.max_depth):
                yield from walk(full, depth + 1)

    if opts.max_depth is None or opts.max_depth >= 1:
        yield from walk(root_abs, 1)


def case_mode(opts, patterns):
    if opts.glob and opts.case == "smart":
        return False
    if opts.case == "sensitive":
        return False
    if opts.case == "insensitive":
        return True
    joined = "".join(p or "" for p in patterns)
    return not any(c.isupper() for c in joined)


def path_for_match(abs_path, rel, root, opts, is_dir):
    if opts.full_path or opts.absolute:
        s = str(abs_path.absolute())
    else:
        s = rel
    if is_dir and not s.endswith("/"):
        s += "/"
    return s


def pattern_matches(pattern, text, opts, insensitive):
    if pattern is None or pattern == "":
        return True
    cmp_text = text
    cmp_pat = pattern
    if insensitive:
        cmp_text = cmp_text.lower()
        cmp_pat = cmp_pat.lower()
    if opts.fixed:
        return cmp_pat in cmp_text
    if opts.glob:
        return fnmatch.fnmatchcase(cmp_text, cmp_pat)
    try:
        flags = re.IGNORECASE if insensitive else 0
        return re.search(pattern, text, flags) is not None
    except re.error:
        return False


def has_type(abs_path, is_dir, opts):
    types = opts.types
    if not types:
        return True
    try:
        st = abs_path.lstat()
    except OSError:
        return False
    mode = st.st_mode
    regular_types = {t for t in types if t != "empty"}
    if "executable" in regular_types:
        regular_types.add("file")
    ok = not regular_types
    if "file" in regular_types and stat.S_ISREG(mode):
        ok = True
    if "dir" in regular_types and stat.S_ISDIR(mode):
        ok = True
    if "symlink" in regular_types and stat.S_ISLNK(mode):
        ok = True
    if "socket" in regular_types and stat.S_ISSOCK(mode):
        ok = True
    if "pipe" in regular_types and stat.S_ISFIFO(mode):
        ok = True
    if "block" in regular_types and stat.S_ISBLK(mode):
        ok = True
    if "char" in regular_types and stat.S_ISCHR(mode):
        ok = True
    if "executable" in types and not os.access(abs_path, os.X_OK):
        ok = False
    if "empty" in types:
        if stat.S_ISDIR(mode):
            empty = not any(abs_path.iterdir())
        elif stat.S_ISREG(mode):
            empty = st.st_size == 0
        else:
            empty = False
        ok = ok and empty if regular_types else empty
    return ok


def passes_filters(abs_path, rel, root, opts, is_dir):
    if opts.extensions:
        ext = abs_path.name.rsplit(".", 1)[-1].lower() if "." in abs_path.name else ""
        if ext not in opts.extensions:
            return False
    if not has_type(abs_path, is_dir, opts):
        return False
    try:
        st = abs_path.stat() if opts.follow else abs_path.lstat()
    except OSError:
        return False
    if opts.size_filter and stat.S_ISREG(st.st_mode):
        sign, size = opts.size_filter
        if sign == "+" and not (st.st_size >= size):
            return False
        if sign == "-" and not (st.st_size <= size):
            return False
        if sign == "=" and not (st.st_size == size):
            return False
    if opts.changed_within is not None and not (st.st_mtime > opts.changed_within):
        return False
    if opts.changed_before is not None and not (st.st_mtime < opts.changed_before):
        return False
    if opts.owner_filter is not None and not owner_matches(opts.owner_filter, st):
        return False
    return True


def make_display(abs_path, rel, root, opts, is_dir, for_exec=False):
    if opts.absolute or Path(root).is_absolute():
        s = str(abs_path.absolute())
    else:
        s = rel
        if for_exec and opts.strip_cwd_prefix != "always":
            s = "./" + s
    if is_dir and not s.endswith("/"):
        s += "/"
    if opts.path_separator != "/":
        s = s.replace("/", opts.path_separator)
    return s


def strip_dir_slash(s):
    return s[:-1] if s.endswith("/") else s


def subst_one(template, path):
    no_slash = strip_dir_slash(path)
    parent = os.path.dirname(no_slash) or "."
    base = os.path.basename(no_slash)
    stem_path = os.path.splitext(no_slash)[0]
    stem_base = os.path.splitext(base)[0]
    return (template.replace("{{", "\0LB\0")
            .replace("}}", "\0RB\0")
            .replace("{//}", parent)
            .replace("{/}", base)
            .replace("{.}", stem_path)
            .replace("{/.}", stem_base)
            .replace("{}", path)
            .replace("\0LB\0", "{")
            .replace("\0RB\0", "}"))


def rooted_rel(root_arg, rel):
    root_path = Path(root_arg)
    if root_path.is_absolute() or str(root_arg) in ("", "."):
        return rel
    prefix = str(root_arg).rstrip("/").replace(os.sep, "/")
    return f"{prefix}/{rel}" if rel else prefix


def find_results(opts, pattern, paths):
    insensitive = case_mode(opts, [pattern] + opts.and_patterns)
    results = []
    cwd = Path.cwd()
    for root_arg in paths:
        original_root = Path(root_arg)
        root = original_root
        if not root.is_absolute():
            root = cwd / root
        for abs_path, rel, depth, is_dir in iter_entries(root, opts):
            display_rel = rooted_rel(str(root_arg), rel)
            if depth < opts.min_depth:
                continue
            match_target = path_for_match(abs_path, display_rel, root, opts, is_dir)
            if not opts.full_path and not opts.absolute:
                match_target = Path(display_rel).name
            if not pattern_matches(pattern, match_target, opts, insensitive):
                continue
            if any(not pattern_matches(p, match_target, opts, insensitive) for p in opts.and_patterns):
                continue
            if not passes_filters(abs_path, rel, root, opts, is_dir):
                continue
            result_root = original_root if original_root.is_absolute() else Path(".")
            results.append((abs_path, display_rel, result_root, is_dir))
            if opts.max_results is not None and len(results) >= opts.max_results:
                return results
    return results


def output_results(results, opts):
    if opts.quiet:
        return 0 if results else 1
    if opts.exec_cmd:
        for abs_path, rel, root, is_dir in results:
            p = make_display(abs_path, rel, root, opts, is_dir, for_exec=True)
            cmd = [subst_one(arg, p) for arg in opts.exec_cmd]
            if not any_placeholder(opts.exec_cmd):
                cmd.append(p)
            subprocess.run(cmd)
        return 0
    if opts.batch_cmd:
        paths = [make_display(a, r, root, opts, d, for_exec=True) for a, r, root, d in results]
        count = sum(arg in ("{}", "{/}", "{//}", "{.}", "{/.}") for arg in opts.batch_cmd)
        if count > 1:
            return fail("Only one placeholder allowed for batch commands")
        cmd = []
        used = False
        for arg in opts.batch_cmd:
            if arg == "{}":
                cmd.extend(paths)
                used = True
            elif arg in ("{/}", "{//}", "{.}", "{/.}"):
                cmd.extend(subst_one(arg, p) for p in paths)
                used = True
            else:
                cmd.append(arg)
        if not used:
            cmd.extend(paths)
        if cmd:
            subprocess.run(cmd)
        return 0
    sep = "\0" if opts.print0 else "\n"
    out = []
    for abs_path, rel, root, is_dir in results:
        p = make_display(abs_path, rel, root, opts, is_dir, for_exec=opts.print0)
        if opts.format is not None:
            p = subst_one(opts.format, p)
        out.append(p)
    if out:
        sys.stdout.write(sep.join(out) + sep)
    return 0


def any_placeholder(args):
    return any(("{}" in a or "{/}" in a or "{//}" in a or "{.}" in a or "{/.}" in a) for a in args)


def main(argv):
    try:
        opts, pattern, paths = parse_args(argv)
        if opts.base_directory:
            os.chdir(opts.base_directory)
        results = find_results(opts, pattern, paths)
        return output_results(results, opts)
    except ValueError as e:
        return fail(str(e))
    except BrokenPipeError:
        return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
