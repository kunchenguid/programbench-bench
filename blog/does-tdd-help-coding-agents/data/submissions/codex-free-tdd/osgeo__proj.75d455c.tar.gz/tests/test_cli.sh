#!/bin/bash
set -euo pipefail

BIN=${1:-./executable}

fail() {
  printf 'FAIL: %s\n' "$1" >&2
  exit 1
}

assert_eq() {
  local name=$1 expected=$2 actual=$3
  if [[ "$actual" != "$expected" ]]; then
    printf 'FAIL: %s\nexpected:\n%s\nactual:\n%s\n' "$name" "$expected" "$actual" >&2
    exit 1
  fi
}

out=$(printf '0 0\n10 20\n' | "$BIN" +proj=merc)
assert_eq "mercator forward default format" $'0.00\t0.00\n1113194.91\t2258423.65' "$out"

out=$(printf '1113194.91 2258423.65\n' | "$BIN" -I -f "%.8f" +proj=merc)
assert_eq "mercator inverse degrees" $'10.00000002\t20.00000001' "$out"

out=$(printf '10 20 30\n' | "$BIN" -f "%.3f" +proj=merc)
assert_eq "printf format and trailing fields" $'1113194.908\t2258423.649 30' "$out"

out=$(printf '10 20\n' | "$BIN" -r +proj=merc)
assert_eq "reverse input order" $'2226389.82\t1111475.10' "$out"

out=$(printf '20 10\n' | "$BIN" -s +proj=merc)
assert_eq "reverse output order" $'1111475.10\t2226389.82' "$out"

out=$(printf -- '-75 40\n0 0\n' | "$BIN" +proj=eqc)
assert_eq "equirectangular forward" $'-8348961.81\t4429529.03\n0.00\t0.00' "$out"

out=$(printf -- '-75 40\n0 0\n' | "$BIN" +proj=webmerc)
assert_eq "web mercator forward" $'-8348961.81\t4865942.28\n0.00\t0.00' "$out"

out=$(printf '0 0\n' | "$BIN" +proj=utm +zone=33 +datum=WGS84)
assert_eq "utm zone 33 forward" $'-1188659.41\t0.00' "$out"

out=$("$BIN" -l=merc)
[[ "$out" == $'     merc : Mercator\n\tCyl, Sph&Ell\n\tlat_ts=' ]] || fail "mercator list detail"

tmp=$(mktemp)
printf '0 0\n10 20\n' > "$tmp"
out=$("$BIN" +proj=merc "$tmp")
rm -f "$tmp"
assert_eq "file input" $'0.00\t0.00\n1113194.91\t2258423.65' "$out"

set +e
out=$("$BIN" --help 2>&1)
status=$?
set -e
[[ $status -eq 1 ]] || fail "--help exit status"
[[ "$out" == *"invalid option: --"* ]] || fail "--help error text"

set +e
out=$("$BIN" +proj=nope 2>&1)
status=$?
set -e
[[ $status -eq 3 ]] || fail "unknown projection exit status"
[[ "$out" == *"projection initialization failure"* ]] || fail "unknown projection error text"

