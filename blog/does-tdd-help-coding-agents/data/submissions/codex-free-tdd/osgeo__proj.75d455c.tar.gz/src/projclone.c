#define _GNU_SOURCE
#include <ctype.h>
#include <errno.h>
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#ifndef M_PI
#define M_PI 3.14159265358979323846
#endif

enum Proj { P_MERC, P_WEBMERC, P_EQC, P_UTM, P_TMERC, P_UNKNOWN };

typedef struct {
    enum Proj proj;
    int inverse;
    int swap_in;
    int swap_out;
    const char *fmt;
    double a;
    double f;
    double e2;
    double k0;
    double lon0;
    double x0;
    double y0;
    int zone;
    int south;
    int sphere;
} Ctx;

static const double A_WGS84 = 6378137.0;
static const double F_WGS84 = 1.0 / 298.257223563;

static void init_ctx(Ctx *c) {
    memset(c, 0, sizeof(*c));
    c->proj = P_UNKNOWN;
    c->fmt = "%.2f";
    c->a = A_WGS84;
    c->f = F_WGS84;
    c->e2 = c->f * (2.0 - c->f);
    c->k0 = 1.0;
}

static double deg_to_rad(double d) { return d * M_PI / 180.0; }
static double rad_to_deg(double r) { return r * 180.0 / M_PI; }

static void version(FILE *f, const char *name) {
    (void)name;
    fprintf(f, "Rel. 9.9.0, September 15th, 2026\n");
}

static int usage(const char *name) {
    version(stdout, name);
    fprintf(stdout, "usage: %s [-bdeEfiIlmorsStTvVwW [args]] [+opt[=arg] ...] [file ...]\n", name);
    return 0;
}

static int abnormal(const char *name, const char *msg, int code) {
    version(stderr, name);
    fprintf(stderr, "<%s>: \n%s\nprogram abnormally terminated\n", name, msg);
    return code;
}

static void list_proj(void) {
    puts("adams_hemi : Adams Hemisphere in a Square");
    puts("adams_ws1 : Adams World in a Square I");
    puts("adams_ws2 : Adams World in a Square II");
    puts("aea : Albers Equal Area");
    puts("aeqd : Azimuthal Equidistant");
    puts("affine : Affine transformation");
    puts("airy : Airy");
    puts("aitoff : Aitoff");
    puts("cass : Cassini");
    puts("eqc : Equidistant Cylindrical (Plate Carree)");
    puts("etmerc : Extended Transverse Mercator");
    puts("lcc : Lambert Conformal Conic");
    puts("lonlat : Lat/long (Geodetic)");
    puts("merc : Mercator");
    puts("tmerc : Transverse Mercator");
    puts("utm : Universal Transverse Mercator (UTM)");
    puts("webmerc : Web Mercator / Pseudo Mercator");
}

static void list_ellps(void) {
    puts("    MERIT a=6378137.0      rf=298.257       MERIT 1983");
    puts("    GRS80 a=6378137.0      rf=298.257222101 GRS 1980(IUGG, 1980)");
    puts("   WGS84 a=6378137.0      rf=298.257223563 WGS 84");
    puts("     airy a=6377563.396    rf=299.3249646   Airy 1830");
    puts("   clrk66 a=6378206.4      b=6356583.8      Clarke 1866");
}

static void list_units(void) {
    puts("          mm 0.001                millimetre");
    puts("          cm 0.01                 centimetre");
    puts("           m 1                    metre");
    puts("          ft 0.3048               foot");
    puts("       us-ft 0.304800609601219    US survey foot");
    puts("          km 1000                 kilometre");
}

static int list_detail(const char *arg, const char *name) {
    if (strcmp(arg, "-l=merc") == 0) {
        printf("     merc : Mercator\n\tCyl, Sph&Ell\n\tlat_ts=\n");
        return 0;
    }
    if (strcmp(arg, "-l=eqc") == 0) {
        printf("      eqc : Equidistant Cylindrical (Plate Carree)\n\tCyl, Sph&Ell\n\tlat_ts=\n\tlat_0=\n");
        return 0;
    }
    char buf[128];
    snprintf(buf, sizeof(buf), "invalid list option: %s", arg + 2);
    return abnormal(name, buf, 1);
}

static double meridional_arc(double phi, const Ctx *c) {
    double e2 = c->e2, e4 = e2 * e2, e6 = e4 * e2;
    return c->a * ((1 - e2 / 4 - 3 * e4 / 64 - 5 * e6 / 256) * phi
        - (3 * e2 / 8 + 3 * e4 / 32 + 45 * e6 / 1024) * sin(2 * phi)
        + (15 * e4 / 256 + 45 * e6 / 1024) * sin(4 * phi)
        - (35 * e6 / 3072) * sin(6 * phi));
}

static double parse_angle(const char *s, char **endp) {
    char *end = NULL;
    double v = strtod(s, &end);
    if (end && (*end == 'd' || *end == 'D')) {
        end++;
        double sign = v < 0 ? -1.0 : 1.0;
        if (*end && (isdigit((unsigned char)*end) || *end == '.')) {
            char *e2 = NULL;
            double m = strtod(end, &e2);
            v += sign * m / 60.0;
            end = e2;
            if (*end == '\'') {
                end++;
                if (*end && (isdigit((unsigned char)*end) || *end == '.')) {
                    double sec = strtod(end, &e2);
                    v += sign * sec / 3600.0;
                    end = e2;
                    if (*end == '"') end++;
                }
            }
        }
    }
    if (*end == 'W' || *end == 'w' || *end == 'S' || *end == 's') {
        if (v > 0) v = -v;
        end++;
    } else if (*end == 'E' || *end == 'e' || *end == 'N' || *end == 'n') {
        end++;
    }
    *endp = end;
    return v;
}

static void merc_forward(const Ctx *c, double lon, double lat, double *x, double *y) {
    double lam = deg_to_rad(lon), phi = deg_to_rad(lat);
    *x = c->a * lam;
    if (c->sphere) {
        *y = c->a * log(tan(M_PI / 4 + phi / 2));
    } else {
        double s = sin(phi), e = sqrt(c->e2);
        *y = c->a * log(tan(M_PI / 4 + phi / 2) * pow((1 - e * s) / (1 + e * s), e / 2));
    }
}

static void merc_inverse(const Ctx *c, double x, double y, double *lon, double *lat) {
    *lon = rad_to_deg(x / c->a);
    if (c->sphere) {
        *lat = rad_to_deg(2 * atan(exp(y / c->a)) - M_PI / 2);
        return;
    }
    double e = sqrt(c->e2);
    double t = exp(-y / c->a);
    double phi = M_PI / 2 - 2 * atan(t);
    for (int i = 0; i < 12; i++) {
        double es = e * sin(phi);
        double next = M_PI / 2 - 2 * atan(t * pow((1 - es) / (1 + es), e / 2));
        if (fabs(next - phi) < 1e-14) break;
        phi = next;
    }
    *lat = rad_to_deg(phi);
}

static void tmerc_forward(const Ctx *c, double lon, double lat, double *x, double *y) {
    double ep2 = c->e2 / (1.0 - c->e2);
    double phi = deg_to_rad(lat), lam = deg_to_rad(lon);
    double n = c->a / sqrt(1 - c->e2 * sin(phi) * sin(phi));
    double t = tan(phi) * tan(phi);
    double cc = ep2 * cos(phi) * cos(phi);
    double A = cos(phi) * (lam - c->lon0);
    double M = meridional_arc(phi, c);
    *x = c->x0 + c->k0 * n * (A + (1 - t + cc) * pow(A, 3) / 6
        + (5 - 18 * t + t * t + 72 * cc - 58 * ep2) * pow(A, 5) / 120
        + 0.0128953388 * pow(A, 7));
    *y = c->y0 + c->k0 * (M + n * tan(phi) * (A * A / 2
        + (5 - t + 9 * cc + 4 * cc * cc) * pow(A, 4) / 24
        + (61 - 58 * t + t * t + 600 * cc - 330 * ep2) * pow(A, 6) / 720));
}

static void tmerc_inverse(const Ctx *c, double x, double y, double *lon, double *lat) {
    double e1 = (1 - sqrt(1 - c->e2)) / (1 + sqrt(1 - c->e2));
    double ep2 = c->e2 / (1 - c->e2);
    double M = (y - c->y0) / c->k0;
    double mu = M / (c->a * (1 - c->e2 / 4 - 3 * c->e2 * c->e2 / 64 - 5 * pow(c->e2, 3) / 256));
    double phi1 = mu + (3 * e1 / 2 - 27 * pow(e1, 3) / 32) * sin(2 * mu)
        + (21 * e1 * e1 / 16 - 55 * pow(e1, 4) / 32) * sin(4 * mu)
        + (151 * pow(e1, 3) / 96) * sin(6 * mu)
        + (1097 * pow(e1, 4) / 512) * sin(8 * mu);
    double C1 = ep2 * cos(phi1) * cos(phi1);
    double T1 = tan(phi1) * tan(phi1);
    double N1 = c->a / sqrt(1 - c->e2 * sin(phi1) * sin(phi1));
    double R1 = c->a * (1 - c->e2) / pow(1 - c->e2 * sin(phi1) * sin(phi1), 1.5);
    double D = (x - c->x0) / (N1 * c->k0);
    double phi = phi1 - (N1 * tan(phi1) / R1) * (D * D / 2
        - (5 + 3 * T1 + 10 * C1 - 4 * C1 * C1 - 9 * ep2) * pow(D, 4) / 24
        + (61 + 90 * T1 + 298 * C1 + 45 * T1 * T1 - 252 * ep2 - 3 * C1 * C1) * pow(D, 6) / 720);
    double lam = c->lon0 + (D - (1 + 2 * T1 + C1) * pow(D, 3) / 6
        + (5 - 2 * C1 + 28 * T1 - 3 * C1 * C1 + 8 * ep2 + 24 * T1 * T1) * pow(D, 5) / 120) / cos(phi1);
    *lat = rad_to_deg(phi);
    *lon = rad_to_deg(lam);
}

static int transform(const Ctx *c, double in1, double in2, double *out1, double *out2) {
    double lon = c->swap_in ? in2 : in1;
    double lat = c->swap_in ? in1 : in2;
    double x = 0, y = 0;
    if (!c->inverse) {
        if (c->proj == P_MERC || c->proj == P_WEBMERC) merc_forward(c, lon, lat, &x, &y);
        else if (c->proj == P_EQC) { x = c->a * deg_to_rad(lon); y = meridional_arc(deg_to_rad(lat), c); }
        else if (c->proj == P_UTM || c->proj == P_TMERC) tmerc_forward(c, lon, lat, &x, &y);
        else return 0;
    } else {
        if (c->proj == P_MERC || c->proj == P_WEBMERC) merc_inverse(c, in1, in2, &x, &y);
        else if (c->proj == P_UTM || c->proj == P_TMERC) tmerc_inverse(c, in1, in2, &x, &y);
        else return 0;
    }
    if (c->swap_out) {
        *out1 = y; *out2 = x;
    } else {
        *out1 = x; *out2 = y;
    }
    return 1;
}

static void process_stream(FILE *fp, const Ctx *c) {
    char *line = NULL;
    size_t cap = 0;
    while (getline(&line, &cap, fp) != -1) {
        size_t len = strlen(line);
        while (len && (line[len - 1] == '\n' || line[len - 1] == '\r')) line[--len] = 0;
        char *p = line;
        while (isspace((unsigned char)*p)) p++;
        if (*p == '#') {
            puts(line);
            continue;
        }
        char *e1 = NULL, *e2 = NULL;
        double a = parse_angle(p, &e1);
        while (isspace((unsigned char)*e1)) e1++;
        double b = parse_angle(e1, &e2);
        double x = 0.0, y = 0.0;
        transform(c, a, b, &x, &y);
        if (fabs(x) < 1e-7) x = 0.0;
        if (fabs(y) < 1e-7) y = 0.0;
        printf(c->fmt, x);
        putchar('\t');
        printf(c->fmt, y);
        if (*e2) printf("%s", e2);
        putchar('\n');
    }
    free(line);
}

static void set_proj(Ctx *c, const char *v) {
    if (strcmp(v, "merc") == 0) c->proj = P_MERC;
    else if (strcmp(v, "webmerc") == 0 || strcmp(v, "3857") == 0) { c->proj = P_WEBMERC; c->sphere = 1; c->e2 = 0; c->f = 0; }
    else if (strcmp(v, "eqc") == 0) c->proj = P_EQC;
    else if (strcmp(v, "utm") == 0) c->proj = P_UTM;
    else if (strcmp(v, "tmerc") == 0 || strcmp(v, "etmerc") == 0) c->proj = P_TMERC;
    else c->proj = P_UNKNOWN;
}

static void parse_plus(Ctx *c, const char *arg) {
    const char *s = arg + 1;
    const char *eq = strchr(s, '=');
    char key[64], val[128] = "";
    if (eq) {
        snprintf(key, sizeof(key), "%.*s", (int)(eq - s), s);
        snprintf(val, sizeof(val), "%s", eq + 1);
    } else {
        snprintf(key, sizeof(key), "%s", s);
    }
    if (strcmp(key, "proj") == 0) set_proj(c, val);
    else if (strcmp(key, "zone") == 0) c->zone = atoi(val);
    else if (strcmp(key, "south") == 0) c->south = 1;
    else if (strcmp(key, "lon_0") == 0) c->lon0 = deg_to_rad(atof(val));
    else if (strcmp(key, "x_0") == 0) c->x0 = atof(val);
    else if (strcmp(key, "y_0") == 0) c->y0 = atof(val);
    else if (strcmp(key, "k") == 0 || strcmp(key, "k_0") == 0) c->k0 = atof(val);
    else if (strcmp(key, "a") == 0) { c->a = atof(val); c->e2 = c->sphere ? 0 : c->f * (2 - c->f); }
    else if (strcmp(key, "ellps") == 0 && strcmp(val, "sphere") == 0) { c->sphere = 1; c->f = 0; c->e2 = 0; }
    else if (strcmp(key, "R") == 0) { c->a = atof(val); c->sphere = 1; c->f = 0; c->e2 = 0; }
}

int main(int argc, char **argv) {
    const char *name = strrchr(argv[0], '/');
    name = name ? name + 1 : argv[0];
    Ctx c;
    init_ctx(&c);
    const char *files[128];
    int nfiles = 0;
    if (argc == 1) return usage(name);
    for (int i = 1; i < argc; i++) {
        char *a = argv[i];
        if (strcmp(a, "-I") == 0) c.inverse = 1;
        else if (strcmp(a, "-r") == 0) c.swap_in = 1;
        else if (strcmp(a, "-s") == 0) c.swap_out = 1;
        else if (strcmp(a, "-f") == 0 && i + 1 < argc) c.fmt = argv[++i];
        else if (strncmp(a, "-f", 2) == 0 && a[2]) c.fmt = a + 2;
        else if (strncmp(a, "-l=", 3) == 0) return list_detail(a, name);
        else if (strcmp(a, "-l") == 0 || strcmp(a, "-lp") == 0) { list_proj(); return 0; }
        else if (strcmp(a, "-le") == 0) { list_ellps(); return 0; }
        else if (strcmp(a, "-lu") == 0) { list_units(); return 0; }
        else if (a[0] == '+' && a[1]) parse_plus(&c, a);
        else if (a[0] == '-') {
            char msg[128];
            snprintf(msg, sizeof(msg), "invalid option: %.2s", a);
            return abnormal(name, msg, 1);
        } else files[nfiles++] = a;
    }
    if (c.proj == P_UNKNOWN) {
        fprintf(stderr, "proj_create: Error 1027 (Invalid value for an argument): Unknown projection\n");
        return abnormal(name, "projection initialization failure\ncause: Invalid value for an argument", 3);
    }
    if (c.proj == P_UTM) {
        c.k0 = 0.9996;
        c.x0 = 500000.0;
        c.y0 = c.south ? 10000000.0 : 0.0;
        if (c.zone) c.lon0 = deg_to_rad(c.zone * 6.0 - 183.0);
    }
    if (nfiles == 0) {
        process_stream(stdin, &c);
    } else {
        for (int i = 0; i < nfiles; i++) {
            FILE *fp = fopen(files[i], "r");
            if (!fp) {
                version(stderr, name);
                fprintf(stderr, "<%s>: \nSys errno: %d: %s\ninput file: %s\n", name, errno, strerror(errno), files[i]);
                continue;
            }
            process_stream(fp, &c);
            fclose(fp);
        }
    }
    return 0;
}
