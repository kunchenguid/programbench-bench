import os
import stat
import subprocess
import tempfile
import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
APP = ROOT / "eureka.py"


def run_cmd(args, *, home=None, input_text=None, env=None, timeout=5):
    merged_env = os.environ.copy()
    if home is not None:
        merged_env["HOME"] = str(home)
    if env:
        merged_env.update({k: str(v) for k, v in env.items()})
    return subprocess.run(
        ["python3", str(APP), *args],
        input=input_text,
        text=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        env=merged_env,
        timeout=timeout,
    )


class EurekaBehaviorTests(unittest.TestCase):
    def test_help_and_version_match_user_facing_cli(self):
        help_result = run_cmd(["--help"])
        self.assertEqual(help_result.returncode, 0)
        self.assertIn("Input and store your ideas without leaving the terminal", help_result.stdout)
        self.assertIn("Usage: executable [OPTIONS]", help_result.stdout)
        self.assertIn("--clear-config", help_result.stdout)
        self.assertIn("-v, --view", help_result.stdout)

        version_result = run_cmd(["--version"])
        self.assertEqual(version_result.returncode, 0)
        self.assertEqual(version_result.stdout, "eureka 2.0.0\n")

    def test_first_run_writes_repo_config(self):
        with tempfile.TemporaryDirectory() as tmp:
            home = Path(tmp) / "home"
            repo = Path(tmp) / "ideas"
            home.mkdir()
            repo.mkdir()
            (repo / "README.md").write_text("# Ideas\n")

            result = run_cmd([], home=home, input_text=f"{repo}\n")

            self.assertEqual(result.returncode, 0)
            self.assertIn("First Time Setup", result.stdout)
            self.assertIn("First time setup complete. Happy ideation!", result.stdout)
            self.assertEqual(
                (home / ".config" / "eureka" / "config.json").read_text(),
                f'{{"repo":"{repo}"}}',
            )

    def test_clear_config_removes_config_silently_when_present(self):
        with tempfile.TemporaryDirectory() as tmp:
            home = Path(tmp) / "home"
            config_dir = home / ".config" / "eureka"
            config_dir.mkdir(parents=True)
            (config_dir / "config.json").write_text('{"repo":"/tmp/ideas"}')

            result = run_cmd(["--clear-config"], home=home)

            self.assertEqual(result.returncode, 0)
            self.assertEqual(result.stdout, "")
            self.assertEqual(result.stderr, "")
            self.assertFalse((config_dir / "config.json").exists())

    def test_clear_config_reports_short_error_when_missing(self):
        with tempfile.TemporaryDirectory() as tmp:
            home = Path(tmp) / "home"
            home.mkdir()

            result = run_cmd(["--clear-config"], home=home)

            self.assertEqual(result.returncode, 0)
            self.assertEqual(result.stdout, "")
            self.assertEqual(result.stderr, " ERROR eureka > No such file or directory (os error 2)\n")

    def test_first_run_accepts_path_without_validation(self):
        with tempfile.TemporaryDirectory() as tmp:
            home = Path(tmp) / "home"
            home.mkdir()
            repo = Path(tmp) / "does-not-exist"

            result = run_cmd([], home=home, input_text=f"{repo}\n")

            self.assertEqual(result.returncode, 0)
            self.assertIn("First time setup complete. Happy ideation!", result.stdout)
            self.assertEqual(
                (home / ".config" / "eureka" / "config.json").read_text(),
                f'{{"repo":"{repo}"}}',
            )

    def test_view_invokes_configured_pager_with_readme(self):
        with tempfile.TemporaryDirectory() as tmp:
            home = Path(tmp) / "home"
            repo = Path(tmp) / "ideas"
            bindir = Path(tmp) / "bin"
            (home / ".config" / "eureka").mkdir(parents=True)
            repo.mkdir()
            bindir.mkdir()
            (repo / "README.md").write_text("# Ideas\n\n- old\n")
            (home / ".config" / "eureka" / "config.json").write_text(f'{{"repo":"{repo}"}}')
            pager = bindir / "pager"
            pager.write_text(
                "#!/bin/sh\n"
                "printf '%s' \"$1\" > \"$HOME/pager.arg\"\n"
                "cat \"$1\" > \"$HOME/pager.out\"\n"
            )
            pager.chmod(pager.stat().st_mode | stat.S_IXUSR)

            result = run_cmd(["--view"], home=home, env={"PAGER": pager})

            self.assertEqual(result.returncode, 0)
            self.assertEqual((home / "pager.arg").read_text(), str(repo / "README.md"))
            self.assertEqual((home / "pager.out").read_text(), "# Ideas\n\n- old\n")

    def test_view_reports_missing_repo_field_in_config(self):
        with tempfile.TemporaryDirectory() as tmp:
            home = Path(tmp) / "home"
            config_dir = home / ".config" / "eureka"
            config_dir.mkdir(parents=True)
            (config_dir / "config.json").write_text("{}")

            result = run_cmd(["--view"], home=home)

            self.assertEqual(result.returncode, 0)
            self.assertEqual(result.stdout, "")
            self.assertIn(" ERROR eureka > missing field `repo`", result.stderr)

    def test_capture_prompts_for_summary_edits_readme_and_commits(self):
        with tempfile.TemporaryDirectory() as tmp:
            home = Path(tmp) / "home"
            repo = Path(tmp) / "ideas"
            bindir = Path(tmp) / "bin"
            (home / ".config" / "eureka").mkdir(parents=True)
            repo.mkdir()
            bindir.mkdir()
            (repo / "README.md").write_text("# Ideas\n")
            subprocess.run(["git", "-C", str(repo), "init", "-q"], check=True)
            subprocess.run(["git", "-C", str(repo), "config", "user.email", "a@b.c"], check=True)
            subprocess.run(["git", "-C", str(repo), "config", "user.name", "Agent"], check=True)
            subprocess.run(["git", "-C", str(repo), "add", "README.md"], check=True)
            subprocess.run(["git", "-C", str(repo), "commit", "-qm", "init"], check=True)
            (home / ".config" / "eureka" / "config.json").write_text(f'{{"repo":"{repo}"}}')
            editor = bindir / "editor"
            editor.write_text(
                "#!/bin/sh\n"
                "printf '%s' \"$1\" > \"$HOME/editor.arg\"\n"
                "printf 'body line\\nsecond line\\n' > \"$1\"\n"
            )
            editor.chmod(editor.stat().st_mode | stat.S_IXUSR)

            result = run_cmd([], home=home, input_text="Short summary\n", env={"EDITOR": editor})

            self.assertEqual(result.returncode, 0)
            self.assertIn(">> Idea summary", result.stdout)
            self.assertEqual((home / "editor.arg").read_text(), str(repo / "README.md"))
            self.assertEqual((repo / "README.md").read_text(), "body line\nsecond line\n")
            log = subprocess.check_output(["git", "-C", str(repo), "log", "--format=%s", "-1"], text=True)
            self.assertEqual(log, "Short summary\n")


if __name__ == "__main__":
    unittest.main()
