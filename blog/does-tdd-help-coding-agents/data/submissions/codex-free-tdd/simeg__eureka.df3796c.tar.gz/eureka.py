#!/usr/bin/env python3
import json
import os
import shutil
import subprocess
import sys
from pathlib import Path


HELP = """Input and store your ideas without leaving the terminal

Usage: executable [OPTIONS]

Options:
      --clear-config  Clear your stored configuration
  -v, --view          View ideas with your $PAGER env variable. If unset use less
  -h, --help          Print help
  -V, --version       Print version
"""

SETUP = """\033[0m\033[33m############################################################
####                  First Time Setup                  ####
############################################################

This tool requires you to have a repository with a README.md
in the root folder. The markdown file is where your ideas
will be stored.

Once first time setup has completed, simply run Eureka again
to begin writing down ideas.
        
\033[0m"""

GREEN_PROMPT = "\033[0m\033[1m\033[32m{label}\n\033[0m> "


def config_path() -> Path:
    return Path(os.environ.get("HOME", str(Path.home()))) / ".config" / "eureka" / "config.json"


def log_error(message: str) -> None:
    print(f" ERROR eureka > {message}", file=sys.stderr)


def read_config() -> dict:
    with config_path().open() as fh:
        return json.load(fh)


def write_config(repo: str) -> None:
    path = config_path()
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps({"repo": repo}, separators=(",", ":")))


def clear_config() -> int:
    try:
        config_path().unlink()
    except FileNotFoundError:
        log_error("No such file or directory (os error 2)")
    return 0


def first_time_setup() -> int:
    sys.stdout.write(SETUP)
    while True:
        sys.stdout.write(GREEN_PROMPT.format(label="Absolute path to your idea repo"))
        sys.stdout.flush()
        line = sys.stdin.readline()
        if line == "":
            continue
        repo = line.strip()
        if not repo:
            continue
        write_config(repo)
        print("First time setup complete. Happy ideation!")
        return 0


def configured_repo() -> Path | None:
    try:
        data = read_config()
        if "repo" not in data:
            log_error("missing field `repo` at line 1 column 2")
            return None
        return Path(data["repo"])
    except Exception as exc:
        log_error(str(exc))
        return None


def view_ideas() -> int:
    repo = configured_repo()
    if repo is None:
        return 0
    pager = os.environ.get("PAGER") or "less"
    try:
        subprocess.run([pager, str(repo / "README.md")])
    except FileNotFoundError as exc:
        log_error(str(exc))
    return 0


def run_git(repo: Path, args: list[str], *, report_errors: bool = True) -> subprocess.CompletedProcess:
    result = subprocess.run(["git", "-C", str(repo), *args], stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
    if report_errors and result.returncode != 0:
        err = result.stderr.strip() or result.stdout.strip()
        if err:
            log_error(err.splitlines()[-1])
    return result


def capture_idea() -> int:
    repo = configured_repo()
    if repo is None:
        return first_time_setup()

    sys.stdout.write(GREEN_PROMPT.format(label=">> Idea summary"))
    sys.stdout.flush()
    summary = sys.stdin.readline().strip()
    if not summary:
        return 0

    readme = repo / "README.md"
    editor = os.environ.get("EDITOR") or os.environ.get("VISUAL") or "vim"
    try:
        subprocess.run([editor, str(readme)])
    except FileNotFoundError as exc:
        log_error(str(exc))
        return 0

    print("Adding and committing your new idea to main..")
    run_git(repo, ["add", "README.md"])
    run_git(repo, ["commit", "-m", summary])
    print("Added and committed!")
    print("Pushing your new idea..")
    run_git(repo, ["push", "origin", "main"])
    return 0


def main(argv: list[str]) -> int:
    if len(argv) > 1:
        arg = argv[1]
        if arg in ("-h", "--help"):
            sys.stdout.write(HELP)
            return 0
        if arg in ("-V", "--version"):
            print("eureka 2.0.0")
            return 0
        if arg == "--clear-config":
            return clear_config()
        if arg in ("-v", "--view"):
            return view_ideas()
        print(f"error: unexpected argument '{arg}' found\n", file=sys.stderr)
        print("Usage: executable [OPTIONS]\n", file=sys.stderr)
        print("For more information, try '--help'.", file=sys.stderr)
        return 2

    if not config_path().exists():
        return first_time_setup()
    return capture_idea()


if __name__ == "__main__":
    raise SystemExit(main(sys.argv))
