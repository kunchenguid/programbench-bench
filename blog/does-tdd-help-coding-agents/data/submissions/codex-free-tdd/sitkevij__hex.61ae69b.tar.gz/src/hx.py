#!/usr/bin/env python3
import math
import os
import sys


VERSION = "hx 0.7.0"
DESC = "Futuristic take on hexdump, made in Rust."
FORMATS = {"o", "x", "X", "b"}
ARRAYS = {"r", "c", "g", "p", "k", "j", "s", "f"}


def help_text(prog):
    return f"""{DESC}


Usage: {prog} [OPTIONS] [INPUTFILE]

Arguments:
  [INPUTFILE]  Pass file path as an argument, or input data may be passed via stdin

Options:
  -c, --cols <columns>        Set column length
  -l, --len <len>             Set <len> bytes to read
  -f, --format <format>       Set format of octet: Octal (o), LowerHex (x), UpperHex (X), Binary (b) [possible values: o, x, X, b]
  -t, --color <color>         Set color tint terminal output. 0 to disable, 1 to enable [possible values: 0, 1]
  -a, --array <array_format>  Set source code format output: rust (r), C (c), golang (g), python (p), kotlin (k), java (j), swift (s), fsharp (f) [possible values: r, c, g, p, k, j, s, f]
  -u, --func <func_length>    Set function wave length
  -p, --places <func_places>  Set function wave output decimal places
  -r, --prefix <prefix>       Include prefix in output (e.g. 0x/0b/0o). 0 to disable, 1 to enable [possible values: 0, 1]
  -h, --help                  Print help
  -V, --version               Print version
"""


def parse_int(value, flag, name):
    try:
        return int(value, 10)
    except ValueError:
        print(f"{flag}, --{name} <integer> expected. ParseIntError {{ kind: InvalidDigit }}", file=sys.stderr)
        print("error: invalid digit found in string", file=sys.stderr)
        raise SystemExit(1)


def clap_invalid(flag, placeholder, value, possible):
    print(f"error: invalid value '{value}' for '{flag} <{placeholder}>'", file=sys.stderr)
    print(f"  [possible values: {', '.join(possible)}]", file=sys.stderr)
    print("", file=sys.stderr)
    print("For more information, try '--help'.", file=sys.stderr)
    raise SystemExit(2)


def parse_args(argv):
    opts = {
        "cols": 10,
        "length": None,
        "format": "x",
        "color": 1,
        "array": None,
        "func": None,
        "places": 4,
        "prefix": 1,
        "input": None,
    }
    i = 0
    while i < len(argv):
        arg = argv[i]
        if arg in ("-h", "--help"):
            print(help_text(os.path.basename(sys.argv[0])), end="")
            raise SystemExit(0)
        if arg in ("-V", "--version"):
            print(VERSION)
            raise SystemExit(0)
        if arg in ("-c", "--cols", "-l", "--len", "-f", "--format", "-t", "--color", "-a", "--array", "-u", "--func", "-p", "--places", "-r", "--prefix"):
            if i + 1 >= len(argv):
                print(f"error: a value is required for '{arg}' but none was supplied", file=sys.stderr)
                raise SystemExit(2)
            val = argv[i + 1]
            i += 2
            if arg in ("-c", "--cols"):
                opts["cols"] = max(1, parse_int(val, "-c", "cols") + (1 if int(val, 10) == 0 else 0))
            elif arg in ("-l", "--len"):
                opts["length"] = max(0, parse_int(val, "-l", "len"))
            elif arg in ("-u", "--func"):
                opts["func"] = max(0, parse_int(val, "-u", "func"))
            elif arg in ("-p", "--places"):
                opts["places"] = max(0, parse_int(val, "-p", "places"))
            elif arg in ("-f", "--format"):
                if val not in FORMATS:
                    clap_invalid("--format", "format", val, ["o", "x", "X", "b"])
                opts["format"] = val
            elif arg in ("-t", "--color"):
                if val not in {"0", "1"}:
                    clap_invalid("--color", "color", val, ["0", "1"])
                opts["color"] = int(val)
            elif arg in ("-r", "--prefix"):
                if val not in {"0", "1"}:
                    clap_invalid("--prefix", "prefix", val, ["0", "1"])
                opts["prefix"] = int(val)
            else:
                if val not in ARRAYS:
                    clap_invalid("--array", "array_format", val, ["r", "c", "g", "p", "k", "j", "s", "f"])
                opts["array"] = val
            continue
        if arg.startswith("--") and "=" in arg:
            name, val = arg.split("=", 1)
            argv = argv[:i] + [name, val] + argv[i + 1 :]
            continue
        if arg.startswith("-") and len(arg) > 2:
            short = arg[:2]
            val = arg[2:]
            if short in {"-c", "-l", "-f", "-t", "-a", "-u", "-p", "-r"}:
                argv = argv[:i] + [short, val] + argv[i + 1 :]
                continue
        if opts["input"] is None:
            opts["input"] = arg
            i += 1
            continue
        print(f"error: unexpected argument '{arg}' found", file=sys.stderr)
        raise SystemExit(2)
    return opts


def load_data(opts):
    if opts["func"] is not None:
        return b""
    try:
        if opts["input"]:
            data = open(opts["input"], "rb").read()
        else:
            data = sys.stdin.buffer.read()
    except OSError as exc:
        print(f"error: {exc.strerror} (os error {exc.errno})", file=sys.stderr)
        raise SystemExit(1)
    if opts["length"] is not None:
        data = data[: opts["length"]]
    return data


def byte_text(byte, fmt="x", prefix=True):
    if fmt == "x":
        body = f"{byte:02x}"
        pre = "0x"
    elif fmt == "X":
        body = f"{byte:02X}"
        pre = "0x"
    elif fmt == "o":
        body = f"{byte:04o}"
        pre = "0o"
    else:
        body = f"{byte:08b}"
        pre = "0b"
    return (pre if prefix else "") + body


def ascii_char(byte):
    ch = chr(byte)
    return ch if 32 <= byte <= 126 else "."


def color_code(byte):
    return 22 if byte == 0 else byte


def tint(text, byte, enabled):
    if not enabled:
        return text
    return f"\033[38;5;{color_code(byte)}m{text}\033[0m"


def dump_output(data, opts):
    cols = opts["cols"]
    fmt = opts["format"]
    prefix = bool(opts["prefix"])
    color = bool(opts["color"]) and "NO_COLOR" not in os.environ
    cell = 5
    lines = []
    offset = 0
    while offset < len(data) or offset == 0 or (len(data) > 0 and len(data) % cols == 0 and offset == len(data)):
        chunk = data[offset : offset + cols]
        rendered = [tint(byte_text(b, fmt, prefix), b, color) for b in chunk]
        byte_part = " ".join(rendered)
        if len(chunk) < cols:
            if chunk:
                pad = (cols - len(chunk)) * cell
            else:
                pad = 0 if cols == 1 else cols * cell - 1
            byte_part += " " * pad
        ascii_part = "".join(tint(ascii_char(b), b, color) for b in chunk)
        if not chunk and cols == 1:
            lines.append(f"0x{offset:06x}: ")
        else:
            lines.append(f"0x{offset:06x}: {byte_part} {ascii_part}")
        offset += cols
        if not data and offset >= cols:
            break
        if offset > len(data):
            break
    lines.append(f"   bytes: {len(data)}")
    return "\n".join(lines) + "\n"


def array_output(data, opts):
    cols = opts["cols"]
    kind = opts["array"]
    vals = [byte_text(b, "x", True) + ("uy" if kind == "f" else "") for b in data]
    sep = "; " if kind == "f" else ", "
    rows = []
    for start in range(0, len(vals), cols):
        row = sep.join(vals[start : start + cols])
        full = start + cols < len(vals)
        if kind == "g":
            row += ", "
        elif kind != "f" and full:
            row += ", "
        elif kind == "f" and full:
            row += "; "
        rows.append("    " + row)
    headers = {
        "r": f"let ARRAY: [u8; {len(data)}] = [",
        "c": f"unsigned char ARRAY[{len(data)}] = {{",
        "g": f"a := [{len(data)}]byte{{",
        "p": "a = [",
        "k": "val a = byteArrayOf(",
        "j": "byte[] a = new byte[]{",
        "s": "let a: [UInt8] = [",
        "f": "let a = [|",
    }
    footers = {"r": "];", "c": "};", "g": "}", "p": "]", "k": ")", "j": "};", "s": "]", "f": "|]"}
    return "\n".join([headers[kind], *rows, footers[kind]]) + "\n"


def func_output(length, places):
    if length <= 0:
        return "\n"
    vals = [f"{math.sin(i * math.pi / (2 * length)):.{places}f}" for i in range(length)]
    out = []
    for start in range(0, len(vals), 10):
        out.append("".join(v + "," for v in vals[start : start + 10]))
    if length % 10 == 0:
        out.append("")
    return "\n".join(out) + "\n"


def main(argv=None):
    opts = parse_args(list(sys.argv[1:] if argv is None else argv))
    if opts["func"] is not None:
        sys.stdout.write(func_output(opts["func"], opts["places"]))
        return 0
    data = load_data(opts)
    if opts["array"]:
        sys.stdout.write(array_output(data, opts))
    else:
        sys.stdout.write(dump_output(data, opts))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
