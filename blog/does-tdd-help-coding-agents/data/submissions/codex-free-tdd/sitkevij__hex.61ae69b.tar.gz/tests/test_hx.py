import os
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
HX = ROOT / "src" / "hx.py"


def run_hx(args, data=None, env=None):
    full_env = os.environ.copy()
    full_env.update(env or {})
    return subprocess.run(
        [sys.executable, str(HX), *args],
        input=data,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        env=full_env,
    )


class HxTests(unittest.TestCase):
    def make_file(self, data):
        fd, name = tempfile.mkstemp()
        os.close(fd)
        Path(name).write_bytes(data)
        self.addCleanup(lambda: Path(name).unlink(missing_ok=True))
        return name

    def test_default_dump_reads_file_with_no_color(self):
        path = self.make_file(b"abc\n0123456789")
        proc = run_hx(["-t", "0", path])
        self.assertEqual(proc.returncode, 0, proc.stderr.decode())
        self.assertEqual(
            proc.stdout.decode(),
            "0x000000: 0x61 0x62 0x63 0x0a 0x30 0x31 0x32 0x33 0x34 0x35 abc.012345\n"
            "0x00000a: 0x36 0x37 0x38 0x39                               6789\n"
            "   bytes: 14\n",
        )

    def test_stdin_and_len_limit(self):
        proc = run_hx(["-t", "0", "-l", "5"], data=b"abcdef")
        self.assertEqual(proc.returncode, 0, proc.stderr.decode())
        self.assertEqual(
            proc.stdout.decode(),
            "0x000000: 0x61 0x62 0x63 0x64 0x65                          abcde\n"
            "   bytes: 5\n",
        )

    def test_exact_full_row_emits_empty_offset_row(self):
        path = self.make_file(b"abcdefghij")
        proc = run_hx(["-t", "0", path])
        self.assertEqual(proc.returncode, 0, proc.stderr.decode())
        self.assertEqual(
            proc.stdout.decode(),
            "0x000000: 0x61 0x62 0x63 0x64 0x65 0x66 0x67 0x68 0x69 0x6a abcdefghij\n"
            "0x00000a:                                                   \n"
            "   bytes: 10\n",
        )

    def test_zero_cols_uses_single_column_with_unpadded_empty_row(self):
        path = self.make_file(b"ab")
        proc = run_hx(["-t", "0", "-c", "0", path])
        self.assertEqual(proc.returncode, 0, proc.stderr.decode())
        self.assertEqual(
            proc.stdout.decode(),
            "0x000000: 0x61 a\n"
            "0x000001: 0x62 b\n"
            "0x000002: \n"
            "   bytes: 2\n",
        )

    def test_upper_octal_binary_and_prefix_flags(self):
        path = self.make_file(bytes([0, 1, 10, 31, 32, 255]))
        upper = run_hx(["-t", "0", "-f", "X", path]).stdout.decode()
        octal = run_hx(["-t", "0", "-f", "o", path]).stdout.decode()
        binary = run_hx(["-t", "0", "-f", "b", "-r", "0", path]).stdout.decode()
        self.assertEqual(upper, "0x000000: 0x00 0x01 0x0A 0x1F 0x20 0xFF                     .... .\n   bytes: 6\n")
        self.assertEqual(octal, "0x000000: 0o0000 0o0001 0o0012 0o0037 0o0040 0o0377                     .... .\n   bytes: 6\n")
        self.assertEqual(binary, "0x000000: 00000000 00000001 00001010 00011111 00100000 11111111                     .... .\n   bytes: 6\n")

    def test_c_and_go_array_output(self):
        path = self.make_file(bytes(range(12)))
        c = run_hx(["-a", "c", path]).stdout.decode()
        go = run_hx(["-a", "g", "-c", "4", path]).stdout.decode()
        self.assertEqual(c, "unsigned char ARRAY[12] = {\n    0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08, 0x09, \n    0x0a, 0x0b\n};\n")
        self.assertEqual(go, "a := [12]byte{\n    0x00, 0x01, 0x02, 0x03, \n    0x04, 0x05, 0x06, 0x07, \n    0x08, 0x09, 0x0a, 0x0b, \n}\n")

    def test_function_wave_output(self):
        proc = run_hx(["-u", "5", "-p", "3"])
        self.assertEqual(proc.returncode, 0, proc.stderr.decode())
        self.assertEqual(proc.stdout.decode(), "0.000,0.309,0.588,0.809,0.951,\n")

    def test_function_wave_wraps_after_ten_values(self):
        proc = run_hx(["-u", "11", "-p", "4"])
        self.assertEqual(proc.returncode, 0, proc.stderr.decode())
        self.assertEqual(
            proc.stdout.decode(),
            "0.0000,0.1423,0.2817,0.4154,0.5406,0.6549,0.7557,0.8413,0.9096,0.9595,\n"
            "0.9898,\n",
        )


if __name__ == "__main__":
    unittest.main()
