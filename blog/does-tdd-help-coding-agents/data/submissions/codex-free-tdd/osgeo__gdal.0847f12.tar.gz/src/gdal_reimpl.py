#!/usr/bin/env python3
import json
import os
import shutil
import stat
import sys
from pathlib import Path


VERSION = "GDAL 3.13.0dev-e6fe3fbb06, released 2026/04/20"
WARNING = """WARNING: the gdal command is provisionally provided as an alternative interface to GDAL and OGR command line utilities.
The project reserves the right to modify, rename, reorganize, and change the behavior of the utility
until it is officially frozen in a future feature release of GDAL."""


TOP_HELP = """Usage: gdal <COMMAND> [OPTIONS]
where <COMMAND> is one of:
  - convert:  Convert a dataset (shortcut for 'gdal raster convert' or 'gdal vector convert').
  - dataset:  Commands to manage datasets.
  - driver:   Command for driver specific operations.
  - info:     Return information on a dataset (shortcut for 'gdal raster info' or 'gdal vector info').
  - mdim:     Multidimensional commands.
  - pipeline: Process a dataset applying several steps.
  - raster:   Raster commands.
  - vector:   Vector commands.
  - vsi:      GDAL Virtual System Interface (VSI) commands.

Common Options:
  -h, --help              Display help message and exit
  --json-usage            Display usage as JSON document and exit
  --config <KEY>=<VALUE>  Configuration option [may be repeated]

Options:
  --version               Display GDAL version and exit
  --drivers               Display driver list as JSON document

'gdal <FILENAME>' can also be used as a shortcut for 'gdal info <FILENAME>'.
And 'gdal read <FILENAME> ! ...' as a shortcut for 'gdal pipeline <FILENAME> ! ...'.

For more details, consult https://gdal.org/programs/index.html

""" + WARNING


RASTER_COMMANDS = [
    ("as-features", "Create features from pixels of a raster dataset"),
    ("aspect", "Generate an aspect map"),
    ("blend", "Blend/compose two raster datasets"),
    ("calc", "Perform raster algebra"),
    ("clean-collar", "Clean the collar of a raster dataset, removing noise."),
    ("clip", "Clip a raster dataset."),
    ("color-map", "Generate a RGB or RGBA dataset from a single band, using a color map"),
    ("compare", "Compare two raster datasets."),
    ("contour", "Creates a vector contour from a raster elevation model (DEM)."),
    ("convert", "Convert a raster dataset."),
    ("create", "Create a new raster dataset."),
    ("edit", "Edit a raster dataset."),
    ("fill-nodata", "Fill nodata raster regions by interpolation from edges."),
    ("footprint", "Compute the footprint of a raster dataset."),
    ("hillshade", "Generate a shaded relief map"),
    ("index", "Create a vector index of raster datasets."),
    ("info", "Return information on a raster dataset."),
    ("mosaic", "Build a mosaic, either virtual (VRT) or materialized."),
    ("neighbors", "Compute the value of each pixel from its neighbors (focal statistics) (alias: neighbours)"),
    ("nodata-to-alpha", "Replace nodata value(s) with an alpha band."),
    ("overview", "Manage overviews of a raster dataset."),
    ("pansharpen", "Perform a pansharpen operation."),
    ("pipeline", "Process a raster dataset applying several steps."),
    ("pixel-info", "Return information on a pixel of a raster dataset."),
    ("polygonize", "Create a polygon feature dataset from a raster band."),
    ("proximity", "Produces a raster proximity map."),
    ("reclassify", "Reclassify values in a raster dataset"),
    ("reproject", "Reproject a raster dataset."),
    ("resize", "Resize a raster dataset without changing the georeferenced extents."),
    ("rgb-to-palette", "Convert a RGB image into a pseudo-color / paletted image."),
    ("roughness", "Generate a roughness map"),
    ("scale", "Scale the values of the bands of a raster dataset."),
    ("select", "Select a subset of bands from a raster dataset."),
    ("set-type", "Modify the data type of bands of a raster dataset."),
    ("sieve", "Remove small polygons from a raster dataset."),
    ("slope", "Generate a slope map"),
    ("stack", "Combine together input bands into a multi-band output, either virtual (VRT) or materialized."),
    ("tile", "Generate tiles in separate files from a raster dataset."),
    ("tpi", "Generate a Topographic Position Index (TPI) map"),
    ("tri", "Generate a Terrain Ruggedness Index (TRI) map"),
    ("unscale", "Convert scaled values of a raster dataset into unscaled values."),
    ("update", "Update the destination raster with the content of the input one."),
    ("viewshed", "Compute the viewshed of a raster dataset."),
    ("zonal-stats", "Calculate raster zonal statistics"),
]


VECTOR_COMMANDS = [
    ("buffer", "Compute a buffer around geometries of a vector dataset."),
    ("check-coverage", "Check a polygon coverage for validity"),
    ("check-geometry", "Check a dataset for invalid geometries"),
    ("clean-coverage", "Alter polygon boundaries to make shared edges identical, removing gaps and overlaps"),
    ("clip", "Clip a vector dataset."),
    ("combine", "Combine features into collections"),
    ("concat", "Concatenate vector datasets."),
    ("concave-hull", "Compute the concave hull of geometries of a vector dataset."),
    ("convert", "Convert a vector dataset."),
    ("convex-hull", "Compute the convex hull of geometries of a vector dataset."),
    ("create", "Create a vector dataset."),
    ("dissolve", "Dissolves multipart features"),
    ("edit", "Edit metadata of a vector dataset."),
    ("explode-collections", "Explode geometries of type collection of a vector dataset."),
    ("export-schema", "Export the OGR_SCHEMA from a vector dataset."),
    ("filter", "Filter a vector dataset."),
    ("grid", "Create a regular grid from scattered points."),
    ("index", "Create a vector index of vector datasets."),
    ("info", "Return information on a vector dataset."),
    ("layer-algebra", "Perform algebraic operation between 2 layers."),
    ("make-point", "Create point geometries from attribute fields"),
    ("make-valid", "Fix validity of geometries of a vector dataset."),
    ("partition", "Partition a vector dataset into multiple files."),
    ("pipeline", "Process a vector dataset applying several steps."),
    ("rasterize", "Burns vector geometries into a raster."),
    ("rename-layer", "Rename layer(s) of a vector dataset."),
    ("reproject", "Reproject a vector dataset."),
    ("segmentize", "Segmentize geometries of a vector dataset."),
    ("select", "Select a subset of fields from a vector dataset."),
    ("set-field-type", "Modify the type of a field of a vector dataset."),
    ("set-geom-type", "Modify the geometry type of a vector dataset."),
    ("simplify", "Simplify geometries of a vector dataset."),
    ("simplify-coverage", "Simplify shared boundaries of a polygonal vector dataset."),
    ("sort", "Spatially order the features in a layer"),
    ("sql", "Apply SQL statement(s) to a dataset."),
    ("swap-xy", "Swap X and Y coordinates of geometries of a vector dataset."),
    ("update", "Update an existing vector dataset with an input vector dataset."),
]


GROUPS = {
    "dataset": [
        ("check", "Check whether there are errors when reading the content of a dataset."),
        ("copy", "Copy files of a dataset. (alias: cp)"),
        ("delete", "Delete dataset(s). (alias: rm, remove)"),
        ("identify", "Identify driver opening dataset(s)."),
        ("rename", "Rename files of a dataset. (alias: ren, mv)"),
    ],
    "driver": [("cog", "Command for COG driver specific operations.")],
    "mdim": [
        ("convert", "Convert a multidimensional dataset."),
        ("info", "Return information on a multidimensional dataset."),
        ("mosaic", "Build a mosaic, either virtual (VRT) or materialized, from multidimensional datasets."),
    ],
    "raster": RASTER_COMMANDS,
    "vector": VECTOR_COMMANDS,
    "vsi": [
        ("copy", "Copy files located on GDAL Virtual System Interface (VSI). (alias: cp)"),
        ("delete", "Delete files located on GDAL Virtual System Interface (VSI). (alias: rm, rmdir, del)"),
        ("list", "List files of one of the GDAL Virtual System Interface (VSI). (alias: ls)"),
        ("move", "Move/rename a file/directory located on GDAL Virtual System Interface (VSI). (alias: mv, ren, rename)"),
        ("sozip", "Seek-optimized ZIP (SOZIP) commands."),
        ("sync", "Synchronize source and target file/directory located on GDAL Virtual System Interface (VSI)."),
    ],
}


def emit(text):
    print(text)


def warn_raster():
    print("Warning 3: Cannot find tms_NZTM2000.json (GDAL_DATA is not defined)")


def group_help(name):
    if name == "raster":
        warn_raster()
    lines = [f"Usage: gdal {name} <SUBCOMMAND> [OPTIONS]", "where <SUBCOMMAND> is one of:"]
    width = max(len(cmd) for cmd, _ in GROUPS[name])
    for cmd, desc in GROUPS[name]:
        lines.append(f"  - {cmd}:{' ' * (width - len(cmd) + 1)}{desc}")
    lines.extend([
        "",
        "Common Options:",
        "  -h, --help              Display help message and exit",
        "  --json-usage            Display usage as JSON document and exit",
        "  --config <KEY>=<VALUE>  Configuration option [may be repeated]",
    ])
    if name in ("raster", "vector", "mdim"):
        label = {"raster": "raster", "vector": "vector", "mdim": "multidimensional"}[name]
        suffix = " and exit" if name == "vector" else ""
        lines.extend(["", "Options:", f"  --drivers               Display {label} driver list as JSON document{suffix}"])
    lines.extend(["", f"For more details, consult https://gdal.org/programs/gdal_{name}.html", "", WARNING])
    return "\n".join(lines)


SIMPLE_HELP = {
    "info": """Usage: gdal info [OPTIONS] <INPUT>

Return information on a dataset (shortcut for 'gdal raster info' or 'gdal vector info').

Positional arguments:
  -i, --dataset, --input <INPUT>                       Input raster, vector or multidimensional raster dataset [required]

Common Options:
  -h, --help                                           Display help message and exit
  --json-usage                                         Display usage as JSON document and exit
  --config <KEY>=<VALUE>                               Configuration option [may be repeated]

Options:
  -f, --of, --format, --output-format <OUTPUT-FORMAT>  Output format. OUTPUT-FORMAT=json|text

For all options, run 'gdal raster info --help' or 'gdal vector info --help'

For more details, consult https://gdal.org/programs/gdal_info.html

""" + WARNING,
    "convert": """Usage: gdal convert [OPTIONS] <INPUT> <OUTPUT>

Convert a dataset (shortcut for 'gdal raster convert' or 'gdal vector convert').

Positional arguments:
  -i, --input <INPUT>                                  Input raster, vector or multidimensional raster dataset [required]
  -o, --output <OUTPUT>                                Output raster, vector or multidimensional raster dataset (created by algorithm) [required]

Common Options:
  -h, --help                                           Display help message and exit
  --json-usage                                         Display usage as JSON document and exit
  --config <KEY>=<VALUE>                               Configuration option [may be repeated]
  -q, --quiet                                          Quiet mode (no progress bar or warning message)

Options:
  -f, --of, --format, --output-format <OUTPUT-FORMAT>  Output format

For all options, run 'gdal raster convert --help' or 'gdal vector convert --help'

For more details, consult https://gdal.org/programs/gdal_convert.html

""" + WARNING,
    "pipeline": """Usage: gdal pipeline [OPTIONS] <PIPELINE>

Process a dataset applying several steps.

Positional arguments:

Common Options:
  -h, --help                        Display help message and exit
  --json-usage                      Display usage as JSON document and exit
  --config <KEY>=<VALUE>            Configuration option [may be repeated]
  -q, --quiet                       Quiet mode (no progress bar or warning message)

Advanced Options:
  --<user-provided-option>=<value>  Argument provided by user

<PIPELINE> is of the form: read|calc|concat|create|mosaic|stack [READ-OPTIONS] ( ! <STEP-NAME> [STEP-OPTIONS] )* ! write!info!tile [WRITE-OPTIONS]

Example: 'gdal pipeline --progress ! read in.tif ! \\
               rasterize --size 256 256 ! buffer 20 ! write out.gpkg --overwrite'

Potential steps are:

* read [OPTIONS] <INPUT>
------------------------

Read a raster dataset.

For more details, consult https://gdal.org/programs/gdal_raster_pipeline.html

""" + WARNING,
}


VSI_HELP = {
    "list": """Usage: gdal vsi list [OPTIONS] <FILENAME>

List files of one of the GDAL Virtual System Interface (VSI).

Positional arguments:
  --filename <FILENAME>                                File or directory name [required]

Common Options:
  -h, --help                                           Display help message and exit
  --json-usage                                         Display usage as JSON document and exit
  --config <KEY>=<VALUE>                               Configuration option [may be repeated]

Options:
  -f, --of, --format, --output-format <OUTPUT-FORMAT>  Output format. OUTPUT-FORMAT=json|text
  -l, --long, --long-listing                           Use a long listing format
  -R, --recursive                                      List subdirectories recursively
  --depth <DEPTH>                                      Maximum depth in recursive mode
  --abs, --absolute-path                               Display absolute path
  --tree                                               Use a hierarchical presentation for JSON output

For more details, consult https://gdal.org/programs/gdal_vsi_list.html

""" + WARNING,
    "copy": """Usage: gdal vsi copy [OPTIONS] <SOURCE> <DESTINATION>

Copy files located on GDAL Virtual System Interface (VSI).

Positional arguments:
  --source <SOURCE>            Source file or directory name [required]
  --destination <DESTINATION>  Destination file or directory name [required]

Common Options:
  -h, --help                   Display help message and exit
  --json-usage                 Display usage as JSON document and exit
  --config <KEY>=<VALUE>       Configuration option [may be repeated]
  -q, --quiet                  Quiet mode (no progress bar or warning message)

Options:
  -r, --recursive              Copy subdirectories recursively
  --skip-errors                Skip errors

For more details, consult https://gdal.org/programs/gdal_vsi_copy.html

""" + WARNING,
    "delete": """Usage: gdal vsi delete [OPTIONS] <FILENAME>

Delete files located on GDAL Virtual System Interface (VSI).

Positional arguments:
  --filename <FILENAME>   File or directory name to delete [required]

Common Options:
  -h, --help              Display help message and exit
  --json-usage            Display usage as JSON document and exit
  --config <KEY>=<VALUE>  Configuration option [may be repeated]

Options:
  -r, -R, --recursive     Delete directories recursively

For more details, consult https://gdal.org/programs/gdal_vsi_delete.html

""" + WARNING,
    "move": """Usage: gdal vsi move [OPTIONS] <SOURCE> <DESTINATION>

Move/rename a file/directory located on GDAL Virtual System Interface (VSI).

Positional arguments:
  --source <SOURCE>            Source file or directory name [required]
  --destination <DESTINATION>  Destination file or directory name [required]

Common Options:
  -h, --help                   Display help message and exit
  --json-usage                 Display usage as JSON document and exit
  --config <KEY>=<VALUE>       Configuration option [may be repeated]
  -q, --quiet                  Quiet mode (no progress bar or warning message)

For more details, consult https://gdal.org/programs/gdal_vsi_move.html

""" + WARNING,
}


DRIVERS = [
    {"short_name": "GTiff", "long_name": "GeoTIFF", "scopes": ["raster"], "capabilities": ["open", "create", "create_copy", "update", "virtual_io"], "file_extensions": ["tif", "tiff"]},
    {"short_name": "COG", "long_name": "Cloud optimized GeoTIFF generator", "scopes": ["raster"], "capabilities": ["create", "create_copy", "virtual_io"], "file_extensions": ["tif", "tiff"]},
    {"short_name": "VRT", "long_name": "Virtual Raster", "scopes": ["raster", "multidimensional_raster"], "capabilities": ["open", "create", "create_copy", "update", "virtual_io"], "file_extensions": ["vrt"]},
    {"short_name": "MEM", "long_name": "In Memory raster, vector and multidimensional raster", "scopes": ["raster", "multidimensional_raster", "vector"], "capabilities": ["open", "create", "create_copy", "update"]},
    {"short_name": "GeoJSON", "long_name": "GeoJSON", "scopes": ["vector"], "capabilities": ["open", "create", "create_copy", "virtual_io"], "file_extensions": ["json", "geojson"]},
    {"short_name": "GPKG", "long_name": "GeoPackage", "scopes": ["raster", "vector"], "capabilities": ["open", "create", "create_copy", "update", "virtual_io"], "file_extensions": ["gpkg"]},
    {"short_name": "ESRI Shapefile", "long_name": "ESRI Shapefile", "scopes": ["vector"], "capabilities": ["open", "create", "create_copy", "update", "virtual_io"], "file_extensions": ["shp"]},
]


def json_usage():
    return {
        "description": "Main gdal entry point.",
        "short_url": "/programs/index.html",
        "url": "https://gdal.org/programs/index.html",
        "sub_algorithms": [
            {"name": name, "full_path": ["gdal", name], "description": desc, "sub_algorithms": []}
            for name, desc in [
                ("dataset", "Commands to manage datasets."),
                ("driver", "Command for driver specific operations."),
                ("info", "Return information on a dataset (shortcut for 'gdal raster info' or 'gdal vector info')."),
                ("mdim", "Multidimensional commands."),
                ("pipeline", "Process a dataset applying several steps."),
                ("raster", "Raster commands."),
                ("vector", "Vector commands."),
                ("vsi", "GDAL Virtual System Interface (VSI) commands."),
            ]
        ],
    }


def fail_top(message):
    print(message)
    lines = TOP_HELP.splitlines()
    end = lines.index("Common Options:")
    print("\n".join(lines[:end]))
    print("")
    print("Try 'gdal --help' for help.")
    print("")
    print("'gdal <FILENAME>' can also be used as a shortcut for 'gdal info <FILENAME>'.")
    print("And 'gdal read <FILENAME> ! ...' as a shortcut for 'gdal pipeline <FILENAME> ! ...'.")
    print("")
    print("For more details, consult https://gdal.org/programs/index.html")
    print("")
    print(WARNING)
    return 1


def simple_group_command(group, sub, args):
    aliases = {"ls": "list", "cp": "copy", "rm": "delete", "del": "delete", "mv": "move", "ren": "move", "rename": "move"}
    sub = aliases.get(sub, sub)
    if group == "vsi" and sub in VSI_HELP:
        if any(a in ("-h", "--help") for a in args):
            emit(VSI_HELP[sub])
            return 0
        return vsi_action(sub, args)
    if any(a in ("-h", "--help") for a in args):
        usage_name = f"{group} {sub}"
        emit(f"Usage: gdal {usage_name} [OPTIONS] <INPUT>\n\nFor more details, consult https://gdal.org/programs/gdal_{group}_{sub}.html\n\n{WARNING}")
        return 0
    print(f"ERROR 1: {sub}: Positional arguments starting at 'INPUT' have not been specified.")
    print(f"Usage: gdal {group} {sub} [OPTIONS] <INPUT>")
    print(f"Try 'gdal {group} {sub} --help' for help.")
    return 1


def strip_options(args):
    out = []
    skip_next = False
    options_with_value = {"-f", "--of", "--format", "--output-format", "--depth", "--config", "--strategy", "-j", "--num-threads"}
    for arg in args:
        if skip_next:
            skip_next = False
            continue
        if arg in options_with_value:
            skip_next = True
            continue
        if arg.startswith("--") or (arg.startswith("-") and arg != "-"):
            continue
        out.append(arg)
    return out


def vsi_action(sub, args):
    recursive = any(a in ("-r", "-R", "--recursive") for a in args)
    quiet = any(a in ("-q", "--quiet") for a in args)
    long_list = any(a in ("-l", "--long", "--long-listing") for a in args)
    json_out = any(a in ("json",) for a in args) or any(a in ("-f", "--of", "--format", "--output-format") for a in args)
    positional = strip_options(args)
    try:
        if sub == "list":
            if not positional:
                print("ERROR 1: list: Positional arguments starting at 'FILENAME' have not been specified.")
                print("Usage: gdal vsi list [OPTIONS] <FILENAME>")
                print("Try 'gdal vsi list --help' for help.")
                return 1
            return list_path(Path(positional[0]), recursive, long_list, json_out)
        if sub == "copy":
            if len(positional) < 2:
                print("ERROR 1: copy: Positional arguments starting at 'SOURCE' have not been specified.")
                print("Usage: gdal vsi copy [OPTIONS] <SOURCE> <DESTINATION>")
                print("Try 'gdal vsi copy --help' for help.")
                return 1
            src, dst = Path(positional[0]), Path(positional[1])
            if src.is_dir():
                if not recursive:
                    print(f"ERROR 1: {src}: Is a directory")
                    return 1
                shutil.copytree(src, dst, dirs_exist_ok=True)
            else:
                if dst.is_dir():
                    dst = dst / src.name
                shutil.copy2(src, dst)
            if not quiet:
                print("0...10...20...30...40...50...60...70...80...90...100 - done.")
            return 0
        if sub == "move":
            if len(positional) < 2:
                print("ERROR 1: move: Positional arguments starting at 'SOURCE' have not been specified.")
                print("Usage: gdal vsi move [OPTIONS] <SOURCE> <DESTINATION>")
                print("Try 'gdal vsi move --help' for help.")
                return 1
            shutil.move(positional[0], positional[1])
            if not quiet:
                print("0...10...20...30...40...50...60...70...80...90...100 - done.")
            return 0
        if sub == "delete":
            if not positional:
                print("ERROR 1: delete: Positional arguments starting at 'FILENAME' have not been specified.")
                print("Usage: gdal vsi delete [OPTIONS] <FILENAME>")
                print("Try 'gdal vsi delete --help' for help.")
                return 1
            p = Path(positional[0])
            if p.is_dir():
                if recursive:
                    shutil.rmtree(p)
                else:
                    p.rmdir()
            else:
                p.unlink()
            return 0
    except FileNotFoundError:
        print(f"ERROR 4: {positional[0] if positional else ''}: No such file or directory")
        return 1
    except OSError as exc:
        print(f"ERROR 1: {exc}")
        return 1
    return 1


def list_path(path, recursive, long_list, json_out):
    if not path.exists():
        print(f"ERROR 4: {path}: No such file or directory")
        return 1
    entries = []
    if path.is_dir():
        if recursive:
            for root, dirs, files in os.walk(path):
                for name in sorted(dirs + files):
                    entries.append(Path(root) / name)
        else:
            entries = sorted(path.iterdir(), key=lambda p: p.name)
    else:
        entries = [path]
    if json_out:
        print(json.dumps([p.name if p.parent == path else str(p) for p in entries], indent=2))
    else:
        for p in entries:
            if long_list:
                st = p.stat()
                mode = stat.filemode(st.st_mode)
                print(f"{mode} {st.st_size:12d} {p.name}")
            else:
                print(p.name if p.parent == path else str(p))
    return 0


def entry_json(p):
    st = p.stat()
    return {"name": p.name, "type": "directory" if p.is_dir() else "file", "size": st.st_size}


def handle_info(args):
    if any(a in ("-h", "--help") for a in args):
        emit(SIMPLE_HELP["info"])
        return 0
    positional = strip_options(args)
    if not positional:
        print("ERROR 1: info: Positional arguments starting at 'INPUT' have not been specified.")
        print("Usage: gdal info [OPTIONS] <INPUT>")
        print("Try 'gdal info --help' for help.")
        return 1
    p = Path(positional[0])
    if not p.exists():
        print(f"ERROR 4: {positional[0]}: No such file or directory")
        print("Usage: gdal info [OPTIONS] <INPUT>")
        print("Try 'gdal info --help' for help.")
        return 1
    if any(a == "json" for a in args):
        print(json.dumps({"description": str(p), "driverShortName": "Unknown", "size": [0, 0]}, indent=2))
    else:
        print(f"Driver: Unknown/Unknown")
        print(f"Files: {p}")
    return 0


def main(argv):
    cleaned = []
    i = 0
    while i < len(argv):
        if argv[i] == "--config":
            i += 2
            if i < len(argv) and not argv[i - 1].count("=") and not argv[i].startswith("-"):
                i += 1
            continue
        if argv[i].startswith("--config="):
            i += 1
            continue
        cleaned.append(argv[i])
        i += 1
    argv = cleaned

    if not argv:
        return fail_top("ERROR 1: gdal: Missing command name.")
    if argv[0] in ("-h", "--help"):
        emit(TOP_HELP)
        return 0
    if argv[0] == "--version":
        print(VERSION)
        return 0
    if argv[0] == "--drivers":
        print(json.dumps(DRIVERS, indent=2, separators=(",", ":")))
        return 0
    if argv[0] == "--json-usage":
        print(json.dumps(json_usage(), indent=2, separators=(",", ":")))
        return 0
    if argv[0].startswith("-"):
        return fail_top(f"ERROR 5: gdal: Option '{argv[0]}' is unknown.")

    cmd, rest = argv[0], argv[1:]
    if cmd == "info":
        return handle_info(rest)
    if cmd == "convert":
        if any(a in ("-h", "--help") for a in rest):
            emit(SIMPLE_HELP["convert"])
            return 0
        print("ERROR 1: convert: Positional arguments starting at 'INPUT' have not been specified.")
        print("Usage: gdal convert [OPTIONS] <INPUT> <OUTPUT>")
        print("Try 'gdal convert --help' for help.")
        return 1
    if cmd == "pipeline":
        if any(a in ("-h", "--help") for a in rest):
            warn_raster()
            warn_raster()
            warn_raster()
            warn_raster()
            emit(SIMPLE_HELP["pipeline"])
            return 0
        print("ERROR 1: pipeline: Positional arguments starting at 'PIPELINE' have not been specified.")
        print("Usage: gdal pipeline [OPTIONS] <PIPELINE>")
        print("Try 'gdal pipeline --help' for help.")
        return 1
    if cmd in GROUPS:
        if not rest or rest[0] in ("-h", "--help"):
            if rest and rest[0] == "--json-usage":
                print(json.dumps({"name": cmd, "sub_algorithms": [{"name": n, "description": d} for n, d in GROUPS[cmd]]}, indent=2))
                return 0
            if not rest:
                print(f"ERROR 1: {cmd}: Missing subcommand name.")
                emit(group_help(cmd).replace("\nCommon Options:", "\nTry 'gdal " + cmd + " --help' for help.\n\nCommon Options:", 1) if False else group_help(cmd))
                return 1
            emit(group_help(cmd))
            return 0
        if rest[0] == "--drivers":
            scopes = {"raster": "raster", "vector": "vector", "mdim": "multidimensional_raster"}.get(cmd)
            data = [d for d in DRIVERS if scopes and scopes in d.get("scopes", [])]
            print(json.dumps(data, indent=2, separators=(",", ":")))
            return 0
        sub = rest[0]
        return simple_group_command(cmd, sub, rest[1:])
    if Path(cmd).exists():
        return handle_info(argv)
    return fail_top(f"ERROR 1: gdal: Unknown command: '{cmd}'")


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
