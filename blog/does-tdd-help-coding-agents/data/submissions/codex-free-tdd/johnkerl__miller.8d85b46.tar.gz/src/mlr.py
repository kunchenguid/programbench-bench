#!/usr/bin/env python3
import csv
import json
import math
import operator
import os
import re
import sys
from collections import OrderedDict


USAGE = """Usage: mlr [flags] {verb} [verb-dependent options ...] {zero or more file names}

If zero file names are provided, standard input is read, e.g.
  mlr --csv sort -f shape example.csv

Output of one verb may be chained as input to another using "then", e.g.
  mlr --csv stats1 -a min,mean,max -f quantity then sort -f color example.csv

Please see 'mlr help topics' for more information.
Please also see https://miller.readthedocs.io
"""


TOPICS = """Type 'mlr help {topic}' for any of the following:
Essentials:
  mlr help topics
  mlr help basic-examples
  mlr help file-formats
Flags:
  mlr help flags
  mlr help flag
Verbs:
  mlr help list-verbs
  mlr help usage-verbs
  mlr help verb
Functions:
  mlr help list-functions
  mlr help usage-functions
Keywords:
  mlr help list-keywords
  mlr help usage-keywords
Other:
  mlr help auxents
  mlr help terminals
Shorthands:
  mlr -g = mlr help flags
  mlr -l = mlr help list-verbs
  mlr -L = mlr help usage-verbs
  mlr -f = mlr help list-functions
  mlr -F = mlr help usage-functions
  mlr -k = mlr help list-keywords
  mlr -K = mlr help usage-keywords
"""


BASIC_EXAMPLES = """mlr --icsv --opprint cat example.csv
mlr --icsv --opprint sort -f shape example.csv
mlr --icsv --opprint sort -f shape -nr index example.csv
mlr --icsv --opprint cut -f flag,shape example.csv
mlr --csv filter '$color == "red"' example.csv
mlr --icsv --ojson put '$ratio = $quantity / $rate' example.csv
mlr --icsv --opprint --from example.csv sort -nr index then cut -f shape,quantity
"""


VERBS = """altkv
bar
bootstrap
case
cat
check
clean-whitespace
count-distinct
count
count-similar
cut
decimate
fill-down
fill-empty
filter
flatten
format-values
fraction
gap
grep
group-by
group-like
gsub
having-fields
head
histogram
json-parse
json-stringify
join
label
latin1-to-utf8
least-frequent
merge-fields
most-frequent
nest
nothing
put
regularize
remove-empty-columns
rename
reorder
repeat
reshape
sample
sec2gmtdate
sec2gmt
seqgen
shuffle
skip-trivial-records
sort
sort-within-records
sparsify
split
ssub
stats1
stats2
step
sub
summary
surv
tac
tail
tee
template
top
utf8-to-latin1
unflatten
uniq
unspace
unsparsify
"""


FILE_FORMATS = """CSV/CSV-lite: comma-separated values with separate header line
TSV: same but with tabs in places of commas
JSON (array of objects)
JSON Lines (sequence of one-line objects)
PPRINT: pretty-printed tabular
DKVP: delimited key-value pairs (Miller default format)
NIDX: implicitly numerically indexed
"""


class Config:
    def __init__(self):
        self.ifmt = "dkvp"
        self.ofmt = "dkvp"
        self.from_file = None
        self.headerless_csv_output = False


def scalar(text):
    if isinstance(text, (int, float)) or text is None:
        return text
    if not isinstance(text, str):
        return text
    if re.fullmatch(r"[-+]?\d+", text):
        try:
            return int(text)
        except ValueError:
            return text
    if re.fullmatch(r"[-+]?(?:\d+\.\d*|\d*\.\d+)(?:[eE][-+]?\d+)?", text) or re.fullmatch(r"[-+]?\d+[eE][-+]?\d+", text):
        try:
            return float(text)
        except ValueError:
            return text
    return text


def display(value):
    if isinstance(value, bool):
        return "true" if value else "false"
    if isinstance(value, float):
        if math.isfinite(value) and value.is_integer():
            return str(int(value))
        return repr(value)
    return str(value)


def flatten(prefix, value, out):
    if isinstance(value, dict):
        for k, v in value.items():
            flatten(f"{prefix}.{k}" if prefix else str(k), v, out)
    elif isinstance(value, list):
        for i, v in enumerate(value, 1):
            flatten(f"{prefix}.{i}" if prefix else str(i), v, out)
    else:
        out[prefix] = value


def parse_dkvp(text):
    records = []
    for line in text.splitlines():
        if line == "":
            continue
        rec = OrderedDict()
        for idx, part in enumerate(line.split(","), 1):
            if "=" in part:
                k, v = part.split("=", 1)
            else:
                k, v = str(idx), part
            rec[k] = scalar(v)
        records.append(rec)
    return records


def parse_csvlike(text, delimiter):
    rows = list(csv.reader(text.splitlines(), delimiter=delimiter))
    if not rows:
        return []
    header = rows[0]
    records = []
    for row in rows[1:]:
        rec = OrderedDict()
        for i, key in enumerate(header):
            rec[key] = scalar(row[i] if i < len(row) else "")
        records.append(rec)
    return records


def parse_json_records(text, lines=False):
    records = []
    if lines:
        items = [json.loads(line) for line in text.splitlines() if line.strip()]
    else:
        data = json.loads(text) if text.strip() else []
        items = data if isinstance(data, list) else [data]
    for item in items:
        rec = OrderedDict()
        flatten("", item, rec)
        records.append(rec)
    return records


def read_all(paths):
    if not paths:
        return sys.stdin.read()
    chunks = []
    for path in paths:
        with open(path, "r", newline="") as f:
            chunks.append(f.read())
    return "".join(chunks)


def parse_records(text, fmt):
    if fmt == "csv":
        return parse_csvlike(text, ",")
    if fmt == "tsv":
        return parse_csvlike(text, "\t")
    if fmt == "json":
        return parse_json_records(text, False)
    if fmt == "jsonl":
        return parse_json_records(text, True)
    return parse_dkvp(text)


def all_keys(records):
    keys = []
    seen = set()
    for rec in records:
        for k in rec:
            if k not in seen:
                seen.add(k)
                keys.append(k)
    return keys


def emit_dkvp(records):
    lines = []
    for rec in records:
        lines.append(",".join(f"{k}={display(v)}" for k, v in rec.items()))
    return "\n".join(lines) + ("\n" if lines else "")


def emit_csvlike(records, delimiter, headerless=False):
    keys = all_keys(records)
    out = []
    sink = csv.writer(out := _CsvSink(), delimiter=delimiter, lineterminator="\n")
    if keys and not headerless:
        sink.writerow(keys)
    for rec in records:
        sink.writerow([display(rec.get(k, "")) for k in keys])
    return out.text


class _CsvSink:
    def __init__(self):
        self.text = ""

    def write(self, s):
        self.text += s


def emit_pprint(records):
    keys = all_keys(records)
    if not keys:
        return ""
    widths = {k: len(k) for k in keys}
    for rec in records:
        for k in keys:
            widths[k] = max(widths[k], len(display(rec.get(k, ""))))
    lines = []
    for row in [OrderedDict((k, k) for k in keys), *records]:
        pieces = []
        for i, k in enumerate(keys):
            s = display(row.get(k, ""))
            pieces.append(s.ljust(widths[k]) if i < len(keys) - 1 else s)
        lines.append(" ".join(pieces).rstrip())
    return "\n".join(lines) + "\n"


def nest_record(rec):
    out = OrderedDict()
    for key, value in rec.items():
        parts = key.split(".")
        cur = out
        for part in parts[:-1]:
            cur = cur.setdefault(part, OrderedDict())
        cur[parts[-1]] = value
    return out


def emit_json(records):
    lines = ["["]
    for i, rec in enumerate(records):
        dumped = json.dumps(nest_record(rec), indent=2)
        lines.extend(dumped.splitlines())
        if i != len(records) - 1:
            lines[-1] += ","
    lines.append("]")
    return "\n".join(lines) + "\n"


def emit_jsonl(records):
    return "".join(json.dumps(nest_record(rec), separators=(",", ":")) + "\n" for rec in records)


def emit_records(records, fmt, cfg):
    if fmt == "csv":
        return emit_csvlike(records, ",", cfg.headerless_csv_output)
    if fmt == "tsv":
        return emit_csvlike(records, "\t", cfg.headerless_csv_output)
    if fmt == "pprint":
        return emit_pprint(records)
    if fmt == "json":
        return emit_json(records)
    if fmt == "jsonl":
        return emit_jsonl(records)
    return emit_dkvp(records)


def split_pipeline(args):
    stages = [[]]
    for arg in args:
        if arg == "then":
            stages.append([])
        else:
            stages[-1].append(arg)
    return stages


def parse_fields(value):
    return [x for x in value.split(",") if x]


def verb_cat(records, args):
    return records, args


def verb_cut(records, args):
    fields = []
    rest = []
    i = 0
    while i < len(args):
        if args[i] == "-f" and i + 1 < len(args):
            fields = parse_fields(args[i + 1])
            i += 2
        else:
            rest.append(args[i])
            i += 1
    wanted = set(fields)
    out = []
    for rec in records:
        nr = OrderedDict()
        for k, v in rec.items():
            if k in wanted:
                nr[k] = v
        out.append(nr)
    return out, rest


class Desc:
    def __init__(self, value):
        self.value = value

    def __lt__(self, other):
        return self.value > other.value

    def __eq__(self, other):
        return self.value == other.value


def verb_sort(records, args):
    criteria = []
    rest = []
    i = 0
    while i < len(args):
        flag = args[i]
        if flag in ("-f", "-r", "-n", "-nr", "-rn") and i + 1 < len(args):
            for field in parse_fields(args[i + 1]):
                criteria.append((field, "n" in flag, "r" in flag))
            i += 2
        else:
            rest.append(args[i])
            i += 1
    def key(rec):
        values = []
        for field, numeric, reverse in criteria:
            value = rec.get(field, "")
            if numeric:
                value = float(value)
            else:
                value = display(value)
            values.append(Desc(value) if reverse else value)
        return tuple(values)
    return sorted(records, key=key), rest


def verb_head(records, args):
    n = 10
    rest = []
    i = 0
    while i < len(args):
        if args[i] == "-n" and i + 1 < len(args):
            n = int(args[i + 1])
            i += 2
        else:
            rest.append(args[i])
            i += 1
    return records[:n], rest


def verb_tail(records, args):
    n = 10
    rest = []
    i = 0
    while i < len(args):
        if args[i] == "-n" and i + 1 < len(args):
            n = int(args[i + 1])
            i += 2
        else:
            rest.append(args[i])
            i += 1
    return records[-n:] if n else [], rest


def eval_filter(expr, rec):
    m = re.fullmatch(r"\s*\$([A-Za-z0-9_.]+)\s*(==|!=|>=|<=|>|<)\s*(.+?)\s*", expr)
    if not m:
        return True
    field, op, raw = m.groups()
    left = rec.get(field, "")
    raw = raw.strip()
    if len(raw) >= 2 and raw[0] == raw[-1] == '"':
        right = raw[1:-1]
    else:
        right = scalar(raw)
    if isinstance(left, (int, float)) and isinstance(right, (int, float)):
        pass
    else:
        left, right = display(left), display(right)
    return {
        "==": operator.eq,
        "!=": operator.ne,
        ">": operator.gt,
        "<": operator.lt,
        ">=": operator.ge,
        "<=": operator.le,
    }[op](left, right)


def verb_filter(records, args):
    if not args:
        return records, []
    expr = args[0]
    return [rec for rec in records if eval_filter(expr, rec)], args[1:]


def eval_expr(expr, rec):
    def repl(match):
        value = rec.get(match.group(1), 0)
        if isinstance(value, str):
            return repr(value)
        return repr(value)
    pyexpr = re.sub(r"\$([A-Za-z0-9_.]+)", repl, expr)
    result = eval(pyexpr, {"__builtins__": {}}, {})
    if isinstance(result, float) and math.isfinite(result) and result.is_integer():
        return int(result)
    return scalar(result)


def verb_put(records, args):
    if not args:
        return records, []
    m = re.fullmatch(r"\s*\$([A-Za-z0-9_.]+)\s*=\s*(.+)\s*", args[0])
    if not m:
        return records, args[1:]
    field, expr = m.groups()
    for rec in records:
        rec[field] = eval_expr(expr, rec)
    return records, args[1:]


def verb_stats1(records, args):
    aggs = []
    fields = []
    groups = []
    rest = []
    i = 0
    while i < len(args):
        if args[i] == "-a" and i + 1 < len(args):
            aggs = parse_fields(args[i + 1])
            i += 2
        elif args[i] == "-f" and i + 1 < len(args):
            fields = parse_fields(args[i + 1])
            i += 2
        elif args[i] == "-g" and i + 1 < len(args):
            groups = parse_fields(args[i + 1])
            i += 2
        else:
            rest.append(args[i])
            i += 1
    buckets = OrderedDict()
    for rec in records:
        gkey = tuple(rec.get(g, "") for g in groups)
        buckets.setdefault(gkey, []).append(rec)
    out = []
    for gkey, bucket in buckets.items():
        nr = OrderedDict((g, gkey[i]) for i, g in enumerate(groups))
        for field in fields:
            vals = [float(rec[field]) for rec in bucket if field in rec and display(rec[field]) != ""]
            for agg in aggs:
                name = f"{field}_{agg}"
                if agg == "count":
                    nr[name] = len(vals)
                elif agg == "min":
                    nr[name] = min(vals) if vals else ""
                elif agg == "max":
                    nr[name] = max(vals) if vals else ""
                elif agg == "sum":
                    nr[name] = sum(vals)
                elif agg == "mean":
                    nr[name] = sum(vals) / len(vals) if vals else ""
        out.append(nr)
    return out, rest


def verb_count(records, args):
    return [OrderedDict([("count", len(records))])], args


VERB_FUNCS = {
    "cat": verb_cat,
    "cut": verb_cut,
    "sort": verb_sort,
    "head": verb_head,
    "tail": verb_tail,
    "filter": verb_filter,
    "put": verb_put,
    "stats1": verb_stats1,
    "count": verb_count,
}


def parse_global(argv):
    cfg = Config()
    rest = []
    i = 0
    while i < len(argv):
        arg = argv[i]
        if arg in ("--csv", "-c", "--c2c"):
            cfg.ifmt = cfg.ofmt = "csv"
        elif arg in ("--tsv", "-t", "--t2t"):
            cfg.ifmt = cfg.ofmt = "tsv"
        elif arg in ("--dkvp", "--d2d"):
            cfg.ifmt = cfg.ofmt = "dkvp"
        elif arg in ("--json", "-j", "--j2j"):
            cfg.ifmt = cfg.ofmt = "json"
        elif arg in ("--jsonl", "--l2l"):
            cfg.ifmt = cfg.ofmt = "jsonl"
        elif arg in ("--pprint", "--p2p"):
            cfg.ifmt = cfg.ofmt = "pprint"
        elif arg.startswith("--i") and arg[3:] in ("csv", "tsv", "dkvp", "json", "jsonl"):
            cfg.ifmt = arg[3:]
        elif arg.startswith("--o") and arg[3:] in ("csv", "tsv", "dkvp", "json", "jsonl", "pprint"):
            cfg.ofmt = arg[3:]
        elif arg == "--opprint":
            cfg.ofmt = "pprint"
        elif arg == "--from" and i + 1 < len(argv):
            cfg.from_file = argv[i + 1]
            i += 1
        elif arg in ("--headerless-csv-output", "--ho"):
            cfg.headerless_csv_output = True
        elif arg == "-i" and i + 1 < len(argv):
            cfg.ifmt = argv[i + 1]
            i += 1
        elif arg == "-o" and i + 1 < len(argv):
            cfg.ofmt = argv[i + 1]
            i += 1
        else:
            rest.append(arg)
        i += 1
    return cfg, rest


def run(argv):
    if not argv or argv == ["--help"] or argv == ["help"]:
        sys.stdout.write(USAGE)
        return 0
    if argv[0] == "--version":
        sys.stdout.write("mlr 6.16.0\n")
        return 0
    if argv[0] == "help":
        topic = argv[1] if len(argv) > 1 else "topics"
        if topic == "topics":
            sys.stdout.write(TOPICS)
        elif topic == "basic-examples":
            sys.stdout.write(BASIC_EXAMPLES)
        elif topic == "list-verbs":
            sys.stdout.write(VERBS)
        elif topic == "file-formats":
            sys.stdout.write(FILE_FORMATS)
        else:
            sys.stdout.write(USAGE)
        return 0
    if argv[0] == "-l":
        sys.stdout.write(VERBS)
        return 0
    if argv[0] == "-g":
        sys.stdout.write("FILE-FORMAT FLAGS\n--csv\n--icsv\n--ocsv\n--ojson\n")
        return 0

    cfg, rest = parse_global(argv)
    if not rest:
        sys.stderr.write("mlr: verb required\n")
        return 1
    stages = split_pipeline(rest)
    verb_names = set(VERB_FUNCS)
    file_args = []
    if cfg.from_file:
        file_args = [cfg.from_file]
    else:
        for stage in stages:
            kept = []
            for token in stage:
                if token not in verb_names and os.path.exists(token):
                    file_args.append(token)
                else:
                    kept.append(token)
            stage[:] = kept
    text = read_all(file_args)
    records = parse_records(text, cfg.ifmt)
    for stage in stages:
        if not stage:
            continue
        verb = stage[0]
        func = VERB_FUNCS.get(verb)
        if func is None:
            sys.stderr.write(f"mlr: verb {verb} not implemented\n")
            return 1
        records, leftover = func(records, stage[1:])
        if leftover:
            # Treat unparsed trailing tokens as filenames only when no explicit --from was used.
            pass
    sys.stdout.write(emit_records(records, cfg.ofmt, cfg))
    return 0


if __name__ == "__main__":
    sys.exit(run(sys.argv[1:]))
