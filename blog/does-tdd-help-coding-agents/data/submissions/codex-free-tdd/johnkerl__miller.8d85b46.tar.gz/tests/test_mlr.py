import os
import subprocess
import textwrap
import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
MLR = ROOT / "src" / "mlr.py"


def run_mlr(args, input_text=None):
    env = os.environ.copy()
    proc = subprocess.run(
        ["python3", str(MLR), *args],
        input=input_text,
        text=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        cwd=ROOT,
        env=env,
    )
    return proc


CSV = """\
color,shape,flag,index,quantity,rate
red,square,true,1,11,5.5
blue,circle,false,2,7,3.5
red,triangle,true,3,8,4
"""


DKVP = """\
a=pan,b=pan,i=1,x=0.3
a=eks,b=pan,i=2,x=0.7
a=wye,b=wye,i=3,x=0.2
a=eks,b=wye,i=4,x=0.4
"""


def write_fixture(tmp_path, name, contents):
    path = tmp_path / name
    path.write_text(textwrap.dedent(contents))
    return str(path)


class MillerTests(unittest.TestCase):
    def setUp(self):
        import tempfile

        self._tmpdir = tempfile.TemporaryDirectory()
        self.tmp_path = Path(self._tmpdir.name)

    def tearDown(self):
        self._tmpdir.cleanup()

    def test_help_and_version_match_documented_entry_points(self):
        help_result = run_mlr(["--help"])
        self.assertEqual(help_result.returncode, 0)
        self.assertTrue(help_result.stdout.startswith(
            "Usage: mlr [flags] {verb} [verb-dependent options ...] {zero or more file names}\n"
        ))
        self.assertIn("Please see 'mlr help topics' for more information.", help_result.stdout)

        version_result = run_mlr(["--version"])
        self.assertEqual(version_result.returncode, 0)
        self.assertEqual(version_result.stdout, "mlr 6.16.0\n")

    def test_csv_cat_sort_cut_filter_put_and_then_pipeline(self):
        csv_path = write_fixture(self.tmp_path, "example.csv", CSV)

        self.assertEqual(run_mlr(["--icsv", "--opprint", "cat", csv_path]).stdout, """\
color shape    flag  index quantity rate
red   square   true  1     11       5.5
blue  circle   false 2     7        3.5
red   triangle true  3     8        4
""")

        self.assertEqual(run_mlr(["--icsv", "--opprint", "sort", "-f", "shape", csv_path]).stdout, """\
color shape    flag  index quantity rate
blue  circle   false 2     7        3.5
red   square   true  1     11       5.5
red   triangle true  3     8        4
""")

        self.assertEqual(run_mlr(["--icsv", "--opprint", "cut", "-f", "flag,shape", csv_path]).stdout, """\
shape    flag
square   true
circle   false
triangle true
""")

        self.assertEqual(run_mlr(["--csv", "filter", '$color == "red"', csv_path]).stdout, """\
color,shape,flag,index,quantity,rate
red,square,true,1,11,5.5
red,triangle,true,3,8,4
""")

        self.assertEqual(run_mlr(["--icsv", "--ojson", "put", "$ratio = $quantity / $rate", csv_path]).stdout, """\
[
{
  "color": "red",
  "shape": "square",
  "flag": "true",
  "index": 1,
  "quantity": 11,
  "rate": 5.5,
  "ratio": 2
},
{
  "color": "blue",
  "shape": "circle",
  "flag": "false",
  "index": 2,
  "quantity": 7,
  "rate": 3.5,
  "ratio": 2
},
{
  "color": "red",
  "shape": "triangle",
  "flag": "true",
  "index": 3,
  "quantity": 8,
  "rate": 4,
  "ratio": 2
}
]
""")

        self.assertEqual(run_mlr([
            "--icsv",
            "--opprint",
            "--from",
            csv_path,
            "sort",
            "-nr",
            "index",
            "then",
            "cut",
            "-f",
            "shape,quantity",
        ]).stdout, """\
shape    quantity
triangle 8
circle   7
square   11
""")


    def test_dkvp_conversion_sort_stats_and_windowing(self):
        dkvp_path = write_fixture(self.tmp_path, "sample.dkvp", DKVP)

        self.assertEqual(run_mlr(["cat", dkvp_path]).stdout, DKVP)
        self.assertEqual(run_mlr(["--ocsv", "cat", dkvp_path]).stdout, """\
a,b,i,x
pan,pan,1,0.3
eks,pan,2,0.7
wye,wye,3,0.2
eks,wye,4,0.4
""")
        self.assertEqual(run_mlr(["cut", "-f", "a,i", dkvp_path]).stdout, """\
a=pan,i=1
a=eks,i=2
a=wye,i=3
a=eks,i=4
""")
        self.assertEqual(run_mlr(["sort", "-f", "a", "-nr", "i", dkvp_path]).stdout, """\
a=eks,b=wye,i=4,x=0.4
a=eks,b=pan,i=2,x=0.7
a=pan,b=pan,i=1,x=0.3
a=wye,b=wye,i=3,x=0.2
""")
        self.assertEqual(run_mlr(["stats1", "-a", "count,min,mean,max,sum", "-f", "i", "-g", "a", dkvp_path]).stdout, """\
a=pan,i_count=1,i_min=1,i_mean=1,i_max=1,i_sum=1
a=eks,i_count=2,i_min=2,i_mean=3,i_max=4,i_sum=6
a=wye,i_count=1,i_min=3,i_mean=3,i_max=3,i_sum=3
""")
        self.assertEqual(run_mlr(["head", "-n", "2", dkvp_path]).stdout, """\
a=pan,b=pan,i=1,x=0.3
a=eks,b=pan,i=2,x=0.7
""")
        self.assertEqual(run_mlr(["tail", "-n", "2", dkvp_path]).stdout, """\
a=wye,b=wye,i=3,x=0.2
a=eks,b=wye,i=4,x=0.4
""")


    def test_json_and_json_lines_format_conversion(self):
        self.assertEqual(run_mlr(["--ijson", "--odkvp", "cat"], '[{"a":1,"b":2},{"a":3,"b":4}]').stdout, """\
a=1,b=2
a=3,b=4
""")
        self.assertEqual(run_mlr(["--ijsonl", "--ocsv", "cat"], '{"a":1,"b":2}\n{"a":3,"b":4}\n').stdout, """\
a,b
1,2
3,4
""")


if __name__ == "__main__":
    unittest.main()
