#!/usr/bin/env python3
import os
import subprocess
import tempfile
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
BIN = Path(os.environ.get("ZOXIDE_BIN", ROOT / "executable"))


def run(args, env=None, cwd=None):
    merged = os.environ.copy()
    if env:
        merged.update(env)
    return subprocess.run(
        [str(BIN), *args],
        cwd=cwd,
        env=merged,
        text=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
    )


def test_top_level_help_and_version():
    help_result = run(["--help"])
    assert help_result.returncode == 0
    assert "zoxide 0.9.9" in help_result.stdout
    assert "Usage:\n  executable <COMMAND>" in help_result.stdout
    assert "  query   Search for a directory in the database" in help_result.stdout

    version = run(["--version"])
    assert version.returncode == 0
    assert version.stdout == "zoxide 0.9.9\n"


def test_add_query_list_score_and_remove_roundtrip():
    with tempfile.TemporaryDirectory() as td:
        base = Path(td)
        data = base / "data"
        afoo = base / "a" / "foo"
        bfoo = base / "b" / "foo"
        abar = base / "a" / "bar"
        for path in [afoo, bfoo, abar]:
            path.mkdir(parents=True)
        env = {"_ZO_DATA_DIR": str(data)}

        assert run(["add", str(afoo)], env).returncode == 0
        assert run(["add", "-s", "5", str(bfoo)], env).returncode == 0
        assert run(["add", str(abar)], env).returncode == 0

        assert run(["query", "foo"], env).stdout == f"{bfoo}\n"
        assert run(["query", "-l", "foo"], env).stdout == f"{bfoo}\n{afoo}\n"
        assert run(["query", "-ls", "foo"], env).stdout == f"  20.0 {bfoo}\n   4.0 {afoo}\n"
        assert run(["query", "--base-dir", str(base / "a"), "foo"], env).stdout == f"{afoo}\n"
        assert run(["query", "--exclude", str(bfoo), "foo"], env).stdout == f"{afoo}\n"

        assert run(["remove", str(bfoo)], env).returncode == 0
        assert run(["query", "-l", "foo"], env).stdout == f"{afoo}\n"


def test_query_matching_and_no_match_status():
    with tempfile.TemporaryDirectory() as td:
        base = Path(td)
        data = base / "data"
        paths = [base / "AlphaBeta", base / "alpha" / "gamma", base / "foo" / "barbaz", base / "foobar"]
        for path in paths:
            path.mkdir(parents=True)
        env = {"_ZO_DATA_DIR": str(data)}
        assert run(["add", "-s", "1", *map(str, paths)], env).returncode == 0

        assert run(["query", "-l", "alpha"], env).stdout == f"{paths[0]}\n"
        assert run(["query", "-l", "foo/"], env).stdout == f"{paths[2]}\n"
        assert run(["query", "-l", "bar"], env).stdout == f"{paths[3]}\n{paths[2]}\n"

        nomatch = run(["query", "nomatch"], env)
        assert nomatch.returncode == 1
        assert nomatch.stderr == "zoxide: no match found\n"

        list_nomatch = run(["query", "-l", "nomatch"], env)
        assert list_nomatch.returncode == 0
        assert list_nomatch.stdout == ""
        assert list_nomatch.stderr == ""


def test_import_z_format_replaces_or_merges_database():
    with tempfile.TemporaryDirectory() as td:
        base = Path(td)
        data = base / "data"
        first = base / "first"
        second = base / "second"
        third = base / "third"
        for path in [first, second, third]:
            path.mkdir()
        env = {"_ZO_DATA_DIR": str(data)}

        db = base / "zdb"
        db.write_text(f"{first}|10|100\n{second}|2|200\n")
        assert run(["import", "--from", "z", str(db)], env).returncode == 0
        assert run(["query", "-ls"], env).stdout == f"   2.5 {first}\n   0.5 {second}\n"

        merge = base / "zdb2"
        merge.write_text(f"{third}|8|300\n")
        assert run(["import", "--from", "z", "--merge", str(merge)], env).returncode == 0
        assert run(["query", "-ls"], env).stdout == f"   2.5 {first}\n   2.0 {third}\n   0.5 {second}\n"


def test_common_errors_and_init_shell_snippet():
    add_missing = run(["add"])
    assert add_missing.returncode == 2
    assert "error: the following required arguments were not provided:" in add_missing.stderr

    with tempfile.TemporaryDirectory() as td:
        data = str(Path(td) / "data")
        bad = run(["add", "/no/such/path"], {"_ZO_DATA_DIR": data})
        assert bad.returncode == 1
        assert bad.stderr == "zoxide: not a directory: /no/such/path\n"

    init = run(["init", "bash", "--hook", "none"])
    assert init.returncode == 0
    assert "function __zoxide_z()" in init.stdout
    assert "\\command zoxide query --interactive -- \"$@\"" in init.stdout
    assert "function z()" in init.stdout


def test_combined_query_flags_and_excluded_add_paths():
    with tempfile.TemporaryDirectory() as td:
        base = Path(td)
        home = base / "home"
        private = home / "private"
        other = base / "other"
        for path in [home, private, other]:
            path.mkdir(parents=True, exist_ok=True)

        data = base / "data1"
        env = {"_ZO_DATA_DIR": str(data), "_ZO_EXCLUDE_DIRS": f"{home}:{other}"}
        assert run(["add", str(home), str(private), str(other)], env).returncode == 0
        assert run(["query", "-la"], {"_ZO_DATA_DIR": str(data)}).stdout == f"{private}\n"

        data2 = base / "data2"
        env2 = {"_ZO_DATA_DIR": str(data2), "_ZO_EXCLUDE_DIRS": f"{home}/*"}
        assert run(["add", str(home), str(private), str(other)], env2).returncode == 0
        assert run(["query", "-la"], {"_ZO_DATA_DIR": str(data2)}).stdout == f"{other}\n{home}\n"
