#!/usr/bin/env python3
import os
import fnmatch
import struct
import sys
import time
from pathlib import Path


VERSION = "0.9.9"
HEADER = """zoxide 0.9.9
Ajeet D'Souza <98ajeet@gmail.com>
https://github.com/ajeetdsouza/zoxide

A smarter cd command for your terminal

Usage:
  executable <COMMAND>

Commands:
  add     Add a new directory or increment its rank
  edit    Edit the database
  import  Import entries from another application
  init    Generate shell configuration
  query   Search for a directory in the database
  remove  Remove a directory from the database

Options:
  -h, --help     Print help
  -V, --version  Print version

Environment variables:
  _ZO_DATA_DIR          Path for zoxide data files
  _ZO_ECHO              Print the matched directory before navigating to it when set to 1
  _ZO_EXCLUDE_DIRS      List of directory globs to be excluded
  _ZO_FZF_OPTS          Custom flags to pass to fzf
  _ZO_MAXAGE            Maximum total age after which entries start getting deleted
  _ZO_RESOLVE_SYMLINKS  Resolve symlinks when storing paths
"""


HELP = {
    "add": """zoxide-add 0.9.9
Ajeet D'Souza <98ajeet@gmail.com>
https://github.com/ajeetdsouza/zoxide

Add a new directory or increment its rank

Usage:
  executable add [OPTIONS] <PATHS>...

Arguments:
  <PATHS>...  

Options:
  -s, --score <SCORE>  The rank to increment the entry if it exists or initialize it with if it doesn't
  -h, --help           Print help
  -V, --version        Print version
""",
    "query": """zoxide-query 0.9.9
Ajeet D'Souza <98ajeet@gmail.com>
https://github.com/ajeetdsouza/zoxide

Search for a directory in the database

Usage:
  executable query [OPTIONS] [KEYWORDS]...

Options:
  -a, --all              Show unavailable directories
  -i, --interactive      Use interactive selection
  -l, --list             List all matching directories
  -s, --score            Print score with results
      --exclude <path>   Exclude the current directory
      --base-dir <path>  Only search within this directory
  -h, --help             Print help
  -V, --version          Print version
""",
    "remove": """zoxide-remove 0.9.9
Ajeet D'Souza <98ajeet@gmail.com>
https://github.com/ajeetdsouza/zoxide

Remove a directory from the database

Usage:
  executable remove [PATHS]...

Options:
  -h, --help     Print help
  -V, --version  Print version
""",
    "import": """zoxide-import 0.9.9
Ajeet D'Souza <98ajeet@gmail.com>
https://github.com/ajeetdsouza/zoxide

Import entries from another application

Usage:
  executable import [OPTIONS] --from <FROM> <PATH>

Options:
      --from <FROM>  Application to import from [possible values: autojump, z]
      --merge        Merge into existing database
  -h, --help         Print help
  -V, --version      Print version
""",
    "init": """zoxide-init 0.9.9
Ajeet D'Souza <98ajeet@gmail.com>
https://github.com/ajeetdsouza/zoxide

Generate shell configuration

Usage:
  executable init [OPTIONS] <SHELL>

Options:
      --no-cmd       Prevents zoxide from defining the `z` and `zi` commands
      --cmd <CMD>    Changes the prefix of the `z` and `zi` commands [default: z]
      --hook <HOOK>  Changes how often zoxide increments a directory's score [default: pwd] [possible values: none, prompt, pwd]
  -h, --help         Print help
  -V, --version      Print version
""",
}


def db_path():
    data = os.environ.get("_ZO_DATA_DIR")
    if not data:
        data = os.path.join(os.environ.get("XDG_DATA_HOME", os.path.expanduser("~/.local/share")), "zoxide")
    return Path(data) / "db.zo"


def load_db():
    path = db_path()
    if not path.exists():
        return []
    raw = path.read_bytes()
    if len(raw) < 12:
        return []
    off = 0
    _version = struct.unpack_from("<I", raw, off)[0]
    off += 4
    count = struct.unpack_from("<Q", raw, off)[0]
    off += 8
    entries = []
    for _ in range(count):
        if off + 8 > len(raw):
            break
        n = struct.unpack_from("<Q", raw, off)[0]
        off += 8
        p = raw[off:off+n].decode()
        off += n
        score = struct.unpack_from("<d", raw, off)[0]
        off += 8
        ts = struct.unpack_from("<q", raw, off)[0]
        off += 8
        entries.append([p, score, ts])
    return entries


def save_db(entries):
    path = db_path()
    path.parent.mkdir(parents=True, exist_ok=True)
    buf = bytearray()
    buf += struct.pack("<IQ", 3, len(entries))
    for p, score, ts in entries:
        b = p.encode()
        buf += struct.pack("<Q", len(b)) + b + struct.pack("<dq", float(score), int(ts))
    path.write_bytes(buf)


def canonical(path):
    return os.path.realpath(path) if os.environ.get("_ZO_RESOLVE_SYMLINKS") == "1" else os.path.abspath(path)


def excluded(path):
    raw = os.environ.get("_ZO_EXCLUDE_DIRS")
    if raw is None:
        raw = os.environ.get("HOME", "")
    path = canonical(path)
    for pattern in [p for p in raw.split(":") if p]:
        pattern = canonical(os.path.expanduser(pattern))
        if fnmatch.fnmatch(path, pattern):
            return True
    return False


def err(msg, code=1):
    sys.stderr.write(msg)
    return code


def cmd_add(args):
    if "-h" in args or "--help" in args:
        print(HELP["add"], end="")
        return 0
    if "-V" in args or "--version" in args:
        print(f"zoxide-add {VERSION}")
        return 0
    score = 1.0
    paths = []
    i = 0
    while i < len(args):
        a = args[i]
        if a == "--":
            paths.extend(args[i+1:])
            break
        if a in ("-s", "--score"):
            i += 1
            try:
                score = float(args[i])
            except Exception:
                return err(f"error: invalid value '{args[i] if i < len(args) else ''}' for '--score <SCORE>': invalid float literal\n\nFor more information, try '--help'.\n", 2)
        else:
            paths.append(a)
        i += 1
    if not paths:
        return err("error: the following required arguments were not provided:\n  <PATHS>...\n\nUsage: executable add <PATHS>...\n\nFor more information, try '--help'.\n", 2)
    entries = load_db()
    now = int(time.time())
    for p in paths:
        if not os.path.isdir(p):
            return err(f"zoxide: not a directory: {p}\n")
        p = canonical(p)
        if excluded(p):
            continue
        for e in entries:
            if e[0] == p:
                e[1] += score
                e[2] = now
                break
        else:
            entries.append([p, score, now])
    save_db(entries)
    return 0


def frecency(entry):
    age = int(time.time()) - int(entry[2])
    if age > 60 * 60 * 24 * 30:
        return entry[1] / 4.0
    return entry[1] * 4.0


def matches(path, keywords):
    low = path.lower()
    base = os.path.basename(low)
    for kw in keywords:
        k = kw.lower()
        if k.endswith("/"):
            needle = "/" + k
            if needle not in low + "/":
                return False
        elif "/" in k:
            if k not in low:
                return False
        else:
            if k not in base:
                return False
    return True


def parse_query(args):
    opts = {"list": False, "score": False, "all": False, "interactive": False, "exclude": None, "base": None}
    words = []
    i = 0
    while i < len(args):
        a = args[i]
        if a == "--":
            words.extend(args[i+1:])
            break
        if a in ("-h", "--help"):
            opts["help"] = True
        elif a in ("-V", "--version"):
            opts["version"] = True
        elif a in ("-l", "--list"):
            opts["list"] = True
        elif a in ("-s", "--score"):
            opts["score"] = True
        elif a in ("-a", "--all"):
            opts["all"] = True
        elif a in ("-i", "--interactive"):
            opts["interactive"] = True
        elif a.startswith("-") and len(a) > 2 and not a.startswith("--"):
            for flag in a[1:]:
                if flag == "l":
                    opts["list"] = True
                elif flag == "s":
                    opts["score"] = True
                elif flag == "a":
                    opts["all"] = True
                elif flag == "i":
                    opts["interactive"] = True
                else:
                    return None, None, err(f"error: unexpected argument '{a}' found\n\nUsage: executable query [KEYWORDS]...\n\nFor more information, try '--help'.\n", 2)
        elif a == "--exclude":
            i += 1
            opts["exclude"] = canonical(args[i])
        elif a == "--base-dir":
            i += 1
            opts["base"] = canonical(args[i])
        elif a.startswith("-"):
            return None, None, err(f"error: unexpected argument '{a}' found\n\nUsage: executable query [KEYWORDS]...\n\nFor more information, try '--help'.\n", 2)
        else:
            words.append(a)
        i += 1
    return opts, words, None


def cmd_query(args):
    opts, words, bad = parse_query(args)
    if bad is not None:
        return bad
    if opts.get("help"):
        print(HELP["query"], end="")
        return 0
    if opts.get("version"):
        print(f"zoxide-query {VERSION}")
        return 0
    if opts["interactive"]:
        return err("zoxide: fzf returned an unknown error\n")
    entries = load_db()
    rows = []
    for e in entries:
        p = e[0]
        if opts["exclude"] and canonical(p) == opts["exclude"]:
            continue
        if opts["base"] and not (canonical(p) == opts["base"] or canonical(p).startswith(opts["base"].rstrip("/") + "/")):
            continue
        if not opts["all"] and not os.path.isdir(p):
            continue
        if matches(p, words):
            rows.append(e)
    rows.sort(key=lambda e: (frecency(e), e[2], e[0]), reverse=True)
    if not rows:
        if opts["list"]:
            return 0
        return err("zoxide: no match found\n")
    out_rows = rows if opts["list"] else rows[:1]
    for e in out_rows:
        if opts["score"]:
            sys.stdout.write(f"{frecency(e):6.1f} {e[0]}\n")
        else:
            sys.stdout.write(e[0] + "\n")
    return 0


def cmd_remove(args):
    if "-h" in args or "--help" in args:
        print(HELP["remove"], end="")
        return 0
    if "-V" in args or "--version" in args:
        print(f"zoxide-remove {VERSION}")
        return 0
    remove = {canonical(a) for a in args if a != "--"}
    if remove:
        save_db([e for e in load_db() if canonical(e[0]) not in remove])
    return 0


def cmd_import(args):
    if "-h" in args or "--help" in args:
        print(HELP["import"], end="")
        return 0
    source = None
    merge = False
    path = None
    i = 0
    while i < len(args):
        a = args[i]
        if a == "--from":
            i += 1
            source = args[i]
        elif a.startswith("--from="):
            source = a.split("=", 1)[1]
        elif a == "--merge":
            merge = True
        else:
            path = a
        i += 1
    if source != "z":
        return err("zoxide: import error\n")
    try:
        lines = Path(path).read_text().splitlines()
    except OSError:
        return err(f"zoxide: could not open database for importing: {path}\n\nCaused by:\n    No such file or directory (os error 2)\n")
    entries = load_db() if merge else []
    by_path = {e[0]: e for e in entries}
    for line in lines:
        if not line.strip():
            continue
        try:
            p, rank, ts = line.rsplit("|", 2)
            e = [canonical(p), float(rank), int(float(ts))]
        except Exception:
            return err("zoxide: import error\n")
        by_path[e[0]] = e
    save_db(list(by_path.values()))
    return 0


def cmd_init(args):
    if "-h" in args or "--help" in args:
        print(HELP["init"], end="")
        return 0
    shell = None
    cmd = "z"
    no_cmd = False
    hook = "pwd"
    i = 0
    while i < len(args):
        a = args[i]
        if a == "--cmd":
            i += 1
            cmd = args[i]
        elif a.startswith("--cmd="):
            cmd = a.split("=", 1)[1]
        elif a == "--no-cmd":
            no_cmd = True
        elif a == "--hook":
            i += 1
            hook = args[i]
        elif a.startswith("--hook="):
            hook = a.split("=", 1)[1]
        else:
            shell = a
        i += 1
    if shell is None:
        return err("error: the following required arguments were not provided:\n  <SHELL>\n\nUsage: executable init <SHELL>\n\nFor more information, try '--help'.\n", 2)
    if shell not in {"bash", "zsh", "fish", "posix", "elvish", "nushell", "powershell", "tcsh", "xonsh"}:
        return err(f"error: invalid value '{shell}' for '<SHELL>'\n  [possible values: bash, elvish, fish, nushell, posix, powershell, tcsh, xonsh, zsh]\n\nFor more information, try '--help'.\n", 2)
    if hook not in {"none", "prompt", "pwd"}:
        return err(f"error: invalid value '{hook}' for '--hook <HOOK>'\n  [possible values: none, prompt, pwd]\n\nFor more information, try '--help'.\n", 2)
    print(init_script(shell, cmd, no_cmd, hook), end="")
    return 0


def init_script(shell, cmd, no_cmd, hook):
    if shell == "fish":
        define = "" if no_cmd else f"\nfunction {cmd}\n    __zoxide_z $argv\nend\nfunction {cmd}i\n    __zoxide_zi $argv\nend\n"
        return f"""# =============================================================================
#
# Utility functions for zoxide.
#
function __zoxide_pwd
    builtin pwd -L
end
function __zoxide_cd
    builtin cd $argv
end
function __zoxide_z
    set -l result (command zoxide query --exclude (__zoxide_pwd) -- $argv)
    and __zoxide_cd $result
end
function __zoxide_zi
    set -l result (command zoxide query --interactive -- $argv)
    and __zoxide_cd $result
end{define}"""
    hook_part = ""
    if hook == "none":
        hook_part = "function __zoxide_doctor() {\n    return 0\n}\n"
    else:
        hook_part = """function __zoxide_hook() {
    \\command zoxide add -- "$(__zoxide_pwd)"
}
"""
    commands = ""
    if not no_cmd:
        commands = f"""
\\builtin unalias {cmd} &>/dev/null || \\builtin true
function {cmd}() {{
    __zoxide_z "$@"
}}

\\builtin unalias {cmd}i &>/dev/null || \\builtin true
function {cmd}i() {{
    __zoxide_zi "$@"
}}
"""
    return f"""# shellcheck shell=bash

# =============================================================================
#
# Utility functions for zoxide.
#
function __zoxide_pwd() {{
    \\builtin pwd -L
}}

function __zoxide_cd() {{
    \\builtin cd -- "$@"
}}

# =============================================================================
#
# Hook configuration for zoxide.
#
{hook_part}
# =============================================================================
#
# When using zoxide with --no-cmd, alias these internal functions as desired.
#
function __zoxide_z() {{
    if [[ $# -eq 0 ]]; then
        __zoxide_cd ~
    else
        \\builtin local result
        result="$(\\command zoxide query --exclude "$(__zoxide_pwd)" -- "$@")" &&
            __zoxide_cd "${{result}}"
    fi
}}

function __zoxide_zi() {{
    \\builtin local result
    result="$(\\command zoxide query --interactive -- "$@")" && __zoxide_cd "${{result}}"
}}
{commands}"""


def cmd_edit(_args):
    editor = os.environ.get("EDITOR")
    if not editor:
        return err("zoxide: EDITOR is not set\n")
    return os.system(f"{editor} {db_path()}") >> 8


def main(argv):
    if not argv or argv[0] in ("-h", "--help"):
        print(HEADER, end="")
        return 0
    if argv[0] in ("-V", "--version"):
        print(f"zoxide {VERSION}")
        return 0
    cmd, args = argv[0], argv[1:]
    if cmd == "add":
        return cmd_add(args)
    if cmd == "query":
        return cmd_query(args)
    if cmd == "remove":
        return cmd_remove(args)
    if cmd == "import":
        return cmd_import(args)
    if cmd == "init":
        return cmd_init(args)
    if cmd == "edit":
        return cmd_edit(args)
    return err(f"error: unrecognized subcommand '{cmd}'\n\nUsage: executable <COMMAND>\n\nFor more information, try '--help'.\n", 2)


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
