#!/usr/bin/env python3
import json
import re
import sys


VERSION = "solar 0.1.8-dev (8f228ae 2026-04-17T19:59:51.519973035Z)"
JSON_VERSION = "0.1.8"


HELP = """Blazingly fast Solidity compiler

Usage: executable [OPTIONS] [INPUT]...

Arguments:
  [INPUT]...  Files to compile, or import remappings

Options:
  -j, --threads <THREADS>          Number of threads to use. Zero specifies the number of logical cores [default: 4] [aliases: --jobs]
      --evm-version <EVM_VERSION>  EVM version [default: prague] [possible values: homestead, tangerineWhistle, spuriousDragon, byzantium, constantinople, petersburg, istanbul, berlin, london, paris, shanghai, cancun, prague, osaka]
      --stop-after <STOP_AFTER>    Stop execution after the given compiler stage [possible values: parsing, lowering, analysis]
      --out-dir <OUT_DIR>          Directory to write output files
      --emit <EMIT>                Comma separated list of types of output for the compiler to emit [possible values: abi, hashes]
  -Z <FLAG>                        Unstable flags. WARNING: these are completely unstable, and may change at any time
  -h, --help                       Print help (see more with '--help')
  -V, --version                    Print version

Input options:
      --base-path <BASE_PATH>        Use the given path as the root of the source tree
  -I, --include-path <INCLUDE_PATH>  Directory to search for files
      --allow-paths <ALLOW_PATHS>    Allow a given path for imports

Display options:
      --color <COLOR>                Coloring [default: auto] [possible values: auto, always, never]
  -v, --verbose                      Use verbose output
      --pretty-json                  Pretty-print JSON output
      --pretty-json-err              Pretty-print error JSON output
      --error-format <ERROR_FORMAT>  How errors and other messages are produced [default: human] [possible values: human, json, rustc-json]
      --error-format-human <VALUE>   Human-readable error message style [default: unicode] [possible values: ascii, unicode, short]
      --diagnostic-width <WIDTH>     Terminal width for error message formatting
      --no-warnings                  Whether to disable warnings
"""

UNSTABLE_HELP = """error: List of all unstable flags.
WARNING: these are completely unstable, and may change at any time!

Options:
      -Zui-testing
          Enables UI testing mode

      -Ztrack-diagnostics
          Prints a note for every diagnostic that is emitted with the creation and emission location.

      -Zparse-yul
          Enables parsing Yul files for testing

      -Zno-resolve-imports
          Disables import resolution

      -Zdump=<KIND[=PATHS...]>
          Print additional information about the compiler's internal state.

      -Zast-stats
          Print AST stats

      -Zspan-visitor
          Run the span visitor after parsing

      -Zprint-max-storage-sizes
          Print contracts' max storage sizes

      -Ztypeck
          Type check the program. WIP

      -Zhelp
          Print help

Usage: solar [OPTIONS] [INPUT]...

For more information, try '--help'.
"""


def parse_args(argv):
    emit = []
    pretty = False
    out_dir = None
    inputs = []
    i = 0
    while i < len(argv):
        arg = argv[i]
        if arg in ("-h", "--help"):
            return {"help": True}
        if arg in ("-V", "--version"):
            return {"version": True}
        if arg == "-Zhelp":
            return {"zhelp": True}
        if arg == "--pretty-json":
            pretty = True
        elif arg == "--emit":
            i += 1
            if i >= len(argv):
                return {"cli_error": "error: a value is required for '--emit <EMIT>' but none was supplied\n"}
            emit = argv[i].split(",")
            for item in emit:
                if item not in ("abi", "hashes"):
                    return {"cli_error": f"error: invalid value '{item}' for '--emit <EMIT>'\n  [possible values: abi, hashes]\n\nFor more information, try '--help'.\n"}
        elif arg.startswith("--emit="):
            emit = arg.split("=", 1)[1].split(",")
            for item in emit:
                if item not in ("abi", "hashes"):
                    return {"cli_error": f"error: invalid value '{item}' for '--emit <EMIT>'\n  [possible values: abi, hashes]\n\nFor more information, try '--help'.\n"}
        elif arg == "-":
            inputs.append(arg)
        elif arg.startswith("-"):
            if arg == "--out-dir":
                i += 1
                if i >= len(argv):
                    return {"cli_error": "error: a value is required for '--out-dir <OUT_DIR>' but none was supplied\n"}
                out_dir = argv[i]
            elif arg in ("-j", "--threads", "--jobs", "--evm-version", "--stop-after", "--base-path", "-I", "--include-path", "--allow-paths", "--color", "--error-format", "--error-format-human", "--diagnostic-width", "-Z"):
                i += 1
            elif arg == "-v" or arg in ("--verbose", "--pretty-json-err", "--no-warnings"):
                pass
            else:
                return {"cli_error": f"error: unexpected argument '{arg}' found\n\nUsage: executable [OPTIONS] [INPUT]...\n\nFor more information, try '--help'.\n"}
        else:
            inputs.append(arg)
        i += 1
    return {"emit": emit, "pretty": pretty, "inputs": inputs, "out_dir": out_dir}


def strip_comments(source):
    source = re.sub(r"//.*", "", source)
    return re.sub(r"/\*.*?\*/", "", source, flags=re.S)


def find_matching_brace(source, start):
    depth = 0
    for i in range(start, len(source)):
        if source[i] == "{":
            depth += 1
        elif source[i] == "}":
            depth -= 1
            if depth == 0:
                return i
    return len(source) - 1


def split_top_level(text):
    parts = []
    current = []
    depth = 0
    for ch in text:
        if ch == "," and depth == 0:
            part = "".join(current).strip()
            if part:
                parts.append(part)
            current = []
            continue
        if ch in "([":
            depth += 1
        elif ch in ")]" and depth:
            depth -= 1
        current.append(ch)
    part = "".join(current).strip()
    if part:
        parts.append(part)
    return parts


def canonical_type(type_words):
    words = [w for w in type_words if w not in ("memory", "calldata", "storage", "indexed")]
    internal = " ".join(words)
    typ = internal.replace(" payable", "")
    typ = re.sub(r"\buint\b", "uint256", typ)
    typ = re.sub(r"\bint\b", "int256", typ)
    internal = re.sub(r"\buint\b", "uint256", internal)
    internal = re.sub(r"\bint\b", "int256", internal)
    return typ, internal


def parse_params(text, include_indexed=False):
    params = []
    for raw in split_top_level(text):
        tokens = raw.split()
        if not tokens:
            continue
        name = ""
        if len(tokens) > 1 and re.match(r"^[A-Za-z_][A-Za-z0-9_]*$", tokens[-1]) and tokens[-1] not in (
            "memory",
            "calldata",
            "storage",
            "payable",
            "indexed",
        ):
            name = tokens.pop()
        indexed = "indexed" in tokens
        typ, internal = canonical_type(tokens)
        item = {"name": name, "type": typ, "internalType": internal}
        if include_indexed:
            item["indexed"] = indexed
        params.append(item)
    return params


def state_mutability(signature_tail):
    if "pure" in signature_tail:
        return "pure"
    if "view" in signature_tail:
        return "view"
    if "payable" in signature_tail:
        return "payable"
    return "nonpayable"


def contract_spans(source):
    for match in re.finditer(r"\b(?:contract|interface|library)\s+([A-Za-z_][A-Za-z0-9_]*)\b", source):
        brace = source.find("{", match.end())
        if brace == -1:
            continue
        end = find_matching_brace(source, brace)
        yield match.group(1), source[brace + 1 : end]


def parse_abi(body):
    constructors = []
    errors = []
    events = []
    functions = []
    getters = []

    for match in re.finditer(r"\bconstructor\s*\(([^)]*)\)\s*([^{;]*)", body):
        constructors.append(
            {
                "type": "constructor",
                "inputs": parse_params(match.group(1)),
                "stateMutability": state_mutability(match.group(2)),
            }
        )

    for match in re.finditer(r"\berror\s+([A-Za-z_][A-Za-z0-9_]*)\s*\(([^)]*)\)\s*;", body):
        errors.append({"type": "error", "name": match.group(1), "inputs": parse_params(match.group(2))})

    for match in re.finditer(r"\bevent\s+([A-Za-z_][A-Za-z0-9_]*)\s*\(([^)]*)\)\s*(anonymous)?\s*;", body):
        events.append(
            {
                "type": "event",
                "name": match.group(1),
                "inputs": parse_params(match.group(2), include_indexed=True),
                "anonymous": bool(match.group(3)),
            }
        )

    func_re = re.compile(r"\bfunction\s+([A-Za-z_][A-Za-z0-9_]*)\s*\(([^)]*)\)\s*([^;{]*?)(?:returns\s*\(([^)]*)\))?\s*(?=[{;])", re.S)
    for match in func_re.finditer(body):
        tail = match.group(3)
        if "internal" in tail or "private" in tail:
            continue
        functions.append(
            {
                "type": "function",
                "name": match.group(1),
                "inputs": parse_params(match.group(2)),
                "outputs": parse_params(match.group(4) or ""),
                "stateMutability": state_mutability(tail),
            }
        )

    occupied = []
    for pat in (r"\bfunction\b.*?(?=[{;])", r"\bevent\b.*?;", r"\berror\b.*?;", r"\bconstructor\b.*?(?=[{;])"):
        occupied.extend((m.start(), m.end()) for m in re.finditer(pat, body, flags=re.S))

    def is_occupied(pos):
        return any(start <= pos < end for start, end in occupied)

    var_re = re.compile(r"\b([A-Za-z_][A-Za-z0-9_]*(?:\s+(?:payable))?)\s+public\s+([A-Za-z_][A-Za-z0-9_]*)\s*(?:[=;])")
    for match in var_re.finditer(body):
        if is_occupied(match.start()):
            continue
        typ, internal = canonical_type(match.group(1).split())
        getters.append(
            {
                "type": "function",
                "name": match.group(2),
                "inputs": [],
                "outputs": [{"name": "", "type": typ, "internalType": internal}],
                "stateMutability": "view",
            }
        )

    return constructors + errors + events + functions + getters


def rol(value, shift):
    return ((value << shift) | (value >> (64 - shift))) & ((1 << 64) - 1)


def keccak256(data):
    rate = 136
    lanes = [0] * 25
    rotations = [
        0, 1, 62, 28, 27, 36, 44, 6, 55, 20, 3, 10, 43,
        25, 39, 41, 45, 15, 21, 8, 18, 2, 61, 56, 14,
    ]
    rounds = [
        0x0000000000000001, 0x0000000000008082, 0x800000000000808A, 0x8000000080008000,
        0x000000000000808B, 0x0000000080000001, 0x8000000080008081, 0x8000000000008009,
        0x000000000000008A, 0x0000000000000088, 0x0000000080008009, 0x000000008000000A,
        0x000000008000808B, 0x800000000000008B, 0x8000000000008089, 0x8000000000008003,
        0x8000000000008002, 0x8000000000000080, 0x000000000000800A, 0x800000008000000A,
        0x8000000080008081, 0x8000000000008080, 0x0000000080000001, 0x8000000080008008,
    ]

    padded = bytearray(data)
    padded.append(0x01)
    while len(padded) % rate != rate - 1:
        padded.append(0)
    padded.append(0x80)

    for offset in range(0, len(padded), rate):
        block = padded[offset : offset + rate]
        for i in range(rate // 8):
            lanes[i] ^= int.from_bytes(block[i * 8 : i * 8 + 8], "little")
        for rc in rounds:
            c = [lanes[x] ^ lanes[x + 5] ^ lanes[x + 10] ^ lanes[x + 15] ^ lanes[x + 20] for x in range(5)]
            d = [c[(x - 1) % 5] ^ rol(c[(x + 1) % 5], 1) for x in range(5)]
            for x in range(5):
                for y in range(5):
                    lanes[x + 5 * y] ^= d[x]
            b = [0] * 25
            for x in range(5):
                for y in range(5):
                    b[y + 5 * ((2 * x + 3 * y) % 5)] = rol(lanes[x + 5 * y], rotations[x + 5 * y])
            for x in range(5):
                for y in range(5):
                    lanes[x + 5 * y] = b[x + 5 * y] ^ ((~b[((x + 1) % 5) + 5 * y]) & b[((x + 2) % 5) + 5 * y])
            lanes[0] ^= rc

    out = bytearray()
    while len(out) < 32:
        for i in range(rate // 8):
            out.extend(lanes[i].to_bytes(8, "little"))
    return bytes(out[:32])


def signature(item):
    types = ",".join(inp["type"] for inp in item.get("inputs", []))
    return f"{item['name']}({types})"


def contracts_from_source(source, label):
    source = strip_comments(source)
    contracts = {}
    for name, body in contract_spans(source):
        contracts[f"{label}:{name}"] = {"abi": parse_abi(body)}
    return contracts


def main(argv):
    args = parse_args(argv)
    if args.get("help"):
        print(HELP, end="")
        return 0
    if args.get("version"):
        print(VERSION)
        return 0
    if args.get("zhelp"):
        print(UNSTABLE_HELP, end="", file=sys.stderr)
        return 0
    if args.get("cli_error"):
        print(args["cli_error"], end="", file=sys.stderr)
        return 2
    if not args["inputs"]:
        print(HELP, end="")
        return 2
    if not args["emit"]:
        for inp in args["inputs"]:
            if inp == "-":
                sys.stdin.read()
            else:
                try:
                    open(inp, "r", encoding="utf-8").close()
                except FileNotFoundError:
                    print(f"error: file {inp} not found\n\nerror: aborting due to 1 previous error\n", file=sys.stderr)
                    return 1
        return 0

    all_contracts = {}
    for inp in args["inputs"]:
        if inp == "-":
            source = sys.stdin.read()
            label = "<stdin>"
        else:
            try:
                with open(inp, "r", encoding="utf-8") as f:
                    source = f.read()
            except FileNotFoundError:
                print(f"error: file {inp} not found\n\nerror: aborting due to 1 previous error\n", file=sys.stderr)
                return 1
            label = inp
        parsed = contracts_from_source(source, label)
        for contract_name, data in sorted(parsed.items()):
            item = {}
            if "abi" in args["emit"]:
                item["abi"] = data["abi"]
            if "hashes" in args["emit"]:
                hashes = {}
                for abi_item in data["abi"]:
                    if abi_item.get("type") == "function":
                        sig = signature(abi_item)
                        hashes[sig] = keccak256(sig.encode()).hex()[:8]
                item["hashes"] = hashes
            all_contracts[contract_name] = item

    result = {"contracts": all_contracts, "version": JSON_VERSION}
    if args["out_dir"]:
        try:
            with open(f"{args['out_dir'].rstrip('/')}/combined.json", "w", encoding="utf-8") as f:
                f.write(json.dumps(result, separators=(",", ":")))
        except OSError as e:
            print(f"error: failed to write to output: {e.strerror} (os error {e.errno})\n\nerror: aborting due to 1 previous error\n", file=sys.stderr)
            return 1
        return 0
    if args["pretty"]:
        print(json.dumps(result, indent=2))
    else:
        print(json.dumps(result, separators=(",", ":")))
    return 0


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
