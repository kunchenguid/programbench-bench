import json
import os
import subprocess
import tempfile
import unittest


ROOT = os.path.dirname(os.path.dirname(__file__))
IMPL = os.path.join(ROOT, "src", "solar.py")


class SolarCliTests(unittest.TestCase):
    def run_impl(self, args, stdin=""):
        self.assertTrue(os.path.exists(IMPL), "implementation script should exist")
        return subprocess.run(
            ["python3", IMPL, *args],
            input=stdin,
            text=True,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
        )

    def test_help_summary_matches_documented_cli(self):
        proc = self.run_impl(["--help"])
        self.assertEqual(proc.returncode, 0)
        self.assertIn("Blazingly fast Solidity compiler", proc.stdout)
        self.assertIn("Usage: executable [OPTIONS] [INPUT]...", proc.stdout)
        self.assertIn("--emit <EMIT>", proc.stdout)

    def test_version_matches_reference_readme_release(self):
        proc = self.run_impl(["--version"])
        self.assertEqual(proc.returncode, 0)
        self.assertEqual(proc.stdout.strip(), "solar 0.1.8-dev (8f228ae 2026-04-17T19:59:51.519973035Z)")

    def test_empty_contract_abi_from_stdin(self):
        proc = self.run_impl(["-", "--emit", "abi"], "contract C {}\n")
        self.assertEqual(proc.returncode, 0, proc.stderr)
        self.assertEqual(
            json.loads(proc.stdout),
            {"contracts": {"<stdin>:C": {"abi": []}}, "version": "0.1.8"},
        )

    def test_function_abi_and_hashes_are_emitted(self):
        source = "contract C { function f(uint x) public returns (uint) { return x; } }\n"
        proc = self.run_impl(["-", "--emit", "abi,hashes", "--pretty-json"], source)
        self.assertEqual(proc.returncode, 0, proc.stderr)
        self.assertEqual(
            json.loads(proc.stdout),
            {
                "contracts": {
                    "<stdin>:C": {
                        "abi": [
                            {
                                "type": "function",
                                "name": "f",
                                "inputs": [{"name": "x", "type": "uint256", "internalType": "uint256"}],
                                "outputs": [{"name": "", "type": "uint256", "internalType": "uint256"}],
                                "stateMutability": "nonpayable",
                            }
                        ],
                        "hashes": {"f(uint256)": "b3de648b"},
                    }
                },
                "version": "0.1.8",
            },
        )

    def test_constructor_event_error_public_variable_abi(self):
        source = (
            "contract C { uint public x; constructor(uint a){x=a;} "
            "event E(address indexed a, uint b); error Bad(uint code); "
            "function f(address payable a, string memory s) external view returns (bool ok, bytes32) { } }"
        )
        proc = self.run_impl(["-", "--emit", "abi", "--pretty-json"], source)
        self.assertEqual(proc.returncode, 0, proc.stderr)
        abi = json.loads(proc.stdout)["contracts"]["<stdin>:C"]["abi"]
        self.assertEqual([item["type"] for item in abi], ["constructor", "error", "event", "function", "function"])
        self.assertEqual(abi[1]["name"], "Bad")
        self.assertEqual(abi[2]["inputs"][0]["indexed"], True)
        self.assertEqual(abi[3]["stateMutability"], "view")
        self.assertEqual(abi[3]["inputs"][0]["internalType"], "address payable")
        self.assertEqual(abi[4]["name"], "x")

    def test_no_emit_succeeds_without_output(self):
        proc = self.run_impl(["-"], "contract C {}\n")
        self.assertEqual(proc.returncode, 0, proc.stderr)
        self.assertEqual(proc.stdout, "")

    def test_contracts_are_sorted_and_internal_functions_are_not_abi(self):
        source = "library L { function f() internal {} } interface I { function x() external; }"
        proc = self.run_impl(["-", "--emit", "abi", "--pretty-json"], source)
        self.assertEqual(proc.returncode, 0, proc.stderr)
        data = json.loads(proc.stdout)
        self.assertEqual(list(data["contracts"].keys()), ["<stdin>:I", "<stdin>:L"])
        self.assertEqual(data["contracts"]["<stdin>:L"]["abi"], [])

    def test_out_dir_writes_combined_json_without_stdout(self):
        with tempfile.TemporaryDirectory() as tmp:
            source_path = os.path.join(tmp, "C.sol")
            out_dir = os.path.join(tmp, "out")
            os.mkdir(out_dir)
            with open(source_path, "w", encoding="utf-8") as f:
                f.write("contract C { function f() public {} }")
            proc = self.run_impl([source_path, "--emit", "abi", "--out-dir", out_dir])
            self.assertEqual(proc.returncode, 0, proc.stderr)
            self.assertEqual(proc.stdout, "")
            with open(os.path.join(out_dir, "combined.json"), encoding="utf-8") as f:
                data = json.load(f)
            self.assertIn(f"{source_path}:C", data["contracts"])

    def test_z_help_prints_unstable_flags(self):
        proc = self.run_impl(["-Zhelp"])
        self.assertEqual(proc.returncode, 0)
        self.assertIn("List of all unstable flags", proc.stderr)
        self.assertIn("-Zparse-yul", proc.stderr)

    def test_emit_equals_rejects_unknown_value(self):
        proc = self.run_impl(["--emit=foo"])
        self.assertEqual(proc.returncode, 2)
        self.assertIn("invalid value 'foo'", proc.stderr)


if __name__ == "__main__":
    unittest.main()
