import os
import shutil
import subprocess
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
EXE = os.environ.get("STG_UNDER_TEST", str(ROOT / "executable"))


def run(cmd, cwd, input=None):
    return subprocess.run(cmd, cwd=cwd, text=True, input=input, stdout=subprocess.PIPE, stderr=subprocess.PIPE)


class StgCliTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.mkdtemp(prefix="stgtest-")
        run(["git", "init", "-q"], self.tmp)
        run(["git", "config", "user.email", "a@b.c"], self.tmp)
        run(["git", "config", "user.name", "Tester"], self.tmp)
        Path(self.tmp, "f").write_text("base\n")
        run(["git", "add", "f"], self.tmp)
        run(["git", "commit", "-q", "-m", "base"], self.tmp)

    def tearDown(self):
        shutil.rmtree(self.tmp)

    def stg(self, *args):
        return run([EXE, *args], self.tmp)

    def test_version_matches_documented_stgit_identity(self):
        res = self.stg("--version")
        self.assertEqual(res.returncode, 0)
        self.assertIn("Stacked Git 2.5.5", res.stdout)
        self.assertIn("git version", res.stdout)

    def test_new_creates_top_patch_and_series_lists_it(self):
        res = self.stg("new", "p1", "-m", "Patch one")
        self.assertEqual(res.returncode, 0, res.stderr)
        self.assertEqual(res.stdout, "> p1 (new)\n")
        self.assertEqual(self.stg("top").stdout, "p1\n")
        self.assertEqual(self.stg("series").stdout, "> p1\n")

    def test_refresh_pop_and_push_round_trip_patch_changes(self):
        self.stg("new", "p1", "-m", "Patch one")
        with open(Path(self.tmp, "f"), "a") as fh:
            fh.write("change\n")
        res = self.stg("refresh")
        self.assertEqual(res.returncode, 0, res.stderr)
        self.assertIn("M f\n", self.stg("files").stdout)
        self.assertIn("+change", self.stg("diff").stdout)
        self.assertEqual(self.stg("pop").stdout, "- p1\n")
        self.assertEqual(Path(self.tmp, "f").read_text(), "base\n")
        self.assertEqual(self.stg("push").stdout, "> p1\n")
        self.assertEqual(Path(self.tmp, "f").read_text(), "base\nchange\n")

    def test_errors_for_no_top_and_duplicate_patch(self):
        top = self.stg("top")
        self.assertEqual(top.returncode, 2)
        self.assertIn("error: no patches applied", top.stderr)
        self.stg("new", "p1", "-m", "msg")
        dup = self.stg("new", "p1", "-m", "msg")
        self.assertEqual(dup.returncode, 2)
        self.assertIn("error: patch `p1` already exists", dup.stderr)

    def test_global_C_runs_command_in_target_repository(self):
        res = run([EXE, "-C", self.tmp, "new", "p1", "-m", "Patch one"], "/")
        self.assertEqual(res.returncode, 0, res.stderr)
        res = run([EXE, "-C", self.tmp, "top"], "/")
        self.assertEqual(res.stdout, "p1\n")

    def test_rename_and_delete_update_the_series(self):
        self.stg("new", "p1", "-m", "Patch one")
        res = self.stg("rename", "p2")
        self.assertEqual(res.returncode, 0, res.stderr)
        self.assertEqual(self.stg("series").stdout, "> p2\n")
        res = self.stg("delete", "p2")
        self.assertEqual(res.returncode, 0, res.stderr)
        self.assertEqual(self.stg("series").stdout, "")
        self.assertEqual(Path(self.tmp, "f").read_text(), "base\n")


if __name__ == "__main__":
    unittest.main()
