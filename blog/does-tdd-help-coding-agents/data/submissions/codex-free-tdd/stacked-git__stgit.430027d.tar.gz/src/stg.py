#!/usr/bin/env python3
import json
import os
import re
import subprocess
import sys
from pathlib import Path


VERSION = """Stacked Git 2.5.5
Copyright (C) 2005-2025 StGit authors
This is free software: you are free to change and redistribute it.
There is NO WARRANTY, to the extent permitted by law.
SPDX-License-Identifier: GPL-2.0-only
"""


HELP = """Maintain a stack of patches on top of a Git branch.

Usage: stg [OPTIONS] <command> [...]
       stg [OPTIONS] <-h|--help>
       stg --version

Patch inspection commands:
  diff   Show a diff
  files  Show files modified by a patch
  id     Print git hash of a StGit revision
  log    Display or optionally clear the stack changelog
  name   Print patch name of a StGit revision
  show   Show patch commits

Patch manipulation commands:
  edit     Edit a patch
  fold     Fold diff file into the current patch
  new      Create a new patch at top of the stack
  refresh  Incorporate worktree changes into current patch
  rename   Rename a patch
  spill    Spill changes from the topmost patch
  sync     Synchronize patches with a branch or a series

Stack inspection commands:
  next     Print the name of the next patch
  prev     Print the name of the previous patch
  series   Display the patch series
  top      Print the name of the top patch

Stack manipulation commands:
  branch    Branch operations: switch, list, create, rename, delete, ...
  init      Initialize a StGit stack on a branch
  pop       Pop (unapply) one or more applied patches
  push      Push (apply) one or more unapplied patches

Administration commands:
  version     Print version information and exit
"""


class StgError(Exception):
    def __init__(self, message, code=2):
        super().__init__(message)
        self.code = code


def git(*args, check=True, capture=True, input_text=None):
    res = subprocess.run(
        ["git", *args],
        text=True,
        input=input_text,
        stdout=subprocess.PIPE if capture else None,
        stderr=subprocess.PIPE if capture else None,
    )
    if check and res.returncode != 0:
        msg = (res.stderr or res.stdout or "").strip()
        raise StgError(msg if msg else f"git {' '.join(args)} failed")
    return res


def git_dir():
    res = git("rev-parse", "--git-dir", check=False)
    if res.returncode != 0:
        raise StgError("Could not find a git repository in '.' or in any of its parents")
    return Path(res.stdout.strip())


def branch():
    res = git("symbolic-ref", "--quiet", "--short", "HEAD", check=False)
    if res.returncode != 0:
        raise StgError("not on a branch")
    return res.stdout.strip()


def ensure_born():
    res = git("rev-parse", "--verify", "HEAD", check=False)
    if res.returncode != 0:
        raise StgError(f"branch `refs/heads/{branch()}` is unborn")


def meta_path():
    return git_dir() / "stgit-py" / f"{branch()}.json"


def load():
    ensure_born()
    path = meta_path()
    if path.exists():
        return json.loads(path.read_text())
    return {"applied": [], "unapplied": [], "messages": {}}


def save(state):
    path = meta_path()
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(state, indent=2, sort_keys=True))


def all_names(state):
    return state["applied"] + state["unapplied"]


def ref_for(name):
    return f"refs/patches/{branch()}/{name}"


def head_hash():
    return git("rev-parse", "HEAD").stdout.strip()


def valid_name(name):
    return name and "/" not in name and not name.endswith(".lock")


def current_message(name, fallback=None):
    res = git("log", "-1", "--format=%B", ref_for(name), check=False)
    if res.returncode == 0:
        return res.stdout.strip() or name
    return fallback or name


def parse_message(args, default_name=None):
    msg = None
    name = None
    i = 0
    while i < len(args):
        a = args[i]
        if a in ("-m", "--message") and i + 1 < len(args):
            msg = args[i + 1]
            i += 2
        elif a in ("-n", "--name") and i + 1 < len(args):
            name = args[i + 1]
            i += 2
        elif a == "--":
            break
        elif not a.startswith("-") and name is None:
            name = a
            i += 1
        else:
            i += 1
    if name is None:
        if msg:
            name = re.sub(r"[^A-Za-z0-9._-]+", "-", msg.strip().lower()).strip("-") or "patch"
        else:
            raise StgError("No patch name given")
    return name, (msg if msg is not None else default_name or name)


def cmd_version(args):
    if "-s" in args or "--short" in args:
        print("2.5.5")
        return
    sys.stdout.write(VERSION)
    sys.stdout.write(git("--version").stdout)


def cmd_init(args):
    ensure_born()
    state = load()
    save(state)


def cmd_new(args):
    state = load()
    name, msg = parse_message(args)
    if not valid_name(name):
        raise StgError(f"invalid patch name `{name}`")
    if name in all_names(state):
        raise StgError(f"patch `{name}` already exists")
    git("commit", "--allow-empty", "-m", msg)
    git("update-ref", ref_for(name), "HEAD")
    state["applied"].append(name)
    state["messages"][name] = msg
    save(state)
    print(f"> {name} (new)")


def cmd_refresh(args):
    state = load()
    if not state["applied"]:
        raise StgError("no patches applied")
    name = state["applied"][-1]
    git("add", "-A")
    msg = current_message(name, state["messages"].get(name))
    git("commit", "--allow-empty", "--amend", "-m", msg)
    git("update-ref", ref_for(name), "HEAD")
    state["messages"][name] = msg
    save(state)


def select_count(args, default=1):
    if "-a" in args or "--all" in args:
        return None
    for i, a in enumerate(args):
        if a in ("-n", "--number") and i + 1 < len(args):
            return int(args[i + 1])
    return default


def cmd_pop(args):
    state = load()
    if not state["applied"]:
        raise StgError("no patches applied")
    n = select_count(args)
    if n is None:
        n = len(state["applied"])
    if n < 0:
        n = max(0, len(state["applied"]) + n)
    n = min(n, len(state["applied"]))
    popped = []
    for _ in range(n):
        name = state["applied"].pop()
        state["unapplied"].insert(0, name)
        popped.append(name)
    git("reset", "--hard", f"HEAD~{n}", capture=True)
    save(state)
    for name in popped:
        print(f"- {name}")


def is_empty_commit(ref):
    res = git("diff-tree", "--quiet", f"{ref}^", ref, check=False)
    return res.returncode == 0


def push_one(state, name):
    ref = ref_for(name)
    msg = current_message(name, state["messages"].get(name))
    if is_empty_commit(ref):
        git("commit", "--allow-empty", "-m", msg)
    else:
        res = git("cherry-pick", ref, check=False)
        if res.returncode != 0:
            raise StgError((res.stderr or res.stdout).strip() or f"could not push `{name}`")
    git("update-ref", ref, "HEAD")
    state["messages"][name] = msg


def cmd_push(args):
    state = load()
    if not state["unapplied"]:
        raise StgError("no unapplied patches")
    n = select_count(args)
    if n is None:
        n = len(state["unapplied"])
    if n < 0:
        n = max(0, len(state["unapplied"]) + n)
    n = min(n, len(state["unapplied"]))
    pushed = []
    for _ in range(n):
        name = state["unapplied"].pop(0)
        push_one(state, name)
        state["applied"].append(name)
        pushed.append(name)
    save(state)
    for name in pushed:
        print(f"> {name}")


def cmd_series(args):
    state = load()
    want_desc = "-d" in args or "--description" in args
    count = "-c" in args or "--count" in args
    selected = []
    for idx, name in enumerate(state["applied"]):
        prefix = ">" if idx == len(state["applied"]) - 1 else "+"
        selected.append((prefix, name))
    selected.extend(("-", name) for name in state["unapplied"])
    if "-A" in args or "--applied" in args:
        selected = [(p, n) for p, n in selected if p in "+>"]
    if "-U" in args or "--unapplied" in args:
        selected = [(p, n) for p, n in selected if p == "-"]
    if "-P" in args or "--no-prefix" in args:
        selected = [("", n) for _, n in selected]
    if count:
        print(len(selected))
        return
    for p, name in selected:
        line = f"{p} {name}" if p else name
        if want_desc:
            line += f" # {current_message(name, state['messages'].get(name)).splitlines()[0]}"
        print(line)


def cmd_top(args):
    state = load()
    if not state["applied"]:
        raise StgError("no patches applied")
    print(state["applied"][-1])


def cmd_prev(args):
    state = load()
    if len(state["applied"]) < 2:
        raise StgError("not enough patches applied")
    print(state["applied"][-2])


def cmd_next(args):
    state = load()
    if not state["unapplied"]:
        raise StgError("no unapplied patches")
    print(state["unapplied"][0])


def cmd_files(args):
    state = load()
    if not state["applied"]:
        raise StgError("no patches applied")
    name = state["applied"][-1]
    out = git("diff-tree", "--no-commit-id", "--name-status", "-r", ref_for(name)).stdout
    sys.stdout.write(out.replace("\t", " "))


def cmd_diff(args):
    state = load()
    if not state["applied"]:
        raise StgError("no patches applied")
    name = state["applied"][-1]
    sys.stdout.write(git("diff", f"{ref_for(name)}^", ref_for(name)).stdout)


def cmd_show(args):
    state = load()
    target = args[0] if args and not args[0].startswith("-") else (state["applied"][-1] if state["applied"] else "HEAD")
    ref = ref_for(target) if target in all_names(state) else target
    res = git("show", ref, check=False)
    sys.stdout.write(res.stdout)
    sys.stderr.write(res.stderr)
    if res.returncode:
        raise StgError("", res.returncode)


def cmd_id(args):
    state = load()
    target = args[0] if args and not args[0].startswith("-") else (state["applied"][-1] if state["applied"] else "HEAD")
    ref = ref_for(target) if target in all_names(state) else target
    print(git("rev-parse", ref).stdout.strip())


def cmd_name(args):
    state = load()
    if args and args[0] in all_names(state):
        print(args[0])
        return
    if state["applied"]:
        print(state["applied"][-1])
    else:
        raise StgError("no patches applied")


def cmd_rename(args):
    state = load()
    if not state["applied"] and not state["unapplied"]:
        raise StgError("no patches")
    if len(args) == 1:
        old, new = (state["applied"][-1] if state["applied"] else state["unapplied"][0]), args[0]
    elif len(args) >= 2:
        old, new = args[0], args[1]
    else:
        raise StgError("No patch name given")
    if old not in all_names(state):
        raise StgError(f"patch `{old}` does not exist")
    if new in all_names(state):
        raise StgError(f"patch `{new}` already exists")
    if not valid_name(new):
        raise StgError(f"invalid patch name `{new}`")
    git("update-ref", ref_for(new), ref_for(old))
    git("update-ref", "-d", ref_for(old), check=False)
    for key in ("applied", "unapplied"):
        state[key] = [new if n == old else n for n in state[key]]
    if old in state["messages"]:
        state["messages"][new] = state["messages"].pop(old)
    save(state)
    print(f"{old} => {new}")
    if state["applied"] and state["applied"][-1] == new:
        print(f"> {new}")


def cmd_delete(args):
    state = load()
    names = [a for a in args if not a.startswith("-")]
    if not names:
        if not state["applied"]:
            raise StgError("no patches applied")
        names = [state["applied"][-1]]
    for name in names:
        if name in state["applied"]:
            idx = state["applied"].index(name)
            if idx != len(state["applied"]) - 1:
                raise StgError("can only delete the top applied patch in this implementation")
            state["applied"].pop()
            git("reset", "--hard", "HEAD~1", capture=True)
            print(f"- {name}")
            print(f"# {name}")
        elif name in state["unapplied"]:
            state["unapplied"].remove(name)
        else:
            raise StgError(f"patch `{name}` does not exist")
        git("update-ref", "-d", ref_for(name), check=False)
        state["messages"].pop(name, None)
    save(state)


def cmd_branch(args):
    if not args:
        print(branch())
        return
    if args[0] in ("-l", "--list"):
        sys.stdout.write(git("branch", "--list").stdout)
        return
    if args[0] in ("-c", "--create") and len(args) >= 2:
        start = args[2] if len(args) > 2 else "HEAD"
        git("checkout", "-q", "-b", args[1], start)
        save({"applied": [], "unapplied": [], "messages": {}})
        return
    git("checkout", args[0], capture=False)


ALIASES = {
    "add": ["add"],
    "mv": ["mv"],
    "resolved": ["add"],
    "rm": ["rm"],
    "status": ["status", "-s"],
}


COMMANDS = {
    "version": cmd_version,
    "init": cmd_init,
    "new": cmd_new,
    "refresh": cmd_refresh,
    "pop": cmd_pop,
    "push": cmd_push,
    "series": cmd_series,
    "top": cmd_top,
    "prev": cmd_prev,
    "next": cmd_next,
    "files": cmd_files,
    "diff": cmd_diff,
    "show": cmd_show,
    "id": cmd_id,
    "name": cmd_name,
    "rename": cmd_rename,
    "delete": cmd_delete,
    "branch": cmd_branch,
}


def sub_help(cmd):
    summaries = {
        "version": "Print version information and exit",
        "init": "Initialize a StGit stack on a branch.",
        "new": "Create a new, empty patch on the current stack.",
        "series": "Show all the patches in the series, ordered from bottom to top.",
        "top": "Print the name of the top patch.",
        "pop": "Pop (unapply) one or more applied patches.",
        "push": "Push one or more unapplied patches from the series onto the stack.",
    }
    print(summaries.get(cmd, f"Help for stg {cmd}"))
    print()
    print(f"Usage: stg {cmd} [OPTIONS]")


def main(argv):
    i = 0
    stripped = []
    while i < len(argv):
        if argv[i] == "-C" and i + 1 < len(argv):
            os.chdir(argv[i + 1])
            i += 2
        elif argv[i] == "--color" and i + 1 < len(argv):
            i += 2
        else:
            stripped.extend(argv[i:])
            break
    argv = stripped
    if not argv or argv[0] in ("-h", "--help"):
        sys.stdout.write(HELP)
        return 0
    if argv[0] == "--version":
        cmd_version([])
        return 0
    if argv[0] == "help":
        if len(argv) > 1:
            sub_help(argv[1])
        else:
            sys.stdout.write(HELP)
        return 0
    cmd = argv[0]
    args = argv[1:]
    if "--help" in args or "-h" in args:
        sub_help(cmd)
        return 0
    if cmd in ALIASES:
        res = subprocess.run(["git", *ALIASES[cmd], *args])
        return res.returncode
    if cmd not in COMMANDS:
        raise StgError(f"unrecognized command `{cmd}`")
    COMMANDS[cmd](args)
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main(sys.argv[1:]))
    except StgError as e:
        if str(e):
            print(f"error: {e}", file=sys.stderr)
        raise SystemExit(e.code)
