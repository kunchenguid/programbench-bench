#!/usr/bin/env python3
import os
import shlex
import subprocess
import sys
import tempfile


VERSION = "0.9.28rc"
VERSION_LINE = "tcc version 0.9.28rc 2026-04-21 build@237d0db* (x86_64 Linux)\n"

HELP = """Tiny C Compiler 0.9.28rc - Copyright (C) 2001-2006 Fabrice Bellard
Usage: tcc [options...] [-o outfile] [-c] infile(s)...
       tcc [options...] -run infile (or --) [arguments...]
General options:
  -c           compile only - generate an object file
  -o outfile   set output filename
  -run         run compiled source [with custom stdin: -rstdin FILE]
  -fflag       set or reset (with 'no-' prefix) 'flag' (see tcc -hh)
  -Wwarning    set or reset (with 'no-' prefix) 'warning' (see tcc -hh)
  -w           disable all warnings
  -v --version show version
  -vv          show search paths or loaded files
  -h -hh       show this, show more help
  -bench       show compilation statistics
  -            use stdin pipe as infile
  @listfile    read arguments from listfile
Preprocessor options:
  -Idir        add include path 'dir'
  -Dsym[=val]  define 'sym' with value 'val'
  -Usym        undefine 'sym'
  -E           preprocess only
  -nostdinc    do not use standard system include paths
Linker options:
  -Ldir        add library path 'dir'
  -llib        link with dynamic or static library 'lib'
  -nostdlib    do not link with standard crt and libraries
  -r           generate (relocatable) object file
  -rdynamic    export all global symbols to dynamic linker
  -shared      generate a shared library/dll
  -soname      set name for shared library to be used at runtime
  -Wl,-opt[=val]  set linker option (see tcc -hh)
Debugger options:
  -g           generate stab runtime debug info
  -gdwarf[-x]  generate dwarf runtime debug info
  -b           compile with built-in memory and bounds checker (implies -g)
  -bt[N]       link with backtrace (stack dump) support [show max N callers]
Misc. options:
  -std=version define __STDC_VERSION__ according to version (c11/gnu11)
  -x[c|a|b|n]  specify type of the next infile (C,ASM,BIN,NONE)
  -Bdir        set tcc's private include/library dir
  -M[M]D       generate make dependency file [ignore system files]
  -M[M]        as above but no other output
  -MF file     specify dependency file name
  -m32/64      defer to i386/x86_64 cross compiler
Tools:
  create library  : tcc -ar [crstvx] lib [files]
Discussion & bug reports:
  https://lists.nongnu.org/mailman/listinfo/tinycc-devel
"""

MORE_HELP = """Tiny C Compiler 0.9.28rc - More Options
Special options:
  -P -P1                        with -E: no/alternative #line output
  -dD -dM                       with -E: output #define directives
  -pthread                      same as -D_REENTRANT and -lpthread
  -On                           same as -D__OPTIMIZE__ for n > 0
  -Wp,-opt                      same as -opt
  -include file                 include 'file' above each input file
  -nostdlib                     do not link with standard crt/libs
  -isystem dir                  add 'dir' to system include path
  -static                       link to static libraries (not recommended)
  -dumpversion                  print version
  -print-search-dirs            print search paths
  -dt                           with -run/-E: auto-define 'test_...' macros
Ignored options:
  -arch -C --param -pedantic -pipe -s -traditional
-W[no-]... warnings:
  all                           turn on some (*) warnings
  error[=warning]               stop after warning (any or specified)
  write-strings                 strings are const
  unsupported                   warn about ignored options, pragmas, etc.
  implicit-function-declaration warn for missing prototype (*)
  discarded-qualifiers          warn when const is dropped (*)
-f[no-]... flags:
  unsigned-char                 default char is unsigned
  signed-char                   default char is signed
  common                        use common section instead of bss
  leading-underscore            decorate extern symbols
  ms-extensions                 allow anonymous struct in struct
  dollars-in-identifiers        allow '$' in C symbols
  reverse-funcargs              evaluate function arguments right to left
  gnu89-inline                  'extern inline' is like 'static inline'
  asynchronous-unwind-tables    create eh_frame section [on]
  test-coverage                 create code coverage code
-m... target specific options:
  ms-bitfields                  use MSVC bitfield layout
  no-sse                        disable floats on x86_64
-Wl,... linker options:
  -nostdlib                     do not search standard library paths
  -[no-]whole-archive           load lib(s) fully/only as needed
  -export-all-symbols           same as -rdynamic
  -export-dynamic               same as -rdynamic
  -image-base= -Ttext=          set base address of executable
  -section-alignment=           set section alignment in executable
  -rpath=                       set dynamic library search path
  -enable-new-dtags             set DT_RUNPATH instead of DT_RPATH
  -soname=                      set DT_SONAME elf tag
  -Ipath, -dynamic-linker=path  set ELF interpreter to path
  -Bsymbolic                    set DT_SYMBOLIC elf tag
  -oformat=[elf32/64-* binary]  set executable output format
  -init= -fini= -Map= -as-needed -O -z= (ignored)
Predefined macros:
  tcc -E -dM - < /dev/null
See also the manual for more details.
"""

SEARCH_DIRS = """install: /usr/local/lib/tcc
include:
  /usr/local/lib/tcc/include
  /usr/local/include/x86_64-linux-gnu
  /usr/local/include
  /usr/include/x86_64-linux-gnu
  /usr/include
libraries:
  /usr/local/lib/tcc
  /usr/lib/x86_64-linux-gnu
  /usr/lib
  /lib/x86_64-linux-gnu
  /lib
  /usr/local/lib/x86_64-linux-gnu
  /usr/local/lib
libtcc1:
  /usr/local/lib/tcc/libtcc1.a
crt:
  /usr/lib/x86_64-linux-gnu
elfinterp:
  /lib64/ld-linux-x86-64.so.2
"""

TCC_MACROS = """#define __TINYC__ 928
#define __x86_64__ 1
#define __x86_64 1
#define __amd64__ 1
#define __linux__ 1
#define __linux 1
#define __unix__ 1
#define __unix 1
#define __TCC_PP__ 1
#define __SIZEOF_POINTER__ 8
#define __SIZEOF_LONG__ 8
#define __STDC__ 1
#define __STDC_HOSTED__ 1
#define __STDC_VERSION__ 199901L
#define __SIZE_TYPE__ unsigned long
#define __PTRDIFF_TYPE__ long
#define __LP64__ 1
#define __INT64_TYPE__ long
#define __SIZEOF_INT__ 4
#define __INT_MAX__ 0x7fffffff
#define __LONG_MAX__ 0x7fffffffffffffffL
#define __SIZEOF_LONG_LONG__ 8
#define __LONG_LONG_MAX__ 0x7fffffffffffffffLL
#define __CHAR_BIT__ 8
#define __ORDER_LITTLE_ENDIAN__ 1234
#define __ORDER_BIG_ENDIAN__ 4321
#define __BYTE_ORDER__ __ORDER_LITTLE_ENDIAN__
#define __WCHAR_TYPE__ int
#define __WINT_TYPE__ unsigned int
#define __UINTPTR_TYPE__ unsigned __PTRDIFF_TYPE__
#define __INTPTR_TYPE__ __PTRDIFF_TYPE__
#define __INT32_TYPE__ int
#define __REDIRECT(name,proto,alias) name proto __asm__(#alias)
#define __REDIRECT_NTH(name,proto,alias) name proto __asm__(#alias)__THROW
#define __REDIRECT_NTHNL(name,proto,alias) name proto __asm__(#alias)__THROWNL
#define __PRETTY_FUNCTION__ __FUNCTION__
#define __has_builtin(x) 0
#define __has_feature(x) 0
#define __has_attribute(x) 0
#define _Nonnull
#define _Nullable
#define _Nullable_result
#define _Null_unspecified
"""


def eprint(msg):
    sys.stderr.write(msg)


def expand_response_files(args):
    out = []
    for arg in args:
        if arg.startswith("@") and len(arg) > 1:
            with open(arg[1:], "r", encoding="utf-8") as fh:
                out.extend(shlex.split(fh.read()))
        else:
            out.append(arg)
    return out


def invalid_option(arg):
    eprint(f"tcc: error: invalid option -- '{arg}'\n")
    return 1


def gcc_args(args, stdin_files):
    out = ["gcc"]
    i = 0
    while i < len(args):
        arg = args[i]
        if arg == "-":
            tmp = tempfile.NamedTemporaryFile("w", suffix=".c", delete=False)
            tmp.write(sys.stdin.read())
            tmp.close()
            stdin_files.append(tmp.name)
            out.append(tmp.name)
        elif arg == "-P1":
            out.append("-P")
        elif arg.startswith("-Wp,"):
            out.extend(arg[4:].split(","))
        elif arg == "-soname":
            if i + 1 >= len(args):
                return None, invalid_option(arg)
            out.append(f"-Wl,-soname,{args[i + 1]}")
            i += 1
        elif arg.startswith("-soname="):
            out.append("-Wl,-soname," + arg.split("=", 1)[1])
        elif arg in ("-b", "-bt") or arg.startswith("-bt"):
            out.append("-g")
        elif arg.startswith("-gdwarf"):
            out.append("-gdwarf")
        elif arg in ("-bench", "-dt", "-vv"):
            pass
        elif arg in ("-m32", "-m64"):
            eprint("tcc: could not run './i386-tcc'\n" if arg == "-m32" else "tcc: could not run './x86_64-tcc'\n")
            return None, 1
        elif arg.startswith("-f"):
            if arg in ("-fsigned-char", "-funsigned-char", "-fcommon", "-fno-common", "-fleading-underscore"):
                out.append(arg)
            else:
                pass
        elif arg.startswith("-W") and not arg.startswith("-Wl,"):
            if arg in ("-Wall", "-Werror", "-w") or arg.startswith("-Werror=") or arg.startswith("-Wno-"):
                out.append(arg)
            else:
                pass
        elif arg == "-ar":
            return None, invalid_option(arg)
        elif arg.startswith("--"):
            return None, invalid_option(arg)
        else:
            out.append(arg)
        i += 1
    return out, None


def run_gcc(args):
    stdin_files = []
    try:
        translated, status = gcc_args(args, stdin_files)
        if status is not None:
            return status
        dep_files_before = set()
        if any(arg in ("-MD", "-MMD") for arg in args):
            dep_files_before = {name for name in os.listdir(".") if name.endswith(".d")}
        proc = subprocess.run(translated)
        if proc.returncode == 0 and any(arg in ("-MD", "-MMD") for arg in args):
            normalize_dependency_files(dep_files_before)
        return proc.returncode
    finally:
        for path in stdin_files:
            try:
                os.unlink(path)
            except OSError:
                pass


def normalize_dependency_files(before):
    after = {name for name in os.listdir(".") if name.endswith(".d")}
    for name in sorted(after - before if after - before else after):
        try:
            with open(name, "r", encoding="utf-8") as fh:
                content = fh.read()
            target, deps_text = content.replace("\\\n", " ").split(":", 1)
        except (OSError, ValueError):
            continue
        deps = []
        for dep in deps_text.split():
            if dep == "/usr/include/stdc-predef.h":
                continue
            if dep not in deps:
                deps.append(dep)
        if not deps:
            continue
        lines = [f"{target}: \\"]
        for pos, dep in enumerate(deps):
            suffix = " \\" if pos + 1 < len(deps) else ""
            lines.append(f"  {dep}{suffix}")
        try:
            with open(name, "w", encoding="utf-8") as fh:
                fh.write("\n".join(lines) + "\n")
        except OSError:
            pass


def run_direct(args):
    idx = args.index("-run")
    compile_opts = args[:idx]
    rest = args[idx + 1 :]
    stdin_name = None
    i = 0
    while i + 1 < len(rest) and rest[i] == "-rstdin":
        stdin_name = rest[i + 1]
        i += 2
    cleaned = rest[i:]
    if not cleaned:
        eprint("tcc: error: file '' not found\n")
        return 1
    if cleaned[0] == "--":
        cleaned = cleaned[1:]
    source = cleaned[0]
    program_args = cleaned[1:]
    with tempfile.TemporaryDirectory() as td:
        exe = os.path.join(td, "runprog")
        compile_source = source
        try:
            with open(source, "r", encoding="utf-8") as fh:
                first = fh.readline()
                if first.startswith("#!"):
                    scrubbed = os.path.join(td, "script.c")
                    with open(scrubbed, "w", encoding="utf-8") as out:
                        out.write("\n")
                        out.write(fh.read())
                    compile_source = scrubbed
        except OSError:
            pass
        status = run_gcc([*compile_opts, "-o", exe, compile_source])
        if status != 0:
            return status
        stdin = open(stdin_name, "rb") if stdin_name else None
        try:
            proc = subprocess.run([exe, *program_args], stdin=stdin)
            return proc.returncode
        finally:
            if stdin is not None:
                stdin.close()


def main(argv):
    args = expand_response_files(argv[1:])
    if not args or args[0] in ("-h", "--help"):
        sys.stdout.write(HELP)
        return 0
    if args[0] == "-hh":
        sys.stdout.write(MORE_HELP)
        return 0
    if args[0] in ("-v", "--version"):
        sys.stdout.write(VERSION_LINE)
        return 0
    if args[0] in ("-vv", "-print-search-dirs"):
        sys.stdout.write(SEARCH_DIRS)
        return 0
    if args[0] == "-dumpversion":
        sys.stdout.write(VERSION + "\n")
        return 0
    if "-E" in args and "-dM" in args:
        sys.stdout.write(TCC_MACROS)
        base = "-"
        for item in args:
            if not item.startswith("-"):
                base = item
                break
        sys.stdout.write(f'#define __BASE_FILE__ "{base}"\n')
        if "-" in args:
            sys.stdin.read()
        return 0
    if args[0] in ("-m32", "-m64"):
        eprint("tcc: could not run './i386-tcc'\n" if args[0] == "-m32" else "tcc: could not run './x86_64-tcc'\n")
        return 1
    if args[0] == "-ar":
        if len(args) < 4:
            eprint("tcc: error: library name expected\n")
            return 1
        return subprocess.run(["ar", *args[1:]]).returncode
    if "-run" in args:
        return run_direct(args)
    return run_gcc(args)


if __name__ == "__main__":
    raise SystemExit(main(sys.argv))
