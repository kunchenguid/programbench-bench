#!/usr/bin/env python3
import json
import os
import re
import sys
from pathlib import Path


VERSION = "nomino 1.6.4"
SUMMARY = "Batch rename utility for developers"


HELP_LONG = """Batch rename utility for developers

Usage: executable [OPTIONS] [[SOURCE] OUTPUT]...

Arguments:
  [[SOURCE] OUTPUT]...
          OUTPUT is the pattern to be used for renaming files, and SOURCE is the optional regex pattern to match by filenames. SOURCE has the same function as -r option

Options:
  -d, --dir <PATH>
          Sets the working directory

      --depth <DEPTH>
          Optional value to overwrite inferred subdirectory depth value in 'regex' mode

  -E, --no-extension
          Does not preserve the extension of input files in 'sort' and 'regex' options

  -g, --generate <PATH>
          Stores a JSON map file in '<PATH>' after renaming files

  -h, --help
          Print help (see a summary with '-h')

  -k, --mkdir
          Recursively creates all parent directories of '<OUTPUT>' if they are missing

  -m, --map <PATH>
          Sets the path of map file to be used for renaming files
          
          [aliases: --from-file]

      --max-depth <DEPTH>
          Optional value to set the maximum of subdirectory depth value in 'regex' mode

  -q, --quiet
          Does not print the map table to stdout

  -r, --regex <PATTERN>
          Regex pattern to match by filenames

  -s, --sort <ORDER>
          Sets the order of natural sorting (by name) to rename files using enumerator

          Possible values:
          - asc:  Sort in ascending order
          - desc: Sort in descending order

  -t, --test
          Runs in test mode without renaming actual files
          
          [aliases: --dry-run]

  -V, --version
          Print version

  -w, --overwrite
          Overwrites output files, otherwise, a '_' is prepended to filename

OUTPUT pattern accepts placeholders that have the format of '{G:P}' where 'G' is the captured group and 'P' is the padding of digits with `0`. Please refer to https://github.com/yaa110/nomino for more information.
"""


HELP_SHORT = """Batch rename utility for developers

Usage: executable [OPTIONS] [[SOURCE] OUTPUT]...

Arguments:
  [[SOURCE] OUTPUT]...  OUTPUT is the pattern to be used for renaming files, and SOURCE is the optional regex pattern to match by filenames. SOURCE has the same function as -r option

Options:
  -d, --dir <PATH>         Sets the working directory
      --depth <DEPTH>      Optional value to overwrite inferred subdirectory depth value in 'regex' mode
  -E, --no-extension       Does not preserve the extension of input files in 'sort' and 'regex' options
  -g, --generate <PATH>    Stores a JSON map file in '<PATH>' after renaming files
  -h, --help               Print help (see more with '--help')
  -k, --mkdir              Recursively creates all parent directories of '<OUTPUT>' if they are missing
  -m, --map <PATH>         Sets the path of map file to be used for renaming files [aliases: --from-file]
      --max-depth <DEPTH>  Optional value to set the maximum of subdirectory depth value in 'regex' mode
  -q, --quiet              Does not print the map table to stdout
  -r, --regex <PATTERN>    Regex pattern to match by filenames
  -s, --sort <ORDER>       Sets the order of natural sorting (by name) to rename files using enumerator [possible values: asc, desc]
  -t, --test               Runs in test mode without renaming actual files [aliases: --dry-run]
  -V, --version            Print version
  -w, --overwrite          Overwrites output files, otherwise, a '_' is prepended to filename

OUTPUT pattern accepts placeholders that have the format of '{G:P}' where 'G' is the captured group and 'P' is the padding of digits with `0`. Please refer to https://github.com/yaa110/nomino for more information.
"""


class Config:
    def __init__(self):
        self.dir = "."
        self.depth = None
        self.max_depth = None
        self.no_extension = False
        self.generate = None
        self.mkdir = False
        self.map = None
        self.quiet = False
        self.regex = None
        self.sort = None
        self.test = False
        self.overwrite = False
        self.positionals = []


def parse_args(argv):
    cfg = Config()
    i = 0
    while i < len(argv):
        arg = argv[i]
        if arg in ("-h", "--help"):
            print(HELP_SHORT if arg == "-h" else HELP_LONG)
            raise SystemExit(0)
        if arg in ("-V", "--version"):
            print(VERSION)
            raise SystemExit(0)
        if arg in ("-d", "--dir", "--depth", "-g", "--generate", "-m", "--map", "--from-file", "--max-depth", "-r", "--regex", "-s", "--sort"):
            if i + 1 >= len(argv):
                print(f"error: a value is required for '{arg}'", file=sys.stderr)
                raise SystemExit(2)
            val = argv[i + 1]
            i += 2
            if arg in ("-d", "--dir"):
                cfg.dir = val
            elif arg == "--depth":
                cfg.depth = int(val)
            elif arg in ("-g", "--generate"):
                cfg.generate = val
            elif arg in ("-m", "--map", "--from-file"):
                cfg.map = val
            elif arg == "--max-depth":
                cfg.max_depth = int(val)
            elif arg in ("-r", "--regex"):
                cfg.regex = val
            elif arg in ("-s", "--sort"):
                if val not in ("asc", "desc"):
                    print(f"error: invalid value '{val}' for '--sort <ORDER>'", file=sys.stderr)
                    print("  [possible values: asc, desc]", file=sys.stderr)
                    print(file=sys.stderr)
                    print("For more information, try '--help'.", file=sys.stderr)
                    raise SystemExit(2)
                cfg.sort = val
            continue
        if arg in ("-E", "--no-extension"):
            cfg.no_extension = True
        elif arg in ("-k", "--mkdir"):
            cfg.mkdir = True
        elif arg in ("-q", "--quiet"):
            cfg.quiet = True
        elif arg in ("-t", "--test", "--dry-run"):
            cfg.test = True
        elif arg in ("-w", "--overwrite"):
            cfg.overwrite = True
        elif arg.startswith("-"):
            print(f"error: unexpected argument '{arg}'", file=sys.stderr)
            raise SystemExit(2)
        else:
            cfg.positionals.append(arg)
        i += 1
    return cfg


def natural_key(s):
    parts = re.split(r"(\d+)", s)
    return [int(p) if p.isdigit() else p.lower() for p in parts]


def list_files(base, depth=1, exact_depth=False):
    files = []
    for root, dirs, names in os.walk(base):
        rel_root = os.path.relpath(root, base)
        level = 0 if rel_root == "." else rel_root.count(os.sep) + 1
        if level >= depth:
            dirs[:] = []
        for name in names:
            rel = name if rel_root == "." else os.path.join(rel_root, name)
            file_depth = level + 1
            if exact_depth:
                if file_depth == depth:
                    files.append(rel)
            elif file_depth <= depth:
                files.append(rel)
    return files


def split_ext(path):
    p = Path(path)
    return str(p.with_suffix("")), p.suffix


def format_value(value, pad):
    text = str(value)
    if pad and re.fullmatch(r"\d+", text):
        return text.zfill(int(pad))
    return text


PLACEHOLDER = re.compile(r"\{([^{}:]*)(?::(\d+))?\}")


def apply_pattern(pattern, groups, names, original, enum_start=1, preserve_ext=True):
    auto = {"value": enum_start}

    def repl(match):
        key, pad = match.group(1), match.group(2)
        if key == "":
            value = auto["value"]
            auto["value"] += 1
        elif key.isdigit():
            idx = int(key)
            value = groups[idx] if idx < len(groups) and groups[idx] is not None else ""
        else:
            value = names.get(key, "")
        return format_value(value, pad)

    rendered = PLACEHOLDER.sub(repl, pattern)
    if preserve_ext:
        _, ext = split_ext(original)
        rendered += ext
    return rendered


def table(rows):
    if not rows:
        return ""
    in_w = max(len("Input"), *(len(a) for a, _ in rows))
    out_w = max(len("Output"), *(len(b) for _, b in rows))
    border = f"+-{'-' * in_w}-+-{'-' * out_w}-+"
    lines = [border, f"| {'Input'.ljust(in_w)} | {'Output'.ljust(out_w)} |", border]
    for src, dst in rows:
        lines.append(f"| {src.ljust(in_w)} | {dst.ljust(out_w)} |")
    lines.append(border)
    return "\n".join(lines) + "\n"


def unique_destination(dst, occupied, overwrite):
    if overwrite or dst not in occupied:
        return dst
    dirname, name = os.path.split(dst)
    candidate = os.path.join(dirname, "_" + name) if dirname else "_" + name
    while candidate in occupied:
        dirname, name = os.path.split(candidate)
        candidate = os.path.join(dirname, "_" + name) if dirname else "_" + name
    return candidate


def build_rows(cfg):
    base = cfg.dir
    if cfg.map:
        with open(os.path.join(base, cfg.map), encoding="utf-8") as fh:
            mapping = json.load(fh)
        return [(str(k), str(v)) for k, v in mapping.items()]

    if cfg.sort:
        if not cfg.positionals:
            print("error: OUTPUT argument is required", file=sys.stderr)
            raise SystemExit(2)
        files = list_files(base, 1)
        files.sort(key=natural_key, reverse=(cfg.sort == "desc"))
        return [
            (
                src,
                apply_pattern(cfg.positionals[-1], [src], {}, src, i, not cfg.no_extension),
            )
            for i, src in enumerate(files, 1)
        ]

    regex = cfg.regex
    output = cfg.positionals[-1] if cfg.positionals else None
    if regex is None and len(cfg.positionals) >= 2:
        regex = cfg.positionals[-2]
    if regex is not None and output is not None:
        depth = cfg.depth if cfg.depth is not None else 1
        files = list_files(base, depth, exact_depth=(cfg.depth is not None))
        compiled = re.compile(regex)
        rows = []
        for src in sorted(files, key=natural_key):
            target_text, _ = split_ext(os.path.basename(src))
            match = compiled.search(target_text)
            if not match:
                continue
            groups = [match.group(0), *match.groups()]
            rows.append((src, apply_pattern(output, groups, match.groupdict(), src, 1, not cfg.no_extension)))
        return rows

    print("error: one of 'regex', 'sort', 'map' or 'SOURCE' options must be set.", file=sys.stderr)
    print("usage: run './executable --help' for more information.", file=sys.stderr)
    raise SystemExit(1)


def perform(cfg, rows):
    base = cfg.dir
    occupied = set(list_files(base, 99))
    final_rows = []
    errors = 0
    for src, requested in rows:
        dst = unique_destination(requested, occupied - {src}, cfg.overwrite)
        final_rows.append((src, dst))
        occupied.discard(src)
        occupied.add(dst)
        if cfg.test:
            continue
        src_path = os.path.join(base, src)
        dst_path = os.path.join(base, dst)
        try:
            if cfg.mkdir:
                parent = os.path.dirname(dst_path)
                if parent:
                    os.makedirs(parent, exist_ok=True)
            os.rename(src_path, dst_path)
        except OSError as exc:
            print(f"[error] unable to rename '{src}': {format_os_error(exc)}", file=sys.stderr)
            errors += 1
    if cfg.generate:
        with open(os.path.join(base, cfg.generate), "w", encoding="utf-8") as fh:
            json.dump({dst: src for src, dst in final_rows}, fh, indent=2)
            fh.write("\n")
    if not cfg.quiet and final_rows and not errors:
        print(table(final_rows), end="")
    return 1 if errors else 0


def format_os_error(exc):
    if exc.errno:
        return f"{exc.strerror} (os error {exc.errno})"
    return str(exc)


def main(argv):
    cfg = parse_args(argv)
    os.chdir(cfg.dir)
    cfg.dir = "."
    rows = build_rows(cfg)
    return perform(cfg, rows)


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
