import json
import os
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
CLI = ROOT / "src" / "nomino.py"


def run_cli(args, cwd=None):
    return subprocess.run(
        [sys.executable, str(CLI), *args],
        cwd=cwd,
        text=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
    )


class NominoCliTest(unittest.TestCase):
    def test_help_and_version_match_documented_program(self):
        help_result = run_cli(["--help"])
        self.assertEqual(help_result.returncode, 0)
        self.assertIn("Batch rename utility for developers", help_result.stdout)
        self.assertIn("Usage: executable [OPTIONS] [[SOURCE] OUTPUT]...", help_result.stdout)

        version_result = run_cli(["--version"])
        self.assertEqual(version_result.returncode, 0)
        self.assertEqual(version_result.stdout, "nomino 1.6.4\n")

    def test_sort_test_mode_uses_natural_order_and_preserves_extensions(self):
        with tempfile.TemporaryDirectory() as tmp:
            for name in ["img2.png", "img10.png", "img1.png"]:
                Path(tmp, name).touch()

            result = run_cli(["-t", "-s", "asc", "pic-{}"], cwd=tmp)

            self.assertEqual(result.returncode, 0)
            self.assertIn("| img1.png  | pic-1.png |", result.stdout)
            self.assertIn("| img2.png  | pic-2.png |", result.stdout)
            self.assertIn("| img10.png | pic-3.png |", result.stdout)
            self.assertEqual(sorted(os.listdir(tmp)), ["img1.png", "img10.png", "img2.png"])

    def test_regex_uses_capture_groups_padding_and_named_groups(self):
        with tempfile.TemporaryDirectory() as tmp:
            Path(tmp, "abc-12.txt").touch()
            Path(tmp, "def-7.md").touch()
            Path(tmp, "nomatch.txt").touch()

            result = run_cli(
                ["-t", "-r", "(?P<word>[a-z]+)-(?P<num>[0-9]+)", "{word}_{num:3}"],
                cwd=tmp,
            )

            self.assertEqual(result.returncode, 0)
            self.assertIn("| abc-12.txt | abc_012.txt |", result.stdout)
            self.assertIn("| def-7.md   | def_007.md  |", result.stdout)
            self.assertNotIn("nomatch", result.stdout)

    def test_map_mode_reads_input_to_output_and_mkdir_creates_parents(self):
        with tempfile.TemporaryDirectory() as tmp:
            Path(tmp, "a.txt").touch()
            Path(tmp, "b.txt").touch()
            Path(tmp, "map.json").write_text(
                json.dumps({"a.txt": "z.txt", "b.txt": "sub/y.txt"}),
                encoding="utf-8",
            )

            result = run_cli(["-k", "-m", "map.json"], cwd=tmp)

            self.assertEqual(result.returncode, 0)
            self.assertTrue(Path(tmp, "z.txt").exists())
            self.assertTrue(Path(tmp, "sub", "y.txt").exists())
            self.assertIn("| a.txt | z.txt     |", result.stdout)
            self.assertIn("| b.txt | sub/y.txt |", result.stdout)

    def test_generate_writes_reverse_map_and_quiet_suppresses_table(self):
        with tempfile.TemporaryDirectory() as tmp:
            Path(tmp, "a.txt").touch()
            Path(tmp, "b.txt").touch()

            result = run_cli(["-q", "-s", "asc", "x-{}", "-g", "map.json"], cwd=tmp)

            self.assertEqual(result.returncode, 0)
            self.assertEqual(result.stdout, "")
            generated = json.loads(Path(tmp, "map.json").read_text(encoding="utf-8"))
            self.assertEqual(generated, {"x-1.txt": "a.txt", "x-2.txt": "b.txt"})

    def test_collision_prepends_underscore_unless_overwrite_is_set(self):
        with tempfile.TemporaryDirectory() as tmp:
            Path(tmp, "a.txt").touch()
            Path(tmp, "z.txt").touch()
            Path(tmp, "map.json").write_text('{"a.txt":"z.txt"}', encoding="utf-8")

            result = run_cli(["-m", "map.json"], cwd=tmp)

            self.assertEqual(result.returncode, 0)
            self.assertTrue(Path(tmp, "_z.txt").exists())
            self.assertTrue(Path(tmp, "z.txt").exists())
            self.assertIn("| a.txt | _z.txt |", result.stdout)

    def test_missing_mode_reports_error(self):
        result = run_cli([])

        self.assertEqual(result.returncode, 1)
        self.assertIn("one of 'regex', 'sort', 'map' or 'SOURCE' options must be set.", result.stderr)

    def test_failed_rename_reports_os_error_without_table(self):
        with tempfile.TemporaryDirectory() as tmp:
            Path(tmp, "a.txt").touch()

            result = run_cli(["-s", "asc", "sub/x"], cwd=tmp)

            self.assertEqual(result.returncode, 1)
            self.assertEqual(result.stdout, "")
            self.assertIn("[error] unable to rename 'a.txt': No such file or directory", result.stderr)


if __name__ == "__main__":
    unittest.main()
