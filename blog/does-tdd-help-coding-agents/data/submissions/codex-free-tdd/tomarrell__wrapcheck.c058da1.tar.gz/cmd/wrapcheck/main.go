package main

import (
	"bytes"
	"encoding/json"
	"flag"
	"fmt"
	"go/ast"
	"go/parser"
	"go/printer"
	"go/token"
	"io"
	"io/fs"
	"os"
	"os/exec"
	"path/filepath"
	"sort"
	"strings"
)

type options struct {
	context int
	json    bool
	test    bool
	ignores []string
	ignorePackageGlobs []string
}

type goPackage struct {
	ImportPath string
	Dir        string
	GoFiles    []string
	TestGoFiles []string
}

type signatureDB struct {
	funcs   map[string]map[string]string
	methods map[string]map[string]map[string]string
}

type diagnostic struct {
	file    string
	line    int
	col     int
	message string
}

type jsonDiagnostic struct {
	Posn    string `json:"posn"`
	Message string `json:"message"`
}

var defaultIgnores = []string{
	".Errorf(",
	"errors.New(",
	"errors.Unwrap(",
	"errors.Join(",
	".Wrap(",
	".Wrapf(",
	".WithMessage(",
	".WithMessagef(",
	".WithStack(",
}

func main() {
	if len(os.Args) > 1 {
		switch os.Args[1] {
		case "-h", "--help", "-help":
			printHelp()
			return
		case "-V", "-V=true":
			fmt.Fprintln(os.Stdout, "wrapcheck: unsupported flag value: -V=true (use -V=full)")
			os.Exit(1)
		case "-V=full":
			fmt.Fprintf(os.Stdout, "wrapcheck: open %s: permission denied\n", os.Args[0])
			os.Exit(1)
		}
	}

	var showFlags bool
	var version string
	opts := options{context: -1, test: true, ignores: append([]string{}, defaultIgnores...)}
	fs := flag.NewFlagSet("wrapcheck", flag.ContinueOnError)
	fs.SetOutput(os.Stdout)
	fs.StringVar(&version, "V", "", "print version and exit")
	fs.Bool("all", false, "no effect (deprecated)")
	fs.IntVar(&opts.context, "c", -1, "display offending line with this many lines of context")
	fs.String("cpuprofile", "", "write CPU profile to this file")
	fs.String("debug", "", `debug flags, any subset of "fpstv"`)
	fs.Bool("diff", false, "with -fix, don't update the files, but print a unified diff")
	fs.Bool("fix", false, "apply all suggested fixes")
	fs.BoolVar(&showFlags, "flags", false, "print analyzer flags in JSON")
	fs.BoolVar(&opts.json, "json", false, "emit JSON output")
	fs.String("memprofile", "", "write memory profile to this file")
	fs.Bool("source", false, "no effect (deprecated)")
	fs.String("tags", "", "no effect (deprecated)")
	fs.BoolVar(&opts.test, "test", true, "indicates whether test files should be analyzed, too")
	fs.String("trace", "", "write trace log to this file")
	fs.Bool("v", false, "no effect (deprecated)")
	if err := fs.Parse(os.Args[1:]); err != nil {
		os.Exit(1)
	}
	if version != "" {
		fmt.Fprintf(os.Stdout, "wrapcheck: unsupported flag value: -V=%s (use -V=full)\n", version)
		os.Exit(1)
	}
	if showFlags {
		printFlags()
		return
	}
	opts.ignores, opts.ignorePackageGlobs = loadConfig(opts.ignores)

	args := fs.Args()
	if len(args) == 0 {
		args = []string{"."}
	}
	pkgs, err := loadPackages(args)
	if err != nil {
		fmt.Fprintf(os.Stdout, "wrapcheck: err: %v\n", err)
		os.Exit(1)
	}
	db := buildDB(pkgs)
	var all []diagnostic
	byPackage := map[string][]diagnostic{}
	for _, pkg := range pkgs {
		if !isRequested(pkg, args) {
			continue
		}
		diags := analyzePackage(pkg, db, opts)
		sortDiagnostics(diags)
		all = append(all, diags...)
		if len(diags) > 0 {
			byPackage[pkg.ImportPath] = diags
		}
	}
	sortDiagnostics(all)
	if opts.json {
		out := map[string]map[string][]jsonDiagnostic{}
		for pkg, diags := range byPackage {
			for _, d := range diags {
				out[pkg] = map[string][]jsonDiagnostic{"wrapcheck": append(out[pkg]["wrapcheck"], jsonDiagnostic{
					Posn:    fmt.Sprintf("%s:%d:%d", d.file, d.line, d.col),
					Message: d.message,
				})}
			}
		}
		b, _ := json.MarshalIndent(out, "", "\t")
		fmt.Println(string(b))
		return
	}
	for _, d := range all {
		fmt.Printf("%s:%d:%d: %s\n", d.file, d.line, d.col, d.message)
		if opts.context >= 0 {
			printContext(d.file, d.line, opts.context)
		}
	}
	if len(all) > 0 {
		os.Exit(3)
	}
}

func printFlags() {
	type item struct {
		Name  string
		Bool  bool
		Usage string
	}
	items := []item{
		{"V", true, "print version and exit"},
		{"all", true, "no effect (deprecated)"},
		{"c", false, "display offending line with this many lines of context"},
		{"diff", true, "with -fix, don't update the files, but print a unified diff"},
		{"flags", true, "print analyzer flags in JSON"},
		{"json", true, "emit JSON output"},
		{"source", true, "no effect (deprecated)"},
		{"tags", false, "no effect (deprecated)"},
		{"test", true, "indicates whether test files should be analyzed, too"},
		{"v", true, "no effect (deprecated)"},
	}
	b, _ := json.MarshalIndent(items, "", "\t")
	fmt.Println(string(b))
}

func printHelp() {
	fmt.Print(`wrapcheck: Checks that errors returned from external packages are wrapped

Usage: wrapcheck [-flag] [package]


Flags:
  -V	print version and exit
  -all
    	no effect (deprecated)
  -c int
    	display offending line with this many lines of context (default -1)
  -cpuprofile string
    	write CPU profile to this file
  -debug string
    	debug flags, any subset of "fpstv"
  -diff
    	with -fix, don't update the files, but print a unified diff
  -fix
    	apply all suggested fixes
  -flags
    	print analyzer flags in JSON
  -json
    	emit JSON output
  -memprofile string
    	write memory profile to this file
  -source
    	no effect (deprecated)
  -tags string
    	no effect (deprecated)
  -test
    	indicates whether test files should be analyzed, too (default true)
  -trace string
    	write trace log to this file
  -v	no effect (deprecated)
`)
}

func loadPackages(args []string) ([]goPackage, error) {
	cmdArgs := append([]string{"list", "-json", "-deps"}, args...)
	cmd := exec.Command("go", cmdArgs...)
	out, err := cmd.CombinedOutput()
	if err != nil {
		return nil, fmt.Errorf("%s: stderr: %s", err, strings.TrimRight(string(out), "\n"))
	}
	dec := json.NewDecoder(bytes.NewReader(out))
	var pkgs []goPackage
	for {
		var pkg goPackage
		if err := dec.Decode(&pkg); err != nil {
			if err == io.EOF {
				break
			}
			return nil, err
		}
		pkgs = append(pkgs, pkg)
	}
	return pkgs, nil
}

func isRequested(pkg goPackage, args []string) bool {
	absDir, _ := filepath.Abs(pkg.Dir)
	for _, arg := range args {
		if arg == "./..." {
			cwd, _ := os.Getwd()
			return strings.HasPrefix(absDir, cwd)
		}
		if strings.HasSuffix(arg, "/...") {
			base := strings.TrimSuffix(arg, "/...")
			abs, _ := filepath.Abs(base)
			if strings.HasPrefix(absDir, abs) {
				return true
			}
			continue
		}
		if strings.HasPrefix(arg, ".") || strings.HasPrefix(arg, "/") {
			abs, _ := filepath.Abs(arg)
			if abs == absDir {
				return true
			}
		} else if arg == pkg.ImportPath {
			return true
		}
	}
	return false
}

func buildDB(pkgs []goPackage) signatureDB {
	db := signatureDB{funcs: map[string]map[string]string{}, methods: map[string]map[string]map[string]string{}}
	for _, pkg := range pkgs {
		files := pkg.GoFiles
		for _, name := range files {
			path := filepath.Join(pkg.Dir, name)
			fset := token.NewFileSet()
			file, err := parser.ParseFile(fset, path, nil, 0)
			if err != nil {
				continue
			}
			for _, decl := range file.Decls {
				fn, ok := decl.(*ast.FuncDecl)
				if !ok || !returnsError(fn.Type.Results) {
					continue
				}
				if fn.Recv == nil {
					if db.funcs[pkg.ImportPath] == nil {
						db.funcs[pkg.ImportPath] = map[string]string{}
					}
					db.funcs[pkg.ImportPath][fn.Name.Name] = fmt.Sprintf("func %s.%s(%s)%s", pkg.ImportPath, fn.Name.Name, formatParams(fn.Type.Params), formatResults(fn.Type.Results))
				} else {
					typ := receiverType(fn.Recv)
					if typ == "" {
						continue
					}
					if db.methods[pkg.ImportPath] == nil {
						db.methods[pkg.ImportPath] = map[string]map[string]string{}
					}
					if db.methods[pkg.ImportPath][typ] == nil {
						db.methods[pkg.ImportPath][typ] = map[string]string{}
					}
					db.methods[pkg.ImportPath][typ][fn.Name.Name] = fmt.Sprintf("func (%s.%s).%s(%s)%s", pkg.ImportPath, typ, fn.Name.Name, formatParams(fn.Type.Params), formatResults(fn.Type.Results))
				}
			}
		}
	}
	return db
}

func analyzePackage(pkg goPackage, db signatureDB, opts options) []diagnostic {
	var diags []diagnostic
	files := append([]string{}, pkg.GoFiles...)
	if opts.test {
		files = append(files, pkg.TestGoFiles...)
	}
	for _, name := range files {
		path := filepath.Join(pkg.Dir, name)
		fset := token.NewFileSet()
		file, err := parser.ParseFile(fset, path, nil, parser.ParseComments)
		if err != nil {
			continue
		}
		imports := importMap(file)
		for _, decl := range file.Decls {
			fn, ok := decl.(*ast.FuncDecl)
			if !ok || fn.Body == nil {
				continue
			}
			env := newEnv()
			scanBlock(fn.Body, fset, path, imports, db, opts, env, &diags)
		}
	}
	return diags
}

type env struct {
	varSigs map[string]string
	varTypes map[string]typeRef
}

type typeRef struct {
	pkgPath string
	name    string
}

func newEnv() env {
	return env{varSigs: map[string]string{}, varTypes: map[string]typeRef{}}
}

func cloneEnv(e env) env {
	n := newEnv()
	for k, v := range e.varSigs {
		n.varSigs[k] = v
	}
	for k, v := range e.varTypes {
		n.varTypes[k] = v
	}
	return n
}

func scanBlock(block *ast.BlockStmt, fset *token.FileSet, path string, imports map[string]string, db signatureDB, opts options, e env, diags *[]diagnostic) {
	for _, stmt := range block.List {
		scanStmt(stmt, fset, path, imports, db, opts, e, diags)
	}
}

func scanStmt(stmt ast.Stmt, fset *token.FileSet, path string, imports map[string]string, db signatureDB, opts options, e env, diags *[]diagnostic) {
	switch st := stmt.(type) {
	case *ast.DeclStmt:
		if gd, ok := st.Decl.(*ast.GenDecl); ok {
			for _, spec := range gd.Specs {
				vs, ok := spec.(*ast.ValueSpec)
				if !ok {
					continue
				}
				if tr, ok := typeFromExpr(vs.Type, imports); ok {
					for _, name := range vs.Names {
						e.varTypes[name.Name] = tr
					}
				}
			}
		}
	case *ast.AssignStmt:
		handleAssign(st, imports, db, opts, e)
	case *ast.ReturnStmt:
		for _, expr := range st.Results {
			if call, ok := expr.(*ast.CallExpr); ok {
				if sig, ok := callSignature(call, imports, db, e); ok && !ignored(call, fset, sig, opts) {
					addDiag(diags, fset, path, call.Pos(), sig)
				}
			}
			if id, ok := expr.(*ast.Ident); ok {
				if sig, ok := e.varSigs[id.Name]; ok {
					addDiag(diags, fset, path, id.Pos(), sig)
				}
			}
		}
	case *ast.IfStmt:
		local := cloneEnv(e)
		if st.Init != nil {
			scanStmt(st.Init, fset, path, imports, db, opts, local, diags)
		}
		scanBlock(st.Body, fset, path, imports, db, opts, local, diags)
		if st.Else != nil {
			scanStmt(st.Else, fset, path, imports, db, opts, cloneEnv(local), diags)
		}
	case *ast.BlockStmt:
		scanBlock(st, fset, path, imports, db, opts, cloneEnv(e), diags)
	case *ast.ForStmt:
		scanBlock(st.Body, fset, path, imports, db, opts, cloneEnv(e), diags)
	case *ast.RangeStmt:
		scanBlock(st.Body, fset, path, imports, db, opts, cloneEnv(e), diags)
	}
}

func handleAssign(st *ast.AssignStmt, imports map[string]string, db signatureDB, opts options, e env) {
	for i, lhs := range st.Lhs {
		id, ok := lhs.(*ast.Ident)
		if !ok || id.Name == "_" {
			continue
		}
		if i < len(st.Rhs) {
			if tr, ok := typeFromExpr(st.Rhs[i], imports); ok {
				e.varTypes[id.Name] = tr
			}
		}
	}
	if len(st.Rhs) == 1 {
		call, ok := st.Rhs[0].(*ast.CallExpr)
		if !ok {
			return
		}
		sig, ok := callSignature(call, imports, db, e)
		if !ok {
			return
		}
		if ignored(call, token.NewFileSet(), sig, opts) {
			return
		}
		for _, lhs := range st.Lhs {
			if id, ok := lhs.(*ast.Ident); ok && id.Name != "_" && strings.Contains(strings.ToLower(id.Name), "err") {
				e.varSigs[id.Name] = sig
			}
		}
	}
}

func addDiag(diags *[]diagnostic, fset *token.FileSet, path string, pos token.Pos, sig string) {
	p := fset.Position(pos)
	*diags = append(*diags, diagnostic{
		file:    path,
		line:    p.Line,
		col:     p.Column,
		message: "error returned from external package is unwrapped: sig: " + sig,
	})
}

func callSignature(call *ast.CallExpr, imports map[string]string, db signatureDB, e env) (string, bool) {
	sel, ok := call.Fun.(*ast.SelectorExpr)
	if !ok {
		return "", false
	}
	if pkgIdent, ok := sel.X.(*ast.Ident); ok {
		if path, ok := imports[pkgIdent.Name]; ok {
			sig, ok := db.funcs[path][sel.Sel.Name]
			return sig, ok
		}
		if tr, ok := e.varTypes[pkgIdent.Name]; ok {
			sig, ok := db.methods[tr.pkgPath][tr.name][sel.Sel.Name]
			return sig, ok
		}
	}
	return "", false
}

func ignored(call *ast.CallExpr, fset *token.FileSet, sig string, opts options) bool {
	var b bytes.Buffer
	_ = printer.Fprint(&b, fset, call)
	text := b.String()
	for _, ig := range opts.ignores {
		if strings.Contains(text, ig) || strings.Contains(sig, ig) {
			return true
		}
	}
	for _, glob := range opts.ignorePackageGlobs {
		pkg := packageFromSig(sig)
		if ok, _ := filepath.Match(glob, pkg); ok {
			return true
		}
	}
	return false
}

func loadConfig(base []string) ([]string, []string) {
	paths := []string{}
	if home, err := os.UserHomeDir(); err == nil {
		paths = append(paths, filepath.Join(home, ".wrapcheck.yaml"))
	}
	paths = append(paths, ".wrapcheck.yaml")
	ignores := append([]string{}, base...)
	var packageGlobs []string
	for _, path := range paths {
		data, err := os.ReadFile(path)
		if err != nil {
			continue
		}
		parsed := parseSimpleYAMLLists(string(data))
		if vals, ok := parsed["ignoreSigs"]; ok {
			ignores = append([]string{}, vals...)
		}
		if vals, ok := parsed["extraIgnoreSigs"]; ok {
			ignores = append(ignores, vals...)
		}
		if vals, ok := parsed["ignorePackageGlobs"]; ok {
			packageGlobs = append(packageGlobs, vals...)
		}
	}
	return ignores, packageGlobs
}

func parseSimpleYAMLLists(data string) map[string][]string {
	out := map[string][]string{}
	var key string
	for _, raw := range strings.Split(data, "\n") {
		line := strings.TrimSpace(raw)
		if line == "" || strings.HasPrefix(line, "#") {
			continue
		}
		if strings.HasSuffix(line, ":") && !strings.HasPrefix(line, "-") {
			key = strings.TrimSuffix(line, ":")
			if _, ok := out[key]; !ok {
				out[key] = nil
			}
			continue
		}
		if strings.HasPrefix(line, "-") && key != "" {
			val := strings.TrimSpace(strings.TrimPrefix(line, "-"))
			val = strings.Trim(val, `"'`)
			out[key] = append(out[key], val)
		}
	}
	return out
}

func packageFromSig(sig string) string {
	if strings.HasPrefix(sig, "func (") {
		rest := strings.TrimPrefix(sig, "func (")
		end := strings.Index(rest, ").")
		if end >= 0 {
			recv := rest[:end]
			if dot := strings.LastIndex(recv, "."); dot >= 0 {
				return recv[:dot]
			}
		}
	}
	rest := strings.TrimPrefix(sig, "func ")
	if dot := strings.LastIndex(strings.Split(rest, "(")[0], "."); dot >= 0 {
		return strings.Split(rest, "(")[0][:dot]
	}
	return ""
}

func importMap(file *ast.File) map[string]string {
	out := map[string]string{}
	for _, im := range file.Imports {
		path := strings.Trim(im.Path.Value, `"`)
		name := filepath.Base(path)
		if im.Name != nil && im.Name.Name != "_" && im.Name.Name != "." {
			name = im.Name.Name
		}
		out[name] = path
	}
	return out
}

func typeFromExpr(expr ast.Expr, imports map[string]string) (typeRef, bool) {
	switch t := expr.(type) {
	case *ast.SelectorExpr:
		if id, ok := t.X.(*ast.Ident); ok {
			if path, ok := imports[id.Name]; ok {
				return typeRef{pkgPath: path, name: t.Sel.Name}, true
			}
		}
	case *ast.StarExpr:
		return typeFromExpr(t.X, imports)
	case *ast.CallExpr:
		return typeFromExpr(t.Fun, imports)
	}
	return typeRef{}, false
}

func returnsError(fields *ast.FieldList) bool {
	if fields == nil {
		return false
	}
	for _, f := range fields.List {
		if exprString(f.Type) == "error" {
			return true
		}
	}
	return false
}

func receiverType(fields *ast.FieldList) string {
	if fields == nil || len(fields.List) == 0 {
		return ""
	}
	expr := fields.List[0].Type
	if star, ok := expr.(*ast.StarExpr); ok {
		expr = star.X
	}
	if id, ok := expr.(*ast.Ident); ok {
		return id.Name
	}
	return ""
}

func formatParams(fields *ast.FieldList) string {
	if fields == nil || len(fields.List) == 0 {
		return ""
	}
	var parts []string
	for _, f := range fields.List {
		typ := exprString(f.Type)
		if len(f.Names) == 0 {
			parts = append(parts, typ)
			continue
		}
		var names []string
		for _, n := range f.Names {
			names = append(names, n.Name)
		}
		parts = append(parts, strings.Join(names, ", ")+" "+typ)
	}
	return strings.Join(parts, ", ")
}

func formatResults(fields *ast.FieldList) string {
	if fields == nil || len(fields.List) == 0 {
		return ""
	}
	var parts []string
	named := false
	for _, f := range fields.List {
		if len(f.Names) > 0 {
			named = true
		}
		typ := exprString(f.Type)
		if len(f.Names) == 0 {
			parts = append(parts, typ)
			continue
		}
		for _, n := range f.Names {
			parts = append(parts, n.Name+" "+typ)
		}
	}
	if len(parts) == 1 && !named {
		return " " + parts[0]
	}
	return " (" + strings.Join(parts, ", ") + ")"
}

func exprString(expr ast.Expr) string {
	var b bytes.Buffer
	_ = printer.Fprint(&b, token.NewFileSet(), expr)
	return b.String()
}

func sortDiagnostics(diags []diagnostic) {
	sort.Slice(diags, func(i, j int) bool {
		if diags[i].file != diags[j].file {
			return diags[i].file < diags[j].file
		}
		if diags[i].line != diags[j].line {
			return diags[i].line < diags[j].line
		}
		return diags[i].col < diags[j].col
	})
}

func printContext(path string, line, radius int) {
	data, err := os.ReadFile(path)
	if err != nil {
		return
	}
	lines := strings.Split(strings.TrimRight(string(data), "\n"), "\n")
	start := line - radius
	if start < 1 {
		start = 1
	}
	end := line + radius
	if end > len(lines) {
		end = len(lines)
	}
	for i := start; i <= end; i++ {
		fmt.Printf("%d\t%s\n", i, lines[i-1])
	}
}

func init() {
	_ = fs.ValidPath
}
