import json
import os
import shutil
import subprocess
import textwrap
import tempfile
import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]


def run(cmd, cwd=ROOT):
    return subprocess.run(cmd, cwd=cwd, text=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)


def build():
    exe = ROOT / "executable"
    if exe.exists():
        exe.unlink()
    result = run(["bash", "compile.sh"])
    assert result.returncode == 0, result.stdout
    assert exe.exists()
    return exe


def make_module(tmp_path):
    (tmp_path / "lib").mkdir()
    (tmp_path / "app").mkdir()
    (tmp_path / "go.mod").write_text("module example.com/probe\n\ngo 1.21\n", encoding="utf-8")
    (tmp_path / "lib" / "lib.go").write_text(
        textwrap.dedent(
            """\
            package lib

            import "errors"

            type C struct{}
            func External() error { return errors.New("x") }
            func Value() (int, error) { return 1, errors.New("x") }
            func (C) Method() error { return errors.New("x") }
            """
        ),
        encoding="utf-8",
    )
    (tmp_path / "app" / "app.go").write_text(
        textwrap.dedent(
            """\
            package app

            import (
             "errors"
             "fmt"
             "example.com/probe/lib"
            )

            type Mine struct{}
            func Internal() error { return errors.New("x") }
            func (Mine) Local() error { return errors.New("x") }

            func A() error { return errors.New("local") }
            func B() error { return fmt.Errorf("x") }
            func C() error { return Internal() }
            func D() error { err := Internal(); return err }
            func E() error { var c lib.C; return c.Method() }
            func F() error { v, err := lib.Value(); _ = v; return err }
            func G() (int,error) { return lib.Value() }
            func H() error { return lib.External() }
            func I() error { err := lib.External(); return err }
            func J() error { return fmt.Errorf("ctx %w", lib.External()) }
            func K() error { var m Mine; return m.Local() }
            """
        ),
        encoding="utf-8",
    )


class WrapcheckTests(unittest.TestCase):
    def run_in_tmp(self, fn):
        with tempfile.TemporaryDirectory() as name:
            return fn(Path(name))

    def test_flags_output_matches_analyzer_contract(self):
        def body(tmp_path):
            exe = build()

            flags = run([str(exe), "-flags"], cwd=tmp_path)
            self.assertEqual(flags.returncode, 0, flags.stdout)
            data = json.loads(flags.stdout)
            self.assertEqual([item["Name"] for item in data], ["V", "all", "c", "diff", "flags", "json", "source", "tags", "test", "v"])

            version = run([str(exe), "-V"], cwd=tmp_path)
            self.assertEqual(version.returncode, 1)
            self.assertEqual(version.stdout, "wrapcheck: unsupported flag value: -V=true (use -V=full)\n")

        self.run_in_tmp(body)

    def test_help_output_matches_analyzer_header(self):
        def body(tmp_path):
            exe = build()

            help_result = run([str(exe), "--help"], cwd=tmp_path)

            self.assertEqual(help_result.returncode, 0, help_result.stdout)
            self.assertTrue(help_result.stdout.startswith(
                "wrapcheck: Checks that errors returned from external packages are wrapped\n\n"
                "Usage: wrapcheck [-flag] [package]\n\n\n"
                "Flags:\n"
            ))
            self.assertIn("  -test\n    \tindicates whether test files should be analyzed, too (default true)\n", help_result.stdout)

        self.run_in_tmp(body)

    def test_plain_output_reports_unwrapped_external_errors(self):
        def body(tmp_path):
            exe = build()
            make_module(tmp_path)

            result = run([str(exe), "./app"], cwd=tmp_path)

            self.assertEqual(result.returncode, 3, result.stdout)
            self.assertEqual(result.stdout, "\n".join(
                [
                    f"{tmp_path}/app/app.go:17:38: error returned from external package is unwrapped: sig: func (example.com/probe/lib.C).Method() error",
                    f"{tmp_path}/app/app.go:18:55: error returned from external package is unwrapped: sig: func example.com/probe/lib.Value() (int, error)",
                    f"{tmp_path}/app/app.go:19:31: error returned from external package is unwrapped: sig: func example.com/probe/lib.Value() (int, error)",
                    f"{tmp_path}/app/app.go:20:25: error returned from external package is unwrapped: sig: func example.com/probe/lib.External() error",
                    f"{tmp_path}/app/app.go:21:48: error returned from external package is unwrapped: sig: func example.com/probe/lib.External() error",
                    "",
                ]
            ))

        self.run_in_tmp(body)

    def test_json_mode_groups_diagnostics_by_import_path(self):
        def body(tmp_path):
            exe = build()
            make_module(tmp_path)

            result = run([str(exe), "-json", "./app"], cwd=tmp_path)

            self.assertEqual(result.returncode, 0, result.stdout)
            data = json.loads(result.stdout)
            messages = data["example.com/probe/app"]["wrapcheck"]
            self.assertEqual(messages[0], {
                "posn": f"{tmp_path}/app/app.go:17:38",
                "message": "error returned from external package is unwrapped: sig: func (example.com/probe/lib.C).Method() error",
            })
            self.assertEqual(len(messages), 5)

        self.run_in_tmp(body)

    def test_context_lines_are_printed_after_each_diagnostic(self):
        def body(tmp_path):
            exe = build()
            make_module(tmp_path)

            result = run([str(exe), "-c=1", "./app"], cwd=tmp_path)

            self.assertEqual(result.returncode, 3, result.stdout)
            self.assertIn(f"{tmp_path}/app/app.go:20:25: error returned from external package is unwrapped: sig: func example.com/probe/lib.External() error\n", result.stdout)
            self.assertIn("19\tfunc G() (int,error) { return lib.Value() }\n20\tfunc H() error { return lib.External() }\n21\tfunc I() error { err := lib.External(); return err }\n", result.stdout)

        self.run_in_tmp(body)

    def test_test_flag_excludes_test_files_when_false(self):
        def body(tmp_path):
            exe = build()
            make_module(tmp_path)
            (tmp_path / "app" / "extra_test.go").write_text(
                textwrap.dedent(
                    """\
                    package app

                    import "example.com/probe/lib"

                    func Helper() error { return lib.External() }
                    """
                ),
                encoding="utf-8",
            )

            skipped = run([str(exe), "-test=false", "./app"], cwd=tmp_path)
            included = run([str(exe), "-test=true", "./app"], cwd=tmp_path)

            self.assertNotIn("extra_test.go", skipped.stdout)
            self.assertIn("extra_test.go:5:30", included.stdout)

        self.run_in_tmp(body)

    def test_extra_ignore_sigs_extends_default_ignores(self):
        def body(tmp_path):
            exe = build()
            make_module(tmp_path)
            (tmp_path / ".wrapcheck.yaml").write_text(
                "extraIgnoreSigs:\n- lib.Value(\n",
                encoding="utf-8",
            )

            result = run([str(exe), "./app"], cwd=tmp_path)

            self.assertEqual(result.returncode, 3, result.stdout)
            self.assertNotIn("lib.Value", result.stdout)
            self.assertNotIn("errors.New", result.stdout)
            self.assertIn("lib.External", result.stdout)

        self.run_in_tmp(body)
