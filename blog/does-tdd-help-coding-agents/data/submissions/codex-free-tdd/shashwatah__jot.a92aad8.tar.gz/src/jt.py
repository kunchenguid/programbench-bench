#!/usr/bin/env python3
from __future__ import annotations

import os
import shutil
import sys
from pathlib import Path


BLUE = "\033[0;34m"
RED = "\033[0;31m"
RESET = "\033[0m"


def home() -> Path:
    return Path(os.environ.get("HOME", "."))


def config_path() -> Path:
    return home() / ".config" / "jot" / "config"


def vaults_path() -> Path:
    return home() / ".local" / "share" / "jot" / "vaults"


def ensure_state() -> None:
    cfg = config_path()
    cfg.parent.mkdir(parents=True, exist_ok=True)
    if not cfg.exists():
        cfg.write_text("editor = 'nvim'\nconflict = true\n")
    vf = vaults_path()
    vf.parent.mkdir(parents=True, exist_ok=True)
    if not vf.exists():
        vf.write_text("[vaults]\n")


def read_vault_state() -> tuple[str | None, dict[str, str]]:
    ensure_state()
    current = None
    vaults: dict[str, str] = {}
    for line in vaults_path().read_text().splitlines():
        line = line.strip()
        if not line or line == "[vaults]":
            continue
        if "=" not in line:
            continue
        key, value = [part.strip() for part in line.split("=", 1)]
        if value.startswith("'") and value.endswith("'"):
            value = value[1:-1]
        if key == "current":
            current = value
        else:
            vaults[key] = value
    return current, vaults


def write_vault_state(current: str | None, vaults: dict[str, str]) -> None:
    lines: list[str] = []
    if current:
        lines.append(f"current = '{current}'")
        lines.append("")
    lines.append("[vaults]")
    for name, loc in vaults.items():
        lines.append(f"{name} = '{loc}'")
    vaults_path().write_text("\n".join(lines) + "\n")


def read_config() -> dict[str, str | bool]:
    ensure_state()
    values: dict[str, str | bool] = {}
    for line in config_path().read_text().splitlines():
        if "=" not in line:
            continue
        key, value = [part.strip() for part in line.split("=", 1)]
        if value in {"true", "false"}:
            values[key] = value == "true"
        elif value.startswith("'") and value.endswith("'"):
            values[key] = value[1:-1]
        else:
            values[key] = value
    return values


def write_config(values: dict[str, str | bool]) -> None:
    lines = []
    for key in ("editor", "conflict"):
        value = values.get(key)
        if isinstance(value, bool):
            text = "true" if value else "false"
        else:
            text = f"'{value}'"
        lines.append(f"{key} = {text}")
    config_path().write_text("\n".join(lines) + "\n")


def vault_root(name: str, loc: str) -> Path:
    return Path(loc) / name


def write_vault_data(name: str, loc: str, folder: str) -> None:
    data = vault_root(name, loc) / ".jot" / "data"
    data.write_text(
        f"name = '{name}'\nlocation = '{loc}'\nfolder = '{folder}'\nhistory = []\n"
    )


def read_vault_data(name: str, loc: str) -> str:
    data = vault_root(name, loc) / ".jot" / "data"
    folder = ""
    if data.exists():
        for line in data.read_text().splitlines():
            if line.startswith("folder = "):
                value = line.split("=", 1)[1].strip()
                if value.startswith("'") and value.endswith("'"):
                    folder = value[1:-1]
    return folder


def current_context() -> tuple[str, str, str] | None:
    current, vaults = read_vault_state()
    if not current or current not in vaults:
        error("not inside a vault")
        return None
    return current, vaults[current], read_vault_data(current, vaults[current])


def current_dir(name: str, loc: str, folder: str) -> Path:
    return vault_root(name, loc) / folder


def error(message: str) -> None:
    print(f"{RED}error{RESET}: {message}")


def print_help() -> None:
    print(
        f"""{BLUE}________      _____ 
______(_)_______  /_
_____  /_  __ \\  __/
____  / / /_/ / /_  
___  /  \\____/\\__/  
/___/         ᵥ₀.₁.₂  
{RESET}         

usage: jt <command>

{BLUE}commands:{RESET}

create items
    {BLUE}vault{RESET}, {BLUE}vl{RESET}       create a vault or list vaults
    create items in current folder
        {BLUE}note{RESET}, {BLUE}nt{RESET}        create a note 
        {BLUE}folder{RESET}, {BLUE}fd{RESET}      create a folder

interact with items
    {BLUE}enter{RESET}, {BLUE}en{RESET}       enter a vault
    {BLUE}open{RESET}, {BLUE}op{RESET}        open a note from current folder
    {BLUE}opdir{RESET}, {BLUE}od{RESET}       open current folder in file explorer
    {BLUE}chdir{RESET}, {BLUE}cd{RESET}       change folder within current vault
    {BLUE}list{RESET}, {BLUE}ls{RESET}        list items in current folder

perform fs operations on items
    {BLUE}remove{RESET}, {BLUE}rm{RESET}      remove an item 
    {BLUE}rename{RESET}, {BLUE}rn{RESET}      rename an item 
    {BLUE}move{RESET}, {BLUE}mv{RESET}        move an item to a new location
    {BLUE}vmove{RESET}, {BLUE}vm{RESET}       move an item to a different vault

config
    {BLUE}config{RESET}, {BLUE}cf{RESET}      display, set or open config

get help 
    use {BLUE}help{RESET} or {BLUE}-h{RESET} and {BLUE}--help{RESET} flags along with a command to get corresponding help"""
    )


def cmd_vault(args: list[str]) -> int:
    current, vaults = read_vault_state()
    if args == ["-l"]:
        for name, loc in vaults.items():
            if name == current:
                print(f"👉 {BLUE}{name}{RESET} \t {loc}")
            else:
                print(f"   {name} \t {loc}")
        return 0
    if not args:
        for name in vaults:
            print(f"   {name}")
        return 0
    if len(args) != 2:
        return 2
    name, loc = args
    if name in vaults:
        error(f"vault {name} already exists")
        return 0
    if not Path(loc).is_absolute():
        error("specified path isn't absolute")
        return 0
    vault_root = Path(loc) / name
    (vault_root / ".jot").mkdir(parents=True, exist_ok=True)
    (vault_root / ".jot" / "data").write_text("")
    vaults[name] = loc
    write_vault_state(current, vaults)
    print(f"vault {BLUE}{name}{RESET} created")
    return 0


def kind_label(kind: str) -> str:
    return {"vl": "vault", "nt": "note", "fd": "folder"}.get(kind, kind)


def item_path(kind: str, item: str, ctx: tuple[str, str, str]) -> Path:
    name, loc, folder = ctx
    base = current_dir(name, loc, folder)
    if kind in {"note", "nt"}:
        return base / f"{item}.md"
    return base / item


def cmd_rename(args: list[str]) -> int:
    if len(args) != 3:
        return 2
    kind, old, new = args
    kind = kind_label(kind)
    current, vaults = read_vault_state()
    if kind == "vault":
        if old not in vaults:
            error(f"vault {old} doesn't exist")
            return 0
        old_root = vault_root(old, vaults[old])
        new_root = vault_root(new, vaults[old])
        if old_root.exists():
            old_root.rename(new_root)
        vaults = {new if key == old else key: value for key, value in vaults.items()}
        if current == old:
            current = new
            write_vault_data(new, vaults[new], "")
        write_vault_state(current, vaults)
        print(f"vault {BLUE}{old}{RESET} renamed to {BLUE}{new}{RESET}")
        return 0
    ctx = current_context()
    if not ctx:
        return 0
    src = item_path(kind, old, ctx)
    dst = item_path(kind, new, ctx)
    if not src.exists():
        error(f"{kind} {old} not found")
        return 0
    src.rename(dst)
    print(f"{kind} {BLUE}{old}{RESET} renamed to {BLUE}{new}{RESET}")
    return 0


def cmd_remove(args: list[str]) -> int:
    if len(args) != 2:
        return 2
    kind, item = args
    kind = kind_label(kind)
    current, vaults = read_vault_state()
    if kind == "vault":
        if item not in vaults:
            error(f"vault {item} doesn't exist")
            return 0
        shutil.rmtree(vault_root(item, vaults[item]), ignore_errors=True)
        vaults.pop(item)
        if current == item:
            current = None
        write_vault_state(current, vaults)
        print(f"vault {BLUE}{item}{RESET} removed")
        return 0
    ctx = current_context()
    if not ctx:
        return 0
    path = item_path(kind, item, ctx)
    if not path.exists():
        error(f"{kind} {item} not found")
        return 0
    if path.is_dir():
        shutil.rmtree(path)
    else:
        path.unlink()
    print(f"{kind} {BLUE}{item}{RESET} removed")
    return 0


def cmd_move(args: list[str]) -> int:
    if len(args) != 3:
        return 2
    kind, item, dest = args
    kind = kind_label(kind)
    current, vaults = read_vault_state()
    if kind == "vault":
        if item not in vaults:
            error(f"vault {item} doesn't exist")
            return 0
        if not Path(dest).is_absolute():
            error("specified path isn't absolute")
            return 0
        src_root = vault_root(item, vaults[item])
        dst_root = Path(dest) / item
        if src_root.exists():
            shutil.move(str(src_root), str(dst_root))
        vaults[item] = dest
        write_vault_state(current, vaults)
        if current == item:
            write_vault_data(item, dest, read_vault_data(item, dest))
        print(f"vault {BLUE}{item}{RESET} moved")
        return 0
    ctx = current_context()
    if not ctx:
        return 0
    name, loc, folder = ctx
    src = item_path(kind, item, ctx)
    target_dir = current_dir(name, loc, folder) / dest
    if not src.exists():
        error(f"{kind} {item} not found")
        return 0
    if not target_dir.exists() or not target_dir.is_dir():
        error("couldn't find the path specified")
        return 0
    shutil.move(str(src), str(target_dir / src.name))
    print(f"{kind} {BLUE}{item}{RESET} moved")
    return 0


def cmd_vmove(args: list[str]) -> int:
    if len(args) != 3:
        return 2
    kind, item, vault = args
    kind = kind_label(kind)
    ctx = current_context()
    if not ctx:
        return 0
    _, vaults = read_vault_state()
    if vault not in vaults:
        error(f"vault {vault} doesn't exist")
        return 0
    src = item_path(kind, item, ctx)
    if not src.exists():
        error(f"{kind} {item} not found")
        return 0
    dst = vault_root(vault, vaults[vault]) / src.name
    shutil.move(str(src), str(dst))
    print(f"{kind} {BLUE}{item}{RESET} moved to vault {BLUE}{vault}{RESET}")
    return 0


def cmd_enter(args: list[str]) -> int:
    if len(args) != 1:
        return 2
    _, vaults = read_vault_state()
    name = args[0]
    if name not in vaults:
        error(f"vault {name} doesn't exist")
        return 0
    write_vault_state(name, vaults)
    write_vault_data(name, vaults[name], "")
    print(f"entered {BLUE}{name}{RESET}")
    return 0


def cmd_note(args: list[str]) -> int:
    if len(args) != 1:
        print("error: The following required arguments were not provided:")
        print("    <note name>")
        return 2
    ctx = current_context()
    if not ctx:
        return 0
    name, loc, folder = ctx
    path = current_dir(name, loc, folder) / f"{args[0]}.md"
    if path.exists():
        error(f"a note named {args[0]} already exists in this location")
        return 0
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text("")
    print(f"note {BLUE}{args[0]}{RESET} created")
    return 0


def cmd_folder(args: list[str]) -> int:
    if len(args) != 1:
        return 2
    ctx = current_context()
    if not ctx:
        return 0
    name, loc, folder = ctx
    path = current_dir(name, loc, folder) / args[0]
    if path.exists():
        error(f"a folder named {args[0]} already exists in this location")
        return 0
    path.mkdir(parents=True)
    print(f"folder {BLUE}{args[0]}{RESET} created")
    return 0


def display_name(path: Path) -> str:
    if path.is_file() and path.suffix == ".md":
        return f"{BLUE}{path.stem}{RESET}"
    return path.name


def cmd_list(args: list[str]) -> int:
    ctx = current_context()
    if not ctx:
        return 0
    name, loc, folder = ctx
    base = current_dir(name, loc, folder)
    header = name if not folder else f"{name} > {folder.replace('/', ' > ')}"
    print(header)
    item_type = args[0] if args else ""
    entries: list[Path] = []
    if base.exists():
        if item_type in {"note", "nt"}:
            entries = sorted([p for p in base.iterdir() if p.is_file() and p.suffix == ".md"], key=lambda p: p.name)
        elif item_type in {"folder", "fd"}:
            visible = sorted([p for p in base.iterdir() if p.is_dir() and p.name != ".jot"], key=lambda p: p.name)
            hidden = sorted([p for p in base.iterdir() if p.is_dir() and p.name == ".jot"], key=lambda p: p.name)
            entries = visible + hidden
        else:
            dirs = sorted([p for p in base.iterdir() if p.is_dir() and p.name != ".jot"], key=lambda p: p.name)
            files = sorted([p for p in base.iterdir() if p.is_file() and p.suffix == ".md"], key=lambda p: p.name)
            entries = dirs + files
    for idx, entry in enumerate(entries):
        prefix = "└── " if idx == len(entries) - 1 else "├── "
        print(prefix + display_name(entry))
    return 0


def cmd_chdir(args: list[str]) -> int:
    if len(args) != 1:
        return 2
    ctx = current_context()
    if not ctx:
        return 0
    name, loc, folder = ctx
    root = vault_root(name, loc).resolve()
    target = (current_dir(name, loc, folder) / args[0]).resolve()
    try:
        target.relative_to(root)
    except ValueError:
        error("path crosses the bounds of vault")
        return 0
    if not target.is_dir():
        error("couldn't find the path specified")
        return 0
    new_folder = "" if target == root else target.relative_to(root).as_posix()
    write_vault_data(name, loc, new_folder)
    print("folder changed")
    return 0


def cmd_config(args: list[str]) -> int:
    values = read_config()
    if not args:
        return 0
    key = args[0]
    if len(args) == 1:
        value = values.get(key, "")
        shown = "true" if value is True else "false" if value is False else str(value)
        print(f"{key}: {BLUE}{shown}{RESET}")
        return 0
    value = args[1]
    values[key] = value == "true" if key == "conflict" else value
    write_config(values)
    print(f"set {BLUE}{key}{RESET} to {BLUE}{value}{RESET}")
    return 0


def cmd_open(args: list[str]) -> int:
    if len(args) != 1:
        return 2
    ctx = current_context()
    if not ctx:
        return 0
    path = item_path("note", args[0], ctx)
    if not path.exists():
        error(f"note {args[0]} not found")
    return 0


def cmd_opdir(args: list[str]) -> int:
    if args:
        return 2
    if not current_context():
        return 0
    return 0


def main(argv: list[str]) -> int:
    ensure_state()
    if not argv or argv[0] in {"help", "-h", "--help"}:
        print_help()
        return 0
    command = argv[0]
    aliases = {
        "vl": "vault",
        "en": "enter",
        "nt": "note",
        "fd": "folder",
        "ls": "list",
        "cd": "chdir",
        "cf": "config",
        "rm": "remove",
        "rn": "rename",
        "mv": "move",
        "vm": "vmove",
        "op": "open",
        "od": "opdir",
    }
    command = aliases.get(command, command)
    if command == "vault":
        return cmd_vault(argv[1:])
    if command == "enter":
        return cmd_enter(argv[1:])
    if command == "note":
        return cmd_note(argv[1:])
    if command == "folder":
        return cmd_folder(argv[1:])
    if command == "list":
        return cmd_list(argv[1:])
    if command == "chdir":
        return cmd_chdir(argv[1:])
    if command == "config":
        return cmd_config(argv[1:])
    if command == "rename":
        return cmd_rename(argv[1:])
    if command == "remove":
        return cmd_remove(argv[1:])
    if command == "move":
        return cmd_move(argv[1:])
    if command == "vmove":
        return cmd_vmove(argv[1:])
    if command == "open":
        return cmd_open(argv[1:])
    if command == "opdir":
        return cmd_opdir(argv[1:])
    return 0


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
