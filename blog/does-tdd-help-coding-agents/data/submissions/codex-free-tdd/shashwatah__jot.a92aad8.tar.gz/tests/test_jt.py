import os
import subprocess
import tempfile
import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
JT = ROOT / "src" / "jt.py"


BLUE = "\033[0;34m"
RED = "\033[0;31m"
RESET = "\033[0m"


class JotCliTests(unittest.TestCase):
    def run_jt(self, home: Path, *args: str):
        env = os.environ.copy()
        env["HOME"] = str(home)
        return subprocess.run(
            ["python3", str(JT), *args],
            text=True,
            capture_output=True,
            env=env,
        )

    def test_initializes_config_and_empty_vaults(self):
        with tempfile.TemporaryDirectory() as td:
            home = Path(td)
            result = self.run_jt(home, "vault")

            self.assertEqual(result.returncode, 0)
            self.assertEqual(result.stdout, "")
            self.assertEqual(result.stderr, "")
            self.assertEqual(
                (home / ".config/jot/config").read_text(),
                "editor = 'nvim'\nconflict = true\n",
            )
            self.assertEqual(
                (home / ".local/share/jot/vaults").read_text(),
                "[vaults]\n",
            )

    def test_top_level_help_mentions_usage_and_version(self):
        with tempfile.TemporaryDirectory() as td:
            home = Path(td)
            result = self.run_jt(home, "--help")

            self.assertEqual(result.returncode, 0)
            self.assertIn("ᵥ₀.₁.₂", result.stdout)
            self.assertIn("usage: jt <command>", result.stdout)
            self.assertIn("vault", result.stdout)
            self.assertIn("config", result.stdout)

    def test_creates_and_lists_vault(self):
        with tempfile.TemporaryDirectory() as td:
            home = Path(td)
            base = home / "vaultroot"
            base.mkdir()

            create = self.run_jt(home, "vault", "alpha", str(base))
            listing = self.run_jt(home, "vault")
            locs = self.run_jt(home, "vault", "-l")

            self.assertEqual(create.stdout, f"vault {BLUE}alpha{RESET} created\n")
            self.assertEqual(listing.stdout, "   alpha\n")
            self.assertEqual(locs.stdout, f"   alpha \t {base}\n")
            self.assertTrue((base / "alpha/.jot/data").is_file())

    def test_enter_create_list_chdir_and_config(self):
        with tempfile.TemporaryDirectory() as td:
            home = Path(td)
            base = home / "vaultroot"
            base.mkdir()
            self.run_jt(home, "vault", "alpha", str(base))

            enter = self.run_jt(home, "enter", "alpha")
            note = self.run_jt(home, "note", "first")
            folder = self.run_jt(home, "folder", "docs")
            listing = self.run_jt(home, "list")
            only_notes = self.run_jt(home, "list", "note")
            only_folders = self.run_jt(home, "list", "folder")
            chdir = self.run_jt(home, "chdir", "docs")
            nested = self.run_jt(home, "note", "nested")
            nested_listing = self.run_jt(home, "list")
            editor = self.run_jt(home, "config", "editor")
            set_editor = self.run_jt(home, "config", "editor", "true")

            self.assertEqual(enter.stdout, f"entered {BLUE}alpha{RESET}\n")
            self.assertEqual(note.stdout, f"note {BLUE}first{RESET} created\n")
            self.assertEqual(folder.stdout, f"folder {BLUE}docs{RESET} created\n")
            self.assertEqual(listing.stdout, f"alpha\n├── docs\n└── {BLUE}first{RESET}\n")
            self.assertEqual(only_notes.stdout, f"alpha\n└── {BLUE}first{RESET}\n")
            self.assertEqual(only_folders.stdout, "alpha\n├── docs\n└── .jot\n")
            self.assertEqual(chdir.stdout, "folder changed\n")
            self.assertEqual(nested.stdout, f"note {BLUE}nested{RESET} created\n")
            self.assertEqual(nested_listing.stdout, f"alpha > docs\n└── {BLUE}nested{RESET}\n")
            self.assertEqual(editor.stdout, f"editor: {BLUE}nvim{RESET}\n")
            self.assertEqual(set_editor.stdout, f"set {BLUE}editor{RESET} to {BLUE}true{RESET}\n")
            self.assertEqual((base / "alpha/first.md").read_text(), "")
            self.assertEqual((base / "alpha/docs/nested.md").read_text(), "")

    def test_rename_move_remove_and_vmove_items(self):
        with tempfile.TemporaryDirectory() as td:
            home = Path(td)
            base = home / "base"
            other = home / "other"
            base.mkdir()
            other.mkdir()
            self.run_jt(home, "vault", "alpha", str(base))
            self.run_jt(home, "vault", "beta", str(other))
            self.run_jt(home, "enter", "alpha")
            self.run_jt(home, "note", "first")
            self.run_jt(home, "folder", "docs")

            rn_note = self.run_jt(home, "rename", "note", "first", "renamed")
            rn_folder = self.run_jt(home, "rename", "folder", "docs", "pages")
            mv_note = self.run_jt(home, "move", "note", "renamed", "pages")
            moved_listing = self.run_jt(home, "chdir", "pages")
            list_pages = self.run_jt(home, "list")
            back = self.run_jt(home, "chdir", "..")
            vmove = self.run_jt(home, "vmove", "folder", "pages", "beta")
            rm_missing = self.run_jt(home, "remove", "note", "renamed")
            rn_vault = self.run_jt(home, "rename", "vault", "alpha", "gamma")
            vault_l = self.run_jt(home, "vault", "-l")

            self.assertEqual(rn_note.stdout, f"note {BLUE}first{RESET} renamed to {BLUE}renamed{RESET}\n")
            self.assertEqual(rn_folder.stdout, f"folder {BLUE}docs{RESET} renamed to {BLUE}pages{RESET}\n")
            self.assertEqual(mv_note.stdout, f"note {BLUE}renamed{RESET} moved\n")
            self.assertEqual(moved_listing.stdout, "folder changed\n")
            self.assertEqual(list_pages.stdout, f"alpha > pages\n└── {BLUE}renamed{RESET}\n")
            self.assertEqual(back.stdout, "folder changed\n")
            self.assertEqual(vmove.stdout, f"folder {BLUE}pages{RESET} moved to vault {BLUE}beta{RESET}\n")
            self.assertEqual(rm_missing.stdout, f"{RED}error{RESET}: note renamed not found\n")
            self.assertEqual(rn_vault.stdout, f"vault {BLUE}alpha{RESET} renamed to {BLUE}gamma{RESET}\n")
            self.assertIn(f"👉 {BLUE}gamma{RESET} \t {base}\n", vault_l.stdout)
            self.assertTrue((other / "beta/pages/renamed.md").is_file())
            self.assertFalse((base / "gamma/pages").exists())


if __name__ == "__main__":
    unittest.main()
