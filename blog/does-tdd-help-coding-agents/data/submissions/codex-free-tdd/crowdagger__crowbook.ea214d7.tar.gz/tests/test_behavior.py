#!/usr/bin/env python3
import os
import subprocess
import tempfile
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
CANDIDATE = Path(os.environ.get("CANDIDATE", ROOT / "executable"))


def run(args, cwd=None, input_text=None):
    return subprocess.run(
        [str(CANDIDATE), *args],
        cwd=cwd,
        input=input_text,
        text=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
    )


def assert_contains(haystack, needle):
    assert needle in haystack, f"missing {needle!r} in:\n{haystack[:1000]}"


def test_help_and_version_contract():
    help_run = run(["--help"])
    assert help_run.returncode == 0
    assert_contains(help_run.stdout, "crowbook 0.17.0 by")
    assert_contains(help_run.stdout, "Render a Markdown book in EPUB, PDF or HTML.")
    assert_contains(help_run.stdout, "  -c, --create <files>...")
    assert help_run.stderr == ""

    version_run = run(["--version"])
    assert version_run.returncode == 0
    assert version_run.stdout == "crowbook 0.17.0\n"
    assert version_run.stderr == ""


def test_create_writes_book_skeleton_to_stdout_and_banner_to_stderr():
    with tempfile.TemporaryDirectory() as d:
        p = Path(d)
        (p / "one.md").write_text("# One\n\nBody\n", encoding="utf-8")
        result = run(["--create", "one.md", "two.md"], cwd=p)
    assert result.returncode == 0
    assert result.stderr == "CROWBOOK 0.17.0\n"
    assert_contains(result.stdout, '"author: Your name"')
    assert_contains(result.stdout, '"# output.html: some_file.html"')
    assert_contains(result.stdout, "## List of chapters\n+ one.md\n+ two.md")


def test_stats_counts_visible_text_from_configured_chapters():
    with tempfile.TemporaryDirectory() as d:
        p = Path(d)
        (p / "ch1.md").write_text("# Chapter One\n\nHello **world**!\n", encoding="utf-8")
        (p / "book.book").write_text(
            "title: Stats\noutput.html: ignored.html\n+ ch1.md\n", encoding="utf-8"
        )
        result = run(["--stats", "book.book"], cwd=p)
    assert result.returncode == 0
    assert result.stderr == "CROWBOOK 0.17.0\n"
    assert_contains(result.stdout, "Chapter      Chars      Words  Chars/Word")
    assert_contains(result.stdout, "ch1.md          23          3        7.67")
    assert_contains(result.stdout, "TOTAL:          23          3        7.67")


def test_renders_simple_configured_html_book():
    with tempfile.TemporaryDirectory() as d:
        p = Path(d)
        (p / "ch1.md").write_text(
            "# Chapter One\n\nHello **world**!\n\n## Section\n\n"
            "Text with *emphasis* and [link](https://example.com).\n",
            encoding="utf-8",
        )
        (p / "book.book").write_text(
            "title: My Book\nauthor: Jane Doe\nlang: en\noutput.html: out.html\n+ ch1.md\n",
            encoding="utf-8",
        )
        result = run(["book.book"], cwd=p)
        html = (p / "out.html").read_text(encoding="utf-8")
    assert result.returncode == 0
    assert result.stdout == ""
    assert result.stderr == "CROWBOOK 0.17.0\n"
    assert_contains(html, '<!DOCTYPE html>')
    assert_contains(html, '<html lang="en">')
    assert_contains(html, '<meta name="author" content="Jane Doe">')
    assert_contains(html, '<title>My Book</title>')
    assert_contains(html, '<h1 id = "link-0" class="title" >My Book</h1>')
    assert_contains(html, "<span class = 'chapter-header'>Chapter 1</span><br />Chapter One")
    assert_contains(html, '<p id = "para-1">Hello <b>world</b>!</p>')
    assert_contains(html, '<h2 id = "link-2">Section</h2>')
    assert_contains(html, '<a href = "https://example.com">link</a>')


def test_single_file_requires_to_and_can_render_with_output():
    with tempfile.TemporaryDirectory() as d:
        p = Path(d)
        (p / "single.md").write_text("# Standalone\n\nText\n", encoding="utf-8")
        missing = run(["--single", "-o", "single.html", "single.md"], cwd=p)
        assert missing.returncode == 2
        assert_contains(missing.stderr, "the following required arguments were not provided:")
        assert_contains(missing.stderr, "--to <to>")

        result = run(["--single", "--to", "html", "-o", "single.html", "single.md"], cwd=p)
        html = (p / "single.html").read_text(encoding="utf-8")
    assert result.returncode == 0
    assert result.stderr == "CROWBOOK 0.17.0\n"
    assert_contains(html, '<title></title>')
    assert_contains(html, "<span class = 'chapter-header'>Chapter 1</span><br />Standalone")


def test_missing_book_reports_error_but_exits_successfully():
    result = run(["missing.book"])
    assert result.returncode == 0
    assert result.stdout == ""
    assert result.stderr == "CROWBOOK 0.17.0\nERROR Could not find file 'missing.book' for book\n"


def test_set_after_book_and_html_dir_output():
    with tempfile.TemporaryDirectory() as d:
        p = Path(d)
        (p / "ch1.md").write_text("# Original\n\nBody\n", encoding="utf-8")
        (p / "book.book").write_text(
            "title: Before\noutput.html.dir: site\n+ ch1.md\n", encoding="utf-8"
        )
        result = run(["book.book", "--set", "title", "After"], cwd=p)
        index = (p / "site" / "index.html").read_text(encoding="utf-8")
        chapter = (p / "site" / "chapter_000.html").read_text(encoding="utf-8")
        stylesheet_exists = (p / "site" / "stylesheet.css").exists()
        print_exists = (p / "site" / "print.css").exists()
    assert result.returncode == 0
    assert result.stderr.startswith("CROWBOOK 0.17.0\n")
    assert_contains(index, "<title>After</title>")
    assert_contains(chapter, "Original")
    assert stylesheet_exists
    assert print_exists


if __name__ == "__main__":
    failures = []
    for name, func in sorted(globals().items()):
        if name.startswith("test_"):
            try:
                func()
            except Exception as exc:
                failures.append((name, exc))
                print(f"FAIL {name}: {exc}")
            else:
                print(f"PASS {name}")
    if failures:
        raise SystemExit(1)
