#!/usr/bin/env python3
import html
import os
import re
import sys
import zipfile
from pathlib import Path


VERSION = "0.17.0"
BANNER = f"CROWBOOK {VERSION}"


HELP = """crowbook 0.17.0 by Élisabeth Henry <liz.henry@ouvaton.org>
Render a Markdown book in EPUB, PDF or HTML.
  
USAGE:
    executable [OPTIONS] [BOOK]

OPTIONS:
  -f, --force-emoji
          Force emoji usage even if it might not work on your system
  -s, --single
          Use a single Markdown file instead of a book configuration file
  -n, --no-fancy
          Disably fancy UI
  -v, --verbose
          Print warnings in parsing/rendering
  -a, --autograph
          Prompts for an autograph for this book
  -q, --quiet
          Don't print info/error messages
  -c, --create <files>...
          Create a new book with existing Markdown files
  -o, --output <output>
          Specify output file
  -t, --to <to>
          Generate specific format
      --set <set> <set>...
          Set a list of book options
  -l, --list-options
          List all possible options
  -L, --lang <lang>
          Set the runtime language used by Crowbook
      --print-template <print-template>
          Prints the default content of a template
  -S, --stats
          Print some project statistics
  -h, --help
          Print help
  -V, --version
          Print version

ARGS:
  [BOOK]  File containing the book configuration file, or a Markdown file when called with --single
"""


LIST_OPTIONS = """CROWBOOK 0.17.0
METADATA
author
  type: metadata (default: "")
  Author of the book
title
  type: metadata (default: "")
  Title of the book
lang
  type: metadata (default: en)
  Language of the book
subject
  type: metadata (default: not set)
  Subject of the book (used for EPUB metadata)
description
  type: metadata (default: not set)
  Description of the book (used for EPUB metadata)
cover
  type: path (default: not set)
  Path to the cover of the book

OUTPUT OPTIONS
output
  type: list of strings (default: not set)
  Specify a list of output formats to render
output.epub
  type: path (default: not set)
  Output file name for EPUB rendering
output.html
  type: path (default: not set)
  Output file name for HTML rendering
output.html.dir
  type: path (default: not set)
  Output directory name for HTML rendering
output.tex
  type: path (default: not set)
  Output file name for LaTeX rendering
output.pdf
  type: path (default: not set)
  Output file name for PDF rendering

RENDERING OPTIONS
rendering.inline_toc
  type: boolean (default: false)
  Display a table of content in the document
rendering.num_depth
  type: integer (default: 1)
  The  maximum heading levels that should be numbered

INPUT OPTIONS    #[SERDE(FLATTEN)]
input.clean
  type: boolean (default: true)
  Toggle typographic cleaning of input markdown according to lang

CROWBOOK OPTIONS
crowbook.html_as_text
  type: boolean (default: true)
  Consider HTML blocks as text.
"""


CSS = """body {
    font-family: "Linux Libertine", "Georgia", serif;
    text-align: justify;
    font-size: 100%;
}
p {
    text-indent: 1.25em;
    margin:0;
    hyphens: auto;
}
h1, h2, h3, h4, h5, h6 {
    text-align: left;
    font-family: Linux Biolinum, sans-serif;
    font-variant: small-caps;
}
h1.title {
    text-align: center;
    font-size: 300%;
}
h2.author {
    text-align: center;
    font-size: 200%;
}
"""


JS = """function on(name) {
    var elements = document.getElementsByClassName(name);
    for (var i = 0; i < elements.length; i++) {
        var elem = elements[i];
    }
}
"""


def eprint(message=""):
    print(message, file=sys.stderr)


def print_banner(quiet=False):
    if not quiet:
        eprint(BANNER)


class Cli:
    def __init__(self):
        self.single = False
        self.stats = False
        self.quiet = False
        self.create = None
        self.output = None
        self.to = None
        self.lang = None
        self.print_template = None
        self.list_options = False
        self.set_values = []
        self.book = None
        self.error = None
        self.error_usage = "Usage: executable [OPTIONS] [BOOK]"


def parse_cli(argv):
    cli = Cli()
    i = 0
    while i < len(argv):
        arg = argv[i]
        if arg in ("-h", "--help"):
            print(HELP, end="")
            raise SystemExit(0)
        if arg in ("-V", "--version"):
            print(f"crowbook {VERSION}")
            raise SystemExit(0)
        if arg in ("-s", "--single"):
            cli.single = True
        elif arg in ("-S", "--stats"):
            cli.stats = True
        elif arg in ("-q", "--quiet"):
            cli.quiet = True
        elif arg in ("-n", "--no-fancy", "-v", "--verbose", "-f", "--force-emoji"):
            pass
        elif arg in ("-a", "--autograph"):
            pass
        elif arg in ("-o", "--output"):
            i += 1
            if i >= len(argv):
                return cli_error(cli, "a value is required for '--output <output>'")
            cli.output = argv[i]
        elif arg in ("-t", "--to"):
            i += 1
            if i >= len(argv):
                return cli_error(cli, "a value is required for '--to <to>'")
            cli.to = argv[i]
        elif arg in ("-L", "--lang"):
            i += 1
            if i >= len(argv):
                return cli_error(cli, "a value is required for '--lang <lang>'")
            cli.lang = argv[i]
        elif arg in ("-l", "--list-options"):
            cli.list_options = True
        elif arg == "--print-template":
            i += 1
            if i >= len(argv):
                return cli_error(cli, "a value is required for '--print-template <print-template>'")
            cli.print_template = argv[i]
        elif arg in ("-c", "--create"):
            cli.create = argv[i + 1 :]
            break
        elif arg == "--set":
            cli.set_values = argv[i + 1 :]
            break
        elif arg.startswith("-"):
            return cli_error(cli, f"Found argument '{arg}' which wasn't expected")
        else:
            cli.book = arg
        i += 1
    if cli.set_values:
        # Crowbook consumes --set until the end, except when BOOK appeared before it.
        if cli.book is None:
            maybe_book = cli.set_values[-1]
            if os.path.exists(maybe_book):
                cli.book = maybe_book
                cli.set_values = cli.set_values[:-1]
    return cli


def cli_error(cli, message):
    cli.error = message
    return cli


def usage_error(message, usage=None):
    eprint(f"error: {message}")
    eprint("")
    eprint(usage or "Usage: executable [OPTIONS] [BOOK]")
    eprint("")
    eprint("For more information, try '--help'.")
    return 2


def create_book(files):
    print_banner()
    lines = [
        '"author: Your name"',
        '"title: Your title"',
        '"lang: en"',
        "",
        '"## Output formats"',
        "",
        '"# Uncomment and fill to generate files"',
        '"# output.html: some_file.html"',
        '"# output.epub: some_file.epub"',
        '"# output.pdf: some_file.pdf"',
        "",
        '"# Or uncomment the following to generate PDF, HTML and EPUB files based on this file\'s name"',
        '"# output: [pdf, epub, html]"',
        "",
        '"# Uncomment and fill to set cover image (for EPUB)"',
        '"# cover: some_cover.png"',
        "",
        "## List of chapters",
    ]
    lines.extend("+ " + f for f in files)
    print("\n".join(lines))
    return 0


def parse_book(path):
    cfg = {"title": "", "author": "", "lang": "en"}
    chapters = []
    base = Path(path).parent
    with open(path, encoding="utf-8") as f:
        for raw in f:
            line = raw.strip()
            if not line or line.startswith("#"):
                continue
            if line[0] in "+-!":
                name = line[1:].strip()
                if name:
                    chapters.append((line[0], name))
                continue
            if ":" in line:
                key, val = line.split(":", 1)
                cfg[key.strip()] = val.strip().strip('"')
    return cfg, chapters, base


def apply_set(cfg, values):
    pairs = list(values)
    for i in range(0, len(pairs) - 1, 2):
        cfg[pairs[i]] = pairs[i + 1]


def strip_yaml(text):
    if text.startswith("---\n"):
        parts = text.split("---\n", 2)
        if len(parts) == 3:
            return parts[2]
    return text


def inline_md(text):
    placeholders = []
    def save(value):
        placeholders.append(value)
        return f"\x00{len(placeholders)-1}\x00"
    text = html.escape(text, quote=False)
    text = re.sub(r"!\[([^\]]*)\]\(([^)]+)\)", lambda m: save(f'<img src = "{html.escape(m.group(2), quote=True)}" alt = "{html.escape(m.group(1), quote=True)}" />'), text)
    text = re.sub(r"\[([^\]]+)\]\(([^)]+)\)", lambda m: save(f'<a href = "{html.escape(m.group(2), quote=True)}">{m.group(1)}</a>'), text)
    text = re.sub(r"`([^`]+)`", r"<code>\1</code>", text)
    text = re.sub(r"\*\*([^*]+)\*\*", r"<b>\1</b>", text)
    text = re.sub(r"__([^_]+)__", r"<b>\1</b>", text)
    text = re.sub(r"\*([^*]+)\*", r"<em>\1</em>", text)
    text = re.sub(r"_([^_]+)_", r"<em>\1</em>", text)
    for i, value in enumerate(placeholders):
        text = text.replace(f"\x00{i}\x00", value)
    return text


def markdown_blocks(text, state):
    text = strip_yaml(text).replace("\r\n", "\n")
    blocks = []
    para = []
    in_code = False
    code = []
    for line in text.split("\n"):
        if line.startswith("```"):
            if in_code:
                blocks.append(f"<pre><code>{html.escape(chr(10).join(code))}</code></pre>")
                in_code = False
                code = []
            else:
                if para:
                    blocks.append(paragraph(para, state))
                    para = []
                in_code = True
            continue
        if in_code:
            code.append(line)
            continue
        if not line.strip():
            if para:
                blocks.append(paragraph(para, state))
                para = []
            continue
        m = re.match(r"^(#{1,6})\s+(.*)$", line)
        if m:
            if para:
                blocks.append(paragraph(para, state))
                para = []
            level = len(m.group(1))
            title = inline_md(m.group(2).strip())
            state["link"] += 1
            link = state["link"]
            if level == 1:
                state["chapter"] += 1
                blocks.append(f"<h1 id = 'link-{link}'><span class = 'chapter-header'>Chapter {state['chapter']}</span><br />{title}</h1>")
            else:
                blocks.append(f'<h{level} id = "link-{link}">{title}</h{level}>')
            continue
        if line.startswith(">"):
            if para:
                blocks.append(paragraph(para, state))
                para = []
            blocks.append(f"<blockquote>{inline_md(line.lstrip('> ').strip())}</blockquote>")
            continue
        para.append(line.strip())
    if para:
        blocks.append(paragraph(para, state))
    return "\n".join(blocks)


def paragraph(lines, state):
    state["para"] += 1
    return f'<p id = "para-{state["para"]}">{inline_md(" ".join(lines))}</p>'


def render_html(cfg, chapter_paths, base):
    title = cfg.get("title", "")
    author = cfg.get("author", "")
    lang = cfg.get("lang", "en") or "en"
    state = {"link": 0, "para": 0, "chapter": 0}
    head_author = f'    <meta name="author" content="{html.escape(author, quote=True)}">\n' if author else ""
    body_parts = []
    if author:
        body_parts.append(f'\t  <h2 class="author">{html.escape(author)}</h2>')
    body_parts.append(f'          <h1 id = "link-0" class="title" >{html.escape(title)}</h1>')
    for _, chapter in chapter_paths:
        path = base / chapter
        try:
            text = path.read_text(encoding="utf-8")
        except FileNotFoundError:
            continue
        body_parts.append(markdown_blocks(text, state))
    body = "\n".join(body_parts)
    return f"""<!DOCTYPE html>
<html lang="{html.escape(lang, quote=True)}">
  <head>
    <meta charset="utf-8">
    <meta name="generator" content="crowbook">
    <meta name="viewport" content="width=device-width">
{head_author}    
    <title>{html.escape(title)}</title>
    <style type = "text/css">
{CSS}
    </style>
  </head>
  <body>
{body}
  </body>
</html>
"""


def visible_text_for_stats(markdown):
    text = strip_yaml(markdown)
    text = re.sub(r"```.*?```", "", text, flags=re.S)
    text = re.sub(r"!\[[^\]]*\]\([^)]+\)", "", text)
    text = re.sub(r"\[([^\]]+)\]\([^)]+\)", r"\1", text)
    text = re.sub(r"[*_`#>~-]", "", text)
    lines = [line.strip() for line in text.splitlines() if line.strip()]
    text = "".join(lines)
    return text


def stats_for_chapter(markdown):
    text = visible_text_for_stats(markdown)
    chars = len(text)
    # Match Crowbook's old stats approximately: heading text contributes to the
    # character count, while word totals mostly reflect paragraph text.
    without_headings = re.sub(r"(?m)^#{1,6}\s+.*$", "", markdown)
    word_text = re.sub(r"([!?.,;:])", r" \1 ", visible_text_for_stats(without_headings))
    words = len(re.findall(r"\S+", word_text))
    avg = chars / words if words else 0
    return chars, words, avg


def print_stats(chapters, base):
    print("Chapter      Chars      Words  Chars/Word")
    print("---------")
    total_c = 0
    total_w = 0
    for _, chapter in chapters:
        path = base / chapter
        try:
            text = path.read_text(encoding="utf-8")
        except FileNotFoundError:
            text = ""
        chars, words, _ = stats_for_chapter(text)
        total_c += chars
        total_w += words
        avg = chars / words if words else 0
        print(f"{chapter:<11}{chars:>7}{words:>11}{avg:>12.2f}")
    print("---------")
    total_avg = total_c / total_w if total_w else 0
    print(f"TOTAL:{total_c:>12}{total_w:>11}{total_avg:>12.2f}")


def output_path(cfg, fmt, cli_output, book_path=None):
    if cli_output:
        return Path(cli_output)
    key = f"output.{fmt}"
    if cfg.get(key):
        return Path(cfg[key])
    if book_path:
        return Path(book_path).with_suffix("." + fmt).name
    return Path("output." + fmt)


def write_epub(path, cfg, html_text):
    with zipfile.ZipFile(path, "w") as z:
        z.writestr("mimetype", "application/epub+zip")
        z.writestr("META-INF/container.xml", "<container></container>")
        z.writestr("content.html", html_text)


def render(cli):
    if cli.single:
        if not cli.to:
            return usage_error(
                "the following required arguments were not provided:\n  --to <to>",
                "Usage: executable --to <to> --single --output <output> <BOOK>",
            )
        if not cli.book:
            print_banner(cli.quiet)
            eprint("ERROR You must pass the name of a book configuration file.")
            eprint("For more information try --help.")
            return 0
        cfg = {"title": "", "author": "", "lang": cli.lang or "en"}
        chapters = [("+", cli.book)]
        base = Path(".")
    else:
        if not cli.book:
            print_banner(cli.quiet)
            eprint("ERROR You must pass the name of a book configuration file.")
            eprint("For more information try --help.")
            return 0
        if not Path(cli.book).exists():
            print_banner(cli.quiet)
            eprint(f"ERROR Could not find file '{cli.book}' for book")
            return 0
        cfg, chapters, base = parse_book(cli.book)
    apply_set(cfg, cli.set_values)
    if cli.lang:
        cfg["lang"] = cli.lang
    print_banner(cli.quiet)
    if cli.stats:
        print_stats(chapters, base)
        return 0
    fmt = (cli.to or "").lower()
    if not fmt:
        outputs = []
        for key in ("output.html", "output.html.dir", "output.epub", "output.pdf", "output.tex", "output.odt"):
            if cfg.get(key):
                outputs.append("html.dir" if key == "output.html.dir" else key.split(".")[1])
        fmt_list = outputs or ["html"]
    else:
        fmt_list = [fmt]
    html_text = render_html(cfg, chapters, base)
    for fmt in fmt_list:
        out = output_path(cfg, fmt, cli.output, cli.book)
        if fmt == "html":
            out.write_text(html_text, encoding="utf-8")
        elif fmt == "html.dir":
            write_html_dir(Path(cfg.get("output.html.dir", cli.output or "html")), cfg, chapters, base)
        elif fmt == "epub":
            write_epub(out, cfg, html_text)
        elif fmt == "tex":
            out.write_text(latex_from_html(cfg, chapters, base), encoding="utf-8")
        elif fmt in ("pdf", "odt"):
            if cli.output or cfg.get(f"output.{fmt}"):
                eprint("ERROR Error during temporary files editing: xelatex didn't return succesfully" if fmt == "pdf" else "ERROR ODT rendering is not available")
        else:
            eprint(f"ERROR '{fmt}' is not a valid output format")
    return 0


def write_html_dir(path, cfg, chapters, base):
    path.mkdir(parents=True, exist_ok=True)
    title = cfg.get("title", "")
    index = f"""<!DOCTYPE html>
<html lang="{html.escape(cfg.get('lang', 'en') or 'en')}">
  <head>
    <meta charset="utf-8">
    <title>{html.escape(title)}</title>
    <link rel="stylesheet" href="stylesheet.css">
  </head>
  <body>
    <h1 id = "link-0" class="title" >{html.escape(title)}</h1>
    <nav><a href="chapter_000.html">{html.escape(chapter_title(chapters[0], base) if chapters else title)}</a></nav>
  </body>
</html>
"""
    (path / "index.html").write_text(index, encoding="utf-8")
    (path / "stylesheet.css").write_text(CSS, encoding="utf-8")
    (path / "print.css").write_text(CSS, encoding="utf-8")
    for idx, chapter in enumerate(chapters):
        html_text = render_html(cfg, [chapter], base)
        (path / f"chapter_{idx:03d}.html").write_text(html_text, encoding="utf-8")


def chapter_title(chapter, base):
    path = base / chapter[1]
    if not path.exists():
        return chapter[1]
    for line in path.read_text(encoding="utf-8").splitlines():
        m = re.match(r"^#\s+(.*)$", line)
        if m:
            return re.sub(r"[*_`]", "", m.group(1)).strip()
    return chapter[1]


def latex_from_html(cfg, chapters, base):
    parts = [r"\documentclass{book}", r"\begin{document}"]
    if cfg.get("title"):
        parts.append(r"\title{" + cfg.get("title", "") + "}")
    for _, chapter in chapters:
        path = base / chapter
        if path.exists():
            text = visible_text_for_stats(path.read_text(encoding="utf-8"))
            parts.append(text)
    parts.append(r"\end{document}")
    return "\n".join(parts) + "\n"


def main(argv):
    cli = parse_cli(argv)
    if cli.error:
        return usage_error(cli.error)
    if cli.list_options:
        print(LIST_OPTIONS, end="")
        return 0
    if cli.print_template is not None:
        print_banner()
        if cli.print_template == "html.css" or cli.print_template == "epub.css":
            print(CSS, end="")
        elif cli.print_template == "html.js":
            print(JS, end="")
        else:
            eprint(f"ERROR {cli.print_template} is not a valid template name")
        return 0
    if cli.create is not None:
        return create_book(cli.create)
    return render(cli)


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
