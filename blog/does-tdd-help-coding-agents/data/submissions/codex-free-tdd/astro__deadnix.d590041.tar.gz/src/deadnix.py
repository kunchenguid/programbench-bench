#!/usr/bin/env python3
import json
import os
import re
import sys
from dataclasses import dataclass
from pathlib import Path


HELP = """Find dead code in .nix files

Usage: executable [OPTIONS] [FILE_PATHS]...

Arguments:
  [FILE_PATHS]...  .nix files, or directories with .nix files inside [default: .]

Options:
  -l, --no-lambda-arg                  Don't check lambda parameter arguments
  -L, --no-lambda-pattern-names        Don't check lambda attrset pattern names (don't break nixpkgs callPackage)
  -_, --no-underscore                  Don't check any bindings that start with a _
                                       (Lambda arguments starting with _ are not checked anyway.)
  -W, --warn-used-underscore           Warn if bindings are referenced that start with '_'
  -q, --quiet                          Don't print dead code report
  -e, --edit                           Remove unused code and write to source file
  -h, --hidden                         Recurse into hidden subdirectories and process hidden .*.nix files
      --help                           
  -f, --fail                           Exit with 1 if unused code has been found
  -o, --output-format <OUTPUT_FORMAT>  Output format to use [default: human-readable] [possible values: human-readable, json]
      --exclude <EXCLUDES>...          Files to exclude from analysis
  -V, --version                        Print version
"""


IDENT = r"[A-Za-z_][A-Za-z0-9_'-]*"
IDENT_RE = re.compile(IDENT)


@dataclass
class Options:
    check_lambda_arg: bool = True
    check_lambda_pattern: bool = True
    check_underscore: bool = True
    warn_used_underscore: bool = False
    quiet: bool = False
    edit: bool = False
    hidden: bool = False
    fail: bool = False
    output_format: str = "human-readable"
    excludes: list[str] = None
    paths: list[str] = None


@dataclass
class Binding:
    name: str
    kind: str
    line: int
    column: int
    end_column: int
    line_text: str
    skip: bool = False


def parse_args(argv):
    opts = Options(excludes=[], paths=[])
    i = 0
    after_dd = False
    while i < len(argv):
        arg = argv[i]
        if after_dd:
            opts.paths.append(arg)
        elif arg == "--":
            after_dd = True
        elif arg == "--help":
            print(HELP, end="")
            raise SystemExit(0)
        elif arg in ("-V", "--version"):
            print("deadnix 1.3.1")
            raise SystemExit(0)
        elif arg in ("-l", "--no-lambda-arg"):
            opts.check_lambda_arg = False
        elif arg in ("-L", "--no-lambda-pattern-names"):
            opts.check_lambda_pattern = False
        elif arg in ("-_", "--no-underscore"):
            opts.check_underscore = False
        elif arg in ("-W", "--warn-used-underscore"):
            opts.warn_used_underscore = True
        elif arg in ("-q", "--quiet"):
            opts.quiet = True
        elif arg in ("-e", "--edit"):
            opts.edit = True
        elif arg in ("-h", "--hidden"):
            opts.hidden = True
        elif arg in ("-f", "--fail"):
            opts.fail = True
        elif arg.startswith("-") and len(arg) > 2 and set(arg[1:]) <= set("qfeh"):
            for ch in arg[1:]:
                if ch == "q":
                    opts.quiet = True
                elif ch == "f":
                    opts.fail = True
                elif ch == "e":
                    opts.edit = True
                elif ch == "h":
                    opts.hidden = True
        elif arg in ("-o", "--output-format"):
            i += 1
            if i >= len(argv):
                cli_error("a value is required for '--output-format <OUTPUT_FORMAT>'")
            opts.output_format = argv[i]
            if opts.output_format not in ("human-readable", "json"):
                print(
                    f"error: invalid value '{opts.output_format}' for '--output-format <OUTPUT_FORMAT>'\n"
                    "  [possible values: human-readable, json]\n\n"
                    "For more information, try '--help'.",
                    file=sys.stderr,
                )
                raise SystemExit(2)
        elif arg == "--exclude":
            i += 1
            while i < len(argv) and argv[i] != "--":
                opts.excludes.append(argv[i])
                i += 1
            if i < len(argv) and argv[i] == "--":
                after_dd = True
        elif arg.startswith("-"):
            cli_error(f"unexpected argument '{arg}' found")
        else:
            opts.paths.append(arg)
        i += 1
    if not opts.paths:
        opts.paths = ["."]
    return opts


def cli_error(message):
    print(f"error: {message}\n\nFor more information, try '--help'.", file=sys.stderr)
    raise SystemExit(2)


def mask_code(text):
    out = []
    in_string = False
    escaped = False
    in_comment = False
    i = 0
    while i < len(text):
        ch = text[i]
        if in_comment:
            if ch == "\n":
                in_comment = False
                out.append(ch)
            else:
                out.append(" ")
            i += 1
            continue
        if in_string:
            if ch == "$" and i + 1 < len(text) and text[i + 1] == "{":
                out.extend([" ", " "])
                i += 2
                depth = 1
                while i < len(text) and depth:
                    expr_ch = text[i]
                    if expr_ch == "{":
                        depth += 1
                    elif expr_ch == "}":
                        depth -= 1
                        if depth == 0:
                            out.append(" ")
                            i += 1
                            break
                    out.append(expr_ch if depth else " ")
                    i += 1
                continue
            if escaped:
                escaped = False
            elif ch == "\\":
                escaped = True
            elif ch == '"':
                in_string = False
            out.append("\n" if ch == "\n" else " ")
            i += 1
            continue
        if ch == "#":
            in_comment = True
            out.append(" ")
        elif ch == '"':
            in_string = True
            out.append(" ")
        else:
            out.append(ch)
        i += 1
    return "".join(out)


def line_offsets(lines):
    offsets = []
    pos = 0
    for line in lines:
        offsets.append(pos)
        pos += len(line)
    return offsets


def is_hidden_path(path):
    return any(part.startswith(".") for part in Path(path).parts if part not in (".", ".."))


def collect_files(paths, excludes, hidden):
    excluded = {str(Path(e)) for e in excludes}
    files = []
    for raw in paths:
        path = Path(raw)
        if not path.exists():
            print(f"Error stating file {raw}: No such file or directory (os error 2)", file=sys.stderr)
            continue
        if path.is_dir():
            for root, dirs, names in os.walk(path):
                if not hidden:
                    dirs[:] = [d for d in dirs if not d.startswith(".")]
                for name in sorted(names):
                    if not name.endswith(".nix"):
                        continue
                    p = Path(root) / name
                    if not hidden and name.startswith("."):
                        continue
                    if str(p) in excluded:
                        continue
                    files.append(p)
        elif path.suffix == ".nix" and str(path) not in excluded:
            if hidden or not is_hidden_path(path):
                files.append(path)
    return files


def find_lambda_colon(line):
    depth = 0
    for idx, ch in enumerate(line):
        if ch in "{[(":
            depth += 1
        elif ch in "}])" and depth:
            depth -= 1
        elif ch == ":" and depth == 0:
            return idx
    return -1


def parse_pattern_names(pattern):
    names = []
    body = pattern.strip()
    if body.startswith("{") and "}" in body:
        body = body[1 : body.rfind("}")]
    cursor = 0
    for part in body.split(","):
        m = re.search(IDENT, part)
        if not m:
            cursor += len(part) + 1
            continue
        name = m.group(0)
        if name == "...":
            cursor += len(part) + 1
            continue
        names.append((name, cursor + m.start()))
        cursor += len(part) + 1
    return names


def declaration_spans(lines, masked_lines, opts):
    bindings = []
    in_let = False
    skip_next = False
    for lineno, (raw, line) in enumerate(zip(lines, masked_lines), start=1):
        if "deadnix: skip" in raw:
            skip_next = True
            continue
        if re.match(r"^\s*let\b", line) or re.search(r":\s*let\s*$", line):
            in_let = True
        if in_let:
            for m in re.finditer(r"\binherit\s*(?:\([^)]*\)\s*)?([^;]+);", line):
                names_part = m.group(1)
                base = m.start(1)
                for nm in re.finditer(IDENT, names_part):
                    name = nm.group(0)
                    bindings.append(Binding(name, "let binding", lineno, base + nm.start() + 1, base + nm.end() + 1, raw.rstrip("\n"), skip_next))
                skip_next = False
                break
            else:
                m = re.match(r"^(\s*)(" + IDENT + r")\s*=", line)
                if m:
                    name = m.group(2)
                    bindings.append(Binding(name, "let binding", lineno, m.start(2) + 1, m.end(2) + 1, raw.rstrip("\n"), skip_next))
                    skip_next = False
        if re.match(r"^\s*in\b", line):
            in_let = False
        if opts.check_lambda_pattern:
            pattern_re = re.compile(r"(?:(?P<pre>" + IDENT + r")@)?\{(?P<body>[^}]*)\}(?:@(?P<post>" + IDENT + r"))?\s*:")
            for pm in pattern_re.finditer(line):
                if pm.group("pre"):
                    name = pm.group("pre")
                    if not (not opts.check_underscore and name.startswith("_")):
                        bindings.append(Binding(name, "lambda pattern", lineno, pm.start("pre") + 1, pm.end("pre") + 1, raw.rstrip("\n"), skip_next))
                body = pm.group("body")
                body_start = pm.start("body")
                cursor = 0
                field_names = []
                for part in body.split(","):
                    nm = re.search(IDENT, part)
                    if nm:
                        field_names.append((nm.group(0), cursor + nm.start(), cursor + nm.end()))
                    cursor += len(part) + 1
                for name, start, end in field_names:
                    if not (not opts.check_underscore and name.startswith("_")):
                        bindings.append(Binding(name, "lambda pattern", lineno, body_start + start + 1, body_start + end + 1, raw.rstrip("\n"), skip_next))
                if pm.group("post"):
                    name = pm.group("post")
                    if not (not opts.check_underscore and name.startswith("_")):
                        bindings.append(Binding(name, "lambda pattern", lineno, pm.start("post") + 1, pm.end("post") + 1, raw.rstrip("\n"), skip_next))
                skip_next = False
        colon = find_lambda_colon(line)
        if colon > 0:
            before = line[:colon].rstrip()
            if opts.check_lambda_arg:
                m = re.search(r"(" + IDENT + r")\s*$", before)
                if m and not before.endswith("}") and not m.group(1).startswith("_"):
                    bindings.append(Binding(m.group(1), "lambda argument", lineno, m.start(1) + 1, m.end(1) + 1, raw.rstrip("\n"), skip_next))
                    skip_next = False
    return bindings


def token_occurrences(masked):
    hits = {}
    for m in IDENT_RE.finditer(masked):
        hits.setdefault(m.group(0), []).append(m.start())
    return hits


def analyze_file(path, opts):
    text = Path(path).read_text(errors="replace")
    lines = text.splitlines(True)
    masked = mask_code(text)
    masked_lines = masked.splitlines(True)
    offsets = line_offsets(lines)
    bindings = declaration_spans(lines, masked_lines, opts)
    hits = token_occurrences(masked)
    decl_positions = {offsets[b.line - 1] + b.column - 1 for b in bindings}
    results = []
    for b in bindings:
        if b.skip:
            continue
        if b.name.startswith("_") and not opts.check_underscore and b.kind != "lambda argument":
            continue
        decl_abs = offsets[b.line - 1] + b.column - 1
        is_used = False
        for pos in hits.get(b.name, []):
            if pos in decl_positions:
                continue
            line_no = 1 + masked.count("\n", 0, pos)
            line = masked_lines[line_no - 1] if line_no - 1 < len(masked_lines) else ""
            if b.kind == "let binding" and line_no == b.line and re.match(r"^\s*" + re.escape(b.name) + r"\s*=", line):
                continue
            if "let " + b.name in line and line_no != b.line:
                continue
            is_used = True
            break
        if b.name.startswith("_") and opts.warn_used_underscore and is_used and b.kind == "let binding":
            msg = f"Used {b.kind}: {b.name}"
        elif is_used:
            continue
        else:
            msg = f"Unused {b.kind}: {b.name}"
        results.append({"column": b.column, "endColumn": b.end_column, "line": b.line, "message": msg})
    results.sort(key=lambda item: (item["line"], item["column"], item["message"]))
    return {"file": str(path), "results": results}


def render_human(report):
    if not report["results"]:
        return ""
    lines = [f"Warning: Unused declarations were found.", f"    ╭─[{report['file']}:{report['results'][0]['line']}:{report['results'][0]['column']}]"]
    src = Path(report["file"]).read_text(errors="replace").splitlines()
    for r in report["results"]:
        text = src[r["line"] - 1] if r["line"] - 1 < len(src) else ""
        lines.append(f"{r['line']:>3} │{text}")
        caret = " " * (r["column"] - 1) + "╰" + "─" * max(1, r["endColumn"] - r["column"] - 3)
        lines.append(f"    │{caret} {r['message']}")
    return "\n".join(lines) + "\n"


def edit_file(path, report):
    if not report["results"]:
        return
    lines = Path(path).read_text(errors="replace").splitlines(True)
    remove_lines = {
        r["line"] for r in report["results"] if r["message"].startswith("Unused let binding:")
    }
    edits_by_line = {}
    for r in report["results"]:
        if r["line"] in remove_lines:
            continue
        edits_by_line.setdefault(r["line"], []).append(r)

    for line_no, edits in edits_by_line.items():
        idx = line_no - 1
        if idx < 0 or idx >= len(lines):
            continue
        line = lines[idx]
        newline = "\n" if line.endswith("\n") else ""
        body = line[:-1] if newline else line
        for r in sorted(edits, key=lambda item: item["column"], reverse=True):
            start = r["column"] - 1
            end = r["endColumn"] - 1
            msg = r["message"]
            if msg.startswith("Unused lambda argument:"):
                if start < len(body) and body[start] != "_":
                    body = body[:start] + "_" + body[start:]
            elif msg.startswith("Unused lambda pattern:"):
                if end < len(body) and body[end] == "@":
                    body = body[:start] + body[end + 1 :]
                    continue
                if start > 0 and body[start - 1] == "@":
                    body = body[: start - 1] + body[end:]
                    continue
                remove_start = start
                remove_end = end
                while remove_end < len(body) and body[remove_end].isspace():
                    remove_end += 1
                if remove_end < len(body) and body[remove_end] == ",":
                    remove_end += 1
                    while remove_end < len(body) and body[remove_end].isspace():
                        remove_end += 1
                elif remove_start > 0:
                    p = remove_start - 1
                    while p >= 0 and body[p].isspace():
                        p -= 1
                    if p >= 0 and body[p] == ",":
                        remove_start = p
                        while remove_start > 0 and body[remove_start - 1].isspace():
                            remove_start -= 1
                body = body[:remove_start] + body[remove_end:]
        lines[idx] = body + newline

    kept = [line for idx, line in enumerate(lines, start=1) if idx not in remove_lines]
    Path(path).write_text("".join(kept))


def main(argv):
    opts = parse_args(argv)
    any_results = False
    files = collect_files(opts.paths, opts.excludes, opts.hidden)
    for path in files:
        report = analyze_file(path, opts)
        if report["results"]:
            any_results = True
            if opts.edit:
                edit_file(path, report)
        if not opts.quiet and report["results"]:
            if opts.output_format == "json":
                print(json.dumps(report, separators=(",", ":")))
            else:
                print(render_human(report), end="")
    return 1 if opts.fail and any_results else 0


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
