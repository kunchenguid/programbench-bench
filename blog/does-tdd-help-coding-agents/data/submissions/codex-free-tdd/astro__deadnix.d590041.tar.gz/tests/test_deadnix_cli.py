import json
import os
import shutil
import subprocess
import tempfile
import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]


class DeadnixCliTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        subprocess.run(["bash", "compile.sh"], cwd=ROOT, check=True)
        cls.exe = ROOT / "executable"

    def run_cli(self, *args, cwd=None, env=None):
        merged_env = os.environ.copy()
        merged_env["NO_COLOR"] = "1"
        if env:
            merged_env.update(env)
        return subprocess.run(
            [str(self.exe), *args],
            cwd=cwd or ROOT,
            env=merged_env,
            text=True,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
        )

    def write(self, path, text):
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(text)

    def parse_json_lines(self, output):
        return [json.loads(line) for line in output.splitlines() if line.strip()]

    def test_help_and_version_match_documented_cli(self):
        help_result = self.run_cli("--help")
        version_result = self.run_cli("--version")

        self.assertEqual(help_result.returncode, 0)
        self.assertIn("Find dead code in .nix files", help_result.stdout)
        self.assertIn("Usage: executable [OPTIONS] [FILE_PATHS]...", help_result.stdout)
        self.assertIn("--warn-used-underscore", help_result.stdout)
        self.assertEqual(version_result.stdout, "deadnix 1.3.1\n")

    def test_reports_unused_let_bindings_as_json(self):
        with tempfile.TemporaryDirectory() as td:
            sample = Path(td) / "simple.nix"
            self.write(sample, "let\n  unused = 1;\n  used = 2;\nin used\n")

            result = self.run_cli("-o", "json", str(sample))

        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertEqual(
            self.parse_json_lines(result.stdout),
            [
                {
                    "file": str(sample),
                    "results": [
                        {
                            "column": 3,
                            "endColumn": 9,
                            "line": 2,
                            "message": "Unused let binding: unused",
                        }
                    ],
                }
            ],
        )

    def test_reports_lambda_patterns_and_respects_disable_flags(self):
        with tempfile.TemporaryDirectory() as td:
            sample = Path(td) / "lambda.nix"
            self.write(
                sample,
                "arg: { a, b ? 1, ... }@args: let\n"
                "  _x = 1;\n"
                "  y = 2;\n"
                "in arg + a + args.c\n",
            )

            default = self.run_cli("-o", "json", str(sample))
            no_patterns = self.run_cli("-L", "-o", "json", str(sample))
            no_underscore = self.run_cli("-_", "-o", "json", str(sample))

        default_messages = [r["message"] for r in self.parse_json_lines(default.stdout)[0]["results"]]
        no_pattern_messages = [r["message"] for r in self.parse_json_lines(no_patterns.stdout)[0]["results"]]
        no_underscore_messages = [r["message"] for r in self.parse_json_lines(no_underscore.stdout)[0]["results"]]

        self.assertEqual(
            default_messages,
            [
                "Unused lambda pattern: b",
                "Unused let binding: _x",
                "Unused let binding: y",
            ],
        )
        self.assertNotIn("Unused lambda pattern: b", no_pattern_messages)
        self.assertNotIn("Unused let binding: _x", no_underscore_messages)

    def test_pragmas_and_used_underscore_warnings(self):
        with tempfile.TemporaryDirectory() as td:
            sample = Path(td) / "skip.nix"
            self.write(sample, "let\n  # deadnix: skip\n  unused = 1;\n  other = 2;\nin _used\n")
            warn = Path(td) / "warn.nix"
            self.write(warn, "let\n  _used = 1;\nin _used\n")

            skipped = self.run_cli("-o", "json", str(sample))
            warned = self.run_cli("-W", "-o", "json", str(warn))

        self.assertEqual(
            [r["message"] for r in self.parse_json_lines(skipped.stdout)[0]["results"]],
            ["Unused let binding: other"],
        )
        self.assertEqual(
            self.parse_json_lines(warned.stdout)[0]["results"][0]["message"],
            "Used let binding: _used",
        )

    def test_traversal_exclude_quiet_and_fail(self):
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            self.write(root / "a.nix", "let\n  unused = 1;\nin 2\n")
            self.write(root / "skip.nix", "let\n  ignored = 1;\nin 2\n")
            self.write(root / ".hidden.nix", "let\n  hidden = 1;\nin 2\n")
            self.write(root / ".hdir" / "nested.nix", "let\n  nested = 1;\nin 2\n")

            visible = self.run_cli("-o", "json", "--exclude", str(root / "skip.nix"), "--", str(root))
            hidden = self.run_cli("-h", "-o", "json", str(root))
            quiet_fail = self.run_cli("-qf", str(root / "a.nix"))

        visible_files = [Path(item["file"]).name for item in self.parse_json_lines(visible.stdout)]
        hidden_files = [Path(item["file"]).name for item in self.parse_json_lines(hidden.stdout)]

        self.assertEqual(visible_files, ["a.nix"])
        self.assertIn(".hidden.nix", hidden_files)
        self.assertIn("nested.nix", hidden_files)
        self.assertEqual(quiet_fail.returncode, 1)
        self.assertEqual(quiet_fail.stdout, "")

    def test_documented_example_json_report(self):
        with tempfile.TemporaryDirectory() as td:
            sample = Path(td) / "example.nix"
            self.write(
                sample,
                "unusedArgs@{ unusedArg, usedArg, ... }:\n"
                "let\n"
                "  inherit (builtins) unused_inherit;\n"
                "  inherit (used2) used_inherit;\n"
                "  unused = \"fnord\";\n"
                "  used1 = \"important\";\n"
                "  used2 = usedArg;\n"
                "  used3 = used4: \"k.${used4}\";\n"
                "  used4 = { t = used_inherit; };\n"
                "  shadowed = 42;\n"
                "  _unused = unused: false;\n"
                "  _used = 23;\n"
                "in {\n"
                "  x = { unusedArg2, x ? args.y, ... }@args: used1 + x;\n"
                "  inherit used2;\n"
                "  \"${used3}\" = true;\n"
                "  y = used4.t;\n"
                "  z = let shadowed = 23; in shadowed;\n"
                "  inherit _used;\n"
                "}\n",
            )

            result = self.run_cli("-o", "json", str(sample))

        self.assertEqual(
            self.parse_json_lines(result.stdout)[0]["results"],
            [
                {"column": 1, "endColumn": 11, "line": 1, "message": "Unused lambda pattern: unusedArgs"},
                {"column": 14, "endColumn": 23, "line": 1, "message": "Unused lambda pattern: unusedArg"},
                {"column": 22, "endColumn": 36, "line": 3, "message": "Unused let binding: unused_inherit"},
                {"column": 3, "endColumn": 9, "line": 5, "message": "Unused let binding: unused"},
                {"column": 3, "endColumn": 11, "line": 10, "message": "Unused let binding: shadowed"},
                {"column": 3, "endColumn": 10, "line": 11, "message": "Unused let binding: _unused"},
                {"column": 13, "endColumn": 19, "line": 11, "message": "Unused lambda argument: unused"},
                {"column": 9, "endColumn": 19, "line": 14, "message": "Unused lambda pattern: unusedArg2"},
            ],
        )

    def test_edit_removes_let_and_pattern_bindings_and_renames_lambda_args(self):
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            simple = root / "simple.nix"
            arg = root / "arg.nix"
            pattern = root / "pattern.nix"
            self.write(simple, "let\n  unused = 1;\n  used = 2;\nin used\n")
            self.write(arg, "unused: used: used\n")
            self.write(pattern, "{ unused, used, ... }: used\n")

            self.run_cli("-e", str(simple))
            self.run_cli("-e", str(arg))
            self.run_cli("-e", str(pattern))

            self.assertEqual(simple.read_text(), "let\n  used = 2;\nin used\n")
            self.assertEqual(arg.read_text(), "_unused: used: used\n")
            self.assertEqual(pattern.read_text(), "{ used, ... }: used\n")


if __name__ == "__main__":
    unittest.main()
