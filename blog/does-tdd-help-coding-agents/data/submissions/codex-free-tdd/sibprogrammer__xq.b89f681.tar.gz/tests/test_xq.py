#!/usr/bin/env python3
import os
import subprocess
import tempfile
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
EXE = ROOT / "executable"


def run_xq(args, data=None, cwd=None):
    proc = subprocess.run(
        [str(EXE), *args],
        input=data,
        text=True,
        capture_output=True,
        cwd=cwd,
    )
    return proc.returncode, proc.stdout, proc.stderr


def test_help_and_version_match_documented_cli():
    code, out, err = run_xq(["--help"])
    assert code == 0
    assert err == ""
    assert "Command-line XML and HTML beautifier and content extractor" in out
    assert "  -x, --xpath string" in out
    assert "      --compact" in out

    code, out, err = run_xq(["--version"])
    assert (code, out, err) == (0, "xq version 1.4.0\n", "")


def test_formats_xml_from_stdin_with_custom_indent():
    xml = '<root><city id="1">NY</city><city>LA</city><empty/><user status="ok">Bob</user></root>'
    code, out, err = run_xq(["--no-color", "--indent", "4"], xml)
    assert code == 0
    assert err == ""
    assert out == (
        "<root>\n"
        '    <city id="1">NY</city>\n'
        "    <city>LA</city>\n"
        "    <empty/>\n"
        '    <user status="ok">Bob</user>\n'
        "</root>\n"
    )


def test_long_flags_accept_equals_values():
    xml = '<root><city id="1">NY</city><city>LA</city></root>'
    code, out, err = run_xq(["--no-color", "--indent=4"], xml)
    assert (code, err) == (0, "")
    assert out == '<root>\n    <city id="1">NY</city>\n    <city>LA</city>\n</root>\n'

    code, out, err = run_xq(["--no-color", "--xpath=//city"], xml)
    assert (code, out, err) == (0, "NY\nLA\n", "")


def test_xpath_text_node_and_attribute_extraction():
    xml = '<root><city id="1">NY</city><city>LA</city><user status="ok">Bob</user></root>'
    code, out, err = run_xq(["--no-color", "-x", "//city"], xml)
    assert (code, out, err) == (0, "NY\nLA\n", "")

    code, out, err = run_xq(["--no-color", "-x", "/root/user/@status"], xml)
    assert (code, out, err) == (0, "ok\n", "")

    code, out, err = run_xq(["--no-color", "-n", "-x", "//city"], xml)
    assert (code, out, err) == (0, '<city id="1">NY</city>\n<city>LA</city>\n', "")


def test_json_output_preserves_attributes_text_and_repeated_nodes():
    xml = '<root><city id="1">NY</city><city>LA</city><empty/><user status="ok">Bob</user></root>'
    code, out, err = run_xq(["--no-color", "-j", "--compact"], xml)
    assert code == 0
    assert err == ""
    assert out == (
        '{"root": {"city": [{"#text": "NY","@id": "1"},"LA"],'
        '"empty": {},"user": {"#text": "Bob","@status": "ok"}}}\n'
    )


def test_css_query_text_node_and_attribute_extraction_for_html():
    html = (
        '<html><head><title>T</title><script src="x.js"></script></head>'
        '<body><p class="a">Hello <b>world</b></p><p id="second">Two</p></body></html>'
    )
    code, out, err = run_xq(["--no-color", "-m", "-q", "body > p"], html)
    assert (code, out, err) == (0, "Hello world\nTwo\n", "")

    code, out, err = run_xq(["--no-color", "-m", "-q", "p.a"], html)
    assert (code, out, err) == (0, "Hello world\n", "")

    code, out, err = run_xq(["--no-color", "-m", "-q", "#second"], html)
    assert (code, out, err) == (0, "Two\n", "")

    code, out, err = run_xq(["--no-color", "-m", "-q", "head > script", "-a", "src"], html)
    assert (code, out, err) == (0, "x.js\n", "")


def test_in_place_formats_file():
    with tempfile.TemporaryDirectory() as td:
        path = Path(td) / "input.xml"
        path.write_text("<root><a>1</a><b>2</b></root>")
        code, out, err = run_xq(["--no-color", "-i", str(path)])
        assert (code, out, err) == (0, "", "")
        assert path.read_text() == "<root>\n  <a>1</a>\n  <b>2</b>\n</root>\n"


def test_missing_file_error_matches_cli_style():
    code, out, err = run_xq(["does-not-exist.xml"])
    assert code == 1
    assert out == ""
    assert err == "Error: open does-not-exist.xml: no such file or directory\n"
