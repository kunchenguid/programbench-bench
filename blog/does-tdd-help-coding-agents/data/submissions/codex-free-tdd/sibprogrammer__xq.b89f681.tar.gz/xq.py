#!/usr/bin/env python3
import html
import json
import os
import sys
import xml.etree.ElementTree as ET
from html.parser import HTMLParser


HELP = """Command-line XML and HTML beautifier and content extractor

Usage:
  xq [flags]

Flags:
  -a, --attr string      Extract an attribute value instead of node content for provided CSS query
  -c, --color            Force colorful output
      --compact          Compact JSON output (no indentation)
  -d, --depth int        Maximum nesting depth for JSON output (-1 for unlimited) (default -1)
  -e, --extract string   Extract a single node from XML
  -h, --help             Print this help message
  -m, --html             Use HTML formatter
  -i, --in-place         Format file in place
      --indent int       Use the given number of spaces for indentation (default 2)
  -j, --json             Output the result as JSON
      --no-color         Disable colorful output
  -n, --node             Return the node content instead of text
  -q, --query string     Extract the node(s) using CSS selector
      --tab              Use tabs for indentation
  -v, --version          Print version information
  -x, --xpath string     Extract the node(s) from XML
"""


VOID_HTML = {"area", "base", "br", "col", "embed", "hr", "img", "input", "link", "meta", "param", "source", "track", "wbr"}


class Args:
    def __init__(self):
        self.attr = ""
        self.color = False
        self.compact = False
        self.depth = -1
        self.extract = ""
        self.html = False
        self.in_place = False
        self.indent = 2
        self.json = False
        self.no_color = False
        self.node = False
        self.query = ""
        self.tab = False
        self.xpath = ""
        self.file = None


def parse_args(argv):
    args = Args()
    i = 0
    while i < len(argv):
        a = argv[i]
        if a.startswith("--") and "=" in a:
            a, inline_value = a.split("=", 1)
            argv = argv[:i] + [a, inline_value] + argv[i + 1 :]
        if a in ("-h", "--help"):
            print(HELP, end="")
            raise SystemExit(0)
        if a in ("-v", "--version"):
            print("xq version 1.4.0")
            raise SystemExit(0)
        if a in ("-a", "--attr", "-e", "--extract", "--indent", "-d", "--depth", "-q", "--query", "-x", "--xpath"):
            if i + 1 >= len(argv):
                print(f"Error: flag needs an argument: {a}", file=sys.stderr)
                raise SystemExit(1)
            v = argv[i + 1]
            if a in ("-a", "--attr"):
                args.attr = v
            elif a in ("-e", "--extract"):
                args.extract = v
            elif a == "--indent":
                args.indent = int(v)
            elif a in ("-d", "--depth"):
                args.depth = int(v)
            elif a in ("-q", "--query"):
                args.query = v
            elif a in ("-x", "--xpath"):
                args.xpath = v
            i += 2
            continue
        if a in ("-c", "--color"):
            args.color = True
        elif a == "--compact":
            args.compact = True
        elif a in ("-m", "--html"):
            args.html = True
        elif a in ("-i", "--in-place"):
            args.in_place = True
        elif a == "--no-color":
            args.no_color = True
        elif a in ("-j", "--json"):
            args.json = True
        elif a in ("-n", "--node"):
            args.node = True
        elif a == "--tab":
            args.tab = True
        elif a.startswith("-"):
            print(f"Error: unknown flag: {a}", file=sys.stderr)
            raise SystemExit(1)
        elif args.file is None:
            args.file = a
        else:
            print(f"Error: unknown argument: {a}", file=sys.stderr)
            raise SystemExit(1)
        i += 1
    return args


def read_input(args):
    if args.file:
        try:
            with open(args.file, "r", encoding="utf-8") as f:
                return f.read()
        except OSError as e:
            print(f"Error: open {args.file}: {e.strerror.lower()}", file=sys.stderr)
            raise SystemExit(1)
    return sys.stdin.read()


def unit(args, level):
    return ("\t" if args.tab else " " * args.indent) * level


def elem_text(e):
    parts = []
    if e.text and e.text.strip():
        parts.append(e.text.strip())
    for c in list(e):
        t = elem_text(c)
        if t:
            parts.append(t)
        if c.tail and c.tail.strip():
            parts.append(c.tail.strip())
    return " ".join(parts)


def attrs_str(attrs):
    return "".join(f' {k}="{html.escape(v, quote=True)}"' for k, v in attrs.items())


def format_xml_elem(e, args, level=0):
    ind = unit(args, level)
    tag = e.tag
    attrs = attrs_str(e.attrib)
    children = list(e)
    text = (e.text or "").strip()
    if not children and not text:
        return f"{ind}<{tag}{attrs}/>\n"
    if not children:
        return f"{ind}<{tag}{attrs}>{html.escape(text)}</{tag}>\n"
    out = f"{ind}<{tag}{attrs}>"
    if text:
        out += html.escape(text)
    out += "\n"
    for child in children:
        out += format_xml_elem(child, args, level + 1)
        if child.tail and child.tail.strip():
            out = out.rstrip("\n") + " " + html.escape(child.tail.strip()) + "\n"
    out += f"{ind}</{tag}>\n"
    return out


def format_xml(data, args):
    prefix = ""
    stripped = data.lstrip()
    if stripped.startswith("<?xml"):
        end = stripped.find("?>")
        if end != -1:
            prefix = stripped[: end + 2].strip() + "\n"
            data = stripped[end + 2 :]
    root = ET.fromstring(data)
    return prefix + format_xml_elem(root, args)


def xml_to_obj(e):
    children = list(e)
    text = (e.text or "").strip()
    if not e.attrib and not children:
        return text if text else {}
    obj = {}
    if text or any((c.tail or "").strip() for c in children):
        tails = [text] if text else []
        tails.extend((c.tail or "").strip() for c in children if (c.tail or "").strip())
        obj["#text"] = "\n".join(tails)
    for k, v in e.attrib.items():
        obj["@" + k] = v
    for c in children:
        val = xml_to_obj(c)
        if c.tag in obj:
            if not isinstance(obj[c.tag], list):
                obj[c.tag] = [obj[c.tag]]
            obj[c.tag].append(val)
        else:
            obj[c.tag] = val
    return obj


def select_xml(root, expr):
    attr = None
    if "/@" in expr:
        expr, attr = expr.rsplit("/@", 1)
    if expr.startswith("//"):
        nodes = root.findall(".//" + expr[2:])
        if root.tag == expr[2:]:
            nodes.insert(0, root)
    elif expr.startswith("/"):
        parts = [p for p in expr.split("/") if p]
        nodes = [root]
        if parts and parts[0] == root.tag:
            parts = parts[1:]
        for p in parts:
            nxt = []
            for n in nodes:
                nxt.extend([c for c in list(n) if c.tag == p])
            nodes = nxt
    else:
        nodes = root.findall(expr)
    return nodes, attr


class HNode:
    def __init__(self, tag, attrs=None, parent=None):
        self.tag = tag
        self.attrs = dict(attrs or [])
        self.parent = parent
        self.children = []
        self.texts = []


class TreeHTMLParser(HTMLParser):
    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.root = HNode("__root__")
        self.stack = [self.root]

    def handle_starttag(self, tag, attrs):
        n = HNode(tag, attrs, self.stack[-1])
        self.stack[-1].children.append(n)
        if tag not in VOID_HTML:
            self.stack.append(n)

    def handle_startendtag(self, tag, attrs):
        self.stack[-1].children.append(HNode(tag, attrs, self.stack[-1]))

    def handle_endtag(self, tag):
        for i in range(len(self.stack) - 1, 0, -1):
            if self.stack[i].tag == tag:
                del self.stack[i:]
                break

    def handle_data(self, data):
        if data.strip():
            self.stack[-1].texts.append(data.strip())


def parse_html(data):
    p = TreeHTMLParser()
    p.feed(data)
    return p.root


def html_text(n):
    parts = list(n.texts)
    for c in n.children:
        t = html_text(c)
        if t:
            parts.append(t)
    return " ".join(parts)


def html_node(n, args, level=0):
    ind = unit(args, level)
    attrs = attrs_str(n.attrs)
    if n.tag in VOID_HTML and not n.children and not n.texts:
        return f"{ind}<{n.tag}{attrs}/>\n"
    if not n.children and len(n.texts) <= 1:
        return f"{ind}<{n.tag}{attrs}>{html.escape(n.texts[0]) if n.texts else ''}</{n.tag}>\n"
    out = f"{ind}<{n.tag}{attrs}>"
    if n.texts:
        out += html.escape(n.texts[0])
    out += "\n"
    for c in n.children:
        out += html_node(c, args, level + 1)
    out += f"{ind}</{n.tag}>\n"
    return out


def format_html(data, args):
    root = parse_html(data)
    return "".join(html_node(c, args) for c in root.children)


def descendants(n):
    out = []
    for c in n.children:
        out.append(c)
        out.extend(descendants(c))
    return out


def match_simple(n, sel):
    if not sel:
        return False
    tag = None
    cls = None
    ident = None
    if sel.startswith("#"):
        ident = sel[1:]
    elif sel.startswith("."):
        cls = sel[1:]
    elif "#" in sel:
        tag, ident = sel.split("#", 1)
    elif "." in sel:
        tag, cls = sel.split(".", 1)
    else:
        tag = sel
    if tag and n.tag != tag:
        return False
    if ident and n.attrs.get("id") != ident:
        return False
    if cls and cls not in n.attrs.get("class", "").split():
        return False
    return True


def select_html(root, selector):
    parts = [p.strip() for p in selector.split(">")]
    current = [root]
    for idx, part in enumerate(parts):
        found = []
        for n in current:
            pool = n.children if idx > 0 else descendants(n)
            found.extend(c for c in pool if match_simple(c, part))
        current = found
    return current


def output_extraction(nodes, attr, node_mode, is_html, args):
    out = []
    for n in nodes:
        if attr:
            if attr in n.attrib if not is_html else attr in n.attrs:
                out.append((n.attrib if not is_html else n.attrs)[attr])
        elif node_mode:
            out.append((html_node(n, args, 0).rstrip("\n") if is_html else ET.tostring(n, encoding="unicode", short_empty_elements=True)))
        else:
            out.append(html_text(n) if is_html else elem_text(n))
    return "".join(v + "\n" for v in out if v != "")


def main(argv):
    args = parse_args(argv)
    data = read_input(args)
    try:
        if args.json:
            root = ET.fromstring(data)
            obj = {root.tag: xml_to_obj(root)}
            if args.compact:
                return json.dumps(obj, separators=(",", ": ")) + "\n"
            return json.dumps(obj, indent=2) + "\n"
        if args.xpath or args.extract:
            root = ET.fromstring(data)
            nodes, attr = select_xml(root, args.xpath or args.extract)
            if args.extract and nodes:
                nodes = nodes[:1]
            result = output_extraction(nodes, attr, args.node, False, args)
        elif args.query:
            root = parse_html(data)
            nodes = select_html(root, args.query)
            result = output_extraction(nodes, args.attr or None, args.node, True, args)
        else:
            result = format_html(data, args) if args.html else format_xml(data, args)
        if args.in_place and args.file:
            with open(args.file, "w", encoding="utf-8") as f:
                f.write(result)
            return ""
        return result
    except Exception as e:
        print(f"Error: {e}", file=sys.stderr)
        raise SystemExit(1)


if __name__ == "__main__":
    sys.stdout.write(main(sys.argv[1:]))
