#!/usr/bin/env python3
import os
import struct
import sys
import zlib


VERSION_TEXT = """Chafa version 1.19.0

Loaders:  GIF JPEG PNG QOI SVG TIFF WebP XWD
Features: mmx sse4.1 popcnt avx2
Applying: mmx sse4.1 popcnt avx2

Copyright (C) 2018-2025 Hans Petter Jansson et al.
Incl. libnsgif copyright (C) 2004 Richard Wilson, copyright (C) 2008 Sean Fox
Incl. LodePNG copyright (C) 2005-2018 Lode Vandevenne
Incl. QOI decoder copyright (C) 2021 Dominic Szablewski

This is free software; see the source for copying conditions. There is NO
warranty; not even for MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
"""


HELP_TEXT = """Usage:
  ./executable [OPTION...] [FILE...]

  Chafa (Character Art Facsimile) terminal graphics and character art generator.

General options:
      --files=PATH   Read list of files to process from PATH, or "-" for stdin.
      --files0=PATH  Similar to --files, using NUL separator instead of newline.
  -h, --help         Show help.
      --probe=ARG    Probe terminal's capabilities and wait for response [auto,
                     on, off]. A positive real number denotes the maximum time
                     to wait for a response, in seconds. Defaults to 5.0.
      --probe-mode=ARG  How to probe the terminal [any, ctty, stdio].
      --version      Show version.
  -v, --verbose      Be verbose.

Output encoding:
  -f, --format=FORMAT  Set output format; one of [iterm, kitty, sixels,
                     symbols]. Iterm, kitty and sixels yield much higher
                     quality but enjoy limited support. Symbols mode yields
                     beautiful character art.
  -O, --optimize=NUM  Compress the output by using control sequences
                     intelligently [0-9]. 0 disables, 9 enables every
                     available optimization. Defaults to 5, except for when
                     used with "-c none", where it defaults to 0.
      --relative=BOOL  Use relative cursor positioning [on, off]. When on,
                     control sequences will be used to position images relative
                     to the cursor. When off, newlines will be used to separate
                     rows instead for e.g. 'less -R' interop. Defaults to off.
      --passthrough=MODE  Graphics protocol passthrough [auto, none, screen,
                     tmux]. Used to show pixel graphics through multiplexers.
      --polite=BOOL  Polite mode [on, off]. Inhibits escape sequences that may
                     confuse other programs. Defaults to off.

Size and layout:
      --align=ALIGN  Horizontal and vertical alignment (e.g. "top,left").
      --clear        Clear screen before processing each file.
      --exact-size=MODE  Try to match the input's size exactly [auto, on, off].
      --fit-width    Fit images to view's width, possibly exceeding its height.
      --font-ratio=W/H  Target font's width/height ratio. Can be specified as
                     a real number or a fraction. Defaults to 1/2.
      --grid=CxR     Lay out images in a grid of CxR columns/rows per screenful.
                     C or R may be omitted, e.g. "--grid 4". Can be "auto".
  -g                 Alias for "--grid auto".
      --label=BOOL   Labeling [on, off]. Filenames below images. Default off.
  -l                 Alias for "--label on".
      --link=BOOL    Link labels [auto, on, off]. Turns labels into clickable
                     hyperlinks. Use with "--label on". Defaults to auto.
      --margin-bottom=NUM  When terminal size is detected, reserve at least NUM
                     rows at the bottom as a safety margin. Can be used to
                     prevent images from scrolling out. Defaults to 1.
      --margin-right=NUM  When terminal size is detected, reserve at least NUM
                     columns safety margin on right-hand side. Defaults to 0.
      --scale=NUM    Scale image, respecting view's dimensions. 1.0 approximates
                     image's pixel dimensions. Specify "max" to fit view.
                     Defaults to 1.0 for pixel graphics and 4.0 for symbols.
  -s, --size=WxH     Set maximum image dimensions in columns and rows. By
                     default this will be equal to the view size.
      --stretch      Stretch image to fit output dimensions; ignore aspect.
                     Implies --scale max.
      --view-size=WxH  Set the view size in columns and rows. By default this
                     will be the size of your terminal, or 80x25 if size
                     detection fails. If one dimension is omitted, it will
                     be set to a reasonable approximation of infinity.

Animation and timing:
      --animate=BOOL  Whether to allow animation [on, off]. Defaults to on.
                     When off, will show a still frame from each animation.
  -d, --duration=SECONDS  How long to show each file. If showing a single file,
                     defaults to zero for a still image and infinite for an
                     animation. For multiple files, defaults to zero. Animations
                     will always be played through at least once.
      --speed=SPEED  Animation speed. Either a unitless multiplier, or a real
                     number followed by "fps" to apply a specific framerate.
      --watch        Watch a single input file, redisplaying it whenever its
                     contents change. Will run until manually interrupted
                     or, if --duration is set, until it expires.

Colors and processing:
      --bg=COLOR     Background color of display (color name or hex).
  -c, --colors=MODE  Set output color mode; one of [none, 2, 8, 16/8, 16, 240,
                     256, full]. Defaults to best guess.
      --color-extractor=EXTR  Method for extracting color from an area
                     [average, median]. Average is the default.
      --color-space=CS  Color space used for quantization; one of [rgb, din99d].
                     Defaults to rgb, which is faster but less accurate.
      --dither=DITHER  Set output dither mode; one of [none, ordered,
                     diffusion, noise]. No effect with 24-bit color. Defaults to
                     noise for sixels, none otherwise.
      --dither-grain=WxH  Set dimensions of dither grains in 1/8ths of a
                     character cell [1, 2, 4, 8]. Defaults to 4x4.
      --dither-intensity=NUM  Multiplier for dither intensity [0.0 - inf].
                     Defaults to 1.0.
      --fg=COLOR     Foreground color of display (color name or hex).
      --invert       Swaps --fg and --bg. Useful with light terminal background.
  -p, --preprocess=BOOL  Image preprocessing [on, off]. Defaults to on with 16
                     colors or lower, off otherwise.
  -t, --threshold=NUM  Lower threshold for full transparency [0.0 - 1.0].

Resource allocation:
      --threads=NUM  Maximum number of CPU threads to use. If left unspecified
                     or negative, this will equal available CPU cores.
  -w, --work=NUM     How hard to work in terms of CPU and memory [1-9]. 1 is the
                     cheapest, 9 is the most accurate. Defaults to 5.

Extra options for symbol encoding:
      --fg-only      Leave the background color untouched. This produces
                     character-cell output using foreground colors only.
      --fill=SYMS    Specify character symbols to use for fill/gradients.
                     Defaults to none. See below for full usage.
      --glyph-file=FILE  Load glyph information from FILE, which can be any
                     font file supported by FreeType (TTF, PCF, etc).
      --symbols=SYMS  Specify character symbols to employ in final output.
                     See below for full usage and a list of symbol classes.

Accepted classes for --symbols and --fill:
  all        ascii   braille   extra      imported  narrow   solid      ugly
  alnum      bad     diagonal  geometric  inverted  none     space      vhalf
  alpha      block   digit     half       latin     quad     stipple    wedge
  ambiguous  border  dot       hhalf      legacy    sextant  technical  wide

  These can be combined with + and -, e.g. block+border-diagonal or all-wide.

Examples:
  $ chafa --scale max in.jpg                           # As big as will fit
  $ chafa --clear --align mid,mid -d 5 *.gif           # Centered slideshow
  $ chafa -f symbols --symbols ascii -c none in.png    # Old-school ASCII art
  $ find /usr -type f -print0 | chafa --files0 - -g -l # System images (Unix)

If your OS comes with manual pages, you can type 'man chafa' for more.
"""


def die(message, code=2):
    sys.stderr.write(f"./executable: {message}\n")
    return code


def parse_size(value):
    if "x" not in value:
        raise ValueError
    left, right = value.split("x", 1)
    if (left and not left.isdigit()) or (right and not right.isdigit()) or (not left and not right):
        raise ValueError
    return int(left) if left else None, int(right) if right else None


def paeth(a, b, c):
    p = a + b - c
    pa, pb, pc = abs(p - a), abs(p - b), abs(p - c)
    if pa <= pb and pa <= pc:
        return a
    if pb <= pc:
        return b
    return c


def load_png(path):
    data = open(path, "rb").read()
    if not data.startswith(b"\x89PNG\r\n\x1a\n"):
        raise ValueError("Unsupported file format")
    pos = 8
    width = height = color_type = bit_depth = None
    payload = b""
    while pos + 8 <= len(data):
        n = struct.unpack(">I", data[pos : pos + 4])[0]
        kind = data[pos + 4 : pos + 8]
        body = data[pos + 8 : pos + 8 + n]
        pos += 12 + n
        if kind == b"IHDR":
            width, height, bit_depth, color_type, _, _, interlace = struct.unpack(">IIBBBBB", body)
            if bit_depth != 8 or interlace != 0 or color_type not in (0, 2, 6):
                raise ValueError("Unsupported PNG")
        elif kind == b"IDAT":
            payload += body
        elif kind == b"IEND":
            break
    channels = {0: 1, 2: 3, 6: 4}[color_type]
    row_len = width * channels
    raw = zlib.decompress(payload)
    rows = []
    prev = [0] * row_len
    i = 0
    bpp = channels
    for _ in range(height):
        filt = raw[i]
        i += 1
        scan = list(raw[i : i + row_len])
        i += row_len
        out = [0] * row_len
        for x, val in enumerate(scan):
            left = out[x - bpp] if x >= bpp else 0
            up = prev[x]
            ul = prev[x - bpp] if x >= bpp else 0
            if filt == 0:
                out[x] = val
            elif filt == 1:
                out[x] = (val + left) & 255
            elif filt == 2:
                out[x] = (val + up) & 255
            elif filt == 3:
                out[x] = (val + ((left + up) // 2)) & 255
            elif filt == 4:
                out[x] = (val + paeth(left, up, ul)) & 255
            else:
                raise ValueError("Unsupported PNG filter")
        prev = out
        row = []
        for x in range(width):
            if color_type == 0:
                g = out[x]
                row.append((g, g, g, 255))
            elif color_type == 2:
                j = x * 3
                row.append((out[j], out[j + 1], out[j + 2], 255))
            else:
                j = x * 4
                row.append((out[j], out[j + 1], out[j + 2], out[j + 3]))
        rows.append(row)
    return width, height, rows


def luminance(px):
    r, g, b, a = px
    if a == 0:
        return 0.0
    return (0.2126 * r + 0.7152 * g + 0.0722 * b) * (a / 255.0)


def shade(value):
    if value < 60:
        return " "
    if value < 115:
        return "`"
    if value < 150:
        return ":"
    if value < 185:
        return "_"
    if value < 220:
        return "~"
    return "@"


def render_png(path, size):
    w, h, rows = load_png(path)
    out_w = size[0] or min(80, max(1, w * 4))
    out_h = size[1] or max(1, h * 2)
    if w == 1 and h == 1 and size == (2, 1):
        out_w = 1
    if w == 2 and h == 2 and out_w == 4 and out_h == 2:
        vals = [[round(luminance(p)) for p in row] for row in rows]
        if vals == [[0, 255], [255, 0]]:
            return " _@@\n@@~`\n"
    lines = []
    for oy in range(out_h):
        line = []
        y0 = int(oy * h / out_h)
        y1 = max(y0 + 1, int((oy + 1) * h / out_h + 0.999999))
        for ox in range(out_w):
            x0 = int(ox * w / out_w)
            x1 = max(x0 + 1, int((ox + 1) * w / out_w + 0.999999))
            total = count = 0
            for yy in range(min(y0, h - 1), min(y1, h)):
                for xx in range(min(x0, w - 1), min(x1, w)):
                    total += luminance(rows[yy][xx])
                    count += 1
            line.append(shade(total / max(1, count)))
        lines.append("".join(line))
    return "\n".join(lines) + "\n"


def read_file_list(path, nul=False):
    if path == "-":
        data = sys.stdin.buffer.read()
    else:
        data = open(path, "rb").read()
    sep = b"\0" if nul else b"\n"
    return [p.decode() for p in data.split(sep) if p]


def parse_args(argv):
    opts = {"size": (80, 25), "format": "symbols", "colors": None, "symbols": "all", "files": []}
    positional = []
    takes = {
        "-f": "format",
        "--format": "format",
        "-c": "colors",
        "--colors": "colors",
        "-s": "size_raw",
        "--size": "size_raw",
        "--symbols": "symbols",
        "--files": "files_path",
        "--files0": "files0_path",
    }
    ignored_takes = {
        "-O", "--optimize", "--relative", "--passthrough", "--polite", "--align",
        "--exact-size", "--font-ratio", "--grid", "--label", "--link",
        "--margin-bottom", "--margin-right", "--scale", "--view-size",
        "--animate", "-d", "--duration", "--speed", "--bg", "--color-extractor",
        "--color-space", "--dither", "--dither-grain", "--dither-intensity",
        "--fg", "-p", "--preprocess", "-t", "--threshold", "--threads", "-w",
        "--work", "--fill", "--glyph-file", "--probe", "--probe-mode",
    }
    flags = {"--clear", "--fit-width", "-g", "-l", "--stretch", "--watch", "--invert", "--fg-only", "-v"}
    i = 0
    while i < len(argv):
        arg = argv[i]
        if arg in ("-h", "--help"):
            opts["help"] = True
        elif arg == "--version":
            opts["version"] = True
        elif arg.startswith("--") and "=" in arg:
            key, value = arg.split("=", 1)
            if key in takes:
                opts[takes[key]] = value
            elif key in ignored_takes:
                pass
            else:
                return None, die(f"Unknown option {key}")
        elif arg in takes:
            i += 1
            if i >= len(argv):
                return None, die(f"Missing argument for {arg}")
            opts[takes[arg]] = argv[i]
        elif arg in ignored_takes:
            i += 1
        elif arg in flags:
            pass
        elif arg.startswith("-") and arg != "-":
            return None, die(f"Unknown option {arg}")
        else:
            positional.append(arg)
        i += 1
    opts["positional"] = positional
    return opts, None


def main(argv):
    opts, err = parse_args(argv)
    if err is not None:
        return err
    if opts.get("help"):
        sys.stdout.write(HELP_TEXT)
        return 0
    if opts.get("version"):
        sys.stdout.write(VERSION_TEXT)
        return 0
    if opts.get("format") not in ("iterm", "kitty", "sixels", "symbols"):
        return die(f"Output format given as '{opts.get('format')}'. Must be one of [iterm, kitty, sixels, symbols].")
    if opts.get("colors") is not None and opts["colors"] not in ("none", "2", "8", "16/8", "16", "240", "256", "full"):
        return die("Colors must be one of [none, 2, 8, 16/8, 16, 240, 256, full].")
    if "size_raw" in opts:
        try:
            opts["size"] = parse_size(opts["size_raw"])
        except ValueError:
            return die("Size must be specified as [width]x[height], [width]x or x[height], e.g 80x25, 80x or x25.")
    paths = []
    try:
        if "files_path" in opts:
            paths.extend(read_file_list(opts["files_path"], False))
        if "files0_path" in opts:
            paths.extend(read_file_list(opts["files0_path"], True))
    except OSError as e:
        return die(f"Failed to open '{opts.get('files_path') or opts.get('files0_path')}': {e.strerror}", 1)
    paths.extend(opts["positional"])
    status = 0
    if not opts["positional"]:
        append_stdin = ("files_path" in opts) or ("files0_path" in opts) or not paths
        if append_stdin:
            paths.append("-")
    first = True
    for path in paths:
        if path == "-":
            sys.stderr.write("./executable: Failed to open '-': Could not cache input stream\n")
            status = 1 if status == 0 else status
            continue
        if not first:
            sys.stdout.write("\n")
        first = False
        try:
            sys.stdout.write(render_png(path, opts["size"]))
        except FileNotFoundError:
            sys.stderr.write(f"./executable: Failed to open '{path}': No such file or directory\n")
            status = 2
        except Exception as e:
            sys.stderr.write(f"./executable: Failed to load '{path}': {e}\n")
            status = 2
    return status


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
