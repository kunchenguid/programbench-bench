import os
import stat
import subprocess
import sys
import unittest


ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
PROGRAM = os.path.join(ROOT, "src", "tig.py")


def run_tig(*args, stdin=""):
    return subprocess.run(
        [sys.executable, PROGRAM, *args],
        input=stdin,
        text=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        cwd=ROOT,
    )


class TigCliTests(unittest.TestCase):
    def test_version_prints_tig_and_ncurses_versions(self):
        result = run_tig("--version")
        self.assertEqual(result.returncode, 0)
        self.assertEqual(
            result.stdout,
            "tig version 2.6.0-g87c9c25\n"
            "ncursesw version 6.3.20211021\n",
        )
        self.assertEqual(result.stderr, "")

    def test_help_prints_usage_and_options(self):
        result = run_tig("--help")
        self.assertEqual(result.returncode, 0)
        self.assertEqual(result.stderr, "")
        self.assertEqual(
            result.stdout,
            "tig 2.6.0-g87c9c25 \n"
            "\n"
            "Usage: tig        [options] [revs] [--] [paths]\n"
            "   or: tig log    [options] [revs] [--] [paths]\n"
            "   or: tig show   [options] [revs] [--] [paths]\n"
            "   or: tig reflog [options] [revs]\n"
            "   or: tig blame  [options] [rev] [--] path\n"
            "   or: tig grep   [options] [pattern]\n"
            "   or: tig refs   [options]\n"
            "   or: tig stash  [options]\n"
            "   or: tig status\n"
            "   or: tig <      [git command output]\n"
            "\n"
            "Options:\n"
            "  +<number>       Select line <number> in the first view\n"
            "  -v, --version   Show version and exit\n"
            "  -h, --help      Show help message and exit\n"
            "  -C <path>       Start in <path>\n",
        )

    def test_interactive_commands_fail_without_tty(self):
        for args in ((), ("log",), ("show",), ("status",), ("--unknown",)):
            with self.subTest(args=args):
                result = run_tig(*args)
                self.assertEqual(result.returncode, 1)
                self.assertEqual(result.stdout, "")
                self.assertEqual(result.stderr, "tig: Failed to open tty for input\n")

    def test_c_option_changes_directory_before_handling_other_options(self):
        result = run_tig("-C", "/no/such", "--version")
        self.assertEqual(result.returncode, 1)
        self.assertEqual(result.stdout, "")
        self.assertEqual(result.stderr, "tig: Failed to change directory to /no/such\n")

    def test_unknown_revision_reports_no_matching_revisions(self):
        for args in (("foo",), ("log", "foo"), ("show", "foo"), ("+x",)):
            with self.subTest(args=args):
                result = run_tig(*args)
                self.assertEqual(result.returncode, 1)
                self.assertEqual(result.stdout, "")
                self.assertEqual(result.stderr, "tig: No revisions match the given arguments.\n")

    def test_compile_script_creates_runnable_executable(self):
        compile_script = os.path.join(ROOT, "compile.sh")
        output = os.path.join(ROOT, "executable")
        if os.path.exists(output):
            os.unlink(output)
        result = subprocess.run(
            ["bash", compile_script],
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
            cwd=ROOT,
        )
        self.assertEqual(result.returncode, 0, result.stderr)
        mode = os.stat(output).st_mode
        self.assertTrue(mode & stat.S_IXUSR)
        version = subprocess.run(
            [output, "--version"],
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
            cwd=ROOT,
        )
        self.assertEqual(version.returncode, 0)
        self.assertIn("tig version 2.6.0-g87c9c25\n", version.stdout)


if __name__ == "__main__":
    unittest.main()
