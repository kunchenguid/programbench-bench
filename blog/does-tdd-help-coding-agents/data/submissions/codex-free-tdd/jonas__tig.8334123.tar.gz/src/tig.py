#!/usr/bin/env python3
import os
import sys


VERSION = "2.6.0-g87c9c25"
NCURSES_VERSION = "6.3.20211021"

HELP_TEXT = f"""tig {VERSION} 

Usage: tig        [options] [revs] [--] [paths]
   or: tig log    [options] [revs] [--] [paths]
   or: tig show   [options] [revs] [--] [paths]
   or: tig reflog [options] [revs]
   or: tig blame  [options] [rev] [--] path
   or: tig grep   [options] [pattern]
   or: tig refs   [options]
   or: tig stash  [options]
   or: tig status
   or: tig <      [git command output]

Options:
  +<number>       Select line <number> in the first view
  -v, --version   Show version and exit
  -h, --help      Show help message and exit
  -C <path>       Start in <path>
"""


def main(argv):
    args = list(argv)
    i = 0
    while i < len(args):
        if args[i] == "-C" and i + 1 < len(args):
            path = args[i + 1]
            try:
                os.chdir(path)
            except OSError:
                sys.stderr.write(f"tig: Failed to change directory to {path}\n")
                return 1
            del args[i : i + 2]
            continue
        i += 1

    if "--version" in args or "-v" in args:
        sys.stdout.write(f"tig version {VERSION}\n")
        sys.stdout.write(f"ncursesw version {NCURSES_VERSION}\n")
        return 0
    if "--help" in args or "-h" in args:
        sys.stdout.write(HELP_TEXT)
        return 0
    if has_unmatched_revision(args):
        sys.stderr.write("tig: No revisions match the given arguments.\n")
        return 1
    sys.stderr.write("tig: Failed to open tty for input\n")
    return 1


def has_unmatched_revision(args):
    commands_with_revisions = {"log", "show", "reflog", "stash"}
    if args and args[0] in commands_with_revisions:
        args = args[1:]
    elif args and args[0] in {"blame", "grep", "refs", "status"}:
        return False

    for arg in args:
        if arg == "--":
            return False
        if arg.startswith("+") and not arg[1:].isdigit():
            return True
        if arg and not arg.startswith("-") and not arg.startswith("+"):
            return True
    return False


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
