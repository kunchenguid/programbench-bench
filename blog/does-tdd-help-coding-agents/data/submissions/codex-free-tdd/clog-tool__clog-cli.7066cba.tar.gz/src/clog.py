#!/usr/bin/env python3
import argparse
import json
import os
import re
import subprocess
import sys
import time
from datetime import date
from pathlib import Path


VERSION = "0.10.0"

SECTION_ORDER = [
    ("Breaking Changes", {"breaking"}),
    ("Features", {"feat", "feature"}),
    ("Bug Fixes", {"fix", "bugfix"}),
    ("Documentation", {"doc", "docs"}),
    ("Style Fixes", {"style"}),
    ("Improvements", {"perf", "performance", "refactor"}),
    ("Tests", {"test", "tests"}),
]


HELP = """a conventional changelog for the rest of us

Usage: executable [OPTIONS]

Options:
  -r, --repository <URL>  Repository used for generating commit and issue links (without the .git,
                          e.g. https://github.com/thoughtram/clog)
  -f, --from <COMMIT>     e.g. 12a8546
  -T, --format <STR>      The output format, defaults to markdown [default: markdown] [possible
                          values: markdown, json]
  -M, --major             Increment major version by one (Sets minor and patch to 0)
  -g, --git-dir <PATH>    Local .git directory (defaults to "$(pwd)/.git")
  -w, --work-tree <PATH>  Local working tree of the git project (defaults to "$(pwd)")
  -m, --minor             Increment minor version by one (Sets patch to 0)
  -p, --patch             Increment patch version by one
  -s, --subtitle <STR>    
  -t, --to <COMMIT>       e.g. 8057684 [default: HEAD]
  -o, --outfile <PATH>    Where to write the changelog (Defaults to stdout when omitted)
  -c, --config <COMMIT>   The Clog Configuration TOML file to use [default: .clog.toml]
  -i, --infile <PATH>     A changelog to append to, but *NOT* write to (Useful in conjunction with
                          --outfile)
      --setversion <VER>  e.g. 1.0.1
  -F, --from-latest-tag   use latest tag as start (instead of --from)
  -l, --link-style <STR>  The style of repository link to generate [default: github] [possible
                          values: github, gitlab, stash, cgit]
  -C, --changelog <PATH>  A previous changelog to prepend new changes to (this is like using the
                          same file for both --infile and --outfile and should not be used in
                          conjunction with either)
  -h, --help              Print help
  -V, --version           Print version


If your .git directory is a child of your project directory (most common, such as /myproject/.git)
AND not in the current working directory (i.e you need to use --work-tree or --git-dir) you only
need to specify either the --work-tree (i.e. /myproject) OR --git-dir (i.e. /myproject/.git), you
don't need to use both.

If using the --config to specify a clog configuration TOML file NOT in the current working directory
(meaning you need to use --work-tree or --git-dir) AND the TOML file is inside your project
directory (i.e. /myproject/.clog.toml) you do not need to use --work-tree or --git-dir.
"""


def parse_args(argv):
    parser = argparse.ArgumentParser(add_help=False)
    parser.add_argument("-h", "--help", action="store_true")
    parser.add_argument("-V", "--version", action="store_true")
    parser.add_argument("-r", "--repository")
    parser.add_argument("-f", "--from", dest="from_rev")
    parser.add_argument("-T", "--format", default=None, choices=["markdown", "json"])
    parser.add_argument("-M", "--major", action="store_true")
    parser.add_argument("-m", "--minor", action="store_true")
    parser.add_argument("-p", "--patch", action="store_true")
    parser.add_argument("-g", "--git-dir")
    parser.add_argument("-w", "--work-tree")
    parser.add_argument("-s", "--subtitle")
    parser.add_argument("-t", "--to", dest="to_rev", default=None)
    parser.add_argument("-o", "--outfile")
    parser.add_argument("-c", "--config", default=".clog.toml")
    parser.add_argument("-i", "--infile")
    parser.add_argument("--setversion")
    parser.add_argument("-F", "--from-latest-tag", action="store_true")
    parser.add_argument("-l", "--link-style", default=None)
    parser.add_argument("-C", "--changelog")
    return parser.parse_args(argv)


def read_config(path):
    config = {}
    sections = {}
    current = None
    p = Path(path)
    if not p.exists():
        return config, sections
    for raw in p.read_text(encoding="utf-8").splitlines():
        line = raw.split("#", 1)[0].strip()
        if not line:
            continue
        if line.startswith("[") and line.endswith("]"):
            current = line[1:-1].strip()
            continue
        if "=" not in line:
            continue
        key, value = [part.strip() for part in line.split("=", 1)]
        value = value.strip()
        if value.startswith('"') and value.endswith('"'):
            parsed = value[1:-1]
        elif value.lower() in {"true", "false"}:
            parsed = value.lower() == "true"
        elif value.startswith("[") and value.endswith("]"):
            parsed = [x.strip().strip('"') for x in value[1:-1].split(",") if x.strip()]
        else:
            parsed = value
        if current == "sections":
            sections[key.strip('"')] = parsed if isinstance(parsed, list) else [str(parsed)]
        elif current in {None, "clog"}:
            config[key] = parsed
    return config, sections


def git(repo, args, allow_fail=False, strip=True):
    proc = subprocess.run(["git", *args], cwd=repo, text=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    if proc.returncode != 0 and not allow_fail:
        raise RuntimeError(proc.stderr.strip() or "git command failed")
    return proc.stdout.strip() if strip else proc.stdout


def resolve_repo(args, config):
    if args.work_tree:
        return Path(args.work_tree)
    if args.git_dir:
        gd = Path(args.git_dir)
        return gd.parent if gd.name == ".git" else Path.cwd()
    return Path.cwd()


def latest_tag(repo):
    out = git(repo, ["describe", "--tags", "--abbrev=0"], allow_fail=True)
    return out or None


def version_from_text(text):
    match = re.search(r'<a name="v?([0-9]+\.[0-9]+\.[0-9]+)"></a>', text)
    if match:
        return match.group(1)
    match = re.search(r"\bv?([0-9]+\.[0-9]+\.[0-9]+)\b", text)
    return match.group(1) if match else ""


def base_version(repo, infile):
    if infile and Path(infile).exists():
        found = version_from_text(Path(infile).read_text(encoding="utf-8"))
        if found:
            return found
    tag = latest_tag(repo)
    if tag:
        return tag.lstrip("v")
    return ""


def bump_version(version, major=False, minor=False, patch=False):
    if not (major or minor or patch):
        return version
    m = re.fullmatch(r"v?([0-9]+)\.([0-9]+)\.([0-9]+)", version or "")
    if not m:
        print("\033[1;31merror:\033[0m Failed to parse version into valid SemVer. Ensure the version is in the X.Y.Z format.", file=sys.stderr)
        sys.exit(1)
    a, b, c = map(int, m.groups())
    if major:
        return f"{a + 1}.0.0"
    if minor:
        return f"{a}.{b + 1}.0"
    return f"{a}.{b}.{c + 1}"


def commit_range(repo, args, config):
    to_rev = args.to_rev or "HEAD"
    start = None
    if args.from_rev:
        start = args.from_rev
    elif args.from_latest_tag or config.get("from-latest-tag"):
        start = latest_tag(repo)
    if start:
        return f"{start}..{to_rev}"
    return to_rev


COMMIT_RE = re.compile(r"^(?P<typ>[A-Za-z]+)(?:\((?P<scope>[^)]*)\))?(?P<bang>!)?:\s*(?P<subject>.+)$")


def parse_commit(raw):
    _sha, full_sha, subject, body = raw.split("\x1f", 3)
    sha = full_sha[:8]
    m = COMMIT_RE.match(subject.strip())
    if not m:
        return None
    typ = m.group("typ").lower()
    breaking = bool(m.group("bang")) or "BREAKING CHANGE" in body.upper()
    closes = []
    for issue in re.findall(r"(?i)(?:close[sd]?|fix(?:e[sd])?|resolve[sd]?)\s+#([0-9]+)", body):
        closes.append(issue)
    return {
        "type": "breaking" if breaking else typ,
        "raw_type": typ,
        "scope": m.group("scope") or "",
        "subject": m.group("subject").strip(),
        "sha": sha,
        "full_sha": full_sha,
        "closes": closes,
    }


def section_map(custom):
    mapping = []
    for title, aliases in custom.items():
        mapping.append((title, {a.lower() for a in aliases}))
    mapping.extend(SECTION_ORDER)
    return mapping


def collect_commits(repo, args, config, custom_sections):
    rng = commit_range(repo, args, config)
    fmt = "%h%x1f%H%x1f%s%x1f%b%x1e"
    out = git(repo, ["log", "--reverse", f"--format={fmt}", rng], allow_fail=True, strip=False)
    commits = []
    for entry in out.split("\x1e"):
        entry = entry.strip("\n")
        if not entry:
            continue
        try:
            parsed = parse_commit(entry)
        except ValueError:
            continue
        if parsed:
            commits.append(parsed)
    grouped = []
    used = set()
    for title, aliases in section_map(custom_sections):
        bucket = []
        for idx, commit in enumerate(commits):
            if idx in used:
                continue
            if commit["type"] in aliases or commit["raw_type"] in aliases:
                bucket.append(commit)
                used.add(idx)
        if bucket:
            grouped.append({"title": title, "commits": bucket})
    return grouped


def link_for(repo_url, style, commit):
    if not repo_url:
        return commit["sha"]
    repo_url = repo_url[:-4] if repo_url.endswith(".git") else repo_url
    if style == "cgit":
        return f"{repo_url}/commit/?id={commit['full_sha']}"
    if style == "stash":
        return f"{repo_url}/commits/{commit['full_sha']}"
    return f"{repo_url}/commit/{commit['sha']}"


def issue_link(repo_url, style, issue):
    if not repo_url:
        return f"#{issue}"
    repo_url = repo_url[:-4] if repo_url.endswith(".git") else repo_url
    if style == "gitlab":
        return f"{repo_url}/issues/{issue}"
    if style == "stash":
        return f"{repo_url}/browse/issue/{issue}"
    return f"{repo_url}/issues/{issue}"


def render_item(commit, repo_url, style):
    text = commit["subject"]
    if commit["scope"]:
        text = f"**{commit['scope']}**: {text}"
    link = link_for(repo_url, style, commit)
    suffix = f"([{commit['sha']}]({link}))" if repo_url else f"({commit['sha']})"
    if commit["closes"]:
        closed = ", ".join(f"closes [#{i}]({issue_link(repo_url, style, i)})" for i in commit["closes"])
        suffix = f"{suffix}, {closed}"
    return f"* {text} {suffix}"


def header(version, subtitle):
    heading = "###" if version and re.match(r"v?[0-9]+\.[0-9]+\.[1-9][0-9]*$", version) else "##"
    title = version or ""
    subtitle_text = f" {subtitle}" if subtitle else ""
    return f'<a name="{title}"></a>\n{heading} {title}{subtitle_text}  ({date.today().isoformat()})\n'


def render_markdown(version, subtitle, sections, repo_url, style):
    out = [header(version, subtitle), "\n"]
    for section in sections:
        out.append(f"\n#### {section['title']}\n\n")
        for commit in section["commits"]:
            out.append(render_item(commit, repo_url, style) + "\n")
    out.append("\n")
    return "".join(out)


def render_json(version, subtitle, sections):
    return json.dumps(
        {
            "header": {
                "version": version or None,
                "patch_version": bool(version and re.match(r"v?[0-9]+\.[0-9]+\.[1-9][0-9]*$", version)),
                "subtitle": subtitle,
                "date": date.today().isoformat(),
            },
            "sections": sections or None,
        },
        separators=(",", ":"),
    ) + "\n"


def main(argv):
    start = time.time()
    args = parse_args(argv)
    if args.help:
        print(HELP)
        return 0
    if args.version:
        print(f"clog {VERSION}")
        return 0

    config, custom_sections = read_config(args.config)
    repo = resolve_repo(args, config)
    infile = args.infile or args.changelog or config.get("changelog")
    version = args.setversion or bump_version(base_version(repo, infile), args.major, args.minor, args.patch)
    fmt = args.format or config.get("format") or "markdown"
    repo_url = args.repository or config.get("repository") or ""
    style = args.link_style or config.get("link-style") or "github"

    try:
        sections = collect_commits(repo, args, config, custom_sections)
    except RuntimeError as exc:
        print(f"\033[1;31merror:\033[0m {exc}", file=sys.stderr)
        return 1

    if fmt == "json":
        rendered = render_json(version, args.subtitle, sections)
    else:
        rendered = render_markdown(version, args.subtitle, sections, repo_url, style)

    if infile and Path(infile).exists() and fmt == "markdown":
        rendered += "\n" + Path(infile).read_text(encoding="utf-8")

    outfile = args.outfile or args.changelog
    if outfile:
        Path(outfile).write_text(rendered, encoding="utf-8")
        elapsed = int((time.time() - start) * 1000)
        print(f"changelog written. (took {elapsed} ms)")
    else:
        print(rendered, end="")
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
