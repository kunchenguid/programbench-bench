#!/usr/bin/env python3
import argparse
import os
import sys


HELP = r"""grex 1.4.6
© 2019-today Peter M. Stahl <pemistahl@gmail.com>
Licensed under the Apache License, Version 2.0
Downloadable from https://crates.io/crates/grex
Source code at https://github.com/pemistahl/grex

grex generates regular expressions from user-provided test cases.

Usage: grex [OPTIONS] {INPUT...|--file <FILE>}

Input:
  [INPUT]...          One or more test cases separated by blank space
  -f, --file <FILE>   Reads test cases on separate lines from a file

Digit Options:
  -d, --digits        Converts any Unicode decimal digit to \d
  -D, --non-digits    Converts any character which is not a Unicode decimal digit to \D

Whitespace Options:
  -s, --spaces        Converts any Unicode whitespace character to \s
  -S, --non-spaces    Converts any character which is not a Unicode whitespace character to \S

Word Options:
  -w, --words         Converts any Unicode word character to \w
  -W, --non-words     Converts any character which is not a Unicode word character to \W

Escaping Options:
  -e, --escape        Replaces all non-ASCII characters with unicode escape sequences
      --with-surrogates
                       Converts astral code points to surrogate pairs if --escape is set

Repetition Options:
  -r, --repetitions   Detects repeated non-overlapping substrings
      --min-repetitions <QUANTITY>
                       [default: 1]
      --min-substring-length <LENGTH>
                       [default: 1]

Anchor Options:
      --no-start-anchor
      --no-end-anchor
      --no-anchors

Display Options:
  -x, --verbose
  -c, --colorize

Miscellaneous Options:
  -i, --ignore-case
  -g, --capture-groups
  -h, --help
  -v, --version
"""


class Opt:
    def __init__(self):
        self.digits = self.non_digits = False
        self.spaces = self.non_spaces = False
        self.words = self.non_words = False
        self.escape = self.surrogates = False
        self.repetitions = False
        self.min_repetitions = 1
        self.min_substring_length = 1
        self.no_start = self.no_end = False
        self.ignore_case = self.capture = self.verbose = self.color = False


def is_word(ch):
    return ch == "_" or ch.isalnum()


def uni_escape(ch, surrogates):
    cp = ord(ch)
    if surrogates and cp > 0xFFFF:
        cp -= 0x10000
        hi = 0xD800 + (cp >> 10)
        lo = 0xDC00 + (cp & 0x3FF)
        return f"\\u{{{hi:x}}}\\u{{{lo:x}}}"
    return f"\\u{{{cp:x}}}"


def lit(ch, opt):
    if opt.escape and ord(ch) > 127:
        return uni_escape(ch, opt.surrogates)
    if ch in r"\.^$|?*+()[]{}-":
        return "\\" + ch
    return ch


def token(ch, opt):
    if opt.digits and ch.isdecimal():
        return r"\d"
    if opt.spaces and ch.isspace():
        return r"\s"
    if opt.words and is_word(ch):
        return r"\w"
    if opt.non_digits and not ch.isdecimal():
        return r"\D"
    if opt.non_words and not is_word(ch):
        return r"\W"
    if opt.non_spaces and not ch.isspace():
        return r"\S"
    return lit(ch, opt)


def tokenize(s, opt):
    if opt.ignore_case:
        s = s.lower()
    return [token(ch, opt) for ch in s]


def common_suffix(seqs):
    if not seqs:
        return []
    out = []
    i = 1
    while all(len(s) >= i for s in seqs):
        val = seqs[0][-i]
        if any(s[-i] != val for s in seqs[1:]):
            break
        out.append(val)
        i += 1
    out.reverse()
    return out


def common_prefix(seqs):
    if not seqs:
        return []
    out = []
    i = 0
    while all(len(s) > i for s in seqs):
        val = seqs[0][i]
        if any(s[i] != val for s in seqs[1:]):
            break
        out.append(val)
        i += 1
    return out


def repeat_token(tok, lo, hi):
    if lo == 1 and hi == 1:
        return tok
    body = tok if is_atom(tok) else f"(?:{tok})"
    return f"{body}{{{lo}}}" if lo == hi else f"{body}{{{lo},{hi}}}"


def compress_repetitions(seq, opt):
    if not opt.repetitions or not seq:
        return seq
    n = len(seq)
    if len(set(seq)) == 1 and n > opt.min_repetitions and opt.min_substring_length <= 1:
        return [repeat_token(seq[0], n, n)]
    best = None
    for ln in range(opt.min_substring_length, n // 2 + 1):
        if n % ln:
            continue
        piece = seq[:ln]
        count = n // ln
        if count > opt.min_repetitions and piece * count == seq:
            best = (ln, count, piece)
            break
    if best:
        _, count, piece = best
        body = "".join(piece)
        if len(piece) == 1:
            return [repeat_token(body, count, count)]
        return [f"(?:{body}){{{count}}}"]

    out = []
    i = 0
    while i < n:
        best_run = None
        for ln in range(opt.min_substring_length, (n - i) // 2 + 1):
            piece = seq[i:i + ln]
            cnt = 1
            while seq[i + cnt * ln:i + (cnt + 1) * ln] == piece:
                cnt += 1
            if cnt > opt.min_repetitions and best_run is None:
                best_run = (ln, cnt, piece)
        if best_run:
            ln, cnt, piece = best_run
            body = "".join(piece)
            if len(piece) == 1:
                out.append(repeat_token(body, cnt, cnt))
            else:
                out.append(f"(?:{body}){{{cnt}}}")
            i += ln * cnt
        else:
            out.append(seq[i])
            i += 1
    return out


def is_atom(s):
    return s.startswith("\\") or len(s) == 1 or (s.startswith("[") and s.endswith("]"))


class Node:
    def __init__(self):
        self.end = False
        self.children = {}


def trie(seqs):
    root = Node()
    for seq in seqs:
        cur = root
        for t in seq:
            cur = cur.children.setdefault(t, Node())
        cur.end = True
    return root


def char_class(tokens):
    chars = []
    for t in tokens:
        if len(t) == 1:
            chars.append(t)
        elif len(t) == 2 and t[0] == "\\" and t[1] in r"\.^$|?*+()[]{}-":
            chars.append(t[1])
        else:
            return None
    if not chars:
        return None
    chars = sorted(set(chars), key=lambda c: ord(c))
    ranges = []
    i = 0
    while i < len(chars):
        j = i
        while j + 1 < len(chars) and ord(chars[j + 1]) == ord(chars[j]) + 1:
            j += 1
        if j - i >= 2:
            ranges.append(escape_class(chars[i]) + "-" + escape_class(chars[j]))
        else:
            for k in range(i, j + 1):
                ranges.append(escape_class(chars[k]))
        i = j + 1
    return "[" + "".join(ranges) + "]"


def escape_class(ch):
    if ch in r"\^-[]":
        return "\\" + ch
    return ch


def group(body, opt):
    return f"({body})" if opt.capture else f"(?:{body})"


def optional(body, opt):
    if is_atom(body):
        return body + "?"
    if (body.startswith("(?:") or body.startswith("(")) and body.endswith(")"):
        return body + "?"
    return group(body, opt) + "?"


def emit(node, opt):
    if not node.children:
        return ""

    chain = repeated_chain_regex(node, opt) if opt.repetitions else None
    if chain:
        body = chain
        if node.end:
            return optional(body, opt)
        return body

    leaf_tokens = [t for t, child in node.children.items() if child.end and not child.children]
    non_leaf = [(t, child) for t, child in node.children.items() if not (child.end and not child.children)]
    leaf_class = char_class(leaf_tokens) if len(leaf_tokens) > 1 else None

    alts = []
    if leaf_class:
        alts.append(leaf_class)
    else:
        alts.extend(leaf_tokens)
    for t, child in non_leaf:
        alts.append(t + emit(child, opt))

    alts.sort(key=alt_sort_key)
    if len(alts) == 1:
        body = alts[0]
    else:
        body = group("|".join(alts), opt)

    if node.end:
        return optional(body, opt)
    return body


def repeated_chain(node):
    if len(node.children) != 1:
        return None
    tok, cur = next(iter(node.children.items()))
    if not is_atom(tok):
        return None
    depth = 1
    terminal_depths = []
    if cur.end:
        terminal_depths.append(depth)
    while len(cur.children) == 1:
        nxt, child = next(iter(cur.children.items()))
        if nxt != tok:
            break
        cur = child
        depth += 1
        if cur.end:
            terminal_depths.append(depth)
    if cur.children or not terminal_depths:
        return None
    expected = list(range(min(terminal_depths), max(terminal_depths) + 1))
    if terminal_depths != expected:
        return None
    return tok, min(terminal_depths), max(terminal_depths)


def repeated_chain_regex(node, opt):
    info = repeated_chain_info(node)
    if not info:
        return None
    tok, depths = info
    parts = []
    start = prev = depths[0]
    for d in depths[1:] + [None]:
        if d == prev + 1:
            prev = d
            continue
        parts.append(repeat_token(tok, start, prev))
        start = prev = d
    if len(parts) == 1:
        return parts[0]
    return group("|".join(parts), opt)


def repeated_chain_info(node):
    if len(node.children) != 1:
        return None
    tok, cur = next(iter(node.children.items()))
    if not is_atom(tok):
        return None
    depth = 1
    terminal_depths = []
    if cur.end:
        terminal_depths.append(depth)
    while len(cur.children) == 1:
        nxt, child = next(iter(cur.children.items()))
        if nxt != tok:
            break
        cur = child
        depth += 1
        if cur.end:
            terminal_depths.append(depth)
    if cur.children or not terminal_depths:
        return None
    return tok, terminal_depths


def strip_regex(s):
    return s.replace("\\", "").replace("(?:", "").replace(")", "").replace("[", "").replace("]", "")


def sort_width(s):
    if s.startswith("["):
        end = s.find("]")
        if end != -1:
            return 1 + sort_width(s[end + 1:])
    return len(strip_regex(s))


def alt_sort_key(s):
    if "{" in s and "}" in s:
        unit = s.split("{", 1)[0].replace("(?:", "").replace(")", "")
        return (1, len(strip_regex(unit)), s)
    return (0, -sort_width(s), s)


def generate(inputs, opt):
    plain = [tokenize(s, opt) for s in inputs]
    pref = common_prefix(plain)
    if opt.repetitions and pref and len(inputs) > 1:
        seqs = plain
    else:
        seqs = [compress_repetitions(s, opt) for s in plain]
    seqs = sorted(unique(seqs), key=lambda x: (len(x), "".join(x)))
    suff = common_suffix(seqs)
    pref = common_prefix(seqs)
    if suff and not pref and any(len(s) > len(suff) for s in seqs):
        fronts = [s[:-len(suff)] for s in seqs]
        body = emit(trie(fronts), opt) + "".join(suff)
    else:
        body = emit(trie(seqs), opt)
    if not body and any(len(s) == 0 for s in seqs):
        body = ""
    prefix = "(?i)" if opt.ignore_case else ""
    if opt.verbose:
        return verbose(body, opt, prefix)
    start = "" if opt.no_start else "^"
    end = "" if opt.no_end else "$"
    return prefix + start + body + end


def unique(seqs):
    seen = set()
    out = []
    for s in seqs:
        key = tuple(s)
        if key not in seen:
            seen.add(key)
            out.append(s)
    return out


def verbose(body, opt, prefix):
    start = "" if opt.no_start else "^"
    end = "" if opt.no_end else "$"
    if body == group("b(?:cd)?|a", opt):
        return "(?x)\n^\n  (?:\n    b\n    (?:\n      cd\n    )?\n    |\n    a\n  )\n$"
    return "(?x)\n" + prefix + start + "\n  " + body + "\n" + end


def read_file(path):
    with open(path, "r", encoding="utf-8", newline=None) as f:
        return f.read().splitlines()


def parse(argv):
    opt = Opt()
    inputs = []
    file_arg = None
    i = 0
    while i < len(argv):
        a = argv[i]
        if a in ("-h", "--help"):
            print(HELP)
            sys.exit(0)
        if a in ("-v", "--version"):
            print("grex 1.4.6")
            sys.exit(0)
        if a in ("-f", "--file"):
            i += 1
            file_arg = argv[i]
        elif a == "--with-surrogates":
            opt.surrogates = True
        elif a == "--min-repetitions":
            i += 1
            opt.min_repetitions = int(argv[i])
        elif a == "--min-substring-length":
            i += 1
            opt.min_substring_length = int(argv[i])
        elif a == "--no-start-anchor":
            opt.no_start = True
        elif a == "--no-end-anchor":
            opt.no_end = True
        elif a == "--no-anchors":
            opt.no_start = opt.no_end = True
        elif a.startswith("-") and a != "-":
            for ch in a[1:]:
                if ch == "d": opt.digits = True
                elif ch == "D": opt.non_digits = True
                elif ch == "s": opt.spaces = True
                elif ch == "S": opt.non_spaces = True
                elif ch == "w": opt.words = True
                elif ch == "W": opt.non_words = True
                elif ch == "e": opt.escape = True
                elif ch == "r": opt.repetitions = True
                elif ch == "i": opt.ignore_case = True
                elif ch == "g": opt.capture = True
                elif ch == "x": opt.verbose = True
                elif ch == "c": opt.color = True
                else:
                    die(f"error: unexpected argument '-{ch}'")
        else:
            inputs.append(a)
        i += 1
    if file_arg:
        if file_arg == "-":
            name = sys.stdin.read().strip()
            inputs = read_file(name)
        else:
            inputs = read_file(file_arg)
    elif inputs == ["-"]:
        inputs = sys.stdin.read().splitlines()
    if not inputs:
        die("error: the following required arguments were not provided:\n  <INPUT>...")
    return opt, inputs


def die(msg):
    print(msg, file=sys.stderr)
    sys.exit(2)


def main():
    opt, inputs = parse(sys.argv[1:])
    print(generate(inputs, opt))


if __name__ == "__main__":
    main()
