#!/usr/bin/env python3
import ipaddress
import json
import os
import random
import socket
import struct
import sys
import time


HELP = """dog \u25cf command-line DNS client

Usage:
  dog [OPTIONS] [--] <arguments>

Examples:
  dog example.net                          Query a domain using default settings
  dog example.net MX                       ...looking up MX records instead
  dog example.net MX @1.1.1.1              ...using a specific nameserver instead
  dog example.net MX @1.1.1.1 -T           ...using TCP rather than UDP
  dog -q example.net -t MX -n 1.1.1.1 -T   As above, but using explicit arguments

Query options:
  <arguments>              Human-readable host names, nameservers, types, or classes
  -q, --query=HOST         Host name or domain name to query
  -t, --type=TYPE          Type of the DNS record being queried (A, MX, NS...)
  -n, --nameserver=ADDR    Address of the nameserver to send packets to
  --class=CLASS            Network class of the DNS record being queried (IN, CH, HS)

Sending options:
  --edns=SETTING           Whether to OPT in to EDNS (disable, hide, show)
  --txid=NUMBER            Set the transaction ID to a specific value
  -Z=TWEAKS                Set uncommon protocol-level tweaks

Protocol options:
  -U, --udp                Use the DNS protocol over UDP
  -T, --tcp                Use the DNS protocol over TCP
  -S, --tls                Use the DNS-over-TLS protocol
  -H, --https              Use the DNS-over-HTTPS protocol

Output options:
  -1, --short              Short mode: display nothing but the first result
  -J, --json               Display the output as JSON
  --color, --colour=WHEN   When to colourise the output (always, automatic, never)
  --seconds                Do not format durations, display them as seconds
  --time                   Print how long the response took to arrive

Meta options:
  -?, --help               Print list of command-line options
  -v, --version            Print version information
"""

VERSION = """dog \u25cf command-line DNS client
v0.2.0-pre [d3a34280] built on 2026-04-17 (pre-release!)
mhttps://dns.lookup.dog/
"""

TYPE_NUM = {
    "A": 1,
    "NS": 2,
    "CNAME": 5,
    "SOA": 6,
    "PTR": 12,
    "HINFO": 13,
    "MX": 15,
    "TXT": 16,
    "AAAA": 28,
    "SRV": 33,
    "NAPTR": 35,
    "SSHFP": 44,
    "TLSA": 52,
    "CAA": 257,
    "ANY": 255,
    "AFSDB": 18,
    "IXFR": 251,
    "OPT": 41,
    "LOC": 29,
}
NUM_TYPE = {v: k for k, v in TYPE_NUM.items()}
CLASS_NUM = {"IN": 1, "CH": 3, "HS": 4}
NUM_CLASS = {v: k for k, v in CLASS_NUM.items()}


class DogError(Exception):
    def __init__(self, message, status=3):
        super().__init__(message)
        self.status = status


def parse_args(argv):
    if "-?" in argv or "--help" in argv:
        print(HELP, end="")
        raise SystemExit(0)
    if "-v" in argv or "--version" in argv:
        print(VERSION, end="")
        raise SystemExit(0)
    opts = {
        "queries": [],
        "types": [],
        "classes": [],
        "nameservers": [],
        "short": False,
        "json": False,
        "color": "automatic",
        "seconds": False,
        "time": False,
        "tcp": False,
        "tls": False,
        "https": False,
        "edns": "hide",
        "txid": None,
        "tweaks": [],
    }
    rest = []
    i = 0
    while i < len(argv):
        arg = argv[i]
        if arg == "--":
            rest.extend(argv[i + 1 :])
            break
        if arg in ("-1", "--short"):
            opts["short"] = True
        elif arg in ("-J", "--json"):
            opts["json"] = True
        elif arg in ("-U", "--udp"):
            opts["tcp"] = False
        elif arg in ("-T", "--tcp"):
            opts["tcp"] = True
        elif arg in ("-S", "--tls"):
            opts["tls"] = True
        elif arg in ("-H", "--https"):
            opts["https"] = True
        elif arg == "--seconds":
            opts["seconds"] = True
        elif arg == "--time":
            opts["time"] = True
        elif arg in ("-q", "--query", "-t", "--type", "-n", "--nameserver", "--class", "--edns", "--txid", "-Z", "--color", "--colour"):
            if i + 1 >= len(argv):
                raise DogError(f"Invalid options: Missing value for option '{arg}'")
            i += 1
            apply_option(opts, arg, argv[i])
        elif arg.startswith("--query="):
            apply_option(opts, "--query", arg.split("=", 1)[1])
        elif arg.startswith("--type="):
            apply_option(opts, "--type", arg.split("=", 1)[1])
        elif arg.startswith("--nameserver="):
            apply_option(opts, "--nameserver", arg.split("=", 1)[1])
        elif arg.startswith("--class="):
            apply_option(opts, "--class", arg.split("=", 1)[1])
        elif arg.startswith("--edns="):
            apply_option(opts, "--edns", arg.split("=", 1)[1])
        elif arg.startswith("--txid="):
            apply_option(opts, "--txid", arg.split("=", 1)[1])
        elif arg.startswith("--color=") or arg.startswith("--colour="):
            apply_option(opts, "--color", arg.split("=", 1)[1])
        elif arg.startswith("-Z="):
            apply_option(opts, "-Z", arg.split("=", 1)[1])
        elif arg.startswith("-"):
            raise DogError(f"Invalid options: Unrecognized option: '{arg.lstrip('-')}'")
        else:
            rest.append(arg)
        i += 1

    for arg in rest:
        classify_plain_arg(opts, arg)
    if not opts["types"]:
        opts["types"] = ["A"]
    if not opts["classes"]:
        opts["classes"] = ["IN"]
    if not opts["nameservers"]:
        opts["nameservers"] = read_system_nameservers()
    if not opts["queries"]:
        print(HELP, end="")
        raise SystemExit(3)
    return opts


def apply_option(opts, opt, value):
    if opt in ("-q", "--query"):
        opts["queries"].append(value)
    elif opt in ("-t", "--type"):
        add_type(opts, value)
    elif opt in ("-n", "--nameserver"):
        opts["nameservers"].append(value.removeprefix("@"))
    elif opt == "--class":
        add_class(opts, value)
    elif opt == "--edns":
        if value not in ("disable", "hide", "show"):
            raise DogError(f'Invalid options: Invalid EDNS setting "{value}"')
        opts["edns"] = value
    elif opt == "--txid":
        try:
            txid = int(value, 0)
        except ValueError:
            raise DogError(f'Invalid options: Invalid transaction ID "{value}"')
        if not 0 <= txid <= 65535:
            raise DogError(f'Invalid options: Invalid transaction ID "{value}"')
        opts["txid"] = txid
    elif opt == "-Z":
        if value not in ("aa", "ad", "cd") and not value.startswith("bufsize="):
            raise DogError(f'Invalid options: Invalid protocol tweak "{value}"')
        if value.startswith("bufsize="):
            try:
                int(value.split("=", 1)[1])
            except ValueError:
                raise DogError(f'Invalid options: Invalid protocol tweak "{value}"')
        opts["tweaks"].append(value)
    elif opt in ("--color", "--colour"):
        if value not in ("always", "automatic", "never"):
            raise DogError(f'Invalid options: Invalid colour setting "{value}"')
        opts["color"] = value


def add_type(opts, value):
    upper = value.upper()
    if upper not in TYPE_NUM:
        raise DogError(f'Invalid options: Invalid query type "{value}"')
    opts["types"].append(upper)


def add_class(opts, value):
    upper = value.upper()
    if upper not in CLASS_NUM:
        raise DogError(f'Invalid options: Invalid query class "{value}"')
    opts["classes"].append(upper)


def classify_plain_arg(opts, arg):
    if arg.startswith("@"):
        opts["nameservers"].append(arg[1:])
    elif arg.upper() in TYPE_NUM:
        opts["types"].append(arg.upper())
    elif arg.upper() in CLASS_NUM:
        opts["classes"].append(arg.upper())
    else:
        opts["queries"].append(arg)


def read_system_nameservers():
    servers = []
    try:
        with open("/etc/resolv.conf", "r", encoding="utf-8") as f:
            for line in f:
                parts = line.split()
                if len(parts) >= 2 and parts[0] == "nameserver":
                    servers.append(parts[1])
    except OSError as e:
        raise DogError(f"Error [network]: {e}", 4)
    return servers or ["127.0.0.53"]


def split_host_port(ns, default_port=53):
    if ns.startswith("["):
        host, rest = ns[1:].split("]", 1)
        return host, int(rest[1:]) if rest.startswith(":") else default_port
    if ns.count(":") == 1 and ns.rsplit(":", 1)[1].isdigit():
        host, port = ns.rsplit(":", 1)
        return host, int(port)
    return ns, default_port


def encode_name(name):
    name = name.rstrip(".")
    out = b""
    for part in name.split("."):
        raw = part.encode("ascii")
        out += bytes([len(raw)]) + raw
    return out + b"\0"


def make_query(name, qtype, qclass, opts):
    txid = opts["txid"] if opts["txid"] is not None else random.randint(0, 65535)
    flags = 0x0100
    for tweak in opts["tweaks"]:
        if tweak == "aa":
            flags |= 0x0400
        elif tweak == "ad":
            flags |= 0x0020
        elif tweak == "cd":
            flags |= 0x0010
    question = encode_name(name) + struct.pack("!HH", qtype, qclass)
    arcount = 0 if opts["edns"] == "disable" else 1
    extra = b"" if arcount == 0 else b"\0" + struct.pack("!HHIH", 41, 512, 0, 0)
    return struct.pack("!HHHHHH", txid, flags, 1, 0, 0, arcount) + question + extra


def query_dns(name, typ, klass, ns, opts):
    packet = make_query(name, TYPE_NUM[typ], CLASS_NUM[klass], opts)
    host, port = split_host_port(ns)
    start = time.monotonic()
    if opts["tcp"]:
        response = tcp_query(host, port, packet)
    else:
        response = udp_query(host, port, packet)
    elapsed = time.monotonic() - start
    return parse_response(response), elapsed


def udp_query(host, port, packet):
    s = socket.socket(socket.AF_INET6 if ":" in host else socket.AF_INET, socket.SOCK_DGRAM)
    s.settimeout(3)
    try:
        s.sendto(packet, (host, port))
        return s.recvfrom(65535)[0]
    finally:
        s.close()


def tcp_query(host, port, packet):
    with socket.create_connection((host, port), timeout=3) as s:
        s.sendall(struct.pack("!H", len(packet)) + packet)
        header = recvn(s, 2)
        size = struct.unpack("!H", header)[0]
        return recvn(s, size)


def recvn(sock, size):
    data = b""
    while len(data) < size:
        chunk = sock.recv(size - len(data))
        if not chunk:
            raise OSError("unexpected EOF")
        data += chunk
    return data


def read_name(packet, pos):
    labels = []
    jumped = False
    end = pos
    seen = set()
    while True:
        length = packet[pos]
        if length & 0xC0 == 0xC0:
            if not jumped:
                end = pos + 2
            ptr = ((length & 0x3F) << 8) | packet[pos + 1]
            if ptr in seen:
                raise ValueError("name pointer loop")
            seen.add(ptr)
            pos = ptr
            jumped = True
            continue
        pos += 1
        if length == 0:
            if not jumped:
                end = pos
            break
        labels.append(packet[pos : pos + length].decode("ascii", "replace"))
        pos += length
    return ".".join(labels) + ".", end


def parse_response(packet):
    _txid, flags, qd, an, ns, ar = struct.unpack("!HHHHHH", packet[:12])
    pos = 12
    queries = []
    for _ in range(qd):
        name, pos = read_name(packet, pos)
        qtype, qclass = struct.unpack("!HH", packet[pos : pos + 4])
        pos += 4
        queries.append({"name": name, "class": NUM_CLASS.get(qclass, f"CLASS{qclass}"), "type": NUM_TYPE.get(qtype, f"TYPE{qtype}")})
    answers = []
    for _ in range(an):
        rec, pos = parse_record(packet, pos)
        answers.append(rec)
    authorities = []
    for _ in range(ns):
        rec, pos = parse_record(packet, pos)
        authorities.append(rec)
    additionals = []
    for _ in range(ar):
        rec, pos = parse_record(packet, pos)
        additionals.append(rec)
    return {"queries": queries, "answers": answers, "authorities": authorities, "additionals": additionals, "rcode": flags & 0xF}


def parse_record(packet, pos):
    name, pos = read_name(packet, pos)
    rtype, rclass, ttl, rdlen = struct.unpack("!HHIH", packet[pos : pos + 10])
    pos += 10
    rdata_pos = pos
    data = packet[pos : pos + rdlen]
    pos += rdlen
    typ = NUM_TYPE.get(rtype, f"TYPE{rtype}")
    rec = {"name": name, "class": NUM_CLASS.get(rclass, f"CLASS{rclass}"), "ttl": ttl, "type": typ}
    rec["data"] = parse_rdata(packet, rdata_pos, data, rtype)
    return rec, pos


def parse_rdata(packet, rdata_pos, data, rtype):
    try:
        if rtype == 1 and len(data) == 4:
            return {"address": socket.inet_ntoa(data)}
        if rtype == 28 and len(data) == 16:
            return {"address": str(ipaddress.IPv6Address(data))}
        if rtype in (2, 5, 12):
            name, _ = read_name(packet, rdata_pos)
            return {"name": name}
        if rtype == 15:
            pref = struct.unpack("!H", data[:2])[0]
            name, _ = read_name(packet, rdata_pos + 2)
            return {"preference": pref, "exchange": name}
        if rtype == 16:
            strings = []
            i = 0
            while i < len(data):
                n = data[i]
                i += 1
                strings.append(data[i : i + n].decode("utf-8", "replace"))
                i += n
            return {"strings": strings}
        if rtype == 6:
            mname, p = read_name(packet, rdata_pos)
            rname, p = read_name(packet, p)
            serial, refresh, retry, expire, minimum = struct.unpack("!IIIII", packet[p : p + 20])
            return {
                "mname": mname,
                "rname": rname,
                "serial": serial,
                "refresh": refresh,
                "retry": retry,
                "expire": expire,
                "minimum": minimum,
            }
        if rtype == 33:
            priority, weight, port = struct.unpack("!HHH", data[:6])
            target, _ = read_name(packet, rdata_pos + 6)
            return {"priority": priority, "weight": weight, "port": port, "target": target}
        if rtype == 257:
            flags = data[0]
            tag_len = data[1]
            tag = data[2 : 2 + tag_len].decode("ascii", "replace")
            value = data[2 + tag_len :].decode("utf-8", "replace")
            return {"flags": flags, "tag": tag, "value": value}
    except Exception:
        pass
    return {"bytes": list(data)}


def ttl_text(ttl, seconds=False):
    if seconds:
        return str(ttl)
    h, rem = divmod(ttl, 3600)
    m, s = divmod(rem, 60)
    parts = []
    if h:
        parts.append(f"{h}h")
        parts.append(f"{m:02d}m")
        parts.append(f"{s:02d}s")
    elif m:
        parts.append(f"{m}m")
        parts.append(f"{s:02d}s")
    else:
        parts.append(f"{s}s")
    return "".join(parts)


def record_value(rec):
    data = rec["data"]
    typ = rec["type"]
    if "address" in data:
        return data["address"]
    if typ == "MX":
        return f'{data.get("preference", 0)} "{data.get("exchange", "")}"'
    if typ == "TXT":
        return ", ".join(f'"{s}"' for s in data.get("strings", []))
    if typ == "SOA":
        return (
            f'"{data["mname"]}" "{data["rname"]}" {data["serial"]} '
            f'{ttl_text(data["refresh"])} {ttl_text(data["retry"])} '
            f'{ttl_text(data["expire"])} {ttl_text(data["minimum"])}'
        )
    if typ == "SRV":
        return f'{data["priority"]} {data["weight"]} "{data["target"]}":{data["port"]}'
    if typ == "CAA":
        critical = "critical" if data.get("flags", 0) & 0x80 else "non-critical"
        return f'"{data["tag"]}" "{data["value"]}" ({critical})'
    if "name" in data:
        return f'"{data["name"]}"'
    if "bytes" in data:
        return " ".join(f"{b:02x}" for b in data["bytes"])
    return str(data)


def colorize(text, code, opts):
    use = opts["color"] == "always" or (opts["color"] == "automatic" and sys.stdout.isatty())
    return f"\033[{code}m{text}\033[0m" if use else text


def print_table(records, opts):
    if not records:
        return
    type_width = max(len(r["type"]) for r in records)
    name_width = max(len(r["name"]) for r in records)
    ttl_width = max(len(ttl_text(r["ttl"], opts["seconds"])) for r in records)
    for rec in records:
        typ = rec["type"].rjust(type_width)
        name = rec["name"].ljust(name_width)
        ttl = ttl_text(rec["ttl"], opts["seconds"]).ljust(ttl_width)
        typ = colorize(typ, "1;32", opts)
        name = colorize(name, "1;34", opts)
        print(f"{typ} {name} {ttl}   {record_value(rec)}")


def run(argv):
    try:
        opts = parse_args(argv)
        responses = []
        elapsed_total = 0.0
        all_answers = []
        for query in opts["queries"]:
            for typ in opts["types"]:
                for klass in opts["classes"]:
                    for ns in opts["nameservers"]:
                        response, elapsed = query_dns(query, typ, klass, ns, opts)
                        elapsed_total += elapsed
                        responses.append({k: response[k] for k in ("queries", "answers", "authorities", "additionals")})
                        all_answers.extend(response["answers"])
        if opts["json"]:
            print(json.dumps({"responses": responses}, separators=(",", ":")))
        elif opts["short"]:
            if not all_answers:
                print("No results", file=sys.stderr)
                return 2
            print(record_value(all_answers[0]).strip('"'))
        else:
            print_table(all_answers, opts)
            if opts["time"]:
                print(f"Ran in {max(1, round(elapsed_total * 1000))}ms")
        return 0
    except DogError as e:
        print(f"dog: {e}", file=sys.stderr)
        return e.status
    except OSError as e:
        print(f"Error [network]: {e}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    sys.exit(run(sys.argv[1:]))
