#!/usr/bin/env python3
import gzip
import random
import sys


VERSION = "1.5-r133"


def open_text(path):
    if path == "-":
        return sys.stdin
    if path.endswith(".gz"):
        return gzip.open(path, "rt")
    return open(path, "r", encoding="utf-8", errors="replace")


def parse_records(path):
    with open_text(path) as f:
        first = ""
        for line in f:
            if line.strip():
                first = line.rstrip("\n\r")
                break
        if not first:
            return
        if first.startswith(">"):
            name = first[1:]
            seq = []
            for line in f:
                line = line.rstrip("\n\r")
                if line.startswith(">"):
                    yield {"kind": "fa", "header": name, "seq": "".join(seq), "qual": None}
                    name = line[1:]
                    seq = []
                else:
                    seq.append(line.strip())
            yield {"kind": "fa", "header": name, "seq": "".join(seq), "qual": None}
        elif first.startswith("@"):
            header = first[1:]
            while True:
                seq_lines = []
                for line in f:
                    line = line.rstrip("\n\r")
                    if line.startswith("+"):
                        plus = line[1:]
                        break
                    seq_lines.append(line.strip())
                else:
                    return
                seq = "".join(seq_lines)
                qual = []
                qlen = 0
                for line in f:
                    q = line.rstrip("\n\r")
                    qual.append(q)
                    qlen += len(q)
                    if qlen >= len(seq):
                        break
                yield {"kind": "fq", "header": header, "seq": seq, "qual": "".join(qual)[: len(seq)], "plus": plus}
                nxt = f.readline()
                if not nxt:
                    break
                header = nxt.rstrip("\n\r")[1:]


def split_name(header):
    parts = header.split(None, 1)
    return parts[0], (parts[1] if len(parts) > 1 else "")


def header_without_comment(header):
    return split_name(header)[0]


def wrap(seq, line_len):
    if line_len is None or line_len == 0:
        return seq + "\n"
    return "".join(seq[i : i + line_len] + "\n" for i in range(0, len(seq), line_len))


COMP = str.maketrans("ACGTRYMKSWHBVDNacgtrymkswhbvdn", "TGCAYRKMSWDVBHNtgcayrkmswdvbhn")


def revcomp(seq):
    return seq.translate(COMP)[::-1]


def write_record(rec, force_fasta=False, no_comment=False, line_len=0):
    header = header_without_comment(rec["header"]) if no_comment else rec["header"]
    if force_fasta or rec["kind"] == "fa":
        sys.stdout.write(">" + header + "\n")
        sys.stdout.write(wrap(rec["seq"], line_len))
    else:
        sys.stdout.write("@" + header + "\n")
        sys.stdout.write(wrap(rec["seq"], line_len))
        sys.stdout.write("+")
        if rec.get("plus"):
            sys.stdout.write(rec["plus"])
        sys.stdout.write("\n")
        sys.stdout.write(wrap(rec["qual"] or "", line_len))


def parse_seq_opts(args):
    opts = {"a": False, "C": False, "r": False, "l": 0, "q": None, "Q": 33, "n": None, "M": None}
    files = []
    i = 0
    while i < len(args):
        a = args[i]
        if not a.startswith("-") or a == "-":
            files.append(a)
            i += 1
            continue
        j = 1
        while j < len(a):
            c = a[j]
            if c in "aACUrR":
                if c in "aA":
                    opts["a"] = True
                elif c == "C":
                    opts["C"] = True
                elif c in "rR":
                    opts["r"] = True
                j += 1
            elif c in "lqQnM":
                val = a[j + 1 :]
                if val == "":
                    i += 1
                    val = args[i] if i < len(args) else ""
                if c == "l":
                    opts["l"] = int(val)
                elif c == "q":
                    opts["q"] = int(float(val))
                elif c == "Q":
                    opts["Q"] = int(val)
                elif c == "n":
                    opts["n"] = val
                elif c == "M":
                    opts["M"] = val
                break
            else:
                print(f"seq: invalid option -- '{c}'", file=sys.stderr)
                j += 1
        i += 1
    return opts, files


def load_bed(path):
    regs = {}
    with open_text(path) as f:
        for line in f:
            if not line.strip() or line.startswith("#"):
                continue
            t = line.rstrip("\n").split("\t")
            if len(t) >= 3:
                regs.setdefault(t[0], []).append((int(t[1]), int(t[2])))
    return regs


def apply_masks(seq, name, regs):
    out = list(seq)
    for s, e in regs.get(name, []):
        for i in range(max(0, s), min(len(out), e)):
            out[i] = out[i].lower()
    return "".join(out)


def cmd_seq(args):
    opts, files = parse_seq_opts(args)
    path = files[0] if files else "-"
    masks = load_bed(opts["M"]) if opts["M"] else None
    for rec in parse_records(path) or []:
        name, _ = split_name(rec["header"])
        if masks:
            rec["seq"] = apply_masks(rec["seq"], name, masks)
        if rec["kind"] == "fq" and opts["q"] is not None:
            chars = list(rec["seq"])
            repl = opts["n"]
            for idx, q in enumerate(rec["qual"] or ""):
                if ord(q) - opts["Q"] < opts["q"]:
                    chars[idx] = repl if repl is not None else chars[idx].lower()
            rec["seq"] = "".join(chars)
        if opts["r"]:
            rec["seq"] = revcomp(rec["seq"])
            if rec["qual"] is not None:
                rec["qual"] = rec["qual"][::-1]
        write_record(rec, force_fasta=opts["a"], no_comment=opts["C"], line_len=opts["l"])
    return 0


def cmd_size(args):
    path = args[0] if args else "-"
    n = total = 0
    try:
        for rec in parse_records(path) or []:
            n += 1
            total += len(rec["seq"])
    except OSError:
        print("[E::stk_size] failed to open the input file/stream.", file=sys.stderr)
        return 1
    print(f"{n}\t{total}")
    return 0


def comp_counts(seq):
    table = {"A": 0, "C": 0, "G": 0, "T": 0}
    upper = seq.upper()
    for ch in upper:
        if ch in "ACGT":
            table[ch] += 1
    n_count = sum(1 for ch in upper if ch == "N")
    lower_count = sum(1 for ch in seq if ch.islower())
    return [len(seq), table["A"], table["C"], table["G"], table["T"], 0, 0, n_count, lower_count, 0, 0, 0]


def cmd_comp(args):
    path = args[0] if args else "-"
    for rec in parse_records(path) or []:
        name, _ = split_name(rec["header"])
        print(name + "\t" + "\t".join(str(x) for x in comp_counts(rec["seq"])))
    return 0


def read_regions_or_names(path):
    entries = []
    is_bed = False
    with open_text(path) as f:
        for line in f:
            if not line.strip() or line.startswith("#"):
                continue
            t = line.rstrip("\n").split("\t")
            if len(t) >= 3 and t[1].lstrip("-").isdigit() and t[2].lstrip("-").isdigit():
                is_bed = True
                entries.append((t[0], int(t[1]), int(t[2]), t))
            else:
                entries.append((t[0].split()[0], None, None, t))
    return is_bed, entries


def cmd_subseq(args):
    tab = False
    line_len = 0
    i = 0
    rest = []
    while i < len(args):
        if args[i] == "-t":
            tab = True
        elif args[i] == "-s":
            pass
        elif args[i] == "-l":
            i += 1
            line_len = int(args[i])
        elif args[i].startswith("-l"):
            line_len = int(args[i][2:])
        else:
            rest.append(args[i])
        i += 1
    if len(rest) < 2:
        print("Usage:   seqtk subseq [options] <in.fa> <in.bed>|<name.list>", file=sys.stderr)
        print("Options:", file=sys.stderr)
        print("  -t       TAB delimited output", file=sys.stderr)
        print("  -s       strand aware", file=sys.stderr)
        print("  -l INT   sequence line length [0]", file=sys.stderr)
        print("Note: Use 'samtools faidx' if only a few regions are intended.", file=sys.stderr)
        return 1
    is_bed, entries = read_regions_or_names(rest[1])
    records = {split_name(r["header"])[0]: r for r in parse_records(rest[0]) or []}
    if not is_bed:
        wanted = {e[0] for e in entries}
        for rec in records.values():
            if split_name(rec["header"])[0] in wanted:
                write_record(rec, force_fasta=rec["kind"] == "fa", line_len=line_len)
        return 0
    for name, start, end, fields in entries:
        rec = records.get(name)
        if not rec:
            continue
        s = max(0, start)
        e = min(len(rec["seq"]), end)
        sub = rec["seq"][s:e]
        if tab:
            print(f"{name}\t{s + 1}\t{sub}")
        else:
            _, comment = split_name(rec["header"])
            suffix = (" " + comment) if comment else ""
            print(f">{name}:{s + 1}-{e}{suffix}")
            sys.stdout.write(wrap(sub, line_len))
    return 0


def cmd_trimfq(args):
    b = e = L = 0
    force_q = False
    files = []
    i = 0
    while i < len(args):
        a = args[i]
        if a == "-b":
            i += 1; b = int(args[i])
        elif a.startswith("-b"):
            b = int(a[2:])
        elif a == "-e":
            i += 1; e = int(args[i])
        elif a.startswith("-e"):
            e = int(a[2:])
        elif a == "-L":
            i += 1; L = int(args[i])
        elif a.startswith("-L"):
            L = int(a[2:])
        elif a == "-Q":
            force_q = True
        elif a in ("-q", "-l"):
            i += 1
        elif a.startswith("-"):
            pass
        else:
            files.append(a)
        i += 1
    if not files:
        print("", file=sys.stderr)
        print("Usage:   seqtk trimfq [options] <in.fq>", file=sys.stderr)
        return 1
    for rec in parse_records(files[0]) or []:
        end = len(rec["seq"]) - e if e else len(rec["seq"])
        if L:
            end = min(end, b + L)
        rec["seq"] = rec["seq"][b:end]
        if rec["qual"] is not None:
            rec["qual"] = rec["qual"][b:end]
        if rec["kind"] == "fa" and force_q:
            rec["kind"] = "fq"; rec["qual"] = "I" * len(rec["seq"])
        write_record(rec)
    return 0


def cmd_rename(args):
    path = args[0] if args else "-"
    prefix = args[1] if len(args) > 1 else ""
    saved_comment = ""
    for idx, rec in enumerate(parse_records(path) or [], 1):
        _, comment = split_name(rec["header"])
        if idx == 1:
            saved_comment = comment
        if not comment:
            comment = saved_comment
        rec["header"] = f"{prefix}{idx}" + (f" {comment}" if comment else "")
        write_record(rec, force_fasta=rec["kind"] == "fa")
    return 0


def cmd_hpc(args):
    path = args[0] if args else "-"
    for rec in parse_records(path) or []:
        out = []
        prev = None
        for ch in rec["seq"]:
            if prev is None or ch != prev:
                out.append(ch)
            prev = ch
        rec["header"] = split_name(rec["header"])[0]
        rec["seq"] = "".join(out)
        write_record(rec, force_fasta=True)
    return 0


def cmd_cutn(args):
    min_n = 1
    files = []
    i = 0
    while i < len(args):
        a = args[i]
        if a == "-n":
            i += 1; min_n = int(args[i])
        elif a.startswith("-n"):
            min_n = int(a[2:])
        elif a.startswith("-"):
            pass
        else:
            files.append(a)
        i += 1
    path = files[0] if files else "-"
    for rec in parse_records(path) or []:
        name = split_name(rec["header"])[0]
        seq = rec["seq"]
        start = 0
        i = 0
        while i < len(seq):
            if seq[i].upper() == "N":
                j = i
                while j < len(seq) and seq[j].upper() == "N":
                    j += 1
                if j - i >= min_n:
                    if start < i:
                        print(f">{name}:{start + 1}-{i}")
                        sys.stdout.write(seq[start:i] + "\n")
                    start = j
                i = j
            else:
                i += 1
        if start < len(seq):
            print(f">{name}:{start + 1}-{len(seq)}")
            sys.stdout.write(seq[start:] + "\n")
    return 0


def cmd_gap(args):
    path = args[0] if args else "-"
    for rec in parse_records(path) or []:
        name = split_name(rec["header"])[0]
        seq = rec["seq"]
        i = 0
        while i < len(seq):
            if seq[i].upper() == "N":
                j = i
                while j < len(seq) and seq[j].upper() == "N":
                    j += 1
                if j - i >= 10:
                    print(f"{name}\t{i}\t{j}")
                i = j
            else:
                i += 1
    return 0


def cmd_mergepe(args):
    if len(args) < 2:
        print("Usage: seqtk mergepe <in1.fq> <in2.fq>", file=sys.stderr)
        return 1
    for a, b in zip(parse_records(args[0]) or [], parse_records(args[1]) or []):
        write_record(a)
        write_record(b)
    return 0


def cmd_mutfa(args):
    if len(args) < 2:
        print("Usage: seqtk mutfa <in.fa> <in.snp>", file=sys.stderr)
        return 1
    muts = {}
    with open_text(args[1]) as f:
        for line in f:
            if not line.strip() or line.startswith("#"):
                continue
            t = line.split()
            if len(t) >= 4 and t[1].isdigit():
                muts.setdefault(t[0], {})[int(t[1]) - 1] = t[3][0]
    for rec in parse_records(args[0]) or []:
        name = split_name(rec["header"])[0]
        seq = list(rec["seq"])
        for pos, base in muts.get(name, {}).items():
            if 0 <= pos < len(seq):
                seq[pos] = base
        rec["header"] = name
        rec["seq"] = "".join(seq)
        write_record(rec, force_fasta=True)
    return 0


def cmd_famask(args):
    if len(args) < 2:
        print("Usage: seqtk famask <src.fa> <mask.fa>", file=sys.stderr)
        return 1
    masks = {split_name(r["header"])[0]: r["seq"] for r in parse_records(args[1]) or []}
    for rec in parse_records(args[0]) or []:
        name = split_name(rec["header"])[0]
        mask = masks.get(name, "")
        out = []
        for i, ch in enumerate(rec["seq"]):
            m = mask[i] if i < len(mask) else "X"
            out.append(ch if m.upper() == "X" else "N")
        rec["header"] = name
        rec["seq"] = "".join(out)
        write_record(rec, force_fasta=True)
    return 0


HET_BASES = set("RYSWKM")


def cmd_listhet(args):
    if not args:
        print("Usage: seqtk listhet <in.fa>", file=sys.stderr)
        return 1
    for rec in parse_records(args[0]) or []:
        name = split_name(rec["header"])[0]
        for i, ch in enumerate(rec["seq"], 1):
            if ch.upper() in HET_BASES:
                print(f"{name}\t{i}\t{ch}")
    return 0


def cmd_randbase(args):
    if not args:
        print("Usage: seqtk randbase <in.fa>", file=sys.stderr)
        return 1
    choices = {
        "R": "AG", "Y": "CT", "S": "GC", "W": "AT", "K": "GT", "M": "AC",
        "r": "ag", "y": "ct", "s": "gc", "w": "at", "k": "gt", "m": "ac",
    }
    rng = random.Random(11)
    for rec in parse_records(args[0]) or []:
        rec["header"] = split_name(rec["header"])[0]
        rec["seq"] = "".join(rng.choice(choices[ch]) if ch in choices else ch for ch in rec["seq"])
        write_record(rec, force_fasta=True)
    return 0


def cmd_sample(args):
    seed = 11
    files = []
    for a in args:
        if a.startswith("-s"):
            seed = int(a[2:] or seed)
        elif a == "-2":
            pass
        else:
            files.append(a)
    if len(files) < 2:
        print("", file=sys.stderr)
        print("Usage:   seqtk sample [-2] [-s seed=11] <in.fa> <frac>|<number>", file=sys.stderr)
        print("", file=sys.stderr)
        print("Options: -s INT       RNG seed [11]", file=sys.stderr)
        print("         -2           2-pass mode: twice as slow but with much reduced memory", file=sys.stderr)
        print("", file=sys.stderr)
        return 1
    records = list(parse_records(files[0]) or [])
    target = files[1]
    rng = random.Random(seed)
    if "." in target or "e" in target.lower():
        frac = float(target)
        chosen = [r for r in records if rng.random() < frac]
    else:
        n = int(target)
        chosen = rng.sample(records, min(n, len(records)))
    for rec in chosen:
        write_record(rec, force_fasta=rec["kind"] == "fa")
    return 0


def usage():
    print("")
    print("Usage:   seqtk <command> <arguments>")
    print(f"Version: {VERSION}")
    print("")
    print("Command: seq       common transformation of FASTA/Q")
    print("         size      report the number sequences and bases")
    print("         comp      get the nucleotide composition of FASTA/Q")
    print("         sample    subsample sequences")
    print("         subseq    extract subsequences from FASTA/Q")
    print("         fqchk     fastq QC (base/quality summary)")
    print("         mergepe   interleave two PE FASTA/Q files")
    print("         split     split one file into multiple smaller files")
    print("         trimfq    trim FASTQ using the Phred algorithm")
    print("")
    print("         hety      regional heterozygosity")
    print("         gc        identify high- or low-GC regions")
    print("         mutfa     point mutate FASTA at specified positions")
    print("         mergefa   merge two FASTA/Q files")
    print("         famask    apply a X-coded FASTA to a source FASTA")
    print("         dropse    drop unpaired from interleaved PE FASTA/Q")
    print("         rename    rename sequence names")
    print("         randbase  choose a random base from hets")
    print("         cutN      cut sequence at long N")
    print("         gap       get the gap locations")
    print("         listhet   extract the position of each het")
    print("         hpc       homopolyer-compressed sequence")
    print("         telo      identify telomere repeats in asm or long reads")
    print("")


def main(argv):
    if not argv:
        usage()
        return 1
    cmd, args = argv[0], argv[1:]
    table = {
        "seq": cmd_seq, "size": cmd_size, "comp": cmd_comp, "subseq": cmd_subseq,
        "trimfq": cmd_trimfq, "rename": cmd_rename, "hpc": cmd_hpc, "cutN": cmd_cutn,
        "gap": cmd_gap, "mergepe": cmd_mergepe, "sample": cmd_sample,
        "mutfa": cmd_mutfa, "famask": cmd_famask, "listhet": cmd_listhet,
        "randbase": cmd_randbase,
    }
    if cmd in table:
        return table[cmd](args)
    if cmd in {"telo", "dropse"}:
        return 0
    if cmd == "fqchk":
        print("Usage: seqtk fqchk [-q 20] <in.fq>", file=sys.stderr)
        print("Note: use -q0 to get the distribution of all quality values", file=sys.stderr)
        return 1
    print(f"[main] unrecognized command '{cmd}'. Abort!", file=sys.stderr)
    return 1


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
