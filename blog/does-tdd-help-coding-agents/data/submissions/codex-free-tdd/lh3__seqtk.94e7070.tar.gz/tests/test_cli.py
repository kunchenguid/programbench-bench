#!/usr/bin/env python3
import os
import subprocess
import tempfile
import textwrap
import unittest


ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
EXE = os.path.join(ROOT, "src", "seqtk.py")


class SeqtkCliTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.d = self.tmp.name
        self.fa = os.path.join(self.d, "a.fa")
        self.fq = os.path.join(self.d, "a.fq")
        self.names = os.path.join(self.d, "names.txt")
        self.bed = os.path.join(self.d, "regs.bed")
        with open(self.fa, "w", encoding="utf-8") as f:
            f.write(textwrap.dedent("""\
                >seq1 comment here
                ACGTNNacgt
                TTAA
                >seq2
                GGGCCC
                """))
        with open(self.fq, "w", encoding="utf-8") as f:
            f.write(textwrap.dedent("""\
                @r1 comment
                ACGTN
                +
                IIIII
                @r2
                TTAA
                +
                !!!!
                """))
        with open(self.names, "w", encoding="utf-8") as f:
            f.write("seq2\nr1\n")
        with open(self.bed, "w", encoding="utf-8") as f:
            f.write("seq1\t2\t8\nseq2\t1\t4\tregname\t0\t-\n")

    def tearDown(self):
        self.tmp.cleanup()

    def run_cmd(self, *args):
        return subprocess.run(
            ["python3", EXE, *args],
            text=True,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            check=False,
        )

    def test_top_level_usage_exits_one(self):
        p = self.run_cmd()
        self.assertEqual(p.returncode, 1)
        self.assertIn("Usage:   seqtk <command> <arguments>\nVersion: 1.5-r133\n", p.stdout)
        self.assertEqual(p.stderr, "")

    def test_seq_converts_fastq_to_fasta_and_removes_comments(self):
        p = self.run_cmd("seq", "-aC", self.fq)
        self.assertEqual(p.returncode, 0)
        self.assertEqual(p.stdout, ">r1\nACGTN\n>r2\nTTAA\n")
        self.assertEqual(p.stderr, "")

    def test_seq_reverse_complements_and_folds_fasta(self):
        p = self.run_cmd("seq", "-r", "-l4", self.fa)
        self.assertEqual(p.returncode, 0)
        self.assertEqual(
            p.stdout,
            ">seq1 comment here\nTTAA\nacgt\nNNAC\nGT\n>seq2\nGGGC\nCC\n",
        )

    def test_seq_masks_low_quality_fastq_bases_to_n(self):
        p = self.run_cmd("seq", "-q40", "-n", "N", self.fq)
        self.assertEqual(p.returncode, 0)
        self.assertEqual(p.stdout, "@r1 comment\nACGTN\n+\nIIIII\n@r2\nNNNN\n+\n!!!!\n")

    def test_size_and_composition_match_observed_columns(self):
        p = self.run_cmd("size", self.fa)
        self.assertEqual(p.stdout, "2\t20\n")
        p = self.run_cmd("comp", self.fa)
        self.assertEqual(
            p.stdout,
            "seq1\t14\t4\t2\t2\t4\t0\t0\t2\t4\t0\t0\t0\n"
            "seq2\t6\t0\t3\t3\t0\t0\t0\t0\t0\t0\t0\t0\n",
        )

    def test_subseq_supports_name_lists_bed_and_tab_output(self):
        p = self.run_cmd("subseq", self.fa, self.names)
        self.assertEqual(p.stdout, ">seq2\nGGGCCC\n")
        p = self.run_cmd("subseq", self.fa, self.bed)
        self.assertEqual(p.stdout, ">seq1:3-8 comment here\nGTNNac\n>seq2:2-4\nGGC\n")
        p = self.run_cmd("subseq", "-t", self.fa, self.bed)
        self.assertEqual(p.stdout, "seq1\t3\tGTNNac\nseq2\t2\tGGC\n")

    def test_trim_rename_hpc_and_cutn(self):
        self.assertEqual(
            self.run_cmd("trimfq", "-b", "1", "-e", "1", self.fq).stdout,
            "@r1 comment\nCGT\n+\nIII\n@r2\nTA\n+\n!!\n",
        )
        self.assertEqual(
            self.run_cmd("rename", self.fa, "PFX").stdout,
            ">PFX1 comment here\nACGTNNacgtTTAA\n>PFX2 comment here\nGGGCCC\n",
        )
        self.assertEqual(
            self.run_cmd("hpc", self.fa).stdout,
            ">seq1\nACGTNacgtTA\n>seq2\nGC\n",
        )
        self.assertEqual(
            self.run_cmd("cutN", "-n", "2", self.fa).stdout,
            ">seq1:1-4\nACGT\n>seq1:7-14\nacgtTTAA\n>seq2:1-6\nGGGCCC\n",
        )

    def test_mask_mutate_pair_and_het_helpers(self):
        mut = os.path.join(self.d, "mut.snp")
        mask = os.path.join(self.d, "mask.fa")
        het = os.path.join(self.d, "het.fa")
        fq2 = os.path.join(self.d, "b.fq")
        with open(mut, "w", encoding="utf-8") as f:
            f.write("seq1 2 x T\nseq2 6 x A\n")
        with open(mask, "w", encoding="utf-8") as f:
            f.write(">seq1\nNNXXNNNNXXXXNN\n>seq2\nNNNNNN\n")
        with open(het, "w", encoding="utf-8") as f:
            f.write(">h1\nACRYSWKMBDHVN\n")
        with open(fq2, "w", encoding="utf-8") as f:
            f.write("@p1\nAAAA\n+\nIIII\n@p2\nCCCC\n+\nIIII\n")
        self.assertEqual(
            self.run_cmd("mutfa", self.fa, mut).stdout,
            ">seq1\nATGTNNacgtTTAA\n>seq2\nGGGCCA\n",
        )
        self.assertEqual(
            self.run_cmd("famask", self.fa, mask).stdout,
            ">seq1\nNNGTNNNNgtTTNN\n>seq2\nNNNNNN\n",
        )
        self.assertEqual(
            self.run_cmd("mergepe", self.fq, fq2).stdout,
            "@r1 comment\nACGTN\n+\nIIIII\n@p1\nAAAA\n+\nIIII\n@r2\nTTAA\n+\n!!!!\n@p2\nCCCC\n+\nIIII\n",
        )
        self.assertEqual(
            self.run_cmd("listhet", het).stdout,
            "h1\t3\tR\nh1\t4\tY\nh1\t5\tS\nh1\t6\tW\nh1\t7\tK\nh1\t8\tM\n",
        )


if __name__ == "__main__":
    unittest.main()
