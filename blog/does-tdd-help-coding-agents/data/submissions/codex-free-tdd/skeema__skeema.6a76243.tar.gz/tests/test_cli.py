#!/usr/bin/env python3
import os
import shutil
import subprocess
import tempfile
import unittest


ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
APP = os.path.join(ROOT, "skeema.py")
COMPILE = os.path.join(ROOT, "compile.sh")


def run_app(args, cwd=None):
    return subprocess.run(
        ["python3", APP] + args,
        cwd=cwd or ROOT,
        text=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
    )


class SkeemaCliTests(unittest.TestCase):
    def test_no_args_displays_command_suite_help(self):
        result = run_app([])
        self.assertEqual(result.returncode, 0)
        self.assertIn("Usage:  skeema [<options>] <command>", result.stdout)
        self.assertIn("add-environment  Add a new named environment", result.stdout)
        self.assertIn("Global Options:", result.stdout)

    def test_version_command_matches_release_banner(self):
        for args in (["version"], ["--version"]):
            with self.subTest(args=args):
                result = run_app(args)
                self.assertEqual(result.returncode, 0)
                self.assertEqual(
                    result.stdout,
                    "skeema version 1.13.2-community, commit a65240e, released 2026-04-17T20:00:03Z\n",
                )

    def test_unknown_command_and_option_use_reference_exit_codes(self):
        unknown = run_app(["bogus"])
        self.assertEqual(unknown.returncode, 78)
        self.assertRegex(unknown.stdout, r'\[ERROR\] Unknown command "bogus"\n$')

        bad_option = run_app(["init", "--bad"])
        self.assertEqual(bad_option.returncode, 78)
        self.assertRegex(bad_option.stdout, r'\[ERROR\] CLI: Unknown option "bad"\n$')

        bad_help = run_app(["--help=bogus"])
        self.assertEqual(bad_help.returncode, 2)
        self.assertRegex(bad_help.stdout, r'\[ERROR\] Unknown command "bogus"\n$')

    def test_command_help_variants_show_command_usage(self):
        for args in (["help", "init"], ["--help=init"], ["init", "--help"]):
            with self.subTest(args=args):
                result = run_app(args)
                self.assertEqual(result.returncode, 0)
                self.assertIn("Usage:  skeema init [<options>] [<environment>]", result.stdout)
                self.assertIn("Init Options:", result.stdout)
                self.assertIn("https://www.skeema.io/docs/commands/init", result.stdout)

    def test_global_options_may_precede_version_command(self):
        result = run_app(["-u", "root", "version"])
        self.assertEqual(result.returncode, 0)
        self.assertEqual(
            result.stdout,
            "skeema version 1.13.2-community, commit a65240e, released 2026-04-17T20:00:03Z\n",
        )

        debug = run_app(["--debug", "version"])
        self.assertEqual(debug.returncode, 0)
        self.assertIn("skeema version 1.13.2-community", debug.stdout)
        self.assertRegex(debug.stdout, r"\[DEBUG\] Exit code 0 \(SUCCESS\)\n$")

    def test_version_rejects_extra_args_but_has_command_help(self):
        extra = run_app(["version", "extra"])
        self.assertEqual(extra.returncode, 78)
        self.assertRegex(extra.stdout, r'\[ERROR\] Extra command-line arg "extra" supplied; command version takes a max of 0 args\n$')

        help_result = run_app(["version", "--help"])
        self.assertEqual(help_result.returncode, 0)
        self.assertIn("Usage:  skeema version [<options>]", help_result.stdout)
        self.assertIn("Display program version", help_result.stdout)

    def test_add_environment_requires_existing_skeema_file(self):
        tmp = tempfile.mkdtemp()
        try:
            result = run_app(["add-environment", "staging"], cwd=tmp)
            self.assertEqual(result.returncode, 78)
            self.assertIn("does not have an existing .skeema file", result.stdout)
        finally:
            shutil.rmtree(tmp)

    def test_add_environment_appends_section_with_host_and_port(self):
        tmp = tempfile.mkdtemp()
        try:
            with open(os.path.join(tmp, ".skeema"), "w", encoding="utf-8") as f:
                f.write("[production]\nhost=prod\nport=3307\n")

            result = run_app(
                ["add-environment", "-h", "stagehost", "-P", "3308", "staging"],
                cwd=tmp,
            )

            self.assertEqual(result.returncode, 0)
            self.assertIn("[WARN]  Unable to automatically determine database server's vendor/version.", result.stdout)
            self.assertIn("[INFO]  Added environment [staging]", result.stdout)
            with open(os.path.join(tmp, ".skeema"), encoding="utf-8") as f:
                self.assertEqual(
                    f.read(),
                    "[production]\nhost=prod\nport=3307\n\n[staging]\nhost=stagehost\nport=3308\n",
                )
        finally:
            shutil.rmtree(tmp)

    def test_add_environment_requires_host_when_config_exists(self):
        tmp = tempfile.mkdtemp()
        try:
            with open(os.path.join(tmp, ".skeema"), "w", encoding="utf-8") as f:
                f.write("[production]\nhost=prod\n")
            result = run_app(["add-environment", "staging"], cwd=tmp)
            self.assertEqual(result.returncode, 78)
            self.assertIn("`skeema add-environment` requires --host to be supplied on command-line", result.stdout)
        finally:
            shutil.rmtree(tmp)

    def test_empty_directory_diff_lint_and_format_match_noop_behavior(self):
        tmp = tempfile.mkdtemp()
        try:
            diff = run_app(["diff"], cwd=tmp)
            self.assertEqual(diff.returncode, 0)
            self.assertEqual(diff.stdout, "")

            lint = run_app(["lint"], cwd=tmp)
            self.assertEqual(lint.returncode, 0)
            self.assertRegex(lint.stdout, r"\[INFO\]  Linting .+\n$")

            fmt = run_app(["format"], cwd=tmp)
            self.assertEqual(fmt.returncode, 0)
            self.assertRegex(fmt.stdout, r"\[INFO\]  Reformatting .+\n$")

            check = run_app(["format", "--skip-write"], cwd=tmp)
            self.assertEqual(check.returncode, 0)
            self.assertRegex(check.stdout, r"\[INFO\]  Checking format of .+\n$")
        finally:
            shutil.rmtree(tmp)

    def test_sql_file_without_server_reports_workspace_connection_errors(self):
        tmp = tempfile.mkdtemp()
        try:
            with open(os.path.join(tmp, ".skeema"), "w", encoding="utf-8") as f:
                f.write("[production]\nhost=localhost\n")
            with open(os.path.join(tmp, "t.sql"), "w", encoding="utf-8") as f:
                f.write("CREATE TABLE t (id int);\n")

            lint = run_app(["lint", "--skip-format"], cwd=tmp)
            self.assertEqual(lint.returncode, 78)
            self.assertIn("[INFO]  Linting", lint.stdout)
            self.assertIn("Unable to connect to localhost:/tmp/mysql.sock", lint.stdout)
            self.assertIn("Skipped 1 operation due to fatal errors", lint.stdout)

            fmt = run_app(["format", "--skip-write"], cwd=tmp)
            self.assertEqual(fmt.returncode, 78)
            self.assertIn("[INFO]  Checking format of", fmt.stdout)
            self.assertIn("Unable to connect to localhost:/tmp/mysql.sock", fmt.stdout)
        finally:
            shutil.rmtree(tmp)

    def test_init_reports_connection_failure_for_supplied_host(self):
        tmp = tempfile.mkdtemp()
        try:
            missing = run_app(["init"], cwd=tmp)
            self.assertEqual(missing.returncode, 78)
            self.assertIn("Option --host must be supplied on the command-line", missing.stdout)

            result = run_app(["init", "-h", "localhost", "--schema", "test"], cwd=tmp)
            self.assertEqual(result.returncode, 2)
            self.assertIn("[ERROR] Unable to connect to localhost:/tmp/mysql.sock", result.stdout)
            self.assertIn(f"for {tmp}/localhost", result.stdout)
        finally:
            shutil.rmtree(tmp)

    def test_extra_command_args_use_reference_error_wording(self):
        result = run_app(["init", "extra1", "extra2"])
        self.assertEqual(result.returncode, 78)
        self.assertRegex(
            result.stdout,
            r'\[ERROR\] Extra command-line arg "extra2" supplied; command init takes a max of 1 args\n$',
        )

    def test_compile_script_produces_runnable_executable(self):
        tmp = tempfile.mkdtemp()
        try:
            for name in ("compile.sh", "skeema.py"):
                shutil.copy(os.path.join(ROOT, name), tmp)
            result = subprocess.run(
                ["bash", "-lc", "chmod +x ./compile.sh && ./compile.sh && ./executable --version"],
                cwd=tmp,
                text=True,
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
            )
            self.assertEqual(result.returncode, 0)
            self.assertIn("skeema version 1.13.2-community", result.stdout)
        finally:
            shutil.rmtree(tmp)


if __name__ == "__main__":
    unittest.main()
