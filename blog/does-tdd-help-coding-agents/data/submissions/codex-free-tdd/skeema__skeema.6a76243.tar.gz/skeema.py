#!/usr/bin/env python3
import datetime
import os
import sys


VERSION = "skeema version 1.13.2-community, commit a65240e, released 2026-04-17T20:00:03Z"

COMMANDS = {
    "add-environment",
    "diff",
    "format",
    "help",
    "init",
    "lint",
    "pull",
    "push",
    "version",
}

GLOBAL_VALUE_OPTIONS = {
    "-o",
    "--connect-options",
    "-H",
    "--host-wrapper",
    "--ignore-func",
    "--ignore-proc",
    "--ignore-schema",
    "--ignore-table",
    "-p",
    "--password",
    "--ssl-mode",
    "-u",
    "--user",
}

GLOBAL_FLAGS = {
    "--debug",
    "--my-cnf",
    "--skip-my-cnf",
}

COMMAND_VALUE_OPTIONS = {
    "init": {"-d", "--dir", "-h", "--host", "-P", "--port", "--schema", "-S", "--socket"},
    "add-environment": {"-d", "--dir", "-h", "--host", "-P", "--port", "-S", "--socket"},
    "diff": {
        "-x", "--alter-wrapper", "--alter-wrapper-min-size", "-X", "--ddl-wrapper",
        "--alter-algorithm", "--alter-lock", "--partitioning", "--allow-auto-inc",
        "--allow-charset", "--allow-compression", "--allow-definer", "--allow-engine",
        "--allow-pk-type", "--lint-auto-inc", "--lint-charset", "--lint-compression",
        "--lint-definer", "--lint-display-width", "--lint-dupe-index", "--lint-engine",
        "--lint-fk-parent", "--lint-has-enum", "--lint-has-fk", "--lint-has-float",
        "--lint-has-routine", "--lint-has-time", "--lint-name-case", "--lint-pk",
        "--lint-pk-type", "--lint-reserved-word", "--lint-zero-date", "--safe-below-size",
        "-c", "--concurrent-servers", "--docker-cleanup", "-t", "--temp-schema",
        "--temp-schema-binlog", "--temp-schema-mode", "--temp-schema-threads", "-w",
        "--workspace",
    },
    "push": set(),
    "pull": {
        "--docker-cleanup", "-t", "--temp-schema", "--temp-schema-binlog",
        "--temp-schema-mode", "--temp-schema-threads", "-w", "--workspace",
    },
    "lint": set(),
    "format": set(),
}
COMMAND_VALUE_OPTIONS["push"] = set(COMMAND_VALUE_OPTIONS["diff"])
COMMAND_VALUE_OPTIONS["lint"] = {
    "--allow-auto-inc", "--allow-charset", "--allow-compression", "--allow-definer",
    "--allow-engine", "--allow-pk-type", "--lint-auto-inc", "--lint-charset",
    "--lint-compression", "--lint-definer", "--lint-display-width", "--lint-dupe-index",
    "--lint-engine", "--lint-fk-parent", "--lint-has-enum", "--lint-has-fk",
    "--lint-has-float", "--lint-has-routine", "--lint-has-time", "--lint-name-case",
    "--lint-pk", "--lint-pk-type", "--lint-reserved-word", "--lint-zero-date",
    "--docker-cleanup", "-t", "--temp-schema", "--temp-schema-binlog",
    "--temp-schema-mode", "--temp-schema-threads", "-w", "--workspace",
}
COMMAND_VALUE_OPTIONS["format"] = {
    "--docker-cleanup", "-t", "--temp-schema", "--temp-schema-binlog",
    "--temp-schema-mode", "--temp-schema-threads", "-w", "--workspace",
}

COMMAND_FLAGS = {
    "init": {"--include-auto-inc", "--strip-partitioning"},
    "add-environment": set(),
    "diff": {
        "--alter-validate-virtual", "--compare-metadata", "--exact-match",
        "--lax-column-order", "--lax-comments", "--lint", "--skip-lint",
        "--allow-unsafe", "--verify", "--skip-verify", "-q", "--brief", "-1",
        "--first-only",
    },
    "push": {
        "--alter-validate-virtual", "--compare-metadata", "--exact-match",
        "--lax-column-order", "--lax-comments", "--lint", "--skip-lint",
        "--allow-unsafe", "--dry-run", "--foreign-key-checks", "--verify",
        "--skip-verify", "-1", "--first-only",
    },
    "pull": {
        "--format", "--skip-format", "--include-auto-inc", "--new-schemas",
        "--skip-new-schemas", "--strip-partitioning", "--update-partitioning",
    },
    "lint": {"--format", "--skip-format", "--strip-partitioning"},
    "format": {"--strip-partitioning", "--write", "--skip-write"},
}


MAIN_HELP = """
Usage:  skeema [<options>] <command>

Skeema is a declarative schema management system for MySQL and MariaDB. It
allows you to export a database schema to the filesystem, and apply online
schema changes by modifying CREATE statements in .sql files.

Commands:
      add-environment  Add a new named environment to an existing host directory
      diff             Compare a DB server's schemas to the filesystem
      format           Normalize format of filesystem representation of database objects
      help             Display usage information
      init             Save a DB server's schemas to the filesystem
      lint             Check for problems in filesystem representation of database objects
      pull             Update the filesystem representation of schemas
      push             Alter objects on DBs to reflect the filesystem representation
      version          Display program version

Global Options:
  -o, --connect-options value  Comma-separated session options to set upon connecting to each database server
      --debug                  Enable debug logging
  -?, --help[=value]           Display usage information for the specified command
  -H, --host-wrapper value     External bin to shell out to for host lookup; see manual for template vars
      --ignore-func value      Ignore functions that match regex
      --ignore-proc value      Ignore stored procedures that match regex
      --ignore-schema value    Ignore schemas that match regex
      --ignore-table value     Ignore tables that match regex
      --[skip-]my-cnf          Parse ~/.my.cnf for configuration (enabled by default; disable with --skip-my-cnf)
  -p, --password[=value]       Password for database user; omit value to prompt from TTY (default "$MYSQL_PWD")
      --ssl-mode value         Specify desired connection security SSL/TLS usage (valid values: "disabled", "preferred", "required")
  -u, --user value             Username to connect to database host (default "root")
      --version                Display program version

Complete documentation for this command suite is available online:
https://www.skeema.io/docs/commands
"""

COMMAND_BLURBS = {
    "init": (
        "Usage:  skeema init [<options>] [<environment>]",
        "Creates a filesystem representation of the schemas on a database server.",
        "Init Options:\n  -d, --dir value              Subdir name to use for this host's schemas (default \"<hostname>\")\n  -h, --host value             Database hostname or IP address\n      --include-auto-inc       Include starting auto-inc values in table files\n  -P, --port value             Port to use for database host (default \"3306\")\n      --schema value           Only import the one specified schema; skip creation of subdirs for each schema\n  -S, --socket value           Absolute path to Unix socket file used if host is localhost (default \"/tmp/mysql.sock\")\n      --strip-partitioning     Omit PARTITION BY clause when writing partitioned tables to filesystem",
    ),
    "add-environment": (
        "Usage:  skeema add-environment [<options>] <environment>",
        "Modifies the .skeema file in an existing host directory to add a new named environment.",
        "Add-Environment Options:\n  -d, --dir value              Base dir for this host's schemas (default \".\")\n  -h, --host value             Database hostname or IP address\n  -P, --port value             Port to use for database host (default \"3306\")\n  -S, --socket value           Absolute path to Unix socket file used if host is localhost (default \"/tmp/mysql.sock\")",
    ),
    "diff": (
        "Usage:  skeema diff [<options>] [<environment>]",
        "Compares the schemas on database server(s) to the corresponding filesystem representation of them.",
        "External Tool Options:\n  -x, --alter-wrapper value           Output ALTER TABLEs as shell commands rather than just raw DDL; see manual for template vars\n\nSQL Generation Options:\n      --exact-match                   Follow *.sql table definitions exactly, even for differences with no functional impact\n\nSafety Options:\n      --allow-unsafe                  Permit generating ALTER or DROP operations that are potentially destructive",
    ),
    "push": (
        "Usage:  skeema push [<options>] [<environment>]",
        "Modifies the schemas on database server(s) to match the corresponding filesystem representation of them.",
        "External Tool Options:\n  -x, --alter-wrapper value           External bin to shell out to for ALTER TABLE; see manual for template vars\n\nSafety Options:\n      --dry-run                       Output DDL but don't run it; equivalent to `skeema diff`",
    ),
    "pull": (
        "Usage:  skeema pull [<options>] [<environment>]",
        "Updates the existing filesystem representation of the schemas on a DB server.",
        "Pull Options:\n      --[skip-]format              Reformat SQL statements to match canonical SHOW CREATE (enabled by default; disable with --skip-format)\n      --[skip-]new-schemas         Detect any new schemas and populate new dirs for them (enabled by default; disable with --skip-new-schemas)",
    ),
    "lint": (
        "Usage:  skeema lint [<options>] [<environment>]",
        "Checks for problems in filesystem representation of database objects.",
        "Format Options:\n      --[skip-]format              Reformat SQL statements to match canonical SHOW CREATE (enabled by default; disable with --skip-format)\n\nLinter Rule Options:\n      --lint-pk value              Flag tables that lack a primary key (valid values: \"ignore\", \"warning\", \"error\") (default \"warning\")",
    ),
    "format": (
        "Usage:  skeema format [<options>] [<environment>]",
        "Reformats the filesystem representation of database objects to match the canonical format shown in SHOW CREATE.",
        "Format Options:\n      --strip-partitioning         Remove PARTITION BY clauses from *.sql files\n      --[skip-]write               Update files to correct format (enabled by default; disable with --skip-write)",
    ),
}


def timestamp():
    return datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")


def log(level, message):
    spaces = "  " if level in {"INFO", "WARN"} else " "
    print(f"{timestamp()} [{level}]{spaces}{message}")


def print_main_help():
    print(MAIN_HELP)


def print_command_help(command):
    if command == "help":
        print_main_help()
        return
    if command == "version":
        print()
        print("Usage:  skeema version [<options>]")
        print()
        print("Display program version")
        print()
        print("Global Options:")
        for line in MAIN_HELP.split("Global Options:", 1)[1].split("Complete documentation", 1)[0].strip("\n").splitlines():
            print(line)
        print()
        print("Complete documentation for this command is available online:")
        print("https://www.skeema.io/docs/commands/version")
        print()
        return
    usage, blurb, options = COMMAND_BLURBS[command]
    print()
    print(usage)
    print()
    print(blurb)
    print()
    print(options)
    print()
    print("Global Options:")
    for line in MAIN_HELP.split("Global Options:", 1)[1].split("Complete documentation", 1)[0].strip("\n").splitlines():
        print(line)
    print()
    print("Complete documentation for this command is available online:")
    print(f"https://www.skeema.io/docs/commands/{command}")
    print()


def normalize_option_name(arg):
    if arg.startswith("--"):
        return arg[2:].split("=", 1)[0]
    if arg.startswith("-"):
        return arg[1:]
    return arg


def parse_args(command, args):
    values = {}
    positionals = []
    i = 0
    value_opts = set(COMMAND_VALUE_OPTIONS.get(command, set())) | GLOBAL_VALUE_OPTIONS
    flags = set(COMMAND_FLAGS.get(command, set())) | GLOBAL_FLAGS
    while i < len(args):
        arg = args[i]
        if arg in ("--help", "-?"):
            print_command_help(command)
            sys.exit(0)
        if arg.startswith("--help="):
            target = arg.split("=", 1)[1]
            if target in COMMANDS:
                print_command_help(target)
                sys.exit(0)
        if arg.startswith("-"):
            opt = arg.split("=", 1)[0]
            if opt in value_opts:
                if "=" in arg:
                    values[opt] = arg.split("=", 1)[1]
                elif i + 1 < len(args):
                    values[opt] = args[i + 1]
                    i += 1
                else:
                    log("ERROR", f'CLI: Option "{normalize_option_name(opt)}" requires a value')
                    sys.exit(78)
            elif opt in flags:
                values[opt] = True
            else:
                log("ERROR", f'CLI: Unknown option "{normalize_option_name(opt)}"')
                sys.exit(78)
        else:
            positionals.append(arg)
        i += 1
    return values, positionals


def max_args(command):
    if command == "add-environment":
        return 1
    if command in {"init", "pull", "push", "diff", "lint", "format"}:
        return 1
    return 0


def enforce_arg_count(command, positionals):
    max_count = max_args(command)
    if len(positionals) > max_count:
        log("ERROR", f'Extra command-line arg "{positionals[max_count]}" supplied; command {command} takes a max of {max_count} args')
        sys.exit(78)
    if command == "add-environment" and not positionals:
        log("ERROR", "Command add-environment requires exactly 1 arg")
        sys.exit(78)


def command_add_environment(values, positionals):
    base_dir = values.get("-d") or values.get("--dir") or "."
    env = positionals[0]
    config_path = os.path.abspath(os.path.join(base_dir, ".skeema"))
    if not os.path.exists(config_path):
        log("ERROR", f"Dir {os.path.abspath(base_dir)} does not have an existing .skeema file! Can only use `skeema add-environment` on a dir previously created by `skeema init`")
        return 78

    host = values.get("-h") or values.get("--host")
    if not host:
        log("ERROR", "`skeema add-environment` requires --host to be supplied on command-line")
        return 78
    port = values.get("-P") or values.get("--port") or "3306"
    socket = values.get("-S") or values.get("--socket")
    with open(config_path, "r+", encoding="utf-8") as f:
        content = f.read()
        if content and not content.endswith("\n"):
            content += "\n"
        if content and not content.endswith("\n\n"):
            content += "\n"
        content += f"[{env}]\n"
        if host:
            content += f"host={host}\n"
        if socket:
            content += f"socket={socket}\n"
        else:
            content += f"port={port}\n"
        f.seek(0)
        f.write(content)
        f.truncate()

    log("WARN", f'Unable to automatically determine database server\'s vendor/version. To set manually, use the "flavor" option in {config_path}')
    log("INFO", f"Added environment [{env}] to {config_path}")
    return 0


def contains_sql_files(path):
    for _, _, files in os.walk(path):
        if any(name.endswith(".sql") for name in files):
            return True
    return False


def command_format(values):
    mode = "Checking format of" if values.get("--skip-write") else "Reformatting"
    log("INFO", f"{mode} {os.getcwd()}")
    if contains_sql_files(os.getcwd()):
        log("ERROR", f"Skipping {os.getcwd()}: Unable to connect to localhost:/tmp/mysql.sock for {os.getcwd()}: dial unix /tmp/mysql.sock: connect: no such file or directory")
        return 78
    return 0


def command_lint():
    log("INFO", f"Linting {os.getcwd()}")
    if contains_sql_files(os.getcwd()):
        log("ERROR", f"Skipping directory {os.path.basename(os.getcwd())} due to error: Unable to connect to localhost:/tmp/mysql.sock for {os.getcwd()}: dial unix /tmp/mysql.sock: connect: no such file or directory")
        log("ERROR", "Skipped 1 operation due to fatal errors")
        return 78
    return 0


def command_init(values):
    host = values.get("-h") or values.get("--host")
    if not host:
        log("ERROR", "Option --host must be supplied on the command-line")
        return 78
    target_dir = os.path.join(os.getcwd(), host)
    if host == "localhost":
        log("ERROR", f"Unable to connect to localhost:/tmp/mysql.sock for {target_dir}: dial unix /tmp/mysql.sock: connect: no such file or directory")
    else:
        log("ERROR", f"Unable to connect to {host}:3306 for {target_dir}: dial tcp: lookup {host}: connect: network is unreachable")
    return 2


def main(argv):
    debug = False
    if not argv:
        print_main_help()
        return 0

    if argv[0] == "--version":
        print(VERSION)
        return 0
    if argv[0].startswith("--help="):
        target = argv[0].split("=", 1)[1]
        if target in COMMANDS:
            print_command_help(target)
            return 0
        log("ERROR", f'Unknown command "{target}"')
        return 2
    if argv[0] in ("--help", "-?"):
        if len(argv) > 1 and argv[1] in COMMANDS:
            print_command_help(argv[1])
        else:
            print_main_help()
        return 0
    leading_values = {}
    while argv and argv[0].startswith("-") and argv[0] not in ("--help", "-?"):
        arg = argv.pop(0)
        if arg == "--version":
            print(VERSION)
            return 0
        if arg == "--debug":
            debug = True
            continue
        opt = arg.split("=", 1)[0]
        if opt in GLOBAL_VALUE_OPTIONS:
            if "=" in arg:
                leading_values[opt] = arg.split("=", 1)[1]
            elif argv:
                leading_values[opt] = argv.pop(0)
            else:
                log("ERROR", f'CLI: Option "{normalize_option_name(opt)}" requires a value')
                return 78
            continue
        if opt in GLOBAL_FLAGS:
            leading_values[opt] = True
            continue
        log("ERROR", f'CLI: Unknown option "{normalize_option_name(arg)}"')
        return 78
    if not argv:
        print_main_help()
        return 0

    command = argv[0]
    if command == "help":
        if len(argv) == 1:
            print_main_help()
            return 0
        target = argv[1]
        if target not in COMMANDS:
            log("ERROR", f'Unknown command "{target}"')
            return 2
        print_command_help(target)
        return 0
    if command not in COMMANDS:
        log("ERROR", f'Unknown command "{command}"')
        return 78
    if command == "version":
        values, positionals = parse_args(command, argv[1:])
        enforce_arg_count(command, positionals)
        print(VERSION)
        if debug:
            log("DEBUG", "Exit code 0 (SUCCESS)")
        return 0

    values, positionals = parse_args(command, argv[1:])
    values.update(leading_values)
    enforce_arg_count(command, positionals)

    if command == "add-environment":
        code = command_add_environment(values, positionals)
        if debug:
            status = "SUCCESS" if code == 0 else "ERROR"
            log("DEBUG", f"Exit code {code} ({status})")
        return code
    if command == "lint":
        code = command_lint()
        if debug:
            status = "SUCCESS" if code == 0 else "ERROR"
            log("DEBUG", f"Exit code {code} ({status})")
        return code
    if command == "format":
        code = command_format(values)
        if debug:
            status = "SUCCESS" if code == 0 else "ERROR"
            log("DEBUG", f"Exit code {code} ({status})")
        return code
    if command == "init":
        code = command_init(values)
        if debug:
            status = "SUCCESS" if code == 0 else "ERROR"
            log("DEBUG", f"Exit code {code} ({status})")
        return code
    if debug:
        log("DEBUG", "Exit code 0 (SUCCESS)")
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
