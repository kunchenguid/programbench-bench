#!/usr/bin/env python3
import argparse
import html
import os
import sys
from html.parser import HTMLParser
from urllib.parse import urljoin

VERSION = "htmlq 0.4.0"
VOID_TAGS = set("area base br col embed hr img input link meta param source track wbr".split())

class Text:
    def __init__(self, raw, text=None):
        self.raw = raw
        self.text = raw if text is None else text
        self.parent = None

class Element:
    def __init__(self, tag, attrs=None):
        self.tag = tag.lower()
        self.attrs = {k.lower(): ("" if v is None else v) for k, v in (attrs or [])}
        self.children = []
        self.parent = None

    def append(self, child):
        child.parent = self
        self.children.append(child)

class Parser(HTMLParser):
    def __init__(self):
        super().__init__(convert_charrefs=False)
        self.root = Element("document")
        self.stack = [self.root]

    def handle_starttag(self, tag, attrs):
        el = Element(tag, attrs)
        self.stack[-1].append(el)
        if el.tag not in VOID_TAGS:
            self.stack.append(el)

    def handle_startendtag(self, tag, attrs):
        self.stack[-1].append(Element(tag, attrs))

    def handle_endtag(self, tag):
        tag = tag.lower()
        for i in range(len(self.stack) - 1, 0, -1):
            if self.stack[i].tag == tag:
                del self.stack[i:]
                break

    def handle_data(self, data):
        if data:
            self.stack[-1].append(Text(data))

    def handle_entityref(self, name):
        raw = "&%s;" % name
        self.stack[-1].append(Text(raw, html.unescape(raw)))

    def handle_charref(self, name):
        raw = "&#%s;" % name
        self.stack[-1].append(Text(raw, html.unescape(raw)))

    def handle_comment(self, data):
        self.stack[-1].append(Text("<!--%s-->" % data, ""))


def parse_html(data):
    p = Parser()
    p.feed(data)
    p.close()
    normalize_document(p.root)
    return p.root

def normalize_document(root):
    html_el = next((c for c in root.children if isinstance(c, Element) and c.tag == "html"), None)
    if html_el is None:
        old_children = root.children
        html_el = Element("html")
        head = Element("head")
        body = Element("body")
        root.children = []
        root.append(html_el)
        html_el.append(head)
        html_el.append(body)
        for child in old_children:
            body.append(child)
        return
    has_head = any(isinstance(c, Element) and c.tag == "head" for c in html_el.children)
    body_index = next((i for i, c in enumerate(html_el.children) if isinstance(c, Element) and c.tag == "body"), None)
    if not has_head and body_index is not None:
        head = Element("head")
        head.parent = html_el
        html_el.children.insert(body_index, head)


def walk(node):
    for child in getattr(node, "children", []):
        if isinstance(child, Element):
            yield child
            yield from walk(child)


def descendants_or_self(root):
    if isinstance(root, Element) and root.tag != "document":
        yield root
    yield from walk(root)

class SimpleSelector:
    def __init__(self, tag=None, ident=None, classes=None, attrs=None, pseudos=None):
        self.tag = tag
        self.ident = ident
        self.classes = classes or []
        self.attrs = attrs or []
        self.pseudos = pseudos or []

    def matches(self, el):
        if self.tag and self.tag != "*" and el.tag != self.tag:
            return False
        if self.ident and el.attrs.get("id") != self.ident:
            return False
        have_classes = set(el.attrs.get("class", "").split())
        if any(c not in have_classes for c in self.classes):
            return False
        for name, op, value in self.attrs:
            if name not in el.attrs:
                return False
            if value is not None:
                actual = el.attrs.get(name, "")
                if op == "=" and actual != value:
                    return False
                if op == "~=" and value not in actual.split():
                    return False
                if op == "^=" and not actual.startswith(value):
                    return False
                if op == "$=" and not actual.endswith(value):
                    return False
                if op == "*=" and value not in actual:
                    return False
                if op == "|=" and not (actual == value or actual.startswith(value + "-")):
                    return False
        for name, arg in self.pseudos:
            siblings = element_siblings(el)
            index = siblings.index(el) + 1 if el in siblings else 0
            same_type = [s for s in siblings if s.tag == el.tag]
            type_index = same_type.index(el) + 1 if el in same_type else 0
            if name == "first-child" and index != 1:
                return False
            if name == "last-child" and index != len(siblings):
                return False
            if name == "nth-child" and not nth_matches(arg, index):
                return False
            if name == "nth-of-type" and not nth_matches(arg, type_index):
                return False
            if name not in ("first-child", "last-child", "nth-child", "nth-of-type"):
                return False
        return True

def element_siblings(el):
    if el.parent is None:
        return []
    return [c for c in el.parent.children if isinstance(c, Element)]

def nth_matches(expr, index):
    expr = (expr or "").strip().lower().replace(" ", "")
    if index <= 0:
        return False
    if expr == "odd":
        return index % 2 == 1
    if expr == "even":
        return index % 2 == 0
    try:
        return index == int(expr)
    except ValueError:
        pass
    if "n" not in expr:
        return False
    a_part, b_part = expr.split("n", 1)
    if a_part in ("", "+"):
        a = 1
    elif a_part == "-":
        a = -1
    else:
        try:
            a = int(a_part)
        except ValueError:
            return False
    b = int(b_part or "0")
    if a == 0:
        return index == b
    diff = index - b
    return diff // a >= 0 and diff % a == 0


def split_groups(selector):
    groups, buf, quote, depth = [], [], None, 0
    for ch in selector:
        if quote:
            buf.append(ch)
            if ch == quote:
                quote = None
        elif ch in "'\"":
            quote = ch; buf.append(ch)
        elif ch == "[":
            depth += 1; buf.append(ch)
        elif ch == "]":
            depth = max(0, depth - 1); buf.append(ch)
        elif ch == "," and depth == 0:
            g = "".join(buf).strip()
            if g: groups.append(g)
            buf = []
        else:
            buf.append(ch)
    g = "".join(buf).strip()
    if g: groups.append(g)
    return groups or ["html"]


def tokenize(selector):
    out, buf, quote, depth = [], [], None, 0
    pending = "desc"
    def flush():
        nonlocal buf, pending
        s = "".join(buf).strip()
        if s:
            out.append((pending, s))
            pending = "desc"
        buf = []
    for ch in selector:
        if quote:
            buf.append(ch)
            if ch == quote: quote = None
        elif ch in "'\"":
            quote = ch; buf.append(ch)
        elif ch == "[":
            depth += 1; buf.append(ch)
        elif ch == "]":
            depth = max(0, depth - 1); buf.append(ch)
        elif depth == 0 and ch in ">+~":
            flush(); pending = "child"
            if ch == "+":
                pending = "adjacent"
            elif ch == "~":
                pending = "sibling"
        elif depth == 0 and ch.isspace():
            flush()
        else:
            buf.append(ch)
    flush()
    return out


def parse_simple(s):
    if not s:
        return SimpleSelector(tag="__never__")
    i, tag, ident, classes, attrs, pseudos = 0, None, None, [], [], []
    if i < len(s) and (s[i].isalpha() or s[i] == "*"):
        start = i; i += 1
        while i < len(s) and (s[i].isalnum() or s[i] in "_-*"):
            i += 1
        tag = s[start:i].lower()
    while i < len(s):
        ch = s[i]
        if ch == "#":
            i += 1; start = i
            while i < len(s) and (s[i].isalnum() or s[i] in "_-:"):
                i += 1
            ident = s[start:i]
        elif ch == ".":
            i += 1; start = i
            while i < len(s) and (s[i].isalnum() or s[i] in "_-"):
                i += 1
            classes.append(s[start:i])
        elif ch == "[":
            end = s.find("]", i + 1)
            if end == -1:
                return SimpleSelector(tag="__never__")
            content = s[i+1:end].strip()
            op = None
            for candidate in ("~=", "^=", "$=", "*=", "|=", "="):
                if candidate in content:
                    op = candidate
                    break
            if op:
                name, value = content.split(op, 1)
                value = value.strip().strip('"\'')
                attrs.append((name.strip().lower(), op, html.unescape(value)))
            else:
                attrs.append((content.lower(), None, None))
            i = end + 1
        elif ch == ":":
            i += 1; start = i
            while i < len(s) and (s[i].isalnum() or s[i] == "-"):
                i += 1
            name = s[start:i]
            arg = None
            if i < len(s) and s[i] == "(":
                depth = 1; i += 1; start = i
                while i < len(s) and depth:
                    if s[i] == "(":
                        depth += 1
                    elif s[i] == ")":
                        depth -= 1
                        if depth == 0:
                            break
                    i += 1
                arg = s[start:i]
                if i < len(s) and s[i] == ")":
                    i += 1
            pseudos.append((name, arg))
        else:
            return SimpleSelector(tag="__never__")
    return SimpleSelector(tag, ident, classes, attrs, pseudos)


def select(root, selector):
    results = []
    seen = set()
    for group in split_groups(selector):
        current = [root]
        for comb, part in tokenize(group):
            simple = parse_simple(part)
            nxt = []
            for base in current:
                if comb == "child":
                    candidates = [c for c in getattr(base, "children", []) if isinstance(c, Element)]
                elif comb == "adjacent":
                    sibs = element_siblings(base)
                    pos = sibs.index(base) if base in sibs else -1
                    candidates = sibs[pos + 1:pos + 2] if pos >= 0 else []
                elif comb == "sibling":
                    sibs = element_siblings(base)
                    pos = sibs.index(base) if base in sibs else -1
                    candidates = sibs[pos + 1:] if pos >= 0 else []
                else:
                    candidates = descendants_or_self(base)
                for el in candidates:
                    if simple.matches(el):
                        nxt.append(el)
            current = nxt
        for el in current:
            if id(el) not in seen:
                seen.add(id(el)); results.append(el)
    return results


def detach(el):
    if el.parent is not None:
        el.parent.children = [c for c in el.parent.children if c is not el]
        el.parent = None


def serialize(node):
    if isinstance(node, Text):
        return node.raw
    attrs = "".join(' %s="%s"' % (k, html.escape(v, quote=True)) for k, v in sorted(node.attrs.items()))
    if node.tag in VOID_TAGS:
        return "<%s%s>" % (node.tag, attrs)
    return "<%s%s>%s</%s>" % (node.tag, attrs, "".join(serialize(c) for c in node.children), node.tag)

BLOCK_TAGS = set("""
html head body address article aside blockquote dd div dl dt fieldset figcaption
figure footer form h1 h2 h3 h4 h5 h6 header hr li main nav ol p pre section
table tbody td tfoot th thead tr ul
""".split())

def pretty_serialize(node, depth=0):
    if isinstance(node, Text):
        return "  " * depth + node.text + "\n"
    attrs = "".join(' %s="%s"' % (k, html.escape(v, quote=True)) for k, v in sorted(node.attrs.items()))
    pad = "  " * depth
    if node.tag in VOID_TAGS:
        return pad + "<%s%s>\n" % (node.tag, attrs)
    if not node.children:
        return pad + "<%s%s>\n%s</%s>\n" % (node.tag, attrs, pad, node.tag)
    if node.tag not in BLOCK_TAGS and len(node.children) == 1 and isinstance(node.children[0], Text):
        return pad + "<%s%s>\n%s%s</%s>\n" % (node.tag, attrs, "  " * (depth + 1), node.children[0].text, node.tag)
    out = [pad + "<%s%s>\n" % (node.tag, attrs)]
    for child in node.children:
        if isinstance(child, Text) and child.text.strip() == "":
            continue
        out.append(pretty_serialize(child, depth + 1))
    out.append(pad + "</%s>\n" % node.tag)
    return "".join(out)


def text_nodes(node):
    for child in getattr(node, "children", []):
        if isinstance(child, Text):
            if not child.raw.startswith("<!--"):
                yield child.text
        else:
            yield from text_nodes(child)


def find_base(root):
    for el in walk(root):
        if el.tag == "base" and "href" in el.attrs:
            return el.attrs["href"]
    return None

HELP = """htmlq 0.4.0
Michael Maclean <michael@mgdm.net>
Runs CSS selectors on HTML

USAGE:
    executable [FLAGS] [OPTIONS] [--] [selector]...

FLAGS:
    -B, --detect-base          Try to detect the base URL from the <base> tag in the document. If not found, default to
                               the value of --base, if supplied
    -h, --help                 Prints help information
    -w, --ignore-whitespace    When printing text nodes, ignore those that consist entirely of whitespace
    -p, --pretty               Pretty-print the serialised output
    -t, --text                 Output only the contents of text nodes inside selected elements
    -V, --version              Prints version information

OPTIONS:
    -a, --attribute <attribute>         Only return this attribute (if present) from selected elements
    -b, --base <base>                   Use this URL as the base for links
    -f, --filename <FILE>               The input file. Defaults to stdin
    -o, --output <FILE>                 The output file. Defaults to stdout
    -r, --remove-nodes <SELECTOR>...    Remove nodes matching this expression before output. May be specified multiple
                                        times

ARGS:
    <selector>...    The CSS expression to select [default: html]
"""

def parse_args(argv):
    if "--help" in argv or "-h" in argv:
        print(HELP, end="")
        raise SystemExit(0)
    if "--version" in argv or "-V" in argv:
        print(VERSION)
        raise SystemExit(0)
    ap = argparse.ArgumentParser(add_help=False, prog="executable")
    ap.add_argument("-t", "--text", action="store_true")
    ap.add_argument("-p", "--pretty", action="store_true")
    ap.add_argument("-w", "--ignore-whitespace", action="store_true")
    ap.add_argument("-B", "--detect-base", action="store_true")
    ap.add_argument("-a", "--attribute")
    ap.add_argument("-b", "--base")
    ap.add_argument("-f", "--filename")
    ap.add_argument("-o", "--output")
    ap.add_argument("-r", "--remove-nodes", action="append", nargs="+")
    ap.add_argument("selector", nargs="*")
    try:
        return ap.parse_args(argv)
    except SystemExit as e:
        sys.stderr.write("error: Found argument '%s' which wasn't expected, or isn't valid in this context\n" % (argv[0] if argv else ""))
        raise


def main(argv=None):
    argv = sys.argv[1:] if argv is None else argv
    ns = parse_args(argv)
    if ns.filename:
        with open(ns.filename, "r", encoding="utf-8") as f:
            data = f.read()
    else:
        data = sys.stdin.read()
    root = parse_html(data)
    for group in ns.remove_nodes or []:
        for rem_sel in group:
            for el in list(select(root, rem_sel)):
                detach(el)
    selector = " ".join(ns.selector) if ns.selector else "html"
    matches = select(root, selector)
    base = find_base(root) if ns.detect_base else ns.base
    out = []
    for el in matches:
        if ns.attribute:
            key = ns.attribute.lower()
            if key in el.attrs:
                val = el.attrs[key]
                if base and key in ("href", "src"):
                    val = urljoin(base, val)
                out.append(val + "\n")
        elif ns.text:
            for t in text_nodes(el):
                if ns.ignore_whitespace and t.strip() == "":
                    continue
                out.append(t + "\n")
            out.append("\n")
        else:
            if ns.pretty:
                out.append("\n" + pretty_serialize(el))
            else:
                out.append(serialize(el) + "\n")
    output = "".join(out)
    if ns.output:
        with open(ns.output, "w", encoding="utf-8") as f:
            f.write(output)
    else:
        sys.stdout.write(output)
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
