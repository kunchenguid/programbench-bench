import os
import subprocess
import sys
import tempfile
import unittest

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
BIN = os.path.join(ROOT, "htmlq.py")

SAMPLE = """<!doctype html>
<html><head><title>Hi &amp; Bye</title><base href="https://example.com/dir/page.html"></head>
<body>
  <main id="m" class="content one">
    <h1>Hello <em>World</em></h1>
    <a id="rel" href="sub/x.html">Link</a>
    <a id="abs" href="https://other.test/z">Abs</a>
    <img src="/img.png" alt="Image Alt">
    <p class="intro">First <span data-x="1">Span</span></p>
    <p class="intro remove">Second</p>
  </main>
</body></html>
"""

class CliTests(unittest.TestCase):
    def run_cli(self, args, stdin=None):
        return subprocess.run(
            [sys.executable, BIN] + args,
            input=stdin,
            text=True,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
        )

    def test_selects_elements_serializes_attributes_and_text(self):
        with tempfile.NamedTemporaryFile("w", delete=False, suffix=".html") as f:
            f.write(SAMPLE)
            name = f.name
        try:
            title = self.run_cli(["-f", name, "title"])
            self.assertEqual(title.returncode, 0, title.stderr)
            self.assertEqual(title.stdout, "<title>Hi &amp; Bye</title>\n")

            links = self.run_cli(["-f", name, "-a", "href", "a"])
            self.assertEqual(links.returncode, 0, links.stderr)
            self.assertEqual(links.stdout, "sub/x.html\nhttps://other.test/z\n")

            text = self.run_cli(["-f", name, "-tw", "#m"])
            self.assertEqual(text.returncode, 0, text.stderr)
            self.assertEqual(text.stdout, "Hello \nWorld\nLink\nAbs\nFirst \nSpan\nSecond\n\n")
        finally:
            os.unlink(name)

    def test_default_selector_normalizes_missing_head(self):
        result = self.run_cli([], "<html><body><b>B</b></body></html>")
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertEqual(result.stdout, "<html><head></head><body><b>B</b></body></html>\n")

    def test_default_selector_wraps_fragments_in_html_body(self):
        result = self.run_cli([], "<div><p>A</p></div>")
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertEqual(result.stdout, "<html><head></head><body><div><p>A</p></div></body></html>\n")

    def test_pretty_prints_block_fragments(self):
        result = self.run_cli(["-p"], "<div><p>A</p><p>B</p></div>")
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertEqual(
            result.stdout,
            "\n<html>\n"
            "  <head>\n"
            "  </head>\n"
            "  <body>\n"
            "    <div>\n"
            "      <p>\n"
            "        A\n"
            "      </p>\n"
            "      <p>\n"
            "        B\n"
            "      </p>\n"
            "    </div>\n"
            "  </body>\n"
            "</html>\n",
        )

    def test_common_css_combinators_pseudos_and_attribute_operators(self):
        html = (
            '<html><body><ul><li class="a">One</li><li class="b">Two</li>'
            '<li class="a b" data-val="abc-def x">Three</li></ul>'
            '<div><p>A</p><span>S</span><p>B</p></div></body></html>'
        )
        with tempfile.NamedTemporaryFile("w", delete=False, suffix=".html") as f:
            f.write(html)
            name = f.name
        try:
            cases = {
                "li:first-child": '<li class="a">One</li>\n',
                "li:last-child": '<li class="a b" data-val="abc-def x">Three</li>\n',
                "li:nth-child(2)": '<li class="b">Two</li>\n',
                "li:nth-of-type(2)": '<li class="b">Two</li>\n',
                "p + span": '<span>S</span>\n',
                "p ~ p": '<p>B</p>\n',
                "[data-val~=x]": '<li class="a b" data-val="abc-def x">Three</li>\n',
                "[data-val^=abc]": '<li class="a b" data-val="abc-def x">Three</li>\n',
                "[data-val$=x]": '<li class="a b" data-val="abc-def x">Three</li>\n',
                "[data-val*=def]": '<li class="a b" data-val="abc-def x">Three</li>\n',
                "[data-val|=abc]": '<li class="a b" data-val="abc-def x">Three</li>\n',
            }
            for selector, expected in cases.items():
                with self.subTest(selector=selector):
                    result = self.run_cli(["-f", name, selector])
                    self.assertEqual(result.returncode, 0, result.stderr)
                    self.assertEqual(result.stdout, expected)
        finally:
            os.unlink(name)

if __name__ == "__main__":
    unittest.main()
