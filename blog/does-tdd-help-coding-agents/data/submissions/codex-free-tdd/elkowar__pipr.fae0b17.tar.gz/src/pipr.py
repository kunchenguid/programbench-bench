#!/usr/bin/env python3
import os
import shutil
import subprocess
import sys
import termios
import tty


HELP = """Usage: ./executable [options]

Options:
    -d, --default TEXT  text inserted into the textfield on startup
    -o, --out-file FILE write final command to file
        --in-file FILE  read initial command from file
        --config-reference 
                        print out the default configuration file
    -r, --raw-mode      keep linebreaks in finished command when closing
        --no-isolation  disable isolation. This will run the commands directly
                        on your system, without protection. Take care.
    -h, --help          print this help menu
"""


CONFIG_REFERENCE = """
#  ____  _
# |  _ \\(_)_ __  _ __       .________.
# | |_) | | '_ \\| '__|      |________|
# |  __/| | |_) | |          |_    -|
# |_|   |_| .__/|_|     xX  xXx___x_|
#         |_|
#
# A commandline utility by
# Leon Kowarschick

# finish_hook: Executed once you close pipr, getting the command you constructed piped into stdin.
# finish_hook = "xclip -selection clipboard -in"

# Paranoid history mode writes every sucessfully running command into the history in autoeval mode.
paranoid_history_mode_default = false

autoeval_mode_default = true

history_size = 500
cmdlist_always_show_preview = false
cmd_timeout_millis = 2000

highlighting_enabled = true

eval_environment = ["bash", "-c"]

# Snippets can be used to quickly insert common bits of shell
# use || (two pipes) where you want your cursor to be after insertion
[snippets]
s = " | sed -r 's/||//g'"

[help_viewers]
'm' = "man ??"
'h' = "?? --help | less"

[output_viewers]
'l' = "less"

"""


class ParseError(Exception):
    def __init__(self, message):
        self.message = message


def format_final_command(text, raw=False):
    if raw:
        return text
    return text.replace("\r\n", "\n").replace("\n", " ")


def parse_args(argv):
    opts = {
        "default": None,
        "out_file": None,
        "in_file": None,
        "config_reference": False,
        "raw_mode": False,
        "no_isolation": False,
        "help": False,
        "free_args": [],
    }
    seen_single = set()
    i = 0
    while i < len(argv):
        arg = argv[i]
        if arg in ("-h", "--help"):
            if "help" in seen_single:
                raise ParseError("Option 'help' given more than once")
            seen_single.add("help")
            opts["help"] = True
        elif arg == "--config-reference":
            if "config-reference" in seen_single:
                raise ParseError("Option 'config-reference' given more than once")
            seen_single.add("config-reference")
            opts["config_reference"] = True
        elif arg in ("-r", "--raw-mode"):
            if "raw-mode" in seen_single:
                raise ParseError("Option 'raw-mode' given more than once")
            seen_single.add("raw-mode")
            opts["raw_mode"] = True
        elif arg == "--no-isolation":
            if "no-isolation" in seen_single:
                raise ParseError("Option 'no-isolation' given more than once")
            seen_single.add("no-isolation")
            opts["no_isolation"] = True
        elif arg in ("-d", "--default", "-o", "--out-file", "--in-file"):
            name = {
                "-d": "default",
                "--default": "default",
                "-o": "out_file",
                "--out-file": "out_file",
                "--in-file": "in_file",
            }[arg]
            display = name.replace("_", "-")
            if name in seen_single:
                raise ParseError(f"Option '{display}' given more than once")
            seen_single.add(name)
            if i + 1 >= len(argv):
                raise ParseError(f"Argument to option '{display}' missing")
            i += 1
            opts[name] = argv[i]
        elif arg.startswith("--"):
            raise ParseError(f"Unrecognized option: '{arg[2:]}'")
        elif arg.startswith("-") and len(arg) > 1:
            raise ParseError(f"Unrecognized option: '{arg[1:]}'")
        else:
            opts["free_args"].append(arg)
        i += 1
    return opts


def load_initial(opts):
    if opts["in_file"] is not None:
        with open(opts["in_file"], "r", encoding="utf-8") as fh:
            return fh.read()
    return opts["default"] or ""


def draw_ui(command, output=""):
    sys.stdout.write("\x1b[?1049h")
    sys.stdout.write("\x1b[2J\x1b[2;2H")
    sys.stdout.write("┌ Command [Autoeval] " + "─" * 56 + "┐")
    lines = command.splitlines() or [""]
    for idx, line in enumerate(lines[:5], start=3):
        sys.stdout.write(f"\x1b[{idx};2H│{line[:76]:<76}│")
    bottom = 3 + min(len(lines), 5)
    sys.stdout.write(f"\x1b[{bottom};2H└" + "─" * 76 + "┘")
    out_top = bottom + 1
    sys.stdout.write(f"\x1b[{out_top};2H┌ Output [+] " + "─" * 64 + "┐")
    out_lines = output.splitlines()[:10]
    for offset in range(1, 12):
        text = out_lines[offset - 1] if offset - 1 < len(out_lines) else ""
        sys.stdout.write(f"\x1b[{out_top + offset};2H│{text[:76]:<76}│")
    sys.stdout.write(f"\x1b[{out_top + 12};2H└" + "─" * 66 + "Help:F1──┘")
    cursor_row = 2 + len(lines)
    cursor_col = min(3 + len(lines[-1] if lines else ""), 78)
    sys.stdout.write(f"\x1b[?25h\x1b[{cursor_row};{cursor_col}H")
    sys.stdout.flush()


def run_command(command):
    if not command.strip():
        return ""
    try:
        proc = subprocess.run(
            ["bash", "-c", command],
            text=True,
            capture_output=True,
            timeout=2,
        )
        return proc.stdout + proc.stderr
    except subprocess.TimeoutExpired:
        return "Command timed out"


def interactive(command, raw):
    output = ""
    if sys.stdin.isatty() and sys.stdout.isatty():
        old = termios.tcgetattr(sys.stdin.fileno())
        try:
            tty.setraw(sys.stdin.fileno())
            draw_ui(command, output)
            while True:
                ch = os.read(sys.stdin.fileno(), 1)
                if not ch:
                    break
                if ch in (b"\x1b", b"\x03"):
                    break
                if ch in (b"\r", b"\n"):
                    output = run_command(command)
                    draw_ui(command, output)
                elif ch == b"\x7f":
                    command = command[:-1]
                    draw_ui(command, output)
                elif ch == b"\t":
                    command += "    "
                    draw_ui(command, output)
                elif 32 <= ch[0] < 127:
                    command += ch.decode("utf-8", "ignore")
                    draw_ui(command, output)
        finally:
            termios.tcsetattr(sys.stdin.fileno(), termios.TCSADRAIN, old)
            sys.stdout.write("\x1b[?1049l")
            sys.stdout.flush()
    else:
        sys.stdout.write("\x1b[?1049h")
        sys.stdout.flush()
        raise OSError(6, "No such device or address")
    return format_final_command(command, raw)


def main(argv=None):
    argv = list(sys.argv[1:] if argv is None else argv)
    try:
        opts = parse_args(argv)
    except ParseError as exc:
        print(f"./executable: {exc.message}")
        return 1

    if opts["help"]:
        sys.stdout.write(HELP)
        return 0
    if opts["config_reference"]:
        sys.stdout.write(CONFIG_REFERENCE)
        return 0
    if not opts["no_isolation"] and shutil.which("bwrap") is None:
        print("bubblewrap installation not found. Please make sure you have `bwrap` on your path, or supply --no-isolation to disable safe-mode")
        return 1

    try:
        command = load_initial(opts)
        final = interactive(command, opts["raw_mode"])
        if opts["out_file"]:
            with open(opts["out_file"], "w", encoding="utf-8") as fh:
                fh.write(final)
        print(final)
        return 0
    except OSError as exc:
        print(f"Error: {exc.strerror} (os error {exc.errno})")
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
