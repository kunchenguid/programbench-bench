#!/usr/bin/env python3
import os
import re
import subprocess
import sys
import tempfile

HELP = """nsh 0.4.2
A command-line shell that focuses on performance and productivity.

USAGE:
    executable [FLAGS] [OPTIONS] [FILE]

FLAGS:
    -h, --help       Prints help information
    -l, --login      Behave like a login shell
        --norc       Don't load nshrc
        --version    Print the version

OPTIONS:
    -c <command>        The command to be executed

ARGS:
    <FILE>    The file to be executed
"""


def usage(context=None):
    if context == "command":
        return "USAGE:\n    executable -c <command>\n\nFor more information try --help\n"
    return "USAGE:\n    executable [FLAGS] [OPTIONS] [FILE]\n\nFor more information try --help\n"


def error(message, context=None):
    sys.stderr.write(f"error: {message}\n\n{usage(context)}")
    return 1


def rc_path():
    xdg = os.environ.get("XDG_CONFIG_HOME")
    if xdg:
        p = os.path.join(xdg, "nsh", "nshrc")
        if os.path.exists(p):
            return p
    home = os.environ.get("HOME")
    if home:
        p = os.path.join(home, ".nshrc")
        if os.path.exists(p):
            return p
    return None


def translate_stderr(data):
    out = []
    for line in data.splitlines(True):
        if ": command not found" in line:
            match = re.search(r":\s*([^:]+): command not found", line)
            cmd = match.group(1).strip() if match else line.replace("command not found", "").strip(" :\n")
            out.append(f"nsh: command not found `{cmd}'\n")
        elif "no match:" in line:
            out.append("nsh: error: no matches\n")
        else:
            out.append(line)
    return "".join(out)


def run_command(command, load_rc):
    prelude = ["shopt -s expand_aliases", "shopt -s failglob"]
    path = rc_path() if load_rc else None
    if path:
        prelude.append(f"source {shell_quote(path)}")
    script = "\n".join(prelude + [command, ""])
    with tempfile.NamedTemporaryFile("w", delete=False, prefix="nsh-", suffix=".bash") as f:
        f.write(script)
        name = f.name
    try:
        proc = subprocess.run(["bash", name], text=True, capture_output=True)
    finally:
        try:
            os.unlink(name)
        except OSError:
            pass
    sys.stdout.write(proc.stdout)
    sys.stderr.write(translate_stderr(proc.stderr))
    if proc.returncode == 127 and "command not found" in proc.stderr:
        return 1
    return proc.returncode


def shell_quote(s):
    return "'" + s.replace("'", "'\\''") + "'"


def run_file(path):
    return subprocess.call(["bash", "-c", f"source {shell_quote(path)}", "bash"])


def main(argv):
    load_rc = True
    login = False
    command = None
    files = []
    i = 0
    while i < len(argv):
        arg = argv[i]
        if arg in ("-h", "--help"):
            sys.stdout.write(HELP)
            return 0
        if arg == "--version":
            sys.stdout.write("0.4.2\n")
            return 0
        if arg in ("-l", "--login"):
            login = True
            i += 1
            continue
        if arg == "-lc":
            login = True
            if i + 1 >= len(argv):
                return error("The argument '-c <command>' requires a value but none was supplied", "command")
            command = argv[i + 1]
            i += 2
            continue
        if arg.startswith("-c") and len(arg) > 2:
            command = arg[2:]
            i += 1
            continue
        if arg == "--norc":
            load_rc = False
            i += 1
            continue
        if arg == "-c":
            if i + 1 >= len(argv):
                return error("The argument '-c <command>' requires a value but none was supplied", "command")
            command = argv[i + 1]
            i += 2
            continue
        if arg.startswith("-"):
            return error(f"Found argument '{arg}' which wasn't expected, or isn't valid in this context")
        files.append(arg)
        i += 1
    if command is not None:
        if len(files) > 1:
            return error(f"Found argument '{files[1]}' which wasn't expected, or isn't valid in this context", "command")
        return run_command(command, load_rc)
    if len(files) > 1:
        return error(f"Found argument '{files[1]}' which wasn't expected, or isn't valid in this context")
    if files:
        return run_file(files[0])
    if not sys.stdout.isatty():
        sys.stderr.write("nsh: warning: stdout is not a tty\n")
        return 0
    if login:
        return subprocess.call(["bash", "-l"])
    return subprocess.call(["bash"])


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
