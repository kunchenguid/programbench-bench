import os
import subprocess
import tempfile
import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
BIN = ROOT / "executable"


def run(args, env=None):
    if not BIN.exists():
        raise AssertionError("expected ./executable to exist; run ./compile.sh before tests")
    merged_env = os.environ.copy()
    if env:
        merged_env.update(env)
    return subprocess.run(
        [str(BIN), *args],
        cwd=ROOT,
        env=merged_env,
        text=True,
        capture_output=True,
    )


class BartibCharacterizationTests(unittest.TestCase):
    def test_start_and_stop_write_bartib_log(self):
        with tempfile.TemporaryDirectory() as tmp:
            log = Path(tmp) / "activities.bartib"

            started = run(["-f", str(log), "start", "-d", "Task A", "-p", "Proj X", "-t", "09:05"])
            self.assertEqual(started.returncode, 0)
            self.assertEqual(started.stdout, 'Started activity: "Task A" (Proj X) at 2026-06-05 09:05\n')
            self.assertEqual(log.read_text(), "2026-06-05 09:05 | Proj X | Task A\n")

            stopped = run(["-f", str(log), "stop", "-t", "10:40"])
            self.assertEqual(stopped.returncode, 0)
            self.assertIn('Stopped activity: "Task A" (Proj X) started at 2026-06-05 09:05 (1h 35m)', stopped.stdout)
            self.assertEqual(log.read_text(), "2026-06-05 09:05 - 2026-06-05 10:40 | Proj X | Task A\n")

    def test_projects_current_and_last_use_existing_log(self):
        with tempfile.TemporaryDirectory() as tmp:
            log = Path(tmp) / "activities.bartib"
            log.write_text(
                "2026-06-01 08:00 - 2026-06-01 09:00 | A | alpha\n"
                "2026-06-02 09:15 - 2026-06-02 10:45 | B | beta\n"
                "2026-06-05 11:00 | A | open task\n"
            )

            projects = run(["-f", str(log), "projects", "--no-quotes"])
            self.assertEqual(projects.returncode, 0)
            self.assertEqual(projects.stdout, "A\nB\n")

            current_projects = run(["-f", str(log), "projects", "--current", "--no-quotes"])
            self.assertEqual(current_projects.returncode, 0)
            self.assertEqual(current_projects.stdout, "A\n")

            last = run(["-f", str(log), "last", "-n", "2"])
            self.assertEqual(last.returncode, 0)
            self.assertIn("[1]", last.stdout)
            self.assertIn("beta", last.stdout)
            self.assertIn("B", last.stdout)
            self.assertIn("[0]", last.stdout)
            self.assertIn("open task", last.stdout)
            self.assertIn("A", last.stdout)

    def test_list_report_search_and_continue(self):
        with tempfile.TemporaryDirectory() as tmp:
            log = Path(tmp) / "activities.bartib"
            log.write_text(
                "2026-06-01 08:00 - 2026-06-01 09:00 | A | alpha\n"
                "2026-06-02 09:15 - 2026-06-02 10:45 | B | beta\n"
                "2026-06-05 11:00 | A | open task\n"
            )

            listing = run(["-f", str(log), "list", "--date", "2026-06-01", "--no_grouping"])
            self.assertEqual(listing.returncode, 0)
            self.assertIn("08:00", listing.stdout)
            self.assertIn("09:00", listing.stdout)
            self.assertIn("alpha", listing.stdout)
            self.assertIn("1h 00m", listing.stdout)
            self.assertNotIn("beta", listing.stdout)

            report = run(["-f", str(log), "report", "--from", "2026-06-01", "--to", "2026-06-02"])
            self.assertEqual(report.returncode, 0)
            self.assertIn("A", report.stdout)
            self.assertIn("alpha", report.stdout)
            self.assertIn("1h 00m", report.stdout)
            self.assertIn("B", report.stdout)
            self.assertIn("beta", report.stdout)
            self.assertIn("1h 30m", report.stdout)
            self.assertIn("Total", report.stdout)
            self.assertIn("2h 30m", report.stdout)

            search = run(["-f", str(log), "search", "be"])
            self.assertEqual(search.returncode, 0)
            self.assertIn("[0]", search.stdout)
            self.assertIn("beta", search.stdout)

            continued = run(["-f", str(log), "continue", "1", "-t", "12:00"])
            self.assertEqual(continued.returncode, 0)
            self.assertIn('Stopped activity: "open task" (A)', continued.stdout)
            self.assertIn('Started activity: "beta" (B) at 2026-06-05 12:00', continued.stdout)
            self.assertTrue(log.read_text().endswith("2026-06-05 12:00 | B | beta\n"))

    def test_check_reports_parse_errors(self):
        with tempfile.TemporaryDirectory() as tmp:
            log = Path(tmp) / "bad.bartib"
            log.write_text("bad line\n")

            checked = run(["-f", str(log), "check"])
            self.assertEqual(checked.returncode, 0)
            self.assertIn("Found 1 line(s) with parsing errors", checked.stdout)
            self.assertIn("bad line", checked.stdout)


if __name__ == "__main__":
    unittest.main()
