#!/usr/bin/env python3
import os
import re
import subprocess
import sys
from collections import OrderedDict
from dataclasses import dataclass
from datetime import date, datetime, time, timedelta


VERSION = """bartib 1.1.0
Nikolas Schmidt-Voigt <nikolas.schmidt-voigt@posteo.de>
A simple timetracker
"""

TOP_HELP = """bartib 1.1.0
Nikolas Schmidt-Voigt <nikolas.schmidt-voigt@posteo.de>
A simple timetracker

USAGE:
    executable [OPTIONS] <SUBCOMMAND>

FLAGS:
    -h, --help       Prints help information
    -V, --version    Prints version information

OPTIONS:
    -f <FILE>        the file in which bartib tracks all the activities [env: BARTIB_FILE=]

SUBCOMMANDS:
    cancel      cancels all currently running activities
    change      changes the current activity
    check       checks file and reports parsing errors
    continue    continues a previous activity
    current     lists all currently running activities
    edit        opens the activity log in an editor
    help        Prints this message or the help of the given subcommand(s)
    last        displays the descriptions and projects of recent activities
    list        list recent activities
    projects    list all projects
    report      reports duration of tracked activities
    sanity      checks sanity of bartib log
    search      search for existing descriptions and projects
    start       starts a new activity
    status      shows current status and time reports for today, current week, and current month
    stop        stops all currently running activities

To get help for a specific subcommand, run `bartib [SUBCOMMAND] --help`.
To get started, view the `start` help with `bartib start --help`
"""

HELP = {
    "start": """executable-start 
starts a new activity

USAGE:
    executable start [OPTIONS] --description <DESCRIPTION> --project <PROJECT>

FLAGS:
    -h, --help    Prints help information

OPTIONS:
    -d, --description <DESCRIPTION>    the description of the new activity
    -p, --project <PROJECT>            the project to which the new activity belongs
    -t, --time <TIME>                  the time for changing the activity status (HH:MM)
""",
    "stop": """executable-stop 
stops all currently running activities

USAGE:
    executable stop [OPTIONS]

FLAGS:
    -h, --help    Prints help information

OPTIONS:
    -t, --time <TIME>    the time for changing the activity status (HH:MM)
""",
    "projects": """executable-projects 
list all projects

USAGE:
    executable projects [FLAGS]

FLAGS:
    -c, --current      prints currently running projects only
    -h, --help         Prints help information
    -n, --no-quotes    prints projects without quotes
""",
}

LINE_RE = re.compile(
    r"^(?P<start>\d{4}-\d{2}-\d{2} \d{2}:\d{2})(?: - (?P<stop>\d{4}-\d{2}-\d{2} \d{2}:\d{2}))? \| (?P<project>.*?) \| (?P<description>.*)$"
)


@dataclass
class Activity:
    start: datetime
    stop: datetime | None
    project: str
    description: str
    raw: str = ""
    line_no: int = 0

    @property
    def running(self) -> bool:
        return self.stop is None

    def duration_minutes(self, now: datetime | None = None) -> int:
        end = self.stop or now or datetime.now().replace(second=0, microsecond=0)
        return max(0, int((end - self.start).total_seconds() // 60))

    def format_line(self) -> str:
        if self.stop:
            return f"{fmt_dt(self.start)} - {fmt_dt(self.stop)} | {self.project} | {self.description}"
        return f"{fmt_dt(self.start)} | {self.project} | {self.description}"


def fmt_dt(value: datetime) -> str:
    return value.strftime("%Y-%m-%d %H:%M")


def parse_dt(text: str) -> datetime:
    return datetime.strptime(text, "%Y-%m-%d %H:%M")


def today() -> date:
    return datetime.now().date()


def command_time(value: str | None) -> datetime:
    d = today()
    if value:
        hour, minute = map(int, value.split(":", 1))
        return datetime.combine(d, time(hour, minute))
    return datetime.now().replace(second=0, microsecond=0)


def format_duration(minutes: int) -> str:
    if minutes < 1:
        return "<1m"
    hours, mins = divmod(minutes, 60)
    if hours:
        return f"{hours}h {mins:02d}m"
    return f"{mins}m"


def parse_file(path: str, missing_ok: bool = False):
    activities = []
    errors = []
    try:
        with open(path, encoding="utf-8") as fh:
            lines = fh.read().splitlines()
    except FileNotFoundError:
        if missing_ok:
            return activities, errors
        raise
    for idx, line in enumerate(lines, 1):
        match = LINE_RE.match(line)
        if not match:
            errors.append((idx, line, "could not parse activity"))
            continue
        try:
            stop = parse_dt(match.group("stop")) if match.group("stop") else None
            activities.append(
                Activity(
                    parse_dt(match.group("start")),
                    stop,
                    match.group("project"),
                    match.group("description"),
                    line,
                    idx,
                )
            )
        except ValueError:
            errors.append((idx, line, "could not parse activity"))
    return activities, errors


def write_file(path: str, activities):
    directory = os.path.dirname(path)
    if directory:
        os.makedirs(directory, exist_ok=True)
    with open(path, "w", encoding="utf-8") as fh:
        for activity in activities:
            fh.write(activity.format_line() + "\n")


def need_file(path: str):
    if not path:
        print("Error: No tracking file configured. Use -f or BARTIB_FILE.", file=sys.stderr)
        sys.exit(1)


def parse_global(argv):
    path = os.environ.get("BARTIB_FILE", "")
    rest = []
    i = 0
    while i < len(argv):
        arg = argv[i]
        if arg == "-f":
            if i + 1 >= len(argv):
                print("error: The argument '-f <FILE>' requires a value", file=sys.stderr)
                sys.exit(1)
            path = argv[i + 1]
            i += 2
        elif arg in ("-h", "--help"):
            print(TOP_HELP, end="")
            sys.exit(0)
        elif arg in ("-V", "--version"):
            print(VERSION, end="")
            sys.exit(0)
        else:
            rest = argv[i:]
            break
    return path, rest


def option_value(args, shorts, longs, default=None):
    for idx, arg in enumerate(args):
        if arg in shorts or arg in longs:
            if idx + 1 < len(args):
                return args[idx + 1]
    return default


def has_flag(args, names):
    return any(arg in names for arg in args)


def unique_pairs(activities):
    seen = set()
    pairs = []
    for activity in reversed(activities):
        pair = (activity.description, activity.project)
        if pair not in seen:
            seen.add(pair)
            pairs.append(pair)
    return pairs


def date_range(args):
    d = option_value(args, ["-d"], ["--date"])
    if has_flag(args, ["--today"]):
        d = str(today())
    if has_flag(args, ["--yesterday"]):
        d = str(today() - timedelta(days=1))
    if d:
        one = datetime.strptime(d, "%Y-%m-%d").date()
        return one, one, True
    start = option_value(args, [], ["--from"])
    end = option_value(args, [], ["--to"])
    if has_flag(args, ["--current_week"]):
        start_date = today() - timedelta(days=today().weekday())
        return start_date, start_date + timedelta(days=6), False
    if has_flag(args, ["--last_week"]):
        this_monday = today() - timedelta(days=today().weekday())
        return this_monday - timedelta(days=7), this_monday - timedelta(days=1), False
    return (
        datetime.strptime(start, "%Y-%m-%d").date() if start else None,
        datetime.strptime(end, "%Y-%m-%d").date() if end else None,
        False,
    )


def filtered(activities, args):
    start, end, single = date_range(args)
    project = option_value(args, ["-p"], ["--project"])
    result = []
    for activity in activities:
        if project and activity.project != project:
            continue
        adate = activity.start.date()
        if start and adate < start:
            continue
        if end and adate > end:
            continue
        result.append(activity)
    number = option_value(args, ["-n"], ["--number"])
    if number:
        result = result[-int(number):]
    return result, single


def stop_running(activities, when):
    messages = []
    for activity in activities:
        if activity.running:
            activity.stop = when
            messages.append(
                f'Stopped activity: "{activity.description}" ({activity.project}) started at {fmt_dt(activity.start)} ({format_duration(activity.duration_minutes())})'
            )
    return messages


def cmd_start(path, args):
    desc = option_value(args, ["-d"], ["--description"])
    project = option_value(args, ["-p"], ["--project"])
    if not desc or not project:
        missing = "--description <DESCRIPTION>" if not desc else "--project <PROJECT>"
        print(f"error: The following required arguments were not provided:\n    {missing}\n", file=sys.stderr)
        return 1
    when = command_time(option_value(args, ["-t"], ["--time"]))
    activities, _ = parse_file(path, missing_ok=True)
    messages = stop_running(activities, when)
    activity = Activity(when, None, project, desc)
    activities.append(activity)
    write_file(path, activities)
    for message in messages:
        print(message)
    print(f'Started activity: "{desc}" ({project}) at {fmt_dt(when)}')
    return 0


def cmd_stop(path, args):
    activities, _ = parse_file(path, missing_ok=True)
    messages = stop_running(activities, command_time(option_value(args, ["-t"], ["--time"])))
    write_file(path, activities)
    for message in messages:
        print(message)
    return 0


def cmd_cancel(path, args):
    activities, _ = parse_file(path, missing_ok=True)
    kept = [activity for activity in activities if not activity.running]
    write_file(path, kept)
    return 0


def cmd_change(path, args):
    activities, _ = parse_file(path, missing_ok=True)
    when = command_time(option_value(args, ["-t"], ["--time"]))
    desc = option_value(args, ["-d"], ["--description"])
    project = option_value(args, ["-p"], ["--project"])
    activities = [activity for activity in activities if not activity.running]
    if desc and project:
        activities.append(Activity(when, None, project, desc))
        write_file(path, activities)
        print(f'Changed activity: "{desc}" ({project}) started at {fmt_dt(when)}')
    return 0


def cmd_continue(path, args):
    activities, _ = parse_file(path, missing_ok=True)
    when = command_time(option_value(args, ["-t"], ["--time"]))
    desc = option_value(args, ["-d"], ["--description"])
    project = option_value(args, ["-p"], ["--project"])
    number = 0
    for arg in args:
        if not arg.startswith("-") and arg not in {desc, project, option_value(args, ["-t"], ["--time"])}:
            try:
                number = int(arg)
            except ValueError:
                pass
    if not desc or not project:
        pairs = unique_pairs(activities)
        if number < len(pairs):
            desc, project = pairs[number]
    if not desc or not project:
        return 1
    messages = stop_running(activities, when)
    activities.append(Activity(when, None, project, desc))
    write_file(path, activities)
    for message in messages:
        print(message)
    print(f'Started activity: "{desc}" ({project}) at {fmt_dt(when)}')
    return 0


def print_table_header(cols):
    print()
    print(" ".join(cols))


def cmd_current(path, args):
    activities, _ = parse_file(path, missing_ok=True)
    print_table_header(["Started At", "Description", "Project", "Duration"])
    for activity in activities:
        if activity.running:
            print(f"{fmt_dt(activity.start)} {activity.description} {activity.project} {format_duration(activity.duration_minutes())}")
    print()
    return 0


def cmd_projects(path, args):
    activities, _ = parse_file(path, missing_ok=True)
    current = has_flag(args, ["-c", "--current"])
    no_quotes = has_flag(args, ["-n", "--no-quotes"])
    projects = []
    for activity in activities:
        if current and not activity.running:
            continue
        if activity.project not in projects:
            projects.append(activity.project)
    for project in projects:
        print(project if no_quotes else f'"{project}"')
    return 0


def cmd_last(path, args, search_term=None):
    activities, _ = parse_file(path, missing_ok=True)
    limit = int(option_value(args, ["-n"], ["--number"], "10"))
    pairs = unique_pairs(activities)
    if search_term is not None:
        term = search_term.lower()
        pairs = [pair for pair in pairs if term in pair[0].lower() or term in pair[1].lower()]
    print_table_header(["#", "Description", "Project"])
    for idx, (desc, project) in enumerate(pairs[:limit]):
        print(f"[{idx}] {desc} {project}")
    print()
    return 0


def cmd_list(path, args):
    activities, _ = parse_file(path, missing_ok=True)
    chosen, single = filtered(activities, args)
    no_grouping = has_flag(args, ["--no_grouping"])
    print_table_header(["Started", "Stopped", "Description", "Project", "Duration"])
    if no_grouping:
        for activity in chosen:
            start = activity.start.strftime("%H:%M") if single else fmt_dt(activity.start)
            stop = activity.stop.strftime("%H:%M") if activity.stop else "-"
            print(f"{start} {stop} {activity.description} {activity.project} {format_duration(activity.duration_minutes())}")
    else:
        groups = OrderedDict()
        for activity in chosen:
            groups.setdefault(activity.start.date(), []).append(activity)
        for group_date, rows in groups.items():
            total = sum(row.duration_minutes() for row in rows)
            print()
            print(f"{group_date}\t{format_duration(total)}")
            for activity in rows:
                stop = activity.stop.strftime("%H:%M") if activity.stop else "-"
                print(f"{activity.start.strftime('%H:%M')} {stop} {activity.description} {activity.project} {format_duration(activity.duration_minutes())}")
    print()
    return 0


def cmd_report(path, args):
    activities, _ = parse_file(path, missing_ok=True)
    chosen, _ = filtered(activities, args)
    by_project = OrderedDict()
    for activity in chosen:
        by_project.setdefault(activity.project, OrderedDict())
        by_project[activity.project][activity.description] = by_project[activity.project].get(activity.description, 0) + activity.duration_minutes()
    total = sum(sum(descs.values()) for descs in by_project.values())
    print()
    for project, descs in by_project.items():
        ptotal = sum(descs.values())
        print(f"{project} {format_duration(ptotal)}")
        for desc, minutes in descs.items():
            print(f"    {desc} {format_duration(minutes)}")
        print()
    print(f"Total {format_duration(total)}")
    print()
    return 0


def cmd_status(path, args):
    activities, _ = parse_file(path, missing_ok=True)
    project = option_value(args, ["-p"], ["--project"])
    filtered_activities = [a for a in activities if not project or a.project == project]
    running = [a for a in filtered_activities if a.running]
    print(f" Status for {project or 'ALL'} projects ")
    if running:
        for activity in running:
            print(f'  NOW: "{activity.description}" ({activity.project}) {format_duration(activity.duration_minutes())}')
    else:
        print("  NOW:  NO Activity")
    def total_for(start, end):
        return sum(a.duration_minutes() for a in filtered_activities if start <= a.start.date() <= end)
    t = today()
    week_start = t - timedelta(days=t.weekday())
    month_start = t.replace(day=1)
    print(f" Today......................... {format_duration(total_for(t, t))}")
    print(f" Current week.................. {format_duration(total_for(week_start, week_start + timedelta(days=6)))}")
    print(f" Current month................. {format_duration(total_for(month_start, t))}")
    return 0


def cmd_check(path, args):
    try:
        _, errors = parse_file(path)
    except FileNotFoundError as exc:
        print(f"Error: Could not read from file: {path}\n\nCaused by:\n    {exc.strerror} (os error {exc.errno})", file=sys.stderr)
        return 1
    if errors:
        print(f"Found {len(errors)} line(s) with parsing errors\n")
        for line_no, line, message in errors:
            print(line)
            print(f"  -> {message} (Line: {line_no})")
    else:
        print("No parsing errors.")
    return 0


def cmd_sanity(path, args):
    print("No unusual activities.")
    return 0


def cmd_edit(path, args):
    editor = option_value(args, ["-e"], ["--editor"], os.environ.get("EDITOR", "vi"))
    return subprocess.call([editor, path])


def main(argv):
    path, rest = parse_global(argv)
    if not rest:
        print(TOP_HELP, end="")
        return 0
    cmd, args = rest[0], rest[1:]
    if cmd == "help":
        if args and args[0] in HELP:
            print(HELP[args[0]], end="")
        else:
            print(TOP_HELP, end="")
        return 0
    if cmd in HELP and has_flag(args, ["-h", "--help"]):
        print(HELP[cmd], end="")
        return 0
    if cmd in {"-h", "--help"}:
        print(TOP_HELP, end="")
        return 0
    handlers = {
        "start": cmd_start,
        "stop": cmd_stop,
        "cancel": cmd_cancel,
        "change": cmd_change,
        "continue": cmd_continue,
        "current": cmd_current,
        "projects": cmd_projects,
        "last": cmd_last,
        "list": cmd_list,
        "report": cmd_report,
        "status": cmd_status,
        "check": cmd_check,
        "sanity": cmd_sanity,
        "edit": cmd_edit,
    }
    if cmd == "search":
        need_file(path)
        return cmd_last(path, ["-n", "100000"], args[0] if args else "")
    if cmd not in handlers:
        print(f"error: Found argument '{cmd}' which wasn't expected, or isn't valid in this context", file=sys.stderr)
        return 1
    need_file(path)
    return handlers[cmd](path, args)


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
