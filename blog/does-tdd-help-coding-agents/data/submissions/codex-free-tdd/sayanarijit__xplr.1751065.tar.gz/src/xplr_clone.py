#!/usr/bin/env python3
import json
import os
import sys


VERSION = "xplr 1.1.0"

HELP = """xplr 1.1.0
Arijit Basu <hi@arijitbasu.in>
A hackable, minimal, fast TUI file explorer

USAGE:
    xplr [FLAG]... [OPTION]... [PATH] [SELECTION]...

FLAGS:
  -                            Reads new-line (\\n) separated paths from stdin
  --                           Denotes the end of command-line flags and options
      --force-focus            Focuses on the given <PATH>, even if it is a directory
  -h, --help                   Prints help information
  -m, --pipe-msg-in            Helps safely passing messages to the active xplr
                                 session, use %%, %s and %q as the placeholders
  -M, --print-msg-in           Like --pipe-msg-in, but prints the message instead of
                                 passing to the active xplr session
      --print-pwd-as-result    Prints the present working directory when quitting
                                 with `PrintResultAndQuit`
      --read-only              Enables read-only mode (config.general.read_only)
      --read0                  Reads paths separated using the null character (\\0)
      --write0                 Prints paths separated using the null character (\\0)
  -0  --null                   Combines --read0 and --write0
  -V, --version                Prints version information

OPTIONS:
  -c, --config <PATH>             Specifies a custom config file (default is
                                    "$HOME/.config/xplr/init.lua")
  -C, --extra-config <PATH>...    Specifies extra config files to load
      --on-load <MESSAGE>...      Sends messages when xplr loads
      --vroot <PATH>              Treats the specified path as the virtual root

ARGS:
  <PATH>            Path to focus on, or enter if directory, (default is `.`)
  <SELECTION>...    Paths to select, requires <PATH> to be set explicitly
"""

MESSAGES = [
    "ExplorePwd", "ExplorePwdAsync", "ExploreParentsAsync", "TryCompletePath",
    "ClearScreen", "Refresh", "FocusNext", "FocusNextSelection",
    "FocusNextByRelativeIndex", "FocusNextByRelativeIndexFromInput",
    "FocusPrevious", "FocusPreviousSelection", "FocusPreviousByRelativeIndex",
    "FocusPreviousByRelativeIndexFromInput", "FocusFirst", "FocusLast",
    "FocusPath", "FocusPathFromInput", "FocusByIndex", "FocusByIndexFromInput",
    "FocusByFileName", "ScrollUp", "ScrollDown", "ScrollUpHalf",
    "ScrollDownHalf", "ChangeDirectory", "Enter", "Back", "LastVisitedPath",
    "NextVisitedPath", "PreviousVisitedDeepBranch", "NextVisitedDeepBranch",
    "FollowSymlink", "SetVroot", "UnsetVroot", "ToggleVroot", "ResetVroot",
    "SetInputPrompt", "UpdateInputBuffer", "UpdateInputBufferFromKey",
    "BufferInput", "BufferInputFromKey", "SetInputBuffer",
    "RemoveInputBufferLastCharacter", "RemoveInputBufferLastWord",
    "ResetInputBuffer", "SwitchMode", "SwitchModeKeepingInputBuffer",
    "SwitchModeBuiltin", "SwitchModeBuiltinKeepingInputBuffer",
    "SwitchModeCustom", "SwitchModeCustomKeepingInputBuffer", "PopMode",
    "PopModeKeepingInputBuffer", "SwitchLayout", "SwitchLayoutBuiltin",
    "SwitchLayoutCustom", "Call", "Call0", "CallSilently", "CallSilently0",
    "BashExec", "BashExec0", "BashExecSilently", "BashExecSilently0",
    "CallLua", "CallLuaSilently", "LuaEval", "LuaEvalSilently", "Select",
    "SelectAll", "SelectPath", "UnSelect", "UnSelectAll", "UnSelectPath",
    "ToggleSelection", "ToggleSelectAll", "ToggleSelectionByPath",
    "ClearSelection", "AddNodeFilter", "RemoveNodeFilter", "ToggleNodeFilter",
    "AddNodeFilterFromInput", "RemoveNodeFilterFromInput", "RemoveLastNodeFilter",
    "ResetNodeFilters", "ClearNodeFilters", "AddNodeSorter", "RemoveNodeSorter",
    "ReverseNodeSorter", "ToggleNodeSorter", "ReverseNodeSorters",
    "RemoveLastNodeSorter", "ResetNodeSorters", "ClearNodeSorters", "Search",
    "SearchFromInput", "SearchFuzzy", "SearchFuzzyFromInput",
    "SearchFuzzyUnordered", "SearchFuzzyUnorderedFromInput", "SearchRegex",
    "SearchRegexFromInput", "SearchRegexUnordered", "SearchRegexUnorderedFromInput",
    "ToggleSearchAlgorithm", "EnableSearchOrder", "DisableSearchOrder",
    "ToggleSearchOrder", "AcceptSearch", "CancelSearch", "EnableMouse",
    "DisableMouse", "ToggleMouse", "StartFifo", "StopFifo", "ToggleFifo",
    "LogInfo", "LogSuccess", "LogWarning", "LogError", "Debug", "Quit",
    "PrintPwdAndQuit", "PrintFocusPathAndQuit", "PrintSelectionAndQuit",
    "PrintResultAndQuit", "PrintAppStateAndQuit", "Terminate",
]

NEWTYPES = {
    "FocusPath", "ChangeDirectory", "SetVroot", "SetInputPrompt",
    "UpdateInputBuffer", "BufferInput", "SetInputBuffer", "SwitchMode",
    "SwitchModeKeepingInputBuffer", "SwitchModeBuiltin",
    "SwitchModeBuiltinKeepingInputBuffer", "SwitchModeCustom",
    "SwitchModeCustomKeepingInputBuffer", "SwitchLayout", "SwitchLayoutBuiltin",
    "SwitchLayoutCustom", "SelectPath", "UnSelectPath", "ToggleSelectionByPath",
    "AddNodeFilter", "RemoveNodeFilter", "ToggleNodeFilter", "AddNodeSorter",
    "RemoveNodeSorter", "LogInfo", "LogSuccess", "LogWarning", "LogError",
    "Debug", "FocusNextByRelativeIndex", "FocusPreviousByRelativeIndex",
    "FocusByIndex", "FocusByFileName", "Call", "Call0", "CallSilently",
    "CallSilently0", "BashExec", "BashExec0", "BashExecSilently",
    "BashExecSilently0", "CallLua", "CallLuaSilently", "LuaEval",
    "LuaEvalSilently",
}


def eprint(message):
    sys.stderr.write(message)


def fail(message):
    eprint(message)
    return 1


def abs_path(path):
    return path if os.path.isabs(path) else os.path.abspath(path)


def path_exists(path):
    return os.path.exists(abs_path(path))


def split_stdin(read0):
    data = sys.stdin.buffer.read()
    sep = b"\0" if read0 else b"\n"
    return [part.decode(errors="surrogateescape") for part in data.split(sep) if part]


def parse_scalar(value):
    value = value.strip()
    if len(value) >= 2 and value[0] == value[-1] == '"':
        return value[1:-1]
    if value == "true":
        return True
    if value == "false":
        return False
    try:
        return int(value)
    except ValueError:
        return value


def parse_inline_object(value):
    text = value.strip()
    if not (text.startswith("{") and text.endswith("}")):
        return None
    inner = text[1:-1].strip()
    result = {}
    parts = []
    current = ""
    depth = 0
    in_string = False
    escaped = False
    for ch in inner:
        if in_string:
            current += ch
            if escaped:
                escaped = False
            elif ch == "\\":
                escaped = True
            elif ch == '"':
                in_string = False
            continue
        if ch == '"':
            in_string = True
            current += ch
        elif ch in "[{":
            depth += 1
            current += ch
        elif ch in "]}":
            depth -= 1
            current += ch
        elif ch == "," and depth == 0:
            parts.append(current.strip())
            current = ""
        else:
            current += ch
    if current.strip():
        parts.append(current.strip())
    for part in parts:
        if ":" not in part:
            return None
        key, raw = part.split(":", 1)
        key = key.strip().strip('"')
        raw = raw.strip()
        if raw.startswith("[") or raw.startswith("{"):
            result[key] = json.loads(raw)
        else:
            result[key] = parse_scalar(raw)
    return result


def json_dumps(value):
    return json.dumps(value, separators=(",", ":"))


def render_template(fmt, values):
    out = ""
    used = 0
    i = 0
    while i < len(fmt):
        if fmt[i] != "%":
            out += fmt[i]
            i += 1
            continue
        if i + 1 >= len(fmt):
            out += "%"
            i += 1
            continue
        code = fmt[i + 1]
        if code == "%":
            out += "%"
            i += 2
        elif code == "s":
            if used >= len(values):
                return None, "not enough positional values"
            out += values[used]
            used += 1
            i += 2
        elif code == "q":
            if used >= len(values):
                return None, "not enough positional values"
            out += json_dumps(values[used])
            used += 1
            i += 2
        elif code == "*" and i + 2 < len(fmt) and fmt[i + 2] == "q":
            out += ",".join(json_dumps(v) for v in values[used:])
            used = len(values)
            i += 3
        else:
            out += "%" + code
            i += 2
    if used < len(values):
        return None, "too many positional values, not enough positional placeholders"
    return out, None


def parse_message(text):
    s = text.strip()
    if not s:
        return None, "invalid type: unit variant, expected newtype variant"
    if ":" not in s:
        name = s
        if name in NEWTYPES:
            return None, "invalid type: unit variant, expected newtype variant"
        if name in MESSAGES:
            return name, None
        return None, unknown_variant(name)

    name, rest = s.split(":", 1)
    name = name.strip()
    rest = rest.strip()
    if name not in MESSAGES:
        return None, unknown_variant(name)
    if not rest:
        return {name: ""}, None
    if rest.startswith("{") or rest.startswith("["):
        obj = parse_inline_object(rest)
        if obj is not None:
            return {name: obj}, None
        try:
            return {name: json.loads(rest)}, None
        except Exception:
            return {name: parse_scalar(rest)}, None
    return {name: parse_scalar(rest)}, None


def unknown_variant(name):
    expected = ", ".join(f"`{m}`" for m in MESSAGES)
    return f"unknown variant `{name}`, expected one of {expected}"


def handle_msg(print_only, args):
    flag = "-M" if print_only else "-m"
    if not args:
        return fail(f"error: usage: xplr {flag} FORMAT [ARGUMENT]...\n")
    rendered, err = render_template(args[0], args[1:])
    if err:
        return fail(f"error: xplr -m: {err}\n")
    msg, err = parse_message(rendered)
    if err:
        return fail(f"error: {err}\n")
    payload = json_dumps(msg)
    if print_only:
        sys.stdout.write(payload)
        return 0
    # The real program inspects its pipe delimiter and reports this spelling
    # outside an active xplr command session.
    return fail("error: failed to detect delimmiter\n")


def validate_message(text):
    msg, err = parse_message(text)
    if err:
        return err
    return None


def main(argv):
    paths = []
    read_stdin = False
    read0 = False
    version = False
    help_flag = False
    i = 0
    end_flags = False
    while i < len(argv):
        arg = argv[i]
        if end_flags:
            paths.append(arg)
            i += 1
            continue
        if arg == "--":
            end_flags = True
            i += 1
        elif arg in ("-h", "--help"):
            help_flag = True
            i += 1
        elif arg in ("-V", "--version"):
            version = True
            i += 1
        elif arg in ("-m", "--pipe-msg-in"):
            return handle_msg(False, argv[i + 1 :])
        elif arg in ("-M", "--print-msg-in"):
            return handle_msg(True, argv[i + 1 :])
        elif arg == "-":
            read_stdin = True
            i += 1
        elif arg in ("--read0",):
            read0 = True
            i += 1
        elif arg in ("--write0", "--read-only", "--force-focus", "--print-pwd-as-result"):
            i += 1
        elif arg in ("-0", "--null"):
            read0 = True
            i += 1
        elif arg in ("-c", "--config"):
            if i + 1 >= len(argv):
                return fail(f"error: usage: xplr {arg} PATH\n")
            if not path_exists(argv[i + 1]):
                return fail(f"error: path doesn't exist: {abs_path(argv[i + 1])}\n")
            i += 2
        elif arg in ("-C", "--extra-config"):
            if i + 1 >= len(argv):
                return fail(f"error: usage: xplr {arg} PATH\n")
            i += 1
            while i < len(argv) and not argv[i].startswith("-"):
                if not path_exists(argv[i]):
                    return fail(f"error: path doesn't exist: {abs_path(argv[i])}\n")
                i += 1
        elif arg == "--vroot":
            if i + 1 >= len(argv):
                return fail("error: usage: xplr --vroot PATH\n")
            if not path_exists(argv[i + 1]):
                return fail(f"error: path doesn't exist: {abs_path(argv[i + 1])}\n")
            i += 2
        elif arg == "--on-load":
            if i + 1 >= len(argv):
                return fail("error: usage: xplr --on-load MESSAGE\n")
            err = validate_message(argv[i + 1])
            if err:
                return fail(f"error: {err}\n")
            i += 2
        elif arg.startswith("-"):
            return fail(f'error: invalid argument: "{arg}", try `-- "{arg}"` or `--help`\n')
        else:
            paths.append(arg)
            i += 1

    if read_stdin:
        paths.extend(split_stdin(read0))

    for p in paths:
        if not path_exists(p):
            return fail(f"error: path doesn't exist: {abs_path(p)}\n")

    if help_flag:
        sys.stdout.write(HELP)
        return 0
    if version:
        print(VERSION)
        return 0

    return fail("error: No such device or address (os error 6)\n")


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
