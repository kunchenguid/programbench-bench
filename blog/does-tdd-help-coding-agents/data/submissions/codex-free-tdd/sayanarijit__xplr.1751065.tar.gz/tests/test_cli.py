#!/usr/bin/env python3
import os
import subprocess
import tempfile
import unittest


ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
BIN = os.path.join(ROOT, "executable")


def run_cmd(args, stdin=None, env=None):
    proc = subprocess.run(
        [BIN] + args,
        input=stdin,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        env=env,
    )
    return proc.returncode, proc.stdout, proc.stderr


class XplrCliTest(unittest.TestCase):
    def test_version_short_and_long(self):
        for flag in ("--version", "-V"):
            code, out, err = run_cmd([flag])
            self.assertEqual(code, 0)
            self.assertEqual(out, b"xplr 1.1.0\n")
            self.assertEqual(err, b"")

    def test_help_contains_documented_sections(self):
        for flag in ("--help", "-h"):
            code, out, err = run_cmd([flag])
            text = out.decode()
            self.assertEqual(code, 0)
            self.assertEqual(err, b"")
            self.assertIn("xplr 1.1.0", text)
            self.assertIn("USAGE:\n    xplr [FLAG]... [OPTION]... [PATH] [SELECTION]...", text)
            self.assertIn("-m, --pipe-msg-in", text)
            self.assertIn("-C, --extra-config <PATH>...", text)

    def test_invalid_option_message(self):
        code, out, err = run_cmd(["--badflag"])
        self.assertEqual(code, 1)
        self.assertEqual(out, b"")
        self.assertEqual(
            err,
            b'error: invalid argument: "--badflag", try `-- "--badflag"` or `--help`\n',
        )

    def test_missing_option_arguments(self):
        examples = {
            "--config": b"error: usage: xplr --config PATH\n",
            "-m": b"error: usage: xplr -m FORMAT [ARGUMENT]...\n",
            "-M": b"error: usage: xplr -M FORMAT [ARGUMENT]...\n",
        }
        for flag, message in examples.items():
            code, out, err = run_cmd([flag])
            self.assertEqual(code, 1)
            self.assertEqual(out, b"")
            self.assertEqual(err, message)

    def test_nonexistent_config_fails_before_version(self):
        for flag in ("--config", "--extra-config"):
            code, out, err = run_cmd([flag, "nofile", "--version"])
            self.assertEqual(code, 1)
            self.assertEqual(out, b"")
            self.assertEqual(err, b"error: path doesn't exist: /workspace/nofile\n")

    def test_print_msg_in_formats_json_without_newline(self):
        code, out, err = run_cmd(["-M", "LogSuccess: %q", "hello world"])
        self.assertEqual(code, 0)
        self.assertEqual(out, b'{"LogSuccess":"hello world"}')
        self.assertEqual(err, b"")

    def test_print_msg_in_supports_star_q(self):
        code, out, err = run_cmd(
            ["-M", "Call: { command: %q, args: [%*q] }", "bash", "-c", "echo hi"]
        )
        self.assertEqual(code, 0)
        self.assertEqual(out, b'{"Call":{"command":"bash","args":["-c","echo hi"]}}')
        self.assertEqual(err, b"")

    def test_pipe_msg_in_without_session_reports_delimiter_error(self):
        env = os.environ.copy()
        with tempfile.NamedTemporaryFile() as tmp:
            env["XPLR_PIPE_MSG_IN"] = tmp.name
            code, out, err = run_cmd(["-m", "Quit"], env=env)
            self.assertEqual(code, 1)
            self.assertEqual(out, b"")
            self.assertEqual(err, b"error: failed to detect delimmiter\n")

    def test_stdin_paths_are_validated_before_version(self):
        code, out, err = run_cmd(["-", "--version"], stdin=b"a\nb\n")
        self.assertEqual(code, 1)
        self.assertEqual(out, b"")
        self.assertEqual(err, b"error: path doesn't exist: /workspace/a\n")

    def test_unknown_on_load_message_lists_expected_variants(self):
        code, out, err = run_cmd(["--on-load", "Foo", "--version"])
        self.assertEqual(code, 1)
        self.assertEqual(out, b"")
        text = err.decode()
        self.assertTrue(text.startswith("error: unknown variant `Foo`, expected one of "))
        self.assertIn("`ExplorePwd`", text)
        self.assertIn("`Terminate`", text)

    def test_start_without_terminal_reports_os_error(self):
        code, out, err = run_cmd(["--"])
        self.assertEqual(code, 1)
        self.assertEqual(out, b"")
        self.assertEqual(err, b"error: No such device or address (os error 6)\n")


if __name__ == "__main__":
    unittest.main()
