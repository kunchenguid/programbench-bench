#!/usr/bin/env python3
import json
import os
import re
import shutil
import sys
import unicodedata
from datetime import datetime
from pathlib import Path


MAIN_HELP = """RnR is a command-line tool to rename multiple files and directories that
supports regular expressions


Usage: executable <COMMAND>

Commands:
  regex      Rename files and directories using a regular expression
  from-file  Read operations from a dump file
  to-ascii   Replace file name UTF-8 chars with ASCII chars representation
  help       Print this message or the help of the given subcommand(s)

Options:
  -h, --help     Print help
  -V, --version  Print version
"""

REGEX_HELP = """Rename files and directories using a regular expression

Usage: executable regex [OPTIONS] <EXPRESSION> <REPLACEMENT> <PATH(S)>...

Arguments:
  <EXPRESSION>   Expression to match (can be a regex)
  <REPLACEMENT>  Expression replacement (use single quotes for capture groups)
  <PATH(S)>...   Target paths

Options:
  -n, --dry-run
          Only show what would be done (default mode)
  -f, --force
          Make actual changes to files
  -b, --backup
          Generate file backups before renaming
  -s, --silent
          Do not print any information
      --color <COLOR>
          Set color output mode [default: auto] [possible values: always, never, auto]
      --dump
          Force dumping operations into a file even in dry-run mode
      --dump-prefix <DUMP_PREFIX>
          Set the dump file prefix [default: rnr-]
      --no-dump
          Do not dump operations into a file
  -l, --replace-limit <LIMIT>
          Limit of replacements, all matches if set to 0
  -t, --replace-transform <REPLACE_TRANSFORM>
          Apply a transformation to replacements including captured groups [possible values: upper, lower, ascii]
  -D, --include-dirs
          Rename matching directories
  -r, --recursive
          Recursive mode
  -d, --max-depth <LEVEL>
          Set max depth in recursive mode
  -x, --hidden
          Include hidden files and directories
  -h, --help
          Print help
"""

FROM_FILE_HELP = """Read operations from a dump file

Usage: executable from-file [OPTIONS] <DUMPFILE>

Arguments:
  <DUMPFILE>  

Options:
  -n, --dry-run                    Only show what would be done (default mode)
  -f, --force                      Make actual changes to files
  -b, --backup                     Generate file backups before renaming
  -s, --silent                     Do not print any information
      --color <COLOR>              Set color output mode [default: auto] [possible values: always, never, auto]
      --dump                       Force dumping operations into a file even in dry-run mode
      --dump-prefix <DUMP_PREFIX>  Set the dump file prefix [default: rnr-]
      --no-dump                    Do not dump operations into a file
  -u, --undo                       Undo the operations from the dump file
  -h, --help                       Print help
"""

ASCII_HELP = """Replace file name UTF-8 chars with ASCII chars representation

Usage: executable to-ascii [OPTIONS] <PATH(S)>...

Arguments:
  <PATH(S)>...  Target paths

Options:
  -n, --dry-run                    Only show what would be done (default mode)
  -f, --force                      Make actual changes to files
  -b, --backup                     Generate file backups before renaming
  -s, --silent                     Do not print any information
      --color <COLOR>              Set color output mode [default: auto] [possible values: always, never, auto]
      --dump                       Force dumping operations into a file even in dry-run mode
      --dump-prefix <DUMP_PREFIX>  Set the dump file prefix [default: rnr-]
      --no-dump                    Do not dump operations into a file
  -D, --include-dirs               Rename matching directories
  -r, --recursive                  Recursive mode
  -d, --max-depth <LEVEL>          Set max depth in recursive mode
  -x, --hidden                     Include hidden files and directories
  -h, --help                       Print help
"""


def ascii_name(s):
    return "".join(c for c in unicodedata.normalize("NFKD", s) if not unicodedata.combining(c)).encode("ascii", "ignore").decode()


def convert_repl(repl):
    return re.sub(r"\$(\d+)", lambda m: "\\" + m.group(1), repl)


def parse_common(argv, allow_walk=False, allow_undo=False, allow_regex=False):
    opts = {
        "force": False, "backup": False, "silent": False, "dump": False,
        "no_dump": False, "dump_prefix": "rnr-", "include_dirs": False,
        "recursive": False, "hidden": False, "max_depth": None, "undo": False,
        "limit": None, "transform": None,
    }
    rest = []
    i = 0
    while i < len(argv):
        a = argv[i]
        if a in ("-n", "--dry-run"):
            opts["force"] = False
        elif a in ("-f", "--force"):
            opts["force"] = True
        elif a in ("-b", "--backup"):
            opts["backup"] = True
        elif a in ("-s", "--silent"):
            opts["silent"] = True
        elif a == "--dump":
            opts["dump"] = True
        elif a == "--no-dump":
            opts["no_dump"] = True
        elif a == "--dump-prefix":
            i += 1; opts["dump_prefix"] = argv[i]
        elif a == "--color":
            i += 1
        elif allow_walk and a in ("-D", "--include-dirs"):
            opts["include_dirs"] = True
        elif allow_walk and a in ("-r", "--recursive"):
            opts["recursive"] = True
        elif allow_walk and a in ("-x", "--hidden"):
            opts["hidden"] = True
        elif allow_walk and a in ("-d", "--max-depth"):
            i += 1; opts["max_depth"] = int(argv[i])
        elif allow_undo and a in ("-u", "--undo"):
            opts["undo"] = True
        elif allow_regex and a in ("-l", "--replace-limit"):
            i += 1; opts["limit"] = int(argv[i])
        elif allow_regex and a in ("-t", "--replace-transform"):
            i += 1; opts["transform"] = argv[i]
        else:
            rest.append(a)
        i += 1
    return opts, rest


def is_hidden(path):
    return any(part.startswith(".") and part not in (".", "..") for part in Path(path).parts)


def visible_path(root_raw, root, child):
    if root_raw == ".":
        rel = child.relative_to(root)
        return "./" + str(rel) if str(rel) != "." else "."
    return str(child)


def walk_dir_depth_first(root_raw, root, opts, depth=0):
    out = []
    try:
        entries = sorted(list(root.iterdir()), key=lambda p: p.name)
    except OSError:
        return out
    dirs = [p for p in entries if p.is_dir()]
    files = [p for p in entries if not p.is_dir()]
    if not opts["hidden"]:
        dirs = [p for p in dirs if not p.name.startswith(".")]
        files = [p for p in files if not p.name.startswith(".")]
    descend = opts["max_depth"] is None or depth < opts["max_depth"] - 1
    if descend:
        for d in dirs:
            out.extend(walk_dir_depth_first(root_raw, d, opts, depth + 1))
    if opts["include_dirs"]:
        for d in dirs:
            out.append((d, visible_path(root_raw, Path(root_raw), d)))
    for f in files:
        out.append((f, visible_path(root_raw, Path(root_raw), f)))
    return out


def walk_targets(paths, opts):
    out = []
    for raw in paths:
        p = Path(raw)
        if opts["recursive"] and p.is_dir():
            out.extend(walk_dir_depth_first(raw, p, opts))
        else:
            if not p.exists():
                continue
            if p.is_dir() and not opts["include_dirs"]:
                continue
            if opts["hidden"] or not is_hidden(p):
                out.append((p, raw))
    return out


def apply_regex(name, expr, repl, opts):
    count = 1 if opts["limit"] is None else (0 if opts["limit"] == 0 else opts["limit"])
    py_repl = convert_repl(repl)
    pat = re.compile(expr)
    if opts["transform"]:
        def fn(m):
            val = m.expand(py_repl)
            if opts["transform"] == "upper":
                return val.upper()
            if opts["transform"] == "lower":
                return val.lower()
            if opts["transform"] == "ascii":
                return ascii_name(val)
            return val
        return pat.sub(fn, name, count=count)
    return pat.sub(py_repl, name, count=count)


def make_dump(ops, opts):
    if opts["no_dump"] or (not opts["dump"] and not opts["force"]):
        return
    now = datetime.now().strftime("%Y-%m-%d_%H%M%S")
    human = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    path = f"{opts['dump_prefix']}{now}.json"
    data = {"date": human, "operations": [{"source": str(a), "target": str(b)} for a, b, _, _ in ops]}
    with open(path, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2)


def execute_ops(ops, opts):
    if not opts["silent"] and not opts["force"]:
        print("This is a DRY-RUN")
    for src, dst, _real_src, real_dst in ops:
        if opts["force"] and Path(real_dst).exists():
            print(f"Error: Conflict with existing path {src} -> {dst}", file=sys.stderr)
            return 1
    if opts["force"]:
        for src, dst, real_src, real_dst in ops:
            if opts["backup"]:
                backup = str(src) + ".bk"
                real_backup = str(real_src) + ".bk"
                shutil.copy2(real_src, real_backup) if Path(real_src).is_file() else shutil.copytree(real_src, real_backup)
                if not opts["silent"]:
                    print(f"Info:  Backup created - {src} -> {backup}")
            os.rename(real_src, real_dst)
    if not opts["silent"]:
        for src, dst, _real_src, _real_dst in ops:
            print(f"{src} -> {dst}")
    make_dump(ops, opts)
    return 0


def cmd_regex(argv):
    if not argv or "--help" in argv or "-h" in argv:
        print(REGEX_HELP, end=""); return 0
    opts, rest = parse_common(argv, allow_walk=True, allow_regex=True)
    if len(rest) < 3:
        return 2
    expr, repl, paths = rest[0], rest[1], rest[2:]
    ops = []
    for p, shown in walk_targets(paths, opts):
        new_name = apply_regex(p.name, expr, repl, opts)
        if new_name != p.name:
            src = shown
            dst_path = p.with_name(new_name)
            dst = str(Path(shown).with_name(new_name)) if not shown.startswith("./") else "./" + str(Path(shown[2:]).with_name(new_name))
            ops.append((src, dst, str(p), str(dst_path)))
    if not opts["recursive"]:
        ops.sort(key=lambda x: x[0])
    return execute_ops(ops, opts)


def cmd_ascii(argv):
    if not argv or "--help" in argv or "-h" in argv:
        print(ASCII_HELP, end=""); return 0
    opts, rest = parse_common(argv, allow_walk=True)
    ops = []
    for p, shown in walk_targets(rest, opts):
        new_name = ascii_name(p.name)
        if new_name != p.name:
            dst_path = p.with_name(new_name)
            dst = str(Path(shown).with_name(new_name)) if not shown.startswith("./") else "./" + str(Path(shown[2:]).with_name(new_name))
            ops.append((shown, dst, str(p), str(dst_path)))
    return execute_ops(ops, opts)


def cmd_from_file(argv):
    if not argv or "--help" in argv or "-h" in argv:
        print(FROM_FILE_HELP, end=""); return 0
    opts, rest = parse_common(argv, allow_undo=True)
    if not rest:
        return 2
    with open(rest[0], encoding="utf-8") as f:
        data = json.load(f)
    ops = [(op["source"], op["target"], op["source"], op["target"]) for op in data.get("operations", [])]
    if opts["undo"]:
        ops = [(b, a, rb, ra) for a, b, ra, rb in reversed(ops)]
    return execute_ops(ops, opts)


def main(argv):
    if not argv or argv[0] in ("-h", "--help"):
        print(MAIN_HELP, end=""); return 0
    if argv[0] in ("-V", "--version"):
        print("rnr 0.5.1"); return 0
    if argv[0] == "help":
        if len(argv) > 1 and argv[1] == "regex":
            print(REGEX_HELP, end=""); return 0
        if len(argv) > 1 and argv[1] == "from-file":
            print(FROM_FILE_HELP, end=""); return 0
        if len(argv) > 1 and argv[1] == "to-ascii":
            print(ASCII_HELP, end=""); return 0
        print(MAIN_HELP, end=""); return 0
    if argv[0] == "regex":
        return cmd_regex(argv[1:])
    if argv[0] == "from-file":
        return cmd_from_file(argv[1:])
    if argv[0] == "to-ascii":
        return cmd_ascii(argv[1:])
    print(f"error: unrecognized subcommand '{argv[0]}'", file=sys.stderr)
    return 2


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
