import os
import shutil
import subprocess
import tempfile
import unittest


ROOT = os.path.dirname(os.path.dirname(__file__))
BIN = os.path.join(ROOT, "executable")


def run(cmd, cwd=None, check=True):
    env = os.environ.copy()
    env.update({
        "GIT_CONFIG_NOSYSTEM": "1",
        "HOME": tempfile.gettempdir(),
        "PAGER": "cat",
        "GIT_PAGER": "cat",
    })
    proc = subprocess.run(
        cmd,
        cwd=cwd,
        env=env,
        text=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
    )
    if check and proc.returncode != 0:
        raise AssertionError(f"{cmd} failed\nstdout={proc.stdout}\nstderr={proc.stderr}")
    return proc


def make_linear_repo():
    path = tempfile.mkdtemp(prefix="gg-linear-")
    run(["git", "init", "-q"], cwd=path)
    run(["git", "config", "user.name", "Alice"], cwd=path)
    run(["git", "config", "user.email", "alice@example.com"], cwd=path)
    with open(os.path.join(path, "f.txt"), "w", encoding="utf-8") as f:
        f.write("one\n")
    run(["git", "add", "f.txt"], cwd=path)
    run(["git", "commit", "-q", "-m", "initial commit"], cwd=path)
    with open(os.path.join(path, "f.txt"), "a", encoding="utf-8") as f:
        f.write("two\n")
    run(["git", "commit", "-q", "-am", "second commit"], cwd=path)
    return path


def make_merge_repo():
    path = tempfile.mkdtemp(prefix="gg-merge-")
    run(["git", "init", "-q"], cwd=path)
    run(["git", "config", "user.name", "Alice"], cwd=path)
    run(["git", "config", "user.email", "alice@example.com"], cwd=path)
    with open(os.path.join(path, "f.txt"), "w", encoding="utf-8") as f:
        f.write("base\n")
    run(["git", "add", "f.txt"], cwd=path)
    run(["git", "commit", "-q", "-m", "base"], cwd=path)
    run(["git", "checkout", "-q", "-b", "feature"], cwd=path)
    with open(os.path.join(path, "feat.txt"), "w", encoding="utf-8") as f:
        f.write("feat\n")
    run(["git", "add", "feat.txt"], cwd=path)
    run(["git", "commit", "-q", "-m", "feature1"], cwd=path)
    with open(os.path.join(path, "feat.txt"), "a", encoding="utf-8") as f:
        f.write("feat2\n")
    run(["git", "commit", "-q", "-am", "feature2"], cwd=path)
    run(["git", "checkout", "-q", "master"], cwd=path)
    with open(os.path.join(path, "f.txt"), "a", encoding="utf-8") as f:
        f.write("main\n")
    run(["git", "commit", "-q", "-am", "main1"], cwd=path)
    run(["git", "merge", "--no-ff", "-q", "feature", "-m", "merge feature"], cwd=path)
    return path


class GitGraphTests(unittest.TestCase):
    def tearDown(self):
        for name in getattr(self, "_cleanup", []):
            shutil.rmtree(name, ignore_errors=True)

    def repo(self):
        self._cleanup = getattr(self, "_cleanup", [])
        path = make_linear_repo()
        self._cleanup.append(path)
        return path

    def test_linear_history_matches_default_text_shape(self):
        repo = self.repo()
        out = run([BIN, "--no-color", "--path", repo]).stdout
        lines = out.splitlines()
        self.assertEqual(2, len(lines))
        self.assertRegex(lines[0], r"^ ●  [0-9a-f]{7} \(HEAD -> master\) second commit$")
        self.assertRegex(lines[1], r"^ ●  [0-9a-f]{7} initial commit$")

    def test_ascii_style_uses_asterisk_nodes(self):
        repo = self.repo()
        out = run([BIN, "--no-color", "--path", repo, "--style", "ascii"]).stdout
        self.assertRegex(out.splitlines()[0], r"^ \*  [0-9a-f]{7} \(HEAD -> master\) second commit$")

    def test_model_subcommand_lists_and_persists_model(self):
        repo = self.repo()
        listing = run([BIN, "model", "--list"], cwd=repo).stdout.splitlines()
        self.assertEqual(["none", "simple", "git-flow"], listing)
        before = run([BIN, "model"], cwd=repo).stdout
        self.assertEqual("No branching model set", before)
        set_result = run([BIN, "model", "simple"], cwd=repo).stdout
        self.assertEqual("Branching model set to 'simple'", set_result)
        after = run([BIN, "model"], cwd=repo).stdout
        self.assertEqual("simple", after)

    def test_custom_format_is_passed_to_git_pretty_formatter(self):
        repo = self.repo()
        out = run([BIN, "--no-color", "--path", repo, "-f", "%h|%s|%an|%ae|%as|%p|%d"]).stdout
        first = out.splitlines()[0]
        self.assertRegex(first, r"^ ●  [0-9a-f]{7}\|second commit\|Alice\|alice@example.com\|\d{4}-\d{2}-\d{2}\|[0-9a-f]{7}\| \(HEAD -> master\)$")

    def test_reverse_linear_history_prints_oldest_commit_first(self):
        repo = self.repo()
        out = run([BIN, "--no-color", "--path", repo, "-r"]).stdout
        lines = out.splitlines()
        self.assertRegex(lines[0], r"^ ●  [0-9a-f]{7} initial commit$")
        self.assertRegex(lines[1], r"^ ●  [0-9a-f]{7} \(HEAD -> master\) second commit$")

    def test_ascii_merge_history_uses_compact_merge_and_join_lines(self):
        self._cleanup = getattr(self, "_cleanup", [])
        repo = make_merge_repo()
        self._cleanup.append(repo)
        lines = run([BIN, "--no-color", "--path", repo, "--style", "ascii"]).stdout.splitlines()
        self.assertRegex(lines[0], r"^ o<\.  [0-9a-f]{7} \(HEAD -> master\) merge feature$")
        self.assertRegex(lines[1], r"^ \* \|  [0-9a-f]{7} main1$")
        self.assertRegex(lines[4], r"^ \|-'  $")
        self.assertRegex(lines[5], r"^ \*    [0-9a-f]{7} base$")


if __name__ == "__main__":
    unittest.main()
