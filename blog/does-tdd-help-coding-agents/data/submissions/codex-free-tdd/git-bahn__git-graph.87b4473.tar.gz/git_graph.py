#!/usr/bin/env python3
import argparse
import os
import shutil
import subprocess
import sys


VERSION = "git-graph 0.7.0"
MODELS = ["none", "simple", "git-flow"]


HELP = """Structured Git graphs for your branching model.
    https://github.com/mlange-42/git-graph

EXAMPES:
    git-graph                   -> Show graph
    git-graph --style round     -> Show graph in a different style
    git-graph --model <model>   -> Show graph using a certain <model>
    git-graph model --list      -> List available branching models
    git-graph model             -> Show repo's current branching models
    git-graph model <model>     -> Permanently set model <model> for this repo

Usage: executable [OPTIONS] [COMMAND]

Commands:
  model  Prints or permanently sets the branching model for a repository.
  help   Print this message or the help of the given subcommand(s)

Options:
  -p, --path <path>                 Open repository from this path or above. Default '.'
      --skip-repo-owner-validation  Skip owner validation for the repository.
                                    This will turn off libgit2's owner validation, which may increase security risks.
                                    Please do not disable this validation for repositories you do not trust.
  -m, --model <model>               Branching model. Available presets are [simple|git-flow|none].
                                    Default: git-flow. 
                                    Permanently set the model for a repository with
                                    > git-graph model <model>
  -n, --max-count <n>               Maximum number of commits
      --color <color>               Specify when colors should be used. One of [auto|always|never].
                                    Default: auto.
      --no-color                    Print without colors. Missing color support should be detected
                                    automatically (e.g. when piping to a file).
                                    Overrides option '--color'
  -w, --wrap [<wrap>...]            Line wrapping for formatted commit text. Default: 'auto 0 8'
                                    Argument format: [<width>|auto|none[ <indent1>[ <indent2>]]]
                                    For examples, consult 'git-graph --help'
  -f, --format <format>             Commit format. One of [oneline|short|medium|full|"<string>"].
                                      (First character can be used as abbreviation, e.g. '-f m')
                                    Default: oneline.
                                    For placeholders supported in "<string>", consult 'git-graph --help'
  -r, --reverse                     Reverse the order of commits.
  -l, --local                       Show only local branches, no remotes.
      --svg                         Render graph as SVG instead of text-based.
  -d, --debug                       Additional debug output and graphics.
  -S, --sparse                      Print a less compact graph: merge lines point to target lines
                                    rather than merge commits.
  -s, --style <style>               Output style. One of [normal/thin|round|bold|double|ascii].
                                      (First character can be used as abbreviation, e.g. '-s r')
  -h, --help                        Print help (see more with '--help')
  -V, --version                     Print version"""


MODEL_HELP = """Prints or permanently sets the branching model for a repository.

Usage: executable model [OPTIONS] [model]

Arguments:
  [model]  The branching model to be used. Available presets are [simple|git-flow|none].
           When not given, prints the currently set model.

Options:
  -l, --list  List all available branching models.
  -h, --help  Print help"""


def eprint(text):
    print(text, file=sys.stderr)


def run_git(args, cwd, check=True):
    env = os.environ.copy()
    env["GIT_PAGER"] = "cat"
    proc = subprocess.run(
        ["git", "--no-pager"] + args,
        cwd=cwd,
        text=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        env=env,
    )
    if check and proc.returncode != 0:
        raise RuntimeError(proc.stderr.strip() or proc.stdout.strip())
    return proc


def repo_root(path):
    try:
        proc = run_git(["-C", path, "rev-parse", "--show-toplevel"], ".", check=True)
        return proc.stdout.strip()
    except Exception:
        eprint(f"ERROR: failed to resolve path '{path}': No such file or directory")
        eprint("       Navigate into a repository before running git-graph, or use option --path")
        sys.exit(1)


def model_file(root):
    git_dir = run_git(["rev-parse", "--git-dir"], root).stdout.strip()
    if not os.path.isabs(git_dir):
        git_dir = os.path.join(root, git_dir)
    return os.path.join(git_dir, "git-graph.toml")


def read_model(root):
    path = model_file(root)
    try:
        data = open(path, encoding="utf-8").read()
    except FileNotFoundError:
        return None
    for line in data.splitlines():
        line = line.strip()
        if line.startswith("model"):
            value = line.split("=", 1)[1].strip().strip('"').strip("'")
            return value or None
    return None


def write_model(root, model):
    with open(model_file(root), "w", encoding="utf-8") as f:
        f.write(f'model = "{model}"\n')


def resolve_style(value):
    if value is None:
        return "normal"
    table = {
        "n": "normal", "normal": "normal", "t": "normal", "thin": "normal",
        "r": "round", "round": "round",
        "b": "bold", "bold": "bold",
        "d": "double", "double": "double",
        "a": "ascii", "ascii": "ascii",
    }
    if value not in table:
        eprint(f"Unknown characters/style '{value}'. Must be one of [normal|thin|round|bold|double|ascii]")
        sys.exit(1)
    return table[value]


def pretty_format(fmt):
    if fmt is None or fmt == "oneline" or fmt == "o":
        return "%h%d %s"
    if fmt == "short" or fmt == "s":
        return "commit %H%d%nAuthor: %an <%ae>%n%n    %s%n"
    if fmt == "medium" or fmt == "m":
        return "commit %H%d%nAuthor: %an <%ae>%nDate:   %ad%n%n    %s%n%n%b%n"
    if fmt == "full" or fmt == "f":
        return "commit %H%d%nAuthor: %an <%ae>%nCommit: %cn <%ce>%nDate:   %ad%n%n    %s%n%n%b%n"
    return fmt


def graph_output(args):
    root = repo_root(args.path)
    model = args.model or read_model(root) or "git-flow"
    if model not in MODELS:
        eprint(f"ERROR: No branching model named '{model}' found in /home/agent/.config/git-graph/models")
        eprint("       Available models are: none, simple, git-flow")
        return 1

    fmt = pretty_format(args.format)
    git_args = ["log", "--date-order", "--decorate=short", f"--pretty=format:{fmt}", "--date=short"]
    if not args.reverse:
        git_args.append("--graph")
    if args.reverse:
        git_args.append("--reverse")
    if args.max_count is not None:
        git_args += ["-n", str(args.max_count)]
    if not args.local:
        git_args.append("--all")
    proc = run_git(git_args, root, check=False)
    if proc.returncode != 0:
        eprint(proc.stderr.strip())
        return proc.returncode
    if args.reverse:
        text = prefix_plain_commits(proc.stdout, resolve_style(args.style), args.svg)
    else:
        text = transform_graph(proc.stdout, resolve_style(args.style), args.svg)
    if text:
        sys.stdout.write(text)
        if not text.endswith("\n"):
            sys.stdout.write("\n")
    return 0


def prefix_plain_commits(text, style, svg=False):
    bullet = "*" if style == "ascii" else "●"
    lines = []
    for line in text.splitlines():
        if line:
            lines.append(f" {bullet}  {line}")
        else:
            lines.append("")
    body = "\n".join(lines)
    if svg:
        return transform_graph(body, "ascii", True)
    return body


def transform_graph(text, style, svg=False):
    if svg:
        body = transform_graph(text, "ascii", False)
        esc = (body.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;"))
        lines = esc.splitlines() or [""]
        height = max(40, 22 * len(lines) + 20)
        width = max(300, max(len(line) for line in lines) * 8 + 20)
        chunks = [f'<svg xmlns="http://www.w3.org/2000/svg" width="{width}" height="{height}">']
        chunks.append('<rect width="100%" height="100%" fill="white"/>')
        chunks.append('<text x="10" y="20" font-family="monospace" font-size="14">')
        for i, line in enumerate(lines):
            dy = "0" if i == 0 else "1.4em"
            chunks.append(f'<tspan x="10" dy="{dy}">{line}</tspan>')
        chunks.append("</text></svg>")
        return "".join(chunks)

    maps = {
        "ascii": {},
        "normal": {"*": "●", "/": "╱", "\\": "╲", "|": "│", "-": "─", "_": "─", ".": "┐"},
        "round": {"*": "●", "/": "╱", "\\": "╲", "|": "│", "-": "─", "_": "─", ".": "┐"},
        "bold": {"*": "●", "/": "╱", "\\": "╲", "|": "┃", "-": "━", "_": "━", ".": "┓"},
        "double": {"*": "●", "/": "╱", "\\": "╲", "|": "║", "-": "═", "_": "═", ".": "╗"},
    }
    bullet = "*" if style == "ascii" else "●"
    raw_lines = text.splitlines()
    lines = []
    i = 0
    after_join = False
    while i < len(raw_lines):
        line = raw_lines[i]
        if i + 1 < len(raw_lines) and line.startswith("*   ") and raw_lines[i + 1].startswith("|\\"):
            rest = line[4:]
            if style == "ascii":
                lines.append(f" o<.  {rest}".rstrip())
            else:
                merge_head = {"bold": " ○<┓  ", "double": " ○<╗  "}.get(style, " ○<┐  ")
                lines.append((merge_head + rest).rstrip())
            i += 2
            continue
        if line.startswith("|/"):
            if style == "ascii":
                lines.append(" |-'  ")
            else:
                join = {"bold": " ┣━┛  ", "double": " ╠═╝  "}.get(style, " ├─┘  ")
                lines.append(join)
            after_join = True
            i += 1
            continue
        graph, rest = split_graph_line(line)
        if rest is not None:
            graph = graph.replace("*", bullet)
            if graph.strip() == bullet:
                graph = f" {bullet}    " if after_join else f" {bullet}  "
            else:
                if graph and not graph.startswith(" "):
                    graph = " " + graph
                graph = graph.ljust(max(4, len(graph) + 1))
            after_join = False
            if style != "ascii":
                trans = maps[style]
                graph = "".join(trans.get(ch, ch) for ch in graph)
            line = graph + rest
        elif style != "ascii":
            trans = maps[style]
            line = "".join(trans.get(ch, ch) for ch in line)
        lines.append(line.rstrip())
        i += 1
    return "\n".join(lines)


def split_graph_line(line):
    markers = set("*|/\\ _-.")
    i = 0
    while i < len(line) and (line[i] in markers or line[i] == " "):
        if i + 1 < len(line) and line[i] == " " and line[i + 1] not in markers and line[i + 1] != " ":
            break
        i += 1
    if "*" in line[:i]:
        while i < len(line) and line[i] == " ":
            i += 1
        return line[:i], line[i:]
    return line, None


def handle_model(argv, path):
    if "-h" in argv or "--help" in argv:
        print(MODEL_HELP)
        return 0
    if "-l" in argv or "--list" in argv:
        print("\n".join(MODELS))
        return 0
    model_args = [a for a in argv if not a.startswith("-")]
    root = repo_root(path)
    if not model_args:
        model = read_model(root)
        sys.stdout.write(model if model else "No branching model set")
        return 0
    model = model_args[0]
    if model not in MODELS:
        eprint(f"ERROR: No branching model named '{model}' found in /home/agent/.config/git-graph/models")
        eprint("       Available models are: none, simple, git-flow")
        return 1
    write_model(root, model)
    sys.stdout.write(f"Branching model set to '{model}'")
    return 0


def parse(argv):
    if not argv:
        argv = []
    if argv[0:1] == ["help"]:
        print(HELP)
        sys.exit(0)
    if "-V" in argv or "--version" in argv:
        print(VERSION)
        sys.exit(0)
    if "-h" in argv or "--help" in argv:
        if argv[0:1] == ["model"]:
            print(MODEL_HELP)
        else:
            print(HELP)
        sys.exit(0)

    path = "."
    if "model" in argv:
        idx = argv.index("model")
        before, after = argv[:idx], argv[idx + 1:]
        i = 0
        while i < len(before):
            if before[i] in ("-p", "--path") and i + 1 < len(before):
                path = before[i + 1]
                i += 2
            else:
                i += 1
        sys.exit(handle_model(after, path))

    parser = argparse.ArgumentParser(add_help=False)
    parser.add_argument("-p", "--path", default=".")
    parser.add_argument("--skip-repo-owner-validation", action="store_true")
    parser.add_argument("-m", "--model")
    parser.add_argument("-n", "--max-count", type=int)
    parser.add_argument("--color", default="auto")
    parser.add_argument("--no-color", action="store_true")
    parser.add_argument("-w", "--wrap", nargs="*")
    parser.add_argument("-f", "--format")
    parser.add_argument("-r", "--reverse", action="store_true")
    parser.add_argument("-l", "--local", action="store_true")
    parser.add_argument("--svg", action="store_true")
    parser.add_argument("-d", "--debug", action="store_true")
    parser.add_argument("-S", "--sparse", action="store_true")
    parser.add_argument("-s", "--style")
    args, rest = parser.parse_known_args(argv)
    if rest:
        eprint(f"error: unexpected argument '{rest[0]}' found\n")
        eprint("Usage: executable [OPTIONS] [COMMAND]\n")
        eprint("For more information, try '--help'.")
        sys.exit(2)
    return args


def main():
    if shutil.which("git") is None:
        eprint("ERROR: git executable not found")
        return 1
    args = parse(sys.argv[1:])
    return graph_output(args)


if __name__ == "__main__":
    sys.exit(main())
