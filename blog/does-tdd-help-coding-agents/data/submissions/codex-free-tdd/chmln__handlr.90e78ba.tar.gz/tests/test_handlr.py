import json
import os
import shutil
import stat
import subprocess
import tempfile
import textwrap
import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
PROGRAM = ROOT / "src" / "handlr.py"


class HandlrTest(unittest.TestCase):
    def setUp(self):
        self.tmp = Path(tempfile.mkdtemp(prefix="handlr-test-"))
        self.home = self.tmp / "home"
        self.config = self.tmp / "config"
        self.data = self.tmp / "data"
        self.bin = self.tmp / "bin"
        for path in [
            self.home,
            self.config,
            self.data / "applications",
            self.bin,
        ]:
            path.mkdir(parents=True, exist_ok=True)

        self.env = os.environ.copy()
        self.env.update(
            {
                "HOME": str(self.home),
                "XDG_CONFIG_HOME": str(self.config),
                "XDG_DATA_HOME": str(self.data),
                "PATH": f"{self.bin}:{self.env.get('PATH', '')}",
                "LOGFILE": str(self.tmp / "log"),
            }
        )
        (self.tmp / "log").write_text("")
        self.write_desktop(
            "foo.desktop",
            """
            [Desktop Entry]
            Type=Application
            Name=Foo App
            Exec=logcmd FOO %f %u %F %U %% %i %c %k
            MimeType=text/plain;text/markdown;x-scheme-handler/https;
            Icon=fooicon
            """,
        )
        self.write_desktop(
            "bar.desktop",
            """
            [Desktop Entry]
            Type=Application
            Name=Bar
            Exec=logcmd BAR --flag
            MimeType=text/plain;
            NoDisplay=true
            """,
        )
        logger = self.bin / "logcmd"
        logger.write_text(
            "#!/bin/sh\n"
            "printf 'ARGS' >> \"$LOGFILE\"\n"
            "for a in \"$@\"; do printf '<%s>' \"$a\" >> \"$LOGFILE\"; done\n"
            "printf '\\n' >> \"$LOGFILE\"\n"
        )
        logger.chmod(logger.stat().st_mode | stat.S_IXUSR)

    def tearDown(self):
        shutil.rmtree(self.tmp)

    def write_desktop(self, name, body):
        (self.data / "applications" / name).write_text(textwrap.dedent(body).lstrip())

    def run_cmd(self, *args):
        return subprocess.run(
            ["python3", str(PROGRAM), *args],
            text=True,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            env=self.env,
            cwd=ROOT,
        )

    def mimeapps(self):
        return (self.config / "mimeapps.list").read_text()

    def test_set_add_unset_update_mimeapps(self):
        self.assertEqual(self.run_cmd("set", "text/plain", "foo.desktop").returncode, 0)
        self.assertEqual(
            self.mimeapps(),
            "[Added Associations]\n\n[Default Applications]\ntext/plain=foo.desktop;\n",
        )

        self.assertEqual(self.run_cmd("add", "text/plain", "bar.desktop").returncode, 0)
        self.assertIn("text/plain=foo.desktop;bar.desktop;\n", self.mimeapps())

        self.assertEqual(self.run_cmd("unset", "text/plain").returncode, 0)
        self.assertEqual(
            self.mimeapps(),
            "[Added Associations]\n\n[Default Applications]\n",
        )

    def test_get_json_and_fallbacks(self):
        self.run_cmd("set", "text/plain", "foo.desktop")
        got = self.run_cmd("get", "--json", "text/plain")
        self.assertEqual(got.returncode, 0, got.stderr)
        self.assertEqual(
            json.loads(got.stdout),
            {
                "handler": "foo.desktop",
                "name": "Foo App",
                "cmd": "logcmd FOO %% %i %c %k",
            },
        )

        self.run_cmd("set", "text/*", "bar.desktop")
        wildcard = self.run_cmd("get", "text/markdown")
        self.assertEqual(wildcard.stdout, "bar.desktop\n")

        self.run_cmd("unset", "text/plain")
        system_fallback = self.run_cmd("get", "text/plain")
        self.assertEqual(system_fallback.stdout, "bar.desktop\n")

    def test_list_outputs_box_table(self):
        self.run_cmd("set", "text/plain", "foo.desktop")
        self.run_cmd("add", "text/plain", "bar.desktop")
        got = self.run_cmd("list")
        self.assertEqual(got.returncode, 0, got.stderr)
        self.assertEqual(
            got.stdout,
            "┌────────────┬──────────────────────────┐\n"
            "│ text/plain │ foo.desktop, bar.desktop │\n"
            "└────────────┴──────────────────────────┘\n",
        )

    def test_launch_substitutes_file_placeholders_and_suppresses_output(self):
        self.run_cmd("set", "text/plain", "foo.desktop")
        got = self.run_cmd("launch", "text/plain", "--", "abc", "two words")
        self.assertEqual(got.returncode, 0, got.stderr)
        self.assertEqual(got.stdout, "")
        self.assertEqual(got.stderr, "")
        self.assertEqual(
            (self.tmp / "log").read_text(),
            "ARGS<FOO><abc><two words><abc><two words><abc><two words><abc><two words><%%><%i><%c><%k>\n",
        )

    def test_unknown_extension_reports_clap_style_error(self):
        got = self.run_cmd("get", ".png")
        self.assertEqual(got.returncode, 2)
        self.assertIn(
            "error: Invalid value for '<mime>': could not figure out the mime type of '.png'\n",
            got.stderr,
        )


if __name__ == "__main__":
    unittest.main()
