#!/usr/bin/env python3
import json
import os
import re
import shlex
import subprocess
import sys
from pathlib import Path


VERSION = "handlr 0.6.4"
HELP = """handlr 0.6.4

USAGE:
    executable <SUBCOMMAND>

FLAGS:
    -h, --help       Prints help information
    -V, --version    Prints version information

SUBCOMMANDS:
    list      List default apps and the associated handlers
    open      Open a path/URL with its default handler
    set       Set the default handler for mime/extension
    unset     Unset the default handler for mime/extension
    launch    Launch the handler for specified extension/mime with optional arguments
    get       Get handler for this mime/extension
    add       Add a handler for given mime/extension Note that the first handler is the default
"""

SUBHELP = {
    "list": """executable-list 
List default apps and the associated handlers

USAGE:
    executable list [FLAGS]

FLAGS:
    -a, --all        
    -h, --help       Prints help information
    -V, --version    Prints version information
""",
    "open": """executable-open 
Open a path/URL with its default handler

USAGE:
    executable open <paths>...

ARGS:
    <paths>...    

FLAGS:
    -h, --help       Prints help information
    -V, --version    Prints version information
""",
    "set": """executable-set 
Set the default handler for mime/extension

USAGE:
    executable set <mime> <handler>

ARGS:
    <mime>       
    <handler>    

FLAGS:
    -h, --help       Prints help information
    -V, --version    Prints version information
""",
    "unset": """executable-unset 
Unset the default handler for mime/extension

USAGE:
    executable unset <mime>

ARGS:
    <mime>    

FLAGS:
    -h, --help       Prints help information
    -V, --version    Prints version information
""",
    "launch": """executable-launch 
Launch the handler for specified extension/mime with optional arguments

USAGE:
    executable launch <mime> [args]...

ARGS:
    <mime>       
    <args>...    

FLAGS:
    -h, --help       Prints help information
    -V, --version    Prints version information
""",
    "get": """executable-get 
Get handler for this mime/extension

USAGE:
    executable get [FLAGS] <mime>

ARGS:
    <mime>    

FLAGS:
        --json       
    -h, --help       Prints help information
    -V, --version    Prints version information
""",
    "add": """executable-add 
Add a handler for given mime/extension Note that the first handler is the default

USAGE:
    executable add <mime> <handler>

ARGS:
    <mime>       
    <handler>    

FLAGS:
    -h, --help       Prints help information
    -V, --version    Prints version information
""",
}


def config_home():
    return Path(os.environ.get("XDG_CONFIG_HOME") or Path.home() / ".config")


def data_dirs():
    dirs = [Path(os.environ.get("XDG_DATA_HOME") or Path.home() / ".local/share")]
    for item in os.environ.get("XDG_DATA_DIRS", "/usr/local/share:/usr/share").split(":"):
        if item:
            dirs.append(Path(item))
    return dirs


def mimeapps_path():
    path = config_home() / "mimeapps.list"
    path.parent.mkdir(parents=True, exist_ok=True)
    if not path.exists():
        path.write_text("")
    return path


def invalid_mime(value):
    mimeapps_path()
    if value.startswith("."):
        return f"could not figure out the mime type of '{value}'"
    if "/" not in value:
        return "mime parse error: a slash (/) was missing between the type and subtype"
    if value.startswith("/"):
        return "mime parse error: an invalid token was encountered, 2F at position 0"
    if not re.match(r"^[A-Za-z0-9.+_-]+/([A-Za-z0-9.+_-]+|\*)$", value):
        return "mime parse error: an invalid token was encountered"
    return None


def die_invalid(kind, value, message):
    print(f"error: Invalid value for '<{kind}>': {message}\n", file=sys.stderr)
    print("For more information try --help", file=sys.stderr)
    return 2


def parse_desktop(path, app_id):
    entry = {"id": app_id, "path": path, "name": app_id, "exec": "", "mimes": []}
    try:
        for raw in path.read_text(errors="ignore").splitlines():
            line = raw.strip()
            if not line or line.startswith("#") or "=" not in line:
                continue
            key, val = line.split("=", 1)
            if key == "Name":
                entry["name"] = val
            elif key == "Exec":
                entry["exec"] = val
            elif key == "MimeType":
                entry["mimes"] = [x for x in val.split(";") if x]
    except OSError:
        return None
    return entry if entry["exec"] or entry["mimes"] else None


def desktop_entries():
    entries = {}
    for base in data_dirs():
        apps = base / "applications"
        if not apps.is_dir():
            continue
        for path in apps.rglob("*.desktop"):
            try:
                rel = path.relative_to(apps)
            except ValueError:
                rel = path.name
            app_id = str(rel).replace("/", "-")
            if app_id not in entries:
                parsed = parse_desktop(path, app_id)
                if parsed:
                    entries[app_id] = parsed
    return entries


def load_defaults():
    path = mimeapps_path()
    current = None
    defaults = {}
    for raw in path.read_text(errors="ignore").splitlines():
        line = raw.strip()
        if line.startswith("[") and line.endswith("]"):
            current = line
            continue
        if current == "[Default Applications]" and "=" in line:
            key, val = line.split("=", 1)
            defaults[key] = [x for x in val.split(";") if x]
    return defaults


def save_defaults(defaults):
    lines = ["[Added Associations]", "", "[Default Applications]"]
    for mime in sorted(defaults):
        handlers = defaults[mime]
        if handlers:
            lines.append(f"{mime}={';'.join(handlers)};")
    mimeapps_path().write_text("\n".join(lines) + "\n")


def system_associations(entries):
    assoc = {}
    for app_id, entry in entries.items():
        for mime in entry["mimes"]:
            assoc.setdefault(mime, []).append(app_id)
    for mime in assoc:
        assoc[mime] = sorted(set(assoc[mime]))
    return assoc


def resolve_handler(mime):
    defaults = load_defaults()
    if defaults.get(mime):
        return defaults[mime][0]
    major = mime.split("/", 1)[0] + "/*"
    if defaults.get(major):
        return defaults[major][0]
    assoc = system_associations(desktop_entries())
    if assoc.get(mime):
        return assoc[mime][0]
    if assoc.get(major):
        return assoc[major][0]
    return None


def command_without_file_fields(exec_line):
    parts = shlex.split(exec_line)
    kept = [p for p in parts if p not in ("%f", "%F", "%u", "%U")]
    return " ".join(kept)


def print_table(rows):
    if not rows:
        return "┌──┐\n│  │\n└──┘\n"
    w1 = max(len(k) for k, _ in rows)
    w2 = max(len(v) for _, v in rows)
    out = [
        f"┌{'─' * (w1 + 2)}┬{'─' * (w2 + 2)}┐",
    ]
    for left, right in rows:
        out.append(f"│ {left.ljust(w1)} │ {right.ljust(w2)} │")
    out.append(f"└{'─' * (w1 + 2)}┴{'─' * (w2 + 2)}┘")
    return "\n".join(out) + "\n"


def cmd_set(args, append=False):
    if len(args) != 2:
        print(SUBHELP["add" if append else "set"], end="")
        return 1
    mime, handler = args
    err = invalid_mime(mime)
    if err:
        return die_invalid("mime", mime, err)
    if handler not in desktop_entries():
        return die_invalid("handler", handler, f"no handlers found for '{handler}'")
    defaults = load_defaults()
    current = defaults.get(mime, [])
    if append:
        if handler not in current:
            current.append(handler)
        defaults[mime] = current
    else:
        defaults[mime] = [handler]
    save_defaults(defaults)
    return 0


def cmd_unset(args):
    if len(args) != 1:
        print(SUBHELP["unset"], end="")
        return 1
    mime = args[0]
    err = invalid_mime(mime)
    if err:
        return die_invalid("mime", mime, err)
    defaults = load_defaults()
    defaults.pop(mime, None)
    save_defaults(defaults)
    return 0


def cmd_get(args):
    as_json = False
    if args and args[0] == "--json":
        as_json = True
        args = args[1:]
    if len(args) != 1:
        print(SUBHELP["get"], end="")
        return 1
    mime = args[0]
    err = invalid_mime(mime)
    if err:
        return die_invalid("mime", mime, err)
    handler = resolve_handler(mime)
    if not handler:
        return 1
    if as_json:
        entry = desktop_entries().get(handler, {})
        print(json.dumps({
            "handler": handler,
            "name": entry.get("name", handler),
            "cmd": command_without_file_fields(entry.get("exec", "")),
        }, separators=(",", ":")))
    else:
        print(handler)
    return 0


def cmd_list(args):
    show_all = args in (["--all"], ["-a"])
    defaults = load_defaults()
    rows = [(mime, ", ".join(handlers)) for mime, handlers in sorted(defaults.items()) if handlers]
    if show_all:
        sys.stdout.write("Default Apps\n")
    sys.stdout.write(print_table(rows))
    if show_all:
        assoc = system_associations(desktop_entries())
        all_rows = [(mime, ", ".join(assoc[mime])) for mime in sorted(assoc)]
        sys.stdout.write("System Apps\n")
        sys.stdout.write(print_table(all_rows))
    return 0


def launch_handler(handler, args):
    entry = desktop_entries().get(handler)
    if not entry or not entry.get("exec"):
        return 1
    parts = shlex.split(entry["exec"])
    used = False
    expanded = []
    for part in parts:
        if part in ("%f", "%F", "%u", "%U"):
            expanded.extend(args)
            used = True
        else:
            expanded.append(part)
    if not used:
        expanded.extend(args)
    try:
        return subprocess.run(expanded, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL).returncode
    except OSError:
        return 1


def cmd_launch(args):
    if not args:
        print(SUBHELP["launch"], end="")
        return 1
    mime = args[0]
    rest = args[1:]
    if rest and rest[0] == "--":
        rest = rest[1:]
    err = invalid_mime(mime)
    if err:
        return die_invalid("mime", mime, err)
    handler = resolve_handler(mime)
    if not handler:
        return 1
    return launch_handler(handler, rest)


def guess_open_mime(path):
    if re.match(r"^[A-Za-z][A-Za-z0-9+.-]*://", path):
        return "x-scheme-handler/" + path.split(":", 1)[0]
    ext = Path(path).suffix.lower()
    return {
        ".txt": "text/plain",
        ".md": "text/markdown",
        ".png": "image/png",
        ".jpg": "image/jpeg",
        ".jpeg": "image/jpeg",
        ".pdf": "application/pdf",
        ".html": "text/html",
        ".htm": "text/html",
        ".desktop": "application/x-desktop",
        ".ui": "application/xml",
        ".vim": "text/x-vim",
    }.get(ext)


def cmd_open(args):
    if not args:
        print(SUBHELP["open"], end="")
        return 1
    status = 0
    for item in args:
        mime = guess_open_mime(item)
        if not mime:
            status = 1
            continue
        handler = resolve_handler(mime)
        if not handler or launch_handler(handler, [item]) != 0:
            status = 1
    return status


def main(argv):
    if not argv:
        print(HELP, end="")
        return 0
    if argv[0] in ("-h", "--help"):
        print(HELP, end="")
        return 0
    if argv[0] in ("-V", "--version"):
        print(VERSION)
        return 0
    cmd, args = argv[0], argv[1:]
    if cmd in SUBHELP and args and args[0] in ("-h", "--help"):
        print(SUBHELP[cmd], end="")
        return 0
    if cmd in SUBHELP and args and args[0] in ("-V", "--version"):
        print(VERSION)
        return 0
    if cmd == "set":
        return cmd_set(args)
    if cmd == "add":
        return cmd_set(args, append=True)
    if cmd == "unset":
        return cmd_unset(args)
    if cmd == "get":
        return cmd_get(args)
    if cmd == "list":
        return cmd_list(args)
    if cmd == "launch":
        return cmd_launch(args)
    if cmd == "open":
        return cmd_open(args)
    print(f"error: Found argument '{cmd}' which wasn't expected, or isn't valid in this context\n", file=sys.stderr)
    print(f"If you tried to supply `{cmd}` as a PATTERN use `-- {cmd}`\n", file=sys.stderr)
    print("USAGE:\n    executable <SUBCOMMAND>\n", file=sys.stderr)
    print("For more information try --help", file=sys.stderr)
    return 1


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
