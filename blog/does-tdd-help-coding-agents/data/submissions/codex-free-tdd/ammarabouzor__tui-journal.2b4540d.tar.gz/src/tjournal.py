#!/usr/bin/env python3
import json
import os
import sys
from pathlib import Path


VERSION = "tui-journal 0.16.1"
HOME = os.environ.get("HOME", "/home/agent")

DEFAULT_THEME = """[general.input_block_active]
fg = "LightYellow"
modifiers = ""

[general.input_block_invalid]
fg = "LightRed"
modifiers = ""

[general.input_corsur_active]
fg = "Black"
bg = "LightYellow"
modifiers = ""

[general.input_corsur_invalid]
fg = "Black"
bg = "LightRed"
modifiers = ""

[general.list_item_selected]
fg = "LightYellow"
modifiers = "BOLD"

[general.list_highlight_active]
fg = "Black"
bg = "LightGreen"
modifiers = ""

[general.list_highlight_inactive]
fg = "Black"
bg = "LightBlue"
modifiers = ""

[journals_list.block_active]
fg = "Reset"
modifiers = "BOLD"

[journals_list.block_inactive]
fg = "#AAAAC8"
modifiers = ""

[journals_list.block_multi_select]
fg = "Yellow"
modifiers = "BOLD | ITALIC"

[journals_list.highlight_active]
fg = "Black"
bg = "LightGreen"
modifiers = "BOLD"

[journals_list.highlight_inactive]
fg = "Black"
bg = "LightBlue"
modifiers = "BOLD"

[journals_list.title_active]
fg = "Reset"
modifiers = "BOLD"

[journals_list.title_inactive]
fg = "#AAAAC8"
modifiers = "BOLD"

[journals_list.title_selected]
fg = "Yellow"
modifiers = "BOLD"

[journals_list.date_priority]
fg = "LightBlue"
modifiers = ""

[journals_list.tags_default]
fg = "LightCyan"
modifiers = "DIM"

[editor.block_insert]
fg = "LightGreen"
modifiers = "BOLD"

[editor.block_visual]
fg = "Blue"
modifiers = "BOLD"

[editor.block_normal_active]
fg = "Reset"
modifiers = "BOLD"

[editor.block_normal_inactive]
fg = "#AAAAC8"
modifiers = ""

[editor.cursor_normal]
fg = "Black"
bg = "White"
modifiers = ""

[editor.cursor_insert]
fg = "Black"
bg = "LightGreen"
modifiers = ""

[editor.cursor_visual]
fg = "Black"
bg = "Blue"
modifiers = ""

[editor.selection_style]
fg = "Black"
bg = "White"
modifiers = ""

[msgbox]
error = "LightRed"
warning = "Yellow"
info = "LightGreen"
question = "LightBlue"

"""


TOP_HELP = """Tui app allows writing and managing journals/notes from within the terminal With different local back-ends

Usage: executable [OPTIONS] [COMMAND]

Commands:
  print-config     Print the current settings including the paths for the back-end files [aliases: pc]
  import-journals  Import journals from the given transfer JSON file to the current back-end file [aliases: imj]
  assign-priority  Assign priority for all the entries with empty priority field [aliases: ap]
  theme            Provides commands regarding changing themes and styles of the app [aliases: style]
  help             Print this message or the help of the given subcommand(s)

Options:
  -j, --json-file-path <FILE PATH>    Sets the entries Json file path and starts using it
  -s, --sqlite-file-path <FILE PATH>  Sets the entries sqlite file path and starts using it
  -b, --backend-type <BACKEND_TYPE>   Sets the backend type and starts using it [possible values: json, sqlite]
  -c, --config <DIR PATH>             Specifies the path for the configuration directory.
                                      Configuration files is considered as root for themes file too.
                                      It still accepts the path for configuration file for backward compatibility.
                                      (default path: /home/agent/.config/tui-journal)
  -v, --verbose...                    Increases logging verbosity each use for up to 3 times
  -l, --log <FILE PATH>               Specifies a file to use for logging
                                      (default file: /home/agent/.cache/tui-journal/tui-journal.log)
  -h, --help                          Print help
  -V, --version                       Print version
"""

THEME_HELP = """Provides commands regarding changing themes and styles of the app

Usage: executable theme <COMMAND>

Commands:
  print-path      Prints the path to the user themes file [aliases: path]
  print-default   Dumps the styles with the default values to be used as a reference and base for user custom themes [aliases: default]
  write-defaults  Creates user custom themes file if doesn't exist then writes the default styles to it [aliases: write]
  help            Print this message or the help of the given subcommand(s)

Options:
  -h, --help  Print help
"""

SUB_HELP = {
    "print-config": """Print the current settings including the paths for the back-end files

Usage: executable print-config

Options:
  -h, --help  Print help
""",
    "import-journals": """Import journals from the given transfer JSON file to the current back-end file

Usage: executable import-journals --path <FILE PATH>

Options:
  -p, --path <FILE PATH>  Path of the JSON file to import from
  -h, --help              Print help
""",
    "assign-priority": """Assign priority for all the entries with empty priority field

Usage: executable assign-priority <PRIORITY>

Arguments:
  <PRIORITY>  Priority value (Positive number)

Options:
  -h, --help  Print help
""",
}


def default_config():
    return {
        "backend_type": "Sqlite",
        "scroll_per_page": 5,
        "sync_os_clipboard": False,
        "history_limit": 10,
        "colored_tags": True,
        "datum_visibility": "show",
        "app_state_dir": f"{HOME}/.local/state/tui-journal",
        "export": {"show_confirmation": True},
        "external_editor": {"auto_save": False, "temp_file_extension": "txt"},
        "json_backend": {"file_path": f"{HOME}/tui-journal/entries.json"},
        "sqlite_backend": {"file_path": f"{HOME}/tui-journal/entries.db"},
    }


def parse_value(raw):
    raw = raw.split("#", 1)[0].strip()
    if raw.startswith('"') and raw.endswith('"'):
        return raw[1:-1]
    if raw == "true":
        return True
    if raw == "false":
        return False
    try:
        return int(raw)
    except ValueError:
        return raw


def config_file_for(config_arg):
    if config_arg is None:
        return Path(HOME) / ".config" / "tui-journal" / "config.toml"
    p = Path(config_arg)
    if p.name == "config.toml" or (p.exists() and p.is_file()):
        return p
    return p / "config.toml"


def config_dir_for(config_arg):
    if config_arg is None:
        return Path(HOME) / ".config" / "tui-journal"
    p = Path(config_arg)
    if p.name == "config.toml" or (p.exists() and p.is_file()):
        return p.parent
    return p


def load_config(config_arg):
    cfg = default_config()
    path = config_file_for(config_arg)
    if not path.exists():
        return cfg
    section = None
    for line in path.read_text().splitlines():
        stripped = line.strip()
        if not stripped or stripped.startswith("#"):
            continue
        if stripped.startswith("[") and stripped.endswith("]"):
            section = stripped[1:-1]
            cfg.setdefault(section, {})
            continue
        if "=" not in stripped:
            continue
        key, raw_value = stripped.split("=", 1)
        key = key.strip()
        value = parse_value(raw_value)
        if section:
            cfg.setdefault(section, {})[key] = value
        else:
            if key == "backend_type" and isinstance(value, str):
                value = value[:1].upper() + value[1:].lower()
            cfg[key] = value
    return cfg


def toml_scalar(value):
    if isinstance(value, bool):
        return "true" if value else "false"
    if isinstance(value, int):
        return str(value)
    return f'"{value}"'


def format_config(cfg):
    lines = [
        f'backend_type = {toml_scalar(cfg["backend_type"])}',
        f'scroll_per_page = {toml_scalar(cfg["scroll_per_page"])}',
        f'sync_os_clipboard = {toml_scalar(cfg["sync_os_clipboard"])}',
        f'history_limit = {toml_scalar(cfg["history_limit"])}',
        f'colored_tags = {toml_scalar(cfg["colored_tags"])}',
        f'datum_visibility = {toml_scalar(cfg["datum_visibility"])}',
        f'app_state_dir = {toml_scalar(cfg["app_state_dir"])}',
        "",
        "[export]",
        f'show_confirmation = {toml_scalar(cfg["export"]["show_confirmation"])}',
        "",
        "[external_editor]",
        f'auto_save = {toml_scalar(cfg["external_editor"]["auto_save"])}',
        f'temp_file_extension = {toml_scalar(cfg["external_editor"]["temp_file_extension"])}',
        "",
        "[json_backend]",
        f'file_path = {toml_scalar(cfg["json_backend"]["file_path"])}',
        "",
        "[sqlite_backend]",
        f'file_path = {toml_scalar(cfg["sqlite_backend"]["file_path"])}',
        "",
        "",
    ]
    return "\n".join(lines)


def normalize_backend(value):
    lower = value.lower()
    if lower == "json":
        return "Json"
    if lower == "sqlite":
        return "Sqlite"
    return None


def parse_global(argv):
    opts = {"config": None, "backend": None, "json": None, "sqlite": None}
    rest = []
    i = 0
    while i < len(argv):
        arg = argv[i]
        if arg in ("-h", "--help"):
            sys.stdout.write(TOP_HELP)
            raise SystemExit(0)
        if arg in ("-V", "--version"):
            print(VERSION)
            raise SystemExit(0)
        if arg in ("-v", "--verbose"):
            i += 1
            continue
        if arg in ("-l", "--log", "-c", "--config", "-b", "--backend-type", "-j", "--json-file-path", "-s", "--sqlite-file-path"):
            if i + 1 >= len(argv):
                print(f"error: a value is required for '{arg}' but none was supplied\n\nFor more information, try '--help'.", file=sys.stderr)
                raise SystemExit(2)
            value = argv[i + 1]
            if arg in ("-c", "--config"):
                opts["config"] = value
            elif arg in ("-b", "--backend-type"):
                backend = normalize_backend(value)
                if backend is None:
                    print(f"error: invalid value '{value}' for '--backend-type <BACKEND_TYPE>'\n  [possible values: json, sqlite]\n\nFor more information, try '--help'.", file=sys.stderr)
                    raise SystemExit(2)
                opts["backend"] = backend
            elif arg in ("-j", "--json-file-path"):
                opts["json"] = value
            elif arg in ("-s", "--sqlite-file-path"):
                opts["sqlite"] = value
            i += 2
            continue
        rest = argv[i:]
        break
    return opts, rest


def apply_cli_overrides(cfg, opts):
    if opts["backend"]:
        cfg["backend_type"] = opts["backend"]
    if opts["json"]:
        cfg["json_backend"]["file_path"] = opts["json"]
        cfg["backend_type"] = "Json"
    if opts["sqlite"]:
        cfg["sqlite_backend"]["file_path"] = opts["sqlite"]
        cfg["backend_type"] = "Sqlite"


def read_entries(path):
    if not Path(path).exists():
        return []
    with open(path, "r", encoding="utf-8") as f:
        data = json.load(f)
    if isinstance(data, list):
        return data
    if isinstance(data, dict):
        for key in ("entries", "journals", "items"):
            if isinstance(data.get(key), list):
                return data[key]
    return []


def write_entries(path, entries):
    p = Path(path)
    p.parent.mkdir(parents=True, exist_ok=True)
    with open(p, "w", encoding="utf-8") as f:
        json.dump(entries, f, indent=2, ensure_ascii=False)
        f.write("\n")


def current_json_path(cfg):
    return cfg["json_backend"]["file_path"]


def command_print_config(cfg, args):
    if args in (["--help"], ["-h"]):
        sys.stdout.write(SUB_HELP["print-config"])
        return 0
    print(format_config(cfg), end="")
    return 0


def command_theme(config_arg, args):
    if not args or args[0] in ("--help", "-h", "help"):
        sys.stdout.write(THEME_HELP)
        return 0
    cmd = args[0]
    theme_path = config_dir_for(config_arg) / "themes.toml"
    if cmd in ("print-path", "path"):
        print(theme_path)
        return 0
    if cmd in ("print-default", "default"):
        print(DEFAULT_THEME, end="")
        return 0
    if cmd in ("write-defaults", "write"):
        theme_path.parent.mkdir(parents=True, exist_ok=True)
        theme_path.write_text(DEFAULT_THEME)
        print(f"Default themes have been written to {theme_path}")
        return 0
    print(f"error: unrecognized subcommand '{cmd}'\n\nUsage: executable theme <COMMAND>\n\nFor more information, try '--help'.", file=sys.stderr)
    return 2


def command_import(cfg, args):
    if args in (["--help"], ["-h"]):
        sys.stdout.write(SUB_HELP["import-journals"])
        return 0
    path = None
    i = 0
    while i < len(args):
        if args[i] in ("-p", "--path") and i + 1 < len(args):
            path = args[i + 1]
            i += 2
        else:
            i += 1
    if not path:
        print("error: the following required arguments were not provided:\n  --path <FILE PATH>\n\nUsage: executable import-journals --path <FILE PATH>\n\nFor more information, try '--help'.", file=sys.stderr)
        return 2
    imported = read_entries(path)
    dest = current_json_path(cfg)
    existing = read_entries(dest)
    write_entries(dest, existing + imported)
    print(f"Imported {len(imported)} journals")
    return 0


def command_priority(cfg, args):
    if args in (["--help"], ["-h"]):
        sys.stdout.write(SUB_HELP["assign-priority"])
        return 0
    if not args:
        print("error: the following required arguments were not provided:\n  <PRIORITY>\n\nUsage: executable assign-priority <PRIORITY>\n\nFor more information, try '--help'.", file=sys.stderr)
        return 2
    try:
        priority = int(args[0])
    except ValueError:
        print(f"error: invalid value '{args[0]}' for '<PRIORITY>': invalid digit found in string\n\nFor more information, try '--help'.", file=sys.stderr)
        return 2
    entries = read_entries(current_json_path(cfg))
    changed = 0
    for entry in entries:
        if isinstance(entry, dict) and not entry.get("priority"):
            entry["priority"] = priority
            changed += 1
    write_entries(current_json_path(cfg), entries)
    print(f"Assigned priority {priority} to {changed} journals")
    return 0


def main(argv):
    opts, rest = parse_global(argv)
    cfg = load_config(opts["config"])
    apply_cli_overrides(cfg, opts)
    if not rest:
        print("Error: No such device or address (os error 6)", file=sys.stderr)
        return 1
    cmd, args = rest[0], rest[1:]
    aliases = {"pc": "print-config", "imj": "import-journals", "ap": "assign-priority", "style": "theme"}
    cmd = aliases.get(cmd, cmd)
    if cmd == "help":
        if not args:
            sys.stdout.write(TOP_HELP)
        elif args[0] == "theme":
            sys.stdout.write(THEME_HELP)
        elif args[0] in SUB_HELP:
            sys.stdout.write(SUB_HELP[args[0]])
        else:
            sys.stdout.write(TOP_HELP)
        return 0
    if cmd == "print-config":
        return command_print_config(cfg, args)
    if cmd == "theme":
        return command_theme(opts["config"], args)
    if cmd == "import-journals":
        return command_import(cfg, args)
    if cmd == "assign-priority":
        return command_priority(cfg, args)
    print(f"error: unrecognized subcommand '{cmd}'\n\nUsage: executable [OPTIONS] [COMMAND]\n\nFor more information, try '--help'.", file=sys.stderr)
    return 2


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
