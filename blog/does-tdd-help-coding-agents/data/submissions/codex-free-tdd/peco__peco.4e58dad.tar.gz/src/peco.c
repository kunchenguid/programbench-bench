#define _GNU_SOURCE

#include <errno.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

static const char *help_text =
"\n"
"Usage: peco [options] [FILE]\n"
"\n"
"Options:\n"
"  -h, --help            show this help message and exit\n"
"  --query               initial value for query\n"
"  --rcfile              path to the settings file\n"
"  --version             print the version and exit\n"
"  -b, --buffer-size     number of lines to keep in search buffer\n"
"  --null                expect NUL (\\0) as separator for target/output\n"
"  --initial-index       position of the initial index of the selection (0 base)\n"
"  --initial-filter      specify the default filter\n"
"  --prompt              specify the prompt string\n"
"  --layout              layout to be used. 'top-down', 'bottom-up', or 'top-down-query-bottom'. default is 'top-down'\n"
"  --select-1            select first item and immediately exit if the input contains only 1 item\n"
"  --exit-0              exit immediately with status 1 if the input is empty\n"
"  --select-all          select all items and immediately exit\n"
"  --on-cancel           specify action on user cancel. 'success' or 'error'.\n"
"                        default is 'success'. This may change in future versions\n"
"  --selection-prefix    use a prefix instead of changing line color to indicate currently selected lines.\n"
"                        default is to use colors. This option is experimental\n"
"  --exec                execute command instead of finishing/terminating peco.\n"
"                        Please note that this command will receive selected line(s) from stdin,\n"
"                        and will be executed via '/bin/sh -c' or 'cmd /c'\n"
"  --print-query         print out the current query as first line of output\n"
"  --ansi                enable ANSI color code support\n"
"  --height              display height in lines or percentage (e.g. '10', '50%')\n";

typedef struct {
    char *display;
    char *result;
} Line;

typedef struct {
    int help, version, select_one, select_all, exit_zero, nul, print_query, ansi;
    int has_query, has_buffer;
    const char *query;
    const char *file;
    const char *rcfile;
} Options;

static int is_number(const char *s) {
    if (!s || !*s) return 0;
    if (*s == '-') s++;
    if (!*s) return 0;
    while (*s) {
        if (*s < '0' || *s > '9') return 0;
        s++;
    }
    return 1;
}

static void parse_error(const char *msg) {
    fprintf(stderr, "%s\n%s", msg, help_text);
    fprintf(stderr, "Error: failed to setup peco: failed to parse command line: failed to parse command line options: invalid command line options: %s\n", msg);
}

static int need_arg(int *i, int argc, char **argv, const char *flag, const char **out) {
    if (*i + 1 >= argc) {
        char buf[256];
        snprintf(buf, sizeof(buf), "expected argument for flag `%s'", flag);
        parse_error(buf);
        return 0;
    }
    *out = argv[++(*i)];
    return 1;
}

static int parse_options(int argc, char **argv, Options *o) {
    memset(o, 0, sizeof(*o));
    for (int i = 1; i < argc; i++) {
        char *a = argv[i];
        const char *v = NULL;
        if (!strcmp(a, "-h") || !strcmp(a, "--help")) o->help = 1;
        else if (!strcmp(a, "--version")) o->version = 1;
        else if (!strcmp(a, "--select-1")) o->select_one = 1;
        else if (!strcmp(a, "--select-all")) o->select_all = 1;
        else if (!strcmp(a, "--exit-0")) o->exit_zero = 1;
        else if (!strcmp(a, "--null")) o->nul = 1;
        else if (!strcmp(a, "--print-query")) o->print_query = 1;
        else if (!strcmp(a, "--ansi")) o->ansi = 1;
        else if (!strcmp(a, "--query")) {
            if (!need_arg(&i, argc, argv, "--query", &v)) return 0;
            o->query = v; o->has_query = 1;
        } else if (!strncmp(a, "--query=", 8)) {
            o->query = a + 8; o->has_query = 1;
        } else if (!strcmp(a, "--layout")) {
            if (!need_arg(&i, argc, argv, "--layout", &v)) return 0;
            if (strcmp(v, "top-down") && strcmp(v, "bottom-up") && strcmp(v, "top-down-query-bottom")) {
                fprintf(stderr, "Error: failed to setup peco: failed to parse command line: failed to parse command line options: invalid command line arguments: unknown layout: '%s'\n", v);
                return 0;
            }
        } else if (!strncmp(a, "--layout=", 9)) {
            v = a + 9;
            if (strcmp(v, "top-down") && strcmp(v, "bottom-up") && strcmp(v, "top-down-query-bottom")) {
                fprintf(stderr, "Error: failed to setup peco: failed to parse command line: failed to parse command line options: invalid command line arguments: unknown layout: '%s'\n", v);
                return 0;
            }
        } else if (!strcmp(a, "--on-cancel")) {
            if (!need_arg(&i, argc, argv, "--on-cancel", &v)) return 0;
            if (strcmp(v, "success") && strcmp(v, "error")) {
                fprintf(stderr, "Error: failed to setup peco: failed to apply configuration: invalid --on-cancel value: invalid OnCancel value \"%s\": must be \"success\" or \"error\"\n", v);
                return 0;
            }
        } else if (!strcmp(a, "--height")) {
            if (!need_arg(&i, argc, argv, "--height", &v)) return 0;
            if (!strcmp(v, "0")) {
                fprintf(stderr, "Error: failed to setup peco: failed to apply configuration: failed to parse height specification: height must be positive: \"%s\"\n", v);
                return 0;
            }
            size_t n = strlen(v);
            int pct = n && v[n - 1] == '%';
            char tmp[128];
            snprintf(tmp, sizeof(tmp), "%s", v);
            if (pct) tmp[n - 1] = '\0';
            if (!is_number(tmp) || atoi(tmp) <= 0) {
                fprintf(stderr, "Error: failed to setup peco: failed to apply configuration: failed to parse height specification: invalid height specification: \"%s\"\n", v);
                return 0;
            }
        } else if (!strcmp(a, "--initial-filter")) {
            if (!need_arg(&i, argc, argv, "--initial-filter", &v)) return 0;
            if (strcmp(v, "IgnoreCase") && strcmp(v, "CaseSensitive") && strcmp(v, "SmartCase") && strcmp(v, "IRegexp") && strcmp(v, "Regexp") && strcmp(v, "Fuzzy")) {
                fprintf(stderr, "Error: failed to setup peco: failed to apply configuration: failed to populate initial filter: failed to set filter: specified filter was not found\n");
                return 0;
            }
        } else if (!strcmp(a, "--rcfile")) {
            if (!need_arg(&i, argc, argv, a, &v)) return 0;
            o->rcfile = v;
        } else if (!strcmp(a, "--prompt") || !strcmp(a, "--selection-prefix") || !strcmp(a, "--exec")) {
            if (!need_arg(&i, argc, argv, a, &v)) return 0;
        } else if (!strcmp(a, "--initial-index")) {
            if (!need_arg(&i, argc, argv, "--initial-index", &v)) return 0;
            if (!is_number(v)) {
                char buf[512];
                snprintf(buf, sizeof(buf), "invalid argument for flag `--initial-index' (expected int): strconv.ParseInt: parsing \"%s\": invalid syntax", v);
                parse_error(buf);
                return 0;
            }
        } else if (!strcmp(a, "-b") || !strcmp(a, "--buffer-size")) {
            if (!need_arg(&i, argc, argv, a, &v)) return 0;
            if (!is_number(v)) {
                char buf[512];
                snprintf(buf, sizeof(buf), "invalid argument for flag `-b, --buffer-size' (expected int): strconv.ParseInt: parsing \"%s\": invalid syntax", v);
                parse_error(buf);
                return 0;
            }
            o->has_buffer = 1;
        } else if (!strncmp(a, "--buffer-size=", 14)) {
            v = a + 14;
            if (!is_number(v)) {
                char buf[512];
                snprintf(buf, sizeof(buf), "invalid argument for flag `-b, --buffer-size' (expected int): strconv.ParseInt: parsing \"%s\": invalid syntax", v);
                parse_error(buf);
                return 0;
            }
            o->has_buffer = 1;
        } else if (a[0] == '-') {
            char buf[256];
            snprintf(buf, sizeof(buf), "unknown flag `%s'", a + (a[1] == '-' ? 2 : 1));
            parse_error(buf);
            return 0;
        } else if (!o->file) {
            o->file = a;
        }
    }
    return 1;
}

static char *dup_range(const char *start, size_t n) {
    char *s = malloc(n + 1);
    if (!s) exit(2);
    memcpy(s, start, n);
    s[n] = '\0';
    return s;
}

static char *dup_cstr(const char *s) {
    return dup_range(s, strlen(s));
}

static int read_lines(FILE *in, int nul, Line **out, size_t *count) {
    Line *lines = NULL;
    size_t cap = 0, len = 0;
    char *buf = NULL;
    size_t bufsz = 0;
    ssize_t n;
    while ((n = getline(&buf, &bufsz, in)) != -1) {
        while (n > 0 && (buf[n - 1] == '\n' || buf[n - 1] == '\r')) n--;
        if (len == cap) {
            cap = cap ? cap * 2 : 16;
            lines = realloc(lines, cap * sizeof(Line));
            if (!lines) exit(2);
        }
        char *zero = nul ? memchr(buf, '\0', (size_t)n) : NULL;
        if (zero) {
            lines[len].display = dup_range(buf, (size_t)(zero - buf));
            lines[len].result = dup_range(zero + 1, (size_t)(buf + n - zero - 1));
        } else {
            lines[len].display = dup_range(buf, (size_t)n);
            lines[len].result = dup_cstr(lines[len].display);
        }
        len++;
    }
    free(buf);
    *out = lines;
    *count = len;
    return 1;
}

static void write_line(const char *s) {
    fputs(s, stdout);
    fputc('\n', stdout);
}

static int screen_error(void) {
    const char *term = getenv("TERM");
    if (!term || !*term) {
        fprintf(stderr, "Error: failed to initialize screen: failed to create tcell screen: terminal entry not found: term not set\n");
    } else {
        fprintf(stderr, "Error: failed to initialize screen: failed to initialize tcell screen: open /dev/tty: no such device or address\n");
    }
    return 1;
}

int main(int argc, char **argv) {
    Options o;
    if (!parse_options(argc, argv, &o)) return 1;
    if (o.help) { fputs(help_text, stdout); return 0; }
    if (o.version) { puts("peco version v0.5.11 (built with go1.25.0)"); return 0; }

    if (o.rcfile) {
        FILE *rc = fopen(o.rcfile, "rb");
        if (!rc) {
            fprintf(stderr, "Error: failed to setup peco: failed to setup configuration: failed to read config file: failed to open file %s: open %s: no such file or directory\n", o.rcfile, o.rcfile);
            return 1;
        }
        fclose(rc);
    }

    FILE *in = stdin;
    if (o.file) {
        in = fopen(o.file, "rb");
        if (!in) {
            if (errno == ENOENT) {
                fprintf(stderr, "Error: failed to setup input source: failed to open file for input: open %s: no such file or directory\n", o.file);
            } else {
                fprintf(stderr, "Error: failed to setup input source: failed to open file for input: open %s: %s\n", o.file, strerror(errno));
            }
            return 1;
        }
    }

    Line *lines = NULL;
    size_t n = 0;
    read_lines(in, o.nul, &lines, &n);
    if (in != stdin) fclose(in);

    if (o.exit_zero && n == 0) return 1;
    if (o.select_one && n == 1 && !o.has_query && !o.has_buffer) {
        if (o.print_query) write_line(o.query ? o.query : "");
        write_line(lines[0].result);
        return 0;
    }
    if (o.select_all && !o.has_query && !o.has_buffer) {
        if (o.print_query) write_line(o.query ? o.query : "");
        for (size_t i = 0; i < n; i++) write_line(lines[i].result);
        return 0;
    }
    return screen_error();
}
