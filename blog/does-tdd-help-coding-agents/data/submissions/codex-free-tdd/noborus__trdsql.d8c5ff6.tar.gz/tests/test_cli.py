import json
import os
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
CLI = ROOT / "src" / "trdsql.py"


def run_cli(args, cwd, stdin=None):
    return subprocess.run(
        [sys.executable, str(CLI), *args],
        cwd=cwd,
        input=stdin,
        text=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
    )


class TrdsqlCliTests(unittest.TestCase):
    def test_csv_query_without_header_uses_c_columns(self):
        with tempfile.TemporaryDirectory() as td:
            Path(td, "people.csv").write_text("name,age\nAlice,30\nBob,25\n")
            result = run_cli(["SELECT c1,c2 FROM people.csv WHERE c2 = '30'"], td)
            self.assertEqual(result.returncode, 0, result.stderr)
            self.assertEqual(result.stdout, "Alice,30\n")

    def test_csv_query_with_header_supports_where_order_and_output_header(self):
        with tempfile.TemporaryDirectory() as td:
            Path(td, "people.csv").write_text("name,age\nAlice,30\nBob,25\n")
            result = run_cli(
                ["-ih", "-ocsv", "-oh", "SELECT name,age FROM people.csv ORDER BY age"],
                td,
            )
            self.assertEqual(result.returncode, 0, result.stderr)
            self.assertEqual(result.stdout, "name,age\nBob,25\nAlice,30\n")

    def test_json_input_and_json_output_preserve_selected_column_names(self):
        with tempfile.TemporaryDirectory() as td:
            Path(td, "people.json").write_text(
                json.dumps([{"name": "Alice", "age": 30}, {"name": "Bob", "age": 25}])
            )
            result = run_cli(["-ojson", "SELECT name,age FROM people.json ORDER BY age"], td)
            self.assertEqual(result.returncode, 0, result.stderr)
            self.assertEqual(
                result.stdout,
                '[\n  {\n    "name": "Bob",\n    "age": "25"\n  },\n'
                '  {\n    "name": "Alice",\n    "age": "30"\n  }\n]\n',
            )

    def test_t_option_converts_csv_to_ltsv_with_default_column_names(self):
        with tempfile.TemporaryDirectory() as td:
            Path(td, "x.csv").write_text("a,b\n1,2\n")
            result = run_cli(["-oltsv", "-t", "x.csv"], td)
            self.assertEqual(result.returncode, 0, result.stderr)
            self.assertEqual(result.stdout, "c1:a\tc2:b\nc1:1\tc2:2\n")

    def test_query_can_read_csv_from_stdin(self):
        with tempfile.TemporaryDirectory() as td:
            result = run_cli(
                ["-icsv", "-ih", "SELECT name FROM - WHERE age > 25"],
                td,
                stdin="name,age\nAlice,30\nBob,25\n",
            )
            self.assertEqual(result.returncode, 0, result.stderr)
            self.assertEqual(result.stdout, "Alice\n")

    def test_ascii_table_output_matches_observed_layout(self):
        with tempfile.TemporaryDirectory() as td:
            Path(td, "x.csv").write_text("a,b\n1,2\n")
            result = run_cli(["-ih", "-oat", "SELECT * FROM x.csv"], td)
            self.assertEqual(result.returncode, 0, result.stderr)
            self.assertEqual(
                result.stdout,
                "+---+---+\n| a | b |\n+---+---+\n| 1 | 2 |\n+---+---+\n",
            )

    def test_ascii_table_right_aligns_numeric_cells(self):
        with tempfile.TemporaryDirectory() as td:
            Path(td, "people.csv").write_text("name,age\nAlice,30\nBob,25\n")
            result = run_cli(["-ih", "-oat", "SELECT * FROM people.csv"], td)
            self.assertEqual(result.returncode, 0, result.stderr)
            self.assertEqual(
                result.stdout,
                "+-------+-----+\n| name  | age |\n+-------+-----+\n"
                "| Alice |  30 |\n| Bob   |  25 |\n+-------+-----+\n",
            )

    def test_vertical_output_matches_observed_layout(self):
        with tempfile.TemporaryDirectory() as td:
            Path(td, "x.csv").write_text("a,b\n1,2\n")
            result = run_cli(["-ih", "-ovf", "SELECT * FROM x.csv"], td)
            self.assertEqual(result.returncode, 0, result.stderr)
            self.assertEqual(result.stdout, "---[ 1]------------------------\n  a | 1\n  b | 2\n")

    def test_tbln_output_includes_name_and_type_rows(self):
        with tempfile.TemporaryDirectory() as td:
            Path(td, "x.csv").write_text("a,b\n1,2\n")
            result = run_cli(["-ih", "-otbln", "SELECT * FROM x.csv"], td)
            self.assertEqual(result.returncode, 0, result.stderr)
            self.assertEqual(result.stdout, "; name: | a | b |\n; type: | text | text |\n| 1 | 2 |\n")

    def test_inum_adds_num_column(self):
        with tempfile.TemporaryDirectory() as td:
            Path(td, "x.csv").write_text("a,b\n1,2\n")
            result = run_cli(["-ih", "-inum", "-oh", "SELECT * FROM x.csv"], td)
            self.assertEqual(result.returncode, 0, result.stderr)
            self.assertEqual(result.stdout, "num,a,b\n1,1,2\n")


if __name__ == "__main__":
    unittest.main()
