#!/usr/bin/env python3
import csv
import io
import json
import os
import re
import sqlite3
import sys
from collections import OrderedDict


HELP = """trdsql - Execute SQL queries on CSV, LTSV, JSON, YAML and TBLN.

Usage
\ttrdsql [OPTIONS] [SQL(SELECT...)]

Options:
  -help               display usage information.
  -version            display version information.
"""


OUTPUT_FLAGS = {
    "-ocsv": "csv",
    "-ojson": "json",
    "-ojsonl": "jsonl",
    "-oltsv": "ltsv",
    "-omd": "md",
    "-oat": "at",
    "-ovf": "vf",
    "-otbln": "tbln",
    "-oraw": "raw",
    "-oyaml": "yaml",
}


INPUT_FLAGS = {
    "-icsv": "csv",
    "-ijson": "json",
    "-iltsv": "ltsv",
    "-itbln": "tbln",
    "-itext": "text",
    "-iyaml": "yaml",
}


def parse_args(argv):
    opts = {
        "input_format": None,
        "output_format": "csv",
        "input_delimiter": ",",
        "output_delimiter": ",",
        "quote": '"',
        "header_in": False,
        "header_out": False,
        "table_file": None,
        "query_file": None,
        "limit_rows": 0,
        "skip_rows": 0,
        "null_in": None,
        "null_out": "",
        "rownum": False,
    }
    positional = []
    i = 0
    while i < len(argv):
        arg = argv[i]
        if arg in ("-help", "--help"):
            opts["help"] = True
        elif arg == "-version":
            opts["version"] = True
        elif arg in OUTPUT_FLAGS:
            opts["output_format"] = OUTPUT_FLAGS[arg]
        elif arg in INPUT_FLAGS:
            opts["input_format"] = INPUT_FLAGS[arg]
        elif arg == "-ih":
            opts["header_in"] = True
        elif arg == "-oh":
            opts["header_out"] = True
        elif arg == "-inum":
            opts["rownum"] = True
        elif arg in ("-t", "-q", "-id", "-od", "-oq", "-ilr", "-is", "-inull", "-onull", "-out"):
            if i + 1 >= len(argv):
                raise SystemExit(f"{arg} requires an argument")
            val = argv[i + 1]
            if arg == "-t":
                opts["table_file"] = val
            elif arg == "-q":
                opts["query_file"] = val
            elif arg == "-id":
                opts["input_delimiter"] = val
            elif arg == "-od":
                opts["output_delimiter"] = val
            elif arg == "-oq":
                opts["quote"] = val
            elif arg == "-ilr":
                opts["limit_rows"] = int(val)
            elif arg == "-is":
                opts["skip_rows"] = int(val)
            elif arg == "-inull":
                opts["null_in"] = val
            elif arg == "-onull":
                opts["null_out"] = val
            elif arg == "-out":
                opts["out"] = val
            i += 1
        elif arg in ("-ig", "-oaq", "-ocrlf", "-onowrap", "-out-without-guess", "-debug", "-dblist"):
            pass
        elif arg in ("-config", "-db", "-driver", "-dsn", "-ijq", "-ir", "-oz", "-A", "-a"):
            if i + 1 < len(argv):
                i += 1
        else:
            positional.append(arg)
        i += 1
    if opts.get("query_file"):
        with open(opts["query_file"], encoding="utf-8") as f:
            opts["query"] = f.read().strip()
    elif positional:
        opts["query"] = " ".join(positional)
    elif opts.get("table_file"):
        opts["query"] = f"SELECT * FROM {opts['table_file']}"
    else:
        opts["query"] = ""
    return opts


def guess_format(name, forced):
    if forced:
        return forced
    ext = os.path.splitext(name)[1].lower()
    return {
        ".json": "json",
        ".jsonl": "json",
        ".ltsv": "ltsv",
        ".tbln": "tbln",
        ".yaml": "yaml",
        ".yml": "yaml",
        ".txt": "text",
    }.get(ext, "csv")


def clean_value(value, null_in):
    if value is None:
        return None
    text = str(value)
    if null_in is not None and text == null_in:
        return None
    return text


def unique_columns(columns):
    seen = {}
    out = []
    for idx, col in enumerate(columns, 1):
        name = str(col) if str(col) else f"c{idx}"
        if name in seen:
            seen[name] += 1
            name = f"{name}_{seen[name]}"
        else:
            seen[name] = 1
        out.append(name)
    return out


def read_csv_table(text, opts):
    reader = csv.reader(io.StringIO(text), delimiter=opts["input_delimiter"])
    rows = list(reader)
    if opts["skip_rows"]:
        rows = rows[opts["skip_rows"] :]
    if not rows:
        return [], []
    width = max(len(r) for r in rows)
    if opts["header_in"]:
        columns = unique_columns(rows[0])
        data_rows = rows[1:]
    else:
        columns = [f"c{i}" for i in range(1, width + 1)]
        data_rows = rows
    if opts["limit_rows"]:
        data_rows = data_rows[: opts["limit_rows"]]
    padded = []
    for row in data_rows:
        vals = [clean_value(v, opts["null_in"]) for v in row]
        padded.append(vals + [None] * (len(columns) - len(vals)))
    return columns, padded


def flatten_json_object(obj):
    if isinstance(obj, dict):
        return OrderedDict((str(k), clean_value(v, None)) for k, v in obj.items())
    return OrderedDict([("c1", clean_value(obj, None))])


def read_json_table(text, opts):
    stripped = text.strip()
    if not stripped:
        return [], []
    try:
        value = json.loads(stripped)
        items = value if isinstance(value, list) else [value]
    except json.JSONDecodeError:
        items = [json.loads(line) for line in stripped.splitlines() if line.strip()]
    objects = [flatten_json_object(item) for item in items]
    columns = []
    for obj in objects:
        for key in obj:
            if key not in columns:
                columns.append(key)
    rows = [[clean_value(obj.get(col), opts["null_in"]) for col in columns] for obj in objects]
    if opts["limit_rows"]:
        rows = rows[: opts["limit_rows"]]
    return columns, rows


def read_ltsv_table(text, opts):
    rows = []
    columns = []
    for line in text.splitlines():
        if not line:
            continue
        rec = OrderedDict()
        for part in line.split("\t"):
            if ":" in part:
                key, val = part.split(":", 1)
                rec[key] = clean_value(val, opts["null_in"])
                if key not in columns:
                    columns.append(key)
        rows.append(rec)
    return columns, [[row.get(col) for col in columns] for row in rows]


def read_table(name, opts, stdin_text):
    if name == "-":
        text = stdin_text
    else:
        with open(name, encoding="utf-8") as f:
            text = f.read()
    fmt = guess_format(name, opts["input_format"])
    if fmt == "json":
        return read_json_table(text, opts)
    if fmt == "ltsv":
        return read_ltsv_table(text, opts)
    return read_csv_table(text, opts)


def query_table_names(query):
    pattern = re.compile(r"\b(?:FROM|JOIN)\s+([^\s,;()]+)", re.IGNORECASE)
    return list(OrderedDict((m.group(1), None) for m in pattern.finditer(query)).keys())


def quote_ident(name):
    return '"' + name.replace('"', '""') + '"'


def rewrite_query(query, table_names):
    for name in sorted(table_names, key=len, reverse=True):
        query = re.sub(
            rf"(\b(?:FROM|JOIN)\s+){re.escape(name)}(?=\s|,|;|$)",
            lambda m, n=name: m.group(1) + quote_ident(n),
            query,
            flags=re.IGNORECASE,
        )
    return query


def create_table(conn, name, columns, rows, opts):
    if opts["rownum"]:
        columns = ["num"] + columns
        rows = [[str(i)] + row for i, row in enumerate(rows, 1)]
    col_sql = ", ".join(f"{quote_ident(c)} TEXT" for c in columns)
    conn.execute(f"CREATE TABLE {quote_ident(name)} ({col_sql})")
    if rows:
        marks = ", ".join("?" for _ in columns)
        conn.executemany(
            f"INSERT INTO {quote_ident(name)} VALUES ({marks})",
            [[None if v is None else str(v) for v in row] for row in rows],
        )


def run_query(opts):
    query = opts["query"]
    if not query:
        return [], []
    stdin_text = sys.stdin.read() if "-" in query or opts.get("table_file") == "-" else ""
    names = query_table_names(query)
    conn = sqlite3.connect(":memory:")
    for name in names:
        columns, rows = read_table(name, opts, stdin_text)
        create_table(conn, name, columns, rows, opts)
    sql = rewrite_query(query, names)
    cur = conn.execute(sql)
    columns = [d[0] for d in cur.description] if cur.description else []
    rows = cur.fetchall()
    return columns, rows


def format_value(value, opts):
    if value is None:
        return opts["null_out"]
    return str(value)


def output_csv(columns, rows, opts):
    out = io.StringIO()
    writer = csv.writer(
        out,
        delimiter=opts["output_delimiter"],
        quotechar=opts["quote"][:1] if opts["quote"] else '"',
        lineterminator="\n",
    )
    if opts["header_out"]:
        writer.writerow(columns)
    for row in rows:
        writer.writerow([format_value(v, opts) for v in row])
    return out.getvalue()


def output_ltsv(columns, rows, opts):
    lines = []
    for row in rows:
        parts = [f"{col}:{format_value(val, opts)}" for col, val in zip(columns, row)]
        lines.append("\t".join(parts))
    return "\n".join(lines) + ("\n" if lines else "")


def output_json(columns, rows, opts, lines=False):
    objs = [
        OrderedDict((col, format_value(val, opts)) for col, val in zip(columns, row))
        for row in rows
    ]
    if lines:
        return "".join(json.dumps(obj, separators=(",", ":")) + "\n" for obj in objs)
    return json.dumps(objs, indent=2) + "\n"


def output_markdown(columns, rows, opts):
    all_rows = [[format_value(v, opts) for v in row] for row in rows]
    widths = [len(c) for c in columns]
    for row in all_rows:
        for i, val in enumerate(row):
            widths[i] = max(widths[i], len(val))
    def cell(val, i):
        return " " + str(val).rjust(widths[i]) + " "
    lines = ["|" + "|".join(cell(c, i) for i, c in enumerate(columns)) + "|"]
    lines.append("|" + "|".join("-" * (widths[i] + 2) for i in range(len(columns))) + "|")
    for row in all_rows:
        lines.append("|" + "|".join(cell(v, i) for i, v in enumerate(row)) + "|")
    return "\n".join(lines) + "\n"


def display_widths(columns, rows, opts):
    rendered = [[format_value(v, opts) for v in row] for row in rows]
    widths = [len(c) for c in columns]
    for row in rendered:
        for i, val in enumerate(row):
            widths[i] = max(widths[i], len(val))
    return rendered, widths


def output_ascii_table(columns, rows, opts):
    rendered, widths = display_widths(columns, rows, opts)
    border = "+" + "+".join("-" * (w + 2) for w in widths) + "+"

    def align_cell(value, i, header=False):
        if not header and re.fullmatch(r"[-+]?(?:\d+(?:\.\d*)?|\.\d+)", str(value)):
            return str(value).rjust(widths[i])
        return str(value).ljust(widths[i])

    def row_line(values):
        return "|" + "|".join(" " + align_cell(v, i) + " " for i, v in enumerate(values)) + "|"

    lines = [border, "|" + "|".join(" " + str(c).ljust(widths[i]) + " " for i, c in enumerate(columns)) + "|", border]
    lines.extend(row_line(row) for row in rendered)
    lines.append(border)
    return "\n".join(lines) + "\n"


def output_vertical(columns, rows, opts):
    rendered, _ = display_widths(columns, rows, opts)
    name_width = max([len(c) for c in columns] + [0])
    lines = []
    for idx, row in enumerate(rendered, 1):
        lines.append(f"---[ {idx}]------------------------")
        for col, val in zip(columns, row):
            lines.append(f"  {col.rjust(name_width)} | {val}")
    return "\n".join(lines) + ("\n" if lines else "")


def output_tbln(columns, rows, opts):
    rendered = [[format_value(v, opts) for v in row] for row in rows]

    def line(values):
        return "| " + " | ".join(values) + " |"

    lines = ["; name: " + line(columns), "; type: " + line(["text"] * len(columns))]
    lines.extend(line(row) for row in rendered)
    return "\n".join(lines) + "\n"


def output_rows(columns, rows, opts):
    fmt = opts["output_format"]
    if fmt in ("csv", "raw"):
        return output_csv(columns, rows, opts)
    if fmt == "ltsv":
        return output_ltsv(columns, rows, opts)
    if fmt == "json":
        return output_json(columns, rows, opts)
    if fmt == "jsonl":
        return output_json(columns, rows, opts, lines=True)
    if fmt == "md" or fmt == "yaml":
        return output_markdown(columns, rows, opts)
    if fmt == "at":
        return output_ascii_table(columns, rows, opts)
    if fmt == "vf":
        return output_vertical(columns, rows, opts)
    if fmt == "tbln":
        return output_tbln(columns, rows, opts)
    return output_csv(columns, rows, opts)


def main(argv):
    try:
        opts = parse_args(argv)
        if opts.get("help"):
            sys.stdout.write(HELP)
            return 0
        if opts.get("version"):
            sys.stdout.write("trdsql version devel\n")
            return 0
        columns, rows = run_query(opts)
        output = output_rows(columns, rows, opts)
        if opts.get("out"):
            with open(opts["out"], "w", encoding="utf-8", newline="") as f:
                f.write(output)
        else:
            sys.stdout.write(output)
        return 0
    except Exception as exc:
        sys.stderr.write(f"trdsql: {exc}\n")
        return 1


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
