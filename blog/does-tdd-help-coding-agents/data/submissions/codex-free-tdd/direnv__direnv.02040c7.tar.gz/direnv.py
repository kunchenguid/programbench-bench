#!/usr/bin/env python3
import hashlib
import json
import os
import re
import shlex
import subprocess
import sys
from pathlib import Path


VERSION = "2.37.1"
SUPPORTED_EXPORTS = ["elvish", "fish", "gha", "murex", "tcsh", "systemd", "bash", "gzenv", "json", "vim", "zsh", "pwsh"]


def config_home():
    return Path(os.environ.get("XDG_CONFIG_HOME", str(Path.home() / ".config"))) / "direnv"


def data_home():
    return Path(os.environ.get("XDG_DATA_HOME", str(Path.home() / ".local" / "share"))) / "direnv"


def eprint(message):
    print(f"\033[31mdirenv: {message}\033[0m", file=sys.stderr)


def log(message):
    fmt = os.environ.get("DIRENV_LOG_FORMAT", "direnv: %s")
    print("\033[0m" + (fmt % message), file=sys.stderr)


def help_text():
    shells = ", ".join(SUPPORTED_EXPORTS)
    return f"""direnv v{VERSION}
Usage: direnv COMMAND [...ARGS]

Available commands
------------------
allow [PATH_TO_RC]:
  aliases: permit, grant
  Grants direnv permission to load the given .envrc or .env file.
block [PATH_TO_RC]:
  aliases: deny, disallow, revoke
  Revokes the authorization of a given .envrc or .env file.
edit [PATH_TO_RC]:
  Opens PATH_TO_RC or the current .envrc or .env into an $EDITOR and allow
  the file to be loaded afterwards.
exec DIR COMMAND [...ARGS]:
  Executes a command after loading the first .envrc or .env found in DIR
export SHELL:
  Loads an .envrc or .env and prints the diff in terms of exports.
  Supported SHELL values are: [{shells}]
fetchurl <url> [<integrity-hash>]:
  Fetches a given URL into direnv's CAS
help [SHOW_PRIVATE]:
  Shows this help
hook SHELL:
  Used to setup the shell hook
prune:
  Removes old allowed and required files
reload:
  Triggers an env reload
status [--json]:
  Prints some debug status information
stdlib:
  Displays the stdlib available in the .envrc execution context
version [VERSION_AT_LEAST]:
  prints the version or checks that direnv is older than VERSION_AT_LEAST.
log [--status | --error] <message>:
  Logs a given message
"""


def find_envrc(start=None):
    cur = Path(start or os.getcwd()).resolve()
    while True:
        rc = cur / ".envrc"
        if rc.exists():
            return rc
        if cur.parent == cur:
            return None
        cur = cur.parent


def rc_for_path(arg=None):
    if not arg:
        rc = find_envrc()
        if rc:
            return rc
        return Path.cwd() / ".envrc"
    p = Path(arg)
    if p.is_dir():
        return p / ".envrc"
    if p.name not in (".envrc", ".env"):
        candidate = p / ".envrc"
        if candidate.exists() or p.exists():
            return candidate
    return p


def allow_key(path):
    p = Path(path).resolve()
    content = p.read_bytes() if p.exists() else b""
    return hashlib.sha256(str(p).encode() + b"\0" + content).hexdigest()


def allow_file(path):
    p = Path(path).resolve()
    target = data_home() / "allow" / allow_key(p)
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text(str(p), encoding="utf-8")


def is_allowed(path):
    return (data_home() / "allow" / allow_key(path)).exists()


def shell_quote_bash(value):
    return "$'" + value.replace("\\", "\\\\").replace("'", "\\'").replace("\n", "\\n") + "'"


def stdlib_script():
    return r'''
has() { type "$1" >/dev/null 2>&1; }
expand_path() {
  local p="$1" base="${2:-$PWD}"
  case "$p" in /*) (cd "$(dirname "$p")" 2>/dev/null && printf "%s/%s\n" "$PWD" "$(basename "$p")");; *) (cd "$base" 2>/dev/null && cd "$(dirname "$p")" 2>/dev/null && printf "%s/%s\n" "$PWD" "$(basename "$p")");; esac
}
path_add() { local var="$1" p; p="$(expand_path "$2")"; eval "export $var=\"$p${!var:+:${!var}}\""; }
PATH_add() { path_add PATH "$1"; }
MANPATH_add() { path_add MANPATH "$1"; }
PATH_rm() { local out="" part pat keep; IFS=: read -ra parts <<< "$PATH"; for part in "${parts[@]}"; do keep=1; for pat in "$@"; do [[ "$part" == $pat ]] && keep=0; done; [[ $keep == 1 ]] && out="${out:+$out:}$part"; done; export PATH="$out"; }
dotenv() { set -a; source "${1:-.env}"; set +a; }
dotenv_if_exists() { [[ -f "${1:-.env}" ]] && dotenv "$@"; }
source_env() { local p="$1"; [[ -d "$p" ]] && p="$p/.envrc"; source "$p"; }
source_env_if_exists() { [[ -f "$1" ]] && source "$1"; }
find_up() { local f="$1" d="$PWD"; while :; do [[ -e "$d/$f" ]] && { printf "%s\n" "$d/$f"; return 0; }; [[ "$d" == / ]] && return 1; d="$(dirname "$d")"; done; }
source_up() { local p; p="$(find_up "${1:-.envrc}")" || return 1; source "$p"; }
source_up_if_exists() { local p; p="$(find_up "${1:-.envrc}")" || return 0; source "$p"; }
user_rel_path() { case "$1" in "$HOME"/*) printf "~/%s\n" "${1#$HOME/}";; "$HOME") printf "~\n";; *) printf "%s\n" "$1";; esac; }
direnv_layout_dir() { mkdir -p ".direnv"; printf "%s\n" "$PWD/.direnv"; }
layout() { case "$1" in node) PATH_add node_modules/.bin;; go) export GOPATH="$(direnv_layout_dir)/go"; PATH_add bin;; python|python3) export VIRTUAL_ENV="$(direnv_layout_dir)/python"; PATH_add "$VIRTUAL_ENV/bin";; *) :;; esac; }
load_prefix() { PATH_add "$1/bin"; path_add CPATH "$1/include"; path_add LD_LIBRARY_PATH "$1/lib"; path_add LIBRARY_PATH "$1/lib"; path_add PKG_CONFIG_PATH "$1/lib/pkgconfig"; MANPATH_add "$1/share/man"; }
env_vars_required() { local v ok=0; for v in "$@"; do [[ -z "${!v:-}" ]] && { echo "direnv: error $v is required" >&2; ok=1; }; done; return $ok; }
watch_file() { :; }
watch_dir() { :; }
'''


def evaluate_envrc(rc):
    restore_lines = []
    for key, value in os.environ.items():
        if key in ("PWD", "OLDPWD", "SHLVL", "_"):
            continue
        if re.fullmatch(r"[A-Za-z_][A-Za-z0-9_]*", key) and not key.startswith("BASH_FUNC_"):
            restore_lines.append(f"export {key}={shlex.quote(value)}")
    script = f"""
set -a
{stdlib_script()}
if [ -f {shlex.quote(str(config_home() / "direnvrc"))} ]; then source {shlex.quote(str(config_home() / "direnvrc"))}; fi
{chr(10).join(restore_lines)}
source {shlex.quote(str(rc))}
python3 - <<'PY'
import json, os
print(json.dumps(dict(os.environ), sort_keys=True))
PY
"""
    proc = subprocess.run(["/usr/bin/bash", "-lc", script], cwd=str(rc.parent), text=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE, env=os.environ.copy())
    if proc.returncode != 0:
        sys.stderr.write(proc.stderr)
        return None, proc.returncode
    lines = proc.stdout.splitlines()
    env_json = lines[-1] if lines else "{}"
    return json.loads(env_json), 0


def changed_env(new_env):
    old = os.environ
    ignore = {"_", "SHLVL", "PWD", "OLDPWD"}
    changes = {}
    for k, v in new_env.items():
        if k in ignore or k.startswith("BASH_FUNC_"):
            continue
        if old.get(k) != v:
            changes[k] = v
    for k in old:
        if k in ignore or k.startswith("BASH_FUNC_") or k.startswith("DIRENV_"):
            continue
        if k not in new_env:
            changes[k] = None
    return changes


def change_summary(changes):
    parts = []
    for key in sorted(changes):
        if changes[key] is None:
            parts.append("-" + key)
        elif key in os.environ:
            parts.append("~" + key)
        else:
            parts.append("+" + key)
    return " ".join(parts)


def emit_export(shell, changes, rc=None):
    if rc:
        changes = {"DIRENV_DIR": "-" + str(rc.parent), "DIRENV_FILE": str(rc), **changes}
    if shell in ("bash", "zsh"):
        for k in sorted(changes):
            if changes[k] is None:
                print(f"unset {k};", end="")
            else:
                print(f"export {k}={shell_quote_bash(changes[k])};", end="")
        if changes:
            print()
    elif shell == "json" or shell in ("elvish", "murex"):
        print(json.dumps(changes, sort_keys=True))
    elif shell == "fish":
        for k, v in sorted(changes.items()):
            if v is None:
                print(f"set -e -g {shlex.quote(k)};")
            else:
                print(f"set -x -g {shlex.quote(k)} {shlex.quote(v)};")
    elif shell == "tcsh":
        for k, v in sorted(changes.items()):
            if v is None:
                print(f"unsetenv {k};")
            else:
                print(f"setenv {k} {shlex.quote(v)};")
    elif shell == "pwsh":
        for k, v in sorted(changes.items()):
            if v is None:
                print(f"Remove-Item Env:{k} -ErrorAction SilentlyContinue")
            else:
                print(f"$env:{k} = {json.dumps(v)}")
    elif shell == "gha":
        for k, v in sorted(changes.items()):
            if v is not None:
                print(f"{k}={v}")
    elif shell in ("systemd", "gzenv", "vim"):
        for k, v in sorted(changes.items()):
            if v is not None:
                print(f"{k}={v}")
    else:
        eprint(f"unknown target shell '{shell}'")
        return 1
    return 0


def cmd_export(args):
    if not args:
        eprint("missing SHELL")
        return 1
    shell = args[0]
    if shell not in SUPPORTED_EXPORTS:
        eprint(f"unknown target shell '{shell}'")
        return 1
    rc = find_envrc()
    if not rc:
        return 0
    if not is_allowed(rc):
        emit_export(shell, {}, rc)
        eprint(f"error {rc} is blocked. Run `direnv allow` to approve its content")
        return 1
    new_env, code = evaluate_envrc(rc)
    if code:
        return code
    changes = changed_env(new_env)
    log(f"loading {rc}")
    if changes:
        log("export " + change_summary(changes))
    return emit_export(shell, changes, rc)


def hook(shell):
    exe = sys.argv[0]
    if shell == "bash":
        return f'''
_direnv_hook() {{
  local previous_exit_status=$?;
  vars="$("{exe}" export bash)";
  trap -- '' SIGINT;
  eval "$vars";
  trap - SIGINT;
  return $previous_exit_status;
}};
if [[ ";${{PROMPT_COMMAND[*]:-}};" != *";_direnv_hook;"* ]]; then
  if [[ "$(declare -p PROMPT_COMMAND 2>&1)" == "declare -a"* ]]; then
    PROMPT_COMMAND=(_direnv_hook "${{PROMPT_COMMAND[@]}}")
  else
    PROMPT_COMMAND="_direnv_hook${{PROMPT_COMMAND:+;$PROMPT_COMMAND}}"
  fi
fi
'''
    if shell == "zsh":
        return f'''
_direnv_hook() {{
  vars="$("{exe}" export zsh)"
  trap -- '' SIGINT
  eval "$vars"
  trap - SIGINT
}}
typeset -ag precmd_functions
if (( ! ${{precmd_functions[(I)_direnv_hook]}} )); then
  precmd_functions=(_direnv_hook $precmd_functions)
fi
typeset -ag chpwd_functions
if (( ! ${{chpwd_functions[(I)_direnv_hook]}} )); then
  chpwd_functions=(_direnv_hook $chpwd_functions)
fi
'''
    if shell == "fish":
        return f'''
    function __direnv_export_eval --on-event fish_prompt;
        "{exe}" export fish | source;
    end;
'''
    if shell == "tcsh":
        return f"alias precmd 'eval `{exe} export tcsh`'"
    if shell == "elvish":
        return f'## hook for direnv\nset @edit:before-readline = $@edit:before-readline {{ {exe} export elvish }}\n'
    if shell == "murex":
        return f'event: onPrompt direnv_hook=before {{\n\t"{exe}" export murex -> set exports\n}}'
    if shell == "pwsh":
        return f'$ExecutionContext.SessionState.InvokeCommand.LocationChangedAction = {{ /workspace/executable export pwsh }};\n'
    if shell == "gha":
        eprint("error Hook not implemented for GitHub Actions shell")
        return None
    if shell == "vim":
        eprint("error this feature is not supported. Install the direnv.vim plugin instead")
        return None
    if shell in ("json", "systemd"):
        eprint("error this feature is not supported")
        return None
    eprint(f"error unknown target shell '{shell}'")
    return None


def parse_semver(s):
    m = re.fullmatch(r"v?(\d+)\.(\d+)\.(\d+)", s)
    if not m:
        return None
    return tuple(int(x) for x in m.groups())


def cmd_exec(args):
    if len(args) < 2:
        eprint("error invalid arguments")
        return 1
    directory = Path(args[0]).resolve()
    rc = find_envrc(directory)
    env = os.environ.copy()
    if rc and is_allowed(rc):
        new_env, code = evaluate_envrc(rc)
        if code:
            return code
        for key, value in changed_env(new_env).items():
            if value is None:
                env.pop(key, None)
            else:
                env[key] = value
    proc = subprocess.run(args[1:], cwd=str(directory), env=env)
    return proc.returncode


def cmd_status(args):
    if args and args[0] == "--json":
        print(json.dumps({"config": str(config_home()), "state": "ok"}))
        return 0
    print(f"direnv exec path {Path(sys.argv[0]).resolve()}")
    print(f"DIRENV_CONFIG {config_home()}")
    print("bash_path /usr/bin/bash")
    print("disable_stdin false")
    print("warn_timeout 5s")
    rc = find_envrc()
    print(f"Found RC path {rc}" if rc else "No .envrc or .env loaded")
    print(f"Found watch: {rc}" if rc else "No .envrc or .env found")
    return 0


def main(argv):
    if not argv or argv[0] in ("--help", "-h", "help"):
        print(help_text(), end="")
        return 0
    cmd, args = argv[0], argv[1:]
    if cmd == "version":
        if not args:
            print(VERSION)
            return 0
        want = parse_semver(args[0])
        if not want:
            eprint(f"error v{args[0]} is not a valid semver version")
            return 1
        if parse_semver(VERSION) < want:
            eprint(f"error current version v{VERSION} is older than the desired version v{args[0]}")
            return 1
        return 0
    if cmd == "hook":
        if not args:
            eprint("error invalid arguments")
            return 1
        out = hook(args[0])
        if out is None:
            return 1
        print(out, end="")
        return 0
    if cmd in ("allow", "permit", "grant"):
        rc = rc_for_path(args[0] if args else None)
        if not rc.exists():
            eprint("error .envrc file not found")
            return 1
        allow_file(rc)
        return 0
    if cmd in ("block", "deny", "disallow", "revoke"):
        rc = rc_for_path(args[0] if args else None)
        key = data_home() / "allow" / allow_key(rc)
        if key.exists():
            key.unlink()
        return 0
    if cmd == "export":
        return cmd_export(args)
    if cmd == "exec":
        return cmd_exec(args)
    if cmd == "status":
        return cmd_status(args)
    if cmd == "stdlib":
        print(stdlib_script())
        return 0
    if cmd == "reload":
        print("export DIRENV_DIFF=$'';")
        return 0
    if cmd == "prune":
        return 0
    if cmd == "log":
        if len(args) >= 2 and args[0] == "--status":
            log(" ".join(args[1:]))
            return 0
        if len(args) >= 2 and args[0] == "--error":
            eprint(" ".join(args[1:]))
            return 0
        eprint("error invalid arguments")
        return 1
    if cmd == "fetchurl":
        eprint("error failed to fetch URL")
        return 1
    eprint(f'error command "{sys.argv[0]} {cmd}" not found')
    return 1


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
