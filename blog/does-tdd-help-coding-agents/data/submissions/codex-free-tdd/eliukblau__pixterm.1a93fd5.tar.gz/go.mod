module pixtermre

go 1.20
