package main

import (
	"bytes"
	"image"
	"image/color"
	"image/png"
	"os"
	"path/filepath"
	"strings"
	"testing"
)

func writePNG(t *testing.T, pixels [][]color.RGBA) string {
	t.Helper()
	h := len(pixels)
	w := len(pixels[0])
	img := image.NewNRGBA(image.Rect(0, 0, w, h))
	for y := 0; y < h; y++ {
		for x := 0; x < w; x++ {
			p := pixels[y][x]
			img.SetNRGBA(x, y, color.NRGBA{R: p.R, G: p.G, B: p.B, A: p.A})
		}
	}
	path := filepath.Join(t.TempDir(), "img.png")
	f, err := os.Create(path)
	if err != nil {
		t.Fatal(err)
	}
	defer f.Close()
	if err := png.Encode(f, img); err != nil {
		t.Fatal(err)
	}
	return path
}

func TestRunPrintsVersion(t *testing.T) {
	var out, errOut bytes.Buffer
	code := run([]string{"-version"}, &out, &errOut)
	if code != 0 {
		t.Fatalf("code=%d stderr=%q", code, errOut.String())
	}
	if got := out.String(); got != "1.3.2\n" {
		t.Fatalf("version output = %q", got)
	}
}

func TestRenderSolidRedPNGAtExplicitTerminalSize(t *testing.T) {
	path := writePNG(t, [][]color.RGBA{{{255, 0, 0, 255}}})
	var out, errOut bytes.Buffer
	code := run([]string{"-tc", "2", "-tr", "2", path}, &out, &errOut)
	if code != 0 {
		t.Fatalf("code=%d stderr=%q", code, errOut.String())
	}
	cell := "\x1b[48;2;255;0;0m\x1b[38;2;255;0;0m▄"
	want := cell + cell + "\x1b[0m\n" + cell + cell + "\x1b[0m\n"
	if out.String() != want {
		t.Fatalf("render mismatch\nwant %q\ngot  %q", want, out.String())
	}
}

func TestMatteCompositesTransparentPixels(t *testing.T) {
	path := writePNG(t, [][]color.RGBA{{{255, 0, 0, 128}}})
	var out, errOut bytes.Buffer
	code := run([]string{"-tc", "2", "-tr", "2", "-m", "00ff00", path}, &out, &errOut)
	if code != 0 {
		t.Fatalf("code=%d stderr=%q", code, errOut.String())
	}
	if !strings.Contains(out.String(), "\x1b[48;2;128;127;0m\x1b[38;2;128;127;0m▄") {
		t.Fatalf("matte composite missing from %q", out.String())
	}
}

func TestGoOutputWrapsEachRenderedLineInFmtPrint(t *testing.T) {
	path := writePNG(t, [][]color.RGBA{{{255, 0, 0, 255}}})
	var out, errOut bytes.Buffer
	code := run([]string{"-tc", "2", "-tr", "2", "-go", path}, &out, &errOut)
	if code != 0 {
		t.Fatalf("code=%d stderr=%q", code, errOut.String())
	}
	if !strings.HasPrefix(out.String(), "fmt.Print(\"\\033[48;2;255;0;0m") {
		t.Fatalf("unexpected go output prefix: %q", out.String())
	}
	if strings.Count(out.String(), "fmt.Print(") != 2 {
		t.Fatalf("expected one fmt.Print per terminal row: %q", out.String())
	}
}

func TestHelpEndsWithBlankLineLikeOriginal(t *testing.T) {
	var out, errOut bytes.Buffer
	code := run([]string{"-help"}, &out, &errOut)
	if code != 0 {
		t.Fatalf("code=%d stderr=%q", code, errOut.String())
	}
	if !strings.HasSuffix(out.String(), "prints this message :D LOL\n\n") {
		t.Fatalf("help suffix mismatch: %q", out.String()[len(out.String())-40:])
	}
}

func TestRedPixelDithersToBrightestGlyphs(t *testing.T) {
	path := writePNG(t, [][]color.RGBA{{{255, 0, 0, 255}}})
	for _, tc := range []struct {
		mode  string
		glyph string
	}{
		{"1", "█"},
		{"2", "#"},
	} {
		var out, errOut bytes.Buffer
		code := run([]string{"-tc", "2", "-tr", "2", "-d", tc.mode, path}, &out, &errOut)
		if code != 0 {
			t.Fatalf("mode %s code=%d stderr=%q", tc.mode, code, errOut.String())
		}
		if strings.Count(out.String(), tc.glyph) != 4 {
			t.Fatalf("mode %s expected four %q glyphs in %q", tc.mode, tc.glyph, out.String())
		}
	}
}

func TestCreditsEndsWithBlankLineLikeOriginal(t *testing.T) {
	var out, errOut bytes.Buffer
	code := run([]string{"-credits"}, &out, &errOut)
	if code != 0 {
		t.Fatalf("code=%d stderr=%q", code, errOut.String())
	}
	if !strings.HasSuffix(out.String(), "+ Moral support.\n\n") {
		t.Fatalf("credits suffix mismatch: %q", out.String()[len(out.String())-40:])
	}
}
