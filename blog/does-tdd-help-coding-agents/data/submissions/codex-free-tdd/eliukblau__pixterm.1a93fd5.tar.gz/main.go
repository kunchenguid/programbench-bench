package main

import (
	"flag"
	"fmt"
	"image"
	"image/color"
	_ "image/gif"
	_ "image/jpeg"
	_ "image/png"
	"io"
	"log"
	"math"
	"net/http"
	"os"
	"strconv"
	"strings"
)

const version = "1.3.2"

const banner = `   ___  _____  ____
  / _ \/  _/ |/_/ /____ ______ _      Made with love by Eliuk Blau
 / ___// /_>  </ __/ -_) __/  ' \ https://github.com/eliukblau/pixterm
/_/  /___/_/|_|\__/\__/_/ /_/_/_/                1.3.2
`

const helpText = banner + `
USAGE:

  executable [options] image/url

  Supported image formats: JPEG, PNG, GIF, BMP, TIFF, WebP.
  Supported URL protocols: HTTP, HTTPS.

OPTIONS:

  -credits
    	show some love to contributors <3
  -d mode
    	dithering mode:
    	   0 - no dithering (default)
    	   1 - with blocks
    	   2 - with chars
  -go
    	output Go code to 'fmt.Print()' the image
  -m color
    	matte color for transparency or background
    	(optional, hex format, default: 000000)
  -nobg
    	disable background color
    	(optional, only in dithering mode, ignores matte color)
  -s method
    	scale method:
    	   0 - resize (default)
    	   1 - fill
    	   2 - fit
  -tc columns
    	terminal columns (optional, >=2; when piping, default: 80)
  -tr rows
    	terminal rows (optional, >=2; when piping, default: 24)
  -version
    	show PIXterm version
  -help
	prints this message :D LOL

`

const creditsText = banner + `
CONTRIBUTORS:

  > @disq - https://github.com/disq
      + Original code for image transparency support.

  > @timob - https://github.com/timob
      + Fix for ANSIpixel type: use 8bit color component for output.

  > @HongjiangHuang - https://github.com/HongjiangHuang
      + Original code for image download support.

  > @brutestack - https://github.com/brutestack
      + Color support for Windows (Command Prompt & PowerShell).
      + Original code for disable background color in dithering mode.
      + Original code for output Go code to 'fmt.Print()' the image.

  > @diamondburned - https://github.com/diamondburned
      + NewFromImage() & NewScaledFromImage() for ANSImage API.

  > @MichaelMure - https://github.com/MichaelMure
      + More conventional 'go.mod' file at repository.

  > @Calinou - https://github.com/Calinou
      + Use HTTPS URLs everywhere.
      + Other awesome contributions.

  > @danirod - https://github.com/danirod
  > @Xpktro - https://github.com/Xpktro
      + Moral support.

`

type rgb struct {
	r, g, b uint8
}

type options struct {
	dither int
	goOut  bool
	matte  rgb
	noBg   bool
	scale  int
	cols   int
	rows   int
}

func main() {
	os.Exit(run(os.Args[1:], os.Stdout, os.Stderr))
}

func run(args []string, stdout, stderr io.Writer) int {
	fs := flag.NewFlagSet("executable", flag.ContinueOnError)
	fs.SetOutput(io.Discard)
	var showVersion, showCredits, showHelp bool
	var matte string
	opt := options{cols: 80, rows: 24}
	fs.BoolVar(&showVersion, "version", false, "")
	fs.BoolVar(&showCredits, "credits", false, "")
	fs.BoolVar(&showHelp, "help", false, "")
	fs.IntVar(&opt.dither, "d", 0, "")
	fs.BoolVar(&opt.goOut, "go", false, "")
	fs.StringVar(&matte, "m", "000000", "")
	fs.BoolVar(&opt.noBg, "nobg", false, "")
	fs.IntVar(&opt.scale, "s", 0, "")
	fs.IntVar(&opt.cols, "tc", 80, "")
	fs.IntVar(&opt.rows, "tr", 24, "")
	if err := fs.Parse(args); err != nil {
		fmt.Fprint(stdout, helpText)
		return 2
	}
	if showVersion {
		fmt.Fprintln(stdout, version)
		return 0
	}
	if showCredits {
		fmt.Fprint(stdout, creditsText)
		return 0
	}
	if showHelp || fs.NArg() != 1 {
		fmt.Fprint(stdout, helpText)
		if showHelp || fs.NArg() == 0 {
			return 0
		}
		return 2
	}
	if opt.dither < 0 || opt.dither > 2 || opt.scale < 0 || opt.scale > 2 || opt.cols < 2 || opt.rows < 2 {
		fmt.Fprint(stdout, helpText)
		return 2
	}
	c, err := parseHexColor(matte)
	if err != nil {
		log.New(stderr, "[PIXTERM ERROR] ", log.LstdFlags).Printf("matte color : %s is not a hex-color", matte)
		return 2
	}
	opt.matte = c
	img, err := openImage(fs.Arg(0))
	if err != nil {
		fmt.Fprint(stdout, banner+"\n")
		log.New(stderr, "[PIXTERM ERROR] ", log.LstdFlags).Print(err)
		return 1
	}
	rendered := render(img, opt)
	if opt.goOut {
		for _, line := range strings.SplitAfter(rendered, "\n") {
			if line == "" {
				continue
			}
			fmt.Fprintf(stdout, "fmt.Print(\"%s\")\n", goEscape(line))
		}
		return 0
	}
	fmt.Fprint(stdout, rendered)
	return 0
}

func parseHexColor(s string) (rgb, error) {
	if strings.HasPrefix(s, "#") {
		s = s[1:]
	}
	if len(s) == 3 {
		s = string([]byte{s[0], s[0], s[1], s[1], s[2], s[2]})
	}
	if len(s) != 6 {
		return rgb{}, fmt.Errorf("bad color")
	}
	v, err := strconv.ParseUint(s, 16, 32)
	if err != nil {
		return rgb{}, err
	}
	return rgb{uint8(v >> 16), uint8(v >> 8), uint8(v)}, nil
}

func openImage(path string) (image.Image, error) {
	var r io.ReadCloser
	if strings.HasPrefix(path, "http://") || strings.HasPrefix(path, "https://") {
		resp, err := http.Get(path)
		if err != nil {
			return nil, err
		}
		r = resp.Body
	} else {
		f, err := os.Open(path)
		if err != nil {
			return nil, err
		}
		r = f
	}
	defer r.Close()
	img, _, err := image.Decode(r)
	return img, err
}

func render(img image.Image, opt options) string {
	dstW, dstH, offX, offY := targetGeometry(img.Bounds().Dx(), img.Bounds().Dy(), opt)
	var b strings.Builder
	for row := 0; row < opt.rows; row++ {
		for col := 0; col < opt.cols; col++ {
			top := opt.matte
			bottom := opt.matte
			if col >= offX && col < offX+dstW {
				y0 := row*2 - offY
				y1 := y0 + 1
				if y0 >= 0 && y0 < dstH {
					top = sample(img, col-offX, y0, dstW, dstH, opt.matte)
				}
				if y1 >= 0 && y1 < dstH {
					bottom = sample(img, col-offX, y1, dstW, dstH, opt.matte)
				}
			}
			if opt.dither == 0 {
				fmt.Fprintf(&b, "\x1b[48;2;%d;%d;%dm\x1b[38;2;%d;%d;%dm▄", top.r, top.g, top.b, bottom.r, bottom.g, bottom.b)
			} else {
				bg := opt.matte
				ch := shadeChar(bottom, opt.dither)
				if opt.noBg {
					fmt.Fprintf(&b, "\x1b[38;2;%d;%d;%dm%s", bottom.r, bottom.g, bottom.b, ch)
				} else {
					fmt.Fprintf(&b, "\x1b[48;2;%d;%d;%dm\x1b[38;2;%d;%d;%dm%s", bg.r, bg.g, bg.b, bottom.r, bottom.g, bottom.b, ch)
				}
			}
		}
		b.WriteString("\x1b[0m\n")
	}
	return b.String()
}

func targetGeometry(srcW, srcH int, opt options) (w, h, offX, offY int) {
	boxW, boxH := opt.cols, opt.rows*2
	if opt.scale == 0 {
		return boxW, boxH, 0, 0
	}
	rx, ry := float64(boxW)/float64(srcW), float64(boxH)/float64(srcH)
	r := rx
	if opt.scale == 2 {
		r = math.Min(rx, ry)
	} else {
		r = math.Max(rx, ry)
	}
	w = max(1, int(math.Round(float64(srcW)*r)))
	h = max(1, int(math.Round(float64(srcH)*r)))
	return w, h, (boxW - w) / 2, (boxH - h) / 2
}

func sample(img image.Image, x, y, dstW, dstH int, matte rgb) rgb {
	b := img.Bounds()
	sx := b.Min.X + min(b.Dx()-1, int(float64(x)*float64(b.Dx())/float64(dstW)))
	sy := b.Min.Y + min(b.Dy()-1, int(float64(y)*float64(b.Dy())/float64(dstH)))
	n := color.NRGBAModel.Convert(img.At(sx, sy)).(color.NRGBA)
	a := int(n.A)
	return rgb{
		uint8((int(n.R)*a + int(matte.r)*(255-a)) / 255),
		uint8((int(n.G)*a + int(matte.g)*(255-a)) / 255),
		uint8((int(n.B)*a + int(matte.b)*(255-a)) / 255),
	}
}

func shadeChar(c rgb, mode int) string {
	intensity := max(int(c.r), max(int(c.g), int(c.b)))
	if mode == 1 {
		switch {
		case intensity > 191:
			return "█"
		case intensity > 127:
			return "▓"
		case intensity > 63:
			return "▒"
		default:
			return "░"
		}
	}
	chars := []string{" ", ".", ":", "-", "=", "+", "*", "#"}
	idx := intensity * (len(chars) - 1) / 255
	return chars[idx]
}

func goEscape(s string) string {
	s = strings.ReplaceAll(s, "\\", "\\\\")
	s = strings.ReplaceAll(s, "\x1b", "\\033")
	s = strings.ReplaceAll(s, "\n", "\\n")
	s = strings.ReplaceAll(s, "\"", "\\\"")
	return s
}

func min(a, b int) int {
	if a < b {
		return a
	}
	return b
}

func max(a, b int) int {
	if a > b {
		return a
	}
	return b
}
