#!/usr/bin/env python3
import os
import re
import shlex
import sys


VERSION = "0.68.0 (5676da4a)"

HELP = """fzf is an interactive filter program for any kind of list.

It implements a "fuzzy" matching algorithm, so you can quickly type in patterns
with omitted characters and still get the results you want.

Project URL: https://github.com/junegunn/fzf
Author: Junegunn Choi <junegunn.c@gmail.com>

* See man page for more information: fzf --man

Usage: fzf [options]

  SEARCH
    -e, --exact              Enable exact-match
    +x, --no-extended        Disable extended-search mode
    -i, --ignore-case        Case-insensitive match
    +i, --no-ignore-case     Case-sensitive match
        --smart-case         Smart-case match (default)
    --scheme=SCHEME          Scoring scheme [default|path|history]
    -n, --nth=N[,..]         Comma-separated list of field index expressions
    --with-nth=N[,..]        Transform the presentation of each line
    --accept-nth=N[,..]      Define which fields to print on accept
    -d, --delimiter=STR      Field delimiter regex (default: AWK-style)
    +s, --no-sort            Do not sort the result

  INPUT/OUTPUT
    --read0                  Read input delimited by ASCII NUL characters
    --print0                 Print output delimited by ASCII NUL characters

  SCRIPTING
    -q, --query=STR          Start the finder with the given query
    -1, --select-1           Automatically select the only match
    -0, --exit-0             Exit immediately when there's no match
    -f, --filter=STR         Print matches for the initial query and exit
    --print-query            Print query as the first line
    --expect=KEYS            Comma-separated list of keys to complete fzf

  HELP
    --version                Display version information and exit
    --help                   Show this message
    --man                    Show man page
"""


class Opts:
    def __init__(self):
        self.filter = None
        self.query = ""
        self.case = "smart"
        self.exact = False
        self.extended = True
        self.sort = True
        self.read0 = False
        self.print0 = False
        self.print_query = False
        self.delimiter = None
        self.nth = None
        self.with_nth = None
        self.accept_nth = None
        self.tail = None
        self.select_1 = False


def shell_words(value):
    if not value:
        return []
    try:
        return shlex.split(value)
    except ValueError:
        return value.split()


def with_default_opts(argv):
    merged = []
    path = os.environ.get("FZF_DEFAULT_OPTS_FILE")
    if path:
        try:
            with open(os.path.expanduser(path), "r", encoding="utf-8") as f:
                merged.extend(shell_words(f.read()))
        except OSError as e:
            sys.stderr.write(f"{e}\n")
            sys.exit(2)
    merged.extend(shell_words(os.environ.get("FZF_DEFAULT_OPTS", "")))
    merged.extend(argv)
    return merged


def parse(argv):
    opts = Opts()
    args = with_default_opts(argv)
    i = 0
    while i < len(args):
        arg = args[i]
        val = None
        if "=" in arg and arg.startswith("--"):
            arg, val = arg.split("=", 1)
        def need():
            nonlocal i, val
            if val is not None:
                return val
            i += 1
            if i >= len(args):
                sys.stderr.write("query string required\n" if arg == "--filter" else f"{arg}: option requires an argument\n")
                sys.exit(2)
            return args[i]
        if arg in ("--help", "-h"):
            print(HELP, end="")
            sys.exit(0)
        if arg == "--version":
            print(VERSION)
            sys.exit(0)
        if arg == "--man":
            print("fzf(1)                         fzf manual                         fzf(1)")
            print("\nNAME\n       fzf - a command-line fuzzy finder\n")
            sys.exit(0)
        if arg in ("--bash", "--zsh", "--fish"):
            name = arg[2:]
            print(f"### key-bindings.{name} ###")
            print("#     ____      ____")
            print("#    / __/___  / __/")
            print("#   / /_/_  / / /_")
            print("#  / __/ / /_/ __/")
            sys.exit(0)
        if arg in ("-f", "--filter"):
            opts.filter = need()
            opts.query = opts.filter
        elif arg.startswith("--filter="):
            opts.filter = arg.split("=", 1)[1]
            opts.query = opts.filter
        elif arg in ("-q", "--query"):
            opts.query = need()
        elif arg == "--query":
            opts.query = need()
        elif arg == "-i" or arg == "--ignore-case":
            opts.case = "ignore"
        elif arg == "+i" or arg == "--no-ignore-case":
            opts.case = "respect"
        elif arg == "--smart-case":
            opts.case = "smart"
        elif arg in ("-e", "--exact"):
            opts.exact = True
        elif arg in ("+x", "--no-extended"):
            opts.extended = False
        elif arg in ("+s", "--no-sort"):
            opts.sort = False
        elif arg == "--read0":
            opts.read0 = True
        elif arg == "--print0":
            opts.print0 = True
        elif arg == "--print-query":
            opts.print_query = True
        elif arg in ("-d", "--delimiter"):
            opts.delimiter = need()
        elif arg in ("-n", "--nth"):
            opts.nth = need()
        elif arg == "--with-nth":
            opts.with_nth = need()
        elif arg == "--accept-nth":
            opts.accept_nth = need()
        elif arg == "--tail":
            try:
                opts.tail = int(need())
            except ValueError:
                sys.stderr.write("invalid number\n")
                sys.exit(2)
        elif arg == "--scheme":
            scheme = need()
            if scheme not in ("default", "path", "history"):
                sys.stderr.write(f"invalid scoring scheme: {scheme} (expected: default|path|history)\n")
                sys.exit(2)
        elif arg in ("--expect", "--bind", "--preview", "--preview-window", "--height", "--layout",
                     "--color", "--style", "--border", "--prompt", "--header", "--header-lines",
                     "--history", "--history-size", "--tmux", "--walker", "--walker-root",
                     "--walker-skip", "--tiebreak", "--algo", "--nth", "--with-nth",
                     "--accept-nth", "--delimiter", "--border-label", "--border-label-pos"):
            if val is None and arg not in ("--border", "--tmux"):
                need()
        elif arg in ("-1", "--select-1"):
            opts.select_1 = True
        elif arg in ("-0", "--exit-0", "-m", "--multi", "--ansi", "--sync",
                     "--no-color", "--no-bold", "--disabled", "--literal", "--tac"):
            pass
        elif arg.startswith("--scheme="):
            scheme = arg.split("=", 1)[1]
            if scheme not in ("default", "path", "history"):
                sys.stderr.write(f"invalid scoring scheme: {scheme} (expected: default|path|history)\n")
                sys.exit(2)
        elif arg.startswith("--"):
            sys.stderr.write(f"unknown option: {arg}\n")
            sys.exit(2)
        i += 1
    return opts


def field_parts(line, delimiter):
    if delimiter is None:
        return re.findall(r"\S+", line)
    if delimiter == "":
        return [line]
    return re.split(delimiter, line)


def select_fields(line, expr, delimiter):
    fields = field_parts(line, delimiter)
    out = []
    for part in expr.split(","):
        part = part.strip()
        if not part:
            continue
        if ".." in part:
            a, b = part.split("..", 1)
            start = int(a) if a else 1
            end = int(b) if b else len(fields)
            if start < 0:
                start = len(fields) + start + 1
            if end < 0:
                end = len(fields) + end + 1
            out.extend(fields[max(0, start - 1):max(0, end)])
        else:
            n = int(part)
            if n < 0:
                n = len(fields) + n + 1
            if 1 <= n <= len(fields):
                out.append(fields[n - 1])
    return " ".join(out)


def render_fields(line, expr, delimiter, index):
    if "{" not in expr:
        return select_fields(line, expr, delimiter)

    def repl(match):
        inner = match.group(1)
        if inner == "n":
            return str(index)
        return select_fields(line, inner, delimiter)

    return re.sub(r"\{([^{}]+)\}", repl, expr)


def normalize(s, ignore):
    return s.lower() if ignore else s


def fuzzy_positions(needle, hay):
    positions = []
    start = 0
    for ch in needle:
        found = hay.find(ch, start)
        if found < 0:
            return None
        positions.append(found)
        start = found + 1
    return positions


def token_match(token, text, opts, ignore):
    inverse = token.startswith("!")
    if inverse:
        token = token[1:]
    quoted = token.startswith("'")
    if quoted:
        token = token[1:]
    prefix = token.startswith("^")
    suffix = token.endswith("$") and len(token) > 0
    if prefix:
        token = token[1:]
    if suffix:
        token = token[:-1]
    t = normalize(token, ignore)
    h = normalize(text, ignore)
    if t == "":
        ok, score = True, (0, 0, len(text))
    elif prefix:
        ok = h.startswith(t)
        score = (0, 0, len(text))
    elif suffix:
        ok = h.endswith(t)
        score = (0, max(0, len(text) - len(token)), len(text))
    elif opts.exact or quoted:
        pos = h.find(t)
        ok = pos >= 0
        score = (0, pos if ok else 999999, len(text))
    else:
        pos = fuzzy_positions(t, h)
        ok = pos is not None
        if ok:
            span = pos[-1] - pos[0] + 1
            contiguous = 0 if span == len(t) else 1
            if len(t) == 1:
                prefix = 0 if pos[0] == 0 else 1
                score = (prefix, len(text))
            else:
                boundary = 0 if pos[0] == 0 or text[pos[0] - 1] in "/ _-." else 1
                end_boundary = 0 if text[pos[-1] - 1] in " _-." else 1 if pos[-1] > 0 else 0
                score = (contiguous, boundary + end_boundary, span, len(text), pos[0])
        else:
            score = (999999, 999999, 999999, 999999, len(text))
    if inverse:
        return (not ok), ("inverse",)
    return ok, score


def matches(query, text, opts):
    ignore = opts.case == "ignore" or (opts.case == "smart" and not any(c.isupper() for c in query))
    if not opts.extended:
        ok, score = token_match(query, text, opts, ignore)
        return ok, score
    scores = []
    for token in query.split():
        ok, score = token_match(token, text, opts, ignore)
        if not ok:
            return False, score
        scores.append(score)
    if scores and all(score == ("inverse",) for score in scores):
        return True, ("inverse",)
    return True, tuple(scores)


def read_items(opts):
    data = sys.stdin.buffer.read()
    sep = b"\0" if opts.read0 else b"\n"
    raw = data.split(sep)
    if raw and raw[-1] == b"":
        raw.pop()
    if opts.tail is not None:
        raw = raw[-opts.tail:]
    return [x.decode("utf-8", "surrogateescape") for x in raw]


def filter_mode(opts):
    items = read_items(opts)
    selected = []
    for idx, line in enumerate(items):
        if opts.nth:
            search_text = select_fields(line, opts.nth, opts.delimiter)
        elif opts.with_nth:
            search_text = render_fields(line, opts.with_nth, opts.delimiter, idx)
        else:
            search_text = line
        ok, score = matches(opts.query, search_text, opts)
        if ok:
            selected.append((idx, score, line))
    if opts.sort:
        def sort_key(row):
            idx, score, line = row
            if score == ("inverse",):
                return (0, idx)
            return (0, score, len(line), idx)
        selected.sort(key=sort_key)
    sep = "\0" if opts.print0 else "\n"
    out = []
    if opts.print_query:
        out.append(opts.query)
    for idx, _, line in selected:
        out.append(render_fields(line, opts.accept_nth, opts.delimiter, idx) if opts.accept_nth else line)
    if out:
        sys.stdout.buffer.write((sep.join(out) + sep).encode("utf-8", "surrogateescape"))
    return 0 if selected else 1


def main(argv):
    opts = parse(argv)
    if opts.filter is not None:
        return filter_mode(opts)
    if opts.select_1:
        items = read_items(opts)
        if len(items) == 1:
            sep = "\0" if opts.print0 else "\n"
            sys.stdout.buffer.write((items[0] + sep).encode("utf-8", "surrogateescape"))
            return 0
    sys.stderr.write("inappropriate ioctl for device\n")
    return 2


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
