#!/usr/bin/env python3
import os
import subprocess
import unittest


ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
BIN = os.path.join(ROOT, "executable")


def run(args, data=b""):
    proc = subprocess.run([BIN] + args, input=data, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    return proc.returncode, proc.stdout, proc.stderr


LINES = b"alpha\nAlphabet\nbeta\ngamma\nfoo/bar.txt\nbar/foo.txt\nfoo baz\n"


class FzfCliTests(unittest.TestCase):
    def test_filter_smart_case_and_exit_codes(self):
        self.assertEqual(run(["--filter", "a"], LINES)[:2], (0, b"alpha\nAlphabet\nbeta\ngamma\nfoo baz\nfoo/bar.txt\nbar/foo.txt\n"))
        self.assertEqual(run(["--filter", "A"], LINES)[:2], (0, b"Alphabet\n"))
        self.assertEqual(run(["-i", "--filter", "A"], LINES)[:2], (0, b"alpha\nAlphabet\nbeta\ngamma\nfoo baz\nfoo/bar.txt\nbar/foo.txt\n"))
        self.assertEqual(run(["--filter", "zz"], LINES)[0], 1)

    def test_extended_search_tokens(self):
        self.assertEqual(run(["--filter", "fb"], LINES)[:2], (0, b"foo baz\nfoo/bar.txt\n"))
        self.assertEqual(run(["--filter", "ft"], LINES)[:2], (0, b"bar/foo.txt\nfoo/bar.txt\n"))
        self.assertEqual(run(["-e", "--filter", "fb"], LINES)[:2], (1, b""))
        self.assertEqual(run(["--filter", "foo bar"], LINES)[:2], (0, b"foo/bar.txt\nbar/foo.txt\n"))
        self.assertEqual(run(["--filter", "^foo"], LINES)[:2], (0, b"foo baz\nfoo/bar.txt\n"))
        self.assertEqual(run(["--filter", "!foo"], LINES)[:2], (0, b"alpha\nAlphabet\nbeta\ngamma\n"))

    def test_no_sort_query_and_nul_io(self):
        self.assertEqual(run(["--no-sort", "--filter", "a"], LINES)[:2], (0, b"alpha\nAlphabet\nbeta\ngamma\nfoo/bar.txt\nbar/foo.txt\nfoo baz\n"))
        self.assertEqual(run(["--print-query", "--filter", "a"], b"alpha\n")[1], b"a\nalpha\n")
        self.assertEqual(run(["--read0", "--print0", "--filter", "a"], b"alpha\0beta\0gamma\0")[:2], (0, b"alpha\0beta\0gamma\0"))

    def test_accept_nth_and_delimiter(self):
        data = b"1 apple red\n2 banana yellow\n3 apricot orange\n10 apple green\n"
        self.assertEqual(run(["--filter", "apple", "--accept-nth", "2"], data)[:2], (0, b"apple\napple\n"))
        self.assertEqual(run(["--filter", "a", "-d", " ", "-n", "2..3"], data)[:2], (0, b"1 apple red\n10 apple green\n3 apricot orange\n2 banana yellow\n"))
        self.assertEqual(run(["--filter", "1", "--with-nth", "2"], data)[:2], (1, b""))
        self.assertEqual(run(["--filter", "apple", "--accept-nth", "{n}:{1}:{2}:{3}:{2..3}"], data)[:2], (0, b"0:1:apple:red:apple red\n3:10:apple:green:apple green\n"))

    def test_status_and_diagnostics(self):
        code, out, err = run(["--version"], b"")
        self.assertEqual((code, out, err), (0, b"0.68.0 (5676da4a)\n", b""))
        self.assertEqual(run(["--select-1"], b"only\n")[:2], (0, b"only\n"))
        self.assertEqual(run(["--unknown"], b"")[0], 2)
        self.assertIn(b"unknown option: --unknown", run(["--unknown"], b"")[2])
        self.assertEqual(run([], b"a\n")[0], 2)
        self.assertIn(b"inappropriate ioctl for device", run([], b"a\n")[2])


if __name__ == "__main__":
    unittest.main()
