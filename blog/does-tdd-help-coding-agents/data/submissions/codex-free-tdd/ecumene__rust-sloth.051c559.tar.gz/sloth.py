#!/usr/bin/env python3
import math
import os
import re
import sys


VERSION = "Sloth 0.1"
BG = "\033[48;2;25;25;25m"
RESET = "\033[49m\033[39m"
PALETTE = {
    "Blue": (31, 158, 163),
    "Green": (36, 163, 36),
    "Purple": (163, 21, 155),
    "ReallyBlue": (27, 30, 163),
    "Red": (163, 26, 23),
    "Yellow": (163, 160, 30),
}


def main(argv):
    if not argv:
        missing_input()
        return 1
    if argv[0] in ("--help", "-h"):
        print_help()
        return 0
    if argv[0] in ("--version", "-V"):
        print(VERSION)
        return 0
    if argv[0] == "help":
        print_help()
        return 0

    try:
        opts, inputs, subcmd, rest = parse_global(argv)
        if not inputs:
            missing_input()
            return 1
        if subcmd == "image":
            return image_command(inputs, rest, opts)
        return terminal_command(inputs, opts)
    except CliError as exc:
        sys.stderr.write(str(exc))
        return 1
    except PanicError as exc:
        sys.stderr.write(str(exc))
        return 101
    except Exception as exc:
        sys.stderr.write(f"error: {exc}\n")
        return 1


class CliError(Exception):
    pass


class PanicError(Exception):
    pass


def print_help():
    sys.stdout.write("""Sloth 0.1
Mitchell Hynes. <mshynes@mun.ca>
A toy for rendering 3D objects in the command line

USAGE:
    executable [FLAGS] [OPTIONS] <input filename(s)>... [SUBCOMMAND]

FLAGS:
    -h, --help       Prints help information
    -b               Flags the rasterizer to render without color
    -V, --version    Prints version information

OPTIONS:
    -x, --yaw <x>      Sets the object's static X rotation (in radians)
    -y, --pitch <y>    Sets the object's static Y rotation (in radians)
    -z, --roll <z>     Sets the object's static Z rotation (in radians)

ARGS:
    <input filename(s)>...    Sets the input file to render

SUBCOMMANDS:
    help     Prints this message or the help of the given subcommand(s)
    image    Generates a colorless terminal output as lines of text
""")


def print_image_help():
    sys.stdout.write("""executable-image 
Mitchell Hynes <mitchell.hynes@ecumene.xyz>
Generates a colorless terminal output as lines of text

USAGE:
    executable <input filename(s)>... image [FLAGS] [OPTIONS] -w <width>

FLAGS:
        --help       Prints help information
    -b               Flags the rasterizer to render without color
    -V, --version    Prints version information

OPTIONS:
    -j, --webify <frame count>    Generates a portable JS based render of your object for the web
    -h <height>                   Sets the height of the image to generate
    -w <width>                    Sets the width of the image to generate
    -x, --yaw <x>                 Sets the object's static X rotation (in radians)
    -y, --pitch <y>               Sets the object's static Y rotation (in radians)
    -z, --roll <z>                Sets the object's static Z rotation (in radians)
""")


def missing_input():
    sys.stderr.write("""error: The following required arguments were not provided:
    <input filename(s)>...

USAGE:
    executable [FLAGS] [OPTIONS] <input filename(s)>... [SUBCOMMAND]

For more information try --help
""")


def parse_global(argv):
    opts = {"b": False, "x": 0.0, "y": 0.0, "z": 0.0}
    inputs = []
    i = 0
    while i < len(argv):
        arg = argv[i]
        if arg == "image":
            return opts, split_inputs(inputs), "image", argv[i + 1 :]
        if arg == "help":
            print_help()
            raise SystemExit(0)
        if arg == "-b":
            opts["b"] = True
        elif arg in ("-x", "--yaw", "-y", "--pitch", "-z", "--roll"):
            i += 1
            if i >= len(argv):
                raise CliError(f"error: The argument '{arg}' requires a value but none was supplied\n")
            key = {"-x": "x", "--yaw": "x", "-y": "y", "--pitch": "y", "-z": "z", "--roll": "z"}[arg]
            opts[key] = float(argv[i])
        elif arg in ("--help", "-h"):
            print_help()
            raise SystemExit(0)
        elif arg in ("--version", "-V"):
            print(VERSION)
            raise SystemExit(0)
        else:
            inputs.append(arg)
        i += 1
    return opts, split_inputs(inputs), None, []


def split_inputs(items):
    result = []
    for item in items:
        result.extend(part for part in item.split() if part)
    return result


def image_command(inputs, argv, global_opts):
    if argv and argv[0] == "--help":
        print_image_help()
        return 0
    if argv and argv[0] in ("--version", "-V"):
        print(VERSION)
        return 0
    opts = dict(global_opts)
    width = None
    height = None
    webify = None
    i = 0
    while i < len(argv):
        arg = argv[i]
        if arg == "-b":
            opts["b"] = True
        elif arg in ("-w",):
            i += 1
            if i >= len(argv):
                raise CliError("error: The argument '-w <width>' requires a value but none was supplied\n")
            width = int(argv[i])
        elif arg == "-h":
            i += 1
            if i >= len(argv):
                raise CliError("error: The argument '-h <height>' requires a value but none was supplied\n")
            height = int(argv[i])
        elif arg in ("-j", "--webify"):
            i += 1
            if i >= len(argv):
                raise CliError("error: The argument '-j <frame count>' requires a value but none was supplied\n")
            webify = int(argv[i])
        elif arg in ("-x", "--yaw", "-y", "--pitch", "-z", "--roll"):
            i += 1
            if i >= len(argv):
                raise CliError(f"error: The argument '{arg}' requires a value but none was supplied\n")
            key = {"-x": "x", "--yaw": "x", "-y": "y", "--pitch": "y", "-z": "z", "--roll": "z"}[arg]
            opts[key] = float(argv[i])
        elif arg == "--help":
            print_image_help()
            return 0
        else:
            raise CliError(f"error: Found argument '{arg}' which wasn't expected\n")
        i += 1
    if width is None:
        sys.stderr.write("""error: The following required arguments were not provided:
    -w <width>

USAGE:
    executable <input filename(s)>... image [FLAGS] [OPTIONS] -w <width>

For more information try --help
""")
        return 1
    height = height if height is not None else width
    model = load_models(inputs)
    if webify is not None:
        sys.stdout.write(web_frames(model, max(0, webify), width, height, opts))
    else:
        sys.stdout.write(render_ansi(model, width, height, opts))
    return 0


def terminal_command(inputs, opts):
    model = load_models(inputs)
    sys.stdout.write(render_ansi(model, 80, 24, opts))
    return 0


def load_models(paths):
    triangles = []
    for path in paths:
        if not os.path.exists(path):
            raise PanicError(
                "\nthread 'main' panicked at src/inputs.rs:126:39:\n"
                "called `Result::unwrap()` on an `Err` value: "
                f"\"filename: [{path}] couldn't load, tobj couldnt load/parse OBJ. open file failed\"\n"
                "note: run with `RUST_BACKTRACE=1` environment variable to display a backtrace\n"
            )
        lower = path.lower()
        if lower.endswith(".stl"):
            triangles.extend(load_stl(path))
        else:
            triangles.extend(load_obj(path))
    return triangles


def load_stl(path):
    verts = []
    tris = []
    with open(path, "r", errors="ignore") as handle:
        for line in handle:
            words = line.strip().split()
            if len(words) == 4 and words[0] == "vertex":
                verts.append(tuple(float(x) for x in words[1:4]))
                if len(verts) == 3:
                    tris.append((verts[0], verts[1], verts[2], (255, 255, 0)))
                    verts = []
    return tris


def load_obj(path):
    verts = []
    tris = []
    current = (255, 255, 0)
    materials = load_mtl_for_obj(path)
    with open(path, "r", errors="ignore") as handle:
        for line in handle:
            words = line.strip().split()
            if not words:
                continue
            if words[0] == "v" and len(words) >= 4:
                verts.append(tuple(float(x) for x in words[1:4]))
            elif words[0] == "usemtl" and len(words) >= 2:
                current = materials.get(words[1], PALETTE.get(words[1], (255, 255, 0)))
            elif words[0] == "f" and len(words) >= 4:
                idx = [int(part.split("/")[0]) - 1 for part in words[1:]]
                for i in range(1, len(idx) - 1):
                    try:
                        tris.append((verts[idx[0]], verts[idx[i]], verts[idx[i + 1]], current))
                    except IndexError:
                        pass
    return tris


def load_mtl_for_obj(path):
    mtls = {}
    base = os.path.dirname(path) or "."
    mtl_names = []
    with open(path, "r", errors="ignore") as handle:
        for line in handle:
            words = line.strip().split()
            if words[:1] == ["mtllib"] and len(words) >= 2:
                mtl_names.append(" ".join(words[1:]))
    for name in mtl_names:
        mpath = os.path.join(base, name)
        if not os.path.exists(mpath):
            raise PanicError(
                "\nthread 'main' panicked at src/inputs.rs:112:39:\n"
                "Expected to have materials.: OpenFileFailed\n"
                "note: run with `RUST_BACKTRACE=1` environment variable to display a backtrace\n"
            )
        current = None
        with open(mpath, "r", errors="ignore") as handle:
            for line in handle:
                words = line.strip().split()
                if words[:1] == ["newmtl"] and len(words) >= 2:
                    current = words[1]
                elif words[:1] == ["Kd"] and current and len(words) >= 4:
                    mtls[current] = tuple(max(0, min(255, int(float(v) * 255))) for v in words[1:4])
    return mtls


def rotate(p, opts):
    x, y, z = p
    cx, sx = math.cos(opts["x"]), math.sin(opts["x"])
    cy, sy = math.cos(opts["y"]), math.sin(opts["y"])
    cz, sz = math.cos(opts["z"]), math.sin(opts["z"])
    y, z = y * cx - z * sx, y * sx + z * cx
    x, z = x * cy + z * sy, -x * sy + z * cy
    x, y = x * cz - y * sz, x * sz + y * cz
    return x, y, z


def project_model(tris, width, height, opts):
    rotated = [(rotate(a, opts), rotate(b, opts), rotate(c, opts), color) for a, b, c, color in tris]
    pts = [p for tri in rotated for p in tri[:3]]
    if not pts:
        return [], 1, 0, 0, 0
    minx, maxx = min(p[0] for p in pts), max(p[0] for p in pts)
    miny, maxy = min(p[1] for p in pts), max(p[1] for p in pts)
    span = max(maxx - minx, maxy - miny, 1e-9)
    scale = min(max(1, width - 2), max(1, height - 2)) / span
    cx = (minx + maxx) / 2
    cy = (miny + maxy) / 2
    return rotated, scale, cx, cy, span


def raster_cells(tris, width, height, opts):
    rows = max(1, height - 1)
    cols = max(1, width * 2)
    chars = [[" " for _ in range(cols)] for _ in range(rows)]
    colors = [[(0, 0, 0) for _ in range(cols)] for _ in range(rows)]
    zbuf = [[-1e100 for _ in range(cols)] for _ in range(rows)]
    projected, scale, cx, cy, _ = project_model(tris, cols, rows, opts)
    for a, b, c, color in projected:
        p2 = []
        for p in (a, b, c):
            sx = int(round((p[0] - cx) * scale + cols / 2))
            sy = int(round(rows / 2 - (p[1] - cy) * scale))
            p2.append((sx, sy, p[2]))
        fill_triangle(p2, chars, colors, zbuf, color)
    return chars, colors


def fill_triangle(p, chars, colors, zbuf, color):
    rows, cols = len(chars), len(chars[0])
    xs = [q[0] for q in p]
    ys = [q[1] for q in p]
    minx, maxx = max(0, min(xs)), min(cols - 1, max(xs))
    miny, maxy = max(0, min(ys)), min(rows - 1, max(ys))
    area = edge(p[0], p[1], p[2][0], p[2][1])
    if abs(area) < 1e-9:
        for x, y, z in p:
            if 0 <= x < cols and 0 <= y < rows:
                chars[y][x] = "#"
                colors[y][x] = color
        return
    for y in range(miny, maxy + 1):
        for x in range(minx, maxx + 1):
            w0 = edge(p[1], p[2], x, y) / area
            w1 = edge(p[2], p[0], x, y) / area
            w2 = edge(p[0], p[1], x, y) / area
            if w0 >= -0.01 and w1 >= -0.01 and w2 >= -0.01:
                z = w0 * p[0][2] + w1 * p[1][2] + w2 * p[2][2]
                if z >= zbuf[y][x]:
                    zbuf[y][x] = z
                    shade = max(-1.0, min(1.0, z / 50.0))
                    chars[y][x] = shade_char(shade)
                    colors[y][x] = color


def edge(a, b, x, y):
    return (x - a[0]) * (b[1] - a[1]) - (y - a[1]) * (b[0] - a[0])


def shade_char(v):
    ramp = ".,-~:;=!*#$@"
    return ramp[max(0, min(len(ramp) - 1, int((v + 1) / 2 * (len(ramp) - 1))))]


def render_ansi(tris, width, height, opts):
    chars, colors = raster_cells(tris, width, height, opts)
    out = []
    for row_chars, row_colors in zip(chars, colors):
        line = []
        for ch, color in zip(row_chars, row_colors):
            fg = (255, 255, 255) if opts.get("b") and color != (0, 0, 0) else color
            line.append(f"{BG}\033[38;2;{fg[0]};{fg[1]};{fg[2]}m{ch}{RESET}")
        out.append("".join(line))
    return "\n".join(out)


def web_frames(tris, count, width, height, opts):
    frames = []
    for i in range(count):
        fopts = dict(opts)
        if count:
            fopts["z"] = opts.get("z", 0.0) + (2 * math.pi * i / count)
        chars, colors = raster_cells(tris, width, height, fopts)
        lines = []
        for row_chars, row_colors in zip(chars, colors):
            parts = []
            for ch, color in zip(row_chars, row_colors):
                parts.append(f'<span style="color:rgb({color[0]},{color[1]},{color[2]})">{html_escape(ch)}')
            lines.append("".join(parts))
        frames.append("`\n" + "\n".join(lines) + " `")
    return "let frames = [\n" + ",\n".join(frames) + "];\n"


def html_escape(ch):
    return {"&": "&amp;", "<": "&lt;", ">": "&gt;"}.get(ch, ch)


if __name__ == "__main__":
    try:
        sys.exit(main(sys.argv[1:]))
    except SystemExit as exc:
        raise exc
