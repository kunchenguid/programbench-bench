import os
import stat
import subprocess
import tempfile
import textwrap
import unittest


ROOT = os.path.dirname(os.path.dirname(__file__))
BIN = os.path.join(ROOT, "sloth.py")


class SlothCliTests(unittest.TestCase):
    def run_cmd(self, *args):
        return subprocess.run(
            [BIN, *args],
            text=True,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            cwd=ROOT,
        )

    def test_version_matches_reference(self):
        result = self.run_cmd("--version")
        self.assertEqual(result.returncode, 0)
        self.assertEqual(result.stdout, "Sloth 0.1\n")
        self.assertEqual(result.stderr, "")

    def test_help_matches_reference_shape(self):
        result = self.run_cmd("--help")
        self.assertEqual(result.returncode, 0)
        self.assertIn("Sloth 0.1\nMitchell Hynes. <mshynes@mun.ca>", result.stdout)
        self.assertIn("USAGE:\n    executable [FLAGS] [OPTIONS] <input filename(s)>... [SUBCOMMAND]", result.stdout)
        self.assertIn("-x, --yaw <x>", result.stdout)
        self.assertEqual(result.stderr, "")

    def test_missing_input_reports_required_argument(self):
        result = self.run_cmd()
        self.assertEqual(result.returncode, 1)
        self.assertEqual(result.stdout, "")
        self.assertIn("error: The following required arguments were not provided:", result.stderr)
        self.assertIn("<input filename(s)>...", result.stderr)

    def test_image_requires_width(self):
        with tempfile.NamedTemporaryFile("w", suffix=".stl", delete=False) as handle:
            handle.write("solid empty\nendsolid empty\n")
            path = handle.name
        try:
            result = self.run_cmd(path, "image")
        finally:
            os.unlink(path)
        self.assertEqual(result.returncode, 1)
        self.assertIn("error: The following required arguments were not provided:", result.stderr)
        self.assertIn("-w <width>", result.stderr)

    def test_ascii_stl_image_has_colored_terminal_cells(self):
        stl = textwrap.dedent(
            """\
            solid tri
              facet normal 0 0 1
                outer loop
                  vertex 0 0 0
                  vertex 1 0 0
                  vertex 0 1 0
                endloop
              endfacet
            endsolid tri
            """
        )
        with tempfile.NamedTemporaryFile("w", suffix=".stl", delete=False) as handle:
            handle.write(stl)
            path = handle.name
        try:
            result = self.run_cmd(path, "image", "-w", "8", "-h", "4")
        finally:
            os.unlink(path)
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertIn("\x1b[48;2;25;25;25m", result.stdout)
        self.assertIn("\x1b[38;2;255;255;0m", result.stdout)
        self.assertEqual(result.stdout.count("\n"), 2)

    def test_image_height_matches_reference_newline_count(self):
        with tempfile.NamedTemporaryFile("w", suffix=".stl", delete=False) as handle:
            handle.write("solid empty\nendsolid empty\n")
            path = handle.name
        try:
            result = self.run_cmd(path, "image", "-w", "10", "-h", "5")
        finally:
            os.unlink(path)
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertEqual(result.stdout.count("\n"), 3)

    def test_webify_emits_js_frame_array(self):
        with tempfile.NamedTemporaryFile("w", suffix=".stl", delete=False) as handle:
            handle.write("solid empty\nendsolid empty\n")
            path = handle.name
        try:
            result = self.run_cmd(path, "image", "-j", "2", "-w", "3", "-h", "2")
        finally:
            os.unlink(path)
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertTrue(result.stdout.startswith("let frames = [\n`\n"))
        self.assertTrue(result.stdout.rstrip().endswith("`];"))
        self.assertEqual(result.stdout.count("`"), 4)

    def test_obj_with_missing_material_file_panics_like_reference(self):
        obj = "mtllib missing.mtl\nv 0 0 0\nv 1 0 0\nv 0 1 0\nusemtl Yellow\nf 1 2 3\n"
        with tempfile.NamedTemporaryFile("w", suffix=".obj", delete=False) as handle:
            handle.write(obj)
            path = handle.name
        try:
            result = self.run_cmd(path, "image", "-w", "8", "-h", "4")
        finally:
            os.unlink(path)
        self.assertEqual(result.returncode, 101)
        self.assertIn("Expected to have materials.: OpenFileFailed", result.stderr)

    def test_missing_obj_file_panics_like_reference(self):
        missing = os.path.join(tempfile.gettempdir(), "sloth_missing_for_test.obj")
        try:
            os.unlink(missing)
        except FileNotFoundError:
            pass
        result = self.run_cmd(missing, "image", "-w", "8", "-h", "4")
        self.assertEqual(result.returncode, 101)
        self.assertIn(f"filename: [{missing}] couldn't load", result.stderr)
        self.assertIn("open file failed", result.stderr)


if __name__ == "__main__":
    unittest.main()
