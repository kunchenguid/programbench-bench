#!/usr/bin/env python3
import datetime as _dt
import os
from pathlib import Path
import select
import stat
import sys
import termios
import tty
import time


VERSION_HELP = """# felix v2.16.1
A simple TUI file manager with vim-like keymapping.

## Usage
`fx` => Show items in the current directory.
`fx <directory path>` => Show items in the path.
Both relative and absolute path available.

## Options
`--help` | `-h`   => Print help.
`--log`  | `-l`   => Launch the app, automatically generating a log file.
`--init`          => Returns a shell script that can be sourcedfor
                     for shell integration.

## Manual
j / <Down>         :Go down.
k / <Up>           :Go up.
<C-d>              :Go down 1/2 page.
<C-u>>             :Go up 1/2 page.
h / <Left>         :Go to the parent directory if exists.
l / <Right> / <CR> :Open item or change directory.
gg                 :Go to the top.
G                  :Go to the bottom.
z<CR>              :Go to the home directory.
z {keyword}<CR>    :Jump to a directory that matches the keyword.
                    (zoxide required)
<C-o>              :Jump backward.
<C-i>              :Jump forward.
i{file name}<CR>   :Create a new empty file.
I{dir name}<CR>    :Create a new empty directory.
o                  :Open item in a new window.
e                  :Unpack archive/compressed file.
dd                 :Delete and yank item.
yy                 :Yank item.
p                  :Put yanked item(s) from register zero
                    in the current directory.
:reg               :Show registers. To hide it, press v.
"ayy               :Yank item to register a.
"add               :Delete and yank item to register a.
"Ayy               :Append item to register a.
"Add               :Delete and append item to register a.
"ap                :Put item(s) from register a.
V                  :Switch to the linewise visual mode.
  - y              :In the visual mode, yank selected item(s).
  - d              :In the visual mode, delete and yank selected item(s).
  - "ay            :In the visual mode, yank items to register a.
  - "ad            :In the visual mode, delete and yank items to register a.
  - "Ay            :In the visual mode, append items to register a.
  - "Ad            :In the visual mode, delete and append items to register a.
  - c              :Rename selected items in default editor.
u                  :Undo put/delete/rename.
<C-r>              :Redo put/delete/rename.
v                  :Toggle whether to show the preview.
s                  :Toggle between vertical / horizontal split in the preview mode.
<Alt-j>
 / <Alt-<Down>>    :Scroll down the preview text.
<Alt-k> 
 / <Alt-<Up>>      :Scroll up the preview text.
<BS>               :Toggle whether to show hidden items.
t                  :Toggle the sort order (name <-> modified time).
c                  :Switch to the rename mode.
/{keyword}         :Search items by a keyword.
n                  :Go forward to the item that matches the keyword.
N                  :Go backward to the item that matches the keyword.
:                  :Switch to the command line.
  - <C-r>a         :In the command line, paste item name in register a.
:cd<CR>            :Go to the home directory.
:cd {path}<CR>     :Go to the path.
:e<CR>             :Reload the current directory.
:config<CR>        :Go to the directory that contains the config file if exists.
:trash<CR>         :Go to the trash directory.
:empty<CR>         :Empty the trash directory.
:h<CR>             :Show help.
:q<CR>             :Exit.
:{command}         :Execute a command e.g. :zip test *.md
<Esc>              :Return to the normal mode.
<C-h>              :Works as Backspace after `i`, `I`, `c`, `/`, `:` and `z`.
ZZ                 :Exit without cd to last working directory
                    (if `match_vim_exit_behavior` is `false`).
ZQ                 :cd into the last working directory and exit
                    (if shell setting is ready and `match_vim_exit_behavior is `false`).

## Preview feature
By default, text files and directories can be previewed.
To preview images, you need to install chafa (>= v1.10.0).
Please see https://hpjansson.org/chafa/

## Configuration

*Both `config.yaml` and `config.yml` work.*

### Linux
config file    : $XDG_CONFIG_HOME/felix/config.yaml(config.yml)
trash directory: $XDG_DATA_HOME/felix/trash
log files      : $XDG_DATA_HOME/felix/log

### macOS
On macOS, felix looks for the config file in the following locations:

1. `$HOME/Library/Application Support/felix/config.yaml(config.yml)`
2. `$HOME/.config/felix/config.yaml`

trash directory: $HOME/Library/Application Support/felix/trash
log files      : $HOME/Library/Application Support/felix/log

### Windows
config file     : $PROFILE\\\\AppData\\\\Roaming\\\\felix\\\\config.yaml(config.yml)
trash directory : $PROFILE\\\\AppData\\\\Local\\\\felix\\\\trash
log files       : $PROFILE\\\\AppData\\\\Local\\\\felix\\\\log

For more details, visit https://github.com/kyoheiu/felix
"""

INIT_SNIPPET = """# To be eval'ed in the calling shell
  eval "$(
    if [ -n "$XDG_RUNTIME_DIR" ]; then
      runtime_dir="$XDG_RUNTIME_DIR/felix"
    elif [ -n "$TMPDIR" ]; then
      runtime_dir="$TMPDIR/felix"
    else
      runtime_dir=/tmp/felix
    fi

    mkdir -p "$runtime_dir"

    # Clean up leftover LWD files
    find "$runtime_dir" -type f -and -mmin +1 -delete

    cat << EOF
fx() {
  local RUNTIME_DIR="$runtime_dir"
  SHELL_PID=\\$\\$ command fx "\\$@"

  if [ -f "\\$RUNTIME_DIR/\\$\\$" ]; then
    cd "\\$(cat "\\$RUNTIME_DIR/\\$\\$")"
    rm "\\$RUNTIME_DIR/\\$\\$"
  fi
}
EOF
  )"
"""


def data_home() -> Path:
    if os.environ.get("XDG_DATA_HOME"):
        return Path(os.environ["XDG_DATA_HOME"])
    return Path(os.environ.get("HOME", str(Path.home()))) / ".local" / "share"


def create_log() -> None:
    log_dir = data_home() / "felix" / "log"
    log_dir.mkdir(parents=True, exist_ok=True)
    now = _dt.datetime.now()
    path = log_dir / f"{now:%Y-%m-%d-%H-%M-%S}.log"
    path.write_text(f"{now:%H:%M:%S} [INFO] ===START===\n")


def print_help() -> None:
    sys.stdout.write(VERSION_HELP)


def invalid_path(p: str) -> None:
    sys.stderr.write(f"Invalid path: {p}\n`fx -h` shows help.\n")


def path_should_be_dir() -> None:
    sys.stderr.write("Path should be directory.\n`fx -h` shows help.\n")


def parse_args(argv):
    if len(argv) > 2:
        if len(argv) == 3 and argv[1] in ("-l", "--log"):
            return "run", argv[2], True
        return "help", None, False
    if len(argv) == 2:
        if argv[1] in ("-h", "--help"):
            return "help", None, False
        if argv[1] == "--init":
            return "init", None, False
        if argv[1] in ("-l", "--log"):
            return "run", ".", True
        return "run", argv[1], False
    return "run", ".", False


def git_branch(path: Path) -> str:
    cur = path.resolve()
    for base in [cur, *cur.parents]:
        head = base / ".git" / "HEAD"
        if head.is_file():
            text = head.read_text(errors="ignore").strip()
            if text.startswith("ref:"):
                return text.rsplit("/", 1)[-1]
            if text:
                return text[:7]
    return ""


def mode_string(st) -> str:
    return oct(stat.S_IMODE(st.st_mode))[-3:]


def fmt_size(size: int) -> str:
    if size < 1024:
        return f"{size}B"
    if size < 1024 * 1024:
        return f"{max(1, round(size / 1024))}KB"
    return f"{size / (1024 * 1024):.1f}MB"


def sorted_entries(path: Path):
    entries = []
    try:
        for entry in path.iterdir():
            try:
                st = entry.stat()
            except OSError:
                continue
            entries.append((entry.is_dir(), entry.name.lower(), entry.name, entry, st))
    except OSError as exc:
        sys.stderr.write(f"{exc}\n")
    entries.sort(key=lambda item: (not item[0], item[1]))
    return entries


def render(path: Path, cols: int, rows: int, selected: int = 0) -> None:
    entries = sorted_entries(path)
    branch = git_branch(path)
    title = f" {path.resolve()}"
    if branch:
        title += f" on {branch}"
    out = ["\x1b7\x1b[?25l\x1b[?1049h\x1b[2J\x1b[1;1H\x1b[38;5;6m", title, "\x1b[0m"]
    visible = entries[: max(0, rows - 4)]
    for i, (_, _, name, entry, st) in enumerate(visible, start=3):
        color = "14" if entry.is_dir() else ("1" if os.access(entry, os.X_OK) else "15")
        stamp = _dt.datetime.fromtimestamp(st.st_mtime).strftime("%Y-%m-%d %H:%M")
        prefix = ">" if i == 3 + selected else " "
        line = f"\x1b[{i};1H{prefix}\x1b[{i};3H\x1b[38;5;{color}m{name}\x1b[0m"
        if cols > 30:
            line += f"\x1b[1000D\x1b[{max(1, cols - 17)}C {stamp}\x1b[0m"
        out.append(line)
    if entries:
        st = visible[selected][4] if selected < len(visible) else entries[0][4]
        status_line = f" {selected + 1}/{len(entries)} {fmt_size(st.st_size)} {mode_string(st)}"
    else:
        status_line = " 0/0"
    out.append(f"\x1b[{rows};1H\x1b[2K\x1b[7m{status_line:<{cols}}\x1b[0m")
    sys.stdout.write("".join(out))
    sys.stdout.flush()


def run_tui(path: Path) -> None:
    try:
        size = os.get_terminal_size(sys.stdout.fileno())
    except OSError:
        sys.stderr.write("Error: Cannot detect terminal size\n")
        return
    if size.columns < 100 or size.lines < 30:
        sys.stderr.write("Error: Too small window size\n")
        return

    render(path, size.columns, size.lines)
    old = None
    if sys.stdin.isatty():
        try:
            old = termios.tcgetattr(sys.stdin.fileno())
            tty.setcbreak(sys.stdin.fileno())
        except termios.error:
            old = None
    try:
        deadline = None
        buf = ""
        while True:
            readable, _, _ = select.select([sys.stdin], [], [], 0.1)
            if not readable:
                if deadline is not None and time.monotonic() > deadline:
                    break
                continue
            ch = sys.stdin.read(1)
            if not ch:
                deadline = time.monotonic() + 0.2
                continue
            buf = (buf + ch)[-3:]
            if ch in ("q", "\x03", "\x04") or buf.endswith("ZZ") or buf.endswith("ZQ"):
                break
    finally:
        if old is not None:
            try:
                termios.tcsetattr(sys.stdin.fileno(), termios.TCSADRAIN, old)
            except termios.error:
                pass
        sys.stdout.write("\x1b[?1049l\x1b[?25h\x1b8")
        sys.stdout.flush()


def main(argv) -> int:
    mode, target, log = parse_args(argv)
    if mode == "help":
        print_help()
        return 0
    if mode == "init":
        sys.stdout.write(INIT_SNIPPET)
        return 0
    if log:
        create_log()
    path = Path(target)
    if not path.exists():
        if log:
            sys.stdout.write("\n")
        invalid_path(target)
        return 0
    if not path.is_dir():
        path_should_be_dir()
        return 0
    run_tui(path)
    return 0


if __name__ == "__main__":
    raise SystemExit(main(sys.argv))
