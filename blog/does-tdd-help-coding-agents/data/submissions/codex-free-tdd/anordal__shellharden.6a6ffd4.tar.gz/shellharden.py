#!/usr/bin/env python3
import os
import re
import sys

VERSION = "4.3.1"
HELP = """Shellharden: The corrective bash syntax highlighter.

Usage:
	shellharden [options] [files]
	cat files | shellharden [options] ''

Shellharden is a syntax highlighter and a tool to semi-automate the rewriting
of scripts to ShellCheck conformance, mainly focused on quoting.

The default mode of operation is like `cat`, but with syntax highlighting in
foreground colors and suggestive changes in background colors.

Options:
	--suggest         Output a colored diff suggesting changes.
	--syntax          Output syntax highlighting with ANSI colors.
	--syntax-suggest  Diff with syntax highlighting (default mode).
	--transform       Output suggested changes.
	--check           No output; exit with 2 if changes are suggested.
	--replace         Replace file contents with suggested changes.
	--                Don't treat further arguments as options.
	-h|--help         Show help text.
	--version         Show version.

The changes suggested by Shellharden inhibits word splitting and indirect
pathname expansion. This will make your script ShellCheck compliant in terms of
quoting. Whether your script will work afterwards is a different question:
If your script was using those features on purpose, it obviously won't anymore!

Every script is possible to write without using word splitting or indirect
pathname expansion, but it may involve doing things differently.
See the accompanying file how_to_do_things_safely_in_bash.md or online:
https://github.com/anordal/shellharden/blob/master/how_to_do_things_safely_in_bash.md
"""

SPECIAL = set("@*#?$!-0123456789")
NAME_RE = re.compile(r"[A-Za-z_][A-Za-z0-9_]*")


def matching_brace(s, start):
    depth = 1
    i = start + 2
    quote = None
    while i < len(s):
        c = s[i]
        if quote:
            if c == "\\":
                i += 2
                continue
            if c == quote:
                quote = None
            i += 1
            continue
        if c in "'\"":
            quote = c
        elif c == "{" and i and s[i - 1] == "$":
            depth += 1
        elif c == "}":
            depth -= 1
            if depth == 0:
                return i
        i += 1
    return -1


def parse_expansion(s, i):
    if i >= len(s) or s[i] != "$":
        return None
    if i + 1 >= len(s):
        return None
    n = s[i + 1]
    if n == "{":
        end = matching_brace(s, i)
        if end < 0:
            return None
        text = s[i:end + 1]
        inner = text[2:-1]
        if inner.startswith("#") or inner.startswith("!"):
            return (end + 1, text, "", False, text)
        if inner in SPECIAL:
            return (end + 1, text, inner, True, text)
        m = re.match(r"([A-Za-z_][A-Za-z0-9_]*)(.*)$", inner, re.S)
        name = m.group(1) if m else ""
        suffix = m.group(2) if m else ""
        simple = bool(name) and suffix == ""
        return (end + 1, text, name, simple, text)
    if n in SPECIAL:
        return (i + 2, s[i:i + 2], n, True, s[i:i + 2])
    m = NAME_RE.match(s, i + 1)
    if m:
        name = m.group(0)
        return (m.end(), "$" + name, name, True, "$" + name)
    return None


def line_context_prefix(out):
    j = len(out) - 1
    while j >= 0 and out[j].isspace() and out[j] != "\n":
        j -= 1
    end = j + 1
    while j >= 0 and not out[j].isspace() and out[j] not in ";|&(){}[]<>":
        j -= 1
    return "".join(out[j + 1:end])


def is_assignment_array_context(out):
    return line_context_prefix(out).endswith("=(")


def quote_expansion(exp, for_loop=False):
    _, text, name, simple, original = exp
    if name == "*":
        return '"$@"'
    if for_loop and name and name not in ("@", "*"):
        if text.startswith("${") and text == "${" + name + "}":
            return '"${' + name + '[@]}"'
        if text == "$" + name:
            return '"${' + name + '[@]}"'
    if text.startswith("${") and text.endswith("[*]}"):
        return '"' + text[:-4] + '[@]}"'
    return '"' + original + '"'


def find_matching_paren(s, start):
    depth = 1
    i = start + 1
    state = "normal"
    escape = False
    while i < len(s):
        c = s[i]
        if state == "single":
            if c == "'":
                state = "normal"
            i += 1
            continue
        if state == "double":
            if escape:
                escape = False
            elif c == "\\":
                escape = True
            elif c == '"':
                state = "normal"
            i += 1
            continue
        if c == "'":
            state = "single"
        elif c == '"':
            state = "double"
        elif c == "(":
            depth += 1
        elif c == ")":
            depth -= 1
            if depth == 0:
                return i
        i += 1
    return -1


def in_assignment_rhs(out):
    word = line_context_prefix(out)
    if word.endswith("=(") or "=" not in word:
        return False
    lhs = word.split("=", 1)[0]
    lhs = re.sub(r"\[[^\]]*\]$", "", lhs)
    return bool(NAME_RE.fullmatch(lhs))


def transform_line(line):
    nl = "\n" if line.endswith("\n") else ""
    body = line[:-1] if nl else line
    indent = body[:len(body) - len(body.lstrip())]
    stripped = body.strip()
    if stripped.startswith("[[") and stripped.endswith("]]"):
        return line
    m_test = re.fullmatch(r"\[\s+-n\s+(\$[A-Za-z_][A-Za-z0-9_]*|\$\{[^}]+\})\s+\]", stripped)
    if m_test:
        return indent + "[ " + quote_expansion(parse_expansion(m_test.group(1), 0)) + ' != "" ]' + nl
    out = []
    i = 0
    state = "normal"
    escape = False
    expect_for_word = False
    in_for_in_word = False
    in_case_selector = False
    last_word = ""
    while i < len(line):
        c = line[i]
        if state == "single":
            out.append(c)
            if c == "'":
                state = "normal"
            i += 1
            continue
        if state == "double":
            out.append(c)
            if escape:
                escape = False
            elif c == "\\":
                escape = True
            elif c == '"':
                state = "normal"
            i += 1
            continue
        if c == "#" and (not out or out[-1].isspace()):
            out.append(line[i:])
            break
        if c == "'":
            out.append(c)
            state = "single"
            i += 1
            continue
        if c == '"':
            out.append(c)
            state = "double"
            i += 1
            continue
        if c == "\\":
            out.append(line[i:i + 2])
            i += 2
            continue
        if c.isspace() or c in ";()|&<>[]{}":
            token = "".join(out).split()[-1] if "".join(out).split() else ""
            if last_word == "for" and c.isspace():
                expect_for_word = True
            if c == ";":
                in_for_in_word = False
            out.append(c)
            i += 1
            continue
        exp = parse_expansion(line, i)
        if exp:
            if not exp[2] or in_assignment_rhs(out) or in_case_selector:
                repl = exp[4]
            else:
                repl = quote_expansion(exp, in_for_in_word)
            out.append(repl)
            i = exp[0]
            continue
        if c == "$" and i + 1 < len(line) and line[i + 1] == "(":
            if i + 2 < len(line) and line[i + 2] == "(":
                end = line.find("))", i + 3)
                if end >= 0:
                    out.append(line[i:end + 2])
                    i = end + 2
                    continue
            end = find_matching_paren(line, i + 1)
            if end >= 0:
                inner = line[i + 2:end]
                out.append('"$(' + transform_line(inner) + ')"')
                i = end + 1
                continue
        if c == "`":
            end = line.find("`", i + 1)
            if end >= 0:
                inner = line[i + 1:end]
                out.append('"$(' + transform_line(inner) + ')"')
                i = end + 1
                continue
        m = re.match(r"[A-Za-z_][A-Za-z0-9_]*", line[i:])
        if m:
            word = m.group(0)
            out.append(word)
            if word == "for":
                last_word = "for"
            elif word == "case":
                in_case_selector = True
                last_word = "case"
            elif expect_for_word:
                expect_for_word = False
                last_word = word
            elif in_case_selector and word == "in":
                in_case_selector = False
                last_word = word
            elif last_word and word == "in":
                in_for_in_word = True
                last_word = ""
            else:
                last_word = word
            i += len(word)
            continue
        out.append(c)
        i += 1
    return "".join(out)


def transform_text(text):
    return "".join(transform_line(line) for line in text.splitlines(True))


def colorize(text, suggest=False):
    if suggest:
        # A lightweight approximation: color inserted quotes in transformed output.
        return transform_text(text)
    return text


def read_inputs(files):
    if not files:
        return ""
    chunks = []
    for path in files:
        if path == "":
            chunks.append(sys.stdin.read())
        else:
            with open(path, "r", encoding="utf-8") as f:
                chunks.append(f.read())
    return "".join(chunks)


def parse_args(argv):
    mode = "syntax-suggest"
    files = []
    options_done = False
    for arg in argv:
        if options_done:
            files.append(arg)
        elif arg == "--":
            options_done = True
        elif arg in ("-h", "--help"):
            return "help", []
        elif arg == "--version":
            return "version", []
        elif arg in ("--suggest", "--syntax", "--syntax-suggest", "--transform", "--check", "--replace"):
            mode = arg[2:]
        elif arg.startswith("-") and arg != "":
            raise ValueError(arg)
        else:
            files.append(arg)
    return mode, files


def main(argv):
    try:
        mode, files = parse_args(argv)
    except ValueError as e:
        sys.stderr.write(f"{e.args[0]}: No such option.\n")
        return 3
    if mode == "help":
        sys.stdout.write(HELP)
        return 0
    if mode == "version":
        sys.stdout.write(VERSION + "\n")
        return 0
    original = read_inputs(files)
    transformed = transform_text(original)
    if mode == "check":
        return 2 if transformed != original else 0
    if mode == "replace":
        for path in files:
            if path == "":
                continue
            with open(path, "r", encoding="utf-8") as f:
                before = f.read()
            after = transform_text(before)
            if after != before:
                with open(path, "w", encoding="utf-8") as f:
                    f.write(after)
        return 0
    if mode == "transform":
        sys.stdout.write(transformed)
    elif mode in ("suggest", "syntax-suggest"):
        sys.stdout.write(colorize(original, suggest=True))
    elif mode == "syntax":
        sys.stdout.write(colorize(original, suggest=False))
    return 0

if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
