import os
import subprocess
import textwrap
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
PROG = ROOT / "shellharden.py"


def run_cmd(args, data=None):
    return subprocess.run(
        ["python3", str(PROG), *args],
        input=data,
        text=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
    )


def test_version_matches_reference():
    p = run_cmd(["--version"])
    assert p.returncode == 0
    assert p.stdout == "4.3.1\n"
    assert p.stderr == ""


def test_transform_quotes_common_unquoted_expansions(tmp_path):
    script = tmp_path / "sample.sh"
    script.write_text(textwrap.dedent("""\
        echo $foo
        cp $src $dst
        for f in $files; do echo $f; done
        echo ${foo:-bar}
        echo "$already" 'single $no'
        echo $@
        echo "$@"
        arr=($words)
    """))
    p = run_cmd(["--transform", str(script)])
    assert p.returncode == 0
    assert p.stdout == textwrap.dedent("""\
        echo "$foo"
        cp "$src" "$dst"
        for f in "${files[@]}"; do echo "$f"; done
        echo "${foo:-bar}"
        echo "$already" 'single $no'
        echo "$@"
        echo "$@"
        arr=("$words")
    """)
    assert p.stderr == ""


def test_check_reports_when_transform_would_change(tmp_path):
    changed = tmp_path / "changed.sh"
    changed.write_text("echo $x\n")
    unchanged = tmp_path / "unchanged.sh"
    unchanged.write_text("echo hi\n")
    p_changed = run_cmd(["--check", str(changed)])
    p_unchanged = run_cmd(["--check", str(unchanged)])
    assert (p_changed.returncode, p_changed.stdout, p_changed.stderr) == (2, "", "")
    assert (p_unchanged.returncode, p_unchanged.stdout, p_unchanged.stderr) == (0, "", "")


def test_empty_file_argument_reads_stdin():
    p = run_cmd(["--transform", ""], "echo $stdin\n")
    assert p.returncode == 0
    assert p.stdout == 'echo "$stdin"\n'


def test_replace_updates_file_in_place(tmp_path):
    script = tmp_path / "replace.sh"
    script.write_text("echo $x\n")
    p = run_cmd(["--replace", str(script)])
    assert p.returncode == 0
    assert p.stdout == ""
    assert script.read_text() == 'echo "$x"\n'


def test_unknown_option_matches_reference():
    p = run_cmd(["--bad"])
    assert p.returncode == 3
    assert p.stdout == ""
    assert p.stderr == "--bad: No such option.\n"


def test_transform_handles_reference_shell_constructs(tmp_path):
    script = tmp_path / "constructs.sh"
    script.write_text(textwrap.dedent("""\
        foo=$bar
        foo=${bar:-baz}
        : ${need:?missing}
        echo pre${x}post
        echo ${arr[*]}
        echo $(echo $inner)
        echo `echo $old`
        echo $((x + y))
        echo ${#name}
        echo hi # comment $x
        if [ $x = y ]; then echo $x; fi
        case $x in a) echo $x;; esac
    """))
    p = run_cmd(["--transform", str(script)])
    assert p.returncode == 0
    assert p.stdout == textwrap.dedent("""\
        foo=$bar
        foo=${bar:-baz}
        : "${need:?missing}"
        echo pre"${x}"post
        echo "${arr[@]}"
        echo "$(echo "$inner")"
        echo "$(echo "$old")"
        echo $((x + y))
        echo ${#name}
        echo hi # comment $x
        if [ "$x" = y ]; then echo "$x"; fi
        case $x in a) echo "$x";; esac
    """)


def test_transform_handles_test_and_special_parameter_edges(tmp_path):
    script = tmp_path / "edges.sh"
    script.write_text(textwrap.dedent("""\
        echo $*
        echo $1 ${2}
        [ -n $foo ]
        [[ -n $foo && $bar == baz ]]
    """))
    p = run_cmd(["--transform", str(script)])
    assert p.returncode == 0
    assert p.stdout == textwrap.dedent("""\
        echo "$@"
        echo "$1" "${2}"
        [ "$foo" != "" ]
        [[ -n $foo && $bar == baz ]]
    """)
