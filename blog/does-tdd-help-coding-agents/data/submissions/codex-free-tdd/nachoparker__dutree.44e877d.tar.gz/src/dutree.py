#!/usr/bin/env python3
import os
import sys
from dataclasses import dataclass, field

HELP = """Usage: ./executable [options] <path> [<path>..]

Options:
    -d, --depth [DEPTH] show directories up to depth N (def 1)
    -a, --aggr [N[KMG]] aggregate smaller than N B/KiB/MiB/GiB (def 1M)
    -s, --summary       equivalent to -da, or -d1 -a1M
    -u, --usage         report real disk usage instead of file size
    -b, --bytes         print sizes in bytes
    -f, --files-only    skip directories for a fast local overview
    -x, --exclude NAME  exclude matching files or directories
    -H, --no-hidden     exclude hidden files
    -A, --ascii         ASCII characters only, no colors
    -h, --help          show help
    -v, --version       print version number"""


@dataclass
class Options:
    depth: int | None = None
    aggr: int | None = None
    usage: bool = False
    bytes: bool = False
    files_only: bool = False
    no_hidden: bool = False
    excludes: list[str] = field(default_factory=list)


@dataclass
class Node:
    name: str
    size: int
    children: list["Node"] = field(default_factory=list)
    aggregate: bool = False


def parse_size(text: str) -> int | None:
    if not text:
        return None
    mult = 1
    last = text[-1].upper()
    if last in "KMG":
        mult = {"K": 1024, "M": 1024**2, "G": 1024**3}[last]
        text = text[:-1]
    try:
        return int(text) * mult
    except ValueError:
        return None


def parse_args(argv: list[str]) -> tuple[Options, list[str], int]:
    opts = Options()
    paths: list[str] = []
    i = 0
    while i < len(argv):
        arg = argv[i]
        if arg in ("-h", "--help"):
            print(HELP)
            return opts, paths, 0
        if arg in ("-v", "--version"):
            print("dutree version 0.2.18")
            return opts, paths, 0
        if arg == "-s" or arg == "--summary":
            opts.depth = 1
            opts.aggr = 1024**2
        elif arg in ("-u", "--usage"):
            opts.usage = True
        elif arg in ("-b", "--bytes"):
            opts.bytes = True
        elif arg in ("-f", "--files-only"):
            opts.files_only = True
        elif arg in ("-H", "--no-hidden"):
            opts.no_hidden = True
        elif arg in ("-A", "--ascii"):
            pass
        elif arg in ("-x", "--exclude"):
            i += 1
            if i >= len(argv):
                print("missing argument")
                return opts, paths, 1
            opts.excludes.append(argv[i])
        elif arg.startswith("--exclude="):
            opts.excludes.append(arg.split("=", 1)[1])
        elif arg in ("-d", "--depth"):
            if i + 1 < len(argv):
                val = parse_size(argv[i + 1])
                if val is not None:
                    opts.depth = val
                    i += 1
                else:
                    opts.depth = 1
            else:
                opts.depth = 1
        elif arg.startswith("--depth="):
            val = parse_size(arg.split("=", 1)[1])
            if val is None:
                print(f"invalid argument '{arg.split('=', 1)[1]}'")
                return opts, paths, 1
            opts.depth = val
        elif arg in ("-a", "--aggr"):
            if i + 1 >= len(argv):
                opts.aggr = 1024**2
            else:
                val = parse_size(argv[i + 1])
                if val is None:
                    print(f"invalid argument '{argv[i + 1]}'")
                    return opts, paths, 1
                opts.aggr = val
                i += 1
        elif arg.startswith("--aggr="):
            val = parse_size(arg.split("=", 1)[1])
            if val is None:
                print(f"invalid argument '{arg.split('=', 1)[1]}'")
                return opts, paths, 1
            opts.aggr = val
        elif arg.startswith("-d") and len(arg) > 2 and arg[2:].isdigit():
            opts.depth = int(arg[2:])
        elif arg.startswith("-a") and len(arg) > 2:
            val = parse_size(arg[2:])
            if val is None:
                print(f"invalid argument '{arg[2:]}'")
                return opts, paths, 1
            opts.aggr = val
        elif arg == "-da":
            opts.depth = 1
            opts.aggr = 1024**2
        elif arg.startswith("-") and len(arg) > 2:
            for ch in arg[1:]:
                if ch == "u":
                    opts.usage = True
                elif ch == "b":
                    opts.bytes = True
                elif ch == "f":
                    opts.files_only = True
                elif ch == "H":
                    opts.no_hidden = True
                elif ch == "A":
                    pass
                elif ch == "d":
                    opts.depth = 1
                elif ch == "a":
                    opts.aggr = 1024**2
                else:
                    print(f"invalid option '{arg}'")
                    return opts, paths, 1
        else:
            paths.append(arg)
        i += 1
    if not paths:
        paths = ["."]
    return opts, paths, -1


def excluded(name: str, opts: Options) -> bool:
    if opts.no_hidden and name.startswith("."):
        return True
    return any(name == pat or pat in name for pat in opts.excludes)


def own_size(path: str, opts: Options) -> int:
    st = os.lstat(path)
    return st.st_blocks * 512 if opts.usage else st.st_size


def build_node(path: str, opts: Options) -> Node:
    name = os.path.basename(os.path.normpath(path)) or path
    total = own_size(path, opts)
    children: list[Node] = []
    if os.path.isdir(path) and not os.path.islink(path):
        try:
            names = os.listdir(path)
        except OSError:
            names = []
        for child_name in names:
            if excluded(child_name, opts):
                continue
            child_path = os.path.join(path, child_name)
            if opts.files_only and os.path.isdir(child_path) and not os.path.islink(child_path):
                continue
            try:
                child = build_node(child_path, opts)
            except OSError:
                continue
            total += child.size
            children.append(child)
    children.sort(key=lambda n: (-n.size, n.name))
    return Node(name=name, size=total, children=children)


def apply_aggregation(node: Node, threshold: int | None) -> None:
    if threshold is None:
        for child in node.children:
            apply_aggregation(child, threshold)
        return
    kept: list[Node] = []
    agg = 0
    for child in node.children:
        if child.size < threshold:
            agg += child.size
        else:
            apply_aggregation(child, threshold)
            kept.append(child)
    if agg:
        kept.append(Node("<aggregated>", agg, aggregate=True))
    kept.sort(key=lambda n: (-n.size, n.name))
    node.children = kept


def format_size(size: int, bytes_mode: bool) -> str:
    if bytes_mode:
        return f"{size} B"
    units = ["B", "KiB", "MiB", "GiB", "TiB"]
    val = float(size)
    unit = units[0]
    for unit in units:
        if val < 1024 or unit == units[-1]:
            break
        val /= 1024
    if unit == "B":
        return f"{int(val)} B"
    return f"{val:.2f} {unit}"


def bar(child_size: int, max_sibling: int) -> str:
    if max_sibling <= 0:
        return " " * 32
    width = int(child_size * 32 / max_sibling)
    if child_size and width == 0:
        width = 1
    return " " * (32 - width) + "#" * width


def line_for(prefix: str, connector: str, node: Node, parent_size: int, max_sibling: int, opts: Options) -> str:
    name = node.name[:20]
    label = f"{prefix}{connector} {name}"
    label = label.ljust(25)
    pct = int(node.size * 100 / parent_size) if parent_size else 0
    return f"{label}│ {bar(node.size, max_sibling)}│ {pct:3}% {format_size(node.size, opts.bytes):>12}"


def emit_children(node: Node, opts: Options, level: int = 1, prefix: str = "") -> list[str]:
    if opts.depth is not None and level > opts.depth:
        return []
    lines: list[str] = []
    max_sibling = max((c.size for c in node.children), default=0)
    for idx, child in enumerate(node.children):
        last = idx == len(node.children) - 1
        connector = "└─" if last else "├─"
        lines.append(line_for(prefix, connector, child, node.size, max_sibling, opts))
        if child.children and (opts.depth is None or level < opts.depth):
            extension = "   " if last else "│  "
            lines.extend(emit_children(child, opts, level + 1, prefix + extension))
    return lines


def main(argv: list[str]) -> int:
    opts, paths, status = parse_args(argv)
    if status >= 0:
        return status
    roots = []
    for path in paths:
        if not os.path.exists(path):
            print(f"path {path} doesn't exist")
            return 1
        roots.append(build_node(path, opts))
    if len(roots) == 1:
        root = roots[0]
    else:
        root = Node("<collection>", sum(n.size for n in roots), roots)
        root.children.sort(key=lambda n: (-n.size, n.name))
    apply_aggregation(root, opts.aggr)
    print(f"[ {root.name} {format_size(root.size, opts.bytes)} ]")
    for line in emit_children(root, opts):
        print(line)
    return 0


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
