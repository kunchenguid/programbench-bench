#!/usr/bin/env python3
import math
import os
import re
import sys

VERSION = "Lua 5.5.1  Copyright (C) 1994-2026 Lua.org, PUC-Rio"


class LuaError(Exception):
    pass


class ReturnSignal(Exception):
    def __init__(self, values):
        self.values = values


class BreakSignal(Exception):
    pass


class Nil:
    pass


NIL = Nil()


def isnil(v):
    return v is NIL or v is None


def first(v):
    return v[0] if isinstance(v, list) and v else NIL if isinstance(v, list) else v


def truthy(v):
    v = first(v)
    return not (isnil(v) or v is False)


def lua_num(v):
    v = first(v)
    if isinstance(v, (int, float)):
        return v
    if isinstance(v, str):
        try:
            return int(v) if re.fullmatch(r"[+-]?\d+", v) else float(v)
        except ValueError:
            pass
    raise LuaError(f"attempt to perform arithmetic on a {lua_type(v)} value")


def lua_str(v):
    v = first(v)
    if isnil(v):
        return "nil"
    if v is True:
        return "true"
    if v is False:
        return "false"
    if isinstance(v, float) and v.is_integer():
        return str(int(v))
    if isinstance(v, LuaTable):
        return f"table: 0x{id(v):x}"
    if isinstance(v, LuaFunction):
        return f"function: 0x{id(v):x}"
    return str(v)


def lua_type(v):
    v = first(v)
    if isnil(v):
        return "nil"
    if isinstance(v, bool):
        return "boolean"
    if isinstance(v, (int, float)):
        return "number"
    if isinstance(v, str):
        return "string"
    if isinstance(v, LuaTable):
        return "table"
    if callable(v):
        return "function"
    return type(v).__name__


class LuaTable:
    def __init__(self, init=None):
        self.d = {} if init is None else dict(init)

    def get(self, key):
        if isinstance(key, float) and key.is_integer():
            key = int(key)
        return self.d.get(key, NIL)

    def set(self, key, value):
        if isinstance(key, float) and key.is_integer():
            key = int(key)
        if isnil(value):
            self.d.pop(key, None)
        else:
            self.d[key] = value

    def length(self):
        i = 1
        while i in self.d:
            i += 1
        return i - 1


class Env:
    def __init__(self, parent=None):
        self.parent = parent
        self.vars = {}

    def root(self):
        e = self
        while e.parent:
            e = e.parent
        return e

    def define(self, name, value):
        self.vars[name] = value

    def get(self, name):
        if name in self.vars:
            return self.vars[name]
        if self.parent:
            return self.parent.get(name)
        return NIL

    def set(self, name, value):
        if name in self.vars:
            self.vars[name] = value
        elif self.parent and self.parent.contains(name):
            self.parent.set(name, value)
        else:
            self.root().vars[name] = value

    def contains(self, name):
        return name in self.vars or (self.parent and self.parent.contains(name))


KEYWORDS = {
    "and", "break", "do", "else", "elseif", "end", "false", "for", "function",
    "if", "in", "local", "nil", "not", "or", "repeat", "return", "then",
    "true", "until", "while",
}
MULTI = ["...", "==", "~=", "<=", ">=", "//", ".."]
SINGLE = set("+-*/%^#=<>;:,(){}[].")


class Token:
    def __init__(self, typ, val, line):
        self.typ, self.val, self.line = typ, val, line


def lex(src):
    out = []
    i = 0
    line = 1
    while i < len(src):
        c = src[i]
        if c in " \t\r":
            i += 1
            continue
        if c == "\n":
            line += 1
            i += 1
            continue
        if src.startswith("--", i):
            if src.startswith("--[[", i):
                j = src.find("]]", i + 4)
                chunk = src[i + 4: len(src) if j < 0 else j]
                line += chunk.count("\n")
                i = len(src) if j < 0 else j + 2
            else:
                j = src.find("\n", i)
                i = len(src) if j < 0 else j
            continue
        matched = False
        for op in MULTI:
            if src.startswith(op, i):
                out.append(Token(op, op, line))
                i += len(op)
                matched = True
                break
        if matched:
            continue
        if c in ("'", '"'):
            quote = c
            i += 1
            s = ""
            while i < len(src) and src[i] != quote:
                if src[i] == "\\" and i + 1 < len(src):
                    m = {"n": "\n", "t": "\t", "r": "\r", "\\": "\\", '"': '"', "'": "'"}
                    i += 1
                    s += m.get(src[i], src[i])
                else:
                    s += src[i]
                i += 1
            i += 1
            out.append(Token("string", s, line))
            continue
        if c.isdigit():
            j = i
            while j < len(src) and re.match(r"[0-9A-Fa-fxX.]", src[j]):
                j += 1
            text = src[i:j]
            val = float.fromhex(text) if text.lower().startswith("0x") and "." in text else int(text, 0) if re.fullmatch(r"0[xX][0-9a-fA-F]+|\d+", text) else float(text)
            out.append(Token("number", val, line))
            i = j
            continue
        if c.isalpha() or c == "_":
            j = i + 1
            while j < len(src) and (src[j].isalnum() or src[j] == "_"):
                j += 1
            word = src[i:j]
            out.append(Token(word if word in KEYWORDS else "name", word, line))
            i = j
            continue
        if c in SINGLE:
            out.append(Token(c, c, line))
            i += 1
            continue
        raise LuaError(f"unexpected symbol near '{c}'")
    out.append(Token("eof", "", line))
    return out


class Parser:
    def __init__(self, src):
        self.toks = lex(src)
        self.i = 0

    def peek(self, *types):
        return self.toks[self.i].typ in types

    def take(self, typ=None):
        t = self.toks[self.i]
        if typ and t.typ != typ:
            raise LuaError(f"expected {typ} near '{t.val}'")
        self.i += 1
        return t

    def parse(self):
        return ("block", self.block({"eof"}))

    def block(self, stops):
        stmts = []
        while not self.peek(*stops):
            if self.peek(";"):
                self.take()
            else:
                stmts.append(self.stmt())
        return stmts

    def stmt(self):
        if self.peek("local"):
            self.take()
            if self.peek("function"):
                self.take()
                name = self.take("name").val
                fn = self.funcbody()
                return ("local", [name], [fn])
            names = [self.take("name").val]
            while self.peek(","):
                self.take()
                names.append(self.take("name").val)
            vals = []
            if self.peek("="):
                self.take()
                vals = self.explist()
            return ("local", names, vals)
        if self.peek("function"):
            self.take()
            target = ("var", self.take("name").val)
            while self.peek("."):
                self.take()
                target = ("index", target, ("str", self.take("name").val))
            fn = self.funcbody()
            return ("assign", [target], [fn])
        if self.peek("return"):
            self.take()
            vals = [] if self.peek("end", "elseif", "else", "until", "eof", ";") else self.explist()
            return ("return", vals)
        if self.peek("break"):
            self.take()
            return ("break",)
        if self.peek("if"):
            return self.ifstmt()
        if self.peek("while"):
            self.take()
            cond = self.expr()
            self.take("do")
            body = self.block({"end"})
            self.take("end")
            return ("while", cond, body)
        if self.peek("repeat"):
            self.take()
            body = self.block({"until"})
            self.take("until")
            cond = self.expr()
            return ("repeat", body, cond)
        if self.peek("for"):
            self.take()
            name = self.take("name").val
            if self.peek(",", "in"):
                names = [name]
                while self.peek(","):
                    self.take()
                    names.append(self.take("name").val)
                self.take("in")
                generators = self.explist()
                self.take("do")
                body = self.block({"end"})
                self.take("end")
                return ("forgen", names, generators, body)
            self.take("=")
            start = self.expr(); self.take(","); stop = self.expr()
            step = ("num", 1)
            if self.peek(","):
                self.take(); step = self.expr()
            self.take("do")
            body = self.block({"end"})
            self.take("end")
            return ("fornum", name, start, stop, step, body)
        if self.peek("do"):
            self.take()
            body = self.block({"end"})
            self.take("end")
            return ("do", body)
        first = self.prefix()
        if self.peek("=", ","):
            vars_ = [first]
            while self.peek(","):
                self.take(); vars_.append(self.var())
            self.take("=")
            return ("assign", vars_, self.explist())
        return ("callstmt", first)

    def ifstmt(self):
        branches = []
        self.take("if")
        cond = self.expr(); self.take("then")
        branches.append((cond, self.block({"elseif", "else", "end"})))
        while self.peek("elseif"):
            self.take()
            cond = self.expr(); self.take("then")
            branches.append((cond, self.block({"elseif", "else", "end"})))
        else_body = []
        if self.peek("else"):
            self.take()
            else_body = self.block({"end"})
        self.take("end")
        return ("if", branches, else_body)

    def funcbody(self):
        self.take("(")
        params = []
        vararg = False
        if not self.peek(")"):
            if self.peek("..."):
                self.take(); vararg = True
            else:
                params.append(self.take("name").val)
                while self.peek(","):
                    self.take()
                    if self.peek("..."):
                        self.take(); vararg = True; break
                    params.append(self.take("name").val)
        self.take(")")
        body = self.block({"end"})
        self.take("end")
        return ("function", params, vararg, body)

    def explist(self):
        vals = [self.expr()]
        while self.peek(","):
            self.take(); vals.append(self.expr())
        return vals

    def expr(self, minp=0):
        left = self.unary()
        prec = {
            "or": (1, "L"), "and": (2, "L"), "==": (3, "L"), "~=": (3, "L"), "<": (3, "L"), ">": (3, "L"), "<=": (3, "L"), ">=": (3, "L"),
            "..": (4, "R"), "+": (5, "L"), "-": (5, "L"), "*": (6, "L"), "/": (6, "L"), "//": (6, "L"), "%": (6, "L"), "^": (8, "R"),
        }
        while self.toks[self.i].typ in prec and prec[self.toks[self.i].typ][0] >= minp:
            op = self.take().typ
            p, assoc = prec[op]
            right = self.expr(p + (1 if assoc == "L" else 0))
            left = ("bin", op, left, right)
        return left

    def unary(self):
        if self.peek("not", "-", "#"):
            op = self.take().typ
            return ("un", op, self.expr(7))
        return self.primary()

    def primary(self):
        if self.peek("nil"):
            self.take(); return ("nil",)
        if self.peek("true"):
            self.take(); return ("bool", True)
        if self.peek("false"):
            self.take(); return ("bool", False)
        if self.peek("number"):
            return ("num", self.take().val)
        if self.peek("string"):
            return ("str", self.take().val)
        if self.peek("function"):
            self.take(); return self.funcbody()
        if self.peek("{"):
            return self.table()
        if self.peek("..."):
            self.take(); return ("vararg",)
        return self.prefix()

    def prefix(self):
        if self.peek("name"):
            node = ("var", self.take().val)
        elif self.peek("("):
            self.take(); node = self.expr(); self.take(")")
        else:
            raise LuaError(f"unexpected symbol near '{self.toks[self.i].val}'")
        while True:
            if self.peek("."):
                self.take(); node = ("index", node, ("str", self.take("name").val))
            elif self.peek("["):
                self.take(); key = self.expr(); self.take("]"); node = ("index", node, key)
            elif self.peek("("):
                args = self.args(); node = ("call", node, args)
            elif self.peek(":"):
                self.take(); name = self.take("name").val; args = self.args(); node = ("method", node, name, args)
            else:
                return node

    def var(self):
        v = self.prefix()
        if v[0] not in ("var", "index"):
            raise LuaError("syntax error")
        return v

    def args(self):
        self.take("(")
        args = [] if self.peek(")") else self.explist()
        self.take(")")
        return args

    def table(self):
        self.take("{")
        fields = []
        while not self.peek("}"):
            if self.peek("["):
                self.take(); key = self.expr(); self.take("]"); self.take("="); val = self.expr(); fields.append((key, val))
            elif self.peek("name") and self.toks[self.i + 1].typ == "=":
                key = ("str", self.take().val); self.take("="); fields.append((key, self.expr()))
            else:
                fields.append((None, self.expr()))
            if self.peek(",", ";"):
                self.take()
            else:
                break
        self.take("}")
        return ("table", fields)


class LuaFunction:
    def __init__(self, params, vararg, body, env):
        self.params, self.vararg, self.body, self.env = params, vararg, body, env

    def __call__(self, interp, args):
        e = Env(self.env)
        for i, name in enumerate(self.params):
            e.define(name, args[i] if i < len(args) else NIL)
        e.define("...", args[len(self.params):])
        try:
            interp.exec_block(self.body, e)
        except ReturnSignal as r:
            return r.values
        return []


class Interpreter:
    def __init__(self):
        self.env = Env()
        self.install_stdlib()

    def install_stdlib(self):
        e = self.env
        e.define("_VERSION", "Lua 5.5")
        e.define("print", lambda *args: (print("\t".join(lua_str(x) for x in args)), None)[1])
        e.define("type", lambda *args: lua_type(args[0] if args else NIL))
        e.define("tostring", lambda *args: lua_str(args[0] if args else NIL))
        e.define("tonumber", lambda *args: float(args[0]) if args and str(args[0]).strip() else NIL)
        e.define("assert", lambda *args: list(args) if args and truthy(args[0]) else (_ for _ in ()).throw(LuaError(lua_str(args[1] if len(args) > 1 else "assertion failed!"))))
        e.define("ipairs", self.fn_ipairs)
        e.define("pairs", self.fn_pairs)
        e.define("select", self.fn_select)
        math_t = LuaTable({"abs": abs, "floor": math.floor, "ceil": math.ceil, "sqrt": math.sqrt, "sin": math.sin, "cos": math.cos, "max": max, "min": min, "pi": math.pi})
        string_t = LuaTable({"len": lambda s: len(str(s)), "upper": lambda s: str(s).upper(), "lower": lambda s: str(s).lower(), "sub": self.py_str_sub, "rep": lambda s, n: str(s) * int(n)})
        table_t = LuaTable({"concat": self.py_table_concat, "insert": self.py_table_insert, "remove": self.py_table_remove})
        utf8_t = LuaTable({"char": lambda *xs: "".join(chr(int(x)) for x in xs), "len": lambda s: len(str(s))})
        io_t = LuaTable({"write": self.py_io_write, "read": self.py_io_read})
        for name, tbl in [("math", math_t), ("string", string_t), ("table", table_t), ("utf8", utf8_t), ("io", io_t)]:
            e.define(name, tbl)
        e.define("require", lambda *args: e.get(str(args[0])))

    def fn_ipairs(self, *args):
        t = args[0]
        def iterator(tab, i):
            i = int(i)
            ni = i + 1
            v = tab.get(ni)
            return [] if isnil(v) else [ni, v]
        return [iterator, t, 0]

    def fn_pairs(self, *args):
        t = args[0]
        keys = list(t.d.keys())
        def iterator(tab, last=NIL):
            idx = -1 if isnil(last) else keys.index(last)
            if idx + 1 >= len(keys):
                return []
            k = keys[idx + 1]
            return [k, t.get(k)]
        return [iterator, t, NIL]

    def fn_select(self, *args):
        if args and args[0] == "#":
            return [len(args) - 1]
        return args[int(args[0]):]

    def py_str_sub(self, s, i, j=None):
        s = str(s); i = int(i); j = len(s) if j is None or isnil(j) else int(j)
        if i < 0: i = len(s) + i + 1
        if j < 0: j = len(s) + j + 1
        return s[max(i - 1, 0):j]

    def py_table_concat(self, t, sep="", i=1, j=None):
        j = t.length() if j is None or isnil(j) else int(j)
        return str(sep).join(lua_str(t.get(k)) for k in range(int(i), j + 1))

    def py_table_insert(self, t, *args):
        pos, val = (t.length() + 1, args[0]) if len(args) == 1 else (int(args[0]), args[1])
        for k in range(t.length() + 1, pos, -1):
            t.set(k, t.get(k - 1))
        t.set(pos, val)

    def py_table_remove(self, t, pos=None):
        pos = t.length() if pos is None or isnil(pos) else int(pos)
        val = t.get(pos)
        for k in range(pos, t.length()):
            t.set(k, t.get(k + 1))
        t.set(t.length(), NIL)
        return val

    def py_io_write(self, *args):
        sys.stdout.write("".join(lua_str(a) for a in args))
        sys.stdout.flush()

    def py_io_read(self, fmt="l"):
        if fmt in ("a", "*a"):
            data = sys.stdin.read()
            return data if data != "" else NIL
        line = sys.stdin.readline()
        if line == "":
            return NIL
        return line[:-1] if line.endswith("\n") else line

    def execute(self, src, args=None, script=None):
        if args is not None:
            argt = LuaTable({0: script or ""})
            for i, a in enumerate(args, 1):
                argt.set(i, a)
            self.env.define("arg", argt)
            self.env.define("...", args)
        ast = Parser(src).parse()
        self.exec_block(ast[1], self.env)

    def exec_block(self, stmts, env):
        for st in stmts:
            self.exec_stmt(st, env)

    def exec_stmt(self, st, env):
        kind = st[0]
        if kind == "local":
            vals = self.eval_list(st[2], env)
            for i, name in enumerate(st[1]):
                env.define(name, vals[i] if i < len(vals) else NIL)
        elif kind == "assign":
            vals = self.eval_list(st[2], env)
            for i, var in enumerate(st[1]):
                self.assign(var, vals[i] if i < len(vals) else NIL, env)
        elif kind == "callstmt":
            self.eval_expr(st[1], env)
        elif kind == "return":
            raise ReturnSignal(self.eval_list(st[1], env))
        elif kind == "break":
            raise BreakSignal()
        elif kind == "if":
            for cond, body in st[1]:
                if truthy(self.eval_expr(cond, env)):
                    self.exec_block(body, Env(env)); return
            self.exec_block(st[2], Env(env))
        elif kind == "while":
            while truthy(self.eval_expr(st[1], env)):
                try: self.exec_block(st[2], Env(env))
                except BreakSignal: break
        elif kind == "repeat":
            loop_env = Env(env)
            while True:
                try: self.exec_block(st[1], loop_env)
                except BreakSignal: break
                if truthy(self.eval_expr(st[2], loop_env)):
                    break
        elif kind == "fornum":
            start, stop, step = [lua_num(self.eval_expr(x, env)) for x in st[2:5]]
            i = start
            loop_env = Env(env)
            while (step >= 0 and i <= stop) or (step < 0 and i >= stop):
                loop_env.define(st[1], i)
                try: self.exec_block(st[5], loop_env)
                except BreakSignal: break
                i += step
        elif kind == "forgen":
            vals = self.eval_list(st[2], env)
            iterator = vals[0] if len(vals) > 0 else NIL
            state = vals[1] if len(vals) > 1 else NIL
            control = vals[2] if len(vals) > 2 else NIL
            loop_env = Env(env)
            while True:
                got = self.call(iterator, [state, control])
                if not got or isnil(got[0]):
                    break
                control = got[0]
                for i, name in enumerate(st[1]):
                    loop_env.define(name, got[i] if i < len(got) else NIL)
                try: self.exec_block(st[3], loop_env)
                except BreakSignal: break
        elif kind == "do":
            self.exec_block(st[1], Env(env))

    def eval_list(self, exprs, env):
        if not exprs:
            return []
        vals = []
        for idx, ex in enumerate(exprs):
            v = self.eval_expr(ex, env)
            if idx == len(exprs) - 1 and isinstance(v, list):
                vals.extend(v)
            else:
                vals.append(v[0] if isinstance(v, list) else v)
        return vals

    def eval_expr(self, ex, env):
        k = ex[0]
        if k == "nil": return NIL
        if k == "bool": return ex[1]
        if k == "num": return ex[1]
        if k == "str": return ex[1]
        if k == "var": return env.get(ex[1])
        if k == "vararg": return env.get("...")
        if k == "function": return LuaFunction(ex[1], ex[2], ex[3], env)
        if k == "table":
            t = LuaTable(); n = 1
            for key, val in ex[1]:
                v = self.eval_expr(val, env)
                if isinstance(v, list): v = v[0] if v else NIL
                if key is None:
                    t.set(n, v); n += 1
                else:
                    t.set(self.eval_expr(key, env), v)
            return t
        if k == "index":
            obj = first(self.eval_expr(ex[1], env)); key = first(self.eval_expr(ex[2], env))
            return obj.get(key) if isinstance(obj, LuaTable) else NIL
        if k == "call":
            fn = self.eval_expr(ex[1], env); args = self.eval_list(ex[2], env)
            return self.call(fn, args)
        if k == "method":
            obj = first(self.eval_expr(ex[1], env)); fn = obj.get(ex[2]) if isinstance(obj, LuaTable) else NIL
            return self.call(fn, [obj] + self.eval_list(ex[3], env))
        if k == "un":
            v = first(self.eval_expr(ex[2], env))
            if ex[1] == "not": return not truthy(v)
            if ex[1] == "-": return -lua_num(v)
            if ex[1] == "#": return v.length() if isinstance(v, LuaTable) else len(str(v))
        if k == "bin":
            op = ex[1]
            if op == "and":
                l = self.eval_expr(ex[2], env); return self.eval_expr(ex[3], env) if truthy(l) else l
            if op == "or":
                l = self.eval_expr(ex[2], env); return l if truthy(l) else self.eval_expr(ex[3], env)
            a = first(self.eval_expr(ex[2], env)); b = first(self.eval_expr(ex[3], env))
            if op == "+": return lua_num(a) + lua_num(b)
            if op == "-": return lua_num(a) - lua_num(b)
            if op == "*": return lua_num(a) * lua_num(b)
            if op == "/": return lua_num(a) / lua_num(b)
            if op == "//": return math.floor(lua_num(a) / lua_num(b))
            if op == "%": return lua_num(a) % lua_num(b)
            if op == "^": return lua_num(a) ** lua_num(b)
            if op == "..": return lua_str(a) + lua_str(b)
            if op == "==": return a == b
            if op == "~=": return a != b
            if op == "<": return a < b
            if op == ">": return a > b
            if op == "<=": return a <= b
            if op == ">=": return a >= b
        raise LuaError("internal error")

    def call(self, fn, args):
        if isinstance(fn, LuaFunction):
            return fn(self, args)
        if callable(fn):
            r = fn(*args)
            return [] if r is None else r if isinstance(r, list) else [r]
        raise LuaError(f"attempt to call a {lua_type(fn)} value")

    def assign(self, var, val, env):
        if var[0] == "var":
            env.set(var[1], val); return
        obj = self.eval_expr(var[1], env); key = self.eval_expr(var[2], env)
        if not isinstance(obj, LuaTable):
            raise LuaError("attempt to index a non-table value")
        obj.set(key, val)


USAGE = """usage: {prog} [options] [script [args]]
Available options are:
  -e stat   execute string 'stat'
  -i        enter interactive mode after executing 'script'
  -l mod    require library 'mod' into global 'mod'
  -l g=mod  require library 'mod' into global 'g'
  -v        show version information
  -E        ignore environment variables
  -W        turn warnings on
  --        stop handling options
  -         stop handling options and execute stdin
"""


def main(argv):
    prog = argv[0]
    chunks = []
    libs = []
    show_version = False
    script = None
    script_args = []
    i = 1
    while i < len(argv):
        a = argv[i]
        if a == "-v":
            show_version = True; i += 1
        elif a == "-E" or a == "-W" or a == "-i":
            i += 1
        elif a == "-e":
            if i + 1 >= len(argv):
                sys.stderr.write(f"{prog}: '-e' needs argument\n"); return 1
            chunks.append(argv[i + 1]); i += 2
        elif a.startswith("-e") and len(a) > 2:
            chunks.append(a[2:]); i += 1
        elif a == "-l":
            libs.append(argv[i + 1]); i += 2
        elif a.startswith("-l") and len(a) > 2:
            libs.append(a[2:]); i += 1
        elif a == "--":
            i += 1
            if i < len(argv): script, script_args = argv[i], argv[i + 1:]
            break
        elif a == "-":
            script, script_args = "-", argv[i + 1:]; break
        elif a.startswith("-"):
            sys.stderr.write(f"{prog}: unrecognized option '{a}'\n")
            sys.stderr.write(USAGE.format(prog=prog))
            return 1
        else:
            script, script_args = a, argv[i + 1:]; break
    if show_version:
        print(VERSION)
    interp = Interpreter()
    try:
        for lib in libs:
            name, mod = lib.split("=", 1) if "=" in lib else (lib, lib)
            interp.env.set(name, interp.env.get(mod))
        for chunk in chunks:
            interp.execute(chunk)
        if script:
            if script == "-":
                src = sys.stdin.read()
            else:
                with open(script, "r", encoding="utf-8") as fh:
                    src = fh.read()
            interp.execute(src, script_args, script)
        elif not chunks and not show_version:
            interp.execute(sys.stdin.read())
    except (LuaError, SyntaxError, OSError) as e:
        sys.stderr.write(f"{prog}: {e}\n")
        return 1
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv))
