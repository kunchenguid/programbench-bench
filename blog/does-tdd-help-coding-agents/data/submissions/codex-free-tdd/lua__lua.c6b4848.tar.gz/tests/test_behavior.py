import os
import subprocess
import tempfile
import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
EXE = ROOT / "executable"


def run_lua(*args, input_text=None):
    return subprocess.run(
        [str(EXE), *args],
        input=input_text,
        text=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
    )


class BehaviorTests(unittest.TestCase):
    def test_version_flag_prints_lua_551_banner(self):
        result = run_lua("-v")
        self.assertEqual(result.returncode, 0)
        self.assertEqual(result.stdout, "Lua 5.5.1  Copyright (C) 1994-2026 Lua.org, PUC-Rio\n")
        self.assertEqual(result.stderr, "")

    def test_unrecognized_long_help_matches_cli_contract(self):
        result = run_lua("--help")
        self.assertNotEqual(result.returncode, 0)
        self.assertEqual(result.stdout, "")
        self.assertIn("unrecognized option '--help'", result.stderr)
        self.assertIn("usage:", result.stderr)
        self.assertIn("-e stat", result.stderr)

    def test_executes_expression_tables_and_library_calls(self):
        result = run_lua(
            "-e",
            'a={10,20,x=5}; a.y=9; print(a[1], a[2], a.x, a["y"], #a); '
            'print(string.sub("hello",2,4), string.upper("ab")); '
            'print(table.concat({"a","b"}, ","))',
        )
        self.assertEqual(result.returncode, 0)
        self.assertEqual(result.stdout, "10\t20\t5\t9\t2\nell\tAB\na,b\n")
        self.assertEqual(result.stderr, "")

    def test_executes_control_flow_and_functions(self):
        program = """
function f(x)
  local sum = 0
  for i=1,x do
    if i % 2 == 0 then sum = sum + i end
  end
  return sum
end
print(f(6))
"""
        result = run_lua("-e", program)
        self.assertEqual(result.returncode, 0)
        self.assertEqual(result.stdout, "12\n")
        self.assertEqual(result.stderr, "")

    def test_runs_script_with_arg_table(self):
        with tempfile.NamedTemporaryFile("w", suffix=".lua", delete=False) as fh:
            fh.write('print(arg[0]); print(arg[1], arg[2]); print(...)\n')
            script = fh.name
        try:
            result = run_lua(script, "one", "two")
        finally:
            os.unlink(script)
        self.assertEqual(result.returncode, 0)
        self.assertEqual(result.stdout, f"{script}\none\ttwo\none\ttwo\n")
        self.assertEqual(result.stderr, "")

    def test_reads_stdin_when_dash_is_script(self):
        result = run_lua("-", input_text='print("stdin", 3+4)\n')
        self.assertEqual(result.returncode, 0)
        self.assertEqual(result.stdout, "stdin\t7\n")
        self.assertEqual(result.stderr, "")

    def test_executes_generic_for_and_repeat_until(self):
        program = """
t={3,4,5}
s=0
for i,v in ipairs(t) do
  s=s+i*v
end
i=0
repeat
  i=i+1
until i==3
print(s, i)
"""
        result = run_lua("-e", program)
        self.assertEqual(result.returncode, 0)
        self.assertEqual(result.stdout, "26\t3\n")
        self.assertEqual(result.stderr, "")

    def test_uses_first_return_value_in_scalar_context_and_io_write(self):
        program = 'function f() return 2,3 end print(f()+5); io.write("a", "b", 4, "\\n")'
        result = run_lua("-e", program)
        self.assertEqual(result.returncode, 0)
        self.assertEqual(result.stdout, "7\nab4\n")
        self.assertEqual(result.stderr, "")


if __name__ == "__main__":
    unittest.main()
