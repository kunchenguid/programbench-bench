#!/usr/bin/env python3
import os
import re
import subprocess
import sys
from dataclasses import dataclass


HELP = """Hush 0.1.4
gahag <gabriel.s.b@live.com>
Hush is a unix shell scripting language based on the Lua programming language

USAGE:
    executable [FLAGS] [arguments]...

FLAGS:
        --ast        Print the AST
        --check      Perform only static analysis instead of executing.
    -h, --help       Prints help information
        --lex        Print the lexemes
        --program    Print the PROGAM
    -V, --version    Prints version information

ARGS:
    <arguments>...    Script and/or arguments
"""


KEYWORDS = {
    "and", "do", "else", "end", "false", "for", "function", "if", "in",
    "let", "nil", "not", "or", "return", "then", "true", "while",
}


@dataclass
class Token:
    text: str
    line: int
    col: int
    kind: str = "sym"


class Lexer:
    def __init__(self, path, source):
        self.path = path
        self.source = source
        self.i = 0
        self.line = 1
        self.col = 0
        self.tokens = []
        self.errors = []

    def peek(self, n=0):
        j = self.i + n
        return self.source[j] if j < len(self.source) else ""

    def advance(self):
        ch = self.peek()
        self.i += 1
        if ch == "\n":
            self.line += 1
            self.col = 0
        else:
            self.col += 1
        return ch

    def error(self, line, col, msg):
        self.errors.append((line, col, msg))

    def lex_number(self):
        line, col = self.line, self.col
        start = self.i
        while self.peek().isdigit():
            self.advance()
        if self.peek() == "." and self.peek(1).isdigit():
            self.advance()
            while self.peek().isdigit():
                self.advance()
        if self.peek().lower() == "e":
            self.advance()
            if self.peek() in "+-":
                self.advance()
            while self.peek().isdigit():
                self.advance()
        raw = self.source[start:self.i]
        if "e" in raw.lower():
            val = float(raw)
            text = str(int(val)) if val.is_integer() else ("%f" % val).rstrip("0").rstrip(".")
        else:
            text = raw
        self.tokens.append(Token(text, line, col, "number"))

    def lex_word(self):
        line, col = self.line, self.col
        start = self.i
        while re.match(r"[A-Za-z0-9_-]", self.peek() or "\0"):
            self.advance()
        text = self.source[start:self.i]
        self.tokens.append(Token(text, line, col, "ident"))

    def lex_string(self):
        quote = self.peek()
        line, col = self.line, self.col
        raw = self.advance()
        out = quote
        valid = {"n", "0", "\\", "'", '"', "t", "r", "$"}
        while self.peek():
            ch = self.advance()
            raw += ch
            if ch == "\\":
                nxt_line, nxt_col = self.line, self.col - 1
                nxt = self.peek()
                if nxt:
                    raw += self.advance()
                    if nxt not in valid:
                        self.error(nxt_line, nxt_col, f"invalid escape sequence '\\{nxt}'.")
                        out += "\\0"
                    else:
                        out += "\\" + nxt
                continue
            if ch == quote:
                self.tokens.append(Token(out + quote, line, col, "string"))
                return
            out += ch
        self.error(line, col, "unterminated string")
        self.tokens.append(Token(out, line, col, "string"))

    def run(self):
        two = {"==", "!=", "<=", ">=", "++", ">>", "<<", "&&", "||", "2>", "1>"}
        one = set("()[]{}+-*/%=,.:;|<>@$?&")
        shell_depth = 0
        while self.peek():
            ch = self.peek()
            if ch.isspace():
                self.advance()
            elif ch == "#":
                while self.peek() and self.peek() != "\n":
                    self.advance()
            elif ch.isdigit():
                self.lex_number()
            elif re.match(r"[A-Za-z_]", ch):
                self.lex_word()
            elif ch in "'\"":
                self.lex_string()
            elif shell_depth and ch not in "{};|<>'\" \t\r\n":
                line, col = self.line, self.col
                start = self.i
                while self.peek() and self.peek() not in "{};|<>'\" \t\r\n":
                    self.advance()
                self.tokens.append(Token(self.source[start:self.i], line, col, "ident"))
            elif self.source[self.i:self.i + 2] in two:
                self.tokens.append(Token(self.source[self.i:self.i + 2], self.line, self.col))
                self.advance()
                self.advance()
            elif ch in one:
                if shell_depth == 0 and ch in {"|", ";", "}"}:
                    line, col = self.line, self.col
                    self.error(line, col, f"unexpected '{ch}'.")
                if shell_depth == 0 and ch == "@" and self.peek(1) != "[":
                    line, col = self.line, self.col
                    self.error(line, col, "unexpected '@'.")
                if ch == "$" and self.peek(1) not in "{":
                    line, col = self.line, self.col
                    self.error(line, col, "unexpected '$'.")
                self.tokens.append(Token(ch, self.line, self.col))
                if ch == "{":
                    shell_depth += 1
                elif ch == "}" and shell_depth:
                    shell_depth -= 1
                self.advance()
            else:
                line, col = self.line, self.col
                self.error(line, col, f"unexpected '{ch}'.")
                self.advance()
        return self.tokens, self.errors


class Parser:
    def __init__(self, tokens):
        self.toks = tokens
        self.i = 0
        self.declared = []
        self.errors = []
        self.stmts = []

    def tok(self, n=0):
        j = self.i + n
        return self.toks[j] if j < len(self.toks) else Token("", 10**9, 0)

    def eat(self, text=None):
        t = self.tok()
        if text is None or t.text == text:
            self.i += 1
            return t
        return None

    def at_end(self):
        return self.i >= len(self.toks)

    def line_end(self, line):
        return self.at_end() or self.tok().line != line or self.tok().text in {";", "end", "else", ")", "]", "}"}

    def parse(self):
        while not self.at_end():
            if self.tok().text in {"end", "else", "}"}:
                self.i += 1
                continue
            if self.tok().text == ";":
                self.i += 1
                continue
            st = self.statement()
            if st:
                self.stmts.append(st)
            else:
                self.i += 1
        self.static_check()
        return self.stmts

    def statement(self):
        t = self.tok()
        if t.text == "let":
            return self.let_statement()
        if t.text == "function" and self.tok(1).kind == "ident":
            return self.named_function()
        if t.text == "return":
            self.eat()
            return {"type": "return", "expr": self.expr_until_line(t.line)}
        if t.text == "{":
            return self.shell_block()
        if t.kind == "ident" and self.tok(1).text == "=":
            name = self.eat().text
            self.eat("=")
            return {"type": "assign", "name": name, "expr": self.expr_until_line(t.line)}
        return {"type": "expr", "expr": self.expr_until_line(t.line)}

    def let_statement(self):
        start = self.eat("let")
        name_tok = self.eat()
        if not name_tok or name_tok.kind != "ident":
            got = name_tok.text if name_tok else ""
            self.errors.append((start.line, start.col + 4, f"unexpected '{got}', expected identifier"))
            name = "***ill-formed***"
        else:
            name = name_tok.text
            if name not in self.declared:
                self.declared.append(name)
        expr = "nil"
        if self.eat("="):
            expr = self.expr_until_line(start.line)
        return {"type": "let", "name": name, "expr": expr}

    def named_function(self):
        start = self.eat("function")
        name = self.eat().text
        if name not in self.declared:
            self.declared.append(name)
        params = self.collect_balanced("(", ")")
        body = []
        while not self.at_end() and self.tok().text != "end":
            st = self.statement()
            if st:
                body.append(st)
        self.eat("end")
        return {"type": "let", "name": name, "expr": f"function({params})", "body": body, "func": True, "line": start.line}

    def shell_block(self):
        self.eat("{")
        parts = []
        depth = 1
        while not self.at_end() and depth:
            t = self.eat()
            if t.text == "{":
                depth += 1
            elif t.text == "}":
                depth -= 1
                if depth == 0:
                    break
            parts.append(t)
        return {"type": "shell", "tokens": parts}

    def expr_until_line(self, line):
        start = self.i
        depth = 0
        while not self.at_end():
            t = self.tok()
            if depth == 0 and (t.text == ";" or (t.line != line and t.text not in {"else", "end"})):
                break
            if depth == 0 and t.text in {"else", "end", "}"}:
                break
            if t.text in {"(", "[", "{", "$", "@", "if", "function"}:
                depth += 1
            elif t.text in {")", "]", "}", "end"} and depth:
                depth -= 1
            self.i += 1
        return format_expr(self.toks[start:self.i])

    def collect_balanced(self, l, r):
        if not self.eat(l):
            return ""
        parts = []
        depth = 1
        while not self.at_end() and depth:
            t = self.eat()
            if t.text == l:
                depth += 1
            elif t.text == r:
                depth -= 1
                if depth == 0:
                    break
            parts.append(t.text)
        return ", ".join([p for p in parts if p != ","])

    def static_check(self):
        declared = set(self.declared) | {"std", "self", "_", "args"}
        for st in self.stmts:
            self.check_stmt(st, declared)

    def check_stmt(self, st, declared):
        if st["type"] in {"let", "assign"}:
            if st["type"] == "assign" and st["name"] not in declared:
                self.errors.append((0, 0, f"undeclared variable '{st['name']}'"))
            self.check_expr(st.get("expr", ""), declared)
            for child in st.get("body", []):
                self.check_stmt(child, declared | set(self.declared))
        elif st["type"] in {"expr", "return"}:
            self.check_expr(st.get("expr", ""), declared)

    def check_expr(self, expr, declared):
        if "@[" in expr or expr.startswith("function(") or "${" in expr:
            return
        for m in re.finditer(r"(?<![.#])\b[A-Za-z_][A-Za-z0-9_]*\b", expr):
            name = m.group(0)
            if name not in KEYWORDS and name not in declared and not is_string_position(expr, m.start()):
                self.errors.append((0, 0, f"undeclared variable '{name}'"))


def is_string_position(s, pos):
    quote = None
    esc = False
    for i, ch in enumerate(s[:pos]):
        if esc:
            esc = False
        elif ch == "\\":
            esc = True
        elif ch in "'\"":
            quote = None if quote == ch else (ch if quote is None else quote)
    return quote is not None


def format_expr(tokens):
    if not tokens:
        return "nil"
    p = ExprParser(tokens)
    return p.parse()


class ExprParser:
    BP = {"or": 1, "and": 2, "==": 3, "!=": 3, "<": 4, ">": 4, "<=": 4, ">=": 4,
          "++": 5, "+": 5, "-": 5, "*": 6, "/": 6, "%": 6}

    def __init__(self, tokens):
        self.toks = tokens
        self.i = 0

    def tok(self):
        return self.toks[self.i] if self.i < len(self.toks) else Token("", 0, 0)

    def eat(self):
        t = self.tok()
        self.i += 1
        return t

    def parse(self, min_bp=0):
        left = self.prefix()
        while self.i < len(self.toks):
            op = self.tok().text
            if op == "[":
                self.eat()
                inner = []
                d = 1
                while self.i < len(self.toks) and d:
                    t = self.eat()
                    if t.text == "[":
                        d += 1
                    elif t.text == "]":
                        d -= 1
                        if d == 0:
                            break
                    inner.append(t)
                left = f"{left}[{format_expr(inner)}]"
                continue
            if op == "(":
                args = self.collect("(", ")")
                left = f"{left}({args})"
                continue
            if op not in self.BP or self.BP[op] < min_bp:
                break
            bp = self.BP[op]
            self.eat()
            right = self.parse(bp + 1)
            left = f"({left} {op} {right})"
        return left

    def prefix(self):
        t = self.eat()
        if t.text == "(":
            inner = self.collect_from_open("(", ")")
            formatted = format_expr(inner)
            if formatted.startswith("if "):
                return formatted
            return f"({formatted})"
        if t.text == "[":
            return format_array(self.collect_from_open("[", "]"))
        if t.text == "@":
            if self.tok().text == "[":
                self.eat()
                return "@[" + format_object(self.collect_from_open("[", "]")) + "]"
            return "@"
        if t.text == "if":
            return self.parse_if()
        if t.text == "function":
            params = self.collect("(", ")")
            body = []
            while self.i < len(self.toks) and self.tok().text != "end":
                body.append(self.eat().text)
            if self.i < len(self.toks):
                self.eat()
            return f"function({params}) " + " ".join(body) + " end"
        if t.text in {"not", "-"}:
            return f"{t.text} {self.parse(7)}"
        return t.text

    def parse_if(self):
        cond = []
        while self.i < len(self.toks) and self.tok().text != "then":
            cond.append(self.eat())
        if self.i < len(self.toks):
            self.eat()
        yes = []
        while self.i < len(self.toks) and self.tok().text != "else":
            yes.append(self.eat())
        if self.i < len(self.toks):
            self.eat()
        no = []
        while self.i < len(self.toks) and self.tok().text != "end":
            no.append(self.eat())
        if self.i < len(self.toks):
            self.eat()
        return f"if {format_expr(cond)} then {format_expr(yes)} else {format_expr(no)} end"

    def collect(self, l, r):
        if self.tok().text != l:
            return ""
        self.eat()
        return format_call_args(self.collect_from_open(l, r))

    def collect_from_open(self, l, r):
        parts = []
        depth = 1
        while self.i < len(self.toks) and depth:
            t = self.eat()
            if t.text == l:
                depth += 1
            elif t.text == r:
                depth -= 1
                if depth == 0:
                    break
            parts.append(t)
        return parts


def split_commas(tokens):
    result, cur, depth = [], [], 0
    for t in tokens:
        if t.text in {"(", "["}:
            depth += 1
        elif t.text in {")", "]"}:
            depth -= 1
        if t.text == "," and depth == 0:
            result.append(cur)
            cur = []
        else:
            cur.append(t)
    if cur:
        result.append(cur)
    return result


def format_call_args(tokens):
    return ", ".join(format_expr(part) for part in split_commas(tokens))


def format_array(tokens):
    parts = split_commas(tokens)
    if len(parts) <= 2 and sum(len(p) for p in parts) <= 4:
        return "[ " + ", ".join(format_expr(p) for p in parts) + " ]"
    return "[\n\t" + ",\n\t".join(format_expr(p) for p in parts) + "\n]"


def format_object(tokens):
    return " ".join(t.text for t in tokens)


def stmt_ast(st):
    if st["type"] == "let":
        if st.get("func"):
            lines = [f"let {st['name']} = {st['expr']}"]
            lines.extend("\t" + stmt_ast(s).replace("\n", "\n\t") for s in st.get("body", []))
            lines.append("end")
            return "\n".join(lines)
        return f"let {st['name']} = {st['expr']}"
    if st["type"] == "assign":
        return f"{st['name']} = {st['expr']}"
    if st["type"] == "return":
        return f"return {st['expr']}"
    if st["type"] == "shell":
        return "{\n\t" + format_shell(st["tokens"]) + "\n}"
    return st.get("expr", "")


def format_shell(tokens):
    commands, cur = [], []
    for t in tokens:
        if t.text == ";":
            if cur:
                commands.append(cur)
                cur = []
        else:
            cur.append(t.text)
    if cur:
        commands.append(cur)
    rendered = []
    for cmd in commands:
        rendered.append(" ".join(("|" if w == "|" else quote_word(w)) for w in cmd))
    return "\n\t".join(rendered)


def quote_word(w):
    if w in {"|", ">", "<", ">>", "<<", "2>", "1>"}:
        return w
    if (w.startswith("'") and w.endswith("'")) or (w.startswith('"') and w.endswith('"')):
        return w
    return '"' + w.replace('"', '\\"') + '"'


def program_lines(stmts):
    names = {}
    decls = ["let #0: auto"]
    body = []
    next_id = 1
    for st in stmts:
        if st["type"] == "let":
            if st["name"] not in names and st["name"] != "***ill-formed***":
                names[st["name"]] = f"#{next_id}"
                next_id += 1
                decls.append(f"let {names[st['name']]}: auto")
            lhs = names.get(st["name"], st["name"])
            body.append(f"{lhs} = {replace_names(st['expr'], names)}")
        elif st["type"] == "assign":
            body.append(f"{names.get(st['name'], st['name'])} = {replace_names(st['expr'], names)}")
        elif st["type"] == "shell":
            body.append("{\n\t" + format_shell(st["tokens"]) + "\n}")
        elif st["type"] == "return":
            body.append("return " + replace_names(st["expr"], names))
        else:
            body.append(replace_names(st.get("expr", ""), names))
    return decls + body


def replace_names(expr, names):
    def repl(m):
        name = m.group(0)
        return names.get(name, name)
    return re.sub(r"(?<![.#])\b[A-Za-z_][A-Za-z0-9_]*\b", repl, expr)


def print_errors(path, errors, parser_errors=None):
    parser_errors = parser_errors or []
    for line, col, msg in errors:
        print(f"Error: {path} (line {line}, column {col}) - {msg}")
    for line, col, msg in parser_errors:
        if line:
            print(f"Error: {path} (line {line}, column {col}) - {msg}")
        else:
            print(f"Error: {path} (line 1, column 0) - {msg}")


def run_shell(tokens):
    text = " ".join(t.text for t in tokens)
    text = text.replace(" ;", ";").replace("|", "|")
    return subprocess.run(text, shell=True).returncode


def main(argv):
    if not argv:
        return 0
    if argv[0] in {"--help", "-h"}:
        print(HELP, end="")
        return 0
    if argv[0] in {"--version", "-V"}:
        print("Hush 0.1.4")
        return 0
    flags = []
    while argv and argv[0].startswith("-"):
        flags.append(argv.pop(0))
    if not argv:
        return 0
    path = argv[0]
    try:
        with open(path, "r", encoding="utf-8") as f:
            source = f.read()
    except OSError as e:
        print(f"Error: {e}", file=sys.stderr)
        return 2
    tokens, lex_errors = Lexer(path, source).run()
    parser = Parser(tokens)
    stmts = parser.parse()
    if lex_errors:
        print_errors(path, lex_errors)
    mode = flags[-1] if flags else None
    if mode == "--lex":
        print("-" * 50)
        for t in tokens:
            print(f"{path} (line {t.line}, column {t.col}):\t{t.text}")
        print("-" * 50)
    elif mode == "--ast":
        print("-" * 50)
        print(f"AST for {path}")
        for st in stmts:
            print(stmt_ast(st))
        print("-" * 50)
    elif mode == "--program":
        if not lex_errors and not parser.errors:
            print("-" * 50)
            print(f"Program for {path}")
            print("\n".join(program_lines(stmts)))
            print("-" * 50)
    if parser.errors:
        print_errors(path, [], parser.errors)
    if lex_errors or parser.errors:
        return 2
    if mode == "--check":
        return 0
    status = 0
    for st in stmts:
        if st["type"] == "shell":
            rc = run_shell(st["tokens"])
            if rc:
                status = rc
    return status


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
