import os
import subprocess
import sys
import tempfile
import textwrap
import unittest


ROOT = os.path.dirname(os.path.dirname(__file__))
HUSH = os.path.join(ROOT, "src", "hush.py")


def run_hush(source, *args):
    with tempfile.NamedTemporaryFile("w", suffix=".hsh", delete=False) as f:
        f.write(textwrap.dedent(source).lstrip())
        path = f.name
    try:
        return subprocess.run(
            [sys.executable, HUSH, *args, path],
            text=True,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            check=False,
        )
    finally:
        os.unlink(path)


class HushBehavior(unittest.TestCase):
    def test_help_matches_reference_header_and_flags(self):
        result = subprocess.run(
            [sys.executable, HUSH, "--help"],
            text=True,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            check=False,
        )
        self.assertEqual(result.returncode, 0)
        self.assertIn("Hush 0.1.4", result.stdout)
        self.assertIn("--ast        Print the AST", result.stdout)
        self.assertIn("<arguments>...    Script and/or arguments", result.stdout)

    def test_lex_formats_positions_and_numbers(self):
        result = run_hush(
            """
            let var = 123 + 456.7 + 89e10 + 1.2e3
            """,
            "--lex",
        )
        self.assertEqual(result.returncode, 0)
        self.assertIn("(line 1, column 0):\tlet", result.stdout)
        self.assertIn("(line 1, column 24):\t890000000000", result.stdout)
        self.assertIn("(line 1, column 32):\t1200", result.stdout)

    def test_ast_for_variables_matches_reference_shape(self):
        result = run_hush(
            """
            let var
            let another_var = (if true then ['a'] else ['b'] end)[0]
            var = 5 * if false then 0 else 1 end + 7
            """,
            "--ast",
        )
        self.assertEqual(result.returncode, 0)
        self.assertIn("let var = nil", result.stdout)
        self.assertIn("let another_var = if true then [ 'a' ] else [ 'b' ] end[0]", result.stdout)
        self.assertIn("var = ((5 * if false then 0 else 1 end) + 7)", result.stdout)

    def test_program_renames_declared_variables(self):
        result = run_hush(
            """
            let y
            let x = 2
            x = x + 3
            x
            """,
            "--program",
        )
        self.assertEqual(result.returncode, 0)
        self.assertIn("let #0: auto", result.stdout)
        self.assertLess(result.stdout.index("let #2: auto"), result.stdout.index("#1 = nil"))
        self.assertIn("#2 = 2", result.stdout)
        self.assertIn("#2 = (#2 + 3)", result.stdout)

    def test_shell_block_executes_pipeline(self):
        result = run_hush("{ echo hi | tr a-z A-Z; }\n")
        self.assertEqual(result.returncode, 0)
        self.assertEqual(result.stdout, "HI\n")

    def test_undeclared_variables_are_reported(self):
        result = run_hush("print 123\n")
        self.assertEqual(result.returncode, 2)
        self.assertIn("undeclared variable 'print'", result.stdout)

    def test_function_parameters_and_object_fields_do_not_fail_static_check(self):
        result = run_hush(
            """
            function(array, cmp)
                let heap = @[
                    _data: array,
                    _cmp: cmp,
                    size: function ()
                        std.len(self._data)
                    end,
                ]
                heap
            end
            """,
            "--check",
        )
        self.assertEqual(result.returncode, 0, result.stdout)

    def test_shell_words_and_command_substitution_lex_without_errors(self):
        result = run_hush(
            """
            {
              ls ~/;
              echo $args "even when \\$ quoted";
            }
            let output = ${ echo hi }
            """,
            "--check",
        )
        self.assertEqual(result.returncode, 0, result.stdout)

    def test_invalid_escape_reports_backslash_column(self):
        result = run_hush("let var = '\\?'\n", "--lex")
        self.assertEqual(result.returncode, 2)
        self.assertIn("(line 1, column 11) - invalid escape sequence '\\?'.", result.stdout)

    def test_invalid_tokens_report_shell_only_tokens_outside_blocks(self):
        result = run_hush("function f() | let $x = 1; return @}x end\n", "--check")
        self.assertEqual(result.returncode, 2)
        self.assertIn("unexpected '|'", result.stdout)
        self.assertIn("unexpected '$'", result.stdout)
        self.assertIn("unexpected ';'", result.stdout)
        self.assertIn("unexpected '@'", result.stdout)
        self.assertIn("unexpected '}'", result.stdout)


if __name__ == "__main__":
    unittest.main()
