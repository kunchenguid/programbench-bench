#!/usr/bin/env python3
import json
import os
import re
import sys


VERSION = "ethabi-cli 18.0.0"

HELP = {
    ("encode",): """executable-encode 18.0.0
Encode ABI call

USAGE:
    executable encode <SUBCOMMAND>

FLAGS:
    -h, --help       Prints help information
    -V, --version    Prints version information

SUBCOMMANDS:
    function    Load function from JSON ABI file
    help        Prints this message or the help of the given subcommand(s)
    params      Specify types of input params inline""",
    ("encode", "params"): """executable-encode-params 18.0.0
Specify types of input params inline

USAGE:
    executable encode params [FLAGS] [OPTIONS]

FLAGS:
    -h, --help       
            Prints help information

    -l, --lenient    
            Allow short representation of input params (numbers are in decimal form)

    -V, --version    
            Prints version information


OPTIONS:
    -v <type-or-param> <type-or-param>        
            Pairs of types directly followed by params in the form:
            
            -v <type1> <param1> -v <type2> <param2> ...""",
    ("encode", "function"): """executable-encode-function 18.0.0
Load function from JSON ABI file

USAGE:
    executable encode function [FLAGS] [OPTIONS] <abi-path> <function-name-or-signature>

FLAGS:
    -h, --help       Prints help information
    -l, --lenient    Allow short representation of input params
    -V, --version    Prints version information

OPTIONS:
    -p <params>...        

ARGS:
    <abi-path>                      
    <function-name-or-signature>    """,
    ("decode",): """executable-decode 18.0.0
Decode ABI call result

USAGE:
    executable decode <SUBCOMMAND>

FLAGS:
    -h, --help       Prints help information
    -V, --version    Prints version information

SUBCOMMANDS:
    function    Load function from JSON ABI file
    help        Prints this message or the help of the given subcommand(s)
    log         Decode event log
    params      Specify types of input params inline""",
    ("decode", "params"): """executable-decode-params 18.0.0
Specify types of input params inline

USAGE:
    executable decode params [OPTIONS] <data>

FLAGS:
    -h, --help       Prints help information
    -V, --version    Prints version information

OPTIONS:
    -t <type>...        

ARGS:
    <data>    """,
    ("decode", "function"): """executable-decode-function 18.0.0
Load function from JSON ABI file

USAGE:
    executable decode function <abi-path> <function-name-or-signature> <data>

FLAGS:
    -h, --help       Prints help information
    -V, --version    Prints version information

ARGS:
    <abi-path>                      
    <function-name-or-signature>    
    <data>                          """,
    ("decode", "log"): """executable-decode-log 18.0.0
Decode event log

USAGE:
    executable decode log [OPTIONS] <abi-path> <event-name-or-signature> <data>

FLAGS:
    -h, --help       Prints help information
    -V, --version    Prints version information

OPTIONS:
    -l <topic>...        

ARGS:
    <abi-path>                   
    <event-name-or-signature>    
    <data>                       """,
}


ROT = [
    [0, 36, 3, 41, 18],
    [1, 44, 10, 45, 2],
    [62, 6, 43, 15, 61],
    [28, 55, 25, 21, 56],
    [27, 20, 39, 8, 14],
]
RC = [
    0x0000000000000001, 0x0000000000008082, 0x800000000000808A,
    0x8000000080008000, 0x000000000000808B, 0x0000000080000001,
    0x8000000080008081, 0x8000000000008009, 0x000000000000008A,
    0x0000000000000088, 0x0000000080008009, 0x000000008000000A,
    0x000000008000808B, 0x800000000000008B, 0x8000000000008089,
    0x8000000000008003, 0x8000000000008002, 0x8000000000000080,
    0x000000000000800A, 0x800000008000000A, 0x8000000080008081,
    0x8000000000008080, 0x0000000080000001, 0x8000000080008008,
]


def rol(x, n):
    return ((x << n) | (x >> (64 - n))) & ((1 << 64) - 1)


def keccak_f(st):
    for rc in RC:
        c = [st[x] ^ st[x + 5] ^ st[x + 10] ^ st[x + 15] ^ st[x + 20] for x in range(5)]
        d = [c[(x - 1) % 5] ^ rol(c[(x + 1) % 5], 1) for x in range(5)]
        for x in range(5):
            for y in range(5):
                st[x + 5 * y] ^= d[x]
        b = [0] * 25
        for x in range(5):
            for y in range(5):
                b[y + 5 * ((2 * x + 3 * y) % 5)] = rol(st[x + 5 * y], ROT[x][y])
        for x in range(5):
            for y in range(5):
                st[x + 5 * y] = b[x + 5 * y] ^ ((~b[((x + 1) % 5) + 5 * y]) & b[((x + 2) % 5) + 5 * y])
        st[0] ^= rc


def keccak256(data):
    rate = 136
    st = [0] * 25
    block = bytearray(data)
    block.append(0x01)
    while len(block) % rate != rate - 1:
        block.append(0)
    block.append(0x80)
    for off in range(0, len(block), rate):
        chunk = block[off:off + rate]
        for i in range(rate // 8):
            st[i] ^= int.from_bytes(chunk[i * 8:i * 8 + 8], "little")
        keccak_f(st)
    out = bytearray()
    while len(out) < 32:
        for i in range(rate // 8):
            out += st[i].to_bytes(8, "little")
        if len(out) < 32:
            keccak_f(st)
    return bytes(out[:32])


class AbiError(Exception):
    pass


class Typ:
    def __init__(self, base, sub=None, bits=None, size=None, dims=None):
        self.base = base
        self.sub = sub
        self.bits = bits
        self.size = size
        self.dims = dims or []

    def __str__(self):
        if self.base == "array":
            s = str(self.sub)
            for d in self.dims:
                s += "[]" if d is None else f"[{d}]"
            return s
        if self.base in ("uint", "int"):
            return f"{self.base}{self.bits}"
        if self.base == "bytes_fixed":
            return f"bytes{self.size}"
        return self.base


def parse_type(s):
    dims = []
    while s.endswith("]"):
        i = s.rfind("[")
        if i < 0:
            raise AbiError("Invalid type")
        raw = s[i + 1:-1]
        dims.insert(0, None if raw == "" else int(raw))
        s = s[:i]
    if s in ("uint", "int"):
        t = Typ(s, bits=256)
    elif re.fullmatch(r"uint([0-9]+)", s):
        t = Typ("uint", bits=int(s[4:]))
    elif re.fullmatch(r"int([0-9]+)", s):
        t = Typ("int", bits=int(s[3:]))
    elif re.fullmatch(r"bytes([0-9]+)", s):
        t = Typ("bytes_fixed", size=int(s[5:]))
    elif s in ("bool", "address", "string", "bytes"):
        t = Typ(s)
    else:
        raise AbiError("Invalid type")
    if dims:
        return Typ("array", sub=t, dims=dims)
    return t


def is_dynamic(t):
    if t.base in ("string", "bytes"):
        return True
    if t.base == "array":
        if t.dims[-1] is None:
            return True
        return is_dynamic(Typ("array", sub=t.sub, dims=t.dims[:-1])) if len(t.dims) > 1 else is_dynamic(t.sub)
    return False


def word(n):
    return n.to_bytes(32, "big", signed=False)


def pad32(b):
    return b + b"\x00" * ((32 - len(b) % 32) % 32)


def clean_hex(s):
    return s[2:] if s.startswith(("0x", "0X")) else s


def hex_bytes(s):
    h = clean_hex(s)
    if len(h) % 2:
        raise AbiError(f"Hex parsing error: Odd number of digits\n\nCaused by:\n    Odd number of digits")
    try:
        return bytes.fromhex(h)
    except ValueError as e:
        msg = str(e)
        m = re.search(r"position ([0-9]+)", msg)
        pos = m.group(1) if m else "0"
        ch = h[int(pos)] if pos.isdigit() and int(pos) < len(h) else ""
        raise AbiError(f"Hex parsing error: Invalid character '{ch}' at position {pos}\n\nCaused by:\n    Invalid character '{ch}' at position {pos}")


def split_array(s):
    s = s.strip()
    if not (s.startswith("[") and s.endswith("]")):
        raise AbiError("Invalid data")
    body = s[1:-1].strip()
    if not body:
        return []
    vals, cur, depth = [], [], 0
    for ch in body:
        if ch == "[":
            depth += 1
        elif ch == "]":
            depth -= 1
        if ch == "," and depth == 0:
            vals.append("".join(cur).strip())
            cur = []
        else:
            cur.append(ch)
    vals.append("".join(cur).strip())
    return vals


def parse_value(t, s, lenient=False):
    if t.base == "array":
        vals = split_array(s)
        n = t.dims[-1]
        if n is not None and len(vals) != n:
            raise AbiError("Invalid data")
        et = t.sub if len(t.dims) == 1 else Typ("array", sub=t.sub, dims=t.dims[:-1])
        return [parse_value(et, v, lenient) for v in vals]
    if t.base == "bool":
        if s in ("true", "1"):
            return True
        if s in ("false", "0"):
            return False
        raise AbiError("Invalid data")
    if t.base == "address":
        b = hex_bytes(s)
        if len(b) != 20:
            raise AbiError("Invalid data")
        return b
    if t.base == "uint":
        if lenient:
            n = int(s, 10)
        else:
            b = hex_bytes(s)
            if len(b) != 32:
                raise AbiError("Invalid data")
            n = int.from_bytes(b, "big")
        if n < 0 or n >= (1 << t.bits):
            raise AbiError("Invalid data")
        return n
    if t.base == "int":
        if lenient:
            n = int(s, 10)
        else:
            b = hex_bytes(s)
            if len(b) != 32:
                raise AbiError("Invalid data")
            n = int.from_bytes(b, "big")
            if n >= (1 << (t.bits - 1)):
                n -= 1 << t.bits
        if n < -(1 << (t.bits - 1)) or n >= (1 << (t.bits - 1)):
            raise AbiError("Invalid data")
        return n
    if t.base == "string":
        return s.encode()
    if t.base == "bytes":
        return hex_bytes(s)
    if t.base == "bytes_fixed":
        b = hex_bytes(s)
        if len(b) != t.size:
            raise AbiError("Invalid data")
        return b
    raise AbiError("Invalid data")


def encode_single(t, v):
    if t.base == "bool":
        return word(1 if v else 0)
    if t.base == "address":
        return b"\x00" * 12 + v
    if t.base == "uint":
        return word(v)
    if t.base == "int":
        return word(v if v >= 0 else (1 << t.bits) + v)
    if t.base == "bytes_fixed":
        return v + b"\x00" * (32 - len(v))
    if t.base in ("string", "bytes"):
        return word(len(v)) + pad32(v)
    if t.base == "array":
        et = t.sub if len(t.dims) == 1 else Typ("array", sub=t.sub, dims=t.dims[:-1])
        body = encode_params([et] * len(v), v)
        return (word(len(v)) if t.dims[-1] is None else b"") + body
    raise AbiError("Invalid data")


def encode_params(types, values):
    head, tail = [], b""
    offset = 32 * len(types)
    for t, v in zip(types, values):
        enc = encode_single(t, v)
        if is_dynamic(t):
            head.append(word(offset + len(tail)))
            tail += enc
        else:
            head.append(enc)
    return b"".join(head) + tail


def read_word(data, off):
    if off + 32 > len(data):
        raise AbiError("Invalid data")
    return int.from_bytes(data[off:off + 32], "big")


def decode_single(t, data, off):
    if t.base == "bool":
        return read_word(data, off) != 0, off + 32
    if t.base == "address":
        if off + 32 > len(data):
            raise AbiError("Invalid data")
        return data[off + 12:off + 32], off + 32
    if t.base == "uint":
        return read_word(data, off), off + 32
    if t.base == "int":
        n = read_word(data, off)
        if n >= (1 << (t.bits - 1)):
            n -= 1 << t.bits
        return n, off + 32
    if t.base == "bytes_fixed":
        if off + 32 > len(data):
            raise AbiError("Invalid data")
        return data[off:off + t.size], off + 32
    if t.base in ("string", "bytes"):
        n = read_word(data, off)
        start = off + 32
        end = start + n
        if end > len(data):
            raise AbiError("Invalid data")
        return data[start:end], start + ((n + 31) // 32) * 32
    if t.base == "array":
        et = t.sub if len(t.dims) == 1 else Typ("array", sub=t.sub, dims=t.dims[:-1])
        if t.dims[-1] is None:
            n = read_word(data, off)
            base = off + 32
        else:
            n = t.dims[-1]
            base = off
        vals = decode_params([et] * n, data[base:])
        return vals, base + 32 * n
    raise AbiError("Invalid data")


def decode_params(types, data):
    vals = []
    for i, t in enumerate(types):
        off = 32 * i
        if is_dynamic(t):
            off = read_word(data, off)
        v, _ = decode_single(t, data, off)
        vals.append(v)
    return vals


def format_value(t, v):
    if t.base == "bool":
        return "true" if v else "false"
    if t.base in ("uint", "int"):
        return str(v) if t.base == "uint" else (hex((1 << t.bits) + v)[2:].rjust(64, "f") if v < 0 else str(v))
    if t.base == "address":
        return v.hex()
    if t.base in ("bytes", "bytes_fixed"):
        return v.hex()
    if t.base == "string":
        return v.decode(errors="replace")
    if t.base == "array":
        et = t.sub if len(t.dims) == 1 else Typ("array", sub=t.sub, dims=t.dims[:-1])
        return "[" + ",".join(format_value(et, x) for x in v) + "]"
    return str(v)


def load_abi(path):
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)


def find_item(abi, kind, name):
    for item in abi:
        if item.get("type") == kind and item.get("name") == name:
            return item
    raise AbiError(f"{kind} `{name}` not found")


def canonical_outputs(fn):
    outs = fn.get("outputs", [])
    return "(" + ",".join(o["type"] for o in outs) + ")"


def function_signature(fn):
    return fn["name"] + "(" + ",".join(i["type"] for i in fn.get("inputs", [])) + ")"


def function_full_signature(fn):
    return function_signature(fn) + (":" + canonical_outputs(fn) if fn.get("outputs") else "")


def find_function(abi, query):
    funcs = [x for x in abi if x.get("type") == "function"]
    if "(" in query:
        for fn in funcs:
            if function_full_signature(fn) == query:
                return fn
        raise AbiError(f"invalid function signature `{query}`")
    matches = [fn for fn in funcs if fn.get("name") == query]
    if len(matches) == 1:
        return matches[0]
    if len(matches) > 1:
        raise AbiError(f"More than one function found for name `{query}`, try providing the full signature")
    raise AbiError(f"function `{query}` not found")


def event_signature(ev):
    return ev["name"] + "(" + ",".join(i["type"] for i in ev.get("inputs", [])) + ")"


def print_help(args):
    if args == []:
        print(f"""{VERSION}
Ethereum ABI coder

USAGE:
    executable <SUBCOMMAND>

FLAGS:
    -h, --help       Prints help information
    -V, --version    Prints version information

SUBCOMMANDS:
    decode    Decode ABI call result
    encode    Encode ABI call
    help      Prints this message or the help of the given subcommand(s)""")
        return True
    return False


def parse_pairs(args, flag):
    out = []
    i = 0
    while i < len(args):
        if args[i] == flag:
            if i + 2 >= len(args):
                raise AbiError(f"error: The argument '{flag}' requires 2 values, but 1 was provided")
            out.append((args[i + 1], args[i + 2]))
            i += 3
        else:
            i += 1
    return out


def encode_params_cmd(args):
    lenient = "-l" in args or "--lenient" in args
    pairs = parse_pairs(args, "-v")
    types = [parse_type(t) for t, _ in pairs]
    vals = [parse_value(t, v, lenient) for t, (_, v) in zip(types, pairs)]
    print(encode_params(types, vals).hex())


def encode_function_cmd(args):
    lenient = False
    params = []
    clean = []
    i = 0
    while i < len(args):
        if args[i] in ("-l", "--lenient"):
            lenient = True
            i += 1
        elif args[i] == "-p":
            params.append(args[i + 1])
            i += 2
        else:
            clean.append(args[i])
            i += 1
    if len(clean) != 2:
        raise AbiError("Invalid arguments")
    abi = load_abi(clean[0])
    fn = find_function(abi, clean[1])
    types = [parse_type(x["type"]) for x in fn.get("inputs", [])]
    vals = [parse_value(t, p, lenient) for t, p in zip(types, params)]
    sel = keccak256(function_signature(fn).encode())[:4]
    print((sel + encode_params(types, vals)).hex())


def decode_params_cmd(args):
    types = []
    clean = []
    i = 0
    while i < len(args):
        if args[i] == "-t":
            types.append(parse_type(args[i + 1]))
            i += 2
        else:
            clean.append(args[i])
            i += 1
    if len(clean) != 1:
        raise AbiError("Invalid arguments")
    vals = decode_params(types, hex_bytes(clean[0]))
    for t, v in zip(types, vals):
        print(f"{t} {format_value(t, v)}")


def decode_function_cmd(args):
    if len(args) != 3:
        raise AbiError("Invalid arguments")
    abi = load_abi(args[0])
    fn = find_function(abi, args[1])
    types = [parse_type(x["type"]) for x in fn.get("outputs", [])]
    vals = decode_params(types, hex_bytes(args[2]))
    for t, v in zip(types, vals):
        print(f"{t} {format_value(t, v)}")


def decode_log_cmd(args):
    topics = []
    clean = []
    i = 0
    while i < len(args):
        if args[i] == "-l":
            topics.append(hex_bytes(args[i + 1]))
            i += 2
        else:
            clean.append(args[i])
            i += 1
    if len(clean) != 3:
        raise AbiError("Invalid arguments")
    abi = load_abi(clean[0])
    ev = find_item(abi, "event", clean[1])
    if not ev.get("anonymous", False):
        if not topics or topics[0] != keccak256(event_signature(ev).encode()):
            raise AbiError("Invalid data")
        topics = topics[1:]
    data = hex_bytes(clean[2])
    data_inputs = [x for x in ev.get("inputs", []) if not x.get("indexed", False)]
    data_types = [parse_type(x["type"]) for x in data_inputs]
    data_vals = decode_params(data_types, data) if data_types else []
    data_iter = iter(data_vals)
    topic_iter = iter(topics)
    for item in ev.get("inputs", []):
        t = parse_type(item["type"])
        if item.get("indexed", False):
            topic = next(topic_iter)
            if is_dynamic(t):
                val_text = topic.hex()
            else:
                val, _ = decode_single(t, topic, 0)
                val_text = format_value(t, val)
        else:
            val_text = format_value(t, next(data_iter))
        print(f"{item.get('name', '')} {val_text}")


def main(argv):
    if argv in (["--version"], ["-V"]):
        print(VERSION)
        return 0
    if argv in ([], ["--help"], ["-h"], ["help"]):
        print_help([])
        return 0
    if len(argv) >= 1 and argv[-1] in ("--help", "-h"):
        key = tuple(argv[:-1])
        if key in HELP:
            print(HELP[key])
            return 0
    if len(argv) == 1 and argv[0] in ("encode", "decode"):
        print(HELP[(argv[0],)], file=sys.stderr)
        return 1
    try:
        if argv[:2] == ["encode", "params"]:
            if "--version" in argv or "-V" in argv:
                print("executable-encode-params 18.0.0")
            else:
                encode_params_cmd(argv[2:])
            return 0
        if argv[:2] == ["encode", "function"]:
            encode_function_cmd(argv[2:])
            return 0
        if argv[:2] == ["decode", "params"]:
            decode_params_cmd(argv[2:])
            return 0
        if argv[:2] == ["decode", "function"]:
            decode_function_cmd(argv[2:])
            return 0
        if argv[:2] == ["decode", "log"]:
            decode_log_cmd(argv[2:])
            return 0
        raise AbiError(f"error: Found argument '{argv[0]}' which wasn't expected, or isn't valid in this context")
    except (AbiError, ValueError, IndexError, FileNotFoundError) as e:
        print(f"Error: {e}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
