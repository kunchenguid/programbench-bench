import os
import subprocess
import sys
import unittest


ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
BIN = os.environ.get("TARGET_BIN", os.path.join(ROOT, "src", "ethabi_py.py"))


def run_cmd(*args):
    if BIN.endswith(".py"):
        cmd = [sys.executable, BIN, *args]
    else:
        cmd = [BIN, *args]
    return subprocess.run(cmd, text=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)


class CliTests(unittest.TestCase):
    def assert_ok(self, args, stdout):
        proc = run_cmd(*args)
        self.assertEqual(proc.returncode, 0, proc.stderr)
        self.assertEqual(proc.stdout, stdout)

    def test_help_and_version_match_cli_shape(self):
        proc = run_cmd("--help")
        self.assertEqual(proc.returncode, 0)
        self.assertIn("ethabi-cli 18.0.0", proc.stdout)
        self.assertIn("SUBCOMMANDS:", proc.stdout)
        self.assertEqual(run_cmd("--version").stdout, "ethabi-cli 18.0.0\n")

    def test_encode_params_help_includes_flags_and_pair_option(self):
        proc = run_cmd("encode", "params", "--help")
        self.assertEqual(proc.returncode, 0, proc.stderr)
        self.assertIn("USAGE:\n    executable encode params [FLAGS] [OPTIONS]", proc.stdout)
        self.assertIn("-l, --lenient", proc.stdout)
        self.assertIn("-v <type-or-param> <type-or-param>", proc.stdout)

    def test_missing_nested_subcommand_prints_help_but_fails(self):
        proc = run_cmd("encode")
        self.assertEqual(proc.returncode, 1)
        self.assertIn("USAGE:\n    executable encode <SUBCOMMAND>", proc.stderr)

    def test_encode_primitive_params(self):
        self.assert_ok(
            ["encode", "params", "-v", "bool", "1"],
            "0000000000000000000000000000000000000000000000000000000000000001\n",
        )
        self.assert_ok(
            ["encode", "params", "-l", "-v", "uint256", "5"],
            "0000000000000000000000000000000000000000000000000000000000000005\n",
        )
        self.assert_ok(
            ["encode", "params", "-l", "-v", "int256", "-1"],
            "ffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff\n",
        )
        self.assert_ok(
            ["encode", "params", "-v", "address", "0000000000000000000000000000000000000001"],
            "0000000000000000000000000000000000000000000000000000000000000001\n",
        )

    def test_encode_dynamic_and_array_params(self):
        self.assert_ok(
            ["encode", "params", "-v", "string", "example"],
            "0000000000000000000000000000000000000000000000000000000000000020"
            "0000000000000000000000000000000000000000000000000000000000000007"
            "6578616d706c6500000000000000000000000000000000000000000000000000\n",
        )
        self.assert_ok(
            ["encode", "params", "-v", "bytes3", "abcdef"],
            "abcdef0000000000000000000000000000000000000000000000000000000000\n",
        )
        self.assert_ok(
            ["encode", "params", "-v", "address[]", "[0000000000000000000000000000000000000001,0000000000000000000000000000000000000002]"],
            "0000000000000000000000000000000000000000000000000000000000000020"
            "0000000000000000000000000000000000000000000000000000000000000002"
            "0000000000000000000000000000000000000000000000000000000000000001"
            "0000000000000000000000000000000000000000000000000000000000000002\n",
        )

    def test_decode_params(self):
        self.assert_ok(
            ["decode", "params", "-t", "bool", "0000000000000000000000000000000000000000000000000000000000000001"],
            "bool true\n",
        )
        self.assert_ok(
            ["decode", "params", "-t", "address[]", "0000000000000000000000000000000000000000000000000000000000000020000000000000000000000000000000000000000000000000000000000000000200000000000000000000000000000000000000000000000000000000000000010000000000000000000000000000000000000000000000000000000000000002"],
            "address[] [0000000000000000000000000000000000000001,0000000000000000000000000000000000000002]\n",
        )

    def test_encode_and_decode_function_from_abi(self):
        abi = os.path.join(ROOT, "assets", "foo.abi")
        self.assert_ok(
            ["encode", "function", abi, "bar", "-p", "0000000000000000000000000000000000000001"],
            "646ea56d0000000000000000000000000000000000000000000000000000000000000001\n",
        )
        self.assert_ok(
            ["decode", "function", abi, "bar", "0000000000000000000000000000000000000000000000000000000000000001"],
            "bool true\n",
        )

    def test_function_lookup_accepts_full_signature_for_overloads(self):
        abi = os.path.join(ROOT, "tests", "overloaded.abi")
        self.assert_ok(
            ["encode", "function", abi, "foo(uint256)", "-l", "-p", "1"],
            "2fbebd380000000000000000000000000000000000000000000000000000000000000001\n",
        )
        self.assert_ok(
            ["encode", "function", os.path.join(ROOT, "assets", "foo.abi"), "bar(address):(bool)", "-p", "0000000000000000000000000000000000000001"],
            "646ea56d0000000000000000000000000000000000000000000000000000000000000001\n",
        )

    def test_decode_event_log_outputs_named_fields(self):
        abi = os.path.join(ROOT, "tests", "event.abi")
        proc = run_cmd(
            "decode",
            "log",
            abi,
            "Ev",
            "-l",
            "3e91596d258ecd21b1a3170f02fc25e0ae12145639df6595a981be8e4bc41ea4",
            "-l",
            "0000000000000000000000000000000000000000000000000000000000000001",
            "0000000000000000000000000000000000000000000000000000000000000005",
        )
        self.assertEqual(proc.returncode, 0, proc.stderr)
        self.assertEqual(proc.stdout, "a 5\nb 0000000000000000000000000000000000000001\n")


if __name__ == "__main__":
    unittest.main()
