#!/usr/bin/env python3
import getopt
import os
import select
import shutil
import signal
import stat
import sys
import time


USAGE = """usage : tty-clock [-iuvsScbtrahDBxn] [-C [0-7]] [-f format] [-d delay] [-a nsdelay] [-T tty] 
    -s            Show seconds                                   
    -S            Screensaver mode                               
    -x            Show box                                       
    -c            Set the clock at the center of the terminal    
    -C [0-7]      Set the clock color                            
    -b            Use bold colors                                
    -t            Set the hour in 12h format                     
    -u            Use UTC time                                   
    -T tty        Display the clock on the specified terminal    
    -r            Do rebound the clock                           
    -f format     Set the date format                            
    -n            Don't quit on keypress                         
    -v            Show tty-clock version                         
    -i            Show some info about tty-clock                 
    -h            Show this page                                 
    -D            Hide date                                      
    -B            Enable blinking colon                          
    -d delay      Set the delay between two redraws of the clock. Default 1s. 
    -a nsdelay    Additional delay between two redraws in nanoseconds. Default 0ns.
"""


DIGITS = {
    "0": ["111", "101", "101", "101", "111"],
    "1": ["010", "110", "010", "010", "111"],
    "2": ["111", "001", "111", "100", "111"],
    "3": ["111", "001", "111", "001", "111"],
    "4": ["101", "101", "111", "001", "001"],
    "5": ["111", "100", "111", "001", "111"],
    "6": ["111", "100", "111", "101", "111"],
    "7": ["111", "001", "001", "001", "001"],
    "8": ["111", "101", "111", "101", "111"],
    "9": ["111", "101", "111", "001", "111"],
}


class Config:
    def __init__(self):
        self.seconds = False
        self.screensaver = False
        self.box = False
        self.center = False
        self.color = 2
        self.bold = False
        self.twelve = False
        self.utc = False
        self.tty = None
        self.rebound = False
        self.date_format = "%F"
        self.no_quit = False
        self.hide_date = False
        self.blink = False
        self.delay = 1.0
        self.nsdelay = 0


def print_usage():
    sys.stdout.write(USAGE)


def parse_args(argv):
    cfg = Config()
    try:
        opts, _ = getopt.getopt(argv, "iuvsScC:btrf:nxhDBd:a:T:")
    except getopt.GetoptError as exc:
        message = str(exc)
        if "requires argument" in message and message.startswith("option -"):
            opt = message[len("option -") : len("option -") + 1]
            message = f"option requires an argument -- '{opt}'"
        elif message.startswith("option --"):
            message = "invalid option -- '-'"
        sys.stderr.write(f"./executable: {message}\n")
        print_usage()
        raise SystemExit(0)

    for opt, arg in opts:
        if opt == "-h":
            print_usage()
            raise SystemExit(0)
        if opt == "-v":
            sys.stdout.write("TTY-Clock 2 \u00a9 devel version\n")
            raise SystemExit(0)
        if opt == "-i":
            sys.stdout.write(
                "TTY-Clock 2 \u00a9 by Martin Duquesnoy (xorg62@gmail.com), Grey (grey@greytheory.net)\n"
            )
            raise SystemExit(0)
        if opt == "-s":
            cfg.seconds = True
        elif opt == "-S":
            cfg.screensaver = True
        elif opt == "-x":
            cfg.box = True
        elif opt == "-c":
            cfg.center = True
        elif opt == "-C":
            try:
                color = int(arg)
            except ValueError:
                color = -1
            if 0 <= color <= 7:
                cfg.color = color
        elif opt == "-b":
            cfg.bold = True
        elif opt == "-t":
            cfg.twelve = True
        elif opt == "-u":
            cfg.utc = True
        elif opt == "-T":
            cfg.tty = arg
        elif opt == "-r":
            cfg.rebound = True
        elif opt == "-f":
            cfg.date_format = arg
        elif opt == "-n":
            cfg.no_quit = True
        elif opt == "-D":
            cfg.hide_date = True
        elif opt == "-B":
            cfg.blink = True
        elif opt == "-d":
            cfg.delay = parse_float(arg, 1.0)
        elif opt == "-a":
            cfg.nsdelay = parse_int(arg, 0)
    return cfg


def parse_float(value, default):
    try:
        return max(0.0, float(value))
    except ValueError:
        return default


def parse_int(value, default):
    try:
        return max(0, int(value))
    except ValueError:
        return default


def validate_tty(path):
    if path is None:
        return None
    try:
        st = os.stat(path)
    except OSError as exc:
        sys.stderr.write(f"tty-clock: error: couldn't stat '{path}': {exc.strerror}.\n")
        raise SystemExit(1)
    if not stat.S_ISCHR(st.st_mode):
        sys.stderr.write(f"tty-clock: error: '{path}' is not a character device.\n")
        raise SystemExit(1)
    try:
        return open(path, "w", buffering=1)
    except OSError as exc:
        sys.stderr.write(f"tty-clock: error: couldn't open '{path}': {exc.strerror}.\n")
        raise SystemExit(1)


def now_tuple(cfg):
    return time.gmtime() if cfg.utc else time.localtime()


def clock_text(cfg, t):
    fmt = "%I:%M" if cfg.twelve else "%H:%M"
    if cfg.seconds:
        fmt += ":%S"
    return time.strftime(fmt, t)


def matrix_for(text, blink_colon=False):
    rows = ["" for _ in range(5)]
    for ch in text:
        if ch.isdigit():
            pattern = DIGITS[ch]
            for i, row in enumerate(pattern):
                rows[i] += "".join("##" if bit == "1" else "  " for bit in row) + " "
        elif ch == ":":
            colon = [" ", "1", " ", "1", " "] if not blink_colon else [" ", " ", " ", " ", " "]
            for i, bit in enumerate(colon):
                rows[i] += ("##" if bit == "1" else "  ") + " "
        else:
            for i in range(5):
                rows[i] += "   "
    return rows


def draw_segment(out, y, x, width, color, bold=False):
    if width <= 0:
        return
    prefix = "\033(B\033[0;5m" if bold else ""
    out.write(f"\033[{y};{x}H{prefix}\033[{40 + color}m{' ' * width}\033[49m\033(B\033[m")


def render_clock(out, cfg, frame):
    term = shutil.get_terminal_size((80, 24))
    t = now_tuple(cfg)
    text = clock_text(cfg, t)
    blink_colon = cfg.blink and frame % 2 == 1
    rows = matrix_for(text, blink_colon)
    width = len(rows[0])
    height = 5 + (0 if cfg.hide_date else 2)
    y = 2
    x = 2
    if cfg.center or cfg.screensaver:
        y = max(1, (term.lines - height) // 2)
        x = max(1, (term.columns - width) // 2)
    if cfg.rebound:
        x = 2 + (frame % max(1, term.columns - width - 3))

    out.write("\033[H\033[2J")
    if cfg.box:
        box_w = width + 4
        box_h = height + 2
        out.write(f"\033[{y};{x}H\033(0l{'q' * max(0, box_w - 2)}k\033(B")
        for row in range(1, box_h - 1):
            out.write(f"\033[{y + row};{x}H\033(0x\033(B\033[{y + row};{x + box_w - 1}H\033(0x\033(B")
        out.write(f"\033[{y + box_h - 1};{x}H\033(0m{'q' * max(0, box_w - 2)}j\033(B")
        y += 2
        x += 2

    for row_index, row in enumerate(rows):
        start = None
        for idx, _ in enumerate(row + " "):
            active = idx < len(row) and row[idx] == "#"
            # Matrix spaces are drawn in runs for a block-like look; leave every
            # third separator blank so individual digits stay readable.
            if idx < len(row) and idx % 7 == 6:
                active = False
            if active and start is None:
                start = idx
            if (not active) and start is not None:
                draw_segment(out, y + row_index, x + start, idx - start, cfg.color, cfg.bold)
                start = None

    if not cfg.hide_date:
        date_text = time.strftime(cfg.date_format, t)
        date_x = x + max(0, (width - len(date_text)) // 2)
        out.write(f"\033[{y + 6};{date_x}H\033[3{cfg.color}m{date_text}\033[39m\033(B\033[m")
    out.flush()


def setup_terminal(out):
    out.write("\033[?1049h\033[22;0;0t\033[1;24r\033(B\033[m\033[4l\033[?7h")
    out.write("\033[?1h\033=\033[39;49m\033[?25l\033[39;49m\033(B\033[m")
    out.flush()


def restore_terminal(out):
    out.write("\033[39;49m\033(B\033[m\033[?25h\033[?1049l")
    out.flush()


running = True


def stop(_signum, _frame):
    raise SystemExit(0)


def main(argv):
    global running
    cfg = parse_args(argv)
    out = validate_tty(cfg.tty) or sys.stdout
    signal.signal(signal.SIGTERM, stop)
    signal.signal(signal.SIGINT, stop)
    setup_terminal(out)
    frame = 0
    try:
        while running:
            render_clock(out, cfg, frame)
            frame += 1
            if sys.stdin in select.select([sys.stdin], [], [], 0)[0]:
                ch = sys.stdin.read(1)
                if cfg.screensaver and not cfg.no_quit:
                    break
                if ch.lower() == "q" and not cfg.no_quit:
                    break
            time.sleep(cfg.delay + cfg.nsdelay / 1_000_000_000.0)
    finally:
        restore_terminal(out)
        if out is not sys.stdout:
            out.close()
    return 0


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
