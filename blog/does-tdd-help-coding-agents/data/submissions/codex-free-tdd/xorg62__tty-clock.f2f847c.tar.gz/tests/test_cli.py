import os
import subprocess
import unittest
import importlib.util


ROOT = os.path.dirname(os.path.dirname(__file__))
PROGRAM = os.path.join(ROOT, "src", "tty_clock.py")


def run_cmd(args, timeout=1.0, env=None):
    merged_env = os.environ.copy()
    merged_env.update({"TERM": "xterm", "TZ": "UTC"})
    if env:
        merged_env.update(env)
    return subprocess.run(
        ["python3", PROGRAM] + args,
        cwd=ROOT,
        text=False,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        timeout=timeout,
        env=merged_env,
    )


def run_with_timeout(args, duration="0.15s", timeout=1.0):
    merged_env = os.environ.copy()
    merged_env.update({"TERM": "xterm", "TZ": "UTC"})
    return subprocess.run(
        ["timeout", duration, "python3", PROGRAM] + args,
        cwd=ROOT,
        text=False,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        timeout=timeout,
        env=merged_env,
    )


class TtyClockCliTests(unittest.TestCase):
    def test_digit_matrix_preserves_segment_gaps(self):
        spec = importlib.util.spec_from_file_location("tty_clock", PROGRAM)
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)
        rows = module.matrix_for("12")
        self.assertEqual(len(rows), 5)
        self.assertIn("##", rows[0])
        self.assertIn("  ", rows[1])
        self.assertNotEqual(rows[0], rows[1])

    def test_help_matches_documented_usage(self):
        result = run_cmd(["-h"])
        self.assertEqual(result.returncode, 0)
        text = result.stdout.decode("utf-8")
        self.assertIn("usage : tty-clock [-iuvsScbtrahDBxn]", text)
        self.assertIn("-C [0-7]      Set the clock color", text)
        self.assertIn("-a nsdelay    Additional delay", text)
        self.assertEqual(result.stderr, b"")

    def test_long_help_is_reported_as_invalid_dash_like_original(self):
        result = run_cmd(["--help"])
        self.assertEqual(result.returncode, 0)
        self.assertIn("invalid option -- '-'", result.stderr.decode("utf-8"))
        self.assertIn("usage : tty-clock", result.stdout.decode("utf-8"))

    def test_version_and_info_are_exact(self):
        version = run_cmd(["-v"])
        info = run_cmd(["-i"])
        self.assertEqual(version.stdout.decode("utf-8"), "TTY-Clock 2 \u00a9 devel version\n")
        self.assertEqual(
            info.stdout.decode("utf-8"),
            "TTY-Clock 2 \u00a9 by Martin Duquesnoy (xorg62@gmail.com), Grey (grey@greytheory.net)\n",
        )

    def test_missing_argument_reports_getopt_style_error_then_usage(self):
        result = run_cmd(["-d"])
        self.assertEqual(result.returncode, 0)
        self.assertIn("option requires an argument -- 'd'", result.stderr.decode("utf-8"))
        self.assertIn("usage : tty-clock", result.stdout.decode("utf-8"))

    def test_missing_tty_reports_stat_error(self):
        result = run_cmd(["-T", "/no/such"])
        self.assertEqual(result.returncode, 1)
        self.assertEqual(result.stdout, b"")
        self.assertIn("couldn't stat '/no/such'", result.stderr.decode("utf-8"))

    def test_short_render_contains_terminal_setup_color_blocks_and_date(self):
        result = run_with_timeout(["-s", "-x", "-f", "%Y-%m-%d", "-d", "1"])
        out = result.stdout
        self.assertIn(b"\x1b[?1049h", out)
        self.assertIn(b"\x1b[H\x1b[2J", out)
        self.assertIn(b"\x1b[42m", out)
        self.assertIn(b"2026-06-05", out)
        self.assertGreaterEqual(out.count(b"\x1b["), 20)


if __name__ == "__main__":
    unittest.main()
