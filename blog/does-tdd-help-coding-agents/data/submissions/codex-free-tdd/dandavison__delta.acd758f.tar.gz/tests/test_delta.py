import os
import subprocess
import sys
import tempfile
import unittest


ROOT = os.path.dirname(os.path.dirname(__file__))
DELTA = os.path.join(ROOT, "src", "delta.py")


def run_delta(*args, input_text=""):
    return subprocess.run(
        [sys.executable, DELTA, *args],
        input=input_text,
        text=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
    )


class DeltaCliTests(unittest.TestCase):
    def test_version_prints_delta_version(self):
        result = run_delta("--version")

        self.assertEqual(result.returncode, 0)
        self.assertEqual(result.stdout, "delta 0.18.2\n")
        self.assertEqual(result.stderr, "")

    def test_help_prints_usage_and_core_options(self):
        result = run_delta("--help")

        self.assertEqual(result.returncode, 0)
        self.assertTrue(result.stdout.startswith("A viewer for git and diff output\n\nUsage: delta [OPTIONS] [MINUS_FILE] [PLUS_FILE]\n"))
        self.assertIn("--color-only", result.stdout)
        self.assertIn("--paging <auto|always|never>", result.stdout)
        self.assertIn("-V, --version", result.stdout)
        self.assertEqual(result.stderr, "")

    def test_plain_stdin_is_copied_to_stdout(self):
        result = run_delta("--no-gitconfig", "--paging=never", input_text="hello\nworld\n")

        self.assertEqual(result.returncode, 0)
        self.assertEqual(result.stdout, "hello\nworld\n")
        self.assertEqual(result.stderr, "")

    def test_color_only_keeps_diff_shape_and_colors_changed_lines(self):
        diff = "\n".join([
            "--- a/a.txt",
            "+++ b/a.txt",
            "@@ -1,2 +1,2 @@",
            "-old",
            "+new",
            " same",
            "",
        ])

        result = run_delta("--color-only", "--paging=never", input_text=diff)

        self.assertEqual(result.returncode, 0)
        self.assertIn("--- a/a.txt\n+++ b/a.txt\n@@ -1,2 +1,2 @@\n", result.stdout)
        self.assertIn("\x1b[31m-old\x1b[0m\n", result.stdout)
        self.assertIn("\x1b[32m+new\x1b[0m\n", result.stdout)
        self.assertTrue(result.stdout.endswith(" same\n"))
        self.assertEqual(result.stderr, "")

    def test_two_file_arguments_emit_a_diff(self):
        with tempfile.TemporaryDirectory() as tmp:
            left = os.path.join(tmp, "left.txt")
            right = os.path.join(tmp, "right.txt")
            with open(left, "w", encoding="utf-8") as f:
                f.write("a\nb\n")
            with open(right, "w", encoding="utf-8") as f:
                f.write("a\nc\n")

            result = run_delta("--raw", "--paging=never", left, right)

        self.assertEqual(result.returncode, 0)
        self.assertIn("diff --git", result.stdout)
        self.assertIn("--- a/", result.stdout)
        self.assertIn("+++ b/", result.stdout)
        self.assertIn("\x1b[31m-b\x1b[0m\n", result.stdout)
        self.assertIn("\x1b[32m+c\x1b[0m\n", result.stdout)
        self.assertEqual(result.stderr, "")

    def test_list_languages_prints_known_language_names(self):
        result = run_delta("--list-languages")

        self.assertEqual(result.returncode, 0)
        self.assertIn("Python", result.stdout)
        self.assertIn("Rust", result.stdout)
        self.assertIn("JavaScript", result.stdout)
        self.assertEqual(result.stderr, "")

    def test_generate_bash_completion_prints_delta_function(self):
        result = run_delta("--generate-completion", "bash")

        self.assertEqual(result.returncode, 0)
        self.assertIn("_delta()", result.stdout)
        self.assertIn("complete -F _delta", result.stdout)
        self.assertEqual(result.stderr, "")


if __name__ == "__main__":
    unittest.main()
