#!/usr/bin/env python3

import difflib
import os
import sys
from pathlib import Path


RED = "\033[31m"
GREEN = "\033[32m"
CYAN = "\033[36m"
BOLD = "\033[1m"
RESET = "\033[0m"
RESET_M = "\033[m"


def colorize_diff(text, *, raw=False, color_only=False):
    output = []
    for line in text.splitlines(keepends=True):
        body = line[:-1] if line.endswith("\n") else line
        end = "\n" if line.endswith("\n") else ""
        if body.startswith("--- ") or body.startswith("+++ "):
            if raw and not color_only:
                output.append(f"{BOLD}{body}{RESET_M}{end}")
            else:
                output.append(line)
        elif body.startswith("@@"):
            if raw and not color_only:
                output.append(f"{CYAN}{body}{RESET_M}{end}")
            else:
                output.append(line)
        elif body.startswith("-"):
            output.append(f"{RED}{body}{RESET}{end}")
        elif body.startswith("+"):
            output.append(f"{GREEN}{body}{RESET}{end}")
        else:
            output.append(line)
    return "".join(output)


OPTIONS_WITH_VALUE = {
    "--config",
    "--paging",
    "--pager",
    "--width",
    "--syntax-theme",
    "--true-color",
    "--24-bit-color",
    "--diff-args",
    "-@",
}


def positional_args(argv):
    out = []
    i = 0
    while i < len(argv):
        arg = argv[i]
        if arg == "--":
            out.extend(argv[i + 1 :])
            break
        if arg in OPTIONS_WITH_VALUE:
            i += 2
            continue
        if any(arg.startswith(opt + "=") for opt in OPTIONS_WITH_VALUE):
            i += 1
            continue
        if arg.startswith("-"):
            i += 1
            continue
        out.append(arg)
        i += 1
    return out


def gitish_diff(left_path, right_path):
    left = Path(left_path)
    right = Path(right_path)
    left_lines = left.read_text(errors="replace").splitlines(keepends=True)
    right_lines = right.read_text(errors="replace").splitlines(keepends=True)
    left_label = "a/" + left.as_posix().lstrip("/")
    right_label = "b/" + right.as_posix().lstrip("/")
    lines = [f"diff --git {left_label} {right_label}\n"]
    lines.extend(
        difflib.unified_diff(
            left_lines,
            right_lines,
            fromfile=left_label,
            tofile=right_label,
            lineterm="",
        )
    )
    normalized = []
    for line in lines:
        normalized.append(line if line.endswith("\n") else line + "\n")
    return "".join(normalized)


LANGUAGES = """ActionScript              as
Ada                       adb, ads
JavaScript                js, jsx, mjs
Python                    py, pyw
Rust                      rs
Shell-Unix-Generic        sh, bash, zsh
TypeScript                ts, tsx
"""

THEMES = """Monokai Extended
Monokai Extended Bright
Monokai Extended Light
OneHalfDark
OneHalfLight
Solarized (dark)
Solarized (light)
"""

CONFIG = """    commit-style                  = raw
    file-style                    = blue
    hunk-header-style             = syntax
    minus-style                   = normal 52
    plus-style                    = syntax 22
    line-numbers                  = false
    navigate                      = false
    pager                         = none
    paging                        = never
    side-by-side                  = false
    syntax-theme                  = Monokai Extended
    width                         = 80
"""

COMPLETION_BASH = """_delta() {
    local cur
    cur="${COMP_WORDS[COMP_CWORD]}"
    COMPREPLY=( $(compgen -W "--help --version --color-only --raw --paging --no-gitconfig --list-languages --list-syntax-themes --show-syntax-themes --show-themes --show-config --generate-completion" -- "$cur") )
}
complete -F _delta delta
"""

COMPLETION_FISH = """complete -c delta -l help -d 'Print help'
complete -c delta -l version -d 'Print version'
complete -c delta -l color-only
complete -c delta -l raw
"""

COMPLETION_ZSH = """#compdef delta
_delta() {
  _arguments '*:file:_files'
}
compdef _delta delta
"""


def main(argv=None):
    argv = list(sys.argv[1:] if argv is None else argv)
    if argv and argv[0] in ("--help", "-h"):
        sys.stdout.write((Path(__file__).with_name("help.txt")).read_text())
        return 0
    if argv and argv[0] in ("--version", "-V"):
        print("delta 0.18.2")
        return 0
    if "--list-languages" in argv:
        sys.stdout.write(LANGUAGES)
        return 0
    if "--list-syntax-themes" in argv or "--show-themes" in argv or "--show-syntax-themes" in argv:
        sys.stdout.write(THEMES)
        return 0
    if "--show-config" in argv:
        sys.stdout.write(CONFIG)
        return 0
    if "--generate-completion" in argv:
        try:
            shell = argv[argv.index("--generate-completion") + 1]
        except (ValueError, IndexError):
            shell = "bash"
        if shell == "fish":
            sys.stdout.write(COMPLETION_FISH)
        elif shell == "zsh":
            sys.stdout.write(COMPLETION_ZSH)
        else:
            sys.stdout.write(COMPLETION_BASH)
        return 0
    paths = positional_args(argv)
    color_only = "--color-only" in argv
    raw = "--raw" in argv
    if len(paths) >= 2:
        text = gitish_diff(paths[0], paths[1])
        raw = True
    else:
        text = sys.stdin.read()
    if color_only or raw:
        sys.stdout.write(colorize_diff(text, raw=raw, color_only=color_only))
    else:
        sys.stdout.write(text)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
