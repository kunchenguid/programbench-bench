#!/bin/bash
set -euo pipefail

ROOT=$(cd "$(dirname "$0")/.." && pwd)
cd "$ROOT"

rm -f executable
chmod +x compile.sh
./compile.sh >/tmp/go-critic-test-build.log 2>&1

TMP=$(mktemp -d)
trap 'rm -rf "$TMP"' EXIT

assert_eq() {
  local name=$1
  local expected=$2
  local actual=$3
  if [[ "$actual" != "$expected" ]]; then
    echo "FAIL: $name"
    echo "expected:"
    printf '%s\n' "$expected"
    echo "actual:"
    printf '%s\n' "$actual"
    exit 1
  fi
}

out=$(./executable help 2>&1)
case "$out" in
  *"Usage:"*"go-critic <command> [arguments...]"*"check             run linter over specified targets"*"Version: v0.0.0-SNAPSHOT"*) ;;
  *) echo "FAIL: help output"; printf '%s\n' "$out"; exit 1 ;;
esac

assert_eq "version" "go-critic version: v0.0.0-SNAPSHOT" "$(./executable version 2>&1)"

doc_out=$(./executable doc unslice 2>&1)
case "$doc_out" in
  *"unslice checker documentation"*"Tags: [style]"*"Detects slice expressions that can be simplified"*"copy(b[:], values...)"*) ;;
  *) echo "FAIL: doc unslice"; printf '%s\n' "$doc_out"; exit 1 ;;
esac

cat > "$TMP/checks.go" <<'EOF'
package probe

import "fmt"

func g(xs []int) {
    xs = xs[:]
    x := 1
    x = x + 2
    switch len(xs) {
    case 1:
        fmt.Println("one")
    }
    switch true {
    case len(xs) > 0:
        fmt.Println("some")
    }
    if len(xs) >= 0 { fmt.Println("always") }
}
EOF

set +e
lint_out=$(./executable check "$TMP/checks.go" 2>&1)
status=$?
set -e
[[ $status -eq 1 ]] || { echo "FAIL: default exit $status"; printf '%s\n' "$lint_out"; exit 1; }
case "$lint_out" in
  *"$TMP/checks.go:6:10: unslice: could simplify xs[:] to xs"*"$TMP/checks.go:8:5: assignOp: replace \`x = x + 2\` with \`x += 2\`"*"$TMP/checks.go:9:5: singleCaseSwitch: should rewrite switch statement to if statement"*"$TMP/checks.go:13:5: singleCaseSwitch: should rewrite switch statement to if statement"*"$TMP/checks.go:13:5: switchTrue: replace 'switch true {}' with 'switch {}'"*"$TMP/checks.go:17:8: sloppyLen: len(xs) >= 0 is always true"*) ;;
  *) echo "FAIL: default lint output"; printf '%s\n' "$lint_out"; exit 1 ;;
esac

set +e
lint_out=$(./executable check -enable=assignOp "$TMP/checks.go" 2>&1)
status=$?
set -e
[[ $status -eq 1 ]] || { echo "FAIL: assignOp exit $status"; exit 1; }
assert_eq "assignOp output" "$TMP/checks.go:8:5: assignOp: replace \`x = x + 2\` with \`x += 2\`" "$lint_out"

set +e
lint_out=$(./executable check -enable=unslice "$TMP/checks.go" 2>&1)
status=$?
set -e
[[ $status -eq 1 ]] || { echo "FAIL: enable exit $status"; exit 1; }
assert_eq "enable unslice output" "$TMP/checks.go:6:10: unslice: could simplify xs[:] to xs" "$lint_out"

set +e
lint_out=$(./executable check -disable=unslice -exitCode=7 "$TMP/checks.go" 2>&1)
status=$?
set -e
[[ $status -eq 7 ]] || { echo "FAIL: exitCode status $status"; printf '%s\n' "$lint_out"; exit 1; }
case "$lint_out" in
  *unslice*) echo "FAIL: disabled unslice still present"; printf '%s\n' "$lint_out"; exit 1 ;;
esac

echo "tests passed"
