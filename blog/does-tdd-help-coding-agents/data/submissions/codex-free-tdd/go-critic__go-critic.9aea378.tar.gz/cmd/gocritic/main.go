package main

import (
	"bytes"
	"flag"
	"fmt"
	"go/ast"
	"go/format"
	"go/parser"
	"go/token"
	"os"
	"path/filepath"
	"sort"
	"strings"
)

const version = "v0.0.0-SNAPSHOT"

var defaultCheckers = []string{
	"appendAssign", "argOrder", "assignOp", "badCall", "badCond", "captLocal",
	"caseOrder", "codegenComment", "commentFormatting", "defaultCaseOrder",
	"deprecatedComment", "dupArg", "dupBranchBody", "dupCase", "dupSubExpr",
	"elseif", "exitAfterDefer", "flagDeref", "flagName", "ifElseChain",
	"mapKey", "newDeref", "offBy1", "regexpMust", "singleCaseSwitch",
	"sloppyLen", "sloppyTypeAssert", "switchTrue", "typeSwitchVar", "underef",
	"unlambda", "unslice", "valSwap", "wrapperFunc",
}

type checkerInfo struct {
	name string
	tags []string
}

var allCheckers = []checkerInfo{
	{"appendAssign", []string{"diagnostic"}}, {"appendCombine", []string{"performance"}},
	{"argOrder", []string{"diagnostic"}}, {"assignOp", []string{"style"}},
	{"badCall", []string{"diagnostic"}}, {"badCond", []string{"diagnostic"}},
	{"badLock", []string{"diagnostic", "experimental"}}, {"badRegexp", []string{"diagnostic", "experimental"}},
	{"badSorting", []string{"diagnostic", "experimental"}}, {"badSyncOnceFunc", []string{"diagnostic", "experimental"}},
	{"boolExprSimplify", []string{"style", "experimental"}}, {"builtinShadow", []string{"style", "opinionated"}},
	{"builtinShadowDecl", []string{"diagnostic", "experimental"}}, {"captLocal", []string{"style"}},
	{"caseOrder", []string{"diagnostic"}}, {"codegenComment", []string{"diagnostic"}},
	{"commentFormatting", []string{"style"}}, {"commentedOutCode", []string{"diagnostic", "experimental"}},
	{"commentedOutImport", []string{"style", "experimental"}}, {"defaultCaseOrder", []string{"style"}},
	{"deferInLoop", []string{"diagnostic", "experimental"}}, {"deferUnlambda", []string{"style", "experimental"}},
	{"deprecatedComment", []string{"diagnostic"}}, {"docStub", []string{"style", "experimental"}},
	{"dupArg", []string{"diagnostic"}}, {"dupBranchBody", []string{"diagnostic"}},
	{"dupCase", []string{"diagnostic"}}, {"dupImport", []string{"style", "experimental"}},
	{"dupOption", []string{"diagnostic", "experimental"}}, {"dupSubExpr", []string{"diagnostic"}},
	{"dynamicFmtString", []string{"diagnostic", "experimental"}}, {"elseif", []string{"style"}},
	{"emptyDecl", []string{"diagnostic", "experimental"}}, {"emptyFallthrough", []string{"style", "experimental"}},
	{"emptyStringTest", []string{"style", "experimental"}}, {"equalFold", []string{"performance", "experimental"}},
	{"evalOrder", []string{"diagnostic", "experimental"}}, {"exitAfterDefer", []string{"diagnostic"}},
	{"exposedSyncMutex", []string{"style", "experimental"}}, {"externalErrorReassign", []string{"diagnostic", "experimental"}},
	{"filepathJoin", []string{"diagnostic", "experimental"}}, {"flagDeref", []string{"diagnostic"}},
	{"flagName", []string{"diagnostic"}}, {"hexLiteral", []string{"style", "experimental"}},
	{"httpNoBody", []string{"style", "experimental"}}, {"hugeParam", []string{"performance"}},
	{"ifElseChain", []string{"style"}}, {"importShadow", []string{"style", "opinionated"}},
	{"indexAlloc", []string{"performance"}}, {"initClause", []string{"style", "opinionated", "experimental"}},
	{"mapKey", []string{"diagnostic"}}, {"methodExprCall", []string{"style", "experimental"}},
	{"nestingReduce", []string{"style", "opinionated", "experimental"}}, {"newDeref", []string{"style"}},
	{"nilValReturn", []string{"diagnostic", "experimental"}}, {"octalLiteral", []string{"style", "experimental", "opinionated"}},
	{"offBy1", []string{"diagnostic"}}, {"paramTypeCombine", []string{"style", "opinionated"}},
	{"preferDecodeRune", []string{"performance", "experimental"}}, {"preferFilepathJoin", []string{"style", "experimental"}},
	{"preferFprint", []string{"performance", "experimental"}}, {"preferStringWriter", []string{"performance", "experimental"}},
	{"preferWriteByte", []string{"performance", "experimental", "opinionated"}}, {"ptrToRefParam", []string{"style", "opinionated", "experimental"}},
	{"rangeAppendAll", []string{"diagnostic", "experimental"}}, {"rangeExprCopy", []string{"performance"}},
	{"rangeValCopy", []string{"performance"}}, {"redundantSprint", []string{"style", "experimental"}},
	{"regexpMust", []string{"style"}}, {"regexpPattern", []string{"diagnostic", "experimental"}},
	{"regexpSimplify", []string{"style", "experimental", "opinionated"}}, {"returnAfterHttpError", []string{"diagnostic", "experimental"}},
	{"ruleguard", []string{"style", "experimental"}}, {"singleCaseSwitch", []string{"style"}},
	{"sliceClear", []string{"performance", "experimental"}}, {"sloppyLen", []string{"diagnostic"}},
	{"sloppyReassign", []string{"diagnostic", "experimental"}}, {"sloppyTypeAssert", []string{"diagnostic"}},
	{"sortSlice", []string{"diagnostic", "experimental"}}, {"sprintfQuotedString", []string{"diagnostic", "experimental"}},
	{"sqlQuery", []string{"diagnostic", "experimental"}}, {"stringConcatSimplify", []string{"style", "experimental"}},
	{"stringXbytes", []string{"performance"}}, {"stringsCompare", []string{"style", "experimental"}},
	{"switchTrue", []string{"style"}}, {"syncMapLoadAndDelete", []string{"diagnostic", "experimental"}},
	{"timeExprSimplify", []string{"style", "experimental"}}, {"todoCommentWithoutDetail", []string{"style", "opinionated", "experimental"}},
	{"tooManyResultsChecker", []string{"style", "opinionated", "experimental"}}, {"truncateCmp", []string{"diagnostic", "experimental"}},
	{"typeAssertChain", []string{"style", "experimental"}}, {"typeDefFirst", []string{"style", "experimental"}},
	{"typeSwitchVar", []string{"style"}}, {"typeUnparen", []string{"style", "opinionated"}},
	{"uncheckedInlineErr", []string{"diagnostic", "experimental"}}, {"underef", []string{"style"}},
	{"unlabelStmt", []string{"style", "experimental"}}, {"unlambda", []string{"style"}},
	{"unnamedResult", []string{"style", "opinionated", "experimental"}}, {"unnecessaryBlock", []string{"style", "opinionated", "experimental"}},
	{"unnecessaryDefer", []string{"diagnostic", "experimental"}}, {"unslice", []string{"style"}},
	{"valSwap", []string{"style"}}, {"weakCond", []string{"diagnostic", "experimental"}},
	{"whyNoLint", []string{"style", "experimental"}}, {"wrapperFunc", []string{"style"}},
	{"yodaStyleExpr", []string{"style", "experimental"}}, {"zeroByteRepeat", []string{"performance"}},
}

type issue struct {
	pos     token.Position
	checker string
	msg     string
}

func main() {
	if len(os.Args) == 1 {
		fmt.Println("no args provided")
		return
	}
	switch os.Args[1] {
	case "help":
		printHelp()
	case "version":
		fmt.Printf("go-critic version: %s\n", version)
	case "doc":
		runDoc(os.Args[2:])
	case "check":
		os.Exit(runCheck(os.Args[2:]))
	default:
		fmt.Printf("%q unknown command\nRun \"go-critic help\" for usage.\n\nno such command %q\n", os.Args[1], os.Args[1])
	}
}

func printHelp() {
	fmt.Printf(`Usage:

    go-critic <command> [arguments...]

The commands are:

    check             run linter over specified targets
    doc               get installed checkers documentation
    help              shows help message
    version           shows version of the application

Version: %s
`, version)
}

func runDoc(args []string) {
	if len(args) == 0 {
		for _, c := range allCheckers {
			fmt.Printf("%s [%s]\n", c.name, strings.Join(c.tags, " "))
		}
		return
	}
	if args[0] == "-help" || args[0] == "--help" {
		fmt.Println("Usage of go-critic:")
		fmt.Println("flag: help requested")
		return
	}
	c, ok := checkerByName(args[0])
	if !ok {
		fmt.Printf("checker with name %q not found\n", args[0])
		os.Exit(1)
	}
	printCheckerDoc(c)
}

func printCheckerDoc(c checkerInfo) {
	fmt.Printf("%s checker documentation\n", c.name)
	fmt.Println("URL: https://github.com/go-critic/go-critic/checkers")
	fmt.Printf("Tags: [%s]\n\n", strings.Join(c.tags, " "))
	switch c.name {
	case "unslice":
		fmt.Println("Detects slice expressions that can be simplified to sliced expression itself.")
		fmt.Println()
		fmt.Println("Non-compliant code:")
		fmt.Println("copy(b[:], values...)")
		fmt.Println()
		fmt.Println("Compliant code:")
		fmt.Println("copy(b, values...)")
	case "singleCaseSwitch":
		fmt.Println("Detects switch statements that can be better written as if statement.")
	case "sloppyLen":
		fmt.Println("Detects comparisons like len(x) >= 0 that are always true.")
	default:
		fmt.Printf("Documentation for %s checker.\n", c.name)
	}
}

func runCheck(args []string) int {
	fs := flag.NewFlagSet("go-critic", flag.ContinueOnError)
	fs.SetOutput(os.Stderr)
	enable := fs.String("enable", strings.Join(defaultCheckers, ","), "comma-separated list of enabled checkers. Can include #tags")
	disable := fs.String("disable", "", "comma-separated list of checkers to be disabled. Can include #tags")
	enableAll := fs.Bool("enableAll", false, "identical to -enable with all checkers listed. If true, -enable is ignored")
	exitCode := fs.Int("exitCode", 1, "exit code to be used when lint issues are found")
	checkTests := fs.Bool("checkTests", true, "whether to check test files")
	_ = fs.Bool("checkGenerated", false, "whether to check generated files")
	_ = fs.Bool("v", false, "whether to print output useful during linter debugging")
	addIgnoredFlags(fs)
	if err := fs.Parse(args); err != nil {
		fmt.Fprintln(os.Stderr, "parse args:", err)
		return 0
	}

	enabled := selectCheckers(*enable, *disable, *enableAll)
	if len(enabled) == 0 {
		fmt.Println("init checkers: empty checkers set selected")
		return 1
	}

	files := collectFiles(fs.Args(), *checkTests)
	var issues []issue
	for _, name := range files {
		issues = append(issues, checkFile(name, enabled)...)
	}
	sort.SliceStable(issues, func(i, j int) bool {
		if issues[i].pos.Filename != issues[j].pos.Filename {
			return issues[i].pos.Filename < issues[j].pos.Filename
		}
		if issues[i].pos.Line != issues[j].pos.Line {
			return issues[i].pos.Line < issues[j].pos.Line
		}
		return issues[i].pos.Column < issues[j].pos.Column
	})
	for _, iss := range issues {
		fmt.Printf("%s:%d:%d: %s: %s\n", iss.pos.Filename, iss.pos.Line, iss.pos.Column, iss.checker, iss.msg)
	}
	if len(issues) != 0 {
		return *exitCode
	}
	return 0
}

func addIgnoredFlags(fs *flag.FlagSet) {
	fs.Int("concurrency", 12, "how many concurrent checkers to run")
	fs.String("cpuprofile", "", "write CPU profile to the specified file")
	fs.String("go", "", "select the Go version to target. Leave as string for the latest")
	fs.String("memprofile", "", "write memory profile to the specified file")
	fs.Bool("shorterErrLocation", true, "whether to replace error location prefix with $GOROOT and $GOPATH")
	fs.Bool("@captLocal.paramsOnly", true, "")
	fs.Int("@commentedOutCode.minLength", 15, "")
	fs.Bool("@elseif.skipBalanced", true, "")
	fs.Int("@hugeParam.sizeThreshold", 80, "")
	fs.Int("@ifElseChain.minThreshold", 2, "")
	fs.Int("@nestingReduce.bodyWidth", 5, "")
	fs.Int("@rangeExprCopy.sizeThreshold", 512, "")
	fs.Bool("@rangeExprCopy.skipTestFuncs", true, "")
	fs.Int("@rangeValCopy.sizeThreshold", 128, "")
	fs.Bool("@rangeValCopy.skipTestFuncs", true, "")
	fs.String("@ruleguard.debug", "", "")
	fs.String("@ruleguard.disable", "", "")
	fs.String("@ruleguard.enable", "<all>", "")
	fs.String("@ruleguard.failOn", "", "")
	fs.Bool("@ruleguard.failOnError", false, "")
	fs.String("@ruleguard.rules", "", "")
	fs.Int("@tooManyResultsChecker.maxResults", 5, "")
	fs.Bool("@truncateCmp.skipArchDependent", true, "")
	fs.Bool("@underef.skipRecvDeref", true, "")
	fs.Bool("@unnamedResult.checkExported", false, "")
}

func selectCheckers(enable, disable string, enableAll bool) map[string]bool {
	selected := map[string]bool{}
	if enableAll {
		for _, c := range allCheckers {
			selected[c.name] = true
		}
	} else {
		for _, name := range expandList(enable) {
			selected[name] = true
		}
	}
	for _, name := range expandList(disable) {
		delete(selected, name)
	}
	return selected
}

func expandList(s string) []string {
	var out []string
	for _, part := range strings.Split(s, ",") {
		part = strings.TrimSpace(part)
		if part == "" {
			continue
		}
		if strings.HasPrefix(part, "#") {
			tag := strings.TrimPrefix(part, "#")
			for _, c := range allCheckers {
				if hasTag(c, tag) {
					out = append(out, c.name)
				}
			}
			continue
		}
		if _, ok := checkerByName(part); ok {
			out = append(out, part)
		}
	}
	return out
}

func collectFiles(targets []string, checkTests bool) []string {
	var files []string
	for _, target := range targets {
		info, err := os.Stat(target)
		if err != nil {
			continue
		}
		if info.IsDir() {
			_ = filepath.WalkDir(target, func(path string, d os.DirEntry, err error) error {
				if err == nil && !d.IsDir() && strings.HasSuffix(path, ".go") && (checkTests || !strings.HasSuffix(path, "_test.go")) {
					files = append(files, displayPath(path))
				}
				return nil
			})
			continue
		}
		if strings.HasSuffix(target, ".go") && (checkTests || !strings.HasSuffix(target, "_test.go")) {
			files = append(files, displayPath(target))
		}
	}
	sort.Strings(files)
	return files
}

func displayPath(path string) string {
	if filepath.IsAbs(path) || strings.HasPrefix(path, ".") {
		return path
	}
	return "./" + path
}

func checkFile(filename string, enabled map[string]bool) []issue {
	fs := token.NewFileSet()
	file, err := parser.ParseFile(fs, filename, nil, parser.ParseComments)
	if err != nil {
		return nil
	}
	var issues []issue
	ast.Inspect(file, func(n ast.Node) bool {
		switch x := n.(type) {
		case *ast.SliceExpr:
			if enabled["unslice"] && x.Low == nil && x.High == nil && x.Max == nil {
				expr := nodeString(x.X)
				issues = append(issues, issue{fs.Position(x.Pos()), "unslice", fmt.Sprintf("could simplify %s[:] to %s", expr, expr)})
			}
		case *ast.SwitchStmt:
			if enabled["singleCaseSwitch"] && len(x.Body.List) == 1 && !caseIsDefault(x.Body.List[0]) {
				issues = append(issues, issue{fs.Position(x.Pos()), "singleCaseSwitch", "should rewrite switch statement to if statement"})
			}
			if enabled["switchTrue"] && isBoolIdent(x.Tag, "true") {
				issues = append(issues, issue{fs.Position(x.Pos()), "switchTrue", "replace 'switch true {}' with 'switch {}'"})
			}
		case *ast.AssignStmt:
			if enabled["assignOp"] {
				if iss, ok := assignOpIssue(fs, x); ok {
					issues = append(issues, iss)
				}
			}
		case *ast.BinaryExpr:
			if enabled["sloppyLen"] {
				if msg, ok := sloppyLenMessage(x); ok {
					issues = append(issues, issue{fs.Position(x.Pos()), "sloppyLen", msg})
				}
			}
		}
		return true
	})
	return issues
}

func assignOpIssue(fs *token.FileSet, x *ast.AssignStmt) (issue, bool) {
	if x.Tok != token.ASSIGN || len(x.Lhs) != 1 || len(x.Rhs) != 1 {
		return issue{}, false
	}
	bin, ok := x.Rhs[0].(*ast.BinaryExpr)
	if !ok {
		return issue{}, false
	}
	if !sameExpr(x.Lhs[0], bin.X) {
		return issue{}, false
	}
	var op string
	switch bin.Op {
	case token.ADD:
		op = "+="
	case token.SUB:
		op = "-="
	case token.MUL:
		op = "*="
	case token.QUO:
		op = "/="
	case token.REM:
		op = "%="
	default:
		return issue{}, false
	}
	old := nodeString(x)
	newText := fmt.Sprintf("%s %s %s", nodeString(x.Lhs[0]), op, nodeString(bin.Y))
	return issue{fs.Position(x.Pos()), "assignOp", fmt.Sprintf("replace `%s` with `%s`", old, newText)}, true
}

func sameExpr(a, b ast.Expr) bool {
	return nodeString(a) == nodeString(b)
}

func isBoolIdent(n ast.Expr, val string) bool {
	id, ok := n.(*ast.Ident)
	return ok && id.Name == val
}

func caseIsDefault(stmt ast.Stmt) bool {
	cc, ok := stmt.(*ast.CaseClause)
	return ok && cc.List == nil
}

func sloppyLenMessage(x *ast.BinaryExpr) (string, bool) {
	left, right := nodeString(x.X), nodeString(x.Y)
	if isLenCall(x.X) && isZero(x.Y) {
		switch x.Op {
		case token.GEQ:
			return fmt.Sprintf("%s >= 0 is always true", left), true
		case token.LSS:
			return fmt.Sprintf("%s < 0 is always false", left), true
		}
	}
	if isZero(x.X) && isLenCall(x.Y) {
		switch x.Op {
		case token.LEQ:
			return fmt.Sprintf("0 <= %s is always true", right), true
		case token.GTR:
			return fmt.Sprintf("0 > %s is always false", right), true
		}
	}
	return "", false
}

func isLenCall(n ast.Expr) bool {
	call, ok := n.(*ast.CallExpr)
	if !ok || len(call.Args) != 1 {
		return false
	}
	id, ok := call.Fun.(*ast.Ident)
	return ok && id.Name == "len"
}

func isZero(n ast.Expr) bool {
	lit, ok := n.(*ast.BasicLit)
	return ok && lit.Value == "0"
}

func nodeString(n ast.Node) string {
	var buf bytes.Buffer
	_ = format.Node(&buf, token.NewFileSet(), n)
	return buf.String()
}

func checkerByName(name string) (checkerInfo, bool) {
	for _, c := range allCheckers {
		if c.name == name {
			return c, true
		}
	}
	return checkerInfo{}, false
}

func hasTag(c checkerInfo, tag string) bool {
	for _, t := range c.tags {
		if t == tag {
			return true
		}
	}
	return false
}
