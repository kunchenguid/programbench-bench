import os
import subprocess
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]


def build_once():
    subprocess.run(["bash", "compile.sh"], cwd=ROOT, check=True)


def run_executable(*args):
    build_once()
    return subprocess.run(
        [str(ROOT / "executable"), *args],
        cwd=ROOT,
        text=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
    )


def test_long_help_matches_documented_cli_surface():
    result = run_executable("--help")
    assert result.returncode == 0
    assert result.stdout.startswith("Ping, but with a graph.\n\nUsage: executable ")
    assert "--cmd" in result.stdout
    assert "--ping-args [<PING_ARGS>...]" in result.stdout
    assert "Print version" in result.stdout


def test_version_outputs_full_build_metadata_for_long_flag():
    result = run_executable("--version")
    assert result.returncode == 0
    assert result.stdout == (
        "gping 1.20.1\n"
        "commit_hash: d67d2aeb\n"
        "build_time: 2026-04-17 19:59:37 +00:00\n"
        "build_env: rustc 1.92.0 (ded5c06cf 2025-12-08),1.92.0-x86_64-unknown-linux-gnu\n"
    )


def test_short_version_outputs_only_program_version():
    result = run_executable("-V")
    assert result.returncode == 0
    assert result.stdout == "gping 1.20.1\n"


def test_requires_at_least_one_host_or_command():
    result = run_executable()
    assert result.returncode == 1
    assert result.stdout == (
        "Error: At least one host or command must be given (i.e gping google.com). "
        "Use --help for a full list of arguments.\n"
    )


def test_unknown_flag_uses_clap_style_error():
    result = run_executable("--bad")
    assert result.returncode == 2
    assert "error: unexpected argument '--bad' found\n" in result.stdout
    assert "tip: to pass '--bad' as a value, use '-- --bad'\n" in result.stdout
    assert "Usage: executable [OPTIONS] [HOSTS_OR_COMMANDS]...\n" in result.stdout


def test_ping_args_consumes_remaining_values_before_host_validation():
    result = run_executable("--ping-args", "-q", "host")
    assert result.returncode == 1
    assert result.stdout.startswith("Error: At least one host or command must be given")


def test_invalid_color_is_reported_after_parsing():
    result = run_executable("--color", "nope", "host")
    assert result.returncode == 1
    assert result.stdout == (
        "Error: Invalid color code: `nope`\n\n"
        "Caused by:\n"
        "    Failed to parse Colors\n"
    )
