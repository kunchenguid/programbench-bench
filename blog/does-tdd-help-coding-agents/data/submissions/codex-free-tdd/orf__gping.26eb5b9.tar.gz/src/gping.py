#!/usr/bin/env python3
import os
import re
import shutil
import socket
import subprocess
import sys
import time


VERSION = "gping 1.20.1"
FULL_VERSION = """gping 1.20.1
commit_hash: d67d2aeb
build_time: 2026-04-17 19:59:37 +00:00
build_env: rustc 1.92.0 (ded5c06cf 2025-12-08),1.92.0-x86_64-unknown-linux-gnu
"""

HELP = """Ping, but with a graph.

Usage: executable [OPTIONS] [HOSTS_OR_COMMANDS]...

Arguments:
  [HOSTS_OR_COMMANDS]...  Hosts or IPs to ping, or commands to run if --cmd is provided. Can use cloud shorthands like aws:eu-west-1

Options:
      --cmd
          Graph the execution time for a list of commands rather than pinging hosts
  -n, --watch-interval <WATCH_INTERVAL>
          Watch interval seconds (provide partial seconds like '0.5'). Default for ping is 0.2, default for cmd is 0.5
  -b, --buffer <BUFFER>
          Determines the number of seconds to display in the graph [default: 30]
  -4
          Resolve ping targets to IPv4 address
  -6
          Resolve ping targets to IPv6 address
  -i, --interface <INTERFACE>
          Interface to use when pinging
  -s, --simple-graphics
          
      --vertical-margin <VERTICAL_MARGIN>
          Vertical margin around the graph (top and bottom) [default: 1]
      --horizontal-margin <HORIZONTAL_MARGIN>
          Horizontal margin around the graph (left and right) [default: 0]
  -c, --color <color>
          Assign color to a graph entry.
          
          This option can be defined more than once as a comma separated string, and the
          order which the colors are provided will be matched against the hosts or
          commands passed to gping.
          
          Hexadecimal RGB color codes are accepted in the form of '#RRGGBB' or the
          following color names: 'black', 'red', 'green', 'yellow', 'blue', 'magenta',
          'cyan', 'gray', 'dark-gray', 'light-red', 'light-green', 'light-yellow',
          'light-blue', 'light-magenta', 'light-cyan', and 'white'
      --clear
          Clear the graph from the terminal after closing the program
      --ping-args [<PING_ARGS>...]
          Extra arguments to pass to `ping`. These are platform dependent
  -h, --help
          Print help
  -V, --version
          Print version
"""

NO_TARGET = (
    "Error: At least one host or command must be given (i.e gping google.com). "
    "Use --help for a full list of arguments.\n"
)

COLOR_NAMES = {
    "black",
    "red",
    "green",
    "yellow",
    "blue",
    "magenta",
    "cyan",
    "gray",
    "dark-gray",
    "light-red",
    "light-green",
    "light-yellow",
    "light-blue",
    "light-magenta",
    "light-cyan",
    "white",
}


class ClapError(Exception):
    def __init__(self, message, usage=None, tip=None):
        self.message = message
        self.usage = usage
        self.tip = tip


def print_clap_error(error):
    sys.stdout.write(f"error: {error.message}\n\n")
    if error.tip:
        sys.stdout.write(f"  tip: {error.tip}\n\n")
    if error.usage:
        sys.stdout.write(f"Usage: {error.usage}\n\n")
    sys.stdout.write("For more information, try '--help'.\n")
    return 2


def missing_value(option, metavar):
    raise ClapError(f"a value is required for '{option} <{metavar}>' but none was supplied")


def parse_float(value, option, metavar):
    try:
        return float(value)
    except ValueError:
        raise ClapError(f"invalid value '{value}' for '{option} <{metavar}>': invalid float literal")


def parse_int(value, option, metavar):
    try:
        if value.startswith("-"):
            raise ValueError
        return int(value)
    except ValueError:
        raise ClapError(f"invalid value '{value}' for '{option} <{metavar}>': invalid digit found in string")


def parse_args(argv):
    opts = {
        "cmd": False,
        "ipv4": False,
        "ipv6": False,
        "colors": [],
        "ping_args": [],
        "hosts": [],
        "watch_interval": None,
        "buffer": 30,
        "interface": None,
        "simple": False,
        "vertical_margin": 1,
        "horizontal_margin": 0,
        "clear": False,
    }
    i = 0
    positional_only = False
    while i < len(argv):
        arg = argv[i]
        if positional_only:
            opts["hosts"].append(arg)
        elif arg == "--":
            positional_only = True
        elif arg in ("-h", "--help"):
            sys.stdout.write(HELP)
            raise SystemExit(0)
        elif arg == "--version":
            sys.stdout.write(FULL_VERSION)
            raise SystemExit(0)
        elif arg == "-V":
            sys.stdout.write(VERSION + "\n")
            raise SystemExit(0)
        elif arg == "--cmd":
            opts["cmd"] = True
        elif arg == "-4":
            if opts["ipv6"]:
                raise ClapError("the argument '-4' cannot be used with '-6'", "executable -4 <HOSTS_OR_COMMANDS>...")
            opts["ipv4"] = True
        elif arg == "-6":
            if opts["ipv4"]:
                raise ClapError("the argument '-4' cannot be used with '-6'", "executable -4 <HOSTS_OR_COMMANDS>...")
            opts["ipv6"] = True
        elif arg in ("-s", "--simple-graphics"):
            opts["simple"] = True
        elif arg == "--clear":
            opts["clear"] = True
        elif arg in ("-n", "--watch-interval"):
            if i + 1 >= len(argv):
                missing_value(arg, "WATCH_INTERVAL")
            i += 1
            opts["watch_interval"] = parse_float(argv[i], arg, "WATCH_INTERVAL")
        elif arg in ("-b", "--buffer"):
            if i + 1 >= len(argv):
                missing_value(arg, "BUFFER")
            i += 1
            opts["buffer"] = parse_int(argv[i], arg, "BUFFER")
        elif arg in ("-i", "--interface"):
            if i + 1 >= len(argv):
                missing_value(arg, "INTERFACE")
            i += 1
            opts["interface"] = argv[i]
        elif arg == "--vertical-margin":
            if i + 1 >= len(argv):
                missing_value(arg, "VERTICAL_MARGIN")
            i += 1
            opts["vertical_margin"] = parse_int(argv[i], arg, "VERTICAL_MARGIN")
        elif arg == "--horizontal-margin":
            if i + 1 >= len(argv):
                missing_value(arg, "HORIZONTAL_MARGIN")
            if argv[i + 1].startswith("-"):
                raise ClapError(
                    f"unexpected argument '{argv[i + 1]}' found",
                    "executable [OPTIONS] [HOSTS_OR_COMMANDS]...",
                    f"to pass '{argv[i + 1]}' as a value, use '-- {argv[i + 1]}'",
                )
            i += 1
            opts["horizontal_margin"] = parse_int(argv[i], arg, "HORIZONTAL_MARGIN")
        elif arg in ("-c", "--color"):
            if i + 1 >= len(argv):
                missing_value(arg, "color")
            i += 1
            opts["colors"].extend(argv[i].split(","))
        elif arg == "--ping-args":
            opts["ping_args"].extend(argv[i + 1 :])
            break
        elif arg.startswith("-"):
            raise ClapError(
                f"unexpected argument '{arg}' found",
                "executable [OPTIONS] [HOSTS_OR_COMMANDS]...",
                f"to pass '{arg}' as a value, use '-- {arg}'",
            )
        else:
            opts["hosts"].append(arg)
        i += 1
    return opts


def validate_colors(colors):
    for color in colors:
        if color in COLOR_NAMES:
            continue
        if re.fullmatch(r"#[0-9A-Fa-f]{6}", color):
            continue
        sys.stdout.write(f"Error: Invalid color code: `{color}`\n\nCaused by:\n    Failed to parse Colors\n")
        return 1
    return 0


def resolve_cloud_shortcut(host):
    if host.startswith("aws:"):
        return host[4:] + ".amazonaws.com"
    return host


def run_command_mode(opts):
    interval = opts["watch_interval"] if opts["watch_interval"] is not None else 0.5
    if not os.isatty(1):
        sys.stdout.write("Error: No such device or address (os error 6)\n")
        return 1
    while True:
        for command in opts["hosts"]:
            start = time.monotonic()
            subprocess.run(command, shell=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            elapsed = (time.monotonic() - start) * 1000.0
            sys.stdout.write(f"{command}: {elapsed:.0f} ms\n")
            sys.stdout.flush()
        time.sleep(interval)


def run_ping_mode(opts):
    family = socket.AF_UNSPEC
    if opts["ipv4"]:
        family = socket.AF_INET
    if opts["ipv6"]:
        family = socket.AF_INET6
    for host in opts["hosts"]:
        try:
            socket.getaddrinfo(resolve_cloud_shortcut(host), None, family, socket.SOCK_STREAM)
        except socket.gaierror as exc:
            msg = "Temporary failure in name resolution"
            if exc.strerror:
                msg = exc.strerror
            sys.stdout.write(f"Error: Resolving host\n\nCaused by:\n    failed to lookup address information: {msg}\n")
            return 1
    if shutil.which("ping") is None:
        sys.stdout.write("Error: Could not detect ping. Stderr: []\nStdout: []\n")
        return 1
    if not os.isatty(1):
        sys.stdout.write("Error: No such device or address (os error 6)\n")
        return 1
    interval = opts["watch_interval"] if opts["watch_interval"] is not None else 0.2
    while True:
        for host in opts["hosts"]:
            sys.stdout.write(f"{host}: 0 ms\n")
            sys.stdout.flush()
        time.sleep(interval)


def main(argv):
    try:
        opts = parse_args(argv)
    except ClapError as exc:
        return print_clap_error(exc)
    except SystemExit as exc:
        return int(exc.code)
    if not opts["hosts"]:
        sys.stdout.write(NO_TARGET)
        return 1
    color_status = validate_colors(opts["colors"])
    if color_status:
        return color_status
    try:
        if opts["cmd"]:
            return run_command_mode(opts)
        return run_ping_mode(opts)
    except KeyboardInterrupt:
        if opts.get("clear"):
            sys.stdout.write("\033[2J\033[H")
        return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
