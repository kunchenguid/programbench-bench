#!/usr/bin/env python3
import os
import shutil
import stat
import subprocess
import tempfile
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
BIN = ROOT / "executable"


def run_xcp(*args, cwd):
    return subprocess.run(
        [str(BIN), "--no-progress", *args],
        cwd=cwd,
        text=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
    )


def workspace():
    return tempfile.TemporaryDirectory(prefix="xcp-test-")


def test_copies_single_file_to_new_file():
    with workspace() as td:
        cwd = Path(td)
        (cwd / "src").write_text("hello")
        result = run_xcp("src", "dst", cwd=cwd)
        assert result.returncode == 0, result.stderr
        assert result.stdout == ""
        assert result.stderr == ""
        assert (cwd / "dst").read_text() == "hello"


def test_multiple_sources_require_directory_destination():
    with workspace() as td:
        cwd = Path(td)
        (cwd / "a").write_text("a")
        (cwd / "b").write_text("b")
        result = run_xcp("a", "b", "dest", cwd=cwd)
        assert result.returncode == 1
        assert result.stderr == "Error: Invalid destination: Multiple sources and destination is not a directory.\n"


def test_recursive_directory_to_existing_directory_nests_source_name():
    with workspace() as td:
        cwd = Path(td)
        (cwd / "src/sub").mkdir(parents=True)
        (cwd / "src/a").write_text("one")
        (cwd / "src/sub/b").write_text("two")
        (cwd / "target").mkdir()
        result = run_xcp("-r", "src", "target", cwd=cwd)
        assert result.returncode == 0, result.stderr
        assert (cwd / "target/src/a").read_text() == "one"
        assert (cwd / "target/src/sub/b").read_text() == "two"


def test_directory_copy_without_recursive_fails():
    with workspace() as td:
        cwd = Path(td)
        (cwd / "src").mkdir()
        result = run_xcp("src", "dst", cwd=cwd)
        assert result.returncode == 1
        assert result.stderr == "Error: Invalid source: Source is directory and --recursive not specified.\n"


def test_no_clobber_keeps_destination():
    with workspace() as td:
        cwd = Path(td)
        (cwd / "src").write_text("new")
        (cwd / "dst").write_text("old")
        result = run_xcp("-n", "src", "dst", cwd=cwd)
        assert result.returncode == 1
        assert "Error: Destination Exists: Destination file exists and --no-clobber is set., dst\n" in result.stderr
        assert (cwd / "dst").read_text() == "old"


def test_numbered_backup_preserves_overwritten_versions():
    with workspace() as td:
        cwd = Path(td)
        (cwd / "src").write_text("new")
        (cwd / "dst").write_text("old")
        assert run_xcp("--backup", "numbered", "src", "dst", cwd=cwd).returncode == 0
        assert (cwd / "dst").read_text() == "new"
        assert (cwd / "dst.~1~").read_text() == "old"
        (cwd / "src").write_text("newer")
        assert run_xcp("--backup", "numbered", "src", "dst", cwd=cwd).returncode == 0
        assert (cwd / "dst.~2~").read_text() == "new"


def test_symlink_is_preserved_unless_dereferenced():
    with workspace() as td:
        cwd = Path(td)
        (cwd / "real").write_text("real")
        os.symlink("real", cwd / "link")
        assert run_xcp("link", "copy-link", cwd=cwd).returncode == 0
        assert os.path.islink(cwd / "copy-link")
        assert os.readlink(cwd / "copy-link") == "real"
        assert run_xcp("-L", "link", "copy-real", cwd=cwd).returncode == 0
        assert not os.path.islink(cwd / "copy-real")
        assert (cwd / "copy-real").read_text() == "real"


def test_permissions_and_timestamps_are_preserved_by_default():
    with workspace() as td:
        cwd = Path(td)
        src = cwd / "src"
        dst = cwd / "dst"
        src.write_text("x")
        src.chmod(0o744)
        os.utime(src, (981173106, 981173106))
        assert run_xcp("src", "dst", cwd=cwd).returncode == 0
        assert stat.S_IMODE(dst.stat().st_mode) == 0o744
        assert int(dst.stat().st_mtime) == 981173106


def test_glob_expands_patterns_into_directory_destination():
    with workspace() as td:
        cwd = Path(td)
        (cwd / "a.txt").write_text("a")
        (cwd / "b.txt").write_text("b")
        (cwd / "c.log").write_text("c")
        (cwd / "out").mkdir()
        result = run_xcp("--glob", "*.txt", "out", cwd=cwd)
        assert result.returncode == 0, result.stderr
        assert sorted(p.name for p in (cwd / "out").iterdir()) == ["a.txt", "b.txt"]


def test_force_and_no_clobber_are_rejected_together():
    with workspace() as td:
        cwd = Path(td)
        (cwd / "src").write_text("x")
        result = run_xcp("-n", "-f", "src", "dst", cwd=cwd)
        assert result.returncode == 1
        assert result.stderr == "Error: Invalid arguments: --force and --noclobber cannot be set at the same time.\n"


def test_long_help_contains_extended_option_details():
    result = subprocess.run(
        [str(BIN), "--help"],
        text=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
    )
    assert result.returncode == 0
    assert result.stderr == ""
    assert "Default is 4; if the value is negative or 0 it uses the number of logical CPUs." in result.stdout
    assert "Whether and how to use reflinks." in result.stdout
    assert "Numbered backups follow the semantics of `cp` numbered backups" in result.stdout


if __name__ == "__main__":
    import pytest  # type: ignore

    raise SystemExit(pytest.main([__file__]))
