#!/usr/bin/env python3
import fnmatch
import os
import shutil
import sys
from pathlib import Path


VERSION = "xcp 0.24.3"


HELP_SHORT = """A (partial) clone of the Unix `cp` command with progress and pluggable drivers.

Usage: executable [OPTIONS] [PATHS]...

Arguments:
  [PATHS]...  Path list

Options:
  -v, --verbose...
          Verbosity
  -r, --recursive
          Copy directories recursively
  -L, --dereference
          Dereference symlinks in source
  -w, --workers <WORKERS>
          Number of parallel workers [default: 4]
      --block-size <BLOCK_SIZE>
          Block size for operations [default: 1MB]
  -n, --no-clobber
          Do not overwrite an existing file
  -f, --force
          Force (compatability only)
      --gitignore
          Use .gitignore if present
  -g, --glob
          Expand file patterns
      --no-progress
          Disable progress bar
      --no-perms
          Do not copy the file permissions
      --no-timestamps
          Do not copy the file timestamps
  -o, --ownership
          Copy ownership
      --driver <DRIVER>
          Driver to use, defaults to 'file-parallel' [default: parfile]
  -T, --no-target-directory
          Target should not be a directory
      --target-directory <TARGET_DIRECTORY>
          Copy into a subdirectory of the target
      --fsync
          Sync each file to disk after writing
      --reflink <REFLINK>
          Reflink options [default: auto]
      --backup <BACKUP>
          Backup options [default: none]
  -h, --help
          Print help (see more with '--help')
  -V, --version
          Print version
"""


HELP_LONG = """A (partial) clone of the Unix `cp` command with progress and pluggable drivers.

Usage: executable [OPTIONS] [PATHS]...

Arguments:
  [PATHS]...
          Path list.
          
          Source and destination files, or multiple source(s) to a directory.

Options:
  -v, --verbose...
          Verbosity.
          
          Can be specified multiple times to increase logging.

  -r, --recursive
          Copy directories recursively

  -L, --dereference
          Dereference symlinks in source
          
          Follow symlinks, possibly recursively, when copying source files.

  -w, --workers <WORKERS>
          Number of parallel workers.
          
          Default is 4; if the value is negative or 0 it uses the number of logical CPUs.
          
          [default: 4]

      --block-size <BLOCK_SIZE>
          Block size for operations.
          
          Accepts standard size modifiers like "M" and "GB". Actual usage internally depends on the driver.
          
          [default: 1MB]

  -n, --no-clobber
          Do not overwrite an existing file

  -f, --force
          Force (compatability only)
          
          Overwrite files; this is the default behaviour, this flag is for compatibility with `cp` only. See `--no-clobber` for the inverse flag. Using this in conjunction with `--no-clobber` will cause an error.

      --gitignore
          Use .gitignore if present.
          
          NOTE: This is fairly basic at the moment, and only honours a .gitignore in the directory root for directory copies; global or sub-directory ignores are skipped.

  -g, --glob
          Expand file patterns.
          
          Glob (expand) filename patterns natively (note; the shell may still do its own expansion first)

      --no-progress
          Disable progress bar

      --no-perms
          Do not copy the file permissions

      --no-timestamps
          Do not copy the file timestamps

  -o, --ownership
          Copy ownership.
          
          Whether to copy ownship (user/group).  This option requires root permissions or appropriate capabilities; if the attempt to copy ownership fails a warning is issued but the operation continues.

      --driver <DRIVER>
          Driver to use, defaults to 'file-parallel'.
          
          Currently there are 2; the default "parfile", which parallelises copies across workers at the file level, and an experimental "parblock" driver, which parellelises at the block level. See also '--block-size'.
          
          [default: parfile]

  -T, --no-target-directory
          Target should not be a directory.
          
          Analogous to cp's no-target-directory. Expected behavior is that when copying a directory to another directory, instead of creating a sub-folder in target, overwrite target.

      --target-directory <TARGET_DIRECTORY>
          Copy into a subdirectory of the target

      --fsync
          Sync each file to disk after writing

      --reflink <REFLINK>
          Reflink options.
          
          Whether and how to use reflinks. 'auto' (the default) will attempt to reflink and fallback to a copy if it is not possible, 'always' will return an error if it cannot reflink, and 'never' will always perform a full data copy.
          
          Note: when using Linux accelerated copy operations (the default when available) the kernel may choose to reflink rather than perform a fully copy regardless of this setting.
          
          [default: auto]

      --backup <BACKUP>
          Backup options
          
          Whether to create backups of overwritten files. Current options are 'none'/'off', or 'numbered', or 'auto'. Numbered backups follow the semantics of `cp` numbered backups (e.g. `file.txt.~123~`). 'auto' will only create a numbered backup if a previous backups exists. Default is 'none'.
          
          [default: none]

  -h, --help
          Print help (see a summary with '-h')

  -V, --version
          Print version
"""


class XcpError(Exception):
    pass


class Options:
    def __init__(self):
        self.recursive = False
        self.dereference = False
        self.no_clobber = False
        self.force = False
        self.glob = False
        self.no_perms = False
        self.no_timestamps = False
        self.no_target_directory = False
        self.target_directory = None
        self.backup = "none"
        self.gitignore = False
        self.fsync = False


def fail(message):
    print(f"Error: {message}", file=sys.stderr)
    return 1


def invalid_value(flag, value, message):
    print(f"error: invalid value '{value}' for '{flag}': {message}\n", file=sys.stderr)
    print("For more information, try '--help'.", file=sys.stderr)
    return 2


def parse_args(argv):
    opts = Options()
    paths = []
    i = 0
    while i < len(argv):
        arg = argv[i]
        if arg == "-h":
            print(HELP_SHORT, end="")
            raise SystemExit(0)
        if arg == "--help":
            print(HELP_LONG, end="")
            raise SystemExit(0)
        if arg in ("-V", "--version"):
            print(VERSION)
            raise SystemExit(0)
        if arg == "--":
            paths.extend(argv[i + 1 :])
            break
        if arg.startswith("--"):
            if arg == "--recursive":
                opts.recursive = True
            elif arg == "--dereference":
                opts.dereference = True
            elif arg == "--no-clobber":
                opts.no_clobber = True
            elif arg == "--force":
                opts.force = True
            elif arg == "--glob":
                opts.glob = True
            elif arg == "--no-progress":
                pass
            elif arg == "--no-perms":
                opts.no_perms = True
            elif arg == "--no-timestamps":
                opts.no_timestamps = True
            elif arg == "--no-target-directory":
                opts.no_target_directory = True
            elif arg == "--gitignore":
                opts.gitignore = True
            elif arg == "--fsync":
                opts.fsync = True
            elif arg in ("--workers", "--block-size"):
                i += 1
                if i >= len(argv):
                    return None, None, fail(f"Invalid arguments: {arg} requires a value.")
            elif arg == "--driver":
                i += 1
                if i >= len(argv):
                    return None, None, fail("Invalid arguments: --driver requires a value.")
                if argv[i] not in ("parfile", "file-parallel", "parblock"):
                    return None, None, invalid_value("--driver <DRIVER>", argv[i], f"Unknown driver: {argv[i]}")
            elif arg == "--backup":
                i += 1
                if i >= len(argv):
                    return None, None, fail("Invalid arguments: --backup requires a value.")
                opts.backup = argv[i]
                if opts.backup not in ("none", "off", "numbered", "auto"):
                    return None, None, invalid_value(
                        "--backup <BACKUP>",
                        opts.backup,
                        f"Invalid arguments: Unexpected value for 'backup': {opts.backup}",
                    )
            elif arg == "--reflink":
                i += 1
                if i >= len(argv):
                    return None, None, fail("Invalid arguments: --reflink requires a value.")
                if argv[i] not in ("auto", "always", "never"):
                    return None, None, invalid_value(
                        "--reflink <REFLINK>",
                        argv[i],
                        f"Invalid arguments: Unexpected value for 'reflink': {argv[i]}",
                    )
            elif arg == "--target-directory":
                i += 1
                if i >= len(argv):
                    return None, None, fail("Invalid arguments: --target-directory requires a value.")
                opts.target_directory = argv[i]
            else:
                return None, None, fail(f"Invalid arguments: unexpected argument '{arg}'")
        elif arg.startswith("-") and arg != "-":
            j = 1
            while j < len(arg):
                ch = arg[j]
                if ch == "r":
                    opts.recursive = True
                elif ch == "L":
                    opts.dereference = True
                elif ch == "n":
                    opts.no_clobber = True
                elif ch == "f":
                    opts.force = True
                elif ch == "g":
                    opts.glob = True
                elif ch == "T":
                    opts.no_target_directory = True
                elif ch == "o":
                    pass
                elif ch == "v":
                    pass
                elif ch == "w":
                    if j != len(arg) - 1:
                        i_value = arg[j + 1 :]
                        j = len(arg)
                    else:
                        i += 1
                        if i >= len(argv):
                            return None, None, fail("Invalid arguments: -w requires a value.")
                        i_value = argv[i]
                    try:
                        int(i_value)
                    except ValueError:
                        pass
                else:
                    return None, None, fail(f"Invalid arguments: unexpected argument '-{ch}'")
                j += 1
        else:
            paths.append(arg)
        i += 1
    return opts, paths, None


def copy_metadata(src, dst, opts, follow):
    if not opts.no_perms:
        try:
            mode = os.stat(src, follow_symlinks=follow).st_mode & 0o7777
            os.chmod(dst, mode, follow_symlinks=follow)
        except (OSError, NotImplementedError):
            pass
    if not opts.no_timestamps:
        try:
            st = os.stat(src, follow_symlinks=follow)
            os.utime(dst, ns=(st.st_atime_ns, st.st_mtime_ns), follow_symlinks=follow)
        except (OSError, NotImplementedError):
            pass


def next_backup_name(path):
    n = 1
    while True:
        candidate = Path(f"{path}.~{n}~")
        if not candidate.exists() and not candidate.is_symlink():
            return candidate
        n += 1


def maybe_backup(dst, opts):
    if not (dst.exists() or dst.is_symlink()):
        return
    backup_mode = opts.backup
    if backup_mode in ("none", "off"):
        return
    if backup_mode == "auto":
        first = Path(f"{dst}.~1~")
        if not first.exists():
            return
    os.replace(dst, next_backup_name(dst))


def remove_existing(path):
    if path.is_dir() and not path.is_symlink():
        shutil.rmtree(path)
    elif path.exists() or path.is_symlink():
        path.unlink()


def destination_exists_error(dst):
    print(
        f"Error: Destination Exists: Destination file exists and --no-clobber is set., {dst}",
        file=sys.stderr,
    )
    return 1


def copy_file(src, dst, opts):
    if dst.exists() or dst.is_symlink():
        if opts.no_clobber:
            return destination_exists_error(dst)
        maybe_backup(dst, opts)
        if dst.exists() or dst.is_symlink():
            remove_existing(dst)
    dst.parent.mkdir(parents=True, exist_ok=True)
    if src.is_symlink() and not opts.dereference:
        os.symlink(os.readlink(src), dst)
        copy_metadata(src, dst, opts, follow=False)
    else:
        shutil.copyfile(src, dst, follow_symlinks=True)
        copy_metadata(src, dst, opts, follow=True)
    if opts.fsync and dst.is_file():
        with open(dst, "rb") as handle:
            os.fsync(handle.fileno())
    return 0


def ignored_names(src_dir, opts):
    if not opts.gitignore:
        return set()
    ignore_file = src_dir / ".gitignore"
    if not ignore_file.exists():
        return set()
    names = set()
    for line in ignore_file.read_text(errors="ignore").splitlines():
        line = line.strip()
        if not line or line.startswith("#") or "/" in line or line.startswith("!"):
            continue
        names.add(line.rstrip("/"))
    return names


def copy_dir(src, dst, opts):
    if not opts.recursive:
        raise XcpError("Invalid source: Source is directory and --recursive not specified.")
    if dst.exists() and not dst.is_dir():
        if opts.no_clobber:
            return destination_exists_error(dst)
        maybe_backup(dst, opts)
        if dst.exists() or dst.is_symlink():
            remove_existing(dst)
    dst.mkdir(parents=True, exist_ok=True)
    ignored = ignored_names(src, opts)
    for root, dirs, files in os.walk(src, followlinks=opts.dereference):
        root_path = Path(root)
        dirs[:] = [d for d in dirs if d not in ignored]
        rel = root_path.relative_to(src)
        target_root = dst / rel
        target_root.mkdir(parents=True, exist_ok=True)
        copy_metadata(root_path, target_root, opts, follow=True)
        for name in files:
            if name in ignored:
                continue
            status = copy_file(root_path / name, target_root / name, opts)
            if status != 0:
                return status
    copy_metadata(src, dst, opts, follow=True)
    return 0


def expand_globs(paths):
    expanded = []
    for path in paths:
        if any(ch in path for ch in "*?["):
            matches = sorted(fnmatch.filter(os.listdir("."), path))
            expanded.extend(matches)
        else:
            expanded.append(path)
    return expanded


def copy_one(src_s, dst_s, opts, multiple):
    src = Path(src_s)
    dst_base = Path(dst_s)
    if not (src.exists() or src.is_symlink()):
        raise XcpError("Invalid source: Source does not exist.")
    if multiple or (dst_base.exists() and dst_base.is_dir() and not opts.no_target_directory):
        dst = dst_base / src.name
    else:
        dst = dst_base
    if src.is_dir() and not (src.is_symlink() and not opts.dereference):
        return copy_dir(src, dst, opts)
    return copy_file(src, dst, opts)


def main(argv=None):
    argv = list(sys.argv[1:] if argv is None else argv)
    parsed = parse_args(argv)
    opts, paths, early_status = parsed
    if early_status is not None:
        return early_status
    if opts.no_clobber and opts.force:
        return fail("Invalid arguments: --force and --noclobber cannot be set at the same time.")
    if opts.target_directory:
        paths.append(opts.target_directory)
    if opts.glob:
        paths = expand_globs(paths)
    if len(paths) < 2:
        return fail("Invalid arguments: Insufficient arguments")
    sources = paths[:-1]
    dest = paths[-1]
    multiple = len(sources) > 1
    if multiple and not Path(dest).is_dir():
        return fail("Invalid destination: Multiple sources and destination is not a directory.")
    try:
        for src in sources:
            status = copy_one(src, dest, opts, multiple)
            if status != 0:
                return status
    except XcpError as exc:
        return fail(str(exc))
    except OSError as exc:
        return fail(str(exc))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
