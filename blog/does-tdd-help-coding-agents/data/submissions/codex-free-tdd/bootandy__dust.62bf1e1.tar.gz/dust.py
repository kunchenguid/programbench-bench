#!/usr/bin/env python3
import argparse
import json
import os
import re
import stat
import sys
from dataclasses import dataclass, field


HELP = """Like du but more intuitive

Usage: executable [OPTIONS] [PATH]...

Arguments:
  [PATH]...
          Input files or directories

Options:
  -d, --depth <DEPTH>
          Depth to show

  -T, --threads <THREADS>
          Number of threads to use

      --config <FILE>
          Specify a config file to use

  -n, --number-of-lines <NUMBER>
          Number of lines of output to show. (Default is terminal_height - 10)

  -p, --full-paths
          Subdirectories will not have their path shortened

  -X, --ignore-directory <PATH>
          Exclude any file or directory with this path

  -I, --ignore-all-in-file <FILE>
          Exclude any file or directory with a regex matching that listed in this file, the file entries will be added to the ignore regexs provided by --invert_filter

  -L, --dereference-links
          dereference sym links - Treat sym links as directories and go into them

  -x, --limit-filesystem
          Only count the files and directories on the same filesystem as the supplied directory

  -s, --apparent-size
          Use file length instead of blocks

  -r, --reverse
          Print tree upside down (biggest highest)

  -c, --no-colors
          No colors will be printed (Useful for commands like: watch)

  -C, --force-colors
          Force colors print

  -b, --no-percent-bars
          No percent bars or percentages will be displayed

  -B, --bars-on-right
          percent bars moved to right side of screen

  -z, --min-size <MIN_SIZE>
          Minimum size file to include in output

  -R, --screen-reader
          For screen readers. Removes bars. Adds new column: depth level (May want to use -p too for full path)

      --skip-total
          No total row will be displayed

  -f, --filecount
          Directory 'size' is number of child files instead of disk size

  -i, --ignore-hidden
          Do not display hidden files

  -v, --invert-filter <REGEX>
          Exclude filepaths matching this regex. To ignore png files type: -v "\\.png$"

  -e, --filter <REGEX>
          Only include filepaths matching this regex. For png files type: -e "\\.png$"

  -t, --file-types
          show only these file types

  -w, --terminal-width <WIDTH>
          Specify width of output overriding the auto detection of terminal width

  -P, --no-progress
          Disable the progress indication

      --print-errors
          Print path with errors

  -D, --only-dir
          Only directories will be displayed

  -F, --only-file
          Only files will be displayed. (Finds your largest files)

  -o, --output-format <FORMAT>
          Changes output display size. si will print sizes in powers of 1000. b k m g t kb mb gb tb will print the whole tree in that size

  -S, --stack-size <STACK_SIZE>
          Specify memory to use as stack size - use if you see: 'fatal runtime error: stack overflow' (default low memory=1048576, high memory=1073741824)

  -j, --output-json
          Output the directory tree as json to the current directory

  -M, --mtime <MTIME>
          +/-n matches files modified more/less than n days ago , and n matches files modified exactly n days ago, days are rounded down.That is +n => (−∞, curr−(n+1)), n => [curr−(n+1), curr−n), and -n => (𝑐𝑢𝑟𝑟−𝑛, +∞)

  -A, --atime <ATIME>
          just like -mtime, but based on file access time

  -y, --ctime <CTIME>
          just like -mtime, but based on file change time

      --files0-from <FILES0_FROM>
          Read NUL-terminated paths from FILE (use `-` for stdin)

      --files-from <FILES_FROM>
          Read newline-terminated paths from FILE (use `-` for stdin)

      --collapse <COLLAPSE>
          Keep these directories collapsed

  -m, --filetime <FILETIME>
          Directory 'size' is max filetime of child files instead of disk size. while a/c/m for last accessed/changed/modified time

  -h, --help
          Print help (see a summary with '-h')

  -V, --version
          Print version
"""


@dataclass
class Node:
    path: str
    size: int
    is_dir: bool
    children: list = field(default_factory=list)


def parse_args(argv):
    if "-V" in argv or "--version" in argv:
        print("Dust 1.2.3")
        raise SystemExit(0)
    if "-h" in argv or "--help" in argv:
        print(HELP, end="")
        raise SystemExit(0)
    p = argparse.ArgumentParser(add_help=False)
    p.add_argument("-d", "--depth", type=int)
    p.add_argument("-T", "--threads")
    p.add_argument("--config")
    p.add_argument("-n", "--number-of-lines", type=int, default=10_000)
    p.add_argument("-p", "--full-paths", action="store_true")
    p.add_argument("-X", "--ignore-directory", action="append", default=[])
    p.add_argument("-I", "--ignore-all-in-file")
    p.add_argument("-L", "--dereference-links", action="store_true")
    p.add_argument("-x", "--limit-filesystem", action="store_true")
    p.add_argument("-s", "--apparent-size", action="store_true")
    p.add_argument("-r", "--reverse", action="store_true")
    p.add_argument("-c", "--no-colors", action="store_true")
    p.add_argument("-C", "--force-colors", action="store_true")
    p.add_argument("-b", "--no-percent-bars", action="store_true")
    p.add_argument("-B", "--bars-on-right", action="store_true")
    p.add_argument("-z", "--min-size")
    p.add_argument("-R", "--screen-reader", action="store_true")
    p.add_argument("--skip-total", action="store_true")
    p.add_argument("-f", "--filecount", action="store_true")
    p.add_argument("-i", "--ignore-hidden", action="store_true")
    p.add_argument("-v", "--invert-filter", action="append", default=[])
    p.add_argument("-e", "--filter", action="append", default=[])
    p.add_argument("-t", "--file-types", action="store_true")
    p.add_argument("-w", "--terminal-width")
    p.add_argument("-P", "--no-progress", action="store_true")
    p.add_argument("--print-errors", action="store_true")
    p.add_argument("-D", "--only-dir", action="store_true")
    p.add_argument("-F", "--only-file", action="store_true")
    p.add_argument("-o", "--output-format", default="")
    p.add_argument("-S", "--stack-size")
    p.add_argument("-j", "--output-json", action="store_true")
    p.add_argument("-M", "--mtime")
    p.add_argument("-A", "--atime")
    p.add_argument("-y", "--ctime")
    p.add_argument("--files0-from")
    p.add_argument("--files-from")
    p.add_argument("--collapse", action="append", default=[])
    p.add_argument("-m", "--filetime")
    p.add_argument("paths", nargs="*")
    return p.parse_args(argv)


def read_list_file(path, nul):
    if path == "-":
        data = sys.stdin.buffer.read()
    else:
        with open(path, "rb") as f:
            data = f.read()
    parts = data.split(b"\0" if nul else b"\n")
    return [p.decode() for p in parts if p]


def raw_size(path, st, apparent, filecount):
    if filecount:
        return 1 if stat.S_ISREG(st.st_mode) else 0
    if apparent:
        return st.st_size
    return getattr(st, "st_blocks", 0) * 512


def should_ignore(path, name, args):
    if args.ignore_hidden and name.startswith("."):
        return True
    for ignored in args.ignore_directory:
        if path == ignored or name == ignored or path.endswith("/" + ignored):
            return True
    for pat in args.invert_filter:
        if re.search(pat, path):
            return True
    return False


def build(path, args):
    try:
        st = os.stat(path) if args.dereference_links else os.lstat(path)
    except OSError as e:
        if args.print_errors:
            print(f"Did not have permissions for: {path}", file=sys.stderr)
        return None
    name = os.path.basename(path.rstrip("/")) or path
    if should_ignore(path, name, args):
        return None
    is_dir = stat.S_ISDIR(st.st_mode)
    own = raw_size(path, st, args.apparent_size, args.filecount)
    node = Node(path=os.path.abspath(path), size=own, is_dir=is_dir)
    if is_dir:
        try:
            entries = sorted(os.listdir(path))
        except OSError:
            entries = []
        for entry in entries:
            child = build(os.path.join(path, entry), args)
            if child is not None:
                node.children.append(child)
                node.size += child.size
    if args.filter:
        matches = any(re.search(pat, node.path) for pat in args.filter)
        if is_dir:
            node.children = [c for c in node.children if c is not None]
            if not node.children and not matches:
                return None
            if not matches:
                node.size = sum(c.size for c in node.children)
        elif not matches:
            return None
    node.children.sort(key=lambda n: (n.size, n.path))
    return node


def size_floor(text):
    if not text:
        return 0
    m = re.match(r"(?i)^\s*(\d+(?:\.\d+)?)([kmgt]?b?|)\s*$", text)
    if not m:
        return 0
    val = float(m.group(1))
    unit = m.group(2).lower()
    mult = {"": 1, "b": 1, "k": 1024, "kb": 1024, "m": 1024**2, "mb": 1024**2,
            "g": 1024**3, "gb": 1024**3, "t": 1024**4, "tb": 1024**4}
    return int(val * mult.get(unit, 1))


def format_size(num, mode, filecount=False):
    if filecount:
        return str(num)
    if mode == "b":
        return f"{num}B"
    fixed = {
        "k": (1024, "K"), "m": (1024**2, "M"), "g": (1024**3, "G"), "t": (1024**4, "T"),
        "kb": (1024, "K"), "mb": (1024**2, "M"), "gb": (1024**3, "G"), "tb": (1024**4, "T"),
    }
    if mode in fixed:
        div, suffix = fixed[mode]
        return f"{int(num / div)}{suffix}"
    base = 1000 if mode in ("si", "kb", "mb", "gb", "tb") else 1024
    units = ["B", "K", "M", "G", "T"]
    n = float(num)
    idx = 0
    while idx < len(units) - 1 and n >= base:
        n /= base
        idx += 1
    if idx == 0:
        return f"{int(n)}B"
    if n < 10:
        return f"{n:.1f}{units[idx]}"
    return f"{n:.0f}{units[idx]}"


def display_name(node, full):
    return node.path if full else os.path.basename(node.path.rstrip("/")) or node.path


def visible_lines(node, args, depth=0, flags=(), is_first=True):
    if args.depth is not None and depth > args.depth:
        return []
    child_rows = []
    if not (args.collapse and os.path.basename(node.path) in args.collapse):
        child_flag = len(node.children) > 1 and not (args.filecount and depth >= 1)
        for idx, child in enumerate(node.children):
            child_rows.extend(visible_lines(child, args, depth + 1, flags + (child_flag,), idx == 0))
    show = True
    if args.only_file and node.is_dir and depth != 0:
        show = False
    if args.only_dir and (not node.is_dir) and depth != 0:
        show = False
    if args.min_size and node.size < size_floor(args.min_size):
        show = False
    lines = child_rows
    if show and not (args.skip_total and depth == 0):
        lines.append((node, depth, flags, bool(child_rows), is_first))
    return lines


def collect_files(node):
    if not node.is_dir:
        return [node]
    found = []
    for child in node.children:
        found.extend(collect_files(child))
    return found


def visible_dir_lines(node, args, depth=0, flags=(), is_first=True):
    raw = []
    for child in node.children:
        if child.is_dir or os.path.islink(child.path):
            raw.append(child)
        elif child.children:
            raw.append(child)
    child_rows = []
    visible_children = [c for c in raw if c.is_dir or os.path.islink(c.path)]
    for idx, child in enumerate(visible_children):
        child_rows.extend(visible_dir_lines(child, args, depth + 1, flags + (len(visible_children) > 1,), idx == 0))
    if args.min_size and node.size < size_floor(args.min_size):
        return child_rows
    if args.depth is not None and depth > args.depth:
        return []
    rows = child_rows
    if not (args.skip_total and depth == 0):
        rows.append((node, depth, flags, bool(child_rows), is_first))
    return rows


def connector(node, depth, flags, has_display_children, is_first, reverse=False):
    if depth == 0:
        return "└─┬" if reverse else "┌─┴"
    parts = []
    for has_siblings in flags[:-1]:
        parts.append("│ " if has_siblings else "  ")
    start = "┌" if is_first else "├"
    if has_display_children:
        if reverse:
            parts.append(("└" if is_first else "├") + "─┬")
        else:
            parts.append(start + "─┴")
    else:
        parts.append(("└" if is_first and reverse else start) + "──")
    return "".join(parts)


def print_tree(roots, args):
    rows = []
    if args.only_file:
        for root in roots:
            files = sorted(collect_files(root), key=lambda n: (n.size, n.path))
            for idx, node in enumerate(files):
                if not args.min_size or node.size >= size_floor(args.min_size):
                    rows.append((node, 1, (len(files) > 1,), False, idx == 0))
            if not args.skip_total:
                rows.append((root, 0, (), True, True))
    elif args.only_dir:
        for root in roots:
            rows.extend(visible_dir_lines(root, args))
    else:
        for root in roots:
            rows.extend(visible_lines(root, args))
    if args.reverse:
        rows = list(reversed(rows))
    if args.number_of_lines:
        rows = rows[-args.number_of_lines:] if not args.reverse else rows[:args.number_of_lines]
    if args.screen_reader:
        print_screen_reader(rows, args)
        return
    widths = [len(format_size(n.size, args.output_format, args.filecount)) for n, _, _, _, _ in rows] or [0]
    width = max(widths)
    out = []
    for node, depth, flags, has_display_children, is_first in rows:
        s = format_size(node.size, args.output_format, args.filecount).rjust(width)
        sep = " " if depth == 0 else "   "
        out.append(f"{s}{sep}{connector(node, depth, flags, has_display_children, is_first, args.reverse)} {display_name(node, args.full_paths)}")
    if not args.no_progress and not args.output_json:
        sys.stderr.write("\r \r")
    sys.stdout.write("\n".join(out))
    if out:
        sys.stdout.write("\n")


def print_screen_reader(rows, args):
    total = max((n.size for n, depth, _, _, _ in rows if depth == 0), default=max((n.size for n, _, _, _, _ in rows), default=1))
    name_width = max((len(display_name(n, args.full_paths)) for n, _, _, _, _ in rows), default=0)
    size_width = max((len(format_size(n.size, args.output_format, args.filecount)) for n, _, _, _, _ in rows), default=0)
    if not args.no_progress:
        sys.stderr.write("\r \r")
    out = []
    for node, depth, _, _, _ in rows:
        name = display_name(node, args.full_paths).ljust(name_width)
        size = format_size(node.size, args.output_format, args.filecount).rjust(size_width)
        pct = 0 if total == 0 else int(node.size * 100 / total)
        out.append(f"{name} {depth} {size} {pct:>3}%")
    sys.stdout.write("\n".join(out))
    if out:
        sys.stdout.write("\n")


def to_json(node):
    return {
        "size": format_size(node.size, ""),
        "name": node.path,
        "children": [to_json(c) for c in sorted(node.children, key=lambda n: (-n.size, n.path))],
    }


def main(argv):
    args = parse_args(argv)
    paths = list(args.paths)
    if args.files_from:
        paths.extend(read_list_file(args.files_from, False))
    if args.files0_from:
        paths.extend(read_list_file(args.files0_from, True))
    if not paths:
        paths = ["."]
    missing = [path for path in paths if not os.path.lexists(path)]
    for path in missing:
        if not args.no_progress:
            sys.stderr.write("\r \r")
        print(f"No such file or directory: {path}", file=sys.stderr)
    roots = [n for n in (build(path, args) for path in paths if os.path.lexists(path)) if n is not None]
    if missing and not roots:
        return 1
    if args.output_json:
        if not args.no_progress:
            sys.stderr.write("\r \r")
        payload = to_json(roots[0]) if len(roots) == 1 else [to_json(r) for r in roots]
        print(json.dumps(payload, separators=(",", ":")))
    else:
        print_tree(roots, args)
    return 0


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
