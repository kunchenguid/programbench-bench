#!/bin/bash
set -euo pipefail

BIN="${BIN:-./executable}"

fail() {
  printf 'FAIL: %s\n' "$1" >&2
  exit 1
}

run_capture() {
  local out status
  set +e
  out="$("$BIN" "$@" 2>&1)"
  status=$?
  printf '%s' "$out" > /tmp/ngrrram-test.out
  return "$status"
}

assert_status() {
  local expected="$1"
  local actual="$2"
  [[ "$actual" == "$expected" ]] || fail "expected status $expected, got $actual; output: $(cat /tmp/ngrrram-test.out)"
}

assert_contains() {
  local needle="$1"
  grep -Fq -- "$needle" /tmp/ngrrram-test.out || fail "missing '$needle' in: $(cat /tmp/ngrrram-test.out)"
}

set +e
run_capture --help
status=$?
set -e
assert_status 0 "$status"
assert_contains 'Usage: executable [OPTIONS]'
assert_contains "-n, --n <2|3|4|w|file>  use bi-(2), tri-(3), tetragrams(4), (w)ords or comma separated wordlist file. [default: 2]"
assert_contains '      --cat               the most important flag. don'

set +e
run_capture --version
status=$?
set -e
assert_status 2 "$status"
assert_contains "error: unexpected argument '--version' found"
assert_contains "For more information, try '--help'."

for case in "--top 0|Invalid argument for top. Use a number between 1 and 200." \
            "--top 201|Invalid argument for top. Use a number between 1 and 200." \
            "--combi 0|Invalid argument for combi. Use a number between 1 and 200." \
            "--rep 0|Invalid argument for rep. Use a number between 1 and 200." \
            "--wpm 0|Invalid argument for wpm. Use a number between 1 and 200." \
            "--acc 101|Invalid argument for acc. Use a number between 0 and 100."; do
  args="${case%%|*}"
  msg="${case#*|}"
  set +e
  # shellcheck disable=SC2086
  run_capture $args
  status=$?
  set -e
  assert_status 1 "$status"
  assert_contains "$msg"
done

set +e
run_capture --wpm abc
status=$?
set -e
assert_status 2 "$status"
assert_contains "error: invalid value 'abc' for '--wpm <number>': invalid digit found in string"

set +e
run_capture --wpm -1
status=$?
set -e
assert_status 2 "$status"
assert_contains "error: unexpected argument '-1' found"

set +e
run_capture --emu-in qwerty
status=$?
set -e
assert_status 1 "$status"
assert_contains 'You need to specify both emu_in and emu_out.'

set +e
run_capture --n /tmp/ngrrram-definitely-missing
status=$?
set -e
assert_status 1 "$status"
assert_contains 'File not found: /tmp/ngrrram-definitely-missing'

set +e
run_capture --n 2 --top 1 --combi 1 --rep 1 --nokb
status=$?
set -e
assert_status 1 "$status"
assert_contains 'Error: Os { code: 6, kind: Uncategorized, message: "No such device or address" }'

printf '\033' >/tmp/ngrrram-keys
timeout 2 script -q -e -c "stty rows 30 cols 100; TERM=xterm $BIN --n 2 --top 1 --combi 1 --rep 1 --nokb" /tmp/ngrrram-ui.out < /tmp/ngrrram-keys >/tmp/ngrrram-ui.stdout 2>/tmp/ngrrram-ui.stderr || true
grep -aq 'ngrrram!' /tmp/ngrrram-ui.out || fail 'UI did not show title'
grep -aq 'Lesson' /tmp/ngrrram-ui.out || fail 'UI did not show lesson label'
grep -aq 'th' /tmp/ngrrram-ui.out || fail 'UI did not show top bigram lesson'
