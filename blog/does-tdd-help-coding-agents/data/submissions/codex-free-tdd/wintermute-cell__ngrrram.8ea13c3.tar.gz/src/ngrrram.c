#include <errno.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/select.h>
#include <termios.h>
#include <unistd.h>

typedef struct {
    const char *n;
    int top;
    int combi;
    int rep;
    int wpm;
    int acc;
    const char *emu_in;
    const char *emu_out;
    int show_ortho;
    int nokb;
    int cat;
} Options;

static const char *bigrams[] = {
    "th", "he", "in", "er", "an", "re", "on", "at", "en", "nd",
    "ti", "es", "or", "te", "of", "ed", "is", "it", "al", "ar"
};
static const char *trigrams[] = {"the", "and", "ing", "ion", "ent", "her"};
static const char *tetragrams[] = {"tion", "ther", "with", "here", "ould"};
static const char *words[] = {"the", "of", "and", "to", "in", "a", "is", "that"};

static void print_help(void) {
    puts("Usage: executable [OPTIONS]");
    puts("");
    puts("Options:");
    puts("  -n, --n <2|3|4|w|file>  use bi-(2), tri-(3), tetragrams(4), (w)ords or comma separated wordlist file. [default: 2]");
    puts("  -t, --top <1-200>       use the top X ngrams ordered by usage. [default: 50]");
    puts("  -c, --combi <1-200>     how many different ngrams to use in a single lesson. [default: 2]");
    puts("  -r, --rep <number>      how often to repeat *each* different ngram in a lesson. [default: 3]");
    puts("  -w, --wpm <number>      the wpm threshold at which the lesson is considered a success. [default: 40]");
    puts("  -a, --acc <0-100>       the accuracy in percent at which the lesson is considered a success. [default: 94]");
    puts("      --emu-in <layout>   your current keyboard layout. only needed if you want to emulate a different layout. see docs for supported layouts. [default: ]");
    puts("      --emu-out <layout>  the layout you want to emulate. only needed if you want to emulate a different layout. see docs for supported layouts. [default: ]");
    puts("      --show-ortho        show keyboard in ortholinear format");
    puts("      --nokb              pass this flag to disable the keyboard layout display.");
    puts("      --cat               the most important flag. don't practice alone.");
    puts("  -h, --help              Print help");
}

static int is_number(const char *s) {
    if (!s || !*s) return 0;
    for (const unsigned char *p = (const unsigned char *)s; *p; p++) {
        if (*p < '0' || *p > '9') return 0;
    }
    return 1;
}

static int parse_num(const char *flag, const char *display, const char *s, int *out) {
    if (!is_number(s)) {
        fprintf(stderr, "error: invalid value '%s' for '%s': invalid digit found in string\n\n", s, display);
        fprintf(stderr, "For more information, try '--help'.\n");
        return 2;
    }
    *out = atoi(s);
    (void)flag;
    return 0;
}

static int need_value(int i, int argc, const char *flag) {
    if (i + 1 < argc) return 0;
    fprintf(stderr, "error: a value is required for '%s <value>' but none was supplied\n\n", flag);
    fprintf(stderr, "For more information, try '--help'.\n");
    return 2;
}

static int reject_dash_value(const char *value) {
    if (value[0] != '-') return 0;
    fprintf(stderr, "error: unexpected argument '%s' found\n\n", value);
    fprintf(stderr, "Usage: executable [OPTIONS]\n\n");
    fprintf(stderr, "For more information, try '--help'.\n");
    return 2;
}

static int parse_args(int argc, char **argv, Options *o) {
    *o = (Options){.n = "2", .top = 50, .combi = 2, .rep = 3, .wpm = 40, .acc = 94, .emu_in = "", .emu_out = ""};
    for (int i = 1; i < argc; i++) {
        const char *a = argv[i];
        if (!strcmp(a, "-h") || !strcmp(a, "--help")) {
            print_help();
            exit(0);
        } else if (!strcmp(a, "-n") || !strcmp(a, "--n")) {
            int e = need_value(i, argc, a);
            if (e) return e;
            e = reject_dash_value(argv[i + 1]);
            if (e) return e;
            o->n = argv[++i];
        } else if (!strcmp(a, "-t") || !strcmp(a, "--top")) {
            int e = need_value(i, argc, a);
            if (e) return e;
            e = reject_dash_value(argv[i + 1]);
            if (e) return e;
            e = parse_num(a, "--top <1-200>", argv[++i], &o->top);
            if (e) return e;
        } else if (!strcmp(a, "-c") || !strcmp(a, "--combi")) {
            int e = need_value(i, argc, a);
            if (e) return e;
            e = reject_dash_value(argv[i + 1]);
            if (e) return e;
            e = parse_num(a, "--combi <1-200>", argv[++i], &o->combi);
            if (e) return e;
        } else if (!strcmp(a, "-r") || !strcmp(a, "--rep")) {
            int e = need_value(i, argc, a);
            if (e) return e;
            e = reject_dash_value(argv[i + 1]);
            if (e) return e;
            e = parse_num(a, "--rep <number>", argv[++i], &o->rep);
            if (e) return e;
        } else if (!strcmp(a, "-w") || !strcmp(a, "--wpm")) {
            int e = need_value(i, argc, a);
            if (e) return e;
            e = reject_dash_value(argv[i + 1]);
            if (e) return e;
            e = parse_num(a, "--wpm <number>", argv[++i], &o->wpm);
            if (e) return e;
        } else if (!strcmp(a, "-a") || !strcmp(a, "--acc")) {
            int e = need_value(i, argc, a);
            if (e) return e;
            e = reject_dash_value(argv[i + 1]);
            if (e) return e;
            e = parse_num(a, "--acc <0-100>", argv[++i], &o->acc);
            if (e) return e;
        } else if (!strcmp(a, "--emu-in")) {
            int e = need_value(i, argc, a);
            if (e) return e;
            e = reject_dash_value(argv[i + 1]);
            if (e) return e;
            o->emu_in = argv[++i];
        } else if (!strcmp(a, "--emu-out")) {
            int e = need_value(i, argc, a);
            if (e) return e;
            e = reject_dash_value(argv[i + 1]);
            if (e) return e;
            o->emu_out = argv[++i];
        } else if (!strcmp(a, "--show-ortho")) {
            o->show_ortho = 1;
        } else if (!strcmp(a, "--nokb")) {
            o->nokb = 1;
        } else if (!strcmp(a, "--cat")) {
            o->cat = 1;
        } else if (a[0] == '-') {
            fprintf(stderr, "error: unexpected argument '%s' found\n\n", a);
            fprintf(stderr, "Usage: executable [OPTIONS]\n\n");
            fprintf(stderr, "For more information, try '--help'.\n");
            return 2;
        } else {
            fprintf(stderr, "error: unexpected argument '%s' found\n\n", a);
            fprintf(stderr, "Usage: executable [OPTIONS]\n\n");
            fprintf(stderr, "For more information, try '--help'.\n");
            return 2;
        }
    }
    return 0;
}

static int validate(const Options *o) {
    if (o->top < 1 || o->top > 200) {
        puts("Invalid argument for top. Use a number between 1 and 200.");
        return 1;
    }
    if (o->combi < 1 || o->combi > 200) {
        puts("Invalid argument for combi. Use a number between 1 and 200.");
        return 1;
    }
    if (o->rep < 1 || o->rep > 200) {
        puts("Invalid argument for rep. Use a number between 1 and 200.");
        return 1;
    }
    if (o->wpm < 1 || o->wpm > 200) {
        puts("Invalid argument for wpm. Use a number between 1 and 200.");
        return 1;
    }
    if (o->acc < 0 || o->acc > 100) {
        puts("Invalid argument for acc. Use a number between 0 and 100.");
        return 1;
    }
    if ((o->emu_in[0] && !o->emu_out[0]) || (!o->emu_in[0] && o->emu_out[0])) {
        puts("You need to specify both emu_in and emu_out.");
        return 1;
    }
    if (strcmp(o->n, "2") && strcmp(o->n, "3") && strcmp(o->n, "4") && strcmp(o->n, "w")) {
        if (access(o->n, R_OK) != 0) {
            printf("File not found: %s\n", o->n);
            return 1;
        }
    }
    return 0;
}

static const char *lesson_word(const Options *o) {
    if (!strcmp(o->n, "3")) return trigrams[0];
    if (!strcmp(o->n, "4")) return tetragrams[0];
    if (!strcmp(o->n, "w")) return words[0];
    if (strcmp(o->n, "2")) {
        static char buf[256];
        FILE *f = fopen(o->n, "r");
        if (f) {
            size_t n = fread(buf, 1, sizeof(buf) - 1, f);
            fclose(f);
            buf[n] = 0;
            char *comma = strchr(buf, ',');
            char *nl = strchr(buf, '\n');
            char *end = comma && (!nl || comma < nl) ? comma : nl;
            if (end) *end = 0;
            if (buf[0]) return buf;
        }
    }
    return bigrams[0];
}

static void draw_keyboard(int ortho, int cat) {
    if (cat) {
        puts(" /\\_/\\\\");
        puts("( o.o )");
        puts(" > ^ <");
    }
    if (ortho) {
        puts("q w e r t y u i o p");
        puts("a s d f g h j k l ;");
        puts("z x c v b n m , . /");
    } else {
        puts("` 1 2 3 4 5 6 7 8 9 0 - =");
        puts("  q w e r t y u i o p [ ]");
        puts("   a s d f g h j k l ; '");
        puts("    z x c v b n m , . /");
    }
}

static void restore_term(struct termios *old, int changed) {
    if (changed) tcsetattr(STDIN_FILENO, TCSANOW, old);
    printf("\033[39m\033[49m\033[59m\033[0m\033[?25h\033[?1049l");
    fflush(stdout);
}

static int run_ui(const Options *o) {
    const char *word = lesson_word(o);
    struct termios old, raw;
    int changed = 0;
    if (!isatty(STDIN_FILENO)) {
        printf("\033[?1049h");
        fprintf(stderr, "Error: Os { code: 6, kind: Uncategorized, message: \"No such device or address\" }\n");
        return 1;
    }
    if (tcgetattr(STDIN_FILENO, &old) == 0) {
        raw = old;
        raw.c_lflag &= (tcflag_t) ~(ICANON | ECHO);
        raw.c_cc[VMIN] = 0;
        raw.c_cc[VTIME] = 1;
        if (tcsetattr(STDIN_FILENO, TCSANOW, &raw) == 0) changed = 1;
    }

    printf("\033[?1049h\033[2J\033[1;1H\033[?25l");
    puts("╭──────────────────────────────────────────────────────────────────Quit \033[1m\033[38;5;4m<esc>\033[22m\033[39m ╮");
    puts("│                    \033[1m               ngrrram!\033[22m\033[3m\033[38;5;7m   by winterveil\033[23m\033[39m │");
    puts("├──────────────────────────────────────────────────────────────────────────────┤");
    printf("│     Lesson  #0                                                   \033[38;5;2m✔: 0, \033[38;5;1m✘: 0\033[39m    │\n");
    puts("├──────────────────────────────────────────────────────────────────────────────┤");
    printf("│                                      \033[1m%s \033[22m                                      │\n", word);
    puts("│                                                                              │");
    puts("│                                                                              │");
    puts("├──────────────────────────────────────────────────────────────────────────────┤");
    printf("│  \033[38;5;7mneed >= %3dWPM,   avg. \033[39m0WPM\033[38;5;7m,   last\033[39m0WPM                         │\n", o->wpm);
    printf("│  \033[38;5;7mneed >= %3d%% Acc, avg. \033[39m0%% Acc\033[38;5;7m, last\033[39m0%% Acc                       │\n", o->acc);
    puts("╰──────────────────────────────────────────────────────────────────────────────╯");
    if (!o->nokb) draw_keyboard(o->show_ortho, o->cat);
    fflush(stdout);

    int typed = 0;
    while (1) {
        fd_set rfds;
        FD_ZERO(&rfds);
        FD_SET(STDIN_FILENO, &rfds);
        struct timeval tv = {.tv_sec = 0, .tv_usec = 100000};
        int rv = select(STDIN_FILENO + 1, &rfds, NULL, NULL, &tv);
        if (rv > 0) {
            unsigned char c;
            ssize_t n = read(STDIN_FILENO, &c, 1);
            if (n <= 0) break;
            if (c == 27) break;
            if (c == '\r' || c == '\n') continue;
            if (word[typed] && c == (unsigned char)word[typed]) {
                printf("\033[38;5;2m%c\033[39m", c);
                typed++;
            } else {
                printf("\033[38;5;1m%c\033[39m", c);
            }
            fflush(stdout);
            if (!word[typed]) typed = 0;
        } else if (!isatty(STDIN_FILENO)) {
            break;
        }
    }
    restore_term(&old, changed);
    return 0;
}

int main(int argc, char **argv) {
    Options opts;
    int e = parse_args(argc, argv, &opts);
    if (e) return e;
    e = validate(&opts);
    if (e) return e;
    return run_ui(&opts);
}
