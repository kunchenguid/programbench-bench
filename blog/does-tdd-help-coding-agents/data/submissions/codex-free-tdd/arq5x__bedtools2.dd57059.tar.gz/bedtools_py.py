#!/usr/bin/env python3
import gzip
import math
import os
import random
import statistics
import sys
from collections import Counter, defaultdict


VERSION = "b2e3657"


class Rec:
    __slots__ = ("fields", "chrom", "start", "end")

    def __init__(self, fields):
        self.fields = fields
        self.chrom = fields[0]
        self.start = int(fields[1])
        self.end = int(fields[2])

    def line(self):
        return "\t".join(self.fields)

    def copy_interval(self, start, end):
        f = self.fields[:]
        f[1] = str(start)
        f[2] = str(end)
        return Rec(f)


def die(msg, code=1):
    if msg:
        print(msg, file=sys.stderr)
    sys.exit(code)


def main_help():
    print("""bedtools is a powerful toolset for genome arithmetic.

Version:   b2e3657
About:     developed in the quinlanlab.org and by many contributors worldwide.
Docs:      http://bedtools.readthedocs.io/
Code:      https://github.com/arq5x/bedtools2
Mail:      https://groups.google.com/forum/#!forum/bedtools-discuss

Usage:     bedtools <subcommand> [options]

The bedtools sub-commands include:

[ Genome arithmetic ]
    intersect     Find overlapping intervals in various ways.
    window        Find overlapping intervals within a window around an interval.
    closest       Find the closest, potentially non-overlapping interval.
    coverage      Compute the coverage over defined intervals.
    map           Apply a function to a column for each overlapping interval.
    genomecov     Compute the coverage over an entire genome.
    merge         Combine overlapping/nearby intervals into a single interval.
    cluster       Cluster (but don't merge) overlapping/nearby intervals.
    complement    Extract intervals _not_ represented by an interval file.
    shift         Adjust the position of intervals.
    subtract      Remove intervals based on overlaps b/w two files.
    slop          Adjust the size of intervals.
    flank         Create new intervals from the flanks of existing intervals.
    sort          Order the intervals in a file.
    random        Generate random intervals in a genome.
    shuffle       Randomly redistribute intervals in a genome.
    sample        Sample random records from file using reservoir sampling.
    spacing       Report the gap lengths between intervals in a file.
    annotate      Annotate coverage of features from multiple files.

[ Miscellaneous tools ]
    makewindows   Make interval "windows" across a genome.
    groupby       Group by common cols. & summarize oth. cols. (~ SQL "groupBy")
""")


def open_text(path):
    if path in ("-", "stdin", None):
        return sys.stdin
    if path.endswith(".gz"):
        return gzip.open(path, "rt")
    return open(path, "rt", encoding="utf-8")


def read_records(path):
    out = []
    with open_text(path) as fh:
        for line in fh:
            line = line.rstrip("\n")
            if not line or line.startswith("#") or line.startswith("track") or line.startswith("browser"):
                continue
            f = line.split("\t") if "\t" in line else line.split()
            if len(f) >= 3:
                try:
                    out.append(Rec(f))
                except ValueError:
                    continue
    return out


def read_genome(path):
    out = []
    with open_text(path) as fh:
        for line in fh:
            if not line.strip() or line.startswith("#"):
                continue
            f = line.split()
            if len(f) >= 2:
                out.append((f[0], int(f[1])))
    return out


def opt_value(args, names, default=None):
    if isinstance(names, str):
        names = [names]
    for i, a in enumerate(args):
        if a in names and i + 1 < len(args):
            return args[i + 1]
    return default


def has(args, name):
    return name in args


def chrom_key(chrom):
    c = chrom[3:] if chrom.startswith("chr") else chrom
    if c.isdigit():
        return (0, int(c))
    special = {"X": 1000, "Y": 1001, "M": 1002, "MT": 1002}
    return (1, special.get(c, 2000), chrom)


def by_chrom(records):
    d = defaultdict(list)
    for r in records:
        d[r.chrom].append(r)
    return d


def overlap_len(a, b):
    if a.chrom != b.chrom:
        return 0
    return max(0, min(a.end, b.end) - max(a.start, b.start))


def strand_ok(a, b, same=False, diff=False):
    sa = a.fields[5] if len(a.fields) > 5 else "."
    sb = b.fields[5] if len(b.fields) > 5 else "."
    if same:
        return sa == sb
    if diff:
        return sa != sb
    return True


def passes(a, b, args):
    ov = overlap_len(a, b)
    if ov <= 0 or not strand_ok(a, b, has(args, "-s") or has(args, "-sm"), has(args, "-S") or has(args, "-Sm")):
        return False
    fa = float(opt_value(args, "-f", "1e-9"))
    fb = float(opt_value(args, "-F", "1e-9"))
    af = ov / max(1, a.end - a.start)
    bf = ov / max(1, b.end - b.start)
    if has(args, "-e"):
        return af >= fa or bf >= fb
    return af >= fa and bf >= fb


def out(fields):
    print("\t".join(map(str, fields)))


def cmd_intersect(args):
    a = read_records(opt_value(args, "-a"))
    bpaths = []
    if "-b" in args:
        i = args.index("-b") + 1
        while i < len(args) and not args[i].startswith("-"):
            bpaths.append(args[i])
            i += 1
    bsets = [read_records(p) for p in bpaths]
    allb = [r for s in bsets for r in s]
    bd = by_chrom(allb)
    wao = has(args, "-wao")
    loj = has(args, "-loj")
    for ar in a:
        hits = [br for br in bd.get(ar.chrom, []) if passes(ar, br, args)]
        if has(args, "-c"):
            out(ar.fields + [len(hits)])
        elif has(args, "-C"):
            for idx, bs in enumerate(bsets, 1):
                c = sum(1 for br in bs if passes(ar, br, args))
                out(ar.fields + ([idx, c] if len(bsets) > 1 else [c]))
        elif has(args, "-v"):
            if not hits:
                out(ar.fields)
        elif has(args, "-u"):
            if hits:
                out(ar.fields)
        elif hits:
            seen = False
            for br in hits:
                seen = True
                ov = overlap_len(ar, br)
                if has(args, "-wo"):
                    out(ar.fields + br.fields + [ov])
                elif has(args, "-wa") and has(args, "-wb"):
                    out(ar.fields + br.fields)
                elif has(args, "-wa"):
                    out(ar.fields)
                elif has(args, "-wb"):
                    out(br.fields)
                else:
                    f = ar.fields[:]
                    f[1] = str(max(ar.start, br.start))
                    f[2] = str(min(ar.end, br.end))
                    out(f)
        elif wao or loj:
            width = max((len(x.fields) for x in allb), default=3)
            null = [".", "-1", "-1"] + ["."] * max(0, width - 3)
            out(ar.fields + null + ([] if loj else [0]))


def merge_groups(records, d=0, same=False, strand=None):
    cur = None
    group = []
    for r in records:
        if strand and (len(r.fields) < 6 or r.fields[5] != strand):
            continue
        same_strand = not same or (cur and len(r.fields) > 5 and len(cur.fields) > 5 and r.fields[5] == cur.fields[5])
        if cur is None or r.chrom != cur.chrom or r.start > cur.end + d or not same_strand:
            if cur is not None:
                yield cur.chrom, cur.start, cur.end, group
            cur = r.copy_interval(r.start, r.end)
            group = [r]
        else:
            cur.end = max(cur.end, r.end)
            cur.fields[2] = str(cur.end)
            group.append(r)
    if cur is not None:
        yield cur.chrom, cur.start, cur.end, group


def fmt_num(x, prec=5):
    if isinstance(x, int) or (isinstance(x, float) and x.is_integer()):
        return str(int(x))
    return (f"{x:.{prec}f}").rstrip("0").rstrip(".")


def aggregate(vals, op, delim=",", prec=5):
    if op in ("collapse", "concat"):
        return ("" if op == "concat" else delim).join(vals)
    if op == "distinct":
        return delim.join(dict.fromkeys(vals))
    if op == "count":
        return str(len(vals))
    if op == "count_distinct":
        return str(len(set(vals)))
    if op == "first":
        return vals[0] if vals else "."
    if op == "last":
        return vals[-1] if vals else "."
    nums = []
    for v in vals:
        try:
            nums.append(float(v))
        except ValueError:
            pass
    if not nums:
        return "."
    if op == "sum":
        return fmt_num(sum(nums), prec)
    if op == "min":
        return fmt_num(min(nums), prec)
    if op == "max":
        return fmt_num(max(nums), prec)
    if op == "mean":
        return fmt_num(sum(nums) / len(nums), prec)
    if op == "median":
        return fmt_num(statistics.median(nums), prec)
    if op == "stdev":
        return fmt_num(statistics.pstdev(nums), prec)
    if op == "sstdev":
        return fmt_num(statistics.stdev(nums) if len(nums) > 1 else 0, prec)
    if op == "mode":
        return Counter(vals).most_common(1)[0][0]
    return fmt_num(sum(nums), prec)


def cmd_merge(args):
    recs = read_records(opt_value(args, "-i"))
    d = int(opt_value(args, "-d", "0"))
    cols = [int(x) for x in opt_value(args, "-c", "").split(",") if x]
    ops = [x for x in opt_value(args, "-o", "sum").split(",") if x]
    delim = opt_value(args, "-delim", ",")
    for chrom, start, end, group in merge_groups(recs, d, has(args, "-s"), opt_value(args, "-S")):
        extra = []
        if cols:
            if len(ops) == 1 and len(cols) > 1:
                ops2 = ops * len(cols)
            elif len(cols) == 1 and len(ops) > 1:
                cols = cols * len(ops)
                ops2 = ops
            else:
                ops2 = ops
            for c, op in zip(cols, ops2):
                vals = [r.fields[c - 1] for r in group if len(r.fields) >= c]
                extra.append(aggregate(vals, op, delim))
        out([chrom, start, end] + extra)


def cmd_sort(args):
    recs = read_records(opt_value(args, "-i"))
    if has(args, "-sizeD"):
        key = lambda r: (-(r.end - r.start), r.chrom, r.start)
    elif has(args, "-sizeA"):
        key = lambda r: (r.end - r.start, r.chrom, r.start)
    elif has(args, "-chrThenSizeD"):
        key = lambda r: (chrom_key(r.chrom), -(r.end - r.start), r.start)
    elif has(args, "-chrThenSizeA"):
        key = lambda r: (chrom_key(r.chrom), r.end - r.start, r.start)
    else:
        key = lambda r: (chrom_key(r.chrom), r.start, r.end)
    for r in sorted(recs, key=key):
        out(r.fields)


def cmd_complement(args):
    recs = sorted(read_records(opt_value(args, "-i")), key=lambda r: (chrom_key(r.chrom), r.start))
    rd = by_chrom(recs)
    seen = set(rd)
    for chrom, size in read_genome(opt_value(args, "-g")):
        if has(args, "-L") and chrom not in seen:
            continue
        pos = 0
        for r in sorted(rd.get(chrom, []), key=lambda x: x.start):
            if r.start > pos:
                out([chrom, pos, r.start])
            pos = max(pos, r.end)
        if pos < size:
            out([chrom, pos, size])


def cmd_subtract(args):
    b = by_chrom(read_records(opt_value(args, "-b")))
    for ar in read_records(opt_value(args, "-a")):
        hits = [br for br in b.get(ar.chrom, []) if passes(ar, br, args)]
        if not hits:
            out(ar.fields)
            continue
        if has(args, "-A") or has(args, "-N"):
            continue
        segments = [(ar.start, ar.end)]
        for br in hits:
            ns = []
            for s, e in segments:
                os, oe = max(s, br.start), min(e, br.end)
                if os >= oe:
                    ns.append((s, e))
                else:
                    if s < os:
                        ns.append((s, os))
                    if oe < e:
                        ns.append((oe, e))
            segments = ns
        for s, e in segments:
            if s < e:
                f = ar.fields[:]
                f[1], f[2] = str(s), str(e)
                out(f)


def cmd_coverage(args):
    b = by_chrom(read_records(opt_value(args, "-b")))
    for ar in read_records(opt_value(args, "-a")):
        hits = [br for br in b.get(ar.chrom, []) if passes(ar, br, args)]
        if has(args, "-counts"):
            out(ar.fields + [len(hits)])
            continue
        depth = [0] * max(0, ar.end - ar.start)
        for br in hits:
            for i in range(max(ar.start, br.start), min(ar.end, br.end)):
                depth[i - ar.start] += 1
        covered = sum(1 for x in depth if x > 0)
        if has(args, "-mean"):
            out(ar.fields + [f"{(sum(depth) / len(depth) if depth else 0):.7f}"])
        else:
            out(ar.fields + [len(hits), covered, ar.end - ar.start, f"{(covered / max(1, ar.end - ar.start)):.7f}"])


def dist(a, b):
    if a.chrom != b.chrom:
        return 10**18
    if overlap_len(a, b) > 0:
        return 0
    if b.end <= a.start:
        return a.start - b.end + 1
    return b.start - a.end + 1


def cmd_closest(args):
    bs = read_records(opt_value(args, "-b"))
    k = int(opt_value(args, "-k", "1"))
    for ar in read_records(opt_value(args, "-a")):
        cand = []
        for idx, br in enumerate(bs):
            if ar.chrom != br.chrom or not strand_ok(ar, br, has(args, "-s"), has(args, "-S")):
                continue
            if has(args, "-io") and overlap_len(ar, br) > 0:
                continue
            cand.append((dist(ar, br), idx, br))
        if not cand:
            out(ar.fields + [".", "-1", "-1"] + (["-1"] if has(args, "-d") or "-D" in args else []))
            continue
        cand.sort(key=lambda x: (x[0], x[1]))
        cutoff = cand[min(k, len(cand)) - 1][0]
        chosen = [x for x in cand if x[0] <= cutoff] if opt_value(args, "-t", "all") == "all" else cand[:k]
        if opt_value(args, "-t") == "first":
            chosen = cand[:k]
        if opt_value(args, "-t") == "last":
            chosen = sorted(cand, key=lambda x: (x[0], -x[1]))[:k]
        for d, _, br in chosen:
            out(ar.fields + br.fields + ([d] if has(args, "-d") or "-D" in args else []))


def cmd_makewindows(args):
    intervals = []
    if opt_value(args, "-g"):
        intervals = [(c, 0, s, c) for c, s in read_genome(opt_value(args, "-g"))]
    else:
        intervals = [(r.chrom, r.start, r.end, r.fields[3] if len(r.fields) > 3 else ".") for r in read_records(opt_value(args, "-b"))]
    wid = opt_value(args, "-i")
    for chrom, start, end, name in intervals:
        if opt_value(args, "-w"):
            w = int(opt_value(args, "-w"))
            step = int(opt_value(args, "-s", str(w)))
            n = 1
            p = start
            while p < end:
                e = min(end, p + w)
                fields = [chrom, p, e]
                if wid == "winnum":
                    fields.append(n)
                elif wid == "src":
                    fields.append(name)
                elif wid == "srcwinnum":
                    fields.append(f"{name}_{n}")
                out(fields)
                n += 1
                p += step
        elif opt_value(args, "-n"):
            nwin = int(opt_value(args, "-n"))
            length = end - start
            for i in range(nwin):
                s = start + int(math.floor(i * length / nwin))
                e = start + int(math.floor((i + 1) * length / nwin))
                out([chrom, s, e])


def genome_sizes(args):
    return dict(read_genome(opt_value(args, "-g")))


def cmd_slop(args, flank=False):
    sizes = genome_sizes(args)
    b = opt_value(args, "-b")
    l = opt_value(args, "-l", b or "0")
    r = opt_value(args, "-r", b or "0")
    pct = has(args, "-pct")
    for rec in read_records(opt_value(args, "-i")):
        length = rec.end - rec.start
        left = float(l) * length if pct else float(l)
        right = float(r) * length if pct else float(r)
        left, right = int(left), int(right)
        if has(args, "-s") and len(rec.fields) > 5 and rec.fields[5] == "-":
            left, right = right, left
        size = sizes.get(rec.chrom, 10**18)
        if flank:
            a = (max(0, rec.start - left), rec.start)
            bseg = (rec.end, min(size, rec.end + right))
            for s, e in (a, bseg):
                if s < e:
                    f = rec.fields[:]
                    f[1], f[2] = str(s), str(e)
                    out(f)
        else:
            f = rec.fields[:]
            f[1], f[2] = str(max(0, rec.start - left)), str(min(size, rec.end + right))
            out(f)


def cmd_window(args):
    a = read_records(opt_value(args, "-a"))
    b = by_chrom(read_records(opt_value(args, "-b")))
    w = int(opt_value(args, "-w", "1000"))
    l = int(opt_value(args, "-l", str(w)))
    r = int(opt_value(args, "-r", str(w)))
    for ar in a:
        wl, wr = l, r
        if has(args, "-sw") and len(ar.fields) > 5 and ar.fields[5] == "-":
            wl, wr = r, l
        win = ar.copy_interval(max(0, ar.start - wl), ar.end + wr)
        hits = [br for br in b.get(ar.chrom, []) if overlap_len(win, br) > 0 and strand_ok(ar, br, has(args, "-sm"), has(args, "-Sm"))]
        if has(args, "-c"):
            out(ar.fields + [len(hits)])
        elif has(args, "-u"):
            if hits:
                out(ar.fields)
        elif has(args, "-v"):
            if not hits:
                out(ar.fields)
        else:
            for br in hits:
                out(ar.fields + br.fields)


def cmd_cluster(args):
    recs = read_records(opt_value(args, "-i"))
    cid = 0
    cur_chrom, cur_end, cur_strand = None, None, None
    d = int(opt_value(args, "-d", "0"))
    for r in recs:
        rs = r.fields[5] if len(r.fields) > 5 else "."
        if cur_chrom != r.chrom or cur_end is None or r.start > cur_end + d or (has(args, "-s") and rs != cur_strand):
            cid += 1
            cur_chrom, cur_end, cur_strand = r.chrom, r.end, rs
        else:
            cur_end = max(cur_end, r.end)
        out(r.fields + [cid])


def cmd_spacing(args):
    prev = None
    for r in read_records(opt_value(args, "-i")):
        if prev is None or r.chrom != prev.chrom:
            gap = "."
        elif r.start < prev.end:
            gap = -1
        else:
            gap = r.start - prev.end
        out(r.fields + [gap])
        if prev is None or r.chrom != prev.chrom or r.end > prev.end:
            prev = r


def merged_length(records):
    total = 0
    for _, s, e, _ in merge_groups(sorted(records, key=lambda r: (chrom_key(r.chrom), r.start))):
        total += e - s
    return total


def cmd_jaccard(args):
    a = read_records(opt_value(args, "-a"))
    b = read_records(opt_value(args, "-b"))
    inter_segments = []
    n = 0
    bd = by_chrom(b)
    for ar in a:
        touched = False
        for br in bd.get(ar.chrom, []):
            if passes(ar, br, args):
                inter_segments.append(Rec([ar.chrom, str(max(ar.start, br.start)), str(min(ar.end, br.end))]))
                touched = True
        if touched:
            n += 1
    inter = merged_length(inter_segments)
    union = merged_length(a + b)
    jac = inter / union if union else 0
    print("intersection\tunion\tjaccard\tn_intersections")
    print(f"{inter}\t{union}\t{jac:.6g}\t{n}")


def cmd_genomecov(args):
    g = read_genome(opt_value(args, "-g"))
    recs = by_chrom(read_records(opt_value(args, "-i")))
    scale = float(opt_value(args, "-scale", "1"))
    if has(args, "-bg") or has(args, "-bga"):
        include_zero = has(args, "-bga")
        for chrom, size in g:
            events = defaultdict(int)
            for r in recs.get(chrom, []):
                events[max(0, r.start)] += 1
                events[min(size, r.end)] -= 1
            depth = 0
            last = 0
            for pos in sorted(set(events.keys()) | {0, size}):
                delta = events[pos]
                if pos == size:
                    delta = -depth
                if delta == 0 and pos != size:
                    continue
                if pos > last and (depth or include_zero):
                    out([chrom, last, pos, fmt_num(depth * scale)])
                depth += delta
                last = pos
        return
    hist = Counter()
    genome_total = 0
    for chrom, size in g:
        depth = [0] * size
        for r in recs.get(chrom, []):
            for i in range(max(0, r.start), min(size, r.end)):
                depth[i] += 1
        c = Counter(depth)
        for dep in sorted(c):
            out([chrom, dep, c[dep], size, f"{c[dep] / max(1, size):.7f}"])
            hist[dep] += c[dep]
        genome_total += size
    for dep in sorted(hist):
        out(["genome", dep, hist[dep], genome_total, f"{hist[dep] / max(1, genome_total):.7f}"])


def cmd_map(args):
    a = read_records(opt_value(args, "-a"))
    b = by_chrom(read_records(opt_value(args, "-b")))
    cols = [int(x) for x in opt_value(args, "-c", "5").split(",")]
    ops = opt_value(args, "-o", "sum").split(",")
    delim = opt_value(args, "-delim", ",")
    for ar in a:
        hits = [br for br in b.get(ar.chrom, []) if passes(ar, br, args)]
        extra = []
        ops2 = ops * len(cols) if len(ops) == 1 else ops
        cols2 = cols * len(ops) if len(cols) == 1 and len(ops) > 1 else cols
        for c, op in zip(cols2, ops2):
            vals = [h.fields[c - 1] for h in hits if len(h.fields) >= c]
            extra.append(aggregate(vals, op, delim) if vals else ".")
        out(ar.fields + extra)


def cmd_groupby(args):
    path = opt_value(args, ["-i"], "-")
    rows = []
    with open_text(path) as fh:
        for line in fh:
            if line.strip():
                rows.append(line.rstrip("\n").split())
    gcols = [int(x) - 1 for x in opt_value(args, ["-g", "-grp"], "1,2,3").split(",")]
    ccols = [int(x) - 1 for x in opt_value(args, ["-c", "-opCols"]).split(",")]
    ops = opt_value(args, ["-o", "-ops"], "sum").split(",")
    cur_key, cur_rows = None, []
    def flush():
        if not cur_rows:
            return
        base = cur_rows[0] if has(args, "-full") else [cur_rows[0][i] for i in gcols]
        ops2 = ops * len(ccols) if len(ops) == 1 else ops
        c2 = ccols * len(ops) if len(ccols) == 1 and len(ops) > 1 else ccols
        extra = [aggregate([r[c] for r in cur_rows if len(r) > c], op) for c, op in zip(c2, ops2)]
        out(base + extra)
    for row in rows:
        key = tuple(row[i].lower() if has(args, "-ignorecase") else row[i] for i in gcols)
        if cur_key is not None and key != cur_key:
            flush()
            cur_rows = []
        cur_key = key
        cur_rows.append(row)
    flush()


def cmd_random(args):
    g = read_genome(opt_value(args, "-g"))
    n = int(opt_value(args, "-n", "1000000"))
    l = int(opt_value(args, "-l", "100"))
    seed = opt_value(args, "-seed")
    if seed is not None:
        random.seed(int(seed))
    for i in range(n):
        chrom, size = random.choice(g)
        if size <= l:
            s = 0
        else:
            s = random.randint(0, size - l)
        out([chrom, s, s + l, i + 1])


def main(argv):
    if len(argv) <= 1 or argv[1] in ("--help", "-h"):
        main_help()
        return
    if argv[1] == "--version":
        print(f"bedtools v{VERSION}")
        return
    if argv[1] == "--contact":
        print("Please see http://bedtools.readthedocs.io/ and the bedtools-discuss mailing list.")
        return
    cmd, args = argv[1], argv[2:]
    if "-h" in args or "--help" in args:
        print(f"Tool:    bedtools {cmd}\nVersion: {VERSION}\n")
        return
    table = {
        "intersect": cmd_intersect, "intersectBed": cmd_intersect,
        "merge": cmd_merge, "mergeBed": cmd_merge,
        "sort": cmd_sort, "sortBed": cmd_sort,
        "complement": cmd_complement, "complementBed": cmd_complement,
        "subtract": cmd_subtract, "subtractBed": cmd_subtract,
        "coverage": cmd_coverage, "coverageBed": cmd_coverage,
        "closest": cmd_closest, "closestBed": cmd_closest,
        "makewindows": cmd_makewindows,
        "slop": lambda a: cmd_slop(a, False), "slopBed": lambda a: cmd_slop(a, False),
        "flank": lambda a: cmd_slop(a, True), "flankBed": lambda a: cmd_slop(a, True),
        "window": cmd_window, "windowBed": cmd_window,
        "cluster": cmd_cluster,
        "spacing": cmd_spacing,
        "jaccard": cmd_jaccard,
        "genomecov": cmd_genomecov, "genomeCoverageBed": cmd_genomecov,
        "map": cmd_map, "mapBed": cmd_map,
        "groupby": cmd_groupby, "groupBy": cmd_groupby,
        "random": cmd_random,
    }
    if cmd not in table:
        die(f"*****ERROR: Unrecognized command: {cmd}")
    table[cmd](args)


if __name__ == "__main__":
    main(sys.argv)
