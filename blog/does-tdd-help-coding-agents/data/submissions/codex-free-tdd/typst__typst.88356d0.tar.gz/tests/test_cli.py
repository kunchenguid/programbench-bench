import os
import subprocess
import tempfile
import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
CMD = ["python3", str(ROOT / "typst_cli.py")]


class CliTests(unittest.TestCase):
    def run_cli(self, *args, input_data=None, cwd=None):
        return subprocess.run(
            CMD + list(args),
            input=input_data,
            text=True,
            cwd=cwd,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
        )

    def test_version_matches_reference(self):
        result = self.run_cli("--version")
        self.assertEqual(result.returncode, 0)
        self.assertEqual(result.stdout, "typst 0.14.2 (ccc34be7)\n")
        self.assertEqual(result.stderr, "")

    def test_no_command_prints_welcome(self):
        result = self.run_cli()
        self.assertEqual(result.returncode, 0)
        self.assertIn("Welcome to Typst", result.stdout)
        self.assertIn("typst compile file.typ", result.stdout)
        self.assertEqual(result.stderr, "")

    def test_unknown_command_is_usage_error(self):
        result = self.run_cli("unknown")
        self.assertEqual(result.returncode, 2)
        self.assertEqual(result.stdout, "")
        self.assertIn("error: unrecognized subcommand 'unknown'", result.stderr)

    def test_eval_serializes_common_values_as_json(self):
        cases = {
            "1 + 2 * 3": "7\n",
            '"hi"': '"hi"\n',
            "true": "true\n",
            "false": "false\n",
            "none": "null\n",
            "(1, 2, 3)": "[1,2,3]\n",
            "(a: 1, b: 2)": '{"a":1,"b":2}\n',
        }
        for expr, expected in cases.items():
            with self.subTest(expr=expr):
                result = self.run_cli("eval", expr)
                self.assertEqual(result.returncode, 0)
                self.assertEqual(result.stdout, expected)
                self.assertEqual(result.stderr, "")

    def test_eval_reads_input_pairs(self):
        result = self.run_cli("eval", "--input", "foo=bar", "sys.inputs.foo")
        self.assertEqual(result.returncode, 0)
        self.assertEqual(result.stdout, '"bar"\n')

    def test_compile_default_writes_pdf_next_to_input(self):
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "hello.typ"
            path.write_text("Hello *world*!\n")
            result = self.run_cli("compile", "hello.typ", cwd=tmp)
            self.assertEqual(result.returncode, 0)
            self.assertEqual(result.stdout, "")
            self.assertEqual(result.stderr, "")
            data = (Path(tmp) / "hello.pdf").read_bytes()
            self.assertTrue(data.startswith(b"%PDF-1.7\n"))
            self.assertIn(b"Hello", data)

    def test_compile_stdout_and_svg(self):
        with tempfile.TemporaryDirectory() as tmp:
            Path(tmp, "hello.typ").write_text("Hello")
            pdf = self.run_cli("compile", "hello.typ", "-", cwd=tmp)
            self.assertEqual(pdf.returncode, 0)
            self.assertTrue(pdf.stdout.startswith("%PDF-1.7\n"))
            svg = self.run_cli("compile", "hello.typ", "out.svg", cwd=tmp)
            self.assertEqual(svg.returncode, 0)
            self.assertTrue(Path(tmp, "out.svg").read_text().startswith("<svg"))

    def test_compile_deps_json_and_make(self):
        with tempfile.TemporaryDirectory() as tmp:
            Path(tmp, "hello.typ").write_text("Hello")
            result = self.run_cli("compile", "--deps", "deps.json", "hello.typ", "out.pdf", cwd=tmp)
            self.assertEqual(result.returncode, 0)
            self.assertEqual(Path(tmp, "deps.json").read_text(), '{"inputs":["hello.typ"],"outputs":["out.pdf"]}')
            result = self.run_cli("compile", "--deps", "-", "--deps-format", "make", "hello.typ", "out.pdf", cwd=tmp)
            self.assertEqual(result.returncode, 0)
            self.assertEqual(result.stdout, "out.pdf: hello.typ\n")

    def test_missing_input_error(self):
        result = self.run_cli("compile", "missing.typ")
        self.assertEqual(result.returncode, 1)
        self.assertIn("error: input file not found (searched at missing.typ)", result.stderr)


if __name__ == "__main__":
    unittest.main()
