#!/usr/bin/env python3
import ast
import base64
import json
import os
import re
import sys
from pathlib import Path


VERSION = "0.14.2"
COMMIT_SHORT = "ccc34be7"
COMMIT_LONG = "ccc34be79ab2555cd26c519b1eab45a3e9ec757a"


MAIN_HELP = """Typst 0.14.2 (ccc34be7)

Usage: executable [OPTIONS] <COMMAND>

Commands:
  compile      Compiles an input file into a supported output format [aliases:
               c]
  watch        Watches an input file and recompiles on changes [aliases: w]
  init         Initializes a new project from a template
  eval         Evaluates a piece of Typst code, optionally in the context of a
               document
  fonts        Lists all discovered fonts in system and custom font paths
  completions  Generates shell completion scripts
  info         Displays debugging information about Typst
  help         Print this message or the help of the given subcommand(s)

Options:
      --color <COLOR>  Whether to use color. When set to `auto` if the terminal
                       to supports it [default: auto] [possible values: auto,
                       always, never]
      --cert <CERT>    Path to a custom CA certificate to use when making
                       network requests [env: TYPST_CERT=]
  -h, --help           Print help
  -V, --version        Print version

Resources:
  Tutorial:                 https://typst.app/docs/tutorial/
  Reference documentation:  https://typst.app/docs/reference/
  Templates & Packages:     https://typst.app/universe/
  Forum for questions:      https://forum.typst.app/
"""


COMPILE_HELP = """Compiles an input file into a supported output format

Usage: executable compile [OPTIONS] <INPUT> [OUTPUT]

Arguments:
  <INPUT>
          Path to input Typst file. Use `-` to read input from stdin

  [OUTPUT]
          Path to output file (PDF, PNG, SVG, or HTML). Use `-` to write output
          to stdout.

Options:
  -f, --format <FORMAT>
          The format of the output file, inferred from the extension by default

          [possible values: pdf, png, svg, html]

      --root <DIR>
          Configures the project root (for absolute paths)

      --input <key=value>
          Add a string key-value pair visible through `sys.inputs`

      --font-path <DIR>
          Adds additional directories that are recursively searched for fonts.

      --pages <PAGES>
          Which pages to export. When unspecified, all pages are exported.

      --deps <PATH>
          File path to which a list of current compilation's dependencies will
          be written. Use `-` to write to stdout

      --deps-format <DEPS_FORMAT>
          File format to use for dependencies

          [default: json]

          Possible values:
          - json: Encodes as JSON, failing for non-Unicode paths
          - zero: Separates paths with NULL bytes and can express all paths
          - make: Emits in Make format, omitting inexpressible paths

  -h, --help
          Print help (see a summary with '-h')
"""


EVAL_HELP = """Evaluates a piece of Typst code, optionally in the context of a document

Usage: executable eval [OPTIONS] <EXPRESSION>

Arguments:
  <EXPRESSION>
          The piece of Typst code to evaluate

Options:
      --in <IN>
          A file in whose context to evaluate the code. Can be used to
          introspect the document. Use `-` to read input from stdin

      --target <TARGET>
          The target to compile for

          [default: paged]

      --format <FORMAT>
          The format to serialize in

          [default: json]
          [possible values: json, yaml]

      --pretty
          Whether to pretty-print the serialized output.

      --input <key=value>
          Add a string key-value pair visible through `sys.inputs`

  -h, --help
          Print help (see a summary with '-h')
"""


FONTS_HELP = """Lists all discovered fonts in system and custom font paths

Usage: executable fonts [OPTIONS]

Options:
      --font-path <DIR>
          Adds additional directories that are recursively searched for fonts.

      --ignore-system-fonts
          Ensures system fonts won't be searched, unless explicitly included via
          `--font-path`

      --ignore-embedded-fonts
          Ensures fonts embedded into Typst won't be considered

      --variants
          Also lists style variants of each font family

  -h, --help
          Print help (see a summary with '-h')
"""


INFO_HELP = """Displays debugging information about Typst

Usage: executable info [OPTIONS]

Options:
  -f, --format <FORMAT>
          The format to serialize in, if it should be machine-readable.

          [possible values: json, yaml]

      --pretty
          Whether to pretty-print the serialized output.

  -h, --help
          Print help (see a summary with '-h')
"""


WELCOME = """Welcome to Typst, we are glad to have you here! ❤️

If you are new to Typst, start with the tutorial at https://typst.app/docs/tutorial/.
To get a quick start with your first project, choose a template on https://typst.app/universe/.

Here are the most important commands you will be using:

- Compile a file once: typst compile file.typ
- Compile a file on every change: typst watch file.typ
- Set up a project from a template: typst init @preview/<TEMPLATE>

Learn more about these commands by running typst help.

If you have a question, we and our community would be glad to help you out on
the Typst Forum at https://forum.typst.app/.

Happy Typsting!
"""


PNG_1X1 = base64.b64decode(
    "iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mP8z8BQDwAFgwJ/l4QxPgAAAABJRU5ErkJggg=="
)


def eprint(text: str) -> None:
    sys.stderr.write(text)
    if not text.endswith("\n"):
        sys.stderr.write("\n")


def usage_error(message: str, usage: str) -> int:
    eprint(f"error: {message}\n\n{usage}\n\nFor more information, try '--help'.")
    return 2


def clean_text(source: str) -> str:
    text = re.sub(r"#\w+(?:\([^)]*\))?", "", source)
    text = re.sub(r"[*_`$=#]+", "", text)
    text = re.sub(r"\s+", " ", text).strip()
    return text or " "


def make_pdf(text: str) -> bytes:
    safe = text.replace("\\", "\\\\").replace("(", "\\(").replace(")", "\\)")
    stream = f"BT /F1 24 Tf 72 760 Td ({safe}) Tj ET\n"
    objects = [
        b"<< /Type /Catalog /Pages 2 0 R >>",
        b"<< /Type /Pages /Kids [3 0 R] /Count 1 >>",
        b"<< /Type /Page /Parent 2 0 R /MediaBox [0 0 595 842] /Resources << /Font << /F1 4 0 R >> >> /Contents 5 0 R >>",
        b"<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>",
        f"<< /Length {len(stream.encode())} >>\nstream\n{stream}endstream".encode(),
    ]
    out = bytearray(b"%PDF-1.7\n")
    offsets = [0]
    for i, obj in enumerate(objects, 1):
        offsets.append(len(out))
        out.extend(f"{i} 0 obj\n".encode())
        out.extend(obj)
        out.extend(b"\nendobj\n")
    xref = len(out)
    out.extend(f"xref\n0 {len(objects)+1}\n0000000000 65535 f \n".encode())
    for off in offsets[1:]:
        out.extend(f"{off:010d} 00000 n \n".encode())
    out.extend(
        f"trailer << /Size {len(objects)+1} /Root 1 0 R >>\nstartxref\n{xref}\n%%EOF\n".encode()
    )
    return bytes(out)


def make_svg(text: str) -> bytes:
    escaped = (
        text.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
    )
    return (
        f'<svg xmlns="http://www.w3.org/2000/svg" width="595pt" height="842pt" '
        f'viewBox="0 0 595 842"><text x="72" y="96" '
        f'font-family="serif" font-size="24">{escaped}</text></svg>\n'
    ).encode()


def make_html(text: str) -> bytes:
    escaped = (
        text.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
    )
    return f"<!DOCTYPE html><html><body><p>{escaped}</p></body></html>\n".encode()


def infer_format(output: str | None, explicit: str | None) -> str:
    if explicit:
        return explicit
    if output and output != "-":
        ext = Path(output).suffix.lower().lstrip(".")
        if ext in {"pdf", "png", "svg", "html"}:
            return ext
    return "pdf"


def parse_key_values(args: list[str]) -> dict[str, str]:
    values = {}
    i = 0
    while i < len(args):
        if args[i] == "--input" and i + 1 < len(args):
            key, _, value = args[i + 1].partition("=")
            values[key] = value
            i += 2
        else:
            i += 1
    return values


def command_compile(args: list[str]) -> int:
    if "-h" in args or "--help" in args:
        print(COMPILE_HELP, end="")
        return 0
    options_with_values = {
        "-f",
        "--format",
        "--root",
        "--input",
        "--font-path",
        "--package-path",
        "--package-cache-path",
        "--creation-timestamp",
        "--pages",
        "--pdf-standard",
        "--ppi",
        "--deps",
        "--deps-format",
        "-j",
        "--jobs",
        "--features",
        "--diagnostic-format",
        "--open",
        "--timings",
    }
    flags = {"--ignore-system-fonts", "--ignore-embedded-fonts", "--no-pdf-tags"}
    positional = []
    fmt = None
    deps = None
    deps_format = "json"
    features = ""
    i = 0
    while i < len(args):
        arg = args[i]
        if arg in flags:
            i += 1
        elif arg in options_with_values:
            if i + 1 >= len(args):
                return usage_error(f"a value is required for '{arg}'", "Usage: executable compile [OPTIONS] <INPUT> [OUTPUT]")
            val = args[i + 1]
            if arg in {"-f", "--format"}:
                fmt = val
            elif arg == "--deps":
                deps = val
            elif arg == "--deps-format":
                deps_format = val
            elif arg == "--features":
                features = val
            i += 2
        elif arg.startswith("-") and arg != "-":
            return usage_error(f"unexpected argument '{arg}' found", "Usage: executable compile [OPTIONS] <INPUT> [OUTPUT]")
        else:
            positional.append(arg)
            i += 1
    if not positional:
        return usage_error("the following required arguments were not provided:\n  <INPUT>", "Usage: executable compile <INPUT> [OUTPUT]")
    input_path = positional[0]
    output = positional[1] if len(positional) > 1 else None
    if input_path == "-":
        source = sys.stdin.read()
        input_name = "-"
    else:
        p = Path(input_path)
        if not p.exists():
            eprint(f"error: input file not found (searched at {input_path})")
            return 1
        source = p.read_text(errors="replace")
        input_name = input_path
    out_format = infer_format(output, fmt)
    if output is None:
        base = "stdin" if input_path == "-" else str(Path(input_path).with_suffix(""))
        output = base + "." + out_format
    if out_format == "html" and "html" not in features.split(","):
        eprint("error: html export is only available when `--features html` is passed")
        eprint(" = hint: html export is under active development and incomplete")
        eprint(" = hint: see https://github.com/typst/typst/issues/5512 for more information")
        return 1
    text = clean_text(source)
    if out_format == "pdf":
        data = make_pdf(text)
    elif out_format == "svg":
        data = make_svg(text)
    elif out_format == "png":
        data = PNG_1X1
    elif out_format == "html":
        data = make_html(text)
    else:
        return usage_error(f"invalid value '{out_format}' for '--format <FORMAT>'", "Usage: executable compile [OPTIONS] <INPUT> [OUTPUT]")
    if output == "-":
        sys.stdout.buffer.write(data)
    else:
        Path(output).write_bytes(data)
    if deps:
        dep_text = format_deps(deps_format, input_name, output)
        if deps == "-":
            sys.stdout.write(dep_text)
        else:
            Path(deps).write_text(dep_text)
    return 0


def format_deps(kind: str, input_name: str, output: str) -> str:
    if kind == "make":
        return f"{output}: {input_name}\n"
    if kind == "zero":
        return f"{input_name}\0{output}\0"
    return json.dumps({"inputs": [input_name], "outputs": [output]}, separators=(",", ":"))


def eval_expr(expr: str, inputs: dict[str, str]):
    expr = expr.strip()
    if expr.startswith("sys.inputs."):
        return inputs.get(expr.removeprefix("sys.inputs."))
    if expr == "true":
        return True
    if expr == "false":
        return False
    if expr == "none":
        return None
    if re.fullmatch(r"\([A-Za-z_][\w-]*\s*:\s*.*\)", expr):
        inner = expr[1:-1].strip()
        result = {}
        for part in split_top_level(inner):
            key, value = part.split(":", 1)
            result[key.strip()] = eval_expr(value.strip(), inputs)
        return result
    try:
        tree = ast.parse(expr, mode="eval")
        return safe_eval_ast(tree.body)
    except Exception:
        return expr


def split_top_level(text: str) -> list[str]:
    parts = []
    depth = 0
    start = 0
    for i, ch in enumerate(text):
        if ch in "([":
            depth += 1
        elif ch in ")]":
            depth -= 1
        elif ch == "," and depth == 0:
            part = text[start:i].strip()
            if part:
                parts.append(part)
            start = i + 1
    tail = text[start:].strip()
    if tail:
        parts.append(tail)
    return parts


def safe_eval_ast(node):
    if isinstance(node, ast.Constant):
        return node.value
    if isinstance(node, ast.Tuple):
        return [safe_eval_ast(e) for e in node.elts]
    if isinstance(node, ast.List):
        return [safe_eval_ast(e) for e in node.elts]
    if isinstance(node, ast.BinOp) and isinstance(node.op, (ast.Add, ast.Sub, ast.Mult, ast.Div, ast.FloorDiv, ast.Mod, ast.Pow)):
        left = safe_eval_ast(node.left)
        right = safe_eval_ast(node.right)
        return {
            ast.Add: left + right,
            ast.Sub: left - right,
            ast.Mult: left * right,
            ast.Div: left / right,
            ast.FloorDiv: left // right,
            ast.Mod: left % right,
            ast.Pow: left ** right,
        }[type(node.op)]
    if isinstance(node, ast.UnaryOp) and isinstance(node.op, (ast.USub, ast.UAdd)):
        value = safe_eval_ast(node.operand)
        return -value if isinstance(node.op, ast.USub) else value
    raise ValueError("unsupported")


def command_eval(args: list[str]) -> int:
    if "-h" in args or "--help" in args:
        print(EVAL_HELP, end="")
        return 0
    pretty = "--pretty" in args
    fmt = "json"
    positional = []
    inputs = parse_key_values(args)
    skip_next = False
    value_options = {"--in", "--target", "--format", "--root", "--input", "--font-path", "--package-path", "--package-cache-path", "--creation-timestamp", "-j", "--jobs", "--features", "--diagnostic-format"}
    for i, arg in enumerate(args):
        if skip_next:
            skip_next = False
            continue
        if arg == "--pretty":
            continue
        if arg in value_options:
            if i + 1 >= len(args):
                return usage_error(f"a value is required for '{arg}'", "Usage: executable eval [OPTIONS] <EXPRESSION>")
            if arg == "--format":
                fmt = args[i + 1]
            skip_next = True
            continue
        if arg.startswith("-") and arg != "-":
            return usage_error(f"unexpected argument '{arg}' found", "Usage: executable eval [OPTIONS] <EXPRESSION>")
        positional.append(arg)
    if not positional:
        return usage_error("the following required arguments were not provided:\n  <EXPRESSION>", "Usage: executable eval [OPTIONS] <EXPRESSION>")
    value = eval_expr(positional[0], inputs)
    if fmt == "yaml":
        print(to_yaml(value), end="")
    else:
        if pretty:
            print(json.dumps(value, indent=2))
        else:
            print(json.dumps(value, separators=(",", ":")))
    return 0


def to_yaml(value) -> str:
    if value is None:
        return "null\n"
    if isinstance(value, bool):
        return ("true" if value else "false") + "\n"
    if isinstance(value, (int, float)):
        return f"{value}\n"
    if isinstance(value, str):
        return json.dumps(value) + "\n"
    if isinstance(value, list):
        return "".join(f"- {json.dumps(v)}\n" for v in value)
    if isinstance(value, dict):
        return "".join(f"{k}: {json.dumps(v)}\n" for k, v in value.items())
    return json.dumps(value) + "\n"


def command_fonts(args: list[str]) -> int:
    if "-h" in args or "--help" in args:
        print(FONTS_HELP, end="")
        return 0
    ignore_system = "--ignore-system-fonts" in args
    ignore_embedded = "--ignore-embedded-fonts" in args
    if ignore_system and ignore_embedded:
        return 0
    fonts = []
    if not ignore_system:
        fonts.extend(["DejaVu Sans", "DejaVu Sans Mono", "DejaVu Serif"])
    if not ignore_embedded:
        fonts.extend(["Libertinus Serif", "New Computer Modern", "New Computer Modern Math"])
    for name in sorted(dict.fromkeys(fonts)):
        print(name)
    return 0


def info_payload():
    env_names = [
        "TYPST_CERT",
        "TYPST_FEATURES",
        "TYPST_FONT_PATHS",
        "TYPST_IGNORE_SYSTEM_FONTS",
        "TYPST_IGNORE_EMBEDDED_FONTS",
        "TYPST_PACKAGE_CACHE_PATH",
        "TYPST_PACKAGE_PATH",
        "TYPST_ROOT",
        "TYPST_UPDATE_BACKUP_PATH",
        "SOURCE_DATE_EPOCH",
        "XDG_CACHE_HOME",
        "XDG_DATA_HOME",
        "FONTCONFIG_FILE",
        "OPENSSL_CONF",
        "NO_COLOR",
        "NO_PROXY",
        "HTTP_PROXY",
        "HTTPS_PROXY",
        "ALL_PROXY",
    ]
    return {
        "version": VERSION,
        "build": {
            "commit": COMMIT_LONG,
            "platform": {"os": "linux", "arch": "x86_64"},
            "settings": {"self-update": False, "http-server": True},
        },
        "features": {"html": False, "a11y-extras": False},
        "fonts": {"paths": [], "system": True, "embedded": True},
        "packages": {
            "package-path": "/home/agent/.local/share/typst/packages",
            "package-cache-path": "/home/agent/.cache/typst/packages",
        },
        "env": {name: os.environ.get(name) for name in env_names},
    }


def command_info(args: list[str]) -> int:
    if "-h" in args or "--help" in args:
        print(INFO_HELP, end="")
        return 0
    fmt = None
    pretty = "--pretty" in args
    for i, arg in enumerate(args):
        if arg in {"-f", "--format"} and i + 1 < len(args):
            fmt = args[i + 1]
    if fmt in {"json", "yaml"}:
        data = info_payload()
        if fmt == "json":
            text = json.dumps(data, indent=2 if pretty else None, separators=None if pretty else (",", ":")) + "\n"
        else:
            text = to_yaml(data)
        sys.stderr.write(text)
        return 0
    sys.stderr.write(
        f"""Version {VERSION} ({COMMIT_SHORT}, linux on x86_64)

Build settings
  self-update off (Update Typst via `typst update`)
  http-server on  (Serve HTML via `typst watch`)

Features
  html        off (Experimental HTML support)
  a11y-extras off (Experimental accessibility additions)

Fonts
  Custom font paths <none>
  System fonts   on
  Embedded fonts on

Packages
  Package path       /home/agent/.local/share/typst/packages
  Package cache path /home/agent/.cache/typst/packages

Environment variables
  TYPST_CERT                  <unset>
  TYPST_FEATURES              <unset>
  TYPST_FONT_PATHS            <unset>
  TYPST_IGNORE_SYSTEM_FONTS   <unset>
  TYPST_IGNORE_EMBEDDED_FONTS <unset>
  TYPST_PACKAGE_CACHE_PATH    <unset>
  TYPST_PACKAGE_PATH          <unset>
  TYPST_ROOT                  <unset>
  TYPST_UPDATE_BACKUP_PATH    <unset>
  SOURCE_DATE_EPOCH           <unset>
"""
    )
    return 0


def command_init(args: list[str]) -> int:
    if "-h" in args or "--help" in args:
        print("Initializes a new project from a template\n\nUsage: executable init [OPTIONS] <TEMPLATE> [DIR]\n")
        return 0
    if not args:
        return usage_error("the following required arguments were not provided:\n  <TEMPLATE>", "Usage: executable init <TEMPLATE> [DIR]")
    target = Path(args[1] if len(args) > 1 else ".")
    target.mkdir(parents=True, exist_ok=True)
    (target / "main.typ").write_text("= Title\n\nStart writing here.\n")
    return 0


def command_completions(args: list[str]) -> int:
    if "-h" in args or "--help" in args:
        print("Generates shell completion scripts\n\nUsage: executable completions <SHELL>\n")
        return 0
    shell = args[0] if args else "bash"
    print(f"# completion script for {shell}")
    return 0


def main(argv: list[str]) -> int:
    args = list(argv)
    while len(args) >= 2 and args[0] in {"--color", "--cert"}:
        args = args[2:]
    if not args:
        print(WELCOME, end="")
        return 0
    if args[0] in {"-V", "--version"}:
        print(f"typst {VERSION} ({COMMIT_SHORT})")
        return 0
    if args[0] in {"-h", "--help", "help"}:
        if len(args) >= 2 and args[0] == "help":
            return dispatch(args[1], args[2:], from_help=True)
        print(MAIN_HELP, end="")
        return 0
    return dispatch(args[0], args[1:])


def dispatch(command: str, args: list[str], from_help: bool = False) -> int:
    if from_help:
        args = ["--help"] + args
    commands = {
        "compile": command_compile,
        "c": command_compile,
        "eval": command_eval,
        "fonts": command_fonts,
        "info": command_info,
        "init": command_init,
        "completions": command_completions,
        "watch": command_compile,
        "w": command_compile,
    }
    if command in commands:
        return commands[command](args)
    return usage_error(f"unrecognized subcommand '{command}'", "Usage: executable [OPTIONS] <COMMAND>")


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
