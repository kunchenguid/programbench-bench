#!/usr/bin/env python3
import argparse
import csv
import fnmatch
import html
import json
import math
import os
import re
import stat
import sys
from dataclasses import dataclass, field
from pathlib import Path


VERSION = "3.7.0"
BORDER = "─" * 79
DEFAULT_EXCLUDE_DIRS = {".git", ".hg", ".svn"}
DEFAULT_EXCLUDE_FILES = {
    "package-lock.json",
    "Cargo.lock",
    "yarn.lock",
    "pubspec.lock",
    "Podfile.lock",
    "pnpm-lock.yaml",
}


LANGS = {
    ".py": ("Python", "#", None, None),
    ".pyw": ("Python", "#", None, None),
    ".js": ("JavaScript", "//", "/*", "*/"),
    ".cjs": ("JavaScript", "//", "/*", "*/"),
    ".mjs": ("JavaScript", "//", "/*", "*/"),
    ".ts": ("TypeScript", "//", "/*", "*/"),
    ".tsx": ("TypeScript", "//", "/*", "*/"),
    ".java": ("Java", "//", "/*", "*/"),
    ".go": ("Go", "//", "/*", "*/"),
    ".rs": ("Rust", "//", "/*", "*/"),
    ".c": ("C", "//", "/*", "*/"),
    ".h": ("C Header", "//", "/*", "*/"),
    ".cc": ("C++", "//", "/*", "*/"),
    ".cpp": ("C++", "//", "/*", "*/"),
    ".cxx": ("C++", "//", "/*", "*/"),
    ".hpp": ("C++ Header", "//", "/*", "*/"),
    ".hh": ("C++ Header", "//", "/*", "*/"),
    ".cs": ("C#", "//", "/*", "*/"),
    ".php": ("PHP", "//", "/*", "*/"),
    ".css": ("CSS", None, "/*", "*/"),
    ".scss": ("Sass", None, "/*", "*/"),
    ".html": ("HTML", None, "<!--", "-->"),
    ".htm": ("HTML", None, "<!--", "-->"),
    ".xml": ("XML", None, "<!--", "-->"),
    ".svg": ("SVG", None, "<!--", "-->"),
    ".md": ("Markdown", None, None, None),
    ".markdown": ("Markdown", None, None, None),
    ".txt": ("Plain Text", None, None, None),
    ".json": ("JSON", None, None, None),
    ".yaml": ("YAML", "#", None, None),
    ".yml": ("YAML", "#", None, None),
    ".toml": ("TOML", "#", None, None),
    ".ini": ("INI", ";", None, None),
    ".sh": ("Shell", "#", None, None),
    ".bash": ("BASH", "#", None, None),
    ".zsh": ("Zsh", "#", None, None),
    ".rb": ("Ruby", "#", None, None),
    ".pl": ("Perl", "#", None, None),
    ".r": ("R", "#", None, None),
    ".lua": ("Lua", "--", None, None),
    ".sql": ("SQL", "--", "/*", "*/"),
    ".make": ("Makefile", "#", None, None),
    ".cmake": ("CMake", "#", None, None),
}

SPECIAL_NAMES = {
    "makefile": ("Makefile", "#", None, None),
    "dockerfile": ("Dockerfile", "#", None, None),
    "cmakelists.txt": ("CMake", "#", None, None),
    ".gitignore": ("gitignore", "#", None, None),
    ".ignore": ("ignore", "#", None, None),
}

LANGUAGE_LIST = [
    ("BASH", "bash,bash_login,bash_logout,bash_profile,bashrc,.bash_login,.bash_logout,.bash_profile,.bashrc"),
    ("C", "c,ec,pgc"),
    ("C Header", "h"),
    ("C#", "cs,csx"),
    ("C++", "cc,cpp,cxx,c++,pcc,ino,ccm,cppm,cxxm,c++m,mxx"),
    ("C++ Header", "hh,hpp,hxx,h++,inl,ipp,ixx,tpp"),
    ("CMake", "cmake,cmakelists.txt"),
    ("CSS", "css"),
    ("Dockerfile", "dockerfile,dockerfile"),
    ("Go", "go"),
    ("HTML", "html,htm"),
    ("INI", "ini"),
    ("Java", "java"),
    ("JavaScript", "js,cjs,mjs"),
    ("JSON", "json"),
    ("Markdown", "md,markdown"),
    ("Makefile", "makefile"),
    ("PHP", "php"),
    ("Plain Text", "txt"),
    ("Python", "py,pyw"),
    ("Ruby", "rb"),
    ("Rust", "rs"),
    ("SQL", "sql"),
    ("Shell", "sh"),
    ("SVG", "svg"),
    ("TOML", "toml"),
    ("TypeScript", "ts,tsx"),
    ("XML", "xml"),
    ("YAML", "yaml,yml"),
    ("gitignore", ".gitignore"),
    ("ignore", ".ignore"),
]


@dataclass
class FileStat:
    name: str
    path: str
    bytes: int
    lines: int
    code: int
    comment: int
    blank: int
    complexity: int
    uloc: int = 0
    max_chars: int = 0
    mean_chars: int = 0


@dataclass
class LangStat:
    name: str
    bytes: int = 0
    lines: int = 0
    code: int = 0
    comment: int = 0
    blank: int = 0
    complexity: int = 0
    count: int = 0
    uloc: int = 0
    files: list = field(default_factory=list)
    max_chars: int = 0
    mean_total: int = 0


def parse_args(argv):
    parser = argparse.ArgumentParser(
        prog="scc",
        description="Sloc, Cloc and Code. Count lines of code in a directory with complexity estimation.",
        add_help=False,
        formatter_class=argparse.RawTextHelpFormatter,
    )
    add = parser.add_argument
    add("paths", nargs="*")
    add("-h", "--help", action="store_true")
    add("--version", action="store_true")
    add("-l", "--languages", action="store_true")
    add("-f", "--format", default="tabular")
    add("--format-multi", default="")
    add("-o", "--output", default="")
    add("--by-file", action="store_true")
    add("-c", "--no-complexity", action="store_true")
    add("--no-cocomo", action="store_true")
    add("-i", "--include-ext", default="")
    add("-x", "--exclude-ext", default="")
    add("-n", "--exclude-file", action="append", default=[])
    add("--exclude-dir", action="append", default=[])
    add("--count-as", default="")
    add("--count-ignore", action="store_true")
    add("--no-gitignore", action="store_true")
    add("--no-ignore", action="store_true")
    add("--no-scc-ignore", action="store_true")
    add("--no-gitmodule", action="store_true")
    add("--include-symlinks", action="store_true")
    add("--binary", action="store_true")
    add("-s", "--sort", default="files")
    add("-p", "--percent", action="store_true")
    add("-u", "--uloc", action="store_true")
    add("-a", "--dryness", action="store_true")
    add("-m", "--character", action="store_true")
    add("-w", "--wide", action="store_true")
    add("--ci", action="store_true")
    add("--no-size", action="store_true")
    add("--no-hborder", action="store_true")
    add("--no-duplicates", action="store_true")
    add("--min", action="store_true")
    add("--gen", action="store_true")
    add("-z", "--min-gen", action="store_true")
    add("--no-min", action="store_true")
    add("--no-gen", action="store_true")
    add("--no-min-gen", action="store_true")
    add("--large-byte-count", type=int, default=1000000)
    add("--large-line-count", type=int, default=40000)
    add("--no-large", action="store_true")
    add("--currency-symbol", default="$")
    add("--avg-wage", type=int, default=56286)
    add("--overhead", type=float, default=2.4)
    add("--eaf", type=float, default=1.0)
    add("--cocomo-project-type", default="organic")
    add("--sloccount-format", action="store_true")
    add("--sql-project", default="")
    add("--debug", action="store_true")
    add("-v", "--verbose", action="store_true")
    add("-t", "--trace", action="store_true")
    add("-M", "--not-match", action="append", default=[])
    add("--remap-all", default="")
    add("--remap-unknown", default="")
    add("--size-unit", default="si")
    add("--cost-comparison", action="store_true")
    add("--locomo", action="store_true")
    add("--mcp", action="store_true")
    add("--locomo-preset", default="medium")
    add("--locomo-config", default="")
    add("--locomo-input-price", type=float, default=0.0)
    add("--locomo-output-price", type=float, default=0.0)
    add("--locomo-cycles", type=float, default=0.0)
    add("--locomo-review", type=float, default=0.01)
    add("--locomo-tps", type=float, default=0.0)
    for ignored in [
        "--file-gc-count",
        "--file-list-queue-size",
        "--file-process-job-workers",
        "--file-summary-job-queue-size",
        "--directory-walker-job-workers",
        "--large-line-count",
        "--large-byte-count",
        "--min-gen-line-length",
    ]:
        if not any(a.option_strings == [ignored] for a in parser._actions):
            add(ignored, default=None)
    try:
        return parser.parse_args(argv)
    except SystemExit:
        return None


def print_help():
    print("""Sloc, Cloc and Code. Count lines of code in a directory with complexity estimation.
Version 3.7.0
Ben Boyter <ben@boyter.org> + Contributors

Usage:
  scc [flags] [files or directories]

Flags:
      --by-file                            display output for every file
  -m, --character                          calculate max and mean characters per line
      --count-as string                    count extension as language [e.g. jsp:htm,chead:"C Header" maps extension jsp to html and chead to C Header]
      --exclude-dir strings                directories to exclude (default [.git,.hg,.svn])
  -x, --exclude-ext strings                ignore file extensions (overrides include-ext) [comma separated list: e.g. go,java,js]
  -n, --exclude-file strings               ignore files with matching names (default [package-lock.json,Cargo.lock,yarn.lock,pubspec.lock,Podfile.lock,pnpm-lock.yaml])
  -f, --format string                      set output format [tabular, wide, json, json2, csv, csv-stream, cloc-yaml, html, html-table, sql, sql-insert, openmetrics] (default "tabular")
  -h, --help                               help for scc
  -i, --include-ext strings                limit to file extensions [comma separated list: e.g. go,java,js]
  -l, --languages                          print supported languages and extensions
      --no-cocomo                          remove COCOMO calculation output
  -c, --no-complexity                      skip calculation of code complexity
  -d, --no-duplicates                      remove duplicate files from stats and output
  -o, --output string                      output filename (default stdout)
  -p, --percent                            include percentage values in output
  -s, --sort string                        column to sort by [files, name, lines, blanks, code, comments, complexity] (default "files")
  -u, --uloc                               calculate the number of unique lines of code (ULOC) for the project
  -v, --verbose                            verbose output
      --version                            version for scc
  -w, --wide                               wider output with additional statistics (implies --complexity)""")


def csv_list(value):
    out = set()
    for part in value.split(","):
        part = part.strip().lower()
        if part:
            out.add(part[1:] if part.startswith(".") else part)
    return out


def count_as_map(value):
    mapping = {}
    if not value:
        return mapping
    for item in value.split(","):
        if ":" not in item:
            continue
        src, dst = item.split(":", 1)
        src = src.strip().strip(".").lower()
        dst = dst.strip().strip('"').strip("'")
        target = lookup_by_extension(dst) or lookup_by_language(dst) or (" ".join(w.capitalize() for w in dst.split()), None, None, None)
        mapping[src] = target
    return mapping


def lookup_by_extension(ext):
    ext = ext.lower()
    if not ext.startswith("."):
        ext = "." + ext
    return LANGS.get(ext)


def lookup_by_language(name):
    low = name.lower()
    for info in set(LANGS.values()) | set(SPECIAL_NAMES.values()):
        if info[0].lower() == low:
            return info
    return None


def language_for(path, data, remaps):
    name = path.name.lower()
    ext = path.suffix.lower().lstrip(".")
    if ext in remaps:
        return remaps[ext]
    if name in SPECIAL_NAMES:
        return SPECIAL_NAMES[name]
    if path.suffix.lower() in LANGS:
        return LANGS[path.suffix.lower()]
    if data.startswith(b"#!"):
        first = data.splitlines()[0].decode("utf-8", "ignore").lower()
        if "python" in first:
            return ("Python", "#", None, None)
        if "bash" in first:
            return ("BASH", "#", None, None)
        if "sh" in first:
            return ("Shell", "#", None, None)
        if "ruby" in first:
            return ("Ruby", "#", None, None)
        if "node" in first:
            return ("JavaScript", "//", "/*", "*/")
    return None


def is_binary(data):
    return b"\0" in data[:8192]


def iter_files(paths, args):
    exclude_dirs = set(DEFAULT_EXCLUDE_DIRS)
    for item in args.exclude_dir:
        exclude_dirs.update(csv_list(item))
    exclude_files = set(DEFAULT_EXCLUDE_FILES)
    for item in args.exclude_file:
        exclude_files.update(x.strip() for x in item.split(",") if x.strip())
    include = csv_list(args.include_ext)
    exclude = csv_list(args.exclude_ext)
    patterns = [re.compile(p) for p in args.not_match]
    for raw in paths:
        p = Path(raw)
        if not p.exists():
            raise FileNotFoundError(raw)
        ignore_rules = load_ignore_rules(p if p.is_dir() else p.parent, args)
        if p.is_file() or (p.is_symlink() and args.include_symlinks):
            if not ignored_by_rules(p, p.parent, ignore_rules):
                yield p
            continue
        for root, dirs, files in os.walk(p, followlinks=args.include_symlinks):
            base = Path(root)
            dirs[:] = [d for d in dirs if not ignored_by_rules(base / d, p, ignore_rules, is_dir=True)]
            dirs[:] = [d for d in dirs if d.lower() not in exclude_dirs]
            for fname in files:
                fp = Path(root) / fname
                if fp.is_symlink() and not args.include_symlinks:
                    continue
                if fname in exclude_files:
                    continue
                if not args.count_ignore and fname in {".gitignore", ".ignore", ".sccignore"}:
                    continue
                if ignored_by_rules(fp, p, ignore_rules):
                    continue
                ext = fp.suffix.lower().lstrip(".")
                if include and ext not in include:
                    continue
                if exclude and ext in exclude:
                    continue
                s = str(fp)
                if any(pat.search(s) for pat in patterns):
                    continue
                yield fp


def load_ignore_rules(root, args):
    rules = []
    candidates = []
    if not args.no_gitignore:
        candidates.append(".gitignore")
    if not args.no_ignore:
        candidates.append(".ignore")
    if not args.no_scc_ignore:
        candidates.append(".sccignore")
    for name in candidates:
        path = root / name
        if not path.exists():
            continue
        try:
            for line in path.read_text(errors="ignore").splitlines():
                line = line.strip()
                if not line or line.startswith("#") or line.startswith("!"):
                    continue
                rules.append(line)
        except OSError:
            pass
    return rules


def ignored_by_rules(path, root, rules, is_dir=False):
    if not rules:
        return False
    try:
        rel = path.relative_to(root).as_posix()
    except ValueError:
        rel = path.name
    name = path.name
    for rule in rules:
        dir_rule = rule.endswith("/")
        pat = rule.rstrip("/")
        if dir_rule:
            if is_dir and (rel == pat or name == pat or rel.startswith(pat + "/")):
                return True
            if rel.startswith(pat + "/"):
                return True
            continue
        if "/" in pat:
            if fnmatch.fnmatch(rel, pat):
                return True
        elif fnmatch.fnmatch(name, pat):
            return True
    return False


def strip_inline_comment(line, line_comment):
    if not line_comment:
        return line
    idx = line.find(line_comment)
    if idx == -1:
        return line
    return line[:idx]


def analyze(path, info, args):
    data = path.read_bytes()
    if not args.binary and is_binary(data):
        return None
    if not args.no_large and (len(data) > args.large_byte_count):
        return None
    text = data.decode("utf-8", "replace")
    lines = text.splitlines()
    if text and (text.endswith("\n") or text.endswith("\r")):
        pass
    if not text:
        lines = []
    if not args.no_large and len(lines) > args.large_line_count:
        return None
    lang, line_comment, block_start, block_end = info
    blank = comment = code = complexity = 0
    in_block = False
    unique = set()
    max_chars = 0
    total_chars = 0
    for line in lines:
        total_chars += len(line)
        max_chars = max(max_chars, len(line))
        stripped = line.strip()
        if not stripped:
            blank += 1
            continue
        line_is_comment = False
        remainder = stripped
        if in_block:
            line_is_comment = True
            if block_end and block_end in remainder:
                after = remainder.split(block_end, 1)[1].strip()
                in_block = False
                if after:
                    code += 1
                    unique.add(after)
                    complexity += complexity_for(after, lang)
                    continue
            comment += 1
            continue
        if block_start and remainder.startswith(block_start):
            line_is_comment = True
            comment += 1
            if block_end and block_end not in remainder:
                in_block = True
            else:
                after = remainder.split(block_end, 1)[1].strip() if block_end in remainder else ""
                if after:
                    code += 1
                    unique.add(after)
                    complexity += complexity_for(after, lang)
            continue
        if line_comment and remainder.startswith(line_comment):
            comment += 1
            continue
        if line_is_comment:
            comment += 1
            continue
        code += 1
        code_part = strip_inline_comment(remainder, line_comment)
        unique.add(code_part.strip())
        complexity += complexity_for(code_part, lang)
    return FileStat(
        name=lang,
        path=str(path),
        bytes=len(data),
        lines=len(lines),
        code=code,
        comment=comment,
        blank=blank,
        complexity=complexity,
        uloc=len(unique) if args.uloc or args.dryness else 0,
        max_chars=max_chars,
        mean_chars=round(total_chars / len(lines)) if lines else 0,
    )


def complexity_for(line, lang):
    if lang in {"Markdown", "Plain Text", "JSON", "YAML", "TOML", "INI", "XML", "HTML", "SVG", "CSS"}:
        return 0
    count = 0
    for pat in [r"\bif\b", r"\bfor\b", r"\bwhile\b", r"\bcase\b", r"\bcatch\b", r"\bexcept\b", r"\belif\b", r"\bwhen\b"]:
        count += len(re.findall(pat, line))
    if lang == "Python":
        count += len(re.findall(r"\b(def|class|with)\b", line))
    count += line.count("&&") + line.count("||") + line.count("?")
    return count


def collect(args):
    paths = args.paths or ["."]
    remaps = count_as_map(args.count_as)
    langs = {}
    files = []
    seen = set()
    for path in iter_files(paths, args):
        try:
            data = path.read_bytes()
        except OSError:
            continue
        info = language_for(path, data, remaps)
        if not info:
            continue
        if args.no_duplicates:
            key = hash(data)
            if key in seen:
                continue
            seen.add(key)
        st = analyze(path, info, args)
        if not st:
            continue
        files.append(st)
        agg = langs.setdefault(st.name, LangStat(st.name))
        agg.bytes += st.bytes
        agg.lines += st.lines
        agg.code += st.code
        agg.comment += st.comment
        agg.blank += st.blank
        agg.complexity += st.complexity
        agg.count += 1
        agg.uloc += st.uloc
        agg.max_chars = max(agg.max_chars, st.max_chars)
        agg.mean_total += st.mean_chars
        agg.files.append(st)
    return sort_langs(list(langs.values()), args), files


def sort_langs(rows, args):
    key = args.sort.lower()
    if key == "name":
        return sorted(rows, key=lambda r: r.name.lower())
    attr = {"files": "count", "lines": "lines", "blanks": "blank", "comments": "comment", "code": "code", "complexity": "complexity"}.get(key, "count")
    return sorted(rows, key=lambda r: (-getattr(r, attr), r.name.lower()))


def row_json(r, include_files=False):
    return {
        "Name": r.name,
        "Bytes": r.bytes,
        "CodeBytes": 0,
        "Lines": r.lines,
        "Code": r.code,
        "Comment": r.comment,
        "Blank": r.blank,
        "Complexity": r.complexity,
        "Count": r.count,
        "WeightedComplexity": 0,
        "Files": [file_json(f) for f in r.files] if include_files else [],
        "LineLength": None,
        "ULOC": r.uloc,
    }


def file_json(f):
    return {
        "Name": f.path,
        "Bytes": f.bytes,
        "CodeBytes": 0,
        "Lines": f.lines,
        "Code": f.code,
        "Comment": f.comment,
        "Blank": f.blank,
        "Complexity": f.complexity,
        "WeightedComplexity": 0,
        "LineLength": None,
        "ULOC": f.uloc,
    }


def totals(rows):
    t = LangStat("Total")
    for r in rows:
        t.bytes += r.bytes
        t.lines += r.lines
        t.code += r.code
        t.comment += r.comment
        t.blank += r.blank
        t.complexity += r.complexity
        t.count += r.count
        t.uloc += r.uloc
    return t


def format_table(rows, args):
    no_complex = args.no_complexity
    total = totals(rows)
    lines = [BORDER]
    if no_complex:
        lines.append(f"{'Language':<23}{'Files':>10}{'Lines':>12}{'Blanks':>11}{'Comments':>12}{'Code':>11}")
    else:
        lines.append(f"{'Language':<18}{'Files':>7}{'Lines':>12}{'Blanks':>10}{'Comments':>10}{'Code':>11}{'Complexity':>11}")
    lines.append(BORDER)
    for r in rows:
        lines.append(format_lang_line(r, no_complex))
        if args.by_file:
            lines.append(BORDER)
            for f in sorted(r.files, key=lambda x: x.path):
                lines.append(format_file_line(f, no_complex))
            lines.append(BORDER)
    if not args.by_file:
        lines.append(BORDER)
    lines.append(format_lang_line(total, no_complex))
    lines.append(BORDER)
    if not args.no_cocomo:
        cost = cocomo_cost(total.code, args)
        schedule = 2.5 * (max(cost[1], 0.01) ** 0.38)
        people = cost[1] / schedule if schedule else 0
        lines.append(f"Estimated Cost to Develop ({args.cocomo_project_type}) {args.currency_symbol}{cost[0]:,.0f}")
        lines.append(f"Estimated Schedule Effort ({args.cocomo_project_type}) {schedule:.2f} months")
        lines.append(f"Estimated People Required ({args.cocomo_project_type}) {people:.2f}")
        lines.append(BORDER)
    if not args.no_size:
        mb = total.bytes / 1000000.0
        lines.append(f"Processed {total.bytes} bytes, {mb:.3f} megabytes (SI)")
        lines.append(BORDER)
    return "\n".join(lines) + "\n"


def format_lang_line(r, no_complex):
    if no_complex:
        return f"{r.name:<23}{r.count:>10,}{r.lines:>12,}{r.blank:>11,}{r.comment:>12,}{r.code:>11,}"
    return f"{r.name:<18}{r.count:>7,}{r.lines:>12,}{r.blank:>10,}{r.comment:>10,}{r.code:>11,}{r.complexity:>11,}"


def format_file_line(f, no_complex):
    name = f.path
    if no_complex:
        return f"{name:<27}{f.lines:>10,}{f.blank:>10,}{f.comment:>12,}{f.code:>11,}"
    return f"{name:<27}{f.lines:>10,}{f.blank:>10,}{f.comment:>10,}{f.code:>11,}{f.complexity:>11,}"


def cocomo_cost(code, args):
    kloc = max(code / 1000.0, 0.001)
    effort = 2.4 * (kloc ** 1.05) * args.eaf
    monthly = (args.avg_wage * args.overhead) / 12.0
    return effort * monthly, effort


def format_csv(rows):
    import io
    out = io.StringIO()
    writer = csv.writer(out, lineterminator="\n")
    writer.writerow(["Language", "Lines", "Code", "Comments", "Blanks", "Complexity", "Bytes", "Files", "ULOC"])
    for r in rows:
        writer.writerow([r.name, r.lines, r.code, r.comment, r.blank, r.complexity, r.bytes, r.count, r.uloc])
    return out.getvalue()


def format_cloc_yaml(rows):
    total = totals(rows)
    out = []
    for r in rows + [total]:
        key = "SUM" if r.name == "Total" else r.name
        out.append(f"{key}:")
        out.append(f"  nFiles: {r.count}")
        out.append(f"  blank: {r.blank}")
        out.append(f"  comment: {r.comment}")
        out.append(f"  code: {r.code}")
    return "\n".join(out) + "\n"


def format_openmetrics(rows):
    out = []
    for r in rows:
        label = r.name.replace("\\", "\\\\").replace('"', '\\"')
        out.append(f'scc_files{{language="{label}"}} {r.count}')
        out.append(f'scc_lines{{language="{label}"}} {r.lines}')
        out.append(f'scc_code{{language="{label}"}} {r.code}')
        out.append(f'scc_comments{{language="{label}"}} {r.comment}')
        out.append(f'scc_blanks{{language="{label}"}} {r.blank}')
        out.append(f'scc_complexity{{language="{label}"}} {r.complexity}')
    return "\n".join(out) + ("\n" if out else "")


def format_html_table(rows, full=False):
    body = ["<table>", "<thead><tr><th>Language</th><th>Files</th><th>Lines</th><th>Blanks</th><th>Comments</th><th>Code</th><th>Complexity</th></tr></thead>", "<tbody>"]
    for r in rows + [totals(rows)]:
        body.append(f"<tr><td>{html.escape(r.name)}</td><td>{r.count}</td><td>{r.lines}</td><td>{r.blank}</td><td>{r.comment}</td><td>{r.code}</td><td>{r.complexity}</td></tr>")
    body += ["</tbody>", "</table>"]
    table = "\n".join(body) + "\n"
    if full:
        return "<!doctype html><html><body>\n" + table + "</body></html>\n"
    return table


def format_sql(rows, insert=False, project=""):
    project = project or "scc"
    if insert:
        out = []
    else:
        out = ["CREATE TABLE t (Project TEXT, Language TEXT, Files INTEGER, Lines INTEGER, Blanks INTEGER, Comments INTEGER, Code INTEGER, Complexity INTEGER);"]
    for r in rows:
        vals = [project, r.name, r.count, r.lines, r.blank, r.comment, r.code, r.complexity]
        out.append("INSERT INTO t VALUES (" + ",".join("'" + str(v).replace("'", "''") + "'" if isinstance(v, str) else str(v) for v in vals) + ");")
    return "\n".join(out) + ("\n" if out else "")


def render(rows, args, fmt=None):
    fmt = (fmt or args.format).lower()
    if fmt in {"tabular", "wide"}:
        return format_table(rows, args)
    if fmt == "json":
        return json.dumps([row_json(r, False) for r in rows], separators=(",", ":"))
    if fmt == "json2":
        total = totals(rows)
        cost, effort = cocomo_cost(total.code, args)
        schedule = 2.5 * (max(effort, 0.01) ** 0.38)
        people = effort / schedule if schedule else 0
        return json.dumps(
            {
                "languageSummary": [row_json(r, False) for r in rows],
                "estimatedCost": cost,
                "estimatedScheduleMonths": schedule,
                "estimatedPeople": people,
            },
            separators=(",", ":"),
        )
    if fmt in {"csv", "csv-stream"}:
        return format_csv(rows)
    if fmt == "cloc-yaml":
        return format_cloc_yaml(rows)
    if fmt == "openmetrics":
        return format_openmetrics(rows)
    if fmt == "html-table":
        return format_html_table(rows)
    if fmt == "html":
        return format_html_table(rows, True)
    if fmt == "sql":
        return format_sql(rows, False, args.sql_project)
    if fmt == "sql-insert":
        return format_sql(rows, True, args.sql_project)
    return format_table(rows, args)


def write_output(text, args):
    if args.output:
        Path(args.output).write_text(text)
        print(f"results written to {args.output}")
    else:
        sys.stdout.write(text)


def main(argv=None):
    argv = sys.argv[1:] if argv is None else argv
    if any(a in {"--help", "-h"} for a in argv):
        print_help()
        return 0
    if any(a == "--version" for a in argv):
        print(f"scc version {VERSION}")
        return 0
    if any(a in {"--languages", "-l"} for a in argv):
        for name, exts in LANGUAGE_LIST:
            print(f"{name} ({exts})")
        return 0
    args = parse_args(argv)
    if args is None:
        return 1
    if args.dryness:
        args.uloc = True
    try:
        rows, _ = collect(args)
    except FileNotFoundError as exc:
        print(f"file or directory could not be read: {exc.args[0]}", file=sys.stderr)
        return 1
    if args.format_multi:
        for spec in args.format_multi.split(","):
            if ":" not in spec:
                continue
            fmt, dest = spec.split(":", 1)
            text = render(rows, args, fmt)
            if dest == "stdout":
                sys.stdout.write(text)
            else:
                Path(dest).write_text(text)
        return 0
    write_output(render(rows, args), args)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
