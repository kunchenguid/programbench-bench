#!/usr/bin/env python3
import sys
import json
import base64
import urllib.request
from urllib.parse import urlsplit


VERSION = "0.25.3"

HELP = """xh is a friendly and fast tool for sending HTTP requests

Usage: executable [OPTIONS] <[METHOD] URL> [REQUEST_ITEM]...

Arguments:
  <[METHOD] URL>     The request URL, preceded by an optional HTTP method
  [REQUEST_ITEM]...  Optional key-value pairs to be included in the request.

Options:
  -j, --json
          (default) Serialize data items from the command line as a JSON object
  -f, --form
          Serialize data items from the command line as form fields
      --raw <RAW>
          Pass raw request data without extra processing
      --offline
          Construct HTTP requests without sending them anywhere
      --curl
          Print a translation to a curl command
      --curl-long
          Use the long versions of curl's flags
      --help
          Print help
  -V, --version
          Print version

Each option can be reset with a --no-OPTION argument.

Run "xh help" for more complete documentation.
"""


def normalize_url(text):
    if text.startswith(":/"):
        text = "localhost" + text[1:]
    elif text.startswith(":"):
        text = "localhost" + text
    if "://" not in text:
        text = "http://" + text
    return urlsplit(text)


def split_items(items, mode="json"):
    data = {}
    form = []
    query = []
    headers = []
    file_body = None
    for item in items:
        if item.startswith("@") and len(item) > 1:
            with open(item[1:], "r", encoding="utf-8") as handle:
                file_body = handle.read()
        elif "==" in item:
            key, value = item.split("==", 1)
            query.append((key, value))
        elif ":=" in item:
            key, raw = item.split(":=", 1)
            data[key] = json.loads(raw)
        elif ":" in item and not item.startswith("@"):
            key, value = item.split(":", 1)
            name = "-".join(part[:1].upper() + part[1:].lower() for part in key.split("-"))
            headers.append((name, value))
        elif "=" in item and "==" not in item:
            key, value = item.split("=", 1)
            if mode == "form":
                form.append((key, value))
            else:
                data[key] = value
    body = None
    if file_body is not None:
        body = file_body
    elif mode == "form" and form:
        body = "&".join(f"{k}={v}" for k, v in form)
    elif data:
        body = json.dumps(data, separators=(",", ":"))
    return query, body, headers, file_body is not None


def append_query(url, query):
    if not query:
        return url
    extra = "&".join(f"{k}={v}" for k, v in query)
    current = url.query
    combined = current + ("&" if current else "") + extra
    return url._replace(query=combined)


def url_to_string(url):
    out = url.geturl()
    return out


def shell_quote(text):
    return "'" + text.replace("'", "'\\''") + "'"


def render_curl(url, body=None, content_type=None, long_flags=False):
    parts = ["curl", url_to_string(url)]
    if body is not None and content_type == "application/json":
        hflag = "--header" if long_flags else "-H"
        dflag = "--data" if long_flags else "-d"
        parts.extend([hflag, shell_quote("content-type: application/json")])
        parts.extend([hflag, shell_quote("accept: application/json, */*;q=0.5")])
        parts.extend([dflag, shell_quote(body)])
    return " ".join(parts) + "\n"
def render_request(method, url, body=None, content_type=None, headers=None):
    headers = headers or []
    path = url.path or "/"
    if url.query:
        path += "?" + url.query
    host = url.netloc
    accept = "application/json, */*;q=0.5" if body is not None and content_type == "application/json" else "*/*"
    lines = [
        f"{method} {path} HTTP/1.1",
        "Accept-Encoding: gzip, deflate, br, zstd",
        f"User-Agent: xh/{VERSION}",
        "Connection: keep-alive",
    ]
    lines.extend(f"{name}: {value}" for name, value in headers)
    if content_type == "application/x-www-form-urlencoded":
        lines.append(f"Content-Type: {content_type}")
        lines.append(f"Accept: {accept}")
    elif content_type == "file":
        lines.append("Content-Type: application/json")
        lines.append(f"Accept: {accept}")
    else:
        lines.append(f"Accept: {accept}")
        if content_type:
            lines.append(f"Content-Type: {content_type}")
    if body is not None and content_type != "file":
        lines.append(f"Content-Length: {len(body.encode())}")
    lines.extend([f"Host: {host}", ""])
    if body is not None:
        lines.append(body)
        return "\n".join(lines) + "\n\n"
    return "\n".join(lines) + "\n"


def main(argv):
    if argv in (["--version"], ["-V"]):
        sys.stdout.write(f"xh {VERSION}\n-native-tls +rustls\n")
        return 0
    if argv in (["--help"], ["help"], ["-h"]):
        sys.stdout.write(HELP)
        return 0
    mode = "json"
    curl = False
    curl_long = False
    offline = False
    print_format = None
    auth = None
    auth_type = "basic"
    raw_body = None
    args = []
    i = 0
    while i < len(argv):
        arg = argv[i]
        if arg == "--offline":
            offline = True
            i += 1
            continue
        if arg in ("-I", "--ignore-stdin"):
            i += 1
            continue
        if arg in ("--pretty", "--format-options", "--style", "-s"):
            i += 2
            continue
        if arg.startswith("--pretty=") or arg.startswith("--format-options=") or arg.startswith("--style="):
            i += 1
            continue
        if arg in ("-p", "--print"):
            print_format = argv[i + 1]
            i += 2
            continue
        if arg.startswith("-p=") or arg.startswith("--print="):
            print_format = arg.split("=", 1)[1]
            i += 1
            continue
        if arg in ("-b", "--body"):
            print_format = "b"
            i += 1
            continue
        if arg in ("-h", "--headers"):
            print_format = "h"
            i += 1
            continue
        if arg == "--curl":
            curl = True
            i += 1
            continue
        if arg == "--curl-long":
            curl = True
            curl_long = True
            i += 1
            continue
        if arg in ("-f", "--form"):
            mode = "form"
            i += 1
            continue
        if arg in ("-a", "--auth"):
            auth = argv[i + 1]
            i += 2
            continue
        if arg == "--raw":
            raw_body = argv[i + 1]
            i += 2
            continue
        if arg.startswith("--raw="):
            raw_body = arg.split("=", 1)[1]
            i += 1
            continue
        if arg.startswith("--auth="):
            auth = arg.split("=", 1)[1]
            i += 1
            continue
        if arg in ("-A", "--auth-type"):
            auth_type = argv[i + 1]
            i += 2
            continue
        if arg.startswith("--auth-type="):
            auth_type = arg.split("=", 1)[1]
            i += 1
            continue
        args.append(arg)
        i += 1
    if not args:
        print("executable: error: the following required arguments were not provided:", file=sys.stderr)
        return 1
    method = "GET"
    url_arg = args[0]
    request_items = args[1:]
    if len(args) >= 2 and args[0].isalpha() and not any(ch in args[0] for ch in ".:/"):
        method = args[0].upper()
        url_arg = args[1]
        request_items = args[2:]
    query, body, headers, is_file_body = split_items(request_items, mode)
    if raw_body is not None:
        body = raw_body
    if auth:
        if auth_type == "bearer":
            headers.insert(0, ("Authorization", "Bearer " + auth))
        else:
            token = base64.b64encode(auth.encode()).decode()
            headers.insert(0, ("Authorization", "Basic " + token))
    url = append_query(normalize_url(url_arg), query)
    if body is not None and method == "GET":
        method = "POST"
    content_type = None
    if body is not None:
        content_type = "application/x-www-form-urlencoded" if mode == "form" else "application/json"
        if is_file_body:
            content_type = "file"
    if curl:
        sys.stdout.write(render_curl(url, body, content_type, curl_long))
        return 0
    if offline:
        sys.stdout.write(render_request(method, url, body, content_type, headers))
        return 0
    req_headers = {name: value for name, value in headers}
    if content_type in ("application/json", "application/x-www-form-urlencoded"):
        req_headers["Content-Type"] = content_type
    data = body.encode() if body is not None else None
    request = urllib.request.Request(url_to_string(url), data=data, headers=req_headers, method=method)
    opener = urllib.request.build_opener(urllib.request.ProxyHandler({}))
    with opener.open(request) as response:
        response_body = response.read().decode(errors="replace")
        if print_format and "h" in print_format:
            sys.stdout.write(f"HTTP/{response.version // 10}.{response.version % 10} {response.status} {response.reason}\n")
            for name, value in response.headers.items():
                sys.stdout.write(f"{name}: {value}\n")
            sys.stdout.write("\n")
        if print_format is None or "b" in print_format:
            sys.stdout.write(response_body)
    return 0


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
