import os
import subprocess
import sys
import threading
import unittest
from http.server import BaseHTTPRequestHandler, HTTPServer


ROOT = os.path.dirname(os.path.dirname(__file__))
CLI = [sys.executable, os.path.join(ROOT, "xh.py")]


def run_cli(*args, input_data=None):
    return subprocess.run(
        CLI + list(args),
        input=input_data,
        text=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        cwd=ROOT,
    )


class XhCliTests(unittest.TestCase):
    def test_offline_get_renders_request_with_default_headers(self):
        result = run_cli("--offline", "-I", "http://example.org/json")

        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertEqual(
            result.stdout,
            "GET /json HTTP/1.1\n"
            "Accept-Encoding: gzip, deflate, br, zstd\n"
            "User-Agent: xh/0.25.3\n"
            "Connection: keep-alive\n"
            "Accept: */*\n"
            "Host: example.org\n"
            "\n",
        )

    def test_request_items_create_compact_json_body_and_post_method(self):
        result = run_cli("--offline", "-I", "http://example.org/post", "name=alice", "age:=30")

        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertEqual(
            result.stdout,
            "POST /post HTTP/1.1\n"
            "Accept-Encoding: gzip, deflate, br, zstd\n"
            "User-Agent: xh/0.25.3\n"
            "Connection: keep-alive\n"
            "Accept: application/json, */*;q=0.5\n"
            "Content-Type: application/json\n"
            "Content-Length: 25\n"
            "Host: example.org\n"
            "\n"
            "{\"name\":\"alice\",\"age\":30}\n\n",
        )

    def test_double_equals_items_are_appended_to_query_string(self):
        result = run_cli("--offline", "-I", "get", "httpbin.org/json", "id==5", "sort==true")

        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertEqual(
            result.stdout,
            "GET /json?id=5&sort=true HTTP/1.1\n"
            "Accept-Encoding: gzip, deflate, br, zstd\n"
            "User-Agent: xh/0.25.3\n"
            "Connection: keep-alive\n"
            "Accept: */*\n"
            "Host: httpbin.org\n"
            "\n",
        )

    def test_header_items_are_title_cased_and_rendered_before_accept(self):
        result = run_cli("--offline", "-I", "get", "httpbin.org/json", "x-api-key:12345")

        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertEqual(
            result.stdout,
            "GET /json HTTP/1.1\n"
            "Accept-Encoding: gzip, deflate, br, zstd\n"
            "User-Agent: xh/0.25.3\n"
            "Connection: keep-alive\n"
            "X-Api-Key: 12345\n"
            "Accept: */*\n"
            "Host: httpbin.org\n"
            "\n",
        )

    def test_form_mode_serializes_fields_as_urlencoded_body(self):
        result = run_cli("--offline", "-I", "-f", "http://e.test/path", "a=1", "b=two")

        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertEqual(
            result.stdout,
            "POST /path HTTP/1.1\n"
            "Accept-Encoding: gzip, deflate, br, zstd\n"
            "User-Agent: xh/0.25.3\n"
            "Connection: keep-alive\n"
            "Content-Type: application/x-www-form-urlencoded\n"
            "Accept: */*\n"
            "Content-Length: 9\n"
            "Host: e.test\n"
            "\n"
            "a=1&b=two\n\n",
        )

    def test_curl_translation_for_json_post_uses_short_flags(self):
        result = run_cli("--curl", "-I", "http://example.org/post", "name=alice", "age:=30")

        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertEqual(
            result.stdout,
            "curl http://example.org/post -H 'content-type: application/json' "
            "-H 'accept: application/json, */*;q=0.5' -d '{\"name\":\"alice\",\"age\":30}'\n",
        )

    def test_version_matches_documented_xh_version(self):
        result = run_cli("--version")

        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertEqual(result.stdout, "xh 0.25.3\n-native-tls +rustls\n")

    def test_basic_auth_adds_authorization_header(self):
        result = run_cli("--offline", "-I", "-a", "user:pass", "http://e.test/")

        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertIn("Authorization: Basic dXNlcjpwYXNz\n", result.stdout)
        self.assertIn("GET / HTTP/1.1\n", result.stdout)

    def test_raw_option_sends_given_string_as_post_body(self):
        result = run_cli("--offline", "-I", "--raw", "hello", "http://e.test/path")

        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertEqual(
            result.stdout,
            "POST /path HTTP/1.1\n"
            "Accept-Encoding: gzip, deflate, br, zstd\n"
            "User-Agent: xh/0.25.3\n"
            "Connection: keep-alive\n"
            "Accept: application/json, */*;q=0.5\n"
            "Content-Type: application/json\n"
            "Content-Length: 5\n"
            "Host: e.test\n"
            "\n"
            "hello\n\n",
        )

    def test_at_filename_uses_file_as_request_body(self):
        with open(os.path.join(ROOT, "tmpbody"), "w", encoding="utf-8") as handle:
            handle.write("abc")

        result = run_cli("--offline", "-I", "http://e.test/post", "@tmpbody")

        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertEqual(
            result.stdout,
            "POST /post HTTP/1.1\n"
            "Accept-Encoding: gzip, deflate, br, zstd\n"
            "User-Agent: xh/0.25.3\n"
            "Connection: keep-alive\n"
            "Content-Type: application/json\n"
            "Accept: */*\n"
            "Host: e.test\n"
            "\n"
            "abc\n\n",
        )

    def test_real_get_prints_response_body_by_default(self):
        class Handler(BaseHTTPRequestHandler):
            def do_GET(self):
                self.send_response(200)
                self.send_header("Content-Type", "text/plain")
                self.end_headers()
                self.wfile.write(b"hello")

            def log_message(self, *args):
                pass

        server = HTTPServer(("127.0.0.1", 0), Handler)
        thread = threading.Thread(target=server.serve_forever, daemon=True)
        thread.start()
        try:
            result = run_cli("-I", "--pretty=none", f"http://127.0.0.1:{server.server_port}/test")
        finally:
            server.shutdown()
            thread.join()

        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertEqual(result.stdout, "hello")


if __name__ == "__main__":
    unittest.main()
