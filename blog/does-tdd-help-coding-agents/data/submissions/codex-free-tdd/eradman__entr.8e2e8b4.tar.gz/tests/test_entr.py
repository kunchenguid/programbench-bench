#!/usr/bin/env python3
import os
import signal
import subprocess
import tempfile
import time
import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
BIN = ROOT / "executable"


class EntrCliTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        subprocess.run(["bash", "compile.sh"], cwd=ROOT, check=True)

    def run_entr(self, args, stdin="", cwd=None, timeout=3, env=None):
        merged_env = os.environ.copy()
        if env:
            merged_env.update(env)
        return subprocess.run(
            [str(BIN), *args],
            input=stdin,
            text=True,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            cwd=cwd or ROOT,
            timeout=timeout,
            env=merged_env,
        )

    def test_help_displays_release_usage_and_summary(self):
        result = self.run_entr(["-h"])
        self.assertEqual(result.returncode, 1)
        self.assertEqual(result.stderr, "")
        self.assertIn("release: 5.7\n", result.stdout)
        self.assertIn("usage: entr [-acdnprsxz] utility", result.stdout)
        self.assertIn("    -n  Non-interactive mode\n", result.stdout)

    def test_requires_regular_files_on_stdin(self):
        result = self.run_entr(["-nz", "/bin/echo", "hi"])
        self.assertEqual(result.returncode, 1)
        self.assertEqual(result.stdout, "")
        self.assertEqual(result.stderr, "executable: No regular files to watch\n")

    def test_noninteractive_exit_after_child_returns_child_status(self):
        result = self.run_entr(["-nz", "/bin/sh", "-c", "exit 7"], stdin="README.md\n")
        self.assertEqual(result.stdout, "")
        self.assertEqual(result.stderr, "")
        self.assertEqual(result.returncode, 7)

    def test_replaces_only_first_placeholder_with_input_path(self):
        result = self.run_entr(["-nz", "/bin/echo", "/_", "x", "/_"], stdin="README.md\n")
        self.assertEqual(result.returncode, 0)
        self.assertEqual(result.stdout, "README.md x /_\n")
        self.assertEqual(result.stderr, "")

    def test_reports_missing_files_and_then_no_watchable_files(self):
        result = self.run_entr(["-nz", "/bin/echo", "hi"], stdin="NOPE\n")
        self.assertEqual(result.returncode, 1)
        self.assertEqual(result.stdout, "")
        self.assertEqual(
            result.stderr,
            "executable: unable to stat 'NOPE'\n"
            "executable: No regular files to watch\n",
        )

    def test_double_dash_is_reported_as_invalid_option(self):
        result = self.run_entr(["--"])
        self.assertEqual(result.returncode, 1)
        self.assertEqual(result.stdout, "")
        self.assertIn("executable: invalid option -- '-'\n", result.stderr)
        self.assertIn("hint: use -h to display option summary\n", result.stderr)

    def test_shell_mode_sets_zero_to_watched_file_and_passes_arguments(self):
        result = self.run_entr(
            ["-nzs", 'printf "zero=%s one=%s\\n" "$0" "$1"', "ARG1"],
            stdin="README.md\n",
        )
        self.assertEqual(result.returncode, 0)
        self.assertEqual(result.stdout, "zero=README.md one=ARG1\n")
        self.assertEqual(result.stderr, "")

    def test_postpone_runs_after_file_change(self):
        with tempfile.TemporaryDirectory() as td:
            work = Path(td)
            watched = work / "a"
            out = work / "out"
            watched.write_text("")
            proc = subprocess.Popen(
                [str(BIN), "-np", "/bin/sh", "-c", f"echo RUN >> {out}"],
                cwd=work,
                stdin=subprocess.PIPE,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                text=True,
                preexec_fn=os.setsid,
            )
            assert proc.stdin is not None
            proc.stdin.write("a\n")
            proc.stdin.close()
            time.sleep(0.25)
            self.assertFalse(out.exists())
            watched.write_text("changed")
            deadline = time.time() + 2
            while time.time() < deadline and not out.exists():
                time.sleep(0.05)
            os.killpg(proc.pid, signal.SIGINT)
            proc.wait(timeout=2)
            self.assertEqual(out.read_text(), "RUN\n")

    def test_directory_tracking_exits_two_when_entry_added(self):
        with tempfile.TemporaryDirectory() as td:
            work = Path(td)
            (work / "a").write_text("")
            proc = subprocess.Popen(
                [str(BIN), "-nd", "/bin/echo", "RUN"],
                cwd=work,
                stdin=subprocess.PIPE,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                text=True,
            )
            assert proc.stdin is not None
            proc.stdin.write("a\n")
            proc.stdin.close()
            proc.stdin = None
            time.sleep(0.25)
            (work / "b").write_text("")
            stdout, stderr = proc.communicate(timeout=2)
            self.assertEqual(proc.returncode, 2)
            self.assertEqual(stdout, "RUN\nRUN\n")
            self.assertEqual(stderr, "executable: directory altered\n")


if __name__ == "__main__":
    unittest.main()
