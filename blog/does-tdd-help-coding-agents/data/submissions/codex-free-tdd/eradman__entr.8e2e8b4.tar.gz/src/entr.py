#!/usr/bin/env python3
import os
import signal
import subprocess
import sys
import time
from pathlib import Path


RELEASE = "5.7"
PROG = "executable"


def usage_hint():
    print(f"release: {RELEASE}", file=sys.stderr)
    print("usage: entr [-acdnprsxz] utility [argument [/_] ...] < filenames", file=sys.stderr)
    print("hint: use -h to display option summary", file=sys.stderr)


def help_text():
    print(f"release: {RELEASE}")
    print("usage: entr [-acdnprsxz] utility [argument [/_] ...] < filenames")
    print("summary:")
    print("    -a  Do not consolidate events")
    print("    -c  Clear screen before execution")
    print("    -d  Track files added or removed from directories")
    print("    -n  Non-interactive mode")
    print("    -p  Wait for first event")
    print("    -r  Run as a background process, use signal to restart")
    print("    -s  Evaluate using a shell")
    print("    -x  Format exit status")
    print("    -z  Exit after the utility completes")
    print("docs:")
    print("    man entr")


def parse_args(argv):
    flags = {k: 0 for k in "acdnprsxz"}
    i = 0
    while i < len(argv) and argv[i].startswith("-") and argv[i] != "-":
        arg = argv[i]
        for ch in arg[1:]:
            if ch == "h":
                help_text()
                return None, None, 1
            if ch not in flags:
                print(f"{PROG}: invalid option -- '{ch}'", file=sys.stderr)
                usage_hint()
                return None, None, 1
            flags[ch] += 1
        i += 1
    if i >= len(argv):
        usage_hint()
        return None, None, 1
    return flags, argv[i:], None


def stat_file(name):
    try:
        st = os.stat(name)
    except OSError:
        print(f"{PROG}: unable to stat '{name}'", file=sys.stderr)
        return None
    if not os.path.isfile(name):
        return None
    return (st.st_dev, st.st_ino, st.st_mtime_ns, st.st_size)


def read_files():
    files = []
    seen = set()
    for raw in sys.stdin:
        name = raw.rstrip("\n")
        if not name or name in seen:
            continue
        seen.add(name)
        if stat_file(name) is not None:
            files.append(name)
    if not files:
        print(f"{PROG}: No regular files to watch", file=sys.stderr)
    return files


def directory_snapshot(files, include_hidden):
    dirs = {}
    for name in files:
        parent = os.path.dirname(name) or "."
        if parent in dirs:
            continue
        try:
            entries = set()
            for entry in os.listdir(parent):
                if not include_hidden and entry.startswith("."):
                    continue
                entries.add(entry)
            dirs[parent] = entries
        except OSError:
            dirs[parent] = set()
    return dirs


def changed_file(files, states):
    for name in files:
        current = stat_file(name)
        if current is None:
            return name
        if current != states.get(name):
            states[name] = current
            return name
    return None


def changed_directory(previous, include_hidden):
    for parent, old_entries in previous.items():
        try:
            entries = set()
            for entry in os.listdir(parent):
                if not include_hidden and entry.startswith("."):
                    continue
                entries.add(entry)
        except OSError:
            entries = set()
        if entries != old_entries:
            previous[parent] = entries
            return True
    return False


def command_for(args, trigger, shell_mode):
    if shell_mode:
        shell = os.environ.get("SHELL", "/bin/sh")
        return [shell, "-c", args[0], trigger, *args[1:]]
    cmd = list(args)
    for i, arg in enumerate(cmd):
        if arg == "/_":
            cmd[i] = trigger
            break
    return cmd


def run_child(args, trigger, flags):
    if flags["c"]:
        if flags["c"] > 1:
            sys.stdout.write("\033[3J")
        sys.stdout.write("\033[H\033[2J")
        sys.stdout.flush()
    cmd = command_for(args, trigger, flags["s"] > 0)
    try:
        proc = subprocess.run(cmd)
        return proc.returncode
    except FileNotFoundError as e:
        print(f"{PROG}: exec {cmd[0]}: {e.strerror}", file=sys.stderr)
        return 1
    except PermissionError as e:
        print(f"{PROG}: exec {cmd[0]}: {e.strerror}", file=sys.stderr)
        return 1


def main(argv):
    flags, args, early_status = parse_args(argv)
    if early_status is not None:
        return early_status
    if not flags["n"] and not sys.stdin.isatty():
        print(f"{PROG}: unable to get terminal attributes, use '-n' to run non-interactively", file=sys.stderr)
        return 1
    files = read_files()
    if not files:
        return 1

    states = {name: stat_file(name) for name in files}
    dirs = directory_snapshot(files, flags["d"] > 1) if flags["d"] else {}
    trigger = files[0]

    if not flags["p"]:
        status = run_child(args, trigger, flags)
        if flags["z"]:
            return status

    while True:
        time.sleep(0.05)
        if flags["d"] and changed_directory(dirs, flags["d"] > 1):
            run_child(args, trigger, flags)
            print(f"{PROG}: directory altered", file=sys.stderr)
            return 2
        changed = changed_file(files, states)
        if changed is not None:
            trigger = changed
            status = run_child(args, trigger, flags)
            if flags["z"]:
                return status


if __name__ == "__main__":
    try:
        raise SystemExit(main(sys.argv[1:]))
    except KeyboardInterrupt:
        raise SystemExit(0)
