package main

import (
	"flag"
	"fmt"
	"os"
	"time"
)

const usageText = `Usage: jplot [OPTIONS] FIELD_SPEC [FIELD_SPEC...]:

OPTIONS:
  -interval duration
    	When url is provided, defines the interval between fetches. Note that counter fields are computed based on this interval. (default 1s)
  -rows int
    	Limits the height of the graph output.
  -steps int
    	Number of values to plot. (default 100)
  -url string
    	URL to fetch every second. Read JSON objects from stdin if not specified.

FIELD_SPEC: [<option>[,<option>...]:]path
  option:
    - counter: Computes the difference with the last value. The value must increase monotonically.
    - marker: When the value is none-zero, a vertical line is drawn.
  path:
    JSON field path (eg: field.sub-field).
`

func main() {
	os.Stdout.Write([]byte("\x1b[c"))
	for _, arg := range os.Args[1:] {
		if arg == "--help" {
			fmt.Fprint(os.Stdout, usageText)
			os.Exit(0)
		}
	}

	fs := flag.NewFlagSet("jplot", flag.ContinueOnError)
	fs.SetOutput(os.Stderr)
	fs.Usage = func() {
		fmt.Fprint(os.Stderr, usageText)
	}

	var interval time.Duration
	var rows int
	var steps int
	var url string
	fs.DurationVar(&interval, "interval", time.Second, "")
	fs.IntVar(&rows, "rows", 0, "")
	fs.IntVar(&steps, "steps", 100, "")
	fs.StringVar(&url, "url", "", "")

	if err := fs.Parse(os.Args[1:]); err != nil {
		if err == flag.ErrHelp {
			fmt.Fprint(os.Stdout, "jplot:  iTerm2, Kitty, or DRCS Sixel graphics required\n")
			os.Exit(0)
		}
		os.Exit(2)
	}

	_, _, _, _ = interval, rows, steps, url
	fmt.Fprint(os.Stdout, "jplot:  iTerm2, Kitty, or DRCS Sixel graphics required\n")
	os.Exit(1)
}
