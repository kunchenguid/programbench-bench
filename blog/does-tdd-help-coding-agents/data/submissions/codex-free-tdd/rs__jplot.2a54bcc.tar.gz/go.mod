module cleanroom-jplot

go 1.20
