import os
import re
import subprocess
import sys
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
APP = [sys.executable, str(ROOT / "src" / "genact.py")]

MODULES = [
    "ansible", "bootlog", "botnet", "bruteforce", "cargo", "cc",
    "composer", "cryptomining", "docker_build", "docker_image_rm", "download",
    "julia", "kernel_compile", "memdump", "mkinitcpio", "rkhunter",
    "simcity", "terraform", "uv", "weblog", "wpt",
]


def run_app(*args, timeout=3):
    env = os.environ.copy()
    env.update({"COLUMNS": "120", "LINES": "40"})
    return subprocess.run(APP + list(args), text=True, capture_output=True, env=env, timeout=timeout)


class GenactCliTests(unittest.TestCase):
    def test_help_matches_documented_cli_shape(self):
        proc = run_app("--help")
        self.assertEqual(proc.returncode, 0)
        self.assertIn("A nonsense activity generator\n\nUsage: executable [OPTIONS]", proc.stdout)
        self.assertIn("-m, --modules <MODULES>", proc.stdout)
        self.assertIn("[possible values: ansible, bootlog, botnet", proc.stdout)
        self.assertIn("--print-manpage", proc.stdout)
        self.assertEqual(proc.stderr, "")

    def test_version_and_module_listing_are_stable(self):
        version = run_app("--version")
        self.assertEqual(version.stdout, "genact 1.5.1\n")
        listing = run_app("--list-modules")
        self.assertEqual(listing.returncode, 0)
        self.assertEqual(listing.stdout.splitlines(), ["Available modules:"] + [f"  {m}" for m in MODULES])

    def test_rejects_invalid_module_like_clap(self):
        proc = run_app("--modules", "bogus")
        self.assertEqual(proc.returncode, 2)
        self.assertIn("error: invalid value 'bogus' for '--modules <MODULES>'", proc.stderr)
        self.assertIn("[possible values: ansible, bootlog", proc.stderr)
        self.assertIn("For more information, try '--help'.", proc.stderr)

    def test_prints_manpage_and_bash_completion(self):
        man = run_app("--print-manpage")
        self.assertEqual(man.returncode, 0)
        self.assertIn(".TH genact 1", man.stdout)
        self.assertIn(".SH OPTIONS", man.stdout)
        self.assertIn("genact \\- A nonsense activity generator", man.stdout)
        bash = run_app("--print-completions", "bash")
        self.assertEqual(bash.returncode, 0)
        self.assertIn("_genact() {", bash.stdout)
        self.assertIn("complete -F _genact", bash.stdout)
        self.assertIn("ansible bootlog botnet", bash.stdout)

    def test_representative_modules_emit_domain_specific_lines(self):
        cases = {
            "cargo": r"Downloading|Compiling|Finished|Saving work to disk",
            "cc": r"clang -c .* -o .+\.o|gcc -c .* -o .+\.o",
            "weblog": r'GET /.+ HTTP/1\.0" (200|201|400|401|403|404|500|502|503)',
            "docker_build": r"Step \d+/\d+ :|Successfully built|Sending build context",
            "terraform": r"terraform|Refreshing state|Plan:|Apply complete",
        }
        for module, pattern in cases.items():
            with self.subTest(module=module):
                proc = run_app("--modules", module, "--instant-print-lines", "8", "--exit-after-modules", "1")
                self.assertEqual(proc.returncode, 0, proc.stderr)
                self.assertRegex(proc.stdout, pattern)

    def test_exit_after_time_accepts_compound_duration_and_stops(self):
        proc = run_app("--modules", "weblog", "--exit-after-time", "1s", "--instant-print-lines", "2", timeout=4)
        self.assertEqual(proc.returncode, 0)
        self.assertGreaterEqual(len(proc.stdout.splitlines()), 1)


if __name__ == "__main__":
    unittest.main()
