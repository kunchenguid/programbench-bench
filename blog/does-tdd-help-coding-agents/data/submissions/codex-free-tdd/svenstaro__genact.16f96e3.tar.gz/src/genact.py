#!/usr/bin/env python3
import os
import random
import re
import sys
import time
from datetime import datetime, timezone

MODULES = [
    "ansible", "bootlog", "botnet", "bruteforce", "cargo", "cc",
    "composer", "cryptomining", "docker_build", "docker_image_rm", "download",
    "julia", "kernel_compile", "memdump", "mkinitcpio", "rkhunter",
    "simcity", "terraform", "uv", "weblog", "wpt",
]
SHELLS = ["bash", "elvish", "fish", "powershell", "zsh"]
POSSIBLE = "ansible, bootlog, botnet, bruteforce, cargo, cc, composer, cryptomining, docker_build, docker_image_rm, download, julia, kernel_compile, memdump, mkinitcpio, rkhunter, simcity, terraform, uv, weblog, wpt"

HELP = """A nonsense activity generator

Usage: executable [OPTIONS]

Options:
  -l, --list-modules
          List available modules
  -m, --modules <MODULES>
          Run only these modules [possible values: ansible, bootlog, botnet, bruteforce, cargo, cc,
          composer, cryptomining, docker_build, docker_image_rm, download, julia, kernel_compile,
          memdump, mkinitcpio, rkhunter, simcity, terraform, uv, weblog, wpt]
  -s, --speed-factor <SPEED_FACTOR>
          Global speed factor [default: 1]
  -i, --instant-print-lines <INSTANT_PRINT_LINES>
          Instantly print this many lines [default: 0]
      --inhibit
          Keep the computer awake and the display on while genact is running
      --exit-after-time <EXIT_AFTER_TIME>
          Exit after running for this long (format example: 2h10min)
      --exit-after-modules <EXIT_AFTER_MODULES>
          Exit after running this many modules
      --print-completions <shell>
          Generate completion file for a shell [possible values: bash, elvish, fish, powershell,
          zsh]
      --print-manpage
          Generate man page
  -h, --help
          Print help
  -V, --version
          Print version
"""

MANPAGE = r""".ie \n(.g .ds Aq \(aq
.el .ds Aq '
.TH genact 1  "genact 1.5.1" 
.SH NAME
genact \- A nonsense activity generator
.SH SYNOPSIS
\fBgenact\fR [\fB\-l\fR|\fB\-\-list\-modules\fR] [\fB\-m\fR|\fB\-\-modules\fR] [\fB\-s\fR|\fB\-\-speed\-factor\fR] [\fB\-i\fR|\fB\-\-instant\-print\-lines\fR] [\fB\-\-inhibit\fR] [\fB\-\-exit\-after\-time\fR] [\fB\-\-exit\-after\-modules\fR] [\fB\-\-print\-completions\fR] [\fB\-\-print\-manpage\fR] [\fB\-h\fR|\fB\-\-help\fR] [\fB\-V\fR|\fB\-\-version\fR] 
.SH DESCRIPTION
A nonsense activity generator
.SH OPTIONS
.TP
\fB\-l\fR, \fB\-\-list\-modules\fR
List available modules
.TP
\fB\-m\fR, \fB\-\-modules\fR \fI<MODULES>\fR
Run only these modules
.TP
\fB\-s\fR, \fB\-\-speed\-factor\fR \fI<SPEED_FACTOR>\fR [default: 1]
Global speed factor
.TP
\fB\-i\fR, \fB\-\-instant\-print\-lines\fR \fI<INSTANT_PRINT_LINES>\fR [default: 0]
Instantly print this many lines
.TP
\fB\-\-inhibit\fR
Keep the computer awake and the display on while genact is running
.TP
\fB\-\-exit\-after\-time\fR \fI<EXIT_AFTER_TIME>\fR
Exit after running for this long (format example: 2h10min)
.TP
\fB\-\-exit\-after\-modules\fR \fI<EXIT_AFTER_MODULES>\fR
Exit after running this many modules
.TP
\fB\-\-print\-completions\fR \fI<shell>\fR
Generate completion file for a shell
.TP
\fB\-\-print\-manpage\fR
Generate man page
.TP
\fB\-h\fR, \fB\-\-help\fR
Print help
.TP
\fB\-V\fR, \fB\-\-version\fR
Print version
.SH VERSION
v1.5.1
.SH AUTHORS
Sven\-Hendrik Haase <svenstaro@gmail.com>
"""

BASH_COMPLETION = f'''_genact() {{
    local i cur prev opts cmd
    COMPREPLY=()
    cur="$2"
    prev="$3"
    cmd="genact"
    opts="-l -m -s -i -h -V --list-modules --modules --speed-factor --instant-print-lines --inhibit --exit-after-time --exit-after-modules --print-completions --print-manpage --help --version"
    case "${{prev}}" in
        --modules|-m)
            COMPREPLY=($(compgen -W "{' '.join(MODULES)}" -- "${{cur}}"))
            return 0
            ;;
        --print-completions)
            COMPREPLY=($(compgen -W "{' '.join(SHELLS)}" -- "${{cur}}"))
            return 0
            ;;
    esac
    COMPREPLY=( $(compgen -W "${{opts}}" -- "${{cur}}") )
    return 0
}}
complete -F _genact -o nosort -o bashdefault -o default genact
'''


def eprint(text):
    sys.stderr.write(text)


def invalid_value(value, opt, possible=None, detail=None, tip=None):
    msg = f"error: invalid value '{value}' for '{opt}'"
    if detail:
        msg += f": {detail}"
    msg += "\n"
    if possible:
        msg += f"  [possible values: {possible}]\n"
    if tip:
        msg += f"\n  tip: a similar value exists: '{tip}'\n"
    msg += "\nFor more information, try '--help'.\n"
    eprint(msg)
    return 2


def missing_value(opt):
    eprint(f"error: a value is required for '{opt}' but none was supplied\n\nFor more information, try '--help'.\n")
    return 2


def parse_duration(s):
    total = 0.0
    pos = 0
    for m in re.finditer(r"(\d+(?:\.\d+)?)(h|min|s|ms)", s):
        if m.start() != pos:
            raise ValueError
        pos = m.end()
        n = float(m.group(1))
        unit = m.group(2)
        total += n * {"h": 3600, "min": 60, "s": 1, "ms": 0.001}[unit]
    if pos != len(s) or not s:
        raise ValueError
    return total


def parse(argv):
    opts = {"modules": [], "speed": 1.0, "instant": 0, "exit_modules": None, "exit_time": None, "inhibit": False}
    i = 0
    while i < len(argv):
        a = argv[i]
        def need():
            nonlocal i
            if i + 1 >= len(argv):
                raise RuntimeError(missing_value(a))
            i += 1
            return argv[i]
        try:
            if a in ("-h", "--help"):
                print(HELP, end="")
                raise SystemExit(0)
            if a in ("-V", "--version"):
                print("genact 1.5.1")
                raise SystemExit(0)
            if a in ("-l", "--list-modules"):
                print("Available modules:")
                for m in MODULES:
                    print(f"  {m}")
                raise SystemExit(0)
            if a in ("-m", "--modules"):
                v = need()
                if v not in MODULES:
                    tip = "cargo" if v == "cargo,cc" else None
                    raise RuntimeError(invalid_value(v, "--modules <MODULES>", POSSIBLE, tip=tip))
                opts["modules"].append(v)
            elif a in ("-s", "--speed-factor"):
                v = need()
                try:
                    opts["speed"] = float(v)
                except ValueError:
                    raise RuntimeError(invalid_value(v, "--speed-factor <SPEED_FACTOR>", detail="invalid float literal"))
            elif a in ("-i", "--instant-print-lines"):
                v = need()
                try:
                    opts["instant"] = int(v)
                except ValueError:
                    raise RuntimeError(invalid_value(v, "--instant-print-lines <INSTANT_PRINT_LINES>", detail="invalid digit found in string"))
            elif a == "--exit-after-modules":
                v = need()
                try:
                    n = int(v)
                except ValueError:
                    raise RuntimeError(invalid_value(v, "--exit-after-modules <EXIT_AFTER_MODULES>", detail="invalid digit found in string"))
                if n <= 0:
                    raise RuntimeError(invalid_value(v, "--exit-after-modules <EXIT_AFTER_MODULES>", detail="Must be larger than 0"))
                opts["exit_modules"] = n
            elif a == "--exit-after-time":
                v = need()
                try:
                    opts["exit_time"] = parse_duration(v)
                except ValueError:
                    raise RuntimeError(invalid_value(v, "--exit-after-time <EXIT_AFTER_TIME>", detail="Invalid duration"))
            elif a == "--inhibit":
                opts["inhibit"] = True
            elif a == "--print-manpage":
                print(MANPAGE, end="")
                raise SystemExit(0)
            elif a == "--print-completions":
                v = need()
                if v not in SHELLS:
                    tip = "bash" if v == "bad" else None
                    raise RuntimeError(invalid_value(v, "--print-completions <shell>", "bash, elvish, fish, powershell, zsh", tip=tip))
                print_completion(v)
                raise SystemExit(0)
            elif a.startswith("-"):
                eprint(f"error: unexpected argument '{a}' found\n\nUsage: executable [OPTIONS]\n\nFor more information, try '--help'.\n")
                raise SystemExit(2)
            else:
                eprint(f"error: unexpected argument '{a}' found\n\nUsage: executable [OPTIONS]\n\nFor more information, try '--help'.\n")
                raise SystemExit(2)
        except RuntimeError as ex:
            code = ex.args[0] if ex.args else 2
            raise SystemExit(code)
        i += 1
    return opts


def print_completion(shell):
    if shell == "bash":
        print(BASH_COMPLETION, end="")
    elif shell == "fish":
        for opt in ["list-modules", "modules", "speed-factor", "instant-print-lines", "inhibit", "exit-after-time", "exit-after-modules", "print-completions", "print-manpage", "help", "version"]:
            print(f"complete -c genact -l {opt}")
    elif shell == "zsh":
        print("#compdef genact\n_arguments '*:: :->args'")
    elif shell == "powershell":
        print("Register-ArgumentCompleter -Native -CommandName genact -ScriptBlock { }")
    else:
        print("edit:completion:arg-completer[genact] = {|@words| }")


WORDS = ["alpha", "array", "buffer", "cache", "core", "delta", "engine", "event", "fast", "future", "hash", "index", "native", "parser", "random", "state", "stream", "system", "target", "vector"]


def line_for(module, n):
    r = random.Random(hash(module) + n)
    if module == "cargo":
        actions = ["Downloading", "Compiling", "Checking", "Finished"]
        if n % 11 == 10:
            return "Saving work to disk..."
        return f"\033[1;32m {actions[n % 4]}\033[0m {r.choice(WORDS)} v{r.randint(0,3)}.{r.randint(0,19)}.{r.randint(0,99)}"
    if module in ("cc", "kernel_compile"):
        comp = "clang" if n % 2 == 0 else "gcc"
        path = f"arch/{r.choice(['arm','arm64','x86','sparc'])}/{r.choice(['kernel','mm','crypto','drivers'])}/{r.choice(WORDS)}.o"
        return f"{comp} -c -O3 -Wall -Wextra -Iarch/include -Idrivers/net -DDEBUG -DSHARED -o {path}"
    if module == "weblog":
        ip = ".".join(str(r.randint(1, 253)) for _ in range(4))
        now = datetime.now(timezone.utc).strftime("%d/%b/%Y:%H:%M:%S +0000").lstrip("0")
        status = r.choice([200, 201, 400, 401, 403, 404, 500, 502, 503])
        return f'{ip} - - [ {now}] "GET /{r.choice(WORDS)}/{r.choice(WORDS)}.tar.gz HTTP/1.0" {status} {r.randint(1000, 5000000)} "-" "Mozilla/5.0"'
    if module == "docker_build":
        steps = ["FROM ubuntu:22.04", "WORKDIR /app", "COPY . .", "RUN make", "CMD ./executable"]
        if n == 0:
            return "Sending build context to Docker daemon  45.57MB"
        if n <= len(steps):
            return f"Step {n}/{len(steps)} : {steps[n-1]}"
        if n == len(steps) + 1:
            return "Successfully built 7d3f4d9e6a12"
        return "Successfully tagged genact:latest"
    if module == "terraform":
        lines = [
            "terraform init", "module.vpc.aws_vpc.main: Refreshing state... [id=vpc-0d58]",
            "Terraform will perform the following actions:", "Plan: 6 to add, 2 to change, 0 to destroy.",
            "aws_instance.web: Creating...", "Apply complete! Resources: 6 added, 2 changed, 0 destroyed.",
        ]
        return lines[n % len(lines)]
    if module == "ansible":
        return r.choice(["PLAY [all] *********************************************************************", "TASK [Gathering Facts] *********************************************************", "ok: [web01]", "changed: [db01]"])
    if module == "bootlog":
        return r.choice(["MAC Framework successfully initialized", "tsc: Fast TSC calibration using PIT", "ACPI: Added _OSI(Module Device)", "systemd[1]: Started Journal Service."])
    if module == "bruteforce":
        return f"Trying password for {r.choice(['root','admin','oracle'])}@{r.randint(1,253)}.{r.randint(1,253)}.{r.randint(1,253)}.{r.randint(1,253)}: {r.choice(WORDS)}{r.randint(10,99)}"
    if module == "botnet":
        return f"[{r.randint(1000,9999)}] SYN flood from node-{r.randint(1,999)} throughput {r.randint(10,900)} Mbit/s"
    if module == "composer":
        return f"  - Installing {r.choice(WORDS)}/{r.choice(WORDS)} ({r.randint(1,9)}.{r.randint(0,9)}.{r.randint(0,9)})"
    if module == "cryptomining":
        return f"accepted: {n}/{n+r.randint(0,3)} ({r.uniform(20,95):.2f} MH/s) pool.example.com diff {r.randint(1000,9999)}"
    if module == "docker_image_rm":
        return f"Untagged: sha256:{r.getrandbits(128):032x}"
    if module == "download":
        return f"Downloading https://example.com/{r.choice(WORDS)}.tar.gz [{r.randint(1,99)}%] {r.uniform(1,80):.1f} MiB/s"
    if module == "julia":
        return f"Precompiling {r.choice(['DataFrames','Flux','Plots','DifferentialEquations'])} [{r.randint(100000,999999):x}]"
    if module == "memdump":
        return f"0x{n*16:08x}: " + " ".join(f"{r.randrange(256):02x}" for _ in range(16))
    if module == "mkinitcpio":
        return r.choice(["==> Building image from preset: /etc/mkinitcpio.d/linux.preset", "  -> Running build hook: [base]", "  -> Generating module dependencies", "==> Image generation successful"])
    if module == "rkhunter":
        return f"Checking {r.choice(['/bin/ls','/usr/bin/ssh','/etc/passwd','network interfaces'])}... [ {r.choice(['OK','Warning','Not found'])} ]"
    if module == "simcity":
        return f"{r.choice(['Residential','Commercial','Industrial'])} demand {r.randint(-2000,2000)}; treasury ${r.randint(1000,999999)}"
    if module == "uv":
        return f"Resolved {r.randint(10,200)} packages in {r.randint(10,900)}ms"
    if module == "wpt":
        return f"Ran {r.randint(1,999)} tests finished in {r.uniform(0.1,30):.2f}s, {r.randint(0,7)} unexpected"
    return f"{module}: processing {r.choice(WORDS)} #{n}"


def run_modules(opts):
    modules = opts["modules"] or MODULES[:]
    target_modules = opts["exit_modules"] or (1 if opts["exit_time"] is not None else None)
    start = time.time()
    completed = 0
    idx = 0
    while True:
        module = modules[idx % len(modules)]
        lines = max(opts["instant"], 8 if target_modules else 1)
        for n in range(lines):
            print(line_for(module, n), flush=True)
            if opts["instant"] <= n:
                delay = max(0.0, 0.05 / max(opts["speed"], 0.01))
                if delay:
                    time.sleep(delay)
            if opts["exit_time"] is not None and time.time() - start >= opts["exit_time"]:
                return 0
        completed += 1
        if target_modules is not None and completed >= target_modules:
            return 0
        idx += 1


def main(argv):
    opts = parse(argv)
    return run_modules(opts)

if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
