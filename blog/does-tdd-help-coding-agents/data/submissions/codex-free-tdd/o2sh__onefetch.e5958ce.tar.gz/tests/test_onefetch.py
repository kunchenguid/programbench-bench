import json
import os
import shutil
import subprocess
import tempfile
import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
EXE = ROOT / "executable"


def run_cmd(args, cwd=None):
    return subprocess.run(
        [str(EXE), *args],
        cwd=cwd,
        text=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        check=False,
    )


def git(repo, *args, env=None):
    merged = os.environ.copy()
    if env:
        merged.update(env)
    subprocess.run(["git", *args], cwd=repo, env=merged, check=True, stdout=subprocess.PIPE)


class OnefetchTests(unittest.TestCase):
    def setUp(self):
        self.tmp = Path(tempfile.mkdtemp(prefix="onefetch-test-"))

    def tearDown(self):
        shutil.rmtree(self.tmp)

    def make_repo(self):
        repo = self.tmp / "repo"
        repo.mkdir()
        git(repo, "init", "-q")
        git(repo, "config", "user.name", "Alice")
        git(repo, "config", "user.email", "alice@example.com")
        (repo / "main.py").write_text('print("hi")\n', encoding="utf-8")
        (repo / "README.md").write_text("# Probe\n", encoding="utf-8")
        (repo / "LICENSE.md").write_text(
            "MIT License\n\nPermission is hereby granted, free of charge, to any person obtaining a copy\n",
            encoding="utf-8",
        )
        git(repo, "add", ".")
        git(
            repo,
            "commit",
            "-q",
            "-m",
            "init",
            env={
                "GIT_AUTHOR_DATE": "2024-01-01T00:00:00+0000",
                "GIT_COMMITTER_DATE": "2024-01-01T00:00:00+0000",
            },
        )
        (repo / "main.py").write_text('print("hi")\nprint("bye")\n', encoding="utf-8")
        git(
            repo,
            "commit",
            "-am",
            "update",
            "-q",
            env={
                "GIT_AUTHOR_NAME": "Bob",
                "GIT_AUTHOR_EMAIL": "bob@example.com",
                "GIT_AUTHOR_DATE": "2024-02-01T00:00:00+0000",
                "GIT_COMMITTER_DATE": "2024-02-01T00:00:00+0000",
            },
        )
        git(repo, "remote", "add", "origin", "git@github.com:user/repo.git")
        (repo / "untracked.txt").write_text("pending\n", encoding="utf-8")
        return repo

    def test_static_modes_match_documented_surface(self):
        self.assertEqual(run_cmd(["--version"]).stdout.strip(), "onefetch 2.25.0")
        help_text = run_cmd(["--help"]).stdout
        self.assertIn("Usage: executable [OPTIONS] [INPUT]", help_text)
        self.assertIn("--number-of-authors <NUM>", help_text)
        languages = run_cmd(["--languages"]).stdout.splitlines()
        self.assertIn("Python", languages)
        self.assertIn("Rust", languages)
        self.assertEqual(run_cmd(["--package-managers"]).stdout.splitlines(), ["Npm", "Cargo"])

    def test_json_repo_summary_contains_core_git_facts(self):
        repo = self.make_repo()
        result = run_cmd(["-o", "json", str(repo)])
        self.assertEqual(result.returncode, 0, result.stdout)
        data = json.loads(result.stdout)
        fields = {}
        for item in data["infoFields"]:
            fields.update(item)
        self.assertEqual(data["title"]["gitUsername"], "Alice")
        self.assertEqual(fields["ProjectInfo"]["repoName"], "repo")
        self.assertEqual(fields["PendingInfo"]["added"], 1)
        self.assertEqual(fields["CommitsInfo"]["numberOfCommits"], 2)
        self.assertEqual(fields["UrlInfo"]["repoUrl"], "git@github.com:user/repo.git")
        self.assertEqual(fields["LanguagesInfo"]["languagesWithPercentage"][0]["language"], "Python")
        self.assertEqual(fields["AuthorsInfo"]["authors"][0]["name"], "Alice")
        self.assertIsNone(fields["AuthorsInfo"]["authors"][0]["email"])
        self.assertEqual(fields["AuthorsInfo"]["authors"][1]["name"], "Bob")
        self.assertEqual(fields["LocInfo"]["linesOfCode"], 2)
        self.assertEqual(fields["LicenseInfo"]["license"], "MIT")

    def test_text_options_filter_fields_and_authors(self):
        repo = self.make_repo()
        out = run_cmd(
            [
                "--no-art",
                "--no-color-palette",
                "--no-bold",
                "--number-of-authors",
                "1",
                str(repo),
                "--disabled-fields",
                "commits",
            ]
        ).stdout
        self.assertIn("Project: repo", out)
        self.assertIn("Author: 50% Alice 1", out)
        self.assertIn("Contributors: 2", out)
        self.assertNotIn("Bob 1", out)
        self.assertNotIn("Commits:", out)
        self.assertEqual(out.count("Contributors:"), 1)

    def test_disabled_fields_consumes_invalid_path_like_reference(self):
        repo = self.make_repo()
        out = run_cmd(["--disabled-fields", "commits", str(repo)]).stdout
        self.assertIn("error: invalid value", out)
        self.assertIn("--disabled-fields <FIELD>", out)


if __name__ == "__main__":
    unittest.main()
