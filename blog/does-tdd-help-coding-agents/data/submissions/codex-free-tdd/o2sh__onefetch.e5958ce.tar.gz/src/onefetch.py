#!/usr/bin/env python3
import json
import os
import re
import subprocess
import sys
from collections import Counter, OrderedDict
from datetime import datetime, timezone
from pathlib import Path


VERSION = "onefetch 2.25.0"

LANGUAGES = [
    "ABNF", "ABAP", "Ada", "Agda", "Arduino C++", "Assembly", "ATS", "AutoHotKey", "BASH", "C",
    "CMake", "C#", "Ceylon", "Clojure", "CoffeeScript", "ColdFusion", "Coq", "C++", "Crystal",
    "CSS", "CUDA", "D", "Dart", "Dockerfile", "Emacs Lisp", "Elixir", "Elm", "Emojicode", "Erlang",
    "F#", "Fish", "Forth", "FORTRAN Legacy", "FORTRAN Modern", "GDScript", "GLSL", "Go", "GraphQL",
    "Groovy", "Haskell", "Haxe", "HCL", "HLSL", "HolyC", "HTML", "Idris", "Java", "JavaScript",
    "JSON", "Jsonnet", "JSX", "Julia", "Jupyter Notebooks", "Kotlin", "LLVM", "Lean", "Common Lisp",
    "Lua", "Makefile", "Markdown", "Modelica", "Nim", "Nix", "OCaml", "Objective-C", "Odin",
    "OpenSCAD", "Org", "Oz", "Pascal", "Perl", "PHP", "PowerShell", "Processing", "Prolog",
    "Protocol Buffers", "PureScript", "Python", "QML", "R", "Racket", "Raku", "Razor", "Ren'Py",
    "Ruby", "Rust", "Sass", "Scala", "Scheme", "Shell", "Solidity", "SQL", "Svelte", "SVG", "Swift",
    "SystemVerilog", "TCL", "TeX", "Plain Text", "TOML", "TSX", "TypeScript", "Typst", "Vala",
    "Verilog", "VHDL", "Vim Script", "Visual Basic", "Vue", "WebAssembly", "Wolfram", "XSL", "XAML",
    "XML", "YAML", "Zig", "Zsh",
]

EXT_LANG = {
    ".py": ("Python", "programming"),
    ".rs": ("Rust", "programming"),
    ".c": ("C", "programming"),
    ".h": ("C", "programming"),
    ".cpp": ("C++", "programming"),
    ".cc": ("C++", "programming"),
    ".cxx": ("C++", "programming"),
    ".hpp": ("C++", "programming"),
    ".go": ("Go", "programming"),
    ".js": ("JavaScript", "programming"),
    ".jsx": ("JSX", "programming"),
    ".ts": ("TypeScript", "programming"),
    ".tsx": ("TSX", "programming"),
    ".java": ("Java", "programming"),
    ".rb": ("Ruby", "programming"),
    ".php": ("PHP", "programming"),
    ".swift": ("Swift", "programming"),
    ".kt": ("Kotlin", "programming"),
    ".sh": ("Shell", "programming"),
    ".bash": ("BASH", "programming"),
    ".zsh": ("Zsh", "programming"),
    ".fish": ("Fish", "programming"),
    ".html": ("HTML", "markup"),
    ".htm": ("HTML", "markup"),
    ".css": ("CSS", "markup"),
    ".scss": ("Sass", "markup"),
    ".sass": ("Sass", "markup"),
    ".md": ("Markdown", "prose"),
    ".xml": ("XML", "markup"),
    ".svg": ("SVG", "markup"),
    ".yml": ("YAML", "data"),
    ".yaml": ("YAML", "data"),
    ".json": ("JSON", "data"),
    ".toml": ("TOML", "data"),
    ".sql": ("SQL", "data"),
    ".txt": ("Plain Text", "prose"),
}

FIELD_ORDER = [
    "project", "description", "head", "pending", "version", "created", "languages", "dependencies",
    "authors", "last-change", "contributors", "url", "commits", "churn", "lines-of-code", "size", "license",
]


class Options:
    def __init__(self):
        self.path = "."
        self.output = None
        self.disabled = set()
        self.no_title = False
        self.no_art = False
        self.no_color_palette = False
        self.email = False
        self.iso_time = False
        self.http_url = False
        self.hide_token = False
        self.include_hidden = False
        self.no_merges = False
        self.number_of_authors = 3
        self.number_of_languages = 6
        self.number_of_file_churns = 3
        self.churn_pool_size = None
        self.number_separator = "plain"
        self.types = {"programming", "markup"}
        self.excludes = []


def run(args, cwd):
    try:
        return subprocess.check_output(args, cwd=cwd, stderr=subprocess.DEVNULL, text=True).strip()
    except subprocess.CalledProcessError:
        return ""


def usage(long=False):
    if not long:
        return """Command-line Git information tool

Usage: executable [OPTIONS] [INPUT]

Arguments:
  [INPUT]  Run as if onefetch was started in <input> instead of the current working directory

Options:
  -h, --help     Print help (see more with '--help')
  -V, --version  Print version

INFO:
  -d, --disabled-fields <FIELD>...   Allows you to disable FIELD(s) from appearing in the output
      --no-title                     Hides the title
      --number-of-authors <NUM>      Maximum NUM of authors to be shown [default: 3]
      --number-of-languages <NUM>    Maximum NUM of languages to be shown [default: 6]
      --number-of-file-churns <NUM>  Maximum NUM of file churns to be shown [default: 3]
      --churn-pool-size <NUM>        Minimum NUM of commits from HEAD used to compute the churn
                                     summary
  -e, --exclude <EXCLUDE>...         Ignore all files & directories matching EXCLUDE
      --no-bots[=<REGEX>]            Exclude [bot] commits. Use <REGEX> to override the default
                                     pattern
      --no-merges                    Ignores merge commits
  -E, --email                        Show the email address of each author
      --http-url                     Display repository URL as HTTP
      --hide-token                   Hide token in repository URL
      --include-hidden               Count hidden files and directories
  -T, --type <TYPE>...               Filters output by language type [default: programming markup]
                                     [possible values: programming, markup, prose, data]

TEXT FORMATTING:
  -t, --text-colors <X>...            Changes the text colors (X X X...)
  -z, --iso-time                      Use ISO 8601 formatted timestamps
      --number-separator <SEPARATOR>  Which thousands SEPARATOR to use [default: plain] [possible
                                      values: plain, comma, space, underscore]
      --no-bold                       Turns off bold formatting

ASCII:
      --ascii-input <STRING>       Takes a non-empty STRING as input to replace the ASCII logo
  -c, --ascii-colors <X>...        Colors (X X X...) to print the ascii art
  -a, --ascii-language <LANGUAGE>  Which LANGUAGE's ascii art to print
      --true-color <WHEN>          Specify when to use true color [default: auto] [possible values:
                                   auto, never, always]

IMAGE:
  -i, --image <IMAGE>              Path to the IMAGE file
      --image-protocol <PROTOCOL>  Which image PROTOCOL to use [possible values: kitty, sixel,
                                   iterm]
      --color-resolution <VALUE>   VALUE of color resolution to use with SIXEL backend [default: 64]
                                   [possible values: 16, 32, 64, 128, 256]

VISUALS:
      --no-color-palette  Hides the color palette
      --no-art            Hides the ascii art or image if provided
      --nerd-fonts        Use Nerd Font icons

DEVELOPER:
  -o, --output <FORMAT>   Outputs Onefetch in a specific format [possible values: json, yaml]
      --generate <SHELL>  If provided, outputs the completion file for given SHELL [possible values:
                          bash, elvish, fish, powershell, zsh]

OTHER:
  -l, --languages         Prints out supported languages
  -p, --package-managers  Prints out supported package managers
"""
    return """Command-line Git information tool

Usage: executable [OPTIONS] [INPUT]

Arguments:
  [INPUT]
          Run as if onefetch was started in <input> instead of the current working directory

Options:
  -h, --help
          Print help (see a summary with '-h')

  -V, --version
          Print version
"""


def parse(argv):
    opt = Options()
    i = 0
    while i < len(argv):
        a = argv[i]
        if a in ("-h", "--help"):
            print(usage(a == "-h"), end="")
            raise SystemExit(0)
        if a in ("-V", "--version"):
            print(VERSION)
            raise SystemExit(0)
        if a in ("-l", "--languages"):
            print("\n".join(LANGUAGES))
            raise SystemExit(0)
        if a in ("-p", "--package-managers"):
            print("Npm\nCargo")
            raise SystemExit(0)
        if a == "--generate":
            shell = argv[i + 1] if i + 1 < len(argv) else ""
            print_completion(shell)
            raise SystemExit(0)
        if a in ("-o", "--output"):
            i += 1
            if i >= len(argv) or argv[i] not in ("json", "yaml"):
                print(f"error: invalid value '{argv[i] if i < len(argv) else ''}' for '--output <FORMAT>'\n  [possible values: json, yaml]\n\nFor more information, try '--help'.")
                raise SystemExit(0)
            opt.output = argv[i]
        elif a in ("-d", "--disabled-fields"):
            i += 1
            while i < len(argv) and not argv[i].startswith("-"):
                if argv[i] not in FIELD_ORDER:
                    print(
                        f"error: invalid value '{argv[i]}' for '--disabled-fields <FIELD>...'\n"
                        "  [possible values: project, description, head, pending, version, created, languages, dependencies, authors, last-change, contributors, url, commits, churn, lines-of-code, size, license]\n\n"
                        "For more information, try '--help'."
                    )
                    raise SystemExit(0)
                opt.disabled.add(argv[i])
                i += 1
            i -= 1
        elif a in ("-e", "--exclude"):
            i += 1
            while i < len(argv) and not argv[i].startswith("-"):
                opt.excludes.append(argv[i])
                i += 1
            i -= 1
        elif a in ("-T", "--type"):
            opt.types = set()
            i += 1
            while i < len(argv) and not argv[i].startswith("-"):
                opt.types.add(argv[i])
                i += 1
            i -= 1
        elif a == "--number-of-authors":
            i += 1
            opt.number_of_authors = int_or_error(argv[i], "--number-of-authors <NUM>")
        elif a == "--number-of-languages":
            i += 1
            opt.number_of_languages = int_or_error(argv[i], "--number-of-languages <NUM>")
        elif a == "--number-of-file-churns":
            i += 1
            opt.number_of_file_churns = int_or_error(argv[i], "--number-of-file-churns <NUM>")
        elif a == "--churn-pool-size":
            i += 1
            opt.churn_pool_size = int_or_error(argv[i], "--churn-pool-size <NUM>")
        elif a == "--number-separator":
            i += 1
            opt.number_separator = argv[i]
        elif a in ("-E", "--email"):
            opt.email = True
        elif a in ("-z", "--iso-time"):
            opt.iso_time = True
        elif a == "--no-title":
            opt.no_title = True
        elif a == "--no-art":
            opt.no_art = True
        elif a == "--no-color-palette":
            opt.no_color_palette = True
        elif a == "--include-hidden":
            opt.include_hidden = True
        elif a == "--no-merges":
            opt.no_merges = True
        elif a == "--http-url":
            opt.http_url = True
        elif a == "--hide-token":
            opt.hide_token = True
        elif a in ("--no-bold", "--nerd-fonts") or a.startswith("--no-bots"):
            pass
        elif a in ("--ascii-input", "-a", "--ascii-language", "-i", "--image", "--image-protocol", "--color-resolution"):
            i += 1
        elif a in ("-c", "--ascii-colors", "-t", "--text-colors"):
            i += 1
            while i < len(argv) and not argv[i].startswith("-"):
                i += 1
            i -= 1
        elif a.startswith("-"):
            print(f"error: unexpected argument '{a}' found\n\nUsage: executable [OPTIONS] [INPUT]\n\nFor more information, try '--help'.")
            raise SystemExit(0)
        else:
            opt.path = a
        i += 1
    return opt


def int_or_error(value, name):
    try:
        return int(value)
    except Exception:
        print(f"error: invalid value '{value}' for '{name}': invalid digit found in string\n\nFor more information, try '--help'.")
        raise SystemExit(0)


def print_completion(shell):
    if shell == "fish":
        print("complete -c onefetch -s d -l disabled-fields -d 'Allows you to disable FIELD(s) from appearing in the output'")
    elif shell == "zsh":
        print("#compdef onefetch\n\n_onefetch() {\n    _arguments '*:: :_files'\n}")
    elif shell == "powershell":
        print("using namespace System.Management.Automation\nRegister-ArgumentCompleter -Native -CommandName 'onefetch' -ScriptBlock {}")
    elif shell == "elvish":
        print("edit:completion:arg completer[onefetch] = {|@words| }")
    else:
        print("_onefetch() {\n    local opts\n    opts=\"-d -e -E -T -t -z -c -a -i -o -l -p -h -V --disabled-fields --no-title --number-of-authors --number-of-languages --number-of-file-churns --churn-pool-size --exclude --no-bots --no-merges --email --http-url --hide-token --include-hidden --type --text-colors --iso-time --number-separator --no-bold --ascii-input --ascii-colors --ascii-language --true-color --image --image-protocol --color-resolution --no-color-palette --no-art --nerd-fonts --output --generate --languages --package-managers --help --version [INPUT]\"\n}\n")


def git_lines(repo, *args):
    out = run(["git", *args], repo)
    return out.splitlines() if out else []


def repo_root(path):
    root = run(["git", "-C", str(path), "rev-parse", "--show-toplevel"], path)
    return Path(root) if root else Path(path)


def tracked_files(repo):
    return git_lines(repo, "ls-files")


def hidden(path):
    return any(part.startswith(".") for part in Path(path).parts)


def excluded(path, patterns):
    return any(p and (p in path or Path(path).match(p)) for p in patterns)


def file_list(repo, opt):
    files = []
    for f in tracked_files(repo):
        if not opt.include_hidden and hidden(f):
            continue
        if excluded(f, opt.excludes):
            continue
        p = repo / f
        if p.is_file():
            files.append(f)
    return files


def language_for(name):
    base = Path(name).name
    if base == "Dockerfile":
        return ("Dockerfile", "programming")
    if base == "Makefile":
        return ("Makefile", "programming")
    return EXT_LANG.get(Path(name).suffix.lower())


def lines_for(path):
    try:
        data = path.read_text(encoding="utf-8", errors="ignore")
    except Exception:
        return 0
    return sum(1 for line in data.splitlines() if line.strip())


def fmt_size(n):
    units = ["B", "KiB", "MiB", "GiB"]
    value = float(n)
    unit = units[0]
    for unit in units:
        if value < 1024 or unit == units[-1]:
            break
        value /= 1024
    if unit == "B":
        return f"{int(value)} B"
    return f"{value:.2f} {unit}"


def fmt_num(n, sep):
    s = str(n)
    if sep == "comma":
        return f"{n:,}"
    if sep == "space":
        return f"{n:,}".replace(",", " ")
    if sep == "underscore":
        return f"{n:,}".replace(",", "_")
    return s


def parse_git_date(s):
    try:
        return datetime.strptime(s, "%Y-%m-%dT%H:%M:%S%z")
    except Exception:
        return None


def rel_time(dt, iso=False):
    if not dt:
        return ""
    if iso:
        return dt.astimezone(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
    now = datetime.now(timezone.utc)
    days = max(0, (now - dt.astimezone(timezone.utc)).days)
    if days < 1:
        return "today"
    if days < 30:
        return "a day ago" if days == 1 else f"{days} days ago"
    months = days // 30
    if months < 12:
        return "a month ago" if months == 1 else f"{months} months ago"
    years = days // 365
    return "a year ago" if years == 1 else f"{years} years ago"


def origin_url(repo, opt):
    url = run(["git", "config", "--get", "remote.origin.url"], repo)
    if opt.http_url and url.startswith("git@github.com:"):
        url = "https://github.com/" + url.split(":", 1)[1]
    if opt.hide_token:
        url = re.sub(r"https://[^/@]+@", "https://", url)
    return url


def repo_name_from_url(url):
    if not url:
        return ""
    name = url.rstrip("/").rsplit("/", 1)[-1]
    if ":" in name:
        name = name.rsplit(":", 1)[-1]
    return name[:-4] if name.endswith(".git") else name


def license_name(repo):
    for f in ["LICENSE", "LICENSE.md", "COPYING", "COPYING.md"]:
        p = repo / f
        if p.exists():
            text = p.read_text(encoding="utf-8", errors="ignore").lower()
            if "permission is hereby granted" in text and "mit" in text:
                return "MIT"
            if "apache license" in text:
                return "Apache-2.0"
            if "gnu general public license" in text:
                return "GPL"
    return ""


def collect(opt):
    path = Path(opt.path)
    if not path.is_dir():
        print(f"Error: Failed to access a directory, or path is not a directory: '{opt.path}'")
        raise SystemExit(0)
    repo = repo_root(path)
    files = file_list(repo, opt)
    git_version = run(["git", "--version"], repo)
    username = run(["git", "config", "user.name"], repo)
    url = origin_url(repo, opt)
    commits = git_lines(repo, "rev-list", "--count", "HEAD")
    commit_count = int(commits[0]) if commits and commits[0].isdigit() else 0
    head = run(["git", "rev-parse", "--short", "HEAD"], repo)
    branch = run(["git", "branch", "--show-current"], repo)
    first_date = parse_git_date(run(["git", "log", "--reverse", "--format=%cI", "-n", "1"], repo))
    last_date = parse_git_date(run(["git", "log", "--format=%cI", "-n", "1"], repo))
    status = git_lines(repo, "status", "--porcelain")
    pending = {"added": 0, "deleted": 0, "modified": 0}
    for line in status:
        code = line[:2]
        if code == "??" or code[0] == "A":
            pending["added"] += 1
        elif "D" in code:
            pending["deleted"] += 1
        elif code.strip():
            pending["modified"] += 1
    author_lines = git_lines(repo, "shortlog", "-sne", "HEAD")
    authors = []
    total_author_commits = 0
    for line in author_lines:
        m = re.match(r"\s*(\d+)\s+(.+?)(?:\s+<([^>]+)>)?$", line)
        if not m:
            continue
        cnt = int(m.group(1))
        total_author_commits += cnt
        authors.append({"name": m.group(2), "email": m.group(3) if opt.email else None, "nbrOfCommits": cnt})
    authors.sort(key=lambda a: (-a["nbrOfCommits"], a["name"].lower()))
    for a in authors:
        a["contribution"] = int(round((a["nbrOfCommits"] / total_author_commits) * 100)) if total_author_commits else 0
    lang_counts = Counter()
    loc = 0
    size = 0
    for f in files:
        p = repo / f
        try:
            size += p.stat().st_size
        except OSError:
            pass
        lang = language_for(f)
        if lang and lang[1] in opt.types:
            n = lines_for(p)
            lang_counts[lang[0]] += n
            loc += n
    languages = []
    total_lang = sum(lang_counts.values())
    if total_lang:
        for lang, count in lang_counts.most_common(opt.number_of_languages):
            languages.append({"language": lang, "percentage": round(count * 100.0 / total_lang, 1)})
    churn = []
    if commit_count:
        n = opt.churn_pool_size or 1
        for line in git_lines(repo, "log", f"-n{n}", "--name-only", "--pretty=format:"):
            if line.strip():
                churn.append(line.strip())
    churns = [{"filePath": f, "nbrOfCommits": c} for f, c in Counter(churn).most_common(opt.number_of_file_churns)]
    return {
        "repo": repo,
        "title": {"gitUsername": username, "gitVersion": git_version},
        "project": {"repoName": repo_name_from_url(url), "numberOfBranches": 0, "numberOfTags": 0},
        "description": {"description": None},
        "head": {"headRefs": {"shortCommitId": head, "refs": [branch] if branch else []}},
        "pending": pending,
        "version": {"version": ""},
        "created": {"creationDate": rel_time(first_date, opt.iso_time)},
        "languages": {"languagesWithPercentage": languages},
        "dependencies": {"dependencies": ""},
        "authors": {"authors": authors},
        "last-change": {"lastChange": rel_time(last_date, opt.iso_time)},
        "contributors": {"totalNumberOfAuthors": len(authors)},
        "url": {"repoUrl": url},
        "commits": {"numberOfCommits": commit_count, "isShallow": False},
        "churn": {"file_churns": churns, "churn_pool_size": opt.churn_pool_size or min(commit_count, 1)},
        "lines-of-code": {"linesOfCode": loc},
        "size": {"repoSize": fmt_size(size), "fileCount": len(files)},
        "license": {"license": license_name(repo)},
    }


JSON_KEYS = {
    "project": "ProjectInfo", "description": "DescriptionInfo", "head": "HeadInfo", "pending": "PendingInfo",
    "version": "VersionInfo", "created": "CreatedInfo", "languages": "LanguagesInfo", "dependencies": "DependenciesInfo",
    "authors": "AuthorsInfo", "last-change": "LastChangeInfo", "contributors": "ContributorsInfo", "url": "UrlInfo",
    "commits": "CommitsInfo", "churn": "ChurnInfo", "lines-of-code": "LocInfo", "size": "SizeInfo", "license": "LicenseInfo",
}


def as_json(data, opt):
    fields = []
    for f in FIELD_ORDER:
        if f in opt.disabled:
            continue
        if f == "languages" and not data[f]["languagesWithPercentage"]:
            continue
        if f == "lines-of-code" and data[f]["linesOfCode"] == 0:
            continue
        fields.append({JSON_KEYS[f]: data[f]})
    return {"title": data["title"], "infoFields": fields}


def yaml_scalar(v):
    if v is None:
        return "null"
    if v == "":
        return "''"
    if isinstance(v, bool):
        return "true" if v else "false"
    return str(v)


def dump_yaml(obj, indent=0):
    pad = " " * indent
    lines = []
    if isinstance(obj, dict):
        for k, v in obj.items():
            if isinstance(v, (dict, list)):
                lines.append(f"{pad}{k}:")
                lines.extend(dump_yaml(v, indent + 2))
            else:
                lines.append(f"{pad}{k}: {yaml_scalar(v)}")
    elif isinstance(obj, list):
        for item in obj:
            if isinstance(item, dict) and len(item) == 1:
                k, v = next(iter(item.items()))
                lines.append(f"{pad}- {k}:")
                lines.extend(dump_yaml(v, indent + 4))
            elif isinstance(item, dict):
                first = True
                for k, v in item.items():
                    prefix = "- " if first else "  "
                    if isinstance(v, (dict, list)):
                        lines.append(f"{pad}{prefix}{k}:")
                        lines.extend(dump_yaml(v, indent + 4))
                    else:
                        lines.append(f"{pad}{prefix}{k}: {yaml_scalar(v)}")
                    first = False
            else:
                lines.append(f"{pad}- {yaml_scalar(item)}")
    return lines


def label(k, authors_count=0):
    return {
        "project": "Project", "head": "HEAD", "pending": "Pending", "created": "Created",
        "languages": "Language", "authors": "Author" if authors_count <= 1 else "Authors",
        "last-change": "Last change", "contributors": "Contributors", "url": "URL",
        "commits": "Commits", "churn": "Churn", "lines-of-code": "Lines of code",
        "size": "Size", "license": "License", "version": "Version", "description": "Description",
        "dependencies": "Dependencies",
    }.get(k, k)


def render_text(data, opt):
    lines = []
    authors = data["authors"]["authors"]
    if not opt.no_title:
        title = f"{data['title']['gitUsername']} ~ {data['title']['gitVersion']}".strip()
        lines.append(title)
        lines.append("-" * max(10, len(title)))
    for f in FIELD_ORDER:
        if f in opt.disabled:
            continue
        if f in ("description", "version", "dependencies"):
            val = next(iter(data[f].values()))
            if not val:
                continue
        if f == "project":
            val = data[f]["repoName"]
            if not val:
                continue
        elif f == "head":
            refs = data[f]["headRefs"]["refs"]
            val = data[f]["headRefs"]["shortCommitId"] + (f" ({', '.join(refs)})" if refs else "")
        elif f == "pending":
            p = data[f]
            parts = []
            if p["added"]:
                parts.append(f"{p['added']}+")
            if p["deleted"]:
                parts.append(f"{p['deleted']}-")
            if p["modified"]:
                parts.append(f"{p['modified']}~")
            val = " ".join(parts) or "None"
        elif f == "languages":
            langs = data[f]["languagesWithPercentage"]
            if not langs:
                continue
            val = ", ".join(f"{x['language']} ({x['percentage']:.1f} %)" for x in langs)
        elif f == "authors":
            if not authors:
                continue
            shown = authors[: opt.number_of_authors]
            first = True
            for a in shown:
                name = a["name"] + (f" <{a['email']}>" if opt.email and a.get("email") else "")
                text = f"{a['contribution']}% {name} {fmt_num(a['nbrOfCommits'], opt.number_separator)}"
                lines.append(f"{label(f, len(shown))}: {text}" if first else f"{' ' * (len(label(f, len(shown))) + 2)}{text}")
                first = False
            continue
        elif f == "contributors":
            if len(authors) <= opt.number_of_authors:
                continue
            val = fmt_num(data[f]["totalNumberOfAuthors"], opt.number_separator)
        elif f == "commits":
            val = fmt_num(data[f]["numberOfCommits"], opt.number_separator)
        elif f == "churn":
            churns = data[f]["file_churns"]
            if not churns:
                continue
            val = ", ".join(f"{x['filePath']} {fmt_num(x['nbrOfCommits'], opt.number_separator)}" for x in churns)
            lines.append(f"Churn ({data[f]['churn_pool_size']}): {val}")
            continue
        elif f == "lines-of-code":
            if data[f]["linesOfCode"] == 0:
                continue
            val = fmt_num(data[f]["linesOfCode"], opt.number_separator)
        elif f == "size":
            val = f"{data[f]['repoSize']} ({fmt_num(data[f]['fileCount'], opt.number_separator)} files)"
        elif f == "license":
            val = data[f]["license"]
            if not val:
                continue
        else:
            val = next(iter(data[f].values()))
            if val is None or val == "":
                continue
        lines.append(f"{label(f, len(authors))}: {val}")
    return "\n".join(lines) + "\n"


def main(argv):
    opt = parse(argv)
    data = collect(opt)
    if opt.output == "json":
        print(json.dumps(as_json(data, opt), indent=2))
    elif opt.output == "yaml":
        print("\n".join(dump_yaml(as_json(data, opt))))
    else:
        print(render_text(data, opt), end="")


if __name__ == "__main__":
    main(sys.argv[1:])
