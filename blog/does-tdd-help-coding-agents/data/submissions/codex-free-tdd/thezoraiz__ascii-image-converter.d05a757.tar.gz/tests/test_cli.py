#!/usr/bin/env python3
import os
import shutil
import struct
import subprocess
import tempfile
import zlib


ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
EXE = os.path.join(ROOT, "executable")


def make_png(path, width, height, rows):
    def chunk(kind, data):
        return (
            struct.pack(">I", len(data))
            + kind
            + data
            + struct.pack(">I", zlib.crc32(kind + data) & 0xFFFFFFFF)
        )

    raw = b"".join(b"\x00" + bytes(c for px in row for c in px) for row in rows)
    data = (
        b"\x89PNG\r\n\x1a\n"
        + chunk(b"IHDR", struct.pack(">IIBBBBB", width, height, 8, 2, 0, 0, 0))
        + chunk(b"IDAT", zlib.compress(raw))
        + chunk(b"IEND", b"")
    )
    with open(path, "wb") as f:
        f.write(data)


def run(args, cwd=None):
    return subprocess.run(
        [EXE] + args,
        cwd=cwd,
        text=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        check=False,
    )


def with_images():
    tmp = tempfile.mkdtemp()
    make_png(
        os.path.join(tmp, "gray4.png"),
        4,
        1,
        [[(0, 0, 0), (85, 85, 85), (170, 170, 170), (255, 255, 255)]],
    )
    make_png(
        os.path.join(tmp, "grid4x2.png"),
        4,
        2,
        [
            [(0, 0, 0), (85, 85, 85), (170, 170, 170), (255, 255, 255)],
            [(255, 0, 0), (0, 255, 0), (0, 0, 255), (255, 255, 255)],
        ],
    )
    return tmp


def test_version_and_formats():
    assert run(["--version"]).stdout == "v1.13.1\n"
    assert "PNG" in run(["--formats"]).stdout
    assert "JPEG/JPG" in run(["--formats"]).stdout


def test_fixed_dimensions_default_map_and_custom_map():
    tmp = with_images()
    try:
        assert run(["-d", "4,1", os.path.join(tmp, "gray4.png")]).stdout == " -*@\n"
        assert run(["-d", "4,1", "-m", "@#-.", os.path.join(tmp, "gray4.png")]).stdout == "@#-.\n"
        assert run(["-d", "4,1", "-n", os.path.join(tmp, "gray4.png")]).stdout == "@*- \n"
    finally:
        shutil.rmtree(tmp)


def test_flips_and_height_scaling():
    tmp = with_images()
    try:
        img = os.path.join(tmp, "grid4x2.png")
        assert run(["-d", "4,2", img]).stdout == " -*@\n:+.@\n"
        assert run(["-d", "4,2", "-x", img]).stdout == "@*- \n@.+:\n"
        assert run(["-d", "4,2", "-y", img]).stdout == ":+.@\n -*@\n"
        assert run(["-W", "4", img]).stdout == ".=-@\n"
    finally:
        shutil.rmtree(tmp)


def test_save_txt_and_only_save_message():
    tmp = with_images()
    try:
        img = os.path.join(tmp, "gray4.png")
        assert run(["--save-txt", ".", "-d", "4,1", img], cwd=tmp).stdout == " -*@\n"
        assert open(os.path.join(tmp, "gray4-ascii-art.txt")).read() == " -*@"
        os.unlink(os.path.join(tmp, "gray4-ascii-art.txt"))
        assert run(["--only-save", "--save-txt", ".", "-d", "4,1", img], cwd=tmp).stdout == "Saved ./gray4-ascii-art.txt\n"
        assert open(os.path.join(tmp, "gray4-ascii-art.txt")).read() == " -*@"
    finally:
        shutil.rmtree(tmp)


def test_save_img_creates_png_artifact():
    tmp = with_images()
    try:
        img = os.path.join(tmp, "gray4.png")
        result = run(["--only-save", "--save-img", ".", "-d", "4,1", img], cwd=tmp)
        assert result.returncode == 0
        assert result.stdout == "Saved ./gray4-ascii-art.png\n"
        data = open(os.path.join(tmp, "gray4-ascii-art.png"), "rb").read(8)
        assert data == b"\x89PNG\r\n\x1a\n"
    finally:
        shutil.rmtree(tmp)


def test_errors_match_statuses():
    no_input = run([])
    assert no_input.returncode == 0
    assert no_input.stdout == "Error: Need at least 1 input path/url or piped input\nUse the -h flag for more info\n"

    missing = run(["missing.png"])
    assert missing.returncode == 0
    assert missing.stdout.startswith("Error: unable to open file: open missing.png: no such file or directory\n")

    bad = run(["--badflag"])
    assert bad.returncode == 1
    assert "unknown flag: --badflag" in bad.stdout


if __name__ == "__main__":
    tests = [
        test_version_and_formats,
        test_fixed_dimensions_default_map_and_custom_map,
        test_flips_and_height_scaling,
        test_save_txt_and_only_save_message,
        test_save_img_creates_png_artifact,
        test_errors_match_statuses,
    ]
    for test in tests:
        test()
        print(f"ok {test.__name__}")
