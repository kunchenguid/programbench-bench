module ascii-clone

go 1.20
