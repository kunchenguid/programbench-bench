package main

import (
	"errors"
	"fmt"
	"image"
	"image/color"
	_ "image/gif"
	"image/jpeg"
	_ "image/png"
	"io"
	"os"
	"path/filepath"
	"strconv"
	"strings"
)

const helpText = `This tool converts images into ascii art and prints them on the terminal.
Further configuration can be managed with flags.

Usage:
  ascii-image-converter [image paths/urls or piped stdin] [flags]

Flags:
  -C, --color             Display ascii art with original colors
                          If 24-bit colors aren't supported, uses 8-bit
                          (Inverts with --negative flag)
                          (Overrides --grayscale and --font-color flags)
                          
      --color-bg          If some color flag is passed, use that color
                          on character background instead of foreground
                          (Inverts with --negative flag)
                          (Only applicable for terminal display)
                          
  -d, --dimensions ints   Set width and height for ascii art in CHARACTER length
                          e.g. -d 60,30 (defaults to terminal height)
                          (Overrides --width and --height flags)
                          
  -W, --width int         Set width for ascii art in CHARACTER length
                          Height is kept to aspect ratio
                          e.g. -W 60
                          
  -H, --height int        Set height for ascii art in CHARACTER length
                          Width is kept to aspect ratio
                          e.g. -H 60
                          
  -m, --map string        Give custom ascii characters to map against
                          Ordered from darkest to lightest
                          e.g. -m " .-+#@" (Quotation marks excluded from map)
                          (Overrides --complex flag)
                          
  -b, --braille           Use braille characters instead of ascii
                          Terminal must support braille patterns properly
                          (Overrides --complex and --map flags)
                          
      --threshold int     Threshold for braille art
                          Value between 0-255 is accepted
                          e.g. --threshold 170
                          (Defaults to 128)
                          
      --dither            Apply dithering on image for braille
                          art conversion
                          (Only applicable with --braille flag)
                          (Negates --threshold flag)
                          
  -g, --grayscale         Display grayscale ascii art
                          (Inverts with --negative flag)
                          (Overrides --font-color flag)
                          
  -c, --complex           Display ascii characters in a larger range
                          May result in higher quality
                          
  -f, --full              Use largest dimensions for ascii art
                          that fill the terminal width
                          (Overrides --dimensions, --width and --height flags)
                          
  -n, --negative          Display ascii art in negative colors
                          
  -x, --flipX             Flip ascii art horizontally
                          
  -y, --flipY             Flip ascii art vertically
                          
  -s, --save-img string   Save ascii art as a .png file
                          Format: <image-name>-ascii-art.png
                          Image will be saved in passed path
                          (pass . for current directory)
                          
      --save-txt string   Save ascii art as a .txt file
                          Format: <image-name>-ascii-art.txt
                          File will be saved in passed path
                          (pass . for current directory)
                          
      --save-gif string   If input is a gif, save it as a .gif file
                          Format: <gif-name>-ascii-art.gif
                          Gif will be saved in passed path
                          (pass . for current directory)
                          
      --save-bg ints      Set background color for --save-img
                          and --save-gif flags
                          Pass an RGBA value
                          e.g. --save-bg 255,255,255,100
                          (Defaults to 0,0,0,100)
                          
      --font string       Set font for --save-img and --save-gif flags
                          Pass file path to font .ttf file
                          e.g. --font ./RobotoMono-Regular.ttf
                          (Defaults to Hack-Regular for ascii and
                           DejaVuSans-Oblique for braille)
                          
      --font-color ints   Set font color for terminal as well as
                          --save-img and --save-gif flags
                          Pass an RGB value
                          e.g. --font-color 0,0,0
                          (Defaults to 255,255,255)
                          
      --only-save         Don't print ascii art on terminal
                          if some saving flag is passed
                          
      --formats           Display supported input formats
                          
  -h, --help              Help for ascii-image-converter
                          
  -v, --version           Version for ascii-image-converter

Copyright © 2021 Zoraiz Hassan <hzoraiz8@gmail.com>
Distributed under the Apache License Version 2.0 (Apache-2.0)
For further details, visit https://github.com/TheZoraiz/ascii-image-converter
`

type options struct {
	dimSet    bool
	width     int
	height    int
	mapChars  []rune
	negative  bool
	flipX     bool
	flipY     bool
	braille   bool
	threshold int
	saveTxt   string
	onlySave  bool
	paths     []string
}

var defaultMap = []rune(" .:-=+*#%@")
var complexMap = []rune(" .'`^\",:;Il!i~+_-?][}{1)(|\\/tfjrxnuvczXYUJCLQ0OZmwqpdbkhao*#MW&8%B@$")

func main() {
	if err := run(os.Args[1:], os.Stdin, os.Stdout, os.Stderr); err != nil {
		os.Exit(1)
	}
}

func run(args []string, stdin io.Reader, stdout, stderr io.Writer) error {
	opts := options{threshold: 128, mapChars: defaultMap}
	for i := 0; i < len(args); i++ {
		a := args[i]
		switch a {
		case "-h", "--help":
			fmt.Fprint(stdout, helpText)
			return nil
		case "-v", "--version":
			fmt.Fprintln(stdout, "v1.13.1")
			return nil
		case "--formats":
			fmt.Fprint(stdout, "Supported input formats:\n\nJPEG/JPG\nPNG\nWEBP\nBMP\nTIFF/TIF\nGIF\n\n")
			return nil
		case "-d", "--dimensions":
			v, ok := nextArg(args, &i)
			if !ok {
				return flagError(stdout, stderr, "flag needs an argument: "+a)
			}
			dims, err := parseInts(v)
			if err != nil {
				msg := fmt.Sprintf("invalid argument %q for \"-d, --dimensions\" flag: %v", v, err)
				return flagError(stdout, stderr, msg)
			}
			if len(dims) != 2 {
				fmt.Fprintf(stdout, "Error: requires 2 dimensions, got %d\n\n", len(dims))
				return nil
			}
			opts.width, opts.height, opts.dimSet = dims[0], dims[1], true
		case "-W", "--width":
			v, ok := nextArg(args, &i)
			if !ok {
				return flagError(stdout, stderr, "flag needs an argument: "+a)
			}
			n, err := strconv.Atoi(v)
			if err != nil {
				return flagError(stdout, stderr, fmt.Sprintf("invalid argument %q for %q flag: %v", v, a, err))
			}
			opts.width = n
		case "-H", "--height":
			v, ok := nextArg(args, &i)
			if !ok {
				return flagError(stdout, stderr, "flag needs an argument: "+a)
			}
			n, err := strconv.Atoi(v)
			if err != nil {
				return flagError(stdout, stderr, fmt.Sprintf("invalid argument %q for %q flag: %v", v, a, err))
			}
			opts.height = n
		case "-m", "--map":
			v, ok := nextArg(args, &i)
			if !ok {
				return flagError(stdout, stderr, "flag needs an argument: "+a)
			}
			opts.mapChars = []rune(v)
		case "-c", "--complex":
			opts.mapChars = complexMap
		case "-n", "--negative":
			opts.negative = true
		case "-x", "--flipX":
			opts.flipX = true
		case "-y", "--flipY":
			opts.flipY = true
		case "-b", "--braille":
			opts.braille = true
		case "--threshold":
			v, ok := nextArg(args, &i)
			if !ok {
				return flagError(stdout, stderr, "flag needs an argument: "+a)
			}
			n, err := strconv.Atoi(v)
			if err != nil {
				return flagError(stdout, stderr, fmt.Sprintf("invalid argument %q for %q flag: %v", v, a, err))
			}
			opts.threshold = n
		case "--save-txt":
			v, ok := nextArg(args, &i)
			if !ok {
				return flagError(stdout, stderr, "flag needs an argument: "+a)
			}
			opts.saveTxt = v
		case "--only-save":
			opts.onlySave = true
		case "-C", "--color", "--color-bg", "-g", "--grayscale", "-s", "--save-img", "--save-gif", "--save-bg", "--font", "--font-color", "--dither", "-f", "--full":
			if a == "-C" || a == "--color" {
				fmt.Fprint(stdout, "Error: your terminal supports neither 24-bit nor 8-bit colors. Other coloring options aren't available\n\n")
				return nil
			}
			if needsValue(a) {
				if _, ok := nextArg(args, &i); !ok {
					return flagError(stdout, stderr, "flag needs an argument: "+a)
				}
			}
		default:
			if strings.HasPrefix(a, "-") {
				return flagError(stdout, stderr, "unknown flag: "+a)
			}
			opts.paths = append(opts.paths, a)
		}
	}

	if opts.threshold < 0 || opts.threshold > 255 {
		fmt.Fprint(stdout, "Error: threshold must be between 0 and 255\n\n")
		return nil
	}
	if len(opts.paths) == 0 {
		fmt.Fprint(stdout, "Error: Need at least 1 input path/url or piped input\nUse the -h flag for more info\n")
		return nil
	}
	for _, p := range opts.paths {
		if err := processPath(p, opts, stdout); err != nil {
			fmt.Fprintf(stdout, "Error: %v\n\n", err)
		}
	}
	return nil
}

func nextArg(args []string, i *int) (string, bool) {
	if *i+1 >= len(args) {
		return "", false
	}
	*i++
	return args[*i], true
}

func needsValue(flag string) bool {
	switch flag {
	case "-s", "--save-img", "--save-gif", "--save-bg", "--font", "--font-color":
		return true
	}
	return false
}

func flagError(stdout, stderr io.Writer, msg string) error {
	fmt.Fprintln(stdout, msg)
	fmt.Fprintf(stderr, "Error: %s\n%s", msg, helpText[strings.Index(helpText, "Usage:"):])
	fmt.Fprintln(stderr, msg)
	return errors.New(msg)
}

func parseInts(s string) ([]int, error) {
	parts := strings.Split(s, ",")
	out := make([]int, 0, len(parts))
	for _, p := range parts {
		n, err := strconv.Atoi(strings.TrimSpace(p))
		if err != nil {
			return nil, err
		}
		out = append(out, n)
	}
	return out, nil
}

func processPath(path string, opts options, stdout io.Writer) error {
	f, err := os.Open(path)
	if err != nil {
		return fmt.Errorf("unable to open file: %w", err)
	}
	defer f.Close()
	img, _, err := image.Decode(f)
	if err != nil {
		// The original accepts jpg; registering JPEG explicitly keeps that path reliable.
		if _, seekErr := f.Seek(0, io.SeekStart); seekErr == nil {
			img, err = jpeg.Decode(f)
		}
		if err != nil {
			return fmt.Errorf("unable to decode image: %w", err)
		}
	}
	art := render(img, opts)
	if opts.saveTxt != "" {
		name := strings.TrimSuffix(filepath.Base(path), filepath.Ext(path)) + "-ascii-art.txt"
		outPath := filepath.Join(opts.saveTxt, name)
		if err := os.WriteFile(outPath, []byte(strings.TrimRight(art, "\n")), 0644); err != nil {
			return err
		}
		if opts.onlySave {
			fmt.Fprintf(stdout, "Saved %s\n", displaySavePath(opts.saveTxt, name))
			return nil
		}
	}
	fmt.Fprint(stdout, art)
	return nil
}

func displaySavePath(dir, name string) string {
	if dir == "." {
		return "./" + name
	}
	return filepath.Join(dir, name)
}

func render(img image.Image, opts options) string {
	b := img.Bounds()
	srcW, srcH := b.Dx(), b.Dy()
	w, h := opts.width, opts.height
	if opts.dimSet {
		// already set
	} else if w > 0 && h == 0 {
		h = int(float64(w) * float64(srcH) / float64(srcW) * 0.5)
		if h < 1 {
			h = 1
		}
	} else if h > 0 && w == 0 {
		w = int(float64(h) * float64(srcW) / float64(srcH) * 2.0)
		if w < 1 {
			w = 1
		}
	}
	if w <= 0 {
		w = srcW
	}
	if h <= 0 {
		h = srcH
	}
	if opts.braille {
		return renderBraille(img, w, h, opts)
	}
	lines := make([]string, h)
	for y := 0; y < h; y++ {
		var sb strings.Builder
		for x := 0; x < w; x++ {
			sx := x
			if opts.flipX {
				sx = w - 1 - x
			}
			sy := y
			if opts.flipY {
				sy = h - 1 - y
			}
			lum := avgLum(img, b, sx, sy, w, h)
			if opts.negative {
				lum = 255 - lum
			}
			sb.WriteRune(mapRune(lum, opts.mapChars))
		}
		lines[y] = sb.String()
	}
	return strings.Join(lines, "\n") + "\n"
}

func avgLum(img image.Image, b image.Rectangle, ox, oy, outW, outH int) int {
	x0 := b.Min.X + ox*b.Dx()/outW
	x1 := b.Min.X + (ox+1)*b.Dx()/outW
	y0 := b.Min.Y + oy*b.Dy()/outH
	y1 := b.Min.Y + (oy+1)*b.Dy()/outH
	if x1 <= x0 {
		x1 = x0 + 1
	}
	if y1 <= y0 {
		y1 = y0 + 1
	}
	var sum, count int
	for y := y0; y < y1 && y < b.Max.Y; y++ {
		for x := x0; x < x1 && x < b.Max.X; x++ {
			sum += luminance(img.At(x, y))
			count++
		}
	}
	if count == 0 {
		return 0
	}
	return sum / count
}

func luminance(c color.Color) int {
	r, g, b, _ := c.RGBA()
	return int((299*(r>>8) + 587*(g>>8) + 114*(b>>8)) / 1000)
}

func mapRune(lum int, chars []rune) rune {
	if len(chars) == 0 {
		return ' '
	}
	idx := lum * (len(chars) - 1) / 255
	if idx < 0 {
		idx = 0
	}
	if idx >= len(chars) {
		idx = len(chars) - 1
	}
	return chars[idx]
}

func renderBraille(img image.Image, w, h int, opts options) string {
	b := img.Bounds()
	dots := [8][2]int{{0, 0}, {0, 1}, {0, 2}, {1, 0}, {1, 1}, {1, 2}, {0, 3}, {1, 3}}
	lines := make([]string, h)
	for cy := 0; cy < h; cy++ {
		var sb strings.Builder
		for cx := 0; cx < w; cx++ {
			mask := 0
			for bit, d := range dots {
				px := (cx*2 + d[0]) * b.Dx() / (w * 2)
				py := (cy*4 + d[1]) * b.Dy() / (h * 4)
				lum := luminance(img.At(b.Min.X+px, b.Min.Y+py))
				if opts.negative {
					lum = 255 - lum
				}
				if lum >= opts.threshold {
					mask |= 1 << bit
				}
			}
			sb.WriteRune(rune(0x2800 + mask))
		}
		lines[cy] = sb.String()
	}
	return strings.Join(lines, "\n") + "\n"
}
