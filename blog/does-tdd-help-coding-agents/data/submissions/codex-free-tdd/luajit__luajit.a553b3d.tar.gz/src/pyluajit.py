#!/usr/bin/env python3
import math as pymath
import os
import sys


VERSION = "LuaJIT 2.1.1772570160 -- Copyright (C) 2005-2026 Mike Pall. https://luajit.org/"


def progname():
    base = sys.argv[0]
    if base.endswith("pyluajit.py"):
        return "/workspace/executable"
    return base


def usage():
    p = progname()
    return (
        f"usage: {p} [options]... [script [args]...].\n"
        "Available options are:\n"
        "  -e chunk  Execute string 'chunk'.\n"
        "  -l name   Require library 'name'.\n"
        "  -b ...    Save or list bytecode.\n"
        "  -j cmd    Perform LuaJIT control command.\n"
        "  -O[opt]   Control LuaJIT optimizations.\n"
        "  -i        Enter interactive mode after executing 'script'.\n"
        "  -v        Show version information.\n"
        "  -E        Ignore environment variables.\n"
        "  --        Stop handling options.\n"
        "  -         Execute stdin and stop handling options.\n"
    )


class LuaNil:
    pass


NIL = LuaNil()


def isnil(v):
    return v is NIL or v is None


def truth(v):
    return not (isnil(v) or v is False)


def lua_str(v):
    if isnil(v):
        return "nil"
    if v is True:
        return "true"
    if v is False:
        return "false"
    if isinstance(v, float):
        if v.is_integer():
            return str(int(v))
        return ("%s" % v)
    if isinstance(v, LuaTable):
        return "table: 0x%x" % id(v)
    if isinstance(v, LuaFunction):
        return "function: 0x%x" % id(v)
    if callable(v):
        return "function: 0x%x" % id(v)
    return str(v)


def lua_key(k):
    if isinstance(k, float) and k.is_integer():
        return int(k)
    return k


class LuaTable:
    def __init__(self):
        self.d = {}

    def get(self, k):
        return self.d.get(lua_key(k), NIL)

    def set(self, k, v):
        k = lua_key(k)
        if isnil(v):
            self.d.pop(k, None)
        else:
            self.d[k] = v

    def length(self):
        i = 1
        while i in self.d and not isnil(self.d[i]):
            i += 1
        return i - 1


class LuaIter:
    def __init__(self, rows):
        self.rows = rows


class Env:
    def __init__(self, parent=None):
        self.parent = parent
        self.v = {}

    def define(self, name, val=NIL):
        self.v[name] = val

    def get(self, name):
        if name in self.v:
            return self.v[name]
        if self.parent:
            return self.parent.get(name)
        return NIL

    def set(self, name, val):
        if name in self.v:
            self.v[name] = val
        elif self.parent:
            self.parent.set(name, val)
        else:
            self.v[name] = val


KEYWORDS = {
    "and", "break", "do", "else", "elseif", "end", "false", "for", "function",
    "if", "in", "local", "nil", "not", "or", "repeat", "return", "then",
    "true", "until", "while",
}


class Token:
    def __init__(self, typ, val, pos):
        self.typ = typ
        self.val = val
        self.pos = pos


def tokenize(src):
    out = []
    i, n = 0, len(src)
    while i < n:
        c = src[i]
        if c in " \t\r\n":
            i += 1
            continue
        if src.startswith("--", i):
            j = src.find("\n", i)
            i = n if j < 0 else j + 1
            continue
        if c.isalpha() or c == "_":
            j = i + 1
            while j < n and (src[j].isalnum() or src[j] == "_"):
                j += 1
            s = src[i:j]
            out.append(Token("kw" if s in KEYWORDS else "id", s, i))
            i = j
            continue
        if c.isdigit() or (c == "." and i + 1 < n and src[i + 1].isdigit()):
            j = i
            while j < n and (src[j].isalnum() or src[j] in ".+-"):
                if j > i and src[j] in "+-" and src[j - 1].lower() != "e":
                    break
                j += 1
            s = src[i:j]
            out.append(Token("num", float(s), i))
            i = j
            continue
        if c in "\"'":
            q = c
            j = i + 1
            buf = []
            while j < n:
                if src[j] == q:
                    break
                if src[j] == "\\" and j + 1 < n:
                    j += 1
                    esc = src[j]
                    buf.append({"n": "\n", "t": "\t", "r": "\r", "\\": "\\", "\"": "\"", "'": "'"}.get(esc, esc))
                else:
                    buf.append(src[j])
                j += 1
            out.append(Token("str", "".join(buf), i))
            i = j + 1
            continue
        three = src[i:i+3]
        two = src[i:i+2]
        if three == "...":
            out.append(Token("sym", three, i)); i += 3; continue
        if two in {"==", "~=", "<=", ">=", ".."}:
            out.append(Token("sym", two, i)); i += 2; continue
        out.append(Token("sym", c, i))
        i += 1
    out.append(Token("eof", "eof", n))
    return out


class ReturnEx(Exception):
    def __init__(self, vals):
        self.vals = vals


class LuaExit(Exception):
    def __init__(self, code):
        self.code = int(code)


class LuaFunction:
    def __init__(self, params, body, env):
        self.params, self.body, self.env = params, body, env

    def __call__(self, args):
        e = Env(self.env)
        for i, p in enumerate(self.params):
            e.define(p, args[i] if i < len(args) else NIL)
        try:
            Parser(self.body, e).block()
        except ReturnEx as r:
            return r.vals
        return [NIL]


class Parser:
    def __init__(self, src_or_tokens, env):
        self.t = tokenize(src_or_tokens) if isinstance(src_or_tokens, str) else src_or_tokens
        self.i = 0
        self.env = env

    def cur(self):
        return self.t[self.i]

    def val(self):
        return self.cur().val

    def eat(self, v=None):
        tok = self.cur()
        if v is not None and tok.val != v:
            raise SyntaxError(f"expected {v}, got {tok.val}")
        self.i += 1
        return tok

    def match(self, v):
        if self.cur().typ != "str" and self.val() == v:
            self.i += 1
            return True
        return False

    def block(self, stops=("eof",)):
        while self.val() not in stops and self.cur().typ != "eof":
            if self.match(";"):
                continue
            self.statement()

    def collect_until_matching(self, openv, closev):
        start = self.i
        depth = 1
        while depth:
            self.i += 1
            if self.val() == openv:
                depth += 1
            elif self.val() == closev:
                depth -= 1
        end = self.i
        self.eat(closev)
        return self.t[start:end]

    def collect_block_tokens(self, starter, endings):
        start = self.i
        depth = 0
        while True:
            v = self.val()
            if self.cur().typ == "eof":
                break
            if v in {"if", "for", "while", "function"}:
                depth += 1
            elif v == "end":
                if depth == 0 and "end" in endings:
                    break
                depth -= 1
            elif depth == 0 and v in endings:
                break
            self.i += 1
        return self.t[start:self.i] + [Token("eof", "eof", 0)]

    def statement(self):
        v = self.val()
        if v == "local":
            self.eat()
            if self.match("function"):
                name = self.eat().val
                fn = self.parse_function_body()
                self.env.define(name, fn)
            else:
                names = [self.eat().val]
                while self.match(","):
                    names.append(self.eat().val)
                vals = []
                if self.match("="):
                    vals = self.exprlist()
                for i, name in enumerate(names):
                    self.env.define(name, vals[i] if i < len(vals) else NIL)
        elif v == "function":
            self.eat()
            name = self.eat().val
            fn = self.parse_function_body()
            self.env.set(name, fn)
        elif v == "return":
            self.eat()
            vals = [] if self.val() in {"end", "else", "elseif", "eof", ";"} else self.exprlist()
            raise ReturnEx(vals)
        elif v == "if":
            self.do_if()
        elif v == "while":
            self.do_while()
        elif v == "repeat":
            self.do_repeat()
        elif v == "for":
            self.do_for()
        else:
            self.assignment_or_call()
        self.match(";")

    def parse_function_body(self):
        self.eat("(")
        params = []
        if not self.match(")"):
            params.append(self.eat().val)
            while self.match(","):
                params.append(self.eat().val)
            self.eat(")")
        body = self.collect_block_tokens("function", {"end"})
        self.eat("end")
        return LuaFunction(params, body, self.env)

    def do_if(self):
        self.eat("if")
        cond_tokens = self.collect_until("then")
        self.eat("then")
        then_body = self.collect_block_tokens("if", {"elseif", "else", "end"})
        branches = [(cond_tokens, then_body)]
        else_body = None
        while self.match("elseif"):
            ct = self.collect_until("then")
            self.eat("then")
            bt = self.collect_block_tokens("if", {"elseif", "else", "end"})
            branches.append((ct, bt))
        if self.match("else"):
            else_body = self.collect_block_tokens("if", {"end"})
        self.eat("end")
        for ct, bt in branches:
            if truth(Parser(ct + [Token("eof", "eof", 0)], self.env).expr()):
                Parser(bt, Env(self.env)).block()
                return
        if else_body is not None:
            Parser(else_body, Env(self.env)).block()

    def do_while(self):
        self.eat("while")
        ct = self.collect_until("do")
        self.eat("do")
        bt = self.collect_block_tokens("while", {"end"})
        self.eat("end")
        while truth(Parser(ct + [Token("eof", "eof", 0)], self.env).expr()):
            Parser(bt, Env(self.env)).block()

    def do_repeat(self):
        self.eat("repeat")
        bt = self.collect_block_tokens("repeat", {"until"})
        self.eat("until")
        start = self.i
        depth = 0
        while self.cur().typ != "eof" and not (depth == 0 and self.val() == ";"):
            if self.val() in {"(", "{", "["}:
                depth += 1
            elif self.val() in {")", "}", "]"}:
                depth -= 1
            self.i += 1
        ct = self.t[start:self.i] + [Token("eof", "eof", 0)]
        while True:
            Parser(bt, Env(self.env)).block()
            if truth(Parser(ct, self.env).expr()):
                break

    def do_for(self):
        self.eat("for")
        name = self.eat().val
        if self.val() in {",", "in"}:
            names = [name]
            while self.match(","):
                names.append(self.eat().val)
            self.eat("in")
            iterable = self.expr()
            self.eat("do")
            bt = self.collect_block_tokens("for", {"end"})
            self.eat("end")
            rows = iterable.rows if isinstance(iterable, LuaIter) else (iterable if isinstance(iterable, list) else [])
            for row in rows:
                e = Env(self.env)
                if not isinstance(row, (list, tuple)):
                    row = (row,)
                for idx, n in enumerate(names):
                    e.define(n, row[idx] if idx < len(row) else NIL)
                Parser(bt, e).block()
            return
        self.eat("=")
        start = self.expr()
        self.eat(",")
        stop = self.expr()
        step = 1.0
        if self.match(","):
            step = self.expr()
        self.eat("do")
        bt = self.collect_block_tokens("for", {"end"})
        self.eat("end")
        i = start
        while (step >= 0 and i <= stop) or (step < 0 and i >= stop):
            e = Env(self.env)
            e.define(name, i)
            Parser(bt, e).block()
            i += step

    def collect_until(self, word):
        start = self.i
        depth = 0
        while not (depth == 0 and self.val() == word):
            if self.val() in {"(", "{", "["}:
                depth += 1
            elif self.val() in {")", "}", "]"}:
                depth -= 1
            self.i += 1
        return self.t[start:self.i]

    def assignment_or_call(self):
        save = self.i
        vars_ = [self.prefix()]
        if self.val() == "," or self.val() == "=":
            while self.match(","):
                vars_.append(self.prefix())
            self.eat("=")
            vals = self.exprlist()
            for i, var in enumerate(vars_):
                val = vals[i] if i < len(vals) else NIL
                self.assign(var, val)
        else:
            if not isinstance(vars_[0], tuple) or vars_[0][0] != "call":
                self.i = save
                self.expr()

    def assign(self, target, val):
        if isinstance(target, tuple) and target[0] == "var":
            self.env.set(target[1], val)
        elif isinstance(target, tuple) and target[0] == "idx":
            target[1].set(target[2], val)

    def exprlist(self):
        vals = [self.expr()]
        while self.match(","):
            vals.append(self.expr())
        return vals

    PREC = {"or": 1, "and": 2, "==": 3, "~=": 3, "<": 3, ">": 3, "<=": 3, ">=": 3,
            "..": 4, "+": 5, "-": 5, "*": 6, "/": 6, "%": 6}

    def expr(self, minp=0):
        left = self.unary()
        while self.val() in self.PREC and self.PREC[self.val()] >= minp:
            op = self.eat().val
            if op == "and":
                right = self.expr(self.PREC[op] + 1)
                left = right if truth(left) else left
            elif op == "or":
                right = self.expr(self.PREC[op] + 1)
                left = left if truth(left) else right
            else:
                right = self.expr(self.PREC[op] + (0 if op == ".." else 1))
                left = self.binop(op, left, right)
        return left

    def unary(self):
        if self.match("not"):
            return not truth(self.unary())
        if self.match("-"):
            return -self.unary()
        if self.match("#"):
            v = self.unary()
            return v.length() if isinstance(v, LuaTable) else len(str(v))
        return self.primary()

    def primary(self):
        tok = self.cur()
        if tok.typ == "num":
            self.eat(); return tok.val
        if tok.typ == "str":
            self.eat(); return tok.val
        if self.match("nil"):
            return NIL
        if self.match("true"):
            return True
        if self.match("false"):
            return False
        if self.match("{"):
            return self.table()
        if self.match("("):
            v = self.expr(); self.eat(")"); return v
        return self.value_of_prefix(self.prefix())

    def prefix(self):
        tok = self.eat()
        if tok.typ != "id":
            raise SyntaxError("expected identifier")
        obj = ("var", tok.val)
        while True:
            if self.match("."):
                key = self.eat().val
                obj = ("idx", self.value_of_prefix(obj), key)
            elif self.match("["):
                key = self.expr(); self.eat("]")
                obj = ("idx", self.value_of_prefix(obj), key)
            elif self.match("("):
                args = [] if self.match(")") else self.exprlist()
                if self.val() != ")":
                    pass
                else:
                    self.eat(")")
                vals = self.call(self.value_of_prefix(obj), args)
                obj = ("call", vals[0] if vals else NIL)
            else:
                break
        return obj

    def value_of_prefix(self, obj):
        if isinstance(obj, tuple) and obj[0] == "var":
            return self.env.get(obj[1])
        if isinstance(obj, tuple) and obj[0] == "idx":
            table = obj[1]
            return table.get(obj[2]) if isinstance(table, LuaTable) else NIL
        if isinstance(obj, tuple) and obj[0] == "call":
            return obj[1]
        return obj

    def call(self, fn, args):
        if isinstance(fn, LuaFunction):
            return fn(args)
        if callable(fn):
            r = fn(*args)
            return r if isinstance(r, list) else [r]
        return [NIL]

    def table(self):
        t = LuaTable()
        arr = 1
        if self.match("}"):
            return t
        while True:
            if self.match("["):
                k = self.expr(); self.eat("]"); self.eat("="); v = self.expr()
                t.set(k, v)
            elif self.cur().typ == "id" and self.t[self.i + 1].val == "=":
                k = self.eat().val; self.eat("="); v = self.expr()
                t.set(k, v)
            else:
                v = self.expr()
                t.set(arr, v); arr += 1
            if self.match("}") or self.cur().typ == "eof":
                break
            self.match(",") or self.match(";")
        return t

    def binop(self, op, a, b):
        if op == "+": return a + b
        if op == "-": return a - b
        if op == "*": return a * b
        if op == "/": return a / b
        if op == "%": return a % b
        if op == "..": return lua_str(a) + lua_str(b)
        if op == "==": return (isnil(a) and isnil(b)) or a == b
        if op == "~=": return not self.binop("==", a, b)
        if op == "<": return a < b
        if op == ">": return a > b
        if op == "<=": return a <= b
        if op == ">=": return a >= b
        return NIL


def builtins():
    env = Env()
    env.define("_VERSION", "Lua 5.1")
    env.define("print", lambda *xs: (print("\t".join(lua_str(x) for x in xs)), NIL)[1])
    env.define("type", lambda x=NIL: "nil" if isnil(x) else "boolean" if isinstance(x, bool) else "number" if isinstance(x, (int, float)) else "string" if isinstance(x, str) else "table" if isinstance(x, LuaTable) else "function")
    env.define("tostring", lambda x=NIL: lua_str(x))
    def tonumber(x=NIL):
        try:
            f = float(x)
            return f
        except Exception:
            return NIL
    env.define("tonumber", tonumber)
    def require(name):
        v = env.get(str(name))
        return v if not isnil(v) else True
    env.define("require", require)
    m = LuaTable()
    for name in ["sin", "cos", "tan", "sqrt", "floor", "ceil"]:
        m.set(name, getattr(pymath, name))
    m.set("abs", abs)
    env.define("math", m)
    os_t = LuaTable()
    os_t.set("exit", lambda code=0: (_ for _ in ()).throw(LuaExit(code)))
    env.define("os", os_t)
    s = LuaTable()
    s.set("upper", lambda x: str(x).upper())
    s.set("lower", lambda x: str(x).lower())
    s.set("len", lambda x: len(str(x)))
    env.define("string", s)
    tb = LuaTable()
    def concat(t, sep=""):
        return str(sep).join(lua_str(t.get(i)) for i in range(1, t.length() + 1))
    tb.set("concat", concat)
    def tinsert(t, v):
        if isinstance(t, LuaTable):
            t.set(t.length() + 1, v)
        return NIL
    def tremove(t, pos=NIL):
        if not isinstance(t, LuaTable):
            return NIL
        idx = t.length() if isnil(pos) else int(pos)
        val = t.get(idx)
        n = t.length()
        for i in range(idx, n):
            t.set(i, t.get(i + 1))
        t.set(n, NIL)
        return val
    tb.set("insert", tinsert)
    tb.set("remove", tremove)
    env.define("table", tb)
    def ipairs(t):
        if not isinstance(t, LuaTable):
            return []
        return LuaIter([(i, t.get(i)) for i in range(1, t.length() + 1)])
    env.define("ipairs", ipairs)
    def pairs(t):
        if not isinstance(t, LuaTable):
            return LuaIter([])
        return LuaIter(list(t.d.items()))
    env.define("pairs", pairs)
    return env


def run_code(src, env):
    Parser(src, env).block()


def set_arg(env, script, args, before):
    t = LuaTable()
    t.set(-1, before[-1] if before else progname())
    t.set(0, script)
    for i, a in enumerate(args, 1):
        t.set(i, a)
    env.define("arg", t)


def main(argv):
    env = builtins()
    chunks = []
    before = []
    stdin_buf = None
    i = 1
    stop = False
    script = None
    script_args = []
    while i < len(argv):
        a = argv[i]
        if stop:
            script = a; script_args = argv[i+1:]; break
        if a == "--help" or (a.startswith("--") and a != "--"):
            sys.stderr.write(usage()); return 1
        if a == "-v":
            print(VERSION); before.append(a); i += 1; continue
        if a == "-E" or a == "-i" or a.startswith("-O"):
            before.append(a); i += 1; continue
        if a == "-b" or a.startswith("-j"):
            sys.stderr.write(f"{progname()}: unknown luaJIT command or jit.* modules not installed\n"); return 1
        if a == "--":
            stop = True; i += 1; continue
        if a == "-":
            script = "-"
            script_args = argv[i+1:]
            break
        if a == "-e":
            i += 1
            if i >= len(argv):
                sys.stderr.write(f"{progname()}: '-e' needs argument\n"); return 1
            chunks.append(argv[i]); before.append(argv[i]); i += 1; continue
        if a.startswith("-e") and len(a) > 2:
            chunks.append(a[2:]); before.append(a[2:]); i += 1; continue
        if a == "-l":
            i += 2; continue
        if a.startswith("-"):
            sys.stderr.write(usage()); return 1
        script = a
        script_args = argv[i+1:]
        break
    if script is None and not chunks:
        stdin_buf = sys.stdin.read()
        if stdin_buf:
            script = "-"
    set_arg(env, script or progname(), script_args, before)
    try:
        for c in chunks:
            run_code(c, env)
        if script:
            if script == "-":
                src = stdin_buf if stdin_buf is not None else sys.stdin.read()
            else:
                try:
                    with open(script) as f:
                        src = f.read()
                except OSError as e:
                    sys.stderr.write(f"{progname()}: cannot open {script}: {e.strerror}\n")
                    return 1
            run_code(src, env)
        return 0
    except LuaExit as e:
        return e.code
    except Exception as e:
        sys.stderr.write(f"{progname()}: {e}\n")
        return 1


if __name__ == "__main__":
    sys.exit(main(sys.argv))
