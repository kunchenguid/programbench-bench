#!/usr/bin/env python3
import gzip
import os
import shlex
import stat
import sys
import time
import zipfile
import zlib
from pathlib import Path


VERSION = "pigz 2.8"
PROG = "pigz"
HELP = """Usage: pigz [options] [files ...]
  will compress files in place, adding the suffix '.gz'. If no files are
  specified, stdin will be compressed to stdout. pigz does what gzip does,
  but spreads the work over multiple processors and cores when compressing.

Options:
  -0 to -9, -11        Compression level (level 11, zopfli, is much slower)
  --fast, --best       Compression levels 1 and 9 respectively
  -A, --alias xxx      Use xxx as the name for any --zip entry from stdin
  -b, --blocksize mmm  Set compression block size to mmmK (default 128K)
  -c, --stdout         Write all processed output to stdout (won't delete)
  -C, --comment ccc    Put comment ccc in the gzip or zip header
  -d, --decompress     Decompress the compressed input
  -f, --force          Force overwrite, compress .gz, links, and to terminal
  -F  --first          Do iterations first, before block split for -11
  -h, --help           Display a help screen and quit
  -H, --huffman        Use only Huffman coding for compression
  -i, --independent    Compress blocks independently for damage recovery
  -I, --iterations n   Number of iterations for -11 optimization
  -J, --maxsplits n    Maximum number of split blocks for -11
  -k, --keep           Do not delete original file after processing
  -K, --zip            Compress to PKWare zip (.zip) single entry format
  -l, --list           List the contents of the compressed input
  -L, --license        Display the pigz license and quit
  -m, --no-time        Do not store or restore mod time
  -M, --time           Store or restore mod time
  -n, --no-name        Do not store or restore file name or mod time
  -N, --name           Store or restore file name and mod time
  -O  --oneblock       Do not split into smaller blocks for -11
  -p, --processes n    Allow up to n compression threads (default is the
                       number of online processors, or 8 if unknown)
  -q, --quiet          Print no messages, even on error
  -r, --recursive      Process the contents of all subdirectories
  -R, --rsyncable      Input-determined block locations for rsync
  -S, --suffix .sss    Use suffix .sss instead of .gz (for compression)
  -t, --test           Test the integrity of the compressed input
  -U, --rle            Use run-length encoding for compression
  -v, --verbose        Provide more verbose output
  -V  --version        Show the version of pigz
  -Y  --synchronous    Force output file write to permanent storage
  -z, --zlib           Compress to zlib (.zz) instead of gzip format
  --                   All arguments after "--" are treated as files
"""
LICENSE = """pigz 2.8
Copyright (C) 2007-2023 Mark Adler <madler@alumni.caltech.edu>
This software is provided 'as-is', without any express or implied warranty.
"""


class Options:
    def __init__(self):
        self.level = 6
        self.stdout = False
        self.decompress = False
        self.force = False
        self.keep = False
        self.zip = False
        self.zlib = False
        self.list = False
        self.test = False
        self.recursive = False
        self.verbose = 0
        self.quiet = False
        self.suffix = ".gz"
        self.alias = "-"
        self.name = True
        self.mtime = True
        self.name_set = False
        self.mtime_set = False
        self.files = []


def die(msg, code=1, opts=None):
    if not (opts and opts.quiet):
        sys.stderr.write(f"{PROG}: {msg}\n")
    raise SystemExit(code)


def parse(argv):
    args = []
    for var in ("GZIP", "PIGZ"):
        if os.environ.get(var):
            args.extend(shlex.split(os.environ[var]))
    args.extend(argv)
    opt = Options()
    i = 0
    endopts = False
    while i < len(args):
        a = args[i]
        if endopts or not a.startswith("-") or a == "-":
            opt.files.append("./-" if endopts and a == "-" else a)
            i += 1
            continue
        if a == "--":
            endopts = True
            i += 1
            continue
        if a in ("--help",):
            sys.stderr.write(HELP)
            raise SystemExit(0)
        if a in ("--version",):
            print(VERSION)
            raise SystemExit(0)
        if a in ("--license",):
            print(LICENSE, end="")
            raise SystemExit(0)
        long_map = {
            "--fast": "1", "--best": "9", "--stdout": "c", "--to-stdout": "c",
            "--decompress": "d", "--uncompress": "d", "--force": "f",
            "--keep": "k", "--zip": "K", "--list": "l", "--test": "t",
            "--recursive": "r", "--zlib": "z", "--verbose": "v",
            "--quiet": "q", "--silent": "q", "--no-time": "m",
            "--time": "M", "--no-name": "n", "--name": "N",
            "--huffman": "H", "--independent": "i", "--rsyncable": "R",
            "--rle": "U", "--first": "F", "--oneblock": "O",
            "--synchronous": "Y",
        }
        if a in ("--alias", "--comment", "--blocksize", "--processes", "--suffix",
                 "--iterations", "--maxsplits"):
            if i + 1 >= len(args):
                die(f"option {a} requires an argument", opts=opt)
            val = args[i + 1]
            if a == "--alias":
                opt.alias = val
            elif a == "--suffix":
                opt.suffix = val
            i += 2
            continue
        if a in long_map:
            apply_short(opt, long_map[a])
            i += 1
            continue
        if a == "-11":
            opt.level = 9
            i += 1
            continue
        if a.startswith("-") and len(a) > 1:
            chars = a[1:]
            j = 0
            while j < len(chars):
                ch = chars[j]
                if ch in "AbCpSIJ":
                    val = chars[j + 1:]
                    if not val:
                        i += 1
                        if i >= len(args):
                            die(f"option requires an argument -- {ch}", opts=opt)
                        val = args[i]
                    if ch == "A":
                        opt.alias = val
                    elif ch == "S":
                        opt.suffix = val
                    break
                apply_short(opt, ch)
                j += 1
            i += 1
            continue
        opt.files.append(a)
        i += 1
    return opt


def apply_short(opt, ch):
    if ch.isdigit():
        opt.level = int(ch)
    elif ch == "c":
        opt.stdout = True
    elif ch == "d":
        opt.decompress = True
    elif ch == "f":
        opt.force = True
    elif ch == "k":
        opt.keep = True
    elif ch == "K":
        opt.zip = True
        opt.zlib = False
        opt.suffix = ".zip"
    elif ch == "z":
        opt.zlib = True
        opt.zip = False
        opt.suffix = ".zz"
    elif ch == "l":
        opt.list = True
    elif ch == "t":
        opt.test = True
    elif ch == "r":
        opt.recursive = True
    elif ch == "v":
        opt.verbose += 1
    elif ch == "V":
        print(VERSION)
        if opt.verbose:
            print(f"zlib {zlib.ZLIB_VERSION}")
        raise SystemExit(0)
    elif ch == "q":
        opt.quiet = True
    elif ch == "m":
        opt.mtime = False
        opt.mtime_set = True
    elif ch == "M":
        opt.mtime = True
        opt.mtime_set = True
    elif ch == "n":
        opt.name = False
        opt.mtime = False
        opt.name_set = True
        opt.mtime_set = True
    elif ch == "N":
        opt.name = True
        opt.mtime = True
        opt.name_set = True
        opt.mtime_set = True
    elif ch == "L":
        print(LICENSE, end="")
        raise SystemExit(0)
    elif ch == "h":
        sys.stderr.write(HELP)
        raise SystemExit(0)
    elif ch in "HibpCRUFYOIJ":
        pass
    else:
        die(f"abort: invalid option: -{ch}", opts=opt)


def gzip_bytes(data, level=6, filename="", mtime=None):
    import io
    bio = io.BytesIO()
    with gzip.GzipFile(filename=filename, mode="wb", compresslevel=level, fileobj=bio, mtime=mtime) as gf:
        gf.write(data)
    return bio.getvalue()


def compress_bytes(data, opt, name="-", mtime=None):
    level = max(0, min(9, opt.level))
    if opt.zlib:
        return zlib.compress(data, level)
    if opt.zip:
        import io
        bio = io.BytesIO()
        zi = zipfile.ZipInfo(name if name != "-" else opt.alias)
        zi.compress_type = zipfile.ZIP_DEFLATED
        if mtime:
            zi.date_time = time.localtime(mtime)[:6]
        with zipfile.ZipFile(bio, "w") as zf:
            zf.writestr(zi, data, compress_type=zipfile.ZIP_DEFLATED, compresslevel=level)
        return bio.getvalue()
    return gzip_bytes(data, level, filename=(name if opt.name else ""), mtime=(int(mtime) if opt.mtime and mtime else 0))


def decompress_bytes(data):
    if data.startswith(b"PK\x03\x04"):
        import io
        with zipfile.ZipFile(io.BytesIO(data)) as zf:
            names = zf.namelist()
            return zf.read(names[0]) if names else b""
    if data.startswith(b"\x78"):
        try:
            return zlib.decompress(data)
        except zlib.error:
            pass
    return gzip.decompress(data)


def gzip_header_info(data):
    if len(data) < 10 or data[:2] != b"\x1f\x8b":
        return None, None
    flg = data[3]
    mtime = int.from_bytes(data[4:8], "little")
    pos = 10
    if flg & 4:
        if pos + 2 > len(data):
            return None, mtime or None
        xlen = int.from_bytes(data[pos:pos + 2], "little")
        pos += 2 + xlen
    name = None
    if flg & 8:
        end = data.find(b"\0", pos)
        if end != -1:
            raw = data[pos:end]
            try:
                name = os.path.basename(raw.decode("latin-1"))
            except UnicodeDecodeError:
                name = None
            pos = end + 1
    if flg & 16:
        end = data.find(b"\0", pos)
        pos = len(data) if end == -1 else end + 1
    if flg & 2:
        pos += 2
    return name, (mtime or None)


def iter_files(paths, recursive):
    for item in paths:
        if item == "-":
            yield "-"
            continue
        p = Path(item)
        if p.is_dir():
            if recursive:
                for root, _, files in os.walk(p):
                    for f in files:
                        yield str(Path(root) / f)
            else:
                sys.stderr.write(f"pigz: skipping: {item} is a directory\n")
            continue
        yield item


def output_name_for_compress(path, opt):
    return str(path) + opt.suffix


def output_name_for_decompress(path, opt):
    s = str(path)
    if s.endswith(".tgz") or s.endswith(".taz"):
        return s[:-4] + ".tar"
    for suf in (opt.suffix, ".gz", ".zz", ".zip", ".z"):
        if s.endswith(suf):
            return s[:-len(suf)]
    return s + ".out"


def compress_file(path, opt):
    if path == "-":
        data = sys.stdin.buffer.read()
        sys.stdout.buffer.write(compress_bytes(data, opt, opt.alias, None))
        return
    p = Path(path)
    if p.suffix == opt.suffix and not opt.force:
        if not opt.quiet:
            sys.stderr.write(f"pigz: skipping: {path} ends with {opt.suffix}\n")
        return
    data = p.read_bytes()
    st = p.stat()
    out = compress_bytes(data, opt, p.name, st.st_mtime)
    if opt.stdout:
        sys.stdout.buffer.write(out)
        return
    out_path = Path(output_name_for_compress(p, opt))
    if out_path.exists() and not opt.force:
        die(f"skipping: {out_path} exists", opts=opt)
    out_path.write_bytes(out)
    os.chmod(out_path, stat.S_IMODE(st.st_mode))
    os.utime(out_path, (st.st_mtime, st.st_mtime))
    if not opt.keep:
        p.unlink()


def decompress_file(path, opt):
    if path == "-":
        data = sys.stdin.buffer.read()
        sys.stdout.buffer.write(decompress_bytes(data))
        return
    p = Path(path)
    data = p.read_bytes()
    out = decompress_bytes(data)
    if opt.stdout or opt.test:
        if not opt.test:
            sys.stdout.buffer.write(out)
        return
    header_name, header_mtime = gzip_header_info(data)
    if opt.name and opt.name_set and header_name:
        out_path = p.with_name(header_name)
    else:
        out_path = Path(output_name_for_decompress(p, opt))
    if out_path.exists() and not opt.force:
        die(f"skipping: {out_path} exists", opts=opt)
    out_path.write_bytes(out)
    try:
        os.chmod(out_path, stat.S_IMODE(p.stat().st_mode))
        restore_mtime = header_mtime if (opt.name_set and header_mtime) else p.stat().st_mtime
        if opt.mtime and restore_mtime:
            os.utime(out_path, (restore_mtime, restore_mtime))
    except OSError:
        pass
    if not opt.keep:
        p.unlink()


def list_file(path):
    p = Path(path)
    comp = p.stat().st_size
    data = decompress_bytes(p.read_bytes())
    orig = len(data)
    name = output_name_for_decompress(p, Options())
    ratio = 0.0 if orig == 0 else (1.0 - (comp - 24) / orig) * 100.0
    return comp, orig, ratio, Path(name).name


def main(argv):
    opt = parse(argv)
    if opt.list:
        print("compressed   original reduced  name")
        for f in iter_files(opt.files or ["-"], opt.recursive):
            if f == "-":
                data = sys.stdin.buffer.read()
                orig = len(decompress_bytes(data))
                print(f"{len(data):10d} {orig:10d}   0.0%  -")
            else:
                comp, orig, ratio, name = list_file(f)
                print(f"{comp:10d} {orig:10d} {ratio:6.1f}%  {name}")
        return 0
    if opt.test:
        opt.decompress = True
    if opt.decompress and not opt.name_set:
        opt.name = False
    if not opt.files:
        opt.stdout = True
        opt.files = ["-"]
    for f in iter_files(opt.files, opt.recursive):
        if opt.decompress:
            decompress_file(f, opt)
        else:
            compress_file(f, opt)
    return 0


if __name__ == "__main__":
    PROG = os.path.basename(sys.argv[0]) or "pigz"
    try:
        raise SystemExit(main(sys.argv[1:]))
    except (OSError, EOFError, gzip.BadGzipFile, zlib.error, zipfile.BadZipFile) as exc:
        die(str(exc))
