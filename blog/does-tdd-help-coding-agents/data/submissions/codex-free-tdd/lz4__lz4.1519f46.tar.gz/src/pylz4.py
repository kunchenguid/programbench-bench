#!/usr/bin/env python3
import os
import struct
import sys
from pathlib import Path


VERSION = "*** lz4 v1.10.0 64-bit multithread, by Yann Collet ***"
MAGIC = b"\x04\x22\x4d\x18"
LEGACY_MAGIC = b"\x02\x21\x4c\x18"


HELP = f"""{VERSION}
Usage : 
      executable [arg] [input] [output] 

input   : a filename 
          with no FILE, or when FILE is - or stdin, read standard input
Arguments : 
 -1     : fast compression (default) 
 -12    : slowest compression level 
 -T#    : use # threads for compression (default:0==auto) 
 -d     : decompression (default for .lz4 extension)
 -f     : overwrite output without prompting 
 -k     : preserve source files(s)  (default) 
--rm    : remove source file(s) after successful de/compression 
 -h/-H  : display help/long help and exit 

Advanced arguments :
 -V     : display Version number and exit 
 -v     : verbose mode 
 -q     : suppress warnings; specify twice to suppress errors too
 -c     : force write to standard output, even if it is the console
 -t     : test compressed file integrity
 -m     : multiple input files (implies automatic output filenames)
 -r     : operate recursively on directories (sets also -m) 
 -l     : compress using Legacy format (Linux kernel compression)
 -z     : force compression 
 -D FILE: use FILE as dictionary (compression & decompression)
 -B#    : cut file into blocks of size # bytes [32+] 
                     or predefined block size [4-7] (default: 7) 
 -BI    : Block Independence (default) 
 -BD    : Block dependency (improves compression ratio) 
 -BX    : enable block checksum (default:disabled) 
--no-frame-crc : disable stream checksum (default:enabled) 
--content-size : compressed frame includes original size (default:not present)
--list FILE : lists information about .lz4 files (useful for files compressed with --content-size flag)
--[no-]sparse  : sparse mode (default:enabled on file, disabled on stdout)
--favor-decSpeed: compressed files decompress faster, but are less compressed 
--fast[=#]: switch to ultra fast compression level (default: 1)
--best  : same as -12
Benchmark arguments : 
 -b#    : benchmark file(s), using # compression level (default : 1) 
 -e#    : test all compression levels from -bX to # (default : 1)
 -i#    : minimum evaluation time in seconds (default : 3s) 
"""


def rotl32(x, r):
    return ((x << r) | (x >> (32 - r))) & 0xFFFFFFFF


def xxh32(data, seed=0):
    p1, p2, p3, p4, p5 = 2654435761, 2246822519, 3266489917, 668265263, 374761393
    data = memoryview(data)
    n = len(data)
    i = 0
    if n >= 16:
        v1 = (seed + p1 + p2) & 0xFFFFFFFF
        v2 = (seed + p2) & 0xFFFFFFFF
        v3 = seed & 0xFFFFFFFF
        v4 = (seed - p1) & 0xFFFFFFFF
        while i <= n - 16:
            v1 = (rotl32((v1 + struct.unpack_from("<I", data, i)[0] * p2) & 0xFFFFFFFF, 13) * p1) & 0xFFFFFFFF
            i += 4
            v2 = (rotl32((v2 + struct.unpack_from("<I", data, i)[0] * p2) & 0xFFFFFFFF, 13) * p1) & 0xFFFFFFFF
            i += 4
            v3 = (rotl32((v3 + struct.unpack_from("<I", data, i)[0] * p2) & 0xFFFFFFFF, 13) * p1) & 0xFFFFFFFF
            i += 4
            v4 = (rotl32((v4 + struct.unpack_from("<I", data, i)[0] * p2) & 0xFFFFFFFF, 13) * p1) & 0xFFFFFFFF
            i += 4
        h = (rotl32(v1, 1) + rotl32(v2, 7) + rotl32(v3, 12) + rotl32(v4, 18)) & 0xFFFFFFFF
    else:
        h = (seed + p5) & 0xFFFFFFFF
    h = (h + n) & 0xFFFFFFFF
    while i <= n - 4:
        h = (rotl32((h + struct.unpack_from("<I", data, i)[0] * p3) & 0xFFFFFFFF, 17) * p4) & 0xFFFFFFFF
        i += 4
    while i < n:
        h = (rotl32((h + data[i] * p5) & 0xFFFFFFFF, 11) * p1) & 0xFFFFFFFF
        i += 1
    h ^= h >> 15
    h = (h * p2) & 0xFFFFFFFF
    h ^= h >> 13
    h = (h * p3) & 0xFFFFFFFF
    h ^= h >> 16
    return h & 0xFFFFFFFF


def lz4_block_decompress(block):
    src = memoryview(block)
    out = bytearray()
    i = 0
    n = len(src)
    while i < n:
        token = src[i]
        i += 1
        literal_len = token >> 4
        if literal_len == 15:
            while True:
                if i >= n:
                    raise ValueError("Malformed LZ4 block")
                b = src[i]
                i += 1
                literal_len += b
                if b != 255:
                    break
        if i + literal_len > n:
            raise ValueError("Malformed LZ4 block")
        out.extend(src[i:i + literal_len])
        i += literal_len
        if i >= n:
            break
        if i + 2 > n:
            raise ValueError("Malformed LZ4 block")
        offset = src[i] | (src[i + 1] << 8)
        i += 2
        if offset == 0 or offset > len(out):
            raise ValueError("Malformed LZ4 block")
        match_len = (token & 0x0F) + 4
        if (token & 0x0F) == 15:
            while True:
                if i >= n:
                    raise ValueError("Malformed LZ4 block")
                b = src[i]
                i += 1
                match_len += b
                if b != 255:
                    break
        start = len(out) - offset
        for j in range(match_len):
            out.append(out[start + j])
    return bytes(out)


def max_block_size_from_bd(bd):
    code = (bd >> 4) & 7
    return {4: 64 << 10, 5: 256 << 10, 6: 1 << 20, 7: 4 << 20}.get(code, 4 << 20)


def decompress_frame(data):
    pos = 0
    result = bytearray()
    while pos < len(data):
        if pos + 4 <= len(data):
            magic = struct.unpack_from("<I", data, pos)[0]
            if 0x184D2A50 <= magic <= 0x184D2A5F:
                pos += 4
                if pos + 4 > len(data):
                    raise ValueError("Truncated skippable frame")
                size = struct.unpack_from("<I", data, pos)[0]
                pos += 4 + size
                continue
        if data[pos:pos + 4] == MAGIC:
            pos += 4
            if pos + 3 > len(data):
                raise ValueError("Unrecognized header")
            flg = data[pos]
            bd = data[pos + 1]
            pos += 2
            if (flg >> 6) != 1:
                raise ValueError("Unsupported LZ4 frame")
            if flg & 0x08:
                pos += 8
            if flg & 0x01:
                pos += 4
            pos += 1
            max_block = max_block_size_from_bd(bd)
            while True:
                if pos + 4 > len(data):
                    raise ValueError("Truncated LZ4 frame")
                raw_size = struct.unpack_from("<I", data, pos)[0]
                pos += 4
                if raw_size == 0:
                    break
                uncompressed = bool(raw_size & 0x80000000)
                size = raw_size & 0x7FFFFFFF
                if size > max_block and not uncompressed:
                    raise ValueError("Invalid block size")
                if pos + size > len(data):
                    raise ValueError("Truncated LZ4 block")
                block = data[pos:pos + size]
                pos += size
                if flg & 0x10:
                    pos += 4
                result.extend(block if uncompressed else lz4_block_decompress(block))
            if flg & 0x04:
                pos += 4
        elif data[pos:pos + 4] == LEGACY_MAGIC:
            pos += 4
            while pos < len(data):
                if pos + 4 > len(data):
                    raise ValueError("Truncated legacy frame")
                size = struct.unpack_from("<I", data, pos)[0]
                pos += 4
                if pos + size > len(data):
                    raise ValueError("Truncated legacy block")
                result.extend(lz4_block_decompress(data[pos:pos + size]))
                pos += size
        else:
            raise ValueError("Unrecognized LZ4 format")
    return bytes(result)


def compress_frame(data, content_size=False):
    flg = 0x60 | (0x08 if content_size else 0)
    bd = 0x70
    descriptor = bytearray([flg, bd])
    if content_size:
        descriptor.extend(struct.pack("<Q", len(data)))
    descriptor.append((xxh32(descriptor) >> 8) & 0xFF)
    out = bytearray(MAGIC)
    out.extend(descriptor)
    block_size = 4 << 20
    for i in range(0, len(data), block_size):
        block = data[i:i + block_size]
        out.extend(struct.pack("<I", len(block) | 0x80000000))
        out.extend(block)
    out.extend(b"\x00\x00\x00\x00")
    return bytes(out)


def parse_args(argv):
    opts = {
        "mode": None,
        "stdout": False,
        "force": False,
        "rm": False,
        "test": False,
        "list": False,
        "multiple": False,
        "content_size": False,
        "quiet": 0,
    }
    files = []
    i = 0
    while i < len(argv):
        arg = argv[i]
        if arg == "--":
            files.extend(argv[i + 1:])
            break
        if arg == "--help" or arg in ("-h", "-H"):
            opts["help"] = True
        elif arg == "-V":
            opts["version"] = True
        elif arg == "--list":
            opts["list"] = True
            if i + 1 < len(argv):
                files.append(argv[i + 1])
                i += 1
        elif arg == "--rm":
            opts["rm"] = True
        elif arg in ("--keep", "-k"):
            opts["rm"] = False
        elif arg in ("--compress", "--decompress"):
            opts["mode"] = "compress" if arg == "--compress" else "decompress"
        elif arg == "--content-size":
            opts["content_size"] = True
        elif arg.startswith("--fast") or arg in ("--best", "--no-frame-crc", "--sparse", "--no-sparse", "--favor-decSpeed"):
            pass
        elif arg.startswith("-") and arg != "-":
            j = 1
            while j < len(arg):
                ch = arg[j]
                if ch == "d":
                    opts["mode"] = "decompress"
                elif ch == "z":
                    opts["mode"] = "compress"
                elif ch == "c":
                    opts["stdout"] = True
                elif ch == "f":
                    opts["force"] = True
                elif ch == "t":
                    opts["test"] = True
                    opts["mode"] = "decompress"
                elif ch == "m":
                    opts["multiple"] = True
                elif ch == "r":
                    opts["multiple"] = True
                elif ch == "q":
                    opts["quiet"] += 1
                elif ch == "v":
                    pass
                elif ch in "0123456789lBI":
                    pass
                elif ch in "TBD":
                    break
                else:
                    pass
                j += 1
        else:
            files.append(arg)
        i += 1
    return opts, files


def read_input(name):
    if not name or name == "-":
        return sys.stdin.buffer.read()
    return Path(name).read_bytes()


def default_output_for(input_name, mode):
    if not input_name or input_name == "-":
        return None
    if mode == "decompress":
        return input_name[:-4] if input_name.endswith(".lz4") else input_name + ".out"
    return input_name + ".lz4"


def write_output(path, data, force=False):
    if path == "null":
        return
    if path is None or path in ("-", "stdout"):
        sys.stdout.buffer.write(data)
        return
    p = Path(path)
    if p.exists() and not force:
        sys.stderr.write(f"{p} already exists; do you want to overwrite (y/N) ?     not overwritten  \n")
        raise FileExistsError(path)
    p.write_bytes(data)


def list_files(files):
    print("    Frames           Type Block  Compressed  Uncompressed    Ratio   Filename")
    status = 0
    for name in files:
        try:
            data = Path(name).read_bytes()
            frames, usize = frame_summary(data)
            comp = len(data)
            utext = str(usize) if usize is not None else "-"
            ratio = f"{(comp / usize * 100):7.2f}%" if usize else "       -"
            print(f"{frames:10d}       LZ4Frame   B4I {comp:11.2f} {utext:>13} {ratio}   {Path(name).name}")
        except Exception as exc:
            sys.stderr.write(f"{name}: {exc}\n")
            status = 1
    return status


def frame_summary(data):
    pos = 0
    frames = 0
    total_content = 0
    known = True
    while pos < len(data):
        magic = struct.unpack_from("<I", data, pos)[0] if pos + 4 <= len(data) else 0
        if 0x184D2A50 <= magic <= 0x184D2A5F:
            pos += 4
            size = struct.unpack_from("<I", data, pos)[0]
            pos += 4 + size
            continue
        if data[pos:pos + 4] != MAGIC:
            raise ValueError("Unrecognized LZ4 format")
        frames += 1
        pos += 4
        flg = data[pos]
        bd = data[pos + 1]
        pos += 2
        if flg & 0x08:
            total_content += struct.unpack_from("<Q", data, pos)[0]
            pos += 8
        else:
            known = False
        if flg & 0x01:
            pos += 4
        pos += 1
        while True:
            raw = struct.unpack_from("<I", data, pos)[0]
            pos += 4
            if raw == 0:
                break
            pos += raw & 0x7FFFFFFF
            if flg & 0x10:
                pos += 4
        if flg & 0x04:
            pos += 4
    return frames, total_content if known else None


def operate_one(opts, input_name, output_name=None):
    mode = opts["mode"]
    if mode is None:
        mode = "decompress" if input_name and input_name.endswith(".lz4") else "compress"
    data = read_input(input_name)
    try:
        if mode == "decompress":
            result = decompress_frame(data)
        else:
            result = compress_frame(data, opts["content_size"])
    except Exception as exc:
        if opts["quiet"] < 2:
            sys.stderr.write(f"Error : {exc}\n")
        return 1
    if opts["test"]:
        if opts["quiet"] == 0 and input_name:
            sys.stderr.write(f"{input_name:<30}: decoded {len(result)} bytes \n")
    else:
        out = None if opts["stdout"] else (output_name or default_output_for(input_name, mode))
        try:
            write_output(out, result, opts["force"])
        except FileExistsError:
            return 1
    if opts["rm"] and input_name and input_name != "-":
        try:
            Path(input_name).unlink()
        except FileNotFoundError:
            pass
    return 0


def main(argv=None):
    argv = sys.argv[1:] if argv is None else argv
    opts, files = parse_args(argv)
    if opts.get("help"):
        sys.stdout.write(HELP)
        return 0
    if opts.get("version"):
        sys.stdout.write(VERSION + "\n")
        return 0
    if opts["list"]:
        return list_files(files)
    if opts["multiple"]:
        status = 0
        for name in files:
            if Path(name).is_dir():
                for root, _, filenames in os.walk(name):
                    for filename in filenames:
                        child = str(Path(root) / filename)
                        if child.endswith(".lz4") and opts["mode"] != "compress":
                            continue
                        status |= operate_one(opts, child)
                continue
            status |= operate_one(opts, name)
        return status
    if len(files) >= 2:
        return operate_one(opts, files[0], files[1])
    if len(files) == 1:
        return operate_one(opts, files[0])
    return operate_one(opts, None)


if __name__ == "__main__":
    raise SystemExit(main())
