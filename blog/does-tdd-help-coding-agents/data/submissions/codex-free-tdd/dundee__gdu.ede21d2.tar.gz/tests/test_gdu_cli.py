import os
import stat
import subprocess
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / "src" / "gdu.py"


def run_gdu(args, cwd):
    return subprocess.run(
        ["python3", str(SRC), *args],
        cwd=cwd,
        text=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        check=False,
    )


def make_fixture(tmp_path):
    root = tmp_path / "probe"
    (root / "dir" / "sub").mkdir(parents=True)
    (root / "empty").mkdir()
    (root / ".hidden").mkdir()
    (root / "a.txt").write_text("abc")
    (root / "dir" / "b.bin").write_text("1234567890")
    (root / "dir" / "sub" / "c.log").write_text("z")
    os.symlink("a.txt", root / "link.txt")
    return root


def usage_of(path):
    st = os.lstat(path)
    return st.st_blocks * 512


def fmt(size):
    if size == 0:
        return "       0 B"
    if size < 1024:
        return f"{size:8d} B"
    return f"{size / 1024:6.1f} KiB"


def test_version_matches_documented_dev_build(tmp_path):
    result = run_gdu(["--version"], tmp_path)

    assert result.returncode == 0
    assert result.stdout == (
        "Version:\t dev\n"
        "Built time:\t Fri Apr 17 19:59:35 UTC 2026\n"
        "Built user:\t root\n"
    )
    assert result.stderr == ""


def test_non_interactive_lists_children_by_disk_usage(tmp_path):
    root = make_fixture(tmp_path)
    d = root / "dir"
    empty = root / "empty"
    hidden = root / ".hidden"
    a = root / "a.txt"
    link = root / "link.txt"
    dir_total = usage_of(d) + usage_of(d / "b.bin") + usage_of(d / "sub") + usage_of(d / "sub" / "c.log")

    result = run_gdu(["-np", str(root)], tmp_path)

    assert result.returncode == 0
    assert result.stdout == "\n".join(
        [
            f" {fmt(dir_total)} /dir",
            f"e{fmt(usage_of(empty))} /empty",
            f" {fmt(usage_of(a))} a.txt",
            f"e{fmt(usage_of(hidden))} /.hidden",
            f"@{fmt(usage_of(link))} link.txt",
            "",
        ]
    )
    assert result.stderr == ""


def test_apparent_and_no_prefix_modes(tmp_path):
    root = make_fixture(tmp_path)
    dsize = sum(os.lstat(p).st_size for p in [root / "dir", root / "dir" / "b.bin", root / "dir" / "sub", root / "dir" / "sub" / "c.log"])

    apparent = run_gdu(["-npa", str(root)], tmp_path)
    raw = run_gdu(["-np", "--no-prefix", str(root)], tmp_path)

    assert apparent.returncode == 0
    assert f" {fmt(dsize)} /dir\n" in apparent.stdout
    assert "        3 B a.txt\n" in apparent.stdout
    assert "@       5 B link.txt\n" in apparent.stdout
    assert raw.returncode == 0
    assert "      0 link.txt\n" in raw.stdout


def test_depth_output_uses_absolute_paths(tmp_path):
    root = make_fixture(tmp_path)
    total = sum(usage_of(p) for p in [
        root,
        root / "dir",
        root / "dir" / "b.bin",
        root / "dir" / "sub",
        root / "dir" / "sub" / "c.log",
        root / "empty",
        root / "a.txt",
        root / ".hidden",
        root / "link.txt",
    ])

    result = run_gdu(["-np", "--depth", "1", str(root)], tmp_path)

    assert result.returncode == 0
    assert result.stdout.startswith(f"{fmt(total)} {root.resolve()}\n")
    assert f"{fmt(usage_of(root / 'link.txt'))} {root.resolve() / 'link.txt'}\n" in result.stdout


def test_output_file_can_be_imported(tmp_path):
    root = make_fixture(tmp_path)
    output = tmp_path / "analysis.json"

    exported = run_gdu(["-npo", str(output), str(root)], tmp_path)
    imported = run_gdu(["-npf", str(output)], tmp_path)

    assert exported.returncode == 0
    assert exported.stdout == ""
    assert output.read_text().startswith('[1,2,{"progname":"gdu","progver":"dev"')
    assert imported.returncode == 0
    assert " /dir\n" in imported.stdout
    assert "@       0 B link.txt\n" in imported.stdout
