#!/usr/bin/env python3
import fnmatch
import json
import os
import re
import shutil
import stat
import sys
import time
from dataclasses import dataclass, field
from pathlib import Path


VERSION_TEXT = "Version:\t dev\nBuilt time:\t Fri Apr 17 19:59:35 UTC 2026\nBuilt user:\t root\n"


HELP_TEXT = """Pretty fast disk usage analyzer written in Go.

Gdu is intended primarily for SSD disks where it can fully utilize parallel processing.
However HDDs work as well, but the performance gain is not so huge.

Usage:
  gdu [directory_to_scan] [flags]

Flags:
      --archive-browsing              Enable browsing of zip/jar archives
      --collapse-path                 Collapse single-child directory chains
      --config-file string            Read config from file (default is $HOME/.gdu.yaml)
  -D, --db string                     Store analysis in database (*.sqlite for SQLite, *.badger for BadgerDB)
      --depth int                     Show directory structure up to specified depth in non-interactive mode (0 means the flag is ignored)
      --enable-profiling              Enable collection of profiling data and provide it on http://localhost:6060/debug/pprof/
  -E, --exclude-type strings          File types to exclude (e.g., --exclude-type yaml,json)
  -L, --follow-symlinks               Follow symlinks for files, i.e. show the size of the file to which symlink points to (symlinks to directories are not followed)
  -h, --help                          help for gdu
  -i, --ignore-dirs strings           Paths to ignore (separated by comma). Can be absolute or relative to current directory (default [/proc,/dev,/sys,/run])
  -I, --ignore-dirs-pattern strings   Path patterns to ignore (separated by comma)
  -X, --ignore-from string            Read path patterns to ignore from file
  -f, --input-file string             Import analysis from JSON file
  -l, --log-file string               Path to a logfile (default "/dev/null")
      --max-age string                Include files with mtime no older than DURATION (e.g., 7d, 2h30m, 1y2mo)
  -m, --max-cores int                 Set max cores that Gdu will use. 12 cores available (default 12)
      --min-age string                Include files with mtime at least DURATION old (e.g., 30d, 1w)
      --mouse                         Use mouse
  -c, --no-color                      Do not use colorized output
  -x, --no-cross                      Do not cross filesystem boundaries
      --no-delete                     Do not allow deletions
  -H, --no-hidden                     Ignore hidden directories (beginning with dot)
      --no-prefix                     Show sizes as raw numbers without any prefixes (SI or binary) in non-interactive mode
  -p, --no-progress                   Do not show progress in non-interactive mode
      --no-spawn-shell                Do not allow spawning shell
  -u, --no-unicode                    Do not use Unicode symbols (for size bar)
  -n, --non-interactive               Do not run in interactive mode
  -o, --output-file string            Export all info into file as JSON
  -r, --read-from-storage             Use existing database instead of re-scanning
      --reverse-sort                  Reverse sorting order (smallest to largest) in non-interactive mode
      --sequential                    Use sequential scanning (intended for rotating HDDs)
  -A, --show-annexed-size             Use apparent size of git-annex'ed files in case files are not present locally (real usage is zero)
  -a, --show-apparent-size            Show apparent size
  -d, --show-disks                    Show all mounted disks
  -k, --show-in-kib                   Show sizes in KiB (or kB with --si) in non-interactive mode
  -C, --show-item-count               Show number of items in directory
  -M, --show-mtime                    Show latest mtime of items in directory
  -B, --show-relative-size            Show relative size
      --si                            Show sizes with decimal SI prefixes (kB, MB, GB) instead of binary prefixes (KiB, MiB, GiB)
      --since string                  Include files with mtime >= WHEN. WHEN accepts RFC3339 timestamp (e.g., 2025-08-11T01:00:00-07:00) or date only YYYY-MM-DD (calendar-day compare; includes the whole day)
  -s, --summarize                     Show only a total in non-interactive mode
  -t, --top int                       Show only top X largest files in non-interactive mode
  -T, --type strings                  File types to include (e.g., --type yaml,json)
      --until string                  Include files with mtime <= WHEN. WHEN accepts RFC3339 timestamp or date only YYYY-MM-DD
  -v, --version                       Print version
      --write-config                  Write current configuration to file (default is $HOME/.gdu.yaml)
"""


@dataclass
class Options:
    apparent: bool = False
    no_prefix: bool = False
    si: bool = False
    kib: bool = False
    summarize: bool = False
    no_hidden: bool = False
    reverse: bool = False
    depth: int = 0
    top: int = 0
    output_file: str | None = None
    input_file: str | None = None
    show_disks: bool = False
    non_interactive: bool = False
    ignore_dirs: list[str] = field(default_factory=lambda: ["/proc", "/dev", "/sys", "/run"])
    ignore_patterns: list[str] = field(default_factory=list)
    include_types: set[str] | None = None
    exclude_types: set[str] = field(default_factory=set)
    follow_symlinks: bool = False
    paths: list[str] = field(default_factory=list)


@dataclass
class Node:
    name: str
    path: str
    is_dir: bool
    is_link: bool = False
    notreg: bool = False
    mtime: int = 0
    asize: int = 0
    dsize: int = 0
    children: list["Node"] = field(default_factory=list)

    def size(self, apparent: bool) -> int:
        own = self.asize if apparent else self.dsize
        if self.is_dir:
            return own + sum(c.size(apparent) for c in self.children)
        return own


def expand_short(arg, argv, idx):
    opts_with_values = set("DfilmtoEITX")
    out = []
    chars = arg[1:]
    j = 0
    while j < len(chars):
        ch = chars[j]
        out.append("-" + ch)
        if ch in opts_with_values:
            rest = chars[j + 1 :]
            if rest:
                out.append(rest)
            return out, idx
        j += 1
    return out, idx


def normalize_argv(argv):
    out = []
    for i, arg in enumerate(argv):
        if arg.startswith("--") or not arg.startswith("-") or arg == "-" or len(arg) <= 2:
            out.append(arg)
        else:
            expanded, _ = expand_short(arg, argv, i)
            out.extend(expanded)
    return out


def add_csv(target, value):
    if value:
        target.extend([x for x in value.split(",") if x])


def parse_args(argv):
    opts = Options()
    argv = normalize_argv(argv)
    i = 0
    while i < len(argv):
        arg = argv[i]
        def take():
            nonlocal i
            if i + 1 >= len(argv):
                print(f"Error: flag needs an argument: {arg}", file=sys.stderr)
                sys.exit(1)
            i += 1
            return argv[i]
        if arg in ("-h", "--help"):
            print(HELP_TEXT, end="")
            sys.exit(0)
        if arg in ("-v", "--version"):
            print(VERSION_TEXT, end="")
            sys.exit(0)
        if arg in ("-n", "--non-interactive"):
            opts.non_interactive = True
        elif arg in ("-p", "--no-progress", "-c", "--no-color", "-u", "--no-unicode", "-x", "--no-cross",
                     "--no-delete", "--no-spawn-shell", "--mouse", "--sequential", "-A", "--show-annexed-size",
                     "--archive-browsing", "--collapse-path", "--enable-profiling", "-r", "--read-from-storage",
                     "-B", "--show-relative-size"):
            pass
        elif arg in ("-a", "--show-apparent-size"):
            opts.apparent = True
        elif arg == "--no-prefix":
            opts.no_prefix = True
        elif arg == "--si":
            opts.si = True
        elif arg in ("-k", "--show-in-kib"):
            opts.kib = True
        elif arg in ("-s", "--summarize"):
            opts.summarize = True
        elif arg in ("-H", "--no-hidden"):
            opts.no_hidden = True
        elif arg == "--reverse-sort":
            opts.reverse = True
        elif arg in ("-L", "--follow-symlinks"):
            opts.follow_symlinks = True
        elif arg in ("-d", "--show-disks"):
            opts.show_disks = True
        elif arg == "--depth":
            opts.depth = int(take())
        elif arg in ("-t", "--top"):
            opts.top = int(take())
        elif arg in ("-o", "--output-file"):
            opts.output_file = take()
        elif arg in ("-f", "--input-file"):
            opts.input_file = take()
        elif arg in ("-i", "--ignore-dirs"):
            opts.ignore_dirs = []
            add_csv(opts.ignore_dirs, take())
        elif arg in ("-I", "--ignore-dirs-pattern"):
            add_csv(opts.ignore_patterns, take())
        elif arg in ("-X", "--ignore-from"):
            try:
                opts.ignore_patterns.extend([ln.strip() for ln in Path(take()).read_text().splitlines() if ln.strip()])
            except OSError as e:
                print(f"Error: {e}", file=sys.stderr)
                sys.exit(1)
        elif arg in ("-T", "--type"):
            vals = set()
            add_csv_list = []
            add_csv(add_csv_list, take())
            vals.update(x.lower().lstrip(".") for x in add_csv_list)
            opts.include_types = vals
        elif arg in ("-E", "--exclude-type"):
            vals = []
            add_csv(vals, take())
            opts.exclude_types.update(x.lower().lstrip(".") for x in vals)
        elif arg in ("-D", "--db", "-l", "--log-file", "--config-file", "--max-age", "--min-age",
                     "--since", "--until", "-m", "--max-cores", "--storage", "--style"):
            take()
        elif arg == "--write-config" or arg == "-w":
            write_config()
            sys.exit(0)
        elif arg.startswith("-"):
            print(f"Error: unknown flag: {arg}", file=sys.stderr)
            sys.exit(1)
        else:
            opts.paths.append(arg)
        i += 1
    return opts


def write_config():
    target = Path.home() / ".gdu.yaml"
    target.write_text("no-color: false\n")


def should_skip(path, name, opts):
    if opts.no_hidden and name.startswith("."):
        return True
    p = os.path.abspath(path)
    for ignored in opts.ignore_dirs:
        if not ignored:
            continue
        ip = os.path.abspath(ignored) if ignored.startswith("/") else os.path.abspath(ignored)
        if p == ip or p.startswith(ip.rstrip("/") + "/"):
            return True
    for pat in opts.ignore_patterns:
        try:
            if re.search(pat, p):
                return True
        except re.error:
            if fnmatch.fnmatch(p, pat):
                return True
    ext = Path(name).suffix.lower().lstrip(".")
    if opts.include_types is not None and not os.path.isdir(path) and ext not in opts.include_types:
        return True
    if ext and ext in opts.exclude_types:
        return True
    return False


def scan(path, opts, root=False):
    try:
        st = os.stat(path) if opts.follow_symlinks and not os.path.isdir(path) else os.lstat(path)
    except OSError:
        return None
    mode = st.st_mode
    is_link = stat.S_ISLNK(mode)
    is_dir = stat.S_ISDIR(mode)
    node = Node(
        name=os.path.basename(path.rstrip(os.sep)) or path,
        path=os.path.abspath(path),
        is_dir=is_dir,
        is_link=is_link,
        notreg=not (stat.S_ISREG(mode) or is_dir),
        mtime=int(st.st_mtime),
        asize=st.st_size,
        dsize=getattr(st, "st_blocks", 0) * 512,
    )
    if is_dir:
        try:
            names = os.listdir(path)
        except OSError:
            names = []
        for name in names:
            child_path = os.path.join(path, name)
            if should_skip(child_path, name, opts):
                continue
            child = scan(child_path, opts)
            if child is not None:
                node.children.append(child)
    return node


def fmt_size(size, opts):
    if opts.no_prefix:
        return f"{size:10d}"
    if opts.si:
        if size == 0:
            return "      0 B"
        units = ["B", "kB", "MB", "GB", "TB"]
        base = 1000.0
        val = float(size)
        unit = units[0]
        for unit in units:
            if abs(val) < base or unit == units[-1]:
                break
            val /= base
        if unit == "B" and not opts.kib:
            return f"{int(size):8d} B"
        return f"{val:6.1f} {unit}"
    if size == 0 and not opts.kib:
        return "       0 B"
    if size < 1024 and not opts.kib:
        return f"{size:8d} B"
    units = ["KiB", "MiB", "GiB", "TiB"]
    val = size / 1024.0
    unit = units[0]
    for unit in units:
        if abs(val) < 1024 or unit == units[-1]:
            break
        val /= 1024.0
    return f"{val:6.1f} {unit}"


def flag_for(node):
    if node.is_link or node.notreg:
        return "@"
    if node.is_dir and len(node.children) == 0:
        return "e"
    return " "


def sorted_children(node, opts):
    def category(n):
        if n.is_link or n.notreg:
            return 2
        if n.is_dir and n.name.startswith("."):
            return 1
        return 0

    def tie_rank(n):
        if n.is_dir:
            return 0
        return 1

    def desc_key(n):
        return (category(n), -n.size(opts.apparent), tie_rank(n), n.name)

    def asc_key(n):
        return (-category(n), n.size(opts.apparent), -tie_rank(n), n.name)

    if opts.reverse:
        return sorted(node.children, key=asc_key)
    return sorted(node.children, key=desc_key)


def line_for(node, label, opts, flags=True):
    if flags:
        return f"{flag_for(node)}{fmt_size(node.size(opts.apparent), opts)} {label}"
    return f"{fmt_size(node.size(opts.apparent), opts)} {label}"


def display_name(child):
    return "/" + child.name if child.is_dir else child.name


def print_listing(root, opts):
    if opts.summarize:
        print(line_for(root, opts.paths[0] if opts.paths else root.name, opts, flags=False))
        return
    if opts.top > 0:
        leaves = []
        collect_leaves(root, leaves)
        leaves.sort(key=lambda n: n.size(opts.apparent), reverse=not opts.reverse)
        for n in leaves[: opts.top]:
            print(line_for(n, n.path, opts, flags=False))
        return
    if opts.depth > 0:
        print_depth(root, opts, 0)
        return
    for child in sorted_children(root, opts):
        print(line_for(child, display_name(child), opts))


def print_depth(node, opts, level):
    print(line_for(node, node.path, opts, flags=False))
    if level >= opts.depth:
        return
    for child in sorted_children(node, opts):
        print_depth(child, opts, level + 1)


def collect_leaves(node, out):
    if not node.is_dir:
        out.append(node)
        return
    for child in node.children:
        collect_leaves(child, out)


def node_to_json(node):
    meta = {"name": node.path if os.path.isabs(node.name) else node.name, "mtime": node.mtime}
    if node.asize:
        meta["asize"] = node.asize
    if node.dsize:
        meta["dsize"] = node.dsize
    if (node.notreg or node.is_link) and not node.is_dir:
        meta["notreg"] = True
    if node.is_dir:
        arr = [{"name": node.path, "mtime": node.mtime}] if os.path.isabs(node.path) else [meta]
        for child in node.children:
            arr.append(node_to_json(child))
        return arr
    return meta


def export_json(root, path):
    data = [1, 2, {"progname": "gdu", "progver": "dev", "timestamp": int(time.time())}, node_to_json(root)]
    Path(path).write_text(json.dumps(data, separators=(",", ":")))


def json_to_node(obj, parent_path=""):
    if isinstance(obj, list):
        meta = obj[0]
        name = meta.get("name", "")
        path = name if os.path.isabs(name) else os.path.join(parent_path, name)
        node = Node(name=os.path.basename(path.rstrip(os.sep)) or path, path=path, is_dir=True, mtime=meta.get("mtime", 0),
                    asize=meta.get("asize", 4096), dsize=meta.get("dsize", 4096))
        for child in obj[1:]:
            node.children.append(json_to_node(child, path))
        return node
    name = obj.get("name", "")
    path = name if os.path.isabs(name) else os.path.join(parent_path, name)
    return Node(
        name=os.path.basename(path),
        path=path,
        is_dir=False,
        is_link=bool(obj.get("notreg")),
        notreg=bool(obj.get("notreg")),
        mtime=obj.get("mtime", 0),
        asize=obj.get("asize", 0),
        dsize=obj.get("dsize", 0),
    )


def load_json(path):
    data = json.loads(Path(path).read_text())
    return json_to_node(data[3])


def show_disks(opts):
    print("   Device      Size      Used      Free Used% Mount point")
    seen = set()
    try:
        mounts = Path("/proc/mounts").read_text().splitlines()
    except OSError:
        mounts = []
    for line in mounts:
        parts = line.split()
        if len(parts) < 2:
            continue
        dev, mount = parts[0], parts[1]
        try:
            usage = shutil.disk_usage(mount)
        except OSError:
            continue
        key = (dev, mount)
        if key in seen:
            continue
        seen.add(key)
        used_pct = int(usage.used * 100 / usage.total) if usage.total else 0
        print(f"{dev:>9} {fmt_size(usage.total, opts):>9} {fmt_size(usage.used, opts):>9} {fmt_size(usage.free, opts):>9} {used_pct:>4}% {mount}")


def main(argv):
    opts = parse_args(argv)
    if opts.show_disks:
        show_disks(opts)
        return 0
    if opts.input_file:
        root = load_json(opts.input_file)
    else:
        path = opts.paths[0] if opts.paths else "."
        if not os.path.exists(path):
            print(f"Error: lstat {path}: no such file or directory", file=sys.stderr)
            return 1
        root = scan(path, opts, root=True)
        if root is None:
            return 1
    if opts.output_file:
        export_json(root, opts.output_file)
        return 0
    print_listing(root, opts)
    return 0


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
