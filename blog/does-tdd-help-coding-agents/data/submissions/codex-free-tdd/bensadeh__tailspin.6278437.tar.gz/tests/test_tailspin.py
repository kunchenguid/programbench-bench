import os
import subprocess
import sys
import tempfile
import unittest


ROOT = os.path.dirname(os.path.dirname(__file__))
SCRIPT = os.path.join(ROOT, "src", "tspin.py")


def run_cmd(args, input_text=None):
    return subprocess.run(
        [sys.executable, SCRIPT, *args],
        input=input_text,
        text=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
    )


class TailspinBehaviorTests(unittest.TestCase):
    def test_stdin_prints_highlighted_log_keywords_and_numbers(self):
        result = run_cmd(["--print"], "INFO user=123 true GET\n")

        self.assertEqual(result.returncode, 0)
        self.assertEqual(
            result.stdout,
            "\033[37mINFO\033[0m "
            "\033[2muser\033[0m\033[37m=\033[0m\033[36m123\033[0m "
            "\033[3;31mtrue\033[0m "
            "\033[42;30m GET \033[0m\n",
        )

    def test_disable_numbers_leaves_numeric_values_plain(self):
        result = run_cmd(["--print", "--disable", "numbers"], "user=123\n")

        self.assertEqual(result.returncode, 0)
        self.assertEqual(result.stdout, "\033[2muser\033[0m\033[37m=\033[0m123\n")

    def test_comma_separated_disable_values_are_accepted(self):
        result = run_cmd(["--print", "--disable", "numbers,urls"], "n=123 http://a/b\n")

        self.assertEqual(result.returncode, 0)
        self.assertEqual(result.stdout, "\033[2mn\033[0m\033[37m=\033[0m123 http://a/b\n")

    def test_file_input_is_read_and_highlighted(self):
        with tempfile.NamedTemporaryFile("w", delete=False) as handle:
            handle.write("ERROR fail\n")
            path = handle.name
        try:
            result = run_cmd(["--print", path])
        finally:
            os.unlink(path)

        self.assertEqual(result.returncode, 0)
        self.assertEqual(result.stdout, "\033[31mERROR\033[0m fail\n")

    def test_custom_highlight_colors_words(self):
        result = run_cmd(["--print", "--highlight", "red:fail,boom"], "fail boom ok\n")

        self.assertEqual(result.returncode, 0)
        self.assertEqual(result.stdout, "\033[31mfail\033[0m \033[31mboom\033[0m ok\n")

    def test_missing_config_path_reports_toml_error(self):
        result = run_cmd(["--config-path", "/tmp/definitely-missing-tailspin.toml", "--print"], "")

        self.assertEqual(result.returncode, 1)
        self.assertIn("could not find the TOML file", result.stderr)

    def test_json_objects_are_spaced_and_dim_punctuation(self):
        result = run_cmd(["--print"], '{"a":123,"b":true}\n')

        self.assertEqual(result.returncode, 0)
        self.assertEqual(
            result.stdout,
            "\033[2m{\033[0m \033[2m\"\033[0m\033[2ma\033[0m\033[2m\"\033[0m"
            "\033[2m:\033[0m \033[36m123\033[0m\033[2m,\033[0m "
            "\033[2m\"\033[0m\033[2mb\033[0m\033[2m\"\033[0m\033[2m:\033[0m "
            "\033[3;31mtrue\033[0m \033[2m}\033[0m\n",
        )

    def test_iso_timestamp_and_https_match_reference_colors(self):
        result = run_cmd(
            ["--print"],
            "ts=2022-09-22T07:46:34.171406833Z url=https://example.com/a\n",
        )

        self.assertEqual(result.returncode, 0)
        self.assertEqual(
            result.stdout,
            "\033[2mts\033[0m\033[37m=\033[0m"
            "\033[35m2022\033[0m\033[2m-\033[0m\033[35m09\033[0m\033[2m-\033[0m"
            "\033[35m22\033[0m\033[31mT\033[0m\033[34m07\033[0m\033[2m:\033[0m"
            "\033[34m46\033[0m\033[2m:\033[0m\033[34m34\033[0m\033[2m.\033[0m"
            "\033[34m171406833\033[0m\033[31mZ\033[0m "
            "\033[2murl\033[0m\033[37m=\033[0m"
            "\033[2;32mhttps\033[0m://\033[2;34mexample.com\033[0m\033[34m/a\033[0m\n",
        )

    def test_version_matches_documented_binary(self):
        result = run_cmd(["--version"])

        self.assertEqual(result.returncode, 0)
        self.assertEqual(result.stdout, "tspin 5.6.0\n")


if __name__ == "__main__":
    unittest.main()
