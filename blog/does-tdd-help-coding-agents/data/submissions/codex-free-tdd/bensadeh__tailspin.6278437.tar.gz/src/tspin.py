#!/usr/bin/env python3
import argparse
import json
import os
import re
import subprocess
import sys
import time


RESET = "\033[0m"
COLORS = {
    "red": "\033[31m",
    "green": "\033[32m",
    "yellow": "\033[33m",
    "blue": "\033[34m",
    "magenta": "\033[35m",
    "cyan": "\033[36m",
}
GROUPS = {
    "numbers",
    "urls",
    "pointers",
    "dates",
    "paths",
    "quotes",
    "key-value-pairs",
    "uuids",
    "ip-addresses",
    "processes",
    "json",
}


def wrap(style, text):
    return f"{style}{text}{RESET}"


def enabled_groups(args):
    groups = set(GROUPS)
    if args.enable:
        groups = set()
        for item in args.enable:
            groups.update(split_csv(item))
    if args.disable:
        for item in args.disable:
            groups.difference_update(split_csv(item))
    return groups


def split_csv(value):
    return [part for part in value.split(",") if part]


def parse_highlights(items):
    result = []
    for item in items or []:
        if ":" not in item:
            continue
        color, words = item.split(":", 1)
        style = COLORS.get(color)
        if not style:
            continue
        for word in split_csv(words):
            result.append((word, style))
    result.sort(key=lambda pair: len(pair[0]), reverse=True)
    return result


def is_boundary(line, start, end):
    before = line[start - 1] if start else " "
    after = line[end] if end < len(line) else " "
    return not (before.isalnum() or before == "_") and not (after.isalnum() or after == "_")


def color_date(text):
    out = []
    for part in re.findall(r"\d+|.", text):
        if part.isdigit():
            out.append(wrap("\033[35m", part))
        elif part in "-/":
            out.append(wrap("\033[2m", part))
        elif part in {"T", " "}:
            out.append(wrap("\033[31m", part))
        elif part == ":":
            out.append(wrap("\033[2m", part))
        else:
            out.append(part)
    return "".join(out)


def color_time(text):
    out = []
    for part in re.findall(r"\d+|.", text):
        if part.isdigit():
            out.append(wrap("\033[34m", part))
        elif part in ":,.":
            out.append(wrap("\033[2m", part))
        elif part == "Z":
            out.append(wrap("\033[31m", part))
        else:
            out.append(part)
    return "".join(out)


def color_path(text):
    pieces = []
    segment = []
    for ch in text:
        if ch in "/\\":
            if segment:
                pieces.append(wrap("\033[32m", "".join(segment)))
                segment = []
            pieces.append(wrap("\033[33m", ch))
        else:
            segment.append(ch)
    if segment:
        pieces.append(wrap("\033[32m", "".join(segment)))
    return "".join(pieces)


def color_url(text):
    match = re.match(r"([A-Za-z][A-Za-z0-9+.-]*)(://)([^/\s]+)(.*)", text)
    if not match:
        return text
    scheme, sep, host, rest = match.groups()
    scheme_style = "\033[2;32m" if scheme.lower() == "https" else "\033[2;31m"
    return wrap(scheme_style, scheme) + sep + wrap("\033[2;34m", host) + (wrap("\033[34m", rest) if rest else "")


def color_ip(text):
    return re.sub(r"\d+", lambda m: wrap("\033[3;34m", m.group(0)), text).replace(".", wrap("\033[31m", "."))


def color_uuid(text):
    out = []
    for ch in text:
        if ch == "-":
            out.append(wrap("\033[31m", ch))
        elif ch.isdigit():
            out.append(wrap("\033[3;34m", ch))
        else:
            out.append(wrap("\033[3;35m", ch))
    return "".join(out)


def apply_builtin_word(word):
    sev = {
        "TRACE": "\033[2m",
        "DEBUG": "\033[32m",
        "INFO": "\033[37m",
        "WARN": "\033[33m",
        "ERROR": "\033[31m",
    }
    rest = {
        "GET": "\033[42;30m",
        "POST": "\033[43;30m",
        "PUT": "\033[45;30m",
        "PATCH": "\033[45;30m",
        "DELETE": "\033[41;30m",
    }
    if word in sev:
        return wrap(sev[word], word)
    if word in rest:
        return wrap(rest[word], f" {word} ")
    if word in {"true", "false", "null"}:
        return wrap("\033[3;31m", word)
    return None


def highlight_line(line, groups, custom, builtin_keywords=True):
    out = []
    i = 0
    while i < len(line):
        remaining = line[i:]

        matched = False
        for word, style in custom:
            end = i + len(word)
            if line.startswith(word, i) and is_boundary(line, i, end):
                out.append(wrap(style, word))
                i = end
                matched = True
                break
        if matched:
            continue

        if "key-value-pairs" in groups:
            m = re.match(r"([A-Za-z_][A-Za-z0-9_.-]*)(=)", remaining)
            if m:
                out.append(wrap("\033[2m", m.group(1)))
                out.append(wrap("\033[37m", m.group(2)))
                i += len(m.group(0))
                continue

        if "dates" in groups:
            m = re.match(r"\d{4}[-/]\d{2}[-/]\d{2}(?:[ T]\d{2}:\d{2}:\d{2}(?:[,.]\d+)?Z?)?", remaining)
            if m:
                value = m.group(0)
                if " " in value or "T" in value:
                    sep_index = max(value.find(" "), value.find("T"))
                    out.append(color_date(value[: sep_index + 1]))
                    out.append(color_time(value[sep_index + 1 :]))
                else:
                    out.append(color_date(value))
                i += len(value)
                continue
            m = re.match(r"\d{2}:\d{2}:\d{2}(?:[,.]\d+)?", remaining)
            if m:
                out.append(color_time(m.group(0)))
                i += len(m.group(0))
                continue

        if "urls" in groups:
            m = re.match(r"[A-Za-z][A-Za-z0-9+.-]*://[^\s]+", remaining)
            if m:
                out.append(color_url(m.group(0)))
                i += len(m.group(0))
                continue

        if "quotes" in groups:
            m = re.match(r'"(?:[^"\\]|\\.)*"', remaining)
            if m:
                out.append(wrap("\033[33m", m.group(0)))
                i += len(m.group(0))
                continue

        if "paths" in groups:
            prev = line[i - 1] if i else ""
            prev2 = line[i - 2 : i] if i >= 2 else ""
            m = None if prev == ":" or prev2 == ":/" else re.match(r"(?:[A-Za-z]:)?[/\\][A-Za-z0-9._~+@%-]+(?:[/\\][A-Za-z0-9._~+@%-]+)+", remaining)
            if m:
                out.append(color_path(m.group(0)))
                i += len(m.group(0))
                continue

        if "uuids" in groups:
            m = re.match(r"[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}", remaining)
            if m:
                out.append(color_uuid(m.group(0)))
                i += len(m.group(0))
                continue

        if "ip-addresses" in groups:
            m = re.match(r"\d{1,3}(?:\.\d{1,3}){3}", remaining)
            if m:
                out.append(color_ip(m.group(0)))
                i += len(m.group(0))
                continue

        word_match = re.match(r"[A-Za-z_][A-Za-z0-9_]*", remaining)
        if word_match:
            word = word_match.group(0)
            colored = apply_builtin_word(word) if builtin_keywords else None
            if colored is not None:
                out.append(colored)
                i += len(word)
                continue

        if "numbers" in groups:
            m = re.match(r"\d+(?:\.\d+)?", remaining)
            if m:
                out.append(wrap("\033[36m", m.group(0)))
                i += len(m.group(0))
                continue

        out.append(line[i])
        i += 1
    return "".join(out)


def highlight_text(text, groups, custom, builtin_keywords=True):
    return "".join(highlight_record(line, groups, custom, builtin_keywords) for line in text.splitlines(True))


def highlight_record(record, groups, custom, builtin_keywords=True):
    newline = "\n" if record.endswith("\n") else ""
    body = record[:-1] if newline else record
    stripped = body.strip()
    if "json" in groups and stripped and stripped[0] in "[{":
        try:
            normalized = json.dumps(json.loads(stripped), ensure_ascii=False, separators=(", ", ": "))
        except Exception:
            pass
        else:
            normalized = re.sub(r"^([{\[])", r"\1 ", normalized)
            normalized = re.sub(r"([}\]])$", r" \1", normalized)
            return color_json(normalized, groups, custom, builtin_keywords) + newline
    return highlight_line(record, groups, custom, builtin_keywords)


def color_json(text, groups, custom, builtin_keywords):
    out = []
    i = 0
    while i < len(text):
        ch = text[i]
        if ch in "{}[]:,":
            out.append(wrap("\033[2m", ch))
            i += 1
            continue
        if ch == '"':
            end = i + 1
            escaped = False
            while end < len(text):
                if text[end] == '"' and not escaped:
                    end += 1
                    break
                escaped = text[end] == "\\" and not escaped
                if text[end] != "\\":
                    escaped = False
                end += 1
            out.append("".join(wrap("\033[2m", c) for c in text[i:end]))
            i = end
            continue
        m = re.match(r"-?\d+(?:\.\d+)?(?:[eE][+-]?\d+)?", text[i:])
        if m and "numbers" in groups:
            out.append(wrap("\033[36m", m.group(0)))
            i += len(m.group(0))
            continue
        m = re.match(r"[A-Za-z_][A-Za-z0-9_]*", text[i:])
        if m:
            word = m.group(0)
            colored = apply_builtin_word(word) if builtin_keywords else None
            out.append(colored if colored is not None else word)
            i += len(word)
            continue
        out.append(ch)
        i += 1
    return "".join(out)


def read_follow(path, groups, custom, builtin_keywords):
    with open(path, "r", encoding="utf-8", errors="replace") as handle:
        while True:
            chunk = handle.read()
            if chunk:
                sys.stdout.write(highlight_text(chunk, groups, custom, builtin_keywords))
                sys.stdout.flush()
            time.sleep(0.2)


class Parser(argparse.ArgumentParser):
    def error(self, message):
        sys.stderr.write(f"error: {message}\n\n")
        self.print_usage(sys.stderr)
        sys.stderr.write("\nFor more information, try '--help'.\n")
        raise SystemExit(2)


def build_parser():
    parser = Parser(
        prog="executable",
        description="A log file highlighter",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        add_help=False,
    )
    parser.add_argument("file", nargs="?", metavar="FILE", help="Filepath")
    parser.add_argument("-f", "--follow", action="store_true", help="Follow the contents of a file")
    parser.add_argument("-p", "--print", action="store_true", dest="print_output", help="Print the output to stdout")
    parser.add_argument("--config-path", help="Provide a custom path to a configuration file")
    parser.add_argument("-e", "--exec", dest="exec_cmd", help="Run command and view the output in a pager")
    parser.add_argument("--highlight", action="append", default=[], metavar="COLOR_WORD", help="Highlights in the form color:word1,word2")
    parser.add_argument("--enable", action="append", metavar="ENABLED_HIGHLIGHTERS", help="Enable specific highlighters")
    parser.add_argument("--disable", action="append", metavar="DISABLED_HIGHLIGHTERS", help="Disable specific highlighters")
    parser.add_argument("--disable-builtin-keywords", action="store_true", help="Disable the highlighting of all builtin keyword groups")
    parser.add_argument("--pager", help="Override the default pager command used by tspin. (e.g. `--pager=\"ov -f [FILE]\"`)")
    parser.add_argument("-h", "--help", action="store_true")
    parser.add_argument("-V", "--version", action="store_true")
    return parser


def print_help():
    sys.stdout.write(
        """A log file highlighter

Usage: executable [OPTIONS] [FILE]

Arguments:
  [FILE]
          Filepath

Options:
  -f, --follow
          Follow the contents of a file

  -p, --print
          Print the output to stdout

      --config-path <CONFIG_PATH>
          Provide a custom path to a configuration file

  -e, --exec <EXEC>
          Run command and view the output in a pager

      --highlight <COLOR_WORD>
          Highlights in the form color:word1,word2
          
          [possible values: red, green, yellow, blue, magenta, cyan]

      --enable <ENABLED_HIGHLIGHTERS>
          Enable specific highlighters
          
          [possible values: numbers, urls, pointers, dates, paths, quotes, key-value-pairs, uuids,
          ip-addresses, processes, json]

      --disable <DISABLED_HIGHLIGHTERS>
          Disable specific highlighters
          
          [possible values: numbers, urls, pointers, dates, paths, quotes, key-value-pairs, uuids,
          ip-addresses, processes, json]

      --disable-builtin-keywords
          Disable the highlighting of all builtin keyword groups (booleans, nulls, log severities
          and common REST verbs)

      --pager <PAGER>
          Override the default pager command used by tspin. (e.g. `--pager="ov -f [FILE]"`)
          
          [env: TAILSPIN_PAGER=]

  -h, --help
          Print help (see a summary with '-h')

  -V, --version
          Print version
"""
    )


def main(argv=None):
    parser = build_parser()
    args, unknown = parser.parse_known_args(argv)
    if unknown:
        parser.error(f"unexpected argument '{unknown[0]}' found")
    if args.help:
        print_help()
        return 0
    if args.version:
        sys.stdout.write("tspin 5.6.0\n")
        return 0
    if args.enable and args.disable:
        sys.stderr.write("error: the argument '--enable <ENABLED_HIGHLIGHTERS>' cannot be used with '--disable <DISABLED_HIGHLIGHTERS>'\n")
        return 2
    for flag_name, values in (("--enable", args.enable), ("--disable", args.disable)):
        for value in values or []:
            for item in split_csv(value):
                if item not in GROUPS:
                    sys.stderr.write(
                        f"error: invalid value '{item}' for '{flag_name} <HIGHLIGHTERS>'\n"
                        "  [possible values: numbers, urls, pointers, dates, paths, quotes, key-value-pairs, uuids, ip-addresses, processes, json]\n\n"
                        "For more information, try '--help'.\n"
                    )
                    return 2
    if args.config_path and not os.path.exists(args.config_path):
        sys.stderr.write("Error:   × could not find the TOML file\n\n")
        return 1

    groups = enabled_groups(args)
    custom = parse_highlights(args.highlight)
    builtin_keywords = not args.disable_builtin_keywords

    try:
        if args.exec_cmd:
            completed = subprocess.run(args.exec_cmd, shell=True, text=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
            sys.stdout.write(highlight_text(completed.stdout, groups, custom, builtin_keywords))
            return completed.returncode
        if args.file:
            if args.follow:
                read_follow(args.file, groups, custom, builtin_keywords)
                return 0
            with open(args.file, "r", encoding="utf-8", errors="replace") as handle:
                text = handle.read()
        else:
            text = sys.stdin.read()
        sys.stdout.write(highlight_text(text, groups, custom, builtin_keywords))
        return 0
    except FileNotFoundError:
        sys.stderr.write(f"Error:   ⚠ \033[33m{args.file}\033[0m: No such file or directory\n\n")
        return 1
    except KeyboardInterrupt:
        return 130


if __name__ == "__main__":
    raise SystemExit(main())
