import json
import os
import subprocess
import sys
import tempfile
import threading
import unittest
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer


ROOT = os.path.dirname(os.path.dirname(__file__))
EXE = [sys.executable, os.path.join(ROOT, "src", "oha.py")]


class SeenHandler(BaseHTTPRequestHandler):
    seen = []

    def do_GET(self):
        self._reply()

    def do_POST(self):
        self._reply()

    def _reply(self):
        body = self.rfile.read(int(self.headers.get("Content-Length", "0") or "0"))
        SeenHandler.seen.append((self.command, self.path, dict(self.headers), body))
        if self.path == "/redir":
            self.send_response(302)
            self.send_header("Location", "/ok")
            self.end_headers()
            return
        if self.path == "/missing":
            data = b"nope"
            self.send_response(404)
        else:
            data = b"hello world"
            self.send_response(200)
        self.send_header("Content-Type", "text/plain")
        self.send_header("Content-Length", str(len(data)))
        self.end_headers()
        self.wfile.write(data)

    def log_message(self, *args):
        pass


class OhaTest(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        SeenHandler.seen = []
        cls.server = ThreadingHTTPServer(("127.0.0.1", 0), SeenHandler)
        cls.thread = threading.Thread(target=cls.server.serve_forever, daemon=True)
        cls.thread.start()
        cls.base = f"http://127.0.0.1:{cls.server.server_port}"

    @classmethod
    def tearDownClass(cls):
        cls.server.shutdown()

    def run_oha(self, *args):
        return subprocess.run(EXE + list(args), text=True, capture_output=True)

    def test_version_prints_oha_version(self):
        res = self.run_oha("--version")
        self.assertEqual(res.returncode, 0)
        self.assertEqual(res.stdout, "oha 1.12.1\n")

    def test_missing_url_prints_help_and_fails_like_clap(self):
        res = self.run_oha()
        self.assertEqual(res.returncode, 2)
        self.assertIn("Ohayou(", res.stdout)
        self.assertIn("Usage: executable [OPTIONS] <URL>", res.stdout)

    def test_dump_urls_repeats_plain_url_without_requests(self):
        res = self.run_oha("--dump-urls", "3", self.base + "/ok")
        self.assertEqual(res.returncode, 0)
        self.assertEqual(res.stdout, (self.base + "/ok\n") * 3)

    def test_text_output_summarizes_successful_requests(self):
        SeenHandler.seen.clear()
        res = self.run_oha("--no-tui", "-n", "3", "-c", "1", self.base + "/ok")
        self.assertEqual(res.returncode, 0, res.stderr)
        self.assertIn("Summary:\n", res.stdout)
        self.assertIn("Success rate:\t100.00%", res.stdout)
        self.assertIn("Total data:\t33 B", res.stdout)
        self.assertIn("[200] 3 responses", res.stdout)
        self.assertEqual(len(SeenHandler.seen), 3)

    def test_json_output_has_reference_schema_keys(self):
        res = self.run_oha("--no-tui", "-n", "2", "-c", "1", "--output-format", "json", self.base + "/ok")
        self.assertEqual(res.returncode, 0, res.stderr)
        payload = json.loads(res.stdout)
        self.assertEqual(payload["summary"]["successRate"], 1.0)
        self.assertEqual(payload["summary"]["totalData"], 22)
        self.assertEqual(payload["statusCodeDistribution"], {"200": 2})
        self.assertIn("responseTimeHistogram", payload)
        self.assertIn("latencyPercentiles", payload)

    def test_csv_output_prints_header_and_one_line_per_request(self):
        res = self.run_oha("--no-tui", "-n", "2", "-c", "1", "--output-format", "csv", self.base + "/ok")
        self.assertEqual(res.returncode, 0, res.stderr)
        lines = res.stdout.strip().splitlines()
        self.assertEqual(lines[0], "request-start,DNS,DNS+dialup,Response-delay,request-duration,bytes,status")
        self.assertEqual(len(lines), 3)
        self.assertTrue(lines[1].endswith(",11,200"))

    def test_method_headers_and_body_are_sent(self):
        SeenHandler.seen.clear()
        res = self.run_oha("--no-tui", "-n", "1", "-m", "POST", "-H", "Foo: bar", "-A", "text/html", "-d", "abc", "-T", "text/custom", self.base + "/ok")
        self.assertEqual(res.returncode, 0, res.stderr)
        method, path, headers, body = SeenHandler.seen[-1]
        self.assertEqual(method, "POST")
        self.assertEqual(path, "/ok")
        self.assertEqual(body, b"abc")
        self.assertEqual(headers.get("foo") or headers.get("Foo"), "bar")
        self.assertEqual(headers.get("content-type") or headers.get("Content-Type"), "text/custom")
        self.assertEqual(headers.get("accept") or headers.get("Accept"), "text/html")

    def test_output_file_receives_summary(self):
        fd, path = tempfile.mkstemp()
        os.close(fd)
        try:
            res = self.run_oha("--no-tui", "-n", "1", "-o", path, self.base + "/ok")
            self.assertEqual(res.returncode, 0, res.stderr)
            self.assertEqual(res.stdout, "")
            with open(path) as f:
                self.assertIn("Summary:", f.read())
        finally:
            os.unlink(path)

    def test_quiet_output_sends_requests_without_printing(self):
        SeenHandler.seen.clear()
        res = self.run_oha("--no-tui", "-n", "1", "--output-format", "quiet", self.base + "/ok")
        self.assertEqual(res.returncode, 0, res.stderr)
        self.assertEqual(res.stdout, "")
        self.assertEqual(res.stderr, "")
        self.assertEqual(len(SeenHandler.seen), 1)

    def test_redirect_limit_zero_counts_redirect_status(self):
        res = self.run_oha("--no-tui", "-n", "1", "-r", "0", self.base + "/redir")
        self.assertEqual(res.returncode, 0, res.stderr)
        self.assertIn("[302] 1 responses", res.stdout)

    def test_urls_from_file_chooses_urls_from_file(self):
        SeenHandler.seen.clear()
        fd, path = tempfile.mkstemp()
        os.close(fd)
        try:
            with open(path, "w") as f:
                f.write(self.base + "/ok\n" + self.base + "/missing\n")
            res = self.run_oha("--no-tui", "--urls-from-file", "-n", "4", path)
            self.assertEqual(res.returncode, 0, res.stderr)
            self.assertEqual(len(SeenHandler.seen), 4)
            self.assertTrue(all(item[1] in ("/ok", "/missing") for item in SeenHandler.seen))
        finally:
            os.unlink(path)

    def test_basic_auth_sets_authorization_header(self):
        SeenHandler.seen.clear()
        res = self.run_oha("--no-tui", "-n", "1", "-a", "user:pass", self.base + "/ok")
        self.assertEqual(res.returncode, 0, res.stderr)
        headers = SeenHandler.seen[-1][2]
        self.assertEqual(headers.get("authorization") or headers.get("Authorization"), "Basic dXNlcjpwYXNz")

    def test_invalid_url_exits_with_error_message(self):
        res = self.run_oha("--no-tui", "-n", "1", "not-a-url")
        self.assertEqual(res.returncode, 1)
        self.assertEqual(res.stderr, "Error: relative URL without a base\n")


if __name__ == "__main__":
    unittest.main()
