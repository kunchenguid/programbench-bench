#!/usr/bin/env python3
import json
import math
import os
import random
import socket
import ssl
import sys
import time
import base64
from concurrent.futures import ThreadPoolExecutor, as_completed
from urllib.parse import urljoin, urlparse


VERSION = "oha 1.12.1"
UA = "oha/1.12.1"
HELP = """Ohayou(おはよう), HTTP load generator, inspired by rakyll/hey with tui animation.

Usage: executable [OPTIONS] <URL>

Arguments:
  <URL>  Target URL or file with multiple URLs.

Options:
  -n <N_REQUESTS>
          Number of requests to run. Accepts plain numbers or suffixes: k = 1,000, m = 1,000,000 (e.g. 10k, 1m). [default: 200]
  -c <N_CONNECTIONS>
          Number of connections to run concurrently. You may should increase limit to number of open files for larger `-c`. [default: 50]
  -p <N_HTTP2_PARALLEL>
          Number of parallel requests to send on HTTP/2. `oha` will run c * p concurrent workers in total. [default: 1]
  -z <DURATION>
          Duration of application to send requests.
          Examples: -z 10s -z 3m.
  -w, --wait-ongoing-requests-after-deadline
          When the duration is reached, ongoing requests are waited
  -q <QUERY_PER_SECOND>
          Rate limit for all, in queries per second (QPS)
      --burst-delay <BURST_DURATION>
          Introduce delay between a predefined number of requests.
      --burst-rate <BURST_REQUESTS>
          Rates of requests for burst. Default is 1
      --rand-regex-url
          Generate URL by rand_regex crate but dot is disabled for each query.
      --urls-from-file
          Read the URLs to query from a file
      --max-repeat <MAX_REPEAT>
          A parameter for the '--rand-regex-url'. [default: 4]
      --dump-urls <DUMP_URLS>
          Dump target Urls <DUMP_URLS> times to debug --rand-regex-url
      --latency-correction
          Correct latency to avoid coordinated omission problem. It's ignored if -q is not set.
      --no-tui
          No realtime tui
      --fps <FPS>
          Frame per second for tui. [default: 16]
  -m, --method <METHOD>
          HTTP method [default: GET]
  -H <HEADERS>
          Custom HTTP header. Examples: -H "foo: bar"
      --proxy-header <PROXY_HEADERS>
          Custom Proxy HTTP header. Examples: --proxy-header "foo: bar"
  -t <TIMEOUT>
          Timeout for each request. Default to infinite.
      --connect-timeout <CONNECT_TIMEOUT>
          Timeout for establishing a new connection. Default to 5s. [default: 5s]
  -A <ACCEPT_HEADER>
          HTTP Accept Header.
  -d <BODY_STRING>
          HTTP request body.
  -D <BODY_PATH>
          HTTP request body from file.
  -Z <BODY_PATH_LINES>
          HTTP request body from file line by line.
  -F, --form <FORM>
          Specify HTTP multipart POST data (curl compatible).
  -T <CONTENT_TYPE>
          Content-Type.
  -a <BASIC_AUTH>
          Basic authentication (username:password), or AWS credentials (access_key:secret_key)
      --debug
          Perform a single request and dump the request and response
  -o, --output <OUTPUT>
          Output file to write the results to. If not specified, results are written to stdout.
      --output-format <OUTPUT_FORMAT>
          Output format [default: text] [possible values: text, json, csv, quiet]
  -u, --time-unit <TIME_UNIT>
          Time unit to be used. [possible values: ns, us, ms, s, m, h]
  -h, --help
          Print help
  -V, --version
          Print version
"""


class Options:
    def __init__(self):
        self.n = 200
        self.c = 50
        self.method = "GET"
        self.headers = []
        self.accept = None
        self.body = b""
        self.content_type = None
        self.output_format = "text"
        self.output = None
        self.timeout = None
        self.connect_timeout = 5.0
        self.redirect = 10
        self.basic_auth = None
        self.dump_urls = 0
        self.rand_regex_url = False
        self.urls_from_file = False
        self.debug = False
        self.no_tui = False
        self.time_unit = None
        self.url = None


def parse_count(s):
    mult = 1
    raw = s
    if s.lower().endswith("k"):
        mult = 1000
        s = s[:-1]
    elif s.lower().endswith("m"):
        mult = 1000000
        s = s[:-1]
    return int(s) * mult


def parse_duration(s):
    units = {"ns": 1e-9, "us": 1e-6, "ms": 1e-3, "s": 1, "m": 60, "h": 3600}
    for unit in ("ms", "ns", "us", "s", "m", "h"):
        if s.endswith(unit):
            return float(s[:-len(unit)]) * units[unit]
    return float(s)


def clap_error(message):
    sys.stderr.write(f"error: {message}\n\nFor more information, try '--help'.\n")
    return 2


def parse_args(argv):
    opts = Options()
    i = 0
    while i < len(argv):
        a = argv[i]
        def value():
            nonlocal i
            if i + 1 >= len(argv):
                raise ValueError(f"a value is required for '{a}'")
            i += 1
            return argv[i]
        try:
            if a in ("-h", "--help"):
                print(HELP, end="")
                raise SystemExit(0)
            if a in ("-V", "--version"):
                print(VERSION)
                raise SystemExit(0)
            elif a == "-n":
                v = value()
                try:
                    opts.n = parse_count(v)
                except Exception as e:
                    raise ValueError(f"invalid value '{v}' for '-n <N_REQUESTS>': {e}")
            elif a == "-c":
                opts.c = int(value())
            elif a == "-p":
                value()
            elif a == "-z":
                opts.duration = parse_duration(value())
            elif a in ("-w", "--wait-ongoing-requests-after-deadline", "--latency-correction",
                       "--disable-compression", "--disable-keepalive", "--no-pre-lookup",
                       "--ipv6", "--ipv4", "--insecure", "--stats-success-breakdown",
                       "--proxy-http2", "--http2", "--no-color"):
                pass
            elif a == "--no-tui":
                opts.no_tui = True
            elif a == "--rand-regex-url":
                opts.rand_regex_url = True
            elif a == "--urls-from-file":
                opts.urls_from_file = True
            elif a == "--debug":
                opts.debug = True
            elif a == "--dump-urls":
                opts.dump_urls = int(value())
            elif a in ("--max-repeat", "--fps", "-q", "--burst-delay", "--burst-rate",
                       "-t", "--connect-timeout", "-x", "--proxy-http-version",
                       "--http-version", "--host", "-r", "--redirect", "--cacert",
                       "--cert", "--key", "--connect-to", "--unix-socket", "--db-url",
                       "--aws-session", "--aws-sigv4"):
                v = value()
                if a in ("-t",):
                    opts.timeout = parse_duration(v)
                elif a == "--connect-timeout":
                    opts.connect_timeout = parse_duration(v)
                elif a in ("-r", "--redirect"):
                    opts.redirect = int(v)
            elif a == "-a":
                opts.basic_auth = value()
            elif a in ("-m", "--method"):
                opts.method = value().upper()
            elif a == "-H":
                opts.headers.append(value())
            elif a == "--proxy-header":
                value()
            elif a == "-A":
                opts.accept = value()
            elif a == "-d":
                opts.body = value().encode()
            elif a == "-D":
                with open(value(), "rb") as f:
                    opts.body = f.read()
            elif a == "-Z":
                with open(value(), "rb") as f:
                    opts.body_lines = f.read().splitlines()
            elif a in ("-F", "--form"):
                opts.headers.append("Content-Type: multipart/form-data")
                opts.body = value().encode()
                opts.method = "POST"
            elif a == "-T":
                opts.content_type = value()
            elif a in ("-o", "--output"):
                opts.output = value()
            elif a == "--output-format":
                opts.output_format = value()
                if opts.output_format not in ("text", "json", "csv", "quiet"):
                    raise ValueError(f"invalid value '{opts.output_format}' for '--output-format <OUTPUT_FORMAT>'\n  [possible values: text, json, csv, quiet]")
            elif a in ("-u", "--time-unit"):
                opts.time_unit = value()
            elif a.startswith("-"):
                sys.stderr.write(f"error: unexpected argument '{a}' found\n\n  tip: to pass '{a}' as a value, use '-- {a}'\n\nUsage: executable [OPTIONS] <URL>\n\nFor more information, try '--help'.\n")
                raise SystemExit(2)
            else:
                if opts.url is not None:
                    raise ValueError(f"unexpected argument '{a}' found")
                opts.url = a
        except ValueError as e:
            raise ValueError(str(e))
        i += 1
    if opts.url is None:
        print(HELP, end="")
        raise SystemExit(2)
    return opts


def expand_regex_url(pattern):
    out = []
    i = 0
    while i < len(pattern):
        if pattern[i] == "[":
            j = pattern.find("]", i)
            if j > i:
                spec = pattern[i + 1:j]
                choices = []
                k = 0
                while k < len(spec):
                    if k + 2 < len(spec) and spec[k + 1] == "-":
                        choices += [chr(c) for c in range(ord(spec[k]), ord(spec[k + 2]) + 1)]
                        k += 3
                    else:
                        choices.append(spec[k])
                        k += 1
                out.append(random.choice(choices or [""]))
                i = j + 1
                continue
        out.append(pattern[i])
        i += 1
    return "".join(out)


def choose_url(opts):
    if opts.urls_from_file:
        with open(opts.url) as f:
            urls = [line.strip() for line in f if line.strip()]
        return random.choice(urls)
    if opts.rand_regex_url:
        return expand_regex_url(opts.url)
    return opts.url


def format_bytes(n):
    if isinstance(n, float) and math.isnan(n):
        return "NaN"
    units = ["B", "KiB", "MiB", "GiB"]
    x = float(n)
    unit = units[0]
    for unit in units:
        if abs(x) < 1024 or unit == units[-1]:
            break
        x /= 1024
    if unit == "B":
        return f"{int(x)} B"
    return f"{x:.2f} {unit}"


def unit_scale(seconds, forced=None):
    if forced:
        table = {"ns": (1e9, "ns"), "us": (1e6, "us"), "ms": (1e3, "ms"), "s": (1, "s"), "m": (1/60, "m"), "h": (1/3600, "h")}
        return table.get(forced, (1000, "ms"))
    if seconds < 1e-6:
        return 1e9, "ns"
    if seconds < 1e-3:
        return 1e6, "us"
    if seconds < 1:
        return 1e3, "ms"
    return 1, "s"


def pct(values, p):
    if not values:
        return float("nan")
    values = sorted(values)
    idx = int(math.ceil((p / 100) * len(values))) - 1
    return values[max(0, min(len(values) - 1, idx))]


def request_once(opts, url):
    start = time.perf_counter()
    parsed = urlparse(url)
    if not parsed.scheme or not parsed.netloc:
        raise RuntimeError("relative URL without a base")
    if parsed.scheme not in ("http", "https"):
        raise RuntimeError("proto error: unsupported scheme")
    port = parsed.port or (443 if parsed.scheme == "https" else 80)
    host = parsed.hostname or ""
    path = parsed.path or "/"
    if parsed.query:
        path += "?" + parsed.query
    dns_start = time.perf_counter()
    addr = socket.getaddrinfo(host, port, type=socket.SOCK_STREAM)[0][4]
    dns_done = time.perf_counter()
    sock = socket.create_connection(addr, timeout=opts.connect_timeout)
    if parsed.scheme == "https":
        sock = ssl.create_default_context().wrap_socket(sock, server_hostname=host)
    dial_done = time.perf_counter()
    body = opts.body
    headers = {
        "accept": opts.accept or "*/*",
        "accept-encoding": "gzip, compress, deflate, br",
        "user-agent": UA,
    }
    if opts.content_type:
        headers["content-type"] = opts.content_type
    if opts.basic_auth:
        token = base64.b64encode(opts.basic_auth.encode()).decode()
        headers["authorization"] = f"Basic {token}"
    for h in opts.headers:
        if ":" in h:
            k, v = h.split(":", 1)
            headers[k.strip().lower()] = v.strip()
    headers["host"] = parsed.netloc
    if body:
        headers["content-length"] = str(len(body))
    lines = [f"{opts.method} {path} HTTP/1.1"] + [f"{k}: {v}" for k, v in headers.items()] + ["", ""]
    raw_req = "\r\n".join(lines).encode() + body
    sock.sendall(raw_req)
    if opts.timeout:
        sock.settimeout(opts.timeout)
    data = b""
    first = None
    while True:
        try:
            chunk = sock.recv(65536)
        except socket.timeout:
            break
        if first is None:
            first = time.perf_counter()
        if not chunk:
            break
        data += chunk
    sock.close()
    end = time.perf_counter()
    head, _, resp_body = data.partition(b"\r\n\r\n")
    lines = head.decode("latin1", "replace").splitlines()
    status = 0
    version = "HTTP/1.1"
    resp_headers = {}
    if lines:
        parts = lines[0].split()
        version = parts[0] if parts else version
        if len(parts) > 1 and parts[1].isdigit():
            status = int(parts[1])
    for line in lines[1:]:
        if ":" in line:
            k, v = line.split(":", 1)
            resp_headers[k.lower()] = v.strip()
    if 300 <= status < 400 and opts.redirect > 0 and "location" in resp_headers:
        opts.redirect -= 1
        return request_once(opts, urljoin(url, resp_headers["location"]))
    return {
        "start": start, "duration": end - start, "dns": dns_done - dns_start,
        "dial": dial_done - dns_start, "delay": (first or end) - start,
        "bytes": len(resp_body), "status": status, "error": None,
        "request": (opts.method, path, headers, body),
        "response": (status, version, resp_headers, resp_body),
    }


def safe_request(opts, url):
    try:
        return request_once(opts, url)
    except Exception as e:
        now = time.perf_counter()
        return {"start": now, "duration": 0.0, "dns": 0.0, "dial": 0.0, "delay": 0.0, "bytes": 0, "status": 0, "error": str(e)}


def run_requests(opts):
    if opts.debug:
        r = request_once(opts, choose_url(opts))
        print_debug(r)
        return []
    n = max(0, opts.n)
    workers = max(1, min(opts.c, n or 1))
    urls = [choose_url(opts) for _ in range(n)]
    results = []
    with ThreadPoolExecutor(max_workers=workers) as pool:
        futures = [pool.submit(safe_request, opts, u) for u in urls]
        for f in as_completed(futures):
            results.append(f.result())
    results.sort(key=lambda r: r["start"])
    return results


def print_debug(r):
    method, path, headers, body = r["request"]
    print("Request {")
    print(f"    method: {method},")
    print(f"    uri: {path},")
    print("    version: HTTP/1.1,")
    print("    headers: {")
    for k, v in headers.items():
        if k != "content-length":
            print(f'        "{k}": "{v}",')
    print("    },")
    print("    body: Full {")
    print("        data: Some(")
    print(f'            b"{body.decode("latin1", "replace")}",')
    print("        ),")
    print("    },")
    print("}")
    status, version, headers, body = r["response"]
    print("Response {")
    print(f"    status: {status},")
    print(f"    version: {version},")
    print("    headers: {")
    for k, v in headers.items():
        print(f'        "{k}": "{v}",')
    print("    },")
    print(f'    body: b"{body.decode("latin1", "replace")}",')
    print("}")


def summarize(results):
    good = [r for r in results if not r["error"]]
    durs = [r["duration"] for r in good]
    total = (max([r["start"] + r["duration"] for r in results]) - min([r["start"] for r in results])) if results else 0.0
    total_data = sum(r["bytes"] for r in good)
    status = {}
    errors = {}
    for r in results:
        if r["error"]:
            errors[r["error"]] = errors.get(r["error"], 0) + 1
        elif r["status"]:
            status[str(r["status"])] = status.get(str(r["status"]), 0) + 1
    avg = sum(durs) / len(durs) if durs else float("nan")
    return {
        "summary": {
            "successRate": (len(good) / len(results)) if results else 0.0,
            "total": total,
            "slowest": max(durs) if durs else float("-inf"),
            "fastest": min(durs) if durs else float("inf"),
            "average": avg,
            "requestsPerSec": (len(results) / total) if total > 0 else 0.0,
            "totalData": total_data,
            "sizePerRequest": (total_data / len(good)) if good else float("nan"),
            "sizePerSec": (total_data / total) if total > 0 else 0.0,
        },
        "statusCodeDistribution": status,
        "errorDistribution": errors,
        "durations": durs,
        "details": {
            "DNSDialup": stat([r["dial"] for r in good]),
            "DNSLookup": stat([r["dns"] for r in good]),
        },
    }


def stat(vals):
    return {
        "average": sum(vals) / len(vals) if vals else float("nan"),
        "fastest": min(vals) if vals else float("inf"),
        "slowest": max(vals) if vals else float("-inf"),
    }


def json_summary(s):
    durs = s["durations"]
    hist = {}
    if durs:
        lo, hi = min(durs), max(durs)
        step = (hi - lo) / 10 if hi != lo else 0
        for i in range(11):
            key = lo + step * i
            hist[str(key)] = 0
        keys = list(hist.keys())
        for d in durs:
            idx = 10 if (hi == lo) else min(10, int((d - lo) / step))
            hist[keys[idx]] += 1
    percentiles = {f"p{p:g}": pct(durs, p) for p in (10, 25, 50, 75, 90, 95, 99, 99.9, 99.99)}
    return json.dumps({
        "summary": s["summary"],
        "responseTimeHistogram": hist,
        "latencyPercentiles": percentiles,
        "rps": {"mean": s["summary"]["requestsPerSec"], "stddev": 0.0, "max": s["summary"]["requestsPerSec"], "min": s["summary"]["requestsPerSec"], "percentiles": percentiles},
        "details": s["details"],
        "statusCodeDistribution": s["statusCodeDistribution"],
        "errorDistribution": s["errorDistribution"],
    }, indent=2, allow_nan=True) + "\n"


def text_summary(s, forced_unit=None):
    summ = s["summary"]
    scale, unit = unit_scale(summ["average"] if math.isfinite(summ["average"]) else summ["total"], forced_unit)
    def ft(x, places=4):
        if math.isnan(x):
            return f"NaN {unit}"
        if x == float("inf"):
            return f"inf {unit}"
        if x == float("-inf"):
            return f"-inf {unit}"
        return f"{x * scale:.{places}f} {unit}"
    lines = [
        "Summary:",
        f"  Success rate:\t{summ['successRate']*100:.2f}%",
        f"  Total:\t{ft(summ['total'])}",
        f"  Slowest:\t{ft(summ['slowest'])}",
        f"  Fastest:\t{ft(summ['fastest'])}",
        f"  Average:\t{ft(summ['average'])}",
        f"  Requests/sec:\t{summ['requestsPerSec']:.4f}",
        "",
        f"  Total data:\t{format_bytes(summ['totalData'])}",
        f"  Size/request:\t{format_bytes(summ['sizePerRequest'])}",
        f"  Size/sec:\t{format_bytes(summ['sizePerSec'])}",
        "",
        "Response time histogram:",
    ]
    durs = s["durations"]
    if durs:
        lo, hi = min(durs), max(durs)
        step = (hi - lo) / 10 if hi != lo else 0
        counts = [0] * 11
        for d in durs:
            idx = 10 if step and d == hi else (int((d - lo) / step) if step else 0)
            counts[max(0, min(10, idx))] += 1
        mx = max(counts) or 1
        for i, c in enumerate(counts):
            val = lo + step * i
            bars = "■" * int(32 * c / mx) if c else ""
            lines.append(f"  {val*scale:7.3f} {unit} [{c}] |{bars}")
    else:
        for _ in range(11):
            lines.append(f"    NaN {unit} [0] |")
    lines += ["", "Response time distribution:"]
    for p in (10, 25, 50, 75, 90, 95, 99, 99.9, 99.99):
        lines.append(f"  {p:.2f}% in {ft(pct(durs, p))}")
    lines += ["", "", "Details (average, fastest, slowest):"]
    for label, key in (("DNS+dialup", "DNSDialup"), ("DNS-lookup", "DNSLookup")):
        st = s["details"][key]
        lines.append(f"  {label}:\t{ft(st['average'])}, {ft(st['fastest'])}, {ft(st['slowest'])}")
    lines += ["", "Status code distribution:"]
    for code, count in sorted(s["statusCodeDistribution"].items()):
        lines.append(f"  [{code}] {count} responses")
    if s["errorDistribution"]:
        lines += ["", "Error distribution:"]
        for err, count in sorted(s["errorDistribution"].items()):
            lines.append(f"  [{count}] {err}")
    return "\n".join(lines) + "\n"


def csv_output(results):
    lines = ["request-start,DNS,DNS+dialup,Response-delay,request-duration,bytes,status"]
    base = min([r["start"] for r in results], default=time.perf_counter())
    for r in results:
        lines.append(f"{r['start']-base:.9f},{r['dns']:.9f},{r['dial']:.9f},{r['delay']:.9f},{r['duration']:.9f},{r['bytes']},{r['status'] or ''}")
    return "\n".join(lines) + "\n"


def main(argv):
    try:
        opts = parse_args(argv)
    except SystemExit as e:
        return int(e.code)
    except ValueError as e:
        return clap_error(str(e))
    if opts.dump_urls:
        for _ in range(opts.dump_urls):
            print(choose_url(opts))
        return 0
    parsed = urlparse(choose_url(opts))
    if not parsed.scheme or not parsed.netloc:
        sys.stderr.write("Error: relative URL without a base\n")
        return 1
    if opts.output_format == "quiet":
        run_requests(opts)
        return 0
    try:
        results = run_requests(opts)
    except RuntimeError as e:
        sys.stderr.write(f"Error: {e}\n")
        return 1
    if opts.debug:
        return 0
    if opts.output_format == "csv":
        out = csv_output(results)
    elif opts.output_format == "json":
        out = json_summary(summarize(results))
    else:
        out = text_summary(summarize(results), opts.time_unit)
    if opts.output:
        with open(opts.output, "w") as f:
            f.write(out)
    else:
        sys.stdout.write(out)
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
