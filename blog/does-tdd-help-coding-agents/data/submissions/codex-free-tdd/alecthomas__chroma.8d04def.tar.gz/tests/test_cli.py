import os
import subprocess
import tempfile
import unittest


ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
EXE = os.path.join(ROOT, "executable")


class ChromaCliTests(unittest.TestCase):
    def run_cli(self, args, data=None):
        return subprocess.run(
            [EXE] + args,
            input=data,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
        )

    def test_version_matches_packaged_binary_placeholder(self):
        result = self.run_cli(["--version"])
        self.assertEqual(result.returncode, 0)
        self.assertEqual(result.stdout, "?-?-?\n")
        self.assertEqual(result.stderr, "")

    def test_help_describes_arguments_and_html_options(self):
        result = self.run_cli(["--help"])
        self.assertEqual(result.returncode, 0)
        self.assertIn("Usage: executable [<files> ...] [flags]", result.stdout)
        self.assertIn("--lexer=\"autodetect\"", result.stdout)
        self.assertIn("--html-linkable-lines", result.stdout)

    def test_list_includes_lexers_styles_and_formatters(self):
        result = self.run_cli(["--list"])
        self.assertEqual(result.returncode, 0)
        self.assertIn("lexers:\n  ABAP", result.stdout)
        self.assertIn("  Go\n    aliases: go golang", result.stdout)
        self.assertIn("styles: ", result.stdout)
        self.assertIn(" monokai ", result.stdout)
        self.assertIn("formatters: html json noop svg terminal", result.stdout)

    def test_default_style_reports_swapoff_file_error(self):
        with tempfile.NamedTemporaryFile("w", suffix=".go", delete=False) as tmp:
            tmp.write("package main\n")
            path = tmp.name
        try:
            result = self.run_cli([path])
        finally:
            os.unlink(path)
        self.assertEqual(result.returncode, 1)
        self.assertIn("package", result.stdout)
        self.assertEqual(
            result.stderr,
            "executable: error: open swapoff: no such file or directory\n",
        )

    def test_terminal_formatter_colours_go_with_named_style(self):
        result = self.run_cli(["-s", "monokai", "-l", "go"], "package main\n")
        self.assertEqual(result.returncode, 0)
        self.assertIn("\x1b[1m\x1b[31mpackage\x1b[0m", result.stdout)
        self.assertIn("\x1b[1m\x1b[33mmain\x1b[0m", result.stdout)
        self.assertEqual(result.stderr, "")

    def test_json_formatter_outputs_token_array_for_json(self):
        result = self.run_cli(["--json", "-s", "monokai", "-l", "json"], '{"a":1}\n')
        self.assertEqual(result.returncode, 0)
        self.assertIn('{"type":"Punctuation","value":"{"}', result.stdout)
        self.assertIn('{"type":"NameTag","value":"\\"a\\""}', result.stdout)
        self.assertTrue(result.stdout.startswith("[\n"))
        self.assertTrue(result.stdout.endswith("]\n"))

    def test_html_formatter_outputs_document_with_spans(self):
        result = self.run_cli(["--html", "-s", "monokai", "-l", "go"], "package main\n")
        self.assertEqual(result.returncode, 0)
        self.assertTrue(result.stdout.startswith("<html>\n<style type=\"text/css\">\n"))
        self.assertIn(".chroma .k { color: #66d9ef }", result.stdout)
        self.assertIn('<pre tabindex="0" class="chroma">', result.stdout)
        self.assertIn('<span class="k">package</span>', result.stdout)


if __name__ == "__main__":
    unittest.main()
