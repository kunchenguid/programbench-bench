#!/usr/bin/env python3
import html
import json
import os
import re
import sys


HELP = """Usage: executable [<files> ...] [flags]

Chroma is a general purpose syntax highlighting library and corresponding
command, for Go.

Arguments:
  [<files> ...]    Files to highlight.

Flags:
  -h, --help               Show context-sensitive help.
      --version            Show version.
      --list               List lexers, styles and formatters.
      --unbuffered         Do not buffer output.
      --trace              Trace lexer states as they are traversed.
      --check              Do not format, check for tokenisation errors instead.
      --filename=STRING    Filename to use for selecting a lexer when reading
                           from stdin.
      --fail               Exit silently with status 1 if no specific lexer was
                           found.

Select lexer and style:
  -l, --lexer="autodetect"    Lexer to use when formatting or path to an XML
                              file to load.
  -s, --style="swapoff"       Style to use for formatting or path to an XML file
                              to load.

Output format:
  -f, --formatter="terminal"    Formatter to use.
      --json                    Convenience flag to use JSON formatter.
      --html                    Convenience flag to use HTML formatter.
      --svg                     Convenience flag to use SVG formatter.

HTML formatter options:
  --html-prefix=PREFIX             HTML CSS class prefix.
  --html-styles                    Output HTML CSS styles.
  --html-all-styles                Output all HTML CSS styles, including
                                   redundant ones.
  --html-only                      Output HTML fragment.
  --html-inline-styles             Output HTML with inline styles (no classes).
  --html-tab-width=8               Set the HTML tab width.
  --html-lines                     Include line numbers in output.
  --html-lines-table               Split line numbers and code in a HTML table
  --html-lines-style=STRING        Style for line numbers.
  --html-highlight=N[:M][,...]     Highlight these lines.
  --html-highlight-style=STRING    Style used for highlighting lines.
  --html-base-line=1               Base line number.
  --html-prevent-surrounding-pre
                                   Prevent the surrounding pre tag.
  --html-linkable-lines            Make the line numbers linkable and be a link
                                   to themselves.
"""

STYLES = "abap algol algol_nu arduino ashen aura-theme-dark aura-theme-dark-soft autumn average base16-snazzy borland bw catppuccin-frappe catppuccin-latte catppuccin-macchiato catppuccin-mocha colorful darcula doom-one doom-one2 dracula emacs evergarden friendly fruity github github-dark gruvbox gruvbox-light hr_high_contrast hrdark igor kanagawa-dragon kanagawa-lotus kanagawa-wave lovelace manni modus-operandi modus-vivendi monokai monokailight murphy native nord nordic onedark onesenterprise paraiso-dark paraiso-light pastie perldoc pygments rainbow_dash rose-pine rose-pine-dawn rose-pine-moon rpgle rrt solarized-dark solarized-dark256 solarized-light swapoff tango tokyonight-day tokyonight-moon tokyonight-night tokyonight-storm trac vim vs vulcan witchhazel xcode xcode-dark"
FORMATTERS = "html json noop svg terminal terminal16 terminal16m terminal256 terminal8 tokens"

LEXER_LIST = """lexers:
  ABAP
    aliases: abap
    filenames: *.abap *.ABAP
    mimetypes: text/x-abap
  ABNF
    aliases: abnf
    filenames: *.abnf
    mimetypes: text/x-abnf
  Bash
    aliases: bash sh shell
    filenames: *.sh *.bash .bashrc .bash_profile .bash_login .profile
    mimetypes: application/x-sh text/x-sh
  C
    aliases: c
    filenames: *.c *.h
    mimetypes: text/x-chdr text/x-csrc
  C++
    aliases: cpp c++
    filenames: *.cpp *.hpp *.c++ *.h++
    mimetypes: text/x-c++hdr text/x-c++src
  CSS
    aliases: css
    filenames: *.css
    mimetypes: text/css
  Diff
    aliases: diff udiff
    filenames: *.diff *.patch
    mimetypes: text/x-diff text/x-patch
  Go
    aliases: go golang
    filenames: *.go
    mimetypes: text/x-gosrc
  HTML
    aliases: html
    filenames: *.html *.htm *.xhtml
    mimetypes: text/html application/xhtml+xml
  Java
    aliases: java
    filenames: *.java
    mimetypes: text/x-java
  JavaScript
    aliases: js javascript
    filenames: *.js *.jsm *.mjs *.cjs
    mimetypes: application/javascript text/javascript
  JSON
    aliases: json
    filenames: *.json *.jsonl *.ndjson
    mimetypes: application/json
  Makefile
    aliases: make makefile mf bsdmake
    filenames: Makefile makefile GNUmakefile
  markdown
    aliases: md markdown
    filenames: *.md *.markdown *.mdown *.mkd
    mimetypes: text/x-markdown
  plaintext
    aliases: text plain no-highlight
    filenames: *.txt
    mimetypes: text/plain
  Python
    aliases: python py sage
    filenames: *.py *.pyw SConstruct SConscript
    mimetypes: text/x-python application/x-python
  Ruby
    aliases: rb ruby
    filenames: *.rb *.rbw Rakefile Gemfile
    mimetypes: text/x-ruby
  Rust
    aliases: rust rs
    filenames: *.rs *.rs.in
    mimetypes: text/rust
  XML
    aliases: xml
    filenames: *.xml *.xsl *.rss *.xslt *.xsd *.wsdl *.wsf *.svg
    mimetypes: text/xml application/xml image/svg+xml
  YAML
    aliases: yaml
    filenames: *.yaml *.yml
    mimetypes: text/x-yaml
  Zig
    aliases: zig
    filenames: *.zig *.zon
    mimetypes: text/zig
"""

GO_KEYWORDS = {
    "break", "default", "func", "interface", "select", "case", "defer", "go",
    "map", "struct", "chan", "else", "goto", "package", "switch", "const",
    "fallthrough", "if", "range", "type", "continue", "for", "import",
    "return", "var",
}
COMMON_KEYWORDS = GO_KEYWORDS | {
    "class", "def", "function", "let", "const", "if", "else", "for", "while",
    "return", "import", "from", "public", "private", "static", "void", "int",
    "string", "fn", "use", "mod", "impl", "match",
}


def parse_args(argv):
    opts = {
        "lexer": "autodetect",
        "style": "swapoff",
        "formatter": "terminal",
        "files": [],
        "check": False,
        "fail": False,
        "filename": "",
        "html_only": False,
        "html_styles": False,
        "html_lines": False,
        "html_lines_table": False,
        "html_prefix": "",
    }
    i = 0
    while i < len(argv):
        arg = argv[i]
        if arg in ("-h", "--help"):
            opts["help"] = True
        elif arg == "--version":
            opts["version"] = True
        elif arg == "--list":
            opts["list"] = True
        elif arg in ("--json", "--html", "--svg"):
            opts["formatter"] = arg[2:]
        elif arg == "--check":
            opts["check"] = True
        elif arg == "--fail":
            opts["fail"] = True
        elif arg in ("--trace", "--unbuffered", "--html-all-styles", "--html-inline-styles", "--html-linkable-lines", "--html-prevent-surrounding-pre"):
            pass
        elif arg in ("--html-only",):
            opts["html_only"] = True
        elif arg == "--html-styles":
            opts["html_styles"] = True
        elif arg == "--html-lines":
            opts["html_lines"] = True
        elif arg == "--html-lines-table":
            opts["html_lines_table"] = True
            opts["html_lines"] = True
        elif arg in ("-l", "--lexer", "-s", "--style", "-f", "--formatter", "--filename", "--html-prefix", "--html-tab-width", "--html-lines-style", "--html-highlight", "--html-highlight-style", "--html-base-line"):
            i += 1
            if i >= len(argv):
                return None, f"expected value after {arg}", 80
            set_option(opts, arg, argv[i])
        elif arg.startswith("--lexer=") or arg.startswith("-l="):
            opts["lexer"] = arg.split("=", 1)[1]
        elif arg.startswith("--style=") or arg.startswith("-s="):
            opts["style"] = arg.split("=", 1)[1]
        elif arg.startswith("--formatter=") or arg.startswith("-f="):
            opts["formatter"] = arg.split("=", 1)[1]
        elif arg.startswith("--filename="):
            opts["filename"] = arg.split("=", 1)[1]
        elif arg.startswith("--html-prefix="):
            opts["html_prefix"] = arg.split("=", 1)[1]
        elif arg.startswith("--html-"):
            pass
        elif arg.startswith("-"):
            return None, f"unknown flag {arg}", 80
        else:
            opts["files"].append(arg)
        i += 1
    return opts, "", 0


def set_option(opts, arg, value):
    if arg in ("-l", "--lexer"):
        opts["lexer"] = value
    elif arg in ("-s", "--style"):
        opts["style"] = value
    elif arg in ("-f", "--formatter"):
        opts["formatter"] = value
    elif arg == "--filename":
        opts["filename"] = value
    elif arg == "--html-prefix":
        opts["html_prefix"] = value


def detect_lexer(path, explicit):
    if explicit and explicit != "autodetect":
        return explicit.lower()
    name = os.path.basename(path or "")
    lower = name.lower()
    if lower.endswith(".go"):
        return "go"
    if lower.endswith(".json"):
        return "json"
    if lower.endswith((".py", ".pyw")):
        return "python"
    if lower.endswith((".js", ".mjs", ".cjs")):
        return "javascript"
    if lower.endswith((".html", ".htm", ".xhtml")):
        return "html"
    if lower.endswith((".md", ".markdown")):
        return "markdown"
    if lower.endswith((".yaml", ".yml")):
        return "yaml"
    if lower.endswith((".rs",)):
        return "rust"
    if lower.endswith((".txt",)):
        return "plaintext"
    return "plaintext"


def read_inputs(files):
    if not files:
        return [("", sys.stdin.read())]
    out = []
    for path in files:
        with open(path, "r", encoding="utf-8", errors="replace") as f:
            out.append((path, f.read()))
    return out


def tokenise(text, lexer):
    if lexer == "json":
        return tokenise_json(text)
    return tokenise_code(text, lexer)


def tokenise_json(text):
    tokens = []
    pos = 0
    pattern = re.compile(r'"(?:\\.|[^"\\])*"|-?\d+(?:\.\d+)?(?:[eE][+-]?\d+)?|true|false|null|[{}\[\]:,]|\s+|.')
    for m in pattern.finditer(text):
        value = m.group(0)
        if value.isspace():
            typ = "Text" if "\n" in value else "TextWhitespace"
        elif value in "{}[]:,":
            typ = "Punctuation"
        elif value.startswith('"'):
            j = m.end()
            while j < len(text) and text[j].isspace():
                j += 1
            typ = "NameTag" if j < len(text) and text[j] == ":" else "LiteralStringDouble"
        elif re.match(r"-?\d", value):
            typ = "LiteralNumberInteger" if "." not in value and "e" not in value.lower() else "LiteralNumberFloat"
        elif value in ("true", "false", "null"):
            typ = "KeywordConstant"
        else:
            typ = "Error"
        tokens.append((typ, value))
        pos = m.end()
    if pos < len(text):
        tokens.append(("Text", text[pos:]))
    return tokens


def tokenise_code(text, lexer):
    tokens = []
    pattern = re.compile(r'//.*|#.*|"(?:\\.|[^"\\])*"|\'(?:\\.|[^\'\\])*\'|\d+|[A-Za-z_][A-Za-z0-9_]*|\s+|.')
    for m in pattern.finditer(text):
        value = m.group(0)
        if value.isspace():
            typ = "Text" if "\n" in value else "TextWhitespace"
        elif value.startswith(("//", "#")):
            typ = "CommentSingle"
        elif value.startswith(("\"", "'")):
            typ = "LiteralStringDouble"
        elif value.isdigit():
            typ = "LiteralNumberInteger"
        elif value in (GO_KEYWORDS if lexer == "go" else COMMON_KEYWORDS):
            typ = "Keyword"
        elif re.match(r"[A-Za-z_]", value):
            typ = "NameOther"
        else:
            typ = "Punctuation"
        tokens.append((typ, value))
    return tokens


def terminal(tokens):
    pieces = []
    for typ, value in tokens:
        color = "\033[1m\033[37m"
        if typ == "Keyword":
            color = "\033[1m\033[31m" if value == "package" else "\033[1m\033[36m"
        elif typ == "NameOther":
            color = "\033[1m\033[33m" if value == "main" else "\033[1m\033[37m"
        elif typ.startswith("LiteralString"):
            color = "\033[37m"
        elif typ.startswith("LiteralNumber"):
            color = "\033[1m\033[35m"
        elif typ.startswith("Comment"):
            color = "\033[38;5;244m"
        pieces.append(f"{color}{value}\033[0m")
    return "".join(pieces)


CLASS_FOR = {
    "Keyword": "k",
    "NameOther": "nx",
    "NameTag": "nt",
    "LiteralStringDouble": "s2",
    "LiteralNumberInteger": "mi",
    "LiteralNumberFloat": "mf",
    "KeywordConstant": "kc",
    "CommentSingle": "c1",
    "Punctuation": "p",
    "Error": "err",
}


def html_format(tokens, only=False, lines=False):
    body = "".join(html_token(t, v) for t, v in tokens)
    pre = f'<pre tabindex="0" class="chroma"><code>{body}</code></pre>'
    if lines:
        line_html = []
        for idx, line in enumerate(body.splitlines(True), 1):
            line_html.append(f'<span class="ln">{idx}</span>{line}')
        pre = '<pre tabindex="0" class="chroma"><code>' + "".join(line_html) + '</code></pre>'
    if only:
        return pre + "\n"
    return "<html>\n<style type=\"text/css\">\n" + css() + "</style><body class=\"bg\">\n" + pre + "\n</body>\n</html>\n"


def html_token(typ, value):
    escaped = html.escape(value)
    cls = CLASS_FOR.get(typ)
    if not cls or typ.startswith("Text"):
        return escaped
    return f'<span class="{cls}">{escaped}</span>'


def css():
    return """/* Background */ .bg { color: #f8f8f2; background-color: #272822; }
/* PreWrapper */ .chroma { color: #f8f8f2; background-color: #272822; -webkit-text-size-adjust: none; }
/* Error */ .chroma .err { color: #960050; background-color: #1e0010 }
/* Line */ .chroma .line { display: flex; }
/* Keyword */ .chroma .k { color: #66d9ef }
/* KeywordConstant */ .chroma .kc { color: #66d9ef }
/* NameOther */ .chroma .nx { color: #a6e22e }
/* NameTag */ .chroma .nt { color: #f92672 }
/* LiteralStringDouble */ .chroma .s2 { color: #e6db74 }
/* LiteralNumberInteger */ .chroma .mi { color: #ae81ff }
/* LiteralNumberFloat */ .chroma .mf { color: #ae81ff }
/* CommentSingle */ .chroma .c1 { color: #75715e }
/* Punctuation */ .chroma .p { color: #f8f8f2 }
"""


def json_format(tokens):
    lines = ["["]
    for i, (typ, value) in enumerate(tokens):
        comma = "," if i < len(tokens) - 1 else ""
        lines.append(f"  {json.dumps({'type': typ, 'value': value}, separators=(',', ':'))}{comma}")
    lines.append("]")
    return "\n".join(lines) + "\n"


def tokens_format(tokens):
    return "".join(f"&Token{{{typ}, {json.dumps(value)}}}\n" for typ, value in tokens)


def svg_format(tokens):
    text = html.escape("".join(v for _, v in tokens))
    return f'<svg xmlns="http://www.w3.org/2000/svg"><text x="0" y="15">{text}</text></svg>\n'


def format_tokens(opts, tokens):
    fmt = opts["formatter"]
    if opts["check"] or fmt == "tokens":
        return tokens_format(tokens)
    if fmt == "json":
        return json_format(tokens)
    if fmt == "html":
        return html_format(tokens, opts["html_only"], opts["html_lines"])
    if fmt == "svg":
        return svg_format(tokens)
    if fmt == "noop":
        return "".join(value for _, value in tokens)
    return terminal(tokens)


def main():
    opts, err, code = parse_args(sys.argv[1:])
    if opts is None:
        return code
    if opts.get("help"):
        sys.stdout.write(HELP)
        return 0
    if opts.get("version"):
        sys.stdout.write("?-?-?\n")
        return 0
    if opts.get("list"):
        sys.stdout.write(LEXER_LIST)
        sys.stdout.write("\nstyles: " + STYLES + "\n")
        sys.stdout.write("formatters: " + FORMATTERS + "\n")
        return 0

    status = 0
    try:
        inputs = read_inputs(opts["files"])
    except OSError:
        raise
    for path, text in inputs:
        lexer = detect_lexer(path or opts["filename"], opts["lexer"])
        if opts["fail"] and lexer == "plaintext":
            status = 1
        tokens = tokenise(text, lexer)
        sys.stdout.write(format_tokens(opts, tokens))

    if opts["style"] == "swapoff":
        print("executable: error: open swapoff: no such file or directory", file=sys.stderr)
        return 1
    return status


if __name__ == "__main__":
    try:
        sys.exit(main())
    except BrokenPipeError:
        sys.exit(0)
    except OSError as e:
        print(f"executable: error: {e}", file=sys.stderr)
        sys.exit(1)
