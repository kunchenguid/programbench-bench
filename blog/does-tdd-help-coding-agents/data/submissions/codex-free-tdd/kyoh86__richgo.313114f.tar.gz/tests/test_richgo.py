import os
import subprocess
import sys
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
EXE = ROOT / "executable"


def run_cmd(args, input_text=None, env=None, cwd=None):
    cmd_env = os.environ.copy()
    if env:
        cmd_env.update(env)
    return subprocess.run(
        [str(EXE), *args],
        input=input_text,
        text=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        env=cmd_env,
        cwd=cwd,
    )


class RichGoTests(unittest.TestCase):
    def test_delegates_version_to_go(self):
        proc = run_cmd(["version"])
        self.assertEqual(proc.returncode, 0)
        self.assertEqual(proc.stderr, "")
        self.assertRegex(proc.stdout, r"^go version go[0-9.]+ linux/amd64\n$")

    def test_testfilter_preserves_plain_output_without_forced_color(self):
        sample = "=== RUN   TestSampleOK\n--- PASS: TestSampleOK (0.00s)\nPASS\nok  \texample.com/foo\t0.001s\n"
        proc = run_cmd(["testfilter"], input_text=sample)
        self.assertEqual(proc.returncode, 0)
        self.assertEqual(proc.stderr, "")
        self.assertEqual(proc.stdout, sample)

    def test_testfilter_decorates_basic_pass_lines_when_color_forced(self):
        sample = "=== RUN   TestSampleOK\n--- PASS: TestSampleOK (0.00s)\nPASS\nok  \texample.com/foo\t0.001s\n"
        proc = run_cmd(["testfilter"], input_text=sample, env={"RICHGO_FORCE_COLOR": "1"})
        self.assertEqual(proc.returncode, 0)
        self.assertEqual(proc.stderr, "")
        self.assertEqual(
            proc.stdout,
            "\033[90mSTART| SampleOK\033[0m\n"
            "\033[32mPASS | SampleOK (0.00s)\033[0m\n"
            "\033[32mPASS | example.com/foo \033[0m\n",
        )

    def test_testfilter_decorates_fail_skip_coverage_and_build_lines(self):
        sample = (
            "=== RUN   TestSkip\n"
            "--- SKIP: TestSkip (0.01s)\n"
            "    x_test.go:3: skip\n"
            "--- FAIL: TestBad (0.02s)\n"
            "    x_test.go:4: boom\n"
            "coverage: 75.5% of statements\n"
            "# example.com/foo\n"
            "file.go:12: bad thing\n"
            "FAIL\texample.com/bar\t0.456s\n"
            "?   \texample.com/none\t[no test files]\n"
        )
        proc = run_cmd(["testfilter"], input_text=sample, env={"RICHGO_FORCE_COLOR": "1"})
        self.assertEqual(proc.returncode, 0)
        self.assertEqual(proc.stderr, "")
        self.assertEqual(
            proc.stdout,
            "\033[90mSTART| Skip\033[0m\n"
            "\033[90mSKIP | Skip (0.01s)\033[0m\n"
            "\033[90m     |     \033[36mx_test.go\033[0m\033[35m:3\033[0m\033[90m: skip\033[0m\n"
            "\033[31m\033[1mFAIL | Bad (0.02s)\033[0m\n"
            "\033[31m\033[1m     |     \033[36mx_test.go\033[0m\033[35m:4\033[0m\033[31m\033[1m: boom\033[0m\n"
            "\033[32mCOVER| 75.5% [#######___]\033[0m\n"
            "\033[33m\033[1mBUILD| example.com/foo\n\033[0m"
            "\033[33m\033[1m     | \033[36mfile.go\033[0m\033[35m:12\033[0m\033[33m\033[1m: bad thing\033[0m\n"
            "\033[31m\033[1mFAIL | \texample.com/bar\t0.456s\033[0m\n"
            "\033[90mSKIP | example.com/none\t[no test files]\033[0m\n",
        )

    def test_test_runs_go_test_filters_output_and_returns_status(self):
        import tempfile

        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            subprocess.run(["go", "mod", "init", "example.com/t"], cwd=root, check=True, stdout=subprocess.PIPE)
            (root / "x_test.go").write_text(
                'package x\nimport "testing"\nfunc TestFail(t *testing.T) { t.Fatal("boom") }\n',
                encoding="utf-8",
            )
            proc = run_cmd(["test"], cwd=root, env={"RICHGO_FORCE_COLOR": "1"})

        self.assertEqual(proc.returncode, 1)
        self.assertIn("\033[31m\033[1mFAIL | Fail", proc.stdout)
        self.assertIn("\033[36mx_test.go\033[0m\033[35m:3\033[0m", proc.stdout)
        self.assertIn("\033[31m\033[1mFAIL | \texample.com/t\t", proc.stdout)
        self.assertEqual(proc.stderr, "")

    def test_reads_richstyle_label_prefix_removals_and_coverage_threshold(self):
        import tempfile

        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            (root / ".richstyle").write_text(
                "labelType: short\nleaveTestPrefix: true\ncoverThreshold: 80\nremovals:\n  - boom\n",
                encoding="utf-8",
            )
            sample = (
                "=== RUN   TestFoo/Sub\n"
                "boom line\n"
                "--- PASS: TestFoo/Sub (0.00s)\n"
                "coverage: 75.5% of statements\n"
                "coverage: 85.0% of statements\n"
            )
            proc = run_cmd(["testfilter"], input_text=sample, env={"RICHGO_FORCE_COLOR": "1"}, cwd=root)

        self.assertEqual(proc.returncode, 0)
        self.assertEqual(
            proc.stdout,
            "\033[90m>    TestFoo/Sub\033[0m\n"
            "\033[90m     |  line\033[0m\n"
            "\033[32mo    TestFoo/Sub (0.00s)\033[0m\n"
            "\033[33m\033[1m%  75.5% [#######___]\033[0m\n"
            "\033[32m%  85.0% [########__]\033[0m\n",
        )


if __name__ == "__main__":
    unittest.main()
