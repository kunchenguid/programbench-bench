#!/usr/bin/env python3
import os
import re
import subprocess
import sys


RESET = "\033[0m"
START = "\033[90m"
PASS = "\033[32m"
FAIL = "\033[31m\033[1m"
SKIP = "\033[90m"
BUILD = "\033[33m\033[1m"
FILE = "\033[36m"
LINE = "\033[35m"


def load_config() -> dict:
    cfg = {
        "labelType": "long",
        "leaveTestPrefix": False,
        "coverThreshold": 50.0,
        "removals": [],
    }
    for name in (".richstyle", ".richstyle.yaml", ".richstyle.yml"):
        path = os.path.join(os.getcwd(), name)
        if not os.path.exists(path):
            continue
        in_removals = False
        with open(path, encoding="utf-8") as fh:
            for raw in fh:
                line = raw.strip()
                if not line or line.startswith("#"):
                    continue
                if line == "removals:":
                    in_removals = True
                    continue
                if in_removals and line.startswith("- "):
                    cfg["removals"].append(line[2:].strip().strip('"').strip("'"))
                    continue
                in_removals = False
                if ":" not in line:
                    continue
                key, value = line.split(":", 1)
                value = value.strip().strip('"').strip("'")
                if key == "labelType" and value in {"long", "short", "none"}:
                    cfg["labelType"] = value
                elif key == "leaveTestPrefix":
                    cfg["leaveTestPrefix"] = value.lower() == "true"
                elif key == "coverThreshold":
                    try:
                        cfg["coverThreshold"] = float(value)
                    except ValueError:
                        pass
        break
    return cfg


def strip_test_prefix(name: str, cfg: dict) -> str:
    if cfg.get("leaveTestPrefix"):
        return name
    parts = []
    for part in name.split("/"):
        parts.append(part[4:] if part.startswith("Test") else part)
    return "/".join(parts)


LONG_LABELS = {
    "start": "START|",
    "pass": "PASS |",
    "fail": "FAIL |",
    "skip": "SKIP |",
    "cover": "COVER|",
}

SHORT_LABELS = {
    "start": ">",
    "pass": "o",
    "fail": "x",
    "skip": "-",
    "cover": "%",
}


def label(kind: str, text: str, cfg: dict, depth: int = 0) -> str:
    label_type = cfg.get("labelType", "long")
    if label_type == "none":
        return f"{'  ' * depth}{text}"
    if label_type == "short":
        return f"{SHORT_LABELS[kind]}{' ' * (2 + 2 * depth)}{text}"
    return f"{LONG_LABELS[kind]}{' ' * (1 + 2 * depth)}{text}"


def decorate(data: str) -> str:
    cfg = load_config()
    out = []
    context = None
    for raw in data.splitlines():
        line = raw.rstrip("\n")
        for pattern in cfg["removals"]:
            line = re.sub(pattern, "", line)
        m = re.match(r"^=== RUN\s+(.+)$", line)
        if m:
            name = strip_test_prefix(m.group(1), cfg)
            out.append(f"{START}{label('start', name, cfg, name.count('/'))}{RESET}")
            context = "start"
            continue

        m = re.match(r"^--- PASS:\s+(\S+)\s+(\(.+\))$", line)
        if m:
            name = strip_test_prefix(m.group(1), cfg)
            out.append(f"{PASS}{label('pass', f'{name} {m.group(2)}', cfg, name.count('/'))}{RESET}")
            context = "pass"
            continue

        m = re.match(r"^--- FAIL:\s+(\S+)\s+(\(.+\))$", line)
        if m:
            name = strip_test_prefix(m.group(1), cfg)
            out.append(f"{FAIL}{label('fail', f'{name} {m.group(2)}', cfg, name.count('/'))}{RESET}")
            context = "fail"
            continue

        m = re.match(r"^--- SKIP:\s+(\S+)\s+(\(.+\))$", line)
        if m:
            name = strip_test_prefix(m.group(1), cfg)
            out.append(f"{SKIP}{label('skip', f'{name} {m.group(2)}', cfg, name.count('/'))}{RESET}")
            context = "skip"
            continue

        if line == "PASS":
            continue

        m = re.match(r"^coverage:\s+([0-9.]+)% of statements$", line)
        if m:
            pct = float(m.group(1))
            full = int(pct // 10)
            color = PASS if pct >= cfg["coverThreshold"] else BUILD
            bar = "#" * full + "_" * (10 - full)
            out.append(f"{color}{label('cover', f'{m.group(1)}% [{bar}]', cfg)}{RESET}")
            context = "cover"
            continue

        m = re.match(r"^#\s+(.+)$", line)
        if m:
            out.append(f"{BUILD}BUILD| {m.group(1)}")
            context = "build"
            continue

        m = re.match(r"^ok\s+\t?(\S+)\t[0-9.]+s(?:\t(.*))?$", line)
        if m:
            tail = m.group(2) or ""
            out.append(f"{PASS}{label('pass', f'{m.group(1)} {tail}', cfg)}{RESET}")
            context = "passpkg"
            continue

        if line.startswith("FAIL\t"):
            out.append(f"{FAIL}{label('fail', line[4:], cfg)}{RESET}")
            context = "failpkg"
            continue

        m = re.match(r"^\?\s+\t?(\S+)\t(.+)$", line)
        if m:
            text = f"{m.group(1)}\t{m.group(2)}"
            out.append(f"{SKIP}{label('skip', text, cfg)}{RESET}")
            context = "skip"
            continue

        file_line = re.match(r"^(\s*)([^:\s]+\.go):([0-9]+)(:.*)$", line)
        if file_line:
            color = {"fail": FAIL, "build": BUILD, "skip": SKIP}.get(context)
            if color:
                prefix = RESET if context == "build" else ""
                out.append(
                    f"{prefix}{color}     | {file_line.group(1)}"
                    f"{FILE}{file_line.group(2)}{RESET}{LINE}:{file_line.group(3)}{RESET}"
                    f"{color}{file_line.group(4)}{RESET}"
                )
                continue

        if context in {"fail", "build"}:
            color = FAIL if context == "fail" else BUILD
            out.append(f"{color}     | {line}{RESET}")
            continue

        if context in {"start", "pass", "skip"}:
            color = PASS if context == "pass" else SKIP
            out.append(f"{color}     | {line}{RESET}")
            continue

        out.append(line)
    return "".join(f"{line}\n" for line in out)


def main() -> int:
    args = sys.argv[1:]
    if args and args[0] == "testfilter":
        data = sys.stdin.read()
        if os.environ.get("RICHGO_FORCE_COLOR") == "1":
            sys.stdout.write(decorate(data))
        else:
            sys.stdout.write(data)
        return 0

    if args and args[0] == "test":
        proc = subprocess.run(
            ["go", *args],
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            text=True,
        )
        data = proc.stdout
        if os.environ.get("RICHGO_FORCE_COLOR") == "1":
            sys.stdout.write(decorate(data))
        else:
            sys.stdout.write(data)
        return proc.returncode

    return subprocess.run(["go", *args]).returncode


if __name__ == "__main__":
    raise SystemExit(main())
