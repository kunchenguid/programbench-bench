import json
import os
import subprocess
import sys
import tempfile
import textwrap
import unittest
import zipfile


ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DSQ = os.path.join(ROOT, "dsq.py")


class DsqCommandTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.work = self.tmp.name
        self.users = os.path.join(self.work, "users.csv")
        with open(self.users, "w", encoding="utf-8") as f:
            f.write("id,name,age\n1,Alice,30\n2,Bob,25\n3,Alice,35\n")

    def run_dsq(self, *args, input_text=None):
        return subprocess.run(
            [sys.executable, DSQ, *args],
            input=input_text,
            text=True,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            cwd=ROOT,
        )

    def test_csv_defaults_to_select_all_as_json(self):
        proc = self.run_dsq(self.users)
        self.assertEqual(proc.returncode, 0, proc.stderr)
        self.assertIn("},\n{", proc.stdout)
        self.assertEqual(
            json.loads(proc.stdout),
            [
                {"id": "1", "name": "Alice", "age": "30"},
                {"id": "2", "name": "Bob", "age": "25"},
                {"id": "3", "name": "Alice", "age": "35"},
            ],
        )

    def test_sql_query_uses_brace_table_shorthand(self):
        proc = self.run_dsq(
            self.users,
            "SELECT name, COUNT(*) AS c FROM {} GROUP BY name ORDER BY name",
        )
        self.assertEqual(proc.returncode, 0, proc.stderr)
        self.assertEqual(
            json.loads(proc.stdout),
            [{"name": "Alice", "c": 2}, {"name": "Bob", "c": 1}],
        )

    def test_join_uses_numbered_table_names(self):
        cities = os.path.join(self.work, "cities.json")
        with open(cities, "w", encoding="utf-8") as f:
            json.dump([{"id": 1, "city": "NY"}, {"id": 2, "city": "SF"}], f)
        proc = self.run_dsq(
            self.users,
            cities,
            "SELECT {0}.name, {1}.city FROM {0} JOIN {1} ON {0}.id = {1}.id ORDER BY {0}.id",
        )
        self.assertEqual(proc.returncode, 0, proc.stderr)
        self.assertEqual(
            json.loads(proc.stdout),
            [{"name": "Alice", "city": "NY"}, {"name": "Bob", "city": "SF"}],
        )

    def test_pretty_output_renders_table_and_row_count(self):
        proc = self.run_dsq(
            "-p",
            self.users,
            "SELECT name, id FROM {} ORDER BY id LIMIT 2",
        )
        self.assertEqual(proc.returncode, 0, proc.stderr)
        self.assertIn("| id | name  |", proc.stdout)
        self.assertIn("|  1 | Alice |", proc.stdout)
        self.assertTrue(proc.stdout.rstrip().endswith("(2 rows)"))

    def test_schema_reports_inferred_scalar_types(self):
        proc = self.run_dsq(self.users, "--schema")
        self.assertEqual(proc.returncode, 0, proc.stderr)
        schema = json.loads(proc.stdout)
        self.assertEqual(schema["kind"], "array")
        self.assertEqual(schema["array"]["object"]["id"]["scalar"], "string")
        self.assertEqual(schema["array"]["object"]["name"]["scalar"], "string")

    def test_stdin_uses_stream_format(self):
        proc = self.run_dsq(
            "-s",
            "csv",
            "SELECT name FROM {} WHERE id = 2",
            input_text="id,name\n1,Alice\n2,Bob\n",
        )
        self.assertEqual(proc.returncode, 0, proc.stderr)
        self.assertEqual(json.loads(proc.stdout), [{"name": "Bob"}])

    def test_query_file_is_supported(self):
        q = os.path.join(self.work, "query.sql")
        with open(q, "w", encoding="utf-8") as f:
            f.write("SELECT name FROM {} WHERE id = 3\n")
        proc = self.run_dsq(self.users, "-f", q)
        self.assertEqual(proc.returncode, 0, proc.stderr)
        self.assertEqual(json.loads(proc.stdout), [{"name": "Alice"}])

    def test_cache_flag_prints_notice_and_runs_query(self):
        proc = self.run_dsq("-C", self.users, "SELECT COUNT(*) AS c FROM {}")
        self.assertEqual(proc.returncode, 0, proc.stderr)
        lines = proc.stdout.splitlines()
        self.assertEqual(lines[0], "Cache invalid, re-import required.")
        self.assertEqual(json.loads("\n".join(lines[1:])), [{"c": 3}])

    def test_json_and_ndjson_inputs(self):
        array_file = os.path.join(self.work, "array.json")
        lines_file = os.path.join(self.work, "lines.ndjson")
        with open(array_file, "w", encoding="utf-8") as f:
            f.write('[{"id":1,"flag":true},{"id":2,"flag":false}]')
        with open(lines_file, "w", encoding="utf-8") as f:
            f.write('{"id":1,"x":"a"}\n{"id":2,"x":"b"}\n')
        proc = self.run_dsq(array_file, "SELECT id, flag FROM {} ORDER BY id DESC")
        self.assertEqual(proc.returncode, 0, proc.stderr)
        self.assertEqual(json.loads(proc.stdout), [{"id": 2, "flag": 0}, {"id": 1, "flag": 1}])
        proc = self.run_dsq(lines_file)
        self.assertEqual(proc.returncode, 0, proc.stderr)
        self.assertEqual(json.loads(proc.stdout), [{"id": 1, "x": "a"}, {"id": 2, "x": "b"}])

    def test_logfmt_input(self):
        log = os.path.join(self.work, "events.logfmt")
        with open(log, "w", encoding="utf-8") as f:
            f.write('level=info msg="hello world" n=2\nlevel=debug msg=bye\n')
        proc = self.run_dsq(log, "SELECT level, msg, n FROM {} ORDER BY level")
        self.assertEqual(proc.returncode, 0, proc.stderr)
        self.assertEqual(
            json.loads(proc.stdout),
            [{"level": "debug", "msg": "bye", "n": None}, {"level": "info", "msg": "hello world", "n": "2"}],
        )

    def test_xlsx_single_sheet_uses_first_row_as_headers(self):
        xlsx = os.path.join(self.work, "book.xlsx")
        with zipfile.ZipFile(xlsx, "w") as z:
            z.writestr("[Content_Types].xml", "<Types/>")
            z.writestr("xl/workbook.xml", textwrap.dedent("""\
                <workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"
                          xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">
                  <sheets><sheet name="Sheet1" sheetId="1" r:id="rId1"/></sheets>
                </workbook>
            """))
            z.writestr("xl/_rels/workbook.xml.rels", textwrap.dedent("""\
                <Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
                  <Relationship Id="rId1" Target="worksheets/sheet1.xml"/>
                </Relationships>
            """))
            z.writestr("xl/worksheets/sheet1.xml", textwrap.dedent("""\
                <worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">
                  <sheetData>
                    <row><c t="inlineStr"><is><t>id</t></is></c><c t="inlineStr"><is><t>name</t></is></c></row>
                    <row><c><v>1</v></c><c t="inlineStr"><is><t>Alice</t></is></c></row>
                    <row><c><v>2</v></c><c t="inlineStr"><is><t>Bob</t></is></c></row>
                  </sheetData>
                </worksheet>
            """))
        proc = self.run_dsq(xlsx, "SELECT name FROM {} WHERE id = 2")
        self.assertEqual(proc.returncode, 0, proc.stderr)
        self.assertEqual(json.loads(proc.stdout), [{"name": "Bob"}])

    def test_ods_single_table_uses_first_row_as_headers(self):
        ods = os.path.join(self.work, "book.ods")
        with zipfile.ZipFile(ods, "w") as z:
            z.writestr("mimetype", "application/vnd.oasis.opendocument.spreadsheet")
            z.writestr("content.xml", textwrap.dedent("""\
                <office:document-content
                    xmlns:office="urn:oasis:names:tc:opendocument:xmlns:office:1.0"
                    xmlns:table="urn:oasis:names:tc:opendocument:xmlns:table:1.0"
                    xmlns:text="urn:oasis:names:tc:opendocument:xmlns:text:1.0">
                  <office:body><office:spreadsheet><table:table table:name="Sheet1">
                    <table:table-row>
                      <table:table-cell><text:p>id</text:p></table:table-cell>
                      <table:table-cell><text:p>name</text:p></table:table-cell>
                    </table:table-row>
                    <table:table-row>
                      <table:table-cell><text:p>1</text:p></table:table-cell>
                      <table:table-cell><text:p>Alice</text:p></table:table-cell>
                    </table:table-row>
                  </table:table></office:spreadsheet></office:body>
                </office:document-content>
            """))
        proc = self.run_dsq(ods, "SELECT name FROM {} WHERE id = 1")
        self.assertEqual(proc.returncode, 0, proc.stderr)
        self.assertEqual(json.loads(proc.stdout), [{"name": "Alice"}])

    def test_ods_cells_include_nested_text(self):
        ods = os.path.join(self.work, "nested.ods")
        with zipfile.ZipFile(ods, "w") as z:
            z.writestr("mimetype", "application/vnd.oasis.opendocument.spreadsheet")
            z.writestr("content.xml", textwrap.dedent("""\
                <office:document-content
                    xmlns:office="urn:oasis:names:tc:opendocument:xmlns:office:1.0"
                    xmlns:table="urn:oasis:names:tc:opendocument:xmlns:table:1.0"
                    xmlns:text="urn:oasis:names:tc:opendocument:xmlns:text:1.0">
                  <office:body><office:spreadsheet><table:table table:name="Sheet1">
                    <table:table-row>
                      <table:table-cell><text:p><text:span> Name </text:span></text:p></table:table-cell>
                    </table:table-row>
                    <table:table-row>
                      <table:table-cell><text:p><text:span>Alice</text:span></text:p></table:table-cell>
                    </table:table-row>
                  </table:table></office:spreadsheet></office:body>
                </office:document-content>
            """))
        proc = self.run_dsq(ods, 'SELECT " Name " AS name FROM {}')
        self.assertEqual(proc.returncode, 0, proc.stderr)
        self.assertEqual(json.loads(proc.stdout), [{"name": "Alice"}])

    def test_errors_match_common_messages(self):
        proc = self.run_dsq(os.path.join(self.work, "missing.csv"))
        self.assertNotEqual(proc.returncode, 0)
        self.assertIn("no such file or directory", proc.stderr)
        proc = self.run_dsq(self.users, "SELECT nope FROM {}")
        self.assertNotEqual(proc.returncode, 0)
        self.assertIn("no such column: nope", proc.stderr)


if __name__ == "__main__":
    unittest.main()
