#!/usr/bin/env python3
import csv
import io
import json
import os
import re
import shlex
import sqlite3
import sys
import zipfile
import xml.etree.ElementTree as ET


HELP = """dsq (Version latest) - commandline SQL engine for data files

Usage:  dsq [file...] $query
        dsq $file [query]
        cat $file | dsq -s $filetype [query]
        dsq $file -f $queryfile

dsq is a tool for running SQL on one or more data files. It uses
SQLite's SQL dialect. Files as tables are accessible via "{N}" where N
is the 0-based index of the file in the commandline.

The shorthand "{}" is replaced with "{0}".

Examples:

    # This simply dumps the CSV as JSON
    $ dsq test.csv

    # This dumps the first 10 rows of the parquet file as JSON.
    $ dsq data.parquet "SELECT * FROM {} LIMIT 10"

    # This joins two datasets of differing origin types (CSV and JSON).
    $ dsq testdata/join/users.csv testdata/join/ages.json \\
          "select {0}.name, {1}.age from {0} join {1} on {0}.id = {1}.id"

See the repo for more details: https://github.com/multiprocessio/dsq"""


def guess_format(path, explicit=None):
    if explicit:
        return explicit.lower()
    ext = os.path.splitext(path)[1].lower().lstrip(".")
    if ext in ("csv", "tsv", "json", "ndjson", "jsonl", "logfmt", "xlsx", "ods"):
        return ext
    if ext == "log":
        return "logfmt"
    return ext


def normalize_row(value):
    if isinstance(value, dict):
        return value
    if isinstance(value, list):
        return {str(i): v for i, v in enumerate(value)}
    return {"value": value}


def read_csv_text(text, delimiter=","):
    sample = text[:4096]
    if delimiter == ",":
        try:
            dialect = csv.Sniffer().sniff(sample, delimiters=",\t;|")
            delimiter = dialect.delimiter
        except csv.Error:
            pass
    reader = csv.DictReader(io.StringIO(text), delimiter=delimiter)
    return [dict(row) for row in reader]


def read_json_text(text):
    stripped = text.strip()
    if not stripped:
        return []
    try:
        data = json.loads(stripped)
        if isinstance(data, list):
            return [normalize_row(item) for item in data]
        if isinstance(data, dict):
            for key in ("data", "rows", "items", "records"):
                if isinstance(data.get(key), list):
                    return [normalize_row(item) for item in data[key]]
            return [data]
        return [{"value": data}]
    except json.JSONDecodeError:
        rows = []
        for line in stripped.splitlines():
            if line.strip():
                rows.append(normalize_row(json.loads(line)))
        return rows


def parse_logfmt_line(line):
    row = {}
    lexer = shlex.shlex(line, posix=True)
    lexer.whitespace_split = True
    lexer.commenters = ""
    for token in lexer:
        if "=" in token:
            key, value = token.split("=", 1)
            row[key] = value
    return row


def read_logfmt_text(text):
    return [parse_logfmt_line(line) for line in text.splitlines() if line.strip()]


def xml_name(tag):
    return tag.rsplit("}", 1)[-1]


def child_text(elem, names):
    wanted = set(names)
    for child in elem.iter():
        if xml_name(child.tag) in wanted and child.text is not None:
            return child.text
    return ""


def read_xlsx(path):
    with zipfile.ZipFile(path) as z:
        shared = []
        if "xl/sharedStrings.xml" in z.namelist():
            root = ET.fromstring(z.read("xl/sharedStrings.xml"))
            for si in root:
                if xml_name(si.tag) == "si":
                    shared.append("".join(t.text or "" for t in si.iter() if xml_name(t.tag) == "t"))
        rels = {}
        if "xl/_rels/workbook.xml.rels" in z.namelist():
            root = ET.fromstring(z.read("xl/_rels/workbook.xml.rels"))
            for rel in root:
                rid = rel.attrib.get("Id")
                target = rel.attrib.get("Target", "")
                if rid:
                    rels[rid] = "xl/" + target.lstrip("/")
        wb = ET.fromstring(z.read("xl/workbook.xml"))
        sheet_paths = []
        for elem in wb.iter():
            if xml_name(elem.tag) == "sheet":
                rid = elem.attrib.get("{http://schemas.openxmlformats.org/officeDocument/2006/relationships}id")
                if rid in rels:
                    sheet_paths.append(rels[rid])
        if not sheet_paths:
            sheet_paths = sorted(name for name in z.namelist() if name.startswith("xl/worksheets/sheet") and name.endswith(".xml"))
        if not sheet_paths:
            return []
        return read_xlsx_sheet(z, sheet_paths[0], shared)


def cell_ref_col(ref):
    letters = "".join(ch for ch in ref if ch.isalpha())
    if not letters:
        return None
    value = 0
    for ch in letters:
        value = value * 26 + ord(ch.upper()) - ord("A") + 1
    return value - 1


def read_xlsx_sheet(z, path, shared):
    root = ET.fromstring(z.read(path))
    matrix = []
    for row in root.iter():
        if xml_name(row.tag) != "row":
            continue
        values = []
        for cell in row:
            if xml_name(cell.tag) != "c":
                continue
            idx = cell_ref_col(cell.attrib.get("r", ""))
            if idx is None:
                idx = len(values)
            while len(values) <= idx:
                values.append("")
            ctype = cell.attrib.get("t")
            raw = child_text(cell, ("v", "t"))
            if ctype == "s":
                try:
                    raw = shared[int(raw)]
                except (ValueError, IndexError):
                    pass
            values[idx] = raw
        if values:
            matrix.append(values)
    if not matrix:
        return []
    headers = [str(h) for h in matrix[0]]
    rows = []
    for values in matrix[1:]:
        row = {}
        for i, header in enumerate(headers):
            if header:
                row[header] = values[i] if i < len(values) else None
        rows.append(row)
    return rows


def read_ods(path):
    with zipfile.ZipFile(path) as z:
        root = ET.fromstring(z.read("content.xml"))
    table = None
    for elem in root.iter():
        if xml_name(elem.tag) == "table":
            table = elem
            break
    if table is None:
        return []
    matrix = []
    for row_elem in table:
        if xml_name(row_elem.tag) != "table-row":
            continue
        repeat_row = int(row_elem.attrib.get("{urn:oasis:names:tc:opendocument:xmlns:table:1.0}number-rows-repeated", "1"))
        values = []
        for cell in row_elem:
            if xml_name(cell.tag) != "table-cell":
                continue
            repeat_col = int(cell.attrib.get("{urn:oasis:names:tc:opendocument:xmlns:table:1.0}number-columns-repeated", "1"))
            text = ods_cell_text(cell)
            for _ in range(min(repeat_col, 1000)):
                values.append(text)
        if values:
            for _ in range(min(repeat_row, 1000)):
                matrix.append(list(values))
    if not matrix:
        return []
    headers = [str(h) for h in matrix[0]]
    rows = []
    for values in matrix[1:]:
        row = {}
        for i, header in enumerate(headers):
            if header:
                row[header] = values[i] if i < len(values) else None
        rows.append(row)
    return rows


def ods_cell_text(cell):
    parts = []
    for elem in cell.iter():
        if elem is cell:
            continue
        if xml_name(elem.tag) == "s":
            count = int(elem.attrib.get("{urn:oasis:names:tc:opendocument:xmlns:text:1.0}c", "1"))
            parts.append(" " * count)
        if elem.text:
            parts.append(elem.text)
        if elem.tail:
            parts.append(elem.tail)
    return "".join(parts)


def read_rows(path, fmt=None, stdin_text=None):
    actual = guess_format(path, fmt)
    if actual in ("xlsx", "ods") and stdin_text is None:
        try:
            return read_xlsx(path) if actual == "xlsx" else read_ods(path)
        except FileNotFoundError:
            raise RuntimeError(f"open {path}: no such file or directory")
        except zipfile.BadZipFile:
            raise RuntimeError(f"unsupported binary format: {path}")
    if stdin_text is None:
        try:
            with open(path, "r", encoding="utf-8", newline="") as f:
                text = f.read()
        except FileNotFoundError:
            raise RuntimeError(f"open {path}: no such file or directory")
        except UnicodeDecodeError:
            raise RuntimeError(f"unsupported binary format: {path}")
    else:
        text = stdin_text
    if actual == "csv":
        return read_csv_text(text, ",")
    if actual == "tsv":
        return read_csv_text(text, "\t")
    if actual in ("json", "ndjson", "jsonl"):
        return read_json_text(text)
    if actual == "logfmt":
        return read_logfmt_text(text)
    raise RuntimeError(f"Unknown mimetype for file: {path}.")


def all_columns(rows):
    cols = []
    seen = set()
    for row in rows:
        for key in row:
            if key not in seen:
                seen.add(key)
                cols.append(key)
    return cols


def sqlite_type(values):
    for value in values:
        if value is not None:
            if isinstance(value, (int, float)) and not isinstance(value, bool):
                return "REAL" if isinstance(value, float) else "INTEGER"
            if isinstance(value, bool):
                return "INTEGER"
            return "TEXT"
    return "TEXT"


def create_table(conn, name, rows):
    cols = all_columns(rows)
    if not cols:
        cols = ["value"]
    defs = []
    for col in cols:
        defs.append(f'"{col}" {sqlite_type([row.get(col) for row in rows])}')
    conn.execute(f'CREATE TABLE "{name}" ({", ".join(defs)})')
    placeholders = ",".join("?" for _ in cols)
    quoted = ",".join(f'"{col}"' for col in cols)
    for row in rows:
        values = [json.dumps(row.get(col)) if isinstance(row.get(col), (dict, list)) else row.get(col) for col in cols]
        conn.execute(f'INSERT INTO "{name}" ({quoted}) VALUES ({placeholders})', values)
    conn.commit()
    return cols


def rewrite_query(query):
    query = query.replace("{}", "t0")
    query = re.sub(r"\{(\d+)\}", lambda m: f"t{m.group(1)}", query)
    return query


def run_query(datasets, query):
    conn = sqlite3.connect(":memory:")
    conn.row_factory = sqlite3.Row
    for i, rows in enumerate(datasets):
        create_table(conn, f"t{i}", rows)
    cur = conn.execute(rewrite_query(query))
    names = [desc[0] for desc in cur.description]
    return [dict(zip(names, row)) for row in cur.fetchall()]


def json_value(value):
    return value


def print_json(rows):
    encoded = [json.dumps({k: json_value(v) for k, v in row.items()}, separators=(",", ":")) for row in rows]
    sys.stdout.write("[")
    sys.stdout.write(",\n".join(encoded))
    sys.stdout.write("]\n")


def cell_text(value):
    if value is None:
        return ""
    return str(value)


def print_pretty(rows):
    cols = sorted(all_columns(rows))
    if not cols:
        sys.stdout.write("(0 rows)\n")
        return
    widths = {col: len(col) for col in cols}
    for row in rows:
        for col in cols:
            widths[col] = max(widths[col], len(cell_text(row.get(col))))
    sep = "+" + "+".join("-" * (widths[col] + 2) for col in cols) + "+"
    header = "| " + " | ".join(col.ljust(widths[col]) for col in cols) + " |"
    sys.stdout.write(sep + "\n" + header + "\n" + sep + "\n")
    for row in rows:
        cells = []
        for col in cols:
            text = cell_text(row.get(col))
            if isinstance(row.get(col), (int, float)) or re.fullmatch(r"-?\d+(\.\d+)?", text):
                cells.append(text.rjust(widths[col]))
            else:
                cells.append(text.ljust(widths[col]))
        sys.stdout.write("| " + " | ".join(cells) + " |\n")
    sys.stdout.write(sep + "\n")
    sys.stdout.write(f"({len(rows)} {'row' if len(rows) == 1 else 'rows'})\n")


def kind_for(value):
    if value is None:
        return ("scalar", "null")
    if isinstance(value, bool):
        return ("scalar", "bool")
    if isinstance(value, (int, float)):
        return ("scalar", "number")
    if isinstance(value, dict):
        return ("object", None)
    if isinstance(value, list):
        return ("array", None)
    return ("scalar", "string")


def schema_for_values(values):
    kinds = []
    seen = set()
    for value in values:
        rep = kind_for(value)
        if rep not in seen:
            seen.add(rep)
            kinds.append(rep)
    if not kinds:
        kinds = [("scalar", "null")]
    if len(kinds) == 1:
        kind, scalar = kinds[0]
        if kind == "scalar":
            return {"kind": "scalar", "scalar": scalar}
        return {"kind": kind}
    return {"kind": "varied", "varied": [{"kind": k, "scalar": s} if k == "scalar" else {"kind": k} for k, s in kinds]}


def print_schema(rows, pretty=False):
    obj = {col: schema_for_values([row.get(col) for row in rows]) for col in all_columns(rows)}
    schema = {"kind": "array", "array": {"kind": "object", "object": obj}}
    if pretty:
        def walk(node, indent=0):
            pad = "  " * indent
            if node["kind"] == "array":
                sys.stdout.write(pad + "Array of\n")
                walk(node["array"], indent + 1)
            elif node["kind"] == "object":
                sys.stdout.write(pad + "Object of\n")
                for key, value in node["object"].items():
                    sys.stdout.write(pad + "  " + key + " of\n")
                    walk(value, indent + 2)
            elif node["kind"] == "scalar":
                sys.stdout.write(pad + node["scalar"] + "\n")
            else:
                sys.stdout.write(pad + "varied\n")
        walk(schema)
    else:
        sys.stdout.write(json.dumps(schema, indent=2) + "\n")


def parse_args(argv):
    pretty = False
    schema = False
    cache = False
    stream_format = None
    query_file = None
    files = []
    query = None
    i = 0
    while i < len(argv):
        arg = argv[i]
        if arg in ("--help", "-h"):
            print(HELP)
            raise SystemExit(0)
        if arg == "--version":
            print("dsq latest")
            raise SystemExit(0)
        if arg in ("-p", "--pretty"):
            pretty = True
        elif arg in ("-C", "--cache"):
            cache = True
        elif arg == "--schema":
            schema = True
        elif arg in ("-s", "--source"):
            i += 1
            if i >= len(argv):
                raise RuntimeError("missing argument for -s")
            stream_format = argv[i]
        elif arg in ("-f", "--file"):
            i += 1
            if i >= len(argv):
                raise RuntimeError("missing argument for -f")
            query_file = argv[i]
        elif i == len(argv) - 1 and (files or stream_format) and (arg.lower().lstrip().startswith("select") or arg.lower().lstrip().startswith("with")):
            query = arg
        else:
            files.append(arg)
        i += 1
    if query_file:
        try:
            with open(query_file, "r", encoding="utf-8") as f:
                query = f.read().strip()
        except FileNotFoundError:
            raise RuntimeError(f"open {query_file}: no such file or directory")
    return pretty, schema, cache, stream_format, files, query


def main(argv):
    try:
        pretty, schema, cache, stream_format, files, query = parse_args(argv)
        datasets = []
        if stream_format:
            datasets.append(read_rows("stdin", stream_format, sys.stdin.read()))
        else:
            if not files:
                raise RuntimeError("No input files.")
            for path in files:
                datasets.append(read_rows(path))
        if schema:
            print_schema(datasets[0], pretty)
            return 0
        if query is None:
            rows = datasets[0]
        else:
            rows = run_query(datasets, query)
        if cache:
            print("Cache invalid, re-import required.")
        if pretty:
            print_pretty(rows)
        else:
            print_json(rows)
        return 0
    except sqlite3.Error as e:
        print(str(e), file=sys.stderr)
        return 1
    except RuntimeError as e:
        print(str(e), file=sys.stderr)
        return 1
    except json.JSONDecodeError as e:
        print(str(e), file=sys.stderr)
        return 1


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
