import os
import shutil
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
CMD = [sys.executable, str(ROOT / "src" / "mdbook_clone.py")]


class MdbookCloneTests(unittest.TestCase):
    def run_cmd(self, args, cwd):
        return subprocess.run(
            CMD + args,
            cwd=cwd,
            text=True,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
        )

    def test_version_matches_documented_binary(self):
        with tempfile.TemporaryDirectory() as tmp:
            result = self.run_cmd(["--version"], tmp)
        self.assertEqual(result.returncode, 0)
        self.assertEqual(result.stdout.strip(), "mdbook v0.5.0-alpha.1")

    def test_init_writes_boilerplate_book(self):
        with tempfile.TemporaryDirectory() as tmp:
            result = self.run_cmd(
                ["init", "--title", "My Book", "--ignore", "git", "--force", "demo"],
                tmp,
            )
            root = Path(tmp) / "demo"
            self.assertEqual(result.returncode, 0, result.stderr)
            self.assertEqual(result.stdout, "\nAll done, no errors...\n")
            self.assertEqual((root / "book.toml").read_text(), '[book]\nauthors = []\nlanguage = "en"\nsrc = "src"\ntitle = "My Book"\n')
            self.assertEqual((root / "src" / "SUMMARY.md").read_text(), "# Summary\n\n- [Chapter 1](./chapter_1.md)\n")
            self.assertEqual((root / "src" / "chapter_1.md").read_text(), "# Chapter 1\n")
            self.assertEqual((root / ".gitignore").read_text(), "book\n")

    def test_build_renders_summary_chapters_and_copies_assets(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp) / "book"
            (root / "src" / "nested").mkdir(parents=True)
            (root / "book.toml").write_text('[book]\ntitle = "T"\nsrc = "src"\n[build]\nbuild-dir = "out"\n')
            (root / "src" / "SUMMARY.md").write_text(
                "# Summary\n\n[Intro](intro.md)\n\n- [First](first.md)\n  - [Second](nested/second.md)\n"
            )
            (root / "src" / "intro.md").write_text("# Intro\nhello *world*\n")
            (root / "src" / "first.md").write_text("# First\n[go](nested/second.md)\n")
            (root / "src" / "nested" / "second.md").write_text("# Second\n")
            (root / "src" / "asset.txt").write_text("asset\n")

            result = self.run_cmd(["build"], root)

            self.assertEqual(result.returncode, 0, result.stderr)
            self.assertTrue((root / "out" / ".nojekyll").exists())
            self.assertEqual((root / "out" / "asset.txt").read_text(), "asset\n")
            first = (root / "out" / "first.html").read_text()
            self.assertIn("<title>First - T</title>", first)
            self.assertIn('<h1 id="first"><a class="header" href="#first">First</a></h1>', first)
            self.assertIn('<a href="nested/second.html">go</a>', first)
            toc = (root / "out" / "toc.html").read_text()
            self.assertIn('<a href="intro.html"', toc)
            self.assertIn("<strong aria-hidden=\"true\">1.</strong> First", toc)
            self.assertIn("<strong aria-hidden=\"true\">1.1.</strong> Second", toc)

    def test_clean_removes_build_directory(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            (root / "book").mkdir()
            (root / "book" / "x").write_text("data")
            result = self.run_cmd(["clean"], root)
            self.assertEqual(result.returncode, 0, result.stderr)
            self.assertFalse((root / "book").exists())
            self.assertIn("Removed", result.stdout)

    def test_init_uses_existing_summary_to_create_missing_chapters(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp) / "demo"
            (root / "src").mkdir(parents=True)
            (root / "src" / "SUMMARY.md").write_text("# Summary\n\n- [A](a.md)\n  - [B](nested/b.md)\n- [Draft]()\n")

            result = self.run_cmd(["init", "--title", "T", "--ignore", "none", "--force", str(root)], tmp)

            self.assertEqual(result.returncode, 0, result.stderr)
            self.assertEqual((root / "src" / "SUMMARY.md").read_text(), "# Summary\n\n- [A](a.md)\n  - [B](nested/b.md)\n- [Draft]()\n")
            self.assertEqual((root / "src" / "a.md").read_text(), "# A\n")
            self.assertEqual((root / "src" / "nested" / "b.md").read_text(), "# B\n")
            self.assertFalse((root / "src" / "Draft").exists())

    def test_test_command_fails_for_invalid_rust_code_block(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            (root / "src").mkdir()
            (root / "book.toml").write_text('[book]\ntitle = "T"\nsrc = "src"\n')
            (root / "src" / "SUMMARY.md").write_text("# Summary\n\n- [Bad](bad.md)\n")
            (root / "src" / "bad.md").write_text("# Bad\n\n```rust\nlet = ;\n```\n")

            result = self.run_cmd(["test"], root)

            self.assertNotEqual(result.returncode, 0)
            self.assertIn("expected pattern", result.stderr)


if __name__ == "__main__":
    unittest.main()
