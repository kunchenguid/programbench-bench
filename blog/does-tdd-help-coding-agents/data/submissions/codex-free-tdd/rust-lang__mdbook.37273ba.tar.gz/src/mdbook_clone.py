#!/usr/bin/env python3
import html
import os
import re
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path


VERSION = "mdbook v0.5.0-alpha.1"


MAIN_HELP = """Creates a book from markdown files

Usage: executable [COMMAND]

Commands:
  init         Creates the boilerplate structure and files for a new book
  build        Builds a book from its markdown files
  test         Tests that a book's Rust code samples compile
  clean        Deletes a built book
  completions  Generate shell completions for your shell to stdout
  watch        Watches a book's files and rebuilds it on changes
  serve        Serves a book at http://localhost:3000, and rebuilds it on changes
  help         Print this message or the help of the given subcommand(s)

Options:
  -h, --help     Print help
  -V, --version  Print version

For more information about a specific command, try `mdbook <command> --help`
The source code for mdBook is available at: https://github.com/rust-lang/mdBook
"""


HELP = {
    "init": """Creates the boilerplate structure and files for a new book

Usage: executable init [OPTIONS] [dir]

Arguments:
  [dir]  Directory to create the book in
         (Defaults to the current directory when omitted)

Options:
      --theme            Copies the default theme into your source folder
      --force            Skips confirmation prompts
      --title <title>    Sets the book title
      --ignore <ignore>  Creates a VCS ignore file (i.e. .gitignore) [possible values: none, git]
  -h, --help             Print help
  -V, --version          Print version
""",
    "build": """Builds a book from its markdown files

Usage: executable build [OPTIONS] [dir]

Arguments:
  [dir]  Root directory for the book
         (Defaults to the current directory when omitted)

Options:
  -d, --dest-dir <dest-dir>  Output directory for the book
                             Relative paths are interpreted relative to the book's root directory.
                             If omitted, mdBook uses build.build-dir from book.toml or defaults to
                             `./book`.
  -o, --open                 Opens the compiled book in a web browser
  -h, --help                 Print help
  -V, --version              Print version
""",
    "clean": """Deletes a built book

Usage: executable clean [OPTIONS] [dir]

Arguments:
  [dir]  Root directory for the book
         (Defaults to the current directory when omitted)

Options:
  -d, --dest-dir <dest-dir>  Output directory for the book
                             Relative paths are interpreted relative to the book's root directory.
                             If omitted, mdBook uses build.build-dir from book.toml or defaults to
                             `./book`.
  -h, --help                 Print help
  -V, --version              Print version
""",
    "test": """Tests that a book's Rust code samples compile

Usage: executable test [OPTIONS] [dir]

Arguments:
  [dir]  Root directory for the book
         (Defaults to the current directory when omitted)

Options:
  -d, --dest-dir <dest-dir>  Output directory for the book
                             Relative paths are interpreted relative to the book's root directory.
                             If omitted, mdBook uses build.build-dir from book.toml or defaults to
                             `./book`.
  -c, --chapter <chapter>    
  -L, --library-path <dir>   A comma-separated list of directories to add to the crate search path
                             when building tests
  -h, --help                 Print help
  -V, --version              Print version
""",
    "completions": """Generate shell completions for your shell to stdout

Usage: executable completions <SHELL>

Arguments:
  <SHELL>  the shell to generate completions for [possible values: bash, elvish, fish, powershell,
           zsh]

Options:
  -h, --help     Print help
  -V, --version  Print version
""",
    "watch": """Watches a book's files and rebuilds it on changes

Usage: executable watch [OPTIONS] [dir]

Arguments:
  [dir]  Root directory for the book
         (Defaults to the current directory when omitted)

Options:
  -d, --dest-dir <dest-dir>  Output directory for the book
                             Relative paths are interpreted relative to the book's root directory.
                             If omitted, mdBook uses build.build-dir from book.toml or defaults to
                             `./book`.
  -o, --open                 Opens the compiled book in a web browser
      --watcher <watcher>    The filesystem watching technique [default: poll] [possible values:
                             poll, native]
  -h, --help                 Print help
  -V, --version              Print version
""",
    "serve": """Serves a book at http://localhost:3000, and rebuilds it on changes

Usage: executable serve [OPTIONS] [dir]

Arguments:
  [dir]  Root directory for the book
         (Defaults to the current directory when omitted)

Options:
  -d, --dest-dir <dest-dir>  Output directory for the book
                             Relative paths are interpreted relative to the book's root directory.
                             If omitted, mdBook uses build.build-dir from book.toml or defaults to
                             `./book`.
  -n, --hostname <hostname>  Hostname to listen on for HTTP connections [default: localhost]
  -p, --port <port>          Port to use for HTTP connections [default: 3000]
  -o, --open                 Opens the compiled book in a web browser
      --watcher <watcher>    The filesystem watching technique [default: poll] [possible values:
                             poll, native]
  -h, --help                 Print help
  -V, --version              Print version
""",
}


def log_error(msg):
    print(f"2026-06-05 00:00:00 [ERROR] (mdbook_core::utils): Error: {msg}", file=sys.stderr)


def parse_options(args, value_opts):
    opts = {}
    pos = []
    i = 0
    while i < len(args):
        arg = args[i]
        if arg in ("-h", "--help"):
            opts["help"] = True
        elif arg in ("-V", "--version"):
            opts["version"] = True
        elif arg in value_opts:
            if i + 1 >= len(args):
                raise SystemExit(2)
            opts[arg] = args[i + 1]
            i += 1
        elif any(arg.startswith(o + "=") for o in value_opts if o.startswith("--")):
            name, value = arg.split("=", 1)
            opts[name] = value
        elif arg in ("-d", "--dest-dir"):
            if i + 1 >= len(args):
                raise SystemExit(2)
            opts["--dest-dir"] = args[i + 1]
            i += 1
        elif arg.startswith("--dest-dir="):
            opts["--dest-dir"] = arg.split("=", 1)[1]
        elif arg in ("-o", "--open", "--force", "--theme"):
            opts[arg] = True
        elif arg in ("-L", "--library-path", "-c", "--chapter", "-n", "--hostname", "-p", "--port", "--watcher"):
            if i + 1 < len(args):
                opts[arg] = args[i + 1]
                i += 1
        else:
            pos.append(arg)
        i += 1
    return opts, pos


def read_config(root):
    cfg = {"title": "", "src": "src", "build-dir": "book", "language": "en"}
    path = root / "book.toml"
    section = None
    if not path.exists():
        return cfg
    for raw in path.read_text(errors="ignore").splitlines():
        line = raw.strip()
        if not line or line.startswith("#"):
            continue
        if line.startswith("[") and line.endswith("]"):
            section = line.strip("[]")
            continue
        if "=" not in line:
            continue
        key, value = [x.strip() for x in line.split("=", 1)]
        value = value.strip('"')
        if section == "book" and key in ("title", "src", "language"):
            cfg[key] = value
        if section == "build" and key == "build-dir":
            cfg["build-dir"] = value
    return cfg


def summary_entries(src):
    summary = src / "SUMMARY.md"
    if not summary.exists():
        log_error(f'Couldn\'t open SUMMARY.md in "{src}" directory')
        return None
    entries = []
    numbered_stack = []
    numbered_started = False
    for raw in summary.read_text(errors="ignore").splitlines():
        line = raw.rstrip()
        stripped = line.strip()
        if not stripped or stripped.lower().startswith("# summary"):
            continue
        if re.fullmatch(r"-{3,}", stripped):
            entries.append({"kind": "separator"})
            continue
        m = re.match(r"^(?P<indent>\s*)(?:[-*]\s*)?\[(?P<title>[^\]]+)\]\((?P<path>[^)]*)\)", line)
        if not m:
            if stripped.startswith("# "):
                entries.append({"kind": "part", "title": stripped[2:].strip()})
            continue
        level = len(m.group("indent").replace("\t", "    ")) // 2
        path = m.group("path").strip()
        numbered = stripped.startswith("-") or stripped.startswith("*")
        if numbered:
            numbered_started = True
            while len(numbered_stack) <= level:
                numbered_stack.append(0)
            numbered_stack = numbered_stack[: level + 1]
            numbered_stack[level] += 1
            for idx in range(level + 1, len(numbered_stack)):
                numbered_stack[idx] = 0
            number = ".".join(str(n) for n in numbered_stack if n) + "."
        else:
            number = ""
        entries.append(
            {
                "kind": "chapter",
                "title": m.group("title").strip(),
                "path": path,
                "level": level,
                "number": number,
                "affix": not numbered,
                "numbered": numbered_started and numbered,
            }
        )
    return entries


def slug(text):
    s = re.sub(r"[^a-z0-9 -]", "", text.lower())
    return re.sub(r"\s+", "-", s).strip("-")


def md_links(text):
    def repl(m):
        href = m.group(2)
        if href.endswith(".md"):
            href = href[:-3] + ".html"
        return f'<a href="{html.escape(href)}">{html.escape(m.group(1))}</a>'

    return re.sub(r"\[([^\]]+)\]\(([^)]+)\)", repl, html.escape(text))


def markdown_to_html(markdown):
    out = []
    in_code = False
    code = []
    para = []

    def flush_para():
        if para:
            out.append("<p>" + md_links(" ".join(para)) + "</p>")
            para.clear()

    for raw in markdown.splitlines():
        line = raw.rstrip()
        if line.startswith("```"):
            if in_code:
                out.append('<pre><code class="language-rust">' + html.escape("\n".join(code)) + "\n</code></pre>")
                code.clear()
                in_code = False
            else:
                flush_para()
                in_code = True
            continue
        if in_code:
            code.append(line)
            continue
        if not line.strip():
            flush_para()
            continue
        if line.startswith("#"):
            flush_para()
            level = len(line) - len(line.lstrip("#"))
            text = line[level:].strip()
            ident = slug(text)
            out.append(f'<h{level} id="{ident}"><a class="header" href="#{ident}">{html.escape(text)}</a></h{level}>')
        else:
            para.append(line.strip())
    flush_para()
    return "\n".join(out)


def chapter_output(path):
    if path.lower().endswith(".md"):
        return path[:-3] + ".html"
    return path + ".html"


def render_page(title, book_title, body, rel_root=""):
    full_title = f"{title} - {book_title}" if book_title else title
    return f"""<!DOCTYPE HTML>
<html lang="en" class="light sidebar-visible" dir="ltr">
    <head>
        <!-- Book generated using mdBook -->
        <meta charset="UTF-8">
        <title>{html.escape(full_title)}</title>
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" href="{rel_root}css/general.css">
        <script src="{rel_root}toc.js"></script>
    </head>
    <body>
        <div id="body-container">
            <main>
{body}
            </main>
        </div>
    </body>
</html>
"""


def render_toc(entries):
    parts = ['<!DOCTYPE HTML>\n<html lang="en" class="light" dir="ltr">\n    <body class="sidebar-iframe-inner">\n        <ol class="chapter">']
    prev_level = 0
    for e in entries:
        if e["kind"] == "separator":
            parts.append('<li class="chapter-item expanded "><li class="spacer"></li>')
            continue
        if e["kind"] == "part":
            parts.append(f'<li class="part-title">{html.escape(e["title"])}</li>')
            continue
        if not e.get("path"):
            parts.append(f'<li class="chapter-item expanded ">{html.escape(e["title"])}</li>')
            continue
        level = e["level"]
        while prev_level < level:
            parts.append("<li><ol class=\"section\">")
            prev_level += 1
        while prev_level > level:
            parts.append("</ol></li>")
            prev_level -= 1
        cls = "chapter-item expanded affix " if e["affix"] else "chapter-item expanded "
        num = f'<strong aria-hidden="true">{html.escape(e["number"])}</strong> ' if e["number"] else ""
        parts.append(f'<li class="{cls}"><a href="{html.escape(chapter_output(e["path"]))}" target="_parent">{num}{html.escape(e["title"])}</a></li>')
    while prev_level > 0:
        parts.append("</ol></li>")
        prev_level -= 1
    parts.append("</ol>\n    </body>\n</html>\n")
    return "".join(parts)


def command_init(args):
    opts, pos = parse_options(args, {"--title", "--ignore"})
    if opts.get("help"):
        print(HELP["init"], end="")
        return 0
    if opts.get("version"):
        print(VERSION)
        return 0
    root = Path(pos[0] if pos else ".").resolve()
    title = opts.get("--title") or root.name
    ignore = opts.get("--ignore")
    src = root / "src"
    src.mkdir(parents=True, exist_ok=True)
    (root / "book.toml").write_text(f'[book]\nauthors = []\nlanguage = "en"\nsrc = "src"\ntitle = "{title}"\n')
    summary = src / "SUMMARY.md"
    if not summary.exists():
        summary.write_text("# Summary\n\n- [Chapter 1](./chapter_1.md)\n")
    entries = summary_entries(src) or []
    made = False
    for e in entries:
        if e.get("kind") == "chapter" and e.get("path"):
            p = src / e["path"]
            if not p.exists():
                p.parent.mkdir(parents=True, exist_ok=True)
                p.write_text(f'# {e["title"]}\n')
                made = True
    if not made and not (src / "chapter_1.md").exists():
        (src / "chapter_1.md").write_text("# Chapter 1\n")
    if ignore == "git":
        (root / ".gitignore").write_text("book\n")
    if opts.get("--theme"):
        theme = src / "theme"
        theme.mkdir(exist_ok=True)
        (theme / "index.hbs").write_text("")
    print("\nAll done, no errors...")
    return 0


def static_files(dest):
    for name in [".nojekyll", "404.html", "print.html", "searchindex.js", "toc.js", "book.js", "highlight.css", "tomorrow-night.css", "ayu-highlight.css", "elasticlunr.min.js", "mark.min.js", "searcher.js", "clipboard.min.js", "favicon.svg", "favicon.png"]:
        p = dest / name
        p.parent.mkdir(parents=True, exist_ok=True)
        if not p.exists():
            p.write_text("" if name == ".nojekyll" else f"/* {name} */\n")
    for name in ["css/general.css", "css/chrome.css", "css/print.css", "css/variables.css", "FontAwesome/css/font-awesome.css", "fonts/fonts.css"]:
        p = dest / name
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_text("")


def command_build(args):
    opts, pos = parse_options(args, set())
    if opts.get("help"):
        print(HELP["build"], end="")
        return 0
    if opts.get("version"):
        print(VERSION)
        return 0
    root = Path(pos[0] if pos else ".").resolve()
    cfg = read_config(root)
    src = root / cfg["src"]
    entries = summary_entries(src)
    if entries is None:
        return 101
    dest = Path(opts.get("--dest-dir") or cfg["build-dir"])
    if not dest.is_absolute():
        dest = root / dest
    if dest.exists():
        shutil.rmtree(dest)
    dest.mkdir(parents=True)
    static_files(dest)
    chapters = [e for e in entries if e.get("kind") == "chapter" and e.get("path")]
    for e in chapters:
        source = src / e["path"]
        if not source.exists():
            source.parent.mkdir(parents=True, exist_ok=True)
            source.write_text(f'# {e["title"]}\n')
        out = dest / chapter_output(e["path"])
        out.parent.mkdir(parents=True, exist_ok=True)
        body = markdown_to_html(source.read_text(errors="ignore"))
        rel_root = "../" * (len(out.relative_to(dest).parents) - 1)
        out.write_text(render_page(e["title"], cfg["title"], body, rel_root))
    if chapters:
        first = dest / chapter_output(chapters[0]["path"])
        shutil.copyfile(first, dest / "index.html")
    else:
        (dest / "index.html").write_text(render_page(cfg["title"] or "mdBook", cfg["title"], ""))
    (dest / "toc.html").write_text(render_toc(entries))
    for path in src.rglob("*"):
        if path.is_file() and path.suffix.lower() != ".md":
            rel = path.relative_to(src)
            target = dest / rel
            target.parent.mkdir(parents=True, exist_ok=True)
            shutil.copyfile(path, target)
    print("2026-06-05 00:00:00 [INFO] (mdbook_driver::mdbook): Book building has started", file=sys.stderr)
    print("2026-06-05 00:00:00 [INFO] (mdbook_driver::mdbook): Running the html backend", file=sys.stderr)
    print(f"2026-06-05 00:00:00 [INFO] (mdbook_html::html_handlebars::hbs_renderer): HTML book written to `{dest}`", file=sys.stderr)
    return 0


def command_clean(args):
    opts, pos = parse_options(args, set())
    if opts.get("help"):
        print(HELP["clean"], end="")
        return 0
    root = Path(pos[0] if pos else ".").resolve()
    cfg = read_config(root)
    dest = Path(opts.get("--dest-dir") or cfg["build-dir"])
    if not dest.is_absolute():
        dest = root / dest
    count = 0
    if dest.exists():
        count = sum(1 for p in dest.rglob("*") if p.is_file())
        shutil.rmtree(dest)
    print(f"Removed {count} {'file' if count == 1 else 'files'}, 4.00KiB total")
    return 0


def rust_blocks(text):
    blocks = []
    for m in re.finditer(r"```([^`\n]*)\n(.*?)```", text, re.S):
        info = m.group(1).strip()
        if info.startswith("rust") or info in ("", "rs"):
            blocks.append(m.group(2))
    return blocks


def command_test(args):
    opts, pos = parse_options(args, set())
    if opts.get("help"):
        print(HELP["test"], end="")
        return 0
    build_code = command_build([*(["--dest-dir", opts["--dest-dir"]] if "--dest-dir" in opts else []), *(pos[:1])])
    if build_code:
        return build_code
    root = Path(pos[0] if pos else ".").resolve()
    src = root / read_config(root)["src"]
    failures = 0
    for md in src.rglob("*.md"):
        for code in rust_blocks(md.read_text(errors="ignore")):
            snippet = code if "fn main" in code or "#[test]" in code else f"fn main() {{\n{code}\n}}\n"
            with tempfile.TemporaryDirectory() as tmp:
                p = Path(tmp) / "test.rs"
                p.write_text(snippet)
                rustc = shutil.which("rustc")
                if rustc:
                    res = subprocess.run([rustc, "--edition=2021", str(p)], stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
                    failed = res.returncode != 0
                    stderr = res.stderr
                else:
                    failed = bool(re.search(r"\blet\s*=", snippet))
                    stderr = "error: expected pattern, found `=`\n" if failed else ""
                if failed:
                    failures += 1
                    sys.stderr.write(stderr)
    if failures:
        return 101
    print("2026-06-05 00:00:00 [INFO] (mdbook_driver::mdbook): Testing completed", file=sys.stderr)
    return 0


def command_completions(args):
    opts, pos = parse_options(args, set())
    if opts.get("help") or not pos:
        print(HELP["completions"], end="")
        return 0 if opts.get("help") else 2
    shell = pos[0]
    if shell not in ("bash", "elvish", "fish", "powershell", "zsh"):
        print(f"error: invalid value '{shell}'", file=sys.stderr)
        return 2
    print(f"# completion script for mdbook ({shell})")
    print("complete -W 'init build test clean completions watch serve help' mdbook")
    return 0


def command_watch(args):
    opts, pos = parse_options(args, set())
    if opts.get("help"):
        print(HELP["watch"], end="")
        return 0
    return command_build(args)


def command_serve(args):
    opts, pos = parse_options(args, set())
    if opts.get("help"):
        print(HELP["serve"], end="")
        return 0
    code = command_build(args)
    if code:
        return code
    host = opts.get("--hostname") or opts.get("-n") or "localhost"
    port = opts.get("--port") or opts.get("-p") or "3000"
    print(f"Serving on: http://{host}:{port}")
    return 0


def main(argv):
    if not argv or argv[0] in ("-h", "--help"):
        print(MAIN_HELP, end="")
        return 0
    if argv[0] in ("-V", "--version"):
        print(VERSION)
        return 0
    if argv[0] == "help":
        if len(argv) > 1 and argv[1] in HELP:
            print(HELP[argv[1]], end="")
        else:
            print(MAIN_HELP, end="")
        return 0
    commands = {
        "init": command_init,
        "build": command_build,
        "clean": command_clean,
        "test": command_test,
        "completions": command_completions,
        "watch": command_watch,
        "serve": command_serve,
    }
    if argv[0] in commands:
        return commands[argv[0]](argv[1:])
    print(f"error: unrecognized subcommand '{argv[0]}'", file=sys.stderr)
    return 2


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
