#!/usr/bin/env python3
import argparse
import json
import os
import random
import re
import string
import sys
import time
import urllib.error
import urllib.parse
import urllib.request
from dataclasses import dataclass


HELP = """Fast directory scanning and scraping tool

Usage: executable [OPTIONS] <uri|--uri-file <uri-file>|--uri <uri>>

Arguments:
  [uri]
          The URI of the host to scan, optionally supports basic auth with
          http://user:pass@host:port

Options:
  -u, --uri <uri>
          Additional hosts to scan [aliases: url]
  -U, --uri-file <uri-file>
          The filename of a file containing a list of URIs to scan - cookies and
          headers set will be applied to all URIs [aliases: url-file]
      --verb <http_verb>
          Specify which HTTP verb to use
           [default: get] [possible values: get, head, post]
  -w, --wordlist <wordlist>
          Sets which wordlist to use, defaults to dirble_wordlist.txt in the same
          folder as the executable
  -p, --prefixes <prefixes>...
          Provides comma separated prefixes to extend queries with
  -P, --prefix-file <prefix-file>
          The name of a file containing extensions to extend queries with, one
          per line
  -x, --extensions <extensions>...
          Provides comma separated extensions to extend queries with
  -X, --extension-file <extension-file>
          The name of a file containing extensions to extend queries with, one
          per line
      --ext-sub
          Indicates whether the string "%EXT%" in a wordlist file should be 
          substituted with the current extension
  -f, --force-extension
          Only scan with provided extensions
  -k, --ignore-cert
          Ignore the certificate validity for HTTPS
      --show-htaccess
          Enable display of items containing .ht when they return 403 responses
      --timeout <timeout>
          Maximum time to wait for a response before giving up, given in seconds
           [default: 5]
      --max-errors <max_errors>
          The number of consecutive errors a thread can have before it exits,
          set to 0 to disable [default: 5]
      --json-file <json_file>
          Sets a file to write JSON output to [aliases: oJ]
      --no-color
          Disable coloring of terminal output
  -o, --output-file <output_file>
          Sets the file to write the report to [aliases: oN]
      --xml-file <xml_file>
          Sets a file to write XML output to [aliases: oX]
      --hide-lengths <length_blacklist>...
          Specify length ranges to hide, e.g. --hide-lengths 348,500-700
      --output-all <output_all>
          Stores all output types respectively as .txt, .json and .xml [aliases: oA]
      --burp
          Sets the proxy to use the default burp proxy values
          (http://localhost:8080)
      --no-proxy
          Disables proxy use even if there is a system proxy
      --proxy <proxy>
          The proxy address to use, including type and port, can also include a
          username and password in the form 
          "http://username:password@proxy_url:proxy_port"
  -t, --max-threads <max-threads>
          Sets the maximum number of request threads that will be spawned [default: 10]
  -T, --wordlist-split <wordlist_split>
          The number of threads to run for each folder/extension combo [default: 3]
  -z, --throttle <milliseconds>
          Time each thread will wait between requests, given in milliseconds
      --username <username>
          Sets the username to authenticate with
      --password <password>
          Sets the password to authenticate with
  -l, --scan-listable
          Scan listable directories
      --max-recursion-depth <max_recursion_depth>
          Sets the maximum directory depth to recurse to, 0 will disable
          recursion
  -r, --disable-recursion
          Disable discovered subdirectory scanning
      --scrape-listable
          Enable scraping of listable directories for urls, often produces large
          amounts of output
  -a, --user-agent <user_agent>
          Set the user-agent provided with requests, by default it isn't set
  -c, --cookie <cookie>
          Provide a cookie in the form "name=value", can be used multiple times
  -H, --header <header>
          Provide an arbitrary header in the form "header:value" - headers with
          no value must end in a semicolon
  -S, --silent
          Don't output information during the scan, only output the report at
          the end.
  -v, --verbose...
          Increase the verbosity level. Use twice for full verbosity.
  -B, --code-blacklist <code_blacklist>...
          Provide a comma separated list of response codes to not show in output
      --disable-validator
          Disable automatic detection of not found codes
  -W, --code-whitelist <code_whitelist>...
          Provide a comma separated list of response codes to show in output,
          also disables detection of not found codes
      --scan-401
          Scan folders even if they return 401 - Unauthorized frequently
      --scan-403
          Scan folders if they return 403 - Forbidden frequently
  -h, --help
          Print help
  -V, --version
          Print version

OUTPUT FORMAT:
    + [url] - File
    D [url] - Directory
    L [url] - Listable Directory

EXAMPLE USE:
    - Run against a website using the default dirble_wordlist.txt from the
      current directory:
        dirble [address]

    - Run with a different wordlist and including .php and .html extensions:
        dirble [address] -w example_wordlist.txt -x .php,.html

    - With listable directory scraping enabled:
        dirble [address] --scrape-listable

    - Providing a list of extensions and a list of URIs:
        dirble [address] -X wordlists/web.lst -U uri-list.txt

    - Providing multiple hosts to scan via command line:
        dirble [address] -u [address] -u [address]
"""


@dataclass
class Finding:
    url: str
    code: int
    size: int
    is_directory: bool = False
    is_listable: bool = False
    redirect_url: str = ""
    found_from_listable: bool = False


class NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        return None


def split_values(values):
    out = []
    for value in values or []:
        for part in value.split(","):
            part = part.strip()
            if part:
                out.append(part)
    return out


def normalize_base(uri):
    parsed = urllib.parse.urlparse(uri)
    if not parsed.scheme or not parsed.netloc:
        raise ValueError("relative URL without a base")
    return uri.rstrip("/") + "/"


def read_lines(path):
    with open(path, encoding="utf-8") as fh:
        return [line.strip() for line in fh if line.strip() and not line.startswith("#")]


def build_parser():
    p = argparse.ArgumentParser(add_help=False, usage=argparse.SUPPRESS)
    p.add_argument("pos_uri", nargs="?")
    p.add_argument("-u", "--uri", "--url", dest="uris", action="append")
    p.add_argument("-U", "--uri-file", "--url-file", dest="uri_file")
    p.add_argument("--verb", default="get", choices=["get", "head", "post"])
    p.add_argument("-w", "--wordlist")
    p.add_argument("-p", "--prefixes", nargs="*", action="append")
    p.add_argument("-P", "--prefix-file")
    p.add_argument("-x", "--extensions", nargs="*", action="append")
    p.add_argument("-X", "--extension-file")
    p.add_argument("--ext-sub", action="store_true")
    p.add_argument("-f", "--force-extension", action="store_true")
    p.add_argument("-k", "--ignore-cert", action="store_true")
    p.add_argument("--show-htaccess", action="store_true")
    p.add_argument("--timeout", type=float, default=5)
    p.add_argument("--max-errors", type=int, default=5)
    p.add_argument("--json-file", "--oJ", dest="json_file")
    p.add_argument("--no-color", action="store_true")
    p.add_argument("-o", "--output-file", "--oN", dest="output_file")
    p.add_argument("--xml-file", "--oX", dest="xml_file")
    p.add_argument("--hide-lengths", nargs="*", action="append")
    p.add_argument("--output-all", "--oA", dest="output_all")
    p.add_argument("--burp", action="store_true")
    p.add_argument("--no-proxy", action="store_true")
    p.add_argument("--proxy")
    p.add_argument("-t", "--max-threads", default=10)
    p.add_argument("-T", "--wordlist-split", default=3)
    p.add_argument("-z", "--throttle", type=int, default=0)
    p.add_argument("--username")
    p.add_argument("--password")
    p.add_argument("-l", "--scan-listable", action="store_true")
    p.add_argument("--max-recursion-depth", type=int, default=1)
    p.add_argument("-r", "--disable-recursion", action="store_true")
    p.add_argument("--scrape-listable", action="store_true")
    p.add_argument("-a", "--user-agent")
    p.add_argument("-c", "--cookie", action="append")
    p.add_argument("-H", "--header", action="append")
    p.add_argument("-S", "--silent", action="store_true")
    p.add_argument("-v", "--verbose", action="count", default=0)
    p.add_argument("-B", "--code-blacklist", nargs="*", action="append")
    p.add_argument("--disable-validator", action="store_true")
    p.add_argument("-W", "--code-whitelist", nargs="*", action="append")
    p.add_argument("--scan-401", action="store_true")
    p.add_argument("--scan-403", action="store_true")
    p.add_argument("-h", "--help", action="store_true")
    p.add_argument("-V", "--version", action="store_true")
    return p


def parse_args(argv):
    if "--help" in argv or "-h" in argv or not argv:
        print(HELP, end="")
        return None
    if "--version" in argv or "-V" in argv:
        print("Dirble 1.4.2 (commit d520c82, build 2026-04-17)")
        return None
    parser = build_parser()
    try:
        return parser.parse_args(argv)
    except SystemExit:
        return "parse_error"


def request(url, args, method=None):
    method = (method or args.verb).upper()
    headers = {}
    if args.user_agent:
        headers["User-Agent"] = args.user_agent
    if args.cookie:
        headers["Cookie"] = "; ".join(args.cookie)
    for header in args.header or []:
        if ":" in header:
            name, value = header.split(":", 1)
            headers[name.strip()] = value.strip()
        elif header.endswith(";"):
            headers[header[:-1]] = ""
    req = urllib.request.Request(url, method=method, headers=headers)
    opener = urllib.request.build_opener(NoRedirect)
    try:
        with opener.open(req, timeout=args.timeout) as resp:
            data = b"" if method == "HEAD" else resp.read()
            size = int(resp.headers.get("Content-Length") or len(data))
            return resp.status, size, resp.headers, data, ""
    except urllib.error.HTTPError as e:
        data = b"" if method == "HEAD" else e.read()
        size = int(e.headers.get("Content-Length") or len(data))
        return e.code, size, e.headers, data, ""
    except Exception as e:
        return 0, 0, {}, b"", str(e)


def random_path(length):
    alphabet = string.ascii_letters + string.digits
    return "".join(random.choice(alphabet) for _ in range(length))


def validate(base, args):
    if args.disable_validator or split_values(args.code_whitelist):
        return set()
    codes = set()
    for length in (10, 20, 30):
        code, _size, _headers, _data, err = request(base + random_path(length), args)
        if err:
            print(f"Curl error after requesting {base + random_path(length)} : {err}")
        elif code:
            codes.add(code)
    if codes and not args.silent:
        joined = ",".join(str(c) for c in sorted(codes))
        print(f"[INFO] Detected nonexistent paths for {base} are (CODE:{joined})")
    return codes


def expanded_entries(words, args):
    exts = split_values(sum(args.extensions or [], []))
    if args.extension_file:
        exts.extend(read_lines(args.extension_file))
    prefixes = split_values(sum(args.prefixes or [], []))
    if args.prefix_file:
        prefixes.extend(read_lines(args.prefix_file))
    prefixes = prefixes or [""]
    variants = []
    base_exts = exts if args.force_extension else [""]
    sorted_words = sorted(words)
    for prefix in prefixes:
        for word in sorted_words:
            for ext in base_exts:
                variants.append(prefix + word.replace("%EXT%", ext if args.ext_sub else "%EXT%") + ext)
    if exts and not args.force_extension:
        for ext in sorted(exts, reverse=True):
            for prefix in prefixes:
                for word in sorted_words:
                    variants.append(prefix + word.replace("%EXT%", ext if args.ext_sub else "%EXT%") + ext)
    return variants


def parse_codes(values):
    out = set()
    for value in split_values(sum(values or [], [])):
        try:
            out.add(int(value))
        except ValueError:
            pass
    return out


def hidden_size_predicate(values):
    ranges = []
    for value in split_values(sum(values or [], [])):
        if "-" in value:
            a, b = value.split("-", 1)
            ranges.append((int(a), int(b)))
        else:
            n = int(value)
            ranges.append((n, n))
    return lambda size: any(a <= size <= b for a, b in ranges)


def is_listable(data):
    sample = data[:500].decode("utf-8", "ignore").lower()
    return "index of /" in sample


def scan_base(base, words, args):
    not_found_codes = validate(base, args)
    whitelist = parse_codes(args.code_whitelist)
    blacklist = parse_codes(args.code_blacklist) or not_found_codes
    hide_size = hidden_size_predicate(args.hide_lengths)
    findings = []
    seen_dirs = set()
    queue = [(base, 0)]
    scanned = set()

    while queue:
        current, depth = queue.pop(0)
        if current in scanned:
            continue
        scanned.add(current)
        for entry in expanded_entries(words, args):
            if args.throttle:
                time.sleep(args.throttle / 1000.0)
            url = urllib.parse.urljoin(current, entry)
            code, size, headers, data, err = request(url, args)
            if err:
                if args.verbose:
                    print(f"Curl error after requesting {url} : {err}")
                continue
            directory = False
            redirect_url = ""
            if code in (301, 302, 303, 307, 308):
                loc = headers.get("Location", "")
                redirect_url = urllib.parse.urljoin(url, loc)
                if redirect_url.rstrip("/") == url.rstrip("/") and redirect_url.endswith("/"):
                    code, size, headers, data, err = request(redirect_url, args)
                    if err:
                        continue
                    url = redirect_url
                    directory = True
            if url.endswith("/"):
                directory = True
            listable = args.scan_listable and directory and is_listable(data)
            if whitelist and code not in whitelist:
                continue
            if not whitelist and code in blacklist:
                continue
            if hide_size(size):
                continue
            if ".ht" in urllib.parse.urlparse(url).path and code == 403 and not args.show_htaccess:
                continue
            if code in (200, 201, 202, 204, 301, 302, 307, 308, 401, 403):
                finding = Finding(url, code, size, directory, listable, redirect_url)
                findings.append(finding)
                if directory and not args.disable_recursion and depth < args.max_recursion_depth and url not in seen_dirs:
                    seen_dirs.add(url)
                    queue.append((url, depth + 1))
    return findings


def line_for(f):
    marker = "L" if f.is_listable else ("D" if f.is_directory else "+")
    return f"{marker} {f.url} (CODE:{f.code}|SIZE:{f.size})"


def ordered(findings):
    return [f for f in findings if not f.is_directory] + [f for f in findings if f.is_directory]


def write_reports(base, findings, args):
    grouped = ordered(findings)
    if args.output_all:
        args.output_file = args.output_all + ".txt"
        args.json_file = args.output_all + ".json"
        args.xml_file = args.output_all + ".xml"
    if args.output_file:
        files = [f for f in findings if not f.is_directory]
        dirs = [f for f in findings if f.is_directory]
        with open(args.output_file, "w", encoding="utf-8") as fh:
            fh.write(f"Dirble Scan Report for {base}:\n")
            for f in files:
                fh.write(line_for(f) + "\n")
            fh.write("\n")
            for f in dirs:
                fh.write(line_for(f) + "\n")
    if args.json_file:
        payload = [
            {
                "url": f.url,
                "code": f.code,
                "size": f.size,
                "is_directory": f.is_directory,
                "is_listable": f.is_listable,
                "redirect_url": f.redirect_url,
                "found_from_listable": f.found_from_listable,
            }
            for f in grouped
        ]
        with open(args.json_file, "w", encoding="utf-8") as fh:
            fh.write(json.dumps(payload, separators=(",", ":")).replace("},{", "},\n{"))
    if args.xml_file:
        with open(args.xml_file, "w", encoding="utf-8") as fh:
            fh.write('<?xml version="1.0" encoding="UTF-8"?>\n<dirble_scan>\n')
            for f in grouped:
                fh.write(
                    f'<path url="{xml_escape(f.url)}" code="{f.code}" content_len="{f.size}" '
                    f'is_directory="{str(f.is_directory).lower()}" '
                    f'is_listable="{str(f.is_listable).lower()}" '
                    f'redirect_url="{xml_escape(f.redirect_url)}" '
                    f'found_from_listable="{str(f.found_from_listable).lower()}"/>\n'
                )
            fh.write("</dirble_scan>")


def xml_escape(value):
    return value.replace("&", "&amp;").replace('"', "&quot;").replace("<", "&lt;").replace(">", "&gt;")


def collect_uris(args):
    uris = []
    if args.pos_uri:
        uris.append(args.pos_uri)
    uris.extend(args.uris or [])
    if args.uri_file:
        uris.extend(read_lines(args.uri_file))
    return uris


def main(argv):
    args = parse_args(argv)
    if args is None:
        return 0 if argv else 2
    if args == "parse_error":
        return 2
    wordlist = args.wordlist
    if not wordlist:
        wordlist = os.path.join(os.path.dirname(os.path.abspath(sys.argv[0])), "dirble_wordlist.txt")
        if not os.path.exists(wordlist):
            print("[ERROR] Unable to find default wordlist")
            return 1
    words = read_lines(wordlist)
    try:
        bases = [normalize_base(uri) for uri in collect_uris(args)]
    except ValueError as e:
        print(f"error: invalid value '{collect_uris(args)[0]}' for '[uri]': {e}", file=sys.stderr)
        print("\nFor more information, try '--help'.", file=sys.stderr)
        return 2
    if not bases:
        print(HELP, end="")
        return 2
    for base in bases:
        findings = scan_base(base, words, args)
        if not args.silent:
            for f in findings:
                print(line_for(f))
        write_reports(base, findings, args)
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
