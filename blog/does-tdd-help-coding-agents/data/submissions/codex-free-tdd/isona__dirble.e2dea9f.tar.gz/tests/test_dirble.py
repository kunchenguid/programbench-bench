import http.server
import os
import subprocess
import sys
import tempfile
import threading
import unittest


ROOT = os.path.dirname(os.path.dirname(__file__))
SCRIPT = os.path.join(ROOT, "src", "dirble.py")


class Handler(http.server.BaseHTTPRequestHandler):
    requests = []

    def do_GET(self):
        self._respond(True)

    def do_HEAD(self):
        self._respond(False)

    def do_POST(self):
        self._respond(True)

    def log_message(self, *_args):
        pass

    def _respond(self, include_body):
        Handler.requests.append((self.command, self.path, self.headers))
        code = 404
        body = b"notfound"
        headers = {}
        if self.path == "/admin":
            code, body = 200, b"admin file"
        elif self.path == "/secret":
            code, body = 403, b"nope"
        elif self.path == "/list":
            code, body = 301, b""
            headers["Location"] = "/list/"
        elif self.path == "/list/":
            code, body = 200, b"<html><title>Index of /list/</title></html>"
            headers["Content-Type"] = "text/html"
        elif self.path == "/index.php":
            code, body = 200, b"php page"

        self.send_response(code)
        for name, value in headers.items():
            self.send_header(name, value)
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        if include_body:
            self.wfile.write(body)


class DirbleTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.httpd = http.server.HTTPServer(("127.0.0.1", 0), Handler)
        cls.port = cls.httpd.server_address[1]
        cls.thread = threading.Thread(target=cls.httpd.serve_forever, daemon=True)
        cls.thread.start()

    @classmethod
    def tearDownClass(cls):
        cls.httpd.shutdown()
        cls.thread.join()

    def setUp(self):
        Handler.requests.clear()
        self.tmp = tempfile.TemporaryDirectory()
        self.wordlist = os.path.join(self.tmp.name, "wl.txt")
        with open(self.wordlist, "w", encoding="utf-8") as fh:
            fh.write("admin\nsecret\nindex\nlist\n.htaccess\n")

    def tearDown(self):
        self.tmp.cleanup()

    def run_cli(self, *args):
        return subprocess.run(
            [sys.executable, SCRIPT, *args],
            text=True,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            check=False,
        )

    def test_scans_wordlist_and_reports_files_and_directories(self):
        url = f"http://127.0.0.1:{self.port}"
        result = self.run_cli(
            url,
            "-w",
            self.wordlist,
            "--no-color",
            "--disable-recursion",
            "-t",
            "1",
            "-T",
            "1",
        )

        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertIn(f"[INFO] Detected nonexistent paths for {url}/ are (CODE:404)", result.stdout)
        self.assertIn(f"+ {url}/admin (CODE:200|SIZE:10)", result.stdout)
        self.assertIn(f"+ {url}/secret (CODE:403|SIZE:4)", result.stdout)
        self.assertIn(f"D {url}/list/ (CODE:200|SIZE:43)", result.stdout)
        self.assertNotIn(".htaccess", result.stdout)

    def test_force_extension_scans_only_extension_variants(self):
        url = f"http://127.0.0.1:{self.port}"
        result = self.run_cli(
            url,
            "-w",
            self.wordlist,
            "--force-extension",
            "-x",
            ".php",
            "--disable-recursion",
        )

        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertIn(f"+ {url}/index.php (CODE:200|SIZE:8)", result.stdout)
        requested_paths = [path for _method, path, _headers in Handler.requests]
        self.assertIn("/index.php", requested_paths)
        self.assertNotIn("/index", requested_paths)

    def test_writes_text_json_and_xml_reports(self):
        url = f"http://127.0.0.1:{self.port}"
        txt = os.path.join(self.tmp.name, "out.txt")
        js = os.path.join(self.tmp.name, "out.json")
        xml = os.path.join(self.tmp.name, "out.xml")
        result = self.run_cli(
            url,
            "-w",
            self.wordlist,
            "--disable-recursion",
            "-o",
            txt,
            "--json-file",
            js,
            "--xml-file",
            xml,
        )

        self.assertEqual(result.returncode, 0, result.stderr)
        with open(txt, encoding="utf-8") as fh:
            self.assertIn(f"Dirble Scan Report for {url}/:", fh.read())
        with open(js, encoding="utf-8") as fh:
            self.assertIn('"url":"' + url + '/admin"', fh.read())
        with open(xml, encoding="utf-8") as fh:
            self.assertIn('<dirble_scan>', fh.read())


if __name__ == "__main__":
    unittest.main()
