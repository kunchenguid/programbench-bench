import os
import subprocess
import unittest


ROOT = os.path.dirname(os.path.dirname(__file__))
EXE = os.path.join(ROOT, "executable")


def build():
    subprocess.run(["bash", "compile.sh"], cwd=ROOT, check=True)


def run_cmd(args, timeout=1.0):
    return subprocess.run(
        [EXE] + args,
        cwd=ROOT,
        text=True,
        stdin=subprocess.DEVNULL,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        timeout=timeout,
        check=False,
    )


class CliBehavior(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        build()

    def test_h_prints_usage_and_metadata(self):
        result = run_cmd(["-h"])
        self.assertEqual(result.returncode, 0)
        self.assertEqual(result.stderr, "")
        self.assertIn("usage: nnn [OPTIONS] [PATH]\n", result.stdout)
        self.assertIn(" -T key  sort order [a/d/e/r/s/t/v]\n", result.stdout)
        self.assertTrue(result.stdout.rstrip().endswith("https://github.com/jarun/nnn"))

    def test_v_prints_plain_version(self):
        result = run_cmd(["-V"])
        self.assertEqual(result.returncode, 0)
        self.assertEqual(result.stdout, "5.2\n")
        self.assertEqual(result.stderr, "")

    def test_long_option_is_invalid_and_prints_help_to_stdout(self):
        result = run_cmd(["--help"])
        self.assertEqual(result.returncode, 1)
        self.assertIn("invalid option -- '-'\n", result.stderr)
        self.assertEqual(result.stdout.splitlines()[0], "usage: nnn [OPTIONS] [PATH]")

    def test_missing_option_argument_uses_getopt_wording(self):
        result = run_cmd(["-b"])
        self.assertEqual(result.returncode, 1)
        self.assertIn("option requires an argument -- 'b'\n", result.stderr)
        self.assertIn(" -b key  open bookmark key (trumps -s/S)\n", result.stdout)

    def test_version_takes_precedence_when_seen_first(self):
        result = run_cmd(["-Vh"])
        self.assertEqual(result.returncode, 0)
        self.assertEqual(result.stdout, "5.2\n")
        self.assertEqual(result.stderr, "")

    def test_help_takes_precedence_when_seen_first(self):
        result = run_cmd(["-hV"])
        self.assertEqual(result.returncode, 0)
        self.assertIn("usage: nnn [OPTIONS] [PATH]\n", result.stdout)
        self.assertEqual(result.stderr, "")

    def test_key_collision_check_exits_without_ui(self):
        result = run_cmd(["-K"])
        self.assertEqual(result.returncode, 0)
        self.assertEqual(result.stdout, "")
        self.assertEqual(result.stderr, "")

    def test_key_collision_combined_with_version_prints_entry_count(self):
        result = run_cmd(["-KV"])
        self.assertEqual(result.returncode, 0)
        self.assertEqual(result.stdout, "0 entries\n")
        self.assertEqual(result.stderr, "")


if __name__ == "__main__":
    unittest.main()
