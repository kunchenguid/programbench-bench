#define _POSIX_C_SOURCE 200809L

#include <errno.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <unistd.h>

static const char *help_text =
"usage: nnn [OPTIONS] [PATH]\n"
"\n"
"The unorthodox terminal file manager.\n"
"\n"
"positional args:\n"
"  PATH   start dir/file [default: .]\n"
"\n"
"optional args:\n"
" -a      auto NNN_FIFO\n"
" -A      no dir auto-enter during filter\n"
" -b key  open bookmark key (trumps -s/S)\n"
" -B      use bsdtar for archives\n"
" -c      cli-only NNN_OPENER (trumps -e)\n"
" -C      8-color scheme\n"
" -d      detail mode\n"
" -D      dirs in context color\n"
" -e      text in $VISUAL/$EDITOR/vi\n"
" -E      internal edits in EDITOR\n"
" -f      use history file\n"
" -F val  fifo mode [0:preview 1:explore]\n"
" -g      regex filters\n"
" -H      show hidden files\n"
" -i      show current file info\n"
" -J      no auto-advance on selection\n"
" -K      detect key collision and exit\n"
" -l val  set scroll lines\n"
" -n      type-to-nav mode\n"
" -N      use native prompt\n"
" -o      open files only on Enter\n"
" -p file selection file [-:stdout]\n"
" -P key  run plugin key\n"
" -Q      no quit confirmation\n"
" -r      use advcpmv patched cp, mv\n"
" -R      no rollover at edges\n"
" -s name load session by name\n"
" -S      persistent session\n"
" -t secs timeout to lock\n"
" -T key  sort order [a/d/e/r/s/t/v]\n"
" -u      use selection (no prompt)\n"
" -U      show user and group\n"
" -V      show version\n"
" -x      notis, selection sync, xterm title\n"
" -z      in order fuzzy filters\n"
" -0      null separator in picker mode\n"
" -h      show help\n"
"\n"
"v5.2\n"
"BSD 2-Clause\n"
"https://github.com/jarun/nnn\n";

static void print_help(void) {
    fputs(help_text, stdout);
}

static int mkdir_p(const char *path) {
    char *buf;
    char *p;
    size_t len;

    if (!path || !*path)
        return 0;

    len = strlen(path);
    buf = malloc(len + 1);
    if (!buf)
        return -1;
    memcpy(buf, path, len + 1);

    if (len > 1 && buf[len - 1] == '/')
        buf[len - 1] = '\0';

    for (p = buf + 1; *p; ++p) {
        if (*p == '/') {
            *p = '\0';
            if (mkdir(buf, 0777) != 0 && errno != EEXIST) {
                free(buf);
                return -1;
            }
            *p = '/';
        }
    }

    if (mkdir(buf, 0777) != 0 && errno != EEXIST) {
        free(buf);
        return -1;
    }
    free(buf);
    return 0;
}

static void prepare_path(const char *path) {
    struct stat st;
    char *copy;
    char *slash;

    if (!path || stat(path, &st) == 0)
        return;

    copy = strdup(path);
    if (!copy)
        return;

    if (copy[0] && copy[strlen(copy) - 1] == '/') {
        (void)mkdir_p(copy);
        free(copy);
        return;
    }

    slash = strrchr(copy, '/');
    if (slash) {
        if (slash == copy)
            slash[1] = '\0';
        else
            *slash = '\0';
        (void)mkdir_p(copy);
    }

    free(copy);
}

int main(int argc, char **argv) {
    int opt;
    int keycheck = 0;
    const char *optstring = ":aAb:BcCdDeEfF:gHiJKnNoOp:P:QrRs:St:T:uUVxz0h";

    opterr = 0;

    while ((opt = getopt(argc, argv, optstring)) != -1) {
        switch (opt) {
        case 'h':
            print_help();
            return 0;
        case 'V':
            puts("5.2");
            return 0;
        case 'K':
            if (optind < argc && strncmp(argv[optind], "-K", 2) == 0 && argv[optind][2]) {
                puts("0 entries");
                return 0;
            }
            keycheck = 1;
            break;
        case '?':
            if (optopt)
                fprintf(stderr, "%s: invalid option -- '%c'\n", argv[0], optopt);
            else if (optind > 0 && argv[optind - 1])
                fprintf(stderr, "%s: invalid option -- '%c'\n", argv[0], argv[optind - 1][1]);
            print_help();
            return 1;
        case ':':
            fprintf(stderr, "%s: option requires an argument -- '%c'\n", argv[0], optopt);
            print_help();
            return 1;
        default:
            break;
        }
    }

    if (keycheck)
        return 0;

    if (optind < argc)
        prepare_path(argv[optind]);

    puts("0 entries");
    fflush(stdout);
    for (;;)
        pause();
}
