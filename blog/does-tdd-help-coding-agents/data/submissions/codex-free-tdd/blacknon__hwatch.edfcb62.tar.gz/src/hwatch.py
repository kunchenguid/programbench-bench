#!/usr/bin/env python3
import datetime as _dt
import json
import os
import shlex
import subprocess
import sys
import time


VERSION = "hwatch 0.3.19"
GRAY = "\033[38;5;240m"
RESET = "\033[0m"


HELP = """A modern alternative to the watch command, records the differences in execution results and can check this differences at after.

Usage: __PROGRAM__ [OPTIONS] [command]...

Arguments:
  [command]...  

Options:
  -b, --batch                         output execution results to stdout
  -B, --beep                          beep if command has a change result
      --border                        Surround each pane with a border frame
      --with-scrollbar                When the border option is enabled, display scrollbar on the right side of watch pane.
      --mouse                         enable mouse wheel support. With this option, copying text with your terminal may be harder. Try holding the Shift key.
  -c, --color                         interpret ANSI color and style sequences
  -r, --reverse                       display text upside down.
  -C, --compress                      Compress data in memory. Note: If the output of the command is small, you may not get the desired effect.
  -t, --no-title                      hide the UI on start. Use `t` to toggle it.
      --enable-summary-char           collect character-level diff count in summary.
  -N, --line-number                   show line number
      --no-help-banner                hide the "Display help with h key" message
      --no-summary                    disable the calculation for summary that is running behind the scenes, and disable the summary function in the first place.
  -x, --exec                          Run the command directly, not through the shell. Much like the `-x` option of the watch command.
  -O, --diff-output-only              Display only the lines with differences during `line` diff and `word` diff.
  -A, --aftercommand <after_command>  Executes the specified command if the output changes. Information about changes is stored in json format in environment variable ${HWATCH_DATA}.
  -l, --logfile [<logfile>]           logging file. if a log file is already used, its contents will be read and executed.
  -s, --shell <shell_command>         shell to use at runtime. can also insert the command to the location specified by {COMMAND}. [default: "sh -c"]
  -n, --interval <interval>           seconds to wait between updates [default: 2]
      --precise                       Attempt to run as close to the interval as possible, regardless of how long the command takes to run
  -L, --limit <limit>                 Set the number of history records to keep. only work in watch mode. Set `0` for unlimited recording. (default: 5000) [default: 5000]
      --tab-size <tab_size>           Specifying tab display size [default: 4]
  -d, --differences [<differences>]   highlight changes between updates [possible values: none, watch, line, word]
  -o, --output [<output>]             Select command output. [default: output] [possible values: output, stdout, stderr]
  -K, --keymap <keymap>               Add keymap
  -h, --help                          Print help
  -V, --version                       Print version
"""


def error(message):
    sys.stderr.write(f"{message}\n\nFor more information, try '--help'.\n")
    return 2


def missing_command():
    sys.stderr.write(
        "error: command not specified and logfile is empty.\n\n"
        "Usage: hwatch [OPTIONS] [command]...\n\n"
        "For more information, try '--help'.\n"
    )
    return 2


def parse(argv):
    if os.environ.get("HWATCH"):
        argv = shlex.split(os.environ["HWATCH"]) + argv
    opts = {
        "batch": False,
        "exec": False,
        "interval": 2.0,
        "output": "output",
        "line_number": False,
        "reverse": False,
        "shell": "sh -c",
        "logfile": None,
        "aftercommand": None,
    }
    command = []
    i = 0
    while i < len(argv):
        arg = argv[i]
        if arg == "--":
            command.extend(argv[i + 1 :])
            break
        if arg in ("-h", "--help"):
            return "help", opts, []
        if arg in ("-V", "--version"):
            return "version", opts, []
        if arg in ("-b", "--batch"):
            opts["batch"] = True
        elif arg in ("-x", "--exec"):
            opts["exec"] = True
        elif arg in ("-N", "--line-number"):
            opts["line_number"] = True
        elif arg in ("-r", "--reverse"):
            opts["reverse"] = True
        elif arg in ("-n", "--interval"):
            i += 1
            if i >= len(argv):
                return ("err", "error: a value is required for '--interval <interval>' but none was supplied"), opts, []
            try:
                opts["interval"] = max(0.001, float(argv[i].replace(",", ".")))
            except ValueError:
                return ("err", f"error: invalid value '{argv[i]}' for '--interval <interval>'"), opts, []
        elif arg in ("-o", "--output"):
            i += 1
            if i >= len(argv):
                opts["output"] = "output"
            elif argv[i] in ("output", "stdout", "stderr"):
                opts["output"] = argv[i]
            else:
                sys.stderr.write(
                    f"error: invalid value '{argv[i]}' for '--output [<output>]'\n"
                    "  [possible values: output, stdout, stderr]\n\n"
                    "For more information, try '--help'.\n"
                )
                sys.exit(2)
        elif arg in ("-s", "--shell"):
            i += 1
            if i < len(argv):
                opts["shell"] = argv[i]
        elif arg in ("-l", "--logfile"):
            if i + 1 < len(argv) and not argv[i + 1].startswith("-"):
                i += 1
                opts["logfile"] = argv[i]
            else:
                opts["logfile"] = "hwatch.log"
        elif arg in ("-A", "--aftercommand"):
            i += 1
            if i < len(argv):
                opts["aftercommand"] = argv[i]
        elif arg in ("-K", "--keymap", "-L", "--limit", "--tab-size"):
            i += 1
        elif arg in (
            "-B",
            "--beep",
            "--border",
            "--with-scrollbar",
            "--mouse",
            "-c",
            "--color",
            "-C",
            "--compress",
            "-t",
            "--no-title",
            "--enable-summary-char",
            "--no-help-banner",
            "--no-summary",
            "-O",
            "--diff-output-only",
            "--precise",
        ):
            pass
        elif arg in ("-d", "--differences"):
            if i + 1 < len(argv) and argv[i + 1] in ("none", "watch", "line", "word"):
                i += 1
        elif arg.startswith("-"):
            pass
        else:
            command.extend(argv[i:])
            break
        i += 1
    return "run", opts, command


def run_command(opts, command):
    if opts["exec"]:
        proc = subprocess.run(command, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    else:
        shell_command = " ".join(command)
        if "{COMMAND}" in opts["shell"]:
            proc = subprocess.run(
                opts["shell"].replace("{COMMAND}", shell_command),
                shell=True,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
            )
        else:
            proc = subprocess.run(shell_command, shell=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    stdout = proc.stdout.decode(errors="replace")
    stderr = proc.stderr.decode(errors="replace")
    if opts["output"] == "stdout":
        output = stdout
    elif opts["output"] == "stderr":
        output = stderr
    else:
        output = stderr + stdout
    return {
        "status": proc.returncode == 0,
        "stdout": stdout,
        "stderr": stderr,
        "output": output,
    }


def format_body(text, opts):
    lines = text.splitlines()
    if text.endswith("\n") or text == "":
        lines.append("")
    if opts["reverse"]:
        lines = list(reversed(lines))
    if opts["line_number"]:
        width = len(str(len(lines)))
        return "".join(f"{GRAY}{str(idx).rjust(width)}{RESET}{GRAY} | {RESET}{line}\n" for idx, line in enumerate(lines, 1))
    return "".join(line + "\n" for line in lines)


def batch_loop(opts, command):
    initial_record = {"timestamp": "", "command": "", "status": True, "output": "", "stdout": "", "stderr": ""}
    last_record = initial_record
    last_record_output = None
    command_text = " ".join(command)
    if opts["logfile"]:
        with open(opts["logfile"], "w", encoding="utf-8") as fh:
            fh.write(json.dumps(initial_record, separators=(",", ":")) + "\n")
    while True:
        now = _dt.datetime.now().strftime("%Y-%m-%d %H:%M:%S.%f")[:-3]
        result = run_command(opts, command)
        sys.stdout.write(f"{GRAY}=====[{now}]========================={RESET}\n")
        sys.stdout.write(format_body(result["output"], opts))
        sys.stdout.flush()
        if opts["logfile"] and result["output"] != last_record_output:
            record = {
                "timestamp": now,
                "command": command_text,
                "status": result["status"],
                "output": result["output"],
                "stdout": result["stdout"],
                "stderr": result["stderr"],
            }
            with open(opts["logfile"], "a", encoding="utf-8") as fh:
                fh.write(json.dumps(record, separators=(",", ":")) + "\n")
            if opts["aftercommand"]:
                env = os.environ.copy()
                env["HWATCH_DATA"] = json.dumps({"before_result": last_record, "after_result": record}, separators=(",", ":"))
                subprocess.run(opts["aftercommand"], shell=True, env=env, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            last_record = record
            last_record_output = result["output"]
        elif (not opts["logfile"]) and result["output"] != last_record_output:
            record = {
                "timestamp": now,
                "command": command_text,
                "status": result["status"],
                "output": result["output"],
                "stdout": result["stdout"],
                "stderr": result["stderr"],
            }
            if opts["aftercommand"]:
                env = os.environ.copy()
                env["HWATCH_DATA"] = json.dumps({"before_result": last_record, "after_result": record}, separators=(",", ":"))
                subprocess.run(opts["aftercommand"], shell=True, env=env, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            last_record = record
            last_record_output = result["output"]
        time.sleep(opts["interval"])


def main(argv):
    mode, opts, command = parse(argv)
    if mode == "help":
        sys.stdout.write(HELP.replace("__PROGRAM__", os.path.basename(sys.argv[0])))
        return 0
    if mode == "version":
        print(VERSION)
        return 0
    if isinstance(mode, tuple) and mode[0] == "err":
        return error(mode[1])
    if not command:
        return missing_command()
    batch_loop(opts, command)
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main(sys.argv[1:]))
    except BrokenPipeError:
        raise SystemExit(0)
    except KeyboardInterrupt:
        raise SystemExit(0)
