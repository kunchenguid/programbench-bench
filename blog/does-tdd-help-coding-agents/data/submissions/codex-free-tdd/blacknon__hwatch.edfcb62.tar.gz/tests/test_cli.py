import os
import json
import re
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
PROGRAM = ROOT / "src" / "hwatch.py"


def run_prog(args, timeout=1.5, env=None):
    merged_env = os.environ.copy()
    if env:
        merged_env.update(env)
    return subprocess.run(
        [sys.executable, str(PROGRAM), *args],
        text=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        timeout=timeout,
        env=merged_env,
    )


def run_watch(args, timeout=0.35):
    try:
        return run_prog(args, timeout=timeout)
    except subprocess.TimeoutExpired as exc:
        return exc


def strip_header(text):
    return re.sub(
        r"^\x1b\[38;5;240m=====\[\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}\.\d{3}\]=========================\x1b\[0m\n",
        "",
        text,
        count=1,
    )


class CliTests(unittest.TestCase):
    def test_version_matches_hwatch_0319(self):
        result = run_prog(["--version"])

        self.assertEqual(result.returncode, 0)
        self.assertEqual(result.stdout, "hwatch 0.3.19\n")
        self.assertEqual(result.stderr, "")

    def test_missing_command_is_clap_style_error(self):
        result = run_prog(["-b"])

        self.assertEqual(result.returncode, 2)
        self.assertEqual(result.stdout, "")
        self.assertEqual(
            result.stderr,
            "error: command not specified and logfile is empty.\n\n"
            "Usage: hwatch [OPTIONS] [command]...\n\n"
            "For more information, try '--help'.\n",
        )

    def test_help_uses_invoked_program_name(self):
        result = run_prog(["--help"])

        self.assertEqual(result.returncode, 0)
        self.assertIn("Usage: hwatch.py [OPTIONS] [command]...\n", result.stdout)
        self.assertIn("-V, --version                       Print version\n", result.stdout)
        self.assertEqual(result.stderr, "")

    def test_batch_prints_header_and_command_output_until_interrupted(self):
        result = run_watch(["-b", "printf hello"])

        self.assertIsInstance(result, subprocess.TimeoutExpired)
        self.assertIn(result.stderr, (None, b"", ""))
        out = result.stdout.decode() if isinstance(result.stdout, bytes) else result.stdout
        self.assertRegex(
            out,
            r"^\x1b\[38;5;240m=====\[\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}\.\d{3}\]=========================\x1b\[0m\n",
        )
        self.assertTrue(strip_header(out).startswith("hello"))

    def test_default_output_preserves_stderr_stdout_arrival_order(self):
        result = run_watch(["-b", "echo out; echo err >&2"])

        self.assertIsInstance(result, subprocess.TimeoutExpired)
        out = result.stdout.decode() if isinstance(result.stdout, bytes) else result.stdout
        self.assertTrue(strip_header(out).startswith("err\nout\n\n"), repr(strip_header(out)))

    def test_logfile_receives_initial_and_changed_json_records(self):
        with tempfile.TemporaryDirectory() as tmp:
            logfile = Path(tmp) / "hwatch.json"
            result = run_watch(["-b", "-n", "0.05", "-l", str(logfile), "date +%s%N"], timeout=0.25)

            self.assertIsInstance(result, subprocess.TimeoutExpired)
            records = [json.loads(line) for line in logfile.read_text().splitlines()]
            self.assertGreaterEqual(len(records), 2)
            self.assertEqual(
                records[0],
                {"timestamp": "", "command": "", "status": True, "output": "", "stdout": "", "stderr": ""},
            )
            self.assertRegex(records[1]["timestamp"], r"^\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}\.\d{3}$")
            self.assertEqual(records[1]["command"], "date +%s%N")
            self.assertTrue(records[1]["status"])
            self.assertEqual(records[1]["output"], records[1]["stdout"])
            self.assertEqual(records[1]["stderr"], "")

    def test_aftercommand_gets_hwatch_data_for_changed_output(self):
        with tempfile.TemporaryDirectory() as tmp:
            capture = Path(tmp) / "after.txt"
            result = run_watch(
                ["-b", "-n", "0.05", "-A", f"printenv HWATCH_DATA >> {capture}", "date +%s%N"],
                timeout=0.25,
            )

            self.assertIsInstance(result, subprocess.TimeoutExpired)
            records = [json.loads(line) for line in capture.read_text().splitlines()]
            self.assertGreaterEqual(len(records), 1)
            self.assertEqual(records[0]["before_result"]["timestamp"], "")
            self.assertEqual(records[0]["after_result"]["command"], "date +%s%N")
            self.assertIn("stdout", records[0]["after_result"])


if __name__ == "__main__":
    unittest.main()
