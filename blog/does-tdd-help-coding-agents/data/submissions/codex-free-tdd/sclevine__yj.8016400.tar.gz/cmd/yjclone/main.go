package main

import (
	"bytes"
	"encoding/json"
	"fmt"
	"io"
	"os"
	"strconv"
	"strings"
	"unicode"

	"gopkg.in/yaml.v3"
)

type Kind int

const (
	Null Kind = iota
	Bool
	Number
	String
	Array
	Object
)

type Entry struct {
	Key string
	Val Value
}

type Value struct {
	Kind    Kind
	Bool    bool
	Raw     string
	Str     string
	Array   []Value
	Entries []Entry
}

const helpText = `Usage: ./executable [-][ytjcrneikhv]

Convert between YAML, TOML, JSON, and HCL.
Preserves map order.

-x[x]  Convert using stdin. Valid options:
          -yj, -y = YAML to JSON (default)
          -yy     = YAML to YAML
          -yt     = YAML to TOML
          -yc     = YAML to HCL
          -tj, -t = TOML to JSON
          -ty     = TOML to YAML
          -tt     = TOML to TOML
          -tc     = TOML to HCL
          -jj     = JSON to JSON
          -jy, -r = JSON to YAML
          -jt     = JSON to TOML
          -jc     = JSON to HCL
          -cy     = HCL to YAML
          -ct     = HCL to TOML
          -cj, -c = HCL to JSON
          -cc     = HCL to HCL
-n     Do not covert inf, -inf, and NaN to/from strings (YAML or TOML only)
-e     Escape HTML (JSON out only)
-i     Indent output (JSON or TOML out only)
-k     Attempt to parse keys as objects or numeric types (YAML out only)
-h     Show this help message
-v     Show version
`

type options struct {
	in, out string
	indent  bool
	escape  bool
	keyObj  bool
}

func main() {
	opts, action, invalid := parseArgs(os.Args[1:])
	if len(invalid) > 0 {
		fmt.Fprint(os.Stderr, helpText+"\n")
		fmt.Fprintf(os.Stderr, "Error: invalid flags specified: %s\n", strings.Join(invalid, " "))
		os.Exit(1)
	}
	switch action {
	case "help":
		fmt.Print(helpText)
		return
	case "version":
		fmt.Println("v0.0.0")
		return
	}
	input, _ := io.ReadAll(os.Stdin)
	val, err := parseInput(opts.in, input)
	if err != nil {
		fmt.Fprintf(os.Stderr, "Error parsing %s: %v\n", formatName(opts.in), err)
		os.Exit(1)
	}
	out, err := emitOutput(opts.out, val, opts)
	if err != nil {
		fmt.Fprintf(os.Stderr, "Error converting to %s: %v\n", formatName(opts.out), err)
		os.Exit(1)
	}
	os.Stdout.Write(out)
}

func formatName(f string) string {
	switch f {
	case "y":
		return "YAML"
	case "j":
		return "JSON"
	case "t":
		return "TOML"
	case "c":
		return "HCL"
	default:
		return strings.ToUpper(f)
	}
}

func parseArgs(args []string) (options, string, []string) {
	opts := options{in: "y", out: "j"}
	var conv []rune
	var invalid []string
	help := false
	version := false
	for _, arg := range args {
		if !strings.HasPrefix(arg, "-") {
			continue
		}
		for _, r := range strings.TrimLeft(arg, "-") {
			switch r {
			case 'h':
				help = true
			case 'v':
				version = true
			case 'y', 't', 'j', 'c', 'r':
				conv = append(conv, r)
			case 'i':
				opts.indent = true
			case 'e':
				opts.escape = true
			case 'k':
				opts.keyObj = true
			case 'n':
			default:
				invalid = append(invalid, string(r))
			}
		}
	}
	if len(invalid) > 0 {
		return opts, "", invalid
	}
	if help {
		return opts, "help", nil
	}
	if version {
		return opts, "version", nil
	}
	if len(conv) == 1 {
		switch conv[0] {
		case 'y':
			opts.in, opts.out = "y", "j"
		case 't':
			opts.in, opts.out = "t", "j"
		case 'j', 'r':
			opts.in, opts.out = "j", "y"
		case 'c':
			opts.in, opts.out = "c", "j"
		}
	} else if len(conv) >= 2 {
		a, b := conv[0], conv[1]
		if a == 'r' {
			a = 'j'
			b = 'y'
		}
		if b == 'r' {
			b = 'y'
		}
		opts.in, opts.out = string(a), string(b)
	}
	return opts, "", invalid
}

func parseInput(format string, input []byte) (Value, error) {
	switch format {
	case "y":
		return parseYAML(input)
	case "j":
		return parseJSON(input)
	case "t", "c":
		return parseAssignments(string(input))
	default:
		return Value{}, fmt.Errorf("unsupported input")
	}
}

func emitOutput(format string, v Value, opts options) ([]byte, error) {
	var b bytes.Buffer
	switch format {
	case "j":
		writeJSON(&b, v, opts.indent, opts.escape, 0)
	case "y":
		writeYAML(&b, v, 0, opts.keyObj)
	case "t":
		writeTOML(&b, v)
	case "c":
		writeHCL(&b, v, 0)
	default:
		return nil, fmt.Errorf("unsupported output")
	}
	return b.Bytes(), nil
}

func parseYAML(input []byte) (Value, error) {
	var node yaml.Node
	if err := yaml.Unmarshal(input, &node); err != nil {
		return Value{}, err
	}
	if len(node.Content) == 1 {
		return yamlNode(node.Content[0]), nil
	}
	return yamlNode(&node), nil
}

func yamlNode(n *yaml.Node) Value {
	switch n.Kind {
	case yaml.DocumentNode:
		if len(n.Content) > 0 {
			return yamlNode(n.Content[0])
		}
		return Value{Kind: Null}
	case yaml.MappingNode:
		v := Value{Kind: Object}
		for i := 0; i+1 < len(n.Content); i += 2 {
			v.Entries = append(v.Entries, Entry{Key: n.Content[i].Value, Val: yamlNode(n.Content[i+1])})
		}
		return v
	case yaml.SequenceNode:
		v := Value{Kind: Array}
		for _, c := range n.Content {
			v.Array = append(v.Array, yamlNode(c))
		}
		return v
	case yaml.ScalarNode:
		switch n.Tag {
		case "!!null":
			return Value{Kind: Null}
		case "!!bool":
			return Value{Kind: Bool, Bool: n.Value == "true"}
		case "!!int", "!!float":
			return Value{Kind: Number, Raw: n.Value}
		default:
			return Value{Kind: String, Str: n.Value}
		}
	default:
		return Value{Kind: Null}
	}
}

func parseJSON(input []byte) (Value, error) {
	var check any
	checkDec := json.NewDecoder(bytes.NewReader(input))
	checkDec.UseNumber()
	if err := checkDec.Decode(&check); err != nil {
		return Value{}, err
	}
	dec := json.NewDecoder(bytes.NewReader(input))
	dec.UseNumber()
	return parseJSONValue(dec)
}

func parseJSONValue(dec *json.Decoder) (Value, error) {
	tok, err := dec.Token()
	if err != nil {
		return Value{}, err
	}
	switch t := tok.(type) {
	case json.Delim:
		if t == '{' {
			obj := Value{Kind: Object}
			for dec.More() {
				kt, err := dec.Token()
				if err != nil {
					return Value{}, err
				}
				child, err := parseJSONValue(dec)
				if err != nil {
					return Value{}, err
				}
				obj.Entries = append(obj.Entries, Entry{Key: kt.(string), Val: child})
			}
			_, err = dec.Token()
			return obj, err
		}
		arr := Value{Kind: Array}
		for dec.More() {
			child, err := parseJSONValue(dec)
			if err != nil {
				return Value{}, err
			}
			arr.Array = append(arr.Array, child)
		}
		_, err = dec.Token()
		return arr, err
	case string:
		return Value{Kind: String, Str: t}, nil
	case bool:
		return Value{Kind: Bool, Bool: t}, nil
	case nil:
		return Value{Kind: Null}, nil
	case json.Number:
		return Value{Kind: Number, Raw: t.String()}, nil
	default:
		return Value{}, fmt.Errorf("invalid JSON")
	}
}

func parseAssignments(input string) (Value, error) {
	root := Value{Kind: Object}
	current := &root
	for _, raw := range strings.Split(input, "\n") {
		line := strings.TrimSpace(raw)
		if line == "" || strings.HasPrefix(line, "#") {
			continue
		}
		if strings.HasPrefix(line, "[") && strings.HasSuffix(line, "]") {
			name := strings.TrimSpace(line[1 : len(line)-1])
			child := Value{Kind: Object}
			root.Entries = append(root.Entries, Entry{Key: name, Val: child})
			current = &root.Entries[len(root.Entries)-1].Val
			continue
		}
		idx := strings.Index(line, "=")
		if idx < 0 {
			return root, fmt.Errorf("expected assignment")
		}
		key := strings.TrimSpace(line[:idx])
		key = strings.Trim(key, `"`)
		val, err := parseInline(strings.TrimSpace(line[idx+1:]))
		if err != nil {
			return root, err
		}
		current.Entries = append(current.Entries, Entry{Key: key, Val: val})
	}
	return root, nil
}

func parseInline(s string) (Value, error) {
	s = strings.TrimSpace(s)
	if s == "" {
		return Value{Kind: String}, nil
	}
	if strings.HasPrefix(s, `"`) {
		var out string
		if err := json.Unmarshal([]byte(s), &out); err == nil {
			return Value{Kind: String, Str: out}, nil
		}
	}
	if strings.HasPrefix(s, "[") && strings.HasSuffix(s, "]") {
		body := strings.TrimSpace(s[1 : len(s)-1])
		arr := Value{Kind: Array}
		if body == "" {
			return arr, nil
		}
		for _, part := range splitCSV(body) {
			v, err := parseInline(part)
			if err != nil {
				return arr, err
			}
			arr.Array = append(arr.Array, v)
		}
		return arr, nil
	}
	switch s {
	case "true":
		return Value{Kind: Bool, Bool: true}, nil
	case "false":
		return Value{Kind: Bool, Bool: false}, nil
	}
	if _, err := strconv.ParseFloat(s, 64); err == nil {
		return Value{Kind: Number, Raw: s}, nil
	}
	return Value{Kind: String, Str: s}, nil
}

func splitCSV(s string) []string {
	var parts []string
	start := 0
	inString := false
	esc := false
	depth := 0
	for i, r := range s {
		if esc {
			esc = false
			continue
		}
		if r == '\\' && inString {
			esc = true
			continue
		}
		if r == '"' {
			inString = !inString
			continue
		}
		if inString {
			continue
		}
		if r == '[' {
			depth++
		} else if r == ']' {
			depth--
		} else if r == ',' && depth == 0 {
			parts = append(parts, strings.TrimSpace(s[start:i]))
			start = i + 1
		}
	}
	parts = append(parts, strings.TrimSpace(s[start:]))
	return parts
}

func writeJSON(b *bytes.Buffer, v Value, indent, escape bool, level int) {
	pad := func(n int) { b.WriteString(strings.Repeat("  ", n)) }
	switch v.Kind {
	case Null:
		b.WriteString("null")
		if level == 0 {
			b.WriteByte('\n')
		}
	case Bool:
		if v.Bool {
			b.WriteString("true")
		} else {
			b.WriteString("false")
		}
		if level == 0 {
			b.WriteByte('\n')
		}
	case Number:
		b.WriteString(v.Raw)
		if level == 0 {
			b.WriteByte('\n')
		}
	case String:
		writeJSONString(b, v.Str, escape)
		if level == 0 {
			b.WriteByte('\n')
		}
	case Array:
		if !indent {
			b.WriteByte('[')
			for i, c := range v.Array {
				if i > 0 {
					b.WriteByte(',')
				}
				writeJSON(b, c, false, escape, level+1)
			}
			b.WriteByte(']')
			if level == 0 {
				b.WriteByte('\n')
			}
			break
		}
		b.WriteByte('[')
		if len(v.Array) > 0 {
			b.WriteByte('\n')
			for i, c := range v.Array {
				pad(level + 1)
				writeJSON(b, c, true, escape, level+1)
				if i+1 < len(v.Array) {
					b.WriteByte(',')
				}
				b.WriteByte('\n')
			}
			pad(level)
		}
		b.WriteByte(']')
		if level == 0 {
			b.WriteByte('\n')
		}
	case Object:
		if !indent {
			b.WriteByte('{')
			for i, e := range v.Entries {
				if i > 0 {
					b.WriteByte(',')
				}
				writeJSONString(b, e.Key, escape)
				b.WriteByte(':')
				writeJSON(b, e.Val, false, escape, level+1)
			}
			b.WriteByte('}')
			if level == 0 {
				b.WriteByte('\n')
			}
			break
		}
		b.WriteByte('{')
		if len(v.Entries) > 0 {
			b.WriteByte('\n')
			for i, e := range v.Entries {
				pad(level + 1)
				writeJSONString(b, e.Key, escape)
				b.WriteString(": ")
				writeJSON(b, e.Val, true, escape, level+1)
				if i+1 < len(v.Entries) {
					b.WriteByte(',')
				}
				b.WriteByte('\n')
			}
			pad(level)
		}
		b.WriteByte('}')
		if level == 0 {
			b.WriteByte('\n')
		}
	}
}

func writeJSONString(b *bytes.Buffer, s string, escapeHTML bool) {
	var tmp bytes.Buffer
	enc := json.NewEncoder(&tmp)
	enc.SetEscapeHTML(escapeHTML)
	_ = enc.Encode(s)
	b.Write(bytes.TrimSpace(tmp.Bytes()))
}

func writeYAML(b *bytes.Buffer, v Value, level int, keyObj bool) {
	indent := strings.Repeat("  ", level)
	switch v.Kind {
	case Object:
		for _, e := range v.Entries {
			key := yamlKey(e.Key, keyObj)
			if e.Val.Kind == Array {
				b.WriteString(indent + key + ":\n")
				writeYAML(b, e.Val, level+1, keyObj)
			} else if e.Val.Kind == Object {
				b.WriteString(indent + key + ":\n")
				writeYAML(b, e.Val, level+1, keyObj)
			} else {
				b.WriteString(indent + key + ": " + yamlScalar(e.Val) + "\n")
			}
		}
	case Array:
		for _, c := range v.Array {
			if c.Kind == Object || c.Kind == Array {
				b.WriteString(indent + "-\n")
				writeYAML(b, c, level+1, keyObj)
			} else {
				b.WriteString(indent + "- " + yamlScalar(c) + "\n")
			}
		}
	default:
		b.WriteString(indent + yamlScalar(v) + "\n")
	}
}

func yamlKey(s string, keyObj bool) string {
	if keyObj {
		if s == "true" || s == "false" || isNumber(s) {
			return s
		}
		if strings.HasPrefix(s, "[") {
			var v Value
			if parsed, err := parseJSON([]byte(s)); err == nil {
				v = parsed
				var b bytes.Buffer
				b.WriteString("? ")
				writeYAMLInlineKey(&b, v, 0)
				return strings.TrimRight(b.String(), "\n")
			}
		}
	}
	if needsYAMLQuote(s, true) {
		return strconv.Quote(s)
	}
	return s
}

func writeYAMLInlineKey(b *bytes.Buffer, v Value, level int) {
	if v.Kind == Array {
		for _, c := range v.Array {
			b.WriteString("- " + yamlScalar(c) + "\n  ")
		}
	}
}

func yamlScalar(v Value) string {
	switch v.Kind {
	case Null:
		return "null"
	case Bool:
		if v.Bool {
			return "true"
		}
		return "false"
	case Number:
		return v.Raw
	case String:
		if needsYAMLQuote(v.Str, false) {
			return strconv.Quote(v.Str)
		}
		return v.Str
	default:
		return ""
	}
}

func needsYAMLQuote(s string, key bool) bool {
	if s == "" {
		return true
	}
	lower := strings.ToLower(s)
	reserved := map[string]bool{"true": true, "false": true, "yes": true, "no": true, "on": true, "off": true, "null": true}
	if reserved[lower] || isNumber(s) {
		return true
	}
	return strings.ContainsAny(s, ":#[]{}&,?|\n\t")
}

func writeAssignments(b *bytes.Buffer, v Value, hcl bool) {
	if v.Kind != Object {
		return
	}
	for i, e := range v.Entries {
		if hcl {
			if i > 0 {
				b.WriteByte('\n')
			}
			writeJSONString(b, e.Key, false)
		} else {
			b.WriteString(e.Key)
		}
		b.WriteString(" = ")
		writeInline(b, e.Val)
		b.WriteByte('\n')
	}
}

func writeTOML(b *bytes.Buffer, v Value) {
	if v.Kind != Object {
		return
	}
	for _, e := range v.Entries {
		if e.Val.Kind == Null || e.Val.Kind == Object {
			continue
		}
		b.WriteString(e.Key)
		b.WriteString(" = ")
		writeInline(b, e.Val)
		b.WriteByte('\n')
	}
	for _, e := range v.Entries {
		if e.Val.Kind != Object {
			continue
		}
		if b.Len() > 0 && !bytes.HasSuffix(b.Bytes(), []byte("\n")) {
			b.WriteByte('\n')
		}
		b.WriteString("[")
		b.WriteString(e.Key)
		b.WriteString("]\n")
		for _, c := range e.Val.Entries {
			if c.Val.Kind == Null || c.Val.Kind == Object {
				continue
			}
			b.WriteString(c.Key)
			b.WriteString(" = ")
			writeInline(b, c.Val)
			b.WriteByte('\n')
		}
	}
}

func writeHCL(b *bytes.Buffer, v Value, level int) {
	if v.Kind != Object {
		return
	}
	indent := strings.Repeat("  ", level)
	written := 0
	for _, e := range v.Entries {
		if e.Val.Kind == Null {
			continue
		}
		if written > 0 {
			b.WriteByte('\n')
		}
		b.WriteString(indent)
		writeJSONString(b, e.Key, false)
		b.WriteString(" = ")
		if e.Val.Kind == Object {
			b.WriteString("{\n")
			writeHCL(b, e.Val, level+1)
			b.WriteString(indent)
			b.WriteString("}")
			if level == 0 {
				b.WriteByte('\n')
			}
		} else {
			writeInline(b, e.Val)
			b.WriteByte('\n')
		}
		written++
	}
}

func writeInline(b *bytes.Buffer, v Value) {
	switch v.Kind {
	case Null:
		b.WriteString("null")
	case Bool:
		if v.Bool {
			b.WriteString("true")
		} else {
			b.WriteString("false")
		}
	case Number:
		b.WriteString(v.Raw)
	case String:
		writeJSONString(b, v.Str, false)
	case Array:
		b.WriteByte('[')
		for i, c := range v.Array {
			if i > 0 {
				b.WriteString(", ")
			}
			writeInline(b, c)
		}
		b.WriteByte(']')
	case Object:
		b.WriteByte('{')
		for i, e := range v.Entries {
			if i > 0 {
				b.WriteString(", ")
			}
			b.WriteString(e.Key)
			b.WriteString(" = ")
			writeInline(b, e.Val)
		}
		b.WriteByte('}')
	}
}

func isNumber(s string) bool {
	if s == "" {
		return false
	}
	_, err := strconv.ParseFloat(s, 64)
	return err == nil
}

func _isIdent(s string) bool {
	for i, r := range s {
		if !(unicode.IsLetter(r) || r == '_' || (i > 0 && unicode.IsDigit(r))) {
			return false
		}
	}
	return s != ""
}
