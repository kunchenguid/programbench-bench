#!/bin/bash
set -euo pipefail

ROOT="$(cd "$(dirname "$0")/.." && pwd)"
BIN="$ROOT/executable"

fail() {
  echo "FAIL: $1" >&2
  exit 1
}

run_case() {
  local name="$1" flags="$2" input="$3" expected="$4"
  local out err status
  out="$(mktemp)"
  err="$(mktemp)"
  set +e
  printf "%b" "$input" | "$BIN" $flags >"$out" 2>"$err"
  status=$?
  set -e
  [[ "$status" == 0 ]] || fail "$name exited $status; stderr=$(cat "$err")"
  diff -u <(printf "%b" "$expected") "$out" || fail "$name stdout mismatch"
  [[ ! -s "$err" ]] || fail "$name stderr not empty: $(cat "$err")"
}

[[ -x "$BIN" ]] || fail "missing executable"

version="$("$BIN" -v)"
[[ "$version" == "v0.0.0" ]] || fail "version mismatch: $version"

help_out="$("$BIN" -h)"
[[ "$help_out" == Usage:* ]] || fail "help did not print usage"

set +e
"$BIN" --help >/tmp/yj_test_long.out 2>/tmp/yj_test_long.err
long_status=$?
set -e
[[ "$long_status" == 1 ]] || fail "--help status $long_status"
grep -q "Error: invalid flags specified: l p" /tmp/yj_test_long.err || fail "--help error mismatch"

run_case "yaml to compact json" "" 'a: 1\nb: two\nlist:\n  - x\n  - 2\n' '{"a":1,"b":"two","list":["x",2]}'$'\n'
run_case "yaml to indented json" "-i" 'a: 1\nb: two\nlist:\n  - x\n  - 2\n' '{\n  "a": 1,\n  "b": "two",\n  "list": [\n    "x",\n    2\n  ]\n}\n'
run_case "json to yaml" "-jy" '{"a":1,"b":"two","list":["x",2]}' 'a: 1\nb: two\nlist:\n  - x\n  - 2\n'
run_case "json to toml" "-jt" '{"a":1,"b":"two","list":["x",2]}' 'a = 1\nb = "two"\nlist = ["x", 2]\n'
run_case "json to hcl" "-jc" '{"a":1,"b":"two","list":["x",2]}' '"a" = 1\n\n"b" = "two"\n\n"list" = ["x", 2]\n'
run_case "toml to yaml" "-ty" 'a = 1\nb = "two"\nlist = ["x", 2]\n' 'a: 1\nb: two\nlist:\n  - x\n  - 2\n'
run_case "hcl to json" "-cj" 'a = 1\nb = "two"\nlist = ["x", 2]\n' '{"a":1,"b":"two","list":["x",2]}'$'\n'
run_case "json html escape" "-jje" '{"x":"<tag>&"}' '{"x":"\\u003ctag\\u003e\\u0026"}'$'\n'
run_case "nested json to toml" "-jt" '{"root":{"child":1,"name":"bob"}}' '[root]\nchild = 1\nname = "bob"\n'
run_case "nested json to hcl" "-jc" '{"root":{"child":1,"name":"bob"}}' '"root" = {\n  "child" = 1\n\n  "name" = "bob"\n}\n'
run_case "toml section to json" "-tj" 'a = 1\n[sec]\nb = 2\n' '{"a":1,"sec":{"b":2}}\n'
run_case "toml section to yaml" "-ty" 'a = 1\n[sec]\nb = 2\n' 'a: 1\nsec:\n  b: 2\n'
run_case "toml date as json string" "-tj" 'd = 1979-05-27T07:32:00Z\n' '{"d":"1979-05-27T07:32:00Z"}\n'
run_case "toml omits null" "-yt" 'a: true\nb: null\n' 'a = true\n'
run_case "json array stays json" "-jj" '[1,2]' '[1,2]\n'
run_case "json scalar stays json" "-jj" 'true' 'true\n'

set +e
printf '{bad' | "$BIN" -jj >/tmp/yj_test_bad_json.out 2>/tmp/yj_test_bad_json.err
bad_json_status=$?
set -e
[[ "$bad_json_status" == 1 ]] || fail "bad JSON status $bad_json_status"
grep -q "Error parsing JSON: invalid character 'b' looking for beginning of object key string" /tmp/yj_test_bad_json.err || fail "bad JSON error mismatch"
