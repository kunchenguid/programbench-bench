import os
import subprocess
import tempfile
import textwrap
import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
CHEAT = ROOT / "cheat.py"


def run_cheat(args, env=None, cwd=None):
    merged = os.environ.copy()
    if env:
        merged.update(env)
    return subprocess.run(
        ["python3", str(CHEAT), *args],
        text=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        env=merged,
        cwd=cwd or ROOT,
    )


def make_fixture(tmp):
    root = Path(tmp)
    personal = root / "personal"
    work = root / "work"
    (work / "nested").mkdir(parents=True)
    personal.mkdir()
    conf = root / "conf.yml"
    conf.write_text(
        textwrap.dedent(
            f"""\
            ---
            editor: /bin/true
            colorize: false
            pager: cat
            cheatpaths:
              - name: personal
                path: {personal}
                tags: [ personal, alpha ]
                readonly: false
              - name: work
                path: {work}
                tags: [ work ]
                readonly: false
            """
        )
    )
    (personal / "tar").write_text(
        "---\nsyntax: bash\ntags: [ archive, linux ]\n---\n# To extract:\ntar -xvf file.tar\n"
    )
    (work / "grep").write_text("# Find text\ngrep -R needle .\n")
    (work / "nested" / "foo").write_text("nested body\n")
    return root, {"CHEAT_CONFIG_PATH": str(conf)}


class CheatCliTests(unittest.TestCase):
    def test_version_prints_documented_release(self):
        result = run_cheat(["--version"])

        self.assertEqual(result.returncode, 0)
        self.assertEqual(result.stdout, "5.1.0\n")

    def test_init_writes_default_config_for_home(self):
        with tempfile.TemporaryDirectory() as tmp:
            result = run_cheat(["--init"], env={"HOME": tmp})

        self.assertEqual(result.returncode, 0)
        self.assertIn("editor: EDITOR_PATH\n", result.stdout)
        self.assertIn(f"path: {tmp}/.config/cheat/cheatsheets/personal\n", result.stdout)
        self.assertIn("tags: [ personal ]\n", result.stdout)

    def test_missing_config_reports_prompt_failure(self):
        with tempfile.TemporaryDirectory() as tmp:
            result = run_cheat(["--conf"], env={"HOME": tmp})

        self.assertEqual(result.returncode, 1)
        self.assertEqual(
            result.stdout,
            "A config file was not found. Would you like to create one now? [Y/n]: "
            "failed to create config: failed to prompt: EOF\n",
        )

    def test_lists_and_views_configured_cheatsheets(self):
        with tempfile.TemporaryDirectory() as tmp:
            _, env = make_fixture(tmp)

            listing = run_cheat(["-l"], env=env)
            brief = run_cheat(["-b"], env=env)
            tags = run_cheat(["-T"], env=env)
            viewed = run_cheat(["tar"], env=env)

        self.assertEqual(listing.returncode, 0)
        self.assertIn("title:", listing.stdout)
        self.assertIn("grep", listing.stdout)
        self.assertIn("nested/foo", listing.stdout)
        self.assertIn("alpha,archive,linux,personal", listing.stdout)
        self.assertEqual(brief.returncode, 0)
        self.assertIn("title:", brief.stdout)
        self.assertNotIn("/personal/tar", brief.stdout)
        self.assertEqual(tags.stdout, "alpha\narchive\nlinux\npersonal\nwork\n")
        self.assertEqual(viewed.stdout, "# To extract:\ntar -xvf file.tar\n")

    def test_search_and_filters_match_observed_grouping(self):
        with tempfile.TemporaryDirectory() as tmp:
            _, env = make_fixture(tmp)

            search = run_cheat(["-r", "-s", "tar|needle"], env=env)
            brief_tar = run_cheat(["-b", "tar"], env=env)
            work_list = run_cheat(["-l", "-p", "work"], env=env)
            archive_list = run_cheat(["-l", "-t", "archive"], env=env)

        self.assertEqual(search.returncode, 0)
        self.assertIn("tar (personal)\n\t# To extract:\n\ttar -xvf file.tar", search.stdout)
        self.assertIn("grep (work)\n\t# Find text\n\tgrep -R needle .", search.stdout)
        self.assertEqual(brief_tar.returncode, 0)
        self.assertIn("tar", brief_tar.stdout)
        self.assertNotIn("grep", brief_tar.stdout)
        self.assertEqual(work_list.returncode, 0)
        self.assertIn("grep", work_list.stdout)
        self.assertNotIn("personal/tar", work_list.stdout)
        self.assertEqual(archive_list.returncode, 0)
        self.assertIn("tar", archive_list.stdout)
        self.assertNotIn("grep", archive_list.stdout)

    def test_errors_help_completion_and_mutations(self):
        with tempfile.TemporaryDirectory() as tmp:
            root, env = make_fixture(tmp)
            missing = run_cheat(["missing"], env=env)
            bad_path = run_cheat(["-p", "nope", "-l"], env=env)
            help_out = run_cheat(["--help"], env=env)
            completion = run_cheat(["--completion", "bash"], env=env)
            bad_completion = run_cheat(["--completion", "bad"], env=env)
            removed = run_cheat(["--rm", "grep"], env=env)
            edit_existing = run_cheat(["-e", "tar"], env=env)

            ro = root / "ro"
            rw = root / "rw"
            ro.mkdir()
            rw.mkdir()
            (ro / "foo").write_text("old\n")
            conf = root / "ro.yml"
            conf.write_text(
                textwrap.dedent(
                    f"""\
                    ---
                    editor: /bin/true
                    pager: cat
                    cheatpaths:
                      - name: ro
                        path: {ro}
                        tags: [ ro ]
                        readonly: true
                      - name: rw
                        path: {rw}
                        tags: [ rw ]
                        readonly: false
                    """
                )
            )
            copied = run_cheat(["-e", "foo"], env={"CHEAT_CONFIG_PATH": str(conf)})
            copied_text = (rw / "foo").read_text()

        self.assertEqual(missing.returncode, 2)
        self.assertEqual(missing.stdout, "No cheatsheet found for 'missing'.\n")
        self.assertEqual(bad_path.returncode, 1)
        self.assertEqual(bad_path.stdout, "invalid option --path: cheatpath does not exist: nope\n")
        self.assertEqual(help_out.returncode, 0)
        self.assertIn("Usage:\n  cheat [cheatsheet] [flags]\n", help_out.stdout)
        self.assertEqual(completion.returncode, 0)
        self.assertIn("# bash completion V2 for cheat", completion.stdout)
        self.assertEqual(bad_completion.returncode, 1)
        self.assertEqual(
            bad_completion.stdout,
            "unsupported shell: bad (valid: bash, zsh, fish, powershell)\n",
        )
        self.assertEqual(removed.returncode, 0)
        self.assertFalse((root / "work" / "grep").exists())
        self.assertEqual(edit_existing.returncode, 0)
        self.assertEqual(copied.returncode, 0)
        self.assertEqual(copied_text, "old\n")


if __name__ == "__main__":
    unittest.main()
