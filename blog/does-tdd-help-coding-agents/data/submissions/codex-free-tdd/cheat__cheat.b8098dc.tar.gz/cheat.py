#!/usr/bin/env python3
import os
import re
import shutil
import sys
from pathlib import Path


VERSION = "5.1.0"
MISSING_CONFIG = (
    "A config file was not found. Would you like to create one now? [Y/n]: "
    "failed to create config: failed to prompt: EOF"
)
HELP = """cheat allows you to create and view interactive cheatsheets on the
command-line. It was designed to help remind *nix system administrators of
options for commands that they use frequently, but not frequently enough to
remember.

Usage:
  cheat [cheatsheet] [flags]

Flags:
  -a, --all                Search among all cheatpaths
  -b, --brief              List cheatsheets without file paths
  -c, --colorize           Colorize output
      --completion shell   Generate shell completion script (shell: bash, zsh, fish, powershell)
      --conf               Display the config file path
  -d, --directories        List cheatsheet directories
  -e, --edit cheatsheet    Edit cheatsheet
  -h, --help               help for cheat
      --init               Write a default config file to stdout
  -l, --list               List cheatsheets
  -p, --path name          Return only sheets found on cheatpath name
  -r, --regex              Treat search <phrase> as a regex
      --rm cheatsheet      Remove (delete) cheatsheet
  -s, --search phrase      Search cheatsheets for phrase
  -t, --tag tag            Return only sheets matching tag
  -T, --tags               List all tags in use
  -u, --update             Update git-backed cheatpaths
  -v, --version            Print the version number
"""


def default_config(home):
    base = f"{home}/.config/cheat/cheatsheets"
    return f"""---
# The editor to use with 'cheat -e <sheet>'. Overridden by $VISUAL or $EDITOR.
editor: EDITOR_PATH

# Should 'cheat' always colorize output?
colorize: false

# Which 'chroma' colorscheme should be applied to the output?
# Options are available here:
#   https://github.com/alecthomas/chroma/tree/master/styles
style: monokai

# Which 'chroma' "formatter" should be applied?
# One of: "terminal", "terminal256", "terminal16m"
formatter: terminal256

# Through which pager should output be piped?
# 'less -FRX' is recommended on Unix systems
# 'more' is recommended on Windows
pager: /usr/bin/pager

# The paths at which cheatsheets are available. Tags associated with a cheatpath
# are automatically attached to all cheatsheets residing on that path.
cheatpaths:

  # Cheatsheets that are tagged "personal" are stored here by default:
  - name: personal
    path: {base}/personal
    tags: [ personal ]
    readonly: false

  # Cheatsheets that are tagged "work" are stored here by default:
  - name: work
    path: {base}/work
    tags: [ work ]
    readonly: false
"""


def config_path():
    if os.environ.get("CHEAT_CONFIG_PATH"):
        p = Path(os.environ["CHEAT_CONFIG_PATH"]).expanduser()
        return p if p.exists() else None
    home = Path(os.environ.get("HOME", "~")).expanduser()
    candidates = [
        Path(os.environ.get("XDG_CONFIG_HOME", home / ".config")) / "cheat" / "conf.yml",
        home / ".config" / "cheat" / "conf.yml",
        home / ".cheat" / "conf.yml",
        Path("/etc/cheat/conf.yml"),
    ]
    for p in candidates:
        if p.exists():
            return p
    return None


def parse_tags(value):
    value = value.strip()
    if value.startswith("[") and value.endswith("]"):
        inner = value[1:-1].strip()
        return [x.strip().strip("'\"") for x in inner.split(",") if x.strip()]
    if not value:
        return []
    return [value.strip("'\"")]


def load_config():
    path = config_path()
    if not path:
        return None
    cfg = {"path": path, "cheatpaths": [], "pager": ""}
    current = None
    for raw in path.read_text().splitlines():
        line = raw.strip()
        if not line or line.startswith("#") or line == "---":
            continue
        if line.startswith("pager:"):
            cfg["pager"] = line.split(":", 1)[1].strip()
        elif line.startswith("- name:"):
            current = {
                "name": line.split(":", 1)[1].strip().strip("'\""),
                "path": "",
                "tags": [],
                "readonly": False,
            }
            cfg["cheatpaths"].append(current)
        elif current is not None and line.startswith("path:"):
            current["path"] = line.split(":", 1)[1].strip().strip("'\"")
            current["path"] = os.path.expanduser(os.path.expandvars(current["path"]))
        elif current is not None and line.startswith("tags:"):
            current["tags"] = parse_tags(line.split(":", 1)[1])
        elif current is not None and line.startswith("readonly:"):
            current["readonly"] = line.split(":", 1)[1].strip().lower() == "true"
    return cfg


def split_frontmatter(text):
    if not text.startswith("---\n"):
        return {}, text
    end = text.find("\n---\n", 4)
    if end < 0:
        return {}, text
    meta = {}
    for raw in text[4:end].splitlines():
        if ":" not in raw:
            continue
        key, value = raw.split(":", 1)
        key = key.strip()
        value = value.strip()
        meta[key] = parse_tags(value) if key == "tags" else value
    return meta, text[end + 5 :]


def discover(cfg):
    sheets = {}
    order = 0
    for cp in cfg["cheatpaths"]:
        root = Path(cp["path"])
        if not root.is_dir():
            continue
        for file in sorted(p for p in root.rglob("*") if p.is_file()):
            rel = file.relative_to(root).as_posix()
            if rel.startswith(".git/") or rel.endswith((".md", ".yml", ".yaml")):
                continue
            try:
                text = file.read_text()
            except UnicodeDecodeError:
                continue
            meta, body = split_frontmatter(text)
            tags = sorted(set(cp["tags"]) | set(meta.get("tags", [])))
            sheets[rel] = {
                "title": rel,
                "file": str(file),
                "tags": tags,
                "body": body,
                "path": cp["name"],
                "order": order,
            }
            order += 1
    return [sheets[k] for k in sorted(sheets)]


def filter_sheets(sheets, tag=None, path_name=None, title_query=None):
    out = sheets
    if path_name:
        out = [s for s in out if s["path"] == path_name]
    if tag:
        out = [s for s in out if tag in s["tags"]]
    if title_query:
        out = [s for s in out if title_query in s["title"]]
    return out


def arg_value(argv, *names):
    for i, item in enumerate(argv):
        for name in names:
            if item == name and i + 1 < len(argv):
                return argv[i + 1]
            if item.startswith(name + "="):
                return item.split("=", 1)[1]
    return None


def positional_args(argv):
    consumed = set()
    for flag in ("-p", "--path", "-t", "--tag", "-s", "--search", "-e", "--edit", "--rm", "--completion"):
        val = arg_value(argv, flag)
        if val is not None:
            consumed.add(val)
    return [a for a in argv if not a.startswith("-") and a not in consumed]


def table(rows, columns):
    widths = [len(c) for c in columns]
    data = []
    for row in rows:
        vals = [row[c] for c in columns]
        data.append(vals)
        widths = [max(w, len(v)) for w, v in zip(widths, vals)]
    lines = [" ".join(c.ljust(widths[i]) for i, c in enumerate(columns)).rstrip()]
    lines.extend(" ".join(v.ljust(widths[i]) for i, v in enumerate(vals)).rstrip() for vals in data)
    return "\n".join(lines) + "\n"


def list_sheets(sheets, brief=False):
    rows = []
    for s in sheets:
        row = {"title:": s["title"], "tags:": ",".join(s["tags"])}
        if not brief:
            row["file:"] = s["file"]
        rows.append(row)
    cols = ["title:", "tags:"] if brief else ["title:", "file:", "tags:"]
    return table(rows, cols)


def search_sheets(sheets, phrase, regex=False):
    parts = []
    for s in sorted(sheets, key=lambda item: item["order"]):
        try:
            found = bool(re.search(phrase, s["body"])) if regex else phrase in s["body"]
        except re.error as exc:
            print(f"invalid regex: {exc}")
            return None
        if found:
            body = "\n".join("\t" + line for line in s["body"].splitlines())
            parts.append(f"{s['title']} ({s['path']})\n{body}")
    return "\n\n".join(parts)


def find_sheet(sheets, title):
    for s in sheets:
        if s["title"] == title:
            return s
    return None


def first_writable(cfg):
    for cp in reversed(cfg["cheatpaths"]):
        if not cp["readonly"]:
            return cp
    return None


def completion(shell):
    if shell not in ("bash", "zsh", "fish", "powershell"):
        return None
    if shell == "bash":
        return "# bash completion V2 for cheat                                -*- shell-script -*-\n\n__cheat_debug()\n{\n    :\n}\n"
    if shell == "zsh":
        return "#compdef cheat\n\n# zsh completion for cheat\n"
    if shell == "fish":
        return "# fish completion for cheat\n"
    return "# powershell completion for cheat\n"


def main(argv):
    known = {
        "-a", "--all", "-b", "--brief", "-c", "--colorize", "--completion",
        "--conf", "-d", "--directories", "-e", "--edit", "-h", "--help",
        "--init", "-l", "--list", "-p", "--path", "-r", "--regex", "--rm",
        "-s", "--search", "-t", "--tag", "-T", "--tags", "-u", "--update",
        "-v", "--version",
    }
    for item in argv:
        if item.startswith("-") and "=" not in item and item not in known:
            print(f"unknown flag: {item}")
            return 1
    if "--version" in argv or "-v" in argv:
        print(VERSION)
        return 0
    if "--init" in argv:
        print(default_config(os.environ.get("HOME", str(Path.home()))), end="")
        return 0
    if "--help" in argv or "-h" in argv:
        print(HELP, end="")
        return 0

    cfg = load_config()
    if cfg is None:
        print(MISSING_CONFIG)
        return 1
    if "--conf" in argv:
        print(cfg["path"])
        return 0

    sheets = discover(cfg)
    path_name = None
    tag = None
    title_query = None
    i = 0
    while i < len(argv):
        if argv[i] in ("-p", "--path") and i + 1 < len(argv):
            path_name = argv[i + 1]
            if path_name not in [cp["name"] for cp in cfg["cheatpaths"]]:
                print(f"invalid option --path: cheatpath does not exist: {path_name}")
                return 1
            i += 2
            continue
        if argv[i] in ("-t", "--tag") and i + 1 < len(argv):
            tag = argv[i + 1]
            i += 2
            continue
        i += 1

    sheets = filter_sheets(sheets, tag=tag, path_name=path_name)
    shell = arg_value(argv, "--completion")
    if shell:
        out = completion(shell)
        if out is None:
            print(f"unsupported shell: {shell} (valid: bash, zsh, fish, powershell)")
            return 1
        print(out, end="")
        return 0
    edit_title = arg_value(argv, "-e", "--edit")
    if edit_title:
        sheet = find_sheet(sheets, edit_title)
        if sheet:
            cp = next((c for c in cfg["cheatpaths"] if c["name"] == sheet["path"]), None)
            if cp and cp["readonly"]:
                writable = first_writable(cfg)
                if writable:
                    dst = Path(writable["path"]) / edit_title
                    dst.parent.mkdir(parents=True, exist_ok=True)
                    shutil.copyfile(sheet["file"], dst)
        return 0
    rm_title = arg_value(argv, "--rm")
    if rm_title:
        sheet = find_sheet(sheets, rm_title)
        if not sheet:
            print(f"No cheatsheet found for '{rm_title}'.")
            return 2
        Path(sheet["file"]).unlink(missing_ok=True)
        return 0
    search = arg_value(argv, "-s", "--search")
    if search is not None:
        out = search_sheets(sheets, search, regex=("-r" in argv or "--regex" in argv))
        if out is None:
            return 1
        print(out, end="")
        return 0
    if "-u" in argv or "--update" in argv:
        return 0
    positional = positional_args(argv)
    if "-b" in argv or "--brief" in argv:
        if positional and positional[0] not in (path_name, tag):
            title_query = positional[-1]
        found = filter_sheets(sheets, title_query=title_query)
        if not found:
            return 2
        print(list_sheets(found, brief=True), end="")
        return 0
    if "-l" in argv or "--list" in argv:
        if not sheets:
            return 2
        print(list_sheets(sheets), end="")
        return 0
    if "-T" in argv or "--tags" in argv:
        tags = sorted({tag for s in sheets for tag in s["tags"]})
        print("\n".join(tags) + ("\n" if tags else ""), end="")
        return 0 if tags else 2
    if "-d" in argv or "--directories" in argv:
        width = max([len(cp["name"]) for cp in cfg["cheatpaths"]] or [0])
        for cp in cfg["cheatpaths"]:
            print(f"{cp['name'] + ':':{width + 1}} {cp['path']}")
        return 0
    if positional:
        title = positional[-1]
        for s in sheets:
            if s["title"] == title:
                print(s["body"], end="")
                return 0
        print(f"No cheatsheet found for '{title}'.")
        return 2
    return 0


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
