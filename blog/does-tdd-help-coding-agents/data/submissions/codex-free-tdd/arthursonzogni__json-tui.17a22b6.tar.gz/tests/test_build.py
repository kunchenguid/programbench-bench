#!/usr/bin/env python3
import os
import subprocess
import tempfile
import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]


class BuildTests(unittest.TestCase):
    def test_compile_script_creates_runnable_executable(self):
        with tempfile.TemporaryDirectory() as tmp:
            work = Path(tmp)
            for name in ("compile.sh", "json_tui.py"):
                (work / name).write_bytes((ROOT / name).read_bytes())
            proc = subprocess.run(["bash", "compile.sh"], cwd=work, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
            self.assertEqual(proc.returncode, 0, proc.stderr)
            executable = work / "executable"
            self.assertTrue(executable.exists())
            self.assertTrue(os.access(executable, os.X_OK))
            version = subprocess.run([str(executable), "--version"], stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
            self.assertEqual(version.stdout, "1.4.1\n")


if __name__ == "__main__":
    unittest.main()
