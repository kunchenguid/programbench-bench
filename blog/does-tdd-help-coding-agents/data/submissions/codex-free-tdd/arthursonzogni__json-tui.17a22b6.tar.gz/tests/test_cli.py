#!/usr/bin/env python3
import os
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
BIN = ROOT / "json_tui.py"


def run_cmd(args, data=None, timeout=2):
    return subprocess.run(
        [sys.executable, str(BIN), *args],
        input=data,
        text=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        timeout=timeout,
        cwd=ROOT,
    )


class CliTests(unittest.TestCase):
    def test_help_matches_documented_menu(self):
        proc = run_cmd(["--help"])
        self.assertEqual(proc.returncode, 0)
        self.assertIn("  json-tui {OPTIONS} [file]\n", proc.stdout)
        self.assertIn("    A JSON terminal UI\n", proc.stdout)
        self.assertIn("      -v, --version                     Print version.\n", proc.stdout)
        self.assertIn("Please report bugs to:https://github.com/ArthurSonzogni/json-tui/issues", proc.stdout)
        self.assertEqual(proc.stderr, "")

    def test_version_prints_reference_version(self):
        proc = run_cmd(["-v"])
        self.assertEqual(proc.returncode, 0)
        self.assertEqual(proc.stdout, "1.4.1\n")

    def test_invalid_argument_prints_message_and_exits_nonzero(self):
        proc = run_cmd(["--bogus"])
        self.assertEqual(proc.returncode, 1)
        self.assertEqual(proc.stdout, "Invalid arguments\n")

    def test_missing_file_message_exits_zero(self):
        proc = run_cmd(["missing.json"])
        self.assertEqual(proc.returncode, 0)
        self.assertEqual(proc.stdout, "Could not open file missing.json\n")

    def test_keybinding_table_contains_supported_navigation_and_exit_keys(self):
        proc = run_cmd(["--keybinding"])
        self.assertEqual(proc.returncode, 0)
        self.assertIn("┌───────────┬────────────────┐\n", proc.stdout)
        self.assertIn("│\x1b[36m\x1b[49mkeys       \x1b[39m\x1b[49m│", proc.stdout)
        self.assertIn("│Navigate   │← ↑ ↓ →         │\n", proc.stdout)
        self.assertIn("│           │h j k l         │\n", proc.stdout)
        self.assertIn("│Exit       │Escape          │\n", proc.stdout)
        self.assertIn("│ - bottom  │G               │\n", proc.stdout)
        self.assertTrue(proc.stdout.endswith("└───────────┴────────────────┘\x00\n"))

    def test_empty_stdin_reports_reference_parse_error(self):
        proc = run_cmd([], data="")
        self.assertEqual(proc.returncode, 1)
        self.assertEqual(
            proc.stdout,
            "Reading from stdin...\n"
            "[json.exception.parse_error.101] parse error at line 1, column 1: "
            "attempting to parse an empty input; check that your input string or stream contains the expected JSON\n",
        )

    def test_unclosed_object_reports_reference_column(self):
        proc = run_cmd([], data="{")
        self.assertEqual(proc.returncode, 1)
        self.assertEqual(
            proc.stdout,
            "Reading from stdin...\n"
            "[json.exception.parse_error.101] parse error at line 1, column 2: "
            "syntax error while parsing object key - unexpected end of input; expected string literal\n",
        )

    def test_file_json_renders_collapsed_nested_values(self):
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "sample.json"
            path.write_text('{"a":1,"b":[true,null,"x"],"c":{"d":false}}\n', encoding="utf-8")
            proc = run_cmd([str(path)])
        self.assertEqual(proc.returncode, 0)
        self.assertIn("\x1b[7m{\x1b[27m", proc.stdout)
        self.assertIn('\x1b[94m\x1b[49m"a"\x1b[39m\x1b[49m: \x1b[96m\x1b[49m1\x1b[39m\x1b[49m,', proc.stdout)
        self.assertIn('\x1b[94m\x1b[49m"b"\x1b[39m\x1b[49m: \x1b[1m[...]\x1b[22m,', proc.stdout)
        self.assertIn('\x1b[94m\x1b[49m"c"\x1b[39m\x1b[49m: \x1b[1m{...}\x1b[22m', proc.stdout)


if __name__ == "__main__":
    unittest.main()
