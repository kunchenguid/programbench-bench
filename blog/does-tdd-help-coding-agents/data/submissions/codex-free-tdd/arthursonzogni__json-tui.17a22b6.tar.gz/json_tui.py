#!/usr/bin/env python3
import json
import sys


HELP = """  json-tui {OPTIONS} [file]

    A JSON terminal UI

  OPTIONS:

      file                              A JSON file. Omit to read from stdin.
      -h, --help                        Display this help menu.
      -v, --version                     Print version.
      -k, --key, --keybinding           Display key binding.
      -f, --fullscreen                  Display the JSON in fullscreen, in an
                                        alternate buffer
      "--" can be used to terminate flag options and force all following
      arguments to be treated as positional options

    If no file is given, json-tui reads JSON from the standard input
    Please report bugs to:https://github.com/ArthurSonzogni/json-tui/issues
"""

KEYS = (
    "┌───────────┬────────────────┐\r\n"
    "│\x1b[36m\x1b[49mkeys       \x1b[39m\x1b[49m│\x1b[36m\x1b[49maction          \x1b[39m\x1b[49m│\r\n"
    "├───────────┼────────────────┤\r\n"
    "│Navigate   │← ↑ ↓ →         │\r\n"
    "│           │h j k l         │\r\n"
    "│           │Mouse::WheelUp  │\r\n"
    "│           │Mouse::WheelDown│\r\n"
    "├───────────┼────────────────┤\r\n"
    "│Toggle     │enter           │\r\n"
    "│           │Mouse::Left     │\r\n"
    "├───────────┼────────────────┤\r\n"
    "│Deep       │                │\r\n"
    "│ - Expand  │+               │\r\n"
    "│ - Collapse│-               │\r\n"
    "├───────────┼────────────────┤\r\n"
    "│Exit       │Escape          │\r\n"
    "│           │q               │\r\n"
    "├───────────┼────────────────┤\r\n"
    "│Navigate   │                │\r\n"
    "│ - first   │page-up         │\r\n"
    "│ - last    │page-down       │\r\n"
    "│ - top     │gg              │\r\n"
    "│ - bottom  │G               │\r\n"
    "└───────────┴────────────────┘\x00\n"
)


def parse_args(argv):
    fullscreen = False
    positional = []
    stop_flags = False
    for arg in argv:
        if stop_flags:
            positional.append(arg)
        elif arg == "--":
            stop_flags = True
        elif arg in ("-h", "--help"):
            return "help", fullscreen, []
        elif arg in ("-v", "--version"):
            return "version", fullscreen, []
        elif arg in ("-k", "--key", "--keybinding"):
            return "keys", fullscreen, []
        elif arg in ("-f", "--fullscreen"):
            fullscreen = True
        elif arg.startswith("-"):
            return "invalid", fullscreen, []
        else:
            positional.append(arg)
    if len(positional) > 1:
        return "invalid", fullscreen, positional
    return "view", fullscreen, positional


def parse_error_message(text, err):
    if text == "":
        return (
            "[json.exception.parse_error.101] parse error at line 1, column 1: "
            "attempting to parse an empty input; check that your input string or stream contains the expected JSON"
        )
    if err.pos >= len(text):
        column = err.colno
        if text.lstrip().startswith("{"):
            detail = "syntax error while parsing object key - unexpected end of input; expected string literal"
        elif text.lstrip().startswith("["):
            detail = "syntax error while parsing value - unexpected end of input; expected '[', '{', or a literal"
        else:
            detail = "syntax error while parsing value - unexpected end of input"
        return f"[json.exception.parse_error.101] parse error at line {err.lineno}, column {column}: {detail}"
    ch = text[err.pos : err.pos + 1]
    unexpected = repr(ch)[1:-1] if ch else "end of input"
    if ch == "]":
        detail = "syntax error while parsing value - unexpected ']'; expected '[', '{', or a literal"
    elif ch == "}":
        detail = "syntax error while parsing object key - unexpected '}'; expected string literal"
    else:
        detail = f"syntax error while parsing value - unexpected '{unexpected}'"
    return f"[json.exception.parse_error.101] parse error at line {err.lineno}, column {err.colno}: {detail}"


def color_key(key):
    return f'\x1b[94m\x1b[49m"{key}"\x1b[39m\x1b[49m'


def color_primitive(value):
    if isinstance(value, bool):
        text = "true" if value else "false"
        return f"\x1b[93m\x1b[49m{text}\x1b[39m\x1b[49m"
    if value is None:
        return "\x1b[90m\x1b[49mnull\x1b[39m\x1b[49m"
    if isinstance(value, (int, float)):
        return f"\x1b[96m\x1b[49m{json.dumps(value)}\x1b[39m\x1b[49m"
    return f"\x1b[92m\x1b[49m{json.dumps(value, ensure_ascii=False)}\x1b[39m\x1b[49m"


def collapsed(value):
    if isinstance(value, list):
        return "\x1b[1m[...]\x1b[22m"
    if isinstance(value, dict):
        return "\x1b[1m{...}\x1b[22m"
    return color_primitive(value)


def render_json(value):
    if isinstance(value, dict):
        lines = ["\x1b[7m{\x1b[27m"]
        items = list(value.items())
        for index, (key, child) in enumerate(items):
            comma = "," if index + 1 < len(items) else ""
            lines.append(f"  {color_key(str(key))}: {collapsed(child)}{comma}")
        lines.append("}")
        return "\r\r\n".join(lines) + "\r\r\n"
    if isinstance(value, list):
        lines = ["\x1b[7m[\x1b[27m"]
        for index, child in enumerate(value):
            comma = "," if index + 1 < len(value) else ""
            lines.append(f"  {collapsed(child)}{comma}")
        lines.append("]")
        return "\r\r\n".join(lines) + "\r\r\n"
    return f"\x1b[7m{color_primitive(value)}\x1b[27m\r\r\n"


def wait_for_quit_if_interactive():
    if not sys.stdin.isatty():
        return
    try:
        while True:
            ch = sys.stdin.read(1)
            if ch in ("q", "\x1b", ""):
                break
    except KeyboardInterrupt:
        pass


def main(argv):
    mode, _fullscreen, positional = parse_args(argv)
    if mode == "help":
        sys.stdout.write(HELP)
        return 0
    if mode == "version":
        sys.stdout.write("1.4.1\n")
        return 0
    if mode == "invalid":
        sys.stdout.write("Invalid arguments\n")
        return 1
    if mode == "keys":
        sys.stdout.write(KEYS)
        return 0
    source_name = None
    if positional:
        source_name = positional[0]
        try:
            with open(source_name, "r", encoding="utf-8") as handle:
                data = handle.read()
        except OSError:
            sys.stdout.write(f"Could not open file {positional[0]}\n")
            return 0
    else:
        sys.stdout.write("Reading from stdin...\n")
        data = sys.stdin.read()
    try:
        value = json.loads(data)
    except json.JSONDecodeError as err:
        sys.stdout.write(parse_error_message(data, err) + "\n")
        return 1
    if _fullscreen:
        sys.stdout.write("\x1b[?1049h")
    sys.stdout.write(render_json(value))
    wait_for_quit_if_interactive()
    if _fullscreen:
        sys.stdout.write("\x1b[?1049l")
    return 0


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
