#!/usr/bin/env python3
import os
import re
import sys
from dataclasses import dataclass


VERSION = "hexyl 0.16.0"

HELP = """A command-line hex viewer

Usage: executable [OPTIONS] [FILE]

Arguments:
  [FILE]  The file to display. If no FILE argument is given, read from STDIN

Options:
  -n, --length <N>                Only read N bytes from the input. The N argument can
                                  also include a unit with a decimal prefix (kB, MB, ..)
                                  or binary prefix (kiB, MiB, ..), or can be specified
                                  using a hex number. The short option '-l' can be used as
                                  an alias.
                                  Examples: --length=64, --length=4KiB, --length=0xff
                                  [aliases: bytes] [short aliases: c]
  -s, --skip <N>                  Skip the first N bytes of the input. The N argument can
                                  also include a unit (see `--length` for details).
                                  A negative value is valid and will seek from the end of
                                  the file.
      --block-size <SIZE>         Sets the size of the `block` unit to SIZE.
                                  Examples: --block-size=1024, --block-size=4kB [default:
                                  512]
  -v, --no-squeezing              Displays all input data. Otherwise any number of groups
                                  of output lines which would be identical to the
                                  preceding group of lines, are replaced with a line
                                  comprised of a single asterisk
      --color <WHEN>              When to use colors [default: always] [possible values:
                                  always, auto, never, force]
      --border <STYLE>            Whether to draw a border [default: unicode] [possible
                                  values: unicode, ascii, none]
  -p, --plain                     Display output with --no-characters, --no-position,
                                  --border=none, and --color=never
      --no-characters             Do not show the character panel on the right
  -C, --characters                Show the character panel on the right. This is the
                                  default, unless --no-characters has been specified
      --character-table <FORMAT>  Defines how bytes are mapped to characters [default:
                                  default] [possible values: default, ascii,
                                  codepage-1047, codepage-437, braille]
      --color-scheme <FORMAT>     Defines the color scheme for the characters [default:
                                  default] [possible values: default, gradient]
  -P, --no-position               Whether to display the position panel on the left
  -o, --display-offset <N>        Add N bytes to the displayed file position. The N
                                  argument can also include a unit (see `--length` for
                                  details).
                                  A negative value is valid and calculates an offset
                                  relative to the end of the file. [default: 0]
      --panels <N>                Sets the number of hex data panels to be displayed.
                                  `--panels=auto` will display the maximum number of hex
                                  data panels based on the current terminal width. By
                                  default, hexyl will show two panels, unless the terminal
                                  is not wide enough for that
  -g, --group-size <N>            Number of bytes/octets that should be grouped together.
                                  You can use the '--endianness' option to control the
                                  ordering of the bytes within a group. '--groupsize' can
                                  be used as an alias (xxd-compatibility) [default: 1]
                                  [possible values: 1, 2, 4, 8]
      --endianness <FORMAT>       Whether to print out groups in little-endian or
                                  big-endian format. This option only has an effect if the
                                  '--group-size' is larger than 1. '-e' can be used as an
                                  alias for '--endianness=little' [default: big] [possible
                                  values: little, big]
  -b, --base <B>                  Sets the base used for the bytes. The possible options
                                  are binary, octal, decimal, and hexadecimal [default:
                                  hexadecimal]
      --terminal-width <N>        Sets the number of terminal columns to be displayed.
                                  Since the terminal width may not be an evenly divisible
                                  by the width per hex data column, this will use the
                                  greatest number of hex data panels that can fit in the
                                  requested width but still leave some space to the right.
                                  Cannot be used with other width-setting options.
      --print-color-table         Print a table showing how different types of bytes are
                                  colored
  -i, --include                   Output in C include file style
      --completion <SHELL>        Show shell completion for a certain shell [possible
                                  values: bash, elvish, fish, powershell, zsh]
  -h, --help                      Print help (see more with '--help')
  -V, --version                   Print version
"""


@dataclass
class Options:
    length: int | None = None
    skip: int = 0
    block_size: int = 512
    squeeze: bool = True
    color: str = "always"
    border: str = "unicode"
    characters: bool = True
    position: bool = True
    char_table: str = "default"
    color_scheme: str = "default"
    display_offset: int = 0
    panels: int | None = None
    terminal_width: int | None = None
    group_size: int = 1
    endianness: str = "big"
    base: str = "hexadecimal"
    include: bool = False
    file: str | None = None
    input_start: int = 0


def die(message: str, code: int = 2) -> None:
    print(message, file=sys.stderr)
    sys.exit(code)


def parse_count(text: str, block_size: int, allow_negative: bool = True) -> int:
    sign = 1
    if text.startswith("-"):
        if not allow_negative:
            raise ValueError("negative offset specified, but only positive offsets (counts) are accepted in this context")
        sign = -1
        text = text[1:]
    if text.lower().startswith("0x"):
        return sign * int(text, 16)
    m = re.fullmatch(r"([0-9]+)([A-Za-z]*)", text)
    if not m:
        raise ValueError("invalid digit found in string")
    value = int(m.group(1))
    unit = m.group(2)
    factors = {
        "": 1,
        "b": 1,
        "kb": 1000,
        "mb": 1000**2,
        "gb": 1000**3,
        "kib": 1024,
        "mib": 1024**2,
        "gib": 1024**3,
        "block": block_size,
    }
    key = unit.lower()
    if key not in factors:
        raise ValueError("invalid unit")
    return sign * value * factors[key]


def take_value(args, i):
    arg = args[i]
    if "=" in arg:
        return arg.split("=", 1)[1], i
    if i + 1 >= len(args):
        die(f"error: a value is required for '{arg}' but none was supplied")
    return args[i + 1], i + 1


def parse_args(argv: list[str]) -> Options:
    opt = Options()
    j = 0
    while j < len(argv):
        arg = argv[j]
        if arg == "--block-size" or arg.startswith("--block-size="):
            val, j = take_value(argv, j)
            opt.block_size = parse_count(val, opt.block_size, allow_negative=False)
        j += 1
    i = 0
    while i < len(argv):
        arg = argv[i]
        if arg in ("-h", "--help"):
            print(HELP, end="")
            sys.exit(0)
        if arg in ("-V", "--version"):
            print(VERSION)
            sys.exit(0)
        if arg == "--print-color-table":
            print_color_table()
            sys.exit(0)
        if arg == "--completion":
            shell, i = take_value(argv, i)
            print_completion(shell)
            sys.exit(0)
        if arg.startswith("--completion="):
            print_completion(arg.split("=", 1)[1])
            sys.exit(0)
        if arg == "-p" or arg == "--plain":
            opt.characters = False
            opt.position = False
            opt.border = "none"
            opt.color = "never"
        elif arg in ("-v", "--no-squeezing"):
            opt.squeeze = False
        elif arg in ("-C", "--characters"):
            opt.characters = True
        elif arg == "--no-characters":
            opt.characters = False
        elif arg in ("-P", "--no-position"):
            opt.position = False
        elif arg == "-e":
            opt.endianness = "little"
        elif arg in ("-i", "--include"):
            opt.include = True
        elif arg in ("-n", "-c", "-l", "--length", "--bytes") or arg.startswith(("--length=", "--bytes=")):
            val, i = take_value(argv, i)
            opt.length = parse_count(val, opt.block_size, allow_negative=False)
        elif arg in ("-s", "--skip") or arg.startswith("--skip="):
            val, i = take_value(argv, i)
            opt.skip = parse_count(val, opt.block_size)
        elif arg == "--block-size" or arg.startswith("--block-size="):
            val, i = take_value(argv, i)
            opt.block_size = parse_count(val, opt.block_size, allow_negative=False)
        elif arg in ("-o", "--display-offset") or arg.startswith("--display-offset="):
            val, i = take_value(argv, i)
            opt.display_offset = parse_count(val, opt.block_size, allow_negative=False)
        elif arg == "--color" or arg.startswith("--color="):
            val, i = take_value(argv, i)
            opt.color = val
        elif arg == "--border" or arg.startswith("--border="):
            val, i = take_value(argv, i)
            opt.border = val
        elif arg == "--character-table" or arg.startswith("--character-table="):
            val, i = take_value(argv, i)
            opt.char_table = val
        elif arg == "--color-scheme" or arg.startswith("--color-scheme="):
            val, i = take_value(argv, i)
            opt.color_scheme = val
        elif arg in ("-g", "--group-size", "--groupsize") or arg.startswith(("--group-size=", "--groupsize=")):
            val, i = take_value(argv, i)
            opt.group_size = int(val)
            if opt.group_size not in (1, 2, 4, 8):
                die(f"error: invalid value '{val}' for '--group-size <N>'")
        elif arg == "--endianness" or arg.startswith("--endianness="):
            val, i = take_value(argv, i)
            opt.endianness = val
        elif arg in ("-b", "--base") or arg.startswith("--base="):
            val, i = take_value(argv, i)
            aliases = {"hex": "hexadecimal", "bin": "binary", "dec": "decimal", "oct": "octal"}
            opt.base = aliases.get(val, val)
        elif arg == "--panels" or arg.startswith("--panels="):
            val, i = take_value(argv, i)
            opt.panels = None if val == "auto" else int(val)
        elif arg == "--terminal-width" or arg.startswith("--terminal-width="):
            val, i = take_value(argv, i)
            opt.terminal_width = int(val)
        elif arg.startswith("-"):
            die(f"error: unexpected argument '{arg}' found\n\nUsage: executable [OPTIONS] [FILE]\n\nFor more information, try '--help'.")
        else:
            if opt.file is not None:
                die(f"error: unexpected argument '{arg}' found")
            opt.file = arg
        i += 1
    return opt


def print_color_table() -> None:
    print("hexyl color reference:\n")
    print("\x1b[90m⋄ NULL bytes (0x00)")
    print("\x1b[39m\x1b[36ma ASCII printable characters (0x20 - 0x7E)")
    print("\x1b[39m\x1b[32m_ ASCII whitespace (0x09 - 0x0D, 0x20)")
    print("\x1b[39m\x1b[32m• ASCII control characters (except NULL and whitespace)")
    print("\x1b[39m\x1b[33m× Non-ASCII bytes (0x80 - 0xFF)")
    print("\x1b[39m", end="")


def print_completion(shell: str) -> None:
    if shell == "bash":
        print("_hexyl() {\n    COMPREPLY=()\n}\ncomplete -F _hexyl -o bashdefault -o default hexyl")
    else:
        print(f"# completion for {shell}")


def read_input(opt: Options) -> bytes:
    try:
        if opt.file:
            data = open(opt.file, "rb").read()
        else:
            data = sys.stdin.buffer.read()
    except OSError as e:
        die(f"Error: {e}", 1)
    start = opt.skip if opt.skip >= 0 else max(len(data) + opt.skip, 0)
    opt.input_start = start
    data = data[start:]
    if opt.length is not None:
        data = data[: opt.length]
    return data


def char_for(b: int, table: str) -> str:
    if table == "ascii":
        if b == 0x20:
            return " "
        if 0x21 <= b <= 0x7E:
            return chr(b)
        return "."
    if table == "braille":
        braille = {
            0: "⋄", 1: "⠁", 2: "⠈", 3: "⠉", 4: "⠂", 5: "⠃", 6: "⠊", 7: "⠋",
            8: "⠐", 9: "→", 10: "↵", 11: "⠙", 12: "⠒", 13: "←", 14: "⠚", 15: "⠛",
        }
        return braille.get(b, char_for(b, "default"))
    if b == 0:
        return "⋄"
    if b == 0x20:
        return " "
    if b in (9, 10, 12, 13):
        return "_"
    if 0x21 <= b <= 0x7E:
        return chr(b)
    if b < 0x80:
        return "•"
    return "×"


def color_enabled(opt: Options) -> bool:
    if opt.color == "never":
        return False
    if opt.color == "auto":
        return sys.stdout.isatty() and "NO_COLOR" not in os.environ
    if opt.color == "force":
        return True
    return "NO_COLOR" not in os.environ


def byte_color(b: int) -> str:
    if b == 0:
        return "\x1b[90m"
    if b == 0x20 or b in (9, 10, 12, 13):
        return "\x1b[32m"
    if 0x21 <= b <= 0x7E:
        return "\x1b[36m"
    if b < 0x80:
        return "\x1b[32m"
    return "\x1b[33m"


def byte_text(b: int, base: str) -> str:
    if base == "binary":
        return f"{b:08b}"
    if base == "octal":
        return f"{b:03o}"
    if base == "decimal":
        return f"{b:03d}"
    return f"{b:02x}"


def panel_width(opt: Options) -> int:
    if opt.base == "binary":
        return 73
    if opt.base in ("octal", "decimal"):
        return 33
    groups = 8 // opt.group_size
    return 1 + 8 * 2 + max(groups - 1, 0) + 1


def format_hex_panel(chunk: bytes, opt: Options) -> str:
    width = panel_width(opt)
    pieces = []
    step = 1 if opt.base != "hexadecimal" else opt.group_size
    for i in range(0, len(chunk), step):
        group = list(chunk[i : i + step])
        if opt.base == "hexadecimal" and opt.endianness == "little" and len(group) == step:
            group = list(reversed(group))
        pieces.append("".join(byte_text(b, opt.base) for b in group) if opt.base == "hexadecimal" else byte_text(group[0], opt.base))
    inner = " ".join(pieces)
    return (" " + inner).ljust(width)


def format_hex_panel_color(chunk: bytes, opt: Options) -> str:
    width = panel_width(opt)
    out = [" "]
    visible = 1
    current = None
    step = 1 if opt.base != "hexadecimal" else opt.group_size
    group_count = (7 // step) + 1
    for gi, i in enumerate(range(0, len(chunk), step)):
        group = list(chunk[i : i + step])
        shown = list(group)
        if opt.base == "hexadecimal" and opt.endianness == "little" and len(shown) == step:
            shown = list(reversed(shown))
        if gi > 0:
            out.append(" ")
            visible += 1
        if opt.base == "hexadecimal":
            for b in shown:
                c = byte_color(b)
                if c != current:
                    out.append(c)
                    current = c
                out.append(byte_text(b, opt.base))
                visible += 2
        else:
            b = shown[0]
            c = byte_color(b)
            if c != current:
                out.append(c)
                current = c
            text = byte_text(b, opt.base)
            out.append(text)
            visible += len(text)
    if visible < width - 1:
        out.append(" " * (width - visible - 1))
    out.append("\x1b[39m")
    if visible < width:
        out.append(" ")
    return "".join(out)


def format_char_panel(chunk: bytes, opt: Options) -> str:
    return "".join(char_for(b, opt.char_table) for b in chunk).ljust(8)


def format_char_panel_color(chunk: bytes, opt: Options) -> str:
    out = []
    current = None
    visible = 0
    for b in chunk:
        c = byte_color(b)
        if c != current:
            out.append(c)
            current = c
        out.append(char_for(b, opt.char_table))
        visible += 1
    if visible < 8:
        out.append(" " * (8 - visible))
    out.append("\x1b[39m")
    return "".join(out)


def border_chars(style: str):
    if style == "ascii":
        return "+", "+", "+", "+", "+", "+", "-", "|", "|"
    return "┌", "┬", "┐", "└", "┴", "┘", "─", "│", "┊"


def make_border(opt: Options, top: bool, widths: list[int]) -> str:
    a, mid, c, d, botmid, f, h, _, _ = border_chars(opt.border)
    left, join, right = (a, mid, c) if top else (d, botmid, f)
    return left + join.join(h * w for w in widths) + right + "\n"


def choose_panels(opt: Options) -> int:
    if opt.panels:
        return opt.panels
    if opt.terminal_width:
        per = panel_width(opt) + (8 if opt.characters else 0)
        return max(1, min(8, (opt.terminal_width - 10) // max(per, 1)))
    return 1 if opt.base in ("binary", "octal", "decimal") else 2


def rows_for(data: bytes, opt: Options):
    panels = choose_panels(opt)
    row_size = panels * 8
    for offset in range(0, len(data), row_size):
        yield offset, data[offset : offset + row_size]


def render(data: bytes, opt: Options) -> str:
    panels = choose_panels(opt)
    pwidth = panel_width(opt)
    widths = []
    if opt.position:
        widths.append(8)
    widths += [pwidth] * panels
    if opt.characters:
        widths += [8] * panels

    if opt.border == "none":
        out = []
    else:
        out = [make_border(opt, True, widths)]

    if not data:
        if opt.border == "none":
            return ""
        a, _, _, _, _, _, _, v, sep = border_chars(opt.border)
        parts = []
        if opt.position:
            parts.append(" " * 8)
        parts.append(" No content".ljust(pwidth))
        parts += [" " * pwidth] * (panels - 1)
        if opt.characters:
            parts += [" " * 8] * panels
        out.append(v + v.join(parts) + v + "\n")
        out.append(make_border(opt, False, widths))
        return "".join(out)

    prev_full = None
    squeezed = False
    for offset, row in rows_for(data, opt):
        if opt.squeeze and len(row) == panels * 8 and row == prev_full:
            if not squeezed:
                out.append(format_line("*", [b"" for _ in range(panels)], opt, squeeze=True))
                squeezed = True
            continue
        squeezed = False
        if len(row) == panels * 8:
            prev_full = row
        chunks = [row[i * 8 : (i + 1) * 8] for i in range(panels)]
        out.append(format_line(f"{offset + opt.input_start + opt.display_offset:08x}", chunks, opt))
    if opt.border != "none":
        out.append(make_border(opt, False, widths))
    return "".join(out)


def format_line(offset_text: str, chunks: list[bytes], opt: Options, squeeze: bool = False) -> str:
    if opt.border == "none":
        left = ""
        sep = "  "
        right = ""
        mid = "  "
    else:
        _, _, _, _, _, _, _, left, mid = border_chars(opt.border)
        sep = left
        right = left
    use_color = color_enabled(opt) and not squeeze
    fields = []
    if opt.position:
        pos = (offset_text if not squeeze else "*").ljust(8)
        fields.append("\x1b[90m" + pos + "\x1b[39m" if use_color else pos)
    if squeeze:
        fields += [" " * panel_width(opt) for _ in chunks]
        if opt.characters:
            fields += [" " * 8 for _ in chunks]
    else:
        fields += [(format_hex_panel_color(c, opt) if use_color else format_hex_panel(c, opt)) for c in chunks]
        if opt.characters:
            fields += [(format_char_panel_color(c, opt) if use_color else format_char_panel(c, opt)) for c in chunks]
    if opt.border == "none":
        pos = (" " + fields[0] + " ") if opt.position else " "
        idx = 1 if opt.position else 0
        hexes = (" ".join(fields[idx : idx + len(chunks)]))
        chars = ""
        if opt.characters:
            chars = " " + " ".join(fields[idx + len(chunks) :])
        return pos + hexes + chars + " \n"
    if opt.border == "unicode" and len(chunks) > 1:
        if opt.position:
            if not opt.characters:
                return left + fields[0] + left + mid.join(fields[1 : 1 + len(chunks)]) + right + "\n"
            return left + fields[0] + left + mid.join(fields[1 : 1 + len(chunks)]) + left + mid.join(fields[1 + len(chunks) :]) + right + "\n"
        if not opt.characters:
            return left + mid.join(fields[: len(chunks)]) + right + "\n"
        return left + mid.join(fields[: len(chunks)]) + left + mid.join(fields[len(chunks) :]) + right + "\n"
    return left + sep.join(fields) + right + "\n"


def render_include(data: bytes, file_name: str | None) -> str:
    stem = "stdin" if not file_name else os.path.basename(file_name)
    name = re.sub(r"\W", "_", stem)
    values = [f"0x{b:02x}" for b in data]
    out = [f"unsigned char {name}[] = {{\n"]
    for i in range(0, len(values), 12):
        line = ", ".join(values[i : i + 12])
        if i + 12 < len(values):
            line += ","
        out.append("  " + line + "\n")
    out.append("};\n")
    out.append(f"unsigned int {name}_len = {len(data)};\n")
    return "".join(out)


def main(argv: list[str]) -> int:
    try:
        opt = parse_args(argv)
    except ValueError as e:
        print(f"Error: {e}", file=sys.stderr)
        return 1
    data = read_input(opt)
    if opt.include:
        sys.stdout.write(render_include(data, opt.file))
    else:
        sys.stdout.write(render(data, opt))
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
