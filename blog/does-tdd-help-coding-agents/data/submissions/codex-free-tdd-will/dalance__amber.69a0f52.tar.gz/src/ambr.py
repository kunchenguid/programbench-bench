#!/usr/bin/env python3
import argparse
import fnmatch
import os
import re
import sys
from pathlib import Path


HELP = """ambr 0.6.0

USAGE:
    executable [FLAGS] [OPTIONS] <KEYWORD> <REPLACEMENT> [PATHS]...

FLAGS:
        --key-from-file        Use file contents of KEYWORD as keyword for search
        --rep-from-file        Use file contents of REPLACEMENT as keyword for replacement
        --verbose              Verbose message
    -r, --regex                Enable regular expression search
        --column               Enable column output
        --row                  Enable row output
        --binary               Enable binary file search
        --statistics           Enable statistics output
        --skipped              Enable skipped file output
        --preserve-time        Enable timestamp preserve
        --no-interactive       Disable interactive replace
        --no-recursive         Disable recursive directory search
        --no-symlink           Disable symbolic link follow
        --no-color             Disable colored output
        --no-file              Disable filename output
        --no-skip-vcs          Disable vcs directory ( .hg/.git/.svn ) skip
        --no-skip-gitignore    Disable .gitignore skip
        --no-fixed-order       Disable output order guarantee
        --no-parent-ignore     Disable .*ignore file search at parent directories
        --tbm                  [Experimental] Enable TBM matcher
        --sse                  [Experimental] Enable SSE 4.2
    -h, --help                 Prints help information
    -V, --version              Prints version information

OPTIONS:
        --max-threads <NUM>          Number of max threads [default: 4]
        --size-per-thread <BYTES>    File size per one thread [default: 1048576]
        --bin-check-bytes <BYTES>    Read size for checking binary [default: 256]
        --mmap-bytes <BYTES>         [Experimental] Minimum size for using mmap [default: 1048576]

ARGS:
    <KEYWORD>        Keyword for search
    <REPLACEMENT>    Keyword for replace
    <PATHS>...       Search paths
"""


def build_parser():
    parser = argparse.ArgumentParser(add_help=False, prog="executable")
    parser.add_argument("--no-interactive", action="store_true")
    parser.add_argument("--no-color", action="store_true")
    parser.add_argument("--no-recursive", action="store_true")
    parser.add_argument("-r", "--regex", action="store_true")
    parser.add_argument("--binary", action="store_true")
    parser.add_argument("--key-from-file", action="store_true")
    parser.add_argument("--rep-from-file", action="store_true")
    parser.add_argument("--verbose", action="store_true")
    parser.add_argument("--column", action="store_true")
    parser.add_argument("--row", action="store_true")
    parser.add_argument("--statistics", action="store_true")
    parser.add_argument("--skipped", action="store_true")
    parser.add_argument("--preserve-time", action="store_true")
    parser.add_argument("--no-symlink", action="store_true")
    parser.add_argument("--no-file", action="store_true")
    parser.add_argument("--no-fixed-order", action="store_true")
    parser.add_argument("--no-parent-ignore", action="store_true")
    parser.add_argument("--tbm", action="store_true")
    parser.add_argument("--sse", action="store_true")
    parser.add_argument("--max-threads")
    parser.add_argument("--size-per-thread")
    parser.add_argument("--bin-check-bytes", type=int, default=256)
    parser.add_argument("--mmap-bytes")
    parser.add_argument("--no-skip-vcs", action="store_true")
    parser.add_argument("--no-skip-gitignore", action="store_true")
    parser.add_argument("keyword")
    parser.add_argument("replacement")
    parser.add_argument("paths", nargs="*")
    return parser


def expand_amber_replacement(match, replacement):
    out = []
    i = 0
    while i < len(replacement):
        ch = replacement[i]
        if ch != "$":
            out.append(ch)
            i += 1
            continue
        if i + 1 >= len(replacement):
            out.append("$")
            i += 1
            continue
        if replacement[i + 1] == "{":
            end = replacement.find("}", i + 2)
            if end != -1:
                name = replacement[i + 2 : end]
                out.append(group_value(match, name))
                i = end + 1
                continue
        j = i + 1
        if replacement[j].isdigit():
            while j < len(replacement) and replacement[j].isdigit():
                j += 1
        else:
            while j < len(replacement) and (replacement[j].isalnum() or replacement[j] == "_"):
                j += 1
        if j > i + 1:
            token = replacement[i + 1 : j]
            out.append(group_value(match, token))
            i = j
        else:
            out.append("$")
            i += 1
    return "".join(out)


def group_value(match, name):
    try:
        if name.isdigit():
            value = match.group(int(name))
        else:
            value = match.group(name)
    except (IndexError, KeyError):
        value = ""
    return "" if value is None else value


def normalize_regex(pattern):
    return re.sub(r"\(\?<([A-Za-z_][A-Za-z0-9_]*)>", r"(?P<\1>", pattern)


def is_binary_file(path, check_bytes=256):
    try:
        return b"\x00" in path.read_bytes()[:check_bytes]
    except OSError:
        return True


def rewritten_content(path, keyword, replacement, regex=False, binary=False):
    data = path.read_bytes()
    if b"\x00" in data[:256] and not binary:
        return None
    text = data.decode("utf-8", errors="surrogateescape")
    if regex:
        pattern = re.compile(normalize_regex(keyword))
        updated = pattern.sub(lambda m: expand_amber_replacement(m, replacement), text)
    else:
        updated = text.replace(keyword, replacement)
    if updated == text:
        return None
    return updated.encode("utf-8", errors="surrogateescape")


def should_replace(path, all_mode):
    if all_mode:
        return True, True, False
    sys.stdout.write("Replace keyword? ( Yes[Y], No[N], All[A], Quit[Q] ):\n")
    sys.stdout.flush()
    answer = sys.stdin.readline()
    normalized = answer.strip().lower()
    if normalized in ("y", "yes"):
        return True, False, False
    if normalized in ("a", "all"):
        return True, True, False
    if normalized in ("q", "quit"):
        return False, False, True
    return False, False, False


def load_ignore_patterns(directory):
    ignore = directory / ".gitignore"
    if not ignore.is_file():
        return []
    patterns = []
    try:
        for line in ignore.read_text(encoding="utf-8").splitlines():
            line = line.strip()
            if line and not line.startswith("#"):
                patterns.append(line)
    except UnicodeDecodeError:
        pass
    return patterns


def ignored_by_patterns(rel, patterns):
    rel_text = rel.as_posix()
    name = rel.name
    for pattern in patterns:
        if pattern.endswith("/"):
            prefix = pattern.rstrip("/")
            if rel_text == prefix or rel_text.startswith(prefix + "/"):
                return True
        elif "/" in pattern:
            if fnmatch.fnmatch(rel_text, pattern):
                return True
        elif fnmatch.fnmatch(name, pattern):
            return True
    return False


def iter_files(root, skip_vcs=True, skip_gitignore=True, recursive=True):
    if root.is_file():
        yield root
        return
    if not root.is_dir():
        return
    vcs_dirs = {".git", ".hg", ".svn", ".bzr"}
    patterns = load_ignore_patterns(root) if skip_gitignore else []
    children = root.rglob("*") if recursive else root.iterdir()
    for child in sorted(children):
        try:
            rel = child.relative_to(root)
        except ValueError:
            rel = child
        if skip_vcs and any(part in vcs_dirs for part in rel.parts):
            continue
        if ignored_by_patterns(rel, patterns):
            continue
        if child.is_file():
            yield child


def main(argv=None):
    argv = sys.argv[1:] if argv is None else argv
    if "-h" in argv or "--help" in argv:
        sys.stdout.write(HELP)
        return 0
    if "-V" in argv or "--version" in argv:
        sys.stdout.write("ambr 0.6.0\n")
        return 0
    args = build_parser().parse_args(argv)
    keyword = Path(args.keyword).read_text(encoding="utf-8") if args.key_from_file else args.keyword
    replacement = (
        Path(args.replacement).read_text(encoding="utf-8")
        if args.rep_from_file
        else args.replacement
    )
    paths = [Path(p) for p in args.paths] or [Path(".")]
    changed = False
    all_mode = args.no_interactive
    for path in paths:
        for file_path in iter_files(
            path,
            skip_vcs=not args.no_skip_vcs,
            skip_gitignore=not args.no_skip_gitignore,
            recursive=not args.no_recursive,
        ):
            updated = rewritten_content(
                file_path,
                keyword,
                replacement,
                regex=args.regex,
                binary=args.binary,
            )
            if updated is None:
                continue
            do_replace, all_mode, quit_now = should_replace(file_path, all_mode)
            if do_replace:
                original_stat = file_path.stat()
                file_path.write_bytes(updated)
                if args.preserve_time:
                    os.utime(file_path, (original_stat.st_atime, original_stat.st_mtime))
                changed = True
            if quit_now:
                return 0 if changed else 1
    return 0 if changed else 1


if __name__ == "__main__":
    sys.exit(main())
