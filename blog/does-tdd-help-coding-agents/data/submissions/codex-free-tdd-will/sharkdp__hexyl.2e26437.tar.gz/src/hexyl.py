#!/usr/bin/env python3
import os
import sys


VERSION = "hexyl 0.16.0"
HELP = """A command-line hex viewer

Usage: executable [OPTIONS] [FILE]

Arguments:
  [FILE]
          The file to display. If no FILE argument is given, read from STDIN

Options:
  -n, --length <N>
          Only read N bytes from the input
  -s, --skip <N>
          Skip the first N bytes of the input
      --block-size <SIZE>
          Sets the size of the `block` unit to SIZE
  -v, --no-squeezing
          Displays all input data
      --color <WHEN>
          When to use colors
      --border <STYLE>
          Whether to draw a border
  -p, --plain
          Display output with --no-characters, --no-position, --border=none, and --color=never
      --no-characters
          Do not show the character panel on the right
  -C, --characters
          Show the character panel on the right
  -P, --no-position
          Whether to display the position panel on the left
  -o, --display-offset <N>
          Add N bytes to the displayed file position
      --panels <N>
          Sets the number of hex data panels to be displayed
  -g, --group-size <N>
          Number of bytes/octets that should be grouped together
      --endianness <FORMAT>
          Whether to print out groups in little-endian or big-endian format
  -b, --base <B>
          Sets the base used for the bytes
  -h, --help
          Print help
  -V, --version
          Print version
"""


class Config:
    def __init__(self):
        self.length = None
        self.skip = 0
        self.block_size = 512
        self.border = "unicode"
        self.show_position = True
        self.show_chars = True
        self.panels = 2
        self.group_size = 1
        self.endianness = "big"
        self.base = "hexadecimal"
        self.display_offset = 0
        self.no_squeezing = False
        self.include = False
        self.character_table = "default"
        self.file = None


def parse_count(text, block_size=512):
    s = str(text).strip()
    sign = -1 if s.startswith("-") else 1
    if s[:1] in "+-":
        s = s[1:]
    lower = s.lower()
    if lower.startswith("0x"):
        return sign * int(lower, 16)
    units = [
        ("kib", 1024),
        ("mib", 1024**2),
        ("gib", 1024**3),
        ("kb", 1000),
        ("mb", 1000**2),
        ("gb", 1000**3),
        ("block", block_size),
        ("b", 1),
    ]
    for suffix, factor in units:
        if lower.endswith(suffix):
            number = lower[: -len(suffix)]
            if not number:
                raise ValueError(text)
            return sign * int(number, 10) * factor
    return sign * int(lower, 10)


def parse_args(argv):
    cfg = Config()
    i = 0
    while i < len(argv):
        arg = argv[i]
        value = None
        if arg.startswith("--") and "=" in arg:
            arg, value = arg.split("=", 1)
        def need_value():
            nonlocal i, value
            if value is not None:
                return value
            i += 1
            if i >= len(argv):
                raise SystemExit(2)
            return argv[i]
        if arg in ("--help", "-h"):
            print(HELP, end="")
            raise SystemExit(0)
        if arg in ("--version", "-V"):
            print(VERSION)
            raise SystemExit(0)
        if arg in ("--length", "--bytes", "-n", "-c", "-l"):
            cfg.length = parse_count(need_value(), cfg.block_size)
        elif arg == "--skip" or arg == "-s":
            cfg.skip = parse_count(need_value(), cfg.block_size)
        elif arg == "--block-size":
            cfg.block_size = parse_count(need_value(), cfg.block_size)
        elif arg in ("--color", "--color-scheme", "--terminal-width", "--completion"):
            need_value()
        elif arg == "--character-table":
            cfg.character_table = need_value()
        elif arg == "--border":
            cfg.border = need_value()
        elif arg == "--plain" or arg == "-p":
            cfg.border = "none"
            cfg.show_position = False
            cfg.show_chars = False
        elif arg == "--no-characters":
            cfg.show_chars = False
        elif arg == "--characters" or arg == "-C":
            cfg.show_chars = True
        elif arg == "--no-position" or arg == "-P":
            cfg.show_position = False
        elif arg == "--display-offset" or arg == "-o":
            cfg.display_offset = parse_count(need_value(), cfg.block_size)
        elif arg == "--panels":
            v = need_value()
            cfg.panels = 2 if v == "auto" else max(1, int(v))
        elif arg in ("--group-size", "--groupsize", "-g"):
            cfg.group_size = int(need_value())
        elif arg == "--endianness":
            cfg.endianness = need_value()
        elif arg == "-e":
            cfg.endianness = "little"
        elif arg == "--base" or arg == "-b":
            cfg.base = need_value()
        elif arg == "--no-squeezing" or arg == "-v":
            cfg.no_squeezing = True
        elif arg == "--include" or arg == "-i":
            cfg.include = True
        elif arg == "--print-color-table":
            pass
        elif arg.startswith("-"):
            print(f"error: unexpected argument '{arg}' found", file=sys.stderr)
            raise SystemExit(2)
        else:
            cfg.file = arg
        i += 1
    return cfg


def format_unit(values, base):
    if base in ("hexadecimal", "hex"):
        return "".join(f"{b:02x}" for b in values)
    if base in ("decimal", "dec"):
        return " ".join(f"{b:03d}" for b in values)
    if base in ("octal", "oct"):
        return " ".join(f"{b:03o}" for b in values)
    if base in ("binary", "bin"):
        return " ".join(f"{b:08b}" for b in values)
    return "".join(f"{b:02x}" for b in values)


def raw_panel(chunk, group_size=1, endianness="big", base="hexadecimal"):
    parts = []
    for i in range(0, len(chunk), group_size):
        group = list(chunk[i : i + group_size])
        shown = list(reversed(group)) if endianness == "little" else group
        parts.append(format_unit(shown, base))
    return " ".join(parts)


def panel_display_width(group_size=1, base="hexadecimal"):
    if base in ("binary", "bin"):
        return 71
    if base in ("decimal", "dec", "octal", "oct"):
        return 31
    return {1: 23, 2: 19, 4: 17, 8: 16}.get(group_size, 23)


def format_hex_panel(chunk, group_size=1, endianness="big", base="hexadecimal"):
    return raw_panel(chunk, group_size, endianness, base).ljust(panel_display_width(group_size, base))


def char_for_byte(b, table="default"):
    if table == "ascii":
        if b == 32:
            return " "
        if 33 <= b <= 126:
            return chr(b)
        return "."
    if table == "braille":
        if b == 0:
            return "⋄"
        dots = [0x01, 0x08, 0x02, 0x10, 0x04, 0x20, 0x40, 0x80]
        pattern = 0
        for bit, dot in enumerate(dots):
            if b & (1 << bit):
                pattern |= dot
        return chr(0x2800 + pattern)
    if b == 0:
        return "⋄"
    if b == 32:
        return " "
    if b in (9, 10, 11, 12, 13):
        return "_"
    if 33 <= b <= 126:
        return chr(b)
    if b < 128:
        return "•"
    return "×"


def format_char_panel(chunk, table="default"):
    return "".join(char_for_byte(b, table) for b in chunk).ljust(8)


def panel_width(group_size=1, base="hexadecimal"):
    return panel_display_width(group_size, base)


def dump(data, cfg):
    border = cfg.border
    show_position = cfg.show_position
    show_chars = cfg.show_chars
    row_bytes = 8 * cfg.panels
    hex_width = panel_width(cfg.group_size, cfg.base)
    if border == "none":
        lines = []
        previous_full = None
        squeezed = False
        for start in range(0, len(data), row_bytes):
            chunk = data[start : start + row_bytes]
            if (
                not cfg.no_squeezing
                and len(chunk) == row_bytes
                and previous_full is not None
                and chunk == previous_full
            ):
                if not squeezed:
                    normal_width = len(lines[-1]) if lines else 0
                    lines.append(" *" + " " * max(0, normal_width - 2))
                    squeezed = True
                continue
            if len(chunk) == row_bytes:
                previous_full = bytes(chunk)
            squeezed = False
            prefix = f" {start + cfg.display_offset:08x}  " if show_position else " "
            hex_panels = [
                format_hex_panel(chunk[p : p + 8], cfg.group_size, cfg.endianness, cfg.base).ljust(hex_width)
                for p in range(0, row_bytes, 8)
            ]
            hex_part = "   ".join(hex_panels)
            chars = ""
            if show_chars:
                chars = " " + " ".join(format_char_panel(chunk[p : p + 8], cfg.character_table) for p in range(0, row_bytes, 8))
            lines.append(f"{prefix}{hex_part} {chars} ")
        return "\n".join(lines) + ("\n" if lines else "")
    return dump_bordered(data, cfg, ascii_border=(border == "ascii"))


def dump_bordered(data, cfg, ascii_border=False):
    row_bytes = 8 * cfg.panels
    hwidth = panel_width(cfg.group_size, cfg.base)
    pos = cfg.show_position
    chars = cfg.show_chars
    if ascii_border:
        tl, tr, bl, br, h, v, tj, bj, sep = "+", "+", "+", "+", "-", "|", "+", "+", "|"
    else:
        tl, tr, bl, br, h, v, tj, bj, sep = "┌", "┐", "└", "┘", "─", "│", "┬", "┴", "┊"
    widths = []
    if pos:
        widths.append(8)
    widths.extend([hwidth + 2] * cfg.panels)
    if chars:
        widths.extend([8] * cfg.panels)
    top = tl + tj.join(h * w for w in widths) + tr
    bottom = bl + bj.join(h * w for w in widths) + br
    lines = [top]
    previous_full = None
    squeezed = False
    for start in range(0, len(data), row_bytes):
        chunk = data[start : start + row_bytes]
        if (
            not cfg.no_squeezing
            and len(chunk) == row_bytes
            and previous_full is not None
            and chunk == previous_full
        ):
            if not squeezed:
                star_cells = []
                if pos:
                    star_cells.append("*".ljust(8))
                star_cells.extend([" " * (hwidth + 2)] * cfg.panels)
                if chars:
                    star_cells.extend([" " * 8] * cfg.panels)
                if ascii_border:
                    lines.append(v + sep.join(star_cells) + v)
                else:
                    line = v
                    idx = 0
                    if pos:
                        line += star_cells[idx] + v
                        idx += 1
                    for panel in range(cfg.panels):
                        line += star_cells[idx]
                        idx += 1
                        line += ("┊" if panel < cfg.panels - 1 else v)
                    if chars:
                        for panel in range(cfg.panels):
                            line += star_cells[idx]
                            idx += 1
                            line += ("┊" if panel < cfg.panels - 1 else v)
                    lines.append(line)
                squeezed = True
            continue
        if len(chunk) == row_bytes:
            previous_full = bytes(chunk)
        squeezed = False
        cells = []
        if pos:
            cells.append(f"{start + cfg.display_offset:08x}")
        for p in range(0, row_bytes, 8):
            cells.append(" " + format_hex_panel(chunk[p : p + 8], cfg.group_size, cfg.endianness, cfg.base).ljust(hwidth) + " ")
        if chars:
            for p in range(0, row_bytes, 8):
                cells.append(format_char_panel(chunk[p : p + 8], cfg.character_table))
        if ascii_border:
            lines.append(v + sep.join(cells) + v)
        else:
            line = v
            idx = 0
            if pos:
                line += cells[idx] + v
                idx += 1
            for panel in range(cfg.panels):
                line += cells[idx]
                idx += 1
                line += ("┊" if panel < cfg.panels - 1 else v)
            if chars:
                for panel in range(cfg.panels):
                    line += cells[idx]
                    idx += 1
                    line += ("┊" if panel < cfg.panels - 1 else v)
            lines.append(line)
    lines.append(bottom)
    return "\n".join(lines) + "\n"


def dump_plain(data):
    cfg = Config()
    cfg.border = "none"
    cfg.show_position = False
    cfg.show_chars = False
    lines = []
    for start in range(0, len(data), 16):
        chunk = data[start : start + 16]
        lines.append(f"  {format_hex_panel(chunk[:8])}   {format_hex_panel(chunk[8:16])}  ")
    return "\n".join(lines) + ("\n" if lines else "")


def dump_plain_configured(data, cfg):
    lines = []
    panel_count = 1 if cfg.base in ("binary", "bin") and cfg.panels == 2 else cfg.panels
    previous_full = None
    squeezed = False
    for start in range(0, len(data), 8 * panel_count):
        chunk = data[start : start + 8 * panel_count]
        row_bytes = 8 * panel_count
        if (
            not cfg.no_squeezing
            and len(chunk) == row_bytes
            and previous_full is not None
            and chunk == previous_full
        ):
            if not squeezed:
                normal_width = len(lines[-1]) if lines else 0
                lines.append(" *" + " " * max(0, normal_width - 2))
                squeezed = True
            continue
        if len(chunk) == row_bytes:
            previous_full = bytes(chunk)
        squeezed = False
        rendered_panels = [
            format_hex_panel(chunk[p : p + 8], cfg.group_size, cfg.endianness, cfg.base)
            for p in range(0, 8 * panel_count, 8)
        ]
        lines.append("  " + "   ".join(rendered_panels) + "  ")
    return "\n".join(lines) + ("\n" if lines else "")


def read_input(cfg):
    if cfg.file:
        with open(cfg.file, "rb") as f:
            data = f.read()
    else:
        data = sys.stdin.buffer.read()
    size = len(data)
    skip = cfg.skip
    if skip < 0:
        skip = max(0, size + skip)
    data = data[skip:]
    if cfg.length is not None:
        data = data[: max(0, cfg.length)]
    return data


def include_name(path):
    base = os.path.basename(path or "stdin")
    return "".join(ch if ch.isalnum() else "_" for ch in base)


def dump_include(data, cfg):
    name = include_name(cfg.file)
    lines = [f"unsigned char {name}[] = {{"]
    if data:
        for start in range(0, len(data), 12):
            chunk = data[start : start + 12]
            suffix = "," if start + 12 < len(data) else ""
            lines.append("  " + ", ".join(f"0x{b:02x}" for b in chunk) + suffix)
    lines.append("};")
    lines.append(f"unsigned int {name}_len = {len(data)};")
    return "\n".join(lines) + "\n"


def main(argv=None):
    argv = list(sys.argv[1:] if argv is None else argv)
    try:
        cfg = parse_args(argv)
        data = read_input(cfg)
        if cfg.display_offset < 0 and cfg.file:
            cfg.display_offset = os.path.getsize(cfg.file) + cfg.display_offset
        if cfg.include:
            sys.stdout.write(dump_include(data, cfg))
            return 0
        if cfg.border == "none" and not cfg.show_position and not cfg.show_chars:
            sys.stdout.write(dump_plain_configured(data, cfg))
        else:
            sys.stdout.write(dump(data, cfg))
        return 0
    except FileNotFoundError as e:
        print(f"Error: {e.strerror} (os error {e.errno})", file=sys.stderr)
        return 1
    except ValueError as e:
        print(f"Error: {e}", file=sys.stderr)
        return 1
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
