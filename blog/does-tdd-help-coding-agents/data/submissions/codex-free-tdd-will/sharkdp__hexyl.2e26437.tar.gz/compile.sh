#!/bin/bash
set -e
cp src/hexyl.py executable
chmod +x executable
