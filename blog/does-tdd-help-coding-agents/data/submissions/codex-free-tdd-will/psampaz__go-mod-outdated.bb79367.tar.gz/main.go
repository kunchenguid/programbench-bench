package main

import (
	"encoding/json"
	"flag"
	"fmt"
	"io"
	"log"
	"os"
	"strings"
	"time"
)

type module struct {
	Path     string
	Version  string
	Time     string
	Update   *moduleRef
	Replace  *moduleRef
	Indirect bool
}

type moduleRef struct {
	Path    string
	Version string
	Time    string
}

type row struct {
	module          string
	version         string
	newVersion      string
	direct          string
	validTimestamps string
	hasUpdate       bool
}

func main() {
	os.Exit(run(os.Args[1:], os.Stdin, os.Stdout, os.Stderr))
}

func run(args []string, in io.Reader, out, errw io.Writer) int {
	fs := flag.NewFlagSet(os.Args[0], flag.ContinueOnError)
	fs.SetOutput(errw)
	onlyDirect := fs.Bool("direct", false, "List only direct modules")
	onlyUpdate := fs.Bool("update", false, "List only modules with updates")
	ci := fs.Bool("ci", false, "Non-zero exit code when at least one outdated dependency was found")
	style := fs.String("style", "default", "Output style, pass 'markdown' for a Markdown table")
	if parseErr := fs.Parse(args); parseErr != nil {
		return 2
	}

	rows, ok := readRows(in, errw)
	if !ok {
		return 0
	}

	filtered := rows[:0]
	outdated := false
	for _, r := range rows {
		if *onlyDirect && r.direct != "true" {
			continue
		}
		if *onlyUpdate && !r.hasUpdate {
			continue
		}
		if r.newVersion != "" {
			outdated = true
		}
		filtered = append(filtered, r)
	}
	if len(filtered) == 0 {
		if *ci && outdated {
			return 1
		}
		return 0
	}
	printTable(out, filtered, *style == "markdown")
	if *ci && outdated {
		return 1
	}
	return 0
}

func readRows(in io.Reader, errw io.Writer) ([]row, bool) {
	logger := log.New(errw, "", log.LstdFlags)
	dec := json.NewDecoder(in)
	var rows []row
	for {
		var m module
		if err := dec.Decode(&m); err != nil {
			if err == io.EOF {
				return rows, true
			}
			logger.Println(err)
			return nil, false
		}
		r, ok := moduleRow(m, logger)
		if !ok {
			return nil, false
		}
		rows = append(rows, r)
	}
}

func moduleRow(m module, logger *log.Logger) (row, bool) {
	version := m.Version
	update := m.Update
	if m.Replace != nil {
		version = m.Replace.Version
		update = nil
	}
	r := row{
		module:          m.Path,
		version:         version,
		direct:          fmt.Sprint(!m.Indirect),
		validTimestamps: "true",
		hasUpdate:       m.Update != nil,
	}
	if update != nil {
		r.newVersion = update.Version
		r.hasUpdate = true
		if m.Time != "" && update.Time != "" {
			current, err := time.Parse(time.RFC3339, m.Time)
			if err != nil {
				logger.Println(err)
				return row{}, false
			}
			next, err := time.Parse(time.RFC3339, update.Time)
			if err != nil {
				logger.Println(err)
				return row{}, false
			}
			if next.Before(current) {
				r.validTimestamps = "false"
			}
		}
	}
	return r, true
}

func printTable(out io.Writer, rows []row, markdown bool) {
	headers := []string{"MODULE", "VERSION", "NEW VERSION", "DIRECT", "VALID TIMESTAMPS"}
	widths := make([]int, len(headers))
	for i, h := range headers {
		widths[i] = len(h)
	}
	for _, r := range rows {
		vals := rowValues(r)
		for i, v := range vals {
			if len(v) > widths[i] {
				widths[i] = len(v)
			}
		}
	}
	if markdown {
		fmt.Fprintln(out, markdownHeader(headers, widths))
		fmt.Fprintln(out, markdownSep(widths))
		for _, r := range rows {
			fmt.Fprintln(out, tableLine(rowValues(r), widths, false))
		}
		return
	}
	sep := border(widths)
	fmt.Fprintln(out, sep)
	fmt.Fprintln(out, tableLine(headers, widths, true))
	fmt.Fprintln(out, sep)
	for _, r := range rows {
		fmt.Fprintln(out, tableLine(rowValues(r), widths, false))
	}
	fmt.Fprintln(out, sep)
}

func rowValues(r row) []string {
	return []string{r.module, r.version, r.newVersion, r.direct, r.validTimestamps}
}

func border(widths []int) string {
	var b strings.Builder
	b.WriteByte('+')
	for _, w := range widths {
		b.WriteString(strings.Repeat("-", w+2))
		b.WriteByte('+')
	}
	return b.String()
}

func markdownHeader(headers []string, widths []int) string {
	return tableLine(headers, widths, true)
}

func markdownSep(widths []int) string {
	var b strings.Builder
	b.WriteByte('|')
	for _, w := range widths {
		b.WriteString(strings.Repeat("-", w+2))
		b.WriteByte('|')
	}
	return b.String()
}

func tableLine(vals []string, widths []int, center bool) string {
	var b strings.Builder
	b.WriteByte('|')
	for i, v := range vals {
		if center {
			b.WriteByte(' ')
			b.WriteString(centerText(v, widths[i]))
			b.WriteByte(' ')
		} else {
			b.WriteByte(' ')
			b.WriteString(v)
			b.WriteString(strings.Repeat(" ", widths[i]-len(v)))
			b.WriteByte(' ')
		}
		b.WriteByte('|')
	}
	return b.String()
}

func centerText(s string, width int) string {
	total := width - len(s)
	left := total / 2
	right := total - left
	return strings.Repeat(" ", left) + s + strings.Repeat(" ", right)
}
