package main

import (
	"bytes"
	"strings"
	"testing"
)

func TestDefaultTableForModuleStream(t *testing.T) {
	input := strings.NewReader(`{"Path":"mod/root","Version":"v1.0.0","Time":"2020-01-01T00:00:00Z"}
{"Path":"mod/a","Version":"v1.0.0","Time":"2020-01-01T00:00:00Z","Update":{"Path":"mod/a","Version":"v1.1.0","Time":"2021-01-01T00:00:00Z"}}
{"Path":"mod/b","Version":"v2.0.0","Time":"2022-01-01T00:00:00Z","Update":{"Path":"mod/b","Version":"v1.9.0","Time":"2021-01-01T00:00:00Z"},"Indirect":true}`)
	var out bytes.Buffer

	code := run([]string{}, input, &out, &bytes.Buffer{})

	if code != 0 {
		t.Fatalf("exit code = %d, want 0", code)
	}
	want := `+----------+---------+-------------+--------+------------------+
|  MODULE  | VERSION | NEW VERSION | DIRECT | VALID TIMESTAMPS |
+----------+---------+-------------+--------+------------------+
| mod/root | v1.0.0  |             | true   | true             |
| mod/a    | v1.0.0  | v1.1.0      | true   | true             |
| mod/b    | v2.0.0  | v1.9.0      | false  | false            |
+----------+---------+-------------+--------+------------------+
`
	if out.String() != want {
		t.Fatalf("output mismatch\nwant:\n%s\ngot:\n%s", want, out.String())
	}
}

func TestUpdateDirectFilterAndCIExit(t *testing.T) {
	input := strings.NewReader(`{"Path":"root","Version":"v1"}
{"Path":"direct","Version":"v1","Update":{"Version":"v2"}}
{"Path":"indirect","Version":"v1","Update":{"Version":"v2"},"Indirect":true}`)
	var out bytes.Buffer

	code := run([]string{"-update", "-direct", "-ci"}, input, &out, &bytes.Buffer{})

	if code != 1 {
		t.Fatalf("exit code = %d, want 1", code)
	}
	want := `+--------+---------+-------------+--------+------------------+
| MODULE | VERSION | NEW VERSION | DIRECT | VALID TIMESTAMPS |
+--------+---------+-------------+--------+------------------+
| direct | v1      | v2          | true   | true             |
+--------+---------+-------------+--------+------------------+
`
	if out.String() != want {
		t.Fatalf("output mismatch\nwant:\n%s\ngot:\n%s", want, out.String())
	}
}

func TestReplacementVersionSuppressesUpdate(t *testing.T) {
	input := strings.NewReader(`{"Path":"m","Version":"v","Replace":{"Version":"vx"},"Update":{"Version":"vu"},"Indirect":true}`)
	var out bytes.Buffer

	code := run([]string{"-update"}, input, &out, &bytes.Buffer{})

	if code != 0 {
		t.Fatalf("exit code = %d, want 0", code)
	}
	want := `+--------+---------+-------------+--------+------------------+
| MODULE | VERSION | NEW VERSION | DIRECT | VALID TIMESTAMPS |
+--------+---------+-------------+--------+------------------+
| m      | vx      |             | false  | true             |
+--------+---------+-------------+--------+------------------+
`
	if out.String() != want {
		t.Fatalf("output mismatch\nwant:\n%s\ngot:\n%s", want, out.String())
	}
}

func TestFilteredEmptyResultPrintsNothing(t *testing.T) {
	input := strings.NewReader(`{"Path":"m","Version":"v","Indirect":true}`)
	var out bytes.Buffer

	code := run([]string{"-direct"}, input, &out, &bytes.Buffer{})

	if code != 0 {
		t.Fatalf("exit code = %d, want 0", code)
	}
	if out.String() != "" {
		t.Fatalf("stdout = %q, want empty", out.String())
	}
}

func TestReplacementAloneDoesNotTriggerCI(t *testing.T) {
	input := strings.NewReader(`{"Path":"m","Version":"v","Replace":{"Version":"vx"}}`)
	var out bytes.Buffer

	code := run([]string{"-ci"}, input, &out, &bytes.Buffer{})

	if code != 0 {
		t.Fatalf("exit code = %d, want 0", code)
	}
}

func TestReplacementWithoutUpdateIsExcludedByUpdateFilter(t *testing.T) {
	input := strings.NewReader(`{"Path":"m","Version":"v","Replace":{"Version":"vx"}}`)
	var out bytes.Buffer

	code := run([]string{"-update"}, input, &out, &bytes.Buffer{})

	if code != 0 {
		t.Fatalf("exit code = %d, want 0", code)
	}
	if out.String() != "" {
		t.Fatalf("stdout = %q, want empty", out.String())
	}
}

func TestMarkdownStyle(t *testing.T) {
	input := strings.NewReader(`{"Path":"mod/root","Version":"v1.0.0"}
{"Path":"mod/a","Version":"v1.0.0","Update":{"Version":"v1.1.0"}}`)
	var out bytes.Buffer

	code := run([]string{"-style", "markdown"}, input, &out, &bytes.Buffer{})

	if code != 0 {
		t.Fatalf("exit code = %d, want 0", code)
	}
	want := `|  MODULE  | VERSION | NEW VERSION | DIRECT | VALID TIMESTAMPS |
|----------|---------|-------------|--------|------------------|
| mod/root | v1.0.0  |             | true   | true             |
| mod/a    | v1.0.0  | v1.1.0      | true   | true             |
`
	if out.String() != want {
		t.Fatalf("output mismatch\nwant:\n%s\ngot:\n%s", want, out.String())
	}
}

func TestMalformedJSONLogsAndExitsZeroWithoutTable(t *testing.T) {
	var out bytes.Buffer
	var errOut bytes.Buffer

	code := run([]string{}, strings.NewReader("bad"), &out, &errOut)

	if code != 0 {
		t.Fatalf("exit code = %d, want 0", code)
	}
	if out.String() != "" {
		t.Fatalf("stdout = %q, want empty", out.String())
	}
	if !strings.Contains(errOut.String(), "invalid character 'b' looking for beginning of value") {
		t.Fatalf("stderr = %q, want JSON parse message", errOut.String())
	}
}
