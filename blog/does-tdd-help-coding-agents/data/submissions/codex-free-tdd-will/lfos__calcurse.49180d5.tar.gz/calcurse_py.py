#!/usr/bin/env python3
from __future__ import annotations

import datetime as dt
import os
import re
import sys
from dataclasses import dataclass
from pathlib import Path


HELP = """Usage:
calcurse [-D <directory>] [-C <directory>] [-c <calendar file>]
calcurse -Q [--from <date>] [--to <date>] [--days <number>]
calcurse -a | -d <date> | -d <number> | -n | -r[<number>] | -s[<date>] | -t[<number>]
calcurse -h | -v | --status | -G | -P | -g | -i <file> | -x[<format>] | --daemon

Operations in command line mode:
  -Q, --query   Print items in a given query range
  -G, --grep    Grep items from the data files
  -P, --purge   Read items and write them back
Query short forms:
-a, -d <date>|<number>, -n, -r[<number>], -s[<date>], -t<number>

Note that filter, format and day-range options affect input or output:
  --filter-*              Filter items loaded by -Q, -G, -P and -x
  --format-*              Rewrite output from -Q, -G and --dump-imported
  --from <date>           Limit day range of -Q.
  --to <date>             Limit day range of -Q.
  --days <number>         Limit day range of -Q.

  --limit, -l <number>    Limit number of query results
  --search, -S <regexp>   Match regular expression in queries
Consult the man page for details.

Miscellaneous:
  -c, --calendar <file>   The calendar data file to use
  -C, --confdir <dir>     The configuration directory to use
  --daemon                Run notification daemon in the background
  -D, --datadir <dir>     The data directory to use
  -g, --gc                Run the garbage collector
  -h, --help              Show this help text
  -i, --import <file>     Import iCal data from file
  -q, --quiet             Suppress import/export result message
  --read-only             Do not save configuration or data files
  --status                Display status of running instances
  -v, --version           Show version information
  -x, --export[<format>]  Export to stdout in ical (default) or pcal format

For more information, type '?' from within calcurse, or read the manpage.
Submit feature requests and suggestions to <misc@calcurse.org>.
Submit bug reports to <bugs@calcurse.org>.
"""

VERSION = """calcurse 4.8.2 -- text-based organizer

Copyright (c) 2004-2023 calcurse Development Team.
This is free software; see the source for copying conditions.
"""


@dataclass
class Apt:
    start: dt.datetime
    end: dt.datetime
    message: str
    raw: str
    note: str = ""
    recur: bool = False


@dataclass
class Event:
    date: dt.date
    days: int
    message: str
    raw: str
    note: str = ""
    recur: bool = False


@dataclass
class Todo:
    priority: int
    done: bool
    message: str
    raw: str
    note: str = ""


def default_datadir() -> Path:
    home = Path(os.environ.get("HOME", "."))
    old = home / ".calcurse"
    if old.exists():
        return old
    return Path(os.environ.get("XDG_DATA_HOME", home / ".local" / "share")) / "calcurse"


def parse_date(s: str, input_fmt: int = 1) -> dt.date:
    low = s.lower()
    today = dt.date.today()
    if low in {"today", "now"}:
        return today
    if low == "tomorrow":
        return today + dt.timedelta(days=1)
    if low == "yesterday":
        return today - dt.timedelta(days=1)
    weekdays = ["mon", "tue", "wed", "thu", "fri", "sat", "sun"]
    if low[:3] in weekdays:
        target = weekdays.index(low[:3])
        delta = (target - today.weekday()) % 7
        return today + dt.timedelta(days=delta)
    parts = re.split(r"[-/]", s)
    if len(parts) != 3:
        raise ValueError(s)
    nums = [int(p) for p in parts]
    if input_fmt == 2:
        day, month, year = nums
    elif input_fmt == 3:
        year, month, day = nums
    elif input_fmt == 4:
        year, month, day = nums
    else:
        month, day, year = nums
    return dt.date(year, month, day)


def parse_stored_date(s: str) -> dt.date:
    return dt.datetime.strptime(s, "%m/%d/%Y").date()


def parse_stored_datetime(date_s: str, time_s: str) -> dt.datetime:
    return dt.datetime.strptime(f"{date_s} {time_s}", "%m/%d/%Y %H:%M")


def strip_note_and_message(text: str) -> tuple[str, str]:
    note = ""
    if text.startswith(">") and len(text) >= 41 and re.match(r">[0-9a-f]{40}", text):
        note = text[1:41]
        text = text[41:].lstrip()
    return note, text


def load_items(datadir: Path, calendar_file: Path | None = None):
    apts: list[Apt] = []
    events: list[Event] = []
    todos: list[Todo] = []
    apt_path = calendar_file or datadir / "apts"
    todo_path = datadir / "todo"
    if apt_path.exists():
        for line in apt_path.read_text(errors="replace").splitlines():
            raw = line
            if not line.strip():
                continue
            m = re.match(
                r"^(\d\d/\d\d/\d{4}) @ (\d\d:\d\d) -> (\d\d/\d\d/\d{4}) @ (\d\d:\d\d)(.*)$",
                line,
            )
            if m:
                rest = m.group(5)
                if "|" in rest:
                    before, msg = rest.split("|", 1)
                    recur = parse_recur(before)
                    note, _ = strip_note_and_message(before.strip())
                    base = Apt(
                        parse_stored_datetime(m.group(1), m.group(2)),
                        parse_stored_datetime(m.group(3), m.group(4)),
                        msg,
                        raw,
                        note,
                        bool(recur),
                    )
                    apts.extend(expand_apt(base, recur))
                continue
            m = re.match(r"^(\d\d/\d\d/\d{4}) \[(\d+)\](.*)$", line)
            if m:
                rest = m.group(3).strip()
                recur = parse_recur(rest)
                rest = remove_recur(rest)
                note, msg = strip_note_and_message(rest.strip())
                base = Event(parse_stored_date(m.group(1)), int(m.group(2)), msg, raw, note, bool(recur))
                events.extend(expand_event(base, recur))
    if todo_path.exists():
        for line in todo_path.read_text(errors="replace").splitlines():
            raw = line
            m = re.match(r"^\[(-?)(\d+)\](.*)$", line)
            if not m:
                continue
            note, msg = strip_note_and_message(m.group(3).strip())
            todos.append(Todo(int(m.group(2)), bool(m.group(1)), msg, raw, note))
    return apts, events, todos


def parse_recur(text: str):
    m = re.search(r"\{(\d+)([DWMY]) -> (\d\d/\d\d/\d{4})([^}]*)\}", text)
    if not m:
        return None
    exceptions = {parse_stored_date(x) for x in re.findall(r"!(\d\d/\d\d/\d{4})", m.group(4))}
    return int(m.group(1)), m.group(2), parse_stored_date(m.group(3)), exceptions


def remove_recur(text: str) -> str:
    return re.sub(r"\{[^}]*\}", "", text).strip()


def add_months(day: dt.date, months: int) -> dt.date | None:
    month0 = day.month - 1 + months
    year = day.year + month0 // 12
    month = month0 % 12 + 1
    month_lengths = [31, 29 if year % 4 == 0 and (year % 100 != 0 or year % 400 == 0) else 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31]
    if day.day > month_lengths[month - 1]:
        return None
    return dt.date(year, month, day.day)


def next_recur_date(day: dt.date, count: int, unit: str) -> dt.date | None:
    if unit == "D":
        return day + dt.timedelta(days=count)
    if unit == "W":
        return day + dt.timedelta(days=7 * count)
    if unit == "M":
        return add_months(day, count)
    if unit == "Y":
        return add_months(day, 12 * count)
    return None


def expand_apt(base: Apt, recur):
    if not recur:
        return [base]
    count, unit, until, exceptions = recur
    result = []
    current = base.start.date()
    duration = base.end - base.start
    cursor = current
    guard = 0
    while cursor and cursor <= until and guard < 10000:
        if cursor not in exceptions:
            start = dt.datetime.combine(cursor, base.start.time())
            result.append(Apt(start, start + duration, base.message, base.raw, base.note, True))
        cursor = next_recur_date(cursor, count, unit)
        guard += 1
    return result


def expand_event(base: Event, recur):
    if not recur:
        return [base]
    count, unit, until, exceptions = recur
    result = []
    cursor = base.date
    guard = 0
    while cursor and cursor <= until and guard < 10000:
        if cursor not in exceptions:
            result.append(Event(cursor, base.days, base.message, base.raw, base.note, True))
        cursor = next_recur_date(cursor, count, unit)
        guard += 1
    return result


def date_line(day: dt.date, fmt: str = "%m/%d/%y") -> str:
    return day.strftime(fmt)


def print_query(
    apts,
    events,
    todos,
    start: dt.date,
    end: dt.date,
    include_cal=True,
    include_todo=True,
    output_fmt: str = "%m/%d/%y",
):
    out: list[str] = []
    if include_todo:
        visible = todos
        if visible:
            out.append("to do:")
            for todo in visible:
                out.append(f"{todo.priority}. {todo.message}")
            out.append("")
    if include_cal:
        step = dt.timedelta(days=1)
        day = start
        while day <= end:
            day_events = [e for e in events if e.date <= day < e.date + dt.timedelta(days=e.days)]
            day_apts = [a for a in apts if a.start.date() <= day <= (a.end - dt.timedelta(seconds=1)).date()]
            if day_events or day_apts:
                out.append(f"{date_line(day, output_fmt)}:")
                for e in sorted(day_events, key=lambda x: x.message):
                    out.append(f" * {e.message}")
                for a in sorted(day_apts, key=lambda x: x.start):
                    s = a.start.strftime("%H:%M") if a.start.date() == day else "..:.."
                    e = a.end.strftime("%H:%M") if a.end.date() == day else "..:.."
                    out.append(f" - {s} -> {e}")
                    out.append(f"\t{a.message}")
                out.append("")
            day += step
    sys.stdout.write("\n".join(out))
    if out:
        sys.stdout.write("\n")


def parse_args(argv):
    opts = {
        "datadir": default_datadir(),
        "calendar": None,
        "input_fmt": 1,
        "op": None,
        "from": None,
        "to": None,
        "days": None,
        "todo_prio": None,
        "filter_type": None,
        "search": None,
        "format_apt": None,
        "format_event": None,
        "format_todo": None,
        "output_fmt": "%m/%d/%y",
        "quiet": False,
    }
    i = 0
    while i < len(argv):
        a = argv[i]
        if a in ("-h", "--help"):
            opts["op"] = "help"
        elif a in ("-v", "--version"):
            opts["op"] = "version"
        elif a == "--status":
            opts["op"] = "status"
        elif a in ("-Q", "--query"):
            opts["op"] = "query"
        elif a in ("-G", "--grep"):
            opts["op"] = "grep"
        elif a == "-x" or a == "--export" or a.startswith("-x") or a.startswith("--export="):
            opts["op"] = "export"
        elif a in ("-P", "--purge", "-F", "--filter"):
            opts["op"] = "purge"
        elif a in ("-g", "--gc", "--daemon"):
            opts["op"] = "noop"
        elif a in ("-i", "--import"):
            i += 1
            opts["op"] = "import"
            opts["import_file"] = Path(argv[i])
        elif a in ("-q", "--quiet"):
            opts["quiet"] = True
        elif a == "--read-only":
            pass
        elif a in ("-a", "--appointment"):
            opts["op"] = "appointment"
        elif a in ("-t", "--todo"):
            opts["op"] = "todo"
        elif a in ("-r", "--range"):
            opts["op"] = "range"
            if i + 1 < len(argv) and not argv[i + 1].startswith("-"):
                i += 1
                opts["range_days"] = int(argv[i])
            else:
                opts["range_days"] = 1
        elif a.startswith("-r") and len(a) > 2:
            opts["op"] = "range"
            opts["range_days"] = int(a[2:])
        elif a in ("-s", "--startday"):
            opts["op"] = "startday"
            if i + 1 < len(argv) and not argv[i + 1].startswith("-"):
                i += 1
                opts["from"] = argv[i]
        elif a.startswith("-s") and len(a) > 2:
            opts["op"] = "startday"
            opts["from"] = a[2:]
        elif a.startswith("-t") and len(a) > 2:
            opts["op"] = "todo"
            opts["todo_prio"] = int(a[2:])
        elif a in ("-D", "--datadir"):
            i += 1
            opts["datadir"] = Path(argv[i])
        elif a in ("-c", "--calendar"):
            i += 1
            opts["calendar"] = Path(argv[i])
        elif a == "--input-datefmt":
            i += 1
            opts["input_fmt"] = int(argv[i])
        elif a == "--output-datefmt":
            i += 1
            opts["output_fmt"] = argv[i]
        elif a == "--from":
            i += 1
            opts["from"] = argv[i]
        elif a == "--to":
            i += 1
            opts["to"] = argv[i]
        elif a == "--days":
            i += 1
            opts["days"] = int(argv[i])
        elif a == "--filter-type":
            i += 1
            opts["filter_type"] = argv[i]
        elif a in ("-S", "--search", "--filter-pattern"):
            i += 1
            opts["search"] = argv[i]
        elif a == "--format-apt":
            i += 1
            opts["format_apt"] = argv[i]
        elif a == "--format-event":
            i += 1
            opts["format_event"] = argv[i]
        elif a == "--format-todo":
            i += 1
            opts["format_todo"] = argv[i]
        elif a in ("-d", "--day"):
            i += 1
            opts["op"] = "day"
            opts["day_arg"] = argv[i]
        else:
            pass
        i += 1
    return opts


def main():
    opts = parse_args(sys.argv[1:])
    op = opts["op"]
    if op == "help" or op is None:
        sys.stdout.write(HELP)
        return 0
    if op == "version":
        sys.stdout.write(VERSION)
        return 0
    if op == "status":
        print("calcurse is not running")
        return 0
    if op == "import":
        import_ical(opts["import_file"], opts["datadir"], quiet=opts["quiet"])
        return 0
    if op == "noop":
        return 0
    apts, events, todos = load_items(opts["datadir"], opts["calendar"])
    apts, events, todos = apply_filters(apts, events, todos, opts)
    if op == "grep":
        seen: set[str] = set()
        for t in todos:
            if t.raw not in seen:
                sys.stdout.write(format_item(t, opts.get("format_todo") or "%(raw)"))
                seen.add(t.raw)
        for a in sorted(apts, key=lambda x: x.start):
            if a.raw not in seen:
                sys.stdout.write(format_item(a, opts.get("format_apt") or "%(raw)"))
                seen.add(a.raw)
        for e in sorted(events, key=lambda x: x.date):
            if e.raw not in seen:
                sys.stdout.write(format_item(e, opts.get("format_event") or "%(raw)"))
                seen.add(e.raw)
        return 0
    if op == "export":
        export_ical(apts, events, todos)
        return 0
    if op == "purge":
        purge(opts["datadir"], opts["calendar"], apts, events, todos)
        return 0
    if op == "todo":
        prio = opts["todo_prio"]
        if prio == 0:
            shown = [t for t in todos if t.done]
            if shown:
                print("completed tasks:")
                for t in shown:
                    print(f"{t.priority}. {t.message}")
            return 0
        shown = [t for t in todos if not t.done and (prio is None or t.priority == prio)]
        if shown:
            print("to do:")
            for t in shown:
                print(f"{t.priority}. {t.message}")
        return 0
    if op == "appointment":
        start = end = dt.date.today()
        print_query(apts, events, [], start, end, include_cal=True, include_todo=False, output_fmt=opts["output_fmt"])
        return 0
    if op == "day":
        arg = opts.get("day_arg", "1")
        if re.fullmatch(r"-?\d+", arg):
            n = int(arg)
            today = dt.date.today()
            if n >= 0:
                start, end = today, today + dt.timedelta(days=max(n - 1, 0))
            else:
                start, end = today + dt.timedelta(days=n + 1), today
        else:
            start = end = parse_date(arg, opts["input_fmt"])
        print_query(apts, events, [], start, end, include_cal=True, include_todo=False, output_fmt=opts["output_fmt"])
        return 0
    if op in ("range", "startday"):
        if op == "range":
            n = opts.get("range_days", 1)
            today = dt.date.today()
            if n >= 0:
                start, end = today, today + dt.timedelta(days=max(n - 1, 0))
            else:
                start, end = today + dt.timedelta(days=n + 1), today
        else:
            start = parse_date(opts["from"], opts["input_fmt"]) if opts["from"] else dt.date.today()
            end = start
        print_query(apts, events, [], start, end, include_cal=True, include_todo=False, output_fmt=opts["output_fmt"])
        return 0
    if op == "query":
        start = parse_date(opts["from"], opts["input_fmt"]) if opts["from"] else dt.date.today()
        if opts["to"]:
            end = parse_date(opts["to"], opts["input_fmt"])
        elif opts["days"]:
            n = opts["days"]
            if n >= 0:
                end = start + dt.timedelta(days=max(n - 1, 0))
            else:
                end = start
                start = start + dt.timedelta(days=n + 1)
        else:
            end = start
        print_query(apts, events, todos, start, end, output_fmt=opts["output_fmt"])
        return 0
    return 0


def ical_escape(s: str) -> str:
    return s.replace("\\", "\\\\").replace("\n", "\\n").replace(",", "\\,").replace(";", "\\;")


def export_ical(apts: list[Apt], events: list[Event], todos: list[Todo]) -> None:
    print("BEGIN:VCALENDAR")
    print("VERSION:2.0")
    print("PRODID:-//calcurse//NONSGML v4.8.2//EN")
    for event in sorted(events, key=lambda e: (e.date, e.message)):
        print("BEGIN:VEVENT")
        print(f"DTSTART;VALUE=DATE:{event.date:%Y%m%d}")
        if event.days != 1:
            print(f"DTEND;VALUE=DATE:{event.date + dt.timedelta(days=event.days):%Y%m%d}")
        print(f"SUMMARY:{ical_escape(event.message)}")
        print("END:VEVENT")
    for apt in sorted(apts, key=lambda a: a.start):
        dur = int((apt.end - apt.start).total_seconds())
        days, rem = divmod(max(dur, 0), 86400)
        hours, rem = divmod(rem, 3600)
        minutes, seconds = divmod(rem, 60)
        print("BEGIN:VEVENT")
        print(f"DTSTART:{apt.start:%Y%m%dT%H%M%S}")
        print(f"DURATION:P{days}DT{hours}H{minutes}M{seconds}S")
        print(f"SUMMARY:{ical_escape(apt.message)}")
        print("END:VEVENT")
    for todo in todos:
        print("BEGIN:VTODO")
        print(f"PRIORITY:{todo.priority}")
        print(f"SUMMARY:{ical_escape(todo.message)}")
        if todo.done:
            print("STATUS:COMPLETED")
        print("END:VTODO")
    print("END:VCALENDAR")


def purge(datadir: Path, calendar_file: Path | None, apts: list[Apt], events: list[Event], todos: list[Todo]) -> None:
    apt_remove = {x.raw for x in apts} | {x.raw for x in events}
    todo_remove = {x.raw for x in todos}
    apt_path = calendar_file or datadir / "apts"
    todo_path = datadir / "todo"
    if apt_path.exists():
        lines = apt_path.read_text(errors="replace").splitlines()
        apt_path.write_text("".join(line + "\n" for line in lines if line not in apt_remove))
    if todo_path.exists():
        lines = todo_path.read_text(errors="replace").splitlines()
        todo_path.write_text("".join(line + "\n" for line in lines if line not in todo_remove))


def type_set(value: str | None) -> set[str] | None:
    if not value:
        return None
    result: set[str] = set()
    for part in value.split(","):
        part = part.strip()
        if part == "cal":
            result.update({"apt", "event", "recur-apt", "recur-event"})
        elif part == "recur":
            result.update({"recur-apt", "recur-event"})
        else:
            result.add(part)
    return result


def apply_filters(apts, events, todos, opts):
    wanted = type_set(opts.get("filter_type"))
    if wanted is not None:
        apts = [a for a in apts if ("recur-apt" if a.recur else "apt") in wanted]
        events = [e for e in events if ("recur-event" if e.recur else "event") in wanted]
        todos = todos if "todo" in wanted else []
    pattern = opts.get("search")
    if pattern:
        rx = re.compile(pattern)
        apts = [a for a in apts if rx.search(a.message)]
        events = [e for e in events if rx.search(e.message)]
        todos = [t for t in todos if rx.search(t.message)]
    return apts, events, todos


def decode_format(fmt: str) -> str:
    return fmt.encode("utf-8").decode("unicode_escape")


def format_item(item, fmt: str) -> str:
    fmt = decode_format(fmt)
    if fmt == "%(raw)":
        return item.raw + "\n"
    out = ""
    i = 0
    while i < len(fmt):
        if fmt[i] != "%":
            out += fmt[i]
            i += 1
            continue
        if fmt.startswith("%(raw)", i):
            out += item.raw
            i += 6
            continue
        if fmt.startswith("%(hash)", i):
            import hashlib

            out += hashlib.sha1(item.raw.encode()).hexdigest()
            i += 7
            continue
        i += 1
        if i >= len(fmt):
            out += "%"
            break
        c = fmt[i]
        if c == "m":
            out += item.message
        elif c == "p" and isinstance(item, Todo):
            out += str(item.priority)
        elif c == "S" and isinstance(item, Apt):
            out += item.start.strftime("%H:%M")
        elif c == "E" and isinstance(item, Apt):
            out += item.end.strftime("%H:%M")
        elif c == "s" and isinstance(item, Apt):
            out += str(int(item.start.timestamp()))
        elif c == "e" and isinstance(item, Apt):
            out += str(int(item.end.timestamp()))
        elif c == "d" and isinstance(item, Apt):
            out += str(int((item.end - item.start).total_seconds()))
        elif c == "n":
            out += getattr(item, "note", "")
        else:
            out += "%" + c
        i += 1
    return out


def unfold_ical(text: str) -> list[str]:
    lines: list[str] = []
    for raw in text.replace("\r\n", "\n").replace("\r", "\n").split("\n"):
        if raw.startswith((" ", "\t")) and lines:
            lines[-1] += raw[1:]
        elif raw:
            lines.append(raw)
    return lines


def prop_name(line: str) -> tuple[str, str]:
    key, _, val = line.partition(":")
    return key.split(";", 1)[0].upper(), val


def unescape_ical(s: str) -> str:
    s = s.replace("\\n", "\n").replace("\\N", "\n")
    out = []
    esc = False
    for ch in s:
        if esc:
            out.append(ch)
            esc = False
        elif ch == "\\":
            esc = True
        else:
            out.append(ch)
    if esc:
        out.append("\\")
    return "".join(out)


def parse_ical_datetime(value: str) -> dt.datetime:
    value = value.rstrip("Z")
    if "T" not in value:
        return dt.datetime.strptime(value, "%Y%m%d")
    if len(value.split("T", 1)[1]) == 4:
        return dt.datetime.strptime(value, "%Y%m%dT%H%M")
    return dt.datetime.strptime(value[:15], "%Y%m%dT%H%M%S")


def parse_duration(value: str) -> dt.timedelta:
    neg = value.startswith("-")
    value = value.lstrip("+-")
    m = re.match(r"P(?:(\d+)D)?(?:T(?:(\d+)H)?(?:(\d+)M)?(?:(\d+)S)?)?$", value)
    if not m:
        return dt.timedelta(0)
    days, hours, minutes, seconds = (int(x or 0) for x in m.groups())
    delta = dt.timedelta(days=days, hours=hours, minutes=minutes, seconds=seconds)
    return -delta if neg else delta


def first_weekday_in_month(year: int, month: int, weekday: int, ordinal: int) -> dt.date:
    day = dt.date(year, month, 1)
    day += dt.timedelta(days=(weekday - day.weekday()) % 7)
    return day + dt.timedelta(days=7 * (ordinal - 1))


def rrule_until(start: dt.datetime, rule: str) -> tuple[int, str, dt.date, str]:
    parts = {}
    for piece in rule.split(";"):
        k, _, v = piece.partition("=")
        parts[k.upper()] = v
    freq_map = {"DAILY": "D", "WEEKLY": "W", "MONTHLY": "M", "YEARLY": "Y"}
    unit = freq_map.get(parts.get("FREQ", "DAILY"), "D")
    interval = int(parts.get("INTERVAL", "1") or 1)
    extra = ""
    if "UNTIL" in parts:
        until_dt = parse_ical_datetime(parts["UNTIL"])
        until = until_dt.date()
    elif "COUNT" in parts:
        count = max(int(parts["COUNT"] or 1), 1)
        until = start.date()
        if unit == "Y" and "BYDAY" in parts and "BYMONTH" in parts:
            m = re.match(r"(\d+)(MO|TU|WE|TH|FR|SA|SU)", parts["BYDAY"])
            if m:
                ord_num = int(m.group(1))
                weekday = ["MO", "TU", "WE", "TH", "FR", "SA", "SU"].index(m.group(2))
                month = int(parts["BYMONTH"])
                until = first_weekday_in_month(start.year + count - 1, month, weekday, ord_num)
                extra = f" w{ord_num}{weekday + 1} m{month}"
        else:
            cursor = until
            for _ in range(count - 1):
                nxt = next_recur_date(cursor, interval, unit)
                if nxt is None:
                    break
                cursor = nxt
            until = cursor
    else:
        until = start.date()
    return interval, unit, until, extra


def exdates(props: dict[str, list[str]]) -> list[str]:
    dates = []
    for value in props.get("EXDATE", []):
        for part in value.split(","):
            try:
                dates.append(parse_ical_datetime(part).strftime(" !%m/%d/%Y"))
            except ValueError:
                pass
    return dates


def first_summary(props: dict[str, list[str]]) -> str:
    value = (props.get("SUMMARY") or [""])[0]
    lines = unescape_ical(value).splitlines()
    return lines[0] if lines else ""


def import_ical(path: Path, datadir: Path, quiet: bool = False) -> None:
    datadir.mkdir(parents=True, exist_ok=True)
    (datadir / "notes").mkdir(exist_ok=True)
    (datadir / "hooks").mkdir(exist_ok=True)
    source = path.read_text(errors="replace")
    line_count = len(source.replace("\r\n", "\n").replace("\r", "\n").splitlines())
    lines = unfold_ical(source)
    stack: list[tuple[str, dict[str, list[str]]]] = []
    apt_lines: list[str] = []
    todo_lines: list[str] = []

    def add_prop(props: dict[str, list[str]], name: str, value: str):
        props.setdefault(name, []).append(value)

    for line in lines:
        name, value = prop_name(line)
        if name == "BEGIN":
            stack.append((value.upper(), {}))
            continue
        if name == "END" and stack:
            kind, props = stack.pop()
            if kind == "VEVENT":
                summary = first_summary(props)
                dtstart = (props.get("DTSTART") or [""])[0]
                if not dtstart:
                    continue
                is_date = "T" not in dtstart
                start = parse_ical_datetime(dtstart)
                if is_date:
                    if props.get("DTEND"):
                        days = max((parse_ical_datetime(props["DTEND"][0]).date() - start.date()).days, 1)
                    elif props.get("DURATION"):
                        days = max(parse_duration(props["DURATION"][0]).days, 1)
                    else:
                        days = 1
                    recur = ""
                    write_days = days
                    if props.get("RRULE"):
                        interval, unit, until, extra = rrule_until(start, props["RRULE"][0])
                        recur = f" {{{interval}{unit} -> {until:%m/%d/%Y}{extra}{''.join(exdates(props))}}}"
                        write_days = 1
                    elif days > 1:
                        recur = f" {{1D -> {start.date() + dt.timedelta(days=days - 1):%m/%d/%Y}}}"
                        write_days = 1
                    apt_lines.append(f"{start:%m/%d/%Y} [{write_days}]{recur} {summary}")
                else:
                    if props.get("DTEND"):
                        end = parse_ical_datetime(props["DTEND"][0])
                    elif props.get("DURATION"):
                        end = start + parse_duration(props["DURATION"][0])
                    else:
                        end = start
                    recur = ""
                    if props.get("RRULE"):
                        interval, unit, until, extra = rrule_until(start, props["RRULE"][0])
                        recur = f" {{{interval}{unit} -> {until:%m/%d/%Y}{extra}{''.join(exdates(props))}}}"
                    apt_lines.append(f"{start:%m/%d/%Y @ %H:%M} -> {end:%m/%d/%Y @ %H:%M}{recur}|{summary}")
            elif kind == "VTODO":
                summary = first_summary(props)
                prio = int((props.get("PRIORITY") or ["0"])[0] or 0)
                done = any(v.upper() == "COMPLETED" for v in props.get("STATUS", []))
                sign = "-" if done else ""
                todo_lines.append(f"[{sign}{prio}] {summary}")
            continue
        if stack:
            kind, props = stack[-1]
            add_prop(props, name, value)

    with (datadir / "apts").open("a") as f:
        for line in apt_lines:
            f.write(line + "\n")
    with (datadir / "todo").open("a") as f:
        for line in todo_lines:
            f.write(line + "\n")
    if not quiet:
        app_count = sum(1 for line in apt_lines if " @ " in line)
        event_count = len(apt_lines) - app_count
        print(f"Import process report: {line_count:04d} lines read")
        print(f"{app_count} app / {event_count} events / {len(todo_lines)} todo / 0 skipped")


if __name__ == "__main__":
    raise SystemExit(main())
