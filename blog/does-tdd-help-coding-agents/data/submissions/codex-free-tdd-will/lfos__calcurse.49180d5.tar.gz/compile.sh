#!/bin/bash
set -e
cp calcurse_py.py executable
chmod +x executable
