#!/usr/bin/env python3
import sys
import re
import json
import math
import os
import types


VERSION = "2025-09-13"


HELP = f"""QuickJS version {VERSION}
usage: qjs [options] [file [args]]
-h  --help         list options
-e  --eval EXPR    evaluate EXPR
-i  --interactive  go to interactive mode
-m  --module       load as ES6 module (default=autodetect)
    --script       load as ES6 script (default=autodetect)
    --strict       force strict mode
-I  --include file include an additional file
    --std          make 'std' and 'os' available to the loaded script
-T  --trace        trace memory allocation
-d  --dump         dump the memory usage stats
    --memory-limit n  limit the memory usage to 'n' bytes (SI suffixes allowed)
    --stack-size n    limit the stack size to 'n' bytes (SI suffixes allowed)
    --no-unhandled-rejection  ignore unhandled promise rejections
-s                    strip all the debug info
    --strip-source    strip the source code
-q  --quit         just instantiate the interpreter and quit
"""


class JSUndefined:
    pass


UNDEFINED = JSUndefined()


def split_top_level(text, sep=","):
    parts, buf = [], []
    depth = 0
    quote = None
    escape = False
    for ch in text:
        if quote:
            buf.append(ch)
            if escape:
                escape = False
            elif ch == "\\":
                escape = True
            elif ch == quote:
                quote = None
            continue
        if ch in ("'", '"', "`"):
            quote = ch
            buf.append(ch)
        elif ch in "([{":
            depth += 1
            buf.append(ch)
        elif ch in ")]}":
            depth -= 1
            buf.append(ch)
        elif ch == sep and depth == 0:
            parts.append("".join(buf).strip())
            buf = []
        else:
            buf.append(ch)
    if buf or text.strip():
        parts.append("".join(buf).strip())
    return parts


def split_statements(source):
    out = []
    source = re.sub(
        r"for\s*\(([^;]+);([^;]+);([^)]+)\)\s*([^;]+(?:\([^)]*\))?)",
        lambda m: "for (" + m.group(1) + "\x1f" + m.group(2) + "\x1f" + m.group(3) + ") " + m.group(4),
        source,
    )
    for line in source.splitlines():
        line = re.sub(r"//.*", "", line).strip()
        if not line:
            continue
        out.extend(p for p in split_top_level(line, ";") if p)
    return out


def js_string(value):
    if value is UNDEFINED:
        return "undefined"
    if value is None:
        return "null"
    if value is True:
        return "true"
    if value is False:
        return "false"
    if isinstance(value, list):
        return ",".join(js_string(v) if v is not None else "" for v in value)
    if isinstance(value, dict):
        return "[object Object]"
    return str(value)


def object_literal_to_json(match):
    body = match.group(1)
    body = re.sub(r"([A-Za-z_$][\w$]*)\s*:", r'"\1":', body)
    return "{" + body + "}"


def translate_expr(expr):
    expr = expr.strip()
    expr = re.sub(r"\btrue\b", "True", expr)
    expr = re.sub(r"\bfalse\b", "False", expr)
    expr = re.sub(r"\bnull\b", "None", expr)
    expr = re.sub(r"\bundefined\b", "UNDEFINED", expr)
    expr = expr.replace("===", "==").replace("!==", "!=")
    expr = expr.replace("&&", " and ").replace("||", " or ")
    expr = re.sub(r"(?<![=!<>])!(?!=)", " not ", expr)
    expr = re.sub(r"(\b[A-Za-z_$][\w$]*|\]|\))\.length\b", r"js_len(\1)", expr)
    expr = re.sub(r"\{([^{}]*)\}", object_literal_to_json, expr)
    expr = expr.replace("Math.", "math.")
    return expr


def js_len(value):
    return len(value)


def js_trim(value):
    return str(value).strip()


def json_stringify(value):
    return json.dumps(value, separators=(",", ":"))


def eval_expr(expr, env):
    expr = expr.strip()
    if expr.endswith(".trim()"):
        return js_trim(eval_expr(expr[:-7], env))
    if expr.startswith("typeof "):
        name = expr[7:].strip()
        if not re.match(r"^[A-Za-z_$][\w$]*$", name):
            try:
                value = eval_expr(name, env)
            except RuntimeError:
                return "undefined"
            if isinstance(value, str):
                return "string"
            if isinstance(value, bool):
                return "boolean"
            if isinstance(value, (int, float)):
                return "number"
            if callable(value):
                return "function"
            return "object"
        if name in env:
            value = env[name]
            if isinstance(value, (dict, types.SimpleNamespace)):
                return "object"
            if callable(value):
                return "function"
            if isinstance(value, str):
                return "string"
            if isinstance(value, (int, float)):
                return "number"
            if isinstance(value, bool):
                return "boolean"
        if name in ("console", "JSON", "Math"):
            return "object"
        return "undefined"
    if expr.startswith("JSON.stringify(") and expr.endswith(")"):
        return json_stringify(eval_expr(expr[len("JSON.stringify("):-1], env))
    scope = {
        "UNDEFINED": UNDEFINED,
        "js_len": js_len,
        "js_trim": js_trim,
        "math": math,
        **env,
    }
    try:
        return eval(translate_expr(expr), {"__builtins__": {}}, scope)
    except NameError as exc:
        name = str(exc).split("'")[1]
        raise RuntimeError(f"ReferenceError: '{name}' is not defined")
    except Exception as exc:
        raise RuntimeError(f"Error: {exc}")


def execute(source, env):
    for stmt in split_statements(source):
        if stmt.startswith("import "):
            continue
        if stmt.startswith("for "):
            m = re.match(r"for\s*\((.*?)\x1f(.*?)\x1f(.*?)\)\s*(.*)", stmt)
            if not m:
                raise RuntimeError("SyntaxError: invalid for statement")
            init, cond, step, body = [x.strip() for x in m.groups()]
            execute(init, env)
            guard = 0
            while eval_expr(cond, env):
                execute(body, env)
                if step.endswith("++"):
                    env[step[:-2].strip()] = env.get(step[:-2].strip(), 0) + 1
                elif step.endswith("--"):
                    env[step[:-2].strip()] = env.get(step[:-2].strip(), 0) - 1
                else:
                    execute(step, env)
                guard += 1
                if guard > 100000:
                    raise RuntimeError("Error: loop limit exceeded")
            continue
        if stmt.startswith(("console.log(", "print(")) and stmt.endswith(")"):
            inner = stmt[stmt.find("(") + 1:-1]
            values = [eval_expr(part, env) for part in split_top_level(inner)]
            print(" ".join(js_string(v) for v in values))
        elif stmt.startswith("std.puts(") and stmt.endswith(")"):
            inner = stmt[stmt.find("(") + 1:-1]
            env["std"].puts(eval_expr(inner, env))
        elif stmt.startswith("std.printf(") and stmt.endswith(")"):
            inner = stmt[stmt.find("(") + 1:-1]
            args = [eval_expr(part, env) for part in split_top_level(inner)]
            env["std"].printf(*args)
        elif stmt.startswith("console.error(") and stmt.endswith(")"):
            inner = stmt[stmt.find("(") + 1:-1]
            values = [eval_expr(part, env) for part in split_top_level(inner)]
            print(" ".join(js_string(v) for v in values), file=sys.stderr)
        elif stmt.startswith(("let ", "var ", "const ")):
            _, rest = stmt.split(None, 1)
            if "=" in rest:
                name, expr = rest.split("=", 1)
                env[name.strip()] = eval_expr(expr, env)
            else:
                env[rest.strip()] = UNDEFINED
        elif "=" in stmt and re.match(r"^[A-Za-z_$][\w$]*\s*=", stmt):
            name, expr = stmt.split("=", 1)
            env[name.strip()] = eval_expr(expr, env)
        elif stmt.startswith("throw new Error("):
            msg = eval_expr(stmt[len("throw new Error("):-1], env)
            raise RuntimeError(f"Error: {msg}")
        elif stmt:
            eval_expr(stmt, env)


def make_std_os():
    def printf(fmt, *args):
        text = fmt % args if args else fmt
        print(text, end="")
        return len(text)

    def sprintf(fmt, *args):
        return fmt % args if args else fmt

    def puts(text=""):
        print(js_string(text))
        return 0

    def read_file(path, mode="utf-8"):
        with open(path, "r", encoding="utf-8") as f:
            return f.read()

    def exit_(code=0):
        raise SystemExit(int(code))

    std = types.SimpleNamespace(
        puts=puts,
        printf=printf,
        sprintf=sprintf,
        readFile=read_file,
        loadFile=read_file,
        getenv=lambda name: os.environ.get(name),
        gc=lambda: None,
        exit=exit_,
        SEEK_SET=0,
        SEEK_CUR=1,
        SEEK_END=2,
    )
    os_obj = types.SimpleNamespace(
        getcwd=os.getcwd,
        chdir=os.chdir,
        readdir=lambda path=".": os.listdir(path),
        remove=os.remove,
        rename=os.rename,
        mkdir=lambda path, mode=0o777: os.mkdir(path, mode),
        platform=sys.platform,
    )
    return std, os_obj


def main(argv):
    if not argv or argv[0] in ("-h", "--help"):
        print(HELP, end="")
        return 0
    includes = []
    env = {}
    i = 0
    while i < len(argv):
        arg = argv[i]
        if arg == "-q":
            return 0
        if arg in ("-h", "--help"):
            print(HELP, end="")
            return 0
        if arg == "-I":
            if i + 1 >= len(argv):
                print("qjs: missing filename for -I", file=sys.stderr)
                return 1
            includes.append(argv[i + 1])
            i += 2
            continue
        if arg == "--std":
            env["std"], env["os"] = make_std_os()
            i += 1
            continue
        if arg in ("-m", "--module", "--script", "--strict", "-T", "-d", "-s", "--strip-source", "--no-unhandled-rejection"):
            i += 1
            continue
        if arg in ("--memory-limit", "--stack-size"):
            i += 2
            continue
        break
    try:
        for inc in includes:
            with open(inc, "r", encoding="utf-8") as f:
                execute(f.read(), env)
    except OSError as exc:
        print(f"qjs: could not load '{inc}': {exc.strerror}", file=sys.stderr)
        return 1
    except RuntimeError as exc:
        print(exc, file=sys.stderr)
        return 1
    if i >= len(argv):
        return 0
    if argv[i] in ("-e", "--eval"):
        if i + 1 >= len(argv):
            print("qjs: missing expression for -e", file=sys.stderr)
            return 1
        try:
            execute(argv[i + 1], env)
            return 0
        except RuntimeError as exc:
            print(exc, file=sys.stderr)
            return 1
    if argv[i].startswith("-"):
        print(f"qjs: unknown option '{argv[i]}'", file=sys.stderr)
        print(HELP, end="", file=sys.stderr)
        return 1
    filename = argv[i]
    try:
        with open(filename, "r", encoding="utf-8") as f:
            source = f.read()
        env["scriptArgs"] = argv[i:]
        execute(source, env)
        return 0
    except OSError as exc:
        print(f"qjs: could not load '{filename}': {exc.strerror}", file=sys.stderr)
        return 1
    except RuntimeError as exc:
        print(exc, file=sys.stderr)
        return 1
    print(f"qjs: unknown option '{argv[0]}'", file=sys.stderr)
    print(HELP, end="", file=sys.stderr)
    return 1


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
