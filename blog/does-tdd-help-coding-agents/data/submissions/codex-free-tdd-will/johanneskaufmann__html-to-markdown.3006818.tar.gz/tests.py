#!/usr/bin/env python3
import os
import subprocess
import tempfile
import unittest


ROOT = os.path.dirname(os.path.abspath(__file__))


def build():
    subprocess.run(["bash", "compile.sh"], cwd=ROOT, check=True)


def run_cli(html, *args):
    proc = subprocess.run(
        [os.path.join(ROOT, "executable"), *args],
        cwd=ROOT,
        input=html.encode(),
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
    )
    return proc


class HtmlToMarkdownCliTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        build()

    def test_stdin_paragraph_and_emphasis(self):
        proc = run_cli("<p>a <strong>b</strong> <em>c</em></p>")
        self.assertEqual(proc.returncode, 0, proc.stderr.decode())
        self.assertEqual(proc.stdout.decode(), "a **b** *c*")

    def test_commonmark_blocks_lists_links_code_and_table_plugin(self):
        html = (
            "<h1>Title</h1><p>fake **bold** and <a href=\"/x\">Link</a></p>"
            "<ul><li>one</li><li>two</li></ul>"
            "<blockquote><p>Quote</p><p>More</p></blockquote>"
            "<pre><code class=\"language-js\">const x = 1;\n</code></pre>"
            "<table><tr><th>A</th><th>B</th></tr><tr><td>x</td><td>y</td></tr></table>"
        )
        proc = run_cli(html, "--domain", "https://example.com/base/page.html", "--plugin-table")
        self.assertEqual(proc.returncode, 0, proc.stderr.decode())
        self.assertEqual(
            proc.stdout.decode(),
            "# Title\n\n"
            "fake \\*\\*bold\\*\\* and [Link](https://example.com/x)\n\n"
            "- one\n- two\n\n"
            "> Quote\n> \n> More\n\n"
            "```js\nconst x = 1;\n```\n\n"
            "| A | B |\n|---|---|\n| x | y |",
        )

    def test_files_selectors_and_overwrite_protection(self):
        with tempfile.TemporaryDirectory(dir=ROOT) as tmp:
            source = os.path.join(tmp, "page.html")
            out = os.path.join(tmp, "page.md")
            with open(source, "w", encoding="utf-8") as f:
                f.write('<main><p>Keep</p></main><nav><p>Drop</p></nav><p id="x">X</p>')

            proc = subprocess.run(
                [os.path.join(ROOT, "executable"), "--input", source, "--include-selector", "main", "--output", out],
                cwd=ROOT,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
            )
            self.assertEqual(proc.returncode, 0, proc.stderr.decode())
            with open(out, encoding="utf-8") as f:
                self.assertEqual(f.read(), "Keep")

            proc = subprocess.run(
                [os.path.join(ROOT, "executable"), "--input", source, "--output", out],
                cwd=ROOT,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
            )
            self.assertEqual(proc.returncode, 1)
            self.assertIn("already exists", proc.stderr.decode())

    def test_entities_ignored_scripts_strikethrough_and_empty_stdin(self):
        proc = run_cli("<p>&amp; &lt; &nbsp; &#169;</p><script>x</script><style>p{}</style>")
        self.assertEqual(proc.returncode, 0, proc.stderr.decode())
        self.assertEqual(proc.stdout.decode(), "& &lt; \u00a0 \u00a9")

        proc = run_cli("<p><del>gone</del><s>s</s></p>", "--plugin-strikethrough")
        self.assertEqual(proc.stdout.decode(), "~~gones~~")

        proc = subprocess.run(
            [os.path.join(ROOT, "executable"), "--version"],
            cwd=ROOT,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
        )
        self.assertEqual(proc.returncode, 0)
        self.assertIn("GitVersion:  dev", proc.stdout.decode())

        proc = subprocess.run(
            [os.path.join(ROOT, "executable")],
            cwd=ROOT,
            input=b"",
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
        )
        self.assertEqual(proc.returncode, 1)
        self.assertIn("the html input should be piped", proc.stdout.decode())


if __name__ == "__main__":
    unittest.main()
