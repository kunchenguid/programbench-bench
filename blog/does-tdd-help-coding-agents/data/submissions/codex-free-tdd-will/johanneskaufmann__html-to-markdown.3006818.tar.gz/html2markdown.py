#!/usr/bin/env python3
import argparse
import glob
import html
import os
import re
import sys
from html.parser import HTMLParser
from urllib.parse import urljoin


VOID_TAGS = {"area", "base", "br", "col", "embed", "hr", "img", "input", "link", "meta", "param", "source", "track", "wbr"}
BLOCK_TAGS = {
    "address", "article", "aside", "blockquote", "body", "dd", "div", "dl", "dt",
    "fieldset", "figcaption", "figure", "footer", "form", "header", "html", "li",
    "main", "nav", "noscript", "ol", "p", "pre", "section", "table", "tbody",
    "td", "tfoot", "th", "thead", "tr", "ul",
}
SKIP_TAGS = {"script", "style", "template"}


class Node:
    def __init__(self, tag=None, attrs=None, text=None):
        self.tag = tag
        self.attrs = dict(attrs or [])
        self.text = text
        self.children = []

    def append(self, child):
        self.children.append(child)


class TreeBuilder(HTMLParser):
    def __init__(self):
        super().__init__(convert_charrefs=False)
        self.root = Node("document")
        self.stack = [self.root]
        self.skip_depth = 0

    def handle_starttag(self, tag, attrs):
        tag = tag.lower()
        node = Node(tag, attrs)
        if self.skip_depth:
            if tag in SKIP_TAGS:
                self.skip_depth += 1
            return
        if tag in SKIP_TAGS:
            self.skip_depth = 1
            return
        self.stack[-1].append(node)
        if tag not in VOID_TAGS:
            self.stack.append(node)

    def handle_startendtag(self, tag, attrs):
        self.handle_starttag(tag, attrs)

    def handle_endtag(self, tag):
        tag = tag.lower()
        if self.skip_depth:
            if tag in SKIP_TAGS:
                self.skip_depth -= 1
            return
        for i in range(len(self.stack) - 1, 0, -1):
            if self.stack[i].tag == tag:
                del self.stack[i:]
                break

    def handle_data(self, data):
        if not self.skip_depth and data:
            self.stack[-1].append(Node(text=data))

    def handle_entityref(self, name):
        self.handle_data(html.unescape("&" + name + ";"))

    def handle_charref(self, name):
        self.handle_data(html.unescape("&#" + name + ";"))


def parse_html(text):
    parser = TreeBuilder()
    parser.feed(text)
    parser.close()
    return parser.root


def normalize_ws(text):
    return re.sub(r"[ \t\r\n\f\v]+", " ", text)


def escape_text(text):
    text = text.replace("\\", "\\\\")
    text = text.replace("<", "&lt;")
    for ch in ("`", "*", "_", "[", "]"):
        text = text.replace(ch, "\\" + ch)
    return text


def strip_outer_blank_lines(text):
    lines = text.splitlines()
    while lines and not lines[0].strip():
        lines.pop(0)
    while lines and not lines[-1].strip():
        lines.pop()
    return "\n".join(lines)


def collapse_blank_lines(text):
    text = strip_outer_blank_lines(text)
    return re.sub(r"\n{3,}", "\n\n", text)


def text_content(node):
    if node.text is not None:
        return node.text
    return "".join(text_content(c) for c in node.children)


class Renderer:
    def __init__(self, args):
        self.args = args
        self.strong = args.opt_strong_delimiter

    def url(self, value):
        if not value:
            return ""
        if self.args.domain:
            return urljoin(self.args.domain, value)
        return value

    def children_inline(self, node):
        out = []
        i = 0
        while i < len(node.children):
            child = node.children[i]
            if (
                self.args.plugin_strikethrough
                and child.text is None
                and child.tag in ("del", "s", "strike")
            ):
                text = []
                while (
                    i < len(node.children)
                    and node.children[i].text is None
                    and node.children[i].tag in ("del", "s", "strike")
                ):
                    text.append(self.children_inline(node.children[i]).strip())
                    i += 1
                out.append("~~" + "".join(text) + "~~")
                continue
            out.append(self.render_inline(child))
            i += 1
        return "".join(out)

    def render_inline(self, node):
        if node.text is not None:
            return escape_text(normalize_ws(node.text))
        tag = node.tag
        if tag in self.args.preserve_tags_set:
            return self.render_preserved(node)
        if tag in ("strong", "b"):
            return self.strong + self.children_inline(node).strip() + self.strong
        if tag in ("em", "i"):
            return "*" + self.children_inline(node).strip() + "*"
        if tag == "code":
            return "`" + text_content(node).strip().replace("`", "\\`") + "`"
        if tag == "a":
            label = self.children_inline(node).strip() or self.url(node.attrs.get("href", ""))
            href = self.url(node.attrs.get("href", ""))
            title = node.attrs.get("title")
            suffix = f' "{title}"' if title else ""
            return f"[{label}]({href}{suffix})"
        if tag == "img":
            alt = escape_text(node.attrs.get("alt", ""))
            src = self.url(node.attrs.get("src", ""))
            title = node.attrs.get("title")
            suffix = f' "{title}"' if title else ""
            return f"![{alt}]({src}{suffix})"
        if tag == "br":
            return "  \n"
        if tag in ("del", "s", "strike"):
            inner = self.children_inline(node).strip()
            return f"~~{inner}~~" if self.args.plugin_strikethrough else inner
        if tag == "hr":
            return "\n\n* * *\n\n"
        if tag in BLOCK_TAGS or tag.startswith("h"):
            return self.render_block(node)
        return self.children_inline(node)

    def paragraph_text(self, node):
        return self.children_inline(node).strip()

    def render_blocks(self, children):
        parts = []
        inline = []
        for child in children:
            if child.text is not None:
                s = escape_text(normalize_ws(child.text))
                if s.strip():
                    inline.append(s)
                continue
            if child.tag in BLOCK_TAGS or re.fullmatch(r"h[1-6]", child.tag or "") or child.tag == "hr":
                if inline:
                    parts.append("".join(inline).strip())
                    inline = []
                rendered = self.render_block(child)
                if rendered.strip():
                    parts.append(rendered.strip("\n"))
            else:
                inline.append(self.render_inline(child))
        if inline:
            parts.append("".join(inline).strip())
        return "\n\n".join(p for p in parts if p != "")

    def render_block(self, node):
        tag = node.tag
        if tag in self.args.preserve_tags_set:
            return self.render_preserved(node)
        if tag == "document":
            return collapse_blank_lines(self.render_blocks(node.children))
        if tag in ("html", "body", "main", "section", "article", "header", "footer", "nav", "aside", "form"):
            return self.render_blocks(node.children)
        if tag in ("p", "div"):
            inner_blocks = [c for c in node.children if c.text is None and (c.tag in BLOCK_TAGS or re.fullmatch(r"h[1-6]", c.tag or ""))]
            if inner_blocks:
                return self.render_blocks(node.children)
            return self.paragraph_text(node)
        if re.fullmatch(r"h[1-6]", tag or ""):
            level = int(tag[1])
            return "#" * level + " " + self.children_inline(node).strip()
        if tag == "br":
            return "  \n"
        if tag == "hr":
            return "* * *"
        if tag == "blockquote":
            inner = self.render_blocks(node.children)
            return "\n".join("> " + line for line in inner.splitlines())
        if tag in ("ul", "ol"):
            return self.render_list(node, ordered=(tag == "ol"))
        if tag == "li":
            return self.render_blocks(node.children)
        if tag == "pre":
            return self.render_pre(node)
        if tag == "table":
            if self.args.plugin_table:
                return self.render_table(node)
            return "".join(text_content(c).strip() for c in node.children).strip()
        if tag in ("thead", "tbody", "tfoot", "tr", "td", "th"):
            return self.render_blocks(node.children)
        return self.render_blocks(node.children)

    def render_preserved(self, node):
        attrs = "".join(f' {k}="{html.escape(v, quote=True)}"' for k, v in node.attrs.items())
        if node.tag in VOID_TAGS:
            return f"<{node.tag}{attrs}>"
        inner = "".join(text_content(c) if c.text is not None else self.render_preserved(c) for c in node.children)
        return f"<{node.tag}{attrs}>{inner}</{node.tag}>"

    def render_pre(self, node):
        code_node = None
        if len(node.children) == 1 and node.children[0].text is None and node.children[0].tag == "code":
            code_node = node.children[0]
        raw = text_content(code_node or node)
        lang = ""
        if code_node:
            cls = code_node.attrs.get("class", "")
            m = re.search(r"(?:^|\s)language-([A-Za-z0-9_+.-]+)", cls)
            if m:
                lang = m.group(1)
        raw = raw.strip("\n")
        return "```" + lang + "\n" + raw + "\n```"

    def render_list(self, node, ordered=False):
        lines = []
        index = 1
        for child in node.children:
            if child.text is None and child.tag == "li":
                body = self.render_block(child).splitlines() or [""]
                marker = f"{index}. " if ordered else "- "
                lines.append(marker + body[0].strip())
                for extra in body[1:]:
                    lines.append("  " + extra if extra else "  ")
                index += 1
        return "\n".join(lines)

    def table_rows(self, node):
        rows = []
        def walk(n):
            if n.text is not None:
                return
            if n.tag == "tr":
                cells = []
                for c in n.children:
                    if c.text is None and c.tag in ("td", "th"):
                        cells.append(self.children_inline(c).strip())
                if cells:
                    rows.append((any(c.text is None and c.tag == "th" for c in n.children), cells))
            else:
                for c in n.children:
                    walk(c)
        walk(node)
        return rows

    def render_table(self, node):
        rows = self.table_rows(node)
        if not rows:
            return ""
        has_header = rows[0][0] or self.args.opt_table_header_promotion
        width = max(len(r[1]) for r in rows)
        data = [r[1] + [""] * (width - len(r[1])) for r in rows]
        if has_header:
            header = data[0]
            body = data[1:]
        else:
            header = [" "] * width
            body = data
        out = ["| " + " | ".join(header) + " |", "|" + "|".join("---" for _ in range(width)) + "|"]
        out += ["| " + " | ".join(row) + " |" for row in body]
        return "\n".join(out)


def matches_selector(node, selector):
    if node.text is not None:
        return False
    selector = selector.strip()
    if not selector:
        return False
    if selector.startswith("."):
        return selector[1:] in node.attrs.get("class", "").split()
    if selector.startswith("#"):
        return node.attrs.get("id") == selector[1:]
    if "." in selector and not selector.startswith("."):
        tag, cls = selector.split(".", 1)
        return node.tag == tag.lower() and cls in node.attrs.get("class", "").split()
    if "#" in selector and not selector.startswith("#"):
        tag, ident = selector.split("#", 1)
        return node.tag == tag.lower() and node.attrs.get("id") == ident
    return node.tag == selector.lower()


def find_matches(node, selector, out):
    if matches_selector(node, selector):
        out.append(node)
    if node.text is None:
        for c in node.children:
            find_matches(c, selector, out)


def remove_matches(node, selector):
    if node.text is not None:
        return False
    kept = []
    for c in node.children:
        if not remove_matches(c, selector):
            kept.append(c)
    node.children = kept
    return matches_selector(node, selector)


def convert(html_text, args):
    root = parse_html(html_text)
    for selector in args.exclude_selector or []:
        remove_matches(root, selector)
    if args.include_selector:
        selected = Node("document")
        for selector in args.include_selector:
            matches = []
            find_matches(root, selector, matches)
            selected.children.extend(matches)
        root = selected
    return Renderer(args).render_block(root)


def usage_error(msg):
    print()
    print("error: " + msg)
    print()
    return 1


def read_inputs(pattern):
    if any(ch in pattern for ch in "*?["):
        paths = sorted(glob.glob(pattern))
    elif os.path.isdir(pattern):
        paths = sorted(p for p in glob.glob(os.path.join(pattern, "*")) if os.path.isfile(p))
    elif os.path.exists(pattern):
        paths = [pattern]
    else:
        paths = []
    return paths


def parse_args(argv):
    p = argparse.ArgumentParser(add_help=False)
    p.add_argument("-v", "--version", action="store_true")
    p.add_argument("--help", action="store_true")
    p.add_argument("--input")
    p.add_argument("--output")
    p.add_argument("--output-overwrite", action="store_true")
    p.add_argument("--domain")
    p.add_argument("--preserve-tags", action="append")
    p.add_argument("--wrap-links", action="store_true")
    p.add_argument("--exclude-selector", action="append")
    p.add_argument("--include-selector", action="append")
    p.add_argument("--opt-strong-delimiter", default="**")
    p.add_argument("--opt-table-cell-padding-behavior", default="minimal")
    p.add_argument("--opt-table-header-promotion", action="store_true")
    p.add_argument("--opt-table-newline-behavior", default="skip")
    p.add_argument("--opt-table-presentation-tables", action="store_true")
    p.add_argument("--opt-table-skip-empty-rows", action="store_true")
    p.add_argument("--opt-table-span-cell-behavior", default="empty")
    p.add_argument("--plugin-strikethrough", action="store_true")
    p.add_argument("--plugin-table", action="store_true")
    try:
        args, rest = p.parse_known_args(argv)
    except SystemExit:
        sys.stderr.write("\nerror: flag needs an argument: -" + (argv[-1].lstrip("-") if argv else "") + "\n\n")
        sys.exit(1)
    if len(rest) == 1 and not rest[0].startswith("-") and not args.input:
        args.input = rest[0]
        rest = []
    if rest:
        sys.stderr.write("\nerror: unknown flag: " + rest[0] + "\n\n")
        sys.exit(1)
    tags = []
    for item in args.preserve_tags or []:
        tags.extend(t.strip().lower() for t in item.split(",") if t.strip())
    args.preserve_tags_set = set(tags)
    return args


HELP = """
# html2markdown - convert html to markdown [version dev]

Convert HTML to Markdown. Even works with entire websites!

## Flags

    -v, --version
        show the version of html2markdown and exit

    --help

    --input PATH
        Input file, directory, or glob pattern (instead of stdin)

    --output PATH
        Output file or directory (instead of stdout)

    --output-overwrite
        Replace existing files
""".strip()


def main(argv=None):
    args = parse_args(argv or sys.argv[1:])
    if args.help:
        print(HELP)
        return 0
    if args.version:
        print("html2markdown\n\nGitVersion:  dev\nGitCommit:   none\nBuildDate:   unknown")
        return 0
    if args.opt_strong_delimiter not in ("**", "__"):
        return usage_error('invalid value for --opt-strong-delimiter: expected "**" or "__"')
    if args.input:
        paths = read_inputs(args.input)
        if not paths:
            print()
            print(f'error: no files found matching pattern "{args.input}"')
            print()
            print("Here is how you can use a glob to match multiple files:")
            print()
            print('    html2markdown --input "src/*.html" --output "dist/"')
            print()
            return 1
        outputs = []
        multiple = len(paths) > 1 or os.path.isdir(args.input) or any(ch in args.input for ch in "*?[")
        if multiple and args.output and not os.path.isdir(args.output):
            return usage_error("if --input is a directory or glob pattern, --output must be a directory")
        for path in paths:
            with open(path, "r", encoding="utf-8") as f:
                md = convert(f.read(), args)
            if args.output:
                out_path = args.output
                if multiple:
                    base = os.path.splitext(os.path.basename(path))[0] + ".md"
                    out_path = os.path.join(args.output, base)
                if os.path.exists(out_path) and not args.output_overwrite:
                    print(f'error: output path "{out_path}" already exists. Use --output-overwrite to replace existing files', file=sys.stderr)
                    return 1
                os.makedirs(os.path.dirname(out_path) or ".", exist_ok=True)
                with open(out_path, "w", encoding="utf-8") as f:
                    f.write(md)
            else:
                outputs.append(md)
        if not args.output:
            sys.stdout.write("\n\n".join(outputs))
        return 0
    data = sys.stdin.read()
    if data == "":
        print()
        print("error: the html input should be piped into the cli")
        print()
        print("Here is how you can use the CLI:")
        print()
        print('    echo "<strong>important</strong>" | html2markdown')
        print()
        return 1
    md = convert(data, args)
    if args.output:
        if os.path.exists(args.output) and not args.output_overwrite:
            print(f'error: output path "{args.output}" already exists. Use --output-overwrite to replace existing files', file=sys.stderr)
            return 1
        with open(args.output, "w", encoding="utf-8") as f:
            f.write(md)
    else:
        sys.stdout.write(md)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
