#!/bin/bash
set -e
rm -f executable
cp html2markdown.py executable
chmod +x executable
