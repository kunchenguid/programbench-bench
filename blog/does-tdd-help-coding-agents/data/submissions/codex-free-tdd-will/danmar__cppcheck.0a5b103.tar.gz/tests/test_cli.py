import os
import subprocess
import sys
import tempfile
import unittest


ROOT = os.path.dirname(os.path.dirname(__file__))
EXE = os.path.join(ROOT, "src", "cppcheck.py")


def run_cppcheck(args, cwd=None):
    return subprocess.run(
        [sys.executable, EXE, *args],
        cwd=cwd,
        text=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
    )


class CppcheckCliTests(unittest.TestCase):
    def test_version_and_help_are_public_cli(self):
        version = run_cppcheck(["--version"])
        self.assertEqual(version.returncode, 0)
        self.assertEqual(version.stdout, "Cppcheck 2.19 dev\n")
        self.assertEqual(version.stderr, "")

        help_result = run_cppcheck(["--help"])
        self.assertEqual(help_result.returncode, 0)
        self.assertIn("Cppcheck - A tool for static C/C++ code analysis", help_result.stdout)
        self.assertIn("Syntax:\n    cppcheck [OPTIONS] [files or paths]", help_result.stdout)

    def test_reports_documented_array_index_out_of_bounds(self):
        with tempfile.TemporaryDirectory() as td:
            path = os.path.join(td, "file1.c")
            with open(path, "w", encoding="utf-8") as f:
                f.write("int main()\n{\n    char a[10];\n    a[10] = 0;\n    return 0;\n}\n")

            result = run_cppcheck([path])

        self.assertEqual(result.returncode, 0)
        self.assertIn(f"Checking {path}...", result.stderr)
        self.assertIn(
            f"[{path}:4]: (error) Array 'a[10]' index 10 out of bounds",
            result.stderr,
        )

    def test_quiet_error_exitcode_template_and_unknown_option(self):
        with tempfile.TemporaryDirectory() as td:
            path = os.path.join(td, "bad.c")
            with open(path, "w", encoding="utf-8") as f:
                f.write("int main(){\nint a[2];\na[3]=0;\n}\n")

            result = run_cppcheck([
                "--quiet",
                "--error-exitcode=7",
                "--template={file}:{line},{severity},{id},{message}",
                path,
            ])

        self.assertEqual(result.returncode, 7)
        self.assertNotIn("Checking ", result.stderr)
        self.assertIn(f"{path}:3,error,arrayIndexOutOfBounds,Array 'a[2]' index 3 out of bounds", result.stderr)

        bad = run_cppcheck(["--bad"])
        self.assertEqual(bad.returncode, 1)
        self.assertEqual(bad.stdout, 'cppcheck: error: unrecognized command line option: "--bad".\n')

    def test_common_static_analysis_diagnostics_and_xml(self):
        with tempfile.TemporaryDirectory() as td:
            path = os.path.join(td, "bugs.c")
            with open(path, "w", encoding="utf-8") as f:
                f.write(
                    "#include <stdlib.h>\n"
                    "int f(int n){\n"
                    "  int *p = 0;\n"
                    "  int unused;\n"
                    "  int *q = malloc(10);\n"
                    "  free(q);\n"
                    "  free(q);\n"
                    "  return *p + 10 / n;\n"
                    "}\n"
                    "int g(){ int x = 1; }\n"
                )

            text = run_cppcheck(["--enable=all", path])
            xml = run_cppcheck(["--xml", "--enable=all", path])

        self.assertEqual(text.returncode, 0)
        self.assertIn("Null pointer dereference: p", text.stderr)
        self.assertIn("Memory pointed to by 'q' is freed twice.", text.stderr)
        self.assertIn("Variable 'unused' is not used.", text.stderr)
        self.assertIn("Found an exit path from function with non-void return type that has missing return statement", text.stderr)
        self.assertIn('<?xml version="1.0" encoding="UTF-8"?>', xml.stderr)
        self.assertIn('id="nullPointer"', xml.stderr)

    def test_errorlist_file_list_and_output_file(self):
        errorlist = run_cppcheck(["--errorlist"])
        self.assertEqual(errorlist.returncode, 0)
        self.assertIn('<error id="arrayIndexOutOfBounds"', errorlist.stdout)
        self.assertIn('<error id="nullPointer"', errorlist.stdout)

        with tempfile.TemporaryDirectory() as td:
            srcdir = os.path.join(td, "src")
            os.mkdir(srcdir)
            checked = os.path.join(srcdir, "a.c")
            ignored = os.path.join(srcdir, "note.txt")
            out = os.path.join(td, "diag.txt")
            listing = os.path.join(td, "files.txt")
            with open(checked, "w", encoding="utf-8") as f:
                f.write("int main(){ int a[1]; a[2]=0; }\n")
            with open(ignored, "w", encoding="utf-8") as f:
                f.write("int main(){ int a[1]; a[2]=0; }\n")
            with open(listing, "w", encoding="utf-8") as f:
                f.write(checked + "\n")

            result = run_cppcheck(["--quiet", f"--file-list={listing}", f"--output-file={out}"])

            with open(out, "r", encoding="utf-8") as f:
                output = f.read()
        self.assertEqual(result.returncode, 0)
        self.assertEqual(result.stderr, "")
        self.assertIn("Array 'a[1]' index 2 out of bounds", output)
