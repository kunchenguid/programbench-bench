#!/usr/bin/env python3
import os
import re
import sys
import html


VERSION = "Cppcheck 2.19 dev"

HELP_TEXT = """Cppcheck - A tool for static C/C++ code analysis

Syntax:
    cppcheck [OPTIONS] [files or paths]

If a directory is given instead of a filename, *.cpp, *.cxx, *.cc, *.c++, *.c, *.ipp,
*.ixx, *.tpp, and *.txx files are checked recursively from the given directory.

Options:
    -h, --help           Print this help.
    --version            Print out version number.
    --enable=<severity>  Enable additional checks grouped by severity.
    --error-exitcode=<n> If errors are found, integer [n] is returned instead of
                         the default '0'.
    -q, --quiet          Do not show progress reports.
    --xml                Write results in xml format to error stream (stderr).
    --template='<text>'  Format the error messages.

Example usage:
  cppcheck file.c
  cppcheck --enable=all --inconclusive --library=posix test.cpp
"""

SOURCE_EXTS = (".cpp", ".cxx", ".cc", ".c++", ".c", ".ipp", ".ixx", ".tpp", ".txx", ".h", ".hpp")
ERROR_CATALOG = [
    ("arrayIndexOutOfBounds", "error", "Array 'arr[16]' accessed at index 16, which is out of bounds."),
    ("negativeIndex", "error", "Negative array index"),
    ("negativeArraySize", "error", "Declaration of array with negative size is undefined behaviour"),
    ("nullPointer", "error", "Null pointer dereference"),
    ("zerodiv", "error", "Division by zero."),
    ("doubleFree", "error", "Memory pointed to by pointer is freed twice."),
    ("memleak", "error", "Memory leak"),
    ("missingReturn", "error", "Found an exit path from function with non-void return type that has missing return statement"),
    ("unusedVariable", "style", "Variable is not used."),
]


class Diagnostic:
    def __init__(self, path, line, severity, error_id, message):
        self.path = path
        self.line = line
        self.severity = severity
        self.error_id = error_id
        self.message = message


def collect_files(paths):
    files = []
    for path in paths:
        if os.path.isdir(path):
            for root, _, names in os.walk(path):
                for name in sorted(names):
                    if name.endswith(SOURCE_EXTS):
                        files.append(os.path.join(root, name))
        else:
            files.append(path)
    return files


def analyze_file(path, enable_all=False):
    try:
        with open(path, "r", encoding="utf-8", errors="replace") as f:
            lines = f.readlines()
    except OSError as exc:
        return [Diagnostic(path, 0, "error", "fileOpenError", str(exc))]

    arrays = {}
    null_ptrs = set()
    allocated = {}
    freed = set()
    variables = {}
    used_names = {}
    diagnostics = []
    declaration = re.compile(r"\b(?:char|int|long|short|float|double|bool|unsigned|signed)\s+([A-Za-z_]\w*)\s*\[\s*(-?\d+)\s*\]")
    for lineno, line in enumerate(lines, 1):
        declaration_spans = set()
        for match in declaration.finditer(line):
            declaration_spans.add(match.span(1))
            arrays[match.group(1)] = int(match.group(2))
            if int(match.group(2)) < 0:
                diagnostics.append(Diagnostic(path, lineno, "error", "negativeArraySize", "Negative array size"))
        for match in re.finditer(r"\b([A-Za-z_]\w*)\s*\[\s*(-?\d+)\s*\]", line):
            name, index = match.group(1), match.group(2)
            if match.span(1) in declaration_spans:
                continue
            if name in arrays:
                idx = int(index)
                size = arrays[name]
                if idx < 0:
                    diagnostics.append(Diagnostic(path, lineno, "error", "negativeIndex", "Negative array index"))
                elif idx >= size:
                    diagnostics.append(
                        Diagnostic(
                            path,
                            lineno,
                            "error",
                            "arrayIndexOutOfBounds",
                            f"Array '{name}[{size}]' index {idx} out of bounds",
                        )
                    )
        for match in re.finditer(r"\b(?:int|char|long|short|float|double|void|bool)\s*\*\s*([A-Za-z_]\w*)\s*=\s*(?:0|NULL|nullptr)\b", line):
            null_ptrs.add(match.group(1))
        for name in list(null_ptrs):
            if re.search(r"(?<![\w])\*\s*" + re.escape(name) + r"\b", line) and not re.search(r"\*\s*" + re.escape(name) + r"\s*=", line):
                diagnostics.append(Diagnostic(path, lineno, "error", "nullPointer", f"Null pointer dereference: {name}"))
        if re.search(r"/\s*0+\b", line):
            diagnostics.append(Diagnostic(path, lineno, "error", "zerodiv", "Division by zero."))
        for match in re.finditer(r"\b(?:int|char|long|short|float|double|bool)\s+([A-Za-z_]\w*)\b(?!\s*\()", line):
            name = match.group(1)
            if match.span(1) not in declaration_spans:
                variables.setdefault(name, lineno)
        for name in re.findall(r"\b[A-Za-z_]\w*\b", line):
            used_names[name] = used_names.get(name, 0) + 1
        for match in re.finditer(r"\b([A-Za-z_]\w*)\s*=\s*(?:\([^)]+\)\s*)?(?:malloc|calloc|realloc)\s*\(", line):
            allocated[match.group(1)] = lineno
        for match in re.finditer(r"\bfree\s*\(\s*([A-Za-z_]\w*)\s*\)", line):
            name = match.group(1)
            if name in freed:
                diagnostics.append(Diagnostic(path, lineno, "error", "doubleFree", f"Memory pointed to by '{name}' is freed twice."))
            freed.add(name)
    if enable_all:
        for name, lineno in variables.items():
            if used_names.get(name, 0) <= 1:
                diagnostics.append(Diagnostic(path, lineno, "style", "unusedVariable", f"Variable '{name}' is not used."))
    for name, lineno in allocated.items():
        if name not in freed:
            diagnostics.append(Diagnostic(path, lineno, "error", "memleak", f"Memory leak: {name}"))
    diagnostics.extend(find_missing_returns(path, lines))
    return diagnostics


def find_missing_returns(path, lines):
    diagnostics = []
    header = re.compile(r"^\s*(?!void\b)(?:int|char|long|short|float|double|bool|[A-Za-z_]\w+\s*\*?)\s+[A-Za-z_]\w*\s*\([^;]*\)\s*\{")
    i = 0
    while i < len(lines):
        if header.search(lines[i]):
            start = i + 1
            depth = lines[i].count("{") - lines[i].count("}")
            body = lines[i]
            i += 1
            while i < len(lines) and depth > 0:
                body += lines[i]
                depth += lines[i].count("{") - lines[i].count("}")
                i += 1
            if "return" not in body:
                diagnostics.append(
                    Diagnostic(
                        path,
                        start,
                        "error",
                        "missingReturn",
                        "Found an exit path from function with non-void return type that has missing return statement",
                    )
                )
            continue
        i += 1
    return diagnostics


def render_text(diag):
    return f"[{diag.path}:{diag.line}]: ({diag.severity}) {diag.message}"


def render_xml(diagnostics):
    out = ['<?xml version="1.0" encoding="UTF-8"?>', '<results version="2">', f'    <cppcheck version="{VERSION.split(" ", 1)[1]}"/>', "    <errors>"]
    for diag in diagnostics:
        out.append(
            f'        <error id="{html.escape(diag.error_id)}" severity="{html.escape(diag.severity)}" '
            f'msg="{html.escape(diag.message, quote=True)}" verbose="{html.escape(diag.message, quote=True)}">'
            f'<location file="{html.escape(diag.path, quote=True)}" line="{diag.line}"/></error>'
        )
    out.extend(["    </errors>", "</results>"])
    return "\n".join(out) + "\n"


def render_errorlist():
    lines = ['<?xml version="1.0" encoding="UTF-8"?>', '<results version="2">', '    <cppcheck version="2.19 dev"/>', "    <errors>"]
    for error_id, severity, msg in ERROR_CATALOG:
        esc = html.escape(msg, quote=True)
        lines.append(f'        <error id="{error_id}" severity="{severity}" msg="{esc}" verbose="{esc}"/>')
    lines.extend(["    </errors>", "</results>"])
    return "\n".join(lines) + "\n"


def render_template(diag, template):
    return (
        template.replace("{file}", diag.path)
        .replace("{line}", str(diag.line))
        .replace("{column}", "0")
        .replace("{severity}", diag.severity)
        .replace("{message}", diag.message)
        .replace("{id}", diag.error_id)
        .replace("\\n", "\n")
        .replace("\\t", "\t")
        .replace("\\r", "\r")
    )


def parse_args(argv):
    opts = {
        "quiet": False,
        "error_exitcode": 0,
        "template": None,
        "xml": False,
        "files": [],
        "enable_all": False,
        "errorlist": False,
        "output_file": None,
    }
    known_with_values = (
        "--enable",
        "--disable",
        "--std",
        "--language",
        "-x",
        "-I",
        "-D",
        "-U",
        "--library",
        "--platform",
        "--output-file",
        "--output-format",
        "--file-list",
        "--file-filter",
        "-i",
    )
    i = 0
    while i < len(argv):
        arg = argv[i]
        if arg in ("-q", "--quiet"):
            opts["quiet"] = True
        elif arg == "--errorlist":
            opts["errorlist"] = True
        elif arg == "--xml":
            opts["xml"] = True
        elif arg == "--enable=all" or (arg == "--enable" and i + 1 < len(argv) and argv[i + 1] == "all"):
            opts["enable_all"] = True
            if arg == "--enable":
                i += 1
        elif arg.startswith("--error-exitcode="):
            try:
                opts["error_exitcode"] = int(arg.split("=", 1)[1])
            except ValueError:
                opts["error_exitcode"] = 1
        elif arg == "--error-exitcode" and i + 1 < len(argv):
            i += 1
            opts["error_exitcode"] = int(argv[i])
        elif arg.startswith("--template="):
            opts["template"] = arg.split("=", 1)[1].strip("'\"")
        elif arg == "--template" and i + 1 < len(argv):
            i += 1
            opts["template"] = argv[i]
        elif arg.startswith("--output-file="):
            opts["output_file"] = arg.split("=", 1)[1]
        elif arg == "--output-file" and i + 1 < len(argv):
            i += 1
            opts["output_file"] = argv[i]
        elif arg.startswith("--file-list="):
            add_file_list(opts["files"], arg.split("=", 1)[1])
        elif arg == "--file-list" and i + 1 < len(argv):
            i += 1
            add_file_list(opts["files"], argv[i])
        elif arg.startswith("-"):
            matched = False
            for flag in known_with_values:
                if arg == flag and i + 1 < len(argv):
                    i += 1
                    matched = True
                    break
                if arg.startswith(flag + "=") or (flag in ("-I", "-D", "-U", "-i") and len(arg) > 2 and arg.startswith(flag)):
                    matched = True
                    break
            if not matched:
                boolean_known = {
                    "-f",
                    "--force",
                    "--inconclusive",
                    "--inline-suppr",
                    "--check-config",
                    "--check-library",
                    "--safety",
                    "--report-progress",
                }
                if arg not in boolean_known:
                    return opts, arg
        else:
            opts["files"].append(arg)
        i += 1
    return opts, None


def add_file_list(files, path):
    if path == "-":
        data = sys.stdin.read().splitlines()
    else:
        try:
            with open(path, "r", encoding="utf-8", errors="replace") as f:
                data = f.read().splitlines()
        except OSError:
            data = []
    for line in data:
        line = line.strip()
        if line:
            files.append(line)


def main(argv):
    if not argv or argv[0] in ("-h", "--help"):
        sys.stdout.write(HELP_TEXT)
        return 0
    if argv[0] == "--version":
        print(VERSION)
        return 0
    opts, bad_option = parse_args(argv)
    if bad_option:
        print(f'cppcheck: error: unrecognized command line option: "{bad_option}".')
        return 1
    if opts["errorlist"]:
        sys.stdout.write(render_errorlist())
        return 0
    inputs = opts["files"]
    diagnostics = []
    for path in collect_files(inputs):
        if not opts["quiet"]:
            print(f"Checking {path}...", file=sys.stderr)
        diagnostics.extend(analyze_file(path, opts["enable_all"]))
    if opts["xml"]:
        rendered = render_xml(diagnostics)
    else:
        rendered = "".join((render_template(diag, opts["template"]) if opts["template"] else render_text(diag)) + "\n" for diag in diagnostics)
    if opts["output_file"]:
        with open(opts["output_file"], "w", encoding="utf-8") as f:
            f.write(rendered)
    else:
        sys.stderr.write(rendered)
    return opts["error_exitcode"] if diagnostics and opts["error_exitcode"] else 0


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
