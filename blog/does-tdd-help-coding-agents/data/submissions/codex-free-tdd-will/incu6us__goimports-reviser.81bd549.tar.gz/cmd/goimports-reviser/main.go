package main

import (
	"bytes"
	"flag"
	"fmt"
	"go/ast"
	"go/format"
	"go/parser"
	"go/token"
	"io/fs"
	"os"
	"path/filepath"
	"sort"
	"strconv"
	"strings"
)

const version = "3.0.0-20260303205914-9926ea38658f"

func main() {
	versionOnly := flag.Bool("version-only", false, "Show only the version string")
	versionFlag := flag.Bool("version", false, "Show version information")
	projectName := flag.String("project-name", "", "Your project name")
	companyPrefixes := flag.String("company-prefixes", "", "Company package prefixes")
	output := flag.String("output", "file", "Can be file, write, or stdout")
	rmUnused := flag.Bool("rm-unused", false, "Remove unused")
	setAlias := flag.Bool("set-alias", false, "Set aliases")
	importsOrder := flag.String("imports-order", "std,general,company,project", "Imports order")
	separateNamed := flag.Bool("separate-named", false, "Separate named")
	applyGenerated := flag.Bool("apply-to-generated-files", false, "Apply to generated files")
	excludes := flag.String("excludes", "", "Exclude files or dirs")
	filePath := flag.String("file-path", "", "Deprecated")
	listDiff := flag.Bool("list-diff", false, "List files whose formatting differs")
	setExitStatus := flag.Bool("set-exit-status", false, "Set exit status")
	flag.Bool("format", false, "Format")
	flag.String("local", "", "Deprecated")
	recursive := flag.Bool("recursive", false, "Recursive")
	flag.Bool("use-cache", false, "Use cache")
	flag.Parse()

	if *versionOnly {
		fmt.Println(version)
		return
	}
	if *versionFlag {
		fmt.Println("version: " + version)
		fmt.Println("built with: go1.26.0")
		fmt.Println("tag: v" + version)
		fmt.Println("commit: n/a")
		fmt.Println("source: github.com/incu6us/goimports-reviser/v3")
		return
	}

	args := flag.Args()
	if *filePath != "" {
		args = append(args, *filePath)
	}
	if len(args) == 0 {
		flag.Usage()
		os.Exit(1)
	}
	paths, err := expandPaths(args, *recursive, splitCSV(*excludes))
	if err != nil {
		fmt.Fprintln(os.Stderr, err)
		os.Exit(1)
	}
	changedAny := false
	for _, path := range paths {
		src, err := os.ReadFile(path)
		if err != nil {
			fmt.Fprintln(os.Stderr, err)
			os.Exit(1)
		}
		if !*applyGenerated && isGenerated(src) {
			continue
		}
		out, err := rewrite(src, *projectName, splitCSV(*companyPrefixes), splitCSV(*importsOrder), *separateNamed, *rmUnused, *setAlias)
		if err != nil {
			fmt.Fprintln(os.Stderr, err)
			os.Exit(1)
		}
		changed := !bytes.Equal(src, out)
		if changed {
			changedAny = true
		}
		if *listDiff && changed {
			fmt.Println(path)
		}
		if *output == "stdout" {
			os.Stdout.Write(out)
		} else if !*listDiff || *output == "write" || *output == "file" {
			if err := os.WriteFile(path, out, 0644); err != nil {
				fmt.Fprintln(os.Stderr, err)
				os.Exit(1)
			}
		}
	}
	if *setExitStatus && changedAny {
		os.Exit(1)
	}
}

func expandPaths(args []string, recursive bool, excludes []string) ([]string, error) {
	var paths []string
	add := func(path string) {
		if !isExcluded(path, excludes) {
			paths = append(paths, path)
		}
	}
	for _, arg := range args {
		if arg == "./..." {
			arg = "."
			recursive = true
		}
		info, err := os.Stat(arg)
		if err != nil {
			return nil, err
		}
		if !info.IsDir() {
			if strings.HasSuffix(arg, ".go") {
				add(arg)
			}
			continue
		}
		if !recursive {
			entries, err := os.ReadDir(arg)
			if err != nil {
				return nil, err
			}
			for _, entry := range entries {
				if !entry.IsDir() && strings.HasSuffix(entry.Name(), ".go") {
					add(filepath.Join(arg, entry.Name()))
				}
			}
			continue
		}
		err = filepath.WalkDir(arg, func(path string, d fs.DirEntry, err error) error {
			if err != nil {
				return err
			}
			if d.IsDir() {
				if d.Name() == ".git" {
					return filepath.SkipDir
				}
				if isExcluded(path+"/", excludes) {
					return filepath.SkipDir
				}
				return nil
			}
			if strings.HasSuffix(path, ".go") {
				add(path)
			}
			return nil
		})
		if err != nil {
			return nil, err
		}
	}
	sort.Strings(paths)
	return paths, nil
}

func isExcluded(path string, excludes []string) bool {
	clean := filepath.ToSlash(path)
	base := filepath.Base(clean)
	for _, ex := range excludes {
		ex = filepath.ToSlash(strings.TrimSpace(ex))
		if ex == "" {
			continue
		}
		if strings.HasSuffix(ex, "/") {
			prefix := strings.TrimSuffix(ex, "/")
			if clean == prefix || strings.HasPrefix(clean, prefix+"/") || strings.Contains(clean, "/"+prefix+"/") {
				return true
			}
			continue
		}
		if ok, _ := filepath.Match(ex, clean); ok {
			return true
		}
		if ok, _ := filepath.Match(ex, base); ok {
			return true
		}
		if clean == ex || strings.HasSuffix(clean, "/"+ex) {
			return true
		}
	}
	return false
}

func isGenerated(src []byte) bool {
	text := string(src)
	text = strings.TrimLeft(text, " \t\r\n")
	return strings.HasPrefix(text, "// Code generated")
}

type imp struct {
	Alias   string
	Path    string
	Comment string
}

func rewrite(src []byte, projectName string, companyPrefixes, importsOrder []string, separateNamed, rmUnused, setAlias bool) ([]byte, error) {
	fset := token.NewFileSet()
	file, err := parser.ParseFile(fset, "input.go", src, parser.ParseComments)
	if err != nil {
		return nil, err
	}
	if len(file.Imports) == 0 {
		return format.Source(src)
	}
	var importDecl *ast.GenDecl
	for _, decl := range file.Decls {
		gen, ok := decl.(*ast.GenDecl)
		if ok && gen.Tok == token.IMPORT {
			importDecl = gen
			break
		}
	}
	if importDecl == nil {
		return format.Source(src)
	}
	start := fset.Position(importDecl.Pos()).Offset
	end := fset.Position(importDecl.End()).Offset
	for start > 0 && src[start-1] != '\n' {
		start--
	}
	for end < len(src) && src[end] != '\n' {
		end++
	}
	if end < len(src) {
		end++
	}

	var imports []imp
	for _, spec := range file.Imports {
		path, _ := strconv.Unquote(spec.Path.Value)
		alias := ""
		if spec.Name != nil {
			alias = spec.Name.Name
		} else if setAlias {
			alias = versionAlias(path)
		}
		if rmUnused && alias != "_" && alias != "." {
			name := alias
			if name == "" {
				name = defaultImportName(path)
			}
			if !identifierUsed(file, name) {
				continue
			}
		}
		comment := ""
		if spec.Comment != nil {
			var parts []string
			for _, c := range spec.Comment.List {
				parts = append(parts, strings.TrimSpace(strings.TrimPrefix(c.Text, "//")))
			}
			comment = strings.Join(parts, " ")
		}
		imports = append(imports, imp{Alias: alias, Path: path, Comment: comment})
	}
	sort.SliceStable(imports, func(i, j int) bool {
		ki := sortKey(imports[i], projectName, companyPrefixes, importsOrder, separateNamed)
		kj := sortKey(imports[j], projectName, companyPrefixes, importsOrder, separateNamed)
		if ki.rank != kj.rank {
			return ki.rank < kj.rank
		}
		if ki.named != kj.named {
			return ki.named < kj.named
		}
		return imports[i].Path < imports[j].Path
	})

	combined := append([]byte{}, src[:start]...)
	if len(imports) > 0 {
		block := renderImports(imports, projectName, companyPrefixes, importsOrder, separateNamed)
		combined = append(combined, block...)
	}
	combined = append(combined, src[end:]...)
	return format.Source(combined)
}

func versionAlias(path string) string {
	parts := strings.Split(path, "/")
	if len(parts) < 2 {
		return ""
	}
	last := parts[len(parts)-1]
	if len(last) < 2 || last[0] != 'v' {
		return ""
	}
	for _, r := range last[1:] {
		if r < '0' || r > '9' {
			return ""
		}
	}
	return sanitizeIdent(parts[len(parts)-2])
}

func defaultImportName(path string) string {
	parts := strings.Split(path, "/")
	return sanitizeIdent(parts[len(parts)-1])
}

func sanitizeIdent(s string) string {
	s = strings.ReplaceAll(s, "-", "_")
	s = strings.ReplaceAll(s, ".", "_")
	return s
}

func identifierUsed(file *ast.File, name string) bool {
	used := false
	for _, decl := range file.Decls {
		if gen, ok := decl.(*ast.GenDecl); ok && gen.Tok == token.IMPORT {
			continue
		}
		ast.Inspect(decl, func(n ast.Node) bool {
			if id, ok := n.(*ast.Ident); ok && id.Name == name {
				used = true
				return false
			}
			return !used
		})
		if used {
			return true
		}
	}
	return false
}

func groupName(im imp, projectName string, companyPrefixes []string) string {
	if im.Alias == "_" {
		return "blanked"
	}
	if im.Alias == "." {
		return "dotted"
	}
	if projectName != "" && (im.Path == projectName || strings.HasPrefix(im.Path, projectName+"/")) {
		return "project"
	}
	for _, prefix := range companyPrefixes {
		if im.Path == prefix || strings.HasPrefix(im.Path, prefix+"/") {
			return "company"
		}
	}
	first := im.Path
	if idx := strings.IndexByte(first, '/'); idx >= 0 {
		first = first[:idx]
	}
	if !strings.Contains(first, ".") {
		return "std"
	}
	return "general"
}

type key struct {
	rank  int
	named int
}

func sortKey(im imp, projectName string, companyPrefixes, importsOrder []string, separateNamed bool) key {
	name := groupName(im, projectName, companyPrefixes)
	rank := len(importsOrder) + 10
	for i, group := range importsOrder {
		if group == name {
			rank = i
			break
		}
	}
	named := 0
	if separateNamed && im.Alias != "" && im.Alias != "_" && im.Alias != "." {
		named = 1
	}
	return key{rank: rank, named: named}
}

func renderImports(imports []imp, projectName string, companyPrefixes, importsOrder []string, separateNamed bool) []byte {
	var b bytes.Buffer
	b.WriteString("import (\n")
	last := key{rank: -1, named: -1}
	for _, im := range imports {
		k := sortKey(im, projectName, companyPrefixes, importsOrder, separateNamed)
		if last.rank != -1 && k != last {
			b.WriteByte('\n')
		}
		b.WriteByte('\t')
		if im.Alias != "" {
			b.WriteString(im.Alias)
			b.WriteByte(' ')
		}
		fmt.Fprintf(&b, "%q", im.Path)
		if im.Comment != "" {
			b.WriteString(" // ")
			b.WriteString(im.Comment)
		}
		b.WriteByte('\n')
		last = k
	}
	b.WriteString(")\n")
	return b.Bytes()
}

func splitCSV(s string) []string {
	var out []string
	for _, part := range strings.Split(s, ",") {
		part = strings.TrimSpace(part)
		if part != "" {
			out = append(out, part)
		}
	}
	return out
}
