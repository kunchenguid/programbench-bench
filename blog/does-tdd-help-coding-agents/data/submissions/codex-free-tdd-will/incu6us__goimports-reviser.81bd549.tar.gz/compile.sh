#!/bin/bash
set -euo pipefail
export GOTOOLCHAIN=local
go build -o executable ./cmd/goimports-reviser
chmod +x executable
