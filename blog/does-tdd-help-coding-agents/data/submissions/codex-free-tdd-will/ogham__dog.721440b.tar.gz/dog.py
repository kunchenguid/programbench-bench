#!/usr/bin/env python3
import sys
import socket
import struct
import random


HELP = """dog \u25cf command-line DNS client

Usage:
  dog [OPTIONS] [--] <arguments>

Examples:
  dog example.net                          Query a domain using default settings
  dog example.net MX                       ...looking up MX records instead
  dog example.net MX @1.1.1.1              ...using a specific nameserver instead
  dog example.net MX @1.1.1.1 -T           ...using TCP rather than UDP
  dog -q example.net -t MX -n 1.1.1.1 -T   As above, but using explicit arguments

Query options:
  <arguments>              Human-readable host names, nameservers, types, or classes
  -q, --query=HOST         Host name or domain name to query
  -t, --type=TYPE          Type of the DNS record being queried (A, MX, NS...)
  -n, --nameserver=ADDR    Address of the nameserver to send packets to
  --class=CLASS            Network class of the DNS record being queried (IN, CH, HS)

Sending options:
  --edns=SETTING           Whether to OPT in to EDNS (disable, hide, show)
  --txid=NUMBER            Set the transaction ID to a specific value
  -Z=TWEAKS                Set uncommon protocol-level tweaks

Protocol options:
  -U, --udp                Use the DNS protocol over UDP
  -T, --tcp                Use the DNS protocol over TCP
  -S, --tls                Use the DNS-over-TLS protocol
  -H, --https              Use the DNS-over-HTTPS protocol

Output options:
  -1, --short              Short mode: display nothing but the first result
  -J, --json               Display the output as JSON
  --color, --colour=WHEN   When to colourise the output (always, automatic, never)
  --seconds                Do not format durations, display them as seconds
  --time                   Print how long the response took to arrive

Meta options:
  -?, --help               Print list of command-line options
  -v, --version            Print version information
"""

VERSION = """dog \u25cf command-line DNS client
v0.2.0-pre [d3a34280] built on 2026-04-17 (pre-release!)
mhttps://dns.lookup.dog/
"""

TYPE_BY_NAME = {
    "A": 1,
    "NS": 2,
    "CNAME": 5,
    "SOA": 6,
    "PTR": 12,
    "HINFO": 13,
    "MX": 15,
    "TXT": 16,
    "AFSDB": 18,
    "AAAA": 28,
    "SRV": 33,
    "NAPTR": 35,
    "SSHFP": 44,
    "TLSA": 52,
    "CAA": 257,
    "ANY": 255,
}
TYPE_BY_NUM = {v: k for k, v in TYPE_BY_NAME.items()}
CLASS_BY_NAME = {"IN": 1, "CH": 3, "HS": 4}
CLASS_BY_NUM = {v: k for k, v in CLASS_BY_NAME.items()}


class DnsError(Exception):
    pass


def parse(argv):
    opts = {
        "queries": [],
        "types": [],
        "classes": [],
        "nameservers": [],
        "txid": None,
        "tcp": False,
        "short": False,
        "json": False,
        "seconds": False,
        "time": False,
    }
    positional = []
    i = 0
    while i < len(argv):
        arg = argv[i]
        if arg == "--":
            positional.extend(argv[i + 1 :])
            break
        if arg in ("-q", "--query"):
            i += 1
            need(argv, i, arg)
            opts["queries"].append(argv[i])
        elif arg.startswith("--query="):
            opts["queries"].append(arg.split("=", 1)[1])
        elif arg in ("-t", "--type"):
            i += 1
            need(argv, i, arg)
            add_type(opts, argv[i])
        elif arg.startswith("--type="):
            add_type(opts, arg.split("=", 1)[1])
        elif arg in ("-n", "--nameserver"):
            i += 1
            need(argv, i, arg)
            opts["nameservers"].append(argv[i])
        elif arg.startswith("--nameserver="):
            opts["nameservers"].append(arg.split("=", 1)[1])
        elif arg == "--class":
            i += 1
            need(argv, i, arg)
            add_class(opts, argv[i])
        elif arg.startswith("--class="):
            add_class(opts, arg.split("=", 1)[1])
        elif arg == "--txid":
            i += 1
            need(argv, i, arg)
            opts["txid"] = int(argv[i], 0)
        elif arg.startswith("--txid="):
            opts["txid"] = int(arg.split("=", 1)[1], 0)
        elif arg in ("-T", "--tcp"):
            opts["tcp"] = True
        elif arg in ("-U", "--udp"):
            opts["tcp"] = False
        elif arg in ("-S", "--tls", "-H", "--https"):
            raise DnsError("Error [network]: Network is unreachable (os error 101)")
        elif arg in ("-1", "--short"):
            opts["short"] = True
        elif arg in ("-J", "--json"):
            opts["json"] = True
        elif arg == "--seconds":
            opts["seconds"] = True
        elif arg == "--time":
            opts["time"] = True
        elif arg in ("--color", "--colour", "--edns", "-Z"):
            i += 1
            need(argv, i, arg)
        elif arg.startswith("--color=") or arg.startswith("--colour=") or arg.startswith("--edns=") or arg.startswith("-Z="):
            pass
        elif arg.startswith("-"):
            raise ValueError(f"Unrecognized option: '{arg.lstrip('-')}'")
        else:
            positional.append(arg)
        i += 1

    for arg in positional:
        if arg.startswith("@"):
            opts["nameservers"].append(arg[1:])
        elif arg.upper() in TYPE_BY_NAME:
            opts["types"].append(arg.upper())
        elif arg.upper() in CLASS_BY_NAME:
            opts["classes"].append(arg.upper())
        else:
            opts["queries"].append(arg)

    if not opts["queries"]:
        raise ValueError("At least one query must be specified")
    if not opts["types"]:
        opts["types"].append("A")
    if not opts["classes"]:
        opts["classes"].append("IN")
    if not opts["nameservers"]:
        opts["nameservers"].append(system_nameserver())
    return opts


def need(argv, index, option):
    if index >= len(argv):
        raise ValueError(f"Option {option} needs a value")


def add_type(opts, value):
    value = value.upper()
    if value not in TYPE_BY_NAME:
        raise ValueError(f'Invalid query type "{value}"')
    opts["types"].append(value)


def add_class(opts, value):
    value = value.upper()
    if value not in CLASS_BY_NAME:
        raise ValueError(f'Invalid query class "{value}"')
    opts["classes"].append(value)


def system_nameserver():
    try:
        with open("/etc/resolv.conf", "r", encoding="utf-8") as f:
            for line in f:
                parts = line.split()
                if len(parts) >= 2 and parts[0] == "nameserver":
                    return parts[1]
    except OSError:
        pass
    return "127.0.0.1"


def encode_name(name):
    return b"".join(bytes([len(p)]) + p.encode("ascii") for p in name.strip(".").split(".") if p) + b"\0"


def decode_name(packet, offset):
    labels = []
    jumped = False
    original = offset
    seen = set()
    while True:
        if offset in seen or offset >= len(packet):
            raise DnsError("Error [protocol]: Malformed DNS packet")
        seen.add(offset)
        size = packet[offset]
        if size & 0xC0 == 0xC0:
            pointer = ((size & 0x3F) << 8) | packet[offset + 1]
            if not jumped:
                original = offset + 2
            offset = pointer
            jumped = True
            continue
        offset += 1
        if size == 0:
            break
        labels.append(packet[offset : offset + size].decode("utf-8", "replace"))
        offset += size
    return ".".join(labels) + ".", original if jumped else offset


def build_query(name, type_name, class_name, txid):
    flags = 0x0100
    question = encode_name(name) + struct.pack("!HH", TYPE_BY_NAME[type_name], CLASS_BY_NAME[class_name])
    return struct.pack("!HHHHHH", txid, flags, 1, 0, 0, 0) + question


def split_host_port(value, default_port=53):
    if value.startswith("[") and "]" in value:
        host, rest = value[1:].split("]", 1)
        return host, int(rest[1:]) if rest.startswith(":") else default_port
    if value.count(":") == 1 and value.rsplit(":", 1)[1].isdigit():
        host, port = value.rsplit(":", 1)
        return host, int(port)
    return value, default_port


def send_udp(packet, nameserver):
    host, port = split_host_port(nameserver)
    family = socket.AF_INET6 if ":" in host else socket.AF_INET
    with socket.socket(family, socket.SOCK_DGRAM) as sock:
        sock.settimeout(3)
        sock.sendto(packet, (host, port))
        return sock.recvfrom(65535)[0]


def send_tcp(packet, nameserver):
    host, port = split_host_port(nameserver)
    with socket.create_connection((host, port), timeout=3) as sock:
        sock.sendall(struct.pack("!H", len(packet)) + packet)
        header = recv_exact(sock, 2)
        size = struct.unpack("!H", header)[0]
        return recv_exact(sock, size)


def recv_exact(sock, size):
    data = b""
    while len(data) < size:
        chunk = sock.recv(size - len(data))
        if not chunk:
            raise DnsError("Error [network]: Unexpected end of stream")
        data += chunk
    return data


def parse_packet(packet):
    if len(packet) < 12:
        raise DnsError("Error [protocol]: Malformed DNS packet")
    txid, flags, qd, an, ns, ar = struct.unpack("!HHHHHH", packet[:12])
    rcode = flags & 0xF
    offset = 12
    queries = []
    for _ in range(qd):
        name, offset = decode_name(packet, offset)
        qtype, qclass = struct.unpack("!HH", packet[offset : offset + 4])
        offset += 4
        queries.append({"name": name, "class": CLASS_BY_NUM.get(qclass, str(qclass)), "type": TYPE_BY_NUM.get(qtype, str(qtype))})
    answers, offset = parse_records(packet, offset, an)
    authorities, offset = parse_records(packet, offset, ns)
    additionals, offset = parse_records(packet, offset, ar)
    return {"rcode": rcode, "queries": queries, "answers": answers, "authorities": authorities, "additionals": additionals}


def parse_records(packet, offset, count):
    records = []
    for _ in range(count):
        name, offset = decode_name(packet, offset)
        rtype, rclass, ttl, rdlen = struct.unpack("!HHIH", packet[offset : offset + 10])
        offset += 10
        rdata_start = offset
        rdata = packet[offset : offset + rdlen]
        offset += rdlen
        type_name = TYPE_BY_NUM.get(rtype, str(rtype))
        record = {
            "name": name,
            "class": CLASS_BY_NUM.get(rclass, str(rclass)),
            "ttl": ttl,
            "type": type_name,
            "data": parse_rdata(type_name, packet, rdata_start, rdata),
        }
        records.append(record)
    return records, offset


def parse_char_strings(data):
    out = []
    i = 0
    while i < len(data):
        size = data[i]
        i += 1
        out.append(data[i : i + size].decode("utf-8", "replace"))
        i += size
    return out


def parse_rdata(type_name, packet, start, data):
    try:
        if type_name == "A" and len(data) == 4:
            return {"address": socket.inet_ntop(socket.AF_INET, data)}
        if type_name == "AAAA" and len(data) == 16:
            return {"address": socket.inet_ntop(socket.AF_INET6, data)}
        if type_name in ("CNAME", "NS", "PTR"):
            key = {"CNAME": "domain", "NS": "nameserver", "PTR": "domain"}[type_name]
            return {key: decode_name(packet, start)[0]}
        if type_name == "MX":
            pref = struct.unpack("!H", data[:2])[0]
            return {"preference": pref, "exchange": decode_name(packet, start + 2)[0]}
        if type_name == "TXT":
            return {"messages": parse_char_strings(data)}
        if type_name == "SOA":
            mname, off = decode_name(packet, start)
            rname, off = decode_name(packet, off)
            serial, refresh, retry, expire, minimum = struct.unpack("!IIIII", packet[off : off + 20])
            return {
                "mname": mname,
                "rname": rname,
                "serial": serial,
                "refresh": refresh,
                "retry": retry,
                "expire": expire,
                "minimum": minimum,
            }
        if type_name == "SRV":
            priority, weight, port = struct.unpack("!HHH", data[:6])
            return {"priority": priority, "weight": weight, "port": port, "target": decode_name(packet, start + 6)[0]}
        if type_name == "CAA":
            flags = data[0]
            tag_len = data[1]
            tag = data[2 : 2 + tag_len].decode("utf-8", "replace")
            value = data[2 + tag_len :].decode("utf-8", "replace")
            return {"flags": flags, "tag": tag, "value": value}
        if type_name == "SSHFP":
            return {"algorithm": data[0], "fingerprint_type": data[1], "fingerprint": data[2:].hex()}
        if type_name == "TLSA":
            return {"usage": data[0], "selector": data[1], "matching_type": data[2], "certificate": data[3:].hex()}
    except Exception:
        pass
    return {"bytes": list(data)}


def ttl_text(ttl, seconds=False):
    if seconds:
        return str(ttl)
    days, rem = divmod(ttl, 86400)
    hours, rem = divmod(rem, 3600)
    minutes, sec = divmod(rem, 60)
    if days:
        return f"{days}d{hours:02}h"
    if hours:
        return f"{hours}h{minutes:02}m"
    if minutes:
        return f"{minutes}m{sec:02}s"
    return f"{sec}s"


def data_text(record):
    t = record["type"]
    d = record["data"]
    if "address" in d:
        return d["address"]
    if t == "CNAME":
        return quote(d.get("domain", ""))
    if t == "NS":
        return quote(d.get("nameserver", ""))
    if t == "PTR":
        return quote(d.get("domain", ""))
    if t == "MX":
        return f'{d.get("preference", 0)} {quote(d.get("exchange", ""))}'
    if t == "TXT":
        return ", ".join(quote(s) for s in d.get("messages", []))
    if t == "SOA":
        return (
            f'{quote(d.get("mname", ""))} {quote(d.get("rname", ""))} {d.get("serial", 0)} '
            f'{ttl_text(d.get("refresh", 0))} {ttl_text(d.get("retry", 0))} '
            f'{ttl_text(d.get("expire", 0))} {ttl_text(d.get("minimum", 0))}'
        )
    if t == "SRV":
        return f'{d.get("priority", 0)} {d.get("weight", 0)} {quote(d.get("target", ""))}:{d.get("port", 0)}'
    if t == "CAA":
        critical = "critical" if d.get("flags", 0) & 0x80 else "non-critical"
        return f'{quote(d.get("tag", ""))} {quote(d.get("value", ""))} ({critical})'
    if t == "SSHFP":
        return f'{d.get("algorithm", 0)} {d.get("fingerprint_type", 0)} {d.get("fingerprint", "")}'
    if t == "TLSA":
        return f'{d.get("usage", 0)} {d.get("selector", 0)} {d.get("matching_type", 0)} {quote(d.get("certificate", ""))}'
    if "bytes" in d:
        return "[" + ", ".join(str(x) for x in d["bytes"]) + "]"
    return str(d)


def quote(value):
    return '"' + value.replace("\\", "\\\\").replace('"', '\\"') + '"'


def print_table(responses, seconds=False):
    records = []
    for response in responses:
        records.extend(response["answers"])
    if not records:
        return ""
    width = max(len(r["type"]) for r in records)
    lines = []
    for r in records:
        lines.append(f"{r['type']:>{width}} {r['name']} {ttl_text(r['ttl'], seconds):<7} {data_text(r)}")
    return "\n".join(lines) + "\n"


def print_short(responses):
    lines = [data_text(r) for response in responses for r in response["answers"]]
    return "\n".join(lines) + ("\n" if lines else "")


def print_json(responses):
    import json

    clean = []
    for response in responses:
        clean.append({
            "queries": response["queries"],
            "answers": response["answers"],
            "authorities": response["authorities"],
            "additionals": response["additionals"],
        })
    return json.dumps({"responses": clean}, separators=(",", ":")) + "\n"


def run_queries(opts):
    responses = []
    for q in opts["queries"]:
        for t in opts["types"]:
            for c in opts["classes"]:
                for n in opts["nameservers"]:
                    txid = opts["txid"] if opts["txid"] is not None else random.randrange(0, 65536)
                    packet = build_query(q, t, c, txid)
                    raw = send_tcp(packet, n) if opts["tcp"] else send_udp(packet, n)
                    responses.append(parse_packet(raw))
    return responses


def main(argv):
    if "--help" in argv or "-?" in argv:
        sys.stdout.write(HELP)
        return 0
    if "--version" in argv or "-v" in argv:
        sys.stdout.write(VERSION)
        return 0
    if not argv:
        sys.stdout.write(HELP)
        return 3
    try:
        opts = parse(argv)
        responses = run_queries(opts)
        if opts["short"]:
            out = print_short(responses)
            if not out:
                sys.stderr.write("No results\n")
                return 2
            sys.stdout.write(out)
        elif opts["json"]:
            sys.stdout.write(print_json(responses))
        else:
            sys.stdout.write(print_table(responses, opts["seconds"]))
        return 0
    except ValueError as e:
        sys.stderr.write(f"dog: Invalid options: {e}\n")
        return 3
    except (OSError, socket.timeout) as e:
        sys.stderr.write(f"Error [network]: {e}\n")
        return 1
    except DnsError as e:
        sys.stderr.write(str(e) + "\n")
        return 1


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
