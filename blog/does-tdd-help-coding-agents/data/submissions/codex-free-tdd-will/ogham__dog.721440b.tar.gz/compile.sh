#!/bin/bash
set -e
rm -f executable
cp dog.py executable
chmod +x executable
