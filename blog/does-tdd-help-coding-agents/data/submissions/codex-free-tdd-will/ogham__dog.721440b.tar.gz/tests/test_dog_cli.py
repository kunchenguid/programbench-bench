import subprocess
import json
import socket
import struct
import threading
import time
import unittest


class DogCliTests(unittest.TestCase):
    def run_dog(self, *args):
        return subprocess.run(
            ["./executable", *args],
            text=True,
            capture_output=True,
        )

    def test_help_prints_usage(self):
        result = self.run_dog("--help")

        self.assertEqual(result.returncode, 0)
        self.assertIn("dog \u25cf command-line DNS client", result.stdout)
        self.assertIn("Usage:\n  dog [OPTIONS] [--] <arguments>", result.stdout)
        self.assertEqual(result.stderr, "")

    def test_udp_query_formats_common_records(self):
        server = DnsServer([
            ("A", 300, "1.2.3.4"),
            ("AAAA", 301, "2001:db8::1"),
            ("CNAME", 302, "alias.example."),
            ("MX", 303, (10, "mail.example.")),
            ("TXT", 304, ["hello", "world"]),
        ])
        server.start()

        result = self.run_dog(
            "--color",
            "never",
            "example.com",
            f"@127.0.0.1:{server.port}",
            "--txid",
            "1234",
        )

        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertEqual(
            result.stdout,
            '    A example.com. 5m00s   1.2.3.4\n'
            ' AAAA example.com. 5m01s   2001:db8::1\n'
            'CNAME example.com. 5m02s   "alias.example."\n'
            '   MX example.com. 5m03s   10 "mail.example."\n'
            '  TXT example.com. 5m04s   "hello", "world"\n',
        )
        self.assertEqual(result.stderr, "")

    def test_json_output_contains_responses(self):
        server = DnsServer([("A", 300, "1.2.3.4")])
        server.start()

        result = self.run_dog("-J", "example.com", f"@127.0.0.1:{server.port}", "--txid", "1234")

        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertEqual(
            json.loads(result.stdout),
            {
                "responses": [
                    {
                        "queries": [{"name": "example.com.", "class": "IN", "type": "A"}],
                        "answers": [
                            {
                                "name": "example.com.",
                                "class": "IN",
                                "ttl": 300,
                                "type": "A",
                                "data": {"address": "1.2.3.4"},
                            }
                        ],
                        "authorities": [],
                        "additionals": [],
                    }
                ]
            },
        )

    def test_formats_documented_special_record_types(self):
        server = DnsServer([
            ("NS", 65, "ns1.example."),
            ("SOA", 66, ("ns.example.", "hostmaster.example.", 1, 2, 3, 4, 5)),
            ("SRV", 67, (1, 2, 443, "svc.example.")),
            ("CAA", 68, (0, "issue", "letsencrypt.org")),
            ("SSHFP", 71, (1, 1, bytes.fromhex("aabbcc"))),
            ("TLSA", 72, (3, 1, 1, bytes.fromhex("aabbcc"))),
        ])
        server.start()

        result = self.run_dog("--color", "never", "-t", "NS", "x.example", f"@127.0.0.1:{server.port}")

        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertEqual(
            result.stdout,
            '   NS x.example. 1m05s   "ns1.example."\n'
            '  SOA x.example. 1m06s   "ns.example." "hostmaster.example." 1 2s 3s 4s 5s\n'
            '  SRV x.example. 1m07s   1 2 "svc.example.":443\n'
            '  CAA x.example. 1m08s   "issue" "letsencrypt.org" (non-critical)\n'
            'SSHFP x.example. 1m11s   1 1 aabbcc\n'
            ' TLSA x.example. 1m12s   3 1 1 "aabbcc"\n',
        )


TYPE_NUMBERS = {
    "A": 1,
    "NS": 2,
    "CNAME": 5,
    "SOA": 6,
    "MX": 15,
    "TXT": 16,
    "AAAA": 28,
    "SRV": 33,
    "SSHFP": 44,
    "TLSA": 52,
    "CAA": 257,
}


def encode_name(name):
    return b"".join(bytes([len(part)]) + part.encode() for part in name.strip(".").split(".")) + b"\0"


def decode_name(packet, offset):
    labels = []
    jumped = False
    original = offset
    while True:
        size = packet[offset]
        if size & 0xC0 == 0xC0:
            pointer = ((size & 0x3F) << 8) | packet[offset + 1]
            if not jumped:
                original = offset + 2
            offset = pointer
            jumped = True
            continue
        offset += 1
        if size == 0:
            break
        labels.append(packet[offset : offset + size].decode())
        offset += size
    return ".".join(labels) + ".", original if jumped else offset


class DnsServer(threading.Thread):
    def __init__(self, answers):
        super().__init__(daemon=True)
        self.answers = answers
        self.socket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        self.socket.bind(("127.0.0.1", 0))
        self.port = self.socket.getsockname()[1]

    def run(self):
        packet, addr = self.socket.recvfrom(4096)
        self.socket.sendto(self.answer(packet), addr)

    def start(self):
        super().start()
        time.sleep(0.02)

    def answer(self, packet):
        txid = struct.unpack("!H", packet[:2])[0]
        offset = 12
        name, offset = decode_name(packet, offset)
        question = packet[12 : offset + 4]
        records = b"".join(self.record(name, *answer) for answer in self.answers)
        return struct.pack("!HHHHHH", txid, 0x8180, 1, len(self.answers), 0, 0) + question + records

    def record(self, name, kind, ttl, value):
        if kind == "A":
            data = socket.inet_aton(value)
        elif kind == "AAAA":
            data = socket.inet_pton(socket.AF_INET6, value)
        elif kind == "CNAME":
            data = encode_name(value)
        elif kind == "MX":
            preference, exchange = value
            data = struct.pack("!H", preference) + encode_name(exchange)
        elif kind == "TXT":
            data = b"".join(bytes([len(part)]) + part.encode() for part in value)
        elif kind == "NS":
            data = encode_name(value)
        elif kind == "SOA":
            mname, rname, serial, refresh, retry, expire, minimum = value
            data = encode_name(mname) + encode_name(rname) + struct.pack("!IIIII", serial, refresh, retry, expire, minimum)
        elif kind == "SRV":
            priority, weight, port, target = value
            data = struct.pack("!HHH", priority, weight, port) + encode_name(target)
        elif kind == "CAA":
            flags, tag, caa_value = value
            data = bytes([flags, len(tag)]) + tag.encode() + caa_value.encode()
        elif kind == "SSHFP":
            algorithm, fp_type, fingerprint = value
            data = bytes([algorithm, fp_type]) + fingerprint
        elif kind == "TLSA":
            usage, selector, matching, cert = value
            data = bytes([usage, selector, matching]) + cert
        return encode_name(name) + struct.pack("!HHIH", TYPE_NUMBERS[kind], 1, ttl, len(data)) + data


if __name__ == "__main__":
    unittest.main()
