#!/usr/bin/env python3
import json
import math
import re
import sys


HELP = """Usage: ./executable [-][ytjcrneikhv]

Convert between YAML, TOML, JSON, and HCL.
Preserves map order.

-x[x]  Convert using stdin. Valid options:
          -yj, -y = YAML to JSON (default)
          -yy     = YAML to YAML
          -yt     = YAML to TOML
          -yc     = YAML to HCL
          -tj, -t = TOML to JSON
          -ty     = TOML to YAML
          -tt     = TOML to TOML
          -tc     = TOML to HCL
          -jj     = JSON to JSON
          -jy, -r = JSON to YAML
          -jt     = JSON to TOML
          -jc     = JSON to HCL
          -cy     = HCL to YAML
          -ct     = HCL to TOML
          -cj, -c = HCL to JSON
          -cc     = HCL to HCL
-n     Do not covert inf, -inf, and NaN to/from strings (YAML or TOML only)
-e     Escape HTML (JSON out only)
-i     Indent output (JSON or TOML out only)
-k     Attempt to parse keys as objects or numeric types (YAML out only)
-h     Show this help message
-v     Show version
"""


class ParseError(Exception):
    pass


def parse_scalar(s):
    s = s.strip()
    if s == "":
        return ""
    if s in ("null", "~"):
        return None
    if s == "true":
        return True
    if s == "false":
        return False
    if (s[0:1], s[-1:]) in ((('"', '"')), (("'", "'"))):
        return s[1:-1]
    if s.startswith("[") and s.endswith("]"):
        inner = s[1:-1].strip()
        if not inner:
            return []
        return [parse_scalar(part) for part in split_commas(inner)]
    if re.match(r"^-?\d+$", s):
        try:
            return int(s)
        except ValueError:
            pass
    if re.match(r"^-?(\d+\.\d*|\d*\.\d+)([eE][+-]?\d+)?$", s) or re.match(r"^-?\d+[eE][+-]?\d+$", s):
        try:
            return float(s)
        except ValueError:
            pass
    if s in (".inf", "inf", "+inf"):
        return math.inf
    if s in ("-.inf", "-inf"):
        return -math.inf
    if s in (".nan", "nan", "NaN"):
        return math.nan
    return s


def split_commas(s):
    out, cur, quote, depth = [], [], None, 0
    esc = False
    for ch in s:
        if quote:
            cur.append(ch)
            if esc:
                esc = False
            elif ch == "\\":
                esc = True
            elif ch == quote:
                quote = None
        elif ch in "'\"":
            quote = ch
            cur.append(ch)
        elif ch in "[{":
            depth += 1
            cur.append(ch)
        elif ch in "]}":
            depth -= 1
            cur.append(ch)
        elif ch == "," and depth == 0:
            out.append("".join(cur).strip())
            cur = []
        else:
            cur.append(ch)
    out.append("".join(cur).strip())
    return out


def yaml_lines(text):
    lines = []
    for raw in text.splitlines():
        if not raw.strip() or raw.lstrip().startswith("#"):
            continue
        indent = len(raw) - len(raw.lstrip(" "))
        lines.append((indent, raw.strip()))
    return lines


def parse_yaml(text):
    lines = yaml_lines(text)
    if not lines:
        return None
    value, idx = parse_yaml_block(lines, 0, lines[0][0])
    if idx != len(lines):
        raise ParseError("yaml: line 1: did not find expected node content")
    return value


def parse_toml(text):
    root = {}
    cur = root
    for raw in text.splitlines():
        line = raw.strip()
        if not line or line.startswith("#"):
            continue
        if "#" in line:
            line = line.split("#", 1)[0].rstrip()
        if line.startswith("[[") and line.endswith("]]"):
            name = line[2:-2].strip()
            arr = root.setdefault(name, [])
            item = {}
            arr.append(item)
            cur = item
            continue
        if line.startswith("[") and line.endswith("]"):
            cur = root
            for part in line[1:-1].split("."):
                cur = cur.setdefault(part.strip(), {})
            continue
        if "=" not in line:
            continue
        key, val = line.split("=", 1)
        set_dotted(cur, key.strip().strip('"'), parse_toml_value(val.strip()))
    return root


def set_dotted(d, key, value):
    parts = [p.strip().strip('"') for p in key.split(".")]
    for p in parts[:-1]:
        d = d.setdefault(p, {})
    d[parts[-1]] = value


def parse_toml_value(s):
    if s.startswith('"') and s.endswith('"'):
        return bytes(s[1:-1], "utf-8").decode("unicode_escape")
    if s.startswith("'") and s.endswith("'"):
        return s[1:-1]
    return parse_scalar(s)


def parse_hcl(text):
    root = {}
    stack = [root]
    for raw in text.splitlines():
        line = raw.strip()
        if not line or line.startswith("#") or line.startswith("//"):
            continue
        if line == "}":
            if len(stack) > 1:
                stack.pop()
            continue
        if line.endswith("{"):
            name = line[:-1].strip().strip('"')
            item = {}
            stack[-1].setdefault(name, []).append(item)
            stack.append(item)
            continue
        if "=" in line:
            k, v = line.split("=", 1)
            stack[-1][k.strip().strip('"')] = parse_toml_value(v.strip().rstrip(","))
    return root


def parse_yaml_block(lines, idx, indent):
    if idx >= len(lines):
        return None, idx
    if lines[idx][1].startswith("- "):
        arr = []
        while idx < len(lines) and lines[idx][0] == indent and lines[idx][1].startswith("- "):
            item = lines[idx][1][2:].strip()
            if item == "":
                val, idx = parse_yaml_block(lines, idx + 1, indent + 2)
                arr.append(val)
            elif ":" in item and not item.startswith(("'", '"')):
                k, v = item.split(":", 1)
                d = {}
                if v.strip():
                    d[k.strip()] = parse_scalar(v)
                    idx += 1
                else:
                    val, idx = parse_yaml_block(lines, idx + 1, indent + 2)
                    d[k.strip()] = val
                while idx < len(lines) and lines[idx][0] == indent + 2 and not lines[idx][1].startswith("- "):
                    key, valtext = split_key_value(lines[idx][1])
                    if valtext == "":
                        val, idx = parse_yaml_block(lines, idx + 1, indent + 4)
                    else:
                        val = parse_scalar(valtext)
                        idx += 1
                    d[key] = val
                arr.append(d)
            else:
                arr.append(parse_scalar(item))
                idx += 1
        return arr, idx
    d = {}
    while idx < len(lines) and lines[idx][0] == indent and not lines[idx][1].startswith("- "):
        key, valtext = split_key_value(lines[idx][1])
        if valtext == "":
            val, idx = parse_yaml_block(lines, idx + 1, indent + 2)
        else:
            val = parse_scalar(valtext)
            idx += 1
        d[key] = val
    return d, idx


def split_key_value(s):
    if ":" not in s:
        raise ParseError("yaml: line 1: did not find expected ':'")
    k, v = s.split(":", 1)
    return k.strip(), v.strip()


def json_dumps(value, indent=False, escape_html=False):
    text = json.dumps(value, ensure_ascii=False, allow_nan=True, separators=None if indent else (",", ":"), indent=2 if indent else None)
    if escape_html:
        text = text.replace("<", "\\u003c").replace(">", "\\u003e").replace("&", "\\u0026")
    return text + "\n"


def yaml_scalar(v):
    if v is None:
        return "null"
    if v is True:
        return "true"
    if v is False:
        return "false"
    if isinstance(v, str):
        if v == "":
            return '""'
        return v
    return str(v)


def yaml_key(k, parse_keys=False):
    s = str(k)
    if parse_keys:
        return s
    if s in ("true", "false", "null", "~") or re.match(r"^-?\d+(\.\d+)?$", s):
        return json.dumps(s, ensure_ascii=False)
    return s


def yaml_emit(value, level=0, parse_keys=False):
    pad = " " * level
    lines = []
    if isinstance(value, dict):
        for k, v in value.items():
            if isinstance(v, (dict, list)):
                lines.append(f"{pad}{yaml_key(k, parse_keys)}:")
                lines.extend(yaml_emit(v, level + 2, parse_keys))
            else:
                lines.append(f"{pad}{yaml_key(k, parse_keys)}: {yaml_scalar(v)}")
    elif isinstance(value, list):
        for item in value:
            if isinstance(item, dict):
                pairs = list(item.items())
                if not pairs:
                    lines.append(f"{pad}- {{}}")
                    continue
                first_k, first_v = pairs[0]
                if isinstance(first_v, (dict, list)):
                    lines.append(f"{pad}- {yaml_key(first_k, parse_keys)}:")
                    lines.extend(yaml_emit(first_v, level + 4, parse_keys))
                else:
                    lines.append(f"{pad}- {yaml_key(first_k, parse_keys)}: {yaml_scalar(first_v)}")
                for k, v in pairs[1:]:
                    if isinstance(v, (dict, list)):
                        lines.append(f"{pad}  {yaml_key(k, parse_keys)}:")
                        lines.extend(yaml_emit(v, level + 4, parse_keys))
                    else:
                        lines.append(f"{pad}  {yaml_key(k, parse_keys)}: {yaml_scalar(v)}")
            elif isinstance(item, list):
                lines.append(f"{pad}-")
                lines.extend(yaml_emit(item, level + 2, parse_keys))
            else:
                lines.append(f"{pad}- {yaml_scalar(item)}")
    else:
        lines.append(pad + yaml_scalar(value))
    return lines


def toml_scalar(v):
    if v is True:
        return "true"
    if v is False:
        return "false"
    if isinstance(v, str):
        return json.dumps(v, ensure_ascii=False)
    return str(v)


def toml_value(v):
    if isinstance(v, list):
        kept = [x for x in v if x is not None and not isinstance(x, dict)]
        return "[" + ", ".join(toml_scalar(x) for x in kept) + "]"
    return toml_scalar(v)


def toml_emit(d, indent=False, level=0):
    lines = []
    sections = []
    pref = "  " if indent and level > 0 else ""
    for k, v in d.items() if isinstance(d, dict) else []:
        if isinstance(v, dict):
            sections.append((k, v, False))
        elif isinstance(v, list) and v and all(isinstance(x, dict) for x in v):
            for item in v:
                sections.append((k, item, True))
        elif v is not None:
            lines.append(f"{pref}{k} = {toml_value(v)}")
    for name, body, array in sections:
        if lines:
            lines.append("")
        lines.append(f"[[{name}]]" if array else f"[{name}]")
        for k, v in body.items():
            if not isinstance(v, (dict, list)) or (isinstance(v, list) and not any(isinstance(x, dict) for x in v)):
                if v is not None:
                    lines.append(f"{'  ' if indent else ''}{k} = {toml_value(v)}")
        nested = {k: v for k, v in body.items() if isinstance(v, dict)}
        if nested:
            sub = toml_emit(nested, indent, level + 1).splitlines()
            lines.extend(sub)
    return "\n".join(lines) + ("\n" if lines else "")


def hcl_value(v, level=0):
    if isinstance(v, dict):
        inner = hcl_emit(v, level + 2)
        pad = " " * level
        return "{\n" + inner + "\n" + pad + "}"
    if isinstance(v, list):
        if v and all(isinstance(x, dict) for x in v):
            return hcl_value(v[0], level)
        return "[" + ", ".join(toml_scalar(x) for x in v if x is not None) + "]"
    return toml_scalar(v)


def hcl_emit(d, level=0):
    pad = " " * level
    lines = []
    if isinstance(d, dict):
        for k, v in d.items():
            lines.append(f'{pad}"{k}" = {hcl_value(v, level)}')
            if level == 0:
                lines.append("")
    if lines and lines[-1] == "":
        lines.pop()
    return "\n".join(lines)


def parse_flags(argv):
    chars = []
    for arg in argv[1:]:
        if arg.startswith("-"):
            chars.extend(arg[1:])
        else:
            chars.extend(arg)
    if not chars:
        chars = ["y"]
    return chars


def main(argv):
    flags = parse_flags(argv)
    valid = set("ytjcrneikhv")
    invalid = [c for c in flags if c not in valid]
    if invalid:
        sys.stderr.write(HELP + "\nError: invalid flags specified: " + " ".join(invalid) + "\n")
        return 1
    if "h" in flags:
        sys.stdout.write(HELP)
        return 0
    if "v" in flags:
        sys.stdout.write("v0.0.0\n")
        return 0
    indent = "i" in flags
    escape_html = "e" in flags
    parse_keys = "k" in flags
    conv = "".join([c for c in flags if c in "ytjcr"]) or "y"
    aliases = {"y": "yj", "t": "tj", "j": "jj", "r": "jy", "c": "cj"}
    conv = aliases.get(conv, conv)
    if len(conv) < 2:
        conv = conv + "j"
    if parse_keys and conv[1] != "y":
        sys.stderr.write(HELP + "\nError: flag -k only valid for YAML output\n")
        return 1
    data = sys.stdin.read()
    try:
        if conv[0] == "y":
            label = "YAML"
            value = parse_yaml(data)
        elif conv[0] == "t":
            label = "TOML"
            value = parse_toml(data)
        elif conv[0] == "c":
            label = "HCL"
            value = parse_hcl(data)
        else:
            label = "JSON"
            value = json.loads(data)
        if conv[1] == "j":
            sys.stdout.write(json_dumps(value, indent, escape_html))
            return 0
        if conv[1] == "y":
            sys.stdout.write("\n".join(yaml_emit(value, parse_keys=parse_keys)) + "\n")
            return 0
        if conv[1] == "t":
            sys.stdout.write(toml_emit(value, indent))
            return 0
        if conv[1] == "c":
            sys.stdout.write(hcl_emit(value))
            return 0
    except Exception as e:
        msg = str(e)
        if label == "JSON" and isinstance(e, json.JSONDecodeError):
            if data.strip() in ("{", "[") or "Unterminated" in msg:
                msg = "unexpected end of JSON input"
        sys.stderr.write(f"Error parsing {label}: {msg}\n")
        return 1
    sys.stdout.write(json_dumps(value, indent, escape_html))
    return 0


if __name__ == "__main__":
    raise SystemExit(main(sys.argv))
