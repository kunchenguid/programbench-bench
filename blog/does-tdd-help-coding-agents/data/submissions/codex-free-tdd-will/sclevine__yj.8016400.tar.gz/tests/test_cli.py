import os, subprocess, unittest

ROOT = os.path.dirname(os.path.dirname(__file__))
EXE = os.path.join(ROOT, 'executable')


def run(args, data=''):
    return subprocess.run([EXE] + args, input=data, text=True, capture_output=True)


class CliTests(unittest.TestCase):
    def test_yaml_to_json_default_compact(self):
        p = run(['-y'], 'a: 1\nb: test\nc:\n  - true\n  - null\n')
        self.assertEqual(p.returncode, 0)
        self.assertEqual(p.stdout, '{"a":1,"b":"test","c":[true,null]}\n')
        self.assertEqual(p.stderr, '')

    def test_json_to_yaml(self):
        p = run(['-jy'], '{"a":1,"b":"test","c":[true,null]}')
        self.assertEqual(p.returncode, 0)
        self.assertEqual(p.stdout, 'a: 1\nb: test\nc:\n  - true\n  - null\n')

    def test_toml_to_json(self):
        p = run(['-t'], 'a = 1\nb = "test"\nc = [true, false]\n')
        self.assertEqual(p.returncode, 0)
        self.assertEqual(p.stdout, '{"a":1,"b":"test","c":[true,false]}\n')

    def test_json_to_toml_sections(self):
        p = run(['-jt'], '{"b":2,"a":{"x":1,"y":"z"},"arr":[{"x":1},{"x":2}]}')
        self.assertEqual(p.returncode, 0)
        self.assertEqual(p.stdout, 'b = 2\n\n[a]\nx = 1\ny = "z"\n\n[[arr]]\nx = 1\n\n[[arr]]\nx = 2\n')

    def test_hcl_to_json_blocks(self):
        p = run(['-c'], 'a = 1\nb = "test"\nlist = [1, 2]\nobj {\n  x = true\n}\n')
        self.assertEqual(p.returncode, 0)
        self.assertEqual(p.stdout, '{"a":1,"b":"test","list":[1,2],"obj":[{"x":true}]}\n')

    def test_json_to_hcl(self):
        p = run(['-jc'], '{"a":{"x":1},"arr":[{"b":2}],"s":"hi"}')
        self.assertEqual(p.returncode, 0)
        self.assertEqual(p.stdout, '"a" = {\n  "x" = 1\n}\n\n"arr" = {\n  "b" = 2\n}\n\n"s" = "hi"')

    def test_yaml_output_quotes_numeric_string_keys_unless_k(self):
        p = run(['-jy'], '{"1":"a","true":"b"}')
        self.assertEqual(p.returncode, 0)
        self.assertEqual(p.stdout, '"1": a\n"true": b\n')
        p = run(['-jyk'], '{"1":"a","true":"b"}')
        self.assertEqual(p.returncode, 0)
        self.assertEqual(p.stdout, '1: a\ntrue: b\n')

    def test_toml_indent_flag_indents_section_values(self):
        p = run(['-jti'], '{"c":[1,2],"a":{"b":1}}')
        self.assertEqual(p.returncode, 0)
        self.assertEqual(p.stdout, 'c = [1, 2]\n\n[a]\n  b = 1\n')

    def test_json_short_alias_and_version(self):
        p = run(['-j'], '{"a":1}')
        self.assertEqual(p.returncode, 0)
        self.assertEqual(p.stdout, '{"a":1}\n')
        p = run(['-v'])
        self.assertEqual(p.returncode, 0)
        self.assertEqual(p.stdout, 'v0.0.0\n')

    def test_k_rejected_unless_yaml_output(self):
        p = run(['-yk'], 'a: 1\n')
        self.assertEqual(p.returncode, 1)
        self.assertEqual(p.stdout, '')
        self.assertIn('Error: flag -k only valid for YAML output', p.stderr)

    def test_yaml_output_uses_inline_first_key_for_map_list_items(self):
        p = run(['-jy'], '{"arr":[{"b":2},{"c":3}]}')
        self.assertEqual(p.returncode, 0)
        self.assertEqual(p.stdout, 'arr:\n  - b: 2\n  - c: 3\n')

    def test_parse_errors_go_to_stderr_with_format_label(self):
        p = run(['-j'], '{')
        self.assertEqual(p.returncode, 1)
        self.assertEqual(p.stdout, '')
        self.assertIn('Error parsing JSON:', p.stderr)

if __name__ == '__main__':
    unittest.main()
