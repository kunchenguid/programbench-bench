#!/bin/bash
set -e
rm -f executable
cp src/yj.py executable
chmod +x executable
