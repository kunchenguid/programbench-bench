#!/bin/bash
set -e
cp impl/ripsecrets.py executable
chmod +x executable
