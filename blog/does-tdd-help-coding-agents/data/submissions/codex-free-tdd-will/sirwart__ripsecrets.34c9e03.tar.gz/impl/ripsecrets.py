#!/usr/bin/env python3
import argparse
import math
import os
import re
import sys
from pathlib import Path

VERSION = "ripsecrets 0.1.11"
HELP_SHORT = """A command-line tool to prevent committing secret keys into your source code

Usage: executable [OPTIONS] [Source files]...

Arguments:
  [Source files]...  Source files. Can be files or directories. Defaults to '.'

Options:
      --install-pre-commit
          Install `ripsecrets` as a pre-commit hook automatically in git directory provided
      --strict-ignore
          If you pass a path as an argument that's ignored by .secretsignore it will be scanned by default. --strict-ignore will override this behavior and not search the paths passed as arguments that are excluded by the .secretsignore file. This is useful when invoking secrets as a pre-commit
      --only-matching
          Print only the matched (non-empty) parts of a matching line, with each such part on a separate output line
      --additional-pattern <ADDITIONAL_PATTERNS>
          Additional regex patterns used to find secrets. If there is a matching group in the regex the matched group will be tested for randomness before being reported as a secret
  -h, --help
          Print help (see more with '--help')
  -V, --version
          Print version"""

HELP_LONG = """ripsecrets searches files and directories recursively for secret API keys.
It's primarily designed to be used as a pre-commit to prevent committing
secrets into version control.

Usage: executable [OPTIONS] [Source files]...

Arguments:
  [Source files]...
          Source files. Can be files or directories. Defaults to '.'

Options:
      --install-pre-commit
          Install `ripsecrets` as a pre-commit hook automatically in git directory provided

      --strict-ignore
          If you pass a path as an argument that's ignored by .secretsignore it will be scanned by default. --strict-ignore will override this behavior and not search the paths passed as arguments that are excluded by the .secretsignore file. This is useful when invoking secrets as a pre-commit

      --only-matching
          Print only the matched (non-empty) parts of a matching line, with each such part on a separate output line

      --additional-pattern <ADDITIONAL_PATTERNS>
          Additional regex patterns used to find secrets. If there is a matching group in the regex the matched group will be tested for randomness before being reported as a secret

  -h, --help
          Print help (see a summary with '-h')

  -V, --version
          Print version"""

SECRET_PATTERNS = [
    re.compile(r"AKIA[0-9A-Z]{16}"),
    re.compile(r"ASIA[0-9A-Z]{16}"),
    re.compile(r"(?i)aws(.{0,20})?(secret|access)?.{0,20}[:=]\s*['\"]?([A-Za-z0-9/+=]{32,})"),
    re.compile(r"xox[baprs]-[A-Za-z0-9-]{20,}"),
    re.compile(r"gh[pousr]_[A-Za-z0-9_]{30,}"),
    re.compile(r"github_pat_[A-Za-z0-9_]{30,}"),
    re.compile(r"glpat-[A-Za-z0-9_-]{20,}"),
    re.compile(r"sk-[A-Za-z0-9]{20,}"),
    re.compile(r"-----BEGIN [A-Z ]*PRIVATE KEY-----"),
    re.compile(r"(?i)(password|passwd|pwd|token|secret|api[_-]?key|access[_-]?key)\s*[:=]\s*['\"]?([^'\"\s]{16,})"),
]


def shannon_entropy(value):
    if not value:
        return 0.0
    counts = {}
    for ch in value:
        counts[ch] = counts.get(ch, 0) + 1
    entropy = 0.0
    length = len(value)
    for count in counts.values():
        p = count / length
        entropy -= p * math.log2(p)
    return entropy


def is_randomish(value):
    if len(value) < 16:
        return False
    classes = sum([
        any(c.islower() for c in value),
        any(c.isupper() for c in value),
        any(c.isdigit() for c in value),
        any(c in "/+=_-." for c in value),
    ])
    return classes >= 2 and shannon_entropy(value) >= 3.25


def find_secret(line, additional):
    for pattern in SECRET_PATTERNS:
        match = pattern.search(line)
        if not match:
            continue
        if len(match.groups()) >= 2 and pattern.pattern.startswith("(?i)(password"):
            candidate = match.group(2)
            if not is_randomish(candidate):
                continue
            return candidate
        if match.lastindex:
            for group in reversed(match.groups()):
                if group and len(group) >= 8:
                    return group
        return match.group(0)

    for pattern in additional:
        match = pattern.search(line)
        if not match:
            continue
        if match.lastindex:
            for group in match.groups():
                if group and (len(group) < 16 or is_randomish(group)):
                    return group
        else:
            return match.group(0)
    return None


def iter_files(paths):
    for raw in paths or ["."]:
        path = Path(raw)
        if path.is_dir():
            for root, dirs, files in os.walk(path):
                dirs[:] = [d for d in sorted(dirs) if d not in {".git", ".hg", ".svn"}]
                for name in sorted(files):
                    yield Path(root) / name
        else:
            yield path


def scan_file(path, only_matching, additional):
    try:
        with open(path, "r", encoding="utf-8", errors="ignore") as handle:
            for number, line in enumerate(handle, 1):
                text = line.rstrip("\n")
                secret = find_secret(text, additional)
                if secret:
                    payload = secret if only_matching else text
                    print(f"{path}:{number}:{payload}")
                    yield True
    except (OSError, UnicodeError) as exc:
        print(f"{path}: {exc}", file=sys.stderr)


def install_pre_commit():
    hook = Path(".git/hooks/pre-commit")
    hook.parent.mkdir(parents=True, exist_ok=True)
    hook.write_text("#!/bin/sh\nripsecrets --strict-ignore\n", encoding="utf-8")
    hook.chmod(0o755)


def parse_args(argv):
    if argv == ["-h"]:
        print(HELP_SHORT)
        raise SystemExit(0)
    if argv == ["--help"]:
        print(HELP_LONG)
        raise SystemExit(0)
    parser = argparse.ArgumentParser(
        prog="executable",
        description="A command-line tool to prevent committing secret keys into your source code",
        add_help=False,
    )
    parser.add_argument("-h", "--help", action="store_true")
    parser.add_argument("--install-pre-commit", action="store_true")
    parser.add_argument("--strict-ignore", action="store_true")
    parser.add_argument("--only-matching", action="store_true")
    parser.add_argument("--additional-pattern", action="append", default=[])
    parser.add_argument("-V", "--version", action="store_true")
    parser.add_argument("paths", nargs="*")
    return parser.parse_args(argv)


def main(argv=None):
    args = parse_args(argv or sys.argv[1:])
    if args.version:
        print(VERSION)
        return 0
    if args.install_pre_commit:
        install_pre_commit()
        return 0

    additional = []
    for raw in args.additional_pattern:
        try:
            additional.append(re.compile(raw))
        except re.error as exc:
            print(f"error: invalid regex: {exc}", file=sys.stderr)
            return 2

    found = False
    for path in iter_files(args.paths):
        for hit in scan_file(path, args.only_matching, additional):
            found = found or hit
    return 1 if found else 0


if __name__ == "__main__":
    raise SystemExit(main())
