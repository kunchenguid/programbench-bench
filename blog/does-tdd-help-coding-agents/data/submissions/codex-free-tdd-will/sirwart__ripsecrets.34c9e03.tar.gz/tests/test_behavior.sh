#!/bin/bash
set -euo pipefail

BIN=${1:-./executable}
TMP=$(mktemp -d)
trap 'rm -rf "$TMP"' EXIT

[ "$("$BIN" --version)" = "ripsecrets 0.1.11" ]
"$BIN" -h > "$TMP/help"
grep -Fq "A command-line tool to prevent committing secret keys into your source code" "$TMP/help"
grep -Fq "Usage: executable [OPTIONS] [Source files]..." "$TMP/help"

cat > "$TMP/cases.txt" <<'CASES'
hello world
aws_access_key_id = AKIAIOSFODNN7EXAMPLE
password = hunter2
password = 7Zcc0Pg02lHl5OJw1zM3zPq5D1nR78NF
private key -----BEGIN PRIVATE KEY-----
CASES

set +e
"$BIN" "$TMP/cases.txt" > "$TMP/out" 2> "$TMP/err"
status=$?
set -e

[ "$status" -eq 1 ]
cat > "$TMP/expected" <<EXPECT
$TMP/cases.txt:2:aws_access_key_id = AKIAIOSFODNN7EXAMPLE
$TMP/cases.txt:4:password = 7Zcc0Pg02lHl5OJw1zM3zPq5D1nR78NF
$TMP/cases.txt:5:private key -----BEGIN PRIVATE KEY-----
EXPECT
diff -u "$TMP/expected" "$TMP/out"
[ ! -s "$TMP/err" ]

cat > "$TMP/custom.txt" <<'CUSTOM'
foo custom = SHORT
foo custom = ABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890
CUSTOM
set +e
"$BIN" --additional-pattern 'custom = ([A-Z0-9]+)' --only-matching "$TMP/custom.txt" > "$TMP/out" 2> "$TMP/err"
status=$?
set -e

[ "$status" -eq 1 ]
cat > "$TMP/expected" <<EXPECT
$TMP/custom.txt:1:SHORT
$TMP/custom.txt:2:ABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890
EXPECT
diff -u "$TMP/expected" "$TMP/out"
[ ! -s "$TMP/err" ]

set +e
"$BIN" --only-matching "$TMP/cases.txt" > "$TMP/out" 2> "$TMP/err"
status=$?
set -e

[ "$status" -eq 1 ]
cat > "$TMP/expected" <<EXPECT
$TMP/cases.txt:2:AKIAIOSFODNN7EXAMPLE
$TMP/cases.txt:4:7Zcc0Pg02lHl5OJw1zM3zPq5D1nR78NF
$TMP/cases.txt:5:-----BEGIN PRIVATE KEY-----
EXPECT
diff -u "$TMP/expected" "$TMP/out"
[ ! -s "$TMP/err" ]
