#!/usr/bin/env python3
import os
import subprocess
import sys


HELP_TEXT = """tig 2.6.0-g87c9c25 

Usage: tig        [options] [revs] [--] [paths]
   or: tig log    [options] [revs] [--] [paths]
   or: tig show   [options] [revs] [--] [paths]
   or: tig reflog [options] [revs]
   or: tig blame  [options] [rev] [--] path
   or: tig grep   [options] [pattern]
   or: tig refs   [options]
   or: tig stash  [options]
   or: tig status
   or: tig <      [git command output]

Options:
  +<number>       Select line <number> in the first view
  -v, --version   Show version and exit
  -h, --help      Show help message and exit
  -C <path>       Start in <path>
"""

SUBCOMMANDS = {"log", "show", "reflog", "blame", "grep", "refs", "stash", "status"}


def first_revision_candidate(argv):
    for arg in argv:
        if arg == "--":
            return None
        if arg in SUBCOMMANDS:
            return None
        if arg.startswith("+") and arg[1:].isdigit():
            continue
        if arg.startswith("-"):
            continue
        return arg
    return None


def revision_exists(rev):
    result = subprocess.run(
        ["git", "rev-parse", "--verify", "--quiet", rev + "^{commit}"],
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL,
    )
    return result.returncode == 0


def main(argv):
    remaining = []
    index = 0
    while index < len(argv):
        arg = argv[index]
        if arg in ("--help", "-h"):
            sys.stdout.write(HELP_TEXT)
            return 0
        if arg in ("--version", "-v"):
            sys.stdout.write("tig version 2.6.0-g87c9c25\nncursesw version 6.3.20211021\n")
            return 0
        if arg == "-C" and index + 1 < len(argv):
            path = argv[index + 1]
            try:
                os.chdir(path)
            except OSError:
                sys.stderr.write(f"tig: Failed to change directory to {path}\n")
                return 1
            index += 2
            continue
        remaining.append(arg)
        index += 1
    rev = first_revision_candidate(remaining)
    if rev and not revision_exists(rev):
        sys.stderr.write("tig: No revisions match the given arguments.\n")
        return 1
    if not sys.stdin.isatty():
        sys.stderr.write("tig: Failed to open tty for input\n")
        return 1
    return 0


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
