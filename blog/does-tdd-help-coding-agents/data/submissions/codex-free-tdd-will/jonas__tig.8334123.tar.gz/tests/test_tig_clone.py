import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
APP = ROOT / "src" / "tig_clone.py"


def run_app(*args, input_data=None, cwd=None):
    return subprocess.run(
        [sys.executable, str(APP), *args],
        input=input_data,
        text=True,
        capture_output=True,
        cwd=cwd or ROOT,
    )


class TigCloneTests(unittest.TestCase):
    def test_help_matches_documented_usage(self):
        result = run_app("--help")
        self.assertEqual(result.returncode, 0)
        self.assertEqual(result.stderr, "")
        self.assertTrue(
            result.stdout.startswith(
                "tig 2.6.0-g87c9c25 \n\n"
                "Usage: tig        [options] [revs] [--] [paths]\n"
            )
        )
        self.assertIn("  -C <path>       Start in <path>\n", result.stdout)

    def test_version_prints_tig_and_ncurses_versions(self):
        result = run_app("--version")
        self.assertEqual(result.returncode, 0)
        self.assertEqual(result.stdout, "tig version 2.6.0-g87c9c25\nncursesw version 6.3.20211021\n")
        self.assertEqual(result.stderr, "")

    def test_invalid_C_path_reports_change_directory_failure_before_help(self):
        result = run_app("-C", "/no/such/path", "--help")
        self.assertEqual(result.returncode, 1)
        self.assertEqual(result.stdout, "")
        self.assertEqual(result.stderr, "tig: Failed to change directory to /no/such/path\n")

    def test_early_version_exits_before_later_invalid_C_path(self):
        result = run_app("--version", "-C", "/no/such/path")
        self.assertEqual(result.returncode, 0)
        self.assertEqual(result.stdout, "tig version 2.6.0-g87c9c25\nncursesw version 6.3.20211021\n")
        self.assertEqual(result.stderr, "")

    def test_noninteractive_status_fails_to_open_tty(self):
        result = run_app("status")
        self.assertEqual(result.returncode, 1)
        self.assertEqual(result.stdout, "")
        self.assertEqual(result.stderr, "tig: Failed to open tty for input\n")

    def test_unknown_revision_reports_no_matching_revisions(self):
        result = run_app("definitely-not-a-revision")
        self.assertEqual(result.returncode, 1)
        self.assertEqual(result.stdout, "")
        self.assertEqual(result.stderr, "tig: No revisions match the given arguments.\n")


if __name__ == "__main__":
    unittest.main()
