#!/bin/bash
set -e
cp src/tig_clone.py executable
chmod +x executable
