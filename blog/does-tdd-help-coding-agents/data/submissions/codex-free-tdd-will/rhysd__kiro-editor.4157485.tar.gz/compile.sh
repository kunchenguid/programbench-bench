#!/bin/bash
set -e
gcc -std=c11 -Wall -Wextra -O2 -o executable src/kiro.c
chmod +x executable
