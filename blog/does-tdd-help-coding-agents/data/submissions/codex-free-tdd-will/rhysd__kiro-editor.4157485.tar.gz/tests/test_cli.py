import os, subprocess, pathlib
ROOT = pathlib.Path(__file__).resolve().parents[1]

def build():
    subprocess.run(["bash", "compile.sh"], cwd=ROOT, check=True)

def run(*args, input=None):
    return subprocess.run([str(ROOT/"executable"), *args], cwd=ROOT, input=input, stdout=subprocess.PIPE, stderr=subprocess.PIPE)

def test_version_matches_kiro():
    build()
    p = run("--version")
    assert p.returncode == 0
    assert p.stdout == b"0.4.3\n"
    assert p.stderr == b""

def test_help_contains_usage_and_keymap():
    build()
    p = run("--help")
    assert p.returncode == 0
    assert b"Usage:\n    ./executable [options] [FILES...]" in p.stdout
    assert b"Ctrl-Q                        : Quit" in p.stdout
    assert b"-v, --version       Print version" in p.stdout


def test_invalid_option_reports_error():
    build()
    p = run("--bad")
    assert p.returncode == 1
    assert p.stdout == b""
    assert p.stderr == b"Error: Unrecognized option: 'bad'. Please see --help for more details\n"
import os, pty, time, tempfile, select, signal

def drive_editor(args, keys, timeout=3):
    build()
    pid, fd = pty.fork()
    if pid == 0:
        os.environ["TERM"] = "xterm"
        os.execv(str(ROOT/"executable"), [str(ROOT/"executable"), *args])
    out = bytearray()
    deadline = time.time() + timeout
    try:
        time.sleep(0.2)
        os.write(fd, keys)
        while time.time() < deadline:
            r, _, _ = select.select([fd], [], [], 0.05)
            if fd in r:
                try:
                    chunk = os.read(fd, 4096)
                except OSError:
                    break
                if not chunk:
                    break
                out.extend(chunk)
            done, status = os.waitpid(pid, os.WNOHANG)
            if done:
                return bytes(out), status
        os.kill(pid, signal.SIGTERM)
        _, status = os.waitpid(pid, 0)
        return bytes(out), status
    finally:
        os.close(fd)


def test_tty_insert_save_and_quit(tmp_path):
    path = tmp_path / "note.txt"
    out, status = drive_editor([str(path)], b"abc\x13\x11")
    assert os.WIFEXITED(status) and os.WEXITSTATUS(status) == 0
    assert path.read_bytes() == b"abc\n"
    assert b"bytes written" in out

def test_tty_cursor_backspace_newline_save_existing_file(tmp_path):
    path = tmp_path / "edit.txt"
    path.write_bytes(b"hello\nworld\n")
    # Ctrl-E to end, left left, backspace removes l, Enter splits line, save, quit
    out, status = drive_editor([str(path)], b"\x05\x1b[D\x1b[D\x7f\r\x13\x11")
    assert os.WIFEXITED(status) and os.WEXITSTATUS(status) == 0
    assert path.read_bytes() == b"he\nlo\nworld\n"
