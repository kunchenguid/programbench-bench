#define _POSIX_C_SOURCE 200809L
#include <ctype.h>
#include <errno.h>
#include <stdbool.h>
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/ioctl.h>
#include <termios.h>
#include <unistd.h>

#define VERSION "0.4.3"
#define CTRL_KEY(k) ((k) & 0x1f)

static const char *HELP =
"./executable: A tiny UTF-8 terminal text editor\n"
"\n"
"Kiro is a tiny UTF-8 text editor on terminals for Unix-like systems.\n"
"Specify file paths to edit as a command argument or run without argument to\n"
"start to write a new text.\n"
"Help can show up with key mapping Ctrl-?.\n"
"\n"
"Usage:\n"
"    ./executable [options] [FILES...]\n"
"\n"
"Mappings:\n"
"    Ctrl-Q                        : Quit\n"
"    Ctrl-S                        : Save to file\n"
"    Ctrl-O                        : Open text buffer\n"
"    Ctrl-X                        : Next text buffer\n"
"    Alt-X                         : Previous text buffer\n"
"    Ctrl-P or UP                  : Move cursor up\n"
"    Ctrl-N or DOWN                : Move cursor down\n"
"    Ctrl-F or RIGHT               : Move cursor right\n"
"    Ctrl-B or LEFT                : Move cursor left\n"
"    Ctrl-A or Alt-LEFT or HOME    : Move cursor to head of line\n"
"    Ctrl-E or Alt-RIGHT or END    : Move cursor to end of line\n"
"    Ctrl-[ or Ctrl-V or PAGE DOWN : Next page\n"
"    Ctrl-] or Alt-V or PAGE UP    : Previous page\n"
"    Alt-F or Ctrl-RIGHT           : Move cursor to next word\n"
"    Alt-B or Ctrl-LEFT            : Move cursor to previous word\n"
"    Alt-N or Ctrl-DOWN            : Move cursor to next paragraph\n"
"    Alt-P or Ctrl-UP              : Move cursor to previous paragraph\n"
"    Alt-<                         : Move cursor to top of file\n"
"    Alt->                         : Move cursor to bottom of file\n"
"    Ctrl-H or BACKSPACE           : Delete character\n"
"    Ctrl-D or DELETE              : Delete next character\n"
"    Ctrl-W                        : Delete a word\n"
"    Ctrl-J                        : Delete until head of line\n"
"    Ctrl-K                        : Delete until end of line\n"
"    Ctrl-U                        : Undo last change\n"
"    Ctrl-R                        : Redo last undo change\n"
"    Ctrl-G                        : Search text\n"
"    Ctrl-M                        : New line\n"
"    Ctrl-L                        : Refresh screen\n"
"    Ctrl-?                        : Show this help\n"
"\n"
"Options:\n"
"    -v, --version       Print version\n"
"    -h, --help          Print this help\n";

typedef struct { char *s; size_t len, cap; } Line;
typedef struct { Line *v; size_t len, cap; } Lines;
typedef struct {
    Lines lines;
    char *filename;
    size_t cx, cy;
    bool dirty;
    char msg[256];
    int rows, cols;
    struct termios orig;
} Editor;

static char *xstrdup(const char *s) { size_t n = strlen(s) + 1; char *p = malloc(n); if (!p) exit(1); memcpy(p, s, n); return p; }
static void line_init(Line *l) { l->cap = 16; l->len = 0; l->s = malloc(l->cap); if (!l->s) exit(1); l->s[0] = 0; }
static void line_reserve(Line *l, size_t n) { if (n + 1 <= l->cap) return; while (l->cap < n + 1) l->cap *= 2; l->s = realloc(l->s, l->cap); if (!l->s) exit(1); }
static void line_insert(Line *l, size_t at, const char *s, size_t n) { if (at > l->len) at = l->len; line_reserve(l, l->len + n); memmove(l->s + at + n, l->s + at, l->len - at + 1); memcpy(l->s + at, s, n); l->len += n; }
static void line_del(Line *l, size_t at, size_t n) { if (at >= l->len) return; if (at + n > l->len) n = l->len - at; memmove(l->s + at, l->s + at + n, l->len - at - n + 1); l->len -= n; }
static void lines_push_empty(Lines *ls) { if (ls->len == ls->cap) { ls->cap = ls->cap ? ls->cap * 2 : 8; ls->v = realloc(ls->v, ls->cap * sizeof(Line)); if (!ls->v) exit(1); } line_init(&ls->v[ls->len++]); }
static void lines_insert_empty(Lines *ls, size_t at) { if (at > ls->len) at = ls->len; if (ls->len == ls->cap) { ls->cap = ls->cap ? ls->cap * 2 : 8; ls->v = realloc(ls->v, ls->cap * sizeof(Line)); if (!ls->v) exit(1); } memmove(ls->v + at + 1, ls->v + at, (ls->len - at) * sizeof(Line)); line_init(&ls->v[at]); ls->len++; }
static void lines_delete(Lines *ls, size_t at) { if (ls->len <= 1 || at >= ls->len) return; free(ls->v[at].s); memmove(ls->v + at, ls->v + at + 1, (ls->len - at - 1) * sizeof(Line)); ls->len--; }

static void editor_init(Editor *e) { memset(e, 0, sizeof(*e)); lines_push_empty(&e->lines); snprintf(e->msg, sizeof(e->msg), "Ctrl-? for help"); }
static void append_bytes(char **buf, size_t *len, size_t *cap, const char *s, size_t n) { if (*len + n + 1 > *cap) { while (*len + n + 1 > *cap) *cap = *cap ? *cap * 2 : 1024; *buf = realloc(*buf, *cap); if (!*buf) exit(1); } memcpy(*buf + *len, s, n); *len += n; (*buf)[*len] = 0; }
static void load_file(Editor *e, const char *path) {
    e->filename = xstrdup(path);
    FILE *f = fopen(path, "rb");
    if (!f) return;
    for (size_t i = 0; i < e->lines.len; i++) free(e->lines.v[i].s);
    free(e->lines.v); e->lines = (Lines){0}; lines_push_empty(&e->lines);
    int c;
    while ((c = fgetc(f)) != EOF) {
        if (c == '\n') lines_push_empty(&e->lines);
        else { char ch = (char)c; Line *l = &e->lines.v[e->lines.len - 1]; line_insert(l, l->len, &ch, 1); }
    }
    if (e->lines.len > 1 && e->lines.v[e->lines.len - 1].len == 0) { free(e->lines.v[e->lines.len - 1].s); e->lines.len--; }
    fclose(f);
}
static void save_file(Editor *e) {
    if (!e->filename) { snprintf(e->msg, sizeof(e->msg), "No filename"); return; }
    FILE *f = fopen(e->filename, "wb");
    if (!f) { snprintf(e->msg, sizeof(e->msg), "Could not save: %s", strerror(errno)); return; }
    size_t bytes = 0;
    for (size_t i = 0; i < e->lines.len; i++) { fwrite(e->lines.v[i].s, 1, e->lines.v[i].len, f); bytes += e->lines.v[i].len; fputc('\n', f); bytes++; }
    fclose(f); e->dirty = false; snprintf(e->msg, sizeof(e->msg), "%zu bytes written to %s", bytes, e->filename);
}

static void disable_raw(Editor *e) { tcsetattr(STDIN_FILENO, TCSAFLUSH, &e->orig); (void)write(STDOUT_FILENO, "\x1b[?1049l\x1b[H", 11); }
static void enable_raw(Editor *e) {
    if (tcgetattr(STDIN_FILENO, &e->orig) == -1) { fprintf(stderr, "Error: %s\n", strerror(errno)); exit(1); }
    struct termios raw = e->orig;
    raw.c_iflag &= ~(BRKINT | ICRNL | INPCK | ISTRIP | IXON);
    raw.c_oflag &= ~(OPOST);
    raw.c_cflag |= CS8;
    raw.c_lflag &= ~(ECHO | ICANON | IEXTEN | ISIG);
    raw.c_cc[VMIN] = 0; raw.c_cc[VTIME] = 1;
    if (tcsetattr(STDIN_FILENO, TCSAFLUSH, &raw) == -1) { fprintf(stderr, "Error: %s\n", strerror(errno)); exit(1); }
    (void)write(STDOUT_FILENO, "\x1b[?1049h", 8);
}
static void get_size(Editor *e) { struct winsize ws; if (ioctl(STDOUT_FILENO, TIOCGWINSZ, &ws) == -1 || ws.ws_col == 0) { e->rows = 24; e->cols = 80; } else { e->rows = ws.ws_row; e->cols = ws.ws_col; } if (e->rows < 3) e->rows = 3; }
static void abuf_append(char **b, size_t *l, size_t *c, const char *fmt, ...) { char tmp[512]; va_list ap; va_start(ap, fmt); int n = vsnprintf(tmp, sizeof(tmp), fmt, ap); va_end(ap); if (n > 0) append_bytes(b, l, c, tmp, (size_t)n); }
static void refresh(Editor *e) {
    get_size(e);
    char *b = NULL; size_t len = 0, cap = 0;
    append_bytes(&b, &len, &cap, "\x1b[?25l\x1b[39;0m", 13);
    int textrows = e->rows - 2;
    for (int y = 0; y < textrows; y++) {
        abuf_append(&b, &len, &cap, "\x1b[%dH", y + 1);
        if ((size_t)y < e->lines.len) {
            Line *ln = &e->lines.v[y];
            size_t n = ln->len < (size_t)e->cols ? ln->len : (size_t)e->cols;
            append_bytes(&b, &len, &cap, ln->s, n);
            append_bytes(&b, &len, &cap, "\x1b[39;0m", 7);
        } else if (e->lines.len == 1 && e->lines.v[0].len == 0 && y == textrows / 3) {
            char welcome[80]; snprintf(welcome, sizeof(welcome), "Kiro editor -- version %s", VERSION);
            int pad = (e->cols - (int)strlen(welcome)) / 2; if (pad < 0) pad = 0;
            for (int i = 0; i < pad; i++) append_bytes(&b, &len, &cap, " ", 1);
            append_bytes(&b, &len, &cap, welcome, strlen(welcome));
        } else append_bytes(&b, &len, &cap, "\x1b[37m~\x1b[39;0m", 15);
        append_bytes(&b, &len, &cap, "\x1b[K", 3);
    }
    char fnamebuf[256]; const char *fn = e->filename ? e->filename : "[No Name]";
    snprintf(fnamebuf, sizeof(fnamebuf), "\"%s\" - 1/1%s", fn, e->dirty ? " (modified)" : "");
    char right[64]; snprintf(right, sizeof(right), "plain %zu/%zu", e->cy + 1, e->lines.len);
    abuf_append(&b, &len, &cap, "\x1b[%dH\x1b[7m", e->rows - 1);
    int leftlen = (int)strlen(fnamebuf), rightlen = (int)strlen(right);
    append_bytes(&b, &len, &cap, fnamebuf, strlen(fnamebuf));
    for (int i = leftlen; i < e->cols - rightlen; i++) append_bytes(&b, &len, &cap, " ", 1);
    append_bytes(&b, &len, &cap, right, strlen(right));
    append_bytes(&b, &len, &cap, "\x1b[39;0m", 7);
    abuf_append(&b, &len, &cap, "\x1b[%dH", e->rows);
    append_bytes(&b, &len, &cap, e->msg, strlen(e->msg)); append_bytes(&b, &len, &cap, "\x1b[K", 3);
    size_t cy = e->cy < e->lines.len ? e->cy : e->lines.len - 1, cx = e->cx;
    if (cx > e->lines.v[cy].len) cx = e->lines.v[cy].len;
    abuf_append(&b, &len, &cap, "\x1b[%zu;%zuH\x1b[?25h", cy + 1, cx + 1);
    (void)write(STDOUT_FILENO, b, len); free(b);
}

static int read_key(void) { char c; for (;;) { ssize_t n = read(STDIN_FILENO, &c, 1); if (n == 1) return (unsigned char)c; if (n == 0) continue; if (errno != EAGAIN) return -1; } }
static void insert_char(Editor *e, char c) { Line *l = &e->lines.v[e->cy]; line_insert(l, e->cx, &c, 1); e->cx++; e->dirty = true; }
static void newline(Editor *e) { Line *l = &e->lines.v[e->cy]; lines_insert_empty(&e->lines, e->cy + 1); Line *n = &e->lines.v[e->cy + 1]; line_insert(n, 0, l->s + e->cx, l->len - e->cx); l->len = e->cx; l->s[l->len] = 0; e->cy++; e->cx = 0; e->dirty = true; }
static void backspace(Editor *e) { if (e->cx > 0) { Line *l = &e->lines.v[e->cy]; line_del(l, e->cx - 1, 1); e->cx--; e->dirty = true; } else if (e->cy > 0) { size_t old = e->lines.v[e->cy - 1].len; line_insert(&e->lines.v[e->cy - 1], old, e->lines.v[e->cy].s, e->lines.v[e->cy].len); lines_delete(&e->lines, e->cy); e->cy--; e->cx = old; e->dirty = true; } }
static void delchar(Editor *e) { Line *l = &e->lines.v[e->cy]; if (e->cx < l->len) { line_del(l, e->cx, 1); e->dirty = true; } else if (e->cy + 1 < e->lines.len) { line_insert(l, l->len, e->lines.v[e->cy + 1].s, e->lines.v[e->cy + 1].len); lines_delete(&e->lines, e->cy + 1); e->dirty = true; } }
static void move_cursor(Editor *e, int key) { Line *l = &e->lines.v[e->cy]; if (key == 'A' || key == CTRL_KEY('P')) { if (e->cy > 0) e->cy--; } else if (key == 'B' || key == CTRL_KEY('N')) { if (e->cy + 1 < e->lines.len) e->cy++; } else if (key == 'C' || key == CTRL_KEY('F')) { if (e->cx < l->len) e->cx++; else if (e->cy + 1 < e->lines.len) { e->cy++; e->cx = 0; } } else if (key == 'D' || key == CTRL_KEY('B')) { if (e->cx > 0) e->cx--; else if (e->cy > 0) { e->cy--; e->cx = e->lines.v[e->cy].len; } } if (e->cx > e->lines.v[e->cy].len) e->cx = e->lines.v[e->cy].len; }
static void editor_loop(Editor *e) {
    enable_raw(e); refresh(e); bool done = false;
    while (!done) {
        int c = read_key(); if (c < 0) break;
        if (c == '\x1b') { char seq[2]; if (read(STDIN_FILENO, &seq[0], 1) == 1 && read(STDIN_FILENO, &seq[1], 1) == 1 && seq[0] == '[') move_cursor(e, seq[1]); }
        else if (c == CTRL_KEY('Q')) done = true;
        else if (c == CTRL_KEY('S')) save_file(e);
        else if (c == CTRL_KEY('M')) newline(e);
        else if (c == 127 || c == CTRL_KEY('H')) backspace(e);
        else if (c == CTRL_KEY('D')) delchar(e);
        else if (c == CTRL_KEY('A')) e->cx = 0;
        else if (c == CTRL_KEY('E')) e->cx = e->lines.v[e->cy].len;
        else if (c == CTRL_KEY('K')) { e->lines.v[e->cy].len = e->cx; e->lines.v[e->cy].s[e->cx] = 0; e->dirty = true; }
        else if (c == CTRL_KEY('J')) { Line *l = &e->lines.v[e->cy]; line_del(l, 0, e->cx); e->cx = 0; e->dirty = true; }
        else if (c == 127) backspace(e);
        else if (c >= 32 && c != 127) insert_char(e, (char)c);
        refresh(e);
    }
    disable_raw(e);
}

int main(int argc, char **argv) {
    for (int i = 1; i < argc; i++) {
        if (strcmp(argv[i], "--version") == 0 || strcmp(argv[i], "-v") == 0) { printf(VERSION "\n"); return 0; }
        if (strcmp(argv[i], "--help") == 0 || strcmp(argv[i], "-h") == 0) { fputs(HELP, stdout); return 0; }
        if (argv[i][0] == '-' && argv[i][1] && strcmp(argv[i], "--") != 0) { const char *opt = argv[i][1] == '-' ? argv[i] + 2 : argv[i] + 1; fprintf(stderr, "Error: Unrecognized option: '%s'. Please see --help for more details\n", opt); return 1; }
    }
    Editor e; editor_init(&e);
    for (int i = 1; i < argc; i++) { if (strcmp(argv[i], "--") == 0) continue; load_file(&e, argv[i]); break; }
    editor_loop(&e); return 0;
}
