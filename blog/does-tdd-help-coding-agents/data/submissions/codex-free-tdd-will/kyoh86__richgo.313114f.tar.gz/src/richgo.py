#!/usr/bin/env python3
import os
import re
import subprocess
import sys


RESET = "\033[0m"
STYLES = {
    "start": "\033[90m",
    "pass": "\033[32m",
    "fail": "\033[31m\033[1m",
    "skip": "\033[90m",
    "build": "\033[33m\033[1m",
    "covered": "\033[32m",
    "uncovered": "\033[33m\033[1m",
    "file": "\033[36m",
    "line": "\033[35m",
}


DEFAULT_CONFIG = {
    "labelType": "long",
    "leaveTestPrefix": False,
    "coverThreshold": 50,
    "hide": set(),
    "removals": [],
    "styles": {},
}


def load_config() -> dict:
    cfg = {
        "labelType": DEFAULT_CONFIG["labelType"],
        "leaveTestPrefix": DEFAULT_CONFIG["leaveTestPrefix"],
        "coverThreshold": DEFAULT_CONFIG["coverThreshold"],
        "hide": set(),
        "removals": [],
        "styles": dict(STYLES),
    }
    names = [".richstyle", ".richstyle.yaml", ".richstyle.yml"]
    roots = [os.getcwd()] if os.environ.get("RICHGO_LOCAL") == "1" else [os.getcwd(), os.environ.get("GOPATH", ""), os.environ.get("GOROOT", ""), os.environ.get("HOME", "")]
    path = next((os.path.join(root, name) for root in roots for name in names if root and os.path.exists(os.path.join(root, name))), None)
    if not path:
        return cfg
    section = None
    style_to_kind = {
        "buildStyle": "build",
        "startStyle": "start",
        "passStyle": "pass",
        "failStyle": "fail",
        "skipStyle": "skip",
        "passPackageStyle": "passPackage",
        "failPackageStyle": "failPackage",
        "coveredStyle": "covered",
        "uncoveredStyle": "uncovered",
        "fileStyle": "file",
        "lineStyle": "line",
    }
    color = {
        "black": 30,
        "red": 31,
        "green": 32,
        "yellow": 33,
        "blue": 34,
        "magenta": 35,
        "cyan": 36,
        "white": 37,
        "lightBlack": 90,
        "lightRed": 91,
        "lightGreen": 92,
        "lightYellow": 93,
        "lightBlue": 94,
        "lightMagenta": 95,
        "lightCyan": 96,
        "lightWhite": 97,
    }
    attrs = {
        "bold": 1,
        "faint": 2,
        "italic": 3,
        "underline": 4,
        "blinkSlow": 5,
        "blinkRapid": 6,
        "inverse": 7,
        "conceal": 8,
        "crossOut": 9,
        "frame": 51,
        "encircle": 52,
        "overline": 53,
    }
    style_opts: dict[str, dict[str, str]] = {}
    with open(path, encoding="utf-8") as f:
        for raw in f:
            line = raw.rstrip()
            stripped = line.strip()
            if not stripped or stripped.startswith("#"):
                continue
            if not raw.startswith((" ", "\t")):
                section = None
                if ":" not in stripped:
                    continue
                key, value = [p.strip() for p in stripped.split(":", 1)]
                if value == "":
                    section = key
                    if section in style_to_kind:
                        style_opts.setdefault(style_to_kind[section], {})
                    continue
                if key == "labelType":
                    cfg["labelType"] = value
                elif key == "leaveTestPrefix":
                    cfg["leaveTestPrefix"] = value.lower() == "true"
                elif key == "coverThreshold":
                    try:
                        cfg["coverThreshold"] = int(value)
                    except ValueError:
                        pass
            elif section == "removals" and stripped.startswith("-"):
                cfg["removals"].append(stripped[1:].strip().strip('"').strip("'"))
            elif section in style_to_kind and ":" in stripped:
                key, value = [p.strip() for p in stripped.split(":", 1)]
                if key == "hide" and value.lower() == "true":
                    cfg["hide"].add(style_to_kind[section])
                else:
                    style_opts.setdefault(style_to_kind[section], {})[key] = value.strip('"').strip("'")
    for kind, opts in style_opts.items():
        seq = ""
        fg = opts.get("foreground")
        bg = opts.get("background")
        if fg in color:
            seq += f"\033[{color[fg]}m"
        if bg in color:
            seq += f"\033[{color[bg] + 10}m"
        for key, code in attrs.items():
            if opts.get(key, "").lower() == "true":
                seq += f"\033[{code}m"
        if seq:
            cfg["styles"][kind] = seq
    return cfg


def test_name(name: str, leave: bool = False) -> str:
    if leave:
        return name
    return "/".join(part[4:] if part.startswith("Test") else part for part in name.split("/"))


def label(kind: str, cfg: dict) -> str:
    long_labels = {
        "build": "BUILD| ",
        "start": "START| ",
        "pass": "PASS | ",
        "fail": "FAIL | ",
        "skip": "SKIP | ",
        "cover": "COVER| ",
        "line": "     | ",
    }
    short_labels = {
        "build": "!! ",
        "start": ">  ",
        "pass": "o  ",
        "fail": "x  ",
        "skip": "-  ",
        "cover": "%  ",
        "line": "   ",
    }
    if cfg["labelType"] == "none":
        return ""
    if cfg["labelType"] == "short":
        return short_labels[kind]
    return long_labels[kind]


def styled(kind: str, text: str, cfg: dict | None = None) -> str:
    styles = (cfg or {}).get("styles", STYLES)
    return styles[kind] + text + RESET


def format_stream(data: str, cfg: dict | None = None) -> str:
    cfg = cfg or load_config()
    out: list[str] = []
    in_build = False
    for raw in data.splitlines():
        for pattern in cfg["removals"]:
            try:
                raw = re.sub(pattern, "", raw)
            except re.error:
                raw = raw.replace(pattern, "")
        if raw in ("PASS", "FAIL"):
            continue
        m = re.match(r"^#\s+(.+)$", raw)
        if m:
            in_build = True
            if "build" not in cfg["hide"]:
                out.append(cfg["styles"]["build"] + label("build", cfg) + m.group(1))
            continue
        m = re.match(r"^=== RUN\s+(.+)$", raw)
        if m:
            in_build = False
            if "start" in cfg["hide"]:
                continue
            name = test_name(m.group(1), cfg["leaveTestPrefix"])
            indent = "  " if "/" in m.group(1) else ""
            out.append(styled("start", label("start", cfg) + indent + name, cfg))
            continue
        m = re.match(r"^--- (PASS|FAIL|SKIP):\s+(.+?)\s+(\(.+\))$", raw)
        if m:
            in_build = False
            kind = m.group(1).lower()
            if kind in cfg["hide"]:
                continue
            name = test_name(m.group(2), cfg["leaveTestPrefix"])
            indent = "  " if "/" in m.group(2) else ""
            out.append(styled(kind, label(kind, cfg) + indent + name + " " + m.group(3), cfg))
            continue
        m = re.match(r"^coverage:\s+([0-9]+(?:\.[0-9]+)?)%\s+of statements$", raw)
        if m:
            in_build = False
            pct = float(m.group(1))
            filled = int(pct // 10)
            bar = "#" * filled + "_" * (10 - filled)
            kind = "covered" if pct >= cfg["coverThreshold"] else "uncovered"
            if kind in cfg["hide"]:
                continue
            out.append(styled(kind, label("cover", cfg) + f"{m.group(1)}% [{bar}]", cfg))
            continue
        m = re.match(r"^ok\s+(\S+)\s+\S+(?:\s+(coverage: .+))?$", raw)
        if m:
            in_build = False
            suffix = (" " + m.group(2)) if m.group(2) else ""
            if "passPackage" not in cfg["hide"]:
                out.append(styled("pass", label("pass", cfg) + m.group(1) + suffix, cfg))
            continue
        m = re.match(r"^FAIL\s+(.+)$", raw)
        if m:
            in_build = False
            if "failPackage" not in cfg["hide"]:
                out.append(styled("fail", label("fail", cfg) + " " + m.group(1), cfg))
            continue
        m = re.match(r"^\?\s+(\S+)\s+(\[no test files\])$", raw)
        if m:
            in_build = False
            if "skip" not in cfg["hide"]:
                out.append(styled("skip", label("skip", cfg) + m.group(1) + " " + m.group(2), cfg))
            continue
        m = re.match(r"^([^:\s][^:]*):([0-9]+(?::[0-9]+)?):(.*)$", raw)
        if in_build and m and "build" not in cfg["hide"]:
            text = (
                RESET
                + cfg["styles"]["build"]
                + label("line", cfg)
                + cfg["styles"]["file"]
                + m.group(1)
                + RESET
                + cfg["styles"]["line"]
                + ":"
                + m.group(2)
                + RESET
                + cfg["styles"]["build"]
                + ":"
                + m.group(3)
                + RESET
            )
            out.append(text)
            continue
        m = re.match(r"^(\s*)([^:\s][^:]*):([0-9]+(?::[0-9]+)?):(.*)$", raw)
        if m:
            out.append(label("line", cfg) + m.group(1) + cfg["styles"]["file"] + m.group(2) + RESET + cfg["styles"]["line"] + ":" + m.group(3) + RESET + ":" + m.group(4))
            continue
        out.append(label("line", cfg) + raw)
    return "\n".join(out) + ("\n" if out else "")


def testfilter() -> int:
    data = sys.stdin.read()
    if not sys.stdout.isatty():
        sys.stdout.write(data)
        return 0
    sys.stdout.write(format_stream(data))
    return 0


def main(argv: list[str]) -> int:
    if len(argv) > 1 and argv[1] == "testfilter":
        return testfilter()
    if len(argv) > 1 and argv[1] == "test":
        if sys.stdout.isatty():
            proc = subprocess.run(["go", *argv[1:]], stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
            sys.stdout.write(format_stream(proc.stdout))
        else:
            proc = subprocess.run(["go", *argv[1:]])
        return proc.returncode
    proc = subprocess.run(["go", *argv[1:]])
    return proc.returncode


if __name__ == "__main__":
    raise SystemExit(main(sys.argv))
