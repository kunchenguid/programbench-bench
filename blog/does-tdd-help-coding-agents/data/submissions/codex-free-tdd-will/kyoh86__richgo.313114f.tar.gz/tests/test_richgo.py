import os, pty, subprocess, sys, unittest

ROOT = os.path.dirname(os.path.dirname(__file__))
SCRIPT = os.path.join(ROOT, "src", "richgo.py")

def run_filter(input_text, files=None, tty=True):
    cwd = ROOT
    env = os.environ.copy()
    env["RICHGO_LOCAL"] = "1"
    if files:
        import tempfile
        d = tempfile.TemporaryDirectory()
        cwd = d.name
        for name, content in files.items():
            with open(os.path.join(cwd, name), "w", encoding="utf-8") as f:
                f.write(content)
        run_filter._tmp = d
    cmd = [sys.executable, SCRIPT, "testfilter"]
    if tty:
        out = pty.spawn(cmd, lambda fd: os.write(fd, input_text.encode()) or b"")
        raise RuntimeError("pty.spawn path unsupported")
    proc = subprocess.run(cmd, input=input_text, text=True, capture_output=True, cwd=cwd, env=env)
    return proc.stdout

def run_filter_tty(input_text, files=None):
    cwd = ROOT
    env = os.environ.copy()
    env["RICHGO_LOCAL"] = "1"
    import tempfile
    tmp = tempfile.TemporaryDirectory()
    cwd = tmp.name
    with open(os.path.join(cwd, "input.txt"), "w", encoding="utf-8") as f:
        f.write(input_text)
    if files:
        for name, content in files.items():
            with open(os.path.join(cwd, name), "w", encoding="utf-8") as f:
                f.write(content)
    proc = subprocess.run(
        ["script", "-q", "-c", f"cat input.txt | {sys.executable} {SCRIPT} testfilter", "/dev/null"],
        text=True,
        capture_output=True,
        cwd=cwd,
        env=env,
    )
    tmp.cleanup()
    return proc.stdout.replace("\r\n", "\n")

class RichGoBehavior(unittest.TestCase):
    def test_non_tty_testfilter_passthrough(self):
        sample = "=== RUN   TestFoo\n--- PASS: TestFoo (0.00s)\nPASS\n"
        proc = subprocess.run([sys.executable, SCRIPT, "testfilter"], input=sample, text=True, capture_output=True)
        self.assertEqual(proc.stdout, sample)

    def test_tty_formats_run_and_pass_lines(self):
        out = run_filter_tty("=== RUN   TestFoo\n--- PASS: TestFoo (0.00s)\nPASS\n")
        self.assertEqual(out, "\x1b[90mSTART| Foo\x1b[0m\n\x1b[32mPASS | Foo (0.00s)\x1b[0m\n")

    def test_tty_formats_coverage_with_default_threshold(self):
        out = run_filter_tty("coverage: 80.5% of statements\ncoverage: 12.3% of statements\n")
        self.assertEqual(out, "\x1b[32mCOVER| 80.5% [########__]\x1b[0m\n\x1b[33m\x1b[1mCOVER| 12.3% [#_________]\x1b[0m\n")

    def test_tty_formats_package_result_lines(self):
        out = run_filter_tty("ok  example.com/foo 0.001s coverage: 80.5% of statements\nFAIL example.com/bar 0.002s\n?   example.com/none [no test files]\n")
        self.assertEqual(out, "\x1b[32mPASS | example.com/foo coverage: 80.5% of statements\x1b[0m\n\x1b[31m\x1b[1mFAIL |  example.com/bar 0.002s\x1b[0m\n\x1b[90mSKIP | example.com/none [no test files]\x1b[0m\n")

    def test_tty_honors_core_config_options(self):
        cfg = "labelType: short\nleaveTestPrefix: true\ncoverThreshold: 80\nstartStyle:\n  hide: true\n"
        out = run_filter_tty("=== RUN   TestFoo\n--- PASS: TestFoo (0.01s)\ncoverage: 79.9% of statements\n", {".richstyle": cfg})
        self.assertEqual(out, "\x1b[32mo  TestFoo (0.01s)\x1b[0m\n\x1b[33m\x1b[1m%  79.9% [#######___]\x1b[0m\n")

    def test_tty_formats_build_errors(self):
        out = run_filter_tty("# example.com/foo\nfoo.go:10:2: undefined: x\nFAIL example.com/foo [build failed]\n")
        self.assertEqual(out, "\x1b[33m\x1b[1mBUILD| example.com/foo\n\x1b[0m\x1b[33m\x1b[1m     | \x1b[36mfoo.go\x1b[0m\x1b[35m:10:2\x1b[0m\x1b[33m\x1b[1m: undefined: x\x1b[0m\n\x1b[31m\x1b[1mFAIL |  example.com/foo [build failed]\x1b[0m\n")

    def test_tty_applies_removal_patterns(self):
        out = run_filter_tty("noise here\nkeep here\n", {".richstyle": "removals:\n  - noise\n"})
        self.assertEqual(out, "     |  here\n     | keep here\n")

    def test_tty_honors_style_color_and_attributes(self):
        cfg = "passStyle:\n  foreground: blue\n  bold: true\n  underline: true\n"
        out = run_filter_tty("--- PASS: TestFoo (0.01s)\n", {".richstyle": cfg})
        self.assertEqual(out, "\x1b[34m\x1b[1m\x1b[4mPASS | Foo (0.01s)\x1b[0m\n")

if __name__ == "__main__":
    unittest.main()
