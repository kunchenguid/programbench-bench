#!/bin/bash
set -e
cp src/richgo.py executable
chmod +x executable
