#!/bin/bash
set -e
go build -o executable .
chmod +x executable
