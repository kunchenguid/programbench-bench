package main

import (
	"bytes"
	"crypto/rand"
	"crypto/sha1"
	"crypto/sha256"
	"crypto/sha512"
	"encoding/base64"
	"encoding/csv"
	"encoding/hex"
	"encoding/json"
	"errors"
	"flag"
	"fmt"
	"io"
	"math"
	mrand "math/rand"
	"net"
	"net/netip"
	"net/url"
	"os"
	"path"
	"path/filepath"
	"reflect"
	"regexp"
	"sort"
	"strconv"
	"strings"
	"text/template"
	"time"
)

type multiFlag []string

func (m *multiFlag) String() string { return strings.Join(*m, ",") }
func (m *multiFlag) Set(v string) error {
	*m = append(*m, v)
	return nil
}

type app struct {
	datasources map[string]string
	context     map[string]any
	left, right string
	tmplPath    string
	root        *template.Template
}

func main() {
	os.Exit(run(os.Args[1:], os.Stdin, os.Stdout, os.Stderr))
}

func run(args []string, stdin io.Reader, stdout, stderr io.Writer) int {
	for _, arg := range args {
		if arg == "-h" || arg == "--help" {
			fmt.Fprint(stdout, helpText)
			return 0
		}
		if arg == "-v" || arg == "--version" {
			fmt.Fprintln(stdout, "gomplate version 0.0.0")
			return 0
		}
	}
	var in, inputDir, outputDir, chmod, missingKey, left, right, outputMap string
	var files, outs, datasources, contexts, templates, excludes, includes, excludeProcessing multiFlag
	var showVersion bool
	fs := flag.NewFlagSet("gomplate", flag.ContinueOnError)
	fs.SetOutput(stderr)
	fs.Var(&datasources, "d", "")
	fs.Var(&datasources, "datasource", "")
	fs.Var(&contexts, "c", "")
	fs.Var(&contexts, "context", "")
	fs.Var(&files, "f", "")
	fs.Var(&files, "file", "")
	fs.StringVar(&in, "i", "", "")
	fs.StringVar(&in, "in", "", "")
	fs.Var(&outs, "o", "")
	fs.Var(&outs, "out", "")
	fs.Var(&templates, "t", "")
	fs.Var(&templates, "template", "")
	fs.StringVar(&inputDir, "input-dir", "", "")
	fs.StringVar(&outputDir, "output-dir", ".", "")
	fs.StringVar(&outputMap, "output-map", "", "")
	fs.Var(&excludes, "exclude", "")
	fs.Var(&includes, "include", "")
	fs.Var(&excludeProcessing, "exclude-processing", "")
	fs.StringVar(&chmod, "chmod", "", "")
	fs.StringVar(&missingKey, "missing-key", "error", "")
	fs.StringVar(&left, "left-delim", "{{", "")
	fs.StringVar(&right, "right-delim", "}}", "")
	fs.BoolVar(&showVersion, "v", false, "")
	fs.BoolVar(&showVersion, "version", false, "")
	fs.Bool("V", false, "")
	fs.Bool("verbose", false, "")
	fs.String("config", ".gomplate.yaml", "")
	fs.Bool("experimental", false, "")
	var headers, plugins multiFlag
	fs.Var(&headers, "H", "")
	fs.Var(&headers, "datasource-header", "")
	fs.Var(&plugins, "plugin", "")
	fs.Bool("exec-pipe", false, "")
	fs.Usage = func() { fmt.Fprint(stderr, helpText) }
	if err := fs.Parse(args); err != nil {
		if errors.Is(err, flag.ErrHelp) {
			return 0
		}
		return 1
	}
	if showVersion {
		fmt.Fprintln(stdout, "gomplate version 0.0.0")
		return 0
	}
	if len(files) == 0 {
		files = append(files, "-")
	}
	a := &app{datasources: map[string]string{}, context: map[string]any{}, left: left, right: right}
	for _, d := range datasources {
		name, loc := datasourceName(d)
		a.datasources[name] = loc
	}
	for _, c := range contexts {
		name, loc := datasourceName(c)
		v, err := a.load(loc)
		if err != nil {
			fmt.Fprintln(stderr, err)
			return 1
		}
		if name == "." {
			if m, ok := v.(map[string]any); ok {
				a.context = m
			} else {
				a.context["."] = v
			}
		} else {
			a.context[name] = v
		}
	}
	a.context["Env"] = envMap()
	a.context["env"] = envNS{}

	if inputDir != "" {
		if err := a.processDir(inputDir, outputDir, outputMap, chmod, excludes, includes, excludeProcessing); err != nil {
			fmt.Fprintln(stderr, err)
			return 1
		}
		return 0
	}
	if in != "" {
		files = multiFlag{"<arg>"}
	}
	if len(outs) == 0 {
		outs = multiFlag{"-"}
	}
	if len(outs) == 1 && len(files) > 1 {
		for len(outs) < len(files) {
			outs = append(outs, "-")
		}
	}
	if len(outs) != len(files) {
		fmt.Fprintln(stderr, "number of --out must match number of --file")
		return 1
	}
	for i, f := range files {
		var text string
		var err error
		a.tmplPath = f
		if in != "" {
			text = in
		} else if f == "-" {
			b, e := io.ReadAll(stdin)
			err = e
			text = string(b)
		} else {
			b, e := os.ReadFile(f)
			err = e
			text = string(b)
		}
		if err != nil {
			fmt.Fprintln(stderr, err)
			return 1
		}
		res, err := a.render(text, f, missingKey, templates)
		if err != nil {
			fmt.Fprintln(stderr, err)
			return 1
		}
		if outs[i] == "-" {
			fmt.Fprint(stdout, res)
		} else {
			if err := os.MkdirAll(filepath.Dir(outs[i]), 0755); err != nil && filepath.Dir(outs[i]) != "." {
				fmt.Fprintln(stderr, err)
				return 1
			}
			mode := os.FileMode(0644)
			if chmod != "" {
				if n, e := strconv.ParseUint(chmod, 8, 32); e == nil {
					mode = os.FileMode(n)
				}
			}
			if err := os.WriteFile(outs[i], []byte(res), mode); err != nil {
				fmt.Fprintln(stderr, err)
				return 1
			}
		}
	}
	return 0
}

func (a *app) render(text, name, missingKey string, extra []string) (string, error) {
	opt := "missingkey=error"
	if missingKey == "default" || missingKey == "invalid" {
		opt = "missingkey=default"
	} else if missingKey == "zero" {
		opt = "missingkey=zero"
	}
	t := template.New(name).Delims(a.left, a.right).Option(opt).Funcs(a.funcs())
	for _, spec := range extra {
		n, p := datasourceName(spec)
		b, err := os.ReadFile(p)
		if err != nil {
			return "", err
		}
		if _, err := t.New(n).Parse(string(b)); err != nil {
			return "", err
		}
	}
	t, err := t.Parse(text)
	if err != nil {
		return "", err
	}
	a.root = t
	var buf bytes.Buffer
	err = t.Execute(&buf, a.context)
	return buf.String(), err
}

func (a *app) funcs() template.FuncMap {
	m := mathNS{}
	c := collNS{}
	d := dataNS{a: a}
	s := stringsNS{}
	f := fileNS{}
	fp := filepathNS{}
	p := pathNS{}
	rx := regexpNS{}
	cv := convNS{}
	b64 := base64NS{}
	nn := netNS{}
	cr := cryptoNS{}
	tm := timeNS{}
	rd := randomNS{}
	ts := testNS{}
	tn := tmplNS{a: a}
	return template.FuncMap{
		"math": func() mathNS { return m }, "add": m.Add, "mul": m.Mul, "div": m.Div, "sub": m.Sub, "pow": m.Pow, "rem": m.Rem, "seq": m.Seq,
		"coll": func() collNS { return c }, "dict": c.Dict, "has": c.Has, "keys": c.Keys, "values": c.Values, "append": c.Append, "prepend": c.Prepend, "uniq": c.Uniq, "flatten": c.Flatten, "reverse": c.Reverse, "sort": c.Sort, "merge": c.Merge, "set": c.Set, "unset": c.Unset,
		"data": func() dataNS { return d }, "json": d.JSON, "jsonArray": d.JSONArray, "yaml": d.YAML, "yamlArray": d.YAMLArray, "toJSON": d.ToJSON, "toJSONPretty": d.ToJSONPretty, "toYAML": d.ToYAML, "ds": d.Datasource, "datasource": d.Datasource, "include": d.Include,
		"env": func() envNS { return envNS{} }, "getenv": envNS{}.Getenv,
		"strings": func() stringsNS { return s }, "indent": s.Indent, "quote": s.Quote, "squote": s.Squote, "shellQuote": s.ShellQuote, "replaceAll": s.ReplaceAll, "toLower": s.ToLower, "toUpper": s.ToUpper, "title": s.Title, "trimSpace": s.TrimSpace,
		"file": func() fileNS { return f }, "filepath": func() filepathNS { return fp }, "path": func() pathNS { return p }, "regexp": func() regexpNS { return rx },
		"conv": func() convNS { return cv }, "bool": cv.Bool, "default": cv.Default, "join": cv.Join, "urlParse": cv.URL,
		"base64": func() base64NS { return b64 }, "net": func() netNS { return nn }, "crypto": func() cryptoNS { return cr }, "time": func() timeNS { return tm }, "random": func() randomNS { return rd },
		"test": func() testNS { return ts }, "assert": ts.Assert, "fail": ts.Fail, "kind": ts.Kind, "isKind": ts.IsKind, "required": ts.Required, "ternary": ts.Ternary,
		"tmpl": func() tmplNS { return tn }, "tpl": tn.Inline,
	}
}

type mathNS struct{}

func (mathNS) Add(v ...any) any {
	if anyFloat(v...) {
		var x float64
		for _, n := range v {
			x += toFloat(n)
		}
		return cleanFloat(x)
	}
	var x int64
	for _, n := range v {
		x += toInt(n)
	}
	return x
}
func (mathNS) Sub(a, b any) any {
	if anyFloat(a, b) {
		return cleanFloat(toFloat(a) - toFloat(b))
	}
	return toInt(a) - toInt(b)
}
func (mathNS) Mul(v ...any) any {
	if anyFloat(v...) {
		x := 1.0
		for _, n := range v {
			x *= toFloat(n)
		}
		return cleanFloat(x)
	}
	x := int64(1)
	for _, n := range v {
		x *= toInt(n)
	}
	return x
}
func (mathNS) Div(a, b any) (float64, error) {
	d := toFloat(b)
	if d == 0 {
		return 0, errors.New("division by zero")
	}
	return toFloat(a) / d, nil
}
func (mathNS) Rem(a, b any) (int64, error) {
	d := toInt(b)
	if d == 0 {
		return 0, errors.New("division by zero")
	}
	return toInt(a) % d, nil
}
func (mathNS) Pow(a, b any) any { return cleanFloat(math.Pow(toFloat(a), toFloat(b))) }
func (mathNS) Abs(n any) any {
	if anyFloat(n) {
		return math.Abs(toFloat(n))
	}
	x := toInt(n)
	if x < 0 {
		return -x
	}
	return x
}
func (mathNS) Ceil(n any) float64  { return math.Ceil(toFloat(n)) }
func (mathNS) Floor(n any) float64 { return math.Floor(toFloat(n)) }
func (mathNS) Round(n any) float64 { return math.Round(toFloat(n)) }
func (mathNS) Max(v ...any) any {
	m := toFloat(v[0])
	for _, n := range v[1:] {
		if x := toFloat(n); x > m {
			m = x
		}
	}
	return cleanFloat(m)
}
func (mathNS) Min(v ...any) any {
	m := toFloat(v[0])
	for _, n := range v[1:] {
		if x := toFloat(n); x < m {
			m = x
		}
	}
	return cleanFloat(m)
}
func (mathNS) IsFloat(n any) bool {
	if _, ok := n.(float64); ok {
		return true
	}
	s := fmt.Sprint(n)
	return strings.ContainsAny(s, ".eENaInf") && !math.IsNaN(toFloat(n)) || strings.EqualFold(s, "nan") || strings.Contains(strings.ToLower(s), "inf")
}
func (mathNS) IsInt(n any) bool {
	_, err := strconv.ParseInt(cleanNum(fmt.Sprint(n)), 0, 64)
	return err == nil
}
func (mathNS) IsNum(n any) bool {
	return !math.IsNaN(toFloat(n)) || strings.EqualFold(fmt.Sprint(n), "nan")
}
func (mathNS) Seq(args ...any) []int64 {
	start, end, step := int64(0), int64(0), int64(1)
	if len(args) == 1 {
		end = toInt(args[0])
		if end == 0 {
			return []int64{}
		}
		start = 1
	} else if len(args) >= 2 {
		start, end = toInt(args[0]), toInt(args[1])
		if len(args) >= 3 {
			step = toInt(args[2])
		}
	}
	if step == 0 {
		return []int64{}
	}
	if end < start && step > 0 {
		step = -step
	}
	if end > start && step < 0 {
		step = -step
	}
	end -= (end - start) % step
	seq := []int64{start}
	for seq[len(seq)-1] != end {
		seq = append(seq, seq[len(seq)-1]+step)
	}
	return seq
}

type collNS struct{}

func (collNS) Slice(v ...any) []any { return v }
func (collNS) GoSlice(v any, start, end any) any {
	r := []rune(fmt.Sprint(v))
	return string(r[toInt(start):toInt(end)])
}
func (collNS) Dict(v ...any) map[string]any {
	m := map[string]any{}
	for i := 0; i+1 < len(v); i += 2 {
		m[fmt.Sprint(v[i])] = v[i+1]
	}
	return m
}
func (collNS) Has(coll, val any) bool {
	if val != nil && (isSlice(val) || reflect.ValueOf(val).Kind() == reflect.Map) {
		coll, val = val, coll
	}
	rv := reflect.ValueOf(coll)
	if rv.Kind() == reflect.Map {
		return rv.MapIndex(reflect.ValueOf(fmt.Sprint(val))).IsValid()
	}
	if rv.Kind() == reflect.Slice || rv.Kind() == reflect.Array {
		for i := 0; i < rv.Len(); i++ {
			if reflect.DeepEqual(rv.Index(i).Interface(), val) || fmt.Sprint(rv.Index(i).Interface()) == fmt.Sprint(val) {
				return true
			}
		}
	}
	return false
}
func (collNS) Index(k, v any) any {
	rv := reflect.ValueOf(v)
	if rv.Kind() == reflect.Map {
		mv := rv.MapIndex(reflect.ValueOf(fmt.Sprint(k)))
		if mv.IsValid() {
			return mv.Interface()
		}
		return nil
	}
	if rv.Kind() == reflect.Slice || rv.Kind() == reflect.Array {
		i := int(toInt(k))
		if i >= 0 && i < rv.Len() {
			return rv.Index(i).Interface()
		}
	}
	return nil
}
func (collNS) Keys(ms ...any) []string {
	set := map[string]bool{}
	for _, m := range ms {
		rv := reflect.ValueOf(m)
		if rv.Kind() == reflect.Map {
			for _, k := range rv.MapKeys() {
				set[fmt.Sprint(k.Interface())] = true
			}
		}
	}
	out := make([]string, 0, len(set))
	for k := range set {
		out = append(out, k)
	}
	sort.Strings(out)
	return out
}
func (collNS) Values(ms ...any) []any {
	var out []any
	for _, m := range ms {
		rv := reflect.ValueOf(m)
		if rv.Kind() == reflect.Map {
			for _, k := range rv.MapKeys() {
				out = append(out, rv.MapIndex(k).Interface())
			}
		}
	}
	return out
}
func (collNS) Append(item, list any) []any  { return append(toSlice(list), item) }
func (collNS) Prepend(item, list any) []any { return append([]any{item}, toSlice(list)...) }
func (collNS) Reverse(list any) []any {
	s := toSlice(list)
	for i, j := 0, len(s)-1; i < j; i, j = i+1, j-1 {
		s[i], s[j] = s[j], s[i]
	}
	return s
}
func (collNS) Uniq(list any) []any {
	var out []any
	seen := map[string]bool{}
	for _, v := range toSlice(list) {
		k := fmt.Sprintf("%#v", v)
		if !seen[k] {
			seen[k] = true
			out = append(out, v)
		}
	}
	return out
}
func (collNS) Flatten(args ...any) []any {
	depth := -1
	v := args[0]
	if len(args) == 2 {
		depth = int(toInt(args[0]))
		v = args[1]
	}
	var out []any
	var walk func(any, int)
	walk = func(x any, d int) {
		rv := reflect.ValueOf(x)
		if (rv.Kind() == reflect.Slice || rv.Kind() == reflect.Array) && d != 0 {
			for i := 0; i < rv.Len(); i++ {
				walk(rv.Index(i).Interface(), d-1)
			}
			return
		}
		out = append(out, x)
	}
	walk(v, depth)
	return out
}
func (collNS) Sort(args ...any) []any {
	list := args[len(args)-1]
	key := ""
	if len(args) > 1 {
		key = fmt.Sprint(args[0])
	}
	s := toSlice(list)
	sort.SliceStable(s, func(i, j int) bool {
		a, b := s[i], s[j]
		if key != "" {
			a = mapGet(a, key)
			b = mapGet(b, key)
		}
		return fmt.Sprint(a) < fmt.Sprint(b)
	})
	return s
}
func (collNS) Merge(ms ...any) map[string]any {
	out := map[string]any{}
	for _, m := range ms {
		for k, v := range toMap(m) {
			out[k] = v
		}
	}
	return out
}
func (collNS) Pick(keys any, m any) map[string]any {
	out := map[string]any{}
	src := toMap(m)
	for _, k := range toSlice(keys) {
		if v, ok := src[fmt.Sprint(k)]; ok {
			out[fmt.Sprint(k)] = v
		}
	}
	return out
}
func (collNS) Omit(keys any, m any) map[string]any {
	out := toMap(m)
	for _, k := range toSlice(keys) {
		delete(out, fmt.Sprint(k))
	}
	return out
}
func (collNS) Set(k, v, m any) map[string]any { out := toMap(m); out[fmt.Sprint(k)] = v; return out }
func (collNS) Unset(k, m any) map[string]any  { out := toMap(m); delete(out, fmt.Sprint(k)); return out }

type convNS struct{}

func (convNS) Bool(v any) bool   { return toBool(v) }
func (convNS) ToBool(v any) bool { return toBool(v) }
func (convNS) ToBools(v ...any) []bool {
	out := []bool{}
	for _, x := range v {
		out = append(out, toBool(x))
	}
	return out
}
func (convNS) Default(def, v any) any {
	if empty(v) {
		return def
	}
	return v
}
func (convNS) Join(args ...any) string {
	sep := ""
	list := args[0]
	if len(args) > 1 {
		if isSlice(args[0]) {
			sep = fmt.Sprint(args[1])
		} else {
			sep = fmt.Sprint(args[0])
			list = args[1]
		}
	}
	parts := []string{}
	for _, v := range toSlice(list) {
		parts = append(parts, fmt.Sprint(v))
	}
	return strings.Join(parts, sep)
}
func (convNS) URL(s any) (*url.URL, error) { return url.Parse(fmt.Sprint(s)) }
func (convNS) ParseInt(s any, base, bit any) (int64, error) {
	return strconv.ParseInt(fmt.Sprint(s), int(toInt(base)), int(toInt(bit)))
}
func (convNS) ParseFloat(s any, bit any) (float64, error) {
	return strconv.ParseFloat(fmt.Sprint(s), int(toInt(bit)))
}
func (convNS) ParseUint(s any, base, bit any) (uint64, error) {
	return strconv.ParseUint(fmt.Sprint(s), int(toInt(base)), int(toInt(bit)))
}
func (convNS) Atoi(s any) (int, error) { return strconv.Atoi(fmt.Sprint(s)) }
func (convNS) ToInt64(v any) int64     { return toInt(v) }
func (convNS) ToInt(v any) int         { return int(toInt(v)) }
func (convNS) ToInt64s(v ...any) []int64 {
	out := []int64{}
	for _, x := range v {
		out = append(out, toInt(x))
	}
	return out
}
func (convNS) ToInts(v ...any) []int {
	out := []int{}
	for _, x := range v {
		out = append(out, int(toInt(x)))
	}
	return out
}
func (convNS) ToFloat64(v any) float64 { return toFloat(v) }
func (convNS) ToFloat64s(v ...any) []float64 {
	out := []float64{}
	for _, x := range v {
		out = append(out, toFloat(x))
	}
	return out
}
func (convNS) ToString(v any) string {
	if v == nil {
		return ""
	}
	if b, ok := v.([]byte); ok {
		return string(b)
	}
	return fmt.Sprint(v)
}
func (convNS) ToStrings(v ...any) []string {
	out := []string{}
	for _, x := range v {
		out = append(out, convNS{}.ToString(x))
	}
	return out
}

type stringsNS struct{}

func (stringsNS) Contains(substr, s string) bool  { return strings.Contains(s, substr) }
func (stringsNS) HasPrefix(prefix, s string) bool { return strings.HasPrefix(s, prefix) }
func (stringsNS) HasSuffix(suffix, s string) bool { return strings.HasSuffix(s, suffix) }
func (stringsNS) Indent(n any, s any) string {
	pad := strings.Repeat(" ", int(toInt(n)))
	lines := strings.Split(fmt.Sprint(s), "\n")
	for i := range lines {
		if lines[i] != "" {
			lines[i] = pad + lines[i]
		}
	}
	return strings.Join(lines, "\n")
}
func (stringsNS) SkipLines(n any, s any) string {
	lines := strings.Split(fmt.Sprint(s), "\n")
	i := int(toInt(n))
	if i >= len(lines) {
		return ""
	}
	return strings.Join(lines[i:], "\n")
}
func (stringsNS) Split(sep, s string) []string { return strings.Split(s, sep) }
func (stringsNS) SplitN(sep string, n any, s string) []string {
	return strings.SplitN(s, sep, int(toInt(n)))
}
func (stringsNS) Quote(v any) string { return strconv.Quote(fmt.Sprint(v)) }
func (stringsNS) Squote(v any) string {
	return "'" + strings.ReplaceAll(fmt.Sprint(v), "'", "'\\''") + "'"
}
func (stringsNS) ShellQuote(v any) string {
	rv := reflect.ValueOf(v)
	if rv.Kind() == reflect.Slice || rv.Kind() == reflect.Array {
		ps := []string{}
		for i := 0; i < rv.Len(); i++ {
			ps = append(ps, stringsNS{}.Squote(rv.Index(i).Interface()))
		}
		return strings.Join(ps, " ")
	}
	return stringsNS{}.Squote(v)
}
func (stringsNS) Repeat(n any, s any) string           { return strings.Repeat(fmt.Sprint(s), int(toInt(n))) }
func (stringsNS) ReplaceAll(old, new, s string) string { return strings.ReplaceAll(s, old, new) }
func (stringsNS) Slug(s string) string {
	x := strings.ToLower(s)
	re := regexp.MustCompile(`[^a-z0-9]+`)
	x = strings.Trim(re.ReplaceAllString(x, "-"), "-")
	return x
}
func (stringsNS) Title(s string) string {
	return strings.Title(s)
}
func (stringsNS) ToLower(s string) string            { return strings.ToLower(s) }
func (stringsNS) ToUpper(s string) string            { return strings.ToUpper(s) }
func (stringsNS) Trim(cut, s string) string          { return strings.Trim(s, cut) }
func (stringsNS) TrimLeft(cut, s string) string      { return strings.TrimLeft(s, cut) }
func (stringsNS) TrimRight(cut, s string) string     { return strings.TrimRight(s, cut) }
func (stringsNS) TrimPrefix(prefix, s string) string { return strings.TrimPrefix(s, prefix) }
func (stringsNS) TrimSuffix(suffix, s string) string { return strings.TrimSuffix(s, suffix) }
func (stringsNS) TrimSpace(s string) string          { return strings.TrimSpace(s) }
func (stringsNS) Trunc(n any, s string) string {
	r := []rune(s)
	if int(toInt(n)) < len(r) {
		return string(r[:toInt(n)])
	}
	return s
}
func (stringsNS) Abbrev(args ...any) string {
	var s string
	max := 0
	if len(args) == 2 {
		max = int(toInt(args[0]))
		s = fmt.Sprint(args[1])
	} else {
		max = int(toInt(args[len(args)-2]))
		s = fmt.Sprint(args[len(args)-1])
	}
	r := []rune(s)
	if len(r) <= max {
		return s
	}
	if max <= 3 {
		return string(r[:max])
	}
	return string(r[:max-3]) + "..."
}
func (stringsNS) RuneCount(s string) int    { return len([]rune(s)) }
func (stringsNS) CamelCase(s string) string { return caseWords(s, "", true) }
func (stringsNS) SnakeCase(s string) string { return caseWords(s, "_", false) }
func (stringsNS) KebabCase(s string) string { return caseWords(s, "-", false) }
func (stringsNS) WordWrap(args ...any) string {
	width := int(toInt(args[0]))
	sep := "\n"
	text := fmt.Sprint(args[len(args)-1])
	if len(args) == 3 {
		sep = fmt.Sprint(args[1])
	}
	var lines []string
	for len(text) > width {
		i := strings.LastIndex(text[:width], " ")
		if i <= 0 {
			i = width
		}
		lines = append(lines, strings.TrimSpace(text[:i]))
		text = strings.TrimSpace(text[i:])
	}
	lines = append(lines, text)
	return strings.Join(lines, sep)
}

type envNS struct{}

func (envNS) Getenv(name string, def ...string) string {
	if v, ok := os.LookupEnv(name); ok {
		return v
	}
	if len(def) > 0 {
		return def[0]
	}
	return ""
}
func (envNS) Env() map[string]string    { return envMap() }
func (envNS) HasEnv(name string) bool   { _, ok := os.LookupEnv(name); return ok }
func (envNS) ExpandEnv(s string) string { return os.ExpandEnv(s) }

type base64NS struct{}

func (base64NS) Encode(v any) string { return base64.StdEncoding.EncodeToString([]byte(fmt.Sprint(v))) }
func (base64NS) Decode(s any) (string, error) {
	b, e := base64.StdEncoding.DecodeString(fmt.Sprint(s))
	return string(b), e
}
func (base64NS) DecodeBytes(s any) ([]byte, error) {
	return base64.StdEncoding.DecodeString(fmt.Sprint(s))
}

type dataNS struct{ a *app }

func (d dataNS) Datasource(name string) (any, error) { return d.a.load(d.a.datasources[name]) }
func (d dataNS) Include(name string) (string, error) {
	v, err := d.a.loadRaw(d.a.datasources[name])
	return string(v), err
}
func (d dataNS) DatasourceExists(name string) bool { _, ok := d.a.datasources[name]; return ok }
func (d dataNS) DatasourceReachable(name string) bool {
	_, err := d.a.loadRaw(d.a.datasources[name])
	return err == nil
}
func (d dataNS) ListDatasources() []string {
	ks := []string{}
	for k := range d.a.datasources {
		ks = append(ks, k)
	}
	sort.Strings(ks)
	return ks
}
func (d dataNS) DefineDatasource(name, loc string) string { d.a.datasources[name] = loc; return "" }
func (dataNS) JSON(s any) (any, error) {
	var v any
	err := json.Unmarshal([]byte(fmt.Sprint(s)), &v)
	return v, err
}
func (dataNS) JSONArray(s any) ([]any, error) {
	var v []any
	err := json.Unmarshal([]byte(fmt.Sprint(s)), &v)
	return v, err
}
func (dataNS) YAML(s any) (any, error) { return parseSimpleYAML(fmt.Sprint(s)), nil }
func (dataNS) YAMLArray(s any) ([]any, error) {
	v := parseSimpleYAML(fmt.Sprint(s))
	if a, ok := v.([]any); ok {
		return a, nil
	}
	return nil, nil
}
func (dataNS) CSV(s any) ([][]string, error) {
	return csv.NewReader(strings.NewReader(fmt.Sprint(s))).ReadAll()
}
func (dataNS) CSVByRow(s any) ([]map[string]string, error) {
	rows, err := dataNS{}.CSV(s)
	if err != nil || len(rows) == 0 {
		return nil, err
	}
	out := []map[string]string{}
	head := rows[0]
	for _, r := range rows[1:] {
		m := map[string]string{}
		for i, h := range head {
			if i < len(r) {
				m[h] = r[i]
			}
		}
		out = append(out, m)
	}
	return out, nil
}
func (dataNS) CSVByColumn(s any) (map[string][]string, error) {
	rows, err := dataNS{}.CSV(s)
	if err != nil || len(rows) == 0 {
		return nil, err
	}
	out := map[string][]string{}
	head := rows[0]
	for _, h := range head {
		out[h] = []string{}
	}
	for _, r := range rows[1:] {
		for i, h := range head {
			if i < len(r) {
				out[h] = append(out[h], r[i])
			}
		}
	}
	return out, nil
}
func (dataNS) ToJSON(v any) (string, error) { b, e := json.Marshal(v); return string(b), e }
func (dataNS) ToJSONPretty(args ...any) (string, error) {
	indent := "  "
	v := args[0]
	if len(args) == 2 {
		indent = fmt.Sprint(args[0])
		v = args[1]
	}
	b, e := json.MarshalIndent(v, "", indent)
	return string(b), e
}
func (dataNS) ToYAML(v any) string { return toYAML(v, 0) }
func (dataNS) ToTOML(v any) string { return toTOML(v) }
func (dataNS) ToCSV(v any) (string, error) {
	var buf bytes.Buffer
	w := csv.NewWriter(&buf)
	for _, row := range toSlice(v) {
		ss := []string{}
		for _, c := range toSlice(row) {
			ss = append(ss, fmt.Sprint(c))
		}
		_ = w.Write(ss)
	}
	w.Flush()
	return buf.String(), w.Error()
}

func (a *app) load(loc string) (any, error) {
	b, err := a.loadRaw(loc)
	if err != nil {
		return nil, err
	}
	s := string(b)
	l := strings.ToLower(loc)
	if strings.HasSuffix(l, ".json") || strings.HasPrefix(strings.TrimSpace(s), "{") || strings.HasPrefix(strings.TrimSpace(s), "[") {
		var v any
		if err := json.Unmarshal(b, &v); err == nil {
			return v, nil
		}
	}
	if strings.HasSuffix(l, ".yaml") || strings.HasSuffix(l, ".yml") {
		return parseSimpleYAML(s), nil
	}
	return s, nil
}
func (a *app) loadRaw(loc string) ([]byte, error) {
	if strings.HasPrefix(loc, "env:///") {
		return []byte(os.Getenv(strings.TrimPrefix(loc, "env:///"))), nil
	}
	if strings.HasPrefix(loc, "file://") {
		loc = strings.TrimPrefix(loc, "file://")
	}
	return os.ReadFile(loc)
}

type fileNS struct{}

func (fileNS) Exists(p string) bool          { _, err := os.Stat(p); return err == nil }
func (fileNS) IsDir(p string) bool           { st, err := os.Stat(p); return err == nil && st.IsDir() }
func (fileNS) Read(p string) (string, error) { b, e := os.ReadFile(p); return string(b), e }
func (fileNS) ReadDir(p string) ([]string, error) {
	ents, e := os.ReadDir(p)
	if e != nil {
		return nil, e
	}
	out := []string{}
	for _, x := range ents {
		out = append(out, x.Name())
	}
	sort.Strings(out)
	return out, nil
}
func (fileNS) Stat(p string) (os.FileInfo, error) { return os.Stat(p) }
func (fileNS) Walk(p string) ([]string, error) {
	out := []string{}
	e := filepath.WalkDir(p, func(path string, d os.DirEntry, e error) error {
		if e == nil {
			out = append(out, path)
		}
		return e
	})
	return out, e
}
func (fileNS) Write(p, s string) (string, error) { return "", os.WriteFile(p, []byte(s), 0644) }

type filepathNS struct{}

func (filepathNS) Base(s string) string                     { return filepath.Base(s) }
func (filepathNS) Clean(s string) string                    { return filepath.Clean(s) }
func (filepathNS) Dir(s string) string                      { return filepath.Dir(s) }
func (filepathNS) Ext(s string) string                      { return filepath.Ext(s) }
func (filepathNS) FromSlash(s string) string                { return filepath.FromSlash(s) }
func (filepathNS) IsAbs(s string) bool                      { return filepath.IsAbs(s) }
func (filepathNS) Join(v ...string) string                  { return filepath.Join(v...) }
func (filepathNS) Match(pattern, name string) (bool, error) { return filepath.Match(pattern, name) }
func (filepathNS) Rel(base, target string) (string, error)  { return filepath.Rel(base, target) }
func (filepathNS) Split(s string) []string                  { a, b := filepath.Split(s); return []string{a, b} }
func (filepathNS) ToSlash(s string) string                  { return filepath.ToSlash(s) }
func (filepathNS) VolumeName(s string) string               { return filepath.VolumeName(s) }

type pathNS struct{}

func (pathNS) Base(s string) string                     { return path.Base(s) }
func (pathNS) Clean(s string) string                    { return path.Clean(s) }
func (pathNS) Dir(s string) string                      { return path.Dir(s) }
func (pathNS) Ext(s string) string                      { return path.Ext(s) }
func (pathNS) IsAbs(s string) bool                      { return path.IsAbs(s) }
func (pathNS) Join(v ...string) string                  { return path.Join(v...) }
func (pathNS) Match(pattern, name string) (bool, error) { return path.Match(pattern, name) }
func (pathNS) Split(s string) []string                  { a, b := path.Split(s); return []string{a, b} }

type regexpNS struct{}

func (regexpNS) Find(pattern, s string) string { return regexp.MustCompile(pattern).FindString(s) }
func (regexpNS) FindAll(args ...any) []string {
	n := -1
	if len(args) == 3 {
		n = int(toInt(args[2]))
	}
	return regexp.MustCompile(fmt.Sprint(args[0])).FindAllString(fmt.Sprint(args[1]), n)
}
func (regexpNS) Match(pattern, s string) (bool, error) { return regexp.MatchString(pattern, s) }
func (regexpNS) QuoteMeta(s string) string             { return regexp.QuoteMeta(s) }
func (regexpNS) Replace(pattern, repl, s string) string {
	return regexp.MustCompile(pattern).ReplaceAllString(s, repl)
}
func (regexpNS) ReplaceLiteral(pattern, repl, s string) string {
	return regexp.MustCompile(pattern).ReplaceAllLiteralString(s, repl)
}
func (regexpNS) Split(args ...any) []string {
	n := -1
	if len(args) == 3 {
		n = int(toInt(args[2]))
	}
	return regexp.MustCompile(fmt.Sprint(args[0])).Split(fmt.Sprint(args[1]), n)
}

type netNS struct{}

func (netNS) LookupIP(name string) (string, error) {
	ips, e := net.LookupIP(name)
	if e != nil {
		return "", e
	}
	for _, ip := range ips {
		if v := ip.To4(); v != nil {
			return v.String(), nil
		}
	}
	return "", nil
}
func (netNS) LookupIPs(name string) ([]string, error) {
	ips, e := net.LookupIP(name)
	if e != nil {
		return nil, e
	}
	out := []string{}
	seen := map[string]bool{}
	for _, ip := range ips {
		if v := ip.To4(); v != nil && !seen[v.String()] {
			seen[v.String()] = true
			out = append(out, v.String())
		}
	}
	return out, nil
}
func (netNS) LookupCNAME(name string) (string, error) { return net.LookupCNAME(name) }
func (netNS) LookupTXT(name string) ([]string, error) { return net.LookupTXT(name) }
func (netNS) LookupSRV(name string) (*net.SRV, error) {
	_, addrs, e := net.LookupSRV("", "", name)
	if e != nil {
		return nil, e
	}
	if len(addrs) == 0 {
		return nil, nil
	}
	return addrs[0], nil
}
func (netNS) LookupSRVs(name string) ([]*net.SRV, error) {
	_, addrs, e := net.LookupSRV("", "", name)
	return addrs, e
}
func (netNS) ParseAddr(s string) (netip.Addr, error)     { return netip.ParseAddr(s) }
func (netNS) ParsePrefix(s string) (netip.Prefix, error) { return netip.ParsePrefix(s) }

type cryptoNS struct{}

func (cryptoNS) SHA1(s any) string {
	h := sha1.Sum([]byte(fmt.Sprint(s)))
	return hex.EncodeToString(h[:])
}
func (cryptoNS) SHA256(s any) string {
	h := sha256.Sum256([]byte(fmt.Sprint(s)))
	return hex.EncodeToString(h[:])
}
func (cryptoNS) SHA224(s any) string {
	h := sha256.Sum224([]byte(fmt.Sprint(s)))
	return hex.EncodeToString(h[:])
}
func (cryptoNS) SHA384(s any) string {
	h := sha512.Sum384([]byte(fmt.Sprint(s)))
	return hex.EncodeToString(h[:])
}
func (cryptoNS) SHA512(s any) string {
	h := sha512.Sum512([]byte(fmt.Sprint(s)))
	return hex.EncodeToString(h[:])
}
func (cryptoNS) SHA512_224(s any) string {
	h := sha512.Sum512_224([]byte(fmt.Sprint(s)))
	return hex.EncodeToString(h[:])
}
func (cryptoNS) SHA512_256(s any) string {
	h := sha512.Sum512_256([]byte(fmt.Sprint(s)))
	return hex.EncodeToString(h[:])
}
func (cryptoNS) SHA1Bytes(s any) []byte   { h := sha1.Sum([]byte(fmt.Sprint(s))); return h[:] }
func (cryptoNS) SHA256Bytes(s any) []byte { h := sha256.Sum256([]byte(fmt.Sprint(s))); return h[:] }

type timeNS struct{}

func (timeNS) Now() time.Time                                { return time.Now() }
func (timeNS) Parse(layout, value string) (time.Time, error) { return time.Parse(layout, value) }
func (timeNS) ParseDuration(s string) (time.Duration, error) { return time.ParseDuration(s) }
func (timeNS) ParseLocal(layout, value string) (time.Time, error) {
	return time.ParseInLocation(layout, value, time.Local)
}
func (timeNS) ParseInLocation(layout, loc, value string) (time.Time, error) {
	l, e := time.LoadLocation(loc)
	if e != nil {
		return time.Time{}, e
	}
	return time.ParseInLocation(layout, value, l)
}
func (timeNS) Since(t time.Time) time.Duration { return time.Since(t) }
func (timeNS) Until(t time.Time) time.Duration { return time.Until(t) }
func (timeNS) Unix(v any) time.Time {
	f := toFloat(v)
	sec := int64(f)
	nsec := int64((f - float64(sec)) * 1e9)
	return time.Unix(sec, nsec)
}
func (timeNS) ZoneName() string           { n, _ := time.Now().Zone(); return n }
func (timeNS) ZoneOffset() int            { _, o := time.Now().Zone(); return o }
func (timeNS) Second(n any) time.Duration { return time.Duration(toInt(n)) * time.Second }
func (timeNS) Minute(n any) time.Duration { return time.Duration(toInt(n)) * time.Minute }
func (timeNS) Hour(n any) time.Duration   { return time.Duration(toInt(n)) * time.Hour }
func (timeNS) RFC3339() string            { return time.RFC3339 }
func (timeNS) Kitchen() string            { return time.Kitchen }
func (timeNS) Stamp() string              { return time.Stamp }
func (timeNS) StampMilli() string         { return time.StampMilli }

type randomNS struct{}

func (randomNS) String(args ...any) string {
	n := int(toInt(args[0]))
	chars := "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789"
	if len(args) > 2 {
		chars = ""
		for _, a := range args[1:] {
			chars += fmt.Sprint(a)
		}
	}
	return randString(n, chars)
}
func (randomNS) ASCII(n any) string {
	return randString(int(toInt(n)), "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789!@#$%^&*()_+-=[]{}|;:,.<>?")
}
func (randomNS) Alpha(n any) string {
	return randString(int(toInt(n)), "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ")
}
func (randomNS) AlphaNum(n any) string {
	return randString(int(toInt(n)), "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789")
}
func (randomNS) Number(args ...any) int64 {
	min, max := int64(0), int64(math.MaxInt32)
	if len(args) == 1 {
		max = toInt(args[0])
	} else if len(args) > 1 {
		min, max = toInt(args[0]), toInt(args[1])
	}
	return min + mrand.Int63n(max-min)
}
func (randomNS) Float(args ...any) float64 {
	min, max := 0.0, 1.0
	if len(args) == 1 {
		max = toFloat(args[0])
	} else if len(args) > 1 {
		min, max = toFloat(args[0]), toFloat(args[1])
	}
	return min + mrand.Float64()*(max-min)
}
func (randomNS) Item(v any) any {
	s := toSlice(v)
	if len(s) == 0 {
		return nil
	}
	return s[mrand.Intn(len(s))]
}

type testNS struct{}

func (testNS) Assert(args ...any) (string, error) {
	msg := "assertion failed"
	cond := args[0]
	if len(args) == 2 {
		msg = fmt.Sprint(args[0])
		cond = args[1]
	}
	if !toBool(cond) {
		return "", errors.New(msg)
	}
	return "", nil
}
func (testNS) Fail(msg ...any) (string, error) {
	if len(msg) > 0 {
		return "", errors.New(fmt.Sprint(msg[0]))
	}
	return "", errors.New("failed")
}
func (testNS) Kind(v any) string {
	if v == nil {
		return "invalid"
	}
	return reflect.TypeOf(v).Kind().String()
}
func (testNS) IsKind(k string, v any) bool { return testNS{}.Kind(v) == k }
func (testNS) Required(msg string, v any) (any, error) {
	if empty(v) {
		return nil, errors.New(msg)
	}
	return v, nil
}
func (testNS) Ternary(a, b, cond any) any {
	if toBool(cond) {
		return a
	}
	return b
}

type tmplNS struct{ a *app }

func (t tmplNS) Exec(name string, data ...any) (string, error) {
	var buf bytes.Buffer
	d := any(t.a.context)
	if len(data) > 0 {
		d = data[0]
	}
	if t.a.root == nil {
		return "", nil
	}
	e := t.a.root.ExecuteTemplate(&buf, name, d)
	return buf.String(), e
}
func (t tmplNS) Inline(src string, data ...any) (string, error) {
	d := any(t.a.context)
	if len(data) > 0 {
		d = data[0]
	}
	tt, e := template.New("inline").Funcs(t.a.funcs()).Parse(src)
	if e != nil {
		return "", e
	}
	var b bytes.Buffer
	e = tt.Execute(&b, d)
	return b.String(), e
}
func (t tmplNS) Path() string    { return t.a.tmplPath }
func (t tmplNS) PathDir() string { return filepath.Dir(t.a.tmplPath) }

func datasourceName(s string) (string, string) {
	if i := strings.Index(s, "="); i >= 0 {
		return s[:i], s[i+1:]
	}
	base := filepath.Base(s)
	ext := filepath.Ext(base)
	return strings.TrimSuffix(base, ext), s
}
func toInt(v any) int64 {
	switch x := v.(type) {
	case int:
		return int64(x)
	case int64:
		return x
	case int32:
		return int64(x)
	case uint64:
		return int64(x)
	case float64:
		return int64(x)
	case float32:
		return int64(x)
	case bool:
		if x {
			return 1
		}
		return 0
	case json.Number:
		i, _ := x.Int64()
		return i
	}
	s := cleanNum(fmt.Sprint(v))
	if f, err := strconv.ParseFloat(s, 64); err == nil && strings.ContainsAny(s, ".eE") {
		return int64(f)
	}
	i, _ := strconv.ParseInt(s, 0, 64)
	return i
}
func toFloat(v any) float64 {
	switch x := v.(type) {
	case float64:
		return x
	case float32:
		return float64(x)
	case int:
		return float64(x)
	case int64:
		return float64(x)
	case bool:
		if x {
			return 1
		}
		return 0
	}
	s := cleanNum(fmt.Sprint(v))
	f, err := strconv.ParseFloat(s, 64)
	if err != nil {
		if i, e := strconv.ParseInt(s, 0, 64); e == nil {
			return float64(i)
		}
	}
	return f
}
func toBool(v any) bool {
	switch x := v.(type) {
	case bool:
		return x
	case string:
		b, e := strconv.ParseBool(x)
		if e == nil {
			return b
		}
		return toFloat(x) != 0
	case nil:
		return false
	}
	return !empty(v) && toFloat(v) != 0
}
func cleanNum(s string) string { return strings.ReplaceAll(strings.TrimSpace(s), ",", "") }
func anyFloat(v ...any) bool {
	for _, x := range v {
		s := fmt.Sprint(x)
		switch x.(type) {
		case float64, float32:
			return true
		}
		if strings.ContainsAny(s, ".eENaInf") {
			return true
		}
	}
	return false
}
func cleanFloat(f float64) any {
	if math.IsInf(f, 0) || math.IsNaN(f) || f != math.Trunc(f) {
		return f
	}
	return int64(f)
}
func toSlice(v any) []any {
	if v == nil {
		return nil
	}
	if s, ok := v.([]any); ok {
		return append([]any{}, s...)
	}
	rv := reflect.ValueOf(v)
	if rv.Kind() == reflect.Slice || rv.Kind() == reflect.Array {
		out := []any{}
		for i := 0; i < rv.Len(); i++ {
			out = append(out, rv.Index(i).Interface())
		}
		return out
	}
	return []any{v}
}
func isSlice(v any) bool {
	if v == nil {
		return false
	}
	rv := reflect.ValueOf(v)
	return rv.Kind() == reflect.Slice || rv.Kind() == reflect.Array
}
func toMap(v any) map[string]any {
	out := map[string]any{}
	if m, ok := v.(map[string]any); ok {
		for k, x := range m {
			out[k] = x
		}
		return out
	}
	rv := reflect.ValueOf(v)
	if rv.Kind() == reflect.Map {
		for _, k := range rv.MapKeys() {
			out[fmt.Sprint(k.Interface())] = rv.MapIndex(k).Interface()
		}
	}
	return out
}
func mapGet(v any, key string) any { return toMap(v)[key] }
func empty(v any) bool {
	if v == nil {
		return true
	}
	rv := reflect.ValueOf(v)
	switch rv.Kind() {
	case reflect.String, reflect.Array, reflect.Slice, reflect.Map:
		return rv.Len() == 0
	case reflect.Bool:
		return !rv.Bool()
	case reflect.Int, reflect.Int64, reflect.Float64:
		return toFloat(v) == 0
	}
	return false
}
func envMap() map[string]string {
	m := map[string]string{}
	for _, e := range os.Environ() {
		p := strings.SplitN(e, "=", 2)
		m[p[0]] = p[1]
	}
	return m
}
func parseSimpleYAML(s string) any {
	m := map[string]any{}
	var arr []any
	for _, line := range strings.Split(s, "\n") {
		line = strings.TrimSpace(line)
		if line == "" || strings.HasPrefix(line, "#") {
			continue
		}
		if strings.HasPrefix(line, "- ") {
			arr = append(arr, parseScalar(strings.TrimSpace(line[2:])))
			continue
		}
		if i := strings.Index(line, ":"); i >= 0 {
			k := strings.TrimSpace(line[:i])
			v := strings.TrimSpace(line[i+1:])
			m[k] = parseScalar(v)
		}
	}
	if arr != nil && len(m) == 0 {
		return arr
	}
	return m
}
func parseScalar(s string) any {
	s = strings.Trim(s, "\"'")
	if i, e := strconv.ParseInt(s, 0, 64); e == nil {
		return i
	}
	if f, e := strconv.ParseFloat(s, 64); e == nil {
		return f
	}
	if b, e := strconv.ParseBool(s); e == nil {
		return b
	}
	return s
}
func toYAML(v any, indent int) string {
	pad := strings.Repeat(" ", indent)
	switch x := v.(type) {
	case map[string]any:
		ks := []string{}
		for k := range x {
			ks = append(ks, k)
		}
		sort.Strings(ks)
		var b strings.Builder
		for _, k := range ks {
			b.WriteString(pad + k + ": " + fmt.Sprint(x[k]) + "\n")
		}
		return b.String()
	case []any:
		var b strings.Builder
		for _, e := range x {
			b.WriteString(pad + "- " + fmt.Sprint(e) + "\n")
		}
		return b.String()
	}
	return fmt.Sprint(v)
}
func toTOML(v any) string {
	m := toMap(v)
	ks := []string{}
	for k := range m {
		ks = append(ks, k)
	}
	sort.Strings(ks)
	var b strings.Builder
	for _, k := range ks {
		fmt.Fprintf(&b, "%s = %q\n", k, fmt.Sprint(m[k]))
	}
	return b.String()
}
func randString(n int, chars string) string {
	if chars == "" {
		chars = "abcdefghijklmnopqrstuvwxyz"
	}
	b := make([]byte, n)
	_, _ = rand.Read(b)
	r := []rune(chars)
	out := make([]rune, n)
	for i, x := range b {
		out[i] = r[int(x)%len(r)]
	}
	return string(out)
}
func caseWords(s, sep string, titleFirst bool) string {
	re := regexp.MustCompile(`[^A-Za-z0-9]+`)
	parts := re.Split(s, -1)
	out := []string{}
	for i, p := range parts {
		if p == "" {
			continue
		}
		p = strings.ToLower(p)
		if titleFirst || i > 0 {
			p = strings.ToUpper(p[:1]) + p[1:]
		}
		out = append(out, p)
	}
	return strings.Join(out, sep)
}

func (a *app) processDir(inDir, outDir, outputMap, chmod string, excludes, includes, excludeProc []string) error {
	return filepath.WalkDir(inDir, func(p string, d os.DirEntry, err error) error {
		if err != nil || d.IsDir() {
			return err
		}
		rel, _ := filepath.Rel(inDir, p)
		if matchAny(rel, excludes) || (len(includes) > 0 && !matchAny(rel, includes)) {
			return nil
		}
		dest := filepath.Join(outDir, rel)
		if outputMap != "" {
			a.context["in"] = rel
			rendered, e := a.render(outputMap, "<output-map>", "error", nil)
			if e != nil {
				return e
			}
			dest = strings.TrimSpace(rendered)
		}
		b, e := os.ReadFile(p)
		if e != nil {
			return e
		}
		if !matchAny(rel, excludeProc) {
			rendered, e := a.render(string(b), p, "error", nil)
			if e != nil {
				return e
			}
			b = []byte(rendered)
		}
		mode := os.FileMode(0644)
		if st, e := os.Stat(p); e == nil {
			mode = st.Mode()
		}
		if chmod != "" {
			if n, e := strconv.ParseUint(chmod, 8, 32); e == nil {
				mode = os.FileMode(n)
			}
		}
		if e := os.MkdirAll(filepath.Dir(dest), 0755); e != nil {
			return e
		}
		return os.WriteFile(dest, b, mode)
	})
}
func matchAny(name string, pats []string) bool {
	for _, p := range pats {
		if ok, _ := filepath.Match(p, name); ok {
			return true
		}
		if strings.HasSuffix(p, "/**") && strings.HasPrefix(name, strings.TrimSuffix(p, "/**")) {
			return true
		}
	}
	return false
}

const helpText = `Process text files with Go templates

Usage:
  gomplate [flags]

Flags:
  -d, --datasource datasource        datasource in alias=URL form. Specify multiple times to add multiple sources.
  -c, --context datasource           pre-load a datasource into the context, in alias=URL form.
  -f, --file file                    Template file to process. Omit to use standard input.
  -i, --in string                    Template string to process
  -o, --out file                     output file name. Omit to use standard output. (default [-])
  -h, --help                         help for gomplate
  -v, --version                      version for gomplate
`
