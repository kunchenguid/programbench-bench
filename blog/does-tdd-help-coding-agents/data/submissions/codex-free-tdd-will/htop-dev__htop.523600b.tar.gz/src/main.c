#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <pwd.h>
#include <ctype.h>
#include <dirent.h>
#include <unistd.h>
#include <sys/stat.h>
#include <sys/types.h>

struct Options {
    int max_iterations;
    const char *filter;
    const char *user;
    int pid_filter[256];
    int pid_count;
};

static void print_help(void) {
    fputs(
        "htop 3.5.0-dev-878e0ce\n"
        "(C) 2004-2019 Hisham Muhammad. (C) 2020-2026 htop dev team.\n"
        "Released under the GNU GPLv2+.\n"
        "\n"
        "-C --no-color                   Use a monochrome color scheme\n"
        "-d --delay=DELAY                Set the delay between updates, in tenths of seconds\n"
        "-F --filter=FILTER              Show only the commands matching the given filter\n"
        "   --no-function-bar             Hide the function bar\n"
        "-h --help                       Print this help screen\n"
        "-H --highlight-changes[=DELAY]  Highlight new and old processes\n"
        "-M --no-mouse                   Disable the mouse\n"
        "   --no-meters                  Hide meters\n"
        "-n --max-iterations=NUMBER      Exit htop after NUMBER iterations/frame updates\n"
        "-p --pid=PID[,PID,PID...]       Show only the given PIDs\n"
        "   --readonly                   Disable all system and process changing features\n"
        "-s --sort-key=COLUMN            Sort by COLUMN in list view (try --sort-key=help for a list)\n"
        "-t --tree                       Show the tree view (can be combined with -s)\n"
        "-u --user[=USERNAME]            Show only processes for a given user (or $USER)\n"
        "-U --no-unicode                 Do not use unicode but plain ASCII\n"
        "-V --version                    Print version info\n"
        "\n"
        "Press F1 inside htop for online help.\n"
        "See 'man htop' for more information.\n",
        stdout);
}

static void print_version(void) {
    puts("htop 3.5.0-dev-878e0ce");
}

static void print_sort_keys(void) {
    fputs(
        "                PID Process/thread ID\n"
        "            Command Command line (insert as last column only)\n"
        "              STATE Process state (S sleeping, R running, D disk, Z zombie, T traced, W paging, I idle)\n"
        "               PPID Parent process ID\n"
        "               PGRP Process group ID\n"
        "            SESSION Process's session ID\n"
        "                TTY Controlling terminal\n"
        "              TPGID Process ID of the fg process group of the controlling terminal\n"
        "             MINFLT Number of minor faults which have not required loading a memory page from disk\n"
        "            CMINFLT Children processes' minor faults\n"
        "             MAJFLT Number of major faults which have required loading a memory page from disk\n"
        "            CMAJFLT Children processes' major faults\n"
        "              UTIME User CPU time - time the process spent executing in user mode\n"
        "              STIME System CPU time - time the kernel spent running system calls for this process\n"
        "             CUTIME Children processes' user CPU time\n"
        "             CSTIME Children processes' system CPU time\n"
        "           PRIORITY Kernel's internal priority for the process\n"
        "               NICE Nice value (the higher the value, the more it lets other processes take priority)\n"
        "          STARTTIME Time the process was started\n"
        "          PROCESSOR Id of the CPU the process last executed on\n"
        "             M_VIRT Total program size in virtual memory\n"
        "         M_RESIDENT Resident set size, size of the text and data sections, plus stack usage\n"
        "            M_SHARE Size of the process's shared pages\n"
        "              M_TRS Size of the .text segment of the process (CODE)\n"
        "              M_DRS Size of the .data segment plus stack usage of the process (DATA)\n"
        "              M_LRS The library size of the process (calculated from memory maps)\n"
        "             ST_UID User ID of the process owner\n"
        "        PERCENT_CPU Percentage of the CPU time the process used in the last sampling\n"
        "        PERCENT_MEM Percentage of the memory the process is using, based on resident memory size\n"
        "               USER Username of the process owner (or user ID if name cannot be determined)\n"
        "               TIME Total time the process has spent in user and system time\n"
        "               NLWP Number of threads in the process\n"
        "               TGID Thread group ID (i.e. process ID)\n"
        "   PERCENT_NORM_CPU Normalized percentage of the CPU time the process used in the last sampling (normalized by cpu count)\n"
        "            ELAPSED Time since the process was started\n"
        "    SCHEDULERPOLICY Current scheduling policy of the process\n"
        "              RCHAR Number of bytes the process has read\n"
        "              WCHAR Number of bytes the process has written\n"
        "              SYSCR Number of read(2) syscalls for the process\n"
        "              SYSCW Number of write(2) syscalls for the process\n"
        "             RBYTES Bytes of read(2) I/O for the process\n"
        "             WBYTES Bytes of write(2) I/O for the process\n"
        "             CNCLWB Bytes of cancelled write(2) I/O\n"
        "       IO_READ_RATE The I/O rate of read(2) in bytes per second for the process\n"
        "      IO_WRITE_RATE The I/O rate of write(2) in bytes per second for the process\n"
        "            IO_RATE Total I/O rate in bytes per second\n"
        "             CGROUP Which cgroup the process is in\n"
        "                OOM OOM (Out-of-Memory) killer score\n"
        "        IO_PRIORITY I/O priority\n"
        "              M_PSS proportional set size, same as M_RESIDENT but each page is divided by the number of processes sharing it\n"
        "             M_SWAP Size of the process's swapped pages\n"
        "            M_PSSWP shows proportional swap share of this mapping, unlike \"Swap\", this does not take into account swapped out page of underlying shmem objects\n"
        "               CTXT Context switches (incremental sum of voluntary_ctxt_switches and nonvoluntary_ctxt_switches)\n"
        "            SECATTR Security attribute of the process (e.g. SELinux or AppArmor)\n"
        "               COMM comm string of the process from /proc/[pid]/comm\n"
        "                EXE Basename of exe of the process from /proc/[pid]/exe\n"
        "                CWD The current working directory of the process\n"
        "       AUTOGROUP_ID The autogroup identifier of the process\n"
        "     AUTOGROUP_NICE Nice value (the higher the value, the more other processes take priority) associated with the process autogroup\n"
        "            CCGROUP Which cgroup the process is in (condensed to essentials)\n"
        "          CONTAINER Name of the container the process is in (guessed by heuristics)\n"
        "             M_PRIV The private memory size of the process - resident set size minus shared memory\n"
        "           GPU_TIME Total GPU time\n"
        "        GPU_PERCENT Percentage of the GPU time the process used in the last sampling\n"
        "        ISCONTAINER Whether the process is running inside a child container\n",
        stdout);
}

static int parse_number(const char *s) {
    if (!s || !*s) return 0;
    char *end = NULL;
    (void)strtol(s, &end, 10);
    return end && *end == '\0';
}

static int valid_sort_key(const char *s) {
    static const char *keys[] = {
        "PID","Command","STATE","PPID","PGRP","SESSION","TTY","TPGID","MINFLT","CMINFLT",
        "MAJFLT","CMAJFLT","UTIME","STIME","CUTIME","CSTIME","PRIORITY","NICE","STARTTIME",
        "PROCESSOR","M_VIRT","M_RESIDENT","M_SHARE","M_TRS","M_DRS","M_LRS","ST_UID",
        "PERCENT_CPU","PERCENT_MEM","USER","TIME","NLWP","TGID","PERCENT_NORM_CPU","ELAPSED",
        "SCHEDULERPOLICY","RCHAR","WCHAR","SYSCR","SYSCW","RBYTES","WBYTES","CNCLWB",
        "IO_READ_RATE","IO_WRITE_RATE","IO_RATE","CGROUP","OOM","IO_PRIORITY","M_PSS",
        "M_SWAP","M_PSSWP","CTXT","SECATTR","COMM","EXE","CWD","AUTOGROUP_ID","AUTOGROUP_NICE",
        "CCGROUP","CONTAINER","M_PRIV","GPU_TIME","GPU_PERCENT","ISCONTAINER", NULL
    };
    for (int i = 0; keys[i]; i++) {
        if (strcmp(keys[i], s) == 0) return 1;
    }
    return 0;
}

static int valid_user(const char *s) {
    if (!s || !*s) return 0;
    int all_digits = 1;
    for (const char *p = s; *p; p++) {
        if (!isdigit((unsigned char)*p)) all_digits = 0;
    }
    if (all_digits) return 1;
    return getpwnam(s) != NULL;
}

static int pid_wanted(const struct Options *opts, int pid) {
    if (opts->pid_count == 0) return 1;
    for (int i = 0; i < opts->pid_count; i++) {
        if (opts->pid_filter[i] == pid) return 1;
    }
    return 0;
}

static int parse_pid_list(struct Options *opts, const char *s) {
    const char *p = s;
    while (p && *p) {
        char *end = NULL;
        long v = strtol(p, &end, 10);
        if (end == p || v < 0) return 0;
        if (opts->pid_count < 256) opts->pid_filter[opts->pid_count++] = (int)v;
        if (*end == ',') p = end + 1;
        else if (*end == '\0') break;
        else return 0;
    }
    return 1;
}

static void read_cmd(int pid, char *buf, size_t buflen) {
    char path[64];
    snprintf(path, sizeof(path), "/proc/%d/cmdline", pid);
    FILE *f = fopen(path, "r");
    size_t n = 0;
    if (f) {
        n = fread(buf, 1, buflen - 1, f);
        fclose(f);
    }
    for (size_t i = 0; i < n; i++) {
        if (buf[i] == '\0') buf[i] = ' ';
    }
    while (n > 0 && isspace((unsigned char)buf[n - 1])) n--;
    buf[n] = '\0';
    if (n == 0) {
        snprintf(path, sizeof(path), "/proc/%d/comm", pid);
        f = fopen(path, "r");
        if (f) {
            if (fgets(buf, (int)buflen, f)) {
                buf[strcspn(buf, "\n")] = '\0';
            }
            fclose(f);
        }
    }
    if (buf[0] == '\0') snprintf(buf, buflen, "[unknown]");
}

static const char *uid_name(uid_t uid, char *buf, size_t buflen) {
    struct passwd *pw = getpwuid(uid);
    if (pw) return pw->pw_name;
    snprintf(buf, buflen, "%u", (unsigned)uid);
    return buf;
}

static int command_matches(const char *cmd, const char *filter) {
    if (!filter || !*filter) return 1;
    char lower_cmd[1024], lower_filter[256];
    size_t i;
    for (i = 0; cmd[i] && i + 1 < sizeof(lower_cmd); i++) lower_cmd[i] = (char)tolower((unsigned char)cmd[i]);
    lower_cmd[i] = '\0';
    for (i = 0; filter[i] && i + 1 < sizeof(lower_filter); i++) lower_filter[i] = (char)tolower((unsigned char)filter[i]);
    lower_filter[i] = '\0';
    char *term = strtok(lower_filter, "|");
    while (term) {
        if (strstr(lower_cmd, term)) return 1;
        term = strtok(NULL, "|");
    }
    return 0;
}

static int render_once(const struct Options *opts) {
    const char *term = getenv("TERM");
    if (!term || strcmp(term, "unknown") == 0 || *term == '\0') {
        fputs("Error opening terminal: unknown.\n", stderr);
        return 1;
    }
    DIR *dir = opendir("/proc");
    if (!dir) {
        perror("opendir /proc");
        return 1;
    }
    printf("\033[H\033[2J");
    printf("  Mem[                    ] Tasks: ");
    int tasks = 0;
    struct dirent *de;
    while ((de = readdir(dir))) {
        if (isdigit((unsigned char)de->d_name[0])) tasks++;
    }
    rewinddir(dir);
    printf("%d, 0 thr; 0 running\n", tasks);
    printf("  Swp[                    ] Load average: 0.00 0.00 0.00\n");
    printf("  [Main] [I/O]\n");
    printf("  PID USER       PRI  NI  VIRT   RES   SHR S  CPU%%-MEM%%   TIME+  Command\n");
    int shown = 0;
    while ((de = readdir(dir))) {
        if (!isdigit((unsigned char)de->d_name[0])) continue;
        int pid = atoi(de->d_name);
        if (!pid_wanted(opts, pid)) continue;
        char cmd[1024] = {0};
        read_cmd(pid, cmd, sizeof(cmd));
        if (!command_matches(cmd, opts->filter)) continue;
        char path[64];
        struct stat st;
        snprintf(path, sizeof(path), "/proc/%d", pid);
        if (stat(path, &st) != 0) continue;
        char ubuf[32];
        const char *user = uid_name(st.st_uid, ubuf, sizeof(ubuf));
        if (opts->user && strcmp(opts->user, user) != 0) continue;
        printf("%5d %-10.10s  20   0     0     0     0 S   0.0  0.0  0:00.00 %s\n",
               pid, user, cmd);
        if (++shown >= 40) break;
    }
    closedir(dir);
    return 0;
}

int main(int argc, char **argv) {
    struct Options opts;
    memset(&opts, 0, sizeof(opts));
    opts.max_iterations = -1;

    for (int i = 1; i < argc; i++) {
        const char *arg = argv[i];
        if (strcmp(arg, "--help") == 0 || strcmp(arg, "-h") == 0) {
            print_help();
            return 0;
        }
        if (strcmp(arg, "--version") == 0 || strcmp(arg, "-V") == 0) {
            print_version();
            return 0;
        }
        if (strcmp(arg, "-v") == 0) {
            fprintf(stderr, "%s: invalid option -- 'v'\n", argv[0]);
            return 1;
        }
        if (strcmp(arg, "--sort-key=help") == 0 ||
            (strcmp(arg, "-s") == 0 && i + 1 < argc && strcmp(argv[i + 1], "help") == 0)) {
            print_sort_keys();
            return 0;
        }
        if (strcmp(arg, "-d") == 0 || strcmp(arg, "--delay") == 0) {
            if (i + 1 >= argc) {
                fprintf(stderr, "%s: option requires an argument -- 'd'\n", argv[0]);
                return 1;
            }
            const char *value = argv[++i];
            if (!parse_number(value)) {
                fprintf(stderr, "Error: invalid delay value \"%s\".\n", value);
                return 1;
            }
            continue;
        }
        if (strncmp(arg, "--delay=", 8) == 0) {
            const char *value = arg + 8;
            if (!parse_number(value)) {
                fprintf(stderr, "Error: invalid delay value \"%s\".\n", value);
                return 1;
            }
            continue;
        }
        if (strcmp(arg, "-s") == 0 || strcmp(arg, "--sort-key") == 0) {
            if (i + 1 >= argc) {
                fprintf(stderr, "%s: option requires an argument -- 's'\n", argv[0]);
                return 1;
            }
            const char *value = argv[++i];
            if (!valid_sort_key(value)) {
                fprintf(stderr, "Error: invalid column \"%s\".\n", value);
                return 1;
            }
            continue;
        }
        if (strncmp(arg, "--sort-key=", 11) == 0) {
            const char *value = arg + 11;
            if (!valid_sort_key(value)) {
                fprintf(stderr, "Error: invalid column \"%s\".\n", value);
                return 1;
            }
            continue;
        }
        if (strcmp(arg, "-u") == 0 || strcmp(arg, "--user") == 0) {
            const char *value = NULL;
            if (i + 1 < argc && argv[i + 1][0] != '-') value = argv[++i];
            else value = getenv("USER");
            if (!valid_user(value)) {
                fprintf(stderr, "Error: invalid user \"%s\".\n", value ? value : "");
                return 1;
            }
            opts.user = value;
            continue;
        }
        if (strncmp(arg, "--user=", 7) == 0) {
            const char *value = arg + 7;
            if (!valid_user(value)) {
                fprintf(stderr, "Error: invalid user \"%s\".\n", value);
                return 1;
            }
            opts.user = value;
            continue;
        }
        if (strcmp(arg, "-n") == 0 || strcmp(arg, "--max-iterations") == 0) {
            if (i + 1 >= argc) {
                fprintf(stderr, "%s: option requires an argument -- 'n'\n", argv[0]);
                return 1;
            }
            const char *value = argv[++i];
            if (!parse_number(value)) {
                fprintf(stderr, "Error: invalid maximum iteration count \"%s\".\n", value);
                return 1;
            }
            opts.max_iterations = atoi(value);
            if (opts.max_iterations <= 0) {
                fputs("Error: maximum iteration count must be positive.\n", stderr);
                return 1;
            }
            continue;
        }
        if (strncmp(arg, "--max-iterations=", 17) == 0) {
            const char *value = arg + 17;
            if (!parse_number(value)) {
                fprintf(stderr, "Error: invalid maximum iteration count \"%s\".\n", value);
                return 1;
            }
            opts.max_iterations = atoi(value);
            if (opts.max_iterations <= 0) {
                fputs("Error: maximum iteration count must be positive.\n", stderr);
                return 1;
            }
            continue;
        }
        if (strcmp(arg, "-F") == 0 || strcmp(arg, "--filter") == 0) {
            if (i + 1 >= argc) {
                fprintf(stderr, "%s: option requires an argument -- 'F'\n", argv[0]);
                return 1;
            }
            opts.filter = argv[++i];
            continue;
        }
        if (strncmp(arg, "--filter=", 9) == 0) {
            opts.filter = arg + 9;
            continue;
        }
        if (strcmp(arg, "-p") == 0 || strcmp(arg, "--pid") == 0) {
            if (i + 1 >= argc) {
                fprintf(stderr, "%s: option requires an argument -- 'p'\n", argv[0]);
                return 1;
            }
            parse_pid_list(&opts, argv[++i]);
            continue;
        }
        if (strncmp(arg, "--pid=", 6) == 0) {
            parse_pid_list(&opts, arg + 6);
            continue;
        }
        if (strcmp(arg, "-C") == 0 || strcmp(arg, "--no-color") == 0 ||
            strcmp(arg, "--no-colour") == 0 || strcmp(arg, "-t") == 0 ||
            strcmp(arg, "--tree") == 0 || strcmp(arg, "-U") == 0 ||
            strcmp(arg, "--no-unicode") == 0 || strcmp(arg, "-M") == 0 ||
            strcmp(arg, "--no-mouse") == 0 || strcmp(arg, "--no-function-bar") == 0 ||
            strcmp(arg, "--no-meters") == 0 || strcmp(arg, "--readonly") == 0 ||
            strcmp(arg, "-H") == 0 || strncmp(arg, "--highlight-changes", 19) == 0) {
            if (strncmp(arg, "--highlight-changes=", 20) == 0 && !parse_number(arg + 20)) {
                fprintf(stderr, "Error: invalid highlight delay value \"%s\".\n", arg + 20);
                return 1;
            }
            if (strcmp(arg, "--highlight-changes") == 0 && i + 1 < argc && argv[i + 1][0] != '-') {
                const char *value = argv[++i];
                if (!parse_number(value)) {
                    fprintf(stderr, "Error: invalid highlight delay value \"%s\".\n", value);
                    return 1;
                }
            }
            continue;
        }
        if (strncmp(arg, "-H", 2) == 0 && arg[2] != '\0') {
            const char *value = arg + 2;
            if (!parse_number(value)) {
                fprintf(stderr, "Error: invalid highlight delay value \"%s\".\n", value);
                return 1;
            }
            continue;
        }
        if (strncmp(arg, "--", 2) == 0) {
            fprintf(stderr, "%s: unrecognized option '%s'\n", argv[0], arg);
            return 1;
        }
        if (arg[0] == '-' && arg[1] != '\0') {
            fprintf(stderr, "%s: invalid option -- '%c'\n", argv[0], arg[1]);
            return 1;
        }
    }
    return render_once(&opts);
}
