#!/bin/bash
set -euo pipefail
ROOT=$(cd "$(dirname "$0")/.." && pwd)
cd "$ROOT"
rm -f executable
chmod +x compile.sh
./compile.sh >/tmp/htop_compile.log
out=$(./executable --help 2>&1)
status=$?
[ "$status" -eq 0 ]
printf '%s\n' "$out" | grep -F 'htop 3.5.0-dev-878e0ce' >/dev/null
printf '%s\n' "$out" | grep -F -- '-C --no-color                   Use a monochrome color scheme' >/dev/null
printf '%s\n' "$out" | grep -F "Press F1 inside htop for online help." >/dev/null

for flag in --version -V; do
  out=$(./executable "$flag" 2>&1)
  status=$?
  [ "$status" -eq 0 ]
  [ "$out" = "htop 3.5.0-dev-878e0ce" ]
done

set +e
out=$(./executable -v 2>&1)
status=$?
set -e
[ "$status" -eq 1 ]
[ "$out" = "./executable: invalid option -- 'v'" ]

out=$(./executable --sort-key=help 2>&1)
status=$?
[ "$status" -eq 0 ]
printf '%s\n' "$out" | grep -F '                PID Process/thread ID' >/dev/null
printf '%s\n' "$out" | grep -F '        PERCENT_CPU Percentage of the CPU time the process used in the last sampling' >/dev/null
printf '%s\n' "$out" | grep -F '        ISCONTAINER Whether the process is running inside a child container' >/dev/null

set +e
out=$(./executable --bad 2>&1); status=$?
set -e
[ "$status" -eq 1 ]
[ "$out" = "./executable: unrecognized option '--bad'" ]

set +e
out=$(./executable -d 2>&1); status=$?
set -e
[ "$status" -eq 1 ]
[ "$out" = "./executable: option requires an argument -- 'd'" ]

set +e
out=$(./executable -d abc 2>&1); status=$?
set -e
[ "$status" -eq 1 ]
[ "$out" = "Error: invalid delay value \"abc\"." ]

set +e
out=$(./executable -s BAD --version 2>&1); status=$?
set -e
[ "$status" -eq 1 ]
[ "$out" = "Error: invalid column \"BAD\"." ]

set +e
out=$(./executable -u definitely_no_such_user_xyz --version 2>&1); status=$?
set -e
[ "$status" -eq 1 ]
[ "$out" = "Error: invalid user \"definitely_no_such_user_xyz\"." ]

set +e
out=$(./executable -Z 2>&1); status=$?
set -e
[ "$status" -eq 1 ]
[ "$out" = "./executable: invalid option -- 'Z'" ]

set +e
out=$(./executable -n abc 2>&1); status=$?
set -e
[ "$status" -eq 1 ]
[ "$out" = "Error: invalid maximum iteration count \"abc\"." ]

set +e
out=$(./executable -n 0 2>&1); status=$?
set -e
[ "$status" -eq 1 ]
[ "$out" = "Error: maximum iteration count must be positive." ]

set +e
out=$(./executable -Habc 2>&1); status=$?
set -e
[ "$status" -eq 1 ]
[ "$out" = "Error: invalid highlight delay value \"abc\"." ]

set +e
out=$(env -u TERM ./executable -n 1 2>&1); status=$?
set -e
[ "$status" -eq 1 ]
[ "$out" = "Error opening terminal: unknown." ]

out=$(TERM=xterm ./executable -n 1 --no-color --no-unicode --no-function-bar 2>&1)
status=$?
[ "$status" -eq 0 ]
printf '%s\n' "$out" | grep -F 'Tasks:' >/dev/null
printf '%s\n' "$out" | grep -F 'PID USER' >/dev/null
printf '%s\n' "$out" | grep -F 'Command' >/dev/null
