#!/bin/bash
set -e
go build -o executable ./src
chmod +x executable
