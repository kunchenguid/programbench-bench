package main

import (
    "bytes"
    "errors"
    "fmt"
    "image"
    "image/color"
    "image/gif"
    "image/png"
    "io"
    "math"
    "os"
    "path/filepath"
    "strconv"
    "strings"

    _ "image/gif"
    _ "image/jpeg"
    _ "image/png"
)

const helpText = `This tool converts images into ascii art and prints them on the terminal.
Further configuration can be managed with flags.

Usage:
  ascii-image-converter [image paths/urls or piped stdin] [flags]

Flags:
  -C, --color             Display ascii art with original colors
                          If 24-bit colors aren't supported, uses 8-bit
                          (Inverts with --negative flag)
                          (Overrides --grayscale and --font-color flags)
                          
      --color-bg          If some color flag is passed, use that color
                          on character background instead of foreground
                          (Inverts with --negative flag)
                          (Only applicable for terminal display)
                          
  -d, --dimensions ints   Set width and height for ascii art in CHARACTER length
                          e.g. -d 60,30 (defaults to terminal height)
                          (Overrides --width and --height flags)
                          
  -W, --width int         Set width for ascii art in CHARACTER length
                          Height is kept to aspect ratio
                          e.g. -W 60
                          
  -H, --height int        Set height for ascii art in CHARACTER length
                          Width is kept to aspect ratio
                          e.g. -H 60
                          
  -m, --map string        Give custom ascii characters to map against
                          Ordered from darkest to lightest
                          e.g. -m " .-+#@" (Quotation marks excluded from map)
                          (Overrides --complex flag)
                          
  -b, --braille           Use braille characters instead of ascii
                          Terminal must support braille patterns properly
                          (Overrides --complex and --map flags)
                          
      --threshold int     Threshold for braille art
                          Value between 0-255 is accepted
                          e.g. --threshold 170
                          (Defaults to 128)
                          
      --dither            Apply dithering on image for braille
                          art conversion
                          (Only applicable with --braille flag)
                          (Negates --threshold flag)
                          
  -g, --grayscale         Display grayscale ascii art
                          (Inverts with --negative flag)
                          (Overrides --font-color flag)
                          
  -c, --complex           Display ascii characters in a larger range
                          May result in higher quality
                          
  -f, --full              Use largest dimensions for ascii art
                          that fill the terminal width
                          (Overrides --dimensions, --width and --height flags)
                          
  -n, --negative          Display ascii art in negative colors
                          
  -x, --flipX             Flip ascii art horizontally
                          
  -y, --flipY             Flip ascii art vertically
                          
  -s, --save-img string   Save ascii art as a .png file
                          Format: <image-name>-ascii-art.png
                          Image will be saved in passed path
                          (pass . for current directory)
                          
      --save-txt string   Save ascii art as a .txt file
                          Format: <image-name>-ascii-art.txt
                          File will be saved in passed path
                          (pass . for current directory)
                          
      --save-gif string   If input is a gif, save it as a .gif file
                          Format: <gif-name>-ascii-art.gif
                          Gif will be saved in passed path
                          (pass . for current directory)
                          
      --save-bg ints      Set background color for --save-img
                          and --save-gif flags
                          Pass an RGBA value
                          e.g. --save-bg 255,255,255,100
                          (Defaults to 0,0,0,100)
                          
      --font string       Set font for --save-img and --save-gif flags
                          Pass file path to font .ttf file
                          e.g. --font ./RobotoMono-Regular.ttf
                          (Defaults to Hack-Regular for ascii and
                           DejaVuSans-Oblique for braille)
                          
      --font-color ints   Set font color for terminal as well as
                          --save-img and --save-gif flags
                          Pass an RGB value
                          e.g. --font-color 0,0,0
                          (Defaults to 255,255,255)
                          
      --only-save         Don't print ascii art on terminal
                          if some saving flag is passed
                          
      --formats           Display supported input formats
                          
  -h, --help              Help for ascii-image-converter
                          
  -v, --version           Version for ascii-image-converter

Copyright © 2021 Zoraiz Hassan <hzoraiz8@gmail.com>
Distributed under the Apache License Version 2.0 (Apache-2.0)
For further details, visit https://github.com/TheZoraiz/ascii-image-converter
`

type config struct {
    width, height int
    charMap string
    complex bool
    negative bool
    flipX, flipY bool
    braille bool
    threshold int
    color, grayscale, colorBG bool
    fontColor bool
    saveTxt, saveImg, saveGif string
    onlySave bool
    inputs []string
}

func main() { os.Exit(run(os.Args[1:], os.Stdout, os.Stderr, os.Stdin)) }

func run(args []string, stdout, stderr io.Writer, stdin io.Reader) int {
    cfg, handled, code := parseArgs(args, stdout, stderr)
    if handled { return code }
    if (cfg.color || cfg.grayscale || cfg.fontColor) && cfg.saveImg == "" && cfg.saveGif == "" {
        fmt.Fprintln(stderr, "Error: your terminal supports neither 24-bit nor 8-bit colors. Other coloring options aren't available")
        fmt.Fprintln(stderr)
        return 1
    }
    if len(cfg.inputs) == 0 {
        if hasPipedStdin() { cfg.inputs = []string{"-"} } else {
            fmt.Fprintln(stderr, "Error: Need at least 1 input path/url or piped input")
            fmt.Fprintln(stderr, "Use the -h flag for more info")
            return 1
        }
    }
    exit := 0
    for _, in := range cfg.inputs {
        img, name, err := loadImage(in, stdin)
        if err != nil { fmt.Fprintf(stderr, "Error: %v\n", err); exit = 1; continue }
        art := convert(img, cfg)
        if cfg.saveTxt != "" { if err := saveText(cfg.saveTxt, name, art); err != nil { fmt.Fprintf(stderr, "Error: %v\n", err); exit = 1 } }
        if cfg.saveImg != "" { if err := savePNGPlaceholder(cfg.saveImg, name, art); err != nil { fmt.Fprintf(stderr, "Error: %v\n", err); exit = 1 } }
        if cfg.saveGif != "" { if err := saveGIFPlaceholder(cfg.saveGif, name); err != nil { fmt.Fprintf(stderr, "Error: %v\n", err); exit = 1 } }
        if !(cfg.onlySave && (cfg.saveTxt != "" || cfg.saveImg != "" || cfg.saveGif != "")) { fmt.Fprintln(stdout, art) }
    }
    return exit
}

func parseArgs(args []string, stdout, stderr io.Writer) (config, bool, int) {
    cfg := config{charMap:" .:-=+*#%@", threshold:128}
    for i:=0; i<len(args); i++ {
        a := args[i]
        next := func() string { if i+1 >= len(args) { return "" }; i++; return args[i] }
        switch a {
        case "-h", "--help": fmt.Fprint(stdout, helpText); return cfg, true, 0
        case "-v", "--version": fmt.Fprintln(stdout, "v1.13.1"); return cfg, true, 0
        case "--formats": fmt.Fprint(stdout, "Supported input formats:\n\nJPEG/JPG\nPNG\nWEBP\nBMP\nTIFF/TIF\nGIF\n"); return cfg, true, 0
        case "-C", "--color": cfg.color=true
        case "--color-bg": cfg.colorBG=true
        case "-g", "--grayscale": cfg.grayscale=true
        case "-n", "--negative": cfg.negative=true
        case "-x", "--flipX": cfg.flipX=true
        case "-y", "--flipY": cfg.flipY=true
        case "-b", "--braille": cfg.braille=true
        case "-c", "--complex": cfg.complex=true; cfg.charMap = " .'`^\",:;Il!i><~+_-?][}{1)(|\\/tfjrxnuvczXYUJCLQ0OZmwqpdbkhao*#MW&8%B@$"
        case "-f", "--full": cfg.width=80; cfg.height=0
        case "-d", "--dimensions":
            w,h,err := parsePair(next()); if err!=nil { fmt.Fprintln(stderr,"Error:",err); return cfg,true,1 }
            cfg.width=w; cfg.height=h
        case "-W", "--width": cfg.width = atoi(next())
        case "-H", "--height": cfg.height = atoi(next())
        case "-m", "--map": cfg.charMap = next(); if cfg.charMap=="" { cfg.charMap=" " }
        case "--threshold": cfg.threshold = atoi(next()); if cfg.threshold<0 {cfg.threshold=0}; if cfg.threshold>255 {cfg.threshold=255}
        case "--dither":
        case "--font-color": _ = next(); cfg.fontColor=true
        case "--save-bg", "--font": _ = next()
        case "--save-txt": cfg.saveTxt = next()
        case "-s", "--save-img": cfg.saveImg = next()
        case "--save-gif": cfg.saveGif = next()
        case "--only-save": cfg.onlySave=true
        default:
            if strings.HasPrefix(a,"--") || (strings.HasPrefix(a,"-") && a!="-") { fmt.Fprintf(stderr,"Error: unknown flag: %s\n",a); fmt.Fprint(stderr, helpText[strings.Index(helpText,"Usage:"):]); return cfg,true,1 }
            cfg.inputs = append(cfg.inputs, a)
        }
    }
    return cfg,false,0
}

func atoi(s string) int { n,_ := strconv.Atoi(s); return n }
func parsePair(s string) (int,int,error) { p:=strings.Split(s,","); if len(p)!=2 {return 0,0,errors.New("invalid argument")}; return atoi(p[0]), atoi(p[1]), nil }
func hasPipedStdin() bool { st,err:=os.Stdin.Stat(); return err==nil && (st.Mode()&os.ModeCharDevice)==0 }

func loadImage(path string, stdin io.Reader) (image.Image,string,error) {
    var data []byte; var err error; name := "stdin"
    if path == "-" { data, err = io.ReadAll(stdin) } else { data, err = os.ReadFile(path); name = strings.TrimSuffix(filepath.Base(path), filepath.Ext(path)) }
    if err != nil { return nil,name,err }
    if img, _, err := image.Decode(bytes.NewReader(data)); err == nil { return img,name,nil }
    if img, err := decodeBMP(data); err == nil { return img,name,nil }
    return nil,name,fmt.Errorf("unsupported image format")
}

func convert(img image.Image, cfg config) string {
    b := img.Bounds(); iw, ih := b.Dx(), b.Dy()
    w,h := cfg.width,cfg.height
    if w<=0 && h<=0 { w=iw; h=ih }
    if w<=0 { w = int(math.Round(float64(h)*float64(iw)/float64(ih))) }
    if h<=0 { h = int(math.Round(float64(w)*float64(ih)/float64(iw))) }
    if w<1 {w=1}; if h<1 {h=1}
    if cfg.braille { return convertBraille(img,w,h,cfg) }
    lines := make([]string,h)
    for oy:=0; oy<h; oy++ {
        var sb strings.Builder
        sy := oy; if cfg.flipY { sy = h-1-oy }
        for ox:=0; ox<w; ox++ {
            sx := ox; if cfg.flipX { sx = w-1-ox }
            lum := avgLum(img, b, sx, sy, w, h)
            if cfg.negative { lum = 255-lum }
            sb.WriteRune(mapRune(cfg.charMap, lum))
        }
        lines[oy]=sb.String()
    }
    return strings.Join(lines,"\n")
}

func avgLum(img image.Image, b image.Rectangle, ox, oy, ow, oh int) int {
    x0 := b.Min.X + int(math.Floor(float64(ox)*float64(b.Dx())/float64(ow)))
    x1 := b.Min.X + int(math.Floor(float64(ox+1)*float64(b.Dx())/float64(ow)))
    y0 := b.Min.Y + int(math.Floor(float64(oy)*float64(b.Dy())/float64(oh)))
    y1 := b.Min.Y + int(math.Floor(float64(oy+1)*float64(b.Dy())/float64(oh)))
    if x1<=x0 { x1=x0+1 }; if y1<=y0 { y1=y0+1 }
    var sum,count int
    for y:=y0; y<y1 && y<b.Max.Y; y++ { for x:=x0; x<x1 && x<b.Max.X; x++ { sum += luminance(img.At(x,y)); count++ } }
    if count==0 { return 0 }
    return int(math.Round(float64(sum)/float64(count)))
}

func luminance(c color.Color) int { r,g,b,_ := c.RGBA(); return int(math.Round(0.299*float64(r/257)+0.587*float64(g/257)+0.114*float64(b/257))) }
func mapRune(m string, lum int) rune { rs:=[]rune(m); if len(rs)==0 { return ' ' }; idx := lum*len(rs)/256; if idx>=len(rs){idx=len(rs)-1}; return rs[idx] }

func convertBraille(img image.Image, w,h int, cfg config) string {
    b := img.Bounds(); lines := make([]string,h)
    dots := []struct{dx,dy,bit int}{{0,0,1},{0,1,2},{0,2,4},{1,0,8},{1,1,16},{1,2,32},{0,3,64},{1,3,128}}
    for oy:=0; oy<h; oy++ { var sb strings.Builder; for ox:=0; ox<w; ox++ { code:=0; for _,d:= range dots { px:=b.Min.X+int((float64(ox*2+d.dx)+0.5)*float64(b.Dx())/float64(w*2)); py:=b.Min.Y+int((float64(oy*4+d.dy)+0.5)*float64(b.Dy())/float64(h*4)); if px>=b.Max.X {px=b.Max.X-1}; if py>=b.Max.Y {py=b.Max.Y-1}; lum:=luminance(img.At(px,py)); on:=lum > cfg.threshold; if cfg.negative { on=!on }; if on { code |= d.bit } }; sb.WriteRune(rune(0x2800+code)) }; lines[oy]=sb.String() }
    return strings.Join(lines,"\n")
}

func saveText(dir,name,art string) error { if dir=="." {dir=""}; path:=filepath.Join(dir, name+"-ascii-art.txt"); return os.WriteFile(path, []byte(art), 0644) }
func savePNGPlaceholder(dir,name,art string) error { if dir=="." {dir=""}; path:=filepath.Join(dir, name+"-ascii-art.png"); w:=max(1, len(firstLine(art))*8); h:=max(1, (strings.Count(art,"\n")+1)*14); img:=image.NewRGBA(image.Rect(0,0,w,h)); f,err:=os.Create(path); if err!=nil {return err}; defer f.Close(); return png.Encode(f,img) }
func saveGIFPlaceholder(dir,name string) error { if dir=="." {dir=""}; path:=filepath.Join(dir, name+"-ascii-art.gif"); img:=image.NewPaletted(image.Rect(0,0,1,1), []color.Color{color.Black}); f,err:=os.Create(path); if err!=nil {return err}; defer f.Close(); return gif.Encode(f,img,nil) }
func firstLine(s string) string { if i:=strings.IndexByte(s,'\n'); i>=0 { return s[:i]}; return s }
func max(a,b int) int { if a>b {return a}; return b }

func decodeBMP(data []byte) (image.Image,error) {
    if len(data)<54 || string(data[:2])!="BM" { return nil, errors.New("not bmp") }
    off:=le32(data[10:14]); w:=int(int32(le32(data[18:22]))); hRaw:=int(int32(le32(data[22:26]))); depth:=le16(data[28:30]); comp:=le32(data[30:34])
    if w<=0 || hRaw==0 || (depth!=24 && depth!=32) || comp!=0 { return nil, errors.New("unsupported bmp") }
    topDown:=hRaw<0; h:=hRaw; if h<0 {h=-h}
    img:=image.NewRGBA(image.Rect(0,0,w,h)); bytesPer:=int(depth/8); stride:=((w*bytesPer+3)/4)*4
    for y:=0; y<h; y++ { srcY:=y; if !topDown {srcY=h-1-y}; row:=int(off)+srcY*stride; for x:=0; x<w; x++ { p:=row+x*bytesPer; if p+2>=len(data){continue}; a:=byte(255); if bytesPer==4 && p+3<len(data){a=data[p+3]}; img.SetRGBA(x,y,color.RGBA{data[p+2],data[p+1],data[p],a}) } }
    return img,nil
}
func le16(b []byte) uint16 { return uint16(b[0])|uint16(b[1])<<8 }
func le32(b []byte) uint32 { return uint32(b[0])|uint32(b[1])<<8|uint32(b[2])<<16|uint32(b[3])<<24 }
