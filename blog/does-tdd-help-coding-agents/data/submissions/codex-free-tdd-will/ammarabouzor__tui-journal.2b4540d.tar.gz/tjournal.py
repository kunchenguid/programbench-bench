#!/usr/bin/env python3
import sys
import json
from pathlib import Path


VERSION = "tui-journal 0.16.1"


HELP = """Tui app allows writing and managing journals/notes from within the terminal With different local back-ends

Usage: executable [OPTIONS] [COMMAND]

Commands:
  print-config     Print the current settings including the paths for the back-end files [aliases: pc]
  import-journals  Import journals from the given transfer JSON file to the current back-end file [aliases: imj]
  assign-priority  Assign priority for all the entries with empty priority field [aliases: ap]
  theme            Provides commands regarding changing themes and styles of the app [aliases: style]
  help             Print this message or the help of the given subcommand(s)

Options:
  -j, --json-file-path <FILE PATH>    Sets the entries Json file path and starts using it
  -s, --sqlite-file-path <FILE PATH>  Sets the entries sqlite file path and starts using it
  -b, --backend-type <BACKEND_TYPE>   Sets the backend type and starts using it [possible values: json, sqlite]
  -c, --config <DIR PATH>             Specifies the path for the configuration directory.
                                      Configuration files is considered as root for themes file too.
                                      It still accepts the path for configuration file for backward compatibility.
                                      (default path: /home/agent/.config/tui-journal)
  -v, --verbose...                    Increases logging verbosity each use for up to 3 times
  -l, --log <FILE PATH>               Specifies a file to use for logging
                                      (default file: /home/agent/.cache/tui-journal/tui-journal.log)
  -h, --help                          Print help
  -V, --version                       Print version
"""

DEFAULT_THEME = """[general.input_block_active]
fg = "LightYellow"
modifiers = ""

[general.input_block_invalid]
fg = "LightRed"
modifiers = ""

[general.input_corsur_active]
fg = "Black"
bg = "LightYellow"
modifiers = ""

[general.input_corsur_invalid]
fg = "Black"
bg = "LightRed"
modifiers = ""

[general.list_item_selected]
fg = "LightYellow"
modifiers = "BOLD"

[general.list_highlight_active]
fg = "Black"
bg = "LightGreen"
modifiers = ""

[general.list_highlight_inactive]
fg = "Black"
bg = "LightBlue"
modifiers = ""

[journals_list.block_active]
fg = "Reset"
modifiers = "BOLD"

[journals_list.block_inactive]
fg = "#AAAAC8"
modifiers = ""

[journals_list.block_multi_select]
fg = "Yellow"
modifiers = "BOLD | ITALIC"

[journals_list.highlight_active]
fg = "Black"
bg = "LightGreen"
modifiers = "BOLD"

[journals_list.highlight_inactive]
fg = "Black"
bg = "LightBlue"
modifiers = "BOLD"

[journals_list.title_active]
fg = "Reset"
modifiers = "BOLD"

[journals_list.title_inactive]
fg = "#AAAAC8"
modifiers = "BOLD"

[journals_list.title_selected]
fg = "Yellow"
modifiers = "BOLD"

[journals_list.date_priority]
fg = "LightBlue"
modifiers = ""

[journals_list.tags_default]
fg = "LightCyan"
modifiers = "DIM"

[editor.block_insert]
fg = "LightGreen"
modifiers = "BOLD"

[editor.block_visual]
fg = "Blue"
modifiers = "BOLD"

[editor.block_normal_active]
fg = "Reset"
modifiers = "BOLD"

[editor.block_normal_inactive]
fg = "#AAAAC8"
modifiers = ""

[editor.cursor_normal]
fg = "Black"
bg = "White"
modifiers = ""

[editor.cursor_insert]
fg = "Black"
bg = "LightGreen"
modifiers = ""

[editor.cursor_visual]
fg = "Black"
bg = "Blue"
modifiers = ""

[editor.selection_style]
fg = "Black"
bg = "White"
modifiers = ""

[msgbox]
error = "LightRed"
warning = "Yellow"
info = "LightGreen"
question = "LightBlue"
"""

PRINT_CONFIG_HELP = """Print the current settings including the paths for the back-end files

Usage: executable print-config

Options:
  -h, --help  Print help
"""

IMPORT_HELP = """Import journals from the given transfer JSON file to the current back-end file

Usage: executable import-journals --path <FILE PATH>

Options:
  -p, --path <FILE PATH>  Path of the JSON file to import from
  -h, --help              Print help
"""

ASSIGN_HELP = """Assign priority for all the entries with empty priority field

Usage: executable assign-priority <PRIORITY>

Arguments:
  <PRIORITY>  Priority value (Positive number)

Options:
  -h, --help  Print help
"""


def default_config():
    return {
        "backend_type": "Sqlite",
        "scroll_per_page": 5,
        "sync_os_clipboard": False,
        "history_limit": 10,
        "colored_tags": True,
        "datum_visibility": "show",
        "app_state_dir": "/home/agent/.local/state/tui-journal",
        "export_show_confirmation": True,
        "external_auto_save": False,
        "external_temp_file_extension": "txt",
        "json_file_path": "/home/agent/tui-journal/entries.json",
        "sqlite_file_path": "/home/agent/tui-journal/entries.db",
    }


def bool_s(value):
    return "true" if value else "false"


def print_config(cfg):
    lines = [
        f'backend_type = "{cfg["backend_type"]}"',
        f'scroll_per_page = {cfg["scroll_per_page"]}',
        f'sync_os_clipboard = {bool_s(cfg["sync_os_clipboard"])}',
        f'history_limit = {cfg["history_limit"]}',
        f'colored_tags = {bool_s(cfg["colored_tags"])}',
        f'datum_visibility = "{cfg["datum_visibility"]}"',
        f'app_state_dir = "{cfg["app_state_dir"]}"',
        "",
        "[export]",
        f'show_confirmation = {bool_s(cfg["export_show_confirmation"])}',
        "",
        "[external_editor]",
        f'auto_save = {bool_s(cfg["external_auto_save"])}',
        f'temp_file_extension = "{cfg["external_temp_file_extension"]}"',
        "",
        "[json_backend]",
        f'file_path = "{cfg["json_file_path"]}"',
        "",
        "[sqlite_backend]",
        f'file_path = "{cfg["sqlite_file_path"]}"',
        "",
    ]
    print("\n".join(lines))


def theme_help():
    print(
        """Provides commands regarding changing themes and styles of the app

Usage: executable theme <COMMAND>

Commands:
  print-path      Prints the path to the user themes file [aliases: path]
  print-default   Dumps the styles with the default values to be used as a reference and base for user custom themes [aliases: default]
  write-defaults  Creates user custom themes file if doesn't exist then writes the default styles to it [aliases: write]
  help            Print this message or the help of the given subcommand(s)

Options:
  -h, --help  Print help
"""
    )


def handle_theme(args, config_dir):
    if not args or args[0] in ("--help", "-h", "help"):
        theme_help()
        return 0
    theme_path = Path(config_dir) / "themes.toml"
    if args[0] in ("print-path", "path"):
        print(theme_path)
        return 0
    if args[0] in ("print-default", "default"):
        print(DEFAULT_THEME, end="")
        return 0
    if args[0] in ("write-defaults", "write"):
        try:
            theme_path.write_text(DEFAULT_THEME)
        except OSError:
            print("Error: Error while writing default themes to file", file=sys.stderr)
            return 1
        print(f"Default themes have been written to {theme_path}")
        return 0
    print(f"error: unrecognized subcommand '{args[0]}'", file=sys.stderr)
    print("\nUsage: executable theme <COMMAND>\n\nFor more information, try '--help'.", file=sys.stderr)
    return 2


def load_entries(path):
    p = Path(path)
    if not p.exists():
        return []
    text = p.read_text().strip()
    if not text:
        return []
    data = json.loads(text)
    if isinstance(data, list):
        return data
    if isinstance(data, dict):
        for key in ("journals", "entries", "items"):
            if isinstance(data.get(key), list):
                return data[key]
    return []


def save_entries(path, entries):
    p = Path(path)
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(json.dumps(entries, indent=2, ensure_ascii=False) + "\n")


def extract_transfer_entries(data):
    if isinstance(data, list):
        return data
    if isinstance(data, dict):
        for key in ("journals", "entries", "items"):
            value = data.get(key)
            if isinstance(value, list):
                return value
    return []


def handle_import(args, cfg):
    if args and args[0] in ("--help", "-h", "help"):
        print(IMPORT_HELP, end="")
        return 0
    path = None
    i = 0
    while i < len(args):
        if args[i] in ("-p", "--path"):
            i += 1
            if i < len(args):
                path = args[i]
        i += 1
    if not path:
        print("error: the following required arguments were not provided:\n  --path <FILE PATH>", file=sys.stderr)
        return 2
    try:
        transfer = json.loads(Path(path).read_text())
        imported = extract_transfer_entries(transfer)
        entries = load_entries(cfg["json_file_path"])
        entries.extend(imported)
        save_entries(cfg["json_file_path"], entries)
    except OSError as exc:
        print(f"Error: {exc}", file=sys.stderr)
        return 1
    except json.JSONDecodeError as exc:
        print(f"Error: {exc}", file=sys.stderr)
        return 1
    noun = "journal" if len(imported) == 1 else "journals"
    print(f"Imported {len(imported)} {noun}")
    return 0


def handle_assign_priority(args, cfg):
    if args and args[0] in ("--help", "-h", "help"):
        print(ASSIGN_HELP, end="")
        return 0
    if not args:
        print(
            "error: the following required arguments were not provided:\n  <PRIORITY>\n\n"
            "Usage: executable assign-priority <PRIORITY>\n\nFor more information, try '--help'.",
            file=sys.stderr,
        )
        return 2
    try:
        priority = int(args[0])
    except ValueError as exc:
        print(
            f"error: invalid value '{args[0]}' for '<PRIORITY>': {exc}\n\n"
            "For more information, try '--help'.",
            file=sys.stderr,
        )
        return 2
    try:
        entries = load_entries(cfg["json_file_path"])
        changed = 0
        for entry in entries:
            if isinstance(entry, dict) and entry.get("priority") in (None, ""):
                entry["priority"] = priority
                changed += 1
        save_entries(cfg["json_file_path"], entries)
    except OSError as exc:
        print(f"Error: {exc}", file=sys.stderr)
        return 1
    print(f"Assigned priority {priority} to {changed} journals")
    return 0


def parse_scalar(value):
    value = value.strip()
    if value.startswith('"') and value.endswith('"'):
        return value[1:-1]
    if value == "true":
        return True
    if value == "false":
        return False
    try:
        return int(value)
    except ValueError:
        return value


def load_config_dir(path, cfg):
    p = Path(path)
    if p.name == "config.toml":
        p = p.parent
    if not p.exists() or not p.is_dir():
        raise FileNotFoundError(f"Provided custom directory doesn't exit. Path: {path}")
    config_file = p / "config.toml"
    if not config_file.exists():
        return str(p)
    section = ""
    for raw in config_file.read_text().splitlines():
        line = raw.split("#", 1)[0].strip()
        if not line:
            continue
        if line.startswith("[") and line.endswith("]"):
            section = line[1:-1]
            continue
        if "=" not in line:
            continue
        key, value = [part.strip() for part in line.split("=", 1)]
        parsed = parse_scalar(value)
        if not section and key in cfg:
            cfg[key] = parsed
        elif section == "json_backend" and key == "file_path":
            cfg["json_file_path"] = parsed
        elif section == "sqlite_backend" and key == "file_path":
            cfg["sqlite_file_path"] = parsed
        elif section == "external_editor" and key == "auto_save":
            cfg["external_auto_save"] = parsed
        elif section == "external_editor" and key == "temp_file_extension":
            cfg["external_temp_file_extension"] = parsed
        elif section == "export" and key == "show_confirmation":
            cfg["export_show_confirmation"] = parsed
    if cfg["backend_type"].lower() == "json":
        cfg["backend_type"] = "Json"
    elif cfg["backend_type"].lower() == "sqlite":
        cfg["backend_type"] = "Sqlite"
    return str(p)


def parse_args(argv):
    cfg = default_config()
    config_dir = "/home/agent/.config/tui-journal"
    command = []
    i = 0
    while i < len(argv):
        arg = argv[i]
        if arg in ("-j", "--json-file-path"):
            i += 1
            cfg["json_file_path"] = argv[i]
            cfg["backend_type"] = "Json"
        elif arg in ("-s", "--sqlite-file-path"):
            i += 1
            cfg["sqlite_file_path"] = argv[i]
            cfg["backend_type"] = "Sqlite"
        elif arg in ("-b", "--backend-type"):
            i += 1
            value = argv[i]
            if value not in ("json", "sqlite"):
                print(
                    f"error: invalid value '{value}' for '--backend-type <BACKEND_TYPE>'\n"
                    "  [possible values: json, sqlite]\n\n"
                    "For more information, try '--help'.",
                    file=sys.stderr,
                )
                raise SystemExit(2)
            cfg["backend_type"] = "Json" if value == "json" else "Sqlite"
        elif arg in ("-c", "--config"):
            i += 1
            try:
                config_dir = load_config_dir(argv[i], cfg)
            except FileNotFoundError as exc:
                print(f"Error: {exc}", file=sys.stderr)
                raise SystemExit(1)
        elif arg in ("-l", "--log"):
            i += 1
        elif arg.startswith("-v") and set(arg[1:]) == {"v"}:
            pass
        else:
            command = argv[i:]
            break
        i += 1
    return cfg, config_dir, command


def main(argv):
    if not argv:
        print("Error: No such device or address (os error 6)", file=sys.stderr)
        return 1
    if argv[0] in ("--version", "-V"):
        print(VERSION)
        return 0
    if argv[0] in ("--help", "-h", "help"):
        print(HELP, end="")
        return 0
    cfg, config_dir, command = parse_args(argv)
    if not command:
        print("Error: No such device or address (os error 6)", file=sys.stderr)
        return 1
    if command[0] in ("print-config", "pc"):
        if len(command) > 1 and command[1] in ("--help", "-h", "help"):
            print(PRINT_CONFIG_HELP, end="")
            return 0
        print_config(cfg)
        return 0
    if command[0] in ("theme", "style"):
        return handle_theme(command[1:], config_dir)
    if command[0] in ("import-journals", "imj"):
        return handle_import(command[1:], cfg)
    if command[0] in ("assign-priority", "ap"):
        return handle_assign_priority(command[1:], cfg)
    print(f"error: unrecognized subcommand '{command[0]}'", file=sys.stderr)
    return 2


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
