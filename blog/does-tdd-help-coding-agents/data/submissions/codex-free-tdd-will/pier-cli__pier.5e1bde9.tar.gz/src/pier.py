#!/usr/bin/env python3
import os, sys, subprocess
from pathlib import Path
try:
    import tomllib
except Exception:
    tomllib = None

VERSION = 'pier 0.1.6'
MAIN_HELP = '''pier 0.1.6
Benjamin Scholtz, Isak Johansson
A simple script management CLI

USAGE:
    executable [FLAGS] [OPTIONS] <alias> [args]...
    executable [FLAGS] [OPTIONS] <SUBCOMMAND>

FLAGS:
    -h, --help       
            Prints help information

    -V, --version    
            Prints version information

    -v, --verbose    
            The level of verbosity


OPTIONS:
    -c, --config-file <path>    
            Sets a custom config file.
            
            DEFAULT PATH is otherwise determined in this order:
            
            - $PIER_CONFIG_PATH (environment variable if set)
            
            - pier.toml (in the current directory)
            
            - $XDG_CONFIG_HOME/pier/config.toml
            
            - $XDG_CONFIG_HOME/pier/config
            
            - $XDG_CONFIG_HOME/pier.toml
            
            - $HOME/.pier.toml
            
            - $HOME/.pier
            
             [env: PIER_CONFIG_PATH=]

ARGS:
    <alias>      
            The alias or name for the script.

    <args>...    
            The positional arguments to send to script.


SUBCOMMANDS:
    add            Add a new script to config.
    config-init    alias: init - Add a config file.
    copy           alias: cp - Copy existing alias to the new one
    edit           Edit a script matching alias.
    help           Prints this message or the help of the given subcommand(s)
    list           alias: ls - List scripts
    move           alias: mv, rename - Move/rename existing alias to the new one
    remove         alias: rm - Remove a script matching alias.
    run            Run a script matching alias.
    show           Show a script matching alias.
'''
DEFAULT_CONFIG = "[scripts.hello-pier]\ncommand = 'echo Hello, Pier!'\ndescription = 'This is an example command.'\n\n[default]\n"
ALIASES = {'ls':'list','rm':'remove','cp':'copy','mv':'move','rename':'move','init':'config-init'}

HELP_TEXT = {
'add': '''executable-add 0.1.6
Add a new script to config.

USAGE:
    executable add [FLAGS] [OPTIONS] --alias <alias> [--] [command]

FLAGS:
    -f, --force      Allows to overwrite the existing script
    -h, --help       Prints help information
    -V, --version    Prints version information

OPTIONS:
    -a, --alias <alias>                The alias or name for the script.
    -d, --description <description>    The description for the script.
    -t, --tag <tags>...                Set which tags the script belongs to.

ARGS:
    <command>    The command/script content to be executed. If this argument is not found it will open your $EDITOR
                 for you to enter the script into.
''',
'list': '''executable-list 0.1.6
alias: ls - List scripts

Display options are determined by priority in this order:

1. List only aliases

2. Show full command

3. Command display with (cli option)

4. Command display with (config option)

USAGE:
    executable list [FLAGS] [OPTIONS]

FLAGS:
    -l, --cmd_full        Display the full command.
    -h, --help            Prints help information
    -q, --list_aliases    Only displays aliases of the scripts.
    -V, --version         Prints version information

OPTIONS:
    -c, --cmd_width <cmd-width>    The max number of characters to display from the command.
    -t, --tag <tags>...            Filter based on tags.
'''}

def parse_string_value(v):
    v = v.strip().rstrip(',').strip()
    if len(v) >= 2 and v[0] == v[-1] and v[0] in ('"', "'"):
        body = v[1:-1]
        if v[0] == '"':
            body = body.replace('\\n', '\n').replace('\\"', '"').replace('\\\\', '\\')
        else:
            body = body.replace("\\'", "'").replace('\\\\', '\\')
        return body
    return v

def parse_toml_subset(text):
    data = {}
    section = None
    current_array = None
    array_values = []
    for raw in text.splitlines():
        line = raw.strip()
        if not line or line.startswith('#'):
            continue
        if current_array:
            if line.startswith(']'):
                section[current_array] = array_values
                current_array = None
                array_values = []
            else:
                array_values.append(parse_string_value(line))
            continue
        if line.startswith('[') and line.endswith(']'):
            name = line[1:-1].strip()
            if name.startswith('scripts.'):
                alias = name.split('.', 1)[1]
                data.setdefault('scripts', {})[alias] = {}
                section = data['scripts'][alias]
            else:
                data[name] = {}
                section = data[name]
            continue
        if '=' in line and section is not None:
            k, v = line.split('=', 1)
            key = k.strip().replace('-', '_')
            v = v.strip()
            if v == '[':
                current_array = key
                array_values = []
            elif v.startswith('[') and v.endswith(']'):
                inner = v[1:-1].strip()
                if inner:
                    section[key] = [parse_string_value(part) for part in inner.split(',') if part.strip()]
                else:
                    section[key] = []
            else:
                section[key] = parse_string_value(v)
    return data

def default_config_path(for_create=False):
    env = os.environ.get('PIER_CONFIG_PATH')
    if env:
        return Path(env)
    cwd = Path.cwd() / 'pier.toml'
    if cwd.exists():
        return cwd
    xdg = os.environ.get('XDG_CONFIG_HOME')
    if xdg:
        for rel in ('pier/config.toml', 'pier/config', 'pier.toml'):
            p = Path(xdg) / rel
            if p.exists():
                return p
        return Path(xdg) / 'pier' / 'config.toml' if for_create else None
    home = os.environ.get('HOME', '')
    if home:
        for rel in ('.pier.toml', '.pier'):
            p = Path(home) / rel
            if p.exists():
                return p
    return None

def parse_global(argv):
    cfg = None; out = []; i = 0
    while i < len(argv):
        a = argv[i]
        if a in ('-c','--config-file') and i+1 < len(argv):
            cfg = Path(argv[i+1]); i += 2
        elif a in ('-v','--verbose'):
            i += 1
        else:
            out.extend(argv[i:]); break
    return cfg, out

def load_config(path):
    if path is None:
        path = default_config_path(False)
    if path is None:
        raise FileNotFoundError('DEFAULT')
    try:
        data = path.read_bytes()
    except OSError as e:
        raise e
    text = data.decode()
    parsed = tomllib.loads(text) if tomllib else parse_toml_subset(text)
    scripts = parsed.get('scripts', {}) if isinstance(parsed.get('scripts', {}), dict) else {}
    default = parsed.get('default', {}) if isinstance(parsed.get('default', {}), dict) else {}
    clean = {}
    for k, v in scripts.items():
        if isinstance(v, dict):
            clean[k] = {'command': str(v.get('command','')), 'description': str(v.get('description','')), 'tags': [str(x) for x in v.get('tags', [])]}
    return path, clean, default

def q(s):
    return "'" + str(s).replace('\\', '\\\\').replace("'", "\\'") + "'"

def write_config(path, scripts, default=None):
    default = default or {}
    parts = []
    for alias in sorted(scripts):
        ent = scripts[alias]
        parts.append(f'[scripts.{alias}]\n')
        parts.append(f"command = {q(ent.get('command',''))}\n")
        if ent.get('description'):
            parts.append(f"description = {q(ent.get('description',''))}\n")
        tags = ent.get('tags') or []
        if tags:
            parts.append('tags = [\n')
            for t in tags:
                parts.append(f'    {q(t)},\n')
            parts.append(']\n')
        parts.append('\n')
    parts.append('[default]\n')
    path.write_text(''.join(parts))

def print_config_error(e, path=None):
    if isinstance(e, FileNotFoundError) and str(e) == 'DEFAULT':
        print('error: No default config file found. See help for more info.', file=sys.stderr)
    elif isinstance(e, FileNotFoundError):
        print(f'error: Unable to read config from file {path}: No such file or directory (os error 2) ', file=sys.stderr)
    else:
        print(f'error: {e}', file=sys.stderr)

def cmd_config_init():
    path = default_config_path(True)
    if path is None:
        print('error: Failed to create directory. No such file or directory (os error 2)', file=sys.stderr); return 1
    try:
        if not path.parent.exists(): os.mkdir(path.parent)
        path.write_text(DEFAULT_CONFIG)
    except OSError as e:
        print(f'error: Failed to create directory. {e.strerror} (os error {e.errno})', file=sys.stderr); return 1
    print('Added hello-pier'); return 0

def cmd_add(argv, cfg):
    alias = desc = None; tags = []; force = False; cmd = None; i = 0
    while i < len(argv):
        a = argv[i]
        if a in ('-h','--help'): sys.stdout.write(HELP_TEXT['add']); return 0
        if a in ('-V','--version'): print('executable-add 0.1.6'); return 0
        if a in ('-f','--force'): force = True; i += 1; continue
        if a in ('-a','--alias') and i+1 < len(argv): alias = argv[i+1]; i += 2; continue
        if a in ('-d','--description') and i+1 < len(argv): desc = argv[i+1]; i += 2; continue
        if a in ('-t','--tag') and i+1 < len(argv): tags.append(argv[i+1]); i += 2; continue
        if a == '--': cmd = ' '.join(argv[i+1:]); break
        cmd = ' '.join(argv[i:]); break
    if not alias:
        print('error: The following required arguments were not provided:', file=sys.stderr); return 1
    try: path, scripts, default = load_config(cfg)
    except Exception as e: print_config_error(e, cfg); return 1
    if alias in scripts and not force:
        print(f'error: AliasAlreadyExists:  {alias}', file=sys.stderr); return 1
    scripts[alias] = {'command': cmd or '', 'description': desc or '', 'tags': tags}
    write_config(path, scripts, default)
    print(f'Added {alias}')
    return 0

def filtered_scripts(scripts, tags):
    if not tags: return scripts
    return {a:e for a,e in scripts.items() if any(t in (e.get('tags') or []) for t in tags)}

def cmd_list(argv, cfg):
    if argv and argv[0] in ('-h','--help'):
        sys.stdout.write(HELP_TEXT['list']); return 0
    aliases_only = False; full = False; width = None; tags = []; i=0
    while i < len(argv):
        a=argv[i]
        if a in ('-q','--list_aliases'): aliases_only=True; i+=1
        elif a in ('-l','--cmd_full'): full=True; i+=1
        elif a in ('-c','--cmd_width') and i+1 < len(argv): width=int(argv[i+1]); i+=2
        elif a in ('-t','--tag') and i+1 < len(argv): tags.append(argv[i+1]); i+=2
        else: i+=1
    try: path, scripts, default = load_config(cfg)
    except Exception as e: print_config_error(e, cfg); return 1
    scripts = filtered_scripts(scripts, tags)
    if aliases_only:
        for a in sorted(scripts): print(a)
        return 0
    rows = []
    for a in sorted(scripts):
        e=scripts[a]; c=e.get('command','')
        if width is not None and not full: c=c[:width]
        rows.append([a, ','.join(e.get('tags') or []), c, e.get('description','')])
    print_table(['Alias','Tags','Command','Description'], rows)
    return 0

def print_table(headers, rows):
    widths=[len(h) for h in headers]
    for r in rows:
        for i,v in enumerate(r): widths[i]=max(widths[i], len(v))
    total=sum(widths)+3*len(widths)+1
    line='≖'*total
    def row(vals): return '⋮ ' + ' ⋮ '.join(str(v).ljust(widths[i]) for i,v in enumerate(vals)) + ' ⋮'
    print(line); print(row(headers)); print(line)
    for r in rows: print(row(r))
    print(line)

def cmd_show(argv, cfg):
    if not argv: return 1
    alias = argv[0]
    try: path, scripts, default = load_config(cfg)
    except Exception as e: print_config_error(e, cfg); return 1
    if alias not in scripts:
        print(f'error: AliasNotFound: No script found by alias {alias}', file=sys.stderr); return 1
    print(scripts[alias].get('command',''))
    return 0

def alias_not_found(alias):
    print(f'error: AliasNotFound: No script found by alias {alias}', file=sys.stderr)
    return 1

def cmd_remove(argv, cfg):
    if not argv: return 1
    alias = argv[0]
    try: path, scripts, default = load_config(cfg)
    except Exception as e: print_config_error(e, cfg); return 1
    if alias not in scripts: return alias_not_found(alias)
    del scripts[alias]
    write_config(path, scripts, default)
    print(f'Removed {alias}')
    return 0

def cmd_copy(argv, cfg):
    if len(argv) < 2: return 1
    src, dst = argv[0], argv[1]
    try: path, scripts, default = load_config(cfg)
    except Exception as e: print_config_error(e, cfg); return 1
    if src not in scripts: return alias_not_found(src)
    if dst in scripts:
        print(f'error: AliasAlreadyExists:  {dst}', file=sys.stderr); return 1
    scripts[dst] = dict(scripts[src])
    scripts[dst]['tags'] = list(scripts[src].get('tags') or [])
    write_config(path, scripts, default)
    print(f'Copy from alias {src} to new alias {dst}')
    return 0

def cmd_move(argv, cfg):
    force = False
    if argv and argv[0] in ('-f','--force'):
        force = True; argv = argv[1:]
    if len(argv) < 2: return 1
    src, dst = argv[0], argv[1]
    try: path, scripts, default = load_config(cfg)
    except Exception as e: print_config_error(e, cfg); return 1
    if src not in scripts: return alias_not_found(src)
    if dst in scripts and not force:
        print(f'error: AliasAlreadyExists:  {dst}', file=sys.stderr); return 1
    scripts[dst] = scripts[src]
    if src != dst: del scripts[src]
    write_config(path, scripts, default)
    print(f'Move from alias {src} to new alias {dst}')
    return 0

def cmd_run(argv, cfg):
    if len(argv) < 1: return 1
    alias, args = argv[0], argv[1:]
    try: path, scripts, default = load_config(cfg)
    except Exception as e: print_config_error(e, cfg); return 1
    if alias not in scripts: return alias_not_found(alias)
    return subprocess.call(['/bin/sh', '-c', scripts[alias].get('command',''), alias] + args)

def cmd_edit(argv, cfg):
    if not argv: return 1
    alias = argv[0]
    try: path, scripts, default = load_config(cfg)
    except Exception as e: print_config_error(e, cfg); return 1
    if alias not in scripts: return alias_not_found(alias)
    editor = os.environ.get('EDITOR')
    if editor:
        tmp = Path(os.environ.get('TMPDIR', '/tmp')) / f'pier-{os.getpid()}-{alias}.sh'
        tmp.write_text(scripts[alias].get('command',''))
        rc = subprocess.call([editor, str(tmp)])
        if rc != 0:
            try: tmp.unlink()
            except OSError: pass
            return rc
        try:
            scripts[alias]['command'] = tmp.read_text()
            tmp.unlink()
        except OSError:
            pass
    write_config(path, scripts, default)
    print(f'Edited {alias}')
    return 0

def main(argv):
    cfg, argv = parse_global(argv)
    if argv and argv[0] == '--': argv = argv[1:]
    if not argv or argv[0] in ('-h', '--help', 'help'):
        if len(argv) >= 2 and ALIASES.get(argv[1], argv[1]) in HELP_TEXT:
            sys.stdout.write(HELP_TEXT[ALIASES.get(argv[1], argv[1])]); return 0
        sys.stdout.write(MAIN_HELP); return 0
    if argv[0] in ('-V', '--version'):
        print(VERSION); return 0
    cmd = ALIASES.get(argv[0], argv[0])
    rest = argv[1:]
    if cmd == 'config-init': return cmd_config_init()
    if cmd == 'add': return cmd_add(rest, cfg)
    if cmd == 'list': return cmd_list(rest, cfg)
    if cmd == 'show': return cmd_show(rest, cfg)
    if cmd == 'remove': return cmd_remove(rest, cfg)
    if cmd == 'copy': return cmd_copy(rest, cfg)
    if cmd == 'move': return cmd_move(rest, cfg)
    if cmd == 'run': return cmd_run(rest, cfg)
    if cmd == 'edit': return cmd_edit(rest, cfg)
    if cmd not in ('add','list','show','remove','copy','move','run','config-init') and rest is not None:
        return cmd_run([cmd] + rest, cfg)
    print(f"error: The subcommand '{cmd}' wasn't recognized", file=sys.stderr)
    return 1

if __name__ == '__main__':
    raise SystemExit(main(sys.argv[1:]))
