#!/bin/bash
set -e
rm -f executable
cp src/pier.py executable
chmod +x executable
