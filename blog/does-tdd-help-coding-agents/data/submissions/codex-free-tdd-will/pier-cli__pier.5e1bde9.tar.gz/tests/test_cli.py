#!/usr/bin/env python3
import os, subprocess, tempfile, pathlib, textwrap, sys

ROOT = pathlib.Path(__file__).resolve().parents[1]
BIN = ROOT / 'executable'

def run(args, cwd=None, env=None):
    e = os.environ.copy()
    e.pop('PIER_CONFIG_PATH', None)
    if env:
        e.update(env)
    return subprocess.run([str(BIN)] + args, cwd=cwd, env=e, text=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)

def assert_eq(got, expected):
    if got != expected:
        raise AssertionError(f'got {got!r}, expected {expected!r}')

def test_version_and_help_tracer():
    p = run(['--version'])
    assert_eq(p.returncode, 0)
    assert_eq(p.stdout, 'pier 0.1.6\n')
    h = run(['--help'])
    assert_eq(h.returncode, 0)
    assert 'A simple script management CLI' in h.stdout
    assert 'SUBCOMMANDS:' in h.stdout


def test_config_init_creates_default_xdg_config():
    with tempfile.TemporaryDirectory() as td:
        home = pathlib.Path(td) / 'home'
        xdg = pathlib.Path(td) / 'xdg'
        home.mkdir(); xdg.mkdir()
        p = run(['config-init'], cwd=td, env={'HOME': str(home), 'XDG_CONFIG_HOME': str(xdg)})
        assert_eq(p.returncode, 0)
        assert_eq(p.stdout, 'Added hello-pier\n')
        assert_eq(p.stderr, '')
        cfg = xdg / 'pier' / 'config.toml'
        assert cfg.exists()
        assert_eq(cfg.read_text(), "[scripts.hello-pier]\ncommand = 'echo Hello, Pier!'\ndescription = 'This is an example command.'\n\n[default]\n")


def test_add_list_aliases_and_show_use_config_file():
    with tempfile.TemporaryDirectory() as td:
        cfg = pathlib.Path(td) / 'cfg.toml'
        cfg.write_text('[default]\n')
        p = run(['-c', str(cfg), 'add', '-a', 'hello', '-d', 'Greeting script', '-t', 'greet', '-t', 'demo', '--', 'echo Hello'], cwd=td)
        assert_eq(p.returncode, 0)
        assert_eq(p.stdout, 'Added hello\n')
        assert "[scripts.hello]" in cfg.read_text()
        q = run(['-c', str(cfg), 'list', '-q'], cwd=td)
        assert_eq(q.returncode, 0)
        assert_eq(q.stdout, 'hello\n')
        sh = run(['-c', str(cfg), 'show', 'hello'], cwd=td)
        assert_eq(sh.returncode, 0)
        assert_eq(sh.stdout, 'echo Hello\n')


def test_run_passes_positional_args_to_shell_script():
    with tempfile.TemporaryDirectory() as td:
        cfg = pathlib.Path(td) / 'pier.toml'
        cfg.write_text("""[scripts.echoer]
command = 'printf "A:%s B:%s\\n" "$1" "$2"'
""")
        p = run(['run', 'echoer', 'one', 'two'], cwd=td)
        assert_eq(p.returncode, 0)
        assert_eq(p.stdout, 'A:one B:two\n')
        q = run(['--', 'echoer', 'red', 'blue'], cwd=td)
        assert_eq(q.returncode, 0)
        assert_eq(q.stdout, 'A:red B:blue\n')


def test_copy_move_remove_mutate_config():
    with tempfile.TemporaryDirectory() as td:
        cfg = pathlib.Path(td) / 'cfg.toml'
        cfg.write_text('[scripts.a]\ncommand = "echo A"\n\n[default]\n')
        cp = run(['-c', str(cfg), 'copy', 'a', 'b'], cwd=td)
        assert_eq(cp.returncode, 0)
        assert_eq(cp.stdout, 'Copy from alias a to new alias b\n')
        mv = run(['-c', str(cfg), 'move', 'b', 'c'], cwd=td)
        assert_eq(mv.returncode, 0)
        assert_eq(mv.stdout, 'Move from alias b to new alias c\n')
        rm = run(['-c', str(cfg), 'remove', 'c'], cwd=td)
        assert_eq(rm.returncode, 0)
        assert_eq(rm.stdout, 'Removed c\n')
        txt = cfg.read_text()
        assert '[scripts.a]' in txt
        assert '[scripts.c]' not in txt

if __name__ == '__main__':
    tests = [v for k, v in sorted(globals().items()) if k.startswith('test_')]
    for t in tests:
        t()
    print(f'{len(tests)} tests passed')
