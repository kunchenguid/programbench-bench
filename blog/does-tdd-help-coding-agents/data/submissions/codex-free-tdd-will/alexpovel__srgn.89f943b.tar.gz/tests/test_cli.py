#!/usr/bin/env python3
import subprocess
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
BIN = ROOT / "src" / "srgn.py"

def run(args, data=""):
    p = subprocess.run([sys.executable, str(BIN), *args], input=data, text=True, capture_output=True)
    return p.returncode, p.stdout, p.stderr

def test_basic_replacement():
    code, out, err = run(["[wW]orld", "--", "there"], "Hello World!\n")
    assert code == 0
    assert out == "Hello there!\n"
    assert err == ""

def test_replacement_then_uppercase():
    code, out, err = run(["--upper", "[wW]orld", "--", "you"], "Hello World!\n")
    assert code == 0
    assert out == "Hello YOU!\n"
    assert err == ""

def test_delete_and_squeeze():
    assert run(["-d", "a"], "aaabaaa\n")[:2] == (0, "b\n")
    assert run(["-s", "a"], "aaabaaa\n")[:2] == (0, "aba\n")

def test_literal_and_capture_replacement():
    assert run(["-L", "a.b", "--", "X"], "a.b aab\n")[:2] == (0, "X aab\n")
    assert run(["([a-z]+)([0-9]+)", "--", "X$2-$1"], "abc123abc\n")[:2] == (0, "X123-abcabc\n")

def test_case_normalize_symbols_german():
    assert run(["-t", "[a-z]+"], "hello world\n")[:2] == (0, "Hello World\n")
    assert run(["-n", ".*"], "áéö ÄÖÜ ß\n")[:2] == (0, "aeo AOU ß\n")
    assert run(["-S"], "x != y -> z <= q >= r\n")[:2] == (0, "x ≠ y → z ≤ q ≥ r\n")
    assert run(["-g", "--german-naive"], "ae oe ue ss\n")[:2] == (0, "ä ö ü ß\n")

def test_fail_flags():
    code, out, err = run(["--fail-any", "one"], "one two\n")
    assert code == 1
    assert out == ""
    assert "Some input was in scope" in err
    code, out, err = run(["--fail-none", "zzz"], "one two\n")
    assert code == 1
    assert out == ""
    assert "No input was in scope" in err

def test_python_language_scope_search_and_replace():
    src = "class Bird:\n    age: int\n    def grow(self):\n        self.age += 1\nname=age\n"
    code, out, err = run(["--python", "class", "age"], src)
    assert code == 0
    assert out == "(stdin):2:4-7:    age: int\n(stdin):4:13-16:        self.age += 1\n"
    assert err == ""
    code, out, err = run(["--python", "comments", "hello", "--", "HI"], "# hello\nx=\"hello\" # tail\n")
    assert code == 0
    assert out == "# HI\nx=\"hello\" # tail\n"

def test_rust_language_scope_replace():
    code, out, err = run(["--rust", "strings", "hello", "--", "HI"], "// hello\nlet s=\"hello\";\n")
    assert code == 0
    assert out == "// hello\nlet s=\"HI\";\n"

def test_glob_replacement_updates_files_and_prints_paths():
    with tempfile.TemporaryDirectory() as d:
        root = Path(d)
        (root / "sub").mkdir()
        target = root / "sub" / "b.rs"
        target.write_text("hello rust\n")
        p = subprocess.run(
            [sys.executable, str(BIN), "-G", "**/*.rs", "hello", "--", "HI"],
            cwd=root,
            text=True,
            capture_output=True,
        )
        assert p.returncode == 0
        assert p.stdout == "sub/b.rs\n"
        assert p.stderr == ""
        assert target.read_text() == "HI rust\n"

if __name__ == "__main__":
    failures = 0
    for name, fn in sorted(globals().items()):
        if name.startswith("test_"):
            try:
                fn()
                print(f"ok {name}")
            except Exception as e:
                failures += 1
                print(f"not ok {name}: {e}")
    raise SystemExit(1 if failures else 0)
