#!/usr/bin/env python3
import glob
import os
import re
import sys
import unicodedata
from dataclasses import dataclass, field
from pathlib import Path


HELP = """A grep-like tool which understands source code syntax and allows for manipulation in
addition to search

Usage: executable [OPTIONS] [SCOPE] [-- <REPLACEMENT>]

Arguments:
  [SCOPE]  Scope to apply to, as a regular expression pattern. [default: .*]

Options:
      --completions <SHELL>  Print shell completions for the given shell. [possible values: bash, elvish, fish, powershell, zsh]
  -h, --help                 Print help (see more with '--help')
  -V, --version              Print version
"""


LANG_FLAGS = {
    "--python": "python", "--py": "python",
    "--rust": "rust", "--rs": "rust",
    "--go": "go", "--typescript": "typescript", "--ts": "typescript",
    "--c": "c", "--csharp": "csharp", "--cs": "csharp", "--hcl": "hcl",
}


@dataclass
class Opts:
    upper: bool = False
    lower: bool = False
    title: bool = False
    normalize: bool = False
    german: bool = False
    german_naive: bool = False
    symbols: bool = False
    invert: bool = False
    delete: bool = False
    squeeze: bool = False
    literal: bool = False
    fail_any: bool = False
    fail_none: bool = False
    line_numbers: bool = False
    only_matching: bool = False
    sorted: bool = False
    hidden: bool = False
    gitignored: bool = False
    dry_run: bool = False
    fail_no_files: bool = False
    force_unreadable: bool = False
    glob_pat: str | None = None
    scope: str | None = None
    replacement: str | None = None
    lang_scopes: list[tuple[str, str]] = field(default_factory=list)


def die(msg: str, code: int = 2) -> None:
    print(msg, file=sys.stderr)
    raise SystemExit(code)


def parse(argv: list[str]) -> Opts:
    o = Opts()
    pos: list[str] = []
    i = 0
    while i < len(argv):
        a = argv[i]
        if a == "--":
            if i + 1 < len(argv):
                o.replacement = argv[i + 1]
            if i + 2 < len(argv):
                pos.extend(argv[i + 2:])
            break
        if a in ("-h", "--help"):
            print(HELP)
            raise SystemExit(0)
        if a in ("-V", "--version"):
            print("srgn 0.14.1")
            raise SystemExit(0)
        if a == "--completions":
            shell = argv[i + 1] if i + 1 < len(argv) else ""
            print(f"# completion script for {shell}")
            raise SystemExit(0)
        if a in ("-u", "--upper"):
            o.upper = True
        elif a in ("-l", "--lower"):
            o.lower = True
        elif a in ("-t", "--titlecase"):
            o.title = True
        elif a in ("-n", "--normalize"):
            o.normalize = True
        elif a in ("-g", "--german"):
            o.german = True
        elif a == "--german-naive":
            o.german_naive = True
        elif a == "--german-prefer-original":
            pass
        elif a in ("-S", "--symbols"):
            o.symbols = True
        elif a in ("-i", "--invert"):
            o.invert = True
        elif a in ("-d", "--delete"):
            o.delete = True
        elif a in ("-s", "--squeeze", "--squeeze-repeats"):
            o.squeeze = True
        elif a in ("-L", "--literal-string"):
            o.literal = True
        elif a == "--fail-any":
            o.fail_any = True
        elif a == "--fail-none":
            o.fail_none = True
        elif a == "--line-numbers":
            o.line_numbers = True
        elif a == "--only-matching":
            o.only_matching = True
        elif a == "--sorted":
            o.sorted = True
        elif a in ("-H", "--hidden"):
            o.hidden = True
        elif a == "--gitignored":
            o.gitignored = True
        elif a == "--dry-run":
            o.dry_run = True
        elif a == "--fail-no-files":
            o.fail_no_files = True
        elif a in ("-G", "--glob", "--files"):
            i += 1
            if i >= len(argv):
                die("error: a value is required for '--glob <GLOB>' but none was supplied")
            o.glob_pat = argv[i]
        elif a == "--stdin-detection":
            i += 1
            if i < len(argv) and argv[i] == "force-unreadable":
                o.force_unreadable = True
        elif a in ("--stdout-detection", "--threads"):
            i += 1
        elif a == "-v" or a.startswith("-v"):
            pass
        elif a in LANG_FLAGS:
            i += 1
            if i >= len(argv):
                die(f"error: a value is required for '{a}'")
            o.lang_scopes.append((LANG_FLAGS[a], argv[i]))
        elif a.endswith("-query") or a.endswith("-query-file"):
            i += 1
        elif a.startswith("-"):
            die(f"error: unexpected argument '{a}' found")
        else:
            pos.append(a)
        i += 1
    if pos:
        o.scope = pos[0]
    if o.scope is None:
        o.scope = ".*"
    if o.delete and o.scope == ".*" and not pos:
        die("error: the following required arguments were not provided:\n  <SCOPE>\n\nUsage: executable --delete <SCOPE> [-- <REPLACEMENT>]")
    if o.literal and o.scope == ".*" and not pos:
        die("error: The following required argument was not provided: scope\n\nUsage: srgn [OPTIONS] [SCOPE] [-- <REPLACEMENT>]")
    if o.delete and (o.replacement is not None or o.upper or o.lower or o.title or o.normalize or o.german or o.symbols):
        die("error: the argument '--delete' cannot be used with:\n  [REPLACEMENT]\n  --upper\n  --lower\n  --titlecase\n  --normalize\n  --german\n  --symbols")
    return o


def compile_scope(o: Opts) -> re.Pattern:
    pat = re.escape(o.scope) if o.literal else o.scope
    try:
        return re.compile(pat, re.MULTILINE)
    except re.error as e:
        die(f"Error: invalid regex: {e}", 1)


SYMBOLS = [
    ("!=", "≠"), ("->", "→"), ("<-", "←"), ("=>", "⇒"), ("<=", "≤"), (">=", "≥"),
]


def symbolize(s: str, invert: bool = False) -> str:
    pairs = [(b, a) for a, b in SYMBOLS] if invert else SYMBOLS
    for a, b in pairs:
        s = s.replace(a, b)
    return s


def germanize(s: str) -> str:
    def repl_word(m: re.Match) -> str:
        w = m.group(0)
        out = re.sub("ue", "ü", w, flags=re.I)
        out = re.sub("oe", "ö", out, flags=re.I)
        out = re.sub("ae", "ä", out, flags=re.I)
        out = re.sub("ss", "ß", out, flags=re.I)
        return out
    return re.sub(r"[A-Za-zÄÖÜäöüß]+", repl_word, s)


def strip_marks(s: str) -> str:
    return "".join(ch for ch in unicodedata.normalize("NFD", s) if unicodedata.category(ch) != "Mn")


def titlecase(s: str) -> str:
    return re.sub(r"\w+", lambda m: m.group(0)[:1].upper() + m.group(0)[1:].lower(), s)


def expand_replacement(rep: str, m: re.Match) -> str:
    def repl(v: re.Match) -> str:
        name = v.group(1) or v.group(2)
        try:
            return m.group(int(name)) if name.isdigit() else m.group(name)
        except (IndexError, KeyError):
            return ""
    return re.sub(r"\$(?:([A-Za-z_][A-Za-z0-9_]*)|([0-9]+))", repl, rep)


def apply_actions_to_match(s: str, o: Opts, m: re.Match | None = None) -> str:
    if o.replacement is not None:
        s = expand_replacement(o.replacement, m) if m else o.replacement
    if o.symbols:
        s = symbolize(s, o.invert)
    if o.german:
        s = germanize(s)
    if o.upper:
        s = s.upper()
    if o.lower:
        s = s.lower()
    if o.title:
        s = titlecase(s)
    if o.normalize:
        s = strip_marks(s)
    return s


def lang_ranges(text: str, lang: str, kind: str) -> list[tuple[int, int]]:
    if lang == "python":
        return python_ranges(text, kind)
    if lang == "rust":
        return rust_ranges(text, kind)
    if lang == "go":
        return go_ranges(text, kind)
    if lang == "typescript":
        return ts_ranges(text, kind)
    if lang in ("c", "csharp"):
        return c_like_ranges(text, kind)
    if kind in ("comments", "strings"):
        return generic_ranges(text, kind)
    return [(0, len(text))]


def generic_ranges(text: str, kind: str) -> list[tuple[int, int]]:
    if kind == "comments":
        return [(m.start(), m.end()) for m in re.finditer(r"//[^\n]*|#[^\n]*|/\*.*?\*/", text, re.S)]
    if kind == "strings":
        return [(m.start(), m.end()) for m in re.finditer(r"(?s)(?:r#*)?\"(?:\\.|[^\"\\])*\"|'(?:\\.|[^'\\])*'", text)]
    return [(0, len(text))]


def block_end_by_indent(text: str, start_line_idx: int, base_indent: int) -> int:
    lines = text.splitlines(True)
    pos = sum(len(x) for x in lines[:start_line_idx])
    end = len(text)
    for j in range(start_line_idx + 1, len(lines)):
        line = lines[j]
        if line.strip() and len(line) - len(line.lstrip(" ")) <= base_indent:
            end = sum(len(x) for x in lines[:j])
            break
    return end


def python_ranges(text: str, kind: str) -> list[tuple[int, int]]:
    if kind in ("comments", "strings"):
        return generic_ranges(text, kind)
    ranges = []
    lines = text.splitlines(True)
    offset = 0
    for idx, line in enumerate(lines):
        stripped = line.lstrip(" ")
        indent = len(line) - len(stripped)
        if kind == "class" and re.match(r"class\s+\w+", stripped):
            ranges.append((offset, block_end_by_indent(text, idx, indent)))
        elif kind in ("def", "methods") and re.match(r"(async\s+)?def\s+\w+", stripped):
            ranges.append((offset, block_end_by_indent(text, idx, indent)))
        elif kind == "function-names":
            m = re.match(r"\s*(?:async\s+)?def\s+(\w+)", line)
            if m:
                ranges.append((offset + m.start(1), offset + m.end(1)))
        elif kind in ("identifiers", "variable-identifiers"):
            ranges.extend((offset + m.start(), offset + m.end()) for m in re.finditer(r"[A-Za-z_][A-Za-z0-9_]*", line))
        offset += len(line)
    return ranges


def brace_block_end(text: str, open_brace: int) -> int:
    depth = 0
    for i in range(open_brace, len(text)):
        if text[i] == "{":
            depth += 1
        elif text[i] == "}":
            depth -= 1
            if depth == 0:
                return i + 1
    return len(text)


def rust_ranges(text: str, kind: str) -> list[tuple[int, int]]:
    if kind in ("comments", "strings"):
        return generic_ranges(text, kind)
    ranges = []
    patterns = {
        "fn": r"(?:pub\s+)?(?:async\s+)?(?:unsafe\s+)?fn\s+\w+[^{;]*(?:\{)?",
        "struct": r"(?:pub\s+)?struct\s+\w+[^{;]*(?:\{)?",
        "enum": r"(?:pub\s+)?enum\s+\w+[^{;]*(?:\{)?",
        "trait": r"(?:pub\s+)?trait\s+\w+[^{;]*(?:\{)?",
        "impl": r"impl\b[^{]*(?:\{)?",
        "attribute": r"#\[[^\]]*\]",
        "identifier": r"[A-Za-z_][A-Za-z0-9_]*",
    }
    base_kind = kind.split("~", 1)[0]
    pat = patterns.get(base_kind)
    if not pat:
        return [(0, len(text))]
    for m in re.finditer(pat, text):
        if text[m.end() - 1:m.end()] == "{":
            ranges.append((m.start(), brace_block_end(text, m.end() - 1)))
        else:
            ranges.append((m.start(), m.end()))
    return ranges


def go_ranges(text: str, kind: str) -> list[tuple[int, int]]:
    if kind in ("comments", "strings"):
        return generic_ranges(text, kind)
    patterns = {
        "func": r"func\s+(?:\([^)]*\)\s*)?\w+[^{]*(?:\{)?",
        "free-func": r"func\s+\w+[^{]*(?:\{)?",
        "method": r"func\s+\([^)]*\)\s*\w+[^{]*(?:\{)?",
        "struct": r"type\s+\w+\s+struct\s*(?:\{)?",
        "interface": r"type\s+\w+\s+interface\s*(?:\{)?",
        "imports": r"import\s+(?:\([^)]*\)|\"[^\"]+\")",
        "const": r"const\s+(?:\([^)]*\)|[^\n]+)",
        "var": r"var\s+(?:\([^)]*\)|[^\n]+)",
        "struct-tags": r"`[^`]*`",
    }
    base = kind.split("~", 1)[0]
    pat = patterns.get(base)
    if not pat:
        return [(0, len(text))]
    out = []
    for m in re.finditer(pat, text, re.S):
        if text[m.end() - 1:m.end()] == "{":
            out.append((m.start(), brace_block_end(text, m.end() - 1)))
        else:
            out.append((m.start(), m.end()))
    return out


def ts_ranges(text: str, kind: str) -> list[tuple[int, int]]:
    if kind in ("comments", "strings"):
        return generic_ranges(text, kind)
    patterns = {
        "function": r"(?:async\s+)?function\s+\w+[^{]*(?:\{)?",
        "async-function": r"async\s+function\s+\w+[^{]*(?:\{)?",
        "sync-function": r"function\s+\w+[^{]*(?:\{)?",
        "class": r"class\s+\w+[^{]*(?:\{)?",
        "interface": r"interface\s+\w+[^{]*(?:\{)?",
        "enum": r"enum\s+\w+[^{]*(?:\{)?",
        "imports": r"import\s+[^;\n]+",
        "let": r"let\s+[^;\n]+",
        "const": r"const\s+[^;\n]+",
        "var": r"var\s+[^;\n]+",
        "var-decl": r"(?:let|const|var)\s+[^;\n]+",
        "type-alias": r"type\s+\w+\s*=\s*[^;\n]+",
    }
    pat = patterns.get(kind)
    if not pat:
        return [(0, len(text))]
    out = []
    for m in re.finditer(pat, text, re.S):
        if text[m.end() - 1:m.end()] == "{":
            out.append((m.start(), brace_block_end(text, m.end() - 1)))
        else:
            out.append((m.start(), m.end()))
    return out


def c_like_ranges(text: str, kind: str) -> list[tuple[int, int]]:
    if kind in ("comments", "strings"):
        return generic_ranges(text, kind)
    patterns = {
        "includes": r"#\s*include\s+[^\n]+",
        "function": r"[A-Za-z_][\\w\\s\\*]*\s+\w+\s*\([^;{}]*\)\s*(?:\{)?",
        "function-def": r"[A-Za-z_][\\w\\s\\*]*\s+\w+\s*\([^;{}]*\)\s*\{",
        "function-decl": r"[A-Za-z_][\\w\\s\\*]*\s+\w+\s*\([^;{}]*\)\s*;",
        "struct": r"struct\s+\w+[^{;]*(?:\{)?",
        "enum": r"enum\s+\w+[^{;]*(?:\{)?",
        "union": r"union\s+\w+[^{;]*(?:\{)?",
        "identifier": r"[A-Za-z_][A-Za-z0-9_]*",
    }
    pat = patterns.get(kind)
    if not pat:
        return [(0, len(text))]
    out = []
    for m in re.finditer(pat, text, re.S):
        if text[m.end() - 1:m.end()] == "{":
            out.append((m.start(), brace_block_end(text, m.end() - 1)))
        else:
            out.append((m.start(), m.end()))
    return out


def intersect_ranges(a: list[tuple[int, int]], b: list[tuple[int, int]]) -> list[tuple[int, int]]:
    out = []
    for x1, x2 in a:
        for y1, y2 in b:
            lo, hi = max(x1, y1), min(x2, y2)
            if lo < hi:
                out.append((lo, hi))
    return out


def selected_ranges(text: str, o: Opts) -> list[tuple[int, int]]:
    ranges = [(0, len(text))]
    for lang, kind in o.lang_scopes:
        ranges = intersect_ranges(ranges, lang_ranges(text, lang, kind))
    return ranges


def transform_segment(seg: str, o: Opts, regex: re.Pattern) -> tuple[str, bool]:
    found = False
    if o.delete:
        out = []
        last = 0
        for m in regex.finditer(seg):
            if m.start() == m.end():
                continue
            found = True
            out.append(seg[last:m.start()])
            last = m.end()
        out.append(seg[last:])
        return "".join(out), found
    if o.squeeze:
        pat = f"(?:{regex.pattern})+"
        try:
            squeeze_re = re.compile(pat, regex.flags)
        except re.error:
            squeeze_re = regex
        out, n = squeeze_re.subn(lambda m: m.group(0)[:1], seg)
        return out, n > 0
    def repl(m: re.Match) -> str:
        nonlocal found
        found = True
        return apply_actions_to_match(m.group(0), o, m)
    out = []
    last = 0
    for m in regex.finditer(seg):
        if m.start() == m.end():
            continue
        out.append(seg[last:m.start()])
        out.append(repl(m))
        last = m.end()
    out.append(seg[last:])
    return "".join(out), found


def transform(text: str, o: Opts) -> tuple[str, bool]:
    regex = compile_scope(o)
    ranges = selected_ranges(text, o)
    if not ranges:
        return text, False
    out = []
    last = 0
    found_any = False
    for a, b in ranges:
        out.append(text[last:a])
        changed, found = transform_segment(text[a:b], o, regex)
        out.append(changed)
        found_any = found_any or found
        last = b
    out.append(text[last:])
    return "".join(out), found_any


def search_output(text: str, o: Opts, name: str = "(stdin)") -> tuple[str, bool]:
    regex = compile_scope(o)
    found = False
    rows = []
    ranges = selected_ranges(text, o)
    starts = [0]
    for m in re.finditer("\n", text):
        starts.append(m.end())
    for line_no, line in enumerate(text.splitlines(True), 1):
        line_start = starts[line_no - 1]
        line_end = line_start + len(line)
        spans = []
        for a, b in ranges:
            lo, hi = max(a, line_start), min(b, line_end)
            if lo >= hi:
                continue
            sub = text[lo:hi]
            for m in regex.finditer(sub):
                if m.start() == m.end():
                    continue
                spans.append((lo + m.start() - line_start, lo + m.end() - line_start))
        if spans:
            found = True
            coords = ";".join(f"{a}-{b}" for a, b in spans)
            prefix = f"{name}:"
            if o.line_numbers or o.lang_scopes:
                prefix += f"{line_no}:"
            rows.append(f"{prefix}{coords}:{line.rstrip(chr(10))}\n")
    return "".join(rows), found


def no_action(o: Opts) -> bool:
    return not (o.delete or o.squeeze or o.replacement is not None or o.upper or o.lower or o.title or o.normalize or o.german or o.symbols)


def handle_fail(o: Opts, found: bool) -> None:
    if o.fail_any and found:
        print("Error: Error applying: Some input was in scope", file=sys.stderr)
        raise SystemExit(1)
    if o.fail_none and not found:
        print("Error: Error applying: No input was in scope", file=sys.stderr)
        raise SystemExit(1)


def process_stdin(o: Opts) -> int:
    data = sys.stdin.read()
    if no_action(o):
        if o.lang_scopes or o.line_numbers or o.only_matching:
            out, found = search_output(data, o)
            handle_fail(o, found)
            sys.stdout.write(out)
        else:
            print("[2026-06-09T00:00:00Z ERROR srgn] No actions specified, and not in search mode. Will return input unchanged, if any.", file=sys.stderr)
            found = bool(compile_scope(o).search(data))
            handle_fail(o, found)
            sys.stdout.write(data)
        return 0
    out, found = transform(data, o)
    handle_fail(o, found)
    sys.stdout.write(out)
    return 0


def files_for(o: Opts) -> list[str]:
    pat = o.glob_pat or "**/*"
    files = [p for p in glob.glob(pat, recursive=True) if os.path.isfile(p)]
    if not o.hidden:
        files = [p for p in files if not any(part.startswith(".") for part in Path(p).parts)]
    return sorted(files) if o.sorted else files


def process_files(o: Opts) -> int:
    files = files_for(o)
    if not files and o.fail_no_files:
        print("Error: No files found", file=sys.stderr)
        return 1
    found_any = False
    for path in files:
        try:
            data = Path(path).read_text()
        except UnicodeDecodeError:
            continue
        if no_action(o):
            if o.lang_scopes:
                out, found = search_output(data, o, path)
                found_any = found_any or found
                sys.stdout.write(out)
            else:
                print("[2026-06-09T00:00:00Z ERROR srgn] No actions specified, and not in search mode. Will return input unchanged, if any.", file=sys.stderr)
                found_any = found_any or bool(compile_scope(o).search(data))
            continue
        out, found = transform(data, o)
        found_any = found_any or found
        if found:
            if o.dry_run:
                print(f"--- {path}\n+++ {path}")
                print(out, end="" if out.endswith("\n") else "\n")
            else:
                Path(path).write_text(out)
                print(path)
    handle_fail(o, found_any)
    return 0


def main(argv: list[str]) -> int:
    o = parse(argv)
    if o.glob_pat is not None or o.force_unreadable:
        return process_files(o)
    return process_stdin(o)


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
