#!/usr/bin/env python3
import sys
import os
import glob
import re
import subprocess


def default_config():
    home = os.path.expanduser("~")
    return f"""---
# The editor to use with 'cheat -e <sheet>'. Overridden by $VISUAL or $EDITOR.
editor: EDITOR_PATH

# Should 'cheat' always colorize output?
colorize: false

# Which 'chroma' colorscheme should be applied to the output?
style: monokai

# Which 'chroma' "formatter" should be applied?
formatter: terminal256

# Through which pager should output be piped?
pager: /usr/bin/pager

cheatpaths:
  - name: personal
    path: {home}/.config/cheat/cheatsheets/personal
    tags: [ personal ]
    readonly: false

  - name: work
    path: {home}/.config/cheat/cheatsheets/work
    tags: [ work ]
    readonly: false
"""


class CheatPath:
    def __init__(self, name, path, tags=None, readonly=False):
        self.name = name
        self.path = os.path.abspath(os.path.expanduser(os.path.expandvars(path)))
        self.tags = tags or []
        self.readonly = readonly


class Sheet:
    def __init__(self, title, path, cheatpath, content, tags=None, syntax=""):
        self.title = title
        self.path = path
        self.cheatpath = cheatpath
        self.content = content
        self.tags = tags or []
        self.syntax = syntax


def parse_list(value):
    value = value.strip()
    if value.startswith("[") and value.endswith("]"):
        inner = value[1:-1].strip()
        if not inner:
            return []
        return [part.strip().strip("'\"") for part in inner.split(",")]
    return [value.strip("'\"")] if value else []


def find_config():
    if os.environ.get("CHEAT_CONFIG_PATH"):
        return os.path.expanduser(os.path.expandvars(os.environ["CHEAT_CONFIG_PATH"]))
    xdg = os.environ.get("XDG_CONFIG_HOME")
    home = os.path.expanduser("~")
    candidates = []
    if xdg:
        candidates.append(os.path.join(xdg, "cheat", "conf.yml"))
    candidates.extend([
        os.path.join(home, ".config", "cheat", "conf.yml"),
        os.path.join(home, ".cheat", "conf.yml"),
        "/etc/cheat/conf.yml",
    ])
    for path in candidates:
        if os.path.exists(path):
            return path
    return None


def parse_config(path):
    cheatpaths = []
    settings = {}
    current = None
    with open(path, encoding="utf-8") as fh:
        for raw in fh:
            line = raw.split("#", 1)[0].rstrip()
            if not line.strip() or line.strip() == "---":
                continue
            stripped = line.strip()
            if stripped == "cheatpaths:":
                continue
            if stripped.startswith("- "):
                if current:
                    cheatpaths.append(current)
                current = {}
                stripped = stripped[2:].strip()
                if ":" in stripped:
                    key, value = stripped.split(":", 1)
                    current[key.strip()] = value.strip()
                continue
            if ":" not in stripped:
                continue
            key, value = stripped.split(":", 1)
            key, value = key.strip(), value.strip()
            if current is not None and (line.startswith(" ") or line.startswith("\t")):
                current[key] = value
            else:
                settings[key] = value
    if current:
        cheatpaths.append(current)
    paths = []
    for entry in cheatpaths:
        pattern = entry.get("path", "")
        expanded = os.path.expanduser(os.path.expandvars(pattern))
        matches = glob.glob(expanded, recursive=True) or [expanded]
        for matched in matches:
            paths.append(CheatPath(
                entry.get("name", os.path.basename(matched) or "default"),
                matched,
                parse_list(entry.get("tags", "")),
                entry.get("readonly", "false").lower() == "true",
            ))
    return settings, paths


def add_cwd_cheatpath(paths):
    cur = os.getcwd()
    while True:
        candidate = os.path.join(cur, ".cheat")
        if os.path.isdir(candidate):
            paths.append(CheatPath("cwd", candidate, [], False))
            return
        parent = os.path.dirname(cur)
        if parent == cur:
            return
        cur = parent


def split_frontmatter(text):
    tags = []
    syntax = ""
    if text.startswith("---\n"):
        end = text.find("\n---", 4)
        if end != -1:
            meta = text[4:end].strip().splitlines()
            text = text[end + len("\n---"):]
            if text.startswith("\n"):
                text = text[1:]
            for line in meta:
                if ":" not in line:
                    continue
                key, value = line.split(":", 1)
                key, value = key.strip(), value.strip()
                if key == "tags":
                    tags = parse_list(value)
                elif key == "syntax":
                    syntax = value.strip("'\"")
    return text, tags, syntax


def load_sheets(paths):
    sheets = []
    for cp in paths:
        if not os.path.isdir(cp.path):
            continue
        for root, dirs, files in os.walk(cp.path):
            dirs[:] = [d for d in dirs if not d.startswith(".git")]
            for name in files:
                full = os.path.join(root, name)
                rel = os.path.relpath(full, cp.path)
                if rel.startswith(".git" + os.sep):
                    continue
                with open(full, encoding="utf-8", errors="replace") as fh:
                    content, meta_tags, syntax = split_frontmatter(fh.read())
                tags = []
                for tag in meta_tags + cp.tags:
                    if tag and tag not in tags:
                        tags.append(tag)
                sheets.append(Sheet(rel, full, cp, content, tags, syntax))
    return sheets


def runtime():
    path = find_config()
    if not path or not os.path.exists(path):
        sys.stdout.write("A config file was not found. Would you like to create one now? [Y/n]: ")
        sys.stderr.write("failed to create config: failed to prompt: EOF\n")
        return None, None, 1
    settings, paths = parse_config(path)
    add_cwd_cheatpath(paths)
    return settings, paths, 0


def matching_sheets(paths, title=None, tag=None, path_name=None):
    sheets = load_sheets(paths)
    if title:
        sheets = [s for s in sheets if s.title == title]
    if tag:
        sheets = [s for s in sheets if tag in s.tags]
    if path_name:
        sheets = [s for s in sheets if s.cheatpath.name == path_name]
    return sheets


def render_table(sheets, brief=False):
    title_w = max([len("title:")] + [len(s.title) for s in sheets])
    rows = []
    if brief:
        rows.append(f"{'title:':<{title_w}} tags:")
        for s in sorted(sheets, key=lambda x: (x.title, x.path)):
            rows.append(f"{s.title:<{title_w}} {','.join(s.tags)}")
    else:
        file_w = max([len("file:")] + [len(s.path) for s in sheets])
        rows.append(f"{'title:':<{title_w}} {'file:':<{file_w}} tags:")
        for s in sorted(sheets, key=lambda x: (x.title, x.path)):
            rows.append(f"{s.title:<{title_w}} {s.path:<{file_w}} {','.join(s.tags)}")
    return "\n".join(rows) + "\n"


def parse_args(argv):
    opts = {
        "all": False, "brief": False, "directories": False, "list": False,
        "regex": False, "tags": False, "update": False, "colorize": False,
        "path": None, "tag": None, "search": None, "edit": None, "rm": None,
        "completion": None, "conf": False, "help": False,
    }
    positionals = []
    i = 0
    while i < len(argv):
        arg = argv[i]
        if arg in ("-h", "--help"):
            opts["help"] = True
        elif arg in ("-a", "--all"):
            opts["all"] = True
        elif arg in ("-b", "--brief"):
            opts["brief"] = True
        elif arg in ("-c", "--colorize"):
            opts["colorize"] = True
        elif arg in ("-d", "--directories"):
            opts["directories"] = True
        elif arg in ("-l", "--list"):
            opts["list"] = True
        elif arg in ("-r", "--regex"):
            opts["regex"] = True
        elif arg in ("-T", "--tags"):
            opts["tags"] = True
        elif arg in ("-u", "--update"):
            opts["update"] = True
        elif arg == "--conf":
            opts["conf"] = True
        elif arg.startswith("--completion="):
            opts["completion"] = arg.split("=", 1)[1]
        elif arg == "--completion":
            if i + 1 >= len(argv):
                sys.stderr.write("flag needs an argument: 'completion' in --completion\n")
                return None, None, 1
            i += 1; opts["completion"] = argv[i]
        elif arg.startswith("--rm="):
            opts["rm"] = arg.split("=", 1)[1]
        elif arg == "--rm":
            if i + 1 >= len(argv):
                sys.stderr.write("flag needs an argument: 'rm' in --rm\n")
                return None, None, 1
            i += 1; opts["rm"] = argv[i]
        elif arg in ("-p", "--path"):
            if i + 1 >= len(argv):
                sys.stderr.write("flag needs an argument: 'p' in -p\n")
                return None, None, 1
            i += 1; opts["path"] = argv[i]
        elif arg.startswith("--path="):
            opts["path"] = arg.split("=", 1)[1]
        elif arg in ("-t", "--tag"):
            if i + 1 >= len(argv):
                sys.stderr.write("flag needs an argument: 't' in -t\n")
                return None, None, 1
            i += 1; opts["tag"] = argv[i]
        elif arg.startswith("--tag="):
            opts["tag"] = arg.split("=", 1)[1]
        elif arg in ("-s", "--search"):
            if i + 1 >= len(argv):
                sys.stderr.write("flag needs an argument: 's' in -s\n")
                return None, None, 1
            i += 1; opts["search"] = argv[i]
        elif arg.startswith("--search="):
            opts["search"] = arg.split("=", 1)[1]
        elif arg in ("-e", "--edit"):
            if i + 1 >= len(argv):
                sys.stderr.write("flag needs an argument: 'e' in -e\n")
                return None, None, 1
            i += 1; opts["edit"] = argv[i]
        elif arg.startswith("--edit="):
            opts["edit"] = arg.split("=", 1)[1]
        elif arg.startswith("-"):
            sys.stderr.write(f"unknown flag: {arg}\n")
            return None, None, 1
        else:
            positionals.append(arg)
        i += 1
    return opts, positionals, 0


def filtered(paths, opts, title=None):
    return matching_sheets(paths, title=title, tag=opts.get("tag"), path_name=opts.get("path"))


def render_search(sheets, phrase, regex=False):
    out = []
    pattern = re.compile(phrase) if regex else None
    for s in sorted(sheets, key=lambda x: (x.title, x.path)):
        lines = []
        for line in s.content.splitlines():
            if (pattern.search(line) if pattern else phrase in line):
                lines.append(line)
        if lines:
            out.append(f"{s.title} ({s.cheatpath.name})")
            out.extend("\t" + line for line in lines)
    return "\n".join(out) + ("\n" if out else "")


def render_tags(sheets):
    tags = sorted({tag for s in sheets for tag in s.tags})
    return "\n".join(tags) + ("\n" if tags else "")


def render_directories(paths):
    width = max([0] + [len(p.name) for p in paths])
    return "".join(f"{p.name + ':':<{width + 1}} {p.path}\n" for p in paths)


def remove_sheet(paths, title, opts):
    sheets = filtered(paths, opts, title=title)
    if not sheets:
        print(f"No cheatsheet found for '{title}'.")
        return 2
    target = sheets[-1]
    if target.cheatpath.readonly:
        sys.stderr.write(f"cannot remove '{title}': cheatpath is read-only\n")
        return 1
    os.remove(target.path)
    return 0


def update_paths(paths, only=None):
    selected = [p for p in paths if only is None or p.name == only]
    out = []
    for p in selected:
        if os.path.isdir(os.path.join(p.path, ".git")):
            out.append(f"{p.name}: skipped (git update not available)")
        else:
            out.append(f"{p.name}: skipped (not a git repository)")
    return "\n".join(out) + ("\n" if out else "")


HELP = """cheat allows you to create and view interactive cheatsheets on the
command-line. It was designed to help remind *nix system administrators of
options for commands that they use frequently, but not frequently enough to
remember.

Usage:
  cheat [cheatsheet] [flags]

Flags:
  -a, --all                Search among all cheatpaths
  -b, --brief              List cheatsheets without file paths
  -c, --colorize           Colorize output
      --completion shell   Generate shell completion script (shell: bash, zsh, fish, powershell)
      --conf               Display the config file path
  -d, --directories        List cheatsheet directories
  -e, --edit cheatsheet    Edit cheatsheet
  -h, --help               help for cheat
      --init               Write a default config file to stdout
  -l, --list               List cheatsheets
  -p, --path name          Return only sheets found on cheatpath name
  -r, --regex              Treat search <phrase> as a regex
      --rm cheatsheet      Remove (delete) cheatsheet
  -s, --search phrase      Search cheatsheets for phrase
  -t, --tag tag            Return only sheets matching tag
  -T, --tags               List all tags in use
  -u, --update             Update git-backed cheatpaths
  -v, --version            Print the version number
"""


def completion(shell):
    if shell not in ("bash", "zsh", "fish", "powershell"):
        sys.stderr.write(f"unsupported shell: {shell} (valid: bash, zsh, fish, powershell)\n")
        return 1
    if shell == "bash":
        print("# bash completion V2 for cheat")
        print("complete -F __start_cheat cheat")
    elif shell == "zsh":
        print("#compdef cheat")
        print("_cheat completion")
    elif shell == "fish":
        print("complete -c cheat -f")
    else:
        print("Register-ArgumentCompleter -CommandName cheat")
    return 0


def edit_sheet(paths, title, opts, settings):
    existing = filtered(paths, opts, title=title)
    target_path = None
    if existing and not existing[-1].cheatpath.readonly:
        target_path = existing[-1].path
    else:
        writable = [p for p in paths if not p.readonly and (opts.get("path") is None or p.name == opts.get("path"))]
        if not writable:
            sys.stderr.write("no writeable cheatpath available\n")
            return 1
        target_path = os.path.join(writable[-1].path, title)
        if existing:
            os.makedirs(os.path.dirname(target_path), exist_ok=True)
            with open(target_path, "w", encoding="utf-8") as out:
                out.write(existing[-1].content)
    os.makedirs(os.path.dirname(target_path), exist_ok=True)
    if not os.path.exists(target_path):
        open(target_path, "a", encoding="utf-8").close()
    editor = os.environ.get("VISUAL") or os.environ.get("EDITOR") or settings.get("editor", "").strip("'\"")
    if not editor or editor == "EDITOR_PATH":
        sys.stderr.write("failed to load config: no editor set\n")
        return 1
    return subprocess.call(editor.split() + [target_path])


def main(argv):
    if "--version" in argv or "-v" in argv:
        print("5.1.0")
        return 0
    if "--init" in argv:
        sys.stdout.write(default_config())
        return 0
    opts, positionals, parse_status = parse_args(argv)
    if parse_status:
        return parse_status
    if opts["completion"] is not None:
        return completion(opts["completion"])
    if opts["help"]:
        sys.stdout.write(HELP)
        return 0
    settings, paths, status = runtime()
    if status:
        return status
    if not argv:
        sys.stdout.write(HELP)
        return 0
    if opts["conf"]:
        print(find_config())
        return 0
    if opts["directories"]:
        sys.stdout.write(render_directories(paths))
        return 0
    if opts["rm"] is not None:
        return remove_sheet(paths, opts["rm"], opts)
    if opts["edit"] is not None:
        return edit_sheet(paths, opts["edit"], opts, settings)
    if opts["update"]:
        sys.stdout.write(update_paths(paths, opts.get("path")))
        return 0
    if opts["tags"]:
        sys.stdout.write(render_tags(filtered(paths, opts)))
        return 0
    if opts["search"] is not None:
        try:
            sys.stdout.write(render_search(filtered(paths, opts), opts["search"], opts["regex"]))
            return 0
        except re.error as exc:
            sys.stderr.write(str(exc) + "\n")
            return 1
    if opts["list"] or opts["brief"]:
        sys.stdout.write(render_table(filtered(paths, opts), brief=opts["brief"]))
        return 0
    title = positionals[0] if positionals else None
    if title:
        sheets = filtered(paths, opts, title=title)
        if not sheets:
            print(f"No cheatsheet found for '{title}'.")
            return 2
        if opts["all"]:
            blocks = [f"{s.title} ({s.cheatpath.name})\n\t" + s.content.replace("\n", "\n\t").rstrip("\t") for s in sheets]
            sys.stdout.write("\n\n".join(blocks))
            if blocks:
                sys.stdout.write("\n")
        else:
            sys.stdout.write(sheets[-1].content)
        return 0
    return 0


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
