#!/usr/bin/env python3
import html
import os
import re
import shutil
import subprocess
import tempfile
from pathlib import Path
import sys

VERSION = "mdbook v0.5.0-alpha.1"

MAIN_HELP = """Creates a book from markdown files

Usage: executable [COMMAND]

Commands:
  init         Creates the boilerplate structure and files for a new book
  build        Builds a book from its markdown files
  test         Tests that a book's Rust code samples compile
  clean        Deletes a built book
  completions  Generate shell completions for your shell to stdout
  watch        Watches a book's files and rebuilds it on changes
  serve        Serves a book at http://localhost:3000, and rebuilds it on changes
  help         Print this message or the help of the given subcommand(s)

Options:
  -h, --help     Print help
  -V, --version  Print version

For more information about a specific command, try `mdbook <command> --help`
The source code for mdBook is available at: https://github.com/rust-lang/mdBook
"""

HELP = {
    "init": """Creates the boilerplate structure and files for a new book

Usage: executable init [OPTIONS] [dir]

Arguments:
  [dir]  Directory to create the book in
         (Defaults to the current directory when omitted)

Options:
      --theme            Copies the default theme into your source folder
      --force            Skips confirmation prompts
      --title <title>    Sets the book title
      --ignore <ignore>  Creates a VCS ignore file (i.e. .gitignore) [possible values: none, git]
  -h, --help             Print help
  -V, --version          Print version
""",
    "build": """Builds a book from its markdown files

Usage: executable build [OPTIONS] [dir]

Arguments:
  [dir]  Root directory for the book
         (Defaults to the current directory when omitted)

Options:
  -d, --dest-dir <dest-dir>  Output directory for the book
                             Relative paths are interpreted relative to the book's root directory.
                             If omitted, mdBook uses build.build-dir from book.toml or defaults to
                             `./book`.
  -o, --open                 Opens the compiled book in a web browser
  -h, --help                 Print help
  -V, --version              Print version
""",
    "clean": """Deletes a built book

Usage: executable clean [OPTIONS] [dir]

Arguments:
  [dir]  Root directory for the book
         (Defaults to the current directory when omitted)

Options:
  -d, --dest-dir <dest-dir>  Output directory for the book
                             Relative paths are interpreted relative to the book's root directory.
                             If omitted, mdBook uses build.build-dir from book.toml or defaults to
                             `./book`.
  -h, --help                 Print help
  -V, --version              Print version
""",
    "test": """Tests that a book's Rust code samples compile

Usage: executable test [OPTIONS] [dir]

Arguments:
  [dir]  Root directory for the book
         (Defaults to the current directory when omitted)

Options:
  -d, --dest-dir <dest-dir>  Output directory for the book
                             Relative paths are interpreted relative to the book's root directory.
                             If omitted, mdBook uses build.build-dir from book.toml or defaults to
                             `./book`.
  -c, --chapter <chapter>    
  -L, --library-path <dir>   A comma-separated list of directories to add to the crate search path
                             when building tests
  -h, --help                 Print help
  -V, --version              Print version
""",
    "completions": """Generate shell completions for your shell to stdout

Usage: executable completions <SHELL>

Arguments:
  <SHELL>  the shell to generate completions for [possible values: bash, elvish, fish, powershell,
           zsh]

Options:
  -h, --help     Print help
  -V, --version  Print version
""",
    "watch": """Watches a book's files and rebuilds it on changes

Usage: executable watch [OPTIONS] [dir]

Options:
  -d, --dest-dir <dest-dir>  Output directory for the book
  -o, --open                 Opens the compiled book in a web browser
      --watcher <watcher>    The filesystem watching technique [default: poll] [possible values:
                             poll, native]
  -h, --help                 Print help
  -V, --version              Print version
""",
    "serve": """Serves a book at http://localhost:3000, and rebuilds it on changes

Usage: executable serve [OPTIONS] [dir]

Options:
  -d, --dest-dir <dest-dir>  Output directory for the book
  -n, --hostname <hostname>  Hostname to listen on for HTTP connections [default: localhost]
  -p, --port <port>          Port to use for HTTP connections [default: 3000]
  -o, --open                 Opens the compiled book in a web browser
      --watcher <watcher>    The filesystem watching technique [default: poll] [possible values:
                             poll, native]
  -h, --help                 Print help
  -V, --version              Print version
""",
}


def command_init(args):
    title = "My First Book"
    ignore = None
    target = Path.cwd()
    i = 0
    while i < len(args):
        arg = args[i]
        if arg in ("--force", "--theme"):
            i += 1
        elif arg == "--title" and i + 1 < len(args):
            title = args[i + 1]
            i += 2
        elif arg == "--ignore" and i + 1 < len(args):
            ignore = args[i + 1]
            i += 2
        elif arg.startswith("-"):
            print(f"error: unexpected argument '{arg}' found", file=sys.stderr)
            return 2
        else:
            target = Path(arg)
            i += 1
    src = target / "src"
    src.mkdir(parents=True, exist_ok=True)
    (target / "book.toml").write_text(
        '[book]\n'
        'authors = []\n'
        'language = "en"\n'
        'src = "src"\n'
        f'title = "{title}"\n'
    )
    (src / "SUMMARY.md").write_text("# Summary\n\n- [Chapter 1](./chapter_1.md)\n")
    (src / "chapter_1.md").write_text("# Chapter 1\n")
    if ignore == "git":
        (target / ".gitignore").write_text("book\n")
    print()
    print("All done, no errors...")
    return 0


def parse_book_toml(root):
    cfg = {"title": "mdBook Documentation", "src": "src", "build-dir": "book"}
    section = None
    path = root / "book.toml"
    if not path.exists():
        return cfg
    for raw in path.read_text(errors="replace").splitlines():
        line = raw.strip()
        if not line or line.startswith("#"):
            continue
        if line.startswith("[") and line.endswith("]"):
            section = line.strip("[]").strip()
            continue
        if "=" not in line:
            continue
        key, value = [p.strip() for p in line.split("=", 1)]
        if "#" in value:
            value = value.split("#", 1)[0].strip()
        if value.startswith('"') and value.endswith('"'):
            value = value[1:-1]
        if section == "book" and key in ("title", "src", "language"):
            cfg[key] = value
        elif section == "build" and key == "build-dir":
            cfg["build-dir"] = value
    return cfg


def destination_from_args(args, root, cfg):
    dest = None
    i = 0
    while i < len(args):
        if args[i] in ("-d", "--dest-dir") and i + 1 < len(args):
            dest = args[i + 1]
            i += 2
        elif args[i] in ("-o", "--open"):
            i += 1
        elif args[i].startswith("-"):
            print(f"error: unexpected argument '{args[i]}' found", file=sys.stderr)
            return None, 2
        else:
            i += 1
    dest = dest or cfg["build-dir"]
    dest_path = Path(dest)
    if not dest_path.is_absolute():
        dest_path = root / dest_path
    return dest_path, 0


def reject_unknown_options(args, allowed_value_options=("-d", "--dest-dir"), allowed_flags=("-o", "--open")):
    i = 0
    while i < len(args):
        arg = args[i]
        if arg in allowed_value_options:
            if i + 1 >= len(args):
                print(f"error: a value is required for '{arg}' but none was supplied", file=sys.stderr)
                return 2
            i += 2
        elif arg in allowed_flags:
            i += 1
        elif arg.startswith("-"):
            print(f"error: unexpected argument '{arg}' found", file=sys.stderr)
            print(f"\n  tip: to pass '{arg}' as a value, use '-- {arg}'", file=sys.stderr)
            return 2
        else:
            i += 1
    return 0


def book_root_from_args(args):
    root = Path.cwd()
    rest = []
    i = 0
    while i < len(args):
        if args[i] in ("-d", "--dest-dir") and i + 1 < len(args):
            rest.extend(args[i:i + 2])
            i += 2
        elif args[i].startswith("-"):
            rest.append(args[i])
            i += 1
        else:
            root = Path(args[i])
            i += 1
    return root, rest


SUMMARY_LINK = re.compile(r"^(?P<indent>\s*)(?:[-*]\s*)?\[(?P<title>[^\]]+)\]\((?P<target>[^)]*)\)")


def parse_summary(summary_text):
    chapters = []
    for raw in summary_text.splitlines():
        m = SUMMARY_LINK.match(raw.strip())
        if not m:
            continue
        target = m.group("target").strip()
        if not target or re.match(r"^[a-zA-Z][a-zA-Z0-9+.-]*:", target):
            continue
        chapters.append({"title": m.group("title").strip(), "path": target})
    return chapters


def slugify(text):
    slug = re.sub(r"[^a-zA-Z0-9 _-]", "", text).strip().lower()
    slug = re.sub(r"\s+", "-", slug)
    return slug or "section"


def md_link_to_html(target):
    if re.match(r"^[a-zA-Z][a-zA-Z0-9+.-]*:", target) or target.startswith("#"):
        return target
    path = target.split("#", 1)
    base = path[0]
    frag = "#" + path[1] if len(path) > 1 else ""
    if base.endswith(".md"):
        base = base[:-3] + ".html"
    if base == "README.html":
        base = "index.html"
    return base + frag


def inline_markdown(text):
    escaped = html.escape(text)
    escaped = re.sub(r"`([^`]+)`", lambda m: f"<code>{m.group(1)}</code>", escaped)
    escaped = re.sub(r"\*\*([^*]+)\*\*", r"<strong>\1</strong>", escaped)
    escaped = re.sub(r"\*([^*]+)\*", r"<em>\1</em>", escaped)
    escaped = re.sub(
        r"\[([^\]]+)\]\(([^)]+)\)",
        lambda m: f'<a href="{html.escape(md_link_to_html(html.unescape(m.group(2))))}">{m.group(1)}</a>',
        escaped,
    )
    return escaped


def render_markdown(markdown):
    lines = markdown.splitlines()
    out = []
    in_code = False
    para = []
    in_ul = False

    def flush_para():
        if para:
            out.append("<p>" + inline_markdown(" ".join(para)) + "</p>")
            para.clear()

    for line in lines:
        stripped = line.strip()
        if stripped.startswith("```"):
            flush_para()
            if in_ul:
                out.append("</ul>")
                in_ul = False
            if in_code:
                out.append("</code></pre>")
            else:
                lang = stripped[3:].strip()
                klass = f' class="language-{html.escape(lang)}"' if lang else ""
                out.append(f"<pre><code{klass}>")
            in_code = not in_code
            continue
        if in_code:
            out.append(html.escape(line))
            continue
        if not stripped:
            flush_para()
            if in_ul:
                out.append("</ul>")
                in_ul = False
            continue
        heading = re.match(r"^(#{1,6})\s+(.*)", stripped)
        if heading:
            flush_para()
            if in_ul:
                out.append("</ul>")
                in_ul = False
            level = len(heading.group(1))
            title = inline_markdown(heading.group(2))
            ident = slugify(html.unescape(re.sub("<[^>]+>", "", title)))
            out.append(f'<h{level} id="{ident}"><a class="header" href="#{ident}">{title}</a></h{level}>')
            continue
        item = re.match(r"^[-*]\s+(.*)", stripped)
        if item:
            flush_para()
            if not in_ul:
                out.append("<ul>")
                in_ul = True
            out.append("<li>" + inline_markdown(item.group(1)) + "</li>")
            continue
        para.append(stripped)
    flush_para()
    if in_ul:
        out.append("</ul>")
    if in_code:
        out.append("</code></pre>")
    return "\n".join(out)


def output_name(md_path):
    if md_path in ("README.md", "./README.md", "readme.md"):
        return "index.html"
    if md_path.endswith(".md"):
        return md_path[:-3] + ".html"
    return md_path + ".html"


def page_title(markdown, fallback):
    for line in markdown.splitlines():
        m = re.match(r"^#\s+(.+)", line.strip())
        if m:
            return re.sub(r"[*_`]", "", m.group(1)).strip()
    return fallback


def render_page(book_title, chapter_title, body, nav_html):
    return f"""<!DOCTYPE HTML>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>{html.escape(chapter_title)} - {html.escape(book_title)}</title>
    <link rel="stylesheet" href="css/general.css">
    <link rel="stylesheet" href="css/chrome.css">
</head>
<body class="sidebar-visible no-js">
<div id="sidebar" class="sidebar">
<h1 class="menu-title">{html.escape(book_title)}</h1>
{nav_html}
</div>
<div id="page-wrapper" class="page-wrapper">
<main>{body}</main>
</div>
</body>
</html>
"""


def nav_for(chapters):
    parts = ["<ol class=\"chapter\">"]
    for ch in chapters:
        href = output_name(ch["path"])
        parts.append(f'<li><a href="{html.escape(href)}">{html.escape(ch["title"])}</a></li>')
    parts.append("</ol>")
    return "\n".join(parts)


def copy_source_assets(src, dest):
    for root, dirs, files in os.walk(src):
        rel_root = Path(root).relative_to(src)
        if any(part.startswith(".") for part in rel_root.parts):
            continue
        for name in files:
            if name.endswith(".md"):
                continue
            source = Path(root) / name
            target = dest / rel_root / name
            target.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(source, target)


def write_theme_stubs(dest):
    files = {
        ".nojekyll": "",
        "404.html": "<!DOCTYPE html><title>404</title><h1>404</h1>\n",
        "print.html": "<!DOCTYPE html><title>Print</title>\n",
        "toc.html": "<!DOCTYPE html><title>Table of Contents</title>\n",
        "searchindex.js": "Object.assign(window, {search: {doc_urls: [], docs: []}});\n",
        "book.js": "",
        "toc.js": "",
        "highlight.js": "",
        "highlight.css": "",
        "ayu-highlight.css": "",
        "tomorrow-night.css": "",
        "clipboard.min.js": "",
        "elasticlunr.min.js": "",
        "mark.min.js": "",
        "searcher.js": "",
        "favicon.svg": "<svg xmlns=\"http://www.w3.org/2000/svg\"/>",
        "favicon.png": "",
        "css/general.css": "body{font-family:sans-serif;line-height:1.5} main{max-width:900px;margin:auto;padding:2rem}\n",
        "css/chrome.css": ".sidebar{float:left;width:240px}.page-wrapper{margin-left:260px}\n",
        "css/print.css": "",
        "css/variables.css": "",
        "fonts/fonts.css": "",
        "fonts/OPEN-SANS-LICENSE.txt": "",
        "fonts/SOURCE-CODE-PRO-LICENSE.txt": "",
    }
    for rel, content in files.items():
        path = dest / rel
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(content)


def load_book(root):
    cfg = parse_book_toml(root)
    src = root / cfg["src"]
    summary = src / "SUMMARY.md"
    if not summary.exists():
        print(f"Error: Couldn't open SUMMARY.md in \"{src}\" directory", file=sys.stderr)
        return None, None, None
    chapters = parse_summary(summary.read_text(errors="replace"))
    return cfg, src, chapters


def command_build(args):
    code = reject_unknown_options(args)
    if code:
        print("\nUsage: executable build [OPTIONS] [dir]\n", file=sys.stderr)
        print("For more information, try '--help'.", file=sys.stderr)
        return code
    root, rest = book_root_from_args(args)
    cfg, src, chapters = load_book(root)
    if cfg is None:
        return 101
    dest, code = destination_from_args(rest, root, cfg)
    if code:
        return code
    if dest.exists():
        shutil.rmtree(dest)
    dest.mkdir(parents=True, exist_ok=True)
    nav = nav_for(chapters)
    for ch in chapters:
        source = src / ch["path"].lstrip("./")
        if not source.exists():
            source.parent.mkdir(parents=True, exist_ok=True)
            source.write_text(f"# {ch['title']}\n")
        markdown = source.read_text(errors="replace")
        body = render_markdown(markdown)
        title = page_title(markdown, ch["title"])
        out = dest / output_name(ch["path"].lstrip("./"))
        out.parent.mkdir(parents=True, exist_ok=True)
        out.write_text(render_page(cfg["title"], title, body, nav))
    copy_source_assets(src, dest)
    write_theme_stubs(dest)
    print("2026-06-11 00:00:00 [INFO] (mdbook_driver::mdbook): Book building has started", file=sys.stderr)
    print("2026-06-11 00:00:00 [INFO] (mdbook_driver::mdbook): Running the html backend", file=sys.stderr)
    print(f"2026-06-11 00:00:00 [INFO] (mdbook_html::html_handlebars::hbs_renderer): HTML book written to `{dest}`", file=sys.stderr)
    return 0


def command_clean(args):
    code = reject_unknown_options(args, allowed_flags=())
    if code:
        print("\nUsage: executable clean [OPTIONS] [dir]\n", file=sys.stderr)
        print("For more information, try '--help'.", file=sys.stderr)
        return code
    root, rest = book_root_from_args(args)
    cfg, _src, _chapters = load_book(root)
    if cfg is None:
        return 101
    dest, code = destination_from_args(rest, root, cfg)
    if code:
        return code
    if dest.exists():
        shutil.rmtree(dest)
    return 0


def rust_blocks(markdown):
    blocks = []
    in_block = False
    lang = ""
    body = []
    for line in markdown.splitlines():
        if line.strip().startswith("```"):
            marker = line.strip()
            if in_block:
                if "rust" in lang and "ignore" not in lang and "no_run" not in lang:
                    blocks.append("\n".join(body))
                in_block = False
                lang = ""
                body = []
            else:
                in_block = True
                lang = marker[3:].strip()
                body = []
        elif in_block:
            body.append(line)
    return blocks


def command_test(args):
    filtered = []
    i = 0
    while i < len(args):
        if args[i] in ("-d", "--dest-dir", "-c", "--chapter", "-L", "--library-path") and i + 1 < len(args):
            i += 2
        elif args[i].startswith("-"):
            i += 1
        else:
            filtered.append(args[i])
            i += 1
    root = Path(filtered[0]) if filtered else Path.cwd()
    cfg, src, chapters = load_book(root)
    if cfg is None:
        return 101
    failures = 0
    for ch in chapters:
        source = src / ch["path"].lstrip("./")
        if not source.exists():
            continue
        blocks = rust_blocks(source.read_text(errors="replace"))
        for idx, code in enumerate(blocks, 1):
            print(f"Testing chapter '{ch['title']}' sample {idx}", file=sys.stderr)
            if shutil.which("rustc") is None:
                continue
            sample = code
            if "fn main" not in sample:
                sample = "fn main() {\n" + sample + "\n}\n"
            with tempfile.TemporaryDirectory() as d:
                path = Path(d) / "sample.rs"
                path.write_text(sample)
                result = subprocess.run(["rustc", "--edition=2021", str(path), "-o", str(Path(d) / "sample")], stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
                if result.returncode != 0:
                    failures += 1
                    sys.stderr.write(result.stderr)
    return 101 if failures else 0


def command_completions(args):
    if not args or args[0] in ("-h", "--help"):
        print(HELP["completions"], end="")
        return 0
    shell = args[0]
    if shell not in {"bash", "elvish", "fish", "powershell", "zsh"}:
        print(f"error: invalid value '{shell}' for '<SHELL>'", file=sys.stderr)
        print("  [possible values: bash, elvish, fish, powershell, zsh]", file=sys.stderr)
        print("\nFor more information, try '--help'.", file=sys.stderr)
        return 2
    if shell == "bash":
        print("_mdbook() {\n    COMPREPLY=()\n}\ncomplete -F _mdbook mdbook")
    elif shell == "fish":
        print("function __fish_mdbook_needs_command\nend\ncomplete -c mdbook -f")
    elif shell == "zsh":
        print("#compdef mdbook\n_mdbook() {\n  _arguments '*::arg:->args'\n}")
    elif shell == "elvish":
        print("set edit:completion:arg-completer[mdbook] = {|@words| }")
    else:
        print("Register-ArgumentCompleter -Native -CommandName 'mdbook' -ScriptBlock {}")
    return 0


def command_watch_or_serve(name, args):
    code = command_build([a for a in args if a not in ("--open", "-o", "--watcher", "poll", "native")])
    if code != 0:
        return code
    if name == "serve":
        host = "localhost"
        port = "3000"
        for i, arg in enumerate(args):
            if arg in ("-n", "--hostname") and i + 1 < len(args):
                host = args[i + 1]
            if arg in ("-p", "--port") and i + 1 < len(args):
                port = args[i + 1]
        print(f"Serving on: http://{host}:{port}", file=sys.stderr)
    return 0


def main(argv=None):
    argv = sys.argv[1:] if argv is None else argv
    if argv in (["--version"], ["-V"]):
        print(VERSION)
        return 0
    if argv in (["--help"], ["-h"]):
        print(MAIN_HELP, end="")
        return 0
    if argv and argv[0] == "help":
        if len(argv) > 1 and argv[1] in HELP:
            print(HELP[argv[1]], end="")
        else:
            print(MAIN_HELP, end="")
        return 0
    if argv and len(argv) > 1 and argv[1] in ("--help", "-h") and argv[0] in HELP:
        print(HELP[argv[0]], end="")
        return 0
    if argv and len(argv) > 1 and argv[1] in ("--version", "-V") and argv[0] in HELP:
        print(VERSION)
        return 0
    if argv and argv[0] == "init":
        return command_init(argv[1:])
    if argv and argv[0] == "build":
        return command_build(argv[1:])
    if argv and argv[0] == "clean":
        return command_clean(argv[1:])
    if argv and argv[0] == "test":
        return command_test(argv[1:])
    if argv and argv[0] == "completions":
        return command_completions(argv[1:])
    if argv and argv[0] in ("watch", "serve"):
        return command_watch_or_serve(argv[0], argv[1:])
    if not argv:
        print(MAIN_HELP, end="")
        return 2
    print(f"error: unrecognized subcommand '{argv[0]}'", file=sys.stderr)
    print("\nUsage: executable [COMMAND]\n", file=sys.stderr)
    print("For more information, try '--help'.", file=sys.stderr)
    return 2


if __name__ == "__main__":
    raise SystemExit(main())
