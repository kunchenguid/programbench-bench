#!/bin/bash
set -e
rm -f executable
cp mdbooklite/main.py executable
chmod +x executable
