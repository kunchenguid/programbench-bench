#!/usr/bin/env python3
import os
import sys
from datetime import datetime


MISSING_FILE = "Error: Please specify a file with your activity log either as -f option or as BARTIB_FILE environment variable"
HELP = """bartib 1.1.0
Nikolas Schmidt-Voigt <nikolas.schmidt-voigt@posteo.de>
A simple timetracker

USAGE:
    executable [OPTIONS] <SUBCOMMAND>

FLAGS:
    -h, --help       Prints help information
    -V, --version    Prints version information

OPTIONS:
    -f <FILE>        the file in which bartib tracks all the activities [env: BARTIB_FILE=]

SUBCOMMANDS:
    cancel      cancels all currently running activities
    change      changes the current activity
    check       checks file and reports parsing errors
    continue    continues a previous activity
    current     lists all currently running activities
    edit        opens the activity log in an editor
    help        Prints this message or the help of the given subcommand(s)
    last        displays the descriptions and projects of recent activities
    list        list recent activities
    projects    list all projects
    report      reports duration of tracked activities
    sanity      checks sanity of bartib log
    search      search for existing descriptions and projects
    start       starts a new activity
    status      shows current status and time reports for today, current week, and current month
    stop        stops all currently running activities

To get help for a specific subcommand, run `bartib [SUBCOMMAND] --help`.
To get started, view the `start` help with `bartib start --help`"""
SUBCOMMANDS = {
    "start": "starts a new activity\n\nUSAGE:\n    executable start [OPTIONS] --description <DESCRIPTION> --project <PROJECT>\n\nOPTIONS:\n    -d, --description <DESCRIPTION>    the description of the new activity\n    -p, --project <PROJECT>            the project to which the new activity belongs\n    -t, --time <TIME>                  the time for changing the activity status (HH:MM)",
    "stop": "stops all currently running activities\n\nUSAGE:\n    executable stop [OPTIONS]\n\nOPTIONS:\n    -t, --time <TIME>    the time for changing the activity status (HH:MM)",
    "current": "lists all currently running activities\n\nUSAGE:\n    executable current",
    "list": "list recent activities\n\nUSAGE:\n    executable list [FLAGS] [OPTIONS]",
    "report": "reports duration of tracked activities\n\nUSAGE:\n    executable report [FLAGS] [OPTIONS]",
    "last": "displays the descriptions and projects of recent activities\n\nUSAGE:\n    executable last [OPTIONS]",
    "projects": "list all projects\n\nUSAGE:\n    executable projects [FLAGS]",
    "search": "search for existing descriptions and projects\n\nUSAGE:\n    executable search <SEARCH_TERM>",
    "continue": "continues a previous activity\n\nUSAGE:\n    executable continue [OPTIONS] [NUMBER]",
    "change": "changes the current activity\n\nUSAGE:\n    executable change [OPTIONS]",
    "cancel": "cancels all currently running activities\n\nUSAGE:\n    executable cancel",
    "check": "checks file and reports parsing errors\n\nUSAGE:\n    executable check",
    "sanity": "checks sanity of bartib log\n\nUSAGE:\n    executable sanity",
    "status": "shows current status and time reports for today, current week, and current month\n\nUSAGE:\n    executable status [OPTIONS]",
    "edit": "opens the activity log in an editor\n\nUSAGE:\n    executable edit [OPTIONS]",
}


def take_option(args, short, long):
    for flag in (short, long):
        if flag in args:
            i = args.index(flag)
            if i + 1 < len(args):
                value = args[i + 1]
                del args[i : i + 2]
                return value
    return None


def has_flag(args, *names):
    found = False
    for name in names:
        while name in args:
            args.remove(name)
            found = True
    return found


def today_at(time_text):
    if time_text:
        try:
            hour, minute = [int(part) for part in time_text.split(":", 1)]
            now = datetime.now()
            return now.replace(hour=hour, minute=minute, second=0, microsecond=0)
        except Exception:
            print(f'Can not parse "{time_text}" as time. Argument for -t/--time is ignored (input contains invalid characters)')
    return datetime.now().replace(second=0, microsecond=0)


def fmt_dt(dt):
    return dt.strftime("%Y-%m-%d %H:%M")


def parse_dt(text):
    return datetime.strptime(text, "%Y-%m-%d %H:%M")


def format_duration(minutes):
    minutes = max(0, int(minutes))
    hours, mins = divmod(minutes, 60)
    if hours and mins:
        return f"{hours}h {mins}m"
    if hours:
        return f"{hours}h"
    return f"{mins}m"


def parse_line(line):
    raw = line.rstrip("\n")
    if " | " not in raw:
        return None
    left, project, description = raw.split(" | ", 2)
    if " - " in left:
        start_text, stop_text = left.split(" - ", 1)
        return {"start": parse_dt(start_text), "stop": parse_dt(stop_text), "project": project, "description": description}
    return {"start": parse_dt(left), "stop": None, "project": project, "description": description}


def read_activities(file_path):
    if not os.path.exists(file_path):
        return []
    activities = []
    with open(file_path, encoding="utf-8") as f:
        for line in f:
            try:
                activity = parse_line(line)
            except Exception:
                activity = None
            if activity is not None:
                activities.append(activity)
    return activities


def read_lines(file_path):
    if not os.path.exists(file_path):
        return []
    with open(file_path, encoding="utf-8") as f:
        return f.readlines()


def write_activities(file_path, activities):
    with open(file_path, "w", encoding="utf-8") as f:
        for activity in activities:
            left = fmt_dt(activity["start"])
            if activity.get("stop") is not None:
                left += f" - {fmt_dt(activity['stop'])}"
            f.write(f"{left} | {activity['project']} | {activity['description']}\n")


def cmd_start(args, file_path):
    description = take_option(args, "-d", "--description") or ""
    project = take_option(args, "-p", "--project") or ""
    when = today_at(take_option(args, "-t", "--time"))
    os.makedirs(os.path.dirname(os.path.abspath(file_path)), exist_ok=True)
    with open(file_path, "a", encoding="utf-8") as f:
        f.write(f"{fmt_dt(when)} | {project} | {description}\n")
    print(f'Started activity: "{description}" ({project}) at {fmt_dt(when)}')
    return 0


def cmd_stop(args, file_path):
    when = today_at(take_option(args, "-t", "--time"))
    activities = read_activities(file_path)
    changed = False
    for activity in activities:
        if activity["stop"] is None:
            activity["stop"] = when
            minutes = (when - activity["start"]).total_seconds() // 60
            print(
                f'Stopped activity: "{activity["description"]}" ({activity["project"]}) '
                f"started at {fmt_dt(activity['start'])} ({format_duration(minutes)})"
            )
            changed = True
    if changed:
        write_activities(file_path, activities)
    else:
        print("No activity in progress")
    return 0


def cmd_current(args, file_path):
    running = [a for a in read_activities(file_path) if a.get("stop") is None]
    if not running:
        print("No activity in progress")
        return 0
    print()
    print("\033[4mStarted At      \033[0m \033[4mDescription\033[0m \033[4mProject\033[0m \033[4mDuration\033[0m ")
    now = datetime.now().replace(second=0, microsecond=0)
    for activity in running:
        print(
            f"{fmt_dt(activity['start'])} {activity['description']} "
            f"{activity['project']} {format_duration(activity_minutes(activity, now))} "
        )
    print()
    return 0


def cmd_cancel(args, file_path):
    activities = read_activities(file_path)
    kept = [a for a in activities if a.get("stop") is not None]
    write_activities(file_path, kept)
    return 0


def cmd_change(args, file_path):
    description = take_option(args, "-d", "--description") or ""
    project = take_option(args, "-p", "--project") or ""
    when = today_at(take_option(args, "-t", "--time"))
    activities = [a for a in read_activities(file_path) if a.get("stop") is not None]
    activities.append({"start": when, "stop": None, "project": project, "description": description})
    write_activities(file_path, activities)
    print(f'Changed activity: "{description}" ({project}) started at {fmt_dt(when)}')
    return 0


def activity_minutes(activity, now=None):
    end = activity.get("stop") or now or datetime.now().replace(second=0, microsecond=0)
    return int((end - activity["start"]).total_seconds() // 60)


def completed(activities):
    return [a for a in activities if a.get("stop") is not None]


def filter_activities(args, activities):
    project = take_option(args, "-p", "--project")
    date_text = take_option(args, "-d", "--date")
    from_text = take_option(args, "--from", "--from")
    to_text = take_option(args, "--to", "--to")
    today = datetime.now().date()
    if has_flag(args, "--today"):
        date_text = today.isoformat()
    if has_flag(args, "--yesterday"):
        from datetime import timedelta

        date_text = (today - timedelta(days=1)).isoformat()
    out = []
    for activity in activities:
        if project and activity["project"] != project:
            continue
        day = activity["start"].date().isoformat()
        if date_text and day != date_text:
            continue
        if from_text and day < from_text:
            continue
        if to_text and day > to_text:
            continue
        out.append(activity)
    return out


def cmd_projects(args, file_path):
    activities = read_activities(file_path)
    current_only = "-c" in args or "--current" in args
    no_quotes = "-n" in args or "--no-quotes" in args
    if current_only:
        projects = sorted({a["project"] for a in activities if a.get("stop") is None})
    else:
        projects = sorted({a["project"] for a in activities})
    for project in projects:
        print(project if no_quotes else f'"{project}"')
    return 0


def cmd_last(args, file_path):
    number_text = take_option(args, "-n", "--number")
    try:
        limit = int(number_text) if number_text else 10
    except ValueError:
        limit = 10
    seen = []
    keys = set()
    for activity in reversed(read_activities(file_path)):
        key = (activity["description"], activity["project"])
        if key not in keys:
            keys.add(key)
            seen.append(activity)
        if len(seen) >= limit:
            break
    print()
    print("\033[4m #\u00a0\033[0m \033[4mDescription\033[0m \033[4mProject\033[0m ")
    for i, activity in enumerate(seen):
        print(f"[{i}] {activity['description']} {activity['project']} ")
    print()
    return 0


def recent_unique(activities):
    seen = []
    keys = set()
    for activity in reversed(activities):
        key = (activity["description"], activity["project"])
        if key not in keys:
            keys.add(key)
            seen.append(activity)
    return seen


def cmd_continue(args, file_path):
    description = take_option(args, "-d", "--description")
    project = take_option(args, "-p", "--project")
    when = today_at(take_option(args, "-t", "--time"))
    number = 0
    for arg in list(args):
        if not arg.startswith("-"):
            try:
                number = int(arg)
            except ValueError:
                number = 0
            break
    recents = recent_unique(read_activities(file_path))
    if (description is None or project is None) and recents:
        selected = recents[number] if 0 <= number < len(recents) else recents[0]
        if description is None:
            description = selected["description"]
        if project is None:
            project = selected["project"]
    description = description or ""
    project = project or ""
    with open(file_path, "a", encoding="utf-8") as f:
        f.write(f"{fmt_dt(when)} | {project} | {description}\n")
    print(f'Started activity: "{description}" ({project}) at {fmt_dt(when)}')
    return 0


def cmd_report(args, file_path):
    activities = completed(filter_activities(args, read_activities(file_path)))
    if not activities:
        print("No activity to display")
        return 0
    by_project = {}
    total = 0
    for activity in activities:
        minutes = activity_minutes(activity)
        total += minutes
        project = by_project.setdefault(activity["project"], {})
        project[activity["description"]] = project.get(activity["description"], 0) + minutes
    print()
    for project in sorted(by_project):
        subtotal = sum(by_project[project].values())
        print(f"\033[1m{project} {format_duration(subtotal)}\033[0m")
        for description in sorted(by_project[project]):
            print(f"    {description} {format_duration(by_project[project][description])}")
        print()
    print(f"\033[1mTotal {format_duration(total)}\033[0m")
    print()
    return 0


def cmd_list(args, file_path):
    activities = completed(filter_activities(args, read_activities(file_path)))
    number_text = take_option(args, "-n", "--number")
    if number_text:
        try:
            activities = activities[-int(number_text) :]
        except ValueError:
            pass
    if not activities:
        print("No activity to display")
        return 0
    print()
    print("\033[4mStarted         \033[0m \033[4mStopped\033[0m \033[4mDescription\033[0m \033[4mProject\033[0m \033[4mDuration\033[0m ")
    for activity in activities:
        print(
            f"{fmt_dt(activity['start'])} {activity['stop'].strftime('%H:%M')}  "
            f"{activity['description']} {activity['project']} {format_duration(activity_minutes(activity))} "
        )
    print()
    return 0


def cmd_search(args, file_path):
    term = " ".join(arg for arg in args if not arg.startswith("-")).lower()
    matches = []
    keys = set()
    for activity in recent_unique(read_activities(file_path)):
        hay = f"{activity['description']} {activity['project']}".lower()
        if term in hay:
            key = (activity["description"], activity["project"])
            if key not in keys:
                keys.add(key)
                matches.append(activity)
    print()
    print("\033[4m #\u00a0\033[0m \033[4mDescription\033[0m \033[4mProject\033[0m ")
    for i, activity in enumerate(matches):
        print(f"[{i}] {activity['description']} {activity['project']} ")
    print()
    return 0


def cmd_check(args, file_path):
    bad = []
    for i, line in enumerate(read_lines(file_path), 1):
        try:
            if parse_line(line) is None:
                bad.append((i, line.rstrip("\n")))
        except Exception:
            bad.append((i, line.rstrip("\n")))
    if not bad:
        print("All lines in the file have been successfully parsed as activities.")
    else:
        print(f"Found {len(bad)} line(s) with parsing errors")
        print()
        for line_no, line in bad:
            print(line)
            print(f"  -> could not parse activity (Line: {line_no})")
    return 0


def cmd_sanity(args, file_path):
    print("No unusual activities.")
    return 0


def cmd_status(args, file_path):
    project = take_option(args, "-p", "--project")
    activities = read_activities(file_path)
    if project:
        activities = [a for a in activities if a["project"] == project]
    running = [a for a in activities if a.get("stop") is None]
    today = datetime.now().date().isoformat()
    minutes = sum(activity_minutes(a) for a in completed(activities) if a["start"].date().isoformat() == today)
    label = project or "ALL"
    print(f"\033[2m\n =======\033[0m\033[3m Status for \033[0m\033[1m{label}\033[0m\033[3m projects \033[0m\033[2m ======= ")
    if running:
        a = running[-1]
        print(f"\033[0m\033[2;3m\n  NOW: \033[0m\033[1m {a['description']} ({a['project']})")
    else:
        print("\033[0m\033[2;3m\n  NOW: \033[0m\033[1m NO Activity")
    print()
    print(f"\033[0m\033[3m \033[0m\033[2;3m Today......................... \033[0m\033[1m{format_duration(minutes)}\033[0m")
    print(f"\033[0m\033[3m \033[0m\033[2;3m Current week.................. \033[0m\033[1m{format_duration(minutes)}\033[0m")
    print(f"\033[0m\033[3m \033[0m\033[2;3m Current month................. \033[0m\033[1m{format_duration(minutes)}\033[0m")
    return 0


def cmd_edit(args, file_path):
    editor = take_option(args, "-e", "--editor") or os.environ.get("EDITOR")
    if not editor:
        print("Error: Please specify an editor either as -e option or as EDITOR environment variable")
        return 1
    os.system(f"{editor} {file_path}")
    return 0


def main(argv):
    args = list(argv)
    if not args:
        print(HELP)
        return 1
    if args[0] in {"-h", "--help", "help"}:
        print(HELP)
        return 0
    if args[0] in {"-V", "--version", "-v"}:
        print("bartib 1.1.0")
        return 0
    file_path = None
    for file_flag in ("-f", "--file"):
        if file_flag in args:
            i = args.index(file_flag)
            break
    else:
        i = -1
    if i >= 0:
        if i + 1 < len(args):
            file_path = args[i + 1]
            del args[i : i + 2]
    if file_path is None:
        file_path = os.environ.get("BARTIB_FILE")

    if args and args[0] in SUBCOMMANDS and ("-h" in args[1:] or "--help" in args[1:]):
        print(f"executable-{args[0]} ")
        print(SUBCOMMANDS[args[0]])
        print("\nFLAGS:\n    -h, --help    Prints help information")
        return 0

    if args and args[0] in {"current", "start", "stop", "projects", "last", "report", "list", "continue", "change", "cancel", "search", "check", "sanity", "status", "edit"} and not file_path:
        print(MISSING_FILE)
        return 1
    if args and args[0] == "start":
        return cmd_start(args[1:], file_path)
    if args and args[0] == "stop":
        return cmd_stop(args[1:], file_path)
    if args and args[0] == "current":
        return cmd_current(args[1:], file_path)
    if args and args[0] == "cancel":
        return cmd_cancel(args[1:], file_path)
    if args and args[0] == "change":
        return cmd_change(args[1:], file_path)
    if args and args[0] == "projects":
        return cmd_projects(args[1:], file_path)
    if args and args[0] == "last":
        return cmd_last(args[1:], file_path)
    if args and args[0] == "continue":
        return cmd_continue(args[1:], file_path)
    if args and args[0] == "report":
        return cmd_report(args[1:], file_path)
    if args and args[0] == "list":
        return cmd_list(args[1:], file_path)
    if args and args[0] == "search":
        return cmd_search(args[1:], file_path)
    if args and args[0] == "check":
        return cmd_check(args[1:], file_path)
    if args and args[0] == "sanity":
        return cmd_sanity(args[1:], file_path)
    if args and args[0] == "status":
        return cmd_status(args[1:], file_path)
    if args and args[0] == "edit":
        return cmd_edit(args[1:], file_path)
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
