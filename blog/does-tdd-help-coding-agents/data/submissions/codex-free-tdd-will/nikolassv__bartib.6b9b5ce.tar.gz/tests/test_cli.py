import os
import subprocess
import tempfile
import unittest
from datetime import date


ROOT = os.path.dirname(os.path.dirname(__file__))
EXE = os.path.join(ROOT, "executable")


class BartibCliTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        subprocess.run(["bash", "compile.sh"], cwd=ROOT, check=True)

    def run_cmd(self, *args, env=None):
        full_env = os.environ.copy()
        full_env.pop("BARTIB_FILE", None)
        if env:
            full_env.update(env)
        return subprocess.run(
            [EXE, *args],
            cwd=ROOT,
            env=full_env,
            text=True,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
        )

    def test_requires_log_file_for_activity_commands(self):
        result = self.run_cmd("current")
        self.assertEqual(result.returncode, 1)
        self.assertIn(
            "Error: Please specify a file with your activity log either as -f option or as BARTIB_FILE environment variable",
            result.stdout,
        )

    def test_start_writes_running_activity(self):
        with tempfile.TemporaryDirectory() as td:
            log = os.path.join(td, "activities.bartib")
            result = self.run_cmd("-f", log, "start", "-d", "Write code", "-p", "Alpha", "-t", "09:00")
            today = date.today().isoformat()
            self.assertEqual(result.returncode, 0)
            self.assertEqual(result.stdout, f'Started activity: "Write code" (Alpha) at {today} 09:00\n')
            with open(log, encoding="utf-8") as f:
                self.assertEqual(f.read(), f"{today} 09:00 | Alpha | Write code\n")

    def test_stop_closes_running_activity(self):
        with tempfile.TemporaryDirectory() as td:
            log = os.path.join(td, "activities.bartib")
            today = date.today().isoformat()
            with open(log, "w", encoding="utf-8") as f:
                f.write(f"{today} 09:00 | Alpha | Write code\n")
            result = self.run_cmd("-f", log, "stop", "-t", "10:30")
            self.assertEqual(result.returncode, 0)
            self.assertEqual(
                result.stdout,
                f'Stopped activity: "Write code" (Alpha) started at {today} 09:00 (1h 30m)\n',
            )
            with open(log, encoding="utf-8") as f:
                self.assertEqual(f.read(), f"{today} 09:00 - {today} 10:30 | Alpha | Write code\n")

    def test_reads_completed_activities_for_common_reports(self):
        with tempfile.TemporaryDirectory() as td:
            log = os.path.join(td, "activities.bartib")
            today = date.today().isoformat()
            with open(log, "w", encoding="utf-8") as f:
                f.write(f"{today} 09:00 - {today} 10:30 | Alpha | Write code\n")
                f.write(f"{today} 11:00 - {today} 11:45 | Beta | Review\n")

            projects = self.run_cmd("-f", log, "projects", "--no-quotes")
            self.assertEqual(projects.stdout, "Alpha\nBeta\n")

            last = self.run_cmd("-f", log, "last")
            self.assertIn("[0] Review", last.stdout)
            self.assertIn("[1] Write code", last.stdout)

            report = self.run_cmd("-f", log, "report")
            self.assertIn("Alpha", report.stdout)
            self.assertIn("Write code 1h 30m", report.stdout)
            self.assertIn("Beta", report.stdout)
            self.assertIn("Review 45m", report.stdout)
            self.assertIn("Total", report.stdout)
            self.assertIn("2h 15m", report.stdout)

            listing = self.run_cmd("-f", log, "list", "--no_grouping")
            self.assertIn(f"{today} 09:00", listing.stdout)
            self.assertIn("10:30", listing.stdout)
            self.assertIn("Write code", listing.stdout)
            self.assertIn("1h 30m", listing.stdout)

    def test_continue_resumes_recent_activity_by_number(self):
        with tempfile.TemporaryDirectory() as td:
            log = os.path.join(td, "activities.bartib")
            today = date.today().isoformat()
            with open(log, "w", encoding="utf-8") as f:
                f.write(f"{today} 09:00 - {today} 10:30 | Alpha | Write code\n")
                f.write(f"{today} 11:00 - {today} 11:45 | Beta | Review\n")
            result = self.run_cmd("-f", log, "continue", "0", "-t", "12:00")
            self.assertEqual(result.returncode, 0)
            self.assertEqual(result.stdout, f'Started activity: "Review" (Beta) at {today} 12:00\n')
            with open(log, encoding="utf-8") as f:
                self.assertTrue(f.read().endswith(f"{today} 12:00 | Beta | Review\n"))

    def test_current_change_and_cancel_operate_on_running_activity(self):
        with tempfile.TemporaryDirectory() as td:
            log = os.path.join(td, "activities.bartib")
            today = date.today().isoformat()
            with open(log, "w", encoding="utf-8") as f:
                f.write(f"{today} 09:00 | Alpha | Write code\n")

            current = self.run_cmd("-f", log, "current")
            self.assertIn("Write code", current.stdout)
            self.assertIn("Alpha", current.stdout)

            changed = self.run_cmd("-f", log, "change", "-d", "Review", "-p", "Beta", "-t", "10:00")
            self.assertEqual(changed.stdout, f'Changed activity: "Review" (Beta) started at {today} 10:00\n')
            with open(log, encoding="utf-8") as f:
                self.assertEqual(f.read(), f"{today} 10:00 | Beta | Review\n")

            canceled = self.run_cmd("-f", log, "cancel")
            self.assertEqual(canceled.returncode, 0)
            with open(log, encoding="utf-8") as f:
                self.assertEqual(f.read(), "")


if __name__ == "__main__":
    unittest.main()
