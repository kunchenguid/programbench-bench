#!/bin/bash
set -e
rm -f executable
cp src/bartib.py executable
chmod +x executable
