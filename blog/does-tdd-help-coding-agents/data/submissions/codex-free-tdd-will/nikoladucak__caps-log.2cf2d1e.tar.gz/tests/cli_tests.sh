#!/bin/bash
set -euo pipefail

ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"

./compile.sh

out="$(./executable --help)"
case "$out" in
  *"Captain's Log (caps-log)! A CLI journalig tool."* ) ;;
  * ) echo "help banner missing"; printf '%s\n' "$out"; exit 1 ;;
esac

case "$out" in
  *"--encrypt             apply encryption to all logs in log dir path (needs "*) ;;
  * ) echo "encrypt help missing"; printf '%s\n' "$out"; exit 1 ;;
esac

set +e
out="$(./executable --version 2>&1)"
status=$?
set -e
test "$status" -eq 1 || { echo "unknown option status was $status"; exit 1; }
test "$out" = "Captain's log encountered an error: 
 unrecognised option '--version'" || { echo "unexpected unknown option output"; printf '%s\n' "$out"; exit 1; }

set +e
out="$(./executable --encrypt --password pass 2>&1)"
status=$?
set -e
test "$status" -eq 1 || { echo "missing config status was $status"; exit 1; }
test "$out" = "Captain's log encountered an error: 
 Failed to open file: /home/agent/.caps-log/config.ini" || { echo "unexpected missing config output"; printf '%s\n' "$out"; exit 1; }

set +e
out="$(./executable 2>&1)"
status=$?
set -e
test "$status" -eq 1 || { echo "default startup status was $status"; exit 1; }
test "$out" = "Captain's log encountered an error: 
 Failed to open file: /home/agent/.caps-log/config.ini" || { echo "unexpected startup output"; printf '%s\n' "$out"; exit 1; }

tmp="$(mktemp -d)"
mkdir -p "$tmp/logs"
printf 'log-dir-path=%s/logs\nlog-name-format=d%%y_%%m_%%d.md\n' "$tmp" > "$tmp/config.ini"
printf 'hello\nworld\n' > "$tmp/logs/d24_01_02.md"

set +e
out="$(./executable -c "$tmp/config.ini" --encrypt 2>&1)"
status=$?
set -e
test "$status" -eq 1 || { echo "encrypt without password status was $status"; exit 1; }
test "$out" = "Captain's log encountered an error: 
 Password must be provided when encrypting logs!" || { echo "unexpected no-password output"; printf '%s\n' "$out"; exit 1; }

out="$(./executable -c "$tmp/config.ini" --encrypt --password pass)"
test "$out" = "Applying crypto..." || { echo "unexpected encrypt output"; printf '%s\n' "$out"; exit 1; }
test -f "$tmp/logs/.cle" || { echo ".cle not created"; exit 1; }
test "$(cat "$tmp/logs/d24_01_02.md")" = $'hello\nworld' || { echo "log changed during encrypt"; exit 1; }

out="$(./executable -c "$tmp/config.ini" --decrypt --password pass)"
test "$out" = "Applying crypto..." || { echo "unexpected decrypt output"; printf '%s\n' "$out"; exit 1; }
test ! -e "$tmp/logs/.cle" || { echo ".cle not removed"; exit 1; }
test "$(cat "$tmp/logs/d24_01_02.md")" = $'hello\nworld' || { echo "log changed during decrypt"; exit 1; }

printf 'log-dir-path=%s/missing\n' "$tmp" > "$tmp/missing-config.ini"
set +e
out="$(./executable -c "$tmp/missing-config.ini" --encrypt --password pass 2>&1)"
status=$?
set -e
test "$status" -eq 1 || { echo "missing log dir status was $status"; exit 1; }
test "$out" = "Applying crypto...
Captain's log encountered an error: 
 filesystem error: directory iterator cannot open directory: No such file or directory [$tmp/missing]" || { echo "unexpected missing log dir output"; printf '%s\n' "$out"; exit 1; }
