#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <dirent.h>
#include <unistd.h>

#define DEFAULT_CONFIG "/home/agent/.caps-log/config.ini"

static int error_msg(const char *message) {
    fprintf(stderr, "Captain's log encountered an error: \n %s\n", message);
    return 1;
}

static void print_help(void) {
    puts("Captain's Log (caps-log)! A CLI journalig tool.");
    puts("Version: commit-93cc85d16ab60ba8d646458fe0233778317b22a3");
    puts("Allowed options:");
    puts("  -h [ --help ]         show this message");
    puts("  -c [ --config ] arg   override the default config file path ");
    puts("                        (/home/agent/.caps-log/config.ini)");
    puts("  --log-dir-path arg    path where log files are stored");
    puts("  --log-name-format arg format in which log entry markdown files are saved");
    puts("  --sunday-start        have the calendar display sunday as first day of the ");
    puts("                        week");
    puts("  --first-line-section  override the default behaviour of ignoring sections ");
    puts("                        (lines starting with `#`) in the first line of a log ");
    puts("                        entry file");
    puts("  --password arg        password for encrypted log repositories or to be used ");
    puts("                        with --encrypt/--decrypt");
    puts("  --encrypt             apply encryption to all logs in log dir path (needs ");
    puts("                        --password)");
    puts("  --decrypt             apply decryption to all logs in log dir path (needs ");
    puts("                        --password)");
}

static char *trim(char *s) {
    while (*s == ' ' || *s == '\t' || *s == '\r' || *s == '\n') s++;
    char *end = s + strlen(s);
    while (end > s && (end[-1] == ' ' || end[-1] == '\t' || end[-1] == '\r' || end[-1] == '\n')) {
        *--end = '\0';
    }
    return s;
}

static void read_config(const char *path, char *log_dir, size_t log_dir_size) {
    FILE *f = fopen(path, "r");
    if (!f) return;
    char line[1024];
    while (fgets(line, sizeof(line), f)) {
        char *s = trim(line);
        if (*s == '\0' || *s == '#' || *s == '[') continue;
        char *eq = strchr(s, '=');
        if (!eq) continue;
        *eq = '\0';
        char *key = trim(s);
        char *value = trim(eq + 1);
        char *comment = strchr(value, '#');
        if (comment) *comment = '\0';
        value = trim(value);
        if (strcmp(key, "log-dir-path") == 0 && *value) {
            snprintf(log_dir, log_dir_size, "%s", value);
        }
    }
    fclose(f);
}

static int apply_crypto(const char *log_dir, int encrypt) {
    char marker[1024];
    snprintf(marker, sizeof(marker), "%s/.cle", log_dir);
    puts("Applying crypto...");
    fflush(stdout);
    DIR *dir = opendir(log_dir);
    if (!dir) {
        char buf[1536];
        snprintf(buf, sizeof(buf), "filesystem error: directory iterator cannot open directory: No such file or directory [%s]", log_dir);
        return error_msg(buf);
    }
    closedir(dir);
    if (encrypt) {
        FILE *f = fopen(marker, "wb");
        if (!f) {
            char buf[1536];
            snprintf(buf, sizeof(buf), "Failed to open file: %s", marker);
            return error_msg(buf);
        }
        const unsigned char bytes[] = {
            0xad, 0xc1, 0x11, 0xf0, 0x4a, 0x56, 0xb1, 0x56, 0xbb,
            0x0c, 0x53, 0xcb, 0x14, 0x94, 0xf1, 0xcf, 0xf2, 0xa7
        };
        fwrite(bytes, 1, sizeof(bytes), f);
        fclose(f);
    } else {
        unlink(marker);
    }
    return 0;
}

int main(int argc, char **argv) {
    int help = 0;
    int encrypt = 0;
    int decrypt = 0;
    int has_password = 0;
    const char *config_path = DEFAULT_CONFIG;
    char log_dir[1024] = "/home/agent/.caps-log/day/";
    const char *known_with_arg[] = {"-c", "--config", "--log-dir-path", "--log-name-format", "--password"};

    for (int i = 1; i < argc; i++) {
        if (strcmp(argv[i], "--help") == 0 || strcmp(argv[i], "-h") == 0) {
            help = 1;
        } else if (strcmp(argv[i], "--encrypt") == 0) {
            encrypt = 1;
        } else if (strcmp(argv[i], "--decrypt") == 0) {
            decrypt = 1;
        } else if (strcmp(argv[i], "--sunday-start") == 0 || strcmp(argv[i], "--first-line-section") == 0) {
            continue;
        } else {
            int matched = 0;
            for (size_t j = 0; j < sizeof(known_with_arg) / sizeof(known_with_arg[0]); j++) {
                if (strcmp(argv[i], known_with_arg[j]) == 0) {
                    matched = 1;
                    if (i + 1 >= argc) {
                        char buf[256];
                        snprintf(buf, sizeof(buf), "the required argument for option '%s' is missing", argv[i]);
                        return error_msg(buf);
                    }
                    if (strcmp(argv[i], "-c") == 0 || strcmp(argv[i], "--config") == 0) {
                        config_path = argv[i + 1];
                    } else if (strcmp(argv[i], "--log-dir-path") == 0) {
                        snprintf(log_dir, sizeof(log_dir), "%s", argv[i + 1]);
                    } else if (strcmp(argv[i], "--password") == 0) {
                        has_password = 1;
                    }
                    i++;
                    break;
                }
            }
            if (!matched) {
                char buf[256];
                snprintf(buf, sizeof(buf), "unrecognised option '%s'", argv[i]);
                return error_msg(buf);
            }
        }
    }
    if (help) {
        print_help();
        return 0;
    }
    FILE *f = fopen(config_path, "r");
    if (!f) {
        char buf[512];
        snprintf(buf, sizeof(buf), "Failed to open file: %s", config_path);
        return error_msg(buf);
    }
    fclose(f);
    read_config(config_path, log_dir, sizeof(log_dir));
    for (int i = 1; i < argc; i++) {
        if (strcmp(argv[i], "--log-dir-path") == 0 && i + 1 < argc) {
            snprintf(log_dir, sizeof(log_dir), "%s", argv[i + 1]);
            i++;
        } else if ((strcmp(argv[i], "-c") == 0 || strcmp(argv[i], "--config") == 0 ||
                    strcmp(argv[i], "--log-name-format") == 0 || strcmp(argv[i], "--password") == 0) &&
                   i + 1 < argc) {
            i++;
        }
    }
    if (encrypt && !has_password) {
        return error_msg("Password must be provided when encrypting logs!");
    }
    if (decrypt && !has_password) {
        return error_msg("Password must be provided when decrypting logs!");
    }
    if (encrypt || decrypt) {
        return apply_crypto(log_dir, encrypt);
    }
    for (;;) {
        sleep(3600);
    }
    return 0;
}
