import os
import subprocess
import textwrap
import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
BIN = ROOT / "executable"


LOG = textwrap.dedent(
    '''\
    178.133.125.122 - - [21/Jan/2021:05:49:52 +0000] "HEAD /broot/download/x86_64-pc-windows-gnu/broot.exe HTTP/1.1" 200 0 "-" "Mozilla/4.0"
    10.0.0.1 - - [21/Jan/2021:06:10:00 +0000] "GET /blog/post HTTP/1.1" 404 123 "https://example.com/start" "Agent One"
    10.0.0.2 - - [22/Jan/2021:18:30:01 +0000] "POST /api/data HTTP/1.1" 500 456 "-" "Agent Two"
    10.0.0.1 - - [22/Jan/2021:23:59:59 +0000] "GET /style.css HTTP/1.1" 200 789 "https://example.com/start" "Agent Three"
    '''
)


class CliTest(unittest.TestCase):
    def setUp(self):
        self.tmp = ROOT / "tmp-test"
        self.tmp.mkdir(exist_ok=True)
        self.log = self.tmp / "access.log"
        self.log.write_text(LOG)

    def run_cmd(self, *args):
        return subprocess.run(
            [str(BIN), "--silent-load", *args, str(self.log)],
            text=True,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            check=False,
        )

    def test_raw_output_preserves_matching_log_lines(self):
        result = self.run_cmd("-o", "raw")
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertEqual(result.stdout, LOG)

    def test_structured_exports_use_observed_fields(self):
        csv_result = self.run_cmd("-o", "csv")
        self.assertEqual(csv_result.returncode, 0, csv_result.stderr)
        self.assertIn("date,time,remote address,method,path,status,bytes sent,referer\n", csv_result.stdout)
        self.assertIn('2021/01/21,06:10:00,10.0.0.1,GET,"/blog/post",404,123,"https://example.com/start"\n', csv_result.stdout)

        json_result = self.run_cmd("-o", "json")
        self.assertEqual(json_result.returncode, 0, json_result.stderr)
        self.assertIn('"remote_addr": "10.0.0.2"', json_result.stdout)
        self.assertIn('"bytes_sent": 456', json_result.stdout)

    def test_filters_select_matching_hits(self):
        status = self.run_cmd("-o", "raw", "-s", "4xx")
        self.assertEqual(status.returncode, 0, status.stderr)
        self.assertEqual(status.stdout, LOG.splitlines(True)[1])

        neg_path = self.run_cmd("-o", "raw", "-p", "!blog")
        self.assertEqual(neg_path.returncode, 0, neg_path.stderr)
        self.assertNotIn("/blog/post", neg_path.stdout)
        self.assertIn("/api/data", neg_path.stdout)

        combined = self.run_cmd("-o", "raw", "-i", "10.0.0.1", "-m", "GET", "-d", "2021/01/22", "-t", ">18:00")
        self.assertEqual(combined.returncode, 0, combined.stderr)
        self.assertEqual(combined.stdout, LOG.splitlines(True)[3])


if __name__ == "__main__":
    unittest.main()
