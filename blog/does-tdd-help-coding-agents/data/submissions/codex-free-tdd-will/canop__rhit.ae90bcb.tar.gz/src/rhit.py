#!/usr/bin/env python3
import csv
import gzip
import json
import os
import re
import sys
from dataclasses import dataclass
from datetime import datetime, time
from pathlib import Path


VERSION = "rhit 2.0.4"
DEFAULT_FIELDS = ["date", "status", "ref", "path"]
ALL_FIELDS = ["date", "time", "method", "status", "ip", "ref", "path"]
RESOURCE_RE = re.compile(r"\.(?:css|js|png|jpe?g|gif|svg|ico|webp|woff2?|ttf|map|txt|xml|rss)(?:[?#].*)?$", re.I)
LOG_RE = re.compile(
    r'^(?P<ip>\S+) \S+ \S+ \[(?P<stamp>[^\]]+)\] '
    r'"(?P<request>[^"]*)" (?P<status>\d{3}) (?P<bytes>\S+) '
    r'"(?P<referer>[^"]*)" "(?P<agent>[^"]*)"$'
)


@dataclass
class Hit:
    raw: str
    ip: str
    dt: datetime
    method: str
    path: str
    status: str
    bytes_sent: int
    referer: str

    @property
    def date_s(self):
        return self.dt.strftime("%Y/%m/%d")

    @property
    def time_s(self):
        return self.dt.strftime("%H:%M:%S")


def usage():
    return """rhit 2.0.4

Rhit analyzes your nginx logs.

Usage: rhit [options] [FILES]

Options:
  --help                 Print help information
  --version              Print the version
  --color COLOR          Whether to have styles and colors
  -k, --key KEY          Key used in sorting, either hits or bytes
  -l, --length LENGTH    Detail level, from 0 to 6
  -f, --fields FIELDS    Comma separated list of hit fields to display
  -c, --changes          Add change tables
  -d, --date DATE        Filter dates
  -i, --ip IP            Filter by IP
  -m, --method METHOD    Filter by HTTP method
  -p, --path PATH        Filter by path
  -r, --referer REFERER  Filter by referer
  -s, --status STATUS    Filter by status
  -t, --time TIME        Filter by time of day
  -a, --all              Show all paths, including resources
  --no-name-check        Try to open all files
  -o, --output OUTPUT    tables, raw, csv, or json
  --silent-load          Don't print during load
"""


def parse_args(argv):
    opts = {
        "output": "tables",
        "fields": None,
        "length": 1,
        "key": "hits",
        "all": False,
        "no_name_check": False,
        "filters": {},
        "files": [],
    }
    i = 0
    while i < len(argv):
        a = argv[i]
        if a == "--":
            opts["files"].extend(argv[i + 1 :])
            break
        if a == "--help":
            print(usage(), end="")
            raise SystemExit(0)
        if a == "--version":
            print(VERSION)
            raise SystemExit(0)
        if a in ("--silent-load", "-c", "--changes"):
            i += 1
            continue
        if a in ("-a", "--all"):
            opts["all"] = True
            i += 1
            continue
        if a == "--no-name-check":
            opts["no_name_check"] = True
            i += 1
            continue
        value_opts = {
            "-o": "output",
            "--output": "output",
            "-f": "fields",
            "--fields": "fields",
            "--field": "fields",
            "-l": "length",
            "--length": "length",
            "-k": "key",
            "--key": "key",
            "--color": "color",
            "-d": "date",
            "--date": "date",
            "-i": "ip",
            "--ip": "ip",
            "-m": "method",
            "--method": "method",
            "-p": "path",
            "--path": "path",
            "-r": "referer",
            "--referer": "referer",
            "-s": "status",
            "--status": "status",
            "-t": "time",
            "--time": "time",
        }
        if a in value_opts:
            if i + 1 >= len(argv):
                print(f"error: a value is required for '{a}'", file=sys.stderr)
                raise SystemExit(2)
            key = value_opts[a]
            val = argv[i + 1]
            if key in ("date", "ip", "method", "path", "referer", "status", "time"):
                opts["filters"][key] = val
            elif key != "color":
                opts[key] = val
            i += 2
            continue
        if a.startswith("-"):
            print(f"error: unexpected argument '{a}' found", file=sys.stderr)
            raise SystemExit(2)
        opts["files"].append(a)
        i += 1
    opts["output"] = normalize_output(opts["output"])
    opts["key"] = "bytes" if str(opts["key"]).startswith("b") else "hits"
    try:
        opts["length"] = int(opts["length"])
    except Exception:
        opts["length"] = 1
    return opts


def normalize_output(s):
    aliases = {"r": "raw", "c": "csv", "j": "json", "t": "tables"}
    s = aliases.get(str(s), str(s))
    if s not in ("raw", "csv", "json", "tables"):
        print(f"error: invalid value '{s}' for '--output <OUTPUT>': unrecognized output \"{s}\"", file=sys.stderr)
        raise SystemExit(2)
    return s


def parse_line(line):
    line = line.rstrip("\n")
    m = LOG_RE.match(line)
    if not m:
        return None
    request = m.group("request")
    parts = request.split()
    method, path = ("none", request)
    if len(parts) >= 2:
        method, path = parts[0], parts[1]
    elif len(parts) == 1 and parts[0]:
        method = parts[0]
    try:
        dt = datetime.strptime(m.group("stamp").split()[0], "%d/%b/%Y:%H:%M:%S")
    except ValueError:
        return None
    b = m.group("bytes")
    return Hit(
        raw=line,
        ip=m.group("ip"),
        dt=dt,
        method=method,
        path=path,
        status=m.group("status"),
        bytes_sent=0 if b == "-" else int(b),
        referer=m.group("referer"),
    )


def discover(paths, no_name_check=False):
    if not paths:
        paths = ["/var/log/nginx/access.log", "/var/log/nginx"]
    files = []
    for p in paths:
        path = Path(p)
        if not path.exists():
            print(f'Error: PathNotFound("{p}")', file=sys.stderr)
            raise SystemExit(1)
        if path.is_dir():
            for child in sorted(path.iterdir()):
                name = child.name
                if child.is_file() and (no_name_check or "access" in name or name.endswith((".log", ".gz"))):
                    files.append(child)
        else:
            files.append(path)
    return files


def read_hits(files):
    hits = []
    for path in files:
        opener = gzip.open if str(path).endswith(".gz") else open
        mode = "rt"
        try:
            with opener(path, mode, encoding="utf-8", errors="replace") as f:
                for line in f:
                    h = parse_line(line)
                    if h:
                        hits.append(h)
        except OSError as e:
            print(f"Error: {e}", file=sys.stderr)
            raise SystemExit(1)
    hits.sort(key=lambda h: h.dt)
    return hits


def keep(hit, filters):
    for key, expr in filters.items():
        if key == "status" and not status_match(hit.status, expr):
            return False
        if key == "ip" and not text_match(hit.ip, expr):
            return False
        if key == "method" and not method_match(hit.method, expr):
            return False
        if key == "path" and not text_match(hit.path, expr):
            return False
        if key == "referer" and not text_match(hit.referer, expr):
            return False
        if key == "date" and not date_match(hit.dt, expr):
            return False
        if key == "time" and not time_match(hit.dt.time(), expr):
            return False
    return True


def text_match(value, expr):
    expr = expr.strip()
    if "," in expr:
        return all(text_match(value, part) for part in split_top(expr, ","))
    if expr.startswith("!"):
        return not text_match(value, expr[1:])
    if has_top(expr, "|"):
        return any(text_match(value, part) for part in split_top(expr, "|"))
    if has_top(expr, "&"):
        return all(text_match(value, part) for part in split_top(expr, "&"))
    if expr.startswith("(") and expr.endswith(")") and balanced(expr[1:-1]):
        return text_match(value, expr[1:-1])
    try:
        return re.search(expr, value) is not None
    except re.error:
        return expr in value


def has_top(s, sep):
    return len(split_top(s, sep)) > 1


def split_top(s, sep):
    parts, depth, start = [], 0, 0
    for i, ch in enumerate(s):
        if ch == "(":
            depth += 1
        elif ch == ")":
            depth -= 1
        elif ch == sep and depth == 0:
            parts.append(s[start:i].strip())
            start = i + 1
    parts.append(s[start:].strip())
    return [p for p in parts if p]


def balanced(s):
    depth = 0
    for ch in s:
        if ch == "(":
            depth += 1
        elif ch == ")":
            depth -= 1
        if depth < 0:
            return False
    return depth == 0


def method_match(method, expr):
    expr = expr.strip()
    if expr.startswith("!"):
        return not method_match(method, expr[1:])
    if expr == "none":
        return method == "none"
    if expr == "other":
        return method not in {"GET", "POST", "HEAD", "PUT", "DELETE", "PATCH", "OPTIONS", "CONNECT", "TRACE"}
    return method == expr


def status_match(status_s, expr):
    status = int(status_s)
    positives = []
    negatives = []
    for raw in expr.split(","):
        raw = raw.strip()
        if not raw:
            continue
        target = negatives if raw.startswith("!") else positives
        target.append(raw[1:] if raw.startswith("!") else raw)
    if positives and not any(status_token(status, t) for t in positives):
        return False
    if any(status_token(status, t) for t in negatives):
        return False
    return True


def status_token(status, token):
    if re.fullmatch(r"\dxx", token):
        return status // 100 == int(token[0])
    if re.fullmatch(r"\d{3}-\d{3}", token):
        lo, hi = map(int, token.split("-"))
        return lo <= status <= hi
    try:
        return status == int(token)
    except ValueError:
        return False


def parse_partial_date(s, end=False):
    parts = s.split("T", 1)
    dparts = [int(p) for p in parts[0].split("/") if p]
    if len(dparts) == 1:
        y, mo, da = dparts[0], (12 if end else 1), (31 if end else 1)
    elif len(dparts) == 2:
        y, mo = dparts
        da = month_days(y, mo) if end else 1
    else:
        y, mo, da = dparts[:3]
    hh, mm, ss = (23, 59, 59) if end else (0, 0, 0)
    if len(parts) == 2:
        t = [int(p) for p in parts[1].split(":") if p]
        if len(t) > 0:
            hh = t[0]
            mm = 59 if end and len(t) == 1 else 0
            ss = 59 if end and len(t) <= 2 else 0
        if len(t) > 1:
            mm = t[1]
        if len(t) > 2:
            ss = t[2]
    return datetime(y, mo, da, hh, mm, ss)


def month_days(y, m):
    if m == 2:
        return 29 if (y % 4 == 0 and (y % 100 != 0 or y % 400 == 0)) else 28
    return [31, 30, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31][m - 1]


def date_match(dt, expr):
    expr = expr.strip()
    if expr.startswith("!"):
        return not date_match(dt, expr[1:])
    if expr.startswith(">"):
        return dt > parse_partial_date(expr[1:], end=True)
    if expr.startswith("<"):
        return dt < parse_partial_date(expr[1:], end=False)
    if "-" in expr:
        lo, hi = expr.split("-", 1)
        return parse_partial_date(lo, False) <= dt <= parse_partial_date(hi, True)
    return parse_partial_date(expr, False) <= dt <= parse_partial_date(expr, True)


def parse_clock(s):
    parts = [int(p) for p in s.split(":")]
    while len(parts) < 3:
        parts.append(0)
    return time(parts[0], parts[1], parts[2])


def time_match(t, expr):
    expr = expr.strip()
    if expr.startswith("!"):
        return not time_match(t, expr[1:])
    if expr.startswith(">"):
        return t > parse_clock(expr[1:])
    if expr.startswith("<"):
        return t < parse_clock(expr[1:])
    if "-" in expr:
        lo, hi = expr.split("-", 1)
        return parse_clock(lo) <= t <= parse_clock(hi)
    return t.hour == parse_clock(expr).hour


def write_csv(hits):
    w = csv.writer(sys.stdout, lineterminator="\n", quoting=csv.QUOTE_MINIMAL)
    w.writerow(["date", "time", "remote address", "method", "path", "status", "bytes sent", "referer"])
    for h in hits:
        print(
            ",".join(
                [
                    h.date_s,
                    h.time_s,
                    h.ip,
                    h.method,
                    csv_quote(h.path),
                    h.status,
                    str(h.bytes_sent),
                    csv_quote(h.referer),
                ]
            )
        )


def csv_quote(s):
    return '"' + s.replace('"', '""') + '"'


def write_json(hits):
    rows = [
        {
            "date": h.date_s,
            "time": h.time_s,
            "remote_addr": h.ip,
            "method": h.method,
            "path": h.path,
            "status": h.status,
            "bytes_sent": h.bytes_sent,
            "referer": h.referer,
        }
        for h in hits
    ]
    print(json.dumps(rows, indent=2))


def selected_fields(spec):
    if not spec:
        return DEFAULT_FIELDS[:]
    fields = DEFAULT_FIELDS[:]
    tokens = re.split(r"[,;+]", spec.replace("all", "a"))
    ops = re.findall(r"^[+-]|[+-]", spec)
    if spec[0] not in "+-":
        fields = []
    pos = 0
    for token in re.split(r"([+-])", spec):
        if token in "+-":
            pos = 1 if token == "+" else -1
            continue
        for part in filter(None, re.split(r"[,;]", token)):
            name = field_name(part.strip())
            if not name:
                continue
            names = ALL_FIELDS if name == "all" else [name]
            for n in names:
                if pos == -1:
                    if n in fields:
                        fields.remove(n)
                elif n not in fields:
                    fields.append(n)
    return fields


def field_name(s):
    aliases = {
        "a": "all",
        "all": "all",
        "d": "date",
        "date": "date",
        "t": "time",
        "time": "time",
        "m": "method",
        "method": "method",
        "s": "status",
        "status": "status",
        "i": "ip",
        "ip": "ip",
        "r": "ref",
        "ref": "ref",
        "referer": "ref",
        "p": "path",
        "path": "path",
        "paths": "path",
    }
    return aliases.get(s)


def field_value(h, field):
    return {
        "date": h.date_s,
        "time": h.time_s[:2],
        "method": h.method,
        "status": h.status,
        "ip": h.ip,
        "ref": h.referer,
        "path": h.path,
    }[field]


def write_tables(hits, opts):
    total_b = sum(h.bytes_sent for h in hits)
    if hits:
        print(f"{len(hits)} hits and {total_b} from {hits[0].date_s} to {hits[-1].date_s}")
    else:
        print("0 hits")
    for field in selected_fields(opts["fields"]):
        rows = {}
        for h in hits:
            if field == "path" and not opts["all"] and RESOURCE_RE.search(h.path):
                continue
            v = field_value(h, field)
            rows.setdefault(v, [0, 0])
            rows[v][0] += 1
            rows[v][1] += h.bytes_sent
        title = {"ref": "referers", "ip": "remote addresses"}.get(field, field + "s")
        if field == "path" and not opts["all"]:
            print(f"{len(rows)} {title} (excluding resources like images, css, etc.).")
        else:
            print(f"{len(rows)} {title}.")
        key_index = 1 if opts["key"] == "bytes" else 0
        limit = {0: 1, 1: 5, 2: 10, 3: 20, 4: 40, 5: 80, 6: 200}.get(opts["length"], 5)
        ordered = sorted(rows.items(), key=lambda kv: (-kv[1][key_index], kv[0]))[:limit]
        print("#\t" + field + "\thits\t%\tbytes")
        for idx, (value, (count, b)) in enumerate(ordered, 1):
            pct = (100.0 * count / len(hits)) if hits else 0.0
            print(f"{idx}\t{value}\t{count}\t{pct:.1f}%\t{b}")


def main(argv=None):
    opts = parse_args(sys.argv[1:] if argv is None else argv)
    hits = read_hits(discover(opts["files"], opts["no_name_check"]))
    hits = [h for h in hits if keep(h, opts["filters"])]
    out = opts["output"]
    if out == "raw":
        for h in hits:
            print(h.raw)
    elif out == "csv":
        write_csv(hits)
    elif out == "json":
        write_json(hits)
    else:
        write_tables(hits, opts)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
