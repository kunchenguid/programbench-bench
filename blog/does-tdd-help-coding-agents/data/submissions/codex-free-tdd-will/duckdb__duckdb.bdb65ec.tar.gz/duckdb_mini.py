#!/usr/bin/env python3
import ast
import csv
import io
import json
import math
import os
import re
import sys


VERSION = "v0.0.1 (Unknown Version) 780a7396"


class DbError(Exception):
    pass


class MiniDuckDB:
    def __init__(self, path=None):
        self.path = path if path and path not in (":memory:", "-") else None
        self.tables = {}
        if self.path and os.path.exists(self.path) and os.path.getsize(self.path):
            try:
                with open(self.path, "r", encoding="utf-8") as f:
                    data = json.load(f)
                self.tables = data.get("tables", {})
            except Exception:
                raise DbError(f'IO Error: The file "{self.path}" exists, but it is not a valid DuckDB database file!')

    def save(self):
        if not self.path:
            return
        with open(self.path, "w", encoding="utf-8") as f:
            json.dump({"tables": self.tables}, f, separators=(",", ":"))

    def execute(self, sql):
        result = None
        for stmt in split_statements(sql):
            if not stmt.strip():
                continue
            result = self.execute_one(stmt.strip())
        self.save()
        return result

    def execute_one(self, stmt):
        low = stmt.lower().strip()
        if low.startswith("create table"):
            return self.create_table(stmt)
        if low.startswith("insert into"):
            return self.insert_into(stmt)
        if low.startswith("drop table"):
            return self.drop_table(stmt)
        if low.startswith("show tables"):
            names = sorted(self.tables)
            return Result(["name"], [["varchar"]], [[n] for n in names])
        if low.startswith("describe ") or low.startswith("desc "):
            name = stmt.split(None, 1)[1].strip().strip('"')
            table = self.get_table(name)
            return Result(["column_name", "column_type", "null", "key", "default", "extra"], [["varchar"]]*6,
                          [[c["name"], c["type"], "YES", None, None, None] for c in table["columns"]])
        if low.startswith("select") or low.startswith("with"):
            return self.select(stmt)
        if low in ("pragma version", "pragma version()"):
            return Result(["library_version", "source_id"], [["varchar"], ["varchar"]], [["v0.0.1", "780a7396"]])
        if low in ("begin", "commit", "rollback"):
            return None
        raise DbError(f"Parser Error: syntax error at or near \"{stmt.split()[0] if stmt.split() else ''}\"")

    def create_table(self, stmt):
        m = re.match(r"create\s+table\s+(?:if\s+not\s+exists\s+)?([A-Za-z_][\w]*)\s*\((.*)\)\s*$", stmt, re.I | re.S)
        if not m:
            raise DbError("Parser Error: syntax error in CREATE TABLE")
        name, body = m.group(1), m.group(2)
        if name in self.tables:
            if re.match(r"create\s+table\s+if\s+not\s+exists", stmt, re.I):
                return None
            raise DbError(f'Catalog Error: Table with name "{name}" already exists!')
        cols = []
        for item in split_commas(body):
            parts = item.strip().split()
            if not parts:
                continue
            col_type = " ".join(parts[1:]) if len(parts) > 1 else "VARCHAR"
            cols.append({"name": unquote_ident(parts[0]), "type": canonical_type(col_type)})
        self.tables[name] = {"columns": cols, "rows": []}
        return None

    def insert_into(self, stmt):
        m = re.match(r"insert\s+into\s+([A-Za-z_][\w]*)(?:\s*\(([^)]*)\))?\s+values\s*(.*)$", stmt, re.I | re.S)
        if not m:
            raise DbError("Parser Error: syntax error in INSERT")
        name, col_list, values = m.group(1), m.group(2), m.group(3)
        table = self.get_table(name)
        target = [c["name"] for c in table["columns"]]
        if col_list:
            target = [unquote_ident(c.strip()) for c in split_commas(col_list)]
        for row_text in parse_value_rows(values):
            vals = [eval_expr(x, {}) for x in split_commas(row_text)]
            row = {c["name"]: None for c in table["columns"]}
            for col, val in zip(target, vals):
                row[col] = val
            table["rows"].append(row)
        return None

    def drop_table(self, stmt):
        m = re.match(r"drop\s+table\s+(?:if\s+exists\s+)?([A-Za-z_][\w]*)", stmt, re.I)
        if not m:
            raise DbError("Parser Error: syntax error in DROP TABLE")
        self.tables.pop(m.group(1), None)
        return None

    def get_table(self, name):
        name = unquote_ident(name)
        if name not in self.tables:
            raise DbError(f'Catalog Error: Table with name "{name}" does not exist!')
        return self.tables[name]

    def select(self, stmt):
        parts = split_union_all(stmt)
        if len(parts) > 1:
            first = self.select(parts[0])
            rows = list(first.rows)
            for p in parts[1:]:
                rows.extend(self.select(p).rows)
            return Result(first.columns, first.types, rows)

        select_part, from_part, where_expr, order_col, order_desc, limit = split_select(stmt)
        if from_part is None:
            exprs = parse_select_list(select_part)
            row = []
            cols = []
            raw_exprs = []
            for expr, alias in exprs:
                val = eval_expr(expr, {})
                cols.append(alias or pretty_expr(expr))
                raw_exprs.append(expr)
                row.append(val)
            rows = [row] if where_expr is None or eval_expr(where_expr, {}) else []
            return Result(cols, [[infer_type(v, raw_exprs[i]) for i, v in enumerate(row)]], rows)

        rows, source_cols, source_types = self.source_rows(from_part)
        if where_expr:
            rows = [r for r in rows if eval_expr(where_expr, r)]
        exprs = parse_select_list(select_part)
        out_cols = []
        out_rows = []
        agg = any(re.match(r"\s*(count\(\*\)|sum\()", e, re.I) for e, _ in exprs)
        if agg:
            row = []
            for expr, alias in exprs:
                if re.match(r"\s*count\(\*\)\s*$", expr, re.I):
                    val = len(rows)
                else:
                    sm = re.match(r"\s*sum\(([^)]+)\)\s*$", expr, re.I)
                    if sm:
                        val = sum((r.get(sm.group(1).strip()) or 0) for r in rows)
                    else:
                        val = None
                out_cols.append(alias or pretty_expr(expr))
                row.append(val)
            return Result(out_cols, [[infer_type(v) for v in row]], [row])
        if len(exprs) == 1 and exprs[0][0].strip() == "*":
            out_cols = list(source_cols)
            out_rows = [[r.get(c) for c in source_cols] for r in rows]
            types = [source_types]
        else:
            for expr, alias in exprs:
                out_cols.append(alias or pretty_expr(expr))
            for r in rows:
                out_rows.append([eval_expr(e, r) for e, _ in exprs])
            types = [[infer_type(v) for v in out_rows[0]]] if out_rows else [["varchar"] * len(out_cols)]
        if order_col:
            idx = out_cols.index(order_col) if order_col in out_cols else source_cols.index(order_col)
            out_rows.sort(key=lambda x: (x[idx] is None, x[idx]), reverse=order_desc)
        if limit is not None:
            out_rows = out_rows[:limit]
        return Result(out_cols, types, out_rows)

    def source_rows(self, from_part):
        fp = from_part.strip()
        if (len(fp) >= 2 and fp[0] in ("'", '"') and fp[-1] == fp[0]):
            path = fp[1:-1]
            if path.lower().endswith(".csv"):
                return read_csv_source(path)
            raise DbError(f"IO Error: No files found that match the pattern \"{path}\"")
        m = re.match(r"range\s*\((\d+)\)(?:\s+as\s+([A-Za-z_][\w]*))?$", fp, re.I)
        if m:
            rows = [{"range": i, (m.group(2) or "range"): i} for i in range(int(m.group(1)))]
            return rows, [m.group(2) or "range"], ["int64"]
        m = re.match(r"\(\s*values\s*(.*?)\s*\)\s+as\s+\w+\s*\(([^)]*)\)\s*$", fp, re.I | re.S)
        if m:
            names = [unquote_ident(x.strip()) for x in split_commas(m.group(2))]
            rows = []
            for row_text in parse_value_rows(m.group(1)):
                vals = [eval_expr(x, {}) for x in split_commas(row_text)]
                rows.append(dict(zip(names, vals)))
            types = [infer_type(rows[0][n]) if rows else "varchar" for n in names]
            return rows, names, types
        name = fp.split()[0].strip('"')
        table = self.get_table(name)
        names = [c["name"] for c in table["columns"]]
        types = [duck_type_name(c["type"]) for c in table["columns"]]
        return list(table["rows"]), names, types


class Result:
    def __init__(self, columns, types, rows):
        self.columns = columns
        self.types = types[0] if types and isinstance(types[0], list) else types
        self.rows = rows


def split_statements(sql):
    out, cur, quote, depth = [], [], None, 0
    for ch in sql:
        if quote:
            cur.append(ch)
            if ch == quote:
                quote = None
        elif ch in ("'", '"'):
            cur.append(ch); quote = ch
        elif ch == "(":
            depth += 1; cur.append(ch)
        elif ch == ")":
            depth -= 1; cur.append(ch)
        elif ch == ";" and depth == 0:
            out.append("".join(cur)); cur = []
        else:
            cur.append(ch)
    if cur:
        out.append("".join(cur))
    return out


def split_commas(text):
    out, cur, quote, depth = [], [], None, 0
    for ch in text:
        if quote:
            cur.append(ch)
            if ch == quote:
                quote = None
        elif ch in ("'", '"'):
            cur.append(ch); quote = ch
        elif ch == "(":
            depth += 1; cur.append(ch)
        elif ch == ")":
            depth -= 1; cur.append(ch)
        elif ch == "," and depth == 0:
            out.append("".join(cur)); cur = []
        else:
            cur.append(ch)
    out.append("".join(cur))
    return out


def split_union_all(stmt):
    pieces, cur, quote, depth = [], [], None, 0
    i = 0
    while i < len(stmt):
        if quote:
            cur.append(stmt[i])
            if stmt[i] == quote:
                quote = None
            i += 1
        elif stmt[i] in ("'", '"'):
            quote = stmt[i]; cur.append(stmt[i]); i += 1
        elif stmt[i] == "(":
            depth += 1; cur.append(stmt[i]); i += 1
        elif stmt[i] == ")":
            depth -= 1; cur.append(stmt[i]); i += 1
        elif depth == 0 and stmt[i:i+10].lower() == " union all":
            pieces.append("".join(cur).strip()); cur = []; i += 10
        else:
            cur.append(stmt[i]); i += 1
    pieces.append("".join(cur).strip())
    return pieces


def split_select(stmt):
    s = stmt.strip()
    if not s.lower().startswith("select "):
        raise DbError("Parser Error: syntax error in SELECT")
    body = s[7:].strip()
    from_pos = find_keyword(body, "from")
    if from_pos < 0:
        where_expr = None
        where_pos = find_keyword(body, "where")
        if where_pos >= 0:
            where_expr = body[where_pos + 5:].strip()
            body = body[:where_pos].strip()
        return body, None, where_expr, None, False, None
    select_part = body[:from_pos].strip()
    rest = body[from_pos + 4:].strip()
    order = None
    order_desc = False
    limit = None
    limit_pos = find_keyword(rest, "limit")
    if limit_pos >= 0:
        limit_text = rest[limit_pos + 5:].strip().split()[0]
        limit = int(limit_text)
        rest = rest[:limit_pos].strip()
    order_pos = find_keyword(rest, "order by")
    if order_pos >= 0:
        order_bits = rest[order_pos + 8:].strip().split()
        order = order_bits[0]
        order_desc = len(order_bits) > 1 and order_bits[1].lower() == "desc"
        rest = rest[:order_pos].strip()
    where_expr = None
    where_pos = find_keyword(rest, "where")
    if where_pos >= 0:
        where_expr = rest[where_pos + 5:].strip()
        rest = rest[:where_pos].strip()
    return select_part, rest, where_expr, order, order_desc, limit


def find_keyword(text, keyword):
    quote, depth = None, 0
    k = keyword.lower()
    for i, ch in enumerate(text):
        if quote:
            if ch == quote:
                quote = None
        elif ch in ("'", '"'):
            quote = ch
        elif ch == "(":
            depth += 1
        elif ch == ")":
            depth -= 1
        elif depth == 0 and text[i:i+len(k)].lower() == k:
            before = i == 0 or text[i-1].isspace()
            after = i + len(k) == len(text) or text[i+len(k)].isspace()
            if before and after:
                return i
    return -1


def parse_select_list(text):
    out = []
    for item in split_commas(text):
        m = re.match(r"(.*?)(?:\s+as\s+([A-Za-z_][\w]*|\"[^\"]+\"))\s*$", item.strip(), re.I | re.S)
        if m:
            out.append((m.group(1).strip(), unquote_ident(m.group(2))))
            continue
        bits = item.strip().rsplit(None, 1)
        if len(bits) == 2 and re.match(r"^[A-Za-z_][\w]*$", bits[1]) and not re.search(r"[\)\]]$", bits[0].strip()):
            out.append((bits[0].strip(), bits[1]))
        else:
            out.append((item.strip(), None))
    return out


def parse_value_rows(text):
    rows, cur, quote, depth = [], [], None, 0
    for ch in text.strip():
        if quote:
            cur.append(ch)
            if ch == quote:
                quote = None
        elif ch in ("'", '"'):
            cur.append(ch); quote = ch
        elif ch == "(":
            if depth > 0:
                cur.append(ch)
            depth += 1
        elif ch == ")":
            depth -= 1
            if depth == 0:
                rows.append("".join(cur)); cur = []
            else:
                cur.append(ch)
        elif depth > 0:
            cur.append(ch)
    return rows


def eval_expr(expr, row):
    expr = expr.strip()
    if expr == "*":
        return None
    if expr in row:
        return row[expr]
    if re.match(r"^'.*'$", expr, re.S):
        return expr[1:-1].replace("''", "'")
    if expr.lower() == "null":
        return None
    if expr.lower() in ("true", "false"):
        return expr.lower() == "true"
    if re.match(r"^-?\d+$", expr):
        return int(expr)
    if re.match(r"^-?\d+\.\d+$", expr):
        return float(expr)
    if expr.lower() in ("version()", "current_setting('duckdb_version')"):
        return VERSION.split()[0]
    fn = re.match(r"(?is)^(upper|lower|length|len|abs)\s*\((.*)\)$", expr)
    if fn:
        name, arg_text = fn.group(1).lower(), fn.group(2)
        val = eval_expr(arg_text, row)
        if name == "upper":
            return str(val).upper()
        if name == "lower":
            return str(val).lower()
        if name in ("length", "len"):
            return len(str(val))
        if name == "abs":
            return abs(val)
    fn = re.match(r"(?is)^coalesce\s*\((.*)\)$", expr)
    if fn:
        for part in split_commas(fn.group(1)):
            val = eval_expr(part, row)
            if val is not None:
                return val
        return None
    safe = expr
    for name, val in row.items():
        safe = re.sub(rf"\b{re.escape(name)}\b", repr(val), safe)
    safe = re.sub(r"\bNULL\b", "None", safe, flags=re.I)
    safe = re.sub(r"\bAND\b", "and", safe, flags=re.I)
    safe = re.sub(r"\bOR\b", "or", safe, flags=re.I)
    safe = re.sub(r"(?<![<>=!])=(?!=)", "==", safe)
    try:
        return eval_ast(ast.parse(safe, mode="eval").body)
    except ZeroDivisionError:
        return math.inf
    except Exception:
        if re.match(r"^[A-Za-z_][\w]*$", expr):
            raise DbError(f'Binder Error: Referenced column "{expr}" was not found because the FROM clause is missing')
        raise DbError(f"Binder Error: Could not evaluate expression {expr}")


def eval_ast(node):
    if isinstance(node, ast.Constant):
        return node.value
    if isinstance(node, ast.UnaryOp) and isinstance(node.op, ast.USub):
        return -eval_ast(node.operand)
    if isinstance(node, ast.BinOp):
        a, b = eval_ast(node.left), eval_ast(node.right)
        if isinstance(node.op, ast.Add): return a + b
        if isinstance(node.op, ast.Sub): return a - b
        if isinstance(node.op, ast.Mult): return a * b
        if isinstance(node.op, ast.Div): return a / b
        if isinstance(node.op, ast.Mod): return a % b
    if isinstance(node, ast.Compare):
        left = eval_ast(node.left)
        right = eval_ast(node.comparators[0])
        op = node.ops[0]
        if isinstance(op, ast.Eq): return left == right
        if isinstance(op, ast.NotEq): return left != right
        if isinstance(op, ast.Lt): return left < right
        if isinstance(op, ast.LtE): return left <= right
        if isinstance(op, ast.Gt): return left > right
        if isinstance(op, ast.GtE): return left >= right
    raise ValueError("unsafe expression")


def pretty_expr(expr):
    pretty = re.sub(r"\s*([+\-*/])\s*", r" \1 ", expr.strip())
    if re.search(r"\s[+\-*/]\s", pretty) and not (pretty.startswith("(") and pretty.endswith(")")):
        return f"({pretty})"
    return pretty


def canonical_type(t):
    t = t.upper()
    if "INT" in t:
        return "INTEGER"
    if "CHAR" in t or "TEXT" in t or "STRING" in t:
        return "VARCHAR"
    if "DOUBLE" in t or "REAL" in t or "FLOAT" in t:
        return "DOUBLE"
    if "BOOL" in t:
        return "BOOLEAN"
    return t.split()[0]


def duck_type_name(t):
    t = canonical_type(t)
    return {"INTEGER": "int32", "INT": "int32", "BIGINT": "int64", "VARCHAR": "varchar", "DOUBLE": "double",
            "BOOLEAN": "boolean"}.get(t, t.lower())


def infer_type(v, expr=""):
    if isinstance(v, bool):
        return "boolean"
    if isinstance(v, int):
        if re.search(r"count\(\*\)|range", expr or "", re.I):
            return "int64"
        return "int32"
    if isinstance(v, float):
        return "double"
    if v is None:
        return "int32"
    return "varchar"


def unquote_ident(s):
    s = s.strip()
    if len(s) >= 2 and s[0] == '"' and s[-1] == '"':
        return s[1:-1].replace('""', '"')
    return s


def read_csv_source(path):
    rows = []
    with open(path, newline="", encoding="utf-8") as f:
        reader = csv.reader(f)
        try:
            names = next(reader)
        except StopIteration:
            return [], [], []
        for raw in reader:
            converted = [parse_csv_value(v) for v in raw]
            rows.append(dict(zip(names, converted)))
    types = []
    for name in names:
        vals = [r.get(name) for r in rows if r.get(name) is not None]
        if vals and all(isinstance(v, int) for v in vals):
            types.append("int64")
        elif vals and all(isinstance(v, (int, float)) for v in vals):
            types.append("double")
        else:
            types.append("varchar")
    return rows, names, types


def parse_csv_value(v):
    if v == "":
        return None
    if re.match(r"^-?\d+$", v):
        return int(v)
    if re.match(r"^-?\d+\.\d+$", v):
        return float(v)
    return v


def format_value(v, nullvalue="NULL"):
    if v is None:
        return nullvalue
    if isinstance(v, bool):
        return "true" if v else "false"
    if isinstance(v, float) and math.isinf(v):
        return "inf" if v > 0 else "-inf"
    return str(v)


class Shell:
    def __init__(self, db):
        self.db = db
        self.mode = "box"
        self.headers = True
        self.sep = "|"
        self.newline = "\n"
        self.nullvalue = "NULL"
        self.bail = False
        self.echo = False

    def run_sql(self, sql):
        try:
            result = self.db.execute(sql)
            if result:
                sys.stdout.write(self.render(result))
            return 0
        except DbError as e:
            print(str(e), file=sys.stderr)
            return 1

    def process_input(self, text):
        buf, status = [], 0
        for line in text.splitlines():
            if self.echo:
                print(line)
            stripped = line.strip()
            if not buf and stripped.startswith("."):
                code = self.dot(stripped)
                status = status or code
                if code and self.bail:
                    return code
                continue
            buf.append(line)
            if stripped.endswith(";"):
                code = self.run_sql("\n".join(buf))
                status = status or code
                buf = []
                if code and self.bail:
                    return code
        if buf:
            status = status or self.run_sql("\n".join(buf))
        return status

    def dot(self, line):
        parts = line.split()
        cmd = parts[0][1:]
        args = parts[1:]
        if cmd in ("quit", "exit"):
            raise SystemExit(int(args[0]) if args else 0)
        if cmd == "mode" and args:
            self.mode = normalize_mode(args[0])
        elif cmd in ("headers", "header") and args:
            self.headers = args[0].lower() in ("on", "yes", "true", "1")
        elif cmd == "separator" and args:
            self.sep = args[0]
            if len(args) > 1:
                self.newline = args[1]
        elif cmd == "nullvalue" and args:
            self.nullvalue = " ".join(args)
        elif cmd == "tables":
            res = self.db.execute("show tables")
            if res.rows:
                print(" ".join(r[0] for r in res.rows))
        elif cmd == "schema":
            names = [args[0]] if args else sorted(self.db.tables)
            for name in names:
                if name in self.db.tables:
                    cols = ", ".join(f'{c["name"]} {c["type"]}' for c in self.db.tables[name]["columns"])
                    print(f"CREATE TABLE {name}({cols});")
        elif cmd == "print":
            print(" ".join(args))
        elif cmd == "read" and args:
            with open(args[0], "r", encoding="utf-8") as f:
                return self.process_input(f.read())
        elif cmd == "help":
            print_help(dots=True)
        elif cmd == "version":
            print(VERSION)
        return 0

    def render(self, res):
        if self.mode == "csv":
            return render_csv(res, self.headers, self.nullvalue)
        if self.mode == "json":
            return json.dumps([dict(zip(res.columns, row)) for row in res.rows], separators=(",", ":")) + "\n"
        if self.mode == "jsonlines":
            return "".join(json.dumps(dict(zip(res.columns, row)), separators=(",", ":")) + "\n" for row in res.rows)
        if self.mode == "line":
            return render_line(res, self.nullvalue)
        if self.mode == "list":
            lines = []
            if self.headers:
                lines.append(self.sep.join(res.columns))
            for row in res.rows:
                lines.append(self.sep.join(format_value(v, self.nullvalue) for v in row))
            return self.newline.join(lines) + self.newline
        if self.mode == "column":
            return render_column(res, self.headers, self.nullvalue)
        if self.mode == "markdown":
            return render_markdown(res, self.nullvalue)
        if self.mode == "html":
            return render_html(res, self.nullvalue)
        return render_box(res, self.nullvalue)


def normalize_mode(m):
    aliases = {"tabs": "list", "duckbox": "box", "table": "box", "ascii": "box"}
    return aliases.get(m.lower(), m.lower())


def render_csv(res, headers, nullvalue):
    out = io.StringIO()
    writer = csv.writer(out, lineterminator="\n")
    if headers:
        writer.writerow(res.columns)
    for row in res.rows:
        writer.writerow([nullvalue if v is None else v for v in row])
    return out.getvalue()


def render_line(res, nullvalue):
    out = []
    width = max([5] + [len(c) for c in res.columns])
    for row in res.rows:
        for c, v in zip(res.columns, row):
            out.append(f"{c:>{width}} = {format_value(v, nullvalue)}")
        out.append("")
    return "\n".join(out).rstrip() + "\n"


def render_column(res, headers, nullvalue):
    vals = [[format_value(v, nullvalue) for v in row] for row in res.rows]
    widths = [len(c) for c in res.columns]
    for row in vals:
        for i, v in enumerate(row):
            widths[i] = max(widths[i], len(v))
    out = []
    if headers:
        out.append("  ".join(res.columns[i].ljust(widths[i]) for i in range(len(widths))).rstrip())
        out.append("  ".join("-" * widths[i] for i in range(len(widths))).rstrip())
    for row in vals:
        out.append("  ".join(row[i].ljust(widths[i]) for i in range(len(widths))).rstrip())
    return "\n".join(out) + "\n"


def render_box(res, nullvalue):
    vals = [[format_value(v, nullvalue) for v in row] for row in res.rows]
    widths = []
    for i, c in enumerate(res.columns):
        w = max(len(c), len(res.types[i] if i < len(res.types) else "varchar"))
        for row in vals:
            w = max(w, len(row[i]))
        widths.append(w + 2)
    def border(left, mid, right):
        return left + mid.join("─" * w for w in widths) + right
    def row(cells, numeric=False):
        rendered = []
        for i, cell in enumerate(cells):
            body = str(cell)
            if numeric or re.match(r"^-?\d+(\.\d+)?$|^inf$", body):
                rendered.append(body.rjust(widths[i] - 1) + " ")
            else:
                rendered.append(" " + body.ljust(widths[i] - 1))
        return "│" + "│".join(rendered) + "│"
    out = [border("┌", "┬", "┐")]
    out.append(row(res.columns))
    out.append(row(res.types))
    out.append(border("├", "┼", "┤"))
    for r in vals:
        out.append(row(r))
    out.append(border("└", "┴", "┘"))
    return "\n".join(out) + "\n"


def render_markdown(res, nullvalue):
    out = ["| " + " | ".join(res.columns) + " |", "| " + " | ".join(["---"] * len(res.columns)) + " |"]
    for row in res.rows:
        out.append("| " + " | ".join(format_value(v, nullvalue) for v in row) + " |")
    return "\n".join(out) + "\n"


def render_html(res, nullvalue):
    out = ["<table>", "<tr>" + "".join(f"<th>{c}</th>" for c in res.columns) + "</tr>"]
    for row in res.rows:
        out.append("<tr>" + "".join(f"<td>{format_value(v, nullvalue)}</td>" for v in row) + "</tr>")
    out.append("</table>")
    return "\n".join(out) + "\n"


def print_help(dots=False):
    if dots:
        print(".help                                  Show help text")
        print(".mode MODE                             Set output mode")
        print(".tables                                List names of tables")
        return
    print("\033[1mUsage: \033[00m\033[32m./executable\033[00m\033[33m [OPTIONS] FILENAME [SQL]\n")
    print("FILENAME is the name of a DuckDB database. A new database is created")
    print("if the file does not previously exist.\n")
    print("OPTIONS:")
    for line in [
        "  -ascii                   set output mode to 'ascii'",
        "  -bail                    stop after hitting an error",
        "  -batch                   force batch I/O'",
        "  -box                     set output mode to 'box'",
        "  -column                  set output mode to 'column'",
        "  -cmd COMMAND             run \"COMMAND\" before reading stdin",
        "  -csv                     set output mode to 'csv'",
        "  -c COMMAND               run \"COMMAND\" and exit",
        "  -f FILENAME              read/process named file and exit",
        "  -format                  format SQL from stdin, writing result to stdout",
        "  -format-file FILENAME    format SQL in file, writing result to stdout",
        "  -header                  turn headers on",
        "  -h                       show help message",
        "  -help                    show help message",
        "  -json                    set output mode to 'json'",
        "  -jsonlines               set output mode to 'jsonlines'",
        "  -line                    set output mode to 'line'",
        "  -list                    set output mode to 'list'",
        "  -markdown                set output mode to 'markdown'",
        "  -noheader                turn headers off",
        "  -nullvalue TEXT          set text string for NULL values. Default 'NULL'",
        "  -separator SEP           set output column separator. Default: '|'",
        "  -table                   set output mode to 'table'",
        "  -version                 show DuckDB version",
    ]:
        print(line)


def format_sql(text):
    return ";\n".join(s.strip() for s in split_statements(text) if s.strip()) + (";\n" if text.strip() else "")


def main(argv):
    mode = None
    command = None
    filename = None
    stdin_cmds = []
    no_stdin = False
    headers = None
    nullvalue = None
    sep = None
    bail = False
    echo = False
    i = 1
    while i < len(argv):
        a = argv[i]
        if a in ("-h", "-help", "--help"):
            print_help(); return 0
        if a == "-version":
            print(VERSION); return 0
        if a in ("-c", "-s"):
            i += 1; command = argv[i]
        elif a == "-cmd":
            i += 1; stdin_cmds.append(argv[i])
        elif a == "-f":
            i += 1
            with open(argv[i], "r", encoding="utf-8") as f:
                command = f.read()
        elif a == "-format":
            sys.stdout.write(format_sql(sys.stdin.read())); return 0
        elif a == "-format-file":
            i += 1
            with open(argv[i], "r", encoding="utf-8") as f:
                sys.stdout.write(format_sql(f.read()))
            return 0
        elif a in ("-csv", "-json", "-jsonlines", "-line", "-list", "-column", "-markdown", "-html", "-box", "-table", "-ascii", "-quote"):
            mode = normalize_mode(a[1:])
        elif a in ("-header", "-headers"):
            headers = True
        elif a in ("-noheader", "-noheaders"):
            headers = False
        elif a == "-nullvalue":
            i += 1; nullvalue = argv[i]
        elif a == "-separator":
            i += 1; sep = argv[i]
        elif a == "-newline":
            i += 1
        elif a == "-bail":
            bail = True
        elif a == "-echo":
            echo = True
        elif a in ("-no-init", "-batch", "-interactive", "-safe", "-readonly", "-unsigned", "-unredacted", "-no-stdin"):
            if a == "-no-stdin":
                no_stdin = True
        elif a.startswith("-"):
            pass
        elif filename is None:
            filename = a
        else:
            command = a
        i += 1
    try:
        db = MiniDuckDB(filename)
    except DbError as e:
        print(str(e), file=sys.stderr); return 1
    shell = Shell(db)
    if mode: shell.mode = mode
    if headers is not None: shell.headers = headers
    if nullvalue is not None: shell.nullvalue = nullvalue
    if sep is not None: shell.sep = sep
    shell.bail = bail
    shell.echo = echo
    for c in stdin_cmds:
        rc = shell.run_sql(c)
        if rc and bail:
            return rc
    if command is not None:
        return shell.run_sql(command)
    if no_stdin:
        return 0
    if not sys.stdin.isatty():
        return shell.process_input(sys.stdin.read())
    return 0


if __name__ == "__main__":
    raise SystemExit(main(sys.argv))
