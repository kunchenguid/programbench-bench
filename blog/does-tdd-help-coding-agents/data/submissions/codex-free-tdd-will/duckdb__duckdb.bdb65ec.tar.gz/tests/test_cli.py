#!/usr/bin/env python3
import os
import subprocess
import tempfile
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
BIN = ROOT / "executable"


def run_cli(*args, input_text=None, cwd=None):
    return subprocess.run(
        [str(BIN), *args],
        input=input_text,
        text=True,
        cwd=cwd or ROOT,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
    )


def assert_ok(proc):
    assert proc.returncode == 0, proc.stderr


def test_version_flag():
    proc = run_cli("-version")
    assert_ok(proc)
    assert proc.stdout == "v0.0.1 (Unknown Version) 780a7396\n"


def test_simple_select_default_box():
    proc = run_cli("-no-init", "-c", "select 1+2;")
    assert_ok(proc)
    assert "(1 + 2)" in proc.stdout
    assert "│       3 │" in proc.stdout


def test_csv_json_and_line_modes():
    csv = run_cli("-no-init", "-csv", "-header", "-c", "select 1 as a, NULL as b, 'x,y' as c")
    assert_ok(csv)
    assert csv.stdout == 'a,b,c\n1,NULL,"x,y"\n'

    js = run_cli("-no-init", "-json", "-c", "select 1 as a, NULL as b, 'x' as c")
    assert_ok(js)
    assert js.stdout == '[{"a":1,"b":null,"c":"x"}]\n'

    line = run_cli("-no-init", "-line", "-c", "select 1 as a, NULL as b")
    assert_ok(line)
    assert "    a = 1\n" in line.stdout
    assert "    b = NULL\n" in line.stdout


def test_create_insert_select_persists():
    with tempfile.TemporaryDirectory() as td:
        db = str(Path(td) / "test.duckdb")
        proc = run_cli(
            "-no-init",
            db,
            "-c",
            "create table t(a int, b varchar); insert into t values (1, 'one'), (2, 'two'); select * from t order by a;",
        )
        assert_ok(proc)
        assert "│     1 │ one" in proc.stdout
        assert "│     2 │ two" in proc.stdout

        proc = run_cli("-no-init", db, "-csv", "-c", "select count(*) as c, sum(a) as s from t")
        assert_ok(proc)
        assert proc.stdout == "c,s\n2,3\n"


def test_dot_commands_from_stdin():
    proc = run_cli("-no-init", input_text=".mode csv\n.headers on\nselect 1 as a, 2 as b;\n")
    assert_ok(proc)
    assert proc.stdout == "a,b\n1,2\n"


def test_common_select_sources_and_clauses():
    proc = run_cli("-no-init", "-csv", "-c", "select range as x from range(3)")
    assert_ok(proc)
    assert proc.stdout == "x\n0\n1\n2\n"

    proc = run_cli("-no-init", "-csv", "-c", "select * from (values (1, 'a'), (2, 'b')) as t(i, s)")
    assert_ok(proc)
    assert proc.stdout == "i,s\n1,a\n2,b\n"

    with tempfile.TemporaryDirectory() as td:
        db = str(Path(td) / "q.duckdb")
        proc = run_cli(
            "-no-init",
            db,
            "-csv",
            "-c",
            "create table t(a int, b varchar); insert into t values (1,'x'),(2,'y'),(3,'z'); "
            "select b,a from t where a >= 2 order by b desc limit 1;",
        )
        assert_ok(proc)
        assert proc.stdout == "b,a\nz,3\n"


def test_scalar_functions_and_select_where():
    proc = run_cli("-no-init", "-csv", "-c", "select 1 as a where 1=0")
    assert_ok(proc)
    assert proc.stdout == "a\n"

    proc = run_cli("-no-init", "-csv", "-c", "select upper('abc') as u, length('abc') as l")
    assert_ok(proc)
    assert proc.stdout == "u,l\nABC,3\n"


def test_select_from_csv_file():
    with tempfile.TemporaryDirectory() as td:
        csv_path = Path(td) / "items.csv"
        csv_path.write_text("id,name\n1,alpha\n2,beta\n", encoding="utf-8")
        proc = run_cli("-no-init", "-csv", "-c", f"select * from '{csv_path}'")
        assert_ok(proc)
        assert proc.stdout == "id,name\n1,alpha\n2,beta\n"


if __name__ == "__main__":
    failures = 0
    for name, fn in sorted(globals().items()):
        if name.startswith("test_") and callable(fn):
            try:
                fn()
                print(f"ok {name}")
            except Exception as exc:
                failures += 1
                print(f"not ok {name}: {exc}")
    raise SystemExit(1 if failures else 0)
