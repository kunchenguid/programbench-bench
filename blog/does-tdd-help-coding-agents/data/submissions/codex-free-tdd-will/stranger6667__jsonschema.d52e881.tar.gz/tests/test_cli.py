import os
import subprocess
import tempfile
import unittest
import json


ROOT = os.path.dirname(os.path.dirname(__file__))
EXE = os.path.join(ROOT, "executable")


class CliTests(unittest.TestCase):
    def run_cli(self, *args, cwd=None):
        return subprocess.run(
            [EXE, *args],
            cwd=cwd or ROOT,
            text=True,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
        )

    def test_version(self):
        result = self.run_cli("--version")
        self.assertEqual(result.returncode, 0)
        self.assertEqual(result.stdout, "Version: 0.41.0\n")

    def test_default_text_reports_validation_errors(self):
        with tempfile.TemporaryDirectory() as td:
            schema = os.path.join(td, "schema.json")
            bad = os.path.join(td, "bad.json")
            with open(schema, "w") as f:
                f.write('{"type":"object","properties":{"age":{"type":"integer","minimum":0}},"required":["name"],"additionalProperties":false}')
            with open(bad, "w") as f:
                f.write('{"age":-1,"extra":true}')
            result = self.run_cli(schema, "-i", bad)
        self.assertEqual(result.returncode, 1)
        self.assertIn("bad.json - INVALID. Errors:", result.stdout)
        self.assertIn("-1 is less than the minimum of 0", result.stdout)
        self.assertIn("'extra' was unexpected", result.stdout)
        self.assertIn('"name" is a required property', result.stdout)

    def test_flag_output_for_multiple_instances(self):
        with tempfile.TemporaryDirectory() as td:
            schema = os.path.join(td, "schema.json")
            good = os.path.join(td, "good.json")
            bad = os.path.join(td, "bad.json")
            with open(schema, "w") as f:
                f.write('{"type":"number","minimum":2}')
            with open(good, "w") as f:
                f.write("3")
            with open(bad, "w") as f:
                f.write("1")
            result = self.run_cli("--output", "flag", schema, "-i", good, "-i", bad)
        self.assertEqual(result.returncode, 1)
        lines = [json.loads(line) for line in result.stdout.splitlines()]
        self.assertEqual([line["payload"]["valid"] for line in lines], [True, False])
        self.assertEqual([line["output"] for line in lines], ["flag", "flag"])

    def test_format_is_asserted_only_when_requested(self):
        with tempfile.TemporaryDirectory() as td:
            schema = os.path.join(td, "schema.json")
            inst = os.path.join(td, "bad.json")
            with open(schema, "w") as f:
                f.write('{"type":"string","format":"email"}')
            with open(inst, "w") as f:
                f.write('"not-email"')
            default = self.run_cli(schema, "-i", inst)
            asserted = self.run_cli("--assert-format", schema, "-i", inst)
        self.assertEqual(default.returncode, 0)
        self.assertIn(" - VALID", default.stdout)
        self.assertEqual(asserted.returncode, 1)
        self.assertIn('"not-email" is not a "email"', asserted.stdout)


if __name__ == "__main__":
    unittest.main()
