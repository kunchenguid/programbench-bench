#!/usr/bin/env python3
import json
import math
import os
import re
import sys
from urllib.parse import quote


VALID_TYPES = {"null", "boolean", "object", "array", "number", "integer", "string"}
OUTPUTS = {"text", "flag", "list", "hierarchical"}
DRAFTS = {"4", "6", "7", "2019", "2020"}


class ValidationError:
    def __init__(self, message, path="", schema_path=""):
        self.message = message
        self.path = path
        self.schema_path = schema_path


def usage(full=True):
    if full:
        return """Usage: executable [OPTIONS] [SCHEMA]

Arguments:
  [SCHEMA]  The JSON Schema to validate with (i.e. schema.json)

Options:
  -i, --instance <INSTANCES>       A path to a JSON instance (i.e. filename.json) to validate (may be specified multiple times)
  -d, --draft <DRAFT>              Enforce a specific JSON Schema draft [possible values: 4, 6, 7, 2019, 2020]
      --assert-format              Turn ON format validation
      --no-assert-format           Turn OFF format validation
      --output <OUTPUT>            Select output style: text (default), flag, list, hierarchical [default: text] [possible values: text, flag, list, hierarchical]
  -v, --version                    Show program's version number and exit
      --errors-only                Only show validation errors
      --connect-timeout <SECONDS>  Timeout for establishing connections (in seconds)
      --timeout <SECONDS>          Total timeout for HTTP requests (in seconds)
  -k, --insecure                   Skip TLS certificate verification (dangerous!)
      --cacert <FILE>              Path to a custom CA certificate file (PEM format)
  -h, --help                       Print help
"""
    return """Usage: executable <SCHEMA>

For more information, try '--help'."""


def parse_args(argv):
    opts = {"instances": [], "output": "text", "assert_format": False}
    schema = None
    i = 0
    while i < len(argv):
        a = argv[i]
        if a in ("-h", "--help"):
            print(usage(True), end="")
            return None, 0
        if a in ("-v", "--version"):
            print("Version: 0.41.0")
            return None, 0
        if a in ("-i", "--instance"):
            i += 1
            if i >= len(argv):
                print(f"error: a value is required for '{a} <INSTANCES>' but none was supplied")
                return None, 2
            opts["instances"].append(argv[i])
        elif a in ("-d", "--draft"):
            i += 1
            if i >= len(argv):
                print(f"error: a value is required for '{a} <DRAFT>' but none was supplied")
                return None, 2
            if argv[i] not in DRAFTS:
                print(f"error: invalid value '{argv[i]}' for '--draft <DRAFT>'")
                print("  [possible values: 4, 6, 7, 2019, 2020]\n")
                print("For more information, try '--help'.")
                return None, 2
            opts["draft"] = argv[i]
        elif a == "--output":
            i += 1
            if i >= len(argv):
                print("error: a value is required for '--output <OUTPUT>' but none was supplied")
                return None, 2
            if argv[i] not in OUTPUTS:
                print(f"error: invalid value '{argv[i]}' for '--output <OUTPUT>'")
                print("  [possible values: text, flag, list, hierarchical]\n")
                print("For more information, try '--help'.")
                return None, 2
            opts["output"] = argv[i]
        elif a == "--assert-format":
            opts["assert_format"] = True
        elif a == "--no-assert-format":
            opts["assert_format"] = False
        elif a in ("--errors-only", "-k", "--insecure"):
            opts[a.lstrip("-").replace("-", "_")] = True
        elif a in ("--connect-timeout", "--timeout", "--cacert"):
            i += 1
        elif a.startswith("-"):
            print(f"error: unexpected argument '{a}' found\n")
            print(f"  tip: to pass '{a}' as a value, use '-- {a}'\n")
            print("Usage: executable [OPTIONS] [SCHEMA]\n")
            print("For more information, try '--help'.")
            return None, 2
        elif schema is None:
            schema = a
        else:
            print(f"error: unexpected argument '{a}' found")
            return None, 2
        i += 1
    if schema is None:
        print("error: the following required arguments were not provided:")
        print("  <SCHEMA>\n")
        print(usage(False), end="\n")
        return None, 2
    opts["schema"] = schema
    return opts, None


def load_json(path):
    try:
        with open(path, "r", encoding="utf-8") as f:
            return json.load(f), None
    except FileNotFoundError:
        return None, "No such file or directory (os error 2)"
    except json.JSONDecodeError as e:
        msg = e.msg
        if msg.startswith("Expecting value"):
            msg = "expected value"
        elif msg.startswith("Expecting property name"):
            msg = "key must be a string"
        return None, f"{msg} at line {e.lineno} column {e.colno}"
    except OSError as e:
        return None, str(e)


def jrepr(v):
    if isinstance(v, bool):
        return "true" if v else "false"
    if v is None:
        return "null"
    return json.dumps(v, ensure_ascii=False, separators=(",", ":"), sort_keys=True)


def sentence_join(values):
    vals = [jrepr(v) for v in values]
    if len(vals) == 1:
        return vals[0]
    return ", ".join(vals[:-1]) + " or " + vals[-1]


def type_name(v):
    if v is None:
        return "null"
    if isinstance(v, bool):
        return "boolean"
    if isinstance(v, dict):
        return "object"
    if isinstance(v, list):
        return "array"
    if isinstance(v, str):
        return "string"
    if isinstance(v, int) and not isinstance(v, bool):
        return "integer"
    if isinstance(v, float):
        return "number"
    return "unknown"


def pointer(path):
    if not path:
        return ""
    return "".join("/" + str(p).replace("~", "~0").replace("/", "~1") for p in path)


def is_type(inst, typ):
    if typ == "null":
        return inst is None
    if typ == "boolean":
        return isinstance(inst, bool)
    if typ == "object":
        return isinstance(inst, dict)
    if typ == "array":
        return isinstance(inst, list)
    if typ == "string":
        return isinstance(inst, str)
    if typ == "integer":
        return isinstance(inst, int) and not isinstance(inst, bool)
    if typ == "number":
        return (isinstance(inst, int) or isinstance(inst, float)) and not isinstance(inst, bool)
    return True


def validate_schema(schema):
    if isinstance(schema, bool):
        return None
    if not isinstance(schema, dict):
        return "schema must be an object or boolean"
    t = schema.get("type")
    if isinstance(t, str) and t not in VALID_TYPES:
        return f"{jrepr(t)} is not valid under any of the schemas listed in the 'anyOf' keyword"
    if isinstance(t, list):
        for x in t:
            if x not in VALID_TYPES:
                return f"{jrepr(x)} is not valid under any of the schemas listed in the 'anyOf' keyword"
    for k in ("properties", "patternProperties", "$defs", "definitions"):
        if isinstance(schema.get(k), dict):
            for sub in schema[k].values():
                err = validate_schema(sub)
                if err:
                    return err
    for k in ("items", "additionalProperties", "not", "contains", "propertyNames", "if", "then", "else"):
        if k in schema:
            if isinstance(schema[k], list):
                for sub in schema[k]:
                    err = validate_schema(sub)
                    if err:
                        return err
            else:
                err = validate_schema(schema[k])
                if err:
                    return err
    for k in ("allOf", "anyOf", "oneOf"):
        if isinstance(schema.get(k), list):
            for sub in schema[k]:
                err = validate_schema(sub)
                if err:
                    return err
    if isinstance(schema.get("prefixItems"), list):
        for sub in schema["prefixItems"]:
            err = validate_schema(sub)
            if err:
                return err
    return None


def validate(inst, schema, ipath=None, spath=None, root=None, assert_format=False):
    ipath = ipath or []
    spath = spath or []
    root = root if root is not None else schema
    errors = []
    if schema is True:
        return []
    if schema is False:
        return [ValidationError("False schema does not allow any value", pointer(ipath), pointer(spath))]
    if not isinstance(schema, dict):
        return []

    if "$ref" in schema:
        target = resolve_ref(root, schema["$ref"])
        if target is not None:
            return validate(inst, target, ipath, spath + ["$ref"], root, assert_format)

    if "type" in schema:
        typ = schema["type"]
        ok = any(is_type(inst, t) for t in typ) if isinstance(typ, list) else is_type(inst, typ)
        if not ok:
            name = sentence_join(typ) if isinstance(typ, list) else jrepr(typ)
            errors.append(ValidationError(f"{jrepr(inst)} is not of type {name}", pointer(ipath), pointer(spath + ["type"])))

    if "enum" in schema and inst not in schema["enum"]:
        errors.append(ValidationError(f"{jrepr(inst)} is not one of {sentence_join(schema['enum'])}", pointer(ipath), pointer(spath + ["enum"])))
    if "const" in schema and inst != schema["const"]:
        errors.append(ValidationError(f"{jrepr(schema['const'])} was expected", pointer(ipath), pointer(spath + ["const"])))

    if isinstance(inst, (int, float)) and not isinstance(inst, bool):
        n = inst
        if "multipleOf" in schema:
            m = schema["multipleOf"]
            if m and not math.isclose(n / m, round(n / m), rel_tol=1e-12, abs_tol=1e-12):
                errors.append(ValidationError(f"{jrepr(n)} is not a multiple of {jrepr(m)}", pointer(ipath), pointer(spath + ["multipleOf"])))
        if "minimum" in schema and n < schema["minimum"]:
            errors.append(ValidationError(f"{jrepr(n)} is less than the minimum of {jrepr(schema['minimum'])}", pointer(ipath), pointer(spath + ["minimum"])))
        if "maximum" in schema and n > schema["maximum"]:
            errors.append(ValidationError(f"{jrepr(n)} is greater than the maximum of {jrepr(schema['maximum'])}", pointer(ipath), pointer(spath + ["maximum"])))
        if "exclusiveMinimum" in schema:
            ex = schema["exclusiveMinimum"]
            if isinstance(ex, bool):
                if ex and "minimum" in schema and n <= schema["minimum"]:
                    errors.append(ValidationError(f"{jrepr(n)} is less than or equal to the minimum of {jrepr(schema['minimum'])}", pointer(ipath), pointer(spath + ["exclusiveMinimum"])))
            elif n <= ex:
                errors.append(ValidationError(f"{jrepr(n)} is less than or equal to the minimum of {jrepr(ex)}", pointer(ipath), pointer(spath + ["exclusiveMinimum"])))
        if "exclusiveMaximum" in schema:
            ex = schema["exclusiveMaximum"]
            if isinstance(ex, bool):
                if ex and "maximum" in schema and n >= schema["maximum"]:
                    errors.append(ValidationError(f"{jrepr(n)} is greater than or equal to the maximum of {jrepr(schema['maximum'])}", pointer(ipath), pointer(spath + ["exclusiveMaximum"])))
            elif n >= ex:
                errors.append(ValidationError(f"{jrepr(n)} is greater than or equal to the maximum of {jrepr(ex)}", pointer(ipath), pointer(spath + ["exclusiveMaximum"])))

    if isinstance(inst, str):
        if "minLength" in schema and len(inst) < schema["minLength"]:
            errors.append(ValidationError(f"{jrepr(inst)} is shorter than {schema['minLength']} characters", pointer(ipath), pointer(spath + ["minLength"])))
        if "maxLength" in schema and len(inst) > schema["maxLength"]:
            errors.append(ValidationError(f"{jrepr(inst)} is longer than {schema['maxLength']} characters", pointer(ipath), pointer(spath + ["maxLength"])))
        if "pattern" in schema and re.search(schema["pattern"], inst) is None:
            errors.append(ValidationError(f"{jrepr(inst)} does not match {jrepr(schema['pattern'])}", pointer(ipath), pointer(spath + ["pattern"])))
        if assert_format and schema.get("format") and not check_format(inst, schema["format"]):
            errors.append(ValidationError(f"{jrepr(inst)} is not a {jrepr(schema['format'])}", pointer(ipath), pointer(spath + ["format"])))

    if isinstance(inst, list):
        if "minItems" in schema and len(inst) < schema["minItems"]:
            errors.append(ValidationError(f"{jrepr(inst)} has fewer than {schema['minItems']} items", pointer(ipath), pointer(spath + ["minItems"])))
        if "maxItems" in schema and len(inst) > schema["maxItems"]:
            errors.append(ValidationError(f"{jrepr(inst)} has more than {schema['maxItems']} items", pointer(ipath), pointer(spath + ["maxItems"])))
        if schema.get("uniqueItems") is True:
            seen = set()
            unique = True
            for v in inst:
                key = json.dumps(v, sort_keys=True, separators=(",", ":"))
                if key in seen:
                    unique = False
                    break
                seen.add(key)
            if not unique:
                errors.append(ValidationError(f"{jrepr(inst)} has non-unique elements", pointer(ipath), pointer(spath + ["uniqueItems"])))
        if isinstance(schema.get("prefixItems"), list):
            plen = len(schema["prefixItems"])
            if schema.get("items") is False:
                for idx in range(plen, len(inst)):
                    errors.extend(validate(inst[idx], False, ipath + [idx], spath + ["items"], root, assert_format))
            for idx, subschema in enumerate(schema["prefixItems"]):
                if idx < len(inst):
                    errors.extend(validate(inst[idx], subschema, ipath + [idx], spath + ["prefixItems", idx], root, assert_format))
        elif isinstance(schema.get("items"), list):
            ilen = len(schema["items"])
            if schema.get("additionalItems") is False:
                for idx in range(ilen, len(inst)):
                    errors.extend(validate(inst[idx], False, ipath + [idx], spath + ["additionalItems"], root, assert_format))
            for idx, subschema in enumerate(schema["items"]):
                if idx < len(inst):
                    errors.extend(validate(inst[idx], subschema, ipath + [idx], spath + ["items", idx], root, assert_format))
        elif schema.get("items") is False:
            for idx, val in enumerate(inst):
                errors.extend(validate(val, False, ipath + [idx], spath + ["items"], root, assert_format))
        elif isinstance(schema.get("items"), dict):
            for idx, val in enumerate(inst):
                errors.extend(validate(val, schema["items"], ipath + [idx], spath + ["items"], root, assert_format))
        if "contains" in schema and not any(not validate(v, schema["contains"], ipath + [i], spath + ["contains"], root, assert_format) for i, v in enumerate(inst)):
            errors.append(ValidationError(f"{jrepr(inst)} does not contain items matching the given schema", pointer(ipath), pointer(spath + ["contains"])))

    if isinstance(inst, dict):
        props = schema.get("properties", {}) if isinstance(schema.get("properties"), dict) else {}
        patterns = schema.get("patternProperties", {}) if isinstance(schema.get("patternProperties"), dict) else {}
        required = schema.get("required", []) if isinstance(schema.get("required"), list) else []
        if "minProperties" in schema and len(inst) < schema["minProperties"]:
            errors.append(ValidationError(f"{jrepr(inst)} has fewer than {schema['minProperties']} properties", pointer(ipath), pointer(spath + ["minProperties"])))
        if "maxProperties" in schema and len(inst) > schema["maxProperties"]:
            errors.append(ValidationError(f"{jrepr(inst)} has more than {schema['maxProperties']} properties", pointer(ipath), pointer(spath + ["maxProperties"])))
        for key in sorted(props.keys()):
            if key in inst:
                errors.extend(validate(inst[key], props[key], ipath + [key], spath + ["properties", key], root, assert_format))
        matched_by_pattern = set()
        for pat, pschema in patterns.items():
            try:
                cre = re.compile(pat)
            except re.error:
                continue
            for key in sorted(inst.keys()):
                if cre.search(key):
                    matched_by_pattern.add(key)
                    errors.extend(validate(inst[key], pschema, ipath + [key], spath + ["patternProperties", pat], root, assert_format))
        if schema.get("additionalProperties") is False:
            extra = sorted([k for k in inst.keys() if k not in props and k not in matched_by_pattern])
            for k in extra:
                errors.append(ValidationError(f"Additional properties are not allowed ('{k}' was unexpected)", pointer(ipath), pointer(spath + ["additionalProperties"])))
        elif isinstance(schema.get("additionalProperties"), dict):
            for key in sorted(inst.keys()):
                if key not in props and key not in matched_by_pattern:
                    errors.extend(validate(inst[key], schema["additionalProperties"], ipath + [key], spath + ["additionalProperties"], root, assert_format))
        if isinstance(schema.get("propertyNames"), dict):
            for key in sorted(inst.keys()):
                errors.extend(validate(key, schema["propertyNames"], ipath + [key], spath + ["propertyNames"], root, assert_format))
        for req in required:
            if req not in inst:
                errors.append(ValidationError(f"{jrepr(req)} is a required property", pointer(ipath), pointer(spath + ["required"])))
        if isinstance(schema.get("dependencies"), dict):
            for key, dep in schema["dependencies"].items():
                if key in inst:
                    if isinstance(dep, list):
                        for req in dep:
                            if req not in inst:
                                errors.append(ValidationError(f"{jrepr(req)} is a required property", pointer(ipath), pointer(spath + ["dependencies", key])))
                    elif isinstance(dep, dict):
                        errors.extend(validate(inst, dep, ipath, spath + ["dependencies", key], root, assert_format))
        if isinstance(schema.get("dependentRequired"), dict):
            for key, reqs in schema["dependentRequired"].items():
                if key in inst:
                    for req in reqs:
                        if req not in inst:
                            errors.append(ValidationError(f"{jrepr(req)} is a required property", pointer(ipath), pointer(spath + ["dependentRequired", key])))
        if isinstance(schema.get("dependentSchemas"), dict):
            for key, dep in schema["dependentSchemas"].items():
                if key in inst:
                    errors.extend(validate(inst, dep, ipath, spath + ["dependentSchemas", key], root, assert_format))

    for keyword in ("allOf", "anyOf", "oneOf"):
        if isinstance(schema.get(keyword), list):
            valids = [not validate(inst, sub, ipath, spath + [keyword, idx], root, assert_format) for idx, sub in enumerate(schema[keyword])]
            if keyword == "allOf" and not all(valids):
                errors.append(ValidationError(f"{jrepr(inst)} is not valid under all of the schemas listed in the 'allOf' keyword", pointer(ipath), pointer(spath + [keyword])))
            if keyword == "anyOf" and not any(valids):
                errors.append(ValidationError(f"{jrepr(inst)} is not valid under any of the schemas listed in the 'anyOf' keyword", pointer(ipath), pointer(spath + [keyword])))
            if keyword == "oneOf" and sum(1 for v in valids if v) != 1:
                errors.append(ValidationError(f"{jrepr(inst)} is not valid under exactly one of the schemas listed in the 'oneOf' keyword", pointer(ipath), pointer(spath + [keyword])))
    if "not" in schema and not validate(inst, schema["not"], ipath, spath + ["not"], root, assert_format):
        errors.append(ValidationError(f"{jrepr(inst)} should not be valid under the schema", pointer(ipath), pointer(spath + ["not"])))
    if "if" in schema:
        if_valid = not validate(inst, schema["if"], ipath, spath + ["if"], root, assert_format)
        if if_valid and "then" in schema:
            errors.extend(validate(inst, schema["then"], ipath, spath + ["then"], root, assert_format))
        if not if_valid and "else" in schema:
            errors.extend(validate(inst, schema["else"], ipath, spath + ["else"], root, assert_format))
    return errors


def check_format(value, fmt):
    if fmt == "email":
        return bool(re.match(r"^[^@\s]+@[^@\s]+\.[^@\s]+$", value))
    if fmt in ("hostname", "idn-hostname"):
        return bool(re.match(r"^[A-Za-z0-9.-]+$", value)) and ".." not in value and len(value) <= 253
    if fmt == "ipv4":
        parts = value.split(".")
        return len(parts) == 4 and all(p.isdigit() and str(int(p)) == p and 0 <= int(p) <= 255 for p in parts)
    if fmt == "ipv6":
        return ":" in value
    if fmt in ("uri", "iri"):
        return bool(re.match(r"^[A-Za-z][A-Za-z0-9+.-]*:", value))
    if fmt in ("uri-reference", "iri-reference"):
        return True
    if fmt == "uuid":
        return bool(re.match(r"^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[1-5][0-9a-fA-F]{3}-[89abAB][0-9a-fA-F]{3}-[0-9a-fA-F]{12}$", value))
    if fmt == "date":
        return bool(re.match(r"^\d{4}-\d{2}-\d{2}$", value))
    if fmt == "time":
        return bool(re.match(r"^\d{2}:\d{2}:\d{2}", value))
    if fmt == "date-time":
        return bool(re.match(r"^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}", value))
    if fmt == "regex":
        try:
            re.compile(value)
            return True
        except re.error:
            return False
    return True


def resolve_ref(root, ref):
    if not isinstance(ref, str) or not ref.startswith("#"):
        return None
    cur = root
    parts = ref[1:].split("/")
    if parts == [""]:
        return root
    for part in parts[1:] if parts and parts[0] == "" else parts:
        part = part.replace("~1", "/").replace("~0", "~")
        if isinstance(cur, dict) and part in cur:
            cur = cur[part]
        else:
            return None
    return cur


def schema_uri(path, schema_path=""):
    return "file://" + quote(os.path.abspath(path)) + "#" + schema_path


def err_key(schema_path):
    return schema_path.strip("/").split("/")[-1] or ""


def detail_node(schema_path, eval_path, inst_path, instance_location, valid, errors):
    if errors:
        d = {"errors": {err_key(e.schema_path): e.message for e in errors}}
    else:
        d = {}
    d.update({
        "evaluationPath": eval_path,
        "instanceLocation": instance_location,
        "schemaLocation": schema_uri(schema_path, eval_path),
        "valid": valid,
    })
    return d


def build_details(schema, inst, schema_path, errors):
    def related(prefix):
        return [e for e in errors if e.schema_path == prefix or e.schema_path.startswith(prefix + "/")]

    def direct(prefix):
        return [e for e in errors if e.schema_path == prefix]

    def nodes_for(subschema, value, ep="", ip=""):
        node_errors = related(ep)
        node = detail_node(schema_path, ep, schema_path, ip, not node_errors, direct(ep))
        children = []
        if not isinstance(subschema, dict):
            return node
        if "type" in subschema:
            children.append(detail_node(schema_path, ep + "/type", schema_path, ip, not direct(ep + "/type"), direct(ep + "/type")))
        if "enum" in subschema:
            children.append(detail_node(schema_path, ep + "/enum", schema_path, ip, not direct(ep + "/enum"), direct(ep + "/enum")))
        if "const" in subschema:
            children.append(detail_node(schema_path, ep + "/const", schema_path, ip, not direct(ep + "/const"), direct(ep + "/const")))
        for key in ("minLength", "maxLength", "pattern", "minimum", "maximum", "exclusiveMinimum", "exclusiveMaximum", "multipleOf", "minItems", "maxItems", "uniqueItems"):
            if key in subschema:
                children.append(detail_node(schema_path, ep + "/" + key, schema_path, ip, not direct(ep + "/" + key), direct(ep + "/" + key)))
        if isinstance(value, list) and isinstance(subschema.get("items"), dict):
            for i, item in enumerate(value):
                children.append(nodes_for(subschema["items"], item, ep + "/items", ip + f"/{i}"))
        if isinstance(value, dict):
            props = subschema.get("properties", {}) if isinstance(subschema.get("properties"), dict) else {}
            ap_errors = direct(ep + "/additionalProperties") + direct(ep + "/required") + [
                e for e in errors if e.schema_path.startswith(ep + "/dependentRequired/")
            ]
            ap = None
            if "additionalProperties" in subschema or props or "required" in subschema:
                ap = detail_node(schema_path, ep + "/additionalProperties", schema_path, ip, not ap_errors, ap_errors)
            prop_nodes = []
            for key in sorted(props.keys()):
                if key in value:
                    child = nodes_for(props[key], value[key], ep + "/properties/" + key, ip + "/" + key.replace("~", "~0").replace("/", "~1"))
                    prop_nodes.append(child)
            if ap is not None:
                if prop_nodes:
                    ap["details"] = prop_nodes
                    if any(not c["valid"] for c in prop_nodes):
                        ap["valid"] = False
                children.append(ap)
            else:
                children.extend(prop_nodes)
        if children:
            base = {k: v for k, v in node.items() if k not in ("details", "errors")}
            reordered = {"details": children}
            if "errors" in node:
                reordered["errors"] = node["errors"]
            reordered.update(base)
            node = reordered
            if any(not c["valid"] for c in children):
                node["valid"] = False
        return node

    root = nodes_for(schema, inst)
    flat = []

    def walk(n):
        copy = {k: v for k, v in n.items() if k != "details"}
        flat.append(copy)
        for c in n.get("details", []):
            walk(c)

    walk(root)
    return root, flat


def json_result(schema_path, inst_path, output, valid, errors, schema=None, inst=None):
    payload = {"valid": valid}
    if output in ("list", "hierarchical"):
        root, flat = build_details(schema, inst, schema_path, errors)
        if output == "list":
            payload = {"details": flat, "valid": valid}
        else:
            payload = {"details": root}
    obj = {"instance": inst_path, "output": output, "payload": payload, "schema": schema_path}
    return json.dumps(obj, separators=(",", ":"), sort_keys=False)


def main(argv):
    opts, status = parse_args(argv)
    if status is not None:
        return status
    schema, err = load_json(opts["schema"])
    if err:
        print(f"Error: {err}")
        return 1
    schema_err = validate_schema(schema)
    if schema_err:
        print(f"Schema is invalid. Error: {schema_err}")
        return 1
    if not opts["instances"]:
        print("Schema is valid")
        return 0
    overall = 0
    for inst_path in opts["instances"]:
        inst, err = load_json(inst_path)
        if err:
            print(f"Error: {err}")
            return 1
        errors = validate(inst, schema, root=schema, assert_format=opts["assert_format"])
        valid = not errors
        if not valid:
            overall = 1
        if opts["output"] == "text":
            if valid:
                if not opts.get("errors_only"):
                    print(f"{inst_path} - VALID")
            else:
                print(f"{inst_path} - INVALID. Errors:")
                for idx, e in enumerate(errors, 1):
                    print(f"{idx}. {e.message}")
        else:
            print(json_result(opts["schema"], inst_path, opts["output"], valid, errors, schema, inst))
    return overall


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
