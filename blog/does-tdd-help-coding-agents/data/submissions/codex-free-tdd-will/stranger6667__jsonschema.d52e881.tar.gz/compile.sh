#!/bin/bash
set -e
cp src/jsonschema_cli.py executable
chmod +x executable
