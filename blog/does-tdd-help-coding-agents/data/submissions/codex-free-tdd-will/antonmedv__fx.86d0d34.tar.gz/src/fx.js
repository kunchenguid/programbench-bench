#!/usr/bin/env node
"use strict";

const fs = require("fs");
const VERSION = "39.2.0";

function readStdin() {
  try {
    return fs.readFileSync(0, "utf8");
  } catch {
    return "";
  }
}

function parseJsonInputs(text) {
  const trimmed = text.trim();
  if (trimmed === "") return undefined;
  try {
    return JSON.parse(trimmed);
  } catch (wholeErr) {
    const values = [];
    for (const line of text.split(/\r?\n/)) {
      if (line.trim() === "") continue;
      try {
        values.push(JSON.parse(line));
      } catch {
        throw wholeErr;
      }
    }
    if (values.length === 1) return values[0];
    return values;
  }
}

function parseAtom(s) {
  const t = s.trim();
  if (/^-?\d+(\.\d+)?$/.test(t)) return Number(t);
  if (t === "true") return true;
  if (t === "false") return false;
  if (t === "null") return null;
  if ((t.startsWith('"') && t.endsWith('"')) || (t.startsWith("'") && t.endsWith("'"))) {
    return t.slice(1, -1);
  }
  if (t.startsWith("[") && t.endsWith("]")) {
    try { return JSON.parse(t); } catch {}
    return t.slice(1, -1).split(",").map(parseAtom);
  }
  return t;
}

function parseYamlBasic(text) {
  const root = {};
  const lines = text.split(/\r?\n/);
  for (let i = 0; i < lines.length; i++) {
    const line = lines[i];
    if (!line.trim() || line.trim().startsWith("#")) continue;
    const m = line.match(/^([A-Za-z0-9_.-]+):(?:\s*(.*))?$/);
    if (!m) continue;
    const key = m[1];
    const rest = (m[2] || "").trim();
    if (rest !== "") {
      root[key] = parseAtom(rest);
    } else {
      const arr = [];
      while (i + 1 < lines.length && /^\s+-\s+/.test(lines[i + 1])) {
        i++;
        arr.push(parseAtom(lines[i].replace(/^\s+-\s+/, "")));
      }
      root[key] = arr;
    }
  }
  return root;
}

function parseTomlBasic(text) {
  const root = {};
  for (const line of text.split(/\r?\n/)) {
    const cleaned = line.replace(/#.*$/, "").trim();
    if (!cleaned || cleaned.startsWith("[")) continue;
    const idx = cleaned.indexOf("=");
    if (idx < 0) continue;
    root[cleaned.slice(0, idx).trim()] = parseAtom(cleaned.slice(idx + 1));
  }
  return root;
}

function parseArgs(argv) {
  const opts = { raw: false, slurp: false, yaml: false, toml: false, noInline: false, comp: null, positionals: [] };
  for (let i = 0; i < argv.length; i++) {
    const a = argv[i];
    if (a === "-r" || a === "--raw") opts.raw = true;
    else if (a === "-s" || a === "--slurp") opts.slurp = true;
    else if (a === "--yaml") opts.yaml = true;
    else if (a === "--toml") opts.toml = true;
    else if (a === "--no-inline") opts.noInline = true;
    else if (a === "--strict") {}
    else if (a === "--comp") opts.comp = argv[++i] || "";
    else opts.positionals.push(a);
  }
  return opts;
}

function quoteString(s) {
  return JSON.stringify(String(s));
}

function isScalar(v) {
  return v === null || typeof v !== "object";
}

function inlineFormat(v) {
  if (typeof v === "string") return quoteString(v);
  if (v === undefined) return "undefined";
  if (isScalar(v)) return JSON.stringify(v);
  if (Array.isArray(v) && v.every((x) => typeof x === "number" || typeof x === "boolean" || x === null)) {
    return `[ ${v.map(inlineFormat).join(", ")} ]`;
  }
  if (!Array.isArray(v) && Object.values(v).every(isScalar)) {
    return `{ ${Object.entries(v).map(([k, val]) => `${quoteString(k)}: ${inlineFormat(val)}`).join(", ")} }`;
  }
  return null;
}

function formatValue(v, indent = 0, noInline = false, context = "root") {
  const pad = " ".repeat(indent);
  const child = " ".repeat(indent + 2);
  if (v === undefined) return "undefined";
  if (typeof v === "string") return v;
  if (isScalar(v)) return JSON.stringify(v);
  const canInlineContainer = context === "array";
  const inline = noInline || (v && typeof v === "object" && !canInlineContainer) ? null : inlineFormat(v);
  if (inline !== null) return inline;
  if (Array.isArray(v)) {
    if (v.length === 0) return "[]";
    return "[\n" + v.map((item) => {
      const itemInline = noInline ? null : inlineFormat(item);
      const rendered = itemInline !== null ? itemInline : formatValue(item, indent + 2, noInline, "array");
      return child + rendered;
    }).join(",\n") + "\n" + pad + "]";
  }
  const entries = Object.entries(v);
  if (entries.length === 0) return "{}";
  return "{\n" + entries.map(([k, val]) => {
    const valInline = noInline ? null : (Array.isArray(val) ? inlineFormat(val) : (isScalar(val) ? inlineFormat(val) : null));
    const rendered = valInline !== null ? valInline : formatValue(val, indent + 2, noInline, "object");
    return `${child}${quoteString(k)}: ${rendered}`;
  }).join(",\n") + "\n" + pad + "}";
}

function normalizeQuery(query) {
  if (!query || query === ".") return "x";
  let q = query.trim();
  if (q.startsWith(".")) return "x" + q;
  if (q.includes("=>")) return `(${q})(x)`;
  return q;
}

function evaluateQuery(value, query) {
  const expr = normalizeQuery(query);
  return Function("x", `const keys = Object.keys(x ?? {}); return (${expr});`)(value);
}

function main(argv) {
  const opts = parseArgs(argv);
  if (argv.includes("--help") || argv.includes("-h")) {
    console.log(`
  fx ${VERSION}
    Terminal JSON viewer

  Usage
    fx data.json
    fx data.json .field
    curl ... | fx

  Flags
    -h, --help            print help
    -v, --version         print version
    --themes              print themes
    --comp <shell>        print completion script
    -r, --raw             treat input as a raw string
    -s, --slurp           read all inputs into an array
    --yaml                parse input as YAML
    --toml                parse input as TOML
    --strict              strict mode
    --no-inline           disable inlining in output
    --game-of-life        play the game of life

  More info
    https://fx.wtf

  Author
    Anton Medvedev <anton@medv.io>
`);
    return 0;
  }
  if (argv.includes("--version") || argv.includes("-v")) {
    console.log(VERSION);
    return 0;
  }
  if (opts.comp !== null) {
    if (opts.comp === "bash") console.log("complete -o filenames -C fx fx");
    else if (opts.comp === "fish") console.log("complete --command fx --arguments '(COMP_FISH=(commandline -cp) fx)'");
    else if (opts.comp === "zsh") console.log(`#compdef fx

_fx() {
    local -a reply
    reply=("\${(@f)$(COMP_ZSH="\${LBUFFER}" fx)}")
}`);
    else console.log("unknown shell type");
    return 0;
  }
  if (argv.includes("--themes")) {
    const sample = `{
  "string": "Fox jumps over the lazy dog",
  "number": 1234567890,
  "boolean": true,
  "null": null,
  "collapsed": {"preview":…}
}`;
    for (let i = 0; i <= 9; i++) {
      console.log(`export FX_THEME="${i}"`);
      console.log(sample);
    }
    return 0;
  }
  const args = opts.positionals;
  const firstPos = args.find((a) => !a.startsWith("-"));
  const queryProvided = Boolean(firstPos);
  let query = firstPos || ".";
  let input = readStdin();
  if (!queryProvided && input.trim()) {
    console.error("panic: could not open a new TTY: open /dev/tty: no such device or address\n\ngoroutine 1 [running]:\nmain.main()\n\t/workspace/main.go:317 +0x191e");
    return 2;
  }
  if (!input.trim() && fs.existsSync(query)) {
    input = fs.readFileSync(query, "utf8");
    query = args.find((a, i) => i > args.indexOf(query) && !a.startsWith("-")) || ".";
  }
  try {
    let value;
    if (opts.raw) value = input.replace(/\n$/, "");
    else if (opts.yaml) value = parseYamlBasic(input);
    else if (opts.toml) value = parseTomlBasic(input);
    else value = parseJsonInputs(input);
    if (opts.slurp && !Array.isArray(value)) {
      value = input.split(/\r?\n/).filter((l) => l.trim()).map((l) => JSON.parse(l));
    }
    const out = evaluateQuery(value, query);
    console.log(formatValue(out, 0, opts.noInline));
    return 0;
  } catch (err) {
    console.error(err && err.message ? err.message : String(err));
    return 1;
  }
  return 0;
}

process.exitCode = main(process.argv.slice(2));
