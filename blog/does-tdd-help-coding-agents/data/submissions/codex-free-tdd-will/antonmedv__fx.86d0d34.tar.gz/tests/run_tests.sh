#!/bin/bash
set -euo pipefail

ROOT="$(cd "$(dirname "$0")/.." && pwd)"
BIN="$ROOT/executable"

run() {
  "$BIN" "$@"
}

assert_eq() {
  local name="$1"
  local expected="$2"
  local actual="$3"
  if [[ "$actual" != "$expected" ]]; then
    printf 'FAIL %s\nexpected:\n%s\nactual:\n%s\n' "$name" "$expected" "$actual" >&2
    exit 1
  fi
  printf 'ok %s\n' "$name"
}

assert_eq "version" "39.2.0" "$(run --version)"

help_out="$(run --help)"
[[ "$help_out" == *"fx 39.2.0"* ]] || { echo "FAIL help version"; exit 1; }
[[ "$help_out" == *"Terminal JSON viewer"* ]] || { echo "FAIL help description"; exit 1; }
[[ "$help_out" == *"--themes"* ]] || { echo "FAIL help flags"; exit 1; }
printf 'ok help\n'

actual="$(printf '{"a":1,"b":[2,3],"c":{"d":4},"sp ace":5}\n' | run .)"
expected='{
  "a": 1,
  "b": [ 2, 3 ],
  "c": {
    "d": 4
  },
  "sp ace": 5
}'
assert_eq "format object" "$expected" "$actual"

assert_eq "field path" "1" "$(printf '{"a":1,"b":[2,3]}\n' | run .a)"
assert_eq "nested path" "4" "$(printf '{"c":{"d":4}}\n' | run .c.d)"
assert_eq "index path" "3" "$(printf '{"b":[2,3]}\n' | run '.b[1]')"

assert_eq "length" "3" "$(printf '[1,2,3]\n' | run .length)"
assert_eq "arrow length" "3" "$(printf '[1,2,3]\n' | run 'x => x.length')"
expected='[
  2,
  3
]'
assert_eq "filter arrow" "$expected" "$(printf '[1,2,3]\n' | run 'x => x.filter(x => x > 1)')"
expected='[
  3,
  6,
  9
]'
assert_eq "method map" "$expected" "$(printf '[1,2,3]\n' | run '.map(x => x*3)')"
assert_eq "reduce arrow" "6" "$(printf '[1,2,3]\n' | run 'x => x.reduce((a,b)=>a+b,0)')"

assert_eq "raw string" "hello" "$(printf 'hello\n' | run -r .)"
assert_eq "raw length" "5" "$(printf 'hello\n' | run --raw .length)"

expected='[
  { "a": 1 },
  { "b": 2 }
]'
assert_eq "slurp" "$expected" "$(printf '{"a":1}\n{"b":2}\n' | run -s .)"

expected='{
  "a": {
    "b": {
      "c": 1
    }
  },
  "x": [
    {
      "y": 2
    },
    {
      "z": 3
    }
  ]
}'
assert_eq "no inline" "$expected" "$(printf '{"a":{"b":{"c":1}},"x":[{"y":2},{"z":3}]}\n' | run --no-inline .)"

expected='{
  "a": 1,
  "b": [
    2,
    "three"
  ]
}'
assert_eq "yaml basic" "$expected" "$(printf 'a: 1\nb:\n  - 2\n  - three\n' | run --yaml .)"

expected='{
  "a": 1,
  "b": [ 2, 3 ],
  "name": "x"
}'
assert_eq "toml basic" "$expected" "$(printf 'a = 1\nb = [2, 3]\nname = "x"\n' | run --toml .)"

assert_eq "object keys" '[
  "a",
  "b"
]' "$(printf '{"a":1,"b":2}\n' | run 'Object.keys(x)')"
assert_eq "keys alias" '[
  "a",
  "b"
]' "$(printf '{"a":1,"b":2}\n' | run keys)"

assert_eq "bash completion" "complete -o filenames -C fx fx" "$(run --comp bash)"
themes="$(run --themes)"
[[ "$themes" == *'export FX_THEME="0"'* ]] || { echo "FAIL themes first"; exit 1; }
[[ "$themes" == *'"string": "Fox jumps over the lazy dog"'* ]] || { echo "FAIL themes sample"; exit 1; }
printf 'ok themes\n'
