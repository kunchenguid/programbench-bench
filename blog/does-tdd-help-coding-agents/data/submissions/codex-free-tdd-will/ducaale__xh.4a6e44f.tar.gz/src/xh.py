#!/usr/bin/env python3
import sys
import json
import shlex
import http.client
from urllib.parse import quote, urlsplit


VERSION = "0.25.3"


def normalize_url(raw, https=False):
    scheme = "https" if https else "http"
    if raw.startswith("://"):
        raw = raw[3:]
    if raw.startswith(":"):
        raw = "localhost" + raw
    if "://" not in raw:
        raw = scheme + "://" + raw
    parsed = urlsplit(raw)
    path = parsed.path or "/"
    host = parsed.netloc
    return parsed.scheme, host, path, parsed.query


def normalized_url_string(raw, https=False, query_pairs=None):
    scheme, host, path, query = normalize_url(raw, https=https)
    all_query = []
    if query:
        all_query.append(query)
    for k, v in query_pairs or []:
        all_query.append(f"{quote(k)}={quote(v)}")
    return f"{scheme}://{host}{path}" + (("?" + "&".join(all_query)) if all_query else "")


def format_json_pairs(pairs):
    parts = []
    for key, value, literal in pairs:
        rendered = value if literal else json.dumps(value, separators=(",", ":"))
        parts.append(json.dumps(key, separators=(",", ":")) + ":" + rendered)
    return "{" + ",".join(parts) + "}"


def header_name(raw):
    return "-".join(part[:1].upper() + part[1:] for part in raw.split("-"))


def offline_request(
    url,
    method="GET",
    https=False,
    json_pairs=None,
    query_pairs=None,
    extra_headers=None,
    json_mode=False,
    form_pairs=None,
    raw_body=None,
):
    json_pairs = json_pairs or []
    form_pairs = form_pairs or []
    query_pairs = query_pairs or []
    extra_headers = extra_headers or []
    _scheme, host, path, query = normalize_url(url, https=https)
    all_query = []
    if query:
        all_query.append(query)
    all_query.extend(f"{quote(k)}={quote(v)}" for k, v in query_pairs)
    target = path + (("?" + "&".join(all_query)) if all_query else "")
    if raw_body is not None:
        body_kind = "raw"
        body = raw_body
    elif form_pairs:
        body_kind = "form"
        body = "&".join(f"{quote(k)}={quote(v)}" for k, v in form_pairs)
    elif json_pairs:
        body_kind = "json"
        body = format_json_pairs(json_pairs)
    else:
        body_kind = None
        body = ""
    has_body = body_kind is not None
    ua = f"xh/{VERSION}"
    filtered = []
    for name, value in extra_headers:
        if name.lower() == "user-agent":
            ua = value
        else:
            filtered.append((name, value))
    headers = (
        f"{method} {target} HTTP/1.1\n"
        "Accept-Encoding: gzip, deflate, br, zstd\n"
        f"User-Agent: {ua}\n"
        "Connection: keep-alive\n"
    )
    if body_kind == "form":
        headers += (
            "Content-Type: application/x-www-form-urlencoded\n"
            "Accept: */*\n"
        )
    elif has_body or json_mode:
        headers += (
            "Accept: application/json, */*;q=0.5\n"
            "Content-Type: application/json\n"
        )
    else:
        for name, value in filtered:
            headers += f"{header_name(name)}: {value}\n"
        filtered = []
        headers += "Accept: */*\n"
    for name, value in filtered:
        headers += f"{header_name(name)}: {value}\n"
    if has_body or json_mode:
        headers += f"Content-Length: {len(body.encode('utf-8'))}\n"
    headers += f"Host: {host}\n\n"
    if has_body:
        headers += body + "\n\n"
    return headers


def curl_quote(s):
    escaped = s.replace("'", "'\"'\"'")
    return "'" + escaped + "'"


def curl_translation(url, https=False, json_pairs=None, form_pairs=None, query_pairs=None, extra_headers=None, long=False):
    json_pairs = json_pairs or []
    form_pairs = form_pairs or []
    query_pairs = query_pairs or []
    extra_headers = extra_headers or []
    full_url = normalized_url_string(url, https=https, query_pairs=query_pairs)
    url_part = shlex.quote(full_url) if query_pairs else full_url
    parts = ["curl", url_part]
    for name, value in extra_headers:
        flag = "--header" if long else "-H"
        parts.extend([flag, curl_quote(f"{name}: {value}")])
    if json_pairs:
        parts.extend(["-H", curl_quote("content-type: application/json")])
        parts.extend(["-H", curl_quote("accept: application/json, */*;q=0.5")])
        parts.extend(["-d", curl_quote(format_json_pairs(json_pairs))])
    for key, value in form_pairs:
        parts.extend(["--data-urlencode", curl_quote(f"{key}={value}")])
    return " ".join(parts) + "\n"


def send_http(url, method="GET", https=False, json_pairs=None, form_pairs=None, query_pairs=None, extra_headers=None, raw_body=None):
    json_pairs = json_pairs or []
    form_pairs = form_pairs or []
    query_pairs = query_pairs or []
    extra_headers = extra_headers or []
    scheme, host, path, query = normalize_url(url, https=https)
    all_query = []
    if query:
        all_query.append(query)
    all_query.extend(f"{quote(k)}={quote(v)}" for k, v in query_pairs)
    target = path + (("?" + "&".join(all_query)) if all_query else "")
    body = None
    headers = {
        "Accept-Encoding": "gzip, deflate, br, zstd",
        "User-Agent": f"xh/{VERSION}",
        "Connection": "keep-alive",
    }
    if raw_body is not None:
        body = raw_body.encode()
        headers["Accept"] = "application/json, */*;q=0.5"
        headers["Content-Type"] = "application/json"
    elif form_pairs:
        body = "&".join(f"{quote(k)}={quote(v)}" for k, v in form_pairs).encode()
        headers["Content-Type"] = "application/x-www-form-urlencoded"
        headers["Accept"] = "*/*"
    elif json_pairs:
        body = format_json_pairs(json_pairs).encode()
        headers["Accept"] = "application/json, */*;q=0.5"
        headers["Content-Type"] = "application/json"
    else:
        headers["Accept"] = "*/*"
    for name, value in extra_headers:
        headers[header_name(name)] = value
    conn_cls = http.client.HTTPSConnection if scheme == "https" else http.client.HTTPConnection
    conn = conn_cls(host, timeout=30)
    try:
        conn.request(method, target, body=body, headers=headers)
        response = conn.getresponse()
        data = response.read()
    finally:
        conn.close()
    sys.stdout.buffer.write(data)
    return 0


def main(argv):
    if "--version" in argv or "-V" in argv:
        sys.stdout.write(f"xh {VERSION}\n-native-tls +rustls\n")
        return 0
    if "--help" in argv or not argv:
        if not argv:
            sys.stderr.write(
                "error: the following required arguments were not provided:\n"
                "  <[METHOD] URL>\n\n"
                "Usage: executable <[METHOD] URL> [REQUEST_ITEM]...\n\n"
                "For more information, try '--help'.\n"
            )
            return 2
        sys.stdout.write(
            "xh is a friendly and fast tool for sending HTTP requests\n\n"
            "Usage: executable [OPTIONS] <[METHOD] URL> [REQUEST_ITEM]...\n"
        )
        return 0

    offline = False
    ignore_stdin = False
    https = False
    form_mode = False
    raw_body = None
    curl = False
    curl_long = False
    positional = []
    i = 0
    while i < len(argv):
        arg = argv[i]
        if arg == "--offline":
            offline = True
        elif arg in ("-I", "--ignore-stdin"):
            ignore_stdin = True
        elif arg == "--https":
            https = True
        elif arg in ("-f", "--form"):
            form_mode = True
        elif arg == "--curl":
            curl = True
        elif arg == "--curl-long":
            curl = True
            curl_long = True
        elif arg == "--raw":
            i += 1
            raw_body = argv[i] if i < len(argv) else ""
        elif arg.startswith("-"):
            pass
        else:
            positional.append(arg)
        i += 1

    if offline and positional:
        method = "GET"
        url = positional[0]
        items = positional[1:]
        if len(positional) >= 2 and positional[0].isalpha():
            method = positional[0].upper()
            url = positional[1]
            items = positional[2:]
        json_pairs = []
        form_pairs = []
        query_pairs = []
        extra_headers = []
        for item in items:
            if "==" in item:
                key, value = item.split("==", 1)
                query_pairs.append((key, value))
            elif item.endswith(";"):
                extra_headers.append((item[:-1], ""))
            elif ":=" in item:
                key, value = item.split(":=", 1)
                json_pairs.append((key, value, True))
            elif ":" in item:
                key, value = item.split(":", 1)
                if value:
                    extra_headers.append((key, value))
            elif "=" in item and "==" not in item:
                key, value = item.split("=", 1)
                if form_mode:
                    form_pairs.append((key, value))
                else:
                    json_pairs.append((key, value, False))
        stdin_body = None
        if not ignore_stdin and not sys.stdin.isatty():
            stdin_body = sys.stdin.read()
        if curl:
            if offline:
                sys.stderr.write("Warning: Ignored --offline\n\n")
            sys.stdout.write(
                curl_translation(
                    url,
                    https=https,
                    json_pairs=json_pairs,
                    form_pairs=form_pairs,
                    query_pairs=query_pairs,
                    extra_headers=extra_headers,
                    long=curl_long,
                )
            )
            return 0
        if stdin_body is not None and (json_pairs or form_pairs):
            sys.stderr.write(
                "executable: error: Request body (from stdin) and request data (key=value) cannot be mixed. Pass --ignore-stdin to ignore standard input.\n"
            )
            return 1
        if stdin_body is not None and raw_body is not None:
            sys.stderr.write(
                "executable: error: Request body from stdin and --raw cannot be mixed. Pass --ignore-stdin to ignore standard input.\n"
            )
            return 1
        if stdin_body is not None:
            raw_body = stdin_body
        if (json_pairs or form_pairs or raw_body is not None) and method == "GET" and not (len(positional) >= 2 and positional[0].isalpha()):
            method = "POST"
        if not ignore_stdin:
            method = "POST"
        sys.stdout.write(
            offline_request(
                url,
                method=method,
                https=https,
                json_pairs=json_pairs,
                query_pairs=query_pairs,
                extra_headers=extra_headers,
                json_mode=False,
                form_pairs=form_pairs,
                raw_body=raw_body,
            )
        )
        return 0

    if positional:
        method = "GET"
        url = positional[0]
        items = positional[1:]
        if len(positional) >= 2 and positional[0].isalpha():
            method = positional[0].upper()
            url = positional[1]
            items = positional[2:]
        json_pairs = []
        form_pairs = []
        query_pairs = []
        extra_headers = []
        for item in items:
            if "==" in item:
                key, value = item.split("==", 1)
                query_pairs.append((key, value))
            elif item.endswith(";"):
                extra_headers.append((item[:-1], ""))
            elif ":=" in item:
                key, value = item.split(":=", 1)
                json_pairs.append((key, value, True))
            elif ":" in item:
                key, value = item.split(":", 1)
                if value:
                    extra_headers.append((key, value))
            elif "=" in item:
                key, value = item.split("=", 1)
                if form_mode:
                    form_pairs.append((key, value))
                else:
                    json_pairs.append((key, value, False))
        if (json_pairs or form_pairs or raw_body is not None) and method == "GET" and not (len(positional) >= 2 and positional[0].isalpha()):
            method = "POST"
        return send_http(
            url,
            method=method,
            https=https,
            json_pairs=json_pairs,
            form_pairs=form_pairs,
            query_pairs=query_pairs,
            extra_headers=extra_headers,
            raw_body=raw_body,
        )

    return 0


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
