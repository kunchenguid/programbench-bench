#!/usr/bin/env python3
import argparse
import fnmatch
import json
import math
import re
import sys
from collections import defaultdict, deque


MISSING = object()


def convert_atom(s):
    if s is None:
        return None
    if isinstance(s, (int, float, bool)):
        return s
    if not isinstance(s, str):
        return s
    t = s.strip()
    if t == "true":
        return True
    if t == "false":
        return False
    if t == "null":
        return None
    if re.fullmatch(r"[-+]?\d+", t):
        try:
            return int(t)
        except ValueError:
            return s
    if re.fullmatch(r"[-+]?(?:\d+\.\d*|\d*\.\d+)(?:[eE][-+]?\d+)?", t) or re.fullmatch(r"[-+]?\d+[eE][-+]?\d+", t):
        try:
            return float(t)
        except ValueError:
            return s
    return s


def flatten_json(value, prefix="", out=None):
    if out is None:
        out = {}
    if isinstance(value, dict):
        for k, v in value.items():
            key = f"{prefix}.{k}" if prefix else str(k)
            flatten_json(v, key, out)
    else:
        out[prefix] = value
    return out


def get_field(row, name):
    name = name.strip()
    if name.startswith('["') and name.endswith('"]'):
        name = name[2:-2]
    cur = row.get(name, MISSING)
    if cur is not MISSING:
        return cur
    parts = re.split(r"\.(?![^\[]*\])", name)
    cur = row
    for part in parts:
        while part:
            m = re.match(r"([^\[]+)(?:\[(-?\d+)\])?(.*)", part)
            if not m:
                return None
            key, idx, rest = m.groups()
            if key:
                if not isinstance(cur, dict) or key not in cur:
                    return None
                cur = cur[key]
            if idx is not None:
                try:
                    cur = cur[int(idx)]
                except Exception:
                    return None
            part = rest
    return cur


def set_field(row, name, val):
    row[name.strip()] = val


def val_to_str(v):
    if v is None:
        return "null"
    if isinstance(v, bool):
        return "true" if v else "false"
    if isinstance(v, float):
        if math.isfinite(v) and v.is_integer():
            return str(int(v))
        return f"{v:.2f}" if abs(v) < 1e12 else str(v)
    if isinstance(v, list):
        return "[" + ", ".join(val_to_str(x) for x in v) + "]"
    return str(v)


def json_value(v):
    return v


class Expr:
    def __init__(self, text):
        self.text = text.strip()

    def eval(self, row):
        return eval_expr(self.text, row)


def split_top(s, sep=","):
    out, cur, quote, depth, i = [], [], None, 0, 0
    while i < len(s):
        c = s[i]
        if quote:
            cur.append(c)
            if c == quote and (i == 0 or s[i - 1] != "\\"):
                quote = None
        elif c in "\"'":
            quote = c
            cur.append(c)
        elif c in "([":
            depth += 1
            cur.append(c)
        elif c in ")]":
            depth -= 1
            cur.append(c)
        elif depth == 0 and s.startswith(sep, i):
            out.append("".join(cur).strip())
            cur = []
            i += len(sep) - 1
        else:
            cur.append(c)
        i += 1
    out.append("".join(cur).strip())
    return [x for x in out if x != ""]


def translate_expr(expr):
    e = expr.strip()
    e = re.sub(r"\bAND\b", " and ", e, flags=re.I)
    e = re.sub(r"\bOR\b", " or ", e, flags=re.I)
    e = e.replace("&&", " and ").replace("||", " or ")
    e = re.sub(r"(?<![=!<>])!(?!=)", " not ", e)
    e = re.sub(r"\btrue\b", "True", e, flags=re.I)
    e = re.sub(r"\bfalse\b", "False", e, flags=re.I)
    e = re.sub(r"\bnull\b", "None", e, flags=re.I)
    e = e.replace("<>", "!=")
    return e


SAFE_FUNCS = {
    "abs": abs, "ceil": math.ceil, "floor": math.floor, "round": round, "sqrt": math.sqrt,
    "sin": math.sin, "cos": math.cos, "tan": math.tan, "asin": math.asin, "acos": math.acos,
    "atan": math.atan, "atan2": math.atan2, "log": math.log, "log10": math.log10,
    "exp": math.exp, "cbrt": lambda x: math.copysign(abs(float(x)) ** (1 / 3), float(x)),
    "concat": lambda *xs: "".join(val_to_str(x) for x in xs),
    "contains": lambda h, n: str(n) in str(h),
    "length": lambda s: len(s) if s is not None else 0,
    "num": lambda x: float(x) if not isinstance(x, (int, float)) else x,
    "parseHex": lambda x: int(str(x), 16),
    "substring": lambda s, a, b=None: str(s)[int(a): None if b is None else int(b)],
    "toLowerCase": lambda s: str(s).lower(),
    "toUpperCase": lambda s: str(s).upper(),
    "isNull": lambda v: v is None,
    "isEmpty": lambda v: v is None or v == "",
    "isBlank": lambda v: v is None or str(v).strip() == "",
    "isNumeric": lambda v: isinstance(convert_atom(str(v)), (int, float)),
    "if_": lambda c, a, b: a if c else b,
}


def eval_expr(expr, row):
    expr = expr.strip()
    if re.fullmatch(r'".*"', expr) or re.fullmatch(r"'.*'", expr):
        return bytes(expr[1:-1], "utf-8").decode("unicode_escape")
    if re.fullmatch(r"[-+]?\d+", expr):
        return int(expr)
    if re.fullmatch(r"[-+]?(?:\d+\.\d*|\d*\.\d+)", expr):
        return float(expr)
    if expr.lower() == "true":
        return True
    if expr.lower() == "false":
        return False
    if expr.lower() == "null":
        return None
    py = translate_expr(expr)
    py = re.sub(r"\bif\s*\(", "if_(", py)
    names = {k: v for k, v in SAFE_FUNCS.items()}
    for k, v in row.items():
        if re.fullmatch(r"[A-Za-z_]\w*", k):
            names[k] = v
    try:
        return eval(py, {"__builtins__": {}}, names)
    except Exception:
        if re.fullmatch(r'[A-Za-z_][\w.\[\]"]*', expr):
            return get_field(row, expr)
        return None


def parse_logfmt(s):
    out = {}
    for m in re.finditer(r'(\w[\w.\-]*)=("(?:\\.|[^"])*"|[^ \t]+)', s):
        v = m.group(2)
        if v.startswith('"') and v.endswith('"'):
            v = bytes(v[1:-1], "utf-8").decode("unicode_escape")
        out[m.group(1)] = convert_atom(v)
    return out if out else None


def wildcard_parse(pattern, text):
    parts = pattern.split("*")
    vals, pos = [], 0
    if not pattern.startswith("*"):
        if not text.startswith(parts[0]):
            return None
        pos = len(parts[0])
        parts = parts[1:]
    for idx, literal in enumerate(parts):
        if idx == 0 and pattern.startswith("*"):
            continue
        if literal == "":
            continue
        next_pos = text.find(literal, pos)
        if next_pos < 0:
            return None
        vals.append(text[pos:next_pos])
        pos = next_pos + len(literal)
    if pattern.endswith("*"):
        vals.append(text[pos:])
    elif pos != len(text):
        return None
    return vals


def op_json(rows, src=None):
    for row in rows:
        text = row.get("_raw", "") if src is None else get_field(row, src)
        try:
            parsed = json.loads(text)
        except Exception:
            continue
        if isinstance(parsed, dict):
            row.update(flatten_json(parsed))
        else:
            row["_json"] = parsed
        yield row


def op_logfmt(rows, src=None):
    for row in rows:
        text = row.get("_raw", "") if src is None else get_field(row, src)
        parsed = parse_logfmt(str(text))
        if parsed is None:
            continue
        row.update(parsed)
        yield row


def op_parse(rows, spec):
    m = re.match(r'parse\s+"((?:\\.|[^"])*)"(?:\s+from\s+(\S+))?\s+as\s+(.+?)(?:\s+(nodrop|noconvert).*)?$', spec)
    if not m:
        return rows
    pattern = bytes(m.group(1), "utf-8").decode("unicode_escape")
    src = m.group(2)
    names = [x.strip() for x in m.group(3).split(",")]
    nodrop = "nodrop" in spec
    noconvert = "noconvert" in spec
    def gen():
        for row in rows:
            text = str(row.get("_raw", "") if src is None else get_field(row, src))
            vals = wildcard_parse(pattern, text)
            if vals is None or len(vals) < len(names):
                if nodrop:
                    yield row
                continue
            for n, v in zip(names, vals):
                row[n] = v if noconvert else convert_atom(v.strip())
            yield row
    return gen()


def op_parse_regex(rows, spec):
    m = re.match(r'parse\s+regex\s+"((?:\\.|[^"])*)"(?:\s+from\s+(\S+))?(.*)$', spec)
    pat, src, tail = bytes(m.group(1), "utf-8").decode("unicode_escape"), m.group(2), m.group(3)
    rx = re.compile(pat)
    nodrop = "nodrop" in tail
    for row in rows:
        text = str(row.get("_raw", "") if src is None else get_field(row, src))
        mm = rx.search(text)
        if not mm:
            if nodrop:
                yield row
            continue
        for k, v in mm.groupdict().items():
            row[k] = convert_atom(v)
        yield row


def op_split(rows, spec):
    m = re.match(r"split(?:\(([^)]*)\))?(?:\s+on\s+\"([^\"]*)\")?(?:\s+as\s+(\S+))?", spec)
    src, sep, dest = m.group(1), m.group(2) or ",", m.group(3)
    for row in rows:
        key = src or "_raw"
        outkey = dest or (src if src else "_split")
        row[outkey] = [x.strip() for x in str(get_field(row, key) if src else row.get("_raw", "")).split(sep)]
        yield row


def op_fields(rows, spec):
    rest = spec[len("fields"):].strip()
    mode = "only"
    if rest.startswith(("only ", "+ ")):
        rest = re.sub(r"^(only|\+)\s+", "", rest)
        mode = "only"
    elif rest.startswith(("except ", "- ")):
        rest = re.sub(r"^(except|-)\s+", "", rest)
        mode = "except"
    fields = [x.strip() for x in rest.split(",") if x.strip()]
    for row in rows:
        if mode == "only":
            yield {k: row[k] for k in fields if k in row}
        else:
            yield {k: v for k, v in row.items() if k not in fields}


def op_where(rows, spec):
    expr = spec[len("where"):].strip()
    for row in rows:
        if bool(eval_expr(expr, row)):
            yield row


def op_limit(rows, spec):
    n = int(spec.split()[1])
    if n >= 0:
        for i, row in enumerate(rows):
            if i >= n:
                break
            yield row
    else:
        d = deque(rows, maxlen=-n)
        for row in d:
            yield row


def filter_match(text, filt):
    filt = filt.strip()
    if not filt or filt == "*":
        return True
    def term(t):
        t = t.strip()
        if t.startswith("(") and t.endswith(")"):
            return filter_match(text, t[1:-1])
        if t.upper().startswith("NOT "):
            return not term(t[4:])
        if t.startswith('"') and t.endswith('"'):
            return t[1:-1] in text
        pat = t.lower()
        return fnmatch.fnmatch(text.lower(), f"*{pat}*")
    for op in (" OR ", " AND "):
        parts = split_bool(filt, op.strip())
        if len(parts) > 1:
            vals = [filter_match(text, p) for p in parts]
            return any(vals) if op.strip() == "OR" else all(vals)
    return term(filt)


def split_bool(s, op):
    out, cur, depth, quote, i = [], [], 0, None, 0
    token = f" {op} "
    while i < len(s):
        c = s[i]
        if quote:
            cur.append(c)
            if c == quote:
                quote = None
        elif c in "\"'":
            quote = c; cur.append(c)
        elif c == "(":
            depth += 1; cur.append(c)
        elif c == ")":
            depth -= 1; cur.append(c)
        elif depth == 0 and s[i:i+len(token)].upper() == token:
            out.append("".join(cur).strip()); cur = []; i += len(token) - 1
        else:
            cur.append(c)
        i += 1
    out.append("".join(cur).strip())
    return out


def is_aggregate(spec):
    return bool(re.search(r"\b(count|sum|average|avg|min|max|p\d+|pct\d+|count_distinct)\b", spec)) and not spec.startswith(("where ", "parse ", "fields ", "split", "json", "logfmt", "limit", "sort", "timeslice", "total"))


def aggregate(rows, spec):
    body, by = spec, []
    m = re.search(r"\s+by\s+(.+)$", spec)
    if m:
        body = spec[:m.start()].strip()
        by = split_top(m.group(1))
    funcs = split_top(body)
    groups = {}
    for row in rows:
        key = tuple(eval_expr(b, row) for b in by)
        if key not in groups:
            groups[key] = {"rows": [], "count": 0}
        groups[key]["rows"].append(row)
        groups[key]["count"] += 1
    out = []
    for key, g in groups.items():
        r = {}
        for b, v in zip(by, key):
            r[b] = v
        for f in funcs:
            alias = None
            if re.search(r"\s+as\s+", f):
                f, alias = re.split(r"\s+as\s+", f, maxsplit=1)
                f, alias = f.strip(), alias.strip()
            col, val = agg_value(f.strip(), g["rows"])
            r[alias or col] = val
        out.append(r)
    return out


def agg_value(f, rows):
    if f == "count":
        return "_count", len(rows)
    m = re.match(r"count\((.+)\)$", f)
    if m:
        return "_count", sum(1 for r in rows if eval_expr(m.group(1), r))
    m = re.match(r"(sum|average|avg|min|max|count_distinct|p(\d+)|pct(\d+))\((.+)\)$", f)
    if not m:
        return f, None
    op, p1, p2, expr = m.group(1), m.group(2), m.group(3), m.group(4)
    vals = [eval_expr(expr, r) for r in rows]
    nums = [float(v) for v in vals if isinstance(v, (int, float)) or re.fullmatch(r"[-+]?\d+(\.\d+)?", str(v))]
    if op == "sum":
        return "_sum", sum(nums)
    if op in ("average", "avg"):
        return "_average", (sum(nums) / len(nums)) if nums else None
    if op == "min":
        return "_min", min(nums) if nums else None
    if op == "max":
        return "_max", max(nums) if nums else None
    if op == "count_distinct":
        return "_countDistinct", len(set(val_to_str(v) for v in vals))
    pct = int(p1 or p2)
    if not nums:
        return f"_p{pct}", None
    nums.sort()
    idx = int(math.ceil((pct / 100) * len(nums))) - 1
    idx = max(0, min(idx, len(nums) - 1))
    return f"p{pct}", nums[idx]


LONG_HELP = """Usage: executable [OPTIONS] [QUERY]

Arguments:
  [QUERY]
          The query

Options:
  -f, --file <FILE>
          Optionally reads from a file instead of Stdin

  -m, --format <FORMAT>
          DEPRECATED. Use -o format=... instead. Provide a Rust std::fmt string to format output

  -o, --output <OUTPUT>
          Set output format. Options: 
          - `json`,
          - `logfmt`
          - `format=<rust format string>` (eg. -o format='{src} => {dst}'
          - `legacy` The original output format, auto aligning [k=v]

  -a, --alias-dir <ALIAS_DIR>
          Specifies an alternative directory to use for aliases. Defaults to `.agrind-aliases` in all parent directories.

      --no-alias
          Disables aliases

  -h, --help
          Print help (see a summary with '-h')

  -V, --version
          Print version

For more details + docs, see https://github.com/rcoh/angle-grinder
"""


SHORT_HELP = """Usage: executable [OPTIONS] [QUERY]

Arguments:
  [QUERY]  The query

Options:
  -f, --file <FILE>            Optionally reads from a file instead of Stdin
  -m, --format <FORMAT>        DEPRECATED. Use -o format=... instead. Provide a Rust std::fmt string to format output
  -o, --output <OUTPUT>        Set output format. One of (json|legacy|format=<rust fmt str>|logfmt)
  -a, --alias-dir <ALIAS_DIR>  Specifies an alternative directory to use for aliases. Defaults to `.agrind-aliases` in all parent directories.
      --no-alias               Disables aliases
  -h, --help                   Print help (see more with '--help')
  -V, --version                Print version

For more details + docs, see https://github.com/rcoh/angle-grinder
"""


def sort_rows(rows, spec):
    m = re.match(r"sort\s+by\s+(.+?)(?:\s+(asc|desc))?$", spec)
    if not m:
        return rows
    exprs = split_top(m.group(1))
    desc = (m.group(2) or "asc").lower() == "desc"
    return sorted(rows, key=lambda r: tuple(eval_expr(e, r) for e in exprs), reverse=desc)


def assign_expr(rows, spec):
    m = re.match(r"(.+)\s+as\s+([A-Za-z_][\w.]*)$", spec)
    if not m:
        return rows
    expr, name = m.group(1), m.group(2)
    for row in rows:
        row[name] = eval_expr(expr, row)
        yield row


def alias_dirs(start, override=None):
    if override:
        return [override]
    dirs = []
    cur = start
    while True:
        cand = cur + "/.agrind-aliases"
        dirs.append(cand)
        parent = re.sub(r"/[^/]+/?$", "", cur.rstrip("/")) or "/"
        if parent == cur or cur == "/":
            break
        cur = parent
    return dirs


def load_aliases(start=".", override=None):
    import os
    aliases = {}
    for d in alias_dirs(os.path.abspath(start), override):
        if not os.path.isdir(d):
            continue
        for fn in sorted(os.listdir(d)):
            path = os.path.join(d, fn)
            if not os.path.isfile(path):
                continue
            try:
                txt = open(path, encoding="utf-8").read()
            except OSError:
                continue
            km = re.search(r'keyword\s*=\s*"([^"]+)"', txt)
            tm = re.search(r'template\s*=\s*"""(.*?)"""', txt, re.S)
            if km and tm:
                aliases[km.group(1)] = tm.group(1).strip()
    return aliases


def expand_aliases(query, aliases):
    if not aliases:
        return query
    parts = [p.strip() for p in query.split("|")]
    out = [parts[0]]
    for p in parts[1:]:
        if p in aliases:
            out.extend(x.strip() for x in aliases[p].split("|") if x.strip())
        else:
            out.append(p)
    return " | ".join(out)


def run_query(query, lines, aliases=None):
    if not query:
        raise ValueError("MissingQuery")
    query = expand_aliases(query, aliases or {})
    parts = [p.strip() for p in query.split("|")]
    filt = parts[0] if parts else "*"
    rows = ({"_raw": line.rstrip("\n")} for line in lines if filter_match(line.rstrip("\n"), filt))
    aggregate_mode = False
    for spec in parts[1:]:
        if spec == "json" or spec.startswith("json from "):
            rows = op_json(rows, spec[10:].strip() if spec.startswith("json from ") else None)
        elif spec == "logfmt" or spec.startswith("logfmt from "):
            rows = op_logfmt(rows, spec[12:].strip() if spec.startswith("logfmt from ") else None)
        elif spec.startswith("parse regex "):
            rows = op_parse_regex(rows, spec)
        elif spec.startswith("parse "):
            rows = op_parse(rows, spec)
        elif spec.startswith("split"):
            rows = op_split(rows, spec)
        elif spec.startswith("fields"):
            rows = op_fields(rows, spec)
        elif spec.startswith("where"):
            rows = op_where(rows, spec)
        elif spec.startswith("limit"):
            rows = op_limit(rows, spec)
        elif spec.startswith("sort"):
            rows = sort_rows(list(rows), spec)
        elif is_aggregate(spec):
            rows = aggregate(list(rows), spec)
            aggregate_mode = True
        elif re.search(r"\s+as\s+", spec):
            rows = assign_expr(rows, spec)
        elif spec:
            raise ValueError("Failed to parse query")
    return list(rows), aggregate_mode


def render_legacy(rows, aggregate_mode=False):
    clean = [{k: v for k, v in r.items() if not k.startswith("_raw")} for r in rows]
    if aggregate_mode:
        return render_table(clean)
    keys = sorted({k for r in clean for k in r.keys()})
    if not keys:
        return "\n".join(r.get("_raw", "") for r in rows) + ("\n" if rows else "")
    widths = {}
    for i, k in enumerate(keys):
        widths[k] = max(len(f"[{k}={val_to_str(r[k])}]") if k in r else 0 for r in clean)
        if i == 0:
            widths[k] = max(widths[k], len(k) * 2 + 3)
    out = []
    for r in clean:
        cells = []
        for k in keys:
            cell = f"[{k}={val_to_str(r[k])}]" if k in r else ""
            cells.append(cell.ljust(widths[k]))
        out.append("        ".join(cells).rstrip())
    return "\n".join(out) + ("\n" if out else "")


def render_table(rows):
    if not rows:
        return ""
    keys = list(rows[0].keys())
    widths = {k: max(len(k), *(len(val_to_str(r.get(k))) for r in rows)) for k in keys}
    header = "        ".join(k.ljust(widths[k]) for k in keys).rstrip()
    line = "-" * (len(header) + 8)
    body = []
    for r in rows:
        body.append("        ".join(val_to_str(r.get(k)).ljust(widths[k]) for k in keys).rstrip())
    return header + "\n" + line + "\n" + "\n".join(body) + "\n"


def render_json(rows):
    clean = [{k: v for k, v in r.items() if not k.startswith("_raw")} for r in rows]
    return "".join(json.dumps(r, separators=(",", ":"), sort_keys=True) + "\n" for r in clean)


def render_logfmt(rows):
    clean = [{k: v for k, v in r.items() if not k.startswith("_raw")} for r in rows]
    lines = []
    for r in clean:
        parts = []
        for k in sorted(r.keys()):
            v = val_to_str(r[k])
            if re.search(r"\s", v):
                v = '"' + v.replace('"', '\\"') + '"'
            parts.append(f"{k}={v}")
        lines.append(" ".join(parts))
    return "\n".join(lines) + ("\n" if lines else "")


def render_format(rows, fmt):
    lines = []
    for r in rows:
        vals = defaultdict(str, {k: val_to_str(v) for k, v in r.items()})
        try:
            lines.append(fmt.format_map(vals))
        except Exception:
            lines.append(fmt)
    return "\n".join(lines) + ("\n" if lines else "")


def main(argv=None):
    argv = list(sys.argv[1:] if argv is None else argv)
    if "--help" in argv:
        sys.stdout.write(LONG_HELP)
        return 0
    if "-h" in argv:
        sys.stdout.write(SHORT_HELP)
        return 0
    p = argparse.ArgumentParser(prog="executable", add_help=False)
    p.add_argument("-f", "--file")
    p.add_argument("-m", "--format")
    p.add_argument("-o", "--output")
    p.add_argument("-a", "--alias-dir")
    p.add_argument("--no-alias", action="store_true")
    p.add_argument("-V", "--version", action="store_true")
    p.add_argument("query", nargs="?")
    args = p.parse_args(argv)
    if args.version:
        print("ag 0.19.6")
        return 0
    if not args.query:
        print("Error: MissingQuery", file=sys.stderr)
        return 1
    try:
        if args.file:
            with open(args.file, "r", encoding="utf-8") as fh:
                rows, agg = run_query(args.query, fh, {} if args.no_alias else load_aliases(".", args.alias_dir))
        else:
            rows, agg = run_query(args.query, sys.stdin, {} if args.no_alias else load_aliases(".", args.alias_dir))
    except Exception as e:
        print(f"Error: {e}", file=sys.stderr)
        return 1
    output = args.output or ("format=" + args.format if args.format else "legacy")
    if output == "json":
        sys.stdout.write(render_json(rows))
    elif output == "logfmt":
        sys.stdout.write(render_logfmt(rows))
    elif output.startswith("format="):
        sys.stdout.write(render_format(rows, output[len("format="):]))
    else:
        sys.stdout.write(render_legacy(rows, agg))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
