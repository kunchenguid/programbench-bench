#!/bin/bash
set -e
cp ag.py executable
chmod +x executable
