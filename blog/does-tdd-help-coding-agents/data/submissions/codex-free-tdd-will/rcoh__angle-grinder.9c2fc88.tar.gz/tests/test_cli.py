import subprocess
import sys
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
BIN = ROOT / "ag.py"


def run_ag(query, data="", *args):
    cmd = [sys.executable, str(BIN), *args, query]
    return subprocess.run(cmd, input=data, text=True, capture_output=True)


class CliTests(unittest.TestCase):
    def test_json_rows_render_as_legacy_columns(self):
        proc = run_ag("* | json", '{"level":"info","n":2}\n{"level":"error","n":3}\n')
        self.assertEqual(proc.returncode, 0)
        self.assertEqual(
            proc.stdout,
            "[level=info]         [n=2]\n[level=error]        [n=3]\n",
        )

    def test_grouped_aggregates_render_as_table(self):
        data = "\n".join(
            [
                '{"level":"info","n":2}',
                '{"level":"info","n":5}',
                '{"level":"error","n":3}',
            ]
        ) + "\n"
        proc = run_ag(
            "* | json | count, sum(n), average(n), min(n), max(n) by level | sort by level",
            data,
        )
        self.assertEqual(proc.returncode, 0)
        self.assertEqual(
            proc.stdout,
            "level        _count        _sum        _average        _min        _max\n"
            "-------------------------------------------------------------------------------\n"
            "error        1             3           3               3           3\n"
            "info         2             7           3.50            2           5\n",
        )

    def test_parse_and_logfmt_examples(self):
        proc = run_ag(
            '* | parse "* user=* ms=*" as level,user,ms',
            "INFO user=bob ms=12\nWARN user=ann ms=5\n",
        )
        self.assertEqual(proc.returncode, 0)
        self.assertEqual(
            proc.stdout,
            "[level=INFO]         [ms=12]        [user=bob]\n"
            "[level=WARN]         [ms=5]         [user=ann]\n",
        )

        proc = run_ag("* | logfmt", "user=bob ms=12 ok=true\nuser=ann ms=5\n")
        self.assertEqual(proc.returncode, 0)
        self.assertEqual(
            proc.stdout,
            "[ms=12]        [ok=true]        [user=bob]\n"
            "[ms=5]                          [user=ann]\n",
        )

    def test_output_formats_and_where(self):
        data = '{"level":"info","n":2}\n{"level":"error","n":3}\n'
        proc = run_ag("* | json | n * 10 as pct", data, "-o", "json")
        self.assertEqual(proc.returncode, 0)
        self.assertEqual(
            proc.stdout,
            '{"level":"info","n":2,"pct":20}\n{"level":"error","n":3,"pct":30}\n',
        )
        proc = run_ag("* | json | where n >= 3", data, "-o", "logfmt")
        self.assertEqual(proc.returncode, 0)
        self.assertEqual(proc.stdout, "level=error n=3\n")


if __name__ == "__main__":
    unittest.main()
