#!/usr/bin/env python3
import html
import json
import os
import random
import re
import sys
import time


VERSION_TEXT = """PHP 8.6.0-dev (cli) (built: Apr 17 2026 20:00:58) (NTS)
Copyright (c) The PHP Group
Zend Engine v4.6.0-dev, Copyright (c) Zend Technologies
    with Zend OPcache v8.6.0-dev, Copyright (c), by Zend Technologies
"""

HELP_TEXT = """Usage: executable [options] [-f] <file> [--] [args...]
   executable [options] -r <code> [--] [args...]
   executable [options] [-B <begin_code>] -R <code> [-E <end_code>] [--] [args...]
   executable [options] [-B <begin_code>] -F <file> [-E <end_code>] [--] [args...]
   executable [options] -S <addr>:<port> [-t docroot] [router]
   executable [options] -- [args...]
   executable [options] -a

  -a               Run as interactive shell (requires readline extension)
  -c <path>|<file> Look for php.ini file in this directory
  -n               No configuration (ini) files will be used
  -d foo[=bar]     Define INI entry foo with value 'bar'
  -e               Generate extended information for debugger/profiler
  -f <file>        Parse and execute <file>.
  -h               This help
  -i               PHP information
  -l               Syntax check only (lint)
  -m               Show compiled in modules
  -r <code>        Run PHP <code> without using script tags <?..?>
  -B <begin_code>  Run PHP <begin_code> before processing input lines
  -R <code>        Run PHP <code> for every input line
  -F <file>        Parse and execute <file> for every input line
  -E <end_code>    Run PHP <end_code> after processing all input lines
  -H               Hide any passed arguments from external tools.
  -S <addr>:<port> Run with built-in web server.
  -t <docroot>     Specify document root <docroot> for built-in web server.
  -s               Output HTML syntax highlighted source.
  -v               Version number
  -w               Output source with stripped comments and whitespace.

  args...          Arguments passed to script. Use -- args when first argument
                   starts with - or script is read from stdin

  --ini            Show configuration file names
  --ini=diff       Show INI entries that differ from the built-in default

  --rf <name>      Show information about function <name>.
  --rc <name>      Show information about class <name>.
  --re <name>      Show information about extension <name>.
  --rz <name>      Show information about Zend extension <name>.
  --ri <name>      Show configuration for extension <name>.

  --repeat <count> Repeat script execution <count> times.
                   For internal purposes only.
"""

MODULES_TEXT = """[PHP Modules]
Core
date
hash
json
lexbor
pcre
random
Reflection
SPL
standard
uri
Zend OPcache

[Zend Modules]
Zend OPcache
"""

INI_TEXT = """Configuration File (php.ini) Path: "/usr/local/lib"
Loaded Configuration File:         (none)
Scan for additional .ini files in: (none)
Additional .ini files parsed:      (none)
"""


class PhpError(Exception):
    pass


class ReturnValue(Exception):
    def __init__(self, value):
        self.value = value


class BreakLoop(Exception):
    pass


class ContinueLoop(Exception):
    pass


TOKEN_RE = re.compile(
    r"""
    (?P<ws>\s+)
  | (?P<comment>//[^\n]*|\#[^\n]*|/\*.*?\*/)
  | (?P<num>\d+\.\d+|\d+)
  | (?P<str>'(?:\\.|[^'\\])*'|"(?:\\.|[^"\\])*")
  | (?P<var>\$[A-Za-z_][A-Za-z0-9_]*)
  | (?P<id>[A-Za-z_][A-Za-z0-9_]*)
  | (?P<op>===|!==|==|!=|<=|>=|\+\+|--|&&|\|\||\?\?|=>|\+=|-=|\.=|[{}()[\],;:?+\-*/%.=<>!])
    """,
    re.S | re.X,
)


def tokenize(code):
    out = []
    pos = 0
    while pos < len(code):
        m = TOKEN_RE.match(code, pos)
        if not m:
            raise PhpError(f"unexpected character {code[pos]!r}")
        pos = m.end()
        kind = m.lastgroup
        if kind in ("ws", "comment"):
            continue
        val = m.group(kind)
        out.append((kind, val))
    out.append(("eof", ""))
    return out


def php_bool(v):
    if v is None or v is False:
        return False
    if v == 0 or v == 0.0 or v == "" or v == "0":
        return False
    if isinstance(v, (list, dict)) and len(v) == 0:
        return False
    return True


def php_str(v):
    if v is None:
        return ""
    if v is True:
        return "1"
    if v is False:
        return ""
    if isinstance(v, float):
        if v.is_integer():
            return str(int(v))
    return str(v)


def php_num(v):
    if isinstance(v, bool):
        return 1 if v else 0
    if v is None:
        return 0
    if isinstance(v, (int, float)):
        return v
    try:
        if "." in str(v):
            return float(v)
        return int(str(v).strip() or "0")
    except Exception:
        return 0


def array_get(arr, key):
    if isinstance(arr, dict):
        return arr.get(key)
    if isinstance(arr, list):
        try:
            return arr[int(key)]
        except Exception:
            return None
    if isinstance(arr, str):
        try:
            return arr[int(key)]
        except Exception:
            return ""
    return None


def array_set(arr, key, value):
    if key is None:
        if isinstance(arr, list):
            arr.append(value)
        elif isinstance(arr, dict):
            arr[len(arr)] = value
        return arr
    if isinstance(arr, list) and isinstance(key, int):
        while len(arr) <= key:
            arr.append(None)
        arr[key] = value
    elif isinstance(arr, dict):
        arr[key] = value
    return arr


class Parser:
    def __init__(self, code):
        self.toks = tokenize(code)
        self.i = 0

    def peek(self, val=None):
        tok = self.toks[self.i]
        return tok if val is None else tok[1] == val

    def take(self, val=None):
        tok = self.toks[self.i]
        if val is not None and tok[1] != val:
            raise PhpError(f"expected {val}, got {tok[1]}")
        self.i += 1
        return tok

    def match(self, val):
        if self.peek(val):
            self.i += 1
            return True
        return False

    def parse(self, until=None):
        stmts = []
        while self.peek()[0] != "eof" and (until is None or not self.peek(until)):
            if self.match(";"):
                continue
            stmts.append(self.statement())
        return stmts

    def parse_until_any(self, terms):
        stmts = []
        while self.peek()[0] != "eof" and self.peek()[1] not in terms:
            if self.match(";"):
                continue
            stmts.append(self.statement())
        return stmts

    def block(self):
        if self.match("{"):
            body = self.parse("}")
            self.take("}")
            return body
        return [self.statement()]

    def statement(self):
        tok = self.peek()
        if tok[1] == "echo":
            self.take()
            exprs = [self.expr()]
            while self.match(","):
                exprs.append(self.expr())
            self.match(";")
            return ("echo", exprs)
        if tok[1] == "print":
            self.take()
            expr = self.expr()
            self.match(";")
            return ("echo", [expr])
        if tok[1] == "if":
            return self.if_stmt()
        if tok[1] == "while":
            self.take()
            self.take("(")
            cond = self.expr()
            self.take(")")
            return ("while", cond, self.block())
        if tok[1] == "for":
            return self.for_stmt()
        if tok[1] == "foreach":
            return self.foreach_stmt()
        if tok[1] == "switch":
            return self.switch_stmt()
        if tok[1] == "break":
            self.take()
            self.match(";")
            return ("break",)
        if tok[1] == "continue":
            self.take()
            self.match(";")
            return ("continue",)
        if tok[1] == "return":
            self.take()
            expr = None if self.peek(";") else self.expr()
            self.match(";")
            return ("return", expr)
        if tok[1] == "function":
            return self.function_decl()
        if tok[1] == "class":
            return self.skip_decl()
        expr = self.expr()
        self.match(";")
        return ("expr", expr)

    def skip_decl(self):
        kind = self.take()[1]
        name = self.take()[1] if self.peek()[0] in ("id", "var") else ""
        depth = 0
        while self.peek()[0] != "eof":
            v = self.take()[1]
            if v == "{":
                depth += 1
            elif v == "}":
                depth -= 1
                if depth <= 0:
                    break
            elif v == ";" and depth == 0:
                break
        return ("decl", kind, name)

    def function_decl(self):
        self.take("function")
        name = self.take()[1]
        self.take("(")
        params = []
        if not self.peek(")"):
            while True:
                params.append(self.take()[1][1:])
                if not self.match(","):
                    break
        self.take(")")
        return ("function", name.lower(), params, self.block())

    def if_stmt(self):
        self.take("if")
        self.take("(")
        cond = self.expr()
        self.take(")")
        then = self.block()
        branches = [(cond, then)]
        otherwise = []
        while self.peek("elseif"):
            self.take()
            self.take("(")
            c = self.expr()
            self.take(")")
            branches.append((c, self.block()))
        if self.peek("else"):
            self.take()
            otherwise = self.block()
        return ("if", branches, otherwise)

    def for_stmt(self):
        self.take("for")
        self.take("(")
        init = None if self.peek(";") else self.expr()
        self.take(";")
        cond = None if self.peek(";") else self.expr()
        self.take(";")
        step = None if self.peek(")") else self.expr()
        self.take(")")
        return ("for", init, cond, step, self.block())

    def foreach_stmt(self):
        self.take("foreach")
        self.take("(")
        seq = self.expr()
        self.take("as")
        first = self.take()[1][1:]
        key = None
        val = first
        if self.match("=>"):
            key = first
            val = self.take()[1][1:]
        self.take(")")
        return ("foreach", seq, key, val, self.block())

    def switch_stmt(self):
        self.take("switch")
        self.take("(")
        expr = self.expr()
        self.take(")")
        self.take("{")
        cases = []
        default = []
        while not self.peek("}") and self.peek()[0] != "eof":
            if self.peek("case"):
                self.take()
                c = self.expr()
                self.take(":")
                cases.append((c, self.parse_until_any({"case", "default", "}"})))
            elif self.peek("default"):
                self.take()
                self.take(":")
                default = self.parse_until_any({"case", "default", "}"})
            else:
                self.take()
        self.take("}")
        return ("switch", expr, cases, default)

    def expr(self, min_bp=0):
        lhs = self.prefix()
        while True:
            op = self.peek()[1]
            if op == "?":
                if min_bp > 2:
                    break
                self.take()
                if self.peek(":"):
                    yes = lhs
                else:
                    yes = self.expr()
                self.take(":")
                no = self.expr(2)
                lhs = ("ternary", lhs, yes, no)
                continue
            if op in ("=", "+=", "-=", ".="):
                if min_bp > 1:
                    break
                self.take()
                rhs = self.expr(1)
                lhs = ("assign", lhs, op, rhs)
                continue
            table = {
                "||": (2, 3), "&&": (4, 5),
                "??": (3, 4),
                "==": (6, 7), "!=": (6, 7), "===": (6, 7), "!==": (6, 7),
                "<": (8, 9), ">": (8, 9), "<=": (8, 9), ">=": (8, 9),
                ".": (10, 11), "+": (12, 13), "-": (12, 13),
                "*": (14, 15), "/": (14, 15), "%": (14, 15),
            }
            if op not in table:
                break
            lbp, rbp = table[op]
            if lbp < min_bp:
                break
            self.take()
            rhs = self.expr(rbp)
            lhs = ("bin", op, lhs, rhs)
        return lhs

    def prefix(self):
        tok = self.take()
        val = tok[1]
        if val in ("+", "-", "!"):
            return ("un", val, self.expr(16))
        if val in ("++", "--"):
            target = self.prefix()
            return ("pre", val, target)
        if val == "(":
            e = self.expr()
            self.take(")")
            return self.postfix(e)
        if val == "[":
            return self.array_literal("]")
        if val == "array":
            self.take("(")
            return self.array_literal(")")
        if tok[0] == "num":
            e = ("lit", float(val) if "." in val else int(val))
        elif tok[0] == "str":
            e = ("str", decode_string(val), val[0] == '"')
        elif tok[0] == "var":
            e = ("var", val[1:])
        elif tok[0] == "id":
            low = val.lower()
            if low in ("true", "false", "null"):
                e = ("lit", {"true": True, "false": False, "null": None}[low])
            else:
                e = ("const", val)
        else:
            raise PhpError(f"unexpected token {val}")
        return self.postfix(e)

    def array_literal(self, end):
        items = []
        if not self.peek(end):
            while True:
                first = self.expr()
                if self.match("=>"):
                    items.append((first, self.expr()))
                else:
                    items.append((None, first))
                if not self.match(","):
                    break
                if self.peek(end):
                    break
        self.take(end)
        return ("array", items)

    def postfix(self, e):
        while True:
            if self.match("("):
                args = []
                if not self.peek(")"):
                    while True:
                        args.append(self.expr())
                        if not self.match(","):
                            break
                self.take(")")
                e = ("call", e, args)
            elif self.match("["):
                idx = None if self.peek("]") else self.expr()
                self.take("]")
                e = ("index", e, idx)
            elif self.peek("++") or self.peek("--"):
                op = self.take()[1]
                e = ("post", op, e)
            else:
                break
        return e


def decode_string(s):
    quote = s[0]
    inner = s[1:-1]
    if quote == "'":
        return inner.replace("\\'", "'").replace("\\\\", "\\")
    escapes = {"n": "\n", "r": "\r", "t": "\t", "v": "\v", "e": "\x1b", "f": "\f", "\\": "\\", '"': '"', "$": "$"}
    return re.sub(r"\\(.)", lambda m: escapes.get(m.group(1), m.group(1)), inner)


class Runtime:
    def __init__(self, argv=None, filename=None):
        argv = argv or []
        self.vars = {
            "argv": [filename or "Standard input code"] + argv,
            "argc": 1 + len(argv),
            "_SERVER": {"argv": [filename or "Standard input code"] + argv, "argc": 1 + len(argv)},
        }
        self.out = []
        self.funcs = {}
        self.consts = {}
        self.filename = filename or "Command line code"

    def run(self, stmts):
        for s in stmts:
            self.exec_stmt(s)
        return "".join(self.out)

    def exec_block(self, block):
        for s in block:
            self.exec_stmt(s)

    def exec_stmt(self, s):
        kind = s[0]
        if kind == "echo":
            for e in s[1]:
                self.out.append(php_str(self.eval(e)))
        elif kind == "expr":
            self.eval(s[1])
        elif kind == "if":
            for cond, block in s[1]:
                if php_bool(self.eval(cond)):
                    self.exec_block(block)
                    return
            self.exec_block(s[2])
        elif kind == "while":
            guard = 0
            while php_bool(self.eval(s[1])) and guard < 100000:
                try:
                    self.exec_block(s[2])
                except ContinueLoop:
                    pass
                except BreakLoop:
                    break
                guard += 1
        elif kind == "for":
            if s[1] is not None:
                self.eval(s[1])
            guard = 0
            while (s[2] is None or php_bool(self.eval(s[2]))) and guard < 100000:
                try:
                    self.exec_block(s[4])
                except ContinueLoop:
                    pass
                except BreakLoop:
                    break
                if s[3] is not None:
                    self.eval(s[3])
                guard += 1
        elif kind == "foreach":
            seq = self.eval(s[1])
            items = seq.items() if isinstance(seq, dict) else enumerate(seq or [])
            for k, v in list(items):
                if s[2]:
                    self.vars[s[2]] = k
                self.vars[s[3]] = v
                try:
                    self.exec_block(s[4])
                except ContinueLoop:
                    continue
                except BreakLoop:
                    break
        elif kind == "return":
            raise ReturnValue(self.eval(s[1]) if s[1] is not None else None)
        elif kind == "function":
            self.funcs[s[1]] = (s[2], s[3])
        elif kind == "break":
            raise BreakLoop()
        elif kind == "continue":
            raise ContinueLoop()
        elif kind == "switch":
            val = self.eval(s[1])
            active = False
            try:
                for c, block in s[2]:
                    if active or self.eval(c) == val:
                        active = True
                        self.exec_block(block)
                if not active:
                    self.exec_block(s[3])
            except BreakLoop:
                pass

    def eval(self, e):
        kind = e[0]
        if kind == "lit":
            return e[1]
        if kind == "str":
            if not e[2]:
                return e[1]
            return re.sub(r"\$([A-Za-z_][A-Za-z0-9_]*)", lambda m: php_str(self.vars.get(m.group(1))), e[1])
        if kind == "const":
            name = e[1]
            upper = name.upper()
            if upper == "PHP_EOL":
                return "\n"
            if upper == "PHP_VERSION":
                return "8.6.0-dev"
            if upper == "DIRECTORY_SEPARATOR":
                return "/"
            if upper == "__FILE__":
                return self.filename
            if upper == "__DIR__":
                return os.path.dirname(os.path.abspath(self.filename)) if self.filename else ""
            if name in self.consts:
                return self.consts[name]
            if upper in self.consts:
                return self.consts[upper]
            return name
        if kind == "var":
            return self.vars.get(e[1])
        if kind == "index":
            return array_get(self.eval(e[1]), self.eval(e[2]) if e[2] is not None else None)
        if kind == "array":
            arr = []
            assoc = {}
            is_assoc = False
            next_i = 0
            for kexpr, vexpr in e[1]:
                v = self.eval(vexpr)
                if kexpr is None:
                    if is_assoc:
                        assoc[next_i] = v
                    else:
                        arr.append(v)
                    next_i += 1
                else:
                    k = self.eval(kexpr)
                    is_assoc = True
                    for i, av in enumerate(arr):
                        assoc[i] = av
                    arr = []
                    assoc[k] = v
                    if isinstance(k, int) and k >= next_i:
                        next_i = k + 1
            return assoc if is_assoc else arr
        if kind == "assign":
            cur = self.eval(e[1])
            rhs = self.eval(e[3])
            if e[2] == "+=":
                rhs = php_num(cur) + php_num(rhs)
            elif e[2] == "-=":
                rhs = php_num(cur) - php_num(rhs)
            elif e[2] == ".=":
                rhs = php_str(cur) + php_str(rhs)
            self.assign(e[1], rhs)
            return rhs
        if kind in ("pre", "post"):
            cur = self.eval(e[2])
            new = php_num(cur) + (1 if e[1] == "++" else -1)
            self.assign(e[2], new)
            return new if kind == "pre" else cur
        if kind == "un":
            v = self.eval(e[2])
            return {"-": -php_num(v), "+": php_num(v), "!": not php_bool(v)}[e[1]]
        if kind == "bin":
            return self.binop(e[1], e[2], e[3])
        if kind == "ternary":
            return self.eval(e[2]) if php_bool(self.eval(e[1])) else self.eval(e[3])
        if kind == "call":
            return self.call(e[1], e[2])
        return None

    def assign(self, target, value):
        if target[0] == "var":
            self.vars[target[1]] = value
        elif target[0] == "index":
            base = self.eval(target[1])
            if base is None:
                base = []
                self.assign(target[1], base)
            key = self.eval(target[2]) if target[2] is not None else None
            array_set(base, key, value)
        else:
            raise PhpError("invalid assignment")

    def binop(self, op, aexpr, bexpr):
        if op == "&&":
            return php_bool(self.eval(aexpr)) and php_bool(self.eval(bexpr))
        if op == "||":
            return php_bool(self.eval(aexpr)) or php_bool(self.eval(bexpr))
        if op == "??":
            a = self.eval(aexpr)
            return a if a is not None else self.eval(bexpr)
        a, b = self.eval(aexpr), self.eval(bexpr)
        if op == ".":
            return php_str(a) + php_str(b)
        if op == "+":
            return php_num(a) + php_num(b)
        if op == "-":
            return php_num(a) - php_num(b)
        if op == "*":
            return php_num(a) * php_num(b)
        if op == "/":
            return php_num(a) / php_num(b)
        if op == "%":
            return int(php_num(a)) % int(php_num(b))
        if op in ("==", "==="):
            return a == b
        if op in ("!=", "!=="):
            return a != b
        if op == "<":
            return a < b
        if op == ">":
            return a > b
        if op == "<=":
            return a <= b
        if op == ">=":
            return a >= b
        return None

    def call(self, callee, arg_exprs):
        name = callee[1].lower() if callee[0] == "const" else ""
        args = [self.eval(a) for a in arg_exprs]
        if name in ("var_dump", "print_r"):
            text = dump_value(args[0] if len(args) == 1 else args, print_r=(name == "print_r"))
            self.out.append(text)
            return True
        if name == "define":
            if args:
                self.consts[str(args[0])] = args[1] if len(args) > 1 else None
            return True
        if name in self.funcs:
            params, body = self.funcs[name]
            saved = self.vars.copy()
            for p, v in zip(params, args):
                self.vars[p] = v
            try:
                self.exec_block(body)
                ret = None
            except ReturnValue as r:
                ret = r.value
            self.vars = saved
            return ret
        if name == "strlen":
            return len(php_str(args[0]))
        if name in ("count", "sizeof"):
            return len(args[0] or [])
        if name == "isset":
            return all(a is not None for a in args)
        if name == "empty":
            return not php_bool(args[0] if args else None)
        if name == "is_array":
            return isinstance(args[0], (list, dict))
        if name == "is_string":
            return isinstance(args[0], str)
        if name == "is_int" or name == "is_integer":
            return isinstance(args[0], int) and not isinstance(args[0], bool)
        if name == "is_numeric":
            try:
                float(str(args[0]))
                return True
            except Exception:
                return False
        if name == "strtolower":
            return php_str(args[0]).lower()
        if name == "strtoupper":
            return php_str(args[0]).upper()
        if name == "trim":
            return php_str(args[0]).strip(args[1] if len(args) > 1 else None)
        if name == "substr":
            s = php_str(args[0]); start = int(args[1]); length = None if len(args) < 3 else int(args[2])
            return s[start:] if length is None else s[start:start + length]
        if name == "strpos":
            p = php_str(args[0]).find(php_str(args[1]))
            return False if p < 0 else p
        if name == "str_replace":
            return php_str(args[2]).replace(php_str(args[0]), php_str(args[1]))
        if name == "explode":
            return php_str(args[1]).split(php_str(args[0]))
        if name == "implode":
            sep, arr = (args[0], args[1]) if len(args) > 1 else ("", args[0])
            vals = arr.values() if isinstance(arr, dict) else arr
            return php_str(sep).join(php_str(x) for x in vals)
        if name == "json_encode":
            return json.dumps(args[0], separators=(",", ":"))
        if name == "json_decode":
            return json.loads(args[0])
        if name == "time":
            return int(time.time())
        if name == "rand" or name == "mt_rand" or name == "random_int":
            lo = int(args[0]) if args else 0
            hi = int(args[1]) if len(args) > 1 else 2147483647
            return random.randint(lo, hi)
        if name == "abs":
            return abs(php_num(args[0]))
        if name == "min":
            return min(args)
        if name == "max":
            return max(args)
        if name == "file_get_contents":
            with open(args[0], "r", encoding="utf-8", errors="replace") as f:
                return f.read()
        if name == "preg_match":
            pattern = php_str(args[0])
            body = pattern[1:pattern.rfind(pattern[0])] if len(pattern) > 2 and pattern[0] in "/#~" else pattern
            return 1 if re.search(body, php_str(args[1])) else 0
        if name == "phpversion":
            return "8.6.0-dev"
        return None


def dump_value(v, indent=0, print_r=False):
    sp = "  " * indent
    if print_r:
        if isinstance(v, (list, dict)):
            items = v.items() if isinstance(v, dict) else enumerate(v)
            s = "Array\n(\n"
            for k, val in items:
                s += f"{sp}    [{k}] => {php_str(val)}\n"
            return s + sp + ")\n"
        return php_str(v)
    if v is None:
        return "NULL\n"
    if v is True:
        return "bool(true)\n"
    if v is False:
        return "bool(false)\n"
    if isinstance(v, int):
        return f"int({v})\n"
    if isinstance(v, float):
        return f"float({v})\n"
    if isinstance(v, str):
        return f"string({len(v)}) \"{v}\"\n"
    if isinstance(v, (list, dict)):
        items = list(v.items()) if isinstance(v, dict) else list(enumerate(v))
        s = f"array({len(items)}) {{\n"
        for k, val in items:
            key = f'"{k}"' if isinstance(k, str) else str(k)
            s += f"{sp}  [{key}]=>\n{dump_value(val, indent + 1, False)}"
        return s + sp + "}\n"
    return php_str(v) + "\n"


def extract_php(source):
    if source.startswith("#!"):
        nl = source.find("\n")
        source = "" if nl < 0 else source[nl + 1:]
    parts = []
    pos = 0
    while True:
        start = source.find("<?", pos)
        if start < 0:
            if pos < len(source):
                parts.append(("html", source[pos:]))
            break
        if start > pos:
            parts.append(("html", source[pos:start]))
        code_start = start + 2
        if source.startswith("=", code_start):
            code_start += 1
            prefix = "echo "
        else:
            prefix = ""
        if source.startswith("php", code_start):
            code_start += 3
        end = source.find("?>", code_start)
        if end < 0:
            parts.append(("php", prefix + source[code_start:]))
            break
        parts.append(("php", prefix + source[code_start:end]))
        pos = end + 2
    return parts


def run_php(code, argv=None, filename=None, with_tags=False):
    rt = Runtime(argv, filename)
    try:
        if with_tags:
            for kind, text in extract_php(code):
                if kind == "html":
                    rt.out.append(text)
                else:
                    rt.run(Parser(text).parse())
        else:
            rt.run(Parser(code).parse())
    except ReturnValue:
        pass
    return "".join(rt.out)


def strip_comments(source):
    return re.sub(r"/\*.*?\*/|//[^\n]*|\#[^\n]*", "", source, flags=re.S)


def highlight_source(source):
    return '<pre><code style="color: #000000">' + html.escape(source) + "</code></pre>"


def phpinfo():
    return """phpinfo()
PHP Version => 8.6.0-dev

System => Linux
Build Date => Apr 17 2026 20:00:58
Server API => Command Line Interface
Configuration File (php.ini) Path => /usr/local/lib
Loaded Configuration File => (none)
Scan this dir for additional .ini files => (none)
Additional .ini files parsed => (none)
PHP API => 20250926
PHP Extension => 20250926
Zend Extension => 420250926
Debug Build => no
Thread Safety => disabled

This program makes use of the Zend Scripting Language Engine:
Zend Engine v4.6.0-dev, Copyright (c) Zend Technologies
    with Zend OPcache v8.6.0-dev, Copyright (c), by Zend Technologies
"""


def main(argv):
    args = list(argv)
    if not args:
        data = sys.stdin.read()
        sys.stdout.write(run_php(data, with_tags=True))
        return 0
    if args[0] in ("-v", "--version"):
        sys.stdout.write(VERSION_TEXT); return 0
    if args[0] in ("-h", "--help"):
        sys.stdout.write(HELP_TEXT); return 0
    if args[0] == "-m":
        sys.stdout.write(MODULES_TEXT); return 0
    if args[0] == "--ini":
        sys.stdout.write(INI_TEXT); return 0
    if args[0] == "-i":
        sys.stdout.write(phpinfo()); return 0
    if args[0] == "-r":
        if len(args) < 2:
            sys.stderr.write("Either execute direct code, process stdin or use a file.\n")
            return 1
        try:
            sys.stdout.write(run_php(args[1], args[2:]))
            return 0
        except Exception as e:
            sys.stderr.write(f"\nParse error: {e} in Command line code on line 1\n")
            return 255
    if "-R" in args or "-F" in args:
        return run_line_mode(args)
    if args[0] in ("-l", "-s", "-w", "-f") or args[0].startswith("-"):
        opt = args.pop(0)
        if opt in ("-n", "-d", "-c"):
            if opt in ("-d", "-c") and args:
                args.pop(0)
            return main(args)
        if not args:
            sys.stderr.write("No input file specified.\n")
            return 1
        path = args[0]
        rest = args[1:]
        if opt == "-f":
            return run_file(path, rest)
        if not os.path.exists(path):
            sys.stderr.write(f"Could not open input file: {path}\n")
            return 1
        source = open(path, "r", encoding="utf-8", errors="replace").read()
        if opt == "-l":
            try:
                for k, text in extract_php(source):
                    if k == "php":
                        Parser(text).parse()
                sys.stdout.write(f"No syntax errors detected in {path}\n")
                return 0
            except Exception as e:
                sys.stderr.write(f"Errors parsing {path}\nPHP Parse error: {e} in {path} on line 1\n")
                return 255
        if opt == "-s":
            sys.stdout.write(highlight_source(source)); return 0
        if opt == "-w":
            sys.stdout.write(strip_comments(source)); return 0
    return run_file(args[0], args[1:])


def run_file(path, rest):
    if not os.path.exists(path):
        sys.stderr.write(f"Could not open input file: {path}\n")
        return 1
    source = open(path, "r", encoding="utf-8", errors="replace").read()
    try:
        sys.stdout.write(run_php(source, rest, path, with_tags=True))
        return 0
    except Exception as e:
        sys.stderr.write(f"\nParse error: {e} in {path} on line 1\n")
        return 255


def run_line_mode(args):
    begin = end = code = file_code = None
    i = 0
    rest = []
    while i < len(args):
        a = args[i]
        if a == "-B" and i + 1 < len(args):
            begin = args[i + 1]; i += 2
        elif a == "-R" and i + 1 < len(args):
            code = args[i + 1]; i += 2
        elif a == "-F" and i + 1 < len(args):
            path = args[i + 1]
            if not os.path.exists(path):
                sys.stderr.write(f"Could not open input file: {path}\n")
                return 1
            file_code = open(path, "r", encoding="utf-8", errors="replace").read()
            if "<?" in file_code:
                chunks = [t for k, t in extract_php(file_code) if k == "php"]
                file_code = "\n".join(chunks)
            i += 2
        elif a == "-E" and i + 1 < len(args):
            end = args[i + 1]; i += 2
        elif a == "--":
            rest = args[i + 1:]; break
        else:
            i += 1
    rt = Runtime(rest)
    try:
        if begin:
            rt.run(Parser(begin).parse())
        body = code if code is not None else file_code
        for idx, line in enumerate(sys.stdin.readlines(), 1):
            rt.vars["argn"] = line
            rt.vars["argi"] = idx
            if body:
                rt.run(Parser(body).parse())
        if end:
            rt.run(Parser(end).parse())
        sys.stdout.write("".join(rt.out))
        return 0
    except Exception as e:
        sys.stderr.write(f"\nParse error: {e} in Command line code on line 1\n")
        return 255


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
