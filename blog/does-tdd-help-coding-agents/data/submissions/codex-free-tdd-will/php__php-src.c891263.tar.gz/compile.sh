#!/bin/bash
set -e
rm -f executable
cp src/mini_php.py executable
chmod +x executable
