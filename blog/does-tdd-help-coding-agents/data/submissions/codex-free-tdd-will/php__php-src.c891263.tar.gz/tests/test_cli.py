#!/usr/bin/env python3
import os
import subprocess
import sys
import tempfile


ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


def run(args, input_text=None):
    exe = os.path.join(ROOT, "executable")
    return subprocess.run(
        [exe] + args,
        input=input_text,
        text=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
    )


def assert_eq(actual, expected, label):
    if actual != expected:
        raise AssertionError(f"{label}\nexpected: {expected!r}\nactual:   {actual!r}")


def test_version_banner():
    result = run(["-v"])
    assert_eq(result.returncode, 0, "version exit")
    assert result.stdout.startswith("PHP 8.6.0-dev (cli)"), result.stdout
    assert "Zend Engine v4.6.0-dev" in result.stdout


def test_run_code_echoes_arithmetic():
    result = run(["-r", "echo 1+2, PHP_EOL;"])
    assert_eq(result.returncode, 0, "run code exit")
    assert_eq(result.stdout, "3\n", "run code stdout")
    assert_eq(result.stderr, "", "run code stderr")


def test_file_mode_and_lint():
    with tempfile.NamedTemporaryFile("w", suffix=".php", delete=False) as f:
        f.write('<?php echo "Hi\\n"; ?>Plain\n')
        path = f.name
    try:
        result = run([path, "arg1"])
        assert_eq(result.returncode, 0, "file mode exit")
        assert_eq(result.stdout, "Hi\nPlain\n", "file mode stdout")
        lint = run(["-l", path])
        assert_eq(lint.stdout, f"No syntax errors detected in {path}\n", "lint stdout")
    finally:
        os.unlink(path)


def test_variables_arrays_foreach_and_dump():
    code = '$a=["x"=>2,3]; foreach ($a as $k=>$v) { echo $k,":",$v,"\\n"; } var_dump($a);'
    result = run(["-r", code])
    assert_eq(result.returncode, 0, "array code exit")
    assert 'x:2\n0:3\narray(2) {' in result.stdout
    assert '["x"]=>\nint(2)' in result.stdout


def test_user_function_return_value():
    result = run(["-r", 'function add($a,$b) { return $a + $b; } echo add(2,5), "\\n";'])
    assert_eq(result.returncode, 0, "function exit")
    assert_eq(result.stdout, "7\n", "function stdout")


def main():
    tests = [
        test_version_banner,
        test_run_code_echoes_arithmetic,
        test_file_mode_and_lint,
        test_variables_arrays_foreach_and_dump,
        test_user_function_return_value,
    ]
    for test in tests:
        test()
    print(f"{len(tests)} tests passed")


if __name__ == "__main__":
    main()
