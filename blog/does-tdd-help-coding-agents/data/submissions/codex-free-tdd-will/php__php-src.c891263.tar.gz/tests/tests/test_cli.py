#!/usr/bin/env python3
import os
import subprocess
import sys


ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


def run(args, input_text=None):
    exe = os.path.join(ROOT, "executable")
    return subprocess.run(
        [exe] + args,
        input=input_text,
        text=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
    )


def assert_eq(actual, expected, label):
    if actual != expected:
        raise AssertionError(f"{label}\nexpected: {expected!r}\nactual:   {actual!r}")


def test_version_banner():
    result = run(["-v"])
    assert_eq(result.returncode, 0, "version exit")
    assert result.stdout.startswith("PHP 8.6.0-dev (cli)"), result.stdout
    assert "Zend Engine v4.6.0-dev" in result.stdout


def main():
    tests = [test_version_banner]
    for test in tests:
        test()
    print(f"{len(tests)} tests passed")


if __name__ == "__main__":
    main()
