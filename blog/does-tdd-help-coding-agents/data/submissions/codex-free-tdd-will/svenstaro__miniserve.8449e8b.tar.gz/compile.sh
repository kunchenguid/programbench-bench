#!/bin/bash
set -e
cp miniserve_clone.py executable
chmod +x executable
