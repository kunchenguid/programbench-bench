import os, socket, subprocess, tempfile, time, unittest

ROOT=os.path.dirname(os.path.dirname(__file__))
BIN=os.path.join(ROOT,'executable')

def http_request(port, path, headers=None, method='GET', body=b''):
    with socket.create_connection(('127.0.0.1', int(port)), timeout=1) as s:
        hdr = ''.join(f'{k}: {v}\r\n' for k,v in (headers or {}).items())
        if body and 'Content-Length' not in (headers or {}):
            hdr += f'Content-Length: {len(body)}\r\n'
        s.sendall(f'{method} {path} HTTP/1.1\r\nHost: 127.0.0.1:{port}\r\n{hdr}Connection: close\r\n\r\n'.encode() + body)
        chunks=[]
        while True:
            data=s.recv(65536)
            if not data: break
            chunks.append(data)
    raw=b''.join(chunks)
    head, _, body = raw.partition(b'\r\n\r\n')
    return head.decode('latin1'), body

def http_get(port, path, headers=None):
    return http_request(port, path, headers=headers)

class Behavior(unittest.TestCase):
    def build(self):
        subprocess.check_call([os.path.join(ROOT,'compile.sh')], cwd=ROOT)
    def test_serves_file_and_directory_listing(self):
        self.build()
        with tempfile.TemporaryDirectory() as d:
            with open(os.path.join(d,'a.txt'),'w') as f: f.write('hello')
            os.mkdir(os.path.join(d,'sub'))
            port='19451'
            p=subprocess.Popen([BIN,'-p',port,'-i','127.0.0.1',d], stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
            try:
                for _ in range(50):
                    try:
                        h, _ = http_get(port, '/')
                        if '200 OK' in h: break
                    except Exception:
                        pass
                    time.sleep(.05)
                _, raw = http_get(port, '/')
                body = raw.decode()
                self.assertIn('a.txt', body)
                self.assertIn('sub/', body)
                _, file_body = http_get(port, '/a.txt')
                self.assertEqual(file_body, b'hello')
            finally:
                p.terminate(); p.wait(timeout=3)

    def start_server(self, args, port):
        p=subprocess.Popen([BIN,'-p',str(port),'-i','127.0.0.1']+args, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
        for _ in range(50):
            try:
                h, _ = http_get(port, '/')
                if h.startswith('HTTP/1.0 ') or h.startswith('HTTP/1.1 '): break
            except Exception:
                pass
            time.sleep(.05)
        return p

    def test_auth_range_prefix_hidden_and_spa(self):
        self.build()
        with tempfile.TemporaryDirectory() as d:
            with open(os.path.join(d,'a.txt'),'w') as f: f.write('0123456789abcdef')
            with open(os.path.join(d,'.secret'),'w') as f: f.write('secret')
            with open(os.path.join(d,'index.html'),'w') as f: f.write('INDEX')
            with open(os.path.join(d,'about.html'),'w') as f: f.write('ABOUT')
            p=self.start_server(['--auth','joe:123','--route-prefix','/foo','--pretty-urls','--index','index.html','--spa',d], 19452)
            try:
                h,_=http_get(19452,'/foo/a.txt')
                self.assertIn('401 Unauthorized', h)
                auth='Basic am9lOjEyMw=='
                h,b=http_get(19452,'/foo/a.txt', {'Authorization':auth, 'Range':'bytes=2-5'})
                self.assertIn('206 Partial Content', h)
                self.assertIn('content-range: bytes 2-5/16'.lower(), h.lower())
                self.assertEqual(b, b'2345')
                h,_=http_get(19452,'/a.txt', {'Authorization':auth})
                self.assertIn('404 Not Found', h)
                h,_=http_get(19452,'/foo/.secret', {'Authorization':auth})
                self.assertIn('400 Bad Request', h)
                h,b=http_get(19452,'/foo/about', {'Authorization':auth})
                self.assertIn('200 OK', h)
                self.assertEqual(b, b'ABOUT')
                h,b=http_get(19452,'/foo/missing/route', {'Authorization':auth,'Accept':'text/html'})
                self.assertIn('200 OK', h)
                self.assertEqual(b, b'INDEX')
            finally:
                p.terminate(); p.wait(timeout=3)

    def test_upload_and_mkdir(self):
        self.build()
        with tempfile.TemporaryDirectory() as d:
            p=self.start_server(['-u','-U',d], 19453)
            try:
                body=b'--X\r\nContent-Disposition: form-data; name="path"; filename="up.txt"\r\nContent-Type: text/plain\r\n\r\nUP\r\n--X--\r\n'
                h,b=http_request(19453,'/upload?path=/', {'Content-Type':'multipart/form-data; boundary=X'}, method='POST', body=body)
                self.assertIn('200 OK', h)
                self.assertEqual(open(os.path.join(d,'up.txt')).read(), 'UP')
                h,_=http_request(19453,'/mkdir?path=newdir', method='POST')
                self.assertIn('200 OK', h)
                self.assertTrue(os.path.isdir(os.path.join(d,'newdir')))
            finally:
                p.terminate(); p.wait(timeout=3)

if __name__ == '__main__': unittest.main()
