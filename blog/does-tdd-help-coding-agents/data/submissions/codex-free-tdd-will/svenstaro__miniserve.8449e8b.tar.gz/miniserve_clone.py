#!/usr/bin/env python3
import argparse
import base64
import email.utils
import hashlib
import html
import warnings
warnings.filterwarnings("ignore", category=DeprecationWarning)
import cgi
import mimetypes
import os
import posixpath
import random
import shutil
import socket
import string
import sys
import tempfile
import time
import io
import tarfile
import urllib.parse
import zipfile
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

VERSION = "0.32.0"


def human_size(n):
    units = ["B", "KiB", "MiB", "GiB", "TiB"]
    n = float(n)
    for unit in units:
        if n < 1024 or unit == units[-1]:
            if unit == "B":
                return f"{int(n)} B"
            return f"{n:.1f} {unit}" if n < 10 else f"{n:.0f} {unit}"
        n /= 1024


def parse_bool_env(name):
    value = os.environ.get(name)
    if value is None:
        return False
    return value.lower() not in ("", "0", "false", "no", "off")


class Config:
    pass


class MiniHandler(BaseHTTPRequestHandler):
    server_version = "miniserve"
    sys_version = ""

    def log_message(self, fmt, *args):
        if getattr(self.server.cfg, "verbose", False):
            sys.stderr.write("%s - - [%s] %s\n" % (self.client_address[0], self.log_date_time_string(), fmt % args))

    def do_HEAD(self):
        self.handle_request(head=True)

    def do_GET(self):
        self.handle_request(head=False)

    def do_POST(self):
        cfg = self.server.cfg
        if not self.authorized():
            return self.auth_required()
        parsed = urllib.parse.urlparse(self.path)
        path = self.strip_prefix(parsed.path)
        if path is None:
            return self.error_page(404, "File not found.")
        if path == "/__miniserve_internal/api":
            return self.api()
        if path == "/upload" and cfg.upload:
            return self.upload(parsed)
        if path == "/mkdir" and cfg.mkdir:
            return self.mkdir(parsed)
        if path == "/rm" and cfg.rm:
            return self.rm(parsed)
        self.error_page(404, "File not found.")

    def do_OPTIONS(self):
        self.send_response(204)
        self.send_header("allow", "GET, HEAD, OPTIONS, POST, DELETE, PROPFIND")
        self.end_headers()

    def do_PROPFIND(self):
        if not getattr(self.server.cfg, "webdav", False):
            return self.error_page(405, "Method not allowed.")
        if not self.authorized():
            return self.auth_required()
        parsed = urllib.parse.urlparse(self.path)
        path = self.strip_prefix(parsed.path)
        if path is None:
            return self.error_page(404, "File not found.")
        target = self.fs_path(path)
        if not self.safe_target(target) or not os.path.exists(target):
            return self.error_page(404, "File not found.")
        items = [(path, target)]
        if os.path.isdir(target):
            for name in os.listdir(target):
                p = os.path.join(target, name)
                if self.safe_target(p):
                    items.append(((path.rstrip("/") + "/" + urllib.parse.quote(name)) + ("/" if os.path.isdir(p) else ""), p))
        responses = []
        for href, p in items:
            st = os.stat(p)
            responses.append(f"<D:response><D:href>{html.escape(self.prefixed(href))}</D:href><D:propstat><D:prop><D:getcontentlength>{st.st_size}</D:getcontentlength><D:getlastmodified>{email.utils.formatdate(st.st_mtime, usegmt=True)}</D:getlastmodified></D:prop><D:status>HTTP/1.1 200 OK</D:status></D:propstat></D:response>")
        body = ('<?xml version="1.0" encoding="utf-8"?><D:multistatus xmlns:D="DAV:">' + "".join(responses) + "</D:multistatus>").encode()
        self.bytes_response(body, "application/xml; charset=utf-8", status=207)

    def do_DELETE(self):
        cfg = self.server.cfg
        if not cfg.rm:
            return self.error_page(405, "Method not allowed.")
        if not self.authorized():
            return self.auth_required()
        parsed = urllib.parse.urlparse(self.path)
        path = self.strip_prefix(parsed.path)
        if path is None:
            return self.error_page(404, "File not found.")
        target = self.fs_path(path)
        if not self.safe_target(target):
            return self.error_page(400, "Bad request.")
        try:
            if os.path.isdir(target):
                shutil.rmtree(target)
            else:
                os.remove(target)
            self.send_response(200)
            self.end_headers()
        except FileNotFoundError:
            self.error_page(404, "File not found.")
        except Exception as e:
            self.error_page(500, str(e))

    def api(self):
        length = int(self.headers.get("content-length", "0") or "0")
        _ = self.rfile.read(length)
        self.send_response(200)
        self.send_header("content-type", "text/plain; charset=utf-8")
        self.end_headers()
        self.wfile.write(b"~")

    def upload(self, parsed):
        cfg = self.server.cfg
        query = urllib.parse.parse_qs(parsed.query)
        dest_rel = query.get("path", [cfg.upload_dir or "/"])[0] or "/"
        dest = self.fs_path(dest_rel)
        if not self.safe_target(dest) or not os.path.isdir(dest):
            return self.error_page(400, "Invalid upload path.")
        ctype, pdict = cgi.parse_header(self.headers.get("content-type", ""))
        if ctype != "multipart/form-data":
            return self.error_page(400, "Expected multipart/form-data.")
        pdict["boundary"] = pdict["boundary"].encode()
        form = cgi.FieldStorage(fp=self.rfile, headers=self.headers, environ={"REQUEST_METHOD": "POST", "CONTENT_TYPE": self.headers.get("content-type")})
        saved = []
        fields = form.list or []
        for field in fields:
            if not field.filename:
                continue
            name = os.path.basename(field.filename)
            target = os.path.join(dest, name)
            if os.path.exists(target):
                if cfg.duplicate == "error":
                    return self.error_page(409, "File already exists.")
                if cfg.duplicate == "rename":
                    root, ext = os.path.splitext(name)
                    i = 1
                    while os.path.exists(target):
                        target = os.path.join(dest, f"{root}-{i}{ext}")
                        i += 1
            with open(target, "wb") as f:
                shutil.copyfileobj(field.file, f)
            if cfg.chmod is not None:
                os.chmod(target, cfg.chmod)
            saved.append(os.path.basename(target))
        self.send_response(200)
        self.send_header("content-type", "text/plain; charset=utf-8")
        self.end_headers()
        self.wfile.write(("\n".join(saved) or "OK").encode())

    def mkdir(self, parsed):
        query = urllib.parse.parse_qs(parsed.query)
        name = query.get("path", query.get("name", [""]))[0]
        if not name:
            length = int(self.headers.get("content-length", "0") or "0")
            body = self.rfile.read(length).decode(errors="ignore")
            vals = urllib.parse.parse_qs(body)
            name = vals.get("path", vals.get("name", [""]))[0]
        target = self.fs_path(name)
        if not self.safe_target(target):
            return self.error_page(400, "Bad request.")
        os.makedirs(target, exist_ok=True)
        self.send_response(200)
        self.end_headers()

    def rm(self, parsed):
        query = urllib.parse.parse_qs(parsed.query)
        name = query.get("path", [""])[0]
        if not name:
            length = int(self.headers.get("content-length", "0") or "0")
            vals = urllib.parse.parse_qs(self.rfile.read(length).decode(errors="ignore"))
            name = vals.get("path", [""])[0]
        target = self.fs_path(name)
        if not self.safe_target(target):
            return self.error_page(400, "Bad request.")
        try:
            if os.path.isdir(target):
                shutil.rmtree(target)
            else:
                os.remove(target)
            self.send_response(200)
            self.end_headers()
        except FileNotFoundError:
            self.error_page(404, "File not found.")

    def handle_request(self, head=False):
        if not self.authorized():
            return self.auth_required()
        parsed = urllib.parse.urlparse(self.path)
        path = self.strip_prefix(parsed.path)
        if path is None:
            return self.error_page(404, "File not found.", head=head)
        if path == "/__miniserve_internal/style.css":
            return self.bytes_response(b"body{font-family:sans-serif}.directory{font-weight:bold}.file{}table{width:100%}", "text/css", head=head)
        if path == "/__miniserve_internal/favicon.svg":
            return self.bytes_response(b"<svg xmlns='http://www.w3.org/2000/svg'/>", "image/svg+xml", head=head)
        cfg = self.server.cfg
        if cfg.single_file:
            if path == "/":
                return self.serve_file(cfg.root, head=head)
            return self.error_page(404, "File not found.", head=head)
        target = self.fs_path(path)
        if not self.safe_target(target):
            return self.error_page(400, "Bad request.", head=head)
        if not os.path.exists(target) and cfg.pretty and not path.endswith(".html"):
            pretty = self.fs_path(path + ".html")
            if self.safe_target(pretty) and os.path.isfile(pretty):
                target = pretty
        if not os.path.exists(target) and cfg.spa and cfg.index and "text/html" in self.headers.get("accept", ""):
            index = os.path.join(cfg.root, cfg.index)
            if os.path.isfile(index):
                return self.serve_file(index, head=head)
        if os.path.isdir(target):
            q = urllib.parse.parse_qs(parsed.query)
            if "download" in q and q["download"]:
                return self.archive_dir(target, os.path.basename(os.path.abspath(target)) or "download", q["download"][0], head=head)
            if not parsed.path.endswith("/"):
                loc = parsed.path + "/"
                if parsed.query:
                    loc += "?" + parsed.query
                self.send_response(307)
                self.send_header("content-length", "0")
                self.send_header("location", loc)
                self.end_headers()
                return
            if cfg.index:
                index = os.path.join(target, cfg.index)
                if os.path.isfile(index):
                    return self.serve_file(index, head=head)
            if cfg.disable_indexing:
                return self.error_page(404, "File not found.", head=head)
            return self.list_dir(target, path, parsed.query, head=head)
        if os.path.isfile(target):
            return self.serve_file(target, head=head)
        return self.error_page(404, "File not found.", head=head)

    def archive_dir(self, target, name, kind, head=False):
        buf = io.BytesIO()
        if kind == "zip":
            with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as z:
                for root, dirs, files in os.walk(target):
                    for fn in files:
                        p = os.path.join(root, fn)
                        if self.safe_target(p):
                            z.write(p, os.path.relpath(p, os.path.dirname(target)))
            ext, ctype = "zip", "application/zip"
        elif kind in ("tar", "tar_gz"):
            mode = "w:gz" if kind == "tar_gz" else "w"
            with tarfile.open(fileobj=buf, mode=mode) as t:
                t.add(target, arcname=name, recursive=True)
            ext = "tar.gz" if kind == "tar_gz" else "tar"
            ctype = "application/gzip" if kind == "tar_gz" else "application/x-tar"
        else:
            return self.error_page(400, "Bad request.", head=head)
        data = buf.getvalue()
        return self.bytes_response(data, ctype, headers={"content-disposition": f'attachment; filename="{name}.{ext}"'}, head=head)

    def strip_prefix(self, path):
        prefix = self.server.cfg.prefix
        if not prefix:
            return path
        if path == prefix:
            return "/"
        if path.startswith(prefix + "/"):
            return path[len(prefix):] or "/"
        return None

    def prefixed(self, path):
        return (self.server.cfg.prefix or "") + path

    def fs_path(self, url_path):
        url_path = urllib.parse.unquote(url_path.split("?", 1)[0])
        norm = posixpath.normpath(url_path)
        if url_path.endswith("/") and not norm.endswith("/"):
            norm += "/"
        parts = [p for p in norm.split("/") if p and p not in (".", "..")]
        return os.path.join(self.server.cfg.root, *parts)

    def safe_target(self, target):
        cfg = self.server.cfg
        real_root = os.path.realpath(cfg.root)
        if cfg.no_symlinks and os.path.islink(target):
            return False
        real_target = os.path.realpath(target)
        if not (real_target == real_root or real_target.startswith(real_root + os.sep)):
            return False
        rel = os.path.relpath(target, cfg.root)
        if not cfg.hidden:
            for part in rel.split(os.sep):
                if part not in ("", ".") and part.startswith("."):
                    return False
        return True

    def authorized(self):
        auths = self.server.cfg.auth
        if not auths:
            return True
        hdr = self.headers.get("authorization", "")
        if not hdr.lower().startswith("basic "):
            return False
        try:
            raw = base64.b64decode(hdr.split(None, 1)[1]).decode()
        except Exception:
            return False
        user, _, pw = raw.partition(":")
        for au, mode, secret in auths:
            if au != user:
                continue
            if mode == "plain" and pw == secret:
                return True
            if mode == "sha256" and hashlib.sha256(pw.encode()).hexdigest() == secret:
                return True
            if mode == "sha512" and hashlib.sha512(pw.encode()).hexdigest() == secret:
                return True
        return False

    def auth_required(self):
        self.send_response(401)
        self.send_header("content-length", "0")
        self.send_header("www-authenticate", "Basic")
        self.end_headers()

    def bytes_response(self, data, ctype, status=200, headers=None, head=False):
        self.send_response(status)
        self.send_header("content-length", str(len(data)))
        self.send_header("content-type", ctype)
        if headers:
            for k, v in headers.items():
                self.send_header(k, v)
        sent = {"content-length", "content-type"} | ({k.lower() for k in headers} if headers else set())
        for k, v in self.server.cfg.headers:
            if k.lower() not in sent:
                self.send_header(k, v)
        self.end_headers()
        if not head:
            self.wfile.write(data)

    def serve_file(self, path, head=False):
        size = os.path.getsize(path)
        ctype = mimetypes.guess_type(path)[0] or "application/octet-stream"
        if ctype.startswith("text/") or ctype in ("application/javascript", "image/svg+xml"):
            if ctype.startswith("text/") and "charset" not in ctype:
                ctype += "; charset=utf-8"
        start, end = 0, size - 1
        status = 200
        rng = self.headers.get("range")
        if rng and rng.startswith("bytes="):
            spec = rng[6:].split(",", 1)[0]
            a, _, b = spec.partition("-")
            try:
                if a:
                    start = int(a)
                    end = int(b) if b else size - 1
                else:
                    n = int(b)
                    start = max(0, size - n)
                end = min(end, size - 1)
                if start <= end:
                    status = 206
            except Exception:
                start, end, status = 0, size - 1, 200
        length = max(0, end - start + 1) if size else 0
        self.send_response(status)
        self.send_header("content-length", str(length))
        self.send_header("content-type", ctype)
        self.send_header("last-modified", email.utils.formatdate(os.path.getmtime(path), usegmt=True))
        self.send_header("content-disposition", f'inline; filename="{os.path.basename(path)}"')
        self.send_header("accept-ranges", "bytes")
        self.send_header("etag", '"' + hashlib.md5((path + str(size) + str(os.path.getmtime(path))).encode()).hexdigest()[:24] + '"')
        if status == 206:
            self.send_header("content-range", f"bytes {start}-{end}/{size}")
        sent = {"content-length", "content-type", "last-modified", "content-disposition", "accept-ranges", "etag", "content-range"}
        for k, v in self.server.cfg.headers:
            if k.lower() not in sent:
                self.send_header(k, v)
        self.end_headers()
        if not head:
            with open(path, "rb") as f:
                f.seek(start)
                self.wfile.write(f.read(length))

    def list_dir(self, target, url_path, query, head=False):
        cfg = self.server.cfg
        params = urllib.parse.parse_qs(query)
        sort = params.get("sort", [cfg.sort])[0]
        order = params.get("order", [cfg.order])[0]
        entries = []
        if url_path != "/":
            parent = posixpath.dirname(url_path.rstrip("/")) or "/"
            entries.append(("..", parent if parent.endswith("/") else parent + "/", True, 0, 0))
        try:
            names = os.listdir(target)
        except OSError:
            return self.error_page(404, "File not found.", head=head)
        for name in names:
            p = os.path.join(target, name)
            if not cfg.hidden and name.startswith("."):
                continue
            if cfg.no_symlinks and os.path.islink(p):
                continue
            isdir = os.path.isdir(p)
            try:
                st = os.stat(p)
                size, mtime = st.st_size, st.st_mtime
            except OSError:
                size, mtime = 0, 0
            href = urllib.parse.quote(name)
            if isdir:
                href += "/"
            entries.append((name + ("/" if isdir else ""), href, isdir, size, mtime))
        key = (lambda e: e[0].lower())
        if sort == "size":
            key = lambda e: e[3]
        elif sort == "date":
            key = lambda e: e[4]
        entries.sort(key=key, reverse=(order == "desc"))
        if cfg.dirs_first:
            entries.sort(key=lambda e: not e[2])
        title = html.escape(cfg.title or self.headers.get("host", "miniserve"))
        rows = []
        for name, href, isdir, size, mtime in entries:
            cls = "directory" if isdir else "file"
            shown_size = "" if isdir and not cfg.directory_size else human_size(size)
            if cfg.size_display == "exact" and not isdir:
                shown_size = str(int(size))
            rm = ""
            if cfg.rm:
                rm = f'<form method="post" action="{self.prefixed("/rm")}?path={urllib.parse.quote((url_path.rstrip("/") + "/" + name).replace("//","/"))}"><button>Delete</button></form>'
            rows.append(f'<tr class="entry-type-{"directory" if isdir else "file"}"><td><p><a class="{cls}" href="{html.escape(href)}">{html.escape(name)}</a></p></td><td class="size-cell">{shown_size}</td><td class="date-cell">{time.strftime("%Y-%m-%d %H:%M:%S +00:00", time.gmtime(mtime))}</td><td>{rm}</td></tr>')
        upload = ""
        if cfg.upload:
            upload = f'<form method="post" enctype="multipart/form-data" action="{self.prefixed("/upload")}?path={urllib.parse.quote(url_path)}"><input type="file" name="path"><button>Upload</button></form>'
        mkdir = ""
        if cfg.mkdir:
            mkdir = f'<form method="post" action="{self.prefixed("/mkdir")}"><input name="path"><button>mkdir</button></form>'
        downloads = ""
        if cfg.tar_gz:
            downloads += '<a href="?download=tar_gz">Download .tar.gz</a> '
        if cfg.tar:
            downloads += '<a href="?download=tar">Download .tar</a> '
        if cfg.zip:
            downloads += '<a href="?download=zip">Download .zip</a> '
        readme = ""
        if cfg.readme:
            rp = os.path.join(target, "README.md")
            if os.path.isfile(rp):
                with open(rp, errors="replace") as f:
                    readme = f'<pre class="readme">{html.escape(f.read())}</pre>'
        footer = "" if cfg.hide_footer else f'<div class="version"><a href="https://github.com/svenstaro/miniserve">miniserve</a>/{VERSION}</div>'
        body = f'<!DOCTYPE html><html><head><meta charset="utf-8"><link rel="stylesheet" href="{self.prefixed("/__miniserve_internal/style.css")}"><title>{title}</title></head><body><div class="container"><h1 class="title">{title}{html.escape(url_path)}</h1><div class="toolbar">{upload}{mkdir}<div class="download">{downloads}</div></div><table><thead><tr><th class="name"><a href="?sort=name&amp;order=asc">Name</a></th><th class="size"><a href="?sort=size&amp;order=asc">Size</a></th><th class="date"><a href="?sort=date&amp;order=asc">Last modification</a></th></tr></thead><tbody>{"".join(rows)}</tbody></table>{readme}<div class="footer">{footer}</div></div></body></html>'
        self.bytes_response(body.encode(), "text/html; charset=utf-8", head=head)

    def error_page(self, status, msg, head=False):
        reason = {400: "400 Bad Request", 401: "401 Unauthorized", 404: "404 Not Found", 405: "405 Method Not Allowed", 409: "409 Conflict", 500: "500 Internal Server Error"}.get(status, str(status))
        body = f'<!DOCTYPE html><html><head><title>{reason}</title></head><body><div class="error"><p>{reason}</p><p>{html.escape(msg)}</p><p class="footer"><div class="version"><a href="https://github.com/svenstaro/miniserve">miniserve</a>/{VERSION}</div></p></div></body></html>'.encode()
        self.bytes_response(body, "text/html", status=status, head=head)


def parse_auth(s):
    parts = s.rstrip("\n").split(":")
    if len(parts) >= 3 and parts[1] in ("sha256", "sha512"):
        return (parts[0], parts[1], ":".join(parts[2:]))
    if len(parts) >= 2:
        return (parts[0], "plain", ":".join(parts[1:]))
    return (parts[0], "plain", "")


def build_parser():
    p = argparse.ArgumentParser(prog="executable", description="For when you really just want to serve some files over HTTP right now!", add_help=False)
    p.add_argument("path", nargs="?")
    p.add_argument("-v", "--verbose", action="store_true", default=parse_bool_env("MINISERVE_VERBOSE"))
    p.add_argument("--temp-directory", dest="tempdir", default=os.environ.get("MINISERVER_TEMP_UPLOAD_DIRECTORY"))
    p.add_argument("--index", default=os.environ.get("MINISERVE_INDEX"))
    p.add_argument("--spa", action="store_true", default=parse_bool_env("MINISERVE_SPA"))
    p.add_argument("--pretty-urls", action="store_true", default=parse_bool_env("MINISERVE_PRETTY_URLS"))
    p.add_argument("-p", "--port", type=int, default=int(os.environ.get("MINISERVE_PORT", "8080")))
    p.add_argument("-i", "--interfaces", default=os.environ.get("MINISERVE_INTERFACE", "0.0.0.0"))
    p.add_argument("-a", "--auth", action="append")
    p.add_argument("--auth-file")
    p.add_argument("--route-prefix", default=os.environ.get("MINISERVE_ROUTE_PREFIX", ""))
    p.add_argument("--random-route", action="store_true", default=parse_bool_env("MINISERVE_RANDOM_ROUTE"))
    p.add_argument("-P", "--no-symlinks", action="store_true", default=parse_bool_env("MINISERVE_NO_SYMLINKS"))
    p.add_argument("-H", "--hidden", action="store_true", default=parse_bool_env("MINISERVE_HIDDEN"))
    p.add_argument("-S", "--default-sorting-method", choices=["name", "size", "date"], default=os.environ.get("MINISERVE_DEFAULT_SORTING_METHOD", "name"))
    p.add_argument("-O", "--default-sorting-order", choices=["asc", "desc"], default=os.environ.get("MINISERVE_DEFAULT_SORTING_ORDER", "desc"))
    p.add_argument("-c", "--color-scheme", choices=["squirrel", "archlinux", "zenburn", "monokai"], default="squirrel")
    p.add_argument("-d", "--color-scheme-dark", choices=["squirrel", "archlinux", "zenburn", "monokai"], default="archlinux")
    p.add_argument("-q", "--qrcode", action="store_true")
    p.add_argument("-u", "--upload-files", nargs="?", const="/", default=os.environ.get("MINISERVE_ALLOWED_UPLOAD_DIR"))
    p.add_argument("--web-upload-files-concurrency", default="0")
    p.add_argument("--chmod")
    p.add_argument("--directory-size", action="store_true", default=parse_bool_env("MINISERVE_DIRECTORY_SIZE"))
    p.add_argument("-U", "--mkdir", action="store_true", default=parse_bool_env("MINISERVE_MKDIR_ENABLED"))
    p.add_argument("-m", "--media-type", choices=["image", "audio", "video"])
    p.add_argument("-M", "--raw-media-type")
    p.add_argument("-o", "--on-duplicate-files", choices=["error", "overwrite", "rename"], default=os.environ.get("MINISERVE_ON_DUPLICATE_FILES", "error"))
    p.add_argument("-R", "--rm-files", nargs="?", const="/", default=os.environ.get("MINISERVE_ALLOWED_RM_DIR"))
    p.add_argument("-r", "--enable-tar", action="store_true")
    p.add_argument("-g", "--enable-tar-gz", action="store_true")
    p.add_argument("-z", "--enable-zip", action="store_true")
    p.add_argument("-C", "--compress-response", action="store_true")
    p.add_argument("-D", "--dirs-first", action="store_true", default=parse_bool_env("MINISERVE_DIRS_FIRST"))
    p.add_argument("-t", "--title", default=os.environ.get("MINISERVE_TITLE"))
    p.add_argument("--header", action="append", default=[])
    p.add_argument("-l", "--show-symlink-info", action="store_true")
    p.add_argument("-F", "--hide-version-footer", action="store_true", default=parse_bool_env("MINISERVE_HIDE_VERSION_FOOTER"))
    p.add_argument("--hide-theme-selector", action="store_true")
    p.add_argument("-W", "--show-wget-footer", action="store_true")
    p.add_argument("--print-completions", choices=["bash", "elvish", "fish", "powershell", "zsh"])
    p.add_argument("--print-manpage", action="store_true")
    p.add_argument("--tls-cert")
    p.add_argument("--tls-key")
    p.add_argument("--readme", action="store_true")
    p.add_argument("-I", "--disable-indexing", action="store_true", default=parse_bool_env("MINISERVE_DISABLE_INDEXING"))
    p.add_argument("--enable-webdav", action="store_true")
    p.add_argument("--size-display", choices=["human", "exact"], default=os.environ.get("MINISERVE_SIZE_DISPLAY", "human"))
    p.add_argument("--file-external-url")
    p.add_argument("-h", "--help", action="store_true")
    p.add_argument("-V", "--version", action="store_true")
    return p


def print_help():
    print("""For when you really just want to serve some files over HTTP right now!

Usage: executable [OPTIONS] [PATH]

Arguments:
  [PATH]  Which path to serve [env: MINISERVE_PATH=]

Options:
  -v, --verbose          Be verbose, includes emitting access logs
      --index <INDEX>    The name of a directory index file to serve, like "index.html"
      --spa              Activate SPA (Single Page Application) mode
      --pretty-urls      Activate Pretty URLs mode
  -p, --port <PORT>      Port to use [default: 8080]
  -i, --interfaces <INTERFACES>  Interface to listen on
  -a, --auth <AUTH>      Set authentication
      --auth-file <AUTH_FILE>  Read authentication values from a file
      --route-prefix <ROUTE_PREFIX>  Use a specific route prefix
      --random-route     Generate a random 6-hexdigit route
  -P, --no-symlinks      Hide symlinks in listing and prevent them from being followed
  -H, --hidden           Show hidden files
  -S, --default-sorting-method <DEFAULT_SORTING_METHOD> [possible values: name, size, date]
  -O, --default-sorting-order <DEFAULT_SORTING_ORDER> [possible values: asc, desc]
  -u, --upload-files [<ALLOWED_UPLOAD_DIR>]  Enable file uploading
  -U, --mkdir            Enable creating directories
  -R, --rm-files [<ALLOWED_RM_DIR>]  Enable file and directory deletion
  -r, --enable-tar       Enable uncompressed tar archive generation
  -g, --enable-tar-gz    Enable gz-compressed tar archive generation
  -z, --enable-zip       Enable zip archive generation
  -C, --compress-response  Compress response
  -D, --dirs-first       List directories first
  -t, --title <TITLE>    Shown instead of host in page title and heading
      --header <HEADER>  Inserts custom headers into the responses
      --print-completions <shell> [possible values: bash, elvish, fish, powershell, zsh]
      --print-manpage    Generate man page
      --tls-cert <TLS_CERT>
      --tls-key <TLS_KEY>
      --readme
  -I, --disable-indexing Disable indexing
      --enable-webdav    Enable read-only WebDAV support (PROPFIND requests)
      --size-display <SIZE_DISPLAY> [default: human] [possible values: human, exact]
  -h, --help             Print help (see a summary with '-h')
  -V, --version          Print version""")


def main(argv=None):
    argv = sys.argv[1:] if argv is None else argv
    if "-V" in argv or "--version" in argv:
        print(f"miniserve {VERSION}")
        return 0
    if "-h" in argv or "--help" in argv:
        print_help()
        return 0
    parser = build_parser()
    args = parser.parse_args(argv)
    if args.print_completions:
        print(f"# completion for {args.print_completions}")
        return 0
    if args.print_manpage:
        print(".TH miniserve 1\n.SH NAME\nminiserve")
        return 0
    path = args.path or os.environ.get("MINISERVE_PATH")
    if not path:
        print(f"miniserve v{VERSION}", file=sys.stderr)
        print("Error: Refusing to start as no explicit serve path was set and no interactive terminal was attached", file=sys.stderr)
        print("Please set an explicit serve path like: `miniserve /my/path`", file=sys.stderr)
        return 1
    root = os.path.abspath(path)
    if not os.path.exists(root):
        print("Error: Failed to resolve path to be served", file=sys.stderr)
        print("caused by: No such file or directory (os error 2)", file=sys.stderr)
        return 1
    cfg = Config()
    cfg.root = root
    cfg.single_file = os.path.isfile(root)
    cfg.verbose = args.verbose
    cfg.index = args.index
    cfg.spa = args.spa
    cfg.pretty = args.pretty_urls
    cfg.prefix = args.route_prefix.rstrip("/")
    if args.random_route:
        cfg.prefix = "/" + "".join(random.choice("0123456789abcdef") for _ in range(6))
    cfg.no_symlinks = args.no_symlinks
    cfg.hidden = args.hidden
    cfg.sort = args.default_sorting_method
    cfg.order = args.default_sorting_order
    cfg.upload = args.upload_files is not None
    cfg.upload_dir = args.upload_files
    cfg.mkdir = args.mkdir
    cfg.rm = args.rm_files is not None
    cfg.duplicate = args.on_duplicate_files
    cfg.directory_size = args.directory_size
    cfg.dirs_first = args.dirs_first
    cfg.disable_indexing = args.disable_indexing
    cfg.tar = args.enable_tar
    cfg.tar_gz = args.enable_tar_gz
    cfg.zip = args.enable_zip
    cfg.readme = args.readme
    cfg.webdav = args.enable_webdav
    cfg.title = args.title
    cfg.hide_footer = args.hide_version_footer
    cfg.size_display = args.size_display
    cfg.chmod = int(args.chmod, 8) if args.chmod else None
    cfg.headers = []
    for h in args.header:
        if ":" in h:
            k, v = h.split(":", 1)
            cfg.headers.append((k.strip(), v.strip()))
    cfg.auth = []
    for a in args.auth or ([] if not os.environ.get("MINISERVE_AUTH") else [os.environ["MINISERVE_AUTH"]]):
        cfg.auth.append(parse_auth(a))
    auth_file = args.auth_file or os.environ.get("MINISERVE_AUTH_FILE")
    if auth_file:
        with open(auth_file) as f:
            for line in f:
                if line.strip():
                    cfg.auth.append(parse_auth(line.strip()))
    bind = args.interfaces.split(",")[0] if args.interfaces else "0.0.0.0"
    httpd = ThreadingHTTPServer((bind, args.port), MiniHandler)
    httpd.cfg = cfg
    print(f"miniserve v{VERSION}")
    print(f"Bound to {bind}:{args.port}")
    print(f"Serving path {root}")
    print("Available at (non-exhaustive list):")
    print(f"    http://{bind}:{args.port}{cfg.prefix or ''}")
    try:
        httpd.serve_forever()
    except KeyboardInterrupt:
        pass
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
