import json
import subprocess
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
BIN = ROOT / "executable"


def compile_project():
    subprocess.run(["bash", "compile.sh"], cwd=ROOT, check=True)


def run_cmd(*args, input_text=None):
    compile_project()
    return subprocess.run([str(BIN), *map(str, args)], cwd=ROOT, input=input_text, text=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)


class TokeiCliTests(unittest.TestCase):
    def test_json_counts_python_rust_and_json(self):
        with tempfile.TemporaryDirectory() as d:
            root = Path(d)
            (root / "a.py").write_text('# top\n\nx = 1  # inline\n"""doc\nstill doc"""\nprint("# not comment")\n')
            (root / "main.rs").write_text('// hi\nfn main() {\n  println!("/* no */");\n  /* block\n     comment */\n  let x = 1;\n}\n')
            (root / "data.json").write_text('{\n  "a": 1\n}\n')

            proc = run_cmd(root, "-o", "json")

        self.assertEqual(proc.returncode, 0, proc.stderr)
        data = json.loads(proc.stdout)
        self.assertEqual(data["Python"]["blanks"], 1)
        self.assertEqual(data["Python"]["code"], 4)
        self.assertEqual(data["Python"]["comments"], 1)
        self.assertEqual(data["Rust"]["code"], 4)
        self.assertEqual(data["Rust"]["comments"], 3)
        self.assertEqual(data["JSON"]["code"], 3)
        self.assertEqual(data["Total"]["code"], 11)
        self.assertEqual(data["Total"]["comments"], 4)

    def test_common_languages_type_filter_and_tokeignore(self):
        with tempfile.TemporaryDirectory() as d:
            root = Path(d)
            (root / "a.c").write_text("#include <stdio.h>\n// cmt\nint main(){ /* inline */\n  return 0;\n}\n")
            (root / "web.js").write_text('// js\nconst s = "// no";\n/* b1\nb2 */\nconsole.log(s);\n')
            (root / "index.html").write_text("<!doctype html>\n<!-- hello\nthere -->\n<p>x</p>\n")
            (root / "readme.md").write_text("# Title\n\ntext\n```js\nconsole.log(1)\n```\n")
            ignored = root / "ignored"
            ignored.mkdir()
            (ignored / ".tokeignore").write_text("*.py\n")
            (ignored / "skip.py").write_text("x = 1\n")

            proc = run_cmd(root, "-o", "json")
            type_proc = run_cmd(root, "-t", "JavaScript", "-o", "json")

        self.assertEqual(proc.returncode, 0, proc.stderr)
        data = json.loads(proc.stdout)
        self.assertEqual(data["C"]["code"], 4)
        self.assertEqual(data["C"]["comments"], 1)
        self.assertEqual(data["JavaScript"]["code"], 2)
        self.assertEqual(data["JavaScript"]["comments"], 3)
        self.assertEqual(data["HTML"]["code"], 2)
        self.assertEqual(data["HTML"]["comments"], 2)
        self.assertEqual(data["Markdown"]["blanks"], 1)
        self.assertEqual(data["Markdown"]["comments"], 5)
        self.assertNotIn("Python", data)

        filtered = json.loads(type_proc.stdout)
        self.assertEqual(sorted(filtered.keys()), ["JavaScript", "Total"])
        self.assertEqual(filtered["Total"]["code"], 2)

    def test_terminal_files_streaming_and_version(self):
        with tempfile.TemporaryDirectory() as d:
            root = Path(d)
            (root / "app.py").write_text("# hi\nprint(1)\n")

            table = run_cmd(root)
            files = run_cmd(root, "--files")
            stream = run_cmd(root, "--streaming", "json")
            version = run_cmd("--version")

        self.assertEqual(table.returncode, 0, table.stderr)
        self.assertIn("Language", table.stdout)
        self.assertIn("Python", table.stdout)
        self.assertIn("Total", table.stdout)
        self.assertIn("app.py", files.stdout)

        rows = [json.loads(line) for line in stream.stdout.splitlines() if line.strip()]
        self.assertEqual(rows[0]["language"], "Python")
        self.assertEqual(rows[0]["stats"]["stats"]["code"], 1)
        self.assertIn("tokei 14.0.0", version.stdout)

    def test_extensionless_files_and_json_input_are_counted(self):
        with tempfile.TemporaryDirectory() as d:
            root = Path(d)
            src = root / "src"
            src.mkdir()
            (src / "Dockerfile").write_text("# c\nFROM ubuntu\nRUN echo hi\n")
            (src / "Makefile").write_text("# c\nall:\n\techo hi\n")
            saved = root / "stats.json"
            saved.write_text(json.dumps({
                "Python": {
                    "blanks": 0,
                    "code": 1,
                    "comments": 0,
                    "reports": [{"stats": {"blanks": 0, "code": 1, "comments": 0, "blobs": {}}, "name": "old.py"}],
                    "children": {},
                    "inaccurate": False,
                },
                "Total": {"blanks": 0, "code": 1, "comments": 0, "reports": [], "children": {}, "inaccurate": False},
            }))

            proc = run_cmd(src, "--input", saved, "-o", "json")

        self.assertEqual(proc.returncode, 0, proc.stderr)
        data = json.loads(proc.stdout)
        self.assertEqual(data["Dockerfile"]["code"], 2)
        self.assertEqual(data["Makefile"]["comments"], 1)
        self.assertEqual(data["Python"]["code"], 1)
        self.assertEqual(data["Total"]["code"], 5)


if __name__ == "__main__":
    unittest.main()
