#!/bin/bash
set -e
cp src/tokei_clone.py executable
chmod +x executable
