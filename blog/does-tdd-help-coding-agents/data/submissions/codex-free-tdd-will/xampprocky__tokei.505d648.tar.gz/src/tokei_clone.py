#!/usr/bin/env python3
import argparse
import json
import os
import sys
from dataclasses import dataclass, field
from pathlib import Path

LANGS = {
    ".py": "Python",
    ".rs": "Rust",
    ".json": "JSON",
    ".c": "C",
    ".h": "C Header",
    ".cpp": "C++",
    ".cc": "C++",
    ".js": "JavaScript",
    ".ts": "TypeScript",
    ".html": "HTML",
    ".htm": "HTML",
    ".md": "Markdown",
    ".toml": "TOML",
    ".yaml": "YAML",
    ".yml": "YAML",
    ".sh": "Shell",
    ".bash": "BASH",
    ".go": "Go",
    ".java": "Java",
    ".rb": "Ruby",
    ".php": "PHP",
    ".css": "CSS",
    ".xml": "XML",
    ".jsx": "JSX",
    ".tsx": "TSX",
    ".rs.in": "Rust",
    ".txt": "Text",
    ".sql": "SQL",
    ".scala": "Scala",
    ".kt": "Kotlin",
    ".kts": "Kotlin",
    ".swift": "Swift",
    ".dart": "Dart",
    ".lua": "Lua",
    ".r": "R",
    ".vim": "Vim script",
    ".zig": "Zig",
}
NAME_LANGS = {
    "Dockerfile": "Dockerfile",
    "Containerfile": "Dockerfile",
    "Makefile": "Makefile",
    "Rakefile": "Ruby",
    "Gemfile": "Ruby",
    "CMakeLists.txt": "CMake",
}

LINE_COMMENTS = {
    "Python": ["#"],
    "Rust": ["//"],
    "C": ["//"],
    "C Header": ["//"],
    "C++": ["//"],
    "JavaScript": ["//"],
    "TypeScript": ["//"],
    "Go": ["//"],
    "Java": ["//"],
    "Shell": ["#"],
    "BASH": ["#"],
    "Ruby": ["#"],
    "PHP": ["//", "#"],
    "CSS": [],
    "Dockerfile": ["#"],
    "Makefile": ["#"],
    "CMake": ["#"],
    "Lua": ["--"],
    "SQL": ["--"],
    "R": ["#"],
    "Vim script": ["\""],
}
BLOCK_COMMENTS = {
    "Rust": [("/*", "*/", True)],
    "C": [("/*", "*/", False)],
    "C Header": [("/*", "*/", False)],
    "C++": [("/*", "*/", False)],
    "JavaScript": [("/*", "*/", False)],
    "TypeScript": [("/*", "*/", False)],
    "Go": [("/*", "*/", False)],
    "Java": [("/*", "*/", False)],
    "CSS": [("/*", "*/", False)],
    "HTML": [("<!--", "-->", False)],
    "XML": [("<!--", "-->", False)],
    "PHP": [("/*", "*/", False)],
    "SQL": [("/*", "*/", False)],
}

@dataclass
class Stats:
    blanks: int = 0
    code: int = 0
    comments: int = 0

    @property
    def lines(self):
        return self.blanks + self.code + self.comments

    def add(self, other):
        self.blanks += other.blanks
        self.code += other.code
        self.comments += other.comments

@dataclass
class Report:
    language: str
    path: str
    stats: Stats


def strip_strings(line):
    out = []
    quote = None
    esc = False
    for ch in line:
        if quote:
            if esc:
                esc = False
            elif ch == "\\":
                esc = True
            elif ch == quote:
                quote = None
            out.append(" ")
        else:
            if ch in ("'", '"'):
                quote = ch
                out.append(" ")
            else:
                out.append(ch)
    return "".join(out)


def split_code_comment(line, lang, in_block):
    original = line.rstrip("\n")
    if not original.strip():
        return False, False, in_block
    code = False
    comment = False
    i = 0
    blocks = BLOCK_COMMENTS.get(lang, [])
    while i < len(original):
        if in_block:
            comment = True
            end = in_block[1]
            j = original.find(end, i)
            if j < 0:
                return code, comment, in_block
            i = j + len(end)
            in_block = None
            continue
        ch = original[i]
        if ch in ("'", '"') and lang != "Python":
            q = ch; i += 1; esc = False
            while i < len(original):
                c = original[i]
                i += 1
                if esc:
                    esc = False
                elif c == "\\":
                    esc = True
                elif c == q:
                    break
            code = True
            continue
        found = False
        for start, end, nested in blocks:
            if original.startswith(start, i):
                comment = True
                j = original.find(end, i + len(start))
                if j < 0:
                    in_block = (start, end, nested)
                    return code, comment, in_block
                i = j + len(end)
                found = True
                break
        if found:
            continue
        for marker in LINE_COMMENTS.get(lang, []):
            if original.startswith(marker, i):
                comment = True
                return code, comment, in_block
        if not ch.isspace():
            code = True
        i += 1
    return code, comment, in_block


def count_file(path, lang):
    stats = Stats()
    try:
        text = Path(path).read_text(errors="ignore")
    except OSError:
        return stats
    in_block = None
    for line in text.splitlines():
        if not line.strip():
            stats.blanks += 1
            continue
        if lang in ("JSON",):
            stats.code += 1
            continue
        if lang == "Markdown":
            stats.comments += 1
            continue
        code, comment, in_block = split_code_comment(line, lang, in_block)
        if code:
            stats.code += 1
        elif comment:
            stats.comments += 1
        else:
            stats.code += 1
    return stats


def load_ignore_files(directory):
    patterns = []
    for name in (".tokeignore", ".ignore", ".gitignore"):
        p = Path(directory) / name
        if p.exists():
            try:
                for line in p.read_text(errors="ignore").splitlines():
                    line = line.strip()
                    if line and not line.startswith("#"):
                        patterns.append(line)
            except OSError:
                pass
    return patterns


def matches_pattern(path, pattern):
    import fnmatch
    name = Path(path).name
    rel = str(path)
    if pattern.endswith("/"):
        return any(part == pattern.rstrip("/") for part in Path(path).parts)
    return fnmatch.fnmatch(name, pattern) or fnmatch.fnmatch(rel, pattern)


def discover(paths, hidden=False, respect_ignores=True, excludes=None):
    files = []
    excludes = excludes or []
    for raw in paths or ["."]:
        p = Path(raw)
        if p.is_file():
            if not any(matches_pattern(p, pat) for pat in excludes):
                files.append(p)
        elif p.is_dir():
            for root, dirs, names in os.walk(p):
                local_patterns = load_ignore_files(root) if respect_ignores else []
                all_excludes = excludes + local_patterns
                dirs[:] = [
                    d for d in dirs
                    if (hidden or not d.startswith("."))
                    and not any(matches_pattern(Path(root) / d, pat) for pat in all_excludes)
                ]
                for name in names:
                    path = Path(root) / name
                    if (hidden or not name.startswith(".")) and not any(matches_pattern(path, pat) for pat in all_excludes):
                        files.append(path)
    return files


def language_for(path):
    p = Path(path)
    if p.name in NAME_LANGS:
        return NAME_LANGS[p.name]
    lower = p.name.lower()
    for ext, lang in sorted(LANGS.items(), key=lambda kv: len(kv[0]), reverse=True):
        if lower.endswith(ext):
            return lang
    return None


HELP_TEXT = """Count your code, quickly.
Support this project on GitHub Sponsors: https://github.com/sponsors/XAMPPRocky

Usage: executable [OPTIONS] [input]...

Arguments:
  [input]...  The path(s) to the file or directory to be counted. (default current directory)

Options:
  -c, --columns <columns>              Sets a strict column width of the output, only available for
                                       terminal output.
  -e, --exclude <exclude>              Ignore all files & directories matching the pattern.
  -f, --files                          Will print out statistics on individual files.
  -i, --input <file_input>             Gives statistics from a previous tokei run. Can be given a
                                       file path, or "stdin" to read from stdin.
      --hidden                         Count hidden files.
  -l, --languages                      Prints out supported languages and their extensions.
      --no-ignore                      Don't respect ignore files (.gitignore, .ignore, etc.). This
                                       implies --no-ignore-parent, --no-ignore-dot, and
                                       --no-ignore-vcs.
      --no-ignore-parent               Don't respect ignore files (.gitignore, .ignore, etc.) in
                                       parent directories.
      --no-ignore-dot                  Don't respect .ignore and .tokeignore files, including those
                                       in parent directories.
      --no-ignore-vcs                  Don't respect VCS ignore files (.gitignore, .hgignore, etc.)
                                       including those in parent directories.
  -o, --output <output>                Outputs Tokei in a specific format. Compile with additional
                                       features for more format support.
      --streaming <streaming>          prints the (language, path, lines, blanks, code, comments)
                                       records as simple lines or as Json for batch processing
                                       [possible values: simple, json]
  -s, --sort <sort>                    Sort languages based on column [possible values: files,
                                       lines, blanks, code, comments]
  -r, --rsort <rsort>                  Reverse sort languages based on column [possible values:
                                       files, lines, blanks, code, comments]
  -t, --types <types>                  Filters output by language type, separated by a comma. i.e.
                                       -t=Rust,Markdown
  -C, --compact                        Do not print statistics about embedded languages.
  -n, --num-format <num_format_style>  Format of printed numbers, i.e., plain (1234, default),
                                       commas (1,234), dots (1.234), or underscores (1_234). Cannot
                                       be used with --output. [possible values: commas, dots, plain,
                                       underscores]
  -v, --verbose...                     Set log output level:
                                                               1: to show unknown file extensions,
                                                               2: reserved for future debugging,
                                                               3: enable file level trace. Not
                                                               recommended on multiple files
  -h, --help                           Print help
  -V, --version                        Print version"""


def scan(paths, hidden=False, respect_ignores=True, excludes=None, types=None):
    reports = []
    wanted = None
    if types:
        wanted = {t.strip().lower() for t in types.split(",") if t.strip()}
    for p in discover(paths, hidden=hidden, respect_ignores=respect_ignores, excludes=excludes):
        lang = language_for(p)
        if not lang:
            continue
        if wanted and lang.lower() not in wanted:
            continue
        reports.append(Report(lang, str(p), count_file(p, lang)))
    return reports


def reports_from_json(path_or_stdin):
    try:
        if path_or_stdin == "stdin":
            text = sys.stdin.read()
        else:
            text = Path(path_or_stdin).read_text(errors="ignore")
        data = json.loads(text)
    except Exception:
        return []
    reports = []
    for lang, value in data.items():
        if lang == "Total" or not isinstance(value, dict):
            continue
        for item in value.get("reports", []):
            st = item.get("stats", {})
            reports.append(Report(lang, item.get("name", ""), Stats(int(st.get("blanks", 0)), int(st.get("code", 0)), int(st.get("comments", 0)))))
        if not value.get("reports") and any(k in value for k in ("blanks", "code", "comments")):
            reports.append(Report(lang, "", Stats(int(value.get("blanks", 0)), int(value.get("code", 0)), int(value.get("comments", 0)))))
    return reports


def json_output(reports):
    grouped = {}
    total = Stats()
    for r in sorted(reports, key=lambda x: (x.language, x.path)):
        grouped.setdefault(r.language, []).append(r)
        total.add(r.stats)
    obj = {}
    for lang in sorted(grouped):
        st = Stats()
        reps = []
        for r in grouped[lang]:
            st.add(r.stats)
            reps.append({"stats": {"blanks": r.stats.blanks, "code": r.stats.code, "comments": r.stats.comments, "blobs": {}}, "name": r.path})
        obj[lang] = {"blanks": st.blanks, "code": st.code, "comments": st.comments, "reports": reps, "children": {}, "inaccurate": False}
    children = {lang: obj[lang]["reports"] for lang in sorted(grouped)}
    obj["Total"] = {"blanks": total.blanks, "code": total.code, "comments": total.comments, "reports": [], "children": children, "inaccurate": False}
    return json.dumps(obj, separators=(",", ":"))


def grouped_stats(reports):
    grouped = {}
    for r in reports:
        grouped.setdefault(r.language, []).append(r)
    return grouped


def render_table(reports, files=False, sort=None, reverse=False, num_format=str):
    grouped = grouped_stats(reports)
    totals = Stats()
    lang_rows = []
    for lang, reps in grouped.items():
        st = Stats()
        for r in reps:
            st.add(r.stats)
        totals.add(st)
        lang_rows.append((lang, len(reps), st))
    key_map = {
        "files": lambda row: row[1],
        "lines": lambda row: row[2].lines,
        "blanks": lambda row: row[2].blanks,
        "code": lambda row: row[2].code,
        "comments": lambda row: row[2].comments,
    }
    if sort in key_map:
        lang_rows.sort(key=key_map[sort], reverse=not reverse)
    else:
        lang_rows.sort(key=lambda row: row[0].lower(), reverse=reverse)
    width = 81
    sep = "━" * width
    thin = "─" * width
    out = [sep, f" {'Language':<20}{'Files':>8}{'Lines':>13}{'Code':>13}{'Comments':>13}{'Blanks':>13}", sep]
    for lang, nfiles, st in lang_rows:
        out.append(f" {lang:<20}{num_format(nfiles):>8}{num_format(st.lines):>13}{num_format(st.code):>13}{num_format(st.comments):>13}{num_format(st.blanks):>13}")
        if files:
            out.append(thin)
            for r in sorted(grouped[lang], key=lambda x: x.path):
                out.append(f" {r.path:<28}{num_format(r.stats.lines):>13}{num_format(r.stats.code):>13}{num_format(r.stats.comments):>13}{num_format(r.stats.blanks):>13}")
            out.append(thin)
    out.append(sep)
    out.append(f" {'Total':<20}{num_format(len(reports)):>8}{num_format(totals.lines):>13}{num_format(totals.code):>13}{num_format(totals.comments):>13}{num_format(totals.blanks):>13}")
    out.append(sep)
    return "\n".join(out)


def streaming_output(reports, style):
    rows = []
    ordered = sorted(reports, key=lambda r: (r.language, r.path))
    if style == "json":
        for r in ordered:
            rows.append(json.dumps({
                "language": r.language,
                "stats": {
                    "name": r.path,
                    "stats": {"blanks": r.stats.blanks, "blobs": {}, "code": r.stats.code, "comments": r.stats.comments},
                },
            }, separators=(",", ":")))
    else:
        rows.append("# language                                        path                                          lines         code       comments      blanks   ")
        rows.append("########## ################################################################################ ############ ############ ############ ############")
        for r in ordered:
            rows.append(f"{r.language:>10} {r.path:<80} {r.stats.lines:>12} {r.stats.code:>12} {r.stats.comments:>12} {r.stats.blanks:>12}")
    return "\n".join(rows)


def main(argv=None):
    argv = list(sys.argv[1:] if argv is None else argv)
    if "-h" in argv or "--help" in argv:
        print(HELP_TEXT)
        return 0
    parser = argparse.ArgumentParser(prog="executable", add_help=False)
    parser.add_argument("input", nargs="*")
    parser.add_argument("-o", "--output")
    parser.add_argument("-f", "--files", action="store_true")
    parser.add_argument("-l", "--languages", action="store_true")
    parser.add_argument("-V", "--version", action="store_true")
    parser.add_argument("-t", "--types")
    parser.add_argument("-i", "--input", dest="file_input")
    parser.add_argument("-e", "--exclude", action="append", default=[])
    parser.add_argument("--hidden", action="store_true")
    parser.add_argument("--no-ignore", action="store_true")
    parser.add_argument("--no-ignore-dot", action="store_true")
    parser.add_argument("--streaming", choices=["simple", "json"])
    parser.add_argument("-s", "--sort", choices=["files", "lines", "blanks", "code", "comments"])
    parser.add_argument("-r", "--rsort", choices=["files", "lines", "blanks", "code", "comments"])
    parser.add_argument("-n", "--num-format", choices=["commas", "dots", "plain", "underscores"], default="plain")
    args, _ = parser.parse_known_args(argv)
    if args.version:
        print("tokei 14.0.0 compiled with serialization support: json")
        return 0
    if args.languages:
        print(" Language                              Extensions")
        for ext, lang in sorted(LANGS.items(), key=lambda kv: kv[1]):
            print(f" {lang:<36} {ext[1:]}")
        return 0
    if args.output and args.output != "json":
        print(f"error: invalid value '{args.output}' for '--output <output>': This version of tokei was compiled without any '{args.output}' serialization support, to enable serialization, reinstall tokei with the features flag.", file=sys.stderr)
        return 2
    reports = []
    if args.file_input:
        reports.extend(reports_from_json(args.file_input))
    reports.extend(scan(args.input, hidden=args.hidden, respect_ignores=not (args.no_ignore or args.no_ignore_dot), excludes=args.exclude, types=args.types))
    if args.output == "json":
        print(json_output(reports), end="")
    elif args.streaming:
        print(streaming_output(reports, args.streaming))
    else:
        def fmt(n):
            s = str(n)
            if args.num_format == "commas":
                return f"{n:,}"
            if args.num_format == "underscores":
                return f"{n:_}"
            if args.num_format == "dots":
                return f"{n:,}".replace(",", ".")
            return s
        print(render_table(reports, files=args.files, sort=args.sort or args.rsort, reverse=bool(args.rsort), num_format=fmt))
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
