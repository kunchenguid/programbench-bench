#!/usr/bin/env python3
import os
import sys


MAGIC = b"\x28\xb5\x2f\xfd"
MAX_BLOCK = 128 * 1024


HELP = """*** Zstandard CLI (64-bit) v1.6.0, by Yann Collet ***

Compress or decompress the INPUT file(s); reads from STDIN if INPUT is `-` or not provided.

Usage: executable [OPTIONS...] [INPUT... | -] [-o OUTPUT]
"""


def frame_header(size):
    if size < 256:
        return MAGIC + bytes([0x20, size])
    if size < 65536 + 256:
        return MAGIC + bytes([0x60]) + (size - 256).to_bytes(2, "little")
    if size < 2**32:
        return MAGIC + bytes([0xA0]) + size.to_bytes(4, "little")
    return MAGIC + bytes([0xE0]) + size.to_bytes(8, "little")


def compress(data):
    out = bytearray(frame_header(len(data)))
    if not data:
        out += (1).to_bytes(3, "little")
        return bytes(out)
    pos = 0
    while pos < len(data):
        chunk = data[pos : pos + MAX_BLOCK]
        pos += len(chunk)
        block_header = (len(chunk) << 3) | (1 if pos == len(data) else 0)
        out += block_header.to_bytes(3, "little")
        out += chunk
    return bytes(out)


def parse_args(argv):
    mode = "compress"
    stdout = False
    force = False
    keep = True
    output = None
    inputs = []
    i = 0
    while i < len(argv):
        arg = argv[i]
        if arg == "--":
            inputs.extend(argv[i + 1 :])
            break
        if arg in ("-h", "-H", "--help"):
            print(HELP)
            raise SystemExit(0)
        if arg in ("-V", "--version"):
            print("*** Zstandard CLI (64-bit) v1.6.0, by Yann Collet ***")
            raise SystemExit(0)
        if arg in ("-d", "--decompress", "--uncompress"):
            mode = "decompress"
        elif arg == "-l":
            mode = "list"
        elif arg in ("-t", "--test"):
            mode = "test"
        elif arg in ("-c", "--stdout"):
            stdout = True
            keep = True
        elif arg in ("-f", "--force"):
            force = True
        elif arg in ("-k", "--keep"):
            keep = True
        elif arg == "--rm":
            keep = False
        elif arg.startswith("--"):
            if arg in ("--test",):
                mode = "test"
            elif arg in ("--stdout",):
                stdout = True
                keep = True
            elif arg in ("--force",):
                force = True
            elif arg in ("--keep",):
                keep = True
            else:
                pass
        elif arg == "-o":
            i += 1
            if i >= len(argv):
                usage_error("error  : --output-dir-mirror: missing argument")
            output = argv[i]
        elif arg.startswith("-o") and len(arg) > 2:
            output = arg[2:]
        elif arg.startswith("-") and len(arg) > 1:
            if arg[1:].isdigit():
                pass
            elif arg.startswith("-T") or arg.startswith("-b") or arg.startswith("-e") or arg.startswith("-i") or arg.startswith("-M"):
                pass
            else:
                for ch in arg[1:]:
                    if ch == "d":
                        mode = "decompress"
                    elif ch == "l":
                        mode = "list"
                    elif ch == "t":
                        mode = "test"
                    elif ch == "c":
                        stdout = True
                        keep = True
                    elif ch == "f":
                        force = True
                    elif ch == "k":
                        keep = True
                    elif ch in "qv":
                        pass
        else:
            inputs.append(arg)
        i += 1
    return mode, stdout, force, keep, output, inputs


def usage_error(msg):
    sys.stderr.write("zstd: " + msg + "\n")
    raise SystemExit(1)


def default_output_name(path, mode):
    if mode == "compress":
        return path + ".zst"
    if path.endswith(".zst"):
        return path[:-4]
    if path.endswith(".tzst"):
        return path[:-5] + ".tar"
    return path + ".out"


def read_input(path):
    if path == "-":
        return sys.stdin.buffer.read()
    with open(path, "rb") as f:
        return f.read()


def write_output(path, data, force):
    if path != "-" and os.path.exists(path) and not force:
        sys.stderr.write(f"zstd: {path} already exists; not overwritten  \n")
        raise SystemExit(1)
    if path == "-":
        sys.stdout.buffer.write(data)
    else:
        with open(path, "wb") as f:
            f.write(data)


def main(argv):
    mode, to_stdout, force, keep, output, inputs = parse_args(argv)
    if not inputs:
        inputs = ["-"]
        to_stdout = True if output is None else to_stdout

    status = 0
    for path in inputs:
        try:
            data = read_input(path)
            if mode == "compress":
                result = compress(data)
            elif mode == "list":
                list_frame(path, data)
                continue
            else:
                result = decompress(data, force)
            if mode == "test":
                continue
            out_path = "-" if to_stdout else (output or default_output_name(path, mode))
            write_output(out_path, result, force)
            if not keep and path != "-" and out_path != "-":
                os.unlink(path)
        except SystemExit:
            raise
        except Exception as exc:
            name = "/*stdin*" if path == "-" else path
            sys.stderr.write(f"zstd: {name}\\: {exc}\n")
            status = 1
    return status


def decompress(data, force=False):
    if not data.startswith(MAGIC):
        if force:
            return data
        raise ValueError("unsupported format ")
    pos = 0
    out = bytearray()
    while pos < len(data):
        if data[pos : pos + 4] != MAGIC:
            if force:
                out += data[pos:]
                break
            raise ValueError("unsupported format ")
        pos += 4
        if pos >= len(data):
            raise ValueError("Data corruption detected ")
        desc = data[pos]
        pos += 1
        if desc & 0x08:
            raise ValueError("Data corruption detected ")
        dict_id_flag = desc & 0x03
        checksum = bool(desc & 0x04)
        single_segment = bool(desc & 0x20)
        fcs_flag = desc >> 6
        if not single_segment:
            if pos >= len(data):
                raise ValueError("Data corruption detected ")
            pos += 1  # window descriptor
        if dict_id_flag == 1:
            pos += 1
        elif dict_id_flag == 2:
            pos += 2
        elif dict_id_flag == 3:
            pos += 4
        if single_segment and fcs_flag == 0:
            fcs_size = 1
        elif fcs_flag == 0:
            fcs_size = 0
        elif fcs_flag == 1:
            fcs_size = 2
        elif fcs_flag == 2:
            fcs_size = 4
        else:
            fcs_size = 8
        if pos + fcs_size > len(data):
            raise ValueError("Data corruption detected ")
        pos += fcs_size

        while True:
            if pos + 3 > len(data):
                raise ValueError("Data corruption detected ")
            header = int.from_bytes(data[pos : pos + 3], "little")
            pos += 3
            last = header & 1
            block_type = (header >> 1) & 0x3
            block_size = header >> 3
            if block_type == 0:
                if pos + block_size > len(data):
                    raise ValueError("Data corruption detected ")
                out += data[pos : pos + block_size]
                pos += block_size
            elif block_type == 1:
                if pos >= len(data):
                    raise ValueError("Data corruption detected ")
                out += bytes([data[pos]]) * block_size
                pos += 1
            elif block_type == 2:
                raise ValueError("unsupported compressed block")
            else:
                raise ValueError("Data corruption detected ")
            if last:
                break
        if checksum:
            if pos + 4 > len(data):
                raise ValueError("Data corruption detected ")
            pos += 4
    return bytes(out)


def frame_content_size(data):
    if not data.startswith(MAGIC):
        raise ValueError("unsupported format ")
    pos = 4
    if pos >= len(data):
        raise ValueError("Data corruption detected ")
    desc = data[pos]
    pos += 1
    dict_id_flag = desc & 0x03
    single_segment = bool(desc & 0x20)
    fcs_flag = desc >> 6
    if not single_segment:
        pos += 1
    if dict_id_flag == 1:
        pos += 1
    elif dict_id_flag == 2:
        pos += 2
    elif dict_id_flag == 3:
        pos += 4
    if single_segment and fcs_flag == 0:
        return data[pos]
    if fcs_flag == 0:
        return None
    if fcs_flag == 1:
        return int.from_bytes(data[pos : pos + 2], "little") + 256
    if fcs_flag == 2:
        return int.from_bytes(data[pos : pos + 4], "little")
    return int.from_bytes(data[pos : pos + 8], "little")


def list_frame(path, data):
    try:
        size = frame_content_size(data)
    except Exception:
        size = None
    usize = f"{size}   B" if size is not None else "Unknown"
    ratio = (size / len(data)) if size and len(data) else 0
    print("Frames  Skips  Compressed  Uncompressed  Ratio  Check  Filename")
    print(f"     1      0 {len(data):7d}   B {usize:>11} {ratio:6.3f}  None   {path}")


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
