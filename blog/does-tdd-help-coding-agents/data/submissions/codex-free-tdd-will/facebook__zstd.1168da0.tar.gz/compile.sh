#!/bin/bash
set -e
rm -f executable
cp zstdlite.py executable
chmod +x executable
