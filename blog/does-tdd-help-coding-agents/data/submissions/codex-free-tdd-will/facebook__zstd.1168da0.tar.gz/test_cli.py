import os
import subprocess
import tempfile
import unittest


ROOT = os.path.dirname(__file__)
REF = "/workspace/executable"


class CliBehaviorTests(unittest.TestCase):
    def build(self):
        subprocess.run(["bash", "compile.sh"], cwd=ROOT, check=True)

    def run_new(self, args, data=b""):
        return subprocess.run(
            [os.path.join(ROOT, "executable")] + args,
            input=data,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            check=False,
        )

    def run_ref(self, args, data=b""):
        return subprocess.run(
            [REF] + args,
            input=data,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            check=False,
        )

    def run_new_cwd(self, cwd, args, data=b""):
        return subprocess.run(
            [os.path.join(ROOT, "executable")] + args,
            cwd=cwd,
            input=data,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            check=False,
        )

    def test_compressed_stdout_is_decodable_by_reference(self):
        self.build()
        payload = b"hello zstd\n" * 5
        produced = self.run_new(["-q", "-c"], payload)
        self.assertEqual(produced.returncode, 0, produced.stderr)

        decoded = self.run_ref(["-q", "-d", "-c"], produced.stdout)
        self.assertEqual(decoded.returncode, 0, decoded.stderr)
        self.assertEqual(decoded.stdout, payload)

    def test_decompresses_its_own_stdout_frame(self):
        self.build()
        payload = (b"stored frame data" * 10000) + b"\n"
        produced = self.run_new(["-q", "-c"], payload)
        self.assertEqual(produced.returncode, 0, produced.stderr)

        decoded = self.run_new(["-q", "-d", "-c"], produced.stdout)
        self.assertEqual(decoded.returncode, 0, decoded.stderr)
        self.assertEqual(decoded.stdout, payload)

    def test_default_file_names_keep_inputs(self):
        self.build()
        with tempfile.TemporaryDirectory() as tmp:
            src = os.path.join(tmp, "sample")
            with open(src, "wb") as f:
                f.write(b"file payload")

            compressed = self.run_new_cwd(tmp, ["-q", "sample"])
            self.assertEqual(compressed.returncode, 0, compressed.stderr)
            self.assertTrue(os.path.exists(src))
            self.assertTrue(os.path.exists(src + ".zst"))

            os.unlink(src)
            decompressed = self.run_new_cwd(tmp, ["-q", "-d", "sample.zst"])
            self.assertEqual(decompressed.returncode, 0, decompressed.stderr)
            with open(src, "rb") as f:
                self.assertEqual(f.read(), b"file payload")
            self.assertTrue(os.path.exists(src + ".zst"))

    def test_combined_decompress_to_stdout_option(self):
        self.build()
        payload = b"option cluster"
        produced = self.run_new(["-q", "-c"], payload)
        self.assertEqual(produced.returncode, 0, produced.stderr)

        decoded = self.run_new(["-dc"], produced.stdout)
        self.assertEqual(decoded.returncode, 0, decoded.stderr)
        self.assertEqual(decoded.stdout, payload)

    def test_list_prints_file_summary(self):
        self.build()
        with tempfile.TemporaryDirectory() as tmp:
            with open(os.path.join(tmp, "thing"), "wb") as f:
                f.write(b"abcdef")
            self.assertEqual(self.run_new_cwd(tmp, ["-q", "thing"]).returncode, 0)

            listed = self.run_new_cwd(tmp, ["-l", "thing.zst"])
            self.assertEqual(listed.returncode, 0, listed.stderr)
            text = listed.stdout.decode()
            self.assertIn("Frames", text)
            self.assertIn("Uncompressed", text)
            self.assertIn("thing.zst", text)
            self.assertIn("6", text)

    def test_output_option_and_rm_remove_source_after_success(self):
        self.build()
        with tempfile.TemporaryDirectory() as tmp:
            src = os.path.join(tmp, "source.txt")
            with open(src, "wb") as f:
                f.write(b"remove me")

            compressed = self.run_new_cwd(tmp, ["-q", "--rm", "-o", "custom.zst", "source.txt"])
            self.assertEqual(compressed.returncode, 0, compressed.stderr)
            self.assertFalse(os.path.exists(src))
            self.assertTrue(os.path.exists(os.path.join(tmp, "custom.zst")))

            decompressed = self.run_new_cwd(tmp, ["-q", "-d", "-o", "restored.txt", "custom.zst"])
            self.assertEqual(decompressed.returncode, 0, decompressed.stderr)
            with open(os.path.join(tmp, "restored.txt"), "rb") as f:
                self.assertEqual(f.read(), b"remove me")

    def test_ignored_long_options_do_not_enable_stdout(self):
        self.build()
        with tempfile.TemporaryDirectory() as tmp:
            with open(os.path.join(tmp, "plain"), "wb") as f:
                f.write(b"long option")

            result = self.run_new_cwd(tmp, ["-q", "--no-check", "plain"])
            self.assertEqual(result.returncode, 0, result.stderr)
            self.assertEqual(result.stdout, b"")
            self.assertTrue(os.path.exists(os.path.join(tmp, "plain.zst")))


if __name__ == "__main__":
    unittest.main()
