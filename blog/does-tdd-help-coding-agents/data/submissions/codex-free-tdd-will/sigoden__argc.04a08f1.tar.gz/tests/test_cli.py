#!/usr/bin/env python3
import os
import subprocess


ROOT = os.path.dirname(os.path.dirname(__file__))


def run(args):
    return subprocess.run(args, cwd=ROOT, text=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)


def test_demo_download_run():
    subprocess.run(["bash", "compile.sh"], cwd=ROOT, check=True)
    r = run(["./executable", "--argc-run", "fixtures/demo.sh", "download", "-f", "-t", "3", "src", "dst"])
    assert r.returncode == 0
    assert r.stdout == """cmd:                      download
flag:   --force           1
option: --tries           3
arg:    source            src
arg:    target            dst
"""


def test_demo_root_help_includes_description():
    subprocess.run(["bash", "compile.sh"], cwd=ROOT, check=True)
    r = run(["./executable", "--argc-run", "fixtures/demo.sh", "--help"])
    assert r.returncode == 0
    assert r.stdout.startswith("A demo cli\n\nUSAGE: demo <COMMAND>\n")


def test_root_main_is_invoked():
    subprocess.run(["bash", "compile.sh"], cwd=ROOT, check=True)
    r = run(["./executable", "--argc-run", "fixtures/main.sh", "abc"])
    assert r.returncode == 0
    assert r.stdout == "main abc\n"


def test_terminal_option_consumes_remaining_args():
    subprocess.run(["bash", "compile.sh"], cwd=ROOT, check=True)
    r = run(["./executable", "--argc-run", "fixtures/terminal.sh", "--rest", "a", "b"])
    assert r.returncode == 0
    assert "argc_rest=([0]=\"a\" [1]=\"b\")\n" in r.stdout
    assert "argc__positionals=()\n" in r.stdout


def test_nested_command_function_is_selected():
    subprocess.run(["bash", "compile.sh"], cwd=ROOT, check=True)
    r = run(["./executable", "--argc-eval", "fixtures/nested.sh", "foo", "bar"])
    assert r.returncode == 0
    assert "argc__fn=foo::bar\n" in r.stdout
    assert r.stdout.rstrip().endswith("foo::bar")


if __name__ == "__main__":
    test_demo_download_run()
    test_demo_root_help_includes_description()
    test_root_main_is_invoked()
    test_terminal_option_consumes_remaining_args()
    test_nested_command_function_is_selected()
