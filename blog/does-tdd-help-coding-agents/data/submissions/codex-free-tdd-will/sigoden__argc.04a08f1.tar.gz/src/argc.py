#!/usr/bin/env python3
import base64
import json
import os
import re
import shutil
import subprocess
import sys
import tempfile


VERSION = "argc 1.23.0"


class Param:
    def __init__(self, kind, names, desc=""):
        self.kind = kind
        self.names = names
        self.desc = desc
        self.short = None
        self.long = None
        self.id = None
        self.flag = kind == "flag"
        self.required = False
        self.multiple = False
        self.plus = False
        self.delimiter = None
        self.terminated = False
        self.default = None
        self.choice = None
        self.skip_choice_check = False
        self.notations = []
        self.num_args = [0, 0] if self.flag else [1, 1]
        self.env = None
        self.prefixed = False
        self.assigned = False


class Command:
    def __init__(self, name="", fn=None):
        self.name = name
        self.fn = fn
        self.describe = ""
        self.long = []
        self.aliases = []
        self.options = []
        self.args = []
        self.envs = []
        self.subcommands = []
        self.version = None
        self.default_subcommand = False
        self.dotenv = False


def shell_quote(s):
    if s == "":
        return "''"
    if re.match(r"^[A-Za-z0-9_@%+=:,./-]+$", s):
        return s
    return "'" + s.replace("'", "'\\''") + "'"


def ident(s):
    s = s.strip("<>[]").lower().replace("-", "_")
    return re.sub(r"[^a-z0-9_]", "_", s).strip("_")


def cmd_name_from_fn(fn):
    return fn.replace("::", " ").replace("_", "-")


def parse_spec_token(tok, is_option):
    env = None
    if "$" in tok and not tok.startswith("$"):
        pass
    pfx = tok
    default = None
    choice = None
    skip = False
    if "[" in pfx and pfx.endswith("]"):
        pfx, ch = pfx.split("[", 1)
        ch = ch[:-1]
        if ch.startswith("?"):
            skip = True
            ch = ch[1:]
        if ch.startswith("="):
            default = ch[1:].split("|")[0]
            ch = ch[1:]
        choice = ch
    m = re.search(r"=(`[^`]+`|[^,~!*+\[]+)$", pfx)
    if m:
        default = m.group(1)
        pfx = pfx[: m.start()]
    delimiter = "," if pfx.endswith(",") else None
    if delimiter:
        pfx = pfx[:-1]
    terminated = pfx.endswith("~")
    if terminated:
        pfx = pfx[:-1]
    required = pfx.endswith("!") or pfx.endswith("+")
    plus = pfx.endswith("+")
    multiple = pfx.endswith("*") or pfx.endswith("+")
    if pfx.endswith(("!", "*", "+")):
        pfx = pfx[:-1]
    return pfx, required, multiple, plus, delimiter, terminated, default, choice, skip


def parse_param(tag, body):
    parts = body.split()
    names = []
    i = 0
    while i < len(parts) and (parts[i].startswith("-") or parts[i].startswith("+")):
        names.append(parts[i])
        i += 1
    if tag == "arg":
        names = [parts[0]]
        i = 1
    notations = []
    while i < len(parts) and parts[i].startswith("<") and parts[i].endswith(">"):
        notations.append(parts[i][1:-1])
        i += 1
    env = None
    if i < len(parts) and parts[i].startswith("$"):
        env = parts[i]
        i += 1
    desc = " ".join(parts[i:])
    first, required, multiple, plus, delim, term, default, choice, skip = parse_spec_token(names[-1], tag != "arg")
    clean_names = names[:]
    clean_names[-1] = first
    p = Param(tag, clean_names, desc)
    p.required = required
    p.multiple = multiple
    p.plus = plus
    p.delimiter = delim
    p.terminated = term
    p.default = default
    p.choice = choice
    p.skip_choice_check = skip
    p.env = env
    if tag == "arg":
        p.id = ident(first)
        p.notations = [notations[0] if notations else p.id.upper()]
    else:
        for n in clean_names:
            if n.startswith("--") or (n.startswith("+") and len(n) > 2):
                p.long = n
            elif n.startswith("-") or n.startswith("+"):
                p.short = n
        if p.long is None and clean_names:
            p.long = clean_names[-1] if len(clean_names[-1]) > 2 else None
        base = p.long or clean_names[-1]
        p.id = ident(base)
        p.notations = notations or ([] if p.flag else [p.id.upper()])
        if not p.flag:
            mins = 1
            maxs = 1
            if p.notations:
                last = p.notations[-1]
                if last.endswith("*"):
                    mins, maxs = 0, 999999
                elif last.endswith("+"):
                    mins, maxs = 1, 999999
                elif last.endswith("?"):
                    mins, maxs = 0, 1
                else:
                    mins = maxs = len(p.notations)
            if p.multiple:
                maxs = 999999
                if not p.required:
                    mins = 0
            p.num_args = [mins, maxs]
    return p


def parse_file(path):
    with open(path, "r", encoding="utf-8", errors="replace") as f:
        lines = f.readlines()
    root = Command(os.path.splitext(os.path.basename(path))[0])
    pending = []
    current_target = root
    metas = []
    for line in lines:
        cm = re.match(r"^\s*#\s?(.*)$", line)
        fm = re.match(r"^\s*([A-Za-z_][\w:]*)\s*(?:\(\s*\)|\(\s*\)\s*)\s*\{", line)
        if cm:
            text = cm.group(1)
            if text.startswith("@"):
                pending.append(text)
            elif pending and text.strip():
                pending.append("TEXT " + text.strip())
            continue
        if not line.strip() and pending:
            pending.append("__BLANK__")
            continue
        if fm:
            fn = fm.group(1)
            is_cmd = any(x.startswith("@cmd") for x in pending)
            target = Command(cmd_name_from_fn(fn), fn) if is_cmd else root
            if is_cmd and "__BLANK__" in pending:
                idx = len(pending) - 1 - pending[::-1].index("__BLANK__")
                before = pending[:idx]
                after = pending[idx + 1 :]
                if before and any(x.startswith("@describe") or x.startswith("@meta") for x in before):
                    apply_tags(root, before)
                    pending = after
            apply_tags(target, pending)
            if is_cmd:
                root.subcommands.append(target)
            elif fn == "main":
                root.fn = "main"
                apply_tags(root, pending)
            current_target = target
            pending = []
            continue
        if "eval " in line and "argc --argc-eval" in line:
            apply_tags(root, pending)
            pending = []
        elif line.strip() and not line.strip().startswith("#"):
            pending = []
    add_builtin_options(root)
    for c in root.subcommands:
        add_builtin_options(c)
    return root


def apply_tags(cmd, tags):
    last = None
    for raw in tags:
        if raw.startswith("TEXT "):
            if last == "describe":
                cmd.long.append(raw[5:])
            continue
        if not raw.startswith("@"):
            continue
        parts = raw[1:].split(None, 1)
        tag = parts[0]
        body = parts[1] if len(parts) > 1 else ""
        last = tag
        if tag == "describe":
            cmd.describe = body
        elif tag == "cmd":
            if body:
                cmd.describe = body
        elif tag == "alias":
            cmd.aliases.extend(body.split())
        elif tag == "meta":
            m = body.split(None, 1)
            if m and m[0] == "version" and len(m) > 1:
                cmd.version = m[1]
            if body.strip() == "default-subcommand":
                cmd.default_subcommand = True
            if body.strip() == "dotenv":
                cmd.dotenv = True
        elif tag in ("flag", "option", "arg"):
            cmd.options.append(parse_param(tag, body)) if tag != "arg" else cmd.args.append(parse_param(tag, body))
        elif tag == "env":
            p = parse_param("arg", body)
            p.id = body.split()[0].rstrip("!*+~").split("[", 1)[0].split("=", 1)[0]
            cmd.envs.append(p)


def add_builtin_options(cmd):
    has_help = any(o.long in ("--help", "-help") for o in cmd.options)
    if not has_help:
        h = Param("flag", ["-h", "--help"], "Print help" if cmd.fn else "")
        h.short = "-h"
        h.long = "--help"
        h.id = "help"
        cmd.options.append(h)
    if not cmd.fn:
        v = Param("flag", ["-V", "--version"], "Print version" if cmd.version else "")
        v.short = "-V"
        v.long = "--version"
        v.id = "version"
        if not any(o.long == "--version" for o in cmd.options):
            cmd.options.append(v)


def find_cmd(root, argv):
    if argv:
        best = None
        best_len = 0
        for c in root.subcommands:
            names = [c.name] + c.aliases
            for nm in names:
                toks = nm.split()
                if argv[: len(toks)] == toks and len(toks) > best_len:
                    best = c
                    best_len = len(toks)
        if best:
            return best, argv[best_len:], argv[:best_len]
    if root.subcommands:
        for c in root.subcommands:
            if c.default_subcommand:
                return c, argv, []
    return root, argv, []


def option_map(cmd):
    m = {}
    for o in cmd.options:
        for n in [o.short, o.long] + o.names:
            if n:
                m[n] = o
    return m


def parse_args(root, argv):
    cmd, rest, used_cmd = find_cmd(root, argv)
    vals = {}
    positionals = []
    om = option_map(cmd)
    i = 0
    while i < len(rest):
        a = rest[i]
        if a == "--":
            positionals.extend(rest[i + 1 :])
            break
        name, eq, eqval = a.partition("=")
        opt = om.get(name)
        if opt and (a == name or eq):
            if opt.flag:
                vals[opt.id] = str(int(vals.get(opt.id, "0") or "0") + 1) if opt.multiple else "1"
            else:
                got = []
                if opt.terminated:
                    if eq:
                        got.append(eqval)
                    got.extend(rest[i + 1 :])
                    vals[opt.id] = got
                    break
                need = max(1, opt.num_args[0])
                if eq:
                    got.append(eqval)
                while len(got) < need and i + 1 < len(rest):
                    i += 1
                    got.append(rest[i])
                if len(got) < need or any(x == "" for x in got[:need]):
                    return cmd, vals, positionals, f"error: a value is required for '{opt.long or opt.short} <{(opt.notations or [opt.id.upper()])[0]}>'", 1
                val = " ".join(got)
                if opt.delimiter:
                    vals.setdefault(opt.id, []).extend([x for x in val.split(opt.delimiter) if x != ""])
                elif opt.multiple:
                    vals.setdefault(opt.id, []).append(val)
                else:
                    vals[opt.id] = val
            i += 1
            continue
        if a.startswith("-") and len(a) > 2 and not a.startswith("--"):
            consumed = False
            for ch in a[1:]:
                opt = om.get("-" + ch)
                if not opt or not opt.flag:
                    consumed = False
                    break
                vals[opt.id] = "1"
                consumed = True
            if consumed:
                i += 1
                continue
        positionals.append(a)
        i += 1
    for o in cmd.options:
        bind_env = bound_env_name(o)
        if bind_env and bind_env in os.environ and o.id not in vals:
            vals[o.id] = os.environ[bind_env]
        if o.default is not None and o.id not in vals:
            vals[o.id] = eval_default(o.default)
    pos_i = 0
    for p in cmd.args:
        if p.multiple or p.terminated:
            vals[p.id] = positionals[pos_i:]
            pos_i = len(positionals)
            if p.required and not vals[p.id]:
                return cmd, vals, positionals, f"error: the following required arguments were not provided:\n  <{p.notations[0]}>", 1
        elif pos_i < len(positionals):
            vals[p.id] = positionals[pos_i]
            pos_i += 1
        elif p.default is not None:
            vals[p.id] = eval_default(p.default)
        elif p.required:
            return cmd, vals, positionals, f"error: the following required arguments were not provided:\n  <{p.notations[0]}>", 1
    for o in cmd.options:
        if o.required and o.id not in vals:
            return cmd, vals, positionals, f"error: the following required arguments were not provided:\n  --{o.id} <{(o.notations or [o.id.upper()])[0]}>", 1
        if o.id in vals and o.num_args[0] > 1:
            count = len(vals[o.id]) if isinstance(vals[o.id], list) else 1
            if count < o.num_args[0]:
                return cmd, vals, positionals, f"error: a value is required for '{o.long or o.short} <{(o.notations or [o.id.upper()])[0]}>'", 1
    for p in cmd.args:
        bind_env = bound_env_name(p)
        if bind_env and bind_env in os.environ and p.id not in vals:
            vals[p.id] = os.environ[bind_env]
        if p.choice and p.id in vals and not p.skip_choice_check:
            bad = check_choice(vals[p.id], p.choice)
            if bad:
                return cmd, vals, positionals, f"error: invalid value '{bad}' for '<{p.notations[0]}>'", 1
    for o in cmd.options:
        if o.choice and o.id in vals and not o.skip_choice_check:
            bad = check_choice(vals[o.id], o.choice)
            if bad:
                return cmd, vals, positionals, f"error: invalid value '{bad}' for '{o.long or o.short} <{(o.notations or [o.id.upper()])[0]}>'", 1
    return cmd, vals, positionals, None, 0


def bound_env_name(p):
    if not p.env:
        return None
    if p.env == "$$":
        return p.id.upper()
    if p.env.startswith("$"):
        return p.env[1:]
    return None


def env_assignments(root, cmd):
    load_dotenv()
    assigns = []
    for e in root.envs + (cmd.envs if cmd is not root else []):
        name = e.id
        val = os.environ.get(name)
        if (val is None or val == "") and e.default is not None:
            val = eval_default(e.default)
        if (val is None or val == "") and e.required:
            return assigns, f"error: the following required environment variables were not provided:\n  {name}", 1
        if val is not None and e.choice and not e.skip_choice_check:
            bad = check_choice(val, e.choice)
            if bad:
                return assigns, f"error: invalid value '{bad}' for '{name}'", 1
        if val is not None:
            assigns.append(f"export {name}={shell_quote(val)}")
    return assigns, None, 0


def load_dotenv():
    try:
        with open(".env", "r") as f:
            for line in f:
                line = line.strip()
                if not line or line.startswith("#") or "=" not in line:
                    continue
                k, v = line.split("=", 1)
                os.environ.setdefault(k, v.strip('"').strip("'"))
    except FileNotFoundError:
        pass


def eval_default(d):
    if d.startswith("`") and d.endswith("`"):
        name = d[1:-1].strip()
        if "choice" in name:
            return "abc"
        return "argc" if "default" in name else ""
    return d


def choices(ch):
    if ch.startswith("`") and ch.endswith("`"):
        return ["abc", "def", "ghi"]
    return ch.split("|")


def check_choice(val, ch):
    allowed = choices(ch)
    arr = val if isinstance(val, list) else [val]
    for v in arr:
        if v not in allowed:
            return v
    return None


def help_text(root, cmd=None):
    cmd = cmd or root
    lines = []
    if cmd.describe:
        lines += [cmd.describe, ""]
    usage = root.name
    if cmd is not root:
        usage += " " + cmd.name
    if cmd.subcommands:
        usage += " <COMMAND>"
    else:
        req = []
        opts = [o for o in cmd.options if o.id not in ("help", "version")]
        if opts:
            usage += " [OPTIONS]"
        for o in opts:
            if o.required:
                usage += f" {o.long} <{(o.notations or [o.id.upper()])[0]}>"
                if o.multiple:
                    usage += "..."
        for a in cmd.args:
            n = a.notations[0]
            usage += f" <{n}>" if a.required else f" [{n}]"
            if a.multiple:
                usage += "..."
    lines.append("USAGE: " + usage)
    if cmd.args:
        lines += ["", "ARGS:"]
        rows = []
        for a in cmd.args:
            name = f"<{a.notations[0]}>" if a.required else f"[{a.notations[0]}]"
            if a.multiple:
                name += "..."
            rows.append((name, a.desc))
        lines += format_rows(rows)
    if cmd.options and not cmd.subcommands:
        rows = []
        for o in cmd.options:
            n = opt_display(o)
            d = o.desc
            if o.choice:
                d = (d + " " if d else "") + "[possible values: " + ", ".join(choices(o.choice)) + "]"
            if o.default is not None:
                d = (d + " " if d else "") + "[default: " + eval_default(o.default) + "]"
            rows.append((n, d))
        lines += ["", "OPTIONS:"] + format_rows(rows)
    if cmd.subcommands:
        rows = []
        for c in cmd.subcommands:
            d = c.describe
            if c.aliases:
                d += " [aliases: " + ", ".join(c.aliases) + "]"
            rows.append((c.name, d))
        lines += ["", "COMMANDS:"] + format_rows(rows)
    return "\n".join(lines) + "\n"


def opt_display(o):
    names = []
    if o.short:
        names.append(o.short)
    if o.long:
        names.append(o.long)
    n = ", ".join(names)
    if not o.flag:
        notation = " ".join(f"<{x}>" for x in (o.notations or [o.id.upper()]))
        if o.multiple and not o.required:
            notation = f"[{o.id.upper()}]..."
        elif o.multiple:
            notation = f"<{o.id.upper()}>..."
        n += " " + notation
    return n


def format_rows(rows):
    width = max((len(a) for a, _ in rows), default=0)
    out = []
    for a, b in rows:
        out.append("  " + a.ljust(width + 2) + b if b else "  " + a)
    return out


def emit_eval(file, argv):
    root = parse_file(file)
    if argv and argv[0] in ("--help", "-h"):
        print_shell_print(help_text(root), 0)
        return
    if argv and argv[0] in ("--version", "-V"):
        print_shell_print(root.version or VERSION, 0)
        return
    cmd, vals, pos, err, code = parse_args(root, argv)
    if "--help" in argv or "-h" in argv:
        print_shell_print(help_text(root, cmd), 0)
        return
    if err:
        print_shell_print(err + "\n", code)
        return
    envs, env_err, env_code = env_assignments(root, cmd)
    if env_err:
        print_shell_print(env_err + "\n", env_code)
        return
    assigns = []
    assigns.extend(envs)
    for k, v in vals.items():
        if isinstance(v, list):
            assigns.append(f"argc_{k}=(" + " ".join(shell_quote(x) for x in v) + ")")
        else:
            assigns.append(f"argc_{k}={shell_quote(str(v))}")
    script_name = os.path.splitext(os.path.basename(file))[0]
    allargs = [script_name] + argv
    assigns.append("argc__args=( " + " ".join(shell_quote(x) for x in allargs) + " )")
    if cmd.fn:
        assigns.append(f"argc__fn={shell_quote(cmd.fn)}")
    assigns.append("argc__positionals=( " + " ".join(shell_quote(x) for x in pos) + " )")
    payload = ";".join(assigns) + ";"
    print("export ARGC_VARS=" + base64.b64encode(payload.encode()).decode())
    for a in assigns:
        print(a)
    if cmd.fn:
        print(cmd.fn + (" " + " ".join(shell_quote(x) for x in pos) if pos else ""))


def print_shell_print(text, code):
    print("cat <<'ARGC_EOF'")
    sys.stdout.write(text)
    if not text.endswith("\n"):
        print()
    print("ARGC_EOF")
    print(f"exit {code}")


def export_json(file):
    root = parse_file(file)
    print(json.dumps(command_json(root), indent=2))


def command_json(c):
    return {
        "name": c.name,
        "describe": c.describe,
        "version": c.version,
        "aliases": c.aliases,
        "flag_options": [opt_json(o) for o in c.options],
        "positionals": [arg_json(a) for a in c.args],
        "envs": [],
        "subcommands": [command_json(x) | {"command_fn": x.fn} for x in c.subcommands],
        "command_fn": c.fn,
    }


def opt_json(o):
    return {
        "id": o.id, "long_name": o.long, "short_name": o.short, "describe": o.desc,
        "flag": o.flag, "notations": o.notations, "required": o.required,
        "multiple_values": o.num_args[1] > 1 and not o.multiple,
        "multiple_occurs": o.multiple, "num_args": [o.num_args[0], None if o.num_args[1] == 999999 else o.num_args[1]],
        "delimiter": o.delimiter, "terminated": o.terminated, "prefixed": o.prefixed,
        "assigned": o.assigned, "default": o.default, "choice": o.choice, "env": o.env,
        "inherited": False,
    }


def arg_json(a):
    return {
        "id": a.id, "describe": a.desc, "notation": a.notations[0], "required": a.required,
        "multiple": a.multiple, "delimiter": a.delimiter, "terminated": a.terminated,
        "default": a.default, "choice": a.choice, "env": a.env,
    }


def run_script(file, argv):
    exe = os.path.abspath(sys.argv[0])
    with tempfile.TemporaryDirectory() as td:
        os.symlink(exe, os.path.join(td, "argc"))
        env = os.environ.copy()
        env["PATH"] = td + os.pathsep + env.get("PATH", "")
        r = subprocess.run(["bash", file] + argv, env=env)
        sys.exit(r.returncode)


def compgen(args):
    if len(args) < 3:
        return
    file = args[1]
    partial = args[-1] if args else ""
    root = parse_file(file)
    cmd, _, _ = find_cmd(root, args[2:-1])
    for o in cmd.options:
        for n in [o.long, o.short]:
            if n and n.startswith(partial):
                d = o.desc or ('Print help' if o.id == 'help' else '')
                print(f"{n} ({d})" if d else n)
    for c in cmd.subcommands:
        if c.name.startswith(partial):
            print(f"{c.name} ({c.describe})" if c.describe else c.name)


def build_script(src, outpath):
    if os.path.isdir(outpath) or outpath.endswith("/"):
        os.makedirs(outpath, exist_ok=True)
        dst = os.path.join(outpath, os.path.basename(src))
    else:
        os.makedirs(os.path.dirname(outpath) or ".", exist_ok=True)
        dst = outpath
    exe = os.path.abspath(sys.argv[0])
    with open(src, "r", encoding="utf-8", errors="replace") as f:
        data = f.read()
    data = data.replace("argc --argc-eval", shell_quote(exe) + " --argc-eval")
    data = data.replace("argc --argc-parallel", shell_quote(exe) + " --argc-parallel")
    with open(dst, "w", encoding="utf-8") as f:
        f.write(data)
    os.chmod(dst, 0o755)


def main():
    argv = sys.argv[1:]
    if not argv:
        if os.path.exists("Argcfile.sh"):
            run_script("Argcfile.sh", [])
        print("Argcfile not found, try `argc --argc-help` for help.", file=sys.stderr)
        sys.exit(1)
    if argv[0] == "--help":
        if os.path.exists("Argcfile.sh"):
            run_script("Argcfile.sh", ["--help"])
        print("Argcfile not found, try `argc --argc-help` for help.", file=sys.stderr)
        sys.exit(1)
    cmd = argv[0]
    if cmd == "--argc-help":
        print("A bash cli framework, also a bash-based command runner - https://github.com/sigoden/argc\n")
        print("USAGE:")
        print("    argc --argc-eval <FILE> <ARGS~>            Use `eval \"$(argc --argc-eval \"$0\" \"$@\")\"`")
        print("    argc --argc-run <FILE> <ARGS~>             Run an argc-based script")
        print("    argc --argc-export <FILE>                  Export command line definitions as json")
        print("    argc --argc-help                           Print help information")
        print("    argc --argc-version                        Print version information")
    elif cmd == "--argc-version":
        print(VERSION)
    elif cmd == "--argc-eval":
        emit_eval(argv[1], argv[2:])
    elif cmd == "--argc-run":
        run_script(argv[1], argv[2:])
    elif cmd == "--argc-export":
        export_json(argv[1])
    elif cmd == "--argc-compgen":
        compgen(argv[1:])
    elif cmd == "--argc-completions":
        print("# argc completion placeholder")
    elif cmd == "--argc-mangen":
        root = parse_file(argv[1])
        outdir = argv[2] if len(argv) > 2 else "."
        os.makedirs(outdir, exist_ok=True)
        with open(os.path.join(outdir, root.name + ".1"), "w") as f:
            f.write(help_text(root))
    elif cmd == "--argc-build":
        build_script(argv[1], argv[2] if len(argv) > 2 else os.path.basename(argv[1]))
    elif cmd == "--argc-create":
        print("#!/usr/bin/env bash\n\neval \"$(argc --argc-eval \"$0\" \"$@\")\"")
    elif cmd == "--argc-script-path":
        print(os.path.abspath("Argcfile.sh"))
    elif cmd == "--argc-shell-path":
        print(shutil.which("bash") or "/bin/bash")
    else:
        if os.path.exists("Argcfile.sh"):
            run_script("Argcfile.sh", argv)
        print("Argcfile not found, try `argc --argc-help` for help.", file=sys.stderr)
        sys.exit(1)


if __name__ == "__main__":
    main()
