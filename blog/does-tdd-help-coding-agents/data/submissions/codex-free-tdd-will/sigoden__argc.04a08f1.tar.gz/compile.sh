#!/bin/bash
set -e
cp src/argc.py executable
chmod +x executable
