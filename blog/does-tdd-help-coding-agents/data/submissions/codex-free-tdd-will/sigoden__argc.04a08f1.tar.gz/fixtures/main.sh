# @arg val
main() {
    echo main "$argc_val"
}

eval "$(argc --argc-eval "$0" "$@")"
