# @option --rest~
main() {
    ( set -o posix ; set ) | grep ^argc_
}

eval "$(argc --argc-eval "$0" "$@")"
