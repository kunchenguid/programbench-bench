# @cmd
foo() { :; }

# @cmd
foo::bar() { :; }

eval "$(argc --argc-eval "$0" "$@")"
