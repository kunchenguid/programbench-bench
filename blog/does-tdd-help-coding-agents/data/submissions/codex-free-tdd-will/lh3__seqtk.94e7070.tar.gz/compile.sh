#!/bin/bash
set -e
cp seqtk_reimpl.py executable
chmod +x executable
