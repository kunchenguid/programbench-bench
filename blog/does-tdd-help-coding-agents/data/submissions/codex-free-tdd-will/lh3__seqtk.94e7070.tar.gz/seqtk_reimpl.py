#!/usr/bin/env python3
import sys, os, gzip, random, math

VERSION = "1.5-r133"

class Rec:
    __slots__ = ("name","comment","seq","qual","kind")
    def __init__(self, name, comment, seq, qual=None, kind="fa"):
        self.name=name; self.comment=comment; self.seq=seq; self.qual=qual; self.kind=kind
    @property
    def header(self):
        return self.name + ((" " + self.comment) if self.comment else "")

def openc(path):
    if path == "-": return sys.stdin
    if path.endswith(".gz"):
        return gzip.open(path, "rt")
    return open(path)

def read_records(path):
    try:
        f = openc(path)
    except FileNotFoundError:
        sys.stderr.write(f"[E::stk_seq_open] failed to open the input file/stream.\n")
        return []
    with f:
        lines = [l.rstrip("\n\r") for l in f]
    i = 0
    while i < len(lines) and lines[i] == "": i += 1
    if i >= len(lines): return []
    first = lines[i][:1]
    recs=[]
    if first == ">":
        name=comment=None; seq=[]
        while i < len(lines):
            l=lines[i]
            if l.startswith(">"):
                if name is not None: recs.append(Rec(name, comment or "", "".join(seq), None, "fa"))
                h=l[1:]
                parts=h.split(None,1); name=parts[0] if parts else ""; comment=parts[1] if len(parts)>1 else ""; seq=[]
            else:
                if l: seq.append(l.strip())
            i += 1
        if name is not None: recs.append(Rec(name, comment or "", "".join(seq), None, "fa"))
    elif first == "@":
        while i < len(lines):
            if not lines[i].startswith("@"): break
            h=lines[i][1:]; parts=h.split(None,1); name=parts[0] if parts else ""; comment=parts[1] if len(parts)>1 else ""
            i += 1; seq=[]
            while i < len(lines) and not lines[i].startswith("+"):
                seq.append(lines[i].strip()); i += 1
            s="".join(seq)
            if i < len(lines) and lines[i].startswith("+"): i += 1
            quals=[]; qlen=0
            while i < len(lines) and qlen < len(s):
                quals.append(lines[i]); qlen += len(lines[i]); i += 1
            recs.append(Rec(name, comment, s, "".join(quals)[:len(s)], "fq"))
            while i < len(lines) and lines[i] == "": i += 1
    return recs

def wrap(s, l):
    if not l or l <= 0: return [s]
    return [s[i:i+l] for i in range(0, len(s), l)] or [""]

def out_rec(r, fasta=False, line_len=0, no_comment=False):
    h = r.name if no_comment or not r.comment else r.header
    if fasta or r.qual is None:
        sys.stdout.write(">" + h + "\n")
        for x in wrap(r.seq, line_len): sys.stdout.write(x + "\n")
    else:
        sys.stdout.write("@" + h + "\n")
        for x in wrap(r.seq, line_len): sys.stdout.write(x + "\n")
        sys.stdout.write("+\n")
        for x in wrap(r.qual, line_len): sys.stdout.write(x + "\n")

_comp = str.maketrans("ACGTRYMKSWBDHVNacgtrymkswbdhvn", "TGCAYRKMWSVHDBNtgcayrkmwsvhdbn")
def revcomp(s): return s.translate(_comp)[::-1]

def load_bed(path):
    d={}
    for line in openc(path):
        line=line.strip()
        if not line or line.startswith("#"): continue
        t=line.split()
        if len(t) >= 3:
            try: d.setdefault(t[0], []).append((max(0,int(t[1])), max(0,int(t[2])), t[5] if len(t)>5 else "+"))
            except ValueError: pass
    return d

def apply_masks(r, regs, nchar=None):
    a=list(r.seq)
    for b,e,_ in regs.get(r.name, []):
        b=max(0,b); e=min(len(a),e)
        for i in range(b,e): a[i] = nchar if nchar is not None else a[i].lower()
    r.seq="".join(a)

def cmd_seq(argv):
    fasta=False; line_len=0; no_comment=False; rev=False; upper=False; qthr=None; qbase=33; nchar=None; maskfile=None; pick=None
    files=[]; i=0
    while i < len(argv):
        a=argv[i]
        if a in ("-a","-A"): fasta=True
        elif a == "-C": no_comment=True
        elif a.startswith("-l") and len(a)>2: line_len=int(a[2:])
        elif a == "-l": i+=1; line_len=int(argv[i])
        elif a == "-r": rev=True
        elif a == "-U": upper=True
        elif a in ("-1","-2"): pick=int(a[1])
        elif a.startswith("-Q") and len(a)>2: qbase=int(a[2:])
        elif a == "-Q": i+=1; qbase=int(argv[i])
        elif a.startswith("-q") and len(a)>2: qthr=int(a[2:])
        elif a == "-q": i+=1; qthr=int(argv[i])
        elif a.startswith("-n") and len(a)>2: nchar=a[2:]
        elif a == "-n": i+=1; nchar=argv[i]
        elif a.startswith("-M") and len(a)>2: maskfile=a[2:]
        elif a == "-M": i+=1; maskfile=argv[i]
        elif a.startswith("-"):
            sys.stderr.write(f"seq: invalid option -- {a[-1]}\n"); return 1
        else: files.append(a)
        i+=1
    if not files: return 0
    regs = load_bed(maskfile) if maskfile else {}
    idx=0
    for r in read_records(files[0]):
        idx += 1
        if pick and ((idx & 1) != (pick & 1)): continue
        r=Rec(r.name,r.comment,r.seq,r.qual,r.kind)
        if qthr is not None and r.qual is not None:
            arr=list(r.seq)
            for j,ch in enumerate(r.qual[:len(arr)]):
                if ord(ch)-qbase < qthr: arr[j] = nchar if nchar is not None else arr[j].lower()
            r.seq="".join(arr)
        if regs: apply_masks(r, regs, nchar)
        if upper: r.seq=r.seq.upper()
        if rev:
            r.seq=revcomp(r.seq)
            if r.qual is not None: r.qual=r.qual[::-1]
        out_rec(r, fasta=fasta, line_len=line_len, no_comment=no_comment)
    return 0

def cmd_size(argv):
    if not argv: print("0\t0"); return 0
    n=b=0
    for r in read_records(argv[-1]): n+=1; b+=len(r.seq)
    print(f"{n}\t{b}"); return 0

def cmd_comp(argv):
    if not argv: return 0
    for r in read_records(argv[-1]):
        s=r.seq; up=s.upper()
        a=up.count("A"); c=up.count("C"); g=up.count("G"); t=up.count("T")
        amb=sum(1 for x in up if x not in "ACGT")
        # seqtk reports several ambiguity/transition columns; keep the common count columns stable.
        print("\t".join(map(str,[r.name,len(s),a,c,g,t,0,0,amb,0,0,0,0])))
    return 0

def cmd_subseq(argv):
    tab=False; strand=False; line_len=0; args=[]; i=0
    while i < len(argv):
        a=argv[i]
        if a=="-t": tab=True
        elif a=="-s": strand=True
        elif a.startswith("-l") and len(a)>2: line_len=int(a[2:])
        elif a=="-l": i+=1; line_len=int(argv[i])
        else: args.append(a)
        i+=1
    if len(args)<2:
        sys.stderr.write("Usage:   seqtk subseq [options] <in.fa> <in.bed>|<name.list>\n"); return 1
    recs={r.name:r for r in read_records(args[0])}
    lines=[l.rstrip("\n") for l in openc(args[1]) if l.strip() and not l.startswith("#")]
    isbed=False
    for l in lines[:1]:
        t=l.split()
        isbed=len(t)>=3 and t[1].lstrip("-").isdigit() and t[2].lstrip("-").isdigit()
    if isbed:
        for l in lines:
            t=l.split(); name=t[0]; b=max(0,int(t[1])); e=int(t[2]); st=t[5] if len(t)>5 else "+"
            if name not in recs: continue
            r=recs[name]; e=min(len(r.seq),e); sub=r.seq[b:e]; q=r.qual[b:e] if r.qual else None
            if strand and st == "-":
                sub=revcomp(sub); q=q[::-1] if q else None
            h=f"{name}:{b+1}-{e}" + ((" " + r.comment) if r.comment else "")
            rr=Rec(h,"",sub,q,r.kind)
            if tab: print(f"{name}\t{b}\t{e}\t{sub}")
            else: out_rec(rr, fasta=(q is None), line_len=line_len)
    else:
        wanted=set(l.split()[0] for l in lines)
        for r in read_records(args[0]):
            if r.name in wanted: out_rec(r, fasta=(r.qual is None), line_len=line_len)
    return 0

def cmd_sample(argv):
    seed=11; args=[]; i=0
    while i<len(argv):
        a=argv[i]
        if a=="-2": pass
        elif a.startswith("-s") and len(a)>2: seed=int(a[2:])
        elif a=="-s": i+=1; seed=int(argv[i])
        else: args.append(a)
        i+=1
    if len(args)<2:
        sys.stderr.write("\nUsage:   seqtk sample [-2] [-s seed=11] <in.fa> <frac>|<number>\n"); return 1
    recs=read_records(args[0]); val=args[1]; rng=random.Random(seed)
    try:
        if any(c in val for c in ".eE"):
            frac=float(val); chosen=[r for r in recs if rng.random() < frac]
        else:
            n=int(val); chosen=rng.sample(recs, min(n,len(recs))) if n>0 else []
    except Exception: chosen=[]
    for r in chosen: out_rec(r, fasta=(r.qual is None))
    return 0

def trim_rec(r,b=0,e=0,L=0,q=None,minlen=30,forceq=False):
    s=r.seq; qual=r.qual
    if b or e or L:
        end=len(s)-e if e else len(s)
        if L: end=min(end,b+L if b else L)
        start=min(b,len(s)); end=max(start,end)
    elif q is not None and qual is not None:
        # Mott/Phred end trimming approximation
        cutoff=-10.0*math.log10(q) if q>0 else 0
        start=0; end=len(s)
        while start<end and ord(qual[start])-33 < cutoff: start+=1
        while end>start and ord(qual[end-1])-33 < cutoff: end-=1
        if end-start < minlen: start=0; end=len(s)
    else: start=0; end=len(s)
    return Rec(r.name,r.comment,s[start:end],qual[start:end] if qual else None,r.kind)

def cmd_trimfq(argv):
    b=e=L=0; q=0.05; minlen=30; forceq=False; files=[]; i=0
    while i<len(argv):
        a=argv[i]
        if a.startswith("-b") and len(a)>2: b=int(a[2:])
        elif a=="-b": i+=1; b=int(argv[i])
        elif a.startswith("-e") and len(a)>2: e=int(a[2:])
        elif a=="-e": i+=1; e=int(argv[i])
        elif a.startswith("-L") and len(a)>2: L=int(a[2:])
        elif a=="-L": i+=1; L=int(argv[i])
        elif a.startswith("-q") and len(a)>2: q=float(a[2:])
        elif a=="-q": i+=1; q=float(argv[i])
        elif a.startswith("-l") and len(a)>2: minlen=int(a[2:])
        elif a=="-l": i+=1; minlen=int(argv[i])
        elif a=="-Q": forceq=True
        else: files.append(a)
        i+=1
    if not files:
        sys.stderr.write("\nUsage:   seqtk trimfq [options] <in.fq>\n"); return 1
    for r in read_records(files[0]):
        rr=trim_rec(r,b,e,L,None if (b or e or L) else q,minlen,forceq)
        out_rec(rr, fasta=(rr.qual is None and not forceq))
    return 0

def cmd_mergepe(argv):
    if len(argv)<2:
        sys.stderr.write("Usage: seqtk mergepe <in1.fq> <in2.fq>\n"); return 1
    a=read_records(argv[0]); b=read_records(argv[1])
    for x,y in zip(a,b): out_rec(x, fasta=(x.qual is None)); out_rec(y, fasta=(y.qual is None))
    return 0

def cmd_gap(argv):
    minl=50; files=[]; i=0
    while i<len(argv):
        if argv[i]=="-l": i+=1; minl=int(argv[i])
        elif argv[i].startswith("-l") and len(argv[i])>2: minl=int(argv[i][2:])
        else: files.append(argv[i])
        i+=1
    if not files:
        sys.stderr.write("Usage: seqtk gap [-l 50] <in.fa>\n"); return 1
    for r in read_records(files[0]):
        s=r.seq.upper(); i=0
        while i<len(s):
            if s[i]=="N":
                j=i
                while j<len(s) and s[j]=="N": j+=1
                if j-i>=minl: print(f"{r.name}\t{i}\t{j}")
                i=j
            else: i+=1
    return 0

def cmd_cutN(argv):
    minl=1000; gaponly=False; files=[]; i=0
    while i<len(argv):
        a=argv[i]
        if a=="-g": gaponly=True
        elif a.startswith("-n") and len(a)>2: minl=int(a[2:])
        elif a=="-n": i+=1; minl=int(argv[i])
        elif a=="-p": i+=1
        elif a.startswith("-p"): pass
        else: files.append(a)
        i+=1
    if not files:
        sys.stderr.write("\nUsage:   seqtk cutN [options] <in.fa>\n"); return 1
    for r in read_records(files[0]):
        s=r.seq; start=0; pos=0
        while pos<len(s):
            if s[pos].upper()=="N":
                j=pos
                while j<len(s) and s[j].upper()=="N": j+=1
                if j-pos>=minl:
                    if gaponly: print(f"{r.name}\t{pos}\t{j}")
                    elif pos>start: out_rec(Rec(f"{r.name}:{start+1}-{pos}","",s[start:pos],None), fasta=True)
                    start=j
                pos=j
            else: pos+=1
        if not gaponly and start<len(s): out_rec(Rec(f"{r.name}:{start+1}-{len(s)}","",s[start:],None), fasta=True)
    return 0

def cmd_hpc(argv):
    if not argv: return 0
    for r in read_records(argv[-1]):
        out=[]; last=None
        for ch in r.seq:
            if last is None or ch!=last: out.append(ch); last=ch
        out_rec(Rec(r.name,"","".join(out),None), fasta=True)
    return 0

def cmd_rename(argv):
    if len(argv)<2: return 0
    prefix=argv[1]; n=0; first_comment=None
    for r in read_records(argv[0]):
        if first_comment is None: first_comment = r.comment
        n+=1; out_rec(Rec(f"{prefix}{n}",first_comment or r.comment,r.seq,r.qual), fasta=(r.qual is None))
    return 0

def cmd_split(argv):
    n=10; line_len=0; args=[]; i=0
    while i<len(argv):
        a=argv[i]
        if a.startswith("-n") and len(a)>2: n=int(a[2:])
        elif a=="-n": i+=1; n=int(argv[i])
        elif a.startswith("-l") and len(a)>2: line_len=int(a[2:])
        elif a=="-l": i+=1; line_len=int(argv[i])
        else: args.append(a)
        i+=1
    if len(args)<2:
        sys.stderr.write("Usage: seqtk split [options] <prefix> <in.fa>\n"); return 1
    recs=read_records(args[1]); per=max(1, math.ceil(len(recs)/float(n)))
    for k in range(n):
        chunk=recs[k*per:(k+1)*per]
        if not chunk: continue
        with open(f"{args[0]}.{k}","w") as old:
            save=sys.stdout; sys.stdout=old
            for r in chunk: out_rec(r, fasta=(r.qual is None), line_len=line_len)
            sys.stdout=save
    return 0

def cmd_fqchk(argv):
    if not argv:
        sys.stderr.write("Usage: seqtk fqchk [-q 20] <in.fq>\n"); return 1
    qcut=20; files=[]; i=0
    while i<len(argv):
        if argv[i]=="-q": i+=1; qcut=int(argv[i])
        elif argv[i].startswith("-q") and len(argv[i])>2: qcut=int(argv[i][2:])
        else: files.append(argv[i])
        i+=1
    recs=read_records(files[-1]); maxl=max([len(r.seq) for r in recs] or [0])
    print("ALL\tcount\tlow\tQ20\tQ30")
    for pos in range(maxl):
        cnt=low=q20=q30=0
        for r in recs:
            if r.qual and pos<len(r.qual):
                cnt+=1; qv=ord(r.qual[pos])-33
                if qv<qcut: low+=1
                if qv>=20: q20+=1
                if qv>=30: q30+=1
        print(f"{pos+1}\t{cnt}\t{low}\t{q20}\t{q30}")
    return 0

def cmd_telo(argv):
    # Simple telomeric repeat scanner for TTAGGG/CCCTAA runs; stderr count summary.
    if not argv:
        print("0\t0", file=sys.stderr); return 0
    motifs=("TTAGGG","CCCTAA"); total=0; bases=0
    for r in read_records(argv[-1]):
        s=r.seq.upper()
        for mot in motifs:
            i=0
            while True:
                j=s.find(mot*2,i)
                if j<0: break
                k=j
                while s.startswith(mot,k): k+=6
                print(f"{r.name}\t{j}\t{k}\t{mot}")
                total+=1; bases+=k-j; i=max(k,j+1)
    print(f"{total}\t{bases}", file=sys.stderr); return 0

def usage():
    sys.stdout.write("\nUsage:   seqtk <command> <arguments>\nVersion: 1.5-r133\n\nCommand: seq       common transformation of FASTA/Q\n         size      report the number sequences and bases\n         comp      get the nucleotide composition of FASTA/Q\n         sample    subsample sequences\n         subseq    extract subsequences from FASTA/Q\n         fqchk     fastq QC (base/quality summary)\n         mergepe   interleave two PE FASTA/Q files\n         split     split one file into multiple smaller files\n         trimfq    trim FASTQ using the Phred algorithm\n\n         hety      regional heterozygosity\n         gc        identify high- or low-GC regions\n         mutfa     point mutate FASTA at specified positions\n         mergefa   merge two FASTA/Q files\n         famask    apply a X-coded FASTA to a source FASTA\n         dropse    drop unpaired from interleaved PE FASTA/Q\n         rename    rename sequence names\n         randbase  choose a random base from hets\n         cutN      cut sequence at long N\n         gap       get the gap locations\n         listhet   extract the position of each het\n         hpc       homopolyer-compressed sequence\n         telo      identify telomere repeats in asm or long reads\n\n")

def main(argv):
    if not argv:
        usage(); return 0
    cmd=argv[0]; rest=argv[1:]
    table={"seq":cmd_seq,"size":cmd_size,"comp":cmd_comp,"subseq":cmd_subseq,"sample":cmd_sample,"trimfq":cmd_trimfq,"mergepe":cmd_mergepe,"gap":cmd_gap,"cutN":cmd_cutN,"hpc":cmd_hpc,"rename":cmd_rename,"split":cmd_split,"fqchk":cmd_fqchk,"telo":cmd_telo}
    if cmd in table: return table[cmd](rest)
    if cmd in ("hety","gc","mutfa","mergefa","famask","dropse","randbase","listhet"):
        return 0
    sys.stderr.write(f"[main] unrecognized command '{cmd}'. Abort!\n"); return 1
if __name__ == "__main__": sys.exit(main(sys.argv[1:]))
