#!/usr/bin/env python3
import os, sys, math

VERSION = "hx 0.7.0"
HELP = """Futuristic take on hexdump, made in Rust.\n\n\nUsage: executable [OPTIONS] [INPUTFILE]\n\nArguments:\n  [INPUTFILE]  Pass file path as an argument, or input data may be passed via stdin\n\nOptions:\n  -c, --cols <columns>        Set column length\n  -l, --len <len>             Set <len> bytes to read\n  -f, --format <format>       Set format of octet: Octal (o), LowerHex (x), UpperHex (X), Binary (b) [possible values: o, x, X, b]\n  -t, --color <color>         Set color tint terminal output. 0 to disable, 1 to enable [possible values: 0, 1]\n  -a, --array <array_format>  Set source code format output: rust (r), C (c), golang (g), python (p), kotlin (k), java (j), swift (s), fsharp (f) [possible values: r, c, g, p, k, j, s, f]\n  -u, --func <func_length>    Set function wave length\n  -p, --places <func_places>  Set function wave output decimal places\n  -r, --prefix <prefix>       Include prefix in output (e.g. 0x/0b/0o). 0 to disable, 1 to enable [possible values: 0, 1]\n  -h, --help                  Print help\n  -V, --version               Print version\n"""

def parse_int(value, opt, name):
    try:
        return int(value)
    except Exception:
        print(f"{opt}, --{name} <integer> expected. ParseIntError {{ kind: InvalidDigit }}")
        print("error: invalid digit found in string")
        sys.exit(1)

def missing_value(opt):
    print(f"error: a value is required for '{opt}' but none was supplied", file=sys.stderr)
    sys.exit(2)

def parse(argv):
    opts = {"cols": 10, "len": None, "format": "x", "color": None, "array": None, "func": None, "places": 4, "prefix": 1, "input": None}
    i = 0
    while i < len(argv):
        a = argv[i]
        if a == "--":
            if i + 1 < len(argv):
                opts["input"] = argv[i+1]
            break
        if a in ("-h", "--help"):
            print(HELP, end="")
            sys.exit(0)
        if a in ("-V", "--version"):
            print(VERSION)
            sys.exit(0)

        def value(longname):
            nonlocal i, a
            if a.startswith(longname + "="):
                return a.split("=", 1)[1]
            if i + 1 >= len(argv):
                missing_value(a)
            i += 1
            return argv[i]

        if a in ("-c", "--cols") or a.startswith("--cols="):
            opts["cols"] = parse_int(value("--cols"), "-c", "cols")
        elif a in ("-l", "--len") or a.startswith("--len="):
            opts["len"] = parse_int(value("--len"), "-l", "len")
        elif a in ("-f", "--format") or a.startswith("--format="):
            v = value("--format")
            if v not in ["o", "x", "X", "b"]:
                print(f"error: invalid value '{v}' for '--format <format>'", file=sys.stderr)
                print("  [possible values: o, x, X, b]\n", file=sys.stderr)
                print("For more information, try '--help'.", file=sys.stderr)
                sys.exit(2)
            opts["format"] = v
        elif a in ("-t", "--color") or a.startswith("--color="):
            v = value("--color")
            if v not in ["0", "1"]:
                print(f"error: invalid value '{v}' for '--color <color>'", file=sys.stderr)
                print("  [possible values: 0, 1]\n", file=sys.stderr)
                print("For more information, try '--help'.", file=sys.stderr)
                sys.exit(2)
            opts["color"] = int(v)
        elif a in ("-a", "--array") or a.startswith("--array="):
            v = value("--array")
            if v not in list("rcgpkjsf"):
                print(f"error: invalid value '{v}' for '--array <array_format>'", file=sys.stderr)
                print("  [possible values: r, c, g, p, k, j, s, f]\n", file=sys.stderr)
                print("For more information, try '--help'.", file=sys.stderr)
                sys.exit(2)
            opts["array"] = v
        elif a in ("-u", "--func") or a.startswith("--func="):
            opts["func"] = parse_int(value("--func"), "-u", "func")
        elif a in ("-p", "--places") or a.startswith("--places="):
            try:
                opts["places"] = int(value("--places"))
            except Exception:
                pass
        elif a in ("-r", "--prefix") or a.startswith("--prefix="):
            v = value("--prefix")
            if v not in ["0", "1"]:
                print(f"error: invalid value '{v}' for '--prefix <prefix>'", file=sys.stderr)
                sys.exit(2)
            opts["prefix"] = int(v)
        elif a.startswith("-"):
            print(f"error: unexpected argument '{a}' found\n", file=sys.stderr)
            print(f"  tip: to pass '{a}' as a value, use '-- {a}'\n", file=sys.stderr)
            print("Usage: executable [OPTIONS] [INPUTFILE]\n", file=sys.stderr)
            print("For more information, try '--help'.", file=sys.stderr)
            sys.exit(2)
        else:
            opts["input"] = a
        i += 1
    return opts

def token(b, fmt, prefix):
    if fmt in ("x", "X"):
        s = f"{b:02x}" if fmt == "x" else f"{b:02X}"
        return ("0x" + s) if prefix else s
    if fmt == "o":
        s = f"{b:04o}"
        return ("0o" + s) if prefix else s
    s = f"{b:08b}"
    return ("0b" + s) if prefix else s

def printable(b):
    return chr(b) if 32 <= b <= 126 else "."

def colorize(s, b, enabled):
    if not enabled:
        return s
    return f"\033[38;5;{b % 256}m{s}\033[0m"

def limit_data(data, opts):
    if opts["len"] and opts["len"] > 0:
        return data[:opts["len"]]
    return data

def dump(data, opts):
    original_cols = opts["cols"]
    cols = original_cols
    if cols <= 0:
        cols = 1
    data = limit_data(data, opts)
    color = (opts["color"] == 1) and ("NO_COLOR" not in os.environ)
    out = []
    offset = 0
    while offset < len(data) or len(data) == 0:
        chunk = data[offset:offset+cols]
        pieces = [colorize(token(b, opts["format"], opts["prefix"]), b, color) for b in chunk]
        field = " ".join(pieces)
        asc = "".join(colorize(printable(b), b, color) for b in chunk)
        spaces = (cols - len(chunk)) * 5 + 1
        out.append(f"0x{offset:06x}: {field}" + " " * spaces + asc)
        offset += cols
        if len(data) == 0:
            break
    if original_cols <= 1 and len(data) > 0:
        out.append(f"0x{len(data):06x}: " + " " * 5)
    out.append(f"   bytes: {len(data)}")
    return "\n".join(out) + "\n"

def hex_lines(data, suffix="", sep=",", trailing_last=False):
    vals = [f"0x{b:02x}{suffix}" for b in data]
    lines = []
    for i in range(0, len(vals), 10):
        group = vals[i:i+10]
        last_group = i + 10 >= len(vals)
        text = (sep + " ").join(group)
        if (not last_group) or trailing_last:
            text += sep + " "
        lines.append("    " + text)
    if not lines:
        lines.append("    ")
    return "\n".join(lines)

def array_output(data, kind):
    n = len(data)
    comma = hex_lines(data, "", ",", trailing_last=(kind == "g"))
    if kind == "r":
        return f"let ARRAY: [u8; {n}] = [\n{comma}\n];\n"
    if kind == "c":
        return f"unsigned char ARRAY[{n}] = {{\n{comma}\n}};\n"
    if kind == "g":
        return f"a := [{n}]byte{{\n{comma}\n}}\n"
    if kind == "p":
        return f"a = [\n{comma}\n]\n"
    if kind == "k":
        return f"val a = byteArrayOf(\n{comma}\n)\n"
    if kind == "j":
        return f"byte[] a = new byte[]{{\n{comma}\n}};\n"
    if kind == "s":
        return f"let a: [UInt8] = [\n{comma}\n]\n"
    if kind == "f":
        return f"let a = [|\n{hex_lines(data, 'uy', ';')}\n|]\n"
    return ""

def read_data(path):
    if path:
        try:
            with open(path, "rb") as f:
                return f.read()
        except OSError as e:
            print(f"error: {e.strerror} (os error {e.errno})", file=sys.stderr)
            sys.exit(1)
    return sys.stdin.buffer.read()

def main():
    opts = parse(sys.argv[1:])
    if opts["func"] is not None:
        n = opts["func"]
        vals = [format(math.sin(i * math.pi / (2 * n)), f".{opts['places']}f") for i in range(n)] if n > 0 else []
        print("".join(v + "," for v in vals))
        return
    data = read_data(opts["input"])
    if opts["array"]:
        sys.stdout.write(array_output(limit_data(data, opts), opts["array"]))
    else:
        sys.stdout.write(dump(data, opts))

if __name__ == "__main__":
    main()
