#!/bin/bash
set -e
rm -f executable
cp src/hx.py executable
chmod +x executable
