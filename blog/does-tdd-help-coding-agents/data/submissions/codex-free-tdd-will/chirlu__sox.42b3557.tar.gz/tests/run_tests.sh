#!/bin/bash
set -euo pipefail
BIN=${1:-./executable}
rm -rf test-tmp && mkdir test-tmp
out=$($BIN --version)
[ "$out" = "./executable:      SoX v14.4.2" ] || { echo "bad version: $out"; exit 1; }
$BIN --help | grep -q "Usage summary"
$BIN --help-effect trim | grep -q "trim {position}"
$BIN -n -r 8000 -c 1 -b 16 test-tmp/tone.wav synth 0.01 sine 440
[ "$($BIN --i -t test-tmp/tone.wav)" = "wav" ]
[ "$($BIN --i -r test-tmp/tone.wav)" = "8000" ]
[ "$($BIN --i -c test-tmp/tone.wav)" = "1" ]
[ "$($BIN --i -s test-tmp/tone.wav)" = "80" ]
[ "$($BIN --i -d test-tmp/tone.wav)" = "00:00:00.01" ]
[ "$($BIN --i -D test-tmp/tone.wav)" = "0.010000" ]
[ "$($BIN --i -b test-tmp/tone.wav)" = "16" ]
$BIN test-tmp/tone.wav test-tmp/trim.wav trim 0 0.005
[ "$($BIN --i -s test-tmp/trim.wav)" = "40" ]
$BIN test-tmp/tone.wav test-tmp/rev.wav reverse
[ "$($BIN --i -s test-tmp/rev.wav)" = "80" ]
$BIN test-tmp/tone.wav -t raw test-tmp/tone.raw
[ "$(wc -c < test-tmp/tone.raw)" = "160" ]
$BIN -r 8000 -e signed -b 16 -c 1 -t raw test-tmp/tone.raw test-tmp/fromraw.wav
[ "$($BIN --i -s test-tmp/fromraw.wav)" = "80" ]
$BIN test-tmp/tone.wav -n stat >/tmp/stat.out 2>/tmp/stat.err
[ ! -s /tmp/stat.out ]
grep -q "Samples read" /tmp/stat.err
$BIN -n -r8k -c1 -b16 test-tmp/a.au synth 0.01 sine 440
[ "$($BIN --i -t test-tmp/a.au)" = "au" ]
[ "$($BIN --i -s test-tmp/a.au)" = "80" ]
