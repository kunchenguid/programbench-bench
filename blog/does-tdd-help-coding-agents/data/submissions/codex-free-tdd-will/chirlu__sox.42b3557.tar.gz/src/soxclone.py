#!/usr/bin/env python3
import sys, os, struct, math

VERSION = "SoX v14.4.2"

HELP = """{prog}:      SoX v14.4.2

Usage summary: [gopts] [[fopts] infile]... [fopts] outfile [effect [effopt]]...

SPECIAL FILENAMES (infile, outfile):
-                        Pipe/redirect input/output (stdin/stdout); may need -t
-d, --default-device     Use the default audio device (where available)
-n, --null               Use the `null' file handler; e.g. with synth effect
-p, --sox-pipe           Alias for `-t sox -'

GLOBAL OPTIONS (gopts) (can be specified at any point before the first effect):
-h, --help               Display version number and usage information
--help-effect NAME       Show usage of effect NAME, or NAME=all for all
--help-format NAME       Show info on format NAME, or NAME=all for all
--i, --info              Behave as soxi(1)
-q, --no-show-progress   Run in quiet mode; opposite of -S
--version                Display version number of SoX and exit
-V[LEVEL]                Increment or set verbosity level (default 2)
FORMAT OPTIONS (fopts):
-v|--volume FACTOR       Input file volume adjustment factor (real number)
-t|--type FILETYPE       File type of audio
-e|--encoding ENCODING   Set encoding
-b|--bits BITS           Encoded sample size in bits
-c|--channels CHANNELS   Number of channels of audio data; e.g. 2 = stereo
-r|--rate RATE           Sample rate of audio

AUDIO FILE FORMATS: raw s8 u8 s16 u16 s24 s32 wav wavpcm au aiff aif flac mp3 ogg
EFFECTS: channels fade gain norm rate reverse stat stats synth trim vol
"""

WAV_FORMAT = """{prog}:      SoX v14.4.2

Format: wav
Description: Microsoft audio format
Also handles: wavpcm amb
Reads: yes
Writes:
  16-bit Signed Integer PCM (16-bit precision)
  24-bit Signed Integer PCM (24-bit precision)
  32-bit Signed Integer PCM (32-bit precision)
   8-bit Unsigned Integer PCM (8-bit precision)
"""

EFFECT_HELP = {
    "trim": "Effect usage:\n\ntrim {position}\n",
    "gain": "Effect usage:\n\ngain [-e|-b|-B|-r] [-n] [-l|-h] [gain-dB]\n",
    "vol": "Effect usage:\n\nvol gain [type [limitergain]]\n",
    "synth": "Effect usage:\n\nsynth [len] {type [combine] [freq]}\n",
    "stat": "Effect usage:\n\nstat [-s scale] [-rms] [-freq] [-v] [-d]\n",
    "stats": "Effect usage:\n\nstats [-b bits|-x bits|-s scale] [-w window-time]\n",
}
EFFECTS = set("channels fade gain norm rate reverse stat stats synth trim vol".split())

class Audio:
    def __init__(self, rate=8000, channels=1, bits=16, samples=None, encoding="Signed Integer PCM"):
        self.rate = int(rate)
        self.channels = int(channels)
        self.bits = int(bits)
        self.samples = samples or []
        self.encoding = encoding
    @property
    def frame_count(self):
        return len(self.samples)

def progname():
    return sys.argv[0]

def parse_rate(s):
    ss = str(s).strip().lower(); mult = 1
    if ss.endswith("k"):
        mult = 1000; ss = ss[:-1]
    return int(float(ss) * mult)

def parse_time(s, rate):
    s = str(s)
    if ":" in s:
        parts = [float(x) for x in s.split(":")]
        secs = parts[-1] + (parts[-2] * 60 if len(parts) > 1 else 0) + (parts[-3] * 3600 if len(parts) > 2 else 0)
    else:
        secs = float(s)
    return max(0, int(round(secs * rate)))

def clip(x):
    return -1.0 if x < -1.0 else 1.0 if x > 1.0 else x

def bytes_to_samples(pcm, channels, bits, code=1):
    samples = []
    if bits == 8:
        step = channels
        for i in range(0, len(pcm)//step*step, step):
            samples.append([(pcm[i+c]-128)/128.0 for c in range(channels)])
    elif bits == 16:
        vals = struct.unpack("<" + "h"*(len(pcm)//2), pcm[:len(pcm)//2*2]) if pcm else []
        for i in range(0, len(vals)//channels*channels, channels):
            samples.append([vals[i+c]/32768.0 for c in range(channels)])
    elif bits == 24:
        step = 3*channels
        for i in range(0, len(pcm)//step*step, step):
            fr=[]
            for c in range(channels):
                b=pcm[i+3*c:i+3*c+3]
                v=int.from_bytes(b + (b"\xff" if b[2]&0x80 else b"\x00"), "little", signed=True)
                fr.append(v/8388608.0)
            samples.append(fr)
    elif bits == 32 and code == 3:
        vals = struct.unpack("<" + "f"*(len(pcm)//4), pcm[:len(pcm)//4*4]) if pcm else []
        for i in range(0, len(vals)//channels*channels, channels):
            samples.append([float(vals[i+c]) for c in range(channels)])
    else:
        vals = struct.unpack("<" + "i"*(len(pcm)//4), pcm[:len(pcm)//4*4]) if pcm else []
        for i in range(0, len(vals)//channels*channels, channels):
            samples.append([vals[i+c]/2147483648.0 for c in range(channels)])
    return samples

def read_wav(path):
    data = sys.stdin.buffer.read() if path == "-" else open(path, "rb").read()
    if len(data) < 44 or data[:4] not in (b"RIFF", b"RIFX") or data[8:12] != b"WAVE":
        raise ValueError("not a WAV file")
    endian = ">" if data[:4] == b"RIFX" else "<"
    pos = 12; fmt = None; pcm = b""
    while pos + 8 <= len(data):
        cid = data[pos:pos+4]; size = struct.unpack(endian+"I", data[pos+4:pos+8])[0]
        chunk = data[pos+8:pos+8+size]
        if cid == b"fmt ":
            code, ch, rate, _br, _ba, bits = struct.unpack(endian+"HHIIHH", chunk[:16])
            fmt = (code, ch, rate, bits)
        elif cid == b"data":
            pcm = chunk
        pos += 8 + size + (size & 1)
    if not fmt: raise ValueError("missing fmt")
    code, ch, rate, bits = fmt
    samples = bytes_to_samples(pcm, ch, bits, code)
    enc = "Unsigned Integer PCM" if bits == 8 and code == 1 else "Signed Integer PCM" if code == 1 else "Floating Point PCM"
    return Audio(rate, ch, bits, samples, enc)

def samples_to_bytes(audio):
    out = bytearray(); bits = audio.bits
    for fr in audio.samples:
        vals = list(fr)[:audio.channels]
        while len(vals) < audio.channels: vals.append(0.0)
        for x in vals:
            x = clip(x)
            if bits == 8:
                out.append(max(0, min(255, int(round(x*127.0+128)))))
            elif bits == 16:
                out += struct.pack("<h", max(-32768, min(32767, int(round(x*32767.0)))))
            elif bits == 24:
                v = max(-8388608, min(8388607, int(round(x*8388607.0))))
                out += int(v).to_bytes(4, "little", signed=True)[:3]
            else:
                out += struct.pack("<i", max(-2147483648, min(2147483647, int(round(x*2147483647.0)))))
    return bytes(out)

def write_wav(audio, path):
    pcm = samples_to_bytes(audio)
    ch, rate, bits = audio.channels, audio.rate, audio.bits
    block = ch * ((bits + 7)//8); byte_rate = rate * block
    fmt = struct.pack("<HHIIHH", 1, ch, rate, byte_rate, block, bits)
    riff_size = 4 + 8 + 16 + 8 + len(pcm)
    data = b"RIFF" + struct.pack("<I", riff_size) + b"WAVEfmt " + struct.pack("<I",16) + fmt + b"data" + struct.pack("<I", len(pcm)) + pcm
    if path == "-": sys.stdout.buffer.write(data)
    else: open(path, "wb").write(data)

def read_au(path):
    data = sys.stdin.buffer.read() if path == "-" else open(path, "rb").read()
    if len(data) < 24 or data[:4] != b".snd":
        raise ValueError("not an AU file")
    off, size, enc, rate, ch = struct.unpack(">IIIII", data[4:24])
    bits = {2:8, 3:16, 4:24, 5:32}.get(enc, 16)
    pcm = data[off:] if size == 0xffffffff else data[off:off+size]
    samples=[]
    if enc == 2:
        for i in range(0, len(pcm)//ch*ch, ch):
            samples.append([struct.unpack("b", pcm[i+c:i+c+1])[0]/128.0 for c in range(ch)])
    elif enc == 3:
        vals = struct.unpack(">" + "h"*(len(pcm)//2), pcm[:len(pcm)//2*2]) if pcm else []
        for i in range(0, len(vals)//ch*ch, ch): samples.append([vals[i+c]/32768.0 for c in range(ch)])
    elif enc == 4:
        step=3*ch
        for i in range(0, len(pcm)//step*step, step):
            fr=[]
            for c in range(ch):
                b=pcm[i+3*c:i+3*c+3]
                v=int.from_bytes((b"\xff" if b[0]&0x80 else b"\x00") + b, "big", signed=True)
                fr.append(v/8388608.0)
            samples.append(fr)
    elif enc == 5:
        vals = struct.unpack(">" + "i"*(len(pcm)//4), pcm[:len(pcm)//4*4]) if pcm else []
        for i in range(0, len(vals)//ch*ch, ch): samples.append([vals[i+c]/2147483648.0 for c in range(ch)])
    else:
        samples = bytes_to_samples(pcm, ch, bits, 1)
    return Audio(rate, ch, bits, samples, "Signed Integer PCM")

def write_au(audio, path):
    enc = {8:2, 16:3, 24:4, 32:5}.get(audio.bits, 3)
    out=bytearray()
    for fr in audio.samples:
        vals=list(fr)[:audio.channels]
        while len(vals)<audio.channels: vals.append(0.0)
        for x in vals:
            x=clip(x)
            if audio.bits == 8: out += struct.pack("b", max(-128,min(127,int(round(x*127.0)))))
            elif audio.bits == 16: out += struct.pack(">h", max(-32768,min(32767,int(round(x*32767.0)))))
            elif audio.bits == 24:
                v=max(-8388608,min(8388607,int(round(x*8388607.0))))
                out += int(v).to_bytes(4,"big",signed=True)[1:]
            else: out += struct.pack(">i", max(-2147483648,min(2147483647,int(round(x*2147483647.0)))))
    header = b".snd" + struct.pack(">IIIII", 24, len(out), enc, audio.rate, audio.channels)
    if path == "-": sys.stdout.buffer.write(header + out)
    else: open(path,"wb").write(header + out)

def read_raw(path, rate, channels, bits, encoding):
    pcm = sys.stdin.buffer.read() if path == "-" else open(path, "rb").read()
    if bits == 8 and str(encoding or "").startswith("signed"):
        samples=[]
        for i in range(0, len(pcm)//channels*channels, channels):
            samples.append([struct.unpack("b", pcm[i+c:i+c+1])[0]/128.0 for c in range(channels)])
        enc = "Signed Integer PCM"
    else:
        samples = bytes_to_samples(pcm, channels, bits, 1)
        enc = "Unsigned Integer PCM" if bits == 8 else "Signed Integer PCM"
    return Audio(rate, channels, bits, samples, enc)

def write_raw(audio, path):
    data = samples_to_bytes(audio)
    if path == "-": sys.stdout.buffer.write(data)
    else: open(path, "wb").write(data)

def duration_hms(frames, rate):
    secs = frames / rate if rate else 0
    total = int(secs + 1e-9); h=total//3600; m=(total%3600)//60; s=total%60
    hundred = int(round((secs-total)*100))
    if hundred >= 100: s += 1; hundred = 0
    return f"{h:02d}:{m:02d}:{s:02d}.{hundred:02d}"

def bitrate(audio, filesize=0):
    dur = audio.frame_count / audio.rate if audio.rate else 0
    if dur <= 0: return "0"
    bps = (filesize * 8) / dur
    return f"{int(round(bps/1000))}k" if bps >= 1000 else str(int(round(bps)))

def detect_type(path):
    if path == "-": return "wav"
    name = path.lower()
    if name.endswith((".au", ".snd")): return "au"
    if name.endswith(".wav"): return "wav"
    try:
        with open(path, "rb") as f: magic = f.read(12)
        if magic[:4] == b".snd": return "au"
        if magic[:4] in (b"RIFF", b"RIFX") and magic[8:12] == b"WAVE": return "wav"
    except OSError:
        pass
    return "wav"

def soxi(path, opt=None):
    typ = detect_type(path)
    a = read_au(path) if typ == "au" else read_wav(path)
    size = os.path.getsize(path) if path != "-" and os.path.exists(path) else 0
    mapping = {
        "-t": typ, "-r": str(a.rate), "-c": str(a.channels), "-s": str(a.frame_count),
        "-d": duration_hms(a.frame_count, a.rate), "-D": f"{a.frame_count/a.rate:.6f}" if a.rate else "0",
        "-b": str(a.bits), "-B": bitrate(a, size), "-p": str(a.bits), "-e": a.encoding,
    }
    if opt:
        if opt in mapping: print(mapping[opt])
        return
    sectors = a.frame_count / 588.0
    print(f"\nInput File     : '{path}'")
    print(f"Channels       : {a.channels}")
    print(f"Sample Rate    : {a.rate}")
    print(f"Precision      : {a.bits}-bit")
    print(f"Duration       : {duration_hms(a.frame_count, a.rate)} = {a.frame_count} samples ~ {sectors:.3g} CDDA sectors")
    print(f"File Size      : {size}")
    print(f"Bit Rate       : {bitrate(a,size)}")
    print(f"Sample Encoding: {a.bits}-bit {a.encoding}\n")

def synth(rate, channels, bits, args):
    dur = 1.0
    if args:
        try: dur = float(args[0]); args = args[1:]
        except ValueError: pass
    waves=[]; i=0
    while i < len(args):
        typ=args[i]; i+=1
        if typ in ("sine","sin","square","sawtooth","saw","triangle","tri"):
            freq=440.0
            if i < len(args):
                try: freq=float(str(args[i]).lstrip("%")); i+=1
                except ValueError: pass
            waves.append((typ,freq))
    if not waves: waves=[("sine",440.0)]
    frames=[]; n=int(round(max(0,dur)*rate))
    for k in range(n):
        t=k/rate; val=0.0
        for typ,f in waves:
            ph=(t*f)%1.0
            if typ == "square": y=1.0 if ph < .5 else -1.0
            elif typ in ("saw","sawtooth"): y=2*ph-1
            elif typ in ("triangle","tri"): y=4*abs(ph-.5)-1
            else: y=math.sin(2*math.pi*f*t)
            val += y
        frames.append([clip(val/len(waves)*0.705)]*channels)
    return Audio(rate, channels, bits, frames)

def print_stat(audio):
    vals=[x for fr in audio.samples for x in fr]; n=len(vals); dur=audio.frame_count/audio.rate if audio.rate else 0
    mx=max(vals) if vals else 0; mn=min(vals) if vals else 0; mean=sum(vals)/n if n else 0
    rms=math.sqrt(sum(x*x for x in vals)/n) if n else 0
    deltas=[abs(vals[i]-vals[i-1]) for i in range(1,n)]
    md=max(deltas) if deltas else 0; meand=sum(deltas)/len(deltas) if deltas else 0; rmsd=math.sqrt(sum(x*x for x in deltas)/len(deltas)) if deltas else 0
    e=sys.stderr
    print(f"Samples read:        {audio.frame_count:10d}", file=e)
    print(f"Length (seconds):     {dur:9.6f}", file=e)
    print("Scaled by:         2147483647.0", file=e)
    print(f"Maximum amplitude:    {mx:9.6f}", file=e)
    print(f"Minimum amplitude:   {mn:9.6f}", file=e)
    print(f"Midline amplitude:    {(mx+mn)/2:9.6f}", file=e)
    print(f"Mean    norm:         {(sum(abs(x) for x in vals)/n if n else 0):9.6f}", file=e)
    print(f"Mean    amplitude:    {mean:9.6f}", file=e)
    print(f"RMS     amplitude:    {rms:9.6f}", file=e)
    print(f"Maximum delta:        {md:9.6f}", file=e)
    print("Minimum delta:         0.000000", file=e)
    print(f"Mean    delta:        {meand:9.6f}", file=e)
    print(f"RMS     delta:        {rmsd:9.6f}", file=e)
    print("Rough   frequency:          0", file=e)
    adj = (1.0/max(abs(mx),abs(mn))) if max(abs(mx),abs(mn)) else 1.0
    print(f"Volume adjustment:    {adj:9.3f}", file=e)

def apply_effects(audio, effects):
    i=0; sink=False
    while i < len(effects):
        name=effects[i]; i+=1
        if name in (":", "newfile", "restart"): continue
        if name == "trim":
            start = parse_time(effects[i], audio.rate) if i < len(effects) else 0; i += 1
            if i < len(effects) and effects[i] not in EFFECTS:
                ln = parse_time(effects[i], audio.rate); i += 1; audio.samples = audio.samples[start:start+ln]
            else: audio.samples = audio.samples[start:]
        elif name == "reverse": audio.samples = list(reversed(audio.samples))
        elif name in ("vol", "gain"):
            factor = 1.0
            if name == "gain":
                while i < len(effects) and effects[i].startswith("-"): i += 1
                if i < len(effects) and effects[i] not in EFFECTS:
                    try: factor = 10 ** (float(effects[i]) / 20.0); i += 1
                    except ValueError: pass
            elif i < len(effects):
                try: factor = float(effects[i]); i += 1
                except ValueError: pass
            audio.samples = [[clip(x*factor) for x in fr] for fr in audio.samples]
        elif name == "norm":
            peak = max([abs(x) for fr in audio.samples for x in fr] or [0])
            if peak > 0: audio.samples = [[clip(x/peak) for x in fr] for fr in audio.samples]
        elif name == "channels" and i < len(effects):
            newc = int(effects[i]); i += 1; ns=[]
            for fr in audio.samples:
                if newc == len(fr): ns.append(fr[:])
                elif newc == 1: ns.append([sum(fr)/len(fr)])
                else: ns.append([(fr[c] if c < len(fr) else fr[-1]) for c in range(newc)])
            audio.channels = newc; audio.samples = ns
        elif name == "rate" and i < len(effects):
            nr = parse_rate(effects[i]); i += 1
            if nr > 0 and nr != audio.rate:
                old = audio.samples; ratio = audio.rate / nr; n = int(round(len(old) / ratio)) if old else 0
                audio.samples = [old[min(len(old)-1, int(k*ratio))][:] for k in range(n)]
                audio.rate = nr
        elif name == "fade":
            if i < len(effects) and effects[i].isalpha(): i += 1
            fi = parse_time(effects[i], audio.rate) if i < len(effects) else 0; i += 1
            stop=None; fo=0
            if i < len(effects) and effects[i] not in EFFECTS: stop=parse_time(effects[i], audio.rate); i += 1
            if i < len(effects) and effects[i] not in EFFECTS: fo=parse_time(effects[i], audio.rate); i += 1
            if stop is not None: audio.samples = audio.samples[:stop]
            n=len(audio.samples)
            for k,fr in enumerate(audio.samples):
                mul=1.0
                if fi and k < fi: mul *= k/max(1,fi)
                if fo and k >= n-fo: mul *= max(0,n-k-1)/max(1,fo)
                audio.samples[k]=[x*mul for x in fr]
        elif name in ("stat", "stats"):
            print_stat(audio); sink=True
    return audio, sink

def split_args(argv):
    info=False; info_opt=None; in_opts={"rate":8000,"channels":1,"bits":16,"type":None,"encoding":"signed"}; out_opts={}
    files=[]; effects=[]; output_seen=False; i=0
    while i < len(argv):
        a=argv[i]
        if a == "--version": print(f"{progname()}:      {VERSION}"); sys.exit(0)
        if a in ("-h","--help"): print(HELP.format(prog=progname()), end=""); sys.exit(0)
        if a == "--help-format":
            name = argv[i+1] if i+1 < len(argv) else ""
            if name in ("wav","all"): print(WAV_FORMAT.format(prog=progname()), end="")
            else: print(f"{progname()}:      {VERSION}\n\nFormat: {name}\nReads: yes\nWrites: yes")
            sys.exit(0)
        if a == "--help-effect":
            name = argv[i+1] if i+1 < len(argv) else ""
            print(f"{progname()}:      {VERSION}\n")
            if name == "all":
                for k in sorted(EFFECT_HELP): print(EFFECT_HELP[k])
            else: print(EFFECT_HELP.get(name, f"Effect usage:\n\n{name} [options]\n"))
            sys.exit(0)
        if a in ("--i","--info"): info=True; i+=1; continue
        if info and a in ("-t","-r","-c","-s","-d","-D","-b","-B","-p","-e","-a"):
            info_opt=a; i+=1; continue
        if a in ("-q","--no-show-progress","--clobber","-D","-G","-S","-m","-M","-T","--ignore-length","--no-glob","-L","-B","-x","-N","-X"):
            i+=1; continue
        if a == "--norm": effects.append("norm"); i+=1; continue
        if a.startswith("-V"): i+=1; continue
        if a in ("--buffer","--input-buffer","--temp","--combine","--replay-gain","--plot","--play-rate-arg","-C","--compression","--comment","--add-comment","--comment-file","--endian"):
            i += 2; continue
        if (a.startswith("-r") and len(a) > 2 and not a.startswith("--")):
            (out_opts if output_seen else in_opts)["rate"] = parse_rate(a[2:]); i+=1; continue
        if (a.startswith("-c") and len(a) > 2 and not a.startswith("--")):
            (out_opts if output_seen else in_opts)["channels"] = int(a[2:]); i+=1; continue
        if (a.startswith("-b") and len(a) > 2 and not a.startswith("--")):
            (out_opts if output_seen else in_opts)["bits"] = int(a[2:]); i+=1; continue
        if a in ("-r","--rate"):
            (out_opts if output_seen else in_opts)["rate"] = parse_rate(argv[i+1]); i+=2; continue
        if a in ("-c","--channels"):
            (out_opts if output_seen else in_opts)["channels"] = int(argv[i+1]); i+=2; continue
        if a in ("-b","--bits"):
            (out_opts if output_seen else in_opts)["bits"] = int(argv[i+1]); i+=2; continue
        if a in ("-e","--encoding"):
            (out_opts if output_seen else in_opts)["encoding"] = argv[i+1].lower(); i+=2; continue
        if a in ("-t","--type"):
            (out_opts if output_seen else in_opts)["type"] = argv[i+1].lower(); i+=2; continue
        if a in ("-v","--volume"):
            effects.extend(["vol", argv[i+1]]); i+=2; continue
        if a in EFFECTS or a == ":": effects.extend(argv[i:]); break
        files.append(a); output_seen = len(files) >= 1; i+=1
    return info, info_opt, in_opts, out_opts, files, effects

def main():
    argv=sys.argv[1:]
    if not argv:
        print(f"{progname()} FAIL sox: No input filenames specified\n", file=sys.stderr)
        print(HELP.format(prog=progname()), end="", file=sys.stderr); return 1
    info, info_opt, in_opts, out_opts, files, effects = split_args(argv)
    if info:
        if not files: return 2
        for f in files: soxi(f, info_opt)
        return 0
    if len(files) < 2 and not (files and files[0] == "-n"):
        print(f"{progname()} FAIL sox: Not enough input filenames specified", file=sys.stderr); return 1
    outfile = files[-1]; input_files = files[:-1]
    if input_files and input_files[0] == "-n":
        synth_args=[]
        if "synth" in effects:
            idx=effects.index("synth"); j=idx+1
            while j < len(effects) and effects[j] not in (EFFECTS - {"synth"}): synth_args.append(effects[j]); j+=1
            effects = effects[:idx] + effects[j:]
        audio = synth(out_opts.get("rate", in_opts.get("rate",8000)), out_opts.get("channels", in_opts.get("channels",1)), out_opts.get("bits", in_opts.get("bits",16)), synth_args)
    else:
        audios=[]
        for f in input_files:
            typ=in_opts.get("type") or ("wav" if f.lower().endswith(".wav") else "au" if f.lower().endswith((".au",".snd")) else "raw")
            if typ in ("raw","s16","s8","u8"):
                audios.append(read_raw(f, in_opts.get("rate",8000), in_opts.get("channels",1), in_opts.get("bits",16), in_opts.get("encoding","signed")))
            elif typ in ("au","snd"):
                audios.append(read_au(f))
            else: audios.append(read_wav(f))
        audio = audios[0]
        for a in audios[1:]: audio.samples.extend(a.samples)
    if "rate" in out_opts: audio.rate=out_opts["rate"]
    if "channels" in out_opts and out_opts["channels"] != audio.channels:
        audio,_ = apply_effects(audio, ["channels", str(out_opts["channels"])] )
    if "bits" in out_opts: audio.bits=out_opts["bits"]
    audio, sink = apply_effects(audio, effects)
    if outfile == "-n" or sink: return 0
    typ = out_opts.get("type") or ("raw" if outfile.lower().endswith((".raw",".s16",".s8",".u8")) else "au" if outfile.lower().endswith((".au",".snd")) else "wav")
    if typ in ("raw","s16","s8","u8"): write_raw(audio, outfile)
    elif typ in ("au","snd"): write_au(audio, outfile)
    else: write_wav(audio, outfile)
    return 0

if __name__ == "__main__":
    try: sys.exit(main())
    except BrokenPipeError: sys.exit(0)
    except Exception as e:
        print(f"{progname()} FAIL sox: {e}", file=sys.stderr); sys.exit(2)
