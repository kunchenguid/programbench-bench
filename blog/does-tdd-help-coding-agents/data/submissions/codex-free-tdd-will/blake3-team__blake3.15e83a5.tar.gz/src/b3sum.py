#!/usr/bin/env python3
import argparse
import re
import sys


OUT_LEN = 32
KEY_LEN = 32
BLOCK_LEN = 64
CHUNK_LEN = 1024

CHUNK_START = 1
CHUNK_END = 2
PARENT = 4
ROOT = 8
KEYED_HASH = 16
DERIVE_KEY_CONTEXT = 32
DERIVE_KEY_MATERIAL = 64

IV = [
    0x6A09E667,
    0xBB67AE85,
    0x3C6EF372,
    0xA54FF53A,
    0x510E527F,
    0x9B05688C,
    0x1F83D9AB,
    0x5BE0CD19,
]

MSG_PERMUTATION = [2, 6, 3, 10, 7, 0, 4, 13, 1, 11, 12, 5, 9, 14, 15, 8]


def rotr32(x, n):
    return ((x >> n) | ((x << (32 - n)) & 0xFFFFFFFF)) & 0xFFFFFFFF


def words_from_bytes(buf):
    return [int.from_bytes(buf[i : i + 4], "little") for i in range(0, len(buf), 4)]


def block_words(block):
    return words_from_bytes(block.ljust(BLOCK_LEN, b"\0"))


def words_to_bytes(words):
    return b"".join((w & 0xFFFFFFFF).to_bytes(4, "little") for w in words)


def g(state, a, b, c, d, mx, my):
    state[a] = (state[a] + state[b] + mx) & 0xFFFFFFFF
    state[d] = rotr32(state[d] ^ state[a], 16)
    state[c] = (state[c] + state[d]) & 0xFFFFFFFF
    state[b] = rotr32(state[b] ^ state[c], 12)
    state[a] = (state[a] + state[b] + my) & 0xFFFFFFFF
    state[d] = rotr32(state[d] ^ state[a], 8)
    state[c] = (state[c] + state[d]) & 0xFFFFFFFF
    state[b] = rotr32(state[b] ^ state[c], 7)


def round_fn(state, m):
    g(state, 0, 4, 8, 12, m[0], m[1])
    g(state, 1, 5, 9, 13, m[2], m[3])
    g(state, 2, 6, 10, 14, m[4], m[5])
    g(state, 3, 7, 11, 15, m[6], m[7])
    g(state, 0, 5, 10, 15, m[8], m[9])
    g(state, 1, 6, 11, 12, m[10], m[11])
    g(state, 2, 7, 8, 13, m[12], m[13])
    g(state, 3, 4, 9, 14, m[14], m[15])


def permute(m):
    return [m[i] for i in MSG_PERMUTATION]


def compress(cv, block, counter, block_len, flags):
    state = cv[:] + IV[:4] + [
        counter & 0xFFFFFFFF,
        (counter >> 32) & 0xFFFFFFFF,
        block_len,
        flags,
    ]
    m = block[:]
    for round_index in range(7):
        round_fn(state, m)
        if round_index != 6:
            m = permute(m)
    for i in range(8):
        state[i] ^= state[i + 8]
        state[i + 8] ^= cv[i]
    return [x & 0xFFFFFFFF for x in state]


class Node:
    def __init__(self, cv, block, counter, block_len, flags):
        self.cv = cv
        self.block = block
        self.counter = counter
        self.block_len = block_len
        self.flags = flags

    def chaining_value(self):
        return compress(self.cv, self.block, self.counter, self.block_len, self.flags)[:8]

    def root_output_block(self, output_counter):
        return words_to_bytes(
            compress(
                self.cv,
                self.block,
                output_counter,
                self.block_len,
                self.flags | ROOT,
            )
        )


def chunk_node(chunk, chunk_index, key_words, flags):
    cv = key_words[:]
    offset = 0
    while offset + BLOCK_LEN < len(chunk):
        block = chunk[offset : offset + BLOCK_LEN]
        block_flags = flags
        if offset == 0:
            block_flags |= CHUNK_START
        cv = compress(cv, block_words(block), chunk_index, BLOCK_LEN, block_flags)[:8]
        offset += BLOCK_LEN

    last = chunk[offset:]
    last_flags = flags | CHUNK_END
    if offset == 0:
        last_flags |= CHUNK_START
    return Node(cv, block_words(last), chunk_index, len(last), last_flags)


def parent_node(left_cv, right_cv, key_words, flags):
    return Node(key_words[:], left_cv + right_cv, 0, BLOCK_LEN, flags | PARENT)


def root_node(data, key_words=None, flags=0):
    if key_words is None:
        key_words = IV[:]
    chunks = [
        chunk_node(data[offset : offset + CHUNK_LEN], offset // CHUNK_LEN, key_words, flags)
        for offset in range(0, len(data), CHUNK_LEN)
    ]
    if not chunks:
        chunks = [chunk_node(b"", 0, key_words, flags)]
    return subtree_node(chunks, key_words, flags)


def subtree_node(nodes, key_words, flags):
    if len(nodes) == 1:
        return nodes[0]
    split = 1 << ((len(nodes) - 1).bit_length() - 1)
    left = subtree_node(nodes[:split], key_words, flags).chaining_value()
    right = subtree_node(nodes[split:], key_words, flags).chaining_value()
    return parent_node(left, right, key_words, flags)


def blake3(data, out_len=OUT_LEN, seek=0, key_words=None, flags=0):
    node = root_node(data, key_words, flags)
    out = bytearray()
    block_counter = seek // BLOCK_LEN
    skip = seek % BLOCK_LEN
    while len(out) < out_len + skip:
        out.extend(node.root_output_block(block_counter))
        block_counter += 1
    return bytes(out[skip : skip + out_len])


def parse_args(argv):
    p = argparse.ArgumentParser(
        prog="executable",
        formatter_class=argparse.RawTextHelpFormatter,
        add_help=False,
    )
    p.add_argument("--keyed", action="store_true")
    p.add_argument("--derive-key")
    p.add_argument("-l", "--length", type=int, default=32)
    p.add_argument("--seek", type=int, default=0)
    p.add_argument("--num-threads", type=int)
    p.add_argument("--no-mmap", action="store_true")
    p.add_argument("--no-names", action="store_true")
    p.add_argument("--raw", action="store_true")
    p.add_argument("--tag", action="store_true")
    p.add_argument("-c", "--check", action="store_true")
    p.add_argument("--quiet", action="store_true")
    p.add_argument("-h", "--help", action="store_true")
    p.add_argument("-V", "--version", action="store_true")
    p.add_argument("files", nargs="*")
    return p.parse_args(argv)


def print_help():
    sys.stdout.write(
        """Usage: executable [OPTIONS] [FILE]...

Arguments:
  [FILE]...  Files to hash, or checkfiles to check

Options:
      --keyed                 Use the keyed mode, reading the 32-byte key from stdin
      --derive-key <CONTEXT>  Use the key derivation mode, with the given context string
  -l, --length <LEN>          The number of output bytes, before hex encoding [default: 32]
      --seek <SEEK>           The starting output byte offset, before hex encoding [default: 0]
      --num-threads <NUM>     The maximum number of threads to use
      --no-mmap               Disable memory mapping
      --no-names              Omit filenames in the output
      --raw                   Write raw output bytes to stdout, rather than hex
      --tag                   Output BSD-style checksums: BLAKE3 ([FILE]) = [HASH]
  -c, --check                 Read BLAKE3 sums from the [FILE]s and check them
      --quiet                 Skip printing OK for each checked file
  -h, --help                  Print help (see more with '--help')
  -V, --version               Print version
"""
    )


def read_input(path):
    if path == "-":
        return sys.stdin.buffer.read()
    with open(path, "rb") as f:
        return f.read()


def parse_check_line(line):
    line = line.rstrip("\n")
    bsd = re.fullmatch(r"BLAKE3 \((.*)\) = ([0-9a-fA-F]+)", line)
    if bsd:
        return bsd.group(2).lower(), bsd.group(1)
    parts = line.split(None, 1)
    if len(parts) != 2:
        return None, None
    filename = parts[1]
    if filename.startswith("*") or filename.startswith(" "):
        filename = filename[1:]
    return parts[0].lower(), filename


def check_files(paths, key_words, flags, quiet):
    failed = 0
    invalid = 0
    for check_path in paths or ["-"]:
        try:
            text = sys.stdin.read() if check_path == "-" else open(check_path, "r", encoding="utf-8").read()
        except OSError as e:
            print(f"executable: {check_path}: {e.strerror}", file=sys.stderr)
            return 1
        for line in text.splitlines():
            if not line:
                continue
            expected, filename = parse_check_line(line)
            if expected is None or len(expected) != 64:
                print("b3sum: Invalid hash length", file=sys.stderr)
                invalid += 1
                continue
            try:
                bytes.fromhex(expected)
            except ValueError:
                print("b3sum: Invalid character in hash", file=sys.stderr)
                invalid += 1
                continue
            try:
                data = read_input(filename)
                actual = blake3(data, len(expected) // 2, 0, key_words, flags).hex()
            except OSError as e:
                print(f"b3sum: {filename}: {e.strerror}", file=sys.stderr)
                failed += 1
                continue
            if actual == expected:
                if not quiet:
                    print(f"{filename}: OK")
            else:
                print(f"{filename}: FAILED")
                failed += 1
    if failed:
        noun = "checksum" if failed == 1 else "checksums"
        print(f"b3sum: WARNING: {failed} computed {noun} did NOT match", file=sys.stderr)
    return 1 if failed or invalid else 0


def main(argv=None):
    args = parse_args(sys.argv[1:] if argv is None else argv)
    if args.help:
        print_help()
        return 0
    if args.version:
        print("b3sum 1.8.4")
        return 0

    key_words = IV[:]
    flags = 0
    if args.keyed:
        if not args.files:
            print(
                "error: the following required arguments were not provided:\n"
                "  <FILE>...\n\n"
                "Usage: executable --keyed <FILE>...\n\n"
                "For more information, try '--help'.",
                file=sys.stderr,
            )
            return 2
        key = sys.stdin.buffer.read(KEY_LEN)
        if len(key) != KEY_LEN:
            print(f"Error: expected 32 key bytes from stdin, found {len(key)}", file=sys.stderr)
            return 1
        key_words = words_from_bytes(key)
        flags = KEYED_HASH
    elif args.derive_key is not None:
        context_key = blake3(args.derive_key.encode(), OUT_LEN, 0, IV[:], DERIVE_KEY_CONTEXT)
        key_words = words_from_bytes(context_key)
        flags = DERIVE_KEY_MATERIAL

    if args.check:
        return check_files(args.files, key_words, flags, args.quiet)

    files = args.files or ["-"]
    if args.raw and len(files) != 1:
        print("Error: Only one filename can be provided when using --raw", file=sys.stderr)
        return 1

    for path in files:
        try:
            data = read_input(path)
        except OSError as e:
            print(f"executable: {path}: {e.strerror}", file=sys.stderr)
            return 1
        digest = blake3(data, args.length, args.seek, key_words, flags)
        if args.raw:
            sys.stdout.buffer.write(digest)
        elif args.no_names:
            print(digest.hex())
        elif args.tag:
            print(f"BLAKE3 ({path}) = {digest.hex()}")
        else:
            print(f"{digest.hex()}  {path}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
