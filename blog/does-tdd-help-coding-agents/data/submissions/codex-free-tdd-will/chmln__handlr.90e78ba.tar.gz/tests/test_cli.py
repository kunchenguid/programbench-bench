import json, os, subprocess, tempfile, unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
BIN = ROOT / "executable"


def build():
    subprocess.run(["bash", "compile.sh"], cwd=ROOT, check=True)


def run(args, env=None):
    e = os.environ.copy()
    if env:
        e.update(env)
    return subprocess.run([str(BIN)] + args, text=True, capture_output=True, env=e)


def isolated_env(tmp):
    return {
        "HOME": str(tmp / "home"),
        "XDG_CONFIG_HOME": str(tmp / "config"),
        "XDG_DATA_HOME": str(tmp / "data"),
        "XDG_DATA_DIRS": str(tmp / "sys"),
    }


class HandlrCliTests(unittest.TestCase):
    def test_top_level_help_matches_observed_contract(self):
        build()
        p = run(["--help"])
        self.assertEqual(p.returncode, 0)
        self.assertTrue(p.stdout.startswith("handlr 0.6.4\n\nUSAGE:\n    executable <SUBCOMMAND>\n"), p.stdout)
        self.assertIn("    get       Get handler for this mime/extension\n", p.stdout)

    def test_set_get_add_and_list_defaults(self):
        build()
        with tempfile.TemporaryDirectory() as d:
            tmp = Path(d)
            env = isolated_env(tmp)
            apps = tmp / "data" / "applications"
            apps.mkdir(parents=True)
            (apps / "foo.desktop").write_text("[Desktop Entry]\nType=Application\nName=Foo\nExec=echo FOO %u\nMimeType=text/plain;\n")
            (apps / "bar.desktop").write_text("[Desktop Entry]\nType=Application\nName=Bar\nExec=echo BAR %F\nMimeType=text/plain;\n")

            self.assertEqual(run(["set", "text/plain", "foo.desktop"], env).returncode, 0)
            self.assertEqual((tmp / "config" / "mimeapps.list").read_text(), "[Added Associations]\n\n[Default Applications]\ntext/plain=foo.desktop;\n")
            got = run(["get", "text/plain"], env)
            self.assertEqual(got.returncode, 0)
            self.assertEqual(got.stdout, "foo.desktop\n")

            self.assertEqual(run(["add", "text/plain", "bar.desktop"], env).returncode, 0)
            listed = run(["list"], env)
            self.assertEqual(listed.returncode, 0)
            self.assertIn("│ text/plain │ foo.desktop, bar.desktop │", listed.stdout)
            all_listed = run(["list", "--all"], env)
            self.assertIn("│ text/plain │ foo.desktop, bar.desktop │", all_listed.stdout)

    def test_json_get_and_launch_expand_desktop_exec_fields(self):
        build()
        with tempfile.TemporaryDirectory() as d:
            tmp = Path(d)
            env = isolated_env(tmp)
            apps = tmp / "data" / "applications"
            apps.mkdir(parents=True)
            out = tmp / "out"
            (apps / "foo.desktop").write_text(
                "[Desktop Entry]\nType=Application\nName=Foo App\n"
                f"Exec=sh -c 'echo ARGS:\"$@\" >> {out}' dummy %u %f %F %U %i %c %k %% --end\n"
                "MimeType=text/plain;x-scheme-handler/https;\n"
            )
            self.assertEqual(run(["set", "text/plain", "foo.desktop"], env).returncode, 0)

            meta = run(["get", "--json", "text/plain"], env)
            self.assertEqual(meta.returncode, 0)
            self.assertEqual(json.loads(meta.stdout)["handler"], "foo.desktop")
            self.assertEqual(json.loads(meta.stdout)["name"], "Foo App")

            launched = run(["launch", "text/plain", "abc", "def"], env)
            self.assertEqual(launched.returncode, 0, launched.stderr)
            import time
            time.sleep(0.2)
            self.assertEqual(out.read_text(), "ARGS:abc def abc def abc def abc def %i %c %k %% --end\n")

if __name__ == "__main__":
    unittest.main()
