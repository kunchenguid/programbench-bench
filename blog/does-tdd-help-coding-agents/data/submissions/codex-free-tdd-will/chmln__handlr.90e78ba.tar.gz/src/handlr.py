#!/usr/bin/env python3
import json
import os
import shlex
import subprocess
import sys
from pathlib import Path


VERSION = "handlr 0.6.4"


TOP_HELP = """handlr 0.6.4

USAGE:
    executable <SUBCOMMAND>

FLAGS:
    -h, --help       Prints help information
    -V, --version    Prints version information

SUBCOMMANDS:
    list      List default apps and the associated handlers
    open      Open a path/URL with its default handler
    set       Set the default handler for mime/extension
    unset     Unset the default handler for mime/extension
    launch    Launch the handler for specified extension/mime with optional arguments
    get       Get handler for this mime/extension
    add       Add a handler for given mime/extension Note that the first handler is the default
"""

SUB_HELP = {
    "list": """executable-list 
List default apps and the associated handlers

USAGE:
    executable list [FLAGS]

FLAGS:
    -a, --all        
    -h, --help       Prints help information
    -V, --version    Prints version information
""",
    "open": """executable-open 
Open a path/URL with its default handler

USAGE:
    executable open <paths>...

ARGS:
    <paths>...    

FLAGS:
    -h, --help       Prints help information
    -V, --version    Prints version information
""",
    "set": """executable-set 
Set the default handler for mime/extension

USAGE:
    executable set <mime> <handler>

ARGS:
    <mime>       
    <handler>    

FLAGS:
    -h, --help       Prints help information
    -V, --version    Prints version information
""",
    "unset": """executable-unset 
Unset the default handler for mime/extension

USAGE:
    executable unset <mime>

ARGS:
    <mime>    

FLAGS:
    -h, --help       Prints help information
    -V, --version    Prints version information
""",
    "launch": """executable-launch 
Launch the handler for specified extension/mime with optional arguments

USAGE:
    executable launch <mime> [args]...

ARGS:
    <mime>       
    <args>...    

FLAGS:
    -h, --help       Prints help information
    -V, --version    Prints version information
""",
    "get": """executable-get 
Get handler for this mime/extension

USAGE:
    executable get [FLAGS] <mime>

ARGS:
    <mime>    

FLAGS:
        --json       
    -h, --help       Prints help information
    -V, --version    Prints version information
""",
    "add": """executable-add 
Add a handler for given mime/extension Note that the first handler is the default

USAGE:
    executable add <mime> <handler>

ARGS:
    <mime>       
    <handler>    

FLAGS:
    -h, --help       Prints help information
    -V, --version    Prints version information
""",
}


def xdg_config_home():
    return Path(os.environ.get("XDG_CONFIG_HOME") or Path.home() / ".config")


def xdg_data_home():
    return Path(os.environ.get("XDG_DATA_HOME") or Path.home() / ".local" / "share")


def xdg_data_dirs():
    raw = os.environ.get("XDG_DATA_DIRS", "/usr/local/share:/usr/share")
    return [Path(p) for p in raw.split(":") if p]


def mimeapps_path():
    return xdg_config_home() / "mimeapps.list"


def ensure_handlr_config():
    p = xdg_config_home() / "handlr" / "handlr.toml"
    if not p.exists():
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_text("enable_selector = false\nselector = \"rofi -dmenu -i -p 'Open With: '\"\n")


def parse_desktop(path):
    vals = {}
    try:
        for line in path.read_text(errors="replace").splitlines():
            if "=" in line and not line.lstrip().startswith("#"):
                k, v = line.split("=", 1)
                vals[k] = v
    except OSError:
        return None
    return {
        "id": path.name,
        "name": vals.get("Name", path.stem),
        "exec": vals.get("Exec", ""),
        "mimes": [m for m in vals.get("MimeType", "").split(";") if m],
    }


def desktop_entries():
    entries = {}
    dirs = [xdg_data_home() / "applications"] + [d / "applications" for d in xdg_data_dirs()]
    home_local = Path.home() / ".local" / "share" / "applications"
    if home_local not in dirs:
        dirs.append(home_local)
    for d in dirs:
        if d.is_dir():
            for p in d.glob("*.desktop"):
                ent = parse_desktop(p)
                if ent and ent["id"] not in entries:
                    entries[ent["id"]] = ent
    return entries


def validate_mime(arg):
    if arg.startswith("."):
        print(f"error: Invalid value for '<mime>': could not figure out the mime type of '{arg}'\n\nFor more information try --help", file=sys.stderr)
        return None
    if "/" not in arg:
        print("error: Invalid value for '<mime>': mime parse error: a slash (/) was missing between the type and subtype\n\nFor more information try --help", file=sys.stderr)
        return None
    if "://" in arg:
        print("error: Invalid value for '<mime>': mime parse error: an invalid token was encountered, 3A at position 5\n\nFor more information try --help", file=sys.stderr)
        return None
    return arg


def read_mimeapps():
    p = mimeapps_path()
    sections = {"Added Associations": {}, "Default Applications": {}}
    cur = None
    if not p.exists():
        return sections
    for line in p.read_text(errors="replace").splitlines():
        s = line.strip()
        if s.startswith("[") and s.endswith("]"):
            cur = s[1:-1]
            sections.setdefault(cur, {})
        elif cur and "=" in line:
            k, v = line.split("=", 1)
            sections[cur][k] = [x for x in v.split(";") if x]
    return sections


def write_mimeapps(sections):
    ensure_handlr_config()
    p = mimeapps_path()
    p.parent.mkdir(parents=True, exist_ok=True)
    out = ["[Added Associations]"]
    for k, vals in sections.get("Added Associations", {}).items():
        if vals:
            out.append(f"{k}={';'.join(vals)};")
    out.append("")
    out.append("[Default Applications]")
    for k, vals in sections.get("Default Applications", {}).items():
        if vals:
            out.append(f"{k}={';'.join(vals)};")
    p.write_text("\n".join(out) + "\n")


def handlers_for(mime, sections=None):
    if sections is None:
        sections = read_mimeapps()
    vals = sections.get("Default Applications", {}).get(mime, [])
    if vals:
        return vals
    matches = []
    for did, ent in desktop_entries().items():
        if mime in ent["mimes"] or (mime.startswith("x-scheme-handler/") and mime in ent["mimes"]):
            matches.append(did)
    return matches


def require_handler(handler):
    if handler not in desktop_entries():
        print(f"error: Invalid value for '<handler>': no handlers found for '{handler}'\n\nFor more information try --help", file=sys.stderr)
        return False
    return True


def table(rows):
    if not rows:
        return "┌──┐\n│  │\n└──┘\n"
    w1 = max(len(r[0]) for r in rows)
    w2 = max(len(r[1]) for r in rows)
    lines = ["┌" + "─" * (w1 + 2) + "┬" + "─" * (w2 + 2) + "┐"]
    for a, b in rows:
        lines.append(f"│ {a.ljust(w1)} │ {b.ljust(w2)} │")
    lines.append("└" + "─" * (w1 + 2) + "┴" + "─" * (w2 + 2) + "┘")
    return "\n".join(lines) + "\n"


def cmd_set(args, append=False):
    if len(args) != 2:
        print(SUB_HELP["add" if append else "set"], end="")
        return 1
    mime = validate_mime(args[0])
    if not mime:
        return 2
    handler = args[1]
    if not require_handler(handler):
        return 2
    sections = read_mimeapps()
    defaults = sections.setdefault("Default Applications", {})
    cur = defaults.get(mime, [])
    if append:
        defaults[mime] = cur + ([] if handler in cur else [handler])
    else:
        defaults[mime] = [handler] + [h for h in cur if h != handler]
    write_mimeapps(sections)
    return 0


def cmd_get(args):
    want_json = False
    if args and args[0] == "--json":
        want_json = True
        args = args[1:]
    if len(args) != 1:
        print(SUB_HELP["get"], end="")
        return 1
    mime = validate_mime(args[0])
    if not mime:
        return 2
    hs = handlers_for(mime)
    if not hs:
        print('Error: Io(Os { code: 2, kind: NotFound, message: "No such file or directory" })', file=sys.stderr)
        return 1
    h = hs[0]
    if want_json:
        ent = desktop_entries().get(h, {"name": "", "exec": ""})
        cmd = clean_exec(ent.get("exec", ""), [])
        print(json.dumps({"handler": h, "name": ent.get("name", ""), "cmd": cmd}, separators=(",", ":")))
    else:
        print(h)
    return 0


def cmd_list(args):
    all_flag = args == ["--all"] or args == ["-a"]
    sections = read_mimeapps()
    defaults = [(k, ", ".join(v)) for k, v in sorted(sections.get("Default Applications", {}).items()) if v]
    if not all_flag:
        print(table(defaults), end="")
        return 0
    print("Default Apps")
    print(table(defaults), end="")
    print("System Apps")
    sysrows = []
    bymime = {}
    for did, ent in desktop_entries().items():
        for m in ent["mimes"]:
            bymime.setdefault(m, []).append(did)
    for m, hs in sorted(bymime.items()):
        sysrows.append((m, ", ".join(hs)))
    print(table(sysrows), end="")
    return 0


def cmd_unset(args):
    if len(args) != 1:
        print(SUB_HELP["unset"], end="")
        return 1
    mime = validate_mime(args[0])
    if not mime:
        return 2
    sections = read_mimeapps()
    sections.setdefault("Default Applications", {}).pop(mime, None)
    write_mimeapps(sections)
    return 0


def exec_tokens(spec, files):
    try:
        parts = shlex.split(spec)
    except ValueError:
        parts = spec.split()
    out = []
    for tok in parts:
        if tok in ("%f", "%u", "%F", "%U"):
            out.extend(files)
        elif tok in ("%i", "%c", "%k"):
            out.append(tok)
        elif tok == "%%":
            out.append("%%")
        elif tok.startswith("%"):
            continue
        else:
            out.append(tok)
    return out


def clean_exec(spec, files):
    return " ".join(exec_tokens(spec, files))


def launch(mime, files):
    hs = handlers_for(mime)
    if not hs:
        print('Error: Io(Os { code: 2, kind: NotFound, message: "No such file or directory" })', file=sys.stderr)
        return 1
    ent = desktop_entries().get(hs[0])
    if not ent or not ent.get("exec"):
        return 1
    cmd = exec_tokens(ent["exec"], files)
    try:
        subprocess.Popen(cmd)
    except OSError as e:
        print(f"Error: Io({e!r})", file=sys.stderr)
        return 1
    return 0


def cmd_launch(args):
    if not args:
        print(SUB_HELP["launch"], end="")
        return 1
    mime = validate_mime(args[0])
    if not mime:
        return 2
    return launch(mime, args[1:])


def guess_mime_path(path):
    if "://" in path:
        return "x-scheme-handler/" + path.split(":", 1)[0]
    p = Path(path)
    if not p.exists():
        print('Error: Io(Os { code: 2, kind: NotFound, message: "No such file or directory" })', file=sys.stderr)
        return None
    ext = p.suffix.lower()
    return {
        ".txt": "text/plain",
        ".text": "text/plain",
        ".md": "text/markdown",
        ".png": "image/png",
        ".jpg": "image/jpeg",
        ".jpeg": "image/jpeg",
        ".pdf": "application/pdf",
        ".html": "text/html",
        ".htm": "text/html",
    }.get(ext, "application/octet-stream")


def cmd_open(args):
    if not args:
        print(SUB_HELP["open"], end="")
        return 1
    status = 0
    for path in args:
        mime = guess_mime_path(path)
        if not mime:
            status = 1
            continue
        status = max(status, launch(mime, [path]))
    return status


def main(argv):
    if not argv or argv[0] in ("-h", "--help"):
        print(TOP_HELP, end="")
        return 0
    if argv[0] in ("-V", "--version"):
        print(VERSION)
        return 0
    sub, args = argv[0], argv[1:]
    if sub in SUB_HELP and (not args or args[0] not in ("-h", "--help")):
        if sub == "set":
            return cmd_set(args)
        if sub == "add":
            return cmd_set(args, append=True)
        if sub == "get":
            return cmd_get(args)
        if sub == "list":
            return cmd_list(args)
        if sub == "unset":
            return cmd_unset(args)
        if sub == "launch":
            return cmd_launch(args)
        if sub == "open":
            return cmd_open(args)
    if sub in SUB_HELP:
        print(SUB_HELP[sub], end="")
        return 0
    print(TOP_HELP, end="")
    return 1


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
