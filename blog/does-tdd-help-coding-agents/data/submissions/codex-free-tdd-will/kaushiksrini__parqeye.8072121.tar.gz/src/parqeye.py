#!/usr/bin/env python3
import os
import sys
from dataclasses import dataclass, field

HELP = """Command line tool to visualize parquet files

Usage: executable <PATH>

Arguments:
  <PATH>  Path to the parquet file

Options:
  -h, --help     Print help
  -V, --version  Print version
"""

MISSING = """error: the following required arguments were not provided:
  <PATH>

Usage: executable <PATH>

For more information, try '--help'.
"""

T_STOP = 0
T_TRUE = 1
T_FALSE = 2
T_BYTE = 3
T_I16 = 4
T_I32 = 5
T_I64 = 6
T_DOUBLE = 7
T_BINARY = 8
T_LIST = 9
T_SET = 10
T_MAP = 11
T_STRUCT = 12

PHYSICAL_TYPES = {
    0: "BOOLEAN",
    1: "INT32",
    2: "INT64",
    3: "INT96",
    4: "FLOAT",
    5: "DOUBLE",
    6: "BYTE_ARRAY",
    7: "FIXED_LEN_BYTE_ARRAY",
}

REPETITION_TYPES = {0: "REQUIRED", 1: "OPTIONAL", 2: "REPEATED"}
CODECS = {
    0: "UNCOMPRESSED",
    1: "SNAPPY",
    2: "GZIP",
    3: "LZO",
    4: "BROTLI",
    5: "LZ4",
    6: "ZSTD",
    7: "LZ4_RAW",
}
ENCODINGS = {
    0: "PLAIN",
    2: "PLAIN_DICTIONARY",
    3: "RLE",
    4: "BIT_PACKED",
    5: "DELTA_BINARY_PACKED",
    6: "DELTA_LENGTH_BYTE_ARRAY",
    7: "DELTA_BYTE_ARRAY",
    8: "RLE_DICTIONARY",
    9: "BYTE_STREAM_SPLIT",
}


class ParquetError(Exception):
    pass


class CompactReader:
    def __init__(self, data):
        self.data = data
        self.pos = 0

    def read_byte(self):
        if self.pos >= len(self.data):
            raise ParquetError("Unexpected end of metadata")
        b = self.data[self.pos]
        self.pos += 1
        return b

    def read_varint(self):
        shift = 0
        result = 0
        while True:
            b = self.read_byte()
            result |= (b & 0x7F) << shift
            if not b & 0x80:
                return result
            shift += 7
            if shift > 70:
                raise ParquetError("Invalid varint")

    def read_zigzag(self):
        n = self.read_varint()
        return (n >> 1) ^ -(n & 1)

    def read_binary(self):
        n = self.read_varint()
        if self.pos + n > len(self.data):
            raise ParquetError("Unexpected end of binary field")
        raw = self.data[self.pos : self.pos + n]
        self.pos += n
        return raw

    def read_string(self):
        return self.read_binary().decode("utf-8", "replace")

    def read_double(self):
        import struct

        if self.pos + 8 > len(self.data):
            raise ParquetError("Unexpected end of double")
        value = struct.unpack("<d", self.data[self.pos : self.pos + 8])[0]
        self.pos += 8
        return value

    def read_field_header(self, previous_id):
        header = self.read_byte()
        field_type = header & 0x0F
        if field_type == T_STOP:
            return 0, T_STOP
        delta = header >> 4
        if delta:
            return previous_id + delta, field_type
        return self.read_zigzag(), field_type

    def read_list_header(self):
        header = self.read_byte()
        size = header >> 4
        elem_type = header & 0x0F
        if size == 15:
            size = self.read_varint()
        return size, elem_type

    def skip(self, field_type):
        if field_type in (T_TRUE, T_FALSE):
            return
        if field_type == T_BYTE:
            self.read_byte()
        elif field_type in (T_I16, T_I32, T_I64):
            self.read_zigzag()
        elif field_type == T_DOUBLE:
            self.read_double()
        elif field_type == T_BINARY:
            self.read_binary()
        elif field_type == T_STRUCT:
            self.skip_struct()
        elif field_type in (T_LIST, T_SET):
            size, elem_type = self.read_list_header()
            for _ in range(size):
                self.skip(elem_type)
        elif field_type == T_MAP:
            size = self.read_varint()
            if size:
                key_value = self.read_byte()
                key_type = key_value >> 4
                value_type = key_value & 0x0F
                for _ in range(size):
                    self.skip(key_type)
                    self.skip(value_type)
        else:
            raise ParquetError(f"Unsupported compact type {field_type}")

    def skip_struct(self):
        previous = 0
        while True:
            field_id, field_type = self.read_field_header(previous)
            if field_type == T_STOP:
                return
            previous = field_id
            self.skip(field_type)


@dataclass
class SchemaElement:
    name: str = ""
    physical_type: int | None = None
    repetition_type: int | None = None
    num_children: int | None = None


@dataclass
class ColumnMeta:
    path: list[str] = field(default_factory=list)
    physical_type: int | None = None
    codec: int | None = None
    encodings: list[int] = field(default_factory=list)
    compressed_size: int = 0
    uncompressed_size: int = 0


@dataclass
class RowGroup:
    num_rows: int = 0
    total_byte_size: int = 0
    columns: list[ColumnMeta] = field(default_factory=list)

    @property
    def compressed_size(self):
        return sum(c.compressed_size for c in self.columns)

    @property
    def uncompressed_size(self):
        return sum(c.uncompressed_size for c in self.columns)


@dataclass
class Metadata:
    version: int = 0
    schema: list[SchemaElement] = field(default_factory=list)
    num_rows: int = 0
    row_groups: list[RowGroup] = field(default_factory=list)
    created_by: str = ""


def parse_schema_element(reader):
    item = SchemaElement()
    previous = 0
    while True:
        field_id, field_type = reader.read_field_header(previous)
        if field_type == T_STOP:
            return item
        previous = field_id
        if field_id == 1:
            item.physical_type = reader.read_zigzag()
        elif field_id == 3:
            item.repetition_type = reader.read_zigzag()
        elif field_id == 4:
            item.name = reader.read_string()
        elif field_id == 5:
            item.num_children = reader.read_zigzag()
        else:
            reader.skip(field_type)


def parse_column_meta(reader):
    item = ColumnMeta()
    previous = 0
    while True:
        field_id, field_type = reader.read_field_header(previous)
        if field_type == T_STOP:
            return item
        previous = field_id
        if field_id == 1:
            item.physical_type = reader.read_zigzag()
        elif field_id == 2:
            size, elem_type = reader.read_list_header()
            item.encodings = [reader.read_zigzag() for _ in range(size)]
        elif field_id == 3:
            size, elem_type = reader.read_list_header()
            item.path = [reader.read_string() for _ in range(size)]
        elif field_id == 4:
            item.codec = reader.read_zigzag()
        elif field_id == 6:
            item.uncompressed_size = reader.read_zigzag()
        elif field_id == 7:
            item.compressed_size = reader.read_zigzag()
        else:
            reader.skip(field_type)


def parse_column_chunk(reader):
    meta = ColumnMeta()
    previous = 0
    while True:
        field_id, field_type = reader.read_field_header(previous)
        if field_type == T_STOP:
            return meta
        previous = field_id
        if field_id == 3:
            meta = parse_column_meta(reader)
        else:
            reader.skip(field_type)


def parse_row_group(reader):
    item = RowGroup()
    previous = 0
    while True:
        field_id, field_type = reader.read_field_header(previous)
        if field_type == T_STOP:
            return item
        previous = field_id
        if field_id == 1:
            size, elem_type = reader.read_list_header()
            item.columns = [parse_column_chunk(reader) for _ in range(size)]
        elif field_id == 2:
            item.total_byte_size = reader.read_zigzag()
        elif field_id == 3:
            item.num_rows = reader.read_zigzag()
        else:
            reader.skip(field_type)


def parse_metadata_blob(blob):
    reader = CompactReader(blob)
    meta = Metadata()
    previous = 0
    while True:
        field_id, field_type = reader.read_field_header(previous)
        if field_type == T_STOP:
            return meta
        previous = field_id
        if field_id == 1:
            meta.version = reader.read_zigzag()
        elif field_id == 2:
            size, elem_type = reader.read_list_header()
            meta.schema = [parse_schema_element(reader) for _ in range(size)]
        elif field_id == 3:
            meta.num_rows = reader.read_zigzag()
        elif field_id == 4:
            size, elem_type = reader.read_list_header()
            meta.row_groups = [parse_row_group(reader) for _ in range(size)]
        elif field_id == 6:
            meta.created_by = reader.read_string()
        else:
            reader.skip(field_type)


def read_metadata(path):
    try:
        with open(path, "rb") as fh:
            fh.seek(0, os.SEEK_END)
            size = fh.tell()
            if size < 8:
                raise ParquetError("Invalid Parquet file. Corrupt footer")
            fh.seek(size - 8)
            footer = fh.read(8)
            if footer[4:] != b"PAR1":
                raise ParquetError("Invalid Parquet file. Corrupt footer")
            meta_len = int.from_bytes(footer[:4], "little")
            if meta_len < 0 or meta_len > size - 8:
                raise ParquetError("Invalid Parquet file. Corrupt footer")
            fh.seek(size - 8 - meta_len)
            return parse_metadata_blob(fh.read(meta_len))
    except FileNotFoundError as exc:
        raise OSError("No such file or directory (os error 2)") from exc


def format_size(n):
    if n < 1024:
        return f"{n} B"
    if n < 1024 * 1024:
        return f"{n / 1024:.1f} KiB"
    return f"{n / (1024 * 1024):.1f} MiB"


def render_metadata(path, meta):
    columns = max(0, len(meta.schema) - 1)
    compressed = sum(rg.compressed_size for rg in meta.row_groups)
    uncompressed = sum(rg.uncompressed_size for rg in meta.row_groups)
    ratio = (uncompressed / compressed) if compressed else 0.0
    codecs = {}
    encodings = set()
    for rg in meta.row_groups:
        for col in rg.columns:
            codecs[CODECS.get(col.codec, str(col.codec))] = codecs.get(CODECS.get(col.codec, str(col.codec)), 0) + 1
            encodings.update(ENCODINGS.get(e, str(e)) for e in col.encodings)

    lines = [
        "parqeye",
        f"Visualize  Metadata  Schema  Row Groups  {path}",
        "",
        "File Metadata",
        f"Format version {meta.version}",
        f"Created by {meta.created_by}",
        f"Rows {meta.num_rows}",
        f"Columns {columns}",
        f"Row groups {len(meta.row_groups)}",
        f"Size (raw) {format_size(uncompressed)}",
        f"Size (compressed) {format_size(compressed)}",
        f"Compression ratio {ratio:.2f}x" if ratio else "Compression ratio n/a",
    ]
    if codecs:
        lines.append("Codecs (cols) " + ", ".join(f"{k}({v})" for k, v in sorted(codecs.items())))
    if encodings:
        lines.append("Encodings " + ", ".join(sorted(encodings)))
    lines.append("")
    lines.append("Schema Tree")
    for i, element in enumerate(meta.schema):
        if i == 0:
            lines.append(f"└─ {element.name or 'root'}")
        else:
            rep = REPETITION_TYPES.get(element.repetition_type, "")
            phys = PHYSICAL_TYPES.get(element.physical_type, "GROUP" if element.num_children else "")
            lines.append(f"   ├─ {element.name} {rep} {phys}".rstrip())
    return "\n".join(lines) + "\n"


def main(argv=None):
    argv = list(sys.argv[1:] if argv is None else argv)
    if argv in (["--help"], ["-h"]):
        sys.stdout.write(HELP)
        return 0
    if argv in (["--version"], ["-V"]):
        sys.stdout.write("parqeye 0.0.2\n")
        return 0
    if not argv:
        sys.stderr.write(MISSING)
        return 2
    path = argv[0]
    try:
        meta = read_metadata(path)
        sys.stdout.write(render_metadata(path, meta))
        return 0
    except (OSError, ParquetError) as exc:
        sys.stderr.write('\x1b[?1049h')
        sys.stderr.write(f'Error: Custom {{ kind: Other, error: "{exc}" }}\n')
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
