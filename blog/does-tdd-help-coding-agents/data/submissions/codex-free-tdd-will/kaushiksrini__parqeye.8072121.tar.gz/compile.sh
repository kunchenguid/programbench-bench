#!/bin/bash
set -e

cp src/parqeye.py executable
chmod +x executable
