import os
import subprocess
import tempfile
import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
BIN = ROOT / "executable"


class HostctlCliTest(unittest.TestCase):
    def run_cli(self, *args):
        return subprocess.run(
            [str(BIN), *args],
            text=True,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            check=False,
        )

    def test_add_domains_creates_profile_block(self):
        with tempfile.TemporaryDirectory() as td:
            hosts = Path(td) / "hosts"
            hosts.write_text("127.0.0.1 localhost\n", encoding="utf-8")

            result = self.run_cli(
                "--host-file",
                str(hosts),
                "--no-color",
                "add",
                "domains",
                "dev",
                "app.test",
                "api.test",
            )

            self.assertEqual(result.returncode, 0, result.stdout)
            self.assertIn("[✔] Domains 'app.test, api.test' added.", result.stdout)
            self.assertIn("| dev     | on", result.stdout)
            self.assertEqual(
                hosts.read_text(encoding="utf-8"),
                """127.0.0.1 localhost

##################################################################
# Content under this line is handled by hostctl. DO NOT EDIT.
##################################################################

# profile.on dev
127.0.0.1 app.test
127.0.0.1 api.test
# end
""",
            )

    def test_add_from_file_then_disable_and_status_json(self):
        with tempfile.TemporaryDirectory() as td:
            hosts = Path(td) / "hosts"
            source = Path(td) / "profile.txt"
            hosts.write_text("127.0.0.1 localhost\n", encoding="utf-8")
            source.write_text("1.1.1.1 one two # comment\ninvalid\n2.2.2.2 three\n", encoding="utf-8")

            added = self.run_cli("--host-file", str(hosts), "--no-color", "add", "dev", "-f", str(source))
            self.assertEqual(added.returncode, 0, added.stdout)

            disabled = self.run_cli("--host-file", str(hosts), "--no-color", "disable", "dev")
            self.assertEqual(disabled.returncode, 0, disabled.stdout)
            self.assertIn("# profile.off dev", hosts.read_text(encoding="utf-8"))
            self.assertIn("# 1.1.1.1 one", hosts.read_text(encoding="utf-8"))

            status = self.run_cli("--host-file", str(hosts), "--no-color", "-o", "json", "status")
            self.assertEqual(status.returncode, 0, status.stdout)
            self.assertEqual(status.stdout.strip(), '[{"Profile":"dev","Status":"off","IP":"","Host":""}]')


if __name__ == "__main__":
    unittest.main()
