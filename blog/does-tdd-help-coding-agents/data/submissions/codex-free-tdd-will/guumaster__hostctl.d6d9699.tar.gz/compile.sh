#!/bin/bash
set -e
cp src/hostctl.py executable
chmod +x executable
