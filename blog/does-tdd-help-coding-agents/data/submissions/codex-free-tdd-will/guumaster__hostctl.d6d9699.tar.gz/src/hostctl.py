#!/usr/bin/env python3
import json
import os
import shutil
import sys
from dataclasses import dataclass, field
from datetime import datetime


HEADER = (
    "##################################################################\n"
    "# Content under this line is handled by hostctl. DO NOT EDIT.\n"
    "##################################################################"
)


@dataclass
class Entry:
    ip: str
    host: str


@dataclass
class Profile:
    name: str
    status: str = "on"
    entries: list[Entry] = field(default_factory=list)


def strip_comment(line):
    return line[2:] if line.startswith("# ") else line[1:] if line.startswith("#") else line


def parse_hosts(path):
    try:
        text = open(path, encoding="utf-8").read()
    except FileNotFoundError:
        raise FileNotFoundError(f"open {path}: no such file or directory")
    text = text.replace("\r\n", "\n")
    lines = text.splitlines()
    unmanaged = []
    profiles = []
    i = 0
    while i < len(lines):
        line = lines[i]
        if line == "##################################################################" and i + 2 < len(lines) and "hostctl" in lines[i + 1]:
            i += 3
            break
        unmanaged.append(line)
        i += 1
    current = None
    while i < len(lines):
        line = lines[i]
        if line.startswith("# profile."):
            parts = line.split(maxsplit=2)
            state = parts[1].split(".", 1)[1] if len(parts) > 1 and "." in parts[1] else "on"
            name = parts[2] if len(parts) > 2 else ""
            current = Profile(name=name, status=state, entries=[])
            profiles.append(current)
        elif line.startswith("# end"):
            current = None
        elif current is not None and line.strip():
            clean = strip_comment(line).strip()
            if clean:
                bits = clean.split()
                if len(bits) >= 2:
                    for host in bits[1:]:
                        current.entries.append(Entry(bits[0], host))
        i += 1
    return unmanaged, profiles


def write_hosts(path, unmanaged, profiles):
    while unmanaged and unmanaged[-1] == "":
        unmanaged.pop()
    out = list(unmanaged)
    out += ["", *HEADER.splitlines(), ""]
    for idx, profile in enumerate(profiles):
        if idx:
            out.append("")
        out.append(f"# profile.{profile.status} {profile.name}")
        for e in profile.entries:
            prefix = "# " if profile.status == "off" else ""
            out.append(f"{prefix}{e.ip} {e.host}")
        out.append("# end")
    with open(path, "w", encoding="utf-8") as f:
        f.write("\n".join(out) + "\n")


def find_profile(profiles, name):
    for p in profiles:
        if p.name == name:
            return p
    return None


def rows_for(profiles, unmanaged=None, include_default=True, names=None, statuses=None):
    rows = []
    if include_default and unmanaged is not None:
        for line in unmanaged:
            s = line.strip()
            if not s or s.startswith("#"):
                continue
            bits = s.split()
            if len(bits) >= 2:
                for host in bits[1:]:
                    rows.append({"Profile": "default", "Status": "on", "IP": bits[0], "Host": host})
    for p in profiles:
        if names and p.name not in names:
            continue
        if statuses and p.status not in statuses:
            continue
        for e in p.entries:
            rows.append({"Profile": p.name, "Status": p.status, "IP": e.ip, "Host": e.host})
    return rows


def status_rows(profiles, names=None):
    return [
        {"Profile": p.name, "Status": p.status, "IP": "", "Host": ""}
        for p in profiles
        if not names or p.name in names
    ]


def selected_columns(opts, default):
    if opts["columns"]:
        mapping = {"profile": "Profile", "status": "Status", "ip": "IP", "domain": "Host", "host": "Host"}
        return [mapping.get(c.strip().lower(), c.strip()) for c in opts["columns"].split(",") if c.strip()]
    return default


def cell(row, col):
    return row["Host"] if col == "DOMAIN" else row.get(col.title(), row.get(col, ""))


def print_rows(rows, opts, default_cols=("Profile", "Status", "IP", "Host")):
    if opts["quiet"]:
        return
    cols = selected_columns(opts, list(default_cols))
    if opts["out"] == "json":
        print(json.dumps(rows, separators=(",", ":")))
        return
    heads = ["DOMAIN" if c == "Host" else c.upper() for c in cols]
    data = [[cell(r, h) for h in heads] for r in rows]
    widths = [len(h) for h in heads]
    for row in data:
        for i, val in enumerate(row):
            widths[i] = max(widths[i], len(str(val)))
    if opts["out"] == "raw":
        print("\t".join(h.ljust(widths[i]) for i, h in enumerate(heads)))
        for row in data:
            print("\t".join(str(v).ljust(widths[i]) for i, v in enumerate(row)) + "\t")
        return
    if opts["out"] == "markdown":
        print("| " + " | ".join(heads[i].center(widths[i]) for i in range(len(heads))) + " |")
        print("|" + "|".join("-" * (widths[i] + 2) for i in range(len(heads))) + "|")
        for row in data:
            print("| " + " | ".join(str(row[i]).ljust(widths[i]) for i in range(len(heads))) + " |")
        return
    border = "+" + "+".join("-" * (w + 2) for w in widths) + "+"
    print(border)
    print("| " + " | ".join(heads[i].center(widths[i]) for i in range(len(heads))) + " |")
    print(border)
    for row in data:
        print("| " + " | ".join(str(row[i]).ljust(widths[i]) for i in range(len(heads))) + " |")
    print(border)


def info(opts):
    if opts.get("_info_shown"):
        return
    if not opts["quiet"] and opts["host_file"] != "/etc/hosts" and opts["out"] != "json":
        print(f"[ℹ] Using hosts file: {opts['host_file']}\n", flush=True)
    opts["_info_shown"] = True


def success(msg, opts):
    if not opts["quiet"] and opts["out"] != "json":
        print(f"[✔] {msg}\n")


def fail(msg):
    print(f"[✖] error: {msg}", file=sys.stderr)
    return 1


def parse_global(argv):
    opts = {"host_file": "/etc/hosts", "out": "table", "quiet": False, "columns": "", "no_color": False}
    rest = []
    i = 0
    while i < len(argv):
        a = argv[i]
        if a in ("--host-file",):
            i += 1; opts["host_file"] = argv[i]
        elif a in ("-o", "--out"):
            i += 1; opts["out"] = argv[i]
        elif a in ("--raw",):
            opts["out"] = "raw"
        elif a in ("-q", "--quiet"):
            opts["quiet"] = True
        elif a in ("-c", "--column"):
            i += 1; opts["columns"] = argv[i]
        elif a == "--no-color":
            opts["no_color"] = True
        elif a in ("-v", "--version"):
            print("hostctl version dev")
            sys.exit(0)
        else:
            rest.append(a)
        i += 1
    return opts, rest


def parse_flag(args, name, default=""):
    if name in args:
        idx = args.index(name)
        if idx + 1 < len(args):
            val = args[idx + 1]
            del args[idx:idx + 2]
            return val
    return default


def parse_bool(args, name):
    if name in args:
        args.remove(name)
        return True
    return False


def discard_wait(args):
    for name in ("-w", "--wait"):
        if name in args:
            idx = args.index(name)
            del args[idx:idx + 2]


def read_entries(path):
    if not path:
        raise FileNotFoundError("open : no such file or directory")
    entries = []
    try:
        f = open(path, encoding="utf-8")
    except FileNotFoundError:
        raise FileNotFoundError(f"open {path}: no such file or directory")
    with f:
        for line in f:
            s = line.strip()
            if not s or s.startswith("#"):
                continue
            if "#" in s:
                s = s.split("#", 1)[0].strip()
            bits = s.split()
            if len(bits) >= 2:
                for host in bits[1:]:
                    entries.append(Entry(bits[0], host))
    return entries


def cmd_add(opts, args):
    discard_wait(args)
    if args and args[0] in ("domains", "domain"):
        info(opts)
        unmanaged, profiles = parse_hosts(opts["host_file"])
        args = args[1:]
        ip = parse_flag(args, "--ip", "127.0.0.1")
        if not args:
            return fail("missing profile name")
        name, domains = args[0], args[1:]
        if not domains:
            return fail("missing domain name")
        p = find_profile(profiles, name)
        if not p:
            p = Profile(name)
            profiles.append(p)
        for d in domains:
            p.entries.append(Entry(ip, d))
        write_hosts(opts["host_file"], unmanaged, profiles)
        success(f"Domains '{', '.join(domains)}' added.", opts)
        print_rows(rows_for([p], include_default=False), opts)
        return 0
    from_file = parse_flag(args, "-f", "") or parse_flag(args, "--from", "")
    if not args:
        return fail("missing profile name")
    name = args[0]
    info(opts)
    try:
        entries = read_entries(from_file)
    except OSError as e:
        info(opts)
        return fail(str(e))
    unmanaged, profiles = parse_hosts(opts["host_file"])
    p = find_profile(profiles, name)
    if not p:
        p = Profile(name)
        profiles.append(p)
    p.entries.extend(entries)
    write_hosts(opts["host_file"], unmanaged, profiles)
    print_rows(rows_for([p], include_default=False), opts)
    return 0


def cmd_replace(opts, args):
    from_file = parse_flag(args, "-f", "") or parse_flag(args, "--from", "")
    if not args:
        return fail("missing profile name")
    info(opts)
    try:
        entries = read_entries(from_file)
    except OSError as e:
        info(opts)
        return fail(str(e))
    unmanaged, profiles = parse_hosts(opts["host_file"])
    name = args[0]
    p = find_profile(profiles, name)
    if not p:
        p = Profile(name)
        profiles.append(p)
    p.status = "on"
    p.entries = entries
    write_hosts(opts["host_file"], unmanaged, profiles)
    print_rows(rows_for([p], include_default=False), opts)
    return 0


def cmd_list(opts, args):
    info(opts)
    unmanaged, profiles = parse_hosts(opts["host_file"])
    statuses = None
    if args and args[0] in ("enabled", "on"):
        statuses = {"on"}; args = args[1:]
    elif args and args[0] in ("disabled", "off"):
        statuses = {"off"}; args = args[1:]
    print_rows(rows_for(profiles, unmanaged, True, set(args) if args else None, statuses), opts)
    return 0


def cmd_status(opts, args):
    info(opts)
    _, profiles = parse_hosts(opts["host_file"])
    print_rows(status_rows(profiles, set(args) if args else None), opts, ("Profile", "Status"))
    return 0


def cmd_set_status(opts, args, target=None, toggle=False):
    discard_wait(args)
    info(opts)
    unmanaged, profiles = parse_hosts(opts["host_file"])
    all_flag = parse_bool(args, "--all")
    only = parse_bool(args, "--only")
    if not args and not all_flag:
        return fail("missing profile name")
    changed = []
    for p in profiles:
        if all_flag or p.name in args:
            p.status = ("off" if p.status == "on" else "on") if toggle else target
            changed.append(p)
        elif only and not toggle:
            p.status = "off" if target == "on" else "on"
    write_hosts(opts["host_file"], unmanaged, profiles)
    print_rows(rows_for(changed, include_default=False), opts)
    return 0


def cmd_remove(opts, args):
    info(opts)
    unmanaged, profiles = parse_hosts(opts["host_file"])
    if args and args[0] in ("domains", "domain"):
        args = args[1:]
        if not args:
            return fail("missing profile name")
        name, domains = args[0], set(args[1:])
        if not domains:
            return fail("missing domain name")
        p = find_profile(profiles, name)
        if p:
            p.entries = [e for e in p.entries if e.host not in domains]
        write_hosts(opts["host_file"], unmanaged, profiles)
        success(f"Domains '{', '.join(domains)}' removed.", opts)
        print_rows(rows_for([p], include_default=False) if p else [], opts)
        return 0
    all_flag = parse_bool(args, "--all")
    if not args and not all_flag:
        return fail("missing profile name")
    names = [p.name for p in profiles] if all_flag else args
    profiles = [p for p in profiles if p.name not in set(names)]
    write_hosts(opts["host_file"], unmanaged, profiles)
    success(f"Profile(s) '{', '.join(names)}' removed.", opts)
    return 0


def cmd_backup(opts, args):
    info(opts)
    path = parse_flag(args, "--path", os.getcwd())
    src = opts["host_file"]
    name = os.path.basename(src) + "." + datetime.now().strftime("%Y%m%d")
    dst = os.path.join(path, name)
    shutil.copyfile(src, dst)
    success(f"Backup '{dst}' created.", opts)
    return 0


def cmd_restore(opts, args):
    info(opts)
    src = parse_flag(args, "--from", "")
    if not src:
        return fail("open : no such file or directory")
    shutil.copyfile(src, opts["host_file"])
    success(f"File '{src}' restored.", opts)
    return 0


def print_help():
    print("""hostctl is a CLI tool to manage your hosts file with ease.
You can have multiple profiles, enable/disable exactly what
you need each time with a simple interface.

Usage:
  hostctl [command]

Available Commands:
  add         Add content to a profile in your hosts file.
  backup      Creates a backup copy of your hosts file
  disable     Disable a profile from your hosts file.
  enable      Enable a profile on your hosts file.
  list        Shows a detailed list of profiles on your hosts file.
  remove      Remove a profile from your hosts file.
  replace     Replace content to a profile in your hosts file.
  restore     Restore hosts file content from a backup file.
  status      Shows a list of profile names and statuses on your hosts file.
  toggle      Change status of a profile on your hosts file.

Flags:
  -h, --help               help for hostctl
      --host-file string   Hosts file path (default "/etc/hosts")
  -o, --out string         Output type (table|raw|markdown|json) (default "table")
  -q, --quiet              Run command without output
      --raw                Output without borders (same as -o raw)
  -v, --version            version for hostctl""")


def main(argv):
    opts, args = parse_global(argv)
    if not args or args[0] in ("-h", "--help", "help"):
        print_help(); return 0
    cmd, args = args[0], args[1:]
    if "--help" in args or "-h" in args:
        print_help(); return 0
    try:
        if cmd == "add": return cmd_add(opts, args)
        if cmd == "replace": return cmd_replace(opts, args)
        if cmd == "list": return cmd_list(opts, args)
        if cmd == "status": return cmd_status(opts, args)
        if cmd == "enable": return cmd_set_status(opts, args, "on")
        if cmd == "disable": return cmd_set_status(opts, args, "off")
        if cmd == "toggle": return cmd_set_status(opts, args, toggle=True)
        if cmd in ("remove", "rm"): return cmd_remove(opts, args)
        if cmd == "backup": return cmd_backup(opts, args)
        if cmd == "restore": return cmd_restore(opts, args)
        if cmd == "sync": return fail("sync source unavailable")
        return fail(f'unknown command "{cmd}" for "hostctl"')
    except OSError as e:
        return fail(str(e))


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
