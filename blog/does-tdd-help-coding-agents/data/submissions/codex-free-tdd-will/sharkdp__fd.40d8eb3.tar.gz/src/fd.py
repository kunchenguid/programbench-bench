#!/usr/bin/env python3
import os
import re
import stat
import subprocess
import sys
from fnmatch import fnmatch


def load_ignore_patterns(root, prefix=""):
    patterns = []
    for name in (".gitignore", ".ignore", ".fdignore"):
        path = os.path.join(root, name)
        if not os.path.isfile(path):
            continue
        with open(path, "r", encoding="utf-8", errors="replace") as handle:
            for line in handle:
                line = line.strip()
                if line and not line.startswith("#"):
                    if prefix and line.endswith("/"):
                        patterns.append(os.path.join(prefix, line))
                    elif "/" not in line.strip("/"):
                        patterns.append(line)
                    else:
                        patterns.append(os.path.join(prefix, line))
    return patterns


def is_ignored(rel, name, is_dir, patterns):
    for pattern in patterns:
        pat = pattern.strip("/")
        if pattern.endswith("/") and not is_dir:
            continue
        if fnmatch(name, pat) or fnmatch(rel, pat) or rel.startswith(pat + "/"):
            return True
    return False


def walk(root, include_hidden=False, no_ignore=False):
    out = []
    for current, dirs, files in os.walk(root):
        dirs.sort()
        files.sort()
        rel_dir = os.path.relpath(current, root)
        if rel_dir == ".":
            rel_dir = ""
        patterns = []
        if not no_ignore:
            cursor = root
            patterns.extend(load_ignore_patterns(cursor, ""))
            if rel_dir:
                parts = rel_dir.split(os.sep)
                prefix_parts = []
                for part in parts:
                    cursor = os.path.join(cursor, part)
                    prefix_parts.append(part)
                    patterns.extend(load_ignore_patterns(cursor, os.path.join(*prefix_parts)))

        kept_dirs = []
        for name in dirs:
            rel = os.path.join(rel_dir, name) if rel_dir else name
            if (not include_hidden and name.startswith(".")) or is_ignored(rel, name, True, patterns):
                continue
            kept_dirs.append(name)
            out.append(rel + "/")
        dirs[:] = kept_dirs

        for name in files:
            rel = os.path.join(rel_dir, name) if rel_dir else name
            if (not include_hidden and name.startswith(".")) or is_ignored(rel, name, False, patterns):
                continue
            out.append(rel)
    return out


def parse_args(argv):
    opts = {
        "hidden": False,
        "no_ignore": False,
        "ignore_case": None,
        "glob": False,
        "fixed": False,
        "extensions": [],
        "types": [],
        "max_depth": None,
        "min_depth": 1,
        "print0": False,
        "absolute": False,
        "full_path": False,
        "max_results": None,
        "quiet": False,
        "exec": None,
        "exec_batch": None,
        "strip_cwd_prefix": "auto",
        "base_directory": None,
        "excludes": [],
        "format": None,
        "search_paths": [],
        "and_patterns": [],
        "size": None,
        "path_separator": None,
        "list_details": False,
    }
    positional = []
    i = 0
    while i < len(argv):
        arg = argv[i]
        if arg == "--":
            positional.extend(argv[i + 1 :])
            break
        if arg in ("-h", "--help"):
            opts["help"] = True
        elif arg in ("-V", "--version"):
            opts["version"] = True
        elif arg in ("-H", "--hidden"):
            opts["hidden"] = True
        elif arg in ("--no-hidden",):
            opts["hidden"] = False
        elif arg in ("-I", "--no-ignore", "-u", "--unrestricted"):
            opts["no_ignore"] = True
            if arg in ("-u", "--unrestricted"):
                opts["hidden"] = True
        elif arg in ("--ignore",):
            opts["no_ignore"] = False
        elif arg in ("-i", "--ignore-case"):
            opts["ignore_case"] = True
        elif arg in ("-s", "--case-sensitive"):
            opts["ignore_case"] = False
        elif arg in ("-g", "--glob"):
            opts["glob"] = True
        elif arg == "--regex":
            opts["glob"] = False
        elif arg in ("-F", "--fixed-strings"):
            opts["fixed"] = True
        elif arg in ("-0", "--print0"):
            opts["print0"] = True
        elif arg in ("-l", "--list-details"):
            opts["list_details"] = True
        elif arg in ("-a", "--absolute-path"):
            opts["absolute"] = True
        elif arg == "--relative-path":
            opts["absolute"] = False
        elif arg in ("-p", "--full-path"):
            opts["full_path"] = True
        elif arg in ("-q", "--quiet", "--has-results"):
            opts["quiet"] = True
            opts["max_results"] = 1
        elif arg == "-1":
            opts["max_results"] = 1
        elif arg in ("--no-ignore-vcs",):
            opts["no_ignore"] = True
        elif arg in ("--no-require-git", "--require-git", "--no-ignore-parent", "--ignore-vcs", "--show-errors", "--one-file-system", "--mount", "--xdev", "--prune", "--follow", "-L", "--no-follow"):
            pass
        elif arg in ("-e", "--extension", "-t", "--type", "-d", "--max-depth", "--min-depth", "--exact-depth", "-E", "--exclude", "-C", "--base-directory", "--max-results", "--format", "--strip-cwd-prefix", "--search-path", "--and", "-S", "--size", "-c", "--color", "-j", "--threads", "--batch-size", "--ignore-file", "--owner", "-o", "--path-separator", "--changed-within", "--changed-before", "--change-newer-than", "--newer", "--changed-after", "--change-older-than", "--older", "--hyperlink", "--ignore-contain"):
            if i + 1 >= len(argv):
                raise ValueError(f"error: a value is required for '{arg}'")
            val = argv[i + 1]
            i += 1
            if arg in ("-e", "--extension"):
                opts["extensions"].append(val.lower().lstrip("."))
            elif arg in ("-t", "--type"):
                opts["types"].append(val)
            elif arg in ("-d", "--max-depth"):
                opts["max_depth"] = int(val)
            elif arg == "--min-depth":
                opts["min_depth"] = int(val)
            elif arg == "--exact-depth":
                opts["min_depth"] = int(val)
                opts["max_depth"] = int(val)
            elif arg in ("-E", "--exclude"):
                opts["excludes"].append(val)
            elif arg in ("-C", "--base-directory"):
                opts["base_directory"] = val
            elif arg == "--max-results":
                opts["max_results"] = int(val)
            elif arg == "--format":
                opts["format"] = val
            elif arg == "--strip-cwd-prefix":
                opts["strip_cwd_prefix"] = val
            elif arg == "--search-path":
                opts["search_paths"].append(val)
            elif arg == "--and":
                opts["and_patterns"].append(val)
            elif arg in ("-S", "--size"):
                opts["size"] = val
            elif arg == "--path-separator":
                opts["path_separator"] = val
            elif arg == "--ignore-file" and not opts["no_ignore"]:
                # Custom ignore files are low precedence; for the common case,
                # copying their patterns into excludes approximates fd behavior.
                try:
                    with open(val, "r", encoding="utf-8", errors="replace") as f:
                        for line in f:
                            line = line.strip()
                            if line and not line.startswith("#"):
                                opts["excludes"].append(line)
                except OSError:
                    pass
        elif arg.startswith("--max-results="):
            opts["max_results"] = int(arg.split("=", 1)[1])
        elif arg.startswith("--path-separator="):
            opts["path_separator"] = arg.split("=", 1)[1]
        elif arg.startswith("--color=") or arg.startswith("--threads=") or arg.startswith("--batch-size=") or arg.startswith("--hyperlink="):
            pass
        elif arg.startswith("--strip-cwd-prefix="):
            opts["strip_cwd_prefix"] = arg.split("=", 1)[1]
        elif arg.startswith("--exact-depth="):
            val = int(arg.split("=", 1)[1])
            opts["min_depth"] = val
            opts["max_depth"] = val
        elif arg in ("-x", "--exec", "-X", "--exec-batch"):
            cmd = argv[i + 1 :]
            if not cmd:
                raise ValueError(f"error: a command is required for '{arg}'")
            if arg in ("-x", "--exec"):
                opts["exec"] = cmd
            else:
                opts["exec_batch"] = cmd
            break
        elif arg.startswith("-") and len(arg) > 2 and not arg.startswith("--"):
            # Support common clusters like -HI, -tf and -d2.
            cluster = arg[1:]
            j = 0
            while j < len(cluster):
                ch = cluster[j]
                if ch == "H":
                    opts["hidden"] = True
                elif ch == "I":
                    opts["no_ignore"] = True
                elif ch == "u":
                    opts["hidden"] = True
                    opts["no_ignore"] = True
                elif ch == "i":
                    opts["ignore_case"] = True
                elif ch == "s":
                    opts["ignore_case"] = False
                elif ch == "g":
                    opts["glob"] = True
                elif ch == "F":
                    opts["fixed"] = True
                elif ch == "0":
                    opts["print0"] = True
                elif ch == "a":
                    opts["absolute"] = True
                elif ch == "p":
                    opts["full_path"] = True
                elif ch == "1":
                    opts["max_results"] = 1
                elif ch in "etdECS":
                    val = cluster[j + 1 :] or (argv[i + 1] if i + 1 < len(argv) else None)
                    if val is None:
                        raise ValueError(f"error: a value is required for '-{ch}'")
                    if not cluster[j + 1 :]:
                        i += 1
                    if ch == "e":
                        opts["extensions"].append(val.lower().lstrip("."))
                    elif ch == "t":
                        opts["types"].append(val)
                    elif ch == "d":
                        opts["max_depth"] = int(val)
                    elif ch == "E":
                        opts["excludes"].append(val)
                    elif ch == "C":
                        opts["base_directory"] = val
                    elif ch == "S":
                        opts["size"] = val
                    break
                else:
                    positional.append("-" + cluster[j:])
                    break
                j += 1
        else:
            positional.append(arg)
        i += 1
    pattern = positional[0] if positional else None
    paths = opts["search_paths"] or (positional[1:] if len(positional) > 1 else ["."])
    return opts, pattern, paths


def compile_pattern(pattern, ignore_case):
    if pattern is None:
        return None
    flags = 0
    if ignore_case is True or (ignore_case is None and not any(c.isupper() for c in pattern)):
        flags = re.IGNORECASE
    return re.compile(pattern, flags)


def match_pattern(text, pattern, regex, opts):
    if pattern is None:
        return True
    if opts["fixed"]:
        a, b = text, pattern
        if opts["ignore_case"] is True or (opts["ignore_case"] is None and not any(c.isupper() for c in pattern)):
            a, b = a.lower(), b.lower()
        return b in a
    if opts["glob"]:
        a, b = text, pattern
        if opts["ignore_case"] is True or (opts["ignore_case"] is None and not any(c.isupper() for c in pattern)):
            a, b = a.lower(), b.lower()
        return fnmatch(a, b)
    return regex.search(text) is not None


def make_matcher(pattern, opts):
    if opts["glob"] or opts["fixed"]:
        return None
    return compile_pattern(pattern, opts["ignore_case"])


def display_path(root_arg, rel, opts):
    if opts["absolute"]:
        return os.path.abspath(os.path.join(root_arg, rel))
    if os.path.isabs(root_arg):
        return os.path.join(root_arg, rel)
    if root_arg in ("", "."):
        return rel
    return os.path.join(root_arg, rel)


def depth_of(rel):
    return rel.rstrip("/").count(os.sep) + 1


def type_matches(path, is_dir, opts):
    types = opts["types"]
    if not types:
        return True
    st = os.lstat(path)
    ok = False
    wanted_empty = False
    for t in types:
        t = t.lower()
        if t in ("f", "file"):
            ok = ok or stat.S_ISREG(st.st_mode)
        elif t in ("d", "dir", "directory"):
            ok = ok or is_dir
        elif t in ("l", "symlink"):
            ok = ok or stat.S_ISLNK(st.st_mode)
        elif t in ("x", "executable"):
            ok = ok or (stat.S_ISREG(st.st_mode) and os.access(path, os.X_OK))
        elif t in ("e", "empty"):
            wanted_empty = True
        elif t in ("p", "pipe"):
            ok = ok or stat.S_ISFIFO(st.st_mode)
        elif t in ("s", "socket"):
            ok = ok or stat.S_ISSOCK(st.st_mode)
        elif t in ("b", "block-device"):
            ok = ok or stat.S_ISBLK(st.st_mode)
        elif t in ("c", "char-device"):
            ok = ok or stat.S_ISCHR(st.st_mode)
    if wanted_empty:
        empty = False
        if is_dir:
            try:
                empty = len(os.listdir(path)) == 0
            except OSError:
                empty = False
        elif stat.S_ISREG(st.st_mode):
            empty = st.st_size == 0
        if len(types) == 1:
            ok = empty
        else:
            ok = ok and empty
    return ok


def extension_matches(rel, opts):
    if not opts["extensions"]:
        return True
    if rel.endswith("/"):
        return False
    ext = os.path.splitext(rel)[1].lstrip(".").lower()
    return ext in opts["extensions"]


def parse_size(spec):
    mults = {
        "": 1,
        "b": 1,
        "k": 1000,
        "m": 1000**2,
        "g": 1000**3,
        "t": 1000**4,
        "ki": 1024,
        "mi": 1024**2,
        "gi": 1024**3,
        "ti": 1024**4,
    }
    op = "="
    if spec and spec[0] in "+-":
        op, spec = spec[0], spec[1:]
    m = re.fullmatch(r"(\d+)([A-Za-z]*)", spec)
    if not m:
        raise ValueError(f"invalid size: {spec}")
    return op, int(m.group(1)) * mults.get(m.group(2).lower(), 1)


def size_matches(path, is_dir, opts):
    if not opts["size"] or is_dir:
        return True
    op, want = parse_size(opts["size"])
    try:
        have = os.path.getsize(path)
    except OSError:
        return False
    if op == "+":
        return have >= want
    if op == "-":
        return have <= want
    return have == want


def excluded(rel, name, opts):
    return any(fnmatch(name, pat) or fnmatch(rel, pat) for pat in opts["excludes"])


def format_result(fmt, path):
    base = os.path.basename(path.rstrip("/"))
    parent = os.path.dirname(path.rstrip("/")) or "."
    no_ext = os.path.splitext(path.rstrip("/"))[0]
    base_no_ext = os.path.splitext(base)[0]
    return (
        fmt.replace("{//}", parent)
        .replace("{/.}", base_no_ext)
        .replace("{.}", no_ext)
        .replace("{/}", base)
        .replace("{}", path)
        .replace("{{", "{")
        .replace("}}", "}")
    )


def subst_args(cmd, paths):
    has_placeholder = any("{" in c for c in cmd)
    if not has_placeholder:
        return cmd + paths
    out = []
    for c in cmd:
        if c in ("{}", "{/}", "{//}", "{.}", "{/.}"):
            if c == "{}":
                out.extend(paths)
            elif c == "{/}":
                out.extend(os.path.basename(p.rstrip("/")) for p in paths)
            elif c == "{//}":
                out.extend(os.path.dirname(p.rstrip("/")) or "." for p in paths)
            elif c == "{.}":
                out.extend(os.path.splitext(p.rstrip("/"))[0] for p in paths)
            elif c == "{/.}":
                out.extend(os.path.splitext(os.path.basename(p.rstrip("/")))[0] for p in paths)
        else:
            value = c
            if paths:
                value = format_result(value, paths[0])
            out.append(value)
    return out


SHORT_HELP = """A program to find entries in your filesystem

Usage: executable [OPTIONS] [pattern] [path]...

Options:
  -H, --hidden                     Search hidden files and directories
  -I, --no-ignore                  Do not respect .(git|fd)ignore files
  -s, --case-sensitive             Case-sensitive search
  -i, --ignore-case                Case-insensitive search
  -g, --glob                       Glob-based search
  -F, --fixed-strings              Treat pattern as a literal string
  -a, --absolute-path              Show absolute instead of relative paths
  -p, --full-path                  Search full path
  -d, --max-depth <depth>          Set maximum search depth
  -E, --exclude <pattern>          Exclude entries matching glob
  -t, --type <filetype>            Filter by type
  -e, --extension <ext>            Filter by file extension
  -x, --exec <cmd>...              Execute command for each result
  -X, --exec-batch <cmd>...        Execute command once with all results
  -h, --help                       Print help
  -V, --version                    Print version
"""


def main(argv):
    try:
        opts, pattern, paths = parse_args(argv)
    except Exception as exc:
        print(f"[fd error]: {exc}", file=sys.stderr)
        return 1
    if opts.get("help"):
        print(SHORT_HELP, end="")
        return 0
    if opts.get("version"):
        print("fd 10.3.0")
        return 0
    if opts["base_directory"]:
        os.chdir(opts["base_directory"])
    try:
        regex = make_matcher(pattern, opts)
        and_regexes = [make_matcher(p, opts) for p in opts["and_patterns"]]
    except re.error as exc:
        print(f"[fd error]: regex parse error: {exc}", file=sys.stderr)
        return 1
    results = []
    for root in paths:
        for rel in walk(root, opts["hidden"], opts["no_ignore"]):
            name = os.path.basename(rel.rstrip("/"))
            if excluded(rel.rstrip("/"), name, opts):
                continue
            d = depth_of(rel)
            if d < opts["min_depth"] or (opts["max_depth"] is not None and d > opts["max_depth"]):
                continue
            full = os.path.join(root, rel.rstrip("/"))
            is_dir = rel.endswith("/")
            if not type_matches(full, is_dir, opts) or not extension_matches(rel, opts) or not size_matches(full, is_dir, opts):
                continue
            target = display_path(root, rel, opts)
            match_text = target if opts["full_path"] else name
            if not match_pattern(match_text, pattern, regex, opts):
                continue
            if any(not match_pattern(match_text, p, rx, opts) for p, rx in zip(opts["and_patterns"], and_regexes)):
                continue
            if opts["print0"] or opts["exec"] or opts["exec_batch"]:
                target = target.rstrip("/")
                if root in ("", ".") and not target.startswith("/") and not target.startswith("./"):
                    target = "./" + target
                if opts["strip_cwd_prefix"] == "always":
                    target = target[2:] if target.startswith("./") else target
            if opts["format"]:
                target = format_result(opts["format"], target)
            results.append(target)
            if opts["max_results"] and len(results) >= opts["max_results"]:
                break
        if opts["max_results"] and len(results) >= opts["max_results"]:
            break
    results = sorted(results)
    if opts["quiet"]:
        return 0 if results else 1
    if opts["exec"]:
        code = 0
        for path in results:
            code = max(code, subprocess.run(subst_args(opts["exec"], [path])).returncode)
        return code
    if opts["exec_batch"]:
        if results:
            return subprocess.run(subst_args(opts["exec_batch"], results)).returncode
        return 0
    if opts["list_details"]:
        code = 0
        for path in results:
            code = max(code, subprocess.run(["ls", "-ld", path]).returncode)
        return code
    if opts["path_separator"]:
        results = [r.replace("/", opts["path_separator"]) for r in results]
    sep = "\0" if opts["print0"] else "\n"
    if results:
        sys.stdout.write(sep.join(results) + sep)
    return 0


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
