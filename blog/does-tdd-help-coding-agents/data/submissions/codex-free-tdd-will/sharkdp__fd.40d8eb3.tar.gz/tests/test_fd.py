import os
import subprocess
import tempfile
import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
BIN = ROOT / "src" / "fd.py"


def run_fd(tmp_path, *args):
    proc = subprocess.run(
        ["python3", str(BIN), *args],
        cwd=tmp_path,
        text=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
    )
    return proc


class FdBehaviorTests(unittest.TestCase):
    def test_default_listing_skips_hidden_and_gitignored_entries(self):
        with tempfile.TemporaryDirectory() as td:
            tmp_path = Path(td)
            (tmp_path / "dir" / "sub").mkdir(parents=True)
            (tmp_path / "dir" / "gamma.rs").write_text("")
            (tmp_path / "dir" / "sub" / "delta.md").write_text("")
            (tmp_path / "alpha.txt").write_text("")
            (tmp_path / ".hidden").mkdir()
            (tmp_path / ".hidden" / "secret.txt").write_text("")
            (tmp_path / "ignored").mkdir()
            (tmp_path / "ignored" / "skip.log").write_text("")
            (tmp_path / ".gitignore").write_text("ignored/\n*.log\n")
            (tmp_path / ".git").mkdir()

            proc = run_fd(tmp_path)

            self.assertEqual(proc.returncode, 0, proc.stderr)
            self.assertEqual(
                proc.stdout.splitlines(),
                [
                    "alpha.txt",
                    "dir/",
                    "dir/gamma.rs",
                    "dir/sub/",
                    "dir/sub/delta.md",
                ],
            )

    def test_pattern_and_path_use_smart_case_regex_on_file_names(self):
        with tempfile.TemporaryDirectory() as td:
            base = Path(td)
            root = base / "tree"
            root.mkdir()
            (root / "alpha.txt").write_text("")
            (root / "Beta.TXT").write_text("")

            insensitive = run_fd(base, "txt", str(root))
            sensitive = run_fd(base, "TXT", str(root))

            self.assertEqual(insensitive.returncode, 0, insensitive.stderr)
            self.assertEqual(
                insensitive.stdout.splitlines(),
                [str(root / "Beta.TXT"), str(root / "alpha.txt")],
            )
            self.assertEqual(sensitive.returncode, 0, sensitive.stderr)
            self.assertEqual(sensitive.stdout.splitlines(), [str(root / "Beta.TXT")])

    def test_common_filters_and_output_modes(self):
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            (root / "dir" / "sub").mkdir(parents=True)
            (root / "dir" / "gamma.rs").write_text("x")
            os.chmod(root / "dir" / "gamma.rs", 0o755)
            (root / "dir" / "sub" / "delta.md").write_text("")
            (root / "alpha.txt").write_text("")
            (root / ".hidden").mkdir()
            (root / ".hidden" / "secret.txt").write_text("")
            (root / "ignored").mkdir()
            (root / "ignored" / "skip.log").write_text("")
            (root / ".gitignore").write_text("ignored/\n")
            (root / ".git").mkdir()

            self.assertEqual(run_fd(root, ".", "-e", "txt").stdout.splitlines(), ["alpha.txt"])
            self.assertEqual(run_fd(root, ".", "-t", "x").stdout.splitlines(), ["dir/gamma.rs"])
            self.assertEqual(
                run_fd(root, ".", "-d", "1").stdout.splitlines(),
                ["alpha.txt", "dir/"],
            )
            self.assertEqual(run_fd(root, "secret", "-H").stdout.splitlines(), [".hidden/secret.txt"])
            self.assertEqual(run_fd(root, "skip", "-I").stdout.splitlines(), ["ignored/skip.log"])
            self.assertEqual(run_fd(root, "-g", "*.txt").stdout.splitlines(), ["alpha.txt"])
            self.assertEqual(run_fd(root, "-F", "a.txt").stdout.splitlines(), ["alpha.txt"])
            self.assertEqual(run_fd(root, "alpha", "-0").stdout, "./alpha.txt\0")
            parent = root.parent
            self.assertEqual(
                run_fd(parent, "alpha", "-0", root.name).stdout,
                f"{root.name}/alpha.txt\0",
            )

    def test_nested_ignore_files_and_exec_paths_match_cli_behavior(self):
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            (root / "repo" / "kept").mkdir(parents=True)
            (root / "repo" / "ignored").mkdir()
            (root / "repo" / "ignored" / "skip.log").write_text("")
            (root / "repo" / "kept" / "ok.log").write_text("")
            (root / "repo" / ".git").mkdir()
            (root / "repo" / ".gitignore").write_text("ignored/\n")

            listing = run_fd(root, ".")
            self.assertNotIn("repo/ignored/", listing.stdout)
            self.assertIn("repo/kept/ok.log", listing.stdout)

            batch = run_fd(root, "kept", "-X", "printf", "%s\n")
            self.assertEqual(batch.stdout, "./repo/kept\n")

    def test_size_and_additional_pattern_search_path_and_format(self):
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            (root / "one-small.txt").write_text("abc")
            (root / "two-large.txt").write_text("abcdefghij")
            (root / "two-large.log").write_text("abcdefghij")

            proc = run_fd(root.parent, "--search-path", root.name, "two", "--and", "large", "-S", "+5b")
            self.assertEqual(proc.stdout.splitlines(), [f"{root.name}/two-large.log", f"{root.name}/two-large.txt"])

            formatted = run_fd(root, "large", "--format", "{/}:{.}")
            self.assertEqual(formatted.stdout.splitlines(), ["two-large.log:two-large", "two-large.txt:two-large"])

    def test_value_options_do_not_become_patterns_and_path_separator_renders(self):
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            (root / "dir").mkdir()
            (root / "dir" / "file.txt").write_text("")

            proc = run_fd(root, "--color", "never", "--threads", "1", "--path-separator", "\\", "file")

            self.assertEqual(proc.stdout, "dir\\file.txt\n")

    def test_list_details_prints_long_listing_for_matches(self):
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            (root / "file.txt").write_text("abc")

            proc = run_fd(root, "file", "--list-details")

            self.assertIn("file.txt", proc.stdout)
            self.assertIn(" 3 ", proc.stdout)


if __name__ == "__main__":
    unittest.main()
