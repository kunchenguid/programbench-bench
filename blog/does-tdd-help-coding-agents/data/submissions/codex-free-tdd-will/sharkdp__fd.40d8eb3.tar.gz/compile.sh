#!/bin/bash
set -e
cp src/fd.py executable
chmod +x executable
