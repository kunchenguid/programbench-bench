#!/usr/bin/env python3
import ast
import fnmatch
import glob
import json
import os
import re
import sys
from pathlib import Path


VERSION = "dep-tree version v0.23.4"
SAMPLE_CONFIG = """# Files that should be completely ignored by dep-tree.
exclude:
  - 'some-glob-pattern/**/*.ts'

# The only files that will be included by dep-tree.
only:
  - 'some-glob-pattern/**/*.ts'

unwrapExports: false

check:
  entrypoints:
    - src/index.ts
  allowCircularDependencies: false
  allow:
    'src/products/**':
      - 'src/products/**'
      - 'src/helpers/**'
  deny:
    'src/products/**':
      - 'src/users/**'
  aliases:
    'common':
      - 'src/helpers/**'
      - 'src/utils/**'

js:
  workspaces: true
  tsConfigPaths: true

python:
  excludeConditionalImports: false

rust:
  # None available at the moment.
"""

ROOT_HELP = r"""
      ____         _ __       _
     |  _ \   ___ |  _ \    _| |_  _ __  ___   ___
     | | | | / _ \| |_) |  |_   _||  __|/ _ \ / _ \
     | |_| ||  __/| .__/     | |  | |  |  __/|  __/
     |____/  \__| |_|        | \__|_|   \___| \___|

Usage:
  dep-tree [command]

Visualize your dependencies graphically
  entropy     (default) Renders a 3d force-directed graph in the browser
  tree        Render the dependency tree starting from the provided entrypoint

Check your dependencies against your own rules
  check       Checks that the dependency rules defined in the configuration file are not broken

Display what are the dependencies between two portions of code
  explain     Shows all the dependencies between two parts of the code

Additional Commands:
  config      Generates a sample config in case that there's not already one present
  help        Help about any command

Flags:
  -c, --config string                        path to dep-tree's config file. (default .dep-tree.yml)
      --unwrap-exports                       trace re-exported symbols to the file where they are declared. (default false)
      --js-tsconfig-paths                    follow the tsconfig.json paths while resolving imports. (default true)
      --js-workspaces                        take the workspaces attribute in the root package.json into account for resolving paths. (default true)
      --python-exclude-conditional-imports   exclude imports wrapped inside if or try statements. (default false)
      --only stringArray                     Files that do not match this glob pattern will be ignored. You can provide an arbitrary number of --only flags.
      --exclude stringArray                  Files that match this glob pattern will be ignored. You can provide an arbitrary number of --exclude flags.
  -h, --help                                 help for dep-tree
  -v, --version                              version for dep-tree
""".strip()

COMMAND_HELP = {
    "tree": """Render the dependency tree starting from the provided entrypoint

Usage:
  dep-tree tree [flags]

Flags:
  -h, --help   help for tree
      --json   render the dependency tree in a machine readable json format""",
    "explain": """Shows all the dependencies between two parts of the code

Usage:
  dep-tree explain [flags]

Flags:
  -h, --help            help for explain
  -l, --overlap-left    When there's an overlap between the files at the left and the right, keep the ones at the left
  -r, --overlap-right   When there's an overlap between the files at the right, keep the ones at the right""",
    "check": """Checks that the dependency rules defined in the configuration file are not broken

Usage:
  dep-tree check [flags]

Flags:
  -h, --help   help for check""",
    "config": """Generates a sample config in case that there's not already one present

Usage:
  dep-tree config [flags]

Aliases:
  config, init

Flags:
  -h, --help   help for config""",
}


def norm(path):
    return path.replace(os.sep, "/")


def go_module_for(path):
    cur = Path(path).resolve().parent
    while True:
        mod = cur / "go.mod"
        if mod.exists():
            name = ""
            for line in mod.read_text(encoding="utf-8", errors="ignore").splitlines():
                line = line.strip()
                if line.startswith("module "):
                    name = line.split(None, 1)[1].strip()
                    break
            return cur, name
        if cur == cur.parent:
            return None, ""
        cur = cur.parent


def display_path(path):
    path = Path(path).resolve()
    if path.suffix == ".go":
        root, _ = go_module_for(path)
        if root:
            return norm(os.path.relpath(path, root))
    return norm(os.path.relpath(path, Path.cwd()))


def resolve_source(path):
    candidate = Path(path)
    if candidate.exists():
        return candidate
    for mod in Path.cwd().rglob("go.mod"):
        mod_candidate = mod.parent / path
        if mod_candidate.exists():
            return mod_candidate
    return candidate


def candidate_files(module_path):
    base = Path(*module_path.split(".")) if module_path else Path()
    out = []
    if str(base) != ".":
        out.append(base.with_suffix(".py"))
        out.append(base / "__init__.py")
    return out


def resolve_python_import(source, node):
    text = source.read_text(encoding="utf-8", errors="ignore")
    try:
        tree = ast.parse(text)
    except SyntaxError:
        return []
    deps = []
    source_dir = source.parent
    def add_resolved(base, name, allow_init=True):
        found = []
        for candidate in candidate_files(name):
            if not allow_init and candidate.name == "__init__.py":
                continue
            full = (base / candidate).resolve()
            if full.exists() and full.is_file() and full != source.resolve():
                rel = norm(os.path.relpath(full, Path.cwd()))
                if rel not in deps:
                    deps.append(rel)
                found.append(rel)
        return found

    for item in ast.walk(tree):
        if isinstance(item, ast.Import):
            for alias in item.names:
                add_resolved(Path.cwd(), alias.name)
        elif isinstance(item, ast.ImportFrom):
            module = item.module or ""
            if item.level:
                base = source_dir
                for _ in range(max(0, item.level - 1)):
                    base = base.parent
                bases = [base]
            else:
                bases = [Path.cwd()]
            for base in bases:
                if any(alias.name == "*" for alias in item.names):
                    add_resolved(base, module)
                    continue
                for alias in item.names:
                    if alias.name == "*":
                        continue
                    if module:
                        found = add_resolved(base, f"{module}.{alias.name}", allow_init=False)
                        if not found:
                            add_resolved(base, module)
                    else:
                        add_resolved(base, alias.name)
        else:
            continue
    return deps


JS_RE = re.compile(r"""(?:import|export)\s+(?:[^'"]*?\s+from\s+)?['"]([^'"]+)['"]|require\(\s*['"]([^'"]+)['"]\s*\)""")


def resolve_relative_import(source, spec, extensions):
    if not spec.startswith("."):
        return None
    base = (source.parent / spec).resolve()
    candidates = []
    if base.suffix:
        candidates.append(base)
    for ext in extensions:
        candidates.append(Path(str(base) + ext))
    for ext in extensions:
        candidates.append(base / ("index" + ext))
    for item in candidates:
        if item.exists() and item.is_file():
            return norm(os.path.relpath(item, Path.cwd()))
    return None


def parse_deps(path):
    source = resolve_source(path)
    suffix = source.suffix
    if suffix == ".py":
        return resolve_python_import(source, path)
    text = source.read_text(encoding="utf-8", errors="ignore")
    deps = []
    if suffix in {".js", ".jsx", ".ts", ".tsx", ".mjs", ".cjs"}:
        for match in JS_RE.finditer(text):
            dep = resolve_relative_import(source, match.group(1) or match.group(2), [".ts", ".tsx", ".js", ".jsx", ".mjs", ".cjs"])
            if dep and dep not in deps:
                deps.append(dep)
    elif suffix == ".go":
        module_root, module_name = go_module_for(source)
        imports = []
        for line in re.findall(r'import\s+"([^"]+)"', text):
            imports.append(line)
        for block in re.findall(r'import\s*\((.*?)\)', text, re.S):
            imports.extend(re.findall(r'"([^"]+)"', block))
        for imp in imports:
            dep = resolve_relative_import(source, imp, [".go"])
            if not dep and module_root and module_name and imp.startswith(module_name + "/"):
                package_dir = module_root / imp[len(module_name) + 1 :]
                files = sorted(p for p in package_dir.glob("*.go") if not p.name.endswith("_test.go"))
                if files:
                    dep = display_path(files[0])
            if dep and dep not in deps:
                deps.append(dep)
    elif suffix == ".rs":
        for mod in re.findall(r'^\s*(?:pub\s+)?mod\s+([A-Za-z_][A-Za-z0-9_]*)\s*;', text, re.M):
            for candidate in (source.parent / f"{mod}.rs", source.parent / mod / "mod.rs"):
                if candidate.exists():
                    deps.append(norm(os.path.relpath(candidate, Path.cwd())))
                    break
    return deps


def build_tree(entry, stack=None, circular=None):
    stack = [] if stack is None else stack
    circular = [] if circular is None else circular
    rel = display_path(resolve_source(entry))
    if rel in stack:
        cycle = stack[stack.index(rel):] + [rel]
        if cycle not in circular:
            circular.append(cycle)
        return None
    children = {}
    for dep in parse_deps(rel):
        children[dep] = build_tree(dep, stack + [rel], circular)
    return children or None


def tree_json(entries):
    circular = []
    tree = {}
    for entry in entries:
        rel = display_path(resolve_source(entry))
        tree[rel] = build_tree(rel, [], circular)
    return {"tree": tree, "circularDependencies": circular, "errors": {}}


def expand_pattern(pattern):
    return sorted(norm(p) for p in glob.glob(pattern, recursive=True) if Path(p).is_file())


def explain(left_pattern, right_pattern, overlap_left=False, overlap_right=False):
    left = set(expand_pattern(left_pattern))
    right = set(expand_pattern(right_pattern))
    overlap = left & right
    if overlap_left:
        right -= overlap
    if overlap_right:
        left -= overlap
    lines = []
    for src in sorted(left):
        for dep in parse_deps(src):
            if dep in right:
                lines.append(f"{src} -> {dep}")
    return lines


def parse_scalar(raw):
    raw = raw.strip()
    if raw in {"true", "True"}:
        return True
    if raw in {"false", "False"}:
        return False
    if (raw.startswith("'") and raw.endswith("'")) or (raw.startswith('"') and raw.endswith('"')):
        return raw[1:-1]
    return raw


def load_config(path):
    if not Path(path).exists():
        return None
    cfg = {"check": {"entrypoints": [], "allow": {}, "deny": {}, "aliases": {}, "allowCircularDependencies": False}}
    section = None
    subsection = None
    current_key = None
    pending_key = None
    for raw in Path(path).read_text(encoding="utf-8", errors="ignore").splitlines():
        line = raw.split("#", 1)[0].rstrip()
        if not line.strip():
            continue
        indent = len(line) - len(line.lstrip(" "))
        stripped = line.strip()
        if indent == 0 and stripped.endswith(":"):
            section = stripped[:-1]
            subsection = None
            current_key = None
            continue
        if section != "check":
            continue
        if indent == 2 and stripped.endswith(":"):
            subsection = stripped[:-1]
            current_key = None
            continue
        if indent == 2 and ":" in stripped:
            key, val = stripped.split(":", 1)
            cfg["check"][key] = parse_scalar(val)
            continue
        if subsection == "entrypoints" and stripped.startswith("- "):
            cfg["check"]["entrypoints"].append(parse_scalar(stripped[2:]))
            continue
        if subsection in {"allow", "deny", "aliases"}:
            if indent == 4 and stripped.endswith(":"):
                current_key = parse_scalar(stripped[:-1])
                cfg["check"][subsection].setdefault(current_key, [])
                pending_key = None
            elif indent == 6 and stripped.startswith("- ") and current_key is not None:
                value = stripped[2:].strip()
                if value.startswith("to:"):
                    cfg["check"][subsection][current_key].append(parse_scalar(value.split(":", 1)[1]))
                else:
                    cfg["check"][subsection][current_key].append(parse_scalar(value))
            elif indent == 6 and stripped == "to:" and current_key is not None:
                pending_key = "to"
            elif indent >= 8 and stripped.startswith("- ") and pending_key == "to" and current_key is not None:
                cfg["check"][subsection][current_key].append(parse_scalar(stripped[2:]))
    return cfg


def all_edges(entries):
    edges = []
    seen = set()

    def visit(src):
        if src in seen:
            return
        seen.add(src)
        for dep in parse_deps(src):
            edge = (src, dep)
            if edge not in edges:
                edges.append(edge)
            visit(dep)

    for entry in entries:
        rel = display_path(resolve_source(entry))
        visit(rel)
    return edges


def expands_alias(patterns, aliases):
    out = []
    for pattern in patterns:
        out.extend(aliases.get(pattern, [pattern]))
    return out


def matches(path, patterns):
    return any(fnmatch.fnmatch(path, pattern) for pattern in patterns)


def check(config_path):
    cfg = load_config(config_path)
    if cfg is None:
        print(
            f"Error: when using the `check` subcommand, a {config_path} file must be provided, you can create one sample {config_path} file executing `dep-tree config` in your terminal",
            file=sys.stderr,
        )
        return 1
    check_cfg = cfg.get("check", {})
    entries = check_cfg.get("entrypoints") or []
    edges = all_edges(entries)
    aliases = check_cfg.get("aliases", {})
    violations = []
    for src, dep in edges:
        for src_pat, denied in check_cfg.get("deny", {}).items():
            if fnmatch.fnmatch(src, src_pat) and matches(dep, expands_alias(denied, aliases)):
                violations.append((src, dep))
        for src_pat, allowed in check_cfg.get("allow", {}).items():
            if fnmatch.fnmatch(src, src_pat) and not matches(dep, expands_alias(allowed, aliases)):
                violations.append((src, dep))
    circular = tree_json(entries)["circularDependencies"] if not check_cfg.get("allowCircularDependencies", False) else []
    if violations or circular:
        print("Error: Check failed, the following dependencies are not allowed:", file=sys.stderr)
        for src, dep in violations:
            print(f"- {src} -> {dep}", file=sys.stderr)
        if circular:
            print("\ndetected circular dependencies:", file=sys.stderr)
            for cycle in circular:
                print(f"- {' -> '.join(cycle)}", file=sys.stderr)
        return 1
    return 0


def write_config(path):
    target = Path(path)
    if target.exists():
        print(f"Error: cannot generate config file, as one already exists in {path}", file=sys.stderr)
        return 1
    target.write_text(SAMPLE_CONFIG, encoding="utf-8")
    return 0


def main(argv=None):
    argv = list(sys.argv[1:] if argv is None else argv)
    if "--version" in argv or "-v" in argv:
        print(VERSION)
        return 0
    if not argv or argv[0] in {"--help", "-h", "help"}:
        print(ROOT_HELP)
        return 0
    if len(argv) > 1 and argv[1] in {"--help", "-h"} and argv[0] in COMMAND_HELP:
        print(COMMAND_HELP[argv[0]])
        return 0
    if argv and argv[0] == "tree":
        entries = [arg for arg in argv[1:] if not arg.startswith("-")]
        if "--json" in argv:
            print(json.dumps(tree_json(entries), indent=2))
            return 0
    if argv and argv[0] == "explain":
        args = [arg for arg in argv[1:] if not arg.startswith("-")]
        if len(args) >= 2:
            for line in explain(args[0], args[1], "--overlap-left" in argv or "-l" in argv, "--overlap-right" in argv or "-r" in argv):
                print(line)
            return 0
    if argv and argv[0] == "check":
        config = ".dep-tree.yml"
        if "-c" in argv:
            config = argv[argv.index("-c") + 1]
        if "--config" in argv:
            config = argv[argv.index("--config") + 1]
        return check(config)
    if argv and argv[0] in {"config", "init"}:
        config = ".dep-tree.yml"
        if "-c" in argv:
            config = argv[argv.index("-c") + 1]
        if "--config" in argv:
            config = argv[argv.index("--config") + 1]
        return write_config(config)
    print(ROOT_HELP)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
