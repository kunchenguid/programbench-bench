#!/bin/bash
set -e
rm -f executable
cp src/dep_tree.py executable
chmod +x executable
