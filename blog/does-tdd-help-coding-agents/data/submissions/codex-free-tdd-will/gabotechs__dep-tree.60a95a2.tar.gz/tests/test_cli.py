import os
import json
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
SCRIPT = ROOT / "src" / "dep_tree.py"


def run_cli(args, cwd=None):
    return subprocess.run(
        [sys.executable, str(SCRIPT), *args],
        cwd=cwd,
        text=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
    )


class DepTreeCliTests(unittest.TestCase):
    def test_version_flag_prints_documented_version(self):
        result = run_cli(["--version"])
        self.assertEqual(result.returncode, 0)
        self.assertEqual(result.stdout.strip(), "dep-tree version v0.23.4")

    def test_tree_json_renders_python_import_dependencies(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            (root / "pkg").mkdir()
            (root / "pkg" / "__init__.py").write_text("", encoding="utf-8")
            (root / "main.py").write_text("from pkg.a import A\n", encoding="utf-8")
            (root / "pkg" / "a.py").write_text("from .b import B\nclass A: pass\n", encoding="utf-8")
            (root / "pkg" / "b.py").write_text("class B: pass\n", encoding="utf-8")

            result = run_cli(["tree", "main.py", "--json"], cwd=root)

        self.assertEqual(result.returncode, 0, result.stderr)
        payload = json.loads(result.stdout)
        self.assertEqual(
            payload,
            {
                "tree": {"main.py": {"pkg/a.py": {"pkg/b.py": None}}},
                "circularDependencies": [],
                "errors": {},
            },
        )

    def test_from_package_import_module_does_not_add_package_init(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            (root / "pkg").mkdir()
            (root / "pkg" / "__init__.py").write_text("", encoding="utf-8")
            (root / "main.py").write_text("from pkg import b\n", encoding="utf-8")
            (root / "pkg" / "b.py").write_text("", encoding="utf-8")

            result = run_cli(["tree", "main.py", "--json"], cwd=root)

        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertEqual(json.loads(result.stdout)["tree"], {"main.py": {"pkg/b.py": None}})

    def test_go_module_imports_are_reported_relative_to_go_mod(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            (root / "pkg" / "lib").mkdir(parents=True)
            (root / "go.mod").write_text("module example.com/app\n", encoding="utf-8")
            (root / "main.go").write_text(
                'package main\nimport "example.com/app/pkg/lib"\nfunc main(){lib.F()}\n',
                encoding="utf-8",
            )
            (root / "pkg" / "lib" / "lib.go").write_text("package lib\nfunc F(){}\n", encoding="utf-8")

            result = run_cli(["tree", "main.go", "--json"], cwd=root)

        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertEqual(json.loads(result.stdout)["tree"], {"main.go": {"pkg/lib/lib.go": None}})

    def test_explain_prints_edges_between_globbed_regions(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            (root / "app").mkdir()
            (root / "lib").mkdir()
            (root / "app" / "main.py").write_text("from lib.util import f\n", encoding="utf-8")
            (root / "lib" / "util.py").write_text("def f(): pass\n", encoding="utf-8")

            result = run_cli(["explain", "app/*.py", "lib/*.py"], cwd=root)

        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertEqual(result.stdout.strip(), "app/main.py -> lib/util.py")

    def test_check_fails_when_a_deny_rule_is_violated(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            (root / "app").mkdir()
            (root / "lib").mkdir()
            (root / "app" / "main.py").write_text("from lib.util import f\n", encoding="utf-8")
            (root / "lib" / "util.py").write_text("def f(): pass\n", encoding="utf-8")
            (root / ".dep-tree.yml").write_text(
                "check:\n"
                "  entrypoints:\n"
                "    - app/main.py\n"
                "  deny:\n"
                "    \"app/**\":\n"
                "      - \"lib/**\"\n",
                encoding="utf-8",
            )

            result = run_cli(["check"], cwd=root)

        self.assertEqual(result.returncode, 1)
        self.assertIn("Error: Check failed, the following dependencies are not allowed:", result.stderr)
        self.assertIn("- app/main.py -> lib/util.py", result.stderr)

    def test_check_fails_on_circular_dependencies_by_default(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            (root / "a.py").write_text("import b\n", encoding="utf-8")
            (root / "b.py").write_text("import a\n", encoding="utf-8")
            (root / ".dep-tree.yml").write_text(
                "check:\n"
                "  entrypoints:\n"
                "    - a.py\n",
                encoding="utf-8",
            )

            result = run_cli(["check"], cwd=root)

        self.assertEqual(result.returncode, 1)
        self.assertIn("detected circular dependencies:", result.stderr)
        self.assertIn("- a.py -> b.py -> a.py", result.stderr)

    def test_config_creates_sample_and_refuses_to_overwrite(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            first = run_cli(["config"], cwd=root)
            second = run_cli(["config"], cwd=root)
            content = (root / ".dep-tree.yml").read_text(encoding="utf-8")

        self.assertEqual(first.returncode, 0)
        self.assertIn("check:", content)
        self.assertIn("entrypoints:", content)
        self.assertEqual(second.returncode, 1)
        self.assertIn("Error: cannot generate config file, as one already exists in .dep-tree.yml", second.stderr)


if __name__ == "__main__":
    unittest.main()
