import subprocess
import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
BIN = ROOT / "xq.py"


def run_xq(args=None, stdin=""):
    proc = subprocess.run(
        ["python3", str(BIN), *(args or [])],
        input=stdin,
        text=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
    )
    return proc


class XqCliTests(unittest.TestCase):
    def test_formats_compact_xml_from_stdin(self):
        proc = run_xq(["--no-color"], '<root><city id="1">Paris</city><empty/></root>')
        self.assertEqual(proc.returncode, 0)
        self.assertEqual(proc.stderr, "")
        self.assertEqual(
            proc.stdout,
            '<root>\n'
            '  <city id="1">Paris</city>\n'
            '  <empty/>\n'
            '</root>\n',
        )

    def test_extracts_xpath_matches_as_text_lines(self):
        proc = run_xq(
            ["-x", "//city"],
            '<root><city id="1">Paris</city><city>Rome</city></root>',
        )
        self.assertEqual(proc.returncode, 0)
        self.assertEqual(proc.stderr, "")
        self.assertEqual(proc.stdout, "Paris\nRome\n")

    def test_extracts_css_attribute_from_html(self):
        html = '<html><head><script src="app.js"></script></head><body></body></html>'
        proc = run_xq(["-m", "-q", "head > script", "-a", "src"], html)
        self.assertEqual(proc.returncode, 0)
        self.assertEqual(proc.stderr, "")
        self.assertEqual(proc.stdout, "app.js\n")

    def test_html_formatter_keeps_empty_non_void_tags_paired(self):
        html = '<html><head><script src="app.js"></script></head></html>'
        proc = run_xq(["-m", "--no-color"], html)
        self.assertEqual(proc.returncode, 0)
        self.assertEqual(
            proc.stdout,
            '<html>\n'
            '  <head>\n'
            '    <script src="app.js"></script>\n'
            '  </head>\n'
            '</html>\n',
        )

    def test_extracted_empty_html_node_uses_self_open_plus_close(self):
        proc = run_xq(["-m", "-n", "-q", "img"], '<html><body><img src="x.png"></body></html>')
        self.assertEqual(proc.returncode, 0)
        self.assertEqual(proc.stdout, '<img src="x.png"/></img>\n')

    def test_xml_tail_text_stays_after_previous_child(self):
        proc = run_xq(["--no-color"], "<r><a/>tail</r>")
        self.assertEqual(proc.returncode, 0)
        self.assertEqual(proc.stdout, "<r>\n  <a/>tail</r>\n")

    def test_missing_file_error_matches_cli(self):
        proc = run_xq(["missing.xml"])
        self.assertEqual(proc.returncode, 1)
        self.assertEqual(proc.stdout, "")
        self.assertEqual(proc.stderr, "Error: open missing.xml: no such file or directory\n")

    def test_outputs_json_preserving_attributes_and_repeated_elements(self):
        xml = '<root><city id="1">Paris</city><city>Rome</city><empty/></root>'
        proc = run_xq(["-j"], xml)
        self.assertEqual(proc.returncode, 0)
        self.assertEqual(proc.stderr, "")
        self.assertEqual(
            proc.stdout,
            '{\n'
            '  "root": {\n'
            '    "city": [\n'
            '      {\n'
            '        "#text": "Paris",\n'
            '        "@id": "1"\n'
            '      },\n'
            '      "Rome"\n'
            '    ],\n'
            '    "empty": {\n'
            '\n'
            '    }\n'
            '  }\n'
            '}\n',
        )


if __name__ == "__main__":
    unittest.main()
