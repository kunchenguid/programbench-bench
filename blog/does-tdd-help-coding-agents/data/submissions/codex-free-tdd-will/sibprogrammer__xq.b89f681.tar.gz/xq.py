#!/usr/bin/env python3
import json
import os
import re
import sys
from dataclasses import dataclass, field
from html import unescape


VERSION = "xq version 1.4.0"
VOID_HTML = {
    "area", "base", "br", "col", "embed", "hr", "img", "input", "link",
    "meta", "param", "source", "track", "wbr",
}


@dataclass
class Text:
    value: str


@dataclass
class Special:
    kind: str
    value: str


@dataclass
class Element:
    name: str
    attrs: list = field(default_factory=list)
    children: list = field(default_factory=list)


@dataclass
class Document:
    children: list = field(default_factory=list)


def parse_attrs(src):
    attrs = []
    i = 0
    n = len(src)
    while i < n:
        while i < n and src[i].isspace():
            i += 1
        if i >= n:
            break
        start = i
        while i < n and not src[i].isspace() and src[i] != "=":
            i += 1
        name = src[start:i]
        while i < n and src[i].isspace():
            i += 1
        value = ""
        if i < n and src[i] == "=":
            i += 1
            while i < n and src[i].isspace():
                i += 1
            if i < n and src[i] in "\"'":
                quote = src[i]
                i += 1
                start = i
                while i < n and src[i] != quote:
                    i += 1
                value = src[start:i]
                if i < n:
                    i += 1
            else:
                start = i
                while i < n and not src[i].isspace():
                    i += 1
                value = src[start:i]
        if name:
            attrs.append((name, unescape(value)))
    return attrs


def parse_document(src, html_mode=False):
    doc = Document()
    stack = [doc]
    token_re = re.compile(r"<!--.*?-->|<!\[CDATA\[.*?\]\]>|<\?.*?\?>|<![^>]*>|</?[^>]+>", re.S)
    pos = 0
    for m in token_re.finditer(src):
        if m.start() > pos:
            add_text(stack[-1], src[pos:m.start()])
        tok = m.group(0)
        low = tok.lower()
        if tok.startswith("<!--"):
            stack[-1].children.append(Special("comment", tok[4:-3]))
        elif tok.startswith("<![CDATA["):
            add_text(stack[-1], tok[9:-3], preserve=True)
        elif tok.startswith("<?"):
            stack[-1].children.append(Special("pi", tok[2:-2].strip()))
        elif low.startswith("<!doctype"):
            stack[-1].children.append(Special("doctype", tok[2:-1].strip()))
        elif tok.startswith("</"):
            name = tok[2:-1].strip().split()[0].lower()
            for idx in range(len(stack) - 1, 0, -1):
                if stack[idx].name.lower() == name:
                    del stack[idx:]
                    break
        else:
            body = tok[1:-1].strip()
            self_close = body.endswith("/")
            if self_close:
                body = body[:-1].rstrip()
            if not body:
                pos = m.end()
                continue
            parts = body.split(None, 1)
            name = parts[0]
            attrs = parse_attrs(parts[1] if len(parts) > 1 else "")
            elem = Element(name, attrs)
            stack[-1].children.append(elem)
            if not self_close and not (html_mode and name.lower() in VOID_HTML):
                stack.append(elem)
        pos = m.end()
    if pos < len(src):
        add_text(stack[-1], src[pos:])
    return doc


def add_text(parent, value, preserve=False):
    if not preserve and value.strip() == "":
        return
    text = unescape(value) if not preserve else value
    if text:
        parent.children.append(Text(text))


def attr_string(attrs, color=False):
    if not attrs:
        return ""
    if color:
        return "".join(f' {k}\033[32m="{escape_attr(v)}"\033[0m' for k, v in attrs)
    return "".join(f' {k}="{escape_attr(v)}"' for k, v in attrs)


def escape_attr(value):
    return value.replace("&", "&amp;").replace('"', "&quot;")


def render_text(value):
    val = value.strip()
    if any(ch in val for ch in "<>&"):
        return f"<![CDATA[{val}]]>"
    return val


def open_tag(elem, color=False, close=">"):
    if color:
        return f"\033[33m<{elem.name}\033[0m{attr_string(elem.attrs, True)}\033[33m{close}\033[0m"
    return f"<{elem.name}{attr_string(elem.attrs)}{close}"


def close_tag(elem, color=False):
    if color:
        return f"\033[33m</{elem.name}>\033[0m"
    return f"</{elem.name}>"


def format_node(node, level=0, unit="  ", color=False, force_pair_empty=False, html_mode=False):
    pad = unit * level
    if isinstance(node, Text):
        return [pad + render_text(node.value)]
    if isinstance(node, Special):
        if node.kind == "comment":
            return [pad + f"<!--{node.value}-->"]
        if node.kind == "doctype":
            return [pad + f"<!{node.value}>"]
        if node.kind == "pi":
            return [pad + f"<?{node.value}?>"]
    elem = node
    children = [c for c in elem.children if not (isinstance(c, Text) and c.value.strip() == "")]
    if not children:
        if force_pair_empty:
            return [pad + open_tag(elem, color, "/>") + close_tag(elem, color)]
        if html_mode and elem.name.lower() not in VOID_HTML:
            return [pad + open_tag(elem, color) + close_tag(elem, color)]
        return [pad + open_tag(elem, color, "/>")]
    if len(children) == 1 and isinstance(children[0], Text):
        return [pad + open_tag(elem, color) + render_text(children[0].value) + close_tag(elem, color)]
    lines = []
    first_text = children and isinstance(children[0], Text)
    if first_text:
        lines.append(pad + open_tag(elem, color) + render_text(children[0].value))
        rest = children[1:]
    else:
        lines.append(pad + open_tag(elem, color))
        rest = children
    closed = False
    for idx, child in enumerate(rest):
        if isinstance(child, Text) and lines:
            lines[-1] += render_text(child.value)
            if idx == len(rest) - 1:
                lines[-1] += close_tag(elem, color)
                closed = True
        else:
            lines.extend(format_node(child, level + 1, unit, color, html_mode=html_mode))
    if closed:
        return lines
    lines.append(pad + close_tag(elem, color))
    return lines


def format_document(doc, unit="  ", color=False, html_mode=False):
    lines = []
    for child in doc.children:
        lines.extend(format_node(child, 0, unit, color, html_mode=html_mode))
    return "\n".join(lines) + ("\n" if lines else "")


def text_content(node):
    if isinstance(node, Text):
        return node.value.strip()
    if isinstance(node, Element):
        parts = []
        for child in node.children:
            t = text_content(child)
            if t:
                parts.append(t)
        return " ".join(parts)
    return ""


def descendants(node):
    for child in getattr(node, "children", []):
        if isinstance(child, Element):
            yield child
            yield from descendants(child)


def root_elements(doc):
    return [c for c in doc.children if isinstance(c, Element)]


def parse_step(step):
    attr = None
    if step.startswith("@"):
        return ("@", step[1:], None)
    m = re.match(r"^([A-Za-z_][\w:.-]*|\*)(?:\[(\d+)\])?$", step)
    if not m:
        return (step, attr, None)
    return (m.group(1), None, int(m.group(2)) if m.group(2) else None)


def child_elements(node):
    return [c for c in getattr(node, "children", []) if isinstance(c, Element)]


def xpath_query(doc, expr, first=False):
    expr = expr.strip()
    if not expr:
        return []
    attr_name = None
    if "/@" in expr:
        expr, attr_name = expr.rsplit("/@", 1)
    anywhere = expr.startswith("//")
    steps = [s for s in expr.strip("/").split("/") if s]
    current = []
    if anywhere and steps:
        name, _, pos = parse_step(steps[0])
        matches = [e for e in descendants(doc) if name == "*" or e.name == name]
        current = apply_pos(matches, pos)
        steps = steps[1:]
    else:
        current = root_elements(doc)
    for idx, step in enumerate(steps):
        name, kind, pos = parse_step(step)
        if idx == 0 and not anywhere:
            matches = [e for e in current if name == "*" or e.name == name]
        else:
            matches = []
            for node in current:
                matches.extend([e for e in child_elements(node) if name == "*" or e.name == name])
        current = apply_pos(matches, pos)
    if attr_name:
        values = []
        for node in current:
            for k, v in node.attrs:
                if k == attr_name:
                    values.append(v)
        return values[:1] if first else values
    return current[:1] if first else current


def apply_pos(nodes, pos):
    if pos is None:
        return nodes
    return [nodes[pos - 1]] if 0 < pos <= len(nodes) else []


def parse_selector(selector):
    spaced = selector.replace(">", " > ")
    return [p for p in spaced.split() if p]


def match_simple(elem, simple):
    attr_match = re.search(r"\[([^=\]]+)(?:=([^\]]+))?\]$", simple)
    attr_req = None
    if attr_match:
        attr_req = (attr_match.group(1), (attr_match.group(2) or "").strip("\"'"))
        simple = simple[:attr_match.start()]
    ident = None
    klass = None
    tag = simple or "*"
    if "#" in simple:
        tag, ident = simple.split("#", 1)
        tag = tag or "*"
    if "." in tag:
        tag, klass = tag.split(".", 1)
        tag = tag or "*"
    if tag != "*" and elem.name.lower() != tag.lower():
        return False
    attrs = dict(elem.attrs)
    if ident is not None and attrs.get("id") != ident:
        return False
    if klass is not None and klass not in attrs.get("class", "").split():
        return False
    if attr_req is not None:
        k, v = attr_req
        if k not in attrs:
            return False
        if v and attrs.get(k) != v:
            return False
    return True


def css_query(doc, selector):
    tokens = parse_selector(selector)
    current = root_elements(doc)
    relation = "desc"
    for token in tokens:
        if token == ">":
            relation = "child"
            continue
        candidates = []
        bases = current if current else root_elements(doc)
        if relation == "child":
            for b in bases:
                candidates.extend(child_elements(b))
        else:
            for b in bases:
                if match_simple(b, token):
                    candidates.append(b)
                candidates.extend(descendants(b))
        current = [e for e in candidates if match_simple(e, token)]
        relation = "desc"
    return current


def to_json_value(elem, depth=-1, current=0):
    attrs = {f"@{k}": v for k, v in elem.attrs}
    elems = child_elements(elem)
    text = text_content_direct(elem)
    if depth >= 0 and current >= depth:
        return text_content(elem)
    if not attrs and not elems:
        return text if text else {}
    obj = {}
    if text:
        obj["#text"] = text
    for k, v in attrs.items():
        obj[k] = v
    grouped = {}
    for child in elems:
        grouped.setdefault(child.name, []).append(to_json_value(child, depth, current + 1))
    for name, values in grouped.items():
        obj[name] = values if len(values) > 1 else values[0]
    return obj


def text_content_direct(elem):
    vals = [c.value.strip() for c in elem.children if isinstance(c, Text) and c.value.strip()]
    return " ".join(vals)


def json_document(doc, depth=-1, compact=False):
    out = {}
    for elem in root_elements(doc):
        val = to_json_value(elem, depth, 0)
        if elem.name in out:
            if not isinstance(out[elem.name], list):
                out[elem.name] = [out[elem.name]]
            out[elem.name].append(val)
        else:
            out[elem.name] = val
    if compact:
        return json.dumps(out, ensure_ascii=False, separators=(",", ": ")) + "\n"
    return dump_json_pretty(out) + "\n"


def dump_json_pretty(value, level=0):
    pad = "  " * level
    inner = "  " * (level + 1)
    if isinstance(value, dict):
        if not value:
            return "{\n\n" + pad + "}"
        items = list(value.items())
        lines = ["{"]
        for i, (k, v) in enumerate(items):
            comma = "," if i + 1 < len(items) else ""
            lines.append(f"{inner}{json.dumps(k, ensure_ascii=False)}: {dump_json_pretty(v, level + 1)}{comma}")
        lines.append(pad + "}")
        return "\n".join(lines)
    if isinstance(value, list):
        if not value:
            return "[]"
        lines = ["["]
        for i, item in enumerate(value):
            comma = "," if i + 1 < len(value) else ""
            lines.append(f"{inner}{dump_json_pretty(item, level + 1)}{comma}")
        lines.append(pad + "]")
        return "\n".join(lines)
    return json.dumps(value, ensure_ascii=False)


HELP = """Command-line XML and HTML beautifier and content extractor

Usage:
  xq [flags]

Flags:
  -a, --attr string      Extract an attribute value instead of node content for provided CSS query
  -c, --color            Force colorful output
      --compact          Compact JSON output (no indentation)
  -d, --depth int        Maximum nesting depth for JSON output (-1 for unlimited) (default -1)
  -e, --extract string   Extract a single node from XML
  -h, --help             Print this help message
  -m, --html             Use HTML formatter
  -i, --in-place         Format file in place
      --indent int       Use the given number of spaces for indentation (default 2)
  -j, --json             Output the result as JSON
      --no-color         Disable colorful output
  -n, --node             Return the node content instead of text
  -q, --query string     Extract the node(s) using CSS selector
      --tab              Use tabs for indentation
  -v, --version          Print version information
  -x, --xpath string     Extract the node(s) from XML
"""


def parse_args(argv):
    opts = {
        "indent": 2, "tab": False, "color": False, "html": False,
        "json": False, "compact": False, "depth": -1, "node": False,
        "xpath": None, "extract": None, "query": None, "attr": None,
        "in_place": False, "file": None,
    }
    i = 0
    while i < len(argv):
        a = argv[i]
        if a in ("-h", "--help"):
            print(HELP, end="")
            raise SystemExit(0)
        if a in ("-v", "--version"):
            print(VERSION)
            raise SystemExit(0)
        if a in ("-c", "--color"):
            opts["color"] = True
        elif a == "--no-color":
            opts["color"] = False
        elif a == "--tab":
            opts["tab"] = True
        elif a in ("-m", "--html"):
            opts["html"] = True
        elif a in ("-j", "--json"):
            opts["json"] = True
        elif a == "--compact":
            opts["compact"] = True
        elif a in ("-n", "--node"):
            opts["node"] = True
        elif a in ("-i", "--in-place"):
            opts["in_place"] = True
        elif a == "--indent":
            i += 1
            opts["indent"] = int(argv[i])
        elif a in ("-d", "--depth"):
            i += 1
            opts["depth"] = int(argv[i])
        elif a in ("-x", "--xpath"):
            i += 1
            opts["xpath"] = argv[i]
        elif a in ("-e", "--extract"):
            i += 1
            opts["extract"] = argv[i]
        elif a in ("-q", "--query"):
            i += 1
            opts["query"] = argv[i]
        elif a in ("-a", "--attr"):
            i += 1
            opts["attr"] = argv[i]
        elif a.startswith("-"):
            print(f"Error: unknown flag: {a}", file=sys.stderr)
            raise SystemExit(1)
        else:
            opts["file"] = a
        i += 1
    return opts


def read_input(path):
    if path:
        try:
            with open(path, "r", encoding="utf-8") as f:
                return f.read()
        except OSError as e:
            print(f"Error: open {path}: {os.strerror(e.errno).lower()}", file=sys.stderr)
            raise SystemExit(1)
    return sys.stdin.read()


def main(argv):
    opts = parse_args(argv)
    src = read_input(opts["file"])
    doc = parse_document(src, opts["html"])
    unit = "\t" if opts["tab"] else " " * opts["indent"]
    if opts["json"]:
        out = json_document(doc, opts["depth"], opts["compact"])
    elif opts["xpath"] is not None or opts["extract"] is not None:
        first = opts["extract"] is not None
        results = xpath_query(doc, opts["extract"] if first else opts["xpath"], first)
        out = extraction_output(results, opts["node"], unit)
    elif opts["query"] is not None:
        results = css_query(doc, opts["query"])
        if opts["attr"]:
            vals = []
            for node in results:
                vals.extend(v for k, v in node.attrs if k == opts["attr"])
            out = "\n".join(vals) + ("\n" if vals else "")
        else:
            out = extraction_output(results, opts["node"], unit)
    else:
        out = format_document(doc, unit, opts["color"], opts["html"])
    if opts["in_place"] and opts["file"]:
        with open(opts["file"], "w", encoding="utf-8") as f:
            f.write(out)
    else:
        sys.stdout.write(out)


def extraction_output(results, node_mode, unit):
    lines = []
    for r in results:
        if isinstance(r, str):
            lines.append(r)
        elif node_mode:
            lines.extend(format_node(r, 0, unit, False, force_pair_empty=True))
        else:
            lines.append(text_content(r))
    return "\n".join(lines) + ("\n" if lines else "")


if __name__ == "__main__":
    main(sys.argv[1:])
