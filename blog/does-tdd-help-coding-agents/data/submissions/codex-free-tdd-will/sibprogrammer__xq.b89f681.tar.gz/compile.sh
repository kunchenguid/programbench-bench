#!/bin/bash
set -e
cp xq.py executable
chmod +x executable
