#!/usr/bin/env python3
import math
import sys


VERSION = "eva 0.3.1"


class CalcError(Exception):
    def __init__(self, message, code=1):
        super().__init__(message)
        self.message = message
        self.code = code


class Parser:
    def __init__(self, text, angle_unit="degree", previous=0.0):
        self.tokens = self._tokens(self._balance(text))
        self.pos = 0
        self.angle_unit = angle_unit
        self.previous = previous

    def _balance(self, text):
        compact = "".join(text.split())
        missing = compact.count("(") - compact.count(")")
        if missing > 0:
            compact += ")" * missing
        return compact

    def _tokens(self, text):
        raw = []
        i = 0
        while i < len(text):
            c = text[i]
            if c.isdigit() or c == ".":
                j = i + 1
                while j < len(text) and (text[j].isdigit() or text[j] == "."):
                    j += 1
                raw.append(("num", text[i:j]))
                i = j
            elif c.isalpha() or c == "_":
                j = i + 1
                while j < len(text) and (text[j].isalpha() or text[j].isdigit() or text[j] == "_"):
                    j += 1
                raw.append(("id", text[i:j]))
                i = j
            elif c in "+-/^(),":
                raw.append((c, c))
                i += 1
            elif c == "*":
                if i + 1 < len(text) and text[i + 1] == "*":
                    raw.append(("^", "**"))
                    i += 2
                else:
                    raw.append(("*", "*"))
                    i += 1
            else:
                raise CalcError("Syntax Error: Mismatched parentheses!")

        out = []
        for tok in raw:
            if out and self._needs_mul(out[-1], tok, raw):
                out.append(("*", "*"))
            out.append(tok)
        return out

    def _needs_mul(self, left, right, raw):
        left_value = left[0] in ("num", "id", ")")
        right_value = right[0] in ("num", "id", "(")
        if not (left_value and right_value):
            return False
        if left[0] == "id" and right[0] == "(" and left[1] not in ("pi", "e", "_"):
            return False
        return True

    def peek(self):
        return self.tokens[self.pos] if self.pos < len(self.tokens) else ("eof", "")

    def take(self, kind=None):
        tok = self.peek()
        if kind is not None and tok[0] != kind:
            raise CalcError("Parser Error: Too many operators, too few operands")
        self.pos += 1
        return tok

    def parse(self):
        if not self.tokens:
            return None
        value = self.expr()
        if self.peek()[0] != "eof":
            if self.peek()[0] == ",":
                raise CalcError("Syntax Error: Mismatched parentheses!")
            raise CalcError("Parser Error: Too many operators, too few operands")
        return value

    def expr(self):
        value = self.term()
        while self.peek()[0] in ("+", "-"):
            op = self.take()[0]
            rhs = self.term()
            value = value + rhs if op == "+" else value - rhs
        return value

    def term(self):
        value = self.power()
        while self.peek()[0] in ("*", "/"):
            op = self.take()[0]
            rhs = self.power()
            if op == "*":
                value *= rhs
            else:
                if rhs == 0:
                    raise CalcError("Math Error: Divide by zero error!")
                value /= rhs
        return value

    def power(self):
        value = self.unary()
        if self.peek()[0] == "^":
            self.take("^")
            value = math.pow(value, self.power())
        return value

    def unary(self):
        if self.peek()[0] == "+":
            self.take("+")
            return self.unary()
        if self.peek()[0] == "-":
            self.take("-")
            return -self.unary()
        return self.primary()

    def primary(self):
        kind, value = self.peek()
        if kind == "num":
            self.take("num")
            try:
                return float(value)
            except ValueError:
                raise CalcError("Parser Error: Too many operators, too few operands")
        if kind == "(":
            self.take("(")
            value = self.expr()
            self.take(")")
            return value
        if kind == "id":
            self.take("id")
            if value == "pi":
                return math.pi
            if value == "e":
                return math.e
            if value == "_":
                return self.previous
            self.take("(")
            args = [self.expr()]
            while self.peek()[0] == ",":
                self.take(",")
                args.append(self.expr())
            self.take(")")
            return self.call(value, args)
        raise CalcError("Parser Error: Too many operators, too few operands")

    def to_radians(self, x):
        if self.angle_unit == "radian":
            return x
        return math.radians(x)

    def call(self, name, args):
        one = {
            "sin": lambda x: math.sin(self.to_radians(x)),
            "cos": lambda x: math.cos(self.to_radians(x)),
            "tan": lambda x: math.tan(self.to_radians(x)),
            "csc": lambda x: 1 / math.sin(self.to_radians(x)),
            "sec": lambda x: 1 / math.cos(self.to_radians(x)),
            "cot": lambda x: 1 / math.tan(self.to_radians(x)),
            "sinh": math.sinh,
            "cosh": math.cosh,
            "tanh": math.tanh,
            "asin": math.asin,
            "acos": math.acos,
            "atan": math.atan,
            "acsc": lambda x: math.asin(1 / x),
            "asec": lambda x: math.acos(1 / x),
            "acot": lambda x: math.atan(1 / x),
            "ln": math.log,
            "log2": math.log2,
            "log10": math.log10,
            "sqrt": math.sqrt,
            "ceil": math.ceil,
            "floor": math.floor,
            "abs": abs,
        }
        two = {
            "log": lambda x, base: math.log(x, base),
            "nroot": lambda x, n: math.pow(x, 1 / n),
        }
        try:
            if name in one and len(args) == 1:
                return float(one[name](args[0]))
            if name in two and len(args) == 2:
                return float(two[name](args[0], args[1]))
        except (ValueError, OverflowError):
            raise CalcError("Domain Error: Out of bounds!")
        except ZeroDivisionError:
            raise CalcError("Math Error: Divide by zero error!")
        raise CalcError("Parser Error: Too many operators, too few operands")


def evaluate(text, angle_unit="degree", previous=0.0):
    try:
        value = Parser(text, angle_unit, previous).parse()
        if value is None:
            return None
        if not math.isfinite(value):
            raise CalcError("Domain Error: Out of bounds!")
        return value
    except CalcError:
        raise
    except (ValueError, OverflowError):
        raise CalcError("Domain Error: Out of bounds!")
    except ZeroDivisionError:
        raise CalcError("Math Error: Divide by zero error!")


def format_base(value, radix):
    sign = "-" if value < 0 else ""
    n = int(abs(value))
    digits = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ"
    if n == 0:
        converted = "0"
    else:
        parts = []
        while n:
            parts.append(digits[n % radix])
            n //= radix
        converted = "".join(reversed(parts))
    groups = []
    while converted:
        groups.append(converted[-3:])
        converted = converted[:-3]
    groups.reverse()
    while len(groups) < 4:
        groups.insert(0, "")
    shown = groups[-4:]
    rendered = shown[0].rjust(1) + "," + ",".join(g.rjust(3) for g in shown[1:])
    return f"{sign}{rendered}.0"


def format_value(value, fix, radix):
    if radix == 10:
        return f"{value:.{fix}f}"
    return format_base(value, radix)


HELP = """Calculator REPL similar to bc(1)

Usage: executable [OPTIONS] [INPUT]

Arguments:
  [INPUT]  Optional expression string to run eva in command mode

Options:
  -f, --fix <FIX>                Number of decimal places in output (1 - 64) [default: 10]
  -b, --base <RADIX>             Radix of calculation output (1 - 36) [default: 10]
  -a, --angle_unit <angle_unit>  Angle unit [default: degree] [possible values: degree, radian, gradian]
  -h, --help                     Print help
  -V, --version                  Print version"""


def parse_args(argv):
    fix = 10
    radix = 10
    angle = "degree"
    expr = None
    i = 0
    while i < len(argv):
        arg = argv[i]
        if arg in ("-h", "--help"):
            return {"help": True}
        if arg in ("-V", "--version"):
            return {"version": True}
        if arg in ("-f", "--fix"):
            i += 1
            if i >= len(argv):
                raise CalcError("error: a value is required for '--fix <FIX>' but none was supplied", 2)
            fix = int(argv[i])
            if fix < 1 or fix > 64:
                raise CalcError(f"error: invalid value '{argv[i]}' for '--fix <FIX>': {fix} is not in 1..=64\n\nFor more information, try '--help'.", 2)
        elif arg in ("-b", "--base"):
            i += 1
            if i >= len(argv):
                raise CalcError("error: a value is required for '--base <RADIX>' but none was supplied", 2)
            radix = int(argv[i])
            if radix < 1 or radix > 36:
                raise CalcError(f"error: invalid value '{argv[i]}' for '--base <RADIX>': {radix} is not in 1..=36\n\nFor more information, try '--help'.", 2)
            if radix == 1:
                radix = 10
        elif arg in ("-a", "--angle_unit"):
            i += 1
            if i >= len(argv):
                raise CalcError("error: a value is required for '--angle_unit <angle_unit>' but none was supplied", 2)
            angle = argv[i]
            if angle not in ("degree", "radian", "gradian"):
                raise CalcError(f"error: invalid value '{angle}' for '--angle_unit <angle_unit>'\n  [possible values: degree, radian, gradian]\n\nFor more information, try '--help'.", 2)
        elif arg.startswith("-"):
            raise CalcError(f"error: unexpected argument '{arg}' found\n\nUsage: executable [OPTIONS] [INPUT]\n\nFor more information, try '--help'.", 2)
        else:
            if expr is None:
                expr = arg
            else:
                expr += arg
        i += 1
    return {"fix": fix, "radix": radix, "angle": angle, "expr": expr}


def run_line(line, options, previous):
    value = evaluate(line, options["angle"], previous)
    if value is None:
        return previous, None
    return value, format_value(value, options["fix"], options["radix"])


def main(argv=None):
    argv = sys.argv[1:] if argv is None else argv
    try:
        options = parse_args(argv)
        if options.get("help"):
            print(HELP)
            return 0
        if options.get("version"):
            print(VERSION)
            return 0
        if options["expr"] is not None:
            value = evaluate(options["expr"], options["angle"])
            if value is not None:
                print(format_value(value, options["fix"], options["radix"]))
            return 0
        if sys.stdin.isatty():
            print("No previous history.")
            return 0
        previous = 0.0
        for line in sys.stdin:
            line = line.rstrip("\n")
            if not line:
                continue
            try:
                previous, output = run_line(line, options, previous)
                if output is not None:
                    print(output)
            except CalcError as exc:
                print(exc.message)
        return 0
    except CalcError as exc:
        print(exc.message)
        return exc.code
    except Exception:
        print("Parser Error: Too many operators, too few operands")
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
