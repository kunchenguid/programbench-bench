#!/bin/bash
set -e
rm -f executable
cp eva.py executable
chmod +x executable
