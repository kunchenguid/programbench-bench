#!/usr/bin/env python3
import os
import re
import sys
import json
from pathlib import Path


VERSION = "ast-grep 0.42.1"


TOP_HELP = """Search and Rewrite code at large scale using AST pattern.

Usage: executable [OPTIONS] <COMMAND>

Commands:
  run          Run one time search or rewrite in command line. (default command)
  scan         Scan and rewrite code by configuration
  test         Test ast-grep rules
  new          Create new ast-grep project or items like rules/tests
  lsp          Start language server
  completions  Generate shell completion script
  help         Print this message or the help of the given subcommand(s)

Options:
  -c, --config <CONFIG_FILE>  Path to ast-grep root config, default is sgconfig.yml
  -h, --help                  Print help (see a summary with '-h')
  -V, --version               Print version
"""

RUN_HELP = """Run one time search or rewrite in command line. (default command)

Usage: executable run [OPTIONS] --pattern <PATTERN> [PATHS]...

Options:
  -p, --pattern <PATTERN>     AST pattern to match
  -r, --rewrite <FIX>         String to replace the matched AST node
  -l, --lang <LANG>           The language of the pattern
      --stdin                 Enable search code from StdIn.
      --files-with-matches    Print only the paths with at least one match
      --json[=<STYLE>]        Output matches in structured JSON
  -A, --after <NUM>           Show NUM lines after each match.
  -B, --before <NUM>          Show NUM lines before each match.
  -C, --context <NUM>         Show NUM lines around each match.
  -h, --help                  Print help
"""

SCAN_HELP = """Scan and rewrite code by configuration

Usage: executable scan [OPTIONS] [PATHS]...

Options:
  -r, --rule <RULE_FILE>      Scan the codebase with the single rule located at RULE_FILE.
      --inline-rules <TEXT>   Scan with a rule defined by text.
      --format <FORMAT>       Supported formats: github, sarif
      --report-style <STYLE>  rich, medium, or short
      --json[=<STYLE>]        Output matches in structured JSON
  -h, --help                  Print help
"""


def parse_options(argv):
    if argv and argv[0] == "run":
        argv = argv[1:]
    opts = {
        "paths": [],
        "pattern": None,
        "lang": None,
        "json": None,
        "rewrite": None,
        "update_all": False,
        "stdin": False,
        "files_with_matches": False,
        "before": 0,
        "after": 0,
        "heading": "never",
    }
    i = 0
    while i < len(argv):
        arg = argv[i]
        if arg in ("-p", "--pattern"):
            i += 1
            opts["pattern"] = argv[i]
        elif arg in ("-r", "--rewrite"):
            i += 1
            opts["rewrite"] = argv[i]
        elif arg in ("-l", "--lang"):
            i += 1
            opts["lang"] = argv[i]
        elif arg == "-U" or arg == "--update-all":
            opts["update_all"] = True
        elif arg == "--stdin":
            opts["stdin"] = True
        elif arg == "--files-with-matches":
            opts["files_with_matches"] = True
        elif arg in ("-A", "--after"):
            i += 1
            opts["after"] = int(argv[i])
        elif arg in ("-B", "--before"):
            i += 1
            opts["before"] = int(argv[i])
        elif arg in ("-C", "--context"):
            i += 1
            opts["before"] = opts["after"] = int(argv[i])
        elif arg == "--heading":
            i += 1
            opts["heading"] = argv[i]
        elif arg.startswith("--heading="):
            opts["heading"] = arg.split("=", 1)[1]
        elif arg in ("-c", "--config", "-j", "--threads", "--color", "--globs", "--no-ignore"):
            i += 1
        elif arg == "--json":
            opts["json"] = "pretty"
        elif arg.startswith("--json="):
            opts["json"] = arg.split("=", 1)[1] or "pretty"
        elif arg.startswith("--"):
            pass
        else:
            opts["paths"].append(arg)
        i += 1
    if not opts["paths"]:
        opts["paths"] = ["."]
    return opts


def pattern_to_regex(pattern):
    out = []
    vars_seen = []
    i = 0
    while i < len(pattern):
        if pattern[i] == "$" and i + 1 < len(pattern) and (pattern[i + 1].isalpha() or pattern[i + 1] == "_"):
            j = i + 1
            while j < len(pattern) and (pattern[j].isalnum() or pattern[j] == "_"):
                j += 1
            name = pattern[i + 1:j]
            if name in vars_seen:
                out.append(f"(?P={name})")
            else:
                vars_seen.append(name)
                out.append(f"(?P<{name}>.+?)")
            i = j
        elif pattern[i].isspace():
            out.append(r"\s+")
            i += 1
        else:
            out.append(re.escape(pattern[i]))
            i += 1
    return re.compile("".join(out)), vars_seen


def iter_files(paths):
    for raw in paths:
        path = Path(raw)
        if path.is_file():
            yield path
        elif path.is_dir():
            for root, dirs, files in os.walk(path):
                dirs[:] = [d for d in dirs if not d.startswith(".")]
                for name in sorted(files):
                    if not name.startswith("."):
                        yield Path(root) / name


def scan_lines(path_label, content, regex, var_names, lang, opts):
    records = []
    plain_lines = []
    count = 0
    lines = content.splitlines()
    starts = line_starts(content)
    for lineno, line in enumerate(lines, 1):
        for match in regex.finditer(line):
            count += 1
            if opts.get("json"):
                records.append(make_record(path_label, content, starts, line, lineno, match, var_names, lang))
            elif not opts.get("files_with_matches"):
                plain_lines.append(f"{path_label}:{lineno}:{line}")
            break
    return count, plain_lines, records


def line_starts(text):
    starts = [0]
    for i, ch in enumerate(text):
        if ch == "\n":
            starts.append(i + 1)
    return starts


def language_name(_lang):
    aliases = {
        "js": "JavaScript",
        "javascript": "JavaScript",
        "ts": "TypeScript",
        "typescript": "TypeScript",
        "py": "Python",
        "python": "Python",
        "rs": "Rust",
        "rust": "Rust",
        "go": "Go",
    }
    return aliases.get((_lang or "").lower(), _lang or "Unknown")


def make_record(path, text, starts, line, lineno, match, var_names, lang):
    abs_line_start = starts[lineno - 1]
    start = abs_line_start + match.start()
    end = abs_line_start + match.end()
    single = {}
    for name in var_names:
        if name not in match.groupdict():
            continue
        var_start = abs_line_start + match.start(name)
        var_end = abs_line_start + match.end(name)
        single[name] = {
            "text": match.group(name),
            "range": {
                "byteOffset": {"start": var_start, "end": var_end},
                "start": {"line": lineno - 1, "column": match.start(name)},
                "end": {"line": lineno - 1, "column": match.end(name)},
            },
        }
    return {
        "text": match.group(0),
        "range": {
            "byteOffset": {"start": start, "end": end},
            "start": {"line": lineno - 1, "column": match.start()},
            "end": {"line": lineno - 1, "column": match.end()},
        },
        "file": str(path),
        "lines": line,
        "charCount": {"leading": match.start(), "trailing": len(line) - match.end()},
        "language": language_name(lang),
        "metaVariables": {"single": single, "multi": {}},
        "transformed": {},
    }


def run_search(argv):
    opts = parse_options(argv)
    if not opts["pattern"]:
        print("error: the following required arguments were not provided:", file=sys.stderr)
        print("  --pattern <PATTERN>", file=sys.stderr)
        return 2
    regex, var_names = pattern_to_regex(opts["pattern"])
    count = 0
    records = []
    if opts["stdin"]:
        content = sys.stdin.read()
        count, plain_lines, records = scan_lines("STDIN", content, regex, var_names, opts["lang"], opts)
        if opts["json"]:
            emit_json(records, opts["json"])
        elif not opts["files_with_matches"]:
            for line in plain_lines:
                print(line)
        elif count:
            print("STDIN")
        return 0 if count else 1
    for path in iter_files(opts["paths"]):
        try:
            content = path.read_text(encoding="utf-8")
        except UnicodeDecodeError:
            continue
        lines = content.splitlines(keepends=True)
        starts = line_starts(content)
        new_lines = []
        context_indexes = set()
        for lineno, line in enumerate(lines, 1):
            body = line.rstrip("\n")
            newline = line[len(body):]
            line_count_before = count
            def repl(match):
                nonlocal count
                count += 1
                if opts["rewrite"] and opts["update_all"]:
                    value = opts["rewrite"]
                    for name, group in match.groupdict().items():
                        value = value.replace(f"${name}", group)
                    return value
                else:
                    return match.group(0)
            if opts["rewrite"] and opts["update_all"]:
                new_body = regex.sub(repl, body)
                new_lines.append(new_body + newline)
                continue
            for match in regex.finditer(body):
                count += 1
                if opts["json"]:
                    records.append(make_record(path, content, starts, body, lineno, match, var_names, opts["lang"]))
                elif opts["before"] or opts["after"]:
                    start = max(1, lineno - opts["before"])
                    end = min(len(lines), lineno + opts["after"])
                    context_indexes.update(range(start, end + 1))
                elif not opts["files_with_matches"]:
                    print(f"{path}:{lineno}:{body}")
                break
            if count == line_count_before and opts["rewrite"] and opts["update_all"]:
                new_lines.append(line)
        if opts["rewrite"] and opts["update_all"]:
            path.write_text("".join(new_lines), encoding="utf-8")
        elif context_indexes and not opts["files_with_matches"]:
            if opts["heading"] == "always":
                print(path)
                for idx in sorted(context_indexes):
                    print(f"{idx}│{lines[idx - 1].rstrip(chr(10))}")
                print()
            else:
                for idx in sorted(context_indexes):
                    print(f"{path}:{idx}:{lines[idx - 1].rstrip(chr(10))}")
        elif opts["files_with_matches"]:
            path_count, _, _ = scan_lines(path, content, regex, var_names, opts["lang"], opts)
            if path_count:
                print(path)
    if opts["json"]:
        emit_json(records, opts["json"])
    elif opts["rewrite"] and opts["update_all"]:
        print(f"Applied {count} changes")
    return 0 if count else 1


def emit_json(records, style):
    if style == "stream":
        for record in records:
            print(json.dumps(record, separators=(",", ":")))
    elif style == "compact":
        print(json.dumps(records, separators=(",", ":")))
    else:
        print(json.dumps(records, indent=2))


def parse_simple_yaml(path):
    data = {}
    last_key = None
    for raw in Path(path).read_text(encoding="utf-8").splitlines():
        if not raw.strip() or raw.lstrip().startswith("#"):
            continue
        stripped = raw.strip()
        if ":" not in stripped:
            continue
        key, value = stripped.split(":", 1)
        value = value.strip().strip("'\"")
        if value:
            if last_key == "rule" and key == "pattern":
                data["pattern"] = value
            else:
                data[key] = value
        last_key = key
    return data


def scan_command(argv):
    rule_file = None
    paths = []
    report_style = "rich"
    i = 1
    while i < len(argv):
        arg = argv[i]
        if arg in ("-r", "--rule"):
            i += 1
            rule_file = argv[i]
        elif arg.startswith("--report-style="):
            report_style = arg.split("=", 1)[1]
        elif arg in ("--report-style", "-c", "--config"):
            i += 1
            if arg == "--report-style":
                report_style = argv[i]
        elif arg.startswith("-"):
            pass
        else:
            paths.append(arg)
        i += 1
    if not paths:
        paths = ["."]
    if not rule_file:
        return 0
    rule = parse_simple_yaml(rule_file)
    regex, var_names = pattern_to_regex(rule.get("pattern", ""))
    count = 0
    severity = rule.get("severity", "warning")
    message = rule.get("message", "This code matches a rule")
    rule_id = rule.get("id", "rule")
    for path in iter_files(paths):
        try:
            content = path.read_text(encoding="utf-8")
        except UnicodeDecodeError:
            continue
        for lineno, line in enumerate(content.splitlines(), 1):
            match = regex.search(line)
            if not match:
                continue
            count += 1
            col = match.start() + 1
            if report_style == "short":
                print(f"{path}:{lineno}:{col}: {severity}[{rule_id}]: {message}")
            else:
                print(f"{path}:{lineno}:{col}: {severity}[{rule_id}]: {message}")
    return 0 if count else 0


def main(argv):
    if argv in (["--version"], ["-V"]):
        print(VERSION)
        return 0
    if not argv or argv in (["--help"], ["-h"]) or (argv and argv[0] == "help"):
        print(TOP_HELP, end="")
        return 0
    if argv[0] == "run" and any(a in ("--help", "-h") for a in argv):
        print(RUN_HELP, end="")
        return 0
    if argv[0] == "scan" and any(a in ("--help", "-h") for a in argv):
        print(SCAN_HELP, end="")
        return 0
    if argv[0] in ("test", "new", "completions", "lsp") and any(a in ("--help", "-h") for a in argv):
        print(f"Usage: executable {argv[0]} [OPTIONS]")
        return 0
    if argv and argv[0] == "scan":
        return scan_command(argv)
    if argv and argv[0] == "completions":
        print("# completion script generation is not available in this reimplementation")
        return 0
    if argv and argv[0] == "new":
        return 0
    if argv and argv[0] == "test":
        print("No tests discovered")
        return 0
    if argv and argv[0] == "lsp":
        return 0
    if not argv or argv[0] == "run" or "-p" in argv or "--pattern" in argv:
        return run_search(argv)
    return 0


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
