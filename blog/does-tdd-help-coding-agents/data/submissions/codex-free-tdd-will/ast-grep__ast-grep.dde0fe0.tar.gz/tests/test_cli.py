import os
import json
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
BIN = os.environ.get("SG_BIN", str(ROOT / "sg.py"))


def run_cmd(args, cwd=None, input_text=None):
    return subprocess.run(
        [sys.executable, BIN, *args],
        cwd=cwd or ROOT,
        input=input_text,
        text=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
    )


class CliTests(unittest.TestCase):
    def test_version(self):
        result = run_cmd(["--version"])
        self.assertEqual(result.returncode, 0)
        self.assertEqual(result.stdout, "ast-grep 0.42.1\n")
        self.assertEqual(result.stderr, "")

    def test_run_finds_wildcard_pattern_in_file(self):
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "sample.js"
            path.write_text("const a = 1;\nlet b = foo(2);\nfoo(3);\n", encoding="utf-8")
            result = run_cmd(["run", "-p", "foo($A)", "-l", "js", str(path)])
        self.assertEqual(result.returncode, 0)
        self.assertEqual(
            result.stdout,
            f"{path}:2:let b = foo(2);\n{path}:3:foo(3);\n",
        )
        self.assertEqual(result.stderr, "")

    def test_run_outputs_compact_json_with_meta_variable(self):
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "sample.js"
            path.write_text("let b = foo(2);\n", encoding="utf-8")
            result = run_cmd(["run", "-p", "foo($A)", "-l", "js", "--json=compact", str(path)])
        self.assertEqual(result.returncode, 0)
        payload = json.loads(result.stdout)
        self.assertEqual(len(payload), 1)
        self.assertEqual(payload[0]["text"], "foo(2)")
        self.assertEqual(payload[0]["file"], str(path))
        self.assertEqual(payload[0]["range"]["start"], {"line": 0, "column": 8})
        self.assertEqual(payload[0]["metaVariables"]["single"]["A"]["text"], "2")

    def test_update_all_rewrites_matches_in_place(self):
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "sample.js"
            path.write_text("let b = foo(2);\nfoo(3);\n", encoding="utf-8")
            result = run_cmd(["run", "-p", "foo($A)", "-l", "js", "-r", "bar($A)", "-U", str(path)])
            updated = path.read_text(encoding="utf-8")
        self.assertEqual(result.returncode, 0)
        self.assertEqual(result.stdout, "Applied 2 changes\n")
        self.assertEqual(updated, "let b = bar(2);\nbar(3);\n")

    def test_run_reads_stdin(self):
        result = run_cmd(["run", "--stdin", "-p", "foo($A)", "-l", "js"], input_text="foo(9)\nnope\n")
        self.assertEqual(result.returncode, 0)
        self.assertEqual(result.stdout, "STDIN:1:foo(9)\n")

    def test_files_with_matches_prints_path_once(self):
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "sample.js"
            path.write_text("foo(1)\nfoo(2)\n", encoding="utf-8")
            result = run_cmd(["run", "-p", "foo($A)", "-l", "js", "--files-with-matches", str(path)])
        self.assertEqual(result.returncode, 0)
        self.assertEqual(result.stdout, f"{path}\n")

    def test_scan_rule_reports_short_diagnostics(self):
        with tempfile.TemporaryDirectory() as tmp:
            sample = Path(tmp) / "sample.js"
            rule = Path(tmp) / "rule.yml"
            sample.write_text("foo(1)\n", encoding="utf-8")
            rule.write_text(
                "id: no-foo\nlanguage: JavaScript\nmessage: found foo\nseverity: warning\nrule:\n  pattern: foo($A)\n",
                encoding="utf-8",
            )
            result = run_cmd(["scan", "-r", str(rule), "--report-style=short", str(sample)])
        self.assertEqual(result.returncode, 0)
        self.assertEqual(result.stdout, f"{sample}:1:1: warning[no-foo]: found foo\n")

    def test_help_mentions_commands(self):
        result = run_cmd(["--help"])
        self.assertEqual(result.returncode, 0)
        self.assertIn("Usage: executable [OPTIONS] <COMMAND>", result.stdout)
        self.assertIn("run", result.stdout)
        self.assertIn("scan", result.stdout)

    def test_context_includes_neighboring_lines_once(self):
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "sample.js"
            path.write_text("before\nfoo(1)\nafter\n", encoding="utf-8")
            result = run_cmd(["run", "-p", "foo($A)", "-l", "js", "-C", "1", str(path)])
        self.assertEqual(result.returncode, 0)
        self.assertEqual(result.stdout, f"{path}:1:before\n{path}:2:foo(1)\n{path}:3:after\n")


if __name__ == "__main__":
    unittest.main()
