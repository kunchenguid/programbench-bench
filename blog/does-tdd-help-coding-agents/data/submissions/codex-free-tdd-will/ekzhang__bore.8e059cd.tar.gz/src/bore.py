#!/usr/bin/env python3
import os, sys, socket, threading, struct, json, time, selectors, argparse, errno, signal

VERSION = "bore-cli 0.6.0"
DESC = "A modern, simple TCP tunnel in Rust that exposes local ports to a remote server, bypassing standard NAT connection firewalls."
CONTROL_PORT = 7835

TOP_HELP = f"""{DESC}

Usage: executable <COMMAND>

Commands:
  local   Starts a local proxy to the remote server
  server  Runs the remote proxy server
  help    Print this message or the help of the given subcommand(s)

Options:
  -h, --help     Print help
  -V, --version  Print version
"""
LOCAL_HELP = """Starts a local proxy to the remote server

Usage: executable local [OPTIONS] --to <TO> <LOCAL_PORT>

Arguments:
  <LOCAL_PORT>  The local port to expose [env: BORE_LOCAL_PORT=]

Options:
  -l, --local-host <HOST>  The local host to expose [default: localhost]
  -t, --to <TO>            Address of the remote server to expose local ports to [env: BORE_SERVER=]
  -p, --port <PORT>        Optional port on the remote server to select [default: 0]
  -s, --secret <SECRET>    Optional secret for authentication [env: BORE_SECRET]
  -h, --help               Print help
"""
SERVER_HELP = """Runs the remote proxy server

Usage: executable server [OPTIONS]

Options:
      --min-port <MIN_PORT>          Minimum accepted TCP port number [env: BORE_MIN_PORT=] [default: 1024]
      --max-port <MAX_PORT>          Maximum accepted TCP port number [env: BORE_MAX_PORT=] [default: 65535]
  -s, --secret <SECRET>              Optional secret for authentication [env: BORE_SECRET]
      --bind-addr <BIND_ADDR>        IP address to bind to, clients must reach this [default: 0.0.0.0]
      --bind-tunnels <BIND_TUNNELS>  IP address where tunnels will listen on, defaults to --bind-addr
  -h, --help                         Print help
"""

def eprint(s=""):
    print(s)

def err(msg, usage=None, tip=None):
    print(f"error: {msg}\n")
    if tip:
        print(f"  tip: {tip}\n")
    if usage:
        print(usage)
        print()
    print("For more information, try '--help'.")
    return 2

def parse_u16(value, name):
    try:
        n = int(value)
    except ValueError:
        raise ValueError(f"invalid value '{value}' for '{name}': invalid digit found in string")
    if n < 0 or n > 65535:
        raise ValueError(f"invalid value '{value}' for '{name}': number too large to fit in target type")
    return n

def parse_ip(value, opt):
    try:
        socket.inet_pton(socket.AF_INET, value)
        return value
    except OSError:
        try:
            socket.inet_pton(socket.AF_INET6, value)
            return value
        except OSError:
            raise ValueError(f"invalid value '{value}' for '{opt}': invalid IP address syntax")

def recv_exact(sock, n):
    b = bytearray()
    while len(b) < n:
        chunk = sock.recv(n-len(b))
        if not chunk:
            raise EOFError
        b.extend(chunk)
    return bytes(b)

def send_frame(sock, lock, cid, typ, payload=b""):
    hdr = struct.pack("!IBI", cid, typ, len(payload))
    with lock:
        sock.sendall(hdr + payload)

def recv_frame(sock):
    hdr = recv_exact(sock, 9)
    cid, typ, ln = struct.unpack("!IBI", hdr)
    return cid, typ, recv_exact(sock, ln) if ln else b""

def pipe_reader(src, on_data, on_close):
    try:
        while True:
            data = src.recv(65536)
            if not data:
                break
            on_data(data)
    except OSError:
        pass
    finally:
        on_close()

def log_client(msg):
    print(f"INFO bore_cli::client: {msg}", flush=True)

def log_server(msg):
    print(f"INFO bore_cli::server: {msg}", flush=True)

def run_server(argv):
    min_port = int(os.environ.get("BORE_MIN_PORT", "1024") or "1024")
    max_port = int(os.environ.get("BORE_MAX_PORT", "65535") or "65535")
    secret = os.environ.get("BORE_SECRET")
    bind_addr = "0.0.0.0"
    bind_tunnels = None
    i=0
    while i < len(argv):
        a=argv[i]
        if a in ("-h","--help"):
            print(SERVER_HELP, end=""); return 0
        if a == "--min-port":
            if i+1>=len(argv): return err("a value is required for '--min-port <MIN_PORT>' but none was supplied")
            try: min_port=parse_u16(argv[i+1], "--min-port <MIN_PORT>")
            except ValueError as ex: return err(str(ex))
            i+=2; continue
        if a == "--max-port":
            if i+1>=len(argv): return err("a value is required for '--max-port <MAX_PORT>' but none was supplied")
            try: max_port=parse_u16(argv[i+1], "--max-port <MAX_PORT>")
            except ValueError as ex: return err(str(ex))
            i+=2; continue
        if a in ("-s","--secret"):
            if i+1>=len(argv): return err("a value is required for '--secret <SECRET>' but none was supplied")
            secret=argv[i+1]; i+=2; continue
        if a == "--bind-addr":
            if i+1>=len(argv): return err("a value is required for '--bind-addr <BIND_ADDR>' but none was supplied")
            try: bind_addr=parse_ip(argv[i+1], "--bind-addr <BIND_ADDR>")
            except ValueError as ex: return err(str(ex))
            i+=2; continue
        if a == "--bind-tunnels":
            if i+1>=len(argv): return err("a value is required for '--bind-tunnels <BIND_TUNNELS>' but none was supplied")
            try: bind_tunnels=parse_ip(argv[i+1], "--bind-tunnels <BIND_TUNNELS>")
            except ValueError as ex: return err(str(ex))
            i+=2; continue
        return err(f"unexpected argument '{a}' found", "Usage: executable server [OPTIONS]")
    if min_port > max_port:
        return err("port range is empty", "Usage: bore-cli <COMMAND>")
    bind_tunnels = bind_tunnels or bind_addr
    srv=socket.socket(socket.AF_INET, socket.SOCK_STREAM); srv.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    srv.bind((bind_addr, CONTROL_PORT)); srv.listen(64)
    log_server(f"server listening addr={bind_addr}")
    while True:
        control, addr = srv.accept()
        threading.Thread(target=handle_control, args=(control, addr, secret, min_port, max_port, bind_tunnels), daemon=True).start()

def handle_control(control, addr, secret, min_port, max_port, bind_tunnels):
    lock=threading.Lock(); conns={}
    try:
        f=control.makefile("rb")
        line=f.readline()
        if not line: return
        req=json.loads(line.decode())
        if secret is not None and req.get("secret") != secret:
            control.sendall(b"ERR authentication failed\n"); return
        requested=int(req.get("port",0))
        if requested and not (min_port <= requested <= max_port):
            control.sendall(b"ERR requested port out of range\n"); return
        ls=socket.socket(socket.AF_INET, socket.SOCK_STREAM); ls.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        if requested:
            ls.bind((bind_tunnels, requested))
        else:
            last_error = None
            for candidate in range(min_port, max_port + 1):
                try:
                    ls.bind((bind_tunnels, candidate))
                    break
                except OSError as ex:
                    last_error = ex
            else:
                raise last_error or OSError("no port")
        port=ls.getsockname()[1]
        if not (min_port <= port <= max_port):
            ls.close(); control.sendall(b"ERR requested port out of range\n"); return
        ls.listen(64)
        control.sendall((json.dumps({"ok": True, "host": bind_tunnels, "port": port})+"\n").encode())
        log_server(f"new client host={bind_tunnels} port={port}")
        next_id=1
        def accept_loop():
            nonlocal next_id
            while True:
                try: client, _ = ls.accept()
                except OSError: break
                cid=next_id; next_id+=1; conns[cid]=client
                send_frame(control, lock, cid, 1)
                threading.Thread(target=pipe_reader, args=(client, lambda d,cid=cid: send_frame(control, lock, cid, 2, d), lambda cid=cid: close_server_conn(cid, conns, control, lock)), daemon=True).start()
        threading.Thread(target=accept_loop, daemon=True).start()
        while True:
            cid, typ, payload = recv_frame(control)
            s=conns.get(cid)
            if typ==2 and s:
                try: s.sendall(payload)
                except OSError: pass
            elif typ==3:
                if s:
                    try: s.shutdown(socket.SHUT_RDWR)
                    except OSError: pass
                    s.close(); conns.pop(cid, None)
    except Exception:
        pass
    finally:
        try: control.close()
        except OSError: pass
        for s in list(conns.values()):
            try: s.close()
            except OSError: pass

def close_server_conn(cid, conns, control, lock):
    s=conns.pop(cid, None)
    if s:
        try: s.close()
        except OSError: pass
    try: send_frame(control, lock, cid, 3)
    except OSError: pass

def run_local(argv):
    local_host="localhost"; to=os.environ.get("BORE_SERVER"); port=0; secret=os.environ.get("BORE_SECRET"); local_port_env=os.environ.get("BORE_LOCAL_PORT"); positional=[]
    i=0
    while i < len(argv):
        a=argv[i]
        if a in ("-h","--help"):
            print(LOCAL_HELP, end=""); return 0
        if a in ("-l","--local-host"):
            if i+1>=len(argv): return err("a value is required for '--local-host <HOST>' but none was supplied")
            local_host=argv[i+1]; i+=2; continue
        if a in ("-t","--to"):
            if i+1>=len(argv): return err("a value is required for '--to <TO>' but none was supplied")
            to=argv[i+1]; i+=2; continue
        if a in ("-p","--port"):
            if i+1>=len(argv): return err("a value is required for '--port <PORT>' but none was supplied")
            try: port=parse_u16(argv[i+1], "--port <PORT>")
            except ValueError as ex: return err(str(ex))
            i+=2; continue
        if a in ("-s","--secret"):
            if i+1>=len(argv): return err("a value is required for '--secret <SECRET>' but none was supplied")
            secret=argv[i+1]; i+=2; continue
        if a.startswith("-"):
            return err(f"unexpected argument '{a}' found", "Usage: executable local [OPTIONS] --to <TO> <LOCAL_PORT>", f"to pass '{a}' as a value, use '-- {a}'")
        positional.append(a); i+=1
    missing=[]
    if not to: missing.append("  --to <TO>")
    if not positional and not local_port_env: missing.append("  <LOCAL_PORT>")
    if missing:
        msg="the following required arguments were not provided:\n" + "\n".join(missing)
        return err(msg, "Usage: executable local --to <TO> <LOCAL_PORT>")
    lp_s = positional[0] if positional else local_port_env
    try: local_port=parse_u16(lp_s, "<LOCAL_PORT>")
    except ValueError as ex: return err(str(ex))
    return local_loop(local_host, local_port, to, port, secret)

def local_loop(local_host, local_port, to, port, secret):
    conns={}; lock=threading.Lock()
    try:
        sock=socket.create_connection((to, CONTROL_PORT), timeout=5)
    except OSError as ex:
        print(f"Error: could not connect to {to}:{CONTROL_PORT}\n\nCaused by:\n    {ex}")
        return 1
    req={"local_host":local_host,"local_port":local_port,"port":port,"secret":secret}
    sock.sendall((json.dumps(req)+"\n").encode())
    f=sock.makefile("rb")
    line=f.readline()
    if not line:
        print("Error: server closed connection"); return 1
    if line.startswith(b"ERR"):
        print("Error: " + line.decode().strip()[4:]); return 1
    resp=json.loads(line.decode()); remote_port=resp["port"]
    log_client(f"connected to server remote_port={remote_port}")
    log_client(f"listening at 127.0.0.1:{remote_port}")
    while True:
        try: cid, typ, payload = recv_frame(sock)
        except Exception: return 1
        if typ==1:
            try:
                backend=socket.create_connection((local_host, local_port), timeout=5)
                conns[cid]=backend
                threading.Thread(target=pipe_reader, args=(backend, lambda d,cid=cid: send_frame(sock, lock, cid, 2, d), lambda cid=cid: close_local_conn(cid, conns, sock, lock)), daemon=True).start()
            except OSError:
                send_frame(sock, lock, cid, 3)
        elif typ==2:
            s=conns.get(cid)
            if s:
                try: s.sendall(payload)
                except OSError: pass
        elif typ==3:
            s=conns.pop(cid, None)
            if s:
                try: s.shutdown(socket.SHUT_RDWR)
                except OSError: pass
                s.close()

def close_local_conn(cid, conns, sock, lock):
    s=conns.pop(cid, None)
    if s:
        try: s.close()
        except OSError: pass
    try: send_frame(sock, lock, cid, 3)
    except OSError: pass

def main(argv=None):
    argv=list(sys.argv[1:] if argv is None else argv)
    if not argv or argv in (["--help"],["-h"]):
        print(TOP_HELP, end=""); return 0 if argv else 2
    if argv in (["--version"],["-V"]):
        print(VERSION); return 0
    if argv[0] == "help":
        if len(argv)>1 and argv[1]=="local": print(LOCAL_HELP, end=""); return 0
        if len(argv)>1 and argv[1]=="server": print(SERVER_HELP, end=""); return 0
        print(TOP_HELP, end=""); return 0
    if argv[0] == "local": return run_local(argv[1:])
    if argv[0] == "server": return run_server(argv[1:])
    return err(f"unrecognized subcommand '{argv[0]}'", "Usage: executable <COMMAND>")

if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except KeyboardInterrupt:
        raise SystemExit(130)
