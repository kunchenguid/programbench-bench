#!/bin/bash
set -e
cp git_trim.py executable
chmod +x executable
