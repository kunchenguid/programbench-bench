import os
import subprocess
import tempfile
import unittest


ROOT = os.path.dirname(os.path.dirname(__file__))
BIN = os.path.join(ROOT, "executable")


def run_cmd(args, cwd=None):
    return subprocess.run(
        [BIN] + args,
        cwd=cwd,
        text=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
    )


def git(cwd, *args):
    subprocess.run(["git"] + list(args), cwd=cwd, check=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)


def init_repo():
    tmp = tempfile.TemporaryDirectory()
    git(tmp.name, "init")
    git(tmp.name, "config", "user.email", "a@b.c")
    git(tmp.name, "config", "user.name", "Agent")
    with open(os.path.join(tmp.name, "f"), "w", encoding="utf-8") as f:
        f.write("base\n")
    git(tmp.name, "add", "f")
    git(tmp.name, "commit", "-m", "init")
    return tmp


def init_remote_work():
    tmp = tempfile.TemporaryDirectory()
    bare = os.path.join(tmp.name, "origin.git")
    work = os.path.join(tmp.name, "work")
    git(tmp.name, "init", "--bare", bare)
    subprocess.run(["git", "clone", bare, work], check=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
    git(work, "config", "user.email", "a@b.c")
    git(work, "config", "user.name", "Agent")
    with open(os.path.join(work, "f"), "w", encoding="utf-8") as f:
        f.write("base\n")
    git(work, "add", "f")
    git(work, "commit", "-m", "init")
    git(work, "push", "-u", "origin", "master")
    git(work, "remote", "set-head", "origin", "-a")
    return tmp, work


class GitTrimBehaviorTests(unittest.TestCase):
    def test_version_matches_documented_program_name(self):
        result = run_cmd(["--version"])

        self.assertEqual(result.returncode, 0)
        self.assertEqual(result.stdout, "git-trim 0.4.4\n")
        self.assertEqual(result.stderr, "")

    def test_repository_without_remote_is_rejected(self):
        with init_repo() as repo:
            result = run_cmd(["--dry-run", "--no-update"], cwd=repo)

        self.assertEqual(result.returncode, 1)
        self.assertEqual(result.stdout, "")
        self.assertEqual(result.stderr, "Error: git-trim requires at least one remote\n")

    def test_dry_run_reports_merged_tracking_local_and_remote_ref(self):
        tmp, work = init_remote_work()
        with tmp:
            git(work, "checkout", "-b", "merged")
            with open(os.path.join(work, "f"), "a", encoding="utf-8") as f:
                f.write("merged\n")
            git(work, "commit", "-am", "merged")
            git(work, "push", "-u", "origin", "merged")
            git(work, "checkout", "master")
            git(work, "merge", "--no-ff", "merged", "-m", "merge")
            git(work, "push")

            result = run_cmd(["--dry-run", "--no-update"], cwd=work)

        self.assertEqual(result.returncode, 0)
        self.assertIn("Branches that will remain:\n", result.stdout)
        self.assertIn("    master [base]\n", result.stdout)
        self.assertIn("    origin/master [base]\n", result.stdout)
        self.assertIn("Delete merged local branches:\n  - merged\n", result.stdout)
        self.assertIn("Delete merged remote refs:\n  - origin, refs/heads/merged\n", result.stdout)
        self.assertIn("Delete branch merged (dry run).\n", result.stdout)

    def test_stray_tracking_branch_is_deleted_when_requested(self):
        tmp, work = init_remote_work()
        with tmp:
            git(work, "checkout", "-b", "stray")
            with open(os.path.join(work, "stray.txt"), "w", encoding="utf-8") as f:
                f.write("stray\n")
            git(work, "add", "stray.txt")
            git(work, "commit", "-m", "stray")
            git(work, "push", "-u", "origin", "stray")
            git(work, "checkout", "master")
            git(work, "push", "origin", ":stray")

            result = run_cmd(["--dry-run", "--no-update", "--delete", "stray"], cwd=work)

        self.assertEqual(result.returncode, 0)
        self.assertIn("Delete stray local branches:\n  - stray\n", result.stdout)
        self.assertIn("Delete branch stray (dry run).\n", result.stdout)

    def test_local_range_deletes_merged_non_tracking_branch(self):
        tmp, work = init_remote_work()
        with tmp:
            git(work, "checkout", "-b", "old")
            with open(os.path.join(work, "f"), "a", encoding="utf-8") as f:
                f.write("old\n")
            git(work, "commit", "-am", "old")
            git(work, "checkout", "master")
            git(work, "merge", "--no-ff", "old", "-m", "merge")
            git(work, "push")

            result = run_cmd(["--dry-run", "--no-update", "--bases", "master", "--delete", "local"], cwd=work)

        self.assertEqual(result.returncode, 0)
        self.assertIn("Delete merged local branches:\n  - old (non-tracking)\n", result.stdout)
        self.assertIn("Delete branch old (dry run).\n", result.stdout)

    def test_protected_pattern_keeps_matching_local_branch(self):
        tmp, work = init_remote_work()
        with tmp:
            git(work, "checkout", "-b", "release-1")
            with open(os.path.join(work, "f"), "a", encoding="utf-8") as f:
                f.write("release\n")
            git(work, "commit", "-am", "release")
            git(work, "push", "-u", "origin", "release-1")
            git(work, "checkout", "master")
            git(work, "merge", "--no-ff", "release-1", "-m", "merge")
            git(work, "push")

            result = run_cmd(["--dry-run", "--no-update", "--protected", "release-*"], cwd=work)

        self.assertEqual(result.returncode, 0)
        self.assertIn("    release-1 [merged, but: protected by a pattern `release-*`]\n", result.stdout)
        self.assertNotIn("Delete branch release-1", result.stdout)
        self.assertIn("Delete merged remote refs:\n  - origin, refs/heads/release-1\n", result.stdout)


if __name__ == "__main__":
    unittest.main()
