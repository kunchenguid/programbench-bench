#!/usr/bin/env python3
import fnmatch
import subprocess
import sys


VERSION = "git-trim 0.4.4"
HELP_SHORT = """Automatically trims your tracking branches whose upstream branches are merged or stray.

Usage: executable [OPTIONS]

Options:
  -b, --bases <BASES>
          Comma separated multiple names of branches. All the other branches are compared with the upstream branches of those branches. [default: branches that tracks `git symbolic-ref refs/remotes/*/HEAD`] [config: trim.bases]
  -p, --protected <PROTECTED>
          Comma separated multiple glob patterns (e.g. `release-*`, `feature/*`) of branches that should never be deleted. [config: trim.protected]
      --no-update
          Do not update remotes [config: trim.update]
      --update-interval <UPDATE_INTERVAL>
          Prevents too frequent updates. Seconds between updates in seconds. 0 to disable. [default: 5] [config: trim.updateInterval]
      --no-confirm
          Do not ask confirm [config: trim.confirm]
      --no-detach
          Do not detach when HEAD is about to be deleted [config: trim.detach]
  -d, --delete <DELETE>
          Comma separated values of `<delete range>[:<remote name>]`. Delete range is one of the `merged, merged-local, merged-remote, stray, diverged, local, remote`. `:<remote name>` is only necessary to a `<delete range>` when the range is applied to remote branches. You can use `*` as `<remote name>` to delete a range of branches from all remotes. [default : `merged:origin`] [config: trim.delete]
      --dry-run
          Do not delete branches, show what branches will be deleted
  -h, --help
          Print help (see more with '--help')
  -V, --version
          Print version"""


def git(args, check=True):
    result = subprocess.run(
        ["git"] + args,
        text=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
    )
    if check and result.returncode != 0:
        raise RuntimeError(result.stderr.strip())
    return result


def parse_args(argv):
    opts = {
        "dry_run": False,
        "no_update": False,
        "bases": None,
        "delete": "merged:origin",
        "protected": [],
        "no_confirm": config_bool("trim.confirm", True) is False,
    }
    cfg = config_value("trim.bases")
    if cfg:
        opts["bases"] = cfg.split(",")
    cfg = config_value("trim.delete")
    if cfg:
        opts["delete"] = cfg
    cfg = config_value("trim.protected")
    if cfg:
        opts["protected"] = cfg.split(",")
    if config_bool("trim.update", True) is False:
        opts["no_update"] = True
    i = 0
    while i < len(argv):
        arg = argv[i]
        if arg == "--dry-run":
            opts["dry_run"] = True
        elif arg == "--no-update":
            opts["no_update"] = True
        elif arg == "--no-confirm":
            opts["no_confirm"] = True
        elif arg == "--update-interval":
            i += 1
        elif arg.startswith("--update-interval="):
            pass
        elif arg == "--no-detach":
            pass
        elif arg in ("-b", "--bases"):
            i += 1
            opts["bases"] = argv[i].split(",") if i < len(argv) else []
        elif arg.startswith("--bases="):
            opts["bases"] = arg.split("=", 1)[1].split(",")
        elif arg in ("-d", "--delete"):
            i += 1
            opts["delete"] = argv[i] if i < len(argv) else ""
        elif arg.startswith("--delete="):
            opts["delete"] = arg.split("=", 1)[1]
        elif arg in ("-p", "--protected"):
            i += 1
            opts["protected"] = argv[i].split(",") if i < len(argv) else []
        elif arg.startswith("--protected="):
            opts["protected"] = arg.split("=", 1)[1].split(",")
        elif arg.startswith("-"):
            print(f"error: unexpected argument '{arg}' found\n\nUsage: executable [OPTIONS]\n\nFor more information, try '--help'.", file=sys.stderr)
            raise SystemExit(2)
        i += 1
    return opts


def config_value(name):
    result = subprocess.run(["git", "config", "--get", name], text=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    return result.stdout.strip() if result.returncode == 0 else None


def config_bool(name, default):
    value = config_value(name)
    if value is None:
        return default
    return value.lower() in ("1", "true", "yes", "on")


def split_nul_lines(text):
    out = []
    for line in text.splitlines():
        out.append(line.split("\0"))
    return out


def local_branches():
    fmt = "%(refname:short)%00%(objectname)%00%(upstream:short)"
    branches = []
    for name, oid, upstream in split_nul_lines(git(["for-each-ref", "refs/heads", f"--format={fmt}"]).stdout):
        branches.append({"name": name, "oid": oid, "upstream": upstream})
    return branches


def remote_refs():
    fmt = "%(refname:short)%00%(objectname)"
    refs = []
    for name, oid in split_nul_lines(git(["for-each-ref", "refs/remotes", f"--format={fmt}"]).stdout):
        if name.endswith("/HEAD"):
            continue
        refs.append({"name": name, "oid": oid})
    return refs


def default_bases(locals_):
    refs = git(["for-each-ref", "refs/remotes", "--format=%(refname:short)%00%(symref:short)"]).stdout
    heads = []
    for name, symref in split_nul_lines(refs):
        if name.endswith("/HEAD") and symref:
            heads.append(symref)
    bases = []
    for up in heads:
        tracked = next((b["name"] for b in locals_ if b["upstream"] == up), None)
        if tracked:
            bases.append(tracked)
    return bases


def is_ancestor(a, b):
    return git(["merge-base", "--is-ancestor", a, b], check=False).returncode == 0


def delete_ranges(spec):
    ranges = set()
    remotes = {}
    for part in [p for p in spec.split(",") if p]:
        if ":" in part:
            name, remote = part.split(":", 1)
        else:
            name, remote = part, None
        if name == "merged":
            ranges.add("merged-local")
            ranges.add("merged-remote")
            remotes.setdefault("merged-remote", set()).add(remote or "origin")
        else:
            ranges.add(name)
            if remote:
                remotes.setdefault(name, set()).add(remote)
    return ranges, remotes


def remote_matches(remote, allowed):
    return "*" in allowed or remote in allowed


def main(argv):
    if argv == ["--help"] or argv == ["-h"]:
        print(HELP_SHORT)
        return 0
    if argv == ["--version"] or argv == ["-V"]:
        print(VERSION)
        return 0
    opts = parse_args(argv)
    repo = git(["rev-parse", "--git-dir"], check=False)
    if repo.returncode != 0:
        print("Error: could not find repository at '.'; class=Repository (6); code=NotFound (-3)", file=sys.stderr)
        return 1
    remotes = [line for line in git(["remote"]).stdout.splitlines() if line]
    if not remotes:
        print("Error: git-trim requires at least one remote", file=sys.stderr)
        return 1
    locals_ = local_branches()
    remotes_refs = remote_refs()
    bases = opts["bases"] or default_bases(locals_)
    base_oids = {b["oid"] for b in locals_ if b["name"] in bases}
    base_upstreams = {b["upstream"] for b in locals_ if b["name"] in bases and b["upstream"]}
    ranges, remote_allowed = delete_ranges(opts["delete"])

    remain_local = []
    delete_local = []
    delete_stray = []
    remote_ref_names = {r["name"] for r in remotes_refs}
    for branch in locals_:
        if branch["name"] in bases:
            remain_local.append((branch["name"], "[base]"))
            continue
        merged = any(is_ancestor(branch["oid"], base_oid) for base_oid in base_oids)
        stray = bool(branch["upstream"]) and branch["upstream"] not in remote_ref_names
        protected_by = next((p for p in opts["protected"] if p and fnmatch.fnmatchcase(branch["name"], p)), None)
        if protected_by:
            if merged:
                reason = f"[merged, but: protected by a pattern `{protected_by}`]"
            elif stray:
                reason = f"[stray, but: protected by a pattern `{protected_by}`]"
            else:
                reason = f"[protected by a pattern `{protected_by}`]"
            remain_local.append((branch["name"], reason))
        elif merged and branch["upstream"] and "merged-local" in ranges:
            delete_local.append((branch["name"], ""))
        elif merged and not branch["upstream"] and "local" in ranges:
            delete_local.append((branch["name"], " (non-tracking)"))
        elif stray and "stray" in ranges:
            delete_stray.append(branch["name"])
        else:
            if stray:
                reason = "[stray, but: delete range `stray` was not given]"
            elif merged:
                reason = "[merged, but: delete range `merged-local` was not given]"
            else:
                reason = ""
            remain_local.append((branch["name"], reason))

    remain_remote = []
    delete_remote = []
    allowed_merged_remotes = remote_allowed.get("merged-remote", set())
    for ref in remotes_refs:
        remote, branch_name = ref["name"].split("/", 1)
        full = f"refs/heads/{branch_name}"
        if ref["name"] in base_upstreams:
            remain_remote.append((ref["name"], "[base]"))
            continue
        merged = any(is_ancestor(ref["oid"], base_oid) for base_oid in base_oids)
        if merged and "merged-remote" in ranges and remote_matches(remote, allowed_merged_remotes):
            delete_remote.append((remote, full))
        else:
            remain_remote.append((ref["name"], ""))

    print("Branches that will remain:")
    print("  local branches:")
    for name, reason in remain_local:
        print(f"    {name} {reason}".rstrip())
    print("  remote references:")
    for name, reason in remain_remote:
        print(f"    {name} {reason}".rstrip())
    if delete_local:
        print()
        print("Delete merged local branches:")
        for name, extra in delete_local:
            print(f"  - {name}{extra}")
    if delete_stray:
        print()
        print("Delete stray local branches:")
        for name in delete_stray:
            print(f"  - {name}")
    if delete_remote:
        print("Delete merged remote refs:")
        for remote, ref in delete_remote:
            print(f"  - {remote}, {ref}")
    if (delete_local or delete_stray or delete_remote) and not opts["dry_run"] and not opts["no_confirm"]:
        print("Error: IO error: not a terminal\n\nCaused by:\n    not a terminal", file=sys.stderr)
        return 1
    for remote, ref in delete_remote:
        branch_name = ref.removeprefix("refs/heads/")
        args = ["push"]
        if opts["dry_run"]:
            args.append("--dry-run")
        args += [remote, f":{branch_name}"]
        subprocess.run(["git"] + args)
    for name in [name for name, _extra in delete_local] + delete_stray:
        if opts["dry_run"]:
            print(f"Delete branch {name} (dry run).")
        else:
            git(["branch", "-d", name], check=False)
    return 0


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
