#!/usr/bin/env python3
import json
import os
import re
import sys
from pathlib import Path


HELP = """Batch rename utility for developers

Usage: executable [OPTIONS] [[SOURCE] OUTPUT]...

Arguments:
  [[SOURCE] OUTPUT]...
          OUTPUT is the pattern to be used for renaming files, and SOURCE is the optional regex pattern to match by filenames. SOURCE has the same function as -r option

Options:
  -d, --dir <PATH>
          Sets the working directory

      --depth <DEPTH>
          Optional value to overwrite inferred subdirectory depth value in 'regex' mode

  -E, --no-extension
          Does not preserve the extension of input files in 'sort' and 'regex' options

  -g, --generate <PATH>
          Stores a JSON map file in '<PATH>' after renaming files

  -h, --help
          Print help (see a summary with '-h')

  -k, --mkdir
          Recursively creates all parent directories of '<OUTPUT>' if they are missing

  -m, --map <PATH>
          Sets the path of map file to be used for renaming files
          
          [aliases: --from-file]

      --max-depth <DEPTH>
          Optional value to set the maximum of subdirectory depth value in 'regex' mode

  -q, --quiet
          Does not print the map table to stdout

  -r, --regex <PATTERN>
          Regex pattern to match by filenames

  -s, --sort <ORDER>
          Sets the order of natural sorting (by name) to rename files using enumerator

          Possible values:
          - asc:  Sort in ascending order
          - desc: Sort in descending order

  -t, --test
          Runs in test mode without renaming actual files
          
          [aliases: --dry-run]

  -V, --version
          Print version

  -w, --overwrite
          Overwrites output files, otherwise, a '_' is prepended to filename

OUTPUT pattern accepts placeholders that have the format of '{G:P}' where 'G' is the captured group and 'P' is the padding of digits with `0`. Please refer to https://github.com/yaa110/nomino for more information.
"""


def main(argv):
    opts, positional, err = parse_args(argv)
    if err:
        print(f"error: {err}", file=sys.stderr)
        return 1
    if opts["version"]:
        print("nomino 1.6.4")
        return 0
    if opts["help"]:
        print(HELP, end="")
        return 0
    if (opts["sort"] or opts["map"] or opts["regex"]) and len(positional) > 1:
        print("error: optional SOURCE must be used without setting regex, map or sort flags", file=sys.stderr)
        return 1
    if opts["map"]:
        os.chdir(opts["dir"])
        with open(opts["map"], encoding="utf-8") as f:
            data = json.load(f)
        mappings = [(str(k), str(v)) for k, v in data.items()]
        if not opts["quiet"]:
            print_table(mappings)
        if not opts["test"]:
            apply_renames(mappings, opts)
        write_generated_map(mappings, opts)
        return 0
    if opts["sort"]:
        if not positional:
            print("error: OUTPUT argument is required", file=sys.stderr)
            return 1
        os.chdir(opts["dir"])
        entries = sorted([p.name for p in Path(".").iterdir() if p.is_file()], key=natural_key)
        if opts["sort"] == "desc":
            entries.reverse()
        mappings = []
        for i, name in enumerate(entries, 1):
            out = render_pattern(positional[-1], [name], i)
            if not opts["no_extension"]:
                out += Path(name).suffix
            mappings.append((name, avoid_collision(out, [m[1] for m in mappings], opts["overwrite"])))
        if not opts["quiet"]:
            print_table(mappings)
        if not opts["test"]:
            apply_renames(mappings, opts)
        write_generated_map(mappings, opts)
        return 0
    if opts["regex"] or len(positional) == 2:
        if len(positional) == 2 and not opts["regex"]:
            opts["regex"] = positional[0]
            output = positional[1]
        elif positional:
            output = positional[-1]
        else:
            print("error: OUTPUT argument is required", file=sys.stderr)
            return 1
        os.chdir(opts["dir"])
        mappings = regex_mappings(opts["regex"], output, opts)
        if not opts["quiet"]:
            print_table(mappings)
        if not opts["test"]:
            apply_renames(mappings, opts)
        write_generated_map(mappings, opts)
        return 0
    print("error: one of 'regex', 'sort', 'map' or 'SOURCE' options must be set.", file=sys.stderr)
    print("usage: run './executable --help' for more information.", file=sys.stderr)
    return 1


def parse_args(argv):
    opts = {
        "dir": ".",
        "help": False,
        "generate": None,
        "map": None,
        "mkdir": False,
        "no_extension": False,
        "overwrite": False,
        "quiet": False,
        "regex": None,
        "sort": None,
        "test": False,
        "version": False,
        "depth": None,
        "max_depth": None,
    }
    positional = []
    i = 0
    while i < len(argv):
        a = argv[i]
        if a in ("-h", "--help"):
            opts["help"] = True
        elif a in ("-V", "--version"):
            opts["version"] = True
        elif a in ("-t", "--test", "--dry-run"):
            opts["test"] = True
        elif a in ("-q", "--quiet"):
            opts["quiet"] = True
        elif a in ("-E", "--no-extension"):
            opts["no_extension"] = True
        elif a in ("-w", "--overwrite"):
            opts["overwrite"] = True
        elif a in ("-k", "--mkdir"):
            opts["mkdir"] = True
        elif a in ("-d", "--dir", "-s", "--sort", "-r", "--regex", "-g", "--generate", "-m", "--map", "--from-file", "--depth", "--max-depth"):
            if i + 1 >= len(argv):
                return opts, positional, f"a value is required for '{a}'"
            val = argv[i + 1]
            if a in ("-d", "--dir"):
                opts["dir"] = val
            elif a in ("-s", "--sort"):
                opts["sort"] = val
            elif a in ("-r", "--regex"):
                opts["regex"] = val
            elif a in ("-g", "--generate"):
                opts["generate"] = val
            elif a in ("-m", "--map", "--from-file"):
                opts["map"] = val
            elif a == "--depth":
                opts["depth"] = int(val)
            else:
                opts["max_depth"] = int(val)
            i += 1
        elif a.startswith("-"):
            return opts, positional, f"unexpected argument '{a}'"
        else:
            positional.append(a)
        i += 1
    return opts, positional, None


def natural_key(text):
    parts = re.split(r"(\d+)", text)
    return [int(p) if p.isdigit() else p.lower() for p in parts]


def regex_mappings(pattern, output, opts):
    compiled = re.compile(pattern)
    depth = opts["depth"]
    if depth is None:
        depth = max(1, output.count("/") + 1)
    max_depth = opts["max_depth"]
    rows = []
    files = [p for p in Path(".").rglob("*") if p.is_file()]
    files.sort(key=lambda p: (len(p.parts), natural_key(p.as_posix())))
    for p in files:
        rel = p.as_posix()
        d = len(Path(rel).parts)
        if opts["depth"] is not None:
            if d != depth:
                continue
        elif max_depth is not None:
            if d > max_depth:
                continue
        else:
            if d != depth:
                continue
        m = compiled.search(rel)
        if not m:
            continue
        groups = [m.group(0), *list(m.groups())]
        named = m.groupdict()
        out = render_pattern(output, groups, len(rows) + 1, named)
        if not opts["no_extension"]:
            out += p.suffix
        rows.append((rel, avoid_collision(out, [r[1] for r in rows], opts["overwrite"])))
    return rows


def render_pattern(pattern, groups, auto_index, named=None):
    named = named or {}
    def repl(match):
        body = match.group(1)
        if ":" in body:
            key, pad = body.split(":", 1)
        else:
            key, pad = body, ""
        if key == "":
            val = str(auto_index)
        elif key.isdigit():
            idx = int(key)
            val = groups[idx] if idx < len(groups) else ""
        else:
            val = named.get(key, "")
        if pad.isdigit() and re.fullmatch(r"[1-9]\d*", val):
            val = val.zfill(int(pad))
        return val

    return re.sub(r"\{([^{}]*)\}", repl, pattern)


def avoid_collision(out, planned, overwrite):
    if overwrite:
        return out
    candidate = out
    while candidate in planned or Path(candidate).exists():
        candidate = "_" + candidate
    return candidate


def print_table(rows):
    iw = max([len("Input"), *[len(a) for a, _ in rows]])
    ow = max([len("Output"), *[len(b) for _, b in rows]])
    border = "+" + "-" * (iw + 2) + "+" + "-" * (ow + 2) + "+"
    print(border)
    print(f"| {'Input'.ljust(iw)} | {'Output'.ljust(ow)} |")
    print(border)
    for a, b in rows:
        print(f"| {a.ljust(iw)} | {b.ljust(ow)} |")
    print(border)


def apply_renames(mappings, opts):
    for src, dst in mappings:
        parent = Path(dst).parent
        if parent != Path(".") and opts["mkdir"]:
            parent.mkdir(parents=True, exist_ok=True)
        os.replace(src, dst) if opts["overwrite"] else os.rename(src, dst)


def write_generated_map(mappings, opts):
    if not opts.get("generate"):
        return
    data = {dst: src for src, dst in mappings}
    with open(opts["generate"], "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2)
        f.write("\n")


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
