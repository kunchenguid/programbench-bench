import subprocess
import tempfile
import unittest
import json
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
EXE = ROOT / "executable"


def run_cmd(args, cwd=None):
    return subprocess.run(
        [str(EXE), *args],
        cwd=cwd,
        text=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
    )


class NominoCliTests(unittest.TestCase):
    def test_version_output(self):
        result = run_cmd(["--version"])
        self.assertEqual(result.returncode, 0)
        self.assertEqual(result.stdout, "nomino 1.6.4\n")

    def test_sort_dry_run_uses_natural_order_and_preserves_extensions(self):
        with tempfile.TemporaryDirectory() as tmp:
            work = Path(tmp)
            for name in ["b.txt", "a.txt", "10.txt", "2.txt"]:
                (work / name).touch()

            result = run_cmd(["-t", "-s", "asc", "file-{:2}"], cwd=work)

            self.assertEqual(result.returncode, 0, result.stderr)
            self.assertEqual(
                result.stdout,
                "+--------+-------------+\n"
                "| Input  | Output      |\n"
                "+--------+-------------+\n"
                "| 2.txt  | file-01.txt |\n"
                "| 10.txt | file-02.txt |\n"
                "| a.txt  | file-03.txt |\n"
                "| b.txt  | file-04.txt |\n"
                "+--------+-------------+\n",
            )
            self.assertEqual(sorted(p.name for p in work.iterdir()), ["10.txt", "2.txt", "a.txt", "b.txt"])

    def test_regex_dry_run_uses_capture_groups_and_preserves_extensions(self):
        with tempfile.TemporaryDirectory() as tmp:
            work = Path(tmp)
            for name in ["img-12.jpg", "foo.txt", "img-7.png"]:
                (work / name).touch()

            result = run_cmd(["-t", "-r", "img-([0-9]+)", "photo-{1:3}"], cwd=work)

            self.assertEqual(result.returncode, 0, result.stderr)
            self.assertEqual(
                result.stdout,
                "+------------+---------------+\n"
                "| Input      | Output        |\n"
                "+------------+---------------+\n"
                "| img-7.png  | photo-007.png |\n"
                "| img-12.jpg | photo-012.jpg |\n"
                "+------------+---------------+\n",
            )

    def test_sort_renames_files_and_generates_reverse_map(self):
        with tempfile.TemporaryDirectory() as tmp:
            work = Path(tmp)
            (work / "a.txt").touch()
            (work / "b.txt").touch()

            result = run_cmd(["-q", "-s", "asc", "-g", "map.json", "x-{}"], cwd=work)

            self.assertEqual(result.returncode, 0, result.stderr)
            self.assertEqual(result.stdout, "")
            self.assertEqual(sorted(p.name for p in work.iterdir()), ["map.json", "x-1.txt", "x-2.txt"])
            self.assertEqual(json.loads((work / "map.json").read_text()), {"x-1.txt": "a.txt", "x-2.txt": "b.txt"})

    def test_map_file_dry_run_renames_from_input_to_output(self):
        with tempfile.TemporaryDirectory() as tmp:
            work = Path(tmp)
            (work / "a.txt").touch()
            (work / "b.txt").touch()
            (work / "map.json").write_text('{"a.txt":"aa.txt","b.txt":"bb.txt"}')

            result = run_cmd(["-t", "-m", "map.json"], cwd=work)

            self.assertEqual(result.returncode, 0, result.stderr)
            self.assertEqual(
                result.stdout,
                "+-------+--------+\n"
                "| Input | Output |\n"
                "+-------+--------+\n"
                "| a.txt | aa.txt |\n"
                "| b.txt | bb.txt |\n"
                "+-------+--------+\n",
            )

    def test_regex_max_depth_orders_by_depth_then_name(self):
        with tempfile.TemporaryDirectory() as tmp:
            work = Path(tmp)
            (work / "d1" / "d2").mkdir(parents=True)
            (work / "root-1.txt").touch()
            (work / "d1" / "inner-2.txt").touch()
            (work / "d1" / "d2" / "deep-3.txt").touch()

            result = run_cmd(["-t", "--max-depth", "3", "-r", "([a-z]+)-([0-9]+)", "x-{2}"], cwd=work)

            self.assertEqual(result.returncode, 0, result.stderr)
            self.assertIn("| root-1.txt       | x-1.txt |", result.stdout)
            self.assertLess(result.stdout.index("root-1.txt"), result.stdout.index("d1/inner-2.txt"))
            self.assertLess(result.stdout.index("d1/inner-2.txt"), result.stdout.index("d1/d2/deep-3.txt"))


if __name__ == "__main__":
    unittest.main()
