#!/bin/bash
set -e
rm -f executable
cp nomino.py executable
chmod +x executable
