import os
import subprocess
import tempfile
import unittest
import json


ROOT = os.path.dirname(os.path.dirname(__file__))
CMD = ["python3", os.path.join(ROOT, "src", "dust.py")]


class DustCliTests(unittest.TestCase):
    def run_cmd(self, *args, input_data=None):
        return subprocess.run(
            CMD + list(args),
            input=input_data,
            text=True,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            cwd=ROOT,
        )

    def test_version_and_help_are_documented(self):
        version = self.run_cmd("--version")
        self.assertEqual(version.returncode, 0)
        self.assertEqual(version.stdout, "Dust 1.2.3\n")

        help_result = self.run_cmd("-h")
        self.assertEqual(help_result.returncode, 0)
        self.assertIn("Like du but more intuitive", help_result.stdout)
        self.assertIn("Usage: executable [OPTIONS] [PATH]...", help_result.stdout)
        self.assertIn("-d, --depth <DEPTH>", help_result.stdout)

    def test_apparent_size_tree_lists_children_and_total(self):
        with tempfile.TemporaryDirectory() as tmp:
            os.mkdir(os.path.join(tmp, "alpha"))
            os.mkdir(os.path.join(tmp, "beta"))
            with open(os.path.join(tmp, "root.txt"), "wb") as f:
                f.write(b"0123456789")
            with open(os.path.join(tmp, "alpha", "a.bin"), "wb") as f:
                f.write(b"a" * 1500)
            with open(os.path.join(tmp, "beta", "b.log"), "wb") as f:
                f.write(b"b" * 2300)

            result = self.run_cmd("-s", "-b", "-p", "-n", "20", tmp)

        self.assertEqual(result.returncode, 0, result.stderr)
        lines = [line.rstrip() for line in result.stdout.splitlines() if line.strip()]
        self.assertTrue(any("10B" in line and line.endswith("/root.txt") for line in lines))
        self.assertTrue(any("1.5K" in line and line.endswith("/alpha/a.bin") for line in lines))
        self.assertTrue(any("1.5K" in line and line.endswith("/alpha") for line in lines))
        self.assertTrue(any("2.2K" in line and line.endswith("/beta/b.log") for line in lines))
        self.assertTrue(any(line.endswith("/beta") for line in lines))
        self.assertTrue(lines[-1].endswith(tmp))

    def test_filters_and_json_output_use_matching_files(self):
        with tempfile.TemporaryDirectory() as tmp:
            os.mkdir(os.path.join(tmp, "alpha"))
            os.mkdir(os.path.join(tmp, "beta"))
            with open(os.path.join(tmp, "alpha", "a.bin"), "wb") as f:
                f.write(b"a" * 1500)
            with open(os.path.join(tmp, "beta", "b.log"), "wb") as f:
                f.write(b"b" * 2300)

            filtered = self.run_cmd("-s", "-b", "-p", "-e", "log", tmp)
            json_result = self.run_cmd("-s", "-j", tmp)

        self.assertEqual(filtered.returncode, 0, filtered.stderr)
        self.assertIn("/beta/b.log", filtered.stdout)
        self.assertNotIn("/alpha/a.bin", filtered.stdout)

        self.assertEqual(json_result.returncode, 0, json_result.stderr)
        payload = json.loads(json_result.stdout)
        self.assertEqual(payload["name"], tmp)
        child_names = {child["name"] for child in payload["children"]}
        self.assertIn(os.path.join(tmp, "alpha"), child_names)
        self.assertIn(os.path.join(tmp, "beta"), child_names)

    def test_files_from_adds_total_root_for_multiple_inputs(self):
        with tempfile.TemporaryDirectory() as tmp:
            one = os.path.join(tmp, "one.bin")
            two = os.path.join(tmp, "two.log")
            with open(one, "wb") as f:
                f.write(b"a" * 1500)
            with open(two, "wb") as f:
                f.write(b"b" * 2300)
            list_file = os.path.join(tmp, "paths.txt")
            with open(list_file, "w", encoding="utf-8") as f:
                f.write(one + "\n" + two + "\n")

            result = self.run_cmd("-s", "-b", "-p", "--files-from", list_file)

        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertIn(one, result.stdout)
        self.assertIn(two, result.stdout)
        self.assertIn("(total)", result.stdout)


if __name__ == "__main__":
    unittest.main()
