#!/usr/bin/env python3
import argparse
import json
import os
import re
import stat
import sys
from dataclasses import dataclass, field


VERSION = "Dust 1.2.3"
HELP_SHORT = """Like du but more intuitive

Usage: executable [OPTIONS] [PATH]...

Arguments:
  [PATH]...  Input files or directories

Options:
  -d, --depth <DEPTH>              Depth to show
  -T, --threads <THREADS>          Number of threads to use
      --config <FILE>              Specify a config file to use
  -n, --number-of-lines <NUMBER>   Number of lines of output to show. (Default is terminal_height - 10)
  -p, --full-paths                 Subdirectories will not have their path shortened
  -X, --ignore-directory <PATH>    Exclude any file or directory with this path
  -I, --ignore-all-in-file <FILE>  Exclude any file or directory with a regex matching that listed in this file, the file entries will be added to the ignore regexs provided by --invert_filter
  -L, --dereference-links          dereference sym links - Treat sym links as directories and go into them
  -x, --limit-filesystem           Only count the files and directories on the same filesystem as the supplied directory
  -s, --apparent-size              Use file length instead of blocks
  -r, --reverse                    Print tree upside down (biggest highest)
  -c, --no-colors                  No colors will be printed (Useful for commands like: watch)
  -C, --force-colors               Force colors print
  -b, --no-percent-bars            No percent bars or percentages will be displayed
  -B, --bars-on-right              percent bars moved to right side of screen
  -z, --min-size <MIN_SIZE>        Minimum size file to include in output
  -R, --screen-reader              For screen readers. Removes bars. Adds new column: depth level (May want to use -p too for full path)
      --skip-total                 No total row will be displayed
  -f, --filecount                  Directory 'size' is number of child files instead of disk size
  -i, --ignore-hidden              Do not display hidden files
  -v, --invert-filter <REGEX>      Exclude filepaths matching this regex. To ignore png files type: -v "\\.png$"
  -e, --filter <REGEX>             Only include filepaths matching this regex. For png files type: -e "\\.png$"
  -t, --file-types                 show only these file types
  -w, --terminal-width <WIDTH>     Specify width of output overriding the auto detection of terminal width
  -P, --no-progress                Disable the progress indication
      --print-errors               Print path with errors
  -D, --only-dir                   Only directories will be displayed
  -F, --only-file                  Only files will be displayed. (Finds your largest files)
  -o, --output-format <FORMAT>     Changes output display size. si will print sizes in powers of 1000. b k m g t kb mb gb tb will print the whole tree in that size [possible values: si, b, k, m, g, t, kb, mb, gb, tb]
  -S, --stack-size <STACK_SIZE>    Specify memory to use as stack size - use if you see: 'fatal runtime error: stack overflow' (default low memory=1048576, high memory=1073741824)
  -j, --output-json                Output the directory tree as json to the current directory
  -M, --mtime <MTIME>              +/-n matches files modified more/less than n days ago , and n matches files modified exactly n days ago, days are rounded down.That is +n => (−∞, curr−(n+1)), n => [curr−(n+1), curr−n), and -n => (𝑐𝑢𝑟𝑟−𝑛, +∞)
  -A, --atime <ATIME>              just like -mtime, but based on file access time
  -y, --ctime <CTIME>              just like -mtime, but based on file change time
      --files0-from <FILES0_FROM>  Read NUL-terminated paths from FILE (use `-` for stdin)
      --files-from <FILES_FROM>    Read newline-terminated paths from FILE (use `-` for stdin)
      --collapse <COLLAPSE>        Keep these directories collapsed
  -m, --filetime <FILETIME>        Directory 'size' is max filetime of child files instead of disk size. while a/c/m for last accessed/changed/modified time [possible values: a, c, m]
  -h, --help                       Print help (see more with '--help')
  -V, --version                    Print version
"""


@dataclass
class Node:
    path: str
    name: str
    size: int
    is_dir: bool
    depth: int
    children: list = field(default_factory=list)


def build_parser():
    parser = argparse.ArgumentParser(add_help=False)
    parser.add_argument("paths", nargs="*")
    for short, long, dest in [
        ("-d", "--depth", "depth"),
        ("-T", "--threads", "threads"),
        ("-n", "--number-of-lines", "number"),
        ("-X", "--ignore-directory", "ignore_dirs"),
        ("-I", "--ignore-all-in-file", "ignore_file"),
        ("-z", "--min-size", "min_size"),
        ("-v", "--invert-filter", "invert_filter"),
        ("-e", "--filter", "filter"),
        ("-w", "--terminal-width", "width"),
        ("-o", "--output-format", "output_format"),
        ("-S", "--stack-size", "stack_size"),
        ("-M", "--mtime", "mtime"),
        ("-A", "--atime", "atime"),
        ("-y", "--ctime", "ctime"),
        ("-m", "--filetime", "filetime"),
    ]:
        parser.add_argument(short, long, dest=dest, action="append" if dest in {"ignore_dirs", "invert_filter"} else "store")
    parser.add_argument("--config")
    parser.add_argument("--files0-from")
    parser.add_argument("--files-from")
    parser.add_argument("--collapse", action="append", default=[])
    for short, long, dest in [
        ("-p", "--full-paths", "full_paths"),
        ("-L", "--dereference-links", "dereference"),
        ("-x", "--limit-filesystem", "limit_fs"),
        ("-s", "--apparent-size", "apparent"),
        ("-r", "--reverse", "reverse"),
        ("-c", "--no-colors", "no_colors"),
        ("-C", "--force-colors", "force_colors"),
        ("-b", "--no-percent-bars", "no_bars"),
        ("-B", "--bars-on-right", "bars_right"),
        ("-R", "--screen-reader", "screen_reader"),
        ("-f", "--filecount", "filecount"),
        ("-i", "--ignore-hidden", "ignore_hidden"),
        ("-t", "--file-types", "file_types"),
        ("-P", "--no-progress", "no_progress"),
        ("-D", "--only-dir", "only_dir"),
        ("-F", "--only-file", "only_file"),
        ("-j", "--output-json", "json"),
    ]:
        parser.add_argument(short, long, dest=dest, action="store_true")
    parser.add_argument("--skip-total", action="store_true")
    parser.add_argument("--print-errors", action="store_true")
    parser.add_argument("-h", "--help", action="store_true")
    parser.add_argument("-V", "--version", action="store_true")
    return parser


def main(argv=None):
    argv = list(sys.argv[1:] if argv is None else argv)
    if argv in (["-h"], ["--help"]):
        print(HELP_SHORT, end="")
        return 0
    if argv in (["-V"], ["--version"]):
        print(VERSION)
        return 0
    parser = build_parser()
    try:
        args = parser.parse_args(argv)
    except SystemExit:
        return 2
    if args.help:
        print(HELP_SHORT, end="")
        return 0
    if args.version:
        print(VERSION)
        return 0
    return run(args)


def run(args):
    paths = collect_input_paths(args)
    if not paths:
        paths = ["."]
    nodes = [scan_path(os.path.abspath(p), args, 0) for p in paths]
    nodes = [n for n in nodes if n is not None]
    if args.file_types:
        nodes = [filetype_tree(nodes, args)]
    elif len(nodes) > 1:
        nodes = [Node("(total)", "(total)", sum(n.size for n in nodes), True, 0, nodes)]
    if args.json:
        if len(nodes) == 1:
            print(json.dumps(to_json(nodes[0]), separators=(",", ":")))
        else:
            root = Node("", "(total)", sum(n.size for n in nodes), True, 0, nodes)
            print(json.dumps(to_json(root), separators=(",", ":")))
        return 0
    rows = []
    for node in nodes:
        flatten(node, args, rows)
    if args.only_file:
        rows = [r for r in rows if not r.is_dir or r.depth == 0]
    elif args.only_dir:
        rows = [r for r in rows if r.is_dir]
    if args.skip_total:
        root_paths = {n.path for n in nodes}
        rows = [r for r in rows if r.path not in root_paths]
    if args.reverse:
        rows = list(reversed(rows))
    if args.number:
        try:
            rows = rows[-int(args.number):] if not args.reverse else rows[: int(args.number)]
        except ValueError:
            pass
    print_rows(rows, args)
    return 0


def collect_input_paths(args):
    paths = list(args.paths)
    if args.files_from:
        data = sys.stdin.read() if args.files_from == "-" else open(args.files_from, "r", encoding="utf-8").read()
        paths.extend([p for p in data.splitlines() if p])
    if args.files0_from:
        data = sys.stdin.buffer.read() if args.files0_from == "-" else open(args.files0_from, "rb").read()
        paths.extend([p.decode() for p in data.split(b"\0") if p])
    return paths


def scan_path(path, args, depth):
    try:
        st = os.stat(path) if args.dereference else os.lstat(path)
    except OSError as exc:
        if args.print_errors:
            print(f"Did not have permissions for: {path}: {exc}", file=sys.stderr)
        return None
    base = os.path.basename(path.rstrip(os.sep)) or path
    if should_ignore(path, base, args):
        return None
    is_dir = stat.S_ISDIR(st.st_mode)
    if not is_dir:
        if not file_matches(path, args):
            return None
        size = file_metric(st, args)
        if size < parse_size(args.min_size):
            return None
        return Node(path, path, size, False, depth)
    children = []
    if base not in set(args.collapse or []):
        try:
            names = sorted(os.listdir(path))
        except OSError as exc:
            if args.print_errors:
                print(f"Did not have permissions for: {path}: {exc}", file=sys.stderr)
            names = []
        for name in names:
            child = scan_path(os.path.join(path, name), args, depth + 1)
            if child is not None:
                children.append(child)
    children.sort(key=lambda n: (n.size, n.path))
    if args.filecount:
        size = count_files(children)
    elif args.filetime:
        size = max([c.size for c in children] + [int(st.st_mtime)])
    else:
        own = st.st_size if args.apparent else st.st_blocks * 512
        size = own + sum(c.size for c in children)
    if size < parse_size(args.min_size):
        return None
    return Node(path, path, size, True, depth, children)


def should_ignore(path, base, args):
    if args.ignore_hidden and base.startswith("."):
        return True
    for ignored in args.ignore_dirs or []:
        if base == ignored or path == ignored or path.endswith(os.sep + ignored):
            return True
    patterns = list(args.invert_filter or [])
    if args.ignore_file:
        try:
            with open(args.ignore_file, "r", encoding="utf-8") as f:
                patterns.extend([line.strip() for line in f if line.strip()])
        except OSError:
            pass
    return any(re.search(p, path) for p in patterns)


def file_matches(path, args):
    return not args.filter or re.search(args.filter, path) is not None


def file_metric(st, args):
    if args.filecount:
        return 1
    if args.filetime:
        return int({"a": st.st_atime, "c": st.st_ctime, "m": st.st_mtime}.get(args.filetime, st.st_mtime))
    return st.st_size if args.apparent else st.st_blocks * 512


def count_files(children):
    total = 0
    for child in children:
        total += count_files(child.children) if child.is_dir else 1
    return total


def parse_size(text):
    if not text:
        return 0
    m = re.fullmatch(r"([0-9]+(?:\.[0-9]+)?)([kmgtKMGT]?)(i?[bB])?", text.strip())
    if not m:
        return 0
    value = float(m.group(1))
    unit = m.group(2).lower()
    mult = {"": 1, "k": 1000, "m": 1000**2, "g": 1000**3, "t": 1000**4}[unit]
    return int(value * mult)


def flatten(node, args, rows):
    max_depth = None
    if args.depth is not None:
        try:
            max_depth = int(args.depth)
        except ValueError:
            max_depth = None
    if max_depth is None or node.depth < max_depth:
        for child in node.children:
            flatten(child, args, rows)
    if max_depth is None or node.depth <= max_depth:
        if not (args.only_file and node.is_dir and node.depth != 0):
            rows.append(node)


def print_rows(rows, args):
    if args.screen_reader:
        namew = max([len(display_name(r, args)) for r in rows] + [0])
        sizew = max([len(format_size(r.size, args)) for r in rows] + [0])
        total = rows[-1].size if rows else 0
        for r in rows:
            pct = int((r.size * 100 / total) if total else 0)
            print(f"{display_name(r, args):<{namew}} {r.depth:>2} {format_size(r.size, args):>{sizew}} {pct:>3}%")
        return
    sizew = max([len(format_size(r.size, args)) for r in rows] + [0])
    for r in rows:
        connector = "┌──" if not args.reverse else "└──"
        if r.is_dir:
            connector = "┌─┴" if not args.reverse else "└─┬"
        indent = "  " * r.depth
        print(f"{format_size(r.size, args):>{sizew}} {indent}{connector} {display_name(r, args)}")


def display_name(node, args):
    if args.full_paths:
        return node.path
    if node.depth == 0:
        return node.path
    return os.path.basename(node.path.rstrip(os.sep)) or node.path


def format_size(size, args):
    if args.filecount:
        return str(size)
    fmt = args.output_format or "si"
    if fmt == "b":
        return f"{size}B"
    fixed = {"k": (1024, "K"), "m": (1024**2, "M"), "g": (1024**3, "G"), "t": (1024**4, "T"),
             "kb": (1000, "K"), "mb": (1000**2, "M"), "gb": (1000**3, "G"), "tb": (1000**4, "T")}
    if fmt in fixed:
        div, suffix = fixed[fmt]
        return f"{size // div}{suffix}"
    units = ["B", "K", "M", "G", "T"]
    value = float(size)
    idx = 0
    base = 1000 if fmt == "si" and args.output_format == "si" else 1024
    while value >= base and idx < len(units) - 1:
        value /= float(base)
        idx += 1
    if idx == 0:
        return f"{int(value)}B"
    return f"{value:.1f}{units[idx]}"


def to_json(node):
    return {"size": format_size(node.size, argparse.Namespace(filecount=False, output_format="si")),
            "name": node.path, "children": [to_json(c) for c in sorted(node.children, key=lambda n: n.size, reverse=True)]}


def filetype_tree(nodes, args):
    totals = {}

    def visit(node):
        if node.is_dir:
            for child in node.children:
                visit(child)
        else:
            base = os.path.basename(node.path)
            if "." in base and not base.startswith("."):
                ext = "." + base.rsplit(".", 1)[1]
            else:
                ext = "(no extension)"
            totals[ext] = totals.get(ext, 0) + node.size

    for node in nodes:
        visit(node)
    children = [Node(name, name, size, False, 1) for name, size in totals.items()]
    children.sort(key=lambda n: (n.size, n.name))
    return Node("(total)", "(total)", sum(totals.values()), True, 0, children)


if __name__ == "__main__":
    raise SystemExit(main())
