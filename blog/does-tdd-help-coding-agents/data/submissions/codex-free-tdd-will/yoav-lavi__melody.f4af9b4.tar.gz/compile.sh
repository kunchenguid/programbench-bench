#!/bin/bash
set -e
mkdir -p build
cp src/melody.py build/executable
chmod +x build/executable
rm -f executable
cp build/executable executable
chmod +x executable
