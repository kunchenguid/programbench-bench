import os, subprocess

ROOT = os.path.dirname(os.path.dirname(__file__))
BIN = os.path.join(ROOT, "build", "executable")


def run_melody(source, *args):
    proc = subprocess.run([BIN, "-", "-n", *args], input=source, text=True, capture_output=True)
    return proc.returncode, proc.stdout, proc.stderr


def test_readme_hashtag_example_compiles_from_stdin():
    code, out, err = run_melody("\"#\";\nsome of <word>;\n")
    assert code == 0
    assert err == ""
    assert out == r"#\w+" + "\n"

def test_exact_numeric_quantifier_wraps_literal_phrase():
    code, out, err = run_melody("16 of \"na\";\n")
    assert code == 0
    assert err == ""
    assert out == "(?:na){16}\n"

def test_groups_concatenate_or_alternate_and_accept_quantifiers():
    code, out, err = run_melody("2 of match { <space>; \"batman\"; }\nany of either { \"a\"; \"b\"; }\n")
    assert code == 0
    assert err == ""
    assert out == "(?: batman){2}(?:a|b)*\n"

def test_quoted_regex_metacharacters_are_escaped_as_literal_text():
    code, out, err = run_melody("\"a.b*\";\n")
    assert code == 0
    assert err == ""
    assert out == r"a\.b\*" + "\n"

def test_test_mode_reports_match_and_non_match_without_failing():
    code, out, err = run_melody("some of <digit>;\n", "-t", "123")
    assert code == 0
    assert out == "'123' matched\n"
    code, out, err = run_melody("some of <digit>;\n", "-t", "abc")
    assert code == 0
    assert out == "'abc' did not match\n"


def test_output_file_writes_compiled_regex(tmp_path):
    output = tmp_path / "regex.txt"
    proc = subprocess.run([BIN, "-", "-n", "-o", str(output)], input="not <digit>;\n", text=True, capture_output=True)
    assert proc.returncode == 0
    assert proc.stdout == ""
    assert output.read_text() == r"\D" + "\n"
