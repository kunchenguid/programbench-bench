#!/usr/bin/env python3
import argparse, re, sys

VERSION = "melody_cli 0.20.0"
SYMBOLS = {
    "char": ".", "space": " ", "whitespace": r"\s", "digit": r"\d", "word": r"\w",
    "newline": r"\n", "tab": r"\t", "return": r"\r", "alphabetic": "[a-zA-Z]",
    "alphanumeric": "[a-zA-Z0-9]", "boundary": r"\b", "start": "^", "end": "$", "backspace": r"[\b]",
}
NEG_SYMBOLS = {"digit": r"\D", "word": r"\W", "whitespace": r"\S", "space": "[^ ]", "char": "(?!)"}

class ParseError(Exception):
    pass

class Parser:
    def __init__(self, text):
        self.text = self._strip_comments(text)
        self.i = 0
    def _strip_comments(self, s):
        s = re.sub(r"//.*", "", s)
        s = re.sub(r"/\*.*?\*/", "", s, flags=re.S)
        return s
    def skip(self):
        while self.i < len(self.text) and self.text[self.i].isspace():
            self.i += 1
    def peek_word(self):
        self.skip(); m = re.match(r"[A-Za-z_][A-Za-z0-9_-]*", self.text[self.i:])
        return m.group(0) if m else None
    def take_word(self, w=None):
        got = self.peek_word()
        if got is None or (w is not None and got != w):
            raise ParseError("expected root")
        self.i += len(got); return got
    def take(self, ch):
        self.skip()
        if self.i >= len(self.text) or self.text[self.i] != ch:
            raise ParseError("expected root")
        self.i += 1
    def parse_root(self):
        parts = []
        while True:
            self.skip()
            if self.i >= len(self.text): break
            parts.append(self.parse_expr())
            self.skip()
            if self.i < len(self.text) and self.text[self.i] == ";": self.i += 1
        return "".join(parts)
    def parse_expr(self):
        self.skip()
        self.skip()
        if self.i < len(self.text) and self.text[self.i].isdigit():
            n = self.take_number(); self.skip()
            if self.peek_word() == "to":
                self.take_word("to"); m = self.take_number(); self.take_word("of")
                return self.quantify(self.parse_expr(), "{%d,%d}" % (n, m))
            self.take_word("of")
            return self.quantify(self.parse_expr(), "{%d}" % n)
        w = self.peek_word()
        if w in ("some", "any", "option"):
            self.take_word(); self.take_word("of")
            return self.quantify(self.parse_expr(), {"some":"+", "any":"*", "option":"?"}[w])
        if w == "not":
            self.take_word("not")
            nw = self.peek_word()
            if nw in ("ahead", "behind"):
                self.take_word(); body = self.parse_block_concat()
                return "(?!%s)" % body if nw == "ahead" else "(?<!%s)" % body
            return self.parse_symbol(neg=True)
        if w in ("match", "capture", "either", "ahead", "behind"):
            self.take_word(); body = self.parse_block_either() if w == "either" else self.parse_block_concat()
            if w == "match": return "(?:%s)" % body
            if w == "capture": return "(%s)" % body
            if w == "either": return "(?:%s)" % body
            if w == "ahead": return "(?=%s)" % body
            if w == "behind": return "(?<=%s)" % body
        if self.i < len(self.text) and self.text[self.i] == '"':
            return self.parse_string()
        if self.i < len(self.text) and self.text[self.i] == "<":
            return self.parse_symbol(False)
        raise ParseError("expected root")
    def take_number(self):
        self.skip(); m = re.match(r"\d+", self.text[self.i:])
        if not m: raise ParseError("expected amount")
        self.i += len(m.group(0)); return int(m.group(0))
    def parse_block_concat(self):
        self.take("{"); parts=[]
        while True:
            self.skip()
            if self.i < len(self.text) and self.text[self.i] == "}": self.i += 1; break
            parts.append(self.parse_expr()); self.skip()
            if self.i < len(self.text) and self.text[self.i] == ";": self.i += 1
        return "".join(parts)
    def parse_block_either(self):
        self.take("{"); parts=[]
        while True:
            self.skip()
            if self.i < len(self.text) and self.text[self.i] == "}": self.i += 1; break
            parts.append(self.parse_expr()); self.skip()
            if self.i < len(self.text) and self.text[self.i] == ";": self.i += 1
        return "|".join(parts)
    def parse_string(self):
        self.take('"'); out=[]
        while self.i < len(self.text):
            c=self.text[self.i]; self.i += 1
            if c == '"': return "".join(out)
            if c == "\\" and self.i < len(self.text):
                n=self.text[self.i]; self.i += 1
                if n == "n": out.append(r"\n")
                elif n == "t": out.append(r"\t")
                elif n == "r": out.append(r"\r")
                else: out.append(self.escape_literal_char(n))
            else:
                out.append(self.escape_literal_char(c))
        raise ParseError("expected root")
    def escape_literal_char(self, c):
        return "\\" + c if c in r".\*+?^${}()|[]" else c
    def parse_symbol(self, neg=False):
        self.skip(); self.take("<"); start=self.i
        while self.i < len(self.text) and self.text[self.i] != ">": self.i += 1
        if self.i >= len(self.text): raise ParseError("usage of an unrecognized symbol")
        name=self.text[start:self.i]; self.i += 1
        table = NEG_SYMBOLS if neg else SYMBOLS
        if name not in table: raise ParseError("usage of an unrecognized symbol")
        return table[name]
    def quantify(self, atom, q):
        if atom.startswith("(?:") or atom.startswith("(") or len(atom) == 1 or atom.startswith("[") or atom.startswith("\\") or atom in (".", " "):
            return atom + q
        return "(?:%s)%s" % (atom, q)

def compile_melody(text):
    return Parser(text).parse_root()

def main(argv=None):
    p=argparse.ArgumentParser(description="A CLI wrapping the Melody language compiler", add_help=False)
    p.add_argument("input", nargs="?"); p.add_argument("-o","--output"); p.add_argument("-n","--no-color", action="store_true")
    p.add_argument("-r","--repl", action="store_true"); p.add_argument("--generate-completions")
    p.add_argument("-t","--test"); p.add_argument("-f","--test-file"); p.add_argument("-h","--help", action="store_true"); p.add_argument("-V","--version", action="store_true")
    ns=p.parse_args(argv)
    if ns.help: print_help(); return 0
    if ns.version: print(VERSION); return 0
    if ns.generate_completions: print_completion(ns.generate_completions); return 0
    if ns.repl: return repl()
    try:
        src = sys.stdin.read() if ns.input in (None, "-") else open(ns.input).read()
        regex = compile_melody(src)
        if ns.output: open(ns.output,"w").write(regex+"\n")
        elif ns.test is not None:
            print("'%s' %s" % (ns.test, "matched" if re.search(regex, ns.test) else "did not match"))
        elif ns.test_file is not None:
            data=open(ns.test_file).read(); print("%s %s" % (ns.test_file, "matched" if re.search(regex, data) else "did not match"))
        else: print(regex)
        return 0
    except Exception as e:
        print("Error: " + str(e), file=sys.stderr); return 65

def print_help():
    print("A CLI wrapping the Melody language compiler\n")
    print("Usage: executable [OPTIONS] [INPUT_FILE_PATH]\n")
    print("Arguments:\n  [INPUT_FILE_PATH]  Read from a file\n                     Use '-' and or pipe input to read from stdin\n")
    print("Options:\n  -o, --output <OUTPUT_FILE_PATH>           Write to a file\n  -n, --no-color                            Print output with no color\n  -r, --repl                                Start the Melody REPL\n      --generate-completions <completions>  Outputs completions for the selected shell\n                                            To use, write the output to the appropriate location for your shell\n  -t, --test <test>                         Test the compiled regex against a string\n  -f, --test-file <test-file>               Test the compiled regex against the contents of a file\n  -h, --help                                Print help\n  -V, --version                             Print version")

def print_completion(shell):
    if shell == "fish": print("complete -c melody -s o -l output -d 'Write to a file' -r")
    else: print("# completion for melody")

def repl():
    print("Melody REPL")
    for line in sys.stdin:
        try: print(compile_melody(line))
        except Exception as e: print("Error: "+str(e))
    return 0
if __name__ == "__main__": sys.exit(main())
