#!/bin/bash
set -euo pipefail
cc -std=c99 -O2 -Wall -Wextra -o pigz_re src/main.c
./pigz_re --help | grep -q "Usage: pigz"
./pigz_re --version | grep -q "pigz 2.8"

tmp=$(mktemp -d)
trap 'rm -rf "$tmp"' EXIT
printf 'hello\nworld\nhello\n' > "$tmp/plain"
./pigz_re -c "$tmp/plain" > "$tmp/ours.gz"
/workspace/executable -dc "$tmp/ours.gz" > "$tmp/ref.out"
cmp "$tmp/plain" "$tmp/ref.out"

/workspace/executable -c "$tmp/plain" > "$tmp/ref.gz"
./pigz_re -dc "$tmp/ref.gz" > "$tmp/ours.out"
cmp "$tmp/plain" "$tmp/ours.out"

python3 - <<'PY' > "$tmp/big"
for i in range(20000):
    print(f"line-{i % 97:03d} abcdefghijklmnopqrstuvwxyz {i*i % 12345}")
PY
/workspace/executable -c "$tmp/big" > "$tmp/big.ref.gz"
./pigz_re -dc "$tmp/big.ref.gz" > "$tmp/big.out"
cmp "$tmp/big" "$tmp/big.out"

./pigz_re -cz < "$tmp/plain" > "$tmp/ours.zz"
/workspace/executable -dcz "$tmp/ours.zz" > "$tmp/z.ref.out"
cmp "$tmp/plain" "$tmp/z.ref.out"
/workspace/executable -cz "$tmp/plain" > "$tmp/ref.zz"
./pigz_re -dcz "$tmp/ref.zz" > "$tmp/z.ours.out"
cmp "$tmp/plain" "$tmp/z.ours.out"

./pigz_re -cK "$tmp/plain" > "$tmp/ours.zip"
/workspace/executable -dc "$tmp/ours.zip" > "$tmp/zip.ref.out"
cmp "$tmp/plain" "$tmp/zip.ref.out"
/workspace/executable -cK "$tmp/plain" > "$tmp/ref.zip"
./pigz_re -dc "$tmp/ref.zip" > "$tmp/zip.ours.out"
cmp "$tmp/plain" "$tmp/zip.ours.out"

cp "$tmp/plain" "$tmp/file"
./pigz_re -k "$tmp/file"
test -f "$tmp/file" && test -f "$tmp/file.gz"
./pigz_re -df "$tmp/file.gz"
cmp "$tmp/plain" "$tmp/file"
