#!/bin/bash
set -e
cc -std=c99 -O2 -w -o executable src/main.c
chmod +x executable
