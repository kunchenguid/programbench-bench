#define _POSIX_C_SOURCE 200809L
#include <errno.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <time.h>
#include <unistd.h>

typedef struct { unsigned char *p; size_t n, cap; } Buf;
static void die(const char *m){ fprintf(stderr,"pigz: %s\n",m); exit(1); }
static void *xrealloc(void *p,size_t n){ void *q=realloc(p,n?n:1); if(!q) die("out of memory"); return q; }
static void bput(Buf *b, int c){ if(b->n==b->cap){ b->cap=b->cap?b->cap*2:4096; b->p=xrealloc(b->p,b->cap);} b->p[b->n++]=(unsigned char)c; }
static void bwrite(Buf *b,const void *p,size_t n){ if(b->n+n>b->cap){ while(b->n+n>b->cap) b->cap=b->cap?b->cap*2:4096; b->p=xrealloc(b->p,b->cap);} memcpy(b->p+b->n,p,n); b->n+=n; }
static void put16(Buf*b,uint32_t x){ bput(b,x&255); bput(b,(x>>8)&255); }
static void put32(Buf*b,uint32_t x){ put16(b,x&65535); put16(b,x>>16); }

static uint32_t crc_table[256];
static void crc_init(void){ for(unsigned n=0;n<256;n++){ uint32_t c=n; for(int k=0;k<8;k++) c=c&1?0xedb88320U^(c>>1):c>>1; crc_table[n]=c; } }
static uint32_t crc32_calc(const unsigned char *p,size_t n){ uint32_t c=0xffffffffU; for(size_t i=0;i<n;i++) c=crc_table[(c^p[i])&255]^(c>>8); return c^0xffffffffU; }
static uint32_t adler32_calc(const unsigned char*p,size_t n){ uint32_t a=1,b=0; for(size_t i=0;i<n;i++){ a=(a+p[i])%65521; b=(b+a)%65521; } return (b<<16)|a; }

typedef struct { Buf *b; unsigned bitbuf; int bits; } BW;
static void bw_bits(BW*w,unsigned val,int cnt){ for(int i=0;i<cnt;i++){ w->bitbuf|=((val>>i)&1U)<<w->bits++; if(w->bits==8){ bput(w->b,w->bitbuf); w->bitbuf=0; w->bits=0; }}}
static void bw_align(BW*w){ if(w->bits) bw_bits(w,0,8-w->bits); }
static void deflate_stored(Buf*out,const unsigned char*in,size_t n){
  BW w={out,0,0}; size_t pos=0;
  do{
    size_t len=n-pos; if(len>65535) len=65535;
    bw_bits(&w, pos+len==n, 1); bw_bits(&w,0,2); bw_align(&w);
    put16(out,(uint32_t)len); put16(out,(uint32_t)(~len));
    bwrite(out,in+pos,len); pos+=len;
  } while(pos<n || n==0);
}

typedef struct { const unsigned char *p; size_t n,pos; unsigned bitbuf; int bits; } BR;
static int br_byte(BR*r){ return r->pos<r->n?r->p[r->pos++]:-1; }
static unsigned br_bits(BR*r,int cnt,int *ok){
  unsigned v=0; for(int i=0;i<cnt;i++){ if(!r->bits){ int c=br_byte(r); if(c<0){*ok=0; return v;} r->bitbuf=(unsigned)c; r->bits=8; } v|=(r->bitbuf&1U)<<i; r->bitbuf>>=1; r->bits--; } return v;
}
static void br_align(BR*r){ r->bitbuf=0; r->bits=0; }

typedef struct { int sym,len; unsigned code; } HE;
typedef struct { HE e[320]; int n; } HT;
static unsigned revbits(unsigned x,int n){ unsigned r=0; while(n--){ r=(r<<1)|(x&1U); x>>=1; } return r; }
static int ht_build(HT*t,const unsigned char*lens,int n){
  int count[16]={0}, next[16]={0}; t->n=0;
  for(int i=0;i<n;i++) if(lens[i]){ if(lens[i]>15) return 0; count[lens[i]]++; }
  int code=0; for(int bits=1;bits<=15;bits++){ code=(code+count[bits-1])<<1; next[bits]=code; }
  for(int i=0;i<n;i++) if(lens[i]){ t->e[t->n].sym=i; t->e[t->n].len=lens[i]; t->e[t->n].code=revbits((unsigned)next[lens[i]]++,lens[i]); t->n++; }
  return 1;
}
static int ht_decode(BR*r,HT*t,int*ok){
  unsigned code=0;
  for(int len=1;len<=15;len++){
    code|=br_bits(r,1,ok)<<(len-1); if(!*ok) return -1;
    for(int i=0;i<t->n;i++) if(t->e[i].len==len && t->e[i].code==code) return t->e[i].sym;
  }
  *ok=0; return -1;
}
static const int lext[29]={3,4,5,6,7,8,9,10,11,13,15,17,19,23,27,31,35,43,51,59,67,83,99,115,131,163,195,227,258};
static const int lextra[29]={0,0,0,0,0,0,0,0,1,1,1,1,2,2,2,2,3,3,3,3,4,4,4,4,5,5,5,5,0};
static const int dext[30]={1,2,3,4,5,7,9,13,17,25,33,49,65,97,129,193,257,385,513,769,1025,1537,2049,3073,4097,6145,8193,12289,16385,24577};
static const int dextra[30]={0,0,0,0,1,1,2,2,3,3,4,4,5,5,6,6,7,7,8,8,9,9,10,10,11,11,12,12,13,13};

static int inflate_codes(BR*r,HT*lt,HT*dt,Buf*out){
  int ok=1;
  for(;;){
    int s=ht_decode(r,lt,&ok); if(!ok) return 0;
    if(s<256){ bput(out,s); continue; }
    if(s==256) return 1;
    if(s<257||s>285) return 0;
    int i=s-257, len=lext[i]+(int)br_bits(r,lextra[i],&ok); if(!ok) return 0;
    int ds=ht_decode(r,dt,&ok); if(!ok||ds<0||ds>29) return 0;
    int dist=dext[ds]+(int)br_bits(r,dextra[ds],&ok); if(!ok||dist<=0||(size_t)dist>out->n) return 0;
    for(int k=0;k<len;k++) bput(out,out->p[out->n-dist]);
  }
}
static int inflate_raw(const unsigned char*in,size_t n,Buf*out){
  BR r={in,n,0,0,0}; int ok=1,last=0;
  while(!last && ok){
    last=(int)br_bits(&r,1,&ok); int type=(int)br_bits(&r,2,&ok); if(!ok) return 0;
    if(type==0){
      br_align(&r); int a=br_byte(&r),b=br_byte(&r),c=br_byte(&r),d=br_byte(&r);
      if(d<0) return 0; unsigned len=(unsigned)a|((unsigned)b<<8), nlen=(unsigned)c|((unsigned)d<<8);
      if(((len^0xffffU)&0xffffU)!=(nlen&0xffffU) || r.pos+len>r.n) return 0;
      bwrite(out,r.p+r.pos,len); r.pos+=len;
    } else if(type==1 || type==2){
      unsigned char ll[288]={0}, dl[32]={0}; HT lt,dt;
      if(type==1){
        for(int i=0;i<=143;i++) ll[i]=8; for(int i=144;i<=255;i++) ll[i]=9; for(int i=256;i<=279;i++) ll[i]=7; for(int i=280;i<288;i++) ll[i]=8;
        for(int i=0;i<32;i++) dl[i]=5;
      } else {
        static const int ord[19]={16,17,18,0,8,7,9,6,10,5,11,4,12,3,13,2,14,1,15};
        int hlit=(int)br_bits(&r,5,&ok)+257, hdist=(int)br_bits(&r,5,&ok)+1, hclen=(int)br_bits(&r,4,&ok)+4; if(!ok) return 0;
        unsigned char cl[19]={0}; for(int i=0;i<hclen;i++) cl[ord[i]]=(unsigned char)br_bits(&r,3,&ok); if(!ok) return 0;
        HT ct; if(!ht_build(&ct,cl,19)) return 0;
        int total=hlit+hdist, idx=0, prev=0; unsigned char vals[320]={0};
        while(idx<total){
          int s=ht_decode(&r,&ct,&ok); if(!ok) return 0;
          if(s<=15){ vals[idx++]=prev=s; }
          else if(s==16){ int rep=(int)br_bits(&r,2,&ok)+3; while(rep--&&idx<total) vals[idx++]=prev; }
          else if(s==17){ int rep=(int)br_bits(&r,3,&ok)+3; prev=0; while(rep--&&idx<total) vals[idx++]=0; }
          else if(s==18){ int rep=(int)br_bits(&r,7,&ok)+11; prev=0; while(rep--&&idx<total) vals[idx++]=0; }
          else return 0;
        }
        memcpy(ll,vals,hlit); memcpy(dl,vals+hlit,hdist);
      }
      if(!ht_build(&lt,ll,288)||!ht_build(&dt,dl,32)) return 0;
      if(!inflate_codes(&r,&lt,&dt,out)) return 0;
    } else return 0;
  }
  return ok;
}

static unsigned char *read_all(FILE*f,size_t*n){
  Buf b={0}; unsigned char tmp[8192]; size_t got;
  while((got=fread(tmp,1,sizeof(tmp),f))>0) bwrite(&b,tmp,got);
  if(ferror(f)) die(strerror(errno)); *n=b.n; return b.p;
}
static unsigned char *read_file(const char*path,size_t*n){
  if(!strcmp(path,"-")) return read_all(stdin,n);
  FILE*f=fopen(path,"rb"); if(!f){ fprintf(stderr,"pigz: abort: cannot open %s: %s\n",path,strerror(errno)); exit(1);} unsigned char*p=read_all(f,n); fclose(f); return p;
}
static void write_file_or_stdout(const char*path,const unsigned char*p,size_t n,int to_stdout,int force){
  if(to_stdout){ if(fwrite(p,1,n,stdout)!=n) exit(1); return; }
  if(!force && access(path,F_OK)==0){ fprintf(stderr,"pigz: abort: write would overwrite %s\n",path); exit(1); }
  FILE*f=fopen(path,"wb"); if(!f){ fprintf(stderr,"pigz: abort: cannot write %s: %s\n",path,strerror(errno)); exit(1);} if(fwrite(p,1,n,f)!=n) exit(1); fclose(f);
}
static char *with_suffix(const char*name,const char*suf){ size_t a=strlen(name),b=strlen(suf); char*r=xrealloc(NULL,a+b+1); memcpy(r,name,a); memcpy(r+a,suf,b+1); return r; }
static char *strip_suffix(const char*name,const char*suf){
  size_t a=strlen(name),b=strlen(suf); if(a>b && !strcmp(name+a-b,suf)){ char*r=xrealloc(NULL,a-b+1); memcpy(r,name,a-b); r[a-b]=0; return r; }
  if(a>3 && !strcmp(name+a-3,".gz")){ char*r=xrealloc(NULL,a-2); memcpy(r,name,a-3); r[a-3]=0; return r; }
  return with_suffix(name,".out");
}

static void gzip_make(Buf*out,const unsigned char*in,size_t n,const char*fname,const char*comment,int noname){
  uint32_t mt=0; if(fname && !noname){ struct stat st; if(!stat(fname,&st)) mt=(uint32_t)st.st_mtime; }
  bput(out,0x1f); bput(out,0x8b); bput(out,8); bput(out,(fname&&!noname?8:0)|(comment?16:0));
  put32(out,mt); bput(out,0); bput(out,3);
  if(fname&&!noname){ const char *base=strrchr(fname,'/'); base=base?base+1:fname; for(;*base;base++) bput(out,*base); bput(out,0); }
  if(comment){ for(const char*c=comment;*c;c++) bput(out,*c); bput(out,0); }
  deflate_stored(out,in,n); put32(out,crc32_calc(in,n)); put32(out,(uint32_t)n);
}
static void zlib_make(Buf*out,const unsigned char*in,size_t n){ bput(out,0x78); bput(out,0x01); deflate_stored(out,in,n); uint32_t a=adler32_calc(in,n); bput(out,a>>24); bput(out,a>>16); bput(out,a>>8); bput(out,a); }
static uint32_t dostime(time_t t){ struct tm *m=localtime(&t); if(!m) return 0; return ((uint32_t)(m->tm_year-80)<<25)|((uint32_t)(m->tm_mon+1)<<21)|((uint32_t)m->tm_mday<<16)|((uint32_t)m->tm_hour<<11)|((uint32_t)m->tm_min<<5)|((uint32_t)m->tm_sec/2); }
static void zip_make(Buf*out,const unsigned char*in,size_t n,const char*name){
  Buf comp={0}; deflate_stored(&comp,in,n); uint32_t crc=crc32_calc(in,n), dt=dostime(time(NULL)); const char*nm=name?name:"-"; uint16_t nl=(uint16_t)strlen(nm); size_t loc=0;
  put32(out,0x04034b50); put16(out,20); put16(out,0); put16(out,8); put16(out,dt&65535); put16(out,dt>>16); put32(out,crc); put32(out,(uint32_t)comp.n); put32(out,(uint32_t)n); put16(out,nl); put16(out,0); bwrite(out,nm,nl); bwrite(out,comp.p,comp.n);
  size_t cen=out->n; put32(out,0x02014b50); put16(out,0x031e); put16(out,20); put16(out,0); put16(out,8); put16(out,dt&65535); put16(out,dt>>16); put32(out,crc); put32(out,(uint32_t)comp.n); put32(out,(uint32_t)n); put16(out,nl); put16(out,0); put16(out,0); put16(out,0); put16(out,0); put32(out,0); put32(out,(uint32_t)loc); bwrite(out,nm,nl);
  put32(out,0x06054b50); put16(out,0); put16(out,0); put16(out,1); put16(out,1); put32(out,(uint32_t)(out->n-cen)); put32(out,(uint32_t)cen); put16(out,0); free(comp.p);
}

static int gzip_parse(const unsigned char*in,size_t n,size_t*start,size_t*end,uint32_t*crc,uint32_t*sz){
  if(n<18||in[0]!=0x1f||in[1]!=0x8b||in[2]!=8) return 0; size_t p=10; int flg=in[3];
  if(flg&4){ if(p+2>n) return 0; unsigned x=in[p]|(in[p+1]<<8); p+=2+x; }
  if(flg&8){ while(p<n&&in[p++]); }
  if(flg&16){ while(p<n&&in[p++]); }
  if(flg&2) p+=2; if(p+8>n) return 0; *start=p; *end=n-8; *crc=in[n-8]|(in[n-7]<<8)|(in[n-6]<<16)|(in[n-5]<<24); *sz=in[n-4]|(in[n-3]<<8)|(in[n-2]<<16)|(in[n-1]<<24); return *start<=*end;
}
static int zlib_parse(const unsigned char*in,size_t n,size_t*start,size_t*end,uint32_t*ad){
  if(n<6) return 0; if((in[0]&15)!=8 || (((in[0]<<8)+in[1])%31)!=0) return 0; if(in[1]&32) return 0; *start=2; *end=n-4; *ad=(in[n-4]<<24)|(in[n-3]<<16)|(in[n-2]<<8)|in[n-1]; return 1;
}
static int zip_parse(const unsigned char*in,size_t n,size_t*start,size_t*end,uint32_t*crc,uint32_t*sz){
  if(n<30||memcmp(in,"PK\003\004",4)) return 0; unsigned flags=in[6]|(in[7]<<8), method=in[8]|(in[9]<<8), nl=in[26]|(in[27]<<8), xl=in[28]|(in[29]<<8); if(method!=8) return 0;
  uint32_t cs=in[18]|(in[19]<<8)|(in[20]<<16)|(in[21]<<24); *sz=in[22]|(in[23]<<8)|(in[24]<<16)|(in[25]<<24); *crc=in[14]|(in[15]<<8)|(in[16]<<16)|(in[17]<<24);
  if(flags&8){
    size_t eocd=n>22?n-22:0; while(eocd>0 && memcmp(in+eocd,"PK\005\006",4)) eocd--;
    if(eocd==0 || eocd+22>n) return 0; uint32_t cen=in[eocd+16]|(in[eocd+17]<<8)|(in[eocd+18]<<16)|(in[eocd+19]<<24);
    if(cen+46>n || memcmp(in+cen,"PK\001\002",4)) return 0;
    *crc=in[cen+16]|(in[cen+17]<<8)|(in[cen+18]<<16)|(in[cen+19]<<24);
    cs=in[cen+20]|(in[cen+21]<<8)|(in[cen+22]<<16)|(in[cen+23]<<24);
    *sz=in[cen+24]|(in[cen+25]<<8)|(in[cen+26]<<16)|(in[cen+27]<<24);
  }
  *start=30+nl+xl; *end=*start+cs; return *end<=n;
}
static int decompress(const unsigned char*in,size_t n,Buf*out,int test_only){
  size_t s=0,e=0; uint32_t want=0,sz=0,ad=0; int kind=0;
  if(gzip_parse(in,n,&s,&e,&want,&sz)) kind=1; else if(zlib_parse(in,n,&s,&e,&ad)) kind=2; else if(zip_parse(in,n,&s,&e,&want,&sz)) kind=3; else return 0;
  if(!inflate_raw(in+s,e-s,out)) return 0;
  if(kind==2){ if(adler32_calc(out->p,out->n)!=ad) return 0; }
  else { if(crc32_calc(out->p,out->n)!=want || ((uint32_t)out->n)!=sz) return 0; }
  (void)test_only; return 1;
}

static void help(void){
  puts("Usage: pigz [options] [files ...]");
  puts("  will compress files in place, adding the suffix '.gz'. If no files are");
  puts("  specified, stdin will be compressed to stdout. pigz does what gzip does,");
  puts("  but spreads the work over multiple processors and cores when compressing.");
  puts("");
  puts("Options:");
  puts("  -0 to -9, -11        Compression level (level 11, zopfli, is much slower)");
  puts("  -c, --stdout         Write all processed output to stdout (won't delete)");
  puts("  -d, --decompress     Decompress the compressed input");
  puts("  -f, --force          Force overwrite, compress .gz, links, and to terminal");
  puts("  -h, --help           Display a help screen and quit");
  puts("  -k, --keep           Do not delete original file after processing");
  puts("  -K, --zip            Compress to PKWare zip (.zip) single entry format");
  puts("  -l, --list           List the contents of the compressed input");
  puts("  -t, --test           Test the integrity of the compressed input");
  puts("  -V  --version        Show the version of pigz");
  puts("  -z, --zlib           Compress to zlib (.zz) instead of gzip format");
}
static void license(void){ puts("pigz 2.8\\nCopyright (C) 2007-2023 Mark Adler\\nThis software is provided 'as-is', without any express or implied warranty."); }

int main(int argc,char**argv){
  crc_init(); int decomp=0,to_stdout=0,keep=0,force=0,zlib=0,zip=0,test=0,list=0,noname=0,verbose=0; const char*suffix=".gz",*comment=NULL,*alias="-"; char**files=xrealloc(NULL,sizeof(char*)*(argc+1)); int nf=0;
  const char *prog=strrchr(argv[0],'/'); prog=prog?prog+1:argv[0]; if(strstr(prog,"unpigz")) decomp=1;
  for(int ai=1;ai<argc;ai++){
    char*a=argv[ai]; if(!strcmp(a,"--")){ while(++ai<argc) files[nf++]=argv[ai]; break; }
    if(a[0]=='-'&&a[1]){
      if(!strcmp(a,"--help")){help(); return 0;} if(!strcmp(a,"--version")){puts("pigz 2.8"); return 0;}
      if(!strcmp(a,"--license")){license(); return 0;} if(!strcmp(a,"--stdout")||!strcmp(a,"--to-stdout")){to_stdout=1; continue;}
      if(!strcmp(a,"--decompress")||!strcmp(a,"--uncompress")){decomp=1; continue;} if(!strcmp(a,"--zlib")){zlib=1; continue;} if(!strcmp(a,"--zip")){zip=1; continue;}
      if(!strcmp(a,"--keep")){keep=1; continue;} if(!strcmp(a,"--force")){force=1; continue;} if(!strcmp(a,"--test")){test=1; decomp=1; continue;} if(!strcmp(a,"--list")){list=1; decomp=1; continue;}
      for(size_t j=1;a[j];j++){
        char o=a[j]; if(o>='0'&&o<='9') continue;
        if(o=='h'){help(); return 0;} else if(o=='V'){ if(verbose) puts("pigz 2.8\nzlib 1.2.11"); else puts("pigz 2.8"); return 0; }
        else if(o=='L'){license(); return 0;} else if(o=='d') decomp=1; else if(o=='c') to_stdout=1; else if(o=='k') keep=1; else if(o=='f') force=1; else if(o=='z') zlib=1; else if(o=='K') zip=1; else if(o=='t'){test=1; decomp=1;} else if(o=='l'){list=1; decomp=1;} else if(o=='n'||o=='m') noname=1; else if(o=='N'||o=='M') noname=0; else if(o=='v') verbose=1; else if(o=='q'||o=='r'||o=='i'||o=='R'||o=='H'||o=='U'||o=='Y'||o=='F'||o=='O') {}
        else if(o=='S'||o=='C'||o=='A'||o=='p'||o=='b'||o=='I'||o=='J'){ const char*val=a[j+1]?a+j+1:(++ai<argc?argv[ai]:""); if(o=='S') suffix=val; else if(o=='C') comment=val; else if(o=='A') alias=val; break; }
      }
    } else files[nf++]=a;
  }
  if(nf==0){ files[nf++]="-"; to_stdout=1; }
  int status=0;
  for(int i=0;i<nf;i++){
    size_t in_n=0; unsigned char*in=read_file(files[i],&in_n); Buf out={0};
    if(decomp){
      if(!decompress(in,in_n,&out,test)){ if(!test) fprintf(stderr,"pigz: skipping: %s corrupted -- invalid deflate data\n",files[i]); status=1; }
      else if(list){ printf("compressed   original reduced  name\n%10lu %10lu %5.1f%%  %s\n",(unsigned long)in_n,(unsigned long)out.n,0.0,files[i]); }
      else if(!test){ char *on=to_stdout?NULL:strip_suffix(files[i],suffix); write_file_or_stdout(on,out.p,out.n,to_stdout,force); if(!to_stdout&&!keep&&strcmp(files[i],"-")) unlink(files[i]); free(on); }
    } else {
      if(zip) zip_make(&out,in,in_n,strcmp(files[i],"-")?files[i]:alias); else if(zlib) zlib_make(&out,in,in_n); else gzip_make(&out,in,in_n,strcmp(files[i],"-")?files[i]:NULL,comment,noname);
      char *on=NULL; if(!to_stdout) on=with_suffix(files[i], zlib?".zz":(zip?".zip":suffix)); write_file_or_stdout(on,out.p,out.n,to_stdout,force); if(!to_stdout&&!keep&&strcmp(files[i],"-")) unlink(files[i]); free(on);
    }
    free(in); free(out.p);
  }
  free(files); return status;
}
