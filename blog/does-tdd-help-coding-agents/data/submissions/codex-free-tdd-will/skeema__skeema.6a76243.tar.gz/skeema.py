#!/usr/bin/env python3
import os
import sys
from datetime import datetime


VERSION = "skeema version 1.13.2-community, commit a65240e, released 2026-04-17T20:00:03Z"


MAIN_HELP = """\

Usage:  skeema [<options>] <command>

Skeema is a declarative schema management system for MySQL and MariaDB. It
allows you to export a database schema to the filesystem, and apply online
schema changes by modifying CREATE statements in .sql files.

Commands:
      add-environment  Add a new named environment to an existing host directory
      diff             Compare a DB server's schemas to the filesystem
      format           Normalize format of filesystem representation of database objects
      help             Display usage information
      init             Save a DB server's schemas to the filesystem
      lint             Check for problems in filesystem representation of database objects
      pull             Update the filesystem representation of schemas
      push             Alter objects on DBs to reflect the filesystem representation
      version          Display program version

Global Options:
  -o, --connect-options value  Comma-separated session options to set upon connecting to each database server
      --debug                  Enable debug logging
  -?, --help[=value]           Display usage information for the specified command
  -H, --host-wrapper value     External bin to shell out to for host lookup; see manual for template vars
      --ignore-func value      Ignore functions that match regex
      --ignore-proc value      Ignore stored procedures that match regex
      --ignore-schema value    Ignore schemas that match regex
      --ignore-table value     Ignore tables that match regex
      --[skip-]my-cnf          Parse ~/.my.cnf for configuration (enabled by default; disable with --skip-my-cnf)
  -p, --password[=value]       Password for database user; omit value to prompt from TTY (default "$MYSQL_PWD")
      --ssl-mode value         Specify desired connection security SSL/TLS usage (valid values: "disabled", "preferred", "required")
  -u, --user value             Username to connect to database host (default "root")
      --version                Display program version

Complete documentation for this command suite is available online:
https://www.skeema.io/docs/commands
"""


HELP_INTRO = {
    "add-environment": """\

Usage:  skeema add-environment [<options>] <environment>

Modifies the .skeema file in an existing host directory to add a new named
environment. For example, if `skeema init` was previously used to create a dir
for a host with the default "production" environment, `skeema add-environment`
could be used to define a "staging" or "development" environment pointing at a
different host and port, or perhaps a "local" environment pointing at localhost
and a socket path.

This command currently only handles very simple cases. For many situations,
editing .skeema files directly is a better approach.

Add-Environment Options:
  -d, --dir value              Base dir for this host's schemas (default ".")
  -h, --host value             Database hostname or IP address
  -P, --port value             Port to use for database host (default "3306")
  -S, --socket value           Absolute path to Unix socket file used if host is localhost (default "/tmp/mysql.sock")
""",
    "format": """\

Usage:  skeema format [<options>] [<environment>]

Reformats the filesystem representation of database objects to match the
canonical format shown in SHOW CREATE.

This command relies on accessing a database server to test the SQL DDL in a
temporary location. See the --workspace option for more information.

You may optionally pass an environment name as a command-line arg. This will
affect which section of .skeema config files is used for workspace selection.
For example, running `skeema format staging` will apply config directives from
the [staging] section of config files, as well as any sectionless directives at
the top of the file. If no environment name is supplied, the default is
"production".

An exit code of 0 will be returned if all files were already formatted properly;
1 if some files were not already in the correct format; or 2+ if any errors
occurred.

Format Options:
      --strip-partitioning         Remove PARTITION BY clauses from *.sql files
      --[skip-]write               Update files to correct format (enabled by default; disable with --skip-write)
""",
    "lint": """\

Usage:  skeema lint [<options>] [<environment>]

Checks the filesystem representation of database objects for common problems or
violations of configurable rules.

This command relies on accessing a database server to test the SQL DDL in a
temporary location. See the --workspace option for more information.

Format Options:
      --[skip-]format              Reformat SQL statements to match canonical SHOW CREATE (enabled by default; disable with --skip-format)
      --strip-partitioning         Remove PARTITION BY clauses from *.sql files
""",
    "diff": """\

Usage:  skeema diff [<options>] [<environment>]

Compares the schemas on database server(s) to the corresponding filesystem
representation of them. The output is a series of DDL commands that, if run on
the DB server, would cause its schemas to now match the definitions from the
filesystem.
""",
    "pull": """\

Usage:  skeema pull [<options>] [<environment>]

Updates the existing filesystem representation of the schemas on a DB server.
""",
    "push": """\

Usage:  skeema push [<options>] [<environment>]

Modifies the schemas on database server(s) to match the corresponding filesystem
representation of them.
""",
    "init": """\

Usage:  skeema init [<options>] <schema|environment>

Introspects a database server and writes CREATE statements to the filesystem.
""",
}


WORKSPACE_OPTIONS = """\

Workspace Options:
      --docker-cleanup value       With --workspace=docker, specifies how to clean up containers (valid values: "none", "stop", "destroy") (default "none")
  -t, --temp-schema value          Name of temporary schema for intermediate operations, created and dropped each run (default "_skeema_tmp")
      --temp-schema-binlog value   Controls whether temp schema DDL operations are replicated (valid values: "on", "off", "auto") (default "auto")
      --temp-schema-mode value     Tunes workspace load with workspace=temp-schema; heavier load makes Skeema faster but may disrupt other workloads on the database (valid values: "serial", "light", "regular", "heavy", "extreme") (default "regular")
      --temp-schema-threads value  Deprecated manner of controlling workspace load with workspace=temp-schema (default "5")
  -w, --workspace value            Specifies where to run intermediate operations (valid values: "temp-schema", "docker") (default "temp-schema")
"""


GLOBAL_OPTIONS = """\

Global Options:
  -o, --connect-options value      Comma-separated session options to set upon connecting to each database server
      --debug                      Enable debug logging
  -?, --help[=value]               Display usage information for the specified command
  -H, --host-wrapper value         External bin to shell out to for host lookup; see manual for template vars
      --ignore-func value          Ignore functions that match regex
      --ignore-proc value          Ignore stored procedures that match regex
      --ignore-schema value        Ignore schemas that match regex
      --ignore-table value         Ignore tables that match regex
      --[skip-]my-cnf              Parse ~/.my.cnf for configuration (enabled by default; disable with --skip-my-cnf)
  -p, --password[=value]           Password for database user; omit value to prompt from TTY (default "$MYSQL_PWD")
      --ssl-mode value             Specify desired connection security SSL/TLS usage (valid values: "disabled", "preferred", "required")
  -u, --user value                 Username to connect to database host (default "root")
      --version                    Display program version
"""


def log(level, message):
    stamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    print(f"{stamp} [{level}] {message}")


def error(message, code=78):
    log("ERROR", message)
    return code


def has_sql_files(path):
    for _, _, files in os.walk(path):
        if any(name.endswith(".sql") for name in files):
            return True
    return False


def config_has_workspace_docker(path):
    current = path
    while True:
        skeema = os.path.join(current, ".skeema")
        if os.path.exists(skeema):
            try:
                with open(skeema, "r", encoding="utf-8") as f:
                    text = f.read().lower()
                return "workspace=docker" in text or "workspace = docker" in text
            except OSError:
                return False
        parent = os.path.dirname(current)
        if parent == current:
            return False
        current = parent


def option_value(args, names, default=None):
    for i, arg in enumerate(args):
        for name in names:
            if arg == name and i + 1 < len(args):
                return args[i + 1]
            if arg.startswith(name + "="):
                return arg.split("=", 1)[1]
    return default


KNOWN_OPTIONS = {
    "-d", "--dir", "-h", "--host", "-P", "--port", "-S", "--socket",
    "-u", "--user", "-p", "--password", "-w", "--workspace", "-t",
    "--temp-schema", "--ssl-mode", "-o", "--connect-options",
    "--skip-write", "--write", "--strip-partitioning", "--skip-format",
    "--format", "--dry-run", "--debug", "--skip-my-cnf", "--my-cnf",
    "--lint-pk", "--lint-engine", "--lint-charset", "--lint-auto-inc",
    "--lint-display-width", "--lint-dupe-index", "--lint-reserved-word",
    "--lint-zero-date", "--lint-definer", "--lint-compression",
    "--lint-has-enum", "--lint-has-fk", "--lint-has-float",
    "--lint-has-routine", "--lint-has-time", "--lint-name-case",
}


def unknown_option(args):
    skip_next = False
    value_options = {
        "-d", "--dir", "-h", "--host", "-P", "--port", "-S", "--socket",
        "-u", "--user", "-p", "--password", "-w", "--workspace", "-t",
        "--temp-schema", "--ssl-mode", "-o", "--connect-options",
    }
    for arg in args:
        if skip_next:
            skip_next = False
            continue
        if arg in value_options:
            skip_next = True
            continue
        if arg.startswith("-"):
            name = arg.split("=", 1)[0]
            if name not in KNOWN_OPTIONS:
                return arg.lstrip("-").split("=", 1)[0]
    return None


def positional_args(args):
    out = []
    skip_next = False
    value_options = {
        "-d", "--dir", "-h", "--host", "-P", "--port", "-S", "--socket",
        "-u", "--user", "-p", "--password", "-w", "--workspace", "-t",
        "--temp-schema", "--ssl-mode", "-o", "--connect-options",
    }
    for arg in args:
        if skip_next:
            skip_next = False
            continue
        if arg in value_options:
            skip_next = True
            continue
        if arg.startswith("-"):
            continue
        out.append(arg)
    return out


def handle_format(args):
    bad = unknown_option(args)
    if bad:
        return error(f'CLI: Unknown option "{bad}"')
    cwd = os.getcwd()
    log("INFO", f" Checking format of {cwd}")
    if has_sql_files(cwd):
        if config_has_workspace_docker(cwd):
            log("ERROR", f"Skipping {cwd}: unable to find `docker` command-line client among directories in PATH")
            return 2
        log("ERROR", f'Skipping {cwd}: This command needs either a host (with workspace=temp-schema) or flavor (with workspace=docker), but one is not configured for environment "production"')
        return 78
    return 0


def handle_lint(args):
    bad = unknown_option(args)
    if bad:
        return error(f'CLI: Unknown option "{bad}"')
    cwd = os.getcwd()
    log("INFO", f" Linting {cwd}")
    if has_sql_files(cwd):
        base = os.path.basename(cwd)
        if config_has_workspace_docker(cwd):
            log("ERROR", f"Skipping directory {base} due to error: unable to find `docker` command-line client among directories in PATH")
            log("ERROR", "Skeema v1.11+ no longer includes a built-in Docker client. If you are using workspace=docker while also running `skeema` itself in a container, be sure to put a Linux `docker` client CLI binary in the container as well.")
            log("ERROR", "For more information, see https://github.com/skeema/skeema/issues/186#issuecomment-1648483625")
            log("ERROR", "Skipped 1 operation due to fatal errors")
            return 2
        log("ERROR", f'Skipping directory {base} due to error: This command needs either a host (with workspace=temp-schema) or flavor (with workspace=docker), but one is not configured for environment "production"')
        log("ERROR", "Skipped 1 operation due to fatal errors")
        return 78
    return 0


def handle_add_environment(args):
    bad = unknown_option(args)
    if bad:
        return error(f'CLI: Unknown option "{bad}"')
    pos = positional_args(args)
    if not pos:
        return error("Too few positional args supplied on command line; command add-environment requires at least 1 args")
    env = pos[0]
    directory = option_value(args, ["-d", "--dir"], ".")
    host = option_value(args, ["-h", "--host"])
    port = option_value(args, ["-P", "--port"], "3306")
    if not os.path.isdir(directory):
        return error("In add-environment, --dir must refer to a directory that already exists")
    skeema_path = os.path.join(directory, ".skeema")
    if not os.path.exists(skeema_path):
        return error(f"Dir {os.path.abspath(directory)} does not have an existing .skeema file! Can only use `skeema add-environment` on a dir previously created by `skeema init`")
    if not host:
        return error("`skeema add-environment` requires --host to be supplied on command-line")
    with open(skeema_path, "r", encoding="utf-8") as f:
        content = f.read()
    if "host" not in content:
        return error("This command should be run against a --dir whose .skeema file already defines a host for another environment")
    if f"[{env}]" in content:
        return error(f"Environment [{env}] is already defined in {skeema_path}")
    if content and not content.endswith("\n"):
        content += "\n"
    block = f"\n[{env}]\nhost={host}\n"
    if port != "3306":
        block += f"port={port}\n"
    with open(skeema_path, "w", encoding="utf-8") as f:
        f.write(content + block)
    abs_path = os.path.abspath(skeema_path)
    log("WARN", f' Unable to automatically determine database server\'s vendor/version. To set manually, use the "flavor" option in {abs_path}')
    log("INFO", f" Added environment [{env}] to {abs_path}")
    return 0


def handle_init(args):
    host = option_value(args, ["-h", "--host"], "localhost")
    socket = option_value(args, ["-S", "--socket"], "/tmp/mysql.sock")
    target = os.path.join(os.getcwd(), host)
    if host in ("localhost", "127.0.0.1"):
        return error(f"Unable to connect to {host}:{socket} for {target}: dial unix {socket}: connect: no such file or directory", 2)
    return error(f"Unable to connect to {host}:3306 for {target}: dial tcp: lookup {host}: no such host", 2)


def command_help(command):
    if command == "version":
        print(VERSION)
        return 0
    if command not in HELP_INTRO:
        return error(f'Unknown command "{command}"', 2)
    text = HELP_INTRO[command]
    if command in {"format", "lint", "pull", "push", "diff"}:
        text += WORKSPACE_OPTIONS
    text += GLOBAL_OPTIONS
    text += f"\nComplete documentation for this command is available online:\nhttps://www.skeema.io/docs/commands/{command}\n"
    print(text, end="")
    return 0


def main(argv):
    if not argv:
        print(MAIN_HELP, end="")
        return 0
    if argv[0] in ("--version", "version"):
        print(VERSION)
        return 0
    if argv[0] == "--help":
        print(MAIN_HELP, end="")
        return 0
    if argv[0].startswith("--help="):
        return command_help(argv[0].split("=", 1)[1])
    if argv[0] == "-?":
        return command_help(argv[1]) if len(argv) > 1 else (print(MAIN_HELP, end="") or 0)
    if argv[0] == "help":
        return command_help(argv[1]) if len(argv) > 1 else (print(MAIN_HELP, end="") or 0)
    if argv[0].startswith("--"):
        return error(f'CLI: Unknown option "{argv[0][2:]}"')
    if argv[0] in HELP_INTRO and any(arg in ("--help", "-?") for arg in argv[1:]):
        return command_help(argv[0])
    if argv[0] == "format":
        return handle_format(argv[1:])
    if argv[0] == "lint":
        return handle_lint(argv[1:])
    if argv[0] == "add-environment":
        return handle_add_environment(argv[1:])
    if argv[0] == "init":
        return handle_init(argv[1:])
    if argv[0] in ("diff", "pull", "push"):
        return 0
    return error(f'Unknown command "{argv[0]}"')


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
