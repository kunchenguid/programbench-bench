#!/bin/bash
set -e
cp skeema.py executable
chmod +x executable
