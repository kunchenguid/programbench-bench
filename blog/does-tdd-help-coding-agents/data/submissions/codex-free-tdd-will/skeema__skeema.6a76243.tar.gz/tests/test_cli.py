import os
import subprocess
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
BIN = ROOT / "executable"


def run_cmd(*args, cwd=None):
    return subprocess.run(
        [str(BIN), *args],
        cwd=cwd or ROOT,
        text=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
    )


def test_version_and_top_level_help():
    result = run_cmd("version")
    assert result.returncode == 0
    assert result.stdout.strip() == (
        "skeema version 1.13.2-community, commit a65240e, "
        "released 2026-04-17T20:00:03Z"
    )

    result = run_cmd("--help")
    assert result.returncode == 0
    assert "Usage:  skeema [<options>] <command>" in result.stdout
    assert "add-environment  Add a new named environment" in result.stdout


def test_errors_noop_commands_and_add_environment(tmp_path):
    result = run_cmd("bogus", cwd=tmp_path)
    assert result.returncode == 78
    assert 'Unknown command "bogus"' in result.stdout

    result = run_cmd("format", "--skip-write", cwd=tmp_path)
    assert result.returncode == 0
    assert f"[INFO]  Checking format of {tmp_path}" in result.stdout

    result = run_cmd("lint", "--skip-format", cwd=tmp_path)
    assert result.returncode == 0
    assert f"[INFO]  Linting {tmp_path}" in result.stdout

    host_dir = tmp_path / "host"
    host_dir.mkdir()
    (host_dir / ".skeema").write_text("[production]\nhost=prod.example.com\nport=3307\nuser=root\n")
    result = run_cmd(
        "add-environment",
        "dev",
        "-d",
        str(host_dir),
        "-h",
        "dev.example.com",
        "-P",
        "3310",
        cwd=tmp_path,
    )
    assert result.returncode == 0
    assert "Added environment [dev]" in result.stdout
    assert (host_dir / ".skeema").read_text() == (
        "[production]\n"
        "host=prod.example.com\n"
        "port=3307\n"
        "user=root\n"
        "\n"
        "[dev]\n"
        "host=dev.example.com\n"
        "port=3310\n"
    )


def test_sql_files_without_workspace_config_fail_like_skeema(tmp_path):
    (tmp_path / "table.sql").write_text(
        "CREATE TABLE t (\n"
        "  id int\n"
        ") ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;\n"
    )

    result = run_cmd("format", "--skip-write", cwd=tmp_path)
    assert result.returncode == 78
    assert f"Skipping {tmp_path}: This command needs either a host" in result.stdout

    result = run_cmd("lint", "--skip-format", cwd=tmp_path)
    assert result.returncode == 78
    assert f"Skipping directory {tmp_path.name} due to error" in result.stdout
    assert "Skipped 1 operation due to fatal errors" in result.stdout


def test_workspace_docker_without_docker_client_error(tmp_path):
    (tmp_path / ".skeema").write_text("[production]\nworkspace=docker\nflavor=mysql:8.0\n")
    (tmp_path / "table.sql").write_text("CREATE TABLE t (id int);\n")

    result = run_cmd("format", "--skip-write", cwd=tmp_path)
    assert result.returncode == 2
    assert "unable to find `docker` command-line client among directories in PATH" in result.stdout

    result = run_cmd("lint", "--skip-format", cwd=tmp_path)
    assert result.returncode == 2
    assert "Skeema v1.11+ no longer includes a built-in Docker client" in result.stdout


def test_command_local_help_and_unknown_option(tmp_path):
    result = run_cmd("format", "--help", cwd=tmp_path)
    assert result.returncode == 0
    assert "Usage:  skeema format [<options>] [<environment>]" in result.stdout

    result = run_cmd("add-environment", "dev", "--help", cwd=tmp_path)
    assert result.returncode == 0
    assert "Usage:  skeema add-environment [<options>] <environment>" in result.stdout

    result = run_cmd("format", "--bogus", cwd=tmp_path)
    assert result.returncode == 78
    assert 'CLI: Unknown option "bogus"' in result.stdout
