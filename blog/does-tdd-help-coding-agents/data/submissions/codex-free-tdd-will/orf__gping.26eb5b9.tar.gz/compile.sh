#!/bin/bash
set -euo pipefail
cp src/gping.py executable
chmod +x executable
