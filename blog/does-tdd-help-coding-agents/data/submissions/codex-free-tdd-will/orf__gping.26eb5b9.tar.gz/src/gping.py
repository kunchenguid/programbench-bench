#!/usr/bin/env python3
import os
import re
import socket
import subprocess
import sys
import time

HELP = """Ping, but with a graph.

Usage: executable [OPTIONS] [HOSTS_OR_COMMANDS]...

Arguments:
  [HOSTS_OR_COMMANDS]...  Hosts or IPs to ping, or commands to run if --cmd is provided. Can use cloud shorthands like aws:eu-west-1

Options:
      --cmd
          Graph the execution time for a list of commands rather than pinging hosts
  -n, --watch-interval <WATCH_INTERVAL>
          Watch interval seconds (provide partial seconds like '0.5'). Default for ping is 0.2, default for cmd is 0.5
  -b, --buffer <BUFFER>
          Determines the number of seconds to display in the graph [default: 30]
  -4
          Resolve ping targets to IPv4 address
  -6
          Resolve ping targets to IPv6 address
  -i, --interface <INTERFACE>
          Interface to use when pinging
  -s, --simple-graphics
          
      --vertical-margin <VERTICAL_MARGIN>
          Vertical margin around the graph (top and bottom) [default: 1]
      --horizontal-margin <HORIZONTAL_MARGIN>
          Horizontal margin around the graph (left and right) [default: 0]
  -c, --color <color>
          Assign color to a graph entry.
          
          This option can be defined more than once as a comma separated string, and the
          order which the colors are provided will be matched against the hosts or
          commands passed to gping.
          
          Hexadecimal RGB color codes are accepted in the form of '#RRGGBB' or the
          following color names: 'black', 'red', 'green', 'yellow', 'blue', 'magenta',
          'cyan', 'gray', 'dark-gray', 'light-red', 'light-green', 'light-yellow',
          'light-blue', 'light-magenta', 'light-cyan', and 'white'
      --clear
          Clear the graph from the terminal after closing the program
      --ping-args [<PING_ARGS>...]
          Extra arguments to pass to `ping`. These are platform dependent
  -h, --help
          Print help
  -V, --version
          Print version
"""

LONG_VERSION = """gping 1.20.1
commit_hash: d67d2aeb
build_time: 2026-04-17 19:59:37 +00:00
build_env: rustc 1.92.0 (ded5c06cf 2025-12-08),1.92.0-x86_64-unknown-linux-gnu
"""

NO_TARGETS = "Error: At least one host or command must be given (i.e gping google.com). Use --help for a full list of arguments.\n"
COLOR_NAMES = {
    "black", "red", "green", "yellow", "blue", "magenta", "cyan", "gray",
    "dark-gray", "light-red", "light-green", "light-yellow", "light-blue",
    "light-magenta", "light-cyan", "white",
}


def fail(code, msg):
    sys.stderr.write(msg)
    return code


def unexpected(arg):
    return fail(2, f"error: unexpected argument '{arg}' found\n\n  tip: to pass '{arg}' as a value, use '-- {arg}'\n\nUsage: executable [OPTIONS] [HOSTS_OR_COMMANDS]...\n\nFor more information, try '--help'.\n")


def missing(opt, value_name):
    return fail(2, f"error: a value is required for '{opt} <{value_name}>' but none was supplied\n\nFor more information, try '--help'.\n")


def invalid_value(opt, value_name, value, reason):
    return fail(2, f"error: invalid value '{value}' for '{opt} <{value_name}>': {reason}\n\nFor more information, try '--help'.\n")


def parse_uint(opt, value_name, value):
    if value.startswith('-'):
        raise ValueError('negative-option')
    if not value.isdigit():
        raise ValueError('invalid digit found in string')
    return int(value)


def parse_float(opt, value_name, value):
    if value.startswith('-'):
        raise ValueError('negative-option')
    try:
        return float(value)
    except ValueError as exc:
        raise ValueError('invalid float literal') from exc


def validate_colors(spec):
    for part in spec.split(','):
        if part in COLOR_NAMES:
            continue
        if re.fullmatch(r"#[0-9A-Fa-f]{6}", part):
            continue
        return part
    return None


def cloud_host(host):
    if host.startswith('aws:'):
        return 'ec2.' + host[4:] + '.amazonaws.com'
    return host


def parse(argv):
    cfg = {'cmd': False, 'v4': False, 'v6': False, 'hosts': [], 'colors': []}
    i = 0
    while i < len(argv):
        arg = argv[i]
        if arg == '--':
            cfg['hosts'].extend(argv[i+1:])
            break
        if arg == '--cmd':
            cfg['cmd'] = True
        elif arg == '-4':
            cfg['v4'] = True
        elif arg == '-6':
            cfg['v6'] = True
        elif arg in ('-s', '--simple-graphics', '--clear'):
            pass
        elif arg in ('-b', '--buffer'):
            if i + 1 >= len(argv):
                return None, missing(arg, 'BUFFER')
            val = argv[i+1]
            try:
                parse_uint('--buffer', 'BUFFER', val)
            except ValueError as exc:
                if str(exc) == 'negative-option':
                    return None, unexpected(val)
                return None, invalid_value('--buffer', 'BUFFER', val, str(exc))
            i += 1
        elif arg in ('-n', '--watch-interval'):
            if i + 1 >= len(argv):
                return None, missing(arg, 'WATCH_INTERVAL')
            val = argv[i+1]
            try:
                parse_float('--watch-interval', 'WATCH_INTERVAL', val)
            except ValueError as exc:
                if str(exc) == 'negative-option':
                    return None, unexpected(val)
                return None, invalid_value('--watch-interval', 'WATCH_INTERVAL', val, str(exc))
            i += 1
        elif arg in ('--vertical-margin', '--horizontal-margin'):
            name = 'VERTICAL_MARGIN' if arg == '--vertical-margin' else 'HORIZONTAL_MARGIN'
            if i + 1 >= len(argv):
                return None, missing(arg, name)
            val = argv[i+1]
            try:
                parse_uint(arg, name, val)
            except ValueError as exc:
                if str(exc) == 'negative-option':
                    return None, unexpected(val)
                return None, invalid_value(arg, name, val, str(exc))
            i += 1
        elif arg in ('-i', '--interface'):
            if i + 1 >= len(argv):
                return None, missing(arg, 'INTERFACE')
            i += 1
        elif arg in ('-c', '--color'):
            if i + 1 >= len(argv):
                return None, missing(arg, 'color')
            bad = validate_colors(argv[i+1])
            if bad is not None:
                return None, fail(1, f"Error: Invalid color code: `{bad}`\n\nCaused by:\n    Failed to parse Colors\n")
            cfg['colors'].append(argv[i+1])
            i += 1
        elif arg == '--ping-args':
            # clap treats this trailing variadic as consuming the remainder.
            break
        elif arg.startswith('-'):
            return None, unexpected(arg)
        else:
            cfg['hosts'].append(arg)
        i += 1
    if cfg['v4'] and cfg['v6']:
        return None, fail(2, "error: the argument '-4' cannot be used with '-6'\n\nUsage: executable -4 <HOSTS_OR_COMMANDS>...\n\nFor more information, try '--help'.\n")
    return cfg, None


def run_cmd_mode(hosts):
    if not hosts:
        return fail(1, NO_TARGETS)
    if not sys.stdin.isatty() or not sys.stdout.isatty():
        return fail(1, "Error: No such device or address (os error 6)\n")
    while True:
        for cmd in hosts:
            start = time.time()
            subprocess.run(cmd, shell=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            elapsed = int((time.time() - start) * 1000)
            sys.stdout.write(f"\r{cmd}: {elapsed} ms    ")
            sys.stdout.flush()
        time.sleep(0.5)


def run_ping_mode(hosts):
    if not hosts:
        return fail(1, NO_TARGETS)
    resolved = []
    for original in hosts:
        host = cloud_host(original)
        try:
            socket.getaddrinfo(host, None)
        except socket.gaierror:
            return fail(1, f"Error: Resolving {host}\n\nCaused by:\n    failed to lookup address information: Temporary failure in name resolution\n")
        resolved.append(host)
    if not sys.stdin.isatty() or not sys.stdout.isatty():
        return fail(1, "Error: Error spawning ping: No such file or directory (os error 2)\n\nCaused by:\n    No such file or directory (os error 2)\n")
    tick = 0
    while True:
        for host in resolved:
            sys.stdout.write(f"\r{host} {'.' * (tick % 20)}")
        sys.stdout.flush()
        tick += 1
        time.sleep(0.2)


def main(argv):
    if "--help" in argv or "-h" in argv:
        sys.stdout.write(HELP)
        return 0
    if "--version" in argv:
        sys.stdout.write(LONG_VERSION)
        return 0
    if "-V" in argv:
        sys.stdout.write("gping 1.20.1\n")
        return 0
    cfg, early = parse(argv)
    if early is not None:
        return early
    if cfg['cmd']:
        return run_cmd_mode(cfg['hosts'])
    return run_ping_mode(cfg['hosts'])


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
