#!/bin/bash
set -e
rm -f executable
cp src/svd2rust_reimpl.py executable
chmod +x executable
