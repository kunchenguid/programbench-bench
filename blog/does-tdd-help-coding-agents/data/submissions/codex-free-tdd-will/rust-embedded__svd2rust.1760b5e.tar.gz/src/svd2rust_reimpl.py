#!/usr/bin/env python3
import argparse
import copy
import os
import re
import sys
import xml.etree.ElementTree as ET
from pathlib import Path

VERSION = "svd2rust 0.37.1 (e29353d 2026-03-03)"

HELP_LONG = """Generate a Rust API from SVD files

Usage: executable [OPTIONS]

Options:
  -i <FILE>
          Input SVD file

  -o, --output-dir <PATH>
          Directory to place generated files

  -c, --config <TOML_FILE>
          Config TOML file

      --settings <YAML_FILE>
          Target-specific settings YAML file

      --edition <YEAR>
          Rust edition of generated code

      --target <ARCH>
          Target architecture

      --atomics
          Generate atomic register modification API

      --atomics-feature <FEATURE>
          add feature gating for atomic register modification API

      --ignore-groups
          Don't add alternateGroup name as prefix to register name

      --keep-list
          Keep lists when generating code of dimElement, instead of trying to generate arrays

  -g, --generic-mod
          Push generic mod in separate file

      --feature-group
          Use group_name of peripherals as feature

      --feature-peripheral
          Use independent cfg feature flags for each peripheral

  -f, --ident-format <ident_format>
          Specify `-f type:prefix:case:suffix` to change default ident formatting.
          Allowed values of `type` are ["enum_value_accessor", "field_reader", "enum_read_name", "peripheral_singleton", "peripheral_spec", "interrupt", "register_accessor", "peripheral", "enum_name", "enum_value", "cluster_mod", "register", "cluster", "enum_write_name", "register_spec", "field_accessor", "peripheral_mod", "peripheral_feature", "field_writer", "cluster_accessor", "register_mod"].
          Allowed cases are `unchanged` (''), `pascal` ('p'), `constant` ('c') and `snake` ('s').
          

      --ident-formats-theme <THEME>
          A set of `ident_format` settings. `new` or `legacy`

      --field-names-for-enums
          Use field name for enumerations even when enumeratedValues has a name

      --max-cluster-size
          Use array increment for cluster size

      --impl-debug
          implement Debug for readable blocks and registers

      --impl-debug-feature <FEATURE>
          Add feature gating for block and register debug implementation

      --impl-defmt <FEATURE>
          Add automatic defmt implementation for enumerated values

  -m, --make-mod
          Create mod.rs instead of lib.rs, without inner attributes

      --skip-crate-attributes
          Do not generate crate attributes

  -s, --strict
          Make advanced checks due to parsing SVD

      --source-type <source_type>
          Specify file/stream format

      --reexport-core-peripherals
          For Cortex-M target reexport peripherals from cortex-m crate

      --reexport-interrupt
          Reexport interrupt macro from cortex-m-rt like crates

  -b, --base-address-shift <base_address_shift>
          Add offset to all base addresses on all peripherals in the SVD file.
          Useful for soft-cores where the peripheral address range isn't necessarily fixed.
          Ignore this option if you are not building your own FPGA based soft-cores.

  -l, --log <log_level>
          Choose which messages to log (overrides RUST_LOG)
          
          [possible values: off, error, warn, info, debug, trace]

  -h, --help
          Print help (see a summary with '-h')

  -V, --version
          Print version
"""

GENERIC = r'''#[allow (unused_imports)] use generic :: * ;
#[doc = r"Common register and bit access and modify traits"] pub mod generic { use core :: marker ;
pub struct Periph < PER : PeripheralSpec > { _marker : marker :: PhantomData < PER > , }
pub trait PeripheralSpec { type RB ; const ADDRESS : usize ; const NAME : & 'static str ; }
unsafe impl < PER : PeripheralSpec > Send for Periph < PER > { }
impl < PER : PeripheralSpec > Periph < PER > { pub const PTR : * const PER :: RB = PER :: ADDRESS as * const _ ; #[inline (always)] pub const fn ptr () -> * const PER :: RB { Self :: PTR } pub unsafe fn steal () -> Self { Self { _marker : marker :: PhantomData , } } }
impl < PER : PeripheralSpec > core :: ops :: Deref for Periph < PER > { type Target = PER :: RB ; #[inline (always)] fn deref (& self) -> & Self :: Target { unsafe { & * Self :: PTR } } }
pub trait RawReg : Copy + From < bool > + core :: ops :: BitOr < Output = Self > + core :: ops :: BitAnd < Output = Self > + core :: ops :: BitOrAssign + core :: ops :: BitAndAssign + core :: ops :: Not < Output = Self > + core :: ops :: Shl < u8 , Output = Self > { fn mask < const WI : u8 > () -> Self ; const ZERO : Self ; const ONE : Self ; }
macro_rules ! raw_reg { ($ U : ty , $ size : literal , $ mask : ident) => { impl RawReg for $ U { fn mask < const WI : u8 > () -> Self { <$ U >:: MAX >> ($ size - WI) } const ZERO : Self = 0 ; const ONE : Self = 1 ; } impl FieldSpec for $ U { type Ux = $ U ; } } ; } raw_reg ! (u8 , 8 , mask_u8) ; raw_reg ! (u16 , 16 , mask_u16) ; raw_reg ! (u32 , 32 , mask_u32) ; raw_reg ! (u64 , 64 , mask_u64) ;
pub trait RegisterSpec { type Ux : RawReg ; } pub trait FieldSpec : Sized { type Ux : Copy + core :: fmt :: Debug + PartialEq + From < Self > ; } pub trait IsEnum : FieldSpec { }
pub trait Readable : RegisterSpec { } pub trait Writable : RegisterSpec { type Safety ; const ZERO_TO_MODIFY_FIELDS_BITMAP : Self :: Ux = Self :: Ux :: ZERO ; const ONE_TO_MODIFY_FIELDS_BITMAP : Self :: Ux = Self :: Ux :: ZERO ; } pub trait Resettable : RegisterSpec { const RESET_VALUE : Self :: Ux = Self :: Ux :: ZERO ; fn reset_value () -> Self :: Ux { Self :: RESET_VALUE } }
pub mod raw { use super :: marker ; pub struct R < REG : super :: RegisterSpec > { pub (crate) bits : REG :: Ux , pub (super) _reg : marker :: PhantomData < REG > , } pub struct W < REG : super :: RegisterSpec > { pub (crate) bits : REG :: Ux , pub (super) _reg : marker :: PhantomData < REG > , } pub struct FieldReader < FI = u8 > where FI : super :: FieldSpec , { pub (crate) bits : FI :: Ux , _reg : marker :: PhantomData < FI > , } impl < FI : super :: FieldSpec > FieldReader < FI > { pub (crate) const fn new (bits : FI :: Ux) -> Self { Self { bits , _reg : marker :: PhantomData , } } } pub struct BitReader < FI = bool > { pub (crate) bits : bool , _reg : marker :: PhantomData < FI > , } impl < FI > BitReader < FI > { pub (crate) const fn new (bits : bool) -> Self { Self { bits , _reg : marker :: PhantomData , } } } pub struct FieldWriter < 'a , REG , const WI : u8 , FI = u8 , Safety = super :: Unsafe > where REG : super :: Writable + super :: RegisterSpec , FI : super :: FieldSpec , { pub (crate) w : & 'a mut super :: W < REG > , pub (crate) o : u8 , _field : marker :: PhantomData < (FI , Safety) > , } impl < 'a , REG , const WI : u8 , FI , Safety > FieldWriter < 'a , REG , WI , FI , Safety > where REG : super :: Writable + super :: RegisterSpec , FI : super :: FieldSpec , { pub (crate) fn new (w : & 'a mut super :: W < REG > , o : u8) -> Self { Self { w , o , _field : marker :: PhantomData , } } } pub struct BitWriter < 'a , REG , FI = bool > where REG : super :: Writable + super :: RegisterSpec , bool : From < FI > , { pub (crate) w : & 'a mut super :: W < REG > , pub (crate) o : u8 , _field : marker :: PhantomData < FI > , } impl < 'a , REG , FI > BitWriter < 'a , REG , FI > where REG : super :: Writable + super :: RegisterSpec , bool : From < FI > , { pub (crate) fn new (w : & 'a mut super :: W < REG > , o : u8) -> Self { Self { w , o , _field : marker :: PhantomData , } } } }
pub type R < REG > = raw :: R < REG > ; impl < REG : RegisterSpec > R < REG > { pub const fn bits (& self) -> REG :: Ux { self . bits } }
pub type W < REG > = raw :: W < REG > ; impl < REG : Writable > W < REG > { pub unsafe fn bits (& mut self , bits : REG :: Ux) -> & mut Self { self . bits = bits ; self } }
pub type FieldReader < FI = u8 > = raw :: FieldReader < FI > ; pub type BitReader < FI = bool > = raw :: BitReader < FI > ; impl < FI : FieldSpec > FieldReader < FI > { pub const fn bits (& self) -> FI :: Ux { self . bits } } impl < FI > BitReader < FI > { pub const fn bit (& self) -> bool { self . bits } pub const fn bit_is_clear (& self) -> bool { ! self . bit () } pub const fn bit_is_set (& self) -> bool { self . bit () } }
pub struct Safe ; pub struct Unsafe ; pub struct Range < const MIN : u64 , const MAX : u64 > ; pub struct RangeFrom < const MIN : u64 > ; pub struct RangeTo < const MAX : u64 > ;
pub type FieldWriter < 'a , REG , const WI : u8 , FI = u8 , Safety = Unsafe > = raw :: FieldWriter < 'a , REG , WI , FI , Safety > ; impl < 'a , REG , const WI : u8 , FI , Safety > FieldWriter < 'a , REG , WI , FI , Safety > where REG : Writable + RegisterSpec , FI : FieldSpec , REG :: Ux : From < FI :: Ux > , { pub unsafe fn bits (self , value : FI :: Ux) -> & 'a mut W < REG > { self . w . bits &= ! (REG :: Ux :: mask :: < WI > () << self . o) ; self . w . bits |= (REG :: Ux :: from (value) & REG :: Ux :: mask :: < WI > ()) << self . o ; self . w } }
pub type BitWriter < 'a , REG , FI = bool > = raw :: BitWriter < 'a , REG , FI > ; impl < 'a , REG , FI > BitWriter < 'a , REG , FI > where REG : Writable + RegisterSpec , bool : From < FI > , { pub fn bit (self , value : bool) -> & 'a mut W < REG > { self . w } pub fn set_bit (self) -> & 'a mut W < REG > { self . w } pub fn clear_bit (self) -> & 'a mut W < REG > { self . w } }
#[repr (transparent)] pub struct Reg < REG : RegisterSpec > { register : REG :: Ux , _marker : marker :: PhantomData < REG > , } impl < REG : RegisterSpec > Reg < REG > { pub fn read (& self) -> R < REG > { R { bits : self . register , _reg : marker :: PhantomData , } } } }
'''

BUILD_RS = '# ! [doc = r" Builder file for Peripheral access crate generated by svd2rust tool"] use std :: env ; use std :: fs :: File ; use std :: io :: Write ; use std :: path :: PathBuf ; fn main () { if env :: var_os ("CARGO_FEATURE_RT") . is_some () { let out = & PathBuf :: from (env :: var_os ("OUT_DIR") . unwrap ()) ; File :: create (out . join ("device.x")) . unwrap () . write_all (include_bytes ! ("device.x")) . unwrap () ; println ! ("cargo:rustc-link-search={}" , out . display ()) ; println ! ("cargo:rerun-if-changed=device.x") ; } println ! ("cargo:rerun-if-changed=build.rs") ; }\n'

def text(elem, name, default=""):
    child = elem.find(name)
    return (child.text or "").strip() if child is not None and child.text is not None else default

def parse_int(s, default=0):
    if s is None or str(s).strip() == "":
        return default
    s = str(s).strip().replace("_", "")
    return int(s, 16) if s.lower().startswith("0x") else int(s, 10)

def words(name):
    parts = re.split(r"[^A-Za-z0-9]+", name.strip())
    out = []
    for p in parts:
        if not p: continue
        sub = re.findall(r"[A-Z]+(?=[A-Z][a-z]|\d|$)|[A-Z]?[a-z]+|\d+", p)
        out.extend(sub or [p])
    return out or ["x"]

def snake(name): return "_".join(w.lower() for w in words(name))
def pascal(name): return "".join(w[:1].upper() + w[1:].lower() for w in words(name))
def const_name(name): return "_".join(w.upper() for w in words(name))

def rust_hex(n):
    h = f"{n:x}"
    pad = (4 - len(h) % 4) % 4
    h = "0" * pad + h
    return "0x" + "_".join(h[i:i+4] for i in range(0, len(h), 4))

def doc(s):
    return (s or "").replace('"', '\\"').replace('\n', ' ')

def bit_range(field):
    if field.find("bitOffset") is not None:
        off = parse_int(text(field, "bitOffset")); width = parse_int(text(field, "bitWidth"), 1)
        return off, width
    if field.find("lsb") is not None and field.find("msb") is not None:
        lsb = parse_int(text(field, "lsb")); msb = parse_int(text(field, "msb")); return lsb, msb-lsb+1
    br = text(field, "bitRange")
    m = re.match(r"\[(\d+)\s*:\s*(\d+)\]", br)
    if m:
        msb, lsb = int(m.group(1)), int(m.group(2)); return lsb, msb-lsb+1
    return 0, 1

def access_of(elem, parent="read-write"):
    return text(elem, "access", parent) or parent

def can_read(acc): return acc not in ("write-only",)
def can_write(acc): return acc not in ("read-only",)

def register_size(reg, dev_width):
    size = parse_int(text(reg, "size"), dev_width)
    if size <= 8: return "u8"
    if size <= 16: return "u16"
    if size <= 32: return "u32"
    return "u64"

def child_registers(periph):
    regs = periph.find("registers")
    return [] if regs is None else [r for r in regs.findall("register")]

def merge_missing(dst, src):
    existing = {child.tag for child in dst}
    for child in src:
        if child.tag not in existing:
            dst.append(copy.deepcopy(child))
    for k, v in src.attrib.items():
        dst.attrib.setdefault(k, v)

def resolve_derived(root):
    periphs = root.findall("./peripherals/peripheral")
    by_name = {text(p, "name"): p for p in periphs}
    for p in periphs:
        ref = p.attrib.get("derivedFrom")
        if ref and ref in by_name:
            merge_missing(p, by_name[ref])
    for p in periphs:
        regs = expanded_registers(p)
        by_reg = {text(r, "name"): r for r in regs}
        for r in regs:
            ref = r.attrib.get("derivedFrom")
            if ref and ref in by_reg:
                merge_missing(r, by_reg[ref])

def expand_dim_name(name, index):
    if "%s" in name:
        return name.replace("%s", str(index))
    if "[%s]" in name:
        return name.replace("[%s]", str(index))
    return f"{name}{index}"

def expanded_registers(periph):
    out = []
    for reg in child_registers(periph):
        dim = parse_int(text(reg, "dim"), 0)
        if dim <= 1:
            out.append(reg)
            continue
        inc = parse_int(text(reg, "dimIncrement"), max(parse_int(text(reg, "size"), 32)//8, 1))
        base_offset = parse_int(text(reg, "addressOffset"), 0)
        indexes = text(reg, "dimIndex")
        if indexes:
            vals = [x.strip() for part in indexes.split(',') for x in (part.split('-') if '-' not in part else range(int(part.split('-')[0]), int(part.split('-')[1])+1))]
            vals = vals[:dim]
        else:
            vals = list(range(dim))
        for i, idx in enumerate(vals):
            nr = copy.deepcopy(reg)
            nr.find("name").text = expand_dim_name(text(reg, "name"), idx)
            nr.find("addressOffset").text = hex(base_offset + i * inc)
            for tag in ("dim", "dimIncrement", "dimIndex"):
                ch = nr.find(tag)
                if ch is not None:
                    nr.remove(ch)
            out.append(nr)
    return out

def render_interrupts(root):
    ints = []
    for p in root.findall("./peripherals/peripheral"):
        for intr in p.findall("interrupt"):
            name = pascal(text(intr, "name", "Interrupt"))
            val = parse_int(text(intr, "value"), len(ints))
            desc = text(intr, "description")
            ints.append((name, val, desc))
    enum_body = " ".join((f'#[doc = "{doc(d)}"] ' if d else "") + f"{n} = {v} ," for n,v,d in ints)
    match_body = " ".join(f"Interrupt :: {n} => {v} ," for n,v,_ in ints)
    return f'''pub mod cortex_m {{ pub mod interrupt {{ pub unsafe trait InterruptNumber {{ fn number (self) -> u16 ; }} }} }}
#[cfg (feature = "rt")] extern "C" {{ }}
#[doc (hidden)] #[repr (C)] pub union Vector {{ _handler : unsafe extern "C" fn () , _reserved : u32 , }}
#[cfg (feature = "rt")] #[doc (hidden)] #[link_section = ".vector_table.interrupts"] #[no_mangle] pub static __INTERRUPTS : [Vector ; {len(ints)}] = [ {" ".join("Vector { _reserved : 0 } ," for _ in ints)} ] ;
#[doc = r"Enumeration of all the interrupts."] #[derive (Copy , Clone , Debug , PartialEq , Eq)] pub enum Interrupt {{ {enum_body} }} unsafe impl cortex_m :: interrupt :: InterruptNumber for Interrupt {{ #[inline (always)] fn number (self) -> u16 {{ match self {{ {match_body} }} }} }}
'''

def render_register_module(reg, dev_width, parent_access):
    rname = text(reg, "name", "REG")
    mod = snake(rname); spec = pascal(rname) + "Spec"; desc = text(reg, "description")
    acc = access_of(reg, parent_access); ux = register_size(reg, dev_width)
    fields = reg.find("fields")
    field_elems = [] if fields is None else fields.findall("field")
    s = [f'#[doc = "Register `{doc(rname)}` reader"] pub type R = crate :: R < {spec} > ;']
    if can_write(acc): s.append(f'#[doc = "Register `{doc(rname)}` writer"] pub type W = crate :: W < {spec} > ;')
    for f in field_elems:
        fname = text(f, "name", "FIELD"); ty = pascal(fname); fd = text(f, "description")
        off,width = bit_range(f)
        if width == 1:
            s.append(f'#[doc = "Field `{doc(fname)}` reader - {doc(fd)}"] pub type {ty}R = crate :: BitReader ;')
            if can_write(access_of(f, acc)): s.append(f'#[doc = "Field `{doc(fname)}` writer - {doc(fd)}"] pub type {ty}W < \'a , REG > = crate :: BitWriter < \'a , REG > ;')
        else:
            s.append(f'#[doc = "Field `{doc(fname)}` reader - {doc(fd)}"] pub type {ty}R = crate :: FieldReader ;')
            if can_write(access_of(f, acc)): s.append(f'#[doc = "Field `{doc(fname)}` writer - {doc(fd)}"] pub type {ty}W < \'a , REG > = crate :: FieldWriter < \'a , REG , {width} > ;')
    if field_elems and can_read(acc):
        s.append("impl R {")
        for f in field_elems:
            fname = text(f, "name", "FIELD"); fn = snake(fname); ty = pascal(fname); fd = text(f, "description")
            off,width = bit_range(f); range_doc = f"Bit {off}" if width == 1 else f"Bits {off}:{off+width-1}"
            s.append(f'#[doc = "{range_doc}{(" - " + doc(fd)) if fd else ""}"] #[inline (always)] pub fn {fn} (& self) -> {ty}R {{')
            if width == 1: s.append(f'{ty}R :: new ((self . bits & {1<<off}) != 0) }}')
            else: s.append(f'{ty}R :: new (((self . bits >> {off}) & {(1<<width)-1}) as u8) }}')
        s.append("}")
    if field_elems and can_write(acc):
        s.append("impl W {")
        for f in field_elems:
            if not can_write(access_of(f, acc)): continue
            fname = text(f, "name", "FIELD"); fn = snake(fname); ty = pascal(fname); fd = text(f, "description")
            off,width = bit_range(f); range_doc = f"Bit {off}" if width == 1 else f"Bits {off}:{off+width-1}"
            s.append(f'#[doc = "{range_doc}{(" - " + doc(fd)) if fd else ""}"] #[inline (always)] pub fn {fn} (& mut self) -> {ty}W < \'_ , {spec} > {{ {ty}W :: new (self , {off}) }}')
        s.append("}")
    s.append(f'#[doc = "{doc(desc)}"] pub struct {spec} ; impl crate :: RegisterSpec for {spec} {{ type Ux = {ux} ; }}')
    if can_read(acc): s.append(f'impl crate :: Readable for {spec} {{ }}')
    if can_write(acc): s.append(f'impl crate :: Writable for {spec} {{ type Safety = crate :: Unsafe ; }}')
    rv = parse_int(text(reg, "resetValue"), None) if text(reg, "resetValue", None) is not None else None
    if rv is None or rv == 0: s.append(f'impl crate :: Resettable for {spec} {{ }}')
    else: s.append(f'impl crate :: Resettable for {spec} {{ const RESET_VALUE : Self :: Ux = {rust_hex(rv)} ; }}')
    return f'#[doc = "{doc(desc)}"] pub mod {mod} {{ ' + " ".join(s) + " }"

def render_peripheral(p, dev_width, base_shift):
    pname = text(p, "name", "PERIPH"); pmod = snake(pname); pty = pascal(pname); pspec = pty + "Spec"; desc = text(p, "description")
    base = parse_int(text(p, "baseAddress"), 0) + base_shift
    regs = expanded_registers(p)
    out = [f'#[doc = "{doc(desc)}"] pub type {pty} = crate :: Periph < {pspec} > ; pub struct {pspec} ; impl crate :: PeripheralSpec for {pspec} {{ type RB = {pmod} :: RegisterBlock ; const ADDRESS : usize = {rust_hex(base)} ; const NAME : & \'static str = "{pty}" ; }}']
    out.append(f'#[doc = "{doc(desc)}"] pub mod {pmod} {{')
    fields = []
    methods = []
    modules = []
    cur = 0
    for reg in regs:
        rname = text(reg, "name", "REG"); rmod = snake(rname); rty = pascal(rname); offset = parse_int(text(reg, "addressOffset"), cur)
        if offset > cur:
            fields.append(f'_reserved{len(fields)} : [u8 ; {offset-cur}] ,')
        fields.append(f'{rmod} : {rty} ,')
        cur = offset + max(parse_int(text(reg, "size"), dev_width)//8, 1)
        desc_r = text(reg, "description")
        methods.append(f'#[doc = "{rust_hex(offset)} - {doc(desc_r)}"] #[inline (always)] pub const fn {rmod} (& self) -> & {rty} {{ & self . {rmod} }}')
        acc = access_of(reg, access_of(p, "read-write")); rw = "rw" if can_read(acc) and can_write(acc) else ("r" if can_read(acc) else "w")
        methods.append("")
        out.append(f'#[doc = "{doc(rname)} ({rw}) register accessor: {doc(desc_r)}"] #[doc (alias = "{doc(rname)}")] pub type {rty} = crate :: Reg < {rmod} :: {rty}Spec > ;')
        modules.append(render_register_module(reg, dev_width, access_of(p, "read-write")))
    out.insert(2, f'#[repr (C)] #[doc = "Register block"] pub struct RegisterBlock {{ {" ".join(fields)} }} impl RegisterBlock {{ {" ".join(m for m in methods if m)} }}')
    out.extend(modules)
    out.append("}")
    return "\n".join(out)

def render(root, opts):
    name = text(root, "name", "device")
    dev_width = parse_int(text(root, "width"), 32)
    base_shift = parse_int(opts.base_address_shift, 0) if opts.base_address_shift else 0
    header = '' if opts.make_mod or opts.skip_crate_attributes else f'# ! [doc = "Peripheral access API for {doc(name)} microcontrollers (generated using svd2rust v0.37.1 (e29353d 2026-03-03))"] # ! [allow (non_camel_case_types)] # ! [allow (non_snake_case)] # ! [no_std]\n'
    parts = [header]
    if opts.generic_mod:
        parts.append('pub use generic :: * ; pub mod generic ;\n')
    else:
        parts.append(GENERIC)
    parts.append(render_interrupts(root))
    periphs = root.findall("./peripherals/peripheral")
    for p in periphs:
        parts.append(render_peripheral(p, dev_width, base_shift))
    fields = " ".join(f'#[doc = "{doc(text(p, "name"))}"] pub {snake(text(p,"name"))} : {pascal(text(p,"name"))} ,' for p in periphs)
    steals = " ".join(f'{snake(text(p,"name"))} : {pascal(text(p,"name"))} :: steal () ,' for p in periphs)
    parts.append(f'#[no_mangle] static mut DEVICE_PERIPHERALS : bool = false ; #[doc = r" All the peripherals."] #[allow (non_snake_case)] pub struct Peripherals {{ {fields} }} impl Peripherals {{ #[inline] pub unsafe fn steal () -> Self {{ DEVICE_PERIPHERALS = true ; Peripherals {{ {steals} }} }} }}')
    return "\n".join(parts)

def parse_args(argv):
    if "--help" in argv or "-h" in argv:
        print(HELP_LONG if "--help" in argv else HELP_LONG.replace('\n\n', '\n'))
        sys.exit(0)
    if "--version" in argv or "-V" in argv:
        print(VERSION); sys.exit(0)
    p = argparse.ArgumentParser(add_help=False, prog="executable")
    p.add_argument("-i", dest="input")
    p.add_argument("positional_input", nargs="?")
    p.add_argument("-o", "--output-dir", default=".")
    p.add_argument("-m", "--make-mod", action="store_true")
    p.add_argument("-g", "--generic-mod", action="store_true")
    p.add_argument("--skip-crate-attributes", action="store_true")
    p.add_argument("-b", "--base-address-shift")
    # Accepted but ignored compatibility flags.
    for opt in ["-c", "--config", "--settings", "--edition", "--target", "--atomics-feature", "--ident-formats-theme", "--impl-debug-feature", "--impl-defmt", "--source-type", "-l", "--log", "-f", "--ident-format"]:
        p.add_argument(opt, dest=re.sub(r"\W+", "_", opt), action="append")
    for opt in ["--atomics", "--ignore-groups", "--keep-list", "--feature-group", "--feature-peripheral", "--field-names-for-enums", "--max-cluster-size", "--impl-debug", "-s", "--strict", "--reexport-core-peripherals", "--reexport-interrupt"]:
        p.add_argument(opt, action="store_true")
    ns = p.parse_args(argv)
    if not ns.input and ns.positional_input:
        ns.input = ns.positional_input
    return ns

def main(argv=None):
    opts = parse_args(sys.argv[1:] if argv is None else argv)
    print("[INFO  svd2rust] Parsing device from SVD file", file=sys.stderr)
    try:
        data = Path(opts.input).read_text() if opts.input else sys.stdin.read()
    except OSError as e:
        print("[ERROR svd2rust] Cannot open the SVD file\n    \n    Caused by:\n        " + str(e), file=sys.stderr); return 1
    try:
        root = ET.fromstring(data)
        resolve_derived(root)
    except Exception as e:
        print("[ERROR svd2rust] Error parsing SVD XML file\n    \n    Caused by:\n        " + str(e), file=sys.stderr); return 1
    print("[INFO  svd2rust] Rendering device", file=sys.stderr)
    outdir = Path(opts.output_dir)
    if not outdir.is_dir():
        print("[ERROR svd2rust] Error rendering device\n    \n    Caused by:\n        No such file or directory (os error 2)", file=sys.stderr); return 1
    libname = "mod.rs" if opts.make_mod else "lib.rs"
    try:
        (outdir / libname).write_text(render(root, opts))
        (outdir / "build.rs").write_text(BUILD_RS)
        (outdir / "device.x").write_text("\n")
        if opts.generic_mod:
            (outdir / "generic.rs").write_text(GENERIC)
    except OSError as e:
        print("[ERROR svd2rust] Error rendering device\n    \n    Caused by:\n        " + str(e), file=sys.stderr); return 1
    return 0

if __name__ == "__main__":
    sys.exit(main())
