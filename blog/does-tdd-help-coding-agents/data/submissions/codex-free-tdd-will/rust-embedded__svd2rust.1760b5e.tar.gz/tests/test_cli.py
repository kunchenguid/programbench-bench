import shutil
import subprocess
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
BIN = ROOT / "executable"

MIN_SVD = '''\
<?xml version="1.0" encoding="UTF-8"?>
<device>
  <name>TEST</name>
  <version>1.0</version>
  <description>Test device</description>
  <addressUnitBits>8</addressUnitBits>
  <width>32</width>
  <peripherals>
    <peripheral>
      <name>GPIOA</name>
      <description>General purpose I/O</description>
      <baseAddress>0x40000000</baseAddress>
      <registers>
        <register>
          <name>CTRL</name>
          <description>Control register</description>
          <addressOffset>0x00</addressOffset>
          <size>32</size>
          <access>read-write</access>
          <resetValue>0x00000000</resetValue>
          <fields>
            <field><name>EN</name><description>Enable bit</description><bitOffset>0</bitOffset><bitWidth>1</bitWidth></field>
            <field><name>MODE</name><bitOffset>1</bitOffset><bitWidth>2</bitWidth></field>
          </fields>
        </register>
      </registers>
    </peripheral>
  </peripherals>
</device>
'''

class CliTests(unittest.TestCase):
    def run_cmd(self, args, cwd, input_text=None):
        return subprocess.run([str(BIN), *args], cwd=cwd, input=input_text, text=True,
                              stdout=subprocess.PIPE, stderr=subprocess.PIPE)

    def test_minimal_svd_generates_core_rust_api(self):
        with tempfile.TemporaryDirectory() as td:
            tmp = Path(td)
            svd = tmp / "min.svd"
            out = tmp / "out"
            out.mkdir()
            svd.write_text(MIN_SVD)

            result = self.run_cmd(["-i", str(svd), "-o", str(out)], cwd=tmp)

            self.assertEqual(result.returncode, 0, result.stderr)
            lib = (out / "lib.rs").read_text()
            self.assertTrue((out / "build.rs").exists())
            self.assertTrue((out / "device.x").exists())
            self.assertIn("Peripheral access API for TEST microcontrollers", lib)
            self.assertIn("pub type Gpioa = crate :: Periph < GpioaSpec >", lib)
            self.assertIn("const ADDRESS : usize = 0x4000_0000", lib)
            self.assertIn("pub mod gpioa", lib)
            self.assertIn("pub struct RegisterBlock { ctrl : Ctrl , }", lib)
            self.assertIn("pub type Ctrl = crate :: Reg < ctrl :: CtrlSpec >", lib)
            self.assertIn("pub type EnR = crate :: BitReader", lib)
            self.assertIn("pub fn en (& self) -> EnR", lib)
            self.assertIn("pub type ModeW < 'a , REG > = crate :: FieldWriter < 'a , REG , 2 >", lib)

    def test_generated_lib_compiles_as_rust_library(self):
        with tempfile.TemporaryDirectory() as td:
            tmp = Path(td)
            svd = tmp / "min.svd"
            out = tmp / "out"
            out.mkdir()
            svd.write_text(MIN_SVD)

            result = self.run_cmd(["-i", str(svd), "-o", str(out)], cwd=tmp)
            self.assertEqual(result.returncode, 0, result.stderr)
            if shutil.which("rustc") is None:
                self.skipTest("rustc is not available on this host")
            rustc = subprocess.run(["rustc", "--crate-type", "lib", "--edition", "2021", str(out / "lib.rs")],
                                   cwd=tmp, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
            self.assertEqual(rustc.returncode, 0, rustc.stderr)

    def test_cli_modes_and_stdin(self):
        with tempfile.TemporaryDirectory() as td:
            tmp = Path(td)
            version = self.run_cmd(["--version"], cwd=tmp)
            self.assertEqual(version.returncode, 0)
            self.assertIn("svd2rust 0.37.1", version.stdout)

            help_result = self.run_cmd(["--help"], cwd=tmp)
            self.assertEqual(help_result.returncode, 0)
            self.assertIn("Generate a Rust API from SVD files", help_result.stdout)
            self.assertIn("--output-dir <PATH>", help_result.stdout)

            out = tmp / "stdin_out"
            out.mkdir()
            stdin_result = self.run_cmd(["-o", str(out), "-m", "-g", "-b", "0x1000"], cwd=tmp, input_text=MIN_SVD)
            self.assertEqual(stdin_result.returncode, 0, stdin_result.stderr)
            self.assertTrue((out / "mod.rs").exists())
            self.assertTrue((out / "generic.rs").exists())
            self.assertFalse((out / "lib.rs").exists())
            mod = (out / "mod.rs").read_text()
            self.assertIn("pub mod generic", mod)
            self.assertIn("const ADDRESS : usize = 0x4000_1000", mod)

    def test_readme_style_positional_input_is_accepted(self):
        with tempfile.TemporaryDirectory() as td:
            tmp = Path(td)
            svd = tmp / "min.svd"
            out = tmp / "out"
            out.mkdir()
            svd.write_text(MIN_SVD)
            result = self.run_cmd([str(svd), "-o", str(out)], cwd=tmp)
            self.assertEqual(result.returncode, 0, result.stderr)
            self.assertTrue((out / "lib.rs").exists())

if __name__ == "__main__":
    unittest.main()
