#!/bin/bash
set -e
cp src/diffr.py executable
chmod +x executable
