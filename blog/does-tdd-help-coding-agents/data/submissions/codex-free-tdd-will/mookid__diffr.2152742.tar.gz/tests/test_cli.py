import subprocess
import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
EXE = ROOT / "executable"


def run_cmd(args, data=b""):
    return subprocess.run(
        [str(EXE), *args],
        input=data,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        check=False,
    )


class DiffrCliTests(unittest.TestCase):
    def test_help_version_and_plain_stdin(self):
        subprocess.run(["bash", "compile.sh"], cwd=ROOT, check=True)

        version = run_cmd(["--version"])
        self.assertEqual(version.returncode, 0)
        self.assertEqual(version.stdout, b"diffr 0.1.5\n")
        self.assertEqual(version.stderr, b"")

        help_result = run_cmd(["--help"])
        self.assertEqual(help_result.returncode, 0)
        self.assertTrue(help_result.stdout.startswith(b"diffr 0.1.5\nNathan Moreau"))
        self.assertIn(b"--line-numbers <compact|aligned>", help_result.stdout)

        plain = run_cmd([], b"plain\ntext\n")
        self.assertEqual(plain.returncode, 0)
        self.assertEqual(plain.stdout, b"\x1b[0mplain\x1b[0m\n\x1b[0mtext\x1b[0m\n")
        self.assertEqual(plain.stderr, b"")

    def test_simple_unified_diff_gets_line_and_word_colors(self):
        subprocess.run(["bash", "compile.sh"], cwd=ROOT, check=True)
        data = (
            b"--- a/f\n+++ b/f\n@@ -1,3 +1,3 @@\n unchanged\n"
            b"-old foo bar\n+new foo baz\n context\n"
        )

        result = run_cmd([], data)

        self.assertEqual(result.returncode, 0)
        self.assertIn(b"\x1b[0m--- a/f\x1b[0m\n", result.stdout)
        self.assertIn(b"\x1b[31m-\x1b[0m", result.stdout)
        self.assertIn(b"\x1b[32m+\x1b[0m", result.stdout)
        self.assertIn(b"\x1b[1m\x1b[38;2;255;255;255m\x1b[41mold\x1b[0m", result.stdout)
        self.assertIn(b"\x1b[31m foo \x1b[0m", result.stdout)
        self.assertIn(b"\x1b[1m\x1b[38;2;255;255;255m\x1b[42mnew\x1b[0m", result.stdout)
        self.assertIn(b"\x1b[32m foo \x1b[0m", result.stdout)

    def test_line_numbers_compact_and_aligned(self):
        subprocess.run(["bash", "compile.sh"], cwd=ROOT, check=True)
        data = (
            b"--- a/f\n+++ b/f\n@@ -1,3 +1,3 @@\n unchanged\n"
            b"-old foo bar\n+new foo baz\n context\n"
        )

        compact = run_cmd(["--line-numbers"], data)
        aligned = run_cmd(["--line-numbers", "aligned"], data)

        self.assertEqual(compact.returncode, 0)
        self.assertIn(b"  1\x1b[0m unchanged", compact.stdout)
        self.assertIn(b"\x1b[31m2  \x1b[0m", compact.stdout)
        self.assertIn(b"\x1b[32m  2\x1b[0m", compact.stdout)
        self.assertIn(b"  3\x1b[0m context", compact.stdout)
        self.assertIn(b"  1\t\x1b[0m unchanged", aligned.stdout)

    def test_change_markers_outside_hunks_are_plain_and_colors_are_configurable(self):
        subprocess.run(["bash", "compile.sh"], cwd=ROOT, check=True)

        outside = run_cmd([], b"-abc\n+xyz\n")
        self.assertEqual(outside.stdout, b"\x1b[0m-abc\x1b[0m\n\x1b[0m+xyz\x1b[0m\n")

        data = b"@@ -1 +1 @@\n-abc\n+xyz\n"
        result = run_cmd(
            [
                "--colors",
                "removed:none",
                "--colors",
                "refine-added:foreground:1:background:2",
            ],
            data,
        )

        self.assertEqual(result.returncode, 0)
        self.assertIn(b"\x1b[0m-\x1b[0m", result.stdout)
        self.assertIn(b"\x1b[1m\x1b[38;5;1m\x1b[48;5;2mxyz\x1b[0m", result.stdout)


if __name__ == "__main__":
    unittest.main()
