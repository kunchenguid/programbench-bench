#!/usr/bin/env python3
import sys
import re
from difflib import SequenceMatcher


RESET = "\033[0m"
REMOVED = "\033[31m"
ADDED = "\033[32m"
REFINE_REMOVED = "\033[1m\033[38;2;255;255;255m\033[41m"
REFINE_ADDED = "\033[1m\033[38;2;255;255;255m\033[42m"
DEFAULT_FACES = {
    "removed": ["31"],
    "added": ["32"],
    "refine-removed": ["1", "38;2;255;255;255", "41"],
    "refine-added": ["1", "38;2;255;255;255", "42"],
}
NAMED_COLORS = {
    "black": 0,
    "red": 1,
    "green": 2,
    "yellow": 3,
    "blue": 4,
    "magenta": 5,
    "cyan": 6,
    "white": 7,
}
VERSION = "diffr 0.1.5"


FULL_HELP = """diffr 0.1.5
Nathan Moreau <nathan.moreau@m4x.org>

diffr adds word-level diff on top of unified diffs.
word-level diff information is displayed using text attributes.

USAGE:
    diffr reads from standard input and writes to standard output.

    Typical usage is for interactive use of diff:
    diff -u <file1> <file2> | diffr
    git show | diffr

OPTIONS:
        --colors <COLOR_SPEC>...
            Configure color settings for console ouput.

            There are four faces to customize:
            +----------------+--------------+----------------+
            |  line prefix   |      +       |       -        |
            +----------------+--------------+----------------+
            | common segment |    added     |    removed     |
            | unique segment | refine-added | refine-removed |
            +----------------+--------------+----------------+

            The customization allows
            - to change the foreground or background color;
            - to set or unset the attributes 'bold', 'intense', 'underline';
            - to clear all attributes.

            Customization is done passing a color_spec argument.
            This flag may be provided multiple times.

            The syntax is the following:

            color_spec = face-name + ':' + attributes
            attributes = attribute
                       | attribute + ':' + attributes
            attribute  = ('foreground' | 'background') + ':' + color
                       | (<empty> | 'no') + font-flag
                       | 'none'
            font-flag  = 'italic'
                       | 'bold'
                       | 'intense'
                       | 'underline'
            color      = 'none'
                       | [0-255]
                       | [0-255] + ',' + [0-255] + ',' + [0-255]
                       | ('black', 'blue', 'green', 'red',
                          'cyan', 'magenta', 'yellow', 'white')

            For example, the color_spec

                'refine-added:background:blue:bold'

            sets the color of unique added segments with
            a blue background, written with a bold font.

        --line-numbers <compact|aligned>
            Display line numbers. Style is optional.
            When style = 'compact', take as little width as possible.
            When style = 'aligned', align to tab stops (useful if tab is used for indentation). [default: compact]

    -h, --help
            Prints help information

    -V, --version
            Prints version information
"""


SHORT_HELP = """diffr 0.1.5
Nathan Moreau <nathan.moreau@m4x.org>

diffr adds word-level diff on top of unified diffs.
word-level diff information is displayed using text attributes.

USAGE:
    diffr reads from standard input and writes to standard output.

    Typical usage is for interactive use of diff:
    diff -u <file1> <file2> | diffr
    git show | diffr

OPTIONS:
        --colors <COLOR_SPEC>...    Configure color settings.
        --line-numbers              Display line numbers.
    -h, --help                      Prints help information
    -V, --version                   Prints version information
"""


def parse_args(argv):
    options = {"line_numbers": None, "faces": {k: list(v) for k, v in DEFAULT_FACES.items()}}
    i = 0
    while i < len(argv):
        arg = argv[i]
        if arg in ("-h", "--help"):
            return "help", options
        if arg in ("-V", "--version"):
            return "version", options
        if arg == "--line-numbers":
            style = "compact"
            if i + 1 < len(argv) and not argv[i + 1].startswith("-"):
                style = argv[i + 1]
                i += 1
            if style not in ("compact", "aligned", "fixed"):
                sys.stderr.write(
                    f"unexpected line number style: got '{style}', expected aligned|compact|fixed\n"
                )
                raise SystemExit(255)
            options["line_numbers"] = style
        elif arg == "--colors":
            if i + 1 >= len(argv):
                sys.stderr.write("missing value for --colors\n")
                raise SystemExit(2)
            i += 1
            apply_color_spec(options["faces"], argv[i])
        else:
            sys.stderr.write(f"bad argument: '{arg}'\n")
            sys.stderr.write(SHORT_HELP)
            raise SystemExit(2)
        i += 1
    return "run", options


def sgr(codes):
    if not codes:
        return ""
    return "".join(f"\033[{code}m" for code in codes)


def color_code(which, value):
    base = "38" if which == "foreground" else "48"
    named_base = 30 if which == "foreground" else 40
    if value == "none":
        return "39" if which == "foreground" else "49"
    if value in NAMED_COLORS:
        return str(named_base + NAMED_COLORS[value])
    if "," in value:
        pieces = value.split(",")
        if len(pieces) == 3 and all(p.isdigit() for p in pieces):
            return f"{base};2;{pieces[0]};{pieces[1]};{pieces[2]}"
    if value.isdigit():
        return f"{base};5;{value}"
    return None


def apply_color_spec(faces, spec):
    if ":" not in spec:
        return
    face, rest = spec.split(":", 1)
    if face not in faces:
        sys.stderr.write(
            f"unexpected face name: got '{face}', expected added|refine-added|removed|refine-removed\n"
        )
        raise SystemExit(255)
    parts = rest.split(":")
    if parts == ["none"]:
        faces[face] = []
        return
    codes = list(faces[face])
    i = 0
    while i < len(parts):
        part = parts[i]
        if part in ("foreground", "background") and i + 1 < len(parts):
            code = color_code(part, parts[i + 1])
            if code:
                if part == "foreground":
                    codes = [c for c in codes if not (c.startswith("3") or c.startswith("38;"))]
                else:
                    codes = [c for c in codes if not (c.startswith("4") or c.startswith("48;"))]
                codes.append(code)
            i += 2
            continue
        if part in ("bold", "intense"):
            codes.append("1")
        elif part == "italic":
            codes.append("3")
        elif part == "underline":
            codes.append("4")
        elif part == "nobold":
            codes.append("22")
        elif part == "nounderline":
            codes.append("24")
        i += 1
    faces[face] = codes


def render_plain(text):
    out = []
    for line in text.splitlines(True):
        if line.endswith("\n"):
            body = line[:-1]
            out.append(f"{RESET}{body}{RESET}\n")
        else:
            out.append(f"{RESET}{line}{RESET}")
    return "".join(out)


def split_tokens(s):
    return re.findall(r"\w+|\W+", s, flags=re.UNICODE)


def styled_segments(text, style, refine_style, mask):
    parts = []
    current_equal = None
    current = []
    for token, equal in zip(split_tokens(text), mask):
        if current_equal is None:
            current_equal = equal
        if equal != current_equal:
            parts.append((style if current_equal else refine_style) + "".join(current) + RESET)
            current = []
            current_equal = equal
        current.append(token)
    if current:
        parts.append((style if current_equal else refine_style) + "".join(current) + RESET)
    return "".join(parts)


def token_masks(old, new):
    old_tokens = split_tokens(old)
    new_tokens = split_tokens(new)
    old_mask = [False] * len(old_tokens)
    new_mask = [False] * len(new_tokens)
    matcher = SequenceMatcher(a=old_tokens, b=new_tokens, autojunk=False)
    for tag, i1, i2, j1, j2 in matcher.get_opcodes():
        if tag == "equal":
            for i in range(i1, i2):
                old_mask[i] = True
            for j in range(j1, j2):
                new_mask[j] = True
    return old_mask, new_mask


HUNK_RE = re.compile(r"^@@ -(\d+)(?:,\d+)? \+(\d+)(?:,\d+)? @@")


def render_changed_pair(old, new, options):
    old_text, old_no = old
    new_text, new_no = new
    old_mask, new_mask = token_masks(old_text, new_text)
    removed = sgr(options["faces"]["removed"])
    added = sgr(options["faces"]["added"])
    refine_removed = sgr(options["faces"]["refine-removed"])
    refine_added = sgr(options["faces"]["refine-added"])
    old_line = line_number_prefix("remove", old_no, None, options) + RESET + removed + "-" + RESET + RESET
    old_line += styled_segments(old_text, removed, refine_removed, old_mask)
    old_line += removed + RESET + "\n"
    new_line = line_number_prefix("add", None, new_no, options) + RESET + added + "+" + RESET + RESET
    new_line += styled_segments(new_text, added, refine_added, new_mask)
    new_line += added + RESET + "\n"
    return old_line + new_line


def render_removed(item, options):
    text, old_no = item
    removed = sgr(options["faces"]["removed"])
    refine_removed = sgr(options["faces"]["refine-removed"])
    return (
        line_number_prefix("remove", old_no, None, options)
        + RESET
        + removed
        + "-"
        + RESET
        + RESET
        + refine_removed
        + text
        + RESET
        + RESET
        + removed
        + RESET
        + "\n"
    )


def render_added(text):
    text, new_no = text
    added = sgr(options["faces"]["added"])
    refine_added = sgr(options["faces"]["refine-added"])
    return (
        line_number_prefix("add", None, new_no, options)
        + RESET
        + added
        + "+"
        + RESET
        + RESET
        + refine_added
        + text
        + RESET
        + RESET
        + added
        + RESET
        + "\n"
    )


def flush_changes(out, removed, added, options):
    count = max(len(removed), len(added))
    for i in range(count):
        if i < len(removed) and i < len(added):
            out.append(render_changed_pair(removed[i], added[i], options))
        elif i < len(removed):
            out.append(render_removed(removed[i], options))
        else:
            out.append(render_added(added[i], options))
    removed.clear()
    added.clear()


def line_number_prefix(kind, old_no, new_no, options):
    style = options.get("line_numbers")
    if not style:
        return ""
    sep = "\t" if style == "aligned" else " "
    if kind == "context":
        if style == "aligned":
            return f"{old_no:>3}\t{RESET}"
        return f"{old_no:>3}{RESET}{sep}"
    if kind == "remove":
        return RESET + sgr(options["faces"]["removed"]) + f"{old_no:<3}" + RESET
    if kind == "add":
        return RESET + sgr(options["faces"]["added"]) + f"{new_no:>3}" + RESET
    return ""


def render_diff(text, options):
    out = []
    removed = []
    added = []
    old_no = None
    new_no = None
    in_hunk = False
    for raw in text.splitlines(True):
        has_newline = raw.endswith("\n")
        line = raw[:-1] if has_newline else raw
        is_file_header = line.startswith("--- ") or line.startswith("+++ ")
        hunk = HUNK_RE.match(line)
        if hunk:
            flush_changes(out, removed, added, options)
            old_no = int(hunk.group(1))
            new_no = int(hunk.group(2))
            in_hunk = True
            suffix = "\n" if has_newline else ""
            out.append(f"{RESET}{line}{RESET}{suffix}")
            continue
        if in_hunk and line.startswith("-") and not is_file_header:
            removed.append((line[1:], old_no))
            if old_no is not None:
                old_no += 1
            continue
        if in_hunk and line.startswith("+") and not is_file_header:
            added.append((line[1:], new_no))
            if new_no is not None:
                new_no += 1
            continue
        flush_changes(out, removed, added, options)
        suffix = "\n" if has_newline else ""
        if line.startswith(" ") and old_no is not None and new_no is not None:
            body = line if options.get("line_numbers") == "aligned" else (line[1:] if options.get("line_numbers") else line)
            out.append(f"{line_number_prefix('context', old_no, new_no, options)}{body}{RESET}{suffix}")
            old_no += 1
            new_no += 1
        else:
            out.append(f"{RESET}{line}{RESET}{suffix}")
    flush_changes(out, removed, added, options)
    return "".join(out)


def main():
    mode, options = parse_args(sys.argv[1:])
    if mode == "help":
        sys.stdout.write(FULL_HELP)
        return 0
    if mode == "version":
        sys.stdout.write(VERSION + "\n")
        return 0
    sys.stdout.write(render_diff(sys.stdin.read(), options))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
