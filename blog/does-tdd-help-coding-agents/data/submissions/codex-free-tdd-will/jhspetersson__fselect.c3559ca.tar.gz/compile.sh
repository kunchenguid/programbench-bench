#!/bin/bash
set -e
cp fselect.py executable
chmod +x executable
