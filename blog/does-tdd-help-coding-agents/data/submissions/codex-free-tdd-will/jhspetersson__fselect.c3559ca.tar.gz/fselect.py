#!/usr/bin/env python3
import os
import json
import math
import shlex
import sys
import time
import hashlib
import pwd
import grp
from dataclasses import dataclass


@dataclass
class Row:
    root: str
    rel: str
    st: os.stat_result
    is_dir: bool
    is_file: bool
    is_symlink: bool


def walk_bfs(root, mindepth=0, maxdepth=None):
    queue = [("", 0)]
    while queue:
        rel_dir, cur_depth = queue.pop(0)
        base = os.path.join(root, rel_dir)
        try:
            entries = list(os.scandir(base))
        except OSError:
            continue
        dirs = []
        for ent in entries:
            rel = os.path.join(rel_dir, ent.name) if rel_dir else ent.name
            try:
                is_dir = ent.is_dir(follow_symlinks=False)
            except OSError:
                is_dir = False
            depth = cur_depth + 1
            if is_dir:
                if maxdepth is None or depth < maxdepth:
                    dirs.append((rel, depth))
                if depth >= mindepth and (maxdepth is None or depth <= maxdepth):
                    yield rel
        for ent in entries:
            rel = os.path.join(rel_dir, ent.name) if rel_dir else ent.name
            depth = cur_depth + 1
            try:
                if not ent.is_dir(follow_symlinks=False) and depth >= mindepth and (maxdepth is None or depth <= maxdepth):
                    yield rel
            except OSError:
                if depth >= mindepth and (maxdepth is None or depth <= maxdepth):
                    yield rel
        queue.extend(dirs)


def split_csv(tokens):
    parts = []
    cur = []
    depth = 0
    for tok in tokens:
        depth += tok.count("(") + tok.count("{")
        depth -= tok.count(")") + tok.count("}")
        if tok.endswith(",") and depth <= 0:
            cur.append(tok[:-1])
            parts.append(" ".join(x for x in cur if x))
            cur = []
        elif "," in tok and depth <= 0:
            bits = tok.split(",")
            cur.append(bits[0])
            parts.append(" ".join(x for x in cur if x))
            for mid in bits[1:-1]:
                parts.append(mid)
            cur = [bits[-1]]
        else:
            cur.append(tok)
    if cur:
        parts.append(" ".join(x for x in cur if x))
    return [p.strip() for p in parts if p.strip()]


def parse(argv):
    text = " ".join(argv)
    tokens = shlex.split(text)
    if tokens and tokens[0].lower() == "select":
        tokens = tokens[1:]
    lows = [t.lower() for t in tokens]
    keys = ["from", "where", "group", "order", "limit", "offset", "into"]
    positions = [lows.index(k) for k in keys if k in lows]
    first = min(positions) if positions else len(tokens)
    cols = split_csv(tokens[:first]) or ["path"]
    q = {"cols": cols, "roots": [(".", 0, None)], "where": [], "group": [], "order": [], "limit": None, "offset": 0, "format": "tabs"}
    if "from" in lows:
        s = lows.index("from") + 1
        e = min([i for i in [lows.index(k) for k in keys[1:] if k in lows] if i > s - 1] or [len(tokens)])
        q["roots"] = parse_roots(tokens[s:e])
    if "where" in lows:
        s = lows.index("where") + 1
        e = min([i for i in [lows.index(k) for k in keys[2:] if k in lows] if i > s - 1] or [len(tokens)])
        q["where"] = tokens[s:e]
    if "group" in lows:
        gi = lows.index("group")
        s = lows.index("by", gi) + 1 if "by" in lows[gi:] else gi + 1
        e = min([i for i in [lows.index(k) for k in ["order", "limit", "offset", "into"] if k in lows] if i > s - 1] or [len(tokens)])
        q["group"] = split_csv(tokens[s:e])
    if "order" in lows:
        s = lows.index("by", lows.index("order")) + 1 if "by" in lows[lows.index("order"):] else lows.index("order") + 1
        e = min([i for i in [lows.index(k) for k in ["limit", "offset", "into"] if k in lows] if i > s - 1] or [len(tokens)])
        q["order"] = split_csv(tokens[s:e])
    if "limit" in lows:
        i = lows.index("limit")
        if i + 1 < len(tokens):
            q["limit"] = int(tokens[i + 1])
    if "offset" in lows:
        i = lows.index("offset")
        if i + 1 < len(tokens):
            q["offset"] = int(tokens[i + 1])
    if "into" in lows:
        i = lows.index("into")
        if i + 1 < len(tokens):
            q["format"] = tokens[i + 1].lower()
    return q


def parse_roots(tokens):
    roots = []
    cur = None
    mindepth = 0
    maxdepth = None
    i = 0
    opts = {"mindepth", "maxdepth", "depth", "bfs", "dfs", "symlinks", "archives", "arc", "gitignore", "git", "nogitignore", "nogit"}
    while i < len(tokens):
        tok = tokens[i].rstrip(",")
        low = tok.lower()
        if low in ("mindepth", "maxdepth", "depth"):
            if i + 1 < len(tokens):
                val = int(tokens[i + 1].rstrip(","))
                if low == "mindepth":
                    mindepth = val
                elif val > 0:
                    maxdepth = val
                i += 2
                continue
        if low in opts:
            i += 1
            continue
        if cur is not None and (tokens[i - 1].endswith(",") or tok.startswith(",")):
            roots.append((cur, mindepth, maxdepth))
            mindepth, maxdepth = 0, None
        if cur is not None and tokens[i - 1].endswith(","):
            cur = tok
        elif cur is None:
            cur = tok
        elif tok:
            cur = tok
        if tokens[i].endswith(","):
            roots.append((cur, mindepth, maxdepth))
            cur = None
            mindepth, maxdepth = 0, None
        i += 1
    if cur is not None:
        roots.append((cur, mindepth, maxdepth))
    return roots or [(".", 0, None)]


def rows_for(root, mindepth=0, maxdepth=None):
    for rel in walk_bfs(root, mindepth, maxdepth):
        full = os.path.join(root, rel)
        try:
            st = os.lstat(full)
        except OSError:
            continue
        yield Row(root, rel, st, os.path.isdir(full) and not os.path.islink(full), os.path.isfile(full) and not os.path.islink(full), os.path.islink(full))


def mode_string(row):
    mode = row.st.st_mode
    kind = "d" if row.is_dir else "l" if row.is_symlink else "-"
    out = [kind]
    for r, w, x in [(0o400, 0o200, 0o100), (0o040, 0o020, 0o010), (0o004, 0o002, 0o001)]:
        out.append("r" if mode & r else "-")
        out.append("w" if mode & w else "-")
        out.append("x" if mode & x else "-")
    return "".join(out)


def value(row, expr):
    e = expr.strip()
    le = e.lower()
    if (e.endswith(")") and "(" in e) or (e.endswith("}") and "{" in e):
        open_ch = "(" if "(" in e else "{"
        close_ch = ")" if open_ch == "(" else "}"
        name, rest = e.split(open_ch, 1)
        args = split_csv([p.strip() for p in rest[:-1].split(",")])
        vals = [value(row, a) for a in args]
        fn = name.lower()
        s0 = "" if not vals else str(vals[0])
        if fn in ("lower", "lowercase", "lcase"):
            return s0.lower()
        if fn in ("upper", "uppercase", "ucase"):
            return s0.upper()
        if fn in ("length", "len"):
            return len(s0)
        if fn == "trim":
            return s0.strip()
        if fn == "ltrim":
            return s0.lstrip()
        if fn == "rtrim":
            return s0.rstrip()
        if fn in ("concat",):
            return "".join(str(v) for v in vals)
        if fn in ("format_size", "format_filesize"):
            return human_size(num(s0))
        if fn == "abs":
            return abs(num(s0))
        if fn in ("floor",):
            return math.floor(num(s0))
        if fn in ("ceil", "ceiling"):
            return math.ceil(num(s0))
        if fn == "round":
            return round(num(s0), int(num(vals[1])) if len(vals) > 1 else 0)
    if le in ("path",):
        return row.rel
    if le in ("name",):
        return os.path.basename(row.rel)
    if le in ("filename", "fname"):
        return os.path.splitext(os.path.basename(row.rel))[0]
    if le in ("ext", "extension"):
        return os.path.splitext(os.path.basename(row.rel))[1][1:]
    if le in ("dir", "directory", "dirname"):
        return os.path.dirname(row.rel)
    if le == "abspath":
        return os.path.abspath(os.path.join(row.root, row.rel))
    if le == "absdir":
        return os.path.dirname(os.path.abspath(os.path.join(row.root, row.rel)))
    if le == "size":
        return row.st.st_size
    if le in ("fsize", "hsize"):
        return human_size(row.st.st_size)
    if le in ("is_dir", "is_file", "is_symlink"):
        return {"is_dir": row.is_dir, "is_file": row.is_file, "is_symlink": row.is_symlink}[le]
    if le == "is_hidden":
        return os.path.basename(row.rel).startswith(".")
    if le == "is_empty":
        if row.is_dir:
            try:
                return not any(os.scandir(os.path.join(row.root, row.rel)))
            except OSError:
                return False
        return row.st.st_size == 0
    if le == "mode":
        return mode_string(row)
    if le in ("uid", "gid", "inode", "device", "rdev", "hardlinks"):
        return {"uid": row.st.st_uid, "gid": row.st.st_gid, "inode": row.st.st_ino, "device": row.st.st_dev, "rdev": row.st.st_rdev, "hardlinks": row.st.st_nlink}[le]
    if le == "blocks":
        return getattr(row.st, "st_blocks", 0) * 2
    if le == "user":
        try:
            return pwd.getpwuid(row.st.st_uid).pw_name
        except KeyError:
            return row.st.st_uid
    if le == "group":
        try:
            return grp.getgrgid(row.st.st_gid).gr_name
        except KeyError:
            return row.st.st_gid
    perm_bits = {
        "user_read": 0o400, "user_write": 0o200, "user_exec": 0o100,
        "group_read": 0o040, "group_write": 0o020, "group_exec": 0o010,
        "other_read": 0o004, "other_write": 0o002, "other_exec": 0o001,
        "suid": 0o4000, "is_suid": 0o4000, "sgid": 0o2000, "is_sgid": 0o2000,
        "sticky": 0o1000, "is_sticky": 0o1000,
    }
    if le in perm_bits:
        return bool(row.st.st_mode & perm_bits[le])
    if le in ("user_all", "user_rwx"):
        return (row.st.st_mode & 0o700) == 0o700
    if le in ("group_all", "group_rwx"):
        return (row.st.st_mode & 0o070) == 0o070
    if le in ("other_all", "other_rwx"):
        return (row.st.st_mode & 0o007) == 0o007
    if le in ("mtime", "atime", "ctime"):
        return int(getattr(row.st, "st_" + le))
    if le in ("modified", "accessed", "created"):
        attr = {"modified": "st_mtime", "accessed": "st_atime", "created": "st_ctime"}[le]
        return time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(getattr(row.st, attr)))
    if le in ("line_count",):
        try:
            with open(os.path.join(row.root, row.rel), "rb") as f:
                return f.read().count(b"\n")
        except OSError:
            return ""
    if le in ("is_text", "is_binary"):
        binary = is_binary_file(os.path.join(row.root, row.rel))
        return (not binary) if le == "is_text" else binary
    if le == "is_shebang":
        try:
            with open(os.path.join(row.root, row.rel), "rb") as f:
                return f.read(2) == b"#!"
        except OSError:
            return False
    if le == "mime":
        return mime_for(row.rel, os.path.join(row.root, row.rel))
    if le.startswith("is_"):
        kind = le[3:]
        return ext_kind(row.rel) == kind
    if le in ("sha1", "sha2_256", "sha256", "sha2_512", "sha512", "sha3_512", "sha3"):
        return digest_file(os.path.join(row.root, row.rel), le)
    if le.startswith("'") and le.endswith("'"):
        return e[1:-1]
    return e


EXTS = {
    "archive": {".7z", ".bz2", ".bzip2", ".gz", ".gzip", ".lz", ".rar", ".tar", ".xz", ".zip"},
    "audio": {".aac", ".aiff", ".amr", ".flac", ".gsm", ".m4a", ".m4b", ".m4p", ".mp3", ".ogg", ".wav", ".wma"},
    "book": {".azw3", ".chm", ".djv", ".djvu", ".epub", ".fb2", ".mobi", ".pdf"},
    "doc": {".accdb", ".doc", ".docm", ".docx", ".dot", ".dotm", ".dotx", ".mdb", ".odp", ".ods", ".odt", ".pdf", ".potm", ".potx", ".ppt", ".pptm", ".pptx", ".rtf", ".xlm", ".xls", ".xlsm", ".xlsx", ".xlt", ".xltm", ".xltx", ".xps"},
    "font": {".eot", ".fon", ".otc", ".otf", ".ttc", ".ttf", ".woff", ".woff2"},
    "image": {".bmp", ".exr", ".gif", ".heic", ".jpeg", ".jpg", ".jxl", ".png", ".psb", ".psd", ".svg", ".tga", ".tiff", ".webp"},
    "source": {".asm", ".awk", ".bas", ".c", ".cc", ".ceylon", ".clj", ".coffee", ".cpp", ".cs", ".d", ".dart", ".elm", ".erl", ".go", ".gradle", ".groovy", ".h", ".hh", ".hpp", ".java", ".jl", ".js", ".jsp", ".jsx", ".kt", ".kts", ".lua", ".nim", ".pas", ".php", ".pl", ".pm", ".py", ".rb", ".rs", ".scala", ".sol", ".swift", ".tcl", ".ts", ".tsx", ".vala", ".vb", ".zig"},
    "video": {".3gp", ".avi", ".flv", ".m4p", ".m4v", ".mkv", ".mov", ".mp4", ".mpeg", ".mpg", ".webm", ".wmv"},
}


def ext_kind(path):
    ext = os.path.splitext(path)[1].lower()
    for kind, exts in EXTS.items():
        if ext in exts:
            return kind
    return ""


def is_binary_file(path):
    try:
        with open(path, "rb") as f:
            chunk = f.read(4096)
        return b"\0" in chunk
    except OSError:
        return False


def mime_for(rel, path):
    ext = os.path.splitext(rel)[1].lower()
    table = {
        ".txt": "text/plain", ".md": "text/markdown", ".py": "text/x-python", ".rs": "text/rust",
        ".html": "text/html", ".json": "application/json", ".csv": "text/csv", ".pdf": "application/pdf",
        ".png": "image/png", ".jpg": "image/jpeg", ".jpeg": "image/jpeg", ".gif": "image/gif",
        ".zip": "application/zip", ".gz": "application/gzip", ".mp3": "audio/mpeg", ".mp4": "video/mp4",
    }
    if ext in table:
        return table[ext]
    return "application/octet-stream" if is_binary_file(path) else "text/plain"


def digest_file(path, name):
    alg = {"sha1": "sha1", "sha2_256": "sha256", "sha256": "sha256", "sha2_512": "sha512", "sha512": "sha512", "sha3_512": "sha3_512", "sha3": "sha3_512"}[name]
    h = hashlib.new(alg)
    try:
        with open(path, "rb") as f:
            for chunk in iter(lambda: f.read(65536), b""):
                h.update(chunk)
        return h.hexdigest()
    except OSError:
        return ""


def num(v):
    if isinstance(v, (int, float)):
        return v
    text = str(v).strip().lower()
    mults = {"k": 1024, "kb": 1024, "m": 1024**2, "mb": 1024**2, "g": 1024**3, "gb": 1024**3, "t": 1024**4, "tb": 1024**4}
    for suf, mult in sorted(mults.items(), key=lambda x: -len(x[0])):
        if text.endswith(suf):
            try:
                f = float(text[:-len(suf)]) * mult
                return int(f) if f.is_integer() else f
            except Exception:
                return 0
    try:
        f = float(text)
        return int(f) if f.is_integer() else f
    except Exception:
        return 0


def human_size(n):
    n = float(n)
    for unit in ["B", "KiB", "MiB", "GiB", "TiB"]:
        if abs(n) < 1024 or unit == "TiB":
            if unit == "B":
                return f"{int(n)}B"
            text = f"{n:.1f}".rstrip("0").rstrip(".")
            return text + unit
        n /= 1024


def is_aggregate(expr):
    le = expr.strip().lower()
    return any(le.startswith(f + "(") or le.startswith(f + "{") for f in ("count", "sum", "min", "max", "avg"))


def aggregate(rows, expr):
    e = expr.strip()
    fn = e.split("(", 1)[0].split("{", 1)[0].lower()
    inner = e[e.find("(") + 1:-1] if "(" in e else e[e.find("{") + 1:-1]
    vals = rows if inner.strip() == "*" else [value(r, inner) for r in rows]
    if fn == "count":
        return len(vals)
    nums = [num(v) for v in vals]
    if not nums:
        return ""
    if fn == "sum":
        return sum(nums)
    if fn == "min":
        return min(nums)
    if fn == "max":
        return max(nums)
    if fn == "avg":
        return sum(nums) / len(nums)
    return ""


def render_table(rows, cols, group_cols):
    if group_cols:
        groups = {}
        order = []
        for r in rows:
            key = tuple(format_value(value(r, c)) for c in group_cols)
            if key not in groups:
                groups[key] = []
                order.append(key)
            groups[key].append(r)
        table = []
        for key in order:
            rs = groups[key]
            out = []
            for c in cols:
                out.append(format_value(aggregate(rs, c)) if is_aggregate(c) else format_value(value(rs[0], c)))
            table.append(out)
        return table
    if any(is_aggregate(c) for c in cols):
        return [[format_value(aggregate(rows, c)) if is_aggregate(c) else "" for c in cols]]
    return [[format_value(value(r, c)) for c in cols] for r in rows]


def truthy(v):
    return bool(v) and v not in ("false", "0")


def cmp_values(a, op, b):
    import fnmatch, re
    af, bf = num(a), num(b)
    na = str(a).strip().lower().replace(".", "", 1).isdigit() or any(str(a).strip().lower().endswith(s) for s in ("k", "kb", "m", "mb", "g", "gb", "t", "tb"))
    nb = str(b).strip().lower().replace(".", "", 1).isdigit() or any(str(b).strip().lower().endswith(s) for s in ("k", "kb", "m", "mb", "g", "gb", "t", "tb"))
    if op in ("=", "==", "eq"):
        return fnmatch.fnmatch(str(a), str(b)) if any(c in str(b) for c in "*?[]") else str(a) == str(b)
    if op in ("===", "eeq"):
        return str(a) == str(b)
    if op in ("!=", "<>", "ne"):
        return not cmp_values(a, "=", b)
    if op in ("!==", "ene"):
        return str(a) != str(b)
    if op in (">", "gt", ">=", "gte", "ge", "<", "lt", "<=", "lte", "le"):
        aa, bb = (af, bf) if na and nb else (str(a), str(b))
        return {">": aa > bb, "gt": aa > bb, ">=": aa >= bb, "gte": aa >= bb, "ge": aa >= bb, "<": aa < bb, "lt": aa < bb, "<=": aa <= bb, "lte": aa <= bb, "le": aa <= bb}[op]
    if op in ("=~", "~=", "regexp", "rx"):
        return re.search(str(b), str(a)) is not None
    if op in ("!=~", "!~=", "notrx"):
        return re.search(str(b), str(a)) is None
    if op == "like":
        pat = "^" + re.escape(str(b)).replace("%", ".*").replace("_", ".") + "$"
        return re.search(pat, str(a)) is not None
    if op == "notlike":
        return not cmp_values(a, "like", b)
    return False


def passes(row, tokens):
    if not tokens:
        return True
    result = None
    logic = "and"
    i = 0
    while i < len(tokens):
        t = tokens[i].strip("()")
        lt = t.lower()
        if lt in ("and", "or"):
            logic = lt; i += 1; continue
        if i + 4 < len(tokens) and tokens[i + 1].lower() == "between":
            left = value(row, t)
            lo = value(row, tokens[i + 2].strip("()"))
            hi = value(row, tokens[i + 4].strip("()")) if tokens[i + 3].lower() == "and" else value(row, tokens[i + 3].strip("()"))
            cur = num(lo) <= num(left) <= num(hi)
            i += 5 if tokens[i + 3].lower() == "and" else 4
        elif i + 2 < len(tokens) and tokens[i + 1].lower() == "in":
            left = str(value(row, t))
            vals = []
            j = i + 2
            while j < len(tokens) and tokens[j].lower() not in ("and", "or"):
                vals.extend(x.strip("(),") for x in tokens[j].split(",") if x.strip("(),"))
                j += 1
            cur = left in [str(value(row, v)) for v in vals]
            i = j
        elif i + 2 < len(tokens) and tokens[i + 1].lower() not in ("and", "or"):
            left = value(row, t)
            op = tokens[i + 1].lower()
            right = value(row, tokens[i + 2].strip("()"))
            cur = cmp_values(left, op, right)
            i += 3
        else:
            cur = truthy(value(row, t))
            i += 1
        result = cur if result is None else (result and cur if logic == "and" else result or cur)
    return bool(result)


def format_value(v):
    if isinstance(v, bool):
        return "true" if v else "false"
    if isinstance(v, float) and v.is_integer():
        return str(int(v))
    return str(v)


def label(col):
    low = col.lower()
    simple = {"name": "Name", "size": "Size", "path": "Path", "ext": "Ext", "extension": "Extension", "filename": "Filename", "fname": "Filename", "dir": "Dir"}
    return simple.get(low, col)


def emit(table, cols, fmt, query_text):
    if fmt == "json":
        print(json.dumps([{label(c): str(v) for c, v in zip(cols, row)} for row in table], separators=(",", ":")), end="")
    elif fmt == "csv":
        for row in table:
            print(",".join(str(v) for v in row))
    elif fmt in ("lines", "tabs"):
        for row in table:
            print("\t".join(str(v) for v in row))
    elif fmt == "list":
        print(" ".join(str(row[0]) for row in table))
    elif fmt == "html":
        cells = "".join("<tr>" + "".join(f"<td>{v}</td>" for v in row) + "</tr>" for row in table)
        print(f"<html><head><title>{query_text}</title></head><body><table><tr><th colspan=\"{len(cols)}\">{query_text}</th></tr>{cells}</table></body></html>")
    else:
        for row in table:
            print("\t".join(str(v) for v in row))


def main(argv):
    if "-i" in argv or "--interactive" in argv:
        for line in sys.stdin:
            cmd = line.strip()
            if cmd in ("exit", "quit"):
                break
            if cmd == "pwd":
                print(os.getcwd())
            elif cmd.startswith("cd "):
                try:
                    os.chdir(cmd[3:].strip())
                except OSError as e:
                    print(e, file=sys.stderr)
            elif cmd == "help":
                print("fselect 0.10.0")
            elif cmd:
                main(shlex.split(cmd))
        return 0
    if "--help" in argv or "-h" in argv or "--version" in argv or "-V" in argv:
        print("fselect 0.10.0")
        print("Find files with SQL-like queries.")
        return 0
    cleaned = []
    skip = False
    for i, a in enumerate(argv):
        if skip:
            skip = False
            continue
        if a in ("--nocolor", "--no-color", "--no-errors", "--us-dates"):
            continue
        if a == "--config":
            skip = True
            continue
        cleaned.append(a)
    argv = cleaned
    if not argv:
        print("fselect 0.10.0")
        print("Find files with SQL-like queries.")
        print("https://github.com/jhspetersson/fselect")
        print()
        print("Usage: fselect [ARGS] COLUMN[, COLUMN...] [from PATH[, PATH...]] [where EXPR] [group by COLUMN, ...] [order by COLUMN (asc|desc), ...] [limit N] [offset N] [into FORMAT]")
        return 0
    q = parse(argv)
    rows = []
    for root, mindepth, maxdepth in q["roots"]:
        rows.extend(r for r in rows_for(root, mindepth, maxdepth) if passes(r, q["where"]))
    start = q["offset"]
    end = None if q["limit"] is None else start + q["limit"]
    if q["group"]:
        table = render_table(rows, q["cols"], q["group"])
        for spec in reversed(q["order"]):
            bits = spec.split()
            desc = len(bits) > 1 and bits[1].lower() == "desc"
            idx = int(bits[0]) - 1 if bits[0].isdigit() else next((i for i, c in enumerate(q["cols"]) if c.lower() == bits[0].lower()), 0)
            table.sort(key=lambda row: row[idx], reverse=desc)
        table = table[start:end]
    else:
        for spec in reversed(q["order"]):
            bits = spec.split()
            col = q["cols"][int(bits[0]) - 1] if bits[0].isdigit() and int(bits[0]) <= len(q["cols"]) else bits[0]
            desc = len(bits) > 1 and bits[1].lower() == "desc"
            rows.sort(key=lambda r: value(r, col), reverse=desc)
        rows = rows[start:end]
        table = render_table(rows, q["cols"], q["group"])
    emit(table, q["cols"], q["format"], " ".join(argv))
    return 0


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
