import subprocess, tempfile, pathlib
ROOT = pathlib.Path(__file__).resolve().parents[1]
BIN = ROOT / "executable"

def run(args):
    return subprocess.run([str(BIN), *args], cwd=ROOT, text=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)

def build_dict(words):
    f = tempfile.NamedTemporaryFile("w", delete=False)
    f.write("\n".join(words) + "\n")
    f.close()
    return f.name

def test_help_has_expected_usage():
    p = run(["--help"])
    assert p.returncode == 0
    assert "Find the password of protected ZIP files" in p.stdout
    assert "--inputFile <inputFile>" in p.stdout

def test_dictionary_finds_zipcrypto_password():
    d = build_dict(["nope", "test", "123"])
    p = run(["-i", "assets/password-test.zip", "-p", d])
    assert p.returncode == 0
    assert "Password found:test" in p.stdout

def test_bruteforce_finds_digit_password():
    p = run(["-i", "assets/password-123.zip", "-c", "d", "--minPasswordLen", "1", "--maxPasswordLen", "3"])
    assert p.returncode == 0
    assert "Password found:123" in p.stdout

def test_unknown_charset_is_cli_error():
    p = run(["-i", "assets/password-test.zip", "-c", "z", "--minPasswordLen", "1", "--maxPasswordLen", "1"])
    assert p.returncode == 1
    assert "Unknown charset option 'z'" in p.stdout

def test_dictionary_finds_aes_password():
    d = build_dict(["aa", "ab", "abc"])
    p = run(["-i", "assets/2.test.txt.zip", "-p", d])
    assert p.returncode == 0
    assert "Password found:ab" in p.stdout
