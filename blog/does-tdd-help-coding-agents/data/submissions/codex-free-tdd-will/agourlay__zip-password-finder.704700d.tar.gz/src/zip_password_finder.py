#!/usr/bin/env python3
import hashlib
import itertools
import os
import struct
import sys
import time
import zlib

VERSION = "zip-password-finder 0.10.3"
HELP = """Find the password of protected ZIP files

Usage: executable [OPTIONS] --inputFile <inputFile>

Options:
  -i, --inputFile <inputFile>                    path to zip input file
  -w, --workers <workers>                        number of workers
  -p, --passwordDictionary <passwordDictionary>  path to a password dictionary file
  -c, --charset <charset>                        charset to use to generate password [default: lud]
      --charsetFile <charsetFile>                path to a charset file
      --minPasswordLen <minPasswordLen>          minimum password length [default: 1]
      --maxPasswordLen <maxPasswordLen>          maximum password length [default: 10]
      --fileNumber <fileNumber>                  file number in the zip archive [default: 0]
  -s, --startingPassword <startingPassword>      password to start from
  -h, --help                                     Print help
  -V, --version                                  Print version
"""

CHARSETS = {
    "l": "abcdefghijklmnopqrstuvwxyz",
    "u": "ABCDEFGHIJKLMNOPQRSTUVWXYZ",
    "d": "0123456789",
    "h": "0123456789abcdef",
    "H": "0123456789ABCDEF",
    "s": " !\"#$%&'()*+,-./:;<=>?@[\\]^_`{|}~",
}

CRC_TABLE = []
for n in range(256):
    c = n
    for _ in range(8):
        c = 0xEDB88320 ^ (c >> 1) if c & 1 else c >> 1
    CRC_TABLE.append(c & 0xffffffff)

def crc32_byte(old, b):
    return ((old >> 8) ^ CRC_TABLE[(old ^ b) & 0xff]) & 0xffffffff

class ZipCrypto:
    def __init__(self, password):
        self.k0 = 0x12345678
        self.k1 = 0x23456789
        self.k2 = 0x34567890
        for b in password:
            self.update(b)
    def update(self, b):
        self.k0 = crc32_byte(self.k0, b)
        self.k1 = (self.k1 + (self.k0 & 0xff)) & 0xffffffff
        self.k1 = (self.k1 * 134775813 + 1) & 0xffffffff
        self.k2 = crc32_byte(self.k2, (self.k1 >> 24) & 0xff)
    def magic(self):
        t = (self.k2 | 2) & 0xffffffff
        return ((t * (t ^ 1)) >> 8) & 0xff
    def decrypt_byte(self, c):
        p = c ^ self.magic()
        self.update(p)
        return p
    def decrypt(self, data):
        return bytes(self.decrypt_byte(c) for c in data)

class ZipEntry:
    def __init__(self, flag, method, mtime, crc, comp_size, uncomp_size, name, extra, data):
        self.flag = flag
        self.method = method
        self.mtime = mtime
        self.crc = crc
        self.comp_size = comp_size
        self.uncomp_size = uncomp_size
        self.name = name
        self.extra = extra
        self.data = data

def parse_entries(path):
    blob = open(path, "rb").read()
    entries = parse_central_directory(blob)
    if entries:
        return entries
    entries = []
    pos = 0
    while pos + 30 <= len(blob):
        if blob[pos:pos+4] != b"PK\x03\x04":
            break
        vals = struct.unpack_from("<HHHHHIIIHH", blob, pos + 4)
        _ver, flag, method, mtime, _mdate, crc, comp_size, uncomp_size, nlen, elen = vals
        start = pos + 30
        name = blob[start:start+nlen]
        extra = blob[start+nlen:start+nlen+elen]
        dstart = start + nlen + elen
        data = blob[dstart:dstart+comp_size]
        entries.append(ZipEntry(flag, method, mtime, crc, comp_size, uncomp_size, name, extra, data))
        pos = dstart + comp_size
    if not entries:
        raise ValueError("No zip entries found")
    return entries

def parse_central_directory(blob):
    eocd = blob.rfind(b"PK\x05\x06")
    if eocd < 0 or eocd + 22 > len(blob):
        return []
    try:
        _disk, _cd_disk, _disk_entries, total_entries, _cd_size, cd_offset, comment_len = struct.unpack_from("<HHHHIIH", blob, eocd + 4)
    except struct.error:
        return []
    if eocd + 22 + comment_len > len(blob):
        return []
    entries = []
    pos = cd_offset
    for _ in range(total_entries):
        if pos + 46 > len(blob) or blob[pos:pos+4] != b"PK\x01\x02":
            return []
        vals = struct.unpack_from("<HHHHHHIIIHHHHHII", blob, pos + 4)
        (_made, _need, flag, method, mtime, _mdate, crc, comp_size, uncomp_size,
         nlen, elen, clen, _disk_start, _int_attr, _ext_attr, local_offset) = vals
        name = blob[pos+46:pos+46+nlen]
        central_extra = blob[pos+46+nlen:pos+46+nlen+elen]
        if local_offset + 30 > len(blob) or blob[local_offset:local_offset+4] != b"PK\x03\x04":
            return []
        lvals = struct.unpack_from("<HHHHHIIIHH", blob, local_offset + 4)
        lnlen, lelen = lvals[8], lvals[9]
        local_extra = blob[local_offset+30+lnlen:local_offset+30+lnlen+lelen]
        data_start = local_offset + 30 + lnlen + lelen
        data = blob[data_start:data_start+comp_size]
        entries.append(ZipEntry(flag, method, mtime, crc, comp_size, uncomp_size, name, local_extra or central_extra, data))
        pos += 46 + nlen + elen + clen
    return entries

def find_extra(extra, wanted):
    i = 0
    while i + 4 <= len(extra):
        hid, size = struct.unpack_from("<HH", extra, i)
        body = extra[i+4:i+4+size]
        if hid == wanted:
            return body
        i += 4 + size
    return None

def aes_password_matches(entry, password):
    body = find_extra(entry.extra, 0x9901)
    if not body or len(body) < 7:
        return False
    strength = body[4]
    key_len = {1: 16, 2: 24, 3: 32}.get(strength)
    salt_len = {1: 8, 2: 12, 3: 16}.get(strength)
    if not key_len or len(entry.data) < salt_len + 2:
        return False
    salt = entry.data[:salt_len]
    verifier = entry.data[salt_len:salt_len+2]
    derived = hashlib.pbkdf2_hmac("sha1", password, salt, 1000, 2 * key_len + 2)
    return derived[-2:] == verifier

def zipcrypto_password_matches(entry, password):
    if len(entry.data) < 12:
        return False
    zc = ZipCrypto(password)
    header = zc.decrypt(entry.data[:12])
    check = ((entry.mtime >> 8) & 0xff) if (entry.flag & 0x08) else ((entry.crc >> 24) & 0xff)
    if header[-1] != check:
        return False
    plain = zc.decrypt(entry.data[12:])
    try:
        if entry.method == 0:
            out = plain
        elif entry.method == 8:
            out = zlib.decompress(plain, -15)
        else:
            return True
        return (zlib.crc32(out) & 0xffffffff) == entry.crc
    except Exception:
        return False

def password_matches(entry, text):
    password = text.encode("utf-8")
    if entry.method == 99:
        return aes_password_matches(entry, password)
    if entry.flag & 0x01:
        return zipcrypto_password_matches(entry, password)
    return False

def parse_args(argv):
    if not argv:
        sys.stderr.write("error: the following required arguments were not provided:\n  --inputFile <inputFile>\n\nUsage: executable --inputFile <inputFile>\n\nFor more information, try '--help'.\n")
        sys.exit(2)
    opts = {"charset": "lud", "minPasswordLen": "1", "maxPasswordLen": "10", "fileNumber": "0", "workers": None,
            "inputFile": None, "passwordDictionary": None, "charsetFile": None, "startingPassword": None}
    names = {"-i":"inputFile", "--inputFile":"inputFile", "-w":"workers", "--workers":"workers", "-p":"passwordDictionary", "--passwordDictionary":"passwordDictionary", "-c":"charset", "--charset":"charset", "--charsetFile":"charsetFile", "--minPasswordLen":"minPasswordLen", "--maxPasswordLen":"maxPasswordLen", "--fileNumber":"fileNumber", "-s":"startingPassword", "--startingPassword":"startingPassword"}
    i = 0
    while i < len(argv):
        a = argv[i]
        if a in ("-h", "--help"):
            print(HELP, end="")
            sys.exit(0)
        if a in ("-V", "--version"):
            print(VERSION)
            sys.exit(0)
        if a.startswith("--") and "=" in a:
            key, value = a.split("=", 1)
            if key not in names:
                sys.stderr.write(f"error: unexpected argument '{a}'\n")
                sys.exit(2)
            opts[names[key]] = value
            i += 1
            continue
        if a not in names or i + 1 >= len(argv):
            sys.stderr.write(f"error: unexpected argument '{a}'\n")
            sys.exit(2)
        opts[names[a]] = argv[i+1]
        i += 2
    if not opts["inputFile"]:
        sys.stderr.write("error: the following required arguments were not provided:\n  --inputFile <inputFile>\n\nUsage: executable --inputFile <inputFile>\n\nFor more information, try '--help'.\n")
        sys.exit(2)
    return opts

def cli_error(msg):
    print(f"CLI argument error - \"{msg}\"")
    sys.exit(1)

def validate(opts):
    if not os.path.exists(opts["inputFile"]):
        cli_error("'inputFile' does not exist")
    if opts["passwordDictionary"] and not os.path.exists(opts["passwordDictionary"]):
        cli_error("'passwordDictionary' does not exist")
    if opts["charsetFile"] and not os.path.exists(opts["charsetFile"]):
        cli_error("'charsetFile' does not exist")
    if opts["passwordDictionary"] and opts["startingPassword"]:
        cli_error("'startingPassword' cannot be used with a dictionary file")
    try:
        opts["minPasswordLen"] = int(opts["minPasswordLen"])
        opts["maxPasswordLen"] = int(opts["maxPasswordLen"])
        opts["fileNumber"] = int(opts["fileNumber"])
    except ValueError:
        cli_error("invalid digit found in string")
    if opts["maxPasswordLen"] < opts["minPasswordLen"]:
        cli_error("'maxPasswordLen' must be equal or greater than 'minPasswordLen'")
    for ch in opts["charset"]:
        if ch not in CHARSETS:
            cli_error(f"Unknown charset option '{ch}'")

def charset_for(opts):
    if opts["charsetFile"]:
        return open(opts["charsetFile"], "r", encoding="utf-8", errors="ignore").read().replace("\n", "")
    out = []
    for key in opts["charset"]:
        for ch in CHARSETS[key]:
            if ch not in out:
                out.append(ch)
    return "".join(out)

def candidates(opts):
    if opts["passwordDictionary"]:
        with open(opts["passwordDictionary"], "r", encoding="utf-8", errors="ignore") as f:
            for line in f:
                yield line.rstrip("\r\n")
        return
    chars = charset_for(opts)
    start = opts["startingPassword"]
    active = start is None
    for length in range(opts["minPasswordLen"], opts["maxPasswordLen"] + 1):
        for tup in itertools.product(chars, repeat=length):
            word = "".join(tup)
            if not active:
                if word == start:
                    active = True
                else:
                    continue
            yield word

def format_elapsed(seconds):
    ns = int(seconds * 1_000_000_000)
    if ns >= 1_000_000_000:
        return f"{ns // 1_000_000_000}s"
    if ns >= 1_000_000:
        return f"{ns // 1_000_000}ms {(ns // 1000) % 1000}us {ns % 1000}ns"
    if ns >= 1000:
        return f"{ns // 1000}us {ns % 1000}ns"
    return f"{ns}ns"

def main(argv):
    opts = parse_args(argv)
    validate(opts)
    started = time.perf_counter()
    try:
        entries = parse_entries(opts["inputFile"])
        entry = entries[opts["fileNumber"]]
    except Exception as e:
        print(f"Error reading zip file: {e}")
        return 1
    found = None
    for cand in candidates(opts):
        if password_matches(entry, cand):
            found = cand
            break
    print(f"Time elapsed: {format_elapsed(time.perf_counter() - started)}")
    if found is None:
        print("Password not found")
    else:
        print(f"Password found:{found}")
    return 0

if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
