#!/bin/bash
set -e
cp src/dstask.py executable
chmod +x executable
