import json
import os
import subprocess
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
BIN = ROOT / "src" / "dstask.py"

def run(home, *args):
    env = os.environ.copy()
    env["HOME"] = str(home)
    env.pop("DSTASK_CONTEXT", None)
    env.pop("DSTASK_GIT_REPO", None)
    return subprocess.run([str(BIN), *args], cwd=ROOT, env=env, text=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)

class DstaskTests(unittest.TestCase):
    def test_add_and_show_open_json(self):
        with tempfile.TemporaryDirectory() as d:
            home = Path(d)
            p = run(home, "add", "buy", "milk", "+home", "project:errands", "P1", "due:2030-01-02")
            self.assertEqual(p.returncode, 0, p.stderr)
            self.assertIn("Added 1: buy milk", p.stdout)
            shown = run(home, "show-open")
            self.assertEqual(shown.returncode, 0, shown.stderr)
            data = json.loads(shown.stdout)
            self.assertEqual(len(data), 1)
            task = data[0]
            self.assertEqual(task["id"], 1)
            self.assertEqual(task["status"], "pending")
            self.assertEqual(task["summary"], "buy milk")
            self.assertEqual(task["tags"], ["home"])
            self.assertEqual(task["project"], "errands")
            self.assertEqual(task["priority"], "P1")
            self.assertEqual(task["due"], "2030-01-02T00:00:00Z")

    def test_filters_and_status_transitions(self):
        with tempfile.TemporaryDirectory() as d:
            home = Path(d)
            run(home, "add", "alpha", "+work", "P3")
            run(home, "add", "bravo", "+home", "project:errands", "P1")
            run(home, "add", "charlie", "+work", "+home", "P0")

            work = json.loads(run(home, "show-open", "+work").stdout)
            self.assertEqual([t["summary"] for t in work], ["charlie", "alpha"])

            not_home = json.loads(run(home, "show-open", "-home").stdout)
            self.assertEqual([t["summary"] for t in not_home], ["alpha"])

            started = run(home, "1", "start")
            self.assertIn("Started 1: alpha", started.stdout)
            active = json.loads(run(home, "show-active").stdout)
            self.assertEqual(active[0]["summary"], "alpha")
            self.assertEqual(active[0]["status"], "active")

            stopped = run(home, "stop", "1")
            self.assertIn("Stopped 1: alpha", stopped.stdout)
            paused = json.loads(run(home, "show-paused").stdout)
            self.assertEqual(paused[0]["status"], "paused")

            done = run(home, "1", "done", "closing", "note")
            self.assertIn("Resolved 1: alpha", done.stdout)
            resolved = json.loads(run(home, "show-resolved").stdout)
            self.assertEqual(resolved[0]["summary"], "alpha")
            self.assertEqual(resolved[0]["id"], 0)
            self.assertIn("closing note", resolved[0]["notes"])

    def test_context_filters_and_applies_to_new_tasks(self):
        with tempfile.TemporaryDirectory() as d:
            home = Path(d)
            self.assertEqual(run(home, "context", "+work", "project:client").returncode, 0)
            run(home, "add", "scoped")
            run(home, "add", "plain", "--")

            scoped = json.loads(run(home, "show-open").stdout)
            self.assertEqual([t["summary"] for t in scoped], ["scoped"])
            self.assertEqual(scoped[0]["tags"], ["work"])
            self.assertEqual(scoped[0]["project"], "client")

            all_tasks = json.loads(run(home, "show-open", "--").stdout)
            self.assertEqual([t["summary"] for t in all_tasks], ["scoped", "plain"])

            run(home, "context", "none")
            unscoped = json.loads(run(home, "show-open").stdout)
            self.assertEqual([t["summary"] for t in unscoped], ["scoped", "plain"])

    def test_templates_have_ids_and_can_seed_tasks(self):
        with tempfile.TemporaryDirectory() as d:
            home = Path(d)
            made = run(home, "template", "routine", "+ops", "P1")
            self.assertIn("Created Template 1: routine", made.stdout)
            templates = json.loads(run(home, "show-templates").stdout)
            self.assertEqual(templates[0]["id"], 1)
            run(home, "add", "template:1", "followup")
            open_tasks = json.loads(run(home, "show-open").stdout)
            self.assertEqual(open_tasks[0]["id"], 2)
            self.assertEqual(open_tasks[0]["summary"], "followup")
            self.assertEqual(open_tasks[0]["tags"], ["ops"])
            self.assertEqual(open_tasks[0]["priority"], "P1")

if __name__ == "__main__":
    unittest.main()
