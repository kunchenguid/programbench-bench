#!/usr/bin/env python3
import json
import os
import subprocess
import sys
import uuid
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path

ZERO_TIME = "0001-01-01T00:00:00Z"
STATUSES = ["pending", "active", "paused", "resolved", "template"]
PRIORITIES = {"P0": 0, "P1": 1, "P2": 2, "P3": 3}


def now_ts():
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%S.%fZ")


@dataclass
class Task:
    uuid: str
    status: str
    summary: str
    notes: str = ""
    tags: list[str] = field(default_factory=list)
    project: str = ""
    priority: str = "P2"
    created: str = field(default_factory=now_ts)
    resolved: str = ZERO_TIME
    due: str = ZERO_TIME

    def to_json(self, task_id):
        return {
            "uuid": self.uuid,
            "status": self.status,
            "id": task_id,
            "summary": self.summary,
            "notes": self.notes,
            "tags": sorted(self.tags),
            "project": self.project,
            "priority": self.priority,
            "created": self.created,
            "resolved": self.resolved,
            "due": self.due,
        }


def repo_path():
    return Path(os.environ.get("DSTASK_GIT_REPO") or (Path.home() / ".dstask"))


def ensure_repo(repo):
    repo.mkdir(parents=True, exist_ok=True)
    for status in STATUSES:
        (repo / status).mkdir(exist_ok=True)
    if not (repo / ".git").exists():
        subprocess.run(["git", "init"], cwd=repo)


def quote_yaml(value):
    if value == "":
        return '""'
    return value


def write_task(repo, task):
    path = repo / task.status / f"{task.uuid}.yml"
    lines = [f"summary: {quote_yaml(task.summary)}"]
    if "\n" in task.notes:
        lines.append("notes: |")
        for line in task.notes.rstrip("\n").split("\n"):
            lines.append(f"  {line}")
    else:
        lines.append(f"notes: {quote_yaml(task.notes)}")
    lines.append("tags:")
    for tag in sorted(task.tags):
        lines.append(f"- {tag}")
    lines += [
        f"project: {quote_yaml(task.project)}",
        f"priority: {task.priority}",
        'delegatedto: ""',
        "subtasks: []",
        "dependencies: []",
        f"created: {task.created}",
        f"resolved: {task.resolved}",
        f"due: {task.due}",
    ]
    path.write_text("\n".join(lines) + "\n")


def delete_task_file(repo, task):
    path = repo / task.status / f"{task.uuid}.yml"
    if path.exists():
        path.unlink()


def unquote(value):
    value = value.strip()
    if value == '""':
        return ""
    return value


def read_task(path, status):
    data = {"tags": []}
    lines = path.read_text().splitlines()
    i = 0
    while i < len(lines):
        line = lines[i]
        if line.startswith("summary:"):
            data["summary"] = unquote(line.split(":", 1)[1])
        elif line == "notes: |":
            note_lines = []
            i += 1
            while i < len(lines) and lines[i].startswith("  "):
                note_lines.append(lines[i][2:])
                i += 1
            data["notes"] = "\n".join(note_lines) + ("\n" if note_lines else "")
            continue
        elif line.startswith("notes:"):
            data["notes"] = unquote(line.split(":", 1)[1])
        elif line == "tags:":
            tags = []
            i += 1
            while i < len(lines) and lines[i].startswith("- "):
                tags.append(lines[i][2:].strip())
                i += 1
            data["tags"] = tags
            continue
        elif line.startswith("project:"):
            data["project"] = unquote(line.split(":", 1)[1])
        elif line.startswith("priority:"):
            data["priority"] = unquote(line.split(":", 1)[1])
        elif line.startswith("created:"):
            data["created"] = unquote(line.split(":", 1)[1])
        elif line.startswith("resolved:"):
            data["resolved"] = unquote(line.split(":", 1)[1])
        elif line.startswith("due:"):
            data["due"] = unquote(line.split(":", 1)[1])
        i += 1
    return Task(
        uuid=path.stem,
        status=status,
        summary=data.get("summary", ""),
        notes=data.get("notes", ""),
        tags=data.get("tags", []),
        project=data.get("project", ""),
        priority=data.get("priority", "P2"),
        created=data.get("created", ZERO_TIME),
        resolved=data.get("resolved", ZERO_TIME),
        due=data.get("due", ZERO_TIME),
    )


def load_tasks(repo):
    tasks = []
    for status in STATUSES:
        for path in sorted((repo / status).glob("*.yml")):
            tasks.append(read_task(path, status))
    return tasks


def open_id_map(tasks):
    open_tasks = [t for t in tasks if t.status in ("pending", "active", "paused", "template")]
    open_tasks.sort(key=lambda t: t.created)
    return {t.uuid: i + 1 for i, t in enumerate(open_tasks)}


def parse_attrs(words):
    summary = []
    tags_add = []
    tags_remove = []
    project = None
    priority = None
    due = None
    notes = []
    in_note = False
    for word in words:
        if word == "--":
            continue
        if in_note:
            notes.append(word)
        elif word == "/":
            in_note = True
        elif word in PRIORITIES:
            priority = word
        elif word.startswith("+") and len(word) > 1:
            tags_add.append(word[1:])
        elif word.startswith("-") and len(word) > 1:
            tags_remove.append(word[1:])
        elif word.startswith("project:"):
            project = word.split(":", 1)[1]
        elif word.startswith("-project:"):
            project = ""
        elif word.startswith("due:"):
            d = word.split(":", 1)[1]
            due = f"{d}T00:00:00Z" if d else ZERO_TIME
        else:
            summary.append(word)
    return {
        "summary": " ".join(summary).strip(),
        "tags_add": tags_add,
        "tags_remove": tags_remove,
        "project": project,
        "priority": priority,
        "due": due,
        "notes": " ".join(notes).strip(),
    }


def context_words(repo):
    env = os.environ.get("DSTASK_CONTEXT")
    if env is not None:
        return [] if env in ("", "none", "--") else env.split()
    path = repo / "context"
    if not path.exists():
        return []
    text = path.read_text().strip()
    return [] if text in ("", "none", "--") else text.split()


def without_bypass(args):
    return [a for a in args if a != "--"]


def apply_context_args(repo, args):
    if "--" in args:
        return without_bypass(args)
    return context_words(repo) + args


def cmd_context(repo, args):
    words = without_bypass(args)
    if not words or words == ["none"]:
        path = repo / "context"
        if path.exists():
            path.unlink()
        return
    attrs = parse_attrs(words)
    if attrs["summary"]:
        print("\033[31mcontext cannot contain text\033[0m", file=sys.stderr)
        raise SystemExit(1)
    (repo / "context").write_text(" ".join(words) + "\n")


def git_commit(repo, message):
    subprocess.run(["git", "add", "."], cwd=repo, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    subprocess.run(["git", "commit", "-m", message], cwd=repo)


def split_command(argv):
    ids = []
    rest = []
    commands = {
        "next", "add", "template", "log", "start", "note", "stop", "done", "context",
        "modify", "edit", "undo", "sync", "open", "git", "remove", "show-projects",
        "show-tags", "show-active", "show-paused", "show-open", "show-resolved",
        "show-templates", "show-unorganised", "bash-completion", "fish-completion",
        "zsh-completion", "powershell-completion", "help", "version",
    }
    command = None
    for word in argv:
        if command is None and word.isdigit():
            ids.append(int(word))
        elif command is None and word in commands:
            command = word
        elif command is None:
            rest.append(word)
        else:
            if word.isdigit() and command in ("start", "stop", "done", "remove", "modify", "note"):
                ids.append(int(word))
            else:
                rest.append(word)
    if command is None:
        command = "next"
        rest = [w for w in argv if not w.isdigit()]
    return ids, command, rest


def task_by_ids(tasks, ids):
    mapping = open_id_map(tasks)
    rev = {v: k for k, v in mapping.items()}
    found = []
    for task_id in ids:
        uid = rev.get(task_id)
        if uid:
            found.extend([t for t in tasks if t.uuid == uid])
    return found


def cmd_add(repo, args, status="pending"):
    raw_args = args
    args = apply_context_args(repo, args)
    template_id = None
    cleaned = []
    for word in args:
        if word.startswith("template:"):
            try:
                template_id = int(word.split(":", 1)[1])
            except ValueError:
                template_id = None
        else:
            cleaned.append(word)
    args = cleaned
    attrs = parse_attrs(args)
    tasks = load_tasks(repo)
    ids = open_id_map(tasks)
    base = None
    if template_id is not None:
        rev = {v: k for k, v in ids.items()}
        uid = rev.get(template_id)
        base = next((t for t in tasks if t.uuid == uid), None)
    merged_tags = (set(base.tags) if base else set()) | set(attrs["tags_add"])
    merged_tags -= set(attrs["tags_remove"])
    task = Task(
        uuid=str(uuid.uuid4()),
        status=status,
        summary=attrs["summary"] or (base.summary if base else ""),
        notes=attrs["notes"] or (base.notes if base else ""),
        tags=sorted(merged_tags),
        project=attrs["project"] if attrs["project"] is not None else (base.project if base else ""),
        priority=attrs["priority"] or (base.priority if base else "P2"),
        due=attrs["due"] or (base.due if base else ZERO_TIME),
    )
    if status == "resolved":
        task.resolved = now_ts()
    write_task(repo, task)
    task_id = max(ids.values(), default=0) + 1 if status != "resolved" else 0
    if status == "resolved":
        verb = "Logged"
    elif status == "template":
        verb = "Created Template"
    else:
        verb = "Added"
    if context_words(repo) and "--" not in raw_args:
        print(f"\033[33mActive context: {' '.join(context_words(repo))}\033[0m")
    print(f"\n{verb} {task_id}: {task.summary}")
    git_commit(repo, f"{verb} {task_id}: {task.summary}")


def change_status(repo, ids, new_status, extra_note=None):
    tasks = load_tasks(repo)
    targets = task_by_ids(tasks, ids)
    if not targets:
        print("[]", end="")
        return
    ids_map = open_id_map(tasks)
    for task in targets:
        old_status = task.status
        old_id = ids_map.get(task.uuid, 0)
        delete_task_file(repo, task)
        task.status = new_status
        if new_status == "resolved":
            task.resolved = now_ts()
            if extra_note:
                task.notes = (task.notes + ("\n" if task.notes and not task.notes.endswith("\n") else "") + extra_note).strip("\n")
        write_task(repo, task)
        if new_status == "active":
            verb = "Started"
        elif new_status == "paused" and old_status == "active":
            verb = "Stopped"
        elif new_status == "resolved":
            verb = "Resolved"
        else:
            verb = "Stopped"
        print(f"\n{verb} {old_id}: {task.summary}")
        git_commit(repo, f"{verb} {old_id}: {task.summary}")


def cmd_modify(repo, ids, args):
    tasks = load_tasks(repo)
    targets = task_by_ids(tasks, ids)
    attrs = parse_attrs(args)
    ids_map = open_id_map(tasks)
    for task in targets:
        for tag in attrs["tags_add"]:
            if tag not in task.tags:
                task.tags.append(tag)
        for tag in attrs["tags_remove"]:
            if tag in task.tags:
                task.tags.remove(tag)
        if attrs["project"] is not None:
            task.project = attrs["project"]
        if attrs["priority"] is not None:
            task.priority = attrs["priority"]
        if attrs["due"] is not None:
            task.due = attrs["due"]
        write_task(repo, task)
        task_id = ids_map.get(task.uuid, 0)
        print(f"\nModified {task_id}: {task.summary}")
        git_commit(repo, f"Modified {task_id}: {task.summary}")


def cmd_note(repo, ids, args):
    tasks = load_tasks(repo)
    targets = task_by_ids(tasks, ids)
    ids_map = open_id_map(tasks)
    text = " ".join(args)
    for task in targets:
        if text:
            task.notes = task.notes + ("\n" if task.notes and not task.notes.endswith("\n") else "") + text
        write_task(repo, task)
        task_id = ids_map.get(task.uuid, 0)
        print(f"\nNoted {task_id}: {task.summary}")
        git_commit(repo, f"Noted {task_id}: {task.summary}")


def cmd_remove(repo, ids):
    tasks = load_tasks(repo)
    targets = task_by_ids(tasks, ids)
    ids_map = open_id_map(tasks)
    for task in targets:
        task_id = ids_map.get(task.uuid, 0)
        delete_task_file(repo, task)
        print(f"\nRemoved {task_id}: {task.summary}")
        git_commit(repo, f"Removed {task_id}: {task.summary}")


def list_for_command(tasks, command):
    if command in ("show-open", "next"):
        return [t for t in tasks if t.status in ("pending", "active", "paused")]
    if command == "show-active":
        return [t for t in tasks if t.status == "active"]
    if command == "show-paused":
        return [t for t in tasks if t.status == "paused"]
    if command == "show-resolved":
        return [t for t in tasks if t.status == "resolved"]
    if command == "show-templates":
        return [t for t in tasks if t.status == "template"]
    return [t for t in tasks if t.status in ("pending", "active", "paused")]


def filter_tasks(tasks, filters):
    attrs = parse_attrs(filters)
    text = attrs["summary"].lower()
    out = []
    for task in tasks:
        if attrs["project"] is not None and task.project != attrs["project"]:
            continue
        if attrs["priority"] is not None and task.priority != attrs["priority"]:
            continue
        if any(tag not in task.tags for tag in attrs["tags_add"]):
            continue
        if any(tag in task.tags for tag in attrs["tags_remove"]):
            continue
        if text and text not in (task.summary + "\n" + task.notes).lower():
            continue
        out.append(task)
    return out


def print_tasks(repo, command, filters):
    tasks = filter_tasks(list_for_command(load_tasks(repo), command), apply_context_args(repo, filters))
    tasks.sort(key=lambda t: (PRIORITIES.get(t.priority, 2), t.created))
    ids = open_id_map(load_tasks(repo))
    data = [t.to_json(ids.get(t.uuid, 0)) for t in tasks]
    print(json.dumps(data, indent=2), end="")


def show_tags(repo):
    tags = sorted({tag for task in load_tasks(repo) for tag in task.tags if task.status != "resolved"})
    if tags:
        print("\n".join(tags))


def show_projects(repo):
    tasks = [t for t in load_tasks(repo) if t.project]
    ids = {}
    projects = []
    for name in sorted({t.project for t in tasks}):
        group = [t for t in tasks if t.project == name]
        open_group = [t for t in group if t.status != "resolved"]
        first = min(group, key=lambda t: t.created)
        best = min(group, key=lambda t: PRIORITIES.get(t.priority, 2))
        projects.append({
            "name": name,
            "taskCount": len(open_group),
            "resolvedCount": len([t for t in group if t.status == "resolved"]),
            "active": any(t.status == "active" for t in group),
            "created": first.created,
            "resolved": ZERO_TIME,
            "priority": best.priority,
        })
    print(json.dumps(projects, indent=2), end="")


def main(argv):
    repo = repo_path()
    ensure_repo(repo)
    if not argv:
        print_tasks(repo, "next", [])
        return 0
    if argv[0] in ("help", "--help", "-h"):
        print("Usage: dstask [id...] <cmd> [task summary/filter]")
        return 0
    if argv[0] in ("version", "--version"):
        print("Version: Unknown\nGit commit: Unknown\nBuild date: Unknown")
        return 0
    ids, cmd, args = split_command(argv)
    if cmd in ("help", "--help", "-h"):
        print("Usage: dstask [id...] <cmd> [task summary/filter]")
        return 0
    if cmd in ("version", "--version"):
        print("Version: Unknown\nGit commit: Unknown\nBuild date: Unknown")
        return 0
    if cmd == "add":
        cmd_add(repo, args)
        return 0
    if cmd == "log":
        cmd_add(repo, args, "resolved")
        return 0
    if cmd == "template":
        cmd_add(repo, args, "template")
        return 0
    if cmd == "context":
        cmd_context(repo, args)
        return 0
    if cmd == "start":
        change_status(repo, ids, "active")
        return 0
    if cmd == "stop":
        change_status(repo, ids, "paused")
        return 0
    if cmd == "done":
        change_status(repo, ids, "resolved", " ".join(args).strip())
        return 0
    if cmd == "modify":
        cmd_modify(repo, ids, args)
        return 0
    if cmd == "note":
        cmd_note(repo, ids, args)
        return 0
    if cmd == "remove":
        cmd_remove(repo, ids)
        return 0
    if cmd == "show-tags":
        show_tags(repo)
        return 0
    if cmd == "show-projects":
        show_projects(repo)
        return 0
    if cmd in ("show-open", "next", "show-active", "show-paused", "show-resolved", "show-templates"):
        print_tasks(repo, cmd, args)
        return 0
    print_tasks(repo, "next", argv)
    return 0


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
