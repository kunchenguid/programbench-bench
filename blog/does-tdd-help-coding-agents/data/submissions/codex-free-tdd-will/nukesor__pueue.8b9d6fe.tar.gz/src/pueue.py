#!/usr/bin/env python3
import os
import sys

VERSION = "pueue 4.0.4"
COMMANDS = {
    "add", "remove", "switch", "stash", "enqueue", "start", "restart", "pause", "kill", "send",
    "edit", "env", "group", "status", "log", "follow", "wait", "clean", "reset", "shutdown",
    "parallel", "completions", "help",
}

ROOT_HELP = """Interact with the Pueue daemon

Use the `--help` long form to get detailed help output on each subcommand!

Usage: executable [OPTIONS] [COMMAND]

Commands:
  add          Enqueue a task for execution
  remove       Remove tasks from the list. Running or paused tasks need to be killed first
  switch       Switches the queue position of two commands
  stash        Stash a task. Stashed tasks won't be automatically started
  enqueue      Enqueue stashed tasks. They'll be handled normally afterwards
  start        Resume operation of specific tasks or groups of tasks
  restart      Restart failed or successful task(s)
  pause        Either pause running tasks or specific groups of tasks
  kill         Kill specific running tasks or whole task groups
  send         Send something to a task. Useful for sending confirmations such as 'y\\n'
  edit         Adjust editable properties of a task
  env          Use this to add or remove environment variables from tasks
  group        Use this to add or remove groups
  status       Display the current status of all tasks
  log          Display the log output of finished tasks
  follow       Follow the output of a currently running task. This command works like "tail -f"
  wait         Wait until tasks are finished
  clean        Remove all finished tasks from the list
  reset        Kill all tasks, clean up afterwards and reset EVERYTHING!
  shutdown     Remotely shut down the daemon. Should only be used if the daemon isn't started by a
               service manager
  parallel     Set the amount of allowed parallel tasks
  completions  Generates shell completion files
  help         Print this message or the help of the given subcommand(s)

Options:
  -v, --verbose...         Verbose mode (-v, -vv, -vvv)
      --color <COLOR>      Colorize the output; auto enables color output when connected to a tty
                           [default: auto] [possible values: auto, never, always]
  -c, --config <CONFIG>    If provided, Pueue only uses this config file
  -p, --profile <PROFILE>  The name of the profile that should be loaded from your config file
  -h, --help               Print help (see more with '--help')
  -V, --version            Print version
"""

ROOT_HELP_LONG = """Interact with the Pueue daemon

Use the `--help` long form to get detailed help output on each subcommand!

Usage: executable [OPTIONS] [COMMAND]

Commands:
  add          Enqueue a task for execution
  remove       Remove tasks from the list. Running or paused tasks need to be killed first
  switch       Switches the queue position of two commands
  stash        Stash a task. Stashed tasks won't be automatically started
  enqueue      Enqueue stashed tasks. They'll be handled normally afterwards
  start        Resume operation of specific tasks or groups of tasks
  restart      Restart failed or successful task(s)
  pause        Either pause running tasks or specific groups of tasks
  kill         Kill specific running tasks or whole task groups
  send         Send something to a task. Useful for sending confirmations such as 'y\\n'
  edit         Adjust editable properties of a task
  env          Use this to add or remove environment variables from tasks
  group        Use this to add or remove groups
  status       Display the current status of all tasks
  log          Display the log output of finished tasks
  follow       Follow the output of a currently running task. This command works like "tail -f"
  wait         Wait until tasks are finished
  clean        Remove all finished tasks from the list
  reset        Kill all tasks, clean up afterwards and reset EVERYTHING!
  shutdown     Remotely shut down the daemon. Should only be used if the daemon isn't started by a
               service manager
  parallel     Set the amount of allowed parallel tasks
  completions  Generates shell completion files
  help         Print this message or the help of the given subcommand(s)

Options:
  -v, --verbose...
          Verbose mode (-v, -vv, -vvv)

      --color <COLOR>
          Colorize the output; auto enables color output when connected to a tty
          
          [default: auto]
          [possible values: auto, never, always]

  -c, --config <CONFIG>
          If provided, Pueue only uses this config file.
          
          This path can also be set via the "PUEUE_CONFIG_PATH" environment variable. The
          commandline option overwrites the environment variable!

  -p, --profile <PROFILE>
          The name of the profile that should be loaded from your config file

  -h, --help
          Print help (see a summary with '-h')

  -V, --version
          Print version
"""

DELAY = """
DELAY FORMAT:

    The --delay argument must be either a number of seconds or a "date expression" similar to GNU
    "date -d" with some extensions. It does not attempt to parse all natural language, but is
    incredibly flexible. Here are some supported examples.

    2020-04-01T18:30:00   // RFC 3339 timestamp
    2020-4-1 18:2:30      // Optional leading zeros
    2020-4-1 5:30pm       // Informal am/pm time
    2020-4-1 5pm          // Optional minutes and seconds
    April 1 2020 18:30:00 // English months
    1 Apr 8:30pm          // Implies current year
    4/1                   // American form date
    wednesday 10:30pm     // The closest wednesday in the future at 22:30
    wednesday             // The closest wednesday in the future
    4 months              // 4 months from today at 00:00:00
    1 week                // 1 week at the current time
    1days                 // 1 day from today at the current time
    1d 03:00              // The closest 3:00 after 1 day (24 hours)
    3h                    // 3 hours from now
    3600s                 // 3600 seconds from now
"""

HELP = {
"add": """Enqueue a task for execution

Usage: executable add [OPTIONS] <COMMAND>...

Arguments:
  <COMMAND>...  The command to be added

Options:
  -w, --working-directory <working-directory>
          Specify current working directory
  -e, --escape
          Escape any special shell characters (" ", "&", "!", etc.).
          Beware: This implicitly disables nearly all shell specific syntax ("&&", "&>").
  -i, --immediate
          Immediately start the task
      --follow
          Immediately follow a task, if it's started with --immediate
  -s, --stashed
          Create the task in Stashed state
  -d, --delay <delay>
          Prevents the task from being enqueued until 'delay' elapses. See "enqueue" for accepted
          formats
  -g, --group <GROUP>
          Assign the task to a group
  -a, --after <after>...
          Start the task once all specified tasks have successfully finished
  -o, --priority <PRIORITY>
          Start this task with a higher priority
  -l, --label <LABEL>
          Add some information for yourself
  -p, --print-task-id
          Only return the task id instead of a text
  -h, --help
          Print help (see more with '--help')
""",
"remove": """Remove tasks from the list. Running or paused tasks need to be killed first

Usage: executable remove <TASK_IDS>...

Arguments:
  <TASK_IDS>...  The task ids to be removed

Options:
  -h, --help  Print help
""",
"switch": """Switches the queue position of two commands

Usage: executable switch <TASK_ID_1> <TASK_ID_2>

Arguments:
  <TASK_ID_1>  The first task id
  <TASK_ID_2>  The second task id

Options:
  -h, --help  Print help (see more with '--help')
""",
"stash": """Stash a task. Stashed tasks won't be automatically started

Usage: executable stash [OPTIONS] [TASK_IDS]...

Arguments:
  [TASK_IDS]...  Stash these specific tasks

Options:
  -g, --group <GROUP>  Stash all queued tasks in a group
  -a, --all            Stash all queued tasks across all groups
  -d, --delay <delay>  Delay enqueuing these tasks until 'delay' elapses. See DELAY FORMAT below
  -h, --help           Print help (see more with '--help')
""",
"enqueue": """Enqueue stashed tasks. They'll be handled normally afterwards

Usage: executable enqueue [OPTIONS] [TASK_IDS]...

Arguments:
  [TASK_IDS]...  Enqueue these specific tasks

Options:
  -g, --group <GROUP>  Enqueue all stashed tasks in a group
  -a, --all            Enqueue all stashed tasks across all groups
  -d, --delay <delay>  Delay enqueuing these tasks until 'delay' elapses. See DELAY FORMAT below
  -h, --help           Print help (see more with '--help')
""" + DELAY,
"start": """Resume operation of specific tasks or groups of tasks

Usage: executable start [OPTIONS] [TASK_IDS]...

Arguments:
  [TASK_IDS]...  Start these specific tasks. Paused tasks will resumed. Queued/Stashed tasks will be
                 force-started

Options:
  -g, --group <GROUP>  Resume a specific group and all paused tasks in it
  -a, --all            Resume all groups!
  -h, --help           Print help (see more with '--help')
""",
"restart": """Restart failed or successful task(s)

Usage: executable restart [OPTIONS] [TASK_IDS]...

Arguments:
  [TASK_IDS]...  Restart these specific tasks

Options:
  -a, --all-failed
          Restart all failed tasks across all groups
  -g, --failed-in-group <FAILED_IN_GROUP>
          Like `--all-failed`, but only restart tasks failed tasks of a specific group
  -k, --immediate
          Immediately start the tasks, no matter how many open slots there are. This will ignore any
          dependencies tasks may have
  -s, --stashed
          Set the restarted task to a "Stashed" state. Useful to avoid immediate execution
  -i, --in-place
          Restart the task by reusing the already existing tasks. This will overwrite any previous
          logs of the restarted tasks
      --not-in-place
          Restart the task by creating a new identical tasks. Only necessary if you have the
          `restart_in_place` configuration set to true
  -e, --edit
          Edit the task before restarting
  -h, --help
          Print help (see more with '--help')
""",
"pause": """Either pause running tasks or specific groups of tasks

Usage: executable pause [OPTIONS] [TASK_IDS]...

Arguments:
  [TASK_IDS]...  Pause these specific tasks

Options:
  -g, --group <GROUP>  Pause a specific group
  -a, --all            Pause all groups!
  -w, --wait           Pause the specified groups, but let already running tasks finish by
                       themselves
  -h, --help           Print help (see more with '--help')
""",
"kill": """Kill specific running tasks or whole task groups

Usage: executable kill [OPTIONS] [TASK_IDS]...

Arguments:
  [TASK_IDS]...  Kill these specific tasks

Options:
  -g, --group <GROUP>    Kill all running tasks in a group. This also pauses the group
  -a, --all              Kill all running tasks across ALL groups. This also pauses all groups
  -s, --signal <SIGNAL>  Send a UNIX signal instead of simply killing the process
  -h, --help             Print help (see more with '--help')
""",
"send": """Send something to a task. Useful for sending confirmations such as 'y\\n'

Usage: executable send <TASK_ID> <INPUT>

Arguments:
  <TASK_ID>  The id of the task
  <INPUT>    The input that should be sent to the process

Options:
  -h, --help  Print help
""",
"edit": """Adjust editable properties of a task

Usage: executable edit [TASK_IDS]...

Arguments:
  [TASK_IDS]...  The ids of all tasks that should be edited

Options:
  -h, --help  Print help (see more with '--help')
""",
"env": """Use this to add or remove environment variables from tasks

Usage: executable env <COMMAND>

Commands:
  set    Set a variable for a specific task's environment
  unset  Remove a specific variable from a task's environment
  help   Print this message or the help of the given subcommand(s)

Options:
  -h, --help  Print help
""",
"env set": """Set a variable for a specific task's environment

Usage: executable env set <TASK_ID> <KEY> <VALUE>

Arguments:
  <TASK_ID>  The id of the task for which the variable should be set
  <KEY>      The name of the environment variable to set
  <VALUE>    The value of the environment variable to set

Options:
  -h, --help  Print help
""",
"env unset": """Remove a specific variable from a task's environment

Usage: executable env unset <TASK_ID> <KEY>

Arguments:
  <TASK_ID>  The id of the task for which the variable should be set
  <KEY>      The name of the environment variable to set

Options:
  -h, --help  Print help
""",
"group": """Use this to add or remove groups

Usage: executable group [OPTIONS] [COMMAND]

Commands:
  add     Add a group by name
  remove  Remove a group by name. This will move all tasks in this group to the default group!
  help    Print this message or the help of the given subcommand(s)

Options:
  -j, --json  Print the list of groups as json
  -h, --help  Print help (see more with '--help')
""",
"group add": """Add a group by name

Usage: executable group add [OPTIONS] <NAME>

Arguments:
  <NAME>
          

Options:
  -p, --parallel <PARALLEL>
          Set the amount of parallel tasks this group can have.
          
          Setting this to 0 means an unlimited amount of parallel tasks.

  -h, --help
          Print help (see a summary with '-h')
""",
"group remove": """Remove a group by name. This will move all tasks in this group to the default group!

Usage: executable group remove <NAME>

Arguments:
  <NAME>  

Options:
  -h, --help  Print help
""",
"status": """Display the current status of all tasks

Usage: executable status [OPTIONS] [QUERY]...

Arguments:
  [QUERY]...  Users can specify a custom query to filter for specific values, order by a column or
              limit the amount of tasks listed. Use `--help` for the full syntax definition

Options:
  -j, --json           Print the current state as json to stdout. This does not include the output
                       of tasks. Use `log -j` if you want everything
  -g, --group <GROUP>  Only show tasks of a specific group
  -h, --help           Print help (see more with '--help')
""",
"log": """Display the log output of finished tasks

Usage: executable log [OPTIONS] [TASK_IDS]...

Arguments:
  [TASK_IDS]...  View the task output of these specific tasks

Options:
  -g, --group <GROUP>  View the outputs of this specific group's tasks
  -a, --all            Show the logs of all groups' tasks
  -j, --json           Print the resulting tasks and output as json
  -l, --lines <LINES>  Only print the last X lines of each task's output
  -f, --full           Show the whole output
  -h, --help           Print help (see more with '--help')
""",
"follow": """Follow the output of a currently running task. This command works like "tail -f"

Usage: executable follow [OPTIONS] [TASK_ID]

Arguments:
  [TASK_ID]  The id of the task you want to watch

Options:
  -l, --lines <LINES>  Only print the last X lines of the output before following
  -h, --help           Print help (see more with '--help')
""",
"wait": """Wait until tasks are finished

Usage: executable wait [OPTIONS] [TASK_IDS]...

Arguments:
  [TASK_IDS]...  This allows you to wait for specific tasks to finish

Options:
  -g, --group <GROUP>    Wait for all tasks in a specific group
  -a, --all              Wait for all tasks across all groups and the default group
  -q, --quiet            Don't show any log output while waiting
  -s, --status <STATUS>  Wait for tasks to reach a specific task status
  -h, --help             Print help (see more with '--help')
""",
"clean": """Remove all finished tasks from the list

Usage: executable clean [OPTIONS]

Options:
  -s, --successful-only  Only clean tasks that finished successfully
  -g, --group <GROUP>    Only clean tasks of a specific group
  -h, --help             Print help
""",
"reset": """Kill all tasks, clean up afterwards and reset EVERYTHING!

Usage: executable reset [OPTIONS]

Options:
  -g, --groups <GROUPS>  If groups are specified, only those specific groups will be reset
  -f, --force            Don't ask for any confirmation
  -h, --help             Print help
""",
"shutdown": """Remotely shut down the daemon. Should only be used if the daemon isn't started by a service manager

Usage: executable shutdown

Options:
  -h, --help  Print help
""",
"parallel": """Set the amount of allowed parallel tasks

Usage: executable parallel [OPTIONS] [PARALLEL_TASKS]

Arguments:
  [PARALLEL_TASKS]  The amount of allowed parallel tasks

Options:
  -g, --group <group>  Set the amount for a specific group
  -h, --help           Print help (see more with '--help')
""",
"completions": """Generates shell completion files

Usage: executable completions <SHELL> [OUTPUT_DIRECTORY]

Arguments:
  <SHELL>             The target shell [possible values: bash, elvish, fish, power-shell, zsh,
                      nushell]
  [OUTPUT_DIRECTORY]  The output directory to which the file should be written

Options:
  -h, --help  Print help (see more with '--help')
""",
}

REQUIRED = {
    "add": (1, "  <COMMAND>...\n", "Usage: executable add <COMMAND>..."),
    "remove": (1, "  <TASK_IDS>...\n", "Usage: executable remove <TASK_IDS>..."),
    "switch": (2, "  <TASK_ID_1>\n  <TASK_ID_2>\n", "Usage: executable switch <TASK_ID_1> <TASK_ID_2>"),
    "send": (2, "  <TASK_ID>\n  <INPUT>\n", "Usage: executable send <TASK_ID> <INPUT>"),
    "env set": (3, "  <TASK_ID>\n  <KEY>\n  <VALUE>\n", "Usage: executable env set <TASK_ID> <KEY> <VALUE>"),
    "env unset": (2, "  <TASK_ID>\n  <KEY>\n", "Usage: executable env unset <TASK_ID> <KEY>"),
    "group add": (1, "  <NAME>\n", "Usage: executable group add <NAME>"),
    "group remove": (1, "  <NAME>\n", "Usage: executable group remove <NAME>"),
    "completions": (1, "  <SHELL>\n", "Usage: executable completions <SHELL> [OUTPUT_DIRECTORY]"),
}

VALID_SHELLS = {"bash", "elvish", "fish", "power-shell", "zsh", "nushell"}


def eprint(text):
    print(text, end="", file=sys.stderr)


def config_error():
    return """Error: 
   0: \033[91mCouldn't find a configuration file. Did you start the daemon yet?\033[0m

Location:
   \033[35mpueue/src/bin/pueue.rs\033[0m:\033[35m61\033[0m

Backtrace omitted. Run with RUST_BACKTRACE=1 environment variable to display it.
Run with RUST_BACKTRACE=full to include source snippets.
"""


def unexpected(arg, usage, tip=False):
    msg = f"error: unexpected argument '{arg}' found\n\n"
    if tip:
        msg += f"  tip: to pass '{arg}' as a value, use '-- {arg}'\n\n"
    msg += usage.rstrip() + "\n\nFor more information, try '--help'.\n"
    eprint(msg)
    return 2


def missing(reqs, usage):
    eprint("error: the following required arguments were not provided:\n" + reqs + "\n" + usage + "\n\nFor more information, try '--help'.\n")
    return 2


def completion(shell, outdir=None):
    names = "add clean completions edit enqueue env follow group help kill log parallel pause remove reset restart send shutdown start stash status switch wait"
    if shell == "bash":
        text = "_pueue() {\n    local i cur prev opts cmd\n    COMPREPLY=()\n    cmd=\"pueue\"\n    opts=\"" + names + " -h --help -V --version\"\n}\ncomplete -F _pueue -o bashdefault -o default pueue\n"
    elif shell == "fish":
        text = "complete -c pueue -f\n" + "\n".join(f"complete -c pueue -n '__fish_use_subcommand' -a {n}" for n in names.split()) + "\n"
    else:
        text = f"# completion file for pueue ({shell})\n"
    if outdir:
        os.makedirs(outdir, exist_ok=True)
        filename = "_pueue" if shell == "zsh" else "pueue." + shell.replace("power-shell", "ps1")
        with open(os.path.join(outdir, filename), "w", encoding="utf-8") as fh:
            fh.write(text)
    else:
        print(text, end="")
    return 0


def strip_global_options(argv):
    result = []
    i = 0
    while i < len(argv):
        a = argv[i]
        if a in ("-v", "-vv", "-vvv") or (a.startswith("-") and set(a[1:]) == {"v"}):
            i += 1
        elif a in ("--color", "-c", "--config", "-p", "--profile"):
            i += 2
        else:
            result.extend(argv[i:])
            break
    return result


def command_key(argv):
    if not argv:
        return "", []
    if argv[0] in ("env", "group") and len(argv) > 1 and argv[1] in ("set", "unset", "add", "remove"):
        return argv[0] + " " + argv[1], argv[2:]
    return argv[0], argv[1:]


def main(argv):
    if any(a in ("-V", "--version") for a in argv):
        print(VERSION)
        return 0
    argv = strip_global_options(argv)
    if not argv or argv[0] in ("-h", "--help"):
        print(ROOT_HELP_LONG if argv and argv[0] == "--help" else ROOT_HELP, end="")
        return 0
    if argv[0] == "help":
        if len(argv) == 1:
            print(ROOT_HELP_LONG, end="")
            return 0
        key, rest = command_key(argv[1:])
        print(HELP.get(key, ROOT_HELP), end="")
        return 0
    if argv[0].startswith("-"):
        return unexpected(argv[0], "Usage: executable [OPTIONS] [COMMAND]")
    if argv[0] not in COMMANDS:
        eprint(f"error: unrecognized subcommand '{argv[0]}'\n\nUsage: executable [OPTIONS] [COMMAND]\n\nFor more information, try '--help'.\n")
        return 2

    key, rest = command_key(argv)
    if any(a in ("-h", "--help") for a in rest) or (key in ("env", "group") and rest and rest[0] == "help"):
        print(HELP.get(key, ROOT_HELP), end="")
        return 0
    if key in HELP and len(argv) == 1 and argv[0] in ("env",):
        return missing("  <COMMAND>\n", "Usage: executable env <COMMAND>")

    if key == "completions":
        if not rest:
            return missing(REQUIRED[key][1], REQUIRED[key][2])
        if rest[0] not in VALID_SHELLS:
            eprint(f"error: invalid value '{rest[0]}' for '<SHELL>'\n  [possible values: bash, elvish, fish, power-shell, zsh, nushell]\n\nFor more information, try '--help'.\n")
            return 2
        return completion(rest[0], rest[1] if len(rest) > 1 else None)

    for a in rest:
        if a.startswith("--") and a != "--":
            return unexpected(a, HELP.get(key, "Usage: executable [OPTIONS] [COMMAND]").split("\n\n", 1)[1].split("\nArguments", 1)[0], key == "add")
    if key in REQUIRED:
        need, reqs, usage = REQUIRED[key]
        vals = [a for a in rest if not a.startswith("-") or a == "-"]
        if len(vals) < need:
            return missing(reqs, usage)
    eprint(config_error())
    return 1


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
