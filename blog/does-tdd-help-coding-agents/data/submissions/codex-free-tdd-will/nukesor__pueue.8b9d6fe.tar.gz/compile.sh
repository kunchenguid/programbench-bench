#!/bin/bash
set -e
cp src/pueue.py executable
chmod +x executable
