module tparse-reimpl

go 1.20
