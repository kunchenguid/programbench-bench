#!/bin/bash
set -euo pipefail
rm -f executable
go build -o executable .
chmod +x executable
