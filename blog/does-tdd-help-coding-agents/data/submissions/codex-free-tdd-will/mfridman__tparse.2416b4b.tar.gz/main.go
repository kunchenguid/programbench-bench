package main

import (
	"bufio"
	"encoding/json"
	"fmt"
	"io"
	"os"
	"sort"
	"strconv"
	"strings"
)

const helpText = `Usage:
    go test ./... -json | tparse [options...]
    go test [packages...] -json | tparse [options...]
    go test [packages...] -json > pkgs.out ; tparse [options...] -file pkgs.out

Options:
    -h                 Show help.
    -v                 Show version.
    -all               Display table event for pass and skip. (Failed items always displayed)
    -pass              Display table for passed tests.
    -skip              Display table for skipped tests.
    -notests           Display packages containing no test files or empty test files.
    -smallscreen       Split subtest names vertically to fit on smaller screens.
    -slow              Number of slowest tests to display. Default is 0, display all.
    -sort              Sort table output by attribute [name, elapsed, cover]. Default is name.
    -nocolor           Disable all colors. (NO_COLOR also supported)
    -format            The output format for tables [basic, plain, markdown]. Default is basic.
    -file              Read test output from a file.
    -follow            Follow raw output from go test to stdout.
    -follow-output     Write raw output from go test to a file (takes precedence over -follow).
    -include-timestamp Include timestamps in follow output. 
    -progress          Print a single summary line for each package. Useful for long running test suites.
    -compare           Compare against a previous test output file. (experimental)
    -trimpath          Remove path prefix from package names in output, simplifying their display.
`

type options struct {
	all, pass, skip, notests, smallscreen, follow, progress, includeTime, noColor bool
	slow                                                                          int
	sortBy, format, file, followOutput, trimPath, compare                         string
}

type event struct {
	Time    string
	Action  string
	Package string
	Test    string
	Elapsed float64
	Output  string
}

type testResult struct {
	status, name, pkg string
	elapsed           float64
	outputs           []string
}
type pkgResult struct {
	name             string
	status           string
	elapsed          float64
	cover            string
	pass, fail, skip int
	noTests          bool
	noTestsText      string
	tests            []*testResult
	failedText       string
	order            int
}

type state struct {
	pkgs  map[string]*pkgResult
	order []*pkgResult
	tests map[string]*testResult
}

func main() { os.Exit(run(os.Args[1:], os.Stdin, os.Stdout, os.Stderr)) }

func run(args []string, stdin io.Reader, stdout, stderr io.Writer) int {
	opt, ok := parseArgs(args, stdout)
	if !ok {
		return 0
	}
	var r io.Reader = stdin
	var f *os.File
	if opt.file != "" {
		var err error
		f, err = os.Open(opt.file)
		if err != nil {
			fmt.Fprintln(stderr, err)
			return 1
		}
		defer f.Close()
		r = f
	}
	st, parsed, failedParse := readEvents(r, stdout, opt)
	if parsed == 0 || failedParse {
		fmt.Fprintln(stdout, "no parsable events: Make sure to run go test with -json flag")
		return 1
	}
	finalize(st)
	out := render(st, opt)
	if !opt.noColor && os.Getenv("NO_COLOR") == "" {
		out = colorize(out, opt)
	}
	fmt.Fprint(stdout, out)
	if hasFailures(st) {
		return 1
	}
	return 0
}

func parseArgs(args []string, out io.Writer) (options, bool) {
	opt := options{format: "basic", sortBy: "name"}
	for i := 0; i < len(args); i++ {
		a := args[i]
		key, val, hasVal := strings.Cut(a, "=")
		take := func() string {
			if hasVal {
				return val
			}
			if i+1 < len(args) {
				i++
				return args[i]
			}
			return ""
		}
		switch key {
		case "-h", "--help":
			fmt.Fprint(out, helpText)
			return opt, false
		case "-v", "--version":
			fmt.Fprintln(out, "tparse version: (devel)")
			return opt, false
		case "-all":
			opt.all = true
		case "-pass":
			opt.pass = true
		case "-skip":
			opt.skip = true
		case "-notests":
			opt.notests = true
		case "-smallscreen":
			opt.smallscreen = true
		case "-nocolor":
			opt.noColor = true
		case "-follow":
			opt.follow = true
		case "-progress":
			opt.progress = true
		case "-include-timestamp":
			opt.includeTime = true
		case "-slow":
			n, _ := strconv.Atoi(take())
			opt.slow = n
		case "-sort":
			opt.sortBy = take()
		case "-format":
			opt.format = take()
			if opt.format == "" {
				opt.format = "basic"
			}
		case "-file":
			opt.file = take()
		case "-follow-output":
			opt.followOutput = take()
		case "-trimpath":
			opt.trimPath = take()
		case "-compare":
			opt.compare = take()
		default:
		}
	}
	return opt, true
}

func readEvents(r io.Reader, out io.Writer, opt options) (*state, int, bool) {
	st := &state{pkgs: map[string]*pkgResult{}, tests: map[string]*testResult{}}
	scanner := bufio.NewScanner(r)
	scanner.Buffer(make([]byte, 1024), 1024*1024)
	parsed := 0
	failedParse := false
	var followFile *os.File
	if opt.followOutput != "" {
		followFile, _ = os.Create(opt.followOutput)
		defer followFile.Close()
	}
	for scanner.Scan() {
		line := scanner.Bytes()
		if len(strings.TrimSpace(string(line))) == 0 {
			continue
		}
		var ev event
		if err := json.Unmarshal(line, &ev); err != nil {
			failedParse = true
			continue
		}
		if ev.Action == "" || ev.Package == "" {
			continue
		}
		parsed++
		p := st.pkg(ev.Package)
		if ev.Action == "output" {
			if strings.Contains(ev.Output, "[no test files]") {
				p.noTests = true
				p.noTestsText = "[no test files]"
			}
			if strings.Contains(ev.Output, "coverage:") {
				p.cover = extractCoverage(ev.Output)
			}
			if ev.Test != "" {
				t := st.test(ev.Package, ev.Test)
				if !strings.HasPrefix(ev.Output, "=== RUN") {
					t.outputs = append(t.outputs, ev.Output)
				}
			}
			if opt.follow || followFile != nil {
				s := ev.Output
				if opt.includeTime && ev.Time != "" {
					s = ev.Time + " " + s
				}
				if followFile != nil {
					followFile.WriteString(s)
				} else {
					fmt.Fprint(out, s)
				}
			}
			continue
		}
		switch ev.Action {
		case "pass", "fail", "skip":
			if ev.Test != "" {
				t := st.test(ev.Package, ev.Test)
				t.status = strings.ToUpper(ev.Action)
				t.elapsed = ev.Elapsed
			} else {
				p.elapsed = ev.Elapsed
				p.status = strings.ToUpper(ev.Action)
			}
		}
	}
	return st, parsed, failedParse
}

func (st *state) pkg(name string) *pkgResult {
	if p := st.pkgs[name]; p != nil {
		return p
	}
	p := &pkgResult{name: name, cover: "--", order: len(st.order)}
	st.pkgs[name] = p
	st.order = append(st.order, p)
	return p
}
func (st *state) test(pkg, name string) *testResult {
	key := pkg + "\x00" + name
	if t := st.tests[key]; t != nil {
		return t
	}
	p := st.pkg(pkg)
	t := &testResult{name: name, pkg: pkg}
	st.tests[key] = t
	p.tests = append(p.tests, t)
	return t
}

func finalize(st *state) {
	for _, p := range st.order {
		for _, t := range p.tests {
			switch t.status {
			case "PASS":
				p.pass++
			case "FAIL":
				p.fail++
			case "SKIP":
				p.skip++
			}
		}
		if p.status == "" {
			if p.fail > 0 {
				p.status = "FAIL"
			} else if p.noTests {
				p.status = "NOTEST"
			} else {
				p.status = "PASS"
			}
		}
		var b strings.Builder
		for _, t := range p.tests {
			if t.status == "FAIL" {
				b.WriteString(formatFailOutput(t.outputs))
			}
		}
		p.failedText = b.String()
	}
}

func formatFailOutput(lines []string) string {
	var heads, rest []string
	for _, l := range lines {
		if strings.HasPrefix(l, "--- FAIL:") || strings.HasPrefix(l, "panic:") {
			heads = append(heads, l)
		} else if strings.TrimSpace(l) != "" {
			rest = append(rest, l)
		}
	}
	if len(heads) > 0 && len(rest) > 0 {
		return strings.Join(heads, "") + "\n" + strings.Join(rest, "")
	}
	return strings.Join(append(heads, rest...), "")
}

func extractCoverage(s string) string {
	idx := strings.Index(s, "coverage:")
	if idx < 0 {
		return "--"
	}
	fields := strings.Fields(s[idx+len("coverage:"):])
	if len(fields) > 0 {
		return fields[0]
	}
	return "--"
}
func hasFailures(st *state) bool {
	for _, p := range st.order {
		if p.status == "FAIL" || p.fail > 0 {
			return true
		}
	}
	return false
}
func dispPkg(p string, opt options) string {
	if opt.trimPath != "" {
		return strings.TrimPrefix(p, opt.trimPath)
	}
	if opt.smallscreen {
		parts := strings.Split(strings.TrimSuffix(p, "/"), "/")
		return parts[len(parts)-1]
	}
	return p
}

func colorize(out string, opt options) string {
	if opt.format == "markdown" {
		out = strings.ReplaceAll(out, "|  PASS  |", "| 🟢 PASS |")
		out = strings.ReplaceAll(out, "|  SKIP  |", "| 🟡 SKIP |")
		out = strings.ReplaceAll(out, "|  FAIL  |", "| 🔴 FAIL |")
		out = strings.ReplaceAll(out, "## FAIL •", "## 🔴 FAIL •")
		return out
	}
	out = strings.ReplaceAll(out, "│  PASS  │", "│  \033[92mPASS\033[0m  │")
	out = strings.ReplaceAll(out, "│  SKIP  │", "│  \033[93mSKIP\033[0m  │")
	out = strings.ReplaceAll(out, "│  FAIL  │", "│  \033[91mFAIL\033[0m  │")
	out = strings.ReplaceAll(out, "│ NOTEST │", "│ \033[96mNOTEST\033[0m │")
	lines := strings.SplitAfter(out, "\n")
	for i, line := range lines {
		trim := strings.TrimSuffix(line, "\n")
		nl := ""
		if strings.HasSuffix(line, "\n") {
			nl = "\n"
		}
		if strings.HasPrefix(trim, "┏") || strings.HasPrefix(trim, "┗") {
			lines[i] = "\033[38;5;103m" + trim + "\033[0m" + nl
		} else if strings.HasPrefix(trim, "┃") && strings.HasSuffix(trim, "┃") {
			mid := strings.TrimSuffix(strings.TrimPrefix(trim, "┃"), "┃")
			mid = strings.Replace(mid, "FAIL", "\033[91m\033[91mFAIL\033[0m\033[0m", 1)
			lines[i] = "\033[38;5;103m┃\033[0m" + mid + "\033[38;5;103m┃\033[0m" + nl
		} else if strings.HasPrefix(trim, "--- FAIL:") {
			lines[i] = "\033[31m" + trim + "\033[0m" + nl
		}
	}
	return strings.Join(lines, "")
}

func render(st *state, opt options) string {
	var b strings.Builder
	if opt.all || opt.pass || opt.skip {
		b.WriteString(renderTests(st, opt))
	}
	for _, p := range st.order {
		if p.fail > 0 || p.status == "FAIL" {
			b.WriteString(renderFailure(p, opt))
		}
	}
	b.WriteString(renderPackages(st, opt))
	return b.String()
}

func visiblePackages(st *state, opt options) []*pkgResult {
	var ps []*pkgResult
	for _, p := range st.order {
		if p.noTests && !opt.notests {
			continue
		}
		if len(p.tests) == 0 && !p.noTests && p.status != "FAIL" {
			continue
		}
		ps = append(ps, p)
	}
	sort.SliceStable(ps, func(i, j int) bool { return ps[i].order < ps[j].order })
	return ps
}

func visibleTests(st *state, opt options) [][]string {
	rows := [][]string{}
	for _, p := range st.order {
		had := false
		ts := append([]*testResult(nil), p.tests...)
		for _, wantStatus := range []string{"PASS", "SKIP", "FAIL"} {
			bucket := []*testResult{}
			for _, t := range ts {
				if t.status == wantStatus {
					bucket = append(bucket, t)
				}
			}
			if opt.slow > 0 {
				sort.SliceStable(bucket, func(i, j int) bool { return bucket[i].elapsed > bucket[j].elapsed })
				if len(bucket) > opt.slow {
					bucket = bucket[:opt.slow]
				}
			}
			for _, t := range bucket {
				show := t.status == "FAIL" || opt.all || (opt.pass && t.status == "PASS") || (opt.skip && t.status == "SKIP")
				if !show {
					continue
				}
				rows = append(rows, []string{t.status, fmt.Sprintf("%.2f", t.elapsed), t.name, dispPkg(t.pkg, opt)})
				had = true
			}
		}
		if had {
			rows = append(rows, []string{"", "", "", ""})
		}
	}
	if len(rows) > 0 && rows[len(rows)-1][0] == "" {
		return rows
	}
	return rows
}

func renderTests(st *state, opt options) string {
	rows := visibleTests(st, opt)
	if len(rows) == 0 {
		return ""
	}
	if opt.format == "markdown" {
		var b strings.Builder
		for _, p := range st.order {
			prs := [][]string{}
			for _, r := range rows {
				if r[3] == dispPkg(p.name, opt) && r[2] != "" {
					prs = append(prs, r)
				}
			}
			if len(prs) == 0 {
				continue
			}
			fmt.Fprintf(&b, "## 📦 Package **`%s`**\n\nTests: ✓ %d passed | %d skipped | %d failed\n\n<details>\n\n<summary>Click for test summary</summary>\n\n", dispPkg(p.name, opt), p.pass, p.skip, p.fail)
			b.WriteString(markdownTable([]string{"Status", "Elapsed", "Test"}, mapRows(prs, []int{0, 1, 2})))
			b.WriteString("</details>\n\n\n")
		}
		return b.String()
	}
	if opt.format == "plain" {
		return plainTable([]string{"Status", "Elapsed", "Test", "Package"}, rows)
	}
	return boxTable([]string{"Status", "Elapsed", "Test", "Package"}, rows)
}

func renderFailure(p *pkgResult, opt options) string {
	if opt.format == "markdown" {
		return fmt.Sprintf("## FAIL • %s\n\n```\n%s\n```\n\n", p.name, p.failedText)
	}
	title := "   FAIL  package: " + p.name + "   "
	line := strings.Repeat("━", runeLen(title))
	return "┏" + line + "┓\n┃" + title + "┃\n┗" + line + "┛\n\n" + p.failedText + "\n"
}

func renderPackages(st *state, opt options) string {
	ps := visiblePackages(st, opt)
	if len(ps) == 0 {
		return ""
	}
	rows := [][]string{}
	for _, p := range ps {
		status := p.status
		if p.noTests {
			status = "NOTEST"
		}
		pass, fail, skip := fmt.Sprint(p.pass), fmt.Sprint(p.fail), fmt.Sprint(p.skip)
		if p.noTests {
			pass, fail, skip = "--", "--", "--"
		}
		rows = append(rows, []string{status, fmt.Sprintf("%.2fs", p.elapsed), dispPkg(p.name, opt), p.cover, pass, fail, skip})
		if p.noTests && p.noTestsText != "" {
			rows = append(rows, []string{"", "", p.noTestsText, "", "", "", ""})
		}
	}
	headers := []string{"Status", "Elapsed", "Package", "Cover", "Pass", "Fail", "Skip"}
	if opt.format == "markdown" {
		return markdownTable(headers, rows)
	}
	if opt.format == "plain" {
		return plainTable(headers, rows)
	}
	return boxTable(headers, rows)
}

func mapRows(rows [][]string, idx []int) [][]string {
	out := [][]string{}
	for _, r := range rows {
		if r[0] == "" {
			continue
		}
		nr := []string{}
		for _, i := range idx {
			nr = append(nr, r[i])
		}
		out = append(out, nr)
	}
	return out
}

func colWidths(headers []string, rows [][]string) []int {
	w := make([]int, len(headers))
	for i, h := range headers {
		w[i] = runeLen(h)
	}
	for _, r := range rows {
		for i, c := range r {
			if i < len(w) && runeLen(c) > w[i] {
				w[i] = runeLen(c)
			}
		}
	}
	return w
}
func runeLen(s string) int { return len([]rune(s)) }
func center(s string, w int) string {
	n := w - runeLen(s)
	if n < 0 {
		n = 0
	}
	l := n / 2
	r := n - l
	return strings.Repeat(" ", l) + s + strings.Repeat(" ", r)
}
func left(s string, w int) string {
	n := w - runeLen(s)
	if n < 0 {
		n = 0
	}
	return s + strings.Repeat(" ", n)
}

func isTextCol(headers []string, i int) bool {
	if i >= len(headers) {
		return false
	}
	return headers[i] == "Test" || headers[i] == "Package"
}

func fmtCell(headers []string, i int, s string, w int, header bool) string {
	if header || !isTextCol(headers, i) {
		return center(s, w)
	}
	return left(s, w)
}

func boxTable(headers []string, rows [][]string) string {
	w := colWidths(headers, rows)
	var b strings.Builder
	border := func(l, mid, r, fill string) {
		b.WriteString(l)
		for i, x := range w {
			if i > 0 {
				b.WriteString(mid)
			}
			b.WriteString(strings.Repeat(fill, x+2))
		}
		b.WriteString(r + "\n")
	}
	border("╭", "┬", "╮", "─")
	b.WriteString("│")
	for i, h := range headers {
		b.WriteString(" " + fmtCell(headers, i, h, w[i], true) + " │")
	}
	b.WriteByte('\n')
	border("├", "┼", "┤", "─")
	for _, r := range rows {
		b.WriteString("│")
		for i := range headers {
			c := ""
			if i < len(r) {
				c = r[i]
			}
			b.WriteString(" " + fmtCell(headers, i, c, w[i], false) + " │")
		}
		b.WriteByte('\n')
	}
	border("╰", "┴", "╯", "─")
	return b.String()
}

func plainTable(headers []string, rows [][]string) string {
	w := colWidths(headers, rows)
	var b strings.Builder
	for i, h := range headers {
		b.WriteString("  " + fmtCell(headers, i, h, w[i], true) + " ")
	}
	b.WriteString("\n")
	b.WriteString(strings.Repeat(" ", sum(w)+3*len(w)) + "\n")
	for _, r := range rows {
		for i := range headers {
			c := ""
			if i < len(r) {
				c = r[i]
			}
			b.WriteString("  " + fmtCell(headers, i, c, w[i], false) + " ")
		}
		b.WriteString("\n")
	}
	return b.String()
}

func sum(xs []int) int {
	n := 0
	for _, x := range xs {
		n += x
	}
	return n
}

func markdownTable(headers []string, rows [][]string) string {
	w := colWidths(headers, rows)
	var b strings.Builder
	write := func(r []string, header bool) {
		b.WriteString("|")
		for i := range headers {
			c := ""
			if i < len(r) {
				c = r[i]
			}
			b.WriteString(" " + fmtCell(headers, i, c, w[i], header) + " |")
		}
		b.WriteByte('\n')
	}
	write(headers, true)
	b.WriteString("|")
	for _, x := range w {
		b.WriteString(strings.Repeat("-", x+2) + "|")
	}
	b.WriteByte('\n')
	for _, r := range rows {
		write(r, false)
	}
	return b.String()
}
