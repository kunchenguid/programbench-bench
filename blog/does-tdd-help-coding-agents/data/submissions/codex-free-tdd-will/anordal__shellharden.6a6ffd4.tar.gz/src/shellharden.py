#!/usr/bin/env python3
import os
import re
import sys


HELP = """Shellharden: The corrective bash syntax highlighter.

Usage:
\tshellharden [options] [files]
\tcat files | shellharden [options] ''

Shellharden is a syntax highlighter and a tool to semi-automate the rewriting
of scripts to ShellCheck conformance, mainly focused on quoting.

Options:
\t--suggest         Output a colored diff suggesting changes.
\t--syntax          Output syntax highlighting with ANSI colors.
\t--syntax-suggest  Diff with syntax highlighting (default mode).
\t--transform       Output suggested changes.
\t--check           No output; exit with 2 if changes are suggested.
\t--replace         Replace file contents with suggested changes.
\t--                Don't treat further arguments as options.
\t-h|--help         Show help text.
\t--version         Show version.
"""


NAME_RE = re.compile(r"[A-Za-z_][A-Za-z0-9_]*")


def is_word_char(ch):
    return ch and not ch.isspace() and ch not in ";|&()<>"


def matching_paren(s, start):
    depth = 1
    i = start
    quote = None
    while i < len(s):
        c = s[i]
        if quote:
            if c == "\\":
                i += 2
                continue
            if c == quote:
                quote = None
            i += 1
            continue
        if c in "'\"":
            quote = c
        elif c == "(":
            depth += 1
        elif c == ")":
            depth -= 1
            if depth == 0:
                return i
        i += 1
    return -1


def transform_script(text):
    lines = text.splitlines(True)
    out = []
    heredoc = None
    for line in lines:
        body = line[:-1] if line.endswith("\n") else line
        nl = "\n" if line.endswith("\n") else ""
        if heredoc:
            out.append(line)
            if body == heredoc:
                heredoc = None
            continue
        new = transform_line(body)
        out.append(new + nl)
        marker = find_heredoc_marker(body)
        if marker:
            heredoc = marker
    return "".join(out)


def find_heredoc_marker(line):
    m = re.search(r"<<-?\s*(['\"]?)([A-Za-z_][A-Za-z0-9_]*)\1", line)
    return m.group(2) if m else None


def transform_line(line):
    if line.startswith("#!"):
        return line
    return transform_segment(line, None)


def transform_segment(s, stop):
    out = []
    i = 0
    prev_word = None
    bracket_test = False
    case_header = False
    case_pattern_line = bool(re.match(r"\s*\$", s))
    while i < len(s):
        if stop and s.startswith(stop, i):
            out.append(stop)
            i += len(stop)
            continue
        c = s[i]
        if c == "#":
            if i == 0 or (i > 0 and s[i - 1].isspace()):
                out.append(s[i:])
                break
        if c == "'":
            j = s.find("'", i + 1)
            if j < 0:
                out.append(s[i:])
                break
            out.append(s[i:j + 1])
            i = j + 1
            continue
        if c == '"':
            j = scan_double(s, i)
            out.append(s[i:j])
            i = j
            continue
        if s.startswith("[[", i):
            j = s.find("]]", i + 2)
            if j < 0:
                out.append(s[i:])
                break
            out.append(s[i:j + 2])
            i = j + 2
            continue
        if s.startswith("$((", i):
            j = matching_paren(s, i + 3)
            if j < 0:
                out.append(s[i:])
                break
            out.append(s[i:j + 1])
            i = j + 1
            continue
        if s.startswith("((", i):
            j = s.find("))", i + 2)
            if j < 0:
                out.append(s[i:])
                break
            out.append(s[i:j + 2])
            i = j + 2
            continue
        if s.startswith("[", i) and (i + 1 == len(s) or s[i + 1].isspace()):
            bracket_test = True
            out.append("[")
            i += 1
            continue
        if c == "]":
            bracket_test = False
            out.append(c)
            i += 1
            continue
        if s.startswith("-n", i) and bracket_test and boundary(s, i - 1) and boundary(s, i + 2):
            j = skip_ws(s, i + 2)
            exp = parse_expansion(s, j)
            if exp:
                text, end, _, _ = exp
                out.append(quote_expansion_text(text))
                out.append(' != ""')
                i = end
                prev_word = None
                continue
        if c == "$":
            exp = parse_expansion(s, i)
            if exp:
                text, end, kind, inner = exp
                assignment = is_assignment_context(s, i, prev_word)
                for_in = prev_word == "in"
                no_quote = case_header or (case_pattern_line and s[end:end + 1] == ")")
                if kind == "cmd":
                    inner_t = transform_segment(inner, None)
                    repl = "$(" + inner_t + ")"
                    out.append(repl if assignment or no_quote else '"' + repl + '"')
                elif kind == "btick":
                    inner_t = transform_segment(inner, None)
                    repl = "$(" + inner_t + ")"
                    out.append(repl if assignment or no_quote else '"' + repl + '"')
                elif kind == "special_safe":
                    out.append(text)
                elif assignment or no_quote:
                    out.append(text)
                elif for_in and kind in ("name", "braced_name"):
                    name = var_name_from_text(text)
                    out.append('"${' + name + '[@]}"')
                else:
                    out.append(quote_expansion_text(text))
                i = end
                prev_word = None
                continue
        if c == "`":
            j = s.find("`", i + 1)
            if j < 0:
                out.append(s[i:])
                break
            inner = s[i + 1:j]
            repl = '"$(' + transform_segment(inner, None) + ')"'
            out.append(repl)
            i = j + 1
            prev_word = None
            continue
        if c.isspace() or c in ";|&":
            out.append(c)
            i += 1
            continue
        m = NAME_RE.match(s, i)
        if m:
            word = m.group(0)
            out.append(word)
            if word == "case":
                case_header = True
            elif case_header and word == "in":
                case_header = False
            prev_word = word
            i = m.end()
            continue
        out.append(c)
        i += 1
    return "".join(out)


def scan_double(s, i):
    i += 1
    while i < len(s):
        if s[i] == "\\":
            i += 2
        elif s[i] == '"':
            return i + 1
        else:
            i += 1
    return len(s)


def boundary(s, i):
    return i < 0 or i >= len(s) or s[i].isspace()


def skip_ws(s, i):
    while i < len(s) and s[i].isspace():
        i += 1
    return i


def parse_expansion(s, i):
    if i >= len(s) or s[i] != "$":
        return None
    if s.startswith("$(", i) and not s.startswith("$((", i):
        j = matching_paren(s, i + 2)
        if j >= 0:
            return s[i:j + 1], j + 1, "cmd", s[i + 2:j]
    if i + 1 >= len(s):
        return None
    c = s[i + 1]
    if c in "?!#$":
        return s[i:i + 2], i + 2, "special_safe", None
    if c in "*@":
        return s[i:i + 2], i + 2, "at", None
    if c.isdigit():
        return s[i:i + 2], i + 2, "pos", None
    if c == "{":
        j = s.find("}", i + 2)
        if j < 0:
            return None
        body = s[i + 2:j]
        if body.startswith("#") and body.endswith("[@]"):
            return s[i:j + 1], j + 1, "special_safe", None
        if body.endswith("[@]") or body.endswith("[*]"):
            return s[i:j + 1], j + 1, "array", None
        if re.match(r"[A-Za-z_][A-Za-z0-9_]*$", body):
            return s[i:j + 1], j + 1, "braced_name", None
        return s[i:j + 1], j + 1, "braced_other", None
    m = NAME_RE.match(s, i + 1)
    if m:
        return s[i:m.end()], m.end(), "name", None
    return None


def var_name_from_text(text):
    if text.startswith("${"):
        body = text[2:-1]
        return body[:-3] if body.endswith("[@]") else body
    return text[1:]


def quote_expansion_text(text):
    if text == "$@":
        return '"$@"'
    if text == "$*":
        return '"$@"'
    return '"' + text + '"'


def is_assignment_context(s, i, prev_word):
    j = i - 1
    while j >= 0 and is_word_char(s[j]):
        j -= 1
    word_start = j + 1
    prefix = s[word_start:i]
    if "=" in prefix and re.match(r"[A-Za-z_][A-Za-z0-9_]*(\[[^]]+\])?=$", prefix):
        return True
    return prev_word in {"export", "local", "declare", "typeset", "readonly"} and "=" in prefix


def color_suggest(orig, new):
    if orig == new:
        return orig
    return new


def read_inputs(files):
    if not files:
        return [(None, sys.stdin.read())]
    result = []
    for f in files:
        if f == "":
            result.append((None, sys.stdin.read()))
        else:
            try:
                with open(f, "r", encoding="utf-8", errors="surrogateescape") as fh:
                    result.append((f, fh.read()))
            except OSError as e:
                print(f"{f}: {e.strerror} (os error {e.errno})", file=sys.stderr)
                sys.exit(1)
    return result


def main(argv):
    mode = "syntax-suggest"
    files = []
    parse_opts = True
    for arg in argv:
        if parse_opts and arg == "--":
            parse_opts = False
        elif parse_opts and arg in ("-h", "--help"):
            sys.stdout.write(HELP)
            return 0
        elif parse_opts and arg == "--version":
            print("4.3.1")
            return 0
        elif parse_opts and arg in ("--transform", "--check", "--replace", "--suggest", "--syntax", "--syntax-suggest"):
            mode = arg[2:]
        elif parse_opts and arg.startswith("-"):
            print(f"{arg}: No such option.", file=sys.stderr)
            return 3
        else:
            files.append(arg)

    inputs = read_inputs(files)
    changed = False
    outputs = []
    for path, text in inputs:
        new = transform_script(text)
        changed = changed or (new != text)
        if mode == "replace":
            if path is None:
                outputs.append(new)
            else:
                with open(path, "w", encoding="utf-8", errors="surrogateescape") as fh:
                    fh.write(new)
        elif mode == "check":
            pass
        elif mode in ("transform", "suggest", "syntax", "syntax-suggest"):
            outputs.append(text if mode == "syntax" else color_suggest(text, new))
    if outputs:
        sys.stdout.write("".join(outputs))
    if mode == "check" and changed:
        return 2
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
