#!/usr/bin/env python3
import os
import subprocess
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
BIN = ROOT / "executable"


def run_cmd(args, data=None):
    return subprocess.run([str(BIN), *args], input=data, text=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)


class ShellhardenBehavior(unittest.TestCase):
    def setUp(self):
        assert BIN.exists(), "run compile.sh first"

    def test_transform_quotes_common_unquoted_expansions(self):
        script = """#!/bin/bash
echo $foo
x=$bar
echo pre$foo post${bar}baz a-$b-c
for f in $files; do echo $f; done
[ -n $x ] && [ $x = \"$y\" ]
"""
        expected = """#!/bin/bash
echo "$foo"
x=$bar
echo pre"$foo" post"${bar}"baz a-"$b"-c
for f in "${files[@]}"; do echo "$f"; done
[ "$x" != "" ] && [ "$x" = "$y" ]
"""
        p = run_cmd(["--transform", ""], script)
        self.assertEqual(p.returncode, 0, p.stderr)
        self.assertEqual(p.stdout, expected)

    def test_check_and_replace_modes(self):
        with tempfile.TemporaryDirectory() as td:
            path = Path(td) / "script.sh"
            path.write_text("echo $x\n", encoding="utf-8")
            p = run_cmd(["--check", str(path)])
            self.assertEqual(p.returncode, 2)
            self.assertEqual(p.stdout, "")
            self.assertEqual(path.read_text(encoding="utf-8"), "echo $x\n")

            p = run_cmd(["--replace", str(path)])
            self.assertEqual(p.returncode, 0, p.stderr)
            self.assertEqual(path.read_text(encoding="utf-8"), 'echo "$x"\n')

            p = run_cmd(["--check", str(path)])
            self.assertEqual(p.returncode, 0)

    def test_help_version_and_bad_option(self):
        self.assertIn("Shellharden", run_cmd(["--help"]).stdout)
        self.assertEqual(run_cmd(["--version"]).stdout, "4.3.1\n")
        p = run_cmd(["--bad"])
        self.assertEqual(p.returncode, 3)
        self.assertEqual(p.stderr, "--bad: No such option.\n")

    def test_case_header_and_pattern_are_not_quoted(self):
        script = """case $word in
  $pat) echo $word ;;
esac
"""
        expected = """case $word in
  $pat) echo "$word" ;;
esac
"""
        p = run_cmd(["--transform", ""], script)
        self.assertEqual(p.returncode, 0, p.stderr)
        self.assertEqual(p.stdout, expected)

    def test_transform_handles_command_substitution_and_ignored_contexts(self):
        script = """echo ${arr[@]} ${#arr[@]} $? $$ $! $#
cmd $(echo $x) end
cmd `echo $x` end
if [[ $x == $y ]]; then echo $x; fi
(( x = $y + 1 ))
cat <<EOF
$x
EOF
"""
        expected = """echo "${arr[@]}" ${#arr[@]} $? $$ $! $#
cmd "$(echo "$x")" end
cmd "$(echo "$x")" end
if [[ $x == $y ]]; then echo "$x"; fi
(( x = $y + 1 ))
cat <<EOF
$x
EOF
"""
        p = run_cmd(["--transform", ""], script)
        self.assertEqual(p.returncode, 0, p.stderr)
        self.assertEqual(p.stdout, expected)


if __name__ == "__main__":
    unittest.main()
