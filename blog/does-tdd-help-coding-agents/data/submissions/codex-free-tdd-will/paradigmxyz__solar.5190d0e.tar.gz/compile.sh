#!/bin/bash
set -e
rm -f executable
cp src/solar.py executable
chmod +x executable
