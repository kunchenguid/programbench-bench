#!/usr/bin/env python3
import json
import os
import re
import sys


VERSION = "0.1.8"


HELP_LONG = """Blazingly fast Solidity compiler

Usage: executable [OPTIONS] [INPUT]...

Arguments:
  [INPUT]...
          Files to compile, or import remappings.
          
          `-` specifies standard input.
          
          Import remappings are specified as `[context:]prefix=path`. See <https://docs.soliditylang.org/en/latest/path-resolution.html#import-remapping>.

Options:
  -j, --threads <THREADS>
          Number of threads to use. Zero specifies the number of logical cores
          
          [default: 4]
          [aliases: --jobs]

      --evm-version <EVM_VERSION>
          EVM version
          
          [default: prague]
          [possible values: homestead, tangerineWhistle, spuriousDragon, byzantium, constantinople, petersburg, istanbul, berlin, london, paris, shanghai, cancun, prague, osaka]

      --stop-after <STOP_AFTER>
          Stop execution after the given compiler stage
          
          [possible values: parsing, lowering, analysis]

      --out-dir <OUT_DIR>
          Directory to write output files

      --emit <EMIT>
          Comma separated list of types of output for the compiler to emit
          
          [possible values: abi, hashes]

  -Z <FLAG>
          Unstable flags. WARNING: these are completely unstable, and may change at any time.
          
          See `-Zhelp` for more details.

  -h, --help
          Print help (see a summary with '-h')

  -V, --version
          Print version

Input options:
      --base-path <BASE_PATH>
          Use the given path as the root of the source tree

  -I, --include-path <INCLUDE_PATH>
          Directory to search for files.
          
          Can be used multiple times.

      --allow-paths <ALLOW_PATHS>
          Allow a given path for imports

Display options:
      --color <COLOR>
          Coloring
          
          [default: auto]
          [possible values: auto, always, never]

  -v, --verbose
          Use verbose output

      --pretty-json
          Pretty-print JSON output.
          
          Does not include errors. See `--pretty-json-err`.

      --pretty-json-err
          Pretty-print error JSON output

      --error-format <ERROR_FORMAT>
          How errors and other messages are produced
          
          [default: human]
          [possible values: human, json, rustc-json]

      --error-format-human <VALUE>
          Human-readable error message style
          
          [default: unicode]
          [possible values: ascii, unicode, short]

      --diagnostic-width <WIDTH>
          Terminal width for error message formatting

      --no-warnings
          Whether to disable warnings
"""


HELP_SHORT = """Blazingly fast Solidity compiler

Usage: executable [OPTIONS] [INPUT]...

Arguments:
  [INPUT]...  Files to compile, or import remappings

Options:
  -j, --threads <THREADS>          Number of threads to use. Zero specifies the number of logical cores [default: 4] [aliases: --jobs]
      --evm-version <EVM_VERSION>  EVM version [default: prague] [possible values: homestead, tangerineWhistle, spuriousDragon, byzantium, constantinople, petersburg, istanbul, berlin, london, paris, shanghai, cancun, prague, osaka]
      --stop-after <STOP_AFTER>    Stop execution after the given compiler stage [possible values: parsing, lowering, analysis]
      --out-dir <OUT_DIR>          Directory to write output files
      --emit <EMIT>                Comma separated list of types of output for the compiler to emit [possible values: abi, hashes]
  -Z <FLAG>                        Unstable flags. WARNING: these are completely unstable, and may change at any time
  -h, --help                       Print help (see more with '--help')
  -V, --version                    Print version

Input options:
      --base-path <BASE_PATH>        Use the given path as the root of the source tree
  -I, --include-path <INCLUDE_PATH>  Directory to search for files
      --allow-paths <ALLOW_PATHS>    Allow a given path for imports

Display options:
      --color <COLOR>                Coloring [default: auto] [possible values: auto, always, never]
  -v, --verbose                      Use verbose output
      --pretty-json                  Pretty-print JSON output
      --pretty-json-err              Pretty-print error JSON output
      --error-format <ERROR_FORMAT>  How errors and other messages are produced [default: human] [possible values: human, json, rustc-json]
      --error-format-human <VALUE>   Human-readable error message style [default: unicode]
      --diagnostic-width <WIDTH>     Terminal width for error message formatting
      --no-warnings                  Whether to disable warnings
"""


ZHELP = """error: List of all unstable flags.
WARNING: these are completely unstable, and may change at any time!

Options:
      -Zui-testing
          Enables UI testing mode

      -Ztrack-diagnostics
          Prints a note for every diagnostic that is emitted with the creation and emission location.
          
          This is enabled by default on debug builds.

      -Zparse-yul
          Enables parsing Yul files for testing

      -Zno-resolve-imports
          Disables import resolution

      -Zdump=<KIND[=PATHS...]>
          Print additional information about the compiler's internal state.
          
          Valid kinds are `ast` and `hir`.

      -Zast-stats
          Print AST stats

      -Zspan-visitor
          Run the span visitor after parsing

      -Zprint-max-storage-sizes
          Print contracts' max storage sizes

      -Ztypeck
          Type check the program. WIP

      -Zhelp
          Print help

Usage: solar [OPTIONS] [INPUT]...

For more information, try '--help'.
"""


ROT = [
    [0, 36, 3, 41, 18],
    [1, 44, 10, 45, 2],
    [62, 6, 43, 15, 61],
    [28, 55, 25, 21, 56],
    [27, 20, 39, 8, 14],
]
RC = [
    0x0000000000000001, 0x0000000000008082, 0x800000000000808A,
    0x8000000080008000, 0x000000000000808B, 0x0000000080000001,
    0x8000000080008081, 0x8000000000008009, 0x000000000000008A,
    0x0000000000000088, 0x0000000080008009, 0x000000008000000A,
    0x000000008000808B, 0x800000000000008B, 0x8000000000008089,
    0x8000000000008003, 0x8000000000008002, 0x8000000000000080,
    0x000000000000800A, 0x800000008000000A, 0x8000000080008081,
    0x8000000000008080, 0x0000000080000001, 0x8000000080008008,
]


def rol(x, n):
    return ((x << n) | (x >> (64 - n))) & ((1 << 64) - 1)


def keccak_f(st):
    for rc in RC:
        c = [st[x] ^ st[x + 5] ^ st[x + 10] ^ st[x + 15] ^ st[x + 20] for x in range(5)]
        d = [c[(x - 1) % 5] ^ rol(c[(x + 1) % 5], 1) for x in range(5)]
        for x in range(5):
            for y in range(5):
                st[x + 5 * y] ^= d[x]
        b = [0] * 25
        for x in range(5):
            for y in range(5):
                b[y + 5 * ((2 * x + 3 * y) % 5)] = rol(st[x + 5 * y], ROT[x][y])
        for x in range(5):
            for y in range(5):
                st[x + 5 * y] = b[x + 5 * y] ^ ((~b[((x + 1) % 5) + 5 * y]) & b[((x + 2) % 5) + 5 * y])
        st[0] ^= rc


def keccak256(data):
    rate = 136
    st = [0] * 25
    msg = bytearray(data)
    msg.append(0x01)
    while len(msg) % rate != rate - 1:
        msg.append(0)
    msg.append(0x80)
    for off in range(0, len(msg), rate):
        block = msg[off:off + rate]
        for i in range(rate // 8):
            st[i] ^= int.from_bytes(block[8 * i:8 * i + 8], "little")
        keccak_f(st)
    out = bytearray()
    while len(out) < 32:
        for i in range(rate // 8):
            out.extend(st[i].to_bytes(8, "little"))
        if len(out) < 32:
            keccak_f(st)
    return bytes(out[:32])


def strip_comments(s):
    s = re.sub(r"/\*.*?\*/", "", s, flags=re.S)
    s = re.sub(r"//.*", "", s)
    return s


def find_matching(s, pos, open_ch="{", close_ch="}"):
    depth = 0
    for i in range(pos, len(s)):
        if s[i] == open_ch:
            depth += 1
        elif s[i] == close_ch:
            depth -= 1
            if depth == 0:
                return i
    return -1


def split_top_level(s, sep=","):
    parts, start, depth = [], 0, 0
    for i, ch in enumerate(s):
        if ch in "([":
            depth += 1
        elif ch in ")]":
            depth -= 1
        elif ch == sep and depth == 0:
            parts.append(s[start:i].strip())
            start = i + 1
    tail = s[start:].strip()
    if tail:
        parts.append(tail)
    return parts


def top_level_semicolon_statements(s):
    out, start, depth = [], 0, 0
    for i, ch in enumerate(s):
        if ch in "{([":
            depth += 1
        elif ch in "})]":
            depth = max(0, depth - 1)
        elif ch == ";" and depth == 0:
            out.append(s[start:i].strip())
            start = i + 1
    return out


def canonical_type(t):
    t = " ".join(t.strip().split())
    t = re.sub(r"\b(memory|calldata|storage|payable)\b", "", t)
    t = " ".join(t.split())
    t = t.replace("uint[", "uint256[")
    t = t.replace("int[", "int256[")
    if t == "uint":
        t = "uint256"
    if t == "int":
        t = "int256"
    if t == "byte":
        t = "bytes1"
    return t


def parse_mapping_type(t):
    t = t.strip()
    if not t.startswith("mapping"):
        return None
    p = t.find("(")
    if p < 0:
        return None
    end = find_matching(t, p, "(", ")")
    if end < 0:
        return None
    inner = t[p + 1:end]
    parts = split_top_level(inner.replace("=>", ","), ",")
    if len(parts) != 2:
        return None
    return parts[0].strip(), parts[1].strip() + t[end + 1:].strip()


def getter_shape(t):
    inputs = []
    cur = " ".join(t.strip().split())
    while True:
        mp = parse_mapping_type(cur)
        if mp:
            key, cur = mp
            inputs.append({"name": "", "type": canonical_type(key), "internalType": internal_type(key)})
            continue
        m = re.search(r"(\[[^\]]*\])\s*$", cur)
        if m:
            cur = cur[:m.start()].strip()
            inputs.append({"name": "", "type": "uint256", "internalType": "uint256"})
            continue
        break
    return inputs, {"name": "", "type": canonical_type(cur), "internalType": internal_type(cur)}


def internal_type(t):
    t = " ".join(t.strip().split())
    t = re.sub(r"\b(memory|calldata|storage)\b", "", t)
    t = " ".join(t.split())
    words = []
    for w in t.split():
        if w == "uint":
            words.append("uint256")
        elif w == "int":
            words.append("int256")
        elif w == "byte":
            words.append("bytes1")
        else:
            words.append(w)
    return " ".join(words)


def parse_param(p):
    p = " ".join(p.strip().split())
    if not p:
        return None
    indexed = bool(re.search(r"\bindexed\b", p))
    p = re.sub(r"\b(indexed)\b", "", p)
    toks = p.split()
    while toks and toks[-1] in ("memory", "calldata", "storage", "payable"):
        break
    name = ""
    if len(toks) >= 2 and re.match(r"^[A-Za-z_]\w*$", toks[-1]) and toks[-1] not in {
        "memory", "calldata", "storage", "payable", "public", "external", "internal", "private",
    }:
        name = toks[-1]
        typ = " ".join(toks[:-1])
    else:
        typ = " ".join(toks)
    internal = internal_type(typ)
    return {"name": name, "type": canonical_type(typ), "internalType": internal, "_indexed": indexed}


def parse_params(params):
    out = []
    for part in split_top_level(params):
        p = parse_param(part)
        if p:
            out.append(p)
    return out


def state_mutability(text, default="nonpayable"):
    if re.search(r"\bpure\b", text):
        return "pure"
    if re.search(r"\bview\b", text) or re.search(r"\bconstant\b", text):
        return "view"
    if re.search(r"\bpayable\b", text):
        return "payable"
    return default


def signature(name, inputs):
    return f"{name}({','.join(p['type'] for p in inputs)})"


def abi_params(params, event=False):
    res = []
    for p in params:
        item = {"name": p["name"], "type": p["type"]}
        if event:
            item["indexed"] = p["_indexed"]
        item["internalType"] = p["internalType"]
        res.append(item)
    return res


def parse_contract_body(body):
    items = []
    for m in re.finditer(r"\bconstructor\s*\(([^)]*)\)\s*([^{;]*)", body, flags=re.S):
        inputs = parse_params(m.group(1))
        items.append(("constructor", "", {
            "type": "constructor",
            "inputs": abi_params(inputs),
            "stateMutability": state_mutability(m.group(2)),
        }, None))
    for m in re.finditer(r"\berror\s+([A-Za-z_]\w*)\s*\(([^)]*)\)", body, flags=re.S):
        inputs = parse_params(m.group(2))
        items.append(("error", m.group(1), {
            "type": "error",
            "name": m.group(1),
            "inputs": abi_params(inputs),
        }, None))
    for m in re.finditer(r"\bevent\s+([A-Za-z_]\w*)\s*\(([^)]*)\)\s*([^;{]*)", body, flags=re.S):
        inputs = parse_params(m.group(2))
        items.append(("event", m.group(1), {
            "type": "event",
            "name": m.group(1),
            "inputs": abi_params(inputs, event=True),
            "anonymous": bool(re.search(r"\banonymous\b", m.group(3))),
        }, None))
    for m in re.finditer(r"\bfallback\s*\(\s*\)\s*([^{;]*)", body, flags=re.S):
        items.append(("fallback", "", {"type": "fallback", "stateMutability": state_mutability(m.group(1))}, None))
    for m in re.finditer(r"\breceive\s*\(\s*\)\s*([^{;]*)", body, flags=re.S):
        items.append(("receive", "", {"type": "receive", "stateMutability": state_mutability(m.group(1), "payable")}, None))
    func_re = re.compile(r"\bfunction\s+([A-Za-z_]\w*)\s*\(([^)]*)\)\s*([^;{]*)(?:[;{])", re.S)
    for m in func_re.finditer(body):
        suffix = m.group(3)
        if re.search(r"\binternal\b|\bprivate\b", suffix):
            continue
        inputs = parse_params(m.group(2))
        outputs = []
        rm = re.search(r"\breturns\s*\(([^)]*)\)", suffix, re.S)
        if rm:
            outputs = parse_params(rm.group(1))
        abi = {
            "type": "function",
            "name": m.group(1),
            "inputs": abi_params(inputs),
            "outputs": abi_params(outputs),
            "stateMutability": state_mutability(suffix),
        }
        items.append(("function", m.group(1), abi, signature(m.group(1), inputs)))
    for stmt in top_level_semicolon_statements(body):
        if " public " not in f" {stmt} " or stmt.startswith(("function ", "event ", "error ")):
            continue
        left = re.split(r"\s=\s|(?<![<>=!])=(?!>)", stmt, 1)[0].strip()
        toks = left.split()
        if "public" not in toks or len(toks) < 3:
            continue
        pub = toks.index("public")
        typ = " ".join(toks[:pub])
        rest = [t for t in toks[pub + 1:] if t not in {"constant", "immutable", "override"}]
        if not rest:
            continue
        name = rest[-1]
        if not re.match(r"^[A-Za-z_]\w*$", name):
            continue
        getter_inputs, getter_output = getter_shape(typ)
        abi = {
            "type": "function",
            "name": name,
            "inputs": getter_inputs,
            "outputs": [getter_output],
            "stateMutability": "view",
        }
        items.append(("function", name, abi, signature(name, getter_inputs)))
    ranks = {"constructor": 0, "error": 1, "event": 2, "fallback": 3, "function": 4, "receive": 5}
    items.sort(key=lambda x: (ranks[x[0]], x[1], x[3] or ""))
    abi = [x[2] for x in items]
    hashes = {}
    for kind, _name, _abi, sig in items:
        if kind == "function" and sig:
            hashes[sig] = keccak256(sig.encode()).hex()[:8]
    return abi, dict(sorted(hashes.items()))


def parse_source(path, text):
    text = strip_comments(text)
    contracts = {}
    pat = re.compile(r"\b(?:abstract\s+)?(contract|interface|library)\s+([A-Za-z_]\w*)[^{;]*\{", re.S)
    for m in pat.finditer(text):
        end = find_matching(text, m.end() - 1)
        if end < 0:
            continue
        body = text[m.end():end]
        abi, hashes = parse_contract_body(body)
        contracts[f"{path}:{m.group(2)}"] = {"abi": abi, "hashes": hashes}
    return contracts


def fail(msg, code=1):
    sys.stderr.write(msg)
    return code


def parse_args(argv):
    opts = {"emit": None, "pretty": False, "out_dir": None, "stop_after": None, "inputs": []}
    i = 0
    while i < len(argv):
        a = argv[i]
        if a in ("-h", "--help"):
            print(HELP_SHORT if a == "-h" else HELP_LONG)
            return None, 0
        if a in ("-V", "--version"):
            print("""solar Version: 0.1.8
Commit SHA: 8f228ae9f0bd90ad4ec81fb1ef4fbba29748b8d5
Build Timestamp: 2026-04-17T19:59:51.519973035Z
Build Features: mimalloc,tracing
Build Profile: release""")
            return None, 0
        if a == "-Zhelp":
            sys.stderr.write(ZHELP)
            return None, 0
        if a == "-Z":
            i += 2
            continue
        if a in ("--pretty-json", "--pretty-json-err", "--no-warnings", "-v"):
            if a == "--pretty-json":
                opts["pretty"] = True
            i += 1
            continue
        if a in ("--emit", "--out-dir", "--stop-after", "--threads", "-j", "--jobs", "--evm-version", "--base-path", "-I", "--include-path", "--allow-paths", "--color", "--error-format", "--error-format-human", "--diagnostic-width"):
            if i + 1 >= len(argv):
                return fail(f"error: a value is required for '{a} <VALUE>' but none was supplied\n", 2), None
            val = argv[i + 1]
            if a == "--emit":
                emits = val.split(",")
                if any(e not in ("abi", "hashes") for e in emits):
                    bad = next(e for e in emits if e not in ("abi", "hashes"))
                    return fail(f"error: invalid value '{bad}' for '--emit <EMIT>'\n  [possible values: abi, hashes]\n\nFor more information, try '--help'.\n", 2), None
                opts["emit"] = emits
            elif a == "--out-dir":
                opts["out_dir"] = val
            elif a == "--stop-after":
                opts["stop_after"] = val
            i += 2
            continue
        if a.startswith("--"):
            return fail(f"error: unexpected argument '{a}' found\n\n  tip: to pass '{a}' as a value, use '-- {a}'\n\nUsage: executable [OPTIONS] [INPUT]...\n\nFor more information, try '--help'.\n", 2), None
        opts["inputs"].append(a)
        i += 1
    return opts, None


def main(argv):
    parsed, early = parse_args(argv)
    if early is not None:
        return early
    if isinstance(parsed, int):
        return parsed
    opts = parsed
    if not opts["inputs"]:
        return fail("error: no files found\n  │\n  ╰ note: if you wish to use the standard input, please specify `-` explicitly\n\nerror: aborting due to 1 previous error\n", 1)
    if opts["stop_after"] and not opts["emit"]:
        return 0
    emit = opts["emit"] or []
    all_contracts = {}
    for inp in opts["inputs"]:
        if "=" in inp and not os.path.exists(inp):
            continue
        if inp == "-":
            text = sys.stdin.read()
            display = "<stdin>"
        else:
            try:
                with open(inp, "r", encoding="utf-8") as f:
                    text = f.read()
            except OSError as e:
                return fail(f"error: failed to read source file: {e}\n", 1)
            display = inp
        for key, val in parse_source(display, text).items():
            entry = {}
            if "abi" in emit:
                entry["abi"] = val["abi"]
            if "hashes" in emit:
                entry["hashes"] = val["hashes"]
            all_contracts[key] = entry
    result = {"contracts": dict(sorted(all_contracts.items())), "version": VERSION}
    if opts["emit"]:
        data = json.dumps(result, indent=2 if opts["pretty"] else None, separators=None if opts["pretty"] else (",", ":"))
        if opts["out_dir"]:
            try:
                with open(os.path.join(opts["out_dir"], "combined.json"), "w", encoding="utf-8") as f:
                    f.write(data)
            except OSError as e:
                return fail(f"error: failed to write to output: {e.strerror} (os error {e.errno})\n\nerror: aborting due to 1 previous error\n", 1)
        else:
            print(data)
    return 0


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
