#!/bin/bash
set -e
rm -f executable
cp ngrrram.py executable
chmod +x executable
