#!/usr/bin/env python3
import sys
import os


HELP = """Usage: executable [OPTIONS]

Options:
  -n, --n <2|3|4|w|file>  use bi-(2), tri-(3), tetragrams(4), (w)ords or comma separated wordlist file. [default: 2]
  -t, --top <1-200>       use the top X ngrams ordered by usage. [default: 50]
  -c, --combi <1-200>     how many different ngrams to use in a single lesson. [default: 2]
  -r, --rep <number>      how often to repeat *each* different ngram in a lesson. [default: 3]
  -w, --wpm <number>      the wpm threshold at which the lesson is considered a success. [default: 40]
  -a, --acc <0-100>       the accuracy in percent at which the lesson is considered a success. [default: 94]
      --emu-in <layout>   your current keyboard layout. only needed if you want to emulate a different layout. see docs for supported layouts. [default: ]
      --emu-out <layout>  the layout you want to emulate. only needed if you want to emulate a different layout. see docs for supported layouts. [default: ]
      --show-ortho        show keyboard in ortholinear format
      --nokb              pass this flag to disable the keyboard layout display.
      --cat               the most important flag. don't practice alone.
  -h, --help              Print help
"""


VALUE_OPTS = {
    "-n": ("n", "<2|3|4|w|file>"),
    "--n": ("n", "<2|3|4|w|file>"),
    "-t": ("top", "<1-200>"),
    "--top": ("top", "<1-200>"),
    "-c": ("combi", "<1-200>"),
    "--combi": ("combi", "<1-200>"),
    "-r": ("rep", "<number>"),
    "--rep": ("rep", "<number>"),
    "-w": ("wpm", "<number>"),
    "--wpm": ("wpm", "<number>"),
    "-a": ("acc", "<0-100>"),
    "--acc": ("acc", "<0-100>"),
    "--emu-in": ("emu_in", "<layout>"),
    "--emu-out": ("emu_out", "<layout>"),
}

FLAG_OPTS = {"--show-ortho", "--nokb", "--cat"}

DISPLAY = {
    "n": "--n <2|3|4|w|file>",
    "top": "--top <1-200>",
    "combi": "--combi <1-200>",
    "rep": "--rep <number>",
    "wpm": "--wpm <number>",
    "acc": "--acc <0-100>",
    "emu_in": "--emu-in <layout>",
    "emu_out": "--emu-out <layout>",
    "show_ortho": "--show-ortho",
    "nokb": "--nokb",
    "cat": "--cat",
}


def unexpected(arg):
    sys.stderr.write(
        f"error: unexpected argument '{arg}' found\n\n"
        "Usage: executable [OPTIONS]\n\n"
        "For more information, try '--help'.\n"
    )
    return 2


def missing_value(opt, metavar):
    sys.stderr.write(
        f"error: a value is required for '{opt} {metavar}' but none was supplied\n\n"
        "For more information, try '--help'.\n"
    )
    return 2


def invalid_value(opt, metavar, value):
    sys.stderr.write(
        f"error: invalid value '{value}' for '{opt} {metavar}': invalid digit found in string\n\n"
        "For more information, try '--help'.\n"
    )
    return 2


def duplicate(name):
    sys.stderr.write(
        f"error: the argument '{DISPLAY[name]}' cannot be used multiple times\n\n"
        "Usage: executable [OPTIONS]\n\n"
        "For more information, try '--help'.\n"
    )
    return 2


def parse(argv):
    opts = {
        "n": "2",
        "top": 50,
        "combi": 2,
        "rep": 3,
        "wpm": 40,
        "acc": 94,
        "emu_in": "",
        "emu_out": "",
        "show_ortho": False,
        "nokb": False,
        "cat": False,
    }
    seen = set()
    i = 0
    while i < len(argv):
        arg = argv[i]
        attached = None
        if arg.startswith("--") and "=" in arg:
            possible, attached = arg.split("=", 1)
            if possible in VALUE_OPTS:
                arg = possible
        elif len(arg) > 2 and arg[:2] in VALUE_OPTS:
            attached = arg[2:]
            arg = arg[:2]
        if arg in VALUE_OPTS:
            name, metavar = VALUE_OPTS[arg]
            if name in seen:
                return None, duplicate(name)
            seen.add(name)
            if attached is None and i + 1 >= len(argv):
                return None, missing_value(arg, metavar)
            value = attached if attached is not None else argv[i + 1]
            if value.startswith("-"):
                return None, unexpected(value)
            if name in {"top", "combi", "rep", "wpm", "acc"}:
                try:
                    number = int(value)
                except ValueError:
                    return None, invalid_value(arg, metavar, value)
                opts[name] = number
            else:
                opts[name] = value
            i += 1 if attached is not None else 2
        elif arg in FLAG_OPTS:
            name = arg[2:].replace("-", "_")
            if name in seen:
                return None, duplicate(name)
            seen.add(name)
            opts[name] = True
            i += 1
        else:
            return None, unexpected(arg)
    return opts, 0


def validate(opts):
    if not 1 <= opts["top"] <= 200:
        sys.stdout.write("Invalid argument for top. Use a number between 1 and 200.\n")
        return 1
    if not 1 <= opts["combi"] <= 200:
        sys.stdout.write("Invalid argument for combi. Use a number between 1 and 200.\n")
        return 1
    if not 1 <= opts["rep"] <= 200:
        sys.stdout.write("Invalid argument for rep. Use a number between 1 and 200.\n")
        return 1
    if not 1 <= opts["wpm"] <= 200:
        sys.stdout.write("Invalid argument for wpm. Use a number between 1 and 200.\n")
        return 1
    if not 0 <= opts["acc"] <= 100:
        sys.stdout.write("Invalid argument for acc. Use a number between 0 and 100.\n")
        return 1
    if bool(opts["emu_in"]) != bool(opts["emu_out"]):
        sys.stdout.write("You need to specify both emu_in and emu_out.\n")
        return 1
    n = opts["n"]
    if n not in {"2", "3", "4", "w"} and not os.path.exists(n):
        sys.stdout.write(f"File not found: {n}\n")
        return 1
    return 0


def run_app(opts):
    sys.stdout.write("\x1b[?1049h")
    if not sys.stdin.isatty():
        sys.stderr.write('Error: Os { code: 6, kind: Uncategorized, message: "No such device or address" }\n')
        return 1
    sys.stdout.write("ngrrram\n")
    sys.stdout.write("Type the shown ngrams. Press Ctrl-C to quit.\n")
    return 0


def main(argv):
    if argv in (["--help"], ["-h"]):
        sys.stdout.write(HELP)
        return 0
    opts, status = parse(argv)
    if status:
        return status
    status = validate(opts)
    if status:
        return status
    return run_app(opts)


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
