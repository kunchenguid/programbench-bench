#!/bin/bash
set -e
rm -f executable
cp src/onefetch.py executable
chmod +x executable
