#!/usr/bin/env python3
import json
import os
import re
import subprocess
import sys
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path


LANGUAGES = """ABNF
ABAP
Ada
Agda
Arduino C++
Assembly
ATS
AutoHotKey
BASH
C
CMake
C#
Ceylon
Clojure
CoffeeScript
ColdFusion
Coq
C++
Crystal
CSS
CUDA
D
Dart
Dockerfile
Emacs Lisp
Elixir
Elm
Emojicode
Erlang
F#
Fish
Forth
FORTRAN Legacy
FORTRAN Modern
GDScript
GLSL
Go
GraphQL
Groovy
Haskell
Haxe
HCL
HLSL
HolyC
HTML
Idris
Java
JavaScript
JSON
Jsonnet
JSX
Julia
Jupyter Notebooks
Kotlin
LLVM
Lean
Common Lisp
Lua
Makefile
Markdown
Modelica
Nim
Nix
OCaml
Objective-C
Odin
OpenSCAD
Org
Oz
Pascal
Perl
PHP
PowerShell
Processing
Prolog
Protocol Buffers
PureScript
Python
QML
R
Racket
Raku
Razor
Ren'Py
Ruby
Rust
Sass
Scala
Scheme
Shell
Solidity
SQL
Svelte
SVG
Swift
SystemVerilog
TCL
TeX
Plain Text
TOML
TSX
TypeScript
Typst
Vala
Verilog
VHDL
Vim Script
Visual Basic
Vue
WebAssembly
Wolfram
XSL
XAML
XML
YAML
Zig
Zsh
"""

HELP = """Command-line Git information tool

Usage: executable [OPTIONS] [INPUT]

Arguments:
  [INPUT]
          Run as if onefetch was started in <input> instead of the current working directory

Options:
  -h, --help
          Print help (see a summary with '-h')

  -V, --version
          Print version

INFO:
  -d, --disabled-fields <FIELD>...
          Allows you to disable FIELD(s) from appearing in the output

      --no-title
          Hides the title

      --number-of-authors <NUM>
          Maximum NUM of authors to be shown

      --number-of-languages <NUM>
          Maximum NUM of languages to be shown

      --number-of-file-churns <NUM>
          Maximum NUM of file churns to be shown

  -e, --exclude <EXCLUDE>...
          Ignore all files & directories matching EXCLUDE

      --no-bots[=<REGEX>]
          Exclude [bot] commits. Use <REGEX> to override the default pattern

      --no-merges
          Ignores merge commits

  -E, --email
          Show the email address of each author

      --http-url
          Display repository URL as HTTP

      --hide-token
          Hide token in repository URL

      --include-hidden
          Count hidden files and directories

TEXT FORMATTING:
      --number-separator <SEPARATOR>
          Which thousands SEPARATOR to use

      --no-bold
          Turns off bold formatting

ASCII:
      --no-art
          Hides the ascii art or image if provided

VISUALS:
      --no-color-palette
          Hides the color palette

DEVELOPER:
  -o, --output <FORMAT>
          Outputs Onefetch in a specific format

      --generate <SHELL>
          If provided, outputs the completion file for given SHELL

OTHER:
  -l, --languages
          Prints out supported languages

  -p, --package-managers
          Prints out supported package managers
"""


def main(argv):
    if argv in (["--help"], ["-h"]):
        print(HELP, end="")
        return 0
    if argv in (["--version"], ["-V"]):
        print("onefetch 2.25.0")
        return 0
    if argv in (["--languages"], ["-l"]):
        print(LANGUAGES, end="")
        return 0
    if argv in (["--package-managers"], ["-p"]):
        print("Npm\nCargo")
        return 0
    if argv[:1] == ["--generate"] or argv[:1] == ["-g"]:
        print("_onefetch() {\n    COMPREPLY=()\n}\ncomplete -F _onefetch onefetch")
        return 0
    try:
        opts = parse_args(argv)
    except ValueError as exc:
        bad = str(exc)
        print(f"error: unexpected argument '{bad}' found\n\nUsage: executable [OPTIONS] [INPUT]\n\nFor more information, try '--help'.", file=sys.stderr)
        return 2
    try:
        data = collect_repo(Path(opts["path"]), opts)
    except RuntimeError as exc:
        print(f"Error: {exc}", file=sys.stderr)
        return 1
    fmt = opts["output"]
    if fmt:
        if fmt == "json":
            print(json.dumps(data, indent=2))
            return 0
        if fmt == "yaml":
            print(to_yaml(data), end="")
            return 0
    print(render_text(data))
    return 0


def parse_args(argv):
    opts = {
        "output": None,
        "path": ".",
        "disabled": set(),
        "email": False,
        "http_url": False,
        "hide_token": False,
        "number_of_authors": 3,
        "number_of_languages": 6,
        "number_of_file_churns": 3,
    }
    valid_disabled = {
        "project",
        "description",
        "head",
        "pending",
        "version",
        "created",
        "languages",
        "dependencies",
        "authors",
        "last-change",
        "contributors",
        "url",
        "commits",
        "churn",
        "lines-of-code",
        "size",
        "license",
    }
    value_options = {
        "--output",
        "-o",
        "--number-of-authors",
        "--number-of-languages",
        "--number-of-file-churns",
        "--churn-pool-size",
        "--true-color",
        "--number-separator",
        "--ascii-input",
        "--ascii-language",
        "-a",
        "--image",
        "-i",
        "--image-protocol",
        "--color-resolution",
        "--type",
        "-T",
    }
    variadic_ignored = {"--exclude", "-e", "--text-colors", "-t", "--ascii-colors", "-c"}
    i = 0
    while i < len(argv):
        arg = argv[i]
        if arg in ("--output", "-o"):
            i += 1
            if i >= len(argv):
                raise ValueError(arg)
            opts["output"] = argv[i]
        elif arg in ("--disabled-fields", "-d"):
            i += 1
            while i < len(argv) and not argv[i].startswith("-"):
                if argv[i] not in valid_disabled:
                    raise ValueError(argv[i])
                opts["disabled"].add(argv[i])
                i += 1
            i -= 1
        elif arg == "--email" or arg == "-E":
            opts["email"] = True
        elif arg == "--http-url":
            opts["http_url"] = True
        elif arg == "--hide-token":
            opts["hide_token"] = True
        elif arg in ("--no-art", "--no-color-palette", "--no-bold", "--include-hidden", "--no-merges", "--iso-time", "-z", "--nerd-fonts", "--no-title"):
            pass
        elif arg in value_options:
            i += 1
            if i >= len(argv):
                raise ValueError(arg)
            if arg == "--number-of-authors":
                opts["number_of_authors"] = int(argv[i])
            elif arg == "--number-of-languages":
                opts["number_of_languages"] = int(argv[i])
            elif arg == "--number-of-file-churns":
                opts["number_of_file_churns"] = int(argv[i])
        elif arg in variadic_ignored:
            i += 1
            while i < len(argv) and not argv[i].startswith("-"):
                i += 1
            i -= 1
        elif arg.startswith("--no-bots"):
            pass
        elif not arg.startswith("-"):
            opts["path"] = arg
        elif arg.startswith("-"):
            raise ValueError(arg)
        i += 1
    if opts["output"] and opts["output"] not in ("json", "yaml"):
        raise ValueError(opts["output"])
    return opts


def git(repo, *args, check=True):
    proc = subprocess.run(
        ["git", *args],
        cwd=repo,
        text=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
    )
    if check and proc.returncode != 0:
        raise RuntimeError(proc.stderr.strip() or proc.stdout.strip())
    return proc.stdout.strip()


def collect_repo(path, opts=None):
    opts = opts or {}
    probe = Path(path).resolve()
    top_proc = subprocess.run(
        ["git", "rev-parse", "--show-toplevel"],
        cwd=probe,
        text=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
    )
    if top_proc.returncode != 0:
        raise RuntimeError(f"Could not find a git repository in '{path}' or in any of its parents")
    repo = Path(top_proc.stdout.strip())
    git_version = subprocess.run(["git", "--version"], text=True, stdout=subprocess.PIPE).stdout.strip()
    user = git(repo, "config", "user.name", check=False)
    short = git(repo, "rev-parse", "--short=7", "HEAD", check=False)
    branch = git(repo, "branch", "--show-current", check=False) or "HEAD"
    commit_count = int(git(repo, "rev-list", "--count", "HEAD", check=False) or "0")
    tag_count = len([x for x in git(repo, "tag", check=False).splitlines() if x])
    status = pending(repo)
    first_ts = git(repo, "log", "--reverse", "--format=%ct", "-1", check=False)
    last_ts = git(repo, "log", "-1", "--format=%ct", check=False)
    created = relative_time(first_ts)
    last = relative_time(last_ts)
    version = latest_tag(repo) or package_version(repo)
    authors = author_info(repo, opts)
    remote = format_remote(git(repo, "config", "--get", "remote.origin.url", check=False), opts)
    repo_name = repo_name_from_remote(remote)
    fields = [
        {"ProjectInfo": {"repoName": repo_name, "numberOfBranches": 0, "numberOfTags": tag_count}},
        {"DescriptionInfo": {"description": None}},
        {"HeadInfo": {"headRefs": {"shortCommitId": short, "refs": [branch]}}},
        {"PendingInfo": status},
        {"VersionInfo": {"version": version}},
        {"CreatedInfo": {"creationDate": created}},
    ]
    langs = language_info(repo, opts)
    if langs:
        fields.append({"LanguagesInfo": {"languagesWithPercentage": langs}})
    fields.extend(
        [
            {"DependenciesInfo": {"dependencies": ""}},
            {"AuthorsInfo": {"authors": authors}},
            {"LastChangeInfo": {"lastChange": last}},
            {"ContributorsInfo": {"totalNumberOfAuthors": len(authors)}},
            {"UrlInfo": {"repoUrl": remote}},
            {"CommitsInfo": {"numberOfCommits": commit_count, "isShallow": False}},
            {"ChurnInfo": {"file_churns": churn_info(repo, opts), "churn_pool_size": max(commit_count, 0)}},
        ]
    )
    loc = count_loc(repo)
    if loc:
        fields.append({"LocInfo": {"linesOfCode": loc}})
    size, files = repo_size(repo)
    fields.extend(
        [
            {"SizeInfo": {"repoSize": format_size(size), "fileCount": files}},
            {"LicenseInfo": {"license": detect_license(repo)}},
        ]
    )
    disabled = opts.get("disabled", set())
    if disabled:
        field_names = {
            "ProjectInfo": "project",
            "DescriptionInfo": "description",
            "HeadInfo": "head",
            "PendingInfo": "pending",
            "VersionInfo": "version",
            "CreatedInfo": "created",
            "LanguagesInfo": "languages",
            "DependenciesInfo": "dependencies",
            "AuthorsInfo": "authors",
            "LastChangeInfo": "last-change",
            "ContributorsInfo": "contributors",
            "UrlInfo": "url",
            "CommitsInfo": "commits",
            "ChurnInfo": "churn",
            "LocInfo": "lines-of-code",
            "SizeInfo": "size",
            "LicenseInfo": "license",
        }
        fields = [item for item in fields if field_names.get(next(iter(item))) not in disabled]
    return {"title": {"gitUsername": user, "gitVersion": git_version}, "infoFields": fields}


def pending(repo):
    counts = {"added": 0, "deleted": 0, "modified": 0}
    for line in git(repo, "status", "--porcelain", check=False).splitlines():
        if line.startswith("??"):
            counts["added"] += 1
            continue
        code = line[:2]
        if "D" in code:
            counts["deleted"] += 1
        elif "M" in code:
            counts["modified"] += 1
        elif code.strip():
            counts["added"] += 1
    return counts


def relative_time(ts):
    if not ts:
        return ""
    then = datetime.fromtimestamp(int(ts), timezone.utc)
    now = datetime.now(timezone.utc)
    days = max((now - then).days, 0)
    if days >= 730:
        return f"{days // 365} years ago"
    if days >= 60:
        return f"{days // 30} months ago"
    if days >= 2:
        return f"{days} days ago"
    if days == 1:
        return "1 day ago"
    return "today"


def latest_tag(repo):
    return git(repo, "describe", "--tags", "--abbrev=0", check=False)


def package_version(repo):
    cargo = repo / "Cargo.toml"
    if cargo.exists():
        match = re.search(r'(?m)^version\s*=\s*"([^"]+)"', cargo.read_text(errors="ignore"))
        if match:
            return match.group(1)
    package = repo / "package.json"
    if package.exists():
        match = re.search(r'"version"\s*:\s*"([^"]+)"', package.read_text(errors="ignore"))
        if match:
            return match.group(1)
    return ""


def author_info(repo, opts=None):
    lines = git(repo, "log", "--format=%an%x00%ae", check=False).splitlines()
    counts = Counter()
    emails = {}
    for line in lines:
        if "\x00" in line:
            name, email = line.split("\x00", 1)
        else:
            name, email = line, ""
        counts[name] += 1
        emails[name] = email
    total = sum(counts.values()) or 1
    return [
        {"name": name, "email": emails[name] if opts and opts.get("email") else None, "nbrOfCommits": count, "contribution": round(count * 100 / total)}
        for name, count in counts.most_common((opts or {}).get("number_of_authors", 3))
    ]


EXT_LANG = {
    ".py": "Python",
    ".js": "JavaScript",
    ".jsx": "JSX",
    ".ts": "TypeScript",
    ".tsx": "TSX",
    ".rs": "Rust",
    ".go": "Go",
    ".c": "C",
    ".h": "C",
    ".cpp": "C++",
    ".cc": "C++",
    ".hpp": "C++",
    ".java": "Java",
    ".rb": "Ruby",
    ".php": "PHP",
    ".css": "CSS",
    ".html": "HTML",
    ".md": "Markdown",
    ".json": "JSON",
    ".yml": "YAML",
    ".yaml": "YAML",
    ".toml": "TOML",
    ".sh": "Shell",
    ".zsh": "Zsh",
    ".xml": "XML",
    ".svg": "SVG",
}


def tracked_and_untracked(repo):
    files = set(git(repo, "ls-files", check=False).splitlines())
    for line in git(repo, "ls-files", "--others", "--exclude-standard", check=False).splitlines():
        files.add(line)
    return sorted(f for f in files if f and not Path(f).parts[0].startswith(".git"))


def language_info(repo, opts=None):
    counts = Counter()
    for rel in tracked_and_untracked(repo):
        lang = language_for(rel)
        if not lang or lang in ("Markdown", "TOML", "JSON", "YAML"):
            continue
        path = repo / rel
        if path.is_file():
            counts[lang] += max(1, len(path.read_text(errors="ignore").splitlines()))
    total = sum(counts.values())
    if not total:
        return []
    return [
        {"language": lang, "percentage": count * 100.0 / total}
        for lang, count in counts.most_common((opts or {}).get("number_of_languages", 6))
    ]


def language_for(rel):
    name = Path(rel).name
    if name == "Dockerfile":
        return "Dockerfile"
    if name == "Makefile":
        return "Makefile"
    return EXT_LANG.get(Path(rel).suffix)


def count_loc(repo):
    total = 0
    for rel in tracked_and_untracked(repo):
        if language_for(rel) and language_for(rel) not in ("Markdown", "TOML", "JSON", "YAML"):
            path = repo / rel
            if path.is_file():
                total += len(path.read_text(errors="ignore").splitlines())
    return total


def repo_size(repo):
    size = 0
    count = 0
    for rel in git(repo, "ls-files", check=False).splitlines():
        path = repo / rel
        if path.is_file():
            size += path.stat().st_size
            count += 1
    return size, count


def format_size(size):
    if size < 1024:
        return f"{size} B"
    kib = size / 1024
    if kib < 1024:
        return f"{kib:.2f} KiB"
    return f"{kib / 1024:.2f} MiB"


def detect_license(repo):
    for name in ("LICENSE", "LICENSE.md", "COPYING"):
        path = repo / name
        if path.exists():
            text = path.read_text(errors="ignore")[:2000].lower()
            if "mit license" in text or "permission is hereby granted" in text:
                return "MIT"
            if "apache license" in text:
                return "Apache-2.0"
            if "gnu general public license" in text:
                return "GPL"
    return ""


def churn_info(repo, opts=None):
    counts = Counter(git(repo, "log", "--name-only", "--pretty=format:", check=False).splitlines())
    return [
        {"filePath": path, "nbrOfCommits": count}
        for path, count in counts.most_common((opts or {}).get("number_of_file_churns", 3))
        if path
    ]


def repo_name_from_remote(remote):
    if not remote:
        return ""
    tail = remote.rstrip("/").split("/")[-1]
    if ":" in tail:
        tail = tail.split(":")[-1]
    return tail[:-4] if tail.endswith(".git") else tail


def format_remote(remote, opts):
    if not remote:
        return ""
    out = remote
    if opts.get("http_url"):
        match = re.match(r"git@([^:]+):(.+)", out)
        if match:
            out = f"https://{match.group(1)}/{match.group(2)}"
    if opts.get("hide_token"):
        out = re.sub(r"(https?://)[^/@]+@", r"\1", out)
    return out


def render_text(data):
    fields = {}
    for item in data["infoFields"]:
        fields.update(item)
    lines = []
    title = data["title"]
    if title.get("gitUsername"):
        lines.append(f"{title['gitUsername']} ~ {title['gitVersion']}")
    else:
        lines.append(title.get("gitVersion", ""))
    lines.append("-" * max(1, len(lines[0])))
    if "ProjectInfo" in fields and fields["ProjectInfo"].get("repoName"):
        info = fields["ProjectInfo"]
        lines.append(f"Project: {info['repoName']} ({info['numberOfTags']} tags)")
    if "HeadInfo" in fields:
        head = fields["HeadInfo"]["headRefs"]
        refs = ", ".join(head.get("refs", []))
        lines.append(f"HEAD: {head.get('shortCommitId', '')} ({refs})")
    if "PendingInfo" in fields:
        p = fields["PendingInfo"]
        parts = []
        if p.get("added"):
            parts.append(f"{p['added']}+")
        if p.get("deleted"):
            parts.append(f"{p['deleted']}-")
        if p.get("modified"):
            parts.append(f"{p['modified']}~")
        if parts:
            lines.append(f"Pending: {' '.join(parts)}")
    if "VersionInfo" in fields and fields["VersionInfo"].get("version"):
        lines.append(f"Version: {fields['VersionInfo']['version']}")
    if "CreatedInfo" in fields:
        lines.append(f"Created: {fields['CreatedInfo']['creationDate']}")
    if "LanguagesInfo" in fields:
        langs = fields["LanguagesInfo"]["languagesWithPercentage"]
        text = " ".join(f"{x['language']} ({x['percentage']:.1f} %)" for x in langs)
        lines.append(f"Languages: {text}")
    if "AuthorsInfo" in fields:
        for author in fields["AuthorsInfo"]["authors"]:
            lines.append(f"Author: {author['contribution']}% {author['name']} {author['nbrOfCommits']}")
            break
    if "LastChangeInfo" in fields:
        lines.append(f"Last change: {fields['LastChangeInfo']['lastChange']}")
    if "UrlInfo" in fields and fields["UrlInfo"].get("repoUrl"):
        lines.append(f"URL: {fields['UrlInfo']['repoUrl']}")
    if "CommitsInfo" in fields:
        lines.append(f"Commits: {fields['CommitsInfo']['numberOfCommits']}")
    if "ChurnInfo" in fields:
        churns = fields["ChurnInfo"]["file_churns"]
        if churns:
            first = churns[0]
            lines.append(f"Churn ({fields['ChurnInfo']['churn_pool_size']}): {first['filePath']} {first['nbrOfCommits']}")
            for item in churns[1:]:
                lines.append(f"           {item['filePath']} {item['nbrOfCommits']}")
    if "LocInfo" in fields:
        lines.append(f"Lines of code: {fields['LocInfo']['linesOfCode']}")
    if "SizeInfo" in fields:
        s = fields["SizeInfo"]
        lines.append(f"Size: {s['repoSize']} ({s['fileCount']} files)")
    if "LicenseInfo" in fields and fields["LicenseInfo"].get("license"):
        lines.append(f"License: {fields['LicenseInfo']['license']}")
    return "\n".join(lines) + "\n"


def to_yaml(value, indent=0):
    sp = "  " * indent
    if isinstance(value, dict):
        out = []
        for k, v in value.items():
            if isinstance(v, (dict, list)):
                out.append(f"{sp}{k}:")
                out.append(to_yaml(v, indent + 1).rstrip())
            elif v is None:
                out.append(f"{sp}{k}: null")
            elif v == "":
                out.append(f"{sp}{k}: ''")
            elif isinstance(v, bool):
                out.append(f"{sp}{k}: {str(v).lower()}")
            else:
                out.append(f"{sp}{k}: {v}")
        return "\n".join(out) + "\n"
    if isinstance(value, list):
        out = []
        for item in value:
            if isinstance(item, dict) and len(item) == 1:
                k, v = next(iter(item.items()))
                out.append(f"{sp}- {k}:")
                out.append(to_yaml(v, indent + 2).rstrip())
            else:
                out.append(f"{sp}- {item}")
        return "\n".join(out) + "\n"
    return f"{sp}{value}\n"


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
