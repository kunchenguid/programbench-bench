#!/usr/bin/env python3
import sys
import os
import subprocess
import tempfile


VERSION = """run-kit 0.3.2
Universal multi-language runner and smart REPL
author: Esubalew Chekol <esubalewchekol6@gmail.com>
homepage: https://esubalew.et
repository: https://github.com/Esubaalew/run
license: Apache-2.0
commit: 0050c88 (2026-03-03T12:39:28-08:00, dirty: dirty)
built: 2026-04-17T19:59:44.418829299+00:00 [release for x86_64-unknown-linux-gnu]
rustc: rustc 1.92.0 (ded5c06cf 2025-12-08)
"""

HELP = """Universal multi-language runner and REPL

Usage: executable [OPTIONS] [ARGS]...

Arguments:
  [ARGS]...  Positional arguments (language, code, or file)

Options:
  -V, --version      Print version information and exit
  -l, --lang <LANG>  Explicitly choose the language to execute
  -f, --file <PATH>  Execute code from the provided file path
  -c, --code <CODE>  Execute the provided code snippet
      --no-detect    Disable heuristic language detection
  -h, --help         Print help
"""


VALUE_OPTIONS = {
    "--lang": "--lang <LANG>",
    "-l": "-l <LANG>",
    "--file": "--file <PATH>",
    "-f": "-f <PATH>",
    "--code": "--code <CODE>",
    "-c": "-c <CODE>",
}


def clap_unexpected(arg):
    return (
        f"error: unexpected argument '{arg}' found\n\n"
        f"  tip: to pass '{arg}' as a value, use '-- {arg}'\n\n"
        "Usage: executable [OPTIONS] [ARGS]...\n\n"
        "For more information, try '--help'.\n"
    )


def clap_missing_value(arg):
    rendered = VALUE_OPTIONS[arg]
    return (
        f"error: a value is required for '{rendered}' but none was supplied\n\n"
        "For more information, try '--help'.\n"
    )


def parse_args(args):
    parsed = {"lang": None, "file": None, "code": None, "no_detect": False, "positionals": []}
    i = 0
    while i < len(args):
        arg = args[i]
        if arg in ("--lang", "-l"):
            parsed["lang"] = args[i + 1]
            i += 2
        elif arg in ("--file", "-f"):
            parsed["file"] = args[i + 1]
            i += 2
        elif arg in ("--code", "-c"):
            parsed["code"] = args[i + 1]
            i += 2
        elif arg == "--no-detect":
            parsed["no_detect"] = True
            i += 1
        else:
            parsed["positionals"].append(arg)
            i += 1
    return parsed


def normalize_lang(lang):
    table = {
        "py": "python",
        "python": "python",
        "python3": "python",
        "bash": "bash",
        "sh": "bash",
        "shell": "bash",
    }
    return table.get((lang or "").lower(), (lang or "").lower())


def detect_language(code=None, path=None, no_detect=False):
    if no_detect:
        return "python"
    if path:
        ext = os.path.splitext(path)[1].lower()
        if ext == ".py":
            return "python"
        if ext in (".sh", ".bash"):
            return "bash"
        if ext == ".go":
            return "go"
        if ext == ".rs":
            return "rust"
        if ext == ".c":
            return "c"
        if ext in (".cc", ".cpp", ".cxx"):
            return "cpp"
        if ext in (".js", ".mjs"):
            return "javascript"
        if ext == ".pl":
            return "perl"
        if ext == ".rb":
            return "ruby"
    text = (code or "").lstrip()
    if text.startswith(("echo ", "cd ", "pwd", "ls ", "cat ", "printf ")):
        return "bash"
    if text.startswith(("print(", "import ", "from ")):
        return "lua"
    if text.startswith("console."):
        return "javascript"
    if text.startswith("puts "):
        return "ruby"
    return "python"


def run_process(argv):
    try:
        completed = subprocess.run(argv)
        return completed.returncode
    except FileNotFoundError:
        sys.stderr.write("Error: No such file or directory (os error 2)\n")
        return 1


def execute(lang, code=None, path=None):
    lang = normalize_lang(lang)
    if lang == "python":
        if path:
            return run_process(["python3", path])
        return run_process(["python3", "-c", code or ""])
    if lang == "bash":
        if path:
            return run_process(["bash", path])
        return run_process(["bash", "-c", code or ""])
    if lang == "lua":
        sys.stderr.write(
            "Error: Lua support requires the `lua` executable. Install it from "
            "https://www.lua.org/download.html and ensure it is on your PATH.\n"
        )
        return 1
    if lang in ("javascript", "js"):
        return run_process(["node", path] if path else ["node", "-e", code or ""])
    if lang == "ruby":
        return run_process(["ruby", path] if path else ["ruby", "-e", code or ""])
    if lang == "perl":
        return run_process(["perl", path] if path else ["perl", "-e", code or ""])
    if lang == "c":
        return execute_c(code, path)
    if lang in ("cpp", "c++"):
        return execute_cpp(code, path)
    if lang == "go":
        return execute_go(code, path)
    if lang == "rust":
        return execute_rust(code, path)
    return run_process([lang, path] if path else [lang, "-c", code or ""])


def read_source(code, path):
    if path:
        with open(path, "r", encoding="utf-8") as f:
            return f.read()
    return code or ""


def run_compile_and_binary(compile_argv, binary):
    status = run_process(compile_argv)
    if status != 0:
        return status
    return run_process([binary])


def c_source_for(source):
    if "int main" in source:
        return source
    return "#include <stdio.h>\nint main(){\n    " + source + "\n    return 0;\n}\n"


def execute_c(code, path):
    source = c_source_for(read_source(code, path))
    with tempfile.TemporaryDirectory(prefix="run-c") as td:
        src = os.path.join(td, "main.c")
        binary = os.path.join(td, "main")
        with open(src, "w", encoding="utf-8") as f:
            f.write(source)
        return run_compile_and_binary(["gcc", src, "-o", binary], binary)


def execute_cpp(code, path):
    source = read_source(code, path)
    with tempfile.TemporaryDirectory(prefix="run-cpp") as td:
        src = os.path.join(td, "main.cpp")
        binary = os.path.join(td, "main")
        with open(src, "w", encoding="utf-8") as f:
            f.write(source)
        return run_compile_and_binary(["g++", src, "-o", binary], binary)


def execute_go(code, path):
    source = read_source(code, path)
    with tempfile.TemporaryDirectory(prefix="run-go") as td:
        src = os.path.join(td, "main.go")
        with open(src, "w", encoding="utf-8") as f:
            f.write(source)
        return run_process(["go", "run", src])


def execute_rust(code, path):
    source = read_source(code, path)
    with tempfile.TemporaryDirectory(prefix="run-rust") as td:
        src = os.path.join(td, "main.rs")
        binary = os.path.join(td, "main")
        with open(src, "w", encoding="utf-8") as f:
            f.write(source)
        return run_compile_and_binary(["rustc", src, "-o", binary], binary)


def main():
    args = sys.argv[1:]
    if args and args[0] in ("--version", "-V"):
        sys.stdout.write(VERSION)
        return 0
    if args and args[0] in ("--help", "-h"):
        sys.stdout.write(HELP)
        return 0
    for i, arg in enumerate(args):
        if arg in VALUE_OPTIONS and i + 1 == len(args):
            sys.stderr.write(clap_missing_value(arg))
            return 2
        if arg.startswith("-") and arg not in VALUE_OPTIONS and arg not in ("--no-detect",):
            sys.stderr.write(clap_unexpected(arg))
            return 2
    parsed = parse_args(args)
    if parsed["code"] and parsed["file"]:
        sys.stderr.write("Error: --code/--inline cannot be combined with --file\n")
        return 1
    if parsed["file"] and parsed["positionals"]:
        sys.stderr.write("Error: Unexpected positional arguments when --file is present\n")
        return 1
    if parsed["code"] and len(parsed["positionals"]) > (0 if parsed["lang"] else 1):
        sys.stderr.write("Error: Unexpected positional arguments after specifying --code\n")
        return 1
    lang = parsed["lang"]
    code = parsed["code"]
    path = parsed["file"]
    positionals = parsed["positionals"]
    if not lang and positionals:
        first = positionals[0]
        known = normalize_lang(first)
        if known in ("python", "bash"):
            lang = first
            if code is None and len(positionals) > 1:
                code = " ".join(positionals[1:])
        elif not path and code is None:
            path = first
    elif lang and code is None and not path and positionals:
        code = " ".join(positionals)
    if code is not None or path is not None:
        lang = lang or detect_language(code, path, parsed["no_detect"])
        return execute(lang, code, path)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
