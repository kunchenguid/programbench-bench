#!/bin/bash
set -e
rm -f executable
cp run.py executable
chmod +x executable
