import subprocess
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
EXE = ROOT / "executable"


def run_cmd(*args, input_text=None):
    return subprocess.run(
        [str(EXE), *args],
        input=input_text,
        text=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
    )


def test_version_output():
    result = run_cmd("--version")
    assert result.returncode == 0
    assert result.stdout == (
        "run-kit 0.3.2\n"
        "Universal multi-language runner and smart REPL\n"
        "author: Esubalew Chekol <esubalewchekol6@gmail.com>\n"
        "homepage: https://esubalew.et\n"
        "repository: https://github.com/Esubaalew/run\n"
        "license: Apache-2.0\n"
        "commit: 0050c88 (2026-03-03T12:39:28-08:00, dirty: dirty)\n"
        "built: 2026-04-17T19:59:44.418829299+00:00 [release for x86_64-unknown-linux-gnu]\n"
        "rustc: rustc 1.92.0 (ded5c06cf 2025-12-08)\n"
    )
    assert result.stderr == ""


def test_help_output():
    result = run_cmd("--help")
    assert result.returncode == 0
    assert result.stdout == (
        "Universal multi-language runner and REPL\n\n"
        "Usage: executable [OPTIONS] [ARGS]...\n\n"
        "Arguments:\n"
        "  [ARGS]...  Positional arguments (language, code, or file)\n\n"
        "Options:\n"
        "  -V, --version      Print version information and exit\n"
        "  -l, --lang <LANG>  Explicitly choose the language to execute\n"
        "  -f, --file <PATH>  Execute code from the provided file path\n"
        "  -c, --code <CODE>  Execute the provided code snippet\n"
        "      --no-detect    Disable heuristic language detection\n"
        "  -h, --help         Print help\n"
    )
    assert result.stderr == ""


def test_unknown_option_matches_clap_error():
    result = run_cmd("--bad")
    assert result.returncode == 2
    assert result.stdout == ""
    assert result.stderr == (
        "error: unexpected argument '--bad' found\n\n"
        "  tip: to pass '--bad' as a value, use '-- --bad'\n\n"
        "Usage: executable [OPTIONS] [ARGS]...\n\n"
        "For more information, try '--help'.\n"
    )


def test_option_requires_value():
    result = run_cmd("--lang")
    assert result.returncode == 2
    assert result.stdout == ""
    assert result.stderr == (
        "error: a value is required for '--lang <LANG>' but none was supplied\n\n"
        "For more information, try '--help'.\n"
    )


def test_python_snippet_with_explicit_language():
    result = run_cmd("--lang", "python", "--code", "print('hello')")
    assert result.returncode == 0
    assert result.stdout == "hello\n"
    assert result.stderr == ""


def test_positional_language_and_code():
    result = run_cmd("python", "print(5)")
    assert result.returncode == 0
    assert result.stdout == "5\n"
    assert result.stderr == ""


def test_stdin_is_forwarded_to_language_process():
    result = run_cmd(
        "python",
        "--code",
        "import sys; print(sys.stdin.read().strip().upper())",
        input_text="Hello\n",
    )
    assert result.returncode == 0
    assert result.stdout == "HELLO\n"
    assert result.stderr == ""


def test_shell_snippet_detection():
    result = run_cmd("--code", "echo hi")
    assert result.returncode == 0
    assert result.stdout == "hi\n"
    assert result.stderr == ""


def test_python_file_detected_from_extension(tmp_path):
    script = tmp_path / "hello.py"
    script.write_text("print(11)\n")
    result = run_cmd(str(script))
    assert result.returncode == 0
    assert result.stdout == "11\n"
    assert result.stderr == ""


def test_shell_file_detected_from_extension(tmp_path):
    script = tmp_path / "hello.sh"
    script.write_text("echo 13\n")
    result = run_cmd(str(script))
    assert result.returncode == 0
    assert result.stdout == "13\n"
    assert result.stderr == ""


def test_code_and_file_are_rejected():
    result = run_cmd("--lang", "python", "--file", "/tmp/nope.py", "--code", "print(1)")
    assert result.returncode == 1
    assert result.stdout == ""
    assert result.stderr == "Error: --code/--inline cannot be combined with --file\n"


def test_file_rejects_extra_positionals():
    result = run_cmd("--file", "/tmp/nope.py", "extra")
    assert result.returncode == 1
    assert result.stdout == ""
    assert result.stderr == "Error: Unexpected positional arguments when --file is present\n"


def test_c_statement_is_wrapped_and_executed():
    result = run_cmd("--lang", "c", "--code", 'printf("hi\\n");')
    assert result.returncode == 0
    assert result.stdout == "hi\n"
    assert result.stderr == ""


def test_go_full_source_executes():
    source = 'package main\nimport "fmt"\nfunc main(){fmt.Println("go")}'
    result = run_cmd("--lang", "go", "--code", source)
    assert result.returncode == 0
    assert result.stdout == "go\n"
    assert result.stderr == ""


def test_rust_full_source_executes():
    result = run_cmd("--lang", "rust", "--code", 'fn main(){println!("rs");}')
    assert result.returncode == 0
    assert result.stdout == "rs\n"
    assert result.stderr == ""


def test_perl_snippet_executes():
    result = run_cmd("--lang", "perl", "--code", "print 42")
    assert result.returncode == 0
    assert result.stdout == "42"
    assert result.stderr == ""


def test_go_file_detected_from_extension(tmp_path):
    script = tmp_path / "main.go"
    script.write_text('package main\nimport "fmt"\nfunc main(){fmt.Println("filego")}\n')
    result = run_cmd(str(script))
    assert result.returncode == 0
    assert result.stdout == "filego\n"
    assert result.stderr == ""


def test_no_detect_defaults_inline_code_to_python():
    result = run_cmd("--no-detect", "--code", "print(9)")
    assert result.returncode == 0
    assert result.stdout == "9\n"
    assert result.stderr == ""


def test_default_print_detection_reports_lua_missing():
    result = run_cmd("--code", "print(1)")
    assert result.returncode == 1
    assert result.stdout == ""
    assert result.stderr == (
        "Error: Lua support requires the `lua` executable. Install it from "
        "https://www.lua.org/download.html and ensure it is on your PATH.\n"
    )
