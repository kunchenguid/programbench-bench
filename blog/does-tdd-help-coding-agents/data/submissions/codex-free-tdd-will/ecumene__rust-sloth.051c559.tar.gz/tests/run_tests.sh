#!/bin/bash
set -euo pipefail

./compile.sh >/tmp/sloth-build.log

help_out="$(./executable --help)"
[[ "$help_out" == *"Sloth 0.1"* ]]
[[ "$help_out" == *"USAGE:"* ]]
[[ "$help_out" == *"SUBCOMMANDS:"* ]]

version_out="$(./executable --version)"
test "$version_out" = "Sloth 0.1"

image_help="$(./executable image --help)"
[[ "$image_help" == *"executable-image"* ]]
[[ "$image_help" == *"--webify <frame count>"* ]]

cat > /tmp/sloth-triangle.obj <<'OBJ'
v -1 -1 0
v 1 -1 0
v 0 1 0
f 1 2 3
OBJ

./executable /tmp/sloth-triangle.obj image -w 12 -h 6 > /tmp/sloth-image.out
python3 - <<'PY'
import re
raw = open('/tmp/sloth-image.out', 'rb').read().decode('latin1')
assert '\x1b[48;2;25;25;25m' in raw
plain = re.sub(r'\x1b\[[0-9;]*m', '', raw)
lines = plain.splitlines()
assert len(lines) == 6, (len(lines), lines)
assert all(len(line) == 12 for line in lines), [len(line) for line in lines]
assert any(ch != ' ' for line in lines for ch in line), repr(plain)
PY

cat > /tmp/sloth-colored.mtl <<'MTL'
newmtl Hot
Kd 0.640000 0.102425 0.091882
MTL
cat > /tmp/sloth-colored.obj <<'OBJ'
mtllib sloth-colored.mtl
v -1 -1 0
v 1 -1 0
v 0 1 0
usemtl Hot
f 1 2 3
OBJ

./executable /tmp/sloth-colored.obj image -w 8 -h 4 > /tmp/sloth-colored.out
grep -Fq $'\033[38;2;163;26;23m' /tmp/sloth-colored.out

./executable /tmp/sloth-colored.obj image -j 2 -w 8 -h 4 > /tmp/sloth-web.out
grep -Fq 'let frames = [' /tmp/sloth-web.out
grep -Fq '<span style="color:rgb(163,26,23)">' /tmp/sloth-web.out
grep -Fq '`];' /tmp/sloth-web.out
