#include <ctype.h>
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define SLOTH_PI 3.14159265358979323846

typedef struct { double x, y, z; } Vec3;
typedef struct { unsigned char r, g, b; } Color;
typedef struct { int a, b, c; Color color; } Face;
typedef struct { Vec3 *v; int nv, cv; Face *f; int nf, cf; } Mesh;
typedef struct { char name[96]; Color color; } Material;

static const Color BG = {25, 25, 25};
static const Color BLACK = {0, 0, 0};
static const Color WHITE = {255, 255, 0};
static const Color DEFAULT_COLOR = {163, 163, 163};

static void print_help(void) {
    puts("Sloth 0.1");
    puts("Mitchell Hynes. <mshynes@mun.ca>");
    puts("A toy for rendering 3D objects in the command line");
    puts("");
    puts("USAGE:");
    puts("    executable [FLAGS] [OPTIONS] <input filename(s)>... [SUBCOMMAND]");
    puts("");
    puts("FLAGS:");
    puts("    -h, --help       Prints help information");
    puts("    -b               Flags the rasterizer to render without color");
    puts("    -V, --version    Prints version information");
    puts("");
    puts("OPTIONS:");
    puts("    -x, --yaw <x>      Sets the object's static X rotation (in radians)");
    puts("    -y, --pitch <y>    Sets the object's static Y rotation (in radians)");
    puts("    -z, --roll <z>     Sets the object's static Z rotation (in radians)");
    puts("");
    puts("ARGS:");
    puts("    <input filename(s)>...    Sets the input file to render");
    puts("");
    puts("SUBCOMMANDS:");
    puts("    help     Prints this message or the help of the given subcommand(s)");
    puts("    image    Generates a colorless terminal output as lines of text");
}

static void print_image_help(void) {
    puts("executable-image ");
    puts("Mitchell Hynes <mitchell.hynes@ecumene.xyz>");
    puts("Generates a colorless terminal output as lines of text");
    puts("");
    puts("USAGE:");
    puts("    executable <input filename(s)>... image [FLAGS] [OPTIONS] -w <width>");
    puts("");
    puts("FLAGS:");
    puts("        --help       Prints help information");
    puts("    -b               Flags the rasterizer to render without color");
    puts("    -V, --version    Prints version information");
    puts("");
    puts("OPTIONS:");
    puts("    -j, --webify <frame count>    Generates a portable JS based render of your object for the web");
    puts("    -h <height>                   Sets the height of the image to generate");
    puts("    -w <width>                    Sets the width of the image to generate");
    puts("    -x, --yaw <x>                 Sets the object's static X rotation (in radians)");
    puts("    -y, --pitch <y>               Sets the object's static Y rotation (in radians)");
    puts("    -z, --roll <z>                Sets the object's static Z rotation (in radians)");
}

static void die(const char *msg) {
    fprintf(stderr, "%s\n", msg);
    exit(1);
}

static void mesh_add_vertex(Mesh *m, Vec3 v) {
    if (m->nv == m->cv) {
        m->cv = m->cv ? m->cv * 2 : 256;
        m->v = realloc(m->v, (size_t)m->cv * sizeof(Vec3));
        if (!m->v) die("out of memory");
    }
    m->v[m->nv++] = v;
}

static void mesh_add_face(Mesh *m, int a, int b, int c, Color color) {
    if (a < 0 || b < 0 || c < 0 || a >= m->nv || b >= m->nv || c >= m->nv) return;
    if (m->nf == m->cf) {
        m->cf = m->cf ? m->cf * 2 : 256;
        m->f = realloc(m->f, (size_t)m->cf * sizeof(Face));
        if (!m->f) die("out of memory");
    }
    m->f[m->nf++] = (Face){a, b, c, color};
}

static int parse_face_index(const char *s, int nv) {
    int idx = atoi(s);
    if (idx < 0) return nv + idx;
    return idx > 0 ? idx - 1 : -1;
}

static int load_mtl(const char *obj_path, const char *mtllib, Material **out) {
    char path[1024];
    const char *slash = strrchr(obj_path, '/');
    if (slash) {
        size_t n = (size_t)(slash - obj_path + 1);
        if (n >= sizeof(path)) return 0;
        memcpy(path, obj_path, n);
        snprintf(path + n, sizeof(path) - n, "%s", mtllib);
    } else {
        snprintf(path, sizeof(path), "%s", mtllib);
    }
    FILE *fp = fopen(path, "r");
    if (!fp) return 0;
    Material *mat = NULL;
    int nm = 0, cm = 0, cur = -1;
    char line[512];
    while (fgets(line, sizeof(line), fp)) {
        char name[96];
        double r, g, b;
        if (sscanf(line, "newmtl %95s", name) == 1) {
            if (nm == cm) {
                cm = cm ? cm * 2 : 16;
                mat = realloc(mat, (size_t)cm * sizeof(Material));
                if (!mat) die("out of memory");
            }
            snprintf(mat[nm].name, sizeof(mat[nm].name), "%s", name);
            mat[nm].color = DEFAULT_COLOR;
            cur = nm++;
        } else if (cur >= 0 && sscanf(line, "Kd %lf %lf %lf", &r, &g, &b) == 3) {
            mat[cur].color.r = (unsigned char)lrint(fmax(0, fmin(255, r * 255.0)));
            mat[cur].color.g = (unsigned char)lrint(fmax(0, fmin(255, g * 255.0)));
            mat[cur].color.b = (unsigned char)lrint(fmax(0, fmin(255, b * 255.0)));
        }
    }
    fclose(fp);
    *out = mat;
    return nm;
}

static Color find_mat(Material *m, int n, const char *name, Color fallback) {
    for (int i = 0; i < n; i++) if (!strcmp(m[i].name, name)) return m[i].color;
    return fallback;
}

static void load_obj(const char *path, Mesh *mesh) {
    FILE *fp = fopen(path, "r");
    if (!fp) {
        fprintf(stderr, "filename: [%s] couldn't load, tobj couldnt load/parse OBJ. open file failed\n", path);
        exit(101);
    }
    Material *mats = NULL;
    int nmats = 0;
    Color cur = DEFAULT_COLOR;
    char line[1024];
    while (fgets(line, sizeof(line), fp)) {
        double x, y, z;
        char word[128];
        if (sscanf(line, "v %lf %lf %lf", &x, &y, &z) == 3) {
            mesh_add_vertex(mesh, (Vec3){x, y, z});
        } else if (sscanf(line, "mtllib %127s", word) == 1) {
            free(mats);
            mats = NULL;
            nmats = load_mtl(path, word, &mats);
        } else if (sscanf(line, "usemtl %127s", word) == 1) {
            cur = find_mat(mats, nmats, word, cur);
        } else if (line[0] == 'f' && isspace((unsigned char)line[1])) {
            char *tok[128];
            int nt = 0;
            char *p = strtok(line + 1, " \t\r\n");
            while (p && nt < 128) {
                tok[nt++] = p;
                p = strtok(NULL, " \t\r\n");
            }
            if (nt >= 3) {
                int a = parse_face_index(tok[0], mesh->nv);
                for (int i = 1; i + 1 < nt; i++) {
                    int b = parse_face_index(tok[i], mesh->nv);
                    int c = parse_face_index(tok[i + 1], mesh->nv);
                    mesh_add_face(mesh, a, b, c, cur);
                }
            }
        }
    }
    fclose(fp);
    free(mats);
}

static void load_stl(const char *path, Mesh *mesh) {
    FILE *fp = fopen(path, "r");
    if (!fp) {
        fprintf(stderr, "filename: [%s] couldn't load\n", path);
        exit(101);
    }
    char line[512];
    int tri[3], n = 0;
    while (fgets(line, sizeof(line), fp)) {
        double x, y, z;
        if (sscanf(line, " vertex %lf %lf %lf", &x, &y, &z) == 3 ||
            sscanf(line, "      vertex %lf %lf %lf", &x, &y, &z) == 3) {
            tri[n++] = mesh->nv;
            mesh_add_vertex(mesh, (Vec3){x, y, z});
            if (n == 3) {
                mesh_add_face(mesh, tri[0], tri[1], tri[2], WHITE);
                n = 0;
            }
        }
    }
    fclose(fp);
}

static int ends_with(const char *s, const char *suffix) {
    size_t a = strlen(s), b = strlen(suffix);
    return a >= b && !strcmp(s + a - b, suffix);
}

static void load_mesh_file(const char *path, Mesh *mesh) {
    if (ends_with(path, ".stl") || ends_with(path, ".STL")) load_stl(path, mesh);
    else load_obj(path, mesh);
}

static Vec3 rotate_vec(Vec3 p, double rx, double ry, double rz) {
    double c = cos(rx), s = sin(rx);
    p = (Vec3){p.x, p.y * c - p.z * s, p.y * s + p.z * c};
    c = cos(ry); s = sin(ry);
    p = (Vec3){p.x * c + p.z * s, p.y, -p.x * s + p.z * c};
    c = cos(rz); s = sin(rz);
    p = (Vec3){p.x * c - p.y * s, p.x * s + p.y * c, p.z};
    return p;
}

static double edge(double ax, double ay, double bx, double by, double px, double py) {
    return (px - ax) * (by - ay) - (py - ay) * (bx - ax);
}

static char shade_char(Vec3 a, Vec3 b, Vec3 c) {
    Vec3 u = {b.x - a.x, b.y - a.y, b.z - a.z};
    Vec3 v = {c.x - a.x, c.y - a.y, c.z - a.z};
    Vec3 n = {u.y * v.z - u.z * v.y, u.z * v.x - u.x * v.z, u.x * v.y - u.y * v.x};
    double len = sqrt(n.x * n.x + n.y * n.y + n.z * n.z);
    double light = len ? fabs(n.z) / len : 0.5;
    if (light > 0.75) return '#';
    if (light > 0.45) return '*';
    if (light > 0.20) return '-';
    return '.';
}

static void render_to_buffers(const Mesh *mesh, int w, int h, double rx, double ry, double rz,
                              Color *colors, char *chars) {
    for (int i = 0; i < w * h; i++) {
        colors[i] = BLACK;
        chars[i] = ' ';
    }
    if (mesh->nv == 0 || mesh->nf == 0 || w <= 0 || h <= 0) return;
    Vec3 *rv = malloc((size_t)mesh->nv * sizeof(Vec3));
    double minx = 1e100, miny = 1e100, minz = 1e100;
    double maxx = -1e100, maxy = -1e100, maxz = -1e100;
    Vec3 center = {0, 0, 0};
    for (int i = 0; i < mesh->nv; i++) {
        center.x += mesh->v[i].x; center.y += mesh->v[i].y; center.z += mesh->v[i].z;
    }
    center.x /= mesh->nv; center.y /= mesh->nv; center.z /= mesh->nv;
    for (int i = 0; i < mesh->nv; i++) {
        rv[i] = rotate_vec((Vec3){mesh->v[i].x - center.x, mesh->v[i].y - center.y, mesh->v[i].z - center.z}, rx, ry, rz);
        if (rv[i].x < minx) minx = rv[i].x;
        if (rv[i].x > maxx) maxx = rv[i].x;
        if (rv[i].y < miny) miny = rv[i].y;
        if (rv[i].y > maxy) maxy = rv[i].y;
        if (rv[i].z < minz) minz = rv[i].z;
        if (rv[i].z > maxz) maxz = rv[i].z;
    }
    double sx = (maxx - minx) ? (w - 1) / (maxx - minx) : 1.0;
    double sy = (maxy - miny) ? (h - 1) / (maxy - miny) : 1.0;
    double scale = fmin(sx, sy) * 0.88;
    double cx = (minx + maxx) / 2.0, cy = (miny + maxy) / 2.0;
    double *zbuf = malloc((size_t)w * (size_t)h * sizeof(double));
    for (int i = 0; i < w * h; i++) zbuf[i] = -1e100;
    for (int fi = 0; fi < mesh->nf; fi++) {
        Face f = mesh->f[fi];
        Vec3 p[3] = {rv[f.a], rv[f.b], rv[f.c]};
        double x[3], y[3];
        for (int k = 0; k < 3; k++) {
            x[k] = (p[k].x - cx) * scale + (w - 1) / 2.0;
            y[k] = (h - 1) / 2.0 - (p[k].y - cy) * scale;
        }
        int minpx = (int)floor(fmin(x[0], fmin(x[1], x[2])));
        int maxpx = (int)ceil(fmax(x[0], fmax(x[1], x[2])));
        int minpy = (int)floor(fmin(y[0], fmin(y[1], y[2])));
        int maxpy = (int)ceil(fmax(y[0], fmax(y[1], y[2])));
        if (minpx < 0) minpx = 0;
        if (minpy < 0) minpy = 0;
        if (maxpx >= w) maxpx = w - 1;
        if (maxpy >= h) maxpy = h - 1;
        double area = edge(x[0], y[0], x[1], y[1], x[2], y[2]);
        if (fabs(area) < 1e-12) continue;
        char ch = shade_char(p[0], p[1], p[2]);
        for (int yy = minpy; yy <= maxpy; yy++) for (int xx = minpx; xx <= maxpx; xx++) {
            double px = xx + 0.5, py = yy + 0.5;
            double w0 = edge(x[1], y[1], x[2], y[2], px, py) / area;
            double w1 = edge(x[2], y[2], x[0], y[0], px, py) / area;
            double w2 = edge(x[0], y[0], x[1], y[1], px, py) / area;
            if (w0 >= -1e-9 && w1 >= -1e-9 && w2 >= -1e-9) {
                double z = w0 * p[0].z + w1 * p[1].z + w2 * p[2].z;
                int idx = yy * w + xx;
                if (z >= zbuf[idx]) {
                    zbuf[idx] = z;
                    colors[idx] = f.color;
                    chars[idx] = ch;
                }
            }
        }
    }
    free(zbuf);
    free(rv);
}

static void print_ansi(const Mesh *mesh, int w, int h, double rx, double ry, double rz) {
    Color *colors = malloc((size_t)w * (size_t)h * sizeof(Color));
    char *chars = malloc((size_t)w * (size_t)h);
    if (!colors || !chars) die("out of memory");
    render_to_buffers(mesh, w, h, rx, ry, rz, colors, chars);
    for (int y = 0; y < h; y++) {
        for (int x = 0; x < w; x++) {
            int i = y * w + x;
            printf("\033[48;2;%d;%d;%dm\033[38;2;%d;%d;%dm%c\033[49m\033[39m",
                   BG.r, BG.g, BG.b, colors[i].r, colors[i].g, colors[i].b, chars[i]);
        }
        putchar('\n');
    }
    free(colors);
    free(chars);
}

static void print_webify(const Mesh *mesh, int w, int h, int frames, double rx, double ry, double rz) {
    if (frames < 1) frames = 1;
    puts("let frames = [");
    for (int f = 0; f < frames; f++) {
        Color *colors = malloc((size_t)w * (size_t)h * sizeof(Color));
        char *chars = malloc((size_t)w * (size_t)h);
        double spin = rz + (2.0 * SLOTH_PI * f / frames);
        render_to_buffers(mesh, w, h, rx, ry, spin, colors, chars);
        puts("`");
        for (int y = 0; y < h; y++) {
            for (int x = 0; x < w; x++) {
                int i = y * w + x;
                printf("<span style=\"color:rgb(%d,%d,%d)\">%c", colors[i].r, colors[i].g, colors[i].b, chars[i]);
            }
            putchar('\n');
        }
        printf("`%s\n", f + 1 == frames ? "];" : ",");
        free(colors);
        free(chars);
    }
}

int main(int argc, char **argv) {
    if (argc == 2 && (!strcmp(argv[1], "--help") || !strcmp(argv[1], "-h"))) { print_help(); return 0; }
    if (argc == 2 && (!strcmp(argv[1], "--version") || !strcmp(argv[1], "-V"))) { puts("Sloth 0.1"); return 0; }
    if (argc == 2 && !strcmp(argv[1], "image")) {
        fputs("error: The following required arguments were not provided:\n    -w <width>\n\nUSAGE:\n    executable <input filename(s)>... image [FLAGS] [OPTIONS] -w <width>\n\nFor more information try --help\n", stderr);
        return 1;
    }

    char *inputs[128];
    int ninputs = 0, image = 0, w = -1, h = -1, web = 0;
    double rx = 0, ry = 0, rz = 0;
    for (int i = 1; i < argc; i++) {
        if (!strcmp(argv[i], "help")) { print_help(); return 0; }
        if (!strcmp(argv[i], "image")) { image = 1; continue; }
        if (image && !strcmp(argv[i], "--help")) { print_image_help(); return 0; }
        if (!strcmp(argv[i], "-b")) continue;
        if ((!strcmp(argv[i], "-w")) && i + 1 < argc) { w = atoi(argv[++i]); continue; }
        if ((!strcmp(argv[i], "-h")) && i + 1 < argc) { h = atoi(argv[++i]); continue; }
        if ((!strcmp(argv[i], "-j") || !strcmp(argv[i], "--webify")) && i + 1 < argc) { web = atoi(argv[++i]); continue; }
        if ((!strcmp(argv[i], "-x") || !strcmp(argv[i], "--yaw")) && i + 1 < argc) { rx = atof(argv[++i]); continue; }
        if ((!strcmp(argv[i], "-y") || !strcmp(argv[i], "--pitch")) && i + 1 < argc) { ry = atof(argv[++i]); continue; }
        if ((!strcmp(argv[i], "-z") || !strcmp(argv[i], "--roll")) && i + 1 < argc) { rz = atof(argv[++i]); continue; }
        if (!image && ninputs < 128) inputs[ninputs++] = argv[i];
    }
    if (ninputs == 0) {
        fputs("error: The following required arguments were not provided:\n    <input filename(s)>...\n\nUSAGE:\n    executable [FLAGS] [OPTIONS] <input filename(s)>... [SUBCOMMAND]\n\nFor more information try --help\n", stderr);
        return 1;
    }
    if (image && w <= 0) {
        fputs("error: The following required arguments were not provided:\n    -w <width>\n\nUSAGE:\n    executable <input filename(s)>... image [FLAGS] [OPTIONS] -w <width>\n\nFor more information try --help\n", stderr);
        return 1;
    }
    if (!image) { w = 80; h = 24; }
    if (h <= 0) h = w / 2 > 0 ? w / 2 : 1;

    Mesh mesh = {0};
    for (int i = 0; i < ninputs; i++) load_mesh_file(inputs[i], &mesh);
    if (web > 0) print_webify(&mesh, w, h, web, rx, ry, rz);
    else print_ansi(&mesh, w, h, rx, ry, rz);
    free(mesh.v);
    free(mesh.f);
    return 0;
}
