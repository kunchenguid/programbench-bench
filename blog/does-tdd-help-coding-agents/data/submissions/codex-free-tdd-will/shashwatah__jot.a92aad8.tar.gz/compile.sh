#!/bin/bash
set -e
cp jot.py executable
chmod +x executable
