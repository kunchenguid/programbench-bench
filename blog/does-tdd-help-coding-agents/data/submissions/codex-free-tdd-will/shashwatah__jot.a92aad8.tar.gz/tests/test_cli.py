import os
import shutil
import subprocess
import tempfile
import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
EXE = ROOT / "jot.py"


class CliTest(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.home = Path(self.tmp.name) / "home"
        self.home.mkdir()
        self.vault_root = Path(self.tmp.name) / "vaults"
        self.vault_root.mkdir()

    def tearDown(self):
        self.tmp.cleanup()

    def run_cli(self, *args):
        env = os.environ.copy()
        env["HOME"] = str(self.home)
        result = subprocess.run(
            ["python3", str(EXE), *args],
            text=True,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            env=env,
        )
        return result.returncode, result.stdout

    def test_create_and_list_vault(self):
        code, out = self.run_cli("vault", "work", str(self.vault_root))
        self.assertEqual(code, 0, out)
        self.assertIn("vault \x1b[0;34mwork\x1b[0m created", out)
        self.assertTrue((self.vault_root / "work" / ".jot" / "data").is_file())

        code, out = self.run_cli("vault", "-l")
        self.assertEqual(code, 0, out)
        self.assertIn("   work \t " + str(self.vault_root), out)

    def test_enter_vault_then_create_note_and_folder(self):
        self.run_cli("vault", "work", str(self.vault_root))

        code, out = self.run_cli("enter", "work")
        self.assertEqual(code, 0, out)
        self.assertIn("entered \x1b[0;34mwork\x1b[0m", out)

        code, out = self.run_cli("note", "first")
        self.assertEqual(code, 0, out)
        self.assertIn("note \x1b[0;34mfirst\x1b[0m created", out)
        self.assertTrue((self.vault_root / "work" / "first.md").is_file())

        code, out = self.run_cli("folder", "docs")
        self.assertEqual(code, 0, out)
        self.assertIn("folder \x1b[0;34mdocs\x1b[0m created", out)
        self.assertTrue((self.vault_root / "work" / "docs").is_dir())

    def test_list_current_vault_tree_and_filters(self):
        self.run_cli("vault", "work", str(self.vault_root))
        self.run_cli("enter", "work")
        self.run_cli("note", "first")
        self.run_cli("folder", "docs")

        code, out = self.run_cli("list")
        self.assertEqual(code, 0, out)
        self.assertIn("work\n", out)
        self.assertIn("\x1b[0;34mfirst\x1b[0m", out)
        self.assertIn("docs", out)

        code, out = self.run_cli("list", "note")
        self.assertEqual(code, 0, out)
        self.assertIn("\x1b[0;34mfirst\x1b[0m", out)
        self.assertNotIn("docs", out)

        code, out = self.run_cli("list", "folder")
        self.assertEqual(code, 0, out)
        self.assertIn(".jot", out)
        self.assertIn("docs", out)
        self.assertNotIn("\x1b[0;34mfirst\x1b[0m", out)

    def test_chdir_move_rename_and_remove_note(self):
        self.run_cli("vault", "work", str(self.vault_root))
        self.run_cli("enter", "work")
        self.run_cli("folder", "docs")
        self.run_cli("note", "first")

        code, out = self.run_cli("move", "note", "first", "docs")
        self.assertEqual(code, 0, out)
        self.assertIn("note \x1b[0;34mfirst\x1b[0m moved", out)
        self.assertTrue((self.vault_root / "work" / "docs" / "first.md").is_file())

        code, out = self.run_cli("chdir", "docs")
        self.assertEqual(code, 0, out)
        self.assertIn("folder changed", out)

        code, out = self.run_cli("rename", "note", "first", "second")
        self.assertEqual(code, 0, out)
        self.assertIn("note \x1b[0;34mfirst\x1b[0m renamed to \x1b[0;34msecond\x1b[0m", out)
        self.assertTrue((self.vault_root / "work" / "docs" / "second.md").is_file())

        code, out = self.run_cli("remove", "note", "second")
        self.assertEqual(code, 0, out)
        self.assertIn("note \x1b[0;34msecond\x1b[0m removed", out)
        self.assertFalse((self.vault_root / "work" / "docs" / "second.md").exists())

    def test_config_editor_and_open_note(self):
        code, out = self.run_cli("config", "editor")
        self.assertEqual(code, 0, out)
        self.assertIn("editor: \x1b[0;34mnvim\x1b[0m", out)

        code, out = self.run_cli("config", "editor", "true")
        self.assertEqual(code, 0, out)
        self.assertIn("set \x1b[0;34meditor\x1b[0m to \x1b[0;34mtrue\x1b[0m", out)

        self.run_cli("vault", "work", str(self.vault_root))
        self.run_cli("enter", "work")
        self.run_cli("note", "first")
        code, out = self.run_cli("open", "first")
        self.assertEqual(code, 0, out)
        self.assertEqual(out, "")

    def test_help_output_names_commands(self):
        code, out = self.run_cli("--help")
        self.assertEqual(code, 0, out)
        self.assertIn("usage: jt <command>", out)
        self.assertIn("vault", out)
        self.assertIn("note", out)
        self.assertIn("config", out)


if __name__ == "__main__":
    unittest.main()
