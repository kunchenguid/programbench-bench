#!/usr/bin/env python3
import os
import shutil
import subprocess
import sys
from pathlib import Path


BLUE = "\033[0;34m"
RED = "\033[0;31m"
RESET = "\033[0m"


def color(text):
    return f"{BLUE}{text}{RESET}"


def home():
    return Path(os.environ.get("HOME", str(Path.home())))


def config_file():
    return home() / ".config" / "jot" / "config"


def vaults_file():
    return home() / ".local" / "share" / "jot" / "vaults"


def ensure_defaults():
    cf = config_file()
    if not cf.exists():
        cf.parent.mkdir(parents=True, exist_ok=True)
        cf.write_text("editor = 'nvim'\nconflict = true\n")
    vf = vaults_file()
    if not vf.exists():
        vf.parent.mkdir(parents=True, exist_ok=True)
        vf.write_text("current = ''\n\n[vaults]\n")


def read_vaults():
    ensure_defaults()
    current = ""
    vaults = {}
    in_vaults = False
    for line in vaults_file().read_text().splitlines():
        line = line.strip()
        if not line:
            continue
        if line == "[vaults]":
            in_vaults = True
            continue
        if "=" not in line:
            continue
        key, val = [part.strip() for part in line.split("=", 1)]
        if val.startswith("'") and val.endswith("'"):
            val = val[1:-1]
        if in_vaults:
            vaults[key] = val
        elif key == "current":
            current = val
    return current, vaults


def read_config():
    ensure_defaults()
    data = {}
    for line in config_file().read_text().splitlines():
        if "=" not in line:
            continue
        key, val = [part.strip() for part in line.split("=", 1)]
        if val.startswith("'") and val.endswith("'"):
            val = val[1:-1]
        data[key] = val
    return data


def write_config(data):
    config_file().parent.mkdir(parents=True, exist_ok=True)
    editor = data.get("editor", "nvim")
    conflict = data.get("conflict", "true")
    config_file().write_text(f"editor = '{editor}'\nconflict = {conflict}\n")


def write_vaults(current, vaults):
    vaults_file().parent.mkdir(parents=True, exist_ok=True)
    lines = [f"current = '{current}'", "", "[vaults]"]
    for name in sorted(vaults):
        lines.append(f"{name} = '{vaults[name]}'")
    vaults_file().write_text("\n".join(lines) + "\n")


def read_vault_data(vault_root):
    data = {"folder": ""}
    path = vault_root / ".jot" / "data"
    if not path.exists():
        return data
    for line in path.read_text().splitlines():
        if "=" not in line:
            continue
        key, val = [part.strip() for part in line.split("=", 1)]
        if val.startswith("'") and val.endswith("'"):
            val = val[1:-1]
        data[key] = val
    return data


def write_vault_data(vault_root, name, location, folder):
    path = vault_root / ".jot" / "data"
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(
        f"name = '{name}'\nlocation = '{location}'\nfolder = '{folder}'\nhistory = []\n"
    )


def active_vault():
    current, vaults = read_vaults()
    if not current or current not in vaults:
        print(f"{RED}error{RESET}: not inside a vault")
        return None
    root = Path(vaults[current]) / current
    data = read_vault_data(root)
    folder = data.get("folder", "")
    return current, vaults[current], root, folder


def create_vault(name, location):
    current, vaults = read_vaults()
    if name in vaults:
        print(f"{RED}error{RESET}: vault {name} already exists")
        return 0
    root = Path(location) / name
    (root / ".jot").mkdir(parents=True, exist_ok=True)
    (root / ".jot" / "data").write_text(
        f"name = '{name}'\nlocation = '{location}'\nfolder = ''\nhistory = []\n"
    )
    vaults[name] = location
    write_vaults(current, vaults)
    print(f"vault {color(name)} created")
    return 0


def list_vaults(show_locations=False):
    current, vaults = read_vaults()
    for name in sorted(vaults):
        prefix = f"\U0001f449 {color(name)}" if name == current else f"   {name}"
        if show_locations:
            print(f"{prefix} \t {vaults[name]}")
        else:
            print(prefix)
    return 0


def enter_vault(name):
    _current, vaults = read_vaults()
    if name not in vaults:
        print(f"{RED}error{RESET}: vault {name} doesn't exist")
        return 0
    root = Path(vaults[name]) / name
    data = read_vault_data(root)
    write_vault_data(root, name, vaults[name], data.get("folder", ""))
    write_vaults(name, vaults)
    print(f"entered {color(name)}")
    return 0


def current_dir():
    info = active_vault()
    if info is None:
        return None
    _name, _location, root, folder = info
    return info, root / folder


def valid_name(name):
    return name not in ("", ".", "..") and "/" not in name


def create_note(name):
    if not valid_name(name):
        print(f"{RED}error{RESET}: invalid name")
        return 0
    state = current_dir()
    if state is None:
        return 0
    _info, directory = state
    path = directory / f"{name}.md"
    if path.exists():
        print(f"{RED}error{RESET}: note {name} already exists")
        return 0
    directory.mkdir(parents=True, exist_ok=True)
    path.write_text("")
    print(f"note {color(name)} created")
    return 0


def create_folder(name):
    if not valid_name(name):
        print(f"{RED}error{RESET}: invalid name")
        return 0
    state = current_dir()
    if state is None:
        return 0
    _info, directory = state
    path = directory / name
    if path.exists():
        print(f"{RED}error{RESET}: folder {name} already exists")
        return 0
    path.mkdir(parents=True)
    print(f"folder {color(name)} created")
    return 0


def children_for(directory, item_type):
    entries = []
    for path in sorted(directory.iterdir(), key=lambda p: p.name.lower()):
        if path.name == ".jot" and item_type != "folder":
            continue
        if path.is_dir():
            if item_type in (None, "folder"):
                entries.append((path, path.name))
            elif item_type == "note":
                entries.append((path, None))
        elif path.is_file() and path.suffix == ".md" and item_type in (None, "note"):
            entries.append((path, color(path.stem)))
    return entries


def render_tree(directory, item_type, prefix=""):
    printable = [(path, label) for path, label in children_for(directory, item_type) if label is not None]
    hidden_dirs = [(path, label) for path, label in children_for(directory, item_type) if label is None]
    combined = printable + hidden_dirs
    lines = []
    for idx, (path, label) in enumerate(combined):
        last = idx == len(combined) - 1
        branch = "└── " if last else "├── "
        child_prefix = prefix + ("    " if last else "│   ")
        if label is not None:
            lines.append(prefix + branch + label)
        if path.is_dir() and path.name != ".jot":
            lines.extend(render_tree(path, item_type, child_prefix if label is not None else prefix))
    return lines


def list_items(item_type=None):
    aliases = {"nt": "note", "fd": "folder"}
    item_type = aliases.get(item_type, item_type)
    state = current_dir()
    if state is None:
        return 0
    (name, _location, root, folder), directory = state
    heading = name if not folder else f"{name} > {folder.replace(os.sep, ' > ')}"
    print(heading)
    for line in render_tree(directory, item_type):
        print(line)
    return 0


def canonical_type(item_type):
    return {"nt": "note", "fd": "folder", "vl": "vault"}.get(item_type, item_type)


def item_path(directory, item_type, name):
    item_type = canonical_type(item_type)
    if item_type == "note":
        return directory / f"{name}.md"
    if item_type == "folder":
        return directory / name
    return None


def chdir(folder_path):
    info = active_vault()
    if info is None:
        return 0
    name, location, root, folder = info
    base = root / folder
    target = (base / folder_path).resolve()
    root_resolved = root.resolve()
    try:
        target.relative_to(root_resolved)
    except ValueError:
        print(f"{RED}error{RESET}: path crosses the bounds of vault")
        return 0
    if not target.is_dir():
        print(f"{RED}error{RESET}: couldn't find the path specified")
        return 0
    new_folder = "" if target == root_resolved else str(target.relative_to(root_resolved))
    write_vault_data(root, name, location, new_folder)
    print("folder changed")
    return 0


def move_item(item_type, name, new_location):
    item_type = canonical_type(item_type)
    state = current_dir()
    if state is None:
        return 0
    _info, directory = state
    src = item_path(directory, item_type, name)
    if src is None or not src.exists():
        print(f"{RED}error{RESET}: couldn't find the {item_type} specified")
        return 0
    dest_dir = directory / new_location
    if not dest_dir.is_dir():
        print(f"{RED}error{RESET}: couldn't find the path specified")
        return 0
    shutil.move(str(src), str(dest_dir / src.name))
    print(f"{item_type} {color(name)} moved")
    return 0


def rename_item(item_type, name, new_name):
    item_type = canonical_type(item_type)
    if not valid_name(new_name):
        print(f"{RED}error{RESET}: invalid name")
        return 0
    if item_type == "vault":
        current, vaults = read_vaults()
        if name not in vaults:
            print(f"{RED}error{RESET}: couldn't find the vault specified")
            return 0
        base = Path(vaults[name])
        (base / name).rename(base / new_name)
        vaults[new_name] = vaults.pop(name)
        write_vaults(new_name if current == name else current, vaults)
        write_vault_data(base / new_name, new_name, vaults[new_name], "")
        print(f"vault {color(name)} renamed to {color(new_name)}")
        return 0
    state = current_dir()
    if state is None:
        return 0
    _info, directory = state
    src = item_path(directory, item_type, name)
    dest = item_path(directory, item_type, new_name)
    if src is None or not src.exists():
        print(f"{RED}error{RESET}: couldn't find the {item_type} specified")
        return 0
    src.rename(dest)
    print(f"{item_type} {color(name)} renamed to {color(new_name)}")
    return 0


def remove_item(item_type, name):
    item_type = canonical_type(item_type)
    if item_type == "vault":
        current, vaults = read_vaults()
        if name not in vaults:
            print(f"{RED}error{RESET}: couldn't find the vault specified")
            return 0
        shutil.rmtree(Path(vaults[name]) / name, ignore_errors=True)
        del vaults[name]
        write_vaults("" if current == name else current, vaults)
        print(f"vault {color(name)} removed")
        return 0
    state = current_dir()
    if state is None:
        return 0
    _info, directory = state
    path = item_path(directory, item_type, name)
    if path is None or not path.exists():
        print(f"{RED}error{RESET}: couldn't find the {item_type} specified")
        return 0
    if path.is_dir():
        shutil.rmtree(path)
    else:
        path.unlink()
    print(f"{item_type} {color(name)} removed")
    return 0


def config_cmd(args):
    data = read_config()
    if not args:
        editor = data.get("editor", "nvim")
        try:
            return subprocess.run([editor, str(config_file())]).returncode
        except FileNotFoundError:
            print(f"{RED}error{RESET}: editor not found")
            return 0
    key = args[0]
    if key not in ("editor", "conflict"):
        print(f"error: \"{key}\" isn't a valid value for '<config type>'")
        print("\t[possible values: editor, conflict]")
        print("")
        print("For more information try --help")
        return 2
    if len(args) == 1:
        print(f"{key}: {color(data.get(key, ''))}")
        return 0
    value = args[1]
    data[key] = value
    write_config(data)
    print(f"set {color(key)} to {color(value)}")
    return 0


def open_note(name):
    state = current_dir()
    if state is None:
        return 0
    _info, directory = state
    path = directory / f"{name}.md"
    if not path.exists():
        print(f"{RED}error{RESET}: couldn't find the note specified")
        return 0
    editor = read_config().get("editor", "nvim")
    try:
        subprocess.run([editor, str(path)])
    except FileNotFoundError:
        print(f"{RED}error{RESET}: editor not found")
    return 0


def vmove_item(item_type, name, vault_name):
    item_type = canonical_type(item_type)
    if item_type not in ("note", "folder"):
        print(f"{RED}error{RESET}: invalid item type")
        return 0
    state = current_dir()
    if state is None:
        return 0
    _current, vaults = read_vaults()
    if vault_name not in vaults:
        print(f"{RED}error{RESET}: vault {vault_name} doesn't exist")
        return 0
    _info, directory = state
    src = item_path(directory, item_type, name)
    if src is None or not src.exists():
        print(f"{RED}error{RESET}: couldn't find the {item_type} specified")
        return 0
    dest_root = Path(vaults[vault_name]) / vault_name
    shutil.move(str(src), str(dest_root / src.name))
    print(f"{item_type} {color(name)} moved")
    return 0


HELP = f"""{BLUE}________      _____ 
______(_)_______  /_
_____  /_  __ \\  __/
____  / / /_/ / /_  
___  /  \\____/\\__/  
/___/         ᵥ₀.₁.₂  
{RESET}         

usage: jt <command>

{BLUE}commands:{RESET}

create items
    {BLUE}vault{RESET}, {BLUE}vl{RESET}       create a vault or list vaults
    create items in current folder
        {BLUE}note{RESET}, {BLUE}nt{RESET}        create a note 
        {BLUE}folder{RESET}, {BLUE}fd{RESET}      create a folder

interact with items
    {BLUE}enter{RESET}, {BLUE}en{RESET}       enter a vault
    {BLUE}open{RESET}, {BLUE}op{RESET}        open a note from current folder
    {BLUE}opdir{RESET}, {BLUE}od{RESET}       open current folder in file explorer
    {BLUE}chdir{RESET}, {BLUE}cd{RESET}       change folder within current vault
    {BLUE}list{RESET}, {BLUE}ls{RESET}        list items in current folder

perform fs operations on items
    {BLUE}remove{RESET}, {BLUE}rm{RESET}      remove an item 
    {BLUE}rename{RESET}, {BLUE}rn{RESET}      rename an item 
    {BLUE}move{RESET}, {BLUE}mv{RESET}        move an item to a new location
    {BLUE}vmove{RESET}, {BLUE}vm{RESET}       move an item to a different vault

config
    {BLUE}config{RESET}, {BLUE}cf{RESET}      display, set or open config

get help 
    use {BLUE}help{RESET} or {BLUE}-h{RESET} and {BLUE}--help{RESET} flags along with a command to get corresponding help"""


COMMAND_HELP = {
    "vault": "executable-vault \ncreate a vault or list vaults\n\nUSAGE:\n    jt vault\n    jt vault -l\n    jt vault <vault name> <vault location>\n",
    "note": "executable-note \ncreate a note\n\nUSAGE:\n    jt note\n    jt note [note name]\n",
    "folder": "executable-folder \ncreate a folder\n\nUSAGE:\n    jt folder\n    jt folder [folder name]\n",
    "enter": "executable-enter \nenter a vault\n\nUSAGE:\n    executable enter <vault name>\n",
    "open": "executable-open \nopen a note (from the current folder)\n\nUSAGE:\n    executable open <note name>\n",
    "chdir": "executable-chdir \nchange folder within current vault\n\nUSAGE:\n    executable chdir <folder path>\n",
    "list": "executable-list \nlist items in current folder\n\nUSAGE:\n    executable list [item type]\n",
    "remove": "executable-remove \nremove an item\n\nUSAGE:\n    executable remove <item type> <name>\n",
    "rename": "executable-rename \nrename an item\n\nUSAGE:\n    executable rename <item type> <name> <new name>\n",
    "move": "executable-move \nmove an item\n\nUSAGE:\n    executable move <item type> <name> <new location>\n",
    "vmove": "executable-vmove \nmove notes and folders to a different vault\n\nUSAGE:\n    executable vmove <item type> <name> <vault name>\n",
    "config": "executable-config \ndisplay, set or open config\n\nUSAGE:\n    jt config <config type>\n    jt config <config type> [config value]\n",
}


def print_help(args):
    if not args:
        print(HELP)
        return 0
    cmd = {"vl": "vault", "nt": "note", "fd": "folder", "en": "enter", "op": "open", "cd": "chdir", "ls": "list", "rm": "remove", "rn": "rename", "mv": "move", "vm": "vmove", "cf": "config"}.get(args[0], args[0])
    if cmd in COMMAND_HELP:
        print(COMMAND_HELP[cmd])
        return 0
    print(f"error: The subcommand '{args[0]}' wasn't recognized")
    return 2


def main(argv):
    ensure_defaults()
    if not argv:
        print(HELP)
        return 2
    cmd = argv[0]
    if cmd in ("--help", "-h"):
        return print_help([])
    if cmd == "help":
        return print_help(argv[1:])
    if len(argv) > 1 and argv[-1] in ("--help", "-h"):
        return print_help([cmd])
    if cmd in ("vault", "vl"):
        if len(argv) == 1:
            return list_vaults(False)
        if len(argv) == 2 and argv[1] == "-l":
            return list_vaults(True)
        if len(argv) == 3:
            return create_vault(argv[1], argv[2])
    if cmd in ("enter", "en") and len(argv) == 2:
        return enter_vault(argv[1])
    if cmd in ("note", "nt") and len(argv) == 2:
        return create_note(argv[1])
    if cmd in ("folder", "fd") and len(argv) == 2:
        return create_folder(argv[1])
    if cmd in ("list", "ls"):
        if len(argv) == 1:
            return list_items()
        if len(argv) == 2:
            return list_items(argv[1])
    if cmd in ("chdir", "cd") and len(argv) == 2:
        return chdir(argv[1])
    if cmd in ("move", "mv") and len(argv) == 4:
        return move_item(argv[1], argv[2], argv[3])
    if cmd in ("rename", "rn") and len(argv) == 4:
        return rename_item(argv[1], argv[2], argv[3])
    if cmd in ("remove", "rm") and len(argv) == 3:
        return remove_item(argv[1], argv[2])
    if cmd in ("config", "cf"):
        return config_cmd(argv[1:])
    if cmd in ("open", "op") and len(argv) == 2:
        return open_note(argv[1])
    if cmd in ("vmove", "vm") and len(argv) == 4:
        return vmove_item(argv[1], argv[2], argv[3])
    print(f"error: The subcommand '{cmd}' wasn't recognized")
    return 2


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
