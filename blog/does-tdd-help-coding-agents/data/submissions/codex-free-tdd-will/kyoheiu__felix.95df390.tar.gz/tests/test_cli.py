import os
import pty
import select
import struct
import subprocess
import sys
import tempfile
import termios
import time
import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
APP = ROOT / "felix.py"


def run_fx(*args, cwd=None, env=None):
    merged_env = os.environ.copy()
    if env:
        merged_env.update(env)
    return subprocess.run(
        [sys.executable, str(APP), *args],
        cwd=cwd or ROOT,
        env=merged_env,
        text=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        check=False,
    )


class FelixCliTests(unittest.TestCase):
    def test_help_matches_public_manual_header(self):
        result = run_fx("--help")

        self.assertEqual(result.returncode, 0)
        self.assertEqual(result.stderr, "")
        self.assertTrue(
            result.stdout.startswith(
                "# felix v2.16.1\n"
                "A simple TUI file manager with vim-like keymapping.\n\n"
                "## Usage\n"
            )
        )
        self.assertIn("`--init`          => Returns a shell script", result.stdout)
        self.assertIn("For more details, visit https://github.com/kyoheiu/felix", result.stdout)

    def test_invalid_path_is_reported_without_error_status(self):
        result = run_fx("/definitely/not/a/felix/path")

        self.assertEqual(result.returncode, 0)
        self.assertEqual(result.stdout, "\n")
        self.assertEqual(
            result.stderr,
            "Invalid path: /definitely/not/a/felix/path\n`fx -h` shows help.\n",
        )

    def test_init_prints_shell_integration_snippet(self):
        result = run_fx("--init")

        self.assertEqual(result.returncode, 0)
        self.assertEqual(result.stderr, "")
        self.assertIn("# To be eval'ed in the calling shell\n", result.stdout)
        self.assertIn('runtime_dir="$XDG_RUNTIME_DIR/felix"', result.stdout)
        self.assertIn('SHELL_PID=\\$\\$ command fx "\\$@"', result.stdout)
        self.assertTrue(result.stdout.endswith('  )"\n'))

    def test_existing_file_path_is_not_a_directory(self):
        with tempfile.TemporaryDirectory() as tmp:
            file_path = Path(tmp) / "note.txt"
            file_path.write_text("hello")

            result = run_fx(str(file_path))

        self.assertEqual(result.returncode, 0)
        self.assertEqual(result.stdout, "")
        self.assertEqual(result.stderr, "Path should be directory.\n`fx -h` shows help.\n")

    def test_launch_without_terminal_reports_size_detection_error(self):
        with tempfile.TemporaryDirectory() as tmp:
            result = run_fx(tmp)

        self.assertEqual(result.returncode, 0)
        self.assertEqual(result.stdout, "")
        self.assertEqual(result.stderr, "Error: Cannot detect terminal size\n")

    def test_log_option_creates_log_file_under_xdg_data_home(self):
        with tempfile.TemporaryDirectory() as tmp:
            home = Path(tmp) / "home"
            data = Path(tmp) / "data"
            home.mkdir()
            data.mkdir()

            result = run_fx("-l", env={"HOME": str(home), "XDG_DATA_HOME": str(data)})

            log_dir = data / "felix" / "log"
            logs = list(log_dir.glob("*.log"))

        self.assertEqual(result.returncode, 0)
        self.assertEqual(result.stderr, "Error: Cannot detect terminal size\n")
        self.assertEqual(len(logs), 1)

    def test_terminal_file_creation_command_creates_file_and_quits(self):
        with tempfile.TemporaryDirectory() as tmp:
            master, slave = pty.openpty()
            try:
                termios.tcsetwinsize(slave, (40, 120))
            except AttributeError:
                import fcntl

                fcntl.ioctl(slave, termios.TIOCSWINSZ, struct.pack("HHHH", 40, 120, 0, 0))
            proc = subprocess.Popen(
                [sys.executable, str(APP), tmp],
                stdin=slave,
                stdout=slave,
                stderr=slave,
                env={**os.environ, "TERM": "xterm"},
                close_fds=True,
            )
            os.close(slave)
            try:
                time.sleep(0.2)
                os.write(master, b"inote.txt\r:q\r")
                proc.wait(timeout=2)
            finally:
                if proc.poll() is None:
                    proc.kill()
                os.close(master)

            self.assertEqual(proc.returncode, 0)
            self.assertEqual((Path(tmp) / "note.txt").read_text(), "")
