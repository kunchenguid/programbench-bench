#!/bin/bash
set -e
cp felix.py executable
chmod +x executable
