#!/usr/bin/env python3
import os
import select
import shutil
import sys
import termios
import tty
from datetime import datetime
from pathlib import Path


HELP = """# felix v2.16.1
A simple TUI file manager with vim-like keymapping.

## Usage
`fx` => Show items in the current directory.
`fx <directory path>` => Show items in the path.
Both relative and absolute path available.

## Options
`--help` | `-h`   => Print help.
`--log`  | `-l`   => Launch the app, automatically generating a log file.
`--init`          => Returns a shell script that can be sourcedfor
                     for shell integration.

## Manual
j / <Down>         :Go down.
k / <Up>           :Go up.
<C-d>              :Go down 1/2 page.
<C-u>>             :Go up 1/2 page.
h / <Left>         :Go to the parent directory if exists.
l / <Right> / <CR> :Open item or change directory.
gg                 :Go to the top.
G                  :Go to the bottom.
z<CR>              :Go to the home directory.
z {keyword}<CR>    :Jump to a directory that matches the keyword.
                    (zoxide required)
<C-o>              :Jump backward.
<C-i>              :Jump forward.
i{file name}<CR>   :Create a new empty file.
I{dir name}<CR>    :Create a new empty directory.
o                  :Open item in a new window.
e                  :Unpack archive/compressed file.
dd                 :Delete and yank item.
yy                 :Yank item.
p                  :Put yanked item(s) from register zero
                    in the current directory.
:reg               :Show registers. To hide it, press v.
"ayy               :Yank item to register a.
"add               :Delete and yank item to register a.
"Ayy               :Append item to register a.
"Add               :Delete and append item to register a.
"ap                :Put item(s) from register a.
V                  :Switch to the linewise visual mode.
  - y              :In the visual mode, yank selected item(s).
  - d              :In the visual mode, delete and yank selected item(s).
  - "ay            :In the visual mode, yank items to register a.
  - "ad            :In the visual mode, delete and yank items to register a.
  - "Ay            :In the visual mode, append items to register a.
  - "Ad            :In the visual mode, delete and append items to register a.
  - c              :Rename selected items in default editor.
u                  :Undo put/delete/rename.
<C-r>              :Redo put/delete/rename.
v                  :Toggle whether to show the preview.
s                  :Toggle between vertical / horizontal split in the preview mode.
<Alt-j>
 / <Alt-<Down>>    :Scroll down the preview text.
<Alt-k> 
 / <Alt-<Up>>      :Scroll up the preview text.
<BS>               :Toggle whether to show hidden items.
t                  :Toggle the sort order (name <-> modified time).
c                  :Switch to the rename mode.
/{keyword}         :Search items by a keyword.
n                  :Go forward to the item that matches the keyword.
N                  :Go backward to the item that matches the keyword.
:                  :Switch to the command line.
  - <C-r>a         :In the command line, paste item name in register a.
:cd<CR>            :Go to the home directory.
:cd {path}<CR>     :Go to the path.
:e<CR>             :Reload the current directory.
:config<CR>        :Go to the directory that contains the config file if exists.
:trash<CR>         :Go to the trash directory.
:empty<CR>         :Empty the trash directory.
:h<CR>             :Show help.
:q<CR>             :Exit.
:{command}         :Execute a command e.g. :zip test *.md
<Esc>              :Return to the normal mode.
<C-h>              :Works as Backspace after `i`, `I`, `c`, `/`, `:` and `z`.
ZZ                 :Exit without cd to last working directory
                    (if `match_vim_exit_behavior` is `false`).
ZQ                 :cd into the last working directory and exit
                    (if shell setting is ready and `match_vim_exit_behavior is `false`).

## Preview feature
By default, text files and directories can be previewed.
To preview images, you need to install chafa (>= v1.10.0).
Please see https://hpjansson.org/chafa/

## Configuration

*Both `config.yaml` and `config.yml` work.*

### Linux
config file    : $XDG_CONFIG_HOME/felix/config.yaml(config.yml)
trash directory: $XDG_DATA_HOME/felix/trash
log files      : $XDG_DATA_HOME/felix/log

### macOS
On macOS, felix looks for the config file in the following locations:

1. `$HOME/Library/Application Support/felix/config.yaml(config.yml)`
2. `$HOME/.config/felix/config.yaml`

trash directory: $HOME/Library/Application Support/felix/trash
log files      : $HOME/Library/Application Support/felix/log

### Windows
config file     : $PROFILE\\\\AppData\\\\Roaming\\\\felix\\\\config.yaml(config.yml)
trash directory : $PROFILE\\\\AppData\\\\Local\\\\felix\\\\trash
log files       : $PROFILE\\\\AppData\\\\Local\\\\felix\\\\log

For more details, visit https://github.com/kyoheiu/felix
"""

INIT = """# To be eval'ed in the calling shell
  eval "$(
    if [ -n "$XDG_RUNTIME_DIR" ]; then
      runtime_dir="$XDG_RUNTIME_DIR/felix"
    elif [ -n "$TMPDIR" ]; then
      runtime_dir="$TMPDIR/felix"
    else
      runtime_dir=/tmp/felix
    fi

    mkdir -p "$runtime_dir"

    # Clean up leftover LWD files
    find "$runtime_dir" -type f -and -mmin +1 -delete

    cat << EOF
fx() {
  local RUNTIME_DIR="$runtime_dir"
  SHELL_PID=\\$\\$ command fx "\\$@"

  if [ -f "\\$RUNTIME_DIR/\\$\\$" ]; then
    cd "\\$(cat "\\$RUNTIME_DIR/\\$\\$")"
    rm "\\$RUNTIME_DIR/\\$\\$"
  fi
}
EOF
  )"
"""


def main(argv):
    target = "."
    log = False
    if argv and argv[0] in ("-l", "--log"):
        log = True
        argv = argv[1:]
    if argv == ["--help"] or argv == ["-h"]:
        print(HELP, end="")
    elif argv == ["--init"]:
        print(INIT, end="")
    elif len(argv) == 1 and Path(argv[0]).exists() and not Path(argv[0]).is_dir():
        print("Path should be directory.", file=sys.stderr)
        print("`fx -h` shows help.", file=sys.stderr)
    elif len(argv) == 1 and not Path(argv[0]).is_dir():
        print()
        print(f"Invalid path: {argv[0]}", file=sys.stderr)
        print("`fx -h` shows help.", file=sys.stderr)
    else:
        if len(argv) == 1:
            target = argv[0]
        launch(target, log)
    return 0


def launch(path, log=False):
    if log:
        log_dir = data_home() / "felix" / "log"
        log_dir.mkdir(parents=True, exist_ok=True)
        stamp = datetime.now().strftime("%Y-%m-%d-%H-%M-%S")
        (log_dir / f"{stamp}.log").touch(exist_ok=True)
    ensure_app_dirs()
    try:
        size = os.get_terminal_size()
    except OSError:
        print("Error: Cannot detect terminal size", file=sys.stderr)
        return
    if size.columns < 60 or size.lines < 20:
        print("Error: Too small window size")
        return
    app = FelixTui(Path(path).resolve(), size)
    app.run()


def data_home():
    value = os.environ.get("XDG_DATA_HOME")
    if value:
        return Path(value)
    return Path(os.environ.get("HOME", ".")) / ".local" / "share"


def config_home():
    value = os.environ.get("XDG_CONFIG_HOME")
    if value:
        return Path(value)
    return Path(os.environ.get("HOME", ".")) / ".config"


def ensure_app_dirs():
    (config_home() / "felix").mkdir(parents=True, exist_ok=True)
    (data_home() / "felix" / "Trash").mkdir(parents=True, exist_ok=True)


class FelixTui:
    def __init__(self, cwd, size):
        self.cwd = cwd
        self.rows = size.lines
        self.cols = size.columns
        self.cursor = 0
        self.show_hidden = False
        self.sort_mtime = False
        self.register = []
        self.prefix = ""
        self.message = ""

    def run(self):
        old = termios.tcgetattr(sys.stdin.fileno())
        try:
            tty.setraw(sys.stdin.fileno())
            self.draw()
            while True:
                ch = sys.stdin.read(1)
                if not ch:
                    break
                if self.handle(ch):
                    break
                self.draw()
        finally:
            termios.tcsetattr(sys.stdin.fileno(), termios.TCSADRAIN, old)
            sys.stdout.write("\x1b[?25h\x1b[0m\x1b[2J\x1b[H")
            sys.stdout.flush()
            self.write_last_working_dir()

    def items(self):
        entries = []
        try:
            for child in self.cwd.iterdir():
                if not self.show_hidden and child.name.startswith("."):
                    continue
                entries.append(child)
        except OSError as exc:
            self.message = str(exc)
        if self.sort_mtime:
            entries.sort(key=lambda p: (not p.is_dir(), -p.stat().st_mtime, p.name.lower()))
        else:
            entries.sort(key=lambda p: (not p.is_dir(), p.name.lower()))
        return entries

    def selected(self):
        entries = self.items()
        if not entries:
            return None
        self.cursor = max(0, min(self.cursor, len(entries) - 1))
        return entries[self.cursor]

    def draw(self):
        entries = self.items()
        self.cursor = max(0, min(self.cursor, max(len(entries) - 1, 0)))
        sys.stdout.write("\x1b[?25l\x1b[2J\x1b[H")
        sys.stdout.write(f"felix {self.cwd}\r\n")
        sys.stdout.write("j/k move  h/l open  i file  I dir  dd delete  yy yank  p put  :q quit\r\n")
        limit = max(1, self.rows - 4)
        start = 0
        if self.cursor >= limit:
            start = self.cursor - limit + 1
        for idx, item in enumerate(entries[start : start + limit], start):
            marker = ">" if idx == self.cursor else " "
            suffix = "/" if item.is_dir() else ""
            name = (item.name + suffix)[: max(1, self.cols - 3)]
            sys.stdout.write(f"{marker} {name}\r\n")
        if self.message:
            sys.stdout.write(self.message[: self.cols] + "\r\n")
        sys.stdout.flush()

    def handle(self, ch):
        if ch == "\x1b":
            self.prefix = ""
            return False
        if ch == ":":
            return self.command_line(":")
        if ch == "/":
            self.search()
            return False
        if ch == "i":
            name = self.read_line("i")
            if name:
                (self.cwd / name).touch(exist_ok=True)
            return False
        if ch == "I":
            name = self.read_line("I")
            if name:
                (self.cwd / name).mkdir(exist_ok=True)
            return False
        if ch == "j":
            self.cursor += 1
        elif ch == "k":
            self.cursor -= 1
        elif ch == "G":
            self.cursor = max(0, len(self.items()) - 1)
        elif ch == "g":
            nxt = self.read_key()
            if nxt == "g":
                self.cursor = 0
        elif ch in ("\r", "\n", "l"):
            item = self.selected()
            if item and item.is_dir():
                self.cwd = item.resolve()
                self.cursor = 0
        elif ch == "h":
            parent = self.cwd.parent
            if parent != self.cwd:
                self.cwd = parent
                self.cursor = 0
        elif ch == "\x7f":
            self.show_hidden = not self.show_hidden
        elif ch == "t":
            self.sort_mtime = not self.sort_mtime
        elif ch == "d":
            if self.read_key() == "d":
                self.delete_selected()
        elif ch == "y":
            if self.read_key() == "y":
                item = self.selected()
                self.register = [item] if item else []
        elif ch == "p":
            self.put_register()
        elif ch == "Z":
            nxt = self.read_key()
            if nxt in ("Z", "Q"):
                return True
        return False

    def command_line(self, starter):
        text = self.read_line(starter)
        if text == "q":
            return True
        if text in ("h", "help"):
            self.message = "Press :q to exit. " + HELP.splitlines()[0]
            return False
        if text == "e":
            return False
        if text == "cd":
            self.cwd = Path(os.environ.get("HOME", str(self.cwd))).resolve()
            self.cursor = 0
            return False
        if text.startswith("cd "):
            target = Path(text[3:]).expanduser()
            if not target.is_absolute():
                target = self.cwd / target
            if target.is_dir():
                self.cwd = target.resolve()
                self.cursor = 0
            else:
                self.message = f"Invalid path: {target}"
            return False
        if text == "trash":
            self.cwd = (data_home() / "felix" / "Trash").resolve()
            self.cursor = 0
            return False
        if text == "empty":
            trash = data_home() / "felix" / "Trash"
            for child in trash.iterdir():
                remove_path(child)
            return False
        if text:
            os.system(text)
        return False

    def read_key(self):
        ready, _, _ = select.select([sys.stdin], [], [], 0.5)
        if ready:
            return sys.stdin.read(1)
        return ""

    def read_line(self, starter):
        buf = []
        sys.stdout.write("\x1b[?25h\r\n" + starter)
        sys.stdout.flush()
        while True:
            ch = sys.stdin.read(1)
            if ch in ("\r", "\n"):
                return "".join(buf)
            if ch == "\x1b":
                return ""
            if ch in ("\x7f", "\x08"):
                if buf:
                    buf.pop()
                    sys.stdout.write("\b \b")
                    sys.stdout.flush()
                continue
            buf.append(ch)
            sys.stdout.write(ch)
            sys.stdout.flush()

    def search(self):
        keyword = self.read_line("/")
        if not keyword:
            return
        for idx, item in enumerate(self.items()):
            if keyword.lower() in item.name.lower():
                self.cursor = idx
                return

    def delete_selected(self):
        item = self.selected()
        if not item:
            return
        self.register = [item]
        trash = data_home() / "felix" / "Trash"
        trash.mkdir(parents=True, exist_ok=True)
        dest = unique_path(trash / item.name)
        try:
            shutil.move(str(item), str(dest))
            self.register = [dest]
        except OSError as exc:
            self.message = str(exc)

    def put_register(self):
        for src in self.register:
            if not src.exists():
                continue
            dest = unique_path(self.cwd / src.name)
            try:
                if src.is_dir():
                    shutil.copytree(src, dest)
                else:
                    shutil.copy2(src, dest)
            except OSError as exc:
                self.message = str(exc)

    def write_last_working_dir(self):
        shell_pid = os.environ.get("SHELL_PID")
        if not shell_pid:
            return
        runtime = os.environ.get("XDG_RUNTIME_DIR") or os.environ.get("TMPDIR") or "/tmp"
        path = Path(runtime) / "felix"
        try:
            path.mkdir(parents=True, exist_ok=True)
            (path / shell_pid).write_text(str(self.cwd))
        except OSError:
            pass


def remove_path(path):
    if path.is_dir() and not path.is_symlink():
        shutil.rmtree(path)
    else:
        path.unlink(missing_ok=True)


def unique_path(path):
    if not path.exists():
        return path
    stem = path.stem
    suffix = path.suffix
    for number in range(1, 10000):
        candidate = path.with_name(f"{stem}_{number}{suffix}")
        if not candidate.exists():
            return candidate
    return path.with_name(f"{path.name}_{os.getpid()}")


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
