import os
import re
import stat
import subprocess
import sys
import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
EXE = ROOT / "executable"


HELP_TEXT = """ Usage: cmatrix -[abBcfhlsmVxk] [-u delay] [-C color] [-t tty] [-M message]
 -a: Asynchronous scroll
 -b: Bold characters on
 -B: All bold characters (overrides -b)
 -c: Use Japanese characters as seen in the original matrix. Requires appropriate fonts
 -f: Force the linux $TERM type to be on
 -l: Linux mode (uses matrix console font)
 -L: Lock mode (can be closed from another terminal)
 -o: Use old-style scrolling
 -h: Print usage and exit
 -n: No bold characters (overrides -b and -B, default)
 -s: "Screensaver" mode, exits on first keystroke
 -x: X window mode, use if your xterm is using mtx.pcf
 -V: Print version information and exit
 -M [message]: Prints your message in the center of the screen. Overrides -L's default message.
 -u delay (0 - 10, default 4): Screen update delay
 -C [color]: Use this color for matrix (default green)
 -r: rainbow mode
 -m: lambda mode
 -k: Characters change while scrolling. (Works without -o opt.)
 -t [tty]: Set tty to use
"""


class CMatrixCliTests(unittest.TestCase):
    def run_exe(self, *args, **kwargs):
        env = os.environ.copy()
        env["TERM"] = "xterm"
        return subprocess.run(
            [str(EXE), *args],
            text=True,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            env=env,
            **kwargs,
        )

    def test_help_prints_usage_and_exits_successfully(self):
        result = self.run_exe("--help")
        self.assertEqual(result.returncode, 0)
        self.assertEqual(result.stdout, HELP_TEXT)
        self.assertEqual(result.stderr, "")

    def test_version_prints_program_identity(self):
        result = self.run_exe("-V")
        self.assertEqual(result.returncode, 0)
        self.assertRegex(
            result.stdout,
            r"^ CMatrix version 2\.0 \(compiled .*?\)\n"
            r"Email: abishekvashok@gmail\.com\n"
            r"Web: https://github\.com/abishekvashok/cmatrix\n$",
        )
        self.assertEqual(result.stderr, "")

    def test_invalid_color_reports_valid_choices(self):
        result = self.run_exe("-C", "bad")
        self.assertEqual(result.returncode, 0)
        self.assertEqual(result.stdout, "")
        self.assertEqual(
            result.stderr,
            " Invalid color selection\n"
            " Valid colors are green, red, blue, white, yellow, cyan, magenta and black.\n",
        )

    def test_runtime_mode_quits_on_q_without_printing_usage(self):
        result = self.run_exe("-u", "0", input="q", timeout=1)
        self.assertEqual(result.returncode, 0)
        self.assertNotIn("Usage: cmatrix", result.stdout)
        self.assertIn("\x1b[", result.stdout)
        self.assertEqual(result.stderr, "")

    def test_unknown_options_print_usage(self):
        for option in ("-Z", "--version"):
            with self.subTest(option=option):
                result = self.run_exe(option)
                self.assertEqual(result.returncode, 0)
                self.assertEqual(result.stdout, HELP_TEXT)
                self.assertEqual(result.stderr, "")


if __name__ == "__main__":
    unittest.main()
