#!/usr/bin/env python3
import os
import random
import select
import shutil
import sys
import termios
import time
import tty


HELP_TEXT = """ Usage: cmatrix -[abBcfhlsmVxk] [-u delay] [-C color] [-t tty] [-M message]
 -a: Asynchronous scroll
 -b: Bold characters on
 -B: All bold characters (overrides -b)
 -c: Use Japanese characters as seen in the original matrix. Requires appropriate fonts
 -f: Force the linux $TERM type to be on
 -l: Linux mode (uses matrix console font)
 -L: Lock mode (can be closed from another terminal)
 -o: Use old-style scrolling
 -h: Print usage and exit
 -n: No bold characters (overrides -b and -B, default)
 -s: "Screensaver" mode, exits on first keystroke
 -x: X window mode, use if your xterm is using mtx.pcf
 -V: Print version information and exit
 -M [message]: Prints your message in the center of the screen. Overrides -L's default message.
 -u delay (0 - 10, default 4): Screen update delay
 -C [color]: Use this color for matrix (default green)
 -r: rainbow mode
 -m: lambda mode
 -k: Characters change while scrolling. (Works without -o opt.)
 -t [tty]: Set tty to use
"""

VERSION_TEXT = """ CMatrix version 2.0 (compiled 19:59:42, Apr 17 2026)
Email: abishekvashok@gmail.com
Web: https://github.com/abishekvashok/cmatrix
"""

VALID_COLORS = {"green", "red", "blue", "white", "yellow", "cyan", "magenta", "black"}
FLAGS_WITHOUT_ARGS = set("abBcfhlsLonVxrmk?")
FLAGS_WITH_ARGS = set("CuMt")
COLOR_CODES = {
    "black": 30,
    "red": 31,
    "green": 32,
    "yellow": 33,
    "blue": 34,
    "magenta": 35,
    "cyan": 36,
    "white": 37,
}
INVALID_COLOR_TEXT = (
    " Invalid color selection\n"
    " Valid colors are green, red, blue, white, yellow, cyan, magenta and black.\n"
)

CHARS = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789@#$%^&*()[]{}<>/?+-=~"


def main(argv):
    color = "green"
    delay = 4
    message = None
    lambda_mode = False
    rainbow = False

    i = 0
    while i < len(argv):
        arg = argv[i]
        if arg == "--help":
            sys.stdout.write(HELP_TEXT)
            return 0
        if arg.startswith("--"):
            sys.stdout.write(HELP_TEXT)
            return 0
        if not arg.startswith("-") or arg == "-":
            sys.stdout.write(HELP_TEXT)
            return 0

        j = 1
        while j < len(arg):
            opt = arg[j]
            if opt == "V":
                sys.stdout.write(VERSION_TEXT)
                return 0
            if opt in ("h", "?"):
                sys.stdout.write(HELP_TEXT)
                return 0
            if opt in FLAGS_WITH_ARGS:
                value = arg[j + 1 :]
                if not value:
                    i += 1
                    if i >= len(argv):
                        sys.stdout.write(HELP_TEXT)
                        return 0
                    value = argv[i]
                if opt == "C":
                    if value not in VALID_COLORS:
                        sys.stderr.write(INVALID_COLOR_TEXT)
                        return 0
                    color = value
                elif opt == "u":
                    try:
                        delay = max(0, min(10, int(value)))
                    except ValueError:
                        delay = 4
                elif opt == "M":
                    message = value
                elif opt == "t":
                    pass
                break
            if opt not in FLAGS_WITHOUT_ARGS:
                sys.stdout.write(HELP_TEXT)
                return 0
            if opt == "m":
                lambda_mode = True
            elif opt == "r":
                rainbow = True
            j += 1
        i += 1
    return run_matrix(color=color, delay=delay, message=message, lambda_mode=lambda_mode, rainbow=rainbow)


def read_key():
    ready, _, _ = select.select([sys.stdin], [], [], 0)
    if not ready:
        return ""
    try:
        return os.read(sys.stdin.fileno(), 1).decode("utf-8", "ignore")
    except OSError:
        return ""


def run_matrix(color, delay, message, lambda_mode, rainbow):
    if os.environ.get("TERM") in ("", "dumb", "unknown"):
        sys.stderr.write("Error opening terminal: unknown.\n")
        return 1

    rows, cols = shutil.get_terminal_size((80, 24))
    cols = max(20, cols)
    rows = max(10, rows)
    rng = random.Random()
    drops = [rng.randrange(-rows, rows) for _ in range(0, cols, 2)]
    speeds = [rng.randint(1, 3) for _ in drops]
    old_attrs = None
    if sys.stdin.isatty():
        try:
            old_attrs = termios.tcgetattr(sys.stdin)
            tty.setcbreak(sys.stdin.fileno())
        except termios.error:
            old_attrs = None

    sleep_time = 0.015 + (delay * 0.018)
    sys.stdout.write("\x1b[?1049h\x1b[?25l\x1b[H\x1b[2J")
    try:
        for frame in range(1000000):
            key = read_key()
            if key and (key == "q" or "-s" in sys.argv[1:]):
                break
            if key in "0123456789":
                sleep_time = 0.015 + (int(key) * 0.018)
            if key in "!@#$%^&)":
                color = {
                    "!": "red",
                    "@": "green",
                    "#": "yellow",
                    "$": "blue",
                    "%": "magenta",
                    "^": "cyan",
                    "&": "white",
                    ")": "black",
                }[key]

            if frame == 0:
                sys.stdout.write(f"\x1b[{COLOR_CODES[color]}m")
                for row in range(1, rows + 1):
                    sys.stdout.write(f"\x1b[{row};1H" + " " * cols)
            for i, x in enumerate(range(1, cols, 2)):
                drops[i] += speeds[i]
                if drops[i] > rows + rng.randint(1, rows):
                    drops[i] = -rng.randint(1, rows)
                    speeds[i] = rng.randint(1, 3)
                head = drops[i]
                tail = head - rng.randint(4, 12)
                if 1 <= tail <= rows:
                    sys.stdout.write(f"\x1b[{tail};{x}H ")
                if 1 <= head <= rows:
                    code = COLOR_CODES[color]
                    if rainbow:
                        code = 31 + ((i + frame) % 7)
                    ch = "λ" if lambda_mode else rng.choice(CHARS)
                    sys.stdout.write(f"\x1b[{head};{x}H\x1b[37m{ch}\x1b[{code}m")
                body = head - 1
                if 1 <= body <= rows:
                    ch = "λ" if lambda_mode else rng.choice(CHARS)
                    sys.stdout.write(f"\x1b[{body};{x}H{ch}")
            if message:
                y = rows // 2
                x = max(1, (cols - len(message)) // 2)
                sys.stdout.write(f"\x1b[{y};{x}H\x1b[37m{message}\x1b[{COLOR_CODES[color]}m")
            sys.stdout.flush()
            time.sleep(sleep_time)
    except KeyboardInterrupt:
        pass
    finally:
        if old_attrs is not None:
            termios.tcsetattr(sys.stdin, termios.TCSADRAIN, old_attrs)
        sys.stdout.write("\x1b[39m\x1b[?25h\x1b[H\x1b[2J\x1b[?1049l")
        sys.stdout.flush()
    return 0


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
