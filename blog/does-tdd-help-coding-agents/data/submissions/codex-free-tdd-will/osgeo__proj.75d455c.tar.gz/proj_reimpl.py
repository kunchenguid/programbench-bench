#!/usr/bin/env python3
import sys, math, os, re

VERSION = "Rel. 9.9.0, September 15th, 2026"
A_WGS84 = 6378137.0
F_INV_WGS84 = 298.257222101
F_WGS84 = 1.0 / F_INV_WGS84
E2_WGS84 = F_WGS84 * (2.0 - F_WGS84)
E_WGS84 = math.sqrt(E2_WGS84)

PROJ_NAMES = [
    ("adams_hemi", "Adams Hemisphere in a Square"),
    ("adams_ws1", "Adams World in a Square I"),
    ("adams_ws2", "Adams World in a Square II"),
    ("aea", "Albers Equal Area"),
    ("aeqd", "Azimuthal Equidistant"),
    ("affine", "Affine transformation"),
    ("airy", "Airy"),
    ("aitoff", "Aitoff"),
    ("alsk", "Modified Stereographic of Alaska"),
    ("apian", "Apian Globular I"),
    ("august", "August Epicycloidal"),
    ("axisswap", "Axis ordering"),
    ("bacon", "Bacon Globular"),
    ("bertin1953", "Bertin 1953"),
    ("bipc", "Bipolar conic of western hemisphere"),
    ("boggs", "Boggs Eumorphic"),
    ("bonne", "Bonne (Werner lat_1=90)"),
    ("cass", "Cassini"),
    ("cea", "Equal Area Cylindrical"),
    ("eqc", "Equidistant Cylindrical (Plate Carree)"),
    ("laea", "Lambert Azimuthal Equal Area"),
    ("lcc", "Lambert Conformal Conic"),
    ("longlat", "Lat/long (Geodetic)"),
    ("lonlat", "Lat/long (Geodetic)"),
    ("merc", "Mercator"),
    ("mill", "Miller Cylindrical"),
    ("moll", "Mollweide"),
    ("ortho", "Orthographic"),
    ("robin", "Robinson"),
    ("sinu", "Sinusoidal (Sanson-Flamsteed)"),
    ("stere", "Stereographic"),
    ("tmerc", "Transverse Mercator"),
    ("utm", "Universal Transverse Mercator (UTM)"),
    ("webmerc", "Web Mercator / Pseudo Mercator"),
]

ELLIPSOIDS = [
"    MERIT a=6378137.0      rf=298.257       MERIT 1983",
"    SGS85 a=6378136.0      rf=298.257       Soviet Geodetic System 85",
"    GRS80 a=6378137.0      rf=298.257222101 GRS 1980(IUGG, 1980)",
"     airy a=6377563.396    rf=299.3249646   Airy 1830",
"   bessel a=6377397.155    rf=299.1528128   Bessel 1841",
"   clrk66 a=6378206.4      b=6356583.8      Clarke 1866",
"     intl a=6378388.0      rf=297.          International 1924 (Hayford 1909, 1910)",
"    WGS72 a=6378135.0      rf=298.26        WGS 72",
"    WGS84 a=6378137.0      rf=298.257223563 WGS 84",
"   sphere a=6370997.0      b=6370997.0      Normal Sphere (r=6370997)",
]

UNITS = [
"          mm 0.001                millimetre",
"          cm 0.01                 centimetre",
"           m 1                    metre",
"          ft 0.3048               foot",
"       us-ft 0.304800609601219    US survey foot",
"         kmi 1852                 nautical mile",
"          km 1000                 kilometre",
"          mi 1609.344             Statute mile",
"          yd 0.9144               yard",
"          in 0.0254               inch",
]

def usage():
    print(VERSION)
    print(f"usage: {os.path.basename(sys.argv[0])} [-bdeEfiIlmorsStTvVwW [args]] [+opt[=arg] ...] [file ...]")

def die(msg, status=1, cause=None):
    print(VERSION, file=sys.stderr)
    print(f"<{os.path.basename(sys.argv[0])}>: ", file=sys.stderr)
    print(msg, file=sys.stderr)
    if cause:
        print(cause, file=sys.stderr)
    print("program abnormally terminated", file=sys.stderr)
    sys.exit(status)

def parse_num(tok):
    s = tok.strip()
    sign = -1 if s.startswith('-') else 1
    s2 = s.lstrip('+-')
    hemi = None
    if s2 and s2[-1].upper() in 'NSEW':
        hemi = s2[-1].upper(); s2 = s2[:-1]
    if 'd' in s2:
        parts = s2.replace("'", ' ').replace('"',' ').split('d')
        deg = float(parts[0] or 0)
        rest = parts[1].strip().split() if len(parts)>1 else []
        minutes = float(rest[0]) if rest else 0.0
        seconds = float(rest[1]) if len(rest)>1 else 0.0
        val = deg + minutes/60.0 + seconds/3600.0
    else:
        val = float(s2)
    if hemi in ('S','W'):
        sign = -1
    return sign * val

FLOAT_RE = re.compile(r'^[ \t]*([+-]?(?:(?:\d+(?:\.\d*)?)|(?:\.\d+))(?:[eE][+-]?\d+)?)')

def parse_coord_text(text):
    original = text
    s = text.lstrip(' \t')
    skipped = len(text) - len(s)
    if not s:
        return 0.0, ''
    token = s.split(None, 1)[0]
    if 'd' in token or (token and token[-1:].upper() in 'NSEW' and any(ch.isdigit() for ch in token)):
        try:
            val = parse_num(token)
            return val, s[len(token):]
        except Exception:
            pass
    m = FLOAT_RE.match(original)
    if not m:
        return 0.0, original
    return float(m.group(1)), original[m.end():]

def parse_params(args):
    p = {}
    files = []
    for a in args:
        if a.startswith('+'):
            body = a[1:]
            if '=' in body:
                k,v = body.split('=',1); p[k]=v
            else:
                p[body] = 'true'
        else:
            files.append(a)
    return p, files

def get_float(p, name, default):
    try: return float(p.get(name, default))
    except Exception: return default

def radius_from_params(p):
    if 'R' in p: return float(p['R'])
    if p.get('ellps') == 'sphere': return 6370997.0
    if 'a' in p: return float(p['a'])
    return A_WGS84

def merc_forward(lon, lat, p, web=False):
    a = radius_from_params(p)
    lon0 = math.radians(get_float(p,'lon_0',0.0))
    lam = math.radians(lon) - lon0
    phi = math.radians(lat)
    if abs(lat) >= 90: raise ValueError('Invalid latitude')
    x = a * lam
    if web or p.get('ellps') == 'sphere' or 'R' in p:
        y = a * math.log(math.tan(math.pi/4 + phi/2))
    else:
        e = E_WGS84
        y = a * (math.log(math.tan(math.pi/4 + phi/2)) - e * math.atanh(e * math.sin(phi)))
    return x, y

def merc_inverse(x, y, p, web=False):
    a = radius_from_params(p)
    lon0 = math.radians(get_float(p,'lon_0',0.0))
    lon = math.degrees(x/a + lon0)
    if web or p.get('ellps') == 'sphere' or 'R' in p:
        lat = math.degrees(2*math.atan(math.exp(y/a))-math.pi/2)
    else:
        t = math.exp(-y/a)
        phi = math.pi/2 - 2*math.atan(t)
        e = E_WGS84
        for _ in range(12):
            phi = math.pi/2 - 2*math.atan(t*((1-e*math.sin(phi))/(1+e*math.sin(phi)))**(e/2))
        lat = math.degrees(phi)
    return lon, lat

def eqc_forward(lon, lat, p):
    a = radius_from_params(p)
    lon0 = math.radians(get_float(p,'lon_0',0)); lat0=math.radians(get_float(p,'lat_0',0)); lat_ts=math.radians(get_float(p,'lat_ts',0))
    phi = math.radians(lat)
    if p.get('ellps') == 'sphere' or 'R' in p:
        y = a*(phi-lat0)
    else:
        y = meridional_arc(phi) - meridional_arc(lat0)
    return a*(math.radians(lon)-lon0)*math.cos(lat_ts), y

def eqc_inverse(x,y,p):
    a = radius_from_params(p); lon0=math.radians(get_float(p,'lon_0',0)); lat0=math.radians(get_float(p,'lat_0',0)); lat_ts=math.radians(get_float(p,'lat_ts',0))
    return math.degrees(lon0 + x/(a*math.cos(lat_ts))), math.degrees(lat0 + y/a)

def utm_params(p):
    zone = int(float(p.get('zone','31')))
    lon0 = (zone - 1)*6 - 180 + 3
    return zone, lon0, 0.9996, 500000.0, (10000000.0 if ('south' in p or p.get('hemisphere','').upper()=='S') else 0.0)

def meridional_arc(phi, a=A_WGS84, e2=E2_WGS84):
    e4=e2*e2; e6=e4*e2
    return a*((1-e2/4-3*e4/64-5*e6/256)*phi -(3*e2/8+3*e4/32+45*e6/1024)*math.sin(2*phi) +(15*e4/256+45*e6/1024)*math.sin(4*phi) -(35*e6/3072)*math.sin(6*phi))

def tmerc_forward(lon, lat, p):
    zone, zlon0, k0, x0, y0 = utm_params(p) if p.get('proj')=='utm' else (0, get_float(p,'lon_0',0), get_float(p,'k', get_float(p,'k_0',1)), get_float(p,'x_0',0), get_float(p,'y_0',0))
    phi=math.radians(lat); lam=math.radians(lon); lam0=math.radians(zlon0); e2=E2_WGS84; ep2=e2/(1-e2)
    N=A_WGS84/math.sqrt(1-e2*math.sin(phi)**2); T=math.tan(phi)**2; C=ep2*math.cos(phi)**2; A=(lam-lam0)*math.cos(phi)
    M=meridional_arc(phi)
    x=x0+k0*N*(A+(1-T+C)*A**3/6+(5-18*T+T*T+72*C-58*ep2)*A**5/120)
    y=y0+k0*(M+N*math.tan(phi)*(A*A/2+(5-T+9*C+4*C*C)*A**4/24+(61-58*T+T*T+600*C-330*ep2)*A**6/720))
    return x,y

def laea_forward(lon, lat, p):
    a=radius_from_params(p); lam=math.radians(lon); phi=math.radians(lat); lam0=math.radians(get_float(p,'lon_0',0)); phi0=math.radians(get_float(p,'lat_0',0))
    if not (p.get('ellps') == 'sphere' or 'R' in p):
        q = qsfn(math.sin(phi))
        qp = qsfn(1.0)
        beta = math.asin(max(-1.0, min(1.0, q / qp)))
        q0 = qsfn(math.sin(phi0))
        beta0 = math.asin(max(-1.0, min(1.0, q0 / qp)))
        rq = a * math.sqrt(0.5 * qp)
        m0 = math.cos(phi0) / math.sqrt(1 - E2_WGS84 * math.sin(phi0) ** 2)
        d = a * m0 / (rq * max(1e-15, math.cos(beta0)))
        denom = 1 + math.sin(beta0)*math.sin(beta)+math.cos(beta0)*math.cos(beta)*math.cos(lam-lam0)
        b = rq * math.sqrt(2 / denom) if denom > 0 else 0
        return b*d*math.cos(beta)*math.sin(lam-lam0), b/d*(math.cos(beta0)*math.sin(beta)-math.sin(beta0)*math.cos(beta)*math.cos(lam-lam0))
    denom=1+math.sin(phi0)*math.sin(phi)+math.cos(phi0)*math.cos(phi)*math.cos(lam-lam0)
    k=math.sqrt(2/denom) if denom>0 else 0
    return a*k*math.cos(phi)*math.sin(lam-lam0), a*k*(math.cos(phi0)*math.sin(phi)-math.sin(phi0)*math.cos(phi)*math.cos(lam-lam0))

def aea_forward(lon, lat, p):
    a=radius_from_params(p); phi=math.radians(lat); lam=math.radians(lon); phi1=math.radians(get_float(p,'lat_1',0)); phi2=math.radians(get_float(p,'lat_2',phi1)); phi0=math.radians(get_float(p,'lat_0',0)); lam0=math.radians(get_float(p,'lon_0',0))
    if not (p.get('ellps') == 'sphere' or 'R' in p):
        def m(phi):
            return math.cos(phi) / math.sqrt(1 - E2_WGS84 * math.sin(phi) ** 2)
        q = qsfn(math.sin(phi)); q0 = qsfn(math.sin(phi0)); q1 = qsfn(math.sin(phi1)); q2 = qsfn(math.sin(phi2))
        m1 = m(phi1); m2 = m(phi2)
        n = (m1*m1 - m2*m2) / (q2 - q1) if abs(phi1-phi2) > 1e-12 else math.sin(phi1)
        C = m1*m1 + n*q1
        rho = a * math.sqrt(max(0, C - n*q)) / n
        rho0 = a * math.sqrt(max(0, C - n*q0)) / n
        theta = n * (lam - lam0)
        return rho * math.sin(theta), rho0 - rho * math.cos(theta)
    n=(math.sin(phi1)+math.sin(phi2))/2 if abs(phi1-phi2)>1e-12 else math.sin(phi1)
    C=math.cos(phi1)**2+2*n*math.sin(phi1); rho=a*math.sqrt(max(0,C-2*n*math.sin(phi)))/n; rho0=a*math.sqrt(max(0,C-2*n*math.sin(phi0)))/n; theta=n*(lam-lam0)
    return rho*math.sin(theta), rho0-rho*math.cos(theta)

def qsfn(sinphi):
    e = E_WGS84
    con = e * sinphi
    return (1 - E2_WGS84) * (sinphi / (1 - con * con) - (0.5 / e) * math.log((1 - con) / (1 + con)))

def simple_forward(lon, lat, p):
    proj=p.get('proj','')
    if proj in ('merc',): return merc_forward(lon, lat, p, False)
    if proj in ('webmerc',): return merc_forward(lon, lat, p, True)
    if proj in ('eqc','longlat','lonlat'): return eqc_forward(lon, lat, p)
    if proj in ('utm','tmerc'): return tmerc_forward(lon, lat, p)
    if proj == 'laea': return laea_forward(lon, lat, p)
    if proj == 'aea': return aea_forward(lon, lat, p)
    if proj == 'geocent': return math.radians(lon), math.radians(lat)
    if proj in ('mill',):
        a=radius_from_params(p); return a*math.radians(lon-get_float(p,'lon_0',0)), a*1.25*math.log(math.tan(math.pi/4+0.4*math.radians(lat)))
    if proj in ('sinu',):
        a=radius_from_params(p); return a*math.radians(lon-get_float(p,'lon_0',0))*math.cos(math.radians(lat)), a*math.radians(lat)
    return merc_forward(lon, lat, p, False)

def simple_inverse(x,y,p):
    proj=p.get('proj','')
    if proj in ('merc',): return merc_inverse(x,y,p,False)
    if proj in ('webmerc',): return merc_inverse(x,y,p,True)
    if proj in ('eqc','longlat','lonlat'): return eqc_inverse(x,y,p)
    return merc_inverse(x,y,p,False)

def dms(v, pos, neg):
    hemi = pos if v >= 0 else neg
    av=abs(v); deg=int(math.floor(av+1e-12)); rem=(av-deg)*60; minute=int(math.floor(rem+1e-12)); sec=(rem-minute)*60
    sec = round(sec, 3)
    if sec >= 59.9995:
        sec = 0.0
        minute += 1
    if minute >= 60:
        minute = 0
        deg += 1
    if sec < 0.0005:
        return f"{deg}d{hemi}" if minute==0 else f"{deg}d{minute}'{hemi}"
    s = f"{sec:.3f}".rstrip('0').rstrip('.')
    return f"{deg}d{minute}'{s}\"{hemi}"

def fmt(v, fmtstr):
    if abs(v) < 0.0000005:
        v = 0.0
    try: return fmtstr % v
    except Exception: return f"{v:.2f}"

def process_line(line, p, opts):
    raw=line.rstrip('\n')
    if raw.startswith('#'):
        return raw
    try:
        a, rest = parse_coord_text(raw)
        b, suffix = parse_coord_text(rest)
        if opts['reverse_in']:
            a,b=b,a
        if opts['inverse']:
            lon,lat=simple_inverse(a,b,p)
            out1,out2=(lat,lon) if opts['reverse_out'] else (lon,lat)
            if opts['fmt']:
                res=f"{fmt(out1,opts['fmt'])}\t{fmt(out2,opts['fmt'])}"
            else:
                res=f"{dms(out1,'E','W')}\t{dms(out2,'N','S')}"
        else:
            x,y=simple_forward(a,b,p)
            x=x*opts['scale']+get_float(p,'x_0',0); y=y*opts['scale']+get_float(p,'y_0',0)
            out1,out2=(y,x) if opts['reverse_out'] else (x,y)
            res=f"{fmt(out1,opts['fmt'] or '%.2f')}\t{fmt(out2,opts['fmt'] or '%.2f')}"
        if suffix:
            res += suffix
        if opts['echo']:
            res = raw + '\t' + res
        return res
    except Exception as e:
        proj=p.get('proj','merc')
        if str(e): print(f"{proj}: {e}", file=sys.stderr)
        return ('*\t*' if not opts['echo'] else raw+'\t*\t*')

def apply_crs(arg, p):
    u=arg.upper()
    if u == 'EPSG:3857': p.update({'proj':'webmerc'}); return True
    if u == 'EPSG:3395' or u == 'ESRI:54004': p.update({'proj':'merc'}); return True
    if u.startswith('EPSG:326') and len(u)>=10:
        p.update({'proj':'utm','zone':str(int(u[-2:]))}); return True
    if u.startswith('EPSG:327') and len(u)>=10:
        p.update({'proj':'utm','zone':str(int(u[-2:])),'south':'true'}); return True
    if u == 'EPSG:4326': die('CRS must be projected',3)
    return False

def main(argv):
    if not argv:
        usage(); return 0
    opts={'inverse':False,'echo':False,'fmt':None,'scale':1.0,'reverse_in':False,'reverse_out':False}
    rest=[]; i=0
    while i < len(argv):
        a=argv[i]
        if a == '--help' or a.startswith('--'):
            die("invalid option: --",1)
        if a == '-I': opts['inverse']=True
        elif a == '-E': opts['echo']=True
        elif a == '-r': opts['reverse_in']=True
        elif a == '-s': opts['reverse_out']=True
        elif a == '-f': i+=1; opts['fmt']=argv[i] if i<len(argv) else '%.2f'
        elif a == '-m': i+=1; opts['scale']=float(argv[i]) if i<len(argv) else 1.0
        elif a == '-l' or a == '-lp':
            for n,d in PROJ_NAMES: print(f"{n} : {d}")
            return 0
        elif a == '-lP':
            for n,d in PROJ_NAMES: print(f"{n} : {d}\n\tSph&Ell")
            return 0
        elif a.startswith('-l='):
            name=a[3:]
            for n,d in PROJ_NAMES:
                if n == name:
                    print(f"{n:>9} : {d}\n\tCyl, Sph&Ell\n\tlat_ts="); return 0
            return 0
        elif a == '-le':
            print('\n'.join(ELLIPSOIDS)); return 0
        elif a == '-lu':
            print('\n'.join(UNITS)); return 0
        elif a.startswith('-') and a != '-':
            # Accept common flags that affect formatting only weakly; reject unknown help-like flags.
            if any(c in a[1:] for c in 'bdDeEfiIlmorsStTvVwW'):
                pass
            else:
                die(f"invalid option: {a}",1)
        else:
            rest.append(a)
        i+=1
    p, files = parse_params(rest)
    remaining=[]
    for f in files:
        if not apply_crs(f,p): remaining.append(f)
    files=remaining
    if 'init' in p and p['init'].lower() == 'epsg:4326':
        die("can't initialize operations that take non-angular input coordinates. Try cct.",3)
    if not p.get('proj'):
        p['proj']='merc'
    if p.get('proj') in ('longlat','lonlat') and not opts['inverse']:
        die("can't initialize operations that produce angular output coordinates",3)
    streams=[]
    if files:
        for fn in files:
            try: streams.append(open(fn))
            except OSError: die(f"can't open {fn}",2)
    else:
        streams=[sys.stdin]
    for st in streams:
        for line in st:
            print(process_line(line,p,opts))
    return 0

if __name__ == '__main__':
    sys.exit(main(sys.argv[1:]))
