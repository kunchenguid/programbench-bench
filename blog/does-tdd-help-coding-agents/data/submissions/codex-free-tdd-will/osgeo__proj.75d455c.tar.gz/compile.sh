#!/bin/bash
set -e
rm -f executable
cp proj_reimpl.py executable
chmod +x executable
