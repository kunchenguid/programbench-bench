#!/bin/bash
set -euo pipefail
gcc -std=c11 -O2 -Wall -Wextra -pedantic -o executable src/elfcat.c
chmod +x executable
