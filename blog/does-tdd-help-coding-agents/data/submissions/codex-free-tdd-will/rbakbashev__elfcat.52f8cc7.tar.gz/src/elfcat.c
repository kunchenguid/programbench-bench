#include <errno.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef struct {
    uint32_t type;
    uint64_t flags, addr, offset, size, link, info, addralign, entsize;
    uint32_t name_off;
    const char *name;
} Section;

typedef struct {
    uint32_t type, flags;
    uint64_t offset, vaddr, paddr, filesz, memsz, align;
} Program;

typedef struct {
    unsigned char *data;
    size_t size;
    int is64;
    int little;
    unsigned abi;
    uint16_t etype, machine, ehsize, phentsize, phnum, shentsize, shnum, shstrndx;
    uint32_t version, flags;
    uint64_t entry, phoff, shoff;
    Section *sections;
    Program *programs;
} Elf;

static void usage(void) {
    puts("Usage: elfcat <filename>");
    puts("Writes <filename>.html to CWD.");
}

static uint16_t rd16(const unsigned char *p, int le) {
    if (le) return (uint16_t)p[0] | ((uint16_t)p[1] << 8);
    return ((uint16_t)p[0] << 8) | (uint16_t)p[1];
}

static uint32_t rd32(const unsigned char *p, int le) {
    if (le) return (uint32_t)p[0] | ((uint32_t)p[1] << 8) | ((uint32_t)p[2] << 16) | ((uint32_t)p[3] << 24);
    return ((uint32_t)p[0] << 24) | ((uint32_t)p[1] << 16) | ((uint32_t)p[2] << 8) | (uint32_t)p[3];
}

static uint64_t rd64(const unsigned char *p, int le) {
    uint64_t a = rd32(p, le), b = rd32(p + 4, le);
    return le ? (a | (b << 32)) : ((a << 32) | b);
}

static int read_file(const char *path, unsigned char **out, size_t *out_size) {
    FILE *f = fopen(path, "rb");
    long n;
    if (!f) return -1;
    if (fseek(f, 0, SEEK_END) != 0 || (n = ftell(f)) < 0 || fseek(f, 0, SEEK_SET) != 0) {
        fclose(f);
        return -1;
    }
    *out = malloc((size_t)n ? (size_t)n : 1);
    if (!*out) {
        fclose(f);
        errno = ENOMEM;
        return -1;
    }
    if (fread(*out, 1, (size_t)n, f) != (size_t)n) {
        free(*out);
        fclose(f);
        return -1;
    }
    fclose(f);
    *out_size = (size_t)n;
    return 0;
}

static int in_bounds(size_t size, uint64_t off, uint64_t len) {
    return off <= size && len <= size - off;
}

static const char *type_name(uint16_t t) {
    switch (t) {
    case 0: return "No file type (NONE)";
    case 1: return "Relocatable file (REL)";
    case 2: return "Executable file (EXEC)";
    case 3: return "Shared object file (DYN)";
    case 4: return "Core file (CORE)";
    default: return "Unknown";
    }
}

static const char *machine_name(uint16_t m) {
    switch (m) {
    case 0: return "None";
    case 3: return "x86";
    case 8: return "MIPS";
    case 20: return "PowerPC";
    case 40: return "ARM";
    case 62: return "x86-64";
    case 183: return "AArch64";
    case 243: return "RISC-V";
    default: return "Unknown";
    }
}

static const char *abi_name(unsigned a) {
    switch (a) {
    case 0: return "SysV";
    case 1: return "HP-UX";
    case 2: return "NetBSD";
    case 3: return "Linux";
    case 6: return "Solaris";
    case 9: return "FreeBSD";
    default: return "Unknown";
    }
}

static const char *section_type(uint32_t t) {
    switch (t) {
    case 0: return "NULL";
    case 1: return "PROGBITS";
    case 2: return "SYMTAB";
    case 3: return "STRTAB";
    case 4: return "RELA";
    case 5: return "HASH";
    case 6: return "DYNAMIC";
    case 7: return "NOTE";
    case 8: return "NOBITS";
    case 9: return "REL";
    case 10: return "SHLIB";
    case 11: return "DYNSYM";
    case 14: return "INIT_ARRAY";
    case 15: return "FINI_ARRAY";
    case 0x6ffffff6: return "GNU_HASH";
    case 0x6fffffff: return "VERSYM";
    case 0x6ffffffe: return "VERNEED";
    default: return "UNKNOWN";
    }
}

static const char *program_type(uint32_t t) {
    switch (t) {
    case 0: return "NULL";
    case 1: return "LOAD";
    case 2: return "DYNAMIC";
    case 3: return "INTERP";
    case 4: return "NOTE";
    case 5: return "SHLIB";
    case 6: return "PHDR";
    case 7: return "TLS";
    case 0x6474e550: return "GNU_EH_FRAME";
    case 0x6474e551: return "GNU_STACK";
    case 0x6474e552: return "GNU_RELRO";
    case 0x6474e553: return "GNU_PROPERTY";
    default: return "UNKNOWN";
    }
}

static void flags3(char *buf, uint32_t f) {
    buf[0] = (f & 4) ? 'R' : ' ';
    buf[1] = (f & 2) ? 'W' : ' ';
    buf[2] = (f & 1) ? 'E' : ' ';
    buf[3] = 0;
}

static void sh_flags(char *buf, uint64_t f) {
    size_t n = 0;
    if (f & 1) buf[n++] = 'W';
    if (f & 2) buf[n++] = 'A';
    if (f & 4) buf[n++] = 'X';
    if (f & 0x10) buf[n++] = 'M';
    if (f & 0x20) buf[n++] = 'S';
    if (f & 0x40) buf[n++] = 'I';
    if (f & 0x400) buf[n++] = 'T';
    buf[n] = 0;
}

static int parse_elf(Elf *e, char *err, size_t errsz) {
    unsigned char *d = e->data;
    if (e->size < 16) {
        snprintf(err, errsz, "file is smaller than ELF header's e_ident");
        return -1;
    }
    if (d[0] != 0x7f || d[1] != 'E' || d[2] != 'L' || d[3] != 'F') {
        snprintf(err, errsz, "mismatched magic: not an ELF file");
        return -1;
    }
    e->is64 = d[4] == 2;
    if (d[4] != 1 && d[4] != 2) {
        snprintf(err, errsz, "unknown ELF class");
        return -1;
    }
    if (d[5] != 1 && d[5] != 2) {
        snprintf(err, errsz, "unknown ELF data encoding");
        return -1;
    }
    e->little = d[5] == 1;
    e->abi = d[7];
    size_t eh = e->is64 ? 64u : 52u;
    if (e->size < eh) {
        snprintf(err, errsz, "file is smaller than ELF header");
        return -1;
    }
    e->etype = rd16(d + 16, e->little);
    e->machine = rd16(d + 18, e->little);
    e->version = rd32(d + 20, e->little);
    if (e->is64) {
        e->entry = rd64(d + 24, e->little);
        e->phoff = rd64(d + 32, e->little);
        e->shoff = rd64(d + 40, e->little);
        e->flags = rd32(d + 48, e->little);
        e->ehsize = rd16(d + 52, e->little);
        e->phentsize = rd16(d + 54, e->little);
        e->phnum = rd16(d + 56, e->little);
        e->shentsize = rd16(d + 58, e->little);
        e->shnum = rd16(d + 60, e->little);
        e->shstrndx = rd16(d + 62, e->little);
    } else {
        e->entry = rd32(d + 24, e->little);
        e->phoff = rd32(d + 28, e->little);
        e->shoff = rd32(d + 32, e->little);
        e->flags = rd32(d + 36, e->little);
        e->ehsize = rd16(d + 40, e->little);
        e->phentsize = rd16(d + 42, e->little);
        e->phnum = rd16(d + 44, e->little);
        e->shentsize = rd16(d + 46, e->little);
        e->shnum = rd16(d + 48, e->little);
        e->shstrndx = rd16(d + 50, e->little);
    }
    if (e->phnum && !in_bounds(e->size, e->phoff, (uint64_t)e->phnum * e->phentsize)) {
        snprintf(err, errsz, "program header table extends past end of file");
        return -1;
    }
    if (e->shnum && !in_bounds(e->size, e->shoff, (uint64_t)e->shnum * e->shentsize)) {
        snprintf(err, errsz, "section header table extends past end of file");
        return -1;
    }
    e->programs = calloc(e->phnum ? e->phnum : 1, sizeof(Program));
    e->sections = calloc(e->shnum ? e->shnum : 1, sizeof(Section));
    if (!e->programs || !e->sections) {
        snprintf(err, errsz, "out of memory");
        return -1;
    }
    for (uint16_t i = 0; i < e->phnum; i++) {
        unsigned char *p = d + e->phoff + (uint64_t)i * e->phentsize;
        Program *ph = &e->programs[i];
        if (e->is64) {
            ph->type = rd32(p, e->little);
            ph->flags = rd32(p + 4, e->little);
            ph->offset = rd64(p + 8, e->little);
            ph->vaddr = rd64(p + 16, e->little);
            ph->paddr = rd64(p + 24, e->little);
            ph->filesz = rd64(p + 32, e->little);
            ph->memsz = rd64(p + 40, e->little);
            ph->align = rd64(p + 48, e->little);
        } else {
            ph->type = rd32(p, e->little);
            ph->offset = rd32(p + 4, e->little);
            ph->vaddr = rd32(p + 8, e->little);
            ph->paddr = rd32(p + 12, e->little);
            ph->filesz = rd32(p + 16, e->little);
            ph->memsz = rd32(p + 20, e->little);
            ph->flags = rd32(p + 24, e->little);
            ph->align = rd32(p + 28, e->little);
        }
    }
    for (uint16_t i = 0; i < e->shnum; i++) {
        unsigned char *p = d + e->shoff + (uint64_t)i * e->shentsize;
        Section *s = &e->sections[i];
        s->name_off = rd32(p, e->little);
        s->type = rd32(p + 4, e->little);
        if (e->is64) {
            s->flags = rd64(p + 8, e->little);
            s->addr = rd64(p + 16, e->little);
            s->offset = rd64(p + 24, e->little);
            s->size = rd64(p + 32, e->little);
            s->link = rd32(p + 40, e->little);
            s->info = rd32(p + 44, e->little);
            s->addralign = rd64(p + 48, e->little);
            s->entsize = rd64(p + 56, e->little);
        } else {
            s->flags = rd32(p + 8, e->little);
            s->addr = rd32(p + 12, e->little);
            s->offset = rd32(p + 16, e->little);
            s->size = rd32(p + 20, e->little);
            s->link = rd32(p + 24, e->little);
            s->info = rd32(p + 28, e->little);
            s->addralign = rd32(p + 32, e->little);
            s->entsize = rd32(p + 36, e->little);
        }
    }
    if (e->shstrndx < e->shnum) {
        Section *str = &e->sections[e->shstrndx];
        if (in_bounds(e->size, str->offset, str->size)) {
            const char *base = (const char *)d + str->offset;
            for (uint16_t i = 0; i < e->shnum; i++) {
                if (e->sections[i].name_off < str->size) e->sections[i].name = base + e->sections[i].name_off;
            }
        }
    }
    return 0;
}

static void html_text(FILE *f, const char *s) {
    for (; *s; s++) {
        switch (*s) {
        case '&': fputs("&amp;", f); break;
        case '<': fputs("&lt;", f); break;
        case '>': fputs("&gt;", f); break;
        case '"': fputs("&quot;", f); break;
        default: fputc(*s, f); break;
        }
    }
}

static const char *base_name(const char *p) {
    const char *s = strrchr(p, '/');
    return s ? s + 1 : p;
}

static char *out_name(const char *path) {
    const char *b = base_name(path);
    size_t n = strlen(b) + 6;
    char *o = malloc(n);
    if (o) snprintf(o, n, "%s.html", b);
    return o;
}

static void human_size(char *buf, size_t cap, size_t n) {
    if (n >= 1024) snprintf(buf, cap, "%.1f KiB (%zu B)", (double)n / 1024.0, n);
    else snprintf(buf, cap, "%zu B", n);
}

static void hexdump(FILE *f, const unsigned char *d, size_t n) {
    fputs("<h2>Hexdump</h2>\n<div class='dump'><pre>", f);
    for (size_t off = 0; off < n; off += 16) {
        fprintf(f, "%08zx  ", off);
        for (size_t j = 0; j < 16; j++) {
            if (off + j < n) fprintf(f, "%02x ", d[off + j]);
            else fputs("   ", f);
        }
        fputs(" |", f);
        for (size_t j = 0; j < 16 && off + j < n; j++) {
            unsigned char c = d[off + j];
            fputc((c >= 32 && c < 127) ? c : '.', f);
        }
        fputs("|\n", f);
    }
    fputs("</pre></div>\n", f);
}

static int write_html(const char *input, const char *out, const Elf *e) {
    FILE *f = fopen(out, "w");
    char sizebuf[64];
    if (!f) return -1;
    human_size(sizebuf, sizeof(sizebuf), e->size);
    fputs("<!doctype html>\n<html>\n  <head>\n    <meta charset='utf-8'>\n", f);
    fputs("    <meta name='viewport' content='width=900, initial-scale=1'>\n    <title>", f);
    html_text(f, base_name(input));
    fputs("</title>\n    <style>\nhtml{font-family:monospace} table{border-collapse:collapse;margin:1em 0}td,th{border:1px solid #bbb;padding:.25em .5em;text-align:left}.number{text-decoration:underline dotted #888}.dump{white-space:pre}.ident{background:#e99}.ehdr{background:#99e}.phdr{background:#eb9}.shdr{background:#9be}.segment{background:#be9}.section{background:#9e9}#credits{color:#888;float:right}\n    </style>\n  </head>\n  <body>\n", f);
    fputs("    <a id='credits' href='https://github.com/rbakbashev/elfcat'>generated with elfcat 0.1.10</a>\n", f);
    fputs("    <h1>ELF report: ", f);
    html_text(f, base_name(input));
    fputs("</h1>\n    <p>Legend: <span class='ident'>ELF Identification</span> <span class='ehdr'>ELF Header</span> <span class='phdr'>Program Header</span> <span class='shdr'>Section Header</span> <span class='segment'>Segment</span> <span class='section'>Section</span></p>\n", f);
    fputs("    <table>\n", f);
    fputs("      <tr class='fileinfo_file_name'> <td>File name:</td> <td>", f);
    html_text(f, input);
    fputs("</td> </tr>\n", f);
    fprintf(f, "      <tr class='fileinfo_file_size'> <td>File size:</td> <td>%s</td> </tr>\n", sizebuf);
    fprintf(f, "      <tr class='fileinfo_class'> <td>Object class:</td> <td>%s-bit</td> </tr>\n", e->is64 ? "64" : "32");
    fprintf(f, "      <tr class='fileinfo_data'> <td>Data encoding:</td> <td>%s endian</td> </tr>\n", e->little ? "Little" : "Big");
    fprintf(f, "      <tr class='fileinfo_abi'> <td>ABI:</td> <td>%s</td> </tr>\n", abi_name(e->abi));
    fprintf(f, "      <tr class='fileinfo_e_type'> <td>Type:</td> <td>%s</td> </tr>\n", type_name(e->etype));
    fprintf(f, "      <tr class='fileinfo_e_machine'> <td>Architecture:</td> <td>%s</td> </tr>\n", machine_name(e->machine));
    fprintf(f, "      <tr class='fileinfo_e_entry'> <td>Entrypoint:</td> <td><span class='number' title='%llu'>0x%llx</span></td> </tr>\n", (unsigned long long)e->entry, (unsigned long long)e->entry);
    fprintf(f, "      <tr class='fileinfo_ph'> <td>Program headers:</td> <td><span title='0x%x' class='number fileinfo_e_phnum'>%u</span> * <span title='0x%x' class='number fileinfo_e_phentsize'>%u</span> @ <span title='0x%llx' class='number fileinfo_e_phoff'>%llu</span></td> </tr>\n", e->phnum, e->phnum, e->phentsize, e->phentsize, (unsigned long long)e->phoff, (unsigned long long)e->phoff);
    fprintf(f, "      <tr class='fileinfo_sh'> <td>Section headers:</td> <td><span title='0x%x' class='number fileinfo_e_shnum'>%u</span> * <span title='0x%x' class='number fileinfo_e_shentsize'>%u</span> @ <span title='0x%llx' class='number fileinfo_e_shoff'>%llu</span></td> </tr>\n", e->shnum, e->shnum, e->shentsize, e->shentsize, (unsigned long long)e->shoff, (unsigned long long)e->shoff);
    fputs("    </table>\n", f);

    fputs("<h2>ELF Header</h2>\n<table><tr><th>Field</th><th>Value</th></tr>\n", f);
    fprintf(f, "<tr><td>Magic</td><td>%02x %02x %02x %02x</td></tr>\n", e->data[0], e->data[1], e->data[2], e->data[3]);
    fprintf(f, "<tr><td>Class</td><td>ELF%s</td></tr>\n", e->is64 ? "64" : "32");
    fprintf(f, "<tr><td>Version</td><td>%u</td></tr>\n", e->version);
    fprintf(f, "<tr><td>Flags</td><td>0x%x</td></tr>\n", e->flags);
    fputs("</table>\n", f);

    fputs("<h2>Program Headers</h2>\n<table><tr><th>#</th><th>Type</th><th>Offset</th><th>VirtAddr</th><th>PhysAddr</th><th>FileSiz</th><th>MemSiz</th><th>Flags</th><th>Align</th></tr>\n", f);
    for (uint16_t i = 0; i < e->phnum; i++) {
        char fl[4];
        const Program *p = &e->programs[i];
        flags3(fl, p->flags);
        fprintf(f, "<tr class='bin_phdr%u phdr'><td>%u</td><td>%s</td><td>0x%llx</td><td>0x%llx</td><td>0x%llx</td><td>0x%llx</td><td>0x%llx</td><td>%s</td><td>0x%llx</td></tr>\n",
                i, i, program_type(p->type), (unsigned long long)p->offset, (unsigned long long)p->vaddr,
                (unsigned long long)p->paddr, (unsigned long long)p->filesz, (unsigned long long)p->memsz,
                fl, (unsigned long long)p->align);
    }
    fputs("</table>\n", f);

    fputs("<h2>Section Headers</h2>\n<table><tr><th>#</th><th>Name</th><th>Type</th><th>Address</th><th>Offset</th><th>Size</th><th>EntSize</th><th>Flags</th><th>Link</th><th>Info</th><th>Align</th></tr>\n", f);
    for (uint16_t i = 0; i < e->shnum; i++) {
        char fl[16];
        const Section *s = &e->sections[i];
        sh_flags(fl, s->flags);
        fprintf(f, "<tr class='bin_shdr%u shdr'><td>%u</td><td>", i, i);
        html_text(f, s->name ? s->name : "");
        fprintf(f, "</td><td>%s</td><td>0x%llx</td><td>0x%llx</td><td>0x%llx</td><td>0x%llx</td><td>%s</td><td>%llu</td><td>%llu</td><td>%llu</td></tr>\n",
                section_type(s->type), (unsigned long long)s->addr, (unsigned long long)s->offset,
                (unsigned long long)s->size, (unsigned long long)s->entsize, fl,
                (unsigned long long)s->link, (unsigned long long)s->info, (unsigned long long)s->addralign);
    }
    fputs("</table>\n", f);

    hexdump(f, e->data, e->size);
    fputs("  </body>\n</html>\n", f);
    return fclose(f);
}

int main(int argc, char **argv) {
    Elf e;
    char err[160];
    char *out;
    memset(&e, 0, sizeof(e));
    if (argc == 2 && (strcmp(argv[1], "--help") == 0 || strcmp(argv[1], "-h") == 0)) {
        usage();
        return 0;
    }
    if (argc == 2 && strcmp(argv[1], "--version") == 0) {
        puts("elfcat 0.1.10");
        return 0;
    }
    if (argc != 2) {
        usage();
        return 1;
    }
    if (read_file(argv[1], &e.data, &e.size) != 0) {
        fprintf(stderr, "Failed to read file \"%s\": %s (os error %d)\n", argv[1], strerror(errno), errno);
        return 1;
    }
    if (parse_elf(&e, err, sizeof(err)) != 0) {
        fprintf(stderr, "Failed to parse ELF: %s\n", err);
        free(e.data);
        free(e.sections);
        free(e.programs);
        return 1;
    }
    out = out_name(argv[1]);
    if (!out || write_html(argv[1], out, &e) != 0) {
        fprintf(stderr, "Failed to write file \"%s\": %s (os error %d)\n", out ? out : "(null)", strerror(errno), errno);
        free(out);
        free(e.data);
        free(e.sections);
        free(e.programs);
        return 1;
    }
    free(out);
    free(e.data);
    free(e.sections);
    free(e.programs);
    return 0;
}
