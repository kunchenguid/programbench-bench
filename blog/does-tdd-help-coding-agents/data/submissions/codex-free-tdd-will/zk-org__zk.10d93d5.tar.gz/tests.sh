#!/bin/bash
set -euo pipefail

ROOT=$(cd "$(dirname "$0")" && pwd)
TMP=$(mktemp -d)
trap 'rm -rf "$TMP"' EXIT

cd "$ROOT"
rm -f ./executable
./compile.sh >/tmp/zk_compile.log
test -x ./executable

cd "$TMP"
"$ROOT/executable" --help >help.out 2>help.err
grep -F "Usage: zk <command>" help.out >/dev/null
grep -F "Commands:" help.out >/dev/null
test ! -s help.err

"$ROOT/executable" --no-input init nb >init.out 2>init.err
test -f nb/.zk/config.toml
test -f nb/.zk/templates/default.md
grep -F "# zk configuration file" nb/.zk/config.toml >/dev/null
grep -F "{{content}}" nb/.zk/templates/default.md >/dev/null
test ! -s init.out

cd nb
"$ROOT/executable" --no-input new --id abc123 --title "Alpha Note" --print-path >new.out 2>new.err
grep -F "abc123.md" new.out >/dev/null
test -f abc123.md
grep -F "# Alpha Note" abc123.md >/dev/null
test ! -s new.err

cat > beta.md <<'NOTE'
---
title: Beta Custom
tags: [work, yaml-tag]
---

Body has #inline and a [[Alpha Note]] link.
NOTE

"$ROOT/executable" list --format json --quiet >list.json 2>list.err
grep -F '"path": "abc123.md"' list.json >/dev/null
grep -F '"title": "Alpha Note"' list.json >/dev/null
grep -F '"title": "Beta Custom"' list.json >/dev/null
test ! -s list.err

"$ROOT/executable" list --tag inline --format oneline --quiet >tagged.out
grep -F "beta.md" tagged.out >/dev/null

"$ROOT/executable" tag list --format json --quiet >tags.json
grep -F '"name": "inline"' tags.json >/dev/null
grep -F '"name": "work"' tags.json >/dev/null

"$ROOT/executable" graph --format json --quiet >graph.json
grep -F '"nodes"' graph.json >/dev/null
grep -F '"links"' graph.json >/dev/null
grep -F '"source": "beta.md"' graph.json >/dev/null

"$ROOT/executable" index --quiet >index.out 2>index.err
test ! -s index.out
test ! -s index.err

"$ROOT/executable" new --help | grep -F "Usage: zk new" >/dev/null
"$ROOT/executable" list --help | grep -F "Usage: zk list" >/dev/null
"$ROOT/executable" tag list --help | grep -F "Usage: zk tag list" >/dev/null
