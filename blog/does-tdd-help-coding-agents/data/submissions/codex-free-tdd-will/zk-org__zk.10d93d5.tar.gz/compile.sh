#!/bin/bash
set -e
cp src/zk.py executable
chmod +x executable
