#!/usr/bin/env python3
import sys
from pathlib import Path
from datetime import datetime
import os
import re
import json


DEFAULT_CONFIG = """# zk configuration file
#
# Uncomment the properties you want to customize.

[note]
template = "default.md"

[format.markdown]
link-format = "wiki"
hashtags = true
colon-tags = false
multiword-tags = false
"""

DEFAULT_TEMPLATE = """# {{title}}

{{content}}
"""


TOP_HELP = """Usage: zk <command>

Commands:

NOTEBOOK
  A notebook is a directory containing a collection of notes

  init     Create a new notebook in the given directory.
  index    Index the notes to be searchable.

NOTES
  Edit or browse your notes

  new      Create a new note in the given notebook directory.
  list     List notes matching the given criteria.
  graph    Produce a graph of the notes matching the given criteria.
  edit     Edit notes matching the given criteria.
  tag      Manage the note tags.

Flags:
  -h, --help                 Show context-sensitive help.
      --notebook-dir=PATH    Turn off notebook auto-discovery and set manually
                             the notebook where commands are run.
  -W, --working-dir=PATH     Run as if zk was started in <PATH> instead of the
                             current working directory.
      --no-input             Never prompt or ask for confirmation.

Run "zk <command> --help" for more information on a command.
"""

HELP = {
    "init": """Usage: zk init [<directory>]

Create a new notebook in the given directory.
""",
    "index": """Usage: zk index

Index the notes to be searchable.
""",
    "new": """Usage: zk new [<directory>]

Create a new note in the given notebook directory.

Flags:
  -i, --interactive            Read contents from standard input.
  -t, --title=TITLE            Title of the new note.
  -p, --print-path             Print the path of the created note instead of editing it.
  -n, --dry-run                Don't actually create the note.
      --id=ID                  Skip id generation and use provided value.
""",
    "list": """Usage: zk list [<path> ...]

List notes matching the given criteria.
""",
    "graph": """Usage: zk graph --format=STRING [<path> ...]

Produce a graph of the notes matching the given criteria.
""",
    "edit": """Usage: zk edit [<path> ...]

Edit notes matching the given criteria.
""",
    "tag": """Usage: zk tag <command>

Manage the note tags.

Commands:
  tag list    List all the note tags.
""",
    "tag list": """Usage: zk tag list

List all the note tags.
""",
}


def parse_global(args):
    opts = {"working_dir": None, "notebook_dir": None, "no_input": False}
    rest = []
    i = 0
    while i < len(args):
        a = args[i]
        if a == "--no-input":
            opts["no_input"] = True
        elif a == "-W" and i + 1 < len(args):
            i += 1
            opts["working_dir"] = args[i]
        elif a.startswith("--working-dir="):
            opts["working_dir"] = a.split("=", 1)[1]
        elif a == "--notebook-dir" and i + 1 < len(args):
            i += 1
            opts["notebook_dir"] = args[i]
        elif a.startswith("--notebook-dir="):
            opts["notebook_dir"] = a.split("=", 1)[1]
        else:
            rest.append(a)
        i += 1
    return opts, rest


def cmd_init(args):
    directory = Path(args[0]) if args else Path(".")
    zk = directory / ".zk"
    (zk / "templates").mkdir(parents=True, exist_ok=True)
    config = zk / "config.toml"
    template = zk / "templates" / "default.md"
    if not config.exists():
        config.write_text(DEFAULT_CONFIG)
    if not template.exists():
        template.write_text(DEFAULT_TEMPLATE)
    return 0


def find_notebook(explicit=None):
    if explicit:
        p = Path(explicit).resolve()
        if (p / ".zk").is_dir():
            return p
        raise RuntimeError(f"failed to open notebook: no notebook found in {p} or a parent directory")
    p = Path.cwd().resolve()
    for cur in [p, *p.parents]:
        if (cur / ".zk").is_dir():
            return cur
    raise RuntimeError(f"failed to open notebook: no notebook found in {p} or a parent directory")


def parse_options(args, specs):
    key_names = {
        "-p": "print_path",
        "-n": "dry_run",
        "-i": "interactive",
        "-f": "format",
        "-d": "delimiter",
        "-q": "quiet",
        "-0": "delimiter0",
    }
    opts = {}
    rest = []
    i = 0
    while i < len(args):
        a = args[i]
        matched = False
        for name, takes_value in specs.items():
            if a == name:
                key = key_names.get(name, name.lstrip("-").replace("-", "_"))
                if name == "-t":
                    key = "tag" if "--tag" in specs else "title"
                elif name == "-n":
                    key = "limit" if "--limit" in specs else "dry_run"
                if takes_value:
                    i += 1
                    opts[key] = args[i] if i < len(args) else ""
                else:
                    opts[key] = True
                matched = True
                break
            if takes_value and a.startswith(name + "="):
                key = key_names.get(name, name.lstrip("-").replace("-", "_"))
                if name == "-t":
                    key = "tag" if "--tag" in specs else "title"
                elif name == "-n":
                    key = "limit" if "--limit" in specs else "dry_run"
                opts[key] = a.split("=", 1)[1]
                matched = True
                break
        if not matched:
            rest.append(a)
        i += 1
    return opts, rest


def slugify(text):
    slug = re.sub(r"[^A-Za-z0-9]+", "-", text.strip().lower()).strip("-")
    return slug or "untitled"


def cmd_new(global_opts, args):
    specs = {
        "--id": True, "--title": True, "-t": True, "--print-path": False,
        "-p": False, "--dry-run": False, "-n": False, "--date": True,
        "--template": True, "--extra": True, "--interactive": False, "-i": False,
    }
    opts, rest = parse_options(args, specs)
    nb = find_notebook(global_opts.get("notebook_dir"))
    target_dir = nb / (rest[0] if rest else ".")
    title = opts.get("title") or opts.get("t") or "Untitled"
    note_id = opts.get("id") or datetime.now().strftime("%Y%m%d%H%M")
    filename = f"{note_id}.md" if opts.get("id") else f"{note_id}-{slugify(title)}.md"
    path = target_dir / filename
    content = sys.stdin.read() if opts.get("interactive") or opts.get("i") else ""
    rendered = DEFAULT_TEMPLATE.replace("{{title}}", title).replace("{{content}}", content)
    if opts.get("dry_run") or opts.get("n"):
        print(rendered, end="")
        print(str(path.relative_to(nb)), file=sys.stderr)
        return 0
    target_dir.mkdir(parents=True, exist_ok=True)
    path.write_text(rendered)
    if opts.get("print_path") or opts.get("p"):
        print(str(path.relative_to(nb)))
    return 0


def parse_front_matter(text):
    meta = {}
    if not text.startswith("---\n"):
        return meta, text
    end = text.find("\n---", 4)
    if end == -1:
        return meta, text
    raw = text[4:end].strip().splitlines()
    body = text[end + 4:].lstrip("\n")
    for line in raw:
        if ":" not in line:
            continue
        key, val = line.split(":", 1)
        key = key.strip()
        val = val.strip().strip('"').strip("'")
        if val.startswith("[") and val.endswith("]"):
            meta[key] = [v.strip().strip('"').strip("'") for v in val[1:-1].split(",") if v.strip()]
        else:
            meta[key] = val
    return meta, body


def note_title(path, meta, body):
    if meta.get("title"):
        return str(meta["title"])
    for line in body.splitlines():
        m = re.match(r"\s*#\s+(.+?)\s*$", line)
        if m:
            return m.group(1)
    return path.stem


def extract_tags(meta, body):
    tags = set()
    value = meta.get("tags")
    if isinstance(value, list):
        tags.update(value)
    elif isinstance(value, str) and value:
        tags.add(value)
    for m in re.finditer(r"(?<!\w)#([A-Za-z0-9_/-]+)", body):
        tags.add(m.group(1))
    return sorted(tags)


def extract_links(body):
    links = []
    links.extend(m.group(1).strip() for m in re.finditer(r"\[\[([^\]]+)\]\]", body))
    links.extend(m.group(2).strip() for m in re.finditer(r"\[([^\]]+)\]\(([^)]+)\)", body))
    return [l for l in links if l]


def load_notes(nb):
    notes = []
    for path in sorted(nb.rglob("*.md")):
        if ".zk" in path.relative_to(nb).parts:
            continue
        text = path.read_text(errors="replace")
        meta, body = parse_front_matter(text)
        rel = path.relative_to(nb).as_posix()
        notes.append({
            "path": rel,
            "title": note_title(path, meta, body),
            "tags": extract_tags(meta, body),
            "links": extract_links(body),
            "body": body,
        })
    return notes


def apply_note_filters(notes, args):
    specs = {
        "--format": True, "-f": True, "--tag": True, "-t": True, "--match": True,
        "-m": True, "--limit": True, "-n": True, "--quiet": False, "-q": False,
        "--delimiter": True, "-d": True, "--delimiter0": False, "-0": False,
        "--sort": True, "-s": True,
    }
    opts, paths = parse_options(args, specs)
    if paths:
        prefixes = [p.rstrip("/") for p in paths]
        notes = [n for n in notes if any(n["path"] == p or n["path"].startswith(p + "/") for p in prefixes)]
    tag = opts.get("tag")
    if tag:
        wanted = {t.strip() for t in tag.split(",") if t.strip()}
        notes = [n for n in notes if wanted.issubset(set(n["tags"]))]
    match = opts.get("match")
    if match:
        terms = [t.lower() for t in match.split(",") if t]
        notes = [n for n in notes if all(t in (n["title"] + "\n" + n["body"]).lower() for t in terms)]
    sort = opts.get("sort")
    if sort:
        reverse = sort.startswith("-")
        key = sort.lstrip("-")
        if key in ("title", "path"):
            notes = sorted(notes, key=lambda n: n[key].lower(), reverse=reverse)
    limit = opts.get("limit")
    if limit:
        try:
            notes = notes[:int(limit)]
        except ValueError:
            pass
    return opts, notes


def format_note_line(note, fmt):
    if fmt in ("short", "medium", "long", "full"):
        return f"{note['path']} {note['title']}"
    return f"{note['path']} {note['title']}"


def cmd_list(global_opts, args):
    nb = find_notebook(global_opts.get("notebook_dir"))
    opts, notes = apply_note_filters(load_notes(nb), args)
    fmt = opts.get("format") or "oneline"
    if fmt == "json":
        serial = [{k: n[k] for k in ("path", "title", "tags", "links")} for n in notes]
        print(json.dumps(serial, indent=2))
    elif fmt == "jsonl":
        for n in notes:
            print(json.dumps({k: n[k] for k in ("path", "title", "tags", "links")}))
    else:
        delimiter = "\0" if opts.get("delimiter0") else opts.get("delimiter", "\n")
        out = delimiter.join(format_note_line(n, fmt) for n in notes)
        if out:
            print(out, end="" if delimiter == "\0" else "\n")
    if not opts.get("quiet"):
        print(f"{len(notes)} notes", file=sys.stderr)
    return 0


def cmd_tag_list(global_opts, args):
    specs = {
        "--format": True, "-f": True, "--quiet": False, "-q": False,
        "--delimiter": True, "-d": True, "--delimiter0": False, "-0": False,
        "--sort": True, "-s": True,
    }
    opts, _ = parse_options(args, specs)
    nb = find_notebook(global_opts.get("notebook_dir"))
    counts = {}
    for n in load_notes(nb):
        for t in n["tags"]:
            counts[t] = counts.get(t, 0) + 1
    tags = [{"name": k, "count": counts[k]} for k in sorted(counts)]
    fmt = opts.get("format") or "name"
    if fmt == "json":
        print(json.dumps(tags, indent=2))
    elif fmt == "jsonl":
        for t in tags:
            print(json.dumps(t))
    else:
        delimiter = "\0" if opts.get("delimiter0") else opts.get("delimiter", "\n")
        lines = [f"{t['name']} {t['count']}" if fmt == "full" else t["name"] for t in tags]
        out = delimiter.join(lines)
        if out:
            print(out, end="" if delimiter == "\0" else "\n")
    if not opts.get("quiet"):
        print(f"{len(tags)} tags", file=sys.stderr)
    return 0


def cmd_graph(global_opts, args):
    nb = find_notebook(global_opts.get("notebook_dir"))
    opts, notes = apply_note_filters(load_notes(nb), args)
    by_title = {n["title"]: n["path"] for n in notes}
    by_path = {n["path"]: n["path"] for n in notes}
    links = []
    for n in notes:
        for target in n["links"]:
            dest = by_title.get(target) or by_path.get(target) or by_path.get(target.lstrip("./"))
            if dest:
                links.append({"source": n["path"], "target": dest})
    print(json.dumps({
        "nodes": [{"id": n["path"], "title": n["title"]} for n in notes],
        "links": links,
    }, indent=2))
    if not opts.get("quiet"):
        print(f"{len(notes)} notes", file=sys.stderr)
    return 0


def cmd_index(global_opts, args):
    opts, _ = parse_options(args, {"--quiet": False, "-q": False, "--force": False, "-f": False, "--verbose": False, "-v": False})
    find_notebook(global_opts.get("notebook_dir"))
    if not opts.get("quiet"):
        print("0 notes indexed")
    return 0


def main(argv):
    opts, args = parse_global(argv[1:])
    if opts["working_dir"]:
        try:
            Path(opts["working_dir"]).mkdir(parents=True, exist_ok=True)
            import os
            os.chdir(opts["working_dir"])
        except OSError as e:
            print(f"zk: error: {e}", file=sys.stderr)
            return 1
    if not args or args[0] in ("-h", "--help"):
        print(TOP_HELP, end="")
        return 0
    cmd, rest = args[0], args[1:]
    if rest and rest[0] in ("-h", "--help"):
        key = "tag list" if cmd == "tag" and len(rest) > 1 and rest[1] == "list" else cmd
        print(HELP.get(key, TOP_HELP), end="" if HELP.get(key, "").endswith("\n") else "\n")
        return 0
    if cmd == "tag" and rest[:2] == ["list", "--help"]:
        print(HELP["tag list"], end="")
        return 0
    if cmd == "init":
        return cmd_init(rest)
    try:
        if cmd == "new":
            return cmd_new(opts, rest)
        if cmd == "list":
            return cmd_list(opts, rest)
        if cmd == "graph":
            return cmd_graph(opts, rest)
        if cmd == "index":
            return cmd_index(opts, rest)
        if cmd == "tag" and rest[:1] == ["list"]:
            return cmd_tag_list(opts, rest[1:])
    except RuntimeError as e:
        print(f"zk: error: {e}", file=sys.stderr)
        return 1
    print(f"zk: error: unknown command {cmd!r}", file=sys.stderr)
    return 1


if __name__ == "__main__":
    raise SystemExit(main(sys.argv))
