#!/bin/bash
set -e
cp loop.py executable
chmod +x executable
