#!/usr/bin/env python3
import datetime as _dt
import os
import re
import shlex
import subprocess
import sys
import time


HELP = """loop 0.6.1
Rich Jones <miserlou@gmail.com>
UNIX's missing `loop` command

USAGE:
    executable [FLAGS] [OPTIONS] [input]...

FLAGS:
    -D, --error-duration    Exit with timeout error code on duration
    -h, --help              Prints help information
    -l, --only-last         Only print the output of the last execution of the command
    -i, --stdin             Read from standard input
        --summary           Provide a summary
    -C, --until-changes     Keep going until the output changes
    -f, --until-fail        Keep going until the command exit status is non-zero
    -S, --until-same        Keep going until the output changes
    -s, --until-success     Keep going until the command exit status is zero
    -V, --version           Prints version information

OPTIONS:
    -b, --count-by <count_by>                Amount to increment the counter by [default: 1]
    -e, --every <every>                      How often to iterate. ex., 5s, 1h1m1s1ms1us [default: 1us]
        --for <ffor>                         A comma-separated list of values, placed into 4ITEM. ex., red,green,blue
    -d, --for-duration <for_duration>        Keep going until the duration has elapsed (example 1m30s)
    -n, --num <num>                          Number of iterations to execute
    -o, --offset <offset>                    Amount to offset the initial counter by [default: 0]
    -c, --until-contains <until_contains>    Keep going until the output contains this string
    -r, --until-error <until_error>          Keep going until the command exit status is the value given
    -m, --until-match <until_match>          Keep going until the output matches this regular expression
    -t, --until-time <until_time>            Keep going until a future time, ex. "2018-04-20 04:20:00" (Times in UTC.)

ARGS:
    <input>...    The command to be looped
"""


def parse_args(argv):
    opts = {
        "num": None,
        "offset": 0,
        "count_by": 1,
        "for_values": None,
        "only_last": False,
        "summary": False,
        "stdin": False,
        "until_success": False,
        "until_fail": False,
        "until_error": None,
        "until_contains": None,
        "until_match": None,
        "until_changes": False,
        "until_same": False,
        "every": 0.000001,
        "for_duration": None,
        "until_time": None,
        "error_duration": False,
    }
    command = []
    i = 0
    while i < len(argv):
        arg = argv[i]
        if arg == "--":
            command = argv[i + 1 :]
            break
        if arg in ("-n", "--num"):
            i += 1
            opts["num"] = parse_number(argv[i], "--num <num>")
        elif arg in ("-o", "--offset"):
            i += 1
            opts["offset"] = parse_number(argv[i], "--offset <offset>")
        elif arg in ("-b", "--count-by"):
            i += 1
            opts["count_by"] = parse_number(argv[i], "--count-by <count_by>")
        elif arg == "--for":
            i += 1
            opts["for_values"] = argv[i].split(",")
        elif arg in ("-l", "--only-last"):
            opts["only_last"] = True
        elif arg == "--summary":
            opts["summary"] = True
        elif arg in ("-i", "--stdin"):
            opts["stdin"] = True
        elif arg in ("-s", "--until-success"):
            opts["until_success"] = True
        elif arg in ("-f", "--until-fail"):
            opts["until_fail"] = True
        elif arg in ("-C", "--until-changes"):
            opts["until_changes"] = True
        elif arg in ("-S", "--until-same"):
            opts["until_same"] = True
        elif arg in ("-D", "--error-duration"):
            opts["error_duration"] = True
        elif arg in ("-c", "--until-contains"):
            i += 1
            opts["until_contains"] = argv[i]
        elif arg in ("-m", "--until-match"):
            i += 1
            opts["until_match"] = argv[i]
        elif arg in ("-r", "--until-error"):
            i += 1
            opts["until_error"] = int(argv[i])
        elif arg in ("-e", "--every"):
            i += 1
            opts["every"] = parse_duration(argv[i])
        elif arg in ("-d", "--for-duration"):
            i += 1
            opts["for_duration"] = parse_duration(argv[i])
        elif arg in ("-t", "--until-time"):
            i += 1
            opts["until_time"] = parse_time(argv[i])
        else:
            command = argv[i:]
            break
        i += 1
    return opts, command


def parse_number(text, label):
    try:
        value = float(text)
    except ValueError as exc:
        raise ValueError(f"Invalid value for '{label}': invalid float literal") from exc
    return int(value)


def parse_duration(text):
    pos = 0
    total = 0.0
    units = {
        "h": 3600.0,
        "m": 60.0,
        "s": 1.0,
        "ms": 0.001,
        "us": 0.000001,
    }
    for match in re.finditer(r"(\d+(?:\.\d+)?)(us|ms|h|m|s)", text):
        if match.start() != pos:
            raise ValueError(f"invalid duration: {text}")
        total += float(match.group(1)) * units[match.group(2)]
        pos = match.end()
    if pos != len(text) or not text:
        raise ValueError(f"invalid duration: {text}")
    return total


def parse_time(text):
    for fmt in ("%Y-%m-%d %H:%M:%S", "%Y-%m-%dT%H:%M:%S"):
        try:
            return _dt.datetime.strptime(text, fmt).replace(tzinfo=_dt.timezone.utc).timestamp()
        except ValueError:
            pass
    raise ValueError(f"invalid time: {text}")


def clap_error(message):
    sys.stderr.write(f"error: {message}\n")
    return 1


def shell_join(command):
    if len(command) == 1:
        return command[0]
    return " ".join(shlex.quote(part) if any(ch.isspace() for ch in part) else part for part in command)


def main(argv):
    if argv in (["--help"], ["-h"]):
        sys.stdout.write(HELP)
        return 0
    if argv in (["--version"], ["-V"]):
        sys.stdout.write("loop 0.6.1\n")
        return 0
    try:
        opts, command = parse_args(argv)
    except (ValueError, IndexError) as exc:
        return clap_error(str(exc))
    if not command:
        sys.stdout.write("No command supplied, exiting.\n")
        return 0
    items = opts["for_values"]
    if opts["stdin"]:
        items = sys.stdin.read().splitlines()
    runs = len(items) if items is not None else (opts["num"] if opts["num"] is not None else 1)
    unbounded = (
        opts["num"] is None
        and items is None
        and (
            opts["for_duration"] is not None
            or opts["until_time"] is not None
            or opts["until_success"]
            or opts["until_fail"]
            or opts["until_error"] is not None
            or opts["until_contains"] is not None
            or opts["until_match"] is not None
            or opts["until_changes"]
            or opts["until_same"]
        )
    )
    command_text = shell_join(command)
    count = opts["offset"]
    last_output = ""
    total = 0
    successes = 0
    failures = []
    previous_output = None
    start = time.time()
    index = 0
    duration_expired = False
    while unbounded or index < runs:
        now = time.time()
        if opts["for_duration"] is not None and now - start >= opts["for_duration"]:
            duration_expired = True
            break
        if opts["until_time"] is not None and now >= opts["until_time"]:
            duration_expired = True
            break
        env = os.environ.copy()
        env["COUNT"] = str(count)
        if items is not None:
            env["ITEM"] = items[index] if index < len(items) else items[-1] if items else ""
        proc = subprocess.run(
            command_text,
            shell=True,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            text=True,
            env=env,
        )
        total += 1
        if proc.returncode == 0:
            successes += 1
        else:
            failures.append(proc.returncode)
        if opts["only_last"]:
            last_output = proc.stdout
        else:
            sys.stdout.write(proc.stdout)
        stop = False
        if opts["until_contains"] is not None and opts["until_contains"] in proc.stdout:
            stop = True
        if opts["until_match"] is not None and re.search(opts["until_match"], proc.stdout):
            stop = True
        if opts["until_success"] and proc.returncode == 0:
            stop = True
        if opts["until_fail"] and proc.returncode != 0:
            stop = True
        if opts["until_error"] is not None and proc.returncode == opts["until_error"]:
            stop = True
        if previous_output is not None:
            if opts["until_changes"] and proc.stdout != previous_output:
                stop = True
            if opts["until_same"] and proc.stdout == previous_output:
                stop = True
        previous_output = proc.stdout
        count += opts["count_by"]
        index += 1
        if stop:
            break
        if opts["every"] > 0:
            time.sleep(opts["every"])
    if opts["only_last"]:
        sys.stdout.write(last_output)
    if opts["summary"]:
        sys.stdout.write(f"Total runs:\t{total}\n")
        sys.stdout.write(f"Successes:\t{successes}\n")
        if failures:
            suffix = " " + " ".join(f"({code})" for code in failures)
            sys.stdout.write(f"Failures:\t{len(failures)}{suffix}\n")
        else:
            sys.stdout.write("Failures:\t0\n")
    if duration_expired and opts["error_duration"]:
        return 124
    return 0


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
