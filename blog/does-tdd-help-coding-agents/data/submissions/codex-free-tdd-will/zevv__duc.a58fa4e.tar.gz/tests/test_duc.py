import os
import json
import shutil
import subprocess
import tempfile
import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
EXE = ROOT / "executable"


class DucBehaviorTests(unittest.TestCase):
    def setUp(self):
        self.tmp = Path(tempfile.mkdtemp(prefix="duc-test-"))
        self.db = self.tmp / "duc.db"
        self.tree = self.tmp / "tree"
        (self.tree / "dirA").mkdir(parents=True)
        (self.tree / "dirB" / "sub").mkdir(parents=True)
        (self.tree / "a.txt").write_text("abc")
        (self.tree / "dirA" / "b.bin").write_bytes(b"\0" * 1500)
        (self.tree / "dirB" / "sub" / "c.txt").write_text("hello")

    def tearDown(self):
        shutil.rmtree(self.tmp)

    def run_duc(self, *args):
        return subprocess.run(
            [str(EXE), *map(str, args)],
            text=True,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            check=False,
        )

    def test_index_info_and_ls_bytes(self):
        indexed = self.run_duc("index", "-d", self.db, self.tree)
        self.assertEqual(indexed.returncode, 0, indexed.stderr)
        self.assertTrue(self.db.exists())

        info = self.run_duc("info", "-b", "-d", self.db)
        self.assertEqual(info.returncode, 0, info.stderr)
        self.assertIn("Date       Time       Files    Dirs    Size Path", info.stdout)
        self.assertIn(str(self.tree), info.stdout)
        self.assertRegex(info.stdout, r"\s+3\s+4\s+\d+ " + str(self.tree))

        listing = self.run_duc("ls", "-b", "-d", self.db, self.tree)
        self.assertEqual(listing.returncode, 0, listing.stderr)
        lines = listing.stdout.splitlines()
        self.assertEqual(len(lines), 3)
        self.assertTrue(any(line.endswith(" dirA") for line in lines))
        self.assertTrue(any(line.endswith(" dirB") for line in lines))
        self.assertTrue(any(line.endswith(" a.txt") for line in lines))

    def test_json_xml_and_recursive_classified_listing(self):
        indexed = self.run_duc("index", "-d", self.db, self.tree)
        self.assertEqual(indexed.returncode, 0, indexed.stderr)

        exported = self.run_duc("json", "-d", self.db, self.tree)
        self.assertEqual(exported.returncode, 0, exported.stderr)
        data = json.loads(exported.stdout)
        self.assertEqual(data["name"], "tree")
        self.assertEqual(data["count"], 6)
        self.assertEqual({child["name"] for child in data["children"]}, {"dirA", "dirB", "a.txt"})
        self.assertEqual(data["size_apparent"], 1508)

        xml = self.run_duc("xml", "-d", self.db, self.tree)
        self.assertEqual(xml.returncode, 0, xml.stderr)
        self.assertIn('<?xml version="1.0" encoding="UTF-8"?>', xml.stdout)
        self.assertIn('<duc root="tree"', xml.stdout)
        self.assertIn('<ent type="dir" name="dirA"', xml.stdout)
        self.assertIn('<ent name="b.bin"', xml.stdout)

        listing = self.run_duc("ls", "-R", "-F", "-b", "-d", self.db, self.tree)
        self.assertEqual(listing.returncode, 0, listing.stderr)
        self.assertIn("dirA/", listing.stdout)
        self.assertIn("b.bin ", listing.stdout)
        self.assertIn("dirB/", listing.stdout)
        self.assertIn("c.txt ", listing.stdout)

    def test_excludes_apparent_histogram_topn_and_svg_graph(self):
        indexed = self.run_duc("index", "-T", "10", "-e", "*.txt", "-d", self.db, self.tree)
        self.assertEqual(indexed.returncode, 0, indexed.stderr)

        apparent = self.run_duc("ls", "-a", "-b", "-d", self.db, self.tree)
        self.assertEqual(apparent.returncode, 0, apparent.stderr)
        self.assertNotIn("a.txt", apparent.stdout)
        self.assertIn("1500 dirA", apparent.stdout)

        topn = self.run_duc("topn", "-b", "-d", self.db)
        self.assertEqual(topn.returncode, 0, topn.stderr)
        self.assertIn("Size Filename", topn.stdout)
        self.assertIn("b.bin", topn.stdout)

        hist = self.run_duc("histogram", "-b", "-d", self.db)
        self.assertEqual(hist.returncode, 0, hist.stderr)
        self.assertIn("Path: " + str(self.tree), hist.stdout)
        self.assertIn("Bkt       Size      Count", hist.stdout)

        svg = self.tmp / "graph.svg"
        graph = self.run_duc("graph", "-f", "svg", "-o", svg, "-d", self.db, self.tree)
        self.assertEqual(graph.returncode, 0, graph.stderr)
        self.assertIn("<svg", svg.read_text())

    def test_help_and_version_match_public_contract(self):
        version = self.run_duc("--version")
        self.assertEqual(version.returncode, 0)
        self.assertIn("duc version: 1.5.0-rc1", version.stdout)
        self.assertIn("options: cairo x11 ui sqlite3", version.stdout)

        help_out = self.run_duc("--help")
        self.assertEqual(help_out.returncode, 0)
        self.assertIn("Available subcommands:", help_out.stdout)
        self.assertIn("index     : Scan the filesystem", help_out.stdout)

        ls_help = self.run_duc("ls", "-h")
        self.assertEqual(ls_help.returncode, 0)
        self.assertIn("usage: duc ls [options] [PATH]...", ls_help.stdout)
        self.assertIn("--recursive", ls_help.stdout)


if __name__ == "__main__":
    unittest.main()
