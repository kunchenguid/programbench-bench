#!/bin/bash
set -e
rm -f executable
cp src/duc.py executable
chmod +x executable
