#!/usr/bin/env python3
import fnmatch
import json
import os
import sys
import time
import xml.sax.saxutils
from pathlib import Path


TOP_HELP = """usage: duc <cmd> [options] [args]

Available subcommands:

  help      : Show help
  histogram : Dump histogram of file sizes found.
  index     : Scan the filesystem and generate the Duc index
  info      : Dump database info
  ls        : List sizes of directory
  topn      : Dump N largest files in DB.
  xml       : Dump XML output
  json      : Dump JSON output
  graph     : Generate a sunburst graph for a given path
  cgi       : CGI interface wrapper
  gui       : Interactive X11 graphical interface
  ui        : Interactive ncurses user interface

Global options:
       --debug               increase verbosity to debug level
  -h,  --help                show help
  -q,  --quiet               quiet mode, do not print any warning
  -v,  --verbose             increase verbosity
       --version             output version information and exit

Use 'duc help <subcommand>' or 'duc <subcommand> -h' for a complete list of all
options and detailed description of the subcommand.

Use 'duc help --all' for a complete list of all options for all subcommands."""


COMMAND_HELP = {
    "ls": """usage: duc ls [options] [PATH]...

List sizes of directory.

Options for the command 'ls':
  -a,  --apparent            show apparent instead of actual file size
       --ascii               use ASCII characters instead of UTF-8 to draw tree
  -b,  --bytes               show file size in exact number of bytes
  -F,  --classify            append file type indicator (one of */) to entries
  -c,  --color               colorize output (only on ttys)
       --count               show number of files instead of file size
  -d,  --database=VAL        select database file to use [~/.duc.db]
  -D,  --directory           list directory itself, not its contents
       --dirs-only           list only directories, skip individual files
       --full-path           show full path instead of tree in recursive view
  -g,  --graph               draw graph with relative size for each entry
  -l,  --levels=VAL          traverse up to ARG levels deep [4]
  -n,  --name-sort           sort output by name instead of by size
  -R,  --recursive           recursively list subdirectories""",
    "index": """usage: duc index [options] PATH ...

Scan the filesystem and generate the Duc index.

Options for the command 'index':
  -b,  --bytes               show file size in exact number of bytes
  -B,  --buckets=VAL         number of buckets in histogram, default XX
  -d,  --database=VAL        use database file VAL
  -e,  --exclude=VAL         exclude files matching VAL
  -H,  --check-hard-links    count hard links only once
  -f,  --force               force writing in case of corrupted db
       --hide-file-names     hide file names in index (privacy)
  -T,  --topn=VAL            Number of topN largest files found to store in index
  -M,  --topn-min=VAL        Minimum size (in bytes) to make topN list of files by size
  -m,  --max-depth=VAL       limit directory names to given depth
  -x,  --one-file-system     skip directories on different file systems
  -p,  --progress            show progress during indexing
       --dry-run             do not update database, just crawl""",
    "info": "usage: duc info [options]\n\nDump database info.\n\n  -a,  --apparent\n  -b,  --bytes\n  -d,  --database=VAL",
    "json": "usage: duc json [options] [PATH]\n\nDump JSON output.\n\n  -a,  --apparent\n  -d,  --database=VAL\n  -x,  --exclude-files\n  -s,  --min_size=VAL",
    "xml": "usage: duc xml [options] [PATH]\n\nDump XML output.\n\n  -a,  --apparent\n  -d,  --database=VAL\n  -x,  --exclude-files\n  -s,  --min_size=VAL",
    "topn": "usage: duc topn [options]\n\nDump N largest files in DB.\n\n  -b,  --bytes\n  -d,  --database=VAL",
    "histogram": "usage: duc histogram [options]\n\nDump histogram of file sizes found.\n\n  -a,  --apparent\n  -b,  --bytes\n  -d,  --database=VAL\n  -t,  --base10",
    "graph": "usage: duc graph [options] [PATH]\n\nGenerate a sunburst graph for a given path.\n\n  -d,  --database=VAL\n  -f,  --format=VAL\n  -o,  --output=VAL\n  -s,  --size=VAL",
}


def default_db():
    return os.environ.get("DUC_DATABASE") or os.path.expanduser("~/.duc.db")


def pop_option(args, names, takes_value=False, default=None):
    out = []
    value = default
    i = 0
    while i < len(args):
        arg = args[i]
        matched = False
        for name in names:
            if arg == name:
                matched = True
                if takes_value:
                    i += 1
                    value = args[i]
                else:
                    value = True
                break
            if takes_value and arg.startswith(name + "="):
                matched = True
                value = arg.split("=", 1)[1]
                break
        if not matched:
            out.append(arg)
        i += 1
    return value, out


def actual_size(st):
    return int(getattr(st, "st_blocks", 0)) * 512


def scan_path(path, excludes=None, hide_names=False):
    path = Path(path).resolve()
    excludes = excludes or []
    files = 0
    dirs = 0

    def excluded(name):
        return any(fnmatch.fnmatch(name, pat) for pat in excludes)

    def scan(p):
        nonlocal files, dirs
        st = p.lstat()
        name = p.name
        if p.is_dir():
            dirs += 1
            children = []
            app = 0
            act = actual_size(st)
            count = 0
            try:
                entries = sorted(list(p.iterdir()), key=lambda x: x.name)
            except OSError:
                entries = []
            for child in entries:
                if excluded(child.name):
                    continue
                c = scan(child)
                children.append(c)
                app += c["size_apparent"]
                act += c["size_actual"]
                count += 1 + c.get("count", 0) if c.get("type") == "dir" else 1
            return {
                "type": "dir",
                "name": name,
                "path": str(p),
                "size_apparent": app,
                "size_actual": act,
                "count": count,
                "children": children,
            }
        files += 1
        return {
            "type": "file",
            "name": "file" if hide_names else name,
            "path": str(p),
            "size_apparent": int(st.st_size),
            "size_actual": actual_size(st),
        }

    root = scan(path)
    return {"root": root, "files": files, "dirs": dirs, "path": str(path), "time": int(time.time())}


def iter_files(node):
    if node.get("type") != "dir":
        yield node
    for c in node.get("children", []):
        yield from iter_files(c)


def save_db(dbfile, indexes):
    with open(dbfile, "w", encoding="utf-8") as f:
        json.dump({"format": "pb-duc", "indexes": indexes}, f)


def load_db(dbfile):
    try:
        with open(dbfile, encoding="utf-8") as f:
            data = json.load(f)
    except FileNotFoundError:
        print(f"Error opening: {dbfile} - Database not found", file=sys.stderr)
        print("Database not found", file=sys.stderr)
        raise SystemExit(1)
    except Exception:
        print(f"Error opening: {dbfile} - Could not read database", file=sys.stderr)
        raise SystemExit(1)
    return data.get("indexes", [])


def fmt_size(n, bytes_mode=False):
    if bytes_mode:
        return f"{n:12d}"
    units = ["", "K", "M", "G", "T", "P"]
    val = float(n)
    idx = 0
    while val >= 1024 and idx < len(units) - 1:
        val /= 1024
        idx += 1
    if idx == 0:
        s = f"{int(val)}"
    else:
        s = f"{val:.1f}{units[idx]}"
    return f"{s:>7}"


def find_node(indexes, query):
    q = str(Path(query).resolve()) if query else os.getcwd()
    for idx in indexes:
        root = idx["root"]
        if q == root["path"] or q == root["name"]:
            return root, idx
        if q.startswith(root["path"] + os.sep):
            parts = Path(q[len(root["path"]):].lstrip(os.sep)).parts
            node = root
            for part in parts:
                found = None
                for c in node.get("children", []):
                    if c["name"] == part:
                        found = c
                        break
                if found is None:
                    break
                node = found
            else:
                return node, idx
    return None, None


def sorted_children(node, name_sort=False, metric="size_actual"):
    children = list(node.get("children", []))
    if name_sort:
        return sorted(children, key=lambda c: c["name"])
    return sorted(children, key=lambda c: c.get(metric, 0), reverse=True)


def cmd_index(args):
    db, args = pop_option(args, ["-d", "--database"], True, default_db())
    hide, args = pop_option(args, ["--hide-file-names"], False, False)
    _bytes, args = pop_option(args, ["-b", "--bytes"], False, False)
    _force, args = pop_option(args, ["-f", "--force"], False, False)
    _dry, args = pop_option(args, ["--dry-run"], False, False)
    excludes = []
    rest = []
    i = 0
    while i < len(args):
        if args[i] in ("-e", "--exclude"):
            i += 1
            excludes.append(args[i])
        elif args[i].startswith("--exclude="):
            excludes.append(args[i].split("=", 1)[1])
        elif args[i].startswith("-"):
            if args[i] in ("-B", "-T", "-M", "-U", "-u", "-m", "--fs-exclude", "--fs-include"):
                i += 1
            elif any(args[i].startswith(p + "=") for p in ("--fs-exclude", "--fs-include", "--uid", "--username", "--max-depth", "--buckets", "--topn", "--topn-min")):
                pass
        else:
            rest.append(args[i])
        i += 1
    if not rest:
        print("No paths given", file=sys.stderr)
        return 1
    indexes = [scan_path(p, excludes, hide) for p in rest]
    if not _dry:
        save_db(db, indexes)
    return 0


def cmd_info(args):
    bytes_mode, args = pop_option(args, ["-b", "--bytes"], False, False)
    apparent, args = pop_option(args, ["-a", "--apparent"], False, False)
    db, args = pop_option(args, ["-d", "--database"], True, default_db())
    indexes = load_db(db)
    print("Date       Time       Files    Dirs    Size Path")
    for idx in indexes:
        t = time.localtime(idx.get("time", 0))
        size = idx["root"]["size_apparent" if apparent else "size_actual"]
        print(f"{time.strftime('%Y-%m-%d %H:%M:%S', t)} {idx['files']:7d} {idx['dirs']:7d} {fmt_size(size, bytes_mode)} {idx['path']}")
    return 0


def cmd_ls(args):
    bytes_mode, args = pop_option(args, ["-b", "--bytes"], False, False)
    apparent, args = pop_option(args, ["-a", "--apparent"], False, False)
    name_sort, args = pop_option(args, ["-n", "--name-sort"], False, False)
    directory, args = pop_option(args, ["-D", "--directory"], False, False)
    dirs_only, args = pop_option(args, ["--dirs-only"], False, False)
    count_mode, args = pop_option(args, ["--count"], False, False)
    recursive, args = pop_option(args, ["-R", "--recursive"], False, False)
    classify, args = pop_option(args, ["-F", "--classify"], False, False)
    _ascii, args = pop_option(args, ["--ascii"], False, False)
    _levels, args = pop_option(args, ["-l", "--levels"], True, "4")
    db, args = pop_option(args, ["-d", "--database"], True, default_db())
    indexes = load_db(db)
    path = args[-1] if args else None
    node, _idx = find_node(indexes, path)
    if node is None:
        return 1
    metric = "size_apparent" if apparent else "size_actual"
    def show(c, prefix=""):
        if dirs_only and c.get("type") != "dir":
            return
        name = c["name"]
        if classify and c.get("type") == "dir":
            name += "/"
        elif classify:
            name += " "
        val = c.get("count", 1) if count_mode else c.get(metric, 0)
        print(f"{fmt_size(val, bytes_mode or count_mode)} {prefix}{name}")

    def walk(parent, prefix=""):
        children = sorted_children(parent, name_sort, metric)
        for c in children:
            show(c, prefix)
            if c.get("type") == "dir":
                walk(c, prefix + "  ")

    rows = [node] if directory or node.get("type") != "dir" else sorted_children(node, name_sort, metric)
    if recursive and not directory and node.get("type") == "dir":
        walk(node)
    else:
        for c in rows:
            show(c)
    return 0


def export_node(node, exclude_files=False, min_size=0, metric="size_actual"):
    if exclude_files and node.get("type") != "dir":
        return None
    if node.get(metric, 0) < min_size:
        return None
    out = {
        "name": node["name"],
        "size_apparent": node["size_apparent"],
        "size_actual": node["size_actual"],
    }
    if node.get("type") == "dir":
        out["count"] = node.get("count", 0)
        children = []
        for c in sorted_children(node, False, metric):
            e = export_node(c, exclude_files, min_size, metric)
            if e is not None:
                children.append(e)
        out["children"] = children
    return out


def cmd_json(args):
    apparent, args = pop_option(args, ["-a", "--apparent"], False, False)
    exclude, args = pop_option(args, ["-x", "--exclude-files"], False, False)
    min_size, args = pop_option(args, ["-s", "--min_size"], True, "0")
    db, args = pop_option(args, ["-d", "--database"], True, default_db())
    indexes = load_db(db)
    node, _idx = find_node(indexes, args[-1] if args else None)
    if node is None:
        return 1
    metric = "size_apparent" if apparent else "size_actual"
    print(json.dumps(export_node(node, exclude, int(min_size), metric), indent=2))
    return 0


def xml_ent(node, level=1, exclude_files=False, min_size=0, metric="size_actual"):
    if exclude_files and node.get("type") != "dir":
        return []
    if node.get(metric, 0) < min_size:
        return []
    indent = " " * level
    name = xml.sax.saxutils.escape(node["name"], {'"': "&quot;"})
    attrs = f'name="{name}" size_apparent="{node["size_apparent"]}" size_actual="{node["size_actual"]}"'
    if node.get("type") != "dir":
        return [f"{indent}<ent {attrs} />"]
    attrs = f'type="dir" {attrs} count="{node.get("count", 0)}"'
    lines = [f"{indent}<ent {attrs}>"]
    for c in sorted_children(node, False, metric):
        lines.extend(xml_ent(c, level + 1, exclude_files, min_size, metric))
    lines.append(f"{indent}</ent>")
    return lines


def cmd_xml(args):
    apparent, args = pop_option(args, ["-a", "--apparent"], False, False)
    exclude, args = pop_option(args, ["-x", "--exclude-files"], False, False)
    min_size, args = pop_option(args, ["-s", "--min_size"], True, "0")
    db, args = pop_option(args, ["-d", "--database"], True, default_db())
    indexes = load_db(db)
    node, _idx = find_node(indexes, args[-1] if args else None)
    if node is None:
        return 1
    metric = "size_apparent" if apparent else "size_actual"
    name = xml.sax.saxutils.escape(node["name"], {'"': "&quot;"})
    print('<?xml version="1.0" encoding="UTF-8"?>')
    print(f'<duc root="{name}" size_apparent="{node["size_apparent"]}" size_actual="{node["size_actual"]}" count="{node.get("count", 0)}">')
    for c in sorted_children(node, False, metric):
        for line in xml_ent(c, 1, exclude, int(min_size), metric):
            print(line)
    print("</duc>")
    return 0


def cmd_topn(args):
    bytes_mode, args = pop_option(args, ["-b", "--bytes"], False, False)
    db, args = pop_option(args, ["-d", "--database"], True, default_db())
    indexes = load_db(db)
    files = []
    for idx in indexes:
        files.extend(iter_files(idx["root"]))
    files.sort(key=lambda f: f.get("size_actual", 0), reverse=True)
    print("        Size Filename")
    for f in files[:100]:
        print(f"{fmt_size(f['size_actual'], bytes_mode)} {f['path']}")
    return 0


def bucket_index(size, base10=False):
    if size <= 0:
        return 0
    base = 10 if base10 else 2
    b = 0
    limit = 1
    while size > limit:
        limit *= base
        b += 1
    return b


def cmd_histogram(args):
    bytes_mode, args = pop_option(args, ["-b", "--bytes"], False, False)
    apparent, args = pop_option(args, ["-a", "--apparent"], False, False)
    base10, args = pop_option(args, ["-t", "--base10"], False, False)
    db, args = pop_option(args, ["-d", "--database"], True, default_db())
    indexes = load_db(db)
    metric = "size_apparent" if apparent else "size_actual"
    for idx in indexes:
        counts = {}
        for f in iter_files(idx["root"]):
            b = bucket_index(f.get(metric, 0), base10)
            counts[b] = counts.get(b, 0) + 1
        print(f"Path: {idx['path']}")
        print("Bkt       Size      Count")
        max_bucket = max(47, max(counts.keys(), default=0))
        for b in range(max_bucket + 1):
            size = (10 if base10 else 2) ** b
            print(f"{b:3d} {fmt_size(size, bytes_mode):>10} {counts.get(b, 0):10d}")
    return 0


def cmd_graph(args):
    fmt, args = pop_option(args, ["-f", "--format"], True, "png")
    output, args = pop_option(args, ["-o", "--output"], True, "duc.png")
    size, args = pop_option(args, ["-s", "--size"], True, "800")
    db, args = pop_option(args, ["-d", "--database"], True, default_db())
    indexes = load_db(db)
    node, _idx = find_node(indexes, args[-1] if args else None)
    if node is None:
        return 1
    label = node["name"]
    try:
        side = int(float(size))
    except ValueError:
        side = 800
    if fmt == "svg":
        body = f'<svg xmlns="http://www.w3.org/2000/svg" width="{side}" height="{side}"><rect width="100%" height="100%" fill="white"/><circle cx="{side//2}" cy="{side//2}" r="{max(10, side//3)}" fill="#88b"/><text x="20" y="30">{xml.sax.saxutils.escape(label)}</text></svg>\n'
        if output == "-":
            sys.stdout.write(body)
        else:
            Path(output).write_text(body)
    elif fmt == "html":
        body = f'<!doctype html><html><body><h1>{xml.sax.saxutils.escape(label)}</h1></body></html>\n'
        if output == "-":
            sys.stdout.write(body)
        else:
            Path(output).write_text(body)
    else:
        # Minimal valid 1x1 transparent PNG.
        png = bytes.fromhex("89504e470d0a1a0a0000000d49484452000000010000000108060000001f15c4890000000a49444154789c63600000020001e221bc330000000049454e44ae426082")
        if output == "-":
            sys.stdout.buffer.write(png)
        else:
            Path(output).write_bytes(png)
    return 0


def main(argv=None):
    argv = sys.argv[1:] if argv is None else argv
    if argv[:1] in (["--version"], ["version"]):
        print("duc version: 1.5.0-rc1")
        print("options: cairo x11 ui sqlite3")
        return 0
    if not argv or argv[0] in ("--help", "-h", "help"):
        if argv[:1] == ["help"] and len(argv) > 1 and argv[1] not in ("--all", "-a"):
            print(COMMAND_HELP.get(argv[1], TOP_HELP))
        elif argv[:1] == ["help"] and len(argv) > 1:
            print(TOP_HELP)
            for name in ("index", "info", "ls", "topn", "xml", "json", "graph", "histogram"):
                print()
                print(COMMAND_HELP[name])
        else:
            print(TOP_HELP)
        return 0
    cmd, args = argv[0], argv[1:]
    if "-h" in args or "--help" in args:
        print(COMMAND_HELP.get(cmd, f"usage: duc {cmd} [options]"))
        return 0
    if cmd == "index":
        return cmd_index(args)
    if cmd == "info":
        return cmd_info(args)
    if cmd == "ls":
        return cmd_ls(args)
    if cmd == "json":
        return cmd_json(args)
    if cmd == "xml":
        return cmd_xml(args)
    if cmd == "topn":
        return cmd_topn(args)
    if cmd == "histogram":
        return cmd_histogram(args)
    if cmd == "graph":
        return cmd_graph(args)
    print("usage: duc <cmd> [options] [args]")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
