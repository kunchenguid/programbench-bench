#!/usr/bin/env python3
import os
import stat
import sys
from dataclasses import dataclass, field
from pathlib import Path

HELP = """Usage: ./executable [options] <path> [<path>..]

Options:
    -d, --depth [DEPTH] show directories up to depth N (def 1)
    -a, --aggr [N[KMG]] aggregate smaller than N B/KiB/MiB/GiB (def 1M)
    -s, --summary       equivalent to -da, or -d1 -a1M
    -u, --usage         report real disk usage instead of file size
    -b, --bytes         print sizes in bytes
    -f, --files-only    skip directories for a fast local overview
    -x, --exclude NAME  exclude matching files or directories
    -H, --no-hidden     exclude hidden files
    -A, --ascii         ASCII characters only, no colors
    -h, --help          show help
    -v, --version       print version number
"""


@dataclass
class Opts:
    depth: int = 2
    aggr: int = 0
    usage: bool = False
    bytes: bool = False
    files_only: bool = False
    no_hidden: bool = False
    ascii: bool = False
    excludes: list[str] = field(default_factory=list)
    paths: list[str] = field(default_factory=list)


@dataclass
class Node:
    name: str
    path: Path
    size: int
    is_dir: bool
    children: list["Node"] = field(default_factory=list)


def parse_num(text: str, default: int) -> int:
    if text is None or text == "":
        return default
    mult = 1
    last = text[-1].upper()
    if last in "KMG":
        mult = {"K": 1024, "M": 1024**2, "G": 1024**3}[last]
        text = text[:-1]
    try:
        return int(text) * mult
    except ValueError:
        return default


def parse_args(argv: list[str]) -> tuple[Opts | None, int]:
    opts = Opts()
    i = 0
    while i < len(argv):
        a = argv[i]
        if a in ("-h", "--help"):
            print(HELP, end="")
            return None, 0
        if a in ("-v", "--version"):
            print("dutree version 0.2.18")
            return None, 0
        if a in ("-A", "--ascii"):
            opts.ascii = True
        elif a in ("-b", "--bytes"):
            opts.bytes = True
        elif a in ("-u", "--usage"):
            opts.usage = True
        elif a in ("-f", "--files-only"):
            opts.files_only = True
        elif a in ("-H", "--no-hidden"):
            opts.no_hidden = True
        elif a in ("-s", "--summary"):
            opts.depth = 1
            opts.aggr = 1024 * 1024
        elif a in ("-d", "--depth"):
            if i + 1 < len(argv) and not argv[i + 1].startswith("-"):
                i += 1
                opts.depth = parse_num(argv[i], 1)
            else:
                opts.depth = 1
        elif a.startswith("--depth="):
            opts.depth = parse_num(a.split("=", 1)[1], 1)
        elif a in ("-a", "--aggr"):
            if i + 1 < len(argv) and looks_number(argv[i + 1]):
                i += 1
                opts.aggr = parse_num(argv[i], 1024 * 1024)
            else:
                opts.aggr = 1024 * 1024
        elif a.startswith("--aggr="):
            opts.aggr = parse_num(a.split("=", 1)[1], 1024 * 1024)
        elif a in ("-x", "--exclude"):
            if i + 1 < len(argv):
                i += 1
                opts.excludes.append(argv[i])
        elif a.startswith("--exclude="):
            opts.excludes.append(a.split("=", 1)[1])
        elif a.startswith("-"):
            print(HELP, end="")
            print(f"Unrecognized option: '{a.lstrip('-')}'")
            return None, 1
        else:
            opts.paths.append(a)
        i += 1
    if not opts.paths:
        opts.paths = ["."]
    return opts, 0


def looks_number(s: str) -> bool:
    return bool(s) and (s[0].isdigit() or (len(s) > 1 and s[0] in "+-" and s[1].isdigit()))


def excluded(name: str, opts: Opts) -> bool:
    return (opts.no_hidden and name.startswith(".")) or name in opts.excludes


def node_size(st: os.stat_result, opts: Opts) -> int:
    if opts.usage:
        return st.st_blocks * 512
    return st.st_size


def scan(path: Path, opts: Opts) -> Node:
    st = path.lstat()
    mode = st.st_mode
    is_dir = stat.S_ISDIR(mode)
    total = node_size(st, opts)
    children: list[Node] = []
    if is_dir:
        try:
            entries = list(path.iterdir())
        except OSError:
            entries = []
        for child in entries:
            if excluded(child.name, opts):
                continue
            cn = scan(child, opts)
            if opts.files_only and cn.is_dir:
                continue
            total += cn.size
            if not (opts.files_only and cn.is_dir):
                children.append(cn)
    children.sort(key=lambda n: -n.size)
    return Node(path.name or str(path), path, total, is_dir, children)


def human(n: int, bytes_mode: bool) -> str:
    if bytes_mode or n < 1024:
        return f"{n} B"
    units = ["KiB", "MiB", "GiB", "TiB"]
    x = float(n)
    unit = "KiB"
    for unit in units:
        x /= 1024.0
        if x < 1024.0:
            break
    return f"{x:.2f} {unit}"


def fill_width(size: int, max_sib: int, force_full: bool = False) -> int:
    if force_full:
        return 32
    if max_sib > 0 and size > 0:
        return int(size * 32 / max_sib)
    return 0


def row(prefix: str, branch: str, name: str, size: int, parent: int, max_sib: int, bytes_mode: bool, ascii_bar: bool, force_full: bool = False) -> str:
    label = prefix + branch + (name[:15] if len(name) > 15 else name)
    pad = " " * max(1, 26 - len(label))
    width = 32
    filled = fill_width(size, max_sib, force_full)
    bar = (" " * (width - filled)) + (("#" if ascii_bar else "█") * filled)
    pct = int(size * 100 / parent) if parent else 0
    return f"{label}{pad}│ {bar}│ {pct:3d}% {human(size, bytes_mode):>13}"


def visible_children(n: Node, opts: Opts) -> list[Node]:
    if opts.aggr <= 0:
        return n.children
    large = [c for c in n.children if c.size >= opts.aggr]
    small_sum = sum(c.size for c in n.children if c.size < opts.aggr)
    if small_sum:
        large.append(Node("<aggregated>", Path("<aggregated>"), small_sum, False, []))
    large.sort(key=lambda c: (-c.size, c.name))
    return large


def render_node(n: Node, opts: Opts, level: int, prefix: str, is_last: bool, parent_size: int, max_sib: int, force_full: bool = False) -> list[str]:
    if level > opts.depth:
        return []
    branch = "└─ " if is_last else "├─ "
    lines = [row(prefix, branch, n.name, n.size, parent_size, max_sib, opts.bytes, opts.ascii, force_full)]
    if level < opts.depth and n.is_dir and n.name != "<aggregated>":
        kids = visible_children(n, opts)
        next_prefix = prefix + ("   " if is_last else "│  ")
        child_max = max([k.size for k in kids], default=0)
        child_force = fill_width(n.size, max_sib, force_full) == 32
        if fill_width(n.size, max_sib, force_full) == 0:
            child_max = 0
        for idx, c in enumerate(kids):
            lines.extend(render_node(c, opts, level + 1, next_prefix, idx == len(kids) - 1, n.size, child_max, child_force))
    return lines


def print_tree(root: Node, opts: Opts) -> None:
    print(f"[ {root.name} {human(root.size, opts.bytes)} ]")
    kids = visible_children(root, opts)
    max_sib = max([k.size for k in kids], default=0)
    for idx, c in enumerate(kids):
        for line in render_node(c, opts, 1, "", idx == len(kids) - 1, root.size, max_sib):
            print(line)


def main(argv: list[str]) -> int:
    opts, code = parse_args(argv)
    if opts is None:
        return code
    roots = []
    for p in opts.paths:
        path = Path(p)
        if not path.exists() and not path.is_symlink():
            print(f"path {p} doesn't exist")
            return 1
        roots.append(scan(path, opts))
    root = roots[0] if len(roots) == 1 else Node("<collection>", Path("."), sum(r.size for r in roots), True, roots)
    print_tree(root, opts)
    return 0


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
