#!/bin/bash
set -e
rm -f executable
cp dutree.py executable
chmod +x executable
