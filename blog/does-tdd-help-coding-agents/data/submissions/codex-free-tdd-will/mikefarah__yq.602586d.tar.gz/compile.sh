#!/bin/bash
set -e
cp src/yq.py executable
chmod +x executable
