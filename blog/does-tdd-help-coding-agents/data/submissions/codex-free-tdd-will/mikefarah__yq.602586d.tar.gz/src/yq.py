#!/usr/bin/env python3
import csv
import io
import json
import os
import re
import sys
import urllib.parse
import base64
import xml.etree.ElementTree as ET


VERSION = "yq (https://github.com/mikefarah/yq/) version v4.52.5"


class YQError(Exception):
    pass


def strip_comment(s):
    quote = None
    for i, ch in enumerate(s):
        if quote:
            if ch == quote and (i == 0 or s[i - 1] != "\\"):
                quote = None
        elif ch in "'\"":
            quote = ch
        elif ch == "#" and (i == 0 or s[i - 1].isspace()):
            return s[:i].rstrip()
    return s.rstrip()


def scalar(text):
    text = text.strip()
    if text == "":
        return ""
    if text in ("null", "~"):
        return None
    if text == "true":
        return True
    if text == "false":
        return False
    if (text[0:1], text[-1:]) in [(('"', '"')), (("'", "'"))]:
        q = text[0]
        body = text[1:-1]
        return bytes(body, "utf-8").decode("unicode_escape") if q == '"' else body.replace("''", "'")
    if text[0:1] in "[{" and text[-1:] in "]}":
        try:
            return json.loads(text)
        except Exception:
            pass
    if re.fullmatch(r"[-+]?\d+", text):
        try:
            return int(text)
        except Exception:
            pass
    if re.fullmatch(r"[-+]?(\d+\.\d*|\d*\.\d+)([eE][-+]?\d+)?", text):
        try:
            return float(text)
        except Exception:
            pass
    return text


def split_key_value(s):
    quote = None
    depth = 0
    for i, ch in enumerate(s):
        if quote:
            if ch == quote and s[i - 1:i] != "\\":
                quote = None
        elif ch in "'\"":
            quote = ch
        elif ch in "[{(":
            depth += 1
        elif ch in "]})":
            depth -= 1
        elif ch == ":" and depth == 0 and (i + 1 == len(s) or s[i + 1].isspace()):
            return s[:i].strip(), s[i + 1:].strip()
    return None, None


def yaml_lines(text):
    out = []
    for raw in text.splitlines():
        if raw.strip() in ("---", "...") or not raw.strip():
            continue
        line = strip_comment(raw.rstrip("\n"))
        if line.strip():
            out.append((len(line) - len(line.lstrip(" ")), line.lstrip(" ")))
    return out


def parse_yaml(text):
    lines = yaml_lines(text)
    if not lines:
        return None

    def parse_block(pos, indent):
        if pos >= len(lines) or lines[pos][0] < indent:
            return None, pos
        if lines[pos][1].startswith("- "):
            arr = []
            while pos < len(lines) and lines[pos][0] == indent and lines[pos][1].startswith("- "):
                item = lines[pos][1][2:].strip()
                pos += 1
                if item == "":
                    val, pos = parse_block(pos, indent + 2)
                    arr.append(val)
                    continue
                k, v = split_key_value(item)
                if k is not None:
                    m = {}
                    if v == "":
                        val, pos = parse_block(pos, indent + 2)
                    else:
                        val = scalar(v)
                    m[scalar(k)] = val
                    while pos < len(lines) and lines[pos][0] >= indent + 2:
                        if lines[pos][0] == indent + 2 and not lines[pos][1].startswith("- "):
                            kk, vv = split_key_value(lines[pos][1])
                            pos += 1
                            if kk is None:
                                break
                            if vv == "":
                                val, pos = parse_block(pos, indent + 4)
                            else:
                                val = scalar(vv)
                            m[scalar(kk)] = val
                        else:
                            break
                    arr.append(m)
                else:
                    arr.append(scalar(item))
            return arr, pos
        m = {}
        while pos < len(lines) and lines[pos][0] == indent and not lines[pos][1].startswith("- "):
            k, v = split_key_value(lines[pos][1])
            if k is None:
                return scalar(lines[pos][1]), pos + 1
            pos += 1
            if v == "":
                val, pos = parse_block(pos, indent + 2)
            else:
                val = scalar(v)
            m[scalar(k)] = val
        return m, pos

    doc, _ = parse_block(0, lines[0][0])
    return doc


def parse_props(text):
    root = {}
    for raw in text.splitlines():
        s = raw.strip()
        if not s or s.startswith(("#", "!")):
            continue
        if "=" in s:
            k, v = s.split("=", 1)
        elif ":" in s:
            k, v = s.split(":", 1)
        else:
            k, v = s, ""
        set_path(root, parse_path("." + k.strip().replace(".", ".")), scalar(v.strip()))
    return root


def parse_csv_text(text, sep=","):
    rows = list(csv.reader(io.StringIO(text), delimiter=sep))
    if not rows:
        return []
    headers = rows[0]
    return [dict(zip(headers, [scalar(x) for x in row])) for row in rows[1:]]


def elem_to_obj(e):
    children = list(e)
    attrs = {"+@" + k: v for k, v in e.attrib.items()}
    text = (e.text or "").strip()
    if not children:
        return {**attrs, "+content": scalar(text)} if attrs else scalar(text)
    obj = dict(attrs)
    for c in children:
        val = elem_to_obj(c)
        if c.tag in obj:
            if not isinstance(obj[c.tag], list):
                obj[c.tag] = [obj[c.tag]]
            obj[c.tag].append(val)
        else:
            obj[c.tag] = val
    if text:
        obj["+content"] = scalar(text)
    return obj


def parse_input(text, fmt):
    if fmt in ("json", "j"):
        return json.loads(text) if text.strip() else None
    if fmt in ("props", "p", "properties"):
        return parse_props(text)
    if fmt in ("csv", "c"):
        return parse_csv_text(text, ",")
    if fmt in ("tsv", "t"):
        return parse_csv_text(text, "\t")
    if fmt in ("xml", "x"):
        root = ET.fromstring(text)
        return {root.tag: elem_to_obj(root)}
    if fmt == "base64":
        return base64.b64decode(text.strip()).decode()
    if fmt == "uri":
        return urllib.parse.unquote(text.strip())
    return parse_yaml(text)


def detect_format(path, requested, output=False):
    if requested not in ("", "auto", "a"):
        aliases = {"y": "yaml", "j": "json", "p": "props", "c": "csv", "t": "tsv", "x": "xml", "s": "shell"}
        return aliases.get(requested, requested)
    ext = os.path.splitext(path or "")[1].lower()
    return {
        ".json": "json", ".yaml": "yaml", ".yml": "yaml", ".xml": "xml",
        ".properties": "props", ".props": "props", ".csv": "csv", ".tsv": "tsv",
    }.get(ext, "yaml")


def quote_yaml_string(s):
    if s == "" or re.search(r"[:#\[\]{},&*!|>'\"%@`]", s) or s.strip() != s or s in ("true", "false", "null", "~"):
        return json.dumps(s)
    return s


def dump_yaml(obj, indent=0):
    sp = " " * indent
    if obj is None:
        return "null\n"
    if isinstance(obj, bool):
        return ("true" if obj else "false") + "\n"
    if isinstance(obj, (int, float)):
        return str(obj) + "\n"
    if isinstance(obj, str):
        return quote_yaml_string(obj) + "\n"
    if isinstance(obj, list):
        if not obj:
            return "[]\n"
        out = []
        for item in obj:
            if isinstance(item, (dict, list)):
                rendered = dump_yaml(item, indent + 2).rstrip("\n").splitlines()
                out.append(sp + "- " + (rendered[0].lstrip() if rendered else ""))
                out.extend(rendered[1:])
            else:
                out.append(sp + "- " + dump_yaml(item, 0).strip())
        return "\n".join(out) + "\n"
    if isinstance(obj, dict):
        if not obj:
            return "{}\n"
        out = []
        for k, v in obj.items():
            key = str(k)
            if isinstance(v, (dict, list)):
                out.append(sp + key + ":")
                out.append(dump_yaml(v, indent + 2).rstrip("\n"))
            else:
                out.append(sp + key + ": " + dump_yaml(v, 0).strip())
        return "\n".join(out) + "\n"
    return str(obj) + "\n"


def dump_props(obj, prefix=""):
    out = []
    if isinstance(obj, dict):
        for k, v in obj.items():
            out.extend(dump_props(v, f"{prefix}.{k}" if prefix else str(k)))
    elif isinstance(obj, list):
        for i, v in enumerate(obj):
            out.extend(dump_props(v, f"{prefix}.{i}" if prefix else str(i)))
    else:
        out.append(f"{prefix} = {format_scalar(obj)}")
    return out


def dump_shell(obj, prefix=""):
    out = []
    if isinstance(obj, dict):
        for k, v in obj.items():
            key = re.sub(r"\W+", "_", str(k)).strip("_")
            out.extend(dump_shell(v, f"{prefix}_{key}" if prefix else key))
    elif isinstance(obj, list):
        for i, v in enumerate(obj):
            out.extend(dump_shell(v, f"{prefix}_{i}" if prefix else str(i)))
    elif prefix:
        out.append(f"{prefix}={json.dumps(str(format_scalar(obj)))}")
    return out


def format_scalar(v):
    if v is None:
        return "null"
    if v is True:
        return "true"
    if v is False:
        return "false"
    return str(v)


def emit(values, fmt, unwrap=True):
    chunks = []
    for v in values:
        if unwrap and not isinstance(v, (dict, list)):
            chunks.append(format_scalar(v) + "\n")
        elif fmt == "json":
            chunks.append(json.dumps(v, indent=2) + "\n")
        elif fmt in ("props", "properties"):
            chunks.append("\n".join(dump_props(v)) + ("\n" if dump_props(v) else ""))
        elif fmt == "shell":
            chunks.append("\n".join(dump_shell(v)) + ("\n" if dump_shell(v) else ""))
        elif fmt == "base64":
            chunks.append(base64.b64encode(str(v).encode()).decode() + "\n")
        elif fmt == "uri":
            chunks.append(urllib.parse.quote(str(v)) + "\n")
        else:
            chunks.append(dump_yaml(v))
    return "".join(chunks)


def emit_documents(values, fmt, unwrap=True, separators=False):
    if not separators or len(values) <= 1:
        return emit(values, fmt, unwrap)
    return "---\n".join(emit([v], fmt, unwrap) for v in values)


def split_top(expr, sep):
    parts, start, quote, depth = [], 0, None, 0
    for i, ch in enumerate(expr):
        if quote:
            if ch == quote and expr[i - 1:i] != "\\":
                quote = None
        elif ch in "'\"":
            quote = ch
        elif ch in "[({":
            depth += 1
        elif ch in "])}":
            depth -= 1
        elif ch == sep and depth == 0:
            parts.append(expr[start:i].strip())
            start = i + 1
    parts.append(expr[start:].strip())
    return parts


def parse_path(expr):
    if expr in ("", "."):
        return []
    i, toks = 0, []
    if expr.startswith("."):
        i = 1
    while i < len(expr):
        if expr[i] == ".":
            i += 1
            continue
        if expr[i] == "[":
            j = expr.find("]", i)
            content = expr[i + 1:j].strip()
            if content == "":
                toks.append(("iter", None))
            elif content[0:1] in "'\"":
                toks.append(("key", scalar(content)))
            else:
                toks.append(("idx", int(content)))
            i = j + 1
        else:
            j = i
            while j < len(expr) and expr[j] not in ".[":
                j += 1
            toks.append(("key", expr[i:j]))
            i = j
    return toks


def get_path(value, toks):
    vals = [value]
    for kind, key in toks:
        nxt = []
        for v in vals:
            if kind == "iter":
                if isinstance(v, list):
                    nxt.extend(v)
                elif isinstance(v, dict):
                    nxt.extend(v.values())
            elif kind == "key" and isinstance(v, dict):
                nxt.append(v.get(key))
            elif kind == "idx" and isinstance(v, list):
                nxt.append(v[key] if -len(v) <= key < len(v) else None)
            else:
                nxt.append(None)
        vals = nxt
    return vals


def ensure_container(next_tok):
    return [] if next_tok and next_tok[0] == "idx" else {}


def set_path(root, toks, value):
    if not toks:
        return value
    cur = root
    for n, (kind, key) in enumerate(toks):
        last = n == len(toks) - 1
        nxt = toks[n + 1] if not last else None
        if kind == "key":
            if not isinstance(cur, dict):
                raise YQError("cannot index non-map")
            if last:
                cur[key] = value
            else:
                if key not in cur or cur[key] is None:
                    cur[key] = ensure_container(nxt)
                cur = cur[key]
        elif kind == "idx":
            if not isinstance(cur, list):
                raise YQError("cannot index non-array")
            while len(cur) <= key:
                cur.append(None)
            if last:
                cur[key] = value
            else:
                if cur[key] is None:
                    cur[key] = ensure_container(nxt)
                cur = cur[key]
    return root


def deep_merge(a, b):
    if isinstance(a, dict) and isinstance(b, dict):
        out = dict(a)
        for k, v in b.items():
            out[k] = deep_merge(out[k], v) if k in out else v
        return out
    return b


def eval_value(expr, doc, files=None):
    expr = expr.strip()
    if " // " in expr:
        left, right = expr.split(" // ", 1)
        vals = eval_value(left, doc, files)
        if vals and vals[0] is not None and vals[0] is not False:
            return vals
        return eval_value(right, doc, files)
    if " * " in expr:
        left, right = split_top(expr, "*")
        lval = eval_value(left, doc, files)[0]
        rval = eval_value(right, doc, files)[0]
        return [deep_merge(lval, rval)]
    if expr in ("", "."):
        return [doc]
    if expr == "keys":
        return [list(doc.keys())] if isinstance(doc, dict) else [[]]
    if expr == "length":
        if isinstance(doc, (dict, list, str)):
            return [len(doc)]
        return [0]
    if expr.startswith("has(") and expr.endswith(")"):
        key = scalar(expr[4:-1].strip())
        return [isinstance(doc, dict) and key in doc]
    if expr.startswith("load("):
        name = scalar(expr[5:-1].strip())
        return [load_file(name)[0]]
    if expr.startswith("strenv(") or expr.startswith("env("):
        name = expr[expr.find("(") + 1:-1].strip()
        return [os.environ.get(name, "")]
    if expr[0:1] in "'\"" or re.fullmatch(r"[-+]?\d+(\.\d+)?", expr) or expr in ("true", "false", "null"):
        return [scalar(expr)]
    if expr.startswith("[") and expr.endswith("]"):
        inner = expr[1:-1].strip()
        vals = eval_expr(inner, doc, files)
        return [vals]
    if expr.startswith("select(") and expr.endswith(")"):
        cond = expr[7:-1].strip()
        return [doc] if test_condition(cond, doc) else []
    if expr.startswith("."):
        return get_path(doc, parse_path(expr))
    return [expr]


def test_condition(cond, doc):
    for op in ("==", "!="):
        if op in cond:
            left, right = cond.split(op, 1)
            lv = eval_value(left.strip(), doc)[0]
            rv = eval_value(right.strip(), doc)[0]
            return (lv == rv) if op == "==" else (lv != rv)
    return bool(eval_value(cond, doc)[0])


def eval_expr(expr, doc, files=None):
    expr = expr.strip()
    if "ireduce" in expr and files:
        acc = {}
        for d in files:
            acc = deep_merge(acc, d)
        return [acc]
    cur = [doc]
    for part in split_top(expr, "|"):
        if not part:
            continue
        assign = find_assignment(part)
        if assign:
            lhs, rhs = assign
            next_vals = []
            for item in cur:
                vals = eval_value(rhs, item, files)
                toks = parse_path(lhs)
                if item is None and toks:
                    item = ensure_container(toks[0])
                item = set_path(item, toks, vals[0] if vals else None)
                next_vals.append(item)
            cur = next_vals
        else:
            next_vals = []
            for item in cur:
                next_vals.extend(eval_value(part, item, files))
            cur = next_vals
    return cur


def find_assignment(part):
    quote, depth = None, 0
    for i, ch in enumerate(part):
        if quote:
            if ch == quote and part[i - 1:i] != "\\":
                quote = None
        elif ch in "'\"":
            quote = ch
        elif ch in "[({":
            depth += 1
        elif ch in "])}":
            depth -= 1
        elif ch == "=" and depth == 0 and part[i - 1:i] not in ("!", "=", "<", ">") and part[i + 1:i + 2] != "=":
            return part[:i].strip(), part[i + 1:].strip()
    return None


def load_file(path, infmt="auto"):
    text = sys.stdin.read() if path == "-" else open(path, "r", encoding="utf-8").read()
    fmt = detect_format(path, infmt)
    return parse_input(text, fmt), fmt


def help_text():
    return """yq is a portable command-line data file processor (https://github.com/mikefarah/yq/) 
See https://mikefarah.gitbook.io/yq/ for detailed documentation and examples.

Usage:
  yq [flags]
  yq [command]

Available Commands:
  completion  Generate the autocompletion script for the specified shell
  eval        (default) Apply the expression to each document in each yaml file in sequence
  eval-all    Loads _all_ yaml documents of _all_ yaml files and runs expression once
  help        Help about any command

Flags:
  -e, --exit-status     set exit status if there are no matches or null or false is returned
  -h, --help            help for yq
  -i, --inplace         update the file in place of first file given.
  -n, --null-input      Don't read input, simply evaluate the expression given.
  -o, --output-format   output format type
  -p, --input-format    parse format for input
  -P, --prettyPrint     pretty print
  -r, --unwrapScalar    unwrap scalar
  -V, --version         Print version information and quit
"""


def parse_args(argv):
    opts = {"in": "auto", "out": "auto", "inplace": False, "null": False, "exit": False, "unwrap": True, "expr": None, "cmd": "eval", "no_doc": False}
    args = []
    it = iter(range(len(argv)))
    i = 0
    while i < len(argv):
        a = argv[i]
        if a in ("eval", "e", "eval-all", "ea"):
            opts["cmd"] = "eval-all" if a in ("eval-all", "ea") else "eval"
        elif a in ("--help", "-h", "help"):
            opts["help"] = True
        elif a in ("--version", "-V"):
            opts["version"] = True
        elif a in ("-i", "--inplace"):
            opts["inplace"] = True
        elif a in ("-n", "--null-input"):
            opts["null"] = True
        elif a in ("-e", "--exit-status"):
            opts["exit"] = True
        elif a in ("-N", "--no-doc"):
            opts["no_doc"] = True
        elif a in ("-P", "--prettyPrint", "-M", "--no-colors", "-C", "--colors"):
            pass
        elif a in ("-r", "--unwrapScalar"):
            opts["unwrap"] = True
        elif a.startswith("-r=") or a.startswith("--unwrapScalar="):
            opts["unwrap"] = a.split("=", 1)[1].lower() != "false"
        elif a in ("--expression", "--from-file"):
            i += 1
            opts["expr"] = open(argv[i]).read() if a == "--from-file" else argv[i]
        elif a.startswith("--expression="):
            opts["expr"] = a.split("=", 1)[1]
        elif a.startswith("--from-file="):
            opts["expr"] = open(a.split("=", 1)[1]).read()
        elif a in ("-o", "--output-format"):
            i += 1
            opts["out"] = argv[i]
        elif a.startswith("-o=") or a.startswith("--output-format="):
            opts["out"] = a.split("=", 1)[1]
        elif a.startswith("-o") and len(a) > 2:
            opts["out"] = a[2:]
        elif a in ("-p", "--input-format"):
            i += 1
            opts["in"] = argv[i]
        elif a.startswith("-p=") or a.startswith("--input-format="):
            opts["in"] = a.split("=", 1)[1]
        elif a.startswith("-p") and len(a) > 2:
            opts["in"] = a[2:]
        elif a.startswith("-I"):
            if a == "-I":
                i += 1
        elif a.startswith("--"):
            if "=" not in a and i + 1 < len(argv) and not argv[i + 1].startswith("-"):
                i += 1
        else:
            args.append(a)
        i += 1
    if opts["expr"] is None:
        expr_heads = ("select", "load", "has", "strenv", "env", "keys", "length")
        if args and (args[0].startswith(".") or args[0].startswith("[") or "|" in args[0] or "=" in args[0] or args[0].startswith(expr_heads)):
            opts["expr"] = args.pop(0)
        else:
            opts["expr"] = "."
    opts["files"] = args
    return opts


def main(argv):
    opts = parse_args(argv)
    if opts.get("version"):
        print(VERSION)
        return 0
    if opts.get("help"):
        print(help_text(), end="")
        return 0

    docs, input_fmt = [], "yaml"
    if opts["null"]:
        docs = [None]
    else:
        files = opts["files"] or ["-"]
        for f in files:
            doc, input_fmt = load_file(f, opts["in"])
            docs.append(doc)
    outfmt = detect_format(opts["files"][0] if opts["files"] else "", opts["out"], True)
    if opts["out"] in ("auto", "a", ""):
        outfmt = input_fmt
    groups = []
    if opts["cmd"] == "eval-all":
        groups = [eval_expr(opts["expr"], docs[0] if docs else None, docs)]
    else:
        for d in docs:
            if opts["null"] and opts["expr"].strip() == ".":
                groups.append([""])
            else:
                groups.append(eval_expr(opts["expr"], d, docs))
    results = [v for group in groups for v in group]
    if opts["inplace"]:
        if not opts["files"]:
            raise YQError("write in place flag only applicable when giving an expression and at least one file")
        with open(opts["files"][0], "w", encoding="utf-8") as f:
            f.write(emit_documents(results[:1], outfmt, unwrap=False))
    else:
        if not opts["no_doc"] and len(groups) > 1:
            sys.stdout.write("---\n".join(emit(group, outfmt, opts["unwrap"]) for group in groups))
        else:
            sys.stdout.write(emit(results, outfmt, opts["unwrap"]))
    if opts["exit"] and (not results or results[-1] in (None, False)):
        print("Error: no matches found", file=sys.stderr)
        return 1
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main(sys.argv[1:]))
    except Exception as e:
        print(f"Error: {e}", file=sys.stderr)
        raise SystemExit(1)
