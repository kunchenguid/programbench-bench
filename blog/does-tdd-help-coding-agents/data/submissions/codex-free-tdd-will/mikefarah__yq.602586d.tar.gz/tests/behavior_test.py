#!/usr/bin/env python3
import os
import subprocess
import tempfile
import textwrap


ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
BIN = os.path.join(ROOT, "executable")


def run_yq(args, input_text=None):
    return subprocess.run(
        [BIN, *args],
        input=input_text,
        text=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
    )


def test_nested_yaml_path():
    with tempfile.NamedTemporaryFile("w", suffix=".yml", delete=False) as f:
        f.write(
            textwrap.dedent(
                """\
                a:
                  b:
                    - c: cool
                """
            )
        )
        name = f.name
    try:
        result = run_yq([".a.b[0].c", name])
        assert result.returncode == 0, result.stderr
        assert result.stdout == "cool\n"
    finally:
        os.unlink(name)


def test_yaml_to_json_output():
    result = run_yq(["-o=json", "."], "a: 1\nb:\n  - x\n")
    assert result.returncode == 0, result.stderr
    assert result.stdout == '{\n  "a": 1,\n  "b": [\n    "x"\n  ]\n}\n'


def test_inplace_assignment_updates_yaml_file():
    with tempfile.NamedTemporaryFile("w", suffix=".yml", delete=False) as f:
        f.write("a:\n  b: old\n")
        name = f.name
    try:
        result = run_yq(["-i", '.a.b = "new"', name])
        assert result.returncode == 0, result.stderr
        with open(name, encoding="utf-8") as changed:
            assert changed.read() == "a:\n  b: new\n"
    finally:
        os.unlink(name)


def test_filter_array_items_and_collect_results():
    data = textwrap.dedent(
        """\
        items:
          - type: fruit
            name: apple
          - type: tool
            name: saw
          - type: fruit
            name: pear
        """
    )
    result = run_yq(['[.items[] | select(.type == "fruit") | .name]'], data)
    assert result.returncode == 0, result.stderr
    assert result.stdout == "- apple\n- pear\n"


def test_multiple_files_are_separated_by_yaml_document_marker():
    files = []
    try:
        for value in (1, 2):
            f = tempfile.NamedTemporaryFile("w", suffix=".yml", delete=False)
            f.write(f"a: {value}\n")
            f.close()
            files.append(f.name)
        result = run_yq([".a", *files])
        assert result.returncode == 0, result.stderr
        assert result.stdout == "1\n---\n2\n"
    finally:
        for name in files:
            os.unlink(name)


def test_exit_status_reports_no_matches_for_missing_path():
    result = run_yq(["-e", ".missing"], "a: 1\n")
    assert result.returncode == 1
    assert result.stdout == "null\n"
    assert "Error: no matches found" in result.stderr


def test_null_input_assignment_creates_nested_document():
    result = run_yq(["-n", '.a.b.c = "cat"'])
    assert result.returncode == 0, result.stderr
    assert result.stdout == "a:\n  b:\n    c: cat\n"


def test_array_iteration_from_one_document_has_no_document_separators():
    result = run_yq([".items[]"], "items:\n  - x\n  - y\n")
    assert result.returncode == 0, result.stderr
    assert result.stdout == "x\ny\n"


if __name__ == "__main__":
    tests = [
        test_nested_yaml_path,
        test_yaml_to_json_output,
        test_inplace_assignment_updates_yaml_file,
        test_filter_array_items_and_collect_results,
        test_multiple_files_are_separated_by_yaml_document_marker,
        test_exit_status_reports_no_matches_for_missing_path,
        test_null_input_assignment_creates_nested_document,
        test_array_iteration_from_one_document_has_no_document_separators,
    ]
    for test in tests:
        test()
    print(f"{len(tests)} tests passed")
