module cleanroom-muffet

go 1.20
