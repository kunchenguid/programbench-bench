package main

import (
	"bytes"
	"encoding/json"
	"encoding/xml"
	"fmt"
	"io"
	"net/http"
	"net/url"
	"os"
	"regexp"
	"sort"
	"strings"
)

var attrRE = regexp.MustCompile(`(?is)\b(?:href|src)\s*=\s*("[^"]*"|'[^']*'|[^\s>]+)`)

type options struct {
	verbose         bool
	onePageOnly     bool
	ignoreFragments bool
	format          string
	accepted        []statusRange
	include         []*regexp.Regexp
	exclude         []*regexp.Regexp
	headers         map[string]string
}

type statusRange struct {
	min int
	max int
}

type pageResult struct {
	URL   string
	Links []linkResult
}

type linkResult struct {
	URL    string `json:"url"`
	Status int    `json:"status,omitempty"`
	Error  string `json:"error,omitempty"`
}

func main() {
	if len(os.Args) == 2 && (os.Args[1] == "-h" || os.Args[1] == "--help") {
		printHelp()
		return
	}
	if len(os.Args) == 2 && os.Args[1] == "--version" {
		fmt.Println("2.11.1")
		return
	}

	opts, rawURL, ok := parseArgs(os.Args[1:])
	if !ok {
		os.Exit(1)
	}

	root, err := url.Parse(rawURL)
	if err != nil || root.Scheme == "" || root.Host == "" {
		fmt.Fprintln(os.Stderr, "invalid URL")
		os.Exit(1)
	}
	if root.Scheme != "http" && root.Scheme != "https" {
		fmt.Fprintf(os.Stderr, "failed to fetch root page: unsupported protocol %q. http and https are supported\n", root.Scheme)
		os.Exit(1)
	}

	results, failed, err := crawl(root, opts)
	if err != nil {
		fmt.Fprintf(os.Stderr, "failed to fetch root page: %v\n", err)
		os.Exit(1)
	}

	switch opts.format {
	case "text":
		printText(results, opts.verbose)
	case "json":
		printJSON(results, opts.verbose)
	case "junit":
		printJUnit(results)
	default:
		printText(results, opts.verbose)
	}

	if failed {
		os.Exit(1)
	}
}

func parseArgs(args []string) (options, string, bool) {
	opts := options{format: "text", accepted: []statusRange{{min: 200, max: 300}}, headers: map[string]string{}}
	var urls []string
	for i := 0; i < len(args); i++ {
		arg := args[i]
		switch {
		case arg == "-v" || arg == "--verbose":
			opts.verbose = true
		case arg == "--one-page-only":
			opts.onePageOnly = true
		case arg == "-f" || arg == "--ignore-fragments":
			opts.ignoreFragments = true
		case arg == "--json":
			opts.format = "json"
		case arg == "--experimental-verbose-json":
			opts.format = "json"
			opts.verbose = true
		case arg == "--junit":
			opts.format = "junit"
		case strings.HasPrefix(arg, "--accepted-status-codes="):
			ranges, err := parseStatusRanges(strings.TrimPrefix(arg, "--accepted-status-codes="))
			if err != nil {
				fmt.Fprintln(os.Stderr, err)
				return opts, "", false
			}
			opts.accepted = ranges
		case strings.HasPrefix(arg, "--include=") || strings.HasPrefix(arg, "-i="):
			pattern := valueAfterEqual(arg)
			re, err := regexp.Compile(pattern)
			if err != nil {
				fmt.Fprintln(os.Stderr, err)
				return opts, "", false
			}
			opts.include = append(opts.include, re)
		case arg == "--include" || arg == "-i":
			if i+1 >= len(args) {
				fmt.Fprintln(os.Stderr, "expected argument for flag `include'")
				return opts, "", false
			}
			i++
			re, err := regexp.Compile(args[i])
			if err != nil {
				fmt.Fprintln(os.Stderr, err)
				return opts, "", false
			}
			opts.include = append(opts.include, re)
		case strings.HasPrefix(arg, "--exclude=") || strings.HasPrefix(arg, "-e="):
			pattern := valueAfterEqual(arg)
			re, err := regexp.Compile(pattern)
			if err != nil {
				fmt.Fprintln(os.Stderr, err)
				return opts, "", false
			}
			opts.exclude = append(opts.exclude, re)
		case arg == "--exclude" || arg == "-e":
			if i+1 >= len(args) {
				fmt.Fprintln(os.Stderr, "expected argument for flag `exclude'")
				return opts, "", false
			}
			i++
			re, err := regexp.Compile(args[i])
			if err != nil {
				fmt.Fprintln(os.Stderr, err)
				return opts, "", false
			}
			opts.exclude = append(opts.exclude, re)
		case strings.HasPrefix(arg, "--header="):
			addHeader(opts.headers, strings.TrimPrefix(arg, "--header="))
		case arg == "--header":
			if i+1 >= len(args) {
				fmt.Fprintln(os.Stderr, "expected argument for flag `header'")
				return opts, "", false
			}
			i++
			addHeader(opts.headers, args[i])
		case strings.HasPrefix(arg, "--format="):
			opts.format = strings.TrimPrefix(arg, "--format=")
			if opts.format != "text" && opts.format != "json" && opts.format != "junit" {
				fmt.Fprintf(os.Stderr, "Invalid value `%s' for option `--format'. Allowed values are: text, json or junit\n", opts.format)
				return opts, "", false
			}
		case arg == "--format":
			if i+1 >= len(args) {
				fmt.Fprintln(os.Stderr, "expected argument for flag `format'")
				return opts, "", false
			}
			i++
			opts.format = args[i]
		case hasValueFlag(arg):
			if !strings.Contains(arg, "=") {
				i++
			}
		case arg == "--follow-robots-txt" || arg == "--follow-sitemap-xml" || arg == "--skip-tls-verification":
			// Accepted for CLI compatibility. These are best-effort no-ops in this reimplementation.
		case strings.HasPrefix(arg, "-"):
			fmt.Fprintf(os.Stderr, "unknown flag `%s'\n", strings.TrimLeft(arg, "-"))
			return opts, "", false
		default:
			urls = append(urls, arg)
		}
	}
	if len(urls) != 1 {
		fmt.Fprintln(os.Stderr, "invalid number of arguments")
		return opts, "", false
	}
	return opts, urls[0], true
}

func crawl(root *url.URL, opts options) ([]pageResult, bool, error) {
	queue := []*url.URL{root}
	visited := map[string]bool{}
	var results []pageResult
	failed := false

	for len(queue) > 0 {
		page := queue[0]
		queue = queue[1:]
		pageNoFragment := *page
		pageNoFragment.Fragment = ""
		pageKey := pageNoFragment.String()
		if visited[pageKey] {
			continue
		}
		visited[pageKey] = true

		body, contentType, err := fetch(pageKey, opts.headers)
		if err != nil {
			if pageKey == root.String() {
				return nil, false, err
			}
			results = append(results, pageResult{URL: pageKey})
			continue
		}

		pr := pageResult{URL: pageKey}
		for _, link := range links(body, &pageNoFragment, opts) {
			status, ctype, linkBody, err := check(link, opts.headers)
			lr := linkResult{URL: link}
			if err != nil {
				lr.Error = "error"
				failed = true
			} else if !accepted(status, opts.accepted) {
				lr.Error = fmt.Sprint(status)
				failed = true
			} else if frag := fragmentOf(link); !opts.ignoreFragments && frag != "" && !hasFragment(linkBody, frag) {
				lr.Error = fmt.Sprintf("id #%s not found", frag)
				failed = true
			} else {
				lr.Status = status
			}
			pr.Links = append(pr.Links, lr)

			parsed, _ := url.Parse(link)
			if !opts.onePageOnly && err == nil && accepted(status, opts.accepted) && sameOrigin(root, parsed) && strings.Contains(strings.ToLower(ctype), "text/html") {
				copyURL := *parsed
				copyURL.Fragment = ""
				if !visited[copyURL.String()] {
					queue = append(queue, &copyURL)
				}
			}
		}
		sort.Slice(pr.Links, func(i, j int) bool { return pr.Links[i].URL < pr.Links[j].URL })
		if strings.Contains(strings.ToLower(contentType), "text/html") || len(pr.Links) > 0 {
			results = append(results, pr)
		}
	}
	return results, failed, nil
}

func fetch(raw string, headers map[string]string) ([]byte, string, error) {
	resp, err := doGet(raw, headers)
	if err != nil {
		return nil, "", err
	}
	defer resp.Body.Close()
	body, err := io.ReadAll(io.LimitReader(resp.Body, 10_000_000))
	return body, resp.Header.Get("Content-Type"), err
}

func check(raw string, headers map[string]string) (int, string, []byte, error) {
	resp, err := doGet(raw, headers)
	if err != nil {
		return 0, "", nil, err
	}
	defer resp.Body.Close()
	body, _ := io.ReadAll(io.LimitReader(resp.Body, 10_000_000))
	return resp.StatusCode, resp.Header.Get("Content-Type"), body, nil
}

func links(body []byte, base *url.URL, opts options) []string {
	matches := attrRE.FindAllSubmatch(body, -1)
	seen := map[string]bool{}
	var out []string
	for _, match := range matches {
		value := string(bytes.Trim(match[1], `"'`))
		if skip(value) {
			continue
		}
		ref, err := url.Parse(value)
		if err != nil {
			continue
		}
		resolved := base.ResolveReference(ref)
		if opts.ignoreFragments {
			resolved.Fragment = ""
		}
		raw := resolved.String()
		if !allowedByFilters(raw, opts) {
			continue
		}
		if !seen[raw] {
			seen[raw] = true
			out = append(out, raw)
		}
	}
	return out
}

func skip(value string) bool {
	value = strings.TrimSpace(value)
	lower := strings.ToLower(value)
	return value == "" || strings.HasPrefix(lower, "mailto:") || strings.HasPrefix(lower, "tel:") || strings.HasPrefix(lower, "javascript:")
}

func doGet(raw string, headers map[string]string) (*http.Response, error) {
	req, err := http.NewRequest(http.MethodGet, raw, nil)
	if err != nil {
		return nil, err
	}
	for name, value := range headers {
		req.Header.Set(name, value)
	}
	return http.DefaultClient.Do(req)
}

func parseStatusRanges(text string) ([]statusRange, error) {
	var ranges []statusRange
	for _, part := range strings.Split(text, ",") {
		part = strings.TrimSpace(part)
		if part == "" {
			continue
		}
		if strings.Contains(part, "..") {
			pieces := strings.SplitN(part, "..", 2)
			min, err := atoi(pieces[0])
			if err != nil {
				return nil, fmt.Errorf("invalid status code %q", part)
			}
			max, err := atoi(pieces[1])
			if err != nil {
				return nil, fmt.Errorf("invalid status code %q", part)
			}
			ranges = append(ranges, statusRange{min: min, max: max})
		} else {
			code, err := atoi(part)
			if err != nil {
				return nil, fmt.Errorf("invalid status code %q", part)
			}
			ranges = append(ranges, statusRange{min: code, max: code + 1})
		}
	}
	if len(ranges) == 0 {
		return nil, fmt.Errorf("invalid status code range")
	}
	return ranges, nil
}

func atoi(text string) (int, error) {
	var n int
	if text == "" {
		return 0, fmt.Errorf("empty")
	}
	for _, r := range text {
		if r < '0' || r > '9' {
			return 0, fmt.Errorf("bad")
		}
		n = n*10 + int(r-'0')
	}
	return n, nil
}

func accepted(status int, ranges []statusRange) bool {
	for _, r := range ranges {
		if status >= r.min && status < r.max {
			return true
		}
	}
	return false
}

func valueAfterEqual(text string) string {
	parts := strings.SplitN(text, "=", 2)
	if len(parts) == 2 {
		return parts[1]
	}
	return ""
}

func addHeader(headers map[string]string, header string) {
	name, value, ok := strings.Cut(header, ":")
	if !ok {
		return
	}
	headers[strings.TrimSpace(name)] = strings.TrimSpace(value)
}

func hasValueFlag(arg string) bool {
	flags := []string{
		"-b", "--buffer-size", "-c", "--max-connections", "--max-connections-per-host",
		"--max-response-body-size", "--max-retries", "--dns-resolver", "-r",
		"--max-redirections", "--rate-limit", "-t", "--timeout", "--proxy", "--color",
	}
	for _, flag := range flags {
		if arg == flag || strings.HasPrefix(arg, flag+"=") {
			return true
		}
	}
	return false
}

func allowedByFilters(raw string, opts options) bool {
	if len(opts.include) > 0 {
		ok := false
		for _, re := range opts.include {
			if re.MatchString(raw) {
				ok = true
				break
			}
		}
		if !ok {
			return false
		}
	}
	for _, re := range opts.exclude {
		if re.MatchString(raw) {
			return false
		}
	}
	return true
}

func sameOrigin(a, b *url.URL) bool {
	return b != nil && a.Scheme == b.Scheme && a.Host == b.Host
}

func fragmentOf(raw string) string {
	u, err := url.Parse(raw)
	if err != nil {
		return ""
	}
	return u.Fragment
}

func hasFragment(body []byte, fragment string) bool {
	quoted := regexp.QuoteMeta(fragment)
	pattern := regexp.MustCompile(`(?is)\b(?:id|name)\s*=\s*(?:"` + quoted + `"|'` + quoted + `'|` + quoted + `(?:\s|>|/))`)
	return pattern.Find(body) != nil
}

func printText(results []pageResult, verbose bool) {
	for _, result := range results {
		lines := visibleLinks(result.Links, verbose)
		if len(lines) == 0 && !verbose {
			continue
		}
		fmt.Println(result.URL)
		for _, link := range lines {
			if link.Error != "" {
				fmt.Printf("\t%s\t%s\n", link.Error, link.URL)
			} else {
				fmt.Printf("\t%d\t%s\n", link.Status, link.URL)
			}
		}
	}
}

func visibleLinks(links []linkResult, verbose bool) []linkResult {
	if verbose {
		return links
	}
	var out []linkResult
	for _, link := range links {
		if link.Error != "" {
			out = append(out, link)
		}
	}
	return out
}

func printJSON(results []pageResult, verbose bool) {
	type jsonPage struct {
		URL   string       `json:"url"`
		Links []linkResult `json:"links"`
	}
	var pages []jsonPage
	for _, result := range results {
		links := visibleLinks(result.Links, verbose)
		if len(links) == 0 && !verbose {
			continue
		}
		pages = append(pages, jsonPage{URL: result.URL, Links: links})
	}
	data, _ := json.Marshal(pages)
	fmt.Println(string(data))
}

func printJUnit(results []pageResult) {
	fmt.Println(`<?xml version="1.0" encoding="UTF-8"?>`)
	fmt.Println("<testsuites>")
	for _, result := range results {
		failures := 0
		for _, link := range result.Links {
			if link.Error != "" {
				failures++
			}
		}
		fmt.Printf("  <testsuite name=\"%s\" tests=\"%d\" failures=\"%d\" skipped=\"0\">\n", xmlEscape(result.URL), len(result.Links), failures)
		for _, link := range result.Links {
			fmt.Printf("    <testcase name=\"%s\" classname=\"%s\">", xmlEscape(link.URL), xmlEscape(result.URL))
			if link.Error != "" {
				fmt.Printf("\n      <failure message=\"%s\"></failure>\n    ", xmlEscape(link.Error))
			}
			fmt.Println("</testcase>")
		}
		fmt.Println("  </testsuite>")
	}
	fmt.Println("</testsuites>")
}

func xmlEscape(text string) string {
	var b bytes.Buffer
	_ = xml.EscapeText(&b, []byte(text))
	return b.String()
}

func printHelp() {
	fmt.Print(`Usage:
  executable [options] <url>

Application Options:
      --accepted-status-codes=<codes>       Accepted HTTP response status codes
                                            (e.g. '200..300,403') (default:
                                            200..300)
  -b, --buffer-size=<size>                  HTTP response buffer size in bytes
                                            (default: 4096)
  -c, --max-connections=<count>             Maximum number of HTTP connections
                                            (default: 512)
      --max-connections-per-host=<count>    Maximum number of HTTP connections
                                            per host (default: 512)
      --max-response-body-size=<size>       Maximum response body size to read
                                            (default: 10000000)
  -e, --exclude=<pattern>...                Exclude URLs matched with given
                                            regular expressions
  -i, --include=<pattern>...                Include URLs matched with given
                                            regular expressions
      --follow-robots-txt                   Follow robots.txt when scraping
                                            pages
      --follow-sitemap-xml                  Scrape only pages listed in
                                            sitemap.xml (deprecated)
      --header=<header>...                  Custom headers
  -f, --ignore-fragments                    Ignore URL fragments
      --max-retries=<count>                 Maximum retry count for network
                                            errors (default: 0)
      --dns-resolver=<address>              Custom DNS resolver
      --format=[text|json|junit]            Output format (default: text)
      --json                                Output results in JSON (deprecated)
      --experimental-verbose-json           Include successful results in JSON
                                            (deprecated)
      --junit                               Output results as JUnit XML file
                                            (deprecated)
  -r, --max-redirections=<count>            Maximum number of redirections
                                            (default: 64)
      --rate-limit=<rate>                   Max requests per second
  -t, --timeout=<seconds>                   Timeout for HTTP requests in
                                            seconds (default: 10)
  -v, --verbose                             Show successful results too
      --proxy=<host>                        HTTP proxy host
      --skip-tls-verification               Skip TLS certificate verification
      --one-page-only                       Only check links found in the given
                                            URL
      --color=[auto|always|never]           Color output (default: auto)
  -h, --help                                Show this help
      --version                             Show version
`)
}
