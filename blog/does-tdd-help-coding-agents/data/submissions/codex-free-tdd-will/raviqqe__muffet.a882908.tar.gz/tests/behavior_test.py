import http.server
import json
import os
import socketserver
import subprocess
import tempfile
import threading
import unittest
import xml.etree.ElementTree as ET


ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
BIN = os.path.join(ROOT, "executable")


class QuietHandler(http.server.SimpleHTTPRequestHandler):
    def log_message(self, format, *args):
        pass


class Server:
    def __init__(self, files):
        self.tmp = tempfile.TemporaryDirectory()
        for path, body in files.items():
            full = os.path.join(self.tmp.name, path.lstrip("/"))
            os.makedirs(os.path.dirname(full), exist_ok=True)
            with open(full, "wb") as f:
                f.write(body)
        handler = lambda *a, **kw: QuietHandler(*a, directory=self.tmp.name, **kw)
        self.httpd = socketserver.TCPServer(("127.0.0.1", 0), handler)
        self.thread = threading.Thread(target=self.httpd.serve_forever, daemon=True)
        self.thread.start()
        self.url = f"http://127.0.0.1:{self.httpd.server_address[1]}/"

    def close(self):
        self.httpd.shutdown()
        self.httpd.server_close()
        self.tmp.cleanup()


class MuffetBehavior(unittest.TestCase):
    def run_muffet(self, *args):
        return subprocess.run([BIN, *args], text=True, capture_output=True)

    def test_reports_broken_links_from_root_page(self):
        server = Server({
            "index.html": b'<html><body><a href="/missing.html">missing</a></body></html>',
        })
        try:
            result = self.run_muffet(server.url)
        finally:
            server.close()

        self.assertEqual(result.returncode, 1)
        self.assertEqual(result.stderr, "")
        self.assertEqual(
            result.stdout,
            f"{server.url}\n\t404\t{server.url}missing.html\n",
        )

    def test_help_and_version(self):
        help_result = self.run_muffet("--help")
        self.assertEqual(help_result.returncode, 0)
        self.assertIn("Usage:\n  executable [options] <url>\n", help_result.stdout)
        self.assertIn("--format=[text|json|junit]", help_result.stdout)

        version_result = self.run_muffet("--version")
        self.assertEqual(version_result.returncode, 0)
        self.assertEqual(version_result.stdout, "2.11.1\n")

    def test_verbose_output_and_same_host_recursion(self):
        server = Server({
            "index.html": b"""
                <html><head><link rel="stylesheet" href="/style.css"></head>
                <body><a href="/ok.html">ok</a><img src="/image.png"></body></html>
            """,
            "ok.html": b'<html><body><a href="/nested-missing.html">bad</a></body></html>',
            "style.css": b"body{}",
            "image.png": b"png",
        })
        try:
            result = self.run_muffet("--verbose", server.url)
        finally:
            server.close()

        self.assertEqual(result.returncode, 1)
        self.assertEqual(result.stderr, "")
        self.assertIn(f"{server.url}\n", result.stdout)
        self.assertIn(f"\t200\t{server.url}ok.html\n", result.stdout)
        self.assertIn(f"\t200\t{server.url}style.css\n", result.stdout)
        self.assertIn(f"\t200\t{server.url}image.png\n", result.stdout)
        self.assertIn(f"{server.url}ok.html\n\t404\t{server.url}nested-missing.html\n", result.stdout)

    def test_json_reports_missing_fragments_and_statuses(self):
        server = Server({
            "index.html": b"""
                <html><body>
                  <a href="/target.html#exists">exists</a>
                  <a href="/target.html#missing">missing</a>
                </body></html>
            """,
            "target.html": b'<html><body><section id="exists"></section></body></html>',
        })
        try:
            result = self.run_muffet("--format=json", "--verbose", server.url)
        finally:
            server.close()

        self.assertEqual(result.returncode, 1)
        payload = json.loads(result.stdout)
        self.assertEqual(payload[0]["url"], server.url)
        links = {link["url"]: link for link in payload[0]["links"]}
        self.assertEqual(links[f"{server.url}target.html#exists"]["status"], 200)
        self.assertEqual(links[f"{server.url}target.html#missing"]["error"], "id #missing not found")

    def test_filtering_accepted_statuses_and_fragment_option(self):
        server = Server({
            "index.html": b"""
                <html><body>
                  <a href="/missing.html">missing</a>
                  <a href="/kept.html">kept</a>
                  <a href="#absent">fragment</a>
                </body></html>
            """,
            "kept.html": b'<html><body><a href="/nested-missing.html">bad</a></body></html>',
        })
        try:
            result = self.run_muffet(
                "--accepted-status-codes=200..500",
                "--include=kept|missing",
                "--exclude=nested",
                "--ignore-fragments",
                "--one-page-only",
                "--verbose",
                server.url,
            )
        finally:
            server.close()

        self.assertEqual(result.returncode, 0)
        self.assertIn(f"\t404\t{server.url}missing.html\n", result.stdout)
        self.assertIn(f"\t200\t{server.url}kept.html\n", result.stdout)
        self.assertNotIn("absent", result.stdout)
        self.assertNotIn("nested-missing", result.stdout)

    def test_junit_output_contains_test_suites_and_failures(self):
        server = Server({
            "index.html": b'<html><body><a href="/missing.html">missing</a><a href="/ok.html">ok</a></body></html>',
            "ok.html": b"<html><body></body></html>",
        })
        try:
            result = self.run_muffet("--format=junit", server.url)
        finally:
            server.close()

        self.assertEqual(result.returncode, 1)
        root = ET.fromstring(result.stdout)
        self.assertEqual(root.tag, "testsuites")
        suite = root.find("testsuite")
        self.assertEqual(suite.attrib["name"], server.url)
        self.assertEqual(suite.attrib["failures"], "1")
        failure = suite.find("testcase/failure")
        self.assertEqual(failure.attrib["message"], "404")


if __name__ == "__main__":
    unittest.main()
