#!/bin/bash
set -euo pipefail
go build -o executable ./cmd/muffet
chmod +x executable
