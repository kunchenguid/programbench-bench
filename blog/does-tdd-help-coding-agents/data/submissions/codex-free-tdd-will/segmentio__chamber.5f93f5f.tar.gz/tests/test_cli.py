import os
import subprocess
import sys
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
CLI = [sys.executable, str(ROOT / "src" / "chamber.py")]


def run(args, input_data=None, env=None):
    e = os.environ.copy()
    e.update(env or {})
    return subprocess.run(CLI + args, input=input_data, text=True, capture_output=True, env=e)


class ChamberCliTests(unittest.TestCase):
    def test_version_and_null_backend_core_outputs(self):
        p = run(["version"])
        self.assertEqual(p.returncode, 0)
        self.assertEqual(p.stdout, "chamber dev\n")
        self.assertEqual(p.stderr, "")

        p = run(["-b", "null", "list", "svc"])
        self.assertEqual(p.returncode, 0)
        self.assertEqual(p.stdout, "Key\tVersion\t\tLastModified\tUser\n")
        self.assertEqual(p.stderr, "")

        p = run(["-b", "null", "read", "svc", "key"])
        self.assertEqual(p.returncode, 1)
        self.assertEqual(p.stdout, "")
        self.assertEqual(p.stderr, "Error: Failed to read: Not implemented for Null Store\n")

    def test_null_backend_empty_data_and_exec(self):
        cases = [
            (["-b", "null", "env", "svc"], ""),
            (["-b", "null", "export", "svc"], "{}\n"),
            (["-b", "null", "export", "-f", "yaml", "svc"], "{}\n"),
            (["-b", "null", "export", "-f", "dotenv", "svc"], ""),
            (["-b", "null", "list-services", "svc"], "Service\n"),
            (["-b", "null", "find", "key"], "Service\n"),
            (["-b", "null", "history", "svc", "key"], "Event\tVersion\t\tDate\tUser\n"),
        ]
        for args, out in cases:
            with self.subTest(args=args):
                p = run(args)
                self.assertEqual(p.returncode, 0)
                self.assertEqual(p.stdout, out)
                self.assertEqual(p.stderr, "")

        p = run(["-b", "null", "exec", "--pristine", "svc", "--", "env"])
        self.assertEqual(p.returncode, 0)
        self.assertEqual(p.stdout, "")
        self.assertEqual(p.stderr, "")

        p = run(["-b", "null", "exec", "--strict", "svc", "--", "env"], env={"FOO": "chamberme"})
        self.assertEqual(p.returncode, 1)
        self.assertEqual(p.stderr, "Error: parent env was expecting FOO=chamberme, but was not in store\n")

    def test_tags_import_arity_and_help_surface(self):
        for args, message in [
            (["-b", "null", "tag", "read", "svc", "key"], "Failed to read tags: Not implemented for Null Store"),
            (["-b", "null", "tag", "write", "svc", "key", "a=b"], "Failed to write tags: Not implemented for Null Store"),
            (["-b", "null", "tag", "delete", "svc", "key", "a"], "Failed to delete tags: Not implemented for Null Store"),
            (["-b", "null", "import", "svc", "-"], "Failed to write secret: Write is not implemented for Null Store"),
        ]:
            with self.subTest(args=args):
                p = run(args, input_data='{"a":"b"}')
                self.assertEqual(p.returncode, 1)
                self.assertEqual(p.stdout, "")
                self.assertEqual(p.stderr, f"Error: {message}\n")

        p = run(["-b", "null", "export"])
        self.assertEqual(p.returncode, 1)
        self.assertIn("Error: requires at least 1 arg(s), only received 0\nUsage:\n  chamber export <service...> [flags]", p.stderr)

        p = run(["read", "--help"])
        self.assertEqual(p.returncode, 0)
        self.assertIn("Read a specific secret from the parameter store\n\nUsage:\n  chamber read <service> <key> [flags]", p.stdout)


if __name__ == "__main__":
    unittest.main()
