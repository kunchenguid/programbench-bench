#!/bin/bash
set -e
cp src/chamber.py executable
chmod +x executable
