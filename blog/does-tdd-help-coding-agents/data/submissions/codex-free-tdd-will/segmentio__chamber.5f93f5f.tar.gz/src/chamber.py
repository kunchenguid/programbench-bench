#!/usr/bin/env python3
import os
import subprocess
import sys


NULL_ERRORS = {
    "read": "Failed to read: Not implemented for Null Store",
    "write": "Write is not implemented for Null Store",
    "delete": "Not implemented for Null Store",
}


def parse_global(argv):
    backend = os.environ.get("CHAMBER_SECRET_BACKEND", "ssm")
    rest = []
    i = 0
    while i < len(argv):
        a = argv[i]
        if a in ("-b", "--backend") and i + 1 < len(argv):
            backend = argv[i + 1]
            i += 2
        elif a.startswith("--backend="):
            backend = a.split("=", 1)[1]
            i += 1
        elif a in ("-r", "--retries", "--retry-mode", "--backend-s3-bucket", "--kms-key-alias") and i + 1 < len(argv):
            i += 2
        elif a == "--verbose":
            i += 1
        else:
            rest.append(a)
            i += 1
    return backend.lower(), rest


def err(msg):
    sys.stderr.write(f"Error: {msg}\n")
    return 1


def main(argv):
    backend, args = parse_global(argv)
    if not args or args[0] in ("-h", "--help"):
        print(ROOT_HELP)
        return 0
    if args[0] == "help":
        topic = args[1] if len(args) > 1 else ""
        print(help_text(topic) if topic else ROOT_HELP)
        return 0
    cmd = args[0]
    rest = args[1:]
    if any(a in ("-h", "--help") for a in rest):
        print(help_text(cmd))
        return 0
    if cmd == "version":
        print("chamber dev")
        return 0
    if backend not in {"null", "ssm", "secretsmanager", "s3", "s3-kms"}:
        return err(f"Failed to get secret store: invalid backend `{backend.upper()}`")
    if backend in {"s3", "s3-kms"} and not os.environ.get("CHAMBER_S3_BUCKET"):
        return err("Failed to get secret store: Must set bucket for s3 backend")
    if cmd == "list" and backend == "null":
        if len(rest) != 1:
            return err(f"accepts 1 arg(s), received {len(rest)}")
        print("Key\tVersion\t\tLastModified\tUser")
        return 0
    if cmd == "env" and backend == "null":
        return 0
    if cmd == "export" and backend == "null":
        fmt, services = parse_export(rest)
        if not services:
            return usage_error("requires at least 1 arg(s), only received 0", "export")
        if fmt not in {"json", "yaml", "dotenv", "csv", "tsv", "java-properties", "tfvars"}:
            return err(f"Unable to export parameters: Unsupported export format: {fmt}")
        if fmt in {"json", "yaml"}:
            print("{}")
        return 0
    if cmd == "list-services" and backend == "null":
        print("Service")
        return 0
    if cmd == "find" and backend == "null":
        print("Service")
        return 0
    if cmd == "history" and backend == "null":
        print("Event\tVersion\t\tDate\tUser")
        return 0
    if cmd == "exec" and backend == "null":
        return run_exec(rest)
    if cmd == "read" and backend == "null":
        rest = strip_flags(rest, {"-q", "--quiet"}, {"-v", "--version"})
        if len(rest) != 2:
            return usage_error(f"accepts 2 arg(s), received {len(rest)}", "read")
        return err(NULL_ERRORS["read"])
    if cmd == "write" and backend == "null":
        return err(NULL_ERRORS["write"])
    if cmd == "delete" and backend == "null":
        return err(NULL_ERRORS["delete"])
    if cmd == "import" and backend == "null":
        rest = strip_flags(rest, {"--normalize-keys"}, set())
        if len(rest) != 2:
            return usage_error(f"accepts 2 arg(s), received {len(rest)}", "import")
        if rest[1] != "-" and not os.path.exists(rest[1]):
            return err(f"Failed to open file: open {rest[1]}: no such file or directory")
        if rest[1] == "-":
            sys.stdin.read()
        return err("Failed to write secret: Write is not implemented for Null Store")
    if cmd == "tag" and backend == "null":
        return run_tag(rest)
    return err(f"unknown command \"{cmd}\" for \"chamber\"")


def parse_export(args):
    fmt = "json"
    services = []
    i = 0
    while i < len(args):
        if args[i] in ("-f", "--format") and i + 1 < len(args):
            fmt = args[i + 1]
            i += 2
        elif args[i].startswith("--format="):
            fmt = args[i].split("=", 1)[1]
            i += 1
        elif args[i] in ("-o", "--output-file") and i + 1 < len(args):
            i += 2
        else:
            services.append(args[i])
            i += 1
    return fmt, services


def run_exec(args):
    pristine = False
    strict = False
    strict_value = "chamberme"
    i = 0
    while i < len(args) and args[i] != "--":
        if args[i] == "--pristine":
            pristine = True
            i += 1
        elif args[i] == "--strict":
            strict = True
            i += 1
        elif args[i] == "--strict-value" and i + 1 < len(args):
            strict_value = args[i + 1]
            i += 2
        else:
            i += 1
    command = args[i + 1 :] if i < len(args) and args[i] == "--" else []
    if strict:
        for k, v in os.environ.items():
            if v == strict_value:
                return err(f"parent env was expecting {k}={strict_value}, but was not in store")
    if not command:
        return 0
    envp = {} if pristine else os.environ.copy()
    try:
        p = subprocess.run(command, env=envp)
    except FileNotFoundError:
        return 1
    return p.returncode


def strip_flags(args, bool_flags, value_flags):
    out = []
    i = 0
    while i < len(args):
        a = args[i]
        if a == "--":
            out.extend(args[i + 1 :])
            break
        if a in bool_flags:
            i += 1
        elif a in value_flags and i + 1 < len(args):
            i += 2
        else:
            out.append(a)
            i += 1
    return out


def usage_error(message, topic):
    sys.stderr.write(f"Error: {message}\n")
    text = help_text(topic)
    usage = text[text.find("Usage:") :] if "Usage:" in text else text
    sys.stderr.write(usage)
    if not usage.endswith("\n"):
        sys.stderr.write("\n")
    return 1


def run_tag(args):
    if not args or args[0] in ("-h", "--help"):
        print(TAG_HELP)
        return 0
    sub = args[0]
    rest = args[1:]
    if any(a in ("-h", "--help") for a in rest):
        print(help_text(f"tag {sub}"))
        return 0
    if sub == "read":
        if len(rest) != 2:
            return usage_error(f"accepts 2 arg(s), received {len(rest)}", "tag read")
        return err("Failed to read tags: Not implemented for Null Store")
    if sub == "write":
        rest = strip_flags(rest, {"--delete-other-tags"}, set())
        if len(rest) < 3:
            return usage_error(f"requires at least 3 arg(s), only received {len(rest)}", "tag write")
        return err("Failed to write tags: Not implemented for Null Store")
    if sub == "delete":
        if len(rest) < 3:
            return usage_error(f"requires at least 3 arg(s), only received {len(rest)}", "tag delete")
        return err("Failed to delete tags: Not implemented for Null Store")
    return err(f"unknown command \"{sub}\" for \"chamber tag\"")


def help_text(topic):
    return HELP_TEXTS.get(topic, ROOT_HELP)


ROOT_HELP = """CLI for storing secrets

Usage:
  chamber [command]

Available Commands:
  completion    Generate the autocompletion script for the specified shell
  delete        Delete a secret, including all versions
  env           Print the secrets from the parameter store in a format to export as environment variables
  exec          Executes a command with secrets loaded into the environment
  export        Exports parameters in the specified format
  find          Find the given secret across all services
  help          Help about any command
  history       View the history of a secret
  import        import secrets from json or yaml
  list          List the secrets set for a service
  list-services List services
  read          Read a specific secret from the parameter store
  tag           work with tags on secrets
  version       print version
  write         write a secret

Flags:
  -b, --backend string             Backend to use; AKA $CHAMBER_SECRET_BACKEND
                                   	null: no-op
                                   	ssm: SSM Parameter Store
                                   	secretsmanager: Secrets Manager
                                   	s3: S3; requires --backend-s3-bucket
                                   	s3-kms: S3 using AWS-KMS encryption; requires --backend-s3-bucket and --kms-key-alias set (if you want to write or delete keys). (default "ssm")
      --backend-s3-bucket string   bucket for S3 backend; AKA $CHAMBER_S3_BUCKET
  -h, --help                       help for chamber
      --kms-key-alias string       KMS Key Alias for writing and deleting secrets; AKA $CHAMBER_KMS_KEY_ALIAS. This option is currently only supported for the S3-KMS backend. (default "alias/parameter_store_key")
  -r, --retries int                For SSM or Secrets Manager, the number of retries we'll make before giving up; AKA $CHAMBER_RETRIES (default 10)
      --retry-mode string          For SSM, the model used to retry requests
                                     standard
                                     adaptive (default "standard")
      --verbose                    Print more information to STDERR

Use "chamber [command] --help" for more information about a command."""

GLOBAL_FLAGS = """Global Flags:
  -b, --backend string             Backend to use; AKA $CHAMBER_SECRET_BACKEND
                                   \tnull: no-op
                                   \tssm: SSM Parameter Store
                                   \tsecretsmanager: Secrets Manager
                                   \ts3: S3; requires --backend-s3-bucket
                                   \ts3-kms: S3 using AWS-KMS encryption; requires --backend-s3-bucket and --kms-key-alias set (if you want to write or delete keys). (default "ssm")
      --backend-s3-bucket string   bucket for S3 backend; AKA $CHAMBER_S3_BUCKET
      --kms-key-alias string       KMS Key Alias for writing and deleting secrets; AKA $CHAMBER_KMS_KEY_ALIAS. This option is currently only supported for the S3-KMS backend. (default "alias/parameter_store_key")
  -r, --retries int                For SSM or Secrets Manager, the number of retries we'll make before giving up; AKA $CHAMBER_RETRIES (default 10)
      --retry-mode string          For SSM, the model used to retry requests
                                     standard
                                     adaptive (default "standard")
      --verbose                    Print more information to STDERR"""

HELP_TEXTS = {
    "read": f"""Read a specific secret from the parameter store

Usage:
  chamber read <service> <key> [flags]

Flags:
  -h, --help          help for read
  -q, --quiet         Only print the secret
  -v, --version int   The version number of the secret. Defaults to latest. (default -1)

{GLOBAL_FLAGS}""",
    "export": f"""Exports parameters in the specified format

Usage:
  chamber export <service...> [flags]

Flags:
  -f, --format string        Output format (json, yaml, java-properties, csv, tsv, dotenv, tfvars) (default "json")
  -o, --output-file string   Output file (default is standard output)
  -h, --help                 help for export

{GLOBAL_FLAGS}""",
    "import": f"""import secrets from json or yaml

Usage:
  chamber import <service> <file|-> [flags]

Flags:
  -h, --help                           help for import
      --normalize-keys chamber write   Normalize keys to match how chamber write would handle them. If not specified, keys will be written exactly how they are defined in the import source.

{GLOBAL_FLAGS}""",
}

TAG_HELP = f"""work with tags on secrets

Usage:
  chamber tag [command]

Available Commands:
  delete      Delete tags for a specific secret
  read        Read tags for a specific secret
  write       Write tags for a specific secret

Flags:
  -h, --help   help for tag

{GLOBAL_FLAGS}

Use "chamber tag [command] --help" for more information about a command."""

HELP_TEXTS.update({
    "tag": TAG_HELP,
    "tag read": f"""Read tags for a specific secret

Usage:
  chamber tag read <service> <key> [flags]

Flags:
  -h, --help   help for read

{GLOBAL_FLAGS}""",
    "tag write": f"""Write tags for a specific secret

Usage:
  chamber tag write <service> <key> <tag>... [flags]

Flags:
      --delete-other-tags   Delete tags not specified in the command
  -h, --help                help for write

{GLOBAL_FLAGS}""",
    "tag delete": f"""Delete tags for a specific secret

Usage:
  chamber tag delete <service> <key> <tag key>... [flags]

Flags:
  -h, --help   help for delete

{GLOBAL_FLAGS}""",
})


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
