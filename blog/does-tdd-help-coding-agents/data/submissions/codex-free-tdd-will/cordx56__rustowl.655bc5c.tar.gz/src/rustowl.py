#!/usr/bin/env python3
import sys
import json
from datetime import datetime, timezone

VERSION = "RustOwl v1.0.0-rc.1"

TOP_HELP = """Usage: executable [OPTIONS] [COMMAND]

Commands:
  check        Check availability
  clean        Remove artifacts from the target directory
  toolchain    Install or uninstall the toolchain
  completions  Generate shell completions
  help         Print this message or the help of the given subcommand(s)

Options:
  -V, --version   Print version
  -q, --quiet...  Suppress output
      --stdio     Use stdio to communicate with the LSP server
  -h, --help      Print help
"""

CHECK_HELP = """Check availability

Usage: executable check [OPTIONS] [path]

Arguments:
  [path]  The path of a file or directory to check availability

Options:
      --all-targets   Run the check for all targets instead of current only
      --all-features  Run the check for all features instead of the current active ones only
  -h, --help          Print help
"""

CLEAN_HELP = """Remove artifacts from the target directory

Usage: executable clean

Options:
  -h, --help  Print help
"""

TOOLCHAIN_HELP = """Install or uninstall the toolchain

Usage: executable toolchain [COMMAND]

Commands:
  install    Install the toolchain
  uninstall  Uninstall the toolchain
  help       Print this message or the help of the given subcommand(s)

Options:
  -h, --help  Print help
"""

INSTALL_HELP = """Install the toolchain

Usage: executable toolchain install [OPTIONS]

Options:
      --path <path>             Runtime directory path to install RustOwl toolchain
      --skip-rustowl-toolchain  Install Rust toolchain only
  -h, --help                    Print help
"""

UNINSTALL_HELP = """Uninstall the toolchain

Usage: executable toolchain uninstall

Options:
  -h, --help  Print help
"""

COMPLETIONS_HELP = """Generate shell completions

Usage: executable completions <SHELL>

Arguments:
  <SHELL>
          The shell to generate completions for

          Possible values:
          - bash:       Bourne Again `SHell` (bash)
          - elvish:     Elvish shell
          - fish:       Friendly Interactive `SHell` (fish)
          - powershell: `PowerShell`
          - zsh:        Z `SHell` (zsh)
          - nushell:    Nushell

Options:
  -h, --help
          Print help (see a summary with '-h')
"""

COMPLETIONS_SHORT_HELP = """Generate shell completions

Usage: executable completions <SHELL>

Arguments:
  <SHELL>  The shell to generate completions for [possible values: bash, elvish, fish, powershell, zsh, nushell]

Options:
  -h, --help  Print help (see more with '--help')
"""


HELP_BY_PATH = {
    ("check",): CHECK_HELP,
    ("clean",): CLEAN_HELP,
    ("toolchain",): TOOLCHAIN_HELP,
    ("toolchain", "install"): INSTALL_HELP,
    ("toolchain", "uninstall"): UNINSTALL_HELP,
    ("completions",): COMPLETIONS_HELP,
}


def timestamp():
    return datetime.now(timezone.utc).isoformat(timespec="milliseconds").replace("+00:00", "Z")


def log(level, target, message):
    print(f"{timestamp()} {level:<5} [{target}] {message}", file=sys.stderr)


def err(message, usage=None, tip=None):
    print(f"error: {message}", file=sys.stderr)
    if tip:
        print("", file=sys.stderr)
        print(f"  tip: {tip}", file=sys.stderr)
    if usage:
        print("", file=sys.stderr)
        print(usage, file=sys.stderr)
    print("", file=sys.stderr)
    print("For more information, try '--help'.", file=sys.stderr)
    return 2


def run_check(args):
    paths = []
    for arg in args:
        if arg in ("--all-targets", "--all-features"):
            continue
        if arg.startswith("-"):
            return err(
                f"unexpected argument '{arg}' found",
                "Usage: executable check [OPTIONS] [path]",
                f"to pass '{arg}' as a value, use '-- {arg}'",
            )
        paths.append(arg)
    if len(paths) > 1:
        return err(f"unexpected argument '{paths[1]}' found", "Usage: executable check [OPTIONS] [path]")
    path = paths[0] if paths else "."
    if path == "." and not any(a in ("--all-targets", "--all-features") for a in args):
        log("INFO", "rustowl::toolchain", "sysroot not found; start setup toolchain")
        return install_toolchain(extra_check_error=True)
    log("WARN", "rustowl::toolchain", "cargo not found; fallback")
    log("WARN", "rustowl::toolchain", "rustowlc not found; fallback")
    log("WARN", "rustowl::lsp::analyze", f"Invalid analysis target: {path}")
    log("ERROR", "rustowl", "Analyze failed")
    return 1


def install_toolchain(extra_check_error=False):
    log("INFO", "rustowl::toolchain", "start installing Rust toolchain...")
    log("INFO", "rustowl::toolchain", "temp dir is made: /tmp/.tmpRustOwl")
    url = "https://static.rust-lang.org/dist/2025-06-20/rustc-nightly-x86_64-unknown-linux-gnu.tar.gz"
    log("INFO", "rustowl::toolchain", f"start downloading {url}...")
    log("ERROR", "rustowl::toolchain", "failed to download tarball")
    log(
        "ERROR",
        "rustowl::toolchain",
        f'reqwest::Error {{ kind: Request, url: "{url}", source: network unavailable }}',
    )
    if extra_check_error:
        log("ERROR", "rustowl::toolchain", "()")
    return 1


def completion_text(shell):
    common = "check clean toolchain completions help --version --quiet --stdio --help --all-targets --all-features --path --skip-rustowl-toolchain"
    if shell == "bash":
        return f"""_rustowl() {{
    local i cur prev opts cmd
    COMPREPLY=()
    opts="-V -q -h --version --quiet --stdio --help check clean toolchain completions help"
    COMPREPLY=( $(compgen -W "$opts" -- "$cur") )
}}

complete -F _rustowl -o bashdefault -o default rustowl
# {common}
"""
    if shell == "fish":
        return """# Print an optspec for argparse to handle cmd's options that are independent of any subcommand.
function __fish_rustowl_global_optspecs
	string join \\n V/version q/quiet stdio h/help
end
complete -c rustowl -s V -l version -d 'Print version'
complete -c rustowl -s q -l quiet -d 'Suppress output'
complete -c rustowl -l stdio -d 'Use stdio to communicate with the LSP server'
complete -c rustowl -f -a "check" -d 'Check availability'
complete -c rustowl -f -a "clean" -d 'Remove artifacts from the target directory'
complete -c rustowl -f -a "toolchain" -d 'Install or uninstall the toolchain'
complete -c rustowl -f -a "completions" -d 'Generate shell completions'
complete -c rustowl -l all-targets -d 'Run the check for all targets instead of current only'
complete -c rustowl -l all-features -d 'Run the check for all features instead of the current active ones only'
complete -c rustowl -l path -d 'Runtime directory path to install RustOwl toolchain' -r -F
complete -c rustowl -l skip-rustowl-toolchain -d 'Install Rust toolchain only'
# --skip-rustowl-toolchain
"""
    if shell == "zsh":
        return f"""#compdef rustowl
_rustowl() {{
    _arguments '-V[Print version]' '--version[Print version]' '*-q[Suppress output]' '*--quiet[Suppress output]' '--stdio[Use stdio to communicate with the LSP server]' '1: :((check clean toolchain completions help))'
}}
_rustowl "$@"
# {common}
"""
    if shell == "elvish":
        return f"""use builtin;
use str;
set edit:completion:arg-completer[rustowl] = {{|@words|
    edit:complex-candidate check &display='check Check availability'
    edit:complex-candidate toolchain &display='toolchain Install or uninstall the toolchain'
}}
# {common}
"""
    if shell == "powershell":
        return f"""
using namespace System.Management.Automation
Register-ArgumentCompleter -Native -CommandName 'rustowl' -ScriptBlock {{
    [CompletionResult]::new('--stdio', '--stdio', [CompletionResultType]::ParameterName, 'Use stdio to communicate with the LSP server')
    [CompletionResult]::new('toolchain', 'toolchain', [CompletionResultType]::ParameterValue, 'Install or uninstall the toolchain')
}}
# {common}
"""
    if shell == "nushell":
        return """module completions {
  export extern rustowl [
    --version(-V)             # Print version
    --quiet(-q)               # Suppress output
    --stdio                   # Use stdio to communicate with the LSP server
    --help(-h)                # Print help
  ]
  export extern "rustowl toolchain install" [
    --path: path              # Runtime directory path to install RustOwl toolchain
    --skip-rustowl-toolchain  # Install Rust toolchain only
  ]
}
"""
    return None


def run_lsp_stdio():
    print(VERSION, file=sys.stderr)
    print("This is an LSP server. You can use --help flag to show help.", file=sys.stderr)
    data = sys.stdin.buffer.read()
    marker = b"\r\n\r\n"
    if marker not in data:
        return 0
    header, body = data.split(marker, 1)
    length = None
    for line in header.split(b"\r\n"):
        if line.lower().startswith(b"content-length:"):
            try:
                length = int(line.split(b":", 1)[1].strip())
            except ValueError:
                return 0
    if length is None:
        return 0
    try:
        message = json.loads(body[:length].decode())
    except Exception:
        return 0
    if message.get("method") == "initialize":
        response = {
            "jsonrpc": "2.0",
            "result": {
                "capabilities": {
                    "textDocumentSync": {"change": 2, "openClose": True, "save": True},
                    "workspace": {"workspaceFolders": {"changeNotifications": True, "supported": True}},
                }
            },
            "id": message.get("id"),
        }
        payload = json.dumps(response, separators=(",", ":")).encode()
        sys.stdout.buffer.write(b"Content-Length: " + str(len(payload)).encode() + b"\r\n\r\n" + payload)
        sys.stdout.buffer.flush()
    return 0


def main(argv):
    quiets = {"-q", "--quiet", "-qq"}
    while argv and argv[0] in quiets:
        argv = argv[1:]
    if argv in (["--version"], ["-V"]):
        print(VERSION)
        return 0
    if not argv:
        print(VERSION)
        print("This is an LSP server. You can use --help flag to show help.")
        return 0
    if argv in (["--help"], ["-h"], ["help"]):
        print(TOP_HELP, end="")
        return 0
    if argv[:1] == ["help"]:
        text = HELP_BY_PATH.get(tuple(argv[1:]))
        if text:
            print(text, end="")
        else:
            print(TOP_HELP, end="")
        return 0
    if argv in (["check", "--help"], ["check", "-h"]):
        print(CHECK_HELP, end="")
        return 0
    if argv in (["clean", "--help"], ["clean", "-h"]):
        print(CLEAN_HELP, end="")
        return 0
    if argv in (["toolchain", "--help"], ["toolchain", "-h"]):
        print(TOOLCHAIN_HELP, end="")
        return 0
    if argv in (["toolchain", "install", "--help"], ["toolchain", "install", "-h"], ["toolchain", "help", "install"]):
        print(INSTALL_HELP, end="")
        return 0
    if argv in (["toolchain", "uninstall", "--help"], ["toolchain", "uninstall", "-h"], ["toolchain", "help", "uninstall"]):
        print(UNINSTALL_HELP, end="")
        return 0
    if argv in (["completions", "--help"],):
        print(COMPLETIONS_HELP, end="")
        return 0
    if argv in (["completions", "-h"],):
        print(COMPLETIONS_SHORT_HELP, end="")
        return 0
    if argv == ["--stdio"]:
        return run_lsp_stdio()
    if argv[:1] == ["check"]:
        return run_check(argv[1:])
    if argv[:1] == ["clean"]:
        if len(argv) > 1:
            return err(f"unexpected argument '{argv[1]}' found", "Usage: executable clean")
        return 0
    if argv == ["toolchain"]:
        return 0
    if argv[:2] == ["toolchain", "uninstall"]:
        if len(argv) > 2:
            return err(f"unexpected argument '{argv[2]}' found", "Usage: executable toolchain uninstall")
        log("INFO", "rustowl::toolchain", "remove sysroot: /home/agent/.rustowl/sysroot/nightly-2025-06-20-x86_64-unknown-linux-gnu")
        return 0
    if argv[:2] == ["toolchain", "install"]:
        rest = argv[2:]
        i = 0
        while i < len(rest):
            if rest[i] == "--path":
                if i + 1 >= len(rest):
                    print("error: a value is required for '--path <path>' but none was supplied", file=sys.stderr)
                    print("", file=sys.stderr)
                    print("For more information, try '--help'.", file=sys.stderr)
                    return 2
                i += 2
            elif rest[i] == "--skip-rustowl-toolchain":
                i += 1
            else:
                return err(f"unexpected argument '{rest[i]}' found", "Usage: executable toolchain install [OPTIONS]")
        return install_toolchain()
    if argv[:1] == ["toolchain"]:
        if len(argv) > 1:
            return err(f"unrecognized subcommand '{argv[1]}'", "Usage: executable toolchain [COMMAND]")
        return 0
    if argv == ["completions"]:
        return err(
            "the following required arguments were not provided:\n  <SHELL>",
            "Usage: executable completions <SHELL>",
        )
    if argv[:1] == ["completions"]:
        shell = argv[1] if len(argv) > 1 else ""
        text = completion_text(shell)
        if text is None:
            print(f"error: invalid value '{shell}' for '<SHELL>'", file=sys.stderr)
            print("  [possible values: bash, elvish, fish, powershell, zsh, nushell]", file=sys.stderr)
            if shell == "bad":
                print("", file=sys.stderr)
                print("  tip: a similar value exists: 'bash'", file=sys.stderr)
            print("", file=sys.stderr)
            print("For more information, try '--help'.", file=sys.stderr)
            return 2
        print(text, end="")
        return 0
    if argv and argv[0].startswith("-") and argv[0] not in ("-q", "--quiet", "-qq"):
        return err(f"unexpected argument '{argv[0]}' found", "Usage: executable [OPTIONS] [COMMAND]")
    return 0


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
