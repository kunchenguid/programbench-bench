import subprocess
import sys
import unittest
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
APP = [sys.executable, str(ROOT / "src" / "rustowl.py")]


def run_app(*args, input_bytes=None, timeout=3):
    return subprocess.run(
        APP + list(args),
        input=input_bytes,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        timeout=timeout,
        check=False,
    )


class CliTests(unittest.TestCase):
    def test_version_matches_documented_release(self):
        result = run_app("--version")
        self.assertEqual(result.returncode, 0)
        self.assertEqual(result.stdout.decode(), "RustOwl v1.0.0-rc.1\n")
        self.assertEqual(result.stderr.decode(), "")

    def test_top_level_help_and_no_args_banner(self):
        help_result = run_app("--help")
        self.assertEqual(help_result.returncode, 0)
        self.assertIn("Usage: executable [OPTIONS] [COMMAND]\n", help_result.stdout.decode())
        self.assertIn("  check        Check availability\n", help_result.stdout.decode())
        self.assertIn("      --stdio     Use stdio to communicate with the LSP server\n", help_result.stdout.decode())

        banner = run_app()
        self.assertEqual(banner.returncode, 0)
        self.assertEqual(
            banner.stdout.decode(),
            "RustOwl v1.0.0-rc.1\n"
            "This is an LSP server. You can use --help flag to show help.\n",
        )

    def test_subcommand_help_texts(self):
        check = run_app("check", "--help")
        self.assertEqual(check.returncode, 0)
        self.assertIn("Check availability\n\nUsage: executable check [OPTIONS] [path]\n", check.stdout.decode())
        self.assertIn("      --all-targets   Run the check for all targets instead of current only\n", check.stdout.decode())

        install = run_app("toolchain", "install", "--help")
        self.assertEqual(install.returncode, 0)
        self.assertIn("Install the toolchain\n\nUsage: executable toolchain install [OPTIONS]\n", install.stdout.decode())
        self.assertIn("      --skip-rustowl-toolchain  Install Rust toolchain only\n", install.stdout.decode())

        comp_short = run_app("completions", "-h")
        self.assertEqual(comp_short.returncode, 0)
        self.assertIn("<SHELL>  The shell to generate completions for [possible values: bash, elvish, fish, powershell, zsh, nushell]", comp_short.stdout.decode())

    def test_errors_and_check_failure_path_match_cli_contract(self):
        bad = run_app("--bad")
        self.assertEqual(bad.returncode, 2)
        self.assertIn("error: unexpected argument '--bad' found\n\nUsage: executable [OPTIONS] [COMMAND]\n", bad.stderr.decode())
        self.assertEqual(bad.stdout.decode(), "")

        missing_shell = run_app("completions")
        self.assertEqual(missing_shell.returncode, 2)
        self.assertIn("error: the following required arguments were not provided:\n  <SHELL>\n", missing_shell.stderr.decode())

        check = run_app("check", "README.md")
        self.assertEqual(check.returncode, 1)
        self.assertIn("WARN  [rustowl::toolchain] cargo not found; fallback", check.stderr.decode())
        self.assertIn("WARN  [rustowl::lsp::analyze] Invalid analysis target: README.md", check.stderr.decode())
        self.assertIn("ERROR [rustowl] Analyze failed", check.stderr.decode())

    def test_completion_generation_and_invalid_shell(self):
        bash = run_app("completions", "bash")
        self.assertEqual(bash.returncode, 0)
        self.assertIn("_rustowl()", bash.stdout.decode())
        self.assertIn("--stdio", bash.stdout.decode())
        self.assertIn("toolchain", bash.stdout.decode())

        fish = run_app("completions", "fish")
        self.assertEqual(fish.returncode, 0)
        self.assertIn("complete -c rustowl", fish.stdout.decode())
        self.assertIn("--skip-rustowl-toolchain", fish.stdout.decode())

        bad = run_app("completions", "bad")
        self.assertEqual(bad.returncode, 2)
        self.assertIn("error: invalid value 'bad' for '<SHELL>'", bad.stderr.decode())
        self.assertIn("[possible values: bash, elvish, fish, powershell, zsh, nushell]", bad.stderr.decode())

    def test_toolchain_clean_and_lsp_initialize(self):
        clean = run_app("clean")
        self.assertEqual(clean.returncode, 0)
        self.assertEqual(clean.stdout.decode(), "")

        uninstall = run_app("toolchain", "uninstall")
        self.assertEqual(uninstall.returncode, 0)
        self.assertIn("INFO  [rustowl::toolchain] remove sysroot:", uninstall.stderr.decode())

        install = run_app("toolchain", "install")
        self.assertEqual(install.returncode, 1)
        self.assertIn("INFO  [rustowl::toolchain] start installing Rust toolchain...", install.stderr.decode())
        self.assertIn("ERROR [rustowl::toolchain] failed to download tarball", install.stderr.decode())

        body = json.dumps(
            {"jsonrpc": "2.0", "id": 1, "method": "initialize", "params": {"capabilities": {}, "rootUri": None}},
            separators=(",", ":"),
        ).encode()
        lsp = run_app("--stdio", input_bytes=b"Content-Length: " + str(len(body)).encode() + b"\r\n\r\n" + body)
        self.assertEqual(lsp.returncode, 0)
        self.assertIn(b"Content-Length: ", lsp.stdout)
        self.assertIn(b'"textDocumentSync":{"change":2,"openClose":true,"save":true}', lsp.stdout)
        self.assertIn(b"RustOwl v1.0.0-rc.1\nThis is an LSP server.", lsp.stderr)


if __name__ == "__main__":
    unittest.main()
