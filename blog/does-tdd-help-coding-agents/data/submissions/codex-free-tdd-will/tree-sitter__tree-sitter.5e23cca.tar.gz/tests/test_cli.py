import os
import subprocess
import tempfile
import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
EXE = ROOT / "executable"


class CliTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        subprocess.run(["bash", "compile.sh"], cwd=ROOT, check=True)

    def run_cli(self, *args, env=None, cwd=None):
        merged_env = os.environ.copy()
        if env:
            merged_env.update(env)
        return subprocess.run(
            [str(EXE), *args],
            cwd=cwd or ROOT,
            env=merged_env,
            text=True,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
        )

    def test_version_flag_prints_tree_sitter_version(self):
        result = self.run_cli("--version")
        self.assertEqual(result.returncode, 0)
        self.assertEqual(result.stdout, "tree-sitter 0.27.0\n")
        self.assertEqual(result.stderr, "")

    def test_no_arguments_prints_help_to_stderr_and_exits_2(self):
        result = self.run_cli()
        self.assertEqual(result.returncode, 2)
        self.assertEqual(result.stdout, "")
        self.assertIn("Usage: executable <COMMAND>", result.stderr)
        self.assertIn("  parse           Parse files", result.stderr)

    def test_init_config_writes_default_config_under_home(self):
        with tempfile.TemporaryDirectory() as home:
            result = self.run_cli("init-config", env={"HOME": home})
            config = Path(home) / ".config" / "tree-sitter" / "config.json"
            self.assertEqual(result.returncode, 0)
            self.assertEqual(result.stdout, "")
            self.assertEqual(
                result.stderr,
                f"Saved initial configuration to {config}\n",
            )
            text = config.read_text()
            self.assertIn('"parser-directories"', text)
            self.assertIn(f'"{home}/github"', text)
            self.assertIn('"variable.parameter"', text)

    def test_existing_config_is_refused(self):
        with tempfile.TemporaryDirectory() as home:
            config = Path(home) / ".config" / "tree-sitter" / "config.json"
            config.parent.mkdir(parents=True)
            config.write_text("old")
            result = self.run_cli("init-config", env={"HOME": home})
            self.assertEqual(result.returncode, 1)
            self.assertEqual(config.read_text(), "old")
            self.assertIn(f"Remove your existing config file first: {config}", result.stderr)

    def test_parse_without_paths_reports_no_language(self):
        with tempfile.TemporaryDirectory() as home:
            result = self.run_cli("parse", env={"HOME": home})
            self.assertEqual(result.returncode, 1)
            self.assertEqual(result.stdout, "\n")
            self.assertIn("Warning:", result.stderr)
            self.assertIn("No language found", result.stderr)

    def test_unknown_subcommand_matches_clap_style_error(self):
        result = self.run_cli("bogus")
        self.assertEqual(result.returncode, 2)
        self.assertEqual(result.stdout, "")
        self.assertIn("error: unrecognized subcommand 'bogus'", result.stderr)
        self.assertIn("Usage: executable <COMMAND>", result.stderr)

    def test_parse_help_lists_observed_options(self):
        result = self.run_cli("parse", "--help")
        self.assertEqual(result.returncode, 0)
        self.assertIn("Usage: executable parse [OPTIONS] [PATHS]...", result.stdout)
        self.assertIn("--json-summary", result.stdout)
        self.assertEqual(result.stderr, "")

    def test_version_reads_tree_sitter_json_metadata(self):
        with tempfile.TemporaryDirectory() as tmp:
            Path(tmp, "tree-sitter.json").write_text(
                '{"grammars":[{"name":"foo","scope":"source.foo","path":"."}],'
                '"metadata":{"version":"1.2.3"}}\n'
            )
            result = self.run_cli("version", cwd=tmp)
            self.assertEqual(result.returncode, 0)
            self.assertEqual(result.stdout, "Current version: 1.2.3\n")
            self.assertEqual(result.stderr, "")

    def test_version_bump_updates_tree_sitter_json_then_reports_missing_makefile(self):
        with tempfile.TemporaryDirectory() as tmp:
            config = Path(tmp, "tree-sitter.json")
            config.write_text(
                '{"grammars":[{"name":"foo","scope":"source.foo","path":"."}],'
                '"metadata":{"version":"1.2.3"}}\n'
            )
            result = self.run_cli("version", "--bump", "patch", cwd=tmp)
            self.assertEqual(result.returncode, 1)
            self.assertIn("Bumping version 1.2.3 to 1.2.4", result.stdout)
            self.assertIn("Failed to update one or more files", result.stderr)
            self.assertIn('"version": "1.2.4"', config.read_text())


if __name__ == "__main__":
    unittest.main()
