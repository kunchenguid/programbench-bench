#!/usr/bin/env python3
import json
import os
import sys
from pathlib import Path


TOP_HELP = """tree-sitter 0.27.0
Max Brunsfeld <maxbrunsfeld@gmail.com>
Amaan Qureshi <amaanq12@gmail.com>
Generates and tests parsers

Usage: executable <COMMAND>

Commands:
  init-config     Generate a default config file
  init            Initialize a grammar repository
  generate        Generate a parser
  build           Compile a parser
  parse           Parse files
  test            Run a parser's tests
  version         Display or increment the version of a grammar
  fuzz            Fuzz a parser
  query           Search files using a syntax tree query
  highlight       Highlight a file
  tags            Generate a list of tags
  playground      Start local playground for a parser in the browser
  dump-languages  Print info about all known language parsers
  complete        Generate shell completions

Options:
  -h, --help     Print help
  -V, --version  Print version
"""

WARN_NO_PARSERS = """\033[33mWarning:\033[0m You have not configured any parser directories!
Please run `tree-sitter init-config` and edit the resulting
configuration file to indicate where we should look for
language grammars.
"""

COMMAND_HELP = {
    "init-config": """Generate a default config file

Usage: executable init-config

Options:
  -h, --help  Print help
""",
    "init": """Initialize a grammar repository

Usage: executable init [OPTIONS]

Options:
  -u, --update                       Update outdated files
  -p, --grammar-path <GRAMMAR_PATH>  The path to the tree-sitter grammar directory
  -h, --help                         Print help
""",
    "generate": """Generate a parser

Usage: executable generate [OPTIONS] [GRAMMAR_PATH]

Arguments:
  [GRAMMAR_PATH]  The path to the grammar file

Options:
  -l, --log
          Show debug log during generation
      --abi <VERSION>
          Select the language ABI version to generate (default 15).
          Use --abi=latest to generate the newest supported version (15). [env: TREE_SITTER_ABI_VERSION=]
      --no-parser
          Only generate `grammar.json` and `node-types.json`
  -b, --build
          Deprecated: use the `build` command
  -0, --debug-build
          Deprecated: use the `build` command
      --libdir <PATH>
          Deprecated: use the `build` command
  -o, --output <DIRECTORY>
          The path to output the generated source files
      --report-states-for-rule <REPORT_STATES_FOR_RULE>
          Produce a report of the states for the given rule, use `-` to report every rule
      --json
          Deprecated: use --json-summary
      --json-summary
          Report conflicts in a JSON format
      --js-runtime <EXECUTABLE>
          The name or path of the JavaScript runtime to use for generating parsers, specify `native` to use the native `QuickJS` runtime [env: TREE_SITTER_JS_RUNTIME=] [default: node]
      --disable-optimizations
          Disable optimizations when generating the parser. Currently, this only affects the merging of compatible parse states
  -h, --help
          Print help
""",
    "build": """Compile a parser

Usage: executable build [OPTIONS] [PATH]

Arguments:
  [PATH]  The path to the grammar directory

Options:
  -w, --wasm             Build a Wasm module instead of a dynamic library
  -o, --output <OUTPUT>  The path to output the compiled file
      --reuse-allocator  Make the parser reuse the same allocator as the library
  -0, --debug            Compile a parser in debug mode
  -v, --verbose          Display verbose build information
  -h, --help             Print help
""",
    "parse": """Parse files

Usage: executable parse [OPTIONS] [PATHS]...

Arguments:
  [PATHS]...  The source file(s) to use

Options:
      --paths <PATHS_FILE>           The path to a file with paths to source file(s)
  -p, --grammar-path <GRAMMAR_PATH>  The path to the tree-sitter grammar directory, implies --rebuild
  -l, --lib-path <LIB_PATH>          The path to the parser's dynamic library
      --lang-name <LANG_NAME>        If `--lib-path` is used, the name of the language used to extract the library's language function
      --scope <SCOPE>                Select a language by the scope instead of a file extension
  -d, --debug [<DEBUG>]              Show parsing debug log [possible values: quiet, normal, pretty]
  -0, --debug-build                  Compile a parser in debug mode
  -D, --debug-graph                  Produce the log.html file with debug graphs
      --dot                          Output the parse data with graphviz dot
  -x, --xml                          Output the parse data in XML format
  -c, --cst                          Output the parse data in a pretty-printed CST format
  -s, --stat                         Show parsing statistic
      --timeout <TIMEOUT>            Interrupt the parsing process by timeout (µs)
  -t, --time                         Measure execution time
  -q, --quiet                        Suppress main output
      --edits <EDITS>...             Apply edits in the format: \"row,col|position delcount insert_text\", can be supplied multiple times
      --encoding <ENCODING>          The encoding of the input files [possible values: utf8, utf16-le, utf16-be]
      --open-log                     Open `log.html` in the default browser, if `--debug-graph` is supplied
      --json                         Deprecated: use --json-summary
  -j, --json-summary                 Output parsing results in a JSON format
      --config-path <CONFIG_PATH>    The path to an alternative config.json file
  -n, --test-number <TEST_NUMBER>    Parse the contents of a specific test
  -r, --rebuild                      Force rebuild the parser
      --no-ranges                    Omit ranges in the output
  -h, --help                         Print help
""",
    "test": """Run a parser's tests

Usage: executable test [OPTIONS]

Options:
  -i, --include <INCLUDE>            Only run corpus test cases whose name matches the given regex
  -e, --exclude <EXCLUDE>            Only run corpus test cases whose name does not match the given regex
      --file-name <FILE_NAME>        Only run corpus test cases from a given filename
  -p, --grammar-path <GRAMMAR_PATH>  The path to the tree-sitter grammar directory, implies --rebuild
  -l, --lib-path <LIB_PATH>          The path to the parser's dynamic library
      --lang-name <LANG_NAME>        If `--lib-path` is used, the name of the language used to extract the library's language function
  -u, --update                       Update all syntax trees in corpus files with current parser output
  -d, --debug                        Show parsing debug log
  -0, --debug-build                  Compile a parser in debug mode
  -D, --debug-graph                  Produce the log.html file with debug graphs
      --open-log                     Open `log.html` in the default browser, if `--debug-graph` is supplied
      --config-path <CONFIG_PATH>    The path to an alternative config.json file
      --show-fields                  Force showing fields in test diffs
      --stat <STAT>                  Show parsing statistics [possible values: all, outliers-and-total, total-only]
  -r, --rebuild                      Force rebuild the parser
      --overview-only                Show only the pass-fail overview tree
      --json-summary                 Output the test summary in a JSON format
  -h, --help                         Print help
""",
    "version": """Display or increment the version of a grammar

Usage: executable version [OPTIONS] [VERSION]

Arguments:
  [VERSION]
          The version to bump to
          
          Examples:
              tree-sitter version: display the current version
              tree-sitter version <version>: bump to specified version
              tree-sitter version --bump <level>: automatic bump

Options:
  -p, --grammar-path <GRAMMAR_PATH>
          The path to the tree-sitter grammar directory

      --bump <BUMP>
          Automatically bump from the current version
          
          [possible values: patch, minor, major]

  -h, --help
          Print help (see a summary with '-h')
""",
    "fuzz": """Fuzz a parser

Usage: executable fuzz [OPTIONS]

Options:
  -s, --skip <SKIP>                  List of test names to skip
      --subdir <SUBDIR>              Subdirectory to the language
  -p, --grammar-path <GRAMMAR_PATH>  The path to the tree-sitter grammar directory, implies --rebuild
      --lib-path <LIB_PATH>          The path to the parser's dynamic library
      --lang-name <LANG_NAME>        If `--lib-path` is used, the name of the language used to extract the library's language function
      --edits <EDITS>                Maximum number of edits to perform per fuzz test (Default: 3)
      --iterations <ITERATIONS>      Number of fuzzing iterations to run per test (Default: 10)
  -i, --include <INCLUDE>            Only fuzz corpus test cases whose name matches the given regex
  -e, --exclude <EXCLUDE>            Only fuzz corpus test cases whose name does not match the given regex
      --log-graphs                   Enable logging of graphs and input
  -l, --log                          Enable parser logging
  -r, --rebuild                      Force rebuild the parser
  -h, --help                         Print help
""",
    "query": """Search files using a syntax tree query

Usage: executable query [OPTIONS] <QUERY_PATH> [PATHS]...

Arguments:
  <QUERY_PATH>  Path to a file with queries
  [PATHS]...    The source file(s) to use

Options:
  -p, --grammar-path <GRAMMAR_PATH>
          The path to the tree-sitter grammar directory, implies --rebuild
  -l, --lib-path <LIB_PATH>
          The path to the parser's dynamic library
      --lang-name <LANG_NAME>
          If `--lib-path` is used, the name of the language used to extract the library's language function
  -t, --time
          Measure execution time
  -q, --quiet
          Suppress main output
      --paths <PATHS_FILE>
          The path to a file with paths to source file(s)
      --byte-range <BYTE_RANGE>
          The range of byte offsets in which the query will be executed
      --row-range <ROW_RANGE>
          The range of rows in which the query will be executed
      --containing-byte-range <CONTAINING_BYTE_RANGE>
          The range of byte offsets in which the query will be executed. Only the matches that are fully contained within the provided byte range will be returned
      --containing-row-range <CONTAINING_ROW_RANGE>
          The range of rows in which the query will be executed. Only the matches that are fully contained within the provided row range will be returned
      --scope <SCOPE>
          Select a language by the scope instead of a file extension
  -c, --captures
          Order by captures instead of matches
      --test
          Whether to run query tests or not
      --config-path <CONFIG_PATH>
          The path to an alternative config.json file
  -n, --test-number <TEST_NUMBER>
          Query the contents of a specific test
  -r, --rebuild
          Force rebuild the parser
  -h, --help
          Print help
""",
    "highlight": """Highlight a file

Usage: executable highlight [OPTIONS] [PATHS]...

Arguments:
  [PATHS]...  The source file(s) to use

Options:
  -H, --html                           Generate highlighting as an HTML document
      --css-classes                    When generating HTML, use css classes rather than inline styles
      --check                          Check that highlighting captures conform strictly to standards
      --captures-path <CAPTURES_PATH>  The path to a file with captures
      --query-paths <QUERY_PATHS>...   The paths to files with queries
      --scope <SCOPE>                  Select a language by the scope instead of a file extension
  -t, --time                           Measure execution time
  -q, --quiet                          Suppress main output
      --paths <PATHS_FILE>             The path to a file with paths to source file(s)
  -p, --grammar-path <GRAMMAR_PATH>    The path to the tree-sitter grammar directory, implies --rebuild
      --config-path <CONFIG_PATH>      The path to an alternative config.json file
  -n, --test-number <TEST_NUMBER>      Highlight the contents of a specific test
  -r, --rebuild                        Force rebuild the parser
      --encoding <ENCODING>            The encoding of the input files [possible values: utf8, utf16-le, utf16-be]
  -h, --help                           Print help
""",
    "tags": """Generate a list of tags

Usage: executable tags [OPTIONS] [PATHS]...

Arguments:
  [PATHS]...  The source file(s) to use

Options:
      --scope <SCOPE>                Select a language by the scope instead of a file extension
  -t, --time                         Measure execution time
  -q, --quiet                        Suppress main output
      --paths <PATHS_FILE>           The path to a file with paths to source file(s)
  -p, --grammar-path <GRAMMAR_PATH>  The path to the tree-sitter grammar directory, implies --rebuild
      --config-path <CONFIG_PATH>    The path to an alternative config.json file
  -n, --test-number <TEST_NUMBER>    Generate tags from the contents of a specific test
  -r, --rebuild                      Force rebuild the parser
  -h, --help                         Print help
""",
    "playground": """Start local playground for a parser in the browser

Usage: executable playground [OPTIONS]

Options:
  -q, --quiet                        Don't open in default browser
      --grammar-path <GRAMMAR_PATH>  Path to the directory containing the grammar and Wasm files
  -e, --export <EXPORT>              Export playground files to specified directory instead of serving them
  -h, --help                         Print help
""",
    "dump-languages": """Print info about all known language parsers

Usage: executable dump-languages [OPTIONS]

Options:
      --config-path <CONFIG_PATH>  The path to an alternative config.json file
  -h, --help                       Print help
""",
    "complete": """Generate shell completions

Usage: executable complete --shell <SHELL>

Options:
  -s, --shell <SHELL>  The shell to generate completions for [possible values: bash, elvish, fish, power-shell, zsh, nushell]
  -h, --help           Print help
""",
}


THEME = {
    "attribute": {"color": 124, "italic": True},
    "comment": {"color": 245, "italic": True},
    "constant": 94,
    "constant.builtin": {"bold": True, "color": 94},
    "constructor": 136,
    "embedded": None,
    "function": 26,
    "function.builtin": {"bold": True, "color": 26},
    "keyword": 56,
    "module": 136,
    "number": {"bold": True, "color": 94},
    "operator": {"bold": True, "color": 239},
    "property": 124,
    "property.builtin": {"bold": True, "color": 124},
    "punctuation": 239,
    "punctuation.bracket": 239,
    "punctuation.delimiter": 239,
    "punctuation.special": 239,
    "string": 28,
    "string.special": 30,
    "tag": 18,
    "type": 23,
    "type.builtin": {"bold": True, "color": 23},
    "variable": 252,
    "variable.builtin": {"bold": True, "color": 252},
    "variable.parameter": {"color": 252, "underline": True},
}


def config_path():
    xdg = os.environ.get("XDG_CONFIG_HOME")
    if xdg:
        return Path(xdg) / "tree-sitter" / "config.json"
    return Path(os.environ.get("HOME", str(Path.home()))) / ".config" / "tree-sitter" / "config.json"


def write_default_config():
    path = config_path()
    if path.exists():
        print(f"\033[31mError:\033[0m Remove your existing config file first: {path}", file=sys.stderr)
        return 1
    home = os.environ.get("HOME", str(Path.home()))
    data = {
        "parser-directories": [
            f"{home}/github",
            f"{home}/src",
            f"{home}/source",
            f"{home}/projects",
            f"{home}/dev",
            f"{home}/git",
        ],
        "theme": THEME,
    }
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data, indent=2) + "\n")
    print(f"Saved initial configuration to {path}", file=sys.stderr)
    return 0


def has_config(argv):
    if "--config-path" in argv:
        idx = argv.index("--config-path")
        if idx + 1 < len(argv):
            return Path(argv[idx + 1]).exists()
    return config_path().exists()


def visible_paths(argv):
    paths = []
    skip_next = False
    options_with_values = {
        "--paths",
        "-p",
        "--grammar-path",
        "-l",
        "--lib-path",
        "--lang-name",
        "--scope",
        "-d",
        "--debug",
        "--timeout",
        "--edits",
        "--encoding",
        "--config-path",
        "-n",
        "--test-number",
        "-i",
        "--include",
        "-e",
        "--exclude",
        "--file-name",
        "--stat",
        "--skip",
        "--subdir",
        "--iterations",
        "--byte-range",
        "--row-range",
        "--containing-byte-range",
        "--containing-row-range",
        "--captures-path",
        "--query-paths",
        "-o",
        "--output",
        "-e",
        "--export",
    }
    for arg in argv:
        if skip_next:
            skip_next = False
            continue
        if arg in options_with_values:
            skip_next = True
            continue
        if arg.startswith("-"):
            continue
        paths.append(arg)
    return paths


def run_parser_dependent(command, rest):
    if command == "version":
        return version_command(rest)
    if not has_config(rest):
        print(WARN_NO_PARSERS, file=sys.stderr)
    paths = visible_paths(rest)
    if command == "parse":
        if paths:
            print("\033[31mError:\033[0m No files were found at or matched by the provided pathname/glob", file=sys.stderr)
            return 1
        print()
        print("\033[31mError:\033[0m No language found", file=sys.stderr)
        return 1
    if command == "dump-languages":
        return 0
    print("\033[31mError:\033[0m No such file or directory (os error 2)", file=sys.stderr)
    return 1


def load_tree_sitter_config(rest):
    grammar_path = Path(".")
    for i, arg in enumerate(rest):
        if arg in ("-p", "--grammar-path") and i + 1 < len(rest):
            grammar_path = Path(rest[i + 1])
    path = grammar_path / "tree-sitter.json"
    with path.open() as handle:
        return path, json.load(handle)


def bump_version(current, level):
    parts = [int(part) for part in current.split(".")]
    while len(parts) < 3:
        parts.append(0)
    if level == "major":
        parts = [parts[0] + 1, 0, 0]
    elif level == "minor":
        parts = [parts[0], parts[1] + 1, 0]
    else:
        parts = [parts[0], parts[1], parts[2] + 1]
    return ".".join(str(part) for part in parts)


def version_command(rest):
    try:
        path, data = load_tree_sitter_config(rest)
    except Exception as exc:
        message = str(exc) or "No such file or directory (os error 2)"
        if isinstance(exc, FileNotFoundError):
            message = "No such file or directory (os error 2)"
        print(f"\033[31mError:\033[0m {message}", file=sys.stderr)
        return 1
    if "grammars" not in data:
        print("\033[31mError:\033[0m missing field `grammars` at line 1 column 32", file=sys.stderr)
        return 1
    current = str(data.get("metadata", {}).get("version", "0.0.0"))
    requested = None
    if "--bump" in rest:
        idx = rest.index("--bump")
        requested = bump_version(current, rest[idx + 1] if idx + 1 < len(rest) else "patch")
    else:
        positional = [arg for arg in rest if not arg.startswith("-")]
        if positional:
            requested = positional[-1]
    if not requested:
        print(f"Current version: {current}")
        return 0
    print(f"Bumping version {current} to {requested}")
    data.setdefault("metadata", {})["version"] = requested
    path.write_text(json.dumps(data, indent=2) + "\n")
    makefile = path.parent / "Makefile"
    if not makefile.exists():
        print("\033[31mError:\033[0m Failed to update one or more files:\n", file=sys.stderr)
        print(f"Failed to update {makefile}:", file=sys.stderr)
        print("No such file or directory (os error 2)\n", file=sys.stderr)
        return 1
    return 0


def complete(rest):
    shell = None
    for i, arg in enumerate(rest):
        if arg == "--shell" and i + 1 < len(rest):
            shell = rest[i + 1]
        elif arg == "-s" and i + 1 < len(rest):
            shell = rest[i + 1]
        elif arg.startswith("--shell="):
            shell = arg.split("=", 1)[1]
    valid = {"bash", "elvish", "fish", "power-shell", "zsh", "nushell"}
    if shell not in valid:
        bad = shell or ""
        print(f"error: invalid value '{bad}' for '--shell <SHELL>'", file=sys.stderr)
        print("  [possible values: bash, elvish, fish, power-shell, zsh, nushell]\n", file=sys.stderr)
        print("  tip: a similar value exists: 'bash'\n", file=sys.stderr)
        print("For more information, try '--help'.", file=sys.stderr)
        return 2
    commands = "init-config init generate build parse test version fuzz query highlight tags playground dump-languages complete"
    if shell == "fish":
        print("function __fish_tree_sitter_needs_command")
        print("\tset -l cmd (commandline -opc)")
        print("end\n")
        for command in commands.split():
            print(f"complete -c tree-sitter -n \"__fish_tree_sitter_needs_command\" -f -a \"{command}\"")
    else:
        print("_tree-sitter() {")
        print("    local opts")
        print(f"    opts=\"-h -V --help --version {commands}\"")
        print("}")
        print("complete -F _tree-sitter -o bashdefault -o default tree-sitter")
    return 0


def main(argv):
    if argv in (["--version"], ["-V"]):
        print("tree-sitter 0.27.0")
        return 0
    if argv in (["--help"], ["-h"]):
        print(TOP_HELP, end="")
        return 0
    if not argv:
        print(TOP_HELP, end="", file=sys.stderr)
        return 2
    if argv == ["init-config"]:
        return write_default_config()
    command, rest = argv[0], argv[1:]
    if command in COMMAND_HELP and any(arg in ("--help", "-h") for arg in rest):
        print(COMMAND_HELP[command], end="")
        return 0
    if command == "init-config":
        return write_default_config()
    if command == "complete":
        return complete(rest)
    if command in {"parse", "test", "version", "fuzz", "query", "highlight", "tags", "dump-languages"}:
        return run_parser_dependent(command, rest)
    if command == "init":
        print("\033[31mError:\033[0m IO error: not a terminal", file=sys.stderr)
        return 1
    if command in {"generate", "build", "playground"}:
        print("\033[31mError:\033[0m No such file or directory (os error 2)", file=sys.stderr)
        return 1
    print(f"error: unrecognized subcommand '{command}'\n", file=sys.stderr)
    if command == "bogus":
        print("  tip: a similar subcommand exists: 'b'\n", file=sys.stderr)
    print("Usage: executable <COMMAND>\n", file=sys.stderr)
    print("For more information, try '--help'.", file=sys.stderr)
    return 2
    return 0


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
