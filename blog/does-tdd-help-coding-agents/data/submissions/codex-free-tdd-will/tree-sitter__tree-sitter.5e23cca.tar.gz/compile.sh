#!/bin/bash
set -e
rm -f executable
cp src/tree_sitter_cli.py executable
chmod +x executable
