#!/usr/bin/env python3
import sys
from pathlib import Path


HELP = """*** lz4 v1.10.0 64-bit multithread, by Yann Collet ***
Usage : 
      executable [arg] [input] [output] 

input   : a filename 
          with no FILE, or when FILE is - or stdin, read standard input
Arguments : 
 -1     : fast compression (default) 
 -12    : slowest compression level 
 -T#    : use # threads for compression (default:0==auto) 
 -d     : decompression (default for .lz4 extension)
 -f     : overwrite output without prompting 
 -k     : preserve source files(s)  (default) 
--rm    : remove source file(s) after successful de/compression 
 -h/-H  : display help/long help and exit 

Advanced arguments :
 -V     : display Version number and exit 
 -v     : verbose mode 
 -q     : suppress warnings; specify twice to suppress errors too
 -c     : force write to standard output, even if it is the console
 -t     : test compressed file integrity
 -m     : multiple input files (implies automatic output filenames)
 -r     : operate recursively on directories (sets also -m) 
 -l     : compress using Legacy format (Linux kernel compression)
 -z     : force compression 
 -D FILE: use FILE as dictionary (compression & decompression)
 -B#    : cut file into blocks of size # bytes [32+] 
                     or predefined block size [4-7] (default: 7) 
 -BI    : Block Independence (default) 
 -BD    : Block dependency (improves compression ratio) 
 -BX    : enable block checksum (default:disabled) 
--no-frame-crc : disable stream checksum (default:enabled) 
--content-size : compressed frame includes original size (default:not present)
--list FILE : lists information about .lz4 files (useful for files compressed with --content-size flag)
--[no-]sparse  : sparse mode (default:enabled on file, disabled on stdout)
--favor-decSpeed: compressed files decompress faster, but are less compressed 
--fast[=#]: switch to ultra fast compression level (default: 1)
--best  : same as -12
Benchmark arguments : 
 -b#    : benchmark file(s), using # compression level (default : 1) 
 -e#    : test all compression levels from -bX to # (default : 1)
 -i#    : minimum evaluation time in seconds (default : 3s) 
"""


def main(argv):
    if any(a in ("--help", "-h", "-H") for a in argv[1:]):
        sys.stdout.write(HELP)
        return 0
    if any(a in ("--version", "-V") for a in argv[1:]):
        sys.stdout.write("*** lz4 v1.10.0 64-bit multithread, by Yann Collet ***\n")
        return 0
    opts, files = parse_args(argv[1:])
    try:
        if opts["list"]:
            for line in list_files(files):
                sys.stdout.write(line + "\n")
            return 0
        if opts["decompress"] or (files and files[0].endswith(".lz4") and not opts["compress"]):
            data = read_input(files[0] if files else "-")
            decoded = decompress_frame(data)
            if opts["test"]:
                return 0
            write_output(decoded, output_name(files, True, opts), opts)
            return 0
        data = read_input(files[0] if files else "-")
        encoded = compress_frame(data, content_checksum=not opts["no_frame_crc"], content_size=opts["content_size"])
        write_output(encoded, output_name(files, False, opts), opts)
        return 0
    except BrokenPipeError:
        return 0
    except Exception as exc:
        if opts.get("quiet", 0) < 2:
            sys.stderr.write(f"Error 44 : {exc}\n")
        return 1


def parse_args(args):
    opts = {
        "decompress": False,
        "compress": False,
        "test": False,
        "stdout": False,
        "force": False,
        "quiet": 0,
        "rm": False,
        "no_frame_crc": False,
        "content_size": False,
        "list": False,
    }
    files = []
    i = 0
    while i < len(args):
        arg = args[i]
        if arg == "--":
            files.extend(args[i + 1 :])
            break
        if arg == "--rm":
            opts["rm"] = True
        elif arg == "--no-frame-crc":
            opts["no_frame_crc"] = True
        elif arg == "--content-size":
            opts["content_size"] = True
        elif arg == "--compress":
            opts["compress"] = True
        elif arg == "--decompress":
            opts["decompress"] = True
        elif arg.startswith("--fast") or arg in ("--best", "--favor-decSpeed", "--sparse", "--no-sparse"):
            pass
        elif arg == "--list":
            opts["list"] = True
            if i + 1 < len(args):
                files.append(args[i + 1])
                i += 1
        elif arg.startswith("-") and arg != "-":
            if arg.startswith("-D") and arg != "-D":
                pass
            elif arg == "-D" and i + 1 < len(args):
                i += 1
            elif arg.startswith("-B") or arg.startswith("-T") or arg.startswith("-b") or arg.startswith("-e") or arg.startswith("-i"):
                pass
            else:
                for ch in arg[1:]:
                    if ch == "d":
                        opts["decompress"] = True
                    elif ch == "z":
                        opts["compress"] = True
                    elif ch == "t":
                        opts["test"] = True
                        opts["decompress"] = True
                    elif ch == "c":
                        opts["stdout"] = True
                    elif ch == "f":
                        opts["force"] = True
                    elif ch == "q":
                        opts["quiet"] += 1
                    elif ch in "123456789klmrvBIHDX":
                        pass
        else:
            files.append(arg)
        i += 1
    return opts, files


def read_input(name):
    if name in ("-", "stdin"):
        return sys.stdin.buffer.read()
    return Path(name).read_bytes()


def output_name(files, decompressing, opts):
    if opts["stdout"] or len(files) < 2:
        if opts["stdout"] or not files:
            return "-"
        src = files[0]
        if decompressing:
            return src[:-4] if src.endswith(".lz4") else src + ".out"
        return src + ".lz4"
    return files[1]


def write_output(data, name, opts):
    if name == "-":
        sys.stdout.buffer.write(data)
        return
    p = Path(name)
    if p.exists() and not opts["force"]:
        raise RuntimeError(f"{name} already exists; use -f to overwrite")
    p.write_bytes(data)


def u32le(data, pos):
    if pos + 4 > len(data):
        raise RuntimeError("premature end of file")
    return int.from_bytes(data[pos : pos + 4], "little")


def decompress_frame(data):
    pos = 0
    out = bytearray()
    while pos < len(data):
        if pos + 4 > len(data):
            raise RuntimeError("Unrecognized header : Magic Number unreadable")
        magic = u32le(data, pos)
        pos += 4
        if 0x184D2A50 <= magic <= 0x184D2A5F:
            size = u32le(data, pos)
            pos += 4 + size
            continue
        if magic == 0x184C2102:
            pos = decompress_legacy(data, pos, out)
            continue
        if magic != 0x184D2204:
            raise RuntimeError("Unrecognized header : Magic Number unreadable")
        pos = decompress_modern_frame(data, pos, out)
    return bytes(out)


def list_files(files):
    lines = ["    Frames           Type Block  Compressed  Uncompressed    Ratio   Filename"]
    for name in files:
        data = read_input(name)
        info = inspect_frame(data)
        compressed = len(data)
        uncompressed = info["uncompressed"]
        ratio = (compressed * 100.0 / uncompressed) if uncompressed else 0.0
        lines.append(
            f"{info['frames']:10d}        {info['type']:>7} {info['block']:>5}"
            f" {compressed:11d} {uncompressed:13d} {ratio:7.2f}%   {name}"
        )
    return lines


def inspect_frame(data):
    pos = 0
    frames = 0
    total = 0
    block_name = "B7"
    while pos < len(data):
        magic = u32le(data, pos)
        pos += 4
        if 0x184D2A50 <= magic <= 0x184D2A5F:
            size = u32le(data, pos)
            pos += 4 + size
            continue
        if magic != 0x184D2204:
            raise RuntimeError("Unrecognized header : Magic Number unreadable")
        frames += 1
        flg = data[pos]
        bd = data[pos + 1]
        pos += 2
        block_name = f"B{(bd >> 4) & 7}"
        block_checksum = bool(flg & 0x10)
        has_content_size = bool(flg & 0x08)
        content_checksum = bool(flg & 0x04)
        has_dict = bool(flg & 0x01)
        declared_size = None
        if has_content_size:
            declared_size = int.from_bytes(data[pos : pos + 8], "little")
            pos += 8
        if has_dict:
            pos += 4
        pos += 1
        frame_total = 0
        while True:
            raw_size = u32le(data, pos)
            pos += 4
            if raw_size == 0:
                break
            size = raw_size & 0x7FFFFFFF
            if raw_size & 0x80000000:
                frame_total += size
            pos += size
            if block_checksum:
                pos += 4
        if content_checksum:
            pos += 4
        total += declared_size if declared_size is not None else frame_total
    return {"frames": frames, "type": "LZ4", "block": block_name, "uncompressed": total}


def decompress_legacy(data, pos, out):
    while pos < len(data):
        size = u32le(data, pos)
        pos += 4
        if pos + size > len(data):
            raise RuntimeError("corrupted legacy block")
        out.extend(decompress_block(data[pos : pos + size], out, True))
        pos += size
    return pos


def decompress_modern_frame(data, pos, out):
    if pos + 3 > len(data):
        raise RuntimeError("corrupted frame header")
    header_start = pos
    flg = data[pos]
    bd = data[pos + 1]
    pos += 2
    if (flg >> 6) != 1:
        raise RuntimeError("unsupported frame version")
    independent = bool(flg & 0x20)
    block_checksum = bool(flg & 0x10)
    has_content_size = bool(flg & 0x08)
    content_checksum = bool(flg & 0x04)
    has_dict = bool(flg & 0x01)
    if has_content_size:
        pos += 8
    if has_dict:
        pos += 4
    if pos >= len(data):
        raise RuntimeError("corrupted frame header")
    expected_hc = (xxh32(data[header_start:pos], 0) >> 8) & 0xFF
    if data[pos] != expected_hc:
        raise RuntimeError("header checksum mismatch")
    pos += 1  # header checksum
    frame_start = len(out)
    while True:
        block_size = u32le(data, pos)
        pos += 4
        if block_size == 0:
            break
        uncompressed = bool(block_size & 0x80000000)
        size = block_size & 0x7FFFFFFF
        if pos + size > len(data):
            raise RuntimeError("corrupted block")
        payload = data[pos : pos + size]
        pos += size
        if block_checksum:
            checksum = u32le(data, pos)
            pos += 4
            if xxh32(payload, 0) != checksum:
                raise RuntimeError("block checksum mismatch")
        if uncompressed:
            out.extend(payload)
        else:
            context = bytearray() if independent else out
            decoded = decompress_block(payload, context, independent)
            out.extend(decoded)
    if content_checksum:
        checksum = u32le(data, pos)
        pos += 4
        if xxh32(bytes(out[frame_start:]), 0) != checksum:
            raise RuntimeError("content checksum mismatch")
    return pos


def read_len(src, pos, length):
    while length == 15:
        if pos >= len(src):
            raise RuntimeError("corrupted block")
        value = src[pos]
        pos += 1
        length += value
        if value != 255:
            break
    return length, pos


def decompress_block(src, context, independent):
    out = bytearray()
    base = bytearray() if independent else context
    pos = 0
    while pos < len(src):
        token = src[pos]
        pos += 1
        lit_len, pos = read_len(src, pos, token >> 4)
        if pos + lit_len > len(src):
            raise RuntimeError("corrupted literals")
        out.extend(src[pos : pos + lit_len])
        pos += lit_len
        if pos == len(src):
            break
        if pos + 2 > len(src):
            raise RuntimeError("missing offset")
        offset = src[pos] | (src[pos + 1] << 8)
        pos += 2
        if offset == 0:
            raise RuntimeError("zero offset")
        match_len, pos = read_len(src, pos, token & 0x0F)
        match_len += 4
        for _ in range(match_len):
            combined_len = len(base) + len(out)
            idx = combined_len - offset
            if idx < 0:
                raise RuntimeError("offset outside history")
            if idx < len(base):
                b = base[idx]
            else:
                b = out[idx - len(base)]
            out.append(b)
    return bytes(out)


def compress_frame(data, content_checksum=True, content_size=False):
    flg = 0x60 | (0x04 if content_checksum else 0) | (0x08 if content_size else 0)
    bd = 0x70
    header = bytearray([flg, bd])
    if content_size:
        header.extend(len(data).to_bytes(8, "little"))
    hc = (xxh32(bytes(header), 0) >> 8) & 0xFF
    res = bytearray(b"\x04\x22\x4d\x18")
    res.extend(header)
    res.append(hc)
    max_block = 4 * 1024 * 1024
    for i in range(0, len(data), max_block):
        block = data[i : i + max_block]
        res.extend((len(block) | 0x80000000).to_bytes(4, "little"))
        res.extend(block)
    res.extend((0).to_bytes(4, "little"))
    if content_checksum:
        res.extend(xxh32(data, 0).to_bytes(4, "little"))
    return bytes(res)


def rotl32(x, r):
    return ((x << r) | (x >> (32 - r))) & 0xFFFFFFFF


def xxh32(data, seed=0):
    p = 0
    n = len(data)
    prime1 = 2654435761
    prime2 = 2246822519
    prime3 = 3266489917
    prime4 = 668265263
    prime5 = 374761393
    if n >= 16:
        v1 = (seed + prime1 + prime2) & 0xFFFFFFFF
        v2 = (seed + prime2) & 0xFFFFFFFF
        v3 = seed & 0xFFFFFFFF
        v4 = (seed - prime1) & 0xFFFFFFFF
        limit = n - 16
        while p <= limit:
            v1 = rotl32((v1 + u32le(data, p) * prime2) & 0xFFFFFFFF, 13)
            v1 = (v1 * prime1) & 0xFFFFFFFF
            p += 4
            v2 = rotl32((v2 + u32le(data, p) * prime2) & 0xFFFFFFFF, 13)
            v2 = (v2 * prime1) & 0xFFFFFFFF
            p += 4
            v3 = rotl32((v3 + u32le(data, p) * prime2) & 0xFFFFFFFF, 13)
            v3 = (v3 * prime1) & 0xFFFFFFFF
            p += 4
            v4 = rotl32((v4 + u32le(data, p) * prime2) & 0xFFFFFFFF, 13)
            v4 = (v4 * prime1) & 0xFFFFFFFF
            p += 4
        h = (rotl32(v1, 1) + rotl32(v2, 7) + rotl32(v3, 12) + rotl32(v4, 18)) & 0xFFFFFFFF
    else:
        h = (seed + prime5) & 0xFFFFFFFF
    h = (h + n) & 0xFFFFFFFF
    while p + 4 <= n:
        h = (h + u32le(data, p) * prime3) & 0xFFFFFFFF
        h = (rotl32(h, 17) * prime4) & 0xFFFFFFFF
        p += 4
    while p < n:
        h = (h + data[p] * prime5) & 0xFFFFFFFF
        h = (rotl32(h, 11) * prime1) & 0xFFFFFFFF
        p += 1
    h ^= h >> 15
    h = (h * prime2) & 0xFFFFFFFF
    h ^= h >> 13
    h = (h * prime3) & 0xFFFFFFFF
    h ^= h >> 16
    return h & 0xFFFFFFFF


if __name__ == "__main__":
    raise SystemExit(main(sys.argv))
