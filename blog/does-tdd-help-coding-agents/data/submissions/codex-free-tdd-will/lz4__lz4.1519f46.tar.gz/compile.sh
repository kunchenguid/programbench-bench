#!/bin/bash
set -e
rm -f executable
cp src/lz4clone.py executable
chmod +x executable
