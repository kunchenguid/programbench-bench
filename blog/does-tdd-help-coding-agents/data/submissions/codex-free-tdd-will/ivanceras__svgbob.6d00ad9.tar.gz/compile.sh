#!/bin/bash
set -e
cp svgbob_clone.py executable
chmod +x executable
