#!/usr/bin/env python3
import glob
import html
import os
import sys


def style(opts):
    text = """.svgbob line, .svgbob path, .svgbob circle, .svgbob rect, .svgbob polygon {
  stroke: __STROKE_COLOR__;
  stroke-width: __STROKE_WIDTH__;
  stroke-opacity: 1;
  fill-opacity: 1;
  stroke-linecap: round;
  stroke-linejoin: miter;
}

.svgbob text {
  white-space: pre;
  fill: __STROKE_COLOR__;
  font-family: __FONT_FAMILY__;
  font-size: __FONT_SIZE__px;
}

.svgbob rect.backdrop {
  stroke: none;
  fill: __BACKGROUND__;
}

.svgbob .broken {
  stroke-dasharray: 8;
}

.svgbob .filled {
  fill: __FILL_COLOR__;
}

.svgbob .bg_filled {
  fill: __BACKGROUND__;
  stroke-width: 1;
}

.svgbob .nofill {
  fill: __BACKGROUND__;
}

.svgbob .end_marked_arrow {
  marker-end: url(#arrow);
}

.svgbob .start_marked_arrow {
  marker-start: url(#arrow);
}

.svgbob .end_marked_diamond {
  marker-end: url(#diamond);
}

.svgbob .start_marked_diamond {
  marker-start: url(#diamond);
}

.svgbob .end_marked_circle {
  marker-end: url(#circle);
}

.svgbob .start_marked_circle {
  marker-start: url(#circle);
}

.svgbob .end_marked_open_circle {
  marker-end: url(#open_circle);
}

.svgbob .start_marked_open_circle {
  marker-start: url(#open_circle);
}

.svgbob .end_marked_big_open_circle {
  marker-end: url(#big_open_circle);
}

.svgbob .start_marked_big_open_circle {
  marker-start: url(#big_open_circle);
}

"""
    return (
        text.replace("__STROKE_COLOR__", opts["stroke_color"])
        .replace("__STROKE_WIDTH__", opts["stroke_width"])
        .replace("__FONT_FAMILY__", opts["font_family"])
        .replace("__FONT_SIZE__", opts["font_size"])
        .replace("__BACKGROUND__", opts["background"])
        .replace("__FILL_COLOR__", opts["fill_color"])
    )


DEFS = """  <defs>
    <marker id="arrow" viewBox="-2 -2 8 8" refX="4" refY="2" markerWidth="7" markerHeight="7" orient="auto-start-reverse">
      <polygon points="0,0 0,4 4,2 0,0"></polygon>
    </marker>
    <marker id="diamond" viewBox="-2 -2 8 8" refX="4" refY="2" markerWidth="7" markerHeight="7" orient="auto-start-reverse">
      <polygon points="0,2 2,0 4,2 2,4 0,2"></polygon>
    </marker>
    <marker id="circle" viewBox="0 0 8 8" refX="4" refY="4" markerWidth="7" markerHeight="7" orient="auto-start-reverse">
      <circle cx="4" cy="4" r="2" class="filled"></circle>
    </marker>
    <marker id="open_circle" viewBox="0 0 8 8" refX="4" refY="4" markerWidth="7" markerHeight="7" orient="auto-start-reverse">
      <circle cx="4" cy="4" r="2" class="bg_filled"></circle>
    </marker>
    <marker id="big_open_circle" viewBox="0 0 8 8" refX="4" refY="4" markerWidth="7" markerHeight="7" orient="auto-start-reverse">
      <circle cx="4" cy="4" r="3" class="bg_filled"></circle>
    </marker>
  </defs>"""


HELP = """svgbob 0.7.6
SvgBobRus is an ascii to svg converter

USAGE:
    executable [FLAGS] [OPTIONS] [input] [SUBCOMMAND]

FLAGS:
    -h, --help       Prints help information
    -s               parse an inline string
    -V, --version    Prints version information

OPTIONS:
        --background <background>        backdrop background will be filled with this color (default: 'white')
        --fill-color <fill-color>        solid shapes will be filled with this color (default: 'black')
        --font-family <font-family>      text will be rendered with this font (default: 'arial')
        --font-size <font-size>          text will be rendered with this font size (default: 14)
    -o, --output <output>                where to write svg output [default: STDOUT]
        --scale <scale>                  scale the entire svg (dimensions, font size, stroke width) by this factor
                                         (default: 1)
        --stroke-color <stroke-color>    stroke color for all lines (default: 'black')
        --stroke-width <stroke-width>    stroke width for all lines (default: 2)

ARGS:
    <input>    svgbob text file or inline string to parse [default: STDIN]

SUBCOMMANDS:
    build    Batch convert files to svg.
    help     Prints this message or the help of the given subcommand(s)
"""


BUILD_HELP = """executable-build 0.0.1
Batch convert files to svg.

USAGE:
    executable build [OPTIONS]

FLAGS:
    -h, --help       Prints help information
    -V, --version    Prints version information

OPTIONS:
    -i, --input <input>      set input file pattern like: *.bob or dir/*.bob
    -o, --outdir <outdir>    set dir of svg files
"""


def scaled(value, scale):
    result = value * scale
    if abs(result - round(result)) < 0.000001:
        return str(int(round(result)))
    return ("%g" % result)


def line_at(lines, row, col):
    if row < 0 or row >= len(lines) or col < 0 or col >= len(lines[row]):
        return " "
    return lines[row][col]


def mark(consumed, row, start, end):
    for col in range(start, end + 1):
        consumed.add((row, col))


def render_text(text, opts):
    scale = float(opts["scale"])
    lines = text.splitlines() or [""]
    width = (max([len(line) for line in lines] + [1]) + 1) * 8
    height = (len(lines) + 1) * 16
    consumed = set()
    shapes = []
    vertical_shapes = []

    for top, top_line in enumerate(lines):
        for left, ch in enumerate(top_line):
            if ch != "+":
                continue
            right = left + 1
            while right < len(top_line) and top_line[right] in "-=+":
                if top_line[right] == "+" and right > left + 1:
                    break
                right += 1
            if right >= len(top_line) or top_line[right] != "+":
                continue
            if not all(c in "-=" for c in top_line[left + 1:right]):
                continue
            for bottom in range(top + 1, len(lines)):
                if line_at(lines, bottom, left) == "+" and line_at(lines, bottom, right) == "+":
                    mid = "".join(line_at(lines, bottom, c) for c in range(left + 1, right))
                    if mid and all(c in "-=" for c in mid):
                        if all(line_at(lines, r, left) == "|" and line_at(lines, r, right) == "|" for r in range(top + 1, bottom)):
                            x = left * 8 + 4
                            y = top * 16 + 8
                            w = (right - left) * 8
                            h = (bottom - top) * 16
                            shapes.append(f'  <rect x="{scaled(x, scale)}" y="{scaled(y, scale)}" width="{scaled(w, scale)}" height="{scaled(h, scale)}" class="solid nofill" rx="0"></rect>')
                            mark(consumed, top, left, right)
                            mark(consumed, bottom, left, right)
                            for r in range(top + 1, bottom):
                                consumed.add((r, left))
                                consumed.add((r, right))
                        break

    for row, line in enumerate(lines):
        col = 0
        while col < len(line):
            if (row, col) in consumed or line[col] not in "-+<*>o":
                col += 1
                continue
            start = col
            while col < len(line) and line[col] in "-+<*>o" and (row, col) not in consumed:
                col += 1
            run = line[start:col]
            if "-" not in run:
                continue
            y = row * 16 + 8
            s = start
            e = col - 1
            if run.startswith("<"):
                shapes.append(f'  <polygon points="{scaled(s * 8 + 8, scale)},{scaled(y - 4, scale)} {scaled(s * 8, scale)},{scaled(y, scale)} {scaled(s * 8 + 8, scale)},{scaled(y + 4, scale)}" class="filled"></polygon>')
                s += 1
            if run.startswith("o", 0) or run.startswith("*", 0):
                cls = "end_marked_open_circle" if run[0] == "o" else "end_marked_circle"
                cx = start * 8 + 4
                stem = min(start + 2, col - 1) * 8
                shapes.append(f'  <line x1="{scaled(stem, scale)}" y1="{scaled(y, scale)}" x2="{scaled(cx, scale)}" y2="{scaled(y, scale)}" class="solid {cls}"></line>')
                s = min(start + 2, e)
            if run.endswith(">"):
                base = e * 8
                shapes.append(f'  <line x1="{scaled(s * 8, scale)}" y1="{scaled(y, scale)}" x2="{scaled(base, scale)}" y2="{scaled(y, scale)}" class="solid"></line>')
                shapes.append(f'  <polygon points="{scaled(base, scale)},{scaled(y - 4, scale)} {scaled((e + 1) * 8, scale)},{scaled(y, scale)} {scaled(base, scale)},{scaled(y + 4, scale)}" class="filled"></polygon>')
            elif run.endswith("o") and e > start:
                cx = e * 8 + 4
                shapes.append(f'  <line x1="{scaled(s * 8, scale)}" y1="{scaled(y, scale)}" x2="{scaled(cx, scale)}" y2="{scaled(y, scale)}" class="solid end_marked_open_circle"></line>')
            else:
                shapes.append(f'  <line x1="{scaled(s * 8, scale)}" y1="{scaled(y, scale)}" x2="{scaled((e + 1) * 8, scale)}" y2="{scaled(y, scale)}" class="solid"></line>')
            mark(consumed, row, start, col - 1)
            for plus_col, plus_ch in enumerate(run, start):
                if plus_ch == "+":
                    consumed.discard((row, plus_col))

    for col in range(max([len(line) for line in lines] + [0])):
        row = 0
        while row < len(lines):
            here = line_at(lines, row, col)
            if ((row, col) in consumed and here != "+") or here not in "|+":
                row += 1
                continue
            start = row
            saw_pipe = False
            while row < len(lines) and line_at(lines, row, col) in "|+" and ((row, col) not in consumed or line_at(lines, row, col) == "+"):
                saw_pipe = saw_pipe or line_at(lines, row, col) == "|"
                row += 1
            if saw_pipe:
                x = col * 8 + 4
                vertical_shapes.append(f'  <line x1="{scaled(x, scale)}" y1="{scaled(start * 16, scale)}" x2="{scaled(x, scale)}" y2="{scaled(row * 16, scale)}" class="solid"></line>')
                for r in range(start, row):
                    consumed.add((r, col))

    for row, line in enumerate(lines):
        for col, ch in enumerate(line):
            if (row, col) in consumed:
                continue
            if ch == "/":
                shapes.append(f'  <line x1="{scaled(col * 8 + 8, scale)}" y1="{scaled(row * 16, scale)}" x2="{scaled(col * 8, scale)}" y2="{scaled(row * 16 + 16, scale)}" class="solid"></line>')
                consumed.add((row, col))
            elif ch == "\\":
                shapes.append(f'  <line x1="{scaled(col * 8, scale)}" y1="{scaled(row * 16, scale)}" x2="{scaled(col * 8 + 8, scale)}" y2="{scaled(row * 16 + 16, scale)}" class="solid"></line>')
                consumed.add((row, col))

    insert_at = 0
    while insert_at < len(shapes) and shapes[insert_at].lstrip().startswith("<rect "):
        insert_at += 1
    shapes[insert_at:insert_at] = vertical_shapes

    texts = []
    structural = set("+-=|")
    for row, line in enumerate(lines):
        col = 0
        while col < len(line):
            while col < len(line) and (line[col] == " " or (row, col) in consumed or line[col] in structural):
                col += 1
            start = col
            buf = []
            while col < len(line) and not (line[col] == " " or (row, col) in consumed or line[col] in structural):
                buf.append(line[col])
                col += 1
            if buf:
                texts.append(f'  <text x="{scaled(start * 8 + 2, scale)}" y="{scaled(row * 16 + 12, scale)}" >{html.escape("".join(buf))}</text>')

    out = [
        f'<svg xmlns="http://www.w3.org/2000/svg" width="{scaled(width, scale)}" height="{scaled(height, scale)}" class="svgbob">',
        f"  <style>{style(opts)}</style>",
        DEFS,
        f'  <rect class="backdrop" x="0" y="0" width="{scaled(width, scale)}" height="{scaled(height, scale)}"></rect>',
    ]
    out.extend(shapes)
    out.extend(texts)
    out.append("</svg>")
    return "\n".join(out) + "\n"


def default_opts():
    return {
        "background": "white",
        "fill_color": "black",
        "stroke_color": "black",
        "font_family": "Iosevka Fixed, monospace",
        "font_size": "14",
        "stroke_width": "2",
        "scale": "1",
        "output": None,
        "inline": False,
        "input": None,
    }


def parse_args(argv):
    opts = default_opts()
    rest = []
    i = 0
    while i < len(argv):
        arg = argv[i]
        if arg in ("-h", "--help"):
            print(HELP, end="")
            raise SystemExit(0)
        if arg in ("-V", "--version"):
            print("svgbob 0.7.6")
            raise SystemExit(0)
        if arg == "-s":
            opts["inline"] = True
        elif arg in ("-o", "--output"):
            i += 1
            opts["output"] = argv[i]
        elif arg.startswith("--") and "=" in arg:
            key, value = arg[2:].split("=", 1)
            opts[key.replace("-", "_")] = value
        elif arg in ("--background", "--fill-color", "--stroke-color", "--font-family", "--font-size", "--stroke-width", "--scale"):
            i += 1
            opts[arg[2:].replace("-", "_")] = argv[i]
        else:
            rest.append(arg)
        i += 1
    if rest:
        opts["input"] = "\n".join(rest) if opts["inline"] else rest[0]
    return opts


def read_input(opts):
    if opts["inline"]:
        return opts["input"] or ""
    if opts["input"]:
        with open(opts["input"], "r", encoding="utf-8") as fh:
            return fh.read()
    return sys.stdin.read()


def run_build(argv):
    pattern = None
    outdir = "."
    i = 0
    while i < len(argv):
        if argv[i] in ("-h", "--help"):
            print(BUILD_HELP, end="")
            return 0
        if argv[i] in ("-V", "--version"):
            print("executable-build 0.0.1")
            return 0
        if argv[i] in ("-i", "--input"):
            i += 1
            pattern = argv[i]
        elif argv[i] in ("-o", "--outdir"):
            i += 1
            outdir = argv[i]
        i += 1
    os.makedirs(outdir, exist_ok=True)
    opts = default_opts()
    for path in glob.glob(pattern or "*.bob"):
        with open(path, "r", encoding="utf-8") as fh:
            svg = render_text(fh.read(), opts)
        base = os.path.splitext(os.path.basename(path))[0] + ".svg"
        target = os.path.join(outdir, base)
        with open(target, "w", encoding="utf-8") as fh:
            fh.write(svg)
        print(f"{path} => {target}")
    return 0


def main():
    argv = sys.argv[1:]
    if argv and argv[0] == "help":
        print(HELP if len(argv) == 1 or argv[1] != "build" else BUILD_HELP, end="")
        return 0
    if argv and argv[0] == "build":
        return run_build(argv[1:])
    opts = parse_args(argv)
    svg = render_text(read_input(opts), opts)
    if opts["output"]:
        with open(opts["output"], "w", encoding="utf-8") as fh:
            fh.write(svg)
    else:
        sys.stdout.write(svg)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
