#!/usr/bin/env python3
import os
import json
import re
import sys


VERSION = "rumdl 0.1.13"


RULES = [
    ("MD001", "Heading levels should only increment by one level at a time", "heading", "error", True),
    ("MD003", "Heading style", "heading", "warning", True),
    ("MD004", "Use consistent style for unordered list markers", "list", "warning", True),
    ("MD005", "List indentation should be consistent", "list", "warning", False),
    ("MD007", "Unordered list indentation", "list", "warning", True),
    ("MD009", "Trailing spaces should be removed", "whitespace", "warning", True),
    ("MD010", "No tabs", "whitespace", "warning", True),
    ("MD011", "Reversed link syntax", "link", "error", True),
    ("MD012", "Multiple consecutive blank lines", "whitespace", "warning", True),
    ("MD013", "Line length should not be excessive", "whitespace", "warning", False),
    ("MD014", "Commands in code blocks should show output", "code-block", "warning", False),
    ("MD018", "No space after hash in heading", "heading", "warning", True),
    ("MD019", "Multiple spaces after hash in heading", "heading", "warning", True),
    ("MD020", "No space inside hashes on closed heading", "heading", "warning", True),
    ("MD021", "Multiple spaces inside hashes on closed heading", "heading", "warning", True),
    ("MD022", "Headings should be surrounded by blank lines", "heading", "warning", True),
    ("MD023", "Headings must start at the beginning of the line", "heading", "warning", True),
    ("MD024", "Multiple headings with the same content", "heading", "error", False),
    ("MD025", "Multiple top-level headings in the same document", "heading", "error", True),
    ("MD026", "Trailing punctuation in heading", "heading", "warning", True),
    ("MD027", "Multiple spaces after quote marker (>)", "blockquote", "warning", True),
    ("MD028", "Blank line inside blockquote", "blockquote", "warning", False),
    ("MD029", "Ordered list marker value", "list", "warning", True),
    ("MD030", "Spaces after list markers should be consistent", "list", "warning", True),
    ("MD031", "Fenced code blocks should be surrounded by blank lines", "code-block", "warning", True),
    ("MD032", "Lists should be surrounded by blank lines", "list", "warning", True),
    ("MD033", "Inline HTML is not allowed", "html", "warning", False),
    ("MD034", "No bare URLs - wrap URLs in angle brackets", "link", "warning", True),
    ("MD035", "Horizontal rule style", "formatting", "warning", True),
    ("MD036", "Emphasis should not be used instead of a heading", "emphasis", "warning", False),
    ("MD037", "Spaces inside emphasis markers", "formatting", "warning", True),
    ("MD038", "Spaces inside code span elements", "formatting", "warning", True),
    ("MD039", "Spaces inside link text", "formatting", "warning", True),
    ("MD040", "Code blocks should have a language specified", "code-block", "warning", True),
    ("MD041", "First line in file should be a top level heading", "heading", "warning", False),
    ("MD042", "No empty links", "link", "error", False),
    ("MD043", "Required heading structure", "heading", "warning", False),
    ("MD044", "Proper names should have the correct capitalization", "formatting", "warning", False),
    ("MD045", "Images should have alternate text (alt text)", "link", "error", True),
    ("MD046", "Code blocks should use a consistent style", "code-block", "warning", True),
    ("MD047", "Files should end with a single newline character", "whitespace", "warning", True),
    ("MD048", "Code fence style should be consistent", "code-block", "warning", True),
    ("MD049", "Emphasis style should be consistent", "formatting", "warning", True),
    ("MD050", "Strong emphasis style should be consistent", "formatting", "warning", True),
    ("MD051", "Link fragments should reference valid headings", "link", "error", False),
    ("MD052", "Reference links and images should use a reference that exists", "link", "warning", False),
    ("MD053", "Link and image reference definitions should be needed", "link", "warning", True),
    ("MD054", "Link and image style should be consistent", "link", "warning", False),
    ("MD055", "Table pipe style should be consistent", "table", "warning", True),
    ("MD056", "Table column count should be consistent", "table", "warning", False),
    ("MD057", "Relative links should point to existing files", "link", "error", False),
    ("MD058", "Tables should be surrounded by blank lines", "table", "warning", True),
    ("MD059", "Link text should be descriptive", "link", "warning", False),
    ("MD060", "Table columns should be consistently aligned", "table", "warning", True),
    ("MD061", "Forbidden terms", "other", "warning", False),
    ("MD062", "Link destination should not have leading or trailing whitespace", "link", "warning", True),
    ("MD063", "Heading capitalization", "heading", "warning", True),
    ("MD064", "Multiple consecutive spaces", "whitespace", "warning", True),
    ("MD065", "Horizontal rules should be surrounded by blank lines", "formatting", "warning", True),
    ("MD066", "Footnote validation", "footnote", "error", False),
    ("MD067", "Footnote definitions should appear in order of first reference", "footnote", "warning", False),
    ("MD068", "Footnote definitions should not be empty", "footnote", "error", False),
    ("MD069", "Duplicate list markers", "list", "warning", True),
    ("MD070", "Nested code fence collision - use longer fence to avoid premature closure", "code-block", "warning", True),
    ("MD071", "Blank line after frontmatter", "front-matter", "warning", True),
    ("MD072", "Frontmatter keys should be sorted alphabetically", "front-matter", "warning", True),
    ("MD073", "Table of Contents should match document headings", "other", "warning", False),
]

RULE_BY_ID = {r[0]: r for r in RULES}
SUMMARY_OVERRIDES = {
    "MD013": "Line length should not be excessive",
    "MD041": "First line in file should be a top level heading",
}
NAME_OVERRIDES = {
    "MD013": "line-length",
    "MD041": "first-line-h1",
}

DEFAULT_CONFIG = """# rumdl configuration file

# Global configuration options
[global]
# disable = ["MD013", "MD033"]
# enable = ["MD001", "MD003", "MD004"]
exclude = [
    ".git",
    ".github",
    "node_modules",
    "vendor",
    "dist",
    "build",
    "CHANGELOG.md",
    "LICENSE.md",
]
respect-gitignore = true

# [MD013]
# line-length = 100
# code-blocks = false
# tables = false
# headings = true
"""


def is_h1(line):
    return line.startswith("# ") or line.startswith("#\t")


class Issue:
    def __init__(self, path, line, col, rule, msg, fixable=False):
        self.path = path
        self.line = line
        self.col = col
        self.rule = rule
        self.msg = msg
        self.fixable = fixable

    @property
    def severity(self):
        return RULE_BY_ID.get(self.rule, ("", "", "", "warning", False))[3]


def display_path(path):
    try:
        rel = os.path.relpath(path, os.getcwd())
        return rel if not rel.startswith("..") else path
    except ValueError:
        return path


def heading_level(line):
    m = re.match(r"^(#{1,6})(?:\s+|$)", line)
    return len(m.group(1)) if m else 0


def fix_text(text):
    lines = text.splitlines()
    out = []
    blank_run = 0
    in_fence = False
    for idx, line in enumerate(lines):
        line = line.rstrip(" ")
        line = line.replace("\t", "    ")
        if line.strip() == "":
            blank_run += 1
            if blank_run > 1:
                continue
        else:
            blank_run = 0
        if re.match(r"^\s*(```+|~~~+)", line):
            if in_fence:
                in_fence = False
                out.append(line)
                continue
            if out and out[-1].strip() != "":
                out.append("")
            if re.match(r"^\s*(```+|~~~+)\s*$", line):
                line = line.rstrip() + "text"
            in_fence = True
        out.append(line)
    return "\n".join(out) + "\n"


def check_file(path, disabled=None, enabled=None, line_length=80):
    disabled = disabled or set()
    with open(path, "r", encoding="utf-8", errors="replace") as fh:
        text = fh.read()
    raw_lines = text.splitlines()
    lines = raw_lines if raw_lines else []
    issues = []
    in_fence = False
    prev_heading = 0
    h1_count = 0
    blank_run = 0
    for idx, line in enumerate(lines, 1):
        stripped = line.strip()
        if idx == 1 and "MD041" not in disabled and not (line.startswith("# ") or line.startswith("---") or line.startswith("+++") or line.startswith("{")):
            issues.append(Issue(path, 1, 1, "MD041", "First line in file should be a level 1 heading"))
        if "\t" in line and "MD010" not in disabled:
            issues.append(Issue(path, idx, line.index("\t") + 1, "MD010", "Found tab for alignment, use spaces instead", True))
        trail = len(line) - len(line.rstrip(" "))
        if trail > 2 and "MD009" not in disabled:
            issues.append(Issue(path, idx, len(line) - trail + 1, "MD009", f"{trail} trailing spaces found", True))
        if stripped == "":
            blank_run += 1
            if blank_run > 1 and "MD012" not in disabled:
                issues.append(Issue(path, idx, 1, "MD012", "Multiple consecutive blank lines between content", True))
            continue
        blank_run = 0
        fence = re.match(r"^\s*(```+|~~~+)(\S*)", line)
        if fence:
            if not in_fence and idx > 1 and lines[idx - 2].strip() != "" and "MD031" not in disabled:
                issues.append(Issue(path, idx, line.find(fence.group(1)) + 1, "MD031", "No blank line before fenced code block", True))
            if not in_fence and fence.group(2) == "" and "MD040" not in disabled:
                issues.append(Issue(path, idx, line.find(fence.group(1)) + 1, "MD040", f"Code block ({fence.group(1)}) missing language", True))
            in_fence = not in_fence
            continue
        if not in_fence:
            indented_heading = re.match(r"^( +)(#{1,6})\s+", line)
            if indented_heading and "MD023" not in disabled:
                issues.append(Issue(path, idx, 1, "MD023", f"Heading should not be indented by {len(indented_heading.group(1))} spaces", True))
            no_space_heading = re.match(r"^(#{1,6})([^#\s].*)", line)
            if no_space_heading and "MD018" not in disabled:
                issues.append(Issue(path, idx, len(no_space_heading.group(1)) + 1, "MD018", f"No space after {no_space_heading.group(1)} in heading", True))
            multi_space_heading = re.match(r"^(#{1,6})( {2,})(\S.*)", line)
            if multi_space_heading and "MD019" not in disabled:
                issues.append(Issue(path, idx, len(multi_space_heading.group(1)) + 1, "MD019", f"Multiple spaces ({len(multi_space_heading.group(2))}) after {multi_space_heading.group(1)} in heading", True))
            lvl = heading_level(line)
            if lvl:
                if idx > 1 and lines[idx - 2].strip() != "" and "MD022" not in disabled:
                    issues.append(Issue(path, idx, 1, "MD022", "Expected 1 blank line above heading", True))
                if idx < len(lines) and lines[idx].strip() != "" and "MD022" not in disabled:
                    issues.append(Issue(path, idx, 1, "MD022", "Expected 1 blank line below heading", True))
                if prev_heading and lvl > prev_heading + 1 and "MD001" not in disabled:
                    issues.append(Issue(path, idx, 1, "MD001", f"Expected heading level {prev_heading + 1}, but found heading level {lvl}", True))
                prev_heading = lvl
                if lvl == 1:
                    h1_count += 1
                    if h1_count > 1 and "MD025" not in disabled:
                        issues.append(Issue(path, idx, 1, "MD025", "Multiple top-level headings (level 1) in the same document", True))
                heading_text = re.sub(r"^#{1,6}\s*", "", line).strip().rstrip("#").strip()
                if heading_text and heading_text[-1:] in ".,;:!" and "MD026" not in disabled:
                    issues.append(Issue(path, idx, line.rfind(heading_text[-1]) + 1, "MD026", f"Heading '{heading_text}' ends with punctuation '{heading_text[-1]}'", True))
            if re.match(r"^\s*([-+*]|\d+[.)])\s+", line) and idx > 1 and lines[idx - 2].strip() != "" and "MD032" not in disabled:
                issues.append(Issue(path, idx, 1, "MD032", "List should be preceded by blank line", True))
            if "MD034" not in disabled:
                for m in re.finditer(r"(?<![<(])\bhttps?://[^\s>)]+", line):
                    issues.append(Issue(path, idx, m.start() + 1, "MD034", f"URL without angle brackets or link formatting: '{m.group(0)}'", True))
            if "MD033" not in disabled:
                m = re.search(r"<([A-Za-z][A-Za-z0-9-]*)(?:\s|>|/)", line)
                if m and not line.strip().startswith("<http"):
                    issues.append(Issue(path, idx, m.start() + 1, "MD033", f"Inline HTML found: <{m.group(1)}>", False))
            if line_length and len(line) > line_length and "MD013" not in disabled and not line.lstrip().startswith("|"):
                issues.append(Issue(path, idx, line_length + 1, "MD013", f"Line length {len(line)} exceeds {line_length} characters"))
            for m in re.finditer(r"!\[([^\]]*)\]\(([^)]*)\)", line):
                if m.group(1) == "" and "MD045" not in disabled:
                    issues.append(Issue(path, idx, m.start() + 1, "MD045", "Image missing alt text (add description for accessibility: ![description](url))", True))
                dest = m.group(2)
                if dest and not re.match(r"^[a-z]+:|^#|^/|^<", dest) and "MD057" not in disabled:
                    target = dest.strip().split()[0]
                    if target and not os.path.exists(os.path.join(os.path.dirname(path), target)):
                        issues.append(Issue(path, idx, m.start() + 1, "MD057", f"Relative link '{target}' does not exist"))
            for m in re.finditer(r"(?<!!)\[([^\]]*)\]\(([^)]*)\)", line):
                dest = m.group(2)
                if dest.strip() == "" and "MD042" not in disabled:
                    issues.append(Issue(path, idx, m.start() + 1, "MD042", f"Empty link found: {m.group(0)}"))
                if dest != dest.strip() and "MD062" not in disabled:
                    kind = "leading and trailing" if dest.startswith(" ") and dest.endswith(" ") else ("leading" if dest.startswith(" ") else "trailing")
                    issues.append(Issue(path, idx, m.start() + 1, "MD062", f"Link destination has {kind} whitespace", True))
            if "MD064" not in disabled:
                m = re.search(r"(?<![.!?]) {2,}(?!$)", line)
                if m and line[m.end():].strip():
                    issues.append(Issue(path, idx, m.start() + 1, "MD064", f"Multiple consecutive spaces ({m.end() - m.start()}) found", True))
    if text and not text.endswith("\n") and "MD047" not in disabled:
        issues.append(Issue(path, len(lines), len(lines[-1]) + 1 if lines else 1, "MD047", "File should end with a single newline character", True))
    if enabled:
        issues = [i for i in issues if i.rule in enabled]
    return issues


def parse_list_value(value):
    return re.findall(r'"([^"]+)"|\'([^\']+)\'|([A-Za-z0-9_-]+)', value)


def load_config(path=None):
    candidates = []
    if path:
        candidates.append(path)
    else:
        cur = os.getcwd()
        while True:
            for name in (".rumdl.toml", "rumdl.toml", "pyproject.toml"):
                candidates.append(os.path.join(cur, name))
            parent = os.path.dirname(cur)
            if parent == cur:
                break
            cur = parent
    disabled = set()
    enabled = set()
    line_length = 80
    for cand in candidates:
        if not os.path.exists(cand):
            continue
        section = ""
        with open(cand, "r", encoding="utf-8", errors="replace") as fh:
            for raw in fh:
                line = raw.split("#", 1)[0].strip()
                if not line:
                    continue
                m = re.match(r"\[+([^\]]+)\]+", line)
                if m:
                    section = m.group(1).split(".")[-1]
                    continue
                if "=" not in line:
                    continue
                key, val = [x.strip() for x in line.split("=", 1)]
                if section == "global" and key in ("disable", "disabled"):
                    for parts in parse_list_value(val):
                        for item in parts:
                            if item:
                                disabled.add(item.upper())
                if section == "global" and key in ("enable", "enabled"):
                    for parts in parse_list_value(val):
                        for item in parts:
                            if item:
                                enabled.add(item.upper())
                if section.upper() == "MD013" and key in ("line-length", "line_length"):
                    try:
                        line_length = int(val.strip('"'))
                    except ValueError:
                        pass
        break
    return disabled, enabled, line_length


def cmd_check(argv, force_fix=False):
    if any(a in ("-h", "--help") for a in argv):
        cmd = "fmt" if force_fix else "check"
        print(("Format Markdown files (alias for check --fix)" if force_fix else "Lint Markdown files and print warnings/errors") + "\n")
        print(f"Usage: executable {cmd} [OPTIONS] [PATHS]...\n")
        print("Arguments:")
        print("  [PATHS]...  Files or directories to lint (use '-' for stdin)\n")
        print("Options:")
        print("  -f, --fix                  Fix issues automatically where possible")
        print("  -d, --disable <DISABLE>    Disable specific rules (comma-separated)")
        print("  -e, --enable <ENABLE>      Enable only specific rules (comma-separated)")
        print("  -o, --output <OUTPUT>      Output format: text or json")
        print("      --output-format <FMT>  Output format")
        print("      --stdin                Read from stdin instead of files")
        print("      --stdin-filename <F>   Filename to use when reading from stdin")
        print("      --fail-on <FAIL_ON>    any, warning, error, or never")
        print("  -h, --help                 Print help")
        return 0
    output_format = "text"
    disabled = set()
    enabled = set()
    silent = False
    fail_never = False
    do_fix = force_fix
    use_config = True
    config_path = None
    paths = []
    i = 0
    while i < len(argv):
        a = argv[i]
        if a in ("--output-format", "-o", "--output") and i + 1 < len(argv):
            output_format = argv[i + 1]
            i += 2
            continue
        if a in ("--disable", "-d") and i + 1 < len(argv):
            disabled.update(x.strip().upper() for x in argv[i + 1].split(",") if x.strip())
            i += 2
            continue
        if a in ("--config",) and i + 1 < len(argv):
            config_path = argv[i + 1]
            i += 2
            continue
        if a in ("--no-config", "--isolated"):
            use_config = False
            i += 1
            continue
        if a in ("--enable", "--rules", "-e") and i + 1 < len(argv):
            enabled.update(x.strip().upper() for x in argv[i + 1].split(",") if x.strip())
            i += 2
            continue
        if a == "--fail-on" and i + 1 < len(argv):
            fail_never = argv[i + 1] == "never"
            i += 2
            continue
        if a in ("--silent", "-s"):
            silent = True
            i += 1
            continue
        if a in ("--fix", "-f"):
            do_fix = True
            i += 1
            continue
        if a == "--stdin":
            paths.append("-")
            i += 1
            continue
        if a == "--stdin-filename" and i + 1 < len(argv):
            paths.append(("stdin", argv[i + 1]))
            i += 2
            continue
        if a.startswith("-"):
            i += 1
            continue
        paths.append(a)
        i += 1
    config_disabled, config_enabled, line_length = load_config(config_path) if use_config else (set(), set(), 80)
    disabled = config_disabled | disabled
    enabled = enabled or config_enabled
    issues = []
    for path in paths or ["."]:
        if path == "-" or (isinstance(path, tuple) and path[0] == "stdin"):
            name = path[1] if isinstance(path, tuple) else "stdin.md"
            tmp = f"/tmp/rumdl-stdin-{os.getpid()}.md"
            with open(tmp, "w", encoding="utf-8") as fh:
                fh.write(sys.stdin.read())
            got = check_file(tmp, disabled, enabled, line_length)
            for issue in got:
                issue.path = name
            issues.extend(got)
            continue
        if os.path.isdir(path):
            for root, dirs, files in os.walk(path):
                dirs[:] = [d for d in dirs if d not in {".git", "node_modules", "vendor", "dist", "build", ".rumdl_cache"}]
                for name in files:
                    if name.lower().endswith((".md", ".markdown")):
                        issues.extend(check_file(os.path.join(root, name), disabled, enabled, line_length))
        else:
            issues.extend(check_file(path, disabled, enabled, line_length))
    if do_fix and issues:
        fixed_count = sum(1 for issue in issues if issue.fixable)
        touched = set()
        for issue in issues:
            if issue.fixable and os.path.exists(issue.path) and issue.path not in touched:
                with open(issue.path, "r", encoding="utf-8", errors="replace") as fh:
                    original = fh.read()
                with open(issue.path, "w", encoding="utf-8") as fh:
                    fh.write(fix_text(original))
                touched.add(issue.path)
        if not silent:
            for issue in issues:
                shown = display_path(issue.path)
                if shown.startswith("/tmp/"):
                    shown = os.path.basename(shown)
                status = "[fixed]" if issue.fixable else "[remaining]"
                print(f"{shown}:{issue.line}:{issue.col}: [{issue.rule}] {issue.msg} {status}")
            print()
            print(f"Fixed: Fixed {fixed_count}/{len(issues)} issues in {len(touched) or len(set(i.path for i in issues))} file")
        return 0
    if output_format == "json":
        print(json.dumps([{"file": display_path(i.path), "line": i.line, "column": i.col, "rule": i.rule, "message": i.msg, "severity": i.severity, "fixable": i.fixable, "fix": None} for i in issues], indent=2))
        return 0 if (not issues or fail_never) else 1
    if output_format == "json-lines":
        for i in issues:
            print(json.dumps({"file": display_path(i.path), "line": i.line, "column": i.col, "rule": i.rule, "message": i.msg, "severity": i.severity, "fixable": i.fixable}))
        return 0 if (not issues or fail_never) else 1
    if silent:
        return 0 if (not issues or fail_never) else 1
    for issue in issues:
        shown = display_path(issue.path)
        if shown.startswith("/tmp/"):
            shown = os.path.basename(shown)
        suffix = " [*]" if issue.fixable else ""
        print(f"{shown}:{issue.line}:{issue.col}: [{issue.rule}] {issue.msg}{suffix}")
    if issues:
        fixable = sum(1 for i in issues if i.fixable)
        files = len({i.path for i in issues})
        print()
        noun = "issue" if len(issues) == 1 else "issues"
        fnoun = "file" if files == 1 else "files"
        print(f"Issues: Found {len(issues)} {noun} in {files} {fnoun}")
        if fixable:
            print(f"Run `rumdl fmt` to automatically fix {fixable} of the {len(issues)} {noun}")
    else:
        print()
        print("Success: No issues found in 1 file")
    return 0 if (not issues or fail_never) else 1


def rule_summary(code):
    r = RULE_BY_ID[code]
    return SUMMARY_OVERRIDES.get(code, r[1])


def rule_name(code):
    return NAME_OVERRIDES.get(code, rule_summary(code).lower().replace(" ", "-"))


def rule_fix_text(code, fixable):
    return "Fix is always available." if (fixable or code == "MD013") else "No automatic fix available."


def cmd_rule(argv):
    if any(a in ("-h", "--help") for a in argv):
        print("Show information about a rule or list all rules\n")
        print("Usage: executable rule [OPTIONS] [RULE]\n")
        print("Arguments:")
        print("  [RULE]  Rule name or ID (optional, omit to list all rules)\n")
        print("Options:")
        print("  -o, --output-format <FORMAT>  Output format: text, json, or json-lines")
        print("  -f, --fixable                 Filter to only fixable rules")
        print("      --list-categories         List available categories and exit")
        print("  -h, --help                    Print help")
        return 0
    output = "text"
    list_categories = False
    fixable_only = False
    rule = None
    i = 0
    while i < len(argv):
        a = argv[i]
        if a in ("--output-format", "-o") and i + 1 < len(argv):
            output = argv[i + 1]
            i += 2
        elif a == "--list-categories":
            list_categories = True
            i += 1
        elif a in ("--fixable", "-f"):
            fixable_only = True
            i += 1
        elif a.startswith("-"):
            i += 1 if a in ("--explain", "--no-config", "--isolated") else 2 if i + 1 < len(argv) else 1
        else:
            rule = a.upper()
            i += 1
    if list_categories:
        counts = {}
        for _, _, cat, _, _ in RULES:
            counts[cat] = counts.get(cat, 0) + 1
        print("Available categories:")
        for cat in sorted(counts):
            print(f"  {cat} ({counts[cat]} rules)")
        return 0
    selected = [r for r in RULES if (not fixable_only or r[4])]
    if rule:
        if rule not in RULE_BY_ID:
            print(f"error: unknown rule '{rule}'", file=sys.stderr)
            return 1
        selected = [RULE_BY_ID[rule]]
    if output == "json":
        payload = []
        for code, _, cat, _, fixable in selected:
            payload.append({"code": code, "name": rule_name(code), "aliases": [], "summary": rule_summary(code), "category": cat, "fix": rule_fix_text(code, fixable), "fix_availability": "Always" if (fixable or code == "MD013") else "None", "url": f"https://rumdl.dev/{code.lower()}/"})
        print(json.dumps(payload[0] if rule else payload, indent=2))
        return 0
    if rule:
        code, _, cat, _, fixable = selected[0]
        print(f"{code} - {rule_summary(code)}\n")
        print(f"Name: {rule_name(code)}")
        print(f"Category: {cat}")
        print(f"Fix: {rule_fix_text(code, fixable)}")
        print(f"Documentation: https://rumdl.dev/{code.lower()}/")
    else:
        print("Available rules:")
        for code, _, _, _, _ in selected:
            print(f"  {code} - {rule_summary(code)}")
        print(f"\nTotal: {len(selected)} rules")
    return 0


def cmd_init(argv):
    if any(a in ("-h", "--help") for a in argv):
        print("Initialize a new configuration file\n")
        print("Usage: executable init [OPTIONS]\n")
        print("Options:")
        print("      --pyproject        Generate configuration for pyproject.toml instead of .rumdl.toml")
        print("  -h, --help             Print help")
        return 0
    pyproject = "--pyproject" in argv
    name = "pyproject.toml" if pyproject else ".rumdl.toml"
    if os.path.exists(name):
        print(f"Configuration file already exists: {name}", file=sys.stderr)
        return 1
    content = "[tool.rumdl]\n" + DEFAULT_CONFIG if pyproject else DEFAULT_CONFIG
    with open(name, "w", encoding="utf-8") as fh:
        fh.write(content)
    print(f"Created default configuration file: {name}\n")
    print("Setup complete! You can now:")
    print("  - Run rumdl check . to lint your Markdown files")
    print("  - Open your editor to see real-time linting")
    return 0


def cmd_config(argv):
    if any(a in ("-h", "--help") for a in argv):
        print("Show configuration or query a specific key\n")
        print("Usage: executable config [OPTIONS] [COMMAND]\n")
        print("Commands:")
        print("  get   Query a specific config key")
        print("  file  Show the absolute path of the configuration file that was loaded")
        print("  help  Print this message or the help of the given subcommand(s)")
        return 0
    if argv and argv[0] == "file":
        for name in (".rumdl.toml", "rumdl.toml", "pyproject.toml"):
            p = os.path.abspath(name)
            if os.path.exists(p):
                print(p)
                return 0
        return 1
    if argv and argv[0] == "get" and len(argv) > 1:
        key = argv[1]
        defaults = {"global.respect_gitignore": "true", "MD013.line-length": "80", "MD007.indent": "2"}
        print(defaults.get(key, ""))
        return 0
    print("[global]")
    print("enable = []")
    print("disable = []")
    print("exclude = []")
    print("include = []")
    print("respect_gitignore = true")
    print("\n[MD013]")
    print("line-length = 80")
    print("code-blocks = true")
    print("tables = false")
    return 0


def cmd_explain(argv):
    code = (argv[0] if argv else "MD013").upper()
    if code not in RULE_BY_ID:
        print(f"error: unknown rule '{code}'", file=sys.stderr)
        return 1
    print(f"{code} - {rule_summary(code)}\n")
    print("What this rule does\n")
    print(rule_summary(code))
    print("\nExamples\n")
    print("✅ Correct\n\n```markdown\n# Heading\n```\n")
    print("❌ Incorrect\n\n```markdown\nTitle\n```\n")
    return 0


def main(argv):
    if len(argv) == 1 or argv[1] in ("-h", "--help", "help"):
        print("A fast Markdown linter written in Rust (Ru(st) MarkDown Linter)\n")
        print("Usage: executable [OPTIONS] <COMMAND>\n")
        print("Commands:")
        print("  check        Lint Markdown files and print warnings/errors")
        print("  fmt          Format Markdown files (alias for check --fix)")
        print("  init         Initialize a new configuration file")
        print("  rule         Show information about a rule or list all rules")
        print("  explain      Explain a rule with detailed information and examples")
        print("  config       Show configuration or query a specific key")
        print("  schema       Generate or check JSON schema for rumdl.toml")
        print("  completions  Generate shell completion scripts")
        print("  clean        Clear the cache")
        print("  version      Show version information")
        print("  help         Print this message or the help of the given subcommand(s)\n")
        print("Options:")
        print("      --color <COLOR>    Control colored output: auto, always, never [default: auto]")
        print("      --config <CONFIG>  Path to configuration file")
        print("      --no-config        Ignore all configuration files and use built-in defaults")
        print("  -h, --help             Print help")
        print("  -V, --version          Print version")
        return 0
    if argv[1] in ("-V", "--version", "version"):
        print(VERSION)
        return 0
    if argv[1] == "rule":
        return cmd_rule(argv[2:])
    if argv[1] == "explain":
        return cmd_explain(argv[2:])
    if argv[1] == "init":
        return cmd_init(argv[2:])
    if argv[1] == "config":
        return cmd_config(argv[2:])
    if argv[1] == "schema":
        print('{"$schema":"http://json-schema.org/draft-07/schema#","title":"rumdl configuration","type":"object"}')
        return 0
    if argv[1] == "completions":
        shell = argv[2] if len(argv) > 2 else "bash"
        print(f"# {shell} completions for rumdl")
        return 0
    if argv[1] in ("clean", "server", "vscode", "import"):
        if argv[1] == "clean":
            print("Cache cleared")
            return 0
        print(f"{argv[1]} command is not available in this reimplementation", file=sys.stderr)
        return 1
    if argv[1] == "check":
        return cmd_check(argv[2:])
    if argv[1] == "fmt":
        return cmd_check(argv[2:], force_fix=True)
    print(f"error: unrecognized command '{argv[1]}'", file=sys.stderr)
    return 2


if __name__ == "__main__":
    raise SystemExit(main(sys.argv))
