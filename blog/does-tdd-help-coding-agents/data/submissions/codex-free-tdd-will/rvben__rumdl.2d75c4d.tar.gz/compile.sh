#!/bin/bash
set -e
cp rumdl.py executable
chmod +x executable
