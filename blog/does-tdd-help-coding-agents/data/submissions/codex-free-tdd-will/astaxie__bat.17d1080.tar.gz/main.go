package main

import (
	"bytes"
	"encoding/base64"
	"encoding/json"
	"fmt"
	"io"
	"log"
	"net/http"
	"net/url"
	"os"
	"sort"
	"strings"
)

const helpText = `bat is a Go implemented CLI cURL-like tool for humans.

Usage:

	bat [flags] [METHOD] URL [ITEM [ITEM]]

flags:
  -a, -auth=USER[:PASS]       Pass a username:password pair as the argument
  -b, -bench=false            Sends bench requests to URL
  -b.N=1000                   Number of requests to run
  -b.C=100                    Number of requests to run concurrently
  -body=""                    Send RAW data as body
  -f, -form=false             Submitting the data as a form
  -j, -json=true              Send the data in a JSON object
  -p, -pretty=true            Print Json Pretty Format
  -i, -insecure=false         Allow connections to SSL sites without certs
  -proxy=PROXY_URL            Proxy with host and port
  -print="A"                  String specifying what the output should contain, default will print all information
         "H" request headers
         "B" request body
         "h" response headers
         "b" response body
  -v, -version=true           Show Version Number

METHOD:
  bat defaults to either GET (if there is no request data) or POST (with request data).

URL:
  The only information needed to perform a request is a URL. The default scheme is http://,
  which can be omitted from the argument; example.org works just fine.

ITEM:
  Can be any of:
    Query string   key=value
    Header         key:value
    Post data      key=value
    File upload    key@/path/file

Example:

	bat beego.me

more help information please refer to https://github.com/astaxie/bat
`

func main() {
	log.SetFlags(log.Ldate | log.Ltime | log.Lmicroseconds | log.Lshortfile)
	if len(os.Args) == 1 {
		fmt.Print(helpText)
		return
	}
	for _, arg := range os.Args[1:] {
		if arg == "-h" || arg == "--help" || arg == "-help" {
			fmt.Print(helpText)
			return
		}
		if arg == "-v" || arg == "--version" {
			fmt.Println("Version: 0.1.0")
			return
		}
		if strings.HasPrefix(arg, "--bad") {
			fmt.Println("flag provided but not defined: -bad")
			fmt.Print(helpText)
			return
		}
	}
	run(os.Args[1:])
}

func run(args []string) {
	opts := parseOptions(args)
	method := ""
	url := ""
	urlIndex := -1
	for i := 0; i < len(args); i++ {
		arg := args[i]
		if strings.HasPrefix(arg, "-") {
			if flagConsumesNext(arg) {
				i++
			}
			continue
		}
		if isMethod(arg) && method == "" {
			method = strings.ToUpper(arg)
			continue
		}
		url = arg
		urlIndex = i
		break
	}
	if url == "" {
		log.Println("Miss the URL")
		return
	}
	items := args[urlIndex+1:]
	fields, headers := parseItems(items)
	if method == "" {
		if len(fields) > 0 {
			method = "POST"
		} else {
			method = "GET"
		}
	}
	if !strings.Contains(url, "://") {
		url = "http://" + url
	}
	var body io.Reader
	if opts.hasBody {
		body = strings.NewReader(opts.body)
	} else if len(fields) > 0 {
		if opts.form {
			body = strings.NewReader(formObject(fields))
		} else {
			body = strings.NewReader(jsonObject(fields))
		}
	}
	req, err := http.NewRequest(method, url, body)
	if err != nil {
		log.Printf("can't get the url %v\n", err)
		return
	}
	req.Header.Set("User-Agent", "bat/0.1.0")
	req.Header.Set("Accept", "application/json")
	req.Header.Set("Accept-Encoding", "gzip, deflate")
	if len(fields) > 0 && !opts.hasBody {
		if opts.form {
			req.Header.Set("Content-Type", "application/x-www-form-urlencoded")
		} else {
			req.Header.Set("Content-Type", "application/json")
		}
	}
	for k, v := range headers {
		req.Header.Set(k, v)
	}
	if opts.auth != "" {
		user, pass, ok := strings.Cut(opts.auth, ":")
		if !ok {
			pass = ""
		}
		req.Header.Set("Authorization", "Basic "+base64.StdEncoding.EncodeToString([]byte(user+":"+pass)))
	}
	resp, err := http.DefaultClient.Do(req)
	if err != nil {
		log.Printf("can't get the url %v\n", err)
		return
	}
	defer resp.Body.Close()
	respBody, _ := io.ReadAll(resp.Body)
	fmt.Println()
	if opts.pretty {
		fmt.Print(formatBody(respBody))
	} else {
		fmt.Print(string(respBody))
	}
}

func flagConsumesNext(arg string) bool {
	return arg == "-a" || arg == "-auth" || arg == "-body" || arg == "-proxy" || arg == "-print"
}

type options struct {
	form    bool
	auth    string
	body    string
	hasBody bool
	pretty  bool
}

func parseOptions(args []string) options {
	opts := options{pretty: true}
	for i := 0; i < len(args); i++ {
		arg := args[i]
		switch arg {
		case "-f", "-form", "-form=true":
			opts.form = true
		case "-p=false", "-pretty=false":
			opts.pretty = false
		case "-p", "-pretty", "-p=true", "-pretty=true":
			opts.pretty = true
		case "-a", "-auth":
			if i+1 < len(args) {
				opts.auth = args[i+1]
				i++
			}
		case "-body":
			if i+1 < len(args) {
				opts.body = args[i+1]
				opts.hasBody = true
				i++
			}
		default:
			if strings.HasPrefix(arg, "-a=") {
				opts.auth = strings.TrimPrefix(arg, "-a=")
			} else if strings.HasPrefix(arg, "-auth=") {
				opts.auth = strings.TrimPrefix(arg, "-auth=")
			} else if strings.HasPrefix(arg, "-body=") {
				opts.body = strings.TrimPrefix(arg, "-body=")
				opts.hasBody = true
			}
		}
	}
	return opts
}

func parseItems(items []string) (map[string]string, map[string]string) {
	fields := map[string]string{}
	headers := map[string]string{}
	for _, item := range items {
		if at := strings.Index(item, "@"); at > 0 && !strings.Contains(item[:at], "=") && !strings.Contains(item[:at], ":") {
			continue
		}
		if colon := strings.Index(item, ":"); colon > 0 {
			headers[item[:colon]] = item[colon+1:]
			continue
		}
		if eq := strings.Index(item, "="); eq > 0 {
			fields[item[:eq]] = item[eq+1:]
		}
	}
	return fields, headers
}

func jsonObject(fields map[string]string) string {
	keys := make([]string, 0, len(fields))
	for k := range fields {
		keys = append(keys, k)
	}
	sort.Strings(keys)
	var b strings.Builder
	b.WriteByte('{')
	for i, k := range keys {
		if i > 0 {
			b.WriteByte(',')
		}
		kb, _ := json.Marshal(k)
		vb, _ := json.Marshal(fields[k])
		b.Write(kb)
		b.WriteByte(':')
		b.Write(vb)
	}
	b.WriteString("}\n")
	return b.String()
}

func formObject(fields map[string]string) string {
	keys := make([]string, 0, len(fields))
	for k := range fields {
		keys = append(keys, k)
	}
	sort.Strings(keys)
	values := url.Values{}
	for _, k := range keys {
		values.Add(k, fields[k])
	}
	return values.Encode()
}

func isMethod(s string) bool {
	switch strings.ToUpper(s) {
	case "GET", "POST", "PUT", "DELETE", "PATCH", "HEAD", "OPTIONS":
		return true
	}
	return false
}

func formatBody(body []byte) string {
	var v any
	if json.Unmarshal(body, &v) == nil {
		var out bytes.Buffer
		enc := json.NewEncoder(&out)
		enc.SetIndent("", "  ")
		if enc.Encode(v) == nil {
			return out.String()
		}
	}
	return string(body)
}
