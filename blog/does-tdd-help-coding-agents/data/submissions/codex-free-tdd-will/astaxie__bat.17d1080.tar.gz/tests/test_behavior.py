import os
import json
import subprocess
import threading
import unittest
from http.server import BaseHTTPRequestHandler, HTTPServer


ROOT = os.path.dirname(os.path.dirname(__file__))


class BatBehaviorTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        subprocess.run(["bash", "compile.sh"], cwd=ROOT, check=True)

    def run_bat(self, *args):
        return subprocess.run(
            [os.path.join(ROOT, "executable"), *args],
            cwd=ROOT,
            text=True,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            check=False,
        )

    def with_server(self, handler):
        server = HTTPServer(("127.0.0.1", 0), handler)
        thread = threading.Thread(target=server.serve_forever, daemon=True)
        thread.start()
        self.addCleanup(server.shutdown)
        self.addCleanup(server.server_close)
        return server

    def test_version_flag_prints_reference_version(self):
        result = self.run_bat("-v")
        self.assertEqual(result.returncode, 0)
        self.assertEqual(result.stdout, "Version: 0.1.0\n")

    def test_no_arguments_prints_help(self):
        result = self.run_bat()
        self.assertEqual(result.returncode, 0)
        self.assertIn("bat is a Go implemented CLI cURL-like tool for humans.", result.stdout)
        self.assertIn("Usage:\n\n\tbat [flags] [METHOD] URL [ITEM [ITEM]]", result.stdout)
        self.assertIn("-a, -auth=USER[:PASS]", result.stdout)

    def test_help_flag_prints_help(self):
        result = self.run_bat("--help")
        self.assertEqual(result.returncode, 0)
        self.assertIn("bat is a Go implemented CLI cURL-like tool for humans.", result.stdout)
        self.assertIn("METHOD:", result.stdout)

    def test_get_defaults_to_http_and_pretty_prints_json_response(self):
        seen = {}

        class Handler(BaseHTTPRequestHandler):
            def do_GET(self):
                seen["method"] = self.command
                seen["path"] = self.path
                seen["headers"] = dict(self.headers)
                self.send_response(200)
                self.send_header("Content-Type", "application/json")
                self.end_headers()
                self.wfile.write(b'{"ok":true,"items":[1,2]}')

            def log_message(self, *args):
                pass

        server = self.with_server(Handler)
        result = self.run_bat(f"127.0.0.1:{server.server_port}/api")
        self.assertEqual(result.returncode, 0)
        self.assertEqual(seen["method"], "GET")
        self.assertEqual(seen["path"], "/api")
        self.assertEqual(seen["headers"]["User-Agent"], "bat/0.1.0")
        self.assertEqual(seen["headers"]["Accept"], "application/json")
        self.assertEqual(seen["headers"]["Accept-Encoding"], "gzip, deflate")
        self.assertEqual(json.loads(result.stdout), {"ok": True, "items": [1, 2]})
        self.assertIn('\n  "items": [', result.stdout)

    def test_pretty_false_prints_json_response_without_reformatting(self):
        class Handler(BaseHTTPRequestHandler):
            def do_GET(self):
                self.send_response(200)
                self.send_header("Content-Type", "application/json")
                self.end_headers()
                self.wfile.write(b'{"z":1,"a":2}')

            def log_message(self, *args):
                pass

        server = self.with_server(Handler)
        result = self.run_bat("-p=false", f"127.0.0.1:{server.server_port}")
        self.assertEqual(result.returncode, 0)
        self.assertEqual(result.stdout, '\n{"z":1,"a":2}')

    def test_key_value_items_default_to_post_json_body(self):
        seen = {}

        class Handler(BaseHTTPRequestHandler):
            def do_POST(self):
                length = int(self.headers.get("Content-Length", "0"))
                seen["method"] = self.command
                seen["headers"] = dict(self.headers)
                seen["body"] = self.rfile.read(length).decode()
                self.send_response(200)
                self.send_header("Content-Type", "text/plain")
                self.end_headers()
                self.wfile.write(b"ok")

            def log_message(self, *args):
                pass

        server = self.with_server(Handler)
        result = self.run_bat(f"127.0.0.1:{server.server_port}", "name=John", "email=john@example.org")
        self.assertEqual(result.returncode, 0)
        self.assertEqual(seen["method"], "POST")
        self.assertEqual(seen["headers"]["Content-Type"], "application/json")
        self.assertEqual(seen["body"], '{"email":"john@example.org","name":"John"}\n')
        self.assertEqual(result.stdout, "\nok")

    def test_form_flag_sends_urlencoded_body(self):
        seen = {}

        class Handler(BaseHTTPRequestHandler):
            def do_POST(self):
                length = int(self.headers.get("Content-Length", "0"))
                seen["headers"] = dict(self.headers)
                seen["body"] = self.rfile.read(length).decode()
                self.send_response(200)
                self.end_headers()
                self.wfile.write(b"ok")

            def log_message(self, *args):
                pass

        server = self.with_server(Handler)
        result = self.run_bat("-form=true", "POST", f"127.0.0.1:{server.server_port}", "hello=World", "x=a b")
        self.assertEqual(result.returncode, 0)
        self.assertEqual(seen["headers"]["Content-Type"], "application/x-www-form-urlencoded")
        self.assertEqual(seen["body"], "hello=World&x=a+b")

    def test_auth_flag_sets_basic_authorization_header(self):
        seen = {}

        class Handler(BaseHTTPRequestHandler):
            def do_GET(self):
                seen["headers"] = dict(self.headers)
                self.send_response(200)
                self.end_headers()
                self.wfile.write(b"ok")

            def log_message(self, *args):
                pass

        server = self.with_server(Handler)
        result = self.run_bat("-a", "user:pass", f"127.0.0.1:{server.server_port}")
        self.assertEqual(result.returncode, 0)
        self.assertEqual(seen["headers"]["Authorization"], "Basic dXNlcjpwYXNz")

    def test_body_flag_sends_raw_body_without_json_content_type(self):
        seen = {}

        class Handler(BaseHTTPRequestHandler):
            def do_POST(self):
                length = int(self.headers.get("Content-Length", "0"))
                seen["headers"] = dict(self.headers)
                seen["body"] = self.rfile.read(length).decode()
                self.send_response(200)
                self.end_headers()
                self.wfile.write(b"ok")

            def log_message(self, *args):
                pass

        server = self.with_server(Handler)
        result = self.run_bat("-body=hello", "POST", f"127.0.0.1:{server.server_port}")
        self.assertEqual(result.returncode, 0)
        self.assertEqual(seen["body"], "hello")
        self.assertNotIn("Content-Type", seen["headers"])


if __name__ == "__main__":
    unittest.main()
