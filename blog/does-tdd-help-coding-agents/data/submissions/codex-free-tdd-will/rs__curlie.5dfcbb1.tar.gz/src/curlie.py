#!/usr/bin/env python3
import json
import subprocess
import sys
from urllib.parse import quote_plus


def render_json(value):
    return json.dumps(value, separators=(",", ":"))


def color_json(value):
    white = "\x1b[37m"
    blue = "\x1b[34m"
    cyan = "\x1b[36m"
    magenta = "\x1b[35m"
    reset = "\x1b[0m"

    def scalar(v, object_value=False):
        if isinstance(v, str):
            color = cyan if object_value else blue
            return color + json.dumps(v, separators=(",", ":"))
        if v is True:
            text = "true"
            return (magenta if object_value else "") + text
        if v is False:
            text = "false"
            return (magenta if object_value else "") + text
        if v is None:
            text = "null"
            return (magenta if object_value else "") + text
        text = json.dumps(v, separators=(",", ":"))
        return (cyan if object_value else "") + text

    def emit(v, indent=0, object_value=False):
        pad = " " * indent
        child_pad = " " * (indent + 4)
        if isinstance(v, dict):
            if not v:
                return white + "{}"
            lines = [white + "{"]
            items = list(v.items())
            for idx, (key, val) in enumerate(items):
                comma = white + "," if idx + 1 < len(items) else ""
                rendered = emit(val, indent + 4, object_value=True)
                lines.append(
                    f"{child_pad}{blue}{json.dumps(str(key))}{white}: {rendered}{comma}"
                )
            lines.append(pad + white + "}")
            return "\n".join(lines)
        if isinstance(v, list):
            if not v:
                return white + "[]"
            lines = [white + "["]
            for idx, val in enumerate(v):
                comma = white + "," if idx + 1 < len(v) else ""
                lines.append(f"{child_pad}{emit(val, indent + 4)}{comma}")
            lines.append(pad + white + "]")
            return "\n".join(lines)
        return scalar(v, object_value=object_value)

    return emit(value) + "\n" + reset


def normalize_for_stderr(url):
    if url.startswith("http://") or url.startswith("https://"):
        return url
    return "http://" + url


def shell_word(arg):
    if arg == "":
        return '""'
    if any(c.isspace() for c in arg):
        return '"' + arg.replace("\\", "\\\\").replace('"', '\\"') + '"'
    return arg


USAGE = "Usage: /workspace/executable [options...] [METHOD] URL [REQUEST_ITEM [REQUEST_ITEM ...]]"
CATEGORY_HELP = """Invalid category provided, here is a list of all categories:

 auth        Different types of authentication methods
 connection  Low level networking operations
 curl        The command line tool itself
 dns         General DNS options
 file        FILE protocol options
 ftp         FTP protocol options
 http        HTTP and HTTPS protocol options
 imap        IMAP protocol options
 misc        Options that don't fit into any other category
 output      Filesystem output
 pop3        POP3 protocol options
 post        HTTP Post specific options
 proxy       All options related to proxies
 scp         SCP protocol options
 sftp        SFTP protocol options
 smtp        SMTP protocol options
 ssh         SSH protocol options
 telnet      TELNET protocol options
 tftp        TFTP protocol options
 tls         All TLS/SSL related options
 upload      All options for uploads
 verbose     Options related to any kind of command line output of curl"""


def print_curl_help(category):
    print(USAGE)
    result = subprocess.run(["curl", "--help", category], capture_output=True, text=True)
    lines = result.stdout.splitlines()
    if lines and lines[0].startswith("Usage: curl "):
        lines = lines[1:]
    if lines:
        print("\n".join(lines))
    return result.returncode


def build_command(args):
    curl = False
    rest = []
    for arg in args:
        if arg == "--curl":
            curl = True
        else:
            rest.append(arg)
    if not curl:
        pass

    method = None
    url = None
    items = []
    passthrough = []
    curl_opts_with_arg = {
        "-A",
        "--user-agent",
        "-b",
        "--cookie",
        "-c",
        "--cookie-jar",
        "-d",
        "--data",
        "--data-ascii",
        "--data-binary",
        "--data-raw",
        "--data-urlencode",
        "-F",
        "--form",
        "--form-string",
        "-H",
        "--header",
        "-o",
        "--output",
        "-u",
        "--user",
        "-X",
        "--request",
        "--json",
        "--connect-timeout",
        "--max-time",
        "--proxy",
    }
    methods = {
        "GET",
        "POST",
        "PUT",
        "PATCH",
        "DELETE",
        "HEAD",
        "OPTIONS",
        "TRACE",
        "CONNECT",
    }
    form_mode = False
    pretty = False
    i = 0
    while i < len(rest):
        arg = rest[i]
        if url is None and arg == "--pretty":
            pretty = True
            i += 1
            continue
        if url is None and arg == "--form":
            form_mode = True
            i += 1
            continue
        if url is None and arg.startswith("-") and arg != "-":
            passthrough.append(arg)
            opt_name = arg.split("=", 1)[0]
            if "=" not in arg and opt_name in curl_opts_with_arg and i + 1 < len(rest):
                i += 1
                passthrough.append(rest[i])
            i += 1
            continue
        if url is None and method is None and arg.upper() in methods and i + 1 < len(rest):
            method = arg.upper()
        elif url is None:
            url = arg
        else:
            items.append(arg)
        i += 1
    if url is None:
        url = ""

    query = []
    data = {}
    form_parts = []
    headers = []
    for item in items:
        if "==" in item:
            k, v = item.split("==", 1)
            query.append((k, v))
        elif ":=" in item:
            k, v = item.split(":=", 1)
            try:
                data[k] = json.loads(v)
            except json.JSONDecodeError:
                data[k] = None
        elif form_mode and "=" in item:
            form_parts.extend(["-F", item])
        elif "=" in item:
            k, v = item.split("=", 1)
            data[k] = v
        elif ":" in item:
            headers.extend(["-H", item])
        else:
            passthrough.append(item)

    display_url = url
    command_url = "localhost" + url if url.startswith(":") else url
    url_with_query = command_url
    display_url_with_query = display_url
    if query:
        sep = "&" if "?" in url_with_query else "?"
        encoded_query = "&".join(
            quote_plus(k) + "=" + quote_plus(v) for k, v in query
        )
        url_with_query += sep + encoded_query
        display_sep = "&" if "?" in display_url_with_query else "?"
        display_url_with_query += display_sep + encoded_query

    cmd = ["curl"] + passthrough
    if method is not None:
        cmd += ["-X", method]
    cmd += headers
    if data:
        cmd += ["-d", render_json(dict(sorted(data.items())))]
    if form_parts:
        cmd += form_parts
    cmd += [url_with_query, "-s", "-S"]
    if pretty and curl:
        cmd += ["-v"]
    if not data:
        cmd += ["-d@-"]
    if not form_mode:
        cmd += ["-H", "Content-Type: application/json"]
    cmd += ["-H", "Accept: application/json, */*"]
    return cmd, normalize_for_stderr(display_url_with_query), curl, pretty


def main(argv):
    if not argv:
        return print_curl_help("all")
    if argv[0] in ("--help", "-h"):
        if len(argv) > 1 and argv[1] != "":
            return print_curl_help(argv[1])
        print(USAGE)
        print(CATEGORY_HELP)
        return 0
    if argv[0] in ("--version", "-V"):
        return subprocess.run(["curl", "--version"]).returncode

    built = build_command(argv)
    cmd, display_url, dry_run, pretty = built
    print(display_url, file=sys.stderr)
    if dry_run:
        print(" ".join(shell_word(a) for a in cmd))
        return 0
    if pretty:
        result = subprocess.run(cmd, stdin=sys.stdin.buffer, capture_output=True)
        if result.stderr:
            sys.stderr.buffer.write(result.stderr)
        try:
            parsed = json.loads(result.stdout.decode())
        except (UnicodeDecodeError, json.JSONDecodeError):
            sys.stdout.buffer.write(result.stdout)
        else:
            sys.stdout.write(color_json(parsed))
        return result.returncode
    return subprocess.run(cmd, stdin=sys.stdin.buffer).returncode


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
