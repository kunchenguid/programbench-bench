import subprocess
import sys
import tempfile
import unittest
from pathlib import Path


CMD = [sys.executable, "src/curlie.py"]


class CurlieCliTests(unittest.TestCase):
    def run_cli(self, *args):
        return subprocess.run(CMD + list(args), capture_output=True, text=True)

    def test_curl_dry_run_builds_json_body_and_query(self):
        result = self.run_cli("--curl", "example.org", "a=b", "q==x")

        self.assertEqual(result.returncode, 0)
        self.assertEqual(
            result.stdout,
            'curl -d {"a":"b"} example.org?q=x -s -S -H "Content-Type: application/json" -H "Accept: application/json, */*"\n',
        )
        self.assertEqual(result.stderr, "http://example.org?q=x\n")

    def test_curl_dry_run_keeps_options_before_method_and_url(self):
        result = self.run_cli("--curl", "-v", "PATCH", "http://example.org", "n:=123")

        self.assertEqual(result.returncode, 0)
        self.assertEqual(
            result.stdout,
            'curl -v -X PATCH -d {"n":123} http://example.org -s -S -H "Content-Type: application/json" -H "Accept: application/json, */*"\n',
        )
        self.assertEqual(result.stderr, "http://example.org\n")

    def test_headers_and_query_parameters_keep_original_order(self):
        result = self.run_cli(
            "--curl", "GET", "example.org/path?z=1", "X-Name:A B", "q==a b", "q==c+d"
        )

        self.assertEqual(result.returncode, 0)
        self.assertEqual(
            result.stdout,
            'curl -X GET -H "X-Name:A B" example.org/path?z=1&q=a+b&q=c%2Bd -s -S -d@- -H "Content-Type: application/json" -H "Accept: application/json, */*"\n',
        )
        self.assertEqual(result.stderr, "http://example.org/path?z=1&q=a+b&q=c%2Bd\n")

    def test_form_mode_translates_request_items_to_curl_form_parts(self):
        result = self.run_cli("--curl", "--form", "POST", "example.org", "a=b")

        self.assertEqual(result.returncode, 0)
        self.assertEqual(
            result.stdout,
            'curl -X POST -F a=b example.org -s -S -d@- -H "Accept: application/json, */*"\n',
        )
        self.assertEqual(result.stderr, "http://example.org\n")

    def test_executes_curl_for_file_urls(self):
        with tempfile.NamedTemporaryFile("w", delete=False) as tmp:
            tmp.write('{"ok":true}')
            path = tmp.name
        self.addCleanup(lambda: Path(path).unlink(missing_ok=True))

        result = self.run_cli(f"file://{path}")

        self.assertEqual(result.returncode, 0)
        self.assertEqual(result.stdout, '{"ok":true}')
        self.assertEqual(result.stderr, f"http://file://{path}\n")

    def test_pretty_dry_run_maps_to_verbose_curl(self):
        result = self.run_cli("--curl", "--pretty", "GET", "example.org")

        self.assertEqual(result.returncode, 0)
        self.assertEqual(
            result.stdout,
            'curl -X GET example.org -s -S -v -d@- -H "Content-Type: application/json" -H "Accept: application/json, */*"\n',
        )
        self.assertEqual(result.stderr, "http://example.org\n")

    def test_colon_prefixed_url_uses_localhost_for_curl_command_only(self):
        result = self.run_cli("--curl", ":8000/path")

        self.assertEqual(result.returncode, 0)
        self.assertEqual(
            result.stdout,
            'curl localhost:8000/path -s -S -d@- -H "Content-Type: application/json" -H "Accept: application/json, */*"\n',
        )
        self.assertEqual(result.stderr, "http://:8000/path\n")

    def test_pretty_exec_formats_json_object_with_colors(self):
        with tempfile.NamedTemporaryFile("w", delete=False) as tmp:
            tmp.write('{"s":"x","n":12,"f":false,"z":null}')
            path = tmp.name
        self.addCleanup(lambda: Path(path).unlink(missing_ok=True))

        result = self.run_cli("--pretty", f"file://{path}")

        self.assertEqual(result.returncode, 0)
        self.assertEqual(
            result.stdout,
            '\x1b[37m{\n    \x1b[34m"s"\x1b[37m: \x1b[36m"x"\x1b[37m,\n    \x1b[34m"n"\x1b[37m: \x1b[36m12\x1b[37m,\n    \x1b[34m"f"\x1b[37m: \x1b[35mfalse\x1b[37m,\n    \x1b[34m"z"\x1b[37m: \x1b[35mnull\n\x1b[37m}\n\x1b[0m',
        )
        self.assertEqual(result.stderr, f"http://file://{path}\n")

    def test_bare_help_lists_categories(self):
        result = self.run_cli("--help")

        self.assertEqual(result.returncode, 0)
        self.assertTrue(result.stdout.startswith("Usage: /workspace/executable "))
        self.assertIn("Invalid category provided, here is a list of all categories:", result.stdout)
        self.assertIn(" auth        Different types of authentication methods", result.stdout)
        self.assertEqual(result.stderr, "")

    def test_no_args_shows_curl_option_help_after_custom_usage(self):
        result = self.run_cli()

        self.assertEqual(result.returncode, 0)
        self.assertTrue(result.stdout.startswith("Usage: /workspace/executable "))
        self.assertIn("--abstract-unix-socket", result.stdout)
        self.assertNotIn("Usage: curl [options...]", result.stdout)
        self.assertEqual(result.stderr, "")


if __name__ == "__main__":
    unittest.main()
