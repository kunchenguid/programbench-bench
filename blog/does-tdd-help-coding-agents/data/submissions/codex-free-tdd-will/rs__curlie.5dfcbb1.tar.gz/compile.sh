#!/bin/bash
set -e
cp src/curlie.py executable
chmod +x executable
