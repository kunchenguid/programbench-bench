#!/usr/bin/env python3
import sys
from pathlib import Path


VERSION = "1.4.1"
HELP = """  json-tui {OPTIONS} [file]

    A JSON terminal UI

  OPTIONS:

      file                              A JSON file. Omit to read from stdin.
      -h, --help                        Display this help menu.
      -v, --version                     Print version.
      -k, --key, --keybinding           Display key binding.
      -f, --fullscreen                  Display the JSON in fullscreen, in an
                                        alternate buffer
      "--" can be used to terminate flag options and force all following
      arguments to be treated as positional options

    If no file is given, json-tui reads JSON from the standard input
    Please report bugs to:https://github.com/ArthurSonzogni/json-tui/issues
"""
KEYBINDING = (
    "┌───────────┬────────────────┐\n"
    "│\x1b[36m\x1b[49mkeys       \x1b[39m\x1b[49m│\x1b[36m\x1b[49maction          \x1b[39m\x1b[49m│\n"
    "├───────────┼────────────────┤\n"
    "│Navigate   │← ↑ ↓ →         │\n"
    "│           │h j k l         │\n"
    "│           │Mouse::WheelUp  │\n"
    "│           │Mouse::WheelDown│\n"
    "├───────────┼────────────────┤\n"
    "│Toggle     │enter           │\n"
    "│           │Mouse::Left     │\n"
    "├───────────┼────────────────┤\n"
    "│Deep       │                │\n"
    "│ - Expand  │+               │\n"
    "│ - Collapse│-               │\n"
    "├───────────┼────────────────┤\n"
    "│Exit       │Escape          │\n"
    "│           │q               │\n"
    "├───────────┼────────────────┤\n"
    "│Navigate   │                │\n"
    "│ - first   │page-up         │\n"
    "│ - last    │page-down       │\n"
    "│ - top     │gg              │\n"
    "│ - bottom  │G               │\n"
    "└───────────┴────────────────┘\x00\n"
)


class JsonParseError(Exception):
    def __init__(self, message, pos):
        super().__init__(message)
        self.pos = pos


class JsonParser:
    def __init__(self, text):
        self.text = text
        self.pos = 0

    def parse(self):
        value = self.parse_value()
        self.skip_ws()
        if self.pos != len(self.text):
            raise JsonParseError("expected end of input", self.pos)
        return value

    def peek(self):
        return self.text[self.pos] if self.pos < len(self.text) else ""

    def take(self, expected=None):
        if self.pos >= len(self.text):
            raise JsonParseError("unexpected end of input", self.pos)
        ch = self.text[self.pos]
        if expected is not None and ch != expected:
            raise JsonParseError(f"expected {expected!r}", self.pos)
        self.pos += 1
        return ch

    def skip_ws(self):
        while self.peek() and self.peek() in " \t\r\n":
            self.pos += 1

    def parse_value(self):
        self.skip_ws()
        ch = self.peek()
        if ch == "{":
            return self.parse_object()
        if ch == "[":
            return self.parse_array()
        if ch == '"':
            return self.parse_string()
        if ch == "-" or ch.isdigit():
            return self.parse_number()
        if self.text.startswith("true", self.pos):
            self.pos += 4
            return True
        if self.text.startswith("false", self.pos):
            self.pos += 5
            return False
        if self.text.startswith("null", self.pos):
            self.pos += 4
            return None
        raise JsonParseError("syntax error while parsing value", self.pos)

    def parse_object(self):
        items = []
        self.take("{")
        self.skip_ws()
        if self.peek() == "}":
            self.pos += 1
            return {"__json_object__": items}
        while True:
            self.skip_ws()
            if self.peek() != '"':
                raise JsonParseError("expected string literal", self.pos)
            key = self.parse_string()
            self.skip_ws()
            self.take(":")
            items.append((key, self.parse_value()))
            self.skip_ws()
            ch = self.take()
            if ch == "}":
                return {"__json_object__": items}
            if ch != ",":
                raise JsonParseError("expected ',' or '}'", self.pos - 1)

    def parse_array(self):
        items = []
        self.take("[")
        self.skip_ws()
        if self.peek() == "]":
            self.pos += 1
            return items
        while True:
            items.append(self.parse_value())
            self.skip_ws()
            ch = self.take()
            if ch == "]":
                return items
            if ch != ",":
                raise JsonParseError("expected ',' or ']'", self.pos - 1)

    def parse_string(self):
        self.take('"')
        out = []
        while True:
            ch = self.take()
            if ch == '"':
                return "".join(out)
            if ch == "\\":
                esc = self.take()
                if esc == '"':
                    out.append('"')
                elif esc == "\\":
                    out.append("\\")
                elif esc == "/":
                    out.append("/")
                elif esc == "b":
                    out.append("\b")
                elif esc == "f":
                    out.append("\f")
                elif esc == "n":
                    out.append("\n")
                elif esc == "r":
                    out.append("\r")
                elif esc == "t":
                    out.append("\t")
                elif esc == "u":
                    digits = self.text[self.pos : self.pos + 4]
                    if len(digits) != 4 or any(c not in "0123456789abcdefABCDEF" for c in digits):
                        raise JsonParseError("invalid unicode escape", self.pos)
                    out.append(chr(int(digits, 16)))
                    self.pos += 4
                else:
                    raise JsonParseError("invalid escape", self.pos - 1)
            elif ord(ch) < 0x20:
                raise JsonParseError("invalid string character", self.pos - 1)
            else:
                out.append(ch)

    def parse_number(self):
        start = self.pos
        if self.peek() == "-":
            self.pos += 1
        if self.peek() == "0":
            self.pos += 1
        elif self.peek().isdigit():
            while self.peek().isdigit():
                self.pos += 1
        else:
            raise JsonParseError("invalid number", self.pos)
        if self.peek() == ".":
            self.pos += 1
            if not self.peek().isdigit():
                raise JsonParseError("invalid number", self.pos)
            while self.peek().isdigit():
                self.pos += 1
        if self.peek() and self.peek() in "eE":
            self.pos += 1
            if self.peek() and self.peek() in "+-":
                self.pos += 1
            if not self.peek().isdigit():
                raise JsonParseError("invalid number", self.pos)
            while self.peek().isdigit():
                self.pos += 1
        token = self.text[start : self.pos]
        if any(c in token for c in ".eE"):
            return float(token)
        return int(token)


def quote_string(value):
    replacements = {
        "\\": "\\\\",
        '"': '\\"',
        "\b": "\\b",
        "\f": "\\f",
        "\n": "\\n",
        "\r": "\\r",
        "\t": "\\t",
    }
    return '"' + "".join(replacements.get(ch, ch) for ch in value) + '"'


def format_json(value, indent=0):
    pad = "  " * indent
    child_pad = "  " * (indent + 1)
    if isinstance(value, dict) and "__json_object__" in value:
        items = value["__json_object__"]
        if not items:
            return "{}"
        lines = ["{"]
        for index, (key, item) in enumerate(items):
            comma = "," if index + 1 < len(items) else ""
            lines.append(f"{child_pad}{quote_string(key)}: {format_json(item, indent + 1)}{comma}")
        lines.append(f"{pad}}}")
        return "\n".join(lines)
    if isinstance(value, list):
        if not value:
            return "[]"
        lines = ["["]
        for index, item in enumerate(value):
            comma = "," if index + 1 < len(value) else ""
            lines.append(f"{child_pad}{format_json(item, indent + 1)}{comma}")
        lines.append(f"{pad}]")
        return "\n".join(lines)
    if isinstance(value, str):
        return quote_string(value)
    if value is True:
        return "true"
    if value is False:
        return "false"
    if value is None:
        return "null"
    return str(value)


def read_input(argv):
    if argv:
        path = Path(argv[0])
        try:
            return path.read_text()
        except OSError:
            print(f"Could not open file {argv[0]}")
            return None
    print("Reading from stdin...")
    return sys.stdin.read()


def parse_args(argv):
    flags = set()
    files = []
    positional = False
    for arg in argv:
        if positional:
            files.append(arg)
            continue
        if arg == "--":
            positional = True
        elif arg in ("--help", "--version", "--key", "--keybinding", "--fullscreen"):
            flags.add(arg[2:])
        elif arg.startswith("--"):
            return None, None
        elif arg.startswith("-") and arg != "-":
            for ch in arg[1:]:
                if ch == "h":
                    flags.add("help")
                elif ch == "v":
                    flags.add("version")
                elif ch == "k":
                    flags.add("keybinding")
                elif ch == "f":
                    flags.add("fullscreen")
                else:
                    return None, None
        else:
            files.append(arg)
    if len(files) > 1:
        return None, None
    return flags, files


def main(argv):
    flags, files = parse_args(argv)
    if flags is None:
        print("Invalid arguments")
        return 1
    if "version" in flags:
        print(VERSION)
        return 0
    if "help" in flags:
        sys.stdout.write(HELP)
        return 0
    if "key" in flags or "keybinding" in flags:
        sys.stdout.write(KEYBINDING)
        return 0
    text = read_input(files)
    if text is None:
        return 1
    try:
        value = JsonParser(text).parse()
    except JsonParseError as exc:
        print(f"\n[json.exception.parse_error.101] parse error: {exc}")
        return 1
    print(format_json(value))
    return 0


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
