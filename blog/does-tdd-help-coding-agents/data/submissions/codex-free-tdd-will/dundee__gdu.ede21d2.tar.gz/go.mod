module gdu-reimpl

go 1.20
