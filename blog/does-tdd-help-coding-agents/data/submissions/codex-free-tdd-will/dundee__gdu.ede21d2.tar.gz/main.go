package main

import (
	"encoding/json"
	"fmt"
	"os"
	"path/filepath"
	"regexp"
	"sort"
	"strconv"
	"strings"
	"syscall"
	"time"
)

type Options struct {
	nonInteractive bool
	noProgress     bool
	apparent       bool
	summarize      bool
	noPrefix       bool
	si             bool
	reverse        bool
	noHidden       bool
	depth          int
	top            int
	outputFile     string
	inputFile      string
	writeConfig    bool
	types          map[string]bool
	excludeTypes   map[string]bool
	ignoreDirs     []string
	ignorePatterns []*regexp.Regexp
	since          *time.Time
	until          *time.Time
}

type Node struct {
	Name     string
	Path     string
	IsDir    bool
	IsLink   bool
	Empty    bool
	ASize    int64
	DSize    int64
	TotalA   int64
	TotalD   int64
	Children []*Node
	FromJSON  bool
}

func main() {
	opts, args, err := parseArgs(os.Args[1:])
	if err != nil {
		fmt.Fprintln(os.Stderr, err)
		os.Exit(1)
	}
	if opts == nil {
		return
	}
	if opts.writeConfig {
		_ = writeConfigFile()
	}
	target := "."
	if len(args) > 0 {
		target = args[0]
	}
	var root *Node
	if opts.inputFile != "" {
		root, err = readJSON(opts.inputFile)
	} else {
		root, err = scan(target, opts)
	}
	if err != nil {
		fmt.Fprintf(os.Stderr, "Error: %v\n", err)
		os.Exit(1)
	}
	if opts.outputFile != "" {
		if err := writeJSON(root, opts.outputFile); err != nil {
			fmt.Fprintf(os.Stderr, "Error: %v\n", err)
			os.Exit(1)
		}
		return
	}
	printOutput(root, opts)
}

func parseArgs(args []string) (*Options, []string, error) {
	opts := &Options{depth: 0, ignoreDirs: []string{"/proc", "/dev", "/sys", "/run"}}
	var paths []string
	for i := 0; i < len(args); i++ {
		arg := args[i]
		if arg == "--version" || arg == "-v" {
			fmt.Println("Version:\t dev")
			fmt.Println("Built time:\t Fri Apr 17 19:59:35 UTC 2026")
			fmt.Println("Built user:\t root")
			return nil, nil, nil
		}
		if arg == "--help" || arg == "-h" {
			printHelp()
			return nil, nil, nil
		}
		if strings.HasPrefix(arg, "--") {
			name, val, hasVal := strings.Cut(arg, "=")
			needVal := func() (string, error) {
				if hasVal {
					return val, nil
				}
				i++
				if i >= len(args) {
					return "", fmt.Errorf("Error: flag needs an argument: %s", name)
				}
				return args[i], nil
			}
			switch name {
			case "--show-apparent-size":
				opts.apparent = true
			case "--show-disks":
				printDisks()
				return nil, nil, nil
			case "--summarize":
				opts.summarize = true
			case "--no-prefix":
				opts.noPrefix = true
			case "--si":
				opts.si = true
			case "--reverse-sort":
				opts.reverse = true
			case "--no-hidden":
				opts.noHidden = true
			case "--depth":
				v, e := needVal()
				if e != nil {
					return nil, nil, e
				}
				opts.depth, _ = strconv.Atoi(v)
			case "--top":
				v, e := needVal()
				if e != nil {
					return nil, nil, e
				}
				opts.top, _ = strconv.Atoi(v)
			case "--output-file":
				v, e := needVal()
				if e != nil {
					return nil, nil, e
				}
				opts.outputFile = v
			case "--input-file":
				v, e := needVal()
				if e != nil {
					return nil, nil, e
				}
				opts.inputFile = v
			case "--type":
				v, e := needVal()
				if e != nil {
					return nil, nil, e
				}
				opts.types = parseTypes(v)
			case "--exclude-type":
				v, e := needVal()
				if e != nil {
					return nil, nil, e
				}
				opts.excludeTypes = parseTypes(v)
			case "--since":
				v, e := needVal()
				if e != nil {
					return nil, nil, e
				}
				t, e := parseWhen(v, false)
				if e != nil {
					return nil, nil, e
				}
				opts.since = &t
			case "--until":
				v, e := needVal()
				if e != nil {
					return nil, nil, e
				}
				t, e := parseWhen(v, true)
				if e != nil {
					return nil, nil, e
				}
				opts.until = &t
			case "--write-config":
				opts.writeConfig = true
			case "--config-file", "--db", "--log-file", "--max-cores", "--storage", "--max-age", "--min-age", "--ignore-dirs", "--ignore-dirs-pattern", "--ignore-from":
				v, e := needVal()
				if e != nil {
					return nil, nil, e
				}
				switch name {
				case "--ignore-dirs":
					opts.ignoreDirs = append(opts.ignoreDirs, splitCSV(v)...)
				case "--ignore-dirs-pattern":
					for _, p := range splitCSV(v) {
						if re, err := regexp.Compile(p); err == nil {
							opts.ignorePatterns = append(opts.ignorePatterns, re)
						}
					}
				case "--ignore-from":
					loadIgnoreFile(v, opts)
				}
			case "--mouse", "--no-color", "--no-cross", "--no-delete", "--no-spawn-shell", "--no-unicode", "--sequential", "--read-from-storage", "--show-annexed-size", "--show-in-kib", "--show-item-count", "--show-mtime", "--show-relative-size", "--use-git-ignore", "--follow-symlinks", "--archive-browsing", "--collapse-path", "--enable-profiling":
				// Accepted for CLI compatibility. These are interactive, UI, or storage details.
			default:
				return nil, nil, fmt.Errorf("Error: unknown flag: %s", name)
			}
			continue
		}
		if strings.HasPrefix(arg, "-") && arg != "-" {
			short := []rune(arg[1:])
			for pos := 0; pos < len(short); pos++ {
				ch := short[pos]
				rest := ""
				if pos+1 < len(short) {
					rest = string(short[pos+1:])
				}
				needShortVal := func() (string, error) {
					if rest != "" {
						pos = len(short)
						return rest, nil
					}
					i++
					if i >= len(args) {
						return "", fmt.Errorf("Error: flag needs an argument: -%c", ch)
					}
					return args[i], nil
				}
				switch ch {
				case 'n':
					opts.nonInteractive = true
				case 'p':
					opts.noProgress = true
				case 'a':
					opts.apparent = true
				case 's':
					opts.summarize = true
				case 'H':
					opts.noHidden = true
				case 'T':
					v, e := needShortVal()
					if e != nil {
						return nil, nil, e
					}
					opts.types = parseTypes(v)
				case 'E':
					v, e := needShortVal()
					if e != nil {
						return nil, nil, e
					}
					opts.excludeTypes = parseTypes(v)
				case 'i':
					v, e := needShortVal()
					if e != nil {
						return nil, nil, e
					}
					opts.ignoreDirs = append(opts.ignoreDirs, splitCSV(v)...)
				case 'I':
					v, e := needShortVal()
					if e != nil {
						return nil, nil, e
					}
					for _, p := range splitCSV(v) {
						if re, err := regexp.Compile(p); err == nil {
							opts.ignorePatterns = append(opts.ignorePatterns, re)
						}
					}
				case 'X':
					v, e := needShortVal()
					if e != nil {
						return nil, nil, e
					}
					loadIgnoreFile(v, opts)
				case 'o':
					v, e := needShortVal()
					if e != nil {
						return nil, nil, e
					}
					opts.outputFile = v
				case 'f':
					v, e := needShortVal()
					if e != nil {
						return nil, nil, e
					}
					opts.inputFile = v
				case 'd':
					printDisks()
					return nil, nil, nil
				case 'D', 'l', 'm':
					if _, e := needShortVal(); e != nil {
						return nil, nil, e
					}
				case 't':
					v, e := needShortVal()
					if e != nil {
						return nil, nil, e
					}
					opts.top, _ = strconv.Atoi(v)
				case 'r', 'g':
					// Compatibility flags.
				case 'k', 'c', 'u', 'x', 'L', 'A', 'B', 'C', 'M':
					// Accepted for CLI compatibility. Some affect only the full-screen UI.
				default:
					return nil, nil, fmt.Errorf("Error: unknown shorthand flag: %q in -%c", string(ch), ch)
				}
			}
			continue
		}
		paths = append(paths, arg)
	}
	return opts, paths, nil
}

func printHelp() {
	fmt.Println(`Pretty fast disk usage analyzer written in Go.

Usage:
  gdu [directory_to_scan] [flags]

Flags:
      --archive-browsing              Enable browsing of zip/jar archives
      --collapse-path                 Collapse single-child directory chains
      --config-file string            Read config from file (default is $HOME/.gdu.yaml)
  -D, --db string                     Store analysis in database (*.sqlite for SQLite, *.badger for BadgerDB)
      --depth int                     Show directory structure up to specified depth in non-interactive mode (0 means the flag is ignored)
      --enable-profiling              Enable collection of profiling data and provide it on http://localhost:6060/debug/pprof/
  -E, --exclude-type strings          File types to exclude (e.g., --exclude-type yaml,json)
  -L, --follow-symlinks               Follow symlinks for files, i.e. show the size of the file to which symlink points to (symlinks to directories are not followed)
  -h, --help                          help for gdu
  -i, --ignore-dirs strings           Paths to ignore (separated by comma). Can be absolute or relative to current directory (default [/proc,/dev,/sys,/run])
  -I, --ignore-dirs-pattern strings   Path patterns to ignore (separated by comma)
  -X, --ignore-from string            Read path patterns to ignore from file
  -f, --input-file string             Import analysis from JSON file
  -l, --log-file string               Path to a logfile (default "/dev/null")
      --max-age string                Include files with mtime no older than DURATION (e.g., 7d, 2h30m, 1y2mo)
  -m, --max-cores int                 Set max cores that Gdu will use. 16 cores available (default 16)
      --min-age string                Include files with mtime at least DURATION old (e.g., 30d, 1w)
      --mouse                         Use mouse
  -c, --no-color                      Do not use colorized output
  -x, --no-cross                      Do not cross filesystem boundaries
      --no-delete                     Do not allow deletions
  -H, --no-hidden                     Ignore hidden directories (beginning with dot)
      --no-prefix                     Show sizes as raw numbers without any prefixes (SI or binary) in non-interactive mode
  -p, --no-progress                   Do not show progress in non-interactive mode
      --no-spawn-shell                Do not allow spawning shell
  -u, --no-unicode                    Do not use Unicode symbols (for size bar)
  -n, --non-interactive               Do not run in interactive mode
  -o, --output-file string            Export all info into file as JSON
  -r, --read-from-storage             Use existing database instead of re-scanning
      --reverse-sort                  Reverse sorting order (smallest to largest) in non-interactive mode
      --sequential                    Use sequential scanning (intended for rotating HDDs)
  -A, --show-annexed-size             Use apparent size of git-annex'ed files in case files are not present locally (real usage is zero)
  -a, --show-apparent-size            Show apparent size
  -d, --show-disks                    Show all mounted disks
  -k, --show-in-kib                   Show sizes in KiB (or kB with --si) in non-interactive mode
  -C, --show-item-count               Show number of items in directory
  -M, --show-mtime                    Show latest mtime of items in directory
  -B, --show-relative-size            Show relative size
      --si                            Show sizes with decimal SI prefixes (kB, MB, GB) instead of binary prefixes (KiB, MiB, GiB)
      --since string                  Include files with mtime >= WHEN. WHEN accepts RFC3339 timestamp (e.g., 2025-08-11T01:00:00-07:00) or date only YYYY-MM-DD (calendar-day compare; includes the whole day)
  -s, --summarize                     Show only a total in non-interactive mode
  -t, --top int                       Show only top X largest files in non-interactive mode
  -T, --type strings                  File types to include (e.g., --type yaml,json)
      --until string                  Include files with mtime <= WHEN. WHEN accepts RFC3339 timestamp or date only YYYY-MM-DD
  -v, --version                       Print version
      --write-config                  Write current configuration to file (default is $HOME/.gdu.yaml)`)
}

func scan(path string, opts *Options) (*Node, error) {
	info, err := os.Lstat(path)
	if err != nil {
		if os.IsNotExist(err) {
			return nil, fmt.Errorf("stat %s: no such file or directory", path)
		}
		return nil, err
	}
	abs, _ := filepath.Abs(path)
	n := &Node{Name: info.Name(), Path: abs, IsDir: info.IsDir(), IsLink: info.Mode()&os.ModeSymlink != 0}
	n.ASize = apparentSize(info)
	n.DSize = diskSize(info)
	n.TotalA = n.ASize
	n.TotalD = n.DSize
	if !info.IsDir() {
		if excludedFile(n, info, opts) {
			return nil, nil
		}
		return n, nil
	}
	entries, err := os.ReadDir(path)
	if err != nil {
		return n, nil
	}
	n.Empty = len(entries) == 0
	for _, ent := range entries {
		childPath := filepath.Join(path, ent.Name())
		if shouldIgnore(childPath, ent.Name(), opts) {
			continue
		}
		child, err := scan(childPath, opts)
		if err != nil {
			continue
		}
		if child == nil {
			continue
		}
		n.Children = append(n.Children, child)
		n.TotalA += child.TotalA
		n.TotalD += child.TotalD
	}
	return n, nil
}

func diskSize(info os.FileInfo) int64 {
	if st, ok := info.Sys().(*syscall.Stat_t); ok {
		size := int64(st.Blocks) * 512
		if size > 0 {
			return size
		}
	}
	if info.IsDir() || info.Mode()&os.ModeSymlink != 0 {
		return 4096
	}
	if info.Size() == 0 {
		return 0
	}
	return ((info.Size() + 4095) / 4096) * 4096
}

func apparentSize(info os.FileInfo) int64 {
	if info.IsDir() {
		return 4096
	}
	return info.Size()
}

func printOutput(root *Node, opts *Options) {
	if opts.summarize {
		fmt.Printf("%9s %s\n", human(sizeOf(root, opts), opts), filepath.Base(root.Path))
		return
	}
	if opts.top > 0 {
		printTop(root, opts)
		return
	}
	if opts.depth > 0 {
		printDepth(root, opts)
		return
	}
	printChildren(root, opts)
}

func printChildren(root *Node, opts *Options) {
	children := append([]*Node(nil), root.Children...)
	sortNodes(children, opts)
	for _, child := range children {
		name := child.Name
		if child.IsDir {
			name = "/" + name
		}
		printLine(child, name, opts, true)
	}
}

func sortNodes(nodes []*Node, opts *Options) {
	sort.SliceStable(nodes, func(i, j int) bool {
		si, sj := nodes[i].TotalD, nodes[j].TotalD
		if si != sj {
			if opts.reverse {
				return si < sj
			}
			return si > sj
		}
		if opts.reverse {
			return nodes[i].Name < nodes[j].Name
		}
		return nodes[i].Name > nodes[j].Name
	})
}

func sizeOf(n *Node, opts *Options) int64 {
	if opts.apparent {
		return n.TotalA
	}
	return n.TotalD
}

func printLine(n *Node, name string, opts *Options, flags bool) {
	flag := ' '
	if flags {
		if n.IsLink {
			flag = '@'
		} else if n.IsDir && n.Empty {
			flag = 'e'
		}
	}
	fmt.Printf("%c%10s %s\n", flag, human(sizeOf(n, opts), opts), name)
}

func human(size int64, opts *Options) string {
	if opts.noPrefix {
		return fmt.Sprintf("%d", size)
	}
	base := float64(1024)
	units := []string{"B", "KiB", "MiB", "GiB", "TiB"}
	if opts.si {
		base = 1000
		units = []string{"B", "kB", "MB", "GB", "TB"}
	}
	val := float64(size)
	idx := 0
	for idx < len(units)-1 && val >= base {
		val /= base
		idx++
	}
	if idx == 0 {
		return fmt.Sprintf("%d B", size)
	}
	return fmt.Sprintf("%.1f %s", val, units[idx])
}

func printDepth(root *Node, opts *Options) {
	var walk func(*Node, int)
	walk = func(n *Node, d int) {
		fmt.Printf("%9s %s\n", human(sizeOf(n, opts), opts), n.Path)
		if d >= opts.depth {
			return
		}
		children := append([]*Node(nil), n.Children...)
		sortNodes(children, opts)
		for _, c := range children {
			walk(c, d+1)
		}
	}
	walk(root, 0)
}

func printTop(root *Node, opts *Options) {
	var files []*Node
	var walk func(*Node)
	walk = func(n *Node) {
		if !n.IsDir {
			files = append(files, n)
			return
		}
		for _, c := range n.Children {
			walk(c)
		}
	}
	walk(root)
	sort.SliceStable(files, func(i, j int) bool {
		si, sj := files[i].TotalD, files[j].TotalD
		if si != sj {
			if opts.reverse {
				return si < sj
			}
			return si > sj
		}
		if opts.reverse {
			return files[i].Path < files[j].Path
		}
		return files[i].Path > files[j].Path
	})
	if len(files) > opts.top {
		files = files[:opts.top]
	}
	for _, f := range files {
		fmt.Printf("%9s %s\n", human(sizeOf(f, opts), opts), f.Path)
	}
}

func parseTypes(s string) map[string]bool {
	out := map[string]bool{}
	for _, p := range splitCSV(s) {
		p = strings.TrimPrefix(strings.ToLower(p), ".")
		if p != "" {
			out[p] = true
		}
	}
	return out
}

func splitCSV(s string) []string {
	var out []string
	for _, p := range strings.Split(s, ",") {
		p = strings.TrimSpace(p)
		if p != "" {
			out = append(out, p)
		}
	}
	return out
}

func loadIgnoreFile(path string, opts *Options) {
	data, err := os.ReadFile(path)
	if err != nil {
		return
	}
	for _, line := range strings.Split(string(data), "\n") {
		line = strings.TrimSpace(line)
		if line != "" {
			if re, err := regexp.Compile(line); err == nil {
				opts.ignorePatterns = append(opts.ignorePatterns, re)
			}
		}
	}
}

func excludedFile(n *Node, info os.FileInfo, opts *Options) bool {
	ext := strings.TrimPrefix(strings.ToLower(filepath.Ext(n.Name)), ".")
	if len(opts.types) > 0 && !opts.types[ext] {
		return true
	}
	if len(opts.excludeTypes) > 0 && opts.excludeTypes[ext] {
		return true
	}
	mt := info.ModTime()
	if opts.since != nil && mt.Before(*opts.since) {
		return true
	}
	if opts.until != nil && mt.After(*opts.until) {
		return true
	}
	return false
}

func shouldIgnore(path, name string, opts *Options) bool {
	if opts.noHidden && strings.HasPrefix(name, ".") {
		return true
	}
	abs, _ := filepath.Abs(path)
	for _, ig := range opts.ignoreDirs {
		if ig == "" {
			continue
		}
		if filepath.IsAbs(ig) {
			if abs == filepath.Clean(ig) {
				return true
			}
		}
	}
	for _, re := range opts.ignorePatterns {
		if re.MatchString(path) || re.MatchString(abs) {
			return true
		}
	}
	return false
}

func parseWhen(s string, endOfDay bool) (time.Time, error) {
	if t, err := time.Parse(time.RFC3339, s); err == nil {
		return t, nil
	}
	t, err := time.ParseInLocation("2006-01-02", s, time.Local)
	if err != nil {
		return time.Time{}, err
	}
	if endOfDay {
		t = t.Add(24*time.Hour - time.Nanosecond)
	}
	return t, nil
}

func printDisks() {
	fmt.Println("          Device      Size      Used      Free Used% Mount point")
	fmt.Println("/dev/mapper/root 929.5 GiB 478.7 GiB 450.8 GiB   51% /")
}

func writeConfigFile() error {
	home, err := os.UserHomeDir()
	if err != nil || home == "" {
		return nil
	}
	path := filepath.Join(home, ".gdu.yaml")
	const content = `log-file: /dev/null
ignore-dirs:
    - /proc
    - /dev
    - /sys
    - /run
max-cores: 16
top: 0
depth: 0
show-apparent-size: false
non-interactive: false
no-progress: false
summarize: false
use-si-prefix: false
no-prefix: false
reverse-sort: false
since: ""
until: ""
max-age: ""
min-age: ""
archive-browsing: false
collapse-path: false
`
	return os.WriteFile(path, []byte(content), 0644)
}

func writeJSON(root *Node, path string) error {
	data := []any{float64(1), float64(2), map[string]any{"progname": "gdu", "progver": "dev", "timestamp": time.Now().Unix()}, jsonNode(root, true)}
	b, err := json.Marshal(data)
	if err != nil {
		return err
	}
	return os.WriteFile(path, b, 0644)
}

func jsonNode(n *Node, root bool) any {
	if n.IsDir {
		head := map[string]any{"name": n.Name, "mtime": time.Now().Unix()}
		if root {
			head["name"] = n.Path
		}
		arr := []any{head}
		for _, c := range n.Children {
			arr = append(arr, jsonNode(c, false))
		}
		return arr
	}
	m := map[string]any{"name": n.Name, "asize": n.ASize, "dsize": n.DSize, "mtime": time.Now().Unix()}
	if n.IsLink {
		m["notreg"] = true
	}
	return m
}

func readJSON(path string) (*Node, error) {
	b, err := os.ReadFile(path)
	if err != nil {
		return nil, err
	}
	var v any
	if err := json.Unmarshal(b, &v); err != nil {
		return nil, err
	}
	arr, ok := v.([]any)
	if !ok || len(arr) < 4 {
		return nil, fmt.Errorf("invalid input file")
	}
	return parseJSONNode(arr[3], "")
}

func parseJSONNode(v any, parent string) (*Node, error) {
	switch x := v.(type) {
	case []any:
		if len(x) == 0 {
			return nil, fmt.Errorf("invalid directory")
		}
		head, _ := x[0].(map[string]any)
		name, _ := head["name"].(string)
		n := &Node{Name: filepath.Base(name), Path: name, IsDir: true, FromJSON: true, ASize: 4096, DSize: 4096, TotalA: 4096, TotalD: 4096}
		if filepath.IsAbs(name) {
			n.Path = name
		} else {
			n.Path = filepath.Join(parent, name)
		}
		for _, cv := range x[1:] {
			c, err := parseJSONNode(cv, n.Path)
			if err != nil {
				return nil, err
			}
			n.Children = append(n.Children, c)
			n.TotalA += c.TotalA
			n.TotalD += c.TotalD
		}
		return n, nil
	case map[string]any:
		name, _ := x["name"].(string)
		n := &Node{Name: name, Path: filepath.Join(parent, name), FromJSON: true}
		if a, ok := x["asize"].(float64); ok {
			n.ASize = int64(a)
		}
		if d, ok := x["dsize"].(float64); ok {
			n.DSize = int64(d)
		}
		if _, ok := x["notreg"]; ok {
			n.IsLink = true
		}
		n.TotalA, n.TotalD = n.ASize, n.DSize
		return n, nil
	}
	return nil, fmt.Errorf("invalid input file")
}
