#!/bin/bash
set -e
cp gmx_reimpl.py executable
chmod +x executable
