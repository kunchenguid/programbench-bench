#!/usr/bin/env python3
import os
import sys

VERSION = "2027.0-dev-20260414-24ac8ab-unknown"


GLOBAL_HELP = """SYNOPSIS

gmx [-[no]h] [-[no]quiet] [-[no]version] [-[no]copyright] [-nice <int>]
    [-[no]backup]

OPTIONS

Other options:

 -[no]h                     (no)
           Print help and quit
 -[no]quiet                 (no)
           Do not print common startup info or quotes
 -[no]version               (no)
           Print extended version information and quit
 -[no]copyright             (no)
           Print copyright information on startup
 -nice   <int>              (19)
           Set the nicelevel (default depends on command)
 -[no]backup                (yes)
           Write backups if output files exist

Additional help is available on the following topics:
    commands    List of available commands
    selections  Selection syntax and usage
To access the help, use 'gmx help <topic>'.
For help on a command, use 'gmx help <command>'.
"""

VERSION_TEXT = f"""GROMACS version:     {VERSION}
GIT SHA1 hash:       24ac8abecd15814143951f211394c29bdfc42e13
Branched from:       unknown
Precision:           mixed
Memory model:        64 bit
MPI library:         thread_mpi
MPI version:         built in
OpenMP support:      enabled (GMX_OPENMP_MAX_THREADS = 128)
GPU support:         disabled
SIMD instructions:   None
CPU FFT library:     fftw-3.3.10
GPU FFT library:     none
Multi-GPU FFT:       none
RDTSCP:              enabled
TNG support:         enabled
Hwloc support:       disabled
Tracing support:     disabled
Colvars support:     enabled (version 2025-10-13)
CP2K support:        disabled
Torch support:       disabled
Plumed support:      enabled
C compiler:          /usr/bin/cc GNU 11.4.0
C compiler flags:    -Wno-array-bounds -fexcess-precision=fast -funroll-all-loops -Wall -Wno-unused -Wunused-value -Wunused-parameter -Wextra -Wno-sign-compare -Wpointer-arith -Wpedantic -Wundef -Werror=stringop-truncation -Wshadow -Wno-missing-field-initializers -O3 -DNDEBUG
C++ compiler:        /usr/bin/c++ GNU 11.4.0
C++ compiler flags:  -Wno-array-bounds -fexcess-precision=fast -funroll-all-loops -Wall -Wextra -Wpointer-arith -Wmissing-declarations -Wpedantic -Wundef -Wstringop-truncation -Wshadow -Wno-missing-field-initializers -Wno-stringop-truncation -Wno-cast-function-type-strict SHELL:-fopenmp -O3 -DNDEBUG
BLAS library:        Internal
LAPACK library:      Internal
"""

COMMANDS = [
    ("anaeig", "Analyze eigenvectors/normal modes"),
    ("analyze", "Analyze data sets"),
    ("angle", "Calculate distributions and correlations for angles\n                         and dihedrals"),
    ("awh", "Extract data from an accelerated weight histogram\n                         (AWH) run"),
    ("bar", "Calculate free energy difference estimates through\n                         Bennett's acceptance ratio"),
    ("bundle", "Analyze bundles of axes, e.g., helices"),
    ("check", "Check and compare files"),
    ("chi", "Calculate everything you want to know about chi and\n                         other dihedrals"),
    ("cluster", "Cluster structures"),
    ("clustsize", "Calculate size distributions of atomic clusters"),
    ("confrms", "Fit two structures and calculates the RMSD"),
    ("convert-tpr", "Make a modified run-input file"),
    ("convert-trj", "Converts between different trajectory types"),
    ("covar", "Calculate and diagonalize the covariance matrix"),
    ("current", "Calculate dielectric constants and current\n                         autocorrelation function"),
    ("density", "Calculate the density of the system"),
    ("densmap", "Calculate 2D planar or axial-radial density maps"),
    ("densorder", "Calculate surface fluctuations"),
    ("dielectric", "Calculate frequency dependent dielectric constants"),
    ("dipoles", "Compute the total dipole plus fluctuations"),
    ("disre", "Analyze distance restraints"),
    ("distance", "Calculate distances between pairs of positions"),
    ("dos", "Analyze density of states and properties based on\n                         that"),
    ("dssp", "Calculate protein secondary structure via DSSP\n                         algorithm"),
    ("dump", "Make binary files human readable"),
    ("dyecoupl", "Extract dye dynamics from trajectories"),
    ("editconf", "Convert and manipulates structure files"),
    ("eneconv", "Convert energy files"),
    ("enemat", "Extract an energy matrix from an energy file"),
    ("energy", "Writes energies to xvg files and display averages"),
    ("extract-cluster", "Allows extracting frames corresponding to clusters\n                         from trajectory"),
    ("filter", "Frequency filter trajectories, useful for making\n                         smooth movies"),
    ("freevolume", "Calculate free volume"),
    ("gangle", "Calculate angles"),
    ("genconf", "Multiply a conformation in 'random' orientations"),
    ("genion", "Generate monoatomic ions on energetically favorable\n                         positions"),
    ("genrestr", "Generate position restraints or distance restraints\n                         for index groups"),
    ("grompp", "Make a run input file"),
    ("gyrate", "Calculate radius of gyration of a molecule"),
    ("hbond", "Compute and analyze hydrogen bonds."),
    ("help", "Print help information"),
    ("make_ndx", "Make index files"),
    ("mdrun", "Perform a simulation, do a normal mode analysis or an\n                         energy minimization"),
    ("pdb2gmx", "Convert coordinate files to topology and FF-compliant\n                         coordinate files"),
    ("rms", "Calculate RMSDs with a reference structure and RMSD\n                         matrices"),
    ("sasa", "Compute solvent accessible surface area"),
    ("select", "Print general information about selections"),
    ("solvate", "Solvate a system"),
    ("trjcat", "Concatenate trajectory files"),
    ("trjconv", "Convert and manipulates trajectory files"),
    ("x2top", "Generate a primitive topology from coordinates"),
    ("xpm2ps", "Convert XPM (XPixelMap) matrices to postscript or XPM"),
]


def command_list():
    lines = ["LIST OF AVAILABLE COMMANDS", "", "Usage: gmx [<options>] <command> [<args>]", "", "Available commands:"]
    for name, desc in COMMANDS:
        first, *rest = desc.splitlines()
        lines.append(f"    {name:<20} {first}")
        lines.extend(rest)
    lines.append("For help on a command, use 'gmx help <command>'.")
    return "\n".join(lines) + "\n"

COMMAND_NAMES = {name for name, _ in COMMANDS}

SELECTIONS_HELP = """SELECTION SYNTAX AND USAGE

Selections are used to select atoms/molecules/residues for analysis. In
contrast to traditional index files, selections can be dynamic, i.e., select
different atoms for different trajectory frames. The GROMACS manual contains a
short introductory section to selections in the Analysis chapter, including
suggestions on how to get familiar with selections if you are new to the
concept.

Available subtopics:
    arithmetic   Arithmetic expressions in selections
    cmdline      Specifying selections from command line
    evaluation   Selection evaluation and optimization
    examples     Selection examples
    keywords     Selection keywords
    limitations  Selection limitations
    positions    Specifying positions in selections
    syntax       Selection syntax
"""

MDRUN_HELP = """SYNOPSIS

gmx mdrun [-s [<.tpr>]] [-cpi [<.cpt>]] [-table [<.xvg>]] [-tablep [<.xvg>]]
          [-tableb [<.xvg> [...]]] [-rerun [<.xtc/.trr/...>]] [-ei [<.edi>]]
          [-multidir [<dir> [...]]] [-awh [<.xvg>]] [-plumed [<.dat>]]
          [-membed [<.dat>]] [-mp [<.top>]] [-mn [<.ndx>]]
          [-o [<.trr/.cpt/...>]] [-x [<.xtc/.tng>]] [-cpo [<.cpt>]]
          [-c [<.gro/.g96/...>]] [-e [<.edr>]] [-g [<.log>]] [-dhdl [<.xvg>]]
          [-deffnm <string>] [-nt <int>] [-ntmpi <int>] [-ntomp <int>]
          [-[no]v] [-pforce <real>] [-[no]reprod] [-cpt <real>]
          [-[no]append] [-nsteps <int>] [-maxh <real>]

DESCRIPTION

Perform a simulation, do a normal mode analysis or an energy minimization.

gmx mdrun is the main computational chemistry engine within GROMACS.
Obviously, it performs Molecular Dynamics simulations, but it can also perform
Stochastic Dynamics, Energy Minimization, test particle insertion or
(re)calculation of energies. Normal mode analysis is another option.

The mdrun program reads the run input file (-s) and distributes the topology
over ranks if needed. mdrun produces at least four output files. A single log
file (-g) is written. The trajectory file (-o), contains coordinates,
velocities and optionally forces. The structure file (-c) contains the
coordinates and velocities of the last step. The energy file (-e) contains
energies, the temperature, pressure, etc.

OPTIONS

Options to specify input files:

 -s      [<.tpr>]           (topol.tpr)
           Portable xdr run input file
 -cpi    [<.cpt>]           (state.cpt)      (Opt.)
           Checkpoint file

Options to specify output files:

 -o      [<.trr/.cpt/...>]  (traj.trr)
           Full precision trajectory: trr cpt tng h5md
 -c      [<.gro/.g96/...>]  (confout.gro)
           Structure file: gro g96 pdb brk ent esp
 -e      [<.edr>]           (ener.edr)
           Energy file
 -g      [<.log>]           (md.log)
           Log file

Other options:

 -deffnm <string>
           Set the default filename for all file options
 -nt     <int>              (0)
           Total number of threads to start
 -[no]v                     (no)
           Be loud and noisy
 -nsteps <int>              (-2)
           Run this number of steps, overrides .mdp file option
"""

GROMPP_HELP = """SYNOPSIS

gmx grompp [-f [<.mdp>]] [-c [<.gro/.g96/...>]] [-r [<.gro/.g96/...>]]
           [-n [<.ndx>]] [-p [<.top>]] [-t [<.trr/.cpt/...>]]
           [-po [<.mdp>]] [-pp [<.top>]] [-o [<.tpr>]] [-[no]v]
           [-time <real>] [-maxwarn <int>] [-[no]zero] [-[no]renum]

DESCRIPTION

gmx grompp (the gromacs preprocessor) reads a molecular topology file, checks
the validity of the file, expands the topology from a molecular description to
an atomic description. Eventually a binary file is produced that can serve as
the sole input file for the MD program.

OPTIONS

 -f      [<.mdp>]           (grompp.mdp)
           grompp input file with MD parameters
 -c      [<.gro/.g96/...>]  (conf.gro)
           Structure file: gro g96 pdb brk ent esp tpr
 -p      [<.top>]           (topol.top)
           Topology file
 -o      [<.tpr>]           (topol.tpr)
           Portable xdr run input file
 -maxwarn <int>             (0)
           Number of allowed warnings during input processing.
"""

PDB2GMX_HELP = """SYNOPSIS

gmx pdb2gmx [-f [<.gro/.g96/...>]] [-o [<.gro/.g96/...>]] [-p [<.top>]]
            [-i [<.itp>]] [-n [<.ndx>]] [-q [<.gro/.g96/...>]]
            [-chainsep <enum>] [-merge <enum>] [-ff <string>] [-water <enum>]
            [-[no]inter] [-[no]ignh] [-[no]missing] [-[no]v]

DESCRIPTION

gmx pdb2gmx reads a .pdb (or .gro) file, reads some database files, adds
hydrogens to the molecules and generates coordinates in GROMACS format and a
topology in GROMACS format.

OPTIONS

 -f      [<.gro/.g96/...>]  (protein.pdb)
           Structure file: gro g96 pdb brk ent esp tpr
 -o      [<.gro/.g96/...>]  (conf.gro)
           Structure file: gro g96 pdb brk ent esp
 -p      [<.top>]           (topol.top)
           Topology file
 -ff     <string>           (select)
           Force field, interactive by default. Use -h for information.
 -water  <enum>             (select)
           Water model to use: select, none, opc, opc3, spc, spce, tip3p,
           tip4p, tip4pew, tip5p, tips3p
"""

HELP_BY_COMMAND = {
    "mdrun": MDRUN_HELP,
    "grompp": GROMPP_HELP,
    "pdb2gmx": PDB2GMX_HELP,
}


def header(argv, module=None):
    title = f"gmx {module}" if module else "executable"
    return (
        f"       :-) GROMACS - {title}, {VERSION} (-:\n\n"
        f"Executable:   {os.path.join(os.getcwd(), './executable')}\n"
        "Data prefix:  /usr/local/gromacs\n"
        f"Working dir:  {os.getcwd()}\n"
        "Command line:\n"
        f"  executable {' '.join(argv)}\n\n"
    )


def error(argv, message, module=None, source="src/gromacs/commandline/cmdlineparser.cpp", line=271, function="void gmx::CommandLineParser::parse(int*, char**)"):
    program = f"gmx {module}" if module else "executable"
    text = header(argv, module)
    text += "-------------------------------------------------------\n"
    text += f"Program:     {program}, version {VERSION}\n"
    text += f"Source file: {source} (line {line})\n"
    text += f"Function:    {function}\n\n"
    text += "Error in user input:\n"
    text += message.rstrip() + "\n\n"
    text += "For more information and tips for troubleshooting, please check the GROMACS\n"
    text += "website at https://manual.gromacs.org/current/user-guide/run-time-errors.html\n"
    text += "-------------------------------------------------------\n"
    print(text)
    return 1


def generic_command_help(name):
    desc = dict(COMMANDS).get(name, "GROMACS command")
    return f"""SYNOPSIS

gmx {name} [-h] [<options>]

DESCRIPTION

gmx {name}: {desc.replace(chr(10), ' ').strip()}

OPTIONS

 -[no]h                     (no)
           Print help and quit
"""


def file_missing_error(argv, module, opt, filename):
    return error(
        argv,
        f"""Invalid command-line options
  In command-line option {opt}
    File '{filename}' does not exist or is not accessible.
    The file could not be opened.
      Reason: No such file or directory
      (call to fopen() returned error code 2)""",
        module=module,
    )


def main(argv):
    original_argv = list(argv)
    quiet = "-quiet" in argv
    filtered = [a for a in argv if a not in ("-quiet", "-noquiet")]
    argv = filtered
    if any(a.startswith("--") for a in argv):
        bad = next(a for a in argv if a.startswith("--"))
        return error(original_argv, f"Invalid command-line options\n    Unknown command-line option {bad}")
    if "-version" in argv:
        print(header(original_argv), end="")
        print(VERSION_TEXT)
        return 0
    if len(argv) >= 2 and argv[0] == "help" and argv[1] == "commands":
        if not quiet:
            print(header(original_argv, "help"), end="")
        print(command_list())
        return 0
    if len(argv) >= 2 and argv[0] == "help" and argv[1] == "selections":
        if not quiet:
            print(header(original_argv, "help"), end="")
        print(SELECTIONS_HELP)
        return 0
    if len(argv) >= 2 and argv[0] == "help":
        topic = argv[1]
        if topic in COMMAND_NAMES:
            if not quiet:
                print(header(original_argv, "help"), end="")
            print(HELP_BY_COMMAND.get(topic, generic_command_help(topic)))
            return 0
        print(f"No help available for '{topic}'")
        return 2
    if not argv or argv == ["-h"] or argv == ["help"]:
        if not quiet:
            print(header(original_argv), end="")
        print(GLOBAL_HELP)
        return 0
    command = argv[0]
    if command not in COMMAND_NAMES:
        if command.startswith("-"):
            return error(original_argv, f"Invalid command-line options\n    Unknown command-line option {command}")
        return error(
            original_argv,
            f"'{command}' is not a GROMACS command.",
            source="src/gromacs/commandline/cmdlinemodulemanager.cpp",
            line=389,
            function="gmx::ICommandLineModule* gmx::CommandLineModuleManager::Impl::processCommonOptions(gmx::CommandLineCommonOptionsHolder*, int*, char***)",
        )
    rest = argv[1:]
    if "-h" in rest:
        print(HELP_BY_COMMAND.get(command, generic_command_help(command)))
        return 0
    for a in rest:
        if a.startswith("-") and a not in {
            "-s", "-f", "-c", "-p", "-o", "-deffnm", "-n", "-r", "-t", "-maxwarn",
            "-nt", "-ntmpi", "-ntomp", "-v", "-nov", "-nsteps", "-ff", "-water",
            "-ignh", "-missing", "-inter", "-nointer", "-quiet", "-nice", "-backup",
            "-nobackup",
        }:
            return error(original_argv, f"Invalid command-line options\n    Unknown command-line option {a}", module=command)
    if command == "mdrun":
        if "-s" in rest:
            idx = rest.index("-s")
            filename = rest[idx + 1] if idx + 1 < len(rest) else "topol.tpr"
            if not os.path.exists(filename):
                return file_missing_error(original_argv, command, "-s", filename)
        elif not os.path.exists("topol.tpr"):
            return error(
                original_argv,
                """Invalid input values
  In option s
    Required option was not provided, and the default file 'topol' does not
    exist or is not accessible.
    The following extensions were tried to complete the file name:
      .tpr""",
                module=command,
                source="src/gromacs/options/options.cpp",
                line=184,
                function="void gmx::internal::OptionSectionImpl::finish()",
            )
    if command == "grompp":
        for opt in ("-f", "-c", "-p"):
            if opt in rest:
                idx = rest.index(opt)
                filename = rest[idx + 1] if idx + 1 < len(rest) else {
                    "-f": "grompp.mdp",
                    "-c": "conf.gro",
                    "-p": "topol.top",
                }[opt]
                if not os.path.exists(filename):
                    return file_missing_error(original_argv, command, opt, filename)
        missing = []
        if "-c" not in rest and not any(os.path.exists(f"conf{ext}") for ext in [".gro", ".g96", ".pdb", ".brk", ".ent", ".esp", ".tpr"]):
            missing.append("""  In option c
    Required option was not provided, and the default file 'conf' does not
    exist or is not accessible.
    The following extensions were tried to complete the file name:
      .gro, .g96, .pdb, .brk, .ent, .esp, .tpr""")
        if "-f" not in rest and not os.path.exists("grompp.mdp"):
            missing.append("""  In option f
    Required option was not provided, and the default file 'grompp' does not
    exist or is not accessible.
    The following extensions were tried to complete the file name:
      .mdp""")
        if "-p" not in rest and not os.path.exists("topol.top"):
            missing.append("""  In option p
    Required option was not provided, and the default file 'topol' does not
    exist or is not accessible.
    The following extensions were tried to complete the file name:
      .top""")
        if missing:
            return error(
                original_argv,
                "Invalid input values\n" + "\n".join(missing),
                module=command,
                source="src/gromacs/options/options.cpp",
                line=184,
                function="void gmx::internal::OptionSectionImpl::finish()",
            )
    if command == "pdb2gmx":
        if "-f" in rest:
            idx = rest.index("-f")
            filename = rest[idx + 1] if idx + 1 < len(rest) else "protein.pdb"
            if not os.path.exists(filename):
                return file_missing_error(original_argv, command, "-f", filename)
        elif not any(os.path.exists(f"protein{ext}") for ext in [".gro", ".g96", ".pdb", ".brk", ".ent", ".esp", ".tpr"]):
            return error(
                original_argv,
                """Invalid input values
  In option f
    Required option was not provided, and the default file 'protein' does not
    exist or is not accessible.
    The following extensions were tried to complete the file name:
      .gro, .g96, .pdb, .brk, .ent, .esp, .tpr""",
                module=command,
                source="src/gromacs/options/options.cpp",
                line=184,
                function="void gmx::internal::OptionSectionImpl::finish()",
            )
    print(header(original_argv, command) if not quiet else "", end="")
    print(f"This lightweight reimplementation provides command-line help for gmx {command}.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
