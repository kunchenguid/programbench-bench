#!/usr/bin/env python3
import getopt
import os
import select
import shutil
import signal
import sys
import time

USAGE = """usage : tty-clock [-iuvsScbtrahDBxn] [-C [0-7]] [-f format] [-d delay] [-a nsdelay] [-T tty] 
    -s            Show seconds                                   
    -S            Screensaver mode                               
    -x            Show box                                       
    -c            Set the clock at the center of the terminal    
    -C [0-7]      Set the clock color                            
    -b            Use bold colors                                
    -t            Set the hour in 12h format                     
    -u            Use UTC time                                   
    -T tty        Display the clock on the specified terminal    
    -r            Do rebound the clock                           
    -f format     Set the date format                            
    -n            Don't quit on keypress                         
    -v            Show tty-clock version                         
    -i            Show some info about tty-clock                 
    -h            Show this page                                 
    -D            Hide date                                      
    -B            Enable blinking colon                          
    -d delay      Set the delay between two redraws of the clock. Default 1s. 
    -a nsdelay    Additional delay between two redraws in nanoseconds. Default 0ns.
"""

VERSION = "TTY-Clock 2 © devel version\n"
INFO = "TTY-Clock 2 © by Martin Duquesnoy (xorg62@gmail.com), Grey (grey@greytheory.net)\n"

DIGITS = {
    "0": [" #### ", "##  ##", "##  ##", "##  ##", " #### "],
    "1": ["  ##  ", " ###  ", "  ##  ", "  ##  ", "######"],
    "2": [" #### ", "##  ##", "   ## ", "  ##  ", "######"],
    "3": ["####  ", "    ##", " #### ", "    ##", "####  "],
    "4": ["##  ##", "##  ##", "######", "    ##", "    ##"],
    "5": ["######", "##    ", "##### ", "    ##", "##### "],
    "6": [" #### ", "##    ", "##### ", "##  ##", " #### "],
    "7": ["######", "    ##", "   ## ", "  ##  ", "  ##  "],
    "8": [" #### ", "##  ##", " #### ", "##  ##", " #### "],
    "9": [" #### ", "##  ##", " #####", "    ##", " #### "],
    ":": ["  ", "##", "  ", "##", "  "],
}


class Opts:
    def __init__(self):
        self.seconds = False
        self.box = False
        self.center = False
        self.color = 2
        self.bold = False
        self.twelve = False
        self.utc = False
        self.rebound = False
        self.date_format = "%F"
        self.no_quit = False
        self.hide_date = False
        self.blink = False
        self.delay = 1.0
        self.tty = None


def usage_error(message):
    sys.stderr.write(f"{sys.argv[0]}: {message}\n")
    sys.stdout.write(USAGE)
    raise SystemExit(0)


def parse(argv):
    opts = Opts()
    for arg in argv:
        if arg.startswith("--"):
            usage_error("invalid option -- '-'")
    try:
        parsed, _ = getopt.getopt(argv, "iuvsScbtrahDBxnC:f:d:a:T:")
    except getopt.GetoptError as exc:
        text = str(exc)
        if "not recognized" in text:
            usage_error(f"invalid option -- '{text[8]}'")
        if text.startswith("option -") and "requires argument" in text:
            usage_error(f"option requires an argument -- '{text[8]}'")
        usage_error(text)
    for opt, val in parsed:
        if opt == "-h":
            sys.stdout.write(USAGE)
            raise SystemExit(0)
        if opt == "-v":
            sys.stdout.write(VERSION)
            raise SystemExit(0)
        if opt == "-i":
            sys.stdout.write(INFO)
            raise SystemExit(0)
        if opt == "-s":
            opts.seconds = True
        elif opt == "-S":
            opts.rebound = True
        elif opt == "-x":
            opts.box = True
        elif opt == "-c":
            opts.center = True
        elif opt == "-C":
            try:
                opts.color = int(val) % 8
            except ValueError:
                opts.color = 2
        elif opt == "-b":
            opts.bold = True
        elif opt == "-t":
            opts.twelve = True
        elif opt == "-u":
            opts.utc = True
        elif opt == "-T":
            opts.tty = val
        elif opt == "-r":
            opts.rebound = True
        elif opt == "-f":
            opts.date_format = val
        elif opt == "-n":
            opts.no_quit = True
        elif opt == "-D":
            opts.hide_date = True
        elif opt == "-B":
            opts.blink = True
        elif opt == "-d":
            try:
                opts.delay = float(val)
            except ValueError:
                opts.delay = 1.0
        elif opt == "-a":
            try:
                opts.delay += int(val) / 1_000_000_000
            except ValueError:
                pass
    return opts


def check_terminal(opts):
    if opts.tty:
        try:
            st = os.stat(opts.tty)
        except OSError as exc:
            sys.stderr.write(f"tty-clock: error: couldn't stat '{opts.tty}': {exc.strerror}.\n")
            raise SystemExit(1)
    term = os.environ.get("TERM", "")
    if not term or term in {"unknown", "dumb"}:
        sys.stderr.write(f"Error opening terminal: {term or 'unknown'}.\n")
        raise SystemExit(1)


def now(opts):
    return time.gmtime() if opts.utc else time.localtime()


def digit_lines(text):
    rows = [""] * 5
    for ch in text:
        pat = DIGITS.get(ch, ["      "] * 5)
        for i in range(5):
            rows[i] += pat[i] + " "
    return rows


def frame(opts):
    tm = now(opts)
    fmt = "%I:%M" if opts.twelve else "%H:%M"
    if opts.seconds:
        fmt += ":%S"
    clock = time.strftime(fmt, tm)
    rows = digit_lines(clock)
    date = ""
    if not opts.hide_date:
        date = time.strftime(opts.date_format, tm)
        if opts.twelve:
            date += time.strftime(" [%p]", tm)
    width = max([len(r) for r in rows] + ([len(date)] if date else []))
    if opts.box:
        border = "+" + "-" * (width + 2) + "+"
        boxed = [border]
        boxed += ["| " + r.ljust(width) + " |" for r in rows]
        if date:
            boxed.append("| " + date.center(width) + " |")
        boxed.append(border)
        rows = boxed
    elif date:
        rows.append(date.center(width))
    return rows


def render(opts):
    cols, lines = shutil.get_terminal_size((80, 24))
    rows = frame(opts)
    y = 0
    x = 0
    if opts.center:
        y = max(0, (lines - len(rows)) // 2)
        x = max(0, (cols - max(len(r) for r in rows)) // 2)
    color = 30 + opts.color
    if opts.bold:
        color_code = f"1;{color}"
    else:
        color_code = str(color)
    sys.stdout.write("\x1b[?1049h\x1b[?25l\x1b[H\x1b[2J")
    for i, row in enumerate(rows):
        sys.stdout.write(f"\x1b[{y + i + 1};{x + 1}H\x1b[{color_code}m{row}\x1b[39m")
    sys.stdout.flush()


def main(argv):
    opts = parse(argv)
    check_terminal(opts)

    def stop(_signum=None, _frame=None):
        sys.stdout.write("\x1b[?25h\x1b[?1049l")
        sys.stdout.flush()
        raise SystemExit(0)

    signal.signal(signal.SIGTERM, stop)
    signal.signal(signal.SIGINT, stop)
    while True:
        render(opts)
        end = time.time() + max(0.01, opts.delay)
        while time.time() < end:
            wait = min(0.05, end - time.time())
            readable, _, _ = select.select([sys.stdin], [], [], wait)
            if readable:
                ch = sys.stdin.read(1)
                if ch and not opts.no_quit and (opts.rebound or ch.lower() == "q"):
                    stop()


if __name__ == "__main__":
    main(sys.argv[1:])
