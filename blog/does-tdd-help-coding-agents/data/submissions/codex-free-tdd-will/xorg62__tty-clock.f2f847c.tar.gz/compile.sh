#!/bin/bash
set -e
cp tty_clock.py executable
chmod +x executable
