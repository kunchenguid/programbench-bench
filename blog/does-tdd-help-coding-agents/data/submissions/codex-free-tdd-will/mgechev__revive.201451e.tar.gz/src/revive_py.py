#!/usr/bin/env python3
import os
import json
import fnmatch
import html
import re
import sys

VALID_FORMATTERS = {"default", "json", "ndjson", "friendly", "stylish", "checkstyle", "sarif", "plain", "unix", ""}


HELP_TEXT = """Usage of ./executable:
  -config string
    \tpath to the configuration TOML file, defaults to $XDG_CONFIG_HOME/revive.toml or $HOME/revive.toml, if present (i.e. -config myconf.toml)
  -exclude value
    \tlist of globs which specify files to be excluded (i.e. -exclude foo/...)
  -formatter string
    \tformatter to be used for the output (i.e. -formatter stylish)
  -max_open_files int
    \tmaximum number of open files at the same time
  -set_exit_status
    \tset exit status to 1 if any issues are found, overwrites errorCode and warningCode in config
  -version
    \tget revive version

 _ __ _____   _(_)__  _____
| '__/ _ \\ \\ / / \\ \\ / / _ \\
| | |  __/\\ V /| |\\ V /  __/
|_|  \\___| \\_/ |_| \\_/ \\___|

Example:
  revive -config c.toml -formatter friendly -exclude a.go -exclude b.go ./...
"""


def camel(name):
    parts = name.split("_")
    return parts[0] + "".join(p[:1].upper() + p[1:] for p in parts[1:])


def is_all_caps(name):
    letters = [c for c in name if c.isalpha()]
    return bool(letters) and name == name.upper()


def is_excluded(path, patterns):
    normalized = rel(path)
    for pattern in patterns:
        pat = rel(pattern)
        if pat.endswith("/..."):
            root = pat[:-4].rstrip("/")
            if normalized == root or normalized.startswith(root + "/"):
                return True
        if fnmatch.fnmatch(normalized, pat):
            return True
    return False


def collect_files(targets, excludes=None):
    excludes = excludes or []
    targets = targets or ["."]
    files = []
    for target in targets:
        if target.startswith("-"):
            continue
        if target.endswith("/..."):
            root = target[:-4] or "."
            for dirpath, dirnames, filenames in os.walk(root):
                dirnames[:] = [d for d in dirnames if d not in {".git", "vendor"}]
                for filename in filenames:
                    if filename.endswith(".go") and not filename.endswith("_test.go"):
                        files.append(os.path.join(dirpath, filename))
        elif os.path.isdir(target):
            for filename in sorted(os.listdir(target)):
                path = os.path.join(target, filename)
                if os.path.isfile(path) and filename.endswith(".go") and not filename.endswith("_test.go"):
                    files.append(path)
        elif target.endswith(".go") and os.path.exists(target):
            files.append(target)
    return sorted(path for path in files if not is_excluded(path, excludes))


def rel(path):
    return path[2:] if path.startswith("./") else path


def line_offset(lines, line, col):
    return sum(len(lines[i]) + 1 for i in range(line - 1)) + col - 1


RULE_ORDER = {
    "package-comments": 10,
    "exported": 10,
    "indent-error-flow": 20,
    "range": 30,
    "var-naming": 40,
}


def finding(path, lines, line, col, message, rule, category, confidence=1.0, end_col=None):
    if end_col is None:
        end_col = col
    return {
        "path": path,
        "line": line,
        "col": col,
        "end_col": end_col,
        "message": message,
        "rule": rule,
        "category": category,
        "severity": "warning",
        "confidence": confidence,
        "offset": line_offset(lines, line, col),
        "end_offset": line_offset(lines, line, end_col),
        "order": RULE_ORDER.get(rule, 100),
    }


def directive_disabled(lines, target_line, rule):
    disabled_all = False
    disabled_rules = set()
    for idx, line in enumerate(lines, 1):
        stripped = line.strip()
        if idx >= target_line:
            break
        if not stripped.startswith("//revive:"):
            continue
        command = stripped[len("//revive:"):]
        if command.startswith("disable-next-line"):
            parts = command.split(":", 1)
            if idx + 1 == target_line and (len(parts) == 1 or parts[1] == rule):
                return True
        elif command.startswith("disable"):
            parts = command.split(":", 1)
            if len(parts) == 1:
                disabled_all = True
            else:
                disabled_rules.add(parts[1])
        elif command.startswith("enable"):
            parts = command.split(":", 1)
            if len(parts) == 1:
                disabled_all = False
                disabled_rules.clear()
            else:
                disabled_rules.discard(parts[1])
    return disabled_all or rule in disabled_rules


def lint_file(path, disabled_rules=None):
    disabled_rules = disabled_rules or set()
    findings = []
    text = open(path, encoding="utf-8").read()
    lines = text.splitlines()
    comments = {}
    for idx, line in enumerate(lines, 1):
        stripped = line.strip()
        if stripped.startswith("//"):
            comments[idx + 1] = stripped[2:].strip()
    for idx, line in enumerate(lines, 1):
        if re.search(r"\bif\b.*\breturn\b.*\}\s*else\s*\{", line):
            col = line.index("{", line.index("else")) + 1
            findings.append(finding(path, lines, idx, col, "if block ends with a return statement, so drop this else and outdent its block", "indent-error-flow", "style", 0.8, col + 4))
        range_match = re.search(r"for\s+([A-Za-z_][A-Za-z0-9_]*)\s*,\s*_\s*:=\s*range\b", line)
        if range_match:
            name = range_match.group(1)
            col = line.index("_", range_match.start()) + 1
            findings.append(finding(path, lines, idx, col, f"should omit 2nd value from range; this loop is equivalent to `for {name} := range ...`", "range", "style", 0.8, col + 1))
        match = re.match(r"\s*func\s+([A-Za-z_][A-Za-z0-9_]*)\s*\(", line)
        if match:
            name = match.group(1)
            col = line.index(name) + 1
            if name[:1].isupper():
                comment = comments.get(idx)
                if not comment:
                    findings.append(finding(path, lines, idx, 1, f"exported function {name} should have comment or be unexported", "exported", "comments", end_col=1 + len(name)))
                elif not comment.startswith(name + " "):
                    findings.append(finding(path, lines, idx, 1, f'comment on exported function {name} should be of the form "{name} ..."', "exported", "comments", end_col=1 + len(name)))
            if "_" in name:
                findings.append(finding(path, lines, idx, col, f"don't use underscores in Go names; func {name} should be {camel(name)}", "var-naming", "naming", 0.9, col + len(name)))
        for kind, pattern in (
            ("var", r"\s*var\s+([A-Za-z_][A-Za-z0-9_]*)\b"),
            ("const", r"\s*const\s+([A-Za-z_][A-Za-z0-9_]*)\b"),
            ("type", r"\s*type\s+([A-Za-z_][A-Za-z0-9_]*)\b"),
        ):
            match = re.match(pattern, line)
            if match:
                name = match.group(1)
                col = line.index(name) + 1
                if name[:1].isupper() and not comments.get(idx):
                    findings.append(finding(path, lines, idx, col, f"exported {kind} {name} should have comment or be unexported", "exported", "comments", end_col=col + len(name)))
                if is_all_caps(name):
                    findings.append(finding(path, lines, idx, col, f"don't use {name} in Go names; use CamelCase", "var-naming", "naming", 0.9, col + len(name)))
                elif "_" in name:
                    findings.append(finding(path, lines, idx, col, f"don't use underscores in Go names; {kind} {name} should be {camel(name)}", "var-naming", "naming", 0.9, col + len(name)))
    package_line = next((i for i, line in enumerate(lines, 1) if re.match(r"\s*package\s+\w+", line)), None)
    if package_line is not None:
        package_name = re.match(r"\s*package\s+(\w+)", lines[package_line - 1]).group(1)
        comment = comments.get(package_line)
        if not comment or not comment.startswith("Package " + package_name):
            findings.append(finding(path, lines, package_line, 1, "should have a package comment", "package-comments", "comments", end_col=len(lines[package_line - 1]) + 1))
    return [
        f for f in findings
        if f["rule"] not in disabled_rules and not directive_disabled(lines, f["line"], f["rule"])
    ]


def disabled_from_config(path):
    if not path or not os.path.exists(path):
        return set()
    disabled = set()
    current_rule = None
    for raw in open(path, encoding="utf-8"):
        line = raw.strip()
        match = re.match(r"\[rule\.([A-Za-z0-9_-]+)\]", line)
        if match:
            current_rule = match.group(1)
            continue
        if current_rule and re.match(r"(?i)disabled\s*=\s*true\b", line):
            disabled.add(current_rule)
    return disabled


def json_payload(findings):
    payload = []
    for f in findings:
        filename = rel(f["path"])
        payload.append({
            "Severity": f["severity"],
            "Failure": f["message"],
            "RuleName": f["rule"],
            "Category": f["category"],
            "Position": {
                "Start": {
                    "Filename": filename,
                    "Offset": f["offset"],
                    "Line": f["line"],
                    "Column": f["col"],
                },
                "End": {
                    "Filename": filename,
                    "Offset": f["end_offset"],
                    "Line": f["line"],
                    "Column": f["end_col"],
                },
            },
            "Confidence": f["confidence"],
            "ReplacementLine": "",
        })
    return payload


def render(findings, formatter):
    if formatter == "json":
        return json.dumps(json_payload(findings), separators=(",", ":")) + "\n"
    if formatter == "ndjson":
        return "".join(json.dumps(item, separators=(",", ":")) + "\n" for item in json_payload(findings))
    if formatter == "unix":
        return "".join(f"{rel(f['path'])}:{f['line']}:{f['col']}: [{f['rule']}] {f['message']}\n" for f in findings)
    if formatter == "plain":
        return "".join(f"{rel(f['path'])}:{f['line']}:{f['col']}: {f['message']} https://revive.run/r#{f['rule']}\n" for f in findings)
    if formatter == "checkstyle":
        by_file = {}
        for f in findings:
            by_file.setdefault(rel(f["path"]), []).append(f)
        out = ['<?xml version="1.0" encoding="UTF-8"?>\n', "<checkstyle version=\"revive\">\n"]
        for filename in sorted(by_file):
            out.append(f'  <file name="{html.escape(filename, quote=True)}">\n')
            for f in by_file[filename]:
                out.append(
                    f'    <error line="{f["line"]}" column="{f["col"]}" severity="{f["severity"]}" '
                    f'message="{html.escape(f["message"], quote=True)}" source="{html.escape(f["rule"], quote=True)}"></error>\n'
                )
            out.append("  </file>\n")
        out.append("</checkstyle>\n")
        return "".join(out)
    if formatter == "sarif":
        rules = []
        seen = set()
        results = []
        for f in findings:
            if f["rule"] not in seen:
                seen.add(f["rule"])
                rules.append({"id": f["rule"], "name": f["rule"], "shortDescription": {"text": f["rule"]}})
            results.append({
                "ruleId": f["rule"],
                "level": "warning",
                "message": {"text": f["message"]},
                "locations": [{
                    "physicalLocation": {
                        "artifactLocation": {"uri": rel(f["path"])},
                        "region": {"startLine": f["line"], "startColumn": f["col"]},
                    }
                }],
            })
        return json.dumps({
            "version": "2.1.0",
            "$schema": "https://json.schemastore.org/sarif-2.1.0.json",
            "runs": [{"tool": {"driver": {"name": "revive", "rules": rules}}, "results": results}],
        }, separators=(",", ":")) + "\n"
    if formatter == "friendly":
        if not findings:
            return "0 problems\n"
        body = []
        for f in findings:
            body.append(f"\n  ⚠  https://revive.run/r#{f['rule']}  {f['message']}\n  {rel(f['path'])}:{f['line']}:{f['col']}\n")
        body.append(f"\n⚠ {len(findings)} problems (0 errors, {len(findings)} warnings)\n")
        return "".join(body)
    if formatter == "stylish":
        return "".join(f"{rel(f['path'])}\n  {f['line']}:{f['col']}  warning  {f['message']}  {f['rule']}\n" for f in findings)
    return "".join(f"{rel(f['path'])}:{f['line']}:{f['col']}: {f['message']}\n" for f in findings)


def parse_args(argv):
    opts = {
        "formatter": "default",
        "set_exit_status": False,
        "version": False,
        "config": None,
        "exclude": [],
        "targets": [],
    }
    i = 0
    while i < len(argv):
        arg = argv[i]
        if arg == "-set_exit_status":
            opts["set_exit_status"] = True
        elif arg == "-version":
            opts["version"] = True
        elif arg in {"-formatter", "-config", "-max_open_files"}:
            i += 1
            if i < len(argv) and arg != "-max_open_files":
                opts[arg[1:]] = argv[i]
        elif arg == "-exclude":
            i += 1
            if i < len(argv):
                opts["exclude"].append(argv[i])
        elif arg in {"-h", "--help"}:
            opts["help"] = True
        elif arg.startswith("-"):
            pass
        else:
            opts["targets"].append(arg)
        i += 1
    return opts


def main():
    opts = parse_args(sys.argv[1:])
    if opts.get("version"):
        print("Version:\ta75b67b")
        print("Commit:\t\ta75b67b73b9edb91dfc9f302dd108fa9d3ea5b05")
        print("Built\t\t2026-04-17 19:59 UTC by build.sh")
        return 0
    if opts.get("help"):
        sys.stdout.write(HELP_TEXT)
        return 0
    if opts["formatter"] not in VALID_FORMATTERS:
        print(f"formatting - getting formatter: unknown formatter {opts['formatter']}")
        return 1
    findings = []
    disabled_rules = disabled_from_config(opts.get("config"))
    for path in collect_files(opts["targets"], opts["exclude"]):
        findings.extend(lint_file(path, disabled_rules))
    findings.sort(key=lambda f: (f["path"], f["order"], f["line"], f["col"], f["message"]))
    sys.stdout.write(render(findings, opts["formatter"]))
    return 1 if findings and opts["set_exit_status"] else 0


if __name__ == "__main__":
    sys.exit(main())
