#!/bin/bash
set -e
rm -f executable
cp src/revive_py.py executable
chmod +x executable
