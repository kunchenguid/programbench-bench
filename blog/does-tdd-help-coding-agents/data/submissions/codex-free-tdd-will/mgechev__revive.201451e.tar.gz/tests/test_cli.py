import os
import json
import subprocess
import textwrap
import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]


def build(tmp_path: Path) -> Path:
    subprocess.run(["bash", "compile.sh"], cwd=ROOT, check=True)
    exe = ROOT / "executable"
    assert exe.exists()
    return exe


def run_revive(exe: Path, args, cwd: Path):
    return subprocess.run(
        [str(exe), *args],
        cwd=cwd,
        text=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
    )


def write(path: Path, content: str):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(textwrap.dedent(content).lstrip(), encoding="utf-8")


class ReviveCliTests(unittest.TestCase):
    def test_default_formatter_reports_common_findings(self):
        import tempfile

        with tempfile.TemporaryDirectory() as td:
            tmp_path = Path(td)
            exe = build(tmp_path)
            write(
                tmp_path / "p" / "main.go",
                """
                package main

                func bad_name() {}
                """,
            )

            result = run_revive(exe, ["./p"], tmp_path)

            self.assertEqual(result.returncode, 0)
            self.assertEqual(
                result.stdout,
                "p/main.go:1:1: should have a package comment\n"
                "p/main.go:3:6: don't use underscores in Go names; func bad_name should be badName\n",
            )

    def test_exported_declarations_need_matching_comments(self):
        import tempfile

        with tempfile.TemporaryDirectory() as td:
            tmp_path = Path(td)
            exe = build(tmp_path)
            write(
                tmp_path / "comments" / "c.go",
                """
                // Package comments documents this package.
                package comments

                // Wrong thing.
                func Bad() {}

                var ExportedVar int
                const ExportedConst = 1
                """,
            )

            result = run_revive(exe, ["./comments"], tmp_path)

            self.assertEqual(result.returncode, 0)
            self.assertEqual(
                result.stdout,
                'comments/c.go:5:1: comment on exported function Bad should be of the form "Bad ..."\n'
                "comments/c.go:7:5: exported var ExportedVar should have comment or be unexported\n"
                "comments/c.go:8:7: exported const ExportedConst should have comment or be unexported\n",
            )

    def test_set_exit_status_turns_findings_into_failure(self):
        import tempfile

        with tempfile.TemporaryDirectory() as td:
            tmp_path = Path(td)
            exe = build(tmp_path)
            write(
                tmp_path / "p" / "p.go",
                """
                package p
                """,
            )

            result = run_revive(exe, ["-set_exit_status", "./p"], tmp_path)

            self.assertEqual(result.returncode, 1)
            self.assertEqual(result.stdout, "p/p.go:1:1: should have a package comment\n")

    def test_json_formatter_emits_revive_objects(self):
        import tempfile

        with tempfile.TemporaryDirectory() as td:
            tmp_path = Path(td)
            exe = build(tmp_path)
            write(
                tmp_path / "p" / "p.go",
                """
                package p

                func bad_name() {}
                """,
            )

            result = run_revive(exe, ["-formatter", "json", "./p"], tmp_path)

            self.assertEqual(result.returncode, 0)
            payload = json.loads(result.stdout)
            self.assertEqual(payload[0]["RuleName"], "package-comments")
            self.assertEqual(payload[1]["RuleName"], "var-naming")
            self.assertEqual(payload[1]["Category"], "naming")
            self.assertEqual(payload[0]["Severity"], "warning")
            self.assertEqual(payload[1]["Position"]["Start"]["Filename"], "p/p.go")
            self.assertEqual(payload[1]["Position"]["Start"]["Line"], 3)
            self.assertEqual(payload[1]["Position"]["Start"]["Column"], 6)

    def test_additional_default_rules_match_observed_messages(self):
        import tempfile

        with tempfile.TemporaryDirectory() as td:
            tmp_path = Path(td)
            exe = build(tmp_path)
            write(
                tmp_path / "rules" / "sample.go",
                """
                // Package rules documents this package.
                package rules

                var ALL_CAPS int

                type ExportedNoComment int

                func IfElse(x bool) int { if x { return 1 } else { return 2 } }

                func Range() { nums := []int{1}; for i, _ := range nums { _ = i } }
                """,
            )

            result = run_revive(exe, ["./rules"], tmp_path)

            self.assertEqual(result.returncode, 0)
            self.assertEqual(
                result.stdout,
                "rules/sample.go:4:5: exported var ALL_CAPS should have comment or be unexported\n"
                "rules/sample.go:6:6: exported type ExportedNoComment should have comment or be unexported\n"
                "rules/sample.go:8:1: exported function IfElse should have comment or be unexported\n"
                "rules/sample.go:10:1: exported function Range should have comment or be unexported\n"
                "rules/sample.go:8:50: if block ends with a return statement, so drop this else and outdent its block\n"
                "rules/sample.go:10:41: should omit 2nd value from range; this loop is equivalent to `for i := range ...`\n"
                "rules/sample.go:4:5: don't use ALL_CAPS in Go names; use CamelCase\n",
            )

    def test_config_can_disable_rules(self):
        import tempfile

        with tempfile.TemporaryDirectory() as td:
            tmp_path = Path(td)
            exe = build(tmp_path)
            write(
                tmp_path / "revive.toml",
                """
                [rule.var-naming]
                Disabled = true
                [rule.package-comments]
                Disabled = true
                """,
            )
            write(
                tmp_path / "p" / "p.go",
                """
                package p
                func bad_name() {}
                """,
            )

            result = run_revive(exe, ["-config", "revive.toml", "./p"], tmp_path)

            self.assertEqual(result.returncode, 0)
            self.assertEqual(result.stdout, "")

    def test_revive_disable_directives_suppress_following_findings(self):
        import tempfile

        with tempfile.TemporaryDirectory() as td:
            tmp_path = Path(td)
            exe = build(tmp_path)
            write(
                tmp_path / "direct" / "d.go",
                """
                package direct

                //revive:disable-next-line:var-naming
                func bad_name() {}

                //revive:disable
                func also_bad() {}
                //revive:enable

                func third_bad() {}
                """,
            )

            result = run_revive(exe, ["./direct"], tmp_path)

            self.assertEqual(result.returncode, 0)
            self.assertEqual(
                result.stdout,
                "direct/d.go:1:1: should have a package comment\n"
                "direct/d.go:10:6: don't use underscores in Go names; func third_bad should be thirdBad\n",
            )

    def test_unix_formatter_and_exclude(self):
        import tempfile

        with tempfile.TemporaryDirectory() as td:
            tmp_path = Path(td)
            exe = build(tmp_path)
            write(tmp_path / "keep" / "k.go", "package keep\nfunc bad_name() {}\n")
            write(tmp_path / "skip" / "s.go", "package skip\nfunc also_bad() {}\n")

            result = run_revive(exe, ["-formatter", "unix", "-exclude", "skip/...", "./..."], tmp_path)

            self.assertEqual(result.returncode, 0)
            self.assertEqual(
                result.stdout,
                "keep/k.go:1:1: [package-comments] should have a package comment\n"
                "keep/k.go:2:6: [var-naming] don't use underscores in Go names; func bad_name should be badName\n",
            )

    def test_version_help_and_unknown_formatter(self):
        import tempfile

        with tempfile.TemporaryDirectory() as td:
            tmp_path = Path(td)
            exe = build(tmp_path)

            version = run_revive(exe, ["-version"], tmp_path)
            self.assertEqual(version.returncode, 0)
            self.assertIn("Version:\ta75b67b\n", version.stdout)

            help_result = run_revive(exe, ["--help"], tmp_path)
            self.assertEqual(help_result.returncode, 0)
            self.assertIn("Usage of", help_result.stdout)
            self.assertIn("-formatter string", help_result.stdout)

            unknown = run_revive(exe, ["-formatter", "bogus"], tmp_path)
            self.assertEqual(unknown.returncode, 1)
            self.assertEqual(unknown.stdout, "formatting - getting formatter: unknown formatter bogus\n")


if __name__ == "__main__":
    unittest.main()
