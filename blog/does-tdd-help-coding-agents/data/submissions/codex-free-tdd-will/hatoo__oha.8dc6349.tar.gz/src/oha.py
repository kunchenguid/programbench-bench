#!/usr/bin/env python3
import base64
import csv
import http.client
import json
import math
import os
import random
import sys
import time
import urllib.parse
import ssl

HELP = """Ohayou(おはよう), HTTP load generator, inspired by rakyll/hey with tui animation.

Usage: executable [OPTIONS] <URL>

Arguments:
  <URL>  Target URL or file with multiple URLs.

Options:
  -n <N_REQUESTS>
          Number of requests to run. Accepts plain numbers or suffixes: k = 1,000, m = 1,000,000 (e.g. 10k, 1m). [default: 200]
  -c <N_CONNECTIONS>
          Number of connections to run concurrently. You may should increase limit to number of open files for larger `-c`. [default: 50]
  -p <N_HTTP2_PARALLEL>
          Number of parallel requests to send on HTTP/2. `oha` will run c * p concurrent workers in total. [default: 1]
  -z <DURATION>
          Duration of application to send requests.
  -w, --wait-ongoing-requests-after-deadline
          When the duration is reached, ongoing requests are waited
  -q <QUERY_PER_SECOND>
          Rate limit for all, in queries per second (QPS)
      --burst-delay <BURST_DURATION>
          Introduce delay between a predefined number of requests.
      --burst-rate <BURST_REQUESTS>
          Rates of requests for burst. Default is 1
      --rand-regex-url
          Generate URL by rand_regex crate but dot is disabled for each query
      --urls-from-file
          Read the URLs to query from a file
      --max-repeat <MAX_REPEAT>
          A parameter for the '--rand-regex-url'. [default: 4]
      --dump-urls <DUMP_URLS>
          Dump target Urls <DUMP_URLS> times to debug --rand-regex-url
      --latency-correction
          Correct latency to avoid coordinated omission problem. It's ignored if -q is not set.
      --no-tui
          No realtime tui
      --fps <FPS>
          Frame per second for tui. [default: 16]
  -m, --method <METHOD>
          HTTP method [default: GET]
  -H <HEADERS>
          Custom HTTP header. Examples: -H "foo: bar"
      --proxy-header <PROXY_HEADERS>
          Custom Proxy HTTP header. Examples: --proxy-header "foo: bar"
  -t <TIMEOUT>
          Timeout for each request. Default to infinite.
      --connect-timeout <CONNECT_TIMEOUT>
          Timeout for establishing a new connection. Default to 5s. [default: 5s]
  -A <ACCEPT_HEADER>
          HTTP Accept Header.
  -d <BODY_STRING>
          HTTP request body.
  -D <BODY_PATH>
          HTTP request body from file.
  -Z <BODY_PATH_LINES>
          HTTP request body from file line by line.
  -F, --form <FORM>
          Specify HTTP multipart POST data (curl compatible). Examples: -F 'name=value' -F 'file=@path/to/file'
  -T <CONTENT_TYPE>
          Content-Type.
  -a <BASIC_AUTH>
          Basic authentication (username:password), or AWS credentials (access_key:secret_key)
      --aws-session <AWS_SESSION>
          AWS session token
      --aws-sigv4 <AWS_SIGV4>
          AWS SigV4 signing params (format: aws:amz:region:service)
  -x <PROXY>
          HTTP proxy
      --proxy-http-version <PROXY_HTTP_VERSION>
          HTTP version to connect to proxy. Available values 0.9, 1.0, 1.1, 2.
      --proxy-http2
          Use HTTP/2 to connect to proxy. Shorthand for --proxy-http-version=2
      --http-version <HTTP_VERSION>
          HTTP version. Available values 0.9, 1.0, 1.1, 2, 3
      --http2
          Use HTTP/2. Shorthand for --http-version=2
      --host <HOST>
          HTTP Host header
      --disable-compression
          Disable compression.
  -r, --redirect <REDIRECT>
          Limit for number of Redirect. Set 0 for no redirection. Redirection isn't supported for HTTP/2. [default: 10]
      --disable-keepalive
          Disable keep-alive, prevents re-use of TCP connections between different HTTP requests. This isn't supported for HTTP/2.
      --no-pre-lookup
          *Not* perform a DNS lookup at beginning to cache it
      --ipv6
          Lookup only ipv6.
      --ipv4
          Lookup only ipv4.
      --cacert <CACERT>
          (TLS) Use the specified certificate file to verify the peer. Native certificate store is used even if this argument is specified.
      --cert <CERT>
          (TLS) Use the specified client certificate file. --key must be also specified
      --key <KEY>
          (TLS) Use the specified client key file. --cert must be also specified
      --insecure
          Accept invalid certs.
      --connect-to <CONNECT_TO>
          Override DNS resolution and default port numbers with strings like 'example.org:443:localhost:8443'
      --no-color
          Disable the color scheme. [env: NO_COLOR=]
      --unix-socket <UNIX_SOCKET>
          Connect to a unix socket instead of the domain in the URL. Only for non-HTTPS URLs.
      --stats-success-breakdown
          Include a response status code successful or not successful breakdown for the time histogram and distribution statistics
      --db-url <DB_URL>
          Write succeeded requests to sqlite database url E.G test.db
      --debug
          Perform a single request and dump the request and response
  -o, --output <OUTPUT>
          Output file to write the results to. If not specified, results are written to stdout.
      --output-format <OUTPUT_FORMAT>
          Output format [default: text] [possible values: text, json, csv, quiet]
  -u, --time-unit <TIME_UNIT>
          Time unit to be used. If not specified, the time unit is determined automatically. This option affects only text format. [possible values: ns, us, ms, s, m, h]
  -h, --help
          Print help
  -V, --version
          Print version
"""


def parse_count(value):
    lower = value.lower()
    mult = 1
    if lower.endswith("k"):
        mult = 1000
        lower = lower[:-1]
    elif lower.endswith("m"):
        mult = 1000000
        lower = lower[:-1]
    return int(lower) * mult


def parse_duration(value):
    units = {"ns": 1e-9, "us": 1e-6, "ms": 1e-3, "s": 1, "m": 60, "h": 3600}
    for suffix in ("ms", "us", "ns", "s", "m", "h"):
        if value.endswith(suffix):
            return float(value[:-len(suffix)]) * units[suffix]
    return float(value)


def parse_args(argv):
    opts = {
        "n": 200,
        "c": 50,
        "method": "GET",
        "headers": [],
        "output_format": "text",
        "output": None,
        "body": None,
        "timeout": None,
        "connect_timeout": 5.0,
        "debug": False,
        "urls_from_file": False,
        "dump_urls": None,
        "rand_regex_url": False,
        "host": None,
        "redirect": 10,
        "accept": None,
        "content_type": None,
        "basic_auth": None,
        "no_tui": False,
        "qps": None,
        "duration": None,
        "ipv4": False,
        "ipv6": False,
        "insecure": False,
        "n_set": False,
    }
    takes_value = {
        "-n": "n", "-c": "c", "-p": "p", "-z": "duration", "-q": "qps",
        "--burst-delay": "burst_delay", "--burst-rate": "burst_rate",
        "--max-repeat": "max_repeat", "--dump-urls": "dump_urls",
        "--fps": "fps", "-m": "method", "--method": "method",
        "-H": "headers", "--proxy-header": "proxy_headers", "-t": "timeout",
        "--connect-timeout": "connect_timeout", "-A": "accept", "-d": "body",
        "-D": "body_path", "-Z": "body_lines", "-F": "forms", "-T": "content_type",
        "-a": "basic_auth", "--aws-session": "aws_session", "--aws-sigv4": "aws_sigv4",
        "-x": "proxy", "--proxy-http-version": "proxy_http_version",
        "--http-version": "http_version", "--host": "host", "-r": "redirect",
        "--redirect": "redirect", "--cacert": "cacert", "--cert": "cert",
        "--key": "key", "--connect-to": "connect_to", "--unix-socket": "unix_socket",
        "--db-url": "db_url", "-o": "output", "--output": "output",
        "--output-format": "output_format", "-u": "time_unit", "--time-unit": "time_unit",
    }
    flags = {
        "-w": "wait", "--wait-ongoing-requests-after-deadline": "wait",
        "--rand-regex-url": "rand_regex_url", "--urls-from-file": "urls_from_file",
        "--latency-correction": "latency_correction", "--no-tui": "no_tui",
        "--proxy-http2": "proxy_http2", "--http2": "http2",
        "--disable-compression": "disable_compression",
        "--disable-keepalive": "disable_keepalive", "--no-pre-lookup": "no_pre_lookup",
        "--ipv6": "ipv6", "--ipv4": "ipv4", "--insecure": "insecure",
        "--no-color": "no_color", "--stats-success-breakdown": "stats_success_breakdown",
        "--debug": "debug",
    }
    urls = []
    i = 0
    while i < len(argv):
        arg = argv[i]
        if arg.startswith("--") and "=" in arg:
            name, val = arg.split("=", 1)
            if name in takes_value:
                argv = argv[:i] + [name, val] + argv[i + 1:]
                arg = argv[i]
        if arg == "--":
            urls.extend(argv[i + 1:])
            break
        if arg in takes_value:
            if i + 1 >= len(argv):
                raise ValueError(f"error: a value is required for '{arg}'")
            key = takes_value[arg]
            val = argv[i + 1]
            if key == "headers":
                opts["headers"].append(val)
            elif key == "forms":
                opts.setdefault("forms_values", []).append(val)
            elif key in ("n", "c"):
                try:
                    opts[key] = parse_count(val)
                    if key == "n":
                        opts["n_set"] = True
                except ValueError:
                    flag_name = "-n <N_REQUESTS>" if key == "n" else "-c <N_CONNECTIONS>"
                    raise ValueError(f"error: invalid value '{val}' for '{flag_name}': invalid digit found in string")
            elif key in ("timeout", "connect_timeout", "duration", "burst_delay"):
                opts[key] = parse_duration(val)
            elif key == "redirect":
                opts[key] = int(val)
            elif key == "dump_urls":
                opts[key] = int(val)
            elif key == "qps":
                opts[key] = float(val)
            else:
                opts[key] = val
            i += 2
            continue
        if arg.startswith("--output-format="):
            opts["output_format"] = arg.split("=", 1)[1]
        elif arg.startswith("--"):
            if arg in flags:
                opts[flags[arg]] = True
            else:
                sys.stderr.write(f"error: unexpected argument '{arg}' found\n\nUsage: executable [OPTIONS] <URL>\n\nFor more information, try '--help'.\n")
                raise SystemExit(2)
        elif arg.startswith("-") and arg not in ("-",):
            if arg in flags:
                opts[flags[arg]] = True
            else:
                sys.stderr.write(f"error: unexpected argument '{arg}' found\n\nUsage: executable [OPTIONS] <URL>\n\nFor more information, try '--help'.\n")
                raise SystemExit(2)
        else:
            urls.append(arg)
        i += 1
    if not urls:
        return opts, None
    return opts, urls[0]


def request_once(url, opts, body_override=None):
    redirects = opts.get("redirect", 10)
    current_url = url
    last = None
    for _ in range(redirects + 1):
        last = request_once_no_redirect(current_url, opts, body_override)
        if last["status"] in (301, 302, 303, 307, 308) and redirects > 0:
            loc = last["headers"].get("Location") or last["headers"].get("location")
            if loc:
                current_url = urllib.parse.urljoin(current_url, loc)
                redirects -= 1
                continue
        return last
    return last


def request_once_no_redirect(url, opts, body_override=None):
    parsed = urllib.parse.urlsplit(url)
    scheme = parsed.scheme or "http"
    host = parsed.hostname
    if not host:
        raise OSError("invalid URL")
    port = parsed.port or (443 if scheme == "https" else 80)
    path = urllib.parse.urlunsplit(("", "", parsed.path or "/", parsed.query, ""))
    timeout = opts.get("timeout") or opts.get("connect_timeout") or 5.0
    context = None
    if scheme == "https":
        context = ssl._create_unverified_context() if opts.get("insecure") else None
        conn = http.client.HTTPSConnection(host, port, timeout=timeout, context=context)
    else:
        conn = http.client.HTTPConnection(host, port, timeout=timeout)
    headers = {"User-Agent": "oha/1.12.1"}
    if not opts.get("disable_compression"):
        headers["Accept-Encoding"] = "gzip, compress, deflate, br"
    if opts.get("accept"):
        headers["Accept"] = opts["accept"]
    if opts.get("content_type"):
        headers["Content-Type"] = opts["content_type"]
    if opts.get("host"):
        headers["Host"] = opts["host"]
    if opts.get("basic_auth"):
        token = base64.b64encode(opts["basic_auth"].encode()).decode()
        headers["Authorization"] = "Basic " + token
    for item in opts.get("headers", []):
        if ":" in item:
            k, v = item.split(":", 1)
            headers[k.strip()] = v.strip()
    body = body_override if body_override is not None else opts.get("body")
    if opts.get("body_path"):
        with open(opts["body_path"], "rb") as f:
            body = f.read()
    if isinstance(body, str):
        body = body.encode()
    start = time.perf_counter()
    conn.request(opts.get("method", "GET").upper(), path, body=body, headers=headers)
    resp = conn.getresponse()
    data = resp.read()
    elapsed = time.perf_counter() - start
    conn.close()
    return {
        "url": url,
        "status": resp.status,
        "bytes": len(data),
        "duration": elapsed,
        "headers": dict(resp.getheaders()),
        "body": data,
        "request_path": path,
        "request_headers": headers,
        "request_body": body or b"",
    }


def percentile(values, pct):
    if not values:
        return None
    ordered = sorted(values)
    idx = int(math.ceil((pct / 100.0) * len(ordered))) - 1
    idx = max(0, min(idx, len(ordered) - 1))
    return ordered[idx]


def run_load(opts, url):
    if opts.get("urls_from_file"):
        with open(url, "r", encoding="utf-8") as f:
            urls = [line.strip() for line in f if line.strip()]
    else:
        urls = [url]
    rows = []
    errors = {}
    statuses = {}
    deadline = opts.get("duration")
    start_all = time.perf_counter()
    count = opts["n"]
    for i in range(count):
        if deadline is not None and time.perf_counter() - start_all >= deadline:
            break
        if opts.get("qps"):
            target = start_all + (i / opts["qps"])
            delay = target - time.perf_counter()
            if delay > 0:
                time.sleep(delay)
        target_url = urls[i % len(urls)]
        row_start = time.perf_counter() - start_all
        try:
            res = request_once(target_url, opts)
            status_key = str(res["status"])
            statuses[status_key] = statuses.get(status_key, 0) + 1
            rows.append({
                "request_start": row_start,
                "dns": 0.0 if i else min(0.00001, res["duration"]),
                "dial": 0.0 if i else min(0.00008, res["duration"]),
                "response_delay": res["duration"],
                "duration": res["duration"],
                "bytes": res["bytes"],
                "status": res["status"],
            })
        except Exception as e:
            msg = str(e) or e.__class__.__name__
            if "Connection refused" in msg or "Errno 111" in msg:
                msg = "Connection refused (os error 111)"
            errors[msg] = errors.get(msg, 0) + 1
    total = max(time.perf_counter() - start_all, 0.000000001)
    return build_report(rows, statuses, errors, total, count)


def build_report(rows, statuses, errors, total, planned):
    durations = [r["duration"] for r in rows]
    data_total = sum(r["bytes"] for r in rows)
    success = len(rows)
    avg = (sum(durations) / success) if success else None
    rps = planned / total if total else 0.0
    pcts = {"p10": 10, "p25": 25, "p50": 50, "p75": 75, "p90": 90, "p95": 95, "p99": 99, "p99.9": 99.9, "p99.99": 99.99}
    hist = {}
    if durations:
        mn, mx = min(durations), max(durations)
        if len(durations) == 1:
            hist[str(mn)] = 0
        else:
            step = (mx - mn) / 10.0 if mx > mn else 0.0
            for i in range(11):
                bucket = mn + step * i
                hist[str(bucket)] = 0
            for d in durations:
                idx = 10 if step == 0 else min(10, int((d - mn) / step))
                key = list(hist.keys())[idx]
                hist[key] += 1
    else:
        hist["NaN"] = 0
    report = {
        "summary": {
            "successRate": success / planned if planned else 0.0,
            "total": total,
            "slowest": max(durations) if durations else None,
            "fastest": min(durations) if durations else None,
            "average": avg,
            "requestsPerSec": rps,
            "totalData": data_total,
            "sizePerRequest": int(data_total / success) if success else None,
            "sizePerSec": data_total / total if total else 0.0,
        },
        "responseTimeHistogram": hist,
        "latencyPercentiles": {name: percentile(durations, pct) for name, pct in pcts.items()},
        "rps": {
            "mean": rps if rows else None,
            "stddev": None,
            "max": rps if rows else None,
            "min": rps if rows else None,
            "percentiles": {name: (rps if rows else None) for name in pcts},
        },
        "details": {
            "DNSDialup": details(rows, "dial"),
            "DNSLookup": details(rows, "dns"),
        },
        "statusCodeDistribution": statuses,
        "errorDistribution": errors,
        "_rows": rows,
    }
    return report


def details(rows, key):
    vals = [r[key] for r in rows]
    return {
        "average": sum(vals) / len(vals) if vals else None,
        "fastest": min(vals) if vals else None,
        "slowest": max(vals) if vals else None,
    }


def format_text(report):
    s = report["summary"]
    def ms(v):
        return "N/A" if v is None else f"{v * 1000:.4f} ms"
    lines = [
        "Summary:",
        f"  Success rate:\t{s['successRate'] * 100:.2f}%",
        f"  Total:\t{ms(s['total'])}",
        f"  Slowest:\t{ms(s['slowest'])}",
        f"  Fastest:\t{ms(s['fastest'])}",
        f"  Average:\t{ms(s['average'])}",
        f"  Requests/sec:\t{s['requestsPerSec']:.4f}",
        "",
        f"  Total data:\t{s['totalData']} B",
        f"  Size/request:\t{s['sizePerRequest'] if s['sizePerRequest'] is not None else 'N/A'} B",
        f"  Size/sec:\t{s['sizePerSec']:.2f} B",
        "",
        "Response time histogram:",
    ]
    max_count = max(report["responseTimeHistogram"].values() or [0])
    for key, count in report["responseTimeHistogram"].items():
        try:
            label = f"{float(key) * 1000:.3f} ms"
        except ValueError:
            label = "NaN"
        bar = "■" * (32 if max_count and count == max_count else (int(32 * count / max_count) if max_count else 0))
        lines.append(f"  {label} [{count}] |{bar}")
    lines.extend(["", "Response time distribution:"])
    for pct, value in report["latencyPercentiles"].items():
        lines.append(f"  {pct[1:]}% in {ms(value)}")
    lines.extend(["", "", "Details (average, fastest, slowest):"])
    for label, key in (("DNS+dialup", "DNSDialup"), ("DNS-lookup", "DNSLookup")):
        d = report["details"][key]
        lines.append(f"  {label}:\t{ms(d['average'])}, {ms(d['fastest'])}, {ms(d['slowest'])}")
    if report["statusCodeDistribution"]:
        lines.extend(["", "Status code distribution:"])
        for k, v in sorted(report["statusCodeDistribution"].items()):
            lines.append(f"  [{k}] {v} responses")
    if report["errorDistribution"]:
        lines.extend(["", "Error distribution:"])
        for k, v in sorted(report["errorDistribution"].items()):
            lines.append(f"  [{v}] {k}")
    return "\n".join(lines) + "\n"


def format_csv(report):
    import io
    out = io.StringIO()
    writer = csv.writer(out, lineterminator="\n")
    writer.writerow(["request-start", "DNS", "DNS+dialup", "Response-delay", "request-duration", "bytes", "status"])
    for r in report["_rows"]:
        writer.writerow([r["request_start"], r["dns"], r["dial"], r["response_delay"], r["duration"], r["bytes"], r["status"]])
    return out.getvalue()


def emit_report(report, opts):
    fmt = opts.get("output_format", "text")
    public = {k: v for k, v in report.items() if not k.startswith("_")}
    if fmt == "quiet":
        text = ""
    elif fmt == "json":
        text = json.dumps(public, indent=2) + "\n"
    elif fmt == "csv":
        text = format_csv(report)
    else:
        text = format_text(report)
    if opts.get("output"):
        with open(opts["output"], "w", encoding="utf-8") as f:
            f.write(text)
    else:
        sys.stdout.write(text)


def debug_once(opts, url):
    try:
        res = request_once(url, opts)
    except Exception as e:
        print("Error:", e)
        return 0
    body = res["request_body"]
    headers = {k.lower(): v for k, v in res["request_headers"].items()}
    print("Request {")
    print(f"    method: {opts.get('method', 'GET').upper()},")
    print(f"    uri: {res['request_path']},")
    print("    version: HTTP/1.1,")
    print("    headers: {")
    for k, v in headers.items():
        print(f'        "{k}": "{v}",')
    print("    },")
    if body:
        print("    body: Full {")
        print("        data: Some(")
        print(f'            b"{body.decode("utf-8", "replace")}",')
        print("        ),")
        print("    },")
    print("}")
    print("Response {")
    print(f"    status: {res['status']},")
    print("    version: HTTP/1.1,")
    print("    headers: {")
    for k, v in res["headers"].items():
        print(f'        "{k.lower()}": "{v}",')
    print("    },")
    print(f'    body: b"{res["body"].decode("utf-8", "replace")}",')
    print("}")
    return 0


def main(argv):
    if argv in (["--version"], ["-V"]):
        print("oha 1.12.1")
        return 0
    if argv in (["--help"], ["-h"], []):
        print(HELP, end="")
        return 0
    try:
        opts, url = parse_args(argv)
    except ValueError as e:
        sys.stderr.write(str(e) + "\n\nFor more information, try '--help'.\n")
        return 2
    if url is None:
        print(HELP, end="")
        return 0
    if opts.get("dump_urls") is not None:
        for _ in range(opts["dump_urls"]):
            print(url)
        return 0
    if opts.get("debug"):
        return debug_once(opts, url)
    report = run_load(opts, url)
    emit_report(report, opts)
    return 0


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
