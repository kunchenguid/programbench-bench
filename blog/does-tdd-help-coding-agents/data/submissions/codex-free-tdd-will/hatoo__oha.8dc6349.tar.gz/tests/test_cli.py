import os
import json
import subprocess
import threading
import unittest
from http.server import BaseHTTPRequestHandler, HTTPServer
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]


class _Handler(BaseHTTPRequestHandler):
    def do_GET(self):
        body = b"ok"
        self.send_response(200)
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def log_message(self, *args):
        pass


class Server:
    def __enter__(self):
        self.httpd = HTTPServer(("127.0.0.1", 0), _Handler)
        self.thread = threading.Thread(target=self.httpd.serve_forever, daemon=True)
        self.thread.start()
        return f"http://127.0.0.1:{self.httpd.server_port}/"

    def __exit__(self, *exc):
        self.httpd.shutdown()
        self.thread.join()
        self.httpd.server_close()


def run_cmd(*args):
    exe = ROOT / "executable"
    return subprocess.run(
        [str(exe), *args],
        cwd=ROOT,
        text=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
    )


class CliTests(unittest.TestCase):
    def test_version_matches_oha_release(self):
        result = run_cmd("--version")

        self.assertEqual(result.returncode, 0)
        self.assertEqual(result.stdout, "oha 1.12.1\n")
        self.assertEqual(result.stderr, "")

    def test_help_describes_required_url_and_output_formats(self):
        result = run_cmd("--help")

        self.assertEqual(result.returncode, 0)
        self.assertIn("Ohayou(", result.stdout)
        self.assertIn("Usage: executable [OPTIONS] <URL>", result.stdout)
        self.assertIn("--output-format <OUTPUT_FORMAT>", result.stdout)
        self.assertIn("[possible values: text, json, csv, quiet]", result.stdout)
        self.assertEqual(result.stderr, "")

    def test_json_output_reports_successful_requests(self):
        with Server() as url:
            result = run_cmd("--no-tui", "-n", "3", "-c", "1", "--output-format", "json", url)

        self.assertEqual(result.returncode, 0)
        payload = json.loads(result.stdout)
        self.assertEqual(payload["summary"]["successRate"], 1.0)
        self.assertEqual(payload["summary"]["totalData"], 6)
        self.assertEqual(payload["summary"]["sizePerRequest"], 2)
        self.assertEqual(payload["statusCodeDistribution"], {"200": 3})
        self.assertEqual(payload["errorDistribution"], {})

    def test_csv_output_contains_one_row_per_successful_request(self):
        with Server() as url:
            result = run_cmd("--no-tui", "-n", "2", "-c", "1", "--output-format", "csv", url)

        lines = result.stdout.strip().splitlines()
        self.assertEqual(lines[0], "request-start,DNS,DNS+dialup,Response-delay,request-duration,bytes,status")
        self.assertEqual(len(lines), 3)
        self.assertTrue(lines[1].endswith(",2,200"))
        self.assertEqual(result.stderr, "")

    def test_quiet_output_suppresses_success_report(self):
        with Server() as url:
            result = run_cmd("--no-tui", "-n", "1", "--output-format", "quiet", url)

        self.assertEqual(result.returncode, 0)
        self.assertEqual(result.stdout, "")
        self.assertEqual(result.stderr, "")

    def test_connection_errors_are_reported_in_json(self):
        result = run_cmd("--no-tui", "-n", "2", "-c", "1", "--output-format", "json", "http://127.0.0.1:9/")

        payload = json.loads(result.stdout)
        self.assertEqual(payload["summary"]["successRate"], 0.0)
        self.assertEqual(payload["statusCodeDistribution"], {})
        self.assertEqual(payload["errorDistribution"], {"Connection refused (os error 111)": 2})


if __name__ == "__main__":
    unittest.main()
