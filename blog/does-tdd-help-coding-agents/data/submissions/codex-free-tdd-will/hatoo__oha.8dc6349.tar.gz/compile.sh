#!/bin/bash
set -e
rm -f executable
cp src/oha.py executable
chmod +x executable
