#!/bin/bash
set -e
cp src/lazygit_clone.py executable
chmod +x executable
