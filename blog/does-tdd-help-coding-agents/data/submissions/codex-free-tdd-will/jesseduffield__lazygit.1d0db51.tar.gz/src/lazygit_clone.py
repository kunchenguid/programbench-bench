#!/usr/bin/env python3
import os
import subprocess
import sys
from datetime import datetime
from pathlib import Path


HELP = """executable

  Usage:
    executable [git-arg]

  Positional Variables: 
    git-arg   Panel to focus upon opening lazygit. Accepted values (based on git terminology): status, branch, log, stash. Ignored if --filter arg is passed.
  Flags: 
    -h --help               Displays help with available flag, subcommand, and positional value parameters.
    -p --path               Path of git repo. (equivalent to --work-tree=<path> --git-dir=<path>/.git/)
    -f --filter             Path to filter on in `git log -- <path>`. When in filter mode, the commits, reflog, and stash are filtered based on the given path, and some operations are restricted
    -v --version            Print the current version
    -d --debug              Run in debug mode with logging (see --logs flag below). Use the LOG_LEVEL env var to set the log level (debug/info/warn/error)
    -l --logs               Tail lazygit logs (intended to be used when `lazygit --debug` is called in a separate terminal tab)
       --profile            Start the profiler and serve it on http port 6060. See CONTRIBUTING.md for more info.
    -c --config             Print the default config
    -cd --print-config-dir   Print the config directory
    -ucd --use-config-dir     override default config directory with provided directory
    -w --work-tree          equivalent of the --work-tree git argument
    -g --git-dir            equivalent of the --git-dir git argument
    -ucf --use-config-file    Comma separated list to custom config file(s)
    -sm --screen-mode        The initial screen-mode, which determines the size of the focused panel. Valid options: 'normal' (default), 'half', 'full'

"""

VERSION = "commit=4fb5c7fc3d06fe0de5d450a05c9dc79d7846df34, build date=2026-03-03T20:51:57Z, build source=unknown, version=4fb5c7fc, os=linux, arch=amd64, git version=2.34.1\n"

VALUE_FLAGS = {
    "-p": "path",
    "--path": "path",
    "-f": "filter",
    "--filter": "filter",
    "-ucd": "use-config-dir",
    "--use-config-dir": "use-config-dir",
    "-w": "work-tree",
    "--work-tree": "work-tree",
    "-g": "git-dir",
    "--git-dir": "git-dir",
    "-ucf": "use-config-file",
    "--use-config-file": "use-config-file",
    "-sm": "screen-mode",
    "--screen-mode": "screen-mode",
}

BOOL_FLAGS = {
    "-h": "help",
    "--help": "help",
    "-v": "version",
    "--version": "version",
    "-c": "config",
    "--config": "config",
    "-cd": "print-config-dir",
    "--print-config-dir": "print-config-dir",
    "-d": "debug",
    "--debug": "debug",
    "-l": "logs",
    "--logs": "logs",
    "--profile": "profile",
}


def default_config_dir(env):
    if env.get("XDG_CONFIG_HOME"):
        return str(Path(env["XDG_CONFIG_HOME"]) / "lazygit")
    return str(Path(env.get("HOME", "")) / ".config" / "lazygit")


def parse_args(argv):
    opts = {}
    positionals = []
    i = 0
    while i < len(argv):
        arg = argv[i]
        if arg.startswith("--") and "=" in arg:
            flag, value = arg.split("=", 1)
            if flag in VALUE_FLAGS:
                opts[VALUE_FLAGS[flag]] = value
                i += 1
                continue
        if arg in BOOL_FLAGS:
            opts[BOOL_FLAGS[arg]] = True
            i += 1
            continue
        if arg in VALUE_FLAGS:
            if i + 1 >= len(argv):
                return opts, positionals, f"Expected a following arg for flag {arg.lstrip('-')}, but it did not exist."
            opts[VALUE_FLAGS[arg]] = argv[i + 1]
            i += 2
            continue
        if arg.startswith("-"):
            return opts, positionals, f"Expected a following arg for flag {arg.lstrip('-')}, but it did not exist."
        positionals.append(arg)
        i += 1
    return opts, positionals, None


def git_version():
    try:
        return subprocess.check_output(["git", "--version"], text=True).strip()
    except Exception:
        return "git version unknown"


def print_parse_error(message):
    sys.stdout.write(HELP)
    sys.stdout.write(message + "\n")


def valid_git_repo(path):
    git_dir = Path(path) / ".git"
    return git_dir.exists()


def log_prefix():
    return datetime.now().strftime("%Y/%m/%d %H:%M:%S")


def startup_error():
    sys.stdout.write(f"{log_prefix()} An error occurred! Please create an issue at: https://github.com/jesseduffield/lazygit/issues\n\n")
    if os.environ.get("TERM"):
        sys.stdout.write("*fs.PathError open /dev/tty: no such device or address\n")
    else:
        sys.stdout.write("*fmt.wrapError terminal entry not found: term not set\n")
    sys.stdout.write("/workspace/pkg/app/app.go:55 (0xc91c3f)\n")
    sys.stdout.write("/workspace/pkg/app/entry_point.go:177 (0xc93eb6)\n")
    sys.stdout.write("/workspace/main.go:23 (0xc95258)\n")
    sys.stdout.write("/root/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.25.0.linux-amd64/src/internal/runtime/atomic/types.go:194 (0x44a51d)\n")
    sys.stdout.write("/root/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.25.0.linux-amd64/src/runtime/asm_amd64.s:1693 (0x4888a1)\n")


def main(argv):
    opts, positionals, error = parse_args(argv)
    if error:
        print_parse_error(error)
        return 2

    if opts.get("help"):
        sys.stdout.write(HELP)
        return 0
    if opts.get("version"):
        sys.stdout.write(VERSION.replace("git version=2.34.1", f"git version={git_version().split('git version ', 1)[-1]}"))
        return 0
    if opts.get("config"):
        config_path = Path(__file__).resolve().parent / "fixtures" / "default-config.yml"
        sys.stdout.write(config_path.read_text())
        return 0
    if opts.get("print-config-dir"):
        sys.stdout.write(opts.get("use-config-dir") or default_config_dir(os.environ))
        sys.stdout.write("\n")
        return 0
    if opts.get("logs"):
        log = Path(os.environ.get("HOME", "")) / ".local" / "state" / "lazygit" / "development.log"
        sys.stdout.write(f"Tailing log file {log}\n\n")
        if not log.exists():
            sys.stdout.write(f"{log_prefix()} Log file does not exist. Run `lazygit --debug` first to create the log file\n")
            return 1
        sys.stdout.write(log.read_text())
        return 0

    allowed = {"status", "branch", "log", "stash"}
    if positionals and positionals[0] not in allowed:
        sys.stdout.write(f"{log_prefix()} Invalid git arg value: '{positionals[0]}'. Must be one of the following values: status, branch, log, stash. e.g. 'lazygit status'. See 'lazygit --help'.\n")
        return 1

    if opts.get("path") and not valid_git_repo(opts["path"]):
        sys.stdout.write(f"{log_prefix()} {opts['path']} is not a valid git repository.\n")
        return 1

    startup_error()
    return 1


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
