package main

import (
	"bufio"
	"flag"
	"fmt"
	"go/scanner"
	"go/token"
	"io"
	"log"
	"os"
	"path/filepath"
	"sort"
	"strings"
)

type options struct {
	files, html, plumbing, vendor, verbose bool
	threshold                              int
}

type fileData struct {
	path  string
	src   []byte
	toks  []string
	lines []int
}

type occ struct{ file, start, end, startLine, endLine int }
type group struct {
	occs   []occ
	length int
	key    string
}

func usage(out io.Writer) {
	fmt.Fprint(out, `Usage: dupl [flags] [paths]

Paths:
  If the given path is a file, dupl will use it regardless of
  the file extension. If it is a directory, it will recursively
  search for *.go files in that directory.

  If no path is given, dupl will recursively search for *.go
  files in the current directory.

Flags:
  -files
    	read file names from stdin one at each line
  -html
    	output the results as HTML, including duplicate code fragments
  -plumbing
    	plumbing (easy-to-parse) output for consumption by scripts or tools
  -t, -threshold size
    	minimum token sequence size as a clone (default 15)
  -vendor
    	check files in vendor directory
  -v, -verbose
    	explain what is being done

Examples:
  dupl -t 100
    	Search clones in the current directory of size at least
    	100 tokens.
  dupl $(find app/ -name *_test.go)
    	Search for clones in tests in the app directory.
  find app/ -name *_test.go |dupl -files
    	The same as above.
`)
}

func main() {
	for _, arg := range os.Args[1:] {
		if arg == "--help" || arg == "-help" || arg == "-h" {
			usage(os.Stderr)
			os.Exit(2)
		}
	}
	var opt options
	fs := flag.NewFlagSet("dupl", flag.ExitOnError)
	fs.SetOutput(os.Stderr)
	fs.Usage = func() { usage(fs.Output()) }
	fs.BoolVar(&opt.files, "files", false, "read file names from stdin one at each line")
	fs.BoolVar(&opt.html, "html", false, "output the results as HTML, including duplicate code fragments")
	fs.BoolVar(&opt.plumbing, "plumbing", false, "plumbing (easy-to-parse) output for consumption by scripts or tools")
	fs.IntVar(&opt.threshold, "t", 15, "minimum token sequence size as a clone")
	fs.IntVar(&opt.threshold, "threshold", 15, "minimum token sequence size as a clone")
	fs.BoolVar(&opt.vendor, "vendor", false, "check files in vendor directory")
	fs.BoolVar(&opt.verbose, "v", false, "explain what is being done")
	fs.BoolVar(&opt.verbose, "verbose", false, "explain what is being done")
	if err := fs.Parse(os.Args[1:]); err != nil {
		os.Exit(2)
	}
	if err := run(opt, fs.Args(), os.Stdout); err != nil {
		log.Fatal(err)
	}
}

func run(opt options, args []string, out io.Writer) error {
	paths, err := gatherPaths(args, opt)
	if err != nil {
		return err
	}
	files := make([]fileData, 0, len(paths))
	for _, p := range paths {
		f, err := scanFile(p)
		if err != nil {
			return err
		}
		if len(f.toks) > 0 {
			files = append(files, f)
		}
	}
	if opt.verbose {
		log.Print("Building suffix tree")
		log.Print("Searching for clones")
	}
	groups := findGroups(files, opt.threshold)
	if opt.html {
		writeHTML(out, files, groups)
		return nil
	}
	if opt.plumbing {
		writePlumbing(out, files, groups)
		return nil
	}
	writeText(out, files, groups)
	return nil
}

func gatherPaths(args []string, opt options) ([]string, error) {
	var roots []string
	if opt.files {
		sc := bufio.NewScanner(os.Stdin)
		for sc.Scan() {
			if s := strings.TrimSpace(sc.Text()); s != "" {
				roots = append(roots, s)
			}
		}
		if err := sc.Err(); err != nil {
			return nil, err
		}
	} else {
		roots = args
		if len(roots) == 0 {
			roots = []string{"."}
		}
	}
	var paths []string
	for _, root := range roots {
		info, err := os.Lstat(root)
		if err != nil {
			return nil, err
		}
		if !info.IsDir() {
			paths = append(paths, root)
			continue
		}
		err = filepath.WalkDir(root, func(path string, d os.DirEntry, err error) error {
			if err != nil {
				return err
			}
			if d.IsDir() {
				if !opt.vendor && d.Name() == "vendor" {
					return filepath.SkipDir
				}
				return nil
			}
			if strings.HasSuffix(d.Name(), ".go") {
				paths = append(paths, path)
			}
			return nil
		})
		if err != nil {
			return nil, err
		}
	}
	sort.Strings(paths)
	return paths, nil
}

func scanFile(path string) (fileData, error) {
	src, err := os.ReadFile(path)
	if err != nil {
		return fileData{}, err
	}
	fs := token.NewFileSet()
	file := fs.AddFile(path, fs.Base(), len(src))
	var s scanner.Scanner
	s.Init(file, src, nil, 0)
	fd := fileData{path: path, src: src}
	for {
		pos, tok, lit := s.Scan()
		if tok == token.EOF {
			break
		}
		if tok == token.SEMICOLON && lit == "\n" {
			continue
		}
		fd.toks = append(fd.toks, norm(tok))
		fd.lines = append(fd.lines, fs.Position(pos).Line)
	}
	return fd, nil
}

func norm(tok token.Token) string {
	switch tok {
	case token.IDENT:
		return "ID"
	case token.INT, token.FLOAT, token.IMAG, token.CHAR, token.STRING:
		return "LIT"
	default:
		return tok.String()
	}
}

func findGroups(files []fileData, threshold int) []group {
	if threshold <= 0 {
		threshold = 1
	}
	byKey := map[string]map[string]occ{}
	for i := range files {
		for j := i + 1; j < len(files); j++ {
			collectPair(files, i, j, threshold, byKey)
		}
		collectSameFile(files, i, threshold, byKey)
	}
	groups := make([]group, 0, len(byKey))
	for key, om := range byKey {
		if len(om) < 2 {
			continue
		}
		occs := make([]occ, 0, len(om))
		for _, o := range om {
			occs = append(occs, o)
		}
		sortOccs(occs, files)
		groups = append(groups, group{occs: occs, length: occs[0].end - occs[0].start, key: key})
	}
	sort.Slice(groups, func(a, b int) bool {
		if groups[a].length != groups[b].length {
			return groups[a].length > groups[b].length
		}
		oa, ob := groups[a].occs[0], groups[b].occs[0]
		if files[oa.file].path != files[ob.file].path {
			return files[oa.file].path < files[ob.file].path
		}
		return oa.start < ob.start
	})
	var selected []group
	for _, g := range groups {
		contained := false
		for _, sg := range selected {
			if groupContained(g, sg, files) {
				contained = true
				break
			}
		}
		if !contained {
			selected = append(selected, g)
		}
	}
	sort.Slice(selected, func(a, b int) bool {
		oa, ob := selected[a].occs[0], selected[b].occs[0]
		if files[oa.file].path != files[ob.file].path {
			return files[oa.file].path < files[ob.file].path
		}
		return oa.start < ob.start
	})
	return selected
}

func collectPair(files []fileData, i, j, threshold int, byKey map[string]map[string]occ) {
	a, b := files[i], files[j]
	for x := range a.toks {
		for y := range b.toks {
			if a.toks[x] != b.toks[y] {
				continue
			}
			if x > 0 && y > 0 && a.toks[x-1] == b.toks[y-1] {
				continue
			}
			l := 0
			for x+l < len(a.toks) && y+l < len(b.toks) && a.toks[x+l] == b.toks[y+l] {
				l++
			}
			if l >= threshold {
				addMatch(files, byKey, i, x, j, y, l)
			}
		}
	}
}

func collectSameFile(files []fileData, i, threshold int, byKey map[string]map[string]occ) {
	a := files[i]
	for x := 0; x < len(a.toks); x++ {
		for y := x + threshold; y < len(a.toks); y++ {
			if a.toks[x] != a.toks[y] {
				continue
			}
			if x > 0 && y > 0 && a.toks[x-1] == a.toks[y-1] {
				continue
			}
			l := 0
			for x+l < len(a.toks) && y+l < len(a.toks) && a.toks[x+l] == a.toks[y+l] {
				l++
			}
			if l >= threshold {
				addMatch(files, byKey, i, x, i, y, l)
			}
		}
	}
}

func addMatch(files []fileData, byKey map[string]map[string]occ, i, x, j, y, l int) {
	key := strings.Join(files[i].toks[x:x+l], "\x00")
	if byKey[key] == nil {
		byKey[key] = map[string]occ{}
	}
	oi := makeOcc(files[i], i, x, l)
	oj := makeOcc(files[j], j, y, l)
	byKey[key][fmt.Sprintf("%d:%d:%d", oi.file, oi.start, oi.end)] = oi
	byKey[key][fmt.Sprintf("%d:%d:%d", oj.file, oj.start, oj.end)] = oj
}

func makeOcc(f fileData, idx, start, l int) occ {
	return occ{file: idx, start: start, end: start + l, startLine: f.lines[start], endLine: f.lines[start+l-1]}
}

func sortOccs(occs []occ, files []fileData) {
	sort.Slice(occs, func(i, j int) bool {
		if files[occs[i].file].path != files[occs[j].file].path {
			return files[occs[i].file].path < files[occs[j].file].path
		}
		return occs[i].start < occs[j].start
	})
}

func groupContained(g, sg group, files []fileData) bool {
	for _, o := range g.occs {
		ok := false
		for _, so := range sg.occs {
			if o.file == so.file && o.start >= so.start && o.end <= so.end {
				ok = true
				break
			}
		}
		if !ok {
			return false
		}
	}
	return true
}

func writeText(out io.Writer, files []fileData, groups []group) {
	if len(groups) == 0 {
		fmt.Fprintln(out)
	}
	for _, g := range groups {
		fmt.Fprintf(out, "found %d clones:\n", len(g.occs))
		for _, o := range g.occs {
			fmt.Fprintf(out, "  %s:%d,%d\n", files[o.file].path, o.startLine, o.endLine)
		}
		fmt.Fprintln(out)
	}
	fmt.Fprintf(out, "Found total %d clone groups.\n", len(groups))
}

func writePlumbing(out io.Writer, files []fileData, groups []group) {
	for _, g := range groups {
		for i, o := range g.occs {
			for j, p := range g.occs {
				if i == j {
					continue
				}
				fmt.Fprintf(out, "%s:%d-%d: duplicate of %s:%d-%d\n", files[o.file].path, o.startLine, o.endLine, files[p.file].path, p.startLine, p.endLine)
			}
		}
	}
}

func writeHTML(out io.Writer, files []fileData, groups []group) {
	fmt.Fprint(out, `<!DOCTYPE html>
<meta charset="utf-8"/>
<title>Duplicates</title>
<style>
	pre {
		background-color: #FFD;
		border: 1px solid #E2E2E2;
		padding: 1ex;
	}
</style>
`)
	for i, g := range groups {
		fmt.Fprintf(out, "<h1>#%d found %d clones</h1>\n", i+1, len(g.occs))
		for _, o := range g.occs {
			fmt.Fprintf(out, "<h2>%s:%d</h2>\n<pre>%s</pre>\n", files[o.file].path, o.startLine, htmlEscape(fragment(files[o.file], o.startLine, o.endLine)))
		}
	}
}

func fragment(f fileData, start, end int) string {
	lines := strings.Split(string(f.src), "\n")
	if start < 1 {
		start = 1
	}
	if end > len(lines) {
		end = len(lines)
	}
	return strings.Join(lines[start-1:end], "\n")
}

func htmlEscape(s string) string {
	s = strings.ReplaceAll(s, "&", "&amp;")
	s = strings.ReplaceAll(s, "<", "&lt;")
	s = strings.ReplaceAll(s, ">", "&gt;")
	return s
}
