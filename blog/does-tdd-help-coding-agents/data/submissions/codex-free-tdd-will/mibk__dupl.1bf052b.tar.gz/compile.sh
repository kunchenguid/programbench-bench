#!/bin/bash
set -e
go build -o executable ./cmd/dupl
chmod +x executable
