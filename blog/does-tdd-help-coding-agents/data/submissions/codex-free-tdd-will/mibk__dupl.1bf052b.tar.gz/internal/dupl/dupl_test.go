package dupl

import (
	"os"
	"os/exec"
	"path/filepath"
	"strings"
	"testing"
)

func buildCLI(t *testing.T) string {
	t.Helper()
	exe := filepath.Join(t.TempDir(), "dupl")
	cmd := exec.Command("go", "build", "-o", exe, "./cmd/dupl")
	cmd.Dir = filepath.Join("..", "..")
	if out, err := cmd.CombinedOutput(); err != nil {
		t.Fatalf("build failed: %v\n%s", err, out)
	}
	return exe
}

func TestHelpMatchesDocumentedUsage(t *testing.T) {
	exe := buildCLI(t)
	cmd := exec.Command(exe, "--help")
	out, err := cmd.CombinedOutput()
	if err == nil {
		t.Fatalf("expected help to exit non-zero")
	}
	text := string(out)
	for _, want := range []string{"Usage: dupl [flags] [paths]", "-threshold size", "minimum token sequence size as a clone (default 15)"} {
		if !strings.Contains(text, want) {
			t.Fatalf("help missing %q in:\n%s", want, text)
		}
	}
}

func TestReportsDuplicateGroupForTwoGoFiles(t *testing.T) {
	exe := buildCLI(t)
	dir := t.TempDir()
	mustWrite := func(name, body string) {
		t.Helper()
		if err := os.WriteFile(filepath.Join(dir, name), []byte(body), 0644); err != nil {
			t.Fatal(err)
		}
	}
	mustWrite("a.go", "package main\n\nfunc one() {\n    x := 1\n    y := 2\n    println(x + y)\n}\n")
	mustWrite("b.go", "package main\n\nfunc two() {\n    x := 1\n    y := 2\n    println(x + y)\n}\n")
	cmd := exec.Command(exe, "-t", "5", dir)
	out, err := cmd.CombinedOutput()
	if err != nil {
		t.Fatalf("dupl failed: %v\n%s", err, out)
	}
	got := string(out)
	if !strings.Contains(got, "found 2 clones:") || !strings.Contains(got, filepath.Join(dir, "a.go")+":1,7") || !strings.Contains(got, "Found total 1 clone groups.") {
		t.Fatalf("unexpected output:\n%s", got)
	}
}

func TestNoCloneReportKeepsBlankLineBeforeSummary(t *testing.T) {
	exe := buildCLI(t)
	dir := t.TempDir()
	if err := os.WriteFile(filepath.Join(dir, "a.go"), []byte("package main\nfunc one(){}\n"), 0644); err != nil {
		t.Fatal(err)
	}
	cmd := exec.Command(exe, "-t", "100", dir)
	out, err := cmd.CombinedOutput()
	if err != nil {
		t.Fatalf("dupl failed: %v\n%s", err, out)
	}
	if got, want := string(out), "\nFound total 0 clone groups.\n"; got != want {
		t.Fatalf("got %q, want %q", got, want)
	}
}
