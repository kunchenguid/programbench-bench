module reimpldupl

go 1.20
