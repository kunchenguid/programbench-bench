#!/usr/bin/env python3
import os
import re
import shutil
import subprocess
import tempfile
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
BIN = ROOT / "executable"


def run(cmd, cwd, check=True):
    result = subprocess.run(
        cmd,
        cwd=cwd,
        text=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        check=False,
    )
    if check and result.returncode != 0:
        raise AssertionError(f"{cmd} failed\nstdout={result.stdout}\nstderr={result.stderr}")
    return result


def git(cwd, *args):
    return run(["git", *args], cwd)


def make_repo():
    tmp = Path(tempfile.mkdtemp(prefix="clog-test-"))
    git(tmp, "init", "-q")
    git(tmp, "config", "user.email", "a@b.c")
    git(tmp, "config", "user.name", "Tester")
    (tmp / ".clog.toml").write_text(
        '[clog]\n[sections]\nFeatures = ["feat", "feature"]\n"Bug Fixes" = ["fix"]\n',
        encoding="utf-8",
    )
    (tmp / "f").write_text("0\n", encoding="utf-8")
    git(tmp, "add", "f", ".clog.toml")
    git(tmp, "commit", "-q", "-m", "init")
    git(tmp, "tag", "1.0.0")
    return tmp


def normalize(output):
    output = re.sub(r"\(took \d+ ms\)", "(took N ms)", output)
    output = re.sub(r"\[[0-9a-f]{8}\]\([^)]+\)", "[SHA](LINK)", output)
    return output


def test_markdown_sections_from_configured_git_range():
    repo = make_repo()
    try:
        (repo / "f").write_text("0\n1\n", encoding="utf-8")
        git(repo, "add", "f")
        git(repo, "commit", "-q", "-m", "feat(core): add alpha")
        (repo / "f").write_text("0\n1\n2\n", encoding="utf-8")
        git(repo, "add", "f")
        git(repo, "commit", "-q", "-m", "fix: repair beta")

        result = run(
            [str(BIN), "--from", "1.0.0", "--setversion", "1.1.0", "--repository", "https://github.com/o/r"],
            repo,
        )

        out = normalize(result.stdout)
        assert '<a name="1.1.0"></a>' in out
        assert "## 1.1.0  (" in out
        assert "#### Features" in out
        assert "* **core:**  add alpha ([SHA](LINK))" in out
        assert "#### Bug Fixes" in out
        assert "*   repair beta ([SHA](LINK))" in out
        assert "changelog written. (took N ms)" in out
    finally:
        shutil.rmtree(repo)


def test_json_format_and_outfile_are_observable_cli_behavior():
    repo = make_repo()
    try:
        (repo / "f").write_text("0\n1\n", encoding="utf-8")
        git(repo, "add", "f")
        git(repo, "commit", "-q", "-m", "feat: add alpha")

        result = run([str(BIN), "--from", "1.0.0", "--setversion", "1.1.0", "--format", "json"], repo)
        assert '"header":{"version":Some("1.1.0")' in result.stdout
        assert '"sections":[{"title":"Features"' in result.stdout
        assert '"subject":" add alpha"' in result.stdout

        out = repo / "CHANGELOG.md"
        result = run([str(BIN), "--from", "1.0.0", "--setversion", "1.1.0", "--outfile", str(out)], repo)
        assert "changelog written. (took " in result.stdout
        written = normalize(out.read_text(encoding="utf-8"))
        assert "#### Features" in written
        assert "changelog written." not in written
    finally:
        shutil.rmtree(repo)


def test_help_version_and_missing_config_error():
    repo = Path(tempfile.mkdtemp(prefix="clog-test-"))
    try:
        help_result = run([str(BIN), "--help"], repo)
        assert "a conventional changelog for the rest of us" in help_result.stdout
        assert "-r, --repository <URL>" in help_result.stdout
        version_result = run([str(BIN), "--version"], repo)
        assert version_result.stdout == "clog 0.10.0\n"

        missing = run([str(BIN)], repo, check=False)
        assert missing.returncode == 1
        assert "fatal I/O error with output file" in missing.stderr
    finally:
        shutil.rmtree(repo)


if __name__ == "__main__":
    test_markdown_sections_from_configured_git_range()
    test_json_format_and_outfile_are_observable_cli_behavior()
    test_help_version_and_missing_config_error()
