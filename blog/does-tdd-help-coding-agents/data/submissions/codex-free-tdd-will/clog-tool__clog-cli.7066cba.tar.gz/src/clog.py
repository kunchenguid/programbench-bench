#!/usr/bin/env python3
import argparse
import datetime as _dt
import os
import re
import subprocess
import sys
import time


def die(message):
    print(f"\033[1;31merror:\033[0m {message}", file=sys.stderr)
    return 1


def parse_args(argv):
    parser = argparse.ArgumentParser(add_help=False, prog=os.path.basename(argv[0]), usage="executable [OPTIONS]")
    parser.add_argument("-r", "--repository")
    parser.add_argument("-f", "--from", dest="from_ref")
    parser.add_argument("-T", "--format", dest="fmt", default="markdown", choices=["markdown", "json"])
    parser.add_argument("-M", "--major", action="store_true")
    parser.add_argument("-g", "--git-dir")
    parser.add_argument("-w", "--work-tree")
    parser.add_argument("-m", "--minor", action="store_true")
    parser.add_argument("-p", "--patch", action="store_true")
    parser.add_argument("-s", "--subtitle")
    parser.add_argument("-t", "--to", dest="to_ref", default="HEAD")
    parser.add_argument("-o", "--outfile")
    parser.add_argument("-c", "--config", default=".clog.toml")
    parser.add_argument("-i", "--infile")
    parser.add_argument("--setversion")
    parser.add_argument("-F", "--from-latest-tag", action="store_true")
    parser.add_argument("-l", "--link-style", default="github", choices=["github", "gitlab", "stash", "cgit"])
    parser.add_argument("-C", "--changelog")
    parser.add_argument("-h", "--help", action="store_true")
    parser.add_argument("-V", "--version", action="store_true")
    return parser.parse_args(argv[1:])


def print_help():
    print("""a conventional changelog for the rest of us

Usage: executable [OPTIONS]

Options:
  -r, --repository <URL>  Repository used for generating commit and issue links (without the .git,
                          e.g. https://github.com/thoughtram/clog)
  -f, --from <COMMIT>     e.g. 12a8546
  -T, --format <STR>      The output format, defaults to markdown [default: markdown] [possible
                          values: markdown, json]
  -M, --major             Increment major version by one (Sets minor and patch to 0)
  -g, --git-dir <PATH>    Local .git directory (defaults to "$(pwd)/.git")
  -w, --work-tree <PATH>  Local working tree of the git project (defaults to "$(pwd)")
  -m, --minor             Increment minor version by one (Sets patch to 0)
  -p, --patch             Increment patch version by one
  -s, --subtitle <STR>    
  -t, --to <COMMIT>       e.g. 8057684 [default: HEAD]
  -o, --outfile <PATH>    Where to write the changelog (Defaults to stdout when omitted)
  -c, --config <COMMIT>   The Clog Configuration TOML file to use [default: .clog.toml]
  -i, --infile <PATH>     A changelog to append to, but *NOT* write to (Useful in conjunction with
                          --outfile)
      --setversion <VER>  e.g. 1.0.1
  -F, --from-latest-tag   use latest tag as start (instead of --from)
  -l, --link-style <STR>  The style of repository link to generate [default: github] [possible
                          values: github, gitlab, stash, cgit]
  -C, --changelog <PATH>  A previous changelog to prepend new changes to (this is like using the
                          same file for both --infile and --outfile and should not be used in
                          conjunction with either)
  -h, --help              Print help
  -V, --version           Print version
""")


def parse_toml_subset(path):
    if not os.path.exists(path):
        raise FileNotFoundError(path)
    section = None
    cfg = {"clog": {}, "sections": []}
    for raw in open(path, encoding="utf-8"):
        line = raw.strip()
        if not line or line.startswith("#"):
            continue
        if line.startswith("[") and line.endswith("]"):
            section = line[1:-1]
            continue
        if "=" not in line:
            continue
        key, value = [p.strip() for p in line.split("=", 1)]
        key = key.strip('"')
        if section == "sections":
            m = re.fullmatch(r"\[(.*)\]", value)
            if not m:
                raise ValueError("bad sections")
            vals = []
            inner = m.group(1).strip()
            if inner:
                vals = [x.strip().strip('"') for x in inner.split(",")]
            cfg["sections"].append((key, vals))
        elif section == "clog":
            if value in ("true", "false"):
                cfg["clog"][key] = value == "true"
            else:
                cfg["clog"][key] = value.strip('"')
    return cfg


def git(args, opts, check=True):
    cmd = ["git"]
    if opts.git_dir:
        cmd += [f"--git-dir={opts.git_dir}"]
    if opts.work_tree:
        cmd += [f"--work-tree={opts.work_tree}"]
    cmd += args
    result = subprocess.run(cmd, text=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    if check and result.returncode != 0:
        raise RuntimeError(result.stderr.strip())
    return result.stdout


def latest_tag(opts):
    out = git(["describe", "--tags", "--abbrev=0"], opts, check=False)
    return out.strip() or None


def commit_link(repo, sha, style):
    if not repo:
        return sha[:8]
    repo = repo[:-4] if repo.endswith(".git") else repo
    if style in ("github", "gitlab"):
        return f"{repo}/commit/{sha}"
    if style == "stash":
        return f"{repo}/commits/{sha}"
    if style == "cgit":
        return f"{repo}/commit/?id={sha}"
    return f"{repo}/commit/{sha}"


def issue_link(repo, issue, style):
    if not repo:
        return f"#{issue}"
    repo = repo[:-4] if repo.endswith(".git") else repo
    if style in ("github", "gitlab"):
        return f"{repo}/issues/{issue}"
    return f"{repo}/issues/{issue}"


def parse_commit(raw):
    sha, subject, body = raw.split("\x1f", 2)
    m = re.match(r"^([A-Za-z]+)(?:\(([^)]*)\))?:((?:.|\n)*)$", subject)
    if not m:
        return None
    return {"sha": sha, "type": m.group(1), "component": m.group(2), "subject": m.group(3), "body": body}


def collect_commits(opts):
    start = opts.from_ref
    if opts.from_latest_tag:
        start = latest_tag(opts)
    rev = opts.to_ref
    if start:
        rev = f"{start}..{opts.to_ref}"
    fmt = "%H%x1f%s%x1f%b%x1e"
    out = git(["log", "--reverse", f"--pretty=format:{fmt}", rev], opts)
    commits = []
    for chunk in out.split("\x1e"):
        chunk = chunk.strip("\n")
        if not chunk:
            continue
        parsed = parse_commit(chunk)
        if parsed:
            commits.append(parsed)
    return commits


def group_commits(commits, sections):
    grouped = []
    for title, aliases in sections:
        wanted = set(aliases)
        picked = [c for c in commits if c["type"] in wanted]
        if picked:
            grouped.append((title, picked))
    return grouped


def render_markdown(grouped, version, subtitle, date, repo, style):
    out = [f'<a name="{version or ""}"></a>', f'## {version or ""} {subtitle or ""} ({date})', ""]
    for title, commits in grouped:
        out += ["", f"#### {title}", ""]
        for c in commits:
            sha8 = c["sha"][:8]
            link = commit_link(repo, c["sha"], style)
            prefix = f"* **{c['component']}:** " if c["component"] is not None else "*  "
            line = f"{prefix}{c['subject']} ([{sha8}]({link}))"
            closes = re.findall(r"(?i)(?:close[sd]?|fix(?:e[sd])?)\s+#(\d+)", c["body"])
            if closes:
                parts = [f"closes [#{n}]({issue_link(repo, n, style)})" for n in closes[:1]]
                line += ", " + ", ".join(parts)
            out.append(line)
    return "\n".join(out) + "\n"


def semver_bump(version, kind):
    v = version[1:] if version.startswith("v") else version
    m = re.fullmatch(r"(\d+)\.(\d+)\.(\d+)", v)
    if not m:
        raise ValueError
    major, minor, patch = map(int, m.groups())
    if kind == "major":
        major, minor, patch = major + 1, 0, 0
    elif kind == "minor":
        minor, patch = minor + 1, 0
    else:
        patch += 1
    return ("v" if version.startswith("v") else "") + f"{major}.{minor}.{patch}"


def main(argv):
    start_time = time.time()
    opts = parse_args(argv)
    if opts.help:
        print_help()
        return 0
    if opts.version:
        print("clog 0.10.0")
        return 0
    try:
        cfg = parse_toml_subset(opts.config)
    except FileNotFoundError:
        return die("fatal I/O error with output file")
    except Exception:
        return die("Failed to parse TOML configuration file")

    if not opts.repository:
        opts.repository = cfg["clog"].get("repository")
    if cfg["clog"].get("from-latest-tag") and not opts.from_ref:
        opts.from_latest_tag = True
    if not opts.from_ref and cfg["clog"].get("from"):
        opts.from_ref = cfg["clog"].get("from")

    version = opts.setversion
    try:
        if opts.major or opts.minor or opts.patch:
            base = opts.setversion or (opts.from_ref or latest_tag(opts) or "")
            version = semver_bump(base, "major" if opts.major else "minor" if opts.minor else "patch")
    except ValueError:
        return die("Failed to parse version into valid SemVer. Ensure the version is in the X.Y.Z format.")

    commits = collect_commits(opts)
    grouped = group_commits(commits, cfg["sections"])
    date = _dt.date.today().isoformat()
    content = render_markdown(grouped, version, opts.subtitle, date, opts.repository, opts.link_style)
    if opts.fmt == "json":
        content = render_json(grouped, version, opts.subtitle, date, opts.repository, opts.link_style)

    existing = ""
    outfile = opts.outfile
    if opts.changelog:
        outfile = opts.changelog
        if os.path.exists(opts.changelog):
            existing = open(opts.changelog, encoding="utf-8").read()
    elif opts.infile and os.path.exists(opts.infile):
        existing = open(opts.infile, encoding="utf-8").read()
    content = content + existing
    elapsed = int((time.time() - start_time) * 1000)
    notice = f"changelog written. (took {elapsed} ms)\n"
    if outfile:
        with open(outfile, "w", encoding="utf-8") as f:
            f.write(content)
        sys.stdout.write(notice)
    else:
        sys.stdout.write(content + notice)
    return 0


def json_val(value):
    if value is None:
        return "null"
    return '"' + str(value).replace("\\", "\\\\").replace('"', '\\"') + '"'


def render_json(grouped, version, subtitle, date, repo, style):
    ver = f'Some("{version}")' if version is not None else "None"
    sub = json_val(subtitle)
    sections = "null"
    if grouped:
        sec_parts = []
        for title, commits in grouped:
            commit_parts = []
            for c in commits:
                comp = json_val(c["component"]) if c["component"] is not None else "null"
                link = commit_link(repo, c["sha"], style)
                commit_parts.append(
                    '{"component":'
                    + comp
                    + ',"subject":'
                    + json_val(c["subject"])
                    + ',"commit_link":'
                    + json_val(link)
                    + ',"closes":null,"breaks":null}'
                )
            sec_parts.append('{"title":' + json_val(title) + ',"commits":[' + ",".join(commit_parts) + "]}")
        sections = "[" + ",".join(sec_parts) + "]"
    return (
        '{"header":{"version":'
        + ver
        + ',"patch_version":false,"subtitle":'
        + sub
        + ',"date":'
        + json_val(date)
        + '},"sections":'
        + sections
        + "}"
    )


if __name__ == "__main__":
    sys.exit(main(sys.argv))
