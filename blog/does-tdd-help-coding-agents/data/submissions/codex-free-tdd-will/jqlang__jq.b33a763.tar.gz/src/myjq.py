#!/usr/bin/env python3
import sys
import math

VERSION = "jq-build-2b77eb1"

class JsonError(Exception):
    pass

class JqError(Exception):
    pass

class Parser:
    def __init__(self, text):
        self.text = text
        self.i = 0
    def parse(self):
        self.ws(); v = self.value(); self.ws()
        if self.i != len(self.text): raise JsonError("extra data")
        return v
    def ws(self):
        while self.i < len(self.text) and self.text[self.i] in " \t\r\n": self.i += 1
    def value(self):
        self.ws()
        if self.i >= len(self.text): raise JsonError("unexpected end")
        c = self.text[self.i]
        if c == '{': return self.object()
        if c == '[': return self.array()
        if c == '"': return self.string()
        if c == '-' or c.isdigit(): return self.number()
        for lit, val in (("true", True), ("false", False), ("null", None)):
            if self.text.startswith(lit, self.i):
                self.i += len(lit); return val
        raise JsonError("invalid value")
    def object(self):
        out = {}; self.i += 1; self.ws()
        if self.i < len(self.text) and self.text[self.i] == '}': self.i += 1; return out
        while True:
            self.ws()
            if self.i >= len(self.text) or self.text[self.i] != '"': raise JsonError("expected object key")
            k = self.string(); self.ws()
            if self.i >= len(self.text) or self.text[self.i] != ':': raise JsonError("expected colon")
            self.i += 1; out[k] = self.value(); self.ws()
            if self.i < len(self.text) and self.text[self.i] == '}': self.i += 1; return out
            if self.i >= len(self.text) or self.text[self.i] != ',': raise JsonError("expected comma")
            self.i += 1
    def array(self):
        out = []; self.i += 1; self.ws()
        if self.i < len(self.text) and self.text[self.i] == ']': self.i += 1; return out
        while True:
            out.append(self.value()); self.ws()
            if self.i < len(self.text) and self.text[self.i] == ']': self.i += 1; return out
            if self.i >= len(self.text) or self.text[self.i] != ',': raise JsonError("expected comma")
            self.i += 1
    def string(self):
        self.i += 1; out = []
        while self.i < len(self.text):
            c = self.text[self.i]; self.i += 1
            if c == '"': return ''.join(out)
            if c == '\\':
                if self.i >= len(self.text): raise JsonError("bad escape")
                e = self.text[self.i]; self.i += 1
                table = {'"':'"', '\\':'\\', '/':'/', 'b':'\b', 'f':'\f', 'n':'\n', 'r':'\r', 't':'\t'}
                if e in table: out.append(table[e])
                elif e == 'u':
                    if self.i + 4 > len(self.text): raise JsonError("bad unicode escape")
                    code = int(self.text[self.i:self.i+4], 16); self.i += 4
                    if 0xD800 <= code <= 0xDBFF and self.text.startswith('\\u', self.i):
                        self.i += 2; lo = int(self.text[self.i:self.i+4], 16); self.i += 4
                        code = 0x10000 + ((code - 0xD800) << 10) + (lo - 0xDC00)
                    out.append(chr(code))
                else: raise JsonError("bad escape")
            else: out.append(c)
        raise JsonError("unterminated string")
    def number(self):
        start = self.i
        if self.text[self.i] == '-': self.i += 1
        if self.i < len(self.text) and self.text[self.i] == '0': self.i += 1
        else:
            if self.i >= len(self.text) or not self.text[self.i].isdigit(): raise JsonError("bad number")
            while self.i < len(self.text) and self.text[self.i].isdigit(): self.i += 1
        is_float = False
        if self.i < len(self.text) and self.text[self.i] == '.':
            is_float = True; self.i += 1
            if self.i >= len(self.text) or not self.text[self.i].isdigit(): raise JsonError("bad number")
            while self.i < len(self.text) and self.text[self.i].isdigit(): self.i += 1
        if self.i < len(self.text) and self.text[self.i] in 'eE':
            is_float = True; self.i += 1
            if self.i < len(self.text) and self.text[self.i] in '+-': self.i += 1
            if self.i >= len(self.text) or not self.text[self.i].isdigit(): raise JsonError("bad number")
            while self.i < len(self.text) and self.text[self.i].isdigit(): self.i += 1
        s = self.text[start:self.i]
        return float(s) if is_float else int(s)

def parse_json_stream(text):
    vals = []; p = Parser(text)
    while True:
        p.ws()
        if p.i >= len(text): return vals
        vals.append(p.value())

def qstr(s, ascii_only=False):
    out = ['"']
    for ch in s:
        o = ord(ch)
        if ch == '"': out.append('\\"')
        elif ch == '\\': out.append('\\\\')
        elif ch == '\b': out.append('\\b')
        elif ch == '\f': out.append('\\f')
        elif ch == '\n': out.append('\\n')
        elif ch == '\r': out.append('\\r')
        elif ch == '\t': out.append('\\t')
        elif o < 32 or (ascii_only and o > 127):
            if o <= 0xFFFF: out.append('\\u%04x' % o)
            else:
                o -= 0x10000; out.append('\\u%04x\\u%04x' % (0xD800 + (o >> 10), 0xDC00 + (o & 1023)))
        else: out.append(ch)
    out.append('"'); return ''.join(out)

def numstr(v):
    if isinstance(v, bool): return 'true' if v else 'false'
    if isinstance(v, int): return str(v)
    if isinstance(v, float):
        if math.isnan(v): return 'null'
        if v.is_integer(): return str(int(v))
        return (('% .15g' % v).strip()).replace('e+', 'e')
    return str(v)

def dumps(v, indent=2, level=0, compact=False, sort_keys=False, ascii_only=False, tab=False):
    if v is None: return 'null'
    if v is True: return 'true'
    if v is False: return 'false'
    if isinstance(v, (int, float)): return numstr(v)
    if isinstance(v, str): return qstr(v, ascii_only)
    step = '\t' if tab else ' ' * indent
    if isinstance(v, list):
        if not v: return '[]'
        if compact: return '[' + ','.join(dumps(x, indent, level+1, True, sort_keys, ascii_only, tab) for x in v) + ']'
        pad = step * (level + 1); end = step * level
        return '[\n' + ',\n'.join(pad + dumps(x, indent, level+1, False, sort_keys, ascii_only, tab) for x in v) + '\n' + end + ']'
    if isinstance(v, dict):
        keys = sorted(v) if sort_keys else list(v.keys())
        if not keys: return '{}'
        if compact: return '{' + ','.join(qstr(str(k), ascii_only) + ':' + dumps(v[k], indent, level+1, True, sort_keys, ascii_only, tab) for k in keys) + '}'
        pad = step * (level + 1); end = step * level
        return '{\n' + ',\n'.join(pad + qstr(str(k), ascii_only) + ': ' + dumps(v[k], indent, level+1, False, sort_keys, ascii_only, tab) for k in keys) + '\n' + end + '}'
    return qstr(str(v), ascii_only)

KEYWORDS = {'as','if','then','else','elif','end','and','or','not','true','false','null'}
class Tok:
    def __init__(self, text): self.toks = self.lex(text); self.i = 0
    def lex(self, s):
        out=[]; i=0
        two = {'==','!=','<=','>=','//','|=','+=','-=','*=','/=','%=','..'}
        while i < len(s):
            c=s[i]
            if c in ' \t\r\n': i+=1; continue
            if s.startswith('#', i):
                while i < len(s) and s[i] != '\n': i+=1
                continue
            if i+1 < len(s) and s[i:i+2] in two: out.append(s[i:i+2]); i+=2; continue
            if c in '.|,[]{}():+-*/%<>?;': out.append(c); i+=1; continue
            if c == '"':
                p=Parser(s[i:]); val=p.string(); out.append(('str', val)); i += p.i; continue
            if c == '$':
                j=i+1
                while j < len(s) and (s[j].isalnum() or s[j]=='_'): j+=1
                out.append(('var', s[i+1:j])); i=j; continue
            if c.isdigit() or (c=='-' and i+1<len(s) and s[i+1].isdigit()):
                p=Parser(s[i:]); val=p.number(); out.append(('num', val)); i += p.i; continue
            if c.isalpha() or c == '_':
                j=i+1
                while j < len(s) and (s[j].isalnum() or s[j]=='_'): j+=1
                out.append(s[i:j]); i=j; continue
            raise SyntaxError(c)
        out.append(('eof', None)); return out
    def peek(self): return self.toks[self.i]
    def pop(self): t=self.toks[self.i]; self.i+=1; return t
    def eat(self, x):
        if self.peek()==x: self.i+=1; return True
        return False
    def expect(self, x):
        if not self.eat(x): raise SyntaxError('expected '+str(x)+' got '+str(self.peek()))

class FilterParser:
    def __init__(self, text): self.t = Tok(text)
    def parse(self):
        e = self.expr()
        if self.t.peek()[0] != 'eof': raise SyntaxError('trailing')
        return e
    def expr(self): return self.comma()
    def comma(self):
        e = self.pipe()
        while self.t.eat(','): e = ('comma', e, self.pipe())
        return e
    def pipe(self):
        e = self.alt()
        if self.t.eat('|='):
            return ('update', e, self.pipe())
        if self.t.peek() == 'as':
            self.t.pop(); v = self.t.pop()
            if not (isinstance(v, tuple) and v[0]=='var'): raise SyntaxError('binding')
            self.t.expect('|'); return ('as', e, v[1], self.pipe())
        while self.t.eat('|'): e = ('pipe', e, self.alt())
        return e
    def alt(self):
        e = self.logic_or()
        while self.t.eat('//'): e = ('alt', e, self.logic_or())
        return e
    def logic_or(self):
        e = self.logic_and()
        while self.t.peek() == 'or': self.t.pop(); e = ('bin','or',e,self.logic_and())
        return e
    def logic_and(self):
        e = self.compare()
        while self.t.peek() == 'and': self.t.pop(); e = ('bin','and',e,self.compare())
        return e
    def compare(self):
        e = self.add()
        while self.t.peek() in ('==','!=','<','>','<=','>='):
            op = self.t.pop(); e = ('bin', op, e, self.add())
        return e
    def add(self):
        e = self.mul()
        while self.t.peek() in ('+','-'):
            op = self.t.pop(); e = ('bin', op, e, self.mul())
        return e
    def mul(self):
        e = self.unary()
        while self.t.peek() in ('*','/','%'):
            op = self.t.pop(); e = ('bin', op, e, self.unary())
        return e
    def unary(self):
        if self.t.eat('-'): return ('neg', self.unary())
        return self.postfix(self.primary())
    def primary(self):
        tok = self.t.peek()
        if tok == '.':
            self.t.pop()
            base = ('id',)
            if isinstance(self.t.peek(), str) and self.t.peek().isidentifier() and self.t.peek() not in KEYWORDS:
                name = self.t.pop()
                return ('field', base, name, self.t.eat('?'))
            if isinstance(self.t.peek(), tuple) and self.t.peek()[0] == 'str':
                name = self.t.pop()[1]
                return ('field', base, name, self.t.eat('?'))
            return base
        if tok == '..':
            self.t.pop()
            return ('recurse',)
        if tok == 'true': self.t.pop(); return ('lit', True)
        if tok == 'false': self.t.pop(); return ('lit', False)
        if tok == 'null': self.t.pop(); return ('lit', None)
        if isinstance(tok, tuple) and tok[0] == 'num': self.t.pop(); return ('lit', tok[1])
        if isinstance(tok, tuple) and tok[0] == 'str': self.t.pop(); return ('lit', tok[1])
        if isinstance(tok, tuple) and tok[0] == 'var': self.t.pop(); return ('var', tok[1])
        if tok == '(':
            self.t.pop(); e = self.expr(); self.t.expect(')'); return e
        if tok == '[':
            self.t.pop()
            if self.t.eat(']'): return ('arrlit', None)
            e = self.expr(); self.t.expect(']'); return ('arr', e)
        if tok == '{': return self.object_lit()
        if tok == 'if': return self.if_expr()
        if isinstance(tok, str) and (tok.isidentifier() or tok in KEYWORDS):
            name = self.t.pop(); args=[]
            if self.t.eat('('):
                if not self.t.eat(')'):
                    while True:
                        args.append(self.expr())
                        if self.t.eat(')'): break
                        if not (self.t.eat(';') or self.t.eat(',')):
                            self.t.expect(',')
            return ('call', name, args)
        raise SyntaxError(str(tok))
    def object_lit(self):
        self.t.expect('{'); pairs=[]
        if self.t.eat('}'): return ('obj', pairs)
        while True:
            keytok = self.t.peek()
            if isinstance(keytok, tuple) and keytok[0] == 'str': self.t.pop(); key = ('lit', keytok[1])
            elif isinstance(keytok, str) and keytok.isidentifier(): self.t.pop(); key = ('lit', keytok); 
            elif keytok == '(':
                self.t.pop(); key = self.expr(); self.t.expect(')')
            else: key = None
            if key is not None and self.t.eat(':'):
                val = self.expr(); pairs.append((key,val))
            elif key is not None and key[0] == 'lit':
                pairs.append((key, ('field', ('id',), key[1], False)))
            else:
                val = self.expr(); pairs.append((None,val))
            if self.t.eat('}'): break
            self.t.expect(',')
        return ('obj', pairs)
    def if_expr(self):
        self.t.expect('if'); cond=self.expr(); self.t.expect('then'); a=self.expr(); self.t.expect('else'); b=self.expr(); self.t.expect('end')
        return ('if', cond, a, b)
    def postfix(self, e):
        while True:
            if self.t.peek() == '.':
                self.t.pop()
                tok = self.t.peek()
                if isinstance(tok, str) and tok.isidentifier():
                    self.t.pop(); opt=self.t.eat('?'); e=('field', e, tok, opt)
                elif isinstance(tok, tuple) and tok[0] == 'str':
                    self.t.pop(); opt=self.t.eat('?'); e=('field', e, tok[1], opt)
                elif self.t.peek() == '[':
                    continue
                else:
                    e=('id',)
            elif self.t.eat('['):
                if self.t.eat(']'): e=('iter', e, self.t.eat('?'))
                else:
                    if self.t.peek() == ':': start=None
                    else: start=self.expr()
                    if self.t.eat(':'):
                        end = None if self.t.peek() == ']' else self.expr(); self.t.expect(']'); e=('slice', e, start, end)
                    else:
                        self.t.expect(']'); e=('index', e, start, self.t.eat('?'))
            else: break
        return e

def truthy(v): return not (v is False or v is None)
def first(vals): return vals[0] if vals else None

def jq_type(v):
    if v is None: return 'null'
    if isinstance(v, bool): return 'boolean'
    if isinstance(v, (int,float)): return 'number'
    if isinstance(v, str): return 'string'
    if isinstance(v, list): return 'array'
    if isinstance(v, dict): return 'object'
    return 'unknown'

def cmp_key(v):
    order = {'null':0,'boolean':1,'number':2,'string':3,'array':4,'object':5}
    return (order[jq_type(v)], v if not isinstance(v, dict) else sorted(v.items()))

def get_field(base, key, opt=False):
    if isinstance(base, dict): return [base.get(key)]
    if base is None: return [None]
    if opt: return []
    raise JqError(f'Cannot index {jq_type(base)} with string "{key}"')

def get_index(base, idx, opt=False):
    if idx is None: return [None]
    if isinstance(base, list):
        if not isinstance(idx, int): raise JqError(f'Cannot index array with {jq_type(idx)}')
        if idx < 0: idx += len(base)
        return [base[idx] if 0 <= idx < len(base) else None]
    if isinstance(base, dict):
        if isinstance(idx, str): return [base.get(idx)]
        if opt: return []
        raise JqError(f'Cannot index object with {jq_type(idx)}')
    if isinstance(base, str):
        if isinstance(idx, int):
            if idx < 0: idx += len(base)
            return [base[idx] if 0 <= idx < len(base) else None]
    if opt: return []
    raise JqError(f'Cannot index {jq_type(base)} with {jq_type(idx)}')

def eval_ast(ast, inp, env):
    tag = ast[0]
    if tag == 'id': return [inp]
    if tag == 'lit': return [ast[1]]
    if tag == 'var': return [env.get(ast[1])]
    if tag == 'comma': return eval_ast(ast[1], inp, env) + eval_ast(ast[2], inp, env)
    if tag == 'pipe':
        out=[]
        for v in eval_ast(ast[1], inp, env): out += eval_ast(ast[2], v, env)
        return out
    if tag == 'update':
        target, rhs = ast[1], ast[2]
        if target[0] == 'field':
            base = inp.copy() if isinstance(inp, dict) else inp
            if not isinstance(base, dict):
                raise JqError('Cannot index '+jq_type(inp)+' with string')
            key = target[2]
            old = base.get(key)
            vals = eval_ast(rhs, old, env)
            base[key] = vals[-1] if vals else None
            return [base]
        return [inp]
    if tag == 'as':
        out=[]
        for v in eval_ast(ast[1], inp, env):
            e=dict(env); e[ast[2]]=v; out += eval_ast(ast[3], inp, e)
        return out
    if tag == 'field':
        out=[]
        for b in eval_ast(ast[1], inp, env): out += get_field(b, ast[2], ast[3])
        return out
    if tag == 'index':
        out=[]
        for b in eval_ast(ast[1], inp, env):
            for ix in eval_ast(ast[2], inp, env): out += get_index(b, ix, ast[3])
        return out
    if tag == 'slice':
        b = first(eval_ast(ast[1], inp, env)); s = first(eval_ast(ast[2], inp, env)) if ast[2] else None; e = first(eval_ast(ast[3], inp, env)) if ast[3] else None
        if isinstance(b, (list,str)): return [b[s:e]]
        return [None]
    if tag == 'iter':
        out=[]
        for b in eval_ast(ast[1], inp, env):
            if isinstance(b, list): out += b
            elif isinstance(b, dict): out += list(b.values())
            elif b is None and ast[2]: pass
            else: raise JqError(f'Cannot iterate over {jq_type(b)}')
        return out
    if tag == 'arrlit': return [[]]
    if tag == 'arr': return [eval_ast(ast[1], inp, env)]
    if tag == 'obj':
        obj={}
        for kexpr, vexpr in ast[1]:
            vals = eval_ast(vexpr, inp, env)
            if kexpr is None:
                for v in vals:
                    if isinstance(v, dict): obj.update(v)
            else:
                key = first(eval_ast(kexpr, inp, env)); obj[str(key)] = vals[-1] if vals else None
        return [obj]
    if tag == 'if':
        return eval_ast(ast[2] if truthy(first(eval_ast(ast[1], inp, env))) else ast[3], inp, env)
    if tag == 'alt':
        vals = [v for v in eval_ast(ast[1], inp, env) if v is not None and v is not False]
        return vals if vals else eval_ast(ast[2], inp, env)
    if tag == 'neg': return [-first(eval_ast(ast[1], inp, env))]
    if tag == 'bin':
        op=ast[1]; a=first(eval_ast(ast[2], inp, env)); b=first(eval_ast(ast[3], inp, env))
        if op == 'and': return [truthy(a) and truthy(b)]
        if op == 'or': return [truthy(a) or truthy(b)]
        if op in ('==','!=','<','>','<=','>='):
            r = (a == b) if op=='==' else (a != b) if op=='!=' else (a < b) if op=='<' else (a > b) if op=='>' else (a <= b) if op=='<=' else (a >= b)
            return [r]
        if op == '+':
            if a is None: return [b]
            if b is None: return [a]
            if isinstance(a, dict) and isinstance(b, dict): c=dict(a); c.update(b); return [c]
            return [a + b]
        if op == '-':
            if isinstance(a, list) and isinstance(b, list): return [[x for x in a if x not in b]]
            return [a - b]
        if op == '*':
            if isinstance(a, dict) and isinstance(b, dict): c=dict(a); c.update(b); return [c]
            return [a * b]
        if op == '/': return [a / b if not (isinstance(a,str) and isinstance(b,str)) else a.split(b)]
        if op == '%': return [a % b]
    if tag == 'call': return call_func(ast[1], ast[2], inp, env)
    if tag == 'recurse':
        out = [inp]
        if isinstance(inp, list):
            for x in inp:
                out += eval_ast(ast, x, env)
        elif isinstance(inp, dict):
            for x in inp.values():
                out += eval_ast(ast, x, env)
        return out
    raise JqError('bad ast')

def eval_arg(expr, inp, env): return first(eval_ast(expr, inp, env)) if expr is not None else None

def call_func(name, args, inp, env):
    if name == 'empty': return []
    if name == 'length':
        v=inp
        if v is None: return [0]
        if isinstance(v, (list,dict,str)): return [len(v)]
        if isinstance(v, (int,float)): return [abs(v)]
    if name == 'keys' or name == 'keys_unsorted':
        if isinstance(inp, dict): return [list(inp.keys()) if name.endswith('unsorted') else sorted(inp.keys())]
        if isinstance(inp, list): return [list(range(len(inp)))]
    if name == 'type': return [jq_type(inp)]
    if name == 'values': return [] if inp is None else [inp]
    if name == 'scalars': return [inp] if not isinstance(inp, (list, dict)) else []
    if name == 'arrays': return [inp] if isinstance(inp, list) else []
    if name == 'objects': return [inp] if isinstance(inp, dict) else []
    if name == 'numbers': return [inp] if isinstance(inp, (int, float)) and not isinstance(inp, bool) else []
    if name == 'strings': return [inp] if isinstance(inp, str) else []
    if name == 'booleans': return [inp] if isinstance(inp, bool) else []
    if name == 'nulls': return [inp] if inp is None else []
    if name == 'has':
        k=eval_arg(args[0], inp, env)
        return [k in inp] if isinstance(inp, dict) else [isinstance(inp, list) and isinstance(k,int) and 0 <= k < len(inp)]
    if name == 'select': return [inp] if truthy(eval_arg(args[0], inp, env)) else []
    if name == 'map':
        if not isinstance(inp, list): raise JqError('Cannot iterate over '+jq_type(inp))
        return [[y for x in inp for y in eval_ast(args[0], x, env)]]
    if name == 'add':
        if not inp: return [None]
        acc=inp[0]
        for x in inp[1:]: acc=first(eval_ast(('bin','+',('lit',acc),('lit',x)), inp, env))
        return [acc]
    if name == 'sort': return [sorted(inp, key=cmp_key)]
    if name == 'unique': return [unique_list(sorted(inp, key=cmp_key))]
    if name == 'sort_by':
        return [sorted(inp, key=lambda x: cmp_key(first(eval_ast(args[0], x, env))))]
    if name == 'min_by': return [min(inp, key=lambda x: cmp_key(first(eval_ast(args[0], x, env))))]
    if name == 'max_by': return [max(inp, key=lambda x: cmp_key(first(eval_ast(args[0], x, env))))]
    if name == 'group_by':
        arr = sorted(inp, key=lambda x: cmp_key(first(eval_ast(args[0], x, env))))
        groups = []
        for x in arr:
            k = first(eval_ast(args[0], x, env))
            if not groups or first(eval_ast(args[0], groups[-1][0], env)) != k:
                groups.append([x])
            else:
                groups[-1].append(x)
        return [groups]
    if name == 'reverse': return [list(reversed(inp)) if isinstance(inp, list) else inp[::-1]]
    if name == 'min': return [min(inp, key=cmp_key)]
    if name == 'max': return [max(inp, key=cmp_key)]
    if name == 'contains':
        sub=eval_arg(args[0], inp, env)
        return [contains(inp, sub)]
    if name == 'index':
        sub=eval_arg(args[0], inp, env)
        if isinstance(inp, list): return [inp.index(sub) if sub in inp else None]
        if isinstance(inp, str):
            i=inp.find(sub); return [i if i>=0 else None]
    if name == 'join':
        sep=str(eval_arg(args[0], inp, env))
        return [sep.join('' if x is None else str(x).lower() if isinstance(x,bool) else str(x) for x in inp)]
    if name == 'split':
        sep=eval_arg(args[0], inp, env)
        if not isinstance(inp,str) or not isinstance(sep,str): raise JqError('split input and separator must be strings')
        return [inp.split(sep)]
    if name == 'startswith':
        return [isinstance(inp, str) and inp.startswith(eval_arg(args[0], inp, env))]
    if name == 'endswith':
        return [isinstance(inp, str) and inp.endswith(eval_arg(args[0], inp, env))]
    if name == 'ltrimstr':
        s=eval_arg(args[0], inp, env); return [inp[len(s):] if isinstance(inp,str) and inp.startswith(s) else inp]
    if name == 'rtrimstr':
        s=eval_arg(args[0], inp, env); return [inp[:-len(s)] if isinstance(inp,str) and s and inp.endswith(s) else inp]
    if name == 'ascii_downcase': return [inp.lower() if isinstance(inp, str) else inp]
    if name == 'ascii_upcase': return [inp.upper() if isinstance(inp, str) else inp]
    if name == 'tostring': return [dumps(inp, compact=True) if isinstance(inp,(list,dict)) or inp is None or isinstance(inp,bool) else str(inp)]
    if name == 'tonumber': return [float(inp) if (isinstance(inp,str) and ('.' in inp or 'e' in inp.lower())) else int(inp)]
    if name == 'floor': return [math.floor(inp)]
    if name == 'ceil': return [math.ceil(inp)]
    if name == 'round': return [math.floor(inp + 0.5)]
    if name == 'abs': return [abs(inp)]
    if name == 'to_entries':
        if isinstance(inp, dict): return [[{'key':k, 'value':v} for k,v in inp.items()]]
        if isinstance(inp, list): return [[{'key':i, 'value':v} for i,v in enumerate(inp)]]
    if name == 'from_entries':
        out={}
        for e in inp:
            k = e.get('key', e.get('Key', e.get('name', e.get('Name'))))
            v = e.get('value', e.get('Value'))
            out[str(k)] = v
        return [out]
    if name == 'with_entries':
        entries = call_func('to_entries', [], inp, env)[0]
        mapped = [y for x in entries for y in eval_ast(args[0], x, env)]
        return call_func('from_entries', [], mapped, env)
    if name == 'not': return [not truthy(eval_arg(args[0], inp, env) if args else inp)]
    if name == 'range':
        vals=[eval_arg(a, inp, env) for a in args]
        if len(vals)==1: start,end,step=0,vals[0],1
        elif len(vals)==2: start,end,step=vals[0],vals[1],1
        else: start,end,step=vals[0],vals[1],vals[2]
        return list(range(start,end,step))
    if name == 'del': return [inp]
    raise JqError(f'{name}/0 is not defined')

def contains(a,b):
    if isinstance(a, str) and isinstance(b, str): return b in a
    if isinstance(a, list): return all(any(contains(x,y) for x in a) for y in b) if isinstance(b,list) else b in a
    if isinstance(a, dict) and isinstance(b, dict): return all(k in a and contains(a[k],v) for k,v in b.items())
    return a == b

def unique_list(arr):
    out = []
    for x in arr:
        if x not in out:
            out.append(x)
    return out

HELP = """jq - commandline JSON processor [version build-2b77eb1]

Usage:\tjq [options] <jq filter> [file...]
\tjq [options] --args <jq filter> [strings...]
\tjq [options] --jsonargs <jq filter> [JSON_TEXTS...]

jq is a tool for processing JSON inputs, applying the given filter to
its JSON text inputs and producing the filter's results as JSON on
standard output.

The simplest filter is ., which copies jq's input to its output
unmodified except for formatting. For more advanced filters see
the jq(1) manpage ("man jq") and/or https://jqlang.org/.

Example:

\t$ echo '{"foo": 0}' | jq .
\t{
\t  "foo": 0
\t}

Command options:
  -n, --null-input          use `null` as the single input value;
  -R, --raw-input           read each line as string instead of JSON;
  -s, --slurp               read all inputs into an array and use it as
                            the single input value;
  -c, --compact-output      compact instead of pretty-printed output;
  -r, --raw-output          output strings without escapes and quotes;
      --raw-output0         implies -r and output NUL after each output;
  -j, --join-output         implies -r and output without newline after
                            each output;
  -a, --ascii-output        output strings by only ASCII characters
                            using escape sequences;
  -S, --sort-keys           sort keys of each object on output;
  -C, --color-output        colorize JSON output;
  -M, --monochrome-output   disable colored output;
      --tab                 use tabs for indentation;
      --indent n            use n spaces for indentation (max 7 spaces);
      --unbuffered          flush output stream after each output;
      --stream              parse the input value in streaming fashion;
      --stream-errors       implies --stream and report parse error as
                            an array;
      --seq                 parse input/output as application/json-seq;
  -f, --from-file           load the filter from a file;
  -L, --library-path dir    search modules from the directory;
      --arg name value      set $name to the string value;
      --argjson name value  set $name to the JSON value;
      --slurpfile name file set $name to an array of JSON values read
                            from the file;
      --rawfile name file   set $name to string contents of file;
      --args                consume remaining arguments as positional
                            string values;
      --jsonargs            consume remaining arguments as positional
                            JSON values;
  -e, --exit-status         set exit status code based on the output;
  -V, --version             show the version;
  --build-configuration     show jq's build configuration;
  -h, --help                show the help;
  --                        terminates argument processing;

Named arguments are also available as $ARGS.named[], while
positional arguments are available as $ARGS.positional[].
"""

def parse_args(argv):
    opts={'compact':False,'sort':False,'raw':False,'join':False,'raw0':False,'ascii':False,'null_input':False,'raw_input':False,'slurp':False,'exit_status':False,'indent':2,'tab':False,'files':[], 'vars':{}, 'pos':[]}
    i=0
    while i < len(argv):
        a=argv[i]
        if a == '--': i+=1; break
        if a in ('-c','--compact-output'): opts['compact']=True
        elif a in ('-S','--sort-keys'): opts['sort']=True
        elif a in ('-r','--raw-output'): opts['raw']=True
        elif a == '-j' or a == '--join-output': opts['raw']=True; opts['join']=True
        elif a == '--raw-output0': opts['raw']=True; opts['raw0']=True
        elif a in ('-a','--ascii-output'): opts['ascii']=True
        elif a in ('-n','--null-input'): opts['null_input']=True
        elif a in ('-e','--exit-status'): opts['exit_status']=True
        elif a in ('-R','--raw-input'): opts['raw_input']=True
        elif a in ('-s','--slurp'): opts['slurp']=True
        elif a == '--tab': opts['tab']=True
        elif a == '--indent': i+=1; opts['indent']=int(argv[i])
        elif a in ('-V','--version'): print(VERSION); raise SystemExit(0)
        elif a in ('-h','--help'): print(HELP, end=''); raise SystemExit(0)
        elif a == '--build-configuration': print(""); raise SystemExit(0)
        elif a in ('-f','--from-file'):
            with open(argv[i+1], 'r', encoding='utf-8') as f:
                opts['filter_file'] = f.read()
            i += 1
        elif a == '--arg':
            name=argv[i+1]; val=argv[i+2]; opts['vars'][name]=val; i+=2
        elif a == '--argjson':
            name=argv[i+1]; val=Parser(argv[i+2]).parse(); opts['vars'][name]=val; i+=2
        elif a == '--rawfile':
            name=argv[i+1]; fn=argv[i+2]
            with open(fn, 'r', encoding='utf-8') as f: opts['vars'][name]=f.read()
            i += 2
        elif a == '--slurpfile':
            name=argv[i+1]; fn=argv[i+2]
            with open(fn, 'r', encoding='utf-8') as f: opts['vars'][name]=parse_json_stream(f.read())
            i += 2
        elif a == '--args':
            opts['args_mode']='strings'; i+=1; break
        elif a == '--jsonargs':
            opts['args_mode']='json'; i+=1; break
        elif a.startswith('-') and len(a)>2 and not a.startswith('--'):
            # clustered short options such as -rc
            expanded=[]
            for ch in a[1:]: expanded.append('-'+ch)
            argv=argv[:i]+expanded+argv[i+1:]; i-=1
        else: break
        i+=1
    if 'filter_file' in opts:
        filt = opts['filter_file']
    elif i >= len(argv): filt='.'
    else: filt=argv[i]; i+=1
    if opts.get('args_mode') == 'strings': opts['pos'] = argv[i:]
    elif opts.get('args_mode') == 'json': opts['pos'] = [Parser(x).parse() for x in argv[i:]]
    else: opts['files'] = argv[i:]
    opts['vars']['ARGS']={'positional':opts['pos'], 'named':opts['vars'].copy()}
    return filt, opts

def read_inputs(opts):
    texts=[]
    if opts['files']:
        for fn in opts['files']:
            with open(fn, 'r', encoding='utf-8') as f: texts.append(f.read())
    else: texts=[sys.stdin.read()]
    if opts['null_input']: return [None]
    if opts['raw_input']:
        vals=[]
        for text in texts:
            lines=text.splitlines()
            if text.endswith('\n') and lines and lines[-1]=='': lines=lines[:-1]
            vals += lines
        return [vals] if opts['slurp'] else vals
    vals=[]
    for text in texts: vals += parse_json_stream(text)
    return [vals] if opts['slurp'] else vals

def output_value(v, opts):
    end='\0' if opts.get('raw0') else ('' if opts['join'] else '\n')
    if opts['raw'] and isinstance(v, str): sys.stdout.write(v + end)
    else: sys.stdout.write(dumps(v, indent=opts['indent'], compact=opts['compact'], sort_keys=opts['sort'], ascii_only=opts['ascii'], tab=opts['tab']) + end)

def main(argv):
    try:
        filt, opts = parse_args(argv)
        ast = FilterParser(filt).parse()
        inputs = read_inputs(opts)
        status=0
        produced = False
        last = None
        for val in inputs:
            for out in eval_ast(ast, val, opts['vars']):
                produced = True
                last = out
                output_value(out, opts)
        if opts.get('exit_status'):
            if not produced: return 4
            return 1 if (last is False or last is None) else 0
        return status
    except SystemExit as e: return int(e.code)
    except JsonError as e:
        print('jq: parse error: Invalid numeric literal at <stdin>:1', file=sys.stderr); return 4
    except SyntaxError as e:
        print('jq: error: syntax error, '+str(e), file=sys.stderr); return 3
    except JqError as e:
        print('jq: error (at <stdin>:0): '+str(e), file=sys.stderr); return 5
    except Exception as e:
        print('jq: error: '+str(e), file=sys.stderr); return 5

if __name__ == '__main__': raise SystemExit(main(sys.argv[1:]))
