#!/bin/bash
set -e
cp src/myjq.py executable
chmod +x executable
