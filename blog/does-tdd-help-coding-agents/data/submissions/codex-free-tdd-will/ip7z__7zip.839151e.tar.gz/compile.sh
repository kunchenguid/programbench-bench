#!/bin/bash
set -e
cp src/pb7za.py executable
chmod +x executable
