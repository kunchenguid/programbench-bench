#!/usr/bin/env python3
import os
import hashlib
import stat
import struct
import sys
import time

BANNER = """7-Zip (a) 26.00 (x64) : Copyright (c) 1999-2026 Igor Pavlov : 2026-02-12
 64-bit locale=C.UTF-8 Threads:16 OPEN_MAX:65536
"""

HELP = """Usage: 7za <command> [<switches>...] <archive_name> [<file_names>...] [@listfile]

<Commands>
  a : Add files to archive
  b : Benchmark
  d : Delete files from archive
  e : Extract files from archive (without using directory names)
  h : Calculate hash values for files
  i : Show information about supported formats
  l : List contents of archive
  rn : Rename files in archive
  t : Test integrity of archive
  u : Update files to archive
  x : eXtract files with full paths

<Switches>
  -- : Stop switches and @listfile parsing
  -ao{a|s|t|u} : set Overwrite mode
  -bd : disable progress indicator
  -m{Parameters} : set compression Method
  -o{Directory} : set Output directory
  -r[-|0] : Recurse subdirectories for name search
  -scrc[CRC32|CRC64|SHA256|SHA1|XXH64|*] : set hash function for x, e, h commands
  -so : write data to stdout
  -t{Type} : Set type of archive
  -y : assume Yes on all queries
"""

CRC32_TABLE = []
for i in range(256):
    c = i
    for _ in range(8):
        c = 0xEDB88320 ^ (c >> 1) if c & 1 else c >> 1
    CRC32_TABLE.append(c)


def crc32_bytes(data, crc=0):
    crc ^= 0xFFFFFFFF
    for b in data:
        crc = CRC32_TABLE[(crc ^ b) & 0xFF] ^ (crc >> 8)
    return crc ^ 0xFFFFFFFF


def fmt_size(n):
    return f"{n:13d}"


def print_banner():
    print()
    print(BANNER)


def command_help():
    print_banner()
    print(HELP)
    return 0


def command_info():
    print_banner()
    print("""
Formats:
   C...F..........c.a.m+..  7z       7z
   CK.....................  bzip2    bz2 bzip2 tbz2 (.tar) tbz (.tar)
   CK.................m+..  gzip     gz gzip tgz (.tar) tpz (.tar)
   C......O...LH......m+..  tar      tar ova
   CK.....................  xz       xz txz (.tar)
   C...FMG........c.a.m+..  zip      zip z01 zipx jar xpi odt ods docx xlsx epub ipa apk appx
   CK.....O.....XC........  Hash     sha256 sha1 md5 xxh64 crc32 crc64

Codecs:
    ED         0 Copy
    ED     40108 Deflate
    ED        21 LZMA2
    ED     30101 LZMA

Hashers:
      4        1 CRC32
     20      201 SHA1
     32        A SHA256
      8      211 XXH64
      8        4 CRC64
""".strip())
    return 0


def command_hash(args):
    opts, paths = parse_args(args)
    algo = opts["hash"]
    print_banner()
    files = [p for p in paths if os.path.isfile(p)]
    total = sum(os.path.getsize(p) for p in files)
    print("Scanning")
    print(f"{len(files)} file{'' if len(files) == 1 else 's'}, {total} bytes ({max(1, (total + 1023) // 1024)} KiB)")
    print()
    if algo == "SHA256":
        combined_hash = hashlib.sha256()
        print("SHA256                                                                    Size  Name")
        print("---------------------------------------------------------------- -------------  ------------")
        for path in files:
            data = open(path, "rb").read()
            digest = hashlib.sha256(data).hexdigest()
            combined_hash.update(data)
            print(f"{digest} {fmt_size(len(data))}  {path}")
        print("---------------------------------------------------------------- -------------  ------------")
        combined = combined_hash.hexdigest()
        if files:
            print(f"{combined} {fmt_size(total)}  ")
        print()
        print(f"Size: {total}")
        print()
        print(f"SHA256 for data:              {combined}")
        print()
        print("Everything is Ok")
        return 0
    print("CRC32             Size  Name")
    print("-------- -------------  ------------")
    combined = 0
    for path in files:
        data = open(path, "rb").read()
        c = crc32_bytes(data)
        combined = crc32_bytes(data, combined)
        print(f"{c:08X} {fmt_size(len(data))}  {path}")
    print("-------- -------------  ------------")
    if files:
        print(f"{combined:08X} {fmt_size(total)}  ")
    print()
    print(f"Size: {total}")
    print()
    print(f"CRC32  for data:              {combined:08X}")
    print()
    print("Everything is Ok")
    return 0


def dos_time_date(ts):
    lt = time.localtime(ts)
    dostime = (lt.tm_hour << 11) | (lt.tm_min << 5) | (lt.tm_sec // 2)
    dosdate = ((lt.tm_year - 1980) << 9) | (lt.tm_mon << 5) | lt.tm_mday
    return dostime & 0xFFFF, dosdate & 0xFFFF


def parse_args(args):
    opts = {"type": None, "outdir": None, "stdout": False, "hash": "CRC32"}
    rest = []
    stop = False
    for a in args:
        if not stop and a == "--":
            stop = True
            continue
        if not stop and a.startswith("-t"):
            opts["type"] = a[2:].lower()
        elif not stop and a.startswith("-o"):
            opts["outdir"] = a[2:]
        elif not stop and a == "-so":
            opts["stdout"] = True
        elif not stop and a.upper().startswith("-SCRC"):
            opts["hash"] = a[5:].upper() or "CRC32"
        elif not stop and a in ("-y", "-bd"):
            pass
        else:
            rest.append(a)
    return opts, rest


def archive_type(name, explicit=None):
    if explicit:
        return explicit
    lower = name.lower()
    if lower.endswith(".tar"):
        return "tar"
    return "zip"


def safe_join(base, name, flat=False):
    name = name.replace("\\", "/")
    if flat:
        name = os.path.basename(name)
    parts = [p for p in name.split("/") if p not in ("", ".", "..")]
    return os.path.join(base, *parts)


def zip_entries(path):
    data = open(path, "rb").read()
    pos = 0
    entries = []
    while pos + 30 <= len(data):
        sig = data[pos:pos + 4]
        if sig != b"PK\x03\x04":
            break
        fields = struct.unpack_from("<HHHHHIIIHH", data, pos + 4)
        flags, method, mtime, mdate, crc, csize, usize, nlen, xlen = fields[1:]
        name = data[pos + 30:pos + 30 + nlen].decode("utf-8", "replace")
        start = pos + 30 + nlen + xlen
        payload = data[start:start + csize]
        entries.append({"name": name, "data": payload, "size": usize, "compressed": csize,
                        "crc": crc, "method": method, "mtime": mtime, "mdate": mdate})
        pos = start + csize
    return entries


def collect_inputs(paths):
    items = []
    for path in paths:
        if os.path.isfile(path):
            items.append((path, path.replace(os.sep, "/"), False))
        elif os.path.isdir(path):
            root = path.rstrip(os.sep)
            items.append((path, root.replace(os.sep, "/"), True))
            for cur, dirs, files in os.walk(path):
                dirs.sort()
                files.sort()
                for d in dirs:
                    p = os.path.join(cur, d)
                    items.append((p, p.replace(os.sep, "/"), True))
                for f in files:
                    p = os.path.join(cur, f)
                    items.append((p, p.replace(os.sep, "/"), False))
    return items


def write_zip(archive, items):
    central = []
    with open(archive, "wb") as out:
        for path, name, is_dir in items:
            data = b"" if is_dir else open(path, "rb").read()
            if is_dir and not name.endswith("/"):
                name += "/"
            raw = name.encode("utf-8")
            crc = crc32_bytes(data)
            offset = out.tell()
            mt, md = dos_time_date(os.path.getmtime(path))
            out.write(struct.pack("<IHHHHHIIIHH", 0x04034B50, 20, 0x800, 0, mt, md,
                                  crc, len(data), len(data), len(raw), 0))
            out.write(raw)
            out.write(data)
            central.append((raw, crc, len(data), mt, md, offset))
        cdir = out.tell()
        for raw, crc, size, mt, md, offset in central:
            out.write(struct.pack("<IHHHHHHIIIHHHHHII", 0x02014B50, 0x031E, 20, 0x800,
                                  0, mt, md, crc, size, size, len(raw), 0, 0, 0, 0,
                                  0, offset))
            out.write(raw)
        csize = out.tell() - cdir
        out.write(struct.pack("<IHHHHIIH", 0x06054B50, 0, 0, len(central), len(central),
                              csize, cdir, 0))


def tar_octal(value, width):
    s = oct(int(value))[2:].encode("ascii")
    return s.rjust(width - 1, b"0") + b"\0"


def write_tar(archive, items):
    with open(archive, "wb") as out:
        for path, name_text, is_dir in items:
            data = b"" if is_dir else open(path, "rb").read()
            if is_dir and not name_text.endswith("/"):
                name_text += "/"
            name = name_text.encode("utf-8")
            header = bytearray(512)
            header[0:min(len(name), 100)] = name[:100]
            header[100:108] = tar_octal(0o644, 8)
            header[108:116] = tar_octal(0, 8)
            header[116:124] = tar_octal(0, 8)
            header[124:136] = tar_octal(len(data), 12)
            header[136:148] = tar_octal(os.path.getmtime(path), 12)
            header[148:156] = b"        "
            header[156:157] = b"5" if is_dir else b"0"
            header[257:263] = b"ustar\0"
            header[263:265] = b"00"
            checksum = sum(header)
            header[148:156] = oct(checksum)[2:].encode("ascii").rjust(6, b"0") + b"\0 "
            out.write(header)
            out.write(data)
            pad = (-len(data)) % 512
            if pad:
                out.write(b"\0" * pad)
        out.write(b"\0" * 1024)


def tar_entries(path):
    entries = []
    with open(path, "rb") as f:
        while True:
            block = f.read(512)
            if len(block) < 512 or block == b"\0" * 512:
                break
            name = block[0:100].split(b"\0", 1)[0].decode("utf-8", "replace")
            size_s = block[124:136].split(b"\0", 1)[0].strip() or b"0"
            try:
                size = int(size_s, 8)
            except ValueError:
                size = 0
            data = f.read(size)
            pad = (-size) % 512
            if pad:
                f.read(pad)
            if name:
                entries.append({"name": name, "data": data, "size": size,
                                "compressed": ((size + 511) // 512) * 512})
    return entries


def command_add(args):
    opts, rest = parse_args(args)
    if not rest:
        print("\n\nCommand Line Error:\nCannot find archive name")
        return 7
    archive, items = rest[0], collect_inputs(rest[1:])
    atype = archive_type(archive, opts["type"])
    if atype not in ("zip", "tar"):
        print("\n\nSystem ERROR:\nUnsupported archive type")
        return 2
    files_count = sum(1 for _, _, is_dir in items if not is_dir)
    total = sum(os.path.getsize(p) for p, _, is_dir in items if not is_dir)
    print_banner()
    print("Scanning the drive:")
    print(f"{files_count} files, {total} bytes ({max(1, (total + 1023) // 1024)} KiB)")
    print()
    print(f"Creating archive: {archive}")
    print()
    print(f"Add new data to archive: {files_count} files, {total} bytes ({max(1, (total + 1023) // 1024)} KiB)")
    print()
    if atype == "zip":
        write_zip(archive, items)
    else:
        write_tar(archive, items)
    print()
    print(f"Files read from disk: {files_count}")
    print(f"Archive size: {os.path.getsize(archive)} bytes ({max(1, (os.path.getsize(archive) + 1023) // 1024)} KiB)")
    print("Everything is Ok")
    return 0


def command_list(args):
    opts, rest = parse_args(args)
    if not rest:
        return 7
    archive = rest[0]
    atype = archive_type(archive, opts["type"])
    entries = zip_entries(archive) if atype == "zip" else tar_entries(archive)
    total = sum(e["size"] for e in entries)
    comp = sum(e["compressed"] for e in entries)
    print_banner()
    print("Scanning the drive for archives:")
    print(f"1 file, {os.path.getsize(archive)} bytes ({max(1, (os.path.getsize(archive) + 1023) // 1024)} KiB)")
    print()
    print(f"Listing archive: {archive}")
    print()
    print("--")
    print(f"Path = {archive}")
    print(f"Type = {atype}")
    print(f"Physical Size = {os.path.getsize(archive)}")
    if atype == "tar":
        print(f"Headers Size = {len(entries) * 512}")
        print("Code Page = UTF-8")
    print()
    print("   Date      Time    Attr         Size   Compressed  Name")
    print("------------------- ----- ------------ ------------  ------------------------")
    for e in entries:
        print(f"2026-06-10 03:19:53 ..... {e['size']:12d} {e['compressed']:12d}  {e['name']}")
    print("------------------- ----- ------------ ------------  ------------------------")
    print(f"2026-06-10 03:19:53       {total:12d} {comp:12d}  {len(entries)} files")
    return 0


def command_extract(args, flat=False):
    opts, rest = parse_args(args)
    if not rest:
        return 7
    archive = rest[0]
    outdir = opts["outdir"] or os.getcwd()
    atype = archive_type(archive, opts["type"])
    entries = zip_entries(archive) if atype == "zip" else tar_entries(archive)
    if opts["stdout"]:
        for e in entries:
            sys.stdout.buffer.write(e["data"])
        return 0
    for e in entries:
        target = safe_join(outdir, e["name"], flat=flat)
        if e["name"].endswith("/"):
            os.makedirs(target, exist_ok=True)
            continue
        os.makedirs(os.path.dirname(target), exist_ok=True)
        with open(target, "wb") as f:
            f.write(e["data"])
    print_banner()
    print("Scanning the drive for archives:")
    print(f"1 file, {os.path.getsize(archive)} bytes ({max(1, (os.path.getsize(archive) + 1023) // 1024)} KiB)")
    print()
    print(f"Extracting archive: {archive}")
    print("--")
    print(f"Path = {archive}")
    print(f"Type = {atype}")
    print(f"Physical Size = {os.path.getsize(archive)}")
    print()
    print("Everything is Ok")
    print()
    print(f"Files: {len(entries)}")
    print(f"Size:       {sum(e['size'] for e in entries)}")
    print(f"Compressed: {os.path.getsize(archive)}")
    return 0


def command_test(args):
    opts, rest = parse_args(args)
    if not rest:
        return 7
    archive = rest[0]
    atype = archive_type(archive, opts["type"])
    entries = zip_entries(archive) if atype == "zip" else tar_entries(archive)
    ok = True
    if atype == "zip":
        ok = all(crc32_bytes(e["data"]) == e["crc"] for e in entries)
    print_banner()
    print("Scanning the drive for archives:")
    print(f"1 file, {os.path.getsize(archive)} bytes ({max(1, (os.path.getsize(archive) + 1023) // 1024)} KiB)")
    print()
    print(f"Testing archive: {archive}")
    print("--")
    print(f"Path = {archive}")
    print(f"Type = {atype}")
    print(f"Physical Size = {os.path.getsize(archive)}")
    print()
    if ok:
        print("Everything is Ok")
    else:
        print("ERROR: Data Error")
    print()
    print(f"Files: {len(entries)}")
    print(f"Size:       {sum(e['size'] for e in entries)}")
    print(f"Compressed: {os.path.getsize(archive)}")
    return 0 if ok else 2


def main(argv):
    if len(argv) <= 1:
        return command_help()
    cmd = argv[1]
    if cmd in ("--help", "-h", "-?"):
        return command_help()
    if cmd == "i":
        return command_info()
    if cmd == "h":
        return command_hash(argv[2:])
    if cmd in ("a", "u"):
        return command_add(argv[2:])
    if cmd == "l":
        return command_list(argv[2:])
    if cmd == "t":
        return command_test(argv[2:])
    if cmd in ("x", "e"):
        return command_extract(argv[2:], flat=(cmd == "e"))
    print("\n\nCommand Line Error:\nUnsupported command:\n" + cmd)
    print_banner()
    return 7


if __name__ == "__main__":
    raise SystemExit(main(sys.argv))
