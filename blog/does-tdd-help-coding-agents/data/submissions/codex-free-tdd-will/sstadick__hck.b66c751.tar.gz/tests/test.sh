#!/bin/bash
set -euo pipefail

ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"

fail() {
  echo "FAIL: $1" >&2
  exit 1
}

assert_eq() {
  local name="$1"
  local expected="$2"
  local actual="$3"
  [[ "$actual" == "$expected" ]] || fail "$name expected [$expected] got [$actual]"
}

./compile.sh >/dev/null

out="$(printf 'a b  c\n1 2  3\n' | ./executable)"
assert_eq "default whitespace splitting" $'a\tb\tc\n1\t2\t3' "$out"

out="$(printf 'a,b,c\n1,2,3\n' | ./executable -Ld, -f2)"
assert_eq "literal delimiter field selection" $'b\n2' "$out"

out="$(printf 'a,b,c,d\n1,2,3,4\n' | ./executable -Ld, -f4-,1,2-3)"
assert_eq "range selection is ordered and deduped" $'d\ta\tb\tc\n4\t1\t2\t3' "$out"

out="$(printf 'a,b,c,d\n1,2,3,4\n' | ./executable -Ld, -f1-4 -e2,4-)"
assert_eq "exclude fields take precedence" $'a\tc\n1\t3' "$out"

out="$(printf 'a,b,c\n1,2,3\n' | ./executable -Ld, -I -f1,3)"
assert_eq "input delimiter can be reused for output" $'a,c\n1,3' "$out"

out="$(printf 'a::b---c\n' | ./executable -d ':+|-+' -f2,3)"
assert_eq "regex delimiter splitting" $'b\tc' "$out"

out="$(printf 'USER PID CPU\nroot 1 0.1\nme 2 2.3\n' | ./executable -F PID -F USER)"
assert_eq "literal header field selection" $'PID\tUSER\n1\troot\n2\tme' "$out"

out="$(printf 'USER PID CPU STAT\nroot 1 0.1 S\n' | ./executable -r -F '^C|ST' -F '^USER$' -E '^STAT$')"
assert_eq "regex header selection and exclusion" $'CPU\tUSER\n0.1\troot' "$out"

tmpdir="$(mktemp -d)"
printf 'x:y:z\n' > "$tmpdir/in.txt"
./executable -Ld: -f3,1 -o "$tmpdir/out.txt" "$tmpdir/in.txt"
out="$(cat "$tmpdir/out.txt")"
assert_eq "file input and output option" $'z\tx' "$out"
rm -rf "$tmpdir"

echo "ok"
