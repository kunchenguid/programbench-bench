#!/bin/bash
set -e
gcc -std=c11 -O2 -Wall -Wextra -o executable src/main.c
chmod +x executable
