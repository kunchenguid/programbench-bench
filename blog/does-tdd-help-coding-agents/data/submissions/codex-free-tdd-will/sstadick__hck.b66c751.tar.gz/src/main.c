#define _GNU_SOURCE
#include <ctype.h>
#include <errno.h>
#include <getopt.h>
#include <regex.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef struct {
    char **items;
    size_t len;
    size_t cap;
} Fields;

typedef struct {
    int *items;
    size_t len;
    size_t cap;
} Ints;

typedef struct {
    char *delimiter;
    bool literal_delim;
    char *out_delim;
    char *fields_spec;
    char *exclude_spec;
    Fields header_fields;
    Fields exclude_headers;
    bool header_is_regex;
    bool output_delim_set;
    bool use_input_delim;
    char *output_path;
    bool try_decompress;
    bool try_compress;
} Config;

static void die(const char *msg) {
    fprintf(stderr, "%s\n", msg);
    exit(1);
}

static void fields_push(Fields *f, const char *start, size_t len) {
    if (f->len == f->cap) {
        size_t cap = f->cap ? f->cap * 2 : 8;
        char **items = realloc(f->items, cap * sizeof(char *));
        if (!items) die("out of memory");
        f->items = items;
        f->cap = cap;
    }
    char *s = malloc(len + 1);
    if (!s) die("out of memory");
    memcpy(s, start, len);
    s[len] = '\0';
    f->items[f->len++] = s;
}

static void fields_free(Fields *f) {
    for (size_t i = 0; i < f->len; i++) free(f->items[i]);
    free(f->items);
    f->items = NULL;
    f->len = f->cap = 0;
}

static void strings_push(Fields *f, const char *s) {
    fields_push(f, s, strlen(s));
}

static void ints_push_unique(Ints *v, int x) {
    if (x < 1) {
        fprintf(stderr, "[2026-06-11T05:34:58Z ERROR hck] Fields and positions are numbered from 1: %d\n", x);
        exit(1);
    }
    for (size_t i = 0; i < v->len; i++) {
        if (v->items[i] == x) return;
    }
    if (v->len == v->cap) {
        size_t cap = v->cap ? v->cap * 2 : 8;
        int *items = realloc(v->items, cap * sizeof(int));
        if (!items) die("out of memory");
        v->items = items;
        v->cap = cap;
    }
    v->items[v->len++] = x;
}

static void ints_free(Ints *v) {
    free(v->items);
    v->items = NULL;
    v->len = v->cap = 0;
}

static Fields split_ws(const char *line) {
    Fields f = {0};
    size_t n = strlen(line);
    size_t start = 0;
    size_t i = 0;
    while (i < n) {
        if (isspace((unsigned char)line[i])) {
            fields_push(&f, line + start, i - start);
            while (i < n && isspace((unsigned char)line[i])) i++;
            start = i;
        } else {
            i++;
        }
    }
    fields_push(&f, line + start, n - start);
    return f;
}

static Fields split_literal(const char *line, const char *delim) {
    Fields f = {0};
    size_t dlen = strlen(delim);
    if (dlen == 0) {
        fields_push(&f, line, strlen(line));
        return f;
    }
    const char *p = line;
    const char *m;
    while ((m = strstr(p, delim)) != NULL) {
        fields_push(&f, p, (size_t)(m - p));
        p = m + dlen;
    }
    fields_push(&f, p, strlen(p));
    return f;
}

static Fields split_regex(const char *line, const char *pattern) {
    Fields f = {0};
    regex_t re;
    int rc = regcomp(&re, pattern, REG_EXTENDED);
    if (rc != 0) {
        fields_push(&f, line, strlen(line));
        return f;
    }
    const char *p = line;
    regmatch_t m;
    while (regexec(&re, p, 1, &m, 0) == 0) {
        if (m.rm_so < 0) break;
        fields_push(&f, p, (size_t)m.rm_so);
        long end = m.rm_eo;
        if (end <= 0) end = 1;
        p += end;
    }
    fields_push(&f, p, strlen(p));
    regfree(&re);
    return f;
}

static Fields split_line(const char *line, const Config *cfg) {
    if (cfg->literal_delim) return split_literal(line, cfg->delimiter);
    if (strcmp(cfg->delimiter, "\\s+") == 0) return split_ws(line);
    return split_regex(line, cfg->delimiter);
}

static Ints parse_field_spec(const char *spec, int nfields) {
    Ints out = {0};
    if (!spec || !*spec) return out;
    char *copy = strdup(spec);
    if (!copy) die("out of memory");
    char *save = NULL;
    for (char *tok = strtok_r(copy, ",", &save); tok; tok = strtok_r(NULL, ",", &save)) {
        char *dash = strchr(tok, '-');
        if (!dash) {
            ints_push_unique(&out, atoi(tok));
            continue;
        }
        int start;
        int end;
        if (dash == tok) {
            start = 1;
        } else {
            *dash = '\0';
            start = atoi(tok);
        }
        if (dash[1] == '\0') {
            end = nfields;
        } else {
            end = atoi(dash + 1);
        }
        if (start < 1) ints_push_unique(&out, start);
        if (end < 1) ints_push_unique(&out, end);
        for (int i = start; i <= end; i++) ints_push_unique(&out, i);
    }
    free(copy);
    return out;
}

static bool int_contains(const Ints *v, int x) {
    for (size_t i = 0; i < v->len; i++) {
        if (v->items[i] == x) return true;
    }
    return false;
}

static bool header_matches(const char *value, const char *pat, bool is_regex) {
    if (!is_regex) return strcmp(value, pat) == 0;
    regex_t re;
    if (regcomp(&re, pat, REG_EXTENDED) != 0) return false;
    bool ok = regexec(&re, value, 0, NULL, 0) == 0;
    regfree(&re);
    return ok;
}

static Ints select_headers(const Fields *header, const Fields *patterns, bool is_regex) {
    Ints out = {0};
    for (size_t p = 0; p < patterns->len; p++) {
        for (size_t i = 0; i < header->len; i++) {
            if (header_matches(header->items[i], patterns->items[p], is_regex)) {
                ints_push_unique(&out, (int)i + 1);
            }
        }
    }
    return out;
}

static void output_selected(FILE *out, const Fields *f, const Ints *sel, const Ints *exclude, const char *delim) {
    bool first = true;
    if (sel->len == 0) {
        for (size_t i = 0; i < f->len; i++) {
            if (int_contains(exclude, (int)i + 1)) continue;
            if (!first) fputs(delim, out);
            first = false;
            fputs(f->items[i], out);
        }
    } else {
        for (size_t i = 0; i < sel->len; i++) {
            int idx = sel->items[i] - 1;
            if (idx < 0 || (size_t)idx >= f->len) continue;
            if (int_contains(exclude, idx + 1)) continue;
            if (!first) fputs(delim, out);
            first = false;
            fputs(f->items[idx], out);
        }
    }
    fputc('\n', out);
}

static void process_stream(FILE *in, FILE *out, const Config *cfg) {
    char *line = NULL;
    size_t cap = 0;
    ssize_t nread;
    bool first_line = true;
    Ints header_sel = {0};
    Ints header_exclude = {0};
    while ((nread = getline(&line, &cap, in)) >= 0) {
        while (nread > 0 && (line[nread - 1] == '\n' || line[nread - 1] == '\r')) {
            line[--nread] = '\0';
        }
        Fields f = split_line(line, cfg);
        Ints sel = {0};
        Ints exclude = parse_field_spec(cfg->exclude_spec, (int)f.len);
        if (first_line && cfg->header_fields.len) {
            header_sel = select_headers(&f, &cfg->header_fields, cfg->header_is_regex);
            if (header_sel.len == 0) {
                fprintf(stderr, "[2026-06-11T05:34:58Z ERROR hck] No headers matched\n");
                exit(1);
            }
        }
        if (first_line && cfg->exclude_headers.len) {
            header_exclude = select_headers(&f, &cfg->exclude_headers, cfg->header_is_regex);
        }
        if (cfg->header_fields.len) {
            sel = header_sel;
        } else {
            sel = parse_field_spec(cfg->fields_spec, (int)f.len);
        }
        for (size_t i = 0; i < header_exclude.len; i++) {
            ints_push_unique(&exclude, header_exclude.items[i]);
        }
        output_selected(out, &f, &sel, &exclude, cfg->out_delim);
        if (!cfg->header_fields.len) ints_free(&sel);
        ints_free(&exclude);
        fields_free(&f);
        first_line = false;
    }
    ints_free(&header_sel);
    ints_free(&header_exclude);
    free(line);
}

static bool ends_with(const char *s, const char *suffix) {
    size_t n = strlen(s), m = strlen(suffix);
    return n >= m && strcmp(s + n - m, suffix) == 0;
}

static char *shell_quote(const char *s) {
    size_t len = 3;
    for (const char *p = s; *p; p++) len += (*p == '\'') ? 4 : 1;
    char *q = malloc(len);
    if (!q) die("out of memory");
    char *o = q;
    *o++ = '\'';
    for (const char *p = s; *p; p++) {
        if (*p == '\'') {
            memcpy(o, "'\\''", 4);
            o += 4;
        } else {
            *o++ = *p;
        }
    }
    *o++ = '\'';
    *o = '\0';
    return q;
}

int main(int argc, char **argv) {
    Config cfg = {.delimiter = "\\s+", .literal_delim = false, .out_delim = "\t", .fields_spec = NULL, .exclude_spec = NULL, .header_fields = {0}, .exclude_headers = {0}, .header_is_regex = false, .output_delim_set = false, .use_input_delim = false, .output_path = NULL, .try_decompress = false, .try_compress = false};
    static struct option opts[] = {
        {"output", required_argument, 0, 'o'},
        {"delimiter", required_argument, 0, 'd'},
        {"delim-is-literal", no_argument, 0, 'L'},
        {"use-input-delim", no_argument, 0, 'I'},
        {"output-delimiter", required_argument, 0, 'D'},
        {"fields", required_argument, 0, 'f'},
        {"exclude", required_argument, 0, 'e'},
        {"header-field", required_argument, 0, 'F'},
        {"exclude-header", required_argument, 0, 'E'},
        {"header-is-regex", no_argument, 0, 'r'},
        {"try-decompress", no_argument, 0, 'z'},
        {"try-compress", no_argument, 0, 'Z'},
        {"compression-threads", required_argument, 0, 't'},
        {"compression-level", required_argument, 0, 'l'},
        {"no-mmap", no_argument, 0, 1000},
        {"crlf", no_argument, 0, 1001},
        {"help", no_argument, 0, 'h'},
        {"version", no_argument, 0, 'V'},
        {0, 0, 0, 0}
    };
    int c;
    while ((c = getopt_long(argc, argv, "o:d:LD:If:e:F:E:rzZt:l:hV", opts, NULL)) != -1) {
        if (c == 'o') cfg.output_path = optarg;
        else if (c == 'd') cfg.delimiter = optarg;
        else if (c == 'L') cfg.literal_delim = true;
        else if (c == 'D') {
            cfg.out_delim = optarg;
            cfg.output_delim_set = true;
        }
        else if (c == 'I') cfg.use_input_delim = true;
        else if (c == 'f') cfg.fields_spec = optarg;
        else if (c == 'e') cfg.exclude_spec = optarg;
        else if (c == 'F') strings_push(&cfg.header_fields, optarg);
        else if (c == 'E') strings_push(&cfg.exclude_headers, optarg);
        else if (c == 'r') cfg.header_is_regex = true;
        else if (c == 'z') cfg.try_decompress = true;
        else if (c == 'Z') cfg.try_compress = true;
        else if (c == 't' || c == 'l' || c == 1000 || c == 1001) {
            /* Accepted for CLI compatibility; this implementation is single threaded. */
        }
        else
        if (c == 'h') {
            puts("Usage: executable [OPTIONS] [INPUT]...\n");
            puts("Arguments:");
            puts("  [INPUT]...  Input files to parse, defaults to stdin\n");
            puts("Options:");
            puts("  -o, --output <OUTPUT>");
            puts("  -d, --delimiter <DELIMITER>        [default: \\s+]");
            puts("  -L, --delim-is-literal");
            puts("  -I, --use-input-delim");
            puts("  -D, --output-delimiter <OUTPUT_DELIMITER>");
            puts("  -f, --fields <FIELDS>");
            puts("  -e, --exclude <EXCLUDE>");
            puts("  -E, --exclude-header <EXCLUDE_HEADER>");
            puts("  -F, --header-field <HEADER_FIELD>");
            puts("  -r, --header-is-regex");
            puts("  -z, --try-decompress");
            puts("  -Z, --try-compress");
            puts("  -t, --compression-threads <COMPRESSION_THREADS>");
            puts("  -l, --compression-level <COMPRESSION_LEVEL>");
            puts("      --no-mmap");
            puts("      --crlf");
            puts("  -h, --help");
            puts("  -V, --version");
            return 0;
        }
        if (c == 'V') {
            puts("hck git:23bebe8-modified");
            return 0;
        }
    }
    (void)errno;
    if (cfg.use_input_delim && cfg.literal_delim && !cfg.output_delim_set) {
        cfg.out_delim = cfg.delimiter;
    }
    FILE *out = stdout;
    bool out_is_pipe = false;
    if (cfg.try_compress) {
        char *cmd;
        if (cfg.output_path) {
            char *q = shell_quote(cfg.output_path);
            if (asprintf(&cmd, "gzip -c > %s", q) < 0) die("out of memory");
            free(q);
        } else {
            cmd = strdup("gzip -c");
            if (!cmd) die("out of memory");
        }
        out = popen(cmd, "w");
        free(cmd);
        if (!out) {
            perror("gzip");
            return 1;
        }
        out_is_pipe = true;
    } else if (cfg.output_path) {
        out = fopen(cfg.output_path, "wb");
        if (!out) {
            perror(cfg.output_path);
            return 1;
        }
    }
    if (optind == argc) {
        process_stream(stdin, out, &cfg);
    } else {
        for (int i = optind; i < argc; i++) {
            FILE *in = NULL;
            bool in_is_pipe = false;
            if (cfg.try_decompress && ends_with(argv[i], ".gz")) {
                char *q = shell_quote(argv[i]);
                char *cmd;
                if (asprintf(&cmd, "gzip -cd %s", q) < 0) die("out of memory");
                free(q);
                in = popen(cmd, "r");
                free(cmd);
                in_is_pipe = true;
            } else {
                in = fopen(argv[i], "rb");
            }
            if (!in) {
                perror(argv[i]);
                if (out_is_pipe) pclose(out);
                else if (out != stdout) fclose(out);
                return 1;
            }
            process_stream(in, out, &cfg);
            if (in_is_pipe) pclose(in);
            else fclose(in);
        }
    }
    if (out_is_pipe) pclose(out);
    else if (out != stdout) fclose(out);
    fields_free(&cfg.header_fields);
    fields_free(&cfg.exclude_headers);
    return 0;
}
