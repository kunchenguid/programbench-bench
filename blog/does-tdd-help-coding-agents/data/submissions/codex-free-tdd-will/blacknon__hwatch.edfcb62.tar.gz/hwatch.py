#!/usr/bin/env python3
import sys
import os
import shlex
import subprocess
import time
from datetime import datetime

HELP = """A modern alternative to the watch command, records the differences in execution results and can check this differences at after.

Usage: executable [OPTIONS] [command]...

Arguments:
  [command]...  

Options:
  -b, --batch                         output execution results to stdout
  -B, --beep                          beep if command has a change result
      --border                        Surround each pane with a border frame
      --with-scrollbar                When the border option is enabled, display scrollbar on the right side of watch pane.
      --mouse                         enable mouse wheel support. With this option, copying text with your terminal may be harder. Try holding the Shift key.
  -c, --color                         interpret ANSI color and style sequences
  -r, --reverse                       display text upside down.
  -C, --compress                      Compress data in memory. Note: If the output of the command is small, you may not get the desired effect.
  -t, --no-title                      hide the UI on start. Use `t` to toggle it.
      --enable-summary-char           collect character-level diff count in summary.
  -N, --line-number                   show line number
      --no-help-banner                hide the "Display help with h key" message
      --no-summary                    disable the calculation for summary that is running behind the scenes, and disable the summary function in the first place.
  -x, --exec                          Run the command directly, not through the shell. Much like the `-x` option of the watch command.
  -O, --diff-output-only              Display only the lines with differences during `line` diff and `word` diff.
  -A, --aftercommand <after_command>  Executes the specified command if the output changes. Information about changes is stored in json format in environment variable ${HWATCH_DATA}.
  -l, --logfile [<logfile>]           logging file. if a log file is already used, its contents will be read and executed.
  -s, --shell <shell_command>         shell to use at runtime. can also insert the command to the location specified by {COMMAND}. [default: "sh -c"]
  -n, --interval <interval>           seconds to wait between updates [default: 2]
      --precise                       Attempt to run as close to the interval as possible, regardless of how long the command takes to run
  -L, --limit <limit>                 Set the number of history records to keep. only work in watch mode. Set `0` for unlimited recording. (default: 5000) [default: 5000]
      --tab-size <tab_size>           Specifying tab display size [default: 4]
  -d, --differences [<differences>]   highlight changes between updates [possible values: none, watch, line, word]
  -o, --output [<output>]             Select command output. [default: output] [possible values: output, stdout, stderr]
  -K, --keymap <keymap>               Add keymap
  -h, --help                          Print help
  -V, --version                       Print version
"""


def main(argv):
    if os.environ.get("HWATCH"):
        argv = shlex.split(os.environ["HWATCH"]) + argv
    if "--help" in argv or "-h" in argv:
        sys.stdout.write(HELP)
        return 0
    if "--version" in argv or "-V" in argv:
        print("hwatch 0.3.19")
        return 0
    if not argv:
        sys.stderr.write(
            "error: command not specified and logfile is empty.\n\n"
            "Usage: hwatch [OPTIONS] [command]...\n\n"
            "For more information, try '--help'.\n"
        )
        return 2
    interval = 2.0
    batch = False
    output = "output"
    reverse = False
    line_number = False
    shell_command = "sh -c"
    logfile = None
    command = []
    i = 0
    while i < len(argv):
        arg = argv[i]
        if arg in ("-b", "--batch"):
            batch = True
            i += 1
        elif arg in ("-r", "--reverse"):
            reverse = True
            i += 1
        elif arg in ("-N", "--line-number"):
            line_number = True
            i += 1
        elif arg in ("-n", "--interval"):
            i += 1
            try:
                interval = float(argv[i].replace(",", "."))
            except (IndexError, ValueError):
                sys.stderr.write(
                    f"error: invalid value '{argv[i] if i < len(argv) else ''}' for '--interval <interval>': invalid float literal\n\n"
                    "For more information, try '--help'.\n"
                )
                return 2
            if interval < 0.001:
                interval = 0.001
            i += 1
        elif arg in ("-o", "--output"):
            if i + 1 < len(argv) and not argv[i + 1].startswith("-"):
                output = argv[i + 1]
                if output not in ("output", "stdout", "stderr"):
                    sys.stderr.write(
                        f"error: invalid value '{output}' for '--output [<output>]'\n"
                        "  [possible values: output, stdout, stderr]\n\n"
                        "For more information, try '--help'.\n"
                    )
                    return 2
                i += 2
            else:
                output = "output"
                i += 1
        elif arg in ("-s", "--shell"):
            if i + 1 >= len(argv):
                sys.stderr.write("error: a value is required for '--shell <shell_command>' but none was supplied\n\nFor more information, try '--help'.\n")
                return 2
            shell_command = argv[i + 1]
            i += 2
        elif arg in ("-l", "--logfile"):
            if i + 1 < len(argv) and not argv[i + 1].startswith("-"):
                logfile = argv[i + 1]
                i += 2
            else:
                logfile = "hwatch_log.json"
                i += 1
        elif arg in ("-d", "--differences"):
            if i + 1 < len(argv) and not argv[i + 1].startswith("-"):
                value = argv[i + 1]
                if value not in ("none", "watch", "line", "word"):
                    sys.stderr.write(
                        f"error: invalid value '{value}' for '--differences [<differences>]'\n"
                        "  [possible values: none, watch, line, word]\n\n"
                        "For more information, try '--help'.\n"
                    )
                    return 2
                i += 2
            else:
                i += 1
        elif arg.startswith("-"):
            i += 1
        else:
            command = argv[i:]
            break
    if not command:
        sys.stderr.write(
            "error: command not specified and logfile is empty.\n\n"
            "Usage: hwatch [OPTIONS] [command]...\n\n"
            "For more information, try '--help'.\n"
        )
        return 2
    if batch:
        command_text = " ".join(command)
        if logfile:
            with open(logfile, "w", encoding="utf-8") as f:
                f.write('{"timestamp":"","command":"","status":true,"output":"","stdout":"","stderr":""}\n')
        while True:
            started = time.time()
            stamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S.") + f"{int(datetime.now().microsecond / 1000):03d}"
            sys.stdout.write(f"\x1b[38;5;240m=====[{stamp}]=========================\x1b[0m\n")
            if "{COMMAND}" in shell_command:
                run_text = shell_command.replace("{COMMAND}", shlex.quote(command_text))
            elif shell_command == "sh -c":
                run_text = command_text
            else:
                run_text = shell_command + " " + shlex.quote(command_text)
            proc = subprocess.run(run_text, shell=True, text=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
            if output == "stdout":
                text = proc.stdout
            elif output == "stderr":
                text = proc.stderr
            else:
                text = proc.stdout + proc.stderr
            if reverse:
                text = "\n".join(reversed(text.split("\n")))
                if not text.endswith("\n"):
                    text += "\n"
            if line_number:
                lines = text.split("\n")
                text = "".join(
                    f"\x1b[38;5;240m{idx}\x1b[0m\x1b[38;5;240m | \x1b[0m{line}\n"
                    for idx, line in enumerate(lines, 1)
                )
            sys.stdout.write(text)
            sys.stdout.write("\n")
            sys.stdout.flush()
            delay = interval - (time.time() - started)
            if delay > 0:
                time.sleep(delay)
    return 0


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
