#!/usr/bin/env python3
import json
import re
import sys


VERSION = "tuc 1.3.0"

HELP = """tuc 1.3.0
Cut text (or bytes) where a delimiter matches, then keep the desired parts.

USAGE:
    tuc [FLAGS] [OPTIONS] < input
    tuc [FLAGS] [OPTIONS] filepath

FLAGS:
    -g, --greedy-delimiter        Match consecutive delimiters as if it was one
    -p, --compress-delimiter      Print only the first delimiter of a sequence
    -s, --only-delimited          Print only lines containing the delimiter
    -V, --version                 Print version information
    -z, --zero-terminated         Line delimiter is NUL (\\0), not LF (\\n)
    -h, --help                    Print this help and exit
    -m, --complement              Invert fields (e.g. '2' becomes '1,3:')
    -j, --(no-)join               Print selected parts with delimiter in between
    --json                        Print fields as a JSON array of strings
    --no-mmap                     Disable memory mapping
"""

SPLASH = """tuc 1.3.0 - Created by Riccardo Attilio Galli

Cut text (or bytes) where a delimiter matches, then keep the desired parts.

Some examples:

    $ echo "a/b/c" | tuc -d / -f 1,-1
    ac

    $ echo "a/b/c" | tuc -d / -f 2:
    b/c

    $ echo "hello.bak" | tuc -d . -f 'mv {1:} {1}'
    mv hello.bak hello

    $ printf "a\\nb\\nc\\nd\\ne" | tuc -l 2:-2
    b
    c
    d

Run `tuc --help` for more detailed information.
Send bug reports to: https://github.com/riquito/tuc/issues
"""


class TucError(Exception):
    pass


def parse_args(argv):
    opts = {
        "delimiter": "\t",
        "regex": None,
        "bounds": None,
        "mode": "fields",
        "join": False,
        "join_set": False,
        "replace": None,
        "json": False,
        "greedy": False,
        "compress": False,
        "only_delimited": False,
        "zero": False,
        "complement": False,
        "fallback": None,
        "trim": None,
        "file": None,
    }
    i = 0
    while i < len(argv):
        arg = argv[i]
        if arg in ("-h", "--help"):
            opts["help"] = True
        elif arg in ("-V", "--version"):
            opts["version"] = True
        elif arg in ("-d", "--delimiter"):
            i += 1
            opts["delimiter"] = decode_escape(argv[i])
        elif arg.startswith("--delimiter="):
            opts["delimiter"] = decode_escape(arg.split("=", 1)[1])
        elif arg in ("-e", "--regex"):
            i += 1
            opts["regex"] = argv[i]
        elif arg in ("-f", "--fields"):
            i += 1
            opts["mode"] = "fields"
            opts["bounds"] = argv[i]
        elif arg.startswith("--fields="):
            opts["mode"] = "fields"
            opts["bounds"] = arg.split("=", 1)[1]
        elif arg in ("-b", "--bytes"):
            i += 1
            opts["mode"] = "bytes"
            opts["bounds"] = argv[i]
        elif arg in ("-c", "--characters"):
            i += 1
            opts["mode"] = "characters"
            opts["bounds"] = argv[i]
        elif arg in ("-l", "--lines"):
            i += 1
            opts["mode"] = "lines"
            opts["bounds"] = argv[i]
            if not opts["join_set"]:
                opts["join"] = True
        elif arg in ("-j", "--join"):
            opts["join"] = True
            opts["join_set"] = True
        elif arg == "--no-join":
            opts["join"] = False
            opts["join_set"] = True
        elif arg in ("-r", "--replace-delimiter"):
            i += 1
            opts["replace"] = decode_escape(argv[i])
            opts["join"] = True
        elif arg == "--json":
            opts["json"] = True
        elif arg in ("-g", "--greedy-delimiter"):
            opts["greedy"] = True
        elif arg in ("-p", "--compress-delimiter"):
            opts["compress"] = True
        elif arg in ("-s", "--only-delimited"):
            opts["only_delimited"] = True
        elif arg in ("-z", "--zero-terminated"):
            opts["zero"] = True
        elif arg in ("-m", "--complement"):
            opts["complement"] = True
        elif arg in ("--fallback-oob",):
            i += 1
            opts["fallback"] = argv[i]
        elif arg in ("-t", "--trim"):
            i += 1
            opts["trim"] = argv[i].lower()[0]
        elif arg in ("--no-mmap", "-M", "--fixed-memory"):
            if arg in ("-M", "--fixed-memory") and i + 1 < len(argv):
                i += 1
        elif not arg.startswith("-") and opts["file"] is None:
            opts["file"] = arg
        i += 1
    if opts["bounds"] is None and len(argv) > 0:
        opts["bounds"] = "1:"
    return opts


def decode_escape(s):
    return s.replace("\\t", "\t").replace("\\n", "\n").replace("\\0", "\0")


def read_input(opts):
    if opts["file"]:
        with open(opts["file"], "rb") as fh:
            return fh.read()
    return sys.stdin.buffer.read()


def split_records(data, sep):
    parts = data.split(sep)
    records = []
    for idx, part in enumerate(parts):
        if idx < len(parts) - 1:
            records.append((part, sep))
        elif part:
            records.append((part, b""))
    return records


def split_fields(text, opts):
    if opts["compress"] and opts["delimiter"]:
        text = re.sub(re.escape(opts["delimiter"]) + "+", opts["delimiter"], text)
    if opts["regex"] is not None:
        fields, delims, pos = [], [], 0
        for match in re.finditer(opts["regex"], text):
            fields.append(text[pos : match.start()])
            delims.append(match.group(0))
            pos = match.end()
        fields.append(text[pos:])
        return fields, delims
    delim = opts["delimiter"]
    if opts["greedy"] and delim:
        fields = re.split(re.escape(delim) + "+", text)
        delims = [delim] * (len(fields) - 1)
        return fields, delims
    fields = text.split(delim)
    delims = [delim] * (len(fields) - 1)
    return fields, delims


def normalize_index(spec, length, fallback):
    try:
        idx = int(spec)
    except ValueError:
        raise TucError(f"failed to parse '{spec}': Not a number `{spec}`")
    if idx < 0:
        idx = length + idx + 1
    if idx < 1 or idx > length:
        if fallback is not None:
            return None
        raise TucError(f"Error: Out of bounds: {spec}")
    return idx


def parse_bound_part(part):
    fallback = None
    if "=" in part:
        part, fallback = part.split("=", 1)
    return part, fallback


def range_indices(part, length, fallback):
    raw, local_fallback = parse_bound_part(part)
    fallback = local_fallback if local_fallback is not None else fallback
    if ":" in raw:
        start_s, end_s = raw.split(":", 1)
        start = normalize_index(start_s, length, fallback) if start_s else 1
        end = normalize_index(end_s, length, fallback) if end_s else length
        if start is None or end is None:
            return [], fallback
        if start <= end:
            return list(range(start, end + 1)), fallback
        return list(range(start, end - 1, -1)), fallback
    idx = normalize_index(raw, length, fallback)
    return ([] if idx is None else [idx]), fallback


def selected_index_groups(bounds, length, fallback):
    groups = []
    for part in bounds.split(","):
        indices, fb = range_indices(part, length, fallback)
        groups.append((indices, fb, ":" in parse_bound_part(part)[0]))
    return groups


def complement_groups(groups, length):
    chosen = set()
    for indices, _fb, _is_range in groups:
        chosen.update(indices)
    out = [i for i in range(1, length + 1) if i not in chosen]
    if not out:
        return []
    ranges = []
    start = prev = out[0]
    for idx in out[1:]:
        if idx == prev + 1:
            prev = idx
        else:
            ranges.append((list(range(start, prev + 1)), None, start != prev))
            start = prev = idx
    ranges.append((list(range(start, prev + 1)), None, start != prev))
    return ranges


def join_group(values, delims, indices, is_range, opts):
    if not indices:
        return None
    if opts["join"]:
        sep = opts["replace"] if opts["replace"] is not None else opts["delimiter"]
        return sep.join(values[i - 1] for i in indices)
    if is_range and len(indices) > 1:
        chunks = []
        for pos, idx in enumerate(indices):
            chunks.append(values[idx - 1])
            if pos < len(indices) - 1 and idx - 1 < len(delims):
                chunks.append(delims[idx - 1])
        return "".join(chunks)
    return "".join(values[i - 1] for i in indices)


def apply_bounds(values, delims, bounds, opts):
    if is_format(bounds):
        return [format_output(bounds, values, delims, opts)]
    groups = selected_index_groups(bounds, len(values), opts["fallback"])
    if opts["complement"]:
        groups = complement_groups(groups, len(values))
    if opts["json"]:
        arr = []
        for indices, fb, _is_range in groups:
            if not indices and fb is not None:
                arr.append(fb)
            else:
                arr.extend(values[i - 1] for i in indices)
        return arr
    out = []
    for indices, fb, is_range in groups:
        if not indices and fb is not None:
            out.append(fb)
        else:
            item = join_group(values, delims, indices, is_range, opts)
            if item is not None:
                out.append(item)
    if opts["join"] and len(out) > 1:
        sep = opts["replace"] if opts["replace"] is not None else opts["delimiter"]
        return [sep.join(out)]
    return ["".join(out)]


def is_format(bounds):
    return "{" in bounds or "}" in bounds


def format_output(fmt, values, delims, opts):
    sentinel_l, sentinel_r = "\x00L", "\x00R"
    work = fmt.replace("{{", sentinel_l).replace("}}", sentinel_r)

    def repl(match):
        inner = match.group(1)
        groups = selected_index_groups(inner, len(values), opts["fallback"])
        parts = []
        for indices, fb, is_range in groups:
            if not indices and fb is not None:
                parts.append(fb)
            else:
                parts.append(join_group(values, delims, indices, is_range, opts) or "")
        return "".join(parts)

    work = re.sub(r"\{([^{}]+)\}", repl, work)
    return work.replace(sentinel_l, "{").replace(sentinel_r, "}")


def process_fields(data, opts):
    sep = b"\0" if opts["zero"] else b"\n"
    output = []
    for rec, ending in split_records(data, sep):
        text = rec.decode("utf-8", "surrogateescape")
        values, delims = split_fields(text, opts)
        if opts["only_delimited"] and len(values) == 1:
            continue
        result = apply_bounds(values, delims, opts["bounds"], opts)
        if opts["json"]:
            rendered = json.dumps(result, ensure_ascii=False, separators=(",", ":"))
        else:
            rendered = result[0]
        output.append(rendered.encode("utf-8", "surrogateescape") + ending)
    return b"".join(output)


def process_units(data, opts, by_chars=False):
    if by_chars:
        text = data.decode("utf-8", "surrogateescape")
        ending = "\n" if text.endswith("\n") else ""
        body = text[:-1] if ending else text
        values = list(body)
        result = apply_bounds(values, [""] * max(0, len(values) - 1), opts["bounds"], opts)
        return (json.dumps(result, ensure_ascii=False, separators=(",", ":")) if opts["json"] else result[0]).encode("utf-8", "surrogateescape") + ending.encode()
    values = [bytes([b]).decode("latin1") for b in data]
    result = apply_bounds(values, [""] * max(0, len(values) - 1), opts["bounds"], opts)
    if opts["json"]:
        return json.dumps(result, separators=(",", ":")).encode()
    return b"".join(v.encode("latin1") for v in result)


def process_lines(data, opts):
    sep = b"\0" if opts["zero"] else b"\n"
    records = split_records(data, sep)
    values = [rec.decode("utf-8", "surrogateescape") for rec, _ in records]
    delim = "\0" if opts["zero"] else "\n"
    line_opts = dict(opts)
    line_opts["delimiter"] = delim
    if line_opts["replace"] is not None:
        line_opts["delimiter"] = line_opts["replace"]
    result = apply_bounds(values, [delim] * max(0, len(values) - 1), opts["bounds"], line_opts)
    if opts["json"]:
        return (json.dumps(result, ensure_ascii=False, separators=(",", ":")) + "\n").encode("utf-8", "surrogateescape")
    rendered = result[0]
    if rendered:
        rendered += delim
    return rendered.encode("utf-8", "surrogateescape")


def main(argv=None):
    argv = sys.argv[1:] if argv is None else argv
    opts = parse_args(argv)
    if opts.get("help"):
        sys.stdout.write(HELP)
        return 0
    if opts.get("version"):
        print(VERSION)
        return 0
    if not argv:
        sys.stdout.write(SPLASH)
        return 0
    try:
        data = read_input(opts)
        if opts["mode"] == "bytes":
            out = process_units(data, opts, by_chars=False)
        elif opts["mode"] == "characters":
            out = process_units(data, opts, by_chars=True)
        elif opts["mode"] == "lines":
            out = process_lines(data, opts)
        else:
            out = process_fields(data, opts)
        sys.stdout.buffer.write(out)
        return 0
    except TucError as exc:
        msg = str(exc)
        if msg.startswith("failed to parse"):
            sys.stderr.write(msg + "\n")
        else:
            sys.stderr.write(msg + "\n")
        return 1
    except (IndexError, ValueError) as exc:
        sys.stderr.write(str(exc) + "\n")
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
