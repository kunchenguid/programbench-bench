import subprocess
import sys
import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
CLI = [sys.executable, str(ROOT / "src" / "tuc.py")]


def run_tuc(args, data=b""):
    return subprocess.run(CLI + args, input=data, stdout=subprocess.PIPE, stderr=subprocess.PIPE)


class TucCliTests(unittest.TestCase):
    def test_version_output(self):
        result = run_tuc(["--version"])
        self.assertEqual(result.returncode, 0)
        self.assertEqual(result.stdout, b"tuc 1.3.0\n")
        self.assertEqual(result.stderr, b"")

    def test_selects_one_delimited_field(self):
        result = run_tuc(["-d", "-", "-f", "2"], b"a-b-c-d\n")
        self.assertEqual(result.returncode, 0)
        self.assertEqual(result.stdout, b"b\n")
        self.assertEqual(result.stderr, b"")

    def test_selects_ranges_and_reordered_fields(self):
        result = run_tuc(["-d", "-", "-f", "3,1:2"], b"a-b-c-d\n")
        self.assertEqual(result.returncode, 0)
        self.assertEqual(result.stdout, b"ca-b\n")
        self.assertEqual(result.stderr, b"")

    def test_json_outputs_selected_fields(self):
        result = run_tuc(["-d", ",", "--json", "-f", "3,1"], b"a,b,c\n")
        self.assertEqual(result.returncode, 0)
        self.assertEqual(result.stdout, b'["c","a"]\n')
        self.assertEqual(result.stderr, b"")

    def test_bytes_and_characters_slice_differently(self):
        result = run_tuc(["-b", "2:4"], "héllo\n".encode())
        self.assertEqual(result.returncode, 0)
        self.assertEqual(result.stdout, "él".encode())

        result = run_tuc(["-c", "2:4"], "héllo\n".encode())
        self.assertEqual(result.returncode, 0)
        self.assertEqual(result.stdout, "éll\n".encode())
