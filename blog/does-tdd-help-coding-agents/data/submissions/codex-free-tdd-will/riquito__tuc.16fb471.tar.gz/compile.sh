#!/bin/bash
set -e
cp src/tuc.py executable
chmod +x executable
