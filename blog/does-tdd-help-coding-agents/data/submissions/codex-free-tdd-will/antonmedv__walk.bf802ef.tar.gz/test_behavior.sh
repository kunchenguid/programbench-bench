#!/bin/bash
set -euo pipefail

go build -o /tmp/walk-test ./src

out=$(/tmp/walk-test --help)
expected=$(cat <<'EOF'

  walk v1.13.0

  Usage: walk [path]

    arrows, hjkl  Move cursor
    enter         Enter directory
    backspace     Exit directory
    space         Toggle preview
    esc, q        Exit with cd
    ctrl+c        Exit without cd
    /             Fuzzy search
    d, delete     Delete file or dir
    y             Copy to clipboard
    .             Hide hidden files
    ?             Show help

  Flags:

    --icons        display icons
    --dir-only     show dirs only
    --hide-hidden  hide hidden files
    --preview      display preview
    --with-border  preview with border
    --fuzzy        fuzzy mode
EOF
)

if [[ "$out" != "$expected" ]]; then
  echo "help output mismatch"
  diff -u <(printf '%s\n' "$expected") <(printf '%s\n' "$out")
  exit 1
fi

version=$(/tmp/walk-test --version)
if [[ "$version" != "v1.13.0" ]]; then
  echo "version output mismatch: $version"
  exit 1
fi
short_version=$(/tmp/walk-test -v)
if [[ "$short_version" != "v1.13.0" ]]; then
  echo "short version output mismatch: $short_version"
  exit 1
fi

set +e
short_help=$(/tmp/walk-test -h)
short_help_code=$?
set -e
if [[ "$short_help_code" -ne 1 ]] || [[ "$short_help" != "$expected" ]]; then
  echo "short help mismatch"
  echo "code=$short_help_code"
  exit 1
fi

set +e
/tmp/walk-test > /tmp/walk-out 2> /tmp/walk-err
code=$?
set -e
if [[ "$code" -ne 2 ]] || ! grep -q "panic: could not open a new TTY: open /dev/tty: no such device or address" /tmp/walk-err; then
  echo "non-tty launch mismatch"
  echo "code=$code"
  cat /tmp/walk-out
  cat /tmp/walk-err
  exit 1
fi

rm -rf /tmp/walk-fixture
mkdir -p /tmp/walk-fixture/alpha /tmp/walk-fixture/beta
mkdir -p /tmp/walk-fixture/.hidden
printf 'hello\n' > /tmp/walk-fixture/readme.txt
printf '\033]11;rgb:0000/0000/0000\007\033[24;80Rq' |
  timeout 3 script -q -c "/tmp/walk-test /tmp/walk-fixture; echo CODE:\$?" /tmp/walk-script >/tmp/walk-pty 2>/tmp/walk-pty-err
if ! grep -q "/tmp/walk-fixture" /tmp/walk-pty || ! grep -q "CODE:0" /tmp/walk-pty; then
  echo "interactive quit output mismatch"
  cat -vet /tmp/walk-pty
  cat -vet /tmp/walk-pty-err
  exit 1
fi

printf 'j\nq' |
  timeout 3 script -q -c "/tmp/walk-test /tmp/walk-fixture; echo CODE:\$?" /tmp/walk-script >/tmp/walk-pty 2>/tmp/walk-pty-err
if ! grep -q "/tmp/walk-fixture/alpha" /tmp/walk-pty || ! grep -q "CODE:0" /tmp/walk-pty; then
  echo "interactive enter-directory output mismatch"
  cat -vet /tmp/walk-pty
  cat -vet /tmp/walk-pty-err
  exit 1
fi

printf 'q' |
  timeout 3 script -q -c "/tmp/walk-test --hide-hidden /tmp/walk-fixture; echo CODE:\$?" /tmp/walk-script >/tmp/walk-pty 2>/tmp/walk-pty-err
if grep -q "\.hidden" /tmp/walk-pty; then
  echo "hide-hidden rendered hidden entries"
  cat -vet /tmp/walk-pty
  exit 1
fi
