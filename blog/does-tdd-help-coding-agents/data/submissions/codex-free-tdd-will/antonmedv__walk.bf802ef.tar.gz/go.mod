module rewalk

go 1.21
