package main

import (
	"bufio"
	"fmt"
	"os"
	"path/filepath"
	"sort"
	"strings"
	"syscall"
	"unsafe"
)

const version = "v1.13.0"

const helpText = `
  walk v1.13.0

  Usage: walk [path]

    arrows, hjkl  Move cursor
    enter         Enter directory
    backspace     Exit directory
    space         Toggle preview
    esc, q        Exit with cd
    ctrl+c        Exit without cd
    /             Fuzzy search
    d, delete     Delete file or dir
    y             Copy to clipboard
    .             Hide hidden files
    ?             Show help

  Flags:

    --icons        display icons
    --dir-only     show dirs only
    --hide-hidden  hide hidden files
    --preview      display preview
    --with-border  preview with border
    --fuzzy        fuzzy mode
`

func main() {
	for _, arg := range os.Args[1:] {
		switch arg {
		case "--help":
			fmt.Print(helpText)
			return
		case "-h":
			fmt.Print(helpText)
			os.Exit(1)
		case "--version", "-v":
			fmt.Println(version)
			return
		}
	}

	start := "."
	for _, arg := range os.Args[1:] {
		if !strings.HasPrefix(arg, "-") {
			start = arg
			break
		}
	}
	root, err := filepath.Abs(start)
	if err != nil {
		panic(err)
	}

	tty, err := os.OpenFile("/dev/tty", os.O_RDWR, 0)
	if err != nil {
		panic(fmt.Errorf("could not open a new TTY: %w", err))
	}
	defer tty.Close()

	restore, _ := makeRaw(tty)
	defer restore()

	dirOnly := hasFlag("--dir-only")
	hideHidden := hasFlag("--hide-hidden")
	run(tty, root, dirOnly, hideHidden)
}

func hasFlag(flag string) bool {
	for _, arg := range os.Args[1:] {
		if arg == flag {
			return true
		}
	}
	return false
}

func run(tty *os.File, dir string, dirOnly, hideHidden bool) {
	selected := 0
	entries := render(tty, dir, dirOnly, hideHidden, selected)
	reader := bufio.NewReader(tty)
	for {
		b, err := reader.ReadByte()
		if err != nil {
			return
		}
		switch b {
		case 'q', 27:
			if b == 27 && reader.Buffered() > 0 {
				key := readEscape(reader)
				switch key {
				case "down":
					if selected+1 < len(entries) {
						selected++
						entries = render(tty, dir, dirOnly, hideHidden, selected)
					}
				case "up":
					if selected > 0 {
						selected--
						entries = render(tty, dir, dirOnly, hideHidden, selected)
					}
				case "left":
					dir, selected, entries = goUp(tty, dir, dirOnly, hideHidden)
				case "right":
					dir, selected, entries = enterSelected(tty, dir, entries, selected, dirOnly, hideHidden)
				}
				continue
			}
			fmt.Fprint(tty, "\x1b[?2004l\x1b[?25h")
			fmt.Println(dir)
			return
		case 3:
			fmt.Fprint(tty, "\x1b[?2004l\x1b[?25h")
			return
		case 'j':
			if selected+1 < len(entries) {
				selected++
				entries = render(tty, dir, dirOnly, hideHidden, selected)
			}
		case 'k':
			if selected > 0 {
				selected--
				entries = render(tty, dir, dirOnly, hideHidden, selected)
			}
		case 'l', '\r', '\n':
			dir, selected, entries = enterSelected(tty, dir, entries, selected, dirOnly, hideHidden)
		case 'h':
			dir, selected, entries = goUp(tty, dir, dirOnly, hideHidden)
		case 127, 8:
			dir, selected, entries = goUp(tty, dir, dirOnly, hideHidden)
		case '.':
			hideHidden = !hideHidden
			selected = 0
			entries = render(tty, dir, dirOnly, hideHidden, selected)
		}
	}
}

func enterSelected(tty *os.File, dir string, entries []os.DirEntry, selected int, dirOnly, hideHidden bool) (string, int, []os.DirEntry) {
	if len(entries) == 0 {
		return dir, selected, entries
	}
	entry := entries[selected]
	if entry.IsDir() {
		dir = filepath.Join(dir, entry.Name())
		selected = 0
		entries = render(tty, dir, dirOnly, hideHidden, selected)
	}
	return dir, selected, entries
}

func goUp(tty *os.File, dir string, dirOnly, hideHidden bool) (string, int, []os.DirEntry) {
	parent := filepath.Dir(dir)
	if parent == dir {
		return dir, 0, render(tty, dir, dirOnly, hideHidden, 0)
	}
	return parent, 0, render(tty, parent, dirOnly, hideHidden, 0)
}

func readEscape(reader *bufio.Reader) string {
	next, _ := reader.ReadByte()
	if next != '[' && next != 'O' {
		return ""
	}
	code, _ := reader.ReadByte()
	switch code {
	case 'A':
		return "up"
	case 'B':
		return "down"
	case 'C':
		return "right"
	case 'D':
		return "left"
	case 'H':
		return "home"
	case 'F':
		return "end"
	}
	return ""
}

func render(tty *os.File, dir string, dirOnly, hideHidden bool, selected int) []os.DirEntry {
	fmt.Fprint(tty, "\x1b[?25l\x1b[?2004h\r\x1b[2J\x1b[H")
	fmt.Fprintln(tty, dir)
	all, _ := os.ReadDir(dir)
	entries := make([]os.DirEntry, 0, len(all))
	for _, entry := range all {
		if hideHidden && strings.HasPrefix(entry.Name(), ".") {
			continue
		}
		if dirOnly && !entry.IsDir() {
			continue
		}
		entries = append(entries, entry)
	}
	sort.Slice(entries, func(i, j int) bool {
		return strings.ToLower(entries[i].Name()) < strings.ToLower(entries[j].Name())
	})
	for i, entry := range entries {
		name := entry.Name()
		if entry.IsDir() {
			name += "/"
		}
		if i == selected {
			name = "> " + name
		} else {
			name = "  " + name
		}
		fmt.Fprintln(tty, name)
	}
	return entries
}

func makeRaw(file *os.File) (func(), error) {
	fd := int(file.Fd())
	var old syscall.Termios
	if _, _, errno := syscall.Syscall(syscall.SYS_IOCTL, uintptr(fd), uintptr(syscall.TCGETS), uintptr(unsafe.Pointer(&old))); errno != 0 {
		return func() {}, errno
	}
	raw := old
	raw.Iflag &^= syscall.BRKINT | syscall.ICRNL | syscall.INPCK | syscall.ISTRIP | syscall.IXON
	raw.Oflag &^= syscall.OPOST
	raw.Cflag |= syscall.CS8
	raw.Lflag &^= syscall.ECHO | syscall.ICANON | syscall.IEXTEN | syscall.ISIG
	raw.Cc[syscall.VMIN] = 1
	raw.Cc[syscall.VTIME] = 0
	if _, _, errno := syscall.Syscall(syscall.SYS_IOCTL, uintptr(fd), uintptr(syscall.TCSETS), uintptr(unsafe.Pointer(&raw))); errno != 0 {
		return func() {}, errno
	}
	return func() {
		syscall.Syscall(syscall.SYS_IOCTL, uintptr(fd), uintptr(syscall.TCSETS), uintptr(unsafe.Pointer(&old)))
	}, nil
}
