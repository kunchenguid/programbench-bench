#!/usr/bin/env python3
import sys
import os
import re
import json
from dataclasses import dataclass


VERSION_TEXT = """Universal Ctags 6.2.0(d922013), Copyright (C) 2015-2025 Universal Ctags Team
Universal Ctags is derived from Exuberant Ctags.
Exuberant Ctags 5.8, Copyright (C) 1996-2009 Darren Hiebert
  Compiled: Apr 20 2026, 16:52:56
  URL: https://ctags.io/
  Output version: 1.1
  Optional compiled features: +wildcards, +regex, +iconv, +option-directory, +xpath, +json, +interactive, +sandbox, +yaml, +packcc, +optscript
"""

HELP_TEXT = VERSION_TEXT + """
Usage: executable [options] [file(s)]

Input/Output Options
  --exclude=<pattern>
       Exclude files and directories matching <pattern>.
  --filter[=(yes|no)]
       Behave as a filter, reading file names from standard input and
       writing tags to standard output [no].
  --filter-terminator=<string>
       Specify <string> to print to stdout following the tags for each file
       parsed when --filter is enabled.
  --recurse[=(yes|no)]
       Recurse into directories supplied on command line [no].
  -R   Equivalent to --recurse.
  -L <file>
       A list of input file names is read from the specified <file>.
  --append[=(yes|no)]
       Should tags should be appended to existing tag file [no]?
  -a   Append the tags to an existing tag file.
  -f <tagfile>
       Write tags to specified <tagfile>. Value of "-" writes tags to stdout
       ["tags"; or "TAGS" when -e supplied].
  -o   Alternative for -f.

Output Format Options
  --format=(1|2)
       Force output of specified tag file format [2].
  --output-format=(u-ctags|e-ctags|etags|xref|json)
      Specify the output format. [u-ctags]
  -e   Output tag file for use with Emacs.
  -x   Print a tabular cross reference file to standard output.
  --sort=(yes|no|foldcase)
       Should tags be sorted (optionally ignoring case) [yes]?
  -u   Equivalent to --sort=no.

Language Selection and Mapping Options
  --language-force=(<language>|auto)
       Force all files to be interpreted using specified <language>.
  --languages=[+|-](<list>|all)
       Restrict files scanned for tags to those mapped to languages
       specified in the comma-separated <list>. The list can contain any
       built-in or user-defined language [all].

Tags File Contents Options
  --excmd=(number|pattern|mix|combine)
       Uses the specified type of EX command to locate tags [mix].
  -n   Equivalent to --excmd=number.
  -N   Equivalent to --excmd=pattern.
  --extras=[+|-][<flags>|*]
       Include extra tag entries for selected information (<flags>: "fFgpqrs") [F].
  --fields=[+|-][<flags>|*]
       Include selected extension fields (<flags>: "aCeEfFikKlmnNpPrRsStxzZ") [fks].

Listing Options
  --list-features
       Output list of compiled features.
  --list-kinds[=(<language>|all)]
       Output a list of all tag kinds for specified <language> or all.
  --list-languages
       Output list of supported languages.
  --list-output-formats
       Output list of output formats.

Miscellaneous Options
  --help
       Print this option summary.
  -?   Print this option summary.
  --license
       Print details of software license.
  --print-language
       Don't make tags file but just print the guessed language name for
       input file.
  --quiet[=(yes|no)]
       Don't print NOTICE class messages [no].
  --totals[=(yes|no|extra)]
       Print statistics about input and tag files [no].
  --verbose[=(yes|no)]
       Enable verbose messages describing actions on each input file.
  --version[=<language>]
       Print version identifier of the program to standard output.
  -V   Equivalent to --verbose.
"""

LANGUAGES = """Abaqus
Abc
Ada
AnsiblePlaybook
Ant
Asciidoc
Asm
Asp
Autoconf
AutoIt
Automake
Awk
Basic
Bats
BETA
BibLaTeX
BibTeX
C
C#
C++
Cargo [disabled]
Clojure
CMake
Cobol
CobolFree
CobolVariable
CPreProcessor
CSS
Ctags
CUDA
D
DBusIntrospect
DBusService
Diff
DosBatch
DTD
DTS
Eiffel
Elixir
Elm
EmacsLisp
Erlang
Falcon
Flex
Forth
Fortran
FrontMatter
FunctionParameters
Fypp
Gdbinit
GDScript
GemSpec
Glade
Go
GoMod
GPerf
Haskell
Haxe
HTML
I18nRubyGem
Iniconf
Inko
IPythonCell
ITcl
Java
JavaProperties
JavaScript
JNI
JSON
Julia
Kconfig
Kotlin
LdScript
LEX
Lisp
LiterateHaskell
Lua
M4
Make
Man
Markdown
MatLab
Maven2
Meson
MesonOptions
Moose
Myrddin
Nftables
NSIS
ObjectiveC
OCaml
Odin
OpenAPI
Org
Pascal
Passwd
Perl
Perl6
PHP
PkgConfig
PlistXML
Pod
PowerShell
Prolog
Protobuf
PuppetManifest
Python
PythonEntryPoints
PythonLoggingConfig
QemuHX
QtMoc
Quarto
R
R6Class
Rake
Raku
RelaxNG
ReStructuredText
REXX
RMarkdown
Robot
RpmMacros
RpmSpec
RSpec
Ruby
Rust
S4Class
Scdoc
Scheme
SCSS
SELinuxInterface
SELinuxTypeEnforcement
Sh
SINEX
SLang
SML
SQL
SVG
SystemdUnit
SystemTap
SystemVerilog
Tcl
TclOO
Terraform
TerraformVariables
Tex
TeXBeamer
Thrift
TOML [disabled]
TTCN
Txt2tags
TypeScript
TypeSpec
Unknown [disabled]
V
Varlink
Vera
Verilog
VHDL
Vim
WindRes
XML
XRC
XSLT
YACC
Yaml
YumRepo
Zephir
Zsh
"""

FEATURES = """#NAME             DESCRIPTION
iconv             can convert input/output encodings
interactive       accepts source code from stdin
json              supports json format output
option-directory  TO BE WRITTEN
optscript         can use the interpreter
packcc            has peg based parser(s)
regex             can use regular expression based pattern matching
sandbox           linked with code for system call level sandbox
wildcards         can use glob matching
xpath             linked with library for parsing xml input
yaml              linked with library for parsing yaml input
"""

LICENSE_TEXT = VERSION_TEXT + """
This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2of the License, or (at your option) any later version.


This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Place - Suite 330, Boston, MA  02111-1307, USA.
"""

KINDS = {
    "Python": """c  classes
f  functions
m  class members
v  variables
I  name referring a module defined in other file
i  modules
Y  name referring a class/variable/function/module defined in other module
z  function parameters [off]
l  local variables [off]
""",
    "C": """d  macro definitions
e  enumerators (values inside an enumeration)
f  function definitions
g  enumeration names
m  struct, and union members
s  structure names
t  typedefs
u  union names
v  variable definitions
""",
    "JavaScript": """C  constants
c  classes
f  functions
m  methods
v  variables
""",
}


@dataclass
class Tag:
    name: str
    path: str
    pattern: str
    kind: str
    line_no: int
    line: str
    scope_kind: str = ""
    scope: str = ""
    extra: tuple = ()


def detect_language(path):
    ext = os.path.splitext(path)[1].lower()
    base = os.path.basename(path)
    if ext in (".py", ".pyw"):
        return "Python"
    if ext in (".c", ".h"):
        return "C"
    if ext in (".cc", ".cpp", ".cxx", ".hpp", ".hh", ".hxx"):
        return "C++"
    if ext in (".js", ".mjs", ".cjs"):
        return "JavaScript"
    if ext in (".ts", ".tsx"):
        return "TypeScript"
    if ext == ".java":
        return "Java"
    if ext == ".go":
        return "Go"
    if ext == ".rs":
        return "Rust"
    if ext == ".rb":
        return "Ruby"
    if ext == ".php":
        return "PHP"
    if ext in (".sh", ".bash", ".zsh"):
        return "Sh"
    if ext in (".css", ".scss"):
        return "CSS"
    if ext in (".html", ".htm"):
        return "HTML"
    if ext in (".md", ".markdown") or base.upper() == "README":
        return "Markdown"
    return "Unknown"


def make_pattern(line, end=True):
    suffix = "$" if end else ""
    return "/^" + line.replace("\\", "\\\\").replace("/", "\\/") + suffix + "/"


def parse_python(path, text):
    tags = []
    class_stack = []
    for idx, raw in enumerate(text.splitlines(), 1):
        line = raw.rstrip("\n")
        stripped = line.strip()
        if not stripped or stripped.startswith("#"):
            continue
        indent = len(line) - len(line.lstrip(" "))
        while class_stack and indent <= class_stack[-1][0]:
            class_stack.pop()
        m = re.match(r"^(\s*)class\s+([A-Za-z_][\w]*)\b.*:\s*$", line)
        if m:
            name = m.group(2)
            tags.append(Tag(name, path, make_pattern(line), "c", idx, line))
            class_stack.append((indent, name))
            continue
        m = re.match(r"^(\s*)def\s+([A-Za-z_][\w]*)\s*\(", line)
        if m:
            name = m.group(2)
            if class_stack and indent > class_stack[-1][0]:
                tags.append(Tag(name, path, make_pattern(line), "m", idx, line, "class", class_stack[-1][1]))
            else:
                tags.append(Tag(name, path, make_pattern(line), "f", idx, line))
            continue
        m = re.match(r"^([A-Z_][A-Z0-9_]*)\s*=", line)
        if m and indent == 0:
            tags.append(Tag(m.group(1), path, make_pattern(line), "v", idx, line))
    return tags


TYPE_WORDS = {
    "void", "char", "short", "int", "long", "float", "double", "signed", "unsigned",
    "bool", "_Bool", "size_t", "ssize_t", "FILE",
}


def clean_c_type(type_text):
    words = [w for w in re.split(r"\s+", type_text.replace("*", " ").strip()) if w]
    words = [w for w in words if w not in ("static", "extern", "inline", "const", "volatile", "register")]
    return " ".join(words) if words else "int"


def parse_c_like(path, text):
    tags = []
    lines = text.splitlines()
    for idx, line in enumerate(lines, 1):
        stripped = line.strip()
        if not stripped or stripped.startswith("//") or stripped.startswith("/*"):
            continue
        m = re.match(r"^\s*#\s*define\s+([A-Za-z_]\w*)\b", line)
        if m:
            name = m.group(1)
            pat_line = re.sub(r"(\b" + re.escape(name) + r")\b.*", r"\1 ", line.rstrip())
            tags.append(Tag(name, path, make_pattern(pat_line, end=False), "d", idx, line.rstrip(), extra=("file:",)))
            continue
        m = re.match(r"^\s*typedef\s+struct\s+([A-Za-z_]\w*)\s+([A-Za-z_]\w*)\s*;", line)
        if m:
            tags.append(Tag(m.group(2), path, make_pattern(line.rstrip()), "t", idx, line.rstrip(), extra=(f"typeref:struct:{m.group(1)}", "file:")))
            continue
        m = re.match(r"^\s*struct\s+([A-Za-z_]\w*)\s*\{(.*)\}\s*;", line)
        if m:
            struct_name, body = m.group(1), m.group(2)
            tags.append(Tag(struct_name, path, make_pattern(line.rstrip()), "s", idx, line.rstrip(), extra=("file:",)))
            for member_type, member_name in re.findall(r"\b([A-Za-z_]\w*)\s+([A-Za-z_]\w*)\s*;", body):
                tags.append(Tag(member_name, path, make_pattern(line.rstrip()), "m", idx, line.rstrip(), "struct", struct_name, (f"typeref:typename:{member_type}", "file:")))
            continue
        m = re.match(r"^\s*enum\s+([A-Za-z_]\w*)\s*\{([^}]*)\}\s*;", line)
        if m:
            enum_name, body = m.group(1), m.group(2)
            tags.append(Tag(enum_name, path, make_pattern(line.rstrip()), "g", idx, line.rstrip(), extra=("file:",)))
            for item in body.split(","):
                enum_const = item.strip().split("=")[0].strip()
                if re.match(r"^[A-Za-z_]\w*$", enum_const):
                    tags.append(Tag(enum_const, path, make_pattern(line.rstrip()), "e", idx, line.rstrip(), "enum", enum_name, ("file:",)))
            continue
        m = re.match(r"^\s*((?:(?:static|extern|inline|const|volatile|unsigned|signed|long|short|struct\s+\w+|enum\s+\w+|[A-Za-z_]\w*|\*)\s+)+?)([A-Za-z_]\w*)\s*\([^;]*\)\s*(?:\{|$)", line)
        if m:
            type_name = clean_c_type(m.group(1))
            name = m.group(2)
            extra = [f"typeref:typename:{type_name}"]
            if "static" in m.group(1).split():
                extra.append("file:")
            tags.append(Tag(name, path, make_pattern(line.rstrip()), "f", idx, line.rstrip(), extra=tuple(extra)))
            continue
        m = re.match(r"^\s*((?:(?:static|extern|const|volatile|unsigned|signed|long|short|struct\s+\w+|enum\s+\w+|[A-Za-z_]\w*|\*)\s+)+?)([A-Za-z_]\w*)\s*(?:=[^;]*)?;", line)
        if m and "(" not in line:
            type_name = clean_c_type(m.group(1))
            name = m.group(2)
            extra = [f"typeref:typename:{type_name}"]
            if "static" in m.group(1).split():
                extra.append("file:")
            tags.append(Tag(name, path, make_pattern(line.rstrip()), "v", idx, line.rstrip(), extra=tuple(extra)))
    return tags


def parse_javascript(path, text):
    tags = []
    class_stack = []
    brace_depth = 0
    for idx, line in enumerate(text.splitlines(), 1):
        stripped = line.strip()
        if not stripped or stripped.startswith("//"):
            brace_depth += line.count("{") - line.count("}")
            continue
        while class_stack and brace_depth < class_stack[-1][0]:
            class_stack.pop()
        m = re.match(r"^\s*class\s+([A-Za-z_$][\w$]*)\b", line)
        if m:
            tags.append(Tag(m.group(1), path, make_pattern(line.rstrip()), "c", idx, line.rstrip()))
            class_stack.append((brace_depth + line.count("{") - line.count("}"), m.group(1)))
        m = re.match(r"^\s*function\s+([A-Za-z_$][\w$]*)\s*\(", line)
        if m:
            tags.append(Tag(m.group(1), path, make_pattern(line.rstrip()), "f", idx, line.rstrip()))
        m = re.match(r"^\s*(?:const|let|var)\s+([A-Za-z_$][\w$]*)\s*=\s*(.*?);?\s*$", line)
        if m:
            kind = "f" if "=>" in m.group(2) or re.match(r"(?:async\s*)?function\b", m.group(2).strip()) else "C"
            tags.append(Tag(m.group(1), path, make_pattern(line.rstrip()), kind, idx, line.rstrip()))
        if class_stack and not stripped.startswith(("class ", "function ", "const ", "let ", "var ")):
            m = re.match(r"^\s*([A-Za-z_$][\w$]*)\s*\([^)]*\)\s*\{", line)
            if m and m.group(1) not in ("if", "for", "while", "switch", "catch"):
                tags.append(Tag(m.group(1), path, make_pattern(line.rstrip()), "m", idx, line.rstrip(), "class", class_stack[-1][1]))
        brace_depth += line.count("{") - line.count("}")
    return tags


def parse_go(path, text):
    tags, package = [], ""
    for idx, line in enumerate(text.splitlines(), 1):
        s = line.strip()
        if m := re.match(r"package\s+([A-Za-z_]\w*)", s):
            package = m.group(1)
            tags.append(Tag(package, path, make_pattern(line.rstrip()), "p", idx, line.rstrip()))
        elif m := re.match(r"const\s+([A-Za-z_]\w*)\b", s):
            tags.append(Tag(m.group(1), path, make_pattern(line.rstrip()), "c", idx, line.rstrip(), "package", package))
        elif m := re.match(r"var\s+([A-Za-z_]\w*)\s+([A-Za-z_]\w*)", s):
            tags.append(Tag(m.group(1), path, make_pattern(line.rstrip()), "v", idx, line.rstrip(), "package", package, (f"typeref:typename:{m.group(2)}",)))
        elif m := re.match(r"type\s+([A-Za-z_]\w*)\s+struct\s*\{(.*)\}", s):
            name, body = m.group(1), m.group(2)
            tags.append(Tag(name, path, make_pattern(line.rstrip()), "s", idx, line.rstrip(), "package", package))
            for ftype in re.findall(r"\b([A-Z][A-Za-z_]\w*)\s+([A-Za-z_]\w*)", body):
                tags.append(Tag(ftype[0], path, make_pattern(line.rstrip()), "m", idx, line.rstrip(), "struct", f"{package}.{name}", (f"typeref:typename:{ftype[1]}",)))
        elif m := re.match(r"func\s+\([^)]*\s+([A-Za-z_]\w*)\)\s+([A-Za-z_]\w*)\([^)]*\)\s*([A-Za-z_]\w*)?", s):
            recv, name, ret = m.group(1), m.group(2), m.group(3) or ""
            extra = (f"typeref:typename:{ret}",) if ret else ()
            tags.append(Tag(name, path, make_pattern(line.rstrip()), "f", idx, line.rstrip(), "struct", f"{package}.{recv}", extra))
        elif m := re.match(r"func\s+([A-Za-z_]\w*)\([^)]*\)\s*([A-Za-z_]\w*)?", s):
            name, ret = m.group(1), m.group(2) or ""
            extra = (f"typeref:typename:{ret}",) if ret else ()
            tags.append(Tag(name, path, make_pattern(line.rstrip()), "f", idx, line.rstrip(), "package", package, extra))
    return tags


def parse_rust(path, text):
    tags = []
    for idx, line in enumerate(text.splitlines(), 1):
        s = line.strip()
        prefix = r"(?:pub\s+)?"
        if m := re.match(prefix + r"struct\s+([A-Za-z_]\w*)\s*(?:\{(.*)\})?", s):
            name, body = m.group(1), m.group(2) or ""
            tags.append(Tag(name, path, make_pattern(line.rstrip()), "s", idx, line.rstrip()))
            for fname, ftype in re.findall(r"\b([a-zA-Z_]\w*)\s*:\s*([A-Za-z_]\w*)", body):
                tags.append(Tag(fname, path, make_pattern(line.rstrip()), "m", idx, line.rstrip(), "struct", name))
        elif m := re.match(prefix + r"enum\s+([A-Za-z_]\w*)\s*\{([^}]*)\}", s):
            name = m.group(1)
            tags.append(Tag(name, path, make_pattern(line.rstrip()), "g", idx, line.rstrip()))
            for item in m.group(2).split(","):
                item = item.strip()
                if re.match(r"^[A-Za-z_]\w*$", item):
                    tags.append(Tag(item, path, make_pattern(line.rstrip()), "e", idx, line.rstrip(), "enum", name))
        elif m := re.match(prefix + r"const\s+([A-Za-z_]\w*)\b", s):
            tags.append(Tag(m.group(1), path, make_pattern(line.rstrip()), "C", idx, line.rstrip()))
        elif m := re.match(prefix + r"fn\s+([A-Za-z_]\w*)\s*\(", s):
            tags.append(Tag(m.group(1), path, make_pattern(line.rstrip()), "f", idx, line.rstrip()))
    return tags


def parse_java(path, text):
    tags, current_class = [], ""
    for idx, line in enumerate(text.splitlines(), 1):
        s = line.strip()
        if m := re.match(r"package\s+([\w.]+)\s*;", s):
            tags.append(Tag(m.group(1), path, make_pattern(line.rstrip()), "p", idx, line.rstrip()))
        elif m := re.search(r"\b(class|interface|enum)\s+([A-Za-z_]\w*)", s):
            current_class = m.group(2)
            tags.append(Tag(current_class, path, make_pattern(line.rstrip()), "c", idx, line.rstrip()))
        elif current_class and (m := re.match(r"(?:public|private|protected|static|final|\s)+\s*[\w<>\[\]]+\s+([A-Za-z_]\w*)\s*\(", s)):
            tags.append(Tag(m.group(1), path, make_pattern(line.rstrip()), "m", idx, line.rstrip(), "class", current_class))
    return tags


def parse_ruby(path, text):
    tags, classes = [], []
    for idx, line in enumerate(text.splitlines(), 1):
        s = line.strip()
        if m := re.match(r"class\s+([A-Za-z_]\w*)", s):
            classes.append(m.group(1))
            tags.append(Tag(m.group(1), path, make_pattern(line.rstrip()), "c", idx, line.rstrip()))
        elif s == "end" and classes:
            classes.pop()
        elif m := re.match(r"def\s+([A-Za-z_]\w*[!?=]?)", s):
            scope = classes[-1] if classes else ""
            tags.append(Tag(m.group(1), path, make_pattern(line.rstrip()), "f", idx, line.rstrip(), "class" if scope else "", scope))
        elif m := re.match(r"([A-Z][A-Z0-9_]*)\s*=", s):
            tags.append(Tag(m.group(1), path, make_pattern(line.rstrip()), "C", idx, line.rstrip()))
    return tags


def parse_php(path, text):
    tags = []
    for idx, line in enumerate(text.splitlines(), 1):
        s = line.strip()
        if m := re.search(r"\bclass\s+([A-Za-z_]\w*)", s):
            cls = m.group(1)
            tags.append(Tag(cls, path, make_pattern(line.rstrip()), "c", idx, line.rstrip()))
            for fn in re.findall(r"\bfunction\s+([A-Za-z_]\w*)\s*\(", s):
                tags.append(Tag(fn, path, make_pattern(line.rstrip()), "f", idx, line.rstrip(), "class", cls))
        elif m := re.search(r"\bfunction\s+([A-Za-z_]\w*)\s*\(", s):
            tags.append(Tag(m.group(1), path, make_pattern(line.rstrip()), "f", idx, line.rstrip()))
        elif m := re.match(r"\$([A-Za-z_]\w*)\s*=", s):
            tags.append(Tag(m.group(1), path, make_pattern(line.rstrip()), "v", idx, line.rstrip()))
    return tags


def parse_shell(path, text):
    tags = []
    for idx, line in enumerate(text.splitlines(), 1):
        if m := re.match(r"\s*([A-Za-z_]\w*)\s*\(\)\s*\{", line):
            tags.append(Tag(m.group(1), path, make_pattern(line.rstrip()), "f", idx, line.rstrip()))
        elif m := re.match(r"\s*function\s+([A-Za-z_]\w*)\b", line):
            tags.append(Tag(m.group(1), path, make_pattern(line.rstrip()), "f", idx, line.rstrip()))
    return tags


def parse_css(path, text):
    tags = []
    for idx, line in enumerate(text.splitlines(), 1):
        selector_part = line.split("{", 1)[0]
        for selector in selector_part.split(","):
            selector = selector.strip()
            if re.match(r"^#[A-Za-z_][\w-]*$", selector):
                tags.append(Tag(selector, path, make_pattern(line.rstrip()), "i", idx, line.rstrip()))
            elif re.match(r"^\.[A-Za-z_][\w-]*$", selector):
                tags.append(Tag(selector, path, make_pattern(line.rstrip()), "c", idx, line.rstrip()))
    return tags


def parse_file(path):
    try:
        with open(path, "r", encoding="utf-8", errors="replace") as f:
            text = f.read()
    except OSError as e:
        sys.stderr.write(f'executable: Warning: cannot open input file "{path}" : {e.strerror}\n')
        return []
    lang = detect_language(path)
    if lang == "Python":
        return parse_python(path, text)
    if lang in ("C", "C++"):
        return parse_c_like(path, text)
    if lang in ("JavaScript", "TypeScript"):
        return parse_javascript(path, text)
    if lang == "Go":
        return parse_go(path, text)
    if lang == "Rust":
        return parse_rust(path, text)
    if lang == "Java":
        return parse_java(path, text)
    if lang == "Ruby":
        return parse_ruby(path, text)
    if lang == "PHP":
        return parse_php(path, text)
    if lang == "Sh":
        return parse_shell(path, text)
    if lang == "CSS":
        return parse_css(path, text)
    return []


def format_tag(tag):
    fields = [tag.name, tag.path, tag.pattern + ';"', tag.kind]
    if tag.scope_kind and tag.scope:
        fields.append(f"{tag.scope_kind}:{tag.scope}")
    fields.extend(tag.extra)
    return "\t".join(fields) + "\n"


KIND_NAMES = {
    "c": "class",
    "C": "constant",
    "d": "macro",
    "e": "enumerator",
    "f": "function",
    "g": "enum",
    "m": "member",
    "s": "struct",
    "t": "typedef",
    "v": "variable",
}


def format_json(tag):
    obj = {
        "_type": "tag",
        "name": tag.name,
        "path": tag.path,
        "pattern": tag.pattern,
        "kind": KIND_NAMES.get(tag.kind, tag.kind),
    }
    if tag.scope_kind and tag.scope:
        obj["scope"] = tag.scope
        obj["scopeKind"] = tag.scope_kind
    return json.dumps(obj, separators=(", ", ": ")) + "\n"


def format_xref(tag):
    kind = KIND_NAMES.get(tag.kind, tag.kind)
    return f"{tag.name:<16} {kind:<11} {tag.line_no:4d} {tag.path:<15} {tag.line}\n"


def render_tags(tags, output_format):
    tags = sorted(tags, key=lambda t: t.name)
    if output_format == "json":
        return "".join(format_json(t) for t in tags)
    if output_format == "xref":
        return "".join(format_xref(t) for t in tags)
    return "".join(format_tag(t) for t in tags)


def parse_args(argv):
    files = []
    out = "tags"
    to_stdout = False
    output_format = "u-ctags"
    filter_mode = False
    filter_terminator = ""
    print_language = False
    i = 0
    while i < len(argv):
        arg = argv[i]
        if arg == "-f" or arg == "-o":
            i += 1
            out = argv[i] if i < len(argv) else "tags"
            to_stdout = out == "-"
        elif arg == "-L":
            i += 1
            list_path = argv[i] if i < len(argv) else ""
            try:
                source = sys.stdin if list_path == "-" else open(list_path, "r", encoding="utf-8", errors="replace")
                with source:
                    for name in source:
                        name = name.strip()
                        if name:
                            files.append(name)
            except OSError as e:
                sys.stderr.write(f'executable: Warning: cannot open input file "{list_path}" : {e.strerror}\n')
        elif arg.startswith("-f") and len(arg) > 2:
            out = arg[2:]
            to_stdout = out == "-"
        elif arg == "-x":
            to_stdout = True
            output_format = "xref"
        elif arg.startswith("--output-format="):
            output_format = arg.split("=", 1)[1]
            if output_format in ("json", "xref"):
                to_stdout = True
        elif arg == "--print-language":
            print_language = True
            to_stdout = True
        elif arg.startswith("--filter-terminator="):
            filter_terminator = arg.split("=", 1)[1]
        elif arg.startswith("--filter"):
            value = "yes"
            if "=" in arg:
                value = arg.split("=", 1)[1]
            filter_mode = value not in ("no", "false", "0")
            to_stdout = True
        elif arg.startswith("-"):
            pass
        else:
            files.append(arg)
        i += 1
    return files, out, to_stdout, output_format, filter_mode, filter_terminator, print_language


def main(argv):
    if "--version" in argv or any(a.startswith("--version=") for a in argv):
        sys.stdout.write(VERSION_TEXT)
        return 0
    if "--help" in argv or "-?" in argv or "--help-full" in argv:
        sys.stdout.write(HELP_TEXT)
        return 0
    if "--list-languages" in argv:
        sys.stdout.write(LANGUAGES)
        return 0
    if "--list-features" in argv:
        sys.stdout.write(FEATURES)
        return 0
    if "--license" in argv:
        sys.stdout.write(LICENSE_TEXT)
        return 0
    for arg in argv:
        if arg.startswith("--list-kinds"):
            lang = "all"
            if "=" in arg:
                lang = arg.split("=", 1)[1]
            sys.stdout.write(KINDS.get(lang, ""))
            return 0
    if "--list-output-formats" in argv:
        sys.stdout.write("""#OFORMAT DEFAULT AVAILABLE NULLTAG 
e-ctags       no       yes      no 
etags         no       yes      no 
json          no       yes     yes 
u-ctags      yes       yes      no 
xref          no       yes     yes 
""")
        return 0
    known_prefixes = (
        "--output-format=", "--filter", "--filter-terminator=", "--sort=", "--excmd=",
        "--language-force=", "--languages=", "--fields=", "--extras=", "--exclude=",
        "--exclude-exception=", "--recurse", "--append", "--totals", "--verbose",
        "--quiet", "--print-language", "--maxdepth=", "--format=", "--tag-relative=",
        "--options", "--options-maybe", "--machinable", "--with-list-header",
    )
    for arg in argv:
        if arg.startswith("--") and not arg.startswith(known_prefixes):
            sys.stderr.write(f"executable: Unknown option: {arg}\n")
            return 1
    files, out, to_stdout, output_format, filter_mode, filter_terminator, print_language = parse_args(argv)
    if print_language:
        for path in files:
            sys.stdout.write(f"{path}: {detect_language(path)}\n")
        return 0
    if filter_mode:
        for name in sys.stdin:
            path = name.strip()
            if not path:
                continue
            sys.stdout.write(render_tags(parse_file(path), output_format))
            sys.stdout.write(filter_terminator)
        return 0
    all_tags = []
    for path in files:
        all_tags.extend(parse_file(path))
    content = render_tags(all_tags, output_format)
    if to_stdout:
        sys.stdout.write(content)
    else:
        with open(out, "w", encoding="utf-8") as f:
            f.write(content)
    return 0


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
