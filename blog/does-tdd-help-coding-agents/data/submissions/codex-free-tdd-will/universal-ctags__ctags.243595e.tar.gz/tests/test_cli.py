#!/usr/bin/env python3
import subprocess
import sys
from pathlib import Path
import tempfile


ROOT = Path(__file__).resolve().parents[1]
EXE = ROOT / "build" / "executable"


def run_cmd(args, cwd=None, input_text=None):
    return subprocess.run(
        [str(EXE), *args],
        cwd=cwd or ROOT,
        input=input_text,
        text=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
    )


def assert_eq(actual, expected, label):
    if actual != expected:
        print(f"FAIL {label}", file=sys.stderr)
        print("expected:", repr(expected), file=sys.stderr)
        print("actual:  ", repr(actual), file=sys.stderr)
        sys.exit(1)


def test_version():
    result = run_cmd(["--version"])
    assert_eq(result.returncode, 0, "version status")
    assert result.stdout.startswith("Universal Ctags 6.2.0(d922013), Copyright")
    assert "Optional compiled features: +wildcards, +regex, +iconv" in result.stdout
    assert_eq(result.stderr, "", "version stderr")


def test_help_and_lists():
    help_result = run_cmd(["--help"])
    assert_eq(help_result.returncode, 0, "help status")
    assert help_result.stdout.startswith("Universal Ctags 6.2.0(d922013), Copyright")
    assert "Usage: executable [options] [file(s)]" in help_result.stdout
    assert "--output-format=(u-ctags|e-ctags|etags|xref|json)" in help_result.stdout

    languages = run_cmd(["--list-languages"]).stdout.splitlines()
    assert languages[:5] == ["Abaqus", "Abc", "Ada", "AnsiblePlaybook", "Ant"]
    assert "Python" in languages
    assert "JavaScript" in languages

    features = run_cmd(["--list-features"]).stdout
    assert "#NAME             DESCRIPTION" in features
    assert "json              supports json format output" in features


def test_python_tags_to_stdout():
    with tempfile.TemporaryDirectory() as td:
        work = Path(td)
        src = work / "sample.py"
        src.write_text(
            "import os\n"
            "CONSTANT = 42\n"
            "class Widget:\n"
            "    def __init__(self, name):\n"
            "        self.name = name\n"
            "    def render(self):\n"
            "        return self.name\n"
            "def top_level(a, b=1):\n"
            "    return a + b\n"
        )
        result = run_cmd(["-f", "-", "sample.py"], cwd=work)
    assert_eq(result.returncode, 0, "python tags status")
    assert_eq(
        result.stdout,
        "CONSTANT\tsample.py\t/^CONSTANT = 42$/;\"\tv\n"
        "Widget\tsample.py\t/^class Widget:$/;\"\tc\n"
        "__init__\tsample.py\t/^    def __init__(self, name):$/;\"\tm\tclass:Widget\n"
        "render\tsample.py\t/^    def render(self):$/;\"\tm\tclass:Widget\n"
        "top_level\tsample.py\t/^def top_level(a, b=1):$/;\"\tf\n",
        "python tags stdout",
    )
    assert_eq(result.stderr, "", "python tags stderr")


def test_c_tags_to_stdout():
    with tempfile.TemporaryDirectory() as td:
        work = Path(td)
        src = work / "sample.c"
        src.write_text(
            "#include <stdio.h>\n"
            "#define MAX 10\n"
            "int global_var = 3;\n"
            "static int helper(int x) { return x + 1; }\n"
            "void greet(void)\n"
            "{\n"
            "}\n"
            "struct Point { int x; int y; };\n"
            "typedef struct Point Point;\n"
            "enum Color { RED, GREEN };\n"
        )
        result = run_cmd(["-f", "-", "sample.c"], cwd=work)
    assert_eq(result.returncode, 0, "c tags status")
    assert_eq(
        result.stdout,
        "Color\tsample.c\t/^enum Color { RED, GREEN };$/;\"\tg\tfile:\n"
        "GREEN\tsample.c\t/^enum Color { RED, GREEN };$/;\"\te\tenum:Color\tfile:\n"
        "MAX\tsample.c\t/^#define MAX /;\"\td\tfile:\n"
        "Point\tsample.c\t/^struct Point { int x; int y; };$/;\"\ts\tfile:\n"
        "Point\tsample.c\t/^typedef struct Point Point;$/;\"\tt\ttyperef:struct:Point\tfile:\n"
        "RED\tsample.c\t/^enum Color { RED, GREEN };$/;\"\te\tenum:Color\tfile:\n"
        "global_var\tsample.c\t/^int global_var = 3;$/;\"\tv\ttyperef:typename:int\n"
        "greet\tsample.c\t/^void greet(void)$/;\"\tf\ttyperef:typename:void\n"
        "helper\tsample.c\t/^static int helper(int x) { return x + 1; }$/;\"\tf\ttyperef:typename:int\tfile:\n"
        "x\tsample.c\t/^struct Point { int x; int y; };$/;\"\tm\tstruct:Point\ttyperef:typename:int\tfile:\n"
        "y\tsample.c\t/^struct Point { int x; int y; };$/;\"\tm\tstruct:Point\ttyperef:typename:int\tfile:\n",
        "c tags stdout",
    )


def test_javascript_json_and_xref_outputs():
    with tempfile.TemporaryDirectory() as td:
        work = Path(td)
        js = work / "sample.js"
        js.write_text(
            "const answer = 42;\n"
            "function add(a, b) { return a + b; }\n"
            "class Thing {\n"
            "  method(x) { return x; }\n"
            "}\n"
            "const arrow = (x) => x * 2;\n"
        )
        tags = run_cmd(["-f", "-", "sample.js"], cwd=work)
        json_result = run_cmd(["--output-format=json", "-f", "-", "sample.js"], cwd=work)
        xref = run_cmd(["-x", "sample.js"], cwd=work)
    assert_eq(
        tags.stdout,
        "Thing\tsample.js\t/^class Thing {$/;\"\tc\n"
        "add\tsample.js\t/^function add(a, b) { return a + b; }$/;\"\tf\n"
        "answer\tsample.js\t/^const answer = 42;$/;\"\tC\n"
        "arrow\tsample.js\t/^const arrow = (x) => x * 2;$/;\"\tf\n"
        "method\tsample.js\t/^  method(x) { return x; }$/;\"\tm\tclass:Thing\n",
        "javascript tags",
    )
    assert '"name": "Thing"' in json_result.stdout
    assert '"kind": "class"' in json_result.stdout
    assert '"scope": "Thing", "scopeKind": "class"' in json_result.stdout
    assert "add              function" in xref.stdout
    assert "answer           constant" in xref.stdout


def test_input_modes_and_print_language():
    with tempfile.TemporaryDirectory() as td:
        work = Path(td)
        (work / "a.py").write_text("def alpha():\n    pass\n")
        (work / "b.js").write_text("function beta() {}\n")
        (work / "files.txt").write_text("a.py\nb.js\n")

        created = run_cmd(["a.py"], cwd=work)
        assert_eq(created.returncode, 0, "default file status")
        assert (work / "tags").exists()
        assert "alpha\ta.py\t/^def alpha():$/;\"\tf\n" in (work / "tags").read_text()

        listed = run_cmd(["-f", "-", "-L", "files.txt"], cwd=work)
        assert "alpha\ta.py\t/^def alpha():$/;\"\tf\n" in listed.stdout
        assert "beta\tb.js\t/^function beta() {}$/;\"\tf\n" in listed.stdout

        filtered = run_cmd(["--filter=yes", "--filter-terminator=END"], cwd=work, input_text="a.py\nb.js\n")
        assert_eq(
            filtered.stdout,
            "alpha\ta.py\t/^def alpha():$/;\"\tf\n"
            "END"
            "beta\tb.js\t/^function beta() {}$/;\"\tf\n"
            "END",
            "filter stdout",
        )

        langs = run_cmd(["--print-language", "a.py", "b.js", "README.md"], cwd=work)
        assert_eq(langs.stdout, "a.py: Python\nb.js: JavaScript\nREADME.md: Markdown\n", "print language")

        missing = run_cmd(["-f", "-", "missing.c"], cwd=work)
        assert_eq(missing.returncode, 0, "missing status")
        assert 'executable: Warning: cannot open input file "missing.c" : No such file or directory\n' == missing.stderr


def test_common_language_smoke_tags():
    with tempfile.TemporaryDirectory() as td:
        work = Path(td)
        (work / "main.go").write_text(
            "package main\nconst Pi = 3\nvar Count int\ntype User struct { Name string }\n"
            "func (u User) Greet(name string) string { return name }\nfunc Add(a int, b int) int { return a+b }\n"
        )
        (work / "lib.rs").write_text(
            "pub struct User { name: String }\nenum Color { Red, Green }\nconst LIMIT: i32 = 10;\n"
            "fn add(a: i32, b: i32) -> i32 { a + b }\n"
        )
        (work / "Hello.java").write_text("package demo;\npublic class Hello {\n  public void greet(String name) {}\n}\n")
        (work / "app.rb").write_text("CONSTANT = 1\nclass Widget\n  def render(name)\n  end\nend\n")
        (work / "run.sh").write_text("hello() { echo hi; }\nfunction bye { echo bye; }\n")
        (work / "style.css").write_text("#main { color: red; }\n.button, .link { display: block; }\n")
        result = run_cmd(["-f", "-", "main.go", "lib.rs", "Hello.java", "app.rb", "run.sh", "style.css"], cwd=work)
    out = result.stdout
    for expected in [
        "Add\tmain.go\t/^func Add(a int, b int) int { return a+b }$/;\"\tf\tpackage:main\ttyperef:typename:int\n",
        "User\tmain.go\t/^type User struct { Name string }$/;\"\ts\tpackage:main\n",
        "Color\tlib.rs\t/^enum Color { Red, Green }$/;\"\tg\n",
        "LIMIT\tlib.rs\t/^const LIMIT: i32 = 10;$/;\"\tC\n",
        "Hello\tHello.java\t/^public class Hello {$/;\"\tc\n",
        "greet\tHello.java\t/^  public void greet(String name) {}$/;\"\tm\tclass:Hello\n",
        "Widget\tapp.rb\t/^class Widget$/;\"\tc\n",
        "render\tapp.rb\t/^  def render(name)$/;\"\tf\tclass:Widget\n",
        "hello\trun.sh\t/^hello() { echo hi; }$/;\"\tf\n",
        "#main\tstyle.css\t/^#main { color: red; }$/;\"\ti\n",
        ".button\tstyle.css\t/^.button, .link { display: block; }$/;\"\tc\n",
    ]:
        assert expected in out, expected


def test_misc_cli_edges():
    py_kinds = run_cmd(["--list-kinds=Python"])
    assert_eq(py_kinds.returncode, 0, "python kinds status")
    assert "c  classes\n" in py_kinds.stdout
    assert "f  functions\n" in py_kinds.stdout

    license_result = run_cmd(["--license"])
    assert_eq(license_result.returncode, 0, "license status")
    assert "This program is free software; you can redistribute it" in license_result.stdout

    bad = run_cmd(["--badopt"])
    assert_eq(bad.returncode, 1, "bad option status")
    assert_eq(bad.stderr, "executable: Unknown option: --badopt\n", "bad option stderr")


def main():
    test_version()
    test_help_and_lists()
    test_python_tags_to_stdout()
    test_c_tags_to_stdout()
    test_javascript_json_and_xref_outputs()
    test_input_modes_and_print_language()
    test_common_language_smoke_tags()
    test_misc_cli_edges()
    print("ok")


if __name__ == "__main__":
    main()
