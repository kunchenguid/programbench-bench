#!/bin/bash
set -e
rm -f executable
cp src/htmlq.py executable
chmod +x executable
