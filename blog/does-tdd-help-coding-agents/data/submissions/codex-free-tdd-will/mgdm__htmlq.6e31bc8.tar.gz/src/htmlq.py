#!/usr/bin/env python3
import argparse
import html
import re
import sys
from urllib.parse import urljoin
from html.parser import HTMLParser


VOID_TAGS = {"area", "base", "br", "col", "embed", "hr", "img", "input", "link", "meta", "param", "source", "track", "wbr"}


class Text:
    def __init__(self, data):
        self.data = data
        self.parent = None


class Element:
    def __init__(self, tag, attrs=None):
        self.tag = tag.lower()
        self.attrs = dict(attrs or [])
        self.children = []
        self.parent = None

    def append(self, child):
        child.parent = self
        self.children.append(child)


class Parser(HTMLParser):
    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.root = Element("#document")
        self.stack = [self.root]

    def handle_starttag(self, tag, attrs):
        el = Element(tag, [(k.lower(), v if v is not None else "") for k, v in attrs])
        self.stack[-1].append(el)
        if el.tag not in VOID_TAGS:
            self.stack.append(el)

    def handle_startendtag(self, tag, attrs):
        self.handle_starttag(tag, attrs)

    def handle_endtag(self, tag):
        tag = tag.lower()
        for i in range(len(self.stack) - 1, 0, -1):
            if self.stack[i].tag == tag:
                del self.stack[i:]
                return

    def handle_data(self, data):
        self.stack[-1].append(Text(data))


def element_children(el):
    return [c for c in el.children if isinstance(c, Element)]


def normalize_document(root):
    html_el = next((c for c in element_children(root) if c.tag == "html"), None)
    if html_el is None:
        html_el = Element("html")
        body = Element("body")
        old = root.children
        root.children = []
        root.append(html_el)
        html_el.append(Element("head"))
        html_el.append(body)
        for child in old:
            body.append(child)
    else:
        kids = element_children(html_el)
        if not any(c.tag == "head" for c in kids):
            head = Element("head")
            head.parent = html_el
            html_el.children.insert(0, head)
        if not any(c.tag == "body" for c in kids):
            body = Element("body")
            body.parent = html_el
            moved = [c for c in html_el.children if not (isinstance(c, Element) and c.tag == "head")]
            html_el.children = [c for c in html_el.children if isinstance(c, Element) and c.tag == "head"]
            html_el.append(body)
            for child in moved:
                body.append(child)
        body = next((c for c in element_children(html_el) if c.tag == "body"), None)
        if body:
            for child in list(root.children):
                if isinstance(child, Text) and child.data.strip() == "":
                    root.children.remove(child)
                    body.append(child)
    return html_el


def serialize(node):
    if isinstance(node, Text):
        return html.escape(node.data, quote=False)
    if node.tag == "#document":
        return "".join(serialize(c) for c in node.children)
    attrs = ""
    for k in sorted(node.attrs):
        attrs += f' {k}="{html.escape(node.attrs[k], quote=True)}"'
    start = f"<{node.tag}{attrs}>"
    if node.tag in VOID_TAGS:
        return start
    return start + "".join(serialize(c) for c in node.children) + f"</{node.tag}>"


def pretty_serialize(node, depth=0):
    if isinstance(node, Text):
        return html.escape(node.data, quote=False)
    if node.tag == "#document":
        return "".join(pretty_serialize(c, depth) for c in node.children)
    indent = "  " * depth
    attrs = ""
    for k in sorted(node.attrs):
        attrs += f' {k}="{html.escape(node.attrs[k], quote=True)}"'
    if node.tag in VOID_TAGS:
        return f"{indent}<{node.tag}{attrs}>\n"
    if not node.children:
        return f"{indent}<{node.tag}{attrs}></{node.tag}>\n"
    if len(node.children) == 1 and isinstance(node.children[0], Text):
        return f"{indent}<{node.tag}{attrs}>{serialize(node.children[0])}</{node.tag}>\n"
    out = f"{indent}<{node.tag}{attrs}>\n"
    for child in node.children:
        if isinstance(child, Text):
            if child.data:
                out += "  " * (depth + 1) + html.escape(child.data, quote=False) + "\n"
        else:
            out += pretty_serialize(child, depth + 1)
    out += f"{indent}</{node.tag}>\n"
    return out


def descendants(el):
    for child in el.children:
        if isinstance(child, Element):
            yield child
            yield from descendants(child)


class SimpleSelector:
    def __init__(self, tag=None):
        self.tag = tag
        self.ids = []
        self.classes = []
        self.attrs = []
        self.first_child = False
        self.last_child = False
        self.nth_child = None
        self.not_selectors = []


def split_selector_groups(selector):
    groups, buf = [], []
    bracket = paren = 0
    quote = None
    for ch in selector:
        if quote:
            buf.append(ch)
            if ch == quote:
                quote = None
            continue
        if ch in "\"'":
            quote = ch
        elif ch == "[":
            bracket += 1
        elif ch == "]":
            bracket -= 1
        elif ch == "(":
            paren += 1
        elif ch == ")":
            paren -= 1
        elif ch == "," and bracket == 0 and paren == 0:
            part = "".join(buf).strip()
            if part:
                groups.append(part)
            buf = []
            continue
        buf.append(ch)
    part = "".join(buf).strip()
    if part:
        groups.append(part)
    return groups


def tokenize_selector(selector):
    tokens, buf = [], []
    bracket = paren = 0
    quote = None
    pending_space = False
    i = 0
    while i < len(selector):
        ch = selector[i]
        if quote:
            buf.append(ch)
            if ch == quote:
                quote = None
            i += 1
            continue
        if ch in "\"'":
            quote = ch
            buf.append(ch)
        elif ch == "[":
            bracket += 1
            buf.append(ch)
        elif ch == "]":
            bracket -= 1
            buf.append(ch)
        elif ch == "(":
            paren += 1
            buf.append(ch)
        elif ch == ")":
            paren -= 1
            buf.append(ch)
        elif bracket == 0 and paren == 0 and ch in ">+~":
            if buf:
                tokens.append(("simple", "".join(buf).strip()))
                buf = []
            tokens.append(("comb", ch))
            pending_space = False
        elif bracket == 0 and paren == 0 and ch.isspace():
            if buf:
                tokens.append(("simple", "".join(buf).strip()))
                buf = []
            pending_space = True
        else:
            if pending_space:
                if tokens and tokens[-1][0] != "comb":
                    tokens.append(("comb", " "))
                pending_space = False
            buf.append(ch)
        i += 1
    if buf:
        tokens.append(("simple", "".join(buf).strip()))
    out, comb = [], None
    for kind, val in tokens:
        if kind == "comb":
            comb = val
        elif val:
            out.append((comb, parse_simple_selector(val)))
            comb = " "
    return out


def parse_simple_selector(text):
    s = SimpleSelector()
    i = 0
    m = re.match(r"(\*|[A-Za-z][A-Za-z0-9_-]*)", text)
    if m:
        if m.group(1) != "*":
            s.tag = m.group(1).lower()
        i = m.end()
    while i < len(text):
        ch = text[i]
        if ch == "#":
            m = re.match(r"#([A-Za-z0-9_-]+)", text[i:])
            s.ids.append(m.group(1))
            i += len(m.group(0))
        elif ch == ".":
            m = re.match(r"\.([A-Za-z0-9_-]+)", text[i:])
            s.classes.append(m.group(1))
            i += len(m.group(0))
        elif ch == "[":
            j = text.find("]", i)
            body = text[i + 1:j].strip()
            if "=" in body:
                op = "="
                for candidate in ["~=", "^=", "$=", "*=", "|=", "="]:
                    if candidate in body:
                        name, value = body.split(candidate, 1)
                        op = candidate
                        break
                value = value.strip()
                if (value.startswith('"') and value.endswith('"')) or (value.startswith("'") and value.endswith("'")):
                    value = value[1:-1]
                s.attrs.append((name.strip().lower(), op, value))
            else:
                s.attrs.append((body.lower(), None, None))
            i = j + 1
        elif text.startswith(":first-child", i):
            s.first_child = True
            i += len(":first-child")
        elif text.startswith(":last-child", i):
            s.last_child = True
            i += len(":last-child")
        elif text.startswith(":nth-child(", i):
            j = text.find(")", i)
            try:
                s.nth_child = int(text[i + len(":nth-child("):j].strip())
            except ValueError:
                s.nth_child = -1
            i = j + 1
        elif text.startswith(":not(", i):
            j = text.find(")", i)
            inner = text[i + len(":not("):j].strip()
            if inner:
                s.not_selectors.append(parse_simple_selector(inner))
            i = j + 1
        else:
            i += 1
    return s


def simple_matches(el, sel):
    if sel.tag and el.tag != sel.tag:
        return False
    if sel.ids and el.attrs.get("id") not in sel.ids:
        return False
    classes = set(el.attrs.get("class", "").split())
    if any(c not in classes for c in sel.classes):
        return False
    for name, op, value in sel.attrs:
        if name not in el.attrs:
            return False
        actual = el.attrs.get(name)
        if op == "=" and actual != value:
            return False
        if op == "~=" and value not in actual.split():
            return False
        if op == "^=" and not actual.startswith(value):
            return False
        if op == "$=" and not actual.endswith(value):
            return False
        if op == "*=" and value not in actual:
            return False
        if op == "|=" and not (actual == value or actual.startswith(value + "-")):
            return False
    if any(simple_matches(el, n) for n in sel.not_selectors):
        return False
    if sel.first_child or sel.last_child or sel.nth_child is not None:
        if not el.parent:
            return False
        siblings = element_children(el.parent)
        pos = siblings.index(el) + 1 if el in siblings else -1
        if sel.first_child and pos != 1:
            return False
        if sel.last_child and pos != len(siblings):
            return False
        if sel.nth_child is not None and pos != sel.nth_child:
            return False
    return True


def sequence_matches(el, seq, idx=None):
    if idx is None:
        idx = len(seq) - 1
    if idx < 0:
        return True
    comb, sel = seq[idx]
    if not simple_matches(el, sel):
        return False
    if idx == 0:
        return True
    prev_comb = seq[idx][0] or " "
    if prev_comb == ">":
        return bool(el.parent and isinstance(el.parent, Element) and sequence_matches(el.parent, seq, idx - 1))
    if prev_comb in {"+", "~"}:
        if not el.parent:
            return False
        siblings = element_children(el.parent)
        pos = siblings.index(el) if el in siblings else -1
        if prev_comb == "+":
            return pos > 0 and sequence_matches(siblings[pos - 1], seq, idx - 1)
        return any(sequence_matches(sib, seq, idx - 1) for sib in siblings[:pos])
    parent = el.parent
    while parent and isinstance(parent, Element) and parent.tag != "#document":
        if sequence_matches(parent, seq, idx - 1):
            return True
        parent = parent.parent
    return False


def select(root, selector):
    groups = [tokenize_selector(g) for g in split_selector_groups(selector)]
    results = []
    seen = set()
    for el in descendants(root):
        if any(seq and sequence_matches(el, seq) for seq in groups):
            if id(el) not in seen:
                seen.add(id(el))
                results.append(el)
    return results


def text_nodes(el):
    for child in el.children:
        if isinstance(child, Text):
            yield child.data
        elif isinstance(child, Element):
            yield from text_nodes(child)


def find_base(root):
    for el in descendants(root):
        if el.tag == "base" and el.attrs.get("href"):
            return el.attrs.get("href")
    return None


def remove_node(el):
    if el.parent:
        el.parent.children = [c for c in el.parent.children if c is not el]
        el.parent = None


def render_text(matches, ignore_whitespace):
    if ignore_whitespace:
        chunks = []
        for el in matches:
            for text in text_nodes(el):
                if text.strip():
                    chunks.append(text)
            chunks.append("")
        return "\n".join(chunks) + "\n" if chunks else ""
    return "\n".join("".join(text_nodes(el)) for el in matches) + ("\n" if matches else "")


def render_attribute(matches, attr, base):
    lines = []
    for el in matches:
        if attr in el.attrs:
            value = el.attrs[attr]
            if attr == "href" and base:
                value = urljoin(base, value)
            lines.append(value)
    return "\n".join(lines) + ("\n" if lines else "")


def main(argv=None):
    ap = argparse.ArgumentParser(add_help=False)
    ap.add_argument("-h", "--help", action="store_true")
    ap.add_argument("-V", "--version", action="store_true")
    ap.add_argument("-t", "--text", action="store_true")
    ap.add_argument("-w", "--ignore-whitespace", action="store_true")
    ap.add_argument("-p", "--pretty", action="store_true")
    ap.add_argument("-B", "--detect-base", action="store_true")
    ap.add_argument("-a", "--attribute")
    ap.add_argument("-b", "--base")
    ap.add_argument("-f", "--filename")
    ap.add_argument("-o", "--output")
    ap.add_argument("-r", "--remove-nodes", action="append", nargs="+", default=[])
    ap.add_argument("selector", nargs="*")
    ns = ap.parse_args(argv)
    if ns.help:
        print("""htmlq 0.4.0
Michael Maclean <michael@mgdm.net>
Runs CSS selectors on HTML

USAGE:
    executable [FLAGS] [OPTIONS] [--] [selector]...

FLAGS:
    -B, --detect-base          Try to detect the base URL from the <base> tag in the document. If not found, default to
                               the value of --base, if supplied
    -h, --help                 Prints help information
    -w, --ignore-whitespace    When printing text nodes, ignore those that consist entirely of whitespace
    -p, --pretty               Pretty-print the serialised output
    -t, --text                 Output only the contents of text nodes inside selected elements
    -V, --version              Prints version information

OPTIONS:
    -a, --attribute <attribute>         Only return this attribute (if present) from selected elements
    -b, --base <base>                   Use this URL as the base for links
    -f, --filename <FILE>               The input file. Defaults to stdin
    -o, --output <FILE>                 The output file. Defaults to stdout
    -r, --remove-nodes <SELECTOR>...    Remove nodes matching this expression before output. May be specified multiple
                                        times

ARGS:
    <selector>...    The CSS expression to select [default: html]""")
        return 0
    if ns.version:
        print("htmlq 0.4.0")
        return 0
    data = open(ns.filename).read() if ns.filename else sys.stdin.read()
    parser = Parser()
    parser.feed(data)
    normalize_document(parser.root)
    for remove_group in ns.remove_nodes:
        for remove_selector in remove_group:
            for el in list(select(parser.root, remove_selector)):
                remove_node(el)
    selector = " ".join(ns.selector) if ns.selector else "html"
    matches = select(parser.root, selector)
    if ns.text:
        out = render_text(matches, ns.ignore_whitespace)
    elif ns.attribute:
        base = find_base(parser.root) if ns.detect_base else None
        if not base:
            base = ns.base
        out = render_attribute(matches, ns.attribute.lower(), base)
    else:
        if ns.pretty:
            out = "\n".join(pretty_serialize(e).rstrip("\n") for e in matches)
        else:
            out = "\n".join(serialize(e) for e in matches)
        out += "\n" if matches else ""
    if ns.output:
        with open(ns.output, "w") as f:
            f.write(out)
    else:
        sys.stdout.write(out)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
