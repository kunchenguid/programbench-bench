#!/bin/bash
set -euo pipefail

ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"

gcc -std=c11 -Wall -Wextra -O2 -o executable src/pingu.c -lm

out="$(./executable --help 2>&1)"
grep -F 'Usage:' <<<"$out"
grep -F '  pingu [OPTIONS] HOST' <<<"$out"
grep -F '  -c, --count=     Stop after <count> replies (default: 20)' <<<"$out"

out="$(./executable -V 2>&1)"
test "$out" = "pingu: v-rev9c2e3df"

set +e
out="$(./executable 2>&1)"
status=$?
set -e
test "$status" -eq 1
test "$out" = "[ ERROR ] must requires an argument"

set +e
out="$(./executable --bad 2>&1)"
status=$?
set -e
test "$status" -eq 1
grep -F 'unknown flag `bad'\''' <<<"$out"
grep -F '[ ERROR ] parse error: unknown flag `bad'\''' <<<"$out"

set +e
out="$(./executable -c abc 127.0.0.1 2>&1)"
status=$?
set -e
test "$status" -eq 1
grep -F 'invalid argument for flag `-c, --count'\''' <<<"$out"

out="$(./executable -c 1 127.0.0.1 2>&1)"
grep -F 'PING 127.0.0.1 (127.0.0.1) type `Ctrl-C` to abort' <<<"$out"
grep -F 'seq=0 32bytes from 127.0.0.1: ttl=' <<<"$out"
grep -F 'PACKET STATISTICS: 1 transmitted => 1 received (0% loss)' <<<"$out"
grep -F 'ROUND TRIP: min=' <<<"$out"
