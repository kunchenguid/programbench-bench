#define _GNU_SOURCE
#include <arpa/inet.h>
#include <errno.h>
#include <math.h>
#include <netdb.h>
#include <netinet/icmp6.h>
#include <netinet/ip.h>
#include <netinet/ip_icmp.h>
#include <signal.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/select.h>
#include <sys/socket.h>
#include <sys/time.h>
#include <sys/types.h>
#include <time.h>
#include <unistd.h>

static volatile sig_atomic_t interrupted = 0;

struct options {
    int count;
    bool privileged;
    const char *host;
};

struct stats {
    int transmitted;
    int received;
    double min_ms;
    double max_ms;
    double sum_ms;
    double sumsq_ms;
};

static void on_signal(int sig) {
    (void)sig;
    interrupted = 1;
}

static void print_help(void) {
    puts("Usage:");
    puts("  pingu [OPTIONS] HOST");
    puts("");
    puts("`ping` command but with pingu");
    puts("");
    puts("Application Options:");
    puts("  -c, --count=     Stop after <count> replies (default: 20)");
    puts("  -P, --privilege  Enable privileged mode");
    puts("  -V, --version    Show version");
    puts("");
    puts("Help Options:");
    puts("  -h, --help       Show this help message");
}

static unsigned short checksum(const void *data, int len) {
    const unsigned short *p = (const unsigned short *)data;
    unsigned int sum = 0;
    while (len > 1) {
        sum += *p++;
        len -= 2;
    }
    if (len == 1) {
        sum += *(const unsigned char *)p;
    }
    while (sum >> 16) {
        sum = (sum & 0xffffU) + (sum >> 16);
    }
    return (unsigned short)~sum;
}

static double elapsed_ms(struct timespec a, struct timespec b) {
    return (double)(b.tv_sec - a.tv_sec) * 1000.0 + (double)(b.tv_nsec - a.tv_nsec) / 1000000.0;
}

static void format_duration(double ms, char *buf, size_t n) {
    if (ms < 1.0) {
        double us = ms * 1000.0;
        if (us < 0.001) {
            snprintf(buf, n, "0s");
        } else {
            snprintf(buf, n, "%.3fµs", us);
            char *dot = strchr(buf, '.');
            if (dot) {
                char *end = strstr(buf, "µs");
                while (end > dot + 1 && end[-1] == '0') {
                    memmove(end - 1, end, strlen(end) + 1);
                    end--;
                }
                if (end > dot && end[-1] == '.') {
                    memmove(end - 1, end, strlen(end) + 1);
                }
            }
        }
    } else {
        snprintf(buf, n, "%.3fms", ms);
        char *dot = strchr(buf, '.');
        if (dot) {
            char *end = strstr(buf, "ms");
            while (end > dot + 1 && end[-1] == '0') {
                memmove(end - 1, end, strlen(end) + 1);
                end--;
            }
            if (end > dot && end[-1] == '.') {
                memmove(end - 1, end, strlen(end) + 1);
            }
        }
    }
}

static int parse_int_arg(const char *value) {
    char *end = NULL;
    errno = 0;
    long v = strtol(value, &end, 10);
    if (errno || !end || *end != '\0') {
        fprintf(stderr, "invalid argument for flag `-c, --count' (expected int): strconv.ParseInt: parsing \"%s\": invalid syntax\n", value);
        fprintf(stderr, "[ ERROR ] parse error: invalid argument for flag `-c, --count' (expected int): strconv.ParseInt: parsing \"%s\": invalid syntax\n", value);
        exit(1);
    }
    return (int)v;
}

static void unknown_flag(const char *flag) {
    const char *name = flag;
    while (*name == '-') name++;
    fprintf(stderr, "unknown flag `%s'\n", name);
    fprintf(stderr, "[ ERROR ] parse error: unknown flag `%s'\n", name);
    exit(1);
}

static struct options parse_args(int argc, char **argv) {
    struct options opt = {.count = 20, .privileged = false, .host = NULL};
    for (int i = 1; i < argc; i++) {
        const char *arg = argv[i];
        if (strcmp(arg, "--help") == 0 || strcmp(arg, "-h") == 0) {
            print_help();
            exit(0);
        } else if (strcmp(arg, "--version") == 0 || strcmp(arg, "-V") == 0) {
            puts("pingu: v-rev9c2e3df");
            exit(0);
        } else if (strcmp(arg, "-P") == 0 || strcmp(arg, "--privilege") == 0) {
            opt.privileged = true;
        } else if (strcmp(arg, "-c") == 0 || strcmp(arg, "--count") == 0) {
            if (i + 1 >= argc) unknown_flag(arg);
            opt.count = parse_int_arg(argv[++i]);
        } else if (strncmp(arg, "-c=", 3) == 0) {
            opt.count = parse_int_arg(arg + 3);
        } else if (strncmp(arg, "--count=", 8) == 0) {
            opt.count = parse_int_arg(arg + 8);
        } else if (arg[0] == '-') {
            unknown_flag(arg);
        } else {
            opt.host = arg;
        }
    }
    if (!opt.host) {
        fputs("[ ERROR ] must requires an argument\n", stderr);
        exit(1);
    }
    return opt;
}

static int make_socket(int family, bool privileged) {
    int proto = family == AF_INET ? IPPROTO_ICMP : IPPROTO_ICMPV6;
    int type = privileged ? SOCK_RAW : SOCK_DGRAM;
    int fd = socket(family, type, proto);
    if (fd < 0 && !privileged) {
        fd = socket(family, SOCK_RAW, proto);
    }
    return fd;
}

static int send_echo(int fd, int family, const struct sockaddr *addr, socklen_t addrlen, int seq, unsigned short ident) {
    unsigned char packet[64];
    memset(packet, 0, sizeof(packet));
    if (family == AF_INET) {
        struct icmphdr *icmp = (struct icmphdr *)packet;
        icmp->type = ICMP_ECHO;
        icmp->code = 0;
        icmp->un.echo.id = htons(ident);
        icmp->un.echo.sequence = htons((unsigned short)seq);
        memset(packet + sizeof(*icmp), '.', 32);
        icmp->checksum = checksum(packet, (int)(sizeof(*icmp) + 32));
        return sendto(fd, packet, sizeof(*icmp) + 32, 0, addr, addrlen);
    }
    struct icmp6_hdr *icmp6 = (struct icmp6_hdr *)packet;
    icmp6->icmp6_type = ICMP6_ECHO_REQUEST;
    icmp6->icmp6_code = 0;
    icmp6->icmp6_id = htons(ident);
    icmp6->icmp6_seq = htons((unsigned short)seq);
    memset(packet + sizeof(*icmp6), '.', 32);
    return sendto(fd, packet, sizeof(*icmp6) + 32, 0, addr, addrlen);
}

static bool recv_echo(int fd, int family, int seq, unsigned short ident, int *ttl) {
    unsigned char buf[1500];
    struct timeval tv = {.tv_sec = 1, .tv_usec = 0};
    fd_set fds;
    FD_ZERO(&fds);
    FD_SET(fd, &fds);
    if (select(fd + 1, &fds, NULL, NULL, &tv) <= 0) return false;
    struct sockaddr_storage from;
    socklen_t fromlen = sizeof(from);
    ssize_t n = recvfrom(fd, buf, sizeof(buf), 0, (struct sockaddr *)&from, &fromlen);
    if (n <= 0) return false;
    if (family == AF_INET) {
        struct icmphdr *icmp = NULL;
        if (n >= (ssize_t)(sizeof(struct iphdr) + sizeof(struct icmphdr)) && ((struct iphdr *)buf)->version == 4) {
            struct iphdr *ip = (struct iphdr *)buf;
            *ttl = ip->ttl;
            icmp = (struct icmphdr *)(buf + ip->ihl * 4);
        } else if (n >= (ssize_t)sizeof(struct icmphdr)) {
            icmp = (struct icmphdr *)buf;
            *ttl = 64;
        }
        if (!icmp) return false;
        return icmp->type == ICMP_ECHOREPLY &&
               (ntohs(icmp->un.echo.sequence) == (unsigned short)seq) &&
               (ntohs(icmp->un.echo.id) == ident || ident == 0 || ntohs(icmp->un.echo.id) != 0);
    }
    struct icmp6_hdr *icmp6 = (struct icmp6_hdr *)buf;
    *ttl = 64;
    return n >= (ssize_t)sizeof(*icmp6) && icmp6->icmp6_type == ICMP6_ECHO_REPLY &&
           ntohs(icmp6->icmp6_seq) == (unsigned short)seq;
}

static const char *art_for_seq(int seq) {
    static const char *lines[] = {
        " ...        .     ...   ..    ..     .........           ",
        " ...     ....          ..  ..      ... .....  .. ..      ",
        "  ..   ..  ..  ..    ..     ...    ...  ...  ..         ",
        " ....   ...       ..  ..      ....       ...    ..       ",
    };
    return lines[seq % 4];
}

static void print_summary(const char *host, struct stats *st) {
    int loss = st->transmitted == 0 ? 0 : (int)((st->transmitted - st->received) * 100.0 / st->transmitted + 0.5);
    printf("\n───────── %s ping statistics ─────────\n", host);
    printf("PACKET STATISTICS: %d transmitted => %d received (%d%% loss)\n", st->transmitted, st->received, loss);
    if (st->received > 0) {
        double avg = st->sum_ms / st->received;
        double variance = st->sumsq_ms / st->received - avg * avg;
        if (variance < 0) variance = 0;
        double stddev = sqrt(variance);
        char minbuf[64], avgbuf[64], maxbuf[64], stdbuf[64];
        format_duration(st->min_ms, minbuf, sizeof(minbuf));
        format_duration(avg, avgbuf, sizeof(avgbuf));
        format_duration(st->max_ms, maxbuf, sizeof(maxbuf));
        format_duration(stddev, stdbuf, sizeof(stdbuf));
        printf("ROUND TRIP: min=%s avg=%s max=%s stddev=%s\n", minbuf, avgbuf, maxbuf, stdbuf);
    }
}

int main(int argc, char **argv) {
    struct options opt = parse_args(argc, argv);
    signal(SIGINT, on_signal);
    signal(SIGTERM, on_signal);

    struct addrinfo hints;
    memset(&hints, 0, sizeof(hints));
    hints.ai_socktype = SOCK_DGRAM;
    hints.ai_family = AF_UNSPEC;
    struct addrinfo *res = NULL;
    int gai = getaddrinfo(opt.host, NULL, &hints, &res);
    if (gai != 0 || !res) {
        fprintf(stderr, "[ ERROR ] an error occurred while initializing pinger: failed to init pinger %s\n",
                gai == EAI_SYSTEM ? strerror(errno) : gai_strerror(gai));
        return 0;
    }

    struct addrinfo *ai = res;
    char addrbuf[INET6_ADDRSTRLEN];
    void *addrptr = NULL;
    if (ai->ai_family == AF_INET) {
        addrptr = &((struct sockaddr_in *)ai->ai_addr)->sin_addr;
    } else {
        addrptr = &((struct sockaddr_in6 *)ai->ai_addr)->sin6_addr;
    }
    inet_ntop(ai->ai_family, addrptr, addrbuf, sizeof(addrbuf));

    int fd = make_socket(ai->ai_family, opt.privileged);
    if (fd < 0) {
        fprintf(stderr, "[ ERROR ] an error occurred while initializing pinger: failed to init pinger %s\n", strerror(errno));
        freeaddrinfo(res);
        return 0;
    }

    printf("PING %s (%s) type `Ctrl-C` to abort\n", opt.host, addrbuf);
    fflush(stdout);

    struct stats st = {.transmitted = 0, .received = 0, .min_ms = 0, .max_ms = 0, .sum_ms = 0, .sumsq_ms = 0};
    unsigned short ident = (unsigned short)(getpid() & 0xffff);
    int limit = opt.count;
    for (int seq = 0; !interrupted && (limit <= 0 || seq < limit); seq++) {
        struct timespec start, end;
        clock_gettime(CLOCK_MONOTONIC, &start);
        int sent = send_echo(fd, ai->ai_family, ai->ai_addr, ai->ai_addrlen, seq, ident);
        if (sent >= 0) st.transmitted++;
        int ttl = 64;
        bool ok = sent >= 0 && recv_echo(fd, ai->ai_family, seq, ident, &ttl);
        clock_gettime(CLOCK_MONOTONIC, &end);
        if (ok) {
            double ms = elapsed_ms(start, end);
            if (st.received == 0 || ms < st.min_ms) st.min_ms = ms;
            if (st.received == 0 || ms > st.max_ms) st.max_ms = ms;
            st.received++;
            st.sum_ms += ms;
            st.sumsq_ms += ms * ms;
            char tbuf[64];
            format_duration(ms, tbuf, sizeof(tbuf));
            printf("%s seq=%d 32bytes from %s: ttl=%d time=%s\n", art_for_seq(seq), seq, addrbuf, ttl, tbuf);
        }
        fflush(stdout);
        if (limit <= 0 || seq + 1 < limit) sleep(1);
    }

    print_summary(opt.host, &st);
    close(fd);
    freeaddrinfo(res);
    return 0;
}
