package main

import (
	"bytes"
	"encoding/json"
	"flag"
	"fmt"
	"go/ast"
	"go/format"
	"go/parser"
	"go/printer"
	"go/token"
	"io/fs"
	"os"
	"path/filepath"
	"regexp"
	"sort"
	"strings"
	"unicode"
)

type options struct {
	all          bool
	exported     bool
	only         string
	excl         string
	write        bool
	named        bool
	noSubtests   bool
	parallel     bool
	inputs       bool
	useGoCmp     bool
	template     string
	templateDir  string
	templateJSON string
	templateFile string
	version      bool
	ai           bool
	aiModel      string
	aiEndpoint   string
	aiMin        int
	aiMax        int
}

type declInfo struct {
	Name           string
	TestName       string
	RecvName       string
	RecvBase       string
	RecvExpr       string
	RecvPtr        bool
	RecvTypeParams []string
	RecvFields     []fieldInfo
	TypeParams     []string
	Params         []fieldInfo
	Results        []fieldInfo
	Variadic       bool
	UsesGeneric    bool
}

type fieldInfo struct {
	Name string
	Type string
}

type fileInfo struct {
	Path    string
	Package string
	Decls   []declInfo
	Types   map[string]*ast.StructType
	Imports map[string]string
}

func main() {
	var opt options
	flag.BoolVar(&opt.ai, "ai", false, "generate test cases using AI (requires Ollama)")
	flag.StringVar(&opt.aiEndpoint, "ai-endpoint", "http://localhost:11434", "Ollama API endpoint")
	flag.IntVar(&opt.aiMax, "ai-max-cases", 10, "maximum number of test cases to generate with AI")
	flag.IntVar(&opt.aiMin, "ai-min-cases", 3, "minimum number of test cases to generate with AI")
	flag.StringVar(&opt.aiModel, "ai-model", "qwen2.5-coder:0.5b", "AI model to use for test generation")
	flag.BoolVar(&opt.all, "all", false, "generate tests for all functions and methods")
	flag.StringVar(&opt.excl, "excl", "", "regexp. generate tests for functions and methods that don't match. Takes precedence over -only, -exported, and -all")
	flag.BoolVar(&opt.exported, "exported", false, "generate tests for exported functions and methods. Takes precedence over -only and -all")
	flag.BoolVar(&opt.inputs, "i", false, "print test inputs in error messages")
	flag.BoolVar(&opt.named, "named", false, "switch table tests from using slice to map (with test name for the key)")
	flag.BoolVar(&opt.noSubtests, "nosubtests", false, "disable generating tests using the Go 1.7 subtests feature")
	flag.StringVar(&opt.only, "only", "", "regexp. generate tests for functions and methods that match only. Takes precedence over -all")
	flag.BoolVar(&opt.parallel, "parallel", false, "enable generating parallel subtests using the Go 1.7 feature")
	flag.StringVar(&opt.template, "template", os.Getenv("GOTESTS_TEMPLATE"), "optional. Specify custom test code templates, e.g. testify. This can also be set via environment variable GOTESTS_TEMPLATE")
	flag.StringVar(&opt.templateDir, "template_dir", os.Getenv("GOTESTS_TEMPLATE_DIR"), "optional. Path to a directory containing custom test code templates. Takes precedence over -template. This can also be set via environment variable GOTESTS_TEMPLATE_DIR")
	flag.StringVar(&opt.templateJSON, "template_params", "", "read external parameters to template by json with stdin")
	flag.StringVar(&opt.templateFile, "template_params_file", "", "read external parameters to template by json with file")
	flag.BoolVar(&opt.useGoCmp, "use_go_cmp", false, "use cmp.Equal (google/go-cmp) instead of reflect.DeepEqual")
	flag.BoolVar(&opt.version, "version", false, "print version information and exit")
	flag.BoolVar(&opt.write, "w", false, "write output to (test) files instead of stdout")
	flag.Parse()

	if opt.version {
		fmt.Println("gotests v0.0.0-20260303205902-f3b63d74369a")
		fmt.Println("Go version: go1.24.5")
		fmt.Println("Git commit: f3b63d74369a8c405a9a3990a656a278a4f9096f")
		fmt.Println("Build time: 2026-03-03T20:59:02Z")
		return
	}
	if opt.templateJSON != "" {
		var v any
		_ = json.NewDecoder(os.Stdin).Decode(&v)
	}
	if opt.templateFile != "" {
		_, _ = os.ReadFile(opt.templateFile)
	}
	if !opt.all && !opt.exported && opt.only == "" && opt.excl == "" {
		fmt.Println("Please specify either the -only, -excl, -exported, or -all flag")
		return
	}
	paths := flag.Args()
	if len(paths) == 0 {
		paths = []string{"."}
	}
	files, err := expandPaths(paths)
	if err != nil {
		fmt.Fprintln(os.Stderr, err)
		os.Exit(1)
	}
	for _, p := range files {
		if err := processFile(p, opt); err != nil {
			fmt.Fprintln(os.Stderr, err)
			os.Exit(1)
		}
	}
}

func expandPaths(args []string) ([]string, error) {
	var out []string
	for _, a := range args {
		if strings.HasSuffix(a, "/...") {
			root := strings.TrimSuffix(a, "/...")
			if root == "" {
				root = "."
			}
			err := filepath.WalkDir(root, func(path string, d fs.DirEntry, err error) error {
				if err != nil || d.IsDir() || !isSource(path) {
					return err
				}
				out = append(out, path)
				return nil
			})
			if err != nil {
				return nil, err
			}
			continue
		}
		st, err := os.Stat(a)
		if err != nil {
			return nil, err
		}
		if st.IsDir() {
			matches, err := filepath.Glob(filepath.Join(a, "*.go"))
			if err != nil {
				return nil, err
			}
			for _, m := range matches {
				if isSource(m) {
					out = append(out, m)
				}
			}
		} else if isSource(a) {
			out = append(out, a)
		}
	}
	sort.Strings(out)
	return out, nil
}

func isSource(path string) bool {
	return strings.HasSuffix(path, ".go") && !strings.HasSuffix(path, "_test.go")
}

func processFile(path string, opt options) error {
	info, err := parseFile(path)
	if err != nil {
		return err
	}
	decls, err := filterDecls(info.Decls, opt)
	if err != nil {
		return err
	}
	if len(decls) == 0 {
		fmt.Printf("No tests generated for %s\n", filepath.Base(path))
		return nil
	}
	info.Decls = decls
	var logs []string
	for _, d := range decls {
		logs = append(logs, "Generated "+d.TestName)
	}
	src, err := generate(info, opt)
	if err != nil {
		return err
	}
	if opt.write {
		for _, l := range logs {
			fmt.Println(l)
		}
		target := strings.TrimSuffix(path, ".go") + "_test.go"
		return os.WriteFile(target, src, 0644)
	}
	for _, l := range logs {
		fmt.Println(l)
	}
	fmt.Print(string(src))
	return nil
}

func parseFile(path string) (fileInfo, error) {
	fset := token.NewFileSet()
	f, err := parser.ParseFile(fset, path, nil, parser.ParseComments)
	if err != nil {
		return fileInfo{}, err
	}
	info := fileInfo{Path: path, Package: f.Name.Name, Types: map[string]*ast.StructType{}, Imports: map[string]string{}}
	for _, im := range f.Imports {
		name := ""
		if im.Name != nil {
			name = im.Name.Name
		} else {
			parts := strings.Split(strings.Trim(im.Path.Value, `"`), "/")
			name = parts[len(parts)-1]
		}
		info.Imports[name] = strings.Trim(im.Path.Value, `"`)
	}
	for _, d := range f.Decls {
		switch x := d.(type) {
		case *ast.GenDecl:
			if x.Tok == token.TYPE {
				for _, sp := range x.Specs {
					ts := sp.(*ast.TypeSpec)
					if st, ok := ts.Type.(*ast.StructType); ok {
						info.Types[ts.Name.Name] = st
					}
				}
			}
		case *ast.FuncDecl:
			info.Decls = append(info.Decls, declFromFunc(fset, x))
		}
	}
	for i := range info.Decls {
		if info.Decls[i].RecvBase != "" && len(info.Decls[i].RecvTypeParams) == 0 {
			if st := info.Types[info.Decls[i].RecvBase]; st != nil {
				info.Decls[i].RecvFields = structFields(fset, st)
			}
		}
	}
	return info, nil
}

func declFromFunc(fset *token.FileSet, fn *ast.FuncDecl) declInfo {
	d := declInfo{Name: fn.Name.Name, TestName: "Test" + fn.Name.Name}
	typeMap := map[string]string{}
	if !ast.IsExported(fn.Name.Name) {
		d.TestName = "Test_" + fn.Name.Name
	}
	if fn.Type.TypeParams != nil {
		d.TypeParams = concreteTypes(fn.Type.TypeParams)
		names := typeParamNames(fn.Type.TypeParams)
		for i, name := range names {
			if i < len(d.TypeParams) {
				typeMap[name] = d.TypeParams[i]
			}
		}
		d.UsesGeneric = len(d.TypeParams) > 0
	}
	if fn.Recv != nil && len(fn.Recv.List) > 0 {
		r := fn.Recv.List[0]
		if len(r.Names) > 0 {
			d.RecvName = r.Names[0].Name
		} else {
			d.RecvName = strings.ToLower(string([]rune(receiverBase(r.Type))[0]))
		}
		d.RecvPtr = isStar(r.Type)
		d.RecvBase = receiverBase(r.Type)
		d.RecvTypeParams = receiverParams(r.Type)
		recvNames := receiverParamNames(r.Type)
		for i, name := range recvNames {
			if i < len(d.RecvTypeParams) {
				typeMap[name] = d.RecvTypeParams[i]
			}
		}
		if len(d.RecvTypeParams) > 0 {
			d.UsesGeneric = true
		}
		d.RecvExpr = d.RecvBase
		if len(d.RecvTypeParams) > 0 {
			d.RecvExpr += "[" + strings.Join(d.RecvTypeParams, ", ") + "]"
		}
		d.TestName = "Test" + d.RecvBase + "_" + fn.Name.Name
	}
	d.Params = fields(fset, fn.Type.Params, true)
	d.Results = fields(fset, fn.Type.Results, false)
	applyTypeMap(d.Params, typeMap)
	applyTypeMap(d.Results, typeMap)
	if fn.Type.Params != nil && len(fn.Type.Params.List) > 0 {
		_, d.Variadic = fn.Type.Params.List[len(fn.Type.Params.List)-1].Type.(*ast.Ellipsis)
	}
	return d
}

func typeParamNames(fl *ast.FieldList) []string {
	var out []string
	if fl == nil {
		return out
	}
	for _, f := range fl.List {
		for _, n := range f.Names {
			out = append(out, n.Name)
		}
	}
	return out
}

func applyTypeMap(fields []fieldInfo, m map[string]string) {
	for i := range fields {
		for from, to := range m {
			re := regexp.MustCompile(`\b` + regexp.QuoteMeta(from) + `\b`)
			fields[i].Type = re.ReplaceAllString(fields[i].Type, to)
		}
	}
}

func fields(fset *token.FileSet, fl *ast.FieldList, params bool) []fieldInfo {
	if fl == nil {
		return nil
	}
	var out []fieldInfo
	unnamed := 0
	for _, f := range fl.List {
		typ := exprString(fset, f.Type)
		if el, ok := f.Type.(*ast.Ellipsis); ok {
			typ = "[]" + exprString(fset, el.Elt)
		}
		if len(f.Names) == 0 {
			name := ""
			if params {
				name = fmt.Sprintf("arg%d", unnamed)
			}
			out = append(out, fieldInfo{Name: name, Type: typ})
			unnamed++
			continue
		}
		for _, n := range f.Names {
			out = append(out, fieldInfo{Name: n.Name, Type: typ})
		}
	}
	return out
}

func exprString(fset *token.FileSet, e ast.Expr) string {
	var b bytes.Buffer
	_ = printer.Fprint(&b, fset, e)
	return b.String()
}

func concreteTypes(fl *ast.FieldList) []string {
	var out []string
	for _, f := range fl.List {
		t := "int"
		switch x := f.Type.(type) {
		case *ast.Ident:
			if x.Name == "comparable" {
				t = "string"
			}
		case *ast.BinaryExpr:
			t = exprString(token.NewFileSet(), x.X)
			t = strings.TrimPrefix(t, "~")
		case *ast.UnaryExpr:
			t = strings.TrimPrefix(exprString(token.NewFileSet(), x.X), "~")
		}
		for range f.Names {
			out = append(out, t)
		}
	}
	return out
}

func receiverBase(e ast.Expr) string {
	switch x := e.(type) {
	case *ast.StarExpr:
		return receiverBase(x.X)
	case *ast.Ident:
		return x.Name
	case *ast.IndexExpr:
		return receiverBase(x.X)
	case *ast.IndexListExpr:
		return receiverBase(x.X)
	}
	return "Receiver"
}

func receiverParams(e ast.Expr) []string {
	switch x := e.(type) {
	case *ast.StarExpr:
		return receiverParams(x.X)
	case *ast.IndexExpr:
		return []string{mapTypeParam(exprString(token.NewFileSet(), x.Index))}
	case *ast.IndexListExpr:
		var out []string
		for _, ix := range x.Indices {
			out = append(out, mapTypeParam(exprString(token.NewFileSet(), ix)))
		}
		return out
	}
	return nil
}

func receiverParamNames(e ast.Expr) []string {
	switch x := e.(type) {
	case *ast.StarExpr:
		return receiverParamNames(x.X)
	case *ast.IndexExpr:
		return []string{exprString(token.NewFileSet(), x.Index)}
	case *ast.IndexListExpr:
		var out []string
		for _, ix := range x.Indices {
			out = append(out, exprString(token.NewFileSet(), ix))
		}
		return out
	}
	return nil
}

func mapTypeParam(s string) string {
	if len(s) == 1 && unicode.IsUpper(rune(s[0])) {
		return "int"
	}
	return s
}

func isStar(e ast.Expr) bool {
	_, ok := e.(*ast.StarExpr)
	return ok
}

func filterDecls(decls []declInfo, opt options) ([]declInfo, error) {
	var only, excl *regexp.Regexp
	var err error
	if opt.only != "" {
		only, err = regexp.Compile(opt.only)
		if err != nil {
			return nil, err
		}
	}
	if opt.excl != "" {
		excl, err = regexp.Compile(opt.excl)
		if err != nil {
			return nil, err
		}
	}
	var out []declInfo
	for _, d := range decls {
		name := d.Name
		if d.RecvBase != "" {
			name = d.RecvBase + "." + d.Name
		}
		keep := opt.all || opt.only != "" || opt.exported || opt.excl != ""
		if only != nil {
			keep = only.MatchString(name) || only.MatchString(d.Name)
		} else if opt.exported {
			keep = ast.IsExported(d.Name) && (d.RecvBase == "" || ast.IsExported(d.RecvBase))
		}
		if excl != nil && (excl.MatchString(name) || excl.MatchString(d.Name)) {
			keep = false
		}
		if keep {
			out = append(out, d)
		}
	}
	return out, nil
}

func generate(info fileInfo, opt options) ([]byte, error) {
	var b strings.Builder
	fmt.Fprintf(&b, "package %s\n\n", info.Package)
	imports := importsFor(info, opt)
	if len(imports) == 1 {
		fmt.Fprintf(&b, "import %q\n\n", imports[0].Path)
	} else if len(imports) > 1 {
		b.WriteString("import (\n")
		wroteThirdPartyBreak := false
		for _, im := range imports {
			if !wroteThirdPartyBreak && strings.Contains(im.Path, ".") {
				b.WriteString("\n")
				wroteThirdPartyBreak = true
			}
			if im.Name != "" {
				fmt.Fprintf(&b, "\t%s %q\n", im.Name, im.Path)
			} else {
				fmt.Fprintf(&b, "\t%q\n", im.Path)
			}
		}
		b.WriteString(")\n\n")
	}
	for i, d := range info.Decls {
		if i > 0 {
			b.WriteString("\n")
		}
		writeTest(&b, d, info, opt)
	}
	out, err := format.Source([]byte(b.String()))
	if err != nil {
		return []byte(b.String()), nil
	}
	return out, nil
}

type imp struct{ Name, Path string }

func importsFor(info fileInfo, opt options) []imp {
	need := map[string]imp{"testing": {Path: "testing"}}
	if isTestify(opt) {
		need["assert"] = imp{Path: "github.com/stretchr/testify/assert"}
	}
	needReflect := false
	needCmp := false
	for _, d := range info.Decls {
		for _, f := range append(append([]fieldInfo{}, d.Params...), d.Results...) {
			for name, path := range info.Imports {
				if strings.Contains(f.Type, name+".") {
					need[name] = imp{Path: path}
				}
			}
		}
		if isTestify(opt) {
			continue
		}
		for _, r := range nonErrorResults(d.Results) {
			if !simpleComparable(r.Type) || d.UsesGeneric {
				if opt.useGoCmp {
					needCmp = true
				} else {
					needReflect = true
				}
			}
		}
	}
	if needReflect {
		need["reflect"] = imp{Path: "reflect"}
	}
	if needCmp {
		need["cmp"] = imp{Path: "github.com/google/go-cmp/cmp"}
	}
	var keys []string
	for k := range need {
		keys = append(keys, k)
	}
	sort.Slice(keys, func(i, j int) bool {
		ai := strings.Contains(need[keys[i]].Path, ".")
		aj := strings.Contains(need[keys[j]].Path, ".")
		if ai != aj {
			return !ai
		}
		return need[keys[i]].Path < need[keys[j]].Path
	})
	var out []imp
	for _, k := range keys {
		out = append(out, need[k])
	}
	return out
}

func isTestify(opt options) bool {
	return opt.template == "testify"
}

func writeTest(b *strings.Builder, d declInfo, info fileInfo, opt options) {
	fmt.Fprintf(b, "func %s(t *testing.T) {\n", d.TestName)
	if opt.parallel && !opt.noSubtests {
		b.WriteString("\tt.Parallel()\n")
	}
	if d.RecvBase != "" && len(d.RecvFields) > 0 {
		writeFieldsStruct(b, "fields", d.RecvFields)
	}
	writeFieldsStruct(b, "args", d.Params)
	writeTable(b, d, opt)
	writeLoop(b, d, opt)
	b.WriteString("}\n")
}

func structFields(fset *token.FileSet, st *ast.StructType) []fieldInfo {
	var out []fieldInfo
	for _, f := range st.Fields.List {
		if len(f.Names) == 0 {
			continue
		}
		for _, n := range f.Names {
			if ast.IsExported(n.Name) {
				out = append(out, fieldInfo{Name: n.Name, Type: exprString(fset, f.Type)})
			}
		}
	}
	return out
}

func writeFieldsStruct(b *strings.Builder, name string, fields []fieldInfo) {
	if len(fields) == 0 {
		return
	}
	fmt.Fprintf(b, "\ttype %s struct {\n", name)
	for _, f := range fields {
		fmt.Fprintf(b, "\t\t%s %s\n", f.Name, f.Type)
	}
	b.WriteString("\t}\n")
}

func writeTable(b *strings.Builder, d declInfo, opt options) {
	if opt.named {
		b.WriteString("\ttests := map[string]struct {\n")
	} else {
		b.WriteString("\ttests := []struct {\n\t\tname string\n")
	}
	if d.RecvBase != "" {
		if len(d.RecvTypeParams) > 0 {
			fmt.Fprintf(b, "\t\t%s %s\n", d.RecvName, d.RecvExpr)
		} else if len(d.RecvFields) > 0 {
			b.WriteString("\t\tfields fields\n")
		}
	}
	if len(d.Params) > 0 {
		b.WriteString("\t\targs args\n")
	}
	results := nonErrorResults(d.Results)
	for i, r := range results {
		name := "want"
		if i > 0 {
			name = fmt.Sprintf("want%d", i)
		}
		fmt.Fprintf(b, "\t\t%s %s\n", name, r.Type)
	}
	if hasError(d.Results) && isTestify(opt) {
		b.WriteString("\t\tassertion assert.ErrorAssertionFunc\n")
	} else if hasError(d.Results) {
		b.WriteString("\t\twantErr bool\n")
	}
	b.WriteString("\t}{\n\t\t// TODO: Add test cases.\n\t}\n")
}

func writeLoop(b *strings.Builder, d declInfo, opt options) {
	if opt.named {
		b.WriteString("\tfor name, tt := range tests {\n")
	} else {
		b.WriteString("\tfor _, tt := range tests {\n")
	}
	if !opt.noSubtests {
		name := "tt.name"
		if opt.named {
			name = "name"
		}
		fmt.Fprintf(b, "\t\tt.Run(%s, func(t *testing.T) {\n", name)
		if opt.parallel {
			b.WriteString("\t\t\tt.Parallel()\n")
		}
		writeBody(b, d, opt, "\t\t\t")
		b.WriteString("\t\t})\n")
	} else {
		writeBody(b, d, opt, "\t\t")
	}
	b.WriteString("\t}\n")
}

func writeBody(b *strings.Builder, d declInfo, opt options, ind string) {
	recv := ""
	if d.RecvBase != "" {
		recv = d.RecvName
		if len(d.RecvTypeParams) > 0 {
			fmt.Fprintf(b, "%s%s := %s{}\n", ind, d.RecvName, d.RecvExpr)
		} else {
			ptr := ""
			if d.RecvPtr {
				ptr = "&"
			}
			fmt.Fprintf(b, "%s%s := %s%s{\n", ind, d.RecvName, ptr, d.RecvExpr)
			// field assignments are harmless even when there are no fields.
			b.WriteString(receiverFieldAssignments(d, ind))
			fmt.Fprintf(b, "%s}\n", ind)
		}
	}
	call := callExpr(d, recv)
	if isTestify(opt) {
		writeTestifyBody(b, d, ind, call)
		return
	}
	results := nonErrorResults(d.Results)
	err := hasError(d.Results)
	switch {
	case len(results) == 0 && !err:
		fmt.Fprintf(b, "%s%s\n", ind, call)
	case len(results) == 0 && err:
		fmt.Fprintf(b, "%sif err := %s; (err != nil) != tt.wantErr {\n", ind, call)
		writeErrLine(b, d, opt, ind+"\t", "error", "err", false)
		fmt.Fprintf(b, "%s}\n", ind)
	default:
		if len(results) == 1 && !err {
			got := "got"
			want := "tt.want"
			cond := fmt.Sprintf("%s != %s", got, want)
			deep := false
			if !simpleComparable(results[0].Type) || d.UsesGeneric {
				deep = true
				cond = fmt.Sprintf("!reflect.DeepEqual(%s, %s)", got, want)
				if opt.useGoCmp {
					cond = fmt.Sprintf("!cmp.Equal(%s, %s)", want, got)
				}
			}
			fmt.Fprintf(b, "%sif got := %s; %s {\n", ind, call, cond)
			if opt.useGoCmp && deep {
				writeCmpValueLine(b, d, ind+"\t", 0, got)
			} else {
				writeValueLine(b, d, opt, ind+"\t", 0, got)
			}
			fmt.Fprintf(b, "%s}\n", ind)
			return
		}
		var lhs []string
		for i := range results {
			if i == 0 {
				lhs = append(lhs, "got")
			} else {
				lhs = append(lhs, fmt.Sprintf("got%d", i))
			}
		}
		if err {
			lhs = append(lhs, "err")
		}
		fmt.Fprintf(b, "%s%s := %s\n", ind, strings.Join(lhs, ", "), call)
		if err {
			fmt.Fprintf(b, "%sif (err != nil) != tt.wantErr {\n", ind)
			fatal := !opt.noSubtests
			writeErrLine(b, d, opt, ind+"\t", "error", "err", fatal)
			if fatal {
				fmt.Fprintf(b, "%s}\n", ind)
			} else {
				fmt.Fprintf(b, "%s\tcontinue\n%s}\n", ind, ind)
			}
			fmt.Fprintf(b, "%sif tt.wantErr {\n%s\treturn\n%s}\n", ind, ind, ind)
		}
		for i, r := range results {
			got := "got"
			want := "tt.want"
			if i > 0 {
				got = fmt.Sprintf("got%d", i)
				want = fmt.Sprintf("tt.want%d", i)
			}
			cond := fmt.Sprintf("%s != %s", got, want)
			deep := false
			if !simpleComparable(r.Type) || d.UsesGeneric {
				deep = true
				cond = fmt.Sprintf("!reflect.DeepEqual(%s, %s)", got, want)
				if opt.useGoCmp {
					cond = fmt.Sprintf("!cmp.Equal(%s, %s)", want, got)
				}
			}
			fmt.Fprintf(b, "%sif %s {\n", ind, cond)
			if opt.useGoCmp && deep {
				writeCmpValueLine(b, d, ind+"\t", i, got)
			} else {
				writeValueLine(b, d, opt, ind+"\t", i, got)
			}
			fmt.Fprintf(b, "%s}\n", ind)
		}
	}
}

func writeTestifyBody(b *strings.Builder, d declInfo, ind, call string) {
	results := nonErrorResults(d.Results)
	err := hasError(d.Results)
	switch {
	case len(results) == 0 && !err:
		fmt.Fprintf(b, "%s%s\n", ind, call)
	case len(results) == 0 && err:
		fmt.Fprintf(b, "%stt.assertion(t, %s)\n", ind, call)
	case len(results) == 1 && !err:
		fmt.Fprintf(b, "%sassert.Equal(t, tt.want, %s)\n", ind, call)
	default:
		var lhs []string
		for i := range results {
			if i == 0 {
				lhs = append(lhs, "got")
			} else {
				lhs = append(lhs, fmt.Sprintf("got%d", i))
			}
		}
		if err {
			lhs = append(lhs, "err")
		}
		fmt.Fprintf(b, "%s%s := %s\n", ind, strings.Join(lhs, ", "), call)
		if err {
			fmt.Fprintf(b, "%stt.assertion(t, err)\n", ind)
		}
		for i := range results {
			got := "got"
			want := "tt.want"
			if i > 0 {
				got = fmt.Sprintf("got%d", i)
				want = fmt.Sprintf("tt.want%d", i)
			}
			fmt.Fprintf(b, "%sassert.Equal(t, %s, %s)\n", ind, want, got)
		}
	}
}

func writeCmpValueLine(b *strings.Builder, d declInfo, ind string, idx int, got string) {
	name := displayName(d)
	want := "tt.want"
	if idx > 0 {
		want = fmt.Sprintf("tt.want%d", idx)
	}
	if len(nonErrorResults(d.Results)) > 1 {
		suffix := "got"
		if idx > 0 {
			suffix = fmt.Sprintf("got%d", idx)
		}
		fmt.Fprintf(b, "%st.Errorf(\"%s() %s = %%v, want %%v\\ndiff=%%s\", %s, %s, cmp.Diff(%s, %s))\n", ind, name, suffix, got, want, want, got)
		return
	}
	fmt.Fprintf(b, "%st.Errorf(\"%s() = %%v, want %%v\\ndiff=%%s\", %s, %s, cmp.Diff(%s, %s))\n", ind, name, got, want, want, got)
}

func receiverFieldAssignments(d declInfo, ind string) string {
	var b strings.Builder
	for _, f := range d.RecvFields {
		fmt.Fprintf(&b, "%s\t%s: tt.fields.%s,\n", ind, f.Name, f.Name)
	}
	return b.String()
}

func callExpr(d declInfo, recv string) string {
	name := d.Name
	if recv != "" {
		name = recv + "." + d.Name
	} else if len(d.TypeParams) > 0 {
		name += "[" + strings.Join(d.TypeParams, ", ") + "]"
	}
	var args []string
	for i, p := range d.Params {
		a := "tt.args." + p.Name
		if d.Variadic && i == len(d.Params)-1 {
			a += "..."
		}
		args = append(args, a)
	}
	return fmt.Sprintf("%s(%s)", name, strings.Join(args, ", "))
}

func writeErrLine(b *strings.Builder, d declInfo, opt options, ind, label, errvar string, fatal bool) {
	fn := "Errorf"
	if fatal {
		fn = "Fatalf"
	}
	prefix := ""
	args := ""
	if opt.noSubtests {
		prefix = "%q. "
		args = "tt.name, "
	}
	name := displayName(d)
	if opt.inputs && len(d.Params) > 0 {
		fmt.Fprintf(b, "%st.%s(\"%s%s(%s) %s = %%v, wantErr %%v\", %s%s, tt.wantErr)\n", ind, fn, prefix, name, inputFormats(d), label, args, inputArgs(d, errvar))
		return
	}
	fmt.Fprintf(b, "%st.%s(\"%s%s() %s = %%v, wantErr %%v\", %s%s, tt.wantErr)\n", ind, fn, prefix, name, label, args, errvar)
}

func writeValueLine(b *strings.Builder, d declInfo, opt options, ind string, idx int, got string) {
	name := displayName(d)
	want := "tt.want"
	if idx > 0 {
		want = fmt.Sprintf("tt.want%d", idx)
	}
	prefix := ""
	args := ""
	if opt.noSubtests {
		prefix = "%q. "
		args = "tt.name, "
	}
	if opt.inputs && len(d.Params) > 0 && idx == 0 {
		fmt.Fprintf(b, "%st.Errorf(\"%s%s(%s) = %%v, want %%v\", %s%s, %s)\n", ind, prefix, name, inputFormats(d), args, inputArgs(d, got), want)
		return
	}
	if len(nonErrorResults(d.Results)) > 1 {
		suffix := "got"
		if idx > 0 {
			suffix = fmt.Sprintf("got%d", idx)
		}
		fmt.Fprintf(b, "%st.Errorf(\"%s%s() %s = %%v, want %%v\", %s%s, %s)\n", ind, prefix, name, suffix, args, got, want)
		return
	}
	fmt.Fprintf(b, "%st.Errorf(\"%s%s() = %%v, want %%v\", %s%s, %s)\n", ind, prefix, name, args, got, want)
}

func displayName(d declInfo) string {
	if d.RecvBase != "" {
		if len(d.RecvTypeParams) > 0 {
			return d.RecvBase + "[T]." + d.Name
		}
		return d.RecvBase + "." + d.Name
	}
	return d.Name
}

func inputFormats(d declInfo) string {
	parts := make([]string, len(d.Params))
	for i := range parts {
		parts[i] = "%v"
	}
	return strings.Join(parts, ", ")
}

func inputArgs(d declInfo, tail string) string {
	var args []string
	for _, p := range d.Params {
		args = append(args, "tt.args."+p.Name)
	}
	args = append(args, tail)
	return strings.Join(args, ", ")
}

func hasError(results []fieldInfo) bool {
	return len(results) > 0 && results[len(results)-1].Type == "error"
}

func nonErrorResults(results []fieldInfo) []fieldInfo {
	if hasError(results) {
		return results[:len(results)-1]
	}
	return results
}

func simpleComparable(t string) bool {
	switch t {
	case "bool", "string", "error":
		return true
	}
	if strings.HasPrefix(t, "*") || strings.HasPrefix(t, "chan ") || strings.HasPrefix(t, "<-chan ") || strings.HasPrefix(t, "chan<- ") {
		return true
	}
	if strings.HasPrefix(t, "int") || strings.HasPrefix(t, "uint") || strings.HasPrefix(t, "float") || strings.HasPrefix(t, "complex") || t == "byte" || t == "rune" {
		return true
	}
	return false
}
