module gotests-reimpl

go 1.21
