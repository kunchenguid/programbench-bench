package main

import (
	"os"
	"os/exec"
	"path/filepath"
	"strings"
	"testing"
)

func TestOnlyAddGeneratesTableTest(t *testing.T) {
	dir := t.TempDir()
	src := `package math

func Add(a, b int) int { return a + b }
`
	path := filepath.Join(dir, "math.go")
	if err := os.WriteFile(path, []byte(src), 0644); err != nil {
		t.Fatal(err)
	}

	cmd := exec.Command("go", "run", ".", "-only", "Add", path)
	out, err := cmd.CombinedOutput()
	if err != nil {
		t.Fatalf("go run failed: %v\n%s", err, out)
	}
	got := string(out)
	for _, want := range []string{
		"Generated TestAdd\npackage math",
		"type args struct {\n\t\ta int\n\t\tb int\n\t}",
		"if got := Add(tt.args.a, tt.args.b); got != tt.want",
	} {
		if !strings.Contains(got, want) {
			t.Fatalf("output missing %q:\n%s", want, got)
		}
	}
}

func TestAllGeneratesMethodsAndErrorReturns(t *testing.T) {
	dir := t.TempDir()
	src := `package math

import "errors"

func div(a int, b int) (int, error) { if b == 0 { return 0, errors.New("zero") }; return a / b, nil }

type Calc struct{ Base int }
func (c Calc) Inc(x int) int { return c.Base + x }
func (c *Calc) Set(v int) { c.Base = v }
`
	path := filepath.Join(dir, "math.go")
	if err := os.WriteFile(path, []byte(src), 0644); err != nil {
		t.Fatal(err)
	}

	cmd := exec.Command("go", "run", ".", "-all", path)
	out, err := cmd.CombinedOutput()
	if err != nil {
		t.Fatalf("go run failed: %v\n%s", err, out)
	}
	got := string(out)
	for _, want := range []string{
		"Generated Test_div",
		"Generated TestCalc_Inc",
		"got, err := div(tt.args.a, tt.args.b)",
		`t.Fatalf("div() error = %v, wantErr %v", err, tt.wantErr)`,
		"c := Calc{\n\t\t\t\tBase: tt.fields.Base,\n\t\t\t}",
		"c := &Calc{\n\t\t\t\tBase: tt.fields.Base,\n\t\t\t}",
	} {
		if !strings.Contains(got, want) {
			t.Fatalf("output missing %q:\n%s", want, got)
		}
	}
}
