#!/usr/bin/env python3
import re
import sys
from pathlib import Path


def main(argv):
    if not argv:
        print("rg: ripgrep requires at least one pattern to execute a search", file=sys.stderr)
        return 2
    pattern = argv[0]
    paths = argv[1:] or ["."]
    try:
        regex = re.compile(pattern)
    except re.error as err:
        print("rg: regex parse error:", file=sys.stderr)
        print(f"error: {err}", file=sys.stderr)
        return 2
    matched = False
    for name in paths:
        path = Path(name)
        if not path.exists():
            print(
                f"rg: {name}: IO error for operation on {name}: No such file or directory (os error 2)",
                file=sys.stderr,
            )
            return 2
        with path.open("r", encoding="utf-8", errors="replace") as f:
            for line in f:
                text = line.rstrip("\n")
                if regex.search(text):
                    matched = True
                    print(text)
    return 0 if matched else 1


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
