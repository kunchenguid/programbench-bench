#!/usr/bin/env python3
import base64
import fnmatch
import json
import os
import re
import stat
import sys
import time
from dataclasses import dataclass, field
from pathlib import Path


VERSION = """ripgrep 14.1.1 (rev 719e15af5e)

features:-pcre2
simd(compile):+SSE2,-SSSE3,-AVX2
simd(runtime):+SSE2,+SSSE3,+AVX2

PCRE2 is not available in this build of ripgrep."""

SHORT_HELP = """ripgrep 14.1.1 (rev 719e15af5e)
Andrew Gallant <jamslam@gmail.com>

ripgrep (rg) recursively searches the current directory for lines matching
a regex pattern. By default, ripgrep will respect gitignore rules and
automatically skip hidden files/directories and binary files.

Use -h for short descriptions and --help for more details.

Project home page: https://github.com/BurntSushi/ripgrep

USAGE:
  rg [OPTIONS] PATTERN [PATH ...]

POSITIONAL ARGUMENTS:
  <PATTERN>   A regular expression used for searching.
  <PATH>...   A file or directory to search.

INPUT OPTIONS:
  -e, --regexp=PATTERN            A pattern to search for.
  -f, --file=PATTERNFILE          Search for patterns from the given file.

SEARCH OPTIONS:
  -F, --fixed-strings             Treat all patterns as literals.
  -i, --ignore-case               Case insensitive search.
  -v, --invert-match              Invert matching.
  -x, --line-regexp               Show matches surrounded by line boundaries.
  -m, --max-count=NUM             Limit the number of matching lines.
  -S, --smart-case                Smart case search.
  -a, --text                      Search binary files as if they were text.
  -w, --word-regexp               Show matches surrounded by word boundaries.

FILTER OPTIONS:
  -., --hidden                    Search hidden files and directories.
  -g, --glob=GLOB                 Include or exclude file paths.
  -d, --max-depth=NUM             Descend at most NUM directories.
  --no-ignore                     Don't use ignore files.
  -u, --unrestricted              Reduce the level of "smart" filtering.

OUTPUT OPTIONS:
  -A, --after-context=NUM         Show NUM lines after each match.
  -B, --before-context=NUM        Show NUM lines before each match.
  -b, --byte-offset               Print the byte offset for each matching line.
  --column                        Show column numbers.
  -C, --context=NUM               Show NUM lines before and after each match.
  -n, --line-number               Show line numbers.
  -N, --no-line-number            Suppress line numbers.
  -0, --null                      Print a NUL byte after file paths.
  -o, --only-matching             Print only matched parts of a line.
  -q, --quiet                     Do not print anything to stdout.
  -r, --replace=TEXT              Replace matches with the given text.
  --sort=SORTBY                   Sort results in ascending order.
  --trim                          Trim prefix whitespace from matches.
  --vimgrep                       Print results in a vim compatible format.
  -H, --with-filename             Print the file path with each matching line.
  -I, --no-filename               Never print the path with each matching line.

OUTPUT MODES:
  -c, --count                     Show count of matching lines for each file.
  --count-matches                 Show count of every match for each file.
  -l, --files-with-matches        Print the paths with at least one match.
  --files-without-match           Print the paths that contain zero matches.
  --json                          Show search results in a JSON Lines format.

OTHER BEHAVIORS:
  --files                         Print each file that would be searched.
  --type-list                     Show all supported file types.
  -V, --version                   Print ripgrep's version."""


TYPES = {
    "c": ["*.c", "*.h"],
    "cpp": ["*.cc", "*.cpp", "*.cxx", "*.hpp", "*.hh", "*.hxx"],
    "go": ["*.go"],
    "html": ["*.html", "*.htm"],
    "java": ["*.java"],
    "js": ["*.js", "*.jsx", "*.mjs", "*.cjs"],
    "json": ["*.json"],
    "md": ["*.md", "*.markdown"],
    "py": ["*.py", "*.pyw"],
    "rs": ["*.rs"],
    "sh": ["*.sh", "*.bash", "*.zsh"],
    "toml": ["*.toml"],
    "ts": ["*.ts", "*.tsx"],
    "txt": ["*.txt"],
    "xml": ["*.xml"],
    "yaml": ["*.yaml", "*.yml"],
}


@dataclass
class Config:
    patterns: list[str] = field(default_factory=list)
    paths: list[str] = field(default_factory=list)
    ignore_case: bool = False
    smart_case: bool = False
    fixed: bool = False
    invert: bool = False
    whole_line: bool = False
    word: bool = False
    text: bool = False
    hidden: bool = False
    no_ignore: bool = False
    line_number: bool = False
    no_line_number: bool = False
    with_filename: bool | None = None
    count: bool = False
    count_matches: bool = False
    include_zero: bool = False
    files_with_matches: bool = False
    files_without_match: bool = False
    only_matching: bool = False
    vimgrep: bool = False
    column: bool = False
    byte_offset: bool = False
    quiet: bool = False
    files: bool = False
    type_list: bool = False
    globs: list[str] = field(default_factory=list)
    type_includes: list[str] = field(default_factory=list)
    type_excludes: list[str] = field(default_factory=list)
    max_depth: int | None = None
    max_count: int | None = None
    before: int = 0
    after: int = 0
    passthru: bool = False
    trim: bool = False
    null: bool = False
    null_data: bool = False
    sort: str | None = None
    reverse_sort: bool = False
    replace: str | None = None
    json: bool = False
    stats: bool = False
    max_filesize: int | None = None
    had_error: bool = False


class ArgError(Exception):
    pass


def die(message):
    print(f"rg: {message}", file=sys.stderr)
    return 2


def split_long(arg):
    if "=" in arg:
        key, val = arg.split("=", 1)
        return key, val
    return arg, None


def parse_size(s):
    m = re.fullmatch(r"([0-9]+)([KMGkmg]?)", s)
    if not m:
        raise ArgError(f"invalid size: {s}")
    n = int(m.group(1))
    return n * {"": 1, "k": 1024, "m": 1024**2, "g": 1024**3}[m.group(2).lower()]


def parse_args(argv):
    cfg = Config()
    positional = []
    i = 0
    stop_flags = False

    def need_value(current, attached=None):
        nonlocal i
        if attached is not None and attached != "":
            return attached
        i += 1
        if i >= len(argv):
            raise ArgError(f"The argument '{current}' requires a value but none was supplied")
        return argv[i]

    while i < len(argv):
        arg = argv[i]
        if stop_flags:
            positional.append(arg)
            i += 1
            continue
        if arg == "--":
            stop_flags = True
            i += 1
            continue
        if arg in ("--help", "-h"):
            print(SHORT_HELP)
            raise SystemExit(0)
        if arg in ("--version", "-V"):
            print(VERSION)
            raise SystemExit(0)
        if arg.startswith("--") and arg != "--":
            opt, val = split_long(arg)
            if opt == "--regexp":
                cfg.patterns.append(need_value(opt, val))
            elif opt == "--file":
                read_pattern_file(cfg, need_value(opt, val))
            elif opt == "--fixed-strings":
                cfg.fixed = True
            elif opt == "--no-fixed-strings":
                cfg.fixed = False
            elif opt == "--ignore-case":
                cfg.ignore_case = True
                cfg.smart_case = False
            elif opt == "--case-sensitive":
                cfg.ignore_case = False
                cfg.smart_case = False
            elif opt == "--smart-case":
                cfg.smart_case = True
            elif opt == "--invert-match":
                cfg.invert = True
            elif opt == "--line-regexp":
                cfg.whole_line = True
            elif opt == "--word-regexp":
                cfg.word = True
            elif opt in ("--text", "--binary"):
                cfg.text = True
            elif opt == "--hidden":
                cfg.hidden = True
            elif opt.startswith("--no-ignore"):
                cfg.no_ignore = True
            elif opt == "--unrestricted":
                cfg.no_ignore = True
            elif opt == "--line-number":
                cfg.line_number = True
                cfg.no_line_number = False
            elif opt == "--no-line-number":
                cfg.no_line_number = True
                cfg.line_number = False
            elif opt == "--with-filename":
                cfg.with_filename = True
            elif opt == "--no-filename":
                cfg.with_filename = False
            elif opt == "--count":
                cfg.count = True
                cfg.count_matches = False
            elif opt == "--count-matches":
                cfg.count_matches = True
                cfg.count = False
            elif opt == "--include-zero":
                cfg.include_zero = True
            elif opt == "--files-with-matches":
                cfg.files_with_matches = True
            elif opt == "--files-without-match":
                cfg.files_without_match = True
            elif opt == "--only-matching":
                cfg.only_matching = True
            elif opt == "--vimgrep":
                cfg.vimgrep = True
                cfg.line_number = True
                cfg.column = True
                cfg.with_filename = True
            elif opt == "--column":
                cfg.column = True
            elif opt == "--byte-offset":
                cfg.byte_offset = True
            elif opt == "--quiet":
                cfg.quiet = True
            elif opt == "--files":
                cfg.files = True
            elif opt == "--type-list":
                cfg.type_list = True
            elif opt == "--glob":
                cfg.globs.append(need_value(opt, val))
            elif opt == "--iglob":
                cfg.globs.append(need_value(opt, val))
            elif opt == "--type":
                cfg.type_includes.append(need_value(opt, val))
            elif opt == "--type-not":
                cfg.type_excludes.append(need_value(opt, val))
            elif opt == "--type-add":
                add_type(need_value(opt, val))
            elif opt == "--type-clear":
                TYPES.pop(need_value(opt, val), None)
            elif opt == "--max-depth":
                cfg.max_depth = int(need_value(opt, val))
            elif opt == "--max-count":
                cfg.max_count = int(need_value(opt, val))
            elif opt == "--after-context":
                cfg.after = int(need_value(opt, val))
            elif opt == "--before-context":
                cfg.before = int(need_value(opt, val))
            elif opt == "--context":
                cfg.before = cfg.after = int(need_value(opt, val))
            elif opt in ("--passthru", "--passthrough"):
                cfg.passthru = True
            elif opt == "--trim":
                cfg.trim = True
            elif opt == "--null":
                cfg.null = True
            elif opt == "--null-data":
                cfg.null_data = True
                cfg.text = True
            elif opt == "--sort":
                cfg.sort = need_value(opt, val)
                cfg.reverse_sort = False
            elif opt == "--sortr":
                cfg.sort = need_value(opt, val)
                cfg.reverse_sort = True
            elif opt == "--sort-files":
                cfg.sort = "path"
            elif opt == "--replace":
                cfg.replace = need_value(opt, val)
            elif opt == "--json":
                cfg.json = True
                cfg.stats = True
            elif opt == "--stats":
                cfg.stats = True
            elif opt == "--max-filesize":
                cfg.max_filesize = parse_size(need_value(opt, val))
            elif opt in ("--no-config", "--mmap", "--no-mmap", "--color", "--colors",
                         "--engine", "--regex-size-limit", "--dfa-size-limit",
                         "--encoding", "--no-encoding", "--threads", "--crlf",
                         "--no-crlf", "--multiline", "--no-multiline",
                         "--multiline-dotall", "--no-unicode", "--unicode",
                         "--search-zip", "--no-search-zip", "--block-buffered",
                         "--line-buffered", "--no-line-buffered",
                         "--max-columns", "--max-columns-preview",
                         "--path-separator", "--context-separator",
                         "--field-context-separator", "--field-match-separator",
                         "--heading", "--no-heading", "--pretty", "--debug",
                         "--trace", "--no-messages", "--no-ignore-messages",
                         "--pcre2", "--no-pcre2", "--auto-hybrid-regex",
                         "--no-pcre2-unicode", "--follow", "--one-file-system",
                         "--no-require-git", "--glob-case-insensitive",
                         "--ignore-file", "--ignore-file-case-insensitive",
                         "--pre", "--pre-glob", "--hostname-bin",
                         "--hyperlink-format"):
                if opt in {"--color", "--colors", "--engine", "--regex-size-limit",
                           "--dfa-size-limit", "--encoding", "--threads",
                           "--max-columns", "--path-separator", "--context-separator",
                           "--field-context-separator", "--field-match-separator",
                           "--ignore-file", "--pre", "--pre-glob", "--hostname-bin",
                           "--hyperlink-format"} and val is None:
                    need_value(opt)
            elif opt == "--pcre2-version":
                print("PCRE2 is not available in this build of ripgrep.", file=sys.stderr)
                raise SystemExit(2)
            elif opt == "--generate":
                kind = need_value(opt, val)
                print(f"rg: unrecognized generation kind: {kind}", file=sys.stderr)
                raise SystemExit(2)
            else:
                raise ArgError(f"unrecognized flag {arg}")
            i += 1
            continue
        if arg.startswith("-") and arg != "-":
            j = 1
            while j < len(arg):
                ch = arg[j]
                rest = arg[j + 1 :]
                if ch == "e":
                    cfg.patterns.append(need_value("-e", rest))
                    break
                if ch == "f":
                    read_pattern_file(cfg, need_value("-f", rest))
                    break
                if ch == "g":
                    cfg.globs.append(need_value("-g", rest))
                    break
                if ch == "t":
                    cfg.type_includes.append(need_value("-t", rest))
                    break
                if ch == "T":
                    cfg.type_excludes.append(need_value("-T", rest))
                    break
                if ch == "d":
                    cfg.max_depth = int(need_value("-d", rest))
                    break
                if ch == "m":
                    cfg.max_count = int(need_value("-m", rest))
                    break
                if ch == "A":
                    cfg.after = int(need_value("-A", rest))
                    break
                if ch == "B":
                    cfg.before = int(need_value("-B", rest))
                    break
                if ch == "C":
                    cfg.before = cfg.after = int(need_value("-C", rest))
                    break
                if ch == "r":
                    cfg.replace = need_value("-r", rest)
                    break
                if ch == "n":
                    cfg.line_number = True
                    cfg.no_line_number = False
                elif ch == "N":
                    cfg.no_line_number = True
                    cfg.line_number = False
                elif ch == "H":
                    cfg.with_filename = True
                elif ch == "I":
                    cfg.with_filename = False
                elif ch == "i":
                    cfg.ignore_case = True
                    cfg.smart_case = False
                elif ch == "s":
                    cfg.ignore_case = False
                    cfg.smart_case = False
                elif ch == "S":
                    cfg.smart_case = True
                elif ch == "F":
                    cfg.fixed = True
                elif ch == "v":
                    cfg.invert = True
                elif ch == "x":
                    cfg.whole_line = True
                elif ch == "w":
                    cfg.word = True
                elif ch == "a":
                    cfg.text = True
                elif ch == ".":
                    cfg.hidden = True
                elif ch == "u":
                    cfg.no_ignore = True
                    if arg.count("u") >= 2:
                        cfg.hidden = True
                    if arg.count("u") >= 3:
                        cfg.text = True
                    break
                elif ch == "c":
                    cfg.count = True
                    cfg.count_matches = False
                elif ch == "l":
                    cfg.files_with_matches = True
                elif ch == "o":
                    cfg.only_matching = True
                elif ch == "q":
                    cfg.quiet = True
                elif ch == "0":
                    cfg.null = True
                elif ch == "b":
                    cfg.byte_offset = True
                elif ch == "p":
                    cfg.line_number = True
                elif ch == "z" or ch in "LP":
                    pass
                else:
                    raise ArgError(f"unrecognized flag -{ch}")
                j += 1
            i += 1
            continue
        positional.append(arg)
        i += 1

    if not cfg.patterns and not cfg.files and not cfg.type_list:
        if not positional:
            raise ArgError("ripgrep requires at least one pattern to execute a search")
        cfg.patterns.append(positional[0])
        cfg.paths = positional[1:]
    else:
        cfg.paths = positional
    if not cfg.paths:
        mode = os.fstat(0).st_mode
        piped_stdin = stat.S_ISFIFO(mode)
        cfg.paths = ["-" if piped_stdin and not cfg.files else "."]
    return cfg


def read_pattern_file(cfg, name):
    if name == "-":
        data = sys.stdin.read().splitlines()
    else:
        try:
            data = Path(name).read_text(encoding="utf-8", errors="replace").splitlines()
        except OSError as err:
            raise ArgError(f"{name}: {err.strerror}") from err
    cfg.patterns.extend(data)


def add_type(spec):
    if ":" not in spec:
        raise ArgError(f"invalid type spec: {spec}")
    name, glob = spec.split(":", 1)
    TYPES.setdefault(name, []).append(glob)


def compile_regex(cfg):
    pats = cfg.patterns or [""]
    out = []
    for p in pats:
        if cfg.fixed:
            p = re.escape(p)
        if cfg.word:
            p = r"\b(?:" + p + r")\b"
        if cfg.whole_line:
            p = r"^(?:" + p + r")$"
        out.append(p)
    flags = re.MULTILINE
    ignore = cfg.ignore_case or (cfg.smart_case and not any(any(c.isupper() for c in p) for p in pats))
    if ignore:
        flags |= re.IGNORECASE
    try:
        return re.compile("|".join(f"(?:{p})" for p in out), flags)
    except re.error as err:
        print("rg: regex parse error:", file=sys.stderr)
        print(f"    (?:{pats[0]})", file=sys.stderr)
        print(f"error: {err}", file=sys.stderr)
        raise SystemExit(2)


def is_hidden(path):
    return any(part.startswith(".") and part not in (".", "..") for part in path.parts)


def load_ignore_file(path):
    rules = []
    try:
        for line in path.read_text(encoding="utf-8", errors="replace").splitlines():
            line = line.strip()
            if not line or line.startswith("#"):
                continue
            rules.append(line)
    except OSError:
        pass
    return rules


def ignored(rel, rules):
    s = rel.as_posix()
    base = rel.name
    ignored_now = False
    for rule in rules:
        neg = rule.startswith("!")
        pat = rule[1:] if neg else rule
        pat = pat.rstrip("/")
        hit = fnmatch.fnmatch(s, pat) or fnmatch.fnmatch(base, pat)
        if not hit and "/" not in pat:
            hit = any(fnmatch.fnmatch(part, pat) for part in rel.parts)
        if hit:
            ignored_now = not neg
    return ignored_now


def matches_globs(rel, cfg):
    include_seen = False
    included = True
    s = rel.as_posix()
    for g in cfg.globs:
        neg = g.startswith("!")
        pat = g[1:] if neg else g
        hit = fnmatch.fnmatch(s, pat) or fnmatch.fnmatch(rel.name, pat)
        if neg and hit:
            return False
        if not neg:
            include_seen = True
            included = included and hit
    return included if include_seen else True


def matches_types(path, cfg):
    def in_type(type_name):
        return any(fnmatch.fnmatch(path.name, pat) for pat in TYPES.get(type_name, []))

    if cfg.type_includes and not any(in_type(t) for t in cfg.type_includes):
        return False
    if cfg.type_excludes and any(in_type(t) for t in cfg.type_excludes):
        return False
    return True


def discover(paths, cfg):
    files = []
    cwd = Path.cwd()
    root_rules = [] if cfg.no_ignore else sum((load_ignore_file(cwd / n) for n in [".gitignore", ".ignore", ".rgignore"]), [])
    for raw in paths:
        if raw == "-":
            files.append(Path("-"))
            continue
        p = Path(raw)
        if not p.exists():
            print(f"rg: {raw}: IO error for operation on {raw}: No such file or directory (os error 2)", file=sys.stderr)
            cfg.had_error = True
            continue
        if p.is_file() or p.is_symlink():
            files.append(p)
            continue
        base_depth = len(p.resolve().parts)
        for dirpath, dirnames, filenames in os.walk(p, followlinks=False):
            d = Path(dirpath)
            try:
                rel_dir = d.relative_to(cwd)
            except ValueError:
                rel_dir = d
            depth = len(d.resolve().parts) - base_depth
            if cfg.max_depth is not None and depth >= cfg.max_depth:
                dirnames[:] = []
            keep_dirs = []
            for name in dirnames:
                child_rel = rel_dir / name
                if not cfg.hidden and name.startswith("."):
                    continue
                if root_rules and ignored(child_rel, root_rules):
                    continue
                keep_dirs.append(name)
            dirnames[:] = keep_dirs
            for name in filenames:
                f = d / name
                try:
                    rel = f.relative_to(cwd)
                except ValueError:
                    rel = f
                if not cfg.hidden and (name.startswith(".") or is_hidden(rel)):
                    continue
                if root_rules and ignored(rel, root_rules):
                    continue
                if not matches_globs(rel, cfg) or not matches_types(f, cfg):
                    continue
                if cfg.max_filesize is not None:
                    try:
                        if f.stat().st_size > cfg.max_filesize:
                            continue
                    except OSError:
                        continue
                files.append(f)
    if cfg.sort == "path":
        files.sort(key=lambda x: rel_display(x), reverse=cfg.reverse_sort)
    return files


def rel_display(path):
    if str(path) == "-":
        return "<stdin>"
    try:
        return path.relative_to(Path.cwd()).as_posix()
    except ValueError:
        return path.as_posix()


def is_binary(path):
    if str(path) == "-":
        return False
    try:
        with path.open("rb") as f:
            return b"\0" in f.read(8192)
    except OSError:
        return False


def read_lines(path, cfg):
    sep = "\0" if cfg.null_data else "\n"
    try:
        if str(path) == "-":
            data = sys.stdin.read()
        else:
            data = path.read_text(encoding="utf-8", errors="replace")
    except OSError as err:
        print(f"rg: {rel_display(path)}: {err.strerror}", file=sys.stderr)
        cfg.had_error = True
        return None
    parts = data.split(sep)
    lines = []
    offset = 0
    for idx, part in enumerate(parts):
        if idx == len(parts) - 1 and part == "":
            break
        line = part + (sep if idx < len(parts) - 1 else "")
        clean = line[:-1] if line.endswith(sep) else line
        lines.append((idx + 1, offset, clean))
        offset += len(line.encode("utf-8", errors="replace"))
    return lines


def repl_text(template, match):
    out = ""
    i = 0
    while i < len(template):
        if template[i] == "$":
            if i + 1 < len(template) and template[i + 1] == "$":
                out += "$"
                i += 2
                continue
            j = i + 1
            if j < len(template) and template[j] == "{":
                k = template.find("}", j + 1)
                if k != -1:
                    name = template[j + 1 : k]
                    out += group(match, name)
                    i = k + 1
                    continue
            while j < len(template) and (template[j].isalnum() or template[j] == "_"):
                j += 1
            if j > i + 1:
                out += group(match, template[i + 1 : j])
                i = j
                continue
        out += template[i]
        i += 1
    return out


def group(match, name):
    try:
        if name.isdigit():
            return match.group(int(name)) or ""
        return match.group(name) or ""
    except Exception:
        return ""


def json_data(s):
    try:
        s.encode("utf-8")
        return {"text": s}
    except UnicodeError:
        return {"bytes": base64.b64encode(s.encode("utf-8", "surrogateescape")).decode("ascii")}


def print_json(obj):
    print(json.dumps(obj, separators=(",", ":")))


def emit_line(prefix_parts, text, cfg, end="\n"):
    if cfg.trim:
        text = text.lstrip(" \t\r\n\v\f")
    print("".join(prefix_parts) + text, end=end)


def search_file(path, regex, cfg, show_filename):
    name = rel_display(path)
    if not cfg.text and is_binary(path):
        return False, 0, 0
    lines = read_lines(path, cfg)
    if lines is None:
        return False, 0, 0
    file_has_match = False
    matched_lines = 0
    match_count = 0
    emitted = 0
    before_buf = []
    after_left = 0
    began_json = False

    for line_no, byte_off, line in lines:
        matches = list(regex.finditer(line))
        line_match = bool(matches)
        if cfg.invert:
            line_match = not line_match
            matches = []
        if cfg.passthru:
            line_match = True
        if line_match and not cfg.passthru:
            file_has_match = True
            matched_lines += 1
            match_count += max(1, len(matches))
        elif cfg.passthru and matches:
            file_has_match = True
            matched_lines += 1
            match_count += len(matches)

        if cfg.max_count is not None and matched_lines > cfg.max_count:
            break
        if not line_match:
            if cfg.before:
                before_buf.append((line_no, byte_off, line))
                before_buf = before_buf[-cfg.before :]
            if after_left > 0:
                emit_record(name, line_no, byte_off, line, [], cfg, show_filename, context=True)
                after_left -= 1
            continue

        if cfg.quiet:
            return True, matched_lines, match_count
        if cfg.count or cfg.count_matches or cfg.files_with_matches or cfg.files_without_match:
            continue
        if cfg.json and not began_json:
            print_json({"type": "begin", "data": {"path": json_data(name)}})
            began_json = True
        for b in before_buf:
            emit_record(name, b[0], b[1], b[2], [], cfg, show_filename, context=True)
        before_buf = []
        if cfg.only_matching and not cfg.invert:
            for m in matches:
                text = repl_text(cfg.replace, m) if cfg.replace is not None else m.group(0)
                emit_record(name, line_no, byte_off + len(line[: m.start()].encode()), text, [m], cfg, show_filename, only=True, col=m.start() + 1)
                emitted += 1
        elif cfg.vimgrep and matches:
            for m in matches:
                emit_record(name, line_no, byte_off, line, [m], cfg, show_filename, col=m.start() + 1)
                emitted += 1
        else:
            out_line = regex.sub(lambda m: repl_text(cfg.replace, m), line) if cfg.replace is not None and not cfg.invert else line
            emit_record(name, line_no, byte_off, out_line, matches, cfg, show_filename)
            emitted += 1
        after_left = cfg.after
        if cfg.max_count is not None and matched_lines >= cfg.max_count:
            break
    if cfg.json and began_json:
        print_json({"type": "end", "data": {"path": json_data(name), "stats": {"matches": match_count, "matched_lines": matched_lines}}})
    return file_has_match, matched_lines, match_count


def emit_record(name, line_no, byte_off, text, matches, cfg, show_filename, context=False, only=False, col=None):
    if cfg.json:
        kind = "context" if context else "match"
        submatches = []
        for m in matches:
            submatches.append({"match": json_data(m.group(0)), "start": m.start(), "end": m.end()})
        print_json({"type": kind, "data": {"path": json_data(name), "lines": json_data(text + "\n"), "line_number": line_no, "absolute_offset": byte_off, "submatches": submatches}})
        return
    sep = "-" if context else ":"
    parts = []
    if show_filename:
        parts.append(name)
        parts.append("\0" if cfg.null else sep)
    if cfg.line_number:
        parts.append(str(line_no))
        parts.append(sep)
    if cfg.column:
        parts.append(str(col if col is not None else (matches[0].start() + 1 if matches else 1)))
        parts.append(sep)
    if cfg.byte_offset:
        parts.append(str(byte_off))
        parts.append(sep)
    emit_line(parts, text, cfg)


def should_show_filename(cfg, paths, files):
    if cfg.with_filename is not None:
        return cfg.with_filename
    if cfg.files_with_matches or cfg.files_without_match or cfg.files:
        return True
    if len(files) > 1:
        return True
    if len(paths) != 1:
        return True
    return Path(paths[0]).is_dir()


def run(cfg):
    if cfg.type_list:
        for name in sorted(TYPES):
            print(f"{name}: {', '.join(TYPES[name])}")
        return 0
    files = discover(cfg.paths, cfg)
    if cfg.files:
        end = "\0" if cfg.null else "\n"
        for p in files:
            print(rel_display(p), end=end)
        return 0 if files else 1
    regex = compile_regex(cfg)
    show_filename = should_show_filename(cfg, cfg.paths, files)
    any_match = False
    searched = 0
    total_lines = 0
    total_matches = 0
    start = time.time()
    for p in files:
        searched += 1
        has, lines, matches = search_file(p, regex, cfg, show_filename)
        any_match = any_match or has
        total_lines += lines
        total_matches += matches
        if cfg.quiet and has:
            return 0
        if cfg.files_with_matches and has:
            print(rel_display(p), end="\0" if cfg.null else "\n")
        elif cfg.files_without_match and not has:
            print(rel_display(p), end="\0" if cfg.null else "\n")
        elif cfg.count or cfg.count_matches:
            count = matches if cfg.count_matches or cfg.only_matching else lines
            if count or cfg.include_zero:
                prefix = f"{rel_display(p)}:" if show_filename else ""
                print(f"{prefix}{count}")
    if cfg.json:
        elapsed = time.time() - start
        print_json({"type": "summary", "data": {"elapsed_total": {"secs": int(elapsed), "nanos": int((elapsed % 1) * 1_000_000_000)}, "stats": {"matched_lines": total_lines, "matches": total_matches, "searches": searched, "searches_with_match": 1 if any_match else 0}}})
    elif cfg.stats and not (cfg.files_with_matches or cfg.files_without_match):
        print(f"\n{total_lines} matched lines")
        print(f"{searched} files searched")
    return 0 if any_match else (2 if cfg.had_error else 1)


def main(argv):
    try:
        cfg = parse_args(argv)
    except SystemExit as e:
        return int(e.code or 0)
    except ArgError as err:
        return die(str(err))
    return run(cfg)


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
