#!/usr/bin/env python3
import argparse
import grp
import os
import pwd
import stat
import sys
from datetime import datetime


VERSION = "pls 0.0.1-beta.9"
ARROW = "󰁔"
HELP = """pls is a prettier and powerful ls(1) for the pros.

Read docs: https://pls.cli.rs/
Get source: https://github.com/pls-rs/pls/
Sponsor: https://github.com/sponsors/dhruvkb/

Usage: executable [OPTIONS] [PATHS]...

Arguments:
  [PATHS]...
          the paths to list, each of which may be a file or directory
          
          [default: .]

Options:
  -h, --help
          Print help (see a summary with '-h')

  -V, --version
          Print version

Detail view:
  -d, --det <DETAILS>
          the data points to show about each node
          
          [default: none]
          [possible values: dev, ino, nlink, typ, perm, oct, user, uid, group, gid, size, blocks,
          btime, ctime, mtime, atime, git, none, std, all]

  -H, --header <HEADER>
          show headers above columnar data
          
          [default: true]
          [possible values: true, false]

  -u, --unit <UNIT>
          the type of units to use for the node sizes
          
          [default: binary]
          [possible values: binary, decimal, none]

Grid view:
  -g, --grid <GRID>
          display node names in multiple columns
          
          [default: false]
          [possible values: true, false]

  -D, --down <DOWN>
          display node names column-first
          
          [default: false]
          [possible values: true, false]

Presentation:
  -i, --icon <ICON>
          display icons next to node names
          
          [default: true]
          [possible values: true, false]

  -S, --suffix <SUFFIX>
          display node type suffixes after the node name
          
          [default: true]
          [possible values: true, false]

  -l, --sym <SYM>
          show symlink targets
          
          [default: true]
          [possible values: true, false]

  -c, --collapse <COLLAPSE>
          show dependent nodes as children of their principal nodes
          
          [default: true]
          [possible values: true, false]

  -a, --align <ALIGN>
          align items accounting for leading dots
          
          [default: true]
          [possible values: true, false]

Filtering:
  -t, --typ <TYPES>
          the set of node types to include in the output
          
          [default: all]
          [possible values: dir, symlink, fifo, socket, block-device, char-device, file, none, all]

  -I, --imp <IMP>
          the importance cutoff to dim or hide unimportant files
          
          [default: 0]

  -e, --exclude <EXCLUDE>
          the pattern of files to selectively hide from the output

  -o, --only <ONLY>
          the pattern of files to exclusively show in the output

Sorting:
  -s, --sort <SORT_BASES>
          the set of fields to sort by, trailing `_` reverses the direction
          
          [default: cat cname]
          [possible values: dev, ino, nlink, typ, cat, user, uid, group, gid, size, blocks, btime,
          ctime, mtime, atime, name, cname, ext, inode_, nlinks_, typ_, cat_, user_, uid_, group_,
          gid_, size_, blocks_, btime_, ctime_, mtime_, atime_, name_, cname_, ext_, none]
"""
ICONS = {
    "dir": "",
    "symlink": "󰌹",
    "fifo": "󰟥",
    "rs": "",
    "md": "",
    "txt": "",
}


DETAILS = [
    "dev", "ino", "nlink", "typ", "perm", "oct", "user", "uid", "group", "gid",
    "size", "blocks", "btime", "ctime", "mtime", "atime", "git", "none", "std", "all",
]
TYPES = ["dir", "symlink", "fifo", "socket", "block-device", "char-device", "file", "none", "all"]
SORTS = [
    "dev", "ino", "nlink", "typ", "cat", "user", "uid", "group", "gid", "size", "blocks",
    "btime", "ctime", "mtime", "atime", "name", "cname", "ext", "inode_", "nlinks_",
    "typ_", "cat_", "user_", "uid_", "group_", "gid_", "size_", "blocks_", "btime_",
    "ctime_", "mtime_", "atime_", "name_", "cname_", "ext_", "none",
]


class Node:
    def __init__(self, path, display=None, from_dir=False):
        self.path = path
        self.name = os.path.basename(path.rstrip(os.sep)) or path
        self.display = display or self.name
        self.from_dir = from_dir
        self.err = None
        try:
            self.st = os.lstat(path)
        except OSError as exc:
            self.st = None
            self.err = exc

    @property
    def type_name(self):
        if self.st is None:
            return "none"
        mode = self.st.st_mode
        if stat.S_ISDIR(mode):
            return "dir"
        if stat.S_ISLNK(mode):
            return "symlink"
        if stat.S_ISFIFO(mode):
            return "fifo"
        if stat.S_ISSOCK(mode):
            return "socket"
        if stat.S_ISBLK(mode):
            return "block-device"
        if stat.S_ISCHR(mode):
            return "char-device"
        return "file"

    @property
    def type_char(self):
        return {
            "dir": "d", "symlink": "l", "fifo": "p", "socket": "s",
            "block-device": "b", "char-device": "c", "file": "f",
        }.get(self.type_name, "?")

    @property
    def ext(self):
        base = self.name
        if "." not in base.strip("."):
            return ""
        return base.rsplit(".", 1)[-1].lower()

    @property
    def category(self):
        if self.type_name == "dir":
            return 0
        if self.type_name == "file" and self.ext not in ("md", "txt"):
            return 1
        if self.type_name == "symlink":
            return 2
        if self.type_name == "fifo":
            return 3
        if self.type_name == "file" and self.ext == "md":
            return 4
        if self.type_name == "file":
            return 5
        return 5


def perm_string(mode):
    parts = []
    for shift in (6, 3, 0):
        bits = (mode >> shift) & 7
        parts.append(("r" if bits & 4 else "-") + ("w" if bits & 2 else "-") + ("x" if bits & 1 else "-"))
    return " ".join(parts)


def user_name(uid):
    try:
        return pwd.getpwuid(uid).pw_name
    except KeyError:
        return str(uid)


def group_name(gid):
    try:
        return grp.getgrgid(gid).gr_name
    except KeyError:
        return str(gid)


def size_string(node, unit):
    if node.type_name == "dir":
        return ""
    n = int(node.st.st_size)
    if unit == "none":
        return f"{n} B"
    base = 1024 if unit == "binary" else 1000
    labels = ["B", "KiB", "MiB", "GiB", "TiB"] if unit == "binary" else ["B", "kB", "MB", "GB", "TB"]
    val = float(n)
    idx = 0
    while val >= base and idx < len(labels) - 1:
        val /= base
        idx += 1
    unit_width = 3 if unit == "binary" else 2
    return f"{val:.1f} {labels[idx]:>{unit_width}}"


def time_string(ts):
    return datetime.fromtimestamp(ts).strftime("%Y-%b-%d %I:%M%p")[:-2] + datetime.fromtimestamp(ts).strftime("%p").lower()


def name_key(name):
    return name.lstrip(".").lower()


def sort_nodes(nodes, sort_bases):
    def value(node, base):
        b = base[:-1] if base.endswith("_") else base
        if b in ("cat",):
            return node.category
        if b in ("name",):
            return node.name
        if b in ("cname",):
            return name_key(node.name)
        if b == "ext":
            return (node.ext, name_key(node.name))
        if b == "size":
            return node.st.st_size if node.st else 0
        if b == "mtime":
            return node.st.st_mtime if node.st else 0
        if b == "typ":
            return node.type_char
        return name_key(node.name)

    result = list(nodes)
    bases = sort_bases or ["cat", "cname"]
    if "none" in bases:
        return result
    for base in reversed(bases):
        result.sort(key=lambda n, b=base: value(n, b), reverse=base.endswith("_"))
    return result


def suffix(node, show_suffix):
    if not show_suffix:
        return ""
    return {"dir": "/", "symlink": "@", "fifo": "|", "socket": "="}.get(node.type_name, "")


def icon_for(node, use_icon):
    if not use_icon:
        return ""
    if node.type_name == "dir":
        return ICONS["dir"] + "  "
    if node.type_name == "symlink":
        return ICONS["symlink"] + "  "
    if node.type_name == "fifo":
        return ICONS["fifo"] + "  "
    if node.ext == "rs":
        return ICONS["rs"] + "  "
    if node.ext == "md":
        return ICONS["md"] + "  "
    if node.ext == "txt":
        return ICONS["txt"] + "  "
    return "  "


def rendered_name(node, opts):
    lead = ""
    if node.from_dir and not node.name.startswith("."):
        lead = " "
    name = f"{lead}{icon_for(node, opts.icon)}{node.name}{suffix(node, opts.suffix)}"
    if node.type_name == "symlink" and opts.sym:
        try:
            name += f" {ARROW} {os.readlink(node.path)}"
        except OSError:
            pass
    return name


def expand_details(values):
    if not values:
        return []
    out = []
    for val in values:
        if val == "none":
            continue
        if val == "std":
            out.extend(["nlink", "typ", "perm", "user", "group", "size", "mtime"])
        elif val == "all":
            out.extend(["dev", "ino", "nlink", "typ", "perm", "oct", "user", "uid", "group", "gid", "size", "blocks", "btime", "ctime", "mtime", "atime", "git"])
        else:
            out.append(val)
    return out


HEADERS = {
    "dev": "Device", "ino": "inode", "nlink": "Link#", "typ": "T", "perm": "Permissions",
    "oct": "SUGO", "user": "User", "uid": "UID", "group": "Group", "gid": "GID",
    "size": "Size", "blocks": "Blocks", "btime": "Created", "ctime": "Changed",
    "mtime": "Modified", "atime": "Accessed", "git": "Git",
}


def detail_value(node, detail, opts):
    st = node.st
    if detail == "dev":
        return str(st.st_dev)
    if detail == "ino":
        return str(st.st_ino)
    if detail == "nlink":
        return str(st.st_nlink)
    if detail == "typ":
        return node.type_char
    if detail == "perm":
        return perm_string(st.st_mode)
    if detail == "oct":
        return f"{stat.S_IMODE(st.st_mode):03o}"
    if detail == "user":
        return user_name(st.st_uid)
    if detail == "uid":
        return str(st.st_uid)
    if detail == "group":
        return group_name(st.st_gid)
    if detail == "gid":
        return str(st.st_gid)
    if detail == "size":
        return size_string(node, opts.unit)
    if detail == "blocks":
        return "" if node.type_name == "dir" else str(getattr(st, "st_blocks", 0))
    if detail == "btime":
        return time_string(getattr(st, "st_birthtime", st.st_ctime))
    if detail == "ctime":
        return time_string(st.st_ctime)
    if detail == "mtime":
        return time_string(st.st_mtime)
    if detail == "atime":
        return time_string(st.st_atime)
    if detail == "git":
        return ""
    return ""


def format_detail(nodes, details, opts):
    rows = []
    for node in nodes:
        vals = [detail_value(node, d, opts) for d in details]
        vals.append(rendered_name(node, opts))
        rows.append(vals)
    headers = [HEADERS[d] for d in details] + ["Name"]
    widths = []
    for col in range(len(headers)):
        widths.append(max([len(headers[col])] + [len(row[col]) for row in rows]))
    lines = []
    if opts.header:
        lines.append(" ".join(headers[i].rjust(widths[i]) if headers[i] in ("Size", "Blocks", "UID", "GID", "SUGO", "Device", "inode", "Link#") else headers[i].ljust(widths[i]) for i in range(len(headers))).rstrip())
    for row in rows:
        cells = []
        for i, val in enumerate(row):
            right = headers[i] in ("Size", "Blocks", "UID", "GID", "SUGO", "Device", "inode", "Link#")
            cells.append(val.rjust(widths[i]) if right else val.ljust(widths[i]))
        lines.append(" ".join(cells).rstrip())
    return "\n".join(lines)


def filter_nodes(nodes, opts):
    selected = []
    wanted = set(opts.typ)
    for node in nodes:
        if "none" in wanted:
            continue
        if "all" not in wanted and node.type_name not in wanted:
            continue
        if opts.exclude and opts.exclude in node.name:
            continue
        if opts.only and opts.only not in node.name:
            continue
        selected.append(node)
    return selected


def list_path(path, opts):
    node = Node(path)
    if node.err:
        return None, f"{path}:\n\terror: {node.err.strerror} (os error {node.err.errno})"
    if node.type_name == "dir":
        try:
            names = os.listdir(path)
        except OSError as exc:
            return None, f"{path}:\n\terror: {exc.strerror} (os error {exc.errno})"
        nodes = [Node(os.path.join(path, name), name, from_dir=True) for name in names]
    else:
        nodes = [node]
    nodes = sort_nodes(filter_nodes(nodes, opts), opts.sort)
    details = expand_details(opts.details)
    if details:
        body = format_detail(nodes, details, opts)
    else:
        body = "\n".join(rendered_name(n, opts) for n in nodes)
    return body, None


def parse_bool(s):
    if s == "true":
        return True
    if s == "false":
        return False
    raise argparse.ArgumentTypeError(f"invalid value '{s}'")


def build_parser():
    p = argparse.ArgumentParser(
        prog="executable",
        description="pls is a prettier and powerful ls(1) for the pros.",
        formatter_class=argparse.RawTextHelpFormatter,
    )
    p.add_argument("paths", nargs="*", default=["."])
    p.add_argument("-V", "--version", action="store_true")
    p.add_argument("-d", "--det", dest="details", action="append", choices=DETAILS, default=[])
    p.add_argument("-H", "--header", type=parse_bool, default=True)
    p.add_argument("-u", "--unit", choices=["binary", "decimal", "none"], default="binary")
    p.add_argument("-g", "--grid", type=parse_bool, default=False)
    p.add_argument("-D", "--down", type=parse_bool, default=False)
    p.add_argument("-i", "--icon", type=parse_bool, default=True)
    p.add_argument("-S", "--suffix", type=parse_bool, default=True)
    p.add_argument("-l", "--sym", type=parse_bool, default=True)
    p.add_argument("-c", "--collapse", type=parse_bool, default=True)
    p.add_argument("-a", "--align", type=parse_bool, default=True)
    p.add_argument("-t", "--typ", action="append", choices=TYPES, default=["all"])
    p.add_argument("-I", "--imp", default="0")
    p.add_argument("-e", "--exclude")
    p.add_argument("-o", "--only")
    p.add_argument("-s", "--sort", action="append", choices=SORTS, default=None)
    return p


def main(argv):
    if "-h" in argv or "--help" in argv:
        sys.stdout.write(HELP)
        return 0
    parser = build_parser()
    opts = parser.parse_args(argv)
    if opts.version:
        print(VERSION)
        return 0
    if opts.typ != ["all"] and "all" in opts.typ:
        opts.typ = [t for t in opts.typ if t != "all"]
    outputs = []
    errors = []
    file_nodes = []
    dir_paths = []
    if len(opts.paths) > 1:
        for path in opts.paths:
            n = Node(path)
            if n.err:
                errors.append(f"{path}:\n\terror: {n.err.strerror} (os error {n.err.errno})")
            elif n.type_name == "dir":
                dir_paths.append(path)
            else:
                file_nodes.append(n)
        file_nodes = sort_nodes(filter_nodes(file_nodes, opts), opts.sort)
        if file_nodes:
            details = expand_details(opts.details)
            outputs.append(format_detail(file_nodes, details, opts) if details else "\n".join(rendered_name(n, opts) for n in file_nodes))
        for path in dir_paths:
            body, err = list_path(path, opts)
            if err:
                errors.append(err)
            else:
                if outputs:
                    outputs.append("")
                outputs.append(f"{path}:")
                if body:
                    outputs.append(body)
    else:
        body, err = list_path(opts.paths[0], opts)
        if err:
            errors.append(err)
        elif body:
            outputs.append(body)
    if outputs:
        print("\n".join(outputs))
    if errors:
        print("\n".join(errors))
    return 0


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
