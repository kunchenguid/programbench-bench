import os
import pathlib
import subprocess
import tempfile
import unittest


ROOT = pathlib.Path(__file__).resolve().parents[1]
EXE = ROOT / "executable"


def run_pls(args, cwd):
    proc = subprocess.run(
        [str(EXE), *args],
        cwd=cwd,
        text=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
    )
    return proc.returncode, proc.stdout, proc.stderr


class PlsBehaviorTests(unittest.TestCase):
    def make_fixture(self):
        tmp = tempfile.TemporaryDirectory()
        root = pathlib.Path(tmp.name)
        (root / "dir").mkdir()
        (root / "beta").write_text("")
        (root / "alpha").write_text("")
        (root / ".hidden").write_text("")
        (root / "README.md").write_text("")
        (root / "file.rs").write_text("")
        os.symlink("alpha", root / "link")
        os.mkfifo(root / "pipe")
        return tmp, root

    def test_plain_listing_uses_pls_category_order(self):
        tmp, root = self.make_fixture()
        with tmp:
            code, out, err = run_pls(["-i", "false", "-S", "false"], root)
        self.assertEqual(code, 0)
        self.assertEqual(err, "")
        self.assertEqual(
            out.splitlines(),
            [
                " dir",
                " alpha",
                " beta",
                " file.rs",
                ".hidden",
                " link 󰁔 alpha",
                " pipe",
                " README.md",
            ],
        )

    def test_version_matches_documented_program_version(self):
        tmp, root = self.make_fixture()
        with tmp:
            code, out, err = run_pls(["--version"], root)
        self.assertEqual(code, 0)
        self.assertEqual(err, "")
        self.assertEqual(out, "pls 0.0.1-beta.9\n")

    def test_missing_path_reports_os_error_but_exits_successfully(self):
        tmp, root = self.make_fixture()
        with tmp:
            code, out, err = run_pls(["/no/such/path"], root)
        self.assertEqual(code, 0)
        self.assertEqual(out, "/no/such/path:\n\terror: No such file or directory (os error 2)\n")
        self.assertEqual(err, "")

    def test_type_filter_and_substring_filters_apply_to_names(self):
        tmp, root = self.make_fixture()
        with tmp:
            code, out, err = run_pls(["-t", "file", "-o", "a", "-i", "false", "-S", "false"], root)
        self.assertEqual(code, 0)
        self.assertEqual(err, "")
        self.assertEqual(out.splitlines(), [" alpha", " beta"])

    def test_suffixes_can_be_shown_without_icons(self):
        tmp, root = self.make_fixture()
        with tmp:
            code, out, err = run_pls(["-i", "false", "-S", "true", "-l", "false"], root)
        self.assertEqual(code, 0)
        self.assertEqual(err, "")
        self.assertIn(" dir/", out.splitlines())
        self.assertIn(" link@", out.splitlines())
        self.assertIn(" pipe|", out.splitlines())

    def test_detail_size_header_and_units_are_rendered(self):
        tmp, root = self.make_fixture()
        (root / "big.bin").write_bytes(b"x" * 1536)
        with tmp:
            code, out, err = run_pls(["-d", "size", "-u", "binary", "-i", "false", "-S", "false"], root)
        self.assertEqual(code, 0)
        self.assertEqual(err, "")
        self.assertEqual(out.splitlines()[0].strip(), "Size Name")
        self.assertTrue(any("1.5 KiB  big.bin" in line for line in out.splitlines()))


if __name__ == "__main__":
    unittest.main()
