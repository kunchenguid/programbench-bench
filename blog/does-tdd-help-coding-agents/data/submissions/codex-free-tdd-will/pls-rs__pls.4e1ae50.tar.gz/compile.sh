#!/bin/bash
set -e
rm -f executable
cp src/pls.py executable
chmod +x executable
