#!/usr/bin/env python3
import html
import os
import re
import shutil
import sys
from pathlib import Path

VERSION = "1.17.0 (9135bd68ddc9ea65023d967c75048a7a86a5d495)"
SHORT_VERSION = "1.17.0"


def data_dir() -> Path:
    here = Path(__file__).resolve()
    for candidate in (here.parent / "src", here.parent):
        if (candidate / "silent_config.txt").exists():
            return candidate
    return here.parent


def load_data(name: str) -> str:
    return (data_dir() / name).read_text()


def usage(prog: str) -> str:
    return f"""Doxygen version {VERSION}
Copyright Dimitri van Heesch 1997-2025

You can use Doxygen in a number of ways:

1) Use Doxygen to generate a template configuration file*:
    {prog} [-s] -g [configName]

2) Use Doxygen to update an old configuration file*:
    {prog} [-s] -u [configName]

3) Use Doxygen to generate documentation using an existing configuration file*:
    {prog} [configName]

4) Use Doxygen to generate a template file controlling the layout of the
   generated documentation:
    {prog} -l [layoutFileName]

    In case layoutFileName is omitted DoxygenLayout.xml will be used as filename.
    If - is used for layoutFileName Doxygen will write to standard output.

5) Use Doxygen to generate a template style sheet file for RTF, HTML or Latex.
    RTF:        {prog} -w rtf styleSheetFile
    HTML:       {prog} -w html headerFile footerFile styleSheetFile [configFile]
    LaTeX:      {prog} -w latex headerFile footerFile styleSheetFile [configFile]

6) Use Doxygen to generate a rtf extensions file
    {prog} -e rtf extensionsFile

    If - is used for extensionsFile Doxygen will write to standard output.

7) Use Doxygen to compare the used configuration file with the template configuration file
    {prog} -x [configFile]

   Use Doxygen to compare the used configuration file with the template configuration file
   without replacing the environment variables or CMake type replacement variables
    {prog} -x_noenv [configFile]

8) Use Doxygen to show a list of built-in emojis.
    {prog} -f emoji outputFileName

    If - is used for outputFileName Doxygen will write to standard output.

*) If -s is specified the comments of the configuration items in the config file will be omitted.
   If configName is omitted 'Doxyfile' will be used as a default.
   If - is used for configFile Doxygen will write / read the configuration to /from standard output / input.

If -q is used for a Doxygen documentation run, Doxygen will see this as if QUIET=YES has been set.

-v print version string, -V print extended version information
-h,-? prints usage help information
{prog} -d prints additional usage flags for debugging purposes
"""


def debug_help() -> str:
    levels = [
        "alias", "cite", "commentcnv", "commentscan", "entries", "extcmd",
        "filteroutput", "formula", "fortranfixed2free", "layout", "lex",
        "lex:code", "lex:commentcnv", "lex:commentscan", "lex:configimpl",
        "lex:constexp", "lex:declinfo", "lex:defargs", "lex:doctokenizer",
        "lex:fortrancode", "lex:fortranscanner", "lex:lexcode",
        "lex:lexscanner", "lex:pre", "lex:pycode", "lex:pyscanner",
        "lex:scanner", "lex:sqlcode", "lex:vhdlcode", "lex:xml",
        "lex:xmlcode", "markdown", "nolineno", "plantuml", "preprocessor",
        "printtree", "qhp", "rtf", "sections", "stderr", "tag", "time",
    ]
    return (
        f"{VERSION}\n    with sqlite3 3.42.0.\n"
        "Developer parameters:\n"
        "  -m          dump symbol map\n"
        "  -b          making messages output unbuffered\n"
        "  -c <file>   process input file as a comment block and produce HTML output\n"
        "  -d <level>  enable a debug level, such as (multiple invocations of -d are possible):\n"
        + "".join(f"\t{x}\n" for x in levels)
    )


def write_or_stdout(target: str, text: str) -> None:
    if target == "-":
        sys.stdout.write(text)
    else:
        Path(target).write_text(text)


def config_template(silent: bool) -> str:
    base = load_data("silent_config.txt")
    if silent:
        return base
    lines = []
    for line in base.splitlines():
        if line.startswith("#") or not line.strip():
            lines.append(line)
        elif "=" in line:
            tag = line.split("=", 1)[0].strip()
            lines.append(f"# The {tag} tag controls a Doxygen configuration option.")
            lines.append(line)
        else:
            lines.append(line)
    return "\n".join(lines) + "\n"


def parse_config(path: str) -> dict:
    cfg = {}
    if path == "-":
        text = sys.stdin.read()
    else:
        p = Path(path)
        text = p.read_text(errors="ignore") if p.exists() else ""
    current = None
    for raw in text.splitlines():
        line = raw.strip()
        if not line or line.startswith("#"):
            continue
        if line.endswith("\\"):
            line = line[:-1].rstrip()
        m = re.match(r"([A-Za-z0-9_]+)\s*(\+?=)\s*(.*)", line)
        if m:
            key, op, val = m.groups()
            val = val.strip().strip('"')
            if op == "+=" and key in cfg and val:
                cfg[key] += " " + val
            else:
                cfg[key] = val
            current = key
        elif current and line:
            cfg[current] += " " + line.strip().strip('"')
    return cfg


def tag_defaults() -> dict:
    defaults = {}
    for line in load_data("silent_config.txt").splitlines():
        m = re.match(r"([A-Za-z0-9_]+)\s*=\s*(.*)", line)
        if m:
            defaults[m.group(1)] = m.group(2).strip().strip('"')
    return defaults


def html_page(title: str, project: str, body: str) -> str:
    return f"""<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "https://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" lang="en-US">
<head>
<meta http-equiv="Content-Type" content="text/xhtml;charset=UTF-8"/>
<meta name="generator" content="Doxygen {SHORT_VERSION}"/>
<meta name="viewport" content="width=device-width, initial-scale=1"/>
<title>{html.escape(title)}</title>
<link href="doxygen.css" rel="stylesheet" type="text/css" />
</head>
<body>
<div id="titlearea"><div id="projectname">{html.escape(project)}</div></div>
<!-- Generated by Doxygen {SHORT_VERSION} -->
<div class="contents">
{body}
</div>
</body>
</html>
"""


def comment_before(text: str, start: int) -> str:
    prefix = text[:start]
    m = list(re.finditer(r"/\*\*(.*?)\*/|///\s*(.*)|##\s*(.*)", prefix, re.S))
    if not m:
        return ""
    last = m[-1]
    if len(prefix) - last.end() > 80:
        return ""
    raw = next(g for g in last.groups() if g is not None)
    lines = []
    for line in raw.splitlines():
        line = re.sub(r"^\s*\* ?", "", line).strip()
        if line:
            lines.append(line)
    return " ".join(lines)


def discover(inputs):
    classes, functions, files = [], [], []
    for item in inputs:
        p = Path(item)
        paths = sorted(p.rglob("*")) if p.is_dir() else [p]
        for path in paths:
            if not path.is_file():
                continue
            if path.suffix.lower() not in {".h", ".hpp", ".hh", ".c", ".cc", ".cpp", ".cxx", ".py", ".java", ".cs"}:
                continue
            files.append(path)
            text = path.read_text(errors="ignore")
            for m in re.finditer(r"\b(?:class|struct)\s+([A-Za-z_][A-Za-z0-9_]*)", text):
                classes.append({"name": m.group(1), "file": path, "brief": comment_before(text, m.start())})
            for m in re.finditer(r"\b([A-Za-z_][\w:<>,\s\*&~]+?)\s+([A-Za-z_][A-Za-z0-9_]*)\s*\([^;{}]*\)\s*(?:;|\{)", text):
                name = m.group(2)
                if name not in {"if", "for", "while", "switch"}:
                    functions.append({"name": name, "file": path, "brief": comment_before(text, m.start())})
            for m in re.finditer(r"^\s*def\s+([A-Za-z_][A-Za-z0-9_]*)\s*\(", text, re.M):
                functions.append({"name": m.group(1), "file": path, "brief": comment_before(text, m.start())})
    return files, classes, functions


def generate_docs(config_file: str, quiet_flag: bool) -> int:
    cfg = tag_defaults()
    cfg.update(parse_config(config_file))
    project = cfg.get("PROJECT_NAME") or "My Project"
    outdir = Path(cfg.get("OUTPUT_DIRECTORY") or ".")
    html_dir = outdir / (cfg.get("HTML_OUTPUT") or "html")
    inputs = (cfg.get("INPUT") or ".").split()
    gen_html = cfg.get("GENERATE_HTML", "YES").upper() != "NO"
    gen_latex = cfg.get("GENERATE_LATEX", "YES").upper() == "YES"
    quiet = quiet_flag or cfg.get("QUIET", "NO").upper() == "YES"
    files, classes, functions = discover(inputs)
    if gen_html:
        html_dir.mkdir(parents=True, exist_ok=True)
        (html_dir / "doxygen.css").write_text("body{font-family:Arial,sans-serif;margin:0;color:#202020}.contents{padding:1rem}#titlearea{padding:1rem;border-bottom:1px solid #ccc}.memitem{margin:.5rem 0}\n")
        (html_dir / "index.html").write_text(html_page(f"{project}: Main Page", project, "<h1>Main Page</h1>"))
        if files:
            body = "<h1>File List</h1><ul>" + "".join(f"<li>{html.escape(str(f))}</li>" for f in files) + "</ul>"
            (html_dir / "files.html").write_text(html_page(f"{project}: File List", project, body))
        if classes:
            body = "<h1>Class List</h1><ul>" + "".join(f'<li><a href="class{c["name"]}.html">{html.escape(c["name"])}</a></li>' for c in classes) + "</ul>"
            (html_dir / "annotated.html").write_text(html_page(f"{project}: Class List", project, body))
        for c in classes:
            related = [f for f in functions if f["file"] == c["file"]]
            body = f"<h1>{html.escape(c['name'])} Class Reference</h1>"
            if c["brief"]:
                body += f"<p>{html.escape(c['brief'])}</p>"
            if related:
                body += "<h2>Member Function Documentation</h2>" + "".join(
                    f'<div class="memitem"><b>{html.escape(fn["name"])}</b> {html.escape(fn["brief"])}</div>'
                    for fn in related
                )
            (html_dir / f"class{c['name']}.html").write_text(html_page(f"{project}: {c['name']} Class Reference", project, body))
            (html_dir / f"class{c['name']}-members.html").write_text(html_page(f"{project}: {c['name']} Members", project, body))
        if functions:
            body = "<h1>Functions</h1>" + "".join(f'<div class="memitem">{html.escape(f["name"])}</div>' for f in functions)
            (html_dir / "functions.html").write_text(html_page(f"{project}: Functions", project, body))
    if gen_latex:
        latex_dir = outdir / (cfg.get("LATEX_OUTPUT") or "latex")
        latex_dir.mkdir(parents=True, exist_ok=True)
        (latex_dir / "refman.tex").write_text(f"\\documentclass{{book}}\n\\begin{{document}}\n{project}\n\\end{{document}}\n")
    if not quiet:
        print(f"Generating documentation for {project}...")
    return 0


def write_style(kind: str, targets) -> int:
    if kind == "rtf":
        if len(targets) < 1:
            print('error: option "-w rtf" does not have enough arguments', file=sys.stderr)
            return 1
        write_or_stdout(targets[0], "{\\rtf1\\ansi\n{\\fonttbl{\\f0 Arial;}}\n}\n")
        return 0
    if kind in {"html", "latex"}:
        needed = 3
        if len(targets) < needed:
            print(f'error: option "-w {kind}" does not have enough arguments', file=sys.stderr)
            return 1
        header, footer, style = targets[:3]
        if kind == "html":
            write_or_stdout(header, "<!-- HTML header generated by doxygen -->\n")
            write_or_stdout(footer, "<!-- HTML footer generated by doxygen -->\n")
            write_or_stdout(style, "/* Doxygen stylesheet */\nbody { font-family: sans-serif; }\n")
        else:
            write_or_stdout(header, "% Latex header generated by doxygen\n")
            write_or_stdout(footer, "% Latex footer generated by doxygen\n")
            write_or_stdout(style, "% Latex style generated by doxygen\n")
        return 0
    print(f'error: option "-w" has unsupported format specifier {kind}', file=sys.stderr)
    return 1


def main(argv=None) -> int:
    argv = list(sys.argv[1:] if argv is None else argv)
    prog = "./executable"
    if not argv:
        if Path("Doxyfile").exists():
            return generate_docs("Doxyfile", False)
        print("error: Doxyfile not found and no input file specified!")
        sys.stdout.write(usage(prog))
        return 1
    if argv[0] in {"-h", "-?", "--help"}:
        sys.stdout.write(usage(prog))
        return 0
    if argv[0] in {"-v", "--version"}:
        print(VERSION)
        return 0
    if argv[0] == "-V":
        print(f"{VERSION}\n    with sqlite3 3.42.0.")
        return 0
    if argv[0] == "-d" and len(argv) == 1:
        sys.stdout.write(debug_help())
        return 0
    if argv[0].startswith("--") or (argv[0].startswith("-") and argv[0] not in {"-s", "-g", "-u", "-l", "-w", "-e", "-f", "-x", "-x_noenv", "-q"}):
        print(f'error: Unknown option "{argv[0]}"')
        sys.stdout.write(usage(prog))
        return 1

    silent = False
    quiet = False
    while argv and argv[0] in {"-s", "-q"}:
        silent = silent or argv[0] == "-s"
        quiet = quiet or argv[0] == "-q"
        argv.pop(0)
    if not argv:
        return generate_docs("Doxyfile", quiet)
    cmd = argv.pop(0)
    if cmd in {"-g", "-u"}:
        target = argv[0] if argv else "Doxyfile"
        write_or_stdout(target, config_template(silent))
        return 0
    if cmd == "-l":
        write_or_stdout(argv[0] if argv else "DoxygenLayout.xml", load_data("layout.xml"))
        return 0
    if cmd == "-e":
        if not argv:
            print('error: option "-e" is missing format specifier rtf.', file=sys.stderr)
            return 1
        kind = argv.pop(0)
        if kind != "rtf":
            print(f'error: option "-e" has unsupported format specifier {kind}', file=sys.stderr)
            return 1
        write_or_stdout(argv[0] if argv else "extensionsFile", load_data("rtf_extensions.txt"))
        return 0
    if cmd == "-f":
        if not argv:
            print('error: option "-f" is missing list specifier.', file=sys.stderr)
            return 1
        kind = argv.pop(0)
        if kind != "emoji":
            print(f'error: option "-f" has unsupported list specifier {kind}', file=sys.stderr)
            return 1
        write_or_stdout(argv[0] if argv else "-", load_data("emojis.txt"))
        return 0
    if cmd == "-w":
        if not argv:
            print('error: option "-w" is missing format specifier rtf, html or latex', file=sys.stderr)
            return 1
        return write_style(argv.pop(0), argv)
    if cmd in {"-x", "-x_noenv"}:
        cfg = tag_defaults()
        cfg.update(parse_config(argv[0] if argv else "Doxyfile"))
        for key in sorted(cfg):
            default = tag_defaults().get(key, "")
            if cfg[key] != default:
                print(f"{key:23}= {cfg[key]}")
        return 0
    return generate_docs(cmd, quiet)


if __name__ == "__main__":
    raise SystemExit(main())
