#!/bin/bash
set -e
rm -f executable
cp src/minilua.py executable
chmod +x executable
