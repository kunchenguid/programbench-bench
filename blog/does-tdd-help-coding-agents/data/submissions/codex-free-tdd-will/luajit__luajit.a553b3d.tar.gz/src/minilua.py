#!/usr/bin/env python3
import math
import os
import re
import sys


VERSION = "LuaJIT 2.1.1772570160 -- Copyright (C) 2005-2026 Mike Pall. https://luajit.org/"


class LuaError(Exception):
    pass


class ReturnSignal(Exception):
    def __init__(self, values):
        self.values = values


class BreakSignal(Exception):
    pass


class LuaTable:
    def __init__(self):
        self.map = {}

    def get(self, key):
        return self.map.get(key, None)

    def set(self, key, value):
        if value is None:
            self.map.pop(key, None)
        else:
            self.map[key] = value

    def length(self):
        i = 1
        while i in self.map:
            i += 1
        return i - 1

    def array(self):
        return [self.map[i] for i in range(1, self.length() + 1)]


class Env:
    def __init__(self, parent=None):
        self.parent = parent
        self.vars = {}

    def define(self, name, value):
        self.vars[name] = value

    def get(self, name):
        if name in self.vars:
            return self.vars[name]
        if self.parent:
            return self.parent.get(name)
        return None

    def set(self, name, value):
        if name in self.vars:
            self.vars[name] = value
        elif self.parent and self.parent.has(name):
            self.parent.set(name, value)
        else:
            self.vars[name] = value

    def has(self, name):
        return name in self.vars or (self.parent.has(name) if self.parent else False)


TOKEN_RE = re.compile(r"""
    (?P<space>[ \t\r\n]+)|
    (?P<comment>--[^\n]*)|
    (?P<number>(?:0[xX][0-9a-fA-F]+)|(?:\d+(?:\.\d*)?|\.\d+)(?:[eE][+-]?\d+)?)|
    (?P<string>'(?:\\.|[^\\'])*'|"(?:\\.|[^\\"])*")|
    (?P<op>\.\.\.|==|~=|<=|>=|\.\.|[+\-*/%^#=<>()[\]{},.;:])|
    (?P<name>[A-Za-z_][A-Za-z0-9_]*)
""", re.X)


KEYWORDS = {
    "and", "break", "do", "else", "elseif", "end", "false", "for", "function",
    "if", "in", "local", "nil", "not", "or", "repeat", "return", "then",
    "true", "until", "while",
}


def tokenize(src):
    out = []
    pos = 0
    while pos < len(src):
        m = TOKEN_RE.match(src, pos)
        if not m:
            raise LuaError(f"syntax error near '{src[pos:pos+12]}'")
        pos = m.end()
        kind = m.lastgroup
        text = m.group(kind)
        if kind in ("space", "comment"):
            continue
        if kind == "name" and text in KEYWORDS:
            out.append((text, text))
        else:
            out.append((kind if kind != "op" else text, text))
    out.append(("EOF", "EOF"))
    return out


def lua_str(v):
    if v is None:
        return "nil"
    if v is True:
        return "true"
    if v is False:
        return "false"
    if isinstance(v, float):
        if math.isfinite(v) and v.is_integer():
            return str(int(v))
        return ("%g" % v)
    if isinstance(v, LuaTable):
        return "table: 0x%x" % (id(v) & 0xffffffff)
    if callable(v):
        return "function: 0x%x" % (id(v) & 0xffffffff)
    return str(v)


def truthy(v):
    return v is not None and v is not False


def num(v):
    if isinstance(v, (int, float)):
        return v
    if isinstance(v, str):
        try:
            return float(v)
        except ValueError:
            pass
    raise LuaError("attempt to perform arithmetic on a non-number value")


class Parser:
    def __init__(self, src):
        self.toks = tokenize(src)
        self.i = 0

    def peek(self):
        return self.toks[self.i][0]

    def text(self):
        return self.toks[self.i][1]

    def pop(self, expected=None):
        tok = self.toks[self.i]
        if expected and tok[0] != expected:
            raise LuaError(f"syntax error near '{tok[1]}'")
        self.i += 1
        return tok

    def accept(self, t):
        if self.peek() == t:
            self.i += 1
            return True
        return False

    def parse(self, stops=("EOF",)):
        stmts = []
        while self.peek() not in stops:
            if self.accept(";"):
                continue
            stmts.append(self.statement())
            self.accept(";")
        return stmts

    def statement(self):
        t = self.peek()
        if t == "local":
            self.pop()
            if self.accept("function"):
                name = self.pop("name")[1]
                fn = self.func_body()
                return ("local", [name], [fn])
            names = [self.pop("name")[1]]
            while self.accept(","):
                names.append(self.pop("name")[1])
            vals = self.exprlist() if self.accept("=") else []
            return ("local", names, vals)
        if t == "for":
            self.pop()
            names = [self.pop("name")[1]]
            if self.accept("="):
                start = self.expr()
                self.pop(",")
                stop = self.expr()
                step = self.expr() if self.accept(",") else ("num", 1)
                self.pop("do")
                body = self.parse(("end",))
                self.pop("end")
                return ("fornum", names[0], start, stop, step, body)
            while self.accept(","):
                names.append(self.pop("name")[1])
            self.pop("in")
            vals = self.exprlist()
            self.pop("do")
            body = self.parse(("end",))
            self.pop("end")
            return ("forin", names, vals, body)
        if t == "while":
            self.pop()
            cond = self.expr()
            self.pop("do")
            body = self.parse(("end",))
            self.pop("end")
            return ("while", cond, body)
        if t == "if":
            self.pop()
            branches = []
            cond = self.expr()
            self.pop("then")
            branches.append((cond, self.parse(("elseif", "else", "end"))))
            while self.accept("elseif"):
                cond = self.expr()
                self.pop("then")
                branches.append((cond, self.parse(("elseif", "else", "end"))))
            other = None
            if self.accept("else"):
                other = self.parse(("end",))
            self.pop("end")
            return ("if", branches, other)
        if t == "function":
            self.pop()
            name = self.prefix_name()
            fn = self.func_body()
            return ("assign", [name], [fn])
        if t == "return":
            self.pop()
            vals = [] if self.peek() in ("EOF", "end", "else", "elseif", "until") else self.exprlist()
            return ("return", vals)
        if t == "break":
            self.pop()
            return ("break",)
        lhs = self.prefix()
        if self.accept("=") or self.accept(","):
            targets = [lhs]
            if self.toks[self.i - 1][0] == ",":
                targets.append(self.prefix())
                while self.accept(","):
                    targets.append(self.prefix())
                self.pop("=")
            vals = self.exprlist()
            return ("assign", targets, vals)
        return ("callstmt", lhs)

    def prefix_name(self):
        node = ("var", self.pop("name")[1])
        while True:
            if self.accept("."):
                node = ("index", node, ("str", self.pop("name")[1]))
            elif self.accept(":"):
                node = ("index", node, ("str", self.pop("name")[1]))
            else:
                return node

    def func_body(self):
        self.pop("(")
        params = []
        vararg = False
        if not self.accept(")"):
            while True:
                if self.accept("..."):
                    vararg = True
                    self.pop(")")
                    break
                params.append(self.pop("name")[1])
                if self.accept(")"):
                    break
                self.pop(",")
        body = self.parse(("end",))
        self.pop("end")
        return ("function", params, vararg, body)

    def exprlist(self):
        vals = [self.expr()]
        while self.accept(","):
            vals.append(self.expr())
        return vals

    def expr(self, minp=0):
        left = self.unary()
        prec = {"or": 1, "and": 2, "==": 3, "~=": 3, "<": 3, ">": 3, "<=": 3, ">=": 3,
                "..": 4, "+": 5, "-": 5, "*": 6, "/": 6, "%": 6, "^": 8}
        right_assoc = {"..", "^"}
        while self.peek() in prec and prec[self.peek()] >= minp:
            op = self.pop()[0]
            p = prec[op]
            rhs = self.expr(p if op in right_assoc else p + 1)
            left = ("bin", op, left, rhs)
        return left

    def unary(self):
        if self.peek() in ("not", "-", "#"):
            op = self.pop()[0]
            return ("unary", op, self.unary())
        return self.primary()

    def primary(self):
        t, s = self.pop()
        if t == "number":
            if s.lower().startswith("0x"):
                node = ("num", int(s, 16))
            else:
                f = float(s)
                node = ("num", int(f) if f.is_integer() else f)
        elif t == "string":
            node = ("str", bytes(s[1:-1], "utf-8").decode("unicode_escape"))
        elif t == "nil":
            node = ("nil",)
        elif t == "true":
            node = ("bool", True)
        elif t == "false":
            node = ("bool", False)
        elif t == "name":
            node = ("var", s)
        elif t == "(":
            node = self.expr()
            self.pop(")")
        elif t == "{":
            items = []
            idx = 1
            while not self.accept("}"):
                if self.accept("["):
                    k = self.expr()
                    self.pop("]")
                    self.pop("=")
                    v = self.expr()
                elif self.peek() == "name" and self.toks[self.i + 1][0] == "=":
                    k = ("str", self.pop("name")[1])
                    self.pop("=")
                    v = self.expr()
                else:
                    k = ("num", idx)
                    idx += 1
                    v = self.expr()
                items.append((k, v))
                self.accept(",") or self.accept(";")
            node = ("table", items)
        elif t == "function":
            node = self.func_body()
        else:
            raise LuaError(f"syntax error near '{s}'")
        return self.suffix(node)

    def prefix(self):
        if self.peek() == "name":
            return self.suffix(("var", self.pop()[1]))
        if self.accept("("):
            n = self.expr()
            self.pop(")")
            return self.suffix(n)
        raise LuaError(f"syntax error near '{self.text()}'")

    def suffix(self, node):
        while True:
            if self.accept("."):
                node = ("index", node, ("str", self.pop("name")[1]))
            elif self.accept("["):
                k = self.expr()
                self.pop("]")
                node = ("index", node, k)
            elif self.accept(":"):
                meth = self.pop("name")[1]
                args = self.args()
                node = ("call", ("index", node, ("str", meth)), [node] + args)
            elif self.peek() in ("(", "string", "{"):
                node = ("call", node, self.args())
            else:
                return node

    def args(self):
        if self.accept("("):
            if self.accept(")"):
                return []
            vals = self.exprlist()
            self.pop(")")
            return vals
        if self.peek() == "string":
            return [self.primary()]
        if self.peek() == "{":
            return [self.primary()]
        raise LuaError("function arguments expected")


class Interpreter:
    def __init__(self, chunk_name="(command line)", argv=None):
        self.chunk_name = chunk_name
        self.global_env = Env()
        self.install(argv or [])

    def install(self, argv):
        g = self.global_env
        def lprint(*args):
            print("\t".join(lua_str(a) for a in args))
        def ltype(x=None):
            if x is None: return "nil"
            if isinstance(x, bool): return "boolean"
            if isinstance(x, (int, float)): return "number"
            if isinstance(x, str): return "string"
            if isinstance(x, LuaTable): return "table"
            if callable(x): return "function"
            return "userdata"
        def tonumber(x=None, base=None):
            try:
                if base is not None:
                    return int(str(x), int(base))
                f = float(str(x).strip())
                return int(f) if f.is_integer() else f
            except Exception:
                return None
        def tostring(x=None): return lua_str(x)
        def assert_(x=None, msg="assertion failed!"):
            if not truthy(x): raise LuaError(str(msg))
            return x
        def error(msg="", level=None): raise LuaError(str(msg))
        def pcall(fn, *args):
            try:
                r = fn(*args)
                if isinstance(r, tuple):
                    return (True,) + r
                return (True, r)
            except Exception as e:
                return (False, str(e))
        def require(name):
            v = g.get(str(name))
            if v is not None:
                return v
            raise LuaError(f"module '{name}' not found")
        g.define("print", lprint); g.define("type", ltype); g.define("tonumber", tonumber)
        g.define("tostring", tostring); g.define("assert", assert_); g.define("error", error)
        g.define("pcall", pcall); g.define("require", require)
        g.define("_VERSION", "Lua 5.1")
        at = LuaTable()
        for i, a in enumerate(argv):
            at.set(i, a)
        g.define("arg", at)
        mt = LuaTable()
        for name in dir(math):
            if not name.startswith("_"):
                mt.set(name, getattr(math, name))
        mt.set("mod", lambda a, b: a % b); g.define("math", mt)
        st = LuaTable()
        st.set("len", lambda s: len(str(s)))
        st.set("upper", lambda s: str(s).upper())
        st.set("lower", lambda s: str(s).lower())
        st.set("sub", lambda s, i, j=None: str(s)[int(i)-1: int(j) if j is not None else None])
        st.set("rep", lambda s, n: str(s) * int(n))
        st.set("reverse", lambda s: str(s)[::-1])
        st.set("format", lambda fmt, *a: fmt % tuple(a))
        def sfind(s, pat, init=1, plain=None):
            start = max(int(init) - 1, 0)
            pos = str(s).find(str(pat), start)
            if pos < 0: return None
            return (pos + 1, pos + len(str(pat)))
        def sgsub(s, pat, repl, n=None):
            total = str(s).count(str(pat))
            if n is None:
                new, made = str(s).replace(str(pat), str(repl)), total
            else:
                count = int(n)
                new, made = str(s).replace(str(pat), str(repl), count), min(total, count)
            return (new, made)
        st.set("find", sfind); st.set("gsub", sgsub)
        g.define("string", st)
        tt = LuaTable()
        def tinsert(t, a, b=None):
            if b is None:
                t.set(t.length()+1, a); return None
            pos = int(a)
            for i in range(t.length()+1, pos, -1):
                t.set(i, t.get(i-1))
            t.set(pos, b)
            return None
        def tsort(t, comp=None):
            arr = t.array()
            arr.sort()
            for i, v in enumerate(arr, 1):
                t.set(i, v)
            return None
        tt.set("insert", tinsert)
        tt.set("concat", lambda t, sep="": str(sep).join(lua_str(x) for x in t.array()))
        tt.set("sort", tsort)
        g.define("table", tt)
        io = LuaTable()
        def iowrite(*args):
            sys.stdout.write("".join(lua_str(a) for a in args))
            sys.stdout.flush()
            return True
        io.set("write", iowrite)
        g.define("io", io)
        def ipairs(t):
            if not isinstance(t, LuaTable): return []
            return [(i, t.get(i)) for i in range(1, t.length()+1)]
        def pairs(t):
            return list(t.map.items()) if isinstance(t, LuaTable) else []
        g.define("ipairs", ipairs); g.define("pairs", pairs)

    def run(self, src):
        stmts = Parser(src).parse()
        self.exec_block(stmts, self.global_env)

    def exec_block(self, stmts, env):
        for st in stmts:
            self.exec_stmt(st, env)

    def exec_stmt(self, st, env):
        k = st[0]
        if k == "local":
            vals = self.eval_list(st[2], env)
            for i, n in enumerate(st[1]):
                env.define(n, vals[i] if i < len(vals) else None)
        elif k == "assign":
            vals = self.eval_list(st[2], env)
            for i, target in enumerate(st[1]):
                self.assign(target, vals[i] if i < len(vals) else None, env)
        elif k == "callstmt":
            self.eval(st[1], env)
        elif k == "fornum":
            start, stop, step = self.eval(st[2], env), self.eval(st[3], env), self.eval(st[4], env)
            i = start
            while (step >= 0 and i <= stop) or (step < 0 and i >= stop):
                child = Env(env); child.define(st[1], i)
                try: self.exec_block(st[5], child)
                except BreakSignal: break
                i += step
        elif k == "forin":
            vals = self.eval_list(st[2], env)
            iterable = vals[0] if vals else []
            for row in iterable:
                if not isinstance(row, tuple):
                    row = (row,)
                child = Env(env)
                for i, name in enumerate(st[1]):
                    child.define(name, row[i] if i < len(row) else None)
                try: self.exec_block(st[3], child)
                except BreakSignal: break
        elif k == "while":
            while truthy(self.eval(st[1], env)):
                try: self.exec_block(st[2], Env(env))
                except BreakSignal: break
        elif k == "if":
            for cond, body in st[1]:
                if truthy(self.eval(cond, env)):
                    self.exec_block(body, Env(env)); return
            if st[2] is not None:
                self.exec_block(st[2], Env(env))
        elif k == "return":
            raise ReturnSignal(self.eval_list(st[1], env))
        elif k == "break":
            raise BreakSignal()

    def assign(self, target, value, env):
        if target[0] == "var":
            env.set(target[1], value)
        elif target[0] == "index":
            obj = self.eval(target[1], env); key = self.eval(target[2], env)
            if isinstance(obj, LuaTable):
                obj.set(key, value)
            else:
                raise LuaError("attempt to index a non-table value")
        else:
            raise LuaError("syntax error")

    def eval(self, n, env):
        k = n[0]
        if k == "num": return n[1]
        if k == "str": return n[1]
        if k == "nil": return None
        if k == "bool": return n[1]
        if k == "var": return env.get(n[1])
        if k == "table":
            t = LuaTable()
            for key, val in n[1]:
                t.set(self.eval(key, env), self.eval(val, env))
            return t
        if k == "index":
            obj = self.eval(n[1], env); key = self.eval(n[2], env)
            if isinstance(obj, LuaTable): return obj.get(key)
            if isinstance(obj, str) and env.get("string"):
                return env.get("string").get(key)
            return None
        if k == "unary":
            v = self.eval(n[2], env)
            return (not truthy(v)) if n[1] == "not" else (-num(v) if n[1] == "-" else (len(v) if isinstance(v, str) else v.length()))
        if k == "bin":
            op = n[1]
            if op == "and":
                a = self.eval(n[2], env); return self.eval(n[3], env) if truthy(a) else a
            if op == "or":
                a = self.eval(n[2], env); return a if truthy(a) else self.eval(n[3], env)
            a, b = self.eval(n[2], env), self.eval(n[3], env)
            if op == "+": return num(a) + num(b)
            if op == "-": return num(a) - num(b)
            if op == "*": return num(a) * num(b)
            if op == "/": return num(a) / num(b)
            if op == "%": return num(a) % num(b)
            if op == "^": return num(a) ** num(b)
            if op == "..": return lua_str(a) + lua_str(b)
            if op == "==": return a == b
            if op == "~=": return a != b
            if op == "<": return a < b
            if op == ">": return a > b
            if op == "<=": return a <= b
            if op == ">=": return a >= b
        if k == "function":
            params, vararg, body = n[1], n[2], n[3]
            def fn(*args):
                child = Env(env)
                for i, p in enumerate(params):
                    child.define(p, args[i] if i < len(args) else None)
                try:
                    self.exec_block(body, child)
                except ReturnSignal as r:
                    return r.values[0] if len(r.values) == 1 else tuple(r.values)
                return None
            return fn
        if k == "call":
            f = self.eval(n[1], env)
            args = self.eval_list(n[2], env)
            if not callable(f):
                raise LuaError("attempt to call a nil value")
            return f(*args)
        raise LuaError("internal error")

    def eval_one(self, n, env):
        v = self.eval(n, env)
        return v[0] if isinstance(v, tuple) and v else v

    def eval_list(self, nodes, env):
        vals = []
        for i, n in enumerate(nodes):
            v = self.eval(n, env)
            if isinstance(v, tuple) and i == len(nodes) - 1:
                vals.extend(v)
            else:
                vals.append(v[0] if isinstance(v, tuple) and v else v)
        return vals


HELP = """Available options are:
  -e chunk  Execute string 'chunk'.
  -l name   Require library 'name'.
  -b ...    Save or list bytecode.
  -j cmd    Perform LuaJIT control command.
  -O[opt]   Control LuaJIT optimizations.
  -i        Enter interactive mode after executing 'script'.
  -v        Show version information.
  -E        Ignore environment variables.
  --        Stop handling options.
  -         Execute stdin and stop handling options."""


def main(argv):
    chunks = []
    script = None
    args = []
    i = 1
    while i < len(argv):
        a = argv[i]
        if a == "-v":
            print(VERSION); i += 1
        elif a in ("--help", "-h"):
            print(f"usage: {argv[0]} [options]... [script [args]...].")
            print(HELP)
            return 1
        elif a == "-e":
            i += 1
            if i >= len(argv):
                print(f"usage: {argv[0]} [options]... [script [args]...].")
                print(HELP)
                return 1
            chunks.append((argv[i], "(command line)")); i += 1
        elif a == "-b":
            print(f"{argv[0]}: unknown luaJIT command or jit.* modules not installed", file=sys.stderr)
            return 1
        elif a == "-l":
            i += 2
        elif a.startswith("-e") and len(a) > 2:
            chunks.append((a[2:], "(command line)")); i += 1
        elif a == "-":
            chunks.append((sys.stdin.read(), "stdin")); args = ["-"] + argv[i+1:]; break
        elif a in ("-E",) or a.startswith("-O") or a.startswith("-j"):
            i += 1
        elif a == "--":
            i += 1
            if i < len(argv): script = argv[i]; args = argv[i:]
            break
        elif a.startswith("-"):
            print(f"usage: {argv[0]} [options]... [script [args]...].")
            print(HELP)
            return 1
        else:
            script = a; args = argv[i:]; break
    try:
        interp = Interpreter(argv=args)
        for src, name in chunks:
            interp.chunk_name = name
            interp.run(src)
        if script:
            if not os.path.exists(script):
                print(f"{argv[0]}: cannot open {script}: No such file or directory", file=sys.stderr)
                return 1 if not chunks else 1
            with open(script) as f:
                interp.chunk_name = script
                interp.run(f.read())
        elif not chunks and len(argv) == 1:
            # Minimal REPL/stdin compatibility for non-tty use.
            if not sys.stdin.isatty():
                interp.run(sys.stdin.read())
        return 0
    except LuaError as e:
        print(f"{argv[0]}: {interp.chunk_name}: {e}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main(sys.argv))
