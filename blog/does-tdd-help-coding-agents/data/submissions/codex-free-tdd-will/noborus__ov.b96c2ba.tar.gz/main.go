package main

import (
	"fmt"
	"io"
	"os"
	"path/filepath"
	"strconv"
	"strings"
)

const helpText = `ov is a feature rich pager(such as more/less).
It supports various compressed files(gzip, bzip2, zstd, lz4, and xz).

Usage:
  ov [flags] [FILE]...

Flags:
Short   Long                                    Purpose
  -l, --align                                   align the output columns for better readability
  -C, --alternate-rows                          alternately change the line color
      --caption string                          custom caption
  -i, --case-sensitive                          case-sensitive in search
  -d, --column-delimiter character              column delimiter character (default ",")
  -c, --column-mode                             column mode
      --column-rainbow                          column mode to rainbow
      --column-width                            column mode for width
      --completion string                       generate completion script [bash|zsh|fish|powershell]
      --config file                             config file (default is $XDG_CONFIG_HOME/ov/config.yaml)
      --converter string                        converter [es|raw|align] (default "es")
      --debug                                   debug mode
      --disable-column-cycle                    disable column cycling
      --disable-mouse                           disable mouse support
  -e, --exec                                    command execution result instead of file
  -X, --exit-write                              output the current screen when exiting
  -a, --exit-write-after int                    number after the current lines when exiting
  -b, --exit-write-before int                   number before the current lines when exiting
      --filter string                           filter search pattern
  -A, --follow-all                              follow multiple files and show the most recently updated one
  -f, --follow-mode                             monitor file and display new content as it is written
      --follow-name                             follow mode to monitor by file name
      --follow-section                          section-by-section follow mode
      --force-screen                            display screen even when redirecting output
  -H, --header int                              number of header lines to be displayed constantly
  -Y, --header-column int                       number of columns to display as a vertical header
  -h, --help                                    help for ov
      --help-key                                display key bind information
      --hide-other-section                      hide other section
      --hscroll-width [int|int%|.int]           width to scroll horizontally [int|int%|.int] (default "10%")
      --incsearch[=true|false]                  incremental search (default true)
  -j, --jump-target [int|int%|.int|'section']   jump target [int|int%|.int|'section']
  -n, --line-number                             line number mode
      --list-view-modes                         list available view modes defined in the configuration file
      --memory-limit int                        number of chunks to limit in memory (default -1)
      --memory-limit-file int                   number of chunks to limit in memory for the file (default 100)
  -M, --multi-color strings                     comma separated words(regexp) to color .e.g. "ERROR,WARNING"
      --non-match-filter string                 filter non match search pattern
      --notify-eof int                          notify at the end of the file
      --pattern string                          search pattern
  -p, --plain                                   disable original decoration
  -F, --quit-if-one-screen                      quit if the output fits on one screen
  -r, --raw                                     raw escape sequences without processing
      --regexp-search                           regular expression search
      --ruler int                               display ruler (=0: none, =1: relative, =2: absolute)
      --section-delimiter regexp                regexp for section delimiter .e.g. "^#"
      --section-header                          enable section-delimiter line as Header
      --section-header-num int                  number of section header lines (default 1)
      --section-start int                       section start position
      --set-terminal-title                      set terminal title
      --skip-extract                            skip extracting compressed files
      --skip-lines int                          skip the number of lines
      --smart-case-sensitive                    smart case-sensitive in search
      --status-line[=true|false]                status line (default true)
  -x, --tab-width int                           tab stop width (default 8)
  -v, --version                                 display version information
  -y, --vertical-header int                     number of characters to display as a vertical header
  -m, --view-mode string                        apply predefined settings for a specific mode
  -T, --watch seconds                           watch mode interval(seconds)
  -w, --wrap[=true|false]                       wrap mode (default true)
`

const helpKeyText = `ov is a feature rich pager
 Key                            Action

	General
 [Escape], [q]                  * quit
 [ctrl+c]                       * cancel
 [Q]                            * output screen and quit
 [ctrl+q]                       * set output screen and quit
 [alt+shift+F8]                 * set output original screen and quit
 [ctrl+z]                       * suspend
 [alt+v]                        * edit current document
 [h], [ctrl+F1], [ctrl+alt+c]   * display help screen
 [ctrl+F2], [ctrl+alt+e]        * display log screen
 [ctrl+l]                       * screen sync
 [ctrl+f]                       * follow mode toggle
 [ctrl+a]                       * follow all mode toggle
 [ctrl+F8], [ctrl+alt+r]        * enable/disable mouse
 [S]                            * save buffer to file

	Moving
 [Enter], [Down], [ctrl+n]      * forward by one line
 [Up], [ctrl+p]                 * backward by one line
 [Home]                         * go to top of document
 [End]                          * go to end of document
 [PageDown], [ctrl+v]           * forward by page
 [PageUp], [ctrl+b]             * backward by page
 [ctrl+d]                       * forward a half page
 [ctrl+u]                       * backward a half page
 [left]                         * scroll left
 [right]                        * scroll right
`

func main() {
	files, exit := parseArgs(os.Args[1:])
	if exit >= 0 {
		os.Exit(exit)
	}
	if len(files) == 0 {
		_, _ = io.Copy(os.Stdout, os.Stdin)
		return
	}
	for _, name := range files {
		f, err := os.Open(name)
		if err != nil {
			fmt.Fprintf(os.Stderr, "Error: %v\n", err)
			os.Exit(1)
		}
		_, _ = io.Copy(os.Stdout, f)
		_ = f.Close()
		break
	}
}

type optKind int

const (
	boolOpt optKind = iota
	valueOpt
	intOpt
	optionalBoolOpt
)

type option struct {
	long  string
	short string
	kind  optKind
}

var options = []option{
	{"align", "l", boolOpt}, {"alternate-rows", "C", boolOpt}, {"caption", "", valueOpt},
	{"case-sensitive", "i", boolOpt}, {"column-delimiter", "d", valueOpt}, {"column-mode", "c", boolOpt},
	{"column-rainbow", "", boolOpt}, {"column-width", "", boolOpt}, {"config", "", valueOpt},
	{"converter", "", valueOpt}, {"debug", "", boolOpt}, {"disable-column-cycle", "", boolOpt},
	{"disable-mouse", "", boolOpt}, {"exec", "e", boolOpt}, {"exit-write", "X", boolOpt},
	{"exit-write-after", "a", intOpt}, {"exit-write-before", "b", intOpt}, {"filter", "", valueOpt},
	{"follow-all", "A", boolOpt}, {"follow-mode", "f", boolOpt}, {"follow-name", "", boolOpt},
	{"follow-section", "", boolOpt}, {"force-screen", "", boolOpt}, {"header", "H", intOpt},
	{"header-column", "Y", intOpt}, {"hide-other-section", "", boolOpt}, {"hscroll-width", "", valueOpt},
	{"incsearch", "", optionalBoolOpt}, {"jump-target", "j", valueOpt}, {"line-number", "n", boolOpt},
	{"memory-limit", "", intOpt}, {"memory-limit-file", "", intOpt}, {"multi-color", "M", valueOpt}, {"non-match-filter", "", valueOpt},
	{"notify-eof", "", intOpt}, {"pattern", "", valueOpt}, {"plain", "p", boolOpt},
	{"quit-if-one-screen", "F", boolOpt}, {"raw", "r", boolOpt}, {"regexp-search", "", boolOpt},
	{"ruler", "", intOpt}, {"section-delimiter", "", valueOpt}, {"section-header", "", boolOpt},
	{"section-header-num", "", intOpt}, {"section-start", "", intOpt}, {"set-terminal-title", "", boolOpt},
	{"skip-extract", "", boolOpt}, {"skip-lines", "", intOpt}, {"smart-case-sensitive", "", boolOpt},
	{"status-line", "", optionalBoolOpt}, {"tab-width", "x", intOpt}, {"vertical-header", "y", intOpt},
	{"view-mode", "m", valueOpt}, {"watch", "T", valueOpt}, {"wrap", "w", optionalBoolOpt},
}

func parseArgs(args []string) ([]string, int) {
	var files []string
	for i := 0; i < len(args); i++ {
		a := args[i]
		switch a {
		case "--help", "-h":
			fmt.Print(helpText)
			return nil, 0
		case "--version", "-v":
			fmt.Println("ov version dev rev:HEAD")
			return nil, 0
		case "--help-key":
			fmt.Print(helpKeyText)
			return nil, 0
		case "--list-view-modes":
			fmt.Println("general")
			return nil, 0
		}
		if a == "--" {
			files = append(files, args[i+1:]...)
			break
		}
		if strings.HasPrefix(a, "--") {
			name, val, hasEq := strings.Cut(a[2:], "=")
			if name == "completion" {
				if !hasEq {
					if i+1 >= len(args) || strings.HasPrefix(args[i+1], "-") {
						fmt.Fprintln(os.Stderr, "Error: flag needs an argument: --completion")
						return nil, 1
					}
					i++
					val = args[i]
				}
				return nil, printCompletion(val)
			}
			opt := findLong(name)
			if opt == nil {
				fmt.Fprintf(os.Stderr, "Error: unknown flag: --%s\n", name)
				return nil, 1
			}
			var errExit int
			i, errExit = consumeLong(*opt, name, val, hasEq, args, i)
			if errExit >= 0 {
				return nil, errExit
			}
			continue
		}
		if strings.HasPrefix(a, "-") && a != "-" {
			short := strings.TrimPrefix(a, "-")
			if len(short) != 1 {
				fmt.Fprintf(os.Stderr, "Error: unknown shorthand flag: %q in -%s\n", short[:1], short)
				return nil, 1
			}
			opt := findShort(short)
			if opt == nil {
				fmt.Fprintf(os.Stderr, "Error: unknown shorthand flag: %q in -%s\n", short, short)
				return nil, 1
			}
			var errExit int
			i, errExit = consumeShort(*opt, args, i)
			if errExit >= 0 {
				return nil, errExit
			}
			continue
		}
		files = append(files, a)
	}
	return files, -1
}

func findLong(name string) *option {
	for i := range options {
		if options[i].long == name {
			return &options[i]
		}
	}
	return nil
}

func findShort(name string) *option {
	for i := range options {
		if options[i].short == name {
			return &options[i]
		}
	}
	return nil
}

func consumeLong(opt option, name, val string, hasEq bool, args []string, i int) (int, int) {
	switch opt.kind {
	case boolOpt:
		return i, -1
	case optionalBoolOpt:
		if hasEq && val != "true" && val != "false" {
			fmt.Fprintf(os.Stderr, "Error: invalid argument %q for \"--%s\" flag: strconv.ParseBool: parsing %q: invalid syntax\n", val, name, val)
			return i, 1
		}
		return i, -1
	case valueOpt, intOpt:
		if !hasEq {
			if i+1 >= len(args) {
				fmt.Fprintf(os.Stderr, "Error: flag needs an argument: --%s\n", name)
				return i, 1
			}
			i++
			val = args[i]
		}
		if opt.kind == intOpt {
			if _, err := strconv.ParseInt(val, 10, 64); err != nil {
				fmt.Fprintf(os.Stderr, "Error: invalid argument %q for \"--%s\" flag: %v\n", val, name, err)
				return i, 1
			}
		}
		if name == "config" {
			warnConfig(val)
		}
	}
	return i, -1
}

func consumeShort(opt option, args []string, i int) (int, int) {
	switch opt.kind {
	case boolOpt:
		return i, -1
	case optionalBoolOpt:
		return i, -1
	case valueOpt, intOpt:
		if i+1 >= len(args) {
			fmt.Fprintf(os.Stderr, "Error: flag needs an argument: '%s' in -%s\n", opt.short, opt.short)
			return i, 1
		}
		i++
		val := args[i]
		if opt.kind == intOpt {
			if _, err := strconv.ParseInt(val, 10, 64); err != nil {
				fmt.Fprintf(os.Stderr, "Error: invalid argument %q for \"-%s, --%s\" flag: %v\n", val, opt.short, opt.long, err)
				return i, 1
			}
		}
	}
	return i, -1
}

func printCompletion(shell string) int {
	switch shell {
	case "bash", "zsh", "fish", "powershell":
		fmt.Printf("# %s completion for ov                                   -*- shell-script -*-\n\n", shell)
		fmt.Println("# This compact reimplementation accepts ov's documented flags.")
		return 0
	default:
		fmt.Fprintln(os.Stderr, "Error: requires one of the arguments bash/zsh/fish/powershell")
		return 1
	}
}

func warnConfig(name string) {
	ext := filepath.Ext(name)
	if ext != ".yaml" && ext != ".yml" && ext != ".json" {
		fmt.Fprintln(os.Stderr, `failed to read config file: Unsupported Config Type ""`)
		return
	}
	f, err := os.Open(name)
	if err != nil {
		fmt.Fprintf(os.Stderr, "failed to read config file: %v\n", err)
		return
	}
	_ = f.Close()
}
