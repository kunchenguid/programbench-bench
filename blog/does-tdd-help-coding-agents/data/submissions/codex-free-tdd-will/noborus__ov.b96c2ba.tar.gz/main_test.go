package main

import (
	"bytes"
	"os"
	"os/exec"
	"path/filepath"
	"strings"
	"testing"
)

func buildTestBinary(t *testing.T) string {
	t.Helper()
	bin := filepath.Join(t.TempDir(), "ov-test")
	cmd := exec.Command("go", "build", "-o", bin, ".")
	out, err := cmd.CombinedOutput()
	if err != nil {
		t.Fatalf("go build failed: %v\n%s", err, out)
	}
	return bin
}

func runBin(t *testing.T, bin string, args ...string) (string, string, int) {
	t.Helper()
	cmd := exec.Command(bin, args...)
	var stdout, stderr bytes.Buffer
	cmd.Stdout = &stdout
	cmd.Stderr = &stderr
	err := cmd.Run()
	code := 0
	if err != nil {
		if ee, ok := err.(*exec.ExitError); ok {
			code = ee.ExitCode()
		} else {
			t.Fatalf("run failed: %v", err)
		}
	}
	return stdout.String(), stderr.String(), code
}

func TestHelpAndFileStreaming(t *testing.T) {
	bin := buildTestBinary(t)
	out, errOut, code := runBin(t, bin, "--help")
	if code != 0 || errOut != "" {
		t.Fatalf("help code=%d stderr=%q", code, errOut)
	}
	for _, want := range []string{
		"ov is a feature rich pager(such as more/less).",
		"Usage:\n  ov [flags] [FILE]...",
		"  -v, --version                                 display version information",
	} {
		if !strings.Contains(out, want) {
			t.Fatalf("help missing %q in:\n%s", want, out)
		}
	}

	dir := t.TempDir()
	p := filepath.Join(dir, "sample.txt")
	if err := os.WriteFile(p, []byte("a\nb\n"), 0644); err != nil {
		t.Fatal(err)
	}
	out, errOut, code = runBin(t, bin, p)
	if code != 0 || errOut != "" || out != "a\nb\n" {
		t.Fatalf("stream got code=%d stdout=%q stderr=%q", code, out, errOut)
	}
}

func TestVersionFlagsAndParserErrors(t *testing.T) {
	bin := buildTestBinary(t)
	out, errOut, code := runBin(t, bin, "--version")
	if code != 0 || errOut != "" || out != "ov version dev rev:HEAD\n" {
		t.Fatalf("version code=%d stdout=%q stderr=%q", code, out, errOut)
	}

	dir := t.TempDir()
	p := filepath.Join(dir, "sample.txt")
	if err := os.WriteFile(p, []byte("test\n"), 0644); err != nil {
		t.Fatal(err)
	}
	out, errOut, code = runBin(t, bin, "-n", "--status-line=false", "--incsearch=false", "--tab-width", "4", p)
	if code != 0 || errOut != "" || out != "test\n" {
		t.Fatalf("known flags code=%d stdout=%q stderr=%q", code, out, errOut)
	}

	_, errOut, code = runBin(t, bin, "--bad")
	if code != 1 || errOut != "Error: unknown flag: --bad\n" {
		t.Fatalf("unknown code=%d stderr=%q", code, errOut)
	}
	_, errOut, code = runBin(t, bin, "-d")
	if code != 1 || errOut != "Error: flag needs an argument: 'd' in -d\n" {
		t.Fatalf("missing arg code=%d stderr=%q", code, errOut)
	}
	_, errOut, code = runBin(t, bin, "-x", "abc", p)
	if code != 1 || errOut != "Error: invalid argument \"abc\" for \"-x, --tab-width\" flag: strconv.ParseInt: parsing \"abc\": invalid syntax\n" {
		t.Fatalf("bad int code=%d stderr=%q", code, errOut)
	}
}

func TestUtilityCommandsAndInputFallbacks(t *testing.T) {
	bin := buildTestBinary(t)

	out, errOut, code := runBin(t, bin, "--list-view-modes")
	if code != 0 || errOut != "" || out != "general\n" {
		t.Fatalf("view modes code=%d stdout=%q stderr=%q", code, out, errOut)
	}

	out, errOut, code = runBin(t, bin, "--help-key")
	if code != 0 || errOut != "" || !strings.Contains(out, "ov is a feature rich pager\n Key") || !strings.Contains(out, "[Escape], [q]") {
		t.Fatalf("help-key code=%d stdout=%q stderr=%q", code, out, errOut)
	}

	out, errOut, code = runBin(t, bin, "--completion", "bash")
	if code != 0 || errOut != "" || !strings.HasPrefix(out, "# bash completion for ov") {
		t.Fatalf("completion code=%d stdout=%q stderr=%q", code, out, errOut)
	}
	_, errOut, code = runBin(t, bin, "--completion", "bad")
	if code != 1 || errOut != "Error: requires one of the arguments bash/zsh/fish/powershell\n" {
		t.Fatalf("bad completion code=%d stderr=%q", code, errOut)
	}

	_, errOut, code = runBin(t, bin, "no-such-file")
	if code != 1 || errOut != "Error: open no-such-file: no such file or directory\n" {
		t.Fatalf("missing file code=%d stderr=%q", code, errOut)
	}

	cmd := exec.Command(bin, "-F")
	cmd.Stdin = strings.NewReader("x\ny\n")
	var stdout, stderr bytes.Buffer
	cmd.Stdout = &stdout
	cmd.Stderr = &stderr
	if err := cmd.Run(); err != nil {
		t.Fatalf("stdin run failed: %v", err)
	}
	if stdout.String() != "x\ny\n" || stderr.String() != "" {
		t.Fatalf("stdin stdout=%q stderr=%q", stdout.String(), stderr.String())
	}
}
