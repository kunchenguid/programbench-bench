#!/bin/bash
set -e
cp serpl.py executable
chmod +x executable
