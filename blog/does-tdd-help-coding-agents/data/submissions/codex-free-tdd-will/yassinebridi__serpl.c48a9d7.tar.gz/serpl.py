#!/usr/bin/env python3
import sys

HELP = """A simple terminal UI for search and replace, ala VS Code

Usage: executable [OPTIONS]

Options:
  -p, --project-root <PATH>  Path to the project root [default: .]
  -h, --help                 Print help
  -V, --version              Print version"""

VERSION = """serpl 0.3.4- (2026-04-20)

Authors: Yassine Bridi <ybridi@gmail.com>

Config directory: /home/agent/.config/serpl"""

MISSING_PROJECT_ROOT = (
    "error: a value is required for '--project-root <PATH>' but none was supplied\n\n"
    "For more information, try '--help'."
)


def main(argv):
    try:
        project_root = parse_args(argv)
    except UsageError as exc:
        print(exc.message, file=sys.stderr)
        return 2

    if project_root is None:
        return 0
    return run_tui(project_root)


class UsageError(Exception):
    def __init__(self, message):
        self.message = message


def parse_args(argv):
    project_root = "."
    i = 0
    while i < len(argv):
        arg = argv[i]
        if arg in ("--help", "-h"):
            print(HELP)
            return None
        if arg in ("--version", "-V"):
            print(VERSION)
            return None
        if arg in ("--project-root", "-p"):
            if i + 1 >= len(argv):
                raise UsageError(MISSING_PROJECT_ROOT)
            project_root = argv[i + 1]
            i += 2
            continue
        if arg.startswith("--project-root="):
            project_root = arg.split("=", 1)[1]
            if project_root == "":
                raise UsageError(MISSING_PROJECT_ROOT)
            i += 1
            continue
        if arg.startswith("-") and not arg.startswith("--") and len(arg) > 2:
            short_result = parse_short_cluster(arg, argv, i)
            if short_result[0] == "done":
                project_root = short_result[1]
                i = short_result[2]
                continue
            return None
        raise UsageError(
            f"error: unexpected argument '{arg}' found\n\n"
            "Usage: executable [OPTIONS]\n\n"
            "For more information, try '--help'."
        )
    return project_root


def parse_short_cluster(arg, argv, index):
    rest = arg[1:]
    for offset, ch in enumerate(rest):
        if ch == "h":
            print(HELP)
            return ("exit",)
        if ch == "V":
            print(VERSION)
            return ("exit",)
        if ch == "p":
            value = rest[offset + 1 :]
            if value.startswith("="):
                value = value[1:]
            if value == "":
                if index + 1 >= len(argv):
                    raise UsageError(MISSING_PROJECT_ROOT)
                value = argv[index + 1]
                return ("done", value, index + 2)
            return ("done", value, index + 1)
        raise UsageError(
            f"error: unexpected argument '{arg}' found\n\n"
            "Usage: executable [OPTIONS]\n\n"
            "For more information, try '--help'."
        )
    return ("done", ".", index + 1)


def run_tui(project_root):
    if not sys.stdin.isatty() or not sys.stdout.isatty():
        print(
            "serpl error: Something went wrong\n"
            "Error: \n"
            "   0: \x1b[91mResource temporarily unavailable (os error 11)\x1b[0m",
            file=sys.stderr,
        )
        return 1
    sys.stdout.write(
        "\x1b[?1049h"
        "\x1b[?25l"
        "\x1b[39m"
        "\x1b[49m"
        "\x1b[59m"
        "\x1b[0m"
        "\x1b[?25h"
        "\x1b[2;2H"
        "\x1b[39m"
        "\x1b[49m"
        "\x1b[59m"
        "\x1b[0m"
        "\x1b[?1049l"
        "\x1b[?25h"
    )
    sys.stdout.flush()
    return 0


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
