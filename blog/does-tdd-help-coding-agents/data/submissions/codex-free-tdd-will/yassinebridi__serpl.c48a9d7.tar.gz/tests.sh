#!/bin/bash
set -euo pipefail

./compile.sh

out="$(./executable --help 2>&1)"
expected='A simple terminal UI for search and replace, ala VS Code

Usage: executable [OPTIONS]

Options:
  -p, --project-root <PATH>  Path to the project root [default: .]
  -h, --help                 Print help
  -V, --version              Print version'

if [[ "$out" != "$expected" ]]; then
  printf 'help output mismatch\nExpected:\n%s\nActual:\n%s\n' "$expected" "$out" >&2
  exit 1
fi

out="$(./executable --version 2>&1)"
expected='serpl 0.3.4- (2026-04-20)

Authors: Yassine Bridi <ybridi@gmail.com>

Config directory: /home/agent/.config/serpl'

if [[ "$out" != "$expected" ]]; then
  printf 'version output mismatch\nExpected:\n%s\nActual:\n%s\n' "$expected" "$out" >&2
  exit 1
fi

set +e
out="$(./executable --nope 2>&1)"
status=$?
set -e
expected="error: unexpected argument '--nope' found

Usage: executable [OPTIONS]

For more information, try '--help'."
if [[ "$status" -ne 2 || "$out" != "$expected" ]]; then
  printf 'unknown argument mismatch\nStatus: %s\nOutput:\n%s\n' "$status" "$out" >&2
  exit 1
fi

set +e
out="$(./executable -p 2>&1)"
status=$?
set -e
expected="error: a value is required for '--project-root <PATH>' but none was supplied

For more information, try '--help'."
if [[ "$status" -ne 2 || "$out" != "$expected" ]]; then
  printf 'missing project root mismatch\nStatus: %s\nOutput:\n%s\n' "$status" "$out" >&2
  exit 1
fi

set +e
out="$(./executable 2>&1)"
status=$?
set -e
expected=$'serpl error: Something went wrong\nError: \n   0: \e[91mResource temporarily unavailable (os error 11)\e[0m'
if [[ "$status" -ne 1 || "$out" != "$expected" ]]; then
  printf 'non-interactive startup mismatch\nStatus: %s\nOutput:\n%s\n' "$status" "$out" >&2
  exit 1
fi

set +e
out="$(./executable --project-root= 2>&1)"
status=$?
set -e
expected="error: a value is required for '--project-root <PATH>' but none was supplied

For more information, try '--help'."
if [[ "$status" -ne 2 || "$out" != "$expected" ]]; then
  printf 'empty project root mismatch\nStatus: %s\nOutput:\n%s\n' "$status" "$out" >&2
  exit 1
fi

out="$(./executable -hp 2>&1)"
expected='A simple terminal UI for search and replace, ala VS Code

Usage: executable [OPTIONS]

Options:
  -p, --project-root <PATH>  Path to the project root [default: .]
  -h, --help                 Print help
  -V, --version              Print version'
if [[ "$out" != "$expected" ]]; then
  printf 'short help cluster mismatch\nOutput:\n%s\n' "$out" >&2
  exit 1
fi

set +e
out="$(./executable -p/tmp 2>&1)"
status=$?
set -e
expected=$'serpl error: Something went wrong\nError: \n   0: \e[91mResource temporarily unavailable (os error 11)\e[0m'
if [[ "$status" -ne 1 || "$out" != "$expected" ]]; then
  printf 'attached short project root mismatch\nStatus: %s\nOutput:\n%s\n' "$status" "$out" >&2
  exit 1
fi

if command -v script >/dev/null; then
  tty_out="$(mktemp)"
  tty_log="$(mktemp)"
  timeout 2 script -q -c "TERM=xterm-256color ./executable" "$tty_log" >"$tty_out" 2>/dev/null
  out="$(cat "$tty_out")"
  rm -f "$tty_out" "$tty_log"
  expected=$'\e[?1049h\e[?25l\e[39m\e[49m\e[59m\e[0m\e[?25h\e[2;2H\e[39m\e[49m\e[59m\e[0m\e[?1049l\e[?25h'
  if [[ "$out" != "$expected" ]]; then
    printf 'tty startup sequence mismatch\nOutput:\n%s\n' "$(printf '%s' "$out" | cat -v)" >&2
    exit 1
  fi
fi
