package main

import (
	"flag"
	"fmt"
	"io"
	"os"
	"time"
)

const terminalQuery = "\x1b[c"

func usage(w io.Writer) {
	fmt.Fprint(w, `Usage: jplot [OPTIONS] FIELD_SPEC [FIELD_SPEC...]:

OPTIONS:
  -interval duration
    	When url is provided, defines the interval between fetches. Note that counter fields are computed based on this interval. (default 1s)
  -rows int
    	Limits the height of the graph output.
  -steps int
    	Number of values to plot. (default 100)
  -url string
    	URL to fetch every second. Read JSON objects from stdin if not specified.

FIELD_SPEC: [<option>[,<option>...]:]path
  option:
    - counter: Computes the difference with the last value. The value must increase monotonically.
    - marker: When the value is none-zero, a vertical line is drawn.
  path:
    JSON field path (eg: field.sub-field).
`)
}

func run(args []string, stdin io.Reader, stdout, stderr io.Writer) int {
	fmt.Fprint(stdout, terminalQuery)

	fs := flag.NewFlagSet("jplot", flag.ContinueOnError)
	fs.SetOutput(stderr)
	fs.Usage = func() { usage(stderr) }
	_ = fs.Duration("interval", time.Second, "")
	_ = fs.Int("rows", 0, "")
	_ = fs.Int("steps", 100, "")
	_ = fs.String("url", "", "")

	if err := fs.Parse(args); err != nil {
		if err == flag.ErrHelp {
			return 0
		}
		return 2
	}
	fmt.Fprintln(stdout, "jplot:  iTerm2, Kitty, or DRCS Sixel graphics required")
	return 1
}

func main() {
	os.Exit(run(os.Args[1:], os.Stdin, os.Stdout, os.Stderr))
}
