module jplot

go 1.20
