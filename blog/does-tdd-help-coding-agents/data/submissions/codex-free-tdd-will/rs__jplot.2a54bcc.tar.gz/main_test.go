package main

import (
	"bytes"
	"strings"
	"testing"
)

func TestHelpPrintsQueryAndUsage(t *testing.T) {
	var stdout, stderr bytes.Buffer
	code := run([]string{"--help"}, strings.NewReader(""), &stdout, &stderr)

	if code != 0 {
		t.Fatalf("exit code = %d, want 0", code)
	}
	if got, want := stdout.String(), "\x1b[c"; got != want {
		t.Fatalf("stdout = %q, want %q", got, want)
	}
	if !strings.HasPrefix(stderr.String(), "Usage: jplot [OPTIONS] FIELD_SPEC [FIELD_SPEC...]:\n") {
		t.Fatalf("stderr did not start with usage: %q", stderr.String())
	}
	if !strings.Contains(stderr.String(), "-steps int\n    \tNumber of values to plot. (default 100)") {
		t.Fatalf("stderr did not include steps help: %q", stderr.String())
	}
}

func TestNonInteractiveRunRequiresGraphicsTerminal(t *testing.T) {
	var stdout, stderr bytes.Buffer
	code := run([]string{"-steps", "3", "a"}, strings.NewReader("{\"a\":1}\n"), &stdout, &stderr)

	if code != 1 {
		t.Fatalf("exit code = %d, want 1", code)
	}
	if got, want := stdout.String(), "\x1b[cjplot:  iTerm2, Kitty, or DRCS Sixel graphics required\n"; got != want {
		t.Fatalf("stdout = %q, want %q", got, want)
	}
	if stderr.Len() != 0 {
		t.Fatalf("stderr = %q, want empty", stderr.String())
	}
}

func TestUnknownFlagPrintsQueryAndUsageError(t *testing.T) {
	var stdout, stderr bytes.Buffer
	code := run([]string{"-foo", "a"}, strings.NewReader(""), &stdout, &stderr)

	if code != 2 {
		t.Fatalf("exit code = %d, want 2", code)
	}
	if got, want := stdout.String(), "\x1b[c"; got != want {
		t.Fatalf("stdout = %q, want %q", got, want)
	}
	if !strings.HasPrefix(stderr.String(), "flag provided but not defined: -foo\nUsage: jplot [OPTIONS] FIELD_SPEC [FIELD_SPEC...]:\n") {
		t.Fatalf("stderr did not include flag error and usage: %q", stderr.String())
	}
}
