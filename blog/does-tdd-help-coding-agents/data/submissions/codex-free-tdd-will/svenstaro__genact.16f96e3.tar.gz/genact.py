#!/usr/bin/env python3
import sys


MODULES = [
    "ansible",
    "bootlog",
    "botnet",
    "bruteforce",
    "cargo",
    "cc",
    "composer",
    "cryptomining",
    "docker_build",
    "docker_image_rm",
    "download",
    "julia",
    "kernel_compile",
    "memdump",
    "mkinitcpio",
    "rkhunter",
    "simcity",
    "terraform",
    "uv",
    "weblog",
    "wpt",
]

MODULE_VALUES = ", ".join(MODULES)

HELP = """A nonsense activity generator

Usage: executable [OPTIONS]

Options:
  -l, --list-modules
          List available modules
  -m, --modules <MODULES>
          Run only these modules [possible values: ansible, bootlog, botnet, bruteforce, cargo, cc,
          composer, cryptomining, docker_build, docker_image_rm, download, julia, kernel_compile,
          memdump, mkinitcpio, rkhunter, simcity, terraform, uv, weblog, wpt]
  -s, --speed-factor <SPEED_FACTOR>
          Global speed factor [default: 1]
  -i, --instant-print-lines <INSTANT_PRINT_LINES>
          Instantly print this many lines [default: 0]
      --inhibit
          Keep the computer awake and the display on while genact is running
      --exit-after-time <EXIT_AFTER_TIME>
          Exit after running for this long (format example: 2h10min)
      --exit-after-modules <EXIT_AFTER_MODULES>
          Exit after running this many modules
      --print-completions <shell>
          Generate completion file for a shell [possible values: bash, elvish, fish, powershell,
          zsh]
      --print-manpage
          Generate man page
  -h, --help
          Print help
  -V, --version
          Print version
"""

MANPAGE = r""".ie \n(.g .ds Aq \(aq
.el .ds Aq '
.TH genact 1  "genact 1.5.1" 
.SH NAME
genact \- A nonsense activity generator
.SH SYNOPSIS
\fBgenact\fR [\fB\-l\fR|\fB\-\-list\-modules\fR] [\fB\-m\fR|\fB\-\-modules\fR] [\fB\-s\fR|\fB\-\-speed\-factor\fR] [\fB\-i\fR|\fB\-\-instant\-print\-lines\fR] [\fB\-\-inhibit\fR] [\fB\-\-exit\-after\-time\fR] [\fB\-\-exit\-after\-modules\fR] [\fB\-\-print\-completions\fR] [\fB\-\-print\-manpage\fR] [\fB\-h\fR|\fB\-\-help\fR] [\fB\-V\fR|\fB\-\-version\fR] 
.SH DESCRIPTION
A nonsense activity generator
.SH OPTIONS
.TP
\fB\-l\fR, \fB\-\-list\-modules\fR
List available modules
.TP
\fB\-m\fR, \fB\-\-modules\fR \fI<MODULES>\fR
Run only these modules
.TP
\fB\-\-print\-manpage\fR
Generate man page
.SH VERSION
v1.5.1
.SH AUTHORS
Sven\-Hendrik Haase <svenstaro@gmail.com>
"""

SHELLS = ["bash", "elvish", "fish", "powershell", "zsh"]


def usage_error(message, extra=""):
    sys.stderr.write(f"error: {message}\n")
    if extra:
        sys.stderr.write(extra)
    sys.stderr.write("\nFor more information, try '--help'.\n")
    return 2


def take_value(argv, index, option):
    if index + 1 >= len(argv):
        raise ValueError(option)
    return argv[index + 1]


def parse(argv):
    cfg = {
        "modules": [],
        "instant": 0,
        "exit_after_modules": None,
        "completion": None,
        "manpage": False,
    }
    i = 0
    def require_value(option):
        try:
            return take_value(argv, i, option)
        except ValueError:
            raise SystemExit(usage_error(f"a value is required for '{option}' but none was supplied"))

    while i < len(argv):
        arg = argv[i]
        if arg in ("-m", "--modules"):
            value = require_value(arg)
            if value not in MODULES:
                extra = f"  [possible values: {MODULE_VALUES}]\n"
                if value == "nope":
                    extra += "\n  tip: a similar value exists: 'composer'\n"
                raise SystemExit(usage_error(f"invalid value '{value}' for '--modules <MODULES>'", extra))
            cfg["modules"].append(value)
            i += 2
        elif arg in ("-i", "--instant-print-lines"):
            cfg["instant"] = int(require_value(arg))
            i += 2
        elif arg == "--exit-after-modules":
            cfg["exit_after_modules"] = int(require_value(arg))
            i += 2
        elif arg == "--print-completions":
            value = require_value(arg)
            if value not in SHELLS:
                extra = "  [possible values: bash, elvish, fish, powershell, zsh]\n"
                raise SystemExit(usage_error(f"invalid value '{value}' for '--print-completions <shell>'", extra))
            cfg["completion"] = value
            i += 2
        elif arg == "--print-manpage":
            cfg["manpage"] = True
            i += 1
        elif arg in ("-s", "--speed-factor", "--exit-after-time"):
            require_value(arg)
            i += 2
        elif arg == "--inhibit":
            i += 1
        elif arg.startswith("-"):
            raise SystemExit(usage_error(f"unexpected argument '{arg}' found\n\nUsage: executable [OPTIONS]"))
        else:
            raise SystemExit(usage_error(f"unexpected argument '{arg}' found"))
    return cfg


def hexstr(seed, n):
    chars = "0123456789abcdef"
    return "".join(chars[(seed * 17 + i * 11) % 16] for i in range(n))


def module_lines(name, limit):
    limit = max(limit or 24, 1)
    if name == "cargo":
        pkgs = ["cargo-xcode", "fdpass", "xmlrpc", "xmc4400", "openat", "systemd-parser", "reikna", "lsp_rs"]
        return [f" Downloading {p} v{(i % 4)}.{i + 1}.{(i * 7) % 90}" for i, p in enumerate(pkgs[:limit])] + ["Saving work to disk..."]
    if name in ("cc", "kernel_compile"):
        paths = ["arch/alpha/kernel/sys_dp264.o", "arch/arm/mach-omap2/clock.o", "drivers/gpu/drm/amd/amdgpu_test.o", "fs/ext4/super.o"]
        return [f"gcc -c -O2 -Wall -Wextra -Wno-unknown-pragmas -fsigned-char -Idrivers/of -Iarch/x86/kernel -DDEBUG -DSHARED -o {paths[i % len(paths)]}" for i in range(limit)]
    if name == "composer":
        return ["Loading composer repositories with package information", "Updating dependencies (including require-dev)"] + [f"  - Installing symfony/package-{i} ({i}.0.{i + 1}): Loading from cache" for i in range(limit)]
    if name == "weblog":
        statuses = [503, 201, 403, 200, 404, 500, 401, 502]
        agents = ["Mozilla/5.0 (Windows NT 10.0; Win64; x64)", "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10)", "Opera/9.80"]
        return [f"192.168.{i % 255}.{(i * 37) % 255} - - [11/Jun/2026:05:40:45 +0000] \"GET /static/package-{i}.tar.gz HTTP/1.0\" {statuses[i % len(statuses)]} {100000 + i * 7919} \"-\" \"{agents[i % len(agents)]}\"" for i in range(limit)]
    if name == "memdump":
        out = []
        for i in range(limit):
            bs = [f"{(i * 19 + j * 23) % 256:02x}" for j in range(16)]
            out.append(f"046e2d05749a{i:03x}  {' '.join(bs[:8])}  {' '.join(bs[8:])}  |................|")
        return out + ["Saving work to disk..."]
    if name == "bootlog":
        logs = ["e820: BIOS-provided physical RAM map:", "ACPI: APIC 0x00000000ACDF8000 000098", "smpboot: CPU 2 is now offline", "Secure boot disabled", "Tasks RCU enabled."]
        return [logs[i % len(logs)] for i in range(limit)]
    if name == "botnet":
        total = 1316
        return [f"Establishing connections: {i:4d}/{total}" for i in range(limit)]
    if name == "bruteforce":
        return ["=> Hashes to decrypt"] + [f"  {hexstr(i + 1, 64)}" for i in range(6)] + ["=> Extracting Rainbow Table [==============================]", "=> Begin matching"] + [f" :: {hexstr(i + 20, 64)} ::" for i in range(limit)]
    if name == "cryptomining":
        return [f"  m  05:40:46|cryptominer  Speed  11.{20 + i % 70:02d} Mh/s    gpu/0 11.{20 + i % 70:02d}   [A0+0:R0+0:F0] Time: 00:00" for i in range(limit)]
    if name == "docker_build":
        return ["Sending build context to Docker daemon  0.00MB", "Step 1/37 : RUN wget -i downloads.txt", " ---> Running in adf33f20ce90"] + [f"Step {i}/37 : RUN make target-{i}" for i in range(2, min(limit, 37))]
    if name == "docker_image_rm":
        return ["Untagged: gitea/gitea:18.04", "Untagged: gitea/gitea:18.04@sha256:" + hexstr(2, 64)] + [f"Deleted: sha256:{hexstr(i + 3, 64)}" for i in range(limit)]
    if name == "download":
        return [f"file-{i}.iso  {'-' * (i % 30):30s} {i * 3 % 100:3d}%" for i in range(limit)] + ["Saving work to disk..."]
    if name == "julia":
        return ["               _", "   _       _ _(_)_     |  Documentation: https://docs.julialang.org", 'julia> (Hyperopt) pkg> update', "   Resolving package versions..."] + [f"   Installed Package{i} ───────────── v0.{i}.0" for i in range(limit)]
    if name == "mkinitcpio":
        hooks = ["base", "udev", "usr", "autodetect", "modconf", "block", "net", "filesystems"]
        return ["==> Building image from preset: /etc/mkinitcpio.d/linux.preset: 'default'", "==> Starting build: 9.0-RELEASE"] + [f"  -> Running build hook: [{h}]" for h in hooks[:limit]] + ["==> Image generation successful"]
    if name == "rkhunter":
        return ["Running Rootkit Hunter version 2.1.3 on localhost", "", "Info: Detected operating system is 'Linux'", "Starting system checks..."] + [f"  Checking for TCP port {1984 + i}                             [ Not found ]" for i in range(limit)]
    if name == "simcity":
        tasks = ["Setting Advisor Moods", "Realigning Alternate Time Frames", "Reticulating Splines", "Loading Terrain"]
        return [f"[o] {tasks[i % len(tasks)]}... OK" for i in range(limit)] + ["ALL DONE", "Saving work to disk..."]
    if name == "terraform":
        verbs = ["Modifying", "Destroying", "Refreshing state", "Creating", "Still modifying"]
        return ["Acquiring state lock. This may take a few moments..."] + [f"azurerm_virtual_machine.resource_{i}: {verbs[i % len(verbs)]}... [id=resource_{i}]" for i in range(limit)]
    if name == "uv":
        return ["Using CPython 3.12.13", "Creating virtualenv at: .venv", f"Resolved {limit + 200} packages in 220.48ms", "Preparing packages..."] + [f"package_{i:<24} {'-' * 30}  {i + 1}.00 KiB/{i + 1}.00 KiB" for i in range(limit)]
    if name == "wpt":
        return ["Running 17849 tests in web-platform-tests", "[0/17849] No tests running.", "    ▶ Unexpected subtest result in :", "    │ ERROR [expected PASS] FAIL test_ assert_throws_dom"] + [f"[{i}/17849] /css/css-color/test-{i}.html" for i in range(limit)]
    if name == "ansible":
        return ["PLAY [all] *********************************************************************", "TASK [Gathering Facts] *********************************************************"] + [f"changed: [server{i}.example.com]" for i in range(limit)] + ["PLAY RECAP *********************************************************************"]
    return [f"{name}: working on task {i}" for i in range(limit)]


def run_modules(cfg):
    modules = cfg["modules"] or MODULES
    count = cfg["exit_after_modules"] or len(modules)
    line_count = cfg["instant"] or 32
    for name in modules[:count]:
        for line in module_lines(name, line_count):
            print(line)
    return 0


def print_completion(shell):
    words = " ".join(MODULES)
    opts = "-l -m -s -i -h -V --list-modules --modules --speed-factor --instant-print-lines --inhibit --exit-after-time --exit-after-modules --print-completions --print-manpage --help --version"
    if shell == "bash":
        print(f"""_genact() {{
    local cur prev opts
    COMPREPLY=()
    cur="${{COMP_WORDS[COMP_CWORD]}}"
    prev="${{COMP_WORDS[COMP_CWORD-1]}}"
    opts="{opts}"
    case "${{prev}}" in
        --modules|-m)
            COMPREPLY=($(compgen -W "{words}" -- "${{cur}}"))
            return 0
            ;;
        --print-completions)
            COMPREPLY=($(compgen -W "bash elvish fish powershell zsh" -- "${{cur}}"))
            return 0
            ;;
    esac
    COMPREPLY=($(compgen -W "${{opts}}" -- "${{cur}}"))
}}
complete -F _genact genact""")
    elif shell == "fish":
        print(f"complete -c genact -s m -l modules -d 'Run only these modules' -r -f -a \"{words}\"")
    elif shell == "zsh":
        print(f"#compdef genact\n_arguments '*--modules[Run only these modules]: :({words})'")
    elif shell == "powershell":
        print("Register-ArgumentCompleter -Native -CommandName genact -ScriptBlock { param($wordToComplete) }")
    else:
        print("edit:completion:arg-completer[genact] = {|@words| put -- --help --version }")


def main(argv):
    if argv in (["--version"], ["-V"]):
        print("genact 1.5.1")
        return 0
    if argv in (["--list-modules"], ["-l"]):
        print("Available modules:")
        for module in MODULES:
            print(f"  {module}")
        return 0
    if argv in (["--help"], ["-h"]):
        sys.stdout.write(HELP)
        return 0

    cfg = parse(argv)
    if cfg["manpage"]:
        print(MANPAGE)
        return 0
    if cfg["completion"]:
        print_completion(cfg["completion"])
        return 0
    return run_modules(cfg)


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
