#!/bin/bash
set -e
rm -f executable
cp genact.py executable
chmod +x executable
