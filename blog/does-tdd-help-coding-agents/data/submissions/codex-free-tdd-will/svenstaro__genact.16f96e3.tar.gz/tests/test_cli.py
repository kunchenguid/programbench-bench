import os
import subprocess
import unittest


ROOT = os.path.dirname(os.path.dirname(__file__))
EXE = os.path.join(ROOT, "executable")


def run_cmd(*args):
    return subprocess.run(
        [EXE, *args],
        cwd=ROOT,
        text=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
    )


class CliTests(unittest.TestCase):
    def test_version_and_module_listing(self):
        version = run_cmd("--version")
        self.assertEqual(version.returncode, 0)
        self.assertEqual(version.stdout, "genact 1.5.1\n")

        listing = run_cmd("--list-modules")
        self.assertEqual(listing.returncode, 0)
        self.assertIn("Available modules:\n", listing.stdout)
        self.assertIn("  cargo\n", listing.stdout)
        self.assertIn("  wpt\n", listing.stdout)

    def test_help_and_invalid_arguments(self):
        help_result = run_cmd("--help")
        self.assertEqual(help_result.returncode, 0)
        self.assertIn("A nonsense activity generator\n\nUsage: executable [OPTIONS]", help_result.stdout)
        self.assertIn("--print-completions <shell>", help_result.stdout)

        bogus = run_cmd("--bogus")
        self.assertEqual(bogus.returncode, 2)
        self.assertIn("error: unexpected argument '--bogus' found", bogus.stderr)
        self.assertIn("For more information, try '--help'.", bogus.stderr)

        bad_module = run_cmd("-m", "nope")
        self.assertEqual(bad_module.returncode, 2)
        self.assertIn("error: invalid value 'nope' for '--modules <MODULES>'", bad_module.stderr)
        self.assertIn("possible values: ansible, bootlog", bad_module.stderr)

    def test_selected_modules_emit_recognizable_transcripts(self):
        cargo = run_cmd("-m", "cargo", "-i", "3", "--exit-after-modules", "1", "-s", "100")
        self.assertEqual(cargo.returncode, 0)
        self.assertIn("Downloading", cargo.stdout)
        self.assertIn("Saving work to disk...", cargo.stdout)

        weblog = run_cmd("-m", "weblog", "-i", "2", "--exit-after-modules", "1", "-s", "100")
        self.assertEqual(weblog.returncode, 0)
        self.assertRegex(weblog.stdout, r'"GET /[^"]+ HTTP/1\.0" (200|201|400|401|403|404|500|502|503)')

    def test_generated_manpage_and_completions(self):
        manpage = run_cmd("--print-manpage")
        self.assertEqual(manpage.returncode, 0)
        self.assertIn(".TH genact 1", manpage.stdout)
        self.assertIn("genact \\- A nonsense activity generator", manpage.stdout)

        bash = run_cmd("--print-completions", "bash")
        self.assertEqual(bash.returncode, 0)
        self.assertIn("_genact()", bash.stdout)
        self.assertIn("--list-modules --modules", bash.stdout)

        bad_shell = run_cmd("--print-completions", "tcsh")
        self.assertEqual(bad_shell.returncode, 2)
        self.assertIn("invalid value 'tcsh' for '--print-completions <shell>'", bad_shell.stderr)

    def test_missing_option_values_are_cli_errors(self):
        missing = run_cmd("-i")
        self.assertEqual(missing.returncode, 2)
        self.assertIn("a value is required", missing.stderr)


if __name__ == "__main__":
    unittest.main()
