#!/usr/bin/env python3
import sys
import re
import html
import json
from html.parser import HTMLParser

INPUT_FORMATS = """asciidoc
biblatex
bibtex
bits
commonmark
commonmark_x
creole
csljson
csv
djot
docbook
docx
dokuwiki
endnotexml
epub
fb2
gfm
haddock
html
ipynb
jats
jira
json
latex
man
markdown
markdown_github
markdown_mmd
markdown_phpextra
markdown_strict
mdoc
mediawiki
muse
native
odt
opml
org
pod
pptx
ris
rst
rtf
t2t
textile
tikiwiki
tsv
twiki
typst
vimwiki
xlsx
xml
"""

OUTPUT_FORMATS = """ansi
asciidoc
asciidoc_legacy
asciidoctor
bbcode
bbcode_fluxbb
bbcode_hubzilla
bbcode_phpbb
bbcode_steam
bbcode_xenforo
beamer
biblatex
bibtex
chunkedhtml
commonmark
commonmark_x
context
csljson
djot
docbook
docbook4
docbook5
docx
dokuwiki
dzslides
epub
epub2
epub3
fb2
gfm
haddock
html
html4
html5
icml
ipynb
jats
jats_archiving
jats_articleauthoring
jats_publishing
jira
json
latex
man
markdown
markdown_github
markdown_mmd
markdown_phpextra
markdown_strict
markua
mediawiki
ms
muse
native
odt
opendocument
opml
org
pdf
plain
pptx
revealjs
rst
rtf
s5
slideous
slidy
tei
texinfo
textile
typst
vimdoc
xml
xwiki
zimwiki
"""

HELP = """executable [OPTIONS] [FILES]
  -f FORMAT, -r FORMAT  --from=FORMAT, --read=FORMAT
  -t FORMAT, -w FORMAT  --to=FORMAT, --write=FORMAT
  -o FILE               --output=FILE
  -s[true|false]        --standalone[=true|false]
  -M KEY[:VALUE]        --metadata=KEY[:VALUE]
  -V KEY[:VALUE]        --variable=KEY[:VALUE]
                        --toc[=true|false], --table-of-contents[=true|false]
  -N[true|false]        --number-sections[=true|false]
  -F PROGRAM            --filter=PROGRAM
  -L SCRIPTPATH         --lua-filter=SCRIPTPATH
  -C                    --citeproc
                        --list-input-formats
                        --list-output-formats
                        --list-extensions[=FORMAT]
  -D FORMAT             --print-default-template=FORMAT
  -v                    --version
  -h                    --help
"""


def slugify(text):
    plain = re.sub(r"[*_`~\[\]\(\)]", "", text).lower()
    plain = re.sub(r"[^a-z0-9 -]", "", plain)
    plain = re.sub(r"\s+", "-", plain.strip())
    return plain


def parse_blocks(text):
    lines = text.replace("\r\n", "\n").replace("\r", "\n").split("\n")
    blocks = []
    i = 0
    while i < len(lines):
        line = lines[i]
        if not line.strip():
            i += 1
            continue
        m = re.match(r"^(#{1,6})\s+(.*?)(?:\s+#+)?$", line)
        if m:
            blocks.append({"type": "heading", "level": len(m.group(1)), "text": m.group(2)})
            i += 1
            continue
        m = re.match(r"^```\s*([A-Za-z0-9_+-]*)\s*$", line)
        if m:
            lang = m.group(1)
            code = []
            i += 1
            while i < len(lines) and not re.match(r"^```\s*$", lines[i]):
                code.append(lines[i])
                i += 1
            if i < len(lines):
                i += 1
            blocks.append({"type": "code_block", "lang": lang, "text": "\n".join(code)})
            continue
        if re.match(r"^\s*>", line):
            quote = []
            while i < len(lines) and re.match(r"^\s*>", lines[i]):
                quote.append(re.sub(r"^\s*>\s?", "", lines[i]).strip())
                i += 1
            blocks.append({"type": "blockquote", "blocks": parse_blocks(" ".join(quote))})
            continue
        if re.match(r"^\s*[-+*]\s+", line):
            items = []
            while i < len(lines) and re.match(r"^\s*[-+*]\s+", lines[i]):
                items.append(re.sub(r"^\s*[-+*]\s+", "", lines[i]).strip())
                i += 1
            blocks.append({"type": "bullet_list", "items": items})
            continue
        if re.match(r"^\s*\d+[.)]\s+", line):
            items = []
            while i < len(lines) and re.match(r"^\s*\d+[.)]\s+", lines[i]):
                items.append(re.sub(r"^\s*\d+[.)]\s+", "", lines[i]).strip())
                i += 1
            blocks.append({"type": "ordered_list", "items": items})
            continue
        para = [line.strip()]
        i += 1
        while i < len(lines) and lines[i].strip() and not re.match(r"^(#{1,6})\s+", lines[i]) and not re.match(r"^\s*[-+*]\s+", lines[i]) and not re.match(r"^\s*\d+[.)]\s+", lines[i]) and not re.match(r"^\s*>", lines[i]) and not re.match(r"^```", lines[i]):
            para.append(lines[i].strip())
            i += 1
        blocks.append({"type": "paragraph", "text": " ".join(para)})
    return blocks


class SimpleHTMLReader(HTMLParser):
    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.blocks = []
        self.current = None
        self.inline_stack = []
        self.href_stack = []

    def push_current(self):
        if self.current and self.current.get("text", "").strip():
            self.current["text"] = re.sub(r"\s+", " ", self.current["text"]).strip()
            self.blocks.append(self.current)
        self.current = None

    def handle_starttag(self, tag, attrs):
        if re.fullmatch(r"h[1-6]", tag):
            self.push_current()
            self.current = {"type": "heading", "level": int(tag[1]), "text": ""}
        elif tag == "p":
            self.push_current()
            self.current = {"type": "paragraph", "text": ""}
        elif tag in ("em", "i"):
            self.inline_stack.append("*")
            self.add_text("*")
        elif tag in ("strong", "b"):
            self.inline_stack.append("**")
            self.add_text("**")
        elif tag == "code":
            self.inline_stack.append("`")
            self.add_text("`")
        elif tag == "a":
            href = dict(attrs).get("href", "")
            self.href_stack.append(href)
            self.add_text("[")

    def handle_endtag(self, tag):
        if tag in ("p", "h1", "h2", "h3", "h4", "h5", "h6"):
            self.push_current()
        elif tag in ("em", "i", "strong", "b", "code") and self.inline_stack:
            self.add_text(self.inline_stack.pop())
        elif tag == "a":
            href = self.href_stack.pop() if self.href_stack else ""
            self.add_text(f"]({href})")

    def handle_data(self, data):
        self.add_text(data)

    def add_text(self, text):
        if self.current is None:
            self.current = {"type": "paragraph", "text": ""}
        self.current["text"] += text


def parse_html_blocks(text):
    parser = SimpleHTMLReader()
    parser.feed(text)
    parser.push_current()
    return parser.blocks


def html_inlines(text):
    s = html.escape(text, quote=False)
    s = re.sub(r"\[([^\]]+)\]\(([^)]+)\)", r'<a href="\2">\1</a>', s)
    s = re.sub(r"`([^`]+)`", r"<code>\1</code>", s)
    s = re.sub(r"\*\*([^*]+)\*\*", r"<strong>\1</strong>", s)
    s = re.sub(r"\*([^*]+)\*", r"<em>\1</em>", s)
    s = re.sub(r"\s*~~([^~]+)~~", r"\n<del>\1</del>", s)
    return s


def write_html(blocks):
    out = []
    for block in blocks:
        if block["type"] == "heading":
            level = block["level"]
            out.append(f'<h{level} id="{slugify(block["text"])}">{html_inlines(block["text"])}</h{level}>')
        elif block["type"] == "paragraph":
            out.append(f'<p>{html_inlines(block["text"])}</p>')
        elif block["type"] == "bullet_list":
            out.append("<ul>")
            for item in block["items"]:
                out.append(f"<li>{html_inlines(item)}</li>")
            out.append("</ul>")
        elif block["type"] == "ordered_list":
            out.append('<ol type="1">')
            for item in block["items"]:
                out.append(f"<li>{html_inlines(item)}</li>")
            out.append("</ol>")
        elif block["type"] == "blockquote":
            out.append("<blockquote>")
            inner = write_html(block["blocks"]).rstrip("\n")
            if inner:
                out.extend(inner.splitlines())
            out.append("</blockquote>")
        elif block["type"] == "code_block":
            lang = block["lang"]
            cls = f" {lang}" if lang else ""
            code = html.escape(block["text"], quote=True)
            out.append(
                f'<div class="sourceCode" id="cb1"><pre\nclass="sourceCode{cls.strip() and " " + lang}"><code class="sourceCode{cls}"><span id="cb1-1"><a href="#cb1-1" aria-hidden="true" tabindex="-1"></a>{code}</span></code></pre></div>'
            )
    return "\n".join(out) + ("\n" if out else "")


def standalone_html(fragment, title="-"):
    return (
        "<!DOCTYPE html>\n"
        '<html xmlns="http://www.w3.org/1999/xhtml">\n'
        "<head>\n"
        '  <meta charset="utf-8" />\n'
        '  <meta name="generator" content="pandoc" />\n'
        '  <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=yes" />\n'
        f"  <title>{html.escape(title)}</title>\n"
        "</head>\n"
        "<body>\n"
        f"{fragment}"
        "</body>\n"
        "</html>\n"
    )


def plain_inlines(text):
    s = re.sub(r"\*\*([^*]+)\*\*", r"\1", text)
    s = re.sub(r"\*([^*]+)\*", r"\1", s)
    s = re.sub(r"`([^`]+)`", r"\1", s)
    s = re.sub(r"\[([^\]]+)\]\([^)]+\)", r"\1", s)
    return s


def write_plain(blocks):
    parts = []
    for block in blocks:
        if block["type"] in ("heading", "paragraph"):
            parts.append(plain_inlines(block["text"]))
        elif block["type"] == "bullet_list":
            parts.append("\n".join("- " + plain_inlines(item) for item in block["items"]))
    return "\n\n".join(parts) + ("\n" if parts else "")


def latex_escape(text):
    replacements = {
        "\\": r"\textbackslash{}",
        "&": r"\&",
        "%": r"\%",
        "$": r"\$",
        "#": r"\#",
        "_": r"\_",
        "{": r"\{",
        "}": r"\}",
    }
    return "".join(replacements.get(ch, ch) for ch in text)


def latex_inlines(text):
    s = latex_escape(text)
    s = re.sub(r"\[([^\]]+)\]\(([^)]+)\)", r"\\href{\2}{\1}", s)
    s = re.sub(r"`([^`]+)`", r"\\texttt{\1}", s)
    s = re.sub(r"\*\*([^*]+)\*\*", r"\\textbf{\1}", s)
    s = re.sub(r"\*([^*]+)\*", r"\\emph{\1}", s)
    s = re.sub(r"~~([^~]+)~~", r"\\st{\1}", s)
    return s


def write_latex(blocks):
    parts = []
    section_cmds = ["section", "subsection", "subsubsection", "paragraph", "subparagraph", "subparagraph"]
    for block in blocks:
        if block["type"] == "heading":
            cmd = section_cmds[min(block["level"], 6) - 1]
            parts.append(f"\\{cmd}{{{latex_inlines(block['text'])}}}\\label{{{slugify(block['text'])}}}")
        elif block["type"] == "paragraph":
            parts.append(latex_inlines(block["text"]))
        elif block["type"] == "bullet_list":
            lines = ["\\begin{itemize}", "\\tightlist"]
            for item in block["items"]:
                lines.extend(["\\item", "  " + latex_inlines(item)])
            lines.append("\\end{itemize}")
            parts.append("\n".join(lines))
        elif block["type"] == "ordered_list":
            lines = ["\\begin{enumerate}", "\\def\\labelenumi{\\arabic{enumi}.}", "\\tightlist"]
            for item in block["items"]:
                lines.extend(["\\item", "  " + latex_inlines(item)])
            lines.append("\\end{enumerate}")
            parts.append("\n".join(lines))
        elif block["type"] == "blockquote":
            inner = write_latex(block["blocks"]).rstrip("\n")
            parts.append("\\begin{quote}\n" + inner + "\n\\end{quote}")
        elif block["type"] == "code_block":
            parts.append("\\begin{verbatim}\n" + block["text"] + "\n\\end{verbatim}")
    return "\n\n".join(parts) + ("\n" if parts else "")


def write_markdown(blocks):
    parts = []
    for block in blocks:
        if block["type"] == "heading":
            parts.append("#" * block["level"] + " " + block["text"])
        elif block["type"] == "paragraph":
            parts.append(block["text"])
        elif block["type"] == "bullet_list":
            parts.append("\n".join("- " + item for item in block["items"]))
        elif block["type"] == "ordered_list":
            parts.append("\n".join(f"{idx}.  {item}" for idx, item in enumerate(block["items"], 1)))
        elif block["type"] == "blockquote":
            inner = write_markdown(block["blocks"]).strip().replace("\n", "\n> ")
            parts.append("> " + inner)
        elif block["type"] == "code_block":
            lang = (" " + block["lang"]) if block["lang"] else ""
            parts.append(f"```{lang}\n{block['text']}\n```")
    return "\n\n".join(parts) + ("\n" if parts else "")


def native_inlines(text):
    return "[ " + " , ".join(f'Str "{word}"' for word in plain_inlines(text).split()) + " ]"


def write_native(blocks):
    lines = []
    for block in blocks:
        prefix = "[ " if not lines else ", "
        if block["type"] == "heading":
            lines.append(f'{prefix}Header {block["level"]} ( "{slugify(block["text"])}" , [] , [] ) {native_inlines(block["text"])}')
        elif block["type"] == "paragraph":
            lines.append(f"{prefix}Para {native_inlines(block['text'])}")
        elif block["type"] == "bullet_list":
            items = " , ".join(native_inlines(item) for item in block["items"])
            lines.append(f"{prefix}BulletList [ {items} ]")
        elif block["type"] == "ordered_list":
            items = " , ".join(native_inlines(item) for item in block["items"])
            lines.append(f"{prefix}OrderedList ( 1 , DefaultStyle , DefaultDelim ) [ {items} ]")
        elif block["type"] == "code_block":
            lines.append(f'{prefix}CodeBlock ( "" , ["{block["lang"]}"] , [] ) "{block["text"]}"')
    if not lines:
        return "[]\n"
    return "\n".join(lines) + "\n]\n"


def json_inlines(text):
    return [{"t": "Str", "c": word} for word in plain_inlines(text).split()]


def block_to_json(block):
    if block["type"] == "heading":
        return {"t": "Header", "c": [block["level"], [slugify(block["text"]), [], []], json_inlines(block["text"])]}
    if block["type"] == "paragraph":
        return {"t": "Para", "c": json_inlines(block["text"])}
    if block["type"] == "bullet_list":
        return {"t": "BulletList", "c": [[{"t": "Plain", "c": json_inlines(item)}] for item in block["items"]]}
    if block["type"] == "ordered_list":
        return {"t": "OrderedList", "c": [[1, {"t": "DefaultStyle"}, {"t": "DefaultDelim"}], [[{"t": "Plain", "c": json_inlines(item)}] for item in block["items"]]]}
    if block["type"] == "blockquote":
        return {"t": "BlockQuote", "c": [block_to_json(b) for b in block["blocks"]]}
    if block["type"] == "code_block":
        return {"t": "CodeBlock", "c": [["", [block["lang"]] if block["lang"] else [], []], block["text"]]}
    return {"t": "Para", "c": []}


def write_json(blocks):
    doc = {"pandoc-api-version": [1, 23, 1], "meta": {}, "blocks": [block_to_json(b) for b in blocks]}
    return json.dumps(doc, separators=(",", ":")) + "\n"


def parse_args(argv):
    opts = {"to": "html", "from": "markdown", "output": None, "standalone": False, "files": []}
    i = 0
    while i < len(argv):
        arg = argv[i]
        if arg in ("-t", "-w", "--to", "--write"):
            i += 1
            opts["to"] = argv[i]
        elif arg in ("-f", "-r", "--from", "--read"):
            i += 1
            opts["from"] = argv[i]
        elif arg in ("-o", "--output"):
            i += 1
            opts["output"] = argv[i]
        elif arg.startswith("--to=") or arg.startswith("--write="):
            opts["to"] = arg.split("=", 1)[1]
        elif arg.startswith("--from=") or arg.startswith("--read="):
            opts["from"] = arg.split("=", 1)[1]
        elif arg.startswith("--output="):
            opts["output"] = arg.split("=", 1)[1]
        elif arg.startswith("-t") and len(arg) > 2:
            opts["to"] = arg[2:]
        elif arg.startswith("-f") and len(arg) > 2:
            opts["from"] = arg[2:]
        elif arg.startswith("-o") and len(arg) > 2:
            opts["output"] = arg[2:]
        elif arg in ("-s", "--standalone") or arg.startswith("--standalone="):
            opts["standalone"] = not arg.endswith("=false")
        elif arg.startswith("-s") and len(arg) > 2:
            opts["standalone"] = arg[2:] != "false"
        elif arg in ("--wrap", "--columns", "--toc-depth", "--metadata-file", "--template", "--css", "--highlight-style", "--print-default-template", "-D", "-M", "-V"):
            i += 1
        elif arg.startswith(("--wrap=", "--columns=", "--toc-depth=", "--metadata=", "--variable=", "--template=", "--css=", "--highlight-style=", "--print-default-template=")):
            pass
        elif arg in ("--toc", "--table-of-contents", "--number-sections", "-N", "--ascii", "--quiet", "--verbose", "--no-highlight"):
            pass
        elif arg.startswith("-"):
            print(f"Unknown option {arg}.", file=sys.stderr)
            print("Try executable --help for more information.", file=sys.stderr)
            raise SystemExit(6)
        else:
            opts["files"].append(arg)
        i += 1
    return opts


def read_input(files):
    if not files:
        return sys.stdin.read()
    chunks = []
    for path in files:
        try:
            with open(path, encoding="utf-8") as f:
                chunks.append(f.read())
        except OSError as e:
            print(f"executable: {path}: withBinaryFile: does not exist ({e.strerror})", file=sys.stderr)
            raise SystemExit(1)
    return "\n\n".join(chunk.rstrip("\n") for chunk in chunks) + "\n"


def infer_output_format(path):
    ext = path.rsplit(".", 1)[-1].lower() if "." in path else ""
    return {
        "html": "html",
        "htm": "html",
        "xhtml": "html",
        "tex": "latex",
        "ltx": "latex",
        "md": "markdown",
        "markdown": "markdown",
        "txt": "plain",
        "text": "plain",
    }.get(ext)


def main(argv):
    if "--help" in argv or "-h" in argv:
        sys.stdout.write(HELP)
        return 0
    if "--version" in argv or "-v" in argv:
        print("pandoc 3.9.0.2")
        print("Features: +server +lua")
        print("Scripting engine: Lua 5.4")
        print("User data directory: /home/agent/.local/share/pandoc")
        print("Copyright (C) 2006-2025 John MacFarlane. Web:  https://pandoc.org")
        print("This is free software; see the source for copying conditions. There is no")
        print("warranty, not even for merchantability or fitness for a particular purpose.")
        return 0
    if "--list-input-formats" in argv:
        sys.stdout.write(INPUT_FORMATS)
        return 0
    if "--list-output-formats" in argv:
        sys.stdout.write(OUTPUT_FORMATS)
        return 0
    opts = parse_args(argv)
    if opts["to"] == "html" and opts["output"]:
        opts["to"] = infer_output_format(opts["output"]) or opts["to"]
    known = set(OUTPUT_FORMATS.splitlines()) | {"html5", "html4"}
    if opts["to"] not in known:
        print(f"Unknown output format {opts['to']}", file=sys.stderr)
        return 22
    source = read_input(opts["files"])
    blocks = parse_html_blocks(source) if opts["from"] in ("html", "html4", "html5") else parse_blocks(source)
    if opts["to"] == "plain":
        output = write_plain(blocks)
    elif opts["to"] in ("latex", "beamer"):
        output = write_latex(blocks)
    elif opts["to"] in ("markdown", "markdown_strict", "gfm", "commonmark", "commonmark_x"):
        output = write_markdown(blocks)
    elif opts["to"] == "native":
        output = write_native(blocks)
    elif opts["to"] == "json":
        output = write_json(blocks)
    else:
        output = write_html(blocks)
        if opts["standalone"]:
            output = standalone_html(output)
    if opts["output"]:
        with open(opts["output"], "w", encoding="utf-8") as f:
            f.write(output)
    else:
        sys.stdout.write(output)
    return 0


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
