#!/usr/bin/env python3
import os
import subprocess
import tempfile


ROOT = os.path.dirname(__file__)
BIN = os.path.join(ROOT, "executable")


def run_cmd(args, input_text=""):
    return subprocess.run(
        [BIN] + args,
        input=input_text,
        text=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
    )


def test_version():
    result = run_cmd(["--version"])
    assert result.returncode == 0
    assert result.stdout.splitlines()[0] == "pandoc 3.9.0.2"
    assert "Features: +server +lua" in result.stdout


def test_default_markdown_to_html():
    result = run_cmd([], "# Hello\n\nThis is *em* and **strong**.\n\n- one\n- two\n")
    assert result.returncode == 0
    assert result.stdout == (
        '<h1 id="hello">Hello</h1>\n'
        '<p>This is <em>em</em> and <strong>strong</strong>.</p>\n'
        '<ul>\n'
        '<li>one</li>\n'
        '<li>two</li>\n'
        '</ul>\n'
    )


def test_markdown_to_plain():
    result = run_cmd(["-t", "plain"], "# Hello\n\nThis is *em* and **strong**.\n\n- one\n- two\n")
    assert result.returncode == 0
    assert result.stdout == "Hello\n\nThis is em and strong.\n\n- one\n- two\n"


def test_rich_markdown_to_html():
    source = (
        "A [link](https://e.com) and `code` and ~~strike~~.\n\n"
        "> quote\n> line\n\n"
        "1. first\n2. second\n\n"
        "```python\nprint(\"hi\")\n```\n"
    )
    result = run_cmd([], source)
    assert result.returncode == 0
    assert result.stdout == (
        '<p>A <a href="https://e.com">link</a> and <code>code</code> and\n'
        '<del>strike</del>.</p>\n'
        '<blockquote>\n'
        '<p>quote line</p>\n'
        '</blockquote>\n'
        '<ol type="1">\n'
        '<li>first</li>\n'
        '<li>second</li>\n'
        '</ol>\n'
        '<div class="sourceCode" id="cb1"><pre\n'
        'class="sourceCode python"><code class="sourceCode python"><span id="cb1-1"><a href="#cb1-1" aria-hidden="true" tabindex="-1"></a>print(&quot;hi&quot;)</span></code></pre></div>\n'
    )


def test_markdown_to_latex():
    result = run_cmd(["-t", "latex"], "# Hello\n\nThis is *em* and **strong**.\n\n- one\n- two\n")
    assert result.returncode == 0
    assert result.stdout == (
        "\\section{Hello}\\label{hello}\n\n"
        "This is \\emph{em} and \\textbf{strong}.\n\n"
        "\\begin{itemize}\n"
        "\\tightlist\n"
        "\\item\n"
        "  one\n"
        "\\item\n"
        "  two\n"
        "\\end{itemize}\n"
    )


def test_file_input_and_output_option():
    with tempfile.TemporaryDirectory() as tmp:
        src = os.path.join(tmp, "input.md")
        dst = os.path.join(tmp, "out.html")
        with open(src, "w", encoding="utf-8") as f:
            f.write("# File\n\nText\n")
        result = run_cmd(["-o", dst, src])
        assert result.returncode == 0
        assert result.stdout == ""
        with open(dst, encoding="utf-8") as f:
            assert f.read() == '<h1 id="file">File</h1>\n<p>Text</p>\n'


def test_format_lists_and_help():
    result = run_cmd(["--list-input-formats"])
    assert result.returncode == 0
    assert result.stdout.splitlines()[:3] == ["asciidoc", "biblatex", "bibtex"]
    assert "markdown" in result.stdout.splitlines()
    result = run_cmd(["--list-output-formats"])
    assert result.returncode == 0
    assert result.stdout.splitlines()[:3] == ["ansi", "asciidoc", "asciidoc_legacy"]
    assert "plain" in result.stdout.splitlines()
    result = run_cmd(["--help"])
    assert result.returncode == 0
    assert result.stdout.startswith("executable [OPTIONS] [FILES]\n")
    assert "--from=FORMAT" in result.stdout


def test_markdown_writer_normalizes_lists_and_code():
    source = "# H1\n\n1. first\n2. second\n\n``` python\nprint(\"hi\")\n```\n"
    result = run_cmd(["-t", "markdown"], source)
    assert result.returncode == 0
    assert result.stdout == "# H1\n\n1.  first\n2.  second\n\n``` python\nprint(\"hi\")\n```\n"


def test_unknown_option_and_output_format_errors():
    result = run_cmd(["--bad-option"])
    assert result.returncode == 6
    assert result.stderr == "Unknown option --bad-option.\nTry executable --help for more information.\n"
    result = run_cmd(["-t", "nope"], "x")
    assert result.returncode == 22
    assert result.stderr == "Unknown output format nope\n"


def test_missing_input_file_error():
    result = run_cmd(["missing.md"])
    assert result.returncode == 1
    assert result.stderr == "executable: missing.md: withBinaryFile: does not exist (No such file or directory)\n"


def test_standalone_html_wraps_fragment():
    result = run_cmd(["-s", "-t", "html"], "# Title\n\nText\n")
    assert result.returncode == 0
    assert result.stdout.startswith("<!DOCTYPE html>\n<html")
    assert "<title>-</title>" in result.stdout
    assert "<body>\n<h1 id=\"title\">Title</h1>\n<p>Text</p>\n</body>" in result.stdout


def test_simple_html_input_to_markdown():
    result = run_cmd(["-f", "html", "-t", "markdown"], "<h1>Hello</h1><p>A <em>small</em> test.</p>")
    assert result.returncode == 0
    assert result.stdout == "# Hello\n\nA *small* test.\n"


def test_output_extension_infers_writer():
    with tempfile.TemporaryDirectory() as tmp:
        dst = os.path.join(tmp, "out.tex")
        result = run_cmd(["-o", dst], "# File\n")
        assert result.returncode == 0
        with open(dst, encoding="utf-8") as f:
            assert f.read() == "\\section{File}\\label{file}\n"


def test_native_and_json_writers_for_simple_document():
    native = run_cmd(["-t", "native"], "# Hello\n\nText\n")
    assert native.returncode == 0
    assert native.stdout == '[ Header 1 ( "hello" , [] , [] ) [ Str "Hello" ]\n, Para [ Str "Text" ]\n]\n'
    json_result = run_cmd(["-t", "json"], "# Hello\n")
    assert json_result.returncode == 0
    assert '"pandoc-api-version"' in json_result.stdout
    assert '"Header"' in json_result.stdout
    assert '"Hello"' in json_result.stdout


def main():
    test_version()
    test_default_markdown_to_html()
    test_markdown_to_plain()
    test_rich_markdown_to_html()
    test_markdown_to_latex()
    test_file_input_and_output_option()
    test_format_lists_and_help()
    test_markdown_writer_normalizes_lists_and_code()
    test_unknown_option_and_output_format_errors()
    test_missing_input_file_error()
    test_standalone_html_wraps_fragment()
    test_simple_html_input_to_markdown()
    test_output_extension_infers_writer()
    test_native_and_json_writers_for_simple_document()
    print("tests passed")


if __name__ == "__main__":
    main()
