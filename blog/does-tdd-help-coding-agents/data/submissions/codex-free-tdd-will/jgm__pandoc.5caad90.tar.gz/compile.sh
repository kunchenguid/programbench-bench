#!/bin/bash
set -e
cp pandoc_lite.py executable
chmod +x executable
