#!/bin/bash
set -e
cp src/fzf_clone.py executable
chmod +x executable
