#!/usr/bin/env python3
import sys
import re
import os
import shlex


ANSI_RE = re.compile(r"\x1b\[[0-?]*[ -/]*[@-~]")


def fuzzy_positions(text, query, case_sensitive=False):
    if not query:
        return []
    haystack = text if case_sensitive else text.lower()
    needle = query if case_sensitive else query.lower()
    pos = 0
    positions = []
    for ch in needle:
        found = haystack.find(ch, pos)
        if found < 0:
            return None
        positions.append(found)
        pos = found + 1
    return positions


def fuzzy_match(text, query, case_sensitive=False):
    return fuzzy_positions(text, query, case_sensitive) is not None


def normalize_for_case(text, case_sensitive):
    return text if case_sensitive else text.lower()


def smart_case(query, forced=None):
    if forced == "ignore":
        return False
    if forced == "respect":
        return True
    return any(ch.isupper() for ch in query)


def split_query_groups(query):
    groups = [[]]
    for token in query.split():
        if token == "|":
            if groups[-1]:
                groups.append([])
            continue
        groups[-1].append(token)
    return [group for group in groups if group]


def term_match(text, token, exact_mode=False, case_mode=None):
    inverse = token.startswith("!")
    if inverse:
        token = token[1:]
    exact = exact_mode or inverse
    if token.startswith("'"):
        token = token[1:]
        exact = not exact_mode
    prefix = token.startswith("^")
    suffix = token.endswith("$") and len(token) > 0
    if prefix:
        token = token[1:]
        exact = True
    if suffix:
        token = token[:-1]
        exact = True

    case_sensitive = smart_case(token, case_mode)
    haystack = normalize_for_case(text, case_sensitive)
    needle = normalize_for_case(token, case_sensitive)

    if prefix and suffix:
        ok = haystack == needle
        positions = [0] if ok and needle else []
    elif prefix:
        ok = haystack.startswith(needle)
        positions = [0] if ok and needle else []
    elif suffix:
        ok = haystack.endswith(needle)
        start = len(haystack) - len(needle)
        positions = [start] if ok and needle else []
    elif exact:
        start = haystack.find(needle)
        ok = start >= 0
        positions = list(range(start, start + len(needle))) if ok else None
    else:
        positions = fuzzy_positions(text, token, case_sensitive)
        ok = positions is not None

    if inverse:
        return (not ok), []
    return ok, positions


def position_bonus(text, positions):
    if not positions:
        return 0
    bonus = 0
    last = None
    for pos in positions:
        if pos == 0:
            bonus += 3
        elif pos < len(text):
            prev = text[pos - 1]
            cur = text[pos]
            if not prev.isalnum():
                bonus += 3
            elif prev.islower() and cur.isupper():
                bonus += 2
        if last is not None and pos == last + 1:
            bonus += 2
        last = pos
    return bonus


def query_match_score(text, query, exact_mode=False, case_mode=None):
    if not query:
        return (0, len(text), 0)
    best = None
    for group in split_query_groups(query):
        all_positions = []
        ok = True
        for token in group:
            term_ok, positions = term_match(text, token, exact_mode, case_mode)
            if not term_ok:
                ok = False
                break
            if positions:
                all_positions.extend(positions)
        if ok:
            if all_positions:
                span = max(all_positions) - min(all_positions) + 1
                begin = min(all_positions)
            else:
                span = 0
                begin = 0
            if all_positions:
                bonus = position_bonus(text, sorted(all_positions))
                score = (span, -bonus, len(text), begin)
            else:
                score = (0, 0, 0, 0)
            if best is None or score < best:
                best = score
    return best


def split_fields(line, delimiter=None):
    if delimiter is None:
        return line.split()
    return re.split(delimiter, line)


def resolve_index(n, count):
    if n > 0:
        return n - 1
    if n < 0:
        return count + n
    return None


def fields_for_expr(fields, expr):
    count = len(fields)
    if ".." in expr:
        left, right = expr.split("..", 1)
        start = 0 if left == "" else resolve_index(int(left), count)
        end = count - 1 if right == "" else resolve_index(int(right), count)
        if start is None or end is None:
            return []
        lo = max(0, start)
        hi = min(count - 1, end)
        if lo > hi:
            return []
        return fields[lo : hi + 1]
    idx = resolve_index(int(expr), count)
    if idx is None or idx < 0 or idx >= count:
        return []
    return [fields[idx]]


def select_fields(line, spec, delimiter=None):
    fields = split_fields(line, delimiter)
    selected = []
    for expr in spec.split(","):
        expr = expr.strip()
        if expr:
            selected.extend(fields_for_expr(fields, expr))
    return " ".join(selected)


def apply_template(line, template, ordinal, delimiter=None):
    fields = split_fields(line, delimiter)

    def repl(match):
        expr = match.group(1)
        if expr == "n":
            return str(ordinal)
        return " ".join(fields_for_expr(fields, expr))

    if "{" in template and "}" in template:
        return re.sub(r"\{([^{}]+)\}", repl, template)
    return select_fields(line, template, delimiter)


def main(argv):
    default_args = []
    opts_file = os.environ.get("FZF_DEFAULT_OPTS_FILE")
    if opts_file:
        try:
            with open(os.path.expanduser(opts_file), "r", encoding="utf-8") as f:
                default_args.extend(shlex.split(f.read()))
        except OSError:
            pass
    if os.environ.get("FZF_DEFAULT_OPTS"):
        default_args.extend(shlex.split(os.environ["FZF_DEFAULT_OPTS"]))
    argv = default_args + list(argv)

    query = None
    initial_query = ""
    exact_mode = False
    case_mode = None
    nth = None
    with_nth = None
    accept_nth = None
    delimiter = None
    print_query = False
    print0 = False
    read0 = False
    sort_results = True
    tac = False
    select_1 = False
    exit_0 = False
    ansi = False
    i = 0
    while i < len(argv):
        arg = argv[i]
        if arg in ("-f", "--filter"):
            i += 1
            if i >= len(argv):
                print("error: option requires an argument: --filter", file=sys.stderr)
                return 2
            query = argv[i]
            initial_query = query
        elif arg.startswith("--filter="):
            query = arg.split("=", 1)[1]
            initial_query = query
        elif arg in ("-q", "--query"):
            i += 1
            initial_query = argv[i]
        elif arg.startswith("--query="):
            initial_query = arg.split("=", 1)[1]
        elif arg in ("-e", "--exact"):
            exact_mode = True
        elif arg in ("-i", "--ignore-case"):
            case_mode = "ignore"
        elif arg in ("+i", "--no-ignore-case"):
            case_mode = "respect"
        elif arg == "--smart-case":
            case_mode = None
        elif arg in ("-n", "--nth"):
            i += 1
            nth = argv[i]
        elif arg.startswith("--nth="):
            nth = arg.split("=", 1)[1]
        elif arg == "--with-nth":
            i += 1
            with_nth = argv[i]
        elif arg.startswith("--with-nth="):
            with_nth = arg.split("=", 1)[1]
        elif arg == "--accept-nth":
            i += 1
            accept_nth = argv[i]
        elif arg.startswith("--accept-nth="):
            accept_nth = arg.split("=", 1)[1]
        elif arg in ("-d", "--delimiter"):
            i += 1
            delimiter = argv[i]
        elif arg.startswith("--delimiter="):
            delimiter = arg.split("=", 1)[1]
        elif arg == "--print-query":
            print_query = True
        elif arg == "--print0":
            print0 = True
        elif arg == "--read0":
            read0 = True
        elif arg in ("+s", "--no-sort"):
            sort_results = False
        elif arg == "--ansi":
            ansi = True
        elif arg == "--tac":
            tac = True
        elif arg in ("-1", "--select-1"):
            select_1 = True
        elif arg in ("-0", "--exit-0"):
            exit_0 = True
        elif arg == "--version":
            print("0.68.0 (5676da4a)")
            return 0
        elif arg == "--help":
            print("fzf is an interactive filter program for any kind of list.")
            print()
            print("Usage: fzf [options]")
            print("  -f, --filter=STR        Print matches for the initial query and exit")
            print("  -q, --query=STR         Start the finder with the given query")
            return 0
        i += 1

    if query is None:
        query = initial_query

    raw = sys.stdin.buffer.read()
    if read0:
        parts = raw.split(b"\0")
        if parts and parts[-1] == b"":
            parts.pop()
        lines = [part.decode(errors="replace") for part in parts]
    else:
        lines = raw.decode(errors="replace").splitlines()

    matched = []
    for index, line in enumerate(lines):
        clean_line = ANSI_RE.sub("", line) if ansi else line
        display_text = apply_template(clean_line, with_nth, index, delimiter) if with_nth else clean_line
        search_text = select_fields(display_text, nth, delimiter) if nth else display_text
        score = query_match_score(search_text, query, exact_mode, case_mode)
        if score is not None:
            output = apply_template(clean_line, accept_nth, index, delimiter) if accept_nth else clean_line
            index_key = -index if tac else index
            matched.append((*score, index_key, output))

    if not matched:
        return 1
    if select_1 and len(matched) != 1 and query is not None:
        pass
    if sort_results or tac:
        matched.sort()
    outputs = [item[-1] for item in matched]
    sep = "\0" if print0 else "\n"
    prefix = []
    if print_query:
        prefix.append(initial_query)
    all_outputs = prefix + outputs
    if all_outputs:
        sys.stdout.write(sep.join(all_outputs) + sep)
        return 0
    return 1 if exit_0 else 0


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
