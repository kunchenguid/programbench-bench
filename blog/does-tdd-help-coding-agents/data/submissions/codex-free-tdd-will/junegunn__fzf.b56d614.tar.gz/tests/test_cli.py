#!/usr/bin/env python3
import os
import subprocess
import sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
BIN = os.path.join(ROOT, 'src', 'fzf_clone.py')


def run(args, data):
    return subprocess.run([sys.executable, BIN] + args, input=data, text=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)


def assert_run(args, data, out, code=0):
    got = run(args, data)
    assert got.returncode == code, (args, got.returncode, got.stderr, got.stdout)
    assert got.stdout == out, (args, repr(got.stdout), repr(out), got.stderr)


def test_filter_fuzzy_matches_in_input_order_when_scores_tie():
    assert_run(['--filter', 'fb'], 'foo bar\nbarfoo\nFast Boat\n', 'foo bar\nFast Boat\n')


def test_filter_sorts_fuzzy_matches_by_match_quality():
    assert_run(['--filter', 'fb'], 'foo bar\nf-b\nFast Boat\n', 'f-b\nfoo bar\nFast Boat\n')


def test_filter_supports_extended_exact_prefix_suffix_inverse_and_or_terms():
    data = 'foo bar\nbarfoo\ncore.rb\ncore.py\nmusic.mp3\nfire music\n'
    assert_run(['--filter', "'foo"], data, 'foo bar\nbarfoo\n')
    assert_run(['--filter', '^core py$ | rb$'], data, 'core.rb\ncore.py\n')
    assert_run(['--filter', '!music'], data, 'foo bar\nbarfoo\ncore.rb\ncore.py\n')


def test_filter_supports_nth_and_accept_nth_fields():
    data = 'foo bar baz\none two three\ntwo nope\n'
    assert_run(['--filter', 'two', '--nth', '2'], data, 'one two three\n')
    assert_run(['--filter', 'two', '--accept-nth', '2'], data, 'nope\ntwo\n')
    assert_run(['--filter', 'bar', '--delimiter', ',', '--accept-nth', '{n}:{2}:{1}'], 'foo,bar,baz\nqux,bar,zot\n', '0:bar:foo\n1:bar:qux\n')


def test_filter_supports_with_nth_query_print0_print_query_and_no_sort():
    assert_run(['--filter', 'ba', '--with-nth', '2..'], 'foo bar baz\none two three\n', 'foo bar baz\n')
    assert_run(['--filter', 'a', '--print-query'], 'alpha\nbeta\n', 'a\nalpha\nbeta\n')
    assert_run(['--filter', 'a', '+s'], 'beta\nalpha\na\n', 'beta\nalpha\na\n')
    got = run(['--filter', 'a', '--print0'], 'alpha\nbeta\n')
    assert got.stdout == 'alpha\0beta\0'


if __name__ == '__main__':
    for name, fn in sorted(globals().items()):
        if name.startswith('test_'):
            fn()
    print('ok')
