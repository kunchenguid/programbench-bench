#!/bin/bash
set -e
cp src/statix_reimpl.py executable
chmod +x executable
