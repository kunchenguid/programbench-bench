import os, subprocess, tempfile, textwrap, unittest

ROOT = os.path.dirname(os.path.dirname(__file__))
BIN = os.path.join(ROOT, 'src', 'statix_reimpl.py')

def run(args, input=None, cwd=None):
    return subprocess.run([BIN] + args, input=input, text=True, capture_output=True, cwd=cwd)

class StatixCliTests(unittest.TestCase):
    def test_list_lints(self):
        r = run(['list'])
        self.assertEqual(r.returncode, 0)
        self.assertEqual(r.stdout, """W01 bool_comparison
W02 empty_let_in
W03 manual_inherit
W04 manual_inherit_from
W05 legacy_let_syntax
W06 collapsible_let_in
W07 eta_reduction
W08 useless_parens
W10 empty_pattern
W11 redundant_pattern_bind
W12 unquoted_uri
W14 empty_inherit
W17 deprecated_to_path
W18 bool_simplification
W19 useless_has_attr
W20 repeated_keys
W23 empty_list_concat
""")

    def test_dump_default_config(self):
        r = run(['dump'])
        self.assertEqual(r.returncode, 0)
        self.assertEqual(r.stdout, "disabled = []\nignore = ['.direnv']\n\n")

    def test_check_stdin_reports_bool_comparison(self):
        r = run(['check', '--stdin'], input='x == false\n')
        self.assertEqual(r.returncode, 1)
        self.assertIn('[W01] Warning:', r.stdout)
        self.assertIn('Unnecessary comparison with boolean', r.stdout)
        self.assertIn('<stdin>:1:1', r.stdout)

    def test_fix_stdin_dry_run_rewrites_bool_comparison(self):
        r = run(['fix', '--stdin', '--dry-run'], input='x == false\n')
        self.assertEqual(r.returncode, 0)
        self.assertIn('--- <stdin>', r.stdout)
        self.assertIn('+++ <stdin> [fixed]', r.stdout)
        self.assertIn('-x == false', r.stdout)
        self.assertIn('+!x', r.stdout)

    def test_fix_stdin_rewrites_common_simple_lints(self):
        source = '\n'.join([
            'let in x',
            '{}: 1',
            '{...}@inputs: inputs',
            'https://example.com/foo',
            '{ inherit; }',
            'if x ? a then x.a else d',
            '[] ++ xs',
            'map (x: f x) xs',
            '(name)',
        ]) + '\n'
        r = run(['fix', '--stdin'], input=source)
        self.assertEqual(r.returncode, 0)
        self.assertIn('x\n', r.stdout)
        self.assertIn('_: 1', r.stdout)
        self.assertIn('inputs: inputs', r.stdout)
        self.assertIn('"https://example.com/foo"', r.stdout)
        self.assertIn('{ }', r.stdout)
        self.assertIn('x.a or d', r.stdout)
        self.assertIn('xs', r.stdout)
        self.assertIn('map f xs', r.stdout)
        self.assertIn('name', r.stdout)

if __name__ == '__main__':
    unittest.main()
