#!/usr/bin/env python3
import os
import subprocess
import tempfile
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
EXE = ROOT / "executable"


def run_cmd(args, input_bytes=None, cwd=None, env=None):
    merged_env = os.environ.copy()
    merged_env.update(env or {})
    return subprocess.run(
        [str(EXE)] + args,
        input=input_bytes,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        cwd=cwd or ROOT,
        env=merged_env,
    )


def build():
    subprocess.run(["bash", "compile.sh"], cwd=ROOT, check=True)


def test_plain_file_output_matches_cat_when_piped():
    build()
    with tempfile.TemporaryDirectory(dir=ROOT) as td:
        sample = Path(td) / "sample.txt"
        content = b"one\n\n\tthree\n"
        sample.write_bytes(content)
        result = run_cmd([str(sample)])
        assert result.returncode == 0
        assert result.stdout == content
        assert result.stderr == b""


def test_version_and_short_help_are_bat_compatible():
    build()
    version = run_cmd(["--version"])
    assert version.returncode == 0
    assert version.stdout == b"bat 0.26.1 (610b77c)\n"
    assert version.stderr == b""

    help_result = run_cmd(["-h"])
    assert help_result.returncode == 0
    text = help_result.stdout.decode()
    assert text.startswith("A cat(1) clone with wings.\n\nUsage: bat [OPTIONS] [FILE]...")
    assert "-n, --number" in text
    assert "-V, --version" in text


def test_stdin_dash_and_multiple_files_are_concatenated_in_order():
    build()
    with tempfile.TemporaryDirectory(dir=ROOT) as td:
        left = Path(td) / "left.txt"
        right = Path(td) / "right.txt"
        left.write_bytes(b"left\n")
        right.write_bytes(b"right\n")
        result = run_cmd([str(left), "-", str(right)], input_bytes=b"middle\n")
        assert result.returncode == 0
        assert result.stdout == b"left\nmiddle\nright\n"
        assert result.stderr == b""


def test_line_numbers_match_plain_bat_number_style():
    build()
    with tempfile.TemporaryDirectory(dir=ROOT) as td:
        sample = Path(td) / "sample.txt"
        sample.write_bytes(b"one\n\n\tfour\n")
        expected = b"   1 one\n   2 \n   3     four\n"
        for args in (["-n", str(sample)], ["--style=numbers", str(sample)]):
            result = run_cmd(args)
            assert result.returncode == 0
            assert result.stdout == expected
            assert result.stderr == b""


def test_line_ranges_are_inclusive_and_support_tail_form():
    build()
    with tempfile.TemporaryDirectory(dir=ROOT) as td:
        sample = Path(td) / "sample.txt"
        sample.write_bytes(b"one\ntwo\nthree\nfour\nfive\n")
        middle = run_cmd(["-r", "2:4", str(sample)])
        assert middle.returncode == 0
        assert middle.stdout == b"two\nthree\nfour\n"

        tail = run_cmd(["--line-range", "-2:", str(sample)])
        assert tail.returncode == 0
        assert tail.stdout == b"four\nfive\n"


def test_squeeze_blank_collapses_consecutive_empty_lines():
    build()
    with tempfile.TemporaryDirectory(dir=ROOT) as td:
        sample = Path(td) / "sample.txt"
        sample.write_bytes(b"one\n\n\n\nfour\n")
        result = run_cmd(["-s", str(sample)])
        assert result.returncode == 0
        assert result.stdout == b"one\n\nfour\n"


def test_show_all_renders_tabs_and_newlines_with_unicode_notation():
    build()
    with tempfile.TemporaryDirectory(dir=ROOT) as td:
        sample = Path(td) / "sample.txt"
        sample.write_bytes(b"one\n\tfour\n")
        result = run_cmd(["-A", str(sample)])
        assert result.returncode == 0
        assert result.stdout == "one␊\n├──┤four␊\n".encode()


def test_lists_common_languages_and_themes():
    build()
    langs = run_cmd(["--list-languages"])
    assert langs.returncode == 0
    lang_text = langs.stdout.decode()
    assert "Bourne Again Shell (bash):sh,bash,zsh" in lang_text
    assert "Python:py,py3,pyw" in lang_text
    assert "Rust:rs" in lang_text

    themes = run_cmd(["--list-themes"])
    assert themes.returncode == 0
    assert b"TwoDark\n" in themes.stdout
    assert b"Solarized (dark)\n" in themes.stdout


def test_missing_file_reports_bat_error_and_nonzero_status():
    build()
    result = run_cmd(["missing.txt"])
    assert result.returncode == 1
    assert result.stdout == b""
    assert b"[bat error]" in result.stderr
    assert b"'missing.txt': No such file or directory (os error 2)" in result.stderr


def test_quiet_empty_unknown_option_and_caret_notation():
    build()
    empty = run_cmd(["--quiet-empty"], input_bytes=b"")
    assert empty.returncode == 0
    assert empty.stdout == b""

    bad = run_cmd(["--badopt"])
    assert bad.returncode == 2
    assert b"unexpected argument '--badopt'" in bad.stderr

    shown = run_cmd(["-A", "--nonprintable-notation=caret"], input_bytes=b"\tX\n")
    assert shown.returncode == 0
    assert shown.stdout == b"^IX^J\n"


if __name__ == "__main__":
    tests = [name for name in globals() if name.startswith("test_")]
    failures = 0
    for name in tests:
        try:
            globals()[name]()
            print(f"PASS {name}")
        except Exception as exc:
            failures += 1
            print(f"FAIL {name}: {exc}")
    raise SystemExit(1 if failures else 0)
