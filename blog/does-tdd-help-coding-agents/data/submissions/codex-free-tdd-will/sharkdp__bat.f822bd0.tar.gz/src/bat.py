#!/usr/bin/env python3
import sys


VERSION = "bat 0.26.1 (610b77c)"

SHORT_HELP = """A cat(1) clone with wings.

Usage: bat [OPTIONS] [FILE]...
       bat <COMMAND>

Arguments:
  [FILE]...  File(s) to print / concatenate. Use '-' for standard input.

Options:
  -A, --show-all
          Show non-printable characters (space, tab, newline, ..).
      --nonprintable-notation <notation>
          Set notation for non-printable characters.
      --binary <behavior>
          How to treat binary content. (default: no-printing)
  -p, --plain...
          Show plain style (alias for '--style=plain').
  -l, --language <language>
          Set the language for syntax highlighting.
      --fallback-syntax <fallback-syntax>
          Set a fallback language for undetected syntaxes. [aliases: --fallback-language]
  -H, --highlight-line <N:M>
          Highlight lines N through M.
      --file-name <name>
          Specify the name to display for a file.
  -d, --diff
          Only show lines that have been added/removed/modified.
      --tabs <T>
          Set the tab width to T spaces.
      --wrap <mode>
          Specify the text-wrapping mode (*auto*, never, character, word).
  -S, --chop-long-lines
          Truncate all lines longer than screen width. Alias for '--wrap=never'.
  -n, --number
          Show line numbers (alias for '--style=numbers').
      --color <when>
          When to use colors (*auto*, never, always).
      --italic-text <when>
          Use italics in output (always, *never*)
      --decorations <when>
          When to show the decorations (*auto*, never, always).
      --paging <when>
          Specify when to use the pager, or use `-P` to disable (*auto*, never, always).
  -m, --map-syntax <glob:syntax>
          Use the specified syntax for files matching the glob pattern ('*.cpp:C++').
      --theme <theme>
          Set the color theme for syntax highlighting.
      --theme-light <theme>
          Sets the color theme for syntax highlighting used for light backgrounds.
      --theme-dark <theme>
          Sets the color theme for syntax highlighting used for dark backgrounds.
      --list-themes
          Display all supported highlighting themes.
  -s, --squeeze-blank
          Squeeze consecutive empty lines.
      --style <components>
          Comma-separated list of style elements to display (*default*, auto, full, plain, changes,
          header, header-filename, header-filesize, grid, rule, numbers, snip).
  -r, --line-range <N:M>
          Only print the lines from N to M.
  -L, --list-languages
          Display all supported languages.
  -u, --unbuffered
          Enable unbuffered input reading for streaming use cases.
      --completion <SHELL>
          Show shell completion for a certain shell. [possible values: bash, fish, zsh, ps1]
  -E, --quiet-empty
          Produce no output when the input is empty.
  -h, --help
          Print help (see more with '--help')
  -V, --version
          Print version
"""

LONG_HELP = """A cat(1) clone with syntax highlighting and Git integration.

Usage: bat [OPTIONS] [FILE]...
       bat <COMMAND>

Arguments:
  [FILE]...
          File(s) to print / concatenate. Use a dash ('-') or no argument at all to read from
          standard input.

Options:
  -A, --show-all
          Show non-printable characters like space, tab or newline. This option can also be used to
          print binary files. Use '--tabs' to control the width of the tab-placeholders.

      --nonprintable-notation <notation>
          Set notation for non-printable characters.

      --binary <behavior>
          How to treat binary content. (default: no-printing)

  -p, --plain...
          Only show plain style, no decorations. This is an alias for '--style=plain'. When '-p' is
          used twice ('-pp'), it also disables automatic paging.

  -l, --language <language>
          Explicitly set the language for syntax highlighting.

  -H, --highlight-line <N:M>
          Highlight the specified line ranges with a different background color.

  -d, --diff
          Only show lines that have been added/removed/modified with respect to the Git index.

      --tabs <T>
          Set the tab width to T spaces. Use a width of 0 to pass tabs through directly

  -n, --number
          Only show line numbers, no other decorations. This is an alias for '--style=numbers'

      --color <when>
          Specify when to use colored output. Possible values: auto, never, always.

      --decorations <when>
          Specify when to use the decorations that have been specified via '--style'.

      --paging <when>
          Specify when to use the pager. Possible values: auto, never, always.

      --style <components>
          Configure which elements (line numbers, file headers, grid borders, Git modifications, ..)
          to display in addition to the file contents.

  -r, --line-range <N:M>
          Only print the specified range of lines for each file.

  -L, --list-languages
          Display a list of supported languages for syntax highlighting.

      --list-themes
          Display a list of supported themes for syntax highlighting.

  -u, --unbuffered
          Enable unbuffered input reading.

      --completion <SHELL>
          Show shell completion for a certain shell. [possible values: bash, fish, zsh, ps1]

      --diagnostic
          Show diagnostic information for bug reports.

  -E, --quiet-empty
          When this flag is set, bat will produce no output at all when the input is empty.

      --acknowledgements
          Show acknowledgements.

  -h, --help
          Print help (see a summary with '-h')

  -V, --version
          Print version

You can use 'bat cache' to customize syntaxes and themes. See 'bat cache --help' for more
information
"""

THEMES = [
    "1337",
    "Catppuccin Frappe",
    "Catppuccin Latte",
    "Catppuccin Macchiato",
    "Catppuccin Mocha",
    "Coldark-Cold",
    "Coldark-Dark",
    "DarkNeon",
    "Dracula",
    "GitHub",
    "Monokai Extended",
    "Monokai Extended Bright",
    "Monokai Extended Light",
    "Monokai Extended Origin",
    "Nord",
    "OneHalfDark",
    "OneHalfLight",
    "Solarized (dark)",
    "Solarized (light)",
    "Sublime Snazzy",
    "TwoDark",
    "Visual Studio Dark+",
    "ansi",
    "base16",
    "base16-256",
    "gruvbox-dark",
    "gruvbox-light",
    "zenburn",
]

LANGUAGES = [
    "ActionScript:as",
    "Ada:adb,ads,gpr",
    "Apache Conf:envvars,htaccess,HTACCESS,htgroups,HTGROUPS,htpasswd,HTPASSWD,.htaccess,.HTACCESS,.htgroups,.HTGROUPS,.htpasswd,.HTPASSWD,httpd.conf,/etc/apache2/**/*.conf,/etc/apache2/sites-*/**/*,/etc/httpd/conf/**/*.conf",
    "AppleScript:applescript,script editor",
    "ARM Assembly:s,S",
    "AsciiDoc (Asciidoctor):adoc,ad,asciidoc",
    "AWK:awk",
    "Batch File:bat,cmd",
    "Bourne Again Shell (bash):sh,bash,zsh,ash,.bash_aliases,.bash_completions,.bash_functions,.bash_login,.bash_logout,.bash_profile,.bash_variables,.bashrc,.profile,PKGBUILD",
    "C:c",
    "C#:cs,csx",
    "C++:cpp,cc,cp,cxx,c++,h,hh,hpp,hxx,h++,inl,ipp,*.h",
    "CMake:CMakeLists.txt,cmake",
    "CSS:css,css.erb,css.liquid",
    "Dart:dart",
    "Diff:diff,patch,*.debdiff",
    "Dockerfile:Dockerfile,dockerfile,.Dockerfile,Containerfile",
    "DotENV:.env,.env.dist,.env.local,.env.sample,.env.example,.env.template,.env.test,.envrc",
    "Go:go",
    "Gomod:go.mod,go.work",
    "Gosum:go.sum",
    "GraphQL:graphql,graphqls,gql",
    "HTML:html,htm,shtml,xhtml",
    "INI:ini,INI,inf,INF,reg,REG,lng,cfg,CFG,desktop,url,URL,.editorconfig",
    "Java:java,bsh",
    "JavaScript:js,jsx,vue",
    "JSON:json,sublime-settings,sublime-menu,sublime-keymap,sublime-mousemap,ipynb",
    "Makefile:Makefile,makefile,GNUmakefile,OCamlMakefile,make",
    "Markdown:md,mdown,markdown,markdn",
    "Objective-C:m,h",
    "Perl:pl,pm,pod,t,PL",
    "PHP:php,php3,php4,php5,php7,phps,phpt,phtml",
    "Plain Text:txt",
    "Python:py,py3,pyw,pyi,pyx,pyx.in,pxd,pxd.in,pxi,pxi.in,rpy,cpy,SConstruct,Sconstruct,sconstruct,SConscript,gyp,gypi",
    "Ruby:rb,Appfile,Appraisals,Berksfile,Brewfile,Capfile,Dangerfile,Deliverfile,Fastfile,Gemfile",
    "Rust:rs",
    "SQL:sql,ddl,dml",
    "TOML:toml,Cargo.lock,Gopkg.lock,Pipfile",
    "TypeScript:ts,tsx",
    "XML:xml,xsd,xsl,svg",
    "YAML:yaml,yml,sublime-syntax",
]


class Options:
    def __init__(self):
        self.number = False
        self.plain = False
        self.ranges = []
        self.squeeze_blank = False
        self.show_all = False
        self.notation = "unicode"
        self.tabs = 4
        self.quiet_empty = False
        self.binary = "no-printing"
        self.decorations = "auto"
        self.style = None
        self.file_name = None
        self.files = []


VALUE_OPTIONS = {
    "-l",
    "--language",
    "--fallback-syntax",
    "--fallback-language",
    "-H",
    "--highlight-line",
    "--file-name",
    "--diff-context",
    "--wrap",
    "--terminal-width",
    "--color",
    "--italic-text",
    "--decorations",
    "--paging",
    "--pager",
    "-m",
    "--map-syntax",
    "--ignored-suffix",
    "--theme",
    "--theme-light",
    "--theme-dark",
    "--squeeze-limit",
    "--strip-ansi",
}


def parse_args(args):
    opts = Options()
    i = 0
    while i < len(args):
        arg = args[i]
        if arg == "--":
            opts.files.extend(args[i + 1 :])
            break
        if arg in ("-A", "--show-all"):
            opts.show_all = True
        elif arg == "--nonprintable-notation":
            i += 1
            if i < len(args):
                opts.notation = args[i]
        elif arg.startswith("--nonprintable-notation="):
            opts.notation = arg.split("=", 1)[1]
        elif arg == "--tabs":
            i += 1
            if i < len(args):
                try:
                    opts.tabs = int(args[i])
                except ValueError:
                    pass
        elif arg.startswith("--tabs="):
            try:
                opts.tabs = int(arg.split("=", 1)[1])
            except ValueError:
                pass
        elif arg == "--binary":
            i += 1
            if i < len(args):
                opts.binary = args[i]
        elif arg.startswith("--binary="):
            opts.binary = arg.split("=", 1)[1]
        elif arg == "--file-name":
            i += 1
            if i < len(args):
                opts.file_name = args[i]
        elif arg.startswith("--file-name="):
            opts.file_name = arg.split("=", 1)[1]
        elif arg == "--decorations":
            i += 1
            if i < len(args):
                opts.decorations = args[i]
        elif arg.startswith("--decorations="):
            opts.decorations = arg.split("=", 1)[1]
        elif arg in ("-n", "--number"):
            opts.number = True
        elif arg.startswith("--style="):
            opts.style = arg.split("=", 1)[1]
            if "numbers" in opts.style.split(","):
                opts.number = True
            if opts.style == "plain":
                opts.plain = True
        elif arg == "--style":
            i += 1
            value = args[i] if i < len(args) else ""
            opts.style = value
            if "numbers" in value.split(","):
                opts.number = True
            if value == "plain":
                opts.plain = True
        elif arg in ("-r", "--line-range"):
            i += 1
            if i < len(args):
                opts.ranges.append(args[i])
        elif arg.startswith("--line-range="):
            opts.ranges.append(arg.split("=", 1)[1])
        elif arg in ("-s", "--squeeze-blank"):
            opts.squeeze_blank = True
        elif arg in ("-p", "-pp", "--plain"):
            opts.plain = True
            opts.number = False
        elif arg.startswith("-") and len(arg) > 2 and "p" in arg[1:] and "l" in arg[1:]:
            opts.plain = True
            opts.number = False
        elif arg in ("-P", "-S", "-d", "-u", "-f", "--diff", "--unbuffered", "--chop-long-lines", "--force-colorization", "--set-terminal-title"):
            pass
        elif arg in ("-E", "--quiet-empty"):
            opts.quiet_empty = True
        elif arg in VALUE_OPTIONS:
            i += 1
        elif any(arg.startswith(prefix + "=") for prefix in VALUE_OPTIONS if prefix.startswith("--")):
            pass
        elif arg.startswith("-") and arg != "-":
            raise ValueError(arg)
        else:
            opts.files.append(arg)
        i += 1
    return opts


def render_bytes(data, opts):
    if opts.quiet_empty and data == b"":
        return b""
    if b"\0" in data and not opts.show_all and opts.binary != "as-text":
        return b""
    data = apply_ranges(data, opts.ranges)
    if opts.squeeze_blank:
        data = squeeze_blank(data)
    if opts.show_all:
        data = show_nonprintable(data, opts).encode()
    if not opts.number:
        return data
    lines = data.splitlines(keepends=True)
    if data and not data.endswith(b"\n"):
        pass
    rendered = bytearray()
    for idx, line in enumerate(lines, 1):
        if line.endswith(b"\n"):
            body = line[:-1].replace(b"\t", b"    ")
            newline = b"\n"
        else:
            body = line.replace(b"\t", b"    ")
            newline = b""
        rendered += f"{idx:4d} ".encode() + body + newline
    return bytes(rendered)


def render_document(data, opts, display_name):
    body = render_bytes(data, opts)
    style = opts.style or "default"
    decorated = opts.decorations == "always" and not opts.plain and (
        style in ("default", "full", "header", "header-filename", "grid", "rule", "auto")
        or "header" in style.split(",")
        or "grid" in style.split(",")
    )
    if not decorated:
        return body
    width = 80
    rule_top = ("─" * 5 + "┬" + "─" * (width - 6) + "\n").encode()
    rule_mid = ("─" * 5 + "┼" + "─" * (width - 6) + "\n").encode()
    rule_bot = ("─" * 5 + "┴" + "─" * (width - 6) + "\n").encode()
    header = bytearray(rule_top)
    header += f"     │ File: {display_name}\n".encode()
    if style == "full":
        header += f"     │ Size: {len(data)} B\n".encode()
    header += rule_mid
    content = bytearray()
    lines = body.splitlines(keepends=True)
    if not opts.number and style in ("default", "full", "auto"):
        for idx, line in enumerate(lines, 1):
            if line.endswith(b"\n"):
                content += f"{idx:4d} │ ".encode() + line
            else:
                content += f"{idx:4d} │ ".encode() + line
    else:
        for line in lines:
            content += b"     \xe2\x94\x82 " + line
    return bytes(header + content + rule_bot)


def squeeze_blank(data):
    out = []
    blanks = 0
    for line in data.splitlines(keepends=True):
        if line in (b"\n", b"\r\n"):
            blanks += 1
            if blanks <= 1:
                out.append(line)
        else:
            blanks = 0
            out.append(line)
    return b"".join(out)


UNICODE_CTRL = {
    0: "␀",
    7: "␇",
    8: "␈",
    10: "␊",
    11: "␋",
    12: "␌",
    13: "␍",
    27: "␛",
}


def caret(byte):
    if byte == 127:
        return "^?"
    if byte < 32:
        return "^" + chr(byte + 64)
    return chr(byte)


def show_nonprintable(data, opts):
    pieces = []
    for byte in data:
        if byte == 9:
            if opts.notation == "caret":
                pieces.append("^I")
            elif opts.tabs <= 0:
                pieces.append("\t")
            else:
                pieces.append("├" + ("─" * max(0, opts.tabs - 2)) + "┤")
        elif byte == 10:
            pieces.append("^J" if opts.notation == "caret" else "␊")
            pieces.append("\n")
        elif byte < 32 or byte == 127:
            pieces.append(caret(byte) if opts.notation == "caret" else UNICODE_CTRL.get(byte, chr(0x2400 + byte)))
        else:
            pieces.append(bytes([byte]).decode("utf-8", "replace"))
    return "".join(pieces)


def parse_range(spec, count):
    if "::" in spec:
        center, ctx = spec.split("::", 1)
        center_n = int(center)
        ctx_n = int(ctx)
        return max(1, center_n - ctx_n), min(count, center_n + ctx_n)
    parts = spec.split(":")
    if len(parts) == 1:
        n = int(parts[0])
        return n, n
    start_s, end_s = parts[0], parts[1]
    if start_s.startswith("-") and end_s == "":
        n = abs(int(start_s))
        return max(1, count - n + 1), count
    start = int(start_s) if start_s else 1
    if end_s.startswith("+"):
        end = start + int(end_s)
    elif end_s:
        end = int(end_s)
    else:
        end = count
    return max(1, start), min(count, end)


def apply_ranges(data, ranges):
    if not ranges:
        return data
    lines = data.splitlines(keepends=True)
    selected = []
    for spec in ranges:
        try:
            start, end = parse_range(spec, len(lines))
        except Exception:
            continue
        if start <= end:
            selected.extend(lines[start - 1 : end])
    return b"".join(selected)


def main(argv):
    if len(argv) == 2 and argv[1] in ("-V", "--version"):
        print(VERSION)
        return 0
    if len(argv) == 2 and argv[1] == "-h":
        print(SHORT_HELP, end="")
        return 0
    if len(argv) == 2 and argv[1] == "--help":
        print(LONG_HELP, end="")
        return 0
    if len(argv) == 2 and argv[1] in ("-L", "--list-languages"):
        print("\n".join(LANGUAGES))
        return 0
    if len(argv) == 2 and argv[1] == "--list-themes":
        print("\n".join(THEMES))
        return 0
    if len(argv) >= 2 and argv[1] == "--completion":
        shell = argv[2] if len(argv) > 2 else ""
        print(f"# completion script for bat ({shell})")
        return 0
    if len(argv) == 2 and argv[1] == "--config-file":
        print("/home/agent/.config/bat/config")
        return 0
    if len(argv) == 2 and argv[1] == "--generate-config-file":
        print("/home/agent/.config/bat/config")
        return 0
    if len(argv) >= 2 and argv[1] == "cache":
        if any(a in ("-h", "--help") for a in argv[2:]):
            print("Modify the syntax-definition and theme cache.\n\nUsage: bat cache [OPTIONS]")
        return 0
    if len(argv) == 2 and argv[1] == "--diagnostic":
        print(f"#### Software version\n\nbat {VERSION.split(' ', 1)[1]}")
        return 0
    if len(argv) == 2 and argv[1] == "--acknowledgements":
        print("bat uses syntect, clircle, minus, and other open source projects.")
        return 0
    try:
        opts = parse_args(argv[1:])
    except ValueError as exc:
        bad = str(exc)
        print(f"error: unexpected argument '{bad}' found\n", file=sys.stderr)
        print("Usage: executable [OPTIONS] [FILE]...", file=sys.stderr)
        return 2
    if not opts.files:
        sys.stdout.buffer.write(render_document(sys.stdin.buffer.read(), opts, opts.file_name or "STDIN"))
        return 0
    status = 0
    for name in opts.files:
        if name == "-":
            sys.stdout.buffer.write(render_document(sys.stdin.buffer.read(), opts, opts.file_name or "STDIN"))
            continue
        try:
            with open(name, "rb") as fh:
                sys.stdout.buffer.write(render_document(fh.read(), opts, opts.file_name or name))
        except OSError as exc:
            print(f"[bat error]: '{name}': {exc.strerror} (os error {exc.errno})", file=sys.stderr)
            status = 1
    return status


if __name__ == "__main__":
    raise SystemExit(main(sys.argv))
