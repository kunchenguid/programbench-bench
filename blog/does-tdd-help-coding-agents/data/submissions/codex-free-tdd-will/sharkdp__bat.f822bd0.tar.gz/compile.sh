#!/bin/bash
set -euo pipefail
rm -f executable
cp src/bat.py executable
chmod +x executable
