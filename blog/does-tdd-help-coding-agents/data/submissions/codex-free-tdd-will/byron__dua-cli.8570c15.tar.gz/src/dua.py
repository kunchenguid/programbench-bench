#!/usr/bin/env python3
import os
import sys
from dataclasses import dataclass


GREEN = "\x1b[32m"
CYAN = "\x1b[36m"
RESET = "\x1b[39m"


@dataclass
class Options:
    fmt: str = "binary"
    apparent: bool = False
    count_hard_links: bool = False
    no_sort: bool = False
    no_total: bool = False
    ignore_dirs: set | None = None


@dataclass
class Entry:
    path: str
    label: str
    size: int
    is_dir: bool
    errors: int = 0


def usage():
    return """A tool to learn about disk usage, fast!

Usage: dua [FLAGS] [OPTIONS] [SUBCOMMAND] [INPUT]...

Commands:
  interactive  Launch the terminal user interface [aliases: i]
  aggregate    Aggregate the consumed space of one or more directories or files [aliases: a]
  completions  Generate shell completions
  help         Print this message or the help of the given subcommand(s)

Arguments:
  [INPUT]...
          One or more input files or directories. If unset, we will use all entries in the current working directory

Options:
  -t, --threads <THREADS>
          The amount of threads to use. Defaults to 0, indicating the amount of logical processors. Set to 1 to use only a single thread
          
          [default: 0]

  -f, --format <FORMAT>
          The format with which to print byte counts
          
          [default: binary]
          [possible values: metric, binary, bytes, gb, gib, mb, mib]

  -A, --apparent-size
          Display apparent size instead of disk usage

  -l, --count-hard-links
          Count hard-linked files each time they are seen

  -x, --stay-on-filesystem
          If set, we will not cross filesystems or traverse mount points

  -i, --ignore-dirs <IGNORE_DIRS>
          One or more absolute directories to ignore. Note that these are not ignored if they are passed as input path.
          
          Hence, they will only be ignored if they are eventually reached as part of the traversal.
          
          [default: /proc /dev /sys /run]

      --log-file <LOG_FILE>
          Write a log file with debug information, including panics

  -h, --help
          Print help (see a summary with '-h')

  -V, --version
          Print version
"""


def aggregate_usage():
    return """Aggregate the consumed space of one or more directories or files

Usage: executable aggregate [OPTIONS] [INPUT]...

Arguments:
  [INPUT]...  One or more input files or directories. If unset, we will use all entries in the current working directory

Options:
      --stats     If set, print additional statistics about the file traversal to stderr
      --no-sort   If set, paths will be printed in their order of occurrence on the command-line. Otherwise they are sorted by their size in bytes, ascending
      --no-total  If set, no total column will be computed for multiple inputs
  -h, --help      Print help
"""


def interactive_usage():
    return """Launch the terminal user interface

Usage: executable interactive [OPTIONS] [INPUT]...

Arguments:
  [INPUT]...  One or more input files or directories. If unset, we will use all entries in the current working directory

Options:
  -e, --no-entry-check  Do not check entries for presence when listing a directory to avoid slugging performance on slow filesystems
  -h, --help            Print help
"""


def die(message, usage_text=None):
    print(message, file=sys.stderr)
    if usage_text:
        print(file=sys.stderr)
        print(usage_text.rstrip(), file=sys.stderr)
    print(file=sys.stderr)
    print("For more information, try '--help'.", file=sys.stderr)
    raise SystemExit(2)


def parse(argv):
    opts = Options()
    inputs = []
    i = 0
    aggregate_mode = False
    if argv == ["help"] or argv == ["help", "help"]:
        print(usage(), end="")
        raise SystemExit(0)
    if argv == ["help", "aggregate"] or argv == ["help", "a"]:
        print(aggregate_usage(), end="")
        raise SystemExit(0)
    if argv == ["help", "interactive"] or argv == ["help", "i"]:
        print(interactive_usage(), end="")
        raise SystemExit(0)
    if argv and argv[0] == "completions":
        shell = argv[1] if len(argv) > 1 else ""
        if shell not in ("bash", "elvish", "fish", "powershell", "zsh"):
            die(
                f"error: invalid value '{shell}' for '<SHELL>'\n  [possible values: bash, elvish, fish, powershell, zsh]"
                + ("\n\n  tip: a similar value exists: 'bash'" if shell == "bad" else "")
            )
        print(f"# completion script for dua ({shell})")
        raise SystemExit(0)
    while i < len(argv):
        arg = argv[i]
        if arg in ("aggregate", "a"):
            aggregate_mode = True
            i += 1
            continue
        if arg in ("interactive", "i"):
            if "--help" in argv or "-h" in argv:
                print(interactive_usage(), end="")
                raise SystemExit(0)
            i += 1
            continue
        if arg == "--":
            inputs.extend(argv[i + 1 :])
            break
        if arg in ("--help", "-h"):
            print(aggregate_usage() if aggregate_mode else usage(), end="")
            raise SystemExit(0)
        if arg in ("--version", "-V"):
            print("dua 2.32.2")
            raise SystemExit(0)
        if arg in ("-f", "--format"):
            i += 1
            opts.fmt = argv[i]
        elif arg.startswith("--format="):
            opts.fmt = arg.split("=", 1)[1]
        elif arg in ("-A", "--apparent-size"):
            opts.apparent = True
        elif arg in ("-l", "--count-hard-links"):
            opts.count_hard_links = True
        elif arg == "--no-sort":
            opts.no_sort = True
        elif arg == "--no-total":
            opts.no_total = True
        elif arg in ("-t", "--threads", "-i", "--ignore-dirs", "--log-file"):
            i += 1
            if arg in ("-i", "--ignore-dirs"):
                if opts.ignore_dirs is None:
                    opts.ignore_dirs = set()
                opts.ignore_dirs.add(os.path.abspath(argv[i]))
        elif arg == "-x" or arg == "--stay-on-filesystem" or arg == "--stats":
            pass
        elif arg.startswith("-"):
            die(
                f"error: unexpected argument '{arg}' found\n\n  tip: to pass '{arg}' as a value, use '-- {arg}'",
                "Usage: executable aggregate [OPTIONS] [INPUT]..." if aggregate_mode else "Usage: dua [FLAGS] [OPTIONS] [SUBCOMMAND] [INPUT]...",
            )
        else:
            inputs.append(arg)
        i += 1
    if opts.fmt not in ("metric", "binary", "bytes", "gb", "gib", "mb", "mib"):
        die(f"error: invalid value '{opts.fmt}' for '--format <FORMAT>'\n  [possible values: metric, binary, bytes, gb, gib, mb, mib]")
    return opts, inputs


def file_size(st, opts):
    return st.st_size if opts.apparent else getattr(st, "st_blocks", 0) * 512


def scan_size(path, opts, seen, ignore_dirs=None):
    ignore_dirs = ignore_dirs if ignore_dirs is not None else (opts.ignore_dirs or set())
    try:
        st = os.lstat(path)
    except OSError:
        return 0, True, 1
    is_dir = os.path.isdir(path) and not os.path.islink(path)
    key = (st.st_dev, st.st_ino)
    if not opts.count_hard_links and not is_dir and st.st_nlink > 1:
        if key in seen:
            return 0, False, 0
        seen.add(key)
    if not is_dir:
        return file_size(st, opts), False, 0
    if os.path.abspath(path) in ignore_dirs:
        return 0, True, 0
    total = 0
    errors = 0
    try:
        with os.scandir(path) as it:
            children = list(it)
    except OSError:
        return 0, True, 1
    for child in children:
        if child.is_symlink():
            continue
        size, _, err = scan_size(child.path, opts, seen, ignore_dirs)
        total += size
        errors += err
    return total, True, errors


def collect(inputs, opts):
    seen = set()
    if not inputs:
        inputs = [e.path for e in sorted(os.scandir("."), key=lambda e: e.name) if not e.is_symlink()]
        labels = {p: p for p in inputs}
    elif len(inputs) == 1 and os.path.isdir(inputs[0]) and not os.path.islink(inputs[0]):
        base = inputs[0]
        try:
            inputs = [e.path for e in sorted(os.scandir(base), key=lambda e: e.name) if not e.is_symlink()]
        except OSError:
            inputs = [base]
        labels = {p: os.path.basename(p) for p in inputs}
    else:
        labels = {p: p for p in inputs}
    entries = []
    for path in inputs:
        size, is_dir, errors = scan_size(path, opts, seen)
        entries.append(Entry(path, labels[path], size, is_dir, errors))
    if not opts.no_sort:
        entries.sort(key=lambda e: e.size)
    return entries


def format_size(size, fmt):
    if fmt == "bytes":
        return f"{size:10d} b"
    if fmt in ("mb", "mib"):
        width = 12
    elif fmt == "metric":
        width = 10
    else:
        width = 11
    return f"{human(size, fmt):>{width}}"


def human(size, fmt):
    if fmt in ("metric", "gb", "mb"):
        unit = 1000.0
        names = [" B", "KB", "MB", "GB"]
    else:
        unit = 1024.0
        names = ["  B", "KiB", "MiB", "GiB"]
    if fmt in ("gb", "gib"):
        value = size / (unit ** 3)
        suffix = "GB" if fmt == "gb" else "GiB"
        return f"{value:.2f} {suffix}"
    if fmt in ("mb", "mib"):
        value = size / (unit ** 2)
        suffix = "MB" if fmt == "mb" else "MiB"
        return f"{value:.2f} {suffix}"
    if size == 0:
        return "0   B" if fmt != "metric" else "0  B"
    value = float(size)
    idx = 0
    while value >= unit and idx < len(names) - 1:
        value /= unit
        idx += 1
    if idx == 0:
        return f"{int(value)}   B" if fmt != "metric" else f"{int(value)}  B"
    return f"{value:.2f} {names[idx]}"


def print_entries(entries, opts):
    status = 0
    total = 0
    for e in entries:
        total += e.size
        label = f"{CYAN}{e.label}{RESET}" if e.is_dir else e.label
        suffix = f"  <{e.errors} IO Error>" if e.errors else ""
        if e.errors:
            status = 1
        print(f"{GREEN}{format_size(e.size, opts.fmt)}{RESET} {label}{suffix}")
    if len(entries) > 1 and not opts.no_total:
        print(f"{GREEN}{format_size(total, opts.fmt)}{RESET} total")
    return status


def main(argv):
    opts, inputs = parse(argv)
    return print_entries(collect(inputs, opts), opts)


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
