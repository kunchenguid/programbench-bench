#!/usr/bin/env python3
import os
import subprocess
import sys
import tempfile
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]


def run(args, cwd=None):
    return subprocess.run(
        [str(ROOT / "executable"), *args],
        cwd=cwd or ROOT,
        text=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
    )


def build():
    subprocess.run(["bash", "compile.sh"], cwd=ROOT, check=True)


def test_version():
    build()
    result = run(["--version"])
    assert result.returncode == 0
    assert result.stdout == "dua 2.32.2\n"
    assert result.stderr == ""


def test_directory_aggregation_uses_disk_blocks_and_deduplicates_hardlinks():
    build()
    with tempfile.TemporaryDirectory() as td:
        root = Path(td) / "probe"
        root.mkdir()
        (root / "emptydir").mkdir()
        (root / "dir").mkdir()
        (root / "a").write_text("abc")
        (root / "dir" / "b").write_bytes(b"0" * 5000)
        os.link(root / "a", root / "hard")

        result = run(["-f", "bytes", str(root)])

    assert result.returncode == 0
    assert result.stdout == (
        "\x1b[32m         0 b\x1b[39m \x1b[36memptydir\x1b[39m\n"
        "\x1b[32m         0 b\x1b[39m hard\n"
        "\x1b[32m      4096 b\x1b[39m a\n"
        "\x1b[32m      8192 b\x1b[39m \x1b[36mdir\x1b[39m\n"
        "\x1b[32m     12288 b\x1b[39m total\n"
    )
    assert result.stderr == ""


def test_apparent_size_no_sort_and_missing_path_status():
    build()
    with tempfile.TemporaryDirectory() as td:
        root = Path(td) / "probe"
        root.mkdir()
        (root / "big").write_bytes(b"x" * 1500)
        (root / "small").write_text("x")
        result = run(["-A", "-f", "bytes", "aggregate", "--no-sort", str(root / "big"), str(root / "small"), str(root / "missing")])

    assert result.returncode == 1
    assert result.stdout == (
        "\x1b[32m      1500 b\x1b[39m " + str(root / "big") + "\n"
        "\x1b[32m         1 b\x1b[39m " + str(root / "small") + "\n"
        "\x1b[32m         0 b\x1b[39m \x1b[36m" + str(root / "missing") + "\x1b[39m  <1 IO Error>\n"
        "\x1b[32m      1501 b\x1b[39m total\n"
    )
    assert result.stderr == ""


if __name__ == "__main__":
    tests = [
        test_version,
        test_directory_aggregation_uses_disk_blocks_and_deduplicates_hardlinks,
        test_apparent_size_no_sort_and_missing_path_status,
    ]
    failures = 0
    for test in tests:
        try:
            test()
            print(f"PASS {test.__name__}")
        except Exception as err:
            failures += 1
            print(f"FAIL {test.__name__}: {err}", file=sys.stderr)
    raise SystemExit(1 if failures else 0)
