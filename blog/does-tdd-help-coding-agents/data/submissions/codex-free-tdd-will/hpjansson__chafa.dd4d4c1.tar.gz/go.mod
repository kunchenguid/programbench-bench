module chafa-lite

go 1.20
