#!/bin/bash
set -e
go build -o executable ./cmd/chafa-lite
chmod +x executable
