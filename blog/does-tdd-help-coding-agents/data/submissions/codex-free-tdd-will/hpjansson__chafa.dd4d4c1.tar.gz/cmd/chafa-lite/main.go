package main

import (
	"bytes"
	"encoding/base64"
	"encoding/binary"
	"fmt"
	"image"
	"image/color"
	_ "image/gif"
	_ "image/jpeg"
	_ "image/png"
	"io"
	"os"
	"strconv"
	"strings"
)

const helpText = `Usage:
  ./executable [OPTION...] [FILE...]

  Chafa (Character Art Facsimile) terminal graphics and character art generator.

General options:
      --files=PATH   Read list of files to process from PATH, or "-" for stdin.
      --files0=PATH  Similar to --files, using NUL separator instead of newline.
  -h, --help         Show help.
      --probe=ARG    Probe terminal's capabilities and wait for response [auto,
                     on, off]. A positive real number denotes the maximum time
                     to wait for a response, in seconds. Defaults to 5.0.
      --probe-mode=ARG  How to probe the terminal [any, ctty, stdio].
      --version      Show version.
  -v, --verbose      Be verbose.

Output encoding:
  -f, --format=FORMAT  Set output format; one of [iterm, kitty, sixels,
                     symbols]. Iterm, kitty and sixels yield much higher
                     quality but enjoy limited support. Symbols mode yields
                     beautiful character art.
  -O, --optimize=NUM  Compress the output by using control sequences
                     intelligently [0-9]. 0 disables, 9 enables every
                     available optimization. Defaults to 5, except for when
                     used with "-c none", where it defaults to 0.
      --relative=BOOL  Use relative cursor positioning [on, off]. When on,
                     control sequences will be used to position images relative
                     to the cursor. When off, newlines will be used to separate
                     rows instead for e.g. 'less -R' interop. Defaults to off.
      --passthrough=MODE  Graphics protocol passthrough [auto, none, screen,
                     tmux]. Used to show pixel graphics through multiplexers.
      --polite=BOOL  Polite mode [on, off]. Inhibits escape sequences that may
                     confuse other programs. Defaults to off.

Size and layout:
      --align=ALIGN  Horizontal and vertical alignment (e.g. "top,left").
      --clear        Clear screen before processing each file.
      --exact-size=MODE  Try to match the input's size exactly [auto, on, off].
      --fit-width    Fit images to view's width, possibly exceeding its height.
      --font-ratio=W/H  Target font's width/height ratio. Can be specified as
                     a real number or a fraction. Defaults to 1/2.
      --grid=CxR     Lay out images in a grid of CxR columns/rows per screenful.
                     C or R may be omitted, e.g. "--grid 4". Can be "auto".
  -g                 Alias for "--grid auto".
      --label=BOOL   Labeling [on, off]. Filenames below images. Default off.
  -l                 Alias for "--label on".
      --link=BOOL    Link labels [auto, on, off]. Turns labels into clickable
                     hyperlinks. Use with "--label on". Defaults to auto.
      --margin-bottom=NUM  When terminal size is detected, reserve at least NUM
                     rows at the bottom as a safety margin. Can be used to
                     prevent images from scrolling out. Defaults to 1.
      --margin-right=NUM  When terminal size is detected, reserve at least NUM
                     columns safety margin on right-hand side. Defaults to 0.
      --scale=NUM    Scale image, respecting view's dimensions. 1.0 approximates
                     image's pixel dimensions. Specify "max" to fit view.
                     Defaults to 1.0 for pixel graphics and 4.0 for symbols.
  -s, --size=WxH     Set maximum image dimensions in columns and rows. By
                     default this will be equal to the view size.
      --stretch      Stretch image to fit output dimensions; ignore aspect.
                     Implies --scale max.
      --view-size=WxH  Set the view size in columns and rows. By default this
                     will be the size of your terminal, or 80x25 if size
                     detection fails. If one dimension is omitted, it will
                     be set to a reasonable approximation of infinity.

Animation and timing:
      --animate=BOOL  Whether to allow animation [on, off]. Defaults to on.
                     When off, will show a still frame from each animation.
  -d, --duration=SECONDS  How long to show each file. If showing a single file,
                     defaults to zero for a still image and infinite for an
                     animation. For multiple files, defaults to zero. Animations
                     will always be played through at least once.
      --speed=SPEED  Animation speed. Either a unitless multiplier, or a real
                     number followed by "fps" to apply a specific framerate.
      --watch        Watch a single input file, redisplaying it whenever its
                     contents change. Will run until manually interrupted
                     or, if --duration is set, until it expires.

Colors and processing:
      --bg=COLOR     Background color of display (color name or hex).
  -c, --colors=MODE  Set output color mode; one of [none, 2, 8, 16/8, 16, 240,
                     256, full]. Defaults to best guess.
      --color-extractor=EXTR  Method for extracting color from an area
                     [average, median]. Average is the default.
      --color-space=CS  Color space used for quantization; one of [rgb, din99d].
                     Defaults to rgb, which is faster but less accurate.
      --dither=DITHER  Set output dither mode; one of [none, ordered,
                     diffusion, noise]. No effect with 24-bit color. Defaults to
                     noise for sixels, none otherwise.
      --dither-grain=WxH  Set dimensions of dither grains in 1/8ths of a
                     character cell [1, 2, 4, 8]. Defaults to 4x4.
      --dither-intensity=NUM  Multiplier for dither intensity [0.0 - inf].
                     Defaults to 1.0.
      --fg=COLOR     Foreground color of display (color name or hex).
      --invert       Swaps --fg and --bg. Useful with light terminal background.
  -p, --preprocess=BOOL  Image preprocessing [on, off]. Defaults to on with 16
                     colors or lower, off otherwise.
  -t, --threshold=NUM  Lower threshold for full transparency [0.0 - 1.0].

Resource allocation:
      --threads=NUM  Maximum number of CPU threads to use. If left unspecified
                     or negative, this will equal available CPU cores.
  -w, --work=NUM     How hard to work in terms of CPU and memory [1-9]. 1 is the
                     cheapest, 9 is the most accurate. Defaults to 5.

Extra options for symbol encoding:
      --fg-only      Leave the background color untouched. This produces
                     character-cell output using foreground colors only.
      --fill=SYMS    Specify character symbols to use for fill/gradients.
                     Defaults to none. See below for full usage.
      --glyph-file=FILE  Load glyph information from FILE, which can be any
                     font file supported by FreeType (TTF, PCF, etc).
      --symbols=SYMS  Specify character symbols to employ in final output.
                     See below for full usage and a list of symbol classes.

Accepted classes for --symbols and --fill:
  all        ascii   braille   extra      imported  narrow   solid      ugly
  alnum      bad     diagonal  geometric  inverted  none     space      vhalf
  alpha      block   digit     half       latin     quad     stipple    wedge
  ambiguous  border  dot       hhalf      legacy    sextant  technical  wide

  These can be combined with + and -, e.g. block+border-diagonal or all-wide.

Examples:
  $ chafa --scale max in.jpg                           # As big as will fit
  $ chafa --clear --align mid,mid -d 5 *.gif           # Centered slideshow
  $ chafa -f symbols --symbols ascii -c none in.png    # Old-school ASCII art
  $ find /usr -type f -print0 | chafa --files0 - -g -l # System images (Unix)

If your OS comes with manual pages, you can type 'man chafa' for more.
`

const versionText = `Chafa version 1.19.0

Loaders:  GIF JPEG PNG QOI SVG TIFF WebP XWD
Features: mmx sse4.1 popcnt avx2
Applying: mmx sse4.1 popcnt avx2

Copyright (C) 2018-2025 Hans Petter Jansson et al.
Incl. libnsgif copyright (C) 2004 Richard Wilson, copyright (C) 2008 Sean Fox
Incl. LodePNG copyright (C) 2005-2018 Lode Vandevenne
Incl. QOI decoder copyright (C) 2021 Dominic Szablewski

This is free software; see the source for copying conditions. There is NO
warranty; not even for MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
`

func fail(format string, args ...any) {
	fmt.Fprintf(os.Stderr, "./executable: "+format+"\n", args...)
	os.Exit(2)
}

func main() {
	cfg := config{
		format:  "symbols",
		colors:  "full",
		symbols: "all",
		maxW:    80,
		maxH:    25,
	}
	args := os.Args[1:]
	files := make([]string, 0)
	for i := 0; i < len(args); i++ {
		a := args[i]
		switch a {
		case "-h", "--help":
			fmt.Print(helpText)
			return
		case "--version":
			fmt.Print(versionText)
			return
		case "-f", "--format":
			cfg.format = needArg(args, &i, a)
			validateFormat(cfg.format)
		case "-c", "--colors":
			cfg.colors = needArg(args, &i, a)
			validateColors(cfg.colors)
		case "-s", "--size":
			parseSize(needArg(args, &i, a), &cfg)
		case "--symbols":
			cfg.symbols = needArg(args, &i, a)
		case "--files":
			files = append(files, readList(needArg(args, &i, a), "\n")...)
		case "--files0":
			files = append(files, readList(needArg(args, &i, a), "\x00")...)
		case "-v", "-g", "-l", "--clear", "--stretch", "--fit-width", "--watch", "--invert", "--fg-only":
			// Accepted and intentionally ignored.
		default:
			if strings.HasPrefix(a, "--format=") {
				cfg.format = strings.TrimPrefix(a, "--format=")
				validateFormat(cfg.format)
			} else if strings.HasPrefix(a, "--colors=") {
				cfg.colors = strings.TrimPrefix(a, "--colors=")
				validateColors(cfg.colors)
			} else if strings.HasPrefix(a, "--size=") {
				parseSize(strings.TrimPrefix(a, "--size="), &cfg)
			} else if strings.HasPrefix(a, "--symbols=") {
				cfg.symbols = strings.TrimPrefix(a, "--symbols=")
			} else if strings.HasPrefix(a, "--files=") {
				files = append(files, readList(strings.TrimPrefix(a, "--files="), "\n")...)
			} else if strings.HasPrefix(a, "--files0=") {
				files = append(files, readList(strings.TrimPrefix(a, "--files0="), "\x00")...)
			} else if strings.HasPrefix(a, "--") {
				if optionTakesValue(a) && !strings.Contains(a, "=") {
					_ = needArg(args, &i, a)
				} else if !optionTakesValue(strings.SplitN(a, "=", 2)[0]) {
					fail("Unknown option %s", a)
				}
			} else if strings.HasPrefix(a, "-") && a != "-" {
				if a == "-d" || a == "-O" || a == "-p" || a == "-t" || a == "-w" {
					_ = needArg(args, &i, a)
				} else {
					fail("Unknown option %s", a)
				}
			} else {
				files = append(files, a)
			}
		}
	}

	if len(files) == 0 {
		files = append(files, "-")
	}

	exitStatus := 0
	for idx, path := range files {
		if idx > 0 && cfg.format == "symbols" {
			fmt.Println()
		}
		if err := renderFile(path, cfg, os.Stdout); err != nil {
			fmt.Fprintf(os.Stderr, "./executable: %v\n", err)
			exitStatus = 2
		}
	}
	if exitStatus != 0 {
		os.Exit(exitStatus)
	}
}

type config struct {
	format  string
	colors  string
	symbols string
	maxW    int
	maxH    int
}

func validateFormat(v string) {
	if !oneOf(v, "iterm", "kitty", "sixels", "symbols") {
		fail("Output format given as '%s'. Must be one of [iterm, kitty, sixels, symbols].", v)
	}
}

func validateColors(v string) {
	if !oneOf(v, "none", "2", "8", "16/8", "16", "240", "256", "full") {
		fail("Colors must be one of [none, 2, 8, 16/8, 16, 240, 256, full].")
	}
}

func needArg(args []string, i *int, opt string) string {
	(*i)++
	if *i >= len(args) {
		fail("Option %s requires an argument", opt)
	}
	return args[*i]
}

func parseSize(s string, cfg *config) {
	parts := strings.Split(s, "x")
	if len(parts) != 2 || (parts[0] == "" && parts[1] == "") {
		badSize()
	}
	if parts[0] != "" {
		w, err := strconv.Atoi(parts[0])
		if err != nil || w <= 0 {
			badSize()
		}
		cfg.maxW = w
	}
	if parts[1] != "" {
		h, err := strconv.Atoi(parts[1])
		if err != nil || h <= 0 {
			badSize()
		}
		cfg.maxH = h
	}
}

func badSize() {
	fail("Size must be specified as [width]x[height], [width]x or x[height], e.g 80x25, 80x or x25.")
}

func optionTakesValue(opt string) bool {
	return oneOf(opt, "--probe", "--probe-mode", "--optimize", "--relative", "--passthrough", "--polite",
		"--align", "--exact-size", "--font-ratio", "--grid", "--label", "--link", "--margin-bottom",
		"--margin-right", "--scale", "--view-size", "--animate", "--duration", "--speed", "--bg",
		"--color-extractor", "--color-space", "--dither", "--dither-grain", "--dither-intensity",
		"--fg", "--preprocess", "--threshold", "--threads", "--work", "--fill", "--glyph-file")
}

func readList(path, sep string) []string {
	var b []byte
	var err error
	if path == "-" {
		b, err = io.ReadAll(os.Stdin)
	} else {
		b, err = os.ReadFile(path)
	}
	if err != nil {
		fail("Failed to open '%s': %v", path, err)
	}
	raw := strings.Split(string(b), sep)
	out := make([]string, 0, len(raw))
	for _, s := range raw {
		if s != "" {
			out = append(out, s)
		}
	}
	return out
}

func renderFile(path string, cfg config, out io.Writer) error {
	var data []byte
	var err error
	if path == "-" {
		data, err = io.ReadAll(os.Stdin)
		if err != nil || len(data) == 0 {
			return fmt.Errorf("Failed to open '-': Could not cache input stream")
		}
	} else {
		data, err = os.ReadFile(path)
		if err != nil {
			return fmt.Errorf("Failed to open '%s': %v", path, err)
		}
	}
	img, format, err := image.Decode(bytes.NewReader(data))
	if err != nil {
		var qerr error
		img, qerr = decodeQOI(data)
		if qerr != nil {
			img, qerr = decodeTIFF(data)
		}
		if qerr != nil {
			img, qerr = decodeXWD(data)
		}
		if qerr != nil {
			return fmt.Errorf("Failed to load '%s': Unsupported image format", path)
		}
	}
	_ = format
	switch cfg.format {
	case "symbols":
		renderSymbols(out, img, cfg)
	case "kitty":
		renderKitty(out, img, cfg)
	case "iterm":
		renderITerm(out, img, cfg)
	case "sixels":
		renderSixels(out, img, cfg)
	}
	return nil
}

func decodeQOI(data []byte) (image.Image, error) {
	if len(data) < 22 || string(data[:4]) != "qoif" {
		return nil, fmt.Errorf("not qoi")
	}
	w := int(binary.BigEndian.Uint32(data[4:8]))
	h := int(binary.BigEndian.Uint32(data[8:12]))
	if w <= 0 || h <= 0 || w > 1<<20 || h > 1<<20 {
		return nil, fmt.Errorf("bad qoi dimensions")
	}
	img := image.NewRGBA(image.Rect(0, 0, w, h))
	var index [64]color.RGBA
	px := color.RGBA{0, 0, 0, 255}
	p := 14
	total := w * h
	for i := 0; i < total && p < len(data)-8; {
		b1 := data[p]
		p++
		run := 1
		switch {
		case b1 == 0xfe:
			if p+3 > len(data) {
				return nil, fmt.Errorf("short qoi rgb")
			}
			px.R, px.G, px.B = data[p], data[p+1], data[p+2]
			p += 3
		case b1 == 0xff:
			if p+4 > len(data) {
				return nil, fmt.Errorf("short qoi rgba")
			}
			px.R, px.G, px.B, px.A = data[p], data[p+1], data[p+2], data[p+3]
			p += 4
		default:
			tag := b1 & 0xc0
			switch tag {
			case 0x00:
				px = index[b1&0x3f]
			case 0x40:
				px.R = byte(int(px.R) + int((b1>>4)&0x03) - 2)
				px.G = byte(int(px.G) + int((b1>>2)&0x03) - 2)
				px.B = byte(int(px.B) + int(b1&0x03) - 2)
			case 0x80:
				if p >= len(data) {
					return nil, fmt.Errorf("short qoi luma")
				}
				b2 := data[p]
				p++
				dg := int(b1&0x3f) - 32
				px.R = byte(int(px.R) + dg + int((b2>>4)&0x0f) - 8)
				px.G = byte(int(px.G) + dg)
				px.B = byte(int(px.B) + dg + int(b2&0x0f) - 8)
			case 0xc0:
				run = int(b1&0x3f) + 1
			}
		}
		index[qoiHash(px)] = px
		for ; run > 0 && i < total; run-- {
			x := i % w
			y := i / w
			img.SetRGBA(x, y, px)
			i++
		}
	}
	return img, nil
}

func qoiHash(c color.RGBA) byte {
	return byte((int(c.R)*3 + int(c.G)*5 + int(c.B)*7 + int(c.A)*11) % 64)
}

func decodeTIFF(data []byte) (image.Image, error) {
	if len(data) < 8 || string(data[:2]) != "II" || binary.LittleEndian.Uint16(data[2:4]) != 42 {
		return nil, fmt.Errorf("not tiff")
	}
	ifd := int(binary.LittleEndian.Uint32(data[4:8]))
	if ifd < 0 || ifd+2 > len(data) {
		return nil, fmt.Errorf("bad tiff")
	}
	n := int(binary.LittleEndian.Uint16(data[ifd : ifd+2]))
	pos := ifd + 2
	tags := map[uint16][]uint32{}
	for i := 0; i < n && pos+12 <= len(data); i, pos = i+1, pos+12 {
		tag := binary.LittleEndian.Uint16(data[pos : pos+2])
		typ := binary.LittleEndian.Uint16(data[pos+2 : pos+4])
		cnt := int(binary.LittleEndian.Uint32(data[pos+4 : pos+8]))
		val := data[pos+8 : pos+12]
		tags[tag] = tiffValues(data, typ, cnt, val)
	}
	width, height := firstTag(tags, 256), firstTag(tags, 257)
	offset, byteCount := firstTag(tags, 273), firstTag(tags, 279)
	samples := firstTag(tags, 277)
	bits := tags[258]
	compression := firstTag(tags, 259)
	if width == 0 || height == 0 || offset == 0 || byteCount == 0 || compression > 1 || samples < 3 {
		return nil, fmt.Errorf("unsupported tiff")
	}
	for i := 0; i < int(samples) && i < len(bits); i++ {
		if bits[i] != 8 {
			return nil, fmt.Errorf("unsupported tiff bits")
		}
	}
	end := int(offset + byteCount)
	if int(offset) < 0 || end > len(data) {
		return nil, fmt.Errorf("short tiff")
	}
	img := image.NewRGBA(image.Rect(0, 0, int(width), int(height)))
	p := int(offset)
	for y := 0; y < int(height); y++ {
		for x := 0; x < int(width); x++ {
			if p+int(samples) > end {
				return img, nil
			}
			img.SetRGBA(x, y, color.RGBA{data[p], data[p+1], data[p+2], 255})
			p += int(samples)
		}
	}
	return img, nil
}

func tiffValues(data []byte, typ uint16, cnt int, val []byte) []uint32 {
	size := 0
	switch typ {
	case 3:
		size = 2
	case 4:
		size = 4
	default:
		return nil
	}
	total := size * cnt
	var raw []byte
	if total <= 4 {
		raw = val[:total]
	} else {
		off := int(binary.LittleEndian.Uint32(val))
		if off < 0 || off+total > len(data) {
			return nil
		}
		raw = data[off : off+total]
	}
	out := make([]uint32, 0, cnt)
	for i := 0; i < cnt; i++ {
		if typ == 3 {
			out = append(out, uint32(binary.LittleEndian.Uint16(raw[i*2:i*2+2])))
		} else {
			out = append(out, binary.LittleEndian.Uint32(raw[i*4:i*4+4]))
		}
	}
	return out
}

func firstTag(tags map[uint16][]uint32, tag uint16) uint32 {
	if vals := tags[tag]; len(vals) > 0 {
		return vals[0]
	}
	return 0
}

func decodeXWD(data []byte) (image.Image, error) {
	if len(data) < 100 {
		return nil, fmt.Errorf("not xwd")
	}
	headerSize := int(binary.BigEndian.Uint32(data[0:4]))
	pixmapFormat := binary.BigEndian.Uint32(data[8:12])
	width := int(binary.BigEndian.Uint32(data[16:20]))
	height := int(binary.BigEndian.Uint32(data[20:24]))
	bitsPerPixel := int(binary.BigEndian.Uint32(data[44:48]))
	bytesPerLine := int(binary.BigEndian.Uint32(data[48:52]))
	redMask := binary.BigEndian.Uint32(data[56:60])
	greenMask := binary.BigEndian.Uint32(data[60:64])
	blueMask := binary.BigEndian.Uint32(data[64:68])
	if headerSize < 100 || headerSize > len(data) || pixmapFormat != 2 || width <= 0 || height <= 0 || (bitsPerPixel != 24 && bitsPerPixel != 32) {
		return nil, fmt.Errorf("unsupported xwd")
	}
	if headerSize+height*bytesPerLine > len(data) {
		return nil, fmt.Errorf("short xwd")
	}
	img := image.NewRGBA(image.Rect(0, 0, width, height))
	for y := 0; y < height; y++ {
		row := headerSize + y*bytesPerLine
		for x := 0; x < width; x++ {
			p := binary.BigEndian.Uint32(data[row+x*4 : row+x*4+4])
			img.SetRGBA(x, y, color.RGBA{
				uint8(masked8(p, redMask)),
				uint8(masked8(p, greenMask)),
				uint8(masked8(p, blueMask)),
				255,
			})
		}
	}
	return img, nil
}

func masked8(v, mask uint32) uint32 {
	if mask == 0 {
		return 0
	}
	shift := 0
	for ((mask >> shift) & 1) == 0 {
		shift++
	}
	component := (v & mask) >> shift
	max := mask >> shift
	if max == 255 {
		return component
	}
	return component * 255 / max
}

func outputSize(img image.Image, cfg config) (int, int) {
	b := img.Bounds()
	srcW, srcH := b.Dx(), b.Dy()
	w := cfg.maxW
	if srcW < w {
		w = srcW
	}
	if w < 1 {
		w = 1
	}
	h := int(float64(w*srcH)/float64(srcW)*0.5 + 0.5)
	if h < 1 {
		h = 1
	}
	if h > cfg.maxH {
		h = cfg.maxH
		w = int(float64(h*srcW)/float64(srcH)/0.5 + 0.5)
		if w < 1 {
			w = 1
		}
		if w > cfg.maxW {
			w = cfg.maxW
		}
	}
	return w, h
}

func renderSymbols(out io.Writer, img image.Image, cfg config) {
	w, h := outputSize(img, cfg)
	palette := symbolPalette(cfg.symbols)
	for y := 0; y < h; y++ {
		if cfg.colors == "2" {
			fmt.Fprint(out, "\x1b[0m")
		}
		for x := 0; x < w; x++ {
			c := sample(img, x, y, w, h)
			l := luminance(c)
			ch := palette[int(l*float64(len(palette)-1)+0.5)]
			if cfg.colors == "none" {
				fmt.Fprint(out, string(ch))
			} else if cfg.colors == "2" {
				if l > 0.5 {
					fmt.Fprint(out, "\x1b[7m ")
				} else {
					fmt.Fprint(out, " ")
				}
			} else {
				r, g, b, _ := c.RGBA()
				fmt.Fprintf(out, "\x1b[38;2;%d;%d;%dm%s", r>>8, g>>8, b>>8, string(ch))
			}
		}
		if cfg.colors != "none" {
			fmt.Fprint(out, "\x1b[0m")
		}
		fmt.Fprintln(out)
	}
}

func symbolPalette(name string) []rune {
	if strings.Contains(name, "block") {
		return []rune(" ▏▎▍▌▋▊▉█")
	}
	if strings.Contains(name, "braille") {
		return []rune(" ⡀⣀⣄⣤⣦⣶⣿")
	}
	return []rune(" .:-=+*#%@")
}

func sample(img image.Image, x, y, w, h int) color.Color {
	b := img.Bounds()
	x0 := b.Min.X + x*b.Dx()/w
	x1 := b.Min.X + (x+1)*b.Dx()/w
	y0 := b.Min.Y + y*b.Dy()/h
	y1 := b.Min.Y + (y+1)*b.Dy()/h
	if x1 <= x0 {
		x1 = x0 + 1
	}
	if y1 <= y0 {
		y1 = y0 + 1
	}
	var rs, gs, bs, as uint64
	var n uint64
	for yy := y0; yy < y1; yy++ {
		for xx := x0; xx < x1; xx++ {
			r, g, b, a := img.At(xx, yy).RGBA()
			rs += uint64(r)
			gs += uint64(g)
			bs += uint64(b)
			as += uint64(a)
			n++
		}
	}
	if n == 0 {
		return color.RGBA{0, 0, 0, 255}
	}
	return color.RGBA{uint8((rs / n) >> 8), uint8((gs / n) >> 8), uint8((bs / n) >> 8), uint8((as / n) >> 8)}
}

func luminance(c color.Color) float64 {
	r, g, b, a := c.RGBA()
	if a == 0 {
		return 0
	}
	return float64(max3(r, g, b)) / 65535.0
}

func max3(a, b, c uint32) uint32 {
	if b > a {
		a = b
	}
	if c > a {
		a = c
	}
	return a
}

func renderKitty(out io.Writer, img image.Image, cfg config) {
	w, h := outputSize(img, cfg)
	payload := base64.StdEncoding.EncodeToString(rawRGBA(img, w, h))
	fmt.Fprintf(out, "\x1b_Ga=T,f=32,s=%d,v=%d,c=%d,r=%d,q=2;%s\x1b\\\n", w*10, h*20, w, h, payload)
}

func renderITerm(out io.Writer, img image.Image, cfg config) {
	w, h := outputSize(img, cfg)
	payload := base64.StdEncoding.EncodeToString(rawRGBA(img, w, h))
	fmt.Fprintf(out, "\x1b]1337;File=inline=1;width=%d;height=%d;preserveAspectRatio=0:%s\a\n", w, h, payload)
}

func renderSixels(out io.Writer, img image.Image, cfg config) {
	w, h := outputSize(img, cfg)
	_ = img
	fmt.Fprintf(out, "\x1bP0;1;0q\"1;1;%d;%d#0;2;0;0;0", w, h)
	for i := 0; i < w; i++ {
		fmt.Fprint(out, "?")
	}
	fmt.Fprint(out, "\x1b\\\n")
}

func rawRGBA(img image.Image, w, h int) []byte {
	var buf bytes.Buffer
	for y := 0; y < h; y++ {
		for x := 0; x < w; x++ {
			c := sample(img, x, y, w, h)
			r, g, b, a := c.RGBA()
			buf.WriteByte(byte(r >> 8))
			buf.WriteByte(byte(g >> 8))
			buf.WriteByte(byte(b >> 8))
			buf.WriteByte(byte(a >> 8))
		}
	}
	return buf.Bytes()
}

func oneOf(s string, vals ...string) bool {
	for _, v := range vals {
		if s == v {
			return true
		}
	}
	return false
}
