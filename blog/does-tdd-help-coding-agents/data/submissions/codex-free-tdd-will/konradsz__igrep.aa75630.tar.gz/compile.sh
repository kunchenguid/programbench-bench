#!/bin/bash
set -e
cat > executable <<'EOF'
#!/bin/bash
DIR="$(cd "$(dirname "$0")" && pwd)"
exec python3 "$DIR/igrep.py" "$@"
EOF
chmod +x executable
