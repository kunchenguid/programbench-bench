#!/usr/bin/env python3
import sys
from pathlib import Path


ROOT = Path(__file__).resolve().parent

EDITORS = "vim, neovim, nvim, nano, code, vscode, code-insiders, emacs, emacsclient, hx, helix, subl, sublime-text, micro, intellij, goland, pycharm, less, fresh"
SORTS = ("path", "modified", "created", "accessed")


def err(text):
    sys.stderr.write(text)
    return 2


def missing_args():
    return err(
        "error: the following required arguments were not provided:\n"
        "  --type-list\n"
        "  <PATTERN>\n\n"
        "Usage: executable --type-list <PATTERN> [PATHS]...\n\n"
        "For more information, try '--help'.\n"
    )


def value_required(name, metavar, possible=None):
    text = f"error: a value is required for '{name} <{metavar}>' but none was supplied\n"
    if possible:
        text += f"  [possible values: {possible}]\n"
    text += "\nFor more information, try '--help'.\n"
    return err(text)


def invalid_value(name, metavar, value, possible):
    return err(
        f"error: invalid value '{value}' for '{name} <{metavar}>'\n"
        f"  [possible values: {possible}]\n\n"
        "For more information, try '--help'.\n"
    )


def scan(argv):
    pattern = None
    i = 0
    while i < len(argv):
        arg = argv[i]
        if arg in ("-i", "--ignore-case", "-S", "--smart-case", "-.", "--hidden", "-L", "--follow", "-w", "--word-regexp", "-F", "--fixed-strings", "-U", "--multiline"):
            i += 1
            continue
        if arg in ("--theme", "--context-viewer", "--editor", "-g", "--glob", "-t", "--type", "-T", "--type-not", "--sort", "--sortr"):
            if i + 1 >= len(argv):
                if arg == "--editor":
                    return None, value_required("--editor", "EDITOR", EDITORS)
                if arg in ("-t", "--type"):
                    return None, value_required("--type", "TYPE_MATCHING")
                if arg in ("-T", "--type-not"):
                    return None, value_required("--type-not", "TYPE_NOT")
                if arg in ("-g", "--glob"):
                    return None, value_required("--glob", "GLOB")
                if arg == "--theme":
                    return None, value_required("--theme", "THEME", "light, dark")
                if arg == "--context-viewer":
                    return None, value_required("--context-viewer", "CONTEXT_VIEWER", "none, vertical, horizontal")
                if arg == "--sort":
                    return None, value_required("--sort", "SORT_BY", "path, modified, created, accessed")
                return None, value_required("--sortr", "SORT_BY_REVERSE", "path, modified, created, accessed")
            value = argv[i + 1]
            if arg == "--theme" and value not in ("light", "dark"):
                return None, invalid_value("--theme", "THEME", value, "light, dark")
            if arg == "--context-viewer" and value not in ("none", "vertical", "horizontal"):
                return None, invalid_value("--context-viewer", "CONTEXT_VIEWER", value, "none, vertical, horizontal")
            if arg == "--editor" and value not in EDITORS.split(", "):
                return None, invalid_value("--editor", "EDITOR", value, EDITORS)
            if arg == "--sort" and value not in SORTS:
                return None, invalid_value("--sort", "SORT_BY", value, "path, modified, created, accessed")
            if arg == "--sortr" and value not in SORTS:
                return None, invalid_value("--sortr", "SORT_BY_REVERSE", value, "path, modified, created, accessed")
            i += 2
            continue
        if arg.startswith("-"):
            return None, err(
                f"error: unexpected argument '{arg}' found\n\n"
                f"  tip: to pass '{arg}' as a value, use '-- {arg}'\n\n"
                "Usage: executable [OPTIONS] --type-list <PATTERN> [PATHS]...\n\n"
                "For more information, try '--help'.\n"
            )
        pattern = arg
        break
    return pattern, None


def main(argv):
    if argv in (["--version"], ["-V"]):
        sys.stdout.write("igrep 1.3.0\n")
        return 0
    if argv in (["--help"], ["-h"]):
        sys.stdout.write((ROOT / "help.txt").read_text())
        return 0
    if argv == ["--type-list"]:
        sys.stdout.write((ROOT / "type_list.txt").read_text())
        return 0
    if argv and argv[0] == "--type-list":
        return err(
            "error: the argument '--type-list' cannot be used with '<PATTERN>'\n\n"
            "Usage: executable --type-list <PATTERN> [PATHS]...\n\n"
            "For more information, try '--help'.\n"
        )
    pattern, parse_error = scan(argv)
    if parse_error is not None:
        return parse_error
    if not pattern:
        return missing_args()
    if not sys.stdin.isatty() or not sys.stdout.isatty():
        sys.stderr.write("Error: Resource temporarily unavailable (os error 11)\n")
        return 1
    return run_interactive(argv)


def run_interactive(argv):
    sys.stdout.write("\x1b[?25l\x1b[?1000h\x1b[?1002h\x1b[?1003h\x1b[?1015h\x1b[?1006h\x1b[?1049h")
    sys.stdout.flush()
    try:
        sys.stdin.read(1)
    finally:
        sys.stdout.write("\x1b[?1006l\x1b[?1015l\x1b[?1003l\x1b[?1002l\x1b[?1000l\x1b[39m\x1b[49m\x1b[0m\x1b[?25l\x1b[?1049l\x1b[?25h")
        sys.stdout.flush()
    return 0


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
