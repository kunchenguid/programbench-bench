import subprocess
import sys
import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
CMD = [sys.executable, str(ROOT / "igrep.py")]


def run_cmd(*args, cwd=None, input_text=None):
    return subprocess.run(
        CMD + list(args),
        cwd=cwd or ROOT,
        input=input_text,
        text=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
    )


class CliTests(unittest.TestCase):
    def test_version_and_type_list_match_public_cli(self):
        version = run_cmd("--version")
        self.assertEqual(version.returncode, 0)
        self.assertEqual(version.stdout, "igrep 1.3.0\n")
        self.assertEqual(version.stderr, "")

        expected = (ROOT / "type_list.txt").read_text()
        type_list = run_cmd("--type-list")
        self.assertEqual(type_list.returncode, 0)
        self.assertEqual(type_list.stdout, expected)
        self.assertEqual(type_list.stderr, "")

    def test_help_and_argument_errors_match_public_cli(self):
        help_result = run_cmd("--help")
        self.assertEqual(help_result.returncode, 0)
        self.assertEqual(help_result.stdout, (ROOT / "help.txt").read_text())
        self.assertEqual(help_result.stderr, "")

        cases = [
            ((), 2, "", "error: the following required arguments were not provided:\n  --type-list\n  <PATTERN>\n\nUsage: executable --type-list <PATTERN> [PATHS]...\n\nFor more information, try '--help'.\n"),
            (("--bad",), 2, "", "error: unexpected argument '--bad' found\n\n  tip: to pass '--bad' as a value, use '-- --bad'\n\nUsage: executable [OPTIONS] --type-list <PATTERN> [PATHS]...\n\nFor more information, try '--help'.\n"),
            (("--theme", "bad", "hello"), 2, "", "error: invalid value 'bad' for '--theme <THEME>'\n  [possible values: light, dark]\n\nFor more information, try '--help'.\n"),
            (("--context-viewer", "bad", "hello"), 2, "", "error: invalid value 'bad' for '--context-viewer <CONTEXT_VIEWER>'\n  [possible values: none, vertical, horizontal]\n\nFor more information, try '--help'.\n"),
            (("--editor", "bad", "hello"), 2, "", "error: invalid value 'bad' for '--editor <EDITOR>'\n  [possible values: vim, neovim, nvim, nano, code, vscode, code-insiders, emacs, emacsclient, hx, helix, subl, sublime-text, micro, intellij, goland, pycharm, less, fresh]\n\nFor more information, try '--help'.\n"),
            (("--type-list", "foo"), 2, "", "error: the argument '--type-list' cannot be used with '<PATTERN>'\n\nUsage: executable --type-list <PATTERN> [PATHS]...\n\nFor more information, try '--help'.\n"),
            (("--editor",), 2, "", "error: a value is required for '--editor <EDITOR>' but none was supplied\n  [possible values: vim, neovim, nvim, nano, code, vscode, code-insiders, emacs, emacsclient, hx, helix, subl, sublime-text, micro, intellij, goland, pycharm, less, fresh]\n\nFor more information, try '--help'.\n"),
            (("-t",), 2, "", "error: a value is required for '--type <TYPE_MATCHING>' but none was supplied\n\nFor more information, try '--help'.\n"),
            (("--sort", "bad", "hello"), 2, "", "error: invalid value 'bad' for '--sort <SORT_BY>'\n  [possible values: path, modified, created, accessed]\n\nFor more information, try '--help'.\n"),
        ]
        for args, code, stdout, stderr in cases:
            with self.subTest(args=args):
                result = run_cmd(*args)
                self.assertEqual(result.returncode, code)
                self.assertEqual(result.stdout, stdout)
                self.assertEqual(result.stderr, stderr)

    def test_search_without_terminal_reports_reference_error(self):
        work = ROOT / "tmp_search"
        work.mkdir(exist_ok=True)
        (work / "a.txt").write_text("hello\nworld hello\n")

        result = run_cmd("hello", str(work))
        self.assertEqual(result.returncode, 1)
        self.assertEqual(result.stdout, "")
        self.assertEqual(result.stderr, "Error: Resource temporarily unavailable (os error 11)\n")


if __name__ == "__main__":
    unittest.main()
