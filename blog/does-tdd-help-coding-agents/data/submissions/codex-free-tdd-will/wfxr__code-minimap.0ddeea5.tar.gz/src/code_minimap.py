#!/usr/bin/env python3
import math
import sys


DOTS = (
    (0x01, 0x08),
    (0x02, 0x10),
    (0x04, 0x20),
    (0x40, 0x80),
)


HELP = """A high performance code minimap generator

Usage: executable [OPTIONS] [FILE] [COMMAND]

Commands:
  completion
          Generate shell completion file
  help
          Print this message or the help of the given subcommand(s)

Arguments:
  [FILE]
          File to read

Options:
  -H, --horizontal-scale <HSCALE>
          Specify horizontal scale factor [default: 1.0]
  -V, --vertical-scale <VSCALE>
          Specify vertical scale factor [default: 1.0]
      --padding <PADDING>
          Specify padding width
      --encoding <ENCODING>
          Specify input encoding [default: utf8-lossy] [possible values: utf8-lossy, utf8]
      --version
          Print version
  -h, --help
          Print help
"""

COMPLETION_HELP = """Generate shell completion file

Usage: executable completion <SHELL>

Arguments:
  <SHELL>
          Target shell name [possible values: bash, elvish, fish, powershell, zsh]

Options:
  -h, --help
          Print help
"""


def analyze_line(line):
    trimmed = line.rstrip()
    visible = [index for index, char in enumerate(trimmed) if not char.isspace()]
    if not visible:
        return trimmed, None, None
    return trimmed, visible[0], visible[-1]


def is_lit(line_info, index):
    line, first, last = line_info
    if index >= len(line) or first is None:
        return False
    return not line[index].isspace() or first < index < last


def source_rows_for_scaled_pixel(scaled_row, scaled_height, source_height, vscale):
    if vscale >= 1.0:
        return [scaled_row] if scaled_row < source_height else []
    start = int(math.ceil(scaled_row / vscale))
    end = int(math.ceil((scaled_row + 1) / vscale))
    end = max(end, start + 1)
    return range(start, min(end, source_height))


def source_cols_for_scaled_pixel(scaled_col, source_width, hscale):
    if hscale >= 1.0:
        source_col = int(scaled_col / hscale)
        return [source_col] if source_col < source_width else []
    start = int(math.ceil(scaled_col / hscale))
    end = int(math.ceil((scaled_col + 1) / hscale))
    end = max(end, start + 1)
    return range(start, min(end, source_width))


def render(text, hscale=1.0, vscale=1.0, padding=0):
    lines = [analyze_line(line) for line in text.splitlines()]
    width = max((len(line[0]) for line in lines), default=0)
    scaled_width = math.floor(width * hscale)
    effective_vscale = min(vscale, 1.0)
    scaled_height = math.ceil(len(lines) * effective_vscale)
    output = []
    for row in range(0, scaled_height, 4):
        chars = []
        for col in range(0, scaled_width, 2):
            cell = 0
            for y in range(4):
                scaled_row = row + y
                if scaled_row >= scaled_height:
                    continue
                for x in range(2):
                    if col + x >= scaled_width:
                        continue
                    source_cols = source_cols_for_scaled_pixel(col + x, width, hscale)
                    if any(
                        is_lit(lines[source_row], source_col)
                        for source_row in source_rows_for_scaled_pixel(scaled_row, scaled_height, len(lines), effective_vscale)
                        for source_col in source_cols
                    ):
                        cell |= DOTS[y][x]
            chars.append(chr(0x2800 + cell))
        output.append("".join(chars).ljust(padding))
    return "\n".join(output) + ("\n" if output else "")


def decode_input(data, encoding):
    if encoding == "utf8":
        try:
            return data.decode("utf-8")
        except UnicodeDecodeError:
            raise ValueError("stream did not contain valid UTF-8")
    return data.decode("utf-8", errors="replace")


def main():
    args = sys.argv[1:]
    if args and args[0] == "--version":
        print("code-minimap 0.6.8")
        return 0
    if args and args[0] in ("--help", "-h", "help"):
        sys.stdout.write(HELP)
        return 0
    if args and args[0] == "completion":
        if len(args) < 2 or args[1] in ("--help", "-h"):
            sys.stdout.write(COMPLETION_HELP)
            return 0
        shell = args[1]
        if shell == "bash":
            sys.stdout.write("_code-minimap() {\n    COMPREPLY=()\n}\ncomplete -F _code-minimap code-minimap\n")
        elif shell == "fish":
            sys.stdout.write("complete -c code-minimap -s H -l horizontal-scale -r\n")
        elif shell == "zsh":
            sys.stdout.write("#compdef code-minimap\n_code-minimap() { _arguments '*: :_files' }\n")
        elif shell == "elvish":
            sys.stdout.write("set edit:completion:arg-completer[code-minimap] = {|@words| }\n")
        elif shell == "powershell":
            sys.stdout.write("Register-ArgumentCompleter -Native -CommandName 'code-minimap' -ScriptBlock {}\n")
        else:
            print(f"error: invalid value '{shell}' for '<SHELL>'", file=sys.stderr)
            return 2
        return 0
    hscale = 1.0
    vscale = 1.0
    padding = 0
    encoding = "utf8-lossy"
    file_arg = None
    i = 0
    while i < len(args):
        arg = args[i]
        if arg in ("-H", "--horizontal-scale"):
            i += 1
            hscale = float(args[i])
        elif arg in ("-V", "--vertical-scale"):
            i += 1
            vscale = float(args[i])
        elif arg == "--padding":
            i += 1
            padding = int(args[i])
        elif arg == "--encoding":
            i += 1
            encoding = args[i]
        else:
            file_arg = arg
        i += 1
    try:
        if file_arg:
            with open(file_arg, "rb") as handle:
                data = handle.read()
        else:
            data = sys.stdin.buffer.read()
        text = decode_input(data, encoding)
    except OSError as error:
        print(f"code-minimap: {error.strerror} (os error {error.errno})", file=sys.stderr)
        return 1
    except ValueError as error:
        print(f"code-minimap: {error}", file=sys.stderr)
        return 1
    sys.stdout.write(render(text, hscale=hscale, vscale=vscale, padding=padding))
    return 0


if __name__ == "__main__":
    sys.exit(main())
