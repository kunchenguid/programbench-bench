import subprocess
import tempfile
import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
SCRIPT = ROOT / "src" / "code_minimap.py"


def run_minimap(args=None, data=None):
    args = args or []
    return subprocess.run(
        ["python3", str(SCRIPT), *args],
        input=data,
        text=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
    )


class CodeMinimapCliTests(unittest.TestCase):
    def test_version_matches_documented_tool(self):
        result = run_minimap(["--version"])

        self.assertEqual(result.returncode, 0)
        self.assertEqual(result.stdout, "code-minimap 0.6.8\n")

    def test_help_prints_cli_usage(self):
        result = run_minimap(["--help"])

        self.assertEqual(result.returncode, 0)
        self.assertIn("A high performance code minimap generator\n\nUsage: executable [OPTIONS] [FILE] [COMMAND]", result.stdout)
        self.assertIn("--horizontal-scale <HSCALE>", result.stdout)

    def test_single_character_lights_first_braille_dot(self):
        with tempfile.NamedTemporaryFile("w", delete=False) as handle:
            handle.write("a\n")
            path = handle.name

        result = run_minimap([path])

        self.assertEqual(result.returncode, 0)
        self.assertEqual(result.stdout, "\u2801\n")

    def test_reads_from_stdin_when_no_file_is_given(self):
        result = run_minimap(data="ab\ncd\n")

        self.assertEqual(result.returncode, 0)
        self.assertEqual(result.stdout, "\u281b\n")

    def test_internal_spaces_are_rendered_but_trailing_spaces_are_trimmed(self):
        result = run_minimap(data="a a\n")

        self.assertEqual(result.returncode, 0)
        self.assertEqual(result.stdout, "\u2809\u2801\n")

    def test_groups_two_columns_and_four_rows_per_braille_cell(self):
        with tempfile.NamedTemporaryFile("w", delete=False) as handle:
            handle.write("abcd\nefgh\nijkl\nmnop\nqrst\n")
            path = handle.name

        result = run_minimap([path])

        self.assertEqual(result.returncode, 0)
        self.assertEqual(result.stdout, "\u28ff\u28ff\n\u2809\u2809\n")

    def test_horizontal_scale_changes_rendered_width(self):
        with tempfile.NamedTemporaryFile("w", delete=False) as handle:
            handle.write("abcd\nefgh\nijkl\nmnop\nqrst\n")
            path = handle.name

        result = run_minimap(["-H", "0.5", path])

        self.assertEqual(result.returncode, 0)
        self.assertEqual(result.stdout, "\u28ff\n\u2809\n")

    def test_horizontal_downscale_preserves_visible_columns_in_bucket(self):
        result = run_minimap(["-H", "0.25"], data="  a b  \n")

        self.assertEqual(result.returncode, 0)
        self.assertEqual(result.stdout, "\u2801\n")

    def test_vertical_scale_downsamples_rows(self):
        with tempfile.NamedTemporaryFile("w", delete=False) as handle:
            handle.write("abcd\nefgh\nijkl\nmnop\nqrst\n")
            path = handle.name

        result = run_minimap(["-V", "0.5", path])

        self.assertEqual(result.returncode, 0)
        self.assertEqual(result.stdout, "\u283f\u283f\n")

    def test_padding_sets_minimum_output_width(self):
        with tempfile.NamedTemporaryFile("w", delete=False) as handle:
            handle.write("x\n")
            path = handle.name

        result = run_minimap(["--padding", "3", path])

        self.assertEqual(result.returncode, 0)
        self.assertEqual(result.stdout, "\u2801  \n")

    def test_utf8_encoding_rejects_invalid_input(self):
        with tempfile.NamedTemporaryFile("wb", delete=False) as handle:
            handle.write(b"a\xffb\n")
            path = handle.name

        result = run_minimap(["--encoding", "utf8", path])

        self.assertEqual(result.returncode, 1)
        self.assertEqual(result.stderr, "code-minimap: stream did not contain valid UTF-8\n")


if __name__ == "__main__":
    unittest.main()
