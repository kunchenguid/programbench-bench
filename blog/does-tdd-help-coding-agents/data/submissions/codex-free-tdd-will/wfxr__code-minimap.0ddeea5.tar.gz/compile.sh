#!/bin/bash
set -e
rm -f executable
cp src/code_minimap.py executable
chmod +x executable
