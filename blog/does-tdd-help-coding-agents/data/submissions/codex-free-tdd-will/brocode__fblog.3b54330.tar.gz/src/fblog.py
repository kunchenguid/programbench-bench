#!/usr/bin/env python3
import sys


BOLD = "\033[1m"
RESET = "\033[0m"


class JsonParser:
    def __init__(self, text):
        self.text = text
        self.i = 0

    def parse(self):
        value = self.value()
        self.ws()
        if self.i != len(self.text):
            raise ValueError("trailing data")
        return value

    def ws(self):
        while self.i < len(self.text) and self.text[self.i] in " \t\r\n":
            self.i += 1

    def value(self):
        self.ws()
        if self.i >= len(self.text):
            raise ValueError("unexpected end")
        c = self.text[self.i]
        if c == '"':
            return self.string()
        if c == "{":
            return self.object()
        if c == "[":
            return self.array()
        if c == "t" and self.text.startswith("true", self.i):
            self.i += 4
            return True
        if c == "f" and self.text.startswith("false", self.i):
            self.i += 5
            return False
        if c == "n" and self.text.startswith("null", self.i):
            self.i += 4
            return None
        return self.number()

    def string(self):
        self.i += 1
        out = []
        while self.i < len(self.text):
            c = self.text[self.i]
            self.i += 1
            if c == '"':
                return "".join(out)
            if c != "\\":
                out.append(c)
                continue
            if self.i >= len(self.text):
                raise ValueError("bad escape")
            e = self.text[self.i]
            self.i += 1
            table = {'"': '"', "\\": "\\", "/": "/", "b": "\b", "f": "\f", "n": "\n", "r": "\r", "t": "\t"}
            if e in table:
                out.append(table[e])
            elif e == "u":
                hx = self.text[self.i : self.i + 4]
                if len(hx) != 4:
                    raise ValueError("bad unicode escape")
                self.i += 4
                out.append(chr(int(hx, 16)))
            else:
                raise ValueError("bad escape")
        raise ValueError("unterminated string")

    def object(self):
        self.i += 1
        obj = {}
        self.ws()
        if self.i < len(self.text) and self.text[self.i] == "}":
            self.i += 1
            return obj
        while True:
            self.ws()
            key = self.string()
            self.ws()
            if self.i >= len(self.text) or self.text[self.i] != ":":
                raise ValueError("missing colon")
            self.i += 1
            obj[key] = self.value()
            self.ws()
            if self.i < len(self.text) and self.text[self.i] == "}":
                self.i += 1
                return obj
            if self.i >= len(self.text) or self.text[self.i] != ",":
                raise ValueError("missing comma")
            self.i += 1

    def array(self):
        self.i += 1
        arr = []
        self.ws()
        if self.i < len(self.text) and self.text[self.i] == "]":
            self.i += 1
            return arr
        while True:
            arr.append(self.value())
            self.ws()
            if self.i < len(self.text) and self.text[self.i] == "]":
                self.i += 1
                return arr
            if self.i >= len(self.text) or self.text[self.i] != ",":
                raise ValueError("missing comma")
            self.i += 1

    def number(self):
        start = self.i
        if self.text[self.i] == "-":
            self.i += 1
        while self.i < len(self.text) and self.text[self.i].isdigit():
            self.i += 1
        if self.i < len(self.text) and self.text[self.i] == ".":
            self.i += 1
            while self.i < len(self.text) and self.text[self.i].isdigit():
                self.i += 1
        if self.i < len(self.text) and self.text[self.i] in "eE":
            self.i += 1
            if self.i < len(self.text) and self.text[self.i] in "+-":
                self.i += 1
            while self.i < len(self.text) and self.text[self.i].isdigit():
                self.i += 1
        raw = self.text[start : self.i]
        if not raw or raw == "-":
            raise ValueError("bad number")
        return float(raw) if any(ch in raw for ch in ".eE") else int(raw)


def parse_json(text):
    return JsonParser(text).parse()


def find_first(obj, keys):
    for key in keys:
        if key in obj:
            return obj[key]
    return None


def lookup(obj, path):
    cur = obj
    for part in [p.strip() for p in path.split(">")]:
        if isinstance(cur, dict) and part in cur:
            cur = cur[part]
        elif isinstance(cur, list) and part.isdigit() and int(part) < len(cur):
            cur = cur[int(part)]
        else:
            return None
    return cur


def plain_value(value):
    if value is True:
        return "true"
    if value is False:
        return "false"
    if value is None:
        return "nil"
    if isinstance(value, list):
        return "[" + ", ".join(plain_value(v) for v in value) + "]"
    if isinstance(value, dict):
        return "{" + ", ".join(f"{k}: {plain_value(value[k])}" for k in sorted(value)) + "}"
    return str(value)


def styled_value(value):
    if value is True:
        return "\033[1;32mtrue\033[0m"
    if value is False:
        return "\033[1;31mfalse\033[0m"
    if value is None:
        return "\033[1;31mnil\033[0m"
    if isinstance(value, (int, float)):
        return f"\033[1;36m{value}\033[0m"
    if isinstance(value, str):
        return f"\033[1;33m{value}\033[0m"
    if isinstance(value, list):
        return "\033[2m[\033[0m" + "\033[2m, \033[0m".join(styled_value(v) for v in value) + "\033[2m]\033[0m"
    if isinstance(value, dict):
        parts = []
        for k in sorted(value):
            parts.append(f"\033[35m{k}\033[0m\033[2m: \033[0m{styled_value(value[k])}")
        return "\033[2m{\033[0m" + "\033[2m, \033[0m".join(parts) + "\033[2m}\033[0m"
    return str(value)


def substitute_message(msg, context, placeholder_fmt):
    if not isinstance(msg, str):
        return msg
    out = msg
    if isinstance(context, dict):
        items = context.items()
    elif isinstance(context, list):
        items = [(str(i), v) for i, v in enumerate(context)]
    else:
        items = []
    for key, value in items:
        marker = placeholder_fmt.replace("key", str(key))
        out = out.replace(marker, styled_value(value))
    return out


HELP = """json log viewer

Usage: executable [OPTIONS] [INPUT]

Arguments:
  [INPUT]  Sets the input file to use, otherwise assumes stdin [default: -]

Options:
  -a, --additional-value <additional-value>
          adds additional values
      --config-file <config-file>
          configuration file to load
  -m, --message-key <message-key>
          Adds an additional key to detect the message in the log entry.
      --print-lua
          Prints lua init expressions. Used for fblog debugging.
  -t, --time-key <time-key>
          Adds an additional key to detect the time in the log entry.
  -l, --level-key <level-key>
          Adds an additional key to detect the level in the log entry.
      --map-level <from=to>
          Rewrite the log level from one value to another.
  -d, --dump-all
          dumps all values
  -x, --excluded-value <excluded-value>
          Excludes values (--dump-all is enabled implicitly)
  -p, --with-prefix
          consider all text before opening curly brace as prefix
  -f, --filter <filter>
          lua expression to filter log entries.
      --main-line-format <main-line-format>
          Formats the main fblog output.
      --additional-value-format <additional-value-format>
          Formats the additional value fblog output.
  -s, --substitute
          Enable substitution of placeholders in the log messages.
  -c, --context-key <context-key>
          Use this key as the source of substitutions for the message.
  -F, --placeholder-format <placeholder-format>
          The format that should be used for substituting values in the message.
  -h, --help
          Print help
  -V, --version
          Print version
"""


def value_line(key, value, fmt=None):
    if fmt:
        return fmt.replace("{{key}}", key).replace("{{value}}", plain_value(value))
    return f"{BOLD}\033[38;2;150;150;150m{key.rjust(25)}\033[0m{RESET}: {plain_value(value)}"


def fmt_time(value):
    if value is None:
        return ""
    s = str(value)
    if s.isdigit() and len(s) >= 13:
        import datetime

        return datetime.datetime.utcfromtimestamp(int(s) / 1000).strftime("%Y-%m-%dT%H:%M:%S")
    if s.endswith("Z"):
        s = s[:-1]
    if "." in s and "T" in s:
        return s.split(".", 1)[0]
    if " CEST " in s:
        s = s.replace(" CEST ", " ")
    return s[:19].rjust(19)


def level_style(level):
    s = str(level if level is not None else "unknown").upper()
    shown = s[:5].rjust(5)
    if s in ("INFO", "INFORMATION", "20"):
        color = "32"
        shown = " INFO" if s != "20" else "   20"
    elif s in ("WARN", "WARNING", "30"):
        color = "33" if s in ("WARN", "30") else "35"
        shown = " WARN" if s in ("WARN", "30") else "WARNI"
    elif s in ("ERROR", "ERR", "40", "50", "60"):
        color = "31"
    elif s in ("DEBUG", "10"):
        color = "34"
    else:
        color = "35"
    return f"\033[1;{color}m{shown}\033[0m"


def render(obj, prefix=None, opts=None):
    opts = opts or {}
    msg = find_first(obj, opts.get("message_keys", []) + ["short_message", "msg", "message"])
    if opts.get("substitute"):
        msg = substitute_message(msg, lookup(obj, opts.get("context_key", "context")), opts.get("placeholder_fmt", "{key}"))
    ts = find_first(obj, opts.get("time_keys", []) + ["timestamp", "time", "@timestamp"])
    lvl = find_first(obj, opts.get("level_keys", []) + ["level", "severity", "log.level", "loglevel"])
    if isinstance(lvl, str) and lvl in opts.get("level_map", {}):
        lvl = opts["level_map"][lvl]
    if opts.get("main_fmt"):
        return (
            opts["main_fmt"]
            .replace("{{message}}", "" if msg is None else str(msg))
            .replace("{{fblog_message}}", "" if msg is None else str(msg))
            .replace("{{level}}", "" if lvl is None else str(lvl))
            .replace("{{time}}", "" if ts is None else str(ts))
        )
    prefix_text = f" {BOLD}\033[36m{prefix.rstrip()}\033[0m{RESET}" if prefix else ""
    return f"{BOLD}{fmt_time(ts)}{RESET} {level_style(lvl)}:{prefix_text} {'' if msg is None else msg}"


def filter_value(obj, name):
    if name in obj:
        return obj[name]
    return lookup(obj, name.replace(".", " > "))


def passes_filter(obj, expr):
    if not expr:
        return True
    e = expr.strip()
    if e.startswith("return "):
        e = e[7:].strip()
    for op in ("==", "~="):
        if op in e:
            left, right = e.split(op, 1)
            left = left.strip()
            right = right.strip()
            if len(right) >= 2 and right[0] == right[-1] == '"':
                right_val = right[1:-1]
            else:
                right_val = right
            val = filter_value(obj, left)
            eq = str(val) == right_val
            return eq if op == "==" else not eq
    if "string.find" in e:
        start = e.find("string.find(") + len("string.find(")
        end = e.find(")", start)
        args = e[start:end].split(",", 1)
        if len(args) == 2:
            val = filter_value(obj, args[0].strip())
            needle = args[1].strip().strip('"')
            return val is not None and needle in str(val)
    return True


def parse_string_array(raw):
    raw = raw.strip()
    if not (raw.startswith("[") and raw.endswith("]")):
        return []
    inner = raw[1:-1].strip()
    if not inner:
        return []
    out = []
    for part in inner.split(","):
        p = part.strip()
        if len(p) >= 2 and p[0] == p[-1] == '"':
            out.append(p[1:-1])
    return out


def load_config(path, opts):
    section = None
    try:
        lines = open(path, "r", encoding="utf-8").read().splitlines()
    except OSError:
        return
    for raw in lines:
        line = raw.split("#", 1)[0].strip()
        if not line:
            continue
        if line.startswith("[") and line.endswith("]"):
            section = line[1:-1]
            continue
        if "=" not in line:
            continue
        key, value = [x.strip() for x in line.split("=", 1)]
        if section == "level_map":
            if len(value) >= 2 and value[0] == value[-1] == '"':
                value = value[1:-1]
            opts["level_map"][key] = value
        elif key == "message_keys":
            opts["message_keys"].extend(parse_string_array(value))
        elif key == "time_keys":
            opts["time_keys"].extend(parse_string_array(value))
        elif key == "level_keys":
            opts["level_keys"].extend(parse_string_array(value))
        elif key == "always_print_fields":
            opts["additional"].extend(parse_string_array(value))
        elif key == "dump_all_exclude":
            opts["excluded"].extend(parse_string_array(value))
        elif key == "main_line_format" and len(value) >= 2:
            opts["main_fmt"] = value.strip('"')
        elif key == "additional_value_format" and len(value) >= 2:
            opts["additional_fmt"] = value.strip('"')


def main(argv):
    if "--help" in argv or "-h" in argv:
        print(HELP, end="")
        return 0
    if "--version" in argv or "-V" in argv:
        print("fblog 4.17.0")
        return 0
    path = "-"
    opts = {
        "with_prefix": False,
        "additional": [],
        "dump": False,
        "excluded": [],
        "additional_fmt": None,
        "message_keys": [],
        "time_keys": [],
        "level_keys": [],
        "level_map": {},
        "filter": None,
        "substitute": False,
        "context_key": "context",
        "placeholder_fmt": "{key}",
        "main_fmt": None,
        "config_file": None,
    }
    i = 1
    while i < len(argv):
        a = argv[i]
        if a in ("-p", "--with-prefix"):
            opts["with_prefix"] = True
        elif a in ("-d", "--dump-all"):
            opts["dump"] = True
        elif a in ("-a", "--additional-value"):
            i += 1
            opts["additional"].append(argv[i])
        elif a in ("-x", "--excluded-value"):
            opts["dump"] = True
            i += 1
            opts["excluded"].append(argv[i])
        elif a == "--additional-value-format":
            i += 1
            opts["additional_fmt"] = argv[i]
        elif a == "--main-line-format":
            i += 1
            opts["main_fmt"] = argv[i]
        elif a == "--config-file":
            i += 1
            opts["config_file"] = argv[i]
        elif a in ("-m", "--message-key"):
            i += 1
            opts["message_keys"].append(argv[i])
        elif a in ("-t", "--time-key"):
            i += 1
            opts["time_keys"].append(argv[i])
        elif a in ("-l", "--level-key"):
            i += 1
            opts["level_keys"].append(argv[i])
        elif a == "--map-level":
            i += 1
            if "=" in argv[i]:
                k, v = argv[i].split("=", 1)
                opts["level_map"][k] = v
        elif a in ("-f", "--filter"):
            i += 1
            opts["filter"] = argv[i]
        elif a in ("-s", "--substitute"):
            opts["substitute"] = True
        elif a in ("-c", "--context-key"):
            i += 1
            opts["context_key"] = argv[i]
        elif a in ("-F", "--placeholder-format"):
            i += 1
            opts["placeholder_fmt"] = argv[i]
        elif a.startswith("-"):
            pass
        else:
            path = a
        i += 1
    if opts["config_file"]:
        load_config(opts["config_file"], opts)
    lines = sys.stdin if path == "-" else open(path, "r", encoding="utf-8")
    with lines:
        for line in lines:
            line = line.rstrip("\n")
            prefix = None
            parse_line = line
            if opts["with_prefix"] and "{" in line:
                pos = line.find("{")
                prefix = line[:pos]
                parse_line = line[pos:]
            try:
                obj = parse_json(parse_line)
            except Exception:
                print("\033[1;38;2;255;135;22m??? >\033[0m " + line)
                continue
            if isinstance(obj, dict):
                if not passes_filter(obj, opts["filter"]):
                    continue
                print(render(obj, prefix, opts))
                keys = list(opts["additional"])
                if opts["dump"]:
                    keys.extend(k for k in sorted(obj) if k not in opts["excluded"])
                for key in keys:
                    val = lookup(obj, key)
                    if val is not None:
                        print(value_line(key, val, opts["additional_fmt"]))
            else:
                print("\033[1;38;2;255;135;22m??? >\033[0m " + line)
    return 0


if __name__ == "__main__":
    raise SystemExit(main(sys.argv))
