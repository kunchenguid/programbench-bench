import json
import subprocess
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
BIN = ROOT / "src" / "hashcards.py"


def run(*args, cwd=None):
    return subprocess.run([str(BIN), *args], cwd=cwd, text=True, capture_output=True)


class HashcardsBehaviorTests(unittest.TestCase):
    def test_export_simple_basic_and_cloze_deck(self):
        with tempfile.TemporaryDirectory() as td:
            deck = Path(td) / "Deck.md"
            deck.write_text("Q: Q1\nA: A1\n\nC: [one] two [three]\n", encoding="utf-8")
            result = run("export", td)
            self.assertEqual(result.returncode, 0, result.stderr)
            payload = json.loads(result.stdout)
            self.assertEqual(payload["sessions"], [])
            cards = payload["cards"]
            self.assertEqual(len(cards), 3)
            basic = next(c for c in cards if "basic" in c["content"])
            self.assertEqual(basic["deckName"], "Deck")
            self.assertIsNone(basic["familyHash"])
            self.assertEqual(basic["content"]["basic"], {"question": "Q1", "answer": "A1"})
            self.assertEqual(basic["location"]["lineEnd"], 3)
            clozes = sorted((c["content"]["cloze"] for c in cards if "cloze" in c["content"]), key=lambda c: c["start"])
            self.assertEqual(clozes, [
                {"text": "one two three", "start": 0, "end": 2},
                {"text": "one two three", "start": 8, "end": 12},
            ])

    def test_stats_json_and_check_media_validation(self):
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            (root / "macros.tex").write_text("macro\n", encoding="utf-8")
            (root / "Deck.md").write_text("Q: See image\nA: ![](missing.png)\n\nC: [alpha]\n", encoding="utf-8")
            stats = run("stats", "--format", "json", td)
            self.assertEqual(stats.returncode, 0, stats.stderr)
            self.assertEqual(json.loads(stats.stdout), {
                "cardsInDeckCount": 2,
                "cardsInDbCount": 0,
                "texMacroCount": 1,
                "cardsReviewedTodayCount": 0,
            })
            check = run("check", td)
            self.assertEqual(check.returncode, 1)
            self.assertIn("Missing media files referenced in cards", check.stderr)
            self.assertIn("missing.png", check.stderr)


if __name__ == "__main__":
    unittest.main()
