#!/bin/bash
set -e
rm -f executable
cp src/hashcards.py executable
chmod +x executable
