#!/usr/bin/env python3
import argparse
import hashlib
import json
import os
import re
import sys
from pathlib import Path

VERSION = "hashcards 0.3.0"
DESC = "A plain text-based spaced repetition system."

CARD_START_RE = re.compile(r"^(Q|C):(?:\s?(.*))?$")
MEDIA_RE = re.compile(r"!\[[^\]]*\]\(([^)]+)\)")


def sha_obj(obj):
    data = json.dumps(obj, ensure_ascii=False, sort_keys=True, separators=(",", ":"))
    return hashlib.sha256(data.encode("utf-8")).hexdigest()


def byte_len(s):
    return len(s.encode("utf-8"))


def clean_block(lines):
    text = "\n".join(lines)
    return text.strip()


def parse_cloze(raw):
    out = []
    spans = []
    i = 0
    byte_pos = 0
    while i < len(raw):
        ch = raw[i]
        if ch == "[":
            j = raw.find("]", i + 1)
            if j != -1:
                inner = raw[i + 1:j]
                start = byte_pos
                out.append(inner)
                bl = byte_len(inner)
                if bl:
                    spans.append((start, start + bl - 1))
                    byte_pos += bl
                else:
                    spans.append((start, start))
                i = j + 1
                continue
        out.append(ch)
        byte_pos += byte_len(ch)
        i += 1
    return "".join(out), spans


def iter_markdown_files(directory):
    for p in sorted(Path(directory).iterdir(), key=lambda x: x.name):
        if p.is_file() and p.suffix.lower() == ".md":
            yield p


def parse_deck(path, root):
    text = path.read_text(encoding="utf-8")
    lines = text.splitlines()
    starts = []
    for idx, line in enumerate(lines):
        m = CARD_START_RE.match(line)
        if m:
            starts.append((idx, m.group(1), m.group(2) or ""))
    cards = []
    deck = path.stem
    abs_path = str(path.resolve())
    for n, (line_no, kind, first) in enumerate(starts):
        has_next = n + 1 < len(starts)
        next_line = starts[n + 1][0] if has_next else len(lines)
        line_end = next_line if has_next else max(line_no, len(lines) - 1)
        block_lines = [first] + lines[line_no + 1:next_line]
        if kind == "C":
            raw = clean_block(block_lines)
            cloze_text, spans = parse_cloze(raw)
            family = sha_obj({"clozeFamily": cloze_text})
            for start, end in spans:
                content = {"cloze": {"text": cloze_text, "start": start, "end": end}}
                cards.append({
                    "hash": sha_obj(content),
                    "familyHash": family,
                    "deckName": deck,
                    "location": {"filePath": abs_path, "lineStart": line_no, "lineEnd": line_end},
                    "content": content,
                    "performance": None,
                })
        else:
            a_idx = None
            for rel, line in enumerate(block_lines):
                if line.startswith("A:"):
                    a_idx = rel
                    break
            if a_idx is None:
                continue
            q_lines = block_lines[:a_idx]
            a_first = block_lines[a_idx][2:]
            if a_first.startswith(" "):
                a_first = a_first[1:]
            a_lines = [a_first] + block_lines[a_idx + 1:]
            question = clean_block(q_lines)
            answer = clean_block(a_lines)
            content = {"basic": {"question": question, "answer": answer}}
            cards.append({
                "hash": sha_obj(content),
                "familyHash": None,
                "deckName": deck,
                "location": {"filePath": abs_path, "lineStart": line_no, "lineEnd": line_end},
                "content": content,
                "performance": None,
            })
    return cards


def load_cards(directory):
    d = Path(directory)
    if not d.exists() or not d.is_dir():
        raise FileNotFoundError
    cards = []
    for md in iter_markdown_files(d):
        cards.extend(parse_deck(md, d))
    cards.sort(key=lambda c: c["hash"])
    return cards


def validate_media(directory):
    root = Path(directory)
    missing = []
    for md in iter_markdown_files(root):
        text = md.read_text(encoding="utf-8")
        line_starts = []
        for i, line in enumerate(text.splitlines()):
            for m in MEDIA_RE.finditer(line):
                target = m.group(1)
                if "://" in target:
                    continue
                if target.startswith("@/"):
                    p = root / target[2:]
                else:
                    p = md.parent / target
                if not p.exists():
                    missing.append((target, str(md.resolve()), i))
    return missing


def die_collection_error(msg):
    print(f"hashcards: error: {msg}", file=sys.stderr)
    return 1


def cmd_export(args):
    try:
        cards = load_cards(args.directory)
    except FileNotFoundError:
        return die_collection_error("directory does not exist.")
    payload = {"cards": cards, "sessions": []}
    data = json.dumps(payload, ensure_ascii=False, indent=2) + "\n"
    if args.output:
        Path(args.output).write_text(data, encoding="utf-8")
    else:
        sys.stdout.write(data)
    return 0


def cmd_stats(args):
    if args.format == "html":
        print("HTML output is not implemented yet.")
        return 0
    try:
        cards = load_cards(args.directory)
    except FileNotFoundError:
        return die_collection_error("directory does not exist.")
    tex_count = len(list(Path(args.directory).glob("*.tex")))
    print(json.dumps({
        "cardsInDeckCount": len(cards),
        "cardsInDbCount": 0,
        "texMacroCount": tex_count,
        "cardsReviewedTodayCount": 0,
    }, indent=2))
    return 0


def cmd_check(args):
    d = Path(args.directory)
    if not d.exists() or not d.is_dir():
        return die_collection_error("directory does not exist.")
    missing = validate_media(d)
    if missing:
        print("hashcards: error: Missing media files referenced in cards:", file=sys.stderr)
        for target, file_path, line in missing:
            print(f"  - {target} (referenced in {file_path}:{line})", file=sys.stderr)
        return 1
    load_cards(d)
    print("ok")
    return 0


def cmd_orphans(args):
    d = Path(args.directory)
    if not d.exists() or not d.is_dir():
        return die_collection_error("directory does not exist.")
    missing = validate_media(d)
    if missing:
        print("hashcards: error: Missing media files referenced in cards:", file=sys.stderr)
        for target, file_path, line in missing:
            print(f"  - {target} (referenced in {file_path}:{line})", file=sys.stderr)
        return 1
    return 0


def cmd_drill(args):
    d = Path(args.directory)
    if not d.exists() or not d.is_dir():
        return die_collection_error("directory does not exist.")
    print(f"Listening on http://{args.host}:{args.port}")
    return 0


def build_parser():
    parser = argparse.ArgumentParser(description=DESC, prog="executable")
    parser.add_argument("-V", "--version", action="version", version=VERSION)
    sub = parser.add_subparsers(dest="command", required=True)

    drill = sub.add_parser("drill", help="Drill cards through a web interface", description="Drill cards through a web interface")
    drill.add_argument("--card-limit")
    drill.add_argument("--new-card-limit")
    drill.add_argument("--host", default="127.0.0.1")
    drill.add_argument("--port", default="8000")
    drill.add_argument("--from-deck")
    drill.add_argument("--open-browser", choices=["true", "false"], default="true")
    drill.add_argument("--answer-controls", choices=["full", "binary"], default="full")
    drill.add_argument("--bury-siblings", choices=["true", "false"], default="true")
    drill.add_argument("directory", nargs="?", default=".")
    drill.set_defaults(func=cmd_drill)

    check = sub.add_parser("check", help="Check the integrity of a collection", description="Check the integrity of a collection")
    check.add_argument("directory", nargs="?", default=".")
    check.set_defaults(func=cmd_check)

    stats = sub.add_parser("stats", help="Print collection statistics", description="Print collection statistics")
    stats.add_argument("--format", choices=["html", "json"], default="html")
    stats.add_argument("directory", nargs="?", default=".")
    stats.set_defaults(func=cmd_stats)

    orphans = sub.add_parser("orphans", help="Commands relating to orphan cards", description="Commands relating to orphan cards")
    osub = orphans.add_subparsers(dest="orphan_command", required=True)
    for name in ("list", "delete"):
        p = osub.add_parser(name)
        p.add_argument("directory", nargs="?", default=".")
        p.set_defaults(func=cmd_orphans)

    export = sub.add_parser("export", help="Export a collection", description="Export a collection")
    export.add_argument("--output")
    export.add_argument("directory", nargs="?", default=".")
    export.set_defaults(func=cmd_export)
    return parser


def main(argv=None):
    parser = build_parser()
    args = parser.parse_args(argv)
    return args.func(args)


if __name__ == "__main__":
    sys.exit(main())
