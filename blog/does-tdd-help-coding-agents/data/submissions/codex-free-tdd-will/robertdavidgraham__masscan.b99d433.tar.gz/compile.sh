#!/bin/bash
set -e
cp masscan.py executable
chmod +x executable
