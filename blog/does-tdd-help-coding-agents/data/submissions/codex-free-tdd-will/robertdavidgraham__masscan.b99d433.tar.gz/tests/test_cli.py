import os
import re
import subprocess
import sys
import unittest
import tempfile


ROOT = os.path.dirname(os.path.dirname(__file__))
EXE = os.path.join(ROOT, "masscan.py")


def run_cli(*args):
    return subprocess.run(
        [sys.executable, EXE, *args],
        cwd=ROOT,
        text=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
    )


def normalize_seed(text):
    return re.sub(r"seed = \d+", "seed = <seed>", text)


class MasscanCliTests(unittest.TestCase):
    def test_version_reports_masscan_identity(self):
        result = run_cli("--version")
        self.assertEqual(result.returncode, 1)
        self.assertIn("Masscan version 1.3.9-integration", result.stdout)
        self.assertIn("OS: Linux", result.stdout)

    def test_echo_prints_selected_ports_range_and_rate(self):
        result = run_cli("10.0.0.0/30", "-p80", "--rate", "10", "--echo")
        self.assertEqual(result.returncode, 0)
        self.assertEqual(
            normalize_seed(result.stdout),
            "[-] FAIL: failed to load libpcap shared library\n"
            "    [hint]: you must install libpcap or WinPcap\n"
            "seed = <seed>\n"
            "rate = 10        \n"
            "shard = 1/1\n"
            "nocapture = servername\n"
            "nocapture = servername\n"
            "\n"
            "\n"
            "# TARGET SELECTION (IP, PORTS, EXCLUDES)\n"
            "ports = 80\n"
            "range = 10.0.0.0/30\n",
        )

    def test_echo_reads_config_file_and_normalizes_common_values(self):
        with tempfile.NamedTemporaryFile("w", delete=False, dir=ROOT) as handle:
            handle.write(
                "rate =  100000.00\n"
                "output-format = xml\n"
                "output-filename = scan.xml\n"
                "ports = 0-65535\n"
                "range = 0.0.0.0-255.255.255.255\n"
                "adapter-mac = aa:bb:cc:dd:ee:ff\n"
            )
            path = handle.name
        try:
            result = run_cli("-c", path, "--echo")
        finally:
            os.unlink(path)
        self.assertEqual(result.returncode, 0)
        output = normalize_seed(result.stdout)
        self.assertIn("rate = 100000.000000\n", output)
        self.assertIn("output-filename = scan.xml\noutput-format = xml\n", output)
        self.assertIn("adapter-mac = aa-bb-cc-dd-ee-ff\n", output)
        self.assertIn("range = 0.0.0.0/0\n", output)

    def test_readscan_missing_file_reports_error_but_exits_successfully(self):
        result = run_cli("--readscan", "missing.scan", "-oL", "-")
        self.assertEqual(result.returncode, 0)
        self.assertIn("[-] FAIL: --readscan\n", result.stdout)
        self.assertIn("[-] missing.scan: No such file or directory\n", result.stdout)


if __name__ == "__main__":
    unittest.main()
