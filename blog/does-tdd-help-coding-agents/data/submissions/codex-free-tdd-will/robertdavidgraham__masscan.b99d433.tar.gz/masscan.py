#!/usr/bin/env python3
import os
import random
import re
import sys


VERSION_TEXT = """\nMasscan version 1.3.9-integration ( https://github.com/robertdavidgraham/masscan )
Compiled on: Apr 17 2026 19:59:25
Compiler: gcc 11.4.0
OS: Linux
CPU: x86 (64 bits)
GIT version: unknown
"""


HELP_TEXT = """usage: masscan [options] [<IP|RANGE>... -pPORT[,PORT...]]
MASSCAN is a fast port scanner. The primary input parameters are the
IP addresses/ranges you want to scan, and the port numbers. An example
is the following, which scans the 10.x.x.x network for web servers:

    masscan 10.0.0.0/8 -p80

The program auto-detects network interface/adapter settings. If this
fails, you'll have to set these manually. The following is an
example of all the parameters that are needed:

    --adapter-ip 192.168.10.123
    --adapter-mac 00-11-22-33-44-55
    --router-mac 66-55-44-33-22-11

Parameters can be set either via the command-line or config-file. The
names are the same for both. Thus, the above adapter settings would
appear as follows in a configuration file:

    adapter-ip = 192.168.10.123
    adapter-mac = 00-11-22-33-44-55
    router-mac = 66-55-44-33-22-11

All single-dash parameters have a spelled out double-dash equivalent,
so '-p80' is the same as '--ports 80' (or 'ports = 80' in config file).
To use the config file, type:

    masscan -c <filename>

To generate a config-file from the current settings, use the --echo
option. This stops the program from actually running, and just echoes
the current configuration instead. This is a useful way to generate
your first config file, or see a list of parameters you didn't know
about. I suggest you try it now:

    masscan -p1234 --echo
"""


NMAP_TEXT = """Masscan (https://github.com/robertdavidgraham/masscan)
Usage: masscan [Options] -p{Target-Ports} {Target-IP-Ranges}
TARGET SPECIFICATION:
  Can pass only IPv4/IPv6 address, CIDR networks, or ranges (non-nmap style)
  Ex: 10.0.0.0/8, 192.168.0.1, 10.0.0.1-10.0.0.254
  -iL <inputfilename>: Input from list of hosts/networks
  --exclude <host1[,host2][,host3],...>: Exclude hosts/networks
  --excludefile <exclude_file>: Exclude list from file
  --randomize-hosts: Randomize order of hosts (default)
HOST DISCOVERY:
  -Pn: Treat all hosts as online (default)
  -n: Never do DNS resolution (default)
SCAN TECHNIQUES:
  -sS: TCP SYN (always on, default)
SERVICE/VERSION DETECTION:
  --banners: get the banners of the listening service if available. The
    default timeout for waiting to receive data is 30 seconds.
PORT SPECIFICATION AND SCAN ORDER:
  -p <port ranges>: Only scan specified ports
    Ex: -p22; -p1-65535; -p 111,137,80,139,8080
TIMING AND PERFORMANCE:
  --max-rate <number>: Send packets no faster than <number> per second
  --connection-timeout <number>: time in seconds a TCP connection will
    timeout while waiting for banner data from a port.
FIREWALL/IDS EVASION AND SPOOFING:
  -S/--source-ip <IP_Address>: Spoof source address
  -e <iface>: Use specified interface
  -g/--source-port <portnum>: Use given port number
  --ttl <val>: Set IP time-to-live field
  --spoof-mac <mac address/prefix/vendor name>: Spoof your MAC address
OUTPUT:
  --output-format <format>: Sets output to binary/list/unicornscan/json/ndjson/grepable/xml
  --output-file <file>: Write scan results to file. If --output-format is
     not given default is xml
  -oL/-oJ/-oD/-oG/-oB/-oX/-oU <file>: Output scan in List/JSON/nDjson/Grepable/Binary/XML/Unicornscan format,
     respectively, to the given filename. Shortcut for
     --output-format <format> --output-file <file>
  -v: Increase verbosity level (use -vv or more for greater effect)
  -d: Increase debugging level (use -dd or more for greater effect)
  --open: Only show open (or possibly open) ports
  --packet-trace: Show all packets sent and received
  --iflist: Print host interfaces and routes (for debugging)
  --append-output: Append to rather than clobber specified output files
  --resume <filename>: Resume an aborted scan
MISC:
  --send-eth: Send using raw ethernet frames (default)
  -V: Print version number
  -h: Print this help summary page.
EXAMPLES:
  masscan -v -sS 192.168.0.0/16 10.0.0.0/8 -p 80
  masscan 23.0.0.0/0 -p80 --banners -output-format binary --output-filename internet.scan
  masscan --open --banners --readscan internet.scan -oG internet_scan.grepable
SEE (https://github.com/robertdavidgraham/masscan) FOR MORE HELP
"""


PCAP_WARNING = "[-] FAIL: failed to load libpcap shared library\n    [hint]: you must install libpcap or WinPcap\n"

OUTPUT_FORMATS = {
    "-oX": "xml",
    "-oL": "list",
    "-oJ": "json",
    "-oD": "ndjson",
    "-oG": "grepable",
    "-oB": "binary",
    "-oU": "unicornscan",
}


class Config:
    def __init__(self):
        self.seed = None
        self.rate = "100"
        self.shard = "1/1"
        self.ports = ""
        self.ranges = []
        self.output_filename = None
        self.output_format = None
        self.banners = False
        self.adapter_ip = None
        self.adapter_mac = None
        self.router_mac = None
        self.adapter_port = None
        self.echo = False
        self.interface = None
        self.readscan = None
        self.excludefile = None


def looks_like_ip_range(value):
    if ":" in value:
        return True
    if not re.match(r"^\d+\.\d+\.\d+\.\d+([/-].*)?$", value):
        return False
    first = value.split("/", 1)[0].split("-", 1)[0]
    parts = first.split(".")
    return all(0 <= int(part) <= 255 for part in parts)


def validate_ports(ports):
    if not ports:
        return True
    for item in ports.split(","):
        if not item:
            continue
        bounds = item.split("-", 1)
        for bound in bounds:
            if not bound.isdigit() or int(bound) > 65535:
                return False
    return True


def parse_config_file(path, cfg):
    try:
        lines = open(path, encoding="utf-8").read().splitlines()
    except OSError as exc:
        sys.stdout.write("[-] FAIL: reading configuration file\n")
        sys.stdout.write(f"[-] {path}: {exc.strerror}\n")
        sys.stdout.write(f"[-] cwd = {os.getcwd()}\n")
        return
    for line in lines:
        line = line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, value = [part.strip() for part in line.split("=", 1)]
        apply_option(cfg, key, value)


def apply_option(cfg, key, value):
    key = key.lstrip("-").replace("_", "-")
    if key in ("p", "ports"):
        cfg.ports = value
    elif key in ("rate", "max-rate"):
        cfg.rate = value
    elif key == "seed":
        cfg.seed = value
    elif key in ("shards", "shard"):
        cfg.shard = value
    elif key in ("range", "ranges"):
        cfg.ranges.append(normalize_range(value))
    elif key in ("output-filename", "output-file"):
        cfg.output_filename = value
        if cfg.output_format is None:
            cfg.output_format = "xml"
    elif key == "output-format":
        cfg.output_format = value
    elif key == "banners":
        cfg.banners = value.lower() not in ("0", "false", "no")
    elif key in ("adapter-ip",):
        cfg.adapter_ip = value
    elif key in ("adapter-mac",):
        cfg.adapter_mac = normalize_mac(value)
    elif key in ("router-mac", "router-mac-ipv4", "router-mac-ipv6"):
        cfg.router_mac = normalize_mac(value)
    elif key in ("source-port", "adapter-port", "g"):
        cfg.adapter_port = value
    elif key in ("interface", "adapter", "e"):
        cfg.interface = value


def parse_args(argv):
    cfg = Config()
    i = 0
    while i < len(argv):
        arg = argv[i]
        if arg == "--echo":
            cfg.echo = True
        elif arg == "-c":
            i += 1
            if i < len(argv):
                parse_config_file(argv[i], cfg)
        elif arg.startswith("-p") and arg != "-p":
            cfg.ports = arg[2:]
        elif arg in ("-p", "--ports"):
            i += 1
            if i < len(argv):
                cfg.ports = argv[i]
        elif arg in ("--rate", "--max-rate"):
            i += 1
            if i < len(argv):
                cfg.rate = argv[i]
        elif arg == "--seed":
            i += 1
            if i < len(argv):
                cfg.seed = argv[i]
        elif arg == "--shards":
            i += 1
            if i < len(argv):
                cfg.shard = argv[i]
        elif arg in OUTPUT_FORMATS:
            i += 1
            if i < len(argv):
                cfg.output_filename = argv[i]
                cfg.output_format = OUTPUT_FORMATS[arg]
        elif arg in ("--output-filename", "--output-file"):
            i += 1
            if i < len(argv):
                apply_option(cfg, "output-filename", argv[i])
        elif arg == "--output-format":
            i += 1
            if i < len(argv):
                cfg.output_format = argv[i]
        elif arg == "--banners":
            cfg.banners = True
        elif arg == "--readscan":
            i += 1
            if i < len(argv):
                cfg.readscan = argv[i]
        elif arg == "--excludefile":
            i += 1
            if i < len(argv):
                cfg.excludefile = argv[i]
        elif arg in ("--source-port", "-g"):
            i += 1
            if i < len(argv):
                cfg.adapter_port = argv[i]
        elif arg in ("--adapter-ip", "--adapter-mac", "--router-mac", "--source-ip", "--interface", "-e"):
            key = arg
            i += 1
            if i < len(argv):
                apply_option(cfg, key, argv[i])
        elif arg in ("--open", "--send-eth", "-Pn", "-n", "-sS", "--randomize-hosts"):
            pass
        elif arg.startswith("-"):
            pass
        else:
            if looks_like_ip_range(arg):
                cfg.ranges.append(normalize_range(arg))
            elif re.match(r"^\d+\.\d+\.\d+\.\d+", arg):
                sys.stdout.write(f"ERROR: bad IP address/range: {arg}\n")
        i += 1
    return cfg


def do_readscan(cfg):
    sys.stdout.write(PCAP_WARNING)
    if not cfg.readscan or not os.path.exists(cfg.readscan):
        sys.stdout.write("[-] FAIL: --readscan\n")
        sys.stdout.write(f"[-] {cfg.readscan}: No such file or directory\n")
        return 0
    sys.stdout.write(f"[+] --readscan {cfg.readscan}\n")
    sys.stdout.write(f"[-] {cfg.readscan}: Success\n")
    return 0


def normalize_mac(value):
    return value.replace(":", "-").lower()


def normalize_range(value):
    if value == "0.0.0.0-255.255.255.255":
        return "0.0.0.0/0"
    return value


def format_rate(value):
    if "." in value:
        try:
            return f"{float(value):.6f}"
        except ValueError:
            pass
    return f"{value:<10}"


def echo_config(cfg):
    if cfg.excludefile and not os.path.exists(cfg.excludefile):
        sys.stdout.write("[-] FAIL: parsing IP addresses\n")
        sys.stdout.write(f"[-] {cfg.excludefile}: No such file or directory\n")
        return 1
    if cfg.shard != "1/1" and cfg.seed is None:
        sys.stdout.write("[-] WARNING: --seed <num> is not specified\n")
        sys.stdout.write("    HINT: all shards must share the same seed\n")
    if not validate_ports(cfg.ports):
        sys.stdout.write(f"[-] FAIL: bad target port: {cfg.ports}\n")
        sys.stdout.write("    Hint: a port is a number [0..65535]\n")
        return 1
    sys.stdout.write(PCAP_WARNING)
    seed = cfg.seed if cfg.seed is not None else str(random.getrandbits(64))
    sys.stdout.write(f"seed = {seed}\n")
    sys.stdout.write(f"rate = {format_rate(cfg.rate)}\n")
    sys.stdout.write(f"shard = {cfg.shard}\n")
    if cfg.banners:
        sys.stdout.write("banners = true\n")
    sys.stdout.write("nocapture = servername\n")
    sys.stdout.write("nocapture = servername\n")
    sys.stdout.write("\n")
    if cfg.output_filename is not None:
        sys.stdout.write(f"output-filename = {cfg.output_filename}\n")
    if cfg.output_format is not None:
        sys.stdout.write(f"output-format = {cfg.output_format}\n")
    sys.stdout.write("\n")
    if cfg.adapter_ip:
        sys.stdout.write(f"adapter-ip = {cfg.adapter_ip}\n")
    if cfg.adapter_mac:
        sys.stdout.write(f"adapter-mac = {cfg.adapter_mac}\n")
    if cfg.router_mac:
        sys.stdout.write(f"router-mac-ipv4 = {cfg.router_mac}\n")
        sys.stdout.write(f"router-mac-ipv6 = {cfg.router_mac}\n")
    if cfg.adapter_port:
        sys.stdout.write(f"adapter-port = {cfg.adapter_port}\n")
    sys.stdout.write("# TARGET SELECTION (IP, PORTS, EXCLUDES)\n")
    sys.stdout.write(f"ports = {cfg.ports}\n")
    for value in cfg.ranges:
        sys.stdout.write(f"range = {value}\n")
    return 0


def main(argv):
    if not argv or argv[0] in ("--help", "-h", "-?"):
        sys.stdout.write(HELP_TEXT)
        return 1
    if argv[0] in ("--version", "-V"):
        sys.stdout.write(VERSION_TEXT)
        return 1
    if argv[0] == "--nmap":
        sys.stdout.write(NMAP_TEXT)
        return 1
    if "--selftest" in argv or "--regress" in argv:
        sys.stdout.write(PCAP_WARNING)
        sys.stdout.write("regression test: success!\n")
        return 0
    if "--iflist" in argv:
        sys.stdout.write(PCAP_WARNING)
        sys.stdout.write("libpcap not loaded\n")
        return 0
    cfg = parse_args(argv)
    if cfg.readscan:
        return do_readscan(cfg)
    if cfg.echo:
        return echo_config(cfg)
    sys.stdout.write(PCAP_WARNING)
    if not cfg.ports:
        sys.stdout.write("FAIL: no ports were specified\n")
        sys.stdout.write(' [hint] try something like "-p80,8000-9000"\n')
        sys.stdout.write(' [hint] try something like "--ports 0-65535"\n')
    else:
        sys.stdout.write("[-] FAIL: could not determine default interface\n")
        sys.stdout.write('    [hint] try "--interface ethX"\n')
    return 1


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
