#!/usr/bin/env python3
import os
import inspect
import subprocess
import textwrap
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
BIN = ROOT / "executable"
PLUGIN_ERROR = "Failed to open plugins.json file. PLUGIN_PATH: /home/agent/.DataSurgeon/plugins.json"


def run_cmd(args, stdin=None):
    return subprocess.run(
        [str(BIN), *args],
        input=stdin,
        text=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        cwd=ROOT,
        check=False,
    )


def assert_lines(result, expected_stdout):
    assert result.stderr == ""
    assert result.stdout.splitlines() == [PLUGIN_ERROR, *expected_stdout]
    assert result.returncode == 0


def test_clean_email_defaults_to_first_match_per_line(tmp_path):
    sample = ROOT / "sample_test.txt"
    sample.write_text("one alice@example.com two bob@example.org\n")
    result = run_cmd(["-e", "-C", "-f", str(sample)])
    assert_lines(result, ["email: alice@example.com"])


def test_thorough_clean_extracts_all_selected_types(tmp_path):
    sample = ROOT / "sample_test.txt"
    sample.write_text(textwrap.dedent("""\
        email alice@example.com bob@example.org
        ip 10.0.0.1 and 8.8.8.8
        url http://example.com and https://sub.example.org/x
    """))
    result = run_cmd(["-e", "-i", "-u", "-C", "-T", "-f", str(sample)])
    assert_lines(result, [
        "email: alice@example.com",
        "email: bob@example.org",
        "ip_address: 10.0.0.1",
        "ip_address: 8.8.8.8",
        "url: http://example.com",
        "url: https://sub.example.org/x",
    ])


def test_display_line_and_hide_formatting(tmp_path):
    sample = ROOT / "sample_test.txt"
    sample.write_text("prefix alice@example.com\n")
    result = run_cmd(["-e", "-C", "-D", "-X", "-l", "-f", str(sample)])
    assert_lines(result, [f"file: {sample} alice@example.com, line: 1"])


def test_stdin_message_can_be_suppressed():
    result = run_cmd(["-e", "-S"], stdin="alice@example.com\n")
    assert_lines(result, ["email: alice@example.com"])


def test_drop_filters_cleaned_match():
    sample = ROOT / "sample_test.txt"
    sample.write_text("alice@example.com\nbob@example.org\n")
    result = run_cmd(["-e", "-C", "-T", "--drop", "bob", "-f", str(sample)])
    assert_lines(result, ["email: alice@example.com"])


def test_output_csv(tmp_path):
    sample = ROOT / "sample_test.txt"
    out = ROOT / "out_test.csv"
    sample.write_text("alice@example.com\n10.0.0.1\n")
    if out.exists():
        out.unlink()
    result = run_cmd(["-e", "-i", "-C", "-f", str(sample), "-o", str(out)])
    assert_lines(result, [])
    assert out.read_text().splitlines() == [
        "content_type, data",
        "email, alice@example.com",
        "ip_address, 10.0.0.1",
    ]


def test_reference_detector_edge_cases():
    sample = ROOT / "sample_test.txt"
    sample.write_text(textwrap.dedent("""\
        phone 555-123-4567 and (212) 555-9876
        file report.pdf and archive.tar.gz
        ipv6 aa:bb:cc:dd:ee:ff and fe80::1ff:fe23:4567:890a
        aws_access_key_id = AKIAIOSFODNN7EXAMPLE
    """))
    phone = run_cmd(["-p", "-C", "-T", "-f", str(sample)])
    assert_lines(phone, ["phone_number: 555-123-4567"])
    files = run_cmd(["-F", "-C", "-T", "-f", str(sample)])
    assert_lines(files, ["files: file report.pdf", "files:  and archive.tar"])
    ipv6 = run_cmd(["-6", "-C", "-T", "-f", str(sample)])
    assert_lines(ipv6, [
        "ipv6_address: aa:bb:cc:dd:ee:ff",
        "ipv6_address: fe80::1ff",
        "ipv6_address: fe23:4567:890a",
    ])
    aws = run_cmd(["-a", "-C", "-T", "-f", str(sample)])
    assert_lines(aws, ["aws_keys: aws_access_key_id = AKIAIOSFODNN7EXAMPLE"])


def test_no_detector_flags_searches_builtin_patterns_and_stops_per_line():
    result = run_cmd(["-S", "-C"], stdin="alice@example.com 10.0.0.1 http://x.com\n")
    assert_lines(result, ["email: alice@example.com"])


def main():
    tests = [value for name, value in sorted(globals().items()) if name.startswith("test_")]
    for test in tests:
        if inspect.signature(test).parameters:
            test(None)
        else:
            test()
    print(f"{len(tests)} tests passed")


if __name__ == "__main__":
    main()
