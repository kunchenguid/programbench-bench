#!/bin/bash
set -e
./compile.sh
python3 tests/test_cli.py
