#!/usr/bin/env python3
import argparse
import os
import re
import sys
import time
from pathlib import Path


PLUGIN_ERROR = "Failed to open plugins.json file. PLUGIN_PATH: /home/agent/.DataSurgeon/plugins.json"
STDIN_MSG = "[*] Reading standard input. If you meant to analyze a file use 'ds -f <FILE>' (ctrl+c to exit)"


def build_parser():
    parser = argparse.ArgumentParser(prog="executable", add_help=False)
    parser.add_argument("-f", "--file", default="")
    parser.add_argument("--add", default="")
    parser.add_argument("--update", default="")
    parser.add_argument("--remove", default="")
    parser.add_argument("--list", action="store_true")
    parser.add_argument("-C", "--clean", action="store_true")
    parser.add_argument("--directory", default="")
    parser.add_argument("--ignore", action="store_true")
    parser.add_argument("-l", "--line", action="store_true")
    parser.add_argument("-T", "--thorough", action="store_true")
    parser.add_argument("-D", "--display", action="store_true")
    parser.add_argument("-S", "--suppress", action="store_true")
    parser.add_argument("--drop", default="")
    parser.add_argument("--filter", default="")
    parser.add_argument("-X", "--hide", action="store_true")
    parser.add_argument("-o", "--output", default="")
    parser.add_argument("-t", "--time", action="store_true")
    parser.add_argument("-e", "--email", action="store_true")
    parser.add_argument("-p", "--phone", action="store_true")
    parser.add_argument("-H", "--hash", action="store_true")
    parser.add_argument("-i", "--ip-addr", action="store_true")
    parser.add_argument("-6", "--ipv6-addr", action="store_true")
    parser.add_argument("-m", "--mac-addr", action="store_true")
    parser.add_argument("-c", "--credit-card", action="store_true")
    parser.add_argument("-u", "--url", action="store_true")
    parser.add_argument("-F", "--files", action="store_true")
    parser.add_argument("-b", "--bitcoin", action="store_true")
    parser.add_argument("-a", "--aws", action="store_true")
    parser.add_argument("-g", "--google", action="store_true")
    parser.add_argument("-d", "--dns", action="store_true")
    parser.add_argument("-s", "--social", action="store_true")
    parser.add_argument("-h", "--help", action="store_true")
    parser.add_argument("-V", "--version", action="store_true")
    return parser


PATTERNS = [
    ("email", "email", re.compile(r"[A-Za-z0-9._%+\-]+@[A-Za-z0-9.\-]+\.[A-Za-z]{2,}")),
    ("phone", "phone_number", re.compile(r"\b\d{3}-\d{3}-\d{4}\b")),
    ("hash", "hashes", re.compile(r"\b(?:[A-Fa-f0-9]{32}|[A-Fa-f0-9]{40}|[A-Fa-f0-9]{56}|[A-Fa-f0-9]{64}|[A-Fa-f0-9]{96}|[A-Fa-f0-9]{128})\b")),
    ("url", "url", re.compile(r"https?://[^\s<>'\"]+")),
    ("ip_addr", "ip_address", re.compile(r"\b(?:(?:25[0-5]|2[0-4]\d|1?\d?\d)\.){3}(?:25[0-5]|2[0-4]\d|1?\d?\d)\b")),
    ("ipv6_addr", "ipv6_address", re.compile(r"\b(?:[A-Fa-f0-9]{1,4}::[A-Fa-f0-9]{1,4}|(?:[A-Fa-f0-9]{1,4}:){2,7}[A-Fa-f0-9]{0,4})\b")),
    ("mac_addr", "mac_address", re.compile(r"\b[0-9A-Fa-f]{2}(?::[0-9A-Fa-f]{2}){5}\b")),
    ("credit_card", "credit_card", re.compile(r"\b(?:\d{4}[ -]){3}\d{4}\b")),
    ("files", "files", re.compile(r"[A-Za-z0-9_ -]+\.(?:txt|csv|pdf|docx?|xlsx?|pptx?|zip|tar|jpg|jpeg|png|gif|exe|dll|log|json|xml|html?|php|py|rs|go|c|cpp|h)\b")),
    ("bitcoin", "bitcoin_wallet", re.compile(r"\b(?:bc1|[13])[a-zA-HJ-NP-Z0-9]{25,62}\b")),
    ("aws", "aws_keys", re.compile(r"aws_access_key_id\s*=\s*(?:AKIA|ASIA)[A-Z0-9]{16}")),
    ("google", "google", re.compile(r"private_key_id[\"':\s]+([a-fA-F0-9]{40})")),
    ("dns", "dns", re.compile(r"\b(?:[A-Za-z0-9](?:[A-Za-z0-9\-]{0,61}[A-Za-z0-9])?\.)+[A-Za-z]{2,63}\b")),
    ("social", "social_security", re.compile(r"\b\d{3}-\d{2}-\d{4}\b")),
]


HELP = """Note: All extraction features (e.g: -i) work on a specified file (-f) or an output stream.

Usage: executable [OPTIONS]

Options:
  -f, --file <file>            File to extract information from [default: ""]
      --add <add>              Adds a plugin from a GitHub repository (e.g ds --add https://github.com/Drew-Alleman/ds-winreg-plugin/) [default: ""]
      --update <update>        Updates a plugin from a GitHub repository. You can also use `ds --update all` to update all plugins. (e.g ds --update https://github.com/DataSurgeon-ds/ds-cve-plugin/) [default: ""]
      --remove <remove>        Removes a plugin from a GitHub repository (e.g ds --remove https://github.com/Drew-Alleman/ds-winreg-plugin/) [default: ""]
      --list                   List all added plugins
  -C, --clean                  Only displays the matched result, rather than the entire line
      --directory <directory>  Process all files found in the specified directory [default: ""]
      --ignore                 Silences error messages
  -l, --line                   Displays the line number where the match occurred
  -T, --thorough               Doesn't stop at first match (useful for -C if multiple unique matches are on the same line
  -D, --display                Displays the filename assoicated with the content found (https://github.com/Drew-Alleman/DataSurgeon#reading-all-files-in-a-directory)
  -S, --suppress               Suppress the 'Reading standard input' message when not providing a file
      --drop <drop>            Specify a regular expression to exclude certain patterns from the search. (e.g --drop "^.{1,10}$" will hide all matches not under 10 characters) [default: ""]
      --filter <filter>        Include only lines that match the specified regex. (e.g: '--filter ^error' will only include lines that start with the word 'error' [default: ""]
  -X, --hide                   Hides the identifier string infront of the desired content (e.g: 'hash: ', 'url: ', 'email: ' will not be displayed.
  -o, --output <output>        Output's the results of the procedure to a local file (recommended for large files) [default: ""]
  -t, --time                   Time how long the operation took
  -e, --email                  Extract email addresses
  -p, --phone                  Extracts phone numbers
  -H, --hash                   Extract hashes (NTLM, LM, bcrypt, Oracle, MD5, SHA-1, SHA-224, SHA-256, SHA-384, SHA-512, SHA3-224, SHA3-256, SHA3-384, SHA3-512, MD4)
  -i, --ip-addr                Extract IP addresses
  -6, --ipv6-addr              Extract IPv6 addresses
  -m, --mac-addr               Extract MAC addresses
  -c, --credit-card            Extract credit card numbers
  -u, --url                    Extract urls
  -F, --files                  Extract filenames
  -b, --bitcoin                Extract bitcoin wallets
  -a, --aws                    Extract AWS keys
  -g, --google                 Extract Google service account private key ids (used for google automations services)
  -d, --dns                    Extract Domain Name System records
  -s, --social                 Extract social security numbers
  -h, --help                   Print help
  -V, --version                Print version"""


def selected_patterns(args):
    out = []
    for attr, label, regex in PATTERNS:
        if getattr(args, attr):
            out.append((label, regex))
    if out:
        return out
    return [(label, regex) for _attr, label, regex in PATTERNS]


def emit_plugin_error(args):
    if not args.ignore:
        print(PLUGIN_ERROR)


def content_for_match(line, match, clean):
    if clean:
        if match.lastindex:
            return next(g for g in match.groups() if g is not None)
        return match.group(0)
    return line.rstrip("\n")


def find_records(args, inputs):
    records = []
    filter_re = re.compile(args.filter) if args.filter else None
    drop_re = re.compile(args.drop) if args.drop else None
    patterns = selected_patterns(args)
    for filename, text in inputs:
        for lineno, line in enumerate(text.splitlines(), 1):
            emitted_for_line = False
            for label, regex in patterns:
                if emitted_for_line and not args.thorough:
                    break
                matches = list(regex.finditer(line))
                if not matches:
                    continue
                if not args.thorough:
                    matches = matches[:1]
                for match in matches:
                    data = content_for_match(line, match, args.clean)
                    if filter_re and not filter_re.search(data):
                        continue
                    if drop_re and drop_re.search(data):
                        continue
                    records.append((label, data, filename, lineno))
                    emitted_for_line = True
                    if not args.thorough:
                        break
                if not args.clean:
                    break
    return records


def format_record(args, label, data, filename, lineno):
    if args.output:
        return None
    prefix = ""
    if not args.hide:
        prefix = f"{label}: " if not (args.display or args.line) else f"{label}, "
    if args.display:
        prefix += f"file: {filename} "
    line = prefix + data
    if args.line:
        line += f", line: {lineno}"
    return line


def read_inputs(args):
    if args.directory:
        root = Path(args.directory)
        if not root.exists():
            if not args.ignore:
                print(f"[-] Directory not found: {args.directory}")
            return []
        files = sorted([p for p in root.rglob("*") if p.is_file()], reverse=True)
        inputs = []
        for path in files:
            try:
                inputs.append((str(path), path.read_text(errors="ignore")))
            except OSError as exc:
                if not args.ignore:
                    print(f"[-] Failed to read file: {path}: {exc}")
        return inputs
    if args.file:
        path = Path(args.file)
        if not path.exists():
            if not args.ignore:
                print(f"[-] File not found: {args.file}")
            return []
        return [(args.file, path.read_text(errors="ignore"))]
    if not args.suppress:
        print(STDIN_MSG)
    return [("", sys.stdin.read())]


def write_output(path, records):
    with open(path, "w") as fh:
        fh.write("content_type, data\n")
        for label, data, _filename, _lineno in records:
            fh.write(f"{label}, {data}\n")


def handle_plugins(args):
    if args.list:
        print(PLUGIN_ERROR)
        print("No plugins found. Plugin File: /home/agent/.DataSurgeon/plugins.json")
        return 0
    for op in ("add", "update", "remove"):
        value = getattr(args, op)
        if value:
            if op == "add":
                print(f"[-] Error: Failed to parse plugins.json from the provided URL. Reason: error sending request for url ({value.rstrip('/')}/main/plugins.json): error trying to connect: dns error: failed to lookup address information: Temporary failure in name resolution")
            else:
                print(PLUGIN_ERROR)
            return 1
    return None


def main(argv=None):
    argv = sys.argv[1:] if argv is None else argv
    parser = build_parser()
    try:
        args = parser.parse_args(argv)
    except SystemExit as exc:
        emit_plugin_error(argparse.Namespace(ignore=False))
        return int(exc.code)
    emit_plugin_error(args)
    if args.help:
        print(HELP)
        return 0
    if args.version:
        print("DataSurgeon: https://github.com/Drew-Alleman/DataSurgeon 1.2.8")
        return 0
    plugin_result = handle_plugins(args)
    if plugin_result is not None:
        return plugin_result
    start = time.monotonic()
    records = find_records(args, read_inputs(args))
    if args.output:
        write_output(args.output, records)
    else:
        for record in records:
            line = format_record(args, *record)
            if line is not None:
                print(line)
    if args.time:
        elapsed = time.monotonic() - start
        print(f"Operation completed in {elapsed:.2f} seconds")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
