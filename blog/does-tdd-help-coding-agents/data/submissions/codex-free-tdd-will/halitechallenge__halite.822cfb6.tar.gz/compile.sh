#!/bin/bash
set -e
rm -f executable
cp src/halite.py executable
chmod +x executable
