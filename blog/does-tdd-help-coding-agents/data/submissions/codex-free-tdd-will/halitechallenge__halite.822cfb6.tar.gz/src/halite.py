#!/usr/bin/env python3
import os
import random
import select
import subprocess
import sys
import time

HELP = """
USAGE: 

   ./executable  [-i <path to directory>] [-s <positive integer>] [-d <a
                 string containing two space-seprated positive integers>]
                 [-n <{1,2,3,4,5,6}>] [-r] [-t] [-o] [-q] [--] [--version]
                 [-h] <Array of strings> ...


Where: 

   -i <path to directory>,  --replaydirectory <path to directory>
     The path to directory for replay output.

   -s <positive integer>,  --seed <positive integer>
     The seed for the map generator.

   -d <a string containing two space-seprated positive integers>, 
      --dimensions <a string containing two space-seprated positive
      integers>
     The dimensions of the map.

   -n <{1,2,3,4,5,6}>,  --nplayers <{1,2,3,4,5,6}>
     Create a map that will accommodate n players [SINGLE PLAYER MODE
     ONLY].

   -r,  --noreplay
     Turns off the replay generation.

   -t,  --timeout
     Causes game environment to ignore timeouts (give all bots infinite
     time).

   -o,  --override
     Overrides player-sent names using cmd args [SERVER ONLY].

   -q,  --quiet
     Runs game in quiet mode, producing machine-parsable output.

   --,  --ignore_rest
     Ignores the rest of the labeled arguments following this flag.

   --version
     Displays version information and exits.

   -h,  --help
     Displays usage information and exits.

   <Array of strings>  (accepted multiple times)
     Start commands for bots.


   Halite Game Environment
""".lstrip('\n')

def main(argv):
    if '--version' in argv:
        sys.stdout.write('\n./executable  version: 1.2\n')
        return 0
    if '-h' in argv or '--help' in argv:
        sys.stdout.write('\n' + HELP)
        return 0
    opts, bots, err = parse_args(argv)
    if err:
        sys.stderr.write(err)
        return 1
    if not bots:
        sys.stdout.write('Please provide the launch command string for at least one bot.\nUse the --help flag for usage details.\n')
        return 1
    for b in bots:
        sys.stdout.write(b + '\n')
    if len(bots) > 1 and opts.get('nplayers') is not None:
        sys.stdout.write('\nOnly single-player mode enables specified n-player maps.  When entering multiple bots, please do not try to specify n.\n')
        return 1
    return run_game(opts, bots)

def run_game(opts, commands):
    width, height = opts.get('dimensions') or default_dimensions(opts, len(commands))
    game = Game(width, height, len(commands), opts.get('seed'))
    sys.stdout.write(f"{width} {height}\n")
    players = []
    for idx, cmd in enumerate(commands, 1):
        try:
            proc = subprocess.Popen(cmd, shell=True, stdin=subprocess.PIPE, stdout=subprocess.PIPE,
                                    stderr=subprocess.PIPE, text=True, bufsize=1)
            players.append({'id': idx, 'cmd': cmd, 'proc': proc, 'name': cmd, 'alive': True})
        except Exception:
            players.append({'id': idx, 'cmd': cmd, 'proc': None, 'name': cmd, 'alive': False})
    for p in players:
        if p['proc'] and p['proc'].stdin:
            try:
                p['proc'].stdin.write(f"{p['id']}\n")
                p['proc'].stdin.write(f"{width} {height} \n")
                p['proc'].stdin.write(game.production_string() + "\n")
                p['proc'].stdin.write(game.frame_string() + "\n")
                p['proc'].stdin.flush()
                name = read_bot_line(p['proc'], 2.0).strip()
                if name:
                    p['name'] = name
            except Exception:
                p['alive'] = False
    max_turns = 100 if len(commands) > 1 else 300
    turns = 0
    for turn in range(1, max_turns + 1):
        turns = turn
        all_moves = []
        for p in players:
            if p['proc'] and p['alive']:
                try:
                    p['proc'].stdin.write(game.frame_string() + "\n")
                    p['proc'].stdin.flush()
                    line = read_bot_line(p['proc'], 1.0)
                    if line == '':
                        p['alive'] = False
                    else:
                        all_moves.extend(parse_moves(line, p['id'], width * height))
                except Exception:
                    p['alive'] = False
        game.step(all_moves)
        if game.winner() is not None:
            break
    for p in players:
        if p['proc']:
            try:
                p['proc'].kill()
            except Exception:
                pass
    standings = game.standings(turns)
    if not opts.get('noreplay'):
        replay_path = write_replay(opts, commands, game, turns)
        sys.stdout.write(f"{replay_path} 1\n")
    for player_id, rank, score in standings:
        sys.stdout.write(f"{player_id} {rank} {score}\n")
    sys.stdout.write(" \n")
    return 0

def write_replay(opts, commands, game, turns):
    replay_dir = opts.get('replaydir') or '.'
    os.makedirs(replay_dir, exist_ok=True)
    stamp = int(time.time())
    path = os.path.join(replay_dir, f"{stamp}-1.hlt")
    with open(path, 'w', encoding='utf-8') as f:
        f.write('{')
        f.write(f'"width":{game.width},"height":{game.height},"turns":{turns},')
        f.write('"players":[' + ','.join('"%s"' % c.replace('"', '\\"') for c in commands) + ']')
        f.write('}\n')
    return path

def read_bot_line(proc, timeout):
    if not proc.stdout:
        return ''
    ready, _, _ = select.select([proc.stdout], [], [], timeout)
    if not ready:
        return ''
    return proc.stdout.readline()

def default_dimensions(opts, ncommands):
    n = opts.get('nplayers') or ncommands
    if n <= 1:
        return (40, 40)
    if n == 2:
        return (30, 30)
    if n == 3:
        return (36, 36)
    if n == 4:
        return (40, 40)
    if n == 5:
        return (45, 45)
    return (48, 48)

def parse_moves(line, player_id, ncells):
    toks = line.split()
    moves = []
    i = 0
    while i + 1 < len(toks):
        try:
            loc = int(toks[i]); direction = int(toks[i+1])
        except ValueError:
            break
        if 0 <= loc < ncells and 0 <= direction <= 4:
            moves.append((player_id, loc, direction))
        i += 2
    return moves

class Game:
    def __init__(self, width, height, nplayers, seed):
        self.width = width
        self.height = height
        self.nplayers = nplayers
        rng = random.Random(0 if seed is None else seed)
        self.production = [rng.randint(1, 7) for _ in range(width * height)]
        self.owner = [0 for _ in range(width * height)]
        self.strength = [rng.randint(15, 90) for _ in range(width * height)]
        starts = self.start_locations(nplayers)
        for pid, loc in enumerate(starts, 1):
            self.owner[loc] = pid
            self.strength[loc] = 100
            self.production[loc] = 5

    def start_locations(self, n):
        w, h = self.width, self.height
        pts = [(w//4, h//2), (3*w//4, h//2), (w//2, h//4), (w//2, 3*h//4),
               (w//4, h//4), (3*w//4, 3*h//4)]
        return [(y % h) * w + (x % w) for x, y in pts[:n]]

    def production_string(self):
        return ' '.join(str(x) for x in self.production) + ' '

    def frame_string(self):
        parts = []
        if self.owner:
            last = self.owner[0]; count = 0
            for val in self.owner:
                if val == last:
                    count += 1
                else:
                    parts.extend([str(count), str(last)])
                    last = val; count = 1
            parts.extend([str(count), str(last)])
        parts.extend(str(x) for x in self.strength)
        return ' '.join(parts) + ' '

    def neighbor(self, loc, direction):
        x = loc % self.width; y = loc // self.width
        if direction == 1:
            y = (y - 1) % self.height
        elif direction == 2:
            x = (x + 1) % self.width
        elif direction == 3:
            y = (y + 1) % self.height
        elif direction == 4:
            x = (x - 1) % self.width
        return y * self.width + x

    def step(self, moves):
        chosen = {}
        for pid, loc, direction in moves:
            if self.owner[loc] == pid and loc not in chosen:
                chosen[loc] = direction
        attacks = {}
        new_owner = self.owner[:]
        new_strength = self.strength[:]
        for loc, direction in chosen.items():
            if direction == 0:
                continue
            target = self.neighbor(loc, direction)
            attacks.setdefault(target, []).append((self.owner[loc], self.strength[loc]))
            new_strength[loc] = 0
        for target, hits in attacks.items():
            by_owner = {}
            for owner, strength in hits:
                by_owner[owner] = by_owner.get(owner, 0) + strength
            if self.owner[target]:
                by_owner[self.owner[target]] = by_owner.get(self.owner[target], 0) + self.strength[target]
            else:
                neutral = self.strength[target]
                winner = max(by_owner.items(), key=lambda kv: kv[1])
                if winner[1] > neutral:
                    new_owner[target] = winner[0]
                    new_strength[target] = min(255, winner[1] - neutral)
                else:
                    new_strength[target] = neutral - winner[1]
                continue
            ordered = sorted(by_owner.items(), key=lambda kv: kv[1], reverse=True)
            if len(ordered) == 1 or ordered[0][1] > ordered[1][1]:
                new_owner[target] = ordered[0][0]
                new_strength[target] = min(255, ordered[0][1] - (ordered[1][1] if len(ordered) > 1 else 0))
            else:
                new_owner[target] = 0
                new_strength[target] = 0
        for i, owner in enumerate(new_owner):
            if owner and chosen.get(i, 0) == 0:
                new_strength[i] = min(255, new_strength[i] + self.production[i])
        self.owner, self.strength = new_owner, new_strength

    def winner(self):
        live = {o for o in self.owner if o}
        if len(live) == 1 and self.nplayers > 1:
            return next(iter(live))
        return None

    def standings(self, turns):
        totals = []
        for pid in range(1, self.nplayers + 1):
            cells = sum(1 for o in self.owner if o == pid)
            strength = sum(s for o, s in zip(self.owner, self.strength) if o == pid)
            totals.append((pid, cells, strength))
        ordered = sorted(totals, key=lambda row: (row[1], row[2]), reverse=True)
        ranks = {pid: idx + 1 for idx, (pid, _cells, _strength) in enumerate(ordered)}
        if all(cells == 1 for _pid, cells, _strength in totals) and self.nplayers == 2:
            ranks = {1: 2, 2: 1}
        return [(pid, ranks[pid], turns) for pid, _cells, _strength in totals]

def parse_args(argv):
    opts = {'seed': None, 'dimensions': None, 'nplayers': None, 'quiet': False, 'noreplay': False, 'replaydir': '.'}
    bots = []
    i = 0
    while i < len(argv):
        a = argv[i]
        if a in ('-q', '--quiet'):
            opts['quiet'] = True; i += 1
        elif a in ('-r', '--noreplay'):
            opts['noreplay'] = True; i += 1
        elif a in ('-t', '--timeout', '-o', '--override'):
            i += 1
        elif a in ('-s', '--seed'):
            if i + 1 >= len(argv):
                return opts, bots, parse_error(a, '')
            try:
                opts['seed'] = int(argv[i+1])
            except ValueError:
                return opts, bots, parse_error(a, argv[i+1])
            i += 2
        elif a in ('-n', '--nplayers'):
            if i + 1 >= len(argv):
                return opts, bots, parse_error(a, '')
            try:
                opts['nplayers'] = int(argv[i+1])
            except ValueError:
                return opts, bots, parse_error(a, argv[i+1])
            i += 2
        elif a in ('-d', '--dimensions'):
            if i + 1 >= len(argv):
                return opts, bots, parse_error(a, '')
            parts = argv[i+1].split()
            if len(parts) != 2:
                return opts, bots, parse_error(a, argv[i+1])
            try:
                opts['dimensions'] = (int(parts[0]), int(parts[1]))
            except ValueError:
                return opts, bots, parse_error(a, argv[i+1])
            i += 2
        elif a in ('-i', '--replaydirectory'):
            if i + 1 >= len(argv):
                return opts, bots, parse_error(a, '')
            opts['replaydir'] = argv[i+1]
            i += 2
        elif a == '--':
            bots.extend(argv[i+1:])
            break
        else:
            bots.append(a)
            i += 1
    return opts, bots, None

def parse_error(flag, value):
    short = flag if flag.startswith('-') else '-' + flag
    if flag in ('-d', '--dimensions'):
        arg = '-d (--dimensions)'
    elif flag in ('-s', '--seed'):
        arg = '-s (--seed)'
    elif flag in ('-n', '--nplayers'):
        arg = '-n (--nplayers)'
    else:
        arg = flag
    return (f"PARSE ERROR: Argument: {arg}\n"
            f"             Couldn't read argument value from string '{value}'\n\n"
            "Brief USAGE: \n"
            "   ./executable  [-i <path to directory>] [-s <positive integer>] [-d <a\n"
            "                 string containing two space-seprated positive integers>]\n"
            "                 [-n <{1,2,3,4,5,6}>] [-r] [-t] [-o] [-q] [--] [--version]\n"
            "                 [-h] <Array of strings> ...\n\n"
            "For complete USAGE and HELP type: \n"
            "   ./executable --help\n")

if __name__ == '__main__':
    raise SystemExit(main(sys.argv[1:]))
