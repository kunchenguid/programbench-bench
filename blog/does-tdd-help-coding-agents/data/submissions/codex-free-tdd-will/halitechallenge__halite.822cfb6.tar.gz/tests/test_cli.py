import os, subprocess, tempfile, textwrap, unittest

ROOT = os.path.dirname(os.path.dirname(__file__))
EXE = os.path.join(ROOT, 'executable')

def run_cmd(args):
    return subprocess.run([EXE] + args, text=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=10)

class CliTests(unittest.TestCase):
    def test_version_and_missing_bot_messages(self):
        p = run_cmd(['--version'])
        self.assertEqual(p.returncode, 0)
        self.assertEqual(p.stdout, '\n./executable  version: 1.2\n')
        p = run_cmd([])
        self.assertEqual(p.returncode, 1)
        self.assertIn('Please provide the launch command string for at least one bot.', p.stdout)

    def test_parse_errors_and_nplayers_validation(self):
        p = run_cmd(['-d', 'bad', 'true'])
        self.assertEqual(p.returncode, 1)
        self.assertIn("PARSE ERROR: Argument: -d (--dimensions)", p.stderr)
        self.assertIn("Couldn't read argument value from string 'bad'", p.stderr)

        p = run_cmd(['-n', '2', '-r', 'true', 'true'])
        self.assertEqual(p.returncode, 1)
        self.assertIn('Only single-player mode enables specified n-player maps.', p.stdout)

    def test_two_passive_bots_get_machine_readable_result(self):
        with tempfile.TemporaryDirectory() as td:
            bot = os.path.join(td, 'passive.py')
            with open(bot, 'w', encoding='utf-8') as f:
                f.write(textwrap.dedent('''\
                    #!/usr/bin/env python3
                    import sys
                    sys.stdin.readline()
                    print("Passive", flush=True)
                    for _ in sys.stdin:
                        print("", flush=True)
                '''))
            os.chmod(bot, 0o755)
            p = run_cmd(['-q', '-r', '-s', '1', '-d', '10 10', f'python3 {bot}', f'python3 {bot}'])
        self.assertEqual(p.returncode, 0, p.stderr)
        lines = [line for line in p.stdout.splitlines() if line]
        self.assertIn('10 10', lines)
        self.assertIn('1 2 100', lines)
        self.assertIn('2 1 100', lines)

    def test_replay_directory_receives_replay_when_enabled(self):
        with tempfile.TemporaryDirectory() as td:
            bot = os.path.join(td, 'passive.py')
            replay_dir = os.path.join(td, 'replays')
            os.mkdir(replay_dir)
            with open(bot, 'w', encoding='utf-8') as f:
                f.write('import sys\\nsys.stdin.readline()\\nprint("P", flush=True)\\n\\nfor _ in sys.stdin: print("", flush=True)\\n')
            p = run_cmd(['-q', '-i', replay_dir, '-s', '2', '-d', '8 8', f'python3 {bot}'])
            self.assertEqual(p.returncode, 0, p.stderr)
            files = os.listdir(replay_dir)
            self.assertEqual(len(files), 1)
            self.assertIn(os.path.join(replay_dir, files[0]) + ' 1', p.stdout)

    def test_exited_bot_command_completes_without_hanging(self):
        p = run_cmd(['-q', '-r', '-d', '6 6', 'true'])
        self.assertEqual(p.returncode, 0)
        self.assertIn('6 6', p.stdout)
        self.assertIn('1 1', p.stdout)

if __name__ == '__main__':
    unittest.main()
