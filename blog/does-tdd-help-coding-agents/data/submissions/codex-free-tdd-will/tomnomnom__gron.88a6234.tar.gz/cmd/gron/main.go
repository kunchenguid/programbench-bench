package main

import (
	"bytes"
	"encoding/json"
	"fmt"
	"io"
	"os"
	"sort"
	"strconv"
	"strings"
)

type node struct {
	v interface{}
}

func main() {
	code := run(os.Args[1:], os.Stdin, os.Stdout, os.Stderr)
	os.Exit(code)
}

func run(args []string, stdin io.Reader, stdout, stderr io.Writer) int {
	if has(args, "--help") || has(args, "-h") {
		printHelp(stdout)
		return 0
	}
	if has(args, "--version") {
		fmt.Fprintln(stdout, "gron version dev")
		return 0
	}

	var files []string
	jsonStream := false
	stream := false
	ungron := false
	values := false
	noSort := false
	for i := 0; i < len(args); i++ {
		switch args[i] {
		case "-j", "--json":
			jsonStream = true
		case "-s", "--stream":
			stream = true
		case "-u", "--ungron":
			ungron = true
		case "-v", "--values":
			values = true
		case "--no-sort":
			noSort = true
		case "-c", "--colorize", "-m", "--monochrome", "-k", "--insecure":
		case "-x", "--proxy", "--noproxy":
			if i+1 < len(args) {
				i++
			}
		default:
			if strings.HasPrefix(args[i], "-") {
				continue
			}
			files = append(files, args[i])
		}
	}

	data, err := readInput(files, stdin)
	if err != nil {
		fmt.Fprintln(stderr, err)
		return 1
	}

	if values && looksLikeStatements(data, jsonStream) {
		stmts, err := parseStatementList(data, jsonStream)
		if err != nil {
			fmt.Fprintf(stderr, "failed to parse statements: %v\n", err)
			return 5
		}
		for _, st := range stmts {
			fmt.Fprintln(stdout, formatValue(st.value))
		}
		return 0
	}

	if ungron {
		result, err := parseStatements(data, jsonStream)
		if err != nil {
			fmt.Fprintf(stderr, "failed to parse statements: %v\n", err)
			return 5
		}
		encoded, err := json.MarshalIndent(result, "", "  ")
		if err != nil {
			fmt.Fprintf(stderr, "failed to encode JSON: %v\n", err)
			return 6
		}
		fmt.Fprintln(stdout, string(encoded))
		return 0
	}

	if stream {
		var arr []interface{}
		for _, line := range bytes.Split(data, []byte{'\n'}) {
			if len(bytes.TrimSpace(line)) == 0 {
				continue
			}
			var v interface{}
			dec := json.NewDecoder(bytes.NewReader(line))
			dec.UseNumber()
			if err := dec.Decode(&v); err != nil {
				fmt.Fprintf(stderr, "failed to form statements: %v\n", err)
				return 3
			}
			arr = append(arr, v)
		}
		data, _ = json.Marshal(arr)
	}

	var v interface{}
	dec := json.NewDecoder(bytes.NewReader(data))
	dec.UseNumber()
	if err := dec.Decode(&v); err != nil {
		fmt.Fprintf(stderr, "failed to form statements: %v\n", err)
		return 3
	}

	var out []statement
	flatten(nil, v, &out)
	if !noSort {
		sort.SliceStable(out, func(i, j int) bool { return lessPath(out[i].path, out[j].path) })
	}
	for _, st := range out {
		if values {
			fmt.Fprintln(stdout, formatValue(st.value))
			continue
		}
		if jsonStream {
			line, _ := json.Marshal([]interface{}{st.path, st.value})
			fmt.Fprintln(stdout, string(line))
			continue
		}
		fmt.Fprintf(stdout, "json%s = %s;\n", formatPath(st.path), formatValue(st.value))
	}
	return 0
}

func parseStatements(data []byte, jsonStream bool) (interface{}, error) {
	var root interface{}
	stmts, err := parseStatementList(data, jsonStream)
	if err != nil {
		return nil, err
	}
	for _, st := range stmts {
		path, value := st.path, st.value
		if len(path) == 0 {
			root = value
			continue
		}
		if root == nil {
			root = containerFor(path[0])
		}
		root = setPath(root, path, value)
	}
	if root == nil {
		root = map[string]interface{}{}
	}
	return root, nil
}

func looksLikeStatements(data []byte, jsonStream bool) bool {
	trimmed := strings.TrimSpace(string(data))
	if trimmed == "" {
		return false
	}
	if jsonStream {
		return strings.HasPrefix(trimmed, "[[") || strings.HasPrefix(trimmed, "[[],")
	}
	return strings.HasPrefix(trimmed, "json")
}

func parseStatementList(data []byte, jsonStream bool) ([]statement, error) {
	var stmts []statement
	for _, raw := range bytes.Split(data, []byte{'\n'}) {
		line := strings.TrimSpace(string(raw))
		if line == "" {
			continue
		}
		var path []interface{}
		var value interface{}
		if jsonStream {
			p, v, err := parseJSONStreamStatement(line)
			if err != nil {
				return nil, err
			}
			path, value = p, v
		} else {
			p, v, err := parseAssignment(line)
			if err != nil {
				return nil, err
			}
			path, value = p, v
		}
		stmts = append(stmts, statement{path: path, value: value})
	}
	return stmts, nil
}

func parseJSONStreamStatement(line string) ([]interface{}, interface{}, error) {
	var pair []json.RawMessage
	if err := json.Unmarshal([]byte(line), &pair); err != nil {
		return nil, nil, err
	}
	if len(pair) != 2 {
		return nil, nil, fmt.Errorf("invalid JSON stream statement")
	}
	var path []interface{}
	var parts []interface{}
	dec := json.NewDecoder(bytes.NewReader(pair[0]))
	dec.UseNumber()
	if err := dec.Decode(&parts); err != nil {
		return nil, nil, err
	}
	for _, p := range parts {
		switch x := p.(type) {
		case string:
			path = append(path, x)
		case json.Number:
			i, err := strconv.Atoi(x.String())
			if err != nil {
				return nil, nil, err
			}
			path = append(path, i)
		case float64:
			path = append(path, int(x))
		default:
			return nil, nil, fmt.Errorf("invalid path element")
		}
	}
	var value interface{}
	dec = json.NewDecoder(bytes.NewReader(pair[1]))
	dec.UseNumber()
	if err := dec.Decode(&value); err != nil {
		return nil, nil, err
	}
	return path, value, nil
}

func parseAssignment(line string) ([]interface{}, interface{}, error) {
	if !strings.HasPrefix(line, "json") {
		return nil, nil, fmt.Errorf("expected json assignment")
	}
	eq := strings.Index(line, "=")
	if eq < 0 {
		return nil, nil, fmt.Errorf("expected =")
	}
	path, err := parsePath(strings.TrimSpace(line[:eq]))
	if err != nil {
		return nil, nil, err
	}
	rhs := strings.TrimSpace(line[eq+1:])
	rhs = strings.TrimSuffix(rhs, ";")
	rhs = strings.TrimSpace(rhs)
	var value interface{}
	dec := json.NewDecoder(strings.NewReader(rhs))
	dec.UseNumber()
	if err := dec.Decode(&value); err != nil {
		return nil, nil, err
	}
	return path, value, nil
}

func parsePath(s string) ([]interface{}, error) {
	if !strings.HasPrefix(s, "json") {
		return nil, fmt.Errorf("expected json path")
	}
	i := len("json")
	var path []interface{}
	for i < len(s) {
		switch s[i] {
		case '.':
			i++
			start := i
			for i < len(s) && (s[i] == '_' || s[i] >= 'A' && s[i] <= 'Z' || s[i] >= 'a' && s[i] <= 'z' || s[i] >= '0' && s[i] <= '9') {
				i++
			}
			if start == i {
				return nil, fmt.Errorf("empty property")
			}
			path = append(path, s[start:i])
		case '[':
			i++
			if i < len(s) && s[i] == '"' {
				var key string
				end, err := scanJSONString(s, i)
				if err != nil {
					return nil, err
				}
				if err := json.Unmarshal([]byte(s[i:end]), &key); err != nil {
					return nil, err
				}
				i = end
				if i >= len(s) || s[i] != ']' {
					return nil, fmt.Errorf("expected ]")
				}
				i++
				path = append(path, key)
			} else {
				start := i
				for i < len(s) && s[i] >= '0' && s[i] <= '9' {
					i++
				}
				n, err := strconv.Atoi(s[start:i])
				if err != nil {
					return nil, err
				}
				if i >= len(s) || s[i] != ']' {
					return nil, fmt.Errorf("expected ]")
				}
				i++
				path = append(path, n)
			}
		default:
			return nil, fmt.Errorf("unexpected path character %q", s[i])
		}
	}
	return path, nil
}

func scanJSONString(s string, start int) (int, error) {
	esc := false
	for i := start + 1; i < len(s); i++ {
		if esc {
			esc = false
			continue
		}
		if s[i] == '\\' {
			esc = true
			continue
		}
		if s[i] == '"' {
			return i + 1, nil
		}
	}
	return 0, fmt.Errorf("unterminated string")
}

func containerFor(next interface{}) interface{} {
	if _, ok := next.(int); ok {
		return []interface{}{}
	}
	return map[string]interface{}{}
}

func setPath(cur interface{}, path []interface{}, value interface{}) interface{} {
	if len(path) == 0 {
		return value
	}
	switch p := path[0].(type) {
	case string:
		m, ok := cur.(map[string]interface{})
		if !ok {
			m = map[string]interface{}{}
		}
		if len(path) == 1 {
			m[p] = value
		} else {
			child, ok := m[p]
			if !ok || child == nil {
				child = containerFor(path[1])
			}
			m[p] = setPath(child, path[1:], value)
		}
		return m
	case int:
		a, ok := cur.([]interface{})
		if !ok {
			a = []interface{}{}
		}
		for len(a) <= p {
			a = append(a, nil)
		}
		if len(path) == 1 {
			a[p] = value
		} else {
			child := a[p]
			if child == nil {
				child = containerFor(path[1])
			}
			a[p] = setPath(child, path[1:], value)
		}
		return a
	}
	return cur
}

func has(args []string, s string) bool {
	for _, a := range args {
		if a == s {
			return true
		}
	}
	return false
}

func readInput(files []string, stdin io.Reader) ([]byte, error) {
	if len(files) == 0 || files[0] == "-" {
		return io.ReadAll(stdin)
	}
	return os.ReadFile(files[0])
}

type statement struct {
	path  []interface{}
	value interface{}
}

func flatten(path []interface{}, v interface{}, out *[]statement) {
	switch x := v.(type) {
	case map[string]interface{}:
		*out = append(*out, statement{append([]interface{}{}, path...), map[string]interface{}{}})
		keys := make([]string, 0, len(x))
		for k := range x {
			keys = append(keys, k)
		}
		sort.Strings(keys)
		for _, k := range keys {
			flatten(append(path, k), x[k], out)
		}
	case []interface{}:
		*out = append(*out, statement{append([]interface{}{}, path...), []interface{}{}})
		for i, item := range x {
			flatten(append(path, i), item, out)
		}
	default:
		*out = append(*out, statement{append([]interface{}{}, path...), v})
	}
}

func lessPath(a, b []interface{}) bool {
	for i := 0; i < len(a) && i < len(b); i++ {
		ai, aInt := a[i].(int)
		bi, bInt := b[i].(int)
		if aInt && bInt {
			if ai != bi {
				return ai < bi
			}
			continue
		}
		as, aStr := a[i].(string)
		bs, bStr := b[i].(string)
		if aStr && bStr {
			av, bv := isIdent(as), isIdent(bs)
			if av != bv {
				return av
			}
			if as != bs {
				return as < bs
			}
			continue
		}
		if aInt != bInt {
			return aInt
		}
	}
	return len(a) < len(b)
}

func formatPath(path []interface{}) string {
	var b strings.Builder
	for _, p := range path {
		switch x := p.(type) {
		case int:
			fmt.Fprintf(&b, "[%d]", x)
		case string:
			if isIdent(x) {
				b.WriteByte('.')
				b.WriteString(x)
			} else {
				b.WriteByte('[')
				b.WriteString(strconv.Quote(x))
				b.WriteByte(']')
			}
		}
	}
	return b.String()
}

func isIdent(s string) bool {
	if s == "" {
		return false
	}
	for i, r := range s {
		if i == 0 {
			if !(r == '_' || r >= 'A' && r <= 'Z' || r >= 'a' && r <= 'z') {
				return false
			}
			continue
		}
		if !(r == '_' || r >= 'A' && r <= 'Z' || r >= 'a' && r <= 'z' || r >= '0' && r <= '9') {
			return false
		}
	}
	return true
}

func formatValue(v interface{}) string {
	switch x := v.(type) {
	case json.Number:
		return x.String()
	case string:
		return strconv.Quote(x)
	case bool:
		if x {
			return "true"
		}
		return "false"
	case nil:
		return "null"
	case map[string]interface{}:
		return "{}"
	case []interface{}:
		return "[]"
	default:
		b, _ := json.Marshal(x)
		return string(b)
	}
}

func printHelp(w io.Writer) {
	fmt.Fprint(w, `Transform JSON (from a file, URL, or stdin) into discrete assignments to make it greppable

Usage:
  gron [OPTIONS] [FILE|URL|-]

Options:
  -u, --ungron     Reverse the operation (turn assignments back into JSON)
  -v, --values     Print just the values of provided assignments
  -c, --colorize   Colorize output (default on tty)
  -m, --monochrome Monochrome (don't colorize output)
  -s, --stream     Treat each line of input as a separate JSON object
  -k, --insecure   Disable certificate validation
  -x, --proxy      Set proxy configuration
      --noproxy    Comma-separated list of hosts for which not to use a proxy, if one is specified.
  -j, --json       Represent gron data as JSON stream
      --no-sort    Don't sort output (faster)
      --version    Print version information
`)
}
