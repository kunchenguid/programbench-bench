#!/bin/bash
set -e
go build -o executable ./cmd/gron
chmod +x executable
