module cleanroom-gron

go 1.20
