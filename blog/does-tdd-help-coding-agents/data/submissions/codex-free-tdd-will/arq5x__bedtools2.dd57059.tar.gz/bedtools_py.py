#!/usr/bin/env python3
import gzip
import math
import os
import signal
import statistics
import sys
from collections import Counter, defaultdict

signal.signal(signal.SIGPIPE, signal.SIG_DFL)


VERSION = "bedtools b2e3657"


class Rec:
    __slots__ = ("fields", "chrom", "start", "end")

    def __init__(self, fields):
        self.fields = fields
        self.chrom = fields[0]
        self.start = int(fields[1])
        self.end = int(fields[2])

    def line(self):
        return "\t".join(self.fields)

    def with_interval(self, start, end):
        f = self.fields[:]
        f[1] = str(start)
        f[2] = str(end)
        return "\t".join(f)


def die(msg, code=1):
    sys.stderr.write(msg.rstrip() + "\n")
    raise SystemExit(code)


def open_text(path):
    if path in ("-", "stdin"):
        return sys.stdin
    if path.endswith(".gz"):
        return gzip.open(path, "rt")
    return open(path, "r")


def read_records(path):
    out = []
    headers = []
    with open_text(path) as fh:
        for line in fh:
            line = line.rstrip("\n")
            if not line:
                continue
            if line.startswith("#") or line.startswith("track") or line.startswith("browser"):
                headers.append(line)
                continue
            fields = line.split("\t") if "\t" in line else line.split()
            if len(fields) < 3:
                continue
            try:
                out.append(Rec(fields))
            except ValueError:
                headers.append(line)
    return out, headers


def read_genome(path):
    genome = []
    with open_text(path) as fh:
        for line in fh:
            if not line.strip() or line.startswith("#"):
                continue
            f = line.split()
            if len(f) >= 2:
                genome.append((f[0], int(f[1])))
    return genome


def overlap_len(a, b):
    if a.chrom != b.chrom:
        return 0
    return max(0, min(a.end, b.end) - max(a.start, b.start))


def strand_ok(a, b, same=False, diff=False):
    if not same and not diff:
        return True
    if len(a.fields) < 6 or len(b.fields) < 6:
        return False
    return (a.fields[5] == b.fields[5]) if same else (a.fields[5] != b.fields[5])


def passes_overlap(a, b, f=1e-9, F=1e-9, recip=False, either=False, same=False, diff=False):
    ov = overlap_len(a, b)
    if ov <= 0 or not strand_ok(a, b, same, diff):
        return False, ov
    fa = ov / max(1, a.end - a.start)
    fb = ov / max(1, b.end - b.start)
    if either:
        ok = fa >= f or fb >= F
    else:
        ok = fa >= f and fb >= F
    if recip:
        ok = ok and fa >= f and fb >= f
    return ok, ov


def build_index(recs):
    by = defaultdict(list)
    for r in recs:
        by[r.chrom].append(r)
    for chrom in by:
        by[chrom].sort(key=lambda r: (r.start, r.end))
    return by


def overlapping(index_or_recs, a, f=1e-9, F=1e-9, recip=False, either=False, same=False, diff=False):
    if isinstance(index_or_recs, dict):
        candidates = index_or_recs.get(a.chrom, [])
    else:
        candidates = index_or_recs
    out = []
    for b in candidates:
        if b.start >= a.end:
            break
        if b.end <= a.start:
            continue
        ok, ov = passes_overlap(a, b, f, F, recip, either, same, diff)
        if ok:
            out.append((b, ov))
    return out


def value(fields, col):
    idx = int(col) - 1
    return fields[idx] if 0 <= idx < len(fields) else "."


def fmt_num(x, prec=5):
    if isinstance(x, int) or abs(x - int(x)) < 1e-12:
        return str(int(x))
    return f"{x:.{prec}f}".rstrip("0").rstrip(".")


def numeric(vals):
    nums = []
    for v in vals:
        try:
            nums.append(float(v))
        except Exception:
            pass
    return nums


def summarize(vals, op, delim=",", prec=5):
    if op == "count":
        return str(len(vals))
    if not vals:
        return "."
    nums = numeric(vals)
    if op == "sum":
        return fmt_num(sum(nums), prec) if nums else "."
    if op == "min":
        return fmt_num(min(nums), prec) if nums else min(vals)
    if op == "max":
        return fmt_num(max(nums), prec) if nums else max(vals)
    if op == "mean":
        return fmt_num(sum(nums) / len(nums), prec) if nums else "."
    if op == "median":
        return fmt_num(statistics.median(nums), prec) if nums else "."
    if op in ("stdev", "sstdev"):
        if len(nums) < 2:
            return "0"
        return fmt_num(statistics.stdev(nums), prec)
    if op == "collapse":
        return delim.join(vals)
    if op == "concat":
        return "".join(vals)
    if op == "distinct":
        return delim.join(dict.fromkeys(vals))
    if op == "count_distinct":
        return str(len(set(vals)))
    if op == "first":
        return vals[0]
    if op == "last":
        return vals[-1]
    if op in ("mode", "antimode", "freqdesc", "freqasc"):
        c = Counter(vals)
        items = list(c.items())
        if op == "mode":
            m = max(c.values())
            return sorted([k for k, v in items if v == m])[0]
        if op == "antimode":
            m = min(c.values())
            return sorted([k for k, v in items if v == m])[0]
        rev = op == "freqdesc"
        items.sort(key=lambda kv: (-kv[1], kv[0]) if rev else (kv[1], kv[0]))
        return delim.join(f"{k}:{v}" for k, v in items)
    if op == "distinct_sort_num":
        return delim.join(fmt_num(x, prec) for x in sorted(set(numeric(vals))))
    if op == "distinct_sort_num_desc":
        return delim.join(fmt_num(x, prec) for x in sorted(set(numeric(vals)), reverse=True))
    return summarize(vals, "sum", delim, prec)


DEFAULT_VALUE_FLAGS = {"-a", "-i", "-g", "-f", "-F", "-w", "-l", "-r", "-S", "-D", "-t", "-k", "-delim", "-prec", "-strand", "-names", "-b", "-n"}


def parse_opts(argv, multi_b=False, value_flags=None):
    value_flags = set(DEFAULT_VALUE_FLAGS if value_flags is None else value_flags)
    opts = defaultdict(lambda: False)
    vals = {}
    i = 0
    while i < len(argv):
        a = argv[i]
        if a in value_flags:
            if a == "-b" and multi_b:
                bs = []
                i += 1
                while i < len(argv) and not argv[i].startswith("-"):
                    bs.append(argv[i])
                    i += 1
                vals[a] = bs
                continue
            if i + 1 >= len(argv):
                die(f"***** ERROR: {a} requires a value")
            vals[a] = argv[i + 1]
            i += 2
        elif a in ("-wa", "-wb", "-wo", "-wao", "-loj", "-u", "-v", "-c", "-C", "-d", "-sorted", "-s", "-r", "-e", "-split", "-header", "-counts", "-mean", "-hist", "-bg", "-bga", "-dz", "-bed", "-full", "-inheader", "-outheader", "-ignorecase", "-sizeA", "-sizeD", "-chrThenSizeA", "-chrThenSizeD", "-chrThenScoreA", "-chrThenScoreD", "-L", "-sw", "-sm", "-Sm", "-io", "-N", "-A", "-trackline"):
            opts[a] = True
            i += 1
        else:
            i += 1
    return opts, vals


def sorted_recs(recs, genome_order=None):
    order = {c: i for i, (c, _) in enumerate(genome_order or [])}
    return sorted(recs, key=lambda r: (order.get(r.chrom, 10**9), r.chrom, r.start, r.end))


def merged_groups(recs, dist=0, same_strand=False, strand_filter=None):
    groups = []
    for r in sorted_recs(recs):
        if strand_filter and (len(r.fields) < 6 or r.fields[5] != strand_filter):
            continue
        if not groups:
            groups.append([r.chrom, r.start, r.end, [r]])
            continue
        g = groups[-1]
        strand_match = True
        if same_strand:
            strand_match = len(g[3][0].fields) >= 6 and len(r.fields) >= 6 and g[3][0].fields[5] == r.fields[5]
        if r.chrom == g[0] and strand_match and r.start <= g[2] + dist:
            g[2] = max(g[2], r.end)
            g[3].append(r)
        else:
            groups.append([r.chrom, r.start, r.end, [r]])
    return groups


def expanded_cols_ops(cols_s, ops_s):
    cols = cols_s.split(",") if cols_s else ["5"]
    ops = ops_s.split(",") if ops_s else ["sum"]
    if len(cols) == 1 and len(ops) > 1:
        cols = cols * len(ops)
    elif len(ops) == 1 and len(cols) > 1:
        ops = ops * len(cols)
    return cols, ops


def cmd_merge(argv):
    opts, vals = parse_opts(argv, value_flags=DEFAULT_VALUE_FLAGS | {"-d", "-c", "-o"})
    recs, headers = read_records(vals.get("-i", "stdin"))
    dist = int(vals.get("-d", 0))
    delim = vals.get("-delim", ",")
    prec = int(vals.get("-prec", 5))
    strand_filter = vals.get("-S") if "-S" in vals else None
    if opts["-header"]:
        for h in headers:
            print(h)
    cols, ops = expanded_cols_ops(vals.get("-c"), vals.get("-o"))
    for chrom, start, end, members in merged_groups(recs, dist, opts["-s"], strand_filter):
        out = [chrom, str(start), str(end)]
        if "-c" in vals or "-o" in vals:
            for col, op in zip(cols, ops):
                out.append(summarize([value(m.fields, col) for m in members], op, delim, prec))
        print("\t".join(out))


def cmd_sort(argv):
    opts, vals = parse_opts(argv)
    recs, headers = read_records(vals.get("-i", "stdin"))
    genome = read_genome(vals["-g"]) if "-g" in vals else None
    if opts["-header"]:
        for h in headers:
            print(h)
    if opts["-sizeA"]:
        key = lambda r: (r.end - r.start, r.chrom, r.start)
    elif opts["-sizeD"]:
        key = lambda r: (-(r.end - r.start), r.chrom, r.start)
    elif opts["-chrThenSizeA"]:
        key = lambda r: (r.chrom, r.end - r.start, r.start)
    elif opts["-chrThenSizeD"]:
        key = lambda r: (r.chrom, -(r.end - r.start), r.start)
    elif opts["-chrThenScoreA"]:
        key = lambda r: (r.chrom, float(value(r.fields, 5)), r.start)
    elif opts["-chrThenScoreD"]:
        key = lambda r: (r.chrom, -float(value(r.fields, 5)), r.start)
    else:
        order = {c: i for i, (c, _) in enumerate(genome or [])}
        key = lambda r: (order.get(r.chrom, 10**9), r.chrom, r.start, r.end)
    for r in sorted(recs, key=key):
        print(r.line())


def cmd_complement(argv):
    opts, vals = parse_opts(argv)
    recs, _ = read_records(vals.get("-i", "stdin"))
    genome = read_genome(vals["-g"])
    by = defaultdict(list)
    for chrom, s, e, members in merged_groups(recs):
        by[chrom].append((s, e))
    present = set(by)
    for chrom, size in genome:
        if opts["-L"] and chrom not in present:
            continue
        pos = 0
        for s, e in by.get(chrom, []):
            if s > pos:
                print(f"{chrom}\t{pos}\t{s}")
            pos = max(pos, e)
        if pos < size:
            print(f"{chrom}\t{pos}\t{size}")


def coverage_segments(recs, chrom, start, end):
    events = defaultdict(int)
    for r in recs:
        if r.chrom != chrom:
            continue
        s = max(start, r.start); e = min(end, r.end)
        if s < e:
            events[s] += 1
            events[e] -= 1
    pts = sorted(set([start, end]) | set(events))
    cov = 0
    segs = []
    last = pts[0] if pts else start
    for p in pts:
        if p > last:
            segs.append((last, p, cov))
        cov += events[p]
        last = p
    return segs


def cmd_coverage(argv):
    opts, vals = parse_opts(argv, value_flags=DEFAULT_VALUE_FLAGS - {"-r", "-S"})
    A, headers = read_records(vals["-a"])
    B, _ = read_records(vals["-b"])
    Bidx = build_index(B)
    f = float(vals.get("-f", 1e-9)); F = float(vals.get("-F", 1e-9))
    same = opts["-s"]; diff = opts["-S"]
    if opts["-header"]:
        for h in headers:
            print(h)
    for a in A:
        hits = [b for b, _ in overlapping(Bidx, a, f, F, opts["-r"], opts["-e"], same, diff)]
        if opts["-counts"]:
            print(a.line() + "\t" + str(len(hits)))
            continue
        segs = coverage_segments(hits, a.chrom, a.start, a.end)
        length = max(1, a.end - a.start)
        covered = sum(e - s for s, e, c in segs if c > 0)
        if opts["-mean"]:
            total = sum((e - s) * c for s, e, c in segs)
            print(a.line() + "\t" + f"{total / length:.7f}")
        elif opts["-d"]:
            for pos in range(a.start, a.end):
                depth = 0
                for s, e, c in segs:
                    if s <= pos < e:
                        depth = c; break
                print(a.line() + "\t" + str(pos - a.start + 1) + "\t" + str(depth))
        else:
            print(a.line() + f"\t{len(hits)}\t{covered}\t{length}\t{covered / length:.7f}")


def genome_depth_segments(recs, genome):
    by = defaultdict(list)
    for r in recs:
        by[r.chrom].append(r)
    for chrom, size in genome:
        yield chrom, coverage_segments(by.get(chrom, []), chrom, 0, size)


def cmd_genomecov(argv):
    opts, vals = parse_opts(argv)
    recs, _ = read_records(vals.get("-i", vals.get("-ibam", "stdin")))
    genome = read_genome(vals["-g"])
    scale = float(vals.get("-scale", 1.0))
    if opts["-bg"] or opts["-bga"]:
        if opts["-trackline"]:
            print("track type=bedGraph")
        for chrom, segs in genome_depth_segments(recs, genome):
            for s, e, c in segs:
                if c > 0 or opts["-bga"]:
                    print(f"{chrom}\t{s}\t{e}\t{fmt_num(c * scale)}")
    elif opts["-d"] or opts["-dz"]:
        for chrom, segs in genome_depth_segments(recs, genome):
            for s, e, c in segs:
                if opts["-dz"]:
                    if c:
                        for p in range(s, e):
                            print(f"{chrom}\t{p}\t{fmt_num(c * scale)}")
                else:
                    for p in range(s, e):
                        print(f"{chrom}\t{p+1}\t{fmt_num(c * scale)}")
    else:
        total_genome = sum(size for _, size in genome)
        genome_hist = Counter()
        for chrom, segs in genome_depth_segments(recs, genome):
            size = dict(genome)[chrom]
            hist = Counter()
            for s, e, c in segs:
                hist[c] += e - s
                genome_hist[c] += e - s
            for d in sorted(hist):
                print(f"{chrom}\t{d}\t{hist[d]}\t{size}\t{hist[d] / size:.7g}")
        for d in sorted(genome_hist):
            print(f"genome\t{d}\t{genome_hist[d]}\t{total_genome}\t{genome_hist[d] / total_genome:.7g}")


def bed_distance(a, b):
    if a.chrom != b.chrom:
        return None
    if overlap_len(a, b) > 0:
        return 0
    if a.end <= b.start:
        return b.start - a.end + 1
    return a.start - b.end + 1


def cmd_closest(argv):
    opts, vals = parse_opts(argv, multi_b=True, value_flags=DEFAULT_VALUE_FLAGS - {"-d", "-r", "-S"})
    A, _ = read_records(vals["-a"])
    b_paths = vals["-b"] if isinstance(vals["-b"], list) else [vals["-b"]]
    B = [b for p in b_paths for b in read_records(p)[0]]
    for a in A:
        cand = []
        for idx, b in enumerate(B):
            if opts["-N"] and len(a.fields) > 3 and len(b.fields) > 3 and a.fields[3] == b.fields[3]:
                continue
            d = bed_distance(a, b)
            if d is not None:
                if opts["-io"] and d == 0:
                    continue
                cand.append((abs(d), idx, d, b))
        if not cand:
            print(a.line() + "\tnone\t-1\t-1" + ("\t-1" if opts["-d"] or "-D" in vals else ""))
            continue
        cand.sort(key=lambda x: (x[0], x[1]))
        best = cand[0][0]
        ties = [x for x in cand if x[0] == best]
        mode = vals.get("-t", "all")
        if mode == "first":
            ties = [ties[0]]
        elif mode == "last":
            ties = [ties[-1]]
        for _, _, d, b in ties[: int(vals.get("-k", len(ties)))]:
            tail = "\t" + str(d) if opts["-d"] or "-D" in vals else ""
            print(a.line() + "\t" + b.line() + tail)


def cmd_subtract(argv):
    opts, vals = parse_opts(argv, value_flags=DEFAULT_VALUE_FLAGS - {"-r", "-S"})
    A, _ = read_records(vals["-a"])
    B, _ = read_records(vals["-b"])
    Bidx = build_index(B)
    f = float(vals.get("-f", 1e-9)); F = float(vals.get("-F", 1e-9))
    for a in A:
        pieces = [(a.start, a.end)]
        hit = False
        for b, ov in overlapping(Bidx, a, f, F, opts["-r"], opts["-e"], opts["-s"], opts["-S"]):
            hit = True
            new = []
            for s, e in pieces:
                os = max(s, b.start); oe = min(e, b.end)
                if os >= oe:
                    new.append((s, e))
                else:
                    if s < os:
                        new.append((s, os))
                    if oe < e:
                        new.append((oe, e))
            pieces = new
        if opts["-A"] and hit:
            continue
        for s, e in pieces:
            if s < e:
                print(a.with_interval(s, e))


def cmd_makewindows(argv):
    opts, vals = parse_opts(argv)
    genome = read_genome(vals["-g"])
    w = int(vals.get("-w", 0))
    n = int(vals.get("-n", 0)) if "-n" in vals else 0
    for chrom, size in genome:
        if w:
            start = 0
            while start < size:
                print(f"{chrom}\t{start}\t{min(size, start + w)}")
                start += w
        elif n:
            step = math.ceil(size / n)
            start = 0
            for _ in range(n):
                if start >= size:
                    break
                end = min(size, start + step)
                print(f"{chrom}\t{start}\t{end}")
                start = end


def cmd_slop(argv):
    opts, vals = parse_opts(argv, value_flags=DEFAULT_VALUE_FLAGS | {"-b"})
    recs, _ = read_records(vals["-i"])
    sizes = dict(read_genome(vals["-g"]))
    b = int(vals.get("-b", 0)) if "-b" in vals else 0
    l = int(vals.get("-l", b)); r = int(vals.get("-r", b))
    for rec in recs:
        start = max(0, rec.start - l)
        end = min(sizes.get(rec.chrom, rec.end + r), rec.end + r)
        print(rec.with_interval(start, end))


def cmd_flank(argv):
    opts, vals = parse_opts(argv, value_flags=DEFAULT_VALUE_FLAGS | {"-b"})
    recs, _ = read_records(vals["-i"])
    sizes = dict(read_genome(vals["-g"]))
    b = int(vals.get("-b", 0)) if "-b" in vals else 0
    l = int(vals.get("-l", b)); r = int(vals.get("-r", b))
    for rec in recs:
        left_l, right_l = l, r
        if opts["-sw"] and len(rec.fields) >= 6 and rec.fields[5] == "-":
            left_l, right_l = r, l
        ls = max(0, rec.start - left_l); le = rec.start
        rs = rec.end; re = min(sizes.get(rec.chrom, rec.end + right_l), rec.end + right_l)
        if ls < le:
            print(rec.with_interval(ls, le))
        if rs < re:
            print(rec.with_interval(rs, re))


def total_merged_bp(recs):
    return sum(e - s for _, s, e, _ in merged_groups(recs))


def cmd_jaccard(argv):
    opts, vals = parse_opts(argv)
    A, _ = read_records(vals["-a"]); B, _ = read_records(vals["-b"])
    inter = 0
    n = 0
    for chrom, s, e, _ in merged_groups(A):
        ar = Rec([chrom, str(s), str(e)])
        any_hit = False
        for bchrom, bs, be, _ in merged_groups([b for b in B if b.chrom == chrom]):
            br = Rec([bchrom, str(bs), str(be)])
            ov = overlap_len(ar, br)
            if ov:
                inter += ov; any_hit = True
        if any_hit:
            n += 1
    union = total_merged_bp(A) + total_merged_bp(B) - inter
    print("intersection\tunion\tjaccard\tn_intersections")
    print(f"{inter}\t{union}\t{fmt_num(inter / union if union else 0, 6)}\t{n}")


def cmd_map(argv):
    opts, vals = parse_opts(argv, value_flags=DEFAULT_VALUE_FLAGS | {"-c", "-o"})
    A, _ = read_records(vals["-a"]); B, _ = read_records(vals["-b"])
    Bidx = build_index(B)
    cols, ops = expanded_cols_ops(vals.get("-c"), vals.get("-o"))
    delim = vals.get("-delim", ","); prec = int(vals.get("-prec", 5))
    for a in A:
        hits = [b for b, _ in overlapping(Bidx, a)]
        out = [a.line()]
        for col, op in zip(cols, ops):
            out.append(summarize([value(h.fields, col) for h in hits], op, delim, prec))
        print("\t".join(out))


def cmd_groupby(argv):
    opts, vals = parse_opts(argv, value_flags=DEFAULT_VALUE_FLAGS | {"-c", "-o", "-grp", "-opCols", "-ops"})
    rows = []
    with open_text(vals.get("-i", "stdin")) as fh:
        for line in fh:
            if line.strip():
                rows.append(line.rstrip("\n").split())
    if opts["-inheader"] or opts["-header"]:
        rows = rows[1:]
    gcols = [int(x) - 1 for x in vals.get("-g", vals.get("-grp", "1,2,3")).split(",")]
    cols, ops = expanded_cols_ops(vals.get("-c") or vals.get("-opCols"), vals.get("-o") or vals.get("-ops"))
    delim = vals.get("-delim", ","); prec = int(vals.get("-prec", 5))
    cur_key = None; group = []
    def emit(key, rows):
        if key is None:
            return
        base = rows[0][:] if opts["-full"] else [rows[0][i] for i in gcols]
        for col, op in zip(cols, ops):
            base.append(summarize([value(r, col) for r in rows], op, delim, prec))
        print("\t".join(base))
    for r in rows:
        key = tuple(r[i].lower() if opts["-ignorecase"] else r[i] for i in gcols)
        if cur_key is not None and key != cur_key:
            emit(cur_key, group); group = []
        cur_key = key; group.append(r)
    emit(cur_key, group)


def cmd_overlap(argv):
    value_flags = DEFAULT_VALUE_FLAGS | {"-cols"}
    opts, vals = parse_opts(argv, value_flags=value_flags)
    cols = [int(x) - 1 for x in vals.get("-cols", "2,3,6,7").split(",")]
    with open_text(vals.get("-i", "stdin")) as fh:
        for line in fh:
            if not line.strip():
                continue
            f = line.rstrip("\n").split()
            s1, e1, s2, e2 = [int(f[i]) for i in cols]
            ov = min(e1, e2) - max(s1, s2)
            print("\t".join(f + [str(ov)]))


def cmd_intersect(argv):
    opts, vals = parse_opts(argv, multi_b=True, value_flags=DEFAULT_VALUE_FLAGS - {"-r", "-S"})
    if "-a" not in vals or "-b" not in vals:
        die("***** ERROR: -a and -b are required")
    A, headers = read_records(vals["-a"])
    b_paths = vals["-b"] if isinstance(vals["-b"], list) else [vals["-b"]]
    Bsets = [read_records(p)[0] for p in b_paths]
    Bidxs = [build_index(B) for B in Bsets]
    names = vals.get("-names", "").split(",") if "-names" in vals else []
    f = float(vals.get("-f", 1e-9)); F = float(vals.get("-F", 1e-9))
    same = opts["-s"]; diff = opts["-S"]
    if opts["-header"]:
        for h in headers:
            print(h)
    for a in A:
        hits = []
        for bi, Bidx in enumerate(Bidxs):
            for b, ov in overlapping(Bidx, a, f, F, opts["-r"], opts["-e"], same, diff):
                hits.append((bi, b, ov))
        if opts["-c"]:
            print(a.line() + "\t" + str(len(hits)))
        elif opts["-C"]:
            for bi, B in enumerate(Bsets):
                c = sum(1 for h in hits if h[0] == bi)
                label = names[bi] if bi < len(names) else str(bi + 1)
                print(a.line() + "\t" + label + "\t" + str(c))
        elif opts["-v"]:
            if not hits:
                print(a.line())
        elif opts["-u"]:
            if hits:
                print(a.line())
        elif opts["-wao"] or opts["-loj"]:
            if hits:
                for bi, b, ov in hits:
                    mid = []
                    if len(Bsets) > 1:
                        mid = [names[bi] if bi < len(names) else str(bi + 1)]
                    tail = "\t" + str(ov) if opts["-wao"] else ""
                    print("\t".join([a.line()] + mid + [b.line()]) + tail)
            else:
                width = max((len(b.fields) for B in Bsets for b in B), default=3)
                null_b = ["none", "-1", "-1"] + ["."] * max(0, width - 3)
                tail = "\t0" if opts["-wao"] else ""
                print(a.line() + "\t" + "\t".join(null_b) + tail)
        elif opts["-wo"]:
            for bi, b, ov in hits:
                mid = []
                if len(Bsets) > 1:
                    mid = [names[bi] if bi < len(names) else str(bi + 1)]
                print("\t".join([a.line()] + mid + [b.line(), str(ov)]))
        elif opts["-wa"] and opts["-wb"]:
            for bi, b, ov in hits:
                mid = []
                if len(Bsets) > 1:
                    mid = [names[bi] if bi < len(names) else str(bi + 1)]
                print("\t".join([a.line()] + mid + [b.line()]))
        elif opts["-wa"]:
            for _ in hits:
                print(a.line())
        elif opts["-wb"]:
            for bi, b, ov in hits:
                print(b.line())
        else:
            for bi, b, ov in hits:
                print(a.with_interval(max(a.start, b.start), min(a.end, b.end)))


def main():
    if len(sys.argv) == 1 or sys.argv[1] in ("--help", "-h"):
        print("bedtools is a powerful toolset for genome arithmetic.")
        print("\nUsage:     bedtools <subcommand> [options]")
        print("\nThe bedtools sub-commands include:\n    intersect\n    merge\n    sort\n    complement\n    coverage\n    genomecov\n    closest")
        return
    if sys.argv[1] == "--version":
        print(VERSION)
        return
    if sys.argv[1] == "--contact":
        print("")
        print("- For further help, or to report a bug, please ")
        print("  email the bedtools mailing list: ")
        print("     bedtools-discuss@googlegroups.com")
        print("")
        print("- The development repository can be found at: ")
        print("     https://github.com/arq5x/bedtools")
        print("")
        print("- Stable releases of bedtools can be found at: ")
        print("     https://github.com/arq5x/bedtools2/releases")
        return
    cmd = sys.argv[1]
    aliases = {
        "intersectBed": "intersect",
        "mergeBed": "merge",
        "sortBed": "sort",
        "complementBed": "complement",
        "coverageBed": "coverage",
        "genomeCoverageBed": "genomecov",
        "closestBed": "closest",
        "subtractBed": "subtract",
        "windowBed": "window",
        "mapBed": "map",
        "groupBy": "groupby",
    }
    cmd = aliases.get(cmd, cmd)
    argv = sys.argv[2:]
    if "-h" in argv or "--help" in argv:
        print(f"Tool:    bedtools {cmd}")
        print(f"Usage:   bedtools {cmd} [OPTIONS]")
        return
    if cmd == "intersect":
        cmd_intersect(argv)
    elif cmd == "merge":
        cmd_merge(argv)
    elif cmd == "sort":
        cmd_sort(argv)
    elif cmd == "complement":
        cmd_complement(argv)
    elif cmd == "coverage":
        cmd_coverage(argv)
    elif cmd == "genomecov":
        cmd_genomecov(argv)
    elif cmd == "closest":
        cmd_closest(argv)
    elif cmd == "subtract":
        cmd_subtract(argv)
    elif cmd == "makewindows":
        cmd_makewindows(argv)
    elif cmd == "slop":
        cmd_slop(argv)
    elif cmd == "flank":
        cmd_flank(argv)
    elif cmd == "jaccard":
        cmd_jaccard(argv)
    elif cmd == "map":
        cmd_map(argv)
    elif cmd == "groupby":
        cmd_groupby(argv)
    elif cmd == "overlap":
        cmd_overlap(argv)
    elif cmd == "window":
        # A window is equivalent to intersecting B against an expanded A, but
        # reports the original A and B records.
        opts, vals = parse_opts(argv)
        A, _ = read_records(vals["-a"]); B, _ = read_records(vals["-b"])
        w = int(vals.get("-w", 1000)); l = int(vals.get("-l", w)); r = int(vals.get("-r", w))
        for a in A:
            q = Rec([a.chrom, str(max(0, a.start - l)), str(a.end + r)])
            hits = [b for b in B if overlap_len(q, b) > 0]
            if opts["-c"]:
                print(a.line() + "\t" + str(len(hits)))
            elif opts["-u"]:
                if hits:
                    print(a.line())
            elif opts["-v"]:
                if not hits:
                    print(a.line())
            else:
                for b in hits:
                    print(a.line() + "\t" + b.line())
    else:
        die(f"*****ERROR: Unrecognized command: {cmd}")


if __name__ == "__main__":
    main()
