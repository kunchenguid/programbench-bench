import os
import subprocess
import tempfile
import unittest


ROOT = os.path.dirname(os.path.dirname(__file__))
EXE = os.path.join(ROOT, "executable")


def run_cmd(args, stdin=None):
    return subprocess.run(
        [EXE] + args,
        input=stdin,
        text=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        check=False,
    )


class BedtoolsCliTests(unittest.TestCase):
    def write_fixture(self, td):
        a = os.path.join(td, "a.bed")
        b = os.path.join(td, "b.bed")
        g = os.path.join(td, "g.txt")
        with open(a, "w") as fh:
            fh.write("chr1\t10\t20\ta1\t0\t+\nchr1\t30\t40\ta2\t0\t-\nchr2\t5\t10\ta3\t0\t+\n")
        with open(b, "w") as fh:
            fh.write("chr1\t15\t25\tb1\t5\t+\nchr1\t18\t22\tb2\t7\t-\nchr1\t40\t45\tb3\t9\t-\nchr2\t1\t6\tb4\t2\t+\n")
        with open(g, "w") as fh:
            fh.write("chr1\t50\nchr2\t12\n")
        return a, b, g

    def test_intersect_default_reports_intersection_with_a_fields(self):
        with tempfile.TemporaryDirectory() as td:
            a = os.path.join(td, "a.bed")
            b = os.path.join(td, "b.bed")
            open(a, "w").write("chr1\t10\t20\ta1\nchr1\t30\t40\ta2\n")
            open(b, "w").write("chr1\t15\t25\tb1\n")

            result = run_cmd(["intersect", "-a", a, "-b", b])

        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertEqual(result.stdout, "chr1\t15\t20\ta1\n")

    def test_core_interval_tools_match_observed_bed6_behavior(self):
        with tempfile.TemporaryDirectory() as td:
            a, b, g = self.write_fixture(td)
            cases = [
                (["intersect", "-a", a, "-b", b, "-wa", "-wb"],
                 "chr1\t10\t20\ta1\t0\t+\tchr1\t15\t25\tb1\t5\t+\n"
                 "chr1\t10\t20\ta1\t0\t+\tchr1\t18\t22\tb2\t7\t-\n"
                 "chr2\t5\t10\ta3\t0\t+\tchr2\t1\t6\tb4\t2\t+\n"),
                (["intersect", "-a", a, "-b", b, "-c"],
                 "chr1\t10\t20\ta1\t0\t+\t2\nchr1\t30\t40\ta2\t0\t-\t0\nchr2\t5\t10\ta3\t0\t+\t1\n"),
                (["merge", "-i", b, "-c", "4,5", "-o", "collapse,sum"],
                 "chr1\t15\t25\tb1,b2\t12\nchr1\t40\t45\tb3\t9\nchr2\t1\t6\tb4\t2\n"),
                (["complement", "-i", b, "-g", g],
                 "chr1\t0\t15\nchr1\t25\t40\nchr1\t45\t50\nchr2\t0\t1\nchr2\t6\t12\n"),
                (["coverage", "-a", a, "-b", b],
                 "chr1\t10\t20\ta1\t0\t+\t2\t5\t10\t0.5000000\n"
                 "chr1\t30\t40\ta2\t0\t-\t0\t0\t10\t0.0000000\n"
                 "chr2\t5\t10\ta3\t0\t+\t1\t1\t5\t0.2000000\n"),
                (["genomecov", "-i", b, "-g", g, "-bg"],
                 "chr1\t15\t18\t1\nchr1\t18\t22\t2\nchr1\t22\t25\t1\nchr1\t40\t45\t1\nchr2\t1\t6\t1\n"),
                (["closest", "-a", a, "-b", b, "-d"],
                 "chr1\t10\t20\ta1\t0\t+\tchr1\t15\t25\tb1\t5\t+\t0\n"
                 "chr1\t10\t20\ta1\t0\t+\tchr1\t18\t22\tb2\t7\t-\t0\n"
                 "chr1\t30\t40\ta2\t0\t-\tchr1\t40\t45\tb3\t9\t-\t1\n"
                 "chr2\t5\t10\ta3\t0\t+\tchr2\t1\t6\tb4\t2\t+\t0\n"),
                (["subtract", "-a", a, "-b", b],
                 "chr1\t10\t15\ta1\t0\t+\nchr1\t30\t40\ta2\t0\t-\nchr2\t6\t10\ta3\t0\t+\n"),
                (["makewindows", "-g", g, "-w", "20"],
                 "chr1\t0\t20\nchr1\t20\t40\nchr1\t40\t50\nchr2\t0\t12\n"),
                (["slop", "-i", a, "-g", g, "-b", "3"],
                 "chr1\t7\t23\ta1\t0\t+\nchr1\t27\t43\ta2\t0\t-\nchr2\t2\t12\ta3\t0\t+\n"),
                (["flank", "-i", a, "-g", g, "-l", "2", "-r", "3"],
                 "chr1\t8\t10\ta1\t0\t+\nchr1\t20\t23\ta1\t0\t+\n"
                 "chr1\t28\t30\ta2\t0\t-\nchr1\t40\t43\ta2\t0\t-\n"
                 "chr2\t3\t5\ta3\t0\t+\nchr2\t10\t12\ta3\t0\t+\n"),
                (["jaccard", "-a", a, "-b", b],
                 "intersection\tunion\tjaccard\tn_intersections\n6\t39\t0.153846\t2\n"),
            ]
            for args, expected in cases:
                with self.subTest(args=args):
                    result = run_cmd(args)
                    self.assertEqual(result.returncode, 0, result.stderr)
                    self.assertEqual(result.stdout, expected)

    def test_map_and_groupby_summarize_columns(self):
        with tempfile.TemporaryDirectory() as td:
            a = os.path.join(td, "a.bed")
            b = os.path.join(td, "b.bed")
            t = os.path.join(td, "t.tsv")
            with open(a, "w") as fh:
                fh.write("chr1\t10\t30\twin1\nchr1\t35\t50\twin2\n")
            with open(b, "w") as fh:
                fh.write("chr1\t12\t20\tx\t5\nchr1\t18\t25\ty\t7\nchr1\t40\t44\tz\t3\n")
            with open(t, "w") as fh:
                fh.write("A\tone\t5\nA\ttwo\t7\nB\tone\t3\n")

            mapped = run_cmd(["map", "-a", a, "-b", b, "-c", "4,5", "-o", "collapse,mean"])
            grouped = run_cmd(["groupby", "-i", t, "-g", "1", "-c", "2,3", "-o", "collapse,sum"])

        self.assertEqual(mapped.stdout, "chr1\t10\t30\twin1\tx,y\t6\nchr1\t35\t50\twin2\tz\t3\n")
        self.assertEqual(grouped.stdout, "A\tone,two\t12\nB\tone\t3\n")

    def test_overlap_appends_overlap_or_distance(self):
        data = "chr1\t10\t20\tA\tchr1\t15\t25\tB\nchr1\t10\t20\tC\tchr1\t25\t35\tD\n"
        result = run_cmd(["overlap", "-i", "stdin", "-cols", "2,3,6,7"], stdin=data)
        self.assertEqual(result.stdout, "chr1\t10\t20\tA\tchr1\t15\t25\tB\t5\nchr1\t10\t20\tC\tchr1\t25\t35\tD\t-5\n")


if __name__ == "__main__":
    unittest.main()
