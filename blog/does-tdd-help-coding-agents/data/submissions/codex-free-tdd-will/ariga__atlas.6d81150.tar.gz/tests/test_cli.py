import os
import sqlite3
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
CLI = ROOT / "src" / "atlas_cli.py"


def run_cli(*args, cwd=None):
    return subprocess.run(
        [sys.executable, str(CLI), *args],
        cwd=cwd,
        text=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
    )


class AtlasCliTests(unittest.TestCase):
    def test_schema_fmt_rewrites_hcl_file_and_prints_name(self):
        with tempfile.TemporaryDirectory() as td:
            path = Path(td) / "schema.hcl"
            path.write_text('table   "users"   {\n  type =    int\n}\n')

            proc = run_cli("schema", "fmt", str(path))

            self.assertEqual(proc.returncode, 0, proc.stderr)
            self.assertEqual(proc.stdout, f"{path}\n")
            self.assertEqual(path.read_text(), 'table "users" {\n  type = int\n}\n')

    def test_schema_inspect_prints_sqlite_tables(self):
        with tempfile.TemporaryDirectory() as td:
            db = Path(td) / "app.db"
            con = sqlite3.connect(db)
            con.executescript(
                """
                CREATE TABLE users (
                  id integer NOT NULL PRIMARY KEY,
                  name text,
                  age int DEFAULT 42
                );
                """
            )
            con.close()

            proc = run_cli("schema", "inspect", "-u", f"sqlite://{db}")

            self.assertEqual(proc.returncode, 0, proc.stderr)
            self.assertIn('table "users" {', proc.stdout)
            self.assertIn('column "id" {', proc.stdout)
            self.assertIn("type = integer", proc.stdout)
            self.assertIn("default = 42", proc.stdout)
            self.assertTrue(proc.stdout.rstrip().endswith('schema "main" {\n}'))

    def test_migrate_new_creates_sql_file_and_sum(self):
        with tempfile.TemporaryDirectory() as td:
            proc = run_cli("migrate", "new", "add_users", "--dir", f"file://{td}")

            self.assertEqual(proc.returncode, 0, proc.stderr)
            self.assertEqual(proc.stdout, "")
            files = sorted(p.name for p in Path(td).iterdir())
            self.assertEqual(len([f for f in files if f.endswith("_add_users.sql")]), 1)
            self.assertIn("atlas.sum", files)
            self.assertIn("_add_users.sql h1:", (Path(td) / "atlas.sum").read_text())


if __name__ == "__main__":
    unittest.main()
