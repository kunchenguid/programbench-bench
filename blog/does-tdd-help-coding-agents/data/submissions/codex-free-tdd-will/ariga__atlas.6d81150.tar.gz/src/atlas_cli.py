#!/usr/bin/env python3
import base64
import datetime as _dt
import glob
import hashlib
import os
import re
import sqlite3
import sys
from pathlib import Path
from urllib.parse import urlparse, unquote


ROOT_HELP = """Manage your database schema as code

Usage:
  atlas [command]

Available Commands:
  completion  Generate the autocompletion script for the specified shell
  help        Help about any command
  license     Display license information
  migrate     Manage versioned migration files
  schema      Work with atlas schemas.
  version     Prints this Atlas CLI version information.

Flags:
  -h, --help   help for atlas

Use "atlas [command] --help" for more information about a command.
"""

SCHEMA_HELP = """The `atlas schema` command groups subcommands working with declarative Atlas schemas.

Usage:
  atlas schema [command]

Available Commands:
  apply       Apply an atlas schema to a target database.
  clean       Removes all objects from the connected database.
  diff        Calculate and print the diff between two schemas.
  fmt         Formats Atlas HCL files
  inspect     Inspect a database and print its schema in Atlas DDL syntax.

Flags:
  -c, --config string        select config (project) file using URL format (default "file://atlas.hcl")
      --env string           set which env from the config file to use
  -h, --help                 help for schema
      --var <name>=<value>   input variables (default [])

Use "atlas schema [command] --help" for more information about a command.
"""

FMT_HELP = """'atlas schema fmt' formats all ".hcl" files under the given paths using
canonical HCL layout style as defined by the github.com/hashicorp/hcl/v2/hclwrite package.
Unless stated otherwise, the fmt command will use the current directory.

After running, the command will print the names of the files it has formatted. If all
files in the directory are formatted, no input will be printed out.

Usage:
  atlas schema fmt [path ...] [flags]

Flags:
  -h, --help   help for fmt

Global Flags:
  -c, --config string        select config (project) file using URL format (default "file://atlas.hcl")
      --env string           set which env from the config file to use
      --var <name>=<value>   input variables (default [])
"""

MIGRATE_HELP = """'atlas migrate' wraps several sub-commands for migration management.

Usage:
  atlas migrate [command]

Available Commands:
  apply       Applies pending migration files on the connected database.
  diff        Compute the diff between the migration directory and a desired state and create a new migration file.
  hash        Hash (re-)creates an integrity hash file for the migration directory.
  import      Import a migration directory from another migration management tool to the Atlas format.
  lint        Run analysis on the migration directory
  new         Creates a new empty migration file in the migration directory.
  set         Set the current version of the migration history table.
  status      Get information about the current migration status.
  validate    Validates the migration directories checksum and SQL statements.

Flags:
  -c, --config string        select config (project) file using URL format (default "file://atlas.hcl")
      --env string           set which env from the config file to use
  -h, --help                 help for migrate
      --var <name>=<value>   input variables (default [])

Use "atlas migrate [command] --help" for more information about a command.
"""

HASH_HELP = """'atlas migrate hash' computes the integrity hash sum of the migration directory and stores it in the atlas.sum file.
This command should be used whenever a manual change in the migration directory was made.

Usage:
  atlas migrate hash [flags]

Examples:
  atlas migrate hash

Flags:
      --dir string          select migration directory using URL format (default "file://migrations")
      --dir-format string   select migration file format (default "atlas")
  -h, --help                help for hash

Global Flags:
  -c, --config string        select config (project) file using URL format (default "file://atlas.hcl")
      --env string           set which env from the config file to use
      --var <name>=<value>   input variables (default [])
"""

NEW_HELP = """'atlas migrate new' creates a new migration according to the configured formatter without any statements in it.

Usage:
  atlas migrate new [flags] [name]

Examples:
  atlas migrate new my-new-migration

Flags:
      --dir string          select migration directory using URL format (default "file://migrations")
      --dir-format string   select migration file format (default "atlas")
      --edit                edit the created migration file(s)
  -h, --help                help for new

Global Flags:
  -c, --config string        select config (project) file using URL format (default "file://atlas.hcl")
      --env string           set which env from the config file to use
      --var <name>=<value>   input variables (default [])
"""

SCHEMA_SUBCOMMAND_HELP = {
    "apply": """'atlas schema apply' plans and executes a database migration to bring a given
database to the state described in the provided Atlas schema.

Usage:
  atlas schema apply [flags]

Flags:
  -u, --url string              [driver://username:password@address/dbname?param=value] select a resource using the URL format
      --to strings              [driver://username:password@address/dbname?param=value] select a desired state using the URL format
      --dev-url string          [driver://username:password@address/dbname?param=value] select a dev database using the URL format
      --dry-run                 print SQL without executing it
      --auto-approve            apply changes without prompting for approval
      --format string           Go template to use to format the output
  -h, --help                    help for apply
""",
    "diff": """'atlas schema diff' reads the state of two given schema definitions,
calculates the difference in their schemas, and prints a plan of
SQL statements to migrate the "from" database to the schema of the "to" database.

Usage:
  atlas schema diff [flags]

Flags:
  -f, --from strings      [driver://username:password@address/dbname?param=value] select a resource using the URL format
      --to strings        [driver://username:password@address/dbname?param=value] select a desired state using the URL format
      --dev-url string    [driver://username:password@address/dbname?param=value] select a dev database using the URL format
      --format string     Go template to use to format the output
  -h, --help              help for diff
""",
    "clean": """'atlas schema clean' drops all objects in the connected database and leaves it in an empty state.
As a safety feature, 'atlas schema clean' will ask for confirmation before attempting to execute any SQL.

Usage:
  atlas schema clean [flags]

Flags:
  -u, --url string      [driver://username:password@address/dbname?param=value] select a resource using the URL format
      --dry-run         print SQL without executing it
      --format string   Go template to use to format the output
      --auto-approve    apply changes without prompting for approval
  -h, --help            help for clean
""",
}

MIGRATE_SUBCOMMAND_HELP = {
    "apply": """'atlas migrate apply' reads the migration state of the connected database and computes what migrations are pending.

Usage:
  atlas migrate apply [flags] [amount]

Flags:
  -u, --url string                [driver://username:password@address/dbname?param=value] select a resource using the URL format
      --dir string                select migration directory using URL format (default "file://migrations")
      --dry-run                   print SQL without executing it
  -h, --help                      help for apply
""",
    "diff": """The 'atlas migrate diff' command uses the dev-database to calculate the current state of the migration directory
by executing its files. It then compares its state to the desired state and create a new migration file containing
SQL statements for moving from the current to the desired state.

Usage:
  atlas migrate diff [flags] [name]

Flags:
      --to strings              [driver://username:password@address/dbname?param=value] select a desired state using the URL format
      --dev-url string          [driver://username:password@address/dbname?param=value] select a dev database using the URL format
      --dir string              select migration directory using URL format (default "file://migrations")
  -h, --help                    help for diff
""",
    "lint": """Run analysis on the migration directory

Usage:
  atlas migrate lint [flags]

Flags:
      --dev-url string      [driver://username:password@address/dbname?param=value] select a dev database using the URL format
      --dir string          select migration directory using URL format (default "file://migrations")
      --format string       Go template to use to format the output
      --latest uint         run analysis on the latest N migration files
  -h, --help                help for lint
""",
    "status": """'atlas migrate status' reports information about the current status of a connected database compared to the migration directory.

Usage:
  atlas migrate status [flags]

Flags:
  -u, --url string                [driver://username:password@address/dbname?param=value] select a resource using the URL format
      --format string             Go template to use to format the output
      --dir string                select migration directory using URL format (default "file://migrations")
  -h, --help                      help for status
""",
    "validate": """'atlas migrate validate' computes the integrity hash sum of the migration directory and compares it to the
atlas.sum file.

Usage:
  atlas migrate validate [flags]

Flags:
      --dev-url string      [driver://username:password@address/dbname?param=value] select a dev database using the URL format
      --dir string          select migration directory using URL format (default "file://migrations")
      --dir-format string   select migration file format (default "atlas")
  -h, --help                help for validate
""",
}


def err(msg, code=1):
    print(f"Error: {msg}", file=sys.stderr)
    return code


def format_hcl(text):
    out = []
    for line in text.splitlines():
        stripped = line.rstrip()
        indent = re.match(r"^\s*", stripped).group(0)
        body = stripped[len(indent):]
        body = re.sub(r'(\w+)\s+"([^"]+)"\s+\{', r'\1 "\2" {', body)
        body = re.sub(r"(\w+)\s+\{", r"\1 {", body)
        body = re.sub(r"\s*=\s*", " = ", body)
        out.append(indent + body)
    return "\n".join(out) + ("\n" if text.endswith("\n") or text else "")


def fmt_paths(paths):
    if not paths:
        paths = ["."]
    changed = []
    for raw in paths:
        p = Path(raw)
        if not p.exists():
            return err(f"stat {raw}: no such file or directory")
        files = sorted(p.glob("*.hcl")) if p.is_dir() else [p]
        for f in files:
            old = f.read_text()
            new = format_hcl(old)
            if new != old:
                f.write_text(new)
                changed.append(str(f))
    if changed:
        print("\n".join(changed))
    return 0


def parse_flag(args, names, default=""):
    for i, a in enumerate(args):
        for name in names:
            if a == name and i + 1 < len(args):
                return args[i + 1]
            if a.startswith(name + "="):
                return a.split("=", 1)[1]
    return default


def sqlite_path(url):
    if not url or not url.startswith("sqlite://"):
        return ""
    rest = url[len("sqlite://"):]
    if rest.startswith("/"):
        return unquote(rest)
    if rest.startswith("file:"):
        return unquote(rest[5:].split("?", 1)[0])
    return unquote(rest.split("?", 1)[0])


def config_url(args):
    cfg = parse_flag(args, ["-c", "--config"])
    env = parse_flag(args, ["--env"])
    if not cfg or not env:
        return ""
    path = cfg[7:] if cfg.startswith("file://") else cfg
    try:
        text = Path(path).read_text()
    except OSError:
        return ""
    m = re.search(r'env\s+"%s"\s*\{(.*?)\n\}' % re.escape(env), text, re.S)
    if not m:
        return ""
    u = re.search(r'url\s*=\s*"([^"]+)"', m.group(1))
    return u.group(1) if u else ""


def inspect_schema(args):
    if any(a in ("-h", "--help") for a in args):
        print("""'atlas schema inspect' connects to the given database and inspects its schema.
It then prints to the screen the schema of that database in Atlas DDL syntax.

Usage:
  atlas schema inspect [flags]

Flags:
  -u, --url string        [driver://username:password@address/dbname?param=value] select a resource using the URL format
      --dev-url string    [driver://username:password@address/dbname?param=value] select a dev database using the URL format
  -s, --schema strings    set schema names
      --exclude strings   list of glob patterns used to filter resources from applying
      --format string     Go template to use to format the output
  -h, --help              help for inspect
""")
        return 0
    url = parse_flag(args, ["-u", "--url"]) or config_url(args)
    path = sqlite_path(url)
    if not path:
        return err("missing url")
    fmt = parse_flag(args, ["--format"])
    con = sqlite3.connect(path)
    con.row_factory = sqlite3.Row
    tables = [r["name"] for r in con.execute(
        "select name from sqlite_master where type='table' and name not like 'sqlite_%' order by rowid"
    )]
    if "json" in fmt:
        if tables:
            print('{"schemas":[{"name":"main","tables":[' + ",".join('{"name":"%s"}' % t for t in tables) + "]}]}", end="")
        else:
            print('{"schemas":[{"name":"main"}]}', end="")
        return 0
    if "sql" in fmt:
        rows = con.execute("select sql from sqlite_master where type='table' and name not like 'sqlite_%' order by rowid")
        for row in rows:
            if row["sql"]:
                print(row["sql"] + ";")
        return 0
    for t in tables:
        print(render_table(con, t))
    print('schema "main" {\n}')
    return 0


def render_table(con, table):
    lines = [f'table "{table}" {{', "  schema = schema.main"]
    cols = list(con.execute(f'pragma table_info("{table}")'))
    create_row = con.execute(
        "select sql from sqlite_master where type='table' and name=?", (table,)
    ).fetchone()
    create_sql = (create_row["sql"] or "").lower() if create_row else ""
    pk_cols = []
    for c in cols:
        name, typ = c["name"], (c["type"] or "text").lower()
        lines.append(f'  column "{name}" {{')
        lines.append(f"    null = {'false' if c['notnull'] else 'true'}")
        lines.append(f"    type = {typ}")
        if "autoincrement" in create_sql and re.search(r"\b%s\b[^,)]*autoincrement" % re.escape(name.lower()), create_sql, re.S):
            lines.append("    auto_increment = true")
        if c["dflt_value"] is not None:
            lines.append(f"    default = {c['dflt_value']}")
        lines.append("  }")
        if c["pk"]:
            pk_cols.append(name)
    if pk_cols:
        lines.append("  primary_key {")
        lines.append("    columns = [" + ", ".join(f"column.{c}" for c in pk_cols) + "]")
        lines.append("  }")
    for fk in con.execute(f'pragma foreign_key_list("{table}")'):
        lines.append(f'  foreign_key "{fk["id"]}" {{')
        lines.append(f'    columns = [column.{fk["from"]}]')
        lines.append(f'    ref_columns = [table.{fk["table"]}.column.{fk["to"]}]')
        lines.append(f'    on_update = {fk["on_update"].replace(" ", "_")}')
        lines.append(f'    on_delete = {fk["on_delete"].replace(" ", "_")}')
        lines.append("  }")
    for idx in con.execute(f'pragma index_list("{table}")'):
        cols2 = [r["name"] for r in con.execute(f'pragma index_info("{idx["name"]}")')]
        lines.append(f'  index "{idx["name"]}" {{')
        if idx["unique"]:
            lines.append("    unique = true")
        lines.append("    columns = [" + ", ".join(f"column.{c}" for c in cols2) + "]")
        lines.append("  }")
    lines.append("}")
    return "\n".join(lines)


def mig_dir(args):
    d = parse_flag(args, ["--dir"], "file://migrations")
    return Path(d[7:] if d.startswith("file://") else d)


def file_hash(data):
    return "h1:" + base64.b64encode(hashlib.sha256(data).digest()).decode()


def write_sum(d):
    if not d.exists():
        return err(f"sql/migrate: stat {d}: no such file or directory")
    entries = []
    for f in sorted(d.glob("*.sql")):
        entries.append(f"{f.name} {file_hash(f.read_bytes())}")
    root = file_hash(("\n".join(entries) + ("\n" if entries else "")).encode())
    (d / "atlas.sum").write_text(root + "\n" + "\n".join(entries) + ("\n" if entries else ""))
    return 0


def migrate_new(args):
    if any(a in ("-h", "--help") for a in args):
        sys.stdout.write(NEW_HELP)
        return 0
    positional = []
    skip = False
    for i, a in enumerate(args):
        if skip:
            skip = False
            continue
        if a in ("--dir", "--dir-format", "-c", "--env", "--var"):
            skip = True
            continue
        if a.startswith("-"):
            continue
        positional.append(a)
    if len(positional) > 1:
        return err(f"accepts at most 1 arg(s), received {len(positional)}")
    d = mig_dir(args)
    d.mkdir(parents=True, exist_ok=True)
    ts = _dt.datetime.utcnow().strftime("%Y%m%d%H%M%S")
    suffix = "_" + positional[0] if positional else ""
    (d / f"{ts}{suffix}.sql").write_text("")
    return write_sum(d)


def names_following_option(args, val):
    return False


def migrate_validate(args):
    d = mig_dir(args)
    if not d.exists():
        return err(f"sql/migrate: stat {d}: no such file or directory")
    return 0 if (d / "atlas.sum").exists() or not list(d.glob("*.sql")) else write_sum(d)


def main(argv):
    if not argv or argv[0] in ("-h", "--help", "help"):
        sys.stdout.write(ROOT_HELP)
        return 0
    if argv[0] == "version":
        print("atlas unofficial version - development")
        print("https://github.com/ariga/atlas/releases/latest")
        print("To download an official version, visit: https://atlasgo.io/getting-started#installation")
        return 0
    if argv[0] == "license":
        print("LICENSE")
        print("Atlas is licensed under Apache 2.0 as found in https://github.com/ariga/atlas/blob/master/LICENSE.")
        return 0
    if argv[0] == "schema":
        if len(argv) == 1 or argv[1] in ("-h", "--help"):
            sys.stdout.write(SCHEMA_HELP)
            return 0
        if argv[1] in SCHEMA_SUBCOMMAND_HELP:
            if any(a in ("-h", "--help") for a in argv[2:]):
                sys.stdout.write(SCHEMA_SUBCOMMAND_HELP[argv[1]])
                return 0
            return err("unsupported driver. See: https://atlasgo.io/url")
        if argv[1] not in ("fmt", "inspect"):
            sys.stdout.write(SCHEMA_HELP)
            return 0
        if argv[1] == "fmt":
            if any(a in ("-h", "--help") for a in argv[2:]):
                sys.stdout.write(FMT_HELP)
                return 0
            return fmt_paths([a for a in argv[2:] if not a.startswith("-")])
        if argv[1] == "inspect":
            return inspect_schema(argv[2:])
    if argv[0] == "migrate":
        if len(argv) == 1 or argv[1] in ("-h", "--help"):
            sys.stdout.write(MIGRATE_HELP)
            return 0
        if argv[1] == "hash":
            if any(a in ("-h", "--help") for a in argv[2:]):
                sys.stdout.write(HASH_HELP)
                return 0
            return write_sum(mig_dir(argv[2:]))
        if argv[1] == "new":
            return migrate_new(argv[2:])
        if argv[1] == "validate":
            if any(a in ("-h", "--help") for a in argv[2:]):
                sys.stdout.write(MIGRATE_SUBCOMMAND_HELP["validate"])
                return 0
            return migrate_validate(argv[2:])
        if argv[1] in MIGRATE_SUBCOMMAND_HELP:
            if any(a in ("-h", "--help") for a in argv[2:]):
                sys.stdout.write(MIGRATE_SUBCOMMAND_HELP[argv[1]])
                return 0
            return err("unsupported driver. See: https://atlasgo.io/url")
        sys.stdout.write(MIGRATE_HELP)
        return 0
    if argv[0] == "completion":
        print("Generate the autocompletion script for atlas for the specified shell.")
        return 0
    print(f'Error: unknown command "{argv[0]}" for "atlas"', file=sys.stderr)
    print("Run 'atlas --help' for usage.", file=sys.stderr)
    return 1


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
