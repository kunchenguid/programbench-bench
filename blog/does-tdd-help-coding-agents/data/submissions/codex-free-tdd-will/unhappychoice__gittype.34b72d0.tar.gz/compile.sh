#!/bin/bash
set -e
rm -f executable
cp src/gittype.py executable
chmod +x executable
