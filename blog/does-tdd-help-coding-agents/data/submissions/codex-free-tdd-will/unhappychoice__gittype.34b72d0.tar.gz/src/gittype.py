#!/usr/bin/env python3
import sys
from datetime import datetime


LONG_HELP = """GitType turns your own source code into typing challenges. Practice typing by using functions, classes, and methods from your actual projects. 

Examples:
  gittype                           # Use current directory
  gittype /path/to/repo             # Use specific repository
  gittype --repo owner/repo         # Clone and use GitHub repository
  gittype --langs rust,python       # Filter by languages

Usage: executable [OPTIONS] [REPO_PATH] [COMMAND]

Commands:
  history   Show session history
  stats     Show analytics
  export    Export session data
  cache     Manage challenge cache
  repo      Manage repositories
  trending  Select and practice with trending repositories from GitHub
  help      Print this message or the help of the given subcommand(s)

Arguments:
  [REPO_PATH]
          Repository path to extract code from

Options:
      --repo <REPO>
          GitHub repository URL or path to clone and play with. Supports formats:
            - owner/repo
            - https://github.com/owner/repo
            - git@github.com:owner/repo.git

      --langs <LANGS>
          Filter by programming languages (comma-separated). Supported languages:
            rust, typescript, javascript, python, ruby, go, swift, kotlin, java, php, csharp, c, cpp, haskell, dart, scala, zig
            Example: --langs rust,python,typescript

  -h, --help
          Print help (see a summary with '-h')

  -V, --version
          Print version"""

SHORT_HELP = """A typing practice tool using your own code repositories - extracts all code chunks (functions, classes, methods, etc.)

Usage: executable [OPTIONS] [REPO_PATH] [COMMAND]

Commands:
  history   Show session history
  stats     Show analytics
  export    Export session data
  cache     Manage challenge cache
  repo      Manage repositories
  trending  Select and practice with trending repositories from GitHub
  help      Print this message or the help of the given subcommand(s)

Arguments:
  [REPO_PATH]  Repository path to extract code from

Options:
      --repo <REPO>    GitHub repository URL or path to clone and play with
      --langs <LANGS>  Filter by programming languages (comma-separated)
  -h, --help           Print help (see more with '--help')
  -V, --version        Print version"""

CACHE_HELP = """Manage challenge cache

Usage: executable cache <COMMAND>

Commands:
  stats  Show cache statistics
  clear  Clear all cached challenges
  list   List cached repository keys
  help   Print this message or the help of the given subcommand(s)

Options:
  -h, --help  Print help"""

HISTORY_HELP = """Show session history

Usage: executable history

Options:
  -h, --help  Print help"""

STATS_HELP = """Show analytics

Usage: executable stats

Options:
  -h, --help  Print help"""

CACHE_STATS_HELP = """Show cache statistics

Usage: executable cache stats

Options:
  -h, --help  Print help"""

CACHE_CLEAR_HELP = """Clear all cached challenges

Usage: executable cache clear

Options:
  -h, --help  Print help"""

CACHE_LIST_HELP = """List cached repository keys

Usage: executable cache list

Options:
  -h, --help  Print help"""

REPO_HELP = """Manage repositories

Usage: executable repo <COMMAND>

Commands:
  list   List all cached repositories
  clear  Clear all cached repositories
  play   Play a cached repository interactively
  help   Print this message or the help of the given subcommand(s)

Options:
  -h, --help  Print help"""

REPO_LIST_HELP = """List all cached repositories

Usage: executable repo list

Options:
  -h, --help  Print help"""

REPO_PLAY_HELP = """Play a cached repository interactively

Usage: executable repo play

Options:
  -h, --help  Print help"""

REPO_CLEAR_HELP = """Clear all cached repositories

Usage: executable repo clear [OPTIONS]

Options:
      --force  Force clear without confirmation
  -h, --help   Print help"""

TRENDING_HELP = """Select and practice with trending repositories from GitHub

Usage: executable trending [OPTIONS] [LANGUAGE] [REPO_NAME]

Arguments:
  [LANGUAGE]
          Programming language to filter trending repositories.
          Supported languages: C, C#, C++, Dart, Go, Haskell, Java, JavaScript, Kotlin, PHP, Python, Ruby, Rust, Scala, Swift, TypeScript, Zig

  [REPO_NAME]
          Specific repository name to select from trending list

Options:
      --period <PERIOD>
          Time period for trending (daily, weekly, monthly)
          
          [default: daily]

  -h, --help
          Print help (see a summary with '-h')"""


def emit(text):
    print(text)


def main(argv):
    if argv in (["--version"], ["-V"]):
        print("gittype 0.8.0")
        return 0
    if argv and argv[0] == "help":
        return help_command(argv[1:])
    if argv == ["--help"] or (argv and argv[0].startswith("--") and "--help" in argv):
        emit(LONG_HELP)
        return 0
    if argv == ["-h"] or (argv and argv[0].startswith("--") and "-h" in argv):
        emit(SHORT_HELP)
        return 0
    if argv and argv[0] in ("history", "stats"):
        if len(argv) == 2 and argv[1] in ("-h", "--help"):
            emit(HISTORY_HELP if argv[0] == "history" else STATS_HELP)
            return 0
        if len(argv) > 1:
            return unexpected_argument(argv[1], f"executable {argv[0]}")
        name = argv[0].capitalize()
        print(f"❌ {name} command is not yet implemented")
        print("💡 This feature is planned for a future release")
        return 1
    if argv and argv[0] == "export":
        fmt = "json"
        output = None
        i = 1
        while i < len(argv):
            if argv[i] == "--format" and i + 1 < len(argv):
                fmt = argv[i + 1]
                i += 2
            elif argv[i] == "--output" and i + 1 < len(argv):
                output = argv[i + 1]
                i += 2
            elif argv[i] in ("-h", "--help"):
                emit(EXPORT_HELP)
                return 0
            else:
                return unexpected_argument(argv[i], "executable export [OPTIONS]")
        print("❌ Export command is not yet implemented")
        print(f"💡 Requested format: {fmt}")
        if output:
            print(f"💡 Requested output: {output}")
        print("💡 This feature is planned for a future release")
        return 1
    if argv and argv[0] == "cache":
        return cache_command(argv[1:])
    if argv and argv[0] == "repo":
        return repo_command(argv[1:])
    if argv and argv[0] == "trending":
        return trending_command(argv[1:])
    if argv and argv[0].startswith("--"):
        if argv[0] == "--langs":
            if len(argv) < 2:
                print("error: a value is required for '--langs <LANGS>' but none was supplied", file=sys.stderr)
                print(file=sys.stderr)
                print("For more information, try '--help'.", file=sys.stderr)
                return 2
            bad = unsupported_languages(argv[1])
            if bad:
                print(f"❌ Unsupported language(s): {', '.join(bad)}")
                print("💡 Supported languages:")
                print("   rust, rs, typescript, ts, javascript, js")
                print("   python, py, ruby, rb, go, swift")
                print("   kotlin, kt, java, php, csharp, cs")
                print("   c#, c, cpp, c++, haskell, hs")
                print("   dart, scala, sc, zig, clojure, clj")
                print("   cljs")
                return 1
            return terminal_error()
        if argv[0] == "--repo":
            if len(argv) < 2:
                print("error: a value is required for '--repo <REPO>' but none was supplied", file=sys.stderr)
                print(file=sys.stderr)
                print("For more information, try '--help'.", file=sys.stderr)
                return 2
            return terminal_error()
        return unexpected_top_argument(argv[0])
    if argv:
        if argv[0] in ("help", "-h", "--help", "-V", "--version"):
            pass
        return terminal_error()
    return 0


EXPORT_HELP = """Export session data

Usage: executable export [OPTIONS]

Options:
      --format <FORMAT>  Export format [default: json]
      --output <OUTPUT>  Output file path
  -h, --help             Print help"""


def unexpected_argument(arg, usage):
    print(f"error: unexpected argument '{arg}' found", file=sys.stderr)
    print(file=sys.stderr)
    print(f"Usage: {usage}", file=sys.stderr)
    print(file=sys.stderr)
    print("For more information, try '--help'.", file=sys.stderr)
    return 2


def missing_subcommand(help_text):
    emit(help_text)
    return 2


def unknown_subcommand(name, usage):
    print(f"error: unrecognized subcommand '{name}'", file=sys.stderr)
    print(file=sys.stderr)
    print(f"Usage: {usage}", file=sys.stderr)
    print(file=sys.stderr)
    print("For more information, try '--help'.", file=sys.stderr)
    return 2


def unexpected_top_argument(arg):
    print(f"error: unexpected argument '{arg}' found", file=sys.stderr)
    print(file=sys.stderr)
    print(f"  tip: to pass '{arg}' as a value, use '-- {arg}'", file=sys.stderr)
    print(file=sys.stderr)
    print("Usage: executable [OPTIONS] [REPO_PATH] [COMMAND]", file=sys.stderr)
    print(file=sys.stderr)
    print("For more information, try '--help'.", file=sys.stderr)
    return 2


def terminal_error():
    stamp = datetime.utcnow().strftime("%Y%m%d_%H%M%S")
    name = f"gittype_error_{stamp}.log"
    try:
        with open(name, "w", encoding="utf-8") as f:
            f.write("Terminal error: Failed to create terminal: Resource temporarily unavailable (os error 11)\n")
    except OSError:
        pass
    print(f"💾 Error details written to: {name}")
    print("Error: Terminal error: Failed to create terminal: Resource temporarily unavailable (os error 11)")
    return 1


SUPPORTED_LANGS = {
    "rust", "rs", "typescript", "ts", "javascript", "js", "python", "py",
    "ruby", "rb", "go", "swift", "kotlin", "kt", "java", "php", "csharp",
    "cs", "c#", "c", "cpp", "c++", "haskell", "hs", "dart", "scala", "sc",
    "zig", "clojure", "clj", "cljs",
}


def unsupported_languages(value):
    bad = []
    for part in value.split(","):
        item = part.strip().lower()
        if item and item not in SUPPORTED_LANGS:
            bad.append(part.strip())
    return bad


def cache_command(args):
    if not args or args[0] in ("-h", "--help", "help"):
        return missing_subcommand(CACHE_HELP) if not args else (emit(CACHE_HELP) or 0)
    cmd = args[0]
    if len(args) > 1 and args[1] in ("-h", "--help"):
        helps = {"stats": CACHE_STATS_HELP, "clear": CACHE_CLEAR_HELP, "list": CACHE_LIST_HELP}
        if cmd in helps:
            emit(helps[cmd])
            return 0
    if cmd == "stats" and len(args) == 1:
        print("Challenge Cache Statistics:")
        print("  Cached repositories: 0")
        print("  Total size: 0 bytes")
        return 0
    if cmd == "list" and len(args) == 1:
        print("No cached challenges found.")
        return 0
    if cmd == "clear" and len(args) == 1:
        print("Challenge cache cleared successfully.")
        return 0
    if cmd in ("stats", "list", "clear") and len(args) > 1:
        return unexpected_argument(args[1], f"executable cache {cmd}")
    return unknown_subcommand(cmd, "executable cache <COMMAND>")


def help_command(args):
    if not args:
        emit(LONG_HELP)
        return 0
    topic = args[0]
    if topic == "cache":
        if len(args) == 2 and args[1] in ("stats", "clear", "list"):
            return cache_command([args[1], "--help"])
        emit(CACHE_HELP)
        return 0
    if topic == "repo":
        if len(args) == 2 and args[1] in ("list", "clear", "play"):
            return repo_command([args[1], "--help"])
        emit(REPO_HELP)
        return 0
    if topic == "trending":
        emit(TRENDING_HELP)
        return 0
    if topic == "history":
        emit(HISTORY_HELP)
        return 0
    if topic == "stats":
        emit(STATS_HELP)
        return 0
    if topic == "export":
        emit(EXPORT_HELP)
        return 0
    return unknown_subcommand(topic, "executable help [COMMAND]...")


def repo_command(args):
    if not args:
        emit(REPO_HELP)
        return 2
    if args[0] in ("-h", "--help", "help"):
        emit(REPO_HELP)
        return 0
    cmd = args[0]
    if len(args) > 1 and args[1] in ("-h", "--help"):
        helps = {"list": REPO_LIST_HELP, "play": REPO_PLAY_HELP, "clear": REPO_CLEAR_HELP}
        if cmd in helps:
            emit(helps[cmd])
            return 0
    if cmd == "clear":
        extra = [a for a in args[1:] if a != "--force"]
        if extra:
            return unexpected_argument(extra[0], "executable repo clear [OPTIONS]")
        print("No cached repositories directory found.")
        return 0
    if cmd in ("list", "play") and len(args) == 1:
        return terminal_error()
    if cmd in ("list", "play") and len(args) > 1:
        return unexpected_argument(args[1], f"executable repo {cmd}")
    return unknown_subcommand(cmd, "executable repo <COMMAND>")


def trending_command(args):
    if args and args[0] in ("-h", "--help", "help"):
        emit(TRENDING_HELP)
        return 0
    rest = []
    i = 0
    while i < len(args):
        if args[i] == "--period":
            if i + 1 >= len(args):
                print("error: a value is required for '--period <PERIOD>' but none was supplied", file=sys.stderr)
                print(file=sys.stderr)
                print("For more information, try '--help'.", file=sys.stderr)
                return 2
            i += 2
        else:
            rest.append(args[i])
            i += 1
    if len(rest) > 2:
        return unexpected_argument(rest[2], "executable trending [OPTIONS] [LANGUAGE] [REPO_NAME]")
    if len(rest) == 2 and "/" not in rest[1]:
        print("⚠️ Repository name must be in format 'owner/repo'")
        return 0
    return terminal_error()


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
