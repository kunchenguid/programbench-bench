import os
import subprocess
import unittest


ROOT = os.path.dirname(os.path.dirname(__file__))
EXE = os.path.join(ROOT, "executable")


def run_cli(*args):
    return subprocess.run(
        [EXE, *args],
        cwd=ROOT,
        text=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
    )


class GitTypeCliTests(unittest.TestCase):
    def test_version(self):
        result = run_cli("--version")
        self.assertEqual(result.returncode, 0)
        self.assertEqual(result.stdout, "gittype 0.8.0\n")

    def test_long_help_contains_documented_interface(self):
        result = run_cli("--help")
        self.assertEqual(result.returncode, 0)
        self.assertIn("GitType turns your own source code into typing challenges.", result.stdout)
        self.assertIn("Usage: executable [OPTIONS] [REPO_PATH] [COMMAND]", result.stdout)
        self.assertIn("  cache     Manage challenge cache", result.stdout)
        self.assertIn("      --langs <LANGS>", result.stdout)

    def test_history_is_planned_stub(self):
        result = run_cli("history")
        self.assertEqual(result.returncode, 1)
        self.assertEqual(
            result.stdout,
            "❌ History command is not yet implemented\n"
            "💡 This feature is planned for a future release\n",
        )

    def test_cache_stats_empty(self):
        result = run_cli("cache", "stats")
        self.assertEqual(result.returncode, 0)
        self.assertEqual(
            result.stdout,
            "Challenge Cache Statistics:\n"
            "  Cached repositories: 0\n"
            "  Total size: 0 bytes\n",
        )

    def test_unsupported_language_is_reported_before_interactive_start(self):
        result = run_cli("--langs", "bogus")
        self.assertEqual(result.returncode, 1)
        self.assertIn("❌ Unsupported language(s): bogus\n", result.stdout)
        self.assertIn("   rust, rs, typescript, ts, javascript, js\n", result.stdout)

    def test_repo_clear_empty(self):
        result = run_cli("repo", "clear")
        self.assertEqual(result.returncode, 0)
        self.assertEqual(result.stdout, "No cached repositories directory found.\n")

    def test_trending_specific_repo_requires_owner_repo_format(self):
        result = run_cli("trending", "Rust", "foo")
        self.assertEqual(result.returncode, 0)
        self.assertEqual(result.stdout, "⚠️ Repository name must be in format 'owner/repo'\n")


if __name__ == "__main__":
    unittest.main()
