#!/usr/bin/env python3
import os, subprocess, tempfile, pathlib, json, re, shutil
ROOT = pathlib.Path(__file__).resolve().parents[1]
BIN = ROOT / 'executable'

def run(args, cwd=None, env=None):
    e = os.environ.copy()
    if env: e.update(env)
    return subprocess.run([str(BIN)] + args, cwd=cwd, env=e, text=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)

def assert_eq(a,b):
    assert a == b, f'expected {b!r}, got {a!r}'

def test_version():
    r = run(['version'])
    assert_eq(r.returncode, 0)
    assert_eq(r.stdout, '2.37.1\n')

def test_allow_and_export_bash_envrc():
    with tempfile.TemporaryDirectory() as td:
        home = pathlib.Path(td) / 'home'
        proj = pathlib.Path(td) / 'proj'
        proj.mkdir()
        (proj / '.envrc').write_text('export FOO=foo\nPATH_add bin\n')
        env = {'HOME': str(home), 'XDG_DATA_HOME': str(pathlib.Path(td) / 'data'), 'DIRENV_LOG_FORMAT': '-'}
        r = run(['export', 'bash'], cwd=proj, env=env)
        assert r.returncode == 1
        assert 'is blocked' in r.stderr
        r = run(['allow', '.'], cwd=proj, env=env)
        assert_eq(r.returncode, 0)
        r = run(['export', 'bash'], cwd=proj, env=env)
        assert_eq(r.returncode, 0)
        assert "export FOO=$'foo';" in r.stdout
        assert f"{proj}/bin" in r.stdout

def test_exec_runs_command_with_loaded_environment():
    with tempfile.TemporaryDirectory() as td:
        home = pathlib.Path(td) / 'home'
        proj = pathlib.Path(td) / 'proj'
        proj.mkdir()
        (proj / '.envrc').write_text('export FOO=from-envrc\n')
        env = {'HOME': str(home), 'XDG_DATA_HOME': str(pathlib.Path(td) / 'data'), 'DIRENV_LOG_FORMAT': '-'}
        assert_eq(run(['allow', '.'], cwd=proj, env=env).returncode, 0)
        r = run(['exec', '.', 'bash', '-lc', 'printf "$FOO"'], cwd=proj, env=env)
        assert_eq(r.returncode, 0)
        assert_eq(r.stdout, 'from-envrc')

def test_dotenv_converts_file_to_exports():
    with tempfile.TemporaryDirectory() as td:
        p = pathlib.Path(td) / '.env'
        p.write_text('FOO=foo\nBAR="two words"\nexport ZED=zed\n')
        r = run(['dotenv', 'bash', str(p)])
        assert_eq(r.returncode, 0)
        assert "export FOO=$'foo';" in r.stdout
        assert "export BAR=$'two words';" in r.stdout
        assert "export ZED=$'zed';" in r.stdout

def main():
    tests=[test_version, test_allow_and_export_bash_envrc, test_exec_runs_command_with_loaded_environment, test_dotenv_converts_file_to_exports]
    for t in tests:
        t()
        print('ok', t.__name__)
if __name__ == '__main__': main()
