#!/usr/bin/env python3
import base64
import hashlib
import json
import os
import shlex
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path

VERSION = "2.37.1"
SHELLS = ["fish", "gha", "gzenv", "tcsh", "vim", "bash", "json", "murex", "zsh", "pwsh", "systemd", "elvish"]


def config_dir():
    return Path(os.environ.get("DIRENV_CONFIG") or os.environ.get("XDG_CONFIG_HOME", str(Path.home() / ".config"))) / "direnv"


def data_dir():
    return Path(os.environ.get("XDG_DATA_HOME", str(Path.home() / ".local/share"))) / "direnv"


def cache_dir():
    return Path(os.environ.get("XDG_CACHE_HOME", str(Path.home() / ".cache"))) / "direnv"


def red(s):
    return "\033[31m" + s + "\033[0m"


def error(msg, code=1):
    print(red("direnv: error " + msg), file=sys.stderr)
    return code


def log(msg):
    if os.environ.get("DIRENV_LOG_FORMAT") == "-":
        return
    print("\033[0mdirenv: " + msg, file=sys.stderr)


def help_text():
    return f"""direnv v{VERSION}
Usage: direnv COMMAND [...ARGS]

Available commands
------------------
allow [PATH_TO_RC]:
  aliases: permit, grant
  Grants direnv permission to load the given .envrc or .env file.
block [PATH_TO_RC]:
  aliases: deny, disallow, revoke
  Revokes the authorization of a given .envrc or .env file.
edit [PATH_TO_RC]:
  Opens PATH_TO_RC or the current .envrc or .env into an $EDITOR and allow
  the file to be loaded afterwards.
exec DIR COMMAND [...ARGS]:
  Executes a command after loading the first .envrc or .env found in DIR
export SHELL:
  Loads an .envrc or .env and prints the diff in terms of exports.
  Supported SHELL values are: [{", ".join(SHELLS)}]
fetchurl <url> [<integrity-hash>]:
  Fetches a given URL into direnv's CAS
help [SHOW_PRIVATE]:
  Shows this help
hook SHELL:
  Used to setup the shell hook
prune:
  Removes old allowed and required files
reload:
  Triggers an env reload
status [--json]:
  Prints some debug status information
stdlib:
  Displays the stdlib available in the .envrc execution context
version [VERSION_AT_LEAST]:
  prints the version or checks that direnv is older than VERSION_AT_LEAST.
log [--status | --error] <message>:
  Logs a given message
"""


def parse_ver(v):
    v = v.lstrip("v")
    parts = []
    for p in v.split("."):
        n = ""
        for ch in p:
            if ch.isdigit():
                n += ch
            else:
                break
        parts.append(int(n or 0))
    return (parts + [0, 0, 0])[:3]


def find_rc(start=None):
    cur = Path(start or os.getcwd()).resolve()
    if cur.is_file():
        return cur
    while True:
        p = cur / ".envrc"
        if p.exists():
            return p
        if load_dotenv_config():
            e = cur / ".env"
            if e.exists():
                return e
        if cur.parent == cur:
            return None
        cur = cur.parent


def load_dotenv_config():
    cfg = config_dir() / "direnv.toml"
    try:
        txt = cfg.read_text()
    except OSError:
        return False
    return "load_dotenv" in txt and "true" in txt.split("load_dotenv", 1)[1].splitlines()[0].lower()


def resolve_rc_arg(arg=None):
    if not arg:
        rc = find_rc()
        if not rc:
            return None, ".envrc not found"
        return rc, None
    p = Path(arg)
    if p.is_dir():
        rc = p / ".envrc"
    else:
        rc = p
    if not rc.exists():
        return None, ".envrc file not found"
    return rc.resolve(), None


def auth_key(path):
    data = path.read_bytes()
    h = hashlib.sha256(str(path).encode() + b"\0" + data).hexdigest()
    return h


def allow_file(path):
    ad = data_dir() / "allow"
    ad.mkdir(parents=True, exist_ok=True)
    (ad / auth_key(path)).write_text(str(path) + "\n")


def is_allowed(path):
    return (data_dir() / "allow" / auth_key(path)).exists() or whitelisted(path)


def whitelisted(path):
    cfg = config_dir() / "direnv.toml"
    try:
        txt = cfg.read_text()
    except OSError:
        return False
    s = str(path)
    for line in txt.splitlines():
        stripped = line.strip()
        if stripped.startswith("prefix") or stripped.startswith("exact"):
            vals = [v.strip().strip('"').replace("~", str(Path.home())) for v in stripped.split("[", 1)[-1].split("]", 1)[0].split(",") if v.strip()]
            if stripped.startswith("prefix") and any(s.startswith(v) for v in vals):
                return True
            exacts = [v if v.endswith(".envrc") else v.rstrip("/") + "/.envrc" for v in vals]
            if stripped.startswith("exact") and s in exacts:
                return True
    return False


def block_file(path):
    ad = data_dir() / "allow"
    if not ad.exists():
        return
    target = str(path)
    for f in ad.iterdir():
        try:
            if f.read_text().strip() == target:
                f.unlink()
        except OSError:
            pass


def stdlib():
    return r'''#!/usr/bin/env bash
shopt -s nullglob
export DIRENV_IN_ENVRC=1
direnv_layout_dir() { echo "${direnv_layout_dir:-$PWD/.direnv}"; }
has() { type "$1" >/dev/null 2>&1; }
expand_path() { python3 -c 'import os,sys; base=sys.argv[2] if len(sys.argv)>2 else os.getcwd(); print(os.path.abspath(os.path.join(base, os.path.expanduser(sys.argv[1]))))' "$@"; }
user_rel_path() { case "$1" in "$HOME"*) printf '~%s\n' "${1#$HOME}";; *) echo "$1";; esac; }
find_up() { local n="${1:-.envrc}" d="$PWD"; while :; do [[ -e "$d/$n" ]] && { echo "$d/$n"; return 0; }; [[ "$d" = / ]] && return 1; d="$(dirname "$d")"; done; }
source_env() { local p="$1"; [[ -d "$p" ]] && p="$p/.envrc"; source "$p"; }
source_env_if_exists() { [[ -f "$1" ]] && source "$1"; }
source_up() { local p; p="$(find_up "${1:-.envrc}")" || return 1; source "$p"; }
source_up_if_exists() { local p; p="$(find_up "${1:-.envrc}")" || return 0; source "$p"; }
dotenv() { local f="${1:-.env}"; set -a; source "$f"; set +a; }
dotenv_if_exists() { [[ -f "${1:-.env}" ]] && dotenv "$@"; }
path_add() { local var="$1" p; p="$(expand_path "$2")"; eval "export $var=\"$p\${$var:+:\${$var}}\""; }
PATH_add() { path_add PATH "$1"; }
MANPATH_add() { path_add MANPATH "$1"; }
PATH_rm() { local old="$PATH" new="" part pat keep; IFS=: read -ra parts <<< "$old"; for part in "${parts[@]}"; do keep=1; for pat in "$@"; do [[ "$part" == $pat ]] && keep=0; done; [[ $keep = 1 ]] && new="${new:+$new:}$part"; done; export PATH="$new"; }
load_prefix() { local p; p="$(expand_path "$1")"; PATH_add "$p/bin"; path_add CPATH "$p/include"; path_add LD_LIBRARY_PATH "$p/lib"; path_add LIBRARY_PATH "$p/lib"; path_add PKG_CONFIG_PATH "$p/lib/pkgconfig"; MANPATH_add "$p/share/man"; }
layout() { case "$1" in node) PATH_add node_modules/.bin;; go) export GOPATH="$(direnv_layout_dir)/go"; PATH_add bin;; python|python3) local d; d="$(direnv_layout_dir)/python"; export VIRTUAL_ENV="$d"; PATH_add "$d/bin";; php) PATH_add vendor/bin;; julia) export JULIA_PROJECT="$PWD";; *) return 0;; esac; }
watch_file() { :; }
watch_dir() { :; }
strict_env() { set -euo pipefail; }
unstrict_env() { set +e +u +o pipefail; }
log_error() { echo "direnv: $*" >&2; }
env_vars_required() { local fail=0 v; for v in "$@"; do [[ -z "${!v:-}" ]] && { log_error "required environment variable '$v' is missing"; fail=1; }; done; return $fail; }
fetchurl() { command direnv fetchurl "$@"; }
source_url() { local p; p="$(fetchurl "$@")" || return $?; source "$p"; }
direnv_apply_dump() { source "$1"; }
direnv_load() { eval "$("$@")"; }
'''


def capture_env_bytes(env):
    out = {}
    for item in env.split(b"\0"):
        if not item or b"=" not in item:
            continue
        k, v = item.split(b"=", 1)
        try:
            out[k.decode()] = v.decode()
        except UnicodeDecodeError:
            out[k.decode(errors="ignore")] = v.decode(errors="ignore")
    return out


def eval_rc(rc, base_env=None):
    base = dict(base_env or os.environ)
    script = stdlib() + "\n" + f"source {shlex.quote(str(rc))}\n/usr/bin/env -0\n"
    bash = "/usr/bin/bash"
    proc = subprocess.run([bash, "-c", script], cwd=str(rc.parent), env=base, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    if proc.returncode != 0:
        sys.stderr.buffer.write(proc.stderr)
        return None, proc.returncode
    env = capture_env_bytes(proc.stdout)
    env["DIRENV_FILE"] = str(rc)
    env["DIRENV_DIR"] = "-" + str(rc.parent)
    env.setdefault("DIRENV_WATCHES", "")
    env.setdefault("DIRENV_DIFF", "")
    return env, 0


def bash_quote(v):
    if v == "":
        return "''"
    return "$'" + v.replace("\\", "\\\\").replace("'", "\\'").replace("\n", "\\n") + "'"


def fish_quote(v):
    return "'" + v.replace("\\", "\\\\").replace("'", "\\'") + "'"


def diff_env(new, old):
    skip = {"DIRENV_IN_ENVRC", "_", "SHLVL", "OLDPWD", "PWD"}
    changed = {}
    for k, v in new.items():
        if k in skip or k.startswith("BASH_FUNC_"):
            continue
        if old.get(k) != v:
            changed[k] = v
    for k in old:
        if k.startswith("DIRENV_") and k not in new:
            changed[k] = None
    return changed


def format_export(shell, changes):
    if shell in ("bash", "zsh"):
        return "".join(f"unset {k};" if v is None else f"export {k}={bash_quote(v)};" for k, v in changes.items())
    if shell == "fish":
        parts = []
        for k, v in changes.items():
            if v is None:
                parts.append(f"set -e {fish_quote(k)};")
            elif k in ("PATH", "MANPATH"):
                parts.append(f"set -x -g {k} " + " ".join(fish_quote(p) for p in v.split(":")) + ";")
            else:
                parts.append(f"set -x -g {fish_quote(k)} {fish_quote(v)};")
        return "".join(parts)
    if shell == "json":
        return json.dumps(changes, indent=2, sort_keys=True)
    if shell == "elvish":
        return json.dumps(changes, sort_keys=True)
    if shell == "tcsh":
        return "".join(f"unsetenv {k};" if v is None else f"setenv {k} {shlex.quote(v)};" for k, v in changes.items())
    if shell == "vim":
        return "".join(f"let ${k}={json.dumps(v)}\n" for k, v in changes.items() if v is not None)
    if shell == "gha":
        return "".join(f"{k}={v}\n" for k, v in changes.items() if v is not None)
    if shell == "gzenv":
        return "".join(f"{k}={v}\0" for k, v in changes.items() if v is not None)
    if shell == "pwsh":
        return "".join(f"Remove-Item Env:{k};" if v is None else f"$Env:{k} = {json.dumps(v)};" for k, v in changes.items())
    if shell == "systemd":
        return "".join(f"unset {k}\n" if v is None else f"{k}={v}\n" for k, v in changes.items())
    if shell == "murex":
        return json.dumps(changes)
    return ""


def parse_dotenv(path):
    vals = {}
    try:
        lines = Path(path).read_text().splitlines()
    except OSError as e:
        raise FileNotFoundError(str(e))
    for line in lines:
        s = line.strip()
        if not s or s.startswith("#"):
            continue
        if s.startswith("export "):
            s = s[7:].lstrip()
        if "=" not in s:
            continue
        k, v = s.split("=", 1)
        k = k.strip()
        v = v.strip()
        if (len(v) >= 2 and v[0] == v[-1] and v[0] in ("'", '"')):
            v = v[1:-1]
        vals[k] = v
    return vals


def cmd_dotenv(args):
    shell = "bash"
    path = ".env"
    if args and args[0] in SHELLS:
        shell = args[0]
        if len(args) > 1:
            path = args[1]
    elif args:
        path = args[0]
    try:
        vals = parse_dotenv(path)
    except FileNotFoundError:
        return error(f"open {path}: no such file or directory")
    sys.stdout.write(format_export(shell, vals))
    if shell == "json":
        sys.stdout.write("\n")
    return 0


def cmd_dump(args):
    shell = args[0] if args and args[0] in SHELLS else None
    if shell:
        sys.stdout.write(format_export(shell, dict(os.environ)))
        if shell in ("json", "systemd", "gha"):
            sys.stdout.write("\n")
    else:
        raw = json.dumps(dict(os.environ), sort_keys=True).encode()
        sys.stdout.write(base64.urlsafe_b64encode(raw).decode())
        sys.stdout.write("\n")
    return 0


def cmd_apply_dump(args):
    if not args:
        return error("not enough arguments")
    try:
        txt = Path(args[0]).read_text().strip()
        env = json.loads(base64.urlsafe_b64decode(txt.encode()))
    except Exception:
        env = {}
    sys.stdout.write(format_export("bash", env))
    return 0


def cmd_export(shell):
    if shell not in SHELLS:
        return error(f"unknown target shell '{shell}'")
    rc = find_rc()
    if not rc:
        return 0
    old = dict(os.environ)
    blocked = not is_allowed(rc)
    if blocked:
        changes = {"DIRENV_DIR": "-" + str(rc.parent), "DIRENV_FILE": str(rc), "DIRENV_WATCHES": "", "DIRENV_DIFF": ""}
        sys.stdout.write(format_export(shell, changes))
        return error(f"{rc} is blocked. Run `direnv allow` to approve its content")
    log(f"loading {rc}")
    new, code = eval_rc(rc, old)
    if code:
        return code
    changes = diff_env(new, old)
    added = sorted(k for k, v in changes.items() if v is not None and k not in old and not k.startswith("DIRENV_"))
    mod = sorted(k for k, v in changes.items() if v is not None and k in old and old[k] != v and not k.startswith("DIRENV_"))
    if added or mod:
        log("export " + " ".join(["+" + k for k in added] + ["~" + k for k in mod]))
    sys.stdout.write(format_export(shell, changes))
    return 0


def hook(shell):
    selfp = sys.argv[0]
    if shell == "bash":
        print(f'''
_direnv_hook() {{
  local previous_exit_status=$?;
  vars="$("{selfp}" export bash)";
  trap -- '' SIGINT;
  eval "$vars";
  trap - SIGINT;
  return $previous_exit_status;
}};
if [[ ";${{PROMPT_COMMAND[*]:-}};" != *";_direnv_hook;"* ]]; then
  if [[ "$(declare -p PROMPT_COMMAND 2>&1)" == "declare -a"* ]]; then
    PROMPT_COMMAND=(_direnv_hook "${{PROMPT_COMMAND[@]}}")
  else
    PROMPT_COMMAND="_direnv_hook${{PROMPT_COMMAND:+;$PROMPT_COMMAND}}"
  fi
fi''')
        return 0
    if shell == "zsh":
        print(f'''
_direnv_hook() {{
  vars="$("{selfp}" export zsh)"
  trap -- '' SIGINT
  eval "$vars"
  trap - SIGINT
}}
typeset -ag precmd_functions
if (( ! ${{precmd_functions[(I)_direnv_hook]}} )); then
  precmd_functions=(_direnv_hook $precmd_functions)
fi
typeset -ag chpwd_functions
if (( ! ${{chpwd_functions[(I)_direnv_hook]}} )); then
  chpwd_functions=(_direnv_hook $chpwd_functions)
fi''')
        return 0
    if shell == "fish":
        print(f'''
    function __direnv_export_eval --on-event fish_prompt;
        "{selfp}" export fish | source;
    end;''')
        return 0
    if shell == "tcsh":
        print(f"alias precmd 'eval `{selfp} export tcsh`'", end="")
        return 0
    if shell == "elvish":
        print(f'var m = [("{selfp}" export elvish | from-json)]')
        return 0
    if shell == "pwsh":
        print(f'$export = ({selfp} export pwsh) -join [Environment]::NewLine; Invoke-Expression -Command $export;')
        return 0
    return error(f"unknown target shell '{shell}'")


def status(json_mode=False):
    rc = find_rc()
    loaded = os.environ.get("DIRENV_FILE")
    if json_mode:
        print(json.dumps({"config": {"ConfigDir": str(config_dir()), "SelfPath": sys.argv[0]}, "state": {"foundRC": str(rc) if rc else None, "loadedRC": loaded}}, indent=2))
    else:
        print(f"direnv exec path {sys.argv[0]}")
        print(f"DIRENV_CONFIG {config_dir()}")
        print("/usr/bin/bash".join(["bash_path ", ""]))
        print("disable_stdin false")
        print("warn_timeout 5s")
        print("whitelist.prefix []")
        print("whitelist.exact map[]")
        print(f"Found RC path {rc}" if rc else "No .envrc or .env found")
    return 0


def fetchurl(args):
    if not args:
        return error("not enough arguments")
    url = args[0]
    if "://" not in url:
        return error("unsupported URL")
    return error("Get \"" + url + "\": network is unavailable")


def cmd_exec(args):
    if len(args) < 2:
        return error("not enough arguments")
    d = Path(args[0]).resolve()
    rc = find_rc(d)
    env = dict(os.environ)
    if rc:
        if not is_allowed(rc):
            return error(f"{rc} is blocked. Run `direnv allow` to approve its content")
        log(f"loading {rc}")
        env, code = eval_rc(rc, env)
        if code:
            return code
    p = subprocess.run(args[1:], cwd=str(d), env=env)
    return p.returncode


def main(argv):
    if not argv or argv[0] in ("help", "--help", "-h"):
        print(help_text(), end="")
        return 0
    cmd, args = argv[0], argv[1:]
    aliases = {"permit": "allow", "grant": "allow", "deny": "block", "disallow": "block", "revoke": "block"}
    cmd = aliases.get(cmd, cmd)
    if cmd == "version":
        if args:
            if parse_ver(VERSION) < parse_ver(args[0]):
                return error(f"current version v{VERSION} is older than the desired version v{args[0].lstrip('v')}")
            return 0
        print(VERSION)
        return 0
    if cmd == "allow":
        rc, err = resolve_rc_arg(args[0] if args else None)
        if err:
            return error(err)
        allow_file(rc)
        return 0
    if cmd == "block":
        rc, err = resolve_rc_arg(args[0] if args else None)
        if err:
            return error(err)
        block_file(rc)
        return 0
    if cmd == "export":
        return cmd_export(args[0] if args else "")
    if cmd == "exec":
        return cmd_exec(args)
    if cmd == "hook":
        return hook(args[0] if args else "")
    if cmd == "stdlib":
        print(stdlib(), end="")
        return 0
    if cmd == "status":
        return status(bool(args and args[0] == "--json"))
    if cmd == "reload":
        rc = find_rc()
        return 0 if rc else error(".envrc not found")
    if cmd == "prune":
        return 0
    if cmd == "fetchurl":
        return fetchurl(args)
    if cmd == "dotenv":
        return cmd_dotenv(args)
    if cmd == "dump":
        return cmd_dump(args)
    if cmd == "apply_dump":
        return cmd_apply_dump(args)
    if cmd in ("watch", "watch-dir", "watch-list"):
        shell = args[0] if args and args[0] in SHELLS else "bash"
        sys.stdout.write(format_export(shell, {"DIRENV_WATCHES": ""}))
        return 0
    if cmd == "watch-print":
        return 0
    if cmd == "current":
        if not args:
            return error("not enough arguments")
        return error(f'File "{Path(args[0]).resolve()}" is unknown')
    if cmd in ("show_dump", "check-required"):
        return 0
    if cmd == "log":
        if not args:
            return error("invalid arguments")
        if args[0] in ("--status", "--error"):
            args = args[1:]
        if not args:
            return error("invalid arguments")
        log(" ".join(args))
        return 0
    if cmd == "edit":
        rc, err = resolve_rc_arg(args[0] if args else None)
        if err:
            return error(err)
        editor = os.environ.get("EDITOR", "vi")
        code = subprocess.call([editor, str(rc)])
        if code == 0:
            allow_file(rc)
        return code
    return error(f'command "{sys.argv[0]} {cmd}" not found')


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
