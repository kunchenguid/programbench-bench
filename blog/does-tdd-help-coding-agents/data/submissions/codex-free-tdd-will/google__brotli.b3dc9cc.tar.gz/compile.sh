#!/bin/bash
set -e
rm -f executable
cp src/brotli_clone.py executable
chmod +x executable
