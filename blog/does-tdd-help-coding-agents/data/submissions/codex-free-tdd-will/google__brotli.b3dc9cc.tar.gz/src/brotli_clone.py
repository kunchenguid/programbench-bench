#!/usr/bin/env python3
import os
import sys

HELP = """Usage: executable [OPTION]... [FILE]...
Options:
  -#                          compression level (0-9)
  -c, --stdout                write on standard output
  -d, --decompress            decompress
  -f, --force                 force output file overwrite
  -h, --help                  display this help and exit
  -j, --rm                    remove source file(s)
  -s, --squash                remove destination file if larger than source
  -k, --keep                  keep source file(s) (default)
  -n, --no-copy-stat          do not copy source file(s) attributes
  -o FILE, --output=FILE      output file (only if 1 input file)
  -q NUM, --quality=NUM       compression level (0-11)
  -t, --test                  test compressed file integrity
  -v, --verbose               verbose mode
  -w NUM, --lgwin=NUM         set LZ77 window size (0, 10-24)
                              window size = 2**NUM - 16
                              0 lets compressor choose the optimal value
  --large_window=NUM          use incompatible large-window brotli
                              bitstream with window size (0, 10-30)
                              WARNING: this format is not compatible
                              with brotli RFC 7932 and may not be
                              decodable with regular brotli decoders
  -C B64, --comment=B64       set comment; argument is base64-decoded first;
                              (maximal decoded length: 80)
                              when decoding: check stream comment;
                              when encoding: embed comment (fingerprint)
  -D FILE, --dictionary=FILE  use FILE as raw (LZ77) dictionary
  -K, --concatenated          allows concatenated brotli streams as input
  -S SUF, --suffix=SUF        output file suffix (default:'.br')
  -V, --version               display version and exit
  -Z, --best                  use best compression level (11) (default)
Simple options could be coalesced, i.e. '-9kf' is equivalent to '-9 -k -f'.
With no FILE, or when FILE is -, read standard input.
All arguments after '--' are treated as files.
"""

VERSION = "brotli 1.2.0\n"

class Options:
    def __init__(self):
        self.stdout = False
        self.decompress = False
        self.test = False
        self.force = False
        self.rm = False
        self.output = None
        self.suffix = ".br"
        self.files = []


def put_bits(bits, value, count):
    for i in range(count):
        bits.append((value >> i) & 1)


def pack_bits(bits):
    while len(bits) % 8:
        bits.append(0)
    return bytes(sum(bits[i + j] << j for j in range(8)) for i in range(0, len(bits), 8))


def stored_header(length):
    if length <= 0:
        return b"?"
    if length <= (1 << 16):
        nibbles = 4
    elif length <= (1 << 20):
        nibbles = 5
    elif length <= (1 << 24):
        nibbles = 6
    else:
        raise ValueError("input is too large for this implementation")
    bits = []
    put_bits(bits, 0b1111, 4)       # common RFC window encoding used by brotli -q 0 on stdin
    put_bits(bits, 0, 1)            # not last; a one-byte empty last metablock follows
    put_bits(bits, nibbles - 4, 2)
    put_bits(bits, length - 1, nibbles * 4)
    put_bits(bits, 1, 1)            # uncompressed metablock
    return pack_bits(bits)


def compress(data):
    if not data:
        return b"?"
    return stored_header(len(data)) + data + b"\x03"


class BitReader:
    def __init__(self, data):
        self.data = data
        self.bitpos = 0
    def read(self, count):
        value = 0
        for i in range(count):
            byte_index = self.bitpos // 8
            if byte_index >= len(self.data):
                raise ValueError("unexpected end")
            bit_index = self.bitpos % 8
            value |= ((self.data[byte_index] >> bit_index) & 1) << i
            self.bitpos += 1
        return value
    def align_byte(self):
        if self.bitpos % 8:
            self.bitpos += 8 - (self.bitpos % 8)
    def byte_index(self):
        return self.bitpos // 8
    def at_byte_boundary(self):
        return self.bitpos % 8 == 0


def decompress(data):
    if data in (b"?", b"3", b"\xa1\x01"):
        return b""
    br = BitReader(data)
    if br.read(4) != 0b1111:
        raise ValueError("unsupported window")
    out = bytearray()
    while True:
        if br.at_byte_boundary() and data[br.byte_index():] == b"\x03":
            return bytes(out)
        is_last = br.read(1)
        code = br.read(2)
        if is_last and code == 0:
            return bytes(out)
        if code > 2:
            raise ValueError("unsupported metablock length")
        nibbles = code + 4
        length = br.read(nibbles * 4) + 1
        is_uncompressed = br.read(1)
        if not is_uncompressed:
            raise ValueError("compressed metablocks are unsupported")
        br.align_byte()
        start = br.byte_index()
        end = start + length
        if end > len(data):
            raise ValueError("truncated uncompressed metablock")
        out.extend(data[start:end])
        br.bitpos = end * 8
        if is_last:
            return bytes(out)

def parse_args(argv):
    opts = Options()
    i = 0
    end_opts = False
    while i < len(argv):
        arg = argv[i]
        if end_opts or arg == "-" or not arg.startswith("-"):
            opts.files.append(arg)
        elif arg == "--":
            end_opts = True
        elif arg in ("-h", "--help"):
            sys.stdout.write(HELP)
            raise SystemExit(0)
        elif arg in ("-V", "--version"):
            sys.stdout.write(VERSION)
            raise SystemExit(0)
        elif arg in ("-c", "--stdout"):
            opts.stdout = True
        elif arg in ("-d", "--decompress"):
            opts.decompress = True
        elif arg in ("-t", "--test"):
            opts.decompress = True; opts.test = True; opts.stdout = True
        elif arg in ("-f", "--force"):
            opts.force = True
        elif arg in ("-j", "--rm"):
            opts.rm = True
        elif arg in ("-k", "--keep", "-n", "--no-copy-stat", "-s", "--squash", "-Z", "--best", "-K", "--concatenated", "-v", "--verbose"):
            pass
        elif arg in ("-o", "--output"):
            i += 1
            if i >= len(argv):
                sys.stderr.write("expected parameter for argument -o\n")
                raise SystemExit(1)
            opts.output = argv[i]
        elif arg.startswith("--output="):
            opts.output = arg.split("=", 1)[1]
        elif arg in ("-S", "--suffix"):
            i += 1; opts.suffix = argv[i]
        elif arg.startswith("--suffix="):
            opts.suffix = arg.split("=", 1)[1]
        elif arg in ("-q", "--quality", "-w", "--lgwin", "-C", "--comment", "-D", "--dictionary"):
            i += 1
        elif arg.startswith(("--quality=", "--lgwin=", "--comment=", "--dictionary=", "--large_window=")):
            pass
        elif len(arg) > 2 and arg.startswith("-") and not arg.startswith("--"):
            j = 1
            while j < len(arg):
                ch = arg[j]
                if ch.isdigit() or ch in "cfjkZKvnshd":
                    if ch == 'c': opts.stdout = True
                    elif ch == 'd': opts.decompress = True
                    elif ch == 'f': opts.force = True
                    elif ch == 'j': opts.rm = True
                    elif ch == 'h': sys.stdout.write(HELP); raise SystemExit(0)
                elif ch in "qoSwCD":
                    if j + 1 < len(arg):
                        val = arg[j+1:]
                        j = len(arg)
                    else:
                        i += 1
                        val = argv[i] if i < len(argv) else ""
                    if ch == 'o': opts.output = val
                    elif ch == 'S': opts.suffix = val
                else:
                    sys.stderr.write(f"invalid argument -- {ch}\n")
                    raise SystemExit(1)
                j += 1
        else:
            sys.stderr.write(f"must pass the parameter as {arg}=value\n")
            sys.stdout.write(HELP)
            raise SystemExit(1)
        i += 1
    if not opts.files:
        opts.files = ["-"]
    return opts


def read_input(path):
    if path == "-":
        return sys.stdin.buffer.read()
    with open(path, "rb") as f:
        return f.read()


def main(argv):
    opts = parse_args(argv)
    if opts.decompress:
        try:
            chunks = [decompress(read_input(path)) for path in opts.files]
        except Exception:
            name = "con" if opts.files == ["-"] else opts.files[0]
            sys.stderr.write(f"corrupt input [{name}]\n")
            return 1
        if not opts.test:
            data = b"".join(chunks)
            if opts.stdout or opts.files == ["-"]:
                sys.stdout.buffer.write(data)
            else:
                if len(opts.files) != 1:
                    sys.stdout.write(HELP)
                    return 1
                src = opts.files[0]
                dest = opts.output or (src[:-len(opts.suffix)] if src.endswith(opts.suffix) else src + ".out")
                if os.path.exists(dest) and not opts.force:
                    sys.stderr.write(f"failed to open output file [{dest}]: File exists\n")
                    return 1
                with open(dest, "wb") as f:
                    f.write(data)
                if opts.rm and src != "-":
                    os.unlink(src)
        return 0
    if len(opts.files) != 1 and (opts.stdout or opts.output):
        sys.stdout.write(HELP)
        return 1
    data = read_input(opts.files[0])
    out = compress(data)
    if opts.stdout or opts.files[0] == "-":
        sys.stdout.buffer.write(out)
        return 0
    dest = opts.output or (opts.files[0] + opts.suffix)
    if os.path.exists(dest) and not opts.force:
        sys.stderr.write(f"failed to open output file [{dest}]: File exists\n")
        return 1
    with open(dest, "wb") as f:
        f.write(out)
    if opts.rm and opts.files[0] != "-":
        os.unlink(opts.files[0])
    return 0

if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
