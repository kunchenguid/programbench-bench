import os
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
BIN = ROOT / "src" / "brotli_clone.py"
ORIG = os.environ.get("ORIG_BROTLI")

class CliTests(unittest.TestCase):
    def run_clone(self, args, data=b""):
        return subprocess.run([sys.executable, str(BIN), *args], input=data, stdout=subprocess.PIPE, stderr=subprocess.PIPE)

    def test_compress_stdout_stream_decodes_with_reference(self):
        data = b"hello stored brotli\n"
        made = self.run_clone(["-c"], data)
        self.assertEqual(made.returncode, 0, made.stderr)
        decoded = subprocess.run([ORIG, "-d", "-c"], input=made.stdout, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        self.assertEqual(decoded.returncode, 0, decoded.stderr)
        self.assertEqual(decoded.stdout, data)

    def test_decompresses_own_stored_stream_to_stdout(self):
        data = b"abc" * 400
        made = self.run_clone(["-c"], data)
        self.assertEqual(made.returncode, 0, made.stderr)
        decoded = self.run_clone(["-d", "-c"], made.stdout)
        self.assertEqual(decoded.returncode, 0, decoded.stderr)
        self.assertEqual(decoded.stdout, data)

    def test_file_compress_and_decompress_respects_existing_output(self):
        with tempfile.TemporaryDirectory() as td:
            src = Path(td) / "sample.txt"
            src.write_bytes(b"file payload")
            first = subprocess.run([sys.executable, str(BIN), str(src)], stdout=subprocess.PIPE, stderr=subprocess.PIPE)
            self.assertEqual(first.returncode, 0, first.stderr)
            self.assertTrue((Path(td) / "sample.txt.br").exists())
            second = subprocess.run([sys.executable, str(BIN), str(src)], stdout=subprocess.PIPE, stderr=subprocess.PIPE)
            self.assertEqual(second.returncode, 1)
            self.assertIn(b"File exists", second.stderr)
            src.unlink()
            decoded = subprocess.run([sys.executable, str(BIN), "-d", str(Path(td) / "sample.txt.br")], stdout=subprocess.PIPE, stderr=subprocess.PIPE)
            self.assertEqual(decoded.returncode, 0, decoded.stderr)
            self.assertEqual(src.read_bytes(), b"file payload")

if __name__ == "__main__":
    unittest.main()
