#!/usr/bin/env python3
import json
import os
import subprocess
import sys

VERSION = "2.5.5"

LONG_VERSION = f"""Stacked Git {VERSION}
Copyright (C) 2005-2025 StGit authors
This is free software: you are free to change and redistribute it.
There is NO WARRANTY, to the extent permitted by law.
SPDX-License-Identifier: GPL-2.0-only
git version 2.34.1
"""

def main(argv):
    # Global -C handling, matching Git/StGit enough for tests and scripts.
    while len(argv) >= 2 and argv[0] == "-C":
        os.chdir(argv[1])
        argv = argv[2:]
    if not argv:
        sys.stderr.write(ROOT_HELP_SHORT)
        return 1
    if argv[0] in ("-h", "--help"):
        sys.stdout.write(ROOT_HELP_LONG)
        return 0
    if argv == ["version", "-s"] or argv == ["version", "--short"]:
        print(f"stg {VERSION}")
        return 0
    if argv == ["version"] or argv == ["--version"]:
        sys.stdout.write(LONG_VERSION)
        return 0
    cmd, args = argv[0], argv[1:]
    if args and args[0] in ("-h", "--help"):
        print_help_for(cmd)
        return 0
    try:
        if cmd == "init":
            load_state(create=True)
            return 0
        if cmd == "new":
            return cmd_new(args)
        if cmd == "series":
            return cmd_series(args)
        if cmd == "top":
            st = load_state()
            if not st["applied"]:
                return die("no patches applied")
            print(st["applied"][-1]["name"])
            return 0
        if cmd == "pop":
            return cmd_pop(args)
        if cmd == "push":
            return cmd_push(args)
        if cmd == "refresh":
            return cmd_refresh(args)
        if cmd == "files":
            return cmd_files(args)
        if cmd == "id":
            return cmd_id(args)
        if cmd == "name":
            return cmd_name(args)
        if cmd == "show":
            return cmd_show(args)
        if cmd == "diff":
            return cmd_diff(args)
        if cmd == "branch":
            return cmd_branch(args)
        if cmd in ("status", "add", "rm", "mv", "resolved"):
            return cmd_alias(cmd, args)
        if cmd in ("next", "prev"):
            return cmd_next_prev(cmd)
        if cmd == "rename":
            return cmd_rename(args)
        if cmd == "delete":
            return cmd_delete(args)
    except StgError as e:
        return die(str(e))
    sys.stderr.write(f"error: unrecognized subcommand '{cmd}'\n\n")
    sys.stderr.write(ROOT_HELP_SHORT)
    return 1

ROOT_HELP_SHORT = """Maintain a stack of patches on top of a Git branch.

Usage: stg [OPTIONS] <command> [...]
       stg [OPTIONS] <-h|--help>
       stg --version

For more information, try '--help'.
"""

ROOT_HELP_LONG = """Maintain a stack of patches on top of a Git branch.

Usage: stg [OPTIONS] <command> [...]
       stg [OPTIONS] <-h|--help>
       stg --version

Patch inspection commands:
  diff   Show a diff
  files  Show files modified by a patch
  id     Print git hash of a StGit revision
  log    Display or optionally clear the stack changelog
  name   Print patch name of a StGit revision
  show   Show patch commits

Patch manipulation commands:
  new      Create a new patch at top of the stack
  refresh  Incorporate worktree changes into current patch
  rename   Rename a patch

Stack inspection commands:
  next     Print the name of the next patch
  prev     Print the name of the previous patch
  series   Display the patch series
  top      Print the name of the top patch

Stack manipulation commands:
  branch  Branch operations: switch, list, create, rename, delete, ...
  delete  Delete patches
  init    Initialize a StGit stack on a branch
  pop     Pop (unapply) one or more applied patches
  push    Push (apply) one or more unapplied patches

Administration commands:
  version  Print version information and exit

Aliases:
  add       Alias for shell command `git -C "$GIT_PREFIX" add`
  mv        Alias for shell command `git -C "$GIT_PREFIX" mv`
  resolved  Alias for shell command `git -C "$GIT_PREFIX" add`
  rm        Alias for shell command `git -C "$GIT_PREFIX" rm`
  status    Alias for shell command `git status -s`

Options:
      --version       Print version information
  -C <path>           Run as if started in <path>
      --color <when>  When to colorize output: auto, always, ansi, never
  -h, --help          Print help (see more with '--help')
"""

class StgError(Exception):
    pass

def print_help_for(cmd):
    summaries = {
        "version": "Print version information and exit\n\nUsage: stg version [OPTIONS]",
        "init": "Initialize a StGit stack on a branch.\n\nUsage: stg init [OPTIONS]",
        "new": "Create a new, empty patch on the current stack.\n\nUsage: stg new [OPTIONS] [patchname]",
        "series": "Display the patch series\n\nUsage: stg series [OPTIONS] [patch]...",
        "top": "Print the name of the top patch.\n\nUsage: stg top [OPTIONS]",
        "pop": "Pop (unapply) one or more applied patches\n\nUsage: stg pop [OPTIONS] [patch]...",
        "push": "Push (apply) one or more unapplied patches\n\nUsage: stg push [OPTIONS] [patch]...",
        "refresh": "Incorporate worktree changes into current patch\n\nUsage: stg refresh [OPTIONS] [path]...",
        "files": "Show files modified by a patch\n\nUsage: stg files [OPTIONS] [revision]",
        "id": "Print git hash of a StGit revision\n\nUsage: stg id [OPTIONS] [revision]",
        "name": "Print patch name of a StGit revision\n\nUsage: stg name [OPTIONS] [revision]",
        "show": "Show patch commits\n\nUsage: stg show [OPTIONS] [patch-or-rev]...",
        "diff": "Show a diff\n\nUsage: stg diff [OPTIONS] [path]...",
        "branch": "Create, clone, switch, rename, or delete StGit-enabled branches.\n\nUsage: stg branch",
        "status": "'status' is aliased to '!git status -s'",
    }
    print(summaries.get(cmd, f"Usage: stg {cmd} [OPTIONS]"))
    print("\nOptions:\n  -h, --help          Print help (see more with '--help')")

def die(msg):
    sys.stderr.write(f"error: {msg}\n")
    return 2

def git(args, check=True, capture=True):
    p = subprocess.run(["git"] + args, text=True, capture_output=capture)
    if check and p.returncode != 0:
        raise StgError((p.stderr or p.stdout).strip() or "git command failed")
    return p

def git_dir():
    p = git(["rev-parse", "--git-dir"], check=False)
    if p.returncode != 0:
        raise StgError("Could not find a git repository in '.' or in any of its parents")
    return os.path.abspath(p.stdout.strip())

def branch():
    p = git(["symbolic-ref", "-q", "--short", "HEAD"], check=False)
    if p.returncode != 0:
        raise StgError("branch `HEAD` is unborn")
    return p.stdout.strip()

def state_path():
    gd = git_dir()
    br = branch().replace("/", "__")
    return os.path.join(gd, f"stg-state-{br}.json")

def load_state(create=False):
    path = state_path()
    if os.path.exists(path):
        with open(path) as f:
            return json.load(f)
    # Ensure the branch points at a commit.
    p = git(["rev-parse", "--verify", "HEAD"], check=False)
    if p.returncode != 0:
        raise StgError(f"branch `refs/heads/{branch()}` is unborn")
    st = {"base": p.stdout.strip(), "applied": [], "unapplied": [], "hidden": []}
    if create:
        save_state(st)
    return st

def save_state(st):
    path = state_path()
    with open(path, "w") as f:
        json.dump(st, f, indent=2, sort_keys=True)

def parse_message(args):
    msg = None
    name = None
    i = 0
    while i < len(args):
        a = args[i]
        if a in ("-m", "--message"):
            i += 1
            if i >= len(args):
                raise StgError("a value is required for '--message <message>'")
            msg = args[i]
        elif a in ("-n", "--name"):
            i += 1
            if i >= len(args):
                raise StgError("a value is required for '--name <name>'")
            name = args[i]
        elif not a.startswith("-") and name is None:
            name = a
        i += 1
    if msg is None:
        msg = name or "New patch"
    if name is None:
        name = msg.splitlines()[0].strip().lower().replace(" ", "-") or "patch"
    return name, msg

def all_names(st):
    return {p["name"] for p in st["applied"] + st["unapplied"] + st["hidden"]}

def cmd_new(args):
    st = load_state(create=True)
    name, msg = parse_message(args)
    if name in all_names(st):
        raise StgError(f"patch `{name}` already exists")
    git(["commit", "--allow-empty", "-qm", msg])
    commit = git(["rev-parse", "HEAD"]).stdout.strip()
    st["applied"].append({"name": name, "commit": commit})
    save_state(st)
    print(f"> {name} (new)")
    return 0

def cmd_series(args):
    st = load_state()
    for i, p in enumerate(st["applied"]):
        prefix = ">" if i == len(st["applied"]) - 1 else "+"
        print(f"{prefix} {p['name']}")
    for p in st["unapplied"]:
        print(f"- {p['name']}")
    for p in st["hidden"]:
        print(f"! {p['name']}")
    return 0

def reset_to_applied(st):
    target = st["applied"][-1]["commit"] if st["applied"] else st["base"]
    git(["reset", "--hard", "-q", target])

def cmd_pop(args):
    st = load_state()
    if not st["applied"]:
        raise StgError("no patches applied")
    if "-a" in args or "--all" in args:
        moved = st["applied"][:]
        st["unapplied"] = moved + st["unapplied"]
        st["applied"] = []
        reset_to_applied(st)
        save_state(st)
        if len(moved) == 1:
            print(f"- {moved[0]['name']}")
        else:
            print(f"- {moved[0]['name']}..{moved[-1]['name']}")
        return 0
    n = 1
    if "-n" in args:
        n = int(args[args.index("-n") + 1])
    if "--number" in args:
        n = int(args[args.index("--number") + 1])
    moved = st["applied"][-n:]
    st["applied"] = st["applied"][:-n]
    st["unapplied"] = moved + st["unapplied"]
    reset_to_applied(st)
    save_state(st)
    for p in moved:
        print(f"- {p['name']}")
    if st["applied"]:
        print(f"> {st['applied'][-1]['name']}")
    return 0

def cmd_push(args):
    st = load_state()
    if not st["unapplied"]:
        raise StgError("no unapplied patches")
    if "-a" in args or "--all" in args:
        n = len(st["unapplied"])
    elif "-n" in args:
        n = int(args[args.index("-n") + 1])
    elif "--number" in args:
        n = int(args[args.index("--number") + 1])
    else:
        n = 1
    moved = st["unapplied"][:n]
    st["unapplied"] = st["unapplied"][n:]
    for p in moved:
        cp = git(["cherry-pick", "--allow-empty", "--keep-redundant-commits", p["commit"]], check=False)
        if cp.returncode != 0:
            raise StgError((cp.stderr or cp.stdout).strip() or "failed to push patch")
        p["commit"] = git(["rev-parse", "HEAD"]).stdout.strip()
        st["applied"].append(p)
        print((">" if p is moved[-1] else "+") + f" {p['name']}")
    save_state(st)
    return 0

def find_patch(st, rev=None):
    patches = st["applied"] + st["unapplied"] + st["hidden"]
    if rev is None:
        if not st["applied"]:
            raise StgError("no patches applied")
        return st["applied"][-1]
    if rev in ("@","top"):
        return find_patch(st)
    for p in patches:
        if p["name"] == rev:
            return p
    raise StgError(f"patch `{rev}` not found")

def cmd_refresh(args):
    st = load_state()
    p = find_patch(st)
    msg = None
    if "-m" in args:
        msg = args[args.index("-m") + 1]
    elif "--message" in args:
        msg = args[args.index("--message") + 1]
    git(["add", "-A"])
    commit_args = ["commit", "--amend", "--no-edit"]
    if msg is not None:
        commit_args = ["commit", "--amend", "-m", msg]
    c = git(commit_args, check=False)
    if c.returncode != 0:
        # No changes; keep it successful like a forgiving approximation.
        pass
    p["commit"] = git(["rev-parse", "HEAD"]).stdout.strip()
    save_state(st)
    print(f"> {p['name']}")
    return 0

def cmd_files(args):
    st = load_state()
    rev = next((a for a in args if not a.startswith("-")), None)
    p = find_patch(st, rev)
    stat = "-s" in args or "--stat" in args
    if stat:
        out = git(["diff", "--stat", f"{p['commit']}^", p["commit"]]).stdout
    else:
        out = git(["diff", "--name-status", f"{p['commit']}^", p["commit"]]).stdout.replace("\t", " ")
    sys.stdout.write(out)
    return 0

def cmd_id(args):
    st = load_state()
    rev = next((a for a in args if not a.startswith("-")), None)
    print(find_patch(st, rev)["commit"])
    return 0

def cmd_name(args):
    st = load_state()
    rev = next((a for a in args if not a.startswith("-")), None)
    print(find_patch(st, rev)["name"])
    return 0

def cmd_show(args):
    st = load_state()
    revs = [a for a in args if not a.startswith("-")]
    targets = [find_patch(st, r) for r in revs] if revs else [find_patch(st)]
    for p in targets:
        show_args = ["show", "--no-ext-diff"]
        if "-s" in args or "--stat" in args:
            show_args.append("--stat")
        show_args.append(p["commit"])
        sys.stdout.write(git(show_args).stdout)
    return 0

def cmd_diff(args):
    st = load_state()
    if st["applied"]:
        p = st["applied"][-1]
        diff_args = ["diff"]
        if "-s" in args or "--stat" in args:
            diff_args.append("--stat")
        diff_args += [f"{p['commit']}^", p["commit"]]
        sys.stdout.write(git(diff_args).stdout)
    return 0

def cmd_branch(args):
    if not args:
        print(branch())
        return 0
    if args[0] in ("-l", "--list"):
        cur = branch()
        p = git(["for-each-ref", "--format=%(refname:short)", "refs/heads"])
        for b in p.stdout.splitlines():
            marker = ">" if b == cur else " "
            initialized = "s" if os.path.exists(os.path.join(git_dir(), f"stg-state-{b.replace('/', '__')}.json")) else " "
            print(f"{marker} {initialized} \t{b}  |")
        return 0
    if args[0] in ("-c", "--create") and len(args) >= 2:
        start = args[2] if len(args) > 2 else "HEAD"
        git(["checkout", "-q", "-b", args[1], start])
        load_state(create=True)
        return 0
    git(["checkout", "-q", args[0]])
    return 0

def cmd_alias(cmd, args):
    gitcmd = "add" if cmd == "resolved" else cmd
    if cmd == "status":
        full = ["git", "status", "-s"] + args
    else:
        full = ["git", gitcmd] + args
    p = subprocess.run(full, text=True, capture_output=True)
    sys.stdout.write(p.stdout)
    sys.stderr.write(p.stderr)
    return p.returncode

def cmd_next_prev(cmd):
    st = load_state()
    if cmd == "next":
        if not st["unapplied"]:
            raise StgError("no unapplied patches")
        print(st["unapplied"][0]["name"])
    else:
        if len(st["applied"]) < 2:
            raise StgError("not enough patches applied")
        print(st["applied"][-2]["name"])
    return 0

def cmd_rename(args):
    st = load_state()
    names = [a for a in args if not a.startswith("-")]
    if len(names) == 1:
        old = st["applied"][-1]["name"] if st["applied"] else None
        new = names[0]
    elif len(names) >= 2:
        old, new = names[-2], names[-1]
    else:
        raise StgError("missing patch name")
    for p in st["applied"] + st["unapplied"] + st["hidden"]:
        if p["name"] == old:
            p["name"] = new
            save_state(st)
            print(f"{old} => {new}")
            if st["applied"] and st["applied"][-1] is p:
                print(f"> {new}")
            return 0
    raise StgError(f"patch `{old}` not found")

def cmd_delete(args):
    st = load_state()
    names = [a for a in args if not a.startswith("-")]
    if "-t" in args or "--top" in args or not names:
        if not st["applied"]:
            raise StgError("no patches applied")
        names = [st["applied"][-1]["name"]]
    for name in names:
        for key in ("applied", "unapplied", "hidden"):
            for i, p in enumerate(st[key]):
                if p["name"] == name:
                    del st[key][i]
                    if key == "applied":
                        reset_to_applied(st)
                    save_state(st)
                    print(f"- {name}")
                    if st["applied"]:
                        print(f"> {st['applied'][-1]['name']}")
                    break
            else:
                continue
            break
    return 0

if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
