#!/bin/bash
set -e
cp src/stg.py executable
chmod +x executable
