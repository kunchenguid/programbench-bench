import os, subprocess, tempfile, unittest
ROOT=os.path.abspath(os.path.join(os.path.dirname(__file__),'..'))
EXE=os.path.join(ROOT,'executable')

def run(args,cwd=None):
    return subprocess.run([EXE]+args,cwd=cwd,text=True,capture_output=True)

def git(args,cwd):
    return subprocess.run(['git']+args,cwd=cwd,text=True,capture_output=True,check=True)

def repo():
    d=tempfile.TemporaryDirectory()
    git(['init','-q'],d.name)
    git(['config','user.email','a@b.c'],d.name)
    git(['config','user.name','A'],d.name)
    with open(os.path.join(d.name,'f'),'w') as f: f.write('base\n')
    git(['add','f'],d.name)
    git(['commit','-qm','base'],d.name)
    return d

class CliTests(unittest.TestCase):
    def test_short_version(self):
        r=run(['version','-s'])
        self.assertEqual(r.returncode,0)
        self.assertEqual(r.stdout,'stg 2.5.5\n')
        self.assertEqual(r.stderr,'')

    def test_new_patch_updates_series_and_top(self):
        with repo() as d:
            r=run(['new','p1','-m','msg'],d)
            self.assertEqual(r.returncode,0,r.stderr)
            self.assertEqual(r.stdout,'> p1 (new)\n')
            self.assertEqual(run(['series'],d).stdout,'> p1\n')
            self.assertEqual(run(['top'],d).stdout,'p1\n')

    def test_pop_and_push_move_patches_between_sections(self):
        with repo() as d:
            run(['new','p1','-m','one'],d)
            run(['new','p2','-m','two'],d)
            r=run(['pop'],d)
            self.assertEqual(r.returncode,0,r.stderr)
            self.assertEqual(r.stdout,'- p2\n> p1\n')
            self.assertEqual(run(['series'],d).stdout,'> p1\n- p2\n')
            r=run(['push'],d)
            self.assertEqual(r.returncode,0,r.stderr)
            self.assertEqual(r.stdout,'> p2\n')
            self.assertEqual(run(['series'],d).stdout,'+ p1\n> p2\n')

    def test_refresh_records_worktree_change_and_files_lists_it(self):
        with repo() as d:
            run(['new','p1','-m','one'],d)
            with open(os.path.join(d,'f'),'a') as f: f.write('change\n')
            r=run(['refresh'],d)
            self.assertEqual(r.returncode,0,r.stderr)
            self.assertIn('> p1\n',r.stdout)
            files=run(['files'],d)
            self.assertEqual(files.returncode,0,files.stderr)
            self.assertEqual(files.stdout,'M f\n')
            ident=run(['id'],d)
            self.assertEqual(ident.returncode,0,ident.stderr)
            self.assertRegex(ident.stdout,r'^[0-9a-f]{40}\n$')

    def test_branch_and_status_alias(self):
        with repo() as d:
            self.assertEqual(run(['branch'],d).stdout,'master\n')
            self.assertIn('master',run(['branch','-l'],d).stdout)
            with open(os.path.join(d,'newfile'),'w') as f: f.write('x')
            self.assertEqual(run(['status'],d).stdout,'?? newfile\n')

if __name__=='__main__': unittest.main()
