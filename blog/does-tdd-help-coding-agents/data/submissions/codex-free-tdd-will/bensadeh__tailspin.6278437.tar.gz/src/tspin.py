#!/usr/bin/env python3
import re, subprocess, sys

HELP_LONG = """A log file highlighter

Usage: executable [OPTIONS] [FILE]

Arguments:
  [FILE]
          Filepath

Options:
  -f, --follow
          Follow the contents of a file

  -p, --print
          Print the output to stdout

      --config-path <CONFIG_PATH>
          Provide a custom path to a configuration file

  -e, --exec <EXEC>
          Run command and view the output in a pager

      --highlight <COLOR_WORD>
          Highlights in the form color:word1,word2
          
          [possible values: red, green, yellow, blue, magenta, cyan]

      --enable <ENABLED_HIGHLIGHTERS>
          Enable specific highlighters
          
          [possible values: numbers, urls, pointers, dates, paths, quotes, key-value-pairs, uuids,
          ip-addresses, processes, json]

      --disable <DISABLED_HIGHLIGHTERS>
          Disable specific highlighters
          
          [possible values: numbers, urls, pointers, dates, paths, quotes, key-value-pairs, uuids,
          ip-addresses, processes, json]

      --disable-builtin-keywords
          Disable the highlighting of all builtin keyword groups (booleans, nulls, log severities
          and common REST verbs)

      --pager <PAGER>
          Override the default pager command used by tspin. (e.g. `--pager="ov -f [FILE]"`)
          
          [env: TAILSPIN_PAGER=]

  -h, --help
          Print help (see a summary with '-h')

  -V, --version
          Print version
"""

COLORS = {"red":"31", "green":"32", "yellow":"33", "blue":"34", "magenta":"35", "cyan":"36"}


def sgr(code, text):
    return f"\x1b[{code}m{text}\x1b[0m"


def parse(argv):
    opts = {"file": None, "custom": [], "enable": None, "disable": set(), "exec": None, "no_builtin": False, "follow": False}
    i = 0
    while i < len(argv):
        arg = argv[i]
        if arg in ("-h", "--help"):
            opts["help"] = True
        elif arg in ("-V", "--version"):
            opts["version"] = True
        elif arg in ("-p", "--print"):
            pass
        elif arg in ("-f", "--follow"):
            opts["follow"] = True
        elif arg == "--disable-builtin-keywords":
            opts["no_builtin"] = True
        elif arg in ("--config-path", "--pager"):
            i += 1
        elif arg.startswith("--config-path=") or arg.startswith("--pager="):
            pass
        elif arg in ("-e", "--exec"):
            i += 1; opts["exec"] = argv[i] if i < len(argv) else ""
        elif arg.startswith("--exec="):
            opts["exec"] = arg.split("=", 1)[1]
        elif arg == "--highlight":
            i += 1; add_highlight(opts, argv[i] if i < len(argv) else "")
        elif arg.startswith("--highlight="):
            add_highlight(opts, arg.split("=", 1)[1])
        elif arg == "--enable":
            i += 1; opts["enable"] = parse_groups(argv[i] if i < len(argv) else "")
        elif arg.startswith("--enable="):
            opts["enable"] = parse_groups(arg.split("=", 1)[1])
        elif arg == "--disable":
            i += 1; opts["disable"].update(parse_groups(argv[i] if i < len(argv) else ""))
        elif arg.startswith("--disable="):
            opts["disable"].update(parse_groups(arg.split("=", 1)[1]))
        elif arg.startswith("-"):
            opts["bad"] = arg
        else:
            opts["file"] = arg
        i += 1
    return opts


def parse_groups(s):
    return {p for p in re.split(r"[, ]+", s) if p}


def add_highlight(opts, spec):
    if ":" not in spec:
        opts["highlight_error"] = spec
        return
    color, words = spec.split(":", 1)
    if color not in COLORS:
        opts["highlight_error"] = spec
        return
    for word in words.split(","):
        if word:
            opts["custom"].append((word, COLORS[color]))


def enabled(opts, group):
    if opts["enable"] is not None:
        return group in opts["enable"]
    return group not in opts["disable"]


def boundary(s, a, b):
    left = a == 0 or not (s[a-1].isalnum() or s[a-1] == "_")
    right = b == len(s) or not (s[b:b+1].isalnum() or s[b:b+1] == "_")
    return left and right


def builtin_at(s, i, opts):
    if opts["no_builtin"]:
        return None
    table = {"ERROR":"31", "WARN":"33", "INFO":"37", "DEBUG":"32", "TRACE":"2", "true":"3;31", "false":"3;31", "null":"3;31"}
    for word, code in sorted(table.items(), key=lambda x: -len(x[0])):
        if s.startswith(word, i) and boundary(s, i, i + len(word)):
            return len(word), code
    for word in ("GET", "POST", "PUT", "PATCH", "DELETE", "HEAD", "OPTIONS"):
        token = f" {word} "
        if s.startswith(token, i):
            return len(token), "42;30"
    return None


def match_any(pattern, s, i):
    m = pattern.match(s, i)
    if m:
        return m.end() - i, m.group(0)
    return None

URL_RE = re.compile(r"https?://[^\s\"']+")
IP_RE = re.compile(r"\d{1,3}(?:\.\d{1,3}){3}")
UUID_RE = re.compile(r"[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}")
NUM_RE = re.compile(r"\d+(?:\.\d+)?")
PATH_RE = re.compile(r"(?:/[A-Za-z0-9_.-]+)+")
QUOTE_RE = re.compile(r"\"(?:[^\"\\]|\\.)*\"")
DATE_RE = re.compile(r"\d{4}-\d{2}-\d{2}(?:[T ][0-9:.Z+-]+)?|(?:Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)\s+\d{1,2}\s+[0-9:.]+")
PROC_RE = re.compile(r"[A-Za-z0-9_.-]+\[\d+\]")


def highlight_text(text, opts):
    out = []
    i = 0
    while i < len(text):
        custom = None
        for word, code in opts["custom"]:
            if text.startswith(word, i):
                custom = (len(word), code); break
        if custom:
            n, code = custom; out.append(sgr(code, text[i:i+n])); i += n; continue
        b = builtin_at(text, i, opts)
        if b:
            n, code = b; out.append(sgr(code, text[i:i+n])); i += n; continue
        if enabled(opts, "quotes"):
            m = match_any(QUOTE_RE, text, i)
            if m:
                n, val = m; out.append(sgr("33", val)); i += n; continue
        if enabled(opts, "urls"):
            m = match_any(URL_RE, text, i)
            if m:
                n, val = m
                mm = re.match(r"(https?)(://)([^/\s]+)(.*)", val)
                if mm:
                    out.append(sgr("2;32", mm.group(1)) + mm.group(2) + sgr("2;34", mm.group(3)) + (sgr("34", mm.group(4)) if mm.group(4) else ""))
                else:
                    out.append(sgr("2;32", val))
                i += n; continue
        if enabled(opts, "ip-addresses"):
            m = match_any(IP_RE, text, i)
            if m:
                n, val = m; out.append("".join(sgr("31", p) if p == "." else sgr("3;34", p) for p in re.split(r"(\.)", val))); i += n; continue
        if enabled(opts, "uuids"):
            m = match_any(UUID_RE, text, i)
            if m:
                n, val = m; out.append(sgr("36", val)); i += n; continue
        if enabled(opts, "paths"):
            m = match_any(PATH_RE, text, i)
            if m:
                n, val = m; out.append("".join(sgr("33", part) if part == "/" else sgr("32", part) for part in re.split(r"(/)", val) if part)); i += n; continue
        if enabled(opts, "processes"):
            m = match_any(PROC_RE, text, i)
            if m:
                n, val = m; out.append(sgr("35", val)); i += n; continue
        if enabled(opts, "dates"):
            m = match_any(DATE_RE, text, i)
            if m:
                n, val = m; out.append(sgr("2", val)); i += n; continue
        if enabled(opts, "key-value-pairs"):
            km = re.match(r"[A-Za-z_][A-Za-z0-9_.-]*(?==)", text[i:])
            if km:
                key = km.group(0); out.append(sgr("2", key)); i += len(key); continue
            if text[i] == "=":
                out.append(sgr("37", "=")); i += 1; continue
        if enabled(opts, "numbers"):
            m = match_any(NUM_RE, text, i)
            if m:
                n, val = m; out.append(sgr("36", val)); i += n; continue
        out.append(text[i]); i += 1
    return "".join(out)


def read_input(opts):
    if opts.get("exec") is not None:
        p = subprocess.run(opts["exec"], shell=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
        return p.stdout, p.returncode
    if opts.get("file"):
        try:
            with open(opts["file"], "rb") as f:
                return f.read(), 0
        except OSError as e:
            sys.stderr.write(f"Error:   ⚠ \x1b[33m{opts['file']}\x1b[0m: {e.strerror}\n\n")
            return None, 1
    return sys.stdin.buffer.read(), 0


def main():
    opts = parse(sys.argv[1:])
    if opts.get("version"):
        print("tspin 5.6.0")
        return 0
    if opts.get("help"):
        sys.stdout.write(HELP_LONG)
        return 0
    if opts.get("bad"):
        sys.stderr.write(f"error: unexpected argument '{opts['bad']}' found\n\nUsage: executable [OPTIONS] [FILE]\n\nFor more information, try '--help'.\n")
        return 2
    if opts.get("highlight_error"):
        color = opts["highlight_error"].split(":", 1)[0]
        sys.stderr.write(f"error: invalid value '{opts['highlight_error']}' for '--highlight <COLOR_WORD>': invalid variant: {color}\n\nFor more information, try '--help'.\n")
        return 2
    if opts["enable"] is not None and opts["disable"]:
        sys.stderr.write("Error:   × cannot both enable and disable highlighters\n\n")
        return 1
    data, status = read_input(opts)
    if data is None:
        return status
    text = data.decode("utf-8", "replace")
    sys.stdout.write(highlight_text(text, opts))
    return status

if __name__ == "__main__":
    raise SystemExit(main())
