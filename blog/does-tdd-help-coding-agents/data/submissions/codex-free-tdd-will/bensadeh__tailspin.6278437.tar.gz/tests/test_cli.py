import subprocess, pathlib
ROOT = pathlib.Path(__file__).resolve().parents[1]
BIN = ROOT / "executable"

def build():
    subprocess.run(["bash", "compile.sh"], cwd=ROOT, check=True)

def run(args, data=None):
    return subprocess.run([str(BIN), *args], input=data, stdout=subprocess.PIPE, stderr=subprocess.PIPE, cwd=ROOT)

def test_stdin_plain_text_passthrough_when_no_patterns():
    build()
    p = run(["-p"], b"hello\n")
    assert p.returncode == 0
    assert p.stdout == b"hello\n"
    assert p.stderr == b""

def test_version_and_help_match_public_cli_shape():
    build()
    version = run(["--version"])
    assert version.returncode == 0
    assert version.stdout == b"tspin 5.6.0\n"
    help_out = run(["--help"])
    assert help_out.returncode == 0
    text = help_out.stdout.decode()
    assert "A log file highlighter" in text
    assert "Usage: executable [OPTIONS] [FILE]" in text
    assert "--highlight <COLOR_WORD>" in text
    assert "--disable-builtin-keywords" in text

def test_reads_file_argument():
    build()
    sample = ROOT / "sample.log"
    sample.write_text("hello file\n")
    p = run(["-p", str(sample)])
    assert p.returncode == 0
    assert p.stdout == b"hello file\n"

def test_highlights_common_log_tokens_on_stdout():
    build()
    line = b"INFO WARN ERROR DEBUG TRACE true null GET /tmp/a 192.168.0.1 123 https://x.y/z key=value \"quote\"\n"
    p = run(["-p"], line)
    assert p.returncode == 0
    out = p.stdout
    assert b"\x1b[37mINFO\x1b[0m" in out
    assert b"\x1b[33mWARN\x1b[0m" in out
    assert b"\x1b[31mERROR\x1b[0m" in out
    assert b"\x1b[32mDEBUG\x1b[0m" in out
    assert b"\x1b[2mTRACE\x1b[0m" in out
    assert b"\x1b[3;31mtrue\x1b[0m" in out
    assert b"\x1b[3;31mnull\x1b[0m" in out
    assert b"\x1b[42;30m GET \x1b[0m" in out
    assert b"\x1b[36m123\x1b[0m" in out
    assert b"\x1b[2;32mhttps\x1b[0m://" in out
    assert b"\x1b[2mkey\x1b[0m\x1b[37m=\x1b[0mvalue" in out
    assert b"\x1b[33m\"quote\"\x1b[0m" in out

def test_highlight_disable_enable_and_validation_flags():
    build()
    custom = run(["-p", "--highlight", "red:error", "--highlight", "green:ok,abc"], b"abc error ok\n")
    assert custom.returncode == 0
    assert custom.stdout == b"\x1b[32mabc\x1b[0m \x1b[31merror\x1b[0m \x1b[32mok\x1b[0m\n"

    no_builtin = run(["-p", "--disable-builtin-keywords"], b"ERROR true GET 123\n")
    assert no_builtin.returncode == 0
    assert b"ERROR true GET" in no_builtin.stdout
    assert b"\x1b[36m123\x1b[0m" in no_builtin.stdout

    disabled_numbers = run(["-p", "--disable", "numbers"], b"abc 123 ERROR\n")
    assert disabled_numbers.returncode == 0
    assert b" 123 " in disabled_numbers.stdout
    assert b"\x1b[31mERROR\x1b[0m" in disabled_numbers.stdout

    enabled_numbers = run(["-p", "--enable", "numbers"], b"abc 123 ERROR\n")
    assert enabled_numbers.returncode == 0
    assert enabled_numbers.stdout == b"abc \x1b[36m123\x1b[0m \x1b[31mERROR\x1b[0m\n"

    conflict = run(["--enable", "dates", "--disable", "urls"])
    assert conflict.returncode == 1
    assert b"cannot both enable and disable highlighters" in conflict.stderr

    bad = run(["--highlight", "orange:x"])
    assert bad.returncode == 2
    assert b"invalid variant: orange" in bad.stderr


def test_exec_command_output_and_missing_file_error():
    build()
    p = run(["-p", "--exec", "printf \"ERROR 42\\n\""])
    assert p.returncode == 0
    assert p.stdout == b"\x1b[31mERROR\x1b[0m \x1b[36m42\x1b[0m\n"

    missing = run(["/tmp/definitely-no-such-tailspin-file"])
    assert missing.returncode == 1
    assert b"No such file or directory" in missing.stderr
    assert b"\x1b[33m/tmp/definitely-no-such-tailspin-file\x1b[0m" in missing.stderr
