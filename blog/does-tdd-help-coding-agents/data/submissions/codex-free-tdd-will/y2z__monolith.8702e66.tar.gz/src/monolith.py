#!/usr/bin/env python3
import argparse
import base64
import mimetypes
import os
import re
import sys
from html.parser import HTMLParser
from pathlib import Path
from urllib.parse import quote, unquote, urljoin, urlparse
from urllib.request import pathname2url


VERSION = "monolith 2.11.0"
BANNER = r""" _____    _____________   __________     ___________________    ___
|     \  /             \ |          |   |                   |  |   |
|      \/       __      \|    __    |   |    ___     ___    |__|   |
|              |  |          |  |   |   |   |   |   |   |          |
|   |\    /|   |__|          |__|   |___|   |   |   |   |    __    |
|   | \__/ |          |\                    |   |   |   |   |  |   |
|___|      |__________| \___________________|   |___|   |___|  |___|"""


class Options:
    def __init__(self):
        self.no_audio = False
        self.base_url = None
        self.blacklist = False
        self.no_css = False
        self.cookie_file = None
        self.domains = []
        self.ignore_errors = False
        self.encoding = "utf-8"
        self.no_frames = False
        self.no_fonts = False
        self.no_images = False
        self.isolate = False
        self.no_js = False
        self.no_video = False
        self.insecure = False
        self.mhtml = False
        self.no_metadata = False
        self.unwrap_noscript = False
        self.output = None
        self.quiet = False
        self.timeout = 60
        self.user_agent = None


def file_url(path):
    return "file://" + pathname2url(str(Path(path).resolve()))


def path_from_file_url(url):
    parsed = urlparse(url)
    return Path(unquote(parsed.path))


def guess_mime(url):
    mime, _ = mimetypes.guess_type(urlparse(url).path or url)
    return mime or "text/plain"


def make_data_url(data, mime):
    return f"data:{mime};base64,{base64.b64encode(data).decode('ascii')}"


def resolve_url(value, base_url):
    if not value or value.startswith(("data:", "mailto:", "javascript:", "#")):
        return value
    return urljoin(base_url, value)


def read_resource(url, options, log):
    if not url:
        return None
    parsed = urlparse(url)
    try:
        if parsed.scheme in ("", "file"):
            path = Path(url) if parsed.scheme == "" else path_from_file_url(url)
            data = path.read_bytes()
        else:
            raise OSError("network unavailable")
        if log is not None:
            log.append(url if parsed.scheme else file_url(path))
        return data
    except Exception:
        if options.ignore_errors:
            return b""
        return None


def process_css(css, base_url, options, log):
    if options.no_css:
        return ""

    def repl(match):
        raw = match.group(1).strip().strip("'\"")
        absolute = resolve_url(raw, base_url)
        data = None if options.no_images else read_resource(absolute, options, log)
        if data is None:
            return f"url({match.group(1)})"
        return f'url("{make_data_url(data, guess_mime(absolute))}")'

    return re.sub(r"url\(([^)]+)\)", repl, css)


def serialize_attrs(attrs):
    out = []
    for key, value in attrs:
        if value is None:
            out.append(key)
        else:
            escaped = (
                value.replace("&", "&amp;")
                .replace('"', "&quot;")
                .replace("<", "&lt;")
                .replace(">", "&gt;")
            )
            out.append(f'{key}="{escaped}"')
    return (" " + " ".join(out)) if out else ""


class Rewriter(HTMLParser):
    def __init__(self, base_url, options, log):
        super().__init__(convert_charrefs=False)
        self.base_url = base_url
        self.options = options
        self.log = log
        self.out = []
        self.skip_script = False
        self.in_style = False
        self.style_parts = []
        self.in_noscript = False

    def handle_decl(self, decl):
        self.out.append("<!DOCTYPE html>" if decl.lower() == "doctype html" else f"<!{decl.upper()}>")

    def handle_starttag(self, tag, attrs):
        attrs = list(attrs)
        low = tag.lower()
        if low == "head":
            self.out.append(f"<{tag}{serialize_attrs(attrs)}>")
            csp = self.csp_content()
            if csp:
                self.out.append(f'<meta http-equiv="Content-Security-Policy" content="{csp}"></meta>')
            if self.options.base_url:
                self.out.append(f'<base href="{self.options.base_url}"></base>')
            return
        if low == "link":
            attrs = self.rewrite_link(attrs)
        elif low == "script":
            handled = self.handle_script_start(tag, attrs)
            if handled:
                return
            attrs = [(k, v) for k, v in attrs if not (self.options.no_js and k.lower() == "src")]
            self.out.append(f"<{tag}{serialize_attrs(attrs)}>")
            if self.options.no_js:
                self.skip_script = True
            return
        elif low == "style":
            self.in_style = True
            self.style_parts = []
        elif low in ("img", "source"):
            attrs = self.rewrite_src(attrs, remove=self.options.no_images, kind="image")
        elif low in ("iframe", "frame"):
            attrs = self.rewrite_src(attrs, remove=self.options.no_frames, kind="html")
        elif low == "audio":
            attrs = self.rewrite_src(attrs, remove=self.options.no_audio, kind="audio")
        elif low == "video":
            attrs = self.rewrite_src(attrs, remove=self.options.no_video, kind="video")
        elif low == "a":
            attrs = self.rewrite_href(attrs)
        elif low == "noscript" and self.options.unwrap_noscript:
            self.in_noscript = True
            self.out.append("<!--noscript-->")
            return
        self.out.append(f"<{tag}{serialize_attrs(attrs)}>")

    def handle_startendtag(self, tag, attrs):
        self.handle_starttag(tag, attrs)
        self.handle_endtag(tag)

    def handle_endtag(self, tag):
        low = tag.lower()
        if low == "script" and self.skip_script:
            self.skip_script = False
            self.out.append(f"</{tag}>")
            return
        if low == "style" and self.in_style:
            css = "".join(self.style_parts)
            self.out.append(process_css(css, self.base_url, self.options, self.log))
            self.in_style = False
        if low == "noscript" and self.options.unwrap_noscript:
            self.in_noscript = False
            self.out.append("<!--/noscript-->")
            return
        self.out.append(f"</{tag}>")

    def handle_data(self, data):
        if self.skip_script:
            return
        if self.in_style:
            self.style_parts.append(data)
            return
        self.out.append(data)

    def handle_entityref(self, name):
        self.out.append(f"&{name};")

    def handle_charref(self, name):
        self.out.append(f"&#{name};")

    def handle_comment(self, data):
        self.out.append(f"<!--{data}-->")

    def csp_content(self):
        parts = []
        if self.options.isolate:
            parts.append("default-src 'unsafe-eval' 'unsafe-inline' data:;")
        if self.options.no_css:
            parts.append("style-src 'none';")
        if self.options.no_js or self.options.mhtml:
            parts.append("script-src 'none';")
        if self.options.no_frames:
            parts.append("frame-src 'none'; child-src 'none';")
        return " ".join(parts)

    def rewrite_link(self, attrs):
        rel = next((v for k, v in attrs if k.lower() == "rel"), "") or ""
        if "stylesheet" not in rel.lower():
            return self.rewrite_href(attrs)
        if self.options.no_css:
            return [(k, v) for k, v in attrs if k.lower() != "href"]
        return self.embed_attr(attrs, "href", "text/css", css=True)

    def handle_script_start(self, tag, attrs):
        if self.options.no_js or self.options.mhtml:
            return False
        src = next((v for k, v in attrs if k.lower() == "src"), None)
        new_attrs = [(k, v) for k, v in attrs if k.lower() != "src"]
        if src:
            absolute = resolve_url(src, self.base_url)
            data = read_resource(absolute, self.options, self.log)
            if data is not None:
                self.out.append(f"<{tag}{serialize_attrs(new_attrs)}>")
                self.out.append(data.decode(self.options.encoding, "replace"))
                self.skip_script = True
                return True
        return False

    def rewrite_src(self, attrs, remove, kind):
        if remove:
            return [(k, "" if k.lower() == "src" else v) for k, v in attrs]
        return self.embed_attr(attrs, "src", None)

    def rewrite_href(self, attrs):
        out = []
        for k, v in attrs:
            if k.lower() == "href" and v:
                out.append((k, resolve_url(v, self.base_url)))
            else:
                out.append((k, v))
        return out

    def embed_attr(self, attrs, attr, forced_mime, css=False):
        out = []
        for k, v in attrs:
            if k.lower() != attr or not v:
                out.append((k, v))
                continue
            absolute = resolve_url(v, self.base_url)
            data = read_resource(absolute, self.options, self.log)
            if data is None:
                out.append((k, v))
                continue
            mime = forced_mime or guess_mime(absolute)
            if css:
                text = data.decode(self.options.encoding, "replace")
                data = process_css(text, absolute, self.options, self.log).encode(self.options.encoding)
            out.append((k, make_data_url(data, mime)))
        return out


def parse_args(argv):
    opts = Options()
    target = None
    value_options = {"-b": "base_url", "--base-url": "base_url", "-C": "cookie_file", "--cookie-file": "cookie_file",
                     "-d": "domain", "--domain": "domain", "-E": "encoding", "--encoding": "encoding",
                     "-o": "output", "--output": "output", "-t": "timeout", "--timeout": "timeout",
                     "-u": "user_agent", "--user-agent": "user_agent"}
    flags = {"-a": "no_audio", "--no-audio": "no_audio", "-B": "blacklist", "--blacklist-domains": "blacklist",
             "-c": "no_css", "--no-css": "no_css", "-e": "ignore_errors", "--ignore-errors": "ignore_errors",
             "-f": "no_frames", "--no-frames": "no_frames", "-F": "no_fonts", "--no-fonts": "no_fonts",
             "-i": "no_images", "--no-images": "no_images", "-I": "isolate", "--isolate": "isolate",
             "-j": "no_js", "--no-js": "no_js", "-k": "insecure", "--insecure": "insecure",
             "-m": "mhtml", "--mhtml": "mhtml", "-M": "no_metadata", "--no-metadata": "no_metadata",
             "-n": "unwrap_noscript", "--unwrap-noscript": "unwrap_noscript", "-q": "quiet", "--quiet": "quiet",
             "-v": "no_video", "--no-video": "no_video"}
    i = 0
    while i < len(argv):
        arg = argv[i]
        if arg in ("-h", "--help"):
            print_help()
            raise SystemExit(0)
        if arg in ("-V", "--version"):
            print(VERSION)
            raise SystemExit(0)
        if arg in flags:
            setattr(opts, flags[arg], True)
            i += 1
            continue
        if arg in value_options:
            if i + 1 >= len(argv):
                print(f"error: a value is required for '{long_value_name(arg)}' but none was supplied\n", file=sys.stderr)
                print("For more information, try '--help'.", file=sys.stderr)
                raise SystemExit(2)
            val = argv[i + 1]
            name = value_options[arg]
            if name == "domain":
                opts.domains.append(val)
            elif name == "timeout":
                opts.timeout = int(val)
            else:
                setattr(opts, name, val)
            i += 2
            continue
        if arg.startswith("-") and arg != "-":
            print(f"error: unexpected argument '{arg}' found\n", file=sys.stderr)
            print(f"  tip: to pass '{arg}' as a value, use '-- {arg}'\n", file=sys.stderr)
            print("Usage: executable [OPTIONS] <TARGET>\n", file=sys.stderr)
            print("For more information, try '--help'.", file=sys.stderr)
            raise SystemExit(2)
        if target is None:
            target = arg
        else:
            print(f"error: unexpected argument '{arg}' found", file=sys.stderr)
            raise SystemExit(2)
        i += 1
    if target is None:
        print("error: the following required arguments were not provided:", file=sys.stderr)
        print("  <TARGET>\n", file=sys.stderr)
        print("Usage: executable <TARGET>\n", file=sys.stderr)
        print("For more information, try '--help'.", file=sys.stderr)
        raise SystemExit(2)
    return opts, target


def long_value_name(arg):
    names = {"-o": "--output <result.html>", "-b": "--base-url <http://localhost/>"}
    return names.get(arg, arg)


def print_help():
    print(BANNER)
    print()
    print(VERSION)
    print()
    print("CLI tool and library for saving web pages as a single HTML file")
    print()
    print("Usage: executable [OPTIONS] <TARGET>")
    print()
    print("Arguments:")
    print("  <TARGET>  URL or file path, use - for STDIN")
    print()
    print("Options:")
    print("  -a, --no-audio                      Remove audio sources")
    print("  -b, --base-url <http://localhost/>  Set custom base URL")
    print("  -B, --blacklist-domains             Treat specified domains as blacklist")
    print("  -c, --no-css                        Remove CSS")
    print("  -C, --cookie-file <cookies.txt>     Specify cookie file")
    print("  -d, --domain <example.com>          Specify domains to use for white/black-listing")
    print("  -e, --ignore-errors                 Ignore network errors")
    print("  -E, --encoding <UTF-8>              Enforce custom charset")
    print("  -f, --no-frames                     Remove frames and iframes")
    print("  -F, --no-fonts                      Remove fonts")
    print("  -i, --no-images                     Remove images")
    print("  -I, --isolate                       Cut off document from the Internet")
    print("  -j, --no-js                         Remove JavaScript")
    print("  -k, --insecure                      Allow invalid X.509 (TLS) certificates")
    print("  -m, --mhtml                         Use MHTML as output format")
    print("  -M, --no-metadata                   Exclude timestamp and source information")
    print("  -n, --unwrap-noscript               Replace NOSCRIPT elements with their contents")
    print("  -o, --output <result.html>          File to write to, use - for STDOUT")
    print("  -q, --quiet                         Suppress verbosity")
    print("  -t, --timeout <60>                  Adjust network request timeout")
    print("  -u, --user-agent <Firefox>          Set custom User-Agent string")
    print("  -v, --no-video                      Remove video sources")
    print("  -h, --help                          Print help")
    print("  -V, --version                       Print version")


def render_document(text, base_url, options, log):
    parser = Rewriter(base_url, options, log)
    parser.feed(text)
    html = "".join(parser.out)
    if "<head" in html and "name=\"robots\"" not in html:
        html = re.sub(r"</head>", '<meta name="robots" content="none"></meta></head>', html, count=1, flags=re.I)
    return html


def mhtml_wrap(html):
    return (
        'MIME-Version: 1.0\r\n'
        'Content-Type: multipart/related; boundary="----=_NextPart_000_0000"\r\n'
        '\r\n------=_NextPart_000_0000\r\n'
        'Content-Type: text/html; charset="utf-8"\r\n'
        'Content-Location: http://example.com/\r\n\r\n'
        + html
        + '\r\n------=_NextPart_000_0000--\r\n'
    )


def output_path(template, html):
    title = "monolith"
    m = re.search(r"<title[^>]*>(.*?)</title>", html, re.I | re.S)
    if m:
        title = re.sub(r"\s+", " ", m.group(1)).strip() or title
    title = re.sub(r'[\\/:*?"<>|]+', "_", title)
    from datetime import datetime, timezone
    timestamp = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H_%M_%SZ")
    return template.replace("%title%", title).replace("%timestamp%", timestamp)


def main(argv=None):
    options, target = parse_args(list(sys.argv[1:] if argv is None else argv))
    log = [] if not options.quiet else None
    if target == "-":
        raw = sys.stdin.buffer.read()
        source_url = options.base_url or "about:blank"
    else:
        path = Path(target)
        raw = path.read_bytes()
        source_url = file_url(path)
        if log is not None:
            log.append(source_url)
    base_url = options.base_url or (source_url if source_url.endswith("/") else source_url.rsplit("/", 1)[0] + "/")
    text = raw.decode(options.encoding, "replace")
    html = render_document(text, base_url, options, log)
    if not options.no_metadata:
        from datetime import datetime, timezone
        stamp = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
        origin = "local source" if source_url.startswith("file:") else source_url
        html = f"<!-- Saved from {origin} at {stamp} using monolith v2.11.0 -->\n" + html
    if options.mhtml:
        html = mhtml_wrap(html)
    if log is not None:
        for item in log:
            print(item, file=sys.stderr)
    if options.output and options.output != "-":
        out = output_path(options.output, html)
        Path(out).parent.mkdir(parents=True, exist_ok=True)
        Path(out).write_text(html, encoding=options.encoding, newline="")
    else:
        sys.stdout.write(html)
        if not html.endswith("\n"):
            sys.stdout.write("\n")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
