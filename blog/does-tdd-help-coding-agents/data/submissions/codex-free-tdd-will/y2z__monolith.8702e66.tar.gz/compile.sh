#!/bin/bash
set -e
rm -f executable
cp src/monolith.py executable
chmod +x executable
