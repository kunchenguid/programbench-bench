import os
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
PROGRAM = ROOT / "src" / "monolith.py"


def run_cli(args, input_text=None, cwd=None):
    return subprocess.run(
        [sys.executable, str(PROGRAM), *args],
        input=input_text,
        text=True,
        cwd=cwd or ROOT,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
    )


class MonolithCliTests(unittest.TestCase):
    def test_version_prints_monolith_version(self):
        result = run_cli(["--version"])
        self.assertEqual(result.returncode, 0)
        self.assertEqual(result.stdout, "monolith 2.11.0\n")
        self.assertEqual(result.stderr, "")

    def test_local_html_embeds_assets_and_rewrites_links(self):
        with tempfile.TemporaryDirectory() as tmp:
            site = Path(tmp)
            (site / "style.css").write_text("body{background:url(bg.png)}\n")
            (site / "app.js").write_text("alert(2);\n")
            (site / "img.png").write_bytes(b"IMGDATA")
            (site / "bg.png").write_bytes(b"BGDATA")
            page = site / "page.html"
            page.write_text(
                '<!doctype html><html><head><title>My Page</title>'
                '<link rel="stylesheet" href="style.css">'
                '<script src="app.js"></script></head><body>'
                '<img src="img.png"><a href="other.html">Other</a></body></html>'
            )

            result = run_cli(["-M", str(page)])

        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertIn('<link rel="stylesheet" href="data:text/css;base64,', result.stdout)
        self.assertIn("Ym9keXtiYWNrZ3JvdW5kOnVybCgiZGF0YTppbWFnZS9wbmc7YmFzZTY0LFFrZEVRVlJCIil9Cg==", result.stdout)
        self.assertIn("<script>alert(2);\n</script>", result.stdout)
        self.assertIn('<img src="data:image/png;base64,SU1HREFUQQ==">', result.stdout)
        self.assertIn('<a href="file://', result.stdout)
        self.assertIn("/other.html", result.stdout)
        self.assertIn("page.html", result.stderr)
        self.assertIn("style.css", result.stderr)

    def test_removal_flags_empty_sources_and_add_security_policy(self):
        with tempfile.TemporaryDirectory() as tmp:
            page = Path(tmp) / "page.html"
            page.write_text(
                "<html><head><style>body{color:red}</style>"
                '<script src="app.js">inline()</script></head><body>'
                '<img src="img.png"><iframe src="frame.html"></iframe>'
                "<noscript><p>No JS</p></noscript></body></html>"
            )
            result = run_cli(["-M", "-c", "-j", "-f", "-i", "-n", str(page)])

        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertIn("style-src 'none';", result.stdout)
        self.assertIn("script-src 'none';", result.stdout)
        self.assertIn("frame-src 'none'; child-src 'none';", result.stdout)
        self.assertIn("<style></style>", result.stdout)
        self.assertIn("<script></script>", result.stdout)
        self.assertIn('<img src="">', result.stdout)
        self.assertIn('<iframe src=""></iframe>', result.stdout)
        self.assertIn("<!--noscript--><p>No JS</p><!--/noscript-->", result.stdout)

    def test_output_template_writes_file_instead_of_stdout(self):
        with tempfile.TemporaryDirectory() as tmp:
            page = Path(tmp) / "page.html"
            page.write_text("<html><head><title>A/B</title></head><body>ok</body></html>")
            template = str(Path(tmp) / "%title%-%timestamp%.html")
            result = run_cli(["-M", "-o", template, str(page)])
            outputs = list(Path(tmp).glob("A_B-*.html"))
            body = outputs[0].read_text() if outputs else ""

        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertEqual(result.stdout, "")
        self.assertEqual(len(outputs), 1)
        self.assertIn("<body>ok</body>", body)


if __name__ == "__main__":
    unittest.main()
