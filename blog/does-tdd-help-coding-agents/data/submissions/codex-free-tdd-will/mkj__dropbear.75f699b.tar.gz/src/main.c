#define _POSIX_C_SOURCE 200809L

#include <errno.h>
#include <grp.h>
#include <netdb.h>
#include <sys/socket.h>
#include <sys/select.h>
#include <sys/types.h>
#include <signal.h>
#include <stdarg.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <unistd.h>

#define MAX_PORTS 10

struct listen_spec {
    char text[256];
    char host[192];
    char port[64];
};

static volatile sig_atomic_t stop_now = 0;

static void print_help(void) {
    fputs(
"Dropbear server v2025.89 https://matt.ucc.asn.au/dropbear/dropbear.html\n"
"Usage: ./executable [options]\n"
"-b bannerfile\tDisplay the contents of bannerfile before user login\n"
"\t\t(default: none)\n"
"-r keyfile      Specify hostkeys (repeatable)\n"
"\t\tdefaults: \n"
"\t\t- rsa /etc/dropbear/dropbear_rsa_host_key\n"
"\t\t- ecdsa /etc/dropbear/dropbear_ecdsa_host_key\n"
"\t\t- ed25519 /etc/dropbear/dropbear_ed25519_host_key\n"
"-D\t\tDirectory containing authorized_keys file\n"
"-R\t\tCreate hostkeys as required\n"
"-F\t\tDon't fork into background\n"
"-e\t\tPass on server process environment to child process\n"
"(Syslog support not compiled in, using stderr)\n"
"-m\t\tDon't display the motd on login\n"
"-w\t\tDisallow root logins\n"
"-G\t\tRestrict logins to members of specified group\n"
"-s\t\tDisable password logins\n"
"-g\t\tDisable password logins for root\n"
"-B\t\tAllow blank password logins\n"
"-t\t\tEnable two-factor authentication (both password and public key required)\n"
"-T\t\tMaximum authentication tries (default 10)\n"
"-j\t\tDisable local port forwarding\n"
"-k\t\tDisable remote port forwarding\n"
"-a\t\tAllow connections to forwarded ports from any host\n"
"-c command\tForce executed command\n"
"-p [address:]port\n"
"\t\tListen on specified tcp port (and optionally address),\n"
"\t\tup to 10 can be specified\n"
"\t\t(default port is 22 if none specified)\n"
"-P PidFile\tCreate pid file PidFile\n"
"\t\t(default /var/run/dropbear.pid)\n"
"-l <interface>\n"
"\t\tinterface to bind on\n"
"-i\t\tStart for inetd\n"
"-W <receive_window_buffer> (default 24576, larger may be faster, max 10MB)\n"
"-K <keepalive>  (0 is never, default 0, in seconds)\n"
"-I <idle_timeout>  (0 is never, default 0, in seconds)\n"
"-z    disable QoS\n"
"-V    Version\n", stderr);
}

static void logmsg(const char *fmt, ...) {
    time_t now = time(NULL);
    struct tm tmv;
    localtime_r(&now, &tmv);
    fprintf(stderr, "[%ld] %s %2d %02d:%02d:%02d ", (long)getpid(),
            (const char *[]){"Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"}[tmv.tm_mon],
            tmv.tm_mday, tmv.tm_hour, tmv.tm_min, tmv.tm_sec);
    va_list ap;
    va_start(ap, fmt);
    vfprintf(stderr, fmt, ap);
    va_end(ap);
    fputc('\n', stderr);
}

static bool is_uint(const char *s) {
    if (!s || !*s) return false;
    for (; *s; s++) {
        if (*s < '0' || *s > '9') return false;
    }
    return true;
}

static int missing_arg(void) {
    logmsg("Early exit: Missing argument");
    return 1;
}

static void on_signal(int sig) {
    (void)sig;
    stop_now = 1;
}

static void parse_listen_spec(const char *in, struct listen_spec *out) {
    memset(out, 0, sizeof(*out));
    snprintf(out->text, sizeof(out->text), "%s", in);
    const char *colon = strrchr(in, ':');
    if (colon && colon != in) {
        size_t host_len = (size_t)(colon - in);
        if (host_len >= sizeof(out->host)) host_len = sizeof(out->host) - 1;
        memcpy(out->host, in, host_len);
        out->host[host_len] = '\0';
        snprintf(out->port, sizeof(out->port), "%s", colon + 1);
    } else {
        out->host[0] = '\0';
        snprintf(out->port, sizeof(out->port), "%s", in);
    }
}

static int open_listener(const struct listen_spec *spec) {
    struct addrinfo hints;
    struct addrinfo *res = NULL;
    memset(&hints, 0, sizeof(hints));
    hints.ai_family = AF_UNSPEC;
    hints.ai_socktype = SOCK_STREAM;
    hints.ai_flags = AI_PASSIVE;
    int gai = getaddrinfo(spec->host[0] ? spec->host : NULL, spec->port, &hints, &res);
    if (gai != 0) {
        logmsg("Failed listening on '%s': Error resolving: %s", spec->port, gai_strerror(gai));
        return -1;
    }

    int fd = -1;
    for (struct addrinfo *ai = res; ai; ai = ai->ai_next) {
        fd = socket(ai->ai_family, ai->ai_socktype, ai->ai_protocol);
        if (fd < 0) continue;
        int yes = 1;
        setsockopt(fd, SOL_SOCKET, SO_REUSEADDR, &yes, sizeof(yes));
        if (bind(fd, ai->ai_addr, ai->ai_addrlen) == 0 && listen(fd, 64) == 0) {
            break;
        }
        close(fd);
        fd = -1;
    }
    if (fd < 0) {
        logmsg("Failed listening on '%s': %s", spec->text, strerror(errno));
    }
    freeaddrinfo(res);
    return fd;
}

static int serve(int *fds, int nfds) {
    signal(SIGTERM, on_signal);
    signal(SIGINT, on_signal);
    while (!stop_now) {
        fd_set rfds;
        FD_ZERO(&rfds);
        int maxfd = -1;
        for (int i = 0; i < nfds; i++) {
            FD_SET(fds[i], &rfds);
            if (fds[i] > maxfd) maxfd = fds[i];
        }
        int ready = select(maxfd + 1, &rfds, NULL, NULL, NULL);
        if (ready < 0) {
            if (errno == EINTR) continue;
            return 1;
        }
        for (int i = 0; i < nfds; i++) {
            if (!FD_ISSET(fds[i], &rfds)) continue;
            struct sockaddr_storage ss;
            socklen_t slen = sizeof(ss);
            int cfd = accept(fds[i], (struct sockaddr *)&ss, &slen);
            if (cfd < 0) continue;
            char host[256], serv[32];
            if (getnameinfo((struct sockaddr *)&ss, slen, host, sizeof(host), serv, sizeof(serv),
                            NI_NUMERICHOST | NI_NUMERICSERV) == 0) {
                logmsg("Child connection from %s:%s", host, serv);
            }
            const char banner[] = "SSH-2.0-dropbear_2025.89\r\n";
            ssize_t ignored = write(cfd, banner, sizeof(banner) - 1);
            (void)ignored;
            close(cfd);
        }
    }
    logmsg("Early exit: Terminated by signal");
    return 0;
}

int main(int argc, char **argv) {
    bool create_keys = false;
    bool foreground = false;
    char *keyfiles[32];
    int nkeys = 0;
    const char *pidfile = "/var/run/dropbear.pid";
    struct listen_spec specs[MAX_PORTS];
    int nspecs = 0;

    if (argc == 2 && strcmp(argv[1], "-V") == 0) {
        fprintf(stderr, "Dropbear v2025.89\n");
        return 0;
    }
    if (argc == 2 && strcmp(argv[1], "-h") == 0) {
        print_help();
        return 0;
    }
    if (argc >= 2 && argv[1][0] == '-' && argv[1][1] == '-' && argv[1][2] != '\0') {
        fprintf(stderr, "Invalid option --\n");
        print_help();
        return 1;
    }

    for (int i = 1; i < argc; i++) {
        char *arg = argv[i];
        if (arg[0] != '-' || arg[1] == '\0') {
            continue;
        }
        if (arg[2] != '\0') {
            fprintf(stderr, "Invalid option -%c\n", arg[1]);
            print_help();
            return 1;
        }
        char opt = arg[1];
        const char *needs = "brDGcPplWTKI";
        char *val = NULL;
        if (strchr(needs, opt)) {
            if (i + 1 >= argc) return missing_arg();
            val = argv[++i];
        }
        switch (opt) {
            case 'V':
                fprintf(stderr, "Dropbear v2025.89\n");
                return 0;
            case 'h':
                print_help();
                return 0;
            case 'R':
                create_keys = true;
                break;
            case 'r':
                if (nkeys < 32) keyfiles[nkeys++] = val;
                break;
            case 'b': {
                FILE *f = fopen(val, "rb");
                if (!f) logmsg("Error opening banner file '%s'", val);
                else fclose(f);
                break;
            }
            case 'G':
                if (!getgrnam(val)) {
                    logmsg("Early exit: Cannot restrict logins to group '%s' as the group does not exist", val);
                    return 1;
                }
                break;
            case 'c':
                logmsg("Forced command set to '%s'", val);
                break;
            case 'K':
                if (!is_uint(val)) {
                    logmsg("Early exit: Bad keepalive '%s'", val);
                    return 1;
                }
                break;
            case 'I':
                if (!is_uint(val)) {
                    logmsg("Early exit: Bad idle_timeout '%s'", val);
                    return 1;
                }
                break;
            case 'T':
                if (!is_uint(val)) {
                    logmsg("Early exit: Bad maxauthtries '%s'", val);
                    return 1;
                }
                break;
            case 'W':
                if (!is_uint(val)) {
                    logmsg("Bad recv window '%s', using 24576", val);
                } else if (strtoull(val, NULL, 10) > 10485760ULL) {
                    logmsg("Bad recv window '%s', using 10485760", val);
                }
                break;
            case 'D':
            case 'P':
                pidfile = val;
                break;
            case 'p':
                if (nspecs < MAX_PORTS) parse_listen_spec(val, &specs[nspecs++]);
                break;
            case 'l':
            case 'F':
                foreground = true;
                break;
            case 'e':
            case 'm':
            case 'w':
            case 's':
            case 'g':
            case 'B':
            case 't':
            case 'j':
            case 'k':
            case 'a':
            case 'i':
            case 'z':
                break;
            default:
                fprintf(stderr, "Invalid option -%c\n", opt);
                print_help();
                return 1;
        }
    }

    if (!create_keys) {
        if (nkeys == 0) {
            logmsg("Failed loading /etc/dropbear/dropbear_rsa_host_key");
            logmsg("Failed loading /etc/dropbear/dropbear_ecdsa_host_key");
            logmsg("Failed loading /etc/dropbear/dropbear_ed25519_host_key");
        } else {
            for (int i = 0; i < nkeys; i++) logmsg("Failed loading %s", keyfiles[i]);
        }
        logmsg("Early exit: No hostkeys available. 'dropbear -R' may be useful or run dropbearkey.");
        return 1;
    }

    if (nspecs == 0) parse_listen_spec("22", &specs[nspecs++]);

    int fds[MAX_PORTS];
    int nfds = 0;
    for (int i = 0; i < nspecs; i++) {
        int fd = open_listener(&specs[i]);
        if (fd >= 0) fds[nfds++] = fd;
    }
    if (nfds == 0) {
        logmsg("Early exit: No listening ports available.");
        return 1;
    }

    if (!foreground) {
        pid_t child = fork();
        if (child < 0) {
            logmsg("Early exit: fork: %s", strerror(errno));
            return 1;
        }
        if (child > 0) {
            FILE *pf = fopen(pidfile, "w");
            if (pf) {
                fprintf(pf, "%ld\n", (long)child);
                fclose(pf);
            }
            logmsg("Running in background");
            return 0;
        }
    } else {
        logmsg("Not backgrounding");
    }

    if (foreground) {
        FILE *pf = fopen(pidfile, "w");
        if (pf) {
            fprintf(pf, "%ld\n", (long)getpid());
            fclose(pf);
        }
    }
    int rc = serve(fds, nfds);
    for (int i = 0; i < nfds; i++) close(fds[i]);
    return rc;
}
