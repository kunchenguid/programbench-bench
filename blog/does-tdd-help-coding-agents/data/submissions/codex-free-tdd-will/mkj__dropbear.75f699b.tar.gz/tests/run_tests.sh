#!/bin/bash
set -euo pipefail

ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"

fail() {
  echo "FAIL: $*" >&2
  exit 1
}

run_case() {
  local name="$1"
  shift
  set +e
  ./executable "$@" >tests/stdout.txt 2>tests/stderr.txt
  local rc=$?
  set -e
  echo "$rc" >tests/status.txt
  echo "$name"
}

assert_status() {
  local want="$1"
  local got
  got="$(cat tests/status.txt)"
  [[ "$got" == "$want" ]] || fail "expected exit $want, got $got"
}

assert_stdout_empty() {
  [[ ! -s tests/stdout.txt ]] || fail "expected empty stdout"
}

assert_stderr_exact() {
  local expected="$1"
  local got
  got="$(cat tests/stderr.txt)"
  [[ "$got" == "$expected" ]] || fail "stderr mismatch: <$got>"
}

normalized_stderr() {
  sed -E 's/^\[[0-9]+\] [A-Z][a-z][a-z] [ 0-9][0-9] [0-9:]{8} //' tests/stderr.txt
}

HELP_TEXT='Dropbear server v2025.89 https://matt.ucc.asn.au/dropbear/dropbear.html
Usage: ./executable [options]
-b bannerfile	Display the contents of bannerfile before user login
		(default: none)
-r keyfile      Specify hostkeys (repeatable)
		defaults: 
		- rsa /etc/dropbear/dropbear_rsa_host_key
		- ecdsa /etc/dropbear/dropbear_ecdsa_host_key
		- ed25519 /etc/dropbear/dropbear_ed25519_host_key
-D		Directory containing authorized_keys file
-R		Create hostkeys as required
-F		Don'\''t fork into background
-e		Pass on server process environment to child process
(Syslog support not compiled in, using stderr)
-m		Don'\''t display the motd on login
-w		Disallow root logins
-G		Restrict logins to members of specified group
-s		Disable password logins
-g		Disable password logins for root
-B		Allow blank password logins
-t		Enable two-factor authentication (both password and public key required)
-T		Maximum authentication tries (default 10)
-j		Disable local port forwarding
-k		Disable remote port forwarding
-a		Allow connections to forwarded ports from any host
-c command	Force executed command
-p [address:]port
		Listen on specified tcp port (and optionally address),
		up to 10 can be specified
		(default port is 22 if none specified)
-P PidFile	Create pid file PidFile
		(default /var/run/dropbear.pid)
-l <interface>
		interface to bind on
-i		Start for inetd
-W <receive_window_buffer> (default 24576, larger may be faster, max 10MB)
-K <keepalive>  (0 is never, default 0, in seconds)
-I <idle_timeout>  (0 is never, default 0, in seconds)
-z    disable QoS
-V    Version'

cc -std=c99 -Wall -Wextra -O2 -o executable src/main.c

run_case "version goes to stderr" -V
assert_status 0
assert_stdout_empty
assert_stderr_exact "Dropbear v2025.89"

run_case "short help goes to stderr" -h
assert_status 0
assert_stdout_empty
assert_stderr_exact "$HELP_TEXT"

run_case "long help is an invalid option" --help
assert_status 1
assert_stdout_empty
assert_stderr_exact "Invalid option --
$HELP_TEXT"

run_case "missing hostkeys prevent startup"
assert_status 1
assert_stdout_empty
[[ "$(normalized_stderr)" == "Failed loading /etc/dropbear/dropbear_rsa_host_key
Failed loading /etc/dropbear/dropbear_ecdsa_host_key
Failed loading /etc/dropbear/dropbear_ed25519_host_key
Early exit: No hostkeys available. 'dropbear -R' may be useful or run dropbearkey." ]] || fail "missing hostkey diagnostics mismatch"

run_case "missing option argument is reported" -p
assert_status 1
assert_stdout_empty
[[ "$(normalized_stderr)" == "Early exit: Missing argument" ]] || fail "missing argument diagnostic mismatch"

PORT=23222
rm -f tests/server.err tests/banner.txt
timeout 3 ./executable -R -F -p 127.0.0.1:$PORT >tests/server.out 2>tests/server.err &
server_pid=$!
for _ in $(seq 1 30); do
  if { exec 3<>/dev/tcp/127.0.0.1/$PORT; } 2>/dev/null; then
    IFS= read -r banner <&3
    printf '%s\n' "$banner" >tests/banner.txt
    exec 3<&-
    exec 3>&-
    break
  fi
  sleep 0.05
done
kill "$server_pid" 2>/dev/null || true
wait "$server_pid" 2>/dev/null || true
[[ "$(cat tests/banner.txt 2>/dev/null)" == $'SSH-2.0-dropbear_2025.89\r' ]] || fail "SSH banner mismatch"
