#!/usr/bin/env python3
import os
import struct
import sys
import time
from pathlib import Path


VERSION = "0.9.9"
ENVS = """Environment variables:
  _ZO_DATA_DIR          Path for zoxide data files
  _ZO_ECHO              Print the matched directory before navigating to it when set to 1
  _ZO_EXCLUDE_DIRS      List of directory globs to be excluded
  _ZO_FZF_OPTS          Custom flags to pass to fzf
  _ZO_MAXAGE            Maximum total age after which entries start getting deleted
  _ZO_RESOLVE_SYMLINKS  Resolve symlinks when storing paths"""


def data_file():
    root = os.environ.get("_ZO_DATA_DIR")
    if not root:
        home = os.environ.get("HOME", "")
        root = os.path.join(home, ".local", "share", "zoxide")
    return Path(root) / "db.zo"


def load_db():
    path = data_file()
    if not path.exists():
        return []
    raw = path.read_bytes()
    if not raw:
        return []
    try:
        off = 0
        version = struct.unpack_from("<I", raw, off)[0]
        off += 4
        if version != 3:
            return []
        count = struct.unpack_from("<Q", raw, off)[0]
        off += 8
        entries = []
        for _ in range(count):
            n = struct.unpack_from("<Q", raw, off)[0]
            off += 8
            p = raw[off : off + n].decode()
            off += n
            score = struct.unpack_from("<d", raw, off)[0]
            off += 8
            ts = struct.unpack_from("<q", raw, off)[0]
            off += 8
            entries.append({"path": p, "score": score, "time": ts})
        return entries
    except Exception:
        return []


def save_db(entries):
    path = data_file()
    path.parent.mkdir(parents=True, exist_ok=True)
    out = bytearray()
    out += struct.pack("<IQ", 3, len(entries))
    for e in entries:
        b = e["path"].encode()
        out += struct.pack("<Q", len(b))
        out += b
        out += struct.pack("<dq", float(e["score"]), int(e.get("time", 0)))
    path.write_bytes(out)


def canonical(path):
    p = Path(path).expanduser()
    if os.environ.get("_ZO_RESOLVE_SYMLINKS") == "1":
        return str(p.resolve())
    return str(p.absolute())


def is_excluded(path):
    import fnmatch

    patterns = os.environ.get("_ZO_EXCLUDE_DIRS")
    if patterns is None:
        patterns = os.environ.get("HOME", "")
    for pat in [p for p in patterns.split(":") if p]:
        cp = canonical(pat)
        if path == cp or fnmatch.fnmatch(path, cp):
            return True
    return False


def sub_help(name):
    helps = {
        "add": f"zoxide-add {VERSION}\n\nAdd a new directory or increment its rank\n\nUsage:\n  executable add [OPTIONS] <PATHS>...\n\nOptions:\n  -s, --score <SCORE>  The rank to increment the entry if it exists or initialize it with if it doesn't\n  -h, --help           Print help\n  -V, --version        Print version\n\n{ENVS}",
        "query": f"zoxide-query {VERSION}\n\nSearch for a directory in the database\n\nUsage:\n  executable query [OPTIONS] [KEYWORDS]...\n\nOptions:\n  -a, --all              Show unavailable directories\n  -i, --interactive      Use interactive selection\n  -l, --list             List all matching directories\n  -s, --score            Print score with results\n      --exclude <path>   Exclude the current directory\n      --base-dir <path>  Only search within this directory\n  -h, --help             Print help\n  -V, --version          Print version\n\n{ENVS}",
        "remove": f"zoxide-remove {VERSION}\n\nRemove a directory from the database\n\nUsage:\n  executable remove [PATHS]...\n\nOptions:\n  -h, --help     Print help\n  -V, --version  Print version\n\n{ENVS}",
        "import": f"zoxide-import {VERSION}\n\nImport entries from another application\n\nUsage:\n  executable import [OPTIONS] --from <FROM> <PATH>\n\nOptions:\n      --from <FROM>  Application to import from [possible values: autojump, z]\n      --merge        Merge into existing database\n  -h, --help         Print help\n  -V, --version      Print version\n\n{ENVS}",
        "init": f"zoxide-init {VERSION}\n\nGenerate shell configuration\n\nUsage:\n  executable init [OPTIONS] <SHELL>\n\nOptions:\n      --no-cmd       Prevents zoxide from defining the `z` and `zi` commands\n      --cmd <CMD>    Changes the prefix of the `z` and `zi` commands [default: z]\n      --hook <HOOK>  Changes how often zoxide increments a directory's score [default: pwd] [possible values: none, prompt, pwd]\n  -h, --help         Print help\n  -V, --version      Print version\n\n{ENVS}",
        "edit": f"zoxide-edit {VERSION}\n\nEdit the database\n\nUsage:\n  executable edit\n\nOptions:\n  -h, --help     Print help\n  -V, --version  Print version\n\n{ENVS}",
    }
    print(helps[name])


def cmd_add(argv):
    score = 1.0
    paths = []
    i = 0
    while i < len(argv):
        a = argv[i]
        if a == "--":
            paths += argv[i + 1 :]
            break
        if a in ("-s", "--score"):
            i += 1
            try:
                score = float(argv[i])
            except Exception:
                print(f"error: invalid value '{argv[i] if i < len(argv) else ''}' for '--score <SCORE>': invalid float literal", file=sys.stderr)
                return 2
        else:
            paths.append(a)
        i += 1
    if not paths:
        print("error: the following required arguments were not provided:\n  <PATHS>...", file=sys.stderr)
        return 2
    entries = load_db()
    now = int(time.time())
    by_path = {e["path"]: e for e in entries}
    for p in paths:
        cp = canonical(p)
        if not Path(cp).is_dir():
            print(f"zoxide: not a directory: {p}", file=sys.stderr)
            return 1
        if is_excluded(cp):
            continue
        if cp in by_path:
            by_path[cp]["score"] += score
            by_path[cp]["time"] = now
        else:
            e = {"path": cp, "score": score, "time": now}
            entries.append(e)
            by_path[cp] = e
    save_db(entries)
    return 0


def matches(path, keywords):
    low = path.lower()
    pos = 0
    for kw in keywords:
        kw = kw.lower()
        if kw == "":
            continue
        idx = low.find(kw, pos)
        if idx < 0:
            return False
        pos = idx + len(kw)
    return True


def frecency(e):
    return float(e["score"]) * 4.0


def match_quality(path, keywords):
    if not keywords:
        return 0
    parts = [p.lower() for p in Path(path).parts]
    quality = 0
    for kw in keywords:
        k = kw.lower().strip("/")
        if not k:
            continue
        if parts and parts[-1] == k:
            quality += 1000
        elif k in parts:
            quality += 300
        elif Path(path).name.lower().startswith(k):
            quality += 100
    return quality


def cmd_query(argv):
    show_all = False
    list_mode = False
    show_score = False
    exclude = None
    base_dir = None
    keywords = []
    i = 0
    while i < len(argv):
        a = argv[i]
        if a == "--":
            keywords += argv[i + 1 :]
            break
        if a in ("-a", "--all"):
            show_all = True
        elif a in ("-l", "--list"):
            list_mode = True
        elif a in ("-s", "--score"):
            show_score = True
        elif a.startswith("-") and len(a) > 2 and all(c in "ails" for c in a[1:]):
            show_all = show_all or "a" in a
            list_mode = list_mode or "l" in a or "i" in a
            show_score = show_score or "s" in a
        elif a in ("-i", "--interactive"):
            list_mode = True
        elif a == "--exclude":
            i += 1
            exclude = canonical(argv[i])
        elif a == "--base-dir":
            i += 1
            base_dir = canonical(argv[i])
        elif a.startswith("-"):
            print(f"error: unexpected argument '{a}' found", file=sys.stderr)
            return 2
        else:
            keywords.append(a)
        i += 1
    entries = []
    for e in load_db():
        p = e["path"]
        if exclude and p == exclude:
            continue
        if base_dir and not (p == base_dir or p.startswith(base_dir.rstrip("/") + "/")):
            continue
        if not show_all and not Path(p).is_dir():
            continue
        if matches(p, keywords):
            entries.append(e)
    if list_mode:
        entries.sort(key=lambda e: (frecency(e), len(e["path"])), reverse=True)
    else:
        entries.sort(key=lambda e: (match_quality(e["path"], keywords), frecency(e), -len(e["path"])), reverse=True)
    if not entries:
        print("zoxide: no match found", file=sys.stderr)
        return 1
    if not list_mode:
        entries = [entries[0]]
    for e in entries:
        if show_score:
            print(f"{frecency(e):6.1f} {e['path']}")
        else:
            print(e["path"])
    return 0


def cmd_remove(argv):
    paths = [a for a in argv if a != "--"]
    entries = load_db()
    if not paths:
        save_db([])
        return 0
    wanted = {canonical(p) for p in paths}
    existing = {e["path"] for e in entries}
    missing = [p for p in wanted if p not in existing]
    if missing:
        print(f"zoxide: path not found in database: {missing[0]}", file=sys.stderr)
        return 1
    save_db([e for e in entries if e["path"] not in wanted])
    return 0


def cmd_import(argv):
    source = None
    merge = False
    path = None
    i = 0
    while i < len(argv):
        a = argv[i]
        if a == "--from":
            i += 1
            source = argv[i]
        elif a.startswith("--from="):
            source = a.split("=", 1)[1]
        elif a == "--merge":
            merge = True
        else:
            path = a
        i += 1
    if source not in ("z", "autojump") or not path:
        print("error: the following required arguments were not provided:\n  --from <FROM> <PATH>", file=sys.stderr)
        return 2
    entries = load_db() if merge else []
    by_path = {e["path"]: e for e in entries}
    now = int(time.time())
    try:
        lines = Path(path).read_text(encoding="utf-8").splitlines()
    except OSError as exc:
        print(f"zoxide: {exc}", file=sys.stderr)
        return 1
    for line in lines:
        if not line.strip():
            continue
        if source == "z":
            parts = line.rsplit("|", 2)
        else:
            parts = line.rsplit("\t", 2)
            if len(parts) < 2:
                parts = line.rsplit("|", 2)
        if len(parts) < 2:
            continue
        p = canonical(parts[0])
        try:
            score = float(parts[1])
        except ValueError:
            continue
        if p in by_path:
            by_path[p]["score"] += score
            by_path[p]["time"] = now
        else:
            e = {"path": p, "score": score, "time": now}
            entries.append(e)
            by_path[p] = e
    save_db(entries)
    return 0


def cmd_init(argv):
    cmd = "z"
    hook = "pwd"
    no_cmd = False
    shell = None
    i = 0
    while i < len(argv):
        a = argv[i]
        if a == "--cmd":
            i += 1
            cmd = argv[i]
        elif a.startswith("--cmd="):
            cmd = a.split("=", 1)[1]
        elif a == "--hook":
            i += 1
            hook = argv[i]
        elif a.startswith("--hook="):
            hook = a.split("=", 1)[1]
        elif a == "--no-cmd":
            no_cmd = True
        elif a in ("-h", "--help"):
            print("Usage:\n  executable init [OPTIONS] <SHELL>")
            return 0
        else:
            shell = a
        i += 1
    if shell not in ("bash", "zsh", "fish", "posix", "powershell", "nushell", "elvish", "tcsh", "xonsh"):
        print("error: invalid value for '<SHELL>'", file=sys.stderr)
        return 2
    zi = f"{cmd}i"
    if shell in ("bash", "zsh", "posix"):
        func = "function " if shell != "posix" else ""
        out = [
            "# shellcheck shell=bash" if shell != "posix" else "# shellcheck shell=sh",
            "",
            "__zoxide_pwd() {",
            "    \\builtin pwd -L 2>/dev/null || \\command pwd -L",
            "}",
            "",
            "__zoxide_cd() {",
            "    \\builtin cd -- \"$@\" 2>/dev/null || \\command cd \"$@\"",
            "}",
            "",
        ]
        if hook != "none":
            out += [
                "__zoxide_hook() {",
                "    \\command zoxide add -- \"$(__zoxide_pwd)\"",
                "}",
                "",
                "PROMPT_COMMAND=\"${PROMPT_COMMAND:+${PROMPT_COMMAND};}__zoxide_hook\"",
                "",
            ]
        out += [
            (f"{func}__zoxide_z() {{" if shell != "posix" else "__zoxide_z() {"),
            "    if [ \"$#\" -eq 0 ]; then",
            "        __zoxide_cd ~",
            "    elif [ \"$#\" -eq 1 ] && { [ -d \"$1\" ] || [ \"$1\" = '-' ]; }; then",
            "        __zoxide_cd \"$1\"",
            "    else",
            "        __zoxide_result=\"$(\\command zoxide query --exclude \"$(__zoxide_pwd)\" -- \"$@\")\" && __zoxide_cd \"$__zoxide_result\"",
            "    fi",
            "}",
            "",
            (f"{func}__zoxide_zi() {{" if shell != "posix" else "__zoxide_zi() {"),
            "    __zoxide_result=\"$(\\command zoxide query --interactive -- \"$@\")\" && __zoxide_cd \"$__zoxide_result\"",
            "}",
        ]
        if not no_cmd:
            out += ["", f"{cmd}() {{", "    __zoxide_z \"$@\"", "}", "", f"{zi}() {{", "    __zoxide_zi \"$@\"", "}"]
        print("\n".join(out))
        return 0
    if shell == "fish":
        out = [
            "function __zoxide_pwd",
            "    builtin pwd -L",
            "end",
            "function __zoxide_z",
            "    set -l result (command zoxide query --exclude (__zoxide_pwd) -- $argv)",
            "    and cd $result",
            "end",
            "function __zoxide_zi",
            "    set -l result (command zoxide query --interactive -- $argv)",
            "    and cd $result",
            "end",
        ]
        if hook != "none":
            out += ["function __zoxide_hook --on-variable PWD", "    command zoxide add -- (__zoxide_pwd)", "end"]
        if not no_cmd:
            out += [f"alias {cmd}=__zoxide_z", f"alias {zi}=__zoxide_zi"]
        print("\n".join(out))
        return 0
    if shell == "powershell":
        print(f"function global:__zoxide_z {{ zoxide query @args | Set-Location }}\nSet-Alias {cmd} __zoxide_z\nSet-Alias {zi} __zoxide_z")
        return 0
    if shell == "nushell":
        print(f"def --env --wrapped __zoxide_z [...rest: string] {{ cd (^zoxide query -- ...$rest | str trim) }}\nalias {cmd} = __zoxide_z\nalias {zi} = __zoxide_z")
        return 0
    print(f"alias {cmd} '__zoxide_z'\nalias {zi} '__zoxide_zi'")
    return 0


def main(argv):
    if not argv or argv[0] in ("-h", "--help"):
        print(f"zoxide {VERSION}\nAjeet D'Souza <98ajeet@gmail.com>\nhttps://github.com/ajeetdsouza/zoxide\n\nA smarter cd command for your terminal\n\nUsage:\n  executable <COMMAND>\n\nCommands:\n  add     Add a new directory or increment its rank\n  edit    Edit the database\n  import  Import entries from another application\n  init    Generate shell configuration\n  query   Search for a directory in the database\n  remove  Remove a directory from the database")
        return 0 if argv else 2
    if argv[0] in ("-V", "--version"):
        print(f"zoxide {VERSION}")
        return 0
    cmd = argv[0]
    rest = argv[1:]
    if cmd in ("add", "query", "remove", "import", "init", "edit"):
        if rest and rest[0] in ("-V", "--version"):
            print(f"zoxide-{cmd} {VERSION}")
            return 0
        if rest and rest[0] in ("-h", "--help"):
            sub_help(cmd)
            return 0
    if cmd == "add":
        return cmd_add(rest)
    if cmd == "query":
        return cmd_query(rest)
    if cmd == "remove":
        return cmd_remove(rest)
    if cmd == "import":
        return cmd_import(rest)
    if cmd == "init":
        return cmd_init(rest)
    if cmd == "edit":
        return 0
    print(f"error: unrecognized subcommand '{cmd}'", file=sys.stderr)
    return 2


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
