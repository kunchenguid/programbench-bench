#!/usr/bin/env python3
import argparse
import html
import json
import os
import re
import shutil
import sys
import time
from dataclasses import dataclass, field
from datetime import datetime, timezone
from email.utils import format_datetime
from pathlib import Path


HELP = """Marmite is the easiest static site generator.

Usage: executable [OPTIONS] <INPUT_FOLDER> [OUTPUT_FOLDER]

Arguments:
  <INPUT_FOLDER>   Input folder containing markdown files
  [OUTPUT_FOLDER]  Output folder to generate the site [default: `input_folder/site`]

Options:
  -v, --verbose...
          Verbosity level (0-4) [default: 0 warn] options: -v: info,-vv: debug,-vvv: trace,-vvvv: trace all
  -w, --watch
          Detect changes and rebuild the site automatically
      --serve
          Serve the site with a built-in HTTP server
      --bind <BIND>
          Address to bind the server [default: 0.0.0.0:8000]
  -c, --config <CONFIG>
          Path to custom configuration file [default: marmite.yaml]
      --init-templates
          Initialize templates in the project
      --start-theme <START_THEME>
          Initialize a theme with templates and static assets
      --set-theme <SET_THEME>
          Download and set a theme from a remote URL or local folder
      --generate-config
          Generate the configuration file
      --init-site
          Init a new site with sample content and default configuration this will overwrite existing files usually you don't need to run this because Marmite can generate a site from any folder with markdown files
      --force
          Force the rebuild of the site even if no changes detected
      --shortcodes
          List all available shortcodes
      --show-urls
          Show all site URLs organized by content type
      --new <NEW>
          Create a new post with the given title and open in the default editor
  -e
          Edit the file in the default editor
  -p
          Set the new content as a page
  -t <TAGS>
          Set the tags for the new content tags are comma separated
      --name <NAME>
          Site name [default: "Home" or value from config file]
      --tagline <TAGLINE>
          Site tagline [default: empty or value from config file]
      --url <URL>
          Site url [default: empty or value from config file]
      --https <HTTPS>
          If protocol is missing in the URL setting, whether to use HTTPS or not [default: false] [possible values: true, false]
      --footer <FOOTER>
          Site footer [default: from '_footer.md' or config file]
      --language <LANGUAGE>
          Site main language 2 letter code [default: "en" or value from config file]
      --pagination <PAGINATION>
          Number of posts per page [default: 10 or value from config file]
      --enable-search <ENABLE_SEARCH>
          Enable search [default: false or from config file] [possible values: true, false]
      --enable-related-content <ENABLE_RELATED_CONTENT>
          Enable backlinks and related content for posts [default: true or from config file] [possible values: true, false]
      --content-path <CONTENT_PATH>
          Path for content subfolder [default: "content" or value from config file] this is the folder where markdown files are stored inside `input_folder` no need to change this if your markdown files are in `input_folder` directly
      --templates-path <TEMPLATES_PATH>
          Path for templates subfolder [default: "templates" or value from config file]
      --static-path <STATIC_PATH>
          Path for static subfolder [default: "static" or value from config file]
      --media-path <MEDIA_PATH>
          Path for media subfolder [default: "media" or value from config file] this path is relative to the folder where your content files are
      --default-date-format <DEFAULT_DATE_FORMAT>
          Default date format [default: "%b %e, %Y" or from config file] see <https://docs.rs/chrono/0.4.19/chrono/format/strftime/index.html>
      --colorscheme <COLORSCHEME>
          Name of the colorscheme to use [default: "default" or from config file] see <https://marmite.blog/getting-started.html#colorschemes>
      --toc <TOC>
          Show Table of Contents in posts [default: false or from config file] this will generate a table of contents for each post [possible values: true, false]
      --json-feed <JSON_FEED>
          Generate JSON Feed [default: false or from config file] [possible values: true, false]
      --show-next-prev-links <SHOW_NEXT_PREV_LINKS>
          Show next and previous links in posts [default: true or from config file] [possible values: true, false]
      --publish-md <PUBLISH_MD>
          Publish markdown source files alongside HTML [default: false or from config file] [possible values: true, false]
      --source-repository <SOURCE_REPOSITORY>
          Source repository URL to link to markdown files [default: None or from config file]
      --image-provider <IMAGE_PROVIDER>
          Image provider for automatic banner image download [default: None or from config file] Available providers: picsum
      --theme <THEME>
          Theme to use for the site [default: from config file or embedded templates]
      --build-sitemap <BUILD_SITEMAP>
          Generate sitemap.xml file [default: true or from config file] [possible values: true, false]
      --publish-urls-json <PUBLISH_URLS_JSON>
          Generate urls.json file [default: true or from config file] [possible values: true, false]
      --enable-shortcodes <ENABLE_SHORTCODES>
          Enable shortcodes processing [default: true or from config file] [possible values: true, false]
      --shortcode-pattern <SHORTCODE_PATTERN>
          Custom shortcode pattern (regex) [default: <!-- \\.(\\w+)(?:\\s+([^-][\\s\\S]*?))?\\s*--> or from config file]
      --skip-image-resize <SKIP_IMAGE_RESIZE>
          Skip image resizing during build [default: false or from config file] Use this for faster development builds when image optimization is not needed [possible values: true, false]
  -h, --help
          Print help
  -V, --version
          Print version
"""


FOOTER = '<div>Powered by <a href="https://github.com/rochacbruno/marmite">Marmite</a> | <small><a href="https://creativecommons.org/licenses/by-nc-sa/4.0/">CC-BY_NC-SA</a></small></div>'


@dataclass
class Config:
    name: str = "Home"
    tagline: str = ""
    url: str = ""
    language: str = "en"
    pagination: int = 10
    content_path: str = "content"
    static_path: str = "static"
    media_path: str = "media"
    footer: str = FOOTER
    enable_search: bool = False
    enable_related_content: bool = True
    toc: bool = False
    json_feed: bool = False
    show_next_prev_links: bool = True
    publish_md: bool = False
    build_sitemap: bool = True
    publish_urls_json: bool = True
    enable_shortcodes: bool = True
    default_date_format: str = "%b %e, %Y"
    menu: list = field(default_factory=lambda: [["Tags", "tags.html"], ["Archive", "archive.html"], ["Authors", "authors.html"]])


@dataclass
class Content:
    source: Path
    rel: str
    title: str
    slug: str
    date: str = ""
    tags: list = field(default_factory=list)
    authors: list = field(default_factory=list)
    stream: str = ""
    series: str = ""
    is_page: bool = False
    html: str = ""
    text: str = ""
    body_md: str = ""

    @property
    def url(self):
        return f"/{self.slug}.html"

    @property
    def year(self):
        return self.date[:4] if self.date else ""


def slugify(value):
    value = value.strip().lower()
    value = re.sub(r"['\"]", "", value)
    value = re.sub(r"[^a-z0-9]+", "-", value)
    return value.strip("-") or "untitled"


def parse_bool(value):
    if isinstance(value, bool):
        return value
    return str(value).strip().lower() in {"true", "yes", "1", "on"}


def parse_scalar(value):
    value = value.strip()
    if value in {"null", "None", "~"}:
        return None
    if value.lower() in {"true", "false"}:
        return parse_bool(value)
    if (value.startswith("'") and value.endswith("'")) or (value.startswith('"') and value.endswith('"')):
        return value[1:-1]
    try:
        return int(value)
    except ValueError:
        return value


def parse_simple_yaml(text):
    data = {}
    lines = text.splitlines()
    i = 0
    while i < len(lines):
        line = lines[i]
        if not line.strip() or line.lstrip().startswith("#") or ":" not in line:
            i += 1
            continue
        key, val = line.split(":", 1)
        key = key.strip().replace("-", "_")
        val = val.strip()
        if val == "":
            arr = []
            obj = {}
            i += 1
            while i < len(lines) and (lines[i].startswith(" ") or lines[i].startswith("-")):
                item = lines[i].strip()
                if item.startswith("- "):
                    item = item[2:].strip()
                    if item.startswith("- "):
                        item = item[2:].strip()
                    arr.append(parse_scalar(item))
                elif ":" in item:
                    k, v = item.split(":", 1)
                    obj[k.strip()] = parse_scalar(v)
                i += 1
            data[key] = arr if arr else obj
            continue
        data[key] = parse_scalar(val)
        i += 1
    return data


def load_config(input_dir, config_path, overrides):
    cfg = Config()
    path = Path(config_path) if config_path else input_dir / "marmite.yaml"
    if path.exists():
        data = parse_simple_yaml(path.read_text(encoding="utf-8"))
        for key, val in data.items():
            if hasattr(cfg, key) and val is not None:
                setattr(cfg, key, val)
    for key, val in overrides.items():
        if val is not None and hasattr(cfg, key):
            setattr(cfg, key, val)
    if not cfg.language:
        cfg.language = "en"
    return cfg


def split_front_matter(text):
    if text.startswith("---\n"):
        end = text.find("\n---", 4)
        if end != -1:
            return parse_simple_yaml(text[4:end]), text[text.find("\n", end + 4) + 1 :]
    return {}, text


def inline_md(text):
    text = html.escape(text)
    text = re.sub(r"`([^`]+)`", r"<code>\1</code>", text)
    text = re.sub(r"\*\*([^*]+)\*\*", r"<strong>\1</strong>", text)
    text = re.sub(r"\*([^*]+)\*", r"<em>\1</em>", text)
    text = re.sub(r"!\[([^\]]*)\]\(([^)]+)\)", r'<img src="\2" alt="\1">', text)
    text = re.sub(r"\[([^\]]+)\]\(([^)]+)\)", r'<a href="\2">\1</a>', text)
    return text


def md_to_html(markdown):
    blocks = []
    lines = markdown.splitlines()
    i = 0
    while i < len(lines):
        line = lines[i]
        if not line.strip():
            i += 1
            continue
        if line.startswith("```"):
            lang = line[3:].strip()
            code = []
            i += 1
            while i < len(lines) and not lines[i].startswith("```"):
                code.append(lines[i])
                i += 1
            i += 1
            cls = f' class="language-{html.escape(lang)}"' if lang else ""
            blocks.append(f"<pre><code{cls}>{html.escape(chr(10).join(code))}</code></pre>")
            continue
        m = re.match(r"^(#{1,6})\s+(.*)$", line)
        if m:
            level = len(m.group(1))
            title = inline_md(m.group(2).strip())
            anchor = slugify(re.sub("<[^>]+>", "", title))
            if level > 1:
                blocks.append(f'<h{level}><a href="#{anchor}" aria-hidden="true" class="anchor" id="{anchor}"></a>{title}</h{level}>')
            else:
                blocks.append(f"<h1>{title}</h1>")
            i += 1
            continue
        if re.match(r"^\s*[-*]\s+", line):
            items = []
            while i < len(lines) and re.match(r"^\s*[-*]\s+", lines[i]):
                item_text = re.sub(r"^\s*[-*]\s+", "", lines[i]).strip()
                items.append(f"<li>{inline_md(item_text)}</li>")
                i += 1
            blocks.append("<ul>\n" + "\n".join(items) + "\n</ul>")
            continue
        if re.match(r"^\s*\d+\.\s+", line):
            items = []
            while i < len(lines) and re.match(r"^\s*\d+\.\s+", lines[i]):
                item_text = re.sub(r"^\s*\d+\.\s+", "", lines[i]).strip()
                items.append(f"<li>{inline_md(item_text)}</li>")
                i += 1
            blocks.append("<ol>\n" + "\n".join(items) + "\n</ol>")
            continue
        para = [line.strip()]
        i += 1
        while i < len(lines) and lines[i].strip() and not re.match(r"^(#{1,6})\s+|^\s*[-*]\s+|^\s*\d+\.\s+|^```", lines[i]):
            para.append(lines[i].strip())
            i += 1
        blocks.append(f"<p>{inline_md(' '.join(para))}</p>")
    return "\n".join(blocks) + ("\n" if blocks else "")


def strip_md(markdown):
    text = re.sub(r"```[\s\S]*?```", "", markdown)
    text = re.sub(r"!\[([^\]]*)\]\([^)]+\)", r"\1", text)
    text = re.sub(r"\[([^\]]+)\]\([^)]+\)", r"\1", text)
    text = re.sub(r"[#>*_`-]", "", text)
    return re.sub(r"\n{3,}", "\n\n", text).strip()


def parse_list(value):
    if not value:
        return []
    if isinstance(value, list):
        return [str(v).strip() for v in value if str(v).strip()]
    return [v.strip() for v in str(value).split(",") if v.strip()]


def discover_content(input_dir, cfg):
    content_dir = input_dir / cfg.content_path
    if not content_dir.exists():
        content_dir = input_dir
    items = []
    for path in sorted(content_dir.rglob("*.md")):
        if path.name.startswith("_"):
            continue
        raw = path.read_text(encoding="utf-8")
        meta, body = split_front_matter(raw)
        title = str(meta.get("title") or "")
        first_heading = re.search(r"^#\s+(.+)$", body, flags=re.M)
        if not title and first_heading:
            title = first_heading.group(1).strip()
            body_for_html = re.sub(r"^#\s+.+\n?", "", body, count=1, flags=re.M)
        else:
            body_for_html = body
        if not title:
            title = path.stem
        fallback_slug = re.sub(r"^\d{4}-\d{2}-\d{2}(?:-\d{2}-\d{2}-\d{2})?-", "", path.stem)
        slug = slugify(str(meta.get("slug") or title or fallback_slug))
        date = str(meta.get("date") or "")
        if not date:
            m = re.match(r"(\d{4}-\d{2}-\d{2})", path.stem)
            date = m.group(1) if m else ""
        item = Content(
            source=path,
            rel=str(path.relative_to(content_dir)),
            title=title,
            slug=slug,
            date=date,
            tags=parse_list(meta.get("tags") or meta.get("tag")),
            authors=parse_list(meta.get("authors") or meta.get("author")),
            stream=str(meta.get("stream") or ""),
            series=str(meta.get("series") or ""),
            is_page=parse_bool(meta.get("page")) or not date,
            html=md_to_html(body_for_html),
            text=strip_md(body_for_html),
            body_md=body,
        )
        items.append(item)
    items.sort(key=lambda c: (c.date, c.title), reverse=True)
    return items


def date_display(date):
    if not date:
        return ""
    try:
        dt = datetime.fromisoformat(date[:10])
        return dt.strftime("%b %e, %Y")
    except ValueError:
        return date


def iso_date(date):
    if not date:
        return ""
    return f"{date[:10]}T00:00:00+00:00"


def page_shell(title, cfg, body, description="", article=False):
    nav = "\n".join(f'<li><a class="menu-item secondary" href="/{href}">{html.escape(label)}</a></li>' for label, href in cfg.menu)
    ogtype = "article" if article else "website"
    return f"""<!DOCTYPE html>
<html lang="{html.escape(cfg.language)}">
<head>
    <meta charset="UTF-8">
    <link rel="icon" type="image/x-icon" href="/static/favicon.ico">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="color-scheme" content="light dark" />
    <meta name="generator" content="Marmite" />
    <meta property="og:title" content="{html.escape(title)}">
    <meta property="og:description" content="{html.escape(description)}">
    <meta property="og:type" content="{ogtype}">
    <meta property="og:site_name" content="{html.escape(cfg.name)}">
    <title>{html.escape(title)} | {html.escape(cfg.name)}</title>
    <link rel="stylesheet" type="text/css" href="/static/pico.min.css">
    <link rel="stylesheet" type="text/css" href="/static/marmite.css">
    <link rel="stylesheet" type="text/css" href="/static/custom.css">
</head>
<body>
<main class="container">
<header class="header-content"><nav class="header-nav"><ul class="header-name"><li><hgroup class="h-card"><h2><a href="/" class="contrast p-name u-url">{html.escape(cfg.name)}</a></h2><p>{html.escape(cfg.tagline)}</p></hgroup></li></ul><ul class="header-menu" id="header-menu">{nav}</ul></nav></header>
<section class="main-content">
{body}
</section>
<footer class="footer-content grid">{cfg.footer}</footer>
</main>
<script src="/static/marmite.js"></script>
</body>
</html>
"""


def render_content(item, cfg):
    tags = "\n".join(f'<li><a href="/tag-{slugify(t)}.html" class="p-category">{html.escape(t)}</a></li>' for t in item.tags)
    date = date_display(item.date)
    body = f"""<article class="h-entry">
  <data class="p-name" value="{html.escape(item.title)}"></data>
  <time class="dt-published" datetime="{iso_date(item.date)}" style="display: none;">{html.escape(date)}</time>
  <div class="content-title" id="title">
    <h1>{html.escape(item.title)}</h1>
  </div>
  <div class="content-date"><span class="content-date">{html.escape(date)}</span></div>
  <div class="content-html e-content">{item.html}</div>
  <footer class="data-tags-footer"><ul class="content-tags">{tags}</ul></footer>
</article>"""
    return page_shell(item.title, cfg, body, item.text, True)


def render_list(title, cfg, items):
    entries = []
    for item in items:
        tags = "".join(f'<li><a href="/tag-{slugify(t)}.html" class="p-category">{html.escape(t)}</a></li>' for t in item.tags)
        excerpt = html.escape(item.text[:300])
        entries.append(f"""<article class="content-list-item h-entry">
<h2 class="p-name" style="display: none;">{html.escape(item.title)}</h2>
<time class="dt-published" datetime="{iso_date(item.date)}" style="display: none;">{html.escape(date_display(item.date))}</time>
<div class="content-title-wrapper"><h2 class="content-title"><a href="{item.url}">{html.escape(item.title)}</a></h2></div>
<p class="content-excerpt p-summary">{excerpt}</p>
<footer class="data-tags-footer"><span class="content-date"><a class="secondary" href="{item.url}">{html.escape(date_display(item.date))}</a></span><ul class="content-tags overflow-auto">{tags}</ul></footer>
</article>""")
    body = f'<div class="content-list h-feed">\n{"".join(entries)}\n</div>'
    return page_shell(title, cfg, body)


def render_group(title, cfg, groups, prefix):
    details = []
    for name, items in groups:
        lis = "".join(f'<li class="h-entry"><a href="{i.url}" class="u-url p-name">{html.escape(i.title)}</a> <small><time class="dt-published" datetime="{iso_date(i.date)}">{html.escape(i.date[:10])}</time></small></li>' for i in items)
        details.append(f'<details open><summary role="button" class="outline contrast {prefix}-group-title">{html.escape(name)} <sup>{len(items)}</sup></summary><ul>{lis}<li><a href="/{prefix}-{slugify(name)}.html">more &rarr;</a></li></ul></details>')
    body = f'<div class="list-title"><article><strong> {html.escape(title)} </strong></article></div><article class="group-details h-feed"><h1 class="p-name" style="display: none;">{html.escape(title)}</h1>{"".join(details)}</article>'
    return page_shell(title, cfg, body)


def write_static(out):
    static = out / "static"
    static.mkdir(parents=True, exist_ok=True)
    files = {
        "marmite.css": "body{font-family:system-ui,sans-serif}.container{max-width:960px;margin:auto}.content-tags{display:flex;gap:.5rem;list-style:none;padding:0}",
        "pico.min.css": "",
        "custom.css": "",
        "marmite.js": "",
        "custom.js": "",
        "search.js": "",
        "robots.txt": "User-agent: *\nAllow: /\n",
        "favicon.ico": "",
        "logo.png": "",
        "avatar-placeholder.png": "",
        "Atkinson-Hyperlegible-Regular-102.woff": "",
    }
    for name, content in files.items():
        path = static / name
        if not path.exists():
            path.write_text(content, encoding="utf-8")


def copy_tree_if_exists(src, dst):
    if not src.exists():
        return
    for path in src.rglob("*"):
        rel = path.relative_to(src)
        target = dst / rel
        if path.is_dir():
            target.mkdir(parents=True, exist_ok=True)
        else:
            target.parent.mkdir(parents=True, exist_ok=True)
            shutil.copyfile(path, target)


def rss_feed(title, cfg, items, source="index"):
    latest = items[0].date if items else datetime.now(timezone.utc).date().isoformat()
    try:
        pub = format_datetime(datetime.fromisoformat(latest[:10]).replace(tzinfo=timezone.utc), usegmt=True)
    except ValueError:
        pub = format_datetime(datetime.now(timezone.utc), usegmt=True)
    now = format_datetime(datetime.now(timezone.utc), usegmt=True)
    root = absolute_root(cfg)
    body = [f'<?xml version="1.0" encoding="utf-8"?><rss version="2.0" xmlns:content="http://purl.org/rss/1.0/modules/content/"><channel><title>{html.escape(cfg.name)}</title><link>{html.escape(root)}</link><description>{html.escape(cfg.tagline)}</description><pubDate>{pub}</pubDate><lastBuildDate>{now}</lastBuildDate><generator>marmite</generator>']
    for item in items:
        cats = "".join(f"<category>{html.escape(t)}</category>" for t in item.tags)
        link = root.rstrip("/") + item.url
        body.append(f"<item><title>{html.escape(item.title)}</title><link>{html.escape(link)}</link>{cats}<guid>{html.escape(link)}</guid><pubDate>{pub}</pubDate><source url=\"{html.escape(root)}\">{html.escape(source)}</source><content:encoded><![CDATA[{item.html}]]></content:encoded></item>")
    body.append("</channel></rss>")
    return "".join(body)


def absolute_root(cfg):
    if cfg.url:
        if cfg.url.startswith("http://") or cfg.url.startswith("https://"):
            return cfg.url.rstrip("/")
        return ("https://" if False else "http://") + cfg.url.rstrip("/")
    return "http://"


def build_site(input_dir, out_dir, cfg, show_urls=False):
    out_dir.mkdir(parents=True, exist_ok=True)
    items = discover_content(input_dir, cfg)
    posts = [i for i in items if not i.is_page]
    pages = [i for i in items if i.is_page]
    for item in items:
        (out_dir / f"{item.slug}.html").write_text(render_content(item, cfg), encoding="utf-8")
        if cfg.publish_md:
            shutil.copyfile(item.source, out_dir / f"{item.slug}.md")
    (out_dir / "index.html").write_text(render_list("Page", cfg, posts or items), encoding="utf-8")
    (out_dir / "index-1.html").write_text(render_list("Page - 1", cfg, posts or items), encoding="utf-8")
    (out_dir / "pages.html").write_text(render_list("Pages", cfg, pages), encoding="utf-8")
    (out_dir / "pages-1.html").write_text(render_list("Pages - 1", cfg, pages), encoding="utf-8")
    tag_groups = []
    for tag in sorted({t for p in posts for t in p.tags}, reverse=True):
        group_items = [p for p in posts if tag in p.tags]
        tag_groups.append((tag, group_items))
        (out_dir / f"tag-{slugify(tag)}.html").write_text(render_list(f"Posts tagged with '{tag}'", cfg, group_items), encoding="utf-8")
        (out_dir / f"tag-{slugify(tag)}-1.html").write_text(render_list(f"Posts tagged with '{tag}' - 1", cfg, group_items), encoding="utf-8")
        (out_dir / f"tag-{slugify(tag)}.rss").write_text(rss_feed(tag, cfg, group_items, f"tag-{slugify(tag)}"), encoding="utf-8")
    (out_dir / "tags.html").write_text(render_group("Tags", cfg, tag_groups, "tag"), encoding="utf-8")
    years = sorted({p.year for p in posts if p.year}, reverse=True)
    archive_groups = []
    for year in years:
        group_items = [p for p in posts if p.year == year]
        archive_groups.append((year, group_items))
        (out_dir / f"archive-{year}.html").write_text(render_list(f"Posts from '{year}'", cfg, group_items), encoding="utf-8")
        (out_dir / f"archive-{year}-1.html").write_text(render_list(f"Posts from '{year}' - 1", cfg, group_items), encoding="utf-8")
        (out_dir / f"archive-{year}.rss").write_text(rss_feed(year, cfg, group_items, f"archive-{year}"), encoding="utf-8")
    (out_dir / "archive.html").write_text(render_group("Archive", cfg, archive_groups, "archive"), encoding="utf-8")
    (out_dir / "authors.html").write_text(render_group("Authors", cfg, [], "author"), encoding="utf-8")
    (out_dir / "series.html").write_text(render_group("Series", cfg, [], "series"), encoding="utf-8")
    (out_dir / "streams.html").write_text(render_group("Streams", cfg, [], "stream"), encoding="utf-8")
    (out_dir / "404.html").write_text(page_shell("Page not found", cfg, "<h1>Page not found</h1><p> :/</p>", " :/", True), encoding="utf-8")
    (out_dir / "index.rss").write_text(rss_feed("index", cfg, posts), encoding="utf-8")
    (out_dir / "robots.txt").write_text("User-agent: *\nAllow: /\n", encoding="utf-8")
    write_static(out_dir)
    copy_tree_if_exists(input_dir / cfg.static_path, out_dir / "static")
    copy_tree_if_exists(input_dir / cfg.media_path, out_dir / cfg.media_path)
    urls = collect_urls(posts, pages, tag_groups, years)
    if cfg.build_sitemap:
        locs = "\n".join(f"  <url>\n    <loc>{u}</loc>\n  </url>" for u in urls["all"])
        (out_dir / "sitemap.xml").write_text(f'<?xml version="1.0" encoding="UTF-8"?>\n<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">\n{locs}\n</urlset>', encoding="utf-8")
    if cfg.publish_urls_json:
        (out_dir / "urls.json").write_text(json.dumps(urls["json"], indent=2), encoding="utf-8")
    (out_dir / "marmite.json").write_text(json.dumps({"marmite_version": "0.2.7", "timestamp": int(time.time()), "config": cfg.__dict__}, indent=2, default=str), encoding="utf-8")
    if show_urls:
        print(json.dumps(urls["json"], indent=2))


def collect_urls(posts, pages, tag_groups, years):
    post_urls = [p.url for p in posts]
    page_urls = [p.url for p in pages]
    tags = [f"/tag-{slugify(t)}.html" for t, _ in tag_groups] + (["/tags.html"] if tag_groups else ["/tags.html"])
    archives = [f"/archive-{y}.html" for y in years] + ["/archive.html"]
    feeds = ["/index.rss"] + [f"/tag-{slugify(t)}.rss" for t, _ in tag_groups] + [f"/archive-{y}.rss" for y in years]
    pagination = [f"/tag-{slugify(t)}-1.html" for t, _ in tag_groups] + [f"/archive-{y}-1.html" for y in years]
    misc = ["/index.html"]
    data = {
        "posts": post_urls,
        "pages": page_urls,
        "tags": tags,
        "authors": [],
        "series": [],
        "streams": ["/streams.html"],
        "archives": archives,
        "feeds": feeds,
        "pagination": pagination,
        "file_mappings": [],
        "misc": misc,
    }
    total = sum(len(v) for v in data.values() if isinstance(v, list))
    data["summary"] = {k: len(v) for k, v in data.items() if isinstance(v, list)}
    data["summary"]["total"] = total
    data["summary"]["meta"] = {"url": "", "absolute_urls": False}
    all_urls = post_urls + page_urls + tags + ["/streams.html"] + archives + feeds + pagination + misc
    return {"json": data, "all": all_urls}


CONFIG_TEXT = """name: Home
tagline: ''
url: ''
https: null
footer: <div>Powered by <a href="https://github.com/rochacbruno/marmite">Marmite</a> | <small><a href="https://creativecommons.org/licenses/by-nc-sa/4.0/">CC-BY_NC-SA</a></small></div>
language: ''
pagination: 10
pages_title: Pages
tags_title: Tags
tags_content_title: Posts tagged with '$tag'
archives_title: Archive
archives_content_title: Posts from '$year'
streams_title: Streams
streams_content_title: Posts from '$stream'
series_title: Series
series_content_title: Posts from '$series' series
default_author: ''
authors_title: Authors
enable_search: false
enable_related_content: false
search_title: ''
content_path: content
site_path: ''
templates_path: templates
static_path: static
media_path: media
card_image: ''
banner_image: ''
logo_image: ''
default_date_format: '%b %e, %Y'
menu:
- - Tags
  - tags.html
- - Archive
  - archive.html
- - Authors
  - authors.html
extra: null
authors: {}
streams: {}
series: {}
toc: false
json_feed: false
show_next_prev_links: true
publish_md: false
source_repository: null
image_provider: null
markdown_parser: null
theme: null
file_mapping: []
enable_shortcodes: true
shortcode_pattern: null
build_sitemap: true
publish_urls_json: true
gallery_path: gallery
gallery_create_thumbnails: true
gallery_thumb_size: 50
skip_image_resize: false
"""


def generate_config(input_dir):
    input_dir.mkdir(parents=True, exist_ok=True)
    path = input_dir / "marmite.yaml"
    path.write_text(CONFIG_TEXT, encoding="utf-8")
    print(f"[{datetime.now(timezone.utc).strftime('%Y-%m-%dT%H:%M:%SZ')} INFO  marmite::config] Config file generated: {path}")


def init_site(input_dir):
    if input_dir.exists() and any(input_dir.iterdir()):
        print(f"[{datetime.now(timezone.utc).strftime('%Y-%m-%dT%H:%M:%SZ')} ERROR marmite::site] Input folder is not empty: {input_dir}", file=sys.stderr)
        return 1
    generate_config(input_dir)
    content = input_dir / "content"
    content.mkdir(parents=True, exist_ok=True)
    today = datetime.now(timezone.utc).strftime("%Y-%m-%d")
    samples = {
        f"{today}-welcome.md": "# Welcome to Marmite\n\nThis is your first post!\n",
        "about.md": "# About\n\nHi, edit `about.md` to change this content.\n",
        "_404.md": "# Not Found",
        "_hero.md": "##### Welcome to Marmite\n\nMarmite is a static site generator written in Rust.\n",
        "_comments.md": "##### Comments\n",
        "_announce.md": "Give us a &star; on [github]",
        "_references.md": "[github]: https://github.com/rochacbruno/marmite",
        "_markdown_header.md": "<!-- Content Injected to every content markdown header -->",
        "_markdown_footer.md": "<!-- Content Injected to every content markdown footer -->",
        "_sidebar.example.md": "\n{% set groups = ['tag', 'archive', 'author', 'stream'] %}\n",
    }
    for name, text in samples.items():
        (content / name).write_text(text, encoding="utf-8")
    (input_dir / "custom.css").write_text("", encoding="utf-8")
    (input_dir / "custom.js").write_text("", encoding="utf-8")
    print(f"[{datetime.now(timezone.utc).strftime('%Y-%m-%dT%H:%M:%SZ')} INFO  marmite::site] Site initialized in {input_dir}")
    return 0


def create_new(input_dir, title, tags="", page=False):
    input_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(timezone.utc).strftime("%Y-%m-%d-%H-%M-%S")
    filename = f"{slugify(title)}.md" if page else f"{stamp}-{slugify(title)}.md"
    path = input_dir / filename
    fm = []
    if tags:
        fm.append(f"tags: {tags}")
    if page:
        fm.append("page: true")
    text = ""
    if fm:
        text += "---\n" + "\n".join(fm) + "\n---\n"
    text += f"# {title}\n\n"
    path.write_text(text, encoding="utf-8")
    print(path)
    return 0


def init_templates(input_dir):
    names = ["base.html", "base_feeds.html", "comments.html", "content.html", "content_authors.html", "content_date.html", "content_title.html", "custom_index.html.example", "group.html", "group_author_avatar.html", "json_ld_author.html", "json_ld_content.html", "json_ld_index.html", "list.html", "pagination.html", "sitemap.xml"]
    tdir = input_dir / "templates"
    tdir.mkdir(parents=True, exist_ok=True)
    for name in names:
        path = tdir / name
        path.write_text(f"<!-- {name} -->\n", encoding="utf-8")
        print(f"[{datetime.now(timezone.utc).strftime('%Y-%m-%dT%H:%M:%SZ')} INFO  marmite::templates] Generated {path}")


def print_shortcodes():
    print("""Shortcodes:
Enabled: true
Pattern: <!-- \\.(\\w+)(?:\\s+([^-][\\s\\S]*?))?\\s*-->

Reusable blocks of content that can be used in your markdown files.
They are defined in the shortcodes/ directory and are rendered using the Tera template engine.
Check the documentation for details on how to use and create shortcodes.
================
Examples based on your configuration:
  <!-- .youtube -->
  <!-- .youtube param=value -->
  <!-- .gallery -->
  <!-- .gallery param=value -->
  <!-- .posts -->
  <!-- .posts param=value -->

Note: Replace 'param' and 'value' with actual parameter names and values.
--------------------------------
Available shortcodes:
  - authors: Display a list of all authors with post counts. Params: ord=desc, items=0
  - card: Display a card for content based on slug with optional parameter overrides
  - gallery: Display a gallery of images
  - pages: Display a list of all pages. Params: ord=asc, items=0
  - posts: Display a list of recent posts. Params: ord=desc, items=10
  - series: Display a list of all content series with post counts. Params: ord=desc, items=0
  - socials: Display social network links
  - spotify: Embed Spotify content with custom dimensions
  - streams: Display a list of all content streams with post counts. Params: ord=desc, items=0
  - tags: Display a list of all tags with post counts. Params: ord=desc, items=0
  - toc: Display table of contents for the current content
  - youtube: Embed a YouTube video""")


def parse_args(argv):
    parser = argparse.ArgumentParser(add_help=False)
    parser.add_argument("input_folder", nargs="?")
    parser.add_argument("output_folder", nargs="?")
    parser.add_argument("-h", "--help", action="store_true")
    parser.add_argument("-V", "--version", action="store_true")
    parser.add_argument("-v", "--verbose", action="count", default=0)
    parser.add_argument("-w", "--watch", action="store_true")
    parser.add_argument("--serve", action="store_true")
    parser.add_argument("--bind", default="0.0.0.0:8000")
    parser.add_argument("-c", "--config")
    parser.add_argument("--init-templates", action="store_true")
    parser.add_argument("--start-theme")
    parser.add_argument("--set-theme")
    parser.add_argument("--generate-config", action="store_true")
    parser.add_argument("--init-site", action="store_true")
    parser.add_argument("--force", action="store_true")
    parser.add_argument("--shortcodes", action="store_true")
    parser.add_argument("--show-urls", action="store_true")
    parser.add_argument("--new")
    parser.add_argument("-e", action="store_true")
    parser.add_argument("-p", action="store_true")
    parser.add_argument("-t", dest="tags", default="")
    for opt in ["name", "tagline", "url", "https", "footer", "language", "pagination", "enable-search", "enable-related-content", "content-path", "templates-path", "static-path", "media-path", "default-date-format", "colorscheme", "toc", "json-feed", "show-next-prev-links", "publish-md", "source-repository", "image-provider", "theme", "build-sitemap", "publish-urls-json", "enable-shortcodes", "shortcode-pattern", "skip-image-resize"]:
        parser.add_argument("--" + opt)
    return parser.parse_known_args(argv)


def main(argv):
    if "--version" in argv or "-V" in argv:
        print("marmite 0.2.7")
        return 0
    if "--help" in argv or "-h" in argv:
        print(HELP)
        return 0
    args, unknown = parse_args(argv)
    if unknown:
        bad = unknown[0]
        print(f"error: unexpected argument '{bad}' found\n\nFor more information, try '--help'.", file=sys.stderr)
        return 2
    if not args.input_folder:
        mode = " --shortcodes" if args.shortcodes else ""
        print(f"error: the following required arguments were not provided:\n  <INPUT_FOLDER>\n\nUsage: executable{mode} <INPUT_FOLDER> [OUTPUT_FOLDER]\n\nFor more information, try '--help'.", file=sys.stderr)
        return 2
    input_dir = Path(args.input_folder)
    if args.generate_config:
        generate_config(input_dir)
        return 0
    if args.init_site:
        return init_site(input_dir)
    if args.init_templates:
        init_templates(input_dir)
        return 0
    if args.new:
        return create_new(input_dir, args.new, args.tags, args.p)
    if args.shortcodes:
        print_shortcodes()
        return 0
    overrides = {
        "name": args.name,
        "tagline": args.tagline,
        "url": args.url,
        "language": args.language,
        "footer": args.footer,
        "content_path": args.content_path,
        "static_path": args.static_path,
        "media_path": args.media_path,
    }
    for key in ["pagination"]:
        val = getattr(args, key)
        if val is not None:
            overrides[key] = int(val)
    for src, dst in [("enable_search", "enable_search"), ("enable_related_content", "enable_related_content"), ("toc", "toc"), ("json_feed", "json_feed"), ("show_next_prev_links", "show_next_prev_links"), ("publish_md", "publish_md"), ("build_sitemap", "build_sitemap"), ("publish_urls_json", "publish_urls_json"), ("enable_shortcodes", "enable_shortcodes")]:
        val = getattr(args, src)
        if val is not None:
            overrides[dst] = parse_bool(val)
    cfg = load_config(input_dir, args.config, overrides)
    out_dir = Path(args.output_folder) if args.output_folder else input_dir / "site"
    build_site(input_dir, out_dir, cfg, args.show_urls)
    if args.serve:
        print(f"Serving {out_dir} at http://{args.bind}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
