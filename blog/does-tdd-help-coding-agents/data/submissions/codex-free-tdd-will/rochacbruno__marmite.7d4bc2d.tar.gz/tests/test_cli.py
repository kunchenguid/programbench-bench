import subprocess
import tempfile
import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]


def run_cmd(args, cwd=None):
    return subprocess.run(args, cwd=cwd or ROOT, text=True, capture_output=True)


class MarmiteCliTest(unittest.TestCase):
    def test_compile_produces_executable_and_version(self):
        exe = ROOT / "executable"
        if exe.exists():
            exe.unlink()
        result = run_cmd(["bash", "compile.sh"])
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertTrue(exe.exists())
        result = run_cmd([str(exe), "--version"])
        self.assertEqual(result.returncode, 0)
        self.assertEqual(result.stdout, "marmite 0.2.7\n")

    def test_generates_site_from_markdown_with_front_matter(self):
        run_cmd(["bash", "compile.sh"])
        with tempfile.TemporaryDirectory() as tmp:
            base = Path(tmp)
            src = base / "input"
            out = base / "out"
            src.mkdir()
            (src / "hello.md").write_text(
                "---\n"
                "title: Hello World\n"
                "date: 2024-01-02\n"
                "tags: rust, web\n"
                "---\n"
                "# Hello World\n\n"
                "This is **bold** and [link](https://example.com).\n\n"
                "## Section\n\n"
                "- one\n"
                "- two\n",
                encoding="utf-8",
            )
            result = run_cmd([str(ROOT / "executable"), str(src), str(out)])
            self.assertEqual(result.returncode, 0, result.stderr)
            post = (out / "hello-world.html").read_text(encoding="utf-8")
            self.assertIn("<title>Hello World | Home</title>", post)
            self.assertIn("<h1>Hello World</h1>", post)
            self.assertIn("<strong>bold</strong>", post)
            self.assertIn('<a href="https://example.com">link</a>', post)
            self.assertIn('<a href="/tag-rust.html"', post)
            index = (out / "index.html").read_text(encoding="utf-8")
            self.assertIn('<a href="/hello-world.html">Hello World</a>', index)
            self.assertIn("This is bold and link.", index)
            self.assertTrue((out / "tag-rust.html").exists())
            self.assertTrue((out / "archive-2024.html").exists())
            self.assertIn("/hello-world.html", (out / "urls.json").read_text())
            self.assertIn("<loc>/hello-world.html</loc>", (out / "sitemap.xml").read_text())
            self.assertIn("<rss", (out / "index.rss").read_text())

    def test_project_helpers_create_documented_files(self):
        run_cmd(["bash", "compile.sh"])
        with tempfile.TemporaryDirectory() as tmp:
            base = Path(tmp)
            cfg_dir = base / "cfg"
            result = run_cmd([str(ROOT / "executable"), str(cfg_dir), "--generate-config"])
            self.assertEqual(result.returncode, 0, result.stderr)
            self.assertIn("name: Home", (cfg_dir / "marmite.yaml").read_text())

            init_dir = base / "init"
            result = run_cmd([str(ROOT / "executable"), str(init_dir), "--init-site"])
            self.assertEqual(result.returncode, 0, result.stderr)
            self.assertTrue((init_dir / "content" / "about.md").exists())
            self.assertTrue((init_dir / "custom.css").exists())

            tpl_dir = base / "tpl"
            result = run_cmd([str(ROOT / "executable"), str(tpl_dir), "--init-templates"])
            self.assertEqual(result.returncode, 0, result.stderr)
            self.assertTrue((tpl_dir / "templates" / "base.html").exists())
            self.assertTrue((tpl_dir / "templates" / "sitemap.xml").exists())

            new_dir = base / "new"
            result = run_cmd([str(ROOT / "executable"), str(new_dir), "--new", "My First Post", "-t", "a,b"])
            self.assertEqual(result.returncode, 0, result.stderr)
            created = list(new_dir.glob("*my-first-post.md"))
            self.assertEqual(len(created), 1)
            text = created[0].read_text()
            self.assertIn("tags: a,b", text)
            self.assertIn("# My First Post", text)

    def test_config_and_cli_options_affect_generated_site(self):
        run_cmd(["bash", "compile.sh"])
        with tempfile.TemporaryDirectory() as tmp:
            base = Path(tmp)
            src = base / "blog"
            content = src / "notes"
            out = base / "site"
            content.mkdir(parents=True)
            (src / "marmite.yaml").write_text(
                "name: Config Name\n"
                "tagline: From config\n"
                "content_path: notes\n"
                "publish_md: true\n"
                "build_sitemap: false\n",
                encoding="utf-8",
            )
            (content / "2024-04-05-sample.md").write_text(
                "# Sample Page\n\nBody text with `code`.\n", encoding="utf-8"
            )
            result = run_cmd([str(ROOT / "executable"), str(src), str(out), "--name", "CLI Name"])
            self.assertEqual(result.returncode, 0, result.stderr)
            page = (out / "sample-page.html").read_text(encoding="utf-8")
            self.assertIn("<title>Sample Page | CLI Name</title>", page)
            self.assertIn("<code>code</code>", page)
            self.assertTrue((out / "sample-page.md").exists())
            self.assertFalse((out / "sitemap.xml").exists())


if __name__ == "__main__":
    unittest.main()
