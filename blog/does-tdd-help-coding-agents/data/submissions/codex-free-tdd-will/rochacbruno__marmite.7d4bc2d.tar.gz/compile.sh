#!/bin/bash
set -e
cp src/marmite.py executable
chmod +x executable
