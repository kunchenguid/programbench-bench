#!/usr/bin/env python3
import sys
import re
import difflib
import os


RED = "\033[31m"
GREEN = "\033[32m"
BLUE = "\033[34m"
RESET = "\033[0m"
MINUS_BG = "\033[48;5;52m"
PLUS_BG = "\033[48;5;22m"
CLEAR = "\033[0K"

SHORT_HELP = """A viewer for git and diff output

Usage: delta [OPTIONS] [MINUS_FILE] [PLUS_FILE]

Arguments:
  [MINUS_FILE]  First file to be compared when delta is being used to diff two files
  [PLUS_FILE]   Second file to be compared when delta is being used to diff two files

Options:
      --color-only                  Do not alter the input structurally in any way
      --dark                        Use default colors appropriate for a dark terminal background
      --diff-highlight              Emulate diff-highlight
      --diff-so-fancy               Emulate diff-so-fancy
      --keep-plus-minus-markers     Prefix added/removed lines with a +/- character, as git does
  -n, --line-numbers                Display line numbers next to the diff
      --list-languages              List supported languages and associated file extensions
      --list-syntax-themes          List available syntax-highlighting color themes
      --no-gitconfig                Do not read any settings from git config
      --paging <auto|always|never>  Whether to use a pager when displaying output
      --raw                         Do not alter the input in any way
      --show-colors                 Show available named colors
      --show-config                 Display the active values for all Delta options
  -s, --side-by-side                Display diffs in side-by-side layout
      --syntax-theme <THEME>        The syntax-highlighting theme to use
  -w, --width <N>                   The width of underline/overline decorations
  -h, --help                        Print help (see more with '--help')
  -V, --version                     Print version
"""

THEMES = """dark\t1337
dark\tColdark-Cold
dark\tColdark-Dark
dark\tDarkNeon
dark\tDracula
dark\tMonokai Extended
dark\tMonokai Extended Bright
dark\tMonokai Extended Origin
dark\tNord
dark\tOneHalfDark
dark\tSolarized (dark)
dark\tSublime Snazzy
dark\tTwoDark
dark\tVisual Studio Dark+
dark\tansi
dark\tbase16
dark\tbase16-256
dark\tgruvbox-dark
dark\tzenburn
light\tGitHub
light\tMonokai Extended Light
light\tOneHalfLight
light\tSolarized (light)
light\tgruvbox-light
"""

LANGUAGES = """ActionScript              \033[32mas\033[0m
Ada                       \033[32madb\033[0m, \033[32mads\033[0m, \033[32mgpr\033[0m
Bourne Again Shell (bash) \033[32msh\033[0m, \033[32mbash\033[0m, \033[32mzsh\033[0m
C                         \033[32mc\033[0m, \033[32mh\033[0m
C++                       \033[32mcpp\033[0m, \033[32mcc\033[0m, \033[32mhpp\033[0m
Diff                      \033[32mdiff\033[0m, \033[32mpatch\033[0m
Git Config                \033[32mgitconfig\033[0m
JSON                      \033[32mjson\033[0m
Markdown                  \033[32mmd\033[0m, \033[32mmarkdown\033[0m
Python                    \033[32mpy\033[0m, \033[32mpyi\033[0m
Rust                      \033[32mrs\033[0m
Text                      \033[32mtxt\033[0m
"""


def raw_output(text: str) -> str:
    out = []
    for line in text.splitlines(True):
        body = line[:-1] if line.endswith("\n") else line
        nl = "\n" if line.endswith("\n") else ""
        if body.startswith("-") and not body.startswith("---"):
            out.append(f"{RED}{body}{RESET}{nl}")
        elif body.startswith("+") and not body.startswith("+++"):
            out.append(f"{GREEN}{body}{RESET}{nl}")
        else:
            out.append(line)
    return "".join(out)


def strip_prefix_path(path: str) -> str:
    path = path.strip()
    if path.startswith("a/") or path.startswith("b/"):
        return path[2:]
    return path


def color_bg(text: str, bg: str) -> str:
    return f"{bg}{text}{RESET}{bg}{CLEAR}{RESET}"


def color_only_output(text: str) -> str:
    out = []
    for line in text.splitlines(True):
        body = line[:-1] if line.endswith("\n") else line
        nl = "\n" if line.endswith("\n") else ""
        if body.startswith("-") and not body.startswith("---"):
            out.append(color_bg(body, MINUS_BG) + nl)
        elif body.startswith("+") and not body.startswith("+++"):
            out.append(color_bg(body, PLUS_BG) + nl)
        else:
            out.append(line)
    return "".join(out)


def hunk_starts(header: str) -> tuple[int, int]:
    m = re.search(r"@@ -(\d+)(?:,\d+)? \+(\d+)", header)
    return (int(m.group(1)), int(m.group(2))) if m else (0, 0)


def render_hunk_header(header: str) -> list[str]:
    start, _ = hunk_starts(header)
    return [
        f"{BLUE}───{RESET}{BLUE}┐{RESET}",
        f"{BLUE}{start}{RESET}: {BLUE}│{RESET}",
        f"{BLUE}───{RESET}{BLUE}┘{RESET}",
    ]


def ln_prefix(old, new) -> str:
    left = f"{old:>3} " if old is not None else "    "
    right = f"{new:>3} " if new is not None else "    "
    return f"{BLUE}\033[38;5;238m{left}{BLUE}⋮\033[38;5;238m{right}{BLUE}│{RESET}"


def default_output(text: str, keep_markers: bool = False, line_numbers: bool = False) -> str:
    lines = text.splitlines()
    if not any(line.startswith(("diff --git ", "@@ ", "--- ", "+++ ")) for line in lines):
        return text
    out: list[str] = []
    current_file = None
    pending_minus = None
    in_diff = False
    old_no = 0
    new_no = 0
    for line in lines:
        if line.startswith("diff --git "):
            parts = line.split()
            current_file = strip_prefix_path(parts[-1]) if len(parts) >= 4 else None
            in_diff = True
            continue
        if line.startswith("--- "):
            pending_minus = strip_prefix_path(line[4:])
            continue
        if line.startswith("+++ "):
            plus = strip_prefix_path(line[4:])
            if pending_minus and pending_minus != plus and plus != "/dev/null":
                current_file = f"{pending_minus} ⟶   {plus}"
            elif plus != "/dev/null":
                current_file = plus
            elif pending_minus:
                current_file = pending_minus
            if in_diff:
                out.extend(["", f"{BLUE}{current_file}{RESET}", f"{BLUE}{'─' * 80}{RESET}", ""])
                in_diff = False
            continue
        if line.startswith("@@ "):
            if in_diff and current_file:
                out.extend(["", f"{BLUE}{current_file}{RESET}", f"{BLUE}{'─' * 80}{RESET}", ""])
                in_diff = False
            out.extend(render_hunk_header(line))
            old_no, new_no = hunk_starts(line)
            continue
        if line.startswith(("index ", "new file mode ", "deleted file mode ", "similarity index ")):
            continue
        if line.startswith("-") and not line.startswith("---"):
            body = line if keep_markers else line[1:]
            rendered = color_bg(body, MINUS_BG)
            if line_numbers:
                rendered = ln_prefix(old_no, None) + rendered
            out.append(rendered)
            old_no += 1
        elif line.startswith("+") and not line.startswith("+++"):
            body = line if keep_markers else line[1:]
            rendered = color_bg(body, PLUS_BG)
            if line_numbers:
                rendered = ln_prefix(None, new_no) + rendered
            out.append(rendered)
            new_no += 1
        elif line.startswith(" "):
            rendered = line[1:]
            if line_numbers:
                rendered = ln_prefix(old_no, new_no) + rendered
            out.append(rendered)
            old_no += 1
            new_no += 1
        else:
            out.append(line)
    return "\n".join(out) + ("\n" if text.endswith("\n") else "")


def unified_diff_for_files(left: str, right: str) -> str:
    with open(left, "r", encoding="utf-8", errors="replace") as f:
        a = f.readlines()
    with open(right, "r", encoding="utf-8", errors="replace") as f:
        b = f.readlines()
    left_label = os.path.relpath(left, "/")
    right_label = os.path.relpath(right, "/")
    diff = difflib.unified_diff(a, b, fromfile=left_label, tofile=right_label, lineterm="")
    lines = [f"diff --git a/{left_label} b/{right_label}", *diff]
    return "\n".join(line.rstrip("\n") for line in lines) + "\n"


def positional_args(argv: list[str]) -> list[str]:
    args = []
    i = 0
    value_options = {
        "--config", "--pager", "--paging", "--syntax-theme", "--true-color", "--24-bit-color",
        "--width", "--tabs", "--diff-args", "-@", "--features", "--grep-output-type",
        "--default-language", "--detect-dark-light", "--max-line-length", "--max-line-distance",
        "--word-diff-regex", "--line-numbers-left-format", "--line-numbers-right-format",
    }
    while i < len(argv):
        arg = argv[i]
        if arg == "--":
            args.extend(argv[i + 1 :])
            break
        if arg.startswith("-"):
            if arg in value_options and "=" not in arg:
                i += 2
                continue
            i += 1
            continue
        args.append(arg)
        i += 1
    return args


def main(argv=None) -> int:
    argv = list(sys.argv[1:] if argv is None else argv)
    if "-V" in argv or "--version" in argv:
        sys.stdout.write("delta 0.18.2\n")
        return 0
    if "-h" in argv or "--help" in argv:
        sys.stdout.write(SHORT_HELP)
        return 0
    if "--list-syntax-themes" in argv:
        sys.stdout.write(THEMES)
        return 0
    if "--list-languages" in argv:
        sys.stdout.write(LANGUAGES)
        return 0
    if "--show-config" in argv:
        sys.stdout.write(
            "    commit-style                  = raw\n"
            "    file-style                    = \033[34mblue\033[0m\n"
            "    hunk-header-style             = syntax\n"
            "    minus-style                   = \033[48;5;52mnormal 52\033[0m\n"
            "    plus-style                    = \033[48;5;22msyntax 22\033[0m\n"
            "    true-color                    = false\n"
            "    line-numbers                  = false\n"
            "    paging                        = never\n"
            "    side-by-side                  = false\n"
            "    syntax-theme                  = Monokai Extended\n"
            "    width                         = 80\n"
        )
        return 0
    if "--show-colors" in argv:
        for name, hex_code in [("Blue", "#0000ff"), ("Green", "#008000"), ("Red", "#ff0000"), ("Yellow", "#ffff00")]:
            sys.stdout.write(f"\n\033[1m{name}\033[0m\nexport function color(): string {{ return \"{name.lower()}\" }}\nexport function hex(): string {{ return \"{hex_code}\" }}\n")
        return 0
    pos = positional_args(argv)
    if "--raw" in argv:
        text = unified_diff_for_files(pos[0], pos[1]) if len(pos) == 2 else sys.stdin.read()
        sys.stdout.write(raw_output(text))
        return 0
    if "--color-only" in argv:
        text = unified_diff_for_files(pos[0], pos[1]) if len(pos) == 2 else sys.stdin.read()
        sys.stdout.write(color_only_output(text))
        return 0
    text = unified_diff_for_files(pos[0], pos[1]) if len(pos) == 2 else sys.stdin.read()
    sys.stdout.write(default_output(text, "--keep-plus-minus-markers" in argv, "--line-numbers" in argv or "-n" in argv))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
