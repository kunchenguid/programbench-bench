import os
import subprocess
import sys
import tempfile
import unittest
import re


ROOT = os.path.dirname(os.path.dirname(__file__))
BIN = os.path.join(ROOT, "src", "delta.py")


def run_delta(args=None, stdin=""):
    args = args or []
    return subprocess.run(
        [sys.executable, BIN, *args],
        input=stdin,
        text=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
    )


def visible(text):
    return re.sub(r"\x1b\[[0-9;]*[A-Za-z]", "", text)


class DeltaCliTests(unittest.TestCase):
    def test_raw_preserves_diff_structure_and_colors_changed_lines(self):
        diff = (
            "diff --git a/a.txt b/a.txt\n"
            "--- a/a.txt\n"
            "+++ b/a.txt\n"
            "@@ -1 +1 @@\n"
            "-old\n"
            "+new\n"
        )

        result = run_delta(["--raw"], diff)

        self.assertEqual(result.returncode, 0)
        self.assertEqual(
            result.stdout,
            "diff --git a/a.txt b/a.txt\n"
            "--- a/a.txt\n"
            "+++ b/a.txt\n"
            "@@ -1 +1 @@\n"
            "\x1b[31m-old\x1b[0m\n"
            "\x1b[32m+new\x1b[0m\n",
        )

    def test_default_renders_unified_diff_with_file_header_and_markerless_lines(self):
        diff = (
            "diff --git a/a.txt b/a.txt\n"
            "index 1111111..2222222 100644\n"
            "--- a/a.txt\n"
            "+++ b/a.txt\n"
            "@@ -1,3 +1,3 @@\n"
            " same\n"
            "-old\n"
            "+new\n"
            " end\n"
        )

        result = run_delta(["--paging=never", "--no-gitconfig"], diff)

        self.assertEqual(result.returncode, 0)
        self.assertEqual(
            result.stdout,
            "\n"
            "\x1b[34ma.txt\x1b[0m\n"
            f"\x1b[34m{'─' * 80}\x1b[0m\n"
            "\n"
            "\x1b[34m───\x1b[0m\x1b[34m┐\x1b[0m\n"
            "\x1b[34m1\x1b[0m: \x1b[34m│\x1b[0m\n"
            "\x1b[34m───\x1b[0m\x1b[34m┘\x1b[0m\n"
            "same\n"
            "\x1b[48;5;52mold\x1b[0m\x1b[48;5;52m\x1b[0K\x1b[0m\n"
            "\x1b[48;5;22mnew\x1b[0m\x1b[48;5;22m\x1b[0K\x1b[0m\n"
            "end\n",
        )

    def test_two_file_arguments_are_compared_as_a_unified_diff(self):
        with tempfile.TemporaryDirectory() as tmp:
            left = os.path.join(tmp, "left.txt")
            right = os.path.join(tmp, "right.txt")
            with open(left, "w", encoding="utf-8") as f:
                f.write("foo\nbar\nbaz\n")
            with open(right, "w", encoding="utf-8") as f:
                f.write("foo\nBAR\nbaz\nqux\n")

            result = run_delta(["--paging=never", left, right])

        self.assertEqual(result.returncode, 0)
        self.assertIn(f"{os.path.relpath(left, '/') } ⟶   {os.path.relpath(right, '/')}", result.stdout)
        self.assertIn("\x1b[48;5;52mbar\x1b[0m", result.stdout)
        self.assertIn("\x1b[48;5;22mBAR\x1b[0m", result.stdout)
        self.assertIn("\x1b[48;5;22mqux\x1b[0m", result.stdout)

    def test_line_numbers_track_old_and_new_hunk_positions(self):
        diff = (
            "diff --git a/a.txt b/a.txt\n"
            "--- a/a.txt\n"
            "+++ b/a.txt\n"
            "@@ -1,3 +1,4 @@\n"
            " same\n"
            "-old\n"
            "+new\n"
            "+more\n"
            " end\n"
        )

        result = run_delta(["--line-numbers"], diff)

        self.assertEqual(result.returncode, 0)
        text = visible(result.stdout)
        self.assertIn("  1 ⋮  1 │same", text)
        self.assertIn("  2 ⋮    │old", text)
        self.assertIn("    ⋮  2 │new", text)
        self.assertIn("  3 ⋮  4 │end", text)

    def test_common_metadata_commands(self):
        version = run_delta(["--version"])
        self.assertEqual(version.stdout, "delta 0.18.2\n")

        help_result = run_delta(["-h"])
        self.assertIn("A viewer for git and diff output", help_result.stdout)
        self.assertIn("Usage: delta [OPTIONS] [MINUS_FILE] [PLUS_FILE]", help_result.stdout)

        themes = run_delta(["--list-syntax-themes"])
        self.assertIn("dark\tDracula\n", themes.stdout)
        self.assertIn("light\tGitHub\n", themes.stdout)


if __name__ == "__main__":
    unittest.main()
