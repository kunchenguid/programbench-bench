#!/bin/bash
set -e
gcc -std=c99 -Wall -Wextra -O2 -o executable src/entr_clone.c
chmod +x executable
