#define _POSIX_C_SOURCE 200809L

#include <errno.h>
#include <signal.h>
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <sys/inotify.h>
#include <sys/wait.h>
#include <poll.h>
#include <unistd.h>

typedef struct {
    int noninteractive;
    int postpone;
    int once;
    int shell;
    int clear_count;
    int dir_count;
    int reload;
    int all_events;
    int status_filter;
} Options;

typedef struct {
    char **items;
    size_t len;
    size_t cap;
} StrList;

typedef struct {
    int wd;
    char *path;
    int is_dir;
} Watch;

static const char *progname = "executable";

static void die_usage(void) {
    fprintf(stderr, "release: 5.7\n");
    fprintf(stderr, "usage: entr [-acdnprsxz] utility [argument [/_] ...] < filenames\n");
    fprintf(stderr, "hint: use -h to display option summary\n");
}

static void print_help(void) {
    printf("release: 5.7\n");
    printf("usage: entr [-acdnprsxz] utility [argument [/_] ...] < filenames\n");
    printf("summary:\n");
    printf("    -a  Do not consolidate events\n");
    printf("    -c  Clear screen before execution\n");
    printf("    -d  Track files added or removed from directories\n");
    printf("    -n  Non-interactive mode\n");
    printf("    -p  Wait for first event\n");
    printf("    -r  Run as a background process, use signal to restart\n");
    printf("    -s  Evaluate using a shell\n");
    printf("    -x  Format exit status\n");
    printf("    -z  Exit after the utility completes\n");
    printf("docs:\n");
    printf("    man entr\n");
}

static void list_push(StrList *list, char *s) {
    if (list->len == list->cap) {
        size_t ncap = list->cap ? list->cap * 2 : 16;
        char **nitems = realloc(list->items, ncap * sizeof(*nitems));
        if (!nitems) {
            perror("realloc");
            exit(1);
        }
        list->items = nitems;
        list->cap = ncap;
    }
    list->items[list->len++] = s;
}

static char *trim_newline(char *s) {
    size_t n = strlen(s);
    while (n && (s[n - 1] == '\n' || s[n - 1] == '\r')) {
        s[--n] = '\0';
    }
    return s;
}

static int read_files(StrList *files) {
    char *line = NULL;
    size_t cap = 0;
    ssize_t nread;
    int regular = 0;

    while ((nread = getline(&line, &cap, stdin)) != -1) {
        (void)nread;
        trim_newline(line);
        if (line[0] == '\0') {
            continue;
        }
        struct stat st;
        if (stat(line, &st) != 0) {
            fprintf(stderr, "%s: unable to stat '%s'\n", progname, line);
            continue;
        }
        if (S_ISREG(st.st_mode) || S_ISDIR(st.st_mode)) {
            if (S_ISREG(st.st_mode)) {
                regular++;
            }
            list_push(files, strdup(line));
        }
    }
    free(line);
    return regular;
}

static int wait_status_to_exit(int status) {
    if (WIFEXITED(status)) {
        return WEXITSTATUS(status);
    }
    if (WIFSIGNALED(status)) {
        return 128 + WTERMSIG(status);
    }
    return 1;
}

static pid_t spawn_command(const Options *opt, char **argv, int argc, const char *trigger) {
    if (opt->clear_count == 1) {
        fputs("\033[H\033[J", stdout);
        fflush(stdout);
    } else if (opt->clear_count >= 2) {
        fputs("\033[H\033[2J\033[3J", stdout);
        fflush(stdout);
    }

    pid_t pid = fork();
    if (pid < 0) {
        perror("fork");
        return -1;
    }
    if (pid == 0) {
        if (opt->reload) {
            setpgid(0, 0);
        }
        if (opt->shell) {
            const char *shell = getenv("SHELL");
            if (!shell || !shell[0]) shell = "/bin/sh";
            execl(shell, shell, "-c", argv[0], trigger, (char *)NULL);
            fprintf(stderr, "%s: exec %s: %s\n", progname, shell, strerror(errno));
            _exit(1);
        }

        char **child = calloc((size_t)argc + 1, sizeof(char *));
        if (!child) _exit(1);
        int replaced = 0;
        for (int i = 0; i < argc; i++) {
            if (!replaced && strcmp(argv[i], "/_") == 0) {
                child[i] = (char *)trigger;
                replaced = 1;
            } else {
                child[i] = argv[i];
            }
        }
        execvp(child[0], child);
        fprintf(stderr, "%s: exec %s: %s\n", progname, child[0], strerror(errno));
        _exit(1);
    }
    return pid;
}

static int run_command(const Options *opt, char **argv, int argc, const char *trigger) {
    pid_t pid = spawn_command(opt, argv, argc, trigger);
    if (pid < 0) return 1;
    int status = 0;
    while (waitpid(pid, &status, 0) < 0) {
        if (errno != EINTR) {
            perror("waitpid");
            return 1;
        }
    }
    return wait_status_to_exit(status);
}

static int restart_signal(void) {
    const char *s = getenv("ENTR_RESTART_SIGNAL");
    if (!s || !*s || strcmp(s, "TERM") == 0 || strcmp(s, "SIGTERM") == 0) return SIGTERM;
    if (strcmp(s, "HUP") == 0 || strcmp(s, "SIGHUP") == 0) return SIGHUP;
    if (strcmp(s, "INT") == 0 || strcmp(s, "SIGINT") == 0) return SIGINT;
    if (strcmp(s, "QUIT") == 0 || strcmp(s, "SIGQUIT") == 0) return SIGQUIT;
    if (strcmp(s, "USR1") == 0 || strcmp(s, "SIGUSR1") == 0) return SIGUSR1;
    if (strcmp(s, "USR2") == 0 || strcmp(s, "SIGUSR2") == 0) return SIGUSR2;
    return SIGTERM;
}

static char *parent_dir(const char *path) {
    const char *slash = strrchr(path, '/');
    if (!slash) return strdup(".");
    if (slash == path) return strdup("/");
    size_t n = (size_t)(slash - path);
    char *out = malloc(n + 1);
    if (!out) return NULL;
    memcpy(out, path, n);
    out[n] = '\0';
    return out;
}

static const char *path_for_wd(Watch *watches, size_t nwatches, int wd, int *is_dir) {
    for (size_t i = 0; i < nwatches; i++) {
        if (watches[i].wd == wd) {
            if (is_dir) *is_dir = watches[i].is_dir;
            return watches[i].path;
        }
    }
    if (is_dir) *is_dir = 0;
    return NULL;
}

static int watch_loop(const Options *opt, const StrList *files, char **cmd, int cmd_argc) {
    int fd = inotify_init1(opt->reload ? IN_NONBLOCK : 0);
    if (fd < 0) {
        perror("inotify_init");
        return 1;
    }

    size_t cap = files->len * 2 + 4;
    Watch *watches = calloc(cap, sizeof(*watches));
    if (!watches) return 1;
    size_t nwatches = 0;
    unsigned file_mask = IN_MODIFY | IN_CLOSE_WRITE | IN_ATTRIB | IN_MOVED_FROM |
                         IN_MOVED_TO | IN_DELETE_SELF | IN_MOVE_SELF | IN_CREATE | IN_DELETE;
    for (size_t i = 0; i < files->len; i++) {
        struct stat st;
        if (stat(files->items[i], &st) != 0) continue;
        int is_dir = S_ISDIR(st.st_mode);
        int wd = inotify_add_watch(fd, files->items[i], file_mask);
        if (wd >= 0 && nwatches < cap) {
            watches[nwatches++] = (Watch){wd, strdup(files->items[i]), is_dir};
        }
        if (opt->dir_count && !is_dir) {
            char *parent = parent_dir(files->items[i]);
            if (parent) {
                wd = inotify_add_watch(fd, parent, IN_CREATE | IN_DELETE | IN_MOVED_FROM | IN_MOVED_TO);
                if (wd >= 0 && nwatches < cap) {
                    watches[nwatches++] = (Watch){wd, parent, 1};
                } else {
                    free(parent);
                }
            }
        }
    }

    char buf[8192] __attribute__((aligned(__alignof__(struct inotify_event))));
    pid_t child = -1;
    if (opt->reload && !opt->postpone) {
        child = spawn_command(opt, cmd, cmd_argc, files->len ? files->items[0] : "");
        if (child < 0) return 1;
    }
    for (;;) {
        if (opt->reload) {
            int status = 0;
            if (child > 0) {
                pid_t got = waitpid(child, &status, WNOHANG);
                if (got == child) {
                    child = -1;
                    if (opt->once) return wait_status_to_exit(status);
                }
            }
            struct pollfd pfd = { .fd = fd, .events = POLLIN };
            int pr = poll(&pfd, 1, 100);
            if (pr == 0) continue;
            if (pr < 0 && errno == EINTR) continue;
            if (pr < 0) {
                perror("poll");
                return 1;
            }
        }
        ssize_t len = read(fd, buf, sizeof(buf));
        if (len < 0) {
            if (errno == EINTR) continue;
            if (errno == EAGAIN || errno == EWOULDBLOCK) continue;
            perror("read");
            return 1;
        }
        const char *trigger = files->len ? files->items[0] : "";
        int dir_altered = 0;
        for (char *ptr = buf; ptr < buf + len;) {
            struct inotify_event *ev = (struct inotify_event *)ptr;
            int is_dir = 0;
            const char *p = path_for_wd(watches, nwatches, ev->wd, &is_dir);
            if (p) trigger = p;
            if (is_dir && (ev->mask & (IN_CREATE | IN_DELETE | IN_MOVED_FROM | IN_MOVED_TO))) {
                if (ev->len == 0 || opt->dir_count > 1 || ev->name[0] != '.') {
                    dir_altered = 1;
                }
            }
            ptr += sizeof(struct inotify_event) + ev->len;
        }
        int st = 0;
        if (opt->reload) {
            if (child > 0) {
                kill(-child, restart_signal());
                int status = 0;
                while (waitpid(child, &status, 0) < 0 && errno == EINTR) {}
            }
            child = spawn_command(opt, cmd, cmd_argc, trigger);
            st = child < 0 ? 1 : 0;
        } else {
            st = run_command(opt, cmd, cmd_argc, trigger);
        }
        if (dir_altered) {
            fprintf(stderr, "%s: directory altered\n", progname);
            return 2;
        }
        if (opt->once && !opt->reload) return st;
    }
}

int main(int argc, char **argv) {
    Options opt = {0};
    int ch;

    progname = strrchr(argv[0], '/');
    progname = progname ? progname + 1 : argv[0];

    opterr = 0;
    while ((ch = getopt(argc, argv, "acdnprsxzh")) != -1) {
        switch (ch) {
            case 'a': opt.all_events = 1; break;
            case 'c': opt.clear_count++; break;
            case 'd': opt.dir_count++; break;
            case 'n': opt.noninteractive = 1; break;
            case 'p': opt.postpone = 1; break;
            case 'r': opt.reload = 1; break;
            case 's': opt.shell = 1; break;
            case 'x': opt.status_filter++; break;
            case 'z': opt.once = 1; break;
            case 'h':
                print_help();
                return 1;
            default:
                fprintf(stderr, "%s: invalid option -- '%c'\n", argv[0], optopt ? optopt : ch);
                die_usage();
                return 1;
        }
    }

    if (optind >= argc) {
        die_usage();
        return 1;
    }
    if (opt.shell && argc - optind != 1) {
        fprintf(stderr, "%s: -s requires commands to be formatted as a single argument\n", progname);
        return 1;
    }

    StrList files = {0};
    int regular = read_files(&files);
    if (regular == 0 && files.len == 0) {
        fprintf(stderr, "%s: No regular files to watch\n", progname);
        return 1;
    }

    const char *trigger = files.len ? files.items[0] : "";
    if (!opt.postpone) {
        int st = run_command(&opt, &argv[optind], argc - optind, trigger);
        if (opt.once) {
            return st;
        }
    }

    return watch_loop(&opt, &files, &argv[optind], argc - optind);
}
