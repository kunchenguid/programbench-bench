import subprocess, pathlib, unittest, tempfile, os
ROOT = pathlib.Path(__file__).resolve().parents[1]
BIN = ROOT / 'executable'

def run(args, input_data=None):
    return subprocess.run([str(BIN), *args], input=input_data, text=True, capture_output=True)

class SdBehaviorTests(unittest.TestCase):
    def test_stdin_literal_replaces_all_occurrences(self):
        p = run(['foo', 'bar'], 'foo foo\n')
        self.assertEqual(p.returncode, 0)
        self.assertEqual(p.stdout, 'bar bar\n')
        self.assertEqual(p.stderr, '')

    def test_regex_capture_groups_expand_in_replacement(self):
        p = run([r'([a-z]+)([0-9]+)([a-z]+)', '$2-$1-$3'], 'abc123def\n')
        self.assertEqual(p.returncode, 0)
        self.assertEqual(p.stdout, '123-abc-def\n')

    def test_fixed_strings_treats_pattern_and_replacement_literally(self):
        p = run(['-F', 'a.b', '$1'], 'a.b axb\n')
        self.assertEqual(p.returncode, 0)
        self.assertEqual(p.stdout, '$1 axb\n')

    def test_named_captures_expand_with_braced_and_unbraced_names(self):
        p = run([r'(?P<dollars>\d+)\.(?P<cents>\d+)', '$dollars/${cents}'], '123.45\n')
        self.assertEqual(p.returncode, 0)
        self.assertEqual(p.stdout, '123/45\n')

    def test_max_replacements_limits_per_input(self):
        p = run(['-n', '1', 'one', 'X'], 'one two one\n')
        self.assertEqual(p.returncode, 0)
        self.assertEqual(p.stdout, 'X two one\n')

    def test_file_mode_edits_in_place_but_preview_does_not(self):
        with tempfile.TemporaryDirectory() as d:
            path = pathlib.Path(d) / 'sample.txt'
            path.write_text('one two one\n')
            p = run(['one', 'X', str(path)])
            self.assertEqual(p.returncode, 0)
            self.assertEqual(p.stdout, '')
            self.assertEqual(path.read_text(), 'X two X\n')

            path.write_text('one two one\n')
            p = run(['-p', 'one', 'X', str(path)])
            self.assertEqual(p.returncode, 0)
            self.assertEqual(p.stdout, 'X two X\n')
            self.assertEqual(path.read_text(), 'one two one\n')

    def test_regex_flags_control_matching(self):
        self.assertEqual(run(['-f', 'i', 'foo', 'x'], 'Foo foo\n').stdout, 'x x\n')
        self.assertEqual(run(['-f', 'e', '^b', 'X'], 'a\nb\n').stdout, 'a\nb\n')
        self.assertEqual(run(['-f', 's', 'a.b', 'X'], 'a\nb\n').stdout, 'X\n')
        self.assertEqual(run(['-f', 'w', 'ell', 'X'], 'hello ell\n').stdout, 'hello X\n')

    def test_short_attached_option_values_and_rust_named_groups(self):
        self.assertEqual(run(['-n1', 'one', 'X'], 'one one\n').stdout, 'X one\n')
        self.assertEqual(run(['-fi', 'foo', 'x'], 'Foo\n').stdout, 'x\n')
        self.assertEqual(run(['-fci', 'foo', 'x'], 'Foo\n').stdout, 'x\n')
        self.assertEqual(run(['-fic', 'foo', 'x'], 'Foo\n').stdout, 'Foo\n')
        self.assertEqual(run([r'(?<word>\w+)', '$word'], 'abc\n').stdout, 'abc\n')

    def test_ambiguous_numbered_capture_reports_error(self):
        p = run([r'(foo)', '$1x'], 'foo\n')
        self.assertEqual(p.returncode, 1)
        self.assertIn("numbered capture group `$1`", p.stderr)
        self.assertEqual(p.stdout, '')
        self.assertEqual(run([r'(foo)', '${1}x'], 'foo\n').stdout, 'foox\n')

if __name__ == '__main__':
    unittest.main()
