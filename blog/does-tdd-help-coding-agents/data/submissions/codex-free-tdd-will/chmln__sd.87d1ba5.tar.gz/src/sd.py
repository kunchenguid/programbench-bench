#!/usr/bin/env python3
import sys
import re


VERSION = "sd 1.0.0"
HELP = """sd v1.0.0
An intuitive find & replace CLI

Usage: executable [OPTIONS] <FIND> <REPLACE_WITH> [FILES]...

Options:
  -p, --preview
  -F, --fixed-strings
  -n, --max-replacements <LIMIT>
  -f, --flags <FLAGS>
  -h, --help
  -V, --version
"""


class ReplacementError(Exception):
    def __init__(self, group, suffix, template, start, end):
        self.group = group
        self.suffix = suffix
        self.template = template
        self.start = start
        self.end = end


def expand_replacement(template, match):
    out = []
    i = 0
    while i < len(template):
        ch = template[i]
        if ch != "$":
            out.append(ch)
            i += 1
            continue
        if i + 1 >= len(template):
            out.append("$")
            i += 1
        elif template[i + 1] == "$":
            out.append("$")
            i += 2
        elif template[i + 1].isdigit():
            j = i + 1
            while j < len(template) and template[j].isdigit():
                j += 1
            if j < len(template) and (template[j].isalpha() or template[j] == "_"):
                k = j
                while k < len(template) and (template[k].isalnum() or template[k] == "_"):
                    k += 1
                raise ReplacementError(template[i + 1:j], template[j:k], template, i, k)
            try:
                out.append(match.group(int(template[i + 1:j])) or "")
            except IndexError:
                out.append("")
            i = j
        elif template[i + 1] == "{":
            j = template.find("}", i + 2)
            if j == -1:
                out.append("$")
                i += 1
            else:
                name = template[i + 2:j]
                try:
                    if name.isdigit():
                        out.append(match.group(int(name)) or "")
                    else:
                        out.append(match.group(name) or "")
                except (IndexError, KeyError):
                    out.append("")
                i = j + 1
        elif template[i + 1].isalpha() or template[i + 1] == "_":
            j = i + 1
            while j < len(template) and (template[j].isalnum() or template[j] == "_"):
                j += 1
            name = template[i + 1:j]
            try:
                out.append(match.group(name) or "")
            except (IndexError, KeyError):
                out.append("")
            i = j
        else:
            out.append("$")
            i += 1
    return "".join(out)


def replace_text(text, find, repl, fixed=False, limit=0, flags_text=""):
    count = 0 if limit == 0 else limit
    if fixed:
        return text.replace(find, repl) if limit == 0 else text.replace(find, repl, limit)
    find = re.sub(r"\(\?<([A-Za-z_][A-Za-z0-9_]*)>", r"(?P<\1>", find)
    flags = 0
    if "e" not in flags_text:
        flags |= re.MULTILINE
    if "s" in flags_text:
        flags |= re.DOTALL
    case_insensitive = False
    for flag in flags_text:
        if flag == "i":
            case_insensitive = True
        elif flag == "c":
            case_insensitive = False
    if case_insensitive:
        flags |= re.IGNORECASE
    if "w" in flags_text:
        find = r"\b(?:" + find + r")\b"
    pattern = re.compile(find, flags)
    return pattern.sub(lambda m: expand_replacement(repl, m), text, count=count)


def parse_args(argv):
    opts = {"fixed": False, "preview": False, "limit": 0, "flags": "", "positionals": []}
    i = 0
    end_opts = False
    while i < len(argv):
        arg = argv[i]
        if not end_opts and arg == "--":
            end_opts = True
        elif not end_opts and arg in ("-h", "--help"):
            print(HELP, end="")
            raise SystemExit(0)
        elif not end_opts and arg in ("-V", "--version"):
            print(VERSION)
            raise SystemExit(0)
        elif not end_opts and arg in ("-F", "--fixed-strings"):
            opts["fixed"] = True
        elif not end_opts and arg in ("-p", "--preview"):
            opts["preview"] = True
        elif not end_opts and arg in ("-n", "--max-replacements"):
            i += 1
            if i >= len(argv):
                raise ValueError("missing --max-replacements value")
            try:
                opts["limit"] = int(argv[i])
            except ValueError:
                raise ValueError("invalid max replacements")
        elif not end_opts and arg.startswith("-n") and len(arg) > 2:
            try:
                opts["limit"] = int(arg[2:])
            except ValueError:
                raise ValueError("invalid max replacements")
        elif not end_opts and arg.startswith("--max-replacements="):
            try:
                opts["limit"] = int(arg.split("=", 1)[1])
            except ValueError:
                raise ValueError("invalid max replacements")
        elif not end_opts and arg in ("-f", "--flags"):
            i += 1
            if i >= len(argv):
                raise ValueError("missing --flags value")
            opts["flags"] += argv[i]
        elif not end_opts and arg.startswith("-f") and len(arg) > 2:
            opts["flags"] += arg[2:]
        elif not end_opts and arg.startswith("--flags="):
            opts["flags"] += arg.split("=", 1)[1]
        elif not end_opts and arg.startswith("-"):
            raise ValueError(f"unexpected argument '{arg}' found")
        else:
            opts["positionals"].append(arg)
        i += 1
    return opts


def main(argv):
    try:
        opts = parse_args(argv)
    except ValueError as e:
        print(f"error: {e}", file=sys.stderr)
        return 2
    if len(opts["positionals"]) < 2:
        print("error: the following required arguments were not provided:", file=sys.stderr)
        print("  <FIND>", file=sys.stderr)
        print("  <REPLACE_WITH>", file=sys.stderr)
        return 2
    find, repl, *files = opts["positionals"]
    try:
        if files:
            for path in files:
                try:
                    data = open(path, "r", encoding="utf-8", errors="surrogateescape").read()
                except OSError:
                    print(f"error: invalid path: {path}", file=sys.stderr)
                    return 1
                new = replace_text(data, find, repl, opts["fixed"], opts["limit"], opts["flags"])
                if opts["preview"]:
                    sys.stdout.write(new)
                else:
                    open(path, "w", encoding="utf-8", errors="surrogateescape").write(new)
        else:
            sys.stdout.write(replace_text(sys.stdin.read(), find, repl, opts["fixed"], opts["limit"], opts["flags"]))
    except ReplacementError as e:
        print(f"error: The numbered capture group `${e.group}` in the replacement text is ambiguous.", file=sys.stderr)
        print(f"hint: Use curly braces to disambiguate it `${{{e.group}}}{e.suffix}`.", file=sys.stderr)
        print(e.template, file=sys.stderr)
        print(" " * (e.start + 1) + "^" * (e.end - e.start - 1), file=sys.stderr)
        return 1
    except re.error as e:
        print(f"error: invalid regex {e}", file=sys.stderr)
        return 1
    return 0


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
