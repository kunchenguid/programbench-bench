#!/bin/bash
set -e
cp csview.py executable
chmod +x executable
