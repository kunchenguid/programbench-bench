#!/usr/bin/env python3
import os
import sys
import unicodedata


HELP = """A high performance csv viewer with cjk/emoji support.

Usage: executable [OPTIONS] [FILE]

Arguments:
  [FILE]
          File to view

Options:
  -H, --no-headers
          Specify that the input has no header row
  -n, --number
          Prepend a column of line numbers to the table
  -t, --tsv
          Use '\\t' as delimiter for tsv
  -d, --delimiter <DELIMITER>
          Specify the field delimiter [default: ,]
  -s, --style <STYLE>
          Specify the border style [default: sharp] [possible values: none, ascii, ascii2, sharp,
          rounded, reinforced, markdown, grid]
  -p, --padding <PADDING>
          Specify padding for table cell [default: 1]
  -i, --indent <INDENT>
          Specify global indent for table [default: 0]
      --sniff <LIMIT>
          Limit column widths sniffing to the specified number of rows. Specify "0" to cancel limit
          [default: 1000]
      --header-align <HEADER_ALIGN>
          Specify the alignment of the table header [default: center] [possible values: left,
          center, right]
      --body-align <BODY_ALIGN>
          Specify the alignment of the table body [default: left] [possible values: left, center,
          right]
  -P, --disable-pager
          Disable pager
  -h, --help
          Print help
  -V, --version
          Print version
"""


STYLES = {"none", "ascii", "ascii2", "sharp", "rounded", "reinforced", "markdown", "grid"}
ALIGNS = {"left", "center", "right"}


class CliError(Exception):
    def __init__(self, message, status=2):
        super().__init__(message)
        self.status = status


def cell_width(text):
    total = 0
    for ch in text:
        if unicodedata.combining(ch):
            continue
        if unicodedata.east_asian_width(ch) in ("W", "F"):
            total += 2
        elif 0x1F000 <= ord(ch) <= 0x1FAFF:
            total += 2
        else:
            total += 1
    return total


def truncate_width(text, limit):
    out = []
    used = 0
    for ch in text:
        w = cell_width(ch)
        if used + w > limit:
            break
        out.append(ch)
        used += w
    return "".join(out)


def align_text(text, width, align):
    text = truncate_width(text, width)
    extra = width - cell_width(text)
    if align == "right":
        return " " * extra + text
    if align == "center":
        left = extra // 2
        return " " * left + text + " " * (extra - left)
    return text + " " * extra


def parse_args(argv):
    opts = {
        "headers": True,
        "number": False,
        "delimiter": ",",
        "style": "sharp",
        "padding": 1,
        "indent": 0,
        "sniff": 1000,
        "header_align": "center",
        "body_align": "left",
        "file": None,
    }
    i = 0
    consumed_option = False
    while i < len(argv):
        arg = argv[i]
        if arg in ("-h", "--help"):
            print(HELP, end="")
            raise SystemExit(0)
        if arg in ("-V", "--version"):
            print("csview 1.3.4")
            raise SystemExit(0)
        if arg in ("-P", "--disable-pager"):
            consumed_option = True
            i += 1
            continue
        if arg in ("-H", "--no-headers"):
            consumed_option = True
            opts["headers"] = False
            i += 1
            continue
        if arg in ("-n", "--number"):
            consumed_option = True
            opts["number"] = True
            i += 1
            continue
        if arg in ("-t", "--tsv"):
            consumed_option = True
            opts["delimiter"] = "\t"
            i += 1
            continue
        if arg in ("-d", "--delimiter", "-s", "--style", "-p", "--padding", "-i", "--indent", "--sniff", "--header-align", "--body-align"):
            if i + 1 >= len(argv):
                raise CliError(f"error: a value is required for '{arg}' but none was supplied\n\nFor more information, try '--help'.")
            val = argv[i + 1]
            if arg in ("-d", "--delimiter"):
                consumed_option = True
                if len(val) != 1:
                    raise CliError(f"error: invalid value '{val}' for '--delimiter <DELIMITER>': too many characters in string\n\nFor more information, try '--help'.")
                opts["delimiter"] = val
            elif arg in ("-s", "--style"):
                consumed_option = True
                if val not in STYLES:
                    raise CliError(f"error: invalid value '{val}' for '--style <STYLE>'\n  [possible values: none, ascii, ascii2, sharp, rounded, reinforced, markdown, grid]\n\nFor more information, try '--help'.")
                opts["style"] = val
            elif arg in ("-p", "--padding"):
                consumed_option = True
                try:
                    opts["padding"] = int(val)
                except ValueError:
                    raise CliError(f"error: invalid value '{val}' for '--padding <PADDING>': invalid digit found in string\n\nFor more information, try '--help'.")
            elif arg in ("-i", "--indent"):
                consumed_option = True
                opts["indent"] = int(val)
            elif arg == "--sniff":
                consumed_option = True
                opts["sniff"] = int(val)
            elif arg == "--header-align":
                consumed_option = True
                if val not in ALIGNS:
                    raise CliError(f"error: invalid value '{val}' for '--header-align <HEADER_ALIGN>'\n  [possible values: left, center, right]\n\nFor more information, try '--help'.")
                opts["header_align"] = val
            elif arg == "--body-align":
                consumed_option = True
                if val not in ALIGNS:
                    raise CliError(f"error: invalid value '{val}' for '--body-align <BODY_ALIGN>'\n  [possible values: left, center, right]\n\nFor more information, try '--help'.")
                opts["body_align"] = val
            i += 2
            continue
        if arg.startswith("-"):
            usage = "executable <FILE|--no-headers|--number|--tsv|--delimiter <DELIMITER>|--style <STYLE>|--padding <PADDING>|--indent <INDENT>|--sniff <LIMIT>|--header-align <HEADER_ALIGN>|--body-align <BODY_ALIGN>|--disable-pager>" if consumed_option else "executable [OPTIONS] [FILE]"
            raise CliError(f"error: unexpected argument '{arg}' found\n\n  tip: to pass '{arg}' as a value, use '-- {arg}'\n\nUsage: {usage}\n\nFor more information, try '--help'.")
        if opts["file"] is not None:
            raise CliError(f"error: unexpected argument '{arg}' found\n\nUsage: executable [OPTIONS] [FILE]\n\nFor more information, try '--help'.")
        opts["file"] = arg
        i += 1
    return opts


def parse_delimited(text, delimiter):
    rows = []
    row = []
    field = []
    in_quotes = False
    i = 0
    while i < len(text):
        ch = text[i]
        if in_quotes:
            if ch == '"':
                if i + 1 < len(text) and text[i + 1] == '"':
                    field.append('"')
                    i += 2
                    continue
                in_quotes = False
            else:
                field.append(ch)
            i += 1
            continue
        if ch == '"':
            in_quotes = True
        elif ch == delimiter:
            row.append("".join(field))
            field = []
        elif ch == "\n":
            row.append("".join(field))
            if any(c != "" for c in row):
                rows.append(row)
            row = []
            field = []
        elif ch == "\r":
            pass
        else:
            field.append(ch)
        i += 1
    if field or row:
        row.append("".join(field))
        if any(c != "" for c in row):
            rows.append(row)
    if not rows:
        return [[]]
    expected = len(rows[0])
    for idx, r in enumerate(rows[1:], start=1):
        if len(r) != expected:
            raise ValueError(f"CSV error: record {idx} (line: {idx + 1}, byte: 0): found record with {len(r)} fields, but the previous record has {expected} fields")
    return rows


def borders(style):
    if style == "ascii":
        return dict(tl="+", tr="+", bl="+", br="+", h="-", v="|", tj="+", bj="+", lj="+", rj="+", x="+")
    if style == "rounded":
        return dict(tl="╭", tr="╮", bl="╰", br="╯", h="─", v="│", tj="┬", bj="┴", lj="├", rj="┤", x="┼")
    if style == "reinforced":
        return dict(tl="┏", tr="┓", bl="┗", br="┛", h="─", v="│", tj="┬", bj="┴", lj="├", rj="┤", x="┼")
    return dict(tl="┌", tr="┐", bl="└", br="┘", h="─", v="│", tj="┬", bj="┴", lj="├", rj="┤", x="┼")


def line(widths, b, left, mid, right):
    return left + mid.join(b["h"] * w for w in widths) + right


def render_row(row, widths, pad, sep, align):
    cells = []
    for value, width in zip(row, widths):
        inner = align_text(value, max(0, width - 2 * pad), align)
        cells.append(" " * pad + inner + " " * pad)
    return sep + sep.join(cells) + sep


def render(rows, opts):
    if opts["number"]:
        start = 1
        if opts["headers"]:
            rows = [[ "#", *rows[0] ]] + [[str(i), *r] for i, r in enumerate(rows[1:], start=start)]
        else:
            rows = [[str(i), *r] for i, r in enumerate(rows, start=start)]
    empty_table = rows == [[]]
    header = rows[0] if opts["headers"] and not empty_table else None
    body = rows[1:] if opts["headers"] and not empty_table else rows
    sniff_body = body if opts["sniff"] == 0 else body[: opts["sniff"]]
    width_rows = ([] if header is None else [header]) + sniff_body
    cols = max((len(r) for r in rows), default=1)
    raw_widths = []
    for c in range(cols):
        raw_widths.append(max([cell_width(r[c]) if c < len(r) else 0 for r in width_rows] or [0]))
    widths = [w + 2 * opts["padding"] for w in raw_widths]
    style = opts["style"]
    indent = " " * opts["indent"]
    out = []
    if style == "none":
        for r in rows:
            out.append(indent + "".join((" " * opts["padding"] + align_text(r[c] if c < len(r) else "", raw_widths[c], opts["body_align"]) + " " * opts["padding"]) for c in range(cols)))
        return "\n".join(out) + "\n"
    if style == "ascii2":
        if header is not None:
            out.append(indent + " " + render_row(header, widths, opts["padding"], "|", opts["header_align"])[1:-1] + " ")
            out.append(indent + " " + "+".join("-" * w for w in widths) + " ")
        for r in body:
            out.append(indent + " " + render_row(r, widths, opts["padding"], "|", opts["body_align"])[1:-1] + " ")
        return "\n".join(out) + "\n"
    if style == "markdown":
        if header is None:
            for r in body:
                out.append(indent + render_row(r, widths, opts["padding"], "|", opts["body_align"]))
        else:
            out.append(indent + render_row(header, widths, opts["padding"], "|", opts["header_align"]))
            out.append(indent + "|" + "|".join("-" * w for w in widths) + "|")
            for r in body:
                out.append(indent + render_row(r, widths, opts["padding"], "|", opts["body_align"]))
        return "\n".join(out) + "\n"
    b = borders(style)
    out.append(indent + line(widths, b, b["tl"], b["tj"], b["tr"]))
    if header is not None:
        out.append(indent + render_row(header, widths, opts["padding"], b["v"], opts["header_align"]))
        if style != "grid":
            out.append(indent + line(widths, b, b["lj"], b["x"], b["rj"]))
    for idx, r in enumerate(body):
        if style == "grid" and (header is not None or idx > 0):
            out.append(indent + line(widths, b, b["lj"], b["x"], b["rj"]))
        out.append(indent + render_row(r, widths, opts["padding"], b["v"], opts["body_align"]))
    out.append(indent + line(widths, b, b["bl"], b["bj"], b["br"]))
    return "\n".join(out) + "\n"


def main():
    try:
        opts = parse_args(sys.argv[1:])
    except CliError as e:
        print(str(e), file=sys.stderr)
        return e.status
    if opts["file"]:
        try:
            with open(opts["file"], "r", encoding="utf-8", newline="") as f:
                text = f.read()
        except OSError as e:
            print(f"csview: {e.strerror} (os error {e.errno})", file=sys.stderr)
            return 1
    else:
        text = sys.stdin.read()
    try:
        rows = parse_delimited(text, opts["delimiter"])
    except ValueError as e:
        print(f"csview: {e}", file=sys.stderr)
        return 1
    sys.stdout.write(render(rows, opts))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
