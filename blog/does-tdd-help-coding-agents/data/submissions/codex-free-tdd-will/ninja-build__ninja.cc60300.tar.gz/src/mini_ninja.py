#!/usr/bin/env python3
import json
import os
import shlex
import subprocess
import sys
from dataclasses import dataclass, field
from pathlib import Path


VERSION = "1.14.0.git"


HELP = """usage: ninja [options] [targets...]

if targets are unspecified, builds the 'default' target (see manual).

options:
  --version      print ninja version ("1.14.0.git")
  -v, --verbose  show all command lines while building
  --quiet        don't show progress status, just command output

  -C DIR   change to DIR before doing anything else
  -f FILE  specify input build file [default=build.ninja]

  -j N     run N jobs in parallel (0 means infinity) [default=6 on this system]
  -k N     keep going until N jobs fail (0 means infinity) [default=1]
  -l N     do not start new jobs if the load average is greater than N
  -n       dry run (don't run commands but act like they succeeded)

  -d MODE  enable debugging (use '-d list' to list modes)
  -t TOOL  run a subtool (use '-t list' to list subtools)
    terminates toplevel options; further flags are passed to the tool
  -w FLAG  adjust warnings (use '-w list' to list warnings)
"""


TOOL_LIST = """ninja subtools:
     browse  browse dependency graph in a web browser
      clean  clean built files
   commands  list all commands required to rebuild given targets
     inputs  list all inputs required to rebuild given targets
multi-inputs  print one or more sets of inputs required to build targets
       deps  show dependencies stored in the deps log
missingdeps  check deps log dependencies on generated files
      graph  output graphviz dot file for targets
      query  show inputs/outputs for a path
    targets  list targets by their rule or depth in the DAG
     compdb  dump JSON compilation database to stdout
compdb-targets  dump JSON compilation database for a given list of targets to stdout
  recompact  recompacts ninja-internal data structures
     restat  restats all outputs in the build log
      rules  list all rules
  cleandead  clean built files that are no longer produced by the manifest
"""


@dataclass
class Rule:
    name: str
    vars: dict = field(default_factory=dict)


@dataclass
class Edge:
    outputs: list
    implicit_outputs: list
    rule: str
    inputs: list
    implicit: list = field(default_factory=list)
    order_only: list = field(default_factory=list)
    vars: dict = field(default_factory=dict)
    file_vars: dict = field(default_factory=dict)

    def all_outputs(self):
        return self.outputs + self.implicit_outputs

    def all_inputs(self):
        return self.inputs + self.implicit + self.order_only


class Manifest:
    def __init__(self):
        self.rules = {"phony": Rule("phony", {"command": ""})}
        self.edges = []
        self.by_output = {}
        self.defaults = []
        self.vars = {}

    def add_edge(self, e):
        self.edges.append(e)
        for out in e.all_outputs():
            self.by_output[out] = e


def strip_comment(line):
    escaped = False
    for i, ch in enumerate(line):
        if ch == "$":
            escaped = not escaped
            continue
        if ch == "#" and not escaped:
            return line[:i]
        escaped = False
    return line


def logical_lines(text):
    raw = text.splitlines()
    out = []
    cur = ""
    for line in raw:
        if cur:
            line = line.lstrip(" \t")
        if line.endswith("$"):
            cur += line[:-1]
            continue
        out.append(cur + line)
        cur = ""
    if cur:
        out.append(cur)
    return out


def expand(s, scopes, path_mode=False):
    res = []
    i = 0
    while i < len(s):
        ch = s[i]
        if ch != "$":
            res.append(ch)
            i += 1
            continue
        i += 1
        if i >= len(s):
            res.append("$")
            break
        c = s[i]
        if c == "$":
            res.append("$")
            i += 1
        elif c == " ":
            res.append(" ")
            i += 1
        elif c == ":":
            res.append(":")
            i += 1
        elif c == "^":
            res.append("\n")
            i += 1
        elif c == "{":
            j = s.find("}", i + 1)
            if j < 0:
                name = s[i + 1 :]
                i = len(s)
            else:
                name = s[i + 1 : j]
                i = j + 1
            res.append(lookup(name, scopes))
        else:
            j = i
            while j < len(s) and (s[j].isalnum() or s[j] in "_.-"):
                j += 1
            name = s[i:j]
            if not name:
                res.append("$" + c)
                i += 1
            else:
                res.append(lookup(name, scopes))
                i = j
    return "".join(res)


def lookup(name, scopes):
    for scope in scopes:
        if name in scope:
            return scope[name]
    return ""


def split_words(s):
    words, cur = [], []
    i = 0
    while i < len(s):
        c = s[i]
        if c in " \t":
            if cur:
                words.append("".join(cur))
                cur = []
            i += 1
        elif c == "$" and i + 1 < len(s):
            n = s[i + 1]
            if n == " ":
                cur.append(" ")
                i += 2
            elif n == ":":
                cur.append(":")
                i += 2
            elif n == "$":
                cur.append("$")
                i += 2
            else:
                cur.append(c)
                i += 1
        else:
            cur.append(c)
            i += 1
    if cur:
        words.append("".join(cur))
    return words


def parse_file(path, manifest=None, parent_vars=None):
    manifest = manifest or Manifest()
    file_vars = dict(parent_vars or {})
    file_vars.update(manifest.vars)
    lines = logical_lines(Path(path).read_text())
    i = 0
    base = Path(path).parent
    while i < len(lines):
        raw = lines[i]
        line = strip_comment(raw).rstrip()
        i += 1
        if not line.strip():
            continue
        if line[0] in " \t":
            continue
        if line.startswith("rule "):
            name = line.split(None, 1)[1].strip()
            rule_vars = {}
            while i < len(lines) and (lines[i].startswith(" ") or lines[i].startswith("\t")):
                sub = strip_comment(lines[i]).strip()
                i += 1
                if not sub or "=" not in sub:
                    continue
                k, v = sub.split("=", 1)
                rule_vars[k.strip()] = v.lstrip()
            manifest.rules[name] = Rule(name, rule_vars)
        elif line.startswith("build "):
            rest = line[6:].strip()
            left, right = split_build(rest)
            outputs, implicit_outputs = parse_outputs(left, [file_vars])
            parts = split_words(right)
            if not parts:
                die(f"ninja: error: {path}: expected build command name")
            rule = parts[0]
            deps = parse_deps(parts[1:], [file_vars])
            e = Edge(outputs, implicit_outputs, rule, deps[0], deps[1], deps[2], {}, dict(file_vars))
            while i < len(lines) and (lines[i].startswith(" ") or lines[i].startswith("\t")):
                sub = strip_comment(lines[i]).strip()
                i += 1
                if not sub or "=" not in sub:
                    continue
                k, v = sub.split("=", 1)
                e.vars[k.strip()] = expand(v.lstrip(), [e.vars, file_vars])
            manifest.add_edge(e)
        elif line.startswith("default "):
            for w in split_words(line[8:].strip()):
                manifest.defaults.append(expand(w, [file_vars]))
        elif line.startswith("include ") or line.startswith("subninja "):
            inc = expand(line.split(None, 1)[1].strip(), [file_vars])
            parse_file(base / inc, manifest, file_vars)
        elif "=" in line:
            k, v = line.split("=", 1)
            file_vars[k.strip()] = expand(v.lstrip(), [file_vars])
            manifest.vars[k.strip()] = file_vars[k.strip()]
        else:
            die(f"ninja: error: {path}: unknown statement: {line}")
    return manifest


def split_build(rest):
    i = 0
    while i < len(rest):
        if rest[i] == "$":
            i += 2
            continue
        if rest[i] == ":":
            return rest[:i].strip(), rest[i + 1 :].strip()
        i += 1
    die("ninja: error: expected ':' in build statement")


def parse_outputs(left, scopes):
    exp, imp = [], []
    cur = exp
    for w in split_words(left):
        if w == "|":
            cur = imp
        else:
            cur.append(expand(w, scopes))
    return exp, imp


def parse_deps(parts, scopes):
    explicit, implicit, order = [], [], []
    cur = explicit
    i = 0
    while i < len(parts):
        p = parts[i]
        if p == "|":
            cur = implicit
        elif p == "||":
            cur = order
        elif p == "|@":
            cur = order
        else:
            cur.append(expand(p, scopes))
        i += 1
    return explicit, implicit, order


def edge_command(manifest, edge):
    rule = manifest.rules.get(edge.rule)
    if not rule:
        die(f"ninja: error: unknown build rule '{edge.rule}'")
    specials = {
        "in": shell_join(edge.inputs),
        "out": shell_join(edge.outputs),
        "in_newline": "\n".join(edge.inputs),
    }
    scopes = [specials, edge.vars, rule.vars, edge.file_vars, manifest.vars]
    cmd = expand_deep(rule.vars.get("command", ""), scopes)
    desc = expand_deep(rule.vars.get("description", cmd), scopes)
    return cmd, desc


def edge_var(manifest, edge, name):
    rule = manifest.rules.get(edge.rule)
    if not rule:
        return ""
    specials = {
        "in": shell_join(edge.inputs),
        "out": shell_join(edge.outputs),
        "in_newline": "\n".join(edge.inputs),
    }
    return expand_deep(rule.vars.get(name, edge.vars.get(name, "")), [specials, edge.vars, rule.vars, edge.file_vars, manifest.vars])


def expand_deep(value, scopes):
    cur = value
    for _ in range(10):
        nxt = expand(cur, scopes)
        if nxt == cur:
            return nxt
        cur = nxt
    return cur


def shell_join(items):
    return " ".join(shlex.quote(x) for x in items)


def default_targets(m):
    if m.defaults:
        return m.defaults
    inputs = set()
    for e in m.edges:
        inputs.update(e.all_inputs())
    roots = []
    for e in m.edges:
        for out in e.outputs:
            if out not in inputs:
                roots.append(out)
    return roots


def collect(m, targets, allow_missing_sources=False):
    seen_edges = set()
    order = []
    visiting = set()

    def visit_node(n, consumer=None):
        e = m.by_output.get(n)
        if not e:
            if not Path(n).exists():
                if allow_missing_sources:
                    return
                if consumer:
                    die(f"ninja: error: '{n}', needed by '{consumer}', missing and no known rule to make it")
                die(f"ninja: error: unknown target '{n}'")
            return
        visit_edge(e)

    def visit_edge(e):
        eid = id(e)
        if eid in seen_edges:
            return
        if eid in visiting:
            die("ninja: error: dependency cycle")
        visiting.add(eid)
        for dep in e.all_inputs():
            visit_node(dep, e.outputs[0] if e.outputs else None)
        visiting.remove(eid)
        seen_edges.add(eid)
        order.append(e)

    for t in targets:
        if t.endswith("^"):
            src = t[:-1]
            matches = [e.outputs[0] for e in m.edges if src in e.inputs and e.outputs]
            if matches:
                t = matches[0]
        visit_node(t)
    return order


def load_log():
    p = Path(".mini_ninja_log")
    if p.exists():
        try:
            return json.loads(p.read_text())
        except Exception:
            return {}
    return {}


def load_deps():
    p = Path(".mini_ninja_deps")
    if p.exists():
        try:
            return json.loads(p.read_text())
        except Exception:
            return {}
    return {}


def save_log(log):
    Path(".mini_ninja_log").write_text(json.dumps(log, sort_keys=True))


def save_deps(deps):
    Path(".mini_ninja_deps").write_text(json.dumps(deps, sort_keys=True))


def parse_depfile(path):
    p = Path(path)
    if not p.exists():
        return []
    text = p.read_text(errors="ignore").replace("\\\n", " ")
    if ":" in text:
        text = text.split(":", 1)[1]
    return [x for x in split_words(text.replace("\n", " ")) if x]


def dirty(m, e, log):
    if e.rule == "phony":
        return any((dep in m.by_output and dirty(m, m.by_output[dep], log)) or not Path(dep).exists() for dep in e.all_inputs())
    outs = e.all_outputs()
    if not outs:
        return True
    if any(not Path(o).exists() for o in outs):
        return True
    out_m = min(Path(o).stat().st_mtime_ns for o in outs)
    for dep in e.inputs + e.implicit:
        if Path(dep).exists() and Path(dep).stat().st_mtime_ns > out_m:
            return True
    depdb = load_deps()
    for dep in depdb.get(e.outputs[0], []):
        if Path(dep).exists() and Path(dep).stat().st_mtime_ns > out_m:
            return True
    cmd, _ = edge_command(m, e)
    return any(log.get(o) != cmd for o in outs)


def build(m, targets, opts):
    edges = collect(m, targets)
    log = load_log()
    depdb = load_deps()
    todo = [e for e in edges if dirty(m, e, log)]
    real = [e for e in todo if e.rule != "phony"]
    if not real:
        print("ninja: no work to do.")
        return 0
    total = len(real)
    done = 0
    for e in todo:
        if e.rule == "phony":
            continue
        cmd, desc = edge_command(m, e)
        done += 1
        for out in e.all_outputs():
            parent = Path(out).parent
            if str(parent) != ".":
                parent.mkdir(parents=True, exist_ok=True)
        if not opts["quiet"]:
            text = cmd if opts["verbose"] or opts["dry"] else desc
            sys.stdout.write(f"[{done}/{total}] {text}\n")
            sys.stdout.flush()
        rspfile = edge_var(m, e, "rspfile")
        if rspfile and not opts["dry"]:
            Path(rspfile).write_text(edge_var(m, e, "rspfile_content"))
        if not opts["dry"]:
            proc = subprocess.run(cmd, shell=True, text=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
            if proc.returncode != 0:
                sys.stdout.write(cmd + "\n")
                sys.stdout.write(proc.stdout)
                return proc.returncode
            if proc.stdout:
                sys.stdout.write(proc.stdout)
            depfile = edge_var(m, e, "depfile")
            if depfile and e.outputs:
                depdb[e.outputs[0]] = parse_depfile(depfile)
            if rspfile and Path(rspfile).exists():
                Path(rspfile).unlink()
            for out in e.all_outputs():
                log[out] = cmd
    if not opts["dry"]:
        save_log(log)
        save_deps(depdb)
    return 0


def tool(m, args, opts):
    name = args[0] if args else "list"
    rest = args[1:]
    if name == "list":
        sys.stdout.write(TOOL_LIST)
    elif name == "rules":
        for r in sorted(m.rules):
            print(r)
    elif name == "targets":
        mode = rest[0] if rest else "depth"
        val = rest[1] if len(rest) > 1 else ("1" if mode == "depth" else "")
        if mode == "all":
            for e in m.edges:
                for out in e.outputs:
                    print(out)
        elif mode == "rule":
            for e in m.edges:
                if e.rule == val:
                    print(e.outputs[0])
        else:
            roots = default_targets(m)
            maxd = int(val) if str(val).isdigit() else 1
            def rec(t, depth):
                e = m.by_output.get(t)
                if e:
                    print("  " * depth + f"{t}: {e.rule}")
                    if maxd == 0 or depth + 1 < maxd:
                        for dep in e.all_inputs():
                            rec(dep, depth + 1)
                else:
                    print("  " * depth + t)
            for r in roots:
                rec(r, 0)
    elif name == "query":
        for q in rest:
            e = m.by_output.get(q)
            if not e:
                print(f"{q}:")
                print("  no known rule to make it")
            else:
                print(f"{q}:")
                print(f"  input: {e.rule}")
                for dep in e.all_inputs():
                    print(f"    {dep}")
                print("  outputs:")
                for out in e.all_outputs():
                    if out != q:
                        print(f"    {out}")
    elif name == "commands":
        short = False
        if rest and rest[0] == "-s":
            short, rest = True, rest[1:]
        edges = collect(m, rest or default_targets(m), allow_missing_sources=True)
        if short and edges:
            edges = [edges[-1]]
        for e in edges:
            if e.rule != "phony":
                print(edge_command(m, e)[0])
    elif name in ("inputs", "multi-inputs"):
        targets = [x for x in rest if not x.startswith("-")] or default_targets(m)
        inputs = []
        for e in collect(m, targets, allow_missing_sources=True):
            inputs.extend(e.all_inputs())
        if name == "multi-inputs":
            for t in targets:
                for i in sorted(set(inputs)):
                    print(f"{t}\t{i}")
        else:
            for i in sorted(set(inputs)):
                print(shlex.quote(i))
    elif name == "clean":
        count = 0
        dry = opts["dry"]
        chosen = set(rest)
        edges = m.edges if not chosen else [m.by_output[t] for t in chosen if t in m.by_output]
        for e in edges:
            if e.rule == "phony":
                continue
            for out in e.all_outputs():
                p = Path(out)
                if p.exists():
                    if opts["verbose"] or dry:
                        print(f"Remove {out}")
                    if not dry:
                        p.unlink()
                    count += 1
        print(f"Cleaning... {count} files.")
    elif name == "compdb":
        rules = set(x for x in rest if x != "-x")
        rows = []
        for e in m.edges:
            if not rules or e.rule in rules:
                cmd, _ = edge_command(m, e)
                if e.inputs:
                    rows.append({"directory": str(Path.cwd()), "command": cmd, "file": e.inputs[0], "output": e.outputs[0] if e.outputs else ""})
        print(json.dumps(rows, indent=2))
    elif name in ("deps", "missingdeps", "recompact", "restat", "cleandead"):
        return 0
    else:
        die(f"ninja: fatal: unknown tool '{name}'")
    return 0


def parse_args(argv):
    opts = {"file": "build.ninja", "verbose": False, "quiet": False, "dry": False, "tool": None}
    targets = []
    i = 0
    while i < len(argv):
        a = argv[i]
        if a in ("--help", "-h"):
            opts["help"] = True
        elif a == "--version":
            opts["version"] = True
        elif a in ("-v", "--verbose"):
            opts["verbose"] = True
        elif a == "--quiet":
            opts["quiet"] = True
        elif a == "-n" or a == "--dry-run":
            opts["dry"] = True
            opts["verbose"] = True
        elif a == "-C":
            i += 1
            print(f"ninja: Entering directory `{argv[i]}'")
            os.chdir(argv[i])
        elif a.startswith("-C") and len(a) > 2:
            print(f"ninja: Entering directory `{a[2:]}'")
            os.chdir(a[2:])
        elif a == "-f":
            i += 1
            opts["file"] = argv[i]
        elif a.startswith("-f") and len(a) > 2:
            opts["file"] = a[2:]
        elif a == "-t":
            opts["tool"] = argv[i + 1 :]
            break
        elif a in ("-j", "-k", "-l", "-d", "-w"):
            i += 1
            if a == "-d" and i < len(argv) and argv[i] == "list":
                print("debugging modes:\n  stats        print operation counts/timing info\n  explain      explain what caused a command to execute\n  keepdepfile  don't delete depfiles after they're read by ninja\n  keeprsp      don't delete @response files on success\nmultiple modes can be enabled via -d FOO -d BAR")
                raise SystemExit(0)
            if a == "-w" and i < len(argv) and argv[i] == "list":
                print("warning flags:\n  phonycycle={err,warn}  phony build statement references itself")
                raise SystemExit(0)
        elif a.startswith("-j") or a.startswith("-k") or a.startswith("-l"):
            pass
        else:
            targets.append(a)
        i += 1
    return opts, targets


def die(msg):
    print(msg, file=sys.stderr)
    raise SystemExit(1)


def main(argv=None):
    argv = sys.argv[1:] if argv is None else argv
    opts, targets = parse_args(argv)
    if opts.get("version"):
        print(VERSION)
        return 0
    if opts.get("help"):
        sys.stdout.write(HELP)
        return 0
    if opts.get("tool") == ["list"]:
        sys.stdout.write(TOOL_LIST)
        return 0
    m = parse_file(opts["file"])
    if opts.get("tool") is not None:
        return tool(m, opts["tool"], opts)
    return build(m, targets or default_targets(m), opts)


if __name__ == "__main__":
    raise SystemExit(main())
