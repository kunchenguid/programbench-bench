#!/bin/bash
set -e
cp src/mini_ninja.py executable
chmod +x executable
