import os
import shutil
import subprocess
import tempfile
import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
EXE = ROOT / "executable"


def run(args, cwd, env=None):
    proc = subprocess.run(
        [str(EXE), *args],
        cwd=cwd,
        text=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        env={**os.environ, **(env or {})},
    )
    return proc.returncode, proc.stdout


def case():
    d = tempfile.mkdtemp(prefix="mini-ninja-test-")
    return Path(d)


class NinjaTests(unittest.TestCase):
  def test_help_and_version(self):
    d = case()
    try:
        code, out = run(["--version"], d)
        self.assertEqual(code, 0)
        self.assertEqual(out, "1.14.0.git\n")
        code, out = run(["--help"], d)
        self.assertEqual(code, 0)
        self.assertIn("usage: ninja [options] [targets...]", out)
        self.assertIn("-t TOOL", out)
    finally:
        shutil.rmtree(d)


  def test_simple_build_and_no_work(self):
    d = case()
    try:
        (d / "build.ninja").write_text(
            "rule touch\n"
            "  command = touch $out\n"
            "\n"
            "build output.txt: touch\n"
        )
        code, out = run([], d)
        self.assertEqual(code, 0)
        self.assertEqual("[1/1] touch output.txt\n", out)
        self.assertTrue((d / "output.txt").exists())

        code, out = run([], d)
        self.assertEqual(code, 0)
        self.assertEqual(out, "ninja: no work to do.\n")
    finally:
        shutil.rmtree(d)

  def test_variables_defaults_dry_run_and_commands_tool(self):
    d = case()
    try:
        (d / "in.txt").write_text("hello\n")
        (d / "build.ninja").write_text(
            "prefix = TOP\n"
            "rule copy\n"
            "  command = printf \"$prefix:$in\" > $out\n"
            "  description = COPY $out\n"
            "build mid.txt: copy in.txt\n"
            "  prefix = LOCAL\n"
            "build final.txt: copy mid.txt\n"
            "default final.txt\n"
        )
        code, out = run(["-n"], d)
        self.assertEqual(code, 0)
        self.assertEqual(
            out,
            "[1/2] printf \"LOCAL:in.txt\" > mid.txt\n"
            "[2/2] printf \"TOP:mid.txt\" > final.txt\n",
        )

        code, out = run(["-t", "commands", "final.txt"], d)
        self.assertEqual(code, 0)
        self.assertEqual(
            out,
            "printf \"LOCAL:in.txt\" > mid.txt\n"
            "printf \"TOP:mid.txt\" > final.txt\n",
        )

        code, out = run([], d)
        self.assertEqual(code, 0)
        self.assertEqual(out, "[1/2] COPY mid.txt\n[2/2] COPY final.txt\n")
        self.assertEqual((d / "final.txt").read_text(), "TOP:mid.txt")
    finally:
        shutil.rmtree(d)

  def test_include_phony_clean_and_missing_input_errors(self):
    d = case()
    try:
        (d / "rules.ninja").write_text(
            "rule make\n"
            "  command = mkdir -p dir && echo $in > $out\n"
        )
        (d / "source").write_text("x")
        (d / "build.ninja").write_text(
            "include rules.ninja\n"
            "build dir/out: make source\n"
            "build all: phony dir/out\n"
            "default all\n"
        )
        code, out = run([], d)
        self.assertEqual(code, 0)
        self.assertIn("[1/1] mkdir -p dir && echo source > dir/out\n", out)
        self.assertEqual((d / "dir/out").read_text(), "source\n")

        code, out = run(["-t", "clean"], d)
        self.assertEqual(code, 0)
        self.assertIn("Cleaning... 1 files.", out)
        self.assertFalse((d / "dir/out").exists())

        (d / "build.ninja").write_text(
            "include rules.ninja\n"
            "build broken: make missing\n"
            "default broken\n"
        )
        code, out = run([], d)
        self.assertNotEqual(code, 0)
        self.assertIn("'missing', needed by 'broken', missing and no known rule to make it", out)
    finally:
        shutil.rmtree(d)

  def test_rule_variables_expand_late_and_recursively(self):
    d = case()
    try:
        (d / "a").write_text("")
        (d / "build.ninja").write_text(
            "rule r\n"
            "  command = $launcher $msg $in > $out\n"
            "  launcher = echo\n"
            "  msg = $word\n"
            "build out: r a\n"
            "  word = edge\n"
        )
        code, out = run([], d)
        self.assertEqual(code, 0)
        self.assertEqual((d / "out").read_text(), "edge a\n")
    finally:
        shutil.rmtree(d)


if __name__ == "__main__":
    unittest.main()
