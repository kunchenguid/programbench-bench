#!/usr/bin/env python3
import os
import subprocess
import tempfile
import unittest


ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
EXE = os.path.join(ROOT, "executable")


def run_cmd(args, cwd=None):
    return subprocess.run(args, cwd=cwd, text=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)


def run_cmd_with_input(args, text, cwd=None):
    return subprocess.run(
        args,
        input=text,
        cwd=cwd,
        text=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
    )


class KeifuCliTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        result = run_cmd(["bash", "compile.sh"], cwd=ROOT)
        assert result.returncode == 0, result.stderr

    def test_help_matches_documented_cli(self):
        result = run_cmd([EXE, "--help"], cwd=ROOT)
        self.assertEqual(result.returncode, 0)
        self.assertEqual(
            result.stdout,
            "A TUI tool to visualize Git commit graphs with branch genealogy\n"
            "\n"
            "Usage: executable\n"
            "\n"
            "Options:\n"
            "  -h, --help     Print help\n"
            "  -V, --version  Print version\n",
        )
        self.assertEqual(result.stderr, "")

    def test_version_matches_release(self):
        result = run_cmd([EXE, "-V"], cwd=ROOT)
        self.assertEqual(result.returncode, 0)
        self.assertEqual(result.stdout, "keifu 0.2.3\n")
        self.assertEqual(result.stderr, "")

    def test_unexpected_argument_uses_clap_style_error(self):
        result = run_cmd([EXE, "--bad"], cwd=ROOT)
        self.assertEqual(result.returncode, 2)
        self.assertEqual(result.stdout, "")
        self.assertEqual(
            result.stderr,
            "error: unexpected argument '--bad' found\n"
            "\n"
            "Usage: executable\n"
            "\n"
            "For more information, try '--help'.\n",
        )

    def test_outside_git_repository_reports_repository_error(self):
        with tempfile.TemporaryDirectory() as tmp:
            result = run_cmd([EXE], cwd=tmp)
        self.assertEqual(result.returncode, 1)
        self.assertEqual(result.stdout, "")
        self.assertEqual(
            result.stderr,
            "Error: Git repository not found. Please run inside a Git repository.\n"
            "\n"
            "Caused by:\n"
            "    could not find repository at '.'; class=Repository (6); code=NotFound (-3)\n",
        )

    def test_git_repository_without_tty_reports_original_terminal_error(self):
        with tempfile.TemporaryDirectory() as tmp:
            run_cmd(["git", "init", "-q"], cwd=tmp)
            run_cmd(["git", "config", "user.email", "a@example.test"], cwd=tmp)
            run_cmd(["git", "config", "user.name", "Alice"], cwd=tmp)
            with open(os.path.join(tmp, "file.txt"), "w", encoding="utf-8") as f:
                f.write("hello\n")
            run_cmd(["git", "add", "file.txt"], cwd=tmp)
            run_cmd(["git", "commit", "-q", "-m", "initial commit"], cwd=tmp)
            result = run_cmd([EXE], cwd=tmp)
        self.assertEqual(result.returncode, 1)
        self.assertEqual(result.stdout, "")
        self.assertEqual(result.stderr, "Error: No such device or address (os error 6)\n")

    def test_terminal_view_renders_git_commit_data(self):
        with tempfile.TemporaryDirectory() as tmp:
            run_cmd(["git", "init", "-q"], cwd=tmp)
            run_cmd(["git", "config", "user.email", "a@example.test"], cwd=tmp)
            run_cmd(["git", "config", "user.name", "Alice"], cwd=tmp)
            with open(os.path.join(tmp, "file.txt"), "w", encoding="utf-8") as f:
                f.write("hello\n")
            run_cmd(["git", "add", "file.txt"], cwd=tmp)
            run_cmd(["git", "commit", "-q", "-m", "initial commit"], cwd=tmp)
            result = run_cmd_with_input(
                [
                    "script",
                    "-q",
                    "-c",
                    f"bash -lc 'stty rows 30 cols 100; {EXE}'",
                    "/dev/null",
                ],
                "q",
                cwd=tmp,
            )
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertIn("keifu", result.stdout)
        self.assertIn("Alice", result.stdout)
        self.assertIn("initial commit", result.stdout)
        self.assertIn("file.txt", result.stdout)


if __name__ == "__main__":
    unittest.main()
