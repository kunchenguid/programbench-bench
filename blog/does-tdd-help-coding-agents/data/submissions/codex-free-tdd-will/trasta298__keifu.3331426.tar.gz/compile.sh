#!/bin/bash
set -e
rm -f executable
cp keifu.py executable
chmod +x executable
