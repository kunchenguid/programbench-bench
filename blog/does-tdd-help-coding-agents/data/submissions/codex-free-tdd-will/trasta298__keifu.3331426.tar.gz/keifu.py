#!/usr/bin/env python3
import os
import subprocess
import sys


HELP = """A TUI tool to visualize Git commit graphs with branch genealogy

Usage: executable

Options:
  -h, --help     Print help
  -V, --version  Print version
"""


def eprint(text: str) -> None:
    sys.stderr.write(text)


def run_git(args, cwd=None, check=False):
    return subprocess.run(
        ["git", *args],
        cwd=cwd,
        text=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        check=check,
    )


def is_git_repository() -> bool:
    proc = run_git(["rev-parse", "--git-dir"])
    return proc.returncode == 0


def parse_args(argv):
    if not argv:
        return "run"
    if len(argv) == 1 and argv[0] in ("-h", "--help"):
        return "help"
    if len(argv) == 1 and argv[0] in ("-V", "--version"):
        return "version"
    bad = argv[0]
    eprint(f"error: unexpected argument '{bad}' found\n\n")
    eprint("Usage: executable\n\n")
    eprint("For more information, try '--help'.\n")
    return "arg_error"


def repository_error() -> int:
    eprint("Error: Git repository not found. Please run inside a Git repository.\n\n")
    eprint("Caused by:\n")
    eprint("    could not find repository at '.'; class=Repository (6); code=NotFound (-3)\n")
    return 1


def no_tty_error() -> int:
    eprint("Error: No such device or address (os error 6)\n")
    return 1


def collect_commits():
    fmt = "%h%x09%H%x09%ad%x09%an%x09%d%x09%s"
    proc = run_git(
        [
            "log",
            "--all",
            "--max-count=500",
            "--date=short",
            f"--pretty=format:{fmt}",
        ]
    )
    if proc.returncode != 0:
        return []
    commits = []
    for line in proc.stdout.splitlines():
        parts = line.split("\t", 5)
        if len(parts) != 6:
            continue
        short, full, date, author, decorations, subject = parts
        labels = []
        decorations = decorations.strip()
        if decorations.startswith("(") and decorations.endswith(")"):
            for item in decorations[1:-1].split(","):
                item = item.strip()
                if item.startswith("HEAD -> "):
                    labels.append(item[8:])
                elif item.startswith("tag: "):
                    labels.append(item)
                elif item:
                    labels.append(item)
        commits.append(
            {
                "short": short,
                "full": full,
                "date": date,
                "author": author,
                "labels": labels,
                "subject": subject,
            }
        )
    return commits


def changed_files(commit):
    parent = run_git(["rev-list", "--parents", "-n", "1", commit])
    if parent.returncode != 0:
        return []
    ids = parent.stdout.strip().split()
    if len(ids) > 1:
        diff_args = ["diff", "--numstat", ids[1], commit]
    else:
        diff_args = ["diff-tree", "--root", "--numstat", "--no-commit-id", "-r", commit]
    proc = run_git(diff_args)
    if proc.returncode != 0:
        return []
    rows = []
    for line in proc.stdout.splitlines()[:50]:
        fields = line.split("\t")
        if len(fields) >= 3:
            rows.append((fields[0], fields[1], fields[2]))
    return rows


def has_uncommitted_changes():
    proc = run_git(["status", "--porcelain", "--untracked-files=no"])
    return proc.returncode == 0 and bool(proc.stdout.strip())


def draw_screen(commits):
    width = 100
    try:
        width = os.get_terminal_size().columns
    except OSError:
        pass

    lines = ["keifu"]
    lines.append("q/Esc quit  j/k move  Enter checkout  b branch  d delete  f fetch  ? help")
    lines.append("")
    if has_uncommitted_changes():
        lines.append("●  uncommitted changes")
    if not commits:
        lines.append("No commits found")
    for i, commit in enumerate(commits[:40]):
        label = ""
        if commit["labels"]:
            label = f" [{', '.join(commit['labels'][:2])}]"
            if len(commit["labels"]) > 2:
                label += f" +{len(commit['labels']) - 2}"
        prefix = ">" if i == 0 else " "
        line = (
            f"{prefix} ● {commit['date']} {commit['author']} "
            f"{commit['short']}{label} {commit['subject']}"
        )
        lines.append(line[: max(20, width - 1)])
    if commits:
        lines.append("")
        selected = commits[0]
        lines.append(f"Commit: {selected['full']}")
        lines.append(f"Author: {selected['author']}")
        lines.append(f"Date:   {selected['date']}")
        lines.append("")
        lines.append(selected["subject"])
        files = changed_files(selected["full"])
        if files:
            lines.append("")
            lines.append("Changed files:")
            for added, deleted, path in files[:12]:
                lines.append(f"  +{added} -{deleted} {path}"[: max(20, width - 1)])
    return "\n".join(lines) + "\n"


def run_tui() -> int:
    if not is_git_repository():
        return repository_error()
    if not sys.stdin.isatty() or not sys.stdout.isatty():
        return no_tty_error()

    commits = collect_commits()
    sys.stdout.write("\x1b[?1049h\x1b[?25l\x1b[H\x1b[2J")
    sys.stdout.write(draw_screen(commits))
    sys.stdout.flush()
    try:
        with open("/dev/tty", "rb", buffering=0) as tty:
            while True:
                ch = tty.read(1)
                if ch in (b"q", b"\x1b", b""):
                    break
    finally:
        sys.stdout.write("\x1b[?25h\x1b[?1049l")
        sys.stdout.flush()
    return 0


def main(argv=None) -> int:
    argv = list(sys.argv[1:] if argv is None else argv)
    mode = parse_args(argv)
    if mode == "help":
        sys.stdout.write(HELP)
        return 0
    if mode == "version":
        sys.stdout.write("keifu 0.2.3\n")
        return 0
    if mode == "arg_error":
        return 2
    return run_tui()


if __name__ == "__main__":
    raise SystemExit(main())
