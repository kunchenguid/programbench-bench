#!/bin/bash
set -e
cp src/texfmt.py executable
chmod +x executable
