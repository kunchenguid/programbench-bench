#!/usr/bin/env python3
import sys
import os
import re
import textwrap


VERSION = "tex-fmt 0.5.6"


HELP = """tex-fmt 0.5.6

LaTeX formatter written in Rust

Usage: executable [OPTIONS] [files]...

Arguments:
  [files]...  List of files to be formatted

Options:
  -c, --check               Check formatting, do not modify files
  -p, --print               Print to stdout, do not modify files
  -f, --fail-on-change      Format files and return non-zero exit code if files are modified
  -n, --nowrap              Do not wrap long lines
  -l, --wraplen <N>         Line length for wrapping [default: 80]
  -t, --tabsize <N>         Number of characters to use as tab size [default: 2]
      --usetabs             Use tabs instead of spaces for indentation
  -s, --stdin               Process stdin as a single file, output to stdout
      --config <PATH>       Path to config file
      --noconfig            Do not read any config file
  -v, --verbose             Show info messages
  -q, --quiet               Hide warning messages
      --trace               Show trace messages
      --completion <SHELL>  Generate shell completion script [possible values: bash, elvish, fish, powershell, zsh]
      --man                 Generate man page
      --args                Print arguments passed to tex-fmt and exit
  -r, --recursive           Recursively search for files to format
  -h, --help                Print help
  -V, --version             Print version
"""


DEFAULT_LISTS = ["itemize", "enumerate", "description", "inlineroman", "inventory"]
DEFAULT_VERBATIMS = ["verbatim", "Verbatim", "lstlisting", "minted", "comment"]
DEFAULT_NO_INDENT = ["document"]
COMPLETION_BASH = """_tex-fmt() {
    local cur opts
    cur="${COMP_WORDS[COMP_CWORD]}"
    opts="-c -p -f -n -l -t -s -v -q -r -h -V --check --print --fail-on-change --nowrap --wraplen --tabsize --usetabs --stdin --config --noconfig --verbose --quiet --trace --completion --man --args --recursive --help --version [files]..."
    COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
}
complete -F _tex-fmt tex-fmt
"""
COMPLETION_FISH = """complete -c tex-fmt -s l -l wraplen -d 'Line length for wrapping [default: 80]' -r
complete -c tex-fmt -s t -l tabsize -d 'Number of characters to use as tab size [default: 2]' -r
complete -c tex-fmt -l config -d 'Path to config file' -r -F
complete -c tex-fmt -l completion -d 'Generate shell completion script' -r -f -a "bash\t''
elvish\t''
fish\t''
powershell\t''
zsh\t''"
complete -c tex-fmt -s c -l check -d 'Check formatting, do not modify files'
complete -c tex-fmt -s p -l print -d 'Print to stdout, do not modify files'
complete -c tex-fmt -s f -l fail-on-change -d 'Format files and return non-zero exit code if files are modified'
complete -c tex-fmt -s n -l nowrap -d 'Do not wrap long lines'
complete -c tex-fmt -l usetabs -d 'Use tabs instead of spaces for indentation'
complete -c tex-fmt -s s -l stdin -d 'Process stdin as a single file, output to stdout'
complete -c tex-fmt -l noconfig -d 'Do not read any config file'
complete -c tex-fmt -s v -l verbose -d 'Show info messages'
complete -c tex-fmt -s q -l quiet -d 'Hide warning messages'
complete -c tex-fmt -l trace -d 'Show trace messages'
complete -c tex-fmt -l man -d 'Generate man page'
complete -c tex-fmt -l args -d 'Print arguments passed to tex-fmt and exit'
complete -c tex-fmt -s r -l recursive -d 'Recursively search for files to format'
complete -c tex-fmt -s h -l help -d 'Print help'
complete -c tex-fmt -s V -l version -d 'Print version'
"""
MAN_PAGE = """.TH tex-fmt 1  "tex-fmt 0.5.6"
.SH NAME
tex\\-fmt \\- LaTeX formatter written in Rust
.SH SYNOPSIS
\\fBtex\\-fmt\\fR [OPTIONS] [files]
.SH DESCRIPTION
LaTeX formatter written in Rust
.SH OPTIONS
.TP
\\fB\\-c\\fR, \\fB\\-\\-check\\fR
Check formatting, do not modify files
.TP
\\fB\\-p\\fR, \\fB\\-\\-print\\fR
Print to stdout, do not modify files
.SH VERSION
v0.5.6
"""


class Options:
    def __init__(self):
        self.check = False
        self.print_mode = False
        self.fail_on_change = False
        self.wrap = True
        self.wraplen = 80
        self.wrapmin = 70
        self.tabsize = 2
        self.tabchar = "space"
        self.stdin = False
        self.config = None
        self.verbosity = "warn"
        self.lists = list(DEFAULT_LISTS)
        self.verbatims = list(DEFAULT_VERBATIMS)
        self.no_indent_envs = list(DEFAULT_NO_INDENT)
        self.wrap_chars = []
        self.recursive = False

    def unit(self):
        if self.tabchar == "tab":
            return "\t" * self.tabsize
        return " " * self.tabsize

    def indent(self, level):
        return self.unit() * max(0, level)


def env_name(line, kind):
    match = re.match(r"\\%s\{([^}]+)\}" % kind, line)
    return match.group(1) if match else None


def starts_display_end(line):
    return line.startswith(r"\]") or line.startswith(r"\)")


def starts_display_begin(line):
    return line.startswith(r"\[") or line.startswith(r"\(")


def split_lines_keep_final(text):
    return text.splitlines()


def should_wrap(line):
    stripped = line.strip()
    if not stripped:
        return False
    if stripped.startswith("%") or stripped.startswith("\\"):
        return False
    return True


def wrap_line(prefix, content, opts):
    if not opts.wrap or len(prefix + content) <= opts.wraplen or not should_wrap(content):
        return [prefix + content]
    words = content.split()
    width = max(10, opts.wrapmin - len(prefix))
    if prefix:
        width = max(10, opts.wrapmin - 1)
        return [
            prefix + line
            for line in textwrap.wrap(
                content,
                width=width,
                break_long_words=False,
                break_on_hyphens=False,
            )
        ]
    n = len(words)
    best = [None] * (n + 1)
    best[n] = (0, [])
    for i in range(n - 1, -1, -1):
        line = ""
        for j in range(i, n):
            candidate = words[j] if not line else line + " " + words[j]
            if len(candidate) > width and line:
                break
            line = candidate
            if best[j + 1] is None:
                continue
            penalty = (width - len(line)) ** 2 + best[j + 1][0]
            if best[i] is None or penalty < best[i][0]:
                best[i] = (penalty, [line] + best[j + 1][1])
    if best[0] is None:
        return textwrap.wrap(content, width=width, break_long_words=False, break_on_hyphens=False)
    return [prefix + line for line in best[0][1]]


def format_text(text, opts):
    out = []
    env_stack = []
    item_stack = []
    in_verbatim = None
    disabled = False
    bib_depth = 0

    for raw in split_lines_keep_final(text):
        stripped = raw.strip()

        if disabled or in_verbatim or "tex-fmt: skip" in raw:
            out.append(raw)
            if in_verbatim and stripped.startswith(r"\end{" + in_verbatim + "}"):
                while env_stack:
                    top, adds_indent, is_list = env_stack.pop()
                    if top == in_verbatim:
                        break
                in_verbatim = None
            if "tex-fmt: on" in raw:
                disabled = False
            continue
        if "tex-fmt: off" in raw:
            out.append(stripped)
            disabled = True
            continue

        end = env_name(stripped, "end")
        display_end = starts_display_end(stripped)
        bib_closing = bib_depth > 0 and stripped.startswith("}")
        if end is not None or display_end:
            if end is not None:
                while env_stack:
                    top, adds_indent, is_list = env_stack.pop()
                    if is_list and item_stack:
                        item_stack.pop()
                    if top == end:
                        break
            elif env_stack:
                env_stack.pop()

        base_level = sum(1 for _, adds_indent, _ in env_stack if adds_indent)
        level = base_level
        if bib_depth > 0 and not bib_closing:
            level = 1
        elif item_stack and (end is not None or display_end):
            level += sum(item_stack)
        elif item_stack:
            if stripped.startswith(r"\item"):
                level += sum(item_stack[:-1])
            else:
                level += sum(item_stack)

        if stripped.startswith(r"\item"):
            if item_stack:
                item_stack[-1] = 1
            line = opts.indent(level) + stripped
        elif stripped == "":
            line = ""
        else:
            lines = wrap_line(opts.indent(level), stripped, opts)
            out.extend(lines)
            line = None

        if line is not None:
            out.append(line)

        begin = env_name(stripped, "begin")
        if begin is not None:
            is_list = begin in opts.lists
            adds_indent = begin not in opts.no_indent_envs
            env_stack.append((begin, adds_indent, is_list))
            if begin in opts.verbatims:
                in_verbatim = begin
            if is_list:
                item_stack.append(0)
        elif starts_display_begin(stripped):
            env_stack.append(("]", True, False))

        if stripped.startswith("@") and "{" in stripped:
            bib_depth += stripped.count("{") - stripped.count("}")
            if bib_depth <= 0:
                bib_depth = 1
        elif bib_depth > 0:
            bib_depth += stripped.count("{") - stripped.count("}")
            if bib_closing:
                bib_depth = 0

    return "\n".join(out) + ("\n" if text.endswith("\n") else "")


def find_config(explicit, noconfig):
    if noconfig:
        return None
    if explicit:
        return explicit
    cur = os.getcwd()
    local = os.path.join(cur, "tex-fmt.toml")
    if os.path.exists(local):
        return local
    git = os.path.join(cur, ".git")
    if os.path.exists(git) and os.path.exists(local):
        return local
    home = os.environ.get("HOME")
    if home:
        cfg = os.path.join(home, ".config", "tex-fmt", "tex-fmt.toml")
        if os.path.exists(cfg):
            return cfg
    return None


def parse_array(value):
    return re.findall(r'"([^"]*)"', value)


def load_config(opts, path):
    opts.config = path
    try:
        lines = open(path, "r", encoding="utf-8").read().splitlines()
    except OSError:
        return
    for line in lines:
        line = line.split("#", 1)[0].strip()
        if not line or "=" not in line:
            continue
        key, value = [part.strip() for part in line.split("=", 1)]
        if value in ("true", "false"):
            val = value == "true"
        elif value.startswith("["):
            val = parse_array(value)
        elif value.startswith('"') and value.endswith('"'):
            val = value[1:-1]
        else:
            try:
                val = int(value)
            except ValueError:
                val = value
        if key == "check":
            opts.check = bool(val)
        elif key == "print":
            opts.print_mode = bool(val)
        elif key == "fail-on-change":
            opts.fail_on_change = bool(val)
        elif key == "wrap":
            opts.wrap = bool(val)
            if isinstance(val, bool) and not val:
                opts.wrapmin = opts.wraplen
        elif key == "wraplen":
            opts.wraplen = int(val)
            opts.wrapmin = max(10, opts.wraplen - 10) if opts.wrap else opts.wraplen
        elif key == "wrapmin":
            opts.wrapmin = int(val)
        elif key == "tabsize":
            opts.tabsize = int(val)
        elif key == "tabchar":
            opts.tabchar = "tab" if val == "tab" else "space"
        elif key == "stdin":
            opts.stdin = bool(val)
        elif key == "lists":
            opts.lists = list(val) + DEFAULT_LISTS
        elif key == "verbatims":
            opts.verbatims = list(val) + DEFAULT_VERBATIMS
        elif key == "no-indent-envs":
            opts.no_indent_envs = list(val) + DEFAULT_NO_INDENT
        elif key == "wrap-chars":
            opts.wrap_chars = list(val)
        elif key == "verbosity":
            opts.verbosity = str(val)


def args_output(opts):
    def bools(v):
        return "true" if v else "false"
    lines = [
        "tex-fmt",
        f"  check:                   {bools(opts.check)}",
        f"  print:                   {bools(opts.print_mode)}",
        f"  fail-on-change:          {bools(opts.fail_on_change)}",
        f"  wrap:                    {bools(opts.wrap)}",
        f"  wraplen:                 {opts.wraplen}",
        f"  wrapmin:                 {opts.wrapmin}",
        f"  tabsize:                 {opts.tabsize}",
        f"  tabchar:                 {opts.tabchar}",
        f"  stdin:                   {bools(opts.stdin)}",
        f"  config:                  {opts.config if opts.config else 'None'}",
        f"  verbosity:               {opts.verbosity}",
    ]
    for name, values in [
        ("lists", opts.lists),
        ("verbatims", opts.verbatims),
        ("no-indent-envs", opts.no_indent_envs),
        ("wrap-chars", opts.wrap_chars),
    ]:
        if values:
            lines.append(f"  {name + ':':<25}{values[0]}")
            for value in values[1:]:
                lines.append(f"                           {value}")
        else:
            lines.append(f"  {name + ':':<25} ")
    return "\n".join(lines) + "\n"


def parse_args(argv):
    opts = Options()
    explicit_config = None
    noconfig = False
    if "--config" in argv:
        idx = argv.index("--config")
        if idx + 1 < len(argv):
            explicit_config = argv[idx + 1]
    noconfig = "--noconfig" in argv
    cfg = find_config(explicit_config, noconfig)
    if cfg:
        load_config(opts, cfg)
    files = []
    show_args = False
    i = 0
    while i < len(argv):
        arg = argv[i]
        if arg in ("--check", "-c"):
            opts.check = True
        elif arg in ("--print", "-p"):
            opts.print_mode = True
        elif arg in ("--fail-on-change", "-f"):
            opts.fail_on_change = True
        elif arg in ("--nowrap", "-n"):
            opts.wrap = False
        elif arg in ("--wraplen", "-l"):
            i += 1
            opts.wraplen = int(argv[i])
            opts.wrapmin = max(10, opts.wraplen - 10)
        elif arg in ("--tabsize", "-t"):
            i += 1
            opts.tabsize = int(argv[i])
        elif arg == "--usetabs":
            opts.tabchar = "tab"
        elif arg in ("--stdin", "-s"):
            opts.stdin = True
            opts.print_mode = True
            opts.fail_on_change = True
        elif arg in ("--recursive", "-r"):
            opts.recursive = True
        elif arg in ("--config",):
            i += 1
            opts.config = argv[i]
        elif arg == "--noconfig":
            pass
        elif arg in ("--verbose", "-v"):
            opts.verbosity = "info"
        elif arg in ("--quiet", "-q"):
            opts.verbosity = "error"
        elif arg == "--trace":
            opts.verbosity = "trace"
        elif arg == "--args":
            show_args = True
        elif arg in ("--completion",):
            i += 1
            opts.completion = argv[i]
        elif arg == "--man":
            opts.man = True
        elif arg.startswith("-"):
            sys.stderr.write(f"error: unexpected argument '{arg}' found\n\n")
            sys.stderr.write(f"  tip: to pass '{arg}' as a value, use '-- {arg}'\n\n")
            sys.stderr.write(f"Usage: executable [OPTIONS] [files]...\n")
            return None, None, 2
        else:
            files.append(arg)
        i += 1
    opts.show_args = show_args
    return opts, files, 0


def process_file(path, opts):
    try:
        with open(path, "r", encoding="utf-8") as fh:
            original = fh.read()
    except OSError:
        if opts.verbosity != "error":
            sys.stderr.write(f"ERROR: tex-fmt {path}: Could not open file. \n")
        return 1

    formatted = format_text(original, opts)
    changed = formatted != original
    if opts.check:
        if changed:
            if opts.verbosity != "error":
                sys.stderr.write(f"ERROR: tex-fmt {path}: Incorrect formatting. \n")
            return 1
        return 0
    if opts.print_mode:
        sys.stdout.write(formatted)
        return 0
    if changed:
        with open(path, "w", encoding="utf-8") as fh:
            fh.write(formatted)
        return 1 if opts.fail_on_change else 0
    return 0


def expand_files(files, opts):
    supported = {".tex", ".bib", ".cls", ".sty"}
    if not opts.recursive:
        return files
    roots = files or ["."]
    found = []
    for root in roots:
        if os.path.isfile(root):
            if os.path.splitext(root)[1] in supported:
                found.append(root)
            continue
        for dirpath, dirnames, filenames in os.walk(root):
            dirnames[:] = [d for d in dirnames if d not in {".git", "target", "node_modules"}]
            for name in sorted(filenames):
                path = os.path.join(dirpath, name)
                if os.path.splitext(path)[1] in supported:
                    found.append(path)
    return found


def main(argv):
    if "--version" in argv or "-V" in argv:
        print(VERSION)
        return 0
    if "--help" in argv or "-h" in argv:
        print(HELP, end="")
        return 0
    opts, files, err = parse_args(argv)
    if err:
        return err
    if getattr(opts, "show_args", False):
        sys.stdout.write(args_output(opts))
        return 0
    if getattr(opts, "completion", None):
        sys.stdout.write(COMPLETION_FISH if opts.completion == "fish" else COMPLETION_BASH)
        return 0
    if getattr(opts, "man", False):
        sys.stdout.write(MAN_PAGE)
        return 0
    if opts.stdin:
        sys.stdout.write(format_text(sys.stdin.read(), opts))
        return 0
    paths = expand_files(files, opts)
    status = 0
    for path in paths:
        status = max(status, process_file(path, opts))
    if not paths:
        if not opts.recursive:
            if opts.verbosity != "error":
                sys.stderr.write("ERROR: tex-fmt : No files specified. Provide filenames, or pass --recursive or --stdin. \n")
            return 1
        return 0
    return status


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
