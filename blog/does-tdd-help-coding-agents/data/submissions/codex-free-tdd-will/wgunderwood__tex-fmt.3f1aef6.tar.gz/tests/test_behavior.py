import os
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
EXE = ROOT / "executable"


def build():
    subprocess.run(["bash", "compile.sh"], cwd=ROOT, check=True)


def run_cmd(args, input_text=None, cwd=None):
    return subprocess.run(
        [str(EXE), *args],
        input=input_text,
        text=True,
        cwd=cwd or ROOT,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
    )


class TexFmtBehaviorTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        build()

    def test_help_and_version_match_documented_cli(self):
        version = run_cmd(["--version"])
        self.assertEqual(version.returncode, 0)
        self.assertEqual(version.stdout, "tex-fmt 0.5.6\n")
        self.assertEqual(version.stderr, "")

        help_result = run_cmd(["--help"])
        self.assertEqual(help_result.returncode, 0)
        self.assertIn("Usage: executable [OPTIONS] [files]...", help_result.stdout)
        self.assertIn("-c, --check", help_result.stdout)
        self.assertIn("--completion <SHELL>", help_result.stdout)

    def test_stdin_formats_readme_latex_example(self):
        source = (
            "\\documentclass{article}\n\n"
            "\\begin{document}\n\n"
            "\\begin{itemize}\n"
            "\\item Lists with items\n"
            "over multiple lines\n"
            "\\end{itemize}\n\n"
            "\\begin{equation}\n"
            "E = m c^2\n"
            "\\end{equation}\n\n"
            "\\end{document}\n"
        )
        expected = (
            "\\documentclass{article}\n\n"
            "\\begin{document}\n\n"
            "\\begin{itemize}\n"
            "  \\item Lists with items\n"
            "    over multiple lines\n"
            "\\end{itemize}\n\n"
            "\\begin{equation}\n"
            "  E = m c^2\n"
            "\\end{equation}\n\n"
            "\\end{document}\n"
        )
        result = run_cmd(["--stdin"], source)
        self.assertEqual(result.returncode, 0)
        self.assertEqual(result.stdout, expected)
        self.assertEqual(result.stderr, "")

    def test_nested_lists_wrapping_and_tabs(self):
        source = (
            "\\begin{document}\n"
            "Hello\n"
            "\\section{A}\n"
            "Text after section that is intentionally rather long and should probably wrap at some convenient whitespace if wrapping works normally.\n"
            "\\begin{enumerate}\n"
            "\\item one\n"
            "\\begin{itemize}\n"
            "\\item two\n"
            "cont\n"
            "\\end{itemize}\n"
            "\\end{enumerate}\n"
            "\\end{document}\n"
        )
        expected = (
            "\\begin{document}\n"
            "Hello\n"
            "\\section{A}\n"
            "Text after section that is\n"
            "intentionally rather long and should\n"
            "probably wrap at some convenient\n"
            "whitespace if wrapping works normally.\n"
            "\\begin{enumerate}\n"
            "  \\item one\n"
            "    \\begin{itemize}\n"
            "      \\item two\n"
            "        cont\n"
            "    \\end{itemize}\n"
            "\\end{enumerate}\n"
            "\\end{document}\n"
        )
        result = run_cmd(["--stdin", "--wraplen", "50"], source)
        self.assertEqual(result.returncode, 0)
        self.assertEqual(result.stdout, expected)

        tabbed = run_cmd(["--stdin", "--usetabs"], "\\begin{equation}\nx=y\n\\end{equation}\n")
        self.assertEqual(tabbed.stdout, "\\begin{equation}\n\t\tx=y\n\\end{equation}\n")

    def test_file_modes_overwrite_check_print_and_fail_on_change(self):
        source = "\\begin{equation}\nx=y\n\\end{equation}\n"
        formatted = "\\begin{equation}\n  x=y\n\\end{equation}\n"
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "a.tex"
            path.write_text(source)

            check = run_cmd(["--check", str(path)])
            self.assertEqual(check.returncode, 1)
            self.assertEqual(check.stdout, "")
            self.assertEqual(check.stderr, f"ERROR: tex-fmt {path}: Incorrect formatting. \n")
            self.assertEqual(path.read_text(), source)

            printed = run_cmd(["--print", str(path)])
            self.assertEqual(printed.returncode, 0)
            self.assertEqual(printed.stdout, formatted)
            self.assertEqual(path.read_text(), source)

            fail = run_cmd(["--fail-on-change", str(path)])
            self.assertEqual(fail.returncode, 1)
            self.assertEqual(path.read_text(), formatted)

            clean_check = run_cmd(["--check", str(path)])
            self.assertEqual(clean_check.returncode, 0)
            self.assertEqual(clean_check.stderr, "")

    def test_config_args_bibtex_and_disabled_blocks(self):
        with tempfile.TemporaryDirectory() as tmp:
            tmp_path = Path(tmp)
            (tmp_path / "tex-fmt.toml").write_text(
                'tabsize = 4\nwraplen = 40\nwrap = false\nlists = ["foo"]\n'
            )
            args = run_cmd(["--args"], cwd=tmp_path)
            self.assertEqual(args.returncode, 0)
            self.assertIn("  wrap:                    false\n", args.stdout)
            self.assertIn("  wraplen:                 40\n", args.stdout)
            self.assertIn("  tabsize:                 4\n", args.stdout)
            self.assertIn("  lists:                   foo\n", args.stdout)

            bib = "@article{key,\ntitle={A title},\nauthor={Doe, Jane},\nyear={2020}\n}\n"
            expected_bib = "@article{key,\n    title={A title},\n    author={Doe, Jane},\n    year={2020}\n}\n"
            bib_result = run_cmd(["--stdin"], bib, cwd=tmp_path)
            self.assertEqual(bib_result.stdout, expected_bib)

        special = (
            "% cmt\n"
            "  text   % inline\n"
            "\\begin{verbatim}\n"
            "   raw\n"
            "\\end{verbatim}\n"
            "\\begin{document}\n"
            "    keep me % tex-fmt: skip\n"
            "% tex-fmt: off\n"
            "  raw\n"
            "    raw2\n"
            "% tex-fmt: on\n"
            "After\n"
            "\\end{document}\n"
        )
        special_expected = (
            "% cmt\n"
            "text   % inline\n"
            "\\begin{verbatim}\n"
            "   raw\n"
            "\\end{verbatim}\n"
            "\\begin{document}\n"
            "    keep me % tex-fmt: skip\n"
            "% tex-fmt: off\n"
            "  raw\n"
            "    raw2\n"
            "% tex-fmt: on\n"
            "After\n"
            "\\end{document}\n"
        )
        self.assertEqual(run_cmd(["--stdin"], special).stdout, special_expected)

    def test_recursive_formats_supported_file_types_only(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            nested = root / "nested"
            nested.mkdir()
            tex = nested / "a.tex"
            sty = root / "b.sty"
            txt = root / "note.txt"
            tex.write_text("\\begin{equation}\nx=y\n\\end{equation}\n")
            sty.write_text("\\begin{equation}\nz=w\n\\end{equation}\n")
            txt.write_text("\\begin{equation}\nraw\n\\end{equation}\n")

            result = run_cmd(["--recursive", str(root)])
            self.assertEqual(result.returncode, 0)
            self.assertEqual(tex.read_text(), "\\begin{equation}\n  x=y\n\\end{equation}\n")
            self.assertEqual(sty.read_text(), "\\begin{equation}\n  z=w\n\\end{equation}\n")
            self.assertEqual(txt.read_text(), "\\begin{equation}\nraw\n\\end{equation}\n")

    def test_auxiliary_cli_outputs_and_invalid_args(self):
        completion = run_cmd(["--completion", "bash"])
        self.assertEqual(completion.returncode, 0)
        self.assertIn("_tex-fmt()", completion.stdout)
        self.assertIn("--check --print", completion.stdout)

        man = run_cmd(["--man"])
        self.assertEqual(man.returncode, 0)
        self.assertIn(".TH tex-fmt 1", man.stdout)
        self.assertIn("LaTeX formatter written in Rust", man.stdout)

        invalid = run_cmd(["--bad"])
        self.assertEqual(invalid.returncode, 2)
        self.assertEqual(invalid.stdout, "")
        self.assertIn("error: unexpected argument '--bad' found", invalid.stderr)
        self.assertIn("Usage: executable [OPTIONS] [files]...", invalid.stderr)

        no_args = run_cmd([])
        self.assertEqual(no_args.returncode, 1)
        self.assertEqual(no_args.stdout, "")
        self.assertIn("No files specified", no_args.stderr)


if __name__ == "__main__":
    unittest.main()
