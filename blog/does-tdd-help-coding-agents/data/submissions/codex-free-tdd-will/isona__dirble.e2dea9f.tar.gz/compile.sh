#!/bin/bash
set -e
cp src/dirble.py executable
chmod +x executable
