#!/usr/bin/env python3
import json
import os
import sys
import time
import urllib.error
import urllib.parse
import urllib.request
from dataclasses import dataclass


VERSION = "Dirble 1.4.2 (commit d520c82, build 2026-04-17)"
HELP = """Fast directory scanning and scraping tool

Usage: executable [OPTIONS] <uri|--uri-file <uri-file>|--uri <uri>>

Arguments:
  [uri]
          The URI of the host to scan, optionally supports basic auth with
          http://user:pass@host:port

Options:
  -u, --uri <uri>
          Additional hosts to scan [aliases: url]
  -U, --uri-file <uri-file>
          The filename of a file containing a list of URIs to scan - cookies and
          headers set will be applied to all URIs [aliases: url-file]
      --verb <http_verb>
          Specify which HTTP verb to use
           [default: get] [possible values: get, head, post]
  -w, --wordlist <wordlist>
          Sets which wordlist to use, defaults to dirble_wordlist.txt in the same
          folder as the executable
  -p, --prefixes <prefixes>...
          Provides comma separated prefixes to extend queries with
  -P, --prefix-file <prefix-file>
          The name of a file containing extensions to extend queries with, one
          per line
  -x, --extensions <extensions>...
          Provides comma separated extensions to extend queries with
  -X, --extension-file <extension-file>
          The name of a file containing extensions to extend queries with, one
          per line
      --ext-sub
          Indicates whether the string "%EXT%" in a wordlist file should be 
          substituted with the current extension
  -f, --force-extension
          Only scan with provided extensions
  -k, --ignore-cert
          Ignore the certificate validity for HTTPS
      --show-htaccess
          Enable display of items containing .ht when they return 403 responses
      --timeout <timeout>
          Maximum time to wait for a response before giving up, given in seconds
           [default: 5]
      --json-file <json_file>
          Sets a file to write JSON output to [aliases: oJ]
      --no-color
          Disable coloring of terminal output
  -o, --output-file <output_file>
          Sets the file to write the report to [aliases: oN]
      --xml-file <xml_file>
          Sets a file to write XML output to [aliases: oX]
      --output-all <output_all>
          Stores all output types respectively as .txt, .json and .xml [aliases: oA]
  -t, --max-threads <max-threads>
          Sets the maximum number of request threads that will be spawned [default: 10]
  -T, --wordlist-split <wordlist_split>
          The number of threads to run for each folder/extension combo [default: 3]
  -z, --throttle <milliseconds>
          Time each thread will wait between requests, given in milliseconds
      --username <username>
          Sets the username to authenticate with
      --password <password>
          Sets the password to authenticate with
  -l, --scan-listable
          Scan listable directories
      --max-recursion-depth <max_recursion_depth>
          Sets the maximum directory depth to recurse to, 0 will disable
          recursion
  -r, --disable-recursion
          Disable discovered subdirectory scanning
      --scrape-listable
          Enable scraping of listable directories for urls, often produces large
          amounts of output
  -a, --user-agent <user_agent>
          Set the user-agent provided with requests, by default it isn't set
  -c, --cookie <cookie>
          Provide a cookie in the form "name=value", can be used multiple times
  -H, --header <header>
          Provide an arbitrary header in the form "header:value" - headers with
          no value must end in a semicolon
  -S, --silent
          Don't output information during the scan, only output the report at
          the end.
  -v, --verbose...
          Increase the verbosity level. Use twice for full verbosity.
  -B, --code-blacklist <code_blacklist>...
          Provide a comma separated list of response codes to not show in output
      --disable-validator
          Disable automatic detection of not found codes
  -W, --code-whitelist <code_whitelist>...
          Provide a comma separated list of response codes to show in output,
          also disables detection of not found codes
      --scan-401
          Scan folders even if they return 401 - Unauthorized frequently
      --scan-403
          Scan folders if they return 403 - Forbidden frequently
  -h, --help
          Print help
  -V, --version
          Print version

OUTPUT FORMAT:
    + [url] - File
    D [url] - Directory
    L [url] - Listable Directory
"""


@dataclass
class Options:
    uris: list
    wordlist: str
    extensions: list
    prefixes: list
    ext_sub: bool
    force_extension: bool
    verb: str
    timeout: float
    silent: bool
    output_file: str | None
    json_file: str | None
    xml_file: str | None
    output_all: str | None
    whitelist: set | None
    blacklist: set
    hide_lengths: list
    headers: dict
    cookies: list
    user_agent: str | None
    disable_recursion: bool
    max_recursion_depth: int
    disable_validator: bool


@dataclass
class Finding:
    url: str
    code: int
    size: int
    redirect_url: str = ""
    is_directory: bool = False
    is_listable: bool = False
    found_from_listable: bool = False


class NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        return None


def split_values(values):
    out = []
    for value in values:
        for item in str(value).split(","):
            item = item.strip()
            if item:
                out.append(item)
    return out


def read_lines(path):
    with open(path, "r", encoding="utf-8", errors="ignore") as handle:
        return [line.strip() for line in handle if line.strip()]


def parse_codes(values):
    if not values:
        return set()
    codes = set()
    for value in split_values(values):
        try:
            codes.add(int(value))
        except ValueError:
            pass
    return codes


def parse_lengths(values):
    ranges = []
    for value in split_values(values):
        if "-" in value:
            a, b = value.split("-", 1)
            ranges.append((int(a), int(b)))
        else:
            n = int(value)
            ranges.append((n, n))
    return ranges


def parse_args(argv):
    uris = []
    wordlist = None
    extensions = []
    prefixes = []
    prefix_file = None
    extension_file = None
    uri_file = None
    verb = "get"
    timeout = 5.0
    silent = False
    output_file = json_file = xml_file = output_all = None
    whitelist = None
    blacklist_values = []
    hide_length_values = []
    headers = {}
    cookies = []
    user_agent = None
    ext_sub = force_extension = disable_recursion = disable_validator = False
    max_recursion_depth = 20

    i = 0
    while i < len(argv):
        arg = argv[i]
        def need():
            nonlocal i
            i += 1
            if i >= len(argv):
                raise SystemExit(2)
            return argv[i]
        if arg in ("-u", "--uri", "--url"):
            uris.append(need())
        elif arg in ("-U", "--uri-file", "--url-file"):
            uri_file = need()
        elif arg in ("-w", "--wordlist"):
            wordlist = need()
        elif arg in ("-x", "--extensions"):
            extensions.extend(split_values([need()]))
        elif arg in ("-X", "--extension-file"):
            extension_file = need()
        elif arg in ("-p", "--prefixes"):
            prefixes.extend(split_values([need()]))
        elif arg in ("-P", "--prefix-file"):
            prefix_file = need()
        elif arg == "--ext-sub":
            ext_sub = True
        elif arg in ("-f", "--force-extension"):
            force_extension = True
        elif arg == "--verb":
            verb = need().lower()
        elif arg == "--timeout":
            timeout = float(need())
        elif arg in ("-S", "--silent"):
            silent = True
        elif arg in ("-o", "--output-file", "--oN"):
            output_file = need()
        elif arg in ("--json-file", "--oJ"):
            json_file = need()
        elif arg in ("--xml-file", "--oX"):
            xml_file = need()
        elif arg in ("--output-all", "--oA"):
            output_all = need()
        elif arg in ("-W", "--code-whitelist"):
            whitelist = parse_codes([need()])
        elif arg in ("-B", "--code-blacklist"):
            blacklist_values.append(need())
        elif arg == "--hide-lengths":
            hide_length_values.append(need())
        elif arg in ("-H", "--header"):
            raw = need()
            if ":" in raw:
                key, value = raw.split(":", 1)
                headers[key.strip()] = value.strip()
            elif raw.endswith(";"):
                headers[raw[:-1].strip()] = ""
        elif arg in ("-c", "--cookie"):
            cookies.append(need())
        elif arg in ("-a", "--user-agent"):
            user_agent = need()
        elif arg in ("-r", "--disable-recursion"):
            disable_recursion = True
        elif arg == "--max-recursion-depth":
            max_recursion_depth = int(need())
        elif arg == "--disable-validator":
            disable_validator = True
        elif arg in ("--no-color", "-k", "--ignore-cert", "--show-htaccess",
                     "--burp", "--no-proxy", "--proxy", "-t", "--max-threads",
                     "-T", "--wordlist-split", "-z", "--throttle", "--username",
                     "--password", "-l", "--scan-listable", "--scrape-listable",
                     "-v", "--verbose", "--scan-401", "--scan-403",
                     "--max-errors"):
            if arg in ("--proxy", "-t", "--max-threads", "-T", "--wordlist-split",
                       "-z", "--throttle", "--username", "--password", "--max-errors"):
                need()
        elif arg.startswith("-v"):
            pass
        elif arg.startswith("-"):
            print(f"error: unexpected argument '{arg}'")
            return None, 2
        else:
            uris.append(arg)
        i += 1

    if uri_file:
        uris.extend(read_lines(uri_file))
    if prefix_file:
        prefixes.extend(read_lines(prefix_file))
    if extension_file:
        extensions.extend(read_lines(extension_file))
    if not uris:
        return None, 2
    if not wordlist:
        wordlist = os.path.join(os.path.dirname(os.path.abspath(sys.argv[0])), "dirble_wordlist.txt")
    return Options(
        uris, wordlist, extensions, prefixes, ext_sub, force_extension, verb,
        timeout, silent, output_file, json_file, xml_file, output_all, whitelist,
        parse_codes(blacklist_values), parse_lengths(hide_length_values),
        headers, cookies, user_agent, disable_recursion, max_recursion_depth,
        disable_validator,
    ), 0


def normalize_base(uri):
    if not uri.startswith(("http://", "https://")):
        uri = "http://" + uri
    return uri.rstrip("/") + "/"


def add_ext(word, ext):
    if not ext:
        return word
    if ext.startswith("."):
        return word + ext
    return word + "." + ext


def candidate_paths(words, opt):
    exts = opt.extensions or [""]
    seen = []
    for word in words:
        words_for_ext = []
        if opt.ext_sub and "%EXT%" in word:
            words_for_ext = [word.replace("%EXT%", e.lstrip(".")) for e in exts]
        elif opt.force_extension:
            words_for_ext = [add_ext(word, e) for e in exts if e]
        else:
            words_for_ext = [word] + [add_ext(word, e) for e in exts if e]
        for item in words_for_ext:
            if item:
                seen.append(item.strip("/"))
        for prefix in opt.prefixes:
            for item in words_for_ext:
                if item:
                    seen.append((prefix + item).strip("/"))
    return seen


def request_url(url, opt):
    method = opt.verb.upper()
    data = b"" if method == "POST" else None
    headers = dict(opt.headers)
    if opt.cookies:
        headers["Cookie"] = "; ".join(opt.cookies)
    if opt.user_agent:
        headers["User-Agent"] = opt.user_agent
    req = urllib.request.Request(url, data=data, headers=headers, method=method)
    opener = urllib.request.build_opener(urllib.request.ProxyHandler({}), NoRedirect)
    try:
        with opener.open(req, timeout=opt.timeout) as resp:
            body = b"" if method == "HEAD" else resp.read()
            headers = dict(resp.headers)
            if method == "HEAD":
                return resp.status, headers, b"\0" * int(headers.get("Content-Length", "0") or 0)
            return resp.status, headers, body
    except urllib.error.HTTPError as exc:
        body = b"" if method == "HEAD" else exc.read()
        headers = dict(exc.headers)
        if method == "HEAD":
            return exc.code, headers, b"\0" * int(headers.get("Content-Length", "0") or 0)
        return exc.code, headers, body
    except Exception:
        return None, {}, b""


def is_hidden_by_length(size, ranges):
    return any(lo <= size <= hi for lo, hi in ranges)


def should_show(finding, opt):
    if opt.disable_validator:
        if finding.code in opt.blacklist:
            return False
        if is_hidden_by_length(finding.size, opt.hide_lengths):
            return False
        return opt.whitelist is None or finding.code in opt.whitelist
    if opt.whitelist is not None:
        return finding.code in opt.whitelist
    if finding.code in opt.blacklist:
        return False
    if is_hidden_by_length(finding.size, opt.hide_lengths):
        return False
    return 200 <= finding.code < 400 or finding.code in (401, 403)


def make_line(f):
    prefix = "D" if f.is_directory else "L" if f.is_listable else "+"
    extra = f"|DEST:{f.redirect_url}" if f.redirect_url else ""
    return f"{prefix} {f.url} (CODE:{f.code}|SIZE:{f.size}{extra})"


def absolutize_redirect(base, location):
    return urllib.parse.urljoin(base, location)


def scan(opt):
    words = read_lines(opt.wordlist)
    findings = []
    for uri in opt.uris:
        start = normalize_base(uri)
        queue = [(start, 0)]
        scanned = set()
        while queue:
            base, depth = queue.pop(0)
            if base in scanned:
                continue
            scanned.add(base)
            for path in candidate_paths(words, opt):
                finding = scan_one(base, path, opt)
                if finding and should_show(finding, opt):
                    findings.append(finding)
                    if not opt.silent:
                        print(make_line(finding))
                    if (finding.is_directory and not opt.disable_recursion and
                            depth < opt.max_recursion_depth):
                        queue.append(normalize_base(finding.url))
    return findings


def scan_one(base, path, opt):
            target = urllib.parse.urljoin(base, path)
            code, headers, body = request_url(target, opt)
            if code is None:
                return None
            size = len(body)
            redirect = ""
            is_directory = False
            shown_url = target
            if code in (301, 302, 303, 307, 308) and headers.get("Location"):
                redirect = absolutize_redirect(target, headers["Location"])
                if redirect.rstrip("/") == target.rstrip("/"):
                    is_directory = True
                    shown_url = redirect
                    code2, headers2, body2 = request_url(redirect, opt)
                    if code2 is not None:
                        code, headers, body, size = code2, headers2, body2, len(body2)
                        redirect = ""
            if code == 200 and path.endswith("/"):
                is_directory = True
            finding = Finding(shown_url, code, size, redirect, is_directory)
            if code == 200 and b"Index of" in body:
                finding.is_listable = True
            return finding


def write_outputs(findings, opt):
    if opt.output_all:
        opt.output_file = opt.output_all + ".txt"
        opt.json_file = opt.output_all + ".json"
        opt.xml_file = opt.output_all + ".xml"
    if opt.output_file:
        with open(opt.output_file, "w", encoding="utf-8") as handle:
            for uri in opt.uris:
                handle.write(f"Dirble Scan Report for {normalize_base(uri)}:\n")
            for f in findings:
                handle.write(make_line(f) + "\n")
            handle.write("\n")
    if opt.json_file:
        rows = [
            {
                "url": f.url,
                "code": f.code,
                "size": f.size,
                "is_directory": f.is_directory,
                "is_listable": f.is_listable,
                "redirect_url": f.redirect_url,
                "found_from_listable": f.found_from_listable,
            }
            for f in findings
        ]
        with open(opt.json_file, "w", encoding="utf-8") as handle:
            handle.write(json.dumps(rows, separators=(",", ":")))
    if opt.xml_file:
        with open(opt.xml_file, "w", encoding="utf-8") as handle:
            handle.write('<?xml version="1.0" encoding="UTF-8"?>\n<dirble_scan>\n')
            for f in findings:
                attrs = (
                    f'url="{escape_xml(f.url)}" code="{f.code}" content_len="{f.size}" '
                    f'is_directory="{str(f.is_directory).lower()}" '
                    f'is_listable="{str(f.is_listable).lower()}" '
                    f'redirect_url="{escape_xml(f.redirect_url)}" '
                    f'found_from_listable="{str(f.found_from_listable).lower()}"'
                )
                handle.write(f"<path {attrs}/>\n")
            handle.write("</dirble_scan>")


def escape_xml(text):
    return (text.replace("&", "&amp;").replace('"', "&quot;")
            .replace("<", "&lt;").replace(">", "&gt;"))


def main(argv=None):
    argv = list(sys.argv[1:] if argv is None else argv)
    if argv in (["--version"], ["-V"]):
        print(VERSION)
        return 0
    if not argv:
        print(HELP)
        return 2
    if argv in (["--help"], ["-h"]):
        print(HELP)
        return 0
    opt, status = parse_args(argv)
    if status:
        print(HELP)
        return status
    try:
        findings = scan(opt)
        if opt.silent and not opt.output_file and not opt.json_file and not opt.xml_file and not opt.output_all:
            for finding in findings:
                print(make_line(finding))
        write_outputs(findings, opt)
        return 0
    except FileNotFoundError as exc:
        print(f"Error: {exc}")
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
