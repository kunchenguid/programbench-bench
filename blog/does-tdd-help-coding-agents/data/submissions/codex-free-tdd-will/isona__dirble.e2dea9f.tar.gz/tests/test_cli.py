import subprocess
import threading
import unittest
from http.server import BaseHTTPRequestHandler, HTTPServer
from pathlib import Path
from tempfile import TemporaryDirectory


ROOT = Path(__file__).resolve().parents[1]
EXE = ROOT / "executable"


def run_cmd(*args, cwd=ROOT):
    return subprocess.run(
        [str(EXE), *args],
        cwd=cwd,
        text=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
    )


class CliTests(unittest.TestCase):
    def test_version_matches_documented_release(self):
        result = run_cmd("--version")
        self.assertEqual(result.returncode, 0)
        self.assertEqual(
            result.stdout.strip(),
            "Dirble 1.4.2 (commit d520c82, build 2026-04-17)",
        )

    def test_help_and_missing_uri_show_usage(self):
        help_result = run_cmd("--help")
        self.assertEqual(help_result.returncode, 0)
        self.assertIn("Fast directory scanning and scraping tool", help_result.stdout)
        self.assertIn("Usage: executable [OPTIONS]", help_result.stdout)
        self.assertIn("--wordlist <wordlist>", help_result.stdout)

        missing = run_cmd()
        self.assertEqual(missing.returncode, 2)
        self.assertIn("Usage: executable [OPTIONS]", missing.stdout)

    def test_scans_wordlist_with_extensions_prefixes_and_redirects(self):
        class Handler(BaseHTTPRequestHandler):
            def do_GET(self):
                responses = {
                    "/admin": (200, {}, b"admin"),
                    "/file.txt": (200, {}, b"hello"),
                    "/api.php": (200, {}, b"php"),
                    "/secret": (403, {}, b"no"),
                    "/redir": (301, {"Location": "/admin/"}, b""),
                    "/prebase": (200, {}, b"pre"),
                }
                code, headers, body = responses.get(self.path, (404, {}, b""))
                self.send_response(code)
                self.send_header("Content-Length", str(len(body)))
                for key, value in headers.items():
                    self.send_header(key, value)
                self.end_headers()
                self.wfile.write(body)

            def log_message(self, *_):
                pass

        server = HTTPServer(("127.0.0.1", 0), Handler)
        thread = threading.Thread(target=server.serve_forever, daemon=True)
        thread.start()
        try:
            with TemporaryDirectory() as tmp:
                words = Path(tmp) / "words.txt"
                words.write_text("admin\nfile\nsecret\nredir\napi\nbase\n")
                result = run_cmd(
                    f"http://127.0.0.1:{server.server_port}",
                    "-w",
                    str(words),
                    "--no-color",
                    "-x",
                    "txt,php",
                    "-p",
                    "pre",
                    "--timeout",
                    "1",
                    "-S",
                )
        finally:
            server.shutdown()
            thread.join()

        self.assertEqual(result.returncode, 0, result.stdout)
        self.assertIn("+ http://127.0.0.1:", result.stdout)
        self.assertIn("/admin (CODE:200|SIZE:5)", result.stdout)
        self.assertIn("/file.txt (CODE:200|SIZE:5)", result.stdout)
        self.assertIn("/api.php (CODE:200|SIZE:3)", result.stdout)
        self.assertIn("/secret (CODE:403|SIZE:2)", result.stdout)
        self.assertIn("/redir (CODE:301|SIZE:0|DEST:http://127.0.0.1:", result.stdout)
        self.assertIn("/prebase (CODE:200|SIZE:3)", result.stdout)

    def test_writes_text_json_and_xml_reports(self):
        class Handler(BaseHTTPRequestHandler):
            def do_GET(self):
                body = b"hello" if self.path == "/file.txt" else b""
                self.send_response(200 if body else 404)
                self.send_header("Content-Length", str(len(body)))
                self.end_headers()
                self.wfile.write(body)

            def log_message(self, *_):
                pass

        server = HTTPServer(("127.0.0.1", 0), Handler)
        thread = threading.Thread(target=server.serve_forever, daemon=True)
        thread.start()
        try:
            with TemporaryDirectory() as tmp:
                tmp_path = Path(tmp)
                words = tmp_path / "words.txt"
                words.write_text("file\n")
                txt = tmp_path / "out.txt"
                js = tmp_path / "out.json"
                xml = tmp_path / "out.xml"
                result = run_cmd(
                    f"http://127.0.0.1:{server.server_port}",
                    "-w",
                    str(words),
                    "-x",
                    "txt",
                    "-o",
                    str(txt),
                    "--json-file",
                    str(js),
                    "--xml-file",
                    str(xml),
                    "-S",
                )
                self.assertEqual(result.returncode, 0, result.stdout)
                self.assertIn("Dirble Scan Report for http://127.0.0.1:", txt.read_text())
                self.assertIn("/file.txt (CODE:200|SIZE:5)", txt.read_text())
                self.assertIn('"url":"http://127.0.0.1:', js.read_text())
                self.assertIn('"code":200', js.read_text())
                self.assertIn("<dirble_scan>", xml.read_text())
                self.assertIn('content_len="5"', xml.read_text())
        finally:
            server.shutdown()
            server.server_close()
            thread.join()

    def test_response_filtering_options(self):
        class Handler(BaseHTTPRequestHandler):
            def do_GET(self):
                bodies = {"/missing": (404, b""), "/tiny": (200, b"abc")}
                code, body = bodies.get(self.path, (404, b""))
                self.send_response(code)
                self.send_header("Content-Length", str(len(body)))
                self.end_headers()
                self.wfile.write(body)

            def log_message(self, *_):
                pass

        server = HTTPServer(("127.0.0.1", 0), Handler)
        thread = threading.Thread(target=server.serve_forever, daemon=True)
        thread.start()
        try:
            with TemporaryDirectory() as tmp:
                words = Path(tmp) / "words.txt"
                words.write_text("missing\ntiny\n")
                base = f"http://127.0.0.1:{server.server_port}"
                normal = run_cmd(base, "-w", str(words), "-S")
                self.assertNotIn("/missing (CODE:404", normal.stdout)
                self.assertIn("/tiny (CODE:200|SIZE:3)", normal.stdout)

                disabled = run_cmd(base, "-w", str(words), "--disable-validator", "-S")
                self.assertIn("/missing (CODE:404|SIZE:0)", disabled.stdout)

                hidden = run_cmd(base, "-w", str(words), "--hide-lengths", "3", "-S")
                self.assertNotIn("/tiny (CODE:200", hidden.stdout)

                whitelisted = run_cmd(base, "-w", str(words), "-W", "404", "-S")
                self.assertIn("/missing (CODE:404|SIZE:0)", whitelisted.stdout)
                self.assertNotIn("/tiny (CODE:200", whitelisted.stdout)
        finally:
            server.shutdown()
            server.server_close()
            thread.join()


if __name__ == "__main__":
    unittest.main()
