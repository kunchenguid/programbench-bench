import os
import json
import subprocess
import tempfile
import unittest


ROOT = os.path.dirname(os.path.dirname(__file__))
EXE = os.path.join(ROOT, "executable")


def run_cli(args, data=None):
    return subprocess.run(
        [EXE, *args],
        input=data,
        text=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
    )


class LightningCliTests(unittest.TestCase):
    def test_formats_css_from_file(self):
        with tempfile.TemporaryDirectory() as tmp:
            css = os.path.join(tmp, "style.css")
            with open(css, "w", encoding="utf-8") as f:
                f.write("body { color: rgb(255, 0, 0); margin: 0px 0px 0px 0px; }\n")

            result = run_cli([css])

        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertEqual(result.stdout, "body {\n  color: red;\n  margin: 0;\n}\n\n")
        self.assertEqual(result.stderr, "")

    def test_minifies_css_from_stdin(self):
        result = run_cli(["-m"], "body { color: red; margin: 0px 0px 0px 0px; }\n")

        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertEqual(result.stdout, "body{color:red;margin:0}\n")
        self.assertEqual(result.stderr, "")

    def test_minifies_nested_at_rules_and_common_values(self):
        css = (
            "@media (min-width: 500px) and (max-width: 1000px) {"
            " .foo { display: flex; user-select: none; } }"
            "@keyframes fade { from { opacity: 0; } to { opacity: 1; } }"
        )

        result = run_cli(["-m"], css)

        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertEqual(
            result.stdout,
            "@media (width>=500px) and (width<=1000px){.foo{user-select:none;display:flex}}"
            "@keyframes fade{0%{opacity:0}to{opacity:1}}\n",
        )

    def test_multiple_inputs_require_output_dir_and_write_each_file(self):
        with tempfile.TemporaryDirectory() as tmp:
            a = os.path.join(tmp, "a.css")
            b = os.path.join(tmp, "b.css")
            out_dir = os.path.join(tmp, "out")
            with open(a, "w", encoding="utf-8") as f:
                f.write("body { color: rgb(255, 0, 0); }\n")
            with open(b, "w", encoding="utf-8") as f:
                f.write(".foo { background: blue; }\n")

            refused = run_cli(["-m", a, b])
            self.assertEqual(refused.returncode, 1)
            self.assertEqual(refused.stderr, "Cannot output to stdout with multiple inputs. Use --output-dir instead.\n")

            written = run_cli(["-m", a, b, "--output-dir", out_dir])
            self.assertEqual(written.returncode, 0, written.stderr)
            self.assertEqual(open(os.path.join(out_dir, "a.css"), encoding="utf-8").read(), "body{color:red}\n")
            self.assertEqual(open(os.path.join(out_dir, "b.css"), encoding="utf-8").read(), ".foo{background:#00f}\n")

    def test_css_modules_stdout_with_pattern(self):
        with tempfile.TemporaryDirectory() as tmp:
            css = os.path.join(tmp, "mod.css")
            with open(css, "w", encoding="utf-8") as f:
                f.write(".foo { color: red; }\n.bar-baz { composes: foo; background: blue; }\n")

            result = run_cli(["--css-modules", "--css-modules-pattern", "[name]__[local]", css])

        self.assertEqual(result.returncode, 0, result.stderr)
        payload = json.loads(result.stdout)
        self.assertEqual(
            payload["code"],
            ".mod__foo {\n  color: red;\n}\n\n.mod__bar-baz {\n  background: #00f;\n}\n",
        )
        self.assertEqual(payload["exports"]["foo"]["name"], "mod__foo")
        self.assertEqual(payload["exports"]["bar-baz"]["composes"], [{"name": "mod__foo", "type": "local"}])


if __name__ == "__main__":
    unittest.main()
