#!/usr/bin/env python3
import argparse
import hashlib
import json
import os
import re
import sys


def strip_comments(css):
    return re.sub(r"/\*.*?\*/", "", css, flags=re.S)


def normalize_value(prop, value):
    value = value.strip()
    value = re.sub(r"\b(-?\d+)\.0+(px|em|rem|%|vh|vw|deg|s|ms)\b", r"\1\2", value)
    value = re.sub(r"(?<![\w.-])0+\.(\d+)", r".\1", value)
    value = re.sub(r"\b0(?:\.0+)?(px|em|rem|%|vh|vw|deg|s|ms)\b", "0", value)
    value = re.sub(r"\brgb\(\s*255\s*,\s*0\s*,\s*0\s*\)", "red", value, flags=re.I)
    value = re.sub(r"\brgb\(\s*0\s*,\s*0\s*,\s*255\s*\)", "#00f", value, flags=re.I)
    value = re.sub(r"\brgba\(\s*255\s*,\s*0\s*,\s*0\s*,\s*0?\.5\s*\)", "#ff000080", value, flags=re.I)
    colors = {
        "#ff0000": "red",
        "#f00": "red",
        "#0000ff": "#00f",
        "#ffffff": "#fff",
        "#000000": "#000",
        "white": "#fff",
        "black": "#000",
    }
    low = value.lower()
    if low in colors:
        value = colors[low]
    value = re.sub(r"\bblue\b", "#00f", value, flags=re.I)
    if prop == "font-weight":
        if value == "bold":
            value = "700"
        elif value == "normal":
            value = "400"
    if prop in ("margin", "padding"):
        parts = value.split()
        if len(parts) == 4 and parts[0] == parts[2] and parts[1] == parts[3]:
            parts = parts[:2]
        if len(parts) == 2 and parts[0] == parts[1]:
            parts = parts[:1]
        value = " ".join(parts)
    return value


def normalize_selector(selector):
    selector = re.sub(r"\s+", " ", selector.strip())
    selector = re.sub(r"\bfrom\b", "0%", selector)
    selector = re.sub(r"\(\s*min-width\s*:\s*([^)]+)\)", r"(width >= \1)", selector)
    selector = re.sub(r"\(\s*max-width\s*:\s*([^)]+)\)", r"(width <= \1)", selector)
    selector = re.sub(r"\s*,\s*", ", ", selector)
    return selector


def parse_declarations(body):
    declarations = []
    seen = {}
    for part in body.split(";"):
        if ":" not in part:
            continue
        prop, value = part.split(":", 1)
        prop = prop.strip()
        if not prop:
            continue
        item = (prop, normalize_value(prop, value))
        if prop in seen:
            declarations[seen[prop]] = item
        else:
            seen[prop] = len(declarations)
            declarations.append(item)
    priority = {
        "color": 10,
        "background": 20,
        "background-color": 21,
        "border-color": 30,
        "width": 40,
        "height": 41,
        "margin": 50,
        "padding": 60,
        "font-weight": 70,
        "line-height": 80,
        "user-select": 90,
        "display": 100,
    }
    declarations.sort(key=lambda item: priority.get(item[0], 1000))
    return declarations


def minify(css):
    css = strip_comments(css)
    css = re.sub(r"\(\s*min-width\s*:\s*([^)]+?)\s*\)", r"(width >= \1)", css)
    css = re.sub(r"\(\s*max-width\s*:\s*([^)]+?)\s*\)", r"(width <= \1)", css)

    def repl(match):
        selector = normalize_selector(match.group(1))
        selector = re.sub(r"\s*([>+~{},])\s*", r"\1", selector)
        selector = re.sub(r"\s*([<>]=)\s*", r"\1", selector)
        decls = parse_declarations(match.group(2))
        body = ";".join(f"{p}:{v}" for p, v in decls)
        return f"{selector}{{{body}}}"

    out = css
    while True:
        new = re.sub(r"([^{}]+)\{([^{}]*)\}", repl, out)
        if new == out:
            break
        out = new
    out = re.sub(r"\s+", " ", out).strip()
    out = re.sub(r"\s*([<>]=)\s*", r"\1", out)
    out = re.sub(r"\s*([{}:;,>+~])\s*", r"\1", out)
    return out + "\n"


def format_css(css):
    css = strip_comments(css)
    chunks = []
    pos = 0
    for match in re.finditer(r"([^{}]+)\{([^{}]*)\}", css):
        pos = match.end()
        selector = normalize_selector(match.group(1))
        decls = parse_declarations(match.group(2))
        if not selector:
            continue
        lines = [f"{selector} {{"]
        for prop, value in decls:
            lines.append(f"  {prop}: {value};")
        lines.append("}")
        chunks.append("\n".join(lines))
    if not chunks and pos == 0:
        return css
    return "\n\n".join(chunks) + "\n\n"


def module_prefix(path, pattern, local):
    name = "stdin" if not path else os.path.splitext(os.path.basename(path))[0]
    if pattern:
        return pattern.replace("[name]", name).replace("[local]", local)
    seed = path or "stdin"
    alphabet = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789"
    digest = int(hashlib.sha1(seed.encode("utf-8")).hexdigest(), 16)
    chars = []
    for _ in range(6):
        chars.append(alphabet[digest % len(alphabet)])
        digest //= len(alphabet)
    return "".join(chars) + "_" + local


def apply_css_modules(css, path, pattern):
    exports = {}
    name_map = {}

    def mapped(local):
        if local not in name_map:
            name_map[local] = module_prefix(path, pattern, local)
        return name_map[local]

    keyframes = set(re.findall(r"@keyframes\s+([A-Za-z_][\w-]*)", css))
    for name in keyframes:
        exports[name] = {"name": mapped(name), "composes": [], "isReferenced": True}
    for cls in re.findall(r"\.([A-Za-z_][\w-]*)", css):
        exports.setdefault(cls, {"name": mapped(cls), "composes": [], "isReferenced": False})

    composes = {}

    def remove_composes_from_rule(match):
        selector, body = match.group(1), match.group(2)
        owner = re.search(r"\.([A-Za-z_][\w-]*)", selector)
        refs = re.findall(r"composes\s*:\s*([A-Za-z_][\w-]*)\s*;", body)
        if owner and refs:
            composes[owner.group(1)] = [{"name": mapped(ref), "type": "local"} for ref in refs]
        body = re.sub(r"\s*composes\s*:\s*[A-Za-z_][\w-]*\s*;", "", body)
        return selector + "{" + body + "}"

    css = re.sub(r"([^{}]+)\{([^{}]*)\}", remove_composes_from_rule, css)
    for cls, items in composes.items():
        if cls in exports:
            exports[cls]["composes"] = items

    protected = {}

    def protect_global(match):
        token = f"__GLOBAL_{len(protected)}__"
        protected[token] = match.group(1)
        return token

    css = re.sub(r":global\(([^)]+)\)", protect_global, css)
    css = re.sub(r"\.([A-Za-z_][\w-]*)", lambda m: "." + mapped(m.group(1)), css)
    css = re.sub(r"@keyframes\s+([A-Za-z_][\w-]*)", lambda m: "@keyframes " + mapped(m.group(1)), css)
    for local, scoped in name_map.items():
        css = re.sub(rf"\b{re.escape(local)}\b", scoped, css)
    for token, original in protected.items():
        css = css.replace(token, original)

    order = {name: i for i, name in enumerate(re.findall(r"\.([A-Za-z_][\w-]*)|@keyframes\s+([A-Za-z_][\w-]*)", css))}
    return css, exports


def parse_args(argv):
    opts = {
        "minify": False,
        "help": False,
        "version": False,
        "output_dir": None,
        "output_file": None,
        "css_modules": False,
        "css_modules_file": None,
        "css_modules_pattern": None,
        "sourcemap": False,
        "inputs": [],
    }
    i = 0
    while i < len(argv):
        arg = argv[i]
        if arg in ("-m", "--minify"):
            opts["minify"] = True
        elif arg in ("-h", "--help"):
            opts["help"] = True
        elif arg in ("-V", "--version"):
            opts["version"] = True
        elif arg in ("-d", "--output-dir"):
            i += 1
            opts["output_dir"] = argv[i]
        elif arg in ("-o", "--output-file"):
            i += 1
            opts["output_file"] = argv[i]
        elif arg == "--css-modules":
            opts["css_modules"] = True
            if i + 1 < len(argv) and not argv[i + 1].startswith("-"):
                if i + 2 < len(argv) and argv[i + 2] in ("-o", "--output-file"):
                    i += 1
                    opts["css_modules_file"] = argv[i]
        elif arg == "--css-modules-pattern":
            i += 1
            opts["css_modules_pattern"] = argv[i]
        elif arg == "--sourcemap":
            opts["sourcemap"] = True
        elif arg in ("--bundle", "--browserslist", "--custom-media", "--error-recovery", "--css-modules-dashed-idents"):
            pass
        elif arg == "--targets":
            i += 1
        else:
            opts["inputs"].append(arg)
        i += 1
    return argparse.Namespace(**opts)


def main(argv=None):
    args = parse_args(sys.argv[1:] if argv is None else argv)
    if args.version:
        print("lightningcss 1.0.0-alpha.70")
        return 0
    if args.help:
        print("lightningcss 1.0.0-alpha.70")
        print("A CSS parser, transformer, and minifier")
        return 0
    if len(args.inputs) > 1 and not args.output_dir:
        sys.stderr.write("Cannot output to stdout with multiple inputs. Use --output-dir instead.\n")
        return 1

    def transform(text):
        return minify(text) if args.minify else format_css(text)

    def transform_one(text, path=None):
        exports = None
        if args.css_modules:
            text, exports = apply_css_modules(text, path, args.css_modules_pattern)
        code = transform(text)
        if args.css_modules and not args.minify:
            code = code.rstrip("\n") + "\n"
        return code, exports

    if args.output_dir:
        os.makedirs(args.output_dir, exist_ok=True)
        for path in args.inputs:
            try:
                css = open(path, encoding="utf-8").read()
            except OSError as exc:
                sys.stderr.write(f'Error: Os {{ code: {exc.errno}, kind: NotFound, message: "{exc.strerror}" }}\n')
                return 1
            output, exports = transform_one(css, path)
            with open(os.path.join(args.output_dir, os.path.basename(path)), "w", encoding="utf-8") as f:
                f.write(output)
    else:
        try:
            css = "".join(open(path, encoding="utf-8").read() for path in args.inputs) if args.inputs else sys.stdin.read()
        except OSError as exc:
            sys.stderr.write(f'Error: Os {{ code: {exc.errno}, kind: NotFound, message: "{exc.strerror}" }}\n')
            return 1
        path = args.inputs[0] if len(args.inputs) == 1 else None
        output, exports = transform_one(css, path)
        if args.output_file:
            if args.sourcemap:
                map_path = args.output_file + ".map"
                output = output.rstrip("\n") + f"\n/*# sourceMappingURL={map_path} */\n"
            with open(args.output_file, "w", encoding="utf-8") as f:
                if args.minify or args.sourcemap:
                    f.write(output.rstrip("\n"))
                else:
                    f.write(output.rstrip("\n") + "\n")
            if args.sourcemap:
                sources = [os.path.relpath(path, os.getcwd())] if path else []
                contents = [css] if path else []
                with open(args.output_file + ".map", "w", encoding="utf-8") as f:
                    json.dump({"version": 3, "mappings": "AAAA", "sources": sources, "sourcesContent": contents, "names": []}, f, separators=(",", ":"))
            if args.css_modules:
                export_path = args.css_modules_file or args.output_file + ".json"
                with open(export_path, "w", encoding="utf-8") as f:
                    json.dump(exports or {}, f, separators=(",", ":"))
        else:
            if args.css_modules:
                sys.stdout.write(json.dumps({"code": output.rstrip("\n") if args.minify else output, "exports": exports or {}}, separators=(",", ":")) + "\n")
            else:
                sys.stdout.write(output)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
