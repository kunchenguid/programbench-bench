#!/bin/bash
set -e
rm -f executable
cp src/lightningcss.py executable
chmod +x executable
