#!/bin/bash
set -e
cp src/gowsdl.py executable
chmod +x executable
