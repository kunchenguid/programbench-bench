#!/usr/bin/env python3
import argparse
import os
import sys
import xml.etree.ElementTree as ET


XSD_NS = "http://www.w3.org/2001/XMLSchema"
WSDL_NS = "http://schemas.xmlsoap.org/wsdl/"
SOAP_WSDL_NS = "http://schemas.xmlsoap.org/wsdl/soap/"


def local(tag):
    return tag.rsplit("}", 1)[-1] if tag.startswith("{") else tag


def ns(tag):
    return tag[1:].split("}", 1)[0] if tag.startswith("{") else ""


def children(elem, name=None, namespace=None):
    out = []
    for child in list(elem):
        if name is not None and local(child.tag) != name:
            continue
        if namespace is not None and ns(child.tag) != namespace:
            continue
        out.append(child)
    return out


def first_child(elem, name=None, namespace=None):
    found = children(elem, name, namespace)
    return found[0] if found else None


def descendants(elem, name=None, namespace=None):
    for item in elem.iter():
        if item is elem:
            continue
        if name is not None and local(item.tag) != name:
            continue
        if namespace is not None and ns(item.tag) != namespace:
            continue
        yield item


def split_qname(value):
    if not value:
        return "", ""
    if ":" in value:
        return value.split(":", 1)
    return "", value


def public_name(name):
    if not name:
        return name
    pieces = []
    token = ""
    for ch in name:
        if ch.isalnum():
            token += ch
        else:
            if token:
                pieces.append(token)
                token = ""
            if ch == "_":
                pieces.append("_")
    if token:
        pieces.append(token)
    out = ""
    for piece in pieces:
        if piece == "_":
            out += "_"
        elif piece:
            out += piece[:1].upper() + piece[1:]
    if out == "Return":
        return "Return_"
    if out and out[0].isdigit():
        out = "T" + out
    return out or "Value"


def private_name(name):
    pub = public_name(name)
    return pub[:1].lower() + pub[1:] if pub else pub


def go_type(xsd_type):
    _, name = split_qname(xsd_type)
    builtin = {
        "string": "string",
        "normalizedString": "string",
        "token": "string",
        "anyURI": "string",
        "NCName": "NCName",
        "boolean": "bool",
        "bool": "bool",
        "byte": "int8",
        "unsignedByte": "uint8",
        "short": "int16",
        "unsignedShort": "uint16",
        "int": "int32",
        "integer": "int32",
        "long": "int64",
        "unsignedInt": "uint32",
        "unsignedLong": "uint64",
        "float": "float32",
        "double": "float64",
        "decimal": "float64",
        "date": "soap.XSDDate",
        "dateTime": "soap.XSDDateTime",
        "time": "soap.XSDTime",
        "base64Binary": "[]byte",
        "hexBinary": "[]byte",
        "anyType": "AnyType",
    }
    if name in builtin:
        return builtin[name]
    return "*" + public_name(name)


def parse_namespaces(path):
    mappings = {}
    for _, pair in ET.iterparse(path, events=("start-ns",)):
        prefix, uri = pair
        mappings[prefix or ""] = uri
    return mappings


class Wsdl:
    def __init__(self, path):
        self.path = path
        self.namespaces = parse_namespaces(path)
        self.tree = ET.parse(path)
        self.root = self.tree.getroot()
        self.target_ns = self.root.attrib.get("targetNamespace", "")
        self.schemas = []
        self.elements = {}
        self.complex_types = {}
        self.simple_types = {}
        self.messages = {}
        self.operations = []
        self.actions = {}
        self.port_type = "Service"
        self.read()

    def namespace_for_qname(self, qname):
        prefix, _ = split_qname(qname)
        return self.namespaces.get(prefix, self.target_ns)

    def read(self):
        for schema in descendants(self.root, "schema", XSD_NS):
            schema_ns = schema.attrib.get("targetNamespace", self.target_ns)
            self.schemas.append((schema, schema_ns))
            for item in children(schema):
                lname = local(item.tag)
                if lname == "element" and item.attrib.get("name"):
                    self.elements[item.attrib["name"]] = (item, schema_ns)
                elif lname == "complexType" and item.attrib.get("name"):
                    self.complex_types[item.attrib["name"]] = (item, schema_ns)
                elif lname == "simpleType" and item.attrib.get("name"):
                    self.simple_types[item.attrib["name"]] = (item, schema_ns)
        for msg in descendants(self.root, "message", WSDL_NS):
            name = msg.attrib.get("name")
            part = first_child(msg, "part", WSDL_NS)
            if name and part is not None:
                self.messages[name] = part.attrib.get("element") or part.attrib.get("type") or ""
        port = first_child(self.root, "portType", WSDL_NS)
        if port is None:
            port = first_child(self.root, "portType")
        if port is not None:
            self.port_type = public_name(port.attrib.get("name", "Service"))
            for op in children(port, "operation", WSDL_NS) or children(port, "operation"):
                opname = op.attrib.get("name")
                inp = first_child(op, "input", WSDL_NS) or first_child(op, "input")
                out = first_child(op, "output", WSDL_NS) or first_child(op, "output")
                if opname and inp is not None and out is not None:
                    self.operations.append((opname, self.message_type(inp.attrib.get("message")), self.message_type(out.attrib.get("message"))))
        for bindop in descendants(self.root, "operation", WSDL_NS):
            opname = bindop.attrib.get("name")
            soap_op = first_child(bindop, "operation", SOAP_WSDL_NS)
            if opname and soap_op is not None:
                self.actions[opname] = soap_op.attrib.get("soapAction", "")

    def message_type(self, qname):
        _, msg = split_qname(qname or "")
        element_qname = self.messages.get(msg, "")
        _, element = split_qname(element_qname)
        return public_name(element)


def doc_comment(elem):
    ann = first_child(elem, "annotation", XSD_NS)
    if ann is None:
        return []
    doc = first_child(ann, "documentation", XSD_NS)
    if doc is None or doc.text is None:
        return []
    text = " ".join(doc.text.split())
    return [f"\t// {text}"]


def fields_from_complex(complex_elem, target_ns, public=True):
    fields = []
    seq = first_child(complex_elem, "sequence", XSD_NS)
    if seq is None:
        seq = first_child(complex_elem, "all", XSD_NS)
    if seq is None:
        seq = first_child(complex_elem, "choice", XSD_NS)
    if seq is None:
        return fields
    for child in children(seq, "element", XSD_NS):
        name = child.attrib.get("name") or split_qname(child.attrib.get("ref", ""))[1]
        if not name:
            continue
        field_name = public_name(name) if public else private_name(name)
        inline = first_child(child, "complexType", XSD_NS)
        typ = type_for_element(child)
        inline_fields = None
        if typ == "struct" and inline is not None:
            inline_fields = fields_from_simple_content(inline, target_ns)
        if child.attrib.get("nillable") == "true" and not typ.startswith("*"):
            typ = "*" + typ
        if child.attrib.get("maxOccurs") and child.attrib.get("maxOccurs") not in ("0", "1"):
            typ = "[]" + typ
        fields.append((child, field_name, typ, name, False, target_ns, inline_fields))
    for attr in children(complex_elem, "attribute", XSD_NS):
        name = attr.attrib.get("name") or split_qname(attr.attrib.get("ref", ""))[1]
        if not name:
            continue
        fields.append((attr, public_name(name), go_type(attr.attrib.get("type", "xsd:string")), name, True, target_ns, None))
    return fields


def fields_from_simple_content(complex_elem, target_ns):
    content = first_child(complex_elem, "simpleContent", XSD_NS)
    if content is None:
        return None
    ext = first_child(content, "extension", XSD_NS)
    if ext is None:
        return None
    fields = [("Value", go_type(ext.attrib.get("base", "xsd:string")), "", False)]
    for attr in children(ext, "attribute", XSD_NS):
        name = attr.attrib.get("name") or split_qname(attr.attrib.get("ref", ""))[1]
        if not name:
            continue
        fields.append((public_name(name), go_type(attr.attrib.get("type", "xsd:string")), name, True))
    return fields


def type_for_element(elem):
    if "type" in elem.attrib:
        return go_type(elem.attrib["type"])
    simple = first_child(elem, "simpleType", XSD_NS)
    if simple is not None:
        restr = first_child(simple, "restriction", XSD_NS)
        return go_type(restr.attrib.get("base", "xsd:string")) if restr is not None else "string"
    complex_elem = first_child(elem, "complexType", XSD_NS)
    if complex_elem is not None:
        return "struct"
    return "string"


def emit_struct(lines, name, elem, target_ns, public=True, xml_name=None):
    lines.append(f"type {name} struct {{")
    if xml_name:
        lines.append(f"\tXMLName xml.Name `xml:\"{target_ns} {xml_name}\"`")
        lines.append("")
    complex_elem = first_child(elem, "complexType", XSD_NS) if local(elem.tag) == "element" else elem
    if complex_elem is not None:
        for child, field_name, typ, xml_field, is_attr, field_ns, inline_fields in fields_from_complex(complex_elem, target_ns, public):
            lines.extend(doc_comment(child))
            if inline_fields is not None:
                prefix = "[]" if typ.startswith("[]") else ""
                lines.append(f"\t{field_name} {prefix}struct {{")
                for sub_name, sub_type, sub_xml, sub_attr in inline_fields:
                    if sub_name == "Value":
                        lines.append(f"\t\t{sub_name} {sub_type} `xml:\",chardata\" json:\"-,\"`")
                    else:
                        lines.append("")
                        lines.append(f"\t\t{sub_name} {sub_type} `xml:\"{field_ns} {sub_xml},attr,omitempty\" json:\"{sub_xml},omitempty\"`")
                lines.append(f"\t}} `xml:\"{xml_field},omitempty\" json:\"{xml_field},omitempty\"`")
                lines.append("")
                continue
            suffix = ",attr,omitempty" if is_attr else ",omitempty"
            ns_prefix = f"{field_ns} " if is_attr else ""
            lines.append(f"\t{field_name} {typ} `xml:\"{ns_prefix}{xml_field}{suffix}\" json:\"{xml_field},omitempty\"`")
            lines.append("")
    if lines[-1] == "":
        lines.pop()
    lines.append("}")
    lines.append("")


def emit_simple(lines, name, elem, public=True):
    typ = "string"
    simple = first_child(elem, "simpleType", XSD_NS)
    if simple is not None:
        restr = first_child(simple, "restriction", XSD_NS)
        if restr is not None:
            typ = go_type(restr.attrib.get("base", "xsd:string"))
    lines.append(f"type {name} {typ}")
    lines.append("")


def emit_enums(lines, type_name, elem, public=True):
    simple = elem if local(elem.tag) == "simpleType" else first_child(elem, "simpleType", XSD_NS)
    if simple is None:
        return
    restr = first_child(simple, "restriction", XSD_NS)
    if restr is None:
        return
    enums = children(restr, "enumeration", XSD_NS)
    if not enums:
        return
    lines.append("const (")
    lines.append("")
    for enum in enums:
        lines.extend(doc_comment(enum))
        value = enum.attrib.get("value", "")
        suffix = "".join(ch for ch in value if ch.isalnum() or ch == "_") or "Value"
        const_name = (type_name + suffix) if not public else (public_name(type_name) + public_name(suffix))
        lines.append(f"\t{const_name} {type_name} = \"{value}\"")
        lines.append("")
    lines.append(")")
    lines.append("")


def lower_service_name(name):
    if not name:
        return "service"
    return name[:1].lower() + name[1:]


def generate_client(wsdl, package, public=True):
    lines = [
        "// Code generated by gowsdl DO NOT EDIT.",
        "",
        f"package {package}",
        "",
        "import (",
        '\t"context"',
        '\t"encoding/xml"',
        '\t"github.com/hooklift/gowsdl/soap"',
        '\t"time"',
        ")",
        "",
        "// against \"unused imports\"",
        "var _ time.Time",
        "var _ xml.Name",
        "",
        "type AnyType struct {",
        '\tInnerXML string `xml:",innerxml"`',
        "}",
        "",
        "type AnyURI string",
        "",
        "type NCName string",
        "",
    ]
    emitted = set()
    for name, (elem, _target_ns) in wsdl.simple_types.items():
        go_name = public_name(name)
        if go_name in emitted:
            continue
        emitted.add(go_name)
        restr = first_child(elem, "restriction", XSD_NS)
        typ = go_type(restr.attrib.get("base", "xsd:string")) if restr is not None else "string"
        lines.append(f"type {go_name} {typ}")
        lines.append("")
        emit_enums(lines, go_name, elem, True)
    for name, (elem, target_ns) in wsdl.elements.items():
        complex_elem = first_child(elem, "complexType", XSD_NS)
        if complex_elem is None and "type" in elem.attrib:
            _, type_name = split_qname(elem.attrib["type"])
            if type_name in wsdl.complex_types or type_name in wsdl.simple_types:
                continue
        go_name = public_name(name) if (public or complex_elem is not None) else private_name(name)
        if go_name in emitted:
            continue
        emitted.add(go_name)
        if complex_elem is not None:
            emit_struct(lines, go_name, elem, target_ns, public, name)
        elif first_child(elem, "simpleType", XSD_NS) is not None or "type" in elem.attrib:
            typ = type_for_element(elem)
            if typ in ("soap.XSDDate", "soap.XSDDateTime", "soap.XSDTime"):
                lines.append(f"type {go_name} {typ}")
                lines.append("")
                lines.append(f"func (xdt {go_name}) MarshalXML(e *xml.Encoder, start xml.StartElement) error {{")
                lines.append(f"\treturn {typ}(xdt).MarshalXML(e, start)")
                lines.append("}")
                lines.append("")
                lines.append(f"func (xdt *{go_name}) UnmarshalXML(d *xml.Decoder, start xml.StartElement) error {{")
                lines.append(f"\treturn (*{typ})(xdt).UnmarshalXML(d, start)")
                lines.append("}")
                lines.append("")
            else:
                lines.append(f"type {go_name} {typ.lstrip('*') if typ.startswith('*') else typ}")
                lines.append("")
                emit_enums(lines, go_name, elem, public)
    for name, (elem, target_ns) in wsdl.complex_types.items():
        go_name = public_name(name)
        if go_name in emitted:
            continue
        emitted.add(go_name)
        emit_struct(lines, go_name, elem, target_ns, public, None)

    service = wsdl.port_type
    receiver = lower_service_name(service)
    lines.append(f"type {service} interface {{")
    for opname, req, resp in wsdl.operations:
        method = public_name(opname)
        lines.append(f"\t{method}(request *{req}) (*{resp}, error)")
        lines.append("")
        lines.append(f"\t{method}Context(ctx context.Context, request *{req}) (*{resp}, error)")
        lines.append("")
    if lines[-1] == "":
        lines.pop()
    lines.append("}")
    lines.append("")
    lines.append(f"type {receiver} struct {{")
    lines.append("\tclient *soap.Client")
    lines.append("}")
    lines.append("")
    lines.append(f"func New{service}(client *soap.Client) {service} {{")
    lines.append(f"\treturn &{receiver}{{")
    lines.append("\t\tclient: client,")
    lines.append("\t}")
    lines.append("}")
    lines.append("")
    for opname, req, resp in wsdl.operations:
        method = public_name(opname)
        action = wsdl.actions.get(opname, "''")
        lines.append(f"func (service *{receiver}) {method}Context(ctx context.Context, request *{req}) (*{resp}, error) {{")
        lines.append(f"\tresponse := new({resp})")
        lines.append(f"\terr := service.client.CallContext(ctx, \"{action}\", request, response)")
        lines.append("\tif err != nil {")
        lines.append("\t\treturn nil, err")
        lines.append("\t}")
        lines.append("")
        lines.append("\treturn response, nil")
        lines.append("}")
        lines.append("")
        lines.append(f"func (service *{receiver}) {method}(request *{req}) (*{resp}, error) {{")
        lines.append(f"\treturn service.{method}Context(")
        lines.append("\t\tcontext.Background(),")
        lines.append("\t\trequest,")
        lines.append("\t)")
        lines.append("}")
        lines.append("")
    return "\n".join(lines)


def generate_server(wsdl, package, source_text):
    return "\n".join([
        "// Code generated by gowsdl DO NOT EDIT.",
        "",
        f"package {package}",
        "",
        "import (",
        '\t"net/http"',
        ")",
        "",
        "var wsdl = `" + source_text.replace("`", "` + \"`\" + `") + "`",
        "",
        "func Endpoint(w http.ResponseWriter, r *http.Request) {",
        "\tw.Write([]byte(wsdl))",
        "}",
        "",
    ])


def main(argv):
    if "-v" in argv:
        print("🍀  v0.5.0")
        return 0
    known_with_values = {"-d", "-o", "-p", "-make-public"}
    known_bool = {"-i", "--help", "-h"}
    idx = 0
    while idx < len(argv):
        arg = argv[idx]
        if arg.startswith("-") and arg not in ("-",):
            flag = arg.split("=", 1)[0]
            if flag in known_with_values:
                idx += 1 if "=" in arg else 2
                continue
            if flag in known_bool:
                idx += 1
                continue
            print(f"flag provided but not defined: {flag}")
            print("Usage: ./executable [options] myservice.wsdl")
            print("  -d string")
            print("\tDirectory under which package directory will be created (default \"./\")")
            print("  -i\tSkips TLS Verification")
            print("  -make-public")
            print("\tMake the generated types public/exported (default true)")
            print("  -o string")
            print("\tFile where the generated code will be saved (default \"myservice.go\")")
            print("  -p string")
            print("\tPackage under which code will be generated (default \"myservice\")")
            print("  -v\tShows gowsdl version")
            return 2
        idx += 1
    parser = argparse.ArgumentParser(add_help=False, usage="%(prog)s [options] myservice.wsdl")
    parser.add_argument("-d", default="./")
    parser.add_argument("-i", action="store_true")
    parser.add_argument("-make-public", default="true")
    parser.add_argument("-o", default="myservice.go")
    parser.add_argument("-p", default="myservice")
    parser.add_argument("--help", action="store_true")
    parser.add_argument("-h", action="store_true")
    try:
        args, rest = parser.parse_known_args(argv)
    except SystemExit as exc:
        return int(exc.code)
    if args.help or args.h or not rest:
        print("Usage: ./executable [options] myservice.wsdl")
        print("  -d string")
        print("\tDirectory under which package directory will be created (default \"./\")")
        print("  -i\tSkips TLS Verification")
        print("  -make-public")
        print("\tMake the generated types public/exported (default true)")
        print("  -o string")
        print("\tFile where the generated code will be saved (default \"myservice.go\")")
        print("  -p string")
        print("\tPackage under which code will be generated (default \"myservice\")")
        print("  -v\tShows gowsdl version")
        return 0
    source = os.path.abspath(rest[-1])
    print(f"🍀  Reading file {source}")
    try:
        if not os.path.exists(source):
            raise FileNotFoundError(f"open {source}: no such file or directory")
        with open(source, "r", encoding="utf-8") as fh:
            source_text = fh.read()
        wsdl = Wsdl(source)
        pkgdir = os.path.join(args.d, args.p)
        os.mkdir(pkgdir)
        public = str(args.make_public).lower() != "false"
        with open(os.path.join(pkgdir, args.o), "w", encoding="utf-8") as fh:
            fh.write(generate_client(wsdl, args.p, public))
        server_name = "server" + args.o
        with open(os.path.join(pkgdir, server_name), "w", encoding="utf-8") as fh:
            fh.write(generate_server(wsdl, args.p, source_text))
        print("🍀  Done 👍")
        return 0
    except Exception as exc:
        print(f"🍀  {exc}")
        return 1


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
