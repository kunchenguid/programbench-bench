import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
CLI = ROOT / "src" / "i3_style.py"


def run_cli(*args, input_text=None):
    return subprocess.run(
        [sys.executable, str(CLI), *args],
        input=input_text,
        text=True,
        capture_output=True,
    )


class CliTests(unittest.TestCase):
    def test_lists_available_themes(self):
        result = run_cli("--list-all")

        self.assertEqual(result.returncode, 0)
        self.assertIn("Available themes:", result.stdout)
        self.assertIn("solarized          - Solarized theme by lasers", result.stdout)
        self.assertIn("tomorrow-night-80s - Tomorrow Night 80s theme by jmfurlott", result.stdout)

    def test_applies_solarized_to_existing_color_sections(self):
        config = """# test templating with a minimal config
font pango:Fira Mono 8

bindsym Right focus right

bar {
  colors {
    separator #111111
    background #111111
    statusline #111111
    focused_workspace #111111 #111111 #111111
    active_workspace #111111 #111111 #111111
    inactive_workspace #111111 #111111 #111111
    urgent_workspace #111111 #111111 #111111
  }
}
client.focused #111111 #111111 #111111 #111111
client.focused_inactive #111111 #111111 #111111 #111111
client.unfocused #111111 #111111 #111111 #111111
client.urgent #111111 #111111 #111111 #111111
"""
        expected = """# test templating with a minimal config
font pango:Fira Mono 8

bindsym Right focus right

bar {
  colors {
    separator #dc322f
    background #002b36
    statusline #268bd2
    focused_workspace #fdf6e3 #859900 #fdf6e3
    active_workspace #fdf6e3 #6c71c4 #fdf6e3
    inactive_workspace #586e75 #93a1a1 #002b36
    urgent_workspace #d33682 #d33682 #fdf6e3
  }
}
client.focused #859900 #859900 #fdf6e3 #6c71c4
client.focused_inactive #073642 #073642 #eee8d5 #6c71c4
client.unfocused #073642 #073642 #93a1a1 #586e75
client.urgent #d33682 #d33682 #fdf6e3 #dc322f
"""
        with tempfile.TemporaryDirectory() as tmp:
            config_path = Path(tmp) / "config"
            output_path = Path(tmp) / "out"
            config_path.write_text(config)

            result = run_cli("solarized", "-c", str(config_path), "-o", str(output_path))

            self.assertEqual(result.returncode, 0, result.stderr)
            self.assertEqual(output_path.read_text(), expected)

    def test_applies_custom_theme_file_and_leaves_unspecified_colors(self):
        config = """bar {
  colors {
    separator #111
    background #111
    statusline #111
    focused_workspace #111 #111 #111 #tail
    active_workspace #111 #111 #111
  }
}
client.focused #111 #111 #111 #111
client.unfocused #111 #111 #111 #111
"""
        theme = """---
meta:
  description: Test custom
colors:
  black: "#000000"
  white: "#ffffff"
  red: "#ff0000"
  green: "#00ff00"
  blue: "#0000ff"
window_colors:
  focused:
    border: green
    background: green
    text: white
    indicator: blue
bar_colors:
  background: black
  statusline: white
  separator: red
  focused_workspace:
    border: green
    background: blue
    text: white
"""
        expected = """bar {
  colors {
    separator #ff0000
    background #000000
    statusline #ffffff
    focused_workspace #00ff00 #0000ff #ffffff
    active_workspace #111 #111 #111
  }
}
client.focused #00ff00 #00ff00 #ffffff #0000ff
client.unfocused #111 #111 #111 #111
"""
        with tempfile.TemporaryDirectory() as tmp:
            config_path = Path(tmp) / "config"
            theme_path = Path(tmp) / "theme.yaml"
            output_path = Path(tmp) / "out"
            config_path.write_text(config)
            theme_path.write_text(theme)

            result = run_cli(str(theme_path), "-c", str(config_path), "-o", str(output_path))

            self.assertEqual(result.returncode, 0, result.stderr)
            self.assertEqual(output_path.read_text(), expected)

    def test_converts_config_to_shareable_theme_yaml(self):
        config = """bar {
  colors {
    separator #dc322f
    background #002b36
    statusline #268bd2
    focused_workspace #fdf6e3 #859900 #fdf6e3
    urgent_workspace #d33682 #d33682 #fdf6e3
  }
}
client.focused #859900 #859900 #fdf6e3 #6c71c4
client.focused_inactive #073642 #073642 #eee8d5 #6c71c4
client.unfocused #073642 #073642 #93a1a1 #586e75
client.urgent #d33682 #d33682 #fdf6e3 #dc322f
"""
        with tempfile.TemporaryDirectory() as tmp:
            config_path = Path(tmp) / "config"
            config_path.write_text(config)

            result = run_cli("--to-theme", str(config_path))

            self.assertEqual(result.returncode, 0, result.stderr)
            self.assertIn("meta:\n  description: AUTOMATICALLY GENERATED THEME", result.stdout)
            self.assertIn('  crimson: "#DC322F"', result.stdout)
            self.assertIn("  focused:\n    border: olive\n    background: olive", result.stdout)
            self.assertIn("  separator: crimson", result.stdout)


if __name__ == "__main__":
    unittest.main()
