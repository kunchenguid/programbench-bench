#!/usr/bin/env python3
import os
import re
import subprocess
import sys

THEME_DESCRIPTIONS = [
    ("slate", "Slate theme by Jody Ribton <jody@ribton.me>"),
    ("alphare", "A beige theme by Alphare"),
    ("ubuntu", "Ubuntu theme by lasers"),
    ("flat-gray", "flat gray based theme"),
    ("purple", "Purple theme by AAlakkad <http://aalakkad.me>"),
    ("archlinux", "Archlinux theme by okraits <http://okraits.de>"),
    ("default", "Default theme for i3wm <http://i3wm.org>"),
    ("debian", "Debian theme by lasers"),
    ("oceanic-next", "Theme by Valentin Weber inspired by voronianski (https://github.com/voronianski/oceanic-next-color-scheme)"),
    ("base16-tomorrow", "Base16 Tomorrow, by Chris Kempson (http://chriskempson.com)"),
    ("okraits", "A simple theme by okraits <http://okraits.de>"),
    ("icelines", "icelines theme by mbfraga"),
    ("solarized", "Solarized theme by lasers"),
    ("deep-purple", "Inspired by the Purple and Default themes. By jcpst <http://jcpst.com>"),
    ("tomorrow-night-80s", "Tomorrow Night 80s theme by jmfurlott <http://jmfurlott.com>"),
    ("seti", "seti theme by Jody Ribton - based on the seti Atom theme at https://atom.io/themes/seti-ui"),
    ("lime", "Lime theme by wei2912 <http://wei2912.github.io>, based on Archlinux theme by okraits <http://okraits.de>"),
    ("gruvbox", "Made by freeware-preacher <https://github.com/freeware-preacher> to match gruvbox by morhetz <https://github.com/morhetz>"),
    ("mate", "Theme for blending i3 into MATE"),
]

THEMES = {}


def add_theme(name, bar_lines, client_lines):
    bar = {}
    client = {}
    for line in bar_lines.strip().splitlines():
        parts = line.split()
        bar[parts[0]] = parts[1:]
    for line in client_lines.strip().splitlines():
        parts = line.split()
        client[parts[0]] = parts[1:]
    THEMES[name] = {"bar": bar, "client": client}


add_theme("solarized", """
separator #dc322f
background #002b36
statusline #268bd2
focused_workspace #fdf6e3 #859900 #fdf6e3
active_workspace #fdf6e3 #6c71c4 #fdf6e3
inactive_workspace #586e75 #93a1a1 #002b36
urgent_workspace #d33682 #d33682 #fdf6e3
""", """
client.focused #859900 #859900 #fdf6e3 #6c71c4
client.focused_inactive #073642 #073642 #eee8d5 #6c71c4
client.unfocused #073642 #073642 #93a1a1 #586e75
client.urgent #d33682 #d33682 #fdf6e3 #dc322f
""")

_THEME_DATA = {
    "slate": ("""separator #586e75
background #002b36
statusline #aea79f
focused_workspace #586e75 #586e75 #ffffff
active_workspace #073642 #073642 #ffffff
inactive_workspace #002b36 #002b36 #aea79f
urgent_workspace #77216f #77216f #ffffff""", """client.focused #586e75 #586e75 #fdf6e3 #268bd2
client.focused_inactive #073642 #073642 #93a1a1 #002b36
client.unfocused #002b36 #002b36 #586e75 #002b36
client.urgent #dc322f #dc322f #fdf6e3 #dc322f"""),
    "alphare": ("""separator #000000
background #FDF6E3
statusline #002B36
focused_workspace #000000 #268BD2 #FFFFFF
active_workspace #333333 #222222 #FFFFFF
inactive_workspace #333333 #222222 #888888
urgent_workspace #2F343A #900000 #FFFFFF""", """client.focused #000000 #FDF6E3 #002B36 #000000
client.focused_inactive #000000 #5F676A #FDF6E3 #484E50
client.unfocused #000000 #000000 #FDF6E3 #000000
client.urgent #000000 #DC322F #FDF6E3 #DC322F"""),
    "ubuntu": ("""separator #333333
background #2c001e
statusline #aea79f
focused_workspace #dd4814 #dd4814 #ffffff
active_workspace #902a07 #902a07 #aea79f
inactive_workspace #902a07 #902a07 #aea79f
urgent_workspace #77216f #77216f #ffffff""", """client.focused #dd4814 #dd4814 #ffffff #902a07
client.focused_inactive #5e2750 #5e2750 #aea79f #5e2750
client.unfocused #5e2750 #5e2750 #aea79f #5e2750
client.urgent #77216f #77216f #ffffff #efb73e"""),
    "flat-gray": ("""separator #111111
background #333333
statusline #AAAAAA
focused_workspace #282828 #282828 #FFFFFF
active_workspace #111111 #111111 #111111
inactive_workspace #333333 #333333 #AAAAAA
urgent_workspace #111111 #111111 #111111""", """client.focused #000000 #000000 #FFFFFF #000000
client.focused_inactive #333333 #333333 #FFFFFF #000000
client.unfocused #333333 #333333 #FFFFFF #333333
client.urgent #111111 #111111 #111111 #111111"""),
    "purple": ("""separator #AAAAAA
background #222133
statusline #FFFFFF
focused_workspace #664477 #664477 #cccccc
active_workspace #DCCD69 #DCCD69 #181715
inactive_workspace #222133 #222133 #AAAAAA
urgent_workspace #CE4045 #CE4045 #FFFFFF""", """client.focused #664477 #664477 #cccccc #e7d8b1
client.focused_inactive #e7d8b1 #e7d8b1 #181715 #A074C4
client.unfocused #222133 #222133 #AAAAAA #A074C4
client.urgent #CE4045 #CE4045 #e7d8b1 #DCCD69"""),
    "archlinux": ("""separator #666666
background #222222
statusline #dddddd
focused_workspace #0088CC #0088CC #ffffff
active_workspace #333333 #333333 #ffffff
inactive_workspace #333333 #333333 #888888
urgent_workspace #2f343a #900000 #ffffff""", """client.focused #0088CC #0088CC #ffffff #dddddd
client.focused_inactive #333333 #333333 #888888 #292d2e
client.unfocused #333333 #333333 #888888 #292d2e
client.urgent #2f343a #900000 #ffffff #900000"""),
    "default": ("""separator #666666
background #000000
statusline #ffffff
focused_workspace #4c7899 #285577 #ffffff
active_workspace #333333 #5f676a #ffffff
inactive_workspace #333333 #222222 #888888
urgent_workspace #2f343a #900000 #ffffff""", """client.focused #4c7899 #285577 #ffffff #2e9ef4
client.focused_inactive #333333 #5f676a #ffffff #484e50
client.unfocused #333333 #222222 #888888 #292d2e
client.urgent #2f343a #900000 #ffffff #900000"""),
    "debian": ("""separator #444444
background #222222
statusline #666666
focused_workspace #d70a53 #d70a53 #ffffff
active_workspace #333333 #333333 #888888
inactive_workspace #333333 #333333 #888888
urgent_workspace #eb709b #eb709b #ffffff""", """client.focused #d70a53 #d70a53 #ffffff #8c0333
client.focused_inactive #333333 #333333 #888888 #333333
client.unfocused #333333 #333333 #888888 #333333
client.urgent #eb709b #eb709b #ffffff #eb709b"""),
    "oceanic-next": ("""separator #65737E
background #1B2B34
statusline #D8DEE9
focused_workspace #6699CC #6699CC #1B2B34
active_workspace #5FB3B3 #5FB3B3 #1B2B34
inactive_workspace #343D46 #343D46 #D8DEE9
urgent_workspace #EC5f67 #EC5f67 #1B2B34""", """client.focused #6699CC #6699CC #1B2B34 #6699CC
client.focused_inactive #5FB3B3 #5FB3B3 #D8DEE9 #A7ADBA
client.unfocused #343D46 #343D46 #D8DEE9 #343D46
client.urgent #EC5f67 #EC5f67 #1B2B34 #EC5f67"""),
    "base16-tomorrow": ("""separator #969896
background #1d1f21
statusline #c5c8c6
focused_workspace #81a2be #81a2be #1d1f21
active_workspace #373b41 #373b41 #ffffff
inactive_workspace #282a2e #282a2e #969896
urgent_workspace #cc6666 #cc6666 #ffffff""", """client.focused #81a2be #81a2be #1d1f21 #282a2e
client.focused_inactive #373b41 #373b41 #969896 #282a2e
client.unfocused #282a2e #282a2e #969896 #282a2e
client.urgent #373b41 #cc6666 #ffffff #cc6666"""),
    "okraits": ("""separator #666666
background #333333
statusline #bbbbbb
focused_workspace #888888 #dddddd #222222
active_workspace #333333 #555555 #bbbbbb
inactive_workspace #333333 #555555 #bbbbbb
urgent_workspace #2f343a #900000 #ffffff""", """client.focused #888888 #dddddd #222222 #2e9ef4
client.focused_inactive #333333 #555555 #bbbbbb #484e50
client.unfocused #333333 #333333 #888888 #292d2e
client.urgent #2f343a #900000 #ffffff #900000"""),
    "icelines": ("""separator #7d7d7d
background #141414
statusline #00b0ef
focused_workspace #00b0ef #141414 #00b0ef
active_workspace #141414 #141414 #00b0ef
inactive_workspace #141414 #141414 #7d7d7d
urgent_workspace #ff7066 #141414 #ff7066""", """client.focused #00b0ef #00b0ef #141414 #ff7066
client.focused_inactive #141414 #141414 #00b0ef #472b2a
client.unfocused #141414 #141414 #7d7d7d #141414
client.urgent #ff7066 #ff7066 #141414 #ff7066"""),
    "deep-purple": ("""separator #666666
background #000000
statusline #ffffff
focused_workspace #551a8b #551a8b #ffffff
active_workspace #333333 #5f676a #ffffff
inactive_workspace #000000 #000000 #888888
urgent_workspace #2f343a #900000 #ffffff""", """client.focused #3b1261 #3b1261 #ffffff #662b9c
client.focused_inactive #333333 #5f676a #ffffff #484e50
client.unfocused #222222 #222222 #888888 #292d2e
client.urgent #2f343a #900000 #ffffff #900000"""),
    "tomorrow-night-80s": ("""separator #515151
background #2d2d2d
statusline #cccccc
focused_workspace #99cc99 #99cc99 #000000
active_workspace #333333 #333333 #ffffff
inactive_workspace #2d2d2d #2d2d2d #999999
urgent_workspace #f2777a #f2777a #ffffff""", """client.focused #99cc99 #99cc99 #000000 #2d2d2d
client.focused_inactive #393939 #393939 #888888 #292d2e
client.unfocused #2d2d2d #2d2d2d #999999 #292d2e
client.urgent #2f343a #900000 #ffffff #900000"""),
    "seti": ("""separator #AAAAAA
background #1f2326
statusline #FFFFFF
focused_workspace #9FCA56 #9FCA56 #151718
active_workspace #DCCD69 #DCCD69 #151718
inactive_workspace #1f2326 #1f2326 #AAAAAA
urgent_workspace #CE4045 #CE4045 #FFFFFF""", """client.focused #4F99D3 #4F99D3 #151718 #9FCA56
client.focused_inactive #9FCA56 #9FCA56 #151718 #A074C4
client.unfocused #1f2326 #1f2326 #AAAAAA #A074C4
client.urgent #CE4045 #CE4045 #FFFFFF #DCCD69"""),
    "lime": ("""separator #888888
background #333333
statusline #FFFFFF
focused_workspace #4E9C00 #4E9C00 #FFFFFF
active_workspace #333333 #333333 #FFFFFF
inactive_workspace #333333 #333333 #888888
urgent_workspace #C20000 #C20000 #FFFFFF""", """client.focused #4E9C00 #4E9C00 #FFFFFF #FFFFFF
client.focused_inactive #1B3600 #1B3600 #888888 #FFFFFF
client.unfocused #333333 #333333 #888888 #FFFFFF
client.urgent #C20000 #C20000 #FFFFFF #FFFFFF"""),
    "gruvbox": ("""separator #928374
background #282828
statusline #ebdbb2
focused_workspace #689d6a #689d6a #282828
active_workspace #1d2021 #1d2021 #928374
inactive_workspace #32302f #32302f #928374
urgent_workspace #cc241d #cc241d #ebdbb2""", """client.focused #689d6a #689d6a #282828 #282828
client.focused_inactive #1d2021 #1d2021 #928374 #282828
client.unfocused #32302f #32302f #928374 #282828
client.urgent #cc241d #cc241d #ebdbb2 #282828"""),
    "mate": ("""separator #ffffff
background #3c3b37
statusline #ffffff
focused_workspace #526532 #526532 #ffffff
active_workspace #aea79f #aea79f #3c3b37
inactive_workspace #3c3b37 #3c3b37 #aea79f
urgent_workspace #FF0000 #FF0000 #ffffff""", """client.focused #526532 #526532 #ffffff #a4cb64
client.focused_inactive #aea79f #aea79f #3c3b37 #aea79f
client.unfocused #3c3b37 #3c3b37 #aea79f #3c3b37
client.urgent #FF0000 #FF0000 #ffffff #FF0000"""),
}

for _name, (_bar, _client) in _THEME_DATA.items():
    add_theme(_name, _bar, _client)

BAR_KEYS = {
    "separator",
    "background",
    "statusline",
    "focused_workspace",
    "active_workspace",
    "inactive_workspace",
    "urgent_workspace",
}

CLIENT_FIELDS = ["border", "background", "text", "indicator"]
WORKSPACE_FIELDS = ["border", "background", "text"]
HEX_NAMES = {
    "#DC322F": "crimson",
    "#002B36": "darkslategray",
    "#268BD2": "steelblue",
    "#FDF6E3": "oldlace",
    "#859900": "olive",
    "#586E75": "dimgray",
    "#93A1A1": "darkgray",
    "#D33682": "mediumvioletred",
    "#6C71C4": "slateblue",
    "#073642": "darkslategray-1",
    "#EEE8D5": "antiquewhite",
}

HELP = """i3-style 1.0
Make your i3 config a bit more stylish

USAGE:
    executable [FLAGS] [OPTIONS] [theme]

FLAGS:
    -h, --help        Prints help information
    -l, --list-all    Print a list of all available themes
    -r, --reload      Apply the theme by reloading the config
    -s, --save        Set the output file to the path of the input file
    -V, --version     Prints version information

OPTIONS:
    -c, --config <file>      The config file the theme should be applied to. Defaults to the default i3 location.
    -o, --output <file>      Apply the theme, attempt to validate the result, and write it to <file>
    -t, --to-theme <file>    Prints an i3-style theme based on the given config suitable for sharing with others
                             [default: ]

ARGS:
    <theme>    The theme to use
"""


def clean_scalar(value):
    value = value.strip()
    if value.startswith('"') and value.endswith('"'):
        return value[1:-1]
    if value.startswith("'") and value.endswith("'"):
        return value[1:-1]
    return value


def parse_theme_file(path):
    colors = {}
    theme = {"bar": {}, "client": {}}
    section = None
    group = None
    with open(path, "r", encoding="utf-8") as f:
        for raw in f:
            if not raw.strip() or raw.strip() == "---" or raw.lstrip().startswith("#"):
                continue
            indent = len(raw) - len(raw.lstrip(" "))
            stripped = raw.strip()
            if not stripped.endswith(":") and ":" not in stripped:
                continue
            if indent == 0 and stripped.endswith(":"):
                section = stripped[:-1]
                group = None
                continue
            if section == "colors" and indent == 2 and ":" in stripped:
                name, value = stripped.split(":", 1)
                colors[name.strip()] = clean_scalar(value)
                continue
            if section == "window_colors":
                if indent == 2 and stripped.endswith(":"):
                    group = "client." + stripped[:-1]
                    theme["client"].setdefault(group, {})
                elif indent == 4 and group and ":" in stripped:
                    name, value = stripped.split(":", 1)
                    theme["client"][group][name.strip()] = clean_scalar(value)
                continue
            if section == "bar_colors":
                if indent == 2 and ":" in stripped:
                    name, value = stripped.split(":", 1)
                    name = name.strip()
                    value = value.strip()
                    if value:
                        theme["bar"][name] = [clean_scalar(value)]
                        group = None
                    else:
                        group = name
                        theme["bar"].setdefault(group, {})
                elif indent == 4 and group and ":" in stripped:
                    name, value = stripped.split(":", 1)
                    theme["bar"][group][name.strip()] = clean_scalar(value)

    def resolve(value):
        return colors.get(value, value)

    for key, values in list(theme["client"].items()):
        if isinstance(values, dict):
            ordered = [resolve(values[field]) for field in CLIENT_FIELDS if field in values]
            if len(ordered) == 4:
                theme["client"][key] = ordered
            else:
                del theme["client"][key]
    for key, values in list(theme["bar"].items()):
        if isinstance(values, dict):
            ordered = [resolve(values[field]) for field in WORKSPACE_FIELDS if field in values]
            if len(ordered) == 3:
                theme["bar"][key] = ordered
            else:
                del theme["bar"][key]
        else:
            theme["bar"][key] = [resolve(values[0])]
    return theme


def apply_theme(config_text, theme):
    output = []
    in_bar = False
    in_colors = False
    seen_clients = set()
    for raw_line in config_text.splitlines():
        stripped = raw_line.strip()
        if stripped == "bar {":
            in_bar = True
        elif in_bar and stripped == "colors {":
            in_colors = True
        elif stripped == "}":
            if in_colors:
                in_colors = False
            elif in_bar:
                in_bar = False

        parts = stripped.split()
        key = parts[0] if parts else ""
        if in_colors and key in BAR_KEYS and key in theme["bar"]:
            replacement = theme["bar"][key]
            extra = [p for p in parts[1 + len(replacement):] if re.fullmatch(r"#[0-9A-Fa-f]{3,8}", p)]
            output.append(f"    {key} {' '.join(replacement + extra)}")
        elif key in theme["client"]:
            output.append(f"{key} {' '.join(theme['client'][key])}")
            seen_clients.add(key)
        else:
            output.append(raw_line)

    for key in ["client.focused", "client.focused_inactive", "client.unfocused", "client.urgent"]:
        if key not in seen_clients and key in theme["client"]:
            output.append(f"{key} {' '.join(theme['client'][key])}")
    return "\n".join(output) + ("\n" if config_text.endswith("\n") else "")


def color_name(hex_value, used):
    upper = hex_value.upper()
    base = HEX_NAMES.get(upper, "color" + upper.lstrip("#").lower())
    name = base
    n = 1
    while name in used and used[name] != upper:
        name = f"{base}-{n}"
        n += 1
    used[name] = upper
    return name


def extract_theme(config_text):
    used = {}
    client = {}
    bar = {}
    in_bar = False
    in_colors = False
    for raw in config_text.splitlines():
        stripped = raw.strip()
        if stripped == "bar {":
            in_bar = True
        elif in_bar and stripped == "colors {":
            in_colors = True
        elif stripped == "}":
            if in_colors:
                in_colors = False
            elif in_bar:
                in_bar = False
        parts = stripped.split()
        if not parts:
            continue
        key = parts[0]
        colors = [p for p in parts[1:] if re.fullmatch(r"#[0-9A-Fa-f]{6}", p)]
        if key.startswith("client.") and len(colors) >= 4:
            client[key.removeprefix("client.")] = [color_name(c, used) for c in colors[:4]]
        elif in_colors and key in BAR_KEYS:
            needed = 1 if key in ("separator", "background", "statusline") else 3
            if len(colors) >= needed:
                bar[key] = [color_name(c, used) for c in colors[:needed]]

    lines = [
        "---",
        "meta:",
        "  description: AUTOMATICALLY GENERATED THEME",
        "colors:",
    ]
    for name, hex_value in used.items():
        lines.append(f'  {name}: "{hex_value}"')
    lines.append("window_colors:")
    for key in ["focused", "focused_inactive", "unfocused", "urgent"]:
        if key in client:
            lines.append(f"  {key}:")
            for field, value in zip(CLIENT_FIELDS, client[key]):
                lines.append(f"    {field}: {value}")
    lines.append("bar_colors:")
    for key in ["background", "statusline", "separator"]:
        if key in bar:
            lines.append(f"  {key}: {bar[key][0]}")
    for key in ["focused_workspace", "active_workspace", "inactive_workspace", "urgent_workspace"]:
        if key in bar:
            lines.append(f"  {key}:")
            for field, value in zip(WORKSPACE_FIELDS, bar[key]):
                lines.append(f"    {field}: {value}")
    return "\n".join(lines) + "\n"


def main(argv=None):
    argv = list(sys.argv[1:] if argv is None else argv)
    if "--help" in argv or "-h" in argv:
        sys.stdout.write(HELP)
        return 0
    if "--version" in argv or "-V" in argv:
        print("i3-style 1.0")
        return 0
    if "--list-all" in argv or "-l" in argv:
        print("\nAvailable themes:\n")
        width = max(len(name) for name, _ in THEME_DESCRIPTIONS)
        for name, desc in THEME_DESCRIPTIONS:
            print(f"  {name:<{width}} - {desc}")
        return 0
    if "--to-theme" in argv or "-t" in argv:
        opt = "--to-theme" if "--to-theme" in argv else "-t"
        idx = argv.index(opt)
        if idx + 1 >= len(argv):
            return 1
        with open(argv[idx + 1], "r", encoding="utf-8") as f:
            yaml_text = extract_theme(f.read())
        output_path = None
        if "-o" in argv:
            output_path = argv[argv.index("-o") + 1]
        elif "--output" in argv:
            output_path = argv[argv.index("--output") + 1]
        if output_path:
            with open(output_path, "w", encoding="utf-8") as f:
                f.write(yaml_text)
        else:
            sys.stdout.write(yaml_text)
        return 0
    theme_name = None
    config_path = None
    output_path = None
    save = False
    reload_i3 = False
    i = 0
    while i < len(argv):
        arg = argv[i]
        if arg in ("-c", "--config"):
            i += 1
            config_path = argv[i]
        elif arg in ("-o", "--output"):
            i += 1
            output_path = argv[i]
        elif arg in ("-s", "--save"):
            save = True
        elif arg in ("-r", "--reload"):
            reload_i3 = True
        elif not arg.startswith("-") and theme_name is None:
            theme_name = arg
        i += 1
    if not theme_name:
        sys.stderr.write("USAGE:\n    executable [FLAGS] [OPTIONS] [theme]\n\nSelect a theme as the first argument. Use `--list-all` to see the themes.\n")
        return 1
    if not config_path:
        for candidate in (os.path.expanduser("~/.config/i3/config"), os.path.expanduser("~/.i3/config")):
            if os.path.exists(candidate):
                config_path = candidate
                break
    if save and config_path:
        output_path = config_path
    if not config_path or not os.path.exists(config_path):
        sys.stderr.write("Could not find i3 config\n")
        return 1
    if not output_path:
        sys.stderr.write("Could not find i3 config\n")
        return 1
    if theme_name and config_path and output_path:
        theme = THEMES.get(theme_name)
        if theme is None and os.path.exists(theme_name):
            theme = parse_theme_file(theme_name)
        if theme is None:
            sys.stderr.write(f"Could not open theme: {theme_name} - No such file or directory (os error 2)\n Use `i3-style --list-all` to see the available themes.\n")
            return 1
        with open(config_path, "r", encoding="utf-8") as f:
            config_text = f.read()
        with open(output_path, "w", encoding="utf-8") as f:
            f.write(apply_theme(config_text, theme))
        if reload_i3:
            subprocess.run(["i3-msg", "reload"], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
