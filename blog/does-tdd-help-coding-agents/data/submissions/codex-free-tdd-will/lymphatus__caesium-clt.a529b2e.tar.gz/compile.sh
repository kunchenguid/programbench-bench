#!/bin/bash
set -e
cp src/caesiumclt.py executable
chmod +x executable
