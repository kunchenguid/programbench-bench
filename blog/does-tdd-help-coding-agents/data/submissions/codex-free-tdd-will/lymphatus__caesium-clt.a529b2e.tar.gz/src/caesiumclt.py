#!/usr/bin/env python3
import os
import re
import shutil
import struct
import sys
import zlib
from pathlib import Path

VERSION = "caesiumclt 1.3.0"
FORMATS = {"jpeg", "png", "gif", "webp", "tiff", "original"}
EXT_FORMAT = {
    ".jpg": "jpeg",
    ".jpeg": "jpeg",
    ".png": "png",
    ".gif": "gif",
    ".webp": "webp",
}

HELP_SHORT = """A fast and efficient lossy and/or lossless image compression tool

Usage: executable [OPTIONS] <--quality <QUALITY>|--lossless|--max-size <MAX_SIZE>> <--output <OUTPUT>|--same-folder-as-input> [FILES]...

Arguments:
  [FILES]...  Input files or directories to process

Options:
  -q, --quality <QUALITY>
          Compression quality [0-100], higher values mean better quality
      --lossless
          Use lossless compression (may increase file size for some formats)
      --max-size <MAX_SIZE>
          Target maximum file size in bytes or human-readable format (e.g., 100KB, 0.5MB)
      --width <WIDTH>
          Output image width in pixels (preserves the aspect ratio if height not set)
      --height <HEIGHT>
          Output image height in pixels (preserves the aspect ratio if width not set)
      --long-edge <LONG_EDGE>
          Size in pixels for the longest edge of the image
      --short-edge <SHORT_EDGE>
          Size in pixels for the shortest edge of the image
      --no-upscale
          Prevents upscaling of the image when resizing
  -o, --output <OUTPUT>
          Output directory path
      --same-folder-as-input
          Use input file's directory as output (WARNING: may overwrite originals)
      --format <FORMAT>
          Convert to the selected output format or keep the original [default: original] [possible values: jpeg, png, gif, webp, tiff, original]
      --png-opt-level <PNG_OPT_LEVEL>
          PNG optimization level [0-6], higher values provide better compression [default: 3]
      --jpeg-chroma-subsampling <JPEG_CHROMA_SUBSAMPLING>
          Chroma subsampling for JPEG files [default: auto] [possible values: 4:4:4, 4:2:2, 4:2:0, 4:1:1, auto]
      --jpeg-baseline
          Output baseline JPEG instead of progressive (default)
      --zopfli
          Use zopfli for PNG optimization (significantly slower but better compression)
  -e, --exif
          Keep EXIF metadata during compression
      --keep-dates
          Preserve original file timestamps
      --strip-icc
          Strips ICC profile info on JPG files, ignoring the -e flag
      --suffix <SUFFIX>
          Add suffix to output filenames
  -R, --recursive
          Scan subfolders recursively when input is a directory
  -S, --keep-structure
          Preserve directory structure (requires -R/--recursive)
  -d, --dry-run
          Simulate compression without writing files
      --threads <THREADS>
          Number of parallel jobs (0 = auto-detect, max = available processors) [default: 0]
  -O, --overwrite <OVERWRITE>
          Policy for handling existing output files [default: all] [possible values: all, never, bigger]
      --min-savings <MIN_SAVINGS>
          Minimum compression savings required to write an output file. Use percentage (e.g., '10%', '1.5%'), absolute size (e.g., '100KB', '1MB'), or plain number as bytes
  -Q, --quiet
          Suppress all output
      --verbose <VERBOSE>
          Verbosity level: 0 = quiet, 1 = progress only, 2 = errors only, 3 = all [default: 1]
  -h, --help
          Print help (see more with '--help')
  -V, --version
          Print version
"""


class UsageError(Exception):
    pass


def die(message, usage=None):
    sys.stderr.write(f"error: {message}\n")
    if usage:
        sys.stderr.write(f"\nUsage: executable {usage}\n")
    sys.stderr.write("\nFor more information, try '--help'.\n")
    return 2


def parse_size(text):
    m = re.fullmatch(r"([0-9]+(?:\.[0-9]+)?)([A-Za-z%]*)", text)
    if not m:
        raise UsageError(
            f"invalid value '{text}' for '--max-size <MAX_SIZE>': Invalid size format: couldn't parse \"{text}\" into a ByteSize, cannot parse float from empty string"
        )
    val = float(m.group(1))
    unit = m.group(2).lower()
    units = {
        "": 1,
        "b": 1,
        "kb": 1000,
        "mb": 1000 * 1000,
        "gb": 1000 * 1000 * 1000,
        "kib": 1024,
        "mib": 1024 * 1024,
        "gib": 1024 * 1024 * 1024,
    }
    if unit not in units:
        raise UsageError(f"invalid value '{text}' for '--max-size <MAX_SIZE>': Invalid size format")
    return int(val * units[unit])


def parse_savings(text):
    if text.endswith("%"):
        return ("percent", float(text[:-1]))
    return ("bytes", parse_size(text))


def expand_short_flags(argv):
    expanded = []
    groupable = set("RSdQe")
    for arg in argv:
        if len(arg) > 2 and arg.startswith("-") and not arg.startswith("--") and all(c in groupable for c in arg[1:]):
            expanded.extend("-" + c for c in arg[1:])
        else:
            expanded.append(arg)
    return expanded


def parse_args(argv):
    argv = expand_short_flags(argv)
    opts = {
        "quality": None,
        "lossless": False,
        "max_size": None,
        "output": None,
        "same_folder": False,
        "format": "original",
        "png_opt": 3,
        "suffix": "",
        "recursive": False,
        "keep_structure": False,
        "dry_run": False,
        "quiet": False,
        "verbose": 1,
        "overwrite": "all",
        "min_savings": None,
        "keep_dates": False,
        "width": None,
        "height": None,
        "long_edge": None,
        "short_edge": None,
        "no_upscale": False,
    }
    files = []
    i = 0
    while i < len(argv):
        a = argv[i]
        def need():
            nonlocal i
            if i + 1 >= len(argv):
                raise UsageError(f"a value is required for '{a}' but none was supplied")
            i += 1
            return argv[i]
        if a in ("-h", "--help"):
            print(HELP_SHORT, end="")
            raise SystemExit(0)
        if a in ("-V", "--version"):
            print(VERSION)
            raise SystemExit(0)
        elif a in ("-q", "--quality"):
            v = need()
            try:
                q = int(v)
            except ValueError:
                raise UsageError(f"invalid value '{v}' for '--quality <QUALITY>'")
            if not 0 <= q <= 100:
                raise UsageError(f"invalid value '{v}' for '--quality <QUALITY>': Quality must be between 0 and 100, but got {v}")
            opts["quality"] = q
        elif a == "--lossless":
            opts["lossless"] = True
        elif a == "--max-size":
            v = need()
            opts["max_size"] = parse_size(v)
        elif a in ("-o", "--output"):
            opts["output"] = need()
        elif a == "--same-folder-as-input":
            opts["same_folder"] = True
        elif a == "--format":
            v = need()
            if v not in FORMATS:
                raise UsageError(f"invalid value '{v}' for '--format <FORMAT>'\n  [possible values: jpeg, png, gif, webp, tiff, original]")
            opts["format"] = v
        elif a == "--png-opt-level":
            v = need()
            n = int(v)
            if not 0 <= n <= 6:
                raise UsageError(f"invalid value '{v}' for '--png-opt-level <PNG_OPT_LEVEL>': PNG optimization level must be between 0 and 6, but got {v}")
            opts["png_opt"] = n
        elif a == "--suffix":
            opts["suffix"] = need()
        elif a in ("-R", "--recursive"):
            opts["recursive"] = True
        elif a in ("-S", "--keep-structure"):
            opts["keep_structure"] = True
        elif a in ("-d", "--dry-run"):
            opts["dry_run"] = True
        elif a in ("-Q", "--quiet"):
            opts["quiet"] = True
        elif a == "--verbose":
            opts["verbose"] = int(need())
        elif a in ("-O", "--overwrite"):
            v = need()
            if v not in {"all", "never", "bigger"}:
                raise UsageError(f"invalid value '{v}' for '--overwrite <OVERWRITE>'")
            opts["overwrite"] = v
        elif a == "--min-savings":
            opts["min_savings"] = parse_savings(need())
        elif a == "--keep-dates":
            opts["keep_dates"] = True
        elif a == "--width":
            opts["width"] = need()
        elif a == "--height":
            opts["height"] = need()
        elif a == "--long-edge":
            opts["long_edge"] = need()
        elif a == "--short-edge":
            opts["short_edge"] = need()
        elif a in ("--threads", "--jpeg-chroma-subsampling"):
            need()
        elif a == "--no-upscale":
            opts["no_upscale"] = True
        elif a in ("--jpeg-baseline", "--zopfli", "-e", "--exif", "--strip-icc"):
            pass
        elif a.startswith("-"):
            raise UsageError(f"unexpected argument '{a}' found")
        else:
            files.append(a)
        i += 1

    modes = sum([opts["quality"] is not None, opts["lossless"], opts["max_size"] is not None])
    dests = sum([opts["output"] is not None, opts["same_folder"]])
    if modes == 0 or dests == 0:
        missing = []
        if modes == 0:
            missing.append("  <--quality <QUALITY>|--lossless|--max-size <MAX_SIZE>>")
        if dests == 0:
            missing.append("  <--output <OUTPUT>|--same-folder-as-input>")
        raise UsageError("the following required arguments were not provided:\n" + "\n".join(missing))
    if modes > 1:
        raise UsageError("the argument '--quality <QUALITY>' cannot be used with '--lossless'")
    if dests > 1:
        raise UsageError("the argument '--output <OUTPUT>' cannot be used with '--same-folder-as-input'")
    if opts["width"] is not None and opts["long_edge"] is not None:
        raise UsageError("the argument '--width <WIDTH>' cannot be used with '--long-edge <LONG_EDGE>'")
    if opts["width"] is not None and opts["short_edge"] is not None:
        raise UsageError("the argument '--width <WIDTH>' cannot be used with '--short-edge <SHORT_EDGE>'")
    if opts["height"] is not None and opts["long_edge"] is not None:
        raise UsageError("the argument '--height <HEIGHT>' cannot be used with '--long-edge <LONG_EDGE>'")
    if opts["height"] is not None and opts["short_edge"] is not None:
        raise UsageError("the argument '--height <HEIGHT>' cannot be used with '--short-edge <SHORT_EDGE>'")
    if opts["long_edge"] is not None and opts["short_edge"] is not None:
        raise UsageError("the argument '--long-edge <LONG_EDGE>' cannot be used with '--short-edge <SHORT_EDGE>'")
    return opts, files


def read_png_chunks(data):
    if not data.startswith(b"\x89PNG\r\n\x1a\n"):
        raise ValueError("not png")
    pos = 8
    chunks = []
    while pos + 8 <= len(data):
        ln = struct.unpack(">I", data[pos:pos + 4])[0]
        typ = data[pos + 4:pos + 8]
        payload = data[pos + 8:pos + 8 + ln]
        pos += 12 + ln
        chunks.append((typ, payload))
        if typ == b"IEND":
            break
    return chunks


def png_recompress(data, level):
    if not data.startswith(b"\x89PNG\r\n\x1a\n"):
        return data
    chunks = read_png_chunks(data)
    out = bytearray(data[:8])
    idat = bytearray()
    other = []
    for typ, payload in chunks:
        if typ == b"IDAT":
            idat.extend(payload)
        else:
            other.append((typ, payload))
    compressed = zlib.compress(zlib.decompress(bytes(idat)), max(0, min(9, level + 3))) if idat else b""
    for typ, payload in other:
        if typ == b"IEND" and compressed:
            write_chunk(out, b"IDAT", compressed)
        write_chunk(out, typ, payload)
    return bytes(out)


def write_chunk(out, typ, payload):
    out.extend(struct.pack(">I", len(payload)))
    out.extend(typ)
    out.extend(payload)
    out.extend(struct.pack(">I", zlib.crc32(typ + payload) & 0xffffffff))


def paeth(a, b, c):
    p = a + b - c
    pa = abs(p - a)
    pb = abs(p - b)
    pc = abs(p - c)
    if pa <= pb and pa <= pc:
        return a
    if pb <= pc:
        return b
    return c


def png_resize(data, opts):
    chunks = read_png_chunks(data)
    ihdr = next(payload for typ, payload in chunks if typ == b"IHDR")
    width, height, bit_depth, color_type, comp, filt, interlace = struct.unpack(">IIBBBBB", ihdr)
    if comp != 0 or filt != 0 or interlace != 0:
        return data
    channels = {0: 1, 2: 3, 3: 1, 4: 2, 6: 4}.get(color_type)
    if channels is None:
        return data
    if color_type == 3:
        if bit_depth not in (1, 2, 4, 8):
            return data
    elif bit_depth != 8:
        return data
    target_w, target_h = compute_target_size(width, height, opts)
    if (target_w, target_h) == (width, height):
        return data
    raw = zlib.decompress(b"".join(payload for typ, payload in chunks if typ == b"IDAT"))
    stride = (width * channels * bit_depth + 7) // 8
    bpp = max(1, (channels * bit_depth + 7) // 8)
    rows = []
    prev = [0] * stride
    pos = 0
    for _ in range(height):
        f = raw[pos]
        pos += 1
        scan = list(raw[pos:pos + stride])
        pos += stride
        recon = [0] * stride
        for i, val in enumerate(scan):
            left = recon[i - bpp] if i >= bpp else 0
            up = prev[i]
            up_left = prev[i - bpp] if i >= bpp else 0
            if f == 0:
                x = val
            elif f == 1:
                x = val + left
            elif f == 2:
                x = val + up
            elif f == 3:
                x = val + ((left + up) // 2)
            elif f == 4:
                x = val + paeth(left, up, up_left)
            else:
                return data
            recon[i] = x & 255
        rows.append(recon)
        prev = recon

    if color_type == 3 and bit_depth < 8:
        pixel_rows = [unpack_bits(row, width, bit_depth) for row in rows]
    else:
        pixel_rows = rows

    out_rows = []
    for y in range(target_h):
        src_y = min(height - 1, int(y * height / target_h))
        row = bytearray([0])
        for x in range(target_w):
            src_x = min(width - 1, int(x * width / target_w))
            if color_type == 3 and bit_depth < 8:
                continue
            off = src_x * channels
            row.extend(pixel_rows[src_y][off:off + channels])
        if color_type == 3 and bit_depth < 8:
            samples = []
            for x in range(target_w):
                src_x = min(width - 1, int(x * width / target_w))
                samples.append(pixel_rows[src_y][src_x])
            row.extend(pack_bits(samples, bit_depth))
        out_rows.append(bytes(row))
    out = bytearray(b"\x89PNG\r\n\x1a\n")
    new_ihdr = struct.pack(">IIBBBBB", target_w, target_h, bit_depth, color_type, comp, filt, interlace)
    write_chunk(out, b"IHDR", new_ihdr)
    for typ, payload in chunks:
        if typ not in (b"IHDR", b"IDAT", b"IEND"):
            write_chunk(out, typ, payload)
    write_chunk(out, b"IDAT", zlib.compress(b"".join(out_rows), max(0, min(9, opts["png_opt"] + 3))))
    write_chunk(out, b"IEND", b"")
    return bytes(out)


def unpack_bits(row, width, bit_depth):
    mask = (1 << bit_depth) - 1
    out = []
    for byte in row:
        for shift in range(8 - bit_depth, -1, -bit_depth):
            out.append((byte >> shift) & mask)
            if len(out) == width:
                return out
    return out


def pack_bits(samples, bit_depth):
    out = bytearray()
    acc = 0
    used = 0
    mask = (1 << bit_depth) - 1
    for s in samples:
        acc = (acc << bit_depth) | (s & mask)
        used += bit_depth
        if used == 8:
            out.append(acc)
            acc = 0
            used = 0
    if used:
        out.append(acc << (8 - used))
    return bytes(out)


def compute_target_size(width, height, opts):
    tw = int(opts["width"]) if opts["width"] is not None else None
    th = int(opts["height"]) if opts["height"] is not None else None
    if opts["long_edge"] is not None:
        edge = int(opts["long_edge"])
        if width >= height:
            tw, th = edge, max(1, round(height * edge / width))
        else:
            th, tw = edge, max(1, round(width * edge / height))
    elif opts["short_edge"] is not None:
        edge = int(opts["short_edge"])
        if width <= height:
            tw, th = edge, max(1, round(height * edge / width))
        else:
            th, tw = edge, max(1, round(width * edge / height))
    elif tw is not None and th is None:
        th = max(1, round(height * tw / width))
    elif th is not None and tw is None:
        tw = max(1, round(width * th / height))
    if tw is None:
        tw = width
    if th is None:
        th = height
    if opts["no_upscale"] and (tw > width or th > height):
        return width, height
    return max(1, tw), max(1, th)


def compress_bytes(path, opts):
    data = path.read_bytes()
    fmt = EXT_FORMAT.get(path.suffix.lower())
    if opts["format"] not in ("original", fmt):
        return data
    if fmt == "png":
        try:
            if any(opts[k] is not None for k in ("width", "height", "long_edge", "short_edge")):
                data = png_resize(data, opts)
            return png_recompress(data, opts["png_opt"])
        except Exception:
            return data
    return data


def output_name(src, opts):
    fmt = opts["format"]
    stem = src.stem + opts["suffix"]
    if fmt == "jpeg":
        ext = ".jpg"
    elif fmt == "original":
        ext = src.suffix
    else:
        ext = "." + fmt
    return stem + ext


def gather(inputs, recursive):
    result = []
    for raw in inputs:
        p = Path(raw)
        if p.is_file():
            if p.suffix.lower() in EXT_FORMAT:
                result.append((p, None))
            else:
                return None
        elif p.is_dir():
            iterator = p.rglob("*") if recursive else p.iterdir()
            for child in iterator:
                if child.is_file() and child.suffix.lower() in EXT_FORMAT:
                    result.append((child, p))
        else:
            return None
    return result


def human(n):
    sign = "-" if n < 0 else ""
    n = abs(n)
    if n < 1024:
        return f"{sign}{n} B"
    for unit in ("KiB", "MiB", "GiB"):
        n /= 1024
        if n < 1024:
            return f"{sign}{n:.1f} {unit}"
    return f"{sign}{n:.1f} TiB"


def savings_ok(original, new, rule):
    if rule is None:
        return True
    saved = original - new
    kind, threshold = rule
    if kind == "percent":
        pct = (saved / original * 100) if original else 0
        return pct >= threshold
    return saved >= threshold


def run(argv):
    try:
        opts, inputs = parse_args(argv)
    except UsageError as e:
        msg = str(e)
        if "required arguments" in msg:
            sys.stderr.write(f"error: {msg}\n\nUsage: executable <--quality <QUALITY>|--lossless|--max-size <MAX_SIZE>> <--output <OUTPUT>|--same-folder-as-input> [FILES]...\n\nFor more information, try '--help'.\n")
            return 2
        return die(msg)

    if not inputs:
        if not opts["quiet"]:
            sys.stderr.write("No files to compress\n")
        return 0
    files = gather(inputs, opts["recursive"])
    if files is None:
        if not opts["quiet"]:
            sys.stderr.write("Unable to compute the base path for the files.\n")
        return 255

    total_in = total_out = 0
    success = skipped = errors = 0
    for src, base in files:
        original_size = src.stat().st_size
        total_in += original_size
        try:
            data = compress_bytes(src, opts)
            out_size = len(data)
            if opts["same_folder"]:
                dest_dir = src.parent
            else:
                dest_dir = Path(opts["output"])
                if opts["keep_structure"] and base is not None:
                    dest_dir = dest_dir / src.parent.relative_to(base)
            dest = dest_dir / output_name(src, opts)
            should_write = True
            if dest.exists():
                if opts["overwrite"] == "never":
                    should_write = False
                    out_size = dest.stat().st_size
                elif opts["overwrite"] == "bigger" and dest.stat().st_size <= out_size:
                    should_write = False
                    out_size = dest.stat().st_size
            if should_write and not savings_ok(original_size, out_size, opts["min_savings"]):
                should_write = False
                out_size = dest.stat().st_size if dest.exists() else original_size
            if should_write:
                success += 1
                if not opts["dry_run"]:
                    dest_dir.mkdir(parents=True, exist_ok=True)
                    dest.write_bytes(data)
                    if opts["keep_dates"]:
                        shutil.copystat(src, dest)
            else:
                skipped += 1
            total_out += out_size
        except Exception:
            errors += 1
            total_out += original_size

    if not opts["quiet"] and opts["verbose"] != 0:
        print(f"Compressed {len(files)} files ({success} success, {skipped} skipped, {errors} errors)")
        delta = total_out - total_in
        pct = (delta / total_in * 100) if total_in else 0
        sign = "+" if delta >= 0 else "-"
        print(f"{human(total_in)} -> {human(total_out)} [{sign}{human(abs(delta))} | {pct:+.2f}%]")
    return 0


if __name__ == "__main__":
    sys.exit(run(sys.argv[1:]))
