#!/usr/bin/env python3
import argparse
import json
import re
import sys
from pathlib import Path

IDENT = re.compile(r"[A-Za-z_][A-Za-z0-9_'-]*")


def strip_strings_and_comments(line: str) -> str:
    out = []
    i = 0
    in_str = False
    interp_depth = 0
    while i < len(line):
        c = line[i]
        if not in_str and c == "#":
            out.append(" " * (len(line) - i))
            break
        if in_str and line.startswith("${", i):
            interp_depth += 1
            out.append("  ")
            i += 2
            continue
        if in_str and interp_depth:
            if c == "{":
                interp_depth += 1
            elif c == "}":
                interp_depth -= 1
            out.append(" " if c == "}" and interp_depth == 0 else c)
        elif c == '"' and (i == 0 or line[i - 1] != "\\"):
            in_str = not in_str
            out.append(" ")
        elif in_str:
            out.append(" ")
        else:
            out.append(c)
        i += 1
    return "".join(out)


def analyze_file(path: Path, opts) -> list[dict]:
    lines = path.read_text(errors="replace").splitlines()
    clean = [strip_strings_and_comments(line) for line in lines]
    declarations = []
    skip_lines = {i + 2 for i, line in enumerate(lines) if "deadnix: skip" in line}
    in_let = False
    for line_no, line in enumerate(clean, start=1):
        header = line.split(":", 1)[0] if ":" in line and "{" in line and "}" in line.split(":", 1)[0] else ""
        if header and not getattr(opts, "no_lambda_pattern_names", False):
            brace_start = header.find("{")
            brace_end = header.rfind("}")
            before = header[:brace_start]
            inside = header[brace_start + 1 : brace_end]
            after = header[brace_end + 1 :]
            alias_match = re.search(r"([A-Za-z_][A-Za-z0-9_'-]*)\s*@\s*$", before)
            if alias_match:
                declarations.append((alias_match.group(1), line_no, alias_match.start(1) + 1, alias_match.end(1) + 1, "lambda pattern"))
            alias_match = re.search(r"@\s*([A-Za-z_][A-Za-z0-9_'-]*)\s*$", after)
            if alias_match:
                declarations.append((alias_match.group(1), line_no, brace_end + alias_match.start(1) + 2, brace_end + alias_match.end(1) + 2, "lambda pattern"))
            offset = brace_start + 1
            for part in inside.split(","):
                name_match = re.match(r"\s*([A-Za-z_][A-Za-z0-9_'-]*)", part)
                if name_match:
                    name = name_match.group(1)
                    if name != "...":
                        start = offset + inside[: inside.find(part)].__len__() + name_match.start(1) + 1
                        declarations.append((name, line_no, start, start + len(name), "lambda pattern"))

        if re.match(r"\s*let\b", line):
            in_let = True
            continue
        if in_let and re.match(r"\s*in\b", line):
            in_let = False
        if not in_let:
            continue
        m = re.match(r"\s*([A-Za-z_][A-Za-z0-9_'-]*)\s*=", line)
        if m:
            name = m.group(1)
            declarations.append((name, line_no, m.start(1) + 1, m.end(1) + 1, "let binding"))
            rhs = line[m.end() :]
            lm = re.match(r"\s*([A-Za-z_][A-Za-z0-9_'-]*)\s*:", rhs)
            if lm:
                arg = lm.group(1)
                if not getattr(opts, "no_lambda_arg", False):
                    declarations.append((arg, line_no, m.end() + lm.start(1) + 1, m.end() + lm.end(1) + 1, "lambda argument"))
        im = re.match(r"\s*inherit(?:\s*\([^)]*\))?\s+([^;]+);", line)
        if in_let and im:
            base = im.start(1)
            for nm in IDENT.finditer(im.group(1)):
                declarations.append((nm.group(0), line_no, base + nm.start() + 1, base + nm.end() + 1, "let binding"))

    text_for_use = "\n".join(clean)
    decl_spans = {(line_no, col, end_col) for _name, line_no, col, end_col, _kind in declarations}
    results = []
    for name, line_no, col, end_col, kind in declarations:
        if line_no in skip_lines:
            continue
        if getattr(opts, "no_underscore", False) and name.startswith("_"):
            continue
        if kind == "lambda argument" and name.startswith("_"):
            continue
        uses = 0
        for m in IDENT.finditer(text_for_use):
            if m.group(0) == name:
                before = text_for_use[: m.start()]
                occ_line = before.count("\n") + 1
                occ_col = m.start() - before.rfind("\n")
                if (occ_line, occ_col, occ_col + len(name)) in decl_spans:
                    continue
                if occ_line != line_no and re.search(r"\blet\s+" + re.escape(name) + r"\s*=", clean[occ_line - 1]):
                    continue
                uses += 1
        if uses == 0:
            results.append({"column": col, "endColumn": end_col, "line": line_no, "message": f"Unused {kind}: {name}"})
        elif getattr(opts, "warn_used_underscore", False) and name.startswith("_"):
            results.append({"column": col, "endColumn": end_col, "line": line_no, "message": f"Used {kind}: {name}"})
    results.sort(key=lambda item: (item["line"], item["column"]))
    return results


def find_files(paths, hidden=False, excludes=()):
    out = []
    exclude_paths = {str(Path(e)) for e in excludes}
    for raw in paths or ["."]:
        p = Path(raw)
        if str(p) in exclude_paths:
            continue
        if p.is_file():
            if p.suffix == ".nix":
                out.append(p)
            continue
        if p.is_dir():
            for child in p.rglob("*.nix"):
                parts = child.relative_to(p).parts
                if not hidden and any(part.startswith(".") for part in parts):
                    continue
                if str(child) in exclude_paths or str(child.relative_to(Path.cwd())) in exclude_paths:
                    continue
                out.append(child)
    return out


HELP = """Find dead code in .nix files

Usage: executable [OPTIONS] [FILE_PATHS]...

Arguments:
  [FILE_PATHS]...  .nix files, or directories with .nix files inside [default: .]

Options:
  -l, --no-lambda-arg                  Don't check lambda parameter arguments
  -L, --no-lambda-pattern-names        Don't check lambda attrset pattern names (don't break nixpkgs callPackage)
  -_, --no-underscore                  Don't check any bindings that start with a _
                                       (Lambda arguments starting with _ are not checked anyway.)
  -W, --warn-used-underscore           Warn if bindings are referenced that start with '_'
  -q, --quiet                          Don't print dead code report
  -e, --edit                           Remove unused code and write to source file
  -h, --hidden                         Recurse into hidden subdirectories and process hidden .*.nix files
      --help
  -f, --fail                           Exit with 1 if unused code has been found
  -o, --output-format <OUTPUT_FORMAT>  Output format to use [default: human-readable] [possible values: human-readable, json]
      --exclude <EXCLUDES>...          Files to exclude from analysis
  -V, --version                        Print version
"""


def print_human(path: Path, results: list[dict]):
    if not results:
        return
    lines = path.read_text(errors="replace").splitlines()
    first = results[0]
    print("Warning: Unused declarations were found.")
    print(f"   ╭─[{path}:{first['line']}:{first['column']}]")
    for r in results:
        text = lines[r["line"] - 1] if 0 <= r["line"] - 1 < len(lines) else ""
        print(f"{r['line']:2} │{text}")
        name_len = max(1, r["endColumn"] - r["column"])
        prefix = " " * (r["column"] + 2)
        marker = "╰" + "─" * min(5, name_len) + " " + r["message"]
        print(f"   │{prefix}{marker}")


def main(argv=None):
    argv = list(sys.argv[1:] if argv is None else argv)
    if "--help" in argv:
        print(HELP, end="")
        return 0
    if "-V" in argv or "--version" in argv:
        print("deadnix 1.3.1")
        return 0
    parser = argparse.ArgumentParser(add_help=False, description="Find dead code in .nix files")
    parser.add_argument("-o", "--output-format", default="human-readable", choices=["human-readable", "json"])
    parser.add_argument("--exclude", nargs="*", default=[])
    parser.add_argument("-h", "--hidden", action="store_true")
    parser.add_argument("-l", "--no-lambda-arg", action="store_true")
    parser.add_argument("-L", "--no-lambda-pattern-names", action="store_true")
    parser.add_argument("-W", "--warn-used-underscore", action="store_true")
    parser.add_argument("-q", "--quiet", action="store_true")
    parser.add_argument("-f", "--fail", action="store_true")
    parser.add_argument("-e", "--edit", action="store_true")
    parser.add_argument("-_", "--no-underscore", action="store_true")
    parser.add_argument("paths", nargs="*")
    args, _unknown = parser.parse_known_args(argv)

    any_unused = False
    for path in find_files(args.paths, args.hidden, args.exclude):
        results = analyze_file(path, args)
        if results:
            any_unused = True
            if args.edit:
                lines = path.read_text(errors="replace").splitlines()
                remove = {r["line"] for r in results if "let binding" in r["message"]}
                kept = [line for i, line in enumerate(lines, start=1) if i not in remove]
                path.write_text("\n".join(kept) + ("\n" if lines else ""))
            if args.quiet:
                continue
            if args.output_format == "json":
                print(json.dumps({"file": str(path), "results": results}, separators=(",", ":")))
            else:
                print_human(path, results)
    return 1 if args.fail and any_unused else 0


if __name__ == "__main__":
    raise SystemExit(main())
