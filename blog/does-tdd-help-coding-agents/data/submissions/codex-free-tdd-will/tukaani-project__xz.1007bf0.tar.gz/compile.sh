#!/bin/bash
set -e
cp src/xzmini.py executable
chmod +x executable
