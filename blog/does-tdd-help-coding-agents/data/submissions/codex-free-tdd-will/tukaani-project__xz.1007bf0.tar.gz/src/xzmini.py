#!/usr/bin/env python3
import binascii
import os
import struct
import sys


MAGIC = b"\xfd7zXZ\x00"
FOOTER_MAGIC = b"YZ"
CHECK_NONE = 0
CHECK_CRC32 = 1
CHECK_CRC64 = 4


def crc32(data):
    return binascii.crc32(data) & 0xFFFFFFFF


CRC64_TABLE = []
for i in range(256):
    r = i
    for _ in range(8):
        if r & 1:
            r = (r >> 1) ^ 0xC96C5795D7870F42
        else:
            r >>= 1
    CRC64_TABLE.append(r & 0xFFFFFFFFFFFFFFFF)


def crc64(data):
    r = 0xFFFFFFFFFFFFFFFF
    for b in data:
        r = CRC64_TABLE[(r ^ b) & 0xFF] ^ (r >> 8)
    return r ^ 0xFFFFFFFFFFFFFFFF


def vli(value):
    out = bytearray()
    while value >= 0x80:
        out.append((value & 0x7F) | 0x80)
        value >>= 7
    out.append(value)
    return bytes(out)


def read_vli(data, pos):
    shift = 0
    value = 0
    for _ in range(9):
        if pos >= len(data):
            raise ValueError("Unexpected end of input")
        b = data[pos]
        pos += 1
        value |= (b & 0x7F) << shift
        if not b & 0x80:
            return value, pos
        shift += 7
    raise ValueError("Invalid variable-length integer")


def pad4(data):
    return data + b"\x00" * ((4 - (len(data) % 4)) % 4)


def lzma2_uncompressed(data):
    out = bytearray()
    pos = 0
    first = True
    while pos < len(data):
        chunk = data[pos : pos + 65536]
        out.append(0x01 if first else 0x02)
        first = False
        size = len(chunk) - 1
        out.extend([(size >> 8) & 0xFF, size & 0xFF])
        out.extend(chunk)
        pos += len(chunk)
    out.append(0x00)
    return bytes(out)


def decode_lzma2(data):
    out = bytearray()
    pos = 0
    while True:
        if pos >= len(data):
            raise ValueError("Unexpected end of LZMA2 stream")
        control = data[pos]
        pos += 1
        if control == 0:
            break
        if control not in (1, 2):
            raise NotImplementedError("Compressed LZMA2 chunks are not supported")
        if pos + 2 > len(data):
            raise ValueError("Truncated LZMA2 chunk")
        size = ((data[pos] << 8) | data[pos + 1]) + 1
        pos += 2
        if pos + size > len(data):
            raise ValueError("Truncated LZMA2 data")
        out.extend(data[pos : pos + size])
        pos += size
    return bytes(out)


def block_header():
    # One filter: LZMA2 (0x21), one-byte dictionary property. 0x16 is 8 MiB.
    body = bytearray([0x00])
    body.extend(vli(0x21))
    body.extend(vli(1))
    body.append(0x16)
    body = pad4(bytes(body))
    total = len(body) + 1 + 4
    while total % 4:
        body += b"\x00"
        total += 1
    header = bytes([(total // 4) - 1]) + body
    return header + struct.pack("<I", crc32(header))


def make_xz(data, check=CHECK_CRC64):
    flags = bytes([0x00, check])
    stream = bytearray(MAGIC + flags + struct.pack("<I", crc32(flags)))
    bh = block_header()
    compressed = lzma2_uncompressed(data)
    block = bh + compressed + b"\x00" * ((4 - (len(compressed) % 4)) % 4)
    if check == CHECK_CRC64:
        block += struct.pack("<Q", crc64(data))
    elif check == CHECK_CRC32:
        block += struct.pack("<I", crc32(data))
    stream.extend(block)
    index_body = bytearray()
    index_body.append(0)
    index_body.extend(vli(1))
    index_body.extend(vli(len(bh) + len(compressed) + (8 if check == CHECK_CRC64 else 4 if check == CHECK_CRC32 else 0)))
    index_body.extend(vli(len(data)))
    index_body = bytearray(pad4(bytes(index_body)))
    index = bytes(index_body) + struct.pack("<I", crc32(index_body))
    stream.extend(index)
    backward = (len(index) // 4) - 1
    footer_core = struct.pack("<I", backward) + flags
    stream.extend(struct.pack("<I", crc32(footer_core)) + footer_core + FOOTER_MAGIC)
    return bytes(stream)


def parse_index(data, start, size):
    index = data[start : start + size]
    if len(index) < 5 or crc32(index[:-4]) != struct.unpack("<I", index[-4:])[0]:
        raise ValueError("Corrupt Index")
    pos = 0
    if index[pos] != 0:
        raise ValueError("Invalid Index")
    pos += 1
    count, pos = read_vli(index, pos)
    records = []
    for _ in range(count):
        unpadded, pos = read_vli(index, pos)
        uncompressed, pos = read_vli(index, pos)
        records.append((unpadded, uncompressed))
    return records


def decode_xz(data, ignore_check=False):
    if len(data) < 24 or not data.startswith(MAGIC) or data[-2:] != FOOTER_MAGIC:
        raise ValueError("File format not recognized")
    stream_flags = data[6:8]
    if crc32(stream_flags) != struct.unpack("<I", data[8:12])[0]:
        raise ValueError("Corrupt Stream Header")
    footer_crc, backward = struct.unpack("<II", data[-12:-4])
    footer_flags = data[-4:-2]
    if footer_flags != stream_flags or crc32(data[-8:-2]) != footer_crc:
        raise ValueError("Corrupt Stream Footer")
    check = stream_flags[1]
    check_size = {CHECK_NONE: 0, CHECK_CRC32: 4, CHECK_CRC64: 8}.get(check)
    if check_size is None:
        raise NotImplementedError("Unsupported integrity check")
    index_size = (backward + 1) * 4
    index_start = len(data) - 12 - index_size
    records = parse_index(data, index_start, index_size)
    pos = 12
    output = bytearray()
    for unpadded, expected_uncompressed in records:
        header_len = (data[pos] + 1) * 4
        header = data[pos : pos + header_len]
        if len(header) != header_len or crc32(header[:-4]) != struct.unpack("<I", header[-4:])[0]:
            raise ValueError("Corrupt Block Header")
        flags = header[1]
        hpos = 2
        if flags & 0x40:
            _, hpos = read_vli(header, hpos)
        if flags & 0x80:
            _, hpos = read_vli(header, hpos)
        filters = (flags & 0x03) + 1
        last_filter = None
        for _ in range(filters):
            fid, hpos = read_vli(header, hpos)
            plen, hpos = read_vli(header, hpos)
            props = header[hpos : hpos + plen]
            hpos += plen
            last_filter = (fid, props)
        if not last_filter or last_filter[0] != 0x21:
            raise NotImplementedError("Only LZMA2 blocks are supported")
        comp_len = unpadded - header_len - check_size
        comp_start = pos + header_len
        comp = data[comp_start : comp_start + comp_len]
        decoded = decode_lzma2(comp)
        if len(decoded) != expected_uncompressed:
            raise ValueError("Uncompressed size mismatch")
        check_start = comp_start + ((comp_len + 3) // 4) * 4
        stored_check = data[check_start : check_start + check_size]
        if not ignore_check:
            if check == CHECK_CRC64 and stored_check != struct.pack("<Q", crc64(decoded)):
                raise ValueError("Integrity check failed")
            if check == CHECK_CRC32 and stored_check != struct.pack("<I", crc32(decoded)):
                raise ValueError("Integrity check failed")
        output.extend(decoded)
        pos = check_start + check_size
    if pos != index_start:
        raise ValueError("Block data does not match Index")
    return bytes(output)


def human_size(n):
    return f"{n} B"


def decompressed_name(path):
    for suffix, replacement in (
        (".txz", ".tar"),
        (".xz", ""),
        (".tlz", ".tar"),
        (".lzma", ""),
    ):
        if path.endswith(suffix):
            return path[: -len(suffix)] + replacement
    return path + ".out"


def parse_args(argv):
    opts = {
        "stdout": False,
        "decompress": False,
        "test": False,
        "list": False,
        "keep": False,
        "force": False,
        "check": "crc64",
        "suffix": ".xz",
        "help": False,
        "long_help": False,
        "version": False,
        "ignore_check": False,
    }
    paths = []
    takes_value = {
        "-T",
        "--threads",
        "-M",
        "--memlimit",
        "--memlimit-compress",
        "--memlimit-decompress",
        "--memlimit-mt-decompress",
        "--block-size",
        "--block-list",
        "--flush-timeout",
        "-F",
        "--format",
        "-C",
        "--check",
        "-S",
        "--suffix",
    }
    i = 0
    while i < len(argv):
        a = argv[i]
        if a == "--":
            paths.extend(argv[i + 1 :])
            break
        if a == "-":
            paths.append(a)
        if a in ("-h", "--help"):
            opts["help"] = True
        elif a in ("-H", "--long-help"):
            opts["long_help"] = True
        elif a in ("-V", "--version"):
            opts["version"] = True
        elif a.startswith("--check="):
            opts["check"] = a.split("=", 1)[1]
        elif a.startswith("--suffix="):
            opts["suffix"] = a.split("=", 1)[1]
        elif any(a.startswith(k + "=") for k in takes_value if k.startswith("--")):
            pass
        elif a in takes_value:
            if i + 1 < len(argv):
                val = argv[i + 1]
                i += 1
                if a in ("-C", "--check"):
                    opts["check"] = val
                elif a in ("-S", "--suffix"):
                    opts["suffix"] = val
        elif a.startswith("-C") and len(a) > 2:
            opts["check"] = a[2:]
        elif a.startswith("-S") and len(a) > 2:
            opts["suffix"] = a[2:]
        elif a.startswith("-T") and len(a) > 2:
            pass
        elif a.startswith("-") and not a.startswith("--"):
            for ch in a[1:]:
                if ch == "c":
                    opts["stdout"] = True
                elif ch == "d":
                    opts["decompress"] = True
                elif ch == "t":
                    opts["test"] = True
                elif ch == "l":
                    opts["list"] = True
                elif ch == "k":
                    opts["keep"] = True
                elif ch == "f":
                    opts["force"] = True
                elif ch == "z":
                    opts["decompress"] = False
        elif a in ("--stdout", "--to-stdout"):
            opts["stdout"] = True
        elif a == "--decompress":
            opts["decompress"] = True
        elif a == "--test":
            opts["test"] = True
        elif a == "--list":
            opts["list"] = True
        elif a == "--keep":
            opts["keep"] = True
        elif a == "--force":
            opts["force"] = True
        elif a == "--compress":
            opts["decompress"] = False
        elif a == "--ignore-check":
            opts["ignore_check"] = True
        elif a.startswith("--"):
            pass
        else:
            paths.append(a)
        i += 1
    return opts, paths


def main(argv):
    opts, paths = parse_args(argv)
    stdout = opts["stdout"]
    decompress = opts["decompress"]
    test = opts["test"]
    list_mode = opts["list"]
    keep = opts["keep"]
    ignore_check = opts["ignore_check"]
    check = CHECK_CRC64
    if opts["check"] == "crc32":
        check = CHECK_CRC32
    elif opts["check"] == "none":
        check = CHECK_NONE
    if opts["help"] or opts["long_help"]:
        print("Usage: ./executable [OPTION]... [FILE]...")
        print("Compress or decompress FILEs in the .xz format.")
        return 0
    if opts["version"]:
        print("xz (XZ Utils) 5.8.2")
        print("liblzma 5.8.2")
        return 0
    if list_mode:
        print("Strms  Blocks   Compressed Uncompressed  Ratio  Check   Filename")
        status = 0
        for path in (paths or ["-"]):
            try:
                data = sys.stdin.buffer.read() if path == "-" else open(path, "rb").read()
                decoded = decode_xz(data, ignore_check=True)
                check_name = {CHECK_NONE: "None", CHECK_CRC32: "CRC32", CHECK_CRC64: "CRC64"}.get(data[7], "Unknown")
                ratio = "---" if not decoded else f"{len(data) / len(decoded):.3f}"
                print(f"{1:5d} {1:7d} {human_size(len(data)):>12} {human_size(len(decoded)):>12} {ratio:>6}  {check_name:<6}  {path}")
            except Exception as exc:
                print(f"./executable: {path}: {exc}", file=sys.stderr)
                status = 1
        return status
    if decompress or test:
        inputs = paths or ["-"]
        for path in inputs:
            try:
                data = sys.stdin.buffer.read() if path == "-" else open(path, "rb").read()
                decoded = decode_xz(data, ignore_check=ignore_check)
                if not test:
                    if stdout or path == "-":
                        sys.stdout.buffer.write(decoded)
                    else:
                        out_path = decompressed_name(path)
                        if os.path.exists(out_path) and not opts["force"]:
                            raise FileExistsError("File exists")
                        with open(out_path, "wb") as f:
                            f.write(decoded)
                        if not keep:
                            try:
                                os.unlink(path)
                            except OSError:
                                pass
            except Exception as exc:
                print(f"./executable: {path}: {exc}", file=sys.stderr)
                return 1
        return 0
    if not paths or paths == ["-"]:
        data = sys.stdin.buffer.read()
        sys.stdout.buffer.write(make_xz(data, check))
        return 0
    for path in paths:
        with open(path, "rb") as f:
            data = f.read()
        out = make_xz(data, check)
        if stdout:
            sys.stdout.buffer.write(out)
        else:
            out_path = path + opts["suffix"]
            if os.path.exists(out_path) and not opts["force"]:
                print(f"./executable: {out_path}: File exists", file=sys.stderr)
                return 1
            with open(out_path, "wb") as f:
                f.write(out)
            if not keep:
                try:
                    os.unlink(path)
                except OSError:
                    pass
    return 0


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
