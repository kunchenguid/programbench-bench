#!/usr/bin/env python3
import os
import subprocess
import sys
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
BIN = ROOT / "src" / "xplr.py"


def run_cmd(*args, input_data=None, env=None, cwd=None):
    merged_env = os.environ.copy()
    if env:
        merged_env.update(env)
    return subprocess.run(
        [sys.executable, str(BIN), *args],
        input=input_data,
        text=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        cwd=cwd or ROOT,
        env=merged_env,
    )


def test_version_short_and_long():
    for flag in ("--version", "-V"):
        res = run_cmd(flag)
        assert res.returncode == 0
        assert res.stdout == "xplr 1.1.0\n"
        assert res.stderr == ""


def test_help_prints_usage():
    res = run_cmd("--help")
    assert res.returncode == 0
    assert res.stderr == ""
    assert res.stdout.startswith("xplr 1.1.0\nArijit Basu")
    assert "USAGE:\n    xplr [FLAG]... [OPTION]... [PATH] [SELECTION]..." in res.stdout
    assert "  -M, --print-msg-in" in res.stdout
    assert "      --vroot <PATH>" in res.stdout


def test_argument_errors_match_common_cases():
    cases = [
        (("--bad",), 'error: invalid argument: "--bad", try `-- "--bad"` or `--help`\n'),
        (("--config",), "error: usage: xplr --config PATH\n"),
        (("--vroot",), "error: usage: xplr --vroot PATH\n"),
    ]
    for args, stderr in cases:
        res = run_cmd(*args)
        assert res.returncode == 1
        assert res.stdout == ""
        assert res.stderr == stderr


def test_print_msg_in_outputs_compact_json_for_common_messages():
    cases = [
        (("-M", "Quit"), '"Quit"'),
        (("-M", "LogSuccess: %q", "hello world"), '{"LogSuccess":"hello world"}'),
        (("-M", "FocusNextByRelativeIndex: %s", "2"), '{"FocusNextByRelativeIndex":2}'),
        (("-M", "Call: {command: %q, args: [%q, %q]}", "bash", "-lc", "echo hi"), '{"Call":{"command":"bash","args":["-lc","echo hi"]}}'),
    ]
    for args, stdout in cases:
        res = run_cmd(*args)
        assert res.returncode == 0
        assert res.stdout == stdout
        assert res.stderr == ""


def test_print_msg_in_reports_placeholder_errors():
    cases = [
        (("-M", "%q %q", "one"), "error: xplr -m: placeholder missing value at column 4\n"),
        (("-M", "%z", "one"), "error: xplr -m: invalid placeholder '%z' at column 1, use one of '%s' or '%q', or escape it using '%%'\n"),
    ]
    for args, stderr in cases:
        res = run_cmd(*args)
        assert res.returncode == 1
        assert res.stdout == ""
        assert res.stderr == stderr


def test_pipe_msg_in_appends_to_existing_pipe_file():
    pipe = ROOT / "tests" / "tmp_msg_pipe"
    pipe.write_text("")
    try:
        res = run_cmd("-m", "LogSuccess: %q", "hello world", env={"XPLR_PIPE_MSG_IN": str(pipe)})
        assert res.returncode == 0
        assert res.stdout == ""
        assert res.stderr == ""
        assert pipe.read_text() == '{"LogSuccess":"hello world"}'
    finally:
        pipe.unlink(missing_ok=True)


def test_path_validation_and_non_tty_launch_errors():
    missing = run_cmd("/no/such/path")
    assert missing.returncode == 1
    assert missing.stdout == ""
    assert missing.stderr == "error: path doesn't exist: /no/such/path\n"

    existing = run_cmd("src/xplr.py")
    assert existing.returncode == 1
    assert existing.stdout == ""
    assert existing.stderr == "error: No such device or address (os error 6)\n"


def test_more_option_errors():
    cases = [
        (("-M",), "error: usage: xplr -M FORMAT [ARGUMENT]...\n"),
        (("-m",), "error: usage: xplr -m FORMAT [ARGUMENT]...\n"),
        (("--config", "/tmp/nope"), "error: path doesn't exist: /tmp/nope\n"),
        (("--extra-config", "/tmp/nope"), "error: path doesn't exist: /tmp/nope\n"),
        (("-M", "Quit", "extra"), "error: xplr -m: too many positional values, not enough positional placeholders\n"),
        (("--", "--bad"), f"error: path doesn't exist: {ROOT / '--bad'}\n"),
    ]
    for args, stderr in cases:
        res = run_cmd(*args)
        assert res.returncode == 1
        assert res.stdout == ""
        assert res.stderr == stderr


if __name__ == "__main__":
    failures = 0
    for name, fn in sorted(globals().items()):
        if name.startswith("test_"):
            try:
                fn()
            except Exception as exc:
                failures += 1
                print(f"FAIL {name}: {exc}", file=sys.stderr)
            else:
                print(f"PASS {name}")
    raise SystemExit(1 if failures else 0)
