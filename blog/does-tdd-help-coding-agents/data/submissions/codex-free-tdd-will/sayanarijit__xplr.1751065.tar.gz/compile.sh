#!/bin/bash
set -e
cp src/xplr.py executable
chmod +x executable
