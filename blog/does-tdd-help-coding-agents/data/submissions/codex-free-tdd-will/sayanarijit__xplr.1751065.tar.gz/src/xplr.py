#!/usr/bin/env python3
import sys
import json
import os


VERSION = "xplr 1.1.0"
HELP = """xplr 1.1.0
Arijit Basu <hi@arijitbasu.in>
A hackable, minimal, fast TUI file explorer

USAGE:
    xplr [FLAG]... [OPTION]... [PATH] [SELECTION]...

FLAGS:
  -                            Reads new-line (\\n) separated paths from stdin
  --                           Denotes the end of command-line flags and options
      --force-focus            Focuses on the given <PATH>, even if it is a directory
  -h, --help                   Prints help information
  -m, --pipe-msg-in            Helps safely passing messages to the active xplr
                                 session, use %%, %s and %q as the placeholders
  -M, --print-msg-in           Like --pipe-msg-in, but prints the message instead of
                                 passing to the active xplr session
      --print-pwd-as-result    Prints the present working directory when quitting
                                 with `PrintResultAndQuit`
      --read-only              Enables read-only mode (config.general.read_only)
      --read0                  Reads paths separated using the null character (\\0)
      --write0                 Prints paths separated using the null character (\\0)
  -0  --null                   Combines --read0 and --write0
  -V, --version                Prints version information

OPTIONS:
  -c, --config <PATH>             Specifies a custom config file (default is
                                    "$HOME/.config/xplr/init.lua")
  -C, --extra-config <PATH>...    Specifies extra config files to load
      --on-load <MESSAGE>...      Sends messages when xplr loads
      --vroot <PATH>              Treats the specified path as the virtual root

ARGS:
  <PATH>            Path to focus on, or enter if directory, (default is `.`)
  <SELECTION>...    Paths to select, requires <PATH> to be set explicitly
"""


class ParseError(Exception):
    pass


def quote_string(value):
    return json.dumps(value, ensure_ascii=False, separators=(",", ":"))


def expand_template(fmt, values):
    out = []
    arg_index = 0
    i = 0
    while i < len(fmt):
        ch = fmt[i]
        if ch == "%":
            if i + 1 >= len(fmt):
                raise ParseError(
                    f"error: xplr -m: invalid placeholder '%' at column {i + 1}, use one of '%s' or '%q', or escape it using '%%'\n"
                )
            code = fmt[i + 1]
            if code == "%":
                out.append("%")
            elif code in {"s", "q"}:
                if arg_index >= len(values):
                    raise ParseError(
                        f"error: xplr -m: placeholder missing value at column {i + 1}\n"
                    )
                value = values[arg_index]
                arg_index += 1
                out.append(value if code == "s" else quote_string(value))
            else:
                raise ParseError(
                    f"error: xplr -m: invalid placeholder '%{code}' at column {i + 1}, use one of '%s' or '%q', or escape it using '%%'\n"
                )
            i += 2
        else:
            out.append(ch)
            i += 1
    if arg_index < len(values):
        raise ParseError(
            "error: xplr -m: too many positional values, not enough positional placeholders\n"
        )
    return "".join(out)


def split_top_level(text, sep=","):
    parts = []
    start = 0
    depth = 0
    in_string = False
    escape = False
    for i, ch in enumerate(text):
        if in_string:
            if escape:
                escape = False
            elif ch == "\\":
                escape = True
            elif ch == '"':
                in_string = False
        else:
            if ch == '"':
                in_string = True
            elif ch in "[{":
                depth += 1
            elif ch in "]}":
                depth -= 1
            elif ch == sep and depth == 0:
                parts.append(text[start:i].strip())
                start = i + 1
    parts.append(text[start:].strip())
    return [p for p in parts if p]


def find_top_level_colon(text):
    depth = 0
    in_string = False
    escape = False
    for i, ch in enumerate(text):
        if in_string:
            if escape:
                escape = False
            elif ch == "\\":
                escape = True
            elif ch == '"':
                in_string = False
        else:
            if ch == '"':
                in_string = True
            elif ch in "[{":
                depth += 1
            elif ch in "]}":
                depth -= 1
            elif ch == ":" and depth == 0:
                return i
    return -1


def parse_atom(text):
    text = text.strip()
    if text.startswith('"'):
        return json.loads(text)
    if text.startswith("[") and text.endswith("]"):
        inner = text[1:-1].strip()
        return [] if not inner else [parse_atom(part) for part in split_top_level(inner)]
    if text.startswith("{") and text.endswith("}"):
        inner = text[1:-1].strip()
        result = {}
        if not inner:
            return result
        for part in split_top_level(inner):
            idx = find_top_level_colon(part)
            if idx < 0:
                raise ParseError("map item missing colon")
            key = part[:idx].strip()
            if key.startswith('"'):
                key = json.loads(key)
            result[key] = parse_atom(part[idx + 1 :])
        return result
    if text.lstrip("-").isdigit():
        return int(text)
    return text


def parse_message(text):
    text = text.strip()
    idx = find_top_level_colon(text)
    if idx < 0:
        return text
    key = text[:idx].strip()
    return {key: parse_atom(text[idx + 1 :])}


def format_message(fmt, values):
    expanded = expand_template(fmt, values)
    msg = parse_message(expanded)
    return json.dumps(msg, ensure_ascii=False, separators=(",", ":"))


def main(argv):
    if argv in (["--version"], ["-V"]):
        print(VERSION)
        return 0
    if argv in (["--help"], ["-h"]):
        sys.stdout.write(HELP)
        return 0
    if argv and argv[0] in {"-M", "--print-msg-in"}:
        if len(argv) < 2:
            sys.stderr.write(f"error: usage: xplr {argv[0]} FORMAT [ARGUMENT]...\n")
            return 1
        try:
            sys.stdout.write(format_message(argv[1], argv[2:]))
            return 0
        except ParseError as exc:
            sys.stderr.write(str(exc))
            return 1
    if argv and argv[0] in {"-m", "--pipe-msg-in"}:
        if len(argv) < 2:
            sys.stderr.write(f"error: usage: xplr {argv[0]} FORMAT [ARGUMENT]...\n")
            return 1
        try:
            rendered = format_message(argv[1], argv[2:])
        except ParseError as exc:
            sys.stderr.write(str(exc))
            return 1
        pipe = os.environ.get("XPLR_PIPE_MSG_IN", "")
        if not pipe or not os.path.exists(pipe):
            sys.stderr.write("error: No such file or directory (os error 2)\n")
            return 1
        with open(pipe, "a", encoding="utf-8") as handle:
            handle.write(rendered)
        return 0
    if argv == ["--config"]:
        sys.stderr.write("error: usage: xplr --config PATH\n")
        return 1
    if argv == ["--vroot"]:
        sys.stderr.write("error: usage: xplr --vroot PATH\n")
        return 1
    path = None
    end_flags = False
    value_options = {"-c", "--config", "--vroot"}
    multi_value_options = {"-C", "--extra-config", "--on-load"}
    flags = {
        "-",
        "--",
        "--force-focus",
        "--print-pwd-as-result",
        "--read-only",
        "--read0",
        "--write0",
        "-0",
        "--null",
    }
    i = 0
    vroot = None
    while i < len(argv):
        arg = argv[i]
        if not end_flags and arg == "--":
            end_flags = True
            i += 1
            continue
        if not end_flags and arg in flags:
            i += 1
            continue
        if not end_flags and arg in value_options:
            if i + 1 >= len(argv):
                sys.stderr.write(f"error: usage: xplr {arg} PATH\n")
                return 1
            value = argv[i + 1]
            if arg in {"-c", "--config"} and not os.path.exists(value):
                shown_path = os.path.abspath(value) if not os.path.isabs(value) else value
                sys.stderr.write(f"error: path doesn't exist: {shown_path}\n")
                return 1
            if arg == "--vroot":
                vroot = os.path.abspath(value)
            i += 2
            continue
        if not end_flags and arg in multi_value_options:
            if i + 1 >= len(argv):
                sys.stderr.write("error: No such device or address (os error 6)\n")
                return 1
            value = argv[i + 1]
            if arg in {"-C", "--extra-config"} and not os.path.exists(value):
                shown_path = os.path.abspath(value) if not os.path.isabs(value) else value
                sys.stderr.write(f"error: path doesn't exist: {shown_path}\n")
                return 1
            i += 2
            continue
        if not end_flags and arg.startswith("-"):
            sys.stderr.write(
                f'error: invalid argument: "{arg}", try `-- "{arg}"` or `--help`\n'
            )
            return 1
        path = arg
        break
    if path is None:
        path = "."
    if vroot is not None:
        pwd = os.getcwd()
        try:
            inside = os.path.commonpath([pwd, vroot]) == vroot
        except ValueError:
            inside = False
        if not inside:
            sys.stderr.write(f'error: "{pwd}" is outside of virtual root "{vroot}"\n')
            return 1
    if not os.path.exists(path):
        shown_path = os.path.abspath(path) if not os.path.isabs(path) else path
        sys.stderr.write(f"error: path doesn't exist: {shown_path}\n")
        return 1
    sys.stderr.write("error: No such device or address (os error 6)\n")
    return 1


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
