import os
import subprocess
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
CLI = ROOT / "src" / "codesnap.py"


def run_cli(*args, cwd=None):
    return subprocess.run(["python3", str(CLI), *args], cwd=cwd, text=True, capture_output=True)


class CodeSnapCliTests(unittest.TestCase):
    def test_version_matches_documented_binary(self):
        result = run_cli("--version")
        self.assertEqual(result.returncode, 0)
        self.assertEqual(result.stdout.strip(), "codesnap-cli 0.13.1")

    def test_from_code_writes_svg_snapshot(self):
        with tempfile.TemporaryDirectory() as td:
            out = Path(td) / "snap.svg"
            result = run_cli("-c", "print('hi')", "-o", str(out))
            self.assertEqual(result.returncode, 0, result.stderr)
            self.assertIn("[SUCCESS]", result.stdout)
            data = out.read_text()
            self.assertTrue(data.startswith("<svg"))
            self.assertIn("print(&#x27;hi&#x27;)", data)

    def test_from_file_applies_one_based_inclusive_range(self):
        with tempfile.TemporaryDirectory() as td:
            source = Path(td) / "sample.txt"
            source.write_text("one\ntwo\nthree\nfour\n")
            out = Path(td) / "range.svg"
            result = run_cli("-f", str(source), "--range", "2:3", "-o", str(out), "--silent")
            self.assertEqual(result.returncode, 0, result.stderr)
            self.assertEqual(result.stdout, "")
            data = out.read_text()
            self.assertNotIn(">one<", data)
            self.assertIn(">two<", data)
            self.assertIn(">three<", data)
            self.assertNotIn(">four<", data)

    def test_png_html_and_ascii_output_contracts(self):
        with tempfile.TemporaryDirectory() as td:
            png = Path(td) / "snap.png"
            html = Path(td) / "snap.html"
            ascii_out = Path(td) / "snap.txt"
            result = run_cli("-c", "abc", "-o", str(png), "--silent")
            self.assertEqual(result.returncode, 0, result.stderr)
            self.assertEqual(png.read_bytes()[:8], b"\x89PNG\r\n\x1a\n")

            result = run_cli("-c", "abc", "-o", str(html), "--silent")
            self.assertEqual(result.returncode, 0, result.stderr)
            self.assertTrue(html.read_text().startswith('<img src="data:image/png;base64,'))

            result = run_cli("-c", "abc", "-o", str(ascii_out), "--type", "ascii")
            self.assertEqual(result.returncode, 0, result.stderr)
            self.assertIn("[WARN]", result.stdout)
            self.assertFalse(ascii_out.exists())

    def test_execute_skip_and_decorations_are_rendered(self):
        with tempfile.TemporaryDirectory() as td:
            executed = Path(td) / "exec.svg"
            result = run_cli("-e", "printf", "hi", "-o", str(executed), "--silent")
            self.assertEqual(result.returncode, 0, result.stderr)
            self.assertIn(">hi<", executed.read_text())

            skipped = Path(td) / "skip.svg"
            result = run_cli("-e", "printf", "hi", "--skip", "-o", str(skipped), "--has-line-number", "--start-line-number", "7", "--title", "Demo", "--watermark", "WM", "--silent")
            self.assertEqual(result.returncode, 0, result.stderr)
            data = skipped.read_text()
            self.assertIn(">printf hi<", data)
            self.assertIn(">7<", data)
            self.assertIn(">Demo<", data)
            self.assertIn(">WM<", data)

    def test_missing_input_errors_and_output_directory_gets_file(self):
        with tempfile.TemporaryDirectory() as td:
            result = run_cli("-o", str(Path(td) / "x.svg"))
            self.assertEqual(result.returncode, 1)
            self.assertIn("No code snippet provided", result.stdout)

            out_dir = Path(td) / "outdir"
            out_dir.mkdir()
            result = run_cli("-c", "abc", "-o", str(out_dir), "--silent")
            self.assertEqual(result.returncode, 0, result.stderr)
            self.assertTrue((out_dir / "codesnap.svg").exists())


if __name__ == "__main__":
    unittest.main()
