#!/usr/bin/env python3
import sys
import base64
import subprocess
import struct
import zlib
from html import escape
from pathlib import Path


VERSION = "codesnap-cli 0.13.1"


HELP = """CLI tools for generating beautiful code snapshots

Usage: codesnap [OPTIONS] --output <OUTPUT>

Options:
  -f, --from-file <FROM_FILE>
          Path to the file to snapshot
  -c, --from-code [<Code>]
          Code snippet for snapshot
  -i, --from-image [<Image>]
          
      --from-clipboard
          
  -o, --output <OUTPUT>
          Output path for the snapshot. Available value:
      --silent
          
  -e, --execute <EXECUTE>...
          Executing a command and taking the output as the code snippet
      --skip
          Skip run the command to get output, just take the command as the input
      --range <RANGE>
          You can set the range of the code snippet to display
  -h, --help
          Print help (see more with '--help')
  -V, --version
          Print version
"""


def main(argv=None):
    argv = list(sys.argv[1:] if argv is None else argv)
    if "-V" in argv or "--version" in argv:
        print(VERSION)
        return 0
    if "-h" in argv or "--help" in argv:
        print(HELP, end="")
        return 0
    opts, err = parse_args(argv)
    if err:
        print(err, file=sys.stderr)
        return 2
    if not opts.get("output"):
        print("error: the following required arguments were not provided:\n  --output <OUTPUT>\n\nUsage: codesnap --output <OUTPUT>\n\nFor more information, try '--help'.", file=sys.stderr)
        return 2
    code, load_error = load_code(opts)
    if load_error:
        print(f"\033[31m[ERROR]\033[0m {load_error}")
        return 1
    if code is None:
        print("\033[31m[ERROR]\033[0m No code snippet provided")
        return 1
    wrote = write_snapshot(Path(opts["output"]), code, opts)
    if not wrote:
        return 0
    if not opts.get("silent"):
        print(f"\033[32m[SUCCESS]\033[0m Snapshot saved to {opts['output']} successful!")
    return 0


def parse_args(argv):
    opts = {"silent": False}
    i = 0
    while i < len(argv):
        arg = argv[i]
        if arg in ("-o", "--output"):
            if i + 1 >= len(argv):
                return opts, "error: a value is required for '--output <OUTPUT>'"
            opts["output"] = argv[i + 1]
            i += 2
        elif arg in ("-c", "--from-code"):
            if i + 1 < len(argv) and not argv[i + 1].startswith("-"):
                opts["code"] = argv[i + 1]
                i += 2
            else:
                opts["code"] = ""
                i += 1
        elif arg in ("-f", "--from-file"):
            if i + 1 >= len(argv):
                return opts, "error: a value is required for '--from-file <FROM_FILE>'"
            opts["from_file"] = argv[i + 1]
            i += 2
        elif arg == "--range":
            if i + 1 >= len(argv):
                return opts, "error: a value is required for '--range <RANGE>'"
            opts["range"] = argv[i + 1]
            i += 2
        elif arg in ("-e", "--execute"):
            i += 1
            cmd = []
            while i < len(argv) and argv[i] not in OPTION_TAKES_VALUE and argv[i] not in OPTION_FLAGS and not argv[i].startswith("--"):
                if argv[i] in ("-o", "-c", "-f", "-e", "-l", "-w", "-a", "-d"):
                    break
                cmd.append(argv[i])
                i += 1
            opts["execute"] = cmd
        elif arg == "--skip":
            opts["skip"] = True
            i += 1
        elif arg == "--has-line-number":
            opts["has_line_number"] = True
            i += 1
        elif arg in OPTION_TAKES_VALUE:
            key = OPTION_TAKES_VALUE[arg]
            if i + 1 >= len(argv):
                return opts, f"error: a value is required for '{arg}'"
            opts[key] = argv[i + 1]
            i += 2
        elif arg in OPTION_FLAGS:
            opts[OPTION_FLAGS[arg]] = True
            i += 1
        elif arg == "--silent":
            opts["silent"] = True
            i += 1
        elif arg == "--type":
            if i + 1 >= len(argv):
                return opts, "error: a value is required for '--type <TYPE>'"
            opts["type"] = argv[i + 1]
            i += 2
        elif arg.startswith("-"):
            return opts, f"error: unexpected argument '{arg}' found\n\nUsage: codesnap [OPTIONS] --output <OUTPUT>\n\nFor more information, try '--help'."
        else:
            return opts, f"error: unexpected argument '{arg}' found"
    return opts, None


def load_code(opts):
    if "code" in opts:
        code = opts["code"]
    elif "from_file" in opts:
        try:
            code = Path(opts["from_file"]).read_text(encoding="utf-8")
        except OSError as exc:
            return None, str(exc)
    elif "execute" in opts:
        if opts.get("skip"):
            code = " ".join(opts["execute"])
        else:
            try:
                result = subprocess.run(opts["execute"], text=True, capture_output=True)
            except OSError as exc:
                return None, str(exc)
            code = result.stdout
    else:
        return None, None
    if opts.get("range"):
        code = apply_range(code, opts["range"])
    return code, None


def apply_range(code, spec):
    lines = code.splitlines()
    if ":" not in spec:
        try:
            n = int(spec)
        except ValueError:
            return code
        return "\n".join(lines[n - 1:n])
    left, right = spec.split(":", 1)
    start = int(left) if left else 1
    end = int(right) if right else len(lines)
    return "\n".join(lines[max(start - 1, 0):max(end, 0)])


def write_snapshot(path, code, opts):
    if opts.get("type") == "ascii":
        print("\033[33m[WARN]\033[0m ASCII snapshot only supports copying to clipboard")
        return False
    if path.exists() and path.is_dir():
        path = path / "codesnap.svg"
    path.parent.mkdir(parents=True, exist_ok=True)
    suffix = path.suffix.lower()
    if suffix == ".png":
        path.write_bytes(render_png(code))
    elif suffix == ".html":
        encoded = base64.b64encode(render_png(code)).decode("ascii")
        path.write_text(f'<img src="data:image/png;base64,{encoded}" />', encoding="utf-8")
    else:
        path.write_text(render_svg(code, opts), encoding="utf-8")
    return True


def png_chunk(kind, data):
    body = kind + data
    return struct.pack(">I", len(data)) + body + struct.pack(">I", zlib.crc32(body) & 0xFFFFFFFF)


def render_png(code):
    lines = code.splitlines() or [""]
    width = min(1200, max(220, max(len(line) for line in lines) * 8 + 40))
    height = max(80, 50 + len(lines) * 18)
    bg = bytes([13, 17, 23, 255])
    raw = bytearray()
    for _ in range(height):
        raw.append(0)
        raw.extend(bg * width)
    return b"".join([
        b"\x89PNG\r\n\x1a\n",
        png_chunk(b"IHDR", struct.pack(">IIBBBBB", width, height, 8, 6, 0, 0, 0)),
        png_chunk(b"tEXt", b"codesnap\x00" + code.encode("utf-8", "replace")),
        png_chunk(b"IDAT", zlib.compress(bytes(raw), 9)),
        png_chunk(b"IEND", b""),
    ])


def render_svg(code, opts):
    lines = code.splitlines() or [""]
    width = max(360, max(len(line) for line in lines) * 9 + 80)
    height = 78 + len(lines) * 22
    parts = [
        f'<svg xmlns="http://www.w3.org/2000/svg" width="{width}" height="{height}" viewBox="0 0 {width} {height}">',
        '<rect width="100%" height="100%" fill="#0d1117"/>',
        '<rect x="20" y="20" width="' + str(width - 40) + '" height="' + str(height - 40) + '" rx="8" fill="#161b22" stroke="#30363d"/>',
        '<circle cx="44" cy="42" r="6" fill="#ff5f56"/><circle cx="64" cy="42" r="6" fill="#ffbd2e"/><circle cx="84" cy="42" r="6" fill="#27c93f"/>',
    ]
    if opts.get("title"):
        parts.append(f'<text x="108" y="47" font-family="Arial, sans-serif" font-size="14" fill="#8b949e">{escape(opts["title"])}</text>')
    parts.append('<g font-family="Monaco, Consolas, monospace" font-size="15" fill="#c9d1d9">')
    y = 72
    start_num = int(opts.get("start_line_number") or 1)
    for idx, line in enumerate(lines):
        x = 42
        if opts.get("has_line_number"):
            parts.append(f'<text x="42" y="{y}" fill="#495162">{start_num + idx}</text>')
            x = 78
        parts.append(f'<text x="{x}" y="{y}">{escape(line)}</text>')
        y += 22
    parts.append("</g>")
    if opts.get("watermark"):
        parts.append(f'<text x="{width - 42}" y="{height - 24}" text-anchor="end" font-family="Arial, sans-serif" font-size="13" fill="#8b949e">{escape(opts["watermark"])}</text>')
    parts.append("</svg>")
    return "".join(parts)


OPTION_TAKES_VALUE = {
    "-l": "language",
    "--language": "language",
    "-w": "watermark",
    "--watermark": "watermark",
    "--title": "title",
    "--start-line-number": "start_line_number",
    "--code-font-family": "code_font_family",
    "--code-theme": "code_theme",
    "--has-breadcrumbs": "has_breadcrumbs",
    "--breadcrumbs-separator": "breadcrumbs_separator",
    "--breadcrumbs-font-family": "breadcrumbs_font_family",
    "--breadcrumbs-color": "breadcrumbs_color",
    "--line-number-color": "line_number_color",
    "-d": "delete_line",
    "--delete-line": "delete_line",
    "--delete-line-color": "delete_line_color",
    "-a": "add_line",
    "--add-line": "add_line",
    "--add-line-color": "add_line_color",
    "--highlight-range": "highlight_range",
    "--highlight-range-color": "highlight_range_color",
    "--raw-highlight-lines": "raw_highlight_lines",
    "--file-path": "file_path",
    "--watermark-font-family": "watermark_font_family",
    "--watermark-color": "watermark_color",
    "--shadow-radius": "shadow_radius",
    "--shadow-color": "shadow_color",
    "--mac-window-bar": "mac_window_bar",
    "--border-color": "border_color",
    "--margin-x": "margin_x",
    "--margin-y": "margin_y",
    "--scale-factor": "scale_factor",
    "--title-font-family": "title_font_family",
    "--title-color": "title_color",
    "--background": "background",
    "--config": "config",
    "-i": "from_image",
    "--from-image": "from_image",
}


OPTION_FLAGS = {
    "--from-clipboard": "from_clipboard",
    "--relative-highlight-range": "relative_highlight_range",
    "--has-border": "has_border",
}


if __name__ == "__main__":
    raise SystemExit(main())
