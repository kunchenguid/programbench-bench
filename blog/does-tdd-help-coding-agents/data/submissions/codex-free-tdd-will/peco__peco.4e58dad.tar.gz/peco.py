#!/usr/bin/env python3
import sys
import re


HELP = """Usage: peco [options] [FILE]

Options:
  -h, --help            show this help message and exit
  --query               initial value for query
  --rcfile              path to the settings file
  --version             print the version and exit
  -b, --buffer-size     number of lines to keep in search buffer
  --null                expect NUL (\\0) as separator for target/output
  --initial-index       position of the initial index of the selection (0 base)
  --initial-filter      specify the default filter
  --prompt              specify the prompt string
  --layout              layout to be used. 'top-down', 'bottom-up', or 'top-down-query-bottom'. default is 'top-down'
  --select-1            select first item and immediately exit if the input contains only 1 item
  --exit-0              exit immediately with status 1 if the input is empty
  --select-all          select all items and immediately exit
  --on-cancel           specify action on user cancel. 'success' or 'error'.
                        default is 'success'. This may change in future versions
  --selection-prefix    use a prefix instead of changing line color to indicate currently selected lines.
                        default is to use colors. This option is experimental
  --exec                execute command instead of finishing/terminating peco.
                        Please note that this command will receive selected line(s) from stdin,
                        and will be executed via '/bin/sh -c' or 'cmd /c'
  --print-query         print out the current query as first line of output
  --ansi                enable ANSI color code support
  --height              display height in lines or percentage (e.g. '10', '50%')
"""


def main(argv):
    select_all = False
    select_1 = False
    print_query = False
    null_mode = False
    exit_0 = False
    query = ""
    buffer_size = None
    initial_filter = "IgnoreCase"
    files = []
    i = 0
    while i < len(argv):
        arg = argv[i]
        if arg.startswith("--") and "=" in arg:
            name, value = arg.split("=", 1)
            argv = argv[:i] + [name, value] + argv[i + 1:]
            arg = argv[i]
        if arg in ("-h", "--help"):
            sys.stdout.write(HELP)
            return 0
        if arg == "--version":
            sys.stdout.write("peco version v0.5.11 (built with go1.25.0)\n")
            return 0
        if arg == "--select-all":
            select_all = True
        elif arg == "--select-1":
            select_1 = True
        elif arg == "--print-query":
            print_query = True
        elif arg == "--null":
            null_mode = True
        elif arg == "--exit-0":
            exit_0 = True
        elif arg == "--ansi":
            pass
        elif arg in ("--query", "--rcfile", "--initial-index", "--initial-filter", "--prompt", "--layout", "--on-cancel", "--selection-prefix", "--exec", "--height"):
            if i + 1 >= len(argv):
                return usage_error(f"flag needs an argument: {arg}")
            if arg == "--query":
                query = argv[i + 1]
            elif arg == "--initial-filter":
                initial_filter = argv[i + 1]
            elif arg == "--on-cancel" and argv[i + 1] not in ("success", "error"):
                sys.stderr.write(f"Error: failed to setup peco: failed to apply configuration: invalid --on-cancel value: invalid OnCancel value \"{argv[i + 1]}\": must be \"success\" or \"error\"\n")
                return 1
            i += 1
        elif arg in ("-b", "--buffer-size"):
            if i + 1 >= len(argv):
                return usage_error(f"flag needs an argument: {arg}")
            try:
                buffer_size = int(argv[i + 1])
            except ValueError:
                return usage_error(
                    f"invalid argument for flag `-b, --buffer-size' (expected int): strconv.ParseInt: parsing \"{argv[i + 1]}\": invalid syntax"
                )
            i += 1
        elif arg.startswith("-"):
            sys.stderr.write(f"unknown flag `{arg.lstrip('-')}'\n\n" + HELP + f"Error: failed to setup peco: failed to parse command line: failed to parse command line options: invalid command line options: unknown flag `{arg.lstrip('-')}'\n")
            return 1
        else:
            files.append(arg)
        i += 1

    if initial_filter not in ("IgnoreCase", "CaseSensitive", "SmartCase", "IRegexp", "Regexp", "Fuzzy"):
        sys.stderr.write("Error: failed to setup peco: failed to apply configuration: failed to populate initial filter: failed to set filter: specified filter was not found\n")
        return 1

    try:
        data = read_input(files)
    except OSError as e:
        sys.stderr.write(f"Error: failed to setup input source: failed to open file for input: {e}\n")
        return 1
    data = apply_buffer(data, buffer_size)
    source_entries = parse_entries(data, null_mode)
    entries = filter_entries(source_entries, query, initial_filter)
    if select_all:
        write_results(entries, query if print_query else None)
        return 0
    if select_1:
        if len(source_entries) == 1:
            write_results(source_entries, query if print_query else None)
            return 0
    if not source_entries and exit_0:
        return 1
    return interactive(entries, query if print_query else None)


def read_input(files):
    if files:
        with open(files[0], "rb") as f:
            return f.read()
    return sys.stdin.buffer.read()


def apply_buffer(data, size):
    if size is None:
        return data
    return b"".join(data.splitlines(True)[-max(size, 0):])


def parse_entries(data, null_mode):
    lines = data.splitlines(True)
    entries = []
    for line in lines:
        has_newline = line.endswith(b"\n")
        body = line[:-1] if has_newline else line
        if null_mode and b"\0" in body:
            display, result = body.split(b"\0", 1)
            entries.append((display, result + (b"\n" if has_newline else b"")))
        else:
            entries.append((body, line))
    return entries


def split_terms(query):
    terms = []
    cur = []
    escaped = False
    for ch in query:
        if escaped:
            cur.append(ch)
            escaped = False
        elif ch == "\\":
            escaped = True
        elif ch.isspace():
            if cur:
                terms.append("".join(cur))
                cur = []
        else:
            cur.append(ch)
    if escaped:
        cur.append("\\")
    if cur:
        terms.append("".join(cur))
    parsed = []
    for term in terms:
        if term.startswith("-") and len(term) > 1:
            parsed.append((True, term[1:]))
        else:
            parsed.append((False, term))
    return parsed


ANSI_RE = re.compile(rb"\x1b\[[0-9;?]*[ -/]*[@-~]")


def plain_text(data):
    return ANSI_RE.sub(b"", data).decode("utf-8", "ignore")


def filter_entries(entries, query, filter_name):
    terms = split_terms(query)
    if not terms:
        return entries
    out = []
    for display, result in entries:
        text = plain_text(display)
        if matches_all(text, terms, filter_name):
            out.append((display, result))
    return out


def matches_all(text, terms, filter_name):
    for negative, term in terms:
        matched = match_term(text, term, filter_name, negative)
        if negative and matched:
            return False
        if not negative and not matched:
            return False
    return True


def match_term(text, term, filter_name, negative=False):
    if term == "":
        return True
    if negative and filter_name == "Fuzzy":
        filter_name = "IRegexp"
    if filter_name == "IgnoreCase":
        return term.lower() in text.lower()
    if filter_name == "CaseSensitive":
        return term in text
    if filter_name == "SmartCase":
        if term.lower() == term:
            return term.lower() in text.lower()
        return term in text
    if filter_name == "IRegexp":
        try:
            return re.search(term, text, re.IGNORECASE) is not None
        except re.error:
            return False
    if filter_name == "Regexp":
        try:
            return re.search(term, text) is not None
        except re.error:
            return False
    if filter_name == "Fuzzy":
        haystack = text if term.lower() != term else text.lower()
        needle = term if term.lower() != term else term.lower()
        pos = 0
        for ch in needle:
            found = haystack.find(ch, pos)
            if found < 0:
                return False
            pos = found + 1
        return True
    return False


def write_results(entries, printed_query):
    if printed_query is not None:
        sys.stdout.buffer.write(printed_query.encode() + b"\n")
    for _display, result in entries:
        sys.stdout.buffer.write(result)


def interactive(entries, printed_query):
    if not sys.stdin.isatty():
        try:
            tty = open("/dev/tty", "rb", buffering=0)
        except OSError:
            sys.stderr.write("Error: failed to initialize screen: failed to create tcell screen: terminal entry not found: term not set\n")
            return 1
    else:
        tty = sys.stdin.buffer
    try:
        ch = tty.read(1)
    except Exception:
        ch = b""
    if ch in (b"\x1b", b"\x03"):
        return 0
    if entries:
        write_results([entries[0]], printed_query)
    elif printed_query is not None:
        write_results([], printed_query)
    return 0


def usage_error(message):
    sys.stderr.write(message + "\n\n" + HELP)
    return 1

if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
