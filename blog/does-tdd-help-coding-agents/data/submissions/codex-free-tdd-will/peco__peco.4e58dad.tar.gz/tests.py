#!/usr/bin/env python3
import os
import subprocess
import sys


ROOT = os.path.dirname(os.path.abspath(__file__))
BIN = os.path.join(ROOT, "executable")


def run(args, data=b""):
    return subprocess.run(
        [BIN] + args,
        input=data,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
    )


def assert_eq(actual, expected, label):
    if actual != expected:
        raise AssertionError(f"{label}: expected {expected!r}, got {actual!r}")


def test_help_and_version():
    help_result = run(["--help"])
    assert_eq(help_result.returncode, 0, "help status")
    assert b"Usage: peco [options] [FILE]\n" in help_result.stdout
    assert b"--select-all" in help_result.stdout

    version_result = run(["--version"])
    assert_eq(version_result.returncode, 0, "version status")
    assert_eq(version_result.stdout, b"peco version v0.5.11 (built with go1.25.0)\n", "version output")


def test_immediate_selection_modes():
    all_result = run(["--select-all"], b"apple\nBanana\ncarrot\n")
    assert_eq(all_result.returncode, 0, "select-all status")
    assert_eq(all_result.stdout, b"apple\nBanana\ncarrot\n", "select-all output")

    one_result = run(["--select-1"], b"only\n")
    assert_eq(one_result.returncode, 0, "select-1 status")
    assert_eq(one_result.stdout, b"only\n", "select-1 output")

    path = os.path.join(ROOT, "sample-input.txt")
    with open(path, "wb") as f:
        f.write(b"x\ny\n")
    file_result = run(["--select-all", path])
    assert_eq(file_result.returncode, 0, "file status")
    assert_eq(file_result.stdout, b"x\ny\n", "file output")


def test_output_transforming_options():
    query_result = run(["--select-1", "--query", "needle", "--print-query"], b"only\n")
    assert_eq(query_result.returncode, 0, "print-query status")
    assert_eq(query_result.stdout, b"needle\nonly\n", "print-query output")

    null_result = run(["--select-1", "--null"], b"visible\x00result\n")
    assert_eq(null_result.returncode, 0, "null status")
    assert_eq(null_result.stdout, b"result\n", "null output")

    buffer_result = run(["--select-all", "-b", "2"], b"1\n2\n3\n4\n")
    assert_eq(buffer_result.returncode, 0, "buffer status")
    assert_eq(buffer_result.stdout, b"3\n4\n", "buffer output")


def test_errors_and_documented_filters():
    missing = run(["--select-all", "/tmp/does-not-exist-for-peco"])
    assert_eq(missing.returncode, 1, "missing status")
    assert b"failed to open file for input" in missing.stderr

    bad_filter = run(["--select-1", "--initial-filter", "Bad"], b"only\n")
    assert_eq(bad_filter.returncode, 1, "bad filter status")
    assert b"specified filter was not found" in bad_filter.stderr

    filtered = run(["--select-all", "--query", "foo -bar"], b"foo one\nfoo bar\nnope\n")
    assert_eq(filtered.returncode, 0, "filtered status")
    assert_eq(filtered.stdout, b"foo one\n", "filtered output")

    fuzzy = run(["--select-all", "--initial-filter", "Fuzzy", "--query", "ALS"], b"ALongString\nwrong\n")
    assert_eq(fuzzy.returncode, 0, "fuzzy status")
    assert_eq(fuzzy.stdout, b"ALongString\n", "fuzzy output")


def main():
    test_help_and_version()
    test_immediate_selection_modes()
    test_output_transforming_options()
    test_errors_and_documented_filters()
    print("ok")


if __name__ == "__main__":
    main()
