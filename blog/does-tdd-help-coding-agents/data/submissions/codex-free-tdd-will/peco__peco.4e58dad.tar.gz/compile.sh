#!/bin/bash
set -e
cp peco.py executable
chmod +x executable
