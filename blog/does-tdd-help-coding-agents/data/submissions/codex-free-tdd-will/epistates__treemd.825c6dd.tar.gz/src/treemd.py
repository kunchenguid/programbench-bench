#!/usr/bin/env python3
import argparse
import json
import re
import sys


HEADING_RE = re.compile(r"^(#{1,6})[ \t]+(.+?)[ \t]*#*[ \t]*$")
LINK_RE = re.compile(r"\[([^\]]+)\]\(([^)\s]+)(?:\s+\"[^\"]*\")?\)")


def read_document(path):
    if path == "-":
        return sys.stdin.read()
    with open(path, "r", encoding="utf-8") as f:
        return f.read()


def parse_headings(text):
    headings = []
    in_fence = False
    for line_no, line in enumerate(text.splitlines(), 1):
        if line.startswith("```") or line.startswith("~~~"):
            in_fence = not in_fence
            continue
        if in_fence:
            continue
        match = HEADING_RE.match(line)
        if match:
            marks, title = match.groups()
            headings.append({"level": len(marks), "title": title.strip(), "line": line_no})
    return headings


def filter_headings(headings, level=None, pattern=None):
    if level is not None:
        headings = [heading for heading in headings if heading["level"] == level]
    if pattern:
        needle = pattern.lower()
        headings = [heading for heading in headings if needle in heading["title"].lower()]
    return headings


def print_headings(headings):
    for heading in headings:
        print("#" * heading["level"], heading["title"])


def build_tree(headings):
    root = {"children": []}
    stack = [(0, root)]
    for heading in headings:
        node = dict(heading)
        node["children"] = []
        while stack and stack[-1][0] >= node["level"]:
            stack.pop()
        stack[-1][1]["children"].append(node)
        stack.append((node["level"], node))
    return root["children"]


def print_tree(nodes, prefix=""):
    for index, node in enumerate(nodes):
        last = index == len(nodes) - 1
        connector = "└──" if last else "├──"
        print(f"{prefix}{connector}{'#' * node['level']} {node['title']}")
        child_prefix = prefix + ("   " if last else "│  ")
        print_tree(node["children"], child_prefix)


def heading_summary_json(headings):
    items = [{"level": heading["level"], "text": heading["title"]} for heading in headings]
    print(json.dumps(items, indent=2))


def slugify(title):
    slug = re.sub(r"[^a-z0-9]+", "-", title.lower()).strip("-")
    return slug or "section"


def word_count(text):
    return len(re.findall(r"\b\w+\b", text))


def section_node_json(node):
    return {
        "id": slugify(node["title"]),
        "level": node["level"],
        "title": node["title"],
        "slug": slugify(node["title"]),
        "position": {"line": node["line"], "offset": 0},
        "content": {"raw": "", "blocks": []},
        "children": [section_node_json(child) for child in node["children"]],
    }


def document_json(text, headings):
    tree = build_tree(headings)
    payload = {
        "document": {
            "metadata": {
                "source": None,
                "headingCount": len(headings),
                "maxDepth": max((heading["level"] for heading in headings), default=0),
                "wordCount": word_count(text),
            },
            "sections": [section_node_json(node) for node in tree],
        }
    }
    print(json.dumps(payload, indent=2))


def print_counts(headings):
    print("Heading counts:")
    total = 0
    for level in range(1, 7):
        count = sum(1 for heading in headings if heading["level"] == level)
        if count:
            total += count
            print(f"  {'#' * level}: {count}")
    print()
    print(f"Total: {total}")


def extract_section(text, headings, title):
    lowered = title.lower()
    for index, heading in enumerate(headings):
        if heading["title"].lower() != lowered:
            continue
        end_line = len(text.splitlines()) + 1
        for later in headings[index + 1 :]:
            if later["level"] <= heading["level"]:
                end_line = later["line"]
                break
        lines = text.splitlines()[heading["line"] - 1 : end_line - 1]
        while lines and lines[-1] == "":
            lines.pop()
        return "\n".join(lines) + "\n"
    return None


def iter_code_blocks(text):
    lines = text.splitlines()
    i = 0
    while i < len(lines):
        line = lines[i]
        if line.startswith("```") or line.startswith("~~~"):
            fence = line[:3]
            start = i
            i += 1
            while i < len(lines) and not lines[i].startswith(fence):
                i += 1
            if i < len(lines):
                yield "\n".join(lines[start : i + 1]) + "\n"
        i += 1


def query_items(selector, text, headings):
    if selector == ".h":
        return [{"type": "heading", "level": h["level"], "text": h["title"], "line": h["line"]} for h in headings]
    if re.fullmatch(r"\.h[1-6]", selector):
        level = int(selector[2])
        return [
            {"type": "heading", "level": h["level"], "text": h["title"], "line": h["line"]}
            for h in headings
            if h["level"] == level
        ]
    if selector == ".code":
        return [{"type": "code", "markdown": block} for block in iter_code_blocks(text)]
    if selector == ".link":
        return [
            {"type": "link", "text": m.group(1), "url": m.group(2), "link_type": "external"}
            for m in LINK_RE.finditer(text)
        ]
    return None


def print_query_plain(items):
    for item in items:
        if item["type"] == "heading":
            print("#" * item["level"], item["text"])
        elif item["type"] == "code":
            sys.stdout.write(item["markdown"])
        elif item["type"] == "link":
            print(f"[{item['text']}]({item['url']})")


def run_query(expr, text, headings, output="plain"):
    expr = expr.strip()
    if expr.startswith("[") and expr.endswith("] | count"):
        selector = expr[1 : expr.index("]")]
        items = query_items(selector, text, headings)
        if items is None:
            return 1
        print(len(items))
        return 0

    pipe_text = False
    if expr.endswith("| text"):
        selector = expr[: -len("| text")].strip()
        pipe_text = True
    else:
        selector = expr

    items = query_items(selector, text, headings)
    if items is None:
        return 1

    if output == "json":
        print(json.dumps(items, separators=(",", ":")))
    elif pipe_text:
        for item in items:
            print(item.get("text", ""))
    else:
        print_query_plain(items)
    return 0


def main(argv=None):
    argv = list(sys.argv[1:] if argv is None else argv)
    if argv[:1] == ["at-line"]:
        if len(argv) > 1 and argv[1] in ("-h", "--help"):
            print("Show heading at specific line number")
            print()
            print("Usage: executable at-line <LINE>")
            return 0
        return 0

    parser = argparse.ArgumentParser(add_help=False)
    parser.add_argument("-l", "--list", action="store_true")
    parser.add_argument("--tree", action="store_true")
    parser.add_argument("-o", "--output", default="plain")
    parser.add_argument("--count", action="store_true")
    parser.add_argument("-s", "--section")
    parser.add_argument("-q", "--query")
    parser.add_argument("--query-output", default="plain")
    parser.add_argument("-L", "--level", type=int)
    parser.add_argument("--filter")
    parser.add_argument("files", nargs="*")
    parser.add_argument("-h", "--help", action="store_true")
    parser.add_argument("-V", "--version", action="store_true")
    args, _ = parser.parse_known_args(argv)

    if args.version:
        print("treemd 0.5.7")
        return 0

    if args.help:
        print("treemd - A modern markdown viewer combining tree-based navigation with interactive TUI.")
        print()
        print("Usage: executable [OPTIONS] [FILE]... [COMMAND]")
        print()
        print("Options:")
        print("  -l, --list")
        print("      --tree")
        print("  -s, --section <HEADING>")
        print("  -q, --query <EXPR>")
        print("  -h, --help")
        print("  -V, --version")
        return 0

    filename = args.files[0] if args.files else None
    text = read_document(filename) if filename else ""
    headings = filter_headings(parse_headings(text), args.level, args.filter)
    if args.list:
        if args.output == "tree":
            print("Use --tree for tree output")
            return 1
        if args.output == "json":
            document_json(text, headings)
        else:
            print_headings(headings)
    elif args.tree:
        if args.output == "json":
            heading_summary_json(headings)
        else:
            print_tree(build_tree(headings))
    elif args.count:
        print_counts(headings)
    elif args.section:
        section = extract_section(text, parse_headings(text), args.section)
        if section is None:
            print(f"Section '{args.section}' not found")
            return 1
        sys.stdout.write(section)
    elif args.query:
        return run_query(args.query, text, headings, args.query_output)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
