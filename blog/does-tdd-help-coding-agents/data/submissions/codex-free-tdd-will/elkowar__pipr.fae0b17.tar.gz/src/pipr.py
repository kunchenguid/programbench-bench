#!/usr/bin/env python3
import os, select, shutil, subprocess, sys, termios, tty

HELP = """Usage: ./executable [options]

Options:
    -d, --default TEXT  text inserted into the textfield on startup
    -o, --out-file FILE write final command to file
        --in-file FILE  read initial command from file
        --config-reference 
                        print out the default configuration file
    -r, --raw-mode      keep linebreaks in finished command when closing
        --no-isolation  disable isolation. This will run the commands directly
                        on your system, without protection. Take care.
    -h, --help          print this help menu
"""

CONFIG = """
#  ____  _
# |  _ \\(_)_ __  _ __       .________.
# | |_) | | '_ \\| '__|      |________|
# |  __/| | |_) | |          |_    -|
# |_|   |_| .__/|_|     xX  xXx___x_|
#         |_|
#
# A commandline utility by
# Leon Kowarschick

# finish_hook: Executed once you close pipr, getting the command you constructed piped into stdin.
# finish_hook = "xclip -selection clipboard -in"

# Paranoid history mode writes every sucessfully running command into the history in autoeval mode.
paranoid_history_mode_default = false

autoeval_mode_default = true

history_size = 500
cmdlist_always_show_preview = false
cmd_timeout_millis = 2000

highlighting_enabled = true

eval_environment = ["bash", "-c"]

# Snippets can be used to quickly insert common bits of shell
# use || (two pipes) where you want your cursor to be after insertion
[snippets]
s = " | sed -r 's/||//g'"

[help_viewers]
'm' = "man ??"
'h' = "?? --help | less"

[output_viewers]
'l' = "less"

"""

BWRAP = "bubblewrap installation not found. Please make sure you have `bwrap` on your path, or supply --no-isolation to disable safe-mode\n"

class OptError(Exception):
    pass

def missing(name):
    raise OptError(f"Argument to option '{name}' missing")

def parse(argv):
    opts = {"default": None, "out_file": None, "in_file": None, "raw": False, "no_isolation": False, "help": False, "config": False}
    i = 1
    while i < len(argv):
        a = argv[i]
        if a == '--':
            i += 1; continue
        if a.startswith('--') and len(a) > 2:
            name = a[2:]; val = None
            if '=' in name:
                name, val = name.split('=', 1)
            if name == 'help':
                if val is not None: raise OptError("Option 'help' does not take an argument")
                opts['help'] = True
            elif name == 'config-reference':
                if val is not None: raise OptError("Option 'config-reference' does not take an argument")
                opts['config'] = True
            elif name == 'raw-mode':
                if val is not None: raise OptError("Option 'raw-mode' does not take an argument")
                opts['raw'] = True
            elif name == 'no-isolation':
                if val is not None: raise OptError("Option 'no-isolation' does not take an argument")
                opts['no_isolation'] = True
            elif name in ('default', 'out-file', 'in-file'):
                if val is None:
                    i += 1
                    if i >= len(argv): missing(name)
                    val = argv[i]
                if name == 'default': opts['default'] = val
                elif name == 'out-file': opts['out_file'] = val
                else: opts['in_file'] = val
            else:
                raise OptError(f"Unrecognized option: '{name}'")
        elif a.startswith('-') and len(a) > 1:
            j = 1
            while j < len(a):
                c = a[j]
                if c == 'h': opts['help'] = True; j += 1
                elif c == 'r': opts['raw'] = True; j += 1
                elif c in ('d', 'o'):
                    if j + 1 < len(a):
                        val = a[j+1:]; j = len(a)
                    else:
                        i += 1
                        if i >= len(argv): missing(c)
                        val = argv[i]; j = len(a)
                    if c == 'd': opts['default'] = val
                    else: opts['out_file'] = val
                else:
                    raise OptError(f"Unrecognized option: '{c}'")
        i += 1
    return opts

def load_command(opts):
    if opts['default'] is not None:
        return opts['default']
    if opts['in_file']:
        try:
            with open(opts['in_file'], 'r', encoding='utf-8') as f:
                return f.read()
        except Exception:
            return ''
    return ''

def finish(opts, command):
    final = command if opts['raw'] else command.replace('\n', ' ')
    if opts['out_file']:
        with open(opts['out_file'], 'w', encoding='utf-8') as f:
            f.write(final)
    sys.stdout.write('\x1b[?1049l')
    sys.stdout.write(final + '\r\n')
    sys.stdout.flush()

def evaluate(command):
    if not command.strip():
        return ''
    try:
        p = subprocess.run(['bash', '-c', command], stdout=subprocess.PIPE, stderr=subprocess.STDOUT, timeout=2)
        return p.stdout.decode('utf-8', 'replace')
    except subprocess.TimeoutExpired:
        return 'Command timed out\n'
    except Exception as e:
        return f'{e}\n'

def redraw(command, output=''):
    sys.stdout.write('\x1b[?1049h\x1b[2J\x1b[H')
    sys.stdout.write('┌ Command [Autoeval] ┐\r\n')
    sys.stdout.write(command.replace('\n', ' ') + '\r\n')
    sys.stdout.write('┌ Output [+] ┐\r\n')
    if output:
        sys.stdout.write(output.replace('\n', '\r\n'))
    sys.stdout.flush()

def interactive(opts):
    command = load_command(opts)
    output = evaluate(command)
    old = termios.tcgetattr(sys.stdin.fileno())
    try:
        tty.setraw(sys.stdin.fileno())
        redraw(command, output)
        while True:
            r, _, _ = select.select([sys.stdin], [], [], 0.25)
            if not r:
                continue
            ch = os.read(sys.stdin.fileno(), 1)
            if ch in (b'\x03', b'\x11', b'\x1b'):
                termios.tcsetattr(sys.stdin.fileno(), termios.TCSADRAIN, old)
                finish(opts, command)
                return 0
            if ch in (b'\r', b'\n'):
                output = evaluate(command)
            elif ch in (b'\x7f', b'\b'):
                command = command[:-1]
            elif ch == b'\x04':
                pass
            elif 32 <= ch[0] < 127:
                command += ch.decode('ascii', 'ignore')
                output = evaluate(command)
            redraw(command, output)
    finally:
        try:
            termios.tcsetattr(sys.stdin.fileno(), termios.TCSADRAIN, old)
        except Exception:
            pass

def main(argv):
    try:
        opts = parse(argv)
    except OptError as e:
        sys.stderr.write(f"./executable: {e}\n")
        return 1
    if opts['help']:
        sys.stdout.write(HELP); return 0
    if opts['config']:
        sys.stdout.write(CONFIG); return 0
    if not opts['no_isolation'] and shutil.which('bwrap') is None:
        sys.stdout.write(BWRAP); return 1
    if not sys.stdin.isatty():
        sys.stderr.write('\x1b[?1049hError: No such device or address (os error 6)\n')
        return 1
    return interactive(opts)

if __name__ == '__main__':
    sys.exit(main(sys.argv))
