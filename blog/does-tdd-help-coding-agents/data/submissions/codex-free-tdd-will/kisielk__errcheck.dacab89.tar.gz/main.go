package main

import (
	"bytes"
	"flag"
	"fmt"
	"go/ast"
	"go/build"
	"go/importer"
	"go/parser"
	"go/printer"
	"go/token"
	"go/types"
	"io"
	"os"
	"path/filepath"
	"regexp"
	"sort"
	"strings"
)

type config struct {
	abspath         bool
	asserts         bool
	blank           bool
	ignoretests     bool
	ignoregenerated bool
	verbose         bool
	tags            multiFlag
	ignore          multiFlag
	ignorepkg       string
	exclude         string
	excludeonly     bool
	ignoreRules     []ignoreRule
	ignorePkgs      map[string]bool
	excludes        map[string]bool
	fmtRuleGiven    bool
}

type ignoreRule struct {
	pkg string
	re  *regexp.Regexp
}

type finding struct {
	pos  token.Position
	text string
}

func main() {
	code := run(os.Args[1:], os.Stdout, os.Stderr)
	os.Exit(code)
}

func run(args []string, stdout, stderr *os.File) int {
	cfg := config{}
	fs := flag.NewFlagSet(os.Args[0], flag.ContinueOnError)
	fs.SetOutput(stderr)
	fs.BoolVar(&cfg.abspath, "abspath", false, "print absolute paths to files")
	fs.BoolVar(&cfg.asserts, "asserts", false, "if true, check for ignored type assertion results")
	fs.BoolVar(&cfg.blank, "blank", false, "if true, check for errors assigned to blank identifier")
	fs.StringVar(&cfg.exclude, "exclude", "", "Path to a file containing a list of functions to exclude from checking")
	fs.BoolVar(&cfg.excludeonly, "excludeonly", false, "Use only excludes from -exclude file")
	fs.Var(&cfg.ignore, "ignore", "[deprecated] comma-separated list of pairs of the form pkg:regex\n            the regex is used to ignore names within pkg.")
	fs.BoolVar(&cfg.ignoregenerated, "ignoregenerated", false, "if true, checking of files with generated code is disabled")
	fs.StringVar(&cfg.ignorepkg, "ignorepkg", "", "comma-separated list of package paths to ignore")
	fs.BoolVar(&cfg.ignoretests, "ignoretests", false, "if true, checking of _test.go files is disabled")
	fs.String("mod", "", "module download mode to use: readonly or vendor. See 'go help modules' for more.")
	fs.Var(&cfg.tags, "tags", "comma or space-separated list of build tags to include")
	fs.BoolVar(&cfg.verbose, "verbose", false, "produce more verbose logging")
	if err := fs.Parse(args); err != nil {
		return 2
	}
	if err := cfg.prepare(stderr); err != nil {
		fmt.Fprintf(stderr, "error: %v\n", err)
		return 2
	}
	patterns := fs.Args()
	if len(patterns) == 0 {
		patterns = []string{"."}
	}

	var all []finding
	for _, pattern := range patterns {
		dirs, err := expandPattern(pattern)
		if err != nil {
			fmt.Fprintf(stderr, "error: %v\n", err)
			return 2
		}
		for _, dir := range dirs {
			findings, err := checkDir(dir, cfg)
			if err != nil {
				fmt.Fprintf(stderr, "error: failed to check packages: %v\n", err)
				return 2
			}
			all = append(all, findings...)
		}
	}
	sort.SliceStable(all, func(i, j int) bool {
		if all[i].pos.Filename != all[j].pos.Filename {
			return all[i].pos.Filename < all[j].pos.Filename
		}
		if all[i].pos.Line != all[j].pos.Line {
			return all[i].pos.Line < all[j].pos.Line
		}
		return all[i].pos.Column < all[j].pos.Column
	})
	for _, f := range all {
		fmt.Fprintf(stdout, "%s:%d:%d:\t%s\n", f.pos.Filename, f.pos.Line, f.pos.Column, f.text)
	}
	if len(all) > 0 {
		return 1
	}
	return 0
}

type multiFlag []string

func (l *multiFlag) String() string { return strings.Join(*l, ",") }
func (l *multiFlag) Set(s string) error {
	*l = append(*l, s)
	return nil
}

func (cfg *config) prepare(stderr io.Writer) error {
	cfg.ignorePkgs = map[string]bool{}
	cfg.excludes = map[string]bool{}
	for _, pkg := range splitList(cfg.ignorepkg) {
		cfg.ignorePkgs[pkg] = true
	}
	for _, raw := range cfg.ignore {
		for _, item := range splitComma(raw) {
			pkg, pattern, _ := strings.Cut(item, ":")
			if pattern == "" {
				pattern = pkg
				pkg = ""
			}
			if pkg == "fmt" {
				cfg.fmtRuleGiven = true
			}
			re, err := regexp.Compile(pattern)
			if err != nil {
				return err
			}
			cfg.ignoreRules = append(cfg.ignoreRules, ignoreRule{pkg: pkg, re: re})
		}
	}
	if cfg.exclude != "" {
		data, err := os.ReadFile(cfg.exclude)
		if err != nil {
			return err
		}
		for _, line := range strings.Split(string(data), "\n") {
			line = strings.TrimSpace(line)
			if line == "" || strings.HasPrefix(line, "//") {
				continue
			}
			if i := strings.Index(line, "("); i > 0 {
				line = line[:i]
			}
			cfg.excludes[line] = true
			if cfg.verbose {
				fmt.Fprintf(stderr, "excluding %s\n", line)
			}
		}
	}
	return nil
}

func expandPattern(pattern string) ([]string, error) {
	if pattern == "all" {
		pattern = "./..."
	}
	if strings.HasSuffix(pattern, "/...") {
		root := strings.TrimSuffix(pattern, "/...")
		if root == "" {
			root = "."
		}
		var dirs []string
		err := filepath.WalkDir(root, func(path string, d os.DirEntry, err error) error {
			if err != nil {
				return err
			}
			if !d.IsDir() {
				return nil
			}
			name := d.Name()
			if name == ".git" || name == "vendor" || strings.HasPrefix(name, ".") && path != "." {
				return filepath.SkipDir
			}
			if hasGoFiles(path) {
				dirs = append(dirs, path)
			}
			return nil
		})
		return dirs, err
	}
	return []string{pattern}, nil
}

func hasGoFiles(dir string) bool {
	entries, err := os.ReadDir(dir)
	if err != nil {
		return false
	}
	for _, entry := range entries {
		if !entry.IsDir() && strings.HasSuffix(entry.Name(), ".go") {
			return true
		}
	}
	return false
}

func isGenerated(src []byte) bool {
	for _, line := range strings.Split(string(src), "\n") {
		trimmed := strings.TrimSpace(line)
		if trimmed == "" {
			continue
		}
		if strings.Contains(trimmed, "Code generated") && strings.Contains(trimmed, "DO NOT EDIT.") {
			return true
		}
		if !strings.HasPrefix(trimmed, "//") && !strings.HasPrefix(trimmed, "/*") && !strings.HasPrefix(trimmed, "*") {
			return false
		}
	}
	return false
}

func checkDir(dir string, cfg config) ([]finding, error) {
	ctxt := build.Default
	ctxt.BuildTags = splitTags(cfg.tags)
	pkg, err := ctxt.ImportDir(dir, 0)
	if err != nil {
		if _, ok := err.(*build.NoGoError); ok {
			return nil, nil
		}
		return nil, err
	}
	names := append([]string{}, pkg.GoFiles...)
	names = append(names, pkg.CgoFiles...)
	if !cfg.ignoretests {
		names = append(names, pkg.TestGoFiles...)
	}
	fset := token.NewFileSet()
	var files []*ast.File
	lines := map[string][]string{}
	for _, name := range names {
		path := filepath.Join(dir, name)
		src, err := os.ReadFile(path)
		if err != nil {
			return nil, err
		}
		if cfg.ignoregenerated && isGenerated(src) {
			continue
		}
		lines[path] = strings.Split(string(src), "\n")
		file, err := parser.ParseFile(fset, path, src, parser.ParseComments)
		if err != nil {
			return nil, err
		}
		files = append(files, file)
	}
	if len(files) == 0 {
		return nil, nil
	}
	info := &types.Info{
		Types: make(map[ast.Expr]types.TypeAndValue),
		Uses:  make(map[*ast.Ident]types.Object),
		Defs:  make(map[*ast.Ident]types.Object),
	}
	conf := types.Config{Importer: importer.Default()}
	if _, err := conf.Check(pkg.ImportPath, fset, files, info); err != nil {
		return nil, err
	}

	var findings []finding
	for _, file := range files {
		ast.Inspect(file, func(n ast.Node) bool {
			var call *ast.CallExpr
			switch stmt := n.(type) {
			case *ast.ExprStmt:
				call, _ = stmt.X.(*ast.CallExpr)
			case *ast.GoStmt:
				call = stmt.Call
			case *ast.DeferStmt:
				call = stmt.Call
			default:
				return true
			}
			if call == nil || !returnsError(info.TypeOf(call)) {
				return true
			}
			if cfg.ignoredCall(call, info) {
				return true
			}
			findings = append(findings, finding{pos: displayPos(fset, call.Lparen, cfg), text: nodeString(fset, call)})
			return true
		})
		if cfg.blank {
			ast.Inspect(file, func(n ast.Node) bool {
				stmt, ok := n.(*ast.AssignStmt)
				if !ok {
					return true
				}
				for _, rhs := range stmt.Rhs {
					call, ok := rhs.(*ast.CallExpr)
					posn, ok := blankedError(stmt.Lhs, info.TypeOf(call), call)
					if !ok || posn == token.NoPos {
						continue
					}
					if cfg.ignoredCall(call, info) {
						continue
					}
					findings = append(findings, finding{pos: displayPos(fset, posn, cfg), text: sourceLine(fset, lines, stmt.Pos(), nodeString(fset, stmt))})
				}
				return true
			})
		}
		if cfg.asserts {
			ast.Inspect(file, func(n ast.Node) bool {
				stmt, ok := n.(*ast.AssignStmt)
				if !ok {
					return true
				}
				for _, rhs := range stmt.Rhs {
					assertion, ok := rhs.(*ast.TypeAssertExpr)
					if !ok {
						continue
					}
					if len(stmt.Lhs) == 1 {
						findings = append(findings, finding{pos: displayPos(fset, assertion.X.Pos(), cfg), text: sourceLine(fset, lines, stmt.Pos(), nodeString(fset, stmt))})
						continue
					}
					if cfg.blank && len(stmt.Lhs) == 2 && isBlank(stmt.Lhs[1]) {
						findings = append(findings, finding{pos: displayPos(fset, stmt.Lhs[1].Pos(), cfg), text: sourceLine(fset, lines, stmt.Pos(), nodeString(fset, stmt))})
					}
				}
				return true
			})
		}
	}
	return findings, nil
}

func blankedError(lhs []ast.Expr, t types.Type, call *ast.CallExpr) (token.Pos, bool) {
	tuple, ok := t.(*types.Tuple)
	if !ok {
		if len(lhs) == 1 && isBlank(lhs[0]) && isError(t) {
			return call.Fun.Pos(), true
		}
		return token.NoPos, false
	}
	if len(lhs) != tuple.Len() {
		return token.NoPos, false
	}
	for i := 0; i < tuple.Len(); i++ {
		if isBlank(lhs[i]) && isError(tuple.At(i).Type()) {
			return lhs[i].Pos(), true
		}
	}
	return token.NoPos, false
}

func isBlank(expr ast.Expr) bool {
	id, ok := expr.(*ast.Ident)
	return ok && id.Name == "_"
}

func (cfg config) ignoredCall(call *ast.CallExpr, info *types.Info) bool {
	full, pkg, name := callName(call, info)
	if full == "" {
		return false
	}
	if cfg.ignorePkgs[pkg] {
		return true
	}
	if !cfg.excludeonly {
		if pkg == "fmt" && !cfg.fmtRuleGiven {
			return true
		}
	}
	if cfg.excludes[full] || cfg.excludes[pkg+"."+name] || cfg.excludes[name] {
		return true
	}
	for _, rule := range cfg.ignoreRules {
		if rule.pkg != "" && rule.pkg != pkg {
			continue
		}
		if rule.re.MatchString(name) || rule.re.MatchString(full) {
			return true
		}
	}
	return false
}

func callName(call *ast.CallExpr, info *types.Info) (full, pkg, name string) {
	var obj types.Object
	switch fun := call.Fun.(type) {
	case *ast.SelectorExpr:
		obj = info.Uses[fun.Sel]
	case *ast.Ident:
		obj = info.Uses[fun]
		if obj == nil {
			obj = info.Defs[fun]
		}
	}
	fn, ok := obj.(*types.Func)
	if !ok {
		return "", "", ""
	}
	if fn.Pkg() != nil {
		pkg = fn.Pkg().Path()
	}
	name = fn.Name()
	full = fn.FullName()
	if full == "" && pkg != "" {
		full = pkg + "." + name
	}
	return full, pkg, name
}

func displayPos(fset *token.FileSet, posn token.Pos, cfg config) token.Position {
	pos := fset.Position(posn)
	if cfg.abspath {
		if abs, err := filepath.Abs(pos.Filename); err == nil {
			pos.Filename = abs
		}
	} else {
		pos.Filename = filepath.Base(pos.Filename)
	}
	return pos
}

func splitComma(s string) []string {
	var out []string
	for _, item := range strings.Split(s, ",") {
		item = strings.TrimSpace(item)
		if item != "" {
			out = append(out, item)
		}
	}
	return out
}

func splitList(s string) []string {
	return splitComma(s)
}

func splitTags(values []string) []string {
	var tags []string
	for _, value := range values {
		for _, field := range strings.FieldsFunc(value, func(r rune) bool { return r == ',' || r == ' ' || r == '\t' || r == '\n' }) {
			if field != "" {
				tags = append(tags, field)
			}
		}
	}
	return tags
}

func returnsError(t types.Type) bool {
	if t == nil {
		return false
	}
	if tuple, ok := t.(*types.Tuple); ok {
		for i := 0; i < tuple.Len(); i++ {
			if isError(tuple.At(i).Type()) {
				return true
			}
		}
		return false
	}
	return isError(t)
}

func isError(t types.Type) bool {
	named, ok := t.(*types.Named)
	if !ok {
		return false
	}
	obj := named.Obj()
	return obj.Name() == "error" && obj.Pkg() == nil
}

func nodeString(fset *token.FileSet, n ast.Node) string {
	var buf bytes.Buffer
	_ = printer.Fprint(&buf, fset, n)
	return buf.String()
}

func sourceLine(fset *token.FileSet, lines map[string][]string, posn token.Pos, fallback string) string {
	pos := fset.Position(posn)
	fileLines := lines[pos.Filename]
	if pos.Line <= 0 || pos.Line > len(fileLines) {
		return fallback
	}
	return strings.TrimSpace(fileLines[pos.Line-1])
}
