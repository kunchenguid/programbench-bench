module errclone

go 1.21
