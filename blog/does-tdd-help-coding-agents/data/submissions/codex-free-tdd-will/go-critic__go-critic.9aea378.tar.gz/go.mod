module reimpl-go-critic

go 1.20
