package main

import (
	"flag"
	"fmt"
	"go/ast"
	"go/format"
	"go/parser"
	"go/token"
	"os"
	"path/filepath"
	"sort"
	"strings"
)

const version = "v0.0.0-SNAPSHOT"

func main() {
	if len(os.Args) == 1 {
		fmt.Println("no args provided")
		return
	}

	switch os.Args[1] {
	case "version":
		fmt.Printf("go-critic version: %s\n", version)
	case "help":
		printHelp()
	case "doc":
		runDoc(os.Args[2:])
	case "check":
		runCheck(os.Args[2:])
	default:
		fmt.Printf("%q unknown command, did you mean \"help\"?\n", os.Args[1])
		fmt.Println(`Run "go-critic help" for usage.`)
		fmt.Println()
		fmt.Printf("no such command %q\n", os.Args[1])
		os.Exit(1)
	}
}

type diagnostic struct {
	file string
	line int
	col  int
	name string
	msg  string
}

func runCheck(args []string) {
	for _, arg := range args {
		if arg == "-help" || arg == "--help" {
			printCheckHelp()
			return
		}
	}
	fs := flag.NewFlagSet("go-critic", flag.ContinueOnError)
	fs.SetOutput(os.Stdout)
	enable := fs.String("enable", "appendAssign,argOrder,assignOp,badCall,badCond,captLocal,caseOrder,codegenComment,commentFormatting,defaultCaseOrder,deprecatedComment,dupArg,dupBranchBody,dupCase,dupSubExpr,elseif,exitAfterDefer,flagDeref,flagName,ifElseChain,mapKey,newDeref,offBy1,regexpMust,singleCaseSwitch,sloppyLen,sloppyTypeAssert,switchTrue,typeSwitchVar,underef,unlambda,unslice,valSwap,wrapperFunc", "")
	disable := fs.String("disable", "", "")
	enableAll := fs.Bool("enableAll", false, "")
	exitCode := fs.Int("exitCode", 1, "")
	_ = fs.Bool("v", false, "")
	_ = fs.Bool("checkTests", true, "")
	_ = fs.Bool("checkGenerated", false, "")
	_ = fs.Int("concurrency", 16, "")
	_ = fs.String("go", "", "")
	registerIgnoredCheckerParams(fs)
	if err := fs.Parse(args); err != nil {
		fmt.Println("parse args:", err)
		return
	}
	targets := fs.Args()
	if len(targets) == 0 {
		fmt.Println("no targets specified")
		return
	}
	enabled := enabledSet(*enable, *disable, *enableAll)
	var diags []diagnostic
	for _, target := range targets {
		files, err := expandTarget(target)
		if err != nil {
			fmt.Println(err)
			os.Exit(1)
		}
		for _, file := range files {
			diags = append(diags, lintFile(file, enabled)...)
		}
	}
	sort.SliceStable(diags, func(i, j int) bool {
		oi, oj := checkerOrder(diags[i].name), checkerOrder(diags[j].name)
		if oi != oj {
			return oi < oj
		}
		if diags[i].file != diags[j].file {
			return diags[i].file < diags[j].file
		}
		if diags[i].line != diags[j].line {
			return diags[i].line < diags[j].line
		}
		if diags[i].col != diags[j].col {
			return diags[i].col < diags[j].col
		}
		return diags[i].name < diags[j].name
	})
	for _, d := range diags {
		fmt.Printf("%s:%d:%d: %s: %s\n", d.file, d.line, d.col, d.name, d.msg)
	}
	if len(diags) != 0 {
		os.Exit(*exitCode)
	}
}

func printCheckHelp() {
	fmt.Println(`Usage of go-critic:
  -@captLocal.paramsOnly
    	whether to restrict checker to params only (default true)
  -@commentedOutCode.minLength int
    	min length of the comment that triggers a warning (default 15)
  -@elseif.skipBalanced
    	whether to skip balanced if-else pairs (default true)
  -@hugeParam.sizeThreshold int
    	size in bytes that makes the warning trigger (default 80)
  -@ifElseChain.minThreshold int
    	min number of if-else blocks that makes the warning trigger (default 2)
  -@nestingReduce.bodyWidth int
    	min number of statements inside a branch to trigger a warning (default 5)
  -@rangeExprCopy.sizeThreshold int
    	size in bytes that makes the warning trigger (default 512)
  -@rangeExprCopy.skipTestFuncs
    	whether to check test functions (default true)
  -@rangeValCopy.sizeThreshold int
    	size in bytes that makes the warning trigger (default 128)
  -@rangeValCopy.skipTestFuncs
    	whether to check test functions (default true)
  -@ruleguard.debug string
    	enable debug for the specified named rules group
  -@ruleguard.disable string
    	comma-separated list of disabled groups or skip empty to enable everything
  -@ruleguard.enable string
    	comma-separated list of enabled groups or skip empty to enable everything (default "<all>")
  -@ruleguard.failOn string
    	Determines the behavior when an error occurs while parsing ruleguard files.
    	If flag is not set, log error and skip rule files that contain an error.
    	If flag is set, the value must be a comma-separated list of error conditions.
    	* 'import': rule refers to a package that cannot be loaded.
    	* 'dsl':    gorule file does not comply with the ruleguard DSL.
  -@ruleguard.failOnError
    	deprecated, use failOn param; if set to true, identical to failOn='all', otherwise failOn=''
  -@ruleguard.rules string
    	comma-separated list of gorule file paths. Glob patterns such as 'rules-*.go' may be specified
  -@tooManyResultsChecker.maxResults int
    	maximum number of results (default 5)
  -@truncateCmp.skipArchDependent
    	whether to skip int/uint/uintptr types (default true)
  -@underef.skipRecvDeref
    	whether to skip (*x).method() calls where x is a pointer receiver (default true)
  -@unnamedResult.checkExported
    	whether to check exported functions
  -checkGenerated
    	whether to check generated files
  -checkTests
    	whether to check test files (default true)
  -concurrency int
    	how many concurrent checkers to run (default is runtime.GOMAXPROCS(0)) (default 16)
  -cpuprofile string
    	write CPU profile to the specified file
  -disable string
    	comma-separated list of checkers to be disabled. Can include #tags
  -enable string
    	comma-separated list of enabled checkers. Can include #tags (default "appendAssign,argOrder,assignOp,badCall,badCond,captLocal,caseOrder,codegenComment,commentFormatting,defaultCaseOrder,deprecatedComment,dupArg,dupBranchBody,dupCase,dupSubExpr,elseif,exitAfterDefer,flagDeref,flagName,ifElseChain,mapKey,newDeref,offBy1,regexpMust,singleCaseSwitch,sloppyLen,sloppyTypeAssert,switchTrue,typeSwitchVar,underef,unlambda,unslice,valSwap,wrapperFunc")
  -enableAll
    	identical to -enable with all checkers listed. If true, -enable is ignored
  -exitCode int
    	exit code to be used when lint issues are found (default 1)
  -go string
    	select the Go version to target. Leave as string for the latest
  -memprofile string
    	write memory profile to the specified file
  -shorterErrLocation
    	whether to replace error location prefix with $GOROOT and $GOPATH (default true)
  -v	whether to print output useful during linter debugging
parse args: flag: help requested`)
}

func registerIgnoredCheckerParams(fs *flag.FlagSet) {
	fs.Bool("@captLocal.paramsOnly", true, "")
	fs.Int("@commentedOutCode.minLength", 15, "")
	fs.Bool("@elseif.skipBalanced", true, "")
	fs.Int("@hugeParam.sizeThreshold", 80, "")
	fs.Int("@ifElseChain.minThreshold", 2, "")
	fs.Int("@nestingReduce.bodyWidth", 5, "")
	fs.Int("@rangeExprCopy.sizeThreshold", 512, "")
	fs.Bool("@rangeExprCopy.skipTestFuncs", true, "")
	fs.Int("@rangeValCopy.sizeThreshold", 128, "")
	fs.Bool("@rangeValCopy.skipTestFuncs", true, "")
	fs.String("@ruleguard.debug", "", "")
	fs.String("@ruleguard.disable", "", "")
	fs.String("@ruleguard.enable", "<all>", "")
	fs.String("@ruleguard.failOn", "", "")
	fs.Bool("@ruleguard.failOnError", false, "")
	fs.String("@ruleguard.rules", "", "")
	fs.Int("@tooManyResultsChecker.maxResults", 5, "")
	fs.Bool("@truncateCmp.skipArchDependent", true, "")
	fs.Bool("@underef.skipRecvDeref", true, "")
	fs.Bool("@unnamedResult.checkExported", false, "")
	fs.String("cpuprofile", "", "")
	fs.String("memprofile", "", "")
	fs.Bool("shorterErrLocation", true, "")
}

func enabledSet(enable, disable string, enableAll bool) map[string]bool {
	result := make(map[string]bool)
	if enableAll {
		for _, c := range checkers {
			result[c.name] = true
		}
	} else {
		for _, name := range splitCSV(enable) {
			if strings.HasPrefix(name, "#") {
				for _, c := range checkers {
					if strings.Contains(c.tags, strings.TrimPrefix(name, "#")) {
						result[c.name] = true
					}
				}
			} else {
				result[name] = true
			}
		}
	}
	for _, name := range splitCSV(disable) {
		if strings.HasPrefix(name, "#") {
			tag := strings.TrimPrefix(name, "#")
			for _, c := range checkers {
				if strings.Contains(c.tags, tag) {
					delete(result, c.name)
				}
			}
		} else {
			delete(result, name)
		}
	}
	return result
}

func splitCSV(s string) []string {
	var out []string
	for _, part := range strings.Split(s, ",") {
		part = strings.TrimSpace(part)
		if part != "" {
			out = append(out, part)
		}
	}
	return out
}

func expandTarget(target string) ([]string, error) {
	if strings.HasSuffix(target, "/...") {
		root := strings.TrimSuffix(target, "/...")
		if root == "" {
			root = "."
		}
		return walkGoFiles(root, target)
	}
	info, err := os.Stat(target)
	if err == nil && !info.IsDir() {
		return []string{target}, nil
	}
	if err == nil && info.IsDir() {
		return walkGoFiles(target, target)
	}
	return nil, fmt.Errorf("can't load package: package %s is not in std", target)
}

func walkGoFiles(root, displayTarget string) ([]string, error) {
	var files []string
	err := filepath.WalkDir(root, func(path string, d os.DirEntry, err error) error {
		if err != nil {
			return err
		}
		if d.IsDir() {
			if strings.HasPrefix(d.Name(), ".") && path != root {
				return filepath.SkipDir
			}
			return nil
		}
		if strings.HasSuffix(path, ".go") && !strings.HasSuffix(path, "_test.go") {
			files = append(files, displayPath(path, root, displayTarget))
		}
		return nil
	})
	return files, err
}

func displayPath(path, root, displayTarget string) string {
	if !strings.HasSuffix(displayTarget, "/...") {
		return path
	}
	if strings.HasPrefix(displayTarget, "./") {
		rel, err := filepath.Rel(root, path)
		if err == nil {
			return "./" + filepath.ToSlash(rel)
		}
	}
	return path
}

func lintFile(path string, enabled map[string]bool) []diagnostic {
	fset := token.NewFileSet()
	file, err := parser.ParseFile(fset, path, nil, parser.ParseComments)
	if err != nil {
		return []diagnostic{{file: path, line: 1, col: 1, name: "parse", msg: err.Error()}}
	}
	var diags []diagnostic
	add := func(pos token.Pos, name, msg string) {
		p := fset.Position(pos)
		diags = append(diags, diagnostic{file: path, line: p.Line, col: p.Column, name: name, msg: msg})
	}
	ast.Inspect(file, func(n ast.Node) bool {
		switch x := n.(type) {
		case *ast.AssignStmt:
			if enabled["assignOp"] {
				for i := range x.Lhs {
					if i < len(x.Rhs) {
						if msg, ok := assignOpMessage(x.Lhs[i], x.Rhs[i]); ok {
							add(x.Pos(), "assignOp", msg)
						}
					}
				}
			}
		case *ast.BinaryExpr:
			if enabled["dupSubExpr"] && (x.Op == token.LOR || x.Op == token.LAND) && exprString(x.X) == exprString(x.Y) {
				add(x.Pos(), "dupSubExpr", fmt.Sprintf("suspicious identical LHS and RHS for `%s` operator", x.Op.String()))
			}
			if enabled["sloppyLen"] {
				if msg, ok := sloppyLenMessage(x); ok {
					add(x.Pos(), "sloppyLen", msg)
				}
			}
		case *ast.SwitchStmt:
			if enabled["singleCaseSwitch"] && len(x.Body.List) == 1 {
				add(x.Pos(), "singleCaseSwitch", "should rewrite switch statement to if statement")
			}
			if enabled["switchTrue"] {
				if id, ok := x.Tag.(*ast.Ident); ok && id.Name == "true" {
					add(x.Pos(), "switchTrue", "replace 'switch true {}' with 'switch {}'")
				}
			}
		case *ast.SliceExpr:
			if enabled["unslice"] && x.Low == nil && x.High == nil && x.Max == nil {
				add(x.Pos(), "unslice", fmt.Sprintf("could simplify %s to %s", exprString(x), exprString(x.X)))
			}
		}
		return true
	})
	return diags
}

func assignOpMessage(lhs ast.Expr, rhs ast.Expr) (string, bool) {
	bin, ok := rhs.(*ast.BinaryExpr)
	if !ok || !isAssignOp(bin.Op) {
		return "", false
	}
	left := exprString(lhs)
	if exprString(bin.X) != left {
		return "", false
	}
	return fmt.Sprintf("replace `%s = %s` with `%s %s= %s`", left, exprString(rhs), left, bin.Op.String(), exprString(bin.Y)), true
}

func isAssignOp(op token.Token) bool {
	switch op {
	case token.ADD, token.SUB, token.MUL, token.QUO, token.REM, token.AND, token.OR, token.XOR, token.SHL, token.SHR, token.AND_NOT:
		return true
	default:
		return false
	}
}

func checkerOrder(name string) int {
	for i, c := range checkers {
		if c.name == name {
			return i
		}
	}
	return len(checkers) + 1
}

func sloppyLenMessage(x *ast.BinaryExpr) (string, bool) {
	if x.Op != token.LEQ && x.Op != token.GEQ {
		return "", false
	}
	if call, ok := x.X.(*ast.CallExpr); ok && isLenCall(call) && isZero(x.Y) {
		arg := exprString(call.Args[0])
		if x.Op == token.LEQ {
			return fmt.Sprintf("len(%s) <= 0 can be len(%s) == 0", arg, arg), true
		}
	}
	if call, ok := x.Y.(*ast.CallExpr); ok && isLenCall(call) && isZero(x.X) && x.Op == token.GEQ {
		arg := exprString(call.Args[0])
		return fmt.Sprintf("0 >= len(%s) can be len(%s) == 0", arg, arg), true
	}
	return "", false
}

func isLenCall(c *ast.CallExpr) bool {
	id, ok := c.Fun.(*ast.Ident)
	return ok && id.Name == "len" && len(c.Args) == 1
}

func isZero(e ast.Expr) bool {
	lit, ok := e.(*ast.BasicLit)
	return ok && lit.Value == "0"
}

func exprString(e ast.Expr) string {
	var b strings.Builder
	_ = formatNode(&b, e)
	return b.String()
}

func formatNode(b *strings.Builder, n any) error {
	return format.Node(b, token.NewFileSet(), n)
}

type checkerInfo struct {
	name string
	tags string
}

var checkers = []checkerInfo{
	{"appendAssign", "diagnostic"}, {"appendCombine", "performance"}, {"argOrder", "diagnostic"},
	{"assignOp", "style"}, {"badCall", "diagnostic"}, {"badCond", "diagnostic"},
	{"badLock", "diagnostic experimental"}, {"badRegexp", "diagnostic experimental"},
	{"badSorting", "diagnostic experimental"}, {"badSyncOnceFunc", "diagnostic experimental"},
	{"boolExprSimplify", "style experimental"}, {"builtinShadow", "style opinionated"},
	{"builtinShadowDecl", "diagnostic experimental"}, {"captLocal", "style"},
	{"caseOrder", "diagnostic"}, {"codegenComment", "diagnostic"}, {"commentFormatting", "style"},
	{"commentedOutCode", "diagnostic experimental"}, {"commentedOutImport", "style experimental"},
	{"defaultCaseOrder", "style"}, {"deferInLoop", "diagnostic experimental"},
	{"deferUnlambda", "style experimental"}, {"deprecatedComment", "diagnostic"},
	{"docStub", "style experimental"}, {"dupArg", "diagnostic"}, {"dupBranchBody", "diagnostic"},
	{"dupCase", "diagnostic"}, {"dupImport", "style experimental"},
	{"dupOption", "diagnostic experimental"}, {"dupSubExpr", "diagnostic"},
	{"dynamicFmtString", "diagnostic experimental"}, {"elseif", "style"},
	{"emptyDecl", "diagnostic experimental"}, {"emptyFallthrough", "style experimental"},
	{"emptyStringTest", "style experimental"}, {"equalFold", "performance experimental"},
	{"evalOrder", "diagnostic experimental"}, {"exitAfterDefer", "diagnostic"},
	{"exposedSyncMutex", "style experimental"}, {"externalErrorReassign", "diagnostic experimental"},
	{"filepathJoin", "diagnostic experimental"}, {"flagDeref", "diagnostic"}, {"flagName", "diagnostic"},
	{"hexLiteral", "style experimental"}, {"httpNoBody", "style experimental"},
	{"hugeParam", "performance"}, {"ifElseChain", "style"}, {"importShadow", "style opinionated"},
	{"indexAlloc", "performance"}, {"initClause", "style opinionated experimental"},
	{"mapKey", "diagnostic"}, {"methodExprCall", "style experimental"},
	{"nestingReduce", "style opinionated experimental"}, {"newDeref", "style"},
	{"nilValReturn", "diagnostic experimental"}, {"octalLiteral", "style experimental opinionated"},
	{"offBy1", "diagnostic"}, {"paramTypeCombine", "style opinionated"},
	{"preferDecodeRune", "performance experimental"}, {"preferFilepathJoin", "style experimental"},
	{"preferFprint", "performance experimental"}, {"preferStringWriter", "performance experimental"},
	{"preferWriteByte", "performance experimental opinionated"}, {"ptrToRefParam", "style opinionated experimental"},
	{"rangeAppendAll", "diagnostic experimental"}, {"rangeExprCopy", "performance"},
	{"rangeValCopy", "performance"}, {"redundantSprint", "style experimental"},
	{"regexpMust", "style"}, {"regexpPattern", "diagnostic experimental"},
	{"regexpSimplify", "style experimental opinionated"}, {"returnAfterHttpError", "diagnostic experimental"},
	{"ruleguard", "style experimental"}, {"singleCaseSwitch", "style"},
	{"sliceClear", "performance experimental"}, {"sloppyLen", "diagnostic"},
	{"sloppyReassign", "diagnostic experimental"}, {"sloppyTypeAssert", "diagnostic"},
	{"sortSlice", "diagnostic experimental"}, {"sprintfQuotedString", "diagnostic experimental"},
	{"sqlQuery", "diagnostic experimental"}, {"stringConcatSimplify", "style experimental"},
	{"stringXbytes", "performance"}, {"stringsCompare", "style experimental"},
	{"switchTrue", "style"}, {"syncMapLoadAndDelete", "diagnostic experimental"},
	{"timeExprSimplify", "style experimental"}, {"todoCommentWithoutDetail", "style opinionated experimental"},
	{"tooManyResultsChecker", "style opinionated experimental"}, {"truncateCmp", "diagnostic experimental"},
	{"typeAssertChain", "style experimental"}, {"typeDefFirst", "style experimental"},
	{"typeSwitchVar", "style"}, {"typeUnparen", "style opinionated"},
	{"uncheckedInlineErr", "diagnostic experimental"}, {"underef", "style"},
	{"unlabelStmt", "style experimental"}, {"unlambda", "style"},
	{"unnamedResult", "style opinionated experimental"}, {"unnecessaryBlock", "style opinionated experimental"},
	{"unnecessaryDefer", "diagnostic experimental"}, {"unslice", "style"},
	{"valSwap", "style"}, {"weakCond", "diagnostic experimental"},
	{"whyNoLint", "style experimental"}, {"wrapperFunc", "style"},
	{"yodaStyleExpr", "style experimental"}, {"zeroByteRepeat", "performance"},
}

func runDoc(args []string) {
	if len(args) > 0 && args[0] == "-help" {
		fmt.Println("Usage of go-critic:")
		fmt.Println("flag: help requested")
		return
	}
	if len(args) == 0 {
		for _, c := range checkers {
			fmt.Printf("%s [%s]\n", c.name, c.tags)
		}
		return
	}
	c, ok := findChecker(args[0])
	if !ok {
		fmt.Printf("checker with name %q not found\n", args[0])
		os.Exit(1)
	}
	fmt.Printf("%s checker documentation\n", c.name)
	fmt.Println("URL: https://github.com/go-critic/go-critic/checkers")
	fmt.Printf("Tags: [%s]\n\n", c.tags)
	switch c.name {
	case "sloppyLen":
		fmt.Println("Detects usage of `len` when result is obvious or doesn't make sense.")
		fmt.Println()
		fmt.Println("Non-compliant code:")
		fmt.Println("len(arr) <= 0")
		fmt.Println()
		fmt.Println("Compliant code:")
		fmt.Println("len(arr) == 0")
	case "dupSubExpr":
		fmt.Println("Detects suspicious duplicated sub-expressions.")
	default:
		fmt.Printf("%s checker.\n", c.name)
	}
}

func findChecker(name string) (checkerInfo, bool) {
	for _, c := range checkers {
		if c.name == name {
			return c, true
		}
	}
	return checkerInfo{}, false
}

func printHelp() {
	fmt.Println(`Usage:

    go-critic <command> [arguments...]

The commands are:

    check             run linter over specified targets
    doc               get installed checkers documentation
    help              shows help message
    version           shows version of the application

Version: v0.0.0-SNAPSHOT`)
}
