#!/usr/bin/env python3
import os
import subprocess
import tempfile
import textwrap

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
EXE = os.path.join(ROOT, "executable")


def run_cmd(args, cwd=ROOT):
    return subprocess.run(
        [EXE] + args,
        cwd=cwd,
        text=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
    )


def test_version():
    p = run_cmd(["version"])
    assert p.returncode == 0
    assert p.stdout == "go-critic version: v0.0.0-SNAPSHOT\n"


def test_doc_lists_known_checkers_and_unknown_fails():
    p = run_cmd(["doc"])
    assert p.returncode == 0
    assert "appendAssign [diagnostic]\n" in p.stdout
    assert "sloppyLen [diagnostic]\n" in p.stdout
    assert "wrapperFunc [style]\n" in p.stdout

    missing = run_cmd(["doc", "noSuch"])
    assert missing.returncode == 1
    assert missing.stdout == 'checker with name "noSuch" not found\n'


def test_check_help_matches_observed_shape():
    p = run_cmd(["check", "-help"])
    assert p.returncode == 0
    assert p.stdout.startswith("Usage of go-critic:\n  -@captLocal.paramsOnly\n")
    assert "  -enable string\n" in p.stdout
    assert p.stdout.endswith("parse args: flag: help requested\n")


def test_check_reports_sloppy_len_for_file_target():
    with tempfile.TemporaryDirectory() as td:
        path = os.path.join(td, "main.go")
        with open(path, "w", encoding="utf-8") as f:
            f.write(textwrap.dedent(
                """\
                package main

                func f(xs []int) {
                    if len(xs) <= 0 {
                    }
                }
                """
            ))
        p = run_cmd(["check", "-enable=sloppyLen", path])
    assert p.returncode == 1
    assert p.stdout == f"{path}:4:8: sloppyLen: len(xs) <= 0 can be len(xs) == 0\n"


def test_check_reports_boolean_and_switch_diagnostics():
    with tempfile.TemporaryDirectory() as td:
        path = os.path.join(td, "main.go")
        with open(path, "w", encoding="utf-8") as f:
            f.write(textwrap.dedent(
                """\
                package main

                func f(xs []int, a bool) {
                    if a || a {
                    }
                    switch true {
                    case a:
                    }
                }
                """
            ))
        p = run_cmd(["check", "-enable=dupSubExpr,singleCaseSwitch,switchTrue", path])
    assert p.returncode == 1
    assert p.stdout == (
        f"{path}:4:8: dupSubExpr: suspicious identical LHS and RHS for `||` operator\n"
        f"{path}:6:5: singleCaseSwitch: should rewrite switch statement to if statement\n"
        f"{path}:6:5: switchTrue: replace 'switch true {{}}' with 'switch {{}}'\n"
    )


def test_check_expands_recursive_directory_target():
    with tempfile.TemporaryDirectory() as td:
        nested = os.path.join(td, "pkg")
        os.mkdir(nested)
        path = os.path.join(nested, "main.go")
        with open(path, "w", encoding="utf-8") as f:
            f.write("package pkg\n\nfunc f(xs []int) { if len(xs) <= 0 {} }\n")
        p = run_cmd(["check", "-enable=sloppyLen", "-exitCode=7", "./..."], cwd=td)
    assert p.returncode == 7
    assert p.stdout == "./pkg/main.go:3:23: sloppyLen: len(xs) <= 0 can be len(xs) == 0\n"


def test_check_reports_assign_op_and_unslice():
    with tempfile.TemporaryDirectory() as td:
        path = os.path.join(td, "main.go")
        with open(path, "w", encoding="utf-8") as f:
            f.write(textwrap.dedent(
                """\
                package main

                func f(xs []int, x int) {
                    x = x + 1
                    _ = xs[:]
                }
                """
            ))
        p = run_cmd(["check", "-enable=assignOp,unslice", path])
    assert p.returncode == 1
    assert p.stdout == (
        f"{path}:4:5: assignOp: replace `x = x + 1` with `x += 1`\n"
        f"{path}:5:9: unslice: could simplify xs[:] to xs\n"
    )


if __name__ == "__main__":
    tests = [
        test_version,
        test_doc_lists_known_checkers_and_unknown_fails,
        test_check_help_matches_observed_shape,
        test_check_reports_sloppy_len_for_file_target,
        test_check_reports_boolean_and_switch_diagnostics,
        test_check_expands_recursive_directory_target,
        test_check_reports_assign_op_and_unslice,
    ]
    for test in tests:
        test()
    print(f"{len(tests)} tests passed")
