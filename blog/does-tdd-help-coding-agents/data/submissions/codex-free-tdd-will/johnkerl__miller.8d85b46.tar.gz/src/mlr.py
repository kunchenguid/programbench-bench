#!/usr/bin/env python3
import sys
import csv
import io
import re
import math
import os
import json


HELP = """Usage: mlr [flags] {verb} [verb-dependent options ...] {zero or more file names}

If zero file names are provided, standard input is read, e.g.
  mlr --csv sort -f shape example.csv

Output of one verb may be chained as input to another using "then", e.g.
  mlr --csv stats1 -a min,mean,max -f quantity then sort -f color example.csv

Please see 'mlr help topics' for more information.
Please also see https://miller.readthedocs.io
"""


TOPICS = """Type 'mlr help {topic}' for any of the following:
Essentials:
  mlr help topics
  mlr help basic-examples
  mlr help file-formats
Flags:
  mlr help flags
  mlr help flag
  mlr help list-separator-aliases
  mlr help list-separator-regex-aliases
  mlr help comments-in-data-flags
  mlr help compressed-data-flags
  mlr help csv/tsv-only-flags
  mlr help dkvp-only-flags
  mlr help file-format-flags
Verbs:
  mlr help list-verbs
  mlr help usage-verbs
  mlr help verb
Functions:
  mlr help list-functions
  mlr help usage-functions
Keywords:
  mlr help list-keywords
  mlr help usage-keywords
Other:
  mlr help auxents
Shorthands:
  mlr -g = mlr help flags
  mlr -l = mlr help list-verbs
  mlr -L = mlr help usage-verbs
  mlr -f = mlr help list-functions
  mlr -F = mlr help usage-functions
  mlr -k = mlr help list-keywords
  mlr -K = mlr help usage-keywords
"""


VERBS = """altkv
bar
bootstrap
case
cat
check
clean-whitespace
count-distinct
count
cut
filter
head
label
nothing
put
rename
sort
stats1
tail
top
uniq
"""


def parse_dkvp(text):
    records = []
    for line in text.splitlines():
        if line == "":
            continue
        rec = []
        for i, part in enumerate(line.split(","), 1):
            if "=" in part:
                k, v = part.split("=", 1)
            else:
                k, v = str(i), part
            rec.append((k, v))
        records.append(rec)
    return records


def parse_csv_text(text, sep=",", implicit=False):
    rows = list(csv.reader(io.StringIO(text), delimiter=sep))
    if not rows:
        return []
    if implicit:
        headers = [str(i) for i in range(1, len(rows[0]) + 1)]
        data = rows
    else:
        headers = rows[0]
        data = rows[1:]
    return [[(headers[i] if i < len(headers) else str(i + 1), row[i]) for i in range(len(row))] for row in data]


def object_to_record(obj):
    if isinstance(obj, dict):
        return [(str(k), format_value(v)) for k, v in obj.items()]
    return [("value", format_value(obj))]


def parse_json_text(text, lines=False):
    if not text.strip():
        return []
    if lines:
        return [object_to_record(json.loads(line)) for line in text.splitlines() if line.strip()]
    obj = json.loads(text)
    if isinstance(obj, list):
        return [object_to_record(x) for x in obj]
    return [object_to_record(obj)]


def keys_in_order(records):
    out = []
    seen = set()
    for rec in records:
        for k, _ in rec:
            if k not in seen:
                seen.add(k)
                out.append(k)
    return out


def write_records(records, fmt):
    if fmt == "pprint":
        keys = keys_in_order(records)
        if not keys:
            return
        widths = {k: len(k) for k in keys}
        for rec in records:
            d = dict(rec)
            for k in keys:
                widths[k] = max(widths[k], len(d.get(k, "")))
        print(" ".join(k.ljust(widths[k]) for k in keys).rstrip())
        for rec in records:
            d = dict(rec)
            print(" ".join(d.get(k, "").ljust(widths[k]) for k in keys).rstrip())
    elif fmt == "jsonl":
        for rec in records:
            print(json.dumps({k: infer_value(v) for k, v in rec}))
    elif fmt == "json":
        objs = [{k: infer_value(v) for k, v in rec} for rec in records]
        if not objs:
            print("[]")
        else:
            print("[")
            for idx, obj in enumerate(objs):
                sys.stdout.write(json.dumps(obj, indent=2))
                sys.stdout.write(",\n" if idx + 1 < len(objs) else "\n")
            print("]")
    elif fmt == "csv" or fmt == "tsv":
        sep = "," if fmt == "csv" else "\t"
        output = io.StringIO()
        writer = csv.writer(output, delimiter=sep, lineterminator="\n")
        keys = keys_in_order(records)
        if keys:
            writer.writerow(keys)
        for rec in records:
            d = dict(rec)
            writer.writerow([d.get(k, "") for k in keys])
        sys.stdout.write(output.getvalue())
    else:
        for rec in records:
            print(",".join(f"{k}={v}" for k, v in rec))


def read_input(files, ifmt, implicit=False):
    if files:
        text = "".join(open(name, newline="").read() for name in files)
    else:
        text = sys.stdin.read()
    if ifmt == "csv":
        return parse_csv_text(text, ",", implicit)
    if ifmt == "tsv":
        return parse_csv_text(text, "\t", implicit)
    if ifmt == "json":
        return parse_json_text(text, False)
    if ifmt == "jsonl":
        return parse_json_text(text, True)
    return parse_dkvp(text)


def split_pipeline(args):
    parts = [[]]
    for arg in args:
        if arg == "then":
            parts.append([])
        else:
            parts[-1].append(arg)
    return parts


def apply_cat(records, args):
    name = None
    i = 0
    while i < len(args):
        if args[i] == "-n":
            name = "n"
        elif args[i] == "-N" and i + 1 < len(args):
            name = args[i + 1]
            i += 1
        i += 1
    if name:
        return [[(name, str(idx))] + rec for idx, rec in enumerate(records, 1)]
    return records


def parse_field_list(value):
    return [x for x in value.split(",") if x]


def apply_cut(records, args):
    fields = []
    complement = False
    ordered = False
    i = 0
    while i < len(args):
        if args[i] == "-f" and i + 1 < len(args):
            fields.extend(parse_field_list(args[i + 1]))
            i += 1
        elif args[i] in ("-x", "--complement"):
            complement = True
        elif args[i] == "-o":
            ordered = True
        i += 1
    fieldset = set(fields)
    out = []
    for rec in records:
        if complement:
            out.append([(k, v) for k, v in rec if k not in fieldset])
        elif ordered:
            d = dict(rec)
            out.append([(k, d[k]) for k in fields if k in d])
        else:
            out.append([(k, v) for k, v in rec if k in fieldset])
    return out


def apply_sort(records, args):
    specs = []
    i = 0
    while i < len(args):
        flag = args[i]
        if flag in ("-f", "-r", "-n", "-nf", "-nr") and i + 1 < len(args):
            for field in parse_field_list(args[i + 1]):
                specs.append((field, flag))
            i += 1
        i += 1
    if not specs:
        return records
    indexed = list(enumerate(records))
    for field, flag in reversed(specs):
        reverse = flag in ("-r", "-nr")
        numeric = flag in ("-n", "-nf", "-nr")

        def key(item):
            idx, rec = item
            d = dict(rec)
            if field not in d:
                return (1, 0)
            v = d[field]
            if numeric:
                try:
                    return (0, float(v))
                except Exception:
                    return (0, float("inf"))
            return (0, v)

        indexed.sort(key=key, reverse=reverse)
    return [rec for _, rec in indexed]


def infer_value(s):
    if s is None:
        return ""
    if isinstance(s, (int, float, bool)):
        return s
    if s == "":
        return ""
    if s.lower() == "true":
        return True
    if s.lower() == "false":
        return False
    try:
        if re.fullmatch(r"[-+]?\d+", s):
            return int(s)
        if re.fullmatch(r"[-+]?(\d+\.\d*|\.\d+)([eE][-+]?\d+)?|[-+]?\d+[eE][-+]?\d+", s):
            return float(s)
    except Exception:
        pass
    return s


def format_value(v):
    if isinstance(v, bool):
        return "true" if v else "false"
    if isinstance(v, float) and v.is_integer():
        return str(int(v))
    return str(v)


def env_for_record(rec):
    env = {k: infer_value(v) for k, v in rec}
    env.update({
        "sqrt": math.sqrt,
        "log10": math.log10,
        "abs": abs,
        "min": min,
        "max": max,
        "int": int,
        "float": float,
        "str": str,
    })
    return env


def translate_expr(expr):
    expr = expr.strip()
    expr = re.sub(r"\$([A-Za-z_][A-Za-z0-9_]*)", r"\1", expr)
    expr = expr.replace("&&", " and ").replace("||", " or ")
    expr = re.sub(r"(?<![=!<>])!(?!=)", " not ", expr)
    return expr


def eval_expr(expr, rec):
    env = env_for_record(rec)
    try:
        return eval(translate_expr(expr), {"__builtins__": {}}, env)
    except Exception:
        return False


def expression_arg(args):
    exprs = []
    i = 0
    while i < len(args):
        if args[i] == "-e" and i + 1 < len(args):
            exprs.append(args[i + 1])
            i += 1
        elif not args[i].startswith("-"):
            exprs.append(args[i])
        i += 1
    return ";".join(exprs)


def apply_filter(records, args):
    invert = "-x" in args
    expr = expression_arg(args)
    out = []
    for rec in records:
        keep = bool(eval_expr(expr, rec))
        if invert:
            keep = not keep
        if keep:
            out.append(rec)
    return out


def apply_put(records, args):
    expr = expression_arg(args)
    statements = [s.strip() for s in expr.split(";") if s.strip()]
    out = []
    for rec in records:
        new = list(rec)
        env = env_for_record(new)
        for stmt in statements:
            m = re.match(r"^\$?([A-Za-z_][A-Za-z0-9_]*)\s*(\+=|-=|\*=|/=|=)\s*(.+)$", stmt)
            if not m:
                continue
            name, op, rhs = m.groups()
            val = eval(translate_expr(rhs), {"__builtins__": {}}, env)
            if op != "=":
                old = env.get(name, 0)
                if op == "+=":
                    val = old + val
                elif op == "-=":
                    val = old - val
                elif op == "*=":
                    val = old * val
                elif op == "/=":
                    val = old / val
            env[name] = val
            replaced = False
            for idx, (k, _) in enumerate(new):
                if k == name:
                    new[idx] = (k, format_value(val))
                    replaced = True
                    break
            if not replaced:
                new.append((name, format_value(val)))
        out.append(new)
    return out


def get_option(args, name, default=None):
    for i, arg in enumerate(args):
        if arg == name and i + 1 < len(args):
            return args[i + 1]
    return default


def apply_count(records, args):
    groups = parse_field_list(get_option(args, "-g", ""))
    out_name = get_option(args, "-o", "count")
    if not groups:
        return [[(out_name, str(len(records)))]]
    counts = {}
    order = []
    for rec in records:
        d = dict(rec)
        key = tuple(d.get(g, "") for g in groups)
        if key not in counts:
            counts[key] = 0
            order.append(key)
        counts[key] += 1
    return [[*zip(groups, key), (out_name, str(counts[key]))] for key in order]


def apply_head(records, args):
    n = int(get_option(args, "-n", "10"))
    groups = parse_field_list(get_option(args, "-g", ""))
    if not groups:
        return records[:n]
    counts = {}
    out = []
    for rec in records:
        d = dict(rec)
        key = tuple(d.get(g, "") for g in groups)
        counts[key] = counts.get(key, 0) + 1
        if counts[key] <= n:
            out.append(rec)
    return out


def apply_tail(records, args):
    n = int(get_option(args, "-n", "10"))
    groups = parse_field_list(get_option(args, "-g", ""))
    if not groups:
        return records[-n:] if n else []
    buckets = {}
    order = []
    for rec in records:
        d = dict(rec)
        key = tuple(d.get(g, "") for g in groups)
        if key not in buckets:
            buckets[key] = []
            order.append(key)
        buckets[key].append(rec)
    out = []
    for key in order:
        out.extend(buckets[key][-n:])
    return out


def apply_rename(records, args):
    if not args:
        return records
    pairs = parse_field_list(args[-1])
    mapping = dict(zip(pairs[0::2], pairs[1::2]))
    return [[(mapping.get(k, k), v) for k, v in rec] for rec in records]


def apply_nothing(records, args):
    return []


def apply_uniq(records, args):
    seen = set()
    out = []
    for rec in records:
        key = tuple(rec)
        if key not in seen:
            seen.add(key)
            out.append(rec)
    return out


def apply_stats1(records, args):
    accs = parse_field_list(get_option(args, "-a", "count"))
    fields = parse_field_list(get_option(args, "-f", ""))
    groups = parse_field_list(get_option(args, "-g", ""))
    if not fields and records:
        fields = [k for k, _ in records[0] if k not in groups]
    buckets = {}
    order = []
    for rec in records:
        d = dict(rec)
        gkey = tuple(d.get(g, "") for g in groups)
        if gkey not in buckets:
            buckets[gkey] = {f: [] for f in fields}
            order.append(gkey)
        for f in fields:
            if f in d:
                buckets[gkey][f].append(d[f])
    out = []
    for gkey in order:
        rec_out = list(zip(groups, gkey))
        for f in fields:
            values = buckets[gkey][f]
            nums = [float(v) for v in values if isinstance(infer_value(v), (int, float))]
            for acc in accs:
                name = "median" if acc == "p50" else acc
                val = ""
                if name == "count":
                    val = len(values)
                elif name == "sum":
                    val = sum(nums)
                elif name == "mean":
                    val = sum(nums) / len(nums) if nums else ""
                elif name == "min":
                    val = min(nums) if nums else (min(values) if values else "")
                elif name == "max":
                    val = max(nums) if nums else (max(values) if values else "")
                elif name == "distinct_count":
                    val = len(set(values))
                else:
                    continue
                rec_out.append((f"{f}_{acc}", format_value(val)))
        out.append(rec_out)
    return out


def apply_label(records, args):
    names = parse_field_list(args[-1]) if args else []
    out = []
    for rec in records:
        new = []
        for i, (_, v) in enumerate(rec):
            new.append((names[i] if i < len(names) else str(i + 1), v))
        out.append(new)
    return out


def apply_grep(records, args):
    invert = "-v" in args
    pattern = ""
    fields = None
    i = 0
    while i < len(args):
        if args[i] == "-f" and i + 1 < len(args):
            fields = set(parse_field_list(args[i + 1]))
            i += 1
        elif not args[i].startswith("-"):
            pattern = args[i]
        i += 1
    try:
        rx = re.compile(pattern)
    except Exception:
        rx = re.compile(re.escape(pattern))
    out = []
    for rec in records:
        vals = [v for k, v in rec if fields is None or k in fields]
        matched = any(rx.search(v) for v in vals)
        if matched != invert:
            out.append(rec)
    return out


def apply_top(records, args):
    n = int(get_option(args, "-n", "10"))
    field = get_option(args, "-f", None)
    if not field:
        return records[:n]
    return apply_sort(records, ["-nr", field])[:n]


def apply_verb(records, verb_args):
    if not verb_args:
        return records
    verb = verb_args[0]
    args = verb_args[1:]
    if verb == "cat":
        return apply_cat(records, args)
    if verb == "cut":
        return apply_cut(records, args)
    if verb == "sort":
        return apply_sort(records, args)
    if verb == "filter":
        return apply_filter(records, args)
    if verb == "put":
        return apply_put(records, args)
    if verb == "count":
        return apply_count(records, args)
    if verb == "head":
        return apply_head(records, args)
    if verb == "tail":
        return apply_tail(records, args)
    if verb == "rename":
        return apply_rename(records, args)
    if verb == "stats1":
        return apply_stats1(records, args)
    if verb == "nothing":
        return apply_nothing(records, args)
    if verb == "uniq":
        return apply_uniq(records, args)
    if verb == "label":
        return apply_label(records, args)
    if verb == "grep":
        return apply_grep(records, args)
    if verb == "top":
        return apply_top(records, args)
    raise ValueError(verb)


def peel_files_from_first_verb(verb_args):
    if not verb_args:
        return [], verb_args
    value_options = {
        "cat": {"-N", "-g"},
        "cut": {"-f"},
        "sort": {"-f", "-r", "-c", "-cr", "-n", "-nf", "-nr", "-t", "-tr", "-rt"},
        "filter": {"-e", "-f", "-s"},
        "put": {"-e", "-f", "-s"},
        "count": {"-g", "-o", "-n"},
        "head": {"-g", "-n"},
        "tail": {"-g", "-n"},
        "rename": set(),
        "stats1": {"-a", "-f", "-g", "--fr", "--fx", "--gr", "--gx", "--grfx"},
    }
    verb = verb_args[0]
    opts = value_options.get(verb, set())
    kept = [verb]
    files = []
    i = 1
    while i < len(verb_args):
        arg = verb_args[i]
        if arg in opts and i + 1 < len(verb_args):
            kept.extend([arg, verb_args[i + 1]])
            i += 2
        elif arg.startswith("-"):
            kept.append(arg)
            i += 1
        elif os.path.exists(arg):
            files.append(arg)
            i += 1
        else:
            kept.append(arg)
            i += 1
    return files, kept


def parse_global_flags(argv):
    ifmt = "dkvp"
    ofmt = "dkvp"
    implicit = False
    files_from = []
    out = []
    known_verbs = {"cat", "cut", "sort", "filter", "put", "count", "head", "tail", "rename", "stats1", "uniq", "nothing", "label", "grep", "top"}
    i = 0
    while i < len(argv):
        arg = argv[i]
        if arg in known_verbs or arg == "then":
            out.extend(argv[i:])
            break
        if arg in ("--csv", "-c", "--c2c"):
            ifmt = ofmt = "csv"
        elif arg in ("--tsv", "-t", "--t2t"):
            ifmt = ofmt = "tsv"
        elif arg in ("--dkvp", "--d2d"):
            ifmt = ofmt = "dkvp"
        elif arg in ("--json", "-j", "--j2j"):
            ifmt = ofmt = "json"
        elif arg in ("--jsonl", "--l2l"):
            ifmt = ofmt = "jsonl"
        elif arg in ("--icsv",):
            ifmt = "csv"
        elif arg in ("--itsv",):
            ifmt = "tsv"
        elif arg in ("--idkvp",):
            ifmt = "dkvp"
        elif arg in ("--ijson",):
            ifmt = "json"
        elif arg in ("--ijsonl",):
            ifmt = "jsonl"
        elif arg in ("--ocsv",):
            ofmt = "csv"
        elif arg in ("--otsv",):
            ofmt = "tsv"
        elif arg in ("--odkvp",):
            ofmt = "dkvp"
        elif arg in ("--ojson",):
            ofmt = "json"
        elif arg in ("--ojsonl",):
            ofmt = "jsonl"
        elif arg in ("--opprint", "--pprint", "--p2p"):
            ofmt = "pprint"
            if arg in ("--pprint", "--p2p"):
                ifmt = "pprint"
        elif arg in ("--implicit-csv-header", "--headerless-csv-input", "--hi", "-N"):
            implicit = True
        elif arg == "--from" and i + 1 < len(argv):
            files_from.append(argv[i + 1])
            i += 1
        elif arg == "-i" and i + 1 < len(argv):
            ifmt = argv[i + 1]
            i += 1
        elif arg == "-o" and i + 1 < len(argv):
            ofmt = argv[i + 1]
            i += 1
        else:
            out.append(arg)
        i += 1
    return ifmt, ofmt, implicit, files_from, out


def main(argv):
    if not argv or argv[0] in ("--help", "-h"):
        sys.stdout.write(HELP)
        return 0
    if argv[0] == "--version":
        print("mlr 6.16.0")
        return 0
    if argv[:2] == ["help", "topics"]:
        sys.stdout.write(TOPICS)
        return 0
    if argv[:2] == ["help", "list-verbs"]:
        sys.stdout.write(VERBS)
        return 0
    ifmt, ofmt, implicit, files_from, args = parse_global_flags(argv)
    if not args:
        sys.stdout.write(HELP)
        return 0
    pipes = split_pipeline(args)
    files = list(files_from)
    known_verbs = {"cat", "cut", "sort", "filter", "put", "count", "head", "tail", "rename", "stats1", "uniq", "nothing"}
    if not files and pipes:
        found_files, kept = peel_files_from_first_verb(pipes[0])
        if found_files:
            files.extend(found_files)
            pipes[0] = kept
    records = read_input(files, ifmt, implicit)
    try:
        for pipe in pipes:
            records = apply_verb(records, pipe)
    except ValueError as e:
        sys.stderr.write(f"mlr: verb \"{e.args[0]}\" not found.\n")
        return 1
    write_records(records, ofmt)
    return 0


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
