#!/bin/bash
set -e
cp src/mlr.py executable
chmod +x executable
