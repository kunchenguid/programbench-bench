import subprocess
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
EXE = ROOT / 'executable'

def run(args, data=''):
    return subprocess.run([str(EXE), *args], input=data, text=True, capture_output=True)

class MlrBehaviorTest(unittest.TestCase):
    def test_version_and_help(self):
        r = run(['--version'])
        self.assertEqual(r.returncode, 0)
        self.assertEqual(r.stdout, 'mlr 6.16.0\n')
        r = run(['--help'])
        self.assertEqual(r.returncode, 0)
        self.assertTrue(r.stdout.startswith('Usage: mlr [flags] {verb}'))
        self.assertIn("Please see 'mlr help topics'", r.stdout)

    def test_cat_reads_dkvp_and_writes_dkvp_or_csv(self):
        data = 'a=1,b=2\na=3,b=4\n'
        self.assertEqual(run(['cat'], data).stdout, data)
        self.assertEqual(run(['cat', '-N', 'row'], data).stdout, 'row=1,a=1,b=2\nrow=2,a=3,b=4\n')
        self.assertEqual(run(['--ocsv', 'cat'], data).stdout, 'a,b\n1,2\n3,4\n')

    def test_csv_pipeline_sort_and_cut_to_pretty_print(self):
        data = 'shape,color,quantity,rate,index\nsquare,red,5,2,2\ncircle,blue,3,1.5,1\n'
        r = run(['--icsv', '--opprint', 'sort', '-nr', 'index', 'then', 'cut', '-f', 'shape,quantity'], data)
        self.assertEqual(r.returncode, 0)
        self.assertEqual(r.stdout, 'shape  quantity\nsquare 5\ncircle 3\n')

    def test_filter_and_put_simple_expressions(self):
        data = 'a=1,b=2\na=3,b=4\n'
        self.assertEqual(run(['filter', '$a > 1'], data).stdout, 'a=3,b=4\n')
        self.assertEqual(run(['put', '$c=$a+$b;$d=$c*2'], data).stdout, 'a=1,b=2,c=3,d=6\na=3,b=4,c=7,d=14\n')

    def test_count_head_tail_rename_stats(self):
        data = 'a=x,b=2\na=x,b=3\na=y,b=4\n'
        self.assertEqual(run(['count'], data).stdout, 'count=3\n')
        self.assertEqual(run(['count', '-g', 'a'], data).stdout, 'a=x,count=2\na=y,count=1\n')
        self.assertEqual(run(['head', '-n', '2'], data).stdout, 'a=x,b=2\na=x,b=3\n')
        self.assertEqual(run(['tail', '-n', '1'], data).stdout, 'a=y,b=4\n')
        self.assertEqual(run(['rename', 'a,z'], data).stdout, 'z=x,b=2\nz=x,b=3\nz=y,b=4\n')
        self.assertEqual(run(['stats1', '-a', 'sum,mean,min,max,count', '-f', 'b'], data).stdout, 'b_sum=9,b_mean=3,b_min=2,b_max=4,b_count=3\n')

    def test_json_and_jsonl_format_conversion(self):
        data = 'a=1,b=2\na=3,b=4\n'
        self.assertEqual(run(['--ojsonl', 'cat'], data).stdout, '{"a": 1, "b": 2}\n{"a": 3, "b": 4}\n')
        self.assertEqual(run(['--ijsonl', 'cat'], '{"a":1,"b":2}\n').stdout, 'a=1,b=2\n')

if __name__ == '__main__':
    unittest.main()
