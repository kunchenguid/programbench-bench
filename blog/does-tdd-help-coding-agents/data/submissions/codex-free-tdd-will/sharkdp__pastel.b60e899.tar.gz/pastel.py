#!/usr/bin/env python3
import colorsys
import math
import random
import re
import sys


VERSION = "pastel 0.11.0"

NAMES = {
    "black": (0, 0, 0), "silver": (192, 192, 192), "gray": (128, 128, 128),
    "white": (255, 255, 255), "maroon": (128, 0, 0), "red": (255, 0, 0),
    "purple": (128, 0, 128), "fuchsia": (255, 0, 255), "green": (0, 128, 0),
    "lime": (0, 255, 0), "olive": (128, 128, 0), "yellow": (255, 255, 0),
    "navy": (0, 0, 128), "blue": (0, 0, 255), "teal": (0, 128, 128),
    "aqua": (0, 255, 255), "orange": (255, 165, 0), "aliceblue": (240, 248, 255),
    "antiquewhite": (250, 235, 215), "aquamarine": (127, 255, 212),
    "azure": (240, 255, 255), "beige": (245, 245, 220), "bisque": (255, 228, 196),
    "blanchedalmond": (255, 235, 205), "blueviolet": (138, 43, 226),
    "brown": (165, 42, 42), "burlywood": (222, 184, 135), "cadetblue": (95, 158, 160),
    "chartreuse": (127, 255, 0), "chocolate": (210, 105, 30), "coral": (255, 127, 80),
    "cornflowerblue": (100, 149, 237), "cornsilk": (255, 248, 220),
    "crimson": (220, 20, 60), "cyan": (0, 255, 255), "darkblue": (0, 0, 139),
    "darkcyan": (0, 139, 139), "darkgoldenrod": (184, 134, 11),
    "darkgray": (169, 169, 169), "darkgreen": (0, 100, 0), "darkgrey": (169, 169, 169),
    "darkkhaki": (189, 183, 107), "darkmagenta": (139, 0, 139), "darkolivegreen": (85, 107, 47),
    "darkorange": (255, 140, 0), "darkorchid": (153, 50, 204), "darkred": (139, 0, 0),
    "darksalmon": (233, 150, 122), "darkseagreen": (143, 188, 143),
    "darkslateblue": (72, 61, 139), "darkslategray": (47, 79, 79),
    "darkslategrey": (47, 79, 79), "darkturquoise": (0, 206, 209),
    "darkviolet": (148, 0, 211), "deeppink": (255, 20, 147),
    "deepskyblue": (0, 191, 255), "dimgray": (105, 105, 105),
    "dimgrey": (105, 105, 105), "dodgerblue": (30, 144, 255),
    "firebrick": (178, 34, 34), "floralwhite": (255, 250, 240),
    "forestgreen": (34, 139, 34), "gainsboro": (220, 220, 220),
    "ghostwhite": (248, 248, 255), "gold": (255, 215, 0), "goldenrod": (218, 165, 32),
    "greenyellow": (173, 255, 47), "grey": (128, 128, 128), "honeydew": (240, 255, 240),
    "hotpink": (255, 105, 180), "indianred": (205, 92, 92), "indigo": (75, 0, 130),
    "ivory": (255, 255, 240), "khaki": (240, 230, 140), "lavender": (230, 230, 250),
    "lavenderblush": (255, 240, 245), "lawngreen": (124, 252, 0),
    "lemonchiffon": (255, 250, 205), "lightblue": (173, 216, 230),
    "lightcoral": (240, 128, 128), "lightcyan": (224, 255, 255),
    "lightgoldenrodyellow": (250, 250, 210), "lightgray": (211, 211, 211),
    "lightgreen": (144, 238, 144), "lightgrey": (211, 211, 211),
    "lightpink": (255, 182, 193), "lightsalmon": (255, 160, 122),
    "lightseagreen": (32, 178, 170), "lightskyblue": (135, 206, 250),
    "lightslategray": (119, 136, 153), "lightslategrey": (119, 136, 153),
    "lightsteelblue": (176, 196, 222), "lightyellow": (255, 255, 224),
    "limegreen": (50, 205, 50), "linen": (250, 240, 230), "magenta": (255, 0, 255),
    "mediumaquamarine": (102, 205, 170), "mediumblue": (0, 0, 205),
    "mediumorchid": (186, 85, 211), "mediumpurple": (147, 112, 219),
    "mediumseagreen": (60, 179, 113), "mediumslateblue": (123, 104, 238),
    "mediumspringgreen": (0, 250, 154), "mediumturquoise": (72, 209, 204),
    "mediumvioletred": (199, 21, 133), "midnightblue": (25, 25, 112),
    "mintcream": (245, 255, 250), "mistyrose": (255, 228, 225),
    "moccasin": (255, 228, 181), "navajowhite": (255, 222, 173),
    "oldlace": (253, 245, 230), "olivedrab": (107, 142, 35),
    "orangered": (255, 69, 0), "orchid": (218, 112, 214),
    "palegoldenrod": (238, 232, 170), "palegreen": (152, 251, 152),
    "paleturquoise": (175, 238, 238), "palevioletred": (219, 112, 147),
    "papayawhip": (255, 239, 213), "peachpuff": (255, 218, 185),
    "peru": (205, 133, 63), "pink": (255, 192, 203), "plum": (221, 160, 221),
    "powderblue": (176, 224, 230), "rebeccapurple": (102, 51, 153),
    "rosybrown": (188, 143, 143), "royalblue": (65, 105, 225),
    "saddlebrown": (139, 69, 19), "salmon": (250, 128, 114),
    "sandybrown": (244, 164, 96), "seagreen": (46, 139, 87),
    "seashell": (255, 245, 238), "sienna": (160, 82, 45), "skyblue": (135, 206, 235),
    "slateblue": (106, 90, 205), "slategray": (112, 128, 144),
    "slategrey": (112, 128, 144), "snow": (255, 250, 250),
    "springgreen": (0, 255, 127), "steelblue": (70, 130, 180),
    "tan": (210, 180, 140), "thistle": (216, 191, 216), "tomato": (255, 99, 71),
    "turquoise": (64, 224, 208), "violet": (238, 130, 238), "wheat": (245, 222, 179),
    "whitesmoke": (245, 245, 245), "yellowgreen": (154, 205, 50),
}


def clamp(x, lo=0.0, hi=1.0):
    return max(lo, min(hi, x))


def parse_num(s, percent_base=1.0):
    s = s.strip()
    if s.endswith("%"):
        return float(s[:-1]) / 100.0 * percent_base
    return float(s)


def parse_alpha(s):
    return clamp(parse_num(s.strip(), 1.0))


class Color:
    def __init__(self, r, g, b, a=1.0):
        self.r = int(clamp(round(r), 0, 255))
        self.g = int(clamp(round(g), 0, 255))
        self.b = int(clamp(round(b), 0, 255))
        self.a = clamp(float(a))

    def rgb01(self):
        return self.r / 255.0, self.g / 255.0, self.b / 255.0

    def hsl(self):
        h, l, s = colorsys.rgb_to_hls(*self.rgb01())
        deg = int(round((h * 360.0) % 360.0))
        if deg == 360:
            deg = 0
        return deg, s, l

    @staticmethod
    def from_hsl(h, s, l, a=1.0):
        r, g, b = colorsys.hls_to_rgb((h % 360.0) / 360.0, clamp(l), clamp(s))
        return Color(r * 255, g * 255, b * 255, a)

    def luminance(self):
        def f(v):
            v /= 255.0
            return v / 12.92 if v <= 0.04045 else ((v + 0.055) / 1.055) ** 2.4
        return 0.2126 * f(self.r) + 0.7152 * f(self.g) + 0.0722 * f(self.b)

    def brightness(self):
        return (0.299 * self.r + 0.587 * self.g + 0.114 * self.b) / 255.0


def parse_color(text):
    s = text.strip()
    low = s.lower().replace(" ", "")
    if low in NAMES:
        return Color(*NAMES[low])
    if low.startswith("#"):
        low = low[1:]
    if re.fullmatch(r"[0-9a-f]{3}", low):
        return Color(int(low[0] * 2, 16), int(low[1] * 2, 16), int(low[2] * 2, 16))
    if re.fullmatch(r"[0-9a-f]{4}", low):
        return Color(int(low[0] * 2, 16), int(low[1] * 2, 16), int(low[2] * 2, 16), int(low[3] * 2, 16) / 255.0)
    if re.fullmatch(r"[0-9a-f]{6}", low):
        return Color(int(low[0:2], 16), int(low[2:4], 16), int(low[4:6], 16))
    if re.fullmatch(r"[0-9a-f]{8}", low):
        return Color(int(low[0:2], 16), int(low[2:4], 16), int(low[4:6], 16), int(low[6:8], 16) / 255.0)
    m = re.fullmatch(r"rgba?\((.*)\)", s.strip(), re.I)
    if m:
        parts = [p.strip() for p in m.group(1).split(",")]
        if len(parts) in (3, 4):
            r = parse_num(parts[0], 255.0); g = parse_num(parts[1], 255.0); b = parse_num(parts[2], 255.0)
            return Color(r, g, b, parse_alpha(parts[3]) if len(parts) == 4 else 1.0)
    m = re.fullmatch(r"hsla?\((.*)\)", s.strip(), re.I)
    if m:
        parts = [p.strip() for p in m.group(1).split(",")]
        if len(parts) in (3, 4):
            return Color.from_hsl(float(parts[0]), parse_num(parts[1], 1.0), parse_num(parts[2], 1.0), parse_alpha(parts[3]) if len(parts) == 4 else 1.0)
    m = re.fullmatch(r"gray\((.*)\)", s.strip(), re.I)
    if m:
        v = parse_num(m.group(1), 255.0)
        if v <= 1:
            v *= 255.0
        return Color(v, v, v)
    if "," in s:
        parts = [p.strip() for p in s.split(",")]
        if len(parts) in (3, 4):
            return Color(parse_num(parts[0], 255.0), parse_num(parts[1], 255.0), parse_num(parts[2], 255.0), parse_alpha(parts[3]) if len(parts) == 4 else 1.0)
    raise ValueError(f"Could not parse color '{text}'")


def fmt_hex(c):
    base = f"#{c.r:02x}{c.g:02x}{c.b:02x}"
    if c.a < 0.9995:
        base += f"{int(round(c.a * 255)):02x}"
    return base


def fmt_hsl(c, spaces=True):
    h, s, l = c.hsl()
    sep = ", " if spaces else ","
    return f"hsl({h}{sep}{s*100:.1f}%{sep}{l*100:.1f}%)"


def ansi8_value(c):
    if c.r == c.g == c.b:
        if c.r < 8:
            return 16
        if c.r > 248:
            return 231
        return 232 + int(round(((c.r - 8) / 247) * 24))
    r = int(round(c.r / 255 * 5)); g = int(round(c.g / 255 * 5)); b = int(round(c.b / 255 * 5))
    return 16 + 36 * r + 6 * g + b


def nearest_name(c):
    for name, rgb in NAMES.items():
        if rgb == (c.r, c.g, c.b):
            return name
    return ""


def format_color(kind, c):
    h, s, l = c.hsl()
    if kind == "hex":
        return fmt_hex(c)
    if kind == "rgb":
        if c.a < 0.9995:
            return f"rgba({c.r}, {c.g}, {c.b}, {c.a:.3f})"
        return f"rgb({c.r}, {c.g}, {c.b})"
    if kind == "rgb-float":
        return f"rgb({c.r/255:.3f}, {c.g/255:.3f}, {c.b/255:.3f})"
    if kind == "rgb-r": return str(c.r)
    if kind == "rgb-g": return str(c.g)
    if kind == "rgb-b": return str(c.b)
    if kind == "hsl": return fmt_hsl(c, True)
    if kind == "hsl-hue": return str(h)
    if kind == "hsl-saturation": return f"{s:.3f}"
    if kind == "hsl-lightness": return f"{l:.3f}"
    if kind == "hsv":
        hh, ss, vv = colorsys.rgb_to_hsv(*c.rgb01())
        return f"hsv({int(round(hh*360))%360}, {ss*100:.1f}%, {vv*100:.1f}%)"
    if kind == "hsv-hue":
        return str(int(round(colorsys.rgb_to_hsv(*c.rgb01())[0] * 360)) % 360)
    if kind == "hsv-saturation":
        return f"{colorsys.rgb_to_hsv(*c.rgb01())[1]:.3f}"
    if kind == "hsv-value":
        return f"{colorsys.rgb_to_hsv(*c.rgb01())[2]:.3f}"
    if kind == "luminance": return f"{c.luminance():.3f}"
    if kind == "brightness": return f"{c.brightness():.3f}"
    if kind == "ansi-8bit-value": return str(ansi8_value(c))
    if kind == "ansi-8bit" or kind == "ansi-8bit-escapecode": return f"\033[38;5;{ansi8_value(c)}m"
    if kind == "ansi-24bit" or kind == "ansi-24bit-escapecode": return f"\033[38;2;{c.r};{c.g};{c.b}m"
    if kind == "cmyk":
        if (c.r, c.g, c.b) == (0, 0, 0):
            return "cmyk(0, 0, 0, 100)"
        rr, gg, bb = c.rgb01()
        k = 1 - max(rr, gg, bb)
        cy = (1 - rr - k) / (1 - k); ma = (1 - gg - k) / (1 - k); ye = (1 - bb - k) / (1 - k)
        return f"cmyk({round(cy*100)}, {round(ma*100)}, {round(ye*100)}, {round(k*100)})"
    if kind == "name":
        return nearest_name(c)
    if kind in ("lab", "lch", "oklab", "oklch"):
        return fmt_hsl(c, True)
    if kind.endswith("-lightness") or kind.endswith("-chroma") or kind.endswith("-hue") or kind.endswith("-a") or kind.endswith("-b") or kind.endswith("-l"):
        return "0.000"
    return fmt_hex(c)


def input_colors(args):
    vals = []
    if args:
        for a in args:
            if a == "-":
                vals.extend(x.strip() for x in sys.stdin if x.strip())
            else:
                vals.append(a)
    else:
        vals.extend(x.strip() for x in sys.stdin if x.strip())
    return [parse_color(v) for v in vals]


def out_lines(lines):
    sys.stdout.write("\n".join(lines))
    if lines:
        sys.stdout.write("\n")


def cmd_format(args):
    kind = "hex"
    if args and not looks_like_color(args[0]):
        kind = args[0]; args = args[1:]
    out_lines([format_color(kind, c) for c in input_colors(args)])


def looks_like_color(s):
    low = s.lower().strip()
    return low in NAMES or low.startswith("#") or "," in low or "(" in low or bool(re.fullmatch(r"[0-9a-fA-F]{3,8}", low))


def adjust_hsl(colors, dl=0.0, ds=0.0, dh=0.0):
    out = []
    for c in colors:
        h, s, l = c.hsl()
        out.append(fmt_hsl(Color.from_hsl(h + dh, clamp(s + ds), clamp(l + dl), c.a), False))
    out_lines(out)


def cmd_mix(args):
    frac = 0.5
    clean = []
    i = 0
    while i < len(args):
        if args[i] in ("-f", "--fraction"):
            frac = float(args[i + 1]); i += 2
        elif args[i].startswith("--fraction="):
            frac = float(args[i].split("=", 1)[1]); i += 1
        elif args[i] in ("-s", "--colorspace"):
            i += 2
        elif args[i].startswith("--colorspace="):
            i += 1
        else:
            clean.append(args[i]); i += 1
    base = parse_color(clean[0])
    others = input_colors(clean[1:])
    lines = []
    for c in others:
        r = c.r * (1 - frac) + base.r * frac
        g = c.g * (1 - frac) + base.g * frac
        b = c.b * (1 - frac) + base.b * frac
        lines.append(fmt_hsl(Color(r, g, b), False))
    out_lines(lines)


def cmd_gradient(args):
    n = 10
    clean = []
    i = 0
    while i < len(args):
        if args[i] in ("-n", "--number"):
            n = int(args[i + 1]); i += 2
        elif args[i].startswith("--number="):
            n = int(args[i].split("=", 1)[1]); i += 1
        elif args[i] in ("-s", "--colorspace"):
            i += 2
        elif args[i].startswith("--colorspace="):
            i += 1
        else:
            clean.append(args[i]); i += 1
    stops = [parse_color(x) for x in clean]
    if not stops:
        return
    if n <= 1:
        out_lines([fmt_hsl(stops[0], False)])
        return
    lines = []
    for idx in range(n):
        t = idx / (n - 1)
        pos = t * (len(stops) - 1)
        j = min(int(math.floor(pos)), len(stops) - 2)
        local = pos - j
        a, b = stops[j], stops[j + 1]
        lines.append(fmt_hsl(Color(a.r + (b.r-a.r)*local, a.g + (b.g-a.g)*local, a.b + (b.b-a.b)*local), False))
    out_lines(lines)


def cmd_sort(args):
    reverse = False; unique = False; clean = []
    order = "hue"
    for a in args:
        if a in ("-r", "--reverse"): reverse = True
        elif a in ("-u", "--unique"): unique = True
        elif a in ("brightness", "luminance", "hue", "chroma", "random"): order = a
        else: clean.append(a)
    colors = input_colors(clean)
    if unique:
        seen = set(); colors = [c for c in colors if not ((c.r,c.g,c.b) in seen or seen.add((c.r,c.g,c.b)))]
    def key(c):
        if order == "brightness": return c.brightness()
        if order == "luminance": return c.luminance()
        if order == "random": return random.random()
        return c.hsl()[0]
    out_lines([fmt_hsl(c, False) for c in sorted(colors, key=key, reverse=reverse)])


def main(argv):
    if not argv or argv[0] in ("-h", "--help", "help"):
        print("A command-line tool to generate, analyze, convert and manipulate colors\n\nUsage: executable [OPTIONS] <COMMAND>")
        return 0
    if argv[0] in ("-V", "--version"):
        print(VERSION); return 0
    while argv and argv[0].startswith("-") and argv[0] not in ("-",):
        if argv[0] in ("-m", "--color-mode", "--color-picker"):
            argv = argv[2:]
        elif argv[0].startswith("--color-mode=") or argv[0].startswith("--color-picker=") or argv[0] == "-f":
            argv = argv[1:]
        else:
            break
    cmd, args = argv[0], argv[1:]
    try:
        if cmd == "format": cmd_format(args)
        elif cmd == "lighten": adjust_hsl(input_colors(args[1:]), dl=float(args[0]))
        elif cmd == "darken": adjust_hsl(input_colors(args[1:]), dl=-float(args[0]))
        elif cmd == "saturate": adjust_hsl(input_colors(args[1:]), ds=float(args[0]))
        elif cmd == "desaturate": adjust_hsl(input_colors(args[1:]), ds=-float(args[0]))
        elif cmd == "rotate": adjust_hsl(input_colors(args[1:]), dh=float(args[0]))
        elif cmd == "complement": adjust_hsl(input_colors(args), dh=180)
        elif cmd == "gray":
            v = clamp(float(args[0])); out_lines([fmt_hsl(Color.from_hsl(0, 0, v), False)])
        elif cmd == "textcolor":
            out_lines([fmt_hsl(Color(0,0,0) if c.luminance() > 0.179 else Color(255,255,255), False) for c in input_colors(args)])
        elif cmd == "to-gray":
            out_lines([fmt_hsl(Color.from_hsl(0, 0, math.sqrt(c.luminance())), False) for c in input_colors(args)])
        elif cmd == "mix": cmd_mix(args)
        elif cmd == "gradient": cmd_gradient(args)
        elif cmd == "sort-by": cmd_sort(args)
        elif cmd == "list":
            out_lines(sorted(NAMES.keys(), key=lambda n: Color(*NAMES[n]).hsl()[0]))
        elif cmd == "random":
            n = 10
            for i, a in enumerate(args):
                if a in ("-n", "--number") and i + 1 < len(args): n = int(args[i+1])
                elif a.startswith("--number="): n = int(a.split("=", 1)[1])
            out_lines([fmt_hex(Color(random.randrange(256), random.randrange(256), random.randrange(256))) for _ in range(n)])
        elif cmd == "distinct":
            n = int(args[0]) if args and args[0].isdigit() else 10
            out_lines([f"hsl({int(round(i * 360.0 / max(n, 1))) % 360},65.0%,55.0%)" for i in range(n)])
        elif cmd == "paint":
            paint(args)
        elif cmd == "color":
            out_lines([fmt_hsl(c, False) for c in input_colors(args)])
        elif cmd == "colorblind":
            out_lines([fmt_hsl(c, False) for c in input_colors(args[1:])])
        elif cmd == "set":
            prop, val = args[0], float(args[1]); res = []
            for c in input_colors(args[2:]):
                h, s, l = c.hsl()
                if prop in ("red",): c.r = int(clamp(val,0,255))
                elif prop == "green": c.g = int(clamp(val,0,255))
                elif prop == "blue": c.b = int(clamp(val,0,255))
                elif prop in ("hsl-hue", "hue"): h = val; c = Color.from_hsl(h, s, l)
                elif prop in ("hsl-saturation",): c = Color.from_hsl(h, val, l)
                elif prop in ("hsl-lightness", "lightness"): c = Color.from_hsl(h, s, val)
                elif prop == "alpha": c.a = val
                res.append(fmt_hsl(c, False) if prop != "alpha" else fmt_hex(c))
            out_lines(res)
        elif cmd == "colorcheck":
            print("\033[48;2;73;39;50m  \033[48;2;16;51;30m  \033[48;2;29;54;90m  \033[0m")
        elif cmd == "pick":
            print("[pastel error]: No color picker available", file=sys.stderr); return 1
        else:
            print(f"error: unrecognized subcommand '{cmd}'", file=sys.stderr); return 2
        return 0
    except Exception as e:
        print(f"[pastel error]: {e}", file=sys.stderr)
        return 1


def paint(args):
    bg = None; styles = []; no_nl = False; clean = []; i = 0
    while i < len(args):
        a = args[i]
        if a in ("-o", "--on"): bg = parse_color(args[i+1]); i += 2
        elif a == "--on" or a.startswith("--on="): bg = parse_color(a.split("=",1)[1]); i += 1
        elif a in ("-b", "--bold"): styles.append("1"); i += 1
        elif a in ("-i", "--italic"): styles.append("3"); i += 1
        elif a in ("-u", "--underline"): styles.append("4"); i += 1
        elif a in ("-n", "--no-newline"): no_nl = True; i += 1
        else: clean.append(a); i += 1
    fg = parse_color(sys.stdin.readline().strip() if clean and clean[0] == "-" else clean[0])
    text = " ".join(clean[1:]) if len(clean) > 1 else sys.stdin.read()
    codes = styles + [f"38;2;{fg.r};{fg.g};{fg.b}"]
    if bg:
        codes.append(f"48;2;{bg.r};{bg.g};{bg.b}")
    sys.stdout.write(f"\033[{';'.join(codes)}m{text}\033[0m")
    if not no_nl:
        sys.stdout.write("\n")


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
