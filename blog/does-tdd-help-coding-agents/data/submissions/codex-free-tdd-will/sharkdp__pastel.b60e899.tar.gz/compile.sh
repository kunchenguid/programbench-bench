#!/bin/bash
set -e
cp pastel.py executable
chmod +x executable
