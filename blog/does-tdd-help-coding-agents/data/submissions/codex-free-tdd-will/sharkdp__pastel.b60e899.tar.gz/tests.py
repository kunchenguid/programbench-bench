#!/usr/bin/env python3
import os
import subprocess
import sys


ROOT = os.path.dirname(os.path.abspath(__file__))
EXE = os.path.join(ROOT, "executable")


def run(*args, input_text=None):
    result = subprocess.run(
        [EXE, *args],
        input=input_text,
        text=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
    )
    return result.returncode, result.stdout, result.stderr


def assert_out(args, expected):
    code, out, err = run(*args)
    assert code == 0, (args, code, out, err)
    assert out == expected, (args, out, expected)


def test_format_core_colors():
    assert_out(["format", "hex", "red"], "#ff0000\n")
    assert_out(["format", "rgb", "red"], "rgb(255, 0, 0)\n")
    assert_out(["format", "hsl", "336699"], "hsl(210, 50.0%, 40.0%)\n")
    assert_out(["format", "hex", "rgb(119, 136, 153)"], "#778899\n")


def test_transforms_and_pipelines():
    assert_out(["lighten", "0.2", "red"], "hsl(0,100.0%,70.0%)\n")
    assert_out(["darken", "0.2", "red"], "hsl(0,100.0%,30.0%)\n")
    assert_out(["rotate", "180", "red"], "hsl(180,100.0%,50.0%)\n")
    assert_out(["mix", "--colorspace", "RGB", "red", "blue"], "hsl(300,100.0%,25.1%)\n")
    assert_out(["gradient", "-n", "3", "--colorspace", "RGB", "red", "blue"], "hsl(0,100.0%,50.0%)\nhsl(300,100.0%,25.1%)\nhsl(240,100.0%,50.0%)\n")
    code, out, err = run("format", "rgb", "#77889980")
    assert (code, out, err) == (0, "rgba(119, 136, 153, 0.502)\n", "")
    code, out, err = run("format", "rgb", input_text="red\nblue\n")
    assert (code, out, err) == (0, "rgb(255, 0, 0)\nrgb(0, 0, 255)\n", "")


def test_auxiliary_cli_behaviors():
    code, out, err = run("random", "-n", "3")
    assert code == 0 and err == ""
    assert len([x for x in out.splitlines() if x.startswith("#")]) == 3
    assert_out(["distinct", "3"], "hsl(0,65.0%,55.0%)\nhsl(120,65.0%,55.0%)\nhsl(240,65.0%,55.0%)\n")
    code, out, err = run("paint", "-n", "--bold", "red", "Hi")
    assert (code, out, err) == (0, "\x1b[1;38;2;255;0;0mHi\x1b[0m", "")
    code, out, err = run("format", "hex", "notacolor")
    assert code != 0
    assert "Could not parse color 'notacolor'" in err


if __name__ == "__main__":
    tests = [v for k, v in sorted(globals().items()) if k.startswith("test_")]
    failures = 0
    for test in tests:
        try:
            test()
            print(f"ok {test.__name__}")
        except Exception as exc:
            failures += 1
            print(f"not ok {test.__name__}: {exc}", file=sys.stderr)
    sys.exit(1 if failures else 0)
