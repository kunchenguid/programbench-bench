#!/bin/bash
set -euo pipefail
rm -f executable
cp src/pyage.py executable
chmod +x executable
