import os
import gzip
import re
import shutil
import subprocess
import tempfile
import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]


class LnavCliTest(unittest.TestCase):
    def build(self):
        if not hasattr(self, "tmp"):
            self.tmp = tempfile.TemporaryDirectory()
            work = Path(self.tmp.name)
            shutil.copy(ROOT / "compile.sh", work / "compile.sh")
            shutil.copytree(ROOT / "src", work / "src")
            subprocess.run(["bash", "compile.sh"], cwd=work, check=True)
        return Path(self.tmp.name) / "executable"

    def tearDown(self):
        tmp = getattr(self, "tmp", None)
        if tmp is not None:
            tmp.cleanup()

    def run_cmd(self, *args, input_text=None):
        exe = self.build()
        return subprocess.run(
            [str(exe), *args],
            input=input_text,
            text=True,
            capture_output=True,
        )

    def test_headless_prints_files_and_quiet_suppresses_output(self):
        exe = self.build()
        work = exe.parent
        log = work / "app.log"
        log.write_text(
            "2024-01-01 00:00:01 INFO first\n"
            "not dated line\n"
            "2024-01-01 00:00:02 WARN second\n"
        )

        proc = subprocess.run([str(exe), "-n", "app.log"], cwd=work, text=True, capture_output=True)
        self.assertEqual(proc.returncode, 0)
        self.assertEqual(proc.stdout, log.read_text())
        self.assertEqual(proc.stderr, "")

        proc = subprocess.run([str(exe), "-n", "-q", "app.log"], cwd=work, text=True, capture_output=True)
        self.assertEqual(proc.returncode, 0)
        self.assertEqual(proc.stdout, "")
        self.assertEqual(proc.stderr, "")

    def test_headless_reports_missing_file(self):
        exe = self.build()
        proc = subprocess.run(
            [str(exe), "-n", "missing.log"],
            cwd=exe.parent,
            text=True,
            capture_output=True,
        )
        self.assertEqual(proc.returncode, 1)
        self.assertEqual(proc.stdout, "")
        self.assertEqual(
            proc.stderr,
            "  error: unable to open file: missing.log\n"
            " reason: No such file or directory\n",
        )

    def test_headless_reads_gzip_files(self):
        exe = self.build()
        work = exe.parent
        compressed = work / "plain.log.gz"
        with gzip.open(compressed, "wt") as f:
            f.write("gz line 1\ngz line 2\n")

        proc = subprocess.run(
            [str(exe), "-n", "plain.log.gz"],
            cwd=work,
            text=True,
            capture_output=True,
        )
        self.assertEqual(proc.returncode, 0)
        self.assertEqual(proc.stdout, "gz line 1\ngz line 2\n")
        self.assertEqual(proc.stderr, "")

    def test_headless_reads_stdin(self):
        proc = self.run_cmd("-n", input_text="line1\nline2\n")
        self.assertEqual(proc.returncode, 0)
        self.assertEqual(proc.stdout, "line1\nline2\n")
        self.assertEqual(proc.stderr, "")

    def test_executes_shell_command(self):
        proc = self.run_cmd("-n", "-e", "printf hi")
        self.assertEqual(proc.returncode, 0)
        self.assertEqual(proc.stdout, "hi\n")
        self.assertEqual(proc.stderr, "")

    def test_requires_headless_when_stdout_is_not_tty(self):
        proc = self.run_cmd()
        self.assertEqual(proc.returncode, 1)
        self.assertEqual(proc.stdout, "")
        self.assertEqual(
            proc.stderr,
            "  error: unable to display interactive text UI\n"
            " reason: stdout is not a TTY\n"
            " = help: pass the -n option to run lnav in headless mode or don't redirect stdout\n",
        )

    def test_update_and_management_messages(self):
        proc = self.run_cmd("-u")
        self.assertEqual(proc.returncode, 0)
        self.assertEqual(
            proc.stdout,
            "No formats from git repositories found, use 'lnav -i extra' to install third-party formats\n",
        )
        self.assertEqual(proc.stderr, "")

        proc = self.run_cmd("-m")
        self.assertEqual(proc.returncode, 1)
        self.assertEqual(proc.stdout, "")
        self.assertIn("  error: expecting an operation to perform\n", proc.stderr)
        self.assertIn("          • config: perform operations on the lnav configuration\n", proc.stderr)

    def test_internal_help_headless(self):
        proc = self.run_cmd("-n", "-H")
        self.assertEqual(proc.returncode, 0)
        self.assertTrue(proc.stdout.startswith("\nlnav 0.14.0\n\nA fancy log file viewer"))
        self.assertIn("Opening Paths/URLs\n", proc.stdout)
        self.assertEqual(proc.stderr, "")

    def test_warnings_without_files(self):
        proc = self.run_cmd("-n", "-W")
        self.assertEqual(proc.returncode, 1)
        self.assertEqual(proc.stdout, "")
        self.assertEqual(
            proc.stderr,
            "  error: nothing to do\n"
            " reason: no files given or default files found\n"
            " = help: use the “-N” option to open lnav without loading any files\n",
        )

    def test_rotated_mode_reports_missing_glob(self):
        exe = self.build()
        work = exe.parent
        (work / "app.log").write_text("cur\n")
        proc = subprocess.run(
            [str(exe), "-n", "-R", "app.log"],
            cwd=work,
            text=True,
            capture_output=True,
        )
        self.assertEqual(proc.returncode, 1)
        self.assertEqual(proc.stdout, "")
        self.assertRegex(
            proc.stderr,
            re.escape("  error: unable to open file: ")
            + r".*/app\.log\.\*\n"
            + re.escape(" reason: failed to find path of “")
            + r".*/app\.log\.\*”\n"
            + re.escape(" |        reason: No such file or directory\n"),
        )

    def test_prints_version(self):
        for flag in ("-V", "--version"):
            with self.subTest(flag=flag):
                proc = self.run_cmd(flag)
                self.assertEqual(proc.returncode, 0)
                self.assertEqual(proc.stdout, "lnav 0.14.0-07efb63\n")
                self.assertEqual(proc.stderr, "")

    def test_prints_help(self):
        for flag in ("-h", "--help"):
            with self.subTest(flag=flag):
                proc = self.run_cmd(flag)
                self.assertEqual(proc.returncode, 0)
                self.assertIn("usage: ", proc.stdout)
                self.assertIn("[options] [logfile1 logfile2 ...]", proc.stdout)
                self.assertIn("  -n         Run without the curses UI. (headless mode)", proc.stdout)
                self.assertIn("Management-Mode Options", proc.stdout)
                self.assertTrue(proc.stdout.endswith("Version: lnav 0.14.0-07efb63\n"))
                self.assertEqual(proc.stderr, "")

    def test_rejects_unexpected_arguments(self):
        for flag in ("--bad", "-z"):
            with self.subTest(flag=flag):
                proc = self.run_cmd(flag)
                self.assertEqual(proc.returncode, 109)
                self.assertEqual(proc.stdout, "")
                self.assertEqual(
                    proc.stderr,
                    "  error: invalid command-line arguments\n"
                    f" reason: The following argument was not expected: {flag}\n",
                )

    def test_rejects_missing_option_values(self):
        cases = {
            "-I": ("-I: 1 required TEXT:DIR missing", 114),
            "-d": ("-d: 1 required FILE missing", 114),
            "-c": ("-c: 1 required  missing", 114),
            "-f": ("-f: 1 required  missing", 114),
            "-S": ("--since: 1 required TEXT missing", 114),
            "--since": ("--since: 1 required TEXT missing", 114),
            "-U": ("--until: 1 required TEXT missing", 114),
            "--until": ("--until: 1 required TEXT missing", 114),
            "-i": ("-i requires file", 107),
        }
        for flag, (reason, code) in cases.items():
            with self.subTest(flag=flag):
                proc = self.run_cmd(flag)
                self.assertEqual(proc.returncode, code)
                self.assertEqual(proc.stdout, "")
                self.assertEqual(
                    proc.stderr,
                    "  error: invalid command-line arguments\n"
                    f" reason: {reason}\n",
                )


if __name__ == "__main__":
    unittest.main()
