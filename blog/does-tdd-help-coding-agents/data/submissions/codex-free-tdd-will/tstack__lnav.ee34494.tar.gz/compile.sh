#!/bin/bash
set -e
cp src/lnav.py executable
chmod +x executable
