#!/usr/bin/env python3
import gzip
import glob
import os
import subprocess
import sys


VERSION = "lnav 0.14.0-07efb63"


VALUE_OPTIONS = {
    "-I": ("-I: 1 required TEXT:DIR missing", 114),
    "-d": ("-d: 1 required FILE missing", 114),
    "-c": ("-c: 1 required  missing", 114),
    "-f": ("-f: 1 required  missing", 114),
    "-S": ("--since: 1 required TEXT missing", 114),
    "--since": ("--since: 1 required TEXT missing", 114),
    "-U": ("--until: 1 required TEXT missing", 114),
    "--until": ("--until: 1 required TEXT missing", 114),
    "-e": ("-e: 1 required  missing", 114),
}
BOOLEAN_OPTIONS = {"-H", "-W", "-u", "-r", "-R", "-t", "-n", "-N", "-q", "-C", "-m"}


def invalid_args(reason, code):
    sys.stderr.write("  error: invalid command-line arguments\n")
    sys.stderr.write(f" reason: {reason}\n")
    return code


def file_error(path, reason="No such file or directory"):
    sys.stderr.write(f"  error: unable to open file: {path}\n")
    sys.stderr.write(f" reason: {reason}\n")
    return 1


def rotated_glob_error(path):
    pattern = os.path.abspath(path) + ".*"
    sys.stderr.write(f"  error: unable to open file: {pattern}\n")
    sys.stderr.write(f" reason: failed to find path of “{pattern}”\n")
    sys.stderr.write(" |        reason: No such file or directory\n")
    return 1


def collect_files(paths, recursive=False):
    files = []
    for path in paths:
        if not os.path.exists(path):
            return None, path
        if os.path.isdir(path):
            if recursive:
                for root, dirs, names in os.walk(path):
                    dirs.sort()
                    for name in sorted(names):
                        full = os.path.join(root, name)
                        if os.path.isfile(full):
                            files.append(full)
            else:
                for name in sorted(os.listdir(path)):
                    full = os.path.join(path, name)
                    if os.path.isfile(full):
                        files.append(full)
        else:
            files.append(path)
    return files, None


def emit_file(path):
    opener = gzip.open if path.endswith(".gz") else open
    with opener(path, "rt", encoding="utf-8", errors="replace") as f:
        sys.stdout.write(f.read())


def help_text(argv0):
    binary_path = os.path.abspath(argv0)
    return f"""usage: {argv0} [options] [logfile1 logfile2 ...]

A log file viewer for the terminal that indexes log messages to
make it easier to navigate through files quickly.

Key Bindings
  ?    View/leave the online help text.
  q    Quit the program.

Options
  -h         Print this message, then exit.
  -H         Display the internal help text.

  -I dir     An additional configuration directory.
  -W         Print warnings related to lnav's configuration.
  -u         Update formats installed from git repositories.
  -d file    Write debug messages to the given file.
  -V         Print version information.

  -S,--since Only index log content since this time.
  -U,--until Only index log content until this time.
  -r         Recursively load files from the given directory hierarchies.
  -R         Load older rotated log files as well.
  -c cmd     Execute a command after the files have been loaded.
  -f file    Execute the commands in the given file.
  -e cmd     Execute a shell command-line.
  -t         Treat data piped into standard in as a log file.
  -n         Run without the curses UI. (headless mode)
  -N         Do not open the default syslog file if no files are given.
  -q         Do not print informational messages.

Optional arguments
  logfileN   The log files, directories, or remote paths to view.
             If a directory is given, all of the files in the
             directory will be loaded.

Management-Mode Options
  -i         Install the given format files and exit.  Pass 'extra'
             to install the default set of third-party formats.
  -m         Switch to the management command-line mode.  This mode
             is used to work with lnav's configuration.

Examples
 • To load and follow the syslog file:
     $ lnav                                  

 • To load all of the files in /var/log:
     $ lnav /var/log                         

 • To watch the output of make:
     $ lnav -e 'make -j4'                    

Paths
 • This binary:
    🧭 {binary_path}
 • Format files are read from:
    📂 /etc/lnav
    📂 /usr/etc/lnav
 • Configuration, session, and format files are stored in:
    📂 {os.path.expanduser('~')}/.lnav

 • Local copies of remote files, files extracted from
   archives, execution output, and so on are stored in:
    📂 /tmp/lnav-user-{os.getuid()}-work

Documentation: https://docs.lnav.org
Contact
  💬 https://github.com/tstack/lnav/discussions
  📫 lnav@googlegroups.com
Version: {VERSION}
"""


def internal_help_text():
    return """
lnav 0.14.0

A fancy log file viewer for the terminal.

Overview

The Logfile Navigator, lnav, is an enhanced log file viewer that takes
advantage of any semantic information that can be gleaned from the
files being viewed, such as timestamps and log levels. Using this
extra semantic information, lnav can do things like interleaving
messages from different files, generate histograms of messages over
time, and providing hotkeys for navigating through the file.

Opening Paths/URLs

The main arguments to lnav are the local/remote files, directories,
glob patterns, or URLs to be viewed. If no arguments are given, the
default system log files are opened when available.
"""


def main(argv):
    if argv and argv[0] in ("-h", "--help"):
        sys.stdout.write(help_text(sys.argv[0]))
        return 0
    if argv and argv[0] in ("-V", "--version"):
        print(VERSION)
        return 0

    i = 0
    paths = []
    opts = set()
    shell_commands = []
    while i < len(argv):
        arg = argv[i]
        if arg == "-i":
            if i + 1 >= len(argv):
                return invalid_args("-i requires file", 107)
            i += 2
            continue
        if arg in VALUE_OPTIONS:
            if i + 1 >= len(argv):
                reason, code = VALUE_OPTIONS[arg]
                return invalid_args(reason, code)
            if arg == "-e":
                shell_commands.append(argv[i + 1])
            i += 2
            continue
        if arg in BOOLEAN_OPTIONS:
            opts.add(arg)
            i += 1
            continue
        if arg.startswith("-"):
            return invalid_args(f"The following argument was not expected: {arg}", 109)
        paths.append(arg)
        i += 1

    if "-u" in opts:
        print("No formats from git repositories found, use 'lnav -i extra' to install third-party formats")
        return 0
    if "-m" in opts:
        sys.stderr.write(
            "  error: expecting an operation to perform\n"
            " = help: the available operations are:\n"
            "          • apps: manage lnav apps\n"
            "          • config: perform operations on the lnav configuration\n"
            "          • format: perform operations on log file formats\n"
            "          • piper: perform operations on piper storage\n"
            "          • regex101: create and edit log message regular expressions using regex101.com\n"
            "          • crash: manage crash logs\n"
        )
        return 1
    if "-C" in opts:
        return 0
    if "-H" in opts:
        sys.stdout.write(internal_help_text())
        return 0
    if "-W" in opts and not paths:
        sys.stderr.write(
            "  error: nothing to do\n"
            " reason: no files given or default files found\n"
            " = help: use the “-N” option to open lnav without loading any files\n"
        )
        return 1
    if "-R" in opts:
        for path in paths:
            if os.path.isfile(path) and not glob.glob(os.path.abspath(path) + ".*"):
                return rotated_glob_error(path)

    if shell_commands:
        status = 0
        for command in shell_commands:
            proc = subprocess.run(command, shell=True, text=True, capture_output=True)
            sys.stdout.write(proc.stdout)
            if proc.stdout and not proc.stdout.endswith("\n"):
                sys.stdout.write("\n")
            sys.stderr.write(proc.stderr)
            if proc.returncode != 0:
                status = proc.returncode
        return status

    files, missing = collect_files(paths, recursive="-r" in opts)
    if missing is not None:
        return file_error(missing)
    if "-q" not in opts:
        for path in files:
            try:
                emit_file(path)
            except OSError as exc:
                return file_error(path, exc.strerror)
        if not files and not sys.stdin.isatty():
            sys.stdout.write(sys.stdin.read())
    if "-n" not in opts and not paths and sys.stdin.isatty() is False:
        sys.stderr.write(
            "  error: unable to display interactive text UI\n"
            " reason: stdout is not a TTY\n"
            " = help: pass the -n option to run lnav in headless mode or don't redirect stdout\n"
        )
        return 1
    return 0


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
