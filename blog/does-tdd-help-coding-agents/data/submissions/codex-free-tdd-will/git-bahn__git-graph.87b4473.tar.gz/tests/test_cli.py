import os
import subprocess
import tempfile
import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
EXE = ROOT / "executable"


def run_cmd(args, cwd=None, check=True):
    proc = subprocess.run(
        args,
        cwd=cwd,
        text=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
    )
    if check and proc.returncode != 0:
        raise AssertionError(
            f"command failed: {args}\nstdout={proc.stdout}\nstderr={proc.stderr}"
        )
    return proc


def make_repo():
    tmp = tempfile.TemporaryDirectory()
    repo = Path(tmp.name)
    run_cmd(["git", "init", "-q", "-b", "main"], cwd=repo)
    run_cmd(["git", "config", "user.name", "Alice"], cwd=repo)
    run_cmd(["git", "config", "user.email", "alice@example.com"], cwd=repo)
    return tmp, repo


def commit(repo, message, when, filename="f.txt", content=None):
    path = repo / filename
    path.write_text(content if content is not None else message + "\n")
    run_cmd(["git", "add", filename], cwd=repo)
    env = os.environ.copy()
    env["GIT_AUTHOR_DATE"] = when
    env["GIT_COMMITTER_DATE"] = when
    proc = subprocess.run(
        ["git", "commit", "-q", "-m", message],
        cwd=repo,
        text=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        env=env,
    )
    if proc.returncode != 0:
        raise AssertionError(proc.stderr)


class CliTests(unittest.TestCase):
    def test_model_list_prints_builtin_models(self):
        proc = run_cmd([str(EXE), "model", "--list"])
        self.assertEqual(proc.stdout, "git-flow\nsimple\nnone\n")
        self.assertEqual(proc.stderr, "")

    def test_graph_reports_missing_repository(self):
        with tempfile.TemporaryDirectory() as tmp:
            proc = run_cmd([str(EXE), "--path", tmp], check=False)
        self.assertEqual(proc.returncode, 1)
        self.assertEqual(proc.stdout, "")
        self.assertEqual(
            proc.stderr,
            f"ERROR: could not find repository at '{tmp}'\n"
            "       Navigate into a repository before running git-graph, or use option --path\n",
        )

    def test_linear_oneline_graph(self):
        tmp, repo = make_repo()
        self.addCleanup(tmp.cleanup)
        commit(repo, "first commit", "2024-01-01T00:00:00+0000")
        commit(repo, "second commit", "2024-01-02T00:00:00+0000")
        hashes = run_cmd(["git", "log", "--format=%h", "--reverse"], cwd=repo).stdout.splitlines()

        proc = run_cmd([str(EXE), "--path", str(repo), "--no-color"])

        self.assertEqual(
            proc.stdout,
            f" ●  {hashes[1]} (HEAD -> main) second commit\n"
            f" ●  {hashes[0]} first commit\n",
        )

    def test_reverse_max_count_and_custom_format(self):
        tmp, repo = make_repo()
        self.addCleanup(tmp.cleanup)
        commit(repo, "first commit", "2024-01-01T00:00:00+0000")
        commit(repo, "second commit", "2024-01-02T00:00:00+0000")
        hashes = run_cmd(["git", "log", "--format=%h", "--reverse"], cwd=repo).stdout.splitlines()

        proc = run_cmd(
            [str(EXE), "--path", str(repo), "--no-color", "--reverse", "-n", "1", "-f", "%h:%s"]
        )

        self.assertEqual(proc.stdout, f" ●  {hashes[1]}:second commit\n")

    def test_basic_merge_graph_ascii(self):
        tmp, repo = make_repo()
        self.addCleanup(tmp.cleanup)
        commit(repo, "base", "2024-01-01T00:00:00+0000", content="base\n")
        run_cmd(["git", "checkout", "-q", "-b", "feature/x"], cwd=repo)
        commit(repo, "feature", "2024-01-02T00:00:00+0000", "feature.txt", "feature\n")
        run_cmd(["git", "checkout", "-q", "main"], cwd=repo)
        commit(repo, "main2", "2024-01-03T00:00:00+0000", content="main2\n")
        env = os.environ.copy()
        env["GIT_AUTHOR_DATE"] = "2024-01-04T00:00:00+0000"
        env["GIT_COMMITTER_DATE"] = "2024-01-04T00:00:00+0000"
        subprocess.run(
            ["git", "merge", "--no-ff", "-q", "feature/x", "-m", "merge feature"],
            cwd=repo,
            text=True,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            env=env,
            check=True,
        )
        run_cmd(["git", "tag", "v1"], cwd=repo)
        rows = run_cmd(["git", "log", "--topo-order", "--format=%h%x00%s"], cwd=repo).stdout.splitlines()
        by_subject = {row.split("\0", 1)[1]: row.split("\0", 1)[0] for row in rows}

        proc = run_cmd([str(EXE), "--path", str(repo), "--style", "ascii", "--no-color"])

        merge_h = by_subject["merge feature"]
        main_h = by_subject["main2"]
        feat_h = by_subject["feature"]
        base_h = by_subject["base"]
        self.assertEqual(
            proc.stdout,
            f" o<.  {merge_h} (HEAD -> main) [v1] merge feature\n"
            f" * |  {main_h} main2\n"
            f" | *  {feat_h} (feature/x) feature\n"
            " |-'  \n"
            f" *    {base_h} base\n",
        )


if __name__ == "__main__":
    unittest.main()
