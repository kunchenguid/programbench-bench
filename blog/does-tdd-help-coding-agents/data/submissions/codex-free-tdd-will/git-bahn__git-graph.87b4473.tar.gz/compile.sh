#!/bin/bash
set -e
cp git_graph.py executable
chmod +x executable
