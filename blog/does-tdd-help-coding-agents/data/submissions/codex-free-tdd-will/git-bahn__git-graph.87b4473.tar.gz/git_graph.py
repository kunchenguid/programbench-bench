#!/usr/bin/env python3
import os
import subprocess
import sys

VERSION = "git-graph 0.7.0"
MODELS = ("git-flow", "simple", "none")
HELP = """Structured Git graphs for your branching model.
    https://github.com/mlange-42/git-graph

EXAMPES:
    git-graph                   -> Show graph
    git-graph --style round     -> Show graph in a different style
    git-graph --model <model>   -> Show graph using a certain <model>
    git-graph model --list      -> List available branching models
    git-graph model             -> Show repo's current branching models
    git-graph model <model>     -> Permanently set model <model> for this repo

Usage: executable [OPTIONS] [COMMAND]

Commands:
  model  Prints or permanently sets the branching model for a repository.
  help   Print this message or the help of the given subcommand(s)

Options:
  -p, --path <path>        Open repository from this path or above. Default '.'
  -m, --model <model>      Branching model. Available presets are [simple|git-flow|none].
  -n, --max-count <n>      Maximum number of commits
      --color <color>      Specify when colors should be used. One of [auto|always|never].
      --no-color           Print without colors.
  -w, --wrap [<wrap>...]   Line wrapping for formatted commit text.
  -f, --format <format>    Commit format. One of [oneline|short|medium|full|"<string>"].
  -r, --reverse            Reverse the order of commits.
  -l, --local              Show only local branches, no remotes.
      --svg                Render graph as SVG instead of text-based.
  -d, --debug              Additional debug output and graphics.
  -S, --sparse             Print a less compact graph.
  -s, --style <style>      Output style. One of [normal/thin|round|bold|double|ascii].
  -h, --help               Print help (see a summary with '-h')
  -V, --version            Print version
"""

def parse_global_args(argv):
    path = "."
    rest = []
    i = 0
    while i < len(argv):
        arg = argv[i]
        if arg in ("-p", "--path") and i + 1 < len(argv):
            path = argv[i + 1]
            i += 2
        else:
            rest.append(arg)
            i += 1
    return path, rest


def parse_options(argv):
    opts = {
        "format": "oneline",
        "max_count": None,
        "reverse": False,
        "style": "normal",
        "svg": False,
        "sparse": False,
    }
    rest = []
    i = 0
    while i < len(argv):
        arg = argv[i]
        if arg in ("-n", "--max-count") and i + 1 < len(argv):
            opts["max_count"] = argv[i + 1]
            i += 2
        elif arg in ("-f", "--format") and i + 1 < len(argv):
            opts["format"] = argv[i + 1]
            i += 2
        elif arg in ("-s", "--style") and i + 1 < len(argv):
            opts["style"] = expand_style(argv[i + 1])
            i += 2
        elif arg in ("-r", "--reverse"):
            opts["reverse"] = True
            i += 1
        elif arg == "--svg":
            opts["svg"] = True
            i += 1
        elif arg in ("-S", "--sparse"):
            opts["sparse"] = True
            i += 1
        elif arg in ("--no-color", "-l", "--local", "-d", "--debug", "--skip-repo-owner-validation"):
            i += 1
        elif arg == "--color" and i + 1 < len(argv):
            i += 2
        elif arg in ("-m", "--model") and i + 1 < len(argv):
            i += 2
        elif arg in ("-w", "--wrap"):
            i += 1
            while i < len(argv) and not argv[i].startswith("-"):
                i += 1
        else:
            rest.append(arg)
            i += 1
    return opts, rest


def expand_style(style):
    if style in ("a", "ascii"):
        return "ascii"
    if style in ("b", "bold"):
        return "bold"
    if style in ("d", "double"):
        return "double"
    if style in ("r", "round"):
        return "round"
    return "normal"


def find_repo(path):
    here = os.path.abspath(path)
    while True:
        if os.path.isdir(os.path.join(here, ".git")):
            return here
        parent = os.path.dirname(here)
        if parent == here:
            return None
        here = parent


def git(repo, args):
    return subprocess.run(
        ["git", "-C", repo] + args,
        text=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        check=True,
    ).stdout


def model_file(repo):
    return os.path.join(repo, ".git", "git-graph.toml")


def get_model(repo):
    path = model_file(repo)
    try:
        text = open(path, encoding="utf-8").read()
    except OSError:
        return None
    for line in text.splitlines():
        line = line.strip()
        if line.startswith("model"):
            return line.split("=", 1)[1].strip().strip('"')
    return None


def set_model(repo, model):
    with open(model_file(repo), "w", encoding="utf-8") as f:
        f.write(f'model = "{model}"\n')


def get_ref_map(repo):
    refs = {}
    branch_lines = git(repo, ["branch", "--format=%(refname:short) %(objectname)"]).splitlines()
    current = git(repo, ["branch", "--show-current"]).strip()
    for line in branch_lines:
        if not line:
            continue
        name, sha = line.split(" ", 1)
        refs.setdefault(sha, []).append(("branch", name))
    tag_lines = git(repo, ["tag", "--format=%(refname:short) %(objectname)"]).splitlines()
    for line in tag_lines:
        if not line:
            continue
        name, sha = line.split(" ", 1)
        refs.setdefault(sha, []).append(("tag", name))
    return refs, current


def decorate(sha, refs, current):
    parts = []
    tags = []
    for kind, name in refs.get(sha, []):
        if kind == "branch":
            parts.append(f"HEAD -> {name}" if name == current else name)
        else:
            tags.append(name)
    out = ""
    if parts:
        out += " (" + ", ".join(parts) + ")"
    for tag in tags:
        out += f" [{tag}]"
    return out


def get_commits(repo, opts):
    fmt = "%x1e%H%x1f%h%x1f%P%x1f%p%x1f%s%x1f%b%x1f%B%x1f%an%x1f%ae%x1f%ad%x1f%as%x1f%cn%x1f%ce%x1f%cd%x1f%cs"
    args = ["log", "--topo-order", f"--format={fmt}"]
    if opts["max_count"]:
        args.insert(1, f"-n{opts['max_count']}")
    if opts["reverse"]:
        args.insert(1, "--reverse")
    out = git(repo, args)
    commits = []
    for rec in out.split("\x1e"):
        rec = rec.strip("\n")
        if not rec:
            continue
        fields = rec.split("\x1f")
        while len(fields) < 15:
            fields.append("")
        keys = ["H", "h", "P", "p", "s", "b", "B", "an", "ae", "ad", "as", "cn", "ce", "cd", "cs"]
        item = dict(zip(keys, fields[:15]))
        item["parents"] = item["P"].split() if item["P"] else []
        commits.append(item)
    normalize_parent_order(commits)
    return commits


def normalize_parent_order(commits):
    by_sha = {c["H"]: i for i, c in enumerate(commits)}
    i = 0
    while i < len(commits):
        parents = commits[i]["parents"]
        if len(parents) > 1:
            wanted = [p for p in parents if p in by_sha]
            positions = [by_sha[p] for p in wanted]
            if positions:
                block = sorted(positions)
                if max(block) - min(block) + 1 == len(block):
                    start = min(block)
                    ordered = [commits[by_sha[p]] for p in wanted]
                    other = [commits[j] for j in block if commits[j]["H"] not in wanted]
                    commits[start : start + len(block)] = ordered + other
                    by_sha.update({c["H"]: j for j, c in enumerate(commits)})
        i += 1


def render_format(commit, fmt, refs, current):
    name = fmt
    if name in ("o", "oneline"):
        return f"{commit['h']}{decorate(commit['H'], refs, current)} {commit['s']}"
    if name in ("s", "short"):
        return (
            f"commit {commit['H']}{decorate(commit['H'], refs, current)}\n"
            f"Author: {commit['an']} <{commit['ae']}>\n\n"
            f"    {commit['s']}\n"
        )
    if name in ("m", "medium"):
        return (
            f"commit {commit['H']}{decorate(commit['H'], refs, current)}\n"
            f"Author: {commit['an']} <{commit['ae']}>\n"
            f"Date:   {commit['ad']}\n\n"
            f"    {commit['s']}\n"
        )
    if name in ("f", "full"):
        return (
            f"commit {commit['H']}{decorate(commit['H'], refs, current)}\n"
            f"Author: {commit['an']} <{commit['ae']}>\n"
            f"Commit: {commit['cn']} <{commit['ce']}>\n"
            f"Date:   {commit['ad']}\n\n"
            f"    {commit['s']}\n"
        )
    return expand_custom(commit, fmt, refs, current)


def expand_custom(commit, fmt, refs, current):
    values = {
        "n": "\n",
        "H": commit["H"],
        "h": commit["h"],
        "P": commit["P"],
        "p": commit["p"],
        "d": decorate(commit["H"], refs, current),
        "s": commit["s"],
        "b": commit["b"],
        "B": commit["B"],
        "an": commit["an"],
        "ae": commit["ae"],
        "ad": commit["ad"],
        "as": commit["as"],
        "cn": commit["cn"],
        "ce": commit["ce"],
        "cd": commit["cd"],
        "cs": commit["cs"],
    }
    out = ""
    i = 0
    while i < len(fmt):
        if fmt[i] != "%":
            out += fmt[i]
            i += 1
            continue
        i += 1
        modifier = ""
        if i < len(fmt) and fmt[i] in ("+", "-", " "):
            modifier = fmt[i]
            i += 1
        key = None
        for size in (2, 1):
            cand = fmt[i : i + size]
            if cand in values:
                key = cand
                i += size
                break
        if key is None:
            out += "%"
            continue
        val = values[key]
        if modifier == "+" and val:
            out += "\n"
        elif modifier == " " and val:
            out += " "
        elif modifier == "-" and not val:
            out = out.rstrip("\n")
        out += val
    return out


def chars(style):
    if style == "ascii":
        return {"dot": "*", "merge": "o", "v": "|", "join": "|-'", "top": "o<.", "tee": "| *"}
    return {"dot": "●", "merge": "○", "v": "│", "join": "├─┘", "top": "○<┐", "tee": "│ ●"}


def prefix_text(prefix, text, cont):
    raw_lines = text.splitlines()
    if text.endswith("\n"):
        raw_lines.append("")
    if not raw_lines:
        raw_lines = [""]
    out = [prefix + raw_lines[0]]
    for line in raw_lines[1:]:
        out.append(cont + line)
    return out


def svg(commits):
    h = max(30, len(commits) * 15 + 30)
    out = [f'<svg height="{h}" viewBox="0 0 45 {h}" width="45" xmlns="http://www.w3.org/2000/svg">']
    for i, _ in enumerate(commits):
        y = 15 + i * 15
        if i:
            out.append(f'<line stroke="blue" stroke-width="1" x1="15" x2="15" y1="{y-15}" y2="{y}"/>')
        out.append(f'<circle cx="15" cy="{y}" fill="blue" r="4" stroke="blue" stroke-width="1"/>')
    out.append("</svg>")
    return "\n".join(out) + "\n"


def graph(repo, opts):
    refs, current = get_ref_map(repo)
    commits = get_commits(repo, opts)
    if opts["svg"]:
        return svg(commits)
    ch = chars(opts["style"])
    merge_side = None
    merge_open = False
    just_joined = False
    lines = []
    for idx, commit in enumerate(commits):
        text = render_format(commit, opts["format"], refs, current)
        is_merge = len(commit["parents"]) > 1
        if is_merge and not opts["reverse"]:
            merge_side = commit["parents"][1]
            merge_open = True
            just_joined = False
            if opts["sparse"]:
                lines.extend(prefix_text(f" {ch['merge']}    ", text, f" {ch['v']}    "))
                lines.append(" ├<┐  " if opts["style"] != "ascii" else " |<.  ")
            else:
                lines.extend(prefix_text(f" {ch['top']}  ", text, f" {ch['v']} {ch['v']}  "))
        elif merge_open and commit["H"] == merge_side:
            lines.extend(prefix_text(f" {ch['tee']}  ", text, f" {ch['v']} {ch['v']}  "))
            lines.append(f" {ch['join']}  ")
            merge_open = False
            merge_side = None
            just_joined = True
        elif merge_open:
            lines.extend(prefix_text(f" {ch['dot']} {ch['v']}  ", text, f" {ch['v']} {ch['v']}  "))
            just_joined = False
        else:
            suffix_spaces = "    " if just_joined else "  "
            lines.extend(prefix_text(f" {ch['dot']}{suffix_spaces}", text, "    "))
            just_joined = False
    return "\n".join(lines) + ("\n" if lines else "")


def main(argv):
    path, rest = parse_global_args(argv)
    if rest and rest[0] in ("--help", "-h", "help"):
        sys.stdout.write(HELP)
        return 0
    if rest and rest[0] in ("--version", "-V"):
        sys.stdout.write(VERSION + "\n")
        return 0
    if len(rest) >= 2 and rest[0] == "model" and rest[1] in ("--list", "-l"):
        sys.stdout.write("\n".join(MODELS) + "\n")
        return 0
    if find_repo(path) is None:
        sys.stderr.write(
            f"ERROR: could not find repository at '{path}'\n"
            "       Navigate into a repository before running git-graph, or use option --path\n"
        )
        return 1
    repo = find_repo(path)
    if rest and rest[0] == "model":
        if len(rest) == 1:
            model = get_model(repo)
            sys.stdout.write(model if model else "No branching model set")
            return 0
        model = rest[1]
        if model not in MODELS:
            sys.stderr.write(
                f"ERROR: No branching model named '{model}' found in /home/agent/.config/git-graph/models\n"
                "       Available models are: git-flow, simple, none\n"
            )
            return 1
        set_model(repo, model)
        sys.stdout.write(f"Branching model set to '{model}'\n")
        return 0
    opts, _ = parse_options(rest)
    sys.stdout.write(graph(repo, opts))
    return 0


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
