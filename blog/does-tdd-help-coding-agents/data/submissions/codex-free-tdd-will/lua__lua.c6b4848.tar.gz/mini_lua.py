#!/usr/bin/env python3
import math
import os
import re
import sys


VERSION = "Lua 5.5.1  Copyright (C) 1994-2026 Lua.org, PUC-Rio"
LUA_VERSION = "Lua 5.5"


class LuaError(Exception):
    pass


class ReturnSignal(Exception):
    def __init__(self, values):
        self.values = values


class BreakSignal(Exception):
    pass


class LuaTable:
    def __init__(self, init=None):
        self.array = []
        self.map = {}
        if init:
            for k, v in init:
                self.set(k, v)

    def get(self, key):
        if isinstance(key, float) and key.is_integer():
            key = int(key)
        if isinstance(key, int) and key >= 1:
            return self.array[key - 1] if key <= len(self.array) else None
        return self.map.get(key)

    def set(self, key, value):
        if isinstance(key, float) and key.is_integer():
            key = int(key)
        if isinstance(key, int) and key >= 1:
            while len(self.array) < key:
                self.array.append(None)
            self.array[key - 1] = value
        else:
            if value is None:
                self.map.pop(key, None)
            else:
                self.map[key] = value

    def length(self):
        n = 0
        for v in self.array:
            if v is None:
                break
            n += 1
        return n

    def items(self):
        for i, v in enumerate(self.array, 1):
            if v is not None:
                yield i, v
        for k, v in self.map.items():
            yield k, v


def lua_truth(v):
    return not (v is None or v is False)


def lua_tostring(v):
    if v is None:
        return "nil"
    if v is True:
        return "true"
    if v is False:
        return "false"
    if isinstance(v, bool):
        return "true" if v else "false"
    if isinstance(v, int):
        return str(v)
    if isinstance(v, float):
        return str(v)
    if isinstance(v, str):
        return v
    if isinstance(v, LuaTable):
        return "table: 0x%x" % (id(v) & 0xFFFFFFFF)
    if callable(v):
        return "function: 0x%x" % (id(v) & 0xFFFFFFFF)
    return str(v)


def lua_type(v):
    if v is None:
        return "nil"
    if isinstance(v, bool):
        return "boolean"
    if isinstance(v, (int, float)):
        return "number"
    if isinstance(v, str):
        return "string"
    if isinstance(v, LuaTable):
        return "table"
    if callable(v):
        return "function"
    return "userdata"


TOKEN_RE = re.compile(
    r"""\s*(?:
    (?P<number>(?:0[xX][0-9a-fA-F]+)|(?:\d+(?:\.\d*)?|\.\d+)(?:[eE][+-]?\d+)?)|
    (?P<string>'(?:\\.|[^'\\])*'|"(?:\\.|[^"\\])*")|
    (?P<id>[A-Za-z_][A-Za-z0-9_]*)|
    (?P<op>\.\.\.|\.\.|==|~=|<=|>=|//|[+\-*/%^#=<>()[\]{},.;:])|
    (?P<misc>.)
    )""",
    re.VERBOSE | re.DOTALL,
)


KEYWORDS = {
    "and", "break", "do", "else", "elseif", "end", "false", "for", "function",
    "if", "in", "local", "nil", "not", "or", "repeat", "return", "then",
    "true", "until", "while",
}


def strip_comments(src):
    src = re.sub(r"--\[(=*)\[.*?\]\1\]", "", src, flags=re.DOTALL)
    return re.sub(r"--[^\n]*", "", src)


def tokenize(src):
    out = []
    pos = 0
    src = strip_comments(src)
    while pos < len(src):
        m = TOKEN_RE.match(src, pos)
        if not m:
            raise LuaError("syntax error")
        pos = m.end()
        if m.group("number"):
            text = m.group("number")
            if text.lower().startswith("0x"):
                val = int(text, 16)
            elif any(c in text for c in ".eE"):
                val = float(text)
            else:
                val = int(text)
            out.append(("num", val))
        elif m.group("string"):
            out.append(("str", bytes(m.group("string")[1:-1], "utf-8").decode("unicode_escape")))
        elif m.group("id"):
            text = m.group("id")
            out.append((text if text in KEYWORDS else "id", text))
        elif m.group("op"):
            out.append((m.group("op"), m.group("op")))
        elif m.group("misc") and not m.group("misc").isspace():
            raise LuaError("unexpected symbol near '%s'" % m.group("misc"))
    out.append(("eof", "eof"))
    return out


class Env:
    def __init__(self, parent=None):
        self.parent = parent
        self.vars = {}

    def get(self, name):
        if name in self.vars:
            return self.vars[name]
        if self.parent:
            return self.parent.get(name)
        return None

    def set_local(self, name, value):
        self.vars[name] = value

    def set(self, name, value):
        if name in self.vars or not self.parent:
            self.vars[name] = value
        else:
            self.parent.set(name, value)


class Function:
    def __init__(self, params, body, closure):
        self.params = params
        self.body = body
        self.closure = closure

    def __call__(self, *args):
        env = Env(self.closure)
        vararg = []
        ai = 0
        for p in self.params:
            if p == "...":
                vararg = list(args[ai:])
            else:
                env.set_local(p, args[ai] if ai < len(args) else None)
                ai += 1
        env.set_local("...", vararg)
        try:
            exec_block(self.body, env)
        except ReturnSignal as r:
            return r.values[0] if len(r.values) == 1 else tuple(r.values)
        return None


class Parser:
    def __init__(self, tokens):
        self.toks = tokens
        self.i = 0

    def peek(self, k=0):
        return self.toks[self.i + k][0]

    def val(self, k=0):
        return self.toks[self.i + k][1]

    def accept(self, typ):
        if self.peek() == typ:
            v = self.val()
            self.i += 1
            return v
        return None

    def expect(self, typ):
        v = self.accept(typ)
        if v is None:
            raise LuaError("syntax error near '%s'" % self.val())
        return v

    def parse(self, stops=("eof",)):
        body = []
        while self.peek() not in stops:
            if self.accept(";") is not None:
                continue
            body.append(self.statement())
        return body

    def statement(self):
        if self.accept("local") is not None:
            if self.accept("function") is not None:
                name = self.expect("id")
                params, body = self.function_tail()
                return ("local", [name], [("function", params, body)])
            names = [self.expect("id")]
            while self.accept(",") is not None:
                names.append(self.expect("id"))
            vals = self.expr_list() if self.accept("=") is not None else []
            return ("local", names, vals)
        if self.accept("function") is not None:
            target = ("var", self.expect("id"))
            while self.accept(".") is not None:
                target = ("index", target, ("str", self.expect("id")))
            method_def = False
            if self.accept(":") is not None:
                target = ("index", target, ("str", self.expect("id")))
                method_def = True
            params, body = self.function_tail()
            if method_def:
                params = ["self"] + params
            return ("assign", [target], [("function", params, body)])
        if self.accept("return") is not None:
            vals = [] if self.peek() in ("end", "else", "elseif", "until", "eof") else self.expr_list()
            return ("return", vals)
        if self.accept("break") is not None:
            return ("break",)
        if self.accept("if") is not None:
            branches = []
            cond = self.expr()
            self.expect("then")
            branches.append((cond, self.parse(("elseif", "else", "end"))))
            while self.accept("elseif") is not None:
                cond = self.expr()
                self.expect("then")
                branches.append((cond, self.parse(("elseif", "else", "end"))))
            else_body = None
            if self.accept("else") is not None:
                else_body = self.parse(("end",))
            self.expect("end")
            return ("if", branches, else_body)
        if self.accept("do") is not None:
            body = self.parse(("end",))
            self.expect("end")
            return ("do", body)
        if self.accept("while") is not None:
            cond = self.expr()
            self.expect("do")
            body = self.parse(("end",))
            self.expect("end")
            return ("while", cond, body)
        if self.accept("repeat") is not None:
            body = self.parse(("until",))
            self.expect("until")
            cond = self.expr()
            return ("repeat", body, cond)
        if self.accept("for") is not None:
            names = [self.expect("id")]
            if self.accept("=") is not None:
                start = self.expr(); self.expect(","); stop = self.expr()
                step = self.expr() if self.accept(",") is not None else ("num", 1)
                self.expect("do")
                body = self.parse(("end",)); self.expect("end")
                return ("fornum", names[0], start, stop, step, body)
            while self.accept(",") is not None:
                names.append(self.expect("id"))
            self.expect("in")
            it = self.expr_list()
            self.expect("do")
            body = self.parse(("end",)); self.expect("end")
            return ("forin", names, it, body)
        first = self.prefix()
        if self.peek() in ("=", ","):
            targets = [first]
            while self.accept(",") is not None:
                targets.append(self.var())
            self.expect("=")
            return ("assign", targets, self.expr_list())
        return ("expr", first)

    def function_tail(self):
        self.expect("(")
        params = []
        if self.peek() != ")":
            if self.accept("...") is not None:
                params.append("...")
            else:
                params.append(self.expect("id"))
                while self.accept(",") is not None:
                    if self.accept("...") is not None:
                        params.append("...")
                        break
                    params.append(self.expect("id"))
        self.expect(")")
        body = self.parse(("end",))
        self.expect("end")
        return params, body

    def expr_list(self):
        vals = [self.expr()]
        while self.accept(",") is not None:
            vals.append(self.expr())
        return vals

    def var(self):
        node = ("var", self.expect("id"))
        return self.suffix(node)

    def prefix(self):
        if self.peek() == "id":
            node = ("var", self.expect("id"))
            return self.suffix(node)
        if self.accept("(") is not None:
            node = self.expr()
            self.expect(")")
            return self.suffix(node)
        raise LuaError("syntax error")

    def suffix(self, node):
        while True:
            if self.accept(".") is not None:
                node = ("index", node, ("str", self.expect("id")))
            elif self.accept("[") is not None:
                idx = self.expr(); self.expect("]")
                node = ("index", node, idx)
            elif self.accept(":") is not None:
                method = self.expect("id")
                args = self.args()
                node = ("methodcall", node, method, args)
            elif self.peek() in ("(", "str", "{"):
                args = self.args()
                node = ("call", node, args)
            else:
                return node

    def args(self):
        if self.accept("(") is not None:
            args = [] if self.peek() == ")" else self.expr_list()
            self.expect(")")
            return args
        if self.peek() == "str":
            return [("str", self.expect("str"))]
        if self.peek() == "{":
            return [self.table()]
        raise LuaError("function arguments expected")

    def expr(self, minp=0):
        node = self.unary()
        prec = {
            "or": 1, "and": 2, "==": 3, "~=": 3, "<": 3, "<=": 3, ">": 3, ">=": 3,
            "..": 4, "+": 5, "-": 5, "*": 6, "/": 6, "//": 6, "%": 6, "^": 8,
        }
        right_assoc = {"^", ".."}
        while self.peek() in prec and prec[self.peek()] >= minp:
            op = self.peek(); p = prec[op]; self.i += 1
            rhs = self.expr(p if op in right_assoc else p + 1)
            node = ("bin", op, node, rhs)
        return node

    def unary(self):
        if self.peek() in ("not", "-", "#"):
            op = self.peek(); self.i += 1
            return ("un", op, self.unary())
        return self.primary()

    def primary(self):
        if self.peek() == "num":
            return ("num", self.expect("num"))
        if self.peek() == "str":
            return ("str", self.expect("str"))
        if self.accept("nil") is not None:
            return ("nil",)
        if self.accept("...") is not None:
            return ("vararg",)
        if self.accept("true") is not None:
            return ("bool", True)
        if self.accept("false") is not None:
            return ("bool", False)
        if self.accept("function") is not None:
            params, body = self.function_tail()
            return ("function", params, body)
        if self.peek() == "{":
            return self.table()
        return self.prefix()

    def table(self):
        self.expect("{")
        fields = []
        array_i = 1
        while self.peek() != "}":
            if self.accept("[") is not None:
                k = self.expr(); self.expect("]"); self.expect("="); v = self.expr()
                fields.append((k, v))
            elif self.peek() == "id" and self.peek(1) == "=":
                k = ("str", self.expect("id")); self.expect("="); v = self.expr()
                fields.append((k, v))
            else:
                fields.append((("num", array_i), self.expr()))
                array_i += 1
            if self.peek() in (",", ";"):
                self.i += 1
            else:
                break
        self.expect("}")
        return ("table", fields)


def eval_expr(node, env):
    kind = node[0]
    if kind in ("num", "str"):
        return node[1]
    if kind == "bool":
        return node[1]
    if kind == "nil":
        return None
    if kind == "var":
        return env.get(node[1])
    if kind == "vararg":
        return tuple(env.get("...") or [])
    if kind == "index":
        t = eval_expr(node[1], env); k = eval_expr(node[2], env)
        if isinstance(t, LuaTable):
            return t.get(k)
        if isinstance(t, str) and isinstance(k, str):
            lib = env.get("string")
            return lib.get(k) if isinstance(lib, LuaTable) else None
        return None
    if kind == "table":
        t = LuaTable()
        for k, v in node[1]:
            t.set(eval_expr(k, env), eval_expr(v, env))
        return t
    if kind == "function":
        return Function(node[1], node[2], env)
    if kind == "un":
        v = eval_expr(node[2], env)
        if node[1] == "not":
            return not lua_truth(v)
        if node[1] == "-":
            return -v
        if node[1] == "#":
            return len(v) if isinstance(v, str) else v.length() if isinstance(v, LuaTable) else 0
    if kind == "bin":
        op = node[1]
        if op == "and":
            a = eval_expr(node[2], env)
            return eval_expr(node[3], env) if lua_truth(a) else a
        if op == "or":
            a = eval_expr(node[2], env)
            return a if lua_truth(a) else eval_expr(node[3], env)
        a = eval_expr(node[2], env); b = eval_expr(node[3], env)
        if op == "+": return a + b
        if op == "-": return a - b
        if op == "*": return a * b
        if op == "/": return a / b
        if op == "//": return math.floor(a / b)
        if op == "%": return a % b
        if op == "^": return a ** b
        if op == "..": return lua_tostring(a) + lua_tostring(b)
        if op == "==": return a == b
        if op == "~=": return a != b
        if op == "<": return a < b
        if op == "<=": return a <= b
        if op == ">": return a > b
        if op == ">=": return a >= b
    if kind == "call":
        fn = eval_expr(node[1], env)
        args = eval_call_args(node[2], env)
        if callable(fn):
            return fn(*args)
        raise LuaError("attempt to call a nil value")
    if kind == "methodcall":
        obj = eval_expr(node[1], env)
        fn = None
        if isinstance(obj, LuaTable):
            fn = obj.get(node[2])
        elif isinstance(obj, str):
            lib = env.get("string")
            fn = lib.get(node[2]) if isinstance(lib, LuaTable) else None
        args = [obj] + eval_call_args(node[3], env)
        if callable(fn):
            return fn(*args)
        raise LuaError("attempt to call a nil value")
    raise LuaError("bad expression")


def assign_target(target, value, env, local=False):
    if target[0] == "var":
        (env.set_local if local else env.set)(target[1], value)
    elif target[0] == "index":
        t = eval_expr(target[1], env)
        k = eval_expr(target[2], env)
        if not isinstance(t, LuaTable):
            raise LuaError("attempt to index a nil value")
        t.set(k, value)


def eval_values(exprs, env):
    vals = []
    for e in exprs:
        v = eval_expr(e, env)
        if isinstance(v, tuple):
            vals.extend(v)
        else:
            vals.append(v)
    return vals


def eval_call_args(exprs, env):
    args = []
    for e in exprs:
        v = eval_expr(e, env)
        if isinstance(v, tuple):
            args.extend(v)
        else:
            args.append(v)
    return args


def exec_block(body, env):
    for st in body:
        kind = st[0]
        if kind == "expr":
            eval_expr(st[1], env)
        elif kind == "assign":
            vals = eval_values(st[2], env)
            for i, target in enumerate(st[1]):
                assign_target(target, vals[i] if i < len(vals) else None, env)
        elif kind == "local":
            vals = eval_values(st[2], env)
            for i, name in enumerate(st[1]):
                env.set_local(name, vals[i] if i < len(vals) else None)
        elif kind == "return":
            raise ReturnSignal(eval_values(st[1], env))
        elif kind == "break":
            raise BreakSignal()
        elif kind == "if":
            done = False
            for cond, block in st[1]:
                if lua_truth(eval_expr(cond, env)):
                    exec_block(block, Env(env)); done = True; break
            if not done and st[2] is not None:
                exec_block(st[2], Env(env))
        elif kind == "do":
            exec_block(st[1], Env(env))
        elif kind == "while":
            while lua_truth(eval_expr(st[1], env)):
                try:
                    exec_block(st[2], Env(env))
                except BreakSignal:
                    break
        elif kind == "repeat":
            while True:
                try:
                    exec_block(st[1], Env(env))
                except BreakSignal:
                    break
                if lua_truth(eval_expr(st[2], env)):
                    break
        elif kind == "fornum":
            name, start, stop, step, block = st[1:]
            i = eval_expr(start, env); end = eval_expr(stop, env); inc = eval_expr(step, env)
            loop_env = Env(env)
            while (i <= end if inc >= 0 else i >= end):
                loop_env.set_local(name, i)
                try:
                    exec_block(block, loop_env)
                except BreakSignal:
                    break
                i += inc
        elif kind == "forin":
            vals = eval_values(st[2], env)
            iterable = vals[0] if vals else []
            if callable(iterable):
                iterable = iterable()
            for row in iterable:
                if not isinstance(row, tuple):
                    row = (row,)
                loop_env = Env(env)
                for i, name in enumerate(st[1]):
                    loop_env.set_local(name, row[i] if i < len(row) else None)
                try:
                    exec_block(st[3], loop_env)
                except BreakSignal:
                    break


def std_env(argv=None):
    env = Env()

    def l_print(*args):
        print("\t".join(lua_tostring(a) for a in args))

    def l_tonumber(x=None, base=None):
        if x is None:
            return None
        try:
            if base is not None:
                return int(str(x), int(base))
            s = str(x).strip()
            return float(s) if any(c in s for c in ".eE") else int(s)
        except Exception:
            return None

    def l_select(idx, *args):
        if idx == "#":
            return len(args)
        return tuple(args[int(idx) - 1:])

    env.set_local("_VERSION", LUA_VERSION)
    env.set_local("print", l_print)
    env.set_local("tostring", lua_tostring)
    env.set_local("tonumber", l_tonumber)
    env.set_local("type", lua_type)
    env.set_local("assert", lambda v, msg=None: v if lua_truth(v) else (_ for _ in ()).throw(LuaError(lua_tostring(msg or "assertion failed!"))))
    env.set_local("error", lambda msg="": (_ for _ in ()).throw(LuaError(lua_tostring(msg))))
    env.set_local("select", l_select)
    env.set_local("pairs", lambda t: (lambda: list(t.items()) if isinstance(t, LuaTable) else []))
    def l_ipairs(t):
        def gen():
            if not isinstance(t, LuaTable):
                return []
            rows = []
            for i, v in enumerate(t.array, 1):
                if v is None:
                    break
                rows.append((i, v))
            return rows
        return gen
    env.set_local("ipairs", l_ipairs)
    env.set_local("next", lambda t, k=None: next(iter(t.items()), (None,))[0] if isinstance(t, LuaTable) else None)
    env.set_local("arg", LuaTable([(i, v) for i, v in enumerate(argv or [], 0)]))

    math_t = LuaTable()
    math_t.set("abs", abs)
    math_t.set("max", lambda *xs: max(xs))
    math_t.set("min", lambda *xs: min(xs))
    for name in ("acos", "asin", "atan", "ceil", "cos", "exp", "floor", "log", "sin", "sqrt", "tan"):
        math_t.set(name, getattr(math, name))
    math_t.set("deg", math.degrees)
    math_t.set("rad", math.radians)
    math_t.set("pi", math.pi)
    math_t.set("huge", math.inf)
    env.set_local("math", math_t)

    string_t = LuaTable()
    string_t.set("len", lambda s: len(str(s)))
    string_t.set("lower", lambda s: str(s).lower())
    string_t.set("upper", lambda s: str(s).upper())
    string_t.set("rep", lambda s, n, sep="": str(sep).join([str(s)] * int(n)))
    string_t.set("sub", lambda s, i, j=None: str(s)[int(i)-1:(int(j) if j is not None and int(j) >= 0 else None)])
    string_t.set("reverse", lambda s: str(s)[::-1])
    string_t.set("format", lambda fmt, *args: fmt % args)
    string_t.set("byte", lambda s, i=1: ord(str(s)[int(i)-1]))
    string_t.set("char", lambda *xs: "".join(chr(int(x)) for x in xs))
    string_t.set("find", lambda s, pat, init=1, plain=None: (
        (lambda p: None if p < 0 else (p + 1, p + len(str(pat))))(str(s).find(str(pat), int(init)-1))
    ))
    env.set_local("string", string_t)

    table_t = LuaTable()
    def table_insert(t, a, b=None):
        if b is None:
            t.array.append(a)
        else:
            t.array.insert(int(a) - 1, b)
    def table_remove(t, pos=None):
        if not t.array:
            return None
        idx = int(pos) - 1 if pos is not None else len(t.array) - 1
        return t.array.pop(idx)
    table_t.set("insert", table_insert)
    table_t.set("remove", table_remove)
    table_t.set("concat", lambda t, sep="", i=1, j=None: str(sep).join(lua_tostring(x) for x in t.array[int(i)-1:(int(j) if j else None)]))
    table_t.set("sort", lambda t: t.array.sort())
    env.set_local("table", table_t)

    io_t = LuaTable()
    io_t.set("write", lambda *args: (sys.stdout.write("".join(lua_tostring(a) for a in args)), None)[1])
    io_t.set("read", lambda *args: sys.stdin.readline().rstrip("\n"))
    env.set_local("io", io_t)

    os_t = LuaTable()
    os_t.set("exit", lambda code=0: sys.exit(int(code) if code is not True else 0))
    os_t.set("getenv", lambda name: os.environ.get(str(name)))
    env.set_local("os", os_t)
    env.set_local("require", lambda mod: env.get(mod) or True)
    return env


def run_source(src, argv=None, env=None):
    env = env or std_env(argv)
    body = Parser(tokenize(src)).parse()
    exec_block(body, env)
    return env


def usage(prog):
    return """usage: %s [options] [script [args]]
Available options are:
  -e stat   execute string 'stat'
  -i        enter interactive mode after executing 'script'
  -l mod    require library 'mod' into global 'mod'
  -l g=mod  require library 'mod' into global 'g'
  -v        show version information
  -E        ignore environment variables
  -W        turn warnings on
  --        stop handling options
  -         stop handling options and execute stdin""" % prog


def main(argv):
    args = argv[1:]
    chunks = []
    loads = []
    interactive = False
    script = None
    script_args = []
    i = 0
    while i < len(args):
        a = args[i]
        if a == "-v":
            print(VERSION)
        elif a == "-e":
            i += 1
            if i >= len(args):
                print("%s: '-e' needs argument" % argv[0], file=sys.stderr)
                return 1
            chunks.append(args[i])
        elif a.startswith("-e") and len(a) > 2:
            chunks.append(a[2:])
        elif a == "-l":
            i += 1
            if i >= len(args):
                print("%s: '-l' needs argument" % argv[0], file=sys.stderr)
                return 1
            loads.append(args[i])
        elif a.startswith("-l") and len(a) > 2:
            loads.append(a[2:])
        elif a == "-i":
            interactive = True
        elif a == "-E" or a == "-W":
            pass
        elif a == "--":
            if i + 1 < len(args):
                script = args[i + 1]
                script_args = args[i + 2:]
            break
        elif a == "-":
            chunks.append(sys.stdin.read())
            script_args = args[i + 1:]
            break
        elif a.startswith("-"):
            print("%s: unrecognized option '%s'" % (argv[0], a), file=sys.stderr)
            print(usage(argv[0]), file=sys.stderr)
            return 1
        else:
            script = a
            script_args = args[i + 1:]
            break
        i += 1
    try:
        env = std_env([script or argv[0]] + script_args)
        for spec in loads:
            if "=" in spec:
                name, mod = spec.split("=", 1)
            else:
                name = mod = spec
            env.set(name, env.get(mod) or True)
        for chunk in chunks:
            run_source(chunk, script_args, env)
        if script:
            with open(script, "r", encoding="utf-8") as f:
                run_source(f.read(), script_args, env)
        elif not chunks and not sys.stdin.isatty():
            run_source(sys.stdin.read(), [], env)
        elif interactive:
            pass
        return 0
    except SystemExit as e:
        return int(e.code or 0)
    except Exception as e:
        print("%s: %s" % (argv[0], e), file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main(sys.argv))
