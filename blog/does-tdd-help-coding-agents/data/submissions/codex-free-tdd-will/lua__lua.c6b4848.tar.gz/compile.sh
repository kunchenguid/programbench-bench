#!/bin/bash
set -e
rm -f executable
cp mini_lua.py executable
chmod +x executable
