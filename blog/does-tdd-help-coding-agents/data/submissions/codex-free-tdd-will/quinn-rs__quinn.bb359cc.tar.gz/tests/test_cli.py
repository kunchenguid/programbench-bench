#!/usr/bin/env python3
import os
import socket
import subprocess
import sys
import tempfile
import time


ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
EXE = os.path.join(ROOT, "executable")


def run(*args, timeout=5):
    return subprocess.run(
        [EXE, *args],
        cwd=ROOT,
        text=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        timeout=timeout,
    )


def assert_contains(haystack, needle):
    if needle not in haystack:
        raise AssertionError(f"expected {needle!r} in:\n{haystack}")


def free_port():
    sock = socket.socket()
    sock.bind(("127.0.0.1", 0))
    port = sock.getsockname()[1]
    sock.close()
    return port


def test_top_level_help():
    proc = run("--help")
    assert proc.returncode == 0
    assert_contains(proc.stdout, "Usage: executable <COMMAND>")
    assert_contains(proc.stdout, "server  Run as a perf server")
    assert_contains(proc.stdout, "client  Run as a perf client")


def test_subcommand_help_lists_perf_options():
    server = run("server", "--help")
    assert server.returncode == 0
    assert_contains(server.stdout, "Run as a perf server")
    assert_contains(server.stdout, "--listen <LISTEN>")
    assert_contains(server.stdout, "--congestion <CONG_ALG>")

    client = run("client", "--help")
    assert client.returncode == 0
    assert_contains(client.stdout, "Run as a perf client")
    assert_contains(client.stdout, "--download-size <DOWNLOAD_SIZE>")
    assert_contains(client.stdout, "--json <JSON>")


def test_rejects_invalid_command_and_size_suffix():
    bad_command = run("bogus")
    assert bad_command.returncode == 2
    assert_contains(bad_command.stderr, "error: unrecognized subcommand 'bogus'")

    bad_size = run("client", "--download-size", "1K", timeout=1)
    assert bad_size.returncode == 2
    assert_contains(bad_size.stderr, "invalid value '1K' for '--download-size <DOWNLOAD_SIZE>'")


def test_client_and_server_exchange_and_write_json():
    port = free_port()
    json_path = tempfile.mktemp(prefix="qperf-", suffix=".json")
    server = subprocess.Popen(
        [EXE, "server", "--listen", f"127.0.0.1:{port}"],
        cwd=ROOT,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        text=True,
    )
    try:
        time.sleep(0.2)
        proc = run(
            "client",
            f"127.0.0.1:{port}",
            "--duration",
            "0",
            "--download-size",
            "64",
            "--upload-size",
            "32",
            "--json",
            json_path,
        )
        assert proc.returncode == 0, proc.stderr
        assert_contains(proc.stdout, "Overall stats:")
        assert_contains(proc.stdout, "RPS:")
        with open(json_path, "r", encoding="utf-8") as handle:
            data = handle.read()
        assert_contains(data, '"intervals"')
        assert_contains(data, '"bits_per_second"')
    finally:
        server.terminate()
        try:
            server.wait(timeout=2)
        except subprocess.TimeoutExpired:
            server.kill()
        if os.path.exists(json_path):
            os.unlink(json_path)


TESTS = [
    test_top_level_help,
    test_subcommand_help_lists_perf_options,
    test_rejects_invalid_command_and_size_suffix,
    test_client_and_server_exchange_and_write_json,
]


if __name__ == "__main__":
    failures = 0
    for test in TESTS:
        try:
            test()
        except Exception as exc:
            failures += 1
            print(f"FAIL {test.__name__}: {exc}", file=sys.stderr)
        else:
            print(f"ok {test.__name__}")
    raise SystemExit(1 if failures else 0)
