#!/bin/bash
set -e
cp src/quinn_perf.py executable
chmod +x executable
