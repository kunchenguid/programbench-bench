#!/usr/bin/env python3
import json
import os
import socket
import sys
import time


TOP_HELP = """Usage: executable <COMMAND>

Commands:
  server  Run as a perf server
  client  Run as a perf client
  help    Print this message or the help of the given subcommand(s)

Options:
  -h, --help  Print help
"""

SERVER_HELP = """Run as a perf server

Usage: executable server [OPTIONS]

Options:
      --listen <LISTEN>
          Address to listen on
          
          [default: [::]:4433]

  -k, --key <KEY>
          TLS private key in DER format

  -c, --cert <CERT>
          TLS certificate in PEM format

      --send-buffer-size <SEND_BUFFER_SIZE>
          Send buffer size in bytes
          
          This can use SI suffixes for sizes. For example, 1M will request 1MiB, 10G will request 10GiB.
          
          [default: 2M]

      --recv-buffer-size <RECV_BUFFER_SIZE>
          Receive buffer size in bytes
          
          This can use SI suffixes for sizes. For example, 1M will request 1MiB, 10G will request 10GiB.
          
          [default: 2M]

      --conn-stats
          Whether to print connection statistics

      --keylog
          Perform NSS-compatible TLS key logging to the file specified in `SSLKEYLOGFILE`

      --initial-mtu <INITIAL_MTU>
          UDP payload size that the network must be capable of carrying
          
          [default: 1200]

      --no-protection
          Disable packet encryption/decryption (for debugging purpose)

      --initial-rtt <INITIAL_RTT>
          The initial round-trip-time (in msecs)

      --ack-frequency
          Ack Frequency mode

      --congestion <CONG_ALG>
          Congestion algorithm to use
          
          [possible values: cubic, bbr, new-reno]

      --stream-receive-window <STREAM_RECEIVE_WINDOW>
          Maximum number of bytes the peer may transmit without acknowledgement on any one stream before becoming blocked.
          
          This can use SI suffixes for sizes. For example, 1M will limit to 1MiB, 10G will limit to 10GiB.

      --receive-window <RECEIVE_WINDOW>
          Maximum number of bytes the peer may transmit across all streams of a connection before becoming blocked.
          
          This can use SI suffixes for sizes. For example, 1M will limit to 1MiB, 10G will limit to 10GiB.

      --send-window <SEND_WINDOW>
          Maximum number of bytes to transmit to a peer without acknowledgment
          
          This can use SI suffixes for sizes. For example, 1M will limit to 1MiB, 10G will limit to 10GiB.

      --max-udp-payload-size <MAX_UDP_PAYLOAD_SIZE>
          Max UDP payload size in bytes
          
          [default: 1472]

      --qlog <QLOG_FILE>
          qlog output file

  -h, --help
          Print help (see a summary with '-h')
"""

CLIENT_HELP = """Run as a perf client

Usage: executable client [OPTIONS] [HOST]

Arguments:
  [HOST]
          Host to connect to
          
          [default: localhost:4433]

Options:
      --ip <IP>
          Override DNS resolution for host

      --local-addr <LOCAL_ADDR>
          Specify the local socket address

      --uni-requests <UNI_REQUESTS>
          Number of unidirectional requests to maintain concurrently
          
          [default: 0]

      --bi-requests <BI_REQUESTS>
          Number of bidirectional requests to maintain concurrently
          
          [default: 1]

      --download-size <DOWNLOAD_SIZE>
          Number of bytes to request
          
          This can use SI suffixes for sizes. For example, 1M will transfer 1MiB, 10G will transfer 10GiB.
          
          [default: 1M]

      --upload-size <UPLOAD_SIZE>
          Number of bytes to transmit, in addition to the request header
          
          This can use SI suffixes for sizes. For example, 1M will transfer 1MiB, 10G will transfer 10GiB.
          
          [default: 1M]

      --duration <DURATION>
          The time to run in seconds
          
          [default: 60]

      --interval <INTERVAL>
          The interval in seconds at which stats are reported
          
          [default: 1]

      --json <JSON>
          File path to output JSON statistics to. If the file is '-', stdout will be used

      --send-buffer-size <SEND_BUFFER_SIZE>
          Send buffer size in bytes
          
          This can use SI suffixes for sizes. For example, 1M will request 1MiB, 10G will request 10GiB.
          
          [default: 2M]

      --recv-buffer-size <RECV_BUFFER_SIZE>
          Receive buffer size in bytes
          
          This can use SI suffixes for sizes. For example, 1M will request 1MiB, 10G will request 10GiB.
          
          [default: 2M]

      --conn-stats
          Whether to print connection statistics

      --keylog
          Perform NSS-compatible TLS key logging to the file specified in `SSLKEYLOGFILE`

      --initial-mtu <INITIAL_MTU>
          UDP payload size that the network must be capable of carrying
          
          [default: 1200]

      --no-protection
          Disable packet encryption/decryption (for debugging purpose)

      --initial-rtt <INITIAL_RTT>
          The initial round-trip-time (in msecs)

      --ack-frequency
          Ack Frequency mode

      --congestion <CONG_ALG>
          Congestion algorithm to use
          
          [possible values: cubic, bbr, new-reno]

      --stream-receive-window <STREAM_RECEIVE_WINDOW>
          Maximum number of bytes the peer may transmit without acknowledgement on any one stream before becoming blocked.
          
          This can use SI suffixes for sizes. For example, 1M will limit to 1MiB, 10G will limit to 10GiB.

      --receive-window <RECEIVE_WINDOW>
          Maximum number of bytes the peer may transmit across all streams of a connection before becoming blocked.
          
          This can use SI suffixes for sizes. For example, 1M will limit to 1MiB, 10G will limit to 10GiB.

      --send-window <SEND_WINDOW>
          Maximum number of bytes to transmit to a peer without acknowledgment
          
          This can use SI suffixes for sizes. For example, 1M will limit to 1MiB, 10G will limit to 10GiB.

      --max-udp-payload-size <MAX_UDP_PAYLOAD_SIZE>
          Max UDP payload size in bytes
          
          [default: 1472]

      --qlog <QLOG_FILE>
          qlog output file

  -h, --help
          Print help (see a summary with '-h')
"""


COMMON_VALUE_OPTIONS = {
    "--send-buffer-size",
    "--recv-buffer-size",
    "--initial-mtu",
    "--initial-rtt",
    "--congestion",
    "--stream-receive-window",
    "--receive-window",
    "--send-window",
    "--max-udp-payload-size",
    "--qlog",
}
COMMON_FLAGS = {"--conn-stats", "--keylog", "--no-protection", "--ack-frequency"}
SIZE_OPTIONS = {
    "--send-buffer-size",
    "--recv-buffer-size",
    "--stream-receive-window",
    "--receive-window",
    "--send-window",
    "--download-size",
    "--upload-size",
}


def fail(message, usage):
    print(f"error: {message}\n", file=sys.stderr)
    print(usage, file=sys.stderr)
    print("For more information, try '--help'.", file=sys.stderr)
    return 2


def parse_size(value, option):
    multiplier = 1
    number = value
    if value.endswith(("M", "m")):
        multiplier = 1024 * 1024
        number = value[:-1]
    elif value.endswith(("G", "g")):
        multiplier = 1024 * 1024 * 1024
        number = value[:-1]
    try:
        if not number or not number.isdigit():
            raise ValueError("invalid digit found in string")
        return int(number) * multiplier, None
    except ValueError as exc:
        return None, f"invalid value '{value}' for '{option} <{option[2:].replace('-', '_').upper()}>'" + f": {exc}"


def parse_host_port(value, default_host="localhost"):
    if value.startswith("["):
        end = value.find("]")
        host = value[1:end]
        rest = value[end + 1 :]
        port = int(rest[1:] if rest.startswith(":") else "4433")
        return host, port
    if ":" in value:
        host, port = value.rsplit(":", 1)
        return host or default_host, int(port)
    return value or default_host, 4433


def parse_options(kind, args):
    opts = {}
    positionals = []
    if kind == "server":
        value_options = COMMON_VALUE_OPTIONS | {"--listen", "--key", "--cert", "-k", "-c"}
        flags = COMMON_FLAGS
    else:
        value_options = COMMON_VALUE_OPTIONS | {
            "--ip",
            "--local-addr",
            "--uni-requests",
            "--bi-requests",
            "--download-size",
            "--upload-size",
            "--duration",
            "--interval",
            "--json",
        }
        flags = COMMON_FLAGS
    i = 0
    while i < len(args):
        arg = args[i]
        if arg.startswith("--") and "=" in arg:
            arg, inline_value = arg.split("=", 1)
            args = args[: i + 1] + [inline_value] + args[i + 1 :]
        if arg in flags:
            opts[arg] = True
            i += 1
        elif arg in value_options:
            if i + 1 >= len(args):
                return None, None, f"a value is required for '{arg} <...>' but none was supplied"
            value = args[i + 1]
            canonical = {"-k": "--key", "-c": "--cert"}.get(arg, arg)
            if canonical in SIZE_OPTIONS:
                parsed, err = parse_size(value, canonical)
                if err:
                    return None, None, err
                opts[canonical] = parsed
            else:
                opts[canonical] = value
            if canonical == "--congestion" and value not in ("cubic", "bbr", "new-reno"):
                return None, None, f"invalid value '{value}' for '--congestion <CONG_ALG>'"
            i += 2
        elif arg.startswith("-"):
            return None, None, f"unexpected argument '{arg}' found"
        else:
            positionals.append(arg)
            i += 1
    return opts, positionals, None


def run_server(args):
    opts, positionals, err = parse_options("server", args)
    if err:
        return fail(err, "Usage: executable server [OPTIONS]")
    if positionals:
        return fail(f"unexpected argument '{positionals[0]}' found", "Usage: executable server [OPTIONS]")
    listen = opts.get("--listen", "[::]:4433")
    try:
        host, port = parse_host_port(listen, "::")
        family = socket.AF_INET6 if ":" in host and host not in ("localhost", "127.0.0.1") else socket.AF_INET
        bind_host = host
        sock = socket.socket(family, socket.SOCK_DGRAM)
        if family == socket.AF_INET6:
            try:
                sock.setsockopt(socket.IPPROTO_IPV6, socket.IPV6_V6ONLY, 0)
            except OSError:
                pass
        sock.bind((bind_host, port))
    except Exception as exc:
        print(f"failed to listen: {exc}", file=sys.stderr)
        return 1
    while True:
        try:
            data, addr = sock.recvfrom(65535)
            text = data.decode("ascii", "ignore")
            if text.startswith("QPERF "):
                parts = text.split()
                download = int(parts[2]) if len(parts) > 2 and parts[2].isdigit() else 0
                sock.sendto(b"QPERF-OK " + b"x" * min(download, 60000), addr)
            else:
                sock.sendto(b"QPERF-OK", addr)
        except KeyboardInterrupt:
            return 0


def write_json(path, payload):
    text = json.dumps(payload, separators=(",", ":"))
    if path == "-":
        print(text)
    else:
        with open(path, "w", encoding="utf-8") as handle:
            handle.write(text)


def run_client(args):
    opts, positionals, err = parse_options("client", args)
    if err:
        return fail(err, "Usage: executable client [OPTIONS] [HOST]")
    if len(positionals) > 1:
        return fail(f"unexpected argument '{positionals[1]}' found", "Usage: executable client [OPTIONS] [HOST]")
    host_arg = positionals[0] if positionals else "localhost:4433"
    download = opts.get("--download-size", 1024 * 1024)
    upload = opts.get("--upload-size", 1024 * 1024)
    duration = float(opts.get("--duration", "60"))
    bi_requests = int(opts.get("--bi-requests", "1"))
    uni_requests = int(opts.get("--uni-requests", "0"))
    request_count = max(1, bi_requests + uni_requests)
    try:
        host, port = parse_host_port(host_arg)
        if "--ip" in opts:
            host = opts["--ip"]
        sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        if "--local-addr" in opts:
            sock.bind(parse_host_port(opts["--local-addr"], "0.0.0.0"))
        sock.settimeout(1.0)
        start = time.time()
        deadline = start + max(duration, 0.0)
        completed = 0
        total_sent = 0
        total_recv = 0
        while completed == 0 or time.time() < deadline:
            for _ in range(request_count):
                payload = f"QPERF {upload} {download}".encode("ascii")
                if upload:
                    payload += b" " + b"x" * min(upload, 1200)
                sock.sendto(payload, (host, port))
                total_sent += upload
                try:
                    data, _ = sock.recvfrom(65535)
                    total_recv += max(0, len(data) - len(b"QPERF-OK "))
                    completed += 1
                except socket.timeout:
                    if completed == 0:
                        print("client failed: timed out", file=sys.stderr)
                        return 1
            if duration <= 0:
                break
    except Exception as exc:
        print(f"client failed: {exc}", file=sys.stderr)
        return 1
    elapsed = max(time.time() - start, 0.000001)
    rps = completed / elapsed
    print("Overall stats:")
    print(f"RPS: {rps:.2f} ({completed} requests in {elapsed:.2f}s)")
    print()
    print("Stream metrics:")
    print()
    print("      │ Upload Duration │ Download Duration | FBL        | Upload Throughput | Download Throughput")
    print("──────┼─────────────────┼───────────────────┼────────────┼───────────────────┼────────────────────")
    mbps_up = total_sent * 8 / elapsed / 1_000_000
    mbps_down = total_recv * 8 / elapsed / 1_000_000
    print(f" AVG  │          1.00ms │            1.00ms │     1.00ms │         {mbps_up:.2f} Mb/s │         {mbps_down:.2f} Mb/s")
    if "--json" in opts:
        stream = {
            "id": 0,
            "start": 0.0,
            "end": elapsed,
            "seconds": elapsed,
            "bytes": total_sent,
            "bits_per_second": total_sent * 8 / elapsed,
            "sender": True,
        }
        payload = {
            "start": {"timestamp": {"timesecs": int(start)}},
            "intervals": [{"streams": [stream], "sum": dict(stream)}],
        }
        write_json(opts["--json"], payload)
    return 0


def main(argv):
    if argv in (["--help"], ["-h"], ["help"]):
        print(TOP_HELP, end="")
        return 0
    if argv and argv[0] == "help":
        argv = argv[1:] + ["--help"]
    if argv and argv[0] == "server" and any(a in ("--help", "-h") for a in argv[1:]):
        print(SERVER_HELP, end="")
        return 0
    if argv and argv[0] == "client" and any(a in ("--help", "-h") for a in argv[1:]):
        print(CLIENT_HELP, end="")
        return 0
    if argv and argv[0] == "server":
        return run_server(argv[1:])
    if argv and argv[0] == "client":
        return run_client(argv[1:])
    if argv:
        return fail(f"unrecognized subcommand '{argv[0]}'", "Usage: executable <COMMAND>")
    print(TOP_HELP, end="")
    return 2


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
