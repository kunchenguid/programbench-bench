import os
import subprocess
import tempfile
import unittest


ROOT = os.path.dirname(os.path.dirname(__file__))
RUNNER = os.environ.get("FLAMELENS_RUNNER", os.path.join(ROOT, "src", "flamelens.py"))


def run_cmd(args, input_data=None):
    return subprocess.run(
        [RUNNER] + args,
        input=input_data,
        text=True,
        capture_output=True,
    )


class CliBehaviorTests(unittest.TestCase):
    def test_help_and_version_match_documented_cli(self):
        help_result = run_cmd(["--help"])
        self.assertEqual(help_result.returncode, 0)
        self.assertEqual(help_result.stderr, "")
        self.assertEqual(
            help_result.stdout,
            "Usage: executable [OPTIONS] [FILENAME]\n"
            "\n"
            "Arguments:\n"
            "  [FILENAME]  Profile data filename\n"
            "\n"
            "Options:\n"
            "      --sorted   Whether to sort the stacks by time spent\n"
            "      --echo     Print data to stdout on exit. Useful when piping to other tools\n"
            "      --debug    Show debug info\n"
            "  -h, --help     Print help\n"
            "  -V, --version  Print version\n",
        )

        version_result = run_cmd(["--version"])
        self.assertEqual(version_result.returncode, 0)
        self.assertEqual(version_result.stderr, "")
        self.assertEqual(version_result.stdout, "flamelens 0.3.1\n")

    def test_unknown_option_and_extra_filename_are_clap_style_errors(self):
        unknown = run_cmd(["--no-such"])
        self.assertEqual(unknown.returncode, 2)
        self.assertEqual(unknown.stdout, "")
        self.assertEqual(
            unknown.stderr,
            "error: unexpected argument '--no-such' found\n"
            "\n"
            "  tip: to pass '--no-such' as a value, use '-- --no-such'\n"
            "\n"
            "Usage: executable [OPTIONS] [FILENAME]\n"
            "\n"
            "For more information, try '--help'.\n",
        )

    def test_echo_prints_profile_data_then_non_tty_error(self):
        data = "a;b;c 10\na;b;d 5\nx 2\n"
        piped = run_cmd(["--echo"], input_data=data)
        self.assertEqual(piped.returncode, 1)
        self.assertEqual(piped.stdout, data)
        self.assertEqual(
            piped.stderr,
            'Error: Os { code: 11, kind: WouldBlock, message: "Resource temporarily unavailable" }\n',
        )

        with tempfile.NamedTemporaryFile("w", delete=False) as f:
            f.write(data)
            name = f.name
        try:
            from_file = run_cmd(["--echo", name])
        finally:
            os.unlink(name)
        self.assertEqual(from_file.returncode, 1)
        self.assertEqual(from_file.stdout, data)
        self.assertEqual(piped.stderr, from_file.stderr)

    def test_missing_file_uses_original_panic_shape(self):
        result = run_cmd(["missing.folded"])
        self.assertEqual(result.returncode, 101)
        self.assertEqual(result.stdout, "")
        self.assertIn("panicked at src/main.rs:44:47:", result.stderr)
        self.assertIn(
            'Could not read file: Os { code: 2, kind: NotFound, message: "No such file or directory" }',
            result.stderr,
        )
        self.assertIn("note: run with `RUST_BACKTRACE=1` environment variable to display a backtrace", result.stderr)

        extra = run_cmd(["a", "b"])
        self.assertEqual(extra.returncode, 2)
        self.assertEqual(extra.stdout, "")
        self.assertEqual(
            extra.stderr,
            "error: unexpected argument 'b' found\n"
            "\n"
            "Usage: executable [OPTIONS] [FILENAME]\n"
            "\n"
            "For more information, try '--help'.\n",
        )


if __name__ == "__main__":
    unittest.main()
