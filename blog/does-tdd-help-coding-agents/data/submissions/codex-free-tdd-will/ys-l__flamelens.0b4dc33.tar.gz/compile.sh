#!/bin/bash
set -e
rm -f executable
cp src/flamelens.py executable
chmod +x executable
