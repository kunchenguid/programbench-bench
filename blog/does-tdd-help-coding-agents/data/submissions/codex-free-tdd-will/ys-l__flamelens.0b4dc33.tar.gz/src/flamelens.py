#!/usr/bin/env python3
import sys
import os


HELP_TEXT = """Usage: executable [OPTIONS] [FILENAME]

Arguments:
  [FILENAME]  Profile data filename

Options:
      --sorted   Whether to sort the stacks by time spent
      --echo     Print data to stdout on exit. Useful when piping to other tools
      --debug    Show debug info
  -h, --help     Print help
  -V, --version  Print version
"""


def main(argv):
    filename = None
    echo = False
    passthrough = False
    for arg in argv:
        if not passthrough and arg == "--":
            passthrough = True
            continue
        if not passthrough and arg in ("-h", "--help"):
            sys.stdout.write(HELP_TEXT)
            return 0
        if not passthrough and arg in ("-V", "--version"):
            sys.stdout.write("flamelens 0.3.1\n")
            return 0
        if not passthrough and arg == "--echo":
            echo = True
            continue
        if not passthrough and arg in ("--sorted", "--debug"):
            continue
        if not passthrough and arg.startswith("-"):
            return unexpected(arg, tip=True)
        if filename is None:
            filename = arg
        else:
            return unexpected(arg, tip=False)
    try:
        data = read_profile_data(filename)
    except FileNotFoundError:
        rust_file_panic()
        return 101
    if echo:
        sys.stdout.write(data)
        sys.stdout.flush()
    if not sys.stdin.isatty() or not sys.stdout.isatty():
        sys.stderr.write(
            'Error: Os { code: 11, kind: WouldBlock, message: "Resource temporarily unavailable" }\n'
        )
        return 1
    return run_tui(data)


def read_profile_data(filename):
    if filename is None:
        return sys.stdin.read()
    with open(filename, "r", encoding="utf-8") as f:
        return f.read()


def rust_file_panic():
    sys.stderr.write(
        f"\nthread 'main' ({os.getpid()}) panicked at src/main.rs:44:47:\n"
        'Could not read file: Os { code: 2, kind: NotFound, message: "No such file or directory" }\n'
        "note: run with `RUST_BACKTRACE=1` environment variable to display a backtrace\n"
    )


def run_tui(data):
    sys.stdout.write("\033[?1049h\033[?25l\033[2J")
    sys.stdout.write("flamelens\n")
    sys.stdout.write(f"samples: {len([line for line in data.splitlines() if line.strip()])}\n")
    sys.stdout.flush()
    try:
        while True:
            ch = sys.stdin.read(1)
            if ch in ("q", "\x03", ""):
                break
    finally:
        sys.stdout.write("\033[?25h\033[?1049l")
        sys.stdout.flush()
    return 0


def unexpected(arg, tip):
    sys.stderr.write(f"error: unexpected argument '{arg}' found\n\n")
    if tip:
        sys.stderr.write(f"  tip: to pass '{arg}' as a value, use '-- {arg}'\n\n")
    sys.stderr.write(
        "Usage: executable [OPTIONS] [FILENAME]\n"
        "\n"
        "For more information, try '--help'.\n"
    )
    return 2


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
