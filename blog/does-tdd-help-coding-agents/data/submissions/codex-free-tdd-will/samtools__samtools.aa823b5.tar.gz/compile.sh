#!/bin/bash
set -e
cp samtools_reimpl.py executable
chmod +x executable
