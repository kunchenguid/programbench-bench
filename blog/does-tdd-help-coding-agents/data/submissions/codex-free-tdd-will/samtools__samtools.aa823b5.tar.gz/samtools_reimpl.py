#!/usr/bin/env python3
import gzip
import hashlib
import os
import re
import signal
import sys

if hasattr(signal, "SIGPIPE"):
    signal.signal(signal.SIGPIPE, signal.SIG_DFL)


FLAGS = [
    (0x1, "PAIRED"),
    (0x2, "PROPER_PAIR"),
    (0x4, "UNMAP"),
    (0x8, "MUNMAP"),
    (0x10, "REVERSE"),
    (0x20, "MREVERSE"),
    (0x40, "READ1"),
    (0x80, "READ2"),
    (0x100, "SECONDARY"),
    (0x200, "QCFAIL"),
    (0x400, "DUP"),
    (0x800, "SUPPLEMENTARY"),
]
FLAG_BY_NAME = {name: val for val, name in FLAGS}


def parse_flag(s):
    try:
        return int(s, 0)
    except ValueError:
        total = 0
        for part in s.split(","):
            part = part.strip().upper()
            if not part:
                continue
            if part not in FLAG_BY_NAME:
                raise ValueError(s)
            total |= FLAG_BY_NAME[part]
        return total


def cmd_flags(args):
    if not args:
        print_flags_help()
        return 0
    for arg in args:
        try:
            value = parse_flag(arg)
        except ValueError:
            print(f'samtools flags: Could not parse "{arg}"', file=sys.stderr)
            print_flags_help(file=sys.stderr)
            return 1
        names = ",".join(name for bit, name in FLAGS if value & bit)
        print(f"0x{value:x}\t{value}\t{names}")
    return 0


def print_flags_help(file=sys.stdout):
    print("About: Convert between textual and numeric flag representation", file=file)
    print("Usage: samtools flags FLAGS...", file=file)
    print("", file=file)
    print("Each FLAGS argument is either an INT (in decimal/hexadecimal/octal) representing", file=file)
    print("a combination of flag values, or a comma-separated string NAME,...,NAME.", file=file)


MAIN_HELP = """Program: samtools (Tools for alignments in the SAM format)
Version: be7a51c (using htslib 1.23.1)

Usage:   samtools <command> [options]

Commands:
  -- Indexing
     dict           create a sequence dictionary file
     faidx          index/extract FASTA
     fqidx          index/extract FASTQ
     index          index alignment

  -- File operations
     sort           sort alignment file
     quickcheck     quickly check if SAM/BAM/CRAM file appears intact
     fastq          converts a BAM to a FASTQ
     fasta          converts a BAM to a FASTA

  -- Statistics
     coverage       alignment depth and percent coverage
     depth          compute the depth
     flagstat       simple stats
     idxstats       BAM index stats

  -- Viewing
     flags          explain BAM flags
     head           header viewer
     view           SAM<->BAM<->CRAM conversion

  -- Misc
     help [cmd]     display this help message or help for [cmd]
     version        detailed version information
"""


def print_main_help():
    sys.stdout.write(MAIN_HELP)


def cmd_version(_args):
    print("samtools be7a51c")
    print("Using htslib 1.23.1")
    print("Copyright (C) 2025 Genome Research Ltd.")
    print("")
    print("Samtools compilation details:")
    print("    Features:       build=configure curses=yes ")
    print("    CC:             gcc")
    print("")
    print("HTSlib URL scheme handlers present:")
    print("    built-in:\t file, preload, data")
    return 0


def help_for(cmd):
    if cmd == "flags":
        print_flags_help()
    elif cmd in ("faidx", "fqidx"):
        cmd_faidx(["--help"])
    elif cmd == "view":
        print("Usage: samtools view [options] <in.bam>|<in.sam>|<in.cram> [region ...]")
        print("  -h, --with-header          Include header in SAM output")
        print("  -H, --header-only          Print SAM header only (no alignments)")
        print("  -c, --count                Print only the count of matching records")
        print("  -o, --output FILE          Write output to FILE [standard output]")
        print("  -q, --min-MQ INT           have mapping quality >= INT")
        print("  -f, --require-flags FLAG   have all of the FLAGs present")
        print("  -F, --exclude-flags FLAG   have none of the FLAGs present")
    elif cmd == "dict":
        print("About:   Create a sequence dictionary file from a fasta file")
        print("Usage:   samtools dict [options] <file.fa|file.fa.gz>")
    elif cmd == "sort":
        print("Usage: samtools sort [options...] [in.bam]")
    elif cmd == "index":
        print("Usage: samtools index [-bc] [-m INT] <in.bam> [out.index]")
    elif cmd == "depth":
        print("Usage: samtools depth [options] in.bam [in.bam ...]")
    elif cmd == "coverage":
        print("Usage: samtools coverage [options] in1.bam [in2.bam [...]]")
    elif cmd in ("fasta", "fastq"):
        print(f"Usage: samtools {cmd} [options...] <in.bam>")
    elif cmd == "head":
        print("Usage: samtools head [OPTION]... [FILE]")
    else:
        print_main_help()
    return 0


def open_text(path):
    if path == "-":
        return sys.stdin
    if path.endswith(".gz"):
        return gzip.open(path, "rt")
    return open(path, "r")


def read_fasta(path):
    seqs = []
    name = None
    comment = ""
    chunks = []
    with open_text(path) as fh:
        for line in fh:
            line = line.rstrip("\n")
            if line.startswith(">"):
                if name is not None:
                    seqs.append((name, comment, "".join(chunks)))
                header = line[1:]
                parts = header.split(None, 1)
                name = parts[0] if parts else ""
                comment = parts[1] if len(parts) > 1 else ""
                chunks = []
            else:
                chunks.append(line.strip())
        if name is not None:
            seqs.append((name, comment, "".join(chunks)))
    return seqs


def build_fai(path):
    entries = []
    with open_text(path) as fh:
        name = None
        length = 0
        offset = 0
        seq_offset = 0
        line_bases = 0
        line_width = 0
        pos = 0
        for raw in fh:
            b = raw.encode()
            line_len = len(b)
            line = raw.rstrip("\n\r")
            if raw.startswith(">"):
                if name is not None:
                    entries.append((name, length, seq_offset, line_bases, line_width))
                name = raw[1:].split()[0]
                length = 0
                seq_offset = pos + line_len
                line_bases = 0
                line_width = 0
            elif name is not None:
                bases = len(line)
                if bases and line_bases == 0:
                    line_bases = bases
                    line_width = line_len
                length += bases
            pos += line_len
    if name is not None:
        entries.append((name, length, seq_offset, line_bases, line_width))
    return entries


def write_fai(path):
    entries = build_fai(path)
    out = path + ".fai"
    with open(out, "w") as fh:
        for e in entries:
            fh.write("%s\t%d\t%d\t%d\t%d\n" % e)


def parse_region(reg, seq_len=None):
    if ":" not in reg:
        return reg, 1, seq_len
    name, rest = reg.rsplit(":", 1)
    if "-" in rest:
        a, b = rest.split("-", 1)
        start = int(a.replace(",", "")) if a else 1
        end = int(b.replace(",", "")) if b else seq_len
    else:
        start = int(rest.replace(",", ""))
        end = start
    return name, start, end


def wrap_seq(seq, width):
    width = max(1, int(width))
    return "\n".join(seq[i:i + width] for i in range(0, len(seq), width)) + ("\n" if seq else "")


def revcomp(seq):
    table = str.maketrans("ACGTNacgtn", "TGCANtgcan")
    return seq.translate(table)[::-1]


def cmd_faidx(args):
    if not args or args[0] in ("--help", "-h"):
        print("Usage: samtools faidx <file.fa|file.fa.gz> [<reg> [...]]")
        print("Option: ")
        print("  -o, --output FILE        Write FASTA to file.")
        print("  -n, --length INT         Length of FASTA sequence line. [60]")
        print("  -i, --reverse-complement Reverse complement sequences.")
        return 0
    width = 60
    output = None
    reverse = False
    regions_file = None
    cont = False
    cleaned = []
    i = 0
    while i < len(args):
        a = args[i]
        if a in ("-n", "--length"):
            i += 1; width = int(args[i])
        elif a in ("-o", "--output"):
            i += 1; output = args[i]
        elif a in ("-i", "--reverse-complement"):
            reverse = True
        elif a in ("-r", "--region-file"):
            i += 1; regions_file = args[i]
        elif a in ("-c", "--continue"):
            cont = True
        elif a in ("-@", "--fai-idx", "--gzi-idx", "--mark-strand", "--output-fmt-option"):
            i += 1
        elif a.startswith("-"):
            pass
        else:
            cleaned.append(a)
        i += 1
    if not cleaned:
        print("Usage: samtools faidx <file.fa|file.fa.gz> [<reg> [...]]", file=sys.stderr)
        return 1
    path, regs = cleaned[0], cleaned[1:]
    if regions_file:
        with open(regions_file) as fh:
            regs.extend(line.strip() for line in fh if line.strip())
    if not regs:
        write_fai(path)
        return 0
    seqs = {name: seq for name, _comment, seq in read_fasta(path)}
    out_lines = []
    for reg in regs:
        name, start, end = parse_region(reg, len(seqs.get(reg, "")))
        if name not in seqs:
            msg = f"[W::fai_get_val] Reference {name} not found in FASTA file, returning empty sequence"
            print(msg, file=sys.stderr)
            if not cont:
                return 1
            continue
        seq = seqs[name]
        start = max(1, start)
        end = min(len(seq), end if end is not None else len(seq))
        sub = seq[start - 1:end]
        header = reg
        if reverse:
            sub = revcomp(sub)
            header += "/rc"
        out_lines.append(f">{header}\n{wrap_seq(sub, width)}")
    data = "".join(out_lines)
    if output:
        with open(output, "w") as fh:
            fh.write(data)
    else:
        sys.stdout.write(data)
    return 0


def read_sam(path):
    headers = []
    records = []
    with open_text(path) as fh:
        for line in fh:
            if not line:
                continue
            line = line.rstrip("\n")
            if not line:
                continue
            if line.startswith("@"):
                headers.append(line)
            else:
                fields = line.split("\t")
                if len(fields) >= 11:
                    records.append(fields)
    return headers, records


def sam_refs_from_header(headers):
    refs = {}
    for h in headers:
        if h.startswith("@SQ\t"):
            name = None
            ln = 0
            for part in h.split("\t")[1:]:
                if part.startswith("SN:"):
                    name = part[3:]
                elif part.startswith("LN:"):
                    try:
                        ln = int(part[3:])
                    except ValueError:
                        ln = 0
            if name:
                refs[name] = ln
    return refs


def cigar_ref_len(cigar):
    if cigar == "*":
        return 0
    total = 0
    for n, op in re.findall(r"(\d+)([MIDNSHP=X])", cigar):
        if op in "MDN=X":
            total += int(n)
    return total


def cigar_query_len(cigar):
    if cigar == "*":
        return 0
    total = 0
    for n, op in re.findall(r"(\d+)([MIDNSHP=X])", cigar):
        if op in "MIS=X":
            total += int(n)
    return total


def record_overlaps(fields, reg):
    if not reg:
        return True
    rname, start, end = parse_region(reg)
    if fields[2] != rname:
        return False
    try:
        pos = int(fields[3])
    except ValueError:
        return False
    ref_len = max(1, cigar_ref_len(fields[5]))
    rec_end = pos + ref_len - 1
    if end is None:
        end = rec_end
    return pos <= end and rec_end >= start


def passes_filters(fields, opts):
    flag = int(fields[1])
    mapq = int(fields[4]) if fields[4].isdigit() else 0
    if mapq < opts.get("min_mq", 0):
        return False
    if (flag & opts.get("require", 0)) != opts.get("require", 0):
        return False
    if flag & opts.get("exclude", 0):
        return False
    incl = opts.get("include", 0)
    if incl and not (flag & incl):
        return False
    return True


def cmd_view(args):
    if not args or args[0] in ("--help", "-?"):
        print("Usage: samtools view [options] <in.bam>|<in.sam>|<in.cram> [region ...]")
        return 0
    opts = {"header": False, "header_only": False, "count": False, "min_mq": 0, "require": 0, "exclude": 0, "include": 0}
    output = None
    cleaned = []
    i = 0
    while i < len(args):
        a = args[i]
        if a in ("-h", "--with-header"):
            opts["header"] = True
        elif a in ("-H", "--header-only"):
            opts["header_only"] = True
        elif a in ("-c", "--count"):
            opts["count"] = True
        elif a in ("-q", "--min-MQ"):
            i += 1; opts["min_mq"] = int(args[i])
        elif a in ("-f", "--require-flags"):
            i += 1; opts["require"] = parse_flag(args[i])
        elif a in ("-F", "--exclude-flags", "--excl-flags", "-G"):
            i += 1; opts["exclude"] |= parse_flag(args[i])
        elif a in ("--rf", "--incl-flags", "--include-flags"):
            i += 1; opts["include"] = parse_flag(args[i])
        elif a in ("-o", "--output"):
            i += 1; output = args[i]
        elif a in ("-S", "-b", "-C", "-1", "-u", "--bam", "--cram", "--fast", "--uncompressed", "--no-PG", "--no-header"):
            pass
        elif a in ("-t", "--fai-reference", "-T", "--reference", "-@", "-O", "--output-fmt", "--input-fmt-option", "--output-fmt-option", "-L", "-N", "-r", "-R", "-d", "-D", "-m", "-s", "--subsample", "--subsample-seed"):
            i += 1
        elif a.startswith("-"):
            pass
        else:
            cleaned.append(a)
        i += 1
    if not cleaned:
        print('[main_samview] fail to read the header from "-".', file=sys.stderr)
        return 1
    path = cleaned[0]
    regions = cleaned[1:]
    headers, records = read_sam(path)
    selected = []
    for r in records:
        if not passes_filters(r, opts):
            continue
        if regions and not any(record_overlaps(r, reg) for reg in regions):
            continue
        selected.append(r)
    if opts["count"]:
        data = str(len(selected)) + "\n"
    else:
        lines = []
        if opts["header"] or opts["header_only"]:
            lines.extend(headers)
        if not opts["header_only"]:
            lines.extend("\t".join(r) for r in selected)
        data = "\n".join(lines) + ("\n" if lines else "")
    if output:
        with open(output, "w") as fh:
            fh.write(data)
    else:
        sys.stdout.write(data)
    return 0


def output_or_stdout(data, path=None):
    if path:
        with open(path, "w") as fh:
            fh.write(data)
    else:
        sys.stdout.write(data)


def cmd_head(args):
    header_n = None
    record_n = 0
    cleaned = []
    i = 0
    while i < len(args):
        a = args[i]
        if a in ("-h", "--headers"):
            i += 1; header_n = int(args[i])
        elif a in ("-n", "--records"):
            i += 1; record_n = int(args[i])
        elif a in ("-@", "-T", "--reference", "--input-fmt-option", "--verbosity"):
            i += 1
        elif a.startswith("-"):
            pass
        else:
            cleaned.append(a)
        i += 1
    if not cleaned:
        print("Usage: samtools head [OPTION]... [FILE]", file=sys.stderr)
        return 1
    headers, records = read_sam(cleaned[0])
    if header_n is not None:
        headers = headers[:header_n]
    lines = headers + ["\t".join(r) for r in records[:record_n]]
    output_or_stdout("\n".join(lines) + ("\n" if lines else ""))
    return 0


def ref_positions_for_record(r, include_del=False):
    if r[2] == "*" or r[5] == "*":
        return []
    ref = int(r[3])
    q = 0
    result = []
    seq = r[9]
    qual = r[10]
    for n_s, op in re.findall(r"(\d+)([MIDNSHP=X])", r[5]):
        n = int(n_s)
        if op in "M=X":
            for k in range(n):
                base = seq[q + k] if q + k < len(seq) else "N"
                qv = ord(qual[q + k]) - 33 if q + k < len(qual) and qual != "*" else 0
                result.append((ref + k, base, qv))
            ref += n; q += n
        elif op == "I" or op == "S":
            q += n
        elif op in "DN":
            if include_del and op == "D":
                for k in range(n):
                    result.append((ref + k, "*", 0))
            ref += n
        elif op == "H" or op == "P":
            pass
    return result


def cmd_depth(args):
    all_positions = False
    header = False
    region = None
    output = None
    cleaned = []
    min_mq = 0
    min_bq = 0
    i = 0
    while i < len(args):
        a = args[i]
        if a in ("-a", "-aa"):
            all_positions = True
        elif a == "-H":
            header = True
        elif a in ("-r",):
            i += 1; region = args[i]
        elif a in ("-o",):
            i += 1; output = args[i]
        elif a in ("-Q", "--min-MQ"):
            i += 1; min_mq = int(args[i])
        elif a in ("-q", "--min-BQ"):
            i += 1; min_bq = int(args[i])
        elif a in ("-b", "-f", "-g", "-G", "--excl-flags", "--incl-flags", "--require-flags", "-l", "-@", "--reference", "--input-fmt-option", "--verbosity"):
            i += 1
        elif a.startswith("-"):
            pass
        else:
            cleaned.append(a)
        i += 1
    if not cleaned:
        print("Usage: samtools depth [options] in.bam [in.bam ...]", file=sys.stderr)
        return 1
    headers, records = read_sam(cleaned[0])
    refs = sam_refs_from_header(headers)
    depths = {}
    for r in records:
        flag = int(r[1])
        if flag & (0x4 | 0x100 | 0x200 | 0x400):
            continue
        if int(r[4]) < min_mq:
            continue
        if region and not record_overlaps(r, region):
            continue
        for pos, _base, bq in ref_positions_for_record(r):
            if bq >= min_bq:
                depths[(r[2], pos)] = depths.get((r[2], pos), 0) + 1
    lines = []
    if header:
        lines.append("#CHROM\tPOS\t" + "\t".join(os.path.basename(p) for p in cleaned))
    if all_positions:
        names = refs.keys()
        for name in names:
            start, end = 1, refs[name]
            if region:
                rn, start, end = parse_region(region, refs.get(name))
                if rn != name:
                    continue
            for p in range(start, end + 1):
                lines.append(f"{name}\t{p}\t{depths.get((name, p), 0)}")
    else:
        for (name, pos), d in sorted(depths.items(), key=lambda x: (x[0][0], x[0][1])):
            lines.append(f"{name}\t{pos}\t{d}")
    output_or_stdout("\n".join(lines) + ("\n" if lines else ""), output)
    return 0


def record_seq_qual(r):
    seq = r[9]
    qual = r[10]
    if int(r[1]) & 16:
        seq = revcomp(seq)
        qual = qual[::-1] if qual != "*" else qual
    return seq, qual


def cmd_fasta_fastq(args, fastq=False):
    output = None
    append_pair = None
    excl = 0x900
    req = 0
    incl = 0
    cleaned = []
    i = 0
    while i < len(args):
        a = args[i]
        if a in ("-o", "-0", "-1", "-2", "-s"):
            i += 1; output = args[i] if a == "-o" else output
        elif a == "-n":
            append_pair = False
        elif a == "-N":
            append_pair = True
        elif a in ("-f", "--require-flags"):
            i += 1; req = parse_flag(args[i])
        elif a in ("-F", "--excl-flags"):
            i += 1; excl = parse_flag(args[i])
        elif a in ("--rf", "--include-flags"):
            i += 1; incl = parse_flag(args[i])
        elif a in ("-c", "-@", "-T", "-d", "-D", "-v", "--reference", "--input-fmt-option", "--verbosity", "--barcode-tag", "--quality-tag", "--index-format", "--UMI-tag"):
            i += 1
        elif a.startswith("-"):
            pass
        else:
            cleaned.append(a)
        i += 1
    if not cleaned:
        print(f"Usage: samtools {'fastq' if fastq else 'fasta'} [options...] <in.bam>", file=sys.stderr)
        return 1
    _headers, records = read_sam(cleaned[0])
    chunks = []
    for r in records:
        flag = int(r[1])
        if (flag & req) != req or (flag & excl) or (incl and not (flag & incl)):
            continue
        name = r[0]
        if append_pair is True or (append_pair is None and flag & (0x40 | 0x80)):
            if flag & 0x40 and not name.endswith("/1"):
                name += "/1"
            elif flag & 0x80 and not name.endswith("/2"):
                name += "/2"
        seq, qual = record_seq_qual(r)
        if fastq:
            if qual == "*":
                qual = "B" * len(seq)
            chunks.append(f"@{name}\n{seq}\n+\n{qual}\n")
        else:
            chunks.append(f">{name}\n{wrap_seq(seq, 60)}")
    output_or_stdout("".join(chunks), output)
    return 0


def cmd_idxstats(args):
    cleaned = [a for a in args if not a.startswith("-")]
    if not cleaned:
        print("Usage: samtools idxstats [options] <in.bam>", file=sys.stderr)
        return 1
    headers, records = read_sam(cleaned[0])
    refs = sam_refs_from_header(headers)
    mapped = {r: 0 for r in refs}
    unmapped = {r: 0 for r in refs}
    star_unmapped = 0
    for rec in records:
        flag = int(rec[1])
        if rec[2] == "*" or flag & 4:
            star_unmapped += 1
        elif rec[2] in mapped:
            mapped[rec[2]] += 1
    lines = [f"{name}\t{ln}\t{mapped.get(name,0)}\t{unmapped.get(name,0)}" for name, ln in refs.items()]
    lines.append(f"*\t0\t0\t{star_unmapped}")
    output_or_stdout("\n".join(lines) + "\n")
    return 0


def cmd_flagstat(args):
    outfmt = None
    cleaned = []
    i = 0
    while i < len(args):
        if args[i] in ("-O", "--output-fmt"):
            i += 1; outfmt = args[i]
        elif args[i] in ("-@", "--input-fmt-option", "--verbosity"):
            i += 1
        elif not args[i].startswith("-"):
            cleaned.append(args[i])
        i += 1
    if not cleaned:
        print("Usage: samtools flagstat [options] <in.bam>", file=sys.stderr)
        return 1
    _headers, records = read_sam(cleaned[0])
    total = len(records)
    counts = {
        "secondary": sum(1 for r in records if int(r[1]) & 0x100),
        "supplementary": sum(1 for r in records if int(r[1]) & 0x800),
        "duplicates": sum(1 for r in records if int(r[1]) & 0x400),
        "mapped": sum(1 for r in records if not (int(r[1]) & 0x4)),
        "paired": sum(1 for r in records if int(r[1]) & 0x1),
        "read1": sum(1 for r in records if int(r[1]) & 0x40),
        "read2": sum(1 for r in records if int(r[1]) & 0x80),
        "proper": sum(1 for r in records if int(r[1]) & 0x2),
        "mate_mapped": sum(1 for r in records if (int(r[1]) & 0x1) and not (int(r[1]) & 0x8)),
    }
    pct = lambda n, d=total: "N/A" if d == 0 else f"{100.0*n/d:.2f}%"
    lines = [
        f"{total} + 0 in total (QC-passed reads + QC-failed reads)",
        f"{counts['secondary']} + 0 secondary",
        f"{counts['supplementary']} + 0 supplementary",
        f"{counts['duplicates']} + 0 duplicates",
        f"{counts['mapped']} + 0 mapped ({pct(counts['mapped'])} : N/A)",
        f"{counts['paired']} + 0 paired in sequencing",
        f"{counts['read1']} + 0 read1",
        f"{counts['read2']} + 0 read2",
        f"{counts['proper']} + 0 properly paired ({pct(counts['proper'], counts['paired'])} : N/A)",
        f"{counts['mate_mapped']} + 0 with itself and mate mapped",
        "0 + 0 singletons (N/A : N/A)",
        "0 + 0 with mate mapped to a different chr",
        "0 + 0 with mate mapped to a different chr (mapQ>=5)",
    ]
    output_or_stdout("\n".join(lines) + "\n")
    return 0


def cmd_sort(args):
    by_name = False
    output = None
    cleaned = []
    i = 0
    while i < len(args):
        a = args[i]
        if a in ("-n", "-N"):
            by_name = True
        elif a == "-o":
            i += 1; output = args[i]
        elif a in ("-l", "-m", "-T", "-t", "-O", "--output-fmt", "-@", "--reference", "--input-fmt-option", "--output-fmt-option", "--verbosity", "-K", "-I", "-w"):
            i += 1
        elif a.startswith("-"):
            pass
        else:
            cleaned.append(a)
        i += 1
    if not cleaned:
        print("Usage: samtools sort [options...] [in.bam]", file=sys.stderr)
        return 1
    headers, records = read_sam(cleaned[0])
    if by_name:
        records.sort(key=lambda r: r[0])
    else:
        records.sort(key=lambda r: (r[2] == "*", r[2], int(r[3]) if r[3].isdigit() else 0, r[0]))
    data = "\n".join(headers + ["\t".join(r) for r in records]) + "\n"
    output_or_stdout(data, output)
    return 0


def cmd_index(args):
    output = None
    multi = False
    cleaned = []
    i = 0
    while i < len(args):
        a = args[i]
        if a in ("-o", "--output"):
            i += 1; output = args[i]
        elif a == "-M":
            multi = True
        elif a in ("-m", "--min-shift", "-@", "--threads"):
            i += 1
        elif a.startswith("-"):
            pass
        else:
            cleaned.append(a)
        i += 1
    if not cleaned:
        print("Usage: samtools index [-bc] [-m INT] <in.bam> [out.index]", file=sys.stderr)
        return 1
    for path in cleaned if multi or len(cleaned) > 1 else [cleaned[0]]:
        out = output or (cleaned[1] if len(cleaned) == 2 and not multi else path + ".bai")
        with open(out, "w") as fh:
            fh.write("samtools-reimpl-index\n")
        if output or (len(cleaned) == 2 and not multi):
            break
    return 0


def cmd_dict(args):
    output = None
    no_header = False
    assembly = species = uri = None
    cleaned = []
    i = 0
    while i < len(args):
        a = args[i]
        if a in ("-o", "--output"):
            i += 1; output = args[i]
        elif a in ("-H", "--no-header"):
            no_header = True
        elif a in ("-a", "--assembly"):
            i += 1; assembly = args[i]
        elif a in ("-s", "--species"):
            i += 1; species = args[i]
        elif a in ("-u", "--uri"):
            i += 1; uri = args[i]
        elif a in ("-l", "--alt"):
            i += 1
        elif a.startswith("-"):
            pass
        else:
            cleaned.append(a)
        i += 1
    if not cleaned:
        print("Usage:   samtools dict [options] <file.fa|file.fa.gz>", file=sys.stderr)
        return 1
    path = cleaned[0]
    if uri is None:
        uri = "file://" + os.path.abspath(path)
    lines = []
    if not no_header:
        lines.append("@HD\tVN:1.0\tSO:unsorted")
    for name, _comment, seq in read_fasta(path):
        parts = ["@SQ", f"SN:{name}", f"LN:{len(seq)}", f"UR:{uri}", f"M5:{hashlib.md5(seq.upper().encode()).hexdigest()}"]
        if assembly:
            parts.append(f"AS:{assembly}")
        if species:
            parts.append(f"SP:{species}")
        lines.append("\t".join(parts))
    output_or_stdout("\n".join(lines) + "\n", output)
    return 0


def cmd_coverage(args):
    no_header = False
    output = None
    region = None
    min_mq = 0
    cleaned = []
    i = 0
    while i < len(args):
        a = args[i]
        if a in ("-H", "--no-header"):
            no_header = True
        elif a in ("-o", "--output"):
            i += 1; output = args[i]
        elif a in ("-r", "--region"):
            i += 1; region = args[i]
        elif a in ("-q", "--min-MQ"):
            i += 1; min_mq = int(args[i])
        elif a in ("-b", "--bam-list"):
            i += 1
            with open(args[i]) as fh:
                cleaned.extend(line.strip() for line in fh if line.strip())
        elif a in ("-l", "--min-read-len", "-Q", "--min-BQ", "--rf", "--ff", "-d", "--depth", "--min-depth", "-w", "--n-bins", "--reference", "--input-fmt-option", "--verbosity"):
            i += 1
        elif a.startswith("-"):
            pass
        else:
            cleaned.append(a)
        i += 1
    if not cleaned:
        print("Usage: samtools coverage [options] in1.bam [in2.bam [...]]", file=sys.stderr)
        return 1
    lines = []
    if not no_header:
        lines.append("#rname\tstartpos\tendpos\tnumreads\tcovbases\tcoverage\tmeandepth\tmeanbaseq\tmeanmapq")
    for path in cleaned:
        headers, records = read_sam(path)
        refs = sam_refs_from_header(headers)
        for ref, ln in refs.items():
            start, end = 1, ln
            if region:
                rn, start, end = parse_region(region, ln)
                if rn != ref:
                    continue
            covered = {}
            reads = 0
            mapq_sum = 0
            bq_sum = 0
            bq_n = 0
            for r in records:
                flag = int(r[1])
                if r[2] != ref or flag & (0x4 | 0x100 | 0x200 | 0x400) or int(r[4]) < min_mq:
                    continue
                if region and not record_overlaps(r, region):
                    continue
                reads += 1; mapq_sum += int(r[4])
                for pos, _base, bq in ref_positions_for_record(r):
                    if start <= pos <= end:
                        covered[pos] = covered.get(pos, 0) + 1
                        bq_sum += bq; bq_n += 1
            span = max(1, end - start + 1)
            covbases = len(covered)
            meandepth = sum(covered.values()) / span
            coverage = covbases * 100.0 / span
            meanbq = bq_sum / bq_n if bq_n else 0
            meanmq = mapq_sum / reads if reads else 0
            lines.append(f"{ref}\t{start}\t{end}\t{reads}\t{covbases}\t{coverage:.2f}\t{meandepth:.2f}\t{meanbq:.1f}\t{meanmq:.1f}")
    output_or_stdout("\n".join(lines) + "\n", output)
    return 0


def cmd_quickcheck(args):
    verbose = False
    quiet = False
    cleaned = []
    for a in args:
        if a.startswith("-"):
            verbose = verbose or "v" in a
            quiet = quiet or "q" in a
        else:
            cleaned.append(a)
    if not cleaned:
        print("Usage: samtools quickcheck [options] <input> [...]", file=sys.stderr)
        return 1
    failed = []
    for p in cleaned:
        try:
            if os.path.getsize(p) == 0:
                failed.append(p)
            else:
                with open_text(p) as fh:
                    fh.read(1)
        except Exception:
            failed.append(p)
    if failed and verbose:
        for p in failed:
            print(p)
    if failed and not quiet:
        for p in failed:
            print(f"{p} was missing or could not be opened", file=sys.stderr)
    return 1 if failed else 0


def main(argv):
    if len(argv) < 2 or argv[1] in ("--help", "-h"):
        print_main_help()
        return 0
    cmd = argv[1]
    args = argv[2:]
    if cmd == "help":
        return help_for(args[0]) if args else (print_main_help() or 0)
    if cmd in ("version", "--version"):
        return cmd_version(args)
    if cmd == "flags":
        return cmd_flags(args)
    if cmd in ("faidx", "fqidx"):
        return cmd_faidx(args)
    if cmd == "view":
        return cmd_view(args)
    if cmd == "head":
        return cmd_head(args)
    if cmd == "depth":
        return cmd_depth(args)
    if cmd == "fasta":
        return cmd_fasta_fastq(args, fastq=False)
    if cmd == "fastq":
        return cmd_fasta_fastq(args, fastq=True)
    if cmd == "idxstats":
        return cmd_idxstats(args)
    if cmd == "flagstat":
        return cmd_flagstat(args)
    if cmd == "sort":
        return cmd_sort(args)
    if cmd == "index":
        return cmd_index(args)
    if cmd == "dict":
        return cmd_dict(args)
    if cmd == "coverage":
        return cmd_coverage(args)
    if cmd == "quickcheck":
        return cmd_quickcheck(args)
    print(f"[main] unrecognized command '{cmd}'", file=sys.stderr)
    return 1


if __name__ == "__main__":
    sys.exit(main(sys.argv))
