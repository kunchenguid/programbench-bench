#!/bin/bash
set -e
rm -f executable
cp src/gdal_cli.py executable
chmod +x executable
