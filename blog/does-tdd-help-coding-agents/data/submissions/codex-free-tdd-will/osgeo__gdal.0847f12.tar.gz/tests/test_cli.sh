#!/bin/bash
set -euo pipefail

BIN="${1:-./executable}"

run_capture() {
  local name="$1"
  shift
  set +e
  "$BIN" "$@" >"/tmp/${name}.out" 2>&1
  local status=$?
  set -e
  echo "$status" >"/tmp/${name}.status"
}

assert_status() {
  local name="$1" expected="$2"
  local actual
  actual="$(cat "/tmp/${name}.status")"
  if [ "$actual" != "$expected" ]; then
    echo "$name: expected status $expected, got $actual" >&2
    cat "/tmp/${name}.out" >&2
    exit 1
  fi
}

assert_contains() {
  local name="$1" text="$2"
  if ! grep -Fq "$text" "/tmp/${name}.out"; then
    echo "$name: missing expected text: $text" >&2
    cat "/tmp/${name}.out" >&2
    exit 1
  fi
}

run_capture version --version
assert_status version 0
assert_contains version "GDAL 3.13.0dev-e6fe3fbb06, released 2026/04/20"

run_capture help --help
assert_status help 0
assert_contains help "Usage: gdal <COMMAND> [OPTIONS]"
assert_contains help "  - raster:   Raster commands."

run_capture noargs
assert_status noargs 1
assert_contains noargs "ERROR 1: gdal: Missing command name."
assert_contains noargs "Try 'gdal --help' for help."

run_capture pipeline_help pipeline --help
assert_status pipeline_help 0
assert_contains pipeline_help "Usage: gdal pipeline [OPTIONS] <PIPELINE>"
assert_contains pipeline_help "Potential steps are:"

run_capture drivers --drivers
assert_status drivers 0
python3 - <<'PY'
import json
with open('/tmp/drivers.out', encoding='utf-8') as f:
    drivers = json.load(f)
names = {d.get('short_name') for d in drivers}
assert {'GTiff', 'GeoJSON', 'ESRI Shapefile'} <= names, names
PY

run_capture vsi_list vsi list .
assert_status vsi_list 0
assert_contains vsi_list "README.md"

run_capture identify dataset identify --format json sample.geojson
assert_status identify 0
python3 - <<'PY'
import json
with open('/tmp/identify.out', encoding='utf-8') as f:
    data = json.load(f)
assert data == [{'filename': 'sample.geojson', 'driver': 'GeoJSON'}], data
PY
