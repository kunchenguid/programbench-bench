#!/usr/bin/env python3
import json
import os
import shutil
import sys
from pathlib import Path

VERSION_TEXT = "GDAL 3.13.0dev-e6fe3fbb06, released 2026/04/20"

WARNING = """WARNING: the gdal command is provisionally provided as an alternative interface to GDAL and OGR command line utilities.
The project reserves the right to modify, rename, reorganize, and change the behavior of the utility
until it is officially frozen in a future feature release of GDAL."""

TOP_HELP = """Usage: gdal <COMMAND> [OPTIONS]
where <COMMAND> is one of:
  - convert:  Convert a dataset (shortcut for 'gdal raster convert' or 'gdal vector convert').
  - dataset:  Commands to manage datasets.
  - driver:   Command for driver specific operations.
  - info:     Return information on a dataset (shortcut for 'gdal raster info' or 'gdal vector info').
  - mdim:     Multidimensional commands.
  - pipeline: Process a dataset applying several steps.
  - raster:   Raster commands.
  - vector:   Vector commands.
  - vsi:      GDAL Virtual System Interface (VSI) commands.

Common Options:
  -h, --help              Display help message and exit
  --json-usage            Display usage as JSON document and exit
  --config <KEY>=<VALUE>  Configuration option [may be repeated]

Options:
  --version               Display GDAL version and exit
  --drivers               Display driver list as JSON document

'gdal <FILENAME>' can also be used as a shortcut for 'gdal info <FILENAME>'.
And 'gdal read <FILENAME> ! ...' as a shortcut for 'gdal pipeline <FILENAME> ! ...'.

For more details, consult https://gdal.org/programs/index.html

""" + WARNING

TOP_HELP_ERROR = TOP_HELP.replace(
    "\nCommon Options:\n  -h, --help              Display help message and exit\n  --json-usage            Display usage as JSON document and exit\n  --config <KEY>=<VALUE>  Configuration option [may be repeated]\n\nOptions:\n  --version               Display GDAL version and exit\n  --drivers               Display driver list as JSON document\n",
    "\nTry 'gdal --help' for help.\n",
)

HELP_TEXTS = {
    ("info",): """Usage: gdal info [OPTIONS] <INPUT>

Return information on a dataset (shortcut for 'gdal raster info' or 'gdal vector info').

Positional arguments:
  -i, --dataset, --input <INPUT>                       Input raster, vector or multidimensional raster dataset [required]

Common Options:
  -h, --help                                           Display help message and exit
  --json-usage                                         Display usage as JSON document and exit
  --config <KEY>=<VALUE>                               Configuration option [may be repeated]

Options:
  -f, --of, --format, --output-format <OUTPUT-FORMAT>  Output format. OUTPUT-FORMAT=json|text

For all options, run 'gdal raster info --help' or 'gdal vector info --help'

For more details, consult https://gdal.org/programs/gdal_info.html

""" + WARNING,
    ("convert",): """Usage: gdal convert [OPTIONS] <INPUT> <OUTPUT>

Convert a dataset (shortcut for 'gdal raster convert' or 'gdal vector convert').

Positional arguments:
  -i, --input <INPUT>                                  Input raster, vector or multidimensional raster dataset [required]
  -o, --output <OUTPUT>                                Output raster, vector or multidimensional raster dataset (created by algorithm) [required]

Common Options:
  -h, --help                                           Display help message and exit
  --json-usage                                         Display usage as JSON document and exit
  --config <KEY>=<VALUE>                               Configuration option [may be repeated]
  -q, --quiet                                          Quiet mode (no progress bar or warning message)

Options:
  -f, --of, --format, --output-format <OUTPUT-FORMAT>  Output format

For all options, run 'gdal raster convert --help' or 'gdal vector convert --help'

For more details, consult https://gdal.org/programs/gdal_convert.html

""" + WARNING,
    ("dataset",): """Usage: gdal dataset <SUBCOMMAND> [OPTIONS]
where <SUBCOMMAND> is one of:
  - check:    Check whether there are errors when reading the content of a dataset.
  - copy:     Copy files of a dataset. (alias: cp)
  - delete:   Delete dataset(s). (alias: rm, remove)
  - identify: Identify driver opening dataset(s).
  - rename:   Rename files of a dataset. (alias: ren, mv)

Common Options:
  -h, --help              Display help message and exit
  --json-usage            Display usage as JSON document and exit
  --config <KEY>=<VALUE>  Configuration option [may be repeated]

For more details, consult https://gdal.org/programs/gdal_dataset.html

""" + WARNING,
    ("dataset", "identify"): """Usage: gdal dataset identify [OPTIONS] <FILENAME>

Identify driver opening dataset(s).

Positional arguments:
  --input, --filename <FILENAME>                       File or directory name [may be repeated] [required]

Common Options:
  -h, --help                                           Display help message and exit
  --json-usage                                         Display usage as JSON document and exit
  --config <KEY>=<VALUE>                               Configuration option [may be repeated]
  -q, --quiet                                          Quiet mode (no progress bar or warning message)

Options:
  -o, --output <OUTPUT>                                Output vector dataset (created by algorithm)
  -f, --of, --format, --output-format <OUTPUT-FORMAT>  Output format
  --co, --creation-option <KEY>=<VALUE>                Creation option [may be repeated]
  --lco, --layer-creation-option <KEY>=<VALUE>         Layer creation option [may be repeated]
  -l, --output-layer <OUTPUT-LAYER>                    Output layer name
  --overwrite                                          Whether overwriting existing output dataset is allowed
  -r, --recursive                                      Recursively scan files/folders for datasets
  --force-recursive                                    Recursively scan folders for datasets, forcing recursion in folders recognized as valid formats
  --detailed                                           Most detailed output. Reports the presence of georeferencing, if a GeoTIFF file is cloud optimized, etc.
  --report-failures                                    Report failures if file type is unidentified

For more details, consult https://gdal.org/programs/gdal_dataset_identify.html

""" + WARNING,
    ("driver",): """Usage: gdal driver <SUBCOMMAND> [OPTIONS]
where <SUBCOMMAND> is one of:
  - cog: Command for COG driver specific operations.

Common Options:
  -h, --help              Display help message and exit
  --json-usage            Display usage as JSON document and exit
  --config <KEY>=<VALUE>  Configuration option [may be repeated]

""" + WARNING,
    ("driver", "cog"): """Usage: gdal driver cog <SUBCOMMAND> [OPTIONS]
where <SUBCOMMAND> is one of:
  - validate: Validate if a TIFF file is a Cloud Optimized GeoTIFF

Common Options:
  -h, --help              Display help message and exit
  --json-usage            Display usage as JSON document and exit
  --config <KEY>=<VALUE>  Configuration option [may be repeated]

For more details, consult https://gdal.org/drivers/raster/cog.html

""" + WARNING,
    ("mdim",): """Usage: gdal mdim <SUBCOMMAND> [OPTIONS]
where <SUBCOMMAND> is one of:
  - convert: Convert a multidimensional dataset.
  - info:    Return information on a multidimensional dataset.
  - mosaic:  Build a mosaic, either virtual (VRT) or materialized, from multidimensional datasets.

Common Options:
  -h, --help              Display help message and exit
  --json-usage            Display usage as JSON document and exit
  --config <KEY>=<VALUE>  Configuration option [may be repeated]

Options:
  --drivers               Display multidimensional driver list as JSON document

For more details, consult https://gdal.org/programs/gdal_mdim.html

""" + WARNING,
}

RASTER_HELP = """Usage: gdal raster <SUBCOMMAND> [OPTIONS]
where <SUBCOMMAND> is one of:
  - as-features:     Create features from pixels of a raster dataset
  - aspect:          Generate an aspect map
  - blend:           Blend/compose two raster datasets
  - calc:            Perform raster algebra
  - clean-collar:    Clean the collar of a raster dataset, removing noise.
  - clip:            Clip a raster dataset.
  - color-map:       Generate a RGB or RGBA dataset from a single band, using a color map
  - compare:         Compare two raster datasets.
  - contour:         Creates a vector contour from a raster elevation model (DEM).
  - convert:         Convert a raster dataset.
  - create:          Create a new raster dataset.
  - edit:            Edit a raster dataset.
  - fill-nodata:     Fill nodata raster regions by interpolation from edges.
  - footprint:       Compute the footprint of a raster dataset.
  - hillshade:       Generate a shaded relief map
  - index:           Create a vector index of raster datasets.
  - info:            Return information on a raster dataset.
  - mosaic:          Build a mosaic, either virtual (VRT) or materialized.
  - neighbors:       Compute the value of each pixel from its neighbors (focal statistics) (alias: neighbours)
  - nodata-to-alpha: Replace nodata value(s) with an alpha band.
  - overview:        Manage overviews of a raster dataset.
  - pansharpen:      Perform a pansharpen operation.
  - pipeline:        Process a raster dataset applying several steps.
  - pixel-info:      Return information on a pixel of a raster dataset.
  - polygonize:      Create a polygon feature dataset from a raster band.
  - proximity:       Produces a raster proximity map.
  - reclassify:      Reclassify values in a raster dataset
  - reproject:       Reproject a raster dataset.
  - resize:          Resize a raster dataset without changing the georeferenced extents.
  - rgb-to-palette:  Convert a RGB image into a pseudo-color / paletted image.
  - roughness:       Generate a roughness map
  - scale:           Scale the values of the bands of a raster dataset.
  - select:          Select a subset of bands from a raster dataset.
  - set-type:        Modify the data type of bands of a raster dataset.
  - sieve:           Remove small polygons from a raster dataset.
  - slope:           Generate a slope map
  - stack:           Combine together input bands into a multi-band output, either virtual (VRT) or materialized.
  - tile:            Generate tiles in separate files from a raster dataset.
  - tpi:             Generate a Topographic Position Index (TPI) map
  - tri:             Generate a Terrain Ruggedness Index (TRI) map
  - unscale:         Convert scaled values of a raster dataset into unscaled values.
  - update:          Update the destination raster with the content of the input one.
  - viewshed:        Compute the viewshed of a raster dataset.
  - zonal-stats:     Calculate raster zonal statistics

Common Options:
  -h, --help              Display help message and exit
  --json-usage            Display usage as JSON document and exit
  --config <KEY>=<VALUE>  Configuration option [may be repeated]

Options:
  --drivers               Display raster driver list as JSON document

For more details, consult https://gdal.org/programs/gdal_raster.html

""" + WARNING

VECTOR_HELP = """Usage: gdal vector <SUBCOMMAND> [OPTIONS]
where <SUBCOMMAND> is one of:
  - buffer:              Compute a buffer around geometries of a vector dataset.
  - check-coverage:      Check a polygon coverage for validity
  - check-geometry:      Check a dataset for invalid geometries
  - clean-coverage:      Alter polygon boundaries to make shared edges identical, removing gaps and overlaps
  - clip:                Clip a vector dataset.
  - combine:             Combine features into collections
  - concat:              Concatenate vector datasets.
  - concave-hull:        Compute the concave hull of geometries of a vector dataset.
  - convert:             Convert a vector dataset.
  - convex-hull:         Compute the convex hull of geometries of a vector dataset.
  - create:              Create a vector dataset.
  - dissolve:            Dissolves multipart features
  - edit:                Edit metadata of a vector dataset.
  - explode-collections: Explode geometries of type collection of a vector dataset.
  - export-schema:       Export the OGR_SCHEMA from a vector dataset.
  - filter:              Filter a vector dataset.
  - grid:                Create a regular grid from scattered points.
  - index:               Create a vector index of vector datasets.
  - info:                Return information on a vector dataset.
  - layer-algebra:       Perform algebraic operation between 2 layers.
  - make-point:          Create point geometries from attribute fields
  - make-valid:          Fix validity of geometries of a vector dataset.
  - partition:           Partition a vector dataset into multiple files.
  - pipeline:            Process a vector dataset applying several steps.
  - rasterize:           Burns vector geometries into a raster.
  - rename-layer:        Rename layer(s) of a vector dataset.
  - reproject:           Reproject a vector dataset.
  - segmentize:          Segmentize geometries of a vector dataset.
  - select:              Select a subset of fields from a vector dataset.
  - set-field-type:      Modify the type of a field of a vector dataset.
  - set-geom-type:       Modify the geometry type of a vector dataset.
  - simplify:            Simplify geometries of a vector dataset.
  - simplify-coverage:   Simplify shared boundaries of a polygonal vector dataset.
  - sort:                Spatially order the features in a layer
  - sql:                 Apply SQL statement(s) to a dataset.
  - swap-xy:             Swap X and Y coordinates of geometries of a vector dataset.
  - update:              Update an existing vector dataset with an input vector dataset.

Common Options:
  -h, --help              Display help message and exit
  --json-usage            Display usage as JSON document and exit
  --config <KEY>=<VALUE>  Configuration option [may be repeated]

Options:
  --drivers               Display vector driver list as JSON document and exit

For more details, consult https://gdal.org/programs/gdal_vector.html

""" + WARNING

HELP_TEXTS[("raster",)] = RASTER_HELP
HELP_TEXTS[("vector",)] = VECTOR_HELP

HELP_TEXTS[("raster", "info")] = """Usage: gdal raster info [OPTIONS] <INPUT>

Return information on a raster dataset.

Positional arguments:
  -i, --dataset, --input <INPUT>                       Input raster dataset [required]

Common Options:
  -h, --help                                           Display help message and exit
  --json-usage                                         Display usage as JSON document and exit
  --config <KEY>=<VALUE>                               Configuration option [may be repeated]

Options:
  -f, --of, --format, --output-format <OUTPUT-FORMAT>  Output format. OUTPUT-FORMAT=json|text
  --mm, --min-max                                      Compute minimum and maximum value
  --stats                                              Retrieve or compute statistics, using all pixels
                                                       Mutually exclusive with --approx-stats
  --approx-stats                                       Retrieve or compute statistics, using a subset of pixels
                                                       Mutually exclusive with --stats
  --hist                                               Retrieve or compute histogram

Advanced Options:
  --if, --input-format <INPUT-FORMAT>                  Input formats [may be repeated]
  --oo, --open-option <KEY>=<VALUE>                    Open options [may be repeated]
  --no-gcp                                             Suppress ground control points list printing
  --no-md                                              Suppress metadata printing
  --no-ct                                              Suppress color table printing
  --no-fl                                              Suppress file list printing
  --checksum                                           Compute pixel checksum
  --list-metadata-domains, --list-mdd                  List all metadata domains available for the dataset
  --mdd, --metadata-domain <METADATA-DOMAIN>           Report metadata for the specified domain. 'all' can be used to report metadata in all domains

Esoteric Options:
  --no-nodata                                          Suppress retrieving nodata value
  --no-mask                                            Suppress mask band information
  --subdataset <SUBDATASET>                            Use subdataset of specified index (starting at 1), instead of the source dataset itself
  --crs-format <CRS-FORMAT>                            Which format to use to report CRS. CRS-FORMAT=AUTO|WKT2|PROJJSON (default: AUTO)

For more details, consult https://gdal.org/programs/gdal_raster_info.html

""" + WARNING

HELP_TEXTS[("vector", "info")] = """Usage: gdal vector info [OPTIONS] <INPUT>...

Return information on a vector dataset.

Positional arguments:
  -i, --dataset, --input <INPUT>                       Input vector datasets [may be repeated] [required]

Common Options:
  -h, --help                                           Display help message and exit
  --json-usage                                         Display usage as JSON document and exit
  --config <KEY>=<VALUE>                               Configuration option [may be repeated]

Options:
  -f, --of, --format, --output-format <OUTPUT-FORMAT>  Output format. OUTPUT-FORMAT=json|text
  -l, --layer, --input-layer <INPUT-LAYER>             Input layer name [may be repeated]
                                                       Mutually exclusive with --sql, --fid
  --features                                           List all features (beware of RAM consumption on large layers)
                                                       Mutually exclusive with --summary
  --summary                                            List the layer names and the geometry type
                                                       Mutually exclusive with --features
  --limit <FEATURE-COUNT>                              Limit the number of features per layer (implies --features)
  --sql <statement>|@<filename>                        Execute the indicated SQL statement and return the result
                                                       Mutually exclusive with --input-layer, --fid
  --where <WHERE>|@<filename>                          Attribute query in a restricted form of the queries used in the SQL WHERE statement
  --fid <FID>                                          Feature identifier
                                                       Mutually exclusive with --input-layer, --sql
  --dialect <DIALECT>                                  SQL dialect

Advanced Options:
  --oo, --open-option <KEY>=<VALUE>                    Open options [may be repeated]
  --if, --input-format <INPUT-FORMAT>                  Input formats [may be repeated]

Esoteric Options:
  --crs-format <CRS-FORMAT>                            Which format to use to report CRS. CRS-FORMAT=AUTO|WKT2|PROJJSON (default: AUTO)

For more details, consult https://gdal.org/programs/gdal_vector_info.html

""" + WARNING

HELP_TEXTS[("vsi",)] = """Usage: gdal vsi <SUBCOMMAND> [OPTIONS]
where <SUBCOMMAND> is one of:
  - copy:   Copy files located on GDAL Virtual System Interface (VSI). (alias: cp)
  - delete: Delete files located on GDAL Virtual System Interface (VSI). (alias: rm, rmdir, del)
  - list:   List files of one of the GDAL Virtual System Interface (VSI). (alias: ls)
  - move:   Move/rename a file/directory located on GDAL Virtual System Interface (VSI). (alias: mv, ren, rename)
  - sozip:  Seek-optimized ZIP (SOZIP) commands.
  - sync:   Synchronize source and target file/directory located on GDAL Virtual System Interface (VSI).

Common Options:
  -h, --help              Display help message and exit
  --json-usage            Display usage as JSON document and exit
  --config <KEY>=<VALUE>  Configuration option [may be repeated]

For more details, consult https://gdal.org/programs/gdal_vsi.html

""" + WARNING

HELP_TEXTS[("vsi", "list")] = """Usage: gdal vsi list [OPTIONS] <FILENAME>

List files of one of the GDAL Virtual System Interface (VSI).

Positional arguments:
  --filename <FILENAME>                                File or directory name [required]

Common Options:
  -h, --help                                           Display help message and exit
  --json-usage                                         Display usage as JSON document and exit
  --config <KEY>=<VALUE>                               Configuration option [may be repeated]

Options:
  -f, --of, --format, --output-format <OUTPUT-FORMAT>  Output format. OUTPUT-FORMAT=json|text
  -l, --long, --long-listing                           Use a long listing format
  -R, --recursive                                      List subdirectories recursively
  --depth <DEPTH>                                      Maximum depth in recursive mode
  --abs, --absolute-path                               Display absolute path
  --tree                                               Use a hierarchical presentation for JSON output

For more details, consult https://gdal.org/programs/gdal_vsi_list.html

""" + WARNING

HELP_TEXTS[("pipeline",)] = """Usage: gdal pipeline [OPTIONS] <PIPELINE>

Process a dataset applying several steps.

Positional arguments:

Common Options:
  -h, --help                        Display help message and exit
  --json-usage                      Display usage as JSON document and exit
  --config <KEY>=<VALUE>            Configuration option [may be repeated]
  -q, --quiet                       Quiet mode (no progress bar or warning message)

Advanced Options:
  --<user-provided-option>=<value>  Argument provided by user

<PIPELINE> is of the form: read|calc|concat|create|mosaic|stack [READ-OPTIONS] ( ! <STEP-NAME> [STEP-OPTIONS] )* ! write!info!tile [WRITE-OPTIONS]

Example: 'gdal pipeline --progress ! read in.tif ! \\
               rasterize --size 256 256 ! buffer 20 ! write out.gpkg --overwrite'

Potential steps are:

* read [OPTIONS] <INPUT>
------------------------

Read a raster dataset.

Positional arguments:
  -i, --input <INPUT>                                              Input raster datasets [required]

Advanced Options:
  --if, --input-format <INPUT-FORMAT>                              Input formats [may be repeated]
  --oo, --open-option <KEY>=<VALUE>                                Open options [may be repeated]

For more details, consult https://gdal.org/programs/gdal_raster_pipeline.html

* read [OPTIONS] <INPUT>
------------------------

Read a vector dataset.

Positional arguments:
  -i, --input <INPUT>                                              Input vector datasets [required]

Options:
  -l, --layer, --input-layer <INPUT-LAYER>                         Input layer name(s) [may be repeated]

Advanced Options:
  --if, --input-format <INPUT-FORMAT>                              Input formats [may be repeated]
  --oo, --open-option <KEY>=<VALUE>                                Open options [may be repeated]

For more details, consult https://gdal.org/programs/gdal_vector_pipeline.html

""" + WARNING

DRIVERS = [
    {"short_name": "GTiff", "long_name": "GeoTIFF", "scopes": ["raster"], "capabilities": ["open", "create", "create_copy", "update", "virtual_io"], "file_extensions": ["tif", "tiff"]},
    {"short_name": "COG", "long_name": "Cloud optimized GeoTIFF generator", "scopes": ["raster"], "capabilities": ["create", "create_copy", "virtual_io"], "file_extensions": ["tif", "tiff"]},
    {"short_name": "VRT", "long_name": "Virtual Raster", "scopes": ["raster", "multidimensional_raster"], "capabilities": ["open", "create", "create_copy", "update", "virtual_io"], "file_extensions": ["vrt"]},
    {"short_name": "MEM", "long_name": "In Memory raster, vector and multidimensional raster", "scopes": ["raster", "multidimensional_raster", "vector"], "capabilities": ["open", "create"]},
    {"short_name": "ESRI Shapefile", "long_name": "ESRI Shapefile", "scopes": ["vector"], "capabilities": ["open", "create", "update", "virtual_io"], "file_extensions": ["shp", "dbf", "shz", "shp.zip"]},
    {"short_name": "GeoJSON", "long_name": "GeoJSON", "scopes": ["vector"], "capabilities": ["open", "create", "update", "virtual_io"], "file_extensions": ["json", "geojson"]},
    {"short_name": "CSV", "long_name": "Comma Separated Value (.csv)", "scopes": ["vector"], "capabilities": ["open", "create", "update", "virtual_io"], "file_extensions": ["csv"]},
    {"short_name": "GPKG", "long_name": "GeoPackage", "scopes": ["raster", "vector"], "capabilities": ["open", "create", "create_copy", "update", "virtual_io"], "file_extensions": ["gpkg"]},
    {"short_name": "netCDF", "long_name": "Network Common Data Format", "scopes": ["raster", "multidimensional_raster"], "capabilities": ["open", "create", "create_copy"], "file_extensions": ["nc"]},
]


def emit(text, status=0):
    print(text)
    return status


def compact_json(obj):
    print(json.dumps(obj, indent=2, separators=(",", ":")))
    return 0


def usage_json(path):
    names = ["dataset", "driver", "info", "mdim", "pipeline", "raster", "vector", "vsi"]
    if path:
        return {"name": path[-1], "full_path": ["gdal"] + path, "description": describe(path), "sub_algorithms": []}
    return {
        "description": "Main gdal entry point.",
        "short_url": "/programs/index.html",
        "url": "https://gdal.org/programs/index.html",
        "sub_algorithms": [{"name": n, "full_path": ["gdal", n], "description": describe((n,)), "sub_algorithms": []} for n in names],
    }


def describe(path):
    descriptions = {
        ("dataset",): "Commands to manage datasets.",
        ("driver",): "Command for driver specific operations.",
        ("info",): "Return information on a dataset (shortcut for 'gdal raster info' or 'gdal vector info').",
        ("mdim",): "Multidimensional commands.",
        ("pipeline",): "Process a dataset applying several steps.",
        ("raster",): "Raster commands.",
        ("vector",): "Vector commands.",
        ("vsi",): "GDAL Virtual System Interface (VSI) commands.",
    }
    return descriptions.get(tuple(path), "")


def drivers_for(scope):
    if not scope:
        return DRIVERS
    if scope == "mdim":
        scope = "multidimensional_raster"
    return [d for d in DRIVERS if scope in d.get("scopes", [])]


def split_options(args):
    stripped = []
    skip_next = False
    for i, arg in enumerate(args):
        if skip_next:
            skip_next = False
            continue
        if arg == "--config":
            skip_next = True
            continue
        if arg.startswith("--config="):
            continue
        stripped.append(arg)
    return stripped


def show_help_for(path):
    key = tuple(path)
    if key in HELP_TEXTS:
        return emit(HELP_TEXTS[key])
    if len(path) >= 2 and path[0] in {"raster", "vector", "mdim"}:
        subject = path[0]
        action = path[1]
        return emit(f"""Usage: gdal {subject} {action} [OPTIONS] <INPUT> <OUTPUT>

{describe((subject,)) or action.title()}.

Common Options:
  -h, --help              Display help message and exit
  --json-usage            Display usage as JSON document and exit
  --config <KEY>=<VALUE>  Configuration option [may be repeated]

For more details, consult https://gdal.org/programs/gdal_{subject}_{action}.html

{WARNING}""")
    return None


def vsi_list(args):
    fmt = "text"
    recursive = False
    absolute = False
    path = None
    i = 0
    while i < len(args):
        arg = args[i]
        if arg in ("-f", "--of", "--format", "--output-format"):
            i += 1
            fmt = args[i] if i < len(args) else fmt
        elif arg.startswith("--format=") or arg.startswith("--output-format="):
            fmt = arg.split("=", 1)[1]
        elif arg in ("-R", "--recursive"):
            recursive = True
        elif arg in ("--abs", "--absolute-path"):
            absolute = True
        elif not arg.startswith("-"):
            path = arg
        i += 1
    if path is None:
        print("ERROR 1: list: Positional arguments starting at 'FILENAME' have not been specified.")
        print("Usage: gdal vsi list [OPTIONS] <FILENAME>")
        print("Try 'gdal vsi list --help' for help.")
        return 1
    p = Path(path)
    if not p.exists():
        print(f"ERROR 4: {path}: No such file or directory")
        return 1
    entries = []
    if p.is_dir():
        if recursive:
            for root, dirs, files in os.walk(p):
                for name in sorted(dirs + files):
                    ep = Path(root) / name
                    entries.append(str(ep.resolve() if absolute else ep))
        else:
            entries = sorted(os.listdir(p))
            if absolute:
                entries = [str((p / e).resolve()) for e in entries]
    else:
        entries = [str(p.resolve() if absolute else p)]
    if fmt == "json":
        return compact_json([{"name": e} for e in entries])
    for e in entries:
        print(e)
    return 0


def infer_driver(path):
    lower = path.lower()
    mapping = {
        ".tif": "GTiff",
        ".tiff": "GTiff",
        ".vrt": "VRT",
        ".shp": "ESRI Shapefile",
        ".dbf": "ESRI Shapefile",
        ".geojson": "GeoJSON",
        ".json": "GeoJSON",
        ".csv": "CSV",
        ".gpkg": "GPKG",
        ".nc": "netCDF",
    }
    for ext, driver in mapping.items():
        if lower.endswith(ext):
            return driver
    return None


def dataset_identify(args):
    report = "--report-failures" in args
    detailed = "--detailed" in args
    json_out = False
    files = []
    i = 0
    while i < len(args):
        arg = args[i]
        if arg in ("-f", "--of", "--format", "--output-format"):
            i += 1
            json_out = i < len(args) and args[i] == "json"
        elif arg.startswith("--format=") or arg.startswith("--output-format="):
            json_out = arg.split("=", 1)[1] == "json"
        elif arg in ("--report-failures", "--detailed", "-q", "--quiet", "-r", "--recursive", "--force-recursive", "--overwrite"):
            pass
        elif arg.startswith("-"):
            if arg in ("-o", "--output", "--co", "--creation-option", "--lco", "--layer-creation-option", "-l", "--output-layer", "--input", "--filename"):
                i += 1
                if arg in ("--input", "--filename") and i < len(args):
                    files.append(args[i])
        else:
            files.append(arg)
        i += 1
    results = []
    for f in files:
        driver = infer_driver(f)
        if driver:
            item = {"filename": f, "driver": driver}
            if detailed:
                item["details"] = {}
            results.append(item)
            if not json_out:
                print(f"{f}: {driver}")
        elif report and not json_out:
            print(f"{f}: unrecognized")
    if json_out:
        return compact_json(results)
    return 0


def info_command(args, mode="info"):
    fmt = "json"
    inputs = []
    i = 0
    while i < len(args):
        arg = args[i]
        if arg in ("-f", "--of", "--format", "--output-format"):
            i += 1
            if i < len(args):
                fmt = args[i]
        elif arg.startswith("--format=") or arg.startswith("--output-format="):
            fmt = arg.split("=", 1)[1]
        elif arg in ("-i", "--dataset", "--input"):
            i += 1
            if i < len(args):
                inputs.append(args[i])
        elif not arg.startswith("-"):
            inputs.append(arg)
        i += 1
    usage = "gdal info [OPTIONS] <INPUT>" if mode == "info" else f"gdal {mode} info [OPTIONS] <INPUT>{'...' if mode == 'vector' else ''}"
    if not inputs:
        print("ERROR 1: info: Positional arguments starting at 'INPUT' have not been specified.")
        print(f"Usage: {usage}")
        print(f"Try '{usage.split(' [', 1)[0]} --help' for help.")
        return 1
    path = inputs[0]
    if not os.path.exists(path):
        print(f"ERROR 4: {path}: No such file or directory")
        print(f"Usage: {usage}")
        print(f"Try '{usage.split(' [', 1)[0]} --help' for help.")
        return 1
    driver = infer_driver(path)
    if not driver:
        q = f"`{path}'" if mode in {"raster", "vector"} else path
        print(f"ERROR 4: {q} not recognized as being in a supported file format.")
        print(f"Usage: {usage}")
        print(f"Try '{usage.split(' [', 1)[0]} --help' for help.")
        return 1
    if fmt == "text":
        print(f"Driver: {driver}")
        print(f"Files: {path}")
    else:
        compact_json({"description": path, "driverShortName": driver, "files": [path]})
    return 0


def copy_file(args, move=False):
    vals = [a for a in args if not a.startswith("-")]
    if len(vals) < 2:
        action = "move" if move else "copy"
        print(f"ERROR 1: {action}: Not enough positional arguments.")
        return 1
    src, dst = vals[-2], vals[-1]
    if move:
        shutil.move(src, dst)
    else:
        if os.path.isdir(src):
            shutil.copytree(src, dst, dirs_exist_ok=True)
        else:
            shutil.copy2(src, dst)
    return 0


def main(argv):
    args = split_options(argv[1:])
    if not args:
        print("ERROR 1: gdal: Missing command name.")
        print(TOP_HELP_ERROR)
        return 1
    if args[0] in ("-h", "--help", "help") or args[0] == "--help=true":
        return emit(TOP_HELP)
    if args[0].startswith("--help=") and args[0] not in ("--help=true", "--help=false"):
        print(f"ERROR 5: gdal: Invalid value '{args[0].split('=', 1)[1]}' for boolean argument '--help'. Should be 'true' or 'false'.")
        print(TOP_HELP_ERROR)
        return 1
    if args[0] == "--version":
        return emit(VERSION_TEXT)
    if args[0] == "--drivers":
        return compact_json(DRIVERS)
    if args[0] == "--json-usage":
        return compact_json(usage_json(()))
    if args[0].startswith("-"):
        print(f"ERROR 5: gdal: Option '{args[0]}' is unknown.")
        print(TOP_HELP_ERROR)
        return 1

    cmd = args[0]
    rest = args[1:]
    if rest and rest[-1] in ("-h", "--help") or rest and rest[0] in ("-h", "--help"):
        help_path = [cmd] + [a for a in rest if not a.startswith("-")]
        shown = show_help_for(help_path)
        if shown is not None:
            return shown
    if "--json-usage" in rest:
        json_path = [cmd] + [a for a in rest if not a.startswith("-")]
        return compact_json(usage_json(tuple(json_path)))
    if cmd in {"raster", "vector", "mdim"} and rest and rest[0] == "--drivers":
        return compact_json(drivers_for(cmd))
    if cmd in {"raster", "vector", "mdim", "dataset", "driver", "vsi"} and not rest:
        print(f"ERROR 1: {cmd}: Missing subcommand name.")
        shown = show_help_for([cmd])
        return 1 if shown is not None else 1
    if cmd == "info":
        return info_command(rest, "info")
    if cmd == "pipeline":
        if not rest:
            print("ERROR 1: pipeline: Positional arguments starting at 'PIPELINE' have not been specified.")
            print("Usage: gdal pipeline [OPTIONS] <PIPELINE>")
            print("Try 'gdal pipeline --help' for help.")
            return 1
        print("ERROR 6: pipeline execution is not supported by this clean-room reimplementation.")
        print("Usage: gdal pipeline [OPTIONS] <PIPELINE>")
        print("Try 'gdal pipeline --help' for help.")
        return 1
    if cmd in {"raster", "vector"} and rest and rest[0] == "info":
        if len(rest) > 1 and rest[1] in ("-h", "--help"):
            return show_help_for([cmd, "info"])
        return info_command(rest[1:], cmd)
    if cmd == "dataset" and rest:
        sub = rest[0]
        if sub in {"identify"}:
            return dataset_identify(rest[1:])
        if sub in {"copy", "cp"}:
            return copy_file(rest[1:])
        if sub in {"rename", "ren", "mv"}:
            return copy_file(rest[1:], move=True)
        if sub in {"delete", "rm", "remove"}:
            for f in [a for a in rest[1:] if not a.startswith("-")]:
                if os.path.isdir(f):
                    shutil.rmtree(f)
                elif os.path.exists(f):
                    os.remove(f)
            return 0
    if cmd == "vsi" and rest:
        sub = rest[0]
        if sub in {"list", "ls"}:
            return vsi_list(rest[1:])
        if sub in {"copy", "cp"}:
            return copy_file(rest[1:])
        if sub in {"move", "mv", "ren", "rename"}:
            return copy_file(rest[1:], move=True)
        if sub in {"delete", "rm", "rmdir", "del"}:
            for f in [a for a in rest[1:] if not a.startswith("-")]:
                if os.path.isdir(f):
                    shutil.rmtree(f)
                elif os.path.exists(f):
                    os.remove(f)
            return 0
    if cmd == "convert":
        vals = [a for a in rest if not a.startswith("-")]
        if len(vals) >= 2 and os.path.exists(vals[-2]):
            shutil.copy2(vals[-2], vals[-1])
            return 0
        if not vals:
            print("ERROR 1: convert: Positional arguments starting at 'INPUT' have not been specified.")
        else:
            print(f"ERROR 4: {vals[0]}: No such file or directory")
        print("Usage: gdal convert [OPTIONS] <INPUT> <OUTPUT>")
        print("Try 'gdal convert --help' for help.")
        return 1
    if os.path.exists(cmd):
        return info_command([cmd], "info")
    print(f"ERROR 1: gdal: Unknown command: '{cmd}'")
    print(TOP_HELP_ERROR)
    return 1


if __name__ == "__main__":
    sys.exit(main(sys.argv))
