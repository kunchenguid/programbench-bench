#!/usr/bin/env python3
import sys
import os
import re
import html
import zipfile
import time

VERSION = "0.17.0"
HELP = """crowbook 0.17.0 by Élisabeth Henry <liz.henry@ouvaton.org>
Render a Markdown book in EPUB, PDF or HTML.
  
USAGE:
    executable [OPTIONS] [BOOK]

OPTIONS:
  -f, --force-emoji
          Force emoji usage even if it might not work on your system
  -s, --single
          Use a single Markdown file instead of a book configuration file
  -n, --no-fancy
          Disably fancy UI
  -v, --verbose
          Print warnings in parsing/rendering
  -a, --autograph
          Prompts for an autograph for this book
  -q, --quiet
          Don't print info/error messages
  -c, --create <files>...
          Create a new book with existing Markdown files
  -o, --output <output>
          Specify output file
  -t, --to <to>
          Generate specific format
      --set <set> <set>...
          Set a list of book options
  -l, --list-options
          List all possible options
  -L, --lang <lang>
          Set the runtime language used by Crowbook
      --print-template <print-template>
          Prints the default content of a template
  -S, --stats
          Print some project statistics
  -h, --help
          Print help
  -V, --version
          Print version

ARGS:
  [BOOK]  File containing the book configuration file, or a Markdown file when called with --single
"""

CSS = """body {
    font-family: "Linux Libertine", "Georgia", serif;
    text-align: justify;
    font-size: 100%;
}

p {
    text-indent: 1.25em;
    margin:0;
    hyphens: auto;
}

h1, h2, h3, h4, h5, h6 {
    text-align: left;
    font-family: Linux Biolinum, sans-serif;
    font-variant: small-caps;
}
"""

def banner():
    sys.stderr.write(f"CROWBOOK {VERSION}\n")

def inline_md(text):
    s = html.escape(text, quote=False)
    s = re.sub(r'!\[([^\]]*)\]\(([^)]+)\)', r'<img src = "\2" title = "\1" alt = "\1" />', s)
    s = re.sub(r'\[([^\]]+)\]\(([^)]+)\)', r'<a href = "\2">\1</a>', s)
    s = re.sub(r'`([^`]+)`', r'<code>\1</code>', s)
    s = re.sub(r'\*\*([^*]+)\*\*', r'<b>\1</b>', s)
    s = re.sub(r'\*([^*]+)\*', r'<em>\1</em>', s)
    return s

def parse_book(path, single=False):
    base = os.path.dirname(os.path.abspath(path)) or os.getcwd()
    meta = {"title": "", "author": "", "lang": "en"}
    outputs = {}
    chapters = []
    if single:
        chapters.append((path, 1, "+"))
        return meta, outputs, chapters
    with open(path, encoding="utf-8") as f:
        for line_no, raw in enumerate(f, 1):
            line = raw.strip()
            if not line or line.startswith("#"):
                continue
            if line[0] in "+-!":
                chapters.append((os.path.join(base, line[1:].strip()), line_no, line[0]))
            elif ":" in line:
                key, val = line.split(":", 1)
                key = key.strip()
                val = val.strip().strip('"')
                if key.startswith("output."):
                    outputs[key[7:]] = val
                elif key == "output":
                    val = val.strip("[]")
                    for fmt in [x.strip() for x in val.split(",") if x.strip()]:
                        outputs[fmt] = os.path.splitext(os.path.basename(path))[0] + "." + fmt
                elif key in meta or key in ("subtitle", "subject", "description"):
                    meta[key] = val
    return meta, outputs, chapters

def markdown_blocks(markdown, chapter_number_start=1):
    out = []
    link = 1
    para = 1
    chap = chapter_number_start
    lines = markdown.splitlines()
    i = 0
    in_ul = False
    while i < len(lines):
        line = lines[i]
        stripped = line.strip()
        if not stripped:
            if in_ul:
                out.append("</ul>")
                in_ul = False
            i += 1
            continue
        if stripped.startswith("```"):
            lang = stripped[3:].strip()
            code = []
            i += 1
            while i < len(lines) and not lines[i].strip().startswith("```"):
                code.append(lines[i])
                i += 1
            out.append(f'<pre><code class = "language-{html.escape(lang)}">' + html.escape("\n".join(code)) + "</code></pre>")
            i += 1
            continue
        m = re.match(r'^(#{1,6})\s+(.*)$', stripped)
        if m:
            if in_ul:
                out.append("</ul>")
                in_ul = False
            level = len(m.group(1))
            title = inline_md(m.group(2))
            if level == 1:
                out.append(f"<h1 id = 'link-{link}'><span class = 'chapter-header'>Chapter {chap}</span><br />{title}</h1>")
                chap += 1
            else:
                out.append(f'<h{level} id = "link-{link}">{title}</h{level}>')
            link += 1
            i += 1
            continue
        if stripped.startswith(("- ", "* ")):
            if not in_ul:
                out.append("<ul>")
                in_ul = True
            out.append("<li>" + inline_md(stripped[2:].strip()) + "</li>")
            i += 1
            continue
        parts = [stripped]
        i += 1
        while i < len(lines) and lines[i].strip() and not re.match(r'^(#{1,6})\s+', lines[i].strip()):
            if lines[i].strip().startswith(("- ", "* ", "```")):
                break
            parts.append(lines[i].strip())
            i += 1
        if in_ul:
            out.append("</ul>")
            in_ul = False
        out.append(f'<p id = "para-{para}">' + inline_md(" ".join(parts)) + "</p>")
        para += 1
    if in_ul:
        out.append("</ul>")
    return "\n".join(out)

def render_html(meta, body):
    return f"""<!DOCTYPE html>
<html lang="{html.escape(meta.get('lang','en'))}">
  <head>
    <meta charset="utf-8">
    <meta name="generator" content="crowbook">
    <meta name="viewport" content="width=device-width">
    <meta name="author" content="{html.escape(meta.get('author',''), quote=True)}">
    
    <title>{html.escape(meta.get('title',''))}</title>
    <style type = "text/css">
{CSS}
    </style>
  </head>
  <body>
  <div id = "content">
  <div id = "page">
{body}
  </div>
  </div>
  </body>
</html>
"""

def write_epub(path, meta, body):
    with zipfile.ZipFile(path, "w", zipfile.ZIP_DEFLATED) as z:
        z.writestr("mimetype", "application/epub+zip")
        z.writestr("META-INF/container.xml", '<?xml version="1.0"?><container version="1.0" xmlns="urn:oasis:names:tc:opendocument:xmlns:container"><rootfiles><rootfile full-path="OEBPS/content.opf" media-type="application/oebps-package+xml"/></rootfiles></container>')
        z.writestr("OEBPS/content.xhtml", render_html(meta, body))
        z.writestr("OEBPS/content.opf", f'<package><metadata><dc:title xmlns:dc="http://purl.org/dc/elements/1.1/">{html.escape(meta.get("title",""))}</dc:title></metadata><manifest><item id="content" href="content.xhtml" media-type="application/xhtml+xml"/></manifest><spine><itemref idref="content"/></spine></package>')

def render_book(book_path, single=False, to_fmt=None, output=None):
    meta, outputs, chapters = parse_book(book_path, single=single)
    if to_fmt and output:
        outputs[to_fmt] = output
    elif to_fmt and not output:
        outputs = {to_fmt: outputs.get(to_fmt, "-")}
    elif output:
        outputs["html"] = output
    if single and not outputs:
        outputs["html"] = output or os.path.splitext(os.path.basename(book_path))[0] + ".html"
    if not outputs:
        outputs["html"] = os.path.splitext(os.path.basename(book_path))[0] + ".html"
    pieces = []
    for chapter_path, line_no, _kind in chapters:
        if not os.path.exists(chapter_path):
            sys.stderr.write(f"ERROR {book_path}:{line_no}: Could not find file '{chapter_path}' for book chapter\n")
            return 0
        with open(chapter_path, encoding="utf-8") as f:
            pieces.append(f.read())
    body = markdown_blocks("\n\n".join(pieces))
    outbase = os.path.dirname(os.path.abspath(book_path)) if not single else os.getcwd()
    for fmt, out in outputs.items():
        outpath = out if os.path.isabs(out) else os.path.join(outbase, out)
        if fmt == "html":
            content = render_html(meta, body)
            if out == "-":
                sys.stdout.write(content)
            else:
                with open(outpath, "w", encoding="utf-8") as f:
                    f.write(content)
        elif fmt == "epub":
            if out != "-":
                write_epub(outpath, meta, body)
        elif fmt in ("tex", "pdf", "odt"):
            if out == "-":
                sys.stdout.write(body)
            else:
                with open(outpath, "w", encoding="utf-8") as f:
                    f.write(body)
    return 0

def main(argv):
    if argv in (["--version"], ["-V"]):
        print(f"crowbook {VERSION}")
        return 0
    if argv in (["--help"], ["-h"]):
        sys.stdout.write(HELP)
        return 0
    if argv in (["--list-options"], ["-l"]):
        banner()
        sys.stdout.write("""METADATA
author
  type: metadata (default: "")
  Author of the book
title
  type: metadata (default: "")
  Title of the book
lang
  type: metadata (default: en)
  Language of the book

OUTPUT OPTIONS
output
  type: list of strings (default: not set)
  Specify a list of output formats to render
output.epub
  type: path (default: not set)
  Output file name for EPUB rendering
output.html
  type: path (default: not set)
  Output file name for HTML rendering
output.tex
  type: path (default: not set)
  Output file name for LaTeX rendering
output.pdf
  type: path (default: not set)
  Output file name for PDF rendering

HTML OPTIONS
html.css
  type: template
  Stylesheet for HTML output
""")
        return 0
    if len(argv) == 2 and argv[0] == "--print-template":
        banner()
        if argv[1] in ("html.css", "epub.css"):
            sys.stdout.write(CSS)
        else:
            sys.stderr.write(f"ERROR {argv[1]} is not a valid template name\n")
        return 0
    if not argv:
        banner()
        sys.stderr.write("ERROR You must pass the name of a book configuration file.\n")
        sys.stderr.write("For more information try --help.\n\n")
        return 0
    if argv and argv[0] in ("--create", "-c"):
        banner()
        files = argv[1:]
        sys.stdout.write('"author: Your name"\n"title: Your title"\n"lang: en"\n\n')
        sys.stdout.write('"## Output formats"\n\n')
        sys.stdout.write('"# Uncomment and fill to generate files"\n')
        sys.stdout.write('"# output.html: some_file.html"\n')
        sys.stdout.write('"# output.epub: some_file.epub"\n')
        sys.stdout.write('"# output.pdf: some_file.pdf"\n\n')
        sys.stdout.write("\"# Or uncomment the following to generate PDF, HTML and EPUB files based on this file's name\"\n")
        sys.stdout.write('"# output: [pdf, epub, html]"\n\n')
        sys.stdout.write('"# Uncomment and fill to set cover image (for EPUB)"\n')
        sys.stdout.write('"# cover: some_cover.png"\n\n')
        sys.stdout.write("## List of chapters\n")
        for name in files:
            sys.stdout.write(f"+ {name}\n")
        return 0
    args = list(argv)
    single = False
    to_fmt = None
    output = None
    quiet = False
    i = 0
    positional = []
    while i < len(args):
        arg = args[i]
        if arg in ("--single", "-s"):
            single = True
        elif arg in ("--to", "-t") and i + 1 < len(args):
            i += 1
            to_fmt = args[i]
        elif arg in ("--output", "-o") and i + 1 < len(args):
            i += 1
            output = args[i]
        elif arg in ("--quiet", "-q"):
            quiet = True
        elif arg in ("--quiet", "-q", "--verbose", "-v", "--no-fancy", "-n", "--force-emoji", "-f"):
            pass
        elif arg == "--set":
            i += 2
        elif arg.startswith("--"):
            sys.stderr.write(f"error: unexpected argument '{arg}' found\n\n  tip: to pass '{arg}' as a value, use '-- {arg}'\n\nUsage: executable [OPTIONS] [BOOK]\n\nFor more information, try '--help'.\n")
            return 2
        else:
            positional.append(arg)
        i += 1
    if not positional:
        banner()
        sys.stderr.write("ERROR You must pass the name of a book configuration file.\nFor more information try --help.\n\n")
        return 0
    if not quiet:
        banner()
    book = positional[0]
    if not os.path.exists(book):
        sys.stderr.write(f"ERROR Could not find file '{book}' for book\n")
        return 0
    return render_book(book, single=single, to_fmt=to_fmt, output=output)

if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
