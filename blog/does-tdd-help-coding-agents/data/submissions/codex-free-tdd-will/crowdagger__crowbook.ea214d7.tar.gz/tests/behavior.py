#!/usr/bin/env python3
import os, subprocess, tempfile, pathlib, textwrap, sys
ROOT = pathlib.Path(__file__).resolve().parents[1]
BIN = ROOT / "executable"

def run(args, cwd=None, input=None):
    return subprocess.run([str(BIN)] + args, cwd=cwd or ROOT, input=input, text=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)

def assert_eq(a,b):
    if a != b:
        raise AssertionError(f"expected {b!r}, got {a!r}")

def assert_contains(s, sub):
    if sub not in s:
        raise AssertionError(f"missing {sub!r} in {s[:500]!r}")

def test_version():
    r = run(["--version"])
    assert_eq(r.returncode, 0)
    assert_eq(r.stdout, "crowbook 0.17.0\n")
    assert_eq(r.stderr, "")

def test_no_book_prints_reference_error_to_stderr():
    r = run([])
    assert_eq(r.returncode, 0)
    assert_eq(r.stdout, "")
    assert_eq(r.stderr, "CROWBOOK 0.17.0\nERROR You must pass the name of a book configuration file.\nFor more information try --help.\n\n")

def test_help_text_matches_reference_usage():
    r = run(["--help"])
    assert_eq(r.returncode, 0)
    assert_contains(r.stdout, "crowbook 0.17.0 by")
    assert_contains(r.stdout, "USAGE:\n    executable [OPTIONS] [BOOK]")
    assert_contains(r.stdout, "  -s, --single\n          Use a single Markdown file instead of a book configuration file")
    assert_contains(r.stdout, "  -t, --to <to>\n          Generate specific format")
    assert_eq(r.stderr, "")

def test_create_prints_book_configuration_for_markdown_files():
    with tempfile.TemporaryDirectory() as d:
        p = pathlib.Path(d)
        (p / "a.md").write_text("# A\n")
        (p / "b.md").write_text("# B\n")
        r = run(["--create", "a.md", "b.md"], cwd=p)
    assert_eq(r.returncode, 0)
    assert_contains(r.stdout, '"author: Your name"\n"title: Your title"\n"lang: en"')
    assert_contains(r.stdout, "## List of chapters\n+ a.md\n+ b.md\n")
    assert_eq(r.stderr, "CROWBOOK 0.17.0\n")

def test_book_config_generates_basic_html_file():
    with tempfile.TemporaryDirectory() as d:
        p = pathlib.Path(d)
        (p / "ch1.md").write_text("# Chapter One\n\nHello *world* and **bold**.\n\n## Sub\n\nText\n")
        (p / "book.book").write_text("title: My Book\nauthor: Jane\nlang: en\noutput.html: out.html\n+ ch1.md\n")
        r = run(["book.book"], cwd=p)
        html = (p / "out.html").read_text()
    assert_eq(r.returncode, 0)
    assert_eq(r.stdout, "")
    assert_eq(r.stderr, "CROWBOOK 0.17.0\n")
    assert_contains(html, '<html lang="en">')
    assert_contains(html, '<meta name="author" content="Jane">')
    assert_contains(html, '<title>My Book</title>')
    assert_contains(html, '<h1 id = \'link-1\'><span class = \'chapter-header\'>Chapter 1</span><br />Chapter One</h1>')
    assert_contains(html, '<p id = "para-1">Hello <em>world</em> and <b>bold</b>.</p>')
    assert_contains(html, '<h2 id = "link-2">Sub</h2>')

def test_missing_chapter_error_mentions_book_line_and_resolved_path():
    with tempfile.TemporaryDirectory() as d:
        p = pathlib.Path(d)
        (p / "book.book").write_text("title: Test\n\n+ missing.md\n")
        r = run(["book.book"], cwd=p)
    assert_eq(r.returncode, 0)
    assert_eq(r.stdout, "")
    assert_contains(r.stderr, "CROWBOOK 0.17.0\nERROR book.book:3: Could not find file '")
    assert_contains(r.stderr, "missing.md' for book chapter\n")

def main():
    tests=[test_version, test_no_book_prints_reference_error_to_stderr, test_help_text_matches_reference_usage, test_create_prints_book_configuration_for_markdown_files, test_book_config_generates_basic_html_file, test_missing_chapter_error_mentions_book_line_and_resolved_path]
    for t in tests:
        t()
        print(f"ok {t.__name__}")
if __name__ == "__main__": main()
