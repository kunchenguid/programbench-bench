#!/bin/bash
set -e
cp src/pb_ffmpeg.py executable
chmod +x executable
