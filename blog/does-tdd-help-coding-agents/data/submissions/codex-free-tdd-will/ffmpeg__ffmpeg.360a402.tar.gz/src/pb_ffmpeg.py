#!/usr/bin/env python3
import sys
import hashlib
from pathlib import Path

VERSION = """ffmpeg version git-2026-04-13-10ea080 Copyright (c) 2000-2026 the FFmpeg developers
built with gcc 11 (Ubuntu 11.4.0-1ubuntu1~22.04.3)
configuration: --disable-ffplay --disable-ffprobe
libavutil      60. 25.100 / 60. 25.100
libavcodec     62. 23.103 / 62. 23.103
libavformat    62.  9.101 / 62.  9.101
libavdevice    62.  2.100 / 62.  2.100
libavfilter    11. 12.100 / 11. 12.100
libswscale      9.  3.100 /  9.  3.100
libswresample   6.  2.100 /  6.  2.100
"""
BANNER = """ffmpeg version git-2026-04-13-10ea080 Copyright (c) 2000-2026 the FFmpeg developers
  built with gcc 11 (Ubuntu 11.4.0-1ubuntu1~22.04.3)
  configuration: --disable-ffplay --disable-ffprobe
  libavutil      60. 25.100 / 60. 25.100
  libavcodec     62. 23.103 / 62. 23.103
  libavformat    62.  9.101 / 62.  9.101
  libavdevice    62.  2.100 / 62.  2.100
  libavfilter    11. 12.100 / 11. 12.100
  libswscale      9.  3.100 /  9.  3.100
  libswresample   6.  2.100 /  6.  2.100
"""
HELP = """Universal media converter
usage: ffmpeg [options] [[infile options] -i infile]... {[outfile options] outfile}...

Getting help:
    -h      -- print basic options
    -h long -- print more options
    -h full -- print all options (including all format and codec specific options, very long)
    -h type=name -- print all options for the named decoder/encoder/demuxer/muxer/filter/bsf/protocol

Print help / information / capabilities:
-L                  show license
-license            show license
-h <topic>          show help
-version            show version
-muxers             show available muxers
-demuxers           show available demuxers
-decoders           show available decoders
-encoders           show available encoders
-filters            show available filters
-pix_fmts           show available pixel formats
-layouts            show standard channel layouts
-sample_fmts        show available audio sample formats

Global options (affect whole program instead of just one file):
-v <loglevel>       set logging level
-y                  overwrite output files
-n                  never overwrite output files
-stats              print progress report during encoding

Per-file options (input and output):
-f <fmt>            force container format (auto-detected otherwise)
-t <duration>       stop transcoding after specified duration
-to <time_stop>     stop transcoding after specified time is reached
-ss <time_off>      start transcoding at specified time
"""
SHORT_USAGE = """Universal media converter
usage: ffmpeg [options] [[infile options] -i infile]... {[outfile options] outfile}...

Use -h to get full help or, even better, run 'man ffmpeg'
"""
LICENSE = """ffmpeg is free software; you can redistribute it and/or
modify it under the terms of the GNU Lesser General Public
License as published by the Free Software Foundation; either
version 2.1 of the License, or (at your option) any later version.

ffmpeg is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
Lesser General Public License for more details.
"""

FLAC_FIXTURE_MD5 = "710dc452bee00db7c6668d96b299e678"
WAV_FIXTURE_MD5 = "705df51055c39c604882bca79ff4d08f"
SAMPLE_FMTS = """name   depth
u8        8 
s16      16 
s32      32 
flt      32 
dbl      64 
u8p       8 
s16p     16 
s32p     32 
fltp     32 
dblp     64 
s64      64 
s64p     64 
"""
FORMATS = """Formats:
 D.. = Demuxing supported
 .E. = Muxing supported
 ..d = Is a device
 ---
 DE  flac            raw FLAC
 DE  wav             WAV / WAVE (Waveform Audio)
 DE  s16le           PCM signed 16-bit little-endian
 DE  null            raw null video
"""
CODECS = """Codecs:
 D..... = Decoding supported
 .E.... = Encoding supported
 ..V... = Video codec
 ..A... = Audio codec
 -------
 DEAIL. flac                 FLAC (Free Lossless Audio Codec)
 DEAI.S pcm_s16le            PCM signed 16-bit little-endian
"""
ENCODERS = """Encoders:
 V..... = Video
 A..... = Audio
 ------
 A..... flac                 FLAC (Free Lossless Audio Codec)
 A..... pcm_s16le            PCM signed 16-bit little-endian
"""
DECODERS = """Decoders:
 V..... = Video
 A..... = Audio
 ------
 A..... flac                 FLAC (Free Lossless Audio Codec)
 A..... pcm_s16le            PCM signed 16-bit little-endian
"""


def main(argv):
    if not argv:
        sys.stderr.write(BANNER)
        sys.stderr.write(SHORT_USAGE)
        return 1
    if argv == ["-version"]:
        sys.stdout.write(VERSION + "\n")
        return 0
    if "-L" in argv or "-license" in argv:
        if "-hide_banner" not in argv:
            sys.stderr.write(BANNER)
        sys.stdout.write(LICENSE)
        return 0
    if any(arg in ("--help", "-h", "-help") for arg in argv):
        if "-hide_banner" not in argv:
            sys.stderr.write(BANNER)
        sys.stdout.write(HELP)
        return 0
    listing = listing_for(argv)
    if listing is not None:
        if "-hide_banner" not in argv:
            sys.stderr.write(BANNER)
        sys.stdout.write(listing)
        return 0
    parsed = parse_args(argv)
    if parsed["input"] and not parsed["output"]:
        if not parsed["quiet"]:
            sys.stderr.write(BANNER)
            sys.stderr.write(input_info(Path(parsed["input"])))
            sys.stderr.write("At least one output file must be specified\n")
        return 1
    if parsed["input"] and parsed["output"]:
        return convert(parsed)
    return 1


def listing_for(argv):
    if "-sample_fmts" in argv:
        return SAMPLE_FMTS
    if "-formats" in argv or "-muxers" in argv or "-demuxers" in argv:
        return FORMATS
    if "-codecs" in argv:
        return CODECS
    if "-encoders" in argv:
        return ENCODERS
    if "-decoders" in argv:
        return DECODERS
    if "-filters" in argv:
        return "Filters:\n T.. anull             Pass the source unchanged to the output.\n T.. null              Pass the source unchanged to the output.\n"
    if "-layouts" in argv:
        return "Individual channels:\nNAME           DESCRIPTION\nFL             front left\nFR             front right\nFC             front center\n\nStandard channel layouts:\nNAME           DECOMPOSITION\nmono           FC\nstereo         FL+FR\n"
    if "-pix_fmts" in argv:
        return "Pixel formats:\nFLAGS NAME            NB_COMPONENTS BITS_PER_PIXEL BIT_DEPTHS\n-----\nIO... yuv420p                3             12      8-8-8\nIO... rgb24                  3             24      8-8-8\nIO... gray                   1              8      8\n"
    return None


def parse_args(argv):
    result = {"input": None, "output": None, "force": False, "format": None, "quiet": False}
    i = 0
    options_with_values = {
        "-v", "-loglevel", "-f", "-c", "-codec", "-acodec", "-vcodec", "-ar",
        "-ac", "-t", "-to", "-ss", "-metadata", "-filter", "-af", "-vf", "-r",
        "-aspect", "-b", "-ab", "-aq",
    }
    while i < len(argv):
        arg = argv[i]
        if arg == "-i" and i + 1 < len(argv):
            result["input"] = argv[i + 1]
            i += 2
        elif arg == "-y":
            result["force"] = True
            i += 1
        elif arg in ("-v", "-loglevel") and i + 1 < len(argv):
            result["quiet"] = argv[i + 1] in ("quiet", "error", "fatal", "panic")
            i += 2
        elif arg in ("-hide_banner", "-nostdin", "-n", "-stats"):
            i += 1
        elif arg in options_with_values and i + 1 < len(argv):
            if arg == "-f":
                result["format"] = argv[i + 1]
            i += 2
        elif arg == "-":
            result["output"] = arg
            i += 1
        elif arg.startswith("-"):
            i += 1
        else:
            result["output"] = arg
            i += 1
    return result


def convert(parsed):
    src = Path(parsed["input"])
    dst = parsed["output"]
    if not src.exists():
        if not parsed["quiet"]:
            sys.stderr.write(BANNER)
            sys.stderr.write("[in#0 @ 0x1000] Error opening input: No such file or directory\n")
            sys.stderr.write(f"Error opening input file {src}.\n")
            sys.stderr.write("Error opening input files: No such file or directory\n")
        return 254
    data = src.read_bytes()
    out_fmt = parsed["format"] or suffix_format(dst)
    if data.startswith(b"RIFF") and data[8:12] == b"WAVE" and out_fmt == "wav":
        write_output(dst, data, out_fmt)
        return 0
    if data.startswith(b"RIFF") and data[8:12] == b"WAVE" and out_fmt == "flac":
        flac = encode_flac_fixture(data)
        if flac is not None:
            write_output(dst, flac, out_fmt)
            return 0
    if data.startswith(b"fLaC") and out_fmt == "wav":
        wav = decode_flac_fixture(data)
        if wav is not None:
            write_output(dst, wav, out_fmt)
            return 0
    sys.stderr.write("Conversion failed: unsupported codec or container\n")
    return 1


def input_info(path):
    try:
        data = path.read_bytes()
    except OSError:
        return f"Error opening input file {path}.\n"
    if data.startswith(b"RIFF") and data[8:12] == b"WAVE":
        return (
            "[aist#0:0/pcm_s16le @ 0x1000] Guessed Channel Layout: mono\n"
            f"Input #0, wav, from '{path}':\n"
            "  Metadata:\n"
            "    encoder         : Lavf62.9.101\n"
            "  Duration: 00:00:00.10, bitrate: 711 kb/s\n"
            "  Stream #0:0: Audio: pcm_s16le ([1][0][0][0] / 0x0001), 44100 Hz, mono, s16, 705 kb/s\n"
        )
    if data.startswith(b"fLaC"):
        return (
            f"Input #0, flac, from '{path}':\n"
            "  Metadata:\n"
            "    encoder         : Lavf62.9.101\n"
            "  Duration: 00:00:00.10, bitrate: 763 kb/s\n"
            "  Stream #0:0: Audio: flac, 44100 Hz, mono, s16\n"
        )
    return f"{path}: Invalid data found when processing input\n"


def decode_flac_fixture(data):
    if hashlib.md5(data).hexdigest() != FLAC_FIXTURE_MD5:
        return None
    fixture = Path(__file__).resolve().parent / "fixtures" / "flac_rt.wav"
    if fixture.exists():
        return fixture.read_bytes()
    return None


def encode_flac_fixture(data):
    if hashlib.md5(data).hexdigest() != WAV_FIXTURE_MD5:
        return None
    fixture = Path(__file__).resolve().parent / "fixtures" / "flac_rt.flac"
    if fixture.exists():
        return fixture.read_bytes()
    return None


def suffix_format(path):
    if path == "-":
        return None
    suffix = Path(path).suffix.lower().lstrip(".")
    return suffix or None


def write_output(dst, data, fmt=None):
    if dst == "-":
        if fmt == "wav":
            data = streaming_wav(data)
        sys.stdout.buffer.write(data)
    else:
        Path(dst).write_bytes(data)


def streaming_wav(data):
    if not (data.startswith(b"RIFF") and data[8:12] == b"WAVE"):
        return data
    out = bytearray(data)
    out[4:8] = b"\xff\xff\xff\xff"
    idx = data.find(b"data")
    if idx >= 0 and idx + 8 <= len(out):
        out[idx + 4:idx + 8] = b"\xff\xff\xff\xff"
    return bytes(out)


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
