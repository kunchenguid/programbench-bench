import json
import os
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
EXE = ROOT / "executable"


def run_eureka(args=None, home=None, input_text=None, env=None, timeout=5):
    args = args or []
    full_env = os.environ.copy()
    if home is not None:
        full_env["HOME"] = str(home)
    if env:
        full_env.update(env)
    return subprocess.run(
        [str(EXE), *args],
        input=input_text,
        text=True,
        capture_output=True,
        env=full_env,
        timeout=timeout,
    )


class EurekaBehaviorTests(unittest.TestCase):
    def test_first_run_records_repo_config(self):
        with tempfile.TemporaryDirectory() as td:
            home = Path(td)
            repo = home / "ideas"
            repo.mkdir()
            (repo / "README.md").write_text("# Ideas\n")

            result = run_eureka(home=home, input_text=f"{repo}\n")

            self.assertEqual(result.returncode, 0, result.stderr)
            self.assertIn("First Time Setup", result.stdout)
            self.assertIn("First time setup complete. Happy ideation!", result.stdout)
            config = json.loads((home / ".config/eureka/config.json").read_text())
            self.assertEqual(config, {"repo": str(repo)})

    def test_help_version_and_bad_flag(self):
        help_result = run_eureka(["--help"])
        self.assertEqual(help_result.returncode, 0)
        self.assertIn("Input and store your ideas without leaving the terminal", help_result.stdout)
        self.assertIn("Usage: executable [OPTIONS]", help_result.stdout)
        self.assertIn("--clear-config", help_result.stdout)
        self.assertIn("-v, --view", help_result.stdout)

        version_result = run_eureka(["--version"])
        self.assertEqual(version_result.returncode, 0)
        self.assertEqual(version_result.stdout, "eureka 2.0.0\n")

        bad_result = run_eureka(["--bad"])
        self.assertEqual(bad_result.returncode, 2)
        self.assertIn("error: unexpected argument '--bad' found", bad_result.stderr)

    def test_clear_config_removes_config_silently(self):
        with tempfile.TemporaryDirectory() as td:
            home = Path(td)
            config_dir = home / ".config/eureka"
            config_dir.mkdir(parents=True)
            config = config_dir / "config.json"
            config.write_text('{"repo":"/tmp/ideas"}')

            result = run_eureka(["--clear-config"], home=home)

            self.assertEqual(result.returncode, 0)
            self.assertEqual(result.stdout, "")
            self.assertEqual(result.stderr, "")
            self.assertFalse(config.exists())

    def test_view_prints_readme_with_pager(self):
        with tempfile.TemporaryDirectory() as td:
            home = Path(td)
            repo = home / "ideas"
            repo.mkdir()
            (repo / "README.md").write_text("# Ideas\n\nOne\n")
            config_dir = home / ".config/eureka"
            config_dir.mkdir(parents=True)
            (config_dir / "config.json").write_text(json.dumps({"repo": str(repo)}))

            result = run_eureka(["--view"], home=home, env={"PAGER": "cat"})

            self.assertEqual(result.returncode, 0, result.stderr)
            self.assertEqual(result.stdout, "# Ideas\n\nOne\n")
            self.assertEqual(result.stderr, "")

    def test_view_without_config_logs_error_without_setup(self):
        with tempfile.TemporaryDirectory() as td:
            home = Path(td)

            result = run_eureka(["--view"], home=home, env={"PAGER": "cat"})

            self.assertEqual(result.returncode, 0)
            self.assertEqual(result.stdout, "")
            self.assertIn("ERROR eureka > No such file or directory", result.stderr)
            self.assertFalse((home / ".config/eureka/config.json").exists())

    def test_capture_edits_readme_and_commits_summary_on_main(self):
        with tempfile.TemporaryDirectory() as td:
            home = Path(td)
            repo = home / "ideas"
            repo.mkdir()
            subprocess.run(["git", "init", "-q"], cwd=repo, check=True)
            subprocess.run(["git", "config", "user.email", "a@b.c"], cwd=repo, check=True)
            subprocess.run(["git", "config", "user.name", "tester"], cwd=repo, check=True)
            (repo / "README.md").write_text("# Ideas\n")
            subprocess.run(["git", "add", "README.md"], cwd=repo, check=True)
            subprocess.run(["git", "commit", "-q", "-m", "init"], cwd=repo, check=True)

            config_dir = home / ".config/eureka"
            config_dir.mkdir(parents=True)
            (config_dir / "config.json").write_text(json.dumps({"repo": str(repo)}))
            editor = home / "editor.sh"
            editor.write_text("#!/bin/sh\nprintf '\\nCaptured body\\n' >> \"$1\"\n")
            editor.chmod(0o755)

            result = run_eureka(home=home, input_text="Useful summary\n", env={"EDITOR": str(editor)})

            self.assertEqual(result.returncode, 0)
            self.assertIn(">> Idea summary", result.stdout)
            self.assertIn("Adding and committing your new idea to main..", result.stdout)
            self.assertIn("Added and committed!", result.stdout)
            self.assertIn("Pushing your new idea..", result.stdout)
            self.assertIn("remote 'origin' does not exist", result.stderr)
            self.assertEqual((repo / "README.md").read_text(), "# Ideas\n\nCaptured body\n")
            branch = subprocess.check_output(["git", "branch", "--show-current"], cwd=repo, text=True)
            self.assertEqual(branch, "main\n")
            subject = subprocess.check_output(["git", "log", "-1", "--pretty=%s"], cwd=repo, text=True)
            self.assertEqual(subject, "Useful summary\n")


if __name__ == "__main__":
    unittest.main()
