#!/usr/bin/env python3
import json
import os
import shlex
import subprocess
import sys
from pathlib import Path


SETUP_TEXT = """\033[0m\033[33m############################################################
####                  First Time Setup                  ####
############################################################

This tool requires you to have a repository with a README.md
in the root folder. The markdown file is where your ideas
will be stored.

Once first time setup has completed, simply run Eureka again
to begin writing down ideas.
        
\033[0m"""


def config_path():
    return Path(os.environ.get("HOME", str(Path.home()))) / ".config" / "eureka" / "config.json"


def prompt(label):
    while True:
        sys.stdout.write(f"\033[0m\033[1m\033[32m{label}\n\033[0m> ")
        sys.stdout.flush()
        line = sys.stdin.readline()
        if line == "":
            continue
        value = line.rstrip("\n")
        if value:
            return value


def first_time_setup():
    sys.stdout.write(SETUP_TEXT)
    repo = prompt("Absolute path to your idea repo")
    path = config_path()
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps({"repo": repo}, separators=(",", ":")))
    print("First time setup complete. Happy ideation!")


HELP = """Input and store your ideas without leaving the terminal

Usage: executable [OPTIONS]

Options:
      --clear-config  Clear your stored configuration
  -v, --view          View ideas with your $PAGER env variable. If unset use less
  -h, --help          Print help
  -V, --version       Print version
"""


def parse_args(argv):
    if not argv:
        return "capture"
    if argv in (["-h"], ["--help"]):
        return "help"
    if argv in (["-V"], ["--version"]):
        return "version"
    if argv == ["--clear-config"]:
        return "clear"
    if argv in (["-v"], ["--view"]):
        return "view"
    bad = argv[0]
    sys.stderr.write(f"error: unexpected argument '{bad}' found\n\n")
    sys.stderr.write("Usage: executable [OPTIONS]\n\n")
    sys.stderr.write("For more information, try '--help'.\n")
    return "bad"


def log_error(message):
    sys.stderr.write(f" ERROR eureka > {message}\n")


def log_exception(exc):
    if isinstance(exc, FileNotFoundError):
        log_error("No such file or directory (os error 2)")
    else:
        log_error(str(exc))


def clear_config():
    try:
        config_path().unlink()
    except FileNotFoundError as exc:
        log_exception(exc)


def load_config():
    with config_path().open() as f:
        return json.load(f)


def view_ideas():
    try:
        repo = Path(load_config()["repo"])
        readme = repo / "README.md"
        pager = os.environ.get("PAGER") or "less"
        with readme.open("rb") as f:
            subprocess.run(shlex.split(pager), stdin=f)
    except Exception as exc:
        log_exception(exc)


def run_git(repo, args, check=True):
    return subprocess.run(
        ["git", *args],
        cwd=repo,
        text=True,
        capture_output=True,
        check=check,
    )


def capture_idea():
    try:
        repo = Path(load_config()["repo"])
        summary = prompt(">> Idea summary")
        readme = repo / "README.md"
        editor = os.environ.get("EDITOR") or "vi"
        subprocess.run([*shlex.split(editor), str(readme)])
        run_git(repo, ["checkout", "-B", "main"])
        run_git(repo, ["add", "README.md"])
        print("Adding and committing your new idea to main..")
        run_git(repo, ["commit", "--allow-empty", "-m", summary])
        print("Added and committed!")
        print("Pushing your new idea..")
        push = run_git(repo, ["push", "origin", "main"], check=False)
        if push.returncode != 0:
            message = (push.stderr or push.stdout).strip()
            if message:
                if "origin" in message:
                    log_error("remote 'origin' does not exist; class=Config (7); code=NotFound (-3)")
                else:
                    log_error(message.splitlines()[-1])
    except Exception as exc:
        log_exception(exc)


def main():
    command = parse_args(sys.argv[1:])
    if command == "bad":
        return 2
    if command == "help":
        print(HELP, end="")
        return 0
    if command == "version":
        print("eureka 2.0.0")
        return 0
    if command == "clear":
        clear_config()
        return 0
    if command == "view":
        view_ideas()
        return 0
    if not config_path().exists():
        first_time_setup()
        return 0
    capture_idea()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
