#!/bin/bash
set -e
rm -f executable
cp eureka.py executable
chmod +x executable
