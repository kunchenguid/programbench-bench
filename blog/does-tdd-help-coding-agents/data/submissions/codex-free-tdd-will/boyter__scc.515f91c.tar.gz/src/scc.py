#!/usr/bin/env python3
import csv
import fnmatch
import hashlib
import html
import json
import math
import os
import re
import sys
from dataclasses import dataclass, field

HELP = """Sloc, Cloc and Code. Count lines of code in a directory with complexity estimation.
Version 3.7.0
Ben Boyter <ben@boyter.org> + Contributors

Usage:
  scc [flags] [files or directories]

Flags:
      --avg-wage int                       average wage value used for basic COCOMO calculation (default 56286)
      --binary                             disable binary file detection
      --by-file                            display output for every file
  -m, --character                          calculate max and mean characters per line
      --ci                                 enable CI output settings where stdout is ASCII
      --cocomo-project-type string         change COCOMO model type [organic, semi-detached, embedded, "custom,1,1,1,1"] (default "organic")
      --cost-comparison                    show both COCOMO and LOCOMO estimates side by side
      --count-as string                    count extension as language [e.g. jsp:htm,chead:"C Header" maps extension jsp to html and chead to C Header]
      --count-ignore                       set to allow .gitignore and .ignore files to be counted
      --currency-symbol string             set currency symbol (default "$")
      --debug                              enable debug output
      --directory-walker-job-workers int   controls the maximum number of workers which will walk the directory tree (default 8)
  -a, --dryness                            calculate the DRYness of the project (implies --uloc)
      --eaf float                          the effort adjustment factor derived from the cost drivers (1.0 if rated nominal) (default 1)
      --exclude-dir strings                directories to exclude (default [.git,.hg,.svn])
  -x, --exclude-ext strings                ignore file extensions (overrides include-ext) [comma separated list: e.g. go,java,js]
  -n, --exclude-file strings               ignore files with matching names (default [package-lock.json,Cargo.lock,yarn.lock,pubspec.lock,Podfile.lock,pnpm-lock.yaml])
  -f, --format string                      set output format [tabular, wide, json, json2, csv, csv-stream, cloc-yaml, html, html-table, sql, sql-insert, openmetrics] (default "tabular")
  -h, --help                               help for scc
  -i, --include-ext strings                limit to file extensions [comma separated list: e.g. go,java,js]
  -l, --languages                          print supported languages and extensions
      --no-cocomo                          remove COCOMO calculation output
  -c, --no-complexity                      skip calculation of code complexity
  -d, --no-duplicates                      remove duplicate files from stats and output
      --no-size                            remove size calculation output
  -o, --output string                      output filename (default stdout)
  -s, --sort string                        column to sort by [files, name, lines, blanks, code, comments, complexity] (default "files")
  -u, --uloc                               calculate the number of unique lines of code (ULOC) for the project
  -v, --verbose                            verbose output
      --version                            version for scc
  -w, --wide                               wider output with additional statistics (implies --complexity)
"""

LANGS = {
    "py": ("Python", "#", None, None, ("if", "for", "while", "except", "elif", "and", "or")),
    "pyw": ("Python", "#", None, None, ("if", "for", "while", "except", "elif", "and", "or")),
    "go": ("Go", "//", "/*", "*/", ("if", "for", "range", "case", "&&", "||")),
    "js": ("JavaScript", "//", "/*", "*/", ("if", "for", "while", "case", "catch", "&&", "||", "?")),
    "jsx": ("JavaScript", "//", "/*", "*/", ("if", "for", "while", "case", "catch", "&&", "||", "?")),
    "ts": ("TypeScript", "//", "/*", "*/", ("if", "for", "while", "case", "catch", "&&", "||", "?")),
    "tsx": ("TypeScript", "//", "/*", "*/", ("if", "for", "while", "case", "catch", "&&", "||", "?")),
    "java": ("Java", "//", "/*", "*/", ("if", "for", "while", "case", "catch", "&&", "||", "?")),
    "c": ("C", "//", "/*", "*/", ("if", "for", "while", "case", "&&", "||", "?")),
    "h": ("C Header", "//", "/*", "*/", ("if", "for", "while", "case", "&&", "||", "?")),
    "cc": ("C++", "//", "/*", "*/", ("if", "for", "while", "case", "catch", "&&", "||", "?")),
    "cpp": ("C++", "//", "/*", "*/", ("if", "for", "while", "case", "catch", "&&", "||", "?")),
    "cxx": ("C++", "//", "/*", "*/", ("if", "for", "while", "case", "catch", "&&", "||", "?")),
    "hpp": ("C++ Header", "//", "/*", "*/", ("if", "for", "while", "case", "catch", "&&", "||", "?")),
    "cs": ("C#", "//", "/*", "*/", ("if", "for", "while", "case", "catch", "&&", "||", "?")),
    "rs": ("Rust", "//", "/*", "*/", ("if", "for", "while", "match", "&&", "||", "?")),
    "php": ("PHP", "//", "/*", "*/", ("if", "for", "while", "case", "catch", "&&", "||", "?")),
    "rb": ("Ruby", "#", None, None, ("if", "for", "while", "elsif", "rescue", "&&", "||")),
    "sh": ("Shell", "#", None, None, ("if", "for", "while", "case", "&&", "||")),
    "bash": ("BASH", "#", None, None, ("if", "for", "while", "case", "&&", "||")),
    "zsh": ("Zsh", "#", None, None, ("if", "for", "while", "case", "&&", "||")),
    "html": ("HTML", None, "<!--", "-->", ()),
    "htm": ("HTML", None, "<!--", "-->", ()),
    "xml": ("XML", None, "<!--", "-->", ()),
    "css": ("CSS", None, "/*", "*/", ()),
    "scss": ("Sass", "//", "/*", "*/", ()),
    "sql": ("SQL", "--", "/*", "*/", ("where", "join", "case", "when", "and", "or")),
    "lua": ("Lua", "--", "--[[", "]]", ("if", "for", "while", "and", "or")),
    "r": ("R", "#", None, None, ("if", "for", "while", "&&", "||")),
    "swift": ("Swift", "//", "/*", "*/", ("if", "for", "while", "case", "catch", "&&", "||", "?")),
    "kt": ("Kotlin", "//", "/*", "*/", ("if", "for", "while", "when", "catch", "&&", "||", "?")),
    "scala": ("Scala", "//", "/*", "*/", ("if", "for", "while", "case", "catch", "&&", "||", "?")),
    "md": ("Markdown", None, None, None, ()),
    "markdown": ("Markdown", None, None, None, ()),
    "txt": ("Plain Text", None, None, None, ()),
    "csv": ("CSV", None, None, None, ()),
    "json": ("JSON", None, None, None, ()),
    "yaml": ("YAML", "#", None, None, ()),
    "yml": ("YAML", "#", None, None, ()),
    "toml": ("TOML", "#", None, None, ()),
    "ini": ("INI", ";", None, None, ()),
    "makefile": ("Makefile", "#", None, None, ("if",)),
}

SPECIAL_NAMES = {
    "makefile": "makefile",
    "dockerfile": "dockerfile",
    "cmakelists.txt": "cmake",
    "package.json": "json",
    "license": "license",
}
LANGS.update({
    "dockerfile": ("Dockerfile", "#", None, None, ()),
    "cmake": ("CMake", "#", None, None, ("if", "foreach", "while")),
    "license": ("License", None, None, None, ()),
})

LANGUAGE_LINES = [
    "BASH (bash,bash_login,bash_logout,bash_profile,bashrc,.bashrc)",
    "C (c,ec,pgc)",
    "C Header (h)",
    "C# (cs,csx)",
    "C++ (cc,cpp,cxx,c++,pcc,ino)",
    "C++ Header (hh,hpp,hxx,h++,inl,ipp,tpp)",
    "CMake (cmake,cmakelists.txt)",
    "CSS (css)",
    "CSV (csv)",
    "Dockerfile (dockerfile)",
    "Go (go)",
    "HTML (html,htm)",
    "INI (ini)",
    "Java (java)",
    "JavaScript (js,jsx)",
    "JSON (json)",
    "Kotlin (kt,kts)",
    "Lua (lua)",
    "Makefile (makefile)",
    "Markdown (md,markdown)",
    "PHP (php)",
    "Plain Text (txt,text)",
    "Python (py,pyw)",
    "R (r)",
    "Ruby (rb)",
    "Rust (rs)",
    "Sass (scss,sass)",
    "Shell (sh)",
    "SQL (sql)",
    "Swift (swift)",
    "TOML (toml)",
    "TypeScript (ts,tsx)",
    "XML (xml)",
    "YAML (yaml,yml)",
]

@dataclass
class FileStat:
    language: str
    filename: str
    extension: str
    location: str
    bytes: int = 0
    lines: int = 0
    code: int = 0
    comment: int = 0
    blank: int = 0
    complexity: int = 0
    uloc: int = 0
    minified: bool = False
    generated: bool = False

@dataclass
class LangStat:
    name: str
    bytes: int = 0
    lines: int = 0
    code: int = 0
    comment: int = 0
    blank: int = 0
    complexity: int = 0
    count: int = 0
    uloc: int = 0
    files: list = field(default_factory=list)
    unique_lines: set = field(default_factory=set)

class Options:
    def __init__(self):
        self.format = "tabular"
        self.output = None
        self.by_file = False
        self.no_cocomo = False
        self.no_size = False
        self.no_complexity = False
        self.ci = False
        self.include_ext = None
        self.exclude_ext = set()
        self.exclude_dir = {".git", ".hg", ".svn"}
        self.exclude_file = {"package-lock.json", "Cargo.lock", "yarn.lock", "pubspec.lock", "Podfile.lock", "pnpm-lock.yaml"}
        self.sort = "files"
        self.uloc = False
        self.dryness = False
        self.percent = False
        self.character = False
        self.no_duplicates = False
        self.include_symlinks = False
        self.count_as = {}
        self.currency = "$"
        self.avg_wage = 56286
        self.eaf = 1.0
        self.overhead = 2.4
        self.project_type = "organic"
        self.size_unit = "si"
        self.no_hborder = False
        self.paths = []

def split_csv(value):
    return [x.strip().lower().lstrip(".") for x in value.split(",") if x.strip()]

def parse_args(argv):
    opts = Options()
    value_flags = {
        "--format": "format", "-f": "format", "--output": "output", "-o": "output",
        "--include-ext": "include_ext", "-i": "include_ext", "--exclude-ext": "exclude_ext", "-x": "exclude_ext",
        "--exclude-dir": "exclude_dir", "--exclude-file": "exclude_file", "-n": "exclude_file",
        "--sort": "sort", "-s": "sort", "--count-as": "count_as", "--currency-symbol": "currency",
        "--avg-wage": "avg_wage", "--eaf": "eaf", "--overhead": "overhead", "--cocomo-project-type": "project_type",
        "--size-unit": "size_unit", "--sql-project": "sql_project", "--large-byte-count": "ignored",
        "--large-line-count": "ignored", "--directory-walker-job-workers": "ignored",
        "--file-gc-count": "ignored", "--file-list-queue-size": "ignored",
        "--file-process-job-workers": "ignored", "--file-summary-job-queue-size": "ignored",
        "--format-multi": "ignored", "--remap-all": "ignored", "--remap-unknown": "ignored",
        "--generated-markers": "ignored", "--min-gen-line-length": "ignored", "--locomo-config": "ignored",
        "--locomo-cycles": "ignored", "--locomo-input-price": "ignored", "--locomo-output-price": "ignored",
        "--locomo-preset": "ignored", "--locomo-review": "ignored", "--locomo-tps": "ignored",
        "--not-match": "ignored", "-M": "ignored",
    }
    bool_flags = {
        "--by-file": "by_file", "--no-cocomo": "no_cocomo", "--no-size": "no_size",
        "--no-complexity": "no_complexity", "-c": "no_complexity", "--ci": "ci",
        "--uloc": "uloc", "-u": "uloc", "--dryness": "dryness", "-a": "dryness",
        "--percent": "percent", "-m": "character", "--character": "character",
        "--no-duplicates": "no_duplicates", "-d": "no_duplicates", "--include-symlinks": "include_symlinks",
        "--size-unit-si": "ignored", "--size-unit-binary": "ignored", "--size-unit-mixed": "ignored",
        "--size-unit-xkcd": "ignored", "--sloccount-format": "ignored", "--binary": "ignored",
        "--debug": "ignored", "--trace": "ignored", "-t": "ignored", "--verbose": "ignored", "-v": "ignored",
        "--wide": "ignored", "-w": "ignored", "--gen": "ignored", "--min": "ignored", "--min-gen": "ignored",
        "-z": "ignored", "--no-gen": "ignored", "--no-min": "ignored", "--no-min-gen": "ignored",
        "--no-min-gen-ignore": "ignored", "--no-large": "ignored", "--no-gitignore": "ignored",
        "--no-ignore": "ignored", "--no-scc-ignore": "ignored", "--no-gitmodule": "ignored",
        "--count-ignore": "ignored", "--format-multi-line": "ignored", "--locomo": "ignored",
        "--cost-comparison": "ignored", "--mcp": "ignored", "--no-hborder": "no_hborder",
    }
    i = 0
    while i < len(argv):
        arg = argv[i]
        if arg in ("--help", "-h", "--version", "-l", "--languages"):
            opts.paths.append(arg)
        elif arg in value_flags:
            i += 1
            if i >= len(argv):
                print(f"Error: flag needs an argument: {arg}", file=sys.stderr)
                return None
            attr = value_flags[arg]
            val = argv[i]
            if attr == "format":
                opts.format = val
            elif attr == "output":
                opts.output = val
            elif attr == "include_ext":
                opts.include_ext = set(split_csv(val))
            elif attr == "exclude_ext":
                opts.exclude_ext = set(split_csv(val))
            elif attr == "exclude_dir":
                opts.exclude_dir = set(x.strip() for x in val.split(",") if x.strip())
            elif attr == "exclude_file":
                opts.exclude_file = set(x.strip() for x in val.split(",") if x.strip())
            elif attr == "count_as":
                for part in val.split(","):
                    if ":" in part:
                        a, b = part.split(":", 1)
                        opts.count_as[a.strip().lower().lstrip(".")] = b.strip().strip('"').lower().lstrip(".")
            elif attr == "avg_wage":
                opts.avg_wage = int(float(val))
            elif attr in ("eaf", "overhead"):
                setattr(opts, attr, float(val))
            elif attr != "ignored":
                setattr(opts, attr, val)
        elif arg in bool_flags:
            attr = bool_flags[arg]
            if attr != "ignored":
                setattr(opts, attr, True)
        elif arg.startswith("-"):
            print(f"Error: unknown flag: {arg}", file=sys.stderr)
            print("Usage:\n  scc [flags] [files or directories]", file=sys.stderr)
            return None
        else:
            opts.paths.append(arg)
        i += 1
    if opts.dryness:
        opts.uloc = True
    return opts

def file_ext(path):
    base = os.path.basename(path)
    low = base.lower()
    if low in SPECIAL_NAMES:
        return SPECIAL_NAMES[low]
    if "." in base:
        return base.rsplit(".", 1)[1].lower()
    return ""

def lang_for(path, opts, data=None):
    ext = file_ext(path)
    if not ext and data is not None and data.startswith(b"#!"):
        first = data.splitlines()[0].decode("utf-8", "ignore").lower()
        if "python" in first:
            ext = "py"
        elif "bash" in first:
            ext = "bash"
        elif "sh" in first:
            ext = "sh"
        elif "ruby" in first:
            ext = "rb"
        elif "node" in first:
            ext = "js"
    mapped = opts.count_as.get(ext, ext)
    if mapped in LANGS:
        name = LANGS[mapped][0]
        return mapped, name, LANGS[mapped]
    return None

def is_binary(data):
    if b"\0" in data:
        return True
    if not data:
        return False
    sample = data[:4096]
    bad = sum(1 for b in sample if b < 9 or (13 < b < 32))
    return bad / len(sample) > 0.30

def strip_strings_for_complexity(line):
    return re.sub(r'"(?:\\.|[^"\\])*"|\'(?:\\.|[^\'\\])*\'', ' ', line)

def count_complexity(line, tokens):
    text = strip_strings_for_complexity(line)
    total = 0
    for tok in tokens:
        if tok in ("&&", "||", "?"):
            total += text.count(tok)
        else:
            total += len(re.findall(r"\b" + re.escape(tok) + r"\b", text, re.I))
    return total

def classify_lines(text, langinfo):
    _, line_comment, block_start, block_end, complexity_tokens = langinfo
    lines = text.splitlines()
    blank = comment = code = complexity = 0
    in_block = False
    unique = set()
    for raw in lines:
        line = raw.rstrip("\r")
        stripped = line.strip()
        if not stripped:
            blank += 1
            continue
        work = stripped
        has_code = False
        has_comment = False
        while True:
            if in_block:
                has_comment = True
                if block_end and block_end in work:
                    work = work.split(block_end, 1)[1].strip()
                    in_block = False
                    if not work:
                        break
                    continue
                work = ""
                break
            bpos = work.find(block_start) if block_start else -1
            lpos = work.find(line_comment) if line_comment else -1
            positions = [(p, "block") for p in [bpos] if p >= 0] + [(p, "line") for p in [lpos] if p >= 0]
            if not positions:
                if work.strip():
                    has_code = True
                    complexity += count_complexity(work, complexity_tokens)
                break
            pos, kind = min(positions)
            before = work[:pos].strip()
            if before:
                has_code = True
                complexity += count_complexity(before, complexity_tokens)
            has_comment = True
            if kind == "line":
                break
            after = work[pos + len(block_start):]
            if block_end and block_end in after:
                work = after.split(block_end, 1)[1].strip()
                if not work:
                    break
                continue
            in_block = True
            break
        unique.add(stripped)
        if has_code:
            code += 1
        elif has_comment:
            comment += 1
    return len(lines), code, comment, blank, complexity, unique

def should_ignore_path(path, root, opts):
    base = os.path.basename(path)
    if base in opts.exclude_file:
        return True
    rel = os.path.relpath(path, root)
    parts = rel.split(os.sep)
    if any(part in opts.exclude_dir for part in parts[:-1]):
        return True
    return False

def gather_files(paths, opts):
    if not paths:
        paths = ["."]
    out = []
    for path in paths:
        if not os.path.exists(path):
            continue
        if os.path.isfile(path):
            if opts.include_symlinks or not os.path.islink(path):
                out.append(os.path.abspath(path))
            continue
        for root, dirs, files in os.walk(path, followlinks=opts.include_symlinks):
            dirs[:] = [d for d in dirs if d not in opts.exclude_dir]
            for name in files:
                fp = os.path.join(root, name)
                if os.path.islink(fp) and not opts.include_symlinks:
                    continue
                if should_ignore_path(fp, path, opts):
                    continue
                out.append(os.path.abspath(fp))
    return sorted(set(out))

def scan(opts):
    stats = {}
    seen_hashes = set()
    for path in gather_files([p for p in opts.paths if not p.startswith("-")], opts):
        try:
            data = open(path, "rb").read()
        except OSError:
            continue
        ext = file_ext(path)
        info = lang_for(path, opts, data)
        if not info:
            continue
        mapped_ext, lname, langinfo = info
        if opts.include_ext is not None and mapped_ext not in opts.include_ext:
            continue
        if mapped_ext in opts.exclude_ext or ext in opts.exclude_ext:
            continue
        if is_binary(data):
            continue
        digest = hashlib.sha1(data).hexdigest()
        if opts.no_duplicates and digest in seen_hashes:
            continue
        seen_hashes.add(digest)
        text = data.decode("utf-8", "replace")
        lines, code, comment, blank, complexity, unique = classify_lines(text, langinfo)
        if opts.no_complexity:
            complexity = 0
        fs = FileStat(lname, os.path.basename(path), mapped_ext, path, len(data), lines, code, comment, blank, complexity, len(unique))
        st = stats.setdefault(lname, LangStat(lname))
        st.bytes += fs.bytes
        st.lines += lines
        st.code += code
        st.comment += comment
        st.blank += blank
        st.complexity += complexity
        st.count += 1
        st.uloc += len(unique)
        st.unique_lines.update(unique)
        st.files.append(fs)
    if opts.uloc:
        for st in stats.values():
            st.uloc = len(st.unique_lines)
    rows = list(stats.values())
    sort_key = opts.sort
    if sort_key == "name":
        rows.sort(key=lambda s: s.name.lower())
    elif sort_key == "lines":
        rows.sort(key=lambda s: (-s.lines, s.name.lower()))
    elif sort_key == "blanks":
        rows.sort(key=lambda s: (-s.blank, s.name.lower()))
    elif sort_key == "code":
        rows.sort(key=lambda s: (-s.code, s.name.lower()))
    elif sort_key == "comments":
        rows.sort(key=lambda s: (-s.comment, s.name.lower()))
    elif sort_key == "complexity":
        rows.sort(key=lambda s: (-s.complexity, s.name.lower()))
    else:
        rows.sort(key=lambda s: (-s.count, s.name.lower()))
    return rows

def file_obj(fs):
    return {
        "Language": fs.language, "PossibleLanguages": [fs.language], "Filename": fs.filename,
        "Extension": fs.extension, "Location": fs.location, "Symlocation": "", "Bytes": fs.bytes,
        "Lines": fs.lines, "Code": fs.code, "Comment": fs.comment, "Blank": fs.blank,
        "Complexity": fs.complexity, "WeightedComplexity": 0, "Hash": None, "Binary": False,
        "Minified": fs.minified, "Generated": fs.generated, "EndPoint": 0, "Uloc": fs.uloc,
    }

def lang_obj(st, opts):
    return {
        "Name": st.name, "Bytes": st.bytes, "CodeBytes": 0, "Lines": st.lines, "Code": st.code,
        "Comment": st.comment, "Blank": st.blank, "Complexity": st.complexity, "Count": st.count,
        "WeightedComplexity": 0, "Files": [file_obj(f) for f in st.files] if opts.by_file else [],
        "LineLength": None, "ULOC": st.uloc if opts.uloc else 0,
    }

def totals(rows):
    return {
        "files": sum(r.count for r in rows), "lines": sum(r.lines for r in rows),
        "blank": sum(r.blank for r in rows), "comment": sum(r.comment for r in rows),
        "code": sum(r.code for r in rows), "complexity": sum(r.complexity for r in rows),
        "bytes": sum(r.bytes for r in rows), "uloc": sum(r.uloc for r in rows),
    }

def cocomo(rows, opts):
    code = max(0.001, totals(rows)["code"] / 1000.0)
    mode = opts.project_type
    factors = {"organic": (2.4, 1.05, 2.5, 0.38), "semi-detached": (3.0, 1.12, 2.5, 0.35), "embedded": (3.6, 1.20, 2.5, 0.32)}
    a, b, c, d = factors.get(mode, factors["organic"])
    effort = a * (code ** b) * opts.eaf
    schedule = c * (effort ** d)
    people = effort / schedule if schedule else 0
    monthly = opts.avg_wage / 12.0 * opts.overhead
    return effort * monthly, schedule, people

def fmt_int(n):
    return f"{n:,}"

def border(opts):
    return "-" * 79 if opts.ci else "─" * 79

def format_table(rows, opts):
    b = border(opts)
    include_complex = not opts.no_complexity
    extra = "      ULOC" if opts.uloc and not opts.dryness else ("   DRYness" if opts.dryness else "")
    comp_head = " Complexity" if include_complex else ""
    out = [b, f"{'Language':<16}{'Files':>9}{'Lines':>12}{'Blanks':>10}{'Comments':>10}{'Code':>11}{comp_head}{extra}", b]
    def row(name, files, lines, blank, comment, code, complexity, uloc=0):
        vals = f"{name:<16}{fmt_int(files):>9}{fmt_int(lines):>12}{fmt_int(blank):>10}{fmt_int(comment):>10}{fmt_int(code):>11}"
        if include_complex:
            vals += f"{fmt_int(complexity):>11}"
        if opts.dryness:
            pct = (uloc / code * 100.0) if code else 0.0
            vals += f"{pct:>9.1f}%"
        elif opts.uloc:
            vals += f"{fmt_int(uloc):>10}"
        return vals
    for st in rows:
        out.append(row(st.name[:20], st.count, st.lines, st.blank, st.comment, st.code, st.complexity, st.uloc))
        if opts.by_file:
            out.append(b)
            for fs in sorted(st.files, key=lambda f: f.location):
                out.append(row(fs.location[:20], fs.lines and 0 or 0, fs.lines, fs.blank, fs.comment, fs.code, fs.complexity, fs.uloc))
            out.append(b)
    t = totals(rows)
    out += [b, row("Total", t["files"], t["lines"], t["blank"], t["comment"], t["code"], t["complexity"], t["uloc"]), b]
    if not opts.no_cocomo and rows:
        cost, sched, people = cocomo(rows, opts)
        out.append(f"Estimated Cost to Develop (organic) {opts.currency}{cost:,.0f}")
        out.append(f"Estimated Schedule Effort (organic) {sched:.2f} months")
        out.append(f"Estimated People Required (organic) {people:.2f}")
        out.append(b)
    if not opts.no_size:
        mb = t["bytes"] / 1000000.0
        out.append(f"Processed {t['bytes']} bytes, {mb:.3f} megabytes (SI)")
        out.append(b)
    return "\n".join(out) + "\n"

def format_csv(rows, opts, stream=False):
    import io
    buf = io.StringIO()
    w = csv.writer(buf, lineterminator="\n")
    w.writerow(["Language", "Lines", "Code", "Comments", "Blanks", "Complexity", "Bytes", "Files", "ULOC"])
    for st in rows:
        w.writerow([st.name, st.lines, st.code, st.comment, st.blank, st.complexity, st.bytes, st.count, st.uloc if opts.uloc else 0])
    return buf.getvalue()

def format_cloc_yaml(rows, opts):
    out = []
    for st in rows:
        out += [f"{st.name}:", f"  nFiles: {st.count}", f"  blank: {st.blank}", f"  comment: {st.comment}", f"  code: {st.code}"]
    t = totals(rows)
    out += ["SUM:", f"  blank: {t['blank']}", f"  comment: {t['comment']}", f"  code: {t['code']}", f"  nFiles: {t['files']}"]
    return "\n".join(out) + "\n"

def format_sql(rows, opts, inserts_only=False):
    lines = []
    if not inserts_only:
        lines.append("CREATE TABLE metadata (project TEXT, elapsed_s REAL, files INTEGER, lines INTEGER, blank INTEGER, comment INTEGER, code INTEGER);")
        lines.append("CREATE TABLE t (language TEXT, files INTEGER, lines INTEGER, blank INTEGER, comment INTEGER, code INTEGER, complexity INTEGER);")
    for st in rows:
        lines.append(f"INSERT INTO t VALUES ('{st.name.replace(chr(39), chr(39)*2)}',{st.count},{st.lines},{st.blank},{st.comment},{st.code},{st.complexity});")
    return "\n".join(lines) + "\n"

def format_openmetrics(rows, opts):
    out = []
    for st in rows:
        label = st.name.replace("\\", "\\\\").replace('"', '\\"')
        for key, val in [("files", st.count), ("lines", st.lines), ("blank", st.blank), ("comment", st.comment), ("code", st.code), ("complexity", st.complexity)]:
            out.append(f'scc_{key}{{language="{label}"}} {val}')
    return "\n".join(out) + "\n"

def format_html(rows, opts, table_only=False):
    table = ["<table>", "<tr><th>Language</th><th>Files</th><th>Lines</th><th>Blanks</th><th>Comments</th><th>Code</th><th>Complexity</th></tr>"]
    for st in rows:
        table.append(f"<tr><td>{html.escape(st.name)}</td><td>{st.count}</td><td>{st.lines}</td><td>{st.blank}</td><td>{st.comment}</td><td>{st.code}</td><td>{st.complexity}</td></tr>")
    table.append("</table>")
    body = "\n".join(table)
    return body + "\n" if table_only else "<!doctype html><html><body>\n" + body + "\n</body></html>\n"

def render(rows, opts):
    if opts.format == "json":
        return json.dumps([lang_obj(st, opts) for st in rows], separators=(",", ":"))
    if opts.format == "json2":
        cost, sched, people = cocomo(rows, opts)
        return json.dumps({"languageSummary": [lang_obj(st, opts) for st in rows], "estimatedCost": cost, "estimatedScheduleMonths": sched, "estimatedPeople": people}, separators=(",", ":"))
    if opts.format in ("csv", "csv-stream"):
        return format_csv(rows, opts)
    if opts.format == "cloc-yaml":
        return format_cloc_yaml(rows, opts)
    if opts.format == "sql":
        return format_sql(rows, opts)
    if opts.format == "sql-insert":
        return format_sql(rows, opts, True)
    if opts.format == "openmetrics":
        return format_openmetrics(rows, opts)
    if opts.format == "html":
        return format_html(rows, opts)
    if opts.format == "html-table":
        return format_html(rows, opts, True)
    return format_table(rows, opts)

def main():
    argv = sys.argv[1:]
    if "--version" in argv:
        print("scc version 3.7.0")
        return 0
    if "--help" in argv or "-h" in argv:
        print(HELP, end="")
        return 0
    if "--languages" in argv or "-l" in argv:
        print("\n".join(LANGUAGE_LINES))
        return 0
    opts = parse_args(argv)
    if opts is None:
        return 1
    rows = scan(opts)
    text = render(rows, opts)
    if opts.output:
        with open(opts.output, "w", encoding="utf-8") as f:
            f.write(text)
    else:
        sys.stdout.write(text)
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
