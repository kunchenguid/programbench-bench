import csv
import io
import json
import os
import subprocess
import tempfile
import textwrap
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
EXE = ROOT / 'executable'


def build():
    subprocess.run(['bash', 'compile.sh'], cwd=ROOT, check=True)


def run_cmd(args, cwd=None):
    build()
    return subprocess.run([str(EXE)] + args, cwd=cwd or ROOT, text=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)


class CliTests(unittest.TestCase):
    def test_help_and_version(self):
        r = run_cmd(['--help'])
        self.assertEqual(r.returncode, 0)
        self.assertIn('Sloc, Cloc and Code.', r.stdout)
        self.assertIn('Version 3.7.0', r.stdout)
        self.assertIn('--format string', r.stdout)
        v = run_cmd(['--version'])
        self.assertEqual(v.stdout.strip(), 'scc version 3.7.0')

    def test_counts_common_languages_as_json(self):
        with tempfile.TemporaryDirectory() as td:
            p = Path(td)
            (p / 'a.py').write_text('# one\n\nprint("hi")  # inline\nif x:\n    pass\n')
            (p / 'b.js').write_text('// comment\nconst x = 1;\n/* multi\n   comment */\nfunction f(){ if (x) return; }\n')
            (p / 'c.go').write_text('package main\n\n// hi\nfunc main() {\n if true {\n }\n}\n')
            (p / 'readme.md').write_text('hi\n')
            (p / 'data.csv').write_text('a,b\n1,2\n')
            r = run_cmd(['--no-cocomo', '--no-size', '--format', 'json', str(p)])
        self.assertEqual(r.returncode, 0, r.stderr)
        rows = {row['Name']: row for row in json.loads(r.stdout)}
        self.assertEqual((rows['Python']['Lines'], rows['Python']['Blank'], rows['Python']['Comment'], rows['Python']['Code']), (5, 1, 1, 3))
        self.assertEqual((rows['JavaScript']['Lines'], rows['JavaScript']['Blank'], rows['JavaScript']['Comment'], rows['JavaScript']['Code']), (5, 0, 3, 2))
        self.assertEqual((rows['Go']['Lines'], rows['Go']['Blank'], rows['Go']['Comment'], rows['Go']['Code']), (7, 1, 1, 5))
        self.assertEqual((rows['Markdown']['Lines'], rows['Markdown']['Code']), (1, 1))
        self.assertEqual((rows['CSV']['Lines'], rows['CSV']['Code']), (2, 2))

    def test_filters_and_csv_output_file(self):
        with tempfile.TemporaryDirectory() as td:
            p = Path(td)
            (p / 'a.py').write_text('print(1)\n')
            (p / 'b.go').write_text('package main\n')
            (p / 'c.js').write_text('const x = 1;\n')
            out = p / 'report.csv'
            r = run_cmd(['--include-ext', 'py,go', '--exclude-ext', 'go', '--format', 'csv', '--output', str(out), str(p)])
            self.assertEqual(r.returncode, 0, r.stderr)
            self.assertEqual(r.stdout, '')
            data = list(csv.DictReader(io.StringIO(out.read_text())))
        self.assertEqual([row['Language'] for row in data], ['Python'])
        self.assertEqual(data[0]['Lines'], '1')


if __name__ == '__main__':
    unittest.main()
