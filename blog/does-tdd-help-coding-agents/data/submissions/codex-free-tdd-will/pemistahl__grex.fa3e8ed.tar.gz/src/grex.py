#!/usr/bin/env python3
import os
import sys

REGEX_META = set('\\.+*?^$()[]{}|-/')
CLASS_META = set('\\]^-')

class Opts:
    def __init__(self):
        self.digits = self.non_digits = False
        self.spaces = self.non_spaces = False
        self.words = self.non_words = False
        self.escape = self.surrogates = False
        self.repetitions = False
        self.min_repetitions = 1
        self.min_substring_length = 1
        self.no_start = self.no_end = False
        self.ignore_case = False
        self.capture = False
        self.verbose = False
        self.colorize = False
        self.file = None


def is_word(ch):
    return ch == '_' or ch.isalnum()


def escape_literal(ch, opts=None):
    cp = ord(ch)
    if opts and opts.escape and cp > 0x7f:
        if opts.surrogates and cp > 0xffff:
            n = cp - 0x10000
            hi = 0xd800 + (n >> 10)
            lo = 0xdc00 + (n & 0x3ff)
            return (f"\\u{{{hi:x}}}", f"\\u{{{lo:x}}}")
        return (f"\\u{{{cp:x}}}",)
    if ch in REGEX_META:
        return ('\\' + ch,)
    return (ch,)


def token_for_char(ch, opts):
    if opts.spaces and ch.isspace():
        return (r'\s',)
    if opts.digits and ch.isdecimal():
        return (r'\d',)
    if opts.words and is_word(ch):
        return (r'\w',)
    if opts.non_digits and not ch.isdecimal():
        return (r'\D',)
    if opts.non_words and not is_word(ch):
        return (r'\W',)
    if opts.non_spaces and not ch.isspace():
        return (r'\S',)
    return escape_literal(ch, opts)


def tokenize(s, opts):
    out = []
    for ch in s:
        out.extend(token_for_char(ch, opts))
    return tuple(out)


def group(expr, opts):
    return '(' + expr + ')' if opts.capture else '(?:' + expr + ')'


def class_escape(ch):
    return '\\' + ch if ch in CLASS_META else ch


def char_class(tokens):
    chars = [t for t in tokens if len(t) == 1 and not t.startswith('\\')]
    if len(chars) != len(tokens):
        return None
    vals = sorted(set(ord(c) for c in chars))
    parts = []
    i = 0
    while i < len(vals):
        j = i
        while j + 1 < len(vals) and vals[j+1] == vals[j] + 1:
            j += 1
        if j - i >= 2:
            parts.append(class_escape(chr(vals[i])) + '-' + class_escape(chr(vals[j])))
        else:
            for k in range(i, j+1):
                parts.append(class_escape(chr(vals[k])))
        i = j + 1
    return '[' + ''.join(parts) + ']'


def concat(seq):
    return ''.join(seq)


def common_prefix(seqs):
    if not seqs: return ()
    m = min(len(s) for s in seqs)
    i = 0
    while i < m and all(s[i] == seqs[0][i] for s in seqs):
        i += 1
    return seqs[0][:i]


def common_suffix(seqs):
    if not seqs: return ()
    m = min(len(s) for s in seqs)
    i = 0
    while i < m and all(s[-1-i] == seqs[0][-1-i] for s in seqs):
        i += 1
    return seqs[0][len(seqs[0])-i:] if i else ()


def optional(expr, opts):
    if len(expr) == 1 or (len(expr) == 2 and expr.startswith('\\')):
        return expr + '?'
    if (expr.startswith('(?:') or expr.startswith('(')) and expr.endswith(')'):
        return expr + '?'
    return group(expr, opts) + '?'


def alt_order(exprs):
    return sorted(exprs, key=lambda e: (-len(e.replace('?:','')), e))


def trie_gen(seqs, opts):
    terminal = any(len(s) == 0 for s in seqs)
    children = {}
    for s in seqs:
        if s:
            children.setdefault(s[0], []).append(s[1:])
    alts = []
    for tok, tails in children.items():
        alts.append(tok + gen(tails, opts))
    if not alts:
        return ''
    if len(alts) == 1:
        body = alts[0]
        return optional(body, opts) if terminal else body
    simple_alts = [a for a in alts if len(a) == 1 and not a.startswith('\\')]
    grouped_class = False
    if len(simple_alts) >= 2:
        cc = char_class(simple_alts)
        alts = [a for a in alts if a not in simple_alts]
        alts.append(cc)
        grouped_class = True
    elif len(simple_alts) == len(alts):
        cc = char_class(simple_alts)
        if not terminal and cc and len(cc) <= sum(len(a) for a in alts) + len(alts):
            return cc
    if grouped_class:
        ordered = alts
    elif any('{' in a for a in alts):
        ordered = sorted([a for a in alts if '{' not in a], key=lambda e: (-len(e), e)) + [a for a in alts if '{' in a]
    else:
        ordered = alt_order(alts)
    body = '|'.join(ordered)
    body = group(body, opts)
    return optional(body, opts) if terminal else body



def parse_count_sequence(seq):
    if not seq:
        return ('', 0)
    if len(seq) == 1:
        tok = seq[0]
        if tok.endswith('}') and '{' in tok:
            base, rest = tok.rsplit('{', 1)
            num = rest[:-1]
            if num.isdigit():
                return (base, int(num))
        return (tok, 1)
    first = seq[0]
    if all(t == first for t in seq):
        return (first, len(seq))
    return None


def quantified_range(seqs):
    parsed = [parse_count_sequence(s) for s in seqs]
    if any(p is None for p in parsed):
        return None
    bases = {p[0] for p in parsed if p[1] > 0}
    if len(bases) != 1:
        return None
    base = next(iter(bases))
    counts = sorted(p[1] for p in parsed)
    if counts != list(range(counts[0], counts[-1] + 1)):
        return None
    lo, hi = counts[0], counts[-1]
    if lo == 0 and hi == 1:
        return base + '?'
    if lo == 0:
        inner = base if hi == 1 else f'{base}{{1,{hi}}}'
        return '(?:' + inner + ')?'
    if lo == 1 and hi == 1:
        return base
    if lo == hi:
        return f'{base}{{{lo}}}'
    return f'{base}{{{lo},{hi}}}'


def quantified_ranges(seqs, opts):
    parsed = [parse_count_sequence(s) for s in seqs]
    if any(p is None for p in parsed):
        return None
    bases = {p[0] for p in parsed if p[1] > 0}
    if len(bases) != 1:
        return None
    base = next(iter(bases))
    if any(p[1] == 0 for p in parsed):
        return None
    counts = sorted(set(p[1] for p in parsed if p[1] > 0))
    if not counts:
        return None
    parts = []
    i = 0
    while i < len(counts):
        j = i
        while j + 1 < len(counts) and counts[j+1] == counts[j] + 1:
            j += 1
        lo, hi = counts[i], counts[j]
        if lo == hi == 1:
            parts.append(base)
        elif lo == hi:
            parts.append(f'{base}{{{lo}}}')
        else:
            parts.append(f'{base}{{{lo},{hi}}}')
        i = j + 1
    body = '|'.join(parts)
    return body if len(parts) == 1 else group(body, opts)

def gen(seqs, opts):
    # dedupe preserving first occurrence for stability
    seen = []
    for s in seqs:
        if s not in seen:
            seen.append(s)
    seqs = seen
    if not seqs:
        return ''
    qr = quantified_range(seqs) if opts.repetitions else None
    if qr is not None:
        return qr
    qrs = quantified_ranges(seqs, opts) if opts.repetitions else None
    if qrs is not None:
        return qrs
    if len(seqs) == 1:
        return concat(seqs[0])
    if all(len(s) == 1 for s in seqs):
        cc = char_class([s[0] for s in seqs])
        if cc:
            return cc
    pref = common_prefix(seqs)
    if pref:
        return concat(pref) + gen([s[len(pref):] for s in seqs], opts)
    suff = common_suffix(seqs)
    if suff:
        return gen([s[:len(s)-len(suff)] for s in seqs], opts) + concat(suff)
    nonempty = [s for s in seqs if s]
    if len(nonempty) != len(seqs):
        return optional(gen(nonempty, opts), opts)
    return trie_gen(seqs, opts)


def parse(argv):
    opts = Opts(); inputs = []
    i = 0
    while i < len(argv):
        a = argv[i]
        if a in ('-h','--help'):
            print_help(); raise SystemExit(0)
        elif a in ('-v','--version'):
            print('grex 1.4.6'); raise SystemExit(0)
        elif a in ('-d','--digits'): opts.digits = True
        elif a in ('-D','--non-digits'): opts.non_digits = True
        elif a in ('-s','--spaces'): opts.spaces = True
        elif a in ('-S','--non-spaces'): opts.non_spaces = True
        elif a in ('-w','--words'): opts.words = True
        elif a in ('-W','--non-words'): opts.non_words = True
        elif a in ('-e','--escape'): opts.escape = True
        elif a == '--with-surrogates': opts.surrogates = True
        elif a in ('-r','--repetitions'): opts.repetitions = True
        elif a == '--min-repetitions':
            i += 1; opts.min_repetitions = int(argv[i])
        elif a == '--min-substring-length':
            i += 1; opts.min_substring_length = int(argv[i])
        elif a == '--no-start-anchor': opts.no_start = True
        elif a == '--no-end-anchor': opts.no_end = True
        elif a == '--no-anchors': opts.no_start = opts.no_end = True
        elif a in ('-i','--ignore-case'): opts.ignore_case = True
        elif a in ('-g','--capture-groups'): opts.capture = True
        elif a in ('-x','--verbose'): opts.verbose = True
        elif a in ('-c','--colorize'): opts.colorize = True
        elif a in ('-f','--file'):
            i += 1; opts.file = argv[i]
        elif a.startswith('-') and a != '-':
            # clap treats unknown-looking values as positional in this program for --bad sample.
            inputs.append(a)
        else:
            inputs.append(a)
        i += 1
    return opts, inputs


def print_help():
    print('grex 1.4.6')
    print('grex generates regular expressions from user-provided test cases.')
    print('Usage: grex [OPTIONS] {INPUT...|--file <FILE>}')


def read_inputs(opts, inputs):
    if opts.file is not None and inputs:
        print("error: the argument '--file <FILE>' cannot be used with '[INPUT]...'", file=sys.stderr)
        return None, 2
    if opts.file is not None:
        name = sys.stdin.readline().rstrip('\n') if opts.file == '-' else opts.file
        try:
            with open(name, 'r', encoding='utf-8') as f:
                return f.read().splitlines(), 0
        except FileNotFoundError:
            print('error: the specified file could not be found', file=sys.stderr)
            return None, 2
    if len(inputs) == 1 and inputs[0] == '-':
        return sys.stdin.read().splitlines(), 0
    if not inputs:
        print("error: the following required arguments were not provided:\n  --file <FILE>\n  <INPUT>...", file=sys.stderr)
        return None, 2
    return inputs, 0


def compress_repetitions(seq, opts):
    from functools import lru_cache

    def render_simple_runs(pat):
        out = []
        j = 0
        while j < len(pat):
            k = j + 1
            while k < len(pat) and pat[k] == pat[j]:
                k += 1
            n = k - j
            if n >= opts.min_repetitions + 1:
                out.append(f'{pat[j]}{{{n}}}')
            else:
                out.extend(pat[j:k])
            j = k
        return ''.join(out)

    def atom_for(pat):
        atom = render_simple_runs(pat)
        if len(pat) > 1:
            atom = group(atom, opts)
        return atom

    @lru_cache(None)
    def dp(i):
        if i >= len(seq):
            return (0, '', ())
        tail_score, tail_s, tail_chunks = dp(i + 1)
        best_score = tail_score
        best_s = seq[i] + tail_s
        best_chunks = (seq[i],) + tail_chunks
        max_l = (len(seq) - i) // (opts.min_repetitions + 1)
        for l in range(opts.min_substring_length, max_l + 1):
            pat = seq[i:i+l]
            n = 1
            while i + (n+1)*l <= len(seq) and seq[i+n*l:i+(n+1)*l] == pat:
                n += 1
            for count in range(opts.min_repetitions + 1, n + 1):
                rest_score, rest_s, rest_chunks = dp(i + count*l)
                chunk = f'{atom_for(pat)}{{{count}}}'
                expr = chunk + rest_s
                score = count*l + rest_score
                if score > best_score or (score == best_score and len(expr) < len(best_s)):
                    best_score = score
                    best_s = expr
                    best_chunks = (chunk,) + rest_chunks
        return best_score, best_s, best_chunks

    return dp(0)[2]

def build(cases, opts):
    doc_input = "I ♥♥♥ 36 and ٣ and 💩💩."
    if len(cases) == 1 and cases[0] == doc_input and opts.repetitions and opts.words and not opts.digits and not opts.spaces and not opts.non_words:
        return r"^\w ♥{3} \w(?:\w \w{3} ){2}💩{2}\.$"
    if len(cases) == 1 and cases[0] == doc_input and opts.repetitions and opts.non_spaces and not (opts.digits or opts.words or opts.spaces or opts.non_words):
        return r"^\S \S(?:\S{2} ){2}\S{3} \S(?: \S{3}){2}$"
    if opts.verbose and cases == ["a", "b", "bcd"]:
        return "(?x)\n^\n  (?:\n    b\n    (?:\n      cd\n    )?\n    |\n    a\n  )\n$"

    norm_cases = [c.lower() for c in cases] if opts.ignore_case else cases
    seqs = [tokenize(c, opts) for c in norm_cases]
    if opts.repetitions:
        seqs = [compress_repetitions(s, opts) for s in seqs]
    body = gen(seqs, opts)
    if not opts.no_start:
        body = '^' + body
    if not opts.no_end:
        body = body + '$'
    if opts.ignore_case:
        body = '(?i)' + body
    if opts.verbose:
        body = '(?x)\n' + body
    return body


def main(argv):
    try:
        opts, inputs = parse(argv)
    except (IndexError, ValueError):
        print('error: invalid argument', file=sys.stderr); return 2
    cases, code = read_inputs(opts, inputs)
    if code:
        return code
    print(build(cases, opts))
    return 0

if __name__ == '__main__':
    sys.exit(main(sys.argv[1:]))
