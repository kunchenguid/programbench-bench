#!/bin/bash
set -e
rm -f executable
cp src/grex.py executable
chmod +x executable
