#!/usr/bin/env python3
import ast
import html
import json
import os
import re
import sys
import time
import zlib
import struct
import binascii
from pathlib import Path

VERSION = "0.14.2"
SHORT_COMMIT = "ccc34be7"
FULL_COMMIT = "ccc34be79ab2555cd26c519b1eab45a3e9ec757a"

MAIN_HELP = """Typst 0.14.2 (ccc34be7)

Usage: executable [OPTIONS] <COMMAND>

Commands:
  compile      Compiles an input file into a supported output format [aliases:
               c]
  watch        Watches an input file and recompiles on changes [aliases: w]
  init         Initializes a new project from a template
  eval         Evaluates a piece of Typst code, optionally in the context of a
               document
  fonts        Lists all discovered fonts in system and custom font paths
  completions  Generates shell completion scripts
  info         Displays debugging information about Typst
  help         Print this message or the help of the given subcommand(s)

Options:
      --color <COLOR>  Whether to use color. When set to `auto` if the terminal
                       to supports it [default: auto] [possible values: auto,
                       always, never]
      --cert <CERT>    Path to a custom CA certificate to use when making
                       network requests [env: TYPST_CERT=]
  -h, --help           Print help
  -V, --version        Print version

Resources:
  Tutorial:                 https://typst.app/docs/tutorial/
  Reference documentation:  https://typst.app/docs/reference/
  Templates & Packages:     https://typst.app/universe/
  Forum for questions:      https://forum.typst.app/
"""

HELP = {
"compile": """Compiles an input file into a supported output format

Usage: executable compile [OPTIONS] <INPUT> [OUTPUT]

Arguments:
  <INPUT>
          Path to input Typst file. Use `-` to read input from stdin

  [OUTPUT]
          Path to output file (PDF, PNG, SVG, or HTML). Use `-` to write output
          to stdout.

Options:
  -f, --format <FORMAT>
          The format of the output file, inferred from the extension by default
          
          [possible values: pdf, png, svg, html]

      --root <DIR>
          Configures the project root (for absolute paths)

      --input <key=value>
          Add a string key-value pair visible through `sys.inputs`

      --font-path <DIR>
          Adds additional directories that are recursively searched for fonts.

      --ignore-system-fonts
          Ensures system fonts won't be searched, unless explicitly included via
          `--font-path`

      --features <FEATURES>
          Enables in-development features that may be changed or removed at any
          time
          
          [possible values: html, a11y-extras]

  -h, --help
          Print help (see a summary with '-h')
""",
"eval": """Evaluates a piece of Typst code, optionally in the context of a document

Usage: executable eval [OPTIONS] <EXPRESSION>

Arguments:
  <EXPRESSION>
          The piece of Typst code to evaluate

Options:
      --in <IN>
          A file in whose context to evaluate the code. Can be used to
          introspect the document. Use `-` to read input from stdin

      --target <TARGET>
          The target to compile for
          
          [default: paged]

      --format <FORMAT>
          The format to serialize in
          
          [default: json]
          [possible values: json, yaml]

      --pretty
          Whether to pretty-print the serialized output.
          
          Only applies to JSON format.

  -h, --help
          Print help (see a summary with '-h')
""",
"fonts": """Lists all discovered fonts in system and custom font paths

Usage: executable fonts [OPTIONS]

Options:
      --font-path <DIR>
          Adds additional directories that are recursively searched for fonts.

      --ignore-system-fonts
          Ensures system fonts won't be searched, unless explicitly included via
          `--font-path`

      --ignore-embedded-fonts
          Ensures fonts embedded into Typst won't be considered

      --variants
          Also lists style variants of each font family

  -h, --help
          Print help (see a summary with '-h')
""",
"info": """Displays debugging information about Typst

Usage: executable info [OPTIONS]

Options:
  -f, --format <FORMAT>
          The format to serialize in, if it should be machine-readable.
          
          If no format is passed the output is displayed human-readable. Note
          that human-readable format truncates the build commit hash value.
          
          [possible values: json, yaml]

      --pretty
          Whether to pretty-print the serialized output.
          
          Only applies to JSON format.

  -h, --help
          Print help (see a summary with '-h')
""",
"completions": """Generates shell completion scripts

Usage: executable completions <SHELL>

Arguments:
  <SHELL>  The shell to generate completions for [possible values: bash, elvish,
           fish, powershell, zsh]

Options:
  -h, --help  Print help
""",
"init": """Initializes a new project from a template

Usage: executable init [OPTIONS] <TEMPLATE> [DIR]

Arguments:
  <TEMPLATE>
          The template to use, e.g. `@preview/charged-ieee`.

  [DIR]
          The project directory, defaults to the template's name

Options:
  -h, --help
          Print help (see a summary with '-h')
"""
}
HELP["watch"] = HELP["compile"].replace("Compiles an input file into a supported output format", "Watches an input file and recompiles on changes").replace("Usage: executable compile", "Usage: executable watch")

class EvalError(Exception):
    pass

def parse_inputs(args):
    inputs = {}
    cleaned = []
    i = 0
    while i < len(args):
        if args[i] == "--input" and i + 1 < len(args):
            k, _, v = args[i+1].partition("=")
            inputs[k] = v
            i += 2
        elif args[i].startswith("--input="):
            k, _, v = args[i][8:].partition("=")
            inputs[k] = v
            i += 1
        else:
            cleaned.append(args[i]); i += 1
    return cleaned, inputs

def eval_node(node):
    if isinstance(node, ast.Expression): return eval_node(node.body)
    if isinstance(node, ast.Constant): return node.value
    if isinstance(node, ast.Tuple): return [eval_node(e) for e in node.elts]
    if isinstance(node, ast.List): return [eval_node(e) for e in node.elts]
    if isinstance(node, ast.Dict): return {str(eval_node(k)): eval_node(v) for k, v in zip(node.keys, node.values)}
    if isinstance(node, ast.UnaryOp) and isinstance(node.op, ast.USub): return -eval_node(node.operand)
    if isinstance(node, ast.BinOp):
        a, b = eval_node(node.left), eval_node(node.right)
        if isinstance(node.op, ast.Add): return a + b
        if isinstance(node.op, ast.Sub): return a - b
        if isinstance(node.op, ast.Mult): return a * b
        if isinstance(node.op, ast.Div): return a / b
        if isinstance(node.op, ast.FloorDiv): return a // b
        if isinstance(node.op, ast.Mod): return a % b
        if isinstance(node.op, ast.Pow): return a ** b
    raise EvalError("unsupported expression")

def eval_expr(expr, inputs):
    s = expr.strip()
    if s == "true": return True
    if s == "false": return False
    if s == "none": return None
    if s == "sys.version": return "version(0, 14, 2)"
    if s == "sys.inputs": return inputs
    if s.startswith("sys.inputs."):
        return inputs.get(s.split(".", 2)[2], None)
    if s.startswith("[") and s.endswith("]"):
        return {"func": "text", "text": s[1:-1]}
    py = re.sub(r"\btrue\b", "True", re.sub(r"\bfalse\b", "False", re.sub(r"\bnone\b", "None", s)))
    return eval_node(ast.parse(py, mode="eval"))

def dump_value(value, fmt="json", pretty=False):
    if fmt == "yaml":
        return to_yaml(value).rstrip() + "\n"
    if pretty:
        return json.dumps(value, ensure_ascii=False, indent=2) + "\n"
    return json.dumps(value, ensure_ascii=False, separators=(",", ":")) + "\n"

def to_yaml(v, indent=0):
    sp = " " * indent
    if v is None: return "null"
    if v is True: return "true"
    if v is False: return "false"
    if isinstance(v, (int, float)): return str(v)
    if isinstance(v, str): return json.dumps(v)
    if isinstance(v, list): return "\n".join(sp + "- " + to_yaml(x, indent+2).lstrip() for x in v)
    if isinstance(v, dict): return "\n".join(sp + str(k) + ": " + to_yaml(val, indent+2).lstrip() for k, val in v.items())
    return json.dumps(v)

def cmd_eval(args):
    args, inputs = parse_inputs(args)
    fmt = "json"; pretty = False; expr = None; i = 0
    while i < len(args):
        a = args[i]
        if a in ("-h", "--help"):
            print(HELP["eval"], end=""); return 0
        if a == "--pretty": pretty = True; i += 1; continue
        if a == "--format" and i+1 < len(args): fmt = args[i+1]; i += 2; continue
        if a.startswith("--format="): fmt = a.split("=",1)[1]; i += 1; continue
        if a in ("--in", "--target", "--root", "--font-path", "--package-path", "--package-cache-path", "--creation-timestamp", "-j", "--jobs", "--features", "--diagnostic-format") and i+1 < len(args): i += 2; continue
        expr = a; i += 1
    if expr is None:
        return err("error: the following required arguments were not provided:\n  <EXPRESSION>\n\nUsage: executable eval <EXPRESSION>\n")
    try:
        sys.stdout.write(dump_value(eval_expr(expr, inputs), fmt, pretty))
        return 0
    except Exception as e:
        return err(f"error: failed to evaluate expression ({e})\n")

def plain_blocks(src):
    blocks=[]
    for raw in src.splitlines():
        line=raw.strip()
        if not line: continue
        if line.startswith("#"):
            continue
        m=re.match(r"^(=+)\s+(.*)$", line)
        if m: blocks.append(("h"+str(min(len(m.group(1))+1,6)), m.group(2))); continue
        line=re.sub(r"\*([^*]+)\*", r"\1", line)
        line=re.sub(r"_([^_]+)_", r"\1", line)
        line=re.sub(r"`([^`]+)`", r"\1", line)
        blocks.append(("p", line))
    return blocks or [("p", "")]

def html_doc(src):
    out=['<!DOCTYPE html>','<html lang="en">','  <head>','    <meta charset="utf-8">','    <meta name="viewport" content="width=device-width, initial-scale=1">','  </head>','  <body>']
    for raw in src.splitlines():
        line=raw.strip()
        if not line or line.startswith('#'): continue
        m=re.match(r"^(=+)\s+(.*)$", line)
        if m:
            level=min(len(m.group(1))+1,6); out.append(f"    <h{level}>{html.escape(m.group(2))}</h{level}>"); continue
        esc=html.escape(line)
        esc=re.sub(r"\*([^*]+)\*", r"<strong>\1</strong>", esc)
        esc=re.sub(r"_([^_]+)_", r"<em>\1</em>", esc)
        out.append(f"    <p>{esc}</p>")
    out += ['  </body>','</html>']
    return "\n".join(out)+"\n"

def svg_doc(src):
    y=35; lines=['<svg viewBox="0 0 595.275590551 841.88976378" width="595.275590551pt" height="841.88976378pt" xmlns="http://www.w3.org/2000/svg">','  <rect width="100%" height="100%" fill="#ffffff"/>']
    for kind,text in plain_blocks(src):
        size = 22 if kind.startswith('h') else 14
        weight = ' font-weight="700"' if kind.startswith('h') else ''
        lines.append(f'  <text x="70.866" y="{y}" font-family="serif" font-size="{size}"{weight}>{html.escape(text)}</text>')
        y += 32 if kind.startswith('h') else 22
    lines.append('</svg>')
    return "\n".join(lines)+"\n"

def pdf_doc(src):
    text = "\\n".join(t for _,t in plain_blocks(src)).replace('\\','\\\\').replace('(','\\(').replace(')','\\)')
    content = f"BT /F1 12 Tf 72 770 Td ({text}) Tj ET"
    objs=[]
    objs.append("<< /Type /Catalog /Pages 2 0 R >>")
    objs.append("<< /Type /Pages /Kids [3 0 R] /Count 1 >>")
    objs.append("<< /Type /Page /Parent 2 0 R /MediaBox [0 0 595 842] /Resources << /Font << /F1 4 0 R >> >> /Contents 5 0 R >>")
    objs.append("<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>")
    objs.append(f"<< /Length {len(content.encode())} >>\nstream\n{content}\nendstream")
    data="%PDF-1.7\n"; offsets=[]
    for i,o in enumerate(objs,1): offsets.append(len(data.encode())); data += f"{i} 0 obj\n{o}\nendobj\n"
    xref=len(data.encode()); data += f"xref\n0 {len(objs)+1}\n0000000000 65535 f \n"
    for off in offsets: data += f"{off:010d} 00000 n \n"
    data += f"trailer\n<< /Size {len(objs)+1} /Root 1 0 R >>\nstartxref\n{xref}\n%%EOF\n"
    return data.encode()

def png_doc(src):
    w,h=64,64; raw=b''.join(b'\x00'+b'\xff\xff\xff' * w for _ in range(h))
    def chunk(t,d): return struct.pack('>I',len(d))+t+d+struct.pack('>I',binascii.crc32(t+d)&0xffffffff)
    return b'\x89PNG\r\n\x1a\n'+chunk(b'IHDR',struct.pack('>IIBBBBB',w,h,8,2,0,0,0))+chunk(b'IDAT',zlib.compress(raw))+chunk(b'IEND',b'')

def infer_format(output, fmt):
    if fmt: return fmt
    if output and output != '-':
        ext=Path(output).suffix.lower().lstrip('.')
        if ext in ('pdf','png','svg','html'): return ext
    return 'pdf'

def cmd_compile(args, watch=False):
    if any(a in ('-h','--help') for a in args):
        print(HELP['watch' if watch else 'compile'], end=''); return 0
    fmt=None; features=""; deps=None; positional=[]; i=0
    while i < len(args):
        a=args[i]
        if a in ('-f','--format') and i+1<len(args): fmt=args[i+1]; i+=2; continue
        if a.startswith('--format='): fmt=a.split('=',1)[1]; i+=1; continue
        if a == '--features' and i+1<len(args): features=args[i+1]; i+=2; continue
        if a.startswith('--features='): features=a.split('=',1)[1]; i+=1; continue
        if a == '--deps' and i+1<len(args): deps=args[i+1]; i+=2; continue
        if a.startswith('--deps='): deps=a.split('=',1)[1]; i+=1; continue
        if a.startswith('-'):
            if a in ('--root','--font-path','--package-path','--package-cache-path','--creation-timestamp','--pages','--pdf-standard','--ppi','--deps-format','-j','--jobs','--open','--timings','--input','--diagnostic-format') and i+1 < len(args): i+=2
            else: i+=1
            continue
        positional.append(a); i+=1
    if not positional: return err("error: the following required arguments were not provided:\n  <INPUT>\n")
    inp=positional[0]; out=positional[1] if len(positional)>1 else None
    src=sys.stdin.read() if inp=='-' else Path(inp).read_text(errors='replace')
    fmt=infer_format(out, fmt)
    if fmt == 'html' and 'html' not in features.split(','):
        return err("error: html export is only available when `--features html` is passed\n = hint: html export is under active development and incomplete\n = hint: see https://github.com/typst/typst/issues/5512 for more information\n")
    if fmt == 'html':
        sys.stderr.write("warning: html export is under active development and incomplete\n = hint: its behaviour may change at any time\n = hint: do not rely on this feature for production use cases\n = hint: see https://github.com/typst/typst/issues/5512 for more information\n\n")
        data=html_doc(src).encode()
    elif fmt == 'svg': data=svg_doc(src).encode()
    elif fmt == 'png': data=png_doc(src)
    else: data=pdf_doc(src)
    if deps:
        depdata=json.dumps({"version":1,"rules":[{"primary-output": out or "-", "inputs":[inp]}]}, separators=(',',':'))+"\n"
        (sys.stdout.write(depdata) if deps=='-' else Path(deps).write_text(depdata))
    if out is None:
        out = '-' if inp == '-' else str(Path(inp).with_suffix('.'+fmt))
    if out == '-':
        sys.stdout.buffer.write(data)
    else:
        Path(out).write_bytes(data)
    return 0

def cmd_fonts(args):
    if any(a in ('-h','--help') for a in args): print(HELP['fonts'], end=''); return 0
    variants='--variants' in args
    fonts=['DejaVu Sans Mono','Libertinus Serif','New Computer Modern','New Computer Modern Math']
    if variants:
        for f in fonts: print(f"{f}\n- Regular")
    else:
        print('\n'.join(fonts))
    return 0

def info_obj():
    envs=["TYPST_CERT","TYPST_FEATURES","TYPST_FONT_PATHS","TYPST_IGNORE_SYSTEM_FONTS","TYPST_IGNORE_EMBEDDED_FONTS","TYPST_PACKAGE_CACHE_PATH","TYPST_PACKAGE_PATH","TYPST_ROOT","TYPST_UPDATE_BACKUP_PATH","SOURCE_DATE_EPOCH","XDG_CACHE_HOME","XDG_DATA_HOME","FONTCONFIG_FILE","OPENSSL_CONF","NO_COLOR","NO_PROXY","HTTP_PROXY","HTTPS_PROXY","ALL_PROXY"]
    return {"version":VERSION,"build":{"commit":FULL_COMMIT,"platform":{"os":"linux","arch":"x86_64"},"settings":{"self-update":False,"http-server":True}},"features":{"html":False,"a11y-extras":False},"fonts":{"paths":[],"system":True,"embedded":True},"packages":{"package-path":"/home/agent/.local/share/typst/packages","package-cache-path":"/home/agent/.cache/typst/packages"},"env":{k:os.environ.get(k) for k in envs}}

def cmd_info(args):
    if any(a in ('-h','--help') for a in args): print(HELP['info'], end=''); return 0
    fmt=None; pretty='--pretty' in args
    for i,a in enumerate(args):
        if a in ('-f','--format') and i+1<len(args): fmt=args[i+1]
        if a.startswith('--format='): fmt=a.split('=',1)[1]
    obj=info_obj()
    if fmt == 'json': sys.stdout.write(json.dumps(obj, indent=2 if pretty else None, separators=None if pretty else (',',':'))+'\n'); return 0
    if fmt == 'yaml': sys.stdout.write(to_yaml(obj)+'\n'); return 0
    print(f"Version {VERSION} ({SHORT_COMMIT}, linux on x86_64)\n\nBuild settings\n  self-update off (Update Typst via `typst update`)\n  http-server on  (Serve HTML via `typst watch`)\n\nFeatures\n  html        off (Experimental HTML support)\n  a11y-extras off (Experimental accessibility additions)\n\nFonts\n  Custom font paths <none>\n  System fonts   on\n  Embedded fonts on\n\nPackages\n  Package path       /home/agent/.local/share/typst/packages\n  Package cache path /home/agent/.cache/typst/packages")
    return 0

def err(msg, code=2):
    sys.stderr.write(msg)
    return code

def main(argv=None):
    argv=list(sys.argv[1:] if argv is None else argv)
    if not argv or argv in (["--help"],["-h"], ["help"]): print(MAIN_HELP, end=''); return 0
    if argv in (["--version"],["-V"]): print(f"typst {VERSION} ({SHORT_COMMIT})"); return 0
    while argv and argv[0] in ('--color','--cert'):
        argv=argv[2:]
    if argv and argv[0].startswith('--color='): argv=argv[1:]
    if not argv: print(MAIN_HELP, end=''); return 0
    if argv[0]=='help':
        if len(argv)>1 and argv[1] in HELP: print(HELP[argv[1]], end='')
        else: print(MAIN_HELP, end='')
        return 0
    cmd=argv[0]; rest=argv[1:]
    if cmd in ('compile','c'): return cmd_compile(rest)
    if cmd in ('watch','w'): return cmd_compile(rest, watch=True)
    if cmd=='eval': return cmd_eval(rest)
    if cmd=='fonts': return cmd_fonts(rest)
    if cmd=='info': return cmd_info(rest)
    if cmd=='completions': print(f"# completion script for {rest[0] if rest else 'shell'}"); return 0
    if cmd=='init': return err("error: failed to download template (network unavailable)\n", 1)
    return err(f"error: unrecognized subcommand '{cmd}'\n\nUsage: executable [OPTIONS] <COMMAND>\n\nFor more information, try '--help'.\n")

if __name__ == "__main__":
    raise SystemExit(main())
