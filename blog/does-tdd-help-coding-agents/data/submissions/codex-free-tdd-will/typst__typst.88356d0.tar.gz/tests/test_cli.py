import os
import subprocess
import unittest

ROOT = os.path.dirname(os.path.dirname(__file__))
BIN = os.path.join(ROOT, "build", "test-executable")

class CliTests(unittest.TestCase):
    def run_cli(self, *args, input_text=None):
        return subprocess.run([BIN, *args], input=input_text, text=True, capture_output=True)

    def test_version_matches_typst_release(self):
        result = self.run_cli("--version")
        self.assertEqual(result.returncode, 0)
        self.assertEqual(result.stdout, "typst 0.14.2 (ccc34be7)\n")
        self.assertEqual(result.stderr, "")

    def test_eval_addition_serializes_json_number(self):
        result = self.run_cli("eval", "1 + 2")
        self.assertEqual(result.returncode, 0)
        self.assertEqual(result.stdout, "3\n")
        self.assertEqual(result.stderr, "")

    def test_compile_html_feature_writes_html_and_warning(self):
        import tempfile
        with tempfile.TemporaryDirectory() as d:
            src = os.path.join(d, "doc.typ")
            out = os.path.join(d, "doc.html")
            with open(src, "w", encoding="utf-8") as f:
                f.write("= Title\nHello, *world*!\n")
            result = self.run_cli("compile", "--features", "html", "-f", "html", src, out)
            self.assertEqual(result.returncode, 0)
            self.assertIn("warning: html export is under active development", result.stderr)
            with open(out, encoding="utf-8") as f:
                html = f.read()
            self.assertIn("<h2>Title</h2>", html)
            self.assertIn("<p>Hello, <strong>world</strong>!</p>", html)

if __name__ == "__main__":
    unittest.main()
