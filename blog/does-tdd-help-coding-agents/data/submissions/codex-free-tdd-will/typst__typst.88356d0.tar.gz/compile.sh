#!/bin/bash
set -e
mkdir -p build
cp src/executable.py build/test-executable
chmod +x build/test-executable
rm -f executable
cp src/executable.py executable
chmod +x executable
