#!/usr/bin/env python3
import json
import re
import sys


RC = [
    0x0000000000000001, 0x0000000000008082, 0x800000000000808A, 0x8000000080008000,
    0x000000000000808B, 0x0000000080000001, 0x8000000080008081, 0x8000000000008009,
    0x000000000000008A, 0x0000000000000088, 0x0000000080008009, 0x000000008000000A,
    0x000000008000808B, 0x800000000000008B, 0x8000000000008089, 0x8000000000008003,
    0x8000000000008002, 0x8000000000000080, 0x000000000000800A, 0x800000008000000A,
    0x8000000080008081, 0x8000000000008080, 0x0000000080000001, 0x8000000080008008,
]
ROT = [
    [0, 36, 3, 41, 18],
    [1, 44, 10, 45, 2],
    [62, 6, 43, 15, 61],
    [28, 55, 25, 21, 56],
    [27, 20, 39, 8, 14],
]


def rol(x, n):
    return ((x << n) | (x >> (64 - n))) & ((1 << 64) - 1)


def keccak256(data: bytes) -> bytes:
    rate = 136
    state = [0] * 25
    padded = data + b"\x01"
    padded += b"\x00" * ((rate - len(padded) % rate) % rate)
    padded = padded[:-1] + bytes([padded[-1] | 0x80])
    for off in range(0, len(padded), rate):
        block = padded[off:off + rate]
        for i in range(rate // 8):
            state[i] ^= int.from_bytes(block[i * 8:i * 8 + 8], "little")
        keccak_f(state)
    out = b""
    while len(out) < 32:
        for i in range(rate // 8):
            out += state[i].to_bytes(8, "little")
            if len(out) >= 32:
                break
        if len(out) < 32:
            keccak_f(state)
    return out[:32]


def keccak_f(a):
    mask = (1 << 64) - 1
    for rc in RC:
        c = [a[x] ^ a[x + 5] ^ a[x + 10] ^ a[x + 15] ^ a[x + 20] for x in range(5)]
        d = [c[(x - 1) % 5] ^ rol(c[(x + 1) % 5], 1) for x in range(5)]
        for x in range(5):
            for y in range(5):
                a[x + 5 * y] ^= d[x]
        b = [0] * 25
        for x in range(5):
            for y in range(5):
                b[y + 5 * ((2 * x + 3 * y) % 5)] = rol(a[x + 5 * y], ROT[x][y])
        for x in range(5):
            for y in range(5):
                a[x + 5 * y] = b[x + 5 * y] ^ ((~b[(x + 1) % 5 + 5 * y]) & b[(x + 2) % 5 + 5 * y])
                a[x + 5 * y] &= mask
        a[0] ^= rc


class AbiError(Exception):
    pass


class Typ:
    def __init__(self, base, sub=None, arr=None):
        self.base = base
        self.sub = sub
        self.arr = arr

    @property
    def dynamic(self):
        if self.arr is not None:
            n, sub = self.arr
            return n is None or sub.dynamic
        return self.base in ("string", "bytes")

    def canon(self):
        if self.arr is not None:
            n, sub = self.arr
            return sub.canon() + "[" + ("" if n is None else str(n)) + "]"
        if self.base == "uint":
            return "uint256"
        if self.base == "int":
            return "int256"
        return self.base


def parse_type(s):
    dims = []
    while s.endswith("]"):
        m = re.search(r"\[(\d*)\]$", s)
        dims.insert(0, None if m.group(1) == "" else int(m.group(1)))
        s = s[:m.start()]
    t = Typ(s)
    for d in reversed(dims):
        t = Typ("array", sub=t, arr=(d, t))
    return t


def clean_hex(s):
    if s.startswith(("0x", "0X")):
        raise AbiError("Hex parsing error: Invalid character 'x' at position 1\n\nCaused by:\n    Invalid character 'x' at position 1")
    if len(s) % 2:
        raise AbiError("Hex parsing error: Odd number of digits\n\nCaused by:\n    Odd number of digits")
    try:
        bytes.fromhex(s)
    except ValueError:
        raise AbiError("Hex parsing error: Invalid data")
    return s.lower()


def word(n):
    return (n % (1 << 256)).to_bytes(32, "big").hex()


def pad_right_hex(h):
    return h + "0" * ((64 - len(h) % 64) % 64)


def split_array(s):
    s = s.strip()
    if not (s.startswith("[") and s.endswith("]")):
        raise AbiError("Invalid data")
    body = s[1:-1].strip()
    if not body:
        return []
    return [p.strip() for p in body.split(",")]


def parse_int_value(val, bits, signed, lenient):
    if lenient:
        n = int(val, 10)
    else:
        h = clean_hex(val)
        if len(h) != 64:
            raise AbiError("Invalid data")
        n = int(h, 16)
    if signed:
        lo, hi = -(1 << (bits - 1)), (1 << (bits - 1)) - 1
    else:
        lo, hi = 0, (1 << bits) - 1
    if not lo <= n <= hi:
        raise AbiError("Invalid data")
    return n


def enc_static(t, val, lenient):
    if t.arr is not None:
        n, sub = t.arr
        vals = split_array(val) if isinstance(val, str) else val
        if n is not None and len(vals) != n:
            raise AbiError("Invalid data")
        return encode_tuple([sub] * len(vals), vals, lenient, force_inline=True)
    b = t.base
    if b == "bool":
        return word(1 if val in ("1", "true", "True", True) else 0)
    if b == "address":
        h = clean_hex(str(val))
        if len(h) != 40:
            raise AbiError("Invalid data")
        return "0" * 24 + h
    if b.startswith("uint"):
        bits = int(b[4:] or "256")
        return word(parse_int_value(str(val), bits, False, lenient))
    if b.startswith("int"):
        bits = int(b[3:] or "256")
        return word(parse_int_value(str(val), bits, True, lenient))
    if re.fullmatch(r"bytes\d+", b):
        size = int(b[5:])
        h = clean_hex(str(val))
        if len(h) != size * 2:
            raise AbiError("Invalid data")
        return h + "0" * (64 - len(h))
    raise AbiError("Invalid data")


def enc_dynamic(t, val, lenient):
    if t.arr is not None:
        n, sub = t.arr
        vals = split_array(val) if isinstance(val, str) else val
        if n is not None and len(vals) != n:
            raise AbiError("Invalid data")
        body = encode_tuple([sub] * len(vals), vals, lenient, force_inline=True)
        return ("" if n is not None else word(len(vals))) + body
    if t.base == "string":
        data = str(val).encode()
        return word(len(data)) + pad_right_hex(data.hex())
    if t.base == "bytes":
        h = clean_hex(str(val))
        return word(len(h) // 2) + pad_right_hex(h)
    raise AbiError("Invalid data")


def encode_one(t, val, lenient):
    return enc_dynamic(t, val, lenient) if t.dynamic else enc_static(t, val, lenient)


def encode_tuple(types, vals, lenient=False, force_inline=False):
    if len(types) != len(vals):
        raise AbiError("Invalid data")
    heads, tails = [], []
    head_size = 32 * len(types)
    tail_size = 0
    for t, v in zip(types, vals):
        if t.dynamic:
            data = enc_dynamic(t, v, lenient)
            heads.append(word(head_size + tail_size))
            tails.append(data)
            tail_size += len(data) // 2
        else:
            heads.append(enc_static(t, v, lenient))
    return "".join(heads + tails)


def read_word(data, off):
    if off + 32 > len(data):
        raise AbiError("Invalid data")
    return int.from_bytes(data[off:off + 32], "big")


def dec_at(t, data, off):
    if t.arr is not None:
        if t.dynamic:
            return 32, dec_content(t, data, read_word(data, off))
        return 32, dec_content(t, data, off)
    b = t.base
    if b == "bool":
        return 32, "true" if read_word(data, off) else "false"
    if b == "address":
        return 32, data[off + 12:off + 32].hex()
    if b.startswith("uint"):
        return 32, str(read_word(data, off))
    if b.startswith("int"):
        n = read_word(data, off)
        if n >= (1 << 255):
            n -= 1 << 256
        return 32, str(n)
    if b == "string":
        return 32, dec_content(t, data, read_word(data, off))
    if b == "bytes":
        return 32, dec_content(t, data, read_word(data, off))
    if re.fullmatch(r"bytes\d+", b):
        size = int(b[5:])
        return 32, data[off:off + size].hex() + data[off + size:off + 32].hex()
    raise AbiError("Invalid data")


def dec_content(t, data, off):
    if t.arr is not None:
        n, sub = t.arr
        base = off
        head = off
        if n is None:
            n = read_word(data, base)
            head = base + 32
        vals = []
        for i in range(n):
            slot = head + 32 * i
            if sub.dynamic:
                vals.append(dec_content(sub, data, head + read_word(data, slot)))
            else:
                vals.append(dec_at(sub, data, slot)[1])
        return "[" + ",".join(vals) + "]"
    if t.base == "string":
        ln = read_word(data, off)
        return data[off + 32:off + 32 + ln].decode(errors="replace")
    if t.base == "bytes":
        ln = read_word(data, off)
        return data[off + 32:off + 32 + ln].hex()
    raise AbiError("Invalid data")


def decode_tuple(types, hdata):
    h = clean_hex(hdata)
    data = bytes.fromhex(h)
    out = []
    for i, t in enumerate(types):
        out.append((t.canon(), dec_at(t, data, i * 32)[1]))
    return out


def abi_items(path):
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)


def select_item(items, kind, name):
    if kind == "function" and "(" in name:
        candidates = []
        for x in items:
            if x.get("type") != kind:
                continue
            ins = ",".join(parse_type(i["type"]).canon() for i in x.get("inputs", []))
            outs = ",".join(parse_type(o["type"]).canon() for o in x.get("outputs", []))
            if (not outs and name == f'{x["name"]}({ins})') or name == f'{x["name"]}({ins}):({outs})':
                candidates.append(x)
        if candidates:
            return candidates[0]
        raise AbiError(f"invalid function signature `{name}`")
    candidates = [x for x in items if x.get("type") == kind and x.get("name") == name]
    if not candidates:
        raise AbiError(f"{kind} not found")
    if len(candidates) > 1:
        raise AbiError(f"More than one {kind} found for name `{name}`, try providing the full signature")
    return candidates[0]


def signature(item):
    return item["name"] + "(" + ",".join(parse_type(i["type"]).canon() for i in item.get("inputs", [])) + ")"


def params_from_argv(argv):
    lenient = False
    pairs = []
    i = 0
    while i < len(argv):
        if argv[i] in ("-l", "--lenient"):
            lenient = True
            i += 1
        elif argv[i] == "-v":
            pairs.append((argv[i + 1], argv[i + 2]))
            i += 3
        else:
            raise AbiError("Invalid data")
    return lenient, pairs


def main(argv):
    try:
        helps = {
            (): """ethabi-cli 18.0.0
Ethereum ABI coder

USAGE:
    executable <SUBCOMMAND>

FLAGS:
    -h, --help       Prints help information
    -V, --version    Prints version information

SUBCOMMANDS:
    decode    Decode ABI call result
    encode    Encode ABI call
    help      Prints this message or the help of the given subcommand(s)""",
            ("encode",): """executable-encode 18.0.0
Encode ABI call

USAGE:
    executable encode <SUBCOMMAND>

FLAGS:
    -h, --help       Prints help information
    -V, --version    Prints version information

SUBCOMMANDS:
    function    Load function from JSON ABI file
    help        Prints this message or the help of the given subcommand(s)
    params      Specify types of input params inline""",
            ("decode",): """executable-decode 18.0.0
Decode ABI call result

USAGE:
    executable decode <SUBCOMMAND>

FLAGS:
    -h, --help       Prints help information
    -V, --version    Prints version information

SUBCOMMANDS:
    function    Load function from JSON ABI file
    help        Prints this message or the help of the given subcommand(s)
    log         Decode event log
    params      Specify types of input params inline""",
            ("encode", "params"): """executable-encode-params 18.0.0
Specify types of input params inline

USAGE:
    executable encode params [FLAGS] [OPTIONS]

FLAGS:
    -h, --help       
            Prints help information

    -l, --lenient    
            Allow short representation of input params (numbers are in decimal form)

    -V, --version    
            Prints version information


OPTIONS:
    -v <type-or-param> <type-or-param>        
            Pairs of types directly followed by params in the form:
            
            -v <type1> <param1> -v <type2> <param2> ...""",
            ("encode", "function"): """executable-encode-function 18.0.0
Load function from JSON ABI file

USAGE:
    executable encode function [FLAGS] [OPTIONS] <abi-path> <function-name-or-signature>

FLAGS:
    -h, --help       Prints help information
    -l, --lenient    Allow short representation of input params
    -V, --version    Prints version information

OPTIONS:
    -p <params>...        

ARGS:
    <abi-path>                      
    <function-name-or-signature>    """,
            ("decode", "params"): """executable-decode-params 18.0.0
Specify types of input params inline

USAGE:
    executable decode params [OPTIONS] <data>

FLAGS:
    -h, --help       Prints help information
    -V, --version    Prints version information

OPTIONS:
    -t <type>...        

ARGS:
    <data>    """,
            ("decode", "function"): """executable-decode-function 18.0.0
Load function from JSON ABI file

USAGE:
    executable decode function <abi-path> <function-name-or-signature> <data>

FLAGS:
    -h, --help       Prints help information
    -V, --version    Prints version information

ARGS:
    <abi-path>                      
    <function-name-or-signature>    
    <data>                          """,
            ("decode", "log"): """executable-decode-log 18.0.0
Decode event log

USAGE:
    executable decode log [OPTIONS] <abi-path> <event-name-or-signature> <data>

FLAGS:
    -h, --help       Prints help information
    -V, --version    Prints version information

OPTIONS:
    -l <topic>...        

ARGS:
    <abi-path>                   
    <event-name-or-signature>    
    <data>                       """,
        }
        if argv in (["--help"], ["-h"], ["help"], []):
            print(helps[()])
            return 0
        for key, text in helps.items():
            if key and tuple(argv[:len(key)]) == key and (argv[len(key):] in (["--help"], ["-h"], ["help"])):
                print(text)
                return 0
        if argv == ["encode", "--help"] or argv == ["encode", "-h"]:
            print(helps[("encode",)])
            return 0
        if argv == ["decode", "--help"] or argv == ["decode", "-h"]:
            print(helps[("decode",)])
            return 0
        if argv == ["--version"] or argv == ["-V"]:
            print("ethabi-cli 18.0.0")
            return 0
        if argv[:2] == ["encode", "params"]:
            lenient, pairs = params_from_argv(argv[2:])
            print(encode_tuple([parse_type(t) for t, _ in pairs], [v for _, v in pairs], lenient))
            return 0
        if argv[:2] == ["decode", "params"]:
            types = []
            i = 2
            while i < len(argv) - 1:
                if argv[i] != "-t":
                    raise AbiError("Invalid data")
                types.append(parse_type(argv[i + 1]))
                i += 2
            for typ, val in decode_tuple(types, argv[-1]):
                print(typ, val)
            return 0
        if argv[:2] == ["encode", "function"]:
            lenient = False
            path, name = argv[2], argv[3]
            params = []
            i = 4
            while i < len(argv):
                if argv[i] in ("-l", "--lenient"):
                    lenient = True
                    i += 1
                elif argv[i] == "-p":
                    params.append(argv[i + 1])
                    i += 2
                else:
                    raise AbiError("Invalid data")
            item = select_item(abi_items(path), "function", name)
            types = [parse_type(x["type"]) for x in item.get("inputs", [])]
            print(keccak256(signature(item).encode()).hex()[:8] + encode_tuple(types, params, lenient))
            return 0
        if argv[:2] == ["decode", "function"]:
            item = select_item(abi_items(argv[2]), "function", argv[3])
            types = [parse_type(x["type"]) for x in item.get("outputs", [])]
            for typ, val in decode_tuple(types, argv[4]):
                print(typ, val)
            return 0
        if argv[:2] == ["decode", "log"]:
            path, name = argv[2], argv[3]
            topics = []
            i = 4
            while i < len(argv) - 1:
                if argv[i] != "-l":
                    raise AbiError("Invalid data")
                topics.append(argv[i + 1])
                i += 2
            data_hex = argv[-1]
            item = select_item(abi_items(path), "event", name)
            indexed = [x for x in item.get("inputs", []) if x.get("indexed")]
            plain = [x for x in item.get("inputs", []) if not x.get("indexed")]
            if not item.get("anonymous") and len(topics) == len(indexed) + 1:
                topics = topics[1:]
            vals = []
            for inp, top in zip(indexed, topics):
                vals.append((inp.get("name") or parse_type(inp["type"]).canon(), dec_at(parse_type(inp["type"]), bytes.fromhex(clean_hex(top)), 0)[1]))
            decoded = decode_tuple([parse_type(x["type"]) for x in plain], data_hex) if plain else []
            for inp, (_, val) in zip(plain, decoded):
                vals.append((inp.get("name") or parse_type(inp["type"]).canon(), val))
            for n, v in vals:
                print(n, v)
            return 0
        raise AbiError("unsupported")
    except AbiError as e:
        print("Error: " + str(e), file=sys.stderr)
        return 1
    except Exception as e:
        print("Error: " + str(e), file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
