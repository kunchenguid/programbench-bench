#!/bin/bash
set -e
cp src/ethabi_cli.py executable
chmod +x executable
