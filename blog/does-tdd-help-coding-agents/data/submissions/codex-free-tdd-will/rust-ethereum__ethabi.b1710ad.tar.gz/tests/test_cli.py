import subprocess
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
BIN = ROOT / "executable"
ASSETS = Path("/workspace/assets") if Path("/workspace/assets").exists() else ROOT / "assets"


def run_cmd(*args):
    return subprocess.run([str(BIN), *map(str, args)], text=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)


class CliTests(unittest.TestCase):
    def test_encode_bool_param(self):
        p = run_cmd("encode", "params", "-v", "bool", "1")
        self.assertEqual(p.returncode, 0)
        self.assertEqual(p.stdout, "0000000000000000000000000000000000000000000000000000000000000001\n")

    def test_encode_dynamic_string_between_static_values(self):
        p = run_cmd("encode", "params", "-v", "bool", "1", "-v", "string", "example", "-v", "bool", "0")
        self.assertEqual(p.returncode, 0)
        self.assertEqual(p.stdout.strip(), "00000000000000000000000000000000000000000000000000000000000000010000000000000000000000000000000000000000000000000000000000000060000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000076578616d706c6500000000000000000000000000000000000000000000000000")

    def test_lenient_uint_array(self):
        p = run_cmd("encode", "params", "-l", "-v", "uint256[]", "[1,2,3]")
        self.assertEqual(p.returncode, 0)
        self.assertIn("0000000000000000000000000000000000000000000000000000000000000003", p.stdout)

    def test_decode_values(self):
        p = run_cmd("decode", "params", "-t", "bool", "-t", "uint256", "00000000000000000000000000000000000000000000000000000000000000010000000000000000000000000000000000000000000000000000000000000005")
        self.assertEqual(p.returncode, 0)
        self.assertEqual(p.stdout, "bool true\nuint256 5\n")

    def test_function_encoding_uses_abi_selector(self):
        p = run_cmd("encode", "function", ASSETS / "test.abi", "foo", "-p", "1")
        self.assertEqual(p.returncode, 0)
        self.assertEqual(p.stdout.strip(), "455575780000000000000000000000000000000000000000000000000000000000000001")


if __name__ == "__main__":
    unittest.main()
