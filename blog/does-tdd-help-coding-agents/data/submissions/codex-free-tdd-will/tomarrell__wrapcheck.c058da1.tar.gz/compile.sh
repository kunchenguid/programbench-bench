#!/bin/bash
set -e
GOFLAGS=${GOFLAGS:-}
go build -o executable ./src
chmod +x executable
