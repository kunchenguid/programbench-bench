module rewrapcheck

go 1.21
