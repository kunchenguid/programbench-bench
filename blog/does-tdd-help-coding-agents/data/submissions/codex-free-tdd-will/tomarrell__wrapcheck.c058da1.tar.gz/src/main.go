package main

import (
	"encoding/json"
	"flag"
	"fmt"
	"go/ast"
	"go/parser"
	"go/token"
	"io/fs"
	"os"
	"path/filepath"
	"regexp"
	"sort"
	"strings"
)

type config struct {
	IgnoreSigs        []string
	ExtraIgnoreSigs   []string
	IgnoreSigRegexps  []string
	IgnorePackageGlob []string
	ReportInternal    bool
}

type diagnostic struct {
	Package string
	Pos     token.Position
	Message string
}

type packageInfo struct {
	Dir        string
	ImportPath string
	ModulePath string
}

type fileInfo struct {
	File    *ast.File
	Imports map[string]string
}

type callSig struct {
	Sig        string
	ImportPath string
}

var defaultIgnoreSigs = []string{
	".Errorf(",
	"errors.New(",
	"errors.Unwrap(",
	"errors.Join(",
	".Wrap(",
	".Wrapf(",
	".WithMessage(",
	".WithMessagef(",
	".WithStack(",
}

func main() {
	jsonOut := flag.Bool("json", false, "emit JSON output")
	flagsOut := flag.Bool("flags", false, "print analyzer flags in JSON")
	version := flag.Bool("V", false, "print version and exit")
	flag.Bool("all", false, "no effect (deprecated)")
	flag.Int("c", -1, "display offending line with this many lines of context")
	flag.String("cpuprofile", "", "write CPU profile to this file")
	flag.String("debug", "", "debug flags, any subset of \"fpstv\"")
	flag.Bool("diff", false, "with -fix, don't update the files, but print a unified diff")
	flag.Bool("fix", false, "apply all suggested fixes")
	flag.String("memprofile", "", "write memory profile to this file")
	flag.Bool("source", false, "no effect (deprecated)")
	flag.String("tags", "", "no effect (deprecated)")
	includeTests := flag.Bool("test", true, "indicates whether test files should be analyzed, too")
	flag.String("trace", "", "write trace log to this file")
	flag.Bool("v", false, "no effect (deprecated)")
	flag.Usage = usage
	flag.Parse()

	if *version {
		fmt.Println("wrapcheck version unknown")
		return
	}
	if *flagsOut {
		printFlagsJSON()
		return
	}

	patterns := flag.Args()
	if len(patterns) == 0 {
		patterns = []string{"."}
	}

	cfg := loadConfig(".")
	pkgs, err := discoverPackages(patterns)
	if err != nil {
		fmt.Fprintf(os.Stderr, "wrapcheck: err: %v\n", err)
		os.Exit(1)
	}
	var diags []diagnostic
	for _, pkg := range pkgs {
		ds := analyzePackage(pkg, cfg, *includeTests)
		diags = append(diags, ds...)
	}
	sort.Slice(diags, func(i, j int) bool {
		if diags[i].Pos.Filename != diags[j].Pos.Filename {
			return diags[i].Pos.Filename < diags[j].Pos.Filename
		}
		if diags[i].Pos.Line != diags[j].Pos.Line {
			return diags[i].Pos.Line < diags[j].Pos.Line
		}
		return diags[i].Pos.Column < diags[j].Pos.Column
	})

	if *jsonOut {
		printJSON(diags)
		return
	}
	for _, d := range diags {
		fmt.Printf("%s:%d:%d: %s\n", d.Pos.Filename, d.Pos.Line, d.Pos.Column, d.Message)
	}
	if len(diags) > 0 {
		os.Exit(3)
	}
}

func usage() {
	fmt.Fprint(os.Stderr, `wrapcheck: Checks that errors returned from external packages are wrapped

Usage: wrapcheck [-flag] [package]


Flags:
`)
	flag.PrintDefaults()
}

func printFlagsJSON() {
	type f struct {
		Name  string
		Bool  bool
		Usage string
	}
	flags := []f{
		{"V", true, "print version and exit"},
		{"all", true, "no effect (deprecated)"},
		{"c", false, "display offending line with this many lines of context"},
		{"diff", true, "with -fix, don't update the files, but print a unified diff"},
		{"flags", true, "print analyzer flags in JSON"},
		{"json", true, "emit JSON output"},
		{"source", true, "no effect (deprecated)"},
		{"tags", false, "no effect (deprecated)"},
		{"test", true, "indicates whether test files should be analyzed, too"},
		{"v", true, "no effect (deprecated)"},
	}
	b, _ := json.MarshalIndent(flags, "", "\t")
	fmt.Print(string(b))
}

func printJSON(diags []diagnostic) {
	type item struct {
		Posn    string `json:"posn"`
		Message string `json:"message"`
	}
	out := map[string]map[string][]item{}
	for _, d := range diags {
		if _, ok := out[d.Package]; !ok {
			out[d.Package] = map[string][]item{}
		}
		posn := fmt.Sprintf("%s:%d:%d", d.Pos.Filename, d.Pos.Line, d.Pos.Column)
		out[d.Package]["wrapcheck"] = append(out[d.Package]["wrapcheck"], item{posn, d.Message})
	}
	b, _ := json.MarshalIndent(out, "", "\t")
	fmt.Println(string(b))
}

func discoverPackages(patterns []string) ([]packageInfo, error) {
	modRoot, modPath := findModule(".")
	var pkgs []packageInfo
	seen := map[string]bool{}
	for _, pat := range patterns {
		if strings.HasSuffix(pat, "/...") {
			base := strings.TrimSuffix(pat, "/...")
			if base == "" {
				base = "."
			}
			err := filepath.WalkDir(base, func(path string, de fs.DirEntry, err error) error {
				if err != nil {
					return err
				}
				if !de.IsDir() {
					return nil
				}
				name := de.Name()
				if strings.HasPrefix(name, ".") || name == "vendor" || name == "testdata" {
					if path != base {
						return filepath.SkipDir
					}
				}
				if hasGoFiles(path) {
					addPackage(&pkgs, seen, path, modRoot, modPath)
				}
				return nil
			})
			if err != nil {
				return nil, err
			}
			continue
		}
		addPackage(&pkgs, seen, pat, modRoot, modPath)
	}
	return pkgs, nil
}

func addPackage(pkgs *[]packageInfo, seen map[string]bool, dir, modRoot, modPath string) {
	abs, err := filepath.Abs(dir)
	if err != nil || seen[abs] {
		return
	}
	seen[abs] = true
	ip := abs
	if modRoot != "" && modPath != "" {
		if rel, err := filepath.Rel(modRoot, abs); err == nil {
			if rel == "." {
				ip = modPath
			} else if !strings.HasPrefix(rel, "..") {
				ip = modPath + "/" + filepath.ToSlash(rel)
			}
		}
	}
	*pkgs = append(*pkgs, packageInfo{Dir: abs, ImportPath: ip, ModulePath: modPath})
}

func hasGoFiles(dir string) bool {
	ents, err := os.ReadDir(dir)
	if err != nil {
		return false
	}
	for _, ent := range ents {
		if !ent.IsDir() && strings.HasSuffix(ent.Name(), ".go") {
			return true
		}
	}
	return false
}

func findModule(start string) (string, string) {
	dir, _ := filepath.Abs(start)
	for {
		data, err := os.ReadFile(filepath.Join(dir, "go.mod"))
		if err == nil {
			for _, line := range strings.Split(string(data), "\n") {
				line = strings.TrimSpace(line)
				if strings.HasPrefix(line, "module ") {
					return dir, strings.TrimSpace(strings.TrimPrefix(line, "module "))
				}
			}
			return dir, ""
		}
		next := filepath.Dir(dir)
		if next == dir {
			return "", ""
		}
		dir = next
	}
}

func analyzePackage(pkg packageInfo, cfg config, includeTests bool) []diagnostic {
	fset := token.NewFileSet()
	parsed, err := parser.ParseDir(fset, pkg.Dir, func(fi os.FileInfo) bool {
		if !strings.HasSuffix(fi.Name(), ".go") {
			return false
		}
		return includeTests || !strings.HasSuffix(fi.Name(), "_test.go")
	}, 0)
	if err != nil {
		return nil
	}
	var diags []diagnostic
	for _, astPkg := range parsed {
		for _, f := range astPkg.Files {
			info := fileInfo{File: f, Imports: importsOf(f)}
			for _, decl := range f.Decls {
				fn, ok := decl.(*ast.FuncDecl)
				if !ok || fn.Body == nil {
					continue
				}
				diags = append(diags, analyzeFunc(fset, pkg, info, fn, cfg)...)
			}
		}
	}
	return diags
}

func importsOf(f *ast.File) map[string]string {
	out := map[string]string{}
	for _, im := range f.Imports {
		path := strings.Trim(im.Path.Value, "\"")
		if im.Name != nil {
			if im.Name.Name == "_" || im.Name.Name == "." {
				continue
			}
			out[im.Name.Name] = path
			continue
		}
		parts := strings.Split(path, "/")
		out[parts[len(parts)-1]] = path
	}
	return out
}

func analyzeFunc(fset *token.FileSet, pkg packageInfo, file fileInfo, fn *ast.FuncDecl, cfg config) []diagnostic {
	var diags []diagnostic
	errVars := map[string]callSig{}
	types := map[string]string{}
	collectParamTypes(fn.Type.Params, file.Imports, types)

	ast.Inspect(fn.Body, func(n ast.Node) bool {
		switch s := n.(type) {
		case *ast.AssignStmt:
			for i, lhs := range s.Lhs {
				id, ok := lhs.(*ast.Ident)
				if !ok {
					continue
				}
				if i < len(s.Rhs) {
					if sig, ok := externalCallSig(s.Rhs[i], file.Imports, pkg, types); ok && !ignored(sig, cfg) {
						errVars[id.Name] = sig
					}
					collectVarType(id.Name, s.Rhs[i], file.Imports, types)
				} else if len(s.Rhs) == 1 {
					if sig, ok := externalCallSig(s.Rhs[0], file.Imports, pkg, types); ok && !ignored(sig, cfg) {
						errVars[id.Name] = sig
					}
				}
			}
		case *ast.ValueSpec:
			for i, name := range s.Names {
				if s.Type != nil {
					if t := typeFromExpr(s.Type, file.Imports); t != "" {
						types[name.Name] = t
					}
				}
				if i < len(s.Values) {
					collectVarType(name.Name, s.Values[i], file.Imports, types)
				}
			}
		case *ast.ReturnStmt:
			for _, expr := range s.Results {
				if sig, ok := externalCallSig(expr, file.Imports, pkg, types); ok && !ignored(sig, cfg) {
					diags = append(diags, diagnostic{pkg.ImportPath, fset.Position(expr.Pos()), message(sig)})
					continue
				}
				if id, ok := expr.(*ast.Ident); ok {
					if sig, ok := errVars[id.Name]; ok && !ignored(sig, cfg) {
						diags = append(diags, diagnostic{pkg.ImportPath, fset.Position(expr.Pos()), message(sig)})
					}
				}
			}
		}
		return true
	})
	return diags
}

func collectParamTypes(fields *ast.FieldList, imports map[string]string, out map[string]string) {
	if fields == nil {
		return
	}
	for _, field := range fields.List {
		t := typeFromExpr(field.Type, imports)
		if t == "" {
			continue
		}
		for _, name := range field.Names {
			out[name.Name] = t
		}
	}
}

func collectVarType(name string, expr ast.Expr, imports map[string]string, out map[string]string) {
	switch e := expr.(type) {
	case *ast.CompositeLit:
		if t := typeFromExpr(e.Type, imports); t != "" {
			out[name] = t
		}
	case *ast.UnaryExpr:
		if cl, ok := e.X.(*ast.CompositeLit); ok {
			if t := typeFromExpr(cl.Type, imports); t != "" {
				out[name] = t
			}
		}
	}
}

func typeFromExpr(expr ast.Expr, imports map[string]string) string {
	switch t := expr.(type) {
	case *ast.StarExpr:
		return typeFromExpr(t.X, imports)
	case *ast.SelectorExpr:
		if id, ok := t.X.(*ast.Ident); ok {
			if p := imports[id.Name]; p != "" {
				return p + "." + t.Sel.Name
			}
		}
	}
	return ""
}

func externalCallSig(expr ast.Expr, imports map[string]string, pkg packageInfo, types map[string]string) (callSig, bool) {
	call, ok := expr.(*ast.CallExpr)
	if !ok {
		return callSig{}, false
	}
	sel, ok := call.Fun.(*ast.SelectorExpr)
	if !ok {
		return callSig{}, false
	}
	left, ok := sel.X.(*ast.Ident)
	if !ok {
		return callSig{}, false
	}
	if path := imports[left.Name]; path != "" {
		if !isExternal(path, pkg) {
			return callSig{}, false
		}
		return callSig{Sig: "func " + path + "." + sel.Sel.Name + "() error", ImportPath: path}, true
	}
	if typ := types[left.Name]; typ != "" {
		dot := strings.LastIndex(typ, ".")
		if dot > 0 {
			path := typ[:dot]
			name := typ[dot+1:]
			if !isExternal(path, pkg) {
				return callSig{}, false
			}
			return callSig{Sig: "func (" + path + "." + name + ")." + sel.Sel.Name + "() error", ImportPath: path}, true
		}
	}
	return callSig{}, false
}

func isExternal(path string, pkg packageInfo) bool {
	if path == pkg.ImportPath {
		return false
	}
	if pkg.ModulePath != "" && strings.HasPrefix(path, pkg.ModulePath+"/") {
		return true
	}
	return true
}

func message(sig callSig) string {
	return "error returned from external package is unwrapped: sig: " + sig.Sig
}

func ignored(sig callSig, cfg config) bool {
	check := append([]string{}, defaultIgnoreSigs...)
	if len(cfg.IgnoreSigs) > 0 {
		check = append([]string{}, cfg.IgnoreSigs...)
	}
	check = append(check, cfg.ExtraIgnoreSigs...)
	for _, s := range check {
		if strings.Contains(sig.Sig, s) {
			return true
		}
	}
	for _, pat := range cfg.IgnorePackageGlob {
		if ok, _ := filepath.Match(pat, sig.ImportPath); ok {
			return true
		}
	}
	for _, re := range cfg.IgnoreSigRegexps {
		if ok, _ := regexp.MatchString(re, sig.Sig); ok {
			return true
		}
	}
	return false
}

func loadConfig(start string) config {
	cfg := config{}
	for _, p := range []string{filepath.Join(start, ".wrapcheck.yaml"), filepath.Join(os.Getenv("HOME"), ".wrapcheck.yaml")} {
		data, err := os.ReadFile(p)
		if err == nil {
			parseYAMLListConfig(string(data), &cfg)
			return cfg
		}
	}
	return cfg
}

func parseYAMLListConfig(s string, cfg *config) {
	var key string
	for _, raw := range strings.Split(s, "\n") {
		line := strings.TrimSpace(raw)
		if line == "" || strings.HasPrefix(line, "#") {
			continue
		}
		if strings.HasSuffix(line, ":") {
			key = strings.TrimSuffix(line, ":")
			continue
		}
		if strings.Contains(line, ":") && !strings.HasPrefix(line, "-") {
			parts := strings.SplitN(line, ":", 2)
			key = strings.TrimSpace(parts[0])
			val := strings.TrimSpace(parts[1])
			if key == "reportInternalErrors" {
				cfg.ReportInternal = val == "true"
			}
			continue
		}
		if strings.HasPrefix(line, "-") {
			val := strings.TrimSpace(strings.TrimPrefix(line, "-"))
			val = strings.Trim(val, "\"'")
			switch key {
			case "ignoreSigs":
				cfg.IgnoreSigs = append(cfg.IgnoreSigs, val)
			case "extraIgnoreSigs":
				cfg.ExtraIgnoreSigs = append(cfg.ExtraIgnoreSigs, val)
			case "ignoreSigRegexps":
				cfg.IgnoreSigRegexps = append(cfg.IgnoreSigRegexps, val)
			case "ignorePackageGlobs":
				cfg.IgnorePackageGlob = append(cfg.IgnorePackageGlob, val)
			}
		}
	}
}
