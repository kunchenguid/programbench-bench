#!/bin/bash
set -e
cp src/minisqlite.py executable
chmod +x executable
