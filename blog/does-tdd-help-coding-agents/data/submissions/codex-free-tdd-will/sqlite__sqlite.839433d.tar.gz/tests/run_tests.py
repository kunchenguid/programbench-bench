#!/usr/bin/env python3
import os, subprocess, tempfile, shutil
ROOT=os.path.dirname(os.path.dirname(__file__))
EXE=os.path.join(ROOT,'executable')

def build():
    subprocess.run(['bash','compile.sh'],cwd=ROOT,check=True,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True)

def run(args,input=None):
    p=subprocess.run([EXE]+args,cwd=ROOT,input=input,text=True,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
    return p.returncode,p.stdout,p.stderr

def assert_eq(got,exp,msg):
    if got!=exp:
        raise AssertionError(f'{msg}\nGOT: {got!r}\nEXP: {exp!r}')

def test_version_and_help():
    code,out,err=run(['-version'])
    assert_eq(code,0,'version status')
    assert out.startswith('3.54.0 2026-04-14 20:02:49 '), out
    code,out,err=run(['--help'])
    assert_eq(code,0,'help status')
    assert 'Usage: ' in out and '[FILENAME [SQL...]]' in out and '-csv' in out

def test_simple_select_expressions():
    assert_eq(run([':memory:', 'select 1;']),(0,'1\n',''),'select literal')
    assert_eq(run([':memory:', "select 1+2, upper('abc'), null;"]),(0,'3|ABC|\n',''),'select expression list')

def test_table_crud_and_aggregates():
    sql="""create table t(a int,b text);
insert into t values(1,'x'),(2,'y'),(3,'x');
select a,b from t where b='x' order by a desc;
select count(*), avg(a), min(b), max(a) from t;
update t set b='z' where a=2;
delete from t where a=1;
select * from t order by a;
"""
    assert_eq(run([':memory:'], sql),(0,'3|x\n1|x\n3|2.0|x|3\n2|z\n3|x\n',''),'table crud')

def test_persistence_schema_tables_and_modes():
    with tempfile.TemporaryDirectory() as td:
        db=os.path.join(td,'x.db')
        assert_eq(run([db, "create table alpha(x,y); insert into alpha values(1,'a,b');"]),(0,'',''),'create persistent')
        assert_eq(run([db, '.tables']),(0,'alpha\n',''),'tables')
        assert_eq(run([db, '.schema alpha']),(0,'CREATE TABLE alpha(x,y);\n',''),'schema')
        assert_eq(run(['-csv','-header',db,"select x,y,null from alpha;"]),(0,'x,y,null\n1,"a,b",\n',''),'csv headers')
        assert_eq(run(['-json',db,"select x,y,null from alpha;"]),(0,'[{"x":1,"y":"a,b","null":null}]\n',''),'json')
        assert_eq(run(['-quote',db,"select 'it''s', 5, null;"]),(0,"'it''s',5,NULL\n",''),'quote')

def test_insert_column_list_boolean_distinct_limit():
    sql="""create table people(id,name,age);
insert into people(name,id) values('ann',2),('bob',1),('ann',3);
select distinct name from people where age is null or id>1 order by name limit 1;
"""
    assert_eq(run([':memory:'], sql),(0,'ann\n',''),'distinct limit where')

if __name__=='__main__':
    build()
    tests=[test_version_and_help, test_simple_select_expressions, test_table_crud_and_aggregates, test_persistence_schema_tables_and_modes, test_insert_column_list_boolean_distinct_limit]
    for t in tests:
        t()
        print('ok',t.__name__)
