#!/usr/bin/env python3
import sys, os, json, re, csv, io, math
VERSION='3.54.0 2026-04-14 20:02:49 49b3bac482c831f503c7f90c35959e7ea731950e991baba86b2ab95987d2539b (64-bit)'
HELP="""Usage: ./executable [OPTIONS] [FILENAME [SQL...]]
FILENAME is the name of an SQLite database. A new database is created
if the file does not previously exist. Defaults to :memory:.
OPTIONS include:
   --                   treat no subsequent arguments as options
   -A ARGS...           run ".archive ARGS" and exit
   -append              append the database to the end of the file
   -ascii               set output mode to 'ascii'
   -bail                stop after hitting an error
   -batch               force batch I/O
   -box                 set output mode to 'box'
   -cmd COMMAND         run "COMMAND" before reading stdin
   -column              set output mode to 'column'
   -csv                 set output mode to 'csv'
   -deserialize         open the database using sqlite3_deserialize()
   -echo                print inputs before execution
   -escape T            ctrl-char escape; T is one of: symbol, ascii, off
   -init FILENAME       read/process named file
   -[no]header          turn headers on or off
   -help                show this message
   -html                set output mode to HTML
   -ifexists            only open if database already exists
   -interactive         force interactive I/O
   -json                set output mode to 'json'
   -line                set output mode to 'line'
   -list                set output mode to 'list'
   -lookaside SIZE N    use N entries of SZ bytes for lookaside memory
   -markdown            set output mode to 'markdown'
   -maxsize N           maximum size for a --deserialize database
   -memtrace            trace all memory allocations and deallocations
   -mmap N              default mmap size set to N
   -newline SEP         set output row separator. Default: '\n'
   -nofollow            refuse to open symbolic links to database files
   -noinit              Do not read the ~/.sqliterc file at startup
   -nonce STRING        set the safe-mode escape nonce
   -no-rowid-in-view    Disable rowid-in-view using sqlite3_config()
   -nullvalue TEXT      set text string for NULL values. Default ''
   -pagecache SIZE N    use N slots of SZ bytes each for page cache memory
   -pcachetrace         trace all page cache operations
   -quote               set output mode to 'quote'
   -readonly            open the database read-only
   -safe                enable safe-mode
   -screenwidth N       use N as the default screenwidth 
   -separator SEP       set output column separator. Default: '|'
   -stats               print memory stats before each finalize
   -table               set output mode to 'table'
   -tabs                set output mode to 'tabs'
   -unsafe-testing      allow unsafe commands and modes for testing
   -version             show SQLite version
   -vfs NAME            use NAME as the default VFS
   -vfstrace            enable tracing of all VFS calls
   -zip                 open the file as a ZIP Archive
"""
HELP_DOT=""".archive ...             Manage SQL archives
.auth ON|OFF             Show authorizer callbacks
.backup ?DB? FILE        Backup DB (default "main") to FILE
.bail on|off             Stop after hitting an error.  Default OFF
.cd DIRECTORY            Change the working directory to DIRECTORY
.changes on|off          Show number of rows changed by SQL
.clone NEWDB             Clone data into NEWDB from the existing database
.connection [close] [#]  Open or close an auxiliary database connection
.crlf ?on|off?           Whether or not to use \r\n line endings
.databases               List names and files of attached databases
.dbconfig ?op? ?val?     List or change sqlite3_db_config() options
.dbinfo ?DB?             Show status information about the database
.dbtotxt                 Hex dump of the database file
.dump ?OBJECTS?          Render database content as SQL
.echo on|off             Turn command echo on or off
.eqp on|off|full|...     Enable or disable automatic EXPLAIN QUERY PLAN
.excel                   Display the output of next command in spreadsheet
.exit ?CODE?             Exit this program with return-code CODE
.expert                  EXPERIMENTAL. Suggest indexes for queries
.explain ?on|off|auto?   Change the EXPLAIN formatting mode.  Default: auto
.filectrl CMD ...        Run various sqlite3_file_control() operations
.fullschema ?--indent?   Show schema and the content of sqlite_stat tables
.headers on|off          Turn display of headers on or off
.help ?-all? ?PATTERN?   Show help text for PATTERN
.import FILE TABLE       Import data from FILE into TABLE
.indexes ?PATTERN?       Show names of indexes matching PATTERN
.limit ?LIMIT? ?VAL?     Display or change the value of an SQLITE_LIMIT
.load FILE ?ENTRY?       Load an extension library
.mode ?MODE? ?OPTIONS?   Set output mode
.nullvalue STRING        Use STRING in place of NULL values
.once ?OPTIONS? ?FILE?   Output for the next SQL command only to FILE
.open ?OPTIONS? ?FILE?   Close existing database and reopen FILE
.output ?FILE?           Send output to FILE or stdout if FILE is omitted
.print STRING...         Print literal STRING
.quit                    Stop interpreting input stream, exit if primary.
.read FILE               Read input from FILE or command output
.schema ?PATTERN?        Show the CREATE statements matching PATTERN
.shell CMD ARGS...       Run CMD ARGS... in a system shell
.tables ?TABLE?          List names of tables matching LIKE pattern TABLE
.timer on|off|once       Turn SQL timer on or off.
.version                 Show source, library and compiler versions
"""

def split_top(s, sep=','):
    out=[]; cur=[]; q=False; par=0; i=0
    while i < len(s):
        c=s[i]
        if q:
            cur.append(c)
            if c=="'":
                if i+1<len(s) and s[i+1]=="'": cur.append("'"); i+=1
                else: q=False
        else:
            if c=="'": q=True; cur.append(c)
            elif c=='(': par+=1; cur.append(c)
            elif c==')': par-=1; cur.append(c)
            elif c==sep and par==0:
                out.append(''.join(cur).strip()); cur=[]
            else: cur.append(c)
        i+=1
    out.append(''.join(cur).strip())
    return out

def split_statements(text):
    res=[]; cur=[]; q=False; line_start=True; i=0
    for line in text.splitlines(True):
        if line.lstrip().startswith('.') and not cur:
            res.append(line.strip()); continue
        for c in line:
            if q:
                cur.append(c)
                if c=="'": q=False
            else:
                if c=="'": q=True; cur.append(c)
                elif c==';':
                    st=''.join(cur).strip(); cur=[]
                    if st: res.append(st)
                else: cur.append(c)
    st=''.join(cur).strip()
    if st: res.append(st)
    return res

def sql_quote(v):
    if v is None: return 'NULL'
    if isinstance(v,(int,float)): return str(v)
    return "'"+str(v).replace("'","''")+"'"

def parse_literal(s):
    s=s.strip()
    if len(s)>=2 and s[0]=="'" and s[-1]=="'": return s[1:-1].replace("''","'")
    if re.fullmatch(r'[-+]?\d+',s): return int(s)
    if re.fullmatch(r'[-+]?\d*\.\d+',s): return float(s)
    if s.lower()=='null': return None
    return None

def eval_expr(expr, row=None):
    expr=strip_alias(expr)[0].strip()
    lit=parse_literal(expr)
    if lit is not None or expr.lower()=='null': return lit
    m=re.match(r'(?is)^(upper|lower|length|abs|round)\((.*)\)$',expr)
    if m:
        v=eval_expr(m.group(2),row); fn=m.group(1).lower()
        if v is None: return None
        if fn=='upper': return str(v).upper()
        if fn=='lower': return str(v).lower()
        if fn=='length': return len(str(v))
        if fn=='abs': return abs(v)
        if fn=='round': return int(v+0.5) if isinstance(v,(int,float)) else v
    if row:
        key=expr.lower()
        if key in row: return row[key]
    if re.fullmatch(r'[0-9+\-*/ ().]+',expr):
        try:
            val=eval(expr, {'__builtins__':{}}, {})
            if isinstance(val,float) and val.is_integer(): return int(val)
            return val
        except Exception: pass
    return ''

def strip_alias(expr):
    m=re.match(r'(?is)^(.*?)(?:\s+as\s+|\s+)([A-Za-z_]\w*)$',expr.strip())
    if m and not re.search(r'\)$', m.group(2)):
        return m.group(1).strip(), m.group(2)
    return expr.strip(), expr.strip()

class Shell:
    def __init__(self):
        self.mode='list'; self.headers=False; self.sep='|'; self.null=''; self.dbfile=':memory:'
        self.db={'tables':{}}
    def load(self, path):
        self.dbfile=path
        if path!=':memory:' and os.path.exists(path):
            try:
                with open(path) as f: self.db=json.load(f)
            except Exception: self.db={'tables':{}}
    def save(self):
        if self.dbfile!=':memory:':
            with open(self.dbfile,'w') as f: json.dump(self.db,f)
    def out_rows(self, cols, rows):
        if not rows and not self.headers: return
        if self.mode=='json':
            print(json.dumps([{cols[i]:r[i] for i in range(len(cols))} for r in rows], separators=(',',':'))); return
        if self.mode=='csv':
            w=csv.writer(sys.stdout, lineterminator='\r\n')
            if self.headers: w.writerow(cols)
            for r in rows: w.writerow(['' if v is None else v for v in r])
            return
        if self.mode=='quote':
            if self.headers: print(','.join(sql_quote(c) for c in cols))
            for r in rows: print(','.join(sql_quote(v) for v in r))
            return
        if self.mode in ('column','table','box','markdown'):
            data=([cols] if self.headers else []) + [[self.fmt(v) for v in r] for r in rows]
            if not data: return
            widths=[max(len(str(row[i])) for row in data) for i in range(len(data[0]))]
            for idx,row in enumerate(data):
                print('  '.join(str(row[i]).ljust(widths[i]) for i in range(len(row))).rstrip())
                if self.headers and idx==0 and self.mode=='column': print('  '.join('-'*w for w in widths).rstrip())
            return
        if self.mode=='line':
            for r in rows:
                for c,v in zip(cols,r): print(f'{c} = {self.fmt(v)}')
                print()
            return
        sep='\t' if self.mode=='tabs' else self.sep
        if self.headers: print(sep.join(cols))
        for r in rows: print(sep.join(self.fmt(v) for v in r))
    def fmt(self,v): return self.null if v is None else str(v)
    def dot(self, st):
        parts=st.split(); cmd=parts[0][1:] if parts else ''
        if cmd in ('quit','exit'): raise SystemExit(int(parts[1]) if len(parts)>1 and parts[1].isdigit() else 0)
        if cmd=='help': print(HELP_DOT,end='')
        elif cmd=='version': print('SQLite '+VERSION+'\nzlib version 1.2.13')
        elif cmd=='mode' and len(parts)>1: self.mode=parts[1].lower()
        elif cmd in ('headers','header') and len(parts)>1: self.headers=parts[1].lower() in ('on','yes','1')
        elif cmd=='nullvalue' and len(parts)>1: self.null=' '.join(parts[1:])
        elif cmd=='separator' and len(parts)>1: self.sep=parts[1]
        elif cmd=='print': print(st.partition(' ')[2])
        elif cmd=='tables': print(' '.join(sorted(self.db['tables'].keys())))
        elif cmd=='schema':
            pat=parts[1].lower() if len(parts)>1 else None
            for n,t in self.db['tables'].items():
                if pat is None or pat==n.lower(): print(t.get('sql',f"CREATE TABLE {n}({','.join(t['cols'])});"))
        elif cmd=='dump':
            print('PRAGMA foreign_keys=OFF;'); print('BEGIN TRANSACTION;')
            for n,t in self.db['tables'].items():
                print(t.get('sql',f"CREATE TABLE {n}({','.join(t['cols'])});"))
                for r in t['rows']:
                    print(f"INSERT INTO {n} VALUES({','.join(sql_quote(v) for v in r)});")
            print('COMMIT;')
    def exec(self, st):
        if not st: return
        if st.startswith('.'): return self.dot(st)
        low=st.lower().strip()
        if low.startswith('create table'):
            m=re.match(r'(?is)^create\s+table\s+(?:if\s+not\s+exists\s+)?([\w_]+)\s*\((.*)\)$',st.strip())
            if not m: return
            name=m.group(1); defs=split_top(m.group(2)); cols=[]
            for d in defs:
                c=d.strip().split()[0].strip('`"[]')
                if c.lower() not in ('primary','foreign','unique','check','constraint'): cols.append(c)
            self.db['tables'][name]={'cols':cols,'rows':[],'sql':f"CREATE TABLE {name}({','.join(defs)});"}; self.save(); return
        if low.startswith('drop table'):
            name=st.split()[-1].strip(';'); self.db['tables'].pop(name,None); self.save(); return
        if low.startswith('insert'):
            m=re.match(r'(?is)^insert\s+into\s+(\w+)(?:\s*\((.*?)\))?\s+values\s*(.*)$',st.strip())
            if not m: return
            name=m.group(1); table=self.db['tables'].setdefault(name,{'cols':[],'rows':[]})
            vals=m.group(3).strip(); groups=[]; cur=''; par=0; q=False
            for c in vals:
                if q:
                    cur+=c
                    if c=="'": q=False
                else:
                    if c=="'": q=True; cur+=c
                    elif c=='(': par+=1; cur+=c if par>1 else ''
                    elif c==')':
                        par-=1
                        if par==0: groups.append(cur); cur=''
                        else: cur+=c
                    elif par>0: cur+=c
            insert_cols=[c.strip().strip('`"[]') for c in split_top(m.group(2))] if m.group(2) else None
            for g in groups:
                vals=[eval_expr(x) for x in split_top(g)]
                if insert_cols and table.get('cols'):
                    row=[None]*len(table['cols'])
                    for c,v in zip(insert_cols,vals):
                        if c in table['cols']:
                            row[table['cols'].index(c)]=v
                    table['rows'].append(row)
                else:
                    row=vals
                    while len(row)<len(table.get('cols',[])): row.append(None)
                    table['rows'].append(row)
            self.save(); return
        if low.startswith('update'):
            m=re.match(r'(?is)^update\s+(\w+)\s+set\s+(.*?)(?:\s+where\s+(.*))?$',st)
            if m and m.group(1) in self.db['tables']:
                t=self.db['tables'][m.group(1)]; assigns=split_top(m.group(2))
                for row in t['rows']:
                    rd={c.lower():row[i] for i,c in enumerate(t['cols'])}
                    if not m.group(3) or self.match_where(m.group(3),rd):
                        for a in assigns:
                            c,e=a.split('=',1); idx=t['cols'].index(c.strip()); row[idx]=eval_expr(e,rd)
                self.save(); return
        if low.startswith('delete'):
            m=re.match(r'(?is)^delete\s+from\s+(\w+)(?:\s+where\s+(.*))?$',st)
            if m and m.group(1) in self.db['tables']:
                t=self.db['tables'][m.group(1)]
                t['rows']=[row for row in t['rows'] if m.group(2) and not self.match_where(m.group(2),{c.lower():row[i] for i,c in enumerate(t['cols'])})]
                self.save(); return
        if low.startswith('select'):
            return self.select(st)
        if low.startswith('pragma table_info'):
            name=re.search(r'\((.*?)\)',st).group(1).strip("'\"")
            t=self.db['tables'].get(name,{'cols':[]}); rows=[[i,c,'',0,None,0] for i,c in enumerate(t['cols'])]
            return self.out_rows(['cid','name','type','notnull','dflt_value','pk'],rows)
    def match_where(self, cond, row):
        cond=cond.strip()
        ors=re.split(r'(?is)\s+or\s+',cond)
        if len(ors)>1:
            return any(self.match_where(x,row) for x in ors)
        ands=re.split(r'(?is)\s+and\s+',cond)
        if len(ands)>1:
            return all(self.match_where(x,row) for x in ands)
        m=re.match(r'(?is)^(.*?)\s+is\s+(not\s+)?null$',cond)
        if m:
            val=eval_expr(m.group(1),row) is None
            return (not val) if m.group(2) else val
        m=re.match(r'(?is)^(.*?)\s+like\s+(.*?)$',cond)
        if m:
            av=str(eval_expr(m.group(1),row)); pat=str(eval_expr(m.group(2),row))
            rx='^'+re.escape(pat).replace('%','.*').replace('_','.')+'$'
            return re.match(rx,av) is not None
        for op in ('>=','<=','!=','<>','=','>','<'):
            if op in cond:
                a,b=cond.split(op,1); av=eval_expr(a,row); bv=eval_expr(b,row)
                return {'=':av==bv,'!=':av!=bv,'<>':av!=bv,'>':av>bv,'<':av<bv,'>=':av>=bv,'<=':av<=bv}[op]
        return bool(eval_expr(cond,row))
    def select(self, st):
        body=st.strip()[6:].strip()
        m=re.match(r'(?is)^(.*?)\s+from\s+(\w+)(.*)$',body)
        if not m:
            exprs=split_top(body); cols=[]; row=[]
            for e in exprs:
                base,alias=strip_alias(e); cols.append(alias); row.append(eval_expr(base))
            return self.out_rows(cols,[row])
        exprpart,name,tail=m.group(1),m.group(2),m.group(3)
        t=self.db['tables'].get(name)
        if not t: return
        rows=[]
        for r in t['rows']:
            rd={c.lower():r[i] if i<len(r) else None for i,c in enumerate(t['cols'])}
            if ' where ' in tail.lower():
                cond=re.split(r'(?is)\s+where\s+',tail,1)[1]
                cond=re.split(r'(?is)\s+order\s+by\s+',cond,1)[0]
                if not self.match_where(cond,rd): continue
            rows.append((r,rd))
        om=re.search(r'(?is)\s+order\s+by\s+([\w_]+)(?:\s+(desc|asc))?',tail)
        if om:
            key=om.group(1).lower(); rev=(om.group(2) or '').lower()=='desc'; rows.sort(key=lambda rr: rr[1].get(key), reverse=rev)
        distinct=False
        if exprpart.strip().lower().startswith('distinct '):
            distinct=True; exprpart=exprpart.strip()[9:].strip()
        exprs=split_top(exprpart)
        aggs=[]
        for e in exprs:
            mm=re.match(r'(?is)^(count|sum|avg|min|max)\((\*|.*?)\)',e.strip())
            aggs.append(mm.groups() if mm else None)
        if any(aggs):
            out=[]; cols=[]
            for e,ag in zip(exprs,aggs):
                cols.append(strip_alias(e)[1])
                if not ag: out.append(None); continue
                fn,arg=ag[0].lower(),ag[1].strip(); vals=[]
                for _,rd in rows:
                    vals.append(1 if arg=='*' else eval_expr(arg,rd))
                nums=[v for v in vals if v is not None]
                if fn=='count': out.append(len(nums) if arg!='*' else len(rows))
                elif fn=='sum': out.append(sum(nums) if nums else None)
                elif fn=='avg': out.append(sum(nums)/len(nums) if nums else None)
                elif fn=='min': out.append(min(nums) if nums else None)
                elif fn=='max': out.append(max(nums) if nums else None)
            return self.out_rows(cols,[out])
        if len(exprs)==1 and exprs[0].strip()=='*': exprs=t['cols']
        cols=[strip_alias(e)[1] for e in exprs]; out=[]
        for _,rd in rows:
            out.append([eval_expr(strip_alias(e)[0],rd) for e in exprs])
        if distinct:
            seen=set(); uniq=[]
            for r in out:
                k=tuple(r)
                if k not in seen:
                    seen.add(k); uniq.append(r)
            out=uniq
        lm=re.search(r'(?is)\s+limit\s+(\d+)',tail)
        if lm: out=out[:int(lm.group(1))]
        return self.out_rows(cols,out)

def parse_args(argv, sh):
    cmds=[]; db=':memory:'; i=1
    while i<len(argv):
        a=argv[i]
        if a in ('-help','--help'): print(HELP,end=''); raise SystemExit(0)
        if a in ('-version','--version'): print(VERSION); raise SystemExit(0)
        if a in ('-csv','-list','-column','-quote','-json','-line','-tabs','-table','-box','-markdown','-html','-ascii'):
            sh.mode=a[1:]; i+=1; continue
        if a in ('-header','--header'): sh.headers=True; i+=1; continue
        if a in ('-noheader','--noheader'): sh.headers=False; i+=1; continue
        if a=='-separator' and i+1<len(argv): sh.sep=argv[i+1]; i+=2; continue
        if a=='-nullvalue' and i+1<len(argv): sh.null=argv[i+1]; i+=2; continue
        if a=='-cmd' and i+1<len(argv): cmds.append(argv[i+1]); i+=2; continue
        if a.startswith('-'): i+=1; continue
        db=a; i+=1
        if i<len(argv): cmds.append(' '.join(argv[i:])); break
    return db,cmds

def main():
    sh=Shell()
    try: db,cmds=parse_args(sys.argv,sh)
    except SystemExit as e: return int(e.code)
    sh.load(db)
    text='\n'.join(cmds) if cmds else sys.stdin.read()
    status=0
    for st in split_statements(text):
        try: sh.exec(st)
        except SystemExit as e: return int(e.code)
        except Exception as e:
            print(f'Error: {e}', file=sys.stderr); status=1
    return status
if __name__=='__main__': sys.exit(main())
