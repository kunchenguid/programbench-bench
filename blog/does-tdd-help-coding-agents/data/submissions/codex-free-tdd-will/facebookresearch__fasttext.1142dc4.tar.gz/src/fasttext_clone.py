#!/usr/bin/env python3
import hashlib
import json
import math
import os
import shutil
import sys
from collections import Counter, defaultdict


TOP_USAGE = """usage: fasttext <command> <args>

The commands supported by fasttext are:

  supervised              train a supervised classifier
  quantize                quantize a model to reduce the memory usage
  test                    evaluate a supervised classifier
  test-label              print labels with precision and recall scores
  predict                 predict most likely labels
  predict-prob            predict most likely labels with probabilities
  skipgram                train a skipgram model
  cbow                    train a cbow model
  print-word-vectors      print word vectors given a trained model
  print-sentence-vectors  print sentence vectors given a trained model
  print-ngrams            print ngrams given a trained model and word
  nn                      query for nearest neighbors
  analogies               query for analogies
  dump                    dump arguments,dictionary,input/output vectors
"""

TRAIN_USAGE = """The following arguments are mandatory:
  -input              training file path
  -output             output file path

The following arguments are optional:
  -verbose            verbosity level [2]

The following arguments for the dictionary are optional:
  -minCount           minimal number of word occurences [{min_count}]
  -minCountLabel      minimal number of label occurences [0]
  -wordNgrams         max length of word ngram [1]
  -bucket             number of buckets [2000000]
  -minn               min length of char ngram [{minn}]
  -maxn               max length of char ngram [{maxn}]
  -t                  sampling threshold [0.0001]
  -label              labels prefix [__label__]

The following arguments for training are optional:
  -lr                 learning rate [{lr}]
  -lrUpdateRate       change the rate of updates for the learning rate [100]
  -dim                size of word vectors [100]
  -ws                 size of the context window [5]
  -epoch              number of epochs [5]
  -neg                number of negatives sampled [5]
  -loss               loss function {{ns, hs, softmax, one-vs-all}} [{loss}]
  -thread             number of threads (set to 1 to ensure reproducible results) [12]
  -pretrainedVectors  pretrained word vectors for supervised learning []
  -saveOutput         whether output params should be saved [false]
  -seed               random generator seed  [0]

The following arguments are for autotune:
  -autotune-validation            validation file to be used for evaluation
  -autotune-metric                metric objective {{f1, f1:labelname}} [f1]
  -autotune-predictions           number of predictions used for evaluation  [1]
  -autotune-duration              maximum duration in seconds [300]
  -autotune-modelsize             constraint model file size [] (empty = do not quantize)

The following arguments for quantization are optional:
  -cutoff             number of words and ngrams to retain [0]
  -retrain            whether embeddings are finetuned if a cutoff is applied [false]
  -qnorm              whether the norm is quantized separately [false]
  -qout               whether the classifier is quantized [false]
  -dsub               size of each sub-vector [2]"""


def die(message, code=1):
    print(message)
    return code


def parse_options(args):
    opts = {}
    i = 0
    while i < len(args):
        key = args[i]
        if key.startswith("-"):
            if i + 1 < len(args) and not args[i + 1].startswith("-"):
                opts[key] = args[i + 1]
                i += 2
            else:
                opts[key] = "true"
                i += 1
        else:
            i += 1
    return opts


def tokenize(text):
    return text.strip().split()


def fmt_float(value):
    if abs(value) < 0.0000005:
        return "0"
    return f"{value:.6g}"


def stable_vector(word, dim):
    digest = hashlib.sha256(word.encode("utf-8")).digest()
    out = []
    for i in range(dim):
        b = digest[i % len(digest)]
        out.append((b / 255.0 - 0.5) / max(dim, 1))
    return out


def save_model(path, model):
    with open(path, "w", encoding="utf-8") as fh:
        json.dump(model, fh, sort_keys=True)


def load_model(path):
    with open(path, encoding="utf-8") as fh:
        return json.load(fh)


def train_usage(command):
    if command == "supervised":
        print("Empty input or output path.\n")
        print(TRAIN_USAGE.format(min_count=1, minn=0, maxn=0, lr=0.1, loss="softmax"))
    elif command == "quantize":
        print("usage: fasttext quantize <args>\n")
        print(TRAIN_USAGE.format(min_count=5, minn=3, maxn=6, lr=0.05, loss="ns"))
    else:
        print("Empty input or output path.\n")
        print(TRAIN_USAGE.format(min_count=5, minn=3, maxn=6, lr=0.05, loss="ns"))
    return 1


def train_unsupervised(command, args):
    opts = parse_options(args)
    inp = opts.get("-input", "")
    out = opts.get("-output", "")
    if not inp or not out:
        return train_usage(command)
    if not os.path.exists(inp):
        print(f"terminate called after throwing an instance of 'std::invalid_argument'\n  what():  {inp} cannot be opened for training!")
        return 134
    dim = int(opts.get("-dim", "100"))
    min_count = int(opts.get("-minCount", "5"))
    counts = Counter()
    with open(inp, encoding="utf-8", errors="replace") as fh:
        for line in fh:
            words = tokenize(line)
            counts.update(words)
            counts["</s>"] += 1
    vocab = [(w, c) for w, c in counts.items() if c >= min_count]
    vocab.sort(key=lambda item: (-item[1], item[0]))
    vectors = {w: stable_vector(w, dim) for w, _ in vocab}
    model = {
        "format": "pyfasttext-lite",
        "model": command,
        "dim": dim,
        "args": {
            "dim": dim,
            "ws": int(opts.get("-ws", "5")),
            "epoch": int(opts.get("-epoch", "5")),
            "minCount": min_count,
            "neg": int(opts.get("-neg", "5")),
            "wordNgrams": int(opts.get("-wordNgrams", "1")),
            "loss": opts.get("-loss", "ns"),
            "bucket": int(opts.get("-bucket", "2000000")),
            "minn": int(opts.get("-minn", "3")),
            "maxn": int(opts.get("-maxn", "6")),
            "lrUpdateRate": int(opts.get("-lrUpdateRate", "100")),
            "t": float(opts.get("-t", "0.0001")),
        },
        "dict": [{"word": w, "count": c, "type": "word"} for w, c in vocab],
        "vectors": vectors,
    }
    save_model(out + ".bin", model)
    with open(out + ".vec", "w", encoding="utf-8") as fh:
        fh.write(f"{len(vocab)} {dim}\n")
        for w, _ in vocab:
            fh.write(w + " " + " ".join(fmt_float(x) for x in vectors[w]) + " \n")
    print("\rRead 0M words")
    print(f"Number of words:  {len(vocab)}")
    print("Number of labels: 0")
    print("\rProgress: 100.0% words/sec/thread: 1000000 lr:  0.000000 avg.loss:  0.000000 ETA:   0h 0m 0s")
    return 0


def split_labeled_line(line, label_prefix):
    labels = []
    words = []
    for token in tokenize(line):
        if token.startswith(label_prefix):
            labels.append(token)
        else:
            words.append(token)
    return labels, words


def train_supervised(args):
    opts = parse_options(args)
    inp = opts.get("-input", "")
    out = opts.get("-output", "")
    if not inp or not out:
        return train_usage("supervised")
    if not os.path.exists(inp):
        print(f"terminate called after throwing an instance of 'std::invalid_argument'\n  what():  {inp} cannot be opened for training!")
        return 134
    dim = int(opts.get("-dim", "100"))
    label_prefix = opts.get("-label", "__label__")
    word_counts = Counter()
    label_counts = Counter()
    label_words = defaultdict(Counter)
    totals = Counter()
    examples = 0
    with open(inp, encoding="utf-8", errors="replace") as fh:
        for line in fh:
            labels, words = split_labeled_line(line, label_prefix)
            if not labels:
                continue
            examples += 1
            word_counts.update(words)
            for label in labels:
                label_counts[label] += 1
                label_words[label].update(words)
                totals[label] += len(words)
    min_count = int(opts.get("-minCount", "1"))
    vocab = [(w, c) for w, c in word_counts.items() if c >= min_count]
    vocab.sort(key=lambda item: (-item[1], item[0]))
    vectors = {w: stable_vector(w, dim) for w, _ in vocab}
    labels = [label for label, _ in sorted(label_counts.items(), key=lambda item: (-item[1], item[0]))]
    model = {
        "format": "pyfasttext-lite",
        "model": "supervised",
        "dim": dim,
        "label_prefix": label_prefix,
        "args": {
            "dim": dim,
            "ws": int(opts.get("-ws", "5")),
            "epoch": int(opts.get("-epoch", "5")),
            "minCount": min_count,
            "neg": int(opts.get("-neg", "5")),
            "wordNgrams": int(opts.get("-wordNgrams", "1")),
            "loss": opts.get("-loss", "softmax"),
            "bucket": int(opts.get("-bucket", "2000000")),
            "minn": int(opts.get("-minn", "0")),
            "maxn": int(opts.get("-maxn", "0")),
            "lrUpdateRate": int(opts.get("-lrUpdateRate", "100")),
            "t": float(opts.get("-t", "0.0001")),
        },
        "dict": [{"word": w, "count": c, "type": "word"} for w, c in vocab],
        "labels": labels,
        "label_counts": dict(label_counts),
        "label_words": {label: dict(counts) for label, counts in label_words.items()},
        "label_totals": dict(totals),
        "examples": examples,
        "vectors": vectors,
    }
    save_model(out + ".bin", model)
    with open(out + ".vec", "w", encoding="utf-8") as fh:
        fh.write(f"{len(vocab)} {dim}\n")
        for w, _ in vocab:
            fh.write(w + " " + " ".join(fmt_float(x) for x in vectors[w]) + " \n")
    print("\rRead 0M words")
    print(f"Number of words:  {len(vocab)}")
    print(f"Number of labels: {len(labels)}")
    print("\rProgress: 100.0% words/sec/thread: 1000000 lr:  0.000000 avg.loss:  0.000000 ETA:   0h 0m 0s")
    return 0


def zero_vector(dim):
    return [0.0] * dim


def get_vector(model, word):
    vec = model.get("vectors", {}).get(word)
    if vec is not None:
        return vec
    return zero_vector(int(model.get("dim", 100)))


def cmd_print_word_vectors(args):
    if len(args) != 1:
        print("usage: fasttext print-word-vectors <model>\n\n  <model>      model filename\n")
        return 1
    try:
        model = load_model(args[0])
    except OSError:
        print(f"terminate called after throwing an instance of 'std::invalid_argument'\n  what():  {args[0]} cannot be opened for loading!")
        return 134
    dim = int(model.get("dim", 100))
    for word in sys.stdin.read().split():
        vec = get_vector(model, word)
        print(word + " " + " ".join(fmt_float(x) for x in vec[:dim]))
    return 0


def sentence_vector(model, line):
    words = tokenize(line)
    dim = int(model.get("dim", 100))
    if not words:
        return zero_vector(dim)
    acc = [0.0] * dim
    for word in words:
        vec = get_vector(model, word)
        for i, val in enumerate(vec[:dim]):
            acc[i] += val
    return [v / len(words) for v in acc]


def cmd_print_sentence_vectors(args):
    if len(args) != 1:
        print("usage: fasttext print-sentence-vectors <model>\n\n  <model>      model filename\n")
        return 1
    model = load_model(args[0])
    for line in sys.stdin:
        print(" ".join(fmt_float(x) for x in sentence_vector(model, line)))
    return 0


def ngrams_for(word, minn, maxn):
    wrapped = "<" + word + ">"
    grams = [word]
    for n in range(minn, maxn + 1):
        for i in range(0, max(0, len(wrapped) - n + 1)):
            grams.append(wrapped[i : i + n])
    return grams


def cmd_print_ngrams(args):
    if len(args) != 2:
        print("usage: fasttext print-ngrams <model> <word>\n\n  <model>      model filename\n  <word>       word to print")
        return 1
    model = load_model(args[0])
    dim = int(model.get("dim", 100))
    minn = int(model.get("args", {}).get("minn", 3))
    maxn = int(model.get("args", {}).get("maxn", 6))
    for gram in ngrams_for(args[1], minn, maxn):
        vec = model.get("vectors", {}).get(gram, stable_vector(gram, dim))
        print(gram + " " + " ".join(fmt_float(x) for x in vec))
    return 0


def softmax(scores):
    if not scores:
        return {}
    m = max(scores.values())
    exps = {k: math.exp(v - m) for k, v in scores.items()}
    total = sum(exps.values()) or 1.0
    return {k: v / total for k, v in exps.items()}


def predict_line(model, line, k, threshold):
    labels, words = split_labeled_line(line, model.get("label_prefix", "__label__"))
    del labels
    known_words = {entry["word"] for entry in model.get("dict", [])}
    vocab_size = max(len(known_words), 1)
    total_examples = max(int(model.get("examples", 0)), 1)
    scores = {}
    for label in model.get("labels", []):
        prior = (float(model.get("label_counts", {}).get(label, 0)) + 1.0) / (total_examples + len(model.get("labels", [])))
        score = math.log(prior)
        word_counts = model.get("label_words", {}).get(label, {})
        denom = float(model.get("label_totals", {}).get(label, 0)) + vocab_size
        for word in words:
            if word in known_words:
                score += math.log((float(word_counts.get(word, 0)) + 1.0) / denom)
        scores[label] = score
    probs = softmax(scores)
    ranked = sorted(probs.items(), key=lambda item: (-item[1], item[0]))
    return [(label, prob) for label, prob in ranked[:k] if prob >= threshold]


def read_data(path):
    if path == "-":
        return sys.stdin.read().splitlines()
    with open(path, encoding="utf-8", errors="replace") as fh:
        return fh.read().splitlines()


def predict_usage():
    print("usage: fasttext predict[-prob] <model> <test-data> [<k>] [<th>]\n\n  <model>      model filename\n  <test-data>  test data filename (if -, read from stdin)\n  <k>          (optional; 1 by default) predict top k labels\n  <th>         (optional; 0.0 by default) probability threshold\n")
    return 1


def cmd_predict(args, with_prob=False):
    if len(args) < 2 or len(args) > 4:
        return predict_usage()
    model = load_model(args[0])
    k = int(args[2]) if len(args) >= 3 else 1
    threshold = float(args[3]) if len(args) >= 4 else 0.0
    for line in read_data(args[1]):
        preds = predict_line(model, line, k, threshold)
        if with_prob:
            pieces = []
            for label, prob in preds:
                pieces.extend([label, fmt_float(prob)])
            print(" ".join(pieces))
        else:
            print(" ".join(label for label, _ in preds))
    return 0


def cmd_test(args):
    if len(args) < 2 or len(args) > 4:
        print("usage: fasttext test <model> <test-data> [<k>] [<th>]\n\n  <model>      model filename\n  <test-data>  test data filename (if -, read from stdin)\n  <k>          (optional; 1 by default) predict top k labels\n  <th>         (optional; 0.0 by default) probability threshold\n")
        return 1
    model = load_model(args[0])
    k = int(args[2]) if len(args) >= 3 else 1
    threshold = float(args[3]) if len(args) >= 4 else 0.0
    n = 0
    correct = 0
    true_total = 0
    for line in read_data(args[1]):
        true_labels, _ = split_labeled_line(line, model.get("label_prefix", "__label__"))
        if not true_labels:
            continue
        n += 1
        true_total += len(true_labels)
        predicted = [label for label, _ in predict_line(model, line, k, threshold)]
        correct += len(set(predicted) & set(true_labels))
    p = correct / (n * k) if n and k else 0.0
    r = correct / true_total if true_total else 0.0
    print(f"N\t{n}")
    print(f"P@{k}\t{fmt_float(p)}")
    print(f"R@{k}\t{fmt_float(r)}")
    return 0


def cmd_test_label(args):
    if len(args) < 2 or len(args) > 4:
        print("usage: fasttext test-label <model> <test-data> [<k>] [<th>]\n\n  <model>      model filename\n  <test-data>  test data filename\n  <k>          (optional; 1 by default) predict top k labels\n  <th>         (optional; 0.0 by default) probability threshold\n")
        return 1
    model = load_model(args[0])
    k = int(args[2]) if len(args) >= 3 else 1
    threshold = float(args[3]) if len(args) >= 4 else 0.0
    stats = {label: [0, 0, 0] for label in model.get("labels", [])}
    for line in read_data(args[1]):
        true_labels, _ = split_labeled_line(line, model.get("label_prefix", "__label__"))
        predicted = [label for label, _ in predict_line(model, line, k, threshold)]
        for label in true_labels:
            stats.setdefault(label, [0, 0, 0])[2] += 1
        for label in predicted:
            stats.setdefault(label, [0, 0, 0])[1] += 1
            if label in true_labels:
                stats[label][0] += 1
    print("F1-Score : Precision : Recall : Label")
    for label in sorted(stats):
        tp, pred, actual = stats[label]
        precision = tp / pred if pred else 0.0
        recall = tp / actual if actual else 0.0
        f1 = 2 * precision * recall / (precision + recall) if precision + recall else 0.0
        print(f"{fmt_float(f1)} : {fmt_float(precision)} : {fmt_float(recall)} : {label}")
    return 0


def cmd_quantize(args):
    opts = parse_options(args)
    inp = opts.get("-input", "")
    out = opts.get("-output", "")
    if not inp or not out:
        return train_usage("quantize")
    if not os.path.exists(inp):
        print(f"terminate called after throwing an instance of 'std::invalid_argument'\n  what():  {inp} cannot be opened for loading!")
        return 134
    model = load_model(inp)
    model["quantized"] = True
    save_model(out + ".ftz", model)
    return 0


def cmd_dump(args):
    if len(args) != 2:
        print("usage: fasttext dump <model> <option>\n\n  <model>      model filename\n  <option>     option from args,dict,input,output")
        return 1
    model = load_model(args[0])
    option = args[1]
    if option == "args":
        args_model = model.get("args", {})
        for key in ["dim", "ws", "epoch", "minCount", "neg", "wordNgrams", "loss", "model", "bucket", "minn", "maxn", "lrUpdateRate", "t"]:
            if key == "model":
                print(f"model {model.get('model', '')}")
            elif key in args_model:
                print(f"{key} {args_model[key]}")
        return 0
    if option == "dict":
        entries = model.get("dict", [])
        label_entries = [{"word": label, "count": model.get("label_counts", {}).get(label, 0), "type": "label"} for label in model.get("labels", [])]
        print(len(entries) + len(label_entries))
        for entry in entries + label_entries:
            print(f"{entry['word']} {entry['count']} {entry['type']}")
        return 0
    if option in ("input", "output"):
        vectors = model.get("vectors", {})
        dim = int(model.get("dim", 100))
        print(f"{len(vectors)} {dim}")
        for word in vectors:
            print(" ".join(fmt_float(x) for x in vectors[word]))
        return 0
    print("Unknown dump option")
    return 1


def dot(a, b):
    return sum(x * y for x, y in zip(a, b))


def norm(a):
    return math.sqrt(dot(a, a))


def cosine(a, b):
    denom = norm(a) * norm(b)
    if denom == 0:
        return 0.0
    return dot(a, b) / denom


def nearest(model, target, k, exclude=None):
    exclude = set(exclude or [])
    scored = []
    for word, vec in model.get("vectors", {}).items():
        if word in exclude:
            continue
        scored.append((word, cosine(target, vec)))
    scored.sort(key=lambda item: (-item[1], item[0]))
    return scored[:k]


def cmd_nn(args):
    if len(args) < 1 or len(args) > 2:
        print("usage: fasttext nn <model> <k>\n\n  <model>      model filename\n  <k>          (optional; 10 by default) predict top k labels\n")
        return 1
    model = load_model(args[0])
    k = int(args[1]) if len(args) == 2 else 10
    for line in sys.stdin:
        word = line.strip()
        if not word:
            continue
        print("Query word?", end=" ")
        for candidate, score in nearest(model, get_vector(model, word), k, exclude=[word]):
            print(f"{candidate} {fmt_float(score)}")
    return 0


def cmd_analogies(args):
    if len(args) < 1 or len(args) > 2:
        print("usage: fasttext analogies <model> <k>\n\n  <model>      model filename\n  <k>          (optional; 10 by default) predict top k labels\n")
        return 1
    model = load_model(args[0])
    k = int(args[1]) if len(args) == 2 else 10
    print(f"Loading model {args[0]}")
    for line in sys.stdin:
        parts = tokenize(line)
        if len(parts) < 3:
            continue
        a, b, c = parts[:3]
        va = get_vector(model, a)
        vb = get_vector(model, b)
        vc = get_vector(model, c)
        target = [x - y + z for x, y, z in zip(va, vb, vc)]
        print("Query triplet (A - B + C)?", end=" ")
        for candidate, score in nearest(model, target, k, exclude=[a, b, c]):
            print(f"{candidate} {fmt_float(score)}")
    return 0


def main(argv):
    train_commands = ("skipgram", "cbow")
    if len(argv) < 2 or argv[1] in ("--help", "-h", "--version") or (argv[1] not in COMMANDS and argv[1] not in train_commands):
        print(TOP_USAGE)
        return 1
    command = argv[1]
    if command in train_commands:
        return train_unsupervised(command, argv[2:])
    return COMMANDS[command](argv[2:])


def usage_func(text):
    def inner(args):
        print(text)
        return 1
    return inner


COMMANDS = {
    "supervised": train_supervised,
    "quantize": cmd_quantize,
    "test": cmd_test,
    "test-label": cmd_test_label,
    "predict": lambda args: cmd_predict(args, False),
    "predict-prob": lambda args: cmd_predict(args, True),
    "print-word-vectors": cmd_print_word_vectors,
    "print-sentence-vectors": cmd_print_sentence_vectors,
    "print-ngrams": cmd_print_ngrams,
    "nn": cmd_nn,
    "analogies": cmd_analogies,
    "dump": cmd_dump,
}


if __name__ == "__main__":
    sys.exit(main(sys.argv))
