#!/bin/bash
set -e
cp src/fasttext_clone.py executable
chmod +x executable
