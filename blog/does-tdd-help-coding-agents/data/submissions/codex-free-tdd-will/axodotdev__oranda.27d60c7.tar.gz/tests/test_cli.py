import subprocess
import tempfile
import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]


def build():
    subprocess.run(["bash", "compile.sh"], cwd=ROOT, check=True)


def run_cli(*args, cwd=None):
    build()
    return subprocess.run(
        [str(ROOT / "executable"), *args],
        cwd=cwd or ROOT,
        text=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
    )


class CliTests(unittest.TestCase):
    def test_version_and_top_level_help(self):
        version = run_cli("--version")
        self.assertEqual(version.returncode, 0)
        self.assertEqual(version.stdout, "oranda 0.6.5\n")
        self.assertEqual(version.stderr, "")

        help_result = run_cli("--help")
        self.assertEqual(help_result.returncode, 0)
        self.assertIn("🎁 generate beautiful landing pages for your projects", help_result.stdout)
        self.assertIn("Usage: executable [OPTIONS] <COMMAND>", help_result.stdout)
        self.assertIn("  build     Build an oranda site", help_result.stdout)
        self.assertIn("      --output-format <OUTPUT_FORMAT>", help_result.stdout)
        self.assertEqual(help_result.stderr, "")

    def test_subcommand_help_and_invalid_command(self):
        build_help = run_cli("build", "--help")
        self.assertEqual(build_help.returncode, 0)
        self.assertIn("Build an oranda site", build_help.stdout)
        self.assertIn("Usage: executable build [OPTIONS]", build_help.stdout)
        self.assertIn("      --json-only", build_help.stdout)

        gen_help = run_cli("generate", "ci", "--help")
        self.assertEqual(gen_help.returncode, 0)
        self.assertIn("Generates a CI file that can be used to deploy your site", gen_help.stdout)
        self.assertIn("Usage: executable generate ci [OPTIONS]", gen_help.stdout)
        self.assertIn("Possible values:\n          - github", gen_help.stdout)

        invalid = run_cli("nosuch")
        self.assertEqual(invalid.returncode, 2)
        self.assertIn("error: unrecognized subcommand 'nosuch'", invalid.stderr)
        self.assertIn("Usage: executable [OPTIONS] <COMMAND>", invalid.stderr)

    def test_build_generates_site_from_readme(self):
        with tempfile.TemporaryDirectory() as td:
            site = Path(td)
            (site / "README.md").write_text("# My Project\n\nA demo project.\n\n## Install\n\nRun it.\n")
            result = run_cli("build", cwd=site)

            self.assertEqual(result.returncode, 0, result.stderr)
            self.assertIn("INFO", result.stdout)
            html = (site / "public" / "index.html").read_text()
            self.assertIn("<title>My Project</title>", html)
            self.assertIn("<h1>My Project</h1>", html)
            self.assertIn("<p>A demo project.</p>", html)
            self.assertIn("<h2>Install</h2>", html)
            self.assertTrue((site / "public" / "oranda.css").exists())
            self.assertTrue((site / "public" / "favicon.ico").exists())

    def test_build_uses_config_and_json_only(self):
        with tempfile.TemporaryDirectory() as td:
            site = Path(td)
            (site / "oranda.json").write_text('{"project":{"name":"CfgName","description":"Cfg Desc"}}')
            result = run_cli("--output-format", "json", "build", "--json-only", cwd=site)

            self.assertEqual(result.returncode, 0, result.stderr)
            self.assertIn('"severity": "info"', result.stdout)
            self.assertTrue((site / "public" / "artifacts.json").exists())
            self.assertFalse((site / "public" / "index.html").exists())

    def test_generate_ci_writes_github_workflow(self):
        with tempfile.TemporaryDirectory() as td:
            site = Path(td)
            result = run_cli("generate", "ci", "--output-path", "deploy.yml", "--site-path", "docs", cwd=site)

            self.assertEqual(result.returncode, 0, result.stderr)
            workflow = (site / "deploy.yml").read_text()
            self.assertIn("Deploy oranda site to Pages", workflow)
            self.assertIn("oranda build", workflow)
            self.assertIn("path: docs/public", workflow)


if __name__ == "__main__":
    unittest.main()
