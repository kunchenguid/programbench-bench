#!/usr/bin/env python3
import html
import http.server
import json
import os
from pathlib import Path
import socketserver
import sys


TOP_HELP = """🎁 generate beautiful landing pages for your projects

Usage: executable [OPTIONS] <COMMAND>

Commands:
  build     Build an oranda site
  dev       Start a local development server that recompiles your oranda site if a file changes
  serve     Start a file server to access your oranda site in a browser
  generate  Generate infrastructure files for oranda sites
  help      Print this message or the help of the given subcommand(s)

Options:
  -h, --help
          Print help (see a summary with '-h')

  -V, --version
          Print version

GLOBAL OPTIONS:
  -v, --verbose
          Whether to output more detailed debug information

      --output-format <OUTPUT_FORMAT>
          The format of the output
          
          [default: human]

          Possible values:
          - human: Human-readable output
          - json:  Machine-readable JSON output
"""

BUILD_HELP = """Build an oranda site

Usage: executable build [OPTIONS]

Options:
      --json-only
          Only build the artifacts JSON file (if applicable) and other files that may be used to
          support it, such as installer source files

  -h, --help
          Print help (see a summary with '-h')

GLOBAL OPTIONS:
  -v, --verbose
          Whether to output more detailed debug information

      --output-format <OUTPUT_FORMAT>
          The format of the output
          
          [default: human]

          Possible values:
          - human: Human-readable output
          - json:  Machine-readable JSON output
"""

SERVE_HELP = """Start a file server to access your oranda site in a browser

Usage: executable serve [OPTIONS]

Options:
      --port <PORT>
          [default: 7979]

  -h, --help
          Print help (see a summary with '-h')

GLOBAL OPTIONS:
  -v, --verbose
          Whether to output more detailed debug information

      --output-format <OUTPUT_FORMAT>
          The format of the output
          
          [default: human]

          Possible values:
          - human: Human-readable output
          - json:  Machine-readable JSON output
"""

DEV_HELP = """Start a local development server that recompiles your oranda site if a file changes

Usage: executable dev [OPTIONS]

Options:
      --port <PORT>
          The port for the file server to be launched on

      --no-first-build
          Skip the first build before starting to watch for changes

  -i, --include-paths <INCLUDE_PATHS>
          List of extra paths to watch

  -h, --help
          Print help (see a summary with '-h')

GLOBAL OPTIONS:
  -v, --verbose
          Whether to output more detailed debug information

      --output-format <OUTPUT_FORMAT>
          The format of the output
          
          [default: human]

          Possible values:
          - human: Human-readable output
          - json:  Machine-readable JSON output
"""

GENERATE_HELP = """Generate infrastructure files for oranda sites

Usage: executable generate [OPTIONS] <COMMAND>

Commands:
  ci    Generates a CI file that can be used to deploy your site
  help  Print this message or the help of the given subcommand(s)

Options:
  -o, --output-path <OUTPUT_PATH>
          Path to the output file

  -s, --site-path <SITE_PATH>
          Path to your oranda site

  -h, --help
          Print help (see a summary with '-h')

GLOBAL OPTIONS:
  -v, --verbose
          Whether to output more detailed debug information

      --output-format <OUTPUT_FORMAT>
          The format of the output
          
          [default: human]

          Possible values:
          - human: Human-readable output
          - json:  Machine-readable JSON output
"""

GENERATE_CI_HELP = """Generates a CI file that can be used to deploy your site

Usage: executable generate ci [OPTIONS]

Options:
      --ci <CI>
          What CI to generate a file for
          
          [default: github]

          Possible values:
          - github: Deploy to GitHub Pages using GitHub Actions

  -o, --output-path <OUTPUT_PATH>
          Path to the output file

  -s, --site-path <SITE_PATH>
          Path to your oranda site

  -h, --help
          Print help (see a summary with '-h')

GLOBAL OPTIONS:
  -v, --verbose
          Whether to output more detailed debug information

      --output-format <OUTPUT_FORMAT>
          The format of the output
          
          [default: human]

          Possible values:
          - human: Human-readable output
          - json:  Machine-readable JSON output
"""


def print_error(message, usage):
    sys.stderr.write(f"error: {message}\n\n{usage}\n\nFor more information, try '--help'.\n")
    return 2


def read_project():
    cwd = Path.cwd()
    data = {}
    cfg = cwd / "oranda.json"
    if cfg.exists():
        try:
            raw = json.loads(cfg.read_text())
            project = raw.get("project", raw) if isinstance(raw, dict) else {}
            if isinstance(project, dict):
                data.update(project)
        except Exception:
            pass
    pkg = cwd / "package.json"
    if pkg.exists():
        try:
            raw = json.loads(pkg.read_text())
            for key in ("name", "description", "version", "homepage"):
                if key in raw and key not in data:
                    data[key] = raw[key]
        except Exception:
            pass
    cargo = cwd / "Cargo.toml"
    if cargo.exists():
        in_package = False
        for line in cargo.read_text().splitlines():
            stripped = line.strip()
            if stripped == "[package]":
                in_package = True
                continue
            if stripped.startswith("[") and stripped != "[package]":
                in_package = False
            if in_package and "=" in stripped:
                k, v = stripped.split("=", 1)
                key = k.strip()
                if key in ("name", "description", "version", "homepage") and key not in data:
                    data[key] = v.strip().strip('"')
    readme = cwd / "README.md"
    body_md = readme.read_text() if readme.exists() else ""
    first_heading = None
    first_para = None
    for block in body_md.split("\n\n"):
        text = block.strip()
        if not text:
            continue
        if text.startswith("# ") and first_heading is None:
            first_heading = text[2:].strip()
        elif not text.startswith("#") and first_para is None:
            first_para = " ".join(text.split())
    name = str(data.get("name") or first_heading or cwd.name)
    description = str(data.get("description") or first_para or "Generated by oranda.")
    return {"name": name, "description": description, "readme": body_md}


def render_inline(text):
    escaped = html.escape(text)
    while "**" in escaped:
        start = escaped.find("**")
        end = escaped.find("**", start + 2)
        if end == -1:
            break
        escaped = escaped[:start] + "<strong>" + escaped[start + 2:end] + "</strong>" + escaped[end + 2:]
    return escaped


def render_markdown(markdown):
    parts = []
    in_list = False
    in_code = False
    code_lines = []
    for raw in markdown.splitlines():
        line = raw.rstrip()
        if line.startswith("```"):
            if in_code:
                parts.append("<pre><code>" + html.escape("\n".join(code_lines)) + "</code></pre>")
                code_lines = []
                in_code = False
            else:
                if in_list:
                    parts.append("</ul>")
                    in_list = False
                in_code = True
            continue
        if in_code:
            code_lines.append(line)
            continue
        if not line.strip():
            if in_list:
                parts.append("</ul>")
                in_list = False
            continue
        if line.startswith("# "):
            if in_list:
                parts.append("</ul>")
                in_list = False
            parts.append(f"<h1>{render_inline(line[2:].strip())}</h1>")
        elif line.startswith("## "):
            if in_list:
                parts.append("</ul>")
                in_list = False
            parts.append(f"<h2>{render_inline(line[3:].strip())}</h2>")
        elif line.startswith("### "):
            if in_list:
                parts.append("</ul>")
                in_list = False
            parts.append(f"<h3>{render_inline(line[4:].strip())}</h3>")
        elif line.startswith("- ") or line.startswith("* "):
            if not in_list:
                parts.append("<ul>")
                in_list = True
            parts.append(f"<li>{render_inline(line[2:].strip())}</li>")
        else:
            if in_list:
                parts.append("</ul>")
                in_list = False
            parts.append(f"<p>{render_inline(line.strip())}</p>")
    if in_code:
        parts.append("<pre><code>" + html.escape("\n".join(code_lines)) + "</code></pre>")
    if in_list:
        parts.append("</ul>")
    return "\n".join(parts)


def build_site(json_only=False, output_format="human"):
    project = read_project()
    out = Path("public")
    out.mkdir(exist_ok=True)
    if json_only:
        (out / "artifacts.json").write_text(json.dumps({"artifacts": []}, indent=2) + "\n")
    else:
        content = render_markdown(project["readme"])
        if not content:
            content = f"<h1>{html.escape(project['name'])}</h1>\n<p>{html.escape(project['description'])}</p>"
        page = f"""<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>{html.escape(project['name'])}</title>
  <meta name="description" content="{html.escape(project['description'], quote=True)}">
  <link rel="stylesheet" href="oranda.css">
  <link rel="icon" href="favicon.ico">
</head>
<body>
  <main class="oranda-main">
{content}
  </main>
</body>
</html>
"""
        (out / "index.html").write_text(page)
        (out / "oranda.css").write_text(DEFAULT_CSS)
    (out / "favicon.ico").write_bytes(b"\x00\x00\x01\x00")
    if output_format == "json":
        print(json.dumps({"diagnostic": {"message": "site built", "severity": "info"}}))
    else:
        print("↪ >o_o< INFO: Your site was built successfully.")
    return 0


DEFAULT_CSS = """html{font-family:system-ui,-apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif;background:#f7f7f4;color:#202124}body{margin:0}.oranda-main{max-width:880px;margin:0 auto;padding:48px 24px}h1{font-size:2.5rem;margin:0 0 1rem}h2{margin-top:2rem;border-bottom:1px solid #ddd;padding-bottom:.35rem}p,li{line-height:1.65}pre{padding:1rem;overflow:auto;background:#1f2328;color:#fff;border-radius:6px}code{font-family:ui-monospace,SFMono-Regular,Menlo,monospace}a{color:#0969da}"""


def option_value(args, names, default=None):
    i = 0
    while i < len(args):
        arg = args[i]
        for name in names:
            if arg == name and i + 1 < len(args):
                return args[i + 1]
            if arg.startswith(name + "="):
                return arg.split("=", 1)[1]
        i += 1
    return default


def generate_ci(args, output_format="human"):
    ci = option_value(args, ["--ci"], "github")
    if ci != "github":
        return print_error(f"invalid value '{ci}' for '--ci <CI>'\n  [possible values: github]", "")
    output_path = option_value(args, ["-o", "--output-path"], ".github/workflows/oranda.yml")
    site_path = option_value(args, ["-s", "--site-path"], ".")
    upload_path = "public" if site_path in ("", ".") else f"{site_path.rstrip('/')}/public"
    workflow = f"""name: Deploy oranda site to Pages

on:
  push:
    branches: ["main"]
  workflow_dispatch:

permissions:
  contents: read
  pages: write
  id-token: write

concurrency:
  group: "pages"
  cancel-in-progress: false

jobs:
  deploy:
    environment:
      name: github-pages
      url: ${{{{ steps.deployment.outputs.page_url }}}}
    runs-on: ubuntu-latest
    steps:
      - name: Checkout
        uses: actions/checkout@v4
      - name: Install oranda
        run: cargo install oranda --locked
      - name: Build
        run: oranda build
        working-directory: {site_path}
      - name: Setup Pages
        uses: actions/configure-pages@v4
      - name: Upload artifact
        uses: actions/upload-pages-artifact@v3
        with:
          path: {upload_path}
      - name: Deploy to GitHub Pages
        id: deployment
        uses: actions/deploy-pages@v4
"""
    path = Path(output_path)
    if path.parent != Path("."):
        path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(workflow)
    if output_format == "json":
        print(json.dumps({"diagnostic": {"message": f"generated {output_path}", "severity": "info"}}))
    else:
        print("↪ >o_o< INFO: Generating a CI deploy workflow for your site...")
    return 0


class QuietHandler(http.server.SimpleHTTPRequestHandler):
    def log_message(self, fmt, *args):
        return


def parse_port(args, default):
    value = option_value(args, ["--port"], None)
    if value is None:
        return default
    try:
        return int(value)
    except ValueError:
        return None


def serve_site(args, output_format="human"):
    port = parse_port(args, 7979)
    if port is None:
        return print_error("invalid value for '--port <PORT>'", "Usage: executable serve [OPTIONS]")
    directory = Path("public")
    directory.mkdir(exist_ok=True)
    os.chdir(directory)
    if output_format == "json":
        print(json.dumps({"diagnostic": {"message": f"serving at http://127.0.0.1:{port}", "severity": "info"}}), flush=True)
    else:
        print(f"↪ >o_o< INFO: Serving at http://127.0.0.1:{port}", flush=True)
    with socketserver.TCPServer(("", port), QuietHandler) as httpd:
        httpd.serve_forever()


def dev_site(args, output_format="human"):
    if "--no-first-build" not in args:
        build_site(False, output_format)
    return serve_site(args, output_format)


def normalize_global_options(argv):
    out = []
    output_format = "human"
    verbose = False
    i = 0
    while i < len(argv):
        arg = argv[i]
        if arg == "--output-format":
            if i + 1 >= len(argv):
                return None, output_format, verbose, print_error("a value is required for '--output-format <OUTPUT_FORMAT>'", "Usage: executable [OPTIONS] <COMMAND>")
            output_format = argv[i + 1]
            if output_format not in ("human", "json"):
                return None, output_format, verbose, print_error(f"invalid value '{output_format}' for '--output-format <OUTPUT_FORMAT>'\n  [possible values: human, json]", "")
            i += 2
        elif arg.startswith("--output-format="):
            output_format = arg.split("=", 1)[1]
            if output_format not in ("human", "json"):
                return None, output_format, verbose, print_error(f"invalid value '{output_format}' for '--output-format <OUTPUT_FORMAT>'\n  [possible values: human, json]", "")
            i += 1
        elif arg in ("-v", "--verbose"):
            verbose = True
            i += 1
        else:
            out.append(arg)
            i += 1
    return out, output_format, verbose, None


def main(argv):
    argv, output_format, _verbose, early = normalize_global_options(argv)
    if early is not None:
        return early
    if argv in (["--version"], ["-V"]):
        print("oranda 0.6.5")
        return 0
    if not argv or argv in (["--help"], ["-h"], ["help"]):
        print(TOP_HELP, end="")
        return 0
    cmd = argv[0]
    rest = argv[1:]
    if cmd == "build":
        if rest in (["--help"], ["-h"]):
            print(BUILD_HELP, end="")
            return 0
        if any(x.startswith("-") and x != "--json-only" for x in rest):
            bad = next(x for x in rest if x.startswith("-") and x != "--json-only")
            return print_error(f"unexpected argument '{bad}' found", "Usage: executable build [OPTIONS]")
        return build_site("--json-only" in rest, output_format)
    if cmd == "serve":
        if rest in (["--help"], ["-h"]):
            print(SERVE_HELP, end="")
            return 0
        return serve_site(rest, output_format)
    if cmd == "dev":
        if rest in (["--help"], ["-h"]):
            print(DEV_HELP, end="")
            return 0
        return dev_site(rest, output_format)
    if cmd == "generate":
        if rest in ([], ["--help"], ["-h"], ["help"]):
            print(GENERATE_HELP, end="")
            return 0
        if rest[0] == "ci":
            if rest[1:] in (["--help"], ["-h"]):
                print(GENERATE_CI_HELP, end="")
                return 0
            return generate_ci(rest[1:], output_format)
        return print_error(f"unrecognized subcommand '{rest[0]}'", "Usage: executable generate [OPTIONS] <COMMAND>")
    return print_error(f"unrecognized subcommand '{cmd}'", "Usage: executable [OPTIONS] <COMMAND>")


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
