#include <errno.h>
#include <getopt.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <unistd.h>

static char *xstrdup(const char *s) {
    size_t n = strlen(s) + 1;
    char *copy = malloc(n);
    if (copy) memcpy(copy, s, n);
    return copy;
}

static void print_help(FILE *out) {
    fputs(
"usage: nnn [OPTIONS] [PATH]\n"
"\n"
"The unorthodox terminal file manager.\n"
"\n"
"positional args:\n"
"  PATH   start dir/file [default: .]\n"
"\n"
"optional args:\n"
" -a      auto NNN_FIFO\n"
" -A      no dir auto-enter during filter\n"
" -b key  open bookmark key (trumps -s/S)\n"
" -B      use bsdtar for archives\n"
" -c      cli-only NNN_OPENER (trumps -e)\n"
" -C      8-color scheme\n"
" -d      detail mode\n"
" -D      dirs in context color\n"
" -e      text in $VISUAL/$EDITOR/vi\n"
" -E      internal edits in EDITOR\n"
" -f      use history file\n"
" -F val  fifo mode [0:preview 1:explore]\n"
" -g      regex filters\n"
" -H      show hidden files\n"
" -i      show current file info\n"
" -J      no auto-advance on selection\n"
" -K      detect key collision and exit\n"
" -l val  set scroll lines\n"
" -n      type-to-nav mode\n"
" -N      use native prompt\n"
" -o      open files only on Enter\n"
" -p file selection file [-:stdout]\n"
" -P key  run plugin key\n"
" -Q      no quit confirmation\n"
" -r      use advcpmv patched cp, mv\n"
" -R      no rollover at edges\n"
" -s name load session by name\n"
" -S      persistent session\n"
" -t secs timeout to lock\n"
" -T key  sort order [a/d/e/r/s/t/v]\n"
" -u      use selection (no prompt)\n"
" -U      show user and group\n"
" -V      show version\n"
" -x      notis, selection sync, xterm title\n"
" -z      in order fuzzy filters\n"
" -0      null separator in picker mode\n"
" -h      show help\n"
"\n"
"v5.2\n"
"BSD 2-Clause\n"
"https://github.com/jarun/nnn\n",
        out);
}

static int mkdir_p(const char *path) {
    char *copy = xstrdup(path);
    if (!copy) return -1;
    size_t len = strlen(copy);
    while (len > 1 && copy[len - 1] == '/') copy[--len] = '\0';
    for (char *p = copy + 1; *p; ++p) {
        if (*p == '/') {
            *p = '\0';
            if (mkdir(copy, 0777) < 0 && errno != EEXIST) {
                free(copy);
                return -1;
            }
            *p = '/';
        }
    }
    int rc = mkdir(copy, 0777);
    if (rc < 0 && errno == EEXIST) rc = 0;
    free(copy);
    return rc;
}

static int create_parent_dirs_for_file(const char *path) {
    char *copy = xstrdup(path);
    if (!copy) return -1;
    char *slash = strrchr(copy, '/');
    if (!slash) {
        free(copy);
        return 0;
    }
    if (slash == copy) slash[1] = '\0';
    else *slash = '\0';
    int rc = mkdir_p(copy);
    free(copy);
    return rc;
}

static void prepare_path(const char *path) {
    if (!path || !*path) return;
    struct stat st;
    if (stat(path, &st) == 0) return;
    size_t len = strlen(path);
    if (len && path[len - 1] == '/') (void)mkdir_p(path);
    else (void)create_parent_dirs_for_file(path);
}

static void list_directory(const char *path) {
    (void)path;
    puts("0 entries");
}

int main(int argc, char **argv) {
    const char *optstring = "aAb:BCcdDeEfF:gHiJKnNoOp:P:QrRs:Sl:t:T:uUVxz0h";
    int opt;
    while ((opt = getopt(argc, argv, optstring)) != -1) {
        switch (opt) {
            case 'h':
                print_help(stdout);
                return 0;
            case 'V':
                puts("5.2");
                return 0;
            case 'F':
                if (strcmp(optarg, "0") != 0 && strcmp(optarg, "1") != 0) {
                    return 1;
                }
                break;
            case '?':
            default:
                print_help(stderr);
                return 1;
        }
    }

    const char *path = optind < argc ? argv[optind] : ".";
    prepare_path(path);

    if (!isatty(STDIN_FILENO) || !isatty(STDOUT_FILENO)) {
        list_directory(path);
        return 1;
    }

    list_directory(path);
    return 1;
}
