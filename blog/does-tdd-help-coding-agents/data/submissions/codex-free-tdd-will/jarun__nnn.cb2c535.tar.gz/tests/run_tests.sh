#!/bin/bash
set -euo pipefail

ROOT=$(cd "$(dirname "$0")/.." && pwd)
BIN="$ROOT/executable"
pass=0
fail=0
status=0

check() {
  local name="$1"
  shift
  if "$@"; then
    echo "ok - $name"
    pass=$((pass + 1))
  else
    echo "not ok - $name"
    fail=$((fail + 1))
  fi
}

run_capture() {
  local outfile="$1"
  local errfile="$2"
  shift 2
  set +e
  "$@" >"$outfile" 2>"$errfile"
  status=$?
  set -e
}

check "version prints 5.2" bash -c 'out=$("'"$BIN"'" -V); [ "$out" = "5.2" ]'
check "help includes usage and homepage" bash -c 'out=$("'"$BIN"'" -h); [[ "$out" == usage:* ]] && [[ "$out" == *"https://github.com/jarun/nnn"* ]]'

run_capture /tmp/nnn_out /tmp/nnn_err "$BIN" --help
check "long help is invalid short option" bash -c '[ "'"$status"'" = 1 ] && grep -q "invalid option -- '\''-'\''" /tmp/nnn_err && grep -q "usage: nnn" /tmp/nnn_err'

run_capture /tmp/nnn_out /tmp/nnn_err "$BIN" -l
check "missing option argument is reported" bash -c '[ "'"$status"'" = 1 ] && grep -q "option requires an argument -- '\''l'\''" /tmp/nnn_err && grep -q "usage: nnn" /tmp/nnn_err'

run_capture /tmp/nnn_out /tmp/nnn_err "$BIN" -F 2
check "invalid fifo mode exits silently" bash -c '[ "'"$status"'" = 1 ] && [ ! -s /tmp/nnn_out ] && [ ! -s /tmp/nnn_err ]'

run_capture /tmp/nnn_out /tmp/nnn_err "$BIN" . </dev/null
check "noninteractive browser reports zero entries" bash -c '[ "'"$status"'" = 1 ] && grep -q "^0 entries$" /tmp/nnn_out && [ ! -s /tmp/nnn_err ]'

rm -rf /tmp/nnn_created
run_capture /tmp/nnn_out /tmp/nnn_err "$BIN" /tmp/nnn_created/a/b/ </dev/null
check "trailing slash path creates directory tree" bash -c '[ "'"$status"'" = 1 ] && [ -d /tmp/nnn_created/a/b ]'

rm -rf /tmp/nnn_created
run_capture /tmp/nnn_out /tmp/nnn_err "$BIN" /tmp/nnn_created/a/file.txt </dev/null
check "file path creates parent tree only" bash -c '[ "'"$status"'" = 1 ] && [ -d /tmp/nnn_created/a ] && [ ! -e /tmp/nnn_created/a/file.txt ]'

echo "$pass passed, $fail failed"
[ "$fail" = 0 ]
