#!/bin/bash
set -euo pipefail
cp pdu.py executable
chmod +x executable
