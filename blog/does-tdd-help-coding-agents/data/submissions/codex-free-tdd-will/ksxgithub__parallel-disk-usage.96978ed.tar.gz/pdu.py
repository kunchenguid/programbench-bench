#!/usr/bin/env python3
import json
import os
import sys
from dataclasses import dataclass, field


VERSION = "0.21.1"
SCHEMA_VERSION = "2024-11-02"


@dataclass
class Options:
    json_output: bool = False
    json_input: bool = False
    quantity: str = "block-size"
    bytes_format: str = "metric"
    max_depth: int | None = 10
    min_ratio: float = 0.01
    no_sort: bool = False
    silent_errors: bool = False
    dedupe: bool = False
    top_down: bool = False
    align_right: bool = False
    total_width: int | None = None
    column_width: tuple[int, int] | None = None
    omit_shared_details: bool = False
    omit_shared_summary: bool = False
    files: list[str] = field(default_factory=list)
    shared: dict | None = None


@dataclass
class Node:
    name: str
    path: str
    size: int = 0
    children: list["Node"] = field(default_factory=list)

    def to_json(self) -> dict:
        return {
            "name": self.name,
            "size": self.size,
            "children": [child.to_json() for child in self.children],
        }


@dataclass
class LinkRecord:
    ino: int
    size: int
    links: int
    paths: list[str] = field(default_factory=list)


@dataclass
class ScanContext:
    links: dict[tuple[int, int], LinkRecord] = field(default_factory=dict)


def parse_args(argv: list[str]) -> Options:
    opts = Options()
    i = 0
    seen = set()
    while i < len(argv):
        arg = argv[i]
        if arg == "--":
            opts.files.extend(argv[i + 1 :])
            break
        if not arg.startswith("-") or arg == "-":
            opts.files.append(arg)
            i += 1
            continue
        if arg in ("-h", "--help"):
            print_help(long=arg == "--help")
            raise SystemExit(0)
        if arg in ("-V", "--version"):
            print(f"pdu {VERSION}")
            raise SystemExit(0)
        if arg in ("--json-input", "--json-output", "-H", "--deduplicate-hardlinks", "--detect-links", "--dedupe-links", "--top-down", "--align-right", "--no-sort", "-s", "--silent-errors", "--no-errors", "-p", "--progress", "--omit-json-shared-details", "--omit-json-shared-summary"):
            if arg == "--json-input":
                opts.json_input = True
            elif arg == "--json-output":
                opts.json_output = True
            elif arg in ("-H", "--deduplicate-hardlinks", "--detect-links", "--dedupe-links"):
                opts.dedupe = True
            elif arg == "--top-down":
                opts.top_down = True
            elif arg == "--align-right":
                opts.align_right = True
            elif arg == "--no-sort":
                opts.no_sort = True
            elif arg in ("-s", "--silent-errors", "--no-errors"):
                opts.silent_errors = True
            elif arg == "--omit-json-shared-details":
                opts.omit_shared_details = True
            elif arg == "--omit-json-shared-summary":
                opts.omit_shared_summary = True
            i += 1
            continue

        name, value = split_value(argv, i)
        if value is None:
            value = next_value(argv, i, name)
            i += 1
        if name in ("-b", "--bytes-format"):
            opts.bytes_format = require_choice(name, value, ["plain", "metric", "binary"])
        elif name in ("-q", "--quantity"):
            opts.quantity = require_choice(name, value, ["apparent-size", "block-size", "block-count"])
        elif name in ("-d", "--depth", "--max-depth"):
            opts.max_depth = parse_depth(value)
        elif name in ("-m", "--min-ratio"):
            opts.min_ratio = parse_min_ratio(value)
        elif name in ("-w", "--width", "--total-width"):
            opts.total_width = parse_positive_int(value, name)
        elif name == "--threads":
            if value not in ("auto", "max"):
                parse_positive_int(value, name)
        elif name == "--column-width":
            first = value
            second = next_value(argv, i, name)
            opts.column_width = (parse_positive_int(first, name), parse_positive_int(second, name))
            i += 1
        else:
            fail(f"error: unexpected argument '{arg}' found\n\nUsage: executable [OPTIONS] [FILES]...\n\nFor more information, try '--help'.", 2)
        i += 1
    if not opts.files:
        opts.files = ["."]
    return opts


def split_value(argv: list[str], i: int) -> tuple[str, str | None]:
    arg = argv[i]
    if "=" in arg and arg.startswith("--"):
        name, value = arg.split("=", 1)
        return name, value
    return arg, None


def next_value(argv: list[str], i: int, name: str) -> str:
    if i + 1 >= len(argv):
        fail(f"error: a value is required for '{name} <VALUE>' but none was supplied", 2)
    return argv[i + 1]


def require_choice(name: str, value: str, choices: list[str]) -> str:
    if value not in choices:
        fail(f"error: invalid value '{value}' for '{name}'\n  [possible values: {', '.join(choices)}]\n\nFor more information, try '--help'.", 2)
    return value


def parse_positive_int(value: str, name: str) -> int:
    try:
        n = int(value)
    except ValueError:
        fail(f"error: invalid value '{value}' for '{name}': invalid digit found in string\n\nFor more information, try '--help'.", 2)
    if n <= 0:
        fail(f"error: invalid value '{value}' for '{name}': Value is neither \"inf\" nor a positive integer: number would be zero for non-zero type\n\nFor more information, try '--help'.", 2)
    return n


def parse_depth(value: str) -> int | None:
    if value == "inf":
        return None
    return parse_positive_int(value, "--max-depth")


def parse_min_ratio(value: str) -> float:
    try:
        ratio = float(value)
    except ValueError:
        fail(f"error: invalid value '{value}' for '--min-ratio <MIN_RATIO>': invalid float literal\n\nFor more information, try '--help'.", 2)
    if ratio < 0:
        fail(f"error: invalid value '{value}' for '--min-ratio <MIN_RATIO>': negative", 2)
    if ratio >= 1:
        fail(f"error: invalid value '{value}' for '--min-ratio <MIN_RATIO>': greater than or equal to 1\n\nFor more information, try '--help'.", 2)
    return ratio


def fail(message: str, code: int) -> None:
    print(message, file=sys.stderr)
    raise SystemExit(code)


def measure_size(st: os.stat_result, opts: Options) -> int:
    if opts.quantity == "apparent-size":
        return int(st.st_size)
    if opts.quantity == "block-count":
        return int(st.st_blocks)
    return int(st.st_blocks) * 512


def build_node(path: str, opts: Options, root_path: str | None = None, depth: int = 1, ctx: ScanContext | None = None) -> Node:
    try:
        st = os.lstat(path)
    except OSError as exc:
        if not opts.silent_errors:
            print(f'[error] symlink_metadata "{path}": {exc.strerror} (os error {exc.errno})', file=sys.stderr)
        return Node(path if root_path is None else os.path.basename(path), path, 0, [])
    name = path if root_path is None else os.path.basename(path)
    node = Node(name, path, measure_size(st, opts), [])
    if opts.dedupe and st.st_nlink > 1 and not os.path.isdir(path):
        key = (int(st.st_dev), int(st.st_ino))
        record = (ctx.links if ctx else {}).get(key)
        if record is None and ctx is not None:
            record = LinkRecord(int(st.st_ino), measure_size(st, opts), int(st.st_nlink), [])
            ctx.links[key] = record
        if record is not None:
            record.paths.append(path)
    if os.path.isdir(path) and not os.path.islink(path):
        try:
            entries = [os.path.join(path, entry) for entry in os.listdir(path)]
        except OSError as exc:
            if not opts.silent_errors:
                print(f'[error] read_dir "{path}": {exc.strerror} (os error {exc.errno})', file=sys.stderr)
            entries = []
        for child_path in entries:
            child = build_node(child_path, opts, root_path=path, depth=depth + 1, ctx=ctx)
            node.children.append(child)
            node.size += child.size
        if not opts.no_sort:
            node.children.sort(key=lambda child: (-child.size, child.name))
    return node


def total_node(paths: list[str], opts: Options) -> Node:
    ctx = ScanContext()
    if len(paths) == 1:
        root = build_node(paths[0], opts, ctx=ctx)
        apply_hardlink_summary(root, opts, ctx)
        return root
    root = Node("(total)", "(total)", 0, [])
    for path in paths:
        child = build_node(path, opts, ctx=ctx)
        root.children.append(child)
        root.size += child.size
    if not opts.no_sort:
        root.children.sort(key=lambda child: (-child.size, child.name))
    apply_hardlink_summary(root, opts, ctx)
    return root


def apply_hardlink_summary(root: Node, opts: Options, ctx: ScanContext) -> None:
    if not opts.dedupe:
        return
    records = [record for record in ctx.links.values() if len(record.paths) > 1]
    if not records:
        return
    duplicate_size = sum((len(record.paths) - 1) * record.size for record in records)
    root.size = max(0, root.size - duplicate_size)
    details = [
        {
            "ino": record.ino,
            "size": record.size,
            "links": record.links,
            "paths": record.paths,
        }
        for record in records
    ]
    all_links = sum(record.links for record in records)
    detected_links = sum(len(record.paths) for record in records)
    shared_size = sum(record.size for record in records)
    opts.shared = {
        "details": details,
        "summary": {
            "inodes": len(records),
            "exclusive_inodes": len(records),
            "all_links": all_links,
            "detected_links": detected_links,
            "exclusive_links": detected_links,
            "shared_size": shared_size,
            "exclusive_shared_size": shared_size,
        },
    }


def prune(node: Node, opts: Options, total: int, depth: int = 1) -> Node:
    max_depth = opts.max_depth
    keep_children = []
    if max_depth is None or depth < max_depth:
        for child in node.children:
            if total == 0 or child.size / total >= opts.min_ratio:
                keep_children.append(prune(child, opts, total, depth + 1))
    return Node(node.name, node.path, node.size, keep_children)


def json_document(root: Node, opts: Options) -> dict:
    unit = "blocks" if opts.quantity == "block-count" else "bytes"
    doc = {"schema-version": SCHEMA_VERSION, "pdu": VERSION, "unit": unit, "tree": root.to_json()}
    if opts.shared:
        shared = {}
        if not opts.omit_shared_details:
            shared["details"] = opts.shared["details"]
        if not opts.omit_shared_summary:
            shared["summary"] = opts.shared["summary"]
        if shared:
            doc["shared"] = shared
    return doc


def print_json(root: Node, opts: Options) -> None:
    print(json.dumps(json_document(root, opts), separators=(",", ":")))


def print_help(long: bool = False) -> None:
    print("""Summarize disk usage of the set of files, recursively for directories.

Usage: executable [OPTIONS] [FILES]...

Arguments:
  [FILES]...  List of files and/or directories

Options:
      --json-input
          Read JSON data from stdin
      --json-output
          Print JSON data instead of an ASCII chart
  -b, --bytes-format <BYTES_FORMAT>
          How to display the numbers of bytes [default: metric] [possible values: plain, metric, binary]
  -H, --deduplicate-hardlinks
          Detect and subtract the sizes of hardlinks from their parent directory totals [aliases: --detect-links, --dedupe-links]
      --top-down
          Print the tree top-down instead of bottom-up
      --align-right
          Set the root of the bars to the right
  -q, --quantity <QUANTITY>
          Aspect of the files/directories to be measured [default: block-size] [possible values: apparent-size, block-size, block-count]
  -d, --max-depth <MAX_DEPTH>
          Maximum depth to display the data. Could be either "inf" or a positive integer [default: 10] [aliases: --depth]
  -w, --total-width <TOTAL_WIDTH>
          Width of the visualization [aliases: --width]
      --column-width <TREE_WIDTH> <BAR_WIDTH>
          Maximum widths of the tree column and width of the bar column
  -m, --min-ratio <MIN_RATIO>
          Minimal size proportion required to appear [default: 0.01]
      --no-sort
          Do not sort the branches in the tree
  -s, --silent-errors
          Prevent filesystem error messages from appearing in stderr [aliases: --no-errors]
  -p, --progress
          Report progress being made at the expense of performance
      --threads <THREADS>
          Set the maximum number of threads to spawn. Could be either "auto", "max", or a positive integer [default: auto]
      --omit-json-shared-details
          Do not output `.shared.details` in the JSON output
      --omit-json-shared-summary
          Do not output `.shared.summary` in the JSON output
  -h, --help
          Print help (see more with '--help')
  -V, --version
          Print version""")


def main(argv: list[str]) -> int:
    opts = parse_args(argv)
    if opts.json_input:
        try:
            doc = json.load(sys.stdin)
        except Exception as exc:
            print(f"[error] DeserializationFailure: {exc}", file=sys.stderr)
            return 3
        if doc.get("schema-version") != SCHEMA_VERSION:
            print(f'[error] DeserializationFailure: InvalidSchema: "{doc.get("schema-version")}": input schema is not "{SCHEMA_VERSION}"', file=sys.stderr)
            return 3
        if doc.get("unit") == "blocks":
            opts.quantity = "block-count"
        root = node_from_json(doc.get("tree", doc))
        opts.json_output = False
    else:
        root = total_node(opts.files, opts)
    root = prune(root, opts, root.size)
    if opts.json_output:
        print_json(root, opts)
    else:
        print_chart(root, opts)
    return 0


def node_from_json(data: dict) -> Node:
    node = Node(str(data.get("name", "")), str(data.get("name", "")), int(data.get("size", 0)), [])
    node.children = [node_from_json(child) for child in data.get("children", [])]
    return node


def format_size(size: int, opts: Options) -> str:
    if opts.bytes_format == "plain" or opts.quantity == "block-count":
        return str(size)
    base = 1024 if opts.bytes_format == "binary" else 1000
    units = ["", "K", "M", "G", "T", "P", "E"]
    value = float(size)
    idx = 0
    while abs(value) >= base and idx < len(units) - 1:
        value /= base
        idx += 1
    if idx == 0:
        return str(size)
    if value >= 10 or value.is_integer():
        return f"{value:.0f}{units[idx]}"
    return f"{value:.1f}{units[idx]}"


def flatten_bottom_up(node: Node, level: int = 0) -> list[tuple[int, Node]]:
    rows: list[tuple[int, Node]] = []
    for child in reversed(node.children):
        rows.extend(flatten_bottom_up(child, level + 1))
    rows.append((level, node))
    return rows


def flatten_top_down(node: Node, level: int = 0) -> list[tuple[int, Node]]:
    rows = [(level, node)]
    for child in node.children:
        rows.extend(flatten_top_down(child, level + 1))
    return rows


def print_chart(root: Node, opts: Options) -> None:
    rows = flatten_top_down(root) if opts.top_down else flatten_bottom_up(root)
    total = root.size or 1
    max_name = max((len("  " * level + node.name) for level, node in rows), default=1)
    for level, node in rows:
        label = "  " * level + node.name
        pct = round(node.size * 100 / total)
        bar_width = 30
        filled = int(round(node.size * bar_width / total)) if total else 0
        bar = "█" * filled + " " * (bar_width - filled)
        print(f"{format_size(node.size, opts):>6}  {label:<{max_name}} │{bar}│{pct:>3}%")


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
