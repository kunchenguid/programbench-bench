#!/usr/bin/env python3
import sys, os, re, csv, json
from io import StringIO

HELP = """trdsql - Execute SQL queries on CSV, LTSV, JSON, YAML and TBLN.

Usage
	trdsql [OPTIONS] [SQL(SELECT...)]

Options:
  -A string           analyze the file but only suggest SQL.
  -a string           analyze the file and suggest SQL.
  -config string      configuration file location.
  -db string          specify db name of the setting.
  -dblist             display db information.
  -debug              debug print.
  -driver string      database driver.  [ mysql | postgres | sqlite3 | sqlite3_ext ]
  -dsn string         database driver specific data source name.
  -help               display usage information.
  -q string           read query from the specified file.
  -t string           read table name from the specified file.
  -version            display version information.

Input Formats:
  -icsv               CSV format for input.
  -ig                 guess format from extension. (default "true")
  -ijson              JSON format for input.
  -iltsv              LTSV format for input.
  -itbln              TBLN format for input.
  -itext              text format for input.
  -iwidth             width specification format for input.
  -iyaml              YAML format for input.

Input options:
  -id string          field delimiter for input. (default ",")
  -ih                 the first line is interpreted as column names(CSV only).
  -ijq string         jq expression string for input(JSON/JSONL only).
  -ilr int            limited number of rows to read. (default 0)
  -inull value        value(string) to convert to null on input.
  -inum               add row number column.
  -ir int             number of rows to preread. (default 1)
  -is int             skip header row. (default 0)

Output Formats:
  -oat                ASCII Table format for output.
  -ocsv               CSV format for output.
  -ojson              JSON format for output.
  -ojsonl             JSON lines format for output.
  -oltsv              LTSV format for output.
  -omd                Markdown format for output.
  -oraw               Raw format for output.
  -otbln              TBLN format for output.
  -ovf                Vertical format for output.
  -oyaml              YAML format for output.

Output options:
  -oaq                enclose all fields in quotes for output.
  -ocrlf              use CRLF for output. End each output line with '\r\n' instead of '\n'.
  -od string          field delimiter for output. (default ",")
  -oh                 output column name as header.
  -onowrap            do not wrap long lines(at/md only).
  -onull value        value(string) to convert from null on output.
  -oq string          quote character for output. (default "\"")
  -out string         output file name.
  -out-without-guess  output without guessing (when using -out).
  -oz string          output compression format. [ gz | bz2 | zstd | lz4 | xz ]

Examples:
  $ trdsql "SELECT c1,c2 FROM test.csv"
  $ trdsql -oltsv "SELECT c1,c2 FROM test.json::.items"
  $ cat test.csv | trdsql -icsv -oltsv "SELECT c1,c2 FROM -"
"""

class Opts:
    def __init__(self):
        self.ih=False; self.inum=False; self.input_fmt=None; self.out_fmt='csv'; self.oh=False
        self.id=','; self.od=','; self.qfile=None; self.tfile=None; self.analyze=None; self.analyze_only=False
        self.ilr=0; self.iskip=0; self.inull=None; self.onull=''; self.out=None; self.crlf=False; self.oaq=False

def parse_args(argv):
    opts=Opts(); sql=[]; i=0
    while i < len(argv):
        a=argv[i]
        if a in ('-help','--help'):
            print(HELP, end=''); sys.exit(2 if a=='--help' else 0)
        if a=='-version': print('trdsql version devel'); sys.exit(0)
        if a=='-dblist': sys.exit(0)
        if a=='-ih': opts.ih=True
        elif a=='-inum': opts.inum=True
        elif a in ('-icsv','-ijson','-iltsv','-itbln','-itext','-iyaml'):
            opts.input_fmt=a[2:]
        elif a in ('-ocsv','-ojson','-ojsonl','-oltsv','-omd','-oat','-oraw','-otbln','-ovf','-oyaml'):
            opts.out_fmt=a[2:]
        elif a.startswith('-o') and len(a)>2 and a not in ('-od','-oh','-oq','-out','-onull','-oaq','-ocrlf'):
            opts.out_fmt=a[2:]
        elif a=='-oh': opts.oh=True
        elif a=='-oaq': opts.oaq=True
        elif a=='-ocrlf': opts.crlf=True
        elif a in ('-id','-od','-q','-t','-a','-A','-ilr','-is','-inull','-onull','-out','-ijq','-config','-db','-driver','-dsn','-oq','-oz'):
            i+=1; val=argv[i] if i < len(argv) else ''
            if a=='-id': opts.id=val
            elif a=='-od': opts.od=val
            elif a=='-q': opts.qfile=val
            elif a=='-t': opts.tfile=val
            elif a=='-a': opts.analyze=val
            elif a=='-A': opts.analyze=val; opts.analyze_only=True
            elif a=='-ilr': opts.ilr=int(val or 0)
            elif a=='-is': opts.iskip=int(val or 0)
            elif a=='-inull': opts.inull=val
            elif a=='-onull': opts.onull=val
            elif a=='-out': opts.out=val
        elif a in ('-debug','-ig','-out-without-guess','-onowrap'):
            pass
        else:
            sql.append(a)
        i+=1
    if opts.qfile:
        with open(opts.qfile) as f: sql=[f.read()]
    return opts, ' '.join(sql).strip()

def read_text(path):
    if path=='-': return sys.stdin.read()
    with open(path, newline='') as f: return f.read()

def guess_fmt(path, opts):
    if opts.input_fmt: return opts.input_fmt
    p=path.split('::',1)[0].lower()
    if p.endswith('.json') or p.endswith('.jsonl'): return 'json'
    if p.endswith('.ltsv'): return 'ltsv'
    if p.endswith('.tbln'): return 'tbln'
    return 'csv'

def table_name(path): return path.split('::',1)[0]

def scalar(v):
    if v is None: return None
    if isinstance(v,(dict,list)): return json.dumps(v, separators=(',',':'))
    return str(v)

def load_table(path, opts):
    base=table_name(path); fmt=guess_fmt(base, opts); text=read_text(base)
    rows=[]; cols=[]
    if fmt=='ltsv':
        for line in text.splitlines():
            if not line: continue
            d={}
            for part in line.split('\t'):
                if ':' in part:
                    k,v=part.split(':',1); d[k]=v
                    if k not in cols: cols.append(k)
            rows.append(d)
    elif fmt=='json':
        s=text.strip()
        if not s: data=[]
        else:
            try: data=json.loads(s)
            except Exception: data=[json.loads(line) for line in text.splitlines() if line.strip()]
        if isinstance(data, dict):
            if '::.' in path:
                key=path.split('::.',1)[1].split('.',1)[0]
                data=data.get(key, [])
            else: data=[data]
        for item in data:
            if isinstance(item, dict): d={k: scalar(v) for k,v in item.items()}
            elif isinstance(item, list): d={f'c{i+1}': scalar(v) for i,v in enumerate(item)}
            else: d={'c1': scalar(item)}
            for k in d:
                if k not in cols: cols.append(k)
            rows.append(d)
    else:
        raw=list(csv.reader(StringIO(text), delimiter=opts.id))[opts.iskip:]
        if raw:
            if opts.ih:
                cols=[c if c else f'c{i+1}' for i,c in enumerate(raw[0])]; data=raw[1:]
            else:
                cols=[f'c{i+1}' for i in range(max(len(r) for r in raw))]; data=raw
            for r in data: rows.append({cols[i]: (r[i] if i < len(r) else '') for i in range(len(cols))})
    if opts.inum:
        cols=['rownum']+cols
        for n,r in enumerate(rows,1): r['rownum']=str(n)
    if opts.ilr: rows=rows[:opts.ilr]
    if opts.inull is not None:
        for r in rows:
            for k,v in list(r.items()):
                if v==opts.inull: r[k]=None
    return cols, rows, fmt

def parse_sql(sql):
    m=re.match(r'(?is)^\s*select\s+(.*?)\s+from\s+([^\s]+)(.*)$', sql.strip())
    if not m: raise SystemExit('invalid query')
    q={'select':m.group(1).strip(),'path':m.group(2).strip('`"'),'where':None,'group':None,'order':None,'limit':None}
    rest=m.group(3).strip(); positions=[]
    for name,pat in [('where',r'\bwhere\b'),('group',r'\bgroup\s+by\b'),('order',r'\border\s+by\b'),('limit',r'\blimit\b')]:
        mm=re.search(pat, rest, re.I)
        if mm: positions.append((mm.start(), mm.end(), name))
    positions.sort()
    for idx,(st,en,name) in enumerate(positions):
        end=positions[idx+1][0] if idx+1<len(positions) else len(rest)
        q[name]=rest[en:end].strip()
    return q

def value(row, expr):
    expr=expr.strip().strip('`')
    if (expr.startswith("'") and expr.endswith("'")) or (expr.startswith('"') and expr.endswith('"')): return expr[1:-1]
    if re.match(r'^[-+]?(?:\d+(?:\.\d*)?|\.\d+)$', expr): return expr
    return row.get(expr, '')

def num_or_str(x):
    if x is None: return None
    try:
        if str(x).strip()=='': return x
        return float(x)
    except Exception: return str(x)

def match_where(row, cond):
    if not cond: return True
    for c in re.split(r'\s+and\s+', cond, flags=re.I):
        m=re.match(r'(?is)^(.+?)\s*(=|!=|<>|>=|<=|>|<|like)\s*(.+)$', c.strip())
        if not m: continue
        l=value(row,m.group(1)); op=m.group(2).lower(); r=value(row,m.group(3))
        if op=='like':
            pat='^'+re.escape(str(r)).replace('%','.*').replace('_','.')+'$'; ok=re.match(pat,str(l)) is not None
        else:
            ln=num_or_str(l); rn=num_or_str(r)
            a,b=(ln,rn) if isinstance(ln,float) and isinstance(rn,float) else (str(l),str(r))
            ok={'=':a==b,'!=':a!=b,'<>':a!=b,'>':a>b,'<':a<b,'>=':a>=b,'<=':a<=b}[op]
        if not ok: return False
    return True

def split_select(sel):
    if sel.strip()=='*': return ['*']
    out=[]; cur=''; quote=None; depth=0
    for ch in sel:
        if quote:
            cur+=ch
            if ch==quote: quote=None
        elif ch in "'\"": quote=ch; cur+=ch
        elif ch=='(': depth+=1; cur+=ch
        elif ch==')': depth-=1; cur+=ch
        elif ch==',' and depth==0: out.append(cur.strip()); cur=''
        else: cur+=ch
    if cur.strip(): out.append(cur.strip())
    return out

def project(cols, rows, q):
    rows=[r for r in rows if match_where(r,q['where'])]
    items=split_select(q['select'])
    if len(items)==1 and re.match(r'(?i)^count\s*\(\s*\*?\w*\s*\)$', items[0]):
        name=items[0]
        return [name], [{name:str(len(rows))}]
    if q['group']:
        g=q['group'].strip().strip('`'); groups={}
        for r in rows: groups.setdefault(r.get(g,''),[]).append(r)
        out=[]
        for key,rs in groups.items():
            d={g:key}
            for it in items:
                cm=re.match(r'(?i)^count\s*\((.*?)\)$', it)
                if cm: d[it]=str(len(rs))
                elif it==g: d[g]=key
            out.append(d)
        return [it.strip().strip('`') for it in items], out
    if q['order']:
        parts=q['order'].split(); key=parts[0].strip('`'); rev=len(parts)>1 and parts[1].lower()=='desc'
        rows=sorted(rows, key=lambda r: num_or_str(r.get(key,'')), reverse=rev)
    if q['limit']:
        try: rows=rows[:int(q['limit'].split()[0])]
        except Exception: pass
    outcols=cols if items==['*'] else [(re.split(r'\s+as\s+', it, flags=re.I)[-1] if re.search(r'\s+as\s+', it, re.I) else it).strip().strip('`') for it in items]
    out=[]
    for r in rows:
        d={}
        if items==['*']:
            for c in outcols: d[c]=r.get(c,'')
        else:
            for it,c in zip(items,outcols): d[c]=value(r,re.split(r'\s+as\s+', it, flags=re.I)[0])
        out.append(d)
    return outcols,out

def write_csv(cols, rows, opts):
    sio=StringIO(); w=csv.writer(sio, delimiter=opts.od, lineterminator='\r\n' if opts.crlf else '\n', quoting=csv.QUOTE_ALL if opts.oaq else csv.QUOTE_MINIMAL)
    if opts.oh: w.writerow(cols)
    for r in rows: w.writerow([opts.onull if r.get(c) is None else r.get(c,'') for c in cols])
    return sio.getvalue()

def render(cols, rows, opts):
    fmt=opts.out_fmt
    if fmt=='csv': return write_csv(cols,rows,opts)
    if fmt=='json': return json.dumps([{c:r.get(c) for c in cols} for r in rows], indent=2) + '\n'
    if fmt=='jsonl': return ''.join(json.dumps({c:r.get(c) for c in cols}, separators=(',',':'))+'\n' for r in rows)
    if fmt=='ltsv': return ''.join('\t'.join(f'{c}:{opts.onull if r.get(c) is None else r.get(c,"")}' for c in cols)+'\n' for r in rows)
    if fmt=='raw': return ''.join(''.join(str(opts.onull if r.get(c) is None else r.get(c,'')) for c in cols)+'\n' for r in rows)
    if fmt in ('md','at'):
        widths=[max([len(str(c))]+[len(str(r.get(c,''))) for r in rows]) for c in cols]
        if fmt=='md':
            lines=['| '+' | '.join(str(c).ljust(w) for c,w in zip(cols,widths))+' |', '| '+' | '.join('-'*w for w in widths)+' |']
            lines += ['| '+' | '.join(str(r.get(c,'')).ljust(w) for c,w in zip(cols,widths))+' |' for r in rows]
            return '\n'.join(lines)+'\n'
        sep='+' + '+'.join('-'*(w+2) for w in widths) + '+\n'
        s=sep+'| '+' | '.join(str(c).ljust(w) for c,w in zip(cols,widths))+' |\n'+sep
        for r in rows: s+='| '+' | '.join(str(r.get(c,'')).ljust(w) for c,w in zip(cols,widths))+' |\n'
        return s+sep
    if fmt=='yaml': return ''.join('- '+', '.join(f'{c}: {r.get(c,"")}' for c in cols)+'\n' for r in rows)
    return write_csv(cols,rows,opts)

def analyze(path, opts):
    cols, rows, fmt=load_table(path, opts); tn=path; prog=os.path.basename(sys.argv[0])
    first=rows[0].get(cols[0], '') if rows and cols else ''
    ex=[f'{prog} "SELECT {", ".join(cols)} FROM {tn}"', f'{prog} "SELECT {", ".join(cols)} FROM {tn} WHERE {cols[0]} = \'{first}\'"', f'{prog} "SELECT {cols[0]}, count({cols[0]}) FROM {tn} GROUP BY {cols[0]}"', f'{prog} "SELECT {", ".join(cols)} FROM {tn} ORDER BY {cols[0]} LIMIT 10"'] if cols else []
    if opts.analyze_only: return '\n'.join(ex)+'\n'
    return f'The table name is {tn}.\nThe file type is {fmt.upper()}.\n\nExamples:\n'+'\n'.join(ex)+'\n'

def main(argv):
    opts, sql=parse_args(argv)
    if opts.analyze:
        out=analyze(opts.analyze, opts)
    else:
        if opts.tfile and not sql: sql=f'select * from {opts.tfile}'
        q=parse_sql(sql); cols, rows, _=load_table(q['path'], opts); cols, rows=project(cols, rows, q); out=render(cols, rows, opts)
    if opts.out:
        with open(opts.out,'w',newline='') as f: f.write(out)
    else: sys.stdout.write(out)

if __name__=='__main__':
    try: main(sys.argv[1:])
    except BrokenPipeError: pass
