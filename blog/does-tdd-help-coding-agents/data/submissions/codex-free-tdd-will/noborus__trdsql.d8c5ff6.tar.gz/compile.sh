#!/bin/bash
set -e
rm -f executable
cp src/trdsql.py executable
chmod +x executable
