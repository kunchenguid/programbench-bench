#include <errno.h>
#include <math.h>
#include <setjmp.h>
#include <stddef.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <jpeglib.h>

#define DEFAULT_CHARS "   ...',;:clodxkO0KXNWM"

struct image {
    int w;
    int h;
    int comps;
    unsigned char *pixels;
};

struct jpeg_error {
    struct jpeg_error_mgr pub;
    jmp_buf jump;
};

struct opts {
    int out_w;
    int out_h;
    int have_w;
    int have_h;
    int invert;
    int flipx;
    int flipy;
    int border;
    int html;
    int html_raw;
    int html_bold;
    int html_fontsize;
    int colors;
    int fill;
    int grayscale;
    const char *chars;
    const char *output;
    const char *html_title;
    double rw;
    double gw;
    double bw;
};

static void jpeg_fail(j_common_ptr cinfo) {
    struct jpeg_error *err = (struct jpeg_error *)cinfo->err;
    longjmp(err->jump, 1);
}

static void version(FILE *out) {
    fputs("jp2a 1.0.8\n", out);
    fputs("Copyright 2006-2016 Christian Stigen Larsen\n", out);
    fputs("Distributed under the GNU General Public License (GPL) v2.\n", out);
}

static void help(FILE *out) {
    version(out);
    fputc('\n', out);
    fputs("Usage: jp2a [ options ] [ file(s) | URL(s) ]\n\n", out);
    fputs("Convert files or URLs from JPEG format to ASCII.\n\n", out);
    fputs("OPTIONS\n", out);
    fputs("  -                 Read images from standard input.\n", out);
    fputs("      --blue=N.N    Set RGB to grayscale conversion weight, default is 0.1145\n", out);
    fputs("  -b, --border      Print a border around the output image.\n", out);
    fputs("      --chars=...   Select character palette used to paint the image.\n", out);
    fputs("      --colors      Use ANSI colors in output.\n", out);
    fputs("  -x, --flipx       Flip image in X direction.\n", out);
    fputs("  -y, --flipy       Flip image in Y direction.\n", out);
    fputs("  -f, --term-fit    Use the largest image dimension that fits in your terminal\n", out);
    fputs("      --height=N    Set output height, calculate width from aspect ratio.\n", out);
    fputs("  -h, --help        Print program help.\n", out);
    fputs("      --html        Produce strict XHTML 1.0 output.\n", out);
    fputs("  -i, --invert      Invert output image.\n", out);
    fputs("      --output=...  Write output to file.\n", out);
    fputs("      --red=N.N     Set RGB to grayscale conversion weight, default 0.2989f.\n", out);
    fputs("      --size=WxH    Set output width and height.\n", out);
    fputs("  -v, --verbose     Verbose output.\n", out);
    fputs("  -V, --version     Print program version.\n", out);
    fputs("      --width=N     Set output width, calculate height from ratio.\n", out);
}

static int read_jpeg(FILE *fp, struct image *img) {
    struct jpeg_decompress_struct cinfo;
    struct jpeg_error err;
    memset(&cinfo, 0, sizeof(cinfo));
    cinfo.err = jpeg_std_error(&err.pub);
    err.pub.error_exit = jpeg_fail;
    if (setjmp(err.jump)) {
        jpeg_destroy_decompress(&cinfo);
        return 0;
    }
    jpeg_create_decompress(&cinfo);
    jpeg_stdio_src(&cinfo, fp);
    jpeg_read_header(&cinfo, TRUE);
    jpeg_start_decompress(&cinfo);
    img->w = (int)cinfo.output_width;
    img->h = (int)cinfo.output_height;
    img->comps = (int)cinfo.output_components;
    size_t row = (size_t)img->w * (size_t)img->comps;
    img->pixels = malloc(row * (size_t)img->h);
    if (!img->pixels) {
        jpeg_destroy_decompress(&cinfo);
        return 0;
    }
    while (cinfo.output_scanline < cinfo.output_height) {
        unsigned char *ptr = img->pixels + (size_t)cinfo.output_scanline * row;
        jpeg_read_scanlines(&cinfo, &ptr, 1);
    }
    jpeg_finish_decompress(&cinfo);
    jpeg_destroy_decompress(&cinfo);
    return 1;
}

static double luminance(const struct image *img, int x, int y, const struct opts *opts) {
    const unsigned char *p = img->pixels + ((size_t)y * (size_t)img->w + (size_t)x) * (size_t)img->comps;
    if (img->comps == 1) return p[0];
    return opts->rw * p[0] + opts->gw * p[1] + opts->bw * p[2];
}

static void compute_size(const struct image *img, struct opts *opts) {
    if (opts->have_w && opts->have_h) return;
    if (opts->have_w) {
        int h = (int)ceil(((double)opts->out_w * (double)img->h) / ((double)img->w * 2.0));
        opts->out_h = h > 0 ? h : 1;
        opts->have_h = 1;
        return;
    }
    if (opts->have_h) {
        int w = (opts->out_h * img->w * 2) / img->h;
        opts->out_w = w > 0 ? w : 1;
        opts->have_w = 1;
        return;
    }
    opts->out_w = 80;
    opts->out_h = (int)ceil(((double)opts->out_w * (double)img->h) / ((double)img->w * 2.0));
    if (opts->out_h < 1) opts->out_h = 1;
    opts->have_w = opts->have_h = 1;
}

static char ascii_at(const struct image *img, int ox, int oy, const struct opts *opts) {
    int x0 = (ox * img->w) / opts->out_w;
    int x1 = ((ox + 1) * img->w) / opts->out_w;
    int y0 = (oy * img->h) / opts->out_h;
    int y1 = ((oy + 1) * img->h) / opts->out_h;
    if (x1 <= x0) x1 = x0 + 1;
    if (y1 <= y0) y1 = y0 + 1;
    if (x1 > img->w) x1 = img->w;
    if (y1 > img->h) y1 = img->h;
    double sum = 0.0;
    long count = 0;
    for (int yy = y0; yy < y1; ++yy) {
        int sy = opts->flipy ? img->h - 1 - yy : yy;
        for (int xx = x0; xx < x1; ++xx) {
            int sx = opts->flipx ? img->w - 1 - xx : xx;
            sum += luminance(img, sx, sy, opts);
            ++count;
        }
    }
    double y = count ? sum / (double)count : 0.0;
    size_t n = strlen(opts->chars);
    int idx = (int)((y * (double)n) / 256.0);
    if (idx < 0) idx = 0;
    if (idx >= (int)n) idx = (int)n - 1;
    if (opts->invert) idx = (int)n - 1 - idx;
    return opts->chars[idx];
}

static void color_at(const struct image *img, int ox, int oy, const struct opts *opts, int *r, int *g, int *b) {
    int x0 = (ox * img->w) / opts->out_w;
    int x1 = ((ox + 1) * img->w) / opts->out_w;
    int y0 = (oy * img->h) / opts->out_h;
    int y1 = ((oy + 1) * img->h) / opts->out_h;
    if (x1 <= x0) x1 = x0 + 1;
    if (y1 <= y0) y1 = y0 + 1;
    if (x1 > img->w) x1 = img->w;
    if (y1 > img->h) y1 = img->h;
    double sr = 0, sg = 0, sb = 0;
    long count = 0;
    for (int yy = y0; yy < y1; ++yy) {
        int sy = opts->flipy ? img->h - 1 - yy : yy;
        for (int xx = x0; xx < x1; ++xx) {
            int sx = opts->flipx ? img->w - 1 - xx : xx;
            const unsigned char *p = img->pixels + ((size_t)sy * (size_t)img->w + (size_t)sx) * (size_t)img->comps;
            if (img->comps == 1 || opts->grayscale) {
                int yv = (int)luminance(img, sx, sy, opts);
                sr += yv; sg += yv; sb += yv;
            } else {
                sr += p[0]; sg += p[1]; sb += p[2];
            }
            ++count;
        }
    }
    if (!count) count = 1;
    *r = (int)(sr / count + 0.5);
    *g = (int)(sg / count + 0.5);
    *b = (int)(sb / count + 0.5);
}

static int ansi_code(int r, int g, int b) {
    int bright = (r + g + b) / 3;
    int red = r > 96, green = g > 96, blue = b > 96;
    int code = 30 + red + 2 * green + 4 * blue;
    if (bright > 170 && code != 37) code += 60;
    return code;
}

static void render_plain(FILE *out, const struct image *img, const struct opts *opts) {
    if (opts->border) {
        fputc('+', out);
        for (int x = 0; x < opts->out_w; ++x) fputc('-', out);
        fputs("+\n", out);
    }
    for (int y = 0; y < opts->out_h; ++y) {
        if (opts->border) fputc('|', out);
        for (int x = 0; x < opts->out_w; ++x) fputc(ascii_at(img, x, y, opts), out);
        if (opts->border) fputc('|', out);
        fputc('\n', out);
    }
    if (opts->border) {
        fputc('+', out);
        for (int x = 0; x < opts->out_w; ++x) fputc('-', out);
        fputs("+\n", out);
    }
}

static void render_html(FILE *out, const struct image *img, const struct opts *opts) {
    if (!opts->html_raw) {
        fputs("<?xml version='1.0' encoding='ISO-8859-1'?>\n", out);
        fputs("<!DOCTYPE html PUBLIC '-//W3C//DTD XHTML 1.0 Strict//EN'  'http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd'>\n", out);
        fputs("<html xmlns='http://www.w3.org/1999/xhtml' lang='en' xml:lang='en'>\n<head>\n", out);
        fprintf(out, "<title>%s</title>\n", opts->html_title);
        fputs("<style type='text/css'>\nbody {\n", out);
        fprintf(out, "background-color: %s;\n}\n.ascii {\n", opts->invert ? "white" : "black");
        fputs("   font-family: Courier;\n", out);
        if (!opts->colors) fprintf(out, "   color: %s;\n", opts->invert ? "black" : "white");
        fprintf(out, "   font-size:%dpt;\n", opts->html_fontsize);
        if (opts->html_bold) fputs("   font-weight: bold;\n", out);
        fputs("}\n</style>\n</head>\n<body>\n<div class='ascii'><pre>\n", out);
    }
    for (int y = 0; y < opts->out_h; ++y) {
        for (int x = 0; x < opts->out_w; ++x) {
            char ch = ascii_at(img, x, y, opts);
            if (opts->colors) {
                int r, g, b;
                color_at(img, x, y, opts, &r, &g, &b);
                if (opts->fill) {
                    fprintf(out, "<span style='color:#%02x%02x%02x; background-color:#%02x%02x%02x;'>", r, g, b, r, g, b);
                } else {
                    fprintf(out, "<span style='color:#%02x%02x%02x;'>", r, g, b);
                }
            }
            if (ch == '<') fputs("&lt;", out);
            else if (ch == '>') fputs("&gt;", out);
            else if (ch == '&') fputs("&amp;", out);
            else fputc(ch, out);
            if (opts->colors) fputs("</span>", out);
        }
        if (opts->colors && !opts->html_raw) fputs("<br/>", out);
        fputc('\n', out);
    }
    if (!opts->html_raw) {
        fputs("</pre>\n</div>\n</body>\n</html>\n", out);
    }
}

static void render_ansi(FILE *out, const struct image *img, const struct opts *opts) {
    int current = -1;
    for (int y = 0; y < opts->out_h; ++y) {
        current = -1;
        for (int x = 0; x < opts->out_w; ++x) {
            int r, g, b;
            color_at(img, x, y, opts, &r, &g, &b);
            int code = ansi_code(r, g, b);
            if (code != current) {
                fprintf(out, "\033[%dm", code);
                current = code;
            }
            fputc(ascii_at(img, x, y, opts), out);
        }
        if (current != -1) fputs("\033[0m", out);
        fputc('\n', out);
    }
}

static void render(FILE *out, const struct image *img, const struct opts *opts) {
    if (opts->html) render_html(out, img, opts);
    else if (opts->colors) render_ansi(out, img, opts);
    else render_plain(out, img, opts);
}

static int parse_size(const char *s, int *w, int *h) {
    char *x = strchr(s, 'x');
    if (!x) return 0;
    *w = atoi(s);
    *h = atoi(x + 1);
    return *w > 0 && *h > 0;
}

static int starts(const char *s, const char *prefix) {
    return strncmp(s, prefix, strlen(prefix)) == 0;
}

int main(int argc, char **argv) {
    struct opts opts;
    memset(&opts, 0, sizeof(opts));
    opts.chars = DEFAULT_CHARS;
    opts.html_bold = 1;
    opts.html_fontsize = 8;
    opts.html_title = "jp2a converted image";
    opts.rw = 0.2989;
    opts.gw = 0.5866;
    opts.bw = 0.1145;
    const char *files[256];
    int nfiles = 0;

    for (int i = 1; i < argc; ++i) {
        const char *a = argv[i];
        if (!strcmp(a, "--version") || !strcmp(a, "-V")) {
            version(stdout);
            return 0;
        } else if (!strcmp(a, "--help") || !strcmp(a, "-h")) {
            help(stdout);
            return 0;
        } else if (!strcmp(a, "-b") || !strcmp(a, "--border")) {
            opts.border = 1;
        } else if (!strcmp(a, "-i") || !strcmp(a, "--invert")) {
            opts.invert = 1;
        } else if (!strcmp(a, "-x") || !strcmp(a, "--flipx")) {
            opts.flipx = 1;
        } else if (!strcmp(a, "-y") || !strcmp(a, "--flipy")) {
            opts.flipy = 1;
        } else if (starts(a, "--size=")) {
            if (!parse_size(a + 7, &opts.out_w, &opts.out_h)) {
                fputs("Invalid width or height specified\n", stderr);
                return 1;
            }
            opts.have_w = opts.have_h = 1;
        } else if (starts(a, "--width=")) {
            opts.out_w = atoi(a + 8);
            if (opts.out_w <= 0) {
                fputs("Invalid width or height specified\n", stderr);
                return 1;
            }
            opts.have_w = 1;
        } else if (starts(a, "--height=")) {
            opts.out_h = atoi(a + 9);
            if (opts.out_h <= 0) {
                fputs("Invalid width or height specified\n", stderr);
                return 1;
            }
            opts.have_h = 1;
        } else if (starts(a, "--chars=")) {
            opts.chars = a + 8;
            if (strlen(opts.chars) < 2) {
                fputs("You must specify at least two characters in --chars.\n", stderr);
                return 1;
            }
        } else if (starts(a, "--output=")) {
            opts.output = a + 9;
        } else if (!strcmp(a, "--background=light")) {
            opts.invert = 1;
        } else if (!strcmp(a, "--background=dark")) {
            opts.invert = 0;
        } else if (starts(a, "--red=")) {
            opts.rw = atof(a + 6);
        } else if (starts(a, "--green=")) {
            opts.gw = atof(a + 8);
        } else if (starts(a, "--blue=")) {
            opts.bw = atof(a + 7);
        } else if (!strcmp(a, "--colors")) {
            opts.colors = 1;
        } else if (!strcmp(a, "--fill") || !strcmp(a, "--html-fill")) {
            opts.fill = 1;
        } else if (!strcmp(a, "--grayscale")) {
            opts.grayscale = 1;
        } else if (!strcmp(a, "--html-no-bold")) {
            opts.html_bold = 0;
        } else if (starts(a, "--html-fontsize=")) {
            opts.html_fontsize = atoi(a + 16);
            if (opts.html_fontsize <= 0) opts.html_fontsize = 8;
        } else if (starts(a, "--html-title=")) {
            opts.html_title = a + 13;
        } else if (!strcmp(a, "--html")) {
            opts.html = 1;
        } else if (!strcmp(a, "--html-raw")) {
            opts.html_raw = 1;
        } else if (!strcmp(a, "-v") || !strcmp(a, "--verbose") ||
                   !strcmp(a, "-d") || !strcmp(a, "--debug") ||
                   !strcmp(a, "-f") || !strcmp(a, "--term-fit") ||
                   !strcmp(a, "-z") || !strcmp(a, "--term-zoom") ||
                   !strcmp(a, "--term-width") || !strcmp(a, "--term-height")) {
            /* Supported later or harmless for plain fixed-size output. */
        } else if (a[0] == '-' && strcmp(a, "-")) {
            fprintf(stderr, "Unknown option %s\n\n", a);
            help(stderr);
            return 1;
        } else {
            if (nfiles < 256) files[nfiles++] = a;
        }
    }
    if (nfiles == 0) {
        fprintf(stderr, "No files specified.\n\n");
        help(stderr);
        return 1;
    }

    FILE *out = stdout;
    if (opts.output && strcmp(opts.output, "-")) {
        out = fopen(opts.output, "wb");
        if (!out) {
            fprintf(stderr, "%s: %s\n", opts.output, strerror(errno));
            return 1;
        }
    }
    int status = 0;
    for (int i = 0; i < nfiles; ++i) {
        FILE *fp = stdin;
        if (strcmp(files[i], "-")) {
            fp = fopen(files[i], "rb");
            if (!fp) {
                fprintf(stderr, "%s: %s\n", files[i], strerror(errno));
                status = 1;
                continue;
            }
        }
        struct image img = {0, 0, 0, NULL};
        struct opts cur = opts;
        if (!read_jpeg(fp, &img)) {
            fprintf(stderr, "%s: Could not read JPEG image\n", files[i]);
            status = 1;
        } else {
            compute_size(&img, &cur);
            render(out, &img, &cur);
        }
        free(img.pixels);
        if (fp != stdin) fclose(fp);
    }
    if (out != stdout) fclose(out);
    return status;
}
