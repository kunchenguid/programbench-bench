#!/bin/bash
set -euo pipefail

BIN=${BIN:-./executable}

fail() {
  echo "FAIL: $*" >&2
  exit 1
}

assert_eq() {
  local name=$1 expected=$2 actual=$3
  if [[ "$actual" != "$expected" ]]; then
    printf 'FAIL: %s\nexpected:\n%s\nactual:\n%s\n' "$name" "$expected" "$actual" >&2
    exit 1
  fi
}

out=$("$BIN" --version)
assert_eq "version" "jp2a 1.0.8
Copyright 2006-2016 Christian Stigen Larsen
Distributed under the GNU General Public License (GPL) v2." "$out"

help=$("$BIN" --help)
[[ "$help" == *"Usage: jp2a [ options ] [ file(s) | URL(s) ]"* ]] || fail "help usage"
[[ "$help" == *"--width=N"* ]] || fail "help width option"

img=$("$BIN" --size=8x4 assets/logo-40x25-gray.jpg)
[[ "$(printf '%s\n' "$img" | wc -l)" == "4" ]] || fail "fixed size height"
[[ "$(printf '%s\n' "$img" | awk '{print length}' | sort -nu | tr '\n' ' ')" == "8 " ]] || fail "fixed size width"

width_only=$("$BIN" --width=8 assets/logo-40x25-gray.jpg)
[[ "$(printf '%s\n' "$width_only" | wc -l)" == "3" ]] || fail "width calculates height"

height_only=$("$BIN" --height=4 assets/logo-40x25-gray.jpg)
[[ "$(printf '%s\n' "$height_only" | wc -l)" == "4" ]] || fail "height calculates height"
[[ "$(printf '%s\n' "$height_only" | awk 'NR==1{print length}')" == "12" ]] || fail "height calculates width"

border=$("$BIN" --size=8x4 --border assets/logo-40x25-gray.jpg)
[[ "$border" == +--------+* ]] || fail "border top"
[[ "$border" == *+--------+ ]] || fail "border bottom"

invert=$("$BIN" --size=4x2 --background=light assets/logo-40x25-gray.jpg)
dark=$("$BIN" --size=4x2 --background=dark assets/logo-40x25-gray.jpg)
[[ "$invert" != "$dark" ]] || fail "background light invert"

stdin_out=$(cat assets/logo-40x25-gray.jpg | "$BIN" --size=4x2 -)
file_out=$("$BIN" --size=4x2 assets/logo-40x25-gray.jpg)
assert_eq "stdin" "$file_out" "$stdin_out"

rm -f /tmp/jp2a-test-out.txt
"$BIN" --output=/tmp/jp2a-test-out.txt --size=4x2 assets/logo-40x25-gray.jpg
assert_eq "output file" "$file_out" "$(cat /tmp/jp2a-test-out.txt)"

html_raw=$("$BIN" --html --html-raw --size=4x2 assets/logo-40x25-gray.jpg)
assert_eq "html raw" "$file_out" "$html_raw"

html=$("$BIN" --html --size=4x2 assets/logo-40x25-gray.jpg)
[[ "$html" == *"<?xml version='1.0' encoding='ISO-8859-1'?>"* ]] || fail "html xml"
[[ "$html" == *"<title>jp2a converted image</title>"* ]] || fail "html title"
[[ "$html" == *"<div class='ascii'><pre>"* ]] || fail "html pre"
[[ "$html" == *"$file_out"* ]] || fail "html body"

echo "tests passed"
