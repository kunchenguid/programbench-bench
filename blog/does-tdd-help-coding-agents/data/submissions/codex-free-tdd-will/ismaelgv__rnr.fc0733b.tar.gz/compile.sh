#!/bin/bash
set -e
rm -f executable
cp src/rnr.py executable
chmod +x executable
