import os
import shutil
import subprocess
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
EXE = ROOT / "executable"

class CliTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        subprocess.run([str(ROOT / "compile.sh")], cwd=ROOT, check=True)

    def run_cmd(self, args, cwd):
        return subprocess.run([str(EXE), *args], cwd=cwd, text=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)

    def test_version(self):
        with tempfile.TemporaryDirectory() as td:
            res = self.run_cmd(["--version"], td)
        self.assertEqual(res.returncode, 0)
        self.assertEqual(res.stdout, "rnr 0.5.1\n")

    def test_regex_dry_run_renames_direct_paths_with_captures(self):
        with tempfile.TemporaryDirectory() as td:
            Path(td, "a12b.txt").write_text("")
            res = self.run_cmd(["regex", "--color", "never", "([a-z]+)([0-9]+)([a-z]+)", "$3-$2-$1", "a12b.txt"], td)
            self.assertEqual(res.returncode, 0)
            self.assertEqual(res.stdout, "This is a DRY-RUN\na12b.txt -> b-12-a.txt\n")
            self.assertTrue(Path(td, "a12b.txt").exists())

    def test_regex_force_renames_file(self):
        with tempfile.TemporaryDirectory() as td:
            Path(td, "foo.txt").write_text("content")
            res = self.run_cmd(["regex", "--color", "never", "-f", "--no-dump", "foo", "bar", "foo.txt"], td)
            self.assertEqual(res.returncode, 0)
            self.assertEqual(res.stdout, "foo.txt -> bar.txt\n")
            self.assertFalse(Path(td, "foo.txt").exists())
            self.assertEqual(Path(td, "bar.txt").read_text(), "content")

    def test_recursive_defaults_to_visible_files_only_and_can_include_dirs(self):
        with tempfile.TemporaryDirectory() as td:
            root = Path(td, "a")
            root.mkdir()
            Path(root, "foo.txt").write_text("")
            Path(root, ".foo.txt").write_text("")
            Path(root, "fooDir").mkdir()
            Path(root, "fooDir", "inside.txt").write_text("")
            res = self.run_cmd(["regex", "--color", "never", "-r", "-D", "foo", "bar", "a"], td)
            self.assertEqual(res.returncode, 0)
            self.assertEqual(res.stdout, "This is a DRY-RUN\na/fooDir -> a/barDir\na/foo.txt -> a/bar.txt\n")

    def test_to_ascii_dry_run(self):
        with tempfile.TemporaryDirectory() as td:
            for name in ["café.txt", "Æther.txt", "ß.txt", "中文.txt"]:
                Path(td, name).write_text("")
            res = self.run_cmd(["to-ascii", "--color", "never", "café.txt", "Æther.txt", "ß.txt", "中文.txt"], td)
            self.assertEqual(res.returncode, 0)
            self.assertEqual(res.stdout, "This is a DRY-RUN\nß.txt -> ss.txt\ncafé.txt -> cafe.txt\n中文.txt -> ZhongWen.txt\nÆther.txt -> Aether.txt\n")

    def test_from_file_force_and_undo_dry_run(self):
        with tempfile.TemporaryDirectory() as td:
            Path(td, "old.txt").write_text("x")
            Path(td, "ops.json").write_text('{"date":"x","operations":[{"source":"old.txt","target":"new.txt"}]}')
            res = self.run_cmd(["from-file", "--color", "never", "-f", "--no-dump", "ops.json"], td)
            self.assertEqual(res.returncode, 0)
            self.assertEqual(res.stdout, "old.txt -> new.txt\n")
            self.assertTrue(Path(td, "new.txt").exists())
            undo = self.run_cmd(["from-file", "--color", "never", "-u", "ops.json"], td)
            self.assertEqual(undo.stdout, "This is a DRY-RUN\nnew.txt -> old.txt\n")

if __name__ == "__main__":
    unittest.main()
