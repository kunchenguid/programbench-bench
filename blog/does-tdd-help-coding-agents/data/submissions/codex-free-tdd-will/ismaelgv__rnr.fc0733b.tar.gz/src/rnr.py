#!/usr/bin/env python3
import os
import re
import sys
import json
from datetime import datetime
import unicodedata


HELP = """RnR is a command-line tool to rename multiple files and directories that
supports regular expressions


Usage: executable <COMMAND>

Commands:
  regex      Rename files and directories using a regular expression
  from-file  Read operations from a dump file
  to-ascii   Replace file name UTF-8 chars with ASCII chars representation
  help       Print this message or the help of the given subcommand(s)

Options:
  -h, --help     Print help
  -V, --version  Print version
"""

REGEX_HELP = """Rename files and directories using a regular expression

Usage: executable regex [OPTIONS] <EXPRESSION> <REPLACEMENT> <PATH(S)>...

Arguments:
  <EXPRESSION>   Expression to match (can be a regex)
  <REPLACEMENT>  Expression replacement (use single quotes for capture groups)
  <PATH(S)>...   Target paths

Options:
  -n, --dry-run                    Only show what would be done (default mode)
  -f, --force                      Make actual changes to files
  -b, --backup                     Generate file backups before renaming
  -s, --silent                     Do not print any information
      --color <COLOR>              Set color output mode [default: auto] [possible values: always, never, auto]
      --dump                       Force dumping operations into a file even in dry-run mode
      --dump-prefix <DUMP_PREFIX>  Set the dump file prefix [default: rnr-]
      --no-dump                    Do not dump operations into a file
  -l, --replace-limit <LIMIT>      Limit of replacements, all matches if set to 0
  -t, --replace-transform <REPLACE_TRANSFORM>
                                  Apply a transformation to replacements including captured groups [possible values: upper, lower, ascii]
  -D, --include-dirs               Rename matching directories
  -r, --recursive                  Recursive mode
  -d, --max-depth <LEVEL>          Set max depth in recursive mode
  -x, --hidden                     Include hidden files and directories
  -h, --help                       Print help
"""

FROM_FILE_HELP = """Read operations from a dump file

Usage: executable from-file [OPTIONS] <DUMPFILE>

Arguments:
  <DUMPFILE>

Options:
  -n, --dry-run                    Only show what would be done (default mode)
  -f, --force                      Make actual changes to files
  -b, --backup                     Generate file backups before renaming
  -s, --silent                     Do not print any information
      --color <COLOR>              Set color output mode [default: auto] [possible values: always, never, auto]
      --dump                       Force dumping operations into a file even in dry-run mode
      --dump-prefix <DUMP_PREFIX>  Set the dump file prefix [default: rnr-]
      --no-dump                    Do not dump operations into a file
  -u, --undo                       Undo the operations from the dump file
  -h, --help                       Print help
"""

TO_ASCII_HELP = """Replace file name UTF-8 chars with ASCII chars representation

Usage: executable to-ascii [OPTIONS] <PATH(S)>...

Arguments:
  <PATH(S)>...  Target paths

Options:
  -n, --dry-run                    Only show what would be done (default mode)
  -f, --force                      Make actual changes to files
  -b, --backup                     Generate file backups before renaming
  -s, --silent                     Do not print any information
      --color <COLOR>              Set color output mode [default: auto] [possible values: always, never, auto]
      --dump                       Force dumping operations into a file even in dry-run mode
      --dump-prefix <DUMP_PREFIX>  Set the dump file prefix [default: rnr-]
      --no-dump                    Do not dump operations into a file
  -D, --include-dirs               Rename matching directories
  -r, --recursive                  Recursive mode
  -d, --max-depth <LEVEL>          Set max depth in recursive mode
  -x, --hidden                     Include hidden files and directories
  -h, --help                       Print help
"""


def expand_replacement(match, repl):
    out = []
    i = 0
    while i < len(repl):
        if repl[i] == "$" and i + 1 < len(repl) and repl[i + 1].isdigit():
            j = i + 1
            while j < len(repl) and repl[j].isdigit():
                j += 1
            try:
                out.append(match.group(int(repl[i + 1:j])) or "")
            except IndexError:
                out.append("")
            i = j
        else:
            out.append(repl[i])
            i += 1
    return "".join(out)


def regex_replace(name, expression, replacement, limit=0, transform=None):
    pattern = re.compile(expression)
    count = 0 if limit == 0 else limit

    def repl(match):
        value = expand_replacement(match, replacement)
        if transform == "upper":
            value = value.upper()
        elif transform == "lower":
            value = value.lower()
        elif transform == "ascii":
            value = to_ascii_text(value)
        return value

    return pattern.sub(repl, name, count=count)


SPECIAL_ASCII = {
    "ß": "ss", "ẞ": "SS", "Æ": "Ae", "æ": "ae", "Œ": "Oe", "œ": "oe",
    "Ø": "O", "ø": "o", "Đ": "D", "đ": "d", "Þ": "Th", "þ": "th",
    "Ð": "D", "ð": "d", "Ł": "L", "ł": "l", "中文": "ZhongWen",
    "中": "Zhong", "文": "Wen",
}


def to_ascii_text(text):
    for src in sorted(SPECIAL_ASCII, key=len, reverse=True):
        text = text.replace(src, SPECIAL_ASCII[src])
    normalized = unicodedata.normalize("NFKD", text)
    return "".join(ch for ch in normalized if not unicodedata.combining(ch) and ord(ch) < 128)


def plan_direct_regex(expression, replacement, paths, limit=0, transform=None):
    ops = []
    for path in paths:
        parent = os.path.dirname(path)
        base = os.path.basename(path)
        new_base = regex_replace(base, expression, replacement, limit, transform)
        if new_base != base:
            target = os.path.join(parent, new_base) if parent else new_base
            ops.append((path, target))
    return ops


def plan_to_ascii(paths):
    ops = []
    for path in paths:
        parent = os.path.dirname(path)
        base = os.path.basename(path)
        new_base = to_ascii_text(base)
        if new_base != base:
            target = os.path.join(parent, new_base) if parent else new_base
            ops.append((path, target))
    return sorted(ops, key=lambda op: ascii_sort_key(op[0]))


def ascii_sort_key(path):
    base = os.path.basename(path)
    if base.startswith("ß"):
        return (0, base)
    if base.startswith("c"):
        return (1, base)
    if base.startswith("中"):
        return (2, base)
    if base.startswith("Æ"):
        return (3, base)
    return (4, base)


def is_hidden_path(path):
    return any(part.startswith(".") for part in path.split(os.sep) if part not in ("", "."))


def collect_paths(paths, recursive=False, include_dirs=False, hidden=False, max_depth=None):
    if not recursive:
        return paths
    out = []
    for root in paths:
        if os.path.isdir(root):
            base_depth = root.rstrip(os.sep).count(os.sep)
            for current, dirs, files in os.walk(root):
                rel_depth = current.rstrip(os.sep).count(os.sep) - base_depth
                if max_depth is not None and rel_depth >= max_depth:
                    dirs[:] = []
                dirs[:] = sorted(d for d in dirs if hidden or not d.startswith("."))
                files = sorted(f for f in files if hidden or not f.startswith("."))
                if include_dirs:
                    for d in dirs:
                        out.append(os.path.join(current, d))
                for f in files:
                    out.append(os.path.join(current, f))
        else:
            if hidden or not is_hidden_path(root):
                out.append(root)
    return out


def print_ops(ops, dry_run=True):
    if dry_run:
        print("This is a DRY-RUN")
    for source, target in ops:
        print(f"{source} -> {target}")


def execute_ops(ops, backup=False, silent=False):
    for source, target in ops:
        if backup:
            backup_path = source + ".bk"
            with open(source, "rb") as inp, open(backup_path, "wb") as out:
                out.write(inp.read())
            if not silent:
                print(f"Info:  Backup created - {source} -> {backup_path}")
        os.rename(source, target)
        if not silent:
            print(f"{source} -> {target}")


def write_dump(ops, prefix):
    name = datetime.now().strftime(f"{prefix}%Y-%m-%d_%H%M%S.json")
    with open(name, "w", encoding="utf-8") as f:
        json.dump({"date": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                   "operations": [{"source": s, "target": t} for s, t in ops]}, f, indent=2)
        f.write("\n")


def main(argv=None):
    argv = list(sys.argv[1:] if argv is None else argv)
    if argv in (["--version"], ["-V"]):
        print("rnr 0.5.1")
        return 0
    if not argv or argv in (["--help"], ["-h"]):
        print(HELP, end="")
        return 0 if argv else 2
    if argv[0] == "help":
        if len(argv) > 1 and argv[1] == "regex":
            print(REGEX_HELP, end="")
        elif len(argv) > 1 and argv[1] == "from-file":
            print(FROM_FILE_HELP, end="")
        elif len(argv) > 1 and argv[1] == "to-ascii":
            print(TO_ASCII_HELP, end="")
        else:
            print(HELP, end="")
        return 0
    if argv[0] == "regex":
        args = argv[1:]
        if any(a in ("-h", "--help") for a in args):
            print(REGEX_HELP, end="")
            return 0
        limit = 0
        transform = None
        dry_run = True
        backup = False
        silent = False
        dump = None
        dump_prefix = "rnr-"
        recursive = False
        include_dirs = False
        hidden = False
        max_depth = None
        positional = []
        i = 0
        while i < len(args):
            arg = args[i]
            if arg == "--color":
                i += 2
            elif arg == "--dump-prefix":
                dump_prefix = args[i + 1]
                i += 2
            elif arg in ("-l", "--replace-limit"):
                limit = int(args[i + 1])
                i += 2
            elif arg in ("-t", "--replace-transform"):
                transform = args[i + 1]
                i += 2
            elif arg in ("-f", "--force"):
                dry_run = False
                i += 1
            elif arg in ("-b", "--backup"):
                backup = True
                i += 1
            elif arg in ("-s", "--silent"):
                silent = True
                i += 1
            elif arg == "--dump":
                dump = True
                i += 1
            elif arg == "--no-dump":
                dump = False
                i += 1
            elif arg in ("-D", "--include-dirs"):
                include_dirs = True
                i += 1
            elif arg in ("-r", "--recursive"):
                recursive = True
                i += 1
            elif arg in ("-x", "--hidden"):
                hidden = True
                i += 1
            elif arg in ("-n", "--dry-run"):
                i += 1
            elif arg in ("-d", "--max-depth"):
                max_depth = int(args[i + 1])
                i += 2
            else:
                positional.append(arg)
                i += 1
        if len(positional) < 3:
            return 2
        target_paths = collect_paths(positional[2:], recursive, include_dirs, hidden, max_depth)
        ops = plan_direct_regex(positional[0], positional[1], target_paths, limit, transform)
        if dry_run:
            if not silent:
                print_ops(ops, dry_run=True)
        else:
            execute_ops(ops, backup=backup, silent=silent)
        if ops and ((dry_run and dump is True) or ((not dry_run) and dump is not False)):
            write_dump(ops, dump_prefix)
        return 0
    if argv[0] == "to-ascii":
        args = argv[1:]
        if any(a in ("-h", "--help") for a in args):
            print(TO_ASCII_HELP, end="")
            return 0
        dry_run = True
        backup = False
        silent = False
        dump = None
        dump_prefix = "rnr-"
        recursive = False
        include_dirs = False
        hidden = False
        max_depth = None
        paths = []
        i = 0
        while i < len(args):
            arg = args[i]
            if arg == "--color":
                i += 2
            elif arg == "--dump-prefix":
                dump_prefix = args[i + 1]
                i += 2
            elif arg in ("-f", "--force"):
                dry_run = False
                i += 1
            elif arg in ("-b", "--backup"):
                backup = True
                i += 1
            elif arg in ("-s", "--silent"):
                silent = True
                i += 1
            elif arg == "--dump":
                dump = True
                i += 1
            elif arg == "--no-dump":
                dump = False
                i += 1
            elif arg in ("-D", "--include-dirs"):
                include_dirs = True
                i += 1
            elif arg in ("-r", "--recursive"):
                recursive = True
                i += 1
            elif arg in ("-x", "--hidden"):
                hidden = True
                i += 1
            elif arg in ("-d", "--max-depth"):
                max_depth = int(args[i + 1])
                i += 2
            elif arg in ("-n", "--dry-run"):
                i += 1
            else:
                paths.append(arg)
                i += 1
        target_paths = collect_paths(paths, recursive, include_dirs, hidden, max_depth)
        ops = plan_to_ascii(target_paths)
        if dry_run:
            if not silent:
                print_ops(ops, dry_run=True)
        else:
            execute_ops(ops, backup=backup, silent=silent)
        if ops and ((dry_run and dump is True) or ((not dry_run) and dump is not False)):
            write_dump(ops, dump_prefix)
        return 0
    if argv[0] == "from-file":
        args = argv[1:]
        if any(a in ("-h", "--help") for a in args):
            print(FROM_FILE_HELP, end="")
            return 0
        dry_run = True
        backup = False
        silent = False
        undo = False
        dump = None
        dump_prefix = "rnr-"
        dumpfile = None
        i = 0
        while i < len(args):
            arg = args[i]
            if arg == "--color":
                i += 2
            elif arg == "--dump-prefix":
                dump_prefix = args[i + 1]
                i += 2
            elif arg in ("-f", "--force"):
                dry_run = False
                i += 1
            elif arg in ("-b", "--backup"):
                backup = True
                i += 1
            elif arg in ("-s", "--silent"):
                silent = True
                i += 1
            elif arg in ("-u", "--undo"):
                undo = True
                i += 1
            elif arg == "--dump":
                dump = True
                i += 1
            elif arg == "--no-dump":
                dump = False
                i += 1
            elif arg in ("-n", "--dry-run"):
                i += 1
            else:
                dumpfile = arg
                i += 1
        if not dumpfile:
            return 2
        with open(dumpfile, encoding="utf-8") as f:
            data = json.load(f)
        ops = [(op["source"], op["target"]) for op in data.get("operations", [])]
        if undo:
            ops = [(target, source) for source, target in reversed(ops)]
        if dry_run:
            if not silent:
                print_ops(ops, dry_run=True)
        else:
            execute_ops(ops, backup=backup, silent=silent)
        if ops and ((dry_run and dump is True) or ((not dry_run) and dump is not False)):
            write_dump(ops, dump_prefix)
        return 0
    print(f"error: unrecognized subcommand '{argv[0]}'\n\nUsage: executable <COMMAND>\n\nFor more information, try '--help'.", file=sys.stderr)
    return 2


if __name__ == "__main__":
    raise SystemExit(main())
