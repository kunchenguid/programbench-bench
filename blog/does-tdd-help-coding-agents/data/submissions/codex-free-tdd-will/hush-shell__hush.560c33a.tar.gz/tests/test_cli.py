import os
import subprocess
import tempfile
import unittest


ROOT = os.path.dirname(os.path.dirname(__file__))
EXE = os.environ.get("HUSH_IMPL", os.path.join(ROOT, "executable"))


class HushCliTests(unittest.TestCase):
    def run_hush(self, args, input_text=None):
        return subprocess.run(
            [EXE] + args,
            input=input_text,
            text=True,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            check=False,
        )

    def script(self, source, *args):
        with tempfile.NamedTemporaryFile("w", delete=False, suffix=".hsh") as f:
            f.write(source)
            path = f.name
        try:
            return self.run_hush([path, *args])
        finally:
            os.unlink(path)

    def test_help_and_version_match_public_cli(self):
        help_result = self.run_hush(["--help"])
        self.assertEqual(help_result.returncode, 0)
        self.assertIn("Hush 0.1.4", help_result.stdout)
        self.assertIn("USAGE:\n    executable [FLAGS] [arguments]...", help_result.stdout)

        version_result = self.run_hush(["--version"])
        self.assertEqual(version_result.returncode, 0)
        self.assertEqual(version_result.stdout, "Hush 0.1.4\n")

    def test_command_block_executes_external_commands(self):
        result = self.script("{ echo hi; echo bye; }\n")
        self.assertEqual(result.returncode, 0)
        self.assertEqual(result.stdout, "hi\nbye\n")
        self.assertEqual(result.stderr, "")

    def test_lex_prints_source_positions_and_normalized_numbers(self):
        result = self.script("let a = 89e10\nlet b = 1.2e3\n", "--lex")
        self.assertEqual(result.returncode, 0)
        self.assertEqual(
            result.stdout,
            "--------------------------------------------------\n"
            f"{result.args[1]} (line 1, column 0):\tlet\n"
            f"{result.args[1]} (line 1, column 4):\ta\n"
            f"{result.args[1]} (line 1, column 6):\t=\n"
            f"{result.args[1]} (line 1, column 8):\t890000000000\n"
            f"{result.args[1]} (line 2, column 0):\tlet\n"
            f"{result.args[1]} (line 2, column 4):\tb\n"
            f"{result.args[1]} (line 2, column 6):\t=\n"
            f"{result.args[1]} (line 2, column 8):\t1200\n"
            "--------------------------------------------------\n",
        )

    def test_check_reports_undeclared_variable(self):
        result = self.script("print 123\n", "--check")
        self.assertEqual(result.returncode, 2)
        self.assertEqual(result.stdout, "")
        self.assertEqual(
            result.stderr,
            f"Error: {result.args[1]} (line 1, column 0) - undeclared variable 'print'\n",
        )

    def test_command_block_expands_hush_variables(self):
        result = self.script('let x = "hi there"\n{ echo $x; }\n')
        self.assertEqual(result.returncode, 0)
        self.assertEqual(result.stdout, "hi there\n")
        self.assertEqual(result.stderr, "")


if __name__ == "__main__":
    unittest.main()
