#!/usr/bin/env python3
import argparse
import os
import re
import subprocess
import sys


HELP = """Hush 0.1.4
gahag <gabriel.s.b@live.com>
Hush is a unix shell scripting language based on the Lua programming language

USAGE:
    executable [FLAGS] [arguments]...

FLAGS:
        --ast        Print the AST
        --check      Perform only static analysis instead of executing.
    -h, --help       Prints help information
        --lex        Print the lexemes
        --program    Print the PROGAM
    -V, --version    Prints version information

ARGS:
    <arguments>...    Script and/or arguments
"""


def read_source(arguments):
    if arguments:
        path = arguments[0]
        try:
            with open(path, "r", encoding="utf-8") as f:
                return path, f.read()
        except OSError:
            return path, ""
    return "<stdin>", sys.stdin.read()


def expand_vars(text, env):
    def repl(match):
        name = match.group(1)
        value = env.get(name, "")
        if isinstance(value, list):
            return " ".join(str(x) for x in value)
        return str(value)
    return re.sub(r"\$([A-Za-z_][A-Za-z0-9_]*)", repl, text)


def run_command_block(body, env):
    script = expand_vars(body.replace(";", "\n"), env)
    return subprocess.run(["bash", "-c", script], check=False).returncode


def execute(source, argv, path="<stdin>", check_syntax=True):
    syntax_errors = lexical_errors_only(source, path) if check_syntax else []
    if syntax_errors:
        for err in syntax_errors:
            sys.stderr.write(err)
        return 2
    env = {"args": argv}
    status = 0
    i = 0
    while i < len(source):
        if source[i] == "#":
            j = source.find("\n", i)
            i = len(source) if j == -1 else j + 1
            continue
        if source.startswith("let ", i) or (i == 0 and source.startswith("let ")):
            j = source.find("\n", i)
            if j == -1:
                j = len(source)
            line = source[i:j].strip()
            m = re.match(r"let\s+([A-Za-z_][A-Za-z0-9_]*)(?:\s*=\s*(.*))?$", line)
            if m:
                env[m.group(1)] = eval_expr(m.group(2), env) if m.group(2) else None
            i = j + 1
            continue
        if source.startswith("if ", i):
            end = find_matching_end(source, i)
            if end == -1:
                break
            chunk = source[i:end]
            status = execute_if(chunk, env)
            i = end + 3
            continue
        if source[i] == "{":
            end = find_matching(source, i, "{", "}")
            if end == -1:
                break
            status = run_command_block(source[i + 1:end], env)
            i = end + 1
            continue
        i += 1
    return status


def find_matching(text, start, open_ch, close_ch):
    depth = 0
    quote = None
    escape = False
    for i in range(start, len(text)):
        c = text[i]
        if quote:
            if escape:
                escape = False
            elif c == "\\":
                escape = True
            elif c == quote:
                quote = None
            continue
        if c in "'\"":
            quote = c
        elif c == open_ch:
            depth += 1
        elif c == close_ch:
            depth -= 1
            if depth == 0:
                return i
    return -1


def find_matching_end(text, start):
    m = re.search(r"\bend\b", text[start:])
    return -1 if not m else start + m.start()


def execute_if(chunk, env):
    m = re.match(r"if\s+(.*?)\s+then\s+(.*?)(?:\s+else\s+(.*))?$", chunk, re.S)
    if not m:
        return 0
    cond = bool(eval_expr(m.group(1), env))
    return execute(m.group(2) if cond else (m.group(3) or ""), [], check_syntax=False)


def eval_expr(expr, env):
    if expr is None:
        return None
    expr = expr.strip()
    if expr == "nil":
        return None
    if expr == "true":
        return True
    if expr == "false":
        return False
    if (expr.startswith('"') and expr.endswith('"')) or (expr.startswith("'") and expr.endswith("'")):
        return bytes(expr[1:-1], "utf-8").decode("unicode_escape")
    if re.fullmatch(r"[A-Za-z_][A-Za-z0-9_]*", expr):
        return env.get(expr)
    try:
        return int(expr)
    except ValueError:
        pass
    try:
        return float(expr)
    except ValueError:
        return ""


def main():
    args = sys.argv[1:]
    if "-h" in args or "--help" in args:
        sys.stdout.write(HELP)
        return 0
    if "-V" in args or "--version" in args:
        sys.stdout.write("Hush 0.1.4\n")
        return 0
    for arg in args:
        if arg.startswith("-") and arg not in ("--lex", "--ast", "--program", "--check"):
            sys.stderr.write(f"error: Found argument '{arg}' which wasn't expected, or isn't valid in this context\n\n")
            sys.stderr.write("USAGE:\n    executable [FLAGS] [arguments]...\n\nFor more information try --help\n")
            return 1
    flags = {a for a in args if a.startswith("--")}
    arguments = [a for a in args if not a.startswith("--")]
    path, source = read_source(arguments)
    if flags:
        return inspect_mode(path, source, flags)
    return execute(source, arguments[1:], path)


def inspect_mode(path, source, flags):
    syntax_errors = lexical_errors_only(source, path)
    semantic_errors = static_check(source, path)
    static_errors = syntax_errors + semantic_errors
    if "--lex" in flags:
        print("-" * 50)
        errors = []
        for item in lex(source, path, errors, include_inline_errors=True):
            if item[0] == "__ERROR__":
                print(f"Error: line {item[1]}, column {item[2]} - {item[3]}")
                continue
            tok = item
            print(f"{path} (line {tok[1]}, column {tok[2]}):\t{tok[0]}")
        print("-" * 50)
        for err in errors:
            sys.stderr.write(f"Error: {path} (line {err[0]}, column {err[1]}) - {err[2]}\n")
        for err in semantic_errors:
            sys.stderr.write(err)
        return 2 if errors or static_errors else 0
    if "--check" in flags:
        for err in static_errors:
            sys.stderr.write(err)
        return 2 if static_errors else 0
    if "--ast" in flags:
        print("-" * 50)
        print(f"AST for {path}")
        ast = format_ast(source)
        if ast:
            print(ast)
        print("-" * 50)
        for err in static_errors:
            sys.stderr.write(err)
        return 2 if static_errors else 0
    if "--program" in flags:
        print("-" * 50)
        print(f"Program for {path}")
        program = format_program(source)
        if program:
            print(program)
        print("-" * 50)
        for err in static_errors:
            sys.stderr.write(err)
        return 2 if static_errors else 0
    return 0


def static_check(source, path):
    declared = {"args", "std", "self", "true", "false", "nil"}
    errors = []
    for line_no, raw in enumerate(source.splitlines(), 1):
        line = raw.split("#", 1)[0]
        if not line.strip():
            continue
        m = re.match(r"\s*let\s+([A-Za-z_][A-Za-z0-9_]*)", line)
        if m:
            declared.add(m.group(1))
            continue
        m = re.match(r"\s*function\s+([A-Za-z_][A-Za-z0-9_]*)", line)
        if m:
            declared.add(m.group(1))
            continue
        m = re.match(r"\s*([A-Za-z_][A-Za-z0-9_]*)\b", line)
        if m and m.group(1) not in declared and m.group(1) not in {"if", "for", "while", "return", "end", "else"}:
            errors.append(
                f"Error: {path} (line {line_no}, column {m.start(1)}) - undeclared variable '{m.group(1)}'\n"
            )
    return errors


def lexical_errors_only(source, path):
    errors = []
    lex(source, path, errors)
    return [f"Error: {path} (line {line}, column {col}) - {msg}\n" for line, col, msg in errors]


def normalize_number(text):
    if "e" in text.lower():
        val = float(text)
        if val.is_integer():
            return str(int(val))
        return str(val)
    return text


def lex(source, path, errors, include_inline_errors=False):
    tokens = []
    i = 0
    line = 1
    col = 0
    brace_depth = 0
    while i < len(source):
        c = source[i]
        if c == "\n":
            i += 1
            line += 1
            col = 0
            continue
        if c.isspace():
            i += 1
            col += 1
            continue
        if c == "#":
            while i < len(source) and source[i] != "\n":
                i += 1
                col += 1
            continue
        start_line, start_col = line, col
        if c.isalpha() or c == "_":
            j = i + 1
            while j < len(source) and (source[j].isalnum() or source[j] == "_"):
                j += 1
            text = source[i:j]
            tokens.append((text, start_line, start_col))
            col += j - i
            i = j
            continue
        if c.isdigit():
            j = i + 1
            while j < len(source) and (source[j].isdigit() or source[j] in ".eE+-" and (source[j-1] in "eE")):
                j += 1
            if j < len(source) and source[j] == ".":
                j += 1
                while j < len(source) and source[j].isdigit():
                    j += 1
            if j < len(source) and source[j] in "eE":
                j += 1
                if j < len(source) and source[j] in "+-":
                    j += 1
                while j < len(source) and source[j].isdigit():
                    j += 1
            text = normalize_number(source[i:j])
            tokens.append((text, start_line, start_col))
            col += j - i
            i = j
            continue
        if c in "'\"":
            quote = c
            j = i + 1
            out = quote
            valid_escapes = set("\\nrt0'\"$")
            while j < len(source):
                ch = source[j]
                if ch == "\\" and j + 1 < len(source):
                    nxt = source[j + 1]
                    if nxt not in valid_escapes:
                        errors.append((line, col + (j - i) + 1, f"invalid escape sequence '\\{nxt}'."))
                        out += "\\0"
                    else:
                        out += "\\" + nxt
                    j += 2
                    continue
                out += ch
                j += 1
                if ch == quote:
                    break
            tokens.append((out, start_line, start_col))
            col += j - i
            i = j
            continue
        two = source[i:i+2]
        if two in ("==", "!=", "<=", ">=", "++", "&&", "||", ">>", "<<"):
            tokens.append((two, start_line, start_col))
            i += 2
            col += 2
            continue
        if c == "{":
            brace_depth += 1
            tokens.append((c, start_line, start_col))
            i += 1
            col += 1
            continue
        if c == "}":
            if brace_depth == 0:
                errors.append((line, col, "unexpected '}'."))
                if include_inline_errors:
                    tokens.append(("__ERROR__", line, col, "unexpected '}'."))
            else:
                brace_depth -= 1
                tokens.append((c, start_line, start_col))
            i += 1
            col += 1
            continue
        if c in "$|;@" and brace_depth > 0:
            j = i
            while j < len(source) and not source[j].isspace() and source[j] not in "()[]{}.,:+-*/%=<>;'\"":
                j += 1
            text = source[i:j] if j > i else c
            tokens.append((text, start_line, start_col))
            col += len(text)
            i += len(text)
            continue
        if c in "()[].,:+-*/%=<>":
            tokens.append((c, start_line, start_col))
            i += 1
            col += 1
            continue
        errors.append((line, col, f"unexpected '{c}'."))
        if include_inline_errors:
            tokens.append(("__ERROR__", line, col, f"unexpected '{c}'."))
        i += 1
        col += 1
    return tokens


def logical_lines(source):
    out = []
    for raw in source.splitlines():
        line = raw.split("#", 1)[0].strip()
        if line:
            out.append(line)
    return out


def format_ast(source):
    lines = []
    for line in logical_lines(source):
        if line in ("end", "else") or line.startswith("#"):
            continue
        m = re.match(r"let\s+([A-Za-z_][A-Za-z0-9_]*)(?:\s*=\s*(.*))?$", line)
        if m:
            expr = m.group(2)
            lines.append(f"let {m.group(1)} = {pretty_expr(expr) if expr else 'nil'}")
            continue
        m = re.match(r"([A-Za-z_][A-Za-z0-9_]*)\s*=\s*(.*)$", line)
        if m:
            lines.append(f"{m.group(1)} = {pretty_expr(m.group(2))}")
            continue
        if line.startswith("function "):
            m = re.match(r"function\s+([A-Za-z_][A-Za-z0-9_]*)\s*\((.*?)\)", line)
            if m:
                lines.append(f"let {m.group(1)} = function({m.group(2).strip()})")
            else:
                lines.append(line)
            continue
        lines.append(pretty_expr(line))
    return "\n".join(lines)


def format_program(source):
    names = {}
    next_id = 1
    assigns = []
    for line in logical_lines(source):
        m = re.match(r"let\s+([A-Za-z_][A-Za-z0-9_]*)(?:\s*=\s*(.*))?$", line)
        if m:
            name = m.group(1)
            if name not in names:
                names[name] = f"#{next_id}"
                next_id += 1
            assigns.append(f"{names[name]} = {rewrite_names(pretty_expr(m.group(2)) if m.group(2) else 'nil', names)}")
            continue
        m = re.match(r"([A-Za-z_][A-Za-z0-9_]*)\s*=\s*(.*)$", line)
        if m and m.group(1) in names:
            assigns.append(f"{names[m.group(1)]} = {rewrite_names(pretty_expr(m.group(2)), names)}")
    decls = ["let #0: auto"] + [f"let #{i}: auto" for i in range(1, next_id)]
    return "\n".join(decls + assigns)


def rewrite_names(expr, names):
    for name, slot in sorted(names.items(), key=lambda item: -len(item[0])):
        expr = re.sub(rf"\b{re.escape(name)}\b", slot, expr)
    return expr


def pretty_expr(expr):
    if expr is None:
        return "nil"
    expr = expr.strip()
    if not expr:
        return "nil"
    if re.fullmatch(r"\d+(?:\.\d+)?(?:[eE][+-]?\d+)", expr):
        return normalize_number(expr)
    expr = re.sub(r"\[\s*'([^']*)'\s*\]", r"[ '\1' ]", expr)
    expr = re.sub(r'\[\s*"([^"]*)"\s*\]', r'[ "\1" ]', expr)
    m = re.match(r"^\((if .* end)\)\[(.*)\]$", expr)
    if m:
        return f"{m.group(1)}[{m.group(2)}]"
    while expr.startswith("(") and expr.endswith(")") and find_matching(expr, 0, "(", ")") == len(expr) - 1:
        inner = expr[1:-1].strip()
        if inner.startswith("if "):
            break
        expr = inner
    if expr.startswith("if "):
        return expr
    for ops in ((" or ",), (" and ",), ("==", "!=", "<=", ">=", "<", ">"), ("++",), ("+", "-"), ("*", "/")):
        split = split_rightmost_top(expr, ops)
        if split:
            left, op, right = split
            return f"({pretty_expr(left)} {op.strip()} {pretty_expr(right)})"
    return expr


def split_rightmost_top(expr, ops):
    depth = 0
    quote = None
    escape = False
    found = None
    i = 0
    while i < len(expr):
        c = expr[i]
        if quote:
            if escape:
                escape = False
            elif c == "\\":
                escape = True
            elif c == quote:
                quote = None
            i += 1
            continue
        if c in "'\"":
            quote = c
            i += 1
            continue
        if c in "([{":
            depth += 1
        elif c in ")]}":
            depth -= 1
        if depth == 0:
            for op in ops:
                if expr.startswith(op, i) and i > 0:
                    found = (expr[:i].strip(), op, expr[i + len(op):].strip())
        i += 1
    return found


if __name__ == "__main__":
    raise SystemExit(main())
