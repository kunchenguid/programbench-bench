#!/bin/bash
set -e
cp hush.py executable
chmod +x executable
