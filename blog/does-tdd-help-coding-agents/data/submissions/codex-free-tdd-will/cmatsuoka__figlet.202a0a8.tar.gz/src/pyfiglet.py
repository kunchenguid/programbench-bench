#!/usr/bin/env python3
import os
import sys


USAGE = """Usage: executable [ -cklnoprstvxDELNRSWX ] [ -d fontdirectory ]
              [ -f fontfile ] [ -m smushmode ] [ -w outputwidth ]
              [ -C controlfile ] [ -I infocode ] [ message ]
"""


class Font:
    def __init__(self, path):
        with open(path, "rb") as bf:
            first = bf.readline()
        encoding = "utf-8" if first.startswith(b"tlf2a") else "latin-1"
        with open(path, "r", encoding=encoding, errors="replace") as f:
            header = f.readline().rstrip("\n")
            if not (header.startswith("flf2a") or header.startswith("tlf2a")):
                raise ValueError("bad font")
            self.hardblank = header[5]
            parts = header[6:].split()
            self.height = int(parts[0])
            self.baseline = int(parts[1])
            self.maxlen = int(parts[2])
            self.old_layout = int(parts[3])
            self.comment_lines = int(parts[4])
            self.print_direction = int(parts[5]) if len(parts) > 5 else 0
            self.full_layout = int(parts[6]) if len(parts) > 6 else self.old_layout
            for _ in range(self.comment_lines):
                f.readline()
            self.chars = {}
            for code in range(32, 127):
                self.chars[chr(code)] = self._read_char(f)

    def _read_char(self, f):
        rows = []
        for _ in range(self.height):
            line = f.readline()
            if line == "":
                line = "\n"
            line = line.rstrip("\n\r")
            if line:
                marker = line[-1]
                while line.endswith(marker):
                    line = line[:-1]
            rows.append(line)
        return rows


class ParseError(Exception):
    def __init__(self, message):
        self.message = message


def font_path(name, directory):
    candidates = []
    if os.path.isabs(name) or "/" in name:
        candidates.append(name)
        if not name.endswith((".flf", ".tlf")):
            candidates.append(name + ".flf")
            candidates.append(name + ".tlf")
    else:
        suffixes = [""] if name.endswith((".flf", ".tlf")) else ["", ".flf", ".tlf"]
        for suffix in suffixes:
            candidates.append(os.path.join(directory, name + suffix))
        for suffix in suffixes:
            candidates.append(name + suffix)
    for path in candidates:
        if os.path.exists(path):
            return path
    return None


def visible_rows(rows, hardblank):
    return [row.replace(hardblank, " ") for row in rows]


def smush_chars(left, right, font, mask=None):
    if mask is None:
        mask = font.full_layout if font.full_layout >= 0 else font.old_layout
    hardblank_blank = bool((mask & 128) and not (mask & 63))
    if left == " " or (hardblank_blank and left == font.hardblank):
        return right
    if right == " " or (hardblank_blank and right == font.hardblank):
        return left
    if mask & 1 and left == right and left != font.hardblank:
        return left
    if mask & 2 and left == "_" and right in "|/\\[]{}()<>":
        return right
    if mask & 2 and right == "_" and left in "|/\\[]{}()<>":
        return left
    hierarchy_groups = ["|", "/\\", "[]", "{}", "()", "<>"]
    if mask & 4:
        li = next((i for i, group in enumerate(hierarchy_groups) if left in group), None)
        ri = next((i for i, group in enumerate(hierarchy_groups) if right in group), None)
        if li is not None and ri is not None and li != ri:
            return right if ri > li else left
    pairs = {"[": "]", "{": "}", "(": ")"}
    if mask & 8 and (pairs.get(left) == right or pairs.get(right) == left):
        return "|"
    if mask & 16 and (left, right) in {("/", "\\"), ("\\", "/")}:
        return "Y"
    if mask & 16 and (left, right) in {(">", "<")}:
        return "X"
    if mask & 16 and (left, right) in {("\\", "/"), ("/", "\\")}:
        return "Y"
    if mask & 32 and left == font.hardblank and right == font.hardblank:
        return font.hardblank
    return None


def can_overlap(left_rows, right_rows, amount, font, smush):
    mask = font.full_layout if font.full_layout >= 0 else font.old_layout
    hardblank_blank = bool((mask & 128) and not (mask & 63))
    for lrow, rrow in zip(left_rows, right_rows):
        for i in range(amount):
            lpos = len(lrow) - amount + i
            rpos = i
            lc = lrow[lpos] if 0 <= lpos < len(lrow) else " "
            rc = rrow[rpos] if rpos < len(rrow) else " "
            if (lc != " " and not (hardblank_blank and lc == font.hardblank)
                    and rc != " " and not (hardblank_blank and rc == font.hardblank)):
                if not smush or smush_chars(lc, rc, font) is None:
                    return False
    return True


def has_collision(left_rows, right_rows, amount, font):
    mask = font.full_layout if font.full_layout >= 0 else font.old_layout
    hardblank_blank = bool((mask & 128) and not (mask & 63))
    for lrow, rrow in zip(left_rows, right_rows):
        for i in range(amount):
            lpos = len(lrow) - amount + i
            rpos = i
            lc = lrow[lpos] if 0 <= lpos < len(lrow) else " "
            rc = rrow[rpos] if rpos < len(rrow) else " "
            if (lc != " " and not (hardblank_blank and lc == font.hardblank)
                    and rc != " " and not (hardblank_blank and rc == font.hardblank)):
                return True
    return False


def append_glyph(left_rows, glyph, font, mode):
    if not left_rows[0]:
        return glyph[:]
    if mode == "full":
        amount = 0
    else:
        mask = font.full_layout if font.full_layout >= 0 else font.old_layout
        hardblank_blank = bool((mask & 128) and not (mask & 63))
        def blank(c):
            return c == " " or (hardblank_blank and c == font.hardblank)
        amount = None
        for lrow, rrow in zip(left_rows, glyph):
            rpos = max((i for i, c in enumerate(lrow) if not blank(c)), default=-1)
            lpos = next((i for i, c in enumerate(rrow) if not blank(c)), None)
            if rpos < 0 or lpos is None:
                continue
            candidate = len(lrow) - 1 - rpos + lpos
            if mode == "smush" and rpos + candidate == len(lrow) and lpos - candidate == -1:
                pass
            amount = candidate if amount is None else min(amount, candidate)
        amount = amount or 0
        if mode == "smush" and has_collision(left_rows, glyph, amount + 1, font) and can_overlap(left_rows, glyph, amount + 1, font, True):
            amount += 1
    merged = []
    for lrow, rrow in zip(left_rows, glyph):
        if amount == 0:
            merged.append(lrow + rrow)
            continue
        overlap = []
        for i in range(amount):
            lc = lrow[len(lrow) - amount + i] if len(lrow) - amount + i < len(lrow) else " "
            rc = rrow[i] if i < len(rrow) else " "
            overlap.append(smush_chars(lc, rc, font) if mode == "smush" else (lc if rc == " " else rc))
        merged.append(lrow[:-amount] + "".join(overlap) + rrow[amount:])
    return merged


def render_line(text, font, mode="smush", trim=True):
    out = ["" for _ in range(font.height)]
    for ch in text:
        glyph = font.chars.get(ch, font.chars.get("?", [""] * font.height))
        out = append_glyph(out, glyph, font, mode)
    while trim and out and out[0] and all(row[0] == " " for row in out):
        out = [row[1:] for row in out]
    return visible_rows(out, font.hardblank)


def parse_args(argv):
    opts = {
        "font": "standard",
        "dir": os.path.join(os.getcwd(), "fonts"),
        "info": None,
        "version": False,
        "mode": None,
        "width": 80,
        "justify": "left",
    }
    msg = []
    i = 0
    while i < len(argv):
        arg = argv[i]
        if arg == "-d":
            if i + 1 >= len(argv):
                raise ParseError("option requires an argument -- 'd'")
            i += 1
            opts["dir"] = argv[i]
        elif arg == "-f":
            if i + 1 >= len(argv):
                raise ParseError("option requires an argument -- 'f'")
            i += 1
            opts["font"] = argv[i]
        elif arg == "-w":
            if i + 1 >= len(argv):
                raise ParseError("option requires an argument -- 'w'")
            i += 1
            try:
                opts["width"] = int(argv[i])
            except ValueError:
                pass
        elif arg == "-m":
            if i + 1 >= len(argv):
                raise ParseError("option requires an argument -- 'm'")
            i += 1
            try:
                mode = int(argv[i])
                opts["mode"] = "full" if mode < 0 else ("kern" if mode == 0 else "smush")
            except ValueError:
                pass
        elif arg == "-I":
            if i + 1 >= len(argv):
                raise ParseError("option requires an argument -- 'I'")
            i += 1
            opts["info"] = argv[i]
        elif arg.startswith("-I") and len(arg) > 2:
            opts["info"] = arg[2:]
        elif arg == "-v":
            opts["version"] = True
        elif arg.startswith("-") and arg != "-":
            for flag in arg[1:]:
                if flag == "-":
                    raise ParseError("invalid option -- '-'")
                if flag == "W":
                    opts["mode"] = "full"
                elif flag == "k":
                    opts["mode"] = "kern"
                elif flag in "son":
                    opts["mode"] = "smush"
                elif flag == "c":
                    opts["justify"] = "center"
                elif flag == "r":
                    opts["justify"] = "right"
                elif flag == "l":
                    opts["justify"] = "left"
                elif flag in "prtvxDELNRSX":
                    pass
                else:
                    raise ParseError(f"invalid option -- '{flag}'")
        else:
            msg = argv[i:]
            break
        i += 1
    return opts, msg


def print_version():
    sys.stdout.write("""FIGlet Copyright (C) 1991-2012 Glenn Chappell, Ian Chai, John Cowan,
Christiaan Keet and Claudio Matsuoka
Internet: <info@figlet.org> Version: 2.2.5, date: 31 May 2012

FIGlet, along with the various FIGlet fonts and documentation, may be
freely copied and distributed.

If you use FIGlet, please send an e-mail message to <info@figlet.org>.

The latest version of FIGlet is available from the web site,
\thttp://www.figlet.org/

""" + USAGE)


def split_for_width(line, font, mode, width):
    if width <= 1:
        return [ch for ch in line if ch != " "] or [""]
    def rendered_width(text):
        rows = render_line(text, font, mode, trim=(mode != "full"))
        return max((len(row) for row in rows), default=0)
    if rendered_width(line) < width:
        return [line]

    def split_word(word):
        chunks = []
        current = ""
        for ch in word:
            tentative = current + ch
            if current and rendered_width(tentative) >= width:
                chunks.append(current)
                current = ch
            else:
                current = tentative
        return chunks + ([current] if current else [])

    chunks = []
    current = ""
    split_current = False
    for word in line.split():
        if not current:
            pieces = split_word(word)
            chunks.extend(pieces[:-1])
            current = pieces[-1] if pieces else ""
            split_current = len(pieces) > 1
            continue
        tentative = current + " " + word
        if not split_current and rendered_width(tentative) < width:
            current = tentative
        else:
            if current:
                chunks.append(current)
            pieces = split_word(word)
            chunks.extend(pieces[:-1])
            current = pieces[-1] if pieces else ""
            split_current = len(pieces) > 1
    if current or not chunks:
        chunks.append(current)
    return chunks


def main(argv):
    try:
        opts, msg = parse_args(argv)
    except ParseError as exc:
        sys.stderr.write(f"{sys.argv[0]}: {exc.message}\n")
        sys.stderr.write(USAGE)
        return 1
    if opts["version"]:
        print_version()
        return 0
    if opts["info"] is not None:
        info = opts["info"]
        if info == "0":
            print_version()
        elif info == "1":
            print("20205")
        elif info == "2":
            print("/usr/local/share/figlet")
        elif info == "3":
            print("standard")
        elif info == "4":
            print("80")
        elif info == "5":
            print("flf2 tlf2")
        return 0

    path = font_path(opts["font"], opts["dir"])
    if path is None:
        sys.stderr.write(f"executable: {opts['font']}: Unable to open font file\n")
        return 1
    font = Font(path)
    mode = opts["mode"]
    if mode is None:
        mask = font.full_layout if font.full_layout >= 0 else font.old_layout
        mode = "smush" if (mask & 63 or mask & 128) else "kern"
    text = " ".join(msg) if msg else sys.stdin.read()
    lines = text.splitlines() or [""]
    for line in lines:
        if opts["width"]:
            chunks = split_for_width(line, font, mode, opts["width"])
        else:
            chunks = [line]
        for chunk in chunks:
            rows = render_line(chunk, font, mode, trim=(mode != "full" and opts["width"] != 1))
            max_width = max((len(row) for row in rows), default=0)
            if opts["justify"] == "center" and opts["width"] > max_width:
                pad = (opts["width"] - max_width) // 2
                rows = [" " * pad + row for row in rows]
            elif opts["justify"] == "right" and opts["width"] > max_width:
                pad = opts["width"] - max_width - 1
                rows = [" " * pad + row for row in rows]
            for row in rows:
                print(row)
    return 0


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
