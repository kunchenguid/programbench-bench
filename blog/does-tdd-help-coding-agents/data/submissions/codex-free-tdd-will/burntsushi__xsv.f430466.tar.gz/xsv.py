#!/usr/bin/env python3
import math
import os
import random
import re
import shutil
import statistics
import sys
from collections import Counter, defaultdict


COMMANDS = [
    "cat", "count", "fixlengths", "flatten", "fmt", "frequency", "headers",
    "index", "input", "join", "partition", "sample", "reverse", "search",
    "select", "slice", "sort", "split", "stats", "table",
]


def parse_csv(text, delim=",", quote='"', escape=None, quoting=True):
    rows, row, field = [], [], []
    i, n, inq = 0, len(text), False
    while i < n:
        ch = text[i]
        if quoting and inq:
            if escape and ch == escape and i + 1 < n:
                field.append(text[i + 1]); i += 2; continue
            if ch == quote:
                if i + 1 < n and text[i + 1] == quote and not escape:
                    field.append(quote); i += 2; continue
                inq = False; i += 1; continue
            field.append(ch); i += 1; continue
        if quoting and ch == quote and not field:
            inq = True; i += 1; continue
        if ch == delim:
            row.append("".join(field)); field = []; i += 1; continue
        if ch == "\n":
            row.append("".join(field)); field = []; rows.append(row); row = []; i += 1; continue
        if ch == "\r":
            row.append("".join(field)); field = []; rows.append(row); row = []
            if i + 1 < n and text[i + 1] == "\n": i += 2
            else: i += 1
            continue
        field.append(ch); i += 1
    if field or row:
        row.append("".join(field)); rows.append(row)
    return rows


def csv_quote(s, delim=",", quote='"', quote_always=False):
    s = "" if s is None else str(s)
    need = quote_always or any(c in s for c in (delim, quote, "\n", "\r"))
    if need:
        return quote + s.replace(quote, quote + quote) + quote
    return s


def write_csv(rows, delim=",", term="\n", quote='"', quote_always=False):
    return "".join(delim.join(csv_quote(c, delim, quote, quote_always) for c in r) + term for r in rows)


def take_opt(args, names, default=None, has_value=True):
    for i, a in enumerate(list(args)):
        if a in names:
            args.pop(i)
            if has_value:
                return args.pop(i)
            return True
        for nm in names:
            if has_value and a.startswith(nm + "="):
                args.pop(i); return a.split("=", 1)[1]
    return default


def common(args):
    args = list(args)
    out = take_opt(args, ["-o", "--output"])
    no_headers = bool(take_opt(args, ["-n", "--no-headers"], False, False))
    delim = take_opt(args, ["-d", "--delimiter"], ",")
    if delim == r"\t": delim = "\t"
    return args, out, no_headers, delim


def read_input(args, delim=",", quote='"', escape=None, quoting=True):
    path = args[-1] if args and not args[-1].startswith("-") else None
    if path and os.path.exists(path):
        text = open(path, "r", encoding="utf-8", newline="").read()
        args.pop()
    else:
        text = sys.stdin.read()
    return parse_csv(text, delim, quote, escape, quoting), path


def emit(text, out=None):
    if out:
        with open(out, "w", encoding="utf-8", newline="") as f: f.write(text)
    else:
        sys.stdout.write(text)


def split_header(rows, no_headers):
    if not rows: return [], []
    return ([], rows) if no_headers else (rows[0], rows[1:])


def col_index(tok, header, width):
    tok = tok.strip()
    m = re.match(r"^(.*)\[(\d+)\]$", tok)
    nth = 1
    if m:
        tok, nth = m.group(1), int(m.group(2))
    if tok.isdigit():
        return max(0, min(width - 1, int(tok) - 1))
    if header:
        seen = 0
        for i, h in enumerate(header):
            if h == tok:
                seen += 1
                if seen == nth: return i
    return 0


def parse_selection(sel, header, width):
    invert = sel.startswith("!")
    if invert: sel = sel[1:]
    parts, cur, q = [], [], False
    for ch in sel:
        if ch == '"':
            q = not q; continue
        if ch == "," and not q:
            parts.append("".join(cur)); cur = []
        else:
            cur.append(ch)
    parts.append("".join(cur))
    idxs = []
    for p in [p.strip() for p in parts if p.strip()]:
        m = re.match(r"^(.+?)-(.*?)$", p)
        if m and not p.startswith("-"):
            a, b = m.group(1), m.group(2)
            start = col_index(a, header, width)
            end = width - 1 if b == "" else col_index(b, header, width)
            step = 1 if end >= start else -1
            idxs.extend(range(start, end + step, step))
        else:
            idxs.append(col_index(p, header, width))
    if invert:
        omit = set(idxs)
        return [i for i in range(width) if i not in omit]
    return idxs


def project(rows, idxs):
    return [[r[i] if i < len(r) else "" for i in idxs] for r in rows]


def cmd_count(args):
    args, _, no_headers, delim = common(args)
    rows, _ = read_input(args, delim)
    n = len(rows) - (0 if no_headers or not rows else 1)
    emit(f"{max(0, n)}\n")


def cmd_headers(args):
    args, _, _, delim = common(args)
    just = bool(take_opt(args, ["-j", "--just-names"], False, False))
    inter = bool(take_opt(args, ["--intersect"], False, False))
    paths = [a for a in args if not a.startswith("-")]
    heads = []
    if paths:
        for p in paths:
            rows = parse_csv(open(p, encoding="utf-8", newline="").read(), delim)
            heads.append(rows[0] if rows else [])
    else:
        rows, _ = read_input(args, delim); heads.append(rows[0] if rows else [])
    if inter and heads:
        vals = [h for h in heads[0] if all(h in x for x in heads[1:])]
    else:
        vals = heads[0] if heads else []
    if just or len(paths) > 1 or inter:
        emit("".join(h + "\n" for h in vals))
    else:
        emit("".join(f"{i:<4}{h}\n" for i, h in enumerate(vals, 1)))


def cmd_select(args):
    args, out, no_headers, delim = common(args)
    if args and args[0] == "--": args.pop(0)
    sel = args.pop(0) if args else "1-"
    rows, _ = read_input(args, delim)
    header, body = split_header(rows, no_headers)
    width = max([len(r) for r in rows] or [0])
    idxs = parse_selection(sel, header, width)
    out_rows = ([] if no_headers else [project([header], idxs)[0]]) + project(body, idxs)
    emit(write_csv(out_rows), out)


def cmd_slice(args):
    args, out, no_headers, delim = common(args)
    ix = take_opt(args, ["-i", "--index"])
    start = int(take_opt(args, ["-s", "--start"], 0) or 0)
    end = take_opt(args, ["-e", "--end"])
    ln = take_opt(args, ["-l", "--len"])
    if ix is not None: start, ln = int(ix), 1
    rows, _ = read_input(args, delim)
    header, body = split_header(rows, no_headers)
    stop = start + int(ln) if ln is not None else (int(end) if end is not None else None)
    out_rows = ([] if no_headers else ([header] if header else [])) + body[start:stop]
    emit(write_csv(out_rows), out)


def cmd_reverse(args):
    args, out, no_headers, delim = common(args)
    rows, _ = read_input(args, delim)
    header, body = split_header(rows, no_headers)
    emit(write_csv(([] if no_headers else ([header] if header else [])) + list(reversed(body))), out)


def cmd_search(args):
    args, out, no_headers, delim = common(args)
    icase = bool(take_opt(args, ["-i", "--ignore-case"], False, False))
    inv = bool(take_opt(args, ["-v", "--invert-match"], False, False))
    sel = take_opt(args, ["-s", "--select"])
    pat = args.pop(0) if args else ""
    rows, _ = read_input(args, delim)
    header, body = split_header(rows, no_headers)
    idxs = parse_selection(sel, header, max([len(r) for r in rows] or [0])) if sel else None
    rx = re.compile(pat, re.I if icase else 0)
    out_rows = [] if no_headers else ([header] if header else [])
    for r in body:
        vals = [r[i] if i < len(r) else "" for i in (idxs if idxs is not None else range(len(r)))]
        ok = any(rx.search(v) for v in vals)
        if ok ^ inv: out_rows.append(r)
    emit(write_csv(out_rows), out)


def cmd_frequency(args):
    args, out, no_headers, delim = common(args)
    sel = take_opt(args, ["-s", "--select"])
    limit = int(take_opt(args, ["-l", "--limit"], 10) or 0)
    asc = bool(take_opt(args, ["-a", "--asc"], False, False))
    nonulls = bool(take_opt(args, ["--no-nulls"], False, False))
    take_opt(args, ["-j", "--jobs"])
    rows, _ = read_input(args, delim)
    header, body = split_header(rows, no_headers)
    width = max([len(r) for r in rows] or [0])
    idxs = parse_selection(sel, header, width) if sel else list(range(width))
    out_rows = [["field", "value", "count"]]
    for i in idxs:
        c = Counter((r[i] if i < len(r) else "") for r in body)
        if nonulls: c.pop("", None)
        items = sorted(c.items(), key=lambda kv: (kv[1], kv[0]) if asc else (-kv[1], kv[0]))
        if limit: items = items[:limit]
        name = header[i] if header and i < len(header) else str(i + 1)
        out_rows.extend([[name, v, str(n)] for v, n in items])
    emit(write_csv(out_rows), out)


def cmd_sort(args):
    args, out, no_headers, delim = common(args)
    sel = take_opt(args, ["-s", "--select"])
    numeric = bool(take_opt(args, ["-N", "--numeric"], False, False))
    rev = bool(take_opt(args, ["-R", "--reverse"], False, False))
    rows, _ = read_input(args, delim)
    header, body = split_header(rows, no_headers)
    width = max([len(r) for r in rows] or [0])
    idxs = parse_selection(sel, header, width) if sel else list(range(width))
    def key(r):
        vals = [r[i] if i < len(r) else "" for i in idxs]
        if numeric:
            return [float(v) if re.match(r"^-?\d+(\.\d+)?$", v) else float("-inf") for v in vals]
        return vals
    body = sorted(body, key=key, reverse=rev)
    emit(write_csv(([] if no_headers else ([header] if header else [])) + body), out)


def cmd_fixlengths(args):
    args, out, _, delim = common(args)
    ln = take_opt(args, ["-l", "--length"])
    rows, _ = read_input(args, delim)
    if ln is None:
        ln = max([max(1, len([x for x in r if x != ""] or r)) for r in rows] or [0])
    ln = int(ln)
    emit(write_csv([(r + [""] * ln)[:ln] for r in rows]), out)


def cmd_fmt(args):
    args, out, _, delim = common(args)
    od = take_opt(args, ["-t", "--out-delimiter"], ",")
    if od == r"\t": od = "\t"
    crlf = bool(take_opt(args, ["--crlf"], False, False))
    ascii_mode = bool(take_opt(args, ["--ascii"], False, False))
    quote = take_opt(args, ["--quote"], '"')
    qalways = bool(take_opt(args, ["--quote-always"], False, False))
    take_opt(args, ["--escape"])
    rows, _ = read_input(args, delim)
    if ascii_mode:
        od, term = chr(31), chr(30)
    else:
        term = "\r\n" if crlf else "\n"
    emit(write_csv(rows, od, term, quote, qalways), out)


def cmd_input(args):
    args, out, _, delim = common(args)
    quote = take_opt(args, ["--quote"], '"')
    escape = take_opt(args, ["--escape"])
    noquoting = bool(take_opt(args, ["--no-quoting"], False, False))
    rows, _ = read_input(args, delim, quote, escape, not noquoting)
    emit(write_csv(rows), out)


def cmd_flatten(args):
    args, _, no_headers, delim = common(args)
    cond = take_opt(args, ["-c", "--condense"])
    sep = take_opt(args, ["-s", "--separator"], "#")
    rows, _ = read_input(args, delim)
    header, body = split_header(rows, no_headers)
    if no_headers:
        header = [str(i) for i in range(max([len(r) for r in rows] or [0]))]
    width = max([2] + [len(h) for h in header])
    chunks = []
    for ri, r in enumerate(body):
        for i, h in enumerate(header):
            v = r[i] if i < len(r) else ""
            if cond and len(v) > int(cond): v = v[:int(cond)]
            chunks.append(f"{h:<{width}}  {v}\n")
        if sep and ri != len(body) - 1: chunks.append(sep + "\n")
    emit("".join(chunks))


def cmd_table(args):
    args, out, _, delim = common(args)
    width_min = int(take_opt(args, ["-w", "--width"], 2) or 2)
    pad = int(take_opt(args, ["-p", "--pad"], 2) or 2)
    cond = take_opt(args, ["-c", "--condense"])
    rows, _ = read_input(args, delim)
    if cond:
        rows = [[v[:int(cond)] if len(v) > int(cond) else v for v in r] for r in rows]
    width = max([len(r) for r in rows] or [0])
    ws = [width_min] * width
    for r in rows:
        for i, v in enumerate(r): ws[i] = max(ws[i], len(v))
    lines = []
    for r in rows:
        cells = [(r[i] if i < len(r) else "") for i in range(width)]
        lines.append((" " * pad).join(cells[i].ljust(ws[i]) for i in range(width)).rstrip() + "\n")
    emit("".join(lines), out)


def cmd_stats(args):
    args, out, no_headers, delim = common(args)
    sel = take_opt(args, ["-s", "--select"])
    everything = bool(take_opt(args, ["--everything"], False, False))
    show_mode = everything or bool(take_opt(args, ["--mode"], False, False))
    show_card = everything or bool(take_opt(args, ["--cardinality"], False, False))
    show_med = everything or bool(take_opt(args, ["--median"], False, False))
    include_nulls = bool(take_opt(args, ["--nulls"], False, False))
    take_opt(args, ["-j", "--jobs"])
    rows, _ = read_input(args, delim)
    header, body = split_header(rows, no_headers)
    width = max([len(r) for r in rows] or [0])
    idxs = parse_selection(sel, header, width) if sel else list(range(width))
    cols = ["field", "type", "sum", "min", "max", "min_length", "max_length", "mean", "stddev"]
    if show_med: cols.append("median")
    if show_mode: cols.append("mode")
    if show_card: cols.append("cardinality")
    out_rows = [cols]
    for i in idxs:
        vals = [r[i] if i < len(r) else "" for r in body]
        nums = []
        all_int, all_float = True, True
        for v in vals:
            if v == "": continue
            try:
                f = float(v); nums.append(f)
                if not re.match(r"^-?\d+$", v): all_int = False
            except ValueError:
                all_float = False; all_int = False
        typ = "Integer" if vals and all_int and nums else ("Float" if all_float and nums else "Unicode")
        lens = [len(v) for v in vals]
        row = [header[i] if header and i < len(header) else str(i + 1), typ]
        if nums and typ in ("Integer", "Float"):
            popn = len(vals) if include_nulls else len(nums)
            s = sum(nums); mean = s / popn if popn else 0
            var = sum((x - mean) ** 2 for x in nums) / popn if popn else 0
            fmt = lambda x: ("%g" % x)
            num_text = [v for v in vals if v != ""]
            row += [fmt(s), min(num_text, key=float), max(num_text, key=float), str(min(lens or [0])), str(max(lens or [0])), fmt(mean), fmt(math.sqrt(var))]
        else:
            nz = [v for v in vals if v != ""]
            row += ["", min(nz) if nz else "", max(nz) if nz else "", str(min(lens or [0])), str(max(lens or [0])), "", ""]
        if show_med:
            row.append(("%g" % statistics.median(nums)) if nums else "")
        if show_mode:
            c = Counter(vals); row.append(c.most_common(1)[0][0] if vals else "")
        if show_card:
            row.append(str(len(set(vals))))
        out_rows.append(row)
    emit(write_csv(out_rows), out)


def cmd_join(args):
    args, out, no_headers, delim = common(args)
    nocase = bool(take_opt(args, ["--no-case"], False, False))
    left = bool(take_opt(args, ["--left"], False, False))
    right = bool(take_opt(args, ["--right"], False, False))
    full = bool(take_opt(args, ["--full"], False, False))
    cross = bool(take_opt(args, ["--cross"], False, False))
    nulls = bool(take_opt(args, ["--nulls"], False, False))
    if len(args) < 4: return emit("")
    c1, f1, c2, f2 = args[:4]
    r1 = parse_csv(open(f1, encoding="utf-8", newline="").read(), delim)
    r2 = parse_csv(open(f2, encoding="utf-8", newline="").read(), delim)
    h1, b1 = split_header(r1, no_headers); h2, b2 = split_header(r2, no_headers)
    w1, w2 = max([len(r) for r in r1] or [0]), max([len(r) for r in r2] or [0])
    i1 = parse_selection(c1, h1, w1); i2 = parse_selection(c2, h2, w2)
    out_rows = ([] if no_headers else [h1 + h2])
    if cross:
        out_rows += [a + b for a in b1 for b in b2]
        return emit(write_csv(out_rows), out)
    def key(r, idxs):
        vals = [(r[i] if i < len(r) else "").strip() for i in idxs]
        if not nulls and any(v == "" for v in vals): return None
        return tuple(v.lower() if nocase else v for v in vals)
    mp = defaultdict(list)
    for j, r in enumerate(b2):
        k = key(r, i2)
        if k is not None: mp[k].append((j, r))
    matched = set()
    for a in b1:
        k = key(a, i1)
        hits = mp.get(k, []) if k is not None else []
        if hits:
            for j, b in hits:
                matched.add(j); out_rows.append(a + b)
        elif left or full:
            out_rows.append(a + [""] * w2)
    if right or full:
        for j, b in enumerate(b2):
            if j not in matched: out_rows.append([""] * w1 + b)
    emit(write_csv(out_rows), out)


def cmd_cat(args):
    args, out, no_headers, delim = common(args)
    pad = bool(take_opt(args, ["-p", "--pad"], False, False))
    mode = args.pop(0) if args else "rows"
    files = [a for a in args if not a.startswith("-")]
    datasets = [parse_csv(open(f, encoding="utf-8", newline="").read(), delim) for f in files] or [parse_csv(sys.stdin.read(), delim)]
    if mode.startswith("col"):
        n = (max if pad else min)([len(d) for d in datasets] or [0])
        rows = []
        widths = [max([len(r) for r in d] or [0]) for d in datasets]
        for i in range(n):
            row = []
            for d, w in zip(datasets, widths):
                row += (d[i] if i < len(d) else [""] * w)
            rows.append(row)
    else:
        rows = []
        for di, d in enumerate(datasets):
            rows += d if no_headers or di == 0 else d[1:]
    emit(write_csv(rows), out)


def safe_name(v):
    v = re.sub(r"[^A-Za-z0-9_.-]+", "_", v)
    return v or "_"


def cmd_split(args):
    args, _, no_headers, delim = common(args)
    size = int(take_opt(args, ["-s", "--size"], 500) or 500)
    take_opt(args, ["-j", "--jobs"])
    tmpl = take_opt(args, ["--filename"], "{}.csv")
    outdir = args.pop(0) if args else "."
    rows, _ = read_input(args, delim)
    os.makedirs(outdir, exist_ok=True)
    header, body = split_header(rows, no_headers)
    for start in range(0, len(body), size):
        chunk = ([] if no_headers else [header]) + body[start:start + size]
        open(os.path.join(outdir, tmpl.replace("{}", str(start))), "w", encoding="utf-8", newline="").write(write_csv(chunk))


def cmd_partition(args):
    args, _, no_headers, delim = common(args)
    tmpl = take_opt(args, ["--filename"], "{}.csv")
    pref = take_opt(args, ["-p", "--prefix-length"])
    drop = bool(take_opt(args, ["--drop"], False, False))
    col = args.pop(0) if args else "1"; outdir = args.pop(0) if args else "."
    rows, _ = read_input(args, delim)
    os.makedirs(outdir, exist_ok=True)
    header, body = split_header(rows, no_headers)
    idx = col_index(col, header, max([len(r) for r in rows] or [0]))
    handles = {}
    for r in body:
        val = r[idx] if idx < len(r) else ""
        if pref: val = val[:int(pref)]
        name = os.path.join(outdir, tmpl.replace("{}", safe_name(val)))
        first = name not in handles
        f = handles.setdefault(name, open(name, "w", encoding="utf-8", newline=""))
        rr = [x for j, x in enumerate(r) if not (drop and j == idx)]
        if first and not no_headers:
            hh = [x for j, x in enumerate(header) if not (drop and j == idx)]
            f.write(write_csv([hh]))
        f.write(write_csv([rr]))
    for f in handles.values(): f.close()


def cmd_sample(args):
    args, out, no_headers, delim = common(args)
    seed = take_opt(args, ["--seed"])
    n = int(args.pop(0)) if args else 0
    rows, _ = read_input(args, delim)
    header, body = split_header(rows, no_headers)
    rng = random.Random(int(seed)) if seed is not None else random.Random()
    body = rng.sample(body, min(n, len(body)))
    emit(write_csv(([] if no_headers else ([header] if header else [])) + body), out)


def cmd_index(args):
    args, _, _, _ = common(args)
    out = take_opt(args, ["-o", "--output"])
    path = args[0] if args else None
    if path:
        open(out or path + ".idx", "wb").write(b"xsvidx\n")


def usage():
    return """Usage:
    xsv <command> [<args>...]
    xsv [options]

Options:
    --list        List all commands available.
    -h, --help    Display this message
    <command> -h  Display the command help message
    --version     Print version info and exit

Commands:
""" + "".join(f"    {c}\n" for c in COMMANDS)


def main(argv):
    if len(argv) == 1 or argv[1] in ("-h", "--help", "help"):
        sys.stdout.write(usage()); return 0
    if argv[1] == "--list":
        sys.stdout.write("\n".join(COMMANDS) + "\n"); return 0
    if argv[1] == "--version":
        sys.stdout.write("xsv 0.13.0\n"); return 0
    cmd, args = argv[1], argv[2:]
    if "-h" in args or "--help" in args:
        sys.stdout.write(f"Usage:\n    xsv {cmd} [options] [<input>]\n"); return 0
    fn = globals().get("cmd_" + cmd)
    if not fn:
        sys.stderr.write(f"Unrecognized command '{cmd}'.\n"); return 1
    fn(args)
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main(sys.argv))
    except BrokenPipeError:
        raise SystemExit(0)
