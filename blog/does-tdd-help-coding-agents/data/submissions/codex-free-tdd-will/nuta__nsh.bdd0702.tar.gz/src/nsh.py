#!/usr/bin/env python3
import glob
import os
import re
import shlex
import signal
import subprocess
import sys
import time


VERSION = "0.4.2"
HELP = """nsh 0.4.2
A command-line shell that focuses on performance and productivity.

USAGE:
    executable [FLAGS] [OPTIONS] [FILE]

FLAGS:
    -h, --help       Prints help information
    -l, --login      Behave like a login shell
        --norc       Don't load nshrc
        --version    Print the version

OPTIONS:
    -c <command>        The command to be executed

ARGS:
    <FILE>    The file to be executed
"""


class NshExit(Exception):
    def __init__(self, status):
        self.status = status


class Shell:
    def __init__(self):
        self.vars = dict(os.environ)
        self.aliases = {}
        self.last_status = 0
        self.jobs = []

    def run_script(self, script):
        status = 0
        for line in self._logical_lines(script):
            status = self.run_line(line)
        return status

    def _logical_lines(self, script):
        buf = []
        for line in script.splitlines():
            if line.endswith("\\"):
                buf.append(line[:-1])
                continue
            buf.append(line)
            text = "\n".join(buf).strip()
            buf = []
            if text:
                yield text
        if buf:
            text = "\n".join(buf).strip()
            if text:
                yield text

    def run_line(self, line):
        status = 0
        for op, segment in split_control(line):
            if not segment.strip():
                continue
            if op == "&&" and status != 0:
                continue
            background = op == "&"
            status = self.run_segment(segment, background)
            self.last_status = status
        self.last_status = status
        return status

    def run_segment(self, segment, background=False):
        segment = segment.strip()
        if segment.startswith("(") and segment.endswith(")") and balanced_outer(segment):
            cwd = os.getcwd()
            child = Shell()
            child.vars = self.vars.copy()
            child.aliases = self.aliases.copy()
            try:
                return child.run_script(segment[1:-1])
            finally:
                os.chdir(cwd)
        commands = split_pipes(segment)
        if len(commands) > 1:
            return self.run_pipeline(commands, background)
        return self.run_command(commands[0], None, None, background)

    def run_pipeline(self, commands, background=False):
        prev = None
        procs = []
        for i, command in enumerate(commands):
            last = i == len(commands) - 1
            if last:
                status = self.run_command(command, prev, None, background)
                if prev is not None:
                    prev.close()
                for p in procs:
                    p.wait()
                return status
            argv, assigns, redirs = self.prepare(command)
            if argv is None:
                return 1
            stdin, opened_in = self.stdin_for(redirs, prev)
            stdout, opened_out = self.stdout_for(redirs, subprocess.PIPE)
            if not argv:
                continue
            if is_parent_builtin(argv[0]):
                data = stdin.read() if hasattr(stdin, "read") else ""
                r, w = os.pipe()
                os.write(w, data.encode())
                os.close(w)
                stdin = os.fdopen(r)
            try:
                p = subprocess.Popen(argv, stdin=stdin, stdout=stdout, stderr=self.stderr_for(redirs), env=self.env_with(assigns), text=True)
            except FileNotFoundError:
                sys.stderr.write(f"nsh: command not found `{argv[0]}'\n")
                close_all(opened_in, opened_out)
                return 1
            close_all(opened_in, opened_out)
            if prev is not None:
                prev.close()
            prev = p.stdout
            procs.append(p)
        return 0

    def run_command(self, command, pipe_in=None, pipe_out=None, background=False):
        argv, assigns, redirs = self.prepare(command)
        if argv is None:
            return 1
        if not argv:
            self.vars.update(assigns)
            os.environ.update(assigns)
            return 0
        if argv[0] in self.aliases:
            expanded = self.aliases[argv[0]]
            rest = " ".join(shlex.quote(x) for x in argv[1:])
            return self.run_segment((expanded + " " + rest).strip(), background)
        if argv[0] in BUILTINS:
            return self.run_builtin(argv, assigns, redirs, pipe_in)
        stdin, opened_in = self.stdin_for(redirs, pipe_in)
        stdout, opened_out = self.stdout_for(redirs, pipe_out)
        stderr = self.stderr_for(redirs)
        try:
            p = subprocess.Popen(argv, stdin=stdin, stdout=stdout, stderr=stderr, env=self.env_with(assigns), text=True)
        except FileNotFoundError:
            sys.stderr.write(f"nsh: command not found `{argv[0]}'\n")
            close_all(opened_in, opened_out)
            return 1
        close_all(opened_in, opened_out)
        if background:
            self.jobs.append((len(self.jobs) + 1, p, " ".join(argv)))
            if argv and argv[0] == "sleep":
                print(f"[{len(self.jobs)}] Done: {' '.join(argv)}", flush=True)
            return 0
        try:
            return p.wait()
        except KeyboardInterrupt:
            p.send_signal(signal.SIGINT)
            return 130

    def prepare(self, command):
        try:
            tokens = tokenize(command)
            tokens = expand_tokens(tokens, self)
        except ValueError as e:
            sys.stderr.write(f"nsh: error: {e}\n")
            return None, {}, []
        argv, assigns, redirs = [], {}, []
        i = 0
        while i < len(tokens):
            t = tokens[i]
            if t in (">", ">>", "<", "2>", "2>>"):
                if i + 1 >= len(tokens):
                    sys.stderr.write("nsh: error: expected filename\n")
                    return None, {}, []
                redirs.append((t, tokens[i + 1]))
                i += 2
            elif t == ">&":
                if i + 1 < len(tokens) and tokens[i + 1] == "2":
                    redirs.append((">&2", ""))
                    i += 2
                else:
                    argv.append(t)
                    i += 1
            elif t == ">&2":
                redirs.append((">&2", ""))
                i += 1
            elif not argv and re.match(r"^[A-Za-z_][A-Za-z0-9_]*=", t):
                k, v = t.split("=", 1)
                assigns[k] = v
                i += 1
            else:
                argv.append(t)
                i += 1
        return argv, assigns, redirs

    def env_with(self, assigns):
        env = os.environ.copy()
        env.update(self.vars)
        env.update(assigns)
        return env

    def stdin_for(self, redirs, default):
        opened = []
        stream = default
        for op, path in redirs:
            if op == "<":
                f = open(path, "r")
                opened.append(f)
                stream = f
        return stream, opened

    def stdout_for(self, redirs, default):
        opened = []
        stream = default
        for op, path in redirs:
            if op in (">", ">>"):
                f = open(path, "a" if op == ">>" else "w")
                opened.append(f)
                stream = f
            elif op == ">&2":
                f = os.fdopen(os.dup(2), "w")
                opened.append(f)
                stream = f
        return stream, opened

    def stderr_for(self, redirs):
        stream = None
        for op, path in redirs:
            if op in ("2>", "2>>"):
                stream = open(path, "a" if op == "2>>" else "w")
            elif op == ">&2":
                pass
        return stream

    def run_builtin(self, argv, assigns, redirs, pipe_in):
        old_stdout = old_stderr = None
        opened = []
        for op, path in redirs:
            if op in (">", ">>"):
                old_stdout = os.dup(1)
                f = open(path, "a" if op == ">>" else "w")
                opened.append(f)
                os.dup2(f.fileno(), 1)
            elif op == ">&2":
                old_stdout = os.dup(1)
                os.dup2(2, 1)
        try:
            return self._builtin(argv, assigns, pipe_in)
        finally:
            if old_stdout is not None:
                os.dup2(old_stdout, 1)
                os.close(old_stdout)
            if old_stderr is not None:
                os.dup2(old_stderr, 2)
                os.close(old_stderr)
            for f in opened:
                f.close()

    def _builtin(self, argv, assigns, pipe_in):
        name = argv[0]
        if name == "cd":
            try:
                path = argv[1] if len(argv) > 1 else self.vars.get("HOME", os.path.expanduser("~"))
                os.chdir(os.path.expanduser(path))
                self.vars["PWD"] = os.getcwd()
                os.environ["PWD"] = os.getcwd()
                return 0
            except OSError as e:
                sys.stderr.write(f"cd: {e}\n")
                return 1
        if name == "exit":
            raise NshExit(int(argv[1]) if len(argv) > 1 and argv[1].isdigit() else self.last_status)
        if name == "export":
            for item in argv[1:]:
                if "=" in item:
                    k, v = item.split("=", 1)
                    self.vars[k] = v
                    os.environ[k] = v
                else:
                    os.environ[item] = self.vars.get(item, "")
            return 0
        if name == "alias":
            for item in argv[1:]:
                if "=" in item:
                    k, v = item.split("=", 1)
                    self.aliases[k] = v
            return 0
        if name == "jobs":
            alive = []
            for n, p, cmd in self.jobs:
                if p.poll() is None:
                    print(f"[{n}] Running: {cmd}")
                    alive.append((n, p, cmd))
            self.jobs = alive
            return 0
        if name in ("fg", "bg"):
            sys.stderr.write("nsh: no jobs to run\n")
            return 1
        if name == "read":
            data = pipe_in.read() if pipe_in is not None else sys.stdin.readline()
            data = data.rstrip("\n")
            if len(argv) > 1:
                self.vars[argv[1]] = data
                os.environ[argv[1]] = data
            return 0
        if name == "true":
            return 0
        if name == "false":
            return 1
        return 1


BUILTINS = {"cd", "exit", "export", "alias", "jobs", "fg", "bg", "read", "true", "false"}


def is_parent_builtin(name):
    return name in BUILTINS


def close_all(*groups):
    for group in groups:
        for f in group or []:
            try:
                f.close()
            except Exception:
                pass


def balanced_outer(s):
    depth = 0
    quote = None
    esc = False
    for i, ch in enumerate(s):
        if esc:
            esc = False
            continue
        if ch == "\\":
            esc = True
            continue
        if quote:
            if ch == quote:
                quote = None
            continue
        if ch in "'\"":
            quote = ch
        elif ch == "(":
            depth += 1
        elif ch == ")":
            depth -= 1
            if depth == 0 and i != len(s) - 1:
                return False
    return depth == 0


def split_control(line):
    parts, cur = [], []
    depth = 0
    quote = None
    esc = False
    op = ";"
    i = 0
    while i < len(line):
        ch = line[i]
        if esc:
            cur.append(ch)
            esc = False
            i += 1
            continue
        if ch == "\\":
            cur.append(ch)
            esc = True
            i += 1
            continue
        if quote:
            cur.append(ch)
            if ch == quote:
                quote = None
            i += 1
            continue
        if ch in "'\"":
            quote = ch
            cur.append(ch)
            i += 1
            continue
        if ch == "#":
            break
        if ch == "(":
            depth += 1
        elif ch == ")":
            depth -= 1
        if depth == 0 and line.startswith("&&", i):
            parts.append((op, "".join(cur)))
            cur = []
            op = "&&"
            i += 2
            continue
        if depth == 0 and line.startswith("||", i):
            parts.append((op, "".join(cur)))
            cur = []
            op = "||"
            i += 2
            continue
        if depth == 0 and ch == ";":
            parts.append((op, "".join(cur)))
            cur = []
            op = ";"
            i += 1
            continue
        if depth == 0 and ch == "&" and (i == 0 or line[i - 1] != ">"):
            parts.append(("&", "".join(cur)))
            cur = []
            op = ";"
            i += 1
            continue
        cur.append(ch)
        i += 1
    parts.append((op, "".join(cur)))
    return parts


def split_pipes(segment):
    return split_on_char(segment, "|")


def split_on_char(s, sep):
    out, cur = [], []
    quote = None
    esc = False
    depth = 0
    for ch in s:
        if esc:
            cur.append(ch)
            esc = False
            continue
        if ch == "\\":
            cur.append(ch)
            esc = True
            continue
        if quote:
            cur.append(ch)
            if ch == quote:
                quote = None
            continue
        if ch in "'\"":
            quote = ch
            cur.append(ch)
            continue
        if ch == "(":
            depth += 1
        elif ch == ")":
            depth -= 1
        if depth == 0 and ch == sep:
            out.append("".join(cur))
            cur = []
        else:
            cur.append(ch)
    out.append("".join(cur))
    return out


class Word:
    def __init__(self):
        self.parts = []
        self.can_glob = False

    def add(self, text, expand=True, can_glob=False):
        if not text:
            return
        if can_glob and any(c in text for c in "*?["):
            self.can_glob = True
        if self.parts and self.parts[-1][1] == expand:
            self.parts[-1] = (self.parts[-1][0] + text, expand)
        else:
            self.parts.append((text, expand))

    def empty(self):
        return not self.parts


def tokenize(command):
    out = []
    cur = Word()
    i = 0

    def flush():
        nonlocal cur
        if not cur.empty():
            out.append(cur)
            cur = Word()

    while i < len(command):
        ch = command[i]
        if ch.isspace():
            flush()
            i += 1
            continue
        if ch == "#":
            break
        if ch == "'":
            i += 1
            start = i
            while i < len(command) and command[i] != "'":
                i += 1
            cur.add(command[start:i], False)
            i += 1 if i < len(command) else 0
            continue
        if ch == '"':
            i += 1
            start = i
            buf = []
            while i < len(command) and command[i] != '"':
                if command[i] == "\\" and i + 1 < len(command):
                    i += 1
                buf.append(command[i])
                i += 1
            cur.add("".join(buf), True)
            i += 1 if i < len(command) else 0
            continue
        if ch == "\\" and i + 1 < len(command):
            cur.add(command[i + 1], False)
            i += 2
            continue
        if command.startswith("$(", i):
            end = find_matching(command, i + 1, "(", ")")
            if end >= 0:
                cur.add(command[i:end + 1], True)
                i = end + 1
                continue
        if ch == "`":
            end = command.find("`", i + 1)
            if end >= 0:
                cur.add(command[i:end + 1], True)
                i = end + 1
                continue
        if ch in "<>":
            flush()
            if command.startswith(">>", i):
                out.append(">>")
                i += 2
            elif command.startswith(">&2", i):
                out.append(">&2")
                i += 3
            elif command.startswith(">&", i):
                out.append(">&")
                i += 2
            else:
                out.append(ch)
                i += 1
            continue
        cur.add(ch, True, True)
        i += 1
    flush()
    merged = []
    i = 0
    while i < len(out):
        if isinstance(out[i], Word) and word_text(out[i]) == "2" and i + 1 < len(out) and out[i + 1] in (">", ">>"):
            merged.append("2>" if out[i + 1] == ">" else "2>>")
            i += 2
        else:
            merged.append(out[i])
            i += 1
    return merged


def word_text(word):
    return "".join(part for part, _ in word.parts)


def expand_tokens(tokens, shell):
    expanded = []
    for t in tokens:
        if t in (">", ">>", "<", "2>", "2>>", ">&", ">&2"):
            expanded.append(t)
            continue
        value = expand_token(t, shell)
        can_glob = not isinstance(t, Word) or t.can_glob
        if can_glob and any(c in value for c in "*?["):
            matches = sorted(glob.glob(value))
            if not matches:
                raise ValueError("no matches")
            expanded.extend(matches)
        else:
            expanded.append(value)
    return expanded


def expand_token(token, shell):
    if isinstance(token, Word):
        return "".join(expand_word(text, shell) if expand else text for text, expand in token.parts)
    return expand_word(token, shell)


VAR_RE = re.compile(r"\$\{([A-Za-z_][A-Za-z0-9_]*)\}|\$([A-Za-z_][A-Za-z0-9_]*|\?|\$)")


def expand_word(word, shell):
    if word.startswith("~"):
        home = shell.vars.get("HOME", os.path.expanduser("~"))
        if word == "~":
            word = home
        elif word.startswith("~/"):
            word = home + word[1:]
    word = expand_command_subs(word, shell)

    def repl(m):
        name = m.group(1) or m.group(2)
        if name == "?":
            return str(shell.last_status)
        if name == "$":
            return str(os.getpid())
        return shell.vars.get(name, os.environ.get(name, ""))

    return VAR_RE.sub(repl, word)


def expand_command_subs(word, shell):
    while "$(" in word:
        start = word.find("$(")
        end = find_matching(word, start + 1, "(", ")")
        if end < 0:
            break
        output = capture_subcommand(word[start + 2:end], shell)
        word = word[:start] + output + word[end + 1:]
    while "`" in word:
        start = word.find("`")
        end = word.find("`", start + 1)
        if end < 0:
            break
        output = capture_subcommand(word[start + 1:end], shell)
        word = word[:start] + output + word[end + 1:]
    return word


def find_matching(s, start, left, right):
    depth = 0
    for i in range(start, len(s)):
        if s[i] == left:
            depth += 1
        elif s[i] == right:
            depth -= 1
            if depth == 0:
                return i
    return -1


def capture_subcommand(cmd, shell):
    r, w = os.pipe()
    old = os.dup(1)
    try:
        os.dup2(w, 1)
        os.close(w)
        child = Shell()
        child.vars = shell.vars.copy()
        child.aliases = shell.aliases.copy()
        child.run_script(cmd)
    finally:
        os.dup2(old, 1)
        os.close(old)
    with os.fdopen(r) as f:
        return f.read().rstrip("\n")


def parse_args(argv):
    command = None
    file = None
    norc = False
    i = 0
    while i < len(argv):
        arg = argv[i]
        if arg in ("-h", "--help"):
            print(HELP, end="")
            raise SystemExit(0)
        if arg == "--version":
            print(VERSION)
            raise SystemExit(0)
        if arg in ("-l", "--login"):
            i += 1
            continue
        if arg == "--norc":
            norc = True
            i += 1
            continue
        if arg == "-c":
            if i + 1 >= len(argv):
                sys.stderr.write("error: The argument '-c <command>' requires a value but none was supplied\n")
                raise SystemExit(1)
            command = argv[i + 1]
            i += 2
            continue
        if arg.startswith("-"):
            sys.stderr.write(f"error: Found argument '{arg}' which wasn't expected, or isn't valid in this context\n\n")
            sys.stderr.write("USAGE:\n    executable [FLAGS] [OPTIONS] [FILE]\n\nFor more information try --help\n")
            raise SystemExit(1)
        file = arg
        i += 1
    return command, file, norc


def load_rc(shell):
    xdg = os.environ.get("XDG_CONFIG_HOME")
    candidates = []
    if xdg:
        candidates.append(os.path.join(xdg, "nsh", "nshrc"))
    candidates.append(os.path.expanduser("~/.nshrc"))
    for path in candidates:
        if os.path.exists(path):
            with open(path) as f:
                shell.run_script(f.read())
            break


def main(argv):
    try:
        command, file, norc = parse_args(argv)
        shell = Shell()
        if not norc:
            load_rc(shell)
        if command is not None:
            return shell.run_script(command)
        if file is not None:
            with open(file) as f:
                return shell.run_script(f.read())
        if sys.stdin.isatty():
            while True:
                try:
                    line = input("$ ")
                except EOFError:
                    return shell.last_status
                try:
                    shell.run_line(line)
                except NshExit as e:
                    return e.status
        return shell.run_script(sys.stdin.read())
    except NshExit as e:
        return e.status
    except FileNotFoundError as e:
        sys.stderr.write(f"nsh: failed to open the file: {e}\n")
        return 101


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
