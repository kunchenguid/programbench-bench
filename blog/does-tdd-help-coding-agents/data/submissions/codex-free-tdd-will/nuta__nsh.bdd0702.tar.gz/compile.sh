#!/bin/bash
set -e
rm -f executable
cp src/nsh.py executable
chmod +x executable
