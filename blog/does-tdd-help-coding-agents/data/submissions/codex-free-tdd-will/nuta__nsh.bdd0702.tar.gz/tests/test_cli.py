import os
import subprocess
import tempfile
import unittest


ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


class NshCliTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        subprocess.run(["bash", "compile.sh"], cwd=ROOT, check=True)

    def run_nsh(self, *args, input_text=None):
        return subprocess.run(
            [os.path.join(ROOT, "executable"), *args],
            cwd=ROOT,
            input=input_text,
            text=True,
            capture_output=True,
        )

    def test_version_prints_plain_version(self):
        result = self.run_nsh("--version")
        self.assertEqual(result.returncode, 0)
        self.assertEqual(result.stdout, "0.4.2\n")
        self.assertEqual(result.stderr, "")

    def test_help_matches_documented_cli(self):
        result = self.run_nsh("--help")
        self.assertEqual(result.returncode, 0)
        self.assertIn("nsh 0.4.2\n", result.stdout)
        self.assertIn("USAGE:\n    executable [FLAGS] [OPTIONS] [FILE]\n", result.stdout)

    def test_c_executes_external_command(self):
        result = self.run_nsh("-c", "echo hi")
        self.assertEqual(result.returncode, 0)
        self.assertEqual(result.stdout, "hi\n")
        self.assertEqual(result.stderr, "")

    def test_sequences_and_status_expansion(self):
        result = self.run_nsh("-c", "false; echo $?; true && echo ok; false && echo no; true || echo also")
        self.assertEqual(result.returncode, 0)
        self.assertEqual(result.stdout, "1\nok\nalso\n")

    def test_variables_quotes_command_substitution_and_glob(self):
        result = self.run_nsh("-c", "FOO=bar; echo '$FOO'; echo \"$FOO\"; echo $(echo sub); echo *.md")
        self.assertEqual(result.returncode, 0)
        self.assertEqual(result.stdout, "$FOO\nbar\nsub\nREADME.md\n")

    def test_unmatched_glob_is_error(self):
        result = self.run_nsh("-c", "echo no_such_*")
        self.assertEqual(result.returncode, 1)
        self.assertEqual(result.stdout, "")
        self.assertEqual(result.stderr, "nsh: error: no matches\n")

    def test_pipeline_redirection_alias_and_read(self):
        with tempfile.TemporaryDirectory(dir=ROOT) as tmp:
            out = os.path.join(tmp, "out")
            command = (
                f"alias ll='echo LL'; ll hi; "
                f"printf 'a\\nb\\n' | grep b > {out}; "
                f"cat < {out}; "
                "echo one two | read x; echo $x"
            )
            result = self.run_nsh("-c", command)
        self.assertEqual(result.returncode, 0)
        self.assertEqual(result.stdout, "LL hi\nb\none two\n")

    def test_script_file_continues_after_false_and_returns_last_status(self):
        with tempfile.NamedTemporaryFile("w", dir=ROOT, delete=False) as f:
            f.write("echo script\nfalse\necho after\n")
            path = f.name
        try:
            result = self.run_nsh(path)
        finally:
            os.unlink(path)
        self.assertEqual(result.returncode, 0)
        self.assertEqual(result.stdout, "script\nafter\n")


if __name__ == "__main__":
    unittest.main()
