#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <stdlib.h>
#include <sys/stat.h>
#include <sys/time.h>
#include <termios.h>
#include <time.h>
#include <ctype.h>

static const char *WORDS[] = {
    "the","be","to","of","and","a","in","that","have","i","it","for","not","on","with",
    "he","as","you","do","at","this","but","his","by","from","they","we","say","her","she",
    "or","an","will","my","one","all","would","there","their","what","so","up","out","if",
    "about","who","get","which","go","me"
};

static void print_help(void) {
    puts("thokr 0.4.1");
    puts("sleek typing tui with visualized results and historical logging");
    puts("");
    puts("USAGE:");
    puts("    executable [OPTIONS]");
    puts("");
    puts("OPTIONS:");
    puts("    -f, --full-sentences <NUMBER_OF_SENTENCES>");
    puts("            number of sentences to use in test");
    puts("");
    puts("    -h, --help");
    puts("            Print help information");
    puts("");
    puts("    -l, --supported-language <SUPPORTED_LANGUAGE>");
    puts("            language to pull words from [default: english] [possible values: english, english1k,");
    puts("            english10k]");
    puts("");
    puts("    -p, --prompt <PROMPT>");
    puts("            custom prompt to use");
    puts("");
    puts("    -s, --number-of-secs <NUMBER_OF_SECS>");
    puts("            number of seconds to run test");
    puts("");
    puts("    -V, --version");
    puts("            Print version information");
    puts("");
    puts("    -w, --number-of-words <NUMBER_OF_WORDS>");
    puts("            number of words to use in test [default: 15]");
}

static double now_secs(void) {
    struct timeval tv;
    gettimeofday(&tv, NULL);
    return (double)tv.tv_sec + (double)tv.tv_usec / 1000000.0;
}

static char *make_prompt(int count) {
    if (count < 1) count = 15;
    size_t cap = (size_t)count * 12 + 1;
    char *s = malloc(cap);
    if (!s) exit(1);
    s[0] = '\0';
    for (int i = 0; i < count; i++) {
        if (i) strcat(s, " ");
        strcat(s, WORDS[i % (int)(sizeof(WORDS) / sizeof(WORDS[0]))]);
    }
    return s;
}

static int word_count(const char *s) {
    int count = 0;
    int in_word = 0;
    for (; *s; s++) {
        if (*s == ' ' || *s == '\n' || *s == '\t' || *s == '\r') {
            in_word = 0;
        } else if (!in_word) {
            count++;
            in_word = 1;
        }
    }
    return count ? count : 1;
}

static int parse_positive_int(const char *value, const char *display, int *out) {
    for (const unsigned char *p = (const unsigned char *)value; *p; p++) {
        if (!isdigit(*p)) {
            fprintf(stderr, "error: Invalid value \"%s\" for '%s': invalid digit found in string\n\nFor more information try --help\n", value, display);
            return 0;
        }
    }
    *out = atoi(value);
    return 1;
}

static void append_log(int num_words, int num_secs, double elapsed, double wpm, double accuracy) {
    const char *home = getenv("HOME");
    if (!home) return;
    char dir1[2048], dir2[2048], path[4096];
    snprintf(dir1, sizeof(dir1), "%s/.config", home);
    snprintf(dir2, sizeof(dir2), "%s/.config/thokr", home);
    snprintf(path, sizeof(path), "%s/log.csv", dir2);
    mkdir(dir1, 0777);
    mkdir(dir2, 0777);
    int exists = access(path, F_OK) == 0;
    FILE *f = fopen(path, "a");
    if (!f) return;
    if (!exists) fputs("date,num_words,num_secs,elapsed_secs,wpm,accuracy,std_dev\n", f);
    time_t t = time(NULL);
    char date[128];
    struct tm *tm = localtime(&t);
    if (tm) {
        strftime(date, sizeof(date), "%a %b %e %H:%M:%S %Y", tm);
    } else {
        snprintf(date, sizeof(date), "unknown");
    }
    if (num_secs > 0) {
        fprintf(f, "%s,%d,%d,%.2f,%.0f,%.0f,0.00\n", date, num_words, num_secs, elapsed, wpm, accuracy);
    } else {
        fprintf(f, "%s,%d,,%.2f,%.0f,%.0f,0.00\n", date, num_words, elapsed, wpm, accuracy);
    }
    fclose(f);
}

static int run_tui(const char *prompt, int word_setting, int num_secs) {
    struct termios oldt, raw;
    tcgetattr(STDIN_FILENO, &oldt);
    raw = oldt;
    raw.c_lflag &= (tcflag_t)~(ICANON | ECHO);
    raw.c_cc[VMIN] = 1;
    raw.c_cc[VTIME] = 0;
    tcsetattr(STDIN_FILENO, TCSANOW, &raw);

    size_t len = strlen(prompt), pos = 0, correct = 0, typed = 0;
    double start = 0.0, elapsed = 0.0;
    printf("\033[?1049h\033[2J\033[12;20H%s\033[?25l", prompt);
    fflush(stdout);
    while (pos < len) {
        unsigned char c;
        if (read(STDIN_FILENO, &c, 1) != 1) break;
        if (c == 27) {
            tcsetattr(STDIN_FILENO, TCSANOW, &oldt);
            printf("\033[?1049l\033[?25h");
            fflush(stdout);
            return 0;
        }
        if (c == 127 || c == 8) continue;
        if (start == 0.0) start = now_secs();
        typed++;
        if ((char)c == prompt[pos]) correct++;
        pos++;
        printf("\033[12;20H");
        for (size_t i = 0; i < len; i++) {
            if (i < pos) printf("\033[38;5;2m%c\033[39m", prompt[i]);
            else if (i == pos) printf("\033[4m\033[2m%c\033[24m\033[22m", prompt[i]);
            else putchar(prompt[i]);
        }
        fflush(stdout);
    }
    elapsed = start == 0.0 ? 0.0 : now_secs() - start;
    double minutes = elapsed / 60.0;
    double wpm = minutes > 0.0 ? ((double)word_count(prompt) / minutes) : 0.0;
    double accuracy = typed ? ((double)correct * 100.0 / (double)typed) : 100.0;
    int words_for_log = word_setting > 0 ? word_setting : word_count(prompt);
    append_log(words_for_log, num_secs, elapsed, wpm, accuracy);
    printf("\033[2J\033[3;6H\033[1minf\033[22m│wpm");
    printf("\033[12;20H%s", prompt);
    printf("\033[17;6H\033[1m0\033[22m│%58sseconds", "");
    printf("\033[19;6H\033[1m1%65.2f", elapsed);
    printf("\033[20;27H%.0f wpm   %.0f%% acc   0.00 sd", wpm, accuracy);
    printf("\033[22;6H\033[3m(r)etry / (n)ew / (esc)ape\033[0m");
    fflush(stdout);
    for (;;) {
        unsigned char c;
        if (read(STDIN_FILENO, &c, 1) != 1) break;
        if (c == 27 || c == 'q') break;
        if (c == 'r' || c == 'n') break;
    }
    tcsetattr(STDIN_FILENO, TCSANOW, &oldt);
    printf("\033[?1049l\033[?25h");
    fflush(stdout);
    return 0;
}

int main(int argc, char **argv) {
    const char *language = "english";
    const char *prompt = NULL;
    int words = 15;
    int num_secs = 0;
    if (argc == 2 && (strcmp(argv[1], "-h") == 0 || strcmp(argv[1], "--help") == 0)) {
        print_help();
        return 0;
    }
    if (argc == 2 && (strcmp(argv[1], "-V") == 0 || strcmp(argv[1], "--version") == 0)) {
        puts("thokr 0.4.1");
        return 0;
    }
    for (int i = 1; i < argc; i++) {
        if (strcmp(argv[i], "-l") == 0 || strcmp(argv[i], "--supported-language") == 0) {
            if (i + 1 >= argc) {
                fprintf(stderr, "error: The argument '%s <SUPPORTED_LANGUAGE>' requires a value but none was supplied\n\nUSAGE:\n    executable %s <SUPPORTED_LANGUAGE>\n\nFor more information try --help\n", argv[i], argv[i]);
                return 2;
            }
            language = argv[++i];
            if (strcmp(language, "english") != 0 && strcmp(language, "english1k") != 0 && strcmp(language, "english10k") != 0) {
                fprintf(stderr, "error: \"%s\" isn't a valid value for '--supported-language <SUPPORTED_LANGUAGE>'\n\t[possible values: english, english1k, english10k]\n\nUSAGE:\n    executable --supported-language <SUPPORTED_LANGUAGE>\n\nFor more information try --help\n", language);
                return 2;
            }
        } else if (strcmp(argv[i], "-p") == 0 || strcmp(argv[i], "--prompt") == 0) {
            if (i + 1 >= argc) {
                fprintf(stderr, "error: The argument '%s <PROMPT>' requires a value but none was supplied\n\nUSAGE:\n    executable %s <PROMPT>\n\nFor more information try --help\n", argv[i], argv[i]);
                return 2;
            }
            prompt = argv[++i];
        } else if (strcmp(argv[i], "-w") == 0 || strcmp(argv[i], "--number-of-words") == 0 ||
                   strcmp(argv[i], "-f") == 0 || strcmp(argv[i], "--full-sentences") == 0) {
            if (i + 1 >= argc) {
                fprintf(stderr, "error: The argument '%s' requires a value but none was supplied\n\nFor more information try --help\n", argv[i]);
                return 2;
            }
            const char *display = (argv[i][1] == 'w' || strstr(argv[i], "number-of-words"))
                ? "--number-of-words <NUMBER_OF_WORDS>"
                : "--full-sentences <NUMBER_OF_SENTENCES>";
            if (!parse_positive_int(argv[++i], display, &words)) return 2;
        } else if (strcmp(argv[i], "-s") == 0 || strcmp(argv[i], "--number-of-secs") == 0) {
            if (i + 1 >= argc) {
                fprintf(stderr, "error: The argument '%s' requires a value but none was supplied\n\nFor more information try --help\n", argv[i]);
                return 2;
            }
            if (!parse_positive_int(argv[++i], "--number-of-secs <NUMBER_OF_SECS>", &num_secs)) return 2;
        } else {
            fprintf(stderr, "error: Found argument '%s' which wasn't expected, or isn't valid in this context\n\n\tIf you tried to supply `%s` as a value rather than a flag, use `-- %s`\n\nUSAGE:\n    executable [OPTIONS]\n\nFor more information try --help\n", argv[i], argv[i], argv[i]);
            return 2;
        }
    }
    (void)language;
    if (!isatty(STDIN_FILENO)) {
        fputs("error: stdin must be a tty\n\nUSAGE:\n    thokr [OPTIONS]\n\nFor more information try --help\n", stderr);
        return 2;
    }
    char *generated = NULL;
    if (!prompt) {
        generated = make_prompt(words);
        prompt = generated;
    }
    int rc = run_tui(prompt, words, num_secs);
    free(generated);
    return rc;
}
