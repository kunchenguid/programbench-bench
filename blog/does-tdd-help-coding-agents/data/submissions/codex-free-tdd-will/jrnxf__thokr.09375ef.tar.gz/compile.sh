#!/bin/bash
set -euo pipefail
gcc -std=c11 -Wall -Wextra -O2 -o executable src/thokr.c
chmod +x executable
