#!/usr/bin/env python3
import csv
import json
import os
import re
import shlex
import sys
import zipfile
import xml.etree.ElementTree as ET
from collections import OrderedDict


HELP = """dsq (Version latest) - commandline SQL engine for data files

Usage:  dsq [file...] $query
        dsq $file [query]
        cat $file | dsq -s $filetype [query]
        dsq $file -f $queryfile

dsq is a tool for running SQL on one or more data files. It uses
SQLite's SQL dialect. Files as tables are accessible via "{N}" where N
is the 0-based index of the file in the commandline.

The shorthand "{}" is replaced with "{0}".

Examples:

    # This simply dumps the CSV as JSON
    $ dsq test.csv

    # This dumps the first 10 rows of the parquet file as JSON.
    $ dsq data.parquet "SELECT * FROM {} LIMIT 10"

    # This joins two datasets of differing origin types (CSV and JSON).
    $ dsq testdata/join/users.csv testdata/join/ages.json \\
          "select {0}.name, {1}.age from {0} join {1} on {0}.id = {1}.id"

See the repo for more details: https://github.com/multiprocessio/dsq"""


def die(msg, code=1):
    print(msg, file=sys.stderr)
    sys.exit(code)


def parse_args(argv):
    opts = {"pretty": False, "schema": False, "stream": None, "query_file": None}
    rest = []
    i = 0
    while i < len(argv):
        a = argv[i]
        if a in ("-h", "--help"):
            print(HELP)
            sys.exit(0)
        if a in ("--version", "version"):
            print("dsq latest")
            sys.exit(0)
        if a in ("-p", "--pretty"):
            opts["pretty"] = True
        elif a == "--schema":
            opts["schema"] = True
        elif a in ("-C", "--cache", "-i", "--interactive"):
            pass
        elif a in ("-s", "--stream", "--filetype"):
            i += 1
            if i >= len(argv):
                die("missing input format")
            opts["stream"] = argv[i]
        elif a in ("-f", "--file"):
            i += 1
            if i >= len(argv):
                die("missing query file")
            opts["query_file"] = argv[i]
        else:
            rest.append(a)
        i += 1
    if opts["query_file"]:
        with open(opts["query_file"], "r", encoding="utf-8") as f:
            query = f.read().strip()
        files = rest
    elif opts["schema"]:
        query = None
        files = rest
    elif rest and looks_like_query(rest[-1]):
        query = rest[-1]
        files = rest[:-1]
    else:
        query = "select * from {}"
        files = rest
    return opts, files, query


def looks_like_query(s):
    return bool(re.search(r"\b(select|with|pragma)\b", s, re.I)) or "{}" in s or re.search(r"\{\d+\}", s)


def detect_format(path, stream_fmt=None):
    if stream_fmt:
        return stream_fmt.lower().lstrip(".")
    ext = os.path.splitext(path)[1].lower().lstrip(".")
    if ext == "txt":
        return "csv"
    return ext


def load_source(path, fmt=None, data=None):
    if data is None:
        with open(path, "rb") as f:
            raw = f.read()
    else:
        raw = data
    text = raw.decode("utf-8", "replace")
    typ = detect_format(path, fmt)
    if typ in ("csv", "tsv"):
        return load_csv(text, "\t" if typ == "tsv" else ",")
    if typ in ("json", "ndjson", "jsonl"):
        return load_json(text, typ)
    if typ == "logfmt":
        return load_logfmt(text)
    if typ == "xlsx":
        return load_xlsx(raw)
    if typ == "ods":
        return load_ods(raw)
    first = text.splitlines()[0] if text.splitlines() else ""
    return load_csv(text, "\t" if "\t" in first else ",")


def load_csv(text, delim):
    rows = list(csv.reader(text.splitlines(), delimiter=delim))
    if not rows:
        return []
    headers = rows[0]
    out = []
    for row in rows[1:]:
        if not row:
            continue
        rec = OrderedDict()
        for i, h in enumerate(headers):
            rec[h] = row[i] if i < len(row) else ""
        out.append(rec)
    return out


def load_json(text, typ):
    s = text.strip()
    if not s:
        return []
    if typ in ("ndjson", "jsonl") or not s.startswith(("[", "{")):
        return [json.loads(line) for line in text.splitlines() if line.strip()]
    val = json.loads(s)
    if isinstance(val, list):
        return val
    if isinstance(val, dict):
        return [val]
    return [{"value": val}]


def load_logfmt(text):
    out = []
    for line in text.splitlines():
        if not line.strip():
            continue
        row = OrderedDict()
        lex = shlex.shlex(line, posix=True)
        lex.whitespace_split = True
        lex.commenters = ""
        for tok in lex:
            if "=" in tok:
                k, v = tok.split("=", 1)
                row[k] = v
        out.append(row)
    return out


def load_xlsx(raw):
    ns = {"a": "http://schemas.openxmlformats.org/spreadsheetml/2006/main"}
    with zipfile.ZipFile(__import__("io").BytesIO(raw)) as zf:
        shared = []
        if "xl/sharedStrings.xml" in zf.namelist():
            root = ET.fromstring(zf.read("xl/sharedStrings.xml"))
            for si in root.findall("a:si", ns):
                shared.append("".join(t.text or "" for t in si.findall(".//a:t", ns)))
        sheet_name = "xl/worksheets/sheet1.xml"
        root = ET.fromstring(zf.read(sheet_name))
    table = []
    max_col = 0
    for row in root.findall(".//a:sheetData/a:row", ns):
        vals = {}
        for c in row.findall("a:c", ns):
            ref = c.attrib.get("r", "")
            col = col_index(re.match(r"[A-Z]+", ref).group(0)) if re.match(r"[A-Z]+", ref) else len(vals)
            vals[col] = cell_value(c, shared, ns)
            max_col = max(max_col, col + 1)
        table.append([vals.get(i, "") for i in range(max_col)])
    if not table:
        return []
    headers = [str(x) for x in table[0]]
    out = []
    for cells in table[1:]:
        if not any(str(x) for x in cells):
            continue
        row = OrderedDict()
        for i, h in enumerate(headers):
            if h:
                row[h] = str(cells[i]) if i < len(cells) else ""
        out.append(row)
    return out


def col_index(s):
    n = 0
    for ch in s:
        n = n * 26 + ord(ch) - ord("A") + 1
    return n - 1


def cell_value(c, shared, ns):
    typ = c.attrib.get("t")
    if typ == "inlineStr":
        return "".join(t.text or "" for t in c.findall(".//a:t", ns))
    v = c.find("a:v", ns)
    if v is None or v.text is None:
        return ""
    if typ == "s":
        try:
            return shared[int(v.text)]
        except Exception:
            return v.text
    if typ == "b":
        return "TRUE" if v.text == "1" else "FALSE"
    return v.text


def load_ods(raw):
    ns = {
        "table": "urn:oasis:names:tc:opendocument:xmlns:table:1.0",
        "text": "urn:oasis:names:tc:opendocument:xmlns:text:1.0",
        "office": "urn:oasis:names:tc:opendocument:xmlns:office:1.0",
    }
    with zipfile.ZipFile(__import__("io").BytesIO(raw)) as zf:
        root = ET.fromstring(zf.read("content.xml"))
    table = root.find(".//table:table", ns)
    if table is None:
        return []
    rows = []
    for tr in table.findall("table:table-row", ns):
        repeat = int(tr.attrib.get("{urn:oasis:names:tc:opendocument:xmlns:table:1.0}number-rows-repeated", "1"))
        vals = []
        for cell in tr.findall("table:table-cell", ns):
            crep = int(cell.attrib.get("{urn:oasis:names:tc:opendocument:xmlns:table:1.0}number-columns-repeated", "1"))
            text = "\n".join("".join(p.itertext()) for p in cell.findall("text:p", ns))
            if not text:
                text = cell.attrib.get("{urn:oasis:names:tc:opendocument:xmlns:office:1.0}value", "")
            vals.extend([text] * min(crep, 1000))
        for _ in range(min(repeat, 1000)):
            rows.append(vals)
    while rows and not any(rows[-1]):
        rows.pop()
    if not rows:
        return []
    headers = [str(x) for x in rows[0]]
    out = []
    for vals in rows[1:]:
        if not any(vals):
            continue
        row = OrderedDict()
        for i, h in enumerate(headers):
            if h:
                row[h] = str(vals[i]) if i < len(vals) else ""
        out.append(row)
    return out


def shape_value(v):
    if v is None:
        return {"kind": "scalar", "scalar": "null"}
    if isinstance(v, bool):
        return {"kind": "scalar", "scalar": "boolean"}
    if isinstance(v, (int, float)):
        return {"kind": "scalar", "scalar": "number"}
    if isinstance(v, list):
        return {"kind": "array", "array": shape_value(v[0]) if v else {"kind": "unknown"}}
    if isinstance(v, dict):
        return {"kind": "object", "object": {k: shape_value(x) for k, x in v.items()}}
    return {"kind": "scalar", "scalar": "string"}


def merge_shapes(a, b):
    if a == b:
        return a
    if a.get("kind") == "object" and b.get("kind") == "object":
        keys = list(dict.fromkeys(list(a["object"].keys()) + list(b["object"].keys())))
        return {"kind": "object", "object": {k: merge_shapes(a["object"].get(k, {"kind": "scalar", "scalar": "null"}), b["object"].get(k, {"kind": "scalar", "scalar": "null"})) for k in keys}}
    vals = []
    for x in (a, b):
        if x.get("kind") == "varied":
            vals.extend(x["varied"])
        elif x not in vals:
            vals.append(x)
    return {"kind": "varied", "varied": vals}


def infer_shape(rows):
    if isinstance(rows, dict):
        return shape_value(rows)
    if not rows:
        return {"kind": "array", "array": {"kind": "unknown"}}
    sh = None
    for r in rows:
        cur = shape_value(r)
        sh = cur if sh is None else merge_shapes(sh, cur)
    return {"kind": "array", "array": sh}


def split_top(s, sep=","):
    parts, cur, depth, quote = [], [], 0, None
    i = 0
    while i < len(s):
        c = s[i]
        if quote:
            cur.append(c)
            if c == quote:
                quote = None
        else:
            if c in "'\"`":
                quote = c
                cur.append(c)
            elif c == "(":
                depth += 1
                cur.append(c)
            elif c == ")":
                depth -= 1
                cur.append(c)
            elif c == sep and depth == 0:
                parts.append("".join(cur).strip())
                cur = []
            else:
                cur.append(c)
        i += 1
    if cur or s.strip():
        parts.append("".join(cur).strip())
    return parts


def parse_query(q):
    q = q.strip().rstrip(";").replace("{}", "{0}")
    m = re.match(r"(?is)\s*select\s+(.*?)\s+from\s+(.+)$", q)
    if not m:
        die("Error: only SELECT queries are supported")
    select = m.group(1).strip()
    rest = m.group(2).strip()
    clauses = {}
    for name in ("limit", "group by", "order by", "where"):
        pass
    lower = rest.lower()
    positions = []
    for key in [" where ", " group by ", " order by ", " limit "]:
        idx = lower.find(key)
        if idx >= 0:
            positions.append((idx, key.strip()))
    positions.sort()
    from_part = rest[:positions[0][0]].strip() if positions else rest
    for n, (idx, key) in enumerate(positions):
        start = idx + len(" " + key + " ")
        end = positions[n + 1][0] if n + 1 < len(positions) else len(rest)
        clauses[key] = rest[start:end].strip()
    return {"select": split_top(select), "from": from_part, **clauses}


def prefixed_rows(tables):
    if len(tables) == 1:
        return [make_context([r], tables) for r in tables[0]]
    return []


def make_context(rows, tables):
    ctx = {}
    for ti, row in enumerate(rows):
        for k, v in row.items():
            ctx[k] = v
            ctx[f"{{{ti}}}.{k}"] = v
    return ctx


def build_contexts(spec, tables):
    if " join " not in spec.lower():
        return prefixed_rows(tables)
    m = re.match(r"(?is)\{(\d+)\}\s+join\s+\{(\d+)\}\s+on\s+(.+)$", spec.strip())
    if not m:
        die("Error: unsupported JOIN syntax")
    a, b, cond = int(m.group(1)), int(m.group(2)), m.group(3).strip()
    out = []
    for ra in tables[a]:
        for rb in tables[b]:
            ctx = make_context([ra, rb], tables)
            if eval_cond(cond, ctx):
                out.append(ctx)
    return out


def unquote(s):
    s = s.strip()
    if len(s) >= 2 and s[0] == s[-1] and s[0] in "'\"`":
        return s[1:-1]
    return s


def get_value(expr, ctx):
    expr = expr.strip()
    if re.match(r"^-?\d+(\.\d+)?$", expr):
        return float(expr) if "." in expr else int(expr)
    if len(expr) >= 2 and expr[0] == expr[-1] and expr[0] in "'\"":
        return expr[1:-1]
    if expr.startswith("`") and expr.endswith("`"):
        return ctx.get(expr[1:-1])
    if expr.lower() == "null":
        return None
    if expr in ctx:
        return ctx[expr]
    if "." in expr:
        return ctx.get(expr)
    return ctx.get(unquote(expr), "")


def cmp_values(a, b, op):
    def num(x):
        try:
            return float(x)
        except Exception:
            return None
    if op.lower() == "like":
        pat = "^" + re.escape(str(b)).replace("%", ".*").replace("_", ".") + "$"
        return re.match(pat, str(a)) is not None
    na, nb = num(a), num(b)
    if na is not None and nb is not None:
        a, b = na, nb
    else:
        a, b = "" if a is None else str(a), "" if b is None else str(b)
    return {"=": a == b, "==": a == b, "!=": a != b, "<>": a != b, ">": a > b, "<": a < b, ">=": a >= b, "<=": a <= b}[op]


def eval_cond(cond, ctx):
    cond = cond.strip()
    ors = re.split(r"(?i)\s+or\s+", cond)
    if len(ors) > 1:
        return any(eval_cond(x, ctx) for x in ors)
    ands = re.split(r"(?i)\s+and\s+", cond)
    if len(ands) > 1:
        return all(eval_cond(x, ctx) for x in ands)
    m = re.match(r"(?is)(.+?)\s+(like)\s+(.+)$", cond)
    if not m:
        m = re.match(r"(?is)(.+?)\s*(>=|<=|<>|!=|==|=|>|<)\s*(.+)$", cond)
    if not m:
        return bool(get_value(cond, ctx))
    return cmp_values(get_value(m.group(1), ctx), get_value(m.group(3), ctx), m.group(2))


def output_name(expr):
    expr = expr.strip()
    m = re.match(r"(?is)(.+?)\s+as\s+(.+)$", expr)
    if m:
        return unquote(m.group(2))
    if "." in expr:
        return expr.split(".")[-1]
    return unquote(expr)


def project(expr, ctx):
    expr = expr.strip()
    m = re.match(r"(?is)(.+?)\s+as\s+(.+)$", expr)
    if m:
        expr = m.group(1).strip()
    return get_value(expr, ctx)


def run_query(query, tables):
    pq = parse_query(query)
    contexts = build_contexts(pq["from"], tables)
    if "where" in pq:
        contexts = [c for c in contexts if eval_cond(pq["where"], c)]
    sels = pq["select"]
    if "group by" in pq:
        gexpr = pq["group by"].strip()
        groups = OrderedDict()
        for c in contexts:
            groups.setdefault(project(gexpr, c), []).append(c)
        rows = []
        for key, items in groups.items():
            row = OrderedDict()
            for e in sels:
                if re.match(r"(?i)^count\s*\(\s*\*\s*\)", e):
                    row[output_name(e)] = len(items)
                else:
                    row[output_name(e)] = project(e, items[0])
            rows.append(row)
    else:
        rows = []
        for c in contexts:
            if len(sels) == 1 and sels[0] == "*":
                row = OrderedDict((k, v) for k, v in c.items() if not k.startswith("{"))
            else:
                row = OrderedDict()
                for e in sels:
                    if re.match(r"(?i)^count\s*\(\s*\*\s*\)", e):
                        row[output_name(e)] = len(contexts)
                    else:
                        row[output_name(e)] = project(e, c)
            rows.append(row)
            if len(sels) == 1 and re.match(r"(?i)^count\s*\(\s*\*\s*\)", sels[0]):
                break
    if "order by" in pq:
        key = pq["order by"].strip()
        desc = bool(re.search(r"(?i)\s+desc$", key))
        key = re.sub(r"(?i)\s+(asc|desc)$", "", key).strip()
        rows.sort(key=lambda r: r.get(output_name(key), ""), reverse=desc)
    if "limit" in pq:
        try:
            rows = rows[: int(pq["limit"].split()[0])]
        except Exception:
            pass
    return rows


def dumps_rows(rows):
    parts = [json_safe(json.dumps(r, ensure_ascii=False, separators=(",", ":"))) for r in rows]
    return "[" + ",\n".join(parts) + "]"


def json_safe(s):
    return s.replace("<", "\\u003c").replace(">", "\\u003e").replace("&", "\\u0026")


def pretty(rows):
    cols = list(rows[0].keys()) if rows else []
    widths = {c: len(str(c)) for c in cols}
    for r in rows:
        for c in cols:
            widths[c] = max(widths[c], len(str(r.get(c, ""))))
    sep = "+" + "+".join("-" * (widths[c] + 2) for c in cols) + "+"
    lines = [sep, "| " + " | ".join(str(c).ljust(widths[c]) for c in cols) + " |", sep]
    for r in rows:
        lines.append("| " + " | ".join(str(r.get(c, "")).ljust(widths[c]) for c in cols) + " |")
    lines.extend([sep, f"({len(rows)} rows)"])
    return "\n".join(lines)


def main():
    opts, files, query = parse_args(sys.argv[1:])
    if not files:
        data = sys.stdin.buffer.read()
        if not opts["stream"]:
            die("Need -s <format> when reading from stdin")
        tables = [load_source("<stdin>", opts["stream"], data)]
    else:
        tables = [load_source(f) for f in files]
    if opts["schema"]:
        target = tables[0] if len(tables) == 1 else {str(i): t for i, t in enumerate(tables)}
        print(json_safe(json.dumps(infer_shape(target), indent=2, ensure_ascii=False)))
        return
    rows = run_query(query, tables)
    print(pretty(rows) if opts["pretty"] else dumps_rows(rows))


if __name__ == "__main__":
    main()
