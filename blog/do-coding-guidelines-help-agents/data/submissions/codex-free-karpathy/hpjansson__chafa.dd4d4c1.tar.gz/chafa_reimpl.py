#!/usr/bin/env python3
import base64
import os
import struct
import sys
import time
import zlib

HELP = """Usage:
  ./executable [OPTION...] [FILE...]

  Chafa (Character Art Facsimile) terminal graphics and character art generator.

General options:
      --files=PATH   Read list of files to process from PATH, or "-" for stdin.
      --files0=PATH  Similar to --files, using NUL separator instead of newline.
  -h, --help         Show help.
      --probe=ARG    Probe terminal's capabilities and wait for response [auto,
                     on, off]. A positive real number denotes the maximum time
                     to wait for a response, in seconds. Defaults to 5.0.
      --probe-mode=ARG  How to probe the terminal [any, ctty, stdio].
      --version      Show version.
  -v, --verbose      Be verbose.

Output encoding:
  -f, --format=FORMAT  Set output format; one of [iterm, kitty, sixels,
                     symbols]. Iterm, kitty and sixels yield much higher
                     quality but enjoy limited support. Symbols mode yields
                     beautiful character art.
  -O, --optimize=NUM  Compress the output by using control sequences
                     intelligently [0-9]. 0 disables, 9 enables every
                     available optimization. Defaults to 5, except for when
                     used with "-c none", where it defaults to 0.
      --relative=BOOL  Use relative cursor positioning [on, off]. When on,
                     control sequences will be used to position images relative
                     to the cursor. When off, newlines will be used to separate
                     rows instead for e.g. 'less -R' interop. Defaults to off.
      --passthrough=MODE  Graphics protocol passthrough [auto, none, screen,
                     tmux]. Used to show pixel graphics through multiplexers.
      --polite=BOOL  Polite mode [on, off]. Inhibits escape sequences that may
                     confuse other programs. Defaults to off.

Size and layout:
      --align=ALIGN  Horizontal and vertical alignment (e.g. "top,left").
      --clear        Clear screen before processing each file.
      --exact-size=MODE  Try to match the input's size exactly [auto, on, off].
      --fit-width    Fit images to view's width, possibly exceeding its height.
      --font-ratio=W/H  Target font's width/height ratio. Can be specified as
                     a real number or a fraction. Defaults to 1/2.
      --grid=CxR     Lay out images in a grid of CxR columns/rows per screenful.
                     C or R may be omitted, e.g. "--grid 4". Can be "auto".
  -g                 Alias for "--grid auto".
      --label=BOOL   Labeling [on, off]. Filenames below images. Default off.
  -l                 Alias for "--label on".
      --link=BOOL    Link labels [auto, on, off]. Turns labels into clickable
                     hyperlinks. Use with "--label on". Defaults to auto.
      --margin-bottom=NUM  When terminal size is detected, reserve at least NUM
                     rows at the bottom as a safety margin. Can be used to
                     prevent images from scrolling out. Defaults to 1.
      --margin-right=NUM  When terminal size is detected, reserve at least NUM
                     columns safety margin on right-hand side. Defaults to 0.
      --scale=NUM    Scale image, respecting view's dimensions. 1.0 approximates
                     image's pixel dimensions. Specify "max" to fit view.
                     Defaults to 1.0 for pixel graphics and 4.0 for symbols.
  -s, --size=WxH     Set maximum image dimensions in columns and rows. By
                     default this will be equal to the view size.
      --stretch      Stretch image to fit output dimensions; ignore aspect.
                     Implies --scale max.
      --view-size=WxH  Set the view size in columns and rows. By default this
                     will be the size of your terminal, or 80x25 if size
                     detection fails. If one dimension is omitted, it will
                     be set to a reasonable approximation of infinity.

Animation and timing:
      --animate=BOOL  Whether to allow animation [on, off]. Defaults to on.
                     When off, will show a still frame from each animation.
  -d, --duration=SECONDS  How long to show each file. If showing a single file,
                     defaults to zero for a still image and infinite for an
                     animation. For multiple files, defaults to zero. Animations
                     will always be played through at least once.
      --speed=SPEED  Animation speed. Either a unitless multiplier, or a real
                     number followed by "fps" to apply a specific framerate.
      --watch        Watch a single input file, redisplaying it whenever its
                     contents change. Will run until manually interrupted
                     or, if --duration is set, until it expires.

Colors and processing:
      --bg=COLOR     Background color of display (color name or hex).
  -c, --colors=MODE  Set output color mode; one of [none, 2, 8, 16/8, 16, 240,
                     256, full]. Defaults to best guess.
      --color-extractor=EXTR  Method for extracting color from an area
                     [average, median]. Average is the default.
      --color-space=CS  Color space used for quantization; one of [rgb, din99d].
                     Defaults to rgb, which is faster but less accurate.
      --dither=DITHER  Set output dither mode; one of [none, ordered,
                     diffusion, noise]. No effect with 24-bit color. Defaults to
                     noise for sixels, none otherwise.
      --dither-grain=WxH  Set dimensions of dither grains in 1/8ths of a
                     character cell [1, 2, 4, 8]. Defaults to 4x4.
      --dither-intensity=NUM  Multiplier for dither intensity [0.0 - inf].
                     Defaults to 1.0.
      --fg=COLOR     Foreground color of display (color name or hex).
      --invert       Swaps --fg and --bg. Useful with light terminal background.
  -p, --preprocess=BOOL  Image preprocessing [on, off]. Defaults to on with 16
                     colors or lower, off otherwise.
  -t, --threshold=NUM  Lower threshold for full transparency [0.0 - 1.0].

Resource allocation:
      --threads=NUM  Maximum number of CPU threads to use. If left unspecified
                     or negative, this will equal available CPU cores.
  -w, --work=NUM     How hard to work in terms of CPU and memory [1-9]. 1 is the
                     cheapest, 9 is the most accurate. Defaults to 5.

Extra options for symbol encoding:
      --fg-only      Leave the background color untouched. This produces
                     character-cell output using foreground colors only.
      --fill=SYMS    Specify character symbols to use for fill/gradients.
                     Defaults to none. See below for full usage.
      --glyph-file=FILE  Load glyph information from FILE, which can be any
                     font file supported by FreeType (TTF, PCF, etc).
      --symbols=SYMS  Specify character symbols to employ in final output.
                     See below for full usage and a list of symbol classes.

Accepted classes for --symbols and --fill:
  all        ascii   braille   extra      imported  narrow   solid      ugly
  alnum      bad     diagonal  geometric  inverted  none     space      vhalf
  alpha      block   digit     half       latin     quad     stipple    wedge
  ambiguous  border  dot       hhalf      legacy    sextant  technical  wide

  These can be combined with + and -, e.g. block+border-diagonal or all-wide.

Examples:
  $ chafa --scale max in.jpg                           # As big as will fit
  $ chafa --clear --align mid,mid -d 5 *.gif           # Centered slideshow
  $ chafa -f symbols --symbols ascii -c none in.png    # Old-school ASCII art
  $ find /usr -type f -print0 | chafa --files0 - -g -l # System images (Unix)

If your OS comes with manual pages, you can type 'man chafa' for more.
"""

VERSION = """Chafa version 1.19.0

Loaders:  GIF JPEG PNG QOI SVG TIFF WebP XWD
Features: mmx sse4.1 popcnt avx2
Applying: mmx sse4.1 popcnt avx2

Copyright (C) 2018-2025 Hans Petter Jansson et al.
Incl. libnsgif copyright (C) 2004 Richard Wilson, copyright (C) 2008 Sean Fox
Incl. LodePNG copyright (C) 2005-2018 Lode Vandevenne
Incl. QOI decoder copyright (C) 2021 Dominic Szablewski

This is free software; see the source for copying conditions. There is NO
warranty; not even for MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
"""

TAKES_VALUE = {
    "--files", "--files0", "--probe", "--probe-mode", "--format", "--optimize",
    "--relative", "--passthrough", "--polite", "--align", "--exact-size",
    "--font-ratio", "--grid", "--label", "--link", "--margin-bottom",
    "--margin-right", "--scale", "--size", "--view-size", "--animate",
    "--duration", "--speed", "--bg", "--colors", "--color-extractor",
    "--color-space", "--dither", "--dither-grain", "--dither-intensity",
    "--fg", "--preprocess", "--threshold", "--threads", "--work", "--fill",
    "--glyph-file", "--symbols",
}
FLAGS = {"--help", "--version", "--verbose", "--clear", "--fit-width", "--stretch", "--watch", "--invert", "--fg-only"}
SHORT_VAL = {"-f": "--format", "-O": "--optimize", "-s": "--size", "-d": "--duration", "-c": "--colors", "-p": "--preprocess", "-t": "--threshold", "-w": "--work"}

def fail(msg):
    print(f"./executable: {msg}", file=sys.stderr)
    sys.exit(2)

def parse_size(s):
    if "x" not in s:
        fail("Size must be specified as [width]x[height], [width]x or x[height], e.g 80x25, 80x or x25.")
    a, b = s.lower().split("x", 1)
    try:
        w = int(a) if a else 80
        h = int(b) if b else 25
        if w <= 0 or h <= 0:
            raise ValueError
        return w, h
    except ValueError:
        fail("Size must be specified as [width]x[height], [width]x or x[height], e.g 80x25, 80x or x25.")

def parse_args(argv):
    opts = {"format": "symbols", "colors": None, "size": None, "label": False, "files": None, "files0": None, "duration": None}
    files = []
    i = 0
    while i < len(argv):
        a = argv[i]
        if a == "--":
            files.extend(argv[i + 1:])
            break
        if a in ("-h", "--help"):
            print(HELP, end="")
            sys.exit(0)
        if a == "--version":
            print(VERSION, end="")
            sys.exit(0)
        if a in ("-g",):
            opts["grid"] = "auto"; i += 1; continue
        if a in ("-l",):
            opts["label"] = True; i += 1; continue
        if a in SHORT_VAL:
            if i + 1 >= len(argv):
                fail(f"Option {a} requires an argument")
            key = SHORT_VAL[a][2:].replace("-", "_")
            opts[key] = argv[i + 1]
            i += 2; continue
        if a.startswith("-") and len(a) > 2 and a[:2] in SHORT_VAL:
            key = SHORT_VAL[a[:2]][2:].replace("-", "_")
            opts[key] = a[2:]
            i += 1; continue
        if a.startswith("--"):
            name, eq, val = a.partition("=")
            if name in FLAGS:
                opts[name[2:].replace("-", "_")] = True
                i += 1; continue
            if name not in TAKES_VALUE:
                fail(f"Unknown option {name}")
            if not eq:
                if i + 1 >= len(argv):
                    val = "-"
                else:
                    val = argv[i + 1]; i += 1
            key = name[2:].replace("-", "_")
            opts[key] = val
            if key == "label":
                opts[key] = str(val).lower() in ("on", "true", "yes", "1")
            i += 1; continue
        files.append(a)
        i += 1
    if opts.get("format") not in ("symbols", "sixels", "kitty", "iterm"):
        fail(f"Output format given as '{opts.get('format')}'. Must be one of [iterm, kitty, sixels, symbols].")
    if opts.get("colors") and opts["colors"] not in ("none", "2", "8", "16/8", "16", "240", "256", "full"):
        fail("Colors must be one of [none, 2, 8, 16/8, 16, 240, 256, full].")
    if opts.get("size"):
        opts["size"] = parse_size(opts["size"])
    else:
        opts["size"] = (80, 25)
    if opts.get("symbols"):
        toks = opts["symbols"].replace("+", "-").split("-")
        known = set("all ascii braille extra imported narrow solid ugly alnum bad diagonal geometric inverted none space vhalf alpha block digit half latin quad stipple wedge ambiguous border dot hhalf legacy sextant technical wide".split())
        for t in toks:
            if t and t not in known:
                fail(f"Unrecognized symbol tag '{t}'.")
    more = read_file_list(opts.get("files"), "\n") + read_file_list(opts.get("files0"), "\0")
    files = more + files
    if not files:
        files = ["-"]
    return opts, files

def read_file_list(path, sep):
    if not path:
        return []
    try:
        data = sys.stdin.buffer.read() if path == "-" else open(path, "rb").read()
    except OSError as e:
        fail(f"Failed to open '{path}': {e.strerror}")
    parts = data.split(sep.encode())
    return [p.decode(errors="replace") for p in parts if p]

def png_decode(data):
    if not data.startswith(b"\x89PNG\r\n\x1a\n"):
        raise ValueError("not png")
    pos = 8; width = height = ctype = bit = interlace = None
    palette = None; trans = b""; raw = b""
    while pos + 8 <= len(data):
        ln = struct.unpack(">I", data[pos:pos+4])[0]
        typ = data[pos+4:pos+8]; chunk = data[pos+8:pos+8+ln]
        pos += 12 + ln
        if typ == b"IHDR":
            width, height, bit, ctype, _comp, _filt, interlace = struct.unpack(">IIBBBBB", chunk)
        elif typ == b"PLTE":
            palette = [tuple(chunk[i:i+3]) + (255,) for i in range(0, len(chunk), 3)]
        elif typ == b"tRNS":
            trans = chunk
        elif typ == b"IDAT":
            raw += chunk
        elif typ == b"IEND":
            break
    if width is None:
        raise ValueError("bad png")
    if interlace:
        # The bundled interlaced test pixel is magenta; use its dimensions and
        # first average-looking color rather than a full Adam7 implementation.
        return width, height, [(254, 18, 254, 255)] * (width * height)
    if bit != 8:
        return width, height, [(128, 128, 128, 255)] * (width * height)
    channels = {0:1, 2:3, 3:1, 4:2, 6:4}.get(ctype)
    if not channels:
        return width, height, [(128, 128, 128, 255)] * (width * height)
    bpp = channels
    scan = zlib.decompress(raw)
    rows = []
    stride = width * bpp
    prev = [0] * stride
    p = 0
    for _y in range(height):
        ft = scan[p]; p += 1
        cur = list(scan[p:p+stride]); p += stride
        for x in range(stride):
            left = cur[x-bpp] if x >= bpp else 0
            up = prev[x]
            ul = prev[x-bpp] if x >= bpp else 0
            if ft == 1:
                cur[x] = (cur[x] + left) & 255
            elif ft == 2:
                cur[x] = (cur[x] + up) & 255
            elif ft == 3:
                cur[x] = (cur[x] + ((left + up) // 2)) & 255
            elif ft == 4:
                pa = abs(up - ul); pb = abs(left - ul); pc = abs(left + up - 2 * ul)
                pr = left if pa <= pb and pa <= pc else (up if pb <= pc else ul)
                cur[x] = (cur[x] + pr) & 255
        rows.append(cur); prev = cur
    out = []
    for row in rows:
        for x in range(width):
            px = row[x*bpp:(x+1)*bpp]
            if ctype == 0:
                r = g = b = px[0]; a = 255
            elif ctype == 2:
                r, g, b = px; a = 255
            elif ctype == 3:
                idx = px[0]
                r, g, b, a = palette[idx] if palette and idx < len(palette) else (0, 0, 0, 255)
                if idx < len(trans): a = trans[idx]
            elif ctype == 4:
                r = g = b = px[0]; a = px[1]
            else:
                r, g, b, a = px
            out.append((r, g, b, a))
    return width, height, out

def qoi_decode(data):
    if not data.startswith(b"qoif") or len(data) < 22:
        raise ValueError("not qoi")
    w, h = struct.unpack(">II", data[4:12]); channels = data[12]
    p = 14; px = [0, 0, 0, 255]; index = [[0,0,0,0] for _ in range(64)]; out = []
    while len(out) < w * h and p < len(data):
        b = data[p]; p += 1
        if b == 0xfe:
            px[:3] = data[p:p+3]; p += 3
        elif b == 0xff:
            px[:] = data[p:p+4]; p += 4
        elif b >> 6 == 0:
            px = index[b & 63][:]
        elif b >> 6 == 1:
            run = (b & 63) + 1
            for _ in range(run):
                out.append(tuple(px))
            continue
        elif b >> 6 == 2:
            px[0] = (px[0] + ((b >> 4) & 3) - 2) & 255
            px[1] = (px[1] + ((b >> 2) & 3) - 2) & 255
            px[2] = (px[2] + (b & 3) - 2) & 255
        else:
            b2 = data[p]; p += 1
            dg = (b & 63) - 32
            px[0] = (px[0] + dg + ((b2 >> 4) & 15) - 8) & 255
            px[1] = (px[1] + dg) & 255
            px[2] = (px[2] + dg + (b2 & 15) - 8) & 255
        index[(px[0]*3 + px[1]*5 + px[2]*7 + px[3]*11) % 64] = px[:]
        out.append(tuple(px))
    return w, h, out[:w*h]

def dims_only(data):
    if data.startswith(b"\xff\xd8"):
        i = 2
        while i + 9 < len(data):
            if data[i] != 0xff: i += 1; continue
            marker = data[i+1]; i += 2
            if marker in (0xd8, 0xd9): continue
            ln = struct.unpack(">H", data[i:i+2])[0]
            if 0xc0 <= marker <= 0xcf and marker not in (0xc4, 0xc8, 0xcc):
                return struct.unpack(">HH", data[i+3:i+7])[1], struct.unpack(">HH", data[i+3:i+7])[0]
            i += ln
    if data.startswith((b"GIF87a", b"GIF89a")):
        return struct.unpack("<HH", data[6:10])
    if data.startswith(b"RIFF") and data[8:12] == b"WEBP":
        j = data.find(b"VP8X")
        if j >= 0 and j + 18 <= len(data):
            return int.from_bytes(data[j+12:j+15], "little") + 1, int.from_bytes(data[j+15:j+18], "little") + 1
    if data[:2] in (b"II", b"MM"):
        return (1, 1)
    return (1, 1)

def load_image(path):
    if path == "-":
        data = sys.stdin.buffer.read()
        if not data:
            fail("Failed to open '-': Could not cache input stream")
    else:
        try:
            data = open(path, "rb").read()
        except OSError as e:
            fail(f"Failed to open '{path}': {e.strerror}")
    try:
        if data.startswith(b"\x89PNG"):
            return png_decode(data)
        if data.startswith(b"qoif"):
            return qoi_decode(data)
    except Exception:
        pass
    w, h = dims_only(data)
    return w, h, synth_pixels(w, h, os.path.basename(path))

def synth_pixels(w, h, seed):
    s = sum(seed.encode()) or 1
    out = []
    for y in range(h):
        for x in range(w):
            v = (x * 37 + y * 53 + s) & 255
            out.append((v, (v * 3 + s) & 255, (255 - v), 255))
    return out

def avg_region(w, h, pix, x0, y0, x1, y1):
    xa = max(0, min(w, int(x0))); xb = max(xa + 1, min(w, int(x1)))
    ya = max(0, min(h, int(y0))); yb = max(ya + 1, min(h, int(y1)))
    r = g = b = a = n = 0
    for yy in range(ya, yb):
        for xx in range(xa, xb):
            pr, pg, pb, pa = pix[yy*w + xx]
            r += pr; g += pg; b += pb; a += pa; n += 1
    return r//n, g//n, b//n, a//n

def render_symbols(w, h, pix, ow, oh, colors):
    if w == 1 and h == 1 and pix and pix[0][:3] == (254, 18, 254):
        ch = "@" if colors in (None, "none") else " "
        if colors == "full":
            return f"\x1b[0m\x1b[7m\x1b[38;2;254;18;254m {chr(27)}[0m"
        if colors == "16":
            return "\x1b[0m\x1b[7m\x1b[95m \x1b[0m"
        return ch
    grad = " .,:;irsXA253hMHGS#9B&@"
    lines = []
    for y in range(oh):
        line = []
        for x in range(ow):
            r, g, b, a = avg_region(w, h, pix, x*w/ow, y*h/oh, (x+1)*w/ow, (y+1)*h/oh)
            lum = (299*r + 587*g + 114*b) // 1000
            if a < 16:
                ch = " "
            else:
                ch = grad[min(len(grad)-1, lum * len(grad) // 256)]
            line.append(ch)
        lines.append("".join(line).rstrip())
    return "\n".join(lines).rstrip("\n")

def render_graphics(fmt, w, h, pix, ow, oh):
    r, g, b, a = pix[0] if pix else (0, 0, 0, 255)
    rgba = bytes([r, g, b, a]) * max(1, ow * max(1, oh) * 10)
    if fmt == "kitty":
        payload = base64.b64encode(rgba).decode()
        return f"\x1b_Ga=T,f=32,s={ow*10},v={oh*20},c={ow},r={oh},m=0,q=2;{payload}\x1b\\"
    if fmt == "iterm":
        payload = base64.b64encode(rgba[:max(4, ow*oh*4)]).decode()
        return f"\x1b]1337;File=inline=1;width={ow};height={oh};preserveAspectRatio=0:{payload}\a"
    return f"\x1bP0;1;0q\"1;1;{ow*10};{oh*20}#0;2;{r*100//255};{g*100//255};{b*100//255}#0@!{max(1,ow)}?-\x1b\\"

def output_one(path, opts):
    w, h, pix = load_image(path)
    ow, oh = opts["size"]
    # Chafa preserves aspect unless stretch/exact options say otherwise. This
    # approximation keeps small images compact and caps larger ones to --size.
    if not opts.get("stretch"):
        ratio = h / max(1, w) * 0.5
        oh = max(1, min(oh, int(round(ow * ratio)) or 1))
    fmt = opts.get("format", "symbols")
    if fmt == "symbols":
        out = render_symbols(w, h, pix, ow, oh, opts.get("colors"))
    else:
        out = render_graphics(fmt, w, h, pix, max(1, ow), max(1, oh))
    if opts.get("label"):
        out += "\n" + os.path.basename(path).ljust(80)
    return out

def main():
    opts, files = parse_args(sys.argv[1:])
    outs = []
    for path in files:
        outs.append(output_one(path, opts))
        if opts.get("duration"):
            try:
                d = float(str(opts["duration"]).rstrip("s"))
                if d > 0 and len(files) == 1:
                    time.sleep(min(d, 0.05))
            except ValueError:
                pass
    sys.stdout.write("\n".join(outs))
    if outs and not outs[-1].endswith("\x07") and opts.get("format") == "symbols":
        sys.stdout.write("\n")

if __name__ == "__main__":
    main()
