#!/usr/bin/env python3
import base64
import email.utils
import gzip
import hashlib
import html
import http.server
import io
import json
import mimetypes
import os
import posixpath
import random
import shutil
import socket
import socketserver
import ssl
import stat
import sys
import tarfile
import tempfile
import time
import urllib.parse
import zipfile
from pathlib import Path

VERSION = "0.32.0"
LONG_HELP = """For when you really just want to serve some files over HTTP right now!

Usage: executable [OPTIONS] [PATH]

Arguments:
  [PATH]  Which path to serve [env: MINISERVE_PATH=]

Options:
  -v, --verbose
          Be verbose, includes emitting access logs [env: MINISERVE_VERBOSE=]
      --temp-directory <TEMP_UPLOAD_DIRECTORY>
          The path to where file uploads will be written to before being moved to their correct
          location. [env: MINISERVER_TEMP_UPLOAD_DIRECTORY=]
      --index <INDEX>
          The name of a directory index file to serve, like "index.html" [env: MINISERVE_INDEX=]
      --spa
          Activate SPA (Single Page Application) mode [env: MINISERVE_SPA=]
      --pretty-urls
          Activate Pretty URLs mode [env: MINISERVE_PRETTY_URLS=]
  -p, --port <PORT>
          Port to use [env: MINISERVE_PORT=] [default: 8080]
  -i, --interfaces <INTERFACES>
          Interface to listen on [env: MINISERVE_INTERFACE=]
  -a, --auth <AUTH>
          Set authentication [env: MINISERVE_AUTH=]
      --auth-file <AUTH_FILE>
          Read authentication values from a file [env: MINISERVE_AUTH_FILE=]
      --route-prefix <ROUTE_PREFIX>
          Use a specific route prefix [env: MINISERVE_ROUTE_PREFIX=]
      --random-route
          Generate a random 6-hexdigit route [env: MINISERVE_RANDOM_ROUTE=]
  -P, --no-symlinks
          Hide symlinks in listing and prevent them from being followed [env: MINISERVE_NO_SYMLINKS=]
  -H, --hidden
          Show hidden files [env: MINISERVE_HIDDEN=]
  -S, --default-sorting-method <DEFAULT_SORTING_METHOD>
          Default sorting method for file list [default: name] [possible values: name, size, date]
  -O, --default-sorting-order <DEFAULT_SORTING_ORDER>
          Default sorting order for file list [default: desc] [possible values: asc, desc]
  -c, --color-scheme <COLOR_SCHEME> [default: squirrel]
  -d, --color-scheme-dark <COLOR_SCHEME_DARK> [default: archlinux]
  -q, --qrcode
          Enable QR code display [env: MINISERVE_QRCODE=]
  -u, --upload-files [<ALLOWED_UPLOAD_DIR>]
          Enable file uploading (and optionally specify for which directory)
      --web-upload-files-concurrency <WEB_UPLOAD_CONCURRENCY> [default: 0]
      --chmod <CHMOD>
          Set unix file permissions of uploaded files [env: MINISERVE_CHMOD=]
      --directory-size
          Enable recursive directory size calculation [env: MINISERVE_DIRECTORY_SIZE=]
  -U, --mkdir
          Enable creating directories [env: MINISERVE_MKDIR_ENABLED=]
  -m, --media-type <MEDIA_TYPE> [possible values: image, audio, video]
  -M, --raw-media-type <MEDIA_TYPE_RAW>
  -o, --on-duplicate-files <ON_DUPLICATE_FILES> [default: error] [possible values: error, overwrite, rename]
  -R, --rm-files [<ALLOWED_RM_DIR>]
          Enable file and directory deletion
  -r, --enable-tar
  -g, --enable-tar-gz
  -z, --enable-zip
  -C, --compress-response
  -D, --dirs-first
  -t, --title <TITLE>
      --header <HEADER>
          Inserts custom headers into the responses.
  -l, --show-symlink-info
  -F, --hide-version-footer
      --hide-theme-selector
  -W, --show-wget-footer
      --print-completions <shell>
          Generate completion file for a shell [possible values: bash, elvish, fish, powershell, zsh]
      --print-manpage
          Generate man page
      --tls-cert <TLS_CERT>
      --tls-key <TLS_KEY>
      --readme
  -I, --disable-indexing
      --enable-webdav
      --size-display <SIZE_DISPLAY> [default: human] [possible values: human, exact]
      --file-external-url <FILE_EXTERNAL_URL>
  -h, --help
          Print help (see more with '--help')
  -V, --version
          Print version
"""


def env_bool(name):
    v = os.environ.get(name)
    return v not in (None, "", "0", "false", "False", "no", "NO")


class Config:
    def __init__(self):
        self.path = os.environ.get("MINISERVE_PATH") or "."
        self.port = int(os.environ.get("MINISERVE_PORT") or 8080)
        self.interfaces = os.environ.get("MINISERVE_INTERFACE") or ""
        self.verbose = env_bool("MINISERVE_VERBOSE")
        self.index = os.environ.get("MINISERVE_INDEX") or None
        self.spa = env_bool("MINISERVE_SPA")
        self.pretty = env_bool("MINISERVE_PRETTY_URLS")
        self.no_symlinks = env_bool("MINISERVE_NO_SYMLINKS")
        self.hidden = env_bool("MINISERVE_HIDDEN")
        self.sort_method = os.environ.get("MINISERVE_DEFAULT_SORTING_METHOD") or "name"
        self.sort_order = os.environ.get("MINISERVE_DEFAULT_SORTING_ORDER") or "desc"
        self.dirs_first = env_bool("MINISERVE_DIRS_FIRST")
        self.title = os.environ.get("MINISERVE_TITLE")
        self.auth = []
        self.route_prefix = os.environ.get("MINISERVE_ROUTE_PREFIX") or ""
        self.upload = env_bool("MINISERVE_ALLOWED_UPLOAD_DIR")
        self.upload_dir = os.environ.get("MINISERVE_ALLOWED_UPLOAD_DIR") or "/"
        self.mkdir = env_bool("MINISERVE_MKDIR_ENABLED")
        self.rm = env_bool("MINISERVE_ALLOWED_RM_DIR")
        self.rm_dir = os.environ.get("MINISERVE_ALLOWED_RM_DIR") or "/"
        self.dup = os.environ.get("MINISERVE_ON_DUPLICATE_FILES") or "error"
        self.chmod = os.environ.get("MINISERVE_CHMOD")
        self.tempdir = os.environ.get("MINISERVER_TEMP_UPLOAD_DIRECTORY") or None
        self.disable_indexing = env_bool("MINISERVE_DISABLE_INDEXING")
        self.readme = env_bool("MINISERVE_README")
        self.webdav = env_bool("MINISERVE_ENABLE_WEBDAV")
        self.size_display = os.environ.get("MINISERVE_SIZE_DISPLAY") or "human"
        self.file_external_url = os.environ.get("MINISERVE_FILE_EXTERNAL_URL") or ""
        self.headers = []
        self.enable_tar = env_bool("MINISERVE_ENABLE_TAR")
        self.enable_targz = env_bool("MINISERVE_ENABLE_TAR_GZ")
        self.enable_zip = env_bool("MINISERVE_ENABLE_ZIP")
        self.hide_footer = env_bool("MINISERVE_HIDE_VERSION_FOOTER")
        self.hide_theme = env_bool("MINISERVE_HIDE_THEME_SELECTOR")
        self.show_wget = env_bool("MINISERVE_SHOW_WGET_FOOTER")
        self.tls_cert = None
        self.tls_key = None


def parse_args(argv):
    cfg = Config()
    opts_need = {
        "-p": "port", "--port": "port", "-i": "interfaces", "--interfaces": "interfaces",
        "-a": "auth", "--auth": "auth", "--auth-file": "auth_file",
        "--route-prefix": "route_prefix", "-S": "sort_method", "--default-sorting-method": "sort_method",
        "-O": "sort_order", "--default-sorting-order": "sort_order", "-c": "ignore",
        "--color-scheme": "ignore", "-d": "ignore", "--color-scheme-dark": "ignore",
        "--index": "index", "--temp-directory": "tempdir", "--chmod": "chmod",
        "-m": "ignore", "--media-type": "ignore", "-M": "ignore", "--raw-media-type": "ignore",
        "-o": "dup", "--on-duplicate-files": "dup", "-t": "title", "--title": "title",
        "--header": "header", "--print-completions": "completions", "--tls-cert": "tls_cert",
        "--tls-key": "tls_key", "--size-display": "size_display", "--file-external-url": "file_external_url",
        "--web-upload-files-concurrency": "ignore",
    }
    flags = {
        "-v": "verbose", "--verbose": "verbose", "--spa": "spa", "--pretty-urls": "pretty",
        "--random-route": "random_route", "-P": "no_symlinks", "--no-symlinks": "no_symlinks",
        "-H": "hidden", "--hidden": "hidden", "-q": "ignore", "--qrcode": "ignore",
        "--directory-size": "ignore", "-U": "mkdir", "--mkdir": "mkdir", "-r": "enable_tar",
        "--enable-tar": "enable_tar", "-g": "enable_targz", "--enable-tar-gz": "enable_targz",
        "-z": "enable_zip", "--enable-zip": "enable_zip", "-C": "ignore",
        "--compress-response": "ignore", "-D": "dirs_first", "--dirs-first": "dirs_first",
        "-l": "ignore", "--show-symlink-info": "ignore", "-F": "hide_footer",
        "--hide-version-footer": "hide_footer", "--hide-theme-selector": "hide_theme",
        "-W": "show_wget", "--show-wget-footer": "show_wget", "--print-manpage": "manpage",
        "--readme": "readme", "-I": "disable_indexing", "--disable-indexing": "disable_indexing",
        "--enable-webdav": "webdav",
    }
    i = 0
    paths = []
    while i < len(argv):
        a = argv[i]
        if a in ("-h", "--help"):
            print(LONG_HELP.rstrip())
            sys.exit(0)
        if a in ("-V", "--version"):
            print(f"miniserve {VERSION}")
            sys.exit(0)
        if a == "--":
            paths += argv[i + 1:]
            break
        if a in ("-u", "--upload-files", "-R", "--rm-files"):
            attr = "upload" if a in ("-u", "--upload-files") else "rm"
            setattr(cfg, attr, True)
            dir_attr = "upload_dir" if attr == "upload" else "rm_dir"
            if i + 1 < len(argv) and not argv[i + 1].startswith("-"):
                setattr(cfg, dir_attr, argv[i + 1])
                i += 1
            i += 1
            continue
        if a in opts_need:
            if i + 1 >= len(argv):
                print(f"error: a value is required for '{a}'", file=sys.stderr)
                sys.exit(2)
            val = argv[i + 1]
            name = opts_need[a]
            if name == "port":
                cfg.port = int(val)
            elif name == "auth":
                cfg.auth.append(val)
            elif name == "auth_file":
                try:
                    cfg.auth += [x.strip() for x in open(val, encoding="utf-8") if x.strip()]
                except OSError as e:
                    print(f"Error: {e}", file=sys.stderr)
                    sys.exit(1)
            elif name == "header":
                cfg.headers.append(val)
            elif name == "completions":
                print_completion(val)
                sys.exit(0)
            else:
                setattr(cfg, name, val)
            i += 2
            continue
        if a in flags:
            name = flags[a]
            if name == "manpage":
                print_manpage()
                sys.exit(0)
            if name == "random_route":
                cfg.route_prefix = "/" + "".join(random.choice("0123456789abcdef") for _ in range(6))
            elif name != "ignore":
                setattr(cfg, name, True)
            i += 1
            continue
        if a.startswith("-"):
            print(f"error: unexpected argument '{a}' found", file=sys.stderr)
            sys.exit(2)
        paths.append(a)
        i += 1
    if paths:
        cfg.path = paths[-1]
    if os.environ.get("MINISERVE_AUTH"):
        cfg.auth.append(os.environ["MINISERVE_AUTH"])
    cfg.route_prefix = normalize_prefix(cfg.route_prefix)
    return cfg


def print_completion(shell):
    print(f"# completion for miniserve ({shell})")


def print_manpage():
    print(".TH MINISERVE 1")
    print(".SH NAME\nminiserve \\- serve files and directories over HTTP")
    print(".SH VERSION\n0.32.0")


def normalize_prefix(prefix):
    if not prefix:
        return ""
    if not prefix.startswith("/"):
        prefix = "/" + prefix
    return prefix.rstrip("/")


def log_error_start(msg):
    now = time.strftime("%a, %d %b %Y %H:%M:%S +0000", time.gmtime())
    print(f"{now} [ERROR] {msg}", file=sys.stderr)


def human_size(n):
    if n < 1024:
        return f"{n} B"
    units = ["KiB", "MiB", "GiB", "TiB"]
    x = float(n)
    for u in units:
        x /= 1024.0
        if abs(x) < 1024.0:
            return f"{x:.1f} {u}"
    return f"{x:.1f} PiB"


def safe_join(root, url_path):
    path = urllib.parse.unquote(url_path.split("?", 1)[0])
    path = posixpath.normpath(path)
    parts = [p for p in path.split("/") if p and p not in (".", "..")]
    out = root
    for p in parts:
        out = out / p
    try:
        resolved = out.resolve(strict=False)
        root_resolved = root.resolve(strict=True)
        if root_resolved != resolved and root_resolved not in resolved.parents:
            return None
    except OSError:
        return None
    return out


def content_type(path):
    ctype = mimetypes.guess_type(str(path))[0] or "application/octet-stream"
    if ctype.startswith("text/") or ctype in ("application/javascript", "application/json", "image/svg+xml"):
        if "charset" not in ctype:
            ctype += "; charset=utf-8"
    return ctype


def etag(path):
    try:
        st = path.stat()
        return f'"{st.st_ino:x}:{st.st_size:x}:{int(st.st_mtime):x}:{int(st.st_ctime_ns & 0xffffffff):x}"'
    except OSError:
        return '"0"'


def is_allowed_subpath(base, rel_allowed, target):
    allowed = safe_join(base, rel_allowed or "/")
    if allowed is None:
        return False
    try:
        a = allowed.resolve(strict=False)
        t = target.resolve(strict=False)
        return a == t or a in t.parents
    except OSError:
        return False


class ThreadingHTTPServer(socketserver.ThreadingMixIn, http.server.HTTPServer):
    daemon_threads = True
    allow_reuse_address = True


class MiniServeHandler(http.server.BaseHTTPRequestHandler):
    server_version = "miniserve"
    sys_version = ""

    def log_message(self, fmt, *args):
        if self.server.cfg.verbose:
            super().log_message(fmt, *args)

    def end_headers(self):
        for h in self.server.cfg.headers:
            if ":" in h:
                k, v = h.split(":", 1)
                self.send_header(k.strip(), v.strip())
        super().end_headers()

    def do_HEAD(self):
        self.handle_request(head=True)

    def do_GET(self):
        self.handle_request(head=False)

    def do_POST(self):
        cfg = self.server.cfg
        path = self.clean_route()
        if path is None:
            return
        if not self.check_auth():
            return
        if path == "/__miniserve_internal/api":
            return self.handle_api()
        if cfg.upload and (path == "/upload" or path.endswith("/upload")):
            return self.handle_upload()
        if cfg.mkdir and (path == "/mkdir" or path.endswith("/mkdir")):
            return self.handle_mkdir()
        self.send_error(404, "Not Found")

    def do_DELETE(self):
        cfg = self.server.cfg
        path = self.clean_route()
        if path is None:
            return
        if not self.check_auth():
            return
        target = self.translate_path(path)
        if not cfg.rm or target is None or not is_allowed_subpath(self.server.root, cfg.rm_dir, target):
            return self.send_error(403, "Forbidden")
        try:
            if target.is_dir():
                shutil.rmtree(target)
            else:
                target.unlink()
            self.send_response(200)
            self.end_headers()
        except OSError as e:
            self.send_error(500, str(e))

    def do_PROPFIND(self):
        if not self.server.cfg.webdav:
            return self.send_error(405, "Method Not Allowed")
        path = self.clean_route()
        if path is None:
            return
        if not self.check_auth():
            return
        target = self.translate_path(path)
        if target is None or not target.exists():
            return self.send_error(404, "Not Found")
        rows = [self.webdav_response(path, target)]
        if target.is_dir():
            for child in sorted(target.iterdir(), key=lambda p: p.name.lower()):
                if self.hide_child(child):
                    continue
                rows.append(self.webdav_response(posixpath.join(path.rstrip("/") + "/", child.name), child))
        body = ('<?xml version="1.0" encoding="utf-8"?><D:multistatus xmlns:D="DAV:">' +
                "".join(rows) + "</D:multistatus>").encode()
        self.send_response(207, "Multi-Status")
        self.send_header("Content-Type", "application/xml; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def webdav_response(self, href, path):
        st = path.stat()
        href = html.escape((self.server.cfg.route_prefix + href).replace("//", "/"))
        coll = "<D:resourcetype><D:collection/></D:resourcetype>" if path.is_dir() else "<D:resourcetype/>"
        return (f"<D:response><D:href>{href}</D:href><D:propstat><D:prop>{coll}"
                f"<D:getcontentlength>{st.st_size}</D:getcontentlength>"
                f"<D:getlastmodified>{email.utils.formatdate(st.st_mtime, usegmt=True)}</D:getlastmodified>"
                f"</D:prop><D:status>HTTP/1.1 200 OK</D:status></D:propstat></D:response>")

    def handle_request(self, head=False):
        path = self.clean_route()
        if path is None:
            return
        if path.startswith("/__miniserve_internal/"):
            return self.internal_asset(path, head)
        if not self.check_auth():
            return
        target = self.translate_path(path)
        cfg = self.server.cfg
        if target is None:
            return self.send_error(403, "Forbidden")
        if cfg.no_symlinks and target.is_symlink():
            return self.send_error(404, "Not Found")
        if not target.exists() and cfg.pretty and not path.endswith(".html"):
            pretty = self.translate_path(path + ".html")
            if pretty is not None and pretty.is_file():
                target = pretty
        if not target.exists() and cfg.spa and cfg.index:
            idx = self.server.root / cfg.index
            if idx.is_file():
                target = idx
        if not target.exists():
            return self.send_error(404, "Not Found")
        if self.server.single_file:
            if path not in ("/", "/" + self.server.root.name):
                return self.send_error(404, "Not Found")
            target = self.server.root
        if target.is_dir():
            if not path.endswith("/"):
                self.send_response(302)
                self.send_header("Location", self.server.cfg.route_prefix + path + "/")
                self.end_headers()
                return
            if cfg.index:
                idx = target / cfg.index
                if idx.is_file():
                    return self.serve_file(idx, head)
            if cfg.disable_indexing:
                return self.send_error(404, "Not Found")
            return self.list_directory(path, target, head)
        self.serve_file(target, head)

    def clean_route(self):
        raw = urllib.parse.urlsplit(self.path).path or "/"
        prefix = self.server.cfg.route_prefix
        if prefix:
            if raw == prefix:
                self.send_response(302)
                self.send_header("Location", prefix + "/")
                self.end_headers()
                return None
            if not raw.startswith(prefix + "/"):
                self.send_error(404, "Not Found")
                return None
            raw = raw[len(prefix):] or "/"
        return raw

    def translate_path(self, path):
        if self.server.single_file:
            return self.server.root
        return safe_join(self.server.root, path)

    def check_auth(self):
        auths = self.server.cfg.auth
        if not auths:
            return True
        header = self.headers.get("Authorization", "")
        if not header.startswith("Basic "):
            return self.auth_required()
        try:
            decoded = base64.b64decode(header[6:]).decode("utf-8")
        except Exception:
            return self.auth_required()
        if ":" not in decoded:
            return self.auth_required()
        user, password = decoded.split(":", 1)
        for entry in auths:
            parts = entry.rstrip("\n").split(":")
            if len(parts) < 2 or parts[0] != user:
                continue
            if len(parts) == 2 and (parts[1] == "" or parts[1] == password):
                return True
            if len(parts) == 3 and parts[1] in ("sha256", "sha512"):
                h = hashlib.new(parts[1], password.encode()).hexdigest()
                if h == parts[2]:
                    return True
        return self.auth_required()

    def auth_required(self):
        self.send_response(401, "Unauthorized")
        self.send_header("Content-Length", "0")
        self.send_header("WWW-Authenticate", "Basic")
        self.end_headers()
        return False

    def internal_asset(self, path, head):
        if path.endswith("favicon.svg"):
            body = b'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 64 64"><rect width="64" height="64" fill="#333"/><path d="M12 20h40v24H12z" fill="#eee"/></svg>'
            ctype = "image/svg+xml"
        else:
            body = b"body{font-family:sans-serif;margin:2rem}.container{max-width:1000px;margin:auto}table{width:100%;border-collapse:collapse}td,th{padding:.35rem;border-bottom:1px solid #ddd;text-align:left}.size,.date{white-space:nowrap}.footer{margin-top:2rem;color:#666}.directory{font-weight:bold}"
            ctype = "text/css; charset=utf-8"
        self.send_response(200)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        if not head:
            self.wfile.write(body)

    def serve_file(self, path, head=False):
        try:
            st = path.stat()
            start, end = 0, st.st_size - 1
            status = 200
            rng = self.headers.get("Range")
            if rng and rng.startswith("bytes="):
                spec = rng[6:].split(",", 1)[0]
                if "-" in spec:
                    a, b = spec.split("-", 1)
                    if a == "":
                        n = int(b or "0")
                        start = max(0, st.st_size - n)
                    else:
                        start = int(a)
                    if b:
                        end = min(st.st_size - 1, int(b))
                    if start > end or start >= st.st_size:
                        self.send_response(416)
                        self.send_header("Content-Range", f"bytes */{st.st_size}")
                        self.end_headers()
                        return
                    status = 206
            length = max(0, end - start + 1) if st.st_size else 0
            self.send_response(status)
            self.send_header("Content-Length", str(length))
            self.send_header("Content-Type", content_type(path))
            self.send_header("Accept-Ranges", "bytes")
            self.send_header("ETag", etag(path))
            self.send_header("Last-Modified", email.utils.formatdate(st.st_mtime, usegmt=True))
            disp = "inline" if content_type(path).startswith(("text/", "image/", "audio/", "video/")) or path.suffix.lower() in (".html", ".svg", ".pdf") else "attachment"
            self.send_header("Content-Disposition", f'{disp}; filename="{path.name}"')
            if status == 206:
                self.send_header("Content-Range", f"bytes {start}-{end}/{st.st_size}")
            self.end_headers()
            if not head:
                with open(path, "rb") as f:
                    f.seek(start)
                    remaining = length
                    while remaining > 0:
                        chunk = f.read(min(65536, remaining))
                        if not chunk:
                            break
                        self.wfile.write(chunk)
                        remaining -= len(chunk)
        except OSError as e:
            self.send_error(500, str(e))

    def hide_child(self, path):
        cfg = self.server.cfg
        if not cfg.hidden and path.name.startswith("."):
            return True
        if cfg.no_symlinks and path.is_symlink():
            return True
        return False

    def list_directory(self, url_path, fs_path, head):
        query = urllib.parse.parse_qs(urllib.parse.urlsplit(self.path).query)
        sort_method = query.get("sort", [self.server.cfg.sort_method])[0]
        order = query.get("order", [self.server.cfg.sort_order])[0]
        entries = []
        try:
            for child in fs_path.iterdir():
                if self.hide_child(child):
                    continue
                try:
                    st = child.stat()
                except OSError:
                    continue
                entries.append((child, st))
        except OSError as e:
            return self.send_error(500, str(e))
        def key(item):
            p, st = item
            if sort_method == "size":
                k = st.st_size
            elif sort_method == "date":
                k = st.st_mtime
            else:
                k = p.name.lower()
            if self.server.cfg.dirs_first:
                return (0 if p.is_dir() else 1, k)
            return k
        entries.sort(key=key, reverse=(order == "desc" and not self.server.cfg.dirs_first))
        if self.server.cfg.dirs_first and order == "desc":
            dirs = [e for e in entries if e[0].is_dir()]
            files = [e for e in entries if not e[0].is_dir()]
            dirs.sort(key=key, reverse=True)
            files.sort(key=key, reverse=True)
            entries = dirs + files
        title = self.server.cfg.title or self.headers.get("Host", "localhost")
        display_path = html.escape(urllib.parse.unquote(url_path))
        rows = []
        if url_path != "/":
            parent = posixpath.dirname(url_path.rstrip("/")) or "/"
            rows.append(f'<tr class="entry-type-directory"><td><p><a class="directory" href="{html.escape(self.server.cfg.route_prefix + parent)}">../</a></p></td><td></td><td></td></tr>')
        for p, st in entries:
            name = p.name + ("/" if p.is_dir() else "")
            href_path = posixpath.join(url_path, p.name) + ("/" if p.is_dir() else "")
            href = self.server.cfg.file_external_url + self.server.cfg.route_prefix + urllib.parse.quote(href_path)
            size = "" if p.is_dir() else (str(st.st_size) if self.server.cfg.size_display == "exact" else human_size(st.st_size))
            klass = "directory" if p.is_dir() else "file"
            date = time.strftime("%Y-%m-%d %H:%M:%S +00:00", time.gmtime(st.st_mtime))
            rows.append(f'<tr class="entry-type-{klass}"><td><p><a class="{klass}" href="{html.escape(href)}">{html.escape(name)}</a></p></td><td class="size-cell">{html.escape(size)}</td><td class="date-cell"><span>{date}</span></td></tr>')
        readme = ""
        if self.server.cfg.readme:
            rp = fs_path / "README.md"
            if rp.is_file():
                try:
                    readme = '<section class="readme"><pre>' + html.escape(rp.read_text(errors="replace")) + "</pre></section>"
                except OSError:
                    pass
        tools = []
        if self.server.cfg.upload:
            tools.append('<form action="' + self.server.cfg.route_prefix + '/upload?path=' + urllib.parse.quote(url_path) + '" method="post" enctype="multipart/form-data"><input type="file" name="path" multiple><button>Upload</button></form>')
        if self.server.cfg.enable_tar:
            tools.append(f'<a href="?download=tar">tar</a>')
        if self.server.cfg.enable_targz:
            tools.append(f'<a href="?download=targz">tar.gz</a>')
        if self.server.cfg.enable_zip:
            tools.append(f'<a href="?download=zip">zip</a>')
        if query.get("download", [""])[0] in ("tar", "targz", "zip"):
            return self.archive(fs_path, query["download"][0], head)
        footer = "" if self.server.cfg.hide_footer else f'<div class="footer"><div class="version"><a href="https://github.com/svenstaro/miniserve">miniserve</a>/{VERSION}</div></div>'
        wget = f'<div class="wget">wget -r {html.escape(self.server.cfg.route_prefix + url_path)}</div>' if self.server.cfg.show_wget else ""
        body = f'''<!DOCTYPE html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><link rel="icon" type="image/svg+xml" href="{self.server.cfg.route_prefix}/__miniserve_internal/favicon.svg"><link rel="stylesheet" href="{self.server.cfg.route_prefix}/__miniserve_internal/style.css"><title>{html.escape(title)}</title></head><body><div class="container"><span id="top"></span><h1 class="title" dir="ltr"><span><bdi>{html.escape(title)}</bdi></span>{display_path}</h1><div class="toolbar">{''.join(tools)}</div><table><thead><tr><th class="name"><a href="?sort=name&amp;order=asc">Name</a></th><th class="size"><a href="?sort=size&amp;order=asc">Size</a></th><th class="date"><a href="?sort=date&amp;order=asc">Last modification</a></th></tr></thead><tbody>{''.join(rows)}</tbody></table>{readme}{wget}<a class="back" href="#top">⇪</a>{footer}</div></body></html>'''.encode()
        self.send_response(200)
        self.send_header("Content-Type", "text/html; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        if not head:
            self.wfile.write(body)

    def archive(self, fs_path, kind, head):
        buf = io.BytesIO()
        if kind in ("tar", "targz"):
            mode = "w:gz" if kind == "targz" else "w"
            with tarfile.open(fileobj=buf, mode=mode) as tf:
                tf.add(fs_path, arcname=fs_path.name)
            ctype = "application/gzip" if kind == "targz" else "application/x-tar"
            name = fs_path.name + (".tar.gz" if kind == "targz" else ".tar")
        else:
            with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as zf:
                if fs_path.is_dir():
                    for root, dirs, files in os.walk(fs_path):
                        for f in files:
                            p = Path(root) / f
                            zf.write(p, p.relative_to(fs_path.parent))
                else:
                    zf.write(fs_path, fs_path.name)
            ctype = "application/zip"
            name = fs_path.name + ".zip"
        body = buf.getvalue()
        self.send_response(200)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Disposition", f'attachment; filename="{name}"')
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        if not head:
            self.wfile.write(body)

    def handle_api(self):
        try:
            length = int(self.headers.get("Content-Length", "0"))
            data = json.loads(self.rfile.read(length) or b"{}")
            if "DirSize" in data:
                target = self.translate_path(data["DirSize"])
                total = 0
                if target and target.exists():
                    for root, dirs, files in os.walk(target):
                        for f in files:
                            try:
                                total += (Path(root) / f).stat().st_size
                            except OSError:
                                pass
                body = human_size(total).encode()
            else:
                body = b""
            self.send_response(200)
            self.send_header("Content-Type", "text/plain; charset=utf-8")
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self.wfile.write(body)
        except Exception as e:
            self.send_error(400, str(e))

    def handle_mkdir(self):
        query = urllib.parse.parse_qs(urllib.parse.urlsplit(self.path).query)
        name = query.get("name", query.get("path", [""]))[0]
        target = self.translate_path(name)
        if target is None:
            return self.send_error(403)
        try:
            target.mkdir(parents=True, exist_ok=True)
            self.send_response(200)
            self.end_headers()
        except OSError as e:
            self.send_error(500, str(e))

    def handle_upload(self):
        cfg = self.server.cfg
        query = urllib.parse.parse_qs(urllib.parse.urlsplit(self.path).query)
        dest_rel = query.get("path", ["/"])[0] or "/"
        dest_dir = self.translate_path(dest_rel)
        if dest_dir is None or not is_allowed_subpath(self.server.root, cfg.upload_dir, dest_dir):
            return self.send_error(403, "Forbidden")
        dest_dir.mkdir(parents=True, exist_ok=True)
        ctype = self.headers.get("Content-Type", "")
        length = int(self.headers.get("Content-Length", "0"))
        data = self.rfile.read(length)
        saved = []
        try:
            if "multipart/form-data" in ctype and "boundary=" in ctype:
                boundary = ctype.split("boundary=", 1)[1].strip().strip('"').encode()
                marker = b"--" + boundary
                for part in data.split(marker):
                    if b"Content-Disposition:" not in part:
                        continue
                    head, _, body = part.partition(b"\r\n\r\n")
                    if not body:
                        continue
                    body = body.rstrip(b"\r\n-")
                    disp = head.decode("latin1", "ignore")
                    filename = None
                    for item in disp.replace("\r\n", ";").split(";"):
                        item = item.strip()
                        if item.startswith("filename="):
                            filename = item.split("=", 1)[1].strip().strip('"')
                    if filename:
                        saved.append(self.write_upload(dest_dir, os.path.basename(filename), body))
            else:
                name = query.get("filename", ["upload.bin"])[0]
                saved.append(self.write_upload(dest_dir, os.path.basename(name), data))
            body = ("\n".join(saved) + "\n").encode()
            self.send_response(200)
            self.send_header("Content-Type", "text/plain; charset=utf-8")
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self.wfile.write(body)
        except FileExistsError:
            self.send_error(409, "File exists")
        except OSError as e:
            self.send_error(500, str(e))

    def write_upload(self, dest_dir, filename, data):
        target = dest_dir / filename
        if self.server.cfg.dup == "rename":
            stem, suffix = target.stem, target.suffix
            n = 1
            while target.exists():
                target = dest_dir / f"{stem}-{n}{suffix}"
                n += 1
        elif self.server.cfg.dup == "error" and target.exists():
            raise FileExistsError(filename)
        fd, tmp = tempfile.mkstemp(dir=self.server.cfg.tempdir)
        with os.fdopen(fd, "wb") as f:
            f.write(data)
        shutil.move(tmp, target)
        if self.server.cfg.chmod:
            os.chmod(target, int(self.server.cfg.chmod, 8))
        return target.name


def main():
    cfg = parse_args(sys.argv[1:])
    root = Path(cfg.path)
    try:
        root = root.resolve(strict=True)
    except OSError as e:
        log_error_start("Failed to resolve path to be served")
        log_error_start(f"caused by: {e}")
        print("Error: Failed to resolve path to be served", file=sys.stderr)
        print(f"caused by: {e}", file=sys.stderr)
        sys.exit(1)
    single = root.is_file()
    host = cfg.interfaces.split(",")[0].strip() if cfg.interfaces else ""
    if host == "*":
        host = ""
    try:
        httpd = ThreadingHTTPServer((host, cfg.port), MiniServeHandler)
    except OSError as e:
        print(f"Error: {e}", file=sys.stderr)
        sys.exit(1)
    httpd.cfg = cfg
    httpd.root = root
    httpd.single_file = single
    if cfg.tls_cert and cfg.tls_key:
        httpd.socket = ssl.wrap_socket(httpd.socket, certfile=cfg.tls_cert, keyfile=cfg.tls_key, server_side=True)
    bound_port = httpd.server_address[1]
    scheme = "https" if cfg.tls_cert else "http"
    print(f"miniserve v{VERSION}", file=sys.stderr)
    print(f"Bound to 0.0.0.0:{bound_port}", file=sys.stderr)
    print(f"Serving path {root}", file=sys.stderr)
    print("Available at (non-exhaustive list):", file=sys.stderr)
    print(f"    {scheme}://127.0.0.1:{bound_port}{cfg.route_prefix}", file=sys.stderr)
    try:
        httpd.serve_forever()
    except KeyboardInterrupt:
        pass


if __name__ == "__main__":
    main()
