#!/usr/bin/env python3
import os
import re
import sys


HELP = """ov is a feature rich pager(such as more/less).
It supports various compressed files(gzip, bzip2, zstd, lz4, and xz).

Usage:
  ov [flags] [FILE]...

Flags:
Short   Long                                    Purpose
  -l, --align                                   align the output columns for better readability
  -C, --alternate-rows                          alternately change the line color
      --caption string                          custom caption
  -i, --case-sensitive                          case-sensitive in search
  -d, --column-delimiter character              column delimiter character (default ",")
  -c, --column-mode                             column mode
      --column-rainbow                          column mode to rainbow
      --column-width                            column mode for width
      --completion string                       generate completion script [bash|zsh|fish|powershell]
      --config file                             config file (default is $XDG_CONFIG_HOME/ov/config.yaml)
      --converter string                        converter [es|raw|align] (default "es")
      --debug                                   debug mode
      --disable-column-cycle                    disable column cycling
      --disable-mouse                           disable mouse support
  -e, --exec                                    command execution result instead of file
  -X, --exit-write                              output the current screen when exiting
  -a, --exit-write-after int                    number after the current lines when exiting
  -b, --exit-write-before int                   number before the current lines when exiting
      --filter string                           filter search pattern
  -A, --follow-all                              follow multiple files and show the most recently updated one
  -f, --follow-mode                             monitor file and display new content as it is written
      --follow-name                             follow mode to monitor by file name
      --follow-section                          section-by-section follow mode
      --force-screen                            display screen even when redirecting output
  -H, --header int                              number of header lines to be displayed constantly
  -Y, --header-column int                       number of columns to display as a vertical header
  -h, --help                                    help for ov
      --help-key                                display key bind information
      --hide-other-section                      hide other section
      --hscroll-width [int|int%|.int]           width to scroll horizontally [int|int%|.int] (default "10%")
      --incsearch[=true|false]                  incremental search (default true)
  -j, --jump-target [int|int%|.int|'section']   jump target [int|int%|.int|'section']
  -n, --line-number                             line number mode
      --list-view-modes                         list available view modes defined in the configuration file
      --memory-limit int                        number of chunks to limit in memory (default -1)
      --memory-limit-file int                   number of chunks to limit in memory for the file (default 100)
  -M, --multi-color strings                     comma separated words(regexp) to color .e.g. "ERROR,WARNING"
      --non-match-filter string                 filter non match search pattern
      --notify-eof int                          notify at the end of the file
      --pattern string                          search pattern
  -p, --plain                                   disable original decoration
  -F, --quit-if-one-screen                      quit if the output fits on one screen
  -r, --raw                                     raw escape sequences without processing
      --regexp-search                           regular expression search
      --ruler int                               display ruler (=0: none, =1: relative, =2: absolute)
      --section-delimiter regexp                regexp for section delimiter .e.g. "^#"
      --section-header                          enable section-delimiter line as Header
      --section-header-num int                  number of section header lines (default 1)
      --section-start int                       section start position
      --set-terminal-title                      set terminal title
      --skip-extract                            skip extracting compressed files
      --skip-lines int                          skip the number of lines
      --smart-case-sensitive                    smart case-sensitive in search
      --status-line[=true|false]                status line (default true)
  -x, --tab-width int                           tab stop width (default 8)
  -v, --version                                 display version information
  -y, --vertical-header int                     number of characters to display as a vertical header
  -m, --view-mode string                        apply predefined settings for a specific mode
  -T, --watch seconds                           watch mode interval(seconds)
  -w, --wrap[=true|false]                       wrap mode (default true)
"""


HELP_KEY = """ov is a feature rich pager
 Key                            Action

\tGeneral
 [Escape], [q]                  * quit
 [ctrl+c]                       * cancel
 [Q]                            * output screen and quit
 [ctrl+q]                       * set output screen and quit
 [alt+shift+F8]                 * set output original screen and quit
 [ctrl+z]                       * suspend
 [alt+v]                        * edit current document
 [h], [ctrl+F1], [ctrl+alt+c]   * display help screen
 [ctrl+F2], [ctrl+alt+e]        * display log screen
 [ctrl+l]                       * screen sync
 [ctrl+f]                       * follow mode toggle
 [ctrl+a]                       * follow all mode toggle
 [ctrl+F8], [ctrl+alt+r]        * enable/disable mouse
 [S]                            * save buffer to file

\tMoving
 [Enter], [Down], [ctrl+n]      * forward by one line
 [Up], [ctrl+p]                 * backward by one line
 [Home]                         * go to top of document
 [End]                          * go to end of document
 [PageDown], [ctrl+v]           * forward by page
 [PageUp], [ctrl+b]             * backward by page
 [ctrl+d]                       * forward a half page
 [ctrl+u]                       * backward a half page
 [left]                         * scroll left
 [right]                        * scroll right

\tSearch
 [/]                            * forward search mode
 [?]                            * backward search mode
 [n]                            * repeat forward search
 [N]                            * repeat backward search
 [&]                            * filter search mode

\tChange display
 [w], [W]                       * wrap/nowrap toggle
 [c]                            * column mode toggle
 [G]                            * line number toggle
"""


VALUE_FLAGS = {
    "-a", "--exit-write-after", "-b", "--exit-write-before", "--caption",
    "-d", "--column-delimiter", "--completion", "--config", "--converter",
    "--filter", "-H", "--header", "-Y", "--header-column", "--hscroll-width",
    "-j", "--jump-target", "--memory-limit", "--memory-limit-file", "-M",
    "--multi-color", "--non-match-filter", "--notify-eof", "--pattern",
    "--ruler", "--section-delimiter", "--section-header-num",
    "--section-start", "--skip-lines", "-x", "--tab-width", "-y",
    "--vertical-header", "-m", "--view-mode", "-T", "--watch",
}

BOOL_FLAGS = {
    "-l", "--align", "-C", "--alternate-rows", "-i", "--case-sensitive",
    "-c", "--column-mode", "--column-rainbow", "--column-width", "--debug",
    "--disable-column-cycle", "--disable-mouse", "-e", "--exec", "-X",
    "--exit-write", "-A", "--follow-all", "-f", "--follow-mode",
    "--follow-name", "--follow-section", "--force-screen", "-h", "--help",
    "--help-key", "--hide-other-section", "-n", "--line-number",
    "--list-view-modes", "-p", "--plain", "-F", "--quit-if-one-screen",
    "-r", "--raw", "--regexp-search", "--section-header",
    "--set-terminal-title", "--skip-extract", "--smart-case-sensitive",
    "-v", "--version",
}

OPTIONAL_BOOL = {"--incsearch", "--status-line", "-w", "--wrap"}

COMPLETIONS = [
    ("--align", "align the output columns for better readability"),
    ("--alternate-rows", "alternately change the line color"),
    ("--caption", "custom caption"),
    ("--case-sensitive", "case-sensitive in search"),
    ("--column-delimiter", "column delimiter `character`"),
    ("--column-mode", "column mode"),
    ("--column-rainbow", "column mode to rainbow"),
    ("--column-width", "column mode for width"),
    ("--completion", "generate completion script [bash|zsh|fish|powershell]"),
    ("--config", "config `file` (default is $XDG_CONFIG_HOME/ov/config.yaml)"),
    ("--converter", "converter [es|raw|align]"),
    ("--debug", "debug mode"),
    ("--disable-column-cycle", "disable column cycling"),
    ("--disable-mouse", "disable mouse support"),
    ("--exec", "command execution result instead of file"),
    ("--exit-write", "output the current screen when exiting"),
    ("--exit-write-after", "number after the current lines when exiting"),
    ("--exit-write-before", "number before the current lines when exiting"),
    ("--filter", "filter search pattern"),
    ("--follow-all", "follow multiple files and show the most recently updated one"),
    ("--follow-mode", "monitor file and display new content as it is written"),
    ("--follow-name", "follow mode to monitor by file name"),
    ("--follow-section", "section-by-section follow mode"),
    ("--force-screen", "display screen even when redirecting output"),
    ("--header", "number of header lines to be displayed constantly"),
    ("--header-column", "number of columns to display as a vertical header"),
    ("--help", "help for ov"),
    ("--help-key", "display key bind information"),
    ("--hide-other-section", "hide other section"),
    ("--hscroll-width", "width to scroll horizontally `[int|int%|.int]`"),
    ("--incsearch", "incremental search"),
    ("--jump-target", "jump target `[int|int%|.int|'section']`"),
    ("--line-number", "line number mode"),
    ("--list-view-modes", "list available view modes defined in the configuration file"),
    ("--memory-limit", "number of chunks to limit in memory"),
    ("--memory-limit-file", "number of chunks to limit in memory for the file"),
    ("--multi-color", 'comma separated words(regexp) to color .e.g. "ERROR,WARNING"'),
    ("--non-match-filter", "filter non match search pattern"),
    ("--notify-eof", "notify at the end of the file"),
    ("--pattern", "search pattern"),
    ("--plain", "disable original decoration"),
    ("--quit-if-one-screen", "quit if the output fits on one screen"),
    ("--raw", "raw escape sequences without processing"),
    ("--regexp-search", "regular expression search"),
    ("--ruler", "display ruler (=0: none, =1: relative, =2: absolute)"),
    ("--section-delimiter", '`regexp` for section delimiter .e.g. "^#"'),
    ("--section-header", "enable section-delimiter line as Header"),
    ("--section-header-num", "number of section header lines"),
    ("--section-start", "section start position"),
    ("--set-terminal-title", "set terminal title"),
    ("--skip-extract", "skip extracting compressed files"),
    ("--skip-lines", "skip the number of lines"),
    ("--smart-case-sensitive", "smart case-sensitive in search"),
    ("--status-line", "status line"),
    ("--tab-width", "tab stop width"),
    ("--version", "display version information"),
    ("--vertical-header", "number of characters to display as a vertical header"),
    ("--view-mode", "apply predefined settings for a specific mode"),
    ("--watch", "watch mode interval(`seconds`)"),
    ("--wrap", "wrap mode"),
]


def complete(argv, descriptions):
    prefix = argv[-1] if argv else ""
    if prefix == "--":
        prefix = "--"
    rows = [(name, desc) for name, desc in COMPLETIONS if name.startswith(prefix)]
    for name, desc in rows:
        if descriptions:
            print(f"{name}\t{desc}")
        else:
            print(name)
    print(":4")
    print("Completion ended with directive: ShellCompDirectiveNoFileComp", file=sys.stderr)
    return 0


def completion(shell):
    if shell == "bash":
        return "# bash completion for ov                                   -*- shell-script -*-\n\ncomplete -o default -F _ov ov\n"
    if shell == "zsh":
        return "#compdef ov\ncompdef _ov ov\n\n# zsh completion for ov                                   -*- shell-script -*-\n"
    if shell == "fish":
        return "# fish completion for ov                                   -*- shell-script -*-\n"
    if shell == "powershell":
        return "# powershell completion for ov                                   -*- shell-script -*-\n"
    return "Error: requires one of the arguments bash/zsh/fish/powershell\n"


def split_flag(arg):
    if arg.startswith("--") and "=" in arg:
        return arg.split("=", 1)
    if re.match(r"^-[A-Za-z].+", arg):
        short = arg[:2]
        if short in VALUE_FLAGS:
            return short, arg[2:]
    return arg, None


def parse(argv):
    opts = {"align": False, "delimiter": "|", "converter": "es", "config": None,
            "completion": None, "list_modes": False}
    files = []
    i = 0
    while i < len(argv):
        arg = argv[i]
        if arg == "--":
            files.extend(argv[i + 1:])
            break
        if not arg.startswith("-") or arg == "-":
            files.append(arg)
            i += 1
            continue
        flag, eq_value = split_flag(arg)
        if flag in ("-h", "--help"):
            sys.stdout.write(HELP)
            raise SystemExit(0)
        if flag in ("-v", "--version"):
            print("ov version dev rev:HEAD")
            raise SystemExit(0)
        if flag == "--help-key":
            print(HELP_KEY)
            raise SystemExit(0)
        if flag in OPTIONAL_BOOL:
            i += 1
            continue
        if flag in VALUE_FLAGS:
            if eq_value is not None:
                value = eq_value
            else:
                i += 1
                if i >= len(argv):
                    print(f"Error: flag needs an argument: {flag}", file=sys.stderr)
                    raise SystemExit(1)
                value = argv[i]
            if flag in ("-l", "--align"):
                opts["align"] = True
            elif flag in ("-d", "--column-delimiter"):
                opts["delimiter"] = value
            elif flag == "--converter":
                opts["converter"] = value
                if value == "align":
                    opts["align"] = True
            elif flag == "--completion":
                opts["completion"] = value
            elif flag == "--config":
                opts["config"] = value
            elif flag == "--list-view-modes":
                opts["list_modes"] = True
            i += 1
            continue
        if flag in BOOL_FLAGS:
            if flag in ("-l", "--align"):
                opts["align"] = True
            if flag == "--list-view-modes":
                opts["list_modes"] = True
            i += 1
            continue
        print(f"Error: unknown flag: {arg}", file=sys.stderr)
        raise SystemExit(1)
    return opts, files


def visual_len(s):
    return len(re.sub(r"\x1b\[[0-9;?]*[ -/]*[@-~]", "", s))


def align_text(data, delimiter):
    text = data.decode("utf-8", "surrogateescape")
    keep_final = text.endswith("\n")
    lines = text.splitlines()
    if not lines:
        return data
    rows = [line.split(delimiter) for line in lines]
    widths = []
    for row in rows:
        for idx, cell in enumerate(row):
            if idx == len(widths):
                widths.append(0)
            widths[idx] = max(widths[idx], visual_len(cell))
    out = []
    for row in rows:
        parts = []
        for idx, cell in enumerate(row):
            pad = widths[idx] - visual_len(cell)
            if idx < len(row) - 1:
                parts.append(cell + (" " * pad))
            else:
                parts.append(cell)
        out.append(delimiter.join(parts))
    result = "\n".join(out)
    if keep_final:
        result += "\n"
    return result.encode("utf-8", "surrogateescape")


def emit_file(path):
    try:
        with open(path, "rb") as f:
            return f.read(), None
    except OSError as e:
        return b"", f"Error: open {path}: {e.strerror.lower()}"


def main(argv):
    if argv and argv[0] in ("__complete", "__completeNoDesc"):
        return complete(argv[1:], argv[0] == "__complete")
    opts, files = parse(argv)
    if opts["completion"] is not None:
        text = completion(opts["completion"])
        if opts["completion"] in {"bash", "zsh", "fish", "powershell"}:
            sys.stdout.write(text)
            return 0
        sys.stderr.write(text)
        return 1
    if opts["list_modes"]:
        print("general")
        return 0
    if opts["config"] is not None and (not os.path.exists(opts["config"]) or not os.path.splitext(opts["config"])[1]):
        print('failed to read config file: Unsupported Config Type ""', file=sys.stderr)

    chunks = []
    if files:
        for path in files:
            data, err = emit_file(path)
            if err:
                print(err, file=sys.stderr)
                return 1
            chunks.append(data)
    else:
        chunks.append(sys.stdin.buffer.read())
    data = b"".join(chunks)
    if opts["align"]:
        data = align_text(data, opts["delimiter"])
    sys.stdout.buffer.write(data)
    return 0


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
