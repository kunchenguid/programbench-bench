#!/usr/bin/env python3
import sys, argparse, json, re
import xml.etree.ElementTree as ET
from html.parser import HTMLParser
from collections import OrderedDict

HELP = '''Command-line XML and HTML beautifier and content extractor

Usage:
  xq [flags]

Flags:
  -a, --attr string      Extract an attribute value instead of node content for provided CSS query
  -c, --color            Force colorful output
      --compact          Compact JSON output (no indentation)
  -d, --depth int        Maximum nesting depth for JSON output (-1 for unlimited) (default -1)
  -e, --extract string   Extract a single node from XML
  -h, --help             Print this help message
  -m, --html             Use HTML formatter
  -i, --in-place         Format file in place
      --indent int       Use the given number of spaces for indentation (default 2)
  -j, --json             Output the result as JSON
      --no-color         Disable colorful output
  -n, --node             Return the node content instead of text
  -q, --query string     Extract the node(s) using CSS selector
      --tab              Use tabs for indentation
  -v, --version          Print version information
  -x, --xpath string     Extract the node(s) from XML
'''

class Node:
    def __init__(self, tag, attrs=None):
        self.tag = tag
        self.attrs = OrderedDict(attrs or [])
        self.children = []
        self.text = ''
        self.tail = ''
    def append(self, child): self.children.append(child)

class MyHTMLParser(HTMLParser):
    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.root = Node('__root__')
        self.stack = [self.root]
    def handle_starttag(self, tag, attrs):
        n = Node(tag.lower(), attrs)
        self.stack[-1].append(n)
        voids = {'area','base','br','col','embed','hr','img','input','link','meta','param','source','track','wbr'}
        if tag.lower() not in voids:
            self.stack.append(n)
    def handle_startendtag(self, tag, attrs):
        self.stack[-1].append(Node(tag.lower(), attrs))
    def handle_endtag(self, tag):
        tag = tag.lower()
        for i in range(len(self.stack)-1, 0, -1):
            if self.stack[i].tag == tag:
                del self.stack[i:]
                break
    def handle_data(self, data):
        if self.stack:
            self.stack[-1].text += data

def et_to_node(e):
    n = Node(strip_ns(e.tag), list(e.attrib.items()))
    n.text = e.text or ''
    for c in list(e):
        cn = et_to_node(c)
        cn.tail = c.tail or ''
        n.children.append(cn)
    return n

def strip_ns(tag):
    return tag.split('}',1)[1] if isinstance(tag, str) and tag.startswith('{') else tag

def parse_xml(data):
    return et_to_node(ET.fromstring(data))

def parse_html(data):
    p = MyHTMLParser(); p.feed(data)
    if len(p.root.children) == 1:
        return p.root.children[0]
    return p.root

def esc(s):
    return (s.replace('&','&amp;').replace('<','&lt;').replace('>','&gt;')
             .replace('"','&quot;'))

def text_content(n):
    parts = []
    def rec(x):
        if x.text: parts.append(x.text)
        for c in x.children:
            rec(c)
            if c.tail: parts.append(c.tail)
    rec(n)
    return ' '.join(''.join(parts).split())

def one_line(n):
    attrs = ''.join(f' {k}="{esc(v)}"' for k,v in n.attrs.items())
    if not n.children and not (n.text or '').strip():
        return f'<{n.tag}{attrs}/>'
    inner = esc((n.text or '').strip())
    for c in n.children:
        inner += one_line(c)
        if c.tail: inner += esc(c.tail.strip())
    return f'<{n.tag}{attrs}>{inner}</{n.tag}>'

VOIDS = {'area','base','br','col','embed','hr','img','input','link','meta','param','source','track','wbr'}

def format_node(n, indent='  ', level=0, html=False):
    pad = indent * level
    attrs = ''.join(f' {k}="{esc(v)}"' for k,v in n.attrs.items())
    txt = (n.text or '').strip()
    if not n.children:
        if txt:
            return [f'{pad}<{n.tag}{attrs}>{esc(txt)}</{n.tag}>']
        if html and n.tag not in VOIDS:
            return [f'{pad}<{n.tag}{attrs}></{n.tag}>']
        return [f'{pad}<{n.tag}{attrs}/>']
    # Inline simple single text child is not used when there are child elements.
    lines = []
    if txt:
        lines.append(f'{pad}<{n.tag}{attrs}>{esc(txt)}')
    else:
        lines.append(f'{pad}<{n.tag}{attrs}>')
    for c in n.children:
        cl = format_node(c, indent, level+1, html)
        if c.tail and c.tail.strip() and cl:
            cl[-1] += ' ' + esc(c.tail.strip())
        lines.extend(cl)
    lines.append(f'{pad}</{n.tag}>')
    return lines

def format_doc(root, indent, html=False):
    if root.tag == '__root__':
        out=[]
        for c in root.children: out.extend(format_node(c, indent, 0, html))
        return '\n'.join(out)+'\n'
    return '\n'.join(format_node(root, indent, 0, html))+'\n'

def all_desc(n):
    for c in n.children:
        yield c
        yield from all_desc(c)

def matches_tag(n, tag): return tag == '*' or n.tag == tag

def xpath(root, expr):
    expr = expr.strip()
    attr = None
    if '/@' in expr:
        expr, attr = expr.rsplit('/@',1)
    elif expr.startswith('@'):
        attr = expr[1:]; expr = '.'
    nodes=[]
    if expr.startswith('//'):
        tag = expr[2:] or '*'
        nodes = [n for n in [root]+list(all_desc(root)) if matches_tag(n, tag)]
    elif expr.startswith('/'):
        parts = [p for p in expr.split('/') if p]
        cur = [root]
        if parts and root.tag == parts[0]: parts = parts[1:]
        for p in parts:
            nxt=[]
            for n in cur:
                nxt.extend([c for c in n.children if matches_tag(c,p)])
            cur=nxt
        nodes=cur
    elif expr in ('.',''):
        nodes=[root]
    else:
        nodes=[n for n in [root]+list(all_desc(root)) if matches_tag(n, expr)]
    if attr is not None:
        return [('attr', n.attrs[attr]) for n in nodes if attr in n.attrs]
    return [('node', n) for n in nodes]

def parse_simple_selector(s):
    tag='*'; cls=None; ident=None
    if s.startswith('.'):
        cls=s[1:]
    elif s.startswith('#'):
        ident=s[1:]
    else:
        m=re.match(r'^([A-Za-z0-9_:-]+|\*)?(?:\.([A-Za-z0-9_-]+))?(?:#([A-Za-z0-9_-]+))?$', s)
        if m:
            tag=m.group(1) or '*'; cls=m.group(2); ident=m.group(3)
        else:
            tag=s
    return tag.lower(), cls, ident

def css_match(n, sel):
    tag, cls, ident = parse_simple_selector(sel)
    if tag != '*' and n.tag.lower() != tag: return False
    if ident and n.attrs.get('id') != ident: return False
    if cls and cls not in n.attrs.get('class','').split(): return False
    return True

def css_query(root, query):
    q=query.strip()
    if '>' in q:
        parts=[p.strip() for p in q.split('>')]
        cur=[root]
        if parts and css_match(root, parts[0]): parts=parts[1:]
        else:
            cur=[n for n in [root]+list(all_desc(root)) if css_match(n, parts[0])]
            parts=parts[1:]
        for p in parts:
            cur=[c for n in cur for c in n.children if css_match(c,p)]
        return cur
    parts=q.split()
    if len(parts)>1:
        cur=[root]
        for p in parts:
            pool=[]
            for n in cur: pool.extend(list(all_desc(n)))
            cur=[n for n in pool if css_match(n,p)]
        return cur
    return [n for n in [root]+list(all_desc(root)) if css_match(n,q)]

def elem_json(n, depth=-1, level=0):
    if depth >= 0 and level >= depth:
        return None
    obj=OrderedDict()
    txt=text_content_only(n)
    for c in n.children:
        val=elem_json(c, depth, level+1)
        if c.tag in obj:
            if not isinstance(obj[c.tag], list): obj[c.tag]=[obj[c.tag]]
            obj[c.tag].append(val)
        else:
            obj[c.tag]=val
    for k,v in n.attrs.items(): obj['@'+k]=v
    if txt and (obj or n.attrs):
        # Original tends to print text before attrs/children for mixed nodes.
        new=OrderedDict(); new['#text']=txt
        for k,v in obj.items(): new[k]=v
        obj=new
    elif txt:
        return txt
    return obj

def text_content_only(n):
    parts=[]
    if n.text and n.text.strip(): parts.append(n.text.strip())
    for c in n.children:
        if c.tail and c.tail.strip(): parts.append(c.tail.strip())
    return '\n'.join(parts) if len(parts)>1 else (parts[0] if parts else '')


def dump_json_like(v, level=0):
    sp = '  ' * level
    child = '  ' * (level + 1)
    if isinstance(v, str) or v is None:
        return json.dumps(v, ensure_ascii=False)
    if isinstance(v, list):
        if not v: return '[]'
        lines = ['[']
        for i, item in enumerate(v):
            txt = dump_json_like(item, level+1)
            first, rest = (txt.split('\n', 1) + [''])[:2]
            part = child + first
            if rest:
                part += '\n' + rest
            if i != len(v)-1: part += ','
            lines.append(part)
        lines.append(sp + ']')
        return '\n'.join(lines)
    if isinstance(v, dict):
        if not v:
            return '{\n\n' + sp + '}'
        lines = ['{']
        items=list(v.items())
        for i,(k,val) in enumerate(items):
            txt = dump_json_like(val, level+1)
            if '\n' in txt:
                first, rest = txt.split('\n',1)
                part = child + json.dumps(k, ensure_ascii=False) + ': ' + first + '\n' + rest
            else:
                part = child + json.dumps(k, ensure_ascii=False) + ': ' + txt
            if i != len(items)-1: part += ','
            lines.append(part)
        lines.append(sp + '}')
        return '\n'.join(lines)
    return json.dumps(v, ensure_ascii=False)

def read_input(files):
    if files:
        try:
            with open(files[0], 'r', encoding='utf-8') as f: return f.read()
        except Exception as e:
            print(f'Error: open {files[0]}: no such file or directory', file=sys.stderr); sys.exit(1)
    data=sys.stdin.read()
    if data == '':
        print(HELP, end=''); sys.exit(0)
    return data

def main(argv):
    if any(a in ('-h','--help') for a in argv): print(HELP,end=''); return 0
    if any(a in ('-v','--version') for a in argv): print('xq version 1.4.0'); return 0
    ap=argparse.ArgumentParser(add_help=False, allow_abbrev=False)
    ap.add_argument('-a','--attr'); ap.add_argument('-c','--color', action='store_true')
    ap.add_argument('--compact', action='store_true'); ap.add_argument('-d','--depth', type=int, default=-1)
    ap.add_argument('-e','--extract'); ap.add_argument('-m','--html', action='store_true')
    ap.add_argument('-i','--in-place', action='store_true'); ap.add_argument('--indent', type=int, default=2)
    ap.add_argument('-j','--json', action='store_true'); ap.add_argument('--no-color', action='store_true')
    ap.add_argument('-n','--node', action='store_true'); ap.add_argument('-q','--query'); ap.add_argument('--tab', action='store_true')
    ap.add_argument('-x','--xpath'); ap.add_argument('files', nargs='*')
    try: ns=ap.parse_args(argv)
    except SystemExit: return 1
    data=read_input(ns.files)
    try: root=parse_html(data) if ns.html else parse_xml(data)
    except Exception as e:
        print('Error:', str(e), file=sys.stderr); return 1
    indent='\t' if ns.tab else ' '*ns.indent
    out=''
    if ns.json:
        wrapped=OrderedDict([(root.tag, elem_json(root, ns.depth, 0))]) if root.tag!='__root__' else elem_json(root, ns.depth, 0)
        if ns.compact: out=json.dumps(wrapped, ensure_ascii=False, separators=(',', ': '))+'\n'
        else: out=dump_json_like(wrapped)+'\n'
    elif ns.query:
        lines=[]
        for n in css_query(root, ns.query):
            if ns.attr:
                if ns.attr in n.attrs: lines.append(n.attrs[ns.attr])
            elif ns.node: lines.append('\n'.join(format_node(n, indent, 0, ns.html)))
            else: lines.append(text_content(n))
        out='\n'.join(lines)+('\n' if lines else '')
    elif ns.xpath or ns.extract:
        res=xpath(root, ns.xpath or ns.extract)
        if ns.extract: res=res[:1]
        lines=[]
        for typ,val in res:
            if typ=='attr': lines.append(val)
            elif ns.node: lines.append(one_line(val))
            else: lines.append(text_content(val))
        out='\n'.join(lines)+('\n' if lines else '')
    else:
        out=format_doc(root, indent, ns.html)
    if ns.in_place and ns.files:
        with open(ns.files[0], 'w', encoding='utf-8') as f: f.write(out)
    else:
        sys.stdout.write(out)
    return 0
if __name__=='__main__': sys.exit(main(sys.argv[1:]))
