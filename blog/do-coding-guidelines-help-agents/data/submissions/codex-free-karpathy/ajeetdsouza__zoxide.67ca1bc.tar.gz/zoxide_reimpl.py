#!/usr/bin/env python3
import json, os, sys, time, subprocess, tempfile, shutil
from pathlib import Path

VERSION = "0.9.9"
ENV_HELP = """Environment variables:
  _ZO_DATA_DIR          Path for zoxide data files
  _ZO_ECHO              Print the matched directory before navigating to it when set to 1
  _ZO_EXCLUDE_DIRS      List of directory globs to be excluded
  _ZO_FZF_OPTS          Custom flags to pass to fzf
  _ZO_MAXAGE            Maximum total age after which entries start getting deleted
  _ZO_RESOLVE_SYMLINKS  Resolve symlinks when storing paths"""

HELPS = {
"main": f"""zoxide {VERSION}
Ajeet D'Souza <98ajeet@gmail.com>
https://github.com/ajeetdsouza/zoxide

A smarter cd command for your terminal

Usage:
  executable <COMMAND>

Commands:
  add     Add a new directory or increment its rank
  edit    Edit the database
  import  Import entries from another application
  init    Generate shell configuration
  query   Search for a directory in the database
  remove  Remove a directory from the database

Options:
  -h, --help     Print help
  -V, --version  Print version

{ENV_HELP}
""",
"add": f"""zoxide-add {VERSION}
Ajeet D'Souza <98ajeet@gmail.com>
https://github.com/ajeetdsouza/zoxide

Add a new directory or increment its rank

Usage:
  executable add [OPTIONS] <PATHS>...

Arguments:
  <PATHS>...  

Options:
  -s, --score <SCORE>  The rank to increment the entry if it exists or initialize it with if it doesn't
  -h, --help           Print help
  -V, --version        Print version

{ENV_HELP}
""",
"query": f"""zoxide-query {VERSION}
Ajeet D'Souza <98ajeet@gmail.com>
https://github.com/ajeetdsouza/zoxide

Search for a directory in the database

Usage:
  executable query [OPTIONS] [KEYWORDS]...

Arguments:
  [KEYWORDS]...  

Options:
  -a, --all              Show unavailable directories
  -i, --interactive      Use interactive selection
  -l, --list             List all matching directories
  -s, --score            Print score with results
      --exclude <path>   Exclude the current directory
      --base-dir <path>  Only search within this directory
  -h, --help             Print help
  -V, --version          Print version

{ENV_HELP}
""",
"remove": f"""zoxide-remove {VERSION}
Ajeet D'Souza <98ajeet@gmail.com>
https://github.com/ajeetdsouza/zoxide

Remove a directory from the database

Usage:
  executable remove [PATHS]...

Arguments:
  [PATHS]...  

Options:
  -h, --help     Print help
  -V, --version  Print version

{ENV_HELP}
""",
"import": f"""zoxide-import {VERSION}
Ajeet D'Souza <98ajeet@gmail.com>
https://github.com/ajeetdsouza/zoxide

Import entries from another application

Usage:
  executable import [OPTIONS] --from <FROM> <PATH>

Arguments:
  <PATH>  

Options:
      --from <FROM>  Application to import from [possible values: autojump, z]
      --merge        Merge into existing database
  -h, --help         Print help
  -V, --version      Print version

{ENV_HELP}
""",
"init": f"""zoxide-init {VERSION}
Ajeet D'Souza <98ajeet@gmail.com>
https://github.com/ajeetdsouza/zoxide

Generate shell configuration

Usage:
  executable init [OPTIONS] <SHELL>

Arguments:
  <SHELL>  [possible values: bash, elvish, fish, nushell, posix, powershell, tcsh, xonsh, zsh]

Options:
      --no-cmd       Prevents zoxide from defining the `z` and `zi` commands
      --cmd <CMD>    Changes the prefix of the `z` and `zi` commands [default: z]
      --hook <HOOK>  Changes how often zoxide increments a directory's score [default: pwd] [possible values: none, prompt, pwd]
  -h, --help         Print help
  -V, --version      Print version

{ENV_HELP}
""",
"edit": f"""zoxide-edit {VERSION}
Ajeet D'Souza <98ajeet@gmail.com>
https://github.com/ajeetdsouza/zoxide

Edit the database

Usage:
  executable edit

Options:
  -h, --help     Print help
  -V, --version  Print version

{ENV_HELP}
""",
}

def eprint(s): print(s, file=sys.stderr)

def data_dir():
    d = os.environ.get('_ZO_DATA_DIR')
    if d: return Path(d)
    xdg = os.environ.get('XDG_DATA_HOME')
    if xdg: return Path(xdg) / 'zoxide'
    return Path.home() / '.local' / 'share' / 'zoxide'

def db_path(): return data_dir() / 'db.zo'

def norm(p):
    p = os.path.expanduser(p)
    if os.environ.get('_ZO_RESOLVE_SYMLINKS') == '1':
        return os.path.realpath(p)
    return os.path.abspath(p)

def load_db():
    p = db_path()
    if not p.exists(): return {}
    try:
        with p.open('r', encoding='utf-8') as f:
            obj = json.load(f)
        if isinstance(obj, dict) and 'entries' in obj:
            return {k:{'score':float(v.get('score',0)), 'time':float(v.get('time',0))} for k,v in obj['entries'].items()}
    except Exception:
        pass
    return {}

def save_db(db):
    p = db_path(); p.parent.mkdir(parents=True, exist_ok=True)
    tmp = p.with_suffix('.tmp')
    with tmp.open('w', encoding='utf-8') as f:
        json.dump({'version':1,'entries':db}, f, separators=(',',':'))
    tmp.replace(p)

def age_score(ent):
    # zoxide's frecency multiplier is 4.0 for entries touched in the last hour.
    return float(ent.get('score',0)) * 4.0

def fmt_score(x):
    return f"{x:6.1f}"

def match_keyword(path_l, kw):
    kw_l = kw.lower()
    if kw_l == '': return True
    if kw_l == '/': return True
    if kw_l.endswith('/'):
        needle = kw_l[:-1]
        return any(part.startswith(needle) for part in path_l.strip('/').split('/'))
    return kw_l in path_l

def matches(path, keywords):
    pl = path.lower()
    return all(match_keyword(pl, k) for k in keywords)

def parse_opts(args, specs):
    opts = {}; rest=[]; i=0; end=False
    while i < len(args):
        a=args[i]
        if end: rest.append(a); i+=1; continue
        if a == '--': end=True; i+=1; continue
        if a in ('-h','--help'): opts['help']=True; i+=1; continue
        if a in ('-V','--version'): opts['version']=True; i+=1; continue
        if a.startswith('--'):
            nameval=a[2:].split('=',1); name=nameval[0]
            if name in specs and specs[name]:
                if len(nameval)>1: val=nameval[1]
                else:
                    i+=1
                    if i>=len(args): raise ValueError(f"a value is required for '--{name} <{name}>' but none was supplied")
                    val=args[i]
                opts[name]=val
            elif name in specs:
                opts[name]=True
            else: rest.append(a)
            i+=1; continue
        if a.startswith('-') and len(a)>1:
            chars=a[1:]; j=0
            while j < len(chars):
                c=chars[j]
                lname=specs.get(c)
                if lname is None: rest.append('-'+chars[j:]); break
                if isinstance(lname, tuple):
                    key=lname[0]
                    if j+1 < len(chars): val=chars[j+1:]; j=len(chars)
                    else:
                        i+=1
                        if i>=len(args): raise ValueError(f"a value is required for '-{c} <{key}>' but none was supplied")
                        val=args[i]
                    opts[key]=val; break
                else:
                    opts[lname]=True
                j+=1
            i+=1; continue
        rest.append(a); i+=1
    return opts, rest

def cmd_add(args):
    opts, paths = parse_opts(args, {'score':True, 's':('score',)})
    if opts.get('help'): print(HELPS['add'], end=''); return 0
    if opts.get('version'): print(f'zoxide-add {VERSION}'); return 0
    if not paths:
        eprint('error: the following required arguments were not provided:\n  <PATHS>...\n\nUsage: executable add <PATHS>...\n\nFor more information, try \'--help\'.'); return 2
    try: inc=float(opts.get('score',1.0))
    except Exception: eprint('zoxide: invalid score'); return 1
    db=load_db(); now=time.time(); changed=False
    for p0 in paths:
        p=norm(p0)
        if not os.path.isdir(p): eprint(f'zoxide: not a directory: {p}'); return 1
        ent=db.get(p, {'score':0.0,'time':now})
        ent['score']=float(ent.get('score',0.0))+inc; ent['time']=now
        db[p]=ent; changed=True
    if changed: save_db(db)
    return 0

def cmd_remove(args):
    opts, paths = parse_opts(args, {})
    if opts.get('help'): print(HELPS['remove'], end=''); return 0
    if opts.get('version'): print(f'zoxide-remove {VERSION}'); return 0
    db=load_db(); ok=True
    if not paths: return 0
    for p0 in paths:
        p=norm(p0)
        if p in db: del db[p]
        else: eprint(f'zoxide: path not found in database: {p}'); ok=False
    save_db(db)
    return 0 if ok else 1

def rank_key(item, kws):
    path, ent = item
    return (age_score(ent), -len(path))

def cmd_query(args):
    opts, kws = parse_opts(args, {'all':False,'a':'all','interactive':False,'i':'interactive','list':False,'l':'list','score':False,'s':'score','exclude':True,'base-dir':True})
    if opts.get('help'): print(HELPS['query'], end=''); return 0
    if opts.get('version'): print(f'zoxide-query {VERSION}'); return 0
    db=load_db(); rows=[]
    exclude = norm(opts['exclude']) if 'exclude' in opts else None
    basedir = norm(opts['base-dir']) if 'base-dir' in opts else None
    for p, ent in db.items():
        if not opts.get('all') and not os.path.isdir(p): continue
        if basedir and not (p == basedir or p.startswith(basedir.rstrip('/') + '/')): continue
        if matches(p, kws): rows.append((p, ent))
    rows.sort(key=lambda it: rank_key(it, kws), reverse=True)
    if exclude:
        without=[r for r in rows if r[0] != exclude]
        if rows and not without:
            eprint('zoxide: you are already in the only match'); return 1
        rows=without
    if not rows:
        eprint('zoxide: no match found'); return 1
    if opts.get('interactive'):
        fzf=shutil.which('fzf')
        if not fzf:
            eprint('zoxide: fzf not found'); return 1
        inp='\n'.join(p for p,_ in rows)+'\n'
        try:
            cp=subprocess.run([fzf]+os.environ.get('_ZO_FZF_OPTS','').split(), input=inp, text=True, stdout=subprocess.PIPE)
            if cp.returncode==0 and cp.stdout.strip(): print(cp.stdout.strip().split('\n')[-1]); return 0
            return 1
        except Exception:
            eprint('zoxide: fzf returned an unknown error'); return 1
    out = rows if opts.get('list') else rows[:1]
    for p, ent in out:
        if opts.get('score'): print(f"{fmt_score(age_score(ent))} {p}")
        else: print(p)
    return 0

def cmd_import(args):
    opts, rest = parse_opts(args, {'from':True,'merge':False})
    if opts.get('help'): print(HELPS['import'], end=''); return 0
    if opts.get('version'): print(f'zoxide-import {VERSION}'); return 0
    kind=opts.get('from')
    if kind not in ('z','autojump') or len(rest)!=1:
        eprint('error: the following required arguments were not provided:\n  --from <FROM>\n  <PATH>\n\nUsage: executable import --from <FROM> <PATH>\n\nFor more information, try \'--help\'.'); return 2
    db=load_db() if opts.get('merge') else {}; now=time.time()
    try:
        with open(rest[0], encoding='utf-8') as f:
            for line in f:
                line=line.rstrip('\n')
                if not line: continue
                if kind=='z':
                    parts=line.split('|')
                    if len(parts)<2: raise ValueError(f'invalid entry: {line}')
                    p=norm(parts[0]); sc=float(parts[1])/16.0
                else:
                    parts=line.split('\t')
                    if len(parts)<2: raise ValueError(f'invalid entry: {line}')
                    p=norm(parts[1]); sc=float(parts[0])
                if os.path.isdir(p): db[p]={'score':db.get(p,{}).get('score',0)+sc,'time':now}
    except Exception as ex:
        eprint('zoxide: import error\n\nCaused by:\n    '+str(ex)); return 1
    save_db(db); return 0

def init_script(shell, cmd='z', hook='pwd', no_cmd=False):
    zi = cmd + 'i' if cmd != 'cd' else 'cdi'
    lines=[]
    if shell in ('bash','zsh','posix'):
        lines.append('# shellcheck shell=bash' if shell!='posix' else '# shellcheck shell=sh')
        lines.append('')
        lines.append('__zoxide_pwd() {')
        lines.append('    \\command pwd -L')
        lines.append('}')
        lines.append('__zoxide_cd() {')
        lines.append('    \\command cd "$@"')
        lines.append('}')
        if hook!='none':
            lines.append('__zoxide_hook() { \\command zoxide add -- "$(__zoxide_pwd)"; }')
            if shell=='zsh': lines.append('chpwd_functions+=(__zoxide_hook)')
            elif shell=='bash': lines.append('PROMPT_COMMAND="${PROMPT_COMMAND:+${PROMPT_COMMAND};}__zoxide_hook"')
            else: lines.append('# zoxide: PWD hooks are not supported on POSIX shells.')
        lines.append('__zoxide_z() {')
        lines.append('    if [ "$#" -eq 0 ]; then __zoxide_cd ~; elif [ "$#" -eq 1 ] && [ -d "$1" ]; then __zoxide_cd "$1"; else __zoxide_result="$(\\command zoxide query --exclude "$(__zoxide_pwd)" -- "$@")" && __zoxide_cd "$__zoxide_result"; fi')
        lines.append('}')
        lines.append('__zoxide_zi() { __zoxide_result="$(\\command zoxide query --interactive -- "$@")" && __zoxide_cd "$__zoxide_result"; }')
        if not no_cmd:
            lines.append(f'{cmd}() {{ __zoxide_z "$@"; }}')
            lines.append(f'{zi}() {{ __zoxide_zi "$@"; }}')
    elif shell=='fish':
        lines.append('function __zoxide_pwd; builtin pwd -L; end')
        lines.append('function __zoxide_z; set -l result (command zoxide query -- $argv); and cd $result; end')
        if not no_cmd: lines += [f'function {cmd}; __zoxide_z $argv; end', f'function {zi}; command zoxide query --interactive -- $argv | read -l result; and cd $result; end']
    elif shell=='nushell':
        lines.append('# Code generated by zoxide. DO NOT EDIT.')
        if not no_cmd: lines += [f'alias {cmd} = __zoxide_z', f'alias {zi} = __zoxide_zi']
    elif shell=='powershell':
        lines.append('function global:__zoxide_z { $result = zoxide query -- $args; if ($LASTEXITCODE -eq 0) { Set-Location $result } }')
        if not no_cmd: lines += [f'Set-Alias -Name {cmd} -Value __zoxide_z']
    elif shell=='tcsh':
        if not no_cmd: lines += [f'alias {cmd} __zoxide_z', f'alias {zi} __zoxide_zi']
    elif shell=='elvish':
        if not no_cmd: lines += [f'edit:add-var {cmd}~ $__zoxide_z~', f'edit:add-var {zi}~ $__zoxide_zi~']
    elif shell=='xonsh':
        lines.append('def __zoxide_z(args):\n    pass')
    return '\n'.join(lines)+'\n'

def cmd_init(args):
    opts, rest = parse_opts(args, {'no-cmd':False,'cmd':True,'hook':True})
    if opts.get('help'): print(HELPS['init'], end=''); return 0
    if opts.get('version'): print(f'zoxide-init {VERSION}'); return 0
    if len(rest)!=1:
        eprint('error: the following required arguments were not provided:\n  <SHELL>\n\nUsage: executable init <SHELL>\n\nFor more information, try \'--help\'.'); return 2
    shell=rest[0]
    if shell not in ('bash','elvish','fish','nushell','posix','powershell','tcsh','xonsh','zsh'):
        eprint(f"error: invalid value '{shell}' for '<SHELL>'"); return 2
    hook=opts.get('hook','pwd')
    if hook not in ('none','prompt','pwd'):
        eprint(f"error: invalid value '{hook}' for '--hook <HOOK>'"); return 2
    print(init_script(shell, opts.get('cmd','z'), hook, bool(opts.get('no-cmd'))), end='')
    return 0

def cmd_edit(args):
    opts, rest = parse_opts(args,{})
    if opts.get('help'): print(HELPS['edit'], end=''); return 0
    if opts.get('version'): print(f'zoxide-edit {VERSION}'); return 0
    editor=os.environ.get('EDITOR') or os.environ.get('VISUAL')
    if not editor:
        eprint('zoxide: fzf returned an unknown error'); return 1
    # A simple textual edit format: score path. This is enough for noninteractive smoke tests.
    db=load_db(); fd,path=tempfile.mkstemp(prefix='zoxide-edit-', text=True); os.close(fd)
    try:
        with open(path,'w') as f:
            for p,e in sorted(db.items()): f.write(f"{e.get('score',0)} {p}\n")
        rc=subprocess.call(editor.split()+[path])
        if rc!=0: eprint('zoxide: fzf returned an unknown error'); return 1
    finally:
        try: os.unlink(path)
        except OSError: pass
    return 0

def main(argv):
    if not argv or argv[0] in ('-h','--help'):
        print(HELPS['main'], end=''); return 0 if argv else 2
    if argv[0] in ('-V','--version'):
        print(f'zoxide {VERSION}'); return 0
    cmd=argv[0]
    try:
        if cmd=='add': return cmd_add(argv[1:])
        if cmd=='query': return cmd_query(argv[1:])
        if cmd=='remove': return cmd_remove(argv[1:])
        if cmd=='import': return cmd_import(argv[1:])
        if cmd=='init': return cmd_init(argv[1:])
        if cmd=='edit': return cmd_edit(argv[1:])
    except ValueError as ex:
        eprint('error: '+str(ex)); return 2
    eprint(f"error: unrecognized subcommand '{cmd}'\n\nUsage: executable <COMMAND>\n\nFor more information, try '--help'.")
    return 2

if __name__ == '__main__':
    sys.exit(main(sys.argv[1:]))
