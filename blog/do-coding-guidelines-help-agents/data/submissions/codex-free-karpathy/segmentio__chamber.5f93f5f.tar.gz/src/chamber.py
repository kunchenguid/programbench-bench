#!/usr/bin/env python3
import os
import sys
import subprocess
import json


GLOBAL_FLAGS = """  -b, --backend string             Backend to use; AKA $CHAMBER_SECRET_BACKEND
                                   \tnull: no-op
                                   \tssm: SSM Parameter Store
                                   \tsecretsmanager: Secrets Manager
                                   \ts3: S3; requires --backend-s3-bucket
                                   \ts3-kms: S3 using AWS-KMS encryption; requires --backend-s3-bucket and --kms-key-alias set (if you want to write or delete keys). (default "ssm")
      --backend-s3-bucket string   bucket for S3 backend; AKA $CHAMBER_S3_BUCKET
      --kms-key-alias string       KMS Key Alias for writing and deleting secrets; AKA $CHAMBER_KMS_KEY_ALIAS. This option is currently only supported for the S3-KMS backend. (default "alias/parameter_store_key")
  -r, --retries int                For SSM or Secrets Manager, the number of retries we'll make before giving up; AKA $CHAMBER_RETRIES (default 10)
      --retry-mode string          For SSM, the model used to retry requests
                                    standard
                                    adaptive (default "standard")
      --verbose                    Print more information to STDERR"""


ROOT_HELP = f"""CLI for storing secrets

Usage:
  chamber [command]

Available Commands:
  completion    Generate the autocompletion script for the specified shell
  delete        Delete a secret, including all versions
  env           Print the secrets from the parameter store in a format to export as environment variables
  exec          Executes a command with secrets loaded into the environment
  export        Exports parameters in the specified format
  find          Find the given secret across all services
  help          Help about any command
  history       View the history of a secret
  import        import secrets from json or yaml
  list          List the secrets set for a service
  list-services List services
  read          Read a specific secret from the parameter store
  tag           work with tags on secrets
  version       print version
  write         write a secret

Flags:
{GLOBAL_FLAGS}
  -h, --help                       help for chamber

Use "chamber [command] --help" for more information about a command."""


HELPS = {
    "write": f"""write a secret

Usage:
  chamber write <service> <key> [--] <value|-> [flags]

Flags:
  -h, --help                  help for write
  -s, --singleline            Insert single line parameter (end with \\n)
      --skip-unchanged        Skip writing secret if value is unchanged
  -t, --tags stringToString   Add tags to the secret; new secrets only (default [])

Global Flags:
{GLOBAL_FLAGS}""",
    "read": f"""Read a specific secret from the parameter store

Usage:
  chamber read <service> <key> [flags]

Flags:
  -h, --help          help for read
  -q, --quiet         Only print the secret
  -v, --version int   The version number of the secret. Defaults to latest. (default -1)

Global Flags:
{GLOBAL_FLAGS}""",
    "list": f"""List the secrets set for a service

Usage:
  chamber list <service> [flags]

Flags:
  -e, --expand    Expand parameter list with values
  -h, --help      help for list
  -t, --time      Sort by modified time
  -u, --user      Sort by user
  -v, --version   Sort by version

Global Flags:
{GLOBAL_FLAGS}""",
    "env": f"""Print the secrets from the parameter store in a format to export as environment variables

Usage:
  chamber env <service> [flags]

Flags:
  -p, --preserve-case    preserve variable name case
  -e, --escape-strings   escape special characters in values
  -h, --help             help for env

Global Flags:
{GLOBAL_FLAGS}""",
    "export": f"""Exports parameters in the specified format

Usage:
  chamber export <service...> [flags]

Flags:
  -f, --format string        Output format (json, yaml, java-properties, csv, tsv, dotenv, tfvars) (default "json")
  -o, --output-file string   Output file (default is standard output)
  -h, --help                 help for export

Global Flags:
{GLOBAL_FLAGS}""",
    "import": f"""import secrets from json or yaml

Usage:
  chamber import <service> <file|-> [flags]

Flags:
  -h, --help                           help for import
      --normalize-keys chamber write   Normalize keys to match how chamber write would handle them. If not specified, keys will be written exactly how they are defined in the import source.

Global Flags:
{GLOBAL_FLAGS}""",
    "exec": f"""Executes a command with secrets loaded into the environment

Usage:
  chamber exec <service...> -- <command> [<arg...>] [flags]

Examples:

Given a secret store like this:

\t$ echo '{{"db_username": "root", "db_password": "hunter22"}}' | chamber import - 

--strict will fail with unfilled env vars

\t$ HOME=/tmp DB_USERNAME=chamberme DB_PASSWORD=chamberme EXTRA=chamberme chamber exec --strict service exec -- env
\tchamber: extra unfilled env var EXTRA
\texit 1

--pristine takes effect after checking for --strict values

\t$ HOME=/tmp DB_USERNAME=chamberme DB_PASSWORD=chamberme chamber exec --strict --pristine service exec -- env
\tDB_USERNAME=root
\tDB_PASSWORD=hunter22


Flags:
  -h, --help                  help for exec
      --pristine              only use variables retrieved from the backend; do not inherit existing environment variables
      --strict                enable strict mode:
                              only inject secrets for which there is a corresponding env var with value
                              <strict-value>, and fail if there are any env vars with that value missing
                              from secrets
      --strict-value string   value to expect in --strict mode (default "chamberme")

Global Flags:
{GLOBAL_FLAGS}""",
    "delete": f"""Delete a secret, including all versions

Usage:
  chamber delete <service> <key> [flags]

Flags:
      --exact-key   Prevent normalization of the provided key in order to delete any keys that match the exact provided casing.
  -h, --help        help for delete

Global Flags:
{GLOBAL_FLAGS}""",
    "find": f"""Find the given secret across all services

Usage:
  chamber find <secret name> [flags]

Flags:
  -v, --by-value   Find parameters by value
  -h, --help       help for find

Global Flags:
{GLOBAL_FLAGS}""",
    "history": f"""View the history of a secret

Usage:
  chamber history <service> <key> [flags]

Flags:
  -h, --help   help for history

Global Flags:
{GLOBAL_FLAGS}""",
    "list-services": f"""List services

Usage:
  chamber list-services <service> [flags]

Flags:
  -h, --help      help for list-services
  -s, --secrets   Include secret names in the list

Global Flags:
{GLOBAL_FLAGS}""",
    "version": f"""print version

Usage:
  chamber version [flags]

Flags:
  -h, --help   help for version

Global Flags:
{GLOBAL_FLAGS}""",
    "tag": f"""work with tags on secrets

Usage:
  chamber tag [command]

Available Commands:
  delete      Delete tags for a specific secret
  read        Read tags for a specific secret
  write       Write tags for a specific secret

Flags:
  -h, --help   help for tag

Global Flags:
{GLOBAL_FLAGS}

Use "chamber tag [command] --help" for more information about a command.""",
    "completion": f"""Generate the autocompletion script for chamber for the specified shell.
See each sub-command's help for details on how to use the generated script.

Usage:
  chamber completion [command]

Available Commands:
  bash        Generate the autocompletion script for bash
  fish        Generate the autocompletion script for fish
  powershell  Generate the autocompletion script for powershell
  zsh         Generate the autocompletion script for zsh

Flags:
  -h, --help   help for completion

Global Flags:
{GLOBAL_FLAGS}

Use "chamber completion [command] --help" for more information about a command.""",
}

TAG_HELPS = {
    "read": f"""Read tags for a specific secret

Usage:
  chamber tag read <service> <key> [flags]

Flags:
  -h, --help   help for read

Global Flags:
{GLOBAL_FLAGS}""",
    "write": f"""Write tags for a specific secret

Usage:
  chamber tag write <service> <key> <tag>... [flags]

Flags:
      --delete-other-tags   Delete tags not specified in the command
  -h, --help                help for write

Global Flags:
{GLOBAL_FLAGS}""",
    "delete": f"""Delete tags for a specific secret

Usage:
  chamber tag delete <service> <key> <tag key>... [flags]

Flags:
  -h, --help   help for delete

Global Flags:
{GLOBAL_FLAGS}""",
}


def out(text=""):
    sys.stdout.write(text + ("\n" if text and not text.endswith("\n") else ""))


def err(text):
    sys.stderr.write(text + ("\n" if not text.endswith("\n") else ""))


def split_global(argv):
    backend = os.environ.get("CHAMBER_SECRET_BACKEND", "ssm")
    rest = []
    i = 0
    while i < len(argv):
        a = argv[i]
        if a in ("-b", "--backend") and i + 1 < len(argv):
            backend = argv[i + 1]
            i += 2
        elif a.startswith("--backend="):
            backend = a.split("=", 1)[1]
            i += 1
        elif a in ("--backend-s3-bucket", "--kms-key-alias", "-r", "--retries", "--retry-mode") and i + 1 < len(argv):
            i += 2
        elif a.startswith(("--backend-s3-bucket=", "--kms-key-alias=", "--retries=", "--retry-mode=")):
            i += 1
        elif a == "--verbose":
            i += 1
        else:
            rest.append(a)
            i += 1
    return backend, rest


def strip_flags(args, specs):
    vals = {}
    pos = []
    i = 0
    while i < len(args):
        a = args[i]
        if a == "--":
            pos.extend(args[i + 1:])
            break
        if a in ("-h", "--help"):
            vals["help"] = True
            i += 1
        elif a in specs:
            takes = specs[a]
            key = a.lstrip("-")
            if takes and i + 1 < len(args):
                vals[key] = args[i + 1]
                i += 2
            else:
                vals[key] = True
                i += 1
        elif a.startswith("-"):
            vals[a.lstrip("-")] = True
            i += 1
        else:
            pos.append(a)
            i += 1
    return vals, pos


def usage_error(msg, help_key):
    err("Error: " + msg)
    if help_key in HELPS:
        err("Usage:")
        lines = HELPS[help_key].splitlines()
        start = lines.index("Usage:") + 1 if "Usage:" in lines else 0
        err("\n".join(lines[start:]))
    return 1


def not_null_backend(backend):
    return backend != "null"


def command_main(argv):
    backend, args = split_global(argv)
    if not args or args[0] in ("-h", "--help", "help"):
        if len(args) >= 2 and args[0] == "help":
            return show_help(args[1:])
        out(ROOT_HELP)
        return 0
    if args[0] == "--version":
        err("Error: unknown flag: --version")
        return 1
    cmd, subargs = args[0], args[1:]
    if cmd not in HELPS:
        err(f'Error: unknown command "{cmd}" for "chamber"')
        err("Run 'chamber --help' for usage.")
        return 1
    if "-h" in subargs or "--help" in subargs:
        return show_help(args)
    if cmd == "version":
        out("chamber dev")
        return 0
    if cmd == "list":
        flags, pos = strip_flags(subargs, {"-e": False, "--expand": False, "-t": False, "--time": False, "-u": False, "--user": False, "-v": False, "--version": False})
        if len(pos) != 1:
            return usage_error(f"accepts 1 arg(s), received {len(pos)}", "list")
        out("Key\tVersion\t\tLastModified\tUser" + ("\tValue" if flags.get("e") or flags.get("expand") else ""))
        return 0
    if cmd == "list-services":
        out("Service")
        return 0
    if cmd == "find":
        flags, pos = strip_flags(subargs, {"-v": False, "--by-value": False})
        if len(pos) != 1:
            return usage_error(f"accepts 1 arg(s), received {len(pos)}", "find")
        out("Service\t\tKey" if flags.get("v") or flags.get("by-value") else "Service")
        return 0
    if cmd == "history":
        flags, pos = strip_flags(subargs, {})
        if len(pos) != 2:
            return usage_error(f"accepts 2 arg(s), received {len(pos)}", "history")
        out("Event\tVersion\t\tDate\tUser")
        return 0
    if cmd == "env":
        flags, pos = strip_flags(subargs, {"-p": False, "--preserve-case": False, "-e": False, "--escape-strings": False})
        if len(pos) != 1:
            return usage_error(f"accepts 1 arg(s), received {len(pos)}", "env")
        return 0
    if cmd == "export":
        return do_export(subargs)
    if cmd == "read":
        flags, pos = strip_flags(subargs, {"-q": False, "--quiet": False, "-v": True, "--version": True})
        if len(pos) != 2:
            return usage_error(f"accepts 2 arg(s), received {len(pos)}", "read")
        err("Error: Failed to read: Not implemented for Null Store")
        return 1
    if cmd == "write":
        flags, pos = strip_flags(subargs, {"-s": False, "--singleline": False, "--skip-unchanged": False, "-t": True, "--tags": True})
        if len(pos) != 3:
            return usage_error(f"accepts 3 arg(s), received {len(pos)}", "write")
        if pos[2] == "-":
            sys.stdin.read()
        err("Error: Write is not implemented for Null Store")
        return 1
    if cmd == "delete":
        flags, pos = strip_flags(subargs, {"--exact-key": False})
        if len(pos) != 2:
            return usage_error(f"accepts 2 arg(s), received {len(pos)}", "delete")
        err("Error: Delete is not implemented for Null Store")
        return 1
    if cmd == "import":
        flags, pos = strip_flags(subargs, {"--normalize-keys": False})
        if len(pos) != 2:
            return usage_error(f"accepts 2 arg(s), received {len(pos)}", "import")
        if pos[1] != "-" and not os.path.exists(pos[1]):
            err(f"Error: Failed to open file: open {pos[1]}: no such file or directory")
            return 1
        if pos[1] == "-":
            sys.stdin.read()
        return 0
    if cmd == "exec":
        return do_exec(subargs)
    if cmd == "tag":
        return do_tag(subargs)
    if cmd == "completion":
        return do_completion(subargs)
    return 0


def show_help(parts):
    if not parts:
        out(ROOT_HELP)
    elif parts[0] == "tag" and len(parts) > 1 and parts[1] in TAG_HELPS:
        out(TAG_HELPS[parts[1]])
    elif parts[0] in HELPS:
        out(HELPS[parts[0]])
    else:
        out(ROOT_HELP)
    return 0


def do_export(subargs):
    flags, pos = strip_flags(subargs, {"-f": True, "--format": True, "-o": True, "--output-file": True})
    if len(pos) < 1:
        return usage_error(f"requires at least 1 arg(s), only received {len(pos)}", "export")
    fmt = flags.get("f") or flags.get("format") or "json"
    if fmt not in ("json", "yaml", "java-properties", "csv", "tsv", "dotenv", "tfvars"):
        err(f"Error: Unsupported output format {fmt}")
        return 1
    if fmt in ("json", "yaml"):
        data = "{}\n"
    elif fmt == "csv":
        data = "key,value\n"
    elif fmt == "tsv":
        data = "key\tvalue\n"
    else:
        data = ""
    target = flags.get("o") or flags.get("output-file")
    if target:
        with open(target, "w") as f:
            f.write(data)
    else:
        sys.stdout.write(data)
    return 0


def do_exec(subargs):
    flags = {"pristine": False, "strict": False, "strict_value": "chamberme"}
    service_args = []
    cmd = None
    i = 0
    while i < len(subargs):
        a = subargs[i]
        if a == "--":
            cmd = subargs[i + 1:]
            break
        if a == "--pristine":
            flags["pristine"] = True
        elif a == "--strict":
            flags["strict"] = True
        elif a == "--strict-value" and i + 1 < len(subargs):
            flags["strict_value"] = subargs[i + 1]
            i += 1
        else:
            service_args.append(a)
        i += 1
    if cmd is None or not cmd:
        err("Error: please separate services and command with '--'. See usage")
        return 1
    if flags["strict"]:
        missing = [k for k, v in os.environ.items() if v == flags["strict_value"]]
        if missing:
            err(f"Error: parent env was expecting {missing[0]}={flags['strict_value']}, but was not in store")
            return 1
    env = {} if flags["pristine"] else os.environ.copy()
    try:
        p = subprocess.run(cmd, env=env)
        return p.returncode
    except FileNotFoundError:
        err(f"Error: exec: \"{cmd[0]}\": executable file not found in $PATH")
        return 1


def do_tag(subargs):
    if not subargs or subargs[0] in ("-h", "--help"):
        out(HELPS["tag"])
        return 0
    sub = subargs[0]
    rest = subargs[1:]
    if sub in TAG_HELPS and ("-h" in rest or "--help" in rest):
        out(TAG_HELPS[sub])
        return 0
    flags, pos = strip_flags(rest, {"--delete-other-tags": False})
    if sub == "read":
        if len(pos) != 2:
            err(f"Error: accepts 2 arg(s), received {len(pos)}")
            return 1
        err("Error: Failed to read tags: Not implemented for Null Store")
        return 1
    if sub == "write":
        if len(pos) < 3:
            err(f"Error: requires at least 3 arg(s), only received {len(pos)}")
            return 1
        err("Error: Failed to write tags: Not implemented for Null Store")
        return 1
    if sub == "delete":
        if len(pos) < 3:
            err(f"Error: requires at least 3 arg(s), only received {len(pos)}")
            return 1
        err("Error: Failed to delete tags: Not implemented for Null Store")
        return 1
    err(f'Error: unknown command "{sub}" for "chamber tag"')
    return 1


def do_completion(subargs):
    if not subargs or subargs[0] in ("-h", "--help"):
        out(HELPS["completion"])
        return 0
    shell = subargs[0]
    if "-h" in subargs or "--help" in subargs:
        out(f"""Generate the autocompletion script for the {shell} shell.

Usage:
  chamber completion {shell} [flags]

Flags:
  -h, --help              help for {shell}
      --no-descriptions   disable completion descriptions

Global Flags:
{GLOBAL_FLAGS}""")
        return 0
    out(f"# completion script for chamber ({shell})")
    return 0


if __name__ == "__main__":
    sys.exit(command_main(sys.argv[1:]))
