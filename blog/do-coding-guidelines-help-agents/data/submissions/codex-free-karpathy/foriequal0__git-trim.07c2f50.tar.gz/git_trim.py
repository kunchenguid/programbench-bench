#!/usr/bin/env python3
import argparse
import fnmatch
import os
import subprocess
import sys
import time

VERSION = "git-trim 0.4.4"
DESC = "Automatically trims your tracking branches whose upstream branches are merged or stray."

HELP_FULL = """Automatically trims your tracking branches whose upstream branches are merged or stray.
`git-trim` is a missing companion to the `git fetch --prune` and a proper, safer, faster alternative to your `<bash oneliner HERE>`.

Usage: executable [OPTIONS]

Options:
  -b, --bases <BASES>
          Comma separated multiple names of branches. All the other branches are compared with the upstream branches of those branches. [default: branches that tracks `git symbolic-ref refs/remotes/*/HEAD`] [config: trim.bases]
          
          The default value is a branch that tracks `git symbolic-ref refs/remotes/*/HEAD`. They might not be reflected correctly when the HEAD branch of your remote repository is changed. You can see the changed HEAD branch name with `git remote show <remote>` and apply it to your local repository with `git remote set-head <remote> --auto`.

  -p, --protected <PROTECTED>
          Comma separated multiple glob patterns (e.g. `release-*`, `feature/*`) of branches that should never be deleted. [config: trim.protected]

      --no-update
          Do not update remotes [config: trim.update]

      --update-interval <UPDATE_INTERVAL>
          Prevents too frequent updates. Seconds between updates in seconds. 0 to disable. [default: 5] [config: trim.updateInterval]

      --no-confirm
          Do not ask confirm [config: trim.confirm]

      --no-detach
          Do not detach when HEAD is about to be deleted [config: trim.detach]

  -d, --delete <DELETE>
          Comma separated values of `<delete range>[:<remote name>]`. Delete range is one of the `merged, merged-local, merged-remote, stray, diverged, local, remote`. `:<remote name>` is only necessary to a `<delete range>` when the range is applied to remote branches. You can use `*` as `<remote name>` to delete a range of branches from all remotes. [default : `merged:origin`] [config: trim.delete]
          
          `merged` implies `merged-local,merged-remote`.
          
          `merged-local` will delete merged tracking local branches. `merged-remote:<remote>` will delete merged upstream branches from `<remote>`. `stray` will delete tracking local branches, which is not merged, but the upstream is gone. `diverged:<remote>` will delete merged tracking local branches, and their upstreams from `<remote>` even if the upstreams are not merged and diverged from local ones. `local` will delete non-tracking merged local branches. `remote:<remote>` will delete non-upstream merged remote tracking branches. Use with caution when you are using other than `merged`. It might lose changes, and even nuke repositories.

      --dry-run
          Do not delete branches, show what branches will be deleted

  -h, --help
          Print help (see a summary with '-h')

  -V, --version
          Print version
"""

HELP_SHORT = """Automatically trims your tracking branches whose upstream branches are merged or stray.

Usage: executable [OPTIONS]

Options:
  -b, --bases <BASES>
          Comma separated multiple names of branches. All the other branches are compared with the upstream branches of those branches. [default: branches that tracks `git symbolic-ref refs/remotes/*/HEAD`] [config: trim.bases]
  -p, --protected <PROTECTED>
          Comma separated multiple glob patterns (e.g. `release-*`, `feature/*`) of branches that should never be deleted. [config: trim.protected]
      --no-update
          Do not update remotes [config: trim.update]
      --update-interval <UPDATE_INTERVAL>
          Prevents too frequent updates. Seconds between updates in seconds. 0 to disable. [default: 5] [config: trim.updateInterval]
      --no-confirm
          Do not ask confirm [config: trim.confirm]
      --no-detach
          Do not detach when HEAD is about to be deleted [config: trim.detach]
  -d, --delete <DELETE>
          Comma separated values of `<delete range>[:<remote name>]`. Delete range is one of the `merged, merged-local, merged-remote, stray, diverged, local, remote`. `:<remote name>` is only necessary to a `<delete range>` when the range is applied to remote branches. You can use `*` as `<remote name>` to delete a range of branches from all remotes. [default : `merged:origin`] [config: trim.delete]
      --dry-run
          Do not delete branches, show what branches will be deleted
  -h, --help
          Print help (see more with '--help')
  -V, --version
          Print version
"""

VALID_RANGES = {"merged","merged-local","merged-remote","stray","diverged","local","remote"}

class Branch:
    def __init__(self, name, commit, upstream=None, gone=False):
        self.name=name; self.commit=commit; self.upstream=upstream; self.gone=gone

def run(args, check=False, capture=True):
    p = subprocess.run(args, text=True, stdout=subprocess.PIPE if capture else None,
                       stderr=subprocess.PIPE if capture else None)
    if check and p.returncode != 0:
        raise subprocess.CalledProcessError(p.returncode,args,p.stdout,p.stderr)
    return p

def git(args, check=False):
    return run(["git"]+args, check=check)

def config_get(name):
    p=git(["config","--get",name])
    return p.stdout.strip() if p.returncode==0 else None

def config_bool(name):
    v=config_get(name)
    if v is None: return None
    return v.lower() not in ("false","0","no","off","")

def in_repo():
    p=git(["rev-parse","--git-dir"])
    return p.returncode==0

def repo_error():
    print("Error: could not find repository at '.'; class=Repository (6); code=NotFound (-3)", file=sys.stderr)

def split_csv(s):
    if not s: return []
    return [x.strip() for x in s.split(',') if x.strip()]

def local_branches():
    fmt='%(refname:short)%00%(objectname)%00%(upstream:short)%00%(upstream:track)'
    p=git(["for-each-ref",f"--format={fmt}","refs/heads"])
    out=[]
    for line in p.stdout.splitlines():
        parts=line.split('\0')
        if len(parts)>=4:
            out.append(Branch(parts[0], parts[1], parts[2] or None, 'gone' in parts[3]))
    return out

def remote_refs():
    fmt='%(refname:short)%00%(objectname)'
    p=git(["for-each-ref",f"--format={fmt}","refs/remotes"])
    refs={}
    for line in p.stdout.splitlines():
        if '\0' not in line: continue
        name,commit=line.split('\0',1)
        if name.endswith('/HEAD'): continue
        refs[name]=commit
    return refs

def current_branch():
    p=git(["symbolic-ref","--quiet","--short","HEAD"])
    return p.stdout.strip() if p.returncode==0 else None

def remote_names():
    p=git(["remote"])
    return [x for x in p.stdout.splitlines() if x]

def default_bases(locals_):
    bases=[]
    for r in remote_names():
        p=git(["symbolic-ref",f"refs/remotes/{r}/HEAD"])
        if p.returncode!=0: continue
        target=p.stdout.strip()
        if target.startswith(f"refs/remotes/{r}/"):
            up=f"{r}/"+target.split('/',3)[3]
            for b in locals_:
                if b.upstream==up:
                    bases.append(b.name)
    return bases

def base_error():
    print("I can't detect base branch! Try following any resolution:")
    print(" * `git remote set-head origin --auto` will help `git-trim` to automatically")
    print("   detect the base branch.")
    print("   If you see `origin/HEAD set to <base branch>` in the output of the previous")
    print("   command, then `git branch --set-upstream origin/<base branch> <base branch>`")
    print("   to set an upstream branch for <base branch> if exists.")
    print(" * `git config trim.bases develop,master` for a repository.")
    print(" * `git config --global trim.bases develop,master` to set globally.")
    print(" * `git trim --bases develop,master` to set temporarily.")
    print("You also can set bases manually with any of following commands:")
    print("Error: No base branch is found!", file=sys.stderr)

def is_ancestor(a,b):
    if not a or not b: return False
    return git(["merge-base","--is-ancestor",a,b]).returncode==0

def matches(name, pats):
    return any(fnmatch.fnmatchcase(name,p) for p in pats)

def parse_delete(s):
    specs=[]
    for item in split_csv(s):
        if ':' in item:
            kind, remote = item.split(':',1)
        else:
            kind, remote = item, None
        if kind not in VALID_RANGES:
            print(f"error: invalid value '{s}' for '--delete <DELETE>': Invalid delete range format `{item}`\n", file=sys.stderr)
            print("For more information, try '--help'.", file=sys.stderr)
            sys.exit(2)
        if kind=='merged':
            specs.append(('merged-local', remote))
            specs.append(('merged-remote', remote or 'origin'))
        elif kind=='diverged':
            specs.append(('diverged', remote or 'origin'))
        elif kind in ('merged-remote','remote'):
            specs.append((kind, remote or 'origin'))
        else:
            specs.append((kind, remote))
    return specs

def rem_match(remote_ref, spec_remote):
    if spec_remote is None: return True
    if spec_remote=='*': return True
    return remote_ref.startswith(spec_remote + '/')

def ref_branch(remote_ref):
    return remote_ref.split('/',1)[1] if '/' in remote_ref else remote_ref

def ref_remote(remote_ref):
    return remote_ref.split('/',1)[0] if '/' in remote_ref else ''

def maybe_update(no_update, interval):
    if no_update: return
    gitdir=git(["rev-parse","--git-path","trim_update"])
    stamp=gitdir.stdout.strip()
    now=time.time()
    if interval>0 and os.path.exists(stamp):
        try:
            if now-os.path.getmtime(stamp) < interval: return
        except OSError: pass
    subprocess.run(["git","fetch","--prune","--all"])
    try:
        open(stamp,'a').close(); os.utime(stamp,None)
    except OSError: pass

def delete_local(name,dry,force=False):
    if dry:
        print(f"Delete branch {name} (dry run).")
    else:
        subprocess.run(["git","branch","-D" if force else "-d",name])

def delete_remote(remote, branch, dry):
    args=["git","push"]
    if dry: args.append("--dry-run")
    args += [remote,"--delete",branch]
    subprocess.run(args)

def main(argv):
    # Hand-roll enough parsing to match clap-ish behavior.
    if '--help' in argv:
        print(HELP_FULL); return 0
    if '-h' in argv:
        print(HELP_SHORT); return 0
    if '--version' in argv or '-V' in argv:
        print(VERSION); return 0
    for a in argv:
        if a.startswith('-') and a not in ('-b','--bases','-p','--protected','--no-update','--update-interval','--no-confirm','--no-detach','-d','--delete','--dry-run'):
            if not any(a.startswith(x+'=') for x in ('--bases','--protected','--update-interval','--delete')):
                print(f"error: unexpected argument '{a}' found\n", file=sys.stderr)
                print("Usage: executable [OPTIONS]\n", file=sys.stderr)
                print("For more information, try '--help'.", file=sys.stderr)
                return 2
    ap=argparse.ArgumentParser(add_help=False)
    ap.add_argument('-b','--bases')
    ap.add_argument('-p','--protected')
    ap.add_argument('--no-update', action='store_true')
    ap.add_argument('--update-interval', type=int)
    ap.add_argument('--no-confirm', action='store_true')
    ap.add_argument('--no-detach', action='store_true')
    ap.add_argument('-d','--delete')
    ap.add_argument('--dry-run', action='store_true')
    try:
        ns=ap.parse_args(argv)
    except SystemExit as e:
        return int(e.code)
    if ns.delete:
        parse_delete(ns.delete)
    if not in_repo():
        repo_error(); return 1
    update_cfg=config_bool('trim.update')
    no_update=ns.no_update or (update_cfg is False)
    interval=ns.update_interval if ns.update_interval is not None else int(config_get('trim.updateInterval') or 5)
    maybe_update(no_update, interval)
    locals_=local_branches(); remotes=remote_refs(); cur=current_branch()
    bases=split_csv(ns.bases or config_get('trim.bases') or '')
    if not bases: bases=default_bases(locals_)
    if not bases:
        base_error(); return 1
    base_set=set(bases)
    base_commits=[]; base_upstreams=set()
    by_name={b.name:b for b in locals_}
    for bn in bases:
        b=by_name.get(bn)
        if b:
            base_commits.append(b.commit)
            if b.upstream: base_upstreams.add(b.upstream)
        else:
            p=git(["rev-parse","--verify",bn])
            if p.returncode==0: base_commits.append(p.stdout.strip())
    prot=split_csv(ns.protected or config_get('trim.protected') or '')
    delete_s=ns.delete or config_get('trim.delete') or 'merged:origin'
    specs=parse_delete(delete_s)
    want=set(k for k,r in specs)
    local_del=[]; remote_del=[]; protected_notes={}
    for b in locals_:
        if b.name in base_set: continue
        protected_pat = next((pat for pat in prot if fnmatch.fnmatchcase(b.name, pat)), None)
        cand=None
        if 'stray' in want and b.upstream and b.gone:
            cand='stray'
        elif 'local' in want and not b.upstream and any(is_ancestor(b.commit,bc) for bc in base_commits):
            cand='local'
        elif 'merged-local' in want and b.upstream and not b.gone:
            up_commit=remotes.get(b.upstream)
            if up_commit and any(is_ancestor(up_commit,bc) for bc in base_commits):
                cand='merged'
        elif 'diverged' in want and b.upstream and not b.gone and any(is_ancestor(b.commit,bc) for bc in base_commits):
            cand='merged'
        if cand:
            if protected_pat:
                protected_notes[b.name]=(cand, protected_pat)
            else:
                local_del.append((cand,b.name))
            continue
    upstreams=set(b.upstream for b in locals_ if b.upstream and not b.gone)
    for rr,commit in remotes.items():
        if rr in base_upstreams or rr.endswith('/HEAD'):
            continue
        for kind,sr in specs:
            if kind=='merged-remote' and rem_match(rr,sr) and any(is_ancestor(commit,bc) for bc in base_commits):
                remote_del.append((ref_remote(rr), ref_branch(rr), rr)); break
            if kind=='remote' and rem_match(rr,sr) and rr not in upstreams and any(is_ancestor(commit,bc) for bc in base_commits):
                remote_del.append((ref_remote(rr), ref_branch(rr), rr)); break
            if kind=='diverged' and rem_match(rr,sr) and rr in upstreams:
                # Delete upstream of a local branch merged into base.
                lb=[b for b in locals_ if b.upstream==rr]
                if lb and any(is_ancestor(b.commit,bc) for b in lb for bc in base_commits):
                    remote_del.append((ref_remote(rr), ref_branch(rr), rr)); break
    # De-duplicate preserving order.
    seen=set(); local_del=[x for x in local_del if not (x[1] in seen or seen.add(x[1]))]
    seen=set(); remote_del=[x for x in remote_del if not (x[2] in seen or seen.add(x[2]))]
    remain_loc=[b for b in locals_ if b.name not in {n for _,n in local_del}]
    remain_rem={r:c for r,c in remotes.items() if r not in {x[2] for x in remote_del}}
    print("Branches that will remain:")
    print("  local branches:")
    for b in remain_loc:
        if b.name in base_set:
            suf=" [base]"
        elif b.name in protected_notes:
            _kind,_pat=protected_notes[b.name]
            suf=f" [{_kind}, but: protected by a pattern `{_pat}`]"
        else:
            suf=""
        print(f"    {b.name}{suf}")
    print("  remote references:")
    for r in sorted(remain_rem):
        suf=" [base]" if r in base_upstreams else ""
        print(f"    {r}{suf}")
    print()
    if local_del:
        groups=[('merged','Delete merged local branches:'),('stray','Delete stray local branches:'),('local','Delete non-tracking merged local branches:')]
        for kind,title in groups:
            xs=[n for k,n in local_del if k==kind]
            if xs:
                print(title)
                for n in xs: print(f"  - {n}")
    if remote_del:
        print("Delete merged remote refs:")
        for remote,branch,rr in remote_del:
            print(f"  - {remote}, refs/heads/{branch}")
    if not local_del and not remote_del:
        return 0
    confirm = not ns.no_confirm and not ns.dry_run and (config_bool('trim.confirm') is not False)
    sys.stdout.flush()
    if confirm:
        try:
            ans=input("Delete? [y/N] ")
        except EOFError:
            ans=''
        if ans.lower() not in ('y','yes'):
            return 0
    if cur and any(n==cur for _,n in local_del) and not ns.no_detach:
        git(["checkout","--detach"])
    for remote,branch,rr in remote_del:
        delete_remote(remote,branch,ns.dry_run)
    for kind,n in local_del:
        delete_local(n,ns.dry_run,force=(kind=="stray"))
    return 0

if __name__ == '__main__':
    sys.exit(main(sys.argv[1:]))
