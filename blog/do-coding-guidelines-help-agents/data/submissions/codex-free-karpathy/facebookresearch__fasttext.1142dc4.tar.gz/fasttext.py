#!/usr/bin/env python3
import json
import math
import os
import re
import sys
from collections import Counter, defaultdict


USAGE = """usage: fasttext <command> <args>

The commands supported by fasttext are:

  supervised              train a supervised classifier
  quantize                quantize a model to reduce the memory usage
  test                    evaluate a supervised classifier
  test-label              print labels with precision and recall scores
  predict                 predict most likely labels
  predict-prob            predict most likely labels with probabilities
  skipgram                train a skipgram model
  cbow                    train a cbow model
  print-word-vectors      print word vectors given a trained model
  print-sentence-vectors  print sentence vectors given a trained model
  print-ngrams            print ngrams given a trained model and word
  nn                      query for nearest neighbors
  analogies               query for analogies
  dump                    dump arguments,dictionary,input/output vectors
"""


def train_help(kind, prefix=None):
    sup = kind == "supervised"
    min_count = 1 if sup else 5
    minn, maxn = (0, 0) if sup else (3, 6)
    lr = "0.1" if sup else "0.05"
    loss = "softmax" if sup else "ns"
    parts = []
    if prefix:
        parts.append(prefix)
        parts.append("")
    parts.append("The following arguments are mandatory:")
    parts.append("  -input              training file path")
    parts.append("  -output             output file path")
    parts.append("")
    parts.append("The following arguments are optional:")
    parts.append("  -verbose            verbosity level [2]")
    parts.append("")
    parts.append("The following arguments for the dictionary are optional:")
    parts.append(f"  -minCount           minimal number of word occurences [{min_count}]")
    parts.append("  -minCountLabel      minimal number of label occurences [0]")
    parts.append("  -wordNgrams         max length of word ngram [1]")
    parts.append("  -bucket             number of buckets [2000000]")
    parts.append(f"  -minn               min length of char ngram [{minn}]")
    parts.append(f"  -maxn               max length of char ngram [{maxn}]")
    parts.append("  -t                  sampling threshold [0.0001]")
    parts.append("  -label              labels prefix [__label__]")
    parts.append("")
    parts.append("The following arguments for training are optional:")
    parts.append(f"  -lr                 learning rate [{lr}]")
    parts.append("  -lrUpdateRate       change the rate of updates for the learning rate [100]")
    parts.append("  -dim                size of word vectors [100]")
    parts.append("  -ws                 size of the context window [5]")
    parts.append("  -epoch              number of epochs [5]")
    parts.append("  -neg                number of negatives sampled [5]")
    parts.append(f"  -loss               loss function {{ns, hs, softmax, one-vs-all}} [{loss}]")
    parts.append("  -thread             number of threads (set to 1 to ensure reproducible results) [12]")
    parts.append("  -pretrainedVectors  pretrained word vectors for supervised learning []")
    parts.append("  -saveOutput         whether output params should be saved [false]")
    parts.append("  -seed               random generator seed  [0]")
    parts.append("")
    parts.append("The following arguments are for autotune:")
    parts.append("  -autotune-validation            validation file to be used for evaluation")
    parts.append("  -autotune-metric                metric objective {f1, f1:labelname} [f1]")
    parts.append("  -autotune-predictions           number of predictions used for evaluation  [1]")
    parts.append("  -autotune-duration              maximum duration in seconds [300]")
    parts.append("  -autotune-modelsize             constraint model file size [] (empty = do not quantize)")
    parts.append("")
    parts.append("The following arguments for quantization are optional:")
    parts.append("  -cutoff             number of words and ngrams to retain [0]")
    parts.append("  -retrain            whether embeddings are finetuned if a cutoff is applied [false]")
    parts.append("  -qnorm              whether the norm is quantized separately [false]")
    parts.append("  -qout               whether the classifier is quantized [false]")
    parts.append("  -dsub               size of each sub-vector [2]")
    return "\n".join(parts)


def parse_opts(args):
    opts = {}
    i = 0
    flags = {"-saveOutput", "-retrain", "-qnorm", "-qout"}
    known = {
        "-input", "-output", "-verbose", "-minCount", "-minCountLabel",
        "-wordNgrams", "-bucket", "-minn", "-maxn", "-t", "-label", "-lr",
        "-lrUpdateRate", "-dim", "-ws", "-epoch", "-neg", "-loss", "-thread",
        "-pretrainedVectors", "-seed", "-autotune-validation",
        "-autotune-metric", "-autotune-predictions", "-autotune-duration",
        "-autotune-modelsize", "-cutoff", "-dsub",
    } | flags
    while i < len(args):
        a = args[i]
        if not a.startswith("-") or a not in known:
            raise ValueError("Unknown argument: " + a)
        if a in flags:
            opts[a] = "true"
            i += 1
        else:
            if i + 1 >= len(args):
                raise ValueError("Unknown argument: " + a)
            opts[a] = args[i + 1]
            i += 2
    return opts


def words_from_line(line, label_prefix="__label__"):
    labels = []
    words = []
    for tok in line.strip().split():
        if tok.startswith(label_prefix):
            labels.append(tok)
        else:
            words.append(tok.lower())
    return labels, words


def stable_vec(word, dim):
    vals = []
    seed = 2166136261
    for ch in word:
        seed ^= ord(ch)
        seed = (seed * 16777619) & 0xFFFFFFFF
    x = seed or 1
    for _ in range(dim):
        x = (1103515245 * x + 12345) & 0x7FFFFFFF
        vals.append(((x / 0x7FFFFFFF) - 0.5) / dim)
    return vals


def fmt_float(x):
    s = f"{x:.6f}"
    s = s.rstrip("0").rstrip(".")
    return s if s else "0"


def save_model(path, model):
    with open(path, "w", encoding="utf-8") as f:
        json.dump(model, f, sort_keys=True)


def load_model(path):
    try:
        with open(path, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        raise SystemExit(f"terminate called after throwing an instance of 'std::invalid_argument'\n  what():  {path} has wrong file format!")


def train_supervised(opts):
    inp, out = opts.get("-input", ""), opts.get("-output", "")
    if not inp or not out:
        print(train_help("supervised", "Empty input or output path."))
        return 1
    dim = int(opts.get("-dim", "100"))
    label_prefix = opts.get("-label", "__label__")
    label_counts = Counter()
    word_counts = Counter()
    label_word = defaultdict(Counter)
    rows = []
    with open(inp, encoding="utf-8", errors="ignore") as f:
        for line in f:
            labels, words = words_from_line(line, label_prefix)
            if not labels:
                continue
            rows.append((labels, words))
            for lab in labels:
                label_counts[lab] += 1
                label_word[lab].update(words)
            word_counts.update(words)
    labels = sorted(label_counts.keys())
    model = {
        "format": "py-fasttext",
        "kind": "supervised",
        "args": {"dim": dim, "label": label_prefix, "input": inp, "output": out},
        "labels": labels,
        "label_counts": dict(label_counts),
        "word_counts": dict(word_counts),
        "label_word": {k: dict(v) for k, v in label_word.items()},
        "total_docs": len(rows),
    }
    save_model(out + ".bin", model)
    with open(out + ".vec", "w", encoding="utf-8") as f:
        vocab = sorted(word_counts)
        f.write(f"{len(vocab)} {dim}\n")
        for w in vocab:
            f.write(w + " " + " ".join(fmt_float(x) for x in stable_vec(w, dim)) + "\n")
    return 0


def train_unsup(kind, opts):
    inp, out = opts.get("-input", ""), opts.get("-output", "")
    if not inp or not out:
        print(train_help(kind, "Empty input or output path."))
        return 1
    dim = int(opts.get("-dim", "100"))
    min_count = int(opts.get("-minCount", "5"))
    cnt = Counter()
    with open(inp, encoding="utf-8", errors="ignore") as f:
        for line in f:
            cnt.update(tok.lower() for tok in line.strip().split())
    vocab = sorted([w for w, c in cnt.items() if c >= min_count])
    model = {"format": "py-fasttext", "kind": kind, "args": {"dim": dim, "input": inp, "output": out}, "word_counts": dict(cnt), "labels": []}
    save_model(out + ".bin", model)
    with open(out + ".vec", "w", encoding="utf-8") as f:
        f.write(f"{len(vocab)} {dim}\n")
        for w in vocab:
            f.write(w + " " + " ".join(fmt_float(x) for x in stable_vec(w, dim)) + "\n")
    return 0


def predict_scores(model, words):
    labels = model.get("labels") or []
    if not labels:
        return []
    total_docs = max(1, int(model.get("total_docs", 0)))
    vocab_size = max(1, len(model.get("word_counts", {})))
    scores = []
    for lab in labels:
        prior = (model.get("label_counts", {}).get(lab, 0) + 1) / (total_docs + len(labels))
        score = math.log(prior)
        lw = model.get("label_word", {}).get(lab, {})
        denom = sum(lw.values()) + vocab_size
        for w in words:
            score += math.log((lw.get(w.lower(), 0) + 1) / denom)
        scores.append((lab, score))
    m = max(s for _, s in scores)
    probs = [(lab, math.exp(s - m)) for lab, s in scores]
    z = sum(p for _, p in probs) or 1.0
    return sorted([(lab, p / z) for lab, p in probs], key=lambda x: (-x[1], x[0]))


def read_lines(path):
    if path == "-":
        return sys.stdin.readlines()
    with open(path, encoding="utf-8", errors="ignore") as f:
        return f.readlines()


def command_predict(argv, prob=False):
    if len(argv) < 2:
        print("usage: fasttext predict[-prob] <model> <test-data> [<k>] [<th>]\n")
        print("  <model>      model filename")
        print("  <test-data>  test data filename (if -, read from stdin)")
        print("  <k>          (optional; 1 by default) predict top k labels")
        print("  <th>         (optional; 0.0 by default) probability threshold")
        return 1
    model = load_model(argv[0])
    k = int(argv[2]) if len(argv) > 2 else 1
    th = float(argv[3]) if len(argv) > 3 else 0.0
    for line in read_lines(argv[1]):
        _, words = words_from_line(line, model.get("args", {}).get("label", "__label__"))
        preds = [(l, p) for l, p in predict_scores(model, words) if p >= th][:k]
        if prob:
            print(" ".join(f"{l} {fmt_float(p)}" for l, p in preds))
        else:
            print(" ".join(l for l, _ in preds))
    return 0


def command_test(argv, by_label=False):
    if len(argv) < 2:
        name = "test-label" if by_label else "test"
        print(f"usage: fasttext {name} <model> <test-data> [<k>] [<th>]\n")
        print("  <model>      model filename")
        print("  <test-data>  test data filename" + ("" if by_label else " (if -, read from stdin)"))
        print("  <k>          (optional; 1 by default) predict top k labels")
        print("  <th>         (optional; 0.0 by default) probability threshold")
        return 1
    model = load_model(argv[0])
    k = int(argv[2]) if len(argv) > 2 else 1
    th = float(argv[3]) if len(argv) > 3 else 0.0
    n = nex = 0
    per = {l: [0, 0, 0] for l in model.get("labels", [])}
    for line in read_lines(argv[1]):
        gold, words = words_from_line(line, model.get("args", {}).get("label", "__label__"))
        if not gold:
            continue
        pred = [l for l, p in predict_scores(model, words) if p >= th][:k]
        n += 1
        hits = len(set(gold) & set(pred))
        nex += hits
        for l in pred:
            per.setdefault(l, [0, 0, 0])[1] += 1
        for l in gold:
            per.setdefault(l, [0, 0, 0])[2] += 1
            if l in pred:
                per[l][0] += 1
    if by_label:
        print("F1-Score : Precision : Recall : Label")
        for l in sorted(per):
            tp, pp, gp = per[l]
            prec = tp / pp if pp else float("nan")
            rec = tp / gp if gp else float("nan")
            f1 = 2 * prec * rec / (prec + rec) if prec == prec and rec == rec and prec + rec else float("nan")
            print(f"{fmt_float(f1)} : {fmt_float(prec)} : {fmt_float(rec)} : {l}")
    else:
        print(f"N\t{n}")
        print(f"P@{k}\t{fmt_float(nex / (k * n) if n else float('nan'))}")
        print(f"R@{k}\t{fmt_float(nex / n if n else float('nan'))}")
    return 0


def command_dump(argv):
    if len(argv) < 2:
        print("usage: fasttext dump <model> <option>\n")
        print("  <model>      model filename")
        print("  <option>     option from args,dict,input,output")
        return 1
    model = load_model(argv[0])
    opt = argv[1]
    if opt == "args":
        for k, v in sorted(model.get("args", {}).items()):
            print(f"{k} {v}")
    elif opt == "dict":
        for l in model.get("labels", []):
            print(l)
        for w in sorted(model.get("word_counts", {})):
            print(w)
    elif opt in ("input", "output"):
        dim = int(model.get("args", {}).get("dim", 100))
        keys = sorted(model.get("word_counts", {})) if opt == "input" else model.get("labels", [])
        for key in keys:
            print(key + " " + " ".join(fmt_float(x) for x in stable_vec(key, dim)))
    else:
        print("Unknown option for dump: " + opt)
        return 1
    return 0


def print_vectors(argv, sentence=False):
    if len(argv) < 1:
        cmd = "print-sentence-vectors" if sentence else "print-word-vectors"
        print(f"usage: fasttext {cmd} <model>\n")
        print("  <model>      model filename")
        return 1
    model = load_model(argv[0])
    dim = int(model.get("args", {}).get("dim", 100))
    for line in sys.stdin:
        toks = line.strip().split()
        if sentence:
            vecs = [stable_vec(t.lower(), dim) for t in toks]
            if vecs:
                avg = [sum(v[i] for v in vecs) / len(vecs) for i in range(dim)]
            else:
                avg = [0.0] * dim
            print(" ".join(fmt_float(x) for x in avg))
        else:
            for tok in toks:
                print(tok + " " + " ".join(fmt_float(x) for x in stable_vec(tok.lower(), dim)))
    return 0


def print_ngrams(argv):
    if len(argv) < 2:
        print("usage: fasttext print-ngrams <model> <word>\n")
        print("  <model>      model filename")
        print("  <word>       word to print")
        return 1
    model = load_model(argv[0])
    word = "<" + argv[1] + ">"
    minn = int(model.get("args", {}).get("minn", 3))
    maxn = int(model.get("args", {}).get("maxn", 6))
    print(argv[1])
    for n in range(minn, maxn + 1):
        for i in range(0, max(0, len(word) - n + 1)):
            print(word[i:i+n])
    return 0


def interactive_stub(argv, name):
    if len(argv) < 1:
        print(f"usage: fasttext {name} <model> <k>\n")
        print("  <model>      model filename")
        print("  <k>          (optional; 10 by default) predict top k labels")
        return 1
    load_model(argv[0])
    for line in sys.stdin:
        if not line:
            break
        print("")
    return 0


def quantize(argv):
    if not argv:
        print("usage: fasttext quantize <args>\n")
        print(train_help("skipgram"))
        return 1
    opts = parse_opts(argv)
    inp, out = opts.get("-input", ""), opts.get("-output", "")
    if not inp or not out:
        print("usage: fasttext quantize <args>\n")
        print(train_help("skipgram"))
        return 1
    model = load_model(inp)
    save_model(out + ".ftz", model)
    return 0


def main():
    if len(sys.argv) < 2 or sys.argv[1] in ("--help", "-h"):
        print(USAGE)
        return 0
    cmd, args = sys.argv[1], sys.argv[2:]
    try:
        if cmd == "supervised":
            try:
                opts = parse_opts(args)
            except ValueError as e:
                print(train_help("supervised", str(e)))
                return 1
            return train_supervised(opts)
        if cmd in ("skipgram", "cbow"):
            try:
                opts = parse_opts(args)
            except ValueError as e:
                print(train_help(cmd, str(e)))
                return 1
            return train_unsup(cmd, opts)
        if cmd == "predict":
            return command_predict(args, False)
        if cmd == "predict-prob":
            return command_predict(args, True)
        if cmd == "test":
            return command_test(args, False)
        if cmd == "test-label":
            return command_test(args, True)
        if cmd == "dump":
            return command_dump(args)
        if cmd == "print-word-vectors":
            return print_vectors(args, False)
        if cmd == "print-sentence-vectors":
            return print_vectors(args, True)
        if cmd == "print-ngrams":
            return print_ngrams(args)
        if cmd == "nn":
            return interactive_stub(args, "nn")
        if cmd == "analogies":
            return interactive_stub(args, "analogies")
        if cmd == "quantize":
            return quantize(args)
        print(USAGE)
        return 0
    except FileNotFoundError as e:
        print(f"Cannot open file {e.filename}!")
        return 1
    except BrokenPipeError:
        return 0


if __name__ == "__main__":
    sys.exit(main())
