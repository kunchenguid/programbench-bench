package main

import (
    "bytes"
    "flag"
    "fmt"
    "go/ast"
    "go/format"
    "go/parser"
    "go/token"
    "io"
    "os"
    "path/filepath"
    "regexp"
    "sort"
    "strings"
    "unicode"
)

type options struct {
    all, exported, named, nosub, parallel, inputs, write, useCmp, ai bool
    only, excl string
    tmpl, tmplDir, tmplParams, tmplParamsFile string
    aiEndpoint, aiModel string
    aiMin, aiMax int
}

type field struct{ name, typ string }
type fninfo struct {
    name string
    recvName string
    recvBase string
    recvExpr string
    recvIsPtr bool
    recvTypeParams []string
    typeParams []string
    params []field
    results []field
    isMethod bool
    fields []field
}

type typeinfo struct {
    fields []field
    typeParams []string
}

func main() {
    var opt options
    flag.BoolVar(&opt.ai, "ai", false, "generate test cases using AI (requires Ollama)")
    flag.StringVar(&opt.aiEndpoint, "ai-endpoint", "http://localhost:11434", "Ollama API endpoint")
    flag.IntVar(&opt.aiMax, "ai-max-cases", 10, "maximum number of test cases to generate with AI")
    flag.IntVar(&opt.aiMin, "ai-min-cases", 3, "minimum number of test cases to generate with AI")
    flag.StringVar(&opt.aiModel, "ai-model", "qwen2.5-coder:0.5b", "AI model to use for test generation")
    flag.BoolVar(&opt.all, "all", false, "generate tests for all functions and methods")
    flag.StringVar(&opt.excl, "excl", "", "regexp. generate tests for functions and methods that don't match. Takes precedence over -only, -exported, and -all")
    flag.BoolVar(&opt.exported, "exported", false, "generate tests for exported functions and methods. Takes precedence over -only and -all")
    flag.BoolVar(&opt.inputs, "i", false, "print test inputs in error messages")
    flag.BoolVar(&opt.named, "named", false, "switch table tests from using slice to map (with test name for the key)")
    flag.BoolVar(&opt.nosub, "nosubtests", false, "disable generating tests using the Go 1.7 subtests feature")
    flag.StringVar(&opt.only, "only", "", "regexp. generate tests for functions and methods that match only. Takes precedence over -all")
    flag.BoolVar(&opt.parallel, "parallel", false, "enable generating parallel subtests using the Go 1.7 feature")
    flag.StringVar(&opt.tmpl, "template", "", "optional. Specify custom test code templates, e.g. testify. This can also be set via environment variable GOTESTS_TEMPLATE")
    flag.StringVar(&opt.tmplDir, "template_dir", "", "optional. Path to a directory containing custom test code templates. Takes precedence over -template. This can also be set via environment variable GOTESTS_TEMPLATE_DIR")
    flag.StringVar(&opt.tmplParams, "template_params", "", "read external parameters to template by json with stdin")
    flag.StringVar(&opt.tmplParamsFile, "template_params_file", "", "read external parameters to template by json with file")
    flag.BoolVar(&opt.useCmp, "use_go_cmp", false, "use cmp.Equal (google/go-cmp) instead of reflect.DeepEqual")
    ver := flag.Bool("version", false, "print version information and exit")
    flag.BoolVar(&opt.write, "w", false, "write output to (test) files instead of stdout")
    flag.Parse()
    if *ver {
        fmt.Println("gotests v0.0.0-20260303205902-f3b63d74369a")
        fmt.Println("Go version: go1.24.5")
        fmt.Println("Git commit: f3b63d74369a8c405a9a3990a656a278a4f9096f")
        fmt.Println("Build time: 2026-03-03T20:59:02Z")
        return
    }
    if !opt.all && !opt.exported && opt.only == "" && opt.excl == "" {
        fmt.Println("Please specify either the -only, -excl, -exported, or -all flag")
        return
    }
    paths := flag.Args()
    if len(paths) == 0 { paths = []string{"."} }
    files := expandPaths(paths)
    if len(files) == 0 { return }
    for _, p := range files {
        out, names, err := generate(p, opt)
        if err != nil { fmt.Fprintln(os.Stderr, err); continue }
        for _, n := range names { fmt.Fprintf(os.Stderr, "Generated %s\n", n) }
        if opt.write {
            target := strings.TrimSuffix(p, ".go") + "_test.go"
            if strings.HasSuffix(p, "_test.go") { target = p }
            os.WriteFile(target, out, 0644)
        } else {
            os.Stdout.Write(out)
        }
    }
}

func expandPaths(paths []string) []string {
    var files []string
    for _, p := range paths {
        if strings.HasSuffix(p, "/...") {
            root := strings.TrimSuffix(p, "/...")
            filepath.WalkDir(root, func(path string, d os.DirEntry, err error) error {
                if err == nil && !d.IsDir() && strings.HasSuffix(path, ".go") && !strings.HasSuffix(path, "_test.go") { files = append(files, path) }
                return nil
            })
            continue
        }
        matches, _ := filepath.Glob(p)
        if len(matches) == 0 { matches = []string{p} }
        for _, m := range matches {
            st, err := os.Stat(m); if err != nil { continue }
            if st.IsDir() {
                ents, _ := os.ReadDir(m)
                for _, e := range ents { if !e.IsDir() && strings.HasSuffix(e.Name(), ".go") && !strings.HasSuffix(e.Name(), "_test.go") { files = append(files, filepath.Join(m,e.Name())) } }
            } else if strings.HasSuffix(m, ".go") && !strings.HasSuffix(m, "_test.go") { files = append(files, m) }
        }
    }
    sort.Strings(files)
    return files
}

func generate(path string, opt options) ([]byte, []string, error) {
    fset := token.NewFileSet()
    f, err := parser.ParseFile(fset, path, nil, parser.ParseComments)
    if err != nil { return nil, nil, err }
    types := map[string]typeinfo{}
    for _, d := range f.Decls {
        gd, ok := d.(*ast.GenDecl); if !ok || gd.Tok != token.TYPE { continue }
        for _, sp := range gd.Specs {
            ts := sp.(*ast.TypeSpec)
            ti := typeinfo{}
            if ts.TypeParams != nil { for _, p := range ts.TypeParams.List { for _, n := range p.Names { ti.typeParams = append(ti.typeParams, n.Name) } } }
            if st, ok := ts.Type.(*ast.StructType); ok {
                for _, fl := range st.Fields.List {
                    typ := exprString(fset, fl.Type)
                    if len(fl.Names) == 0 { ti.fields = append(ti.fields, field{name: embeddedName(typ), typ: typ}) }
                    for _, n := range fl.Names { if n.IsExported() { ti.fields = append(ti.fields, field{name:n.Name, typ:typ}) } }
                }
            }
            types[ts.Name.Name] = ti
        }
    }
    var funcs []fninfo
    for _, d := range f.Decls {
        fd, ok := d.(*ast.FuncDecl); if !ok || fd.Name.Name == "main" { continue }
        info := fninfo{name: fd.Name.Name}
        if fd.Type.TypeParams != nil { for _, p := range fd.Type.TypeParams.List { for _, n := range p.Names { info.typeParams = append(info.typeParams, n.Name) } } }
        if fd.Recv != nil && len(fd.Recv.List) > 0 {
            info.isMethod = true
            r := fd.Recv.List[0]
            if len(r.Names) > 0 { info.recvName = r.Names[0].Name } else { info.recvName = strings.ToLower(string(baseReceiverName(fset, r.Type)[0])) }
            info.recvExpr = exprString(fset, r.Type)
            info.recvBase = baseReceiverName(fset, r.Type)
            _, info.recvIsPtr = r.Type.(*ast.StarExpr)
            if ti, ok := types[info.recvBase]; ok { info.fields = ti.fields; info.recvTypeParams = ti.typeParams }
        }
        info.params = paramsFromList(fset, fd.Type.Params)
        info.results = resultsFromList(fset, fd.Type.Results)
        if selected(info, opt) { funcs = append(funcs, info) }
    }
    var names []string
    var b strings.Builder
    b.WriteString("package "+f.Name.Name+"\n\n")
    needReflect, needCmp := false, false
    for _, fn := range funcs { if fn.needsDeep() { if opt.useCmp { needCmp = true } else { needReflect = true } } }
    writeImports(&b, needReflect, needCmp)
    for _, fn := range funcs {
        names = append(names, fn.testName())
        b.WriteString(renderFunc(fn, opt))
        b.WriteString("\n")
    }
    src := []byte(b.String())
    fmtd, err := format.Source(src); if err == nil { src = fmtd }
    return src, names, nil
}

func selected(fn fninfo, opt options) bool {
    full := fn.name; if fn.isMethod { full = fn.recvBase + "." + fn.name }
    if opt.excl != "" { re, err := regexp.Compile(opt.excl); return err == nil && !re.MatchString(full) && !re.MatchString(fn.name) }
    if opt.exported { return ast.IsExported(fn.name) }
    if opt.only != "" { re, err := regexp.Compile(opt.only); return err == nil && (re.MatchString(full) || re.MatchString(fn.name)) }
    return opt.all
}

func writeImports(b *strings.Builder, reflect, cmp bool) {
    if !reflect && !cmp { b.WriteString("import \"testing\"\n\n"); return }
    b.WriteString("import (\n")
    if reflect { b.WriteString("\t\"reflect\"\n") }
    b.WriteString("\t\"testing\"\n")
    if cmp { b.WriteString("\n\t\"github.com/google/go-cmp/cmp\"\n") }
    b.WriteString(")\n\n")
}

func renderFunc(fn fninfo, opt options) string {
    var b strings.Builder
    fmt.Fprintf(&b, "func %s(t *testing.T) {\n", fn.testName())
    if opt.parallel { b.WriteString("\tt.Parallel()\n") }
    if len(fn.fields) > 0 && !fn.recvIsPtr { b.WriteString("\ttype fields struct {\n"); for _, f := range fn.fields { fmt.Fprintf(&b,"\t\t%s %s\n", f.name, concreteType(f.typ)) }; b.WriteString("\t}\n") }
    if len(fn.params) > 0 { b.WriteString("\ttype args struct {\n"); for _, p := range fn.params { fmt.Fprintf(&b,"\t\t%s %s\n", p.name, concreteType(p.typ)) }; b.WriteString("\t}\n") }
    if opt.named { b.WriteString("\ttests := map[string]struct {\n") } else { b.WriteString("\ttests := []struct {\n\t\tname string\n") }
    if len(fn.fields) > 0 && !fn.recvIsPtr { b.WriteString("\t\tfields fields\n") }
    if fn.recvIsPtr { fmt.Fprintf(&b, "\t\t%s %s\n", fn.recvName, concreteRecv(fn.recvExpr)) }
    if len(fn.params) > 0 { b.WriteString("\t\targs args\n") }
    for i, r := range fn.results {
        nm := wantName(r, i, len(fn.results))
        typ := concreteType(r.typ)
        if isError(r.typ) { nm = "wantErr"; typ = "bool" }
        fmt.Fprintf(&b,"\t\t%s %s\n", nm, typ)
    }
    b.WriteString("\t}{\n\t\t// TODO: Add test cases.\n\t}\n")
    if opt.named { b.WriteString("\tfor name, tt := range tests {\n") } else { b.WriteString("\tfor _, tt := range tests {\n") }
    if opt.nosub {
        if opt.named { b.WriteString("\t\t_ = name\n") }
        b.WriteString(renderBody(fn,opt,"\t",false)); b.WriteString("\t}\n}\n"); return b.String()
    }
    if opt.named { b.WriteString("\t\tt.Run(name, func(t *testing.T) {\n") } else { b.WriteString("\t\tt.Run(tt.name, func(t *testing.T) {\n") }
    if opt.parallel { b.WriteString("\t\t\tt.Parallel()\n") }
    b.WriteString(renderBody(fn,opt,"\t\t\t",true))
    b.WriteString("\t\t})\n\t}\n}\n")
    return b.String()
}

func renderBody(fn fninfo, opt options, ind string, sub bool) string {
    var b strings.Builder
    callRecv := ""
    if fn.isMethod {
        callRecv = fn.recvName
        if fn.recvIsPtr {
            fmt.Fprintf(&b, "%s%s := &%s{}\n", ind, fn.recvName, strings.TrimPrefix(concreteRecv(fn.recvExpr), "*"))
        } else {
            fmt.Fprintf(&b, "%s%s := %s{\n", ind, fn.recvName, concreteRecv(fn.recvExpr))
            for _, f := range fn.fields { fmt.Fprintf(&b, "%s\t%s: tt.fields.%s,\n", ind, f.name, f.name) }
            fmt.Fprintf(&b, "%s}\n", ind)
        }
    }
    call := fn.callExpr(callRecv)
    nonErr := fn.nonErrResults()
    hasErr := fn.hasError()
    switch len(fn.results) {
    case 0:
        fmt.Fprintf(&b, "%s%s\n", ind, call)
    case 1:
        if hasErr {
            fmt.Fprintf(&b, "%serr := %s\n", ind, call)
            b.WriteString(errorCheck(fn,opt,ind,sub))
        } else {
            cond, msg := compareExpr(fn,opt,"got","tt.want",0)
            fmt.Fprintf(&b, "%sif got := %s; %s {\n", ind, call, cond)
            fmt.Fprintf(&b, "%s\tt.Errorf(%s)\n%s}\n", ind, errArgs(fn,opt,msg,0), ind)
        }
    default:
        vars := []string{}
        for i, r := range fn.results { if isError(r.typ) { vars = append(vars,"err") } else if r.name != "" { vars = append(vars,"got"+upperFirst(r.name)) } else if len(nonErr)==1 { vars = append(vars,"got") } else { n:=countNonErrBefore(fn.results,i); if n==0 { vars=append(vars,"got") } else { vars = append(vars, fmt.Sprintf("got%d", n)) } } }
        fmt.Fprintf(&b, "%s%s := %s\n", ind, strings.Join(vars, ", "), call)
        if hasErr { b.WriteString(errorCheck(fn,opt,ind,sub)) }
        ni := 0
        for i, r := range fn.results {
            if isError(r.typ) { continue }
            got := vars[i]; want := "tt."+wantName(r,i,len(fn.results))
            cond, msg := compareExpr(fn,opt,got,want,ni)
            fmt.Fprintf(&b, "%sif %s {\n", ind, cond)
            fmt.Fprintf(&b, "%s\tt.Errorf(%s)\n%s}\n", ind, errArgs(fn,opt,msg,ni), ind)
            ni++
        }
    }
    return b.String()
}

func errorCheck(fn fninfo, opt options, ind string, sub bool) string {
    name := displayName(fn)
    prefix := name + "()"
    if opt.inputs { prefix = inputFormat(fn) + " error" } else { prefix += " error" }
    fatal := "Fatalf"; if opt.nosub { fatal = "Errorf" }
    args := []string{"err", "tt.wantErr"}
    if opt.inputs { args = append(inputArgs(fn), args...) }
    s := fmt.Sprintf("%sif (err != nil) != tt.wantErr {\n%s\tt.%s(\"%s = %%v, wantErr %%v\", %s)\n", ind, ind, fatal, prefix, strings.Join(args, ", "))
    if opt.nosub { s += ind+"\tcontinue\n" }
    s += ind+"}\n"+ind+"if tt.wantErr {\n"+ind+"\treturn\n"+ind+"}\n"
    return s
}

func compareExpr(fn fninfo, opt options, got, want string, idx int) (string,string) {
    if fn.needsDeepAt(idx) {
        if opt.useCmp { return fmt.Sprintf("!cmp.Equal(%s, %s)", want, got), fmt.Sprintf("\"%s = %%v, want %%v\\ndiff=%%s\", %s, %s, cmp.Diff(%s, %s)", errPrefix(fn,opt,idx), got, want, want, got) }
        return fmt.Sprintf("!reflect.DeepEqual(%s, %s)", got, want), fmt.Sprintf("\"%s = %%v, want %%v\", %s, %s", errPrefix(fn,opt,idx), got, want)
    }
    return fmt.Sprintf("%s != %s", got, want), fmt.Sprintf("\"%s = %%v, want %%v\", %s, %s", errPrefix(fn,opt,idx), got, want)
}
func errArgs(fn fninfo,opt options,msg string,idx int) string {
    if !opt.inputs { return msg }
    cut := strings.Index(msg, "\", ")
    if cut < 0 { return msg }
    args := strings.Join(inputArgs(fn), ", ")
    if args == "" { return msg }
    return msg[:cut+2] + args + ", " + msg[cut+3:]
}
func errPrefix(fn fninfo,opt options,idx int) string { if opt.inputs { return inputFormat(fn) }; if idx>0 || len(fn.nonErrResults())>1 { if idx==0 { return displayName(fn)+"() got"}; return fmt.Sprintf("%s() got%d", displayName(fn), idx) }; return displayName(fn)+"()" }
func inputFormat(fn fninfo) string { vals:=[]string{}; for _,p:= range fn.params { vals=append(vals,"%v"); _=p }; return displayName(fn)+"("+strings.Join(vals, ", ")+")" }
func inputArgs(fn fninfo) []string { vals:=[]string{}; for _,p:= range fn.params { vals=append(vals,"tt.args."+p.name) }; return vals }

func (fn fninfo) callExpr(recv string) string { args:=[]string{}; for _,p:=range fn.params { args=append(args,"tt.args."+p.name) }; name:=fn.name; if len(fn.typeParams)>0 { name += "["+strings.Join(defaultTypes(len(fn.typeParams)), ", ")+"]" }; if fn.isMethod { return recv+"."+fn.name+"("+strings.Join(args, ", ")+")" }; return name+"("+strings.Join(args, ", ")+")" }
func (fn fninfo) testName() string { if fn.isMethod { return "Test"+fn.recvBase+"_"+fn.name }; if ast.IsExported(fn.name) { return "Test"+fn.name }; return "Test_"+fn.name }
func displayName(fn fninfo) string { if fn.isMethod { if len(fn.recvTypeParams)>0 { return fn.recvBase+"[T]."+fn.name }; return fn.recvBase+"."+fn.name }; return fn.name }
func (fn fninfo) hasError() bool { for _,r:=range fn.results { if isError(r.typ) { return true } }; return false }
func (fn fninfo) nonErrResults() []field { var out []field; for _,r:=range fn.results { if !isError(r.typ) { out=append(out,r) } }; return out }
func (fn fninfo) needsDeep() bool { for i:=range fn.nonErrResults(){ if fn.needsDeepAt(i){return true} }; return false }
func (fn fninfo) needsDeepAt(idx int) bool { rs:=fn.nonErrResults(); if idx>=len(rs){return false}; t:=rs[idx].typ; return strings.HasPrefix(t,"[]")||strings.HasPrefix(t,"map[")||strings.HasPrefix(t,"func(")||len(fn.typeParams)>0||strings.Contains(t,"interface{") }

func paramsFromList(fset *token.FileSet, fl *ast.FieldList) []field {
    if fl == nil { return nil }
    var out []field; unnamed:=0
    for _, f := range fl.List { typ:=exprString(fset,f.Type); if len(f.Names)==0 { out=append(out,field{name:fmt.Sprintf("arg%d", unnamed),typ:typ}); unnamed++; continue }; for _, n := range f.Names { out=append(out,field{name:n.Name,typ:typ}) } }
    return out
}
func resultsFromList(fset *token.FileSet, fl *ast.FieldList) []field {
    if fl == nil { return nil }
    var out []field
    for _, f := range fl.List { typ:=exprString(fset,f.Type); if len(f.Names)==0 { out=append(out,field{typ:typ}); continue }; for _, n := range f.Names { out=append(out,field{name:n.Name,typ:typ}) } }
    return out
}
func exprString(fset *token.FileSet, e ast.Expr) string { var b bytes.Buffer; format.Node(&b,fset,e); return b.String() }
func baseReceiverName(fset *token.FileSet, e ast.Expr) string { s:=exprString(fset,e); s=strings.TrimPrefix(s,"*"); if i:=strings.Index(s,"["); i>=0 { s=s[:i] }; return s }
func concreteRecv(s string) string { ptr:=strings.HasPrefix(s,"*"); s=strings.TrimPrefix(s,"*"); base:=s; if i:=strings.Index(base,"["); i>=0 { names:=strings.Split(strings.TrimSuffix(base[i+1:],"]"),","); base=base[:i]+"["+strings.Join(defaultTypes(len(names)),", ")+"]" }; if ptr { return "*"+base }; return base }
func concreteType(t string) string { for _, p := range []string{"T","K","V"} { if t==p { return "string" }; t=strings.ReplaceAll(t,"[]"+p,"[]string") }; return t }
func defaultTypes(n int) []string { out:=make([]string,n); for i:=range out { if i==0 { out[i]="string" } else { out[i]="int" } }; return out }
func isError(t string) bool { return t == "error" }
func wantName(r field, i,total int) string { if isError(r.typ){return "wantErr"}; if r.name!="" { return "want"+upperFirst(r.name) }; if total<=1 { return "want" }; if i==0 { return "want" }; return fmt.Sprintf("want%d", i) }
func countNonErrBefore(rs []field, idx int) int { c:=0; for i:=0;i<idx;i++{ if !isError(rs[i].typ){c++} }; return c }
func upperFirst(s string) string { if s==""{return s}; r:=[]rune(s); r[0]=unicode.ToUpper(r[0]); return string(r) }
func embeddedName(t string) string { t=strings.TrimPrefix(t,"*"); parts:=strings.FieldsFunc(t, func(r rune)bool{return r=='.'||r=='['||r==']'}); if len(parts)>0{return parts[len(parts)-1]}; return "field" }
var _ io.Reader
