package main

import (
	"bytes"
	"flag"
	"fmt"
	"go/ast"
	"go/format"
	"go/parser"
	"go/token"
	"io/fs"
	"log"
	"os"
	"path/filepath"
	"regexp"
	"sort"
	"strconv"
	"strings"
)

const version = "3.0.0-20260303205914-9926ea38658f"

type opts struct {
	applyGenerated  bool
	companyPrefixes string
	excludes        string
	filePath        string
	formatOnly      bool
	importsOrder    string
	listDiff        bool
	local           string
	output          string
	projectName     string
	recursive       bool
	rmUnused        bool
	separateNamed   bool
	setAlias        bool
	setExitStatus   bool
	useCache        bool
	versionFlag     bool
	versionOnly     bool
}

type imp struct {
	alias   string
	path    string
	doc     []string
	comment string
	group   string
	named   bool
}

func main() {
	log.SetFlags(log.LstdFlags)
	var o opts
	flag.BoolVar(&o.applyGenerated, "apply-to-generated-files", false, "Apply imports sorting and formatting(if the option is set) to generated files. Generated file is a file with first comment which starts with comment '// Code generated'. Optional parameter.")
	flag.StringVar(&o.companyPrefixes, "company-prefixes", "", "Company package prefixes which will be placed after 3rd-party group by default(if defined). Values should be comma-separated. Optional parameters.")
	flag.StringVar(&o.excludes, "excludes", "", "Exclude files or dirs, example: '.git/,proto/*.go'.")
	flag.StringVar(&o.filePath, "file-path", "", "Deprecated. Put file name as an argument(last item) of command line.")
	flag.BoolVar(&o.formatOnly, "format", false, "Option will perform additional formatting. Optional parameter.")
	flag.StringVar(&o.importsOrder, "imports-order", "std,general,company,project", "Your imports groups can be sorted in your way. \n\tstd - std import group; \n\tgeneral - libs for general purpose; \n\tcompany - inter-org or your company libs(if you set '-company-prefixes'-option, then 4th group will be split separately. In other case, it will be the part of general purpose libs); \n\tproject - your local project dependencies;\n\tblanked - imports with \"_\" alias;\n\tdotted - imports with \".\" alias.\n\tOptional parameter.")
	flag.BoolVar(&o.listDiff, "list-diff", false, "Option will list files whose formatting differs from goimports-reviser. Optional parameter.")
	flag.StringVar(&o.local, "local", "", "Deprecated")
	flag.StringVar(&o.output, "output", "file", "Can be \"file\", \"write\" or \"stdout\". Whether to write the formatted content back to the file or to stdout. When \"write\" together with \"-list-diff\" will list the file name and write back to the file. Optional parameter.")
	flag.StringVar(&o.projectName, "project-name", "", "Your project name(ex.: github.com/incu6us/goimports-reviser). Optional parameter.")
	flag.BoolVar(&o.recursive, "recursive", false, "Apply rules recursively if target is a directory. In case of ./... execution will be recursively applied by default. Optional parameter.")
	flag.BoolVar(&o.rmUnused, "rm-unused", false, "Remove unused imports. Optional parameter.")
	flag.BoolVar(&o.separateNamed, "separate-named", false, "Option will separate named imports from the rest of the imports, per group. Optional parameter.")
	flag.BoolVar(&o.setAlias, "set-alias", false, "Set alias for versioned package names, like 'github.com/go-pg/pg/v9'. In this case import will be set as 'pg \"github.com/go-pg/pg/v9\"'. Optional parameter.")
	flag.BoolVar(&o.setExitStatus, "set-exit-status", false, "set the exit status to 1 if a change is needed/made. Optional parameter.")
	flag.BoolVar(&o.useCache, "use-cache", false, "Use cache to improve performance. Optional parameter.")
	flag.BoolVar(&o.versionFlag, "version", false, "Show version information")
	flag.BoolVar(&o.versionOnly, "version-only", false, "Show only the version string")
	flag.Parse()

	if o.versionOnly {
		fmt.Println(version)
		return
	}
	if o.versionFlag {
		fmt.Printf("version: %s\nbuilt with: go1.26.0\ntag: v%s\ncommit: n/a\nsource: github.com/incu6us/goimports-reviser/v3\n", version, version)
		return
	}

	targets := append([]string{}, flag.Args()...)
	if o.filePath != "" {
		targets = append(targets, o.filePath)
	}
	if len(targets) == 0 {
		flag.Usage()
		log.Fatal("no file(s) or directory(ies) specified on input")
	}
	files, err := expandTargets(targets, o)
	if err != nil {
		log.Fatal(err)
	}
	log.Printf("Paths: %v", files)
	changed := false
	for _, p := range files {
		log.Printf("Processing %s", p)
		c, ch, err := processFile(p, o)
		if err != nil {
			log.Fatalf("Failed to fix file: %v", err)
		}
		if ch {
			changed = true
		}
		if o.output == "stdout" {
			os.Stdout.Write(c)
		}
		if o.listDiff && ch {
			fmt.Println(p)
		}
		if (o.output == "file" || o.output == "write") && (!o.listDiff || o.output == "write") {
			if ch {
				if err := os.WriteFile(p, c, 0644); err != nil {
					log.Fatal(err)
				}
			}
		}
	}
	if o.setExitStatus && changed {
		os.Exit(1)
	}
}

func expandTargets(targets []string, o opts) ([]string, error) {
	var out []string
	seen := map[string]bool{}
	for _, t := range targets {
		rec := o.recursive || strings.HasSuffix(t, "/...") || t == "./..."
		base := strings.TrimSuffix(t, "/...")
		if base == "." || base == "" {
			base = "."
		}
		info, err := os.Stat(base)
		if err != nil {
			return nil, err
		}
		if !info.IsDir() {
			if strings.HasSuffix(base, ".go") && !excluded(base, o.excludes) && !seen[base] {
				out = append(out, base)
				seen[base] = true
			}
			continue
		}
		if rec {
			err = filepath.WalkDir(base, func(path string, d fs.DirEntry, err error) error {
				if err != nil {
					return err
				}
				if d.IsDir() && excluded(path+string(os.PathSeparator), o.excludes) {
					return filepath.SkipDir
				}
				if !d.IsDir() && strings.HasSuffix(path, ".go") && !excluded(path, o.excludes) && !seen[path] {
					out = append(out, path)
					seen[path] = true
				}
				return nil
			})
			if err != nil {
				return nil, err
			}
		} else {
			ents, err := os.ReadDir(base)
			if err != nil {
				return nil, err
			}
			for _, e := range ents {
				p := filepath.Join(base, e.Name())
				if !e.IsDir() && strings.HasSuffix(p, ".go") && !excluded(p, o.excludes) && !seen[p] {
					out = append(out, p)
					seen[p] = true
				}
			}
		}
	}
	sort.Strings(out)
	return out, nil
}

func excluded(path, pats string) bool {
	if pats == "" {
		return false
	}
	path = filepath.ToSlash(path)
	for _, p := range strings.Split(pats, ",") {
		p = strings.TrimSpace(filepath.ToSlash(p))
		if p == "" {
			continue
		}
		if strings.HasSuffix(p, "/") && strings.Contains(path, p) {
			return true
		}
		if ok, _ := filepath.Match(p, path); ok {
			return true
		}
		if ok, _ := filepath.Match(p, filepath.Base(path)); ok {
			return true
		}
		if strings.HasPrefix(path, strings.TrimSuffix(p, "/")) {
			return true
		}
	}
	return false
}

func processFile(path string, o opts) ([]byte, bool, error) {
	src, err := os.ReadFile(path)
	if err != nil {
		return nil, false, err
	}
	if !o.applyGenerated && isGenerated(src) {
		return src, false, nil
	}
	project := o.projectName
	if project == "" {
		project = findModule(path)
	}
	fset := token.NewFileSet()
	file, err := parser.ParseFile(fset, path, src, parser.ParseComments)
	if err != nil {
		return nil, false, err
	}
	imports := collectImports(file, src, fset)
	if o.rmUnused {
		imports = filterUnused(imports, file)
	}
	for i := range imports {
		if o.setAlias && imports[i].alias == "" {
			imports[i].alias = versionAlias(imports[i].path)
		}
		imports[i].group, imports[i].named = classify(imports[i], project, o)
	}
	var out []byte
	if len(imports) == 0 {
		out, err = format.Source(src)
		if err != nil {
			out = src
			err = nil
		}
	} else {
		out, err = replaceImports(src, file, fset, imports, o)
		if err != nil {
			return nil, false, err
		}
	}
	return out, !bytes.Equal(src, out), nil
}

func isGenerated(src []byte) bool {
	for _, line := range strings.Split(string(src), "\n") {
		s := strings.TrimSpace(line)
		if s == "" {
			continue
		}
		return strings.HasPrefix(s, "// Code generated")
	}
	return false
}

func findModule(path string) string {
	dir := filepath.Dir(path)
	for {
		b, err := os.ReadFile(filepath.Join(dir, "go.mod"))
		if err == nil {
			for _, l := range strings.Split(string(b), "\n") {
				fs := strings.Fields(l)
				if len(fs) >= 2 && fs[0] == "module" {
					return fs[1]
				}
			}
		}
		nd := filepath.Dir(dir)
		if nd == dir {
			return ""
		}
		dir = nd
	}
}

func collectImports(file *ast.File, src []byte, fset *token.FileSet) []imp {
	var res []imp
	for _, d := range file.Decls {
		gd, ok := d.(*ast.GenDecl)
		if !ok || gd.Tok != token.IMPORT {
			continue
		}
		for _, s := range gd.Specs {
			is := s.(*ast.ImportSpec)
			p, _ := strconv.Unquote(is.Path.Value)
			it := imp{path: p}
			if is.Name != nil {
				it.alias = is.Name.Name
			}
			if is.Doc != nil {
				for _, c := range is.Doc.List {
					it.doc = append(it.doc, c.Text)
				}
			}
			if is.Comment != nil && len(is.Comment.List) > 0 {
				it.comment = is.Comment.List[0].Text
			}
			res = append(res, it)
		}
	}
	return res
}

func filterUnused(imports []imp, file *ast.File) []imp {
	used := map[string]bool{}
	ast.Inspect(file, func(n ast.Node) bool {
		switch x := n.(type) {
		case *ast.ImportSpec:
			return false
		case *ast.SelectorExpr:
			if id, ok := x.X.(*ast.Ident); ok {
				used[id.Name] = true
			}
		case *ast.Ident:
			used[x.Name] = true
		}
		return true
	})
	var out []imp
	for _, im := range imports {
		if im.alias == "_" || im.alias == "." {
			out = append(out, im)
			continue
		}
		name := im.alias
		if name == "" {
			name = defaultName(im.path)
		}
		if used[name] {
			out = append(out, im)
		}
	}
	return out
}

func defaultName(p string) string {
	parts := strings.Split(p, "/")
	last := parts[len(parts)-1]
	if regexp.MustCompile(`^v[0-9]+$`).MatchString(last) && len(parts) > 1 {
		last = parts[len(parts)-2]
	}
	return sanitizeIdent(last)
}

func versionAlias(p string) string {
	parts := strings.Split(p, "/")
	if len(parts) < 2 {
		return ""
	}
	last := parts[len(parts)-1]
	if regexp.MustCompile(`^v[2-9][0-9]*$`).MatchString(last) {
		return sanitizeIdent(parts[len(parts)-2])
	}
	return ""
}

func sanitizeIdent(s string) string {
	var b strings.Builder
	for i, r := range s {
		if (r >= 'A' && r <= 'Z') || (r >= 'a' && r <= 'z') || r == '_' || (i > 0 && r >= '0' && r <= '9') {
			b.WriteRune(r)
		}
	}
	if b.Len() == 0 {
		return s
	}
	return b.String()
}

func classify(im imp, project string, o opts) (string, bool) {
	orderHas := func(g string) bool {
		for _, x := range strings.Split(o.importsOrder, ",") {
			if strings.TrimSpace(x) == g {
				return true
			}
		}
		return false
	}
	if im.alias == "_" && orderHas("blanked") {
		return "blanked", false
	}
	if im.alias == "." && orderHas("dotted") {
		return "dotted", false
	}
	named := im.alias != "" && im.alias != "_" && im.alias != "." && o.separateNamed
	if project != "" && (im.path == project || strings.HasPrefix(im.path, project+"/")) {
		return "project", named
	}
	for _, p := range strings.Split(o.companyPrefixes, ",") {
		p = strings.TrimSpace(p)
		if p != "" && (im.path == p || strings.HasPrefix(im.path, p)) {
			return "company", named
		}
	}
	first := strings.Split(im.path, "/")[0]
	if !strings.Contains(first, ".") {
		return "std", named
	}
	return "general", named
}

func replaceImports(src []byte, file *ast.File, fset *token.FileSet, imports []imp, o opts) ([]byte, error) {
	type span struct{ start, end int }
	var spans []span
	for _, d := range file.Decls {
		if gd, ok := d.(*ast.GenDecl); ok && gd.Tok == token.IMPORT {
			spans = append(spans, span{fset.Position(gd.Pos()).Offset, fset.Position(gd.End()).Offset})
		}
	}
	if len(spans) == 0 {
		return format.Source(src)
	}
	sort.Slice(spans, func(i, j int) bool { return spans[i].start < spans[j].start })
	block := buildImportBlock(imports, o)
	var b bytes.Buffer
	b.Write(src[:spans[0].start])
	b.WriteString(block)
	last := spans[0].end
	for _, sp := range spans[1:] {
		b.Write(src[last:sp.start])
		last = sp.end
	}
	b.Write(src[last:])
	out, err := format.Source(b.Bytes())
	if err != nil {
		return b.Bytes(), nil
	}
	return out, nil
}

func buildImportBlock(imports []imp, o opts) string {
	groups := map[string][]imp{}
	for _, im := range imports {
		groups[im.group] = append(groups[im.group], im)
	}
	for g := range groups {
		sort.SliceStable(groups[g], func(i, j int) bool {
			a, b := groups[g][i], groups[g][j]
			if a.named != b.named {
				return !a.named
			}
			if a.named && b.named && a.alias != b.alias {
				return a.alias < b.alias
			}
			return a.path < b.path
		})
	}
	var all [][]imp
	for _, g := range strings.Split(o.importsOrder, ",") {
		g = strings.TrimSpace(g)
		list := groups[g]
		if len(list) == 0 {
			continue
		}
		if o.separateNamed && g != "blanked" && g != "dotted" {
			var plain, named []imp
			for _, im := range list {
				if im.named {
					named = append(named, im)
				} else {
					plain = append(plain, im)
				}
			}
			if len(plain) > 0 {
				all = append(all, plain)
			}
			if len(named) > 0 {
				all = append(all, named)
			}
		} else {
			all = append(all, list)
		}
		delete(groups, g)
	}
	var rest []string
	for g := range groups {
		rest = append(rest, g)
	}
	sort.Strings(rest)
	for _, g := range rest {
		if len(groups[g]) > 0 {
			all = append(all, groups[g])
		}
	}
	var lines []string
	for gi, gr := range all {
		if gi > 0 {
			lines = append(lines, "")
		}
		for _, im := range gr {
			lines = append(lines, importLines(im)...)
		}
	}
	if len(lines) == 1 {
		return "import " + strings.TrimSpace(lines[0]) + "\n"
	}
	return "import (\n\t" + strings.Join(lines, "\n\t") + "\n)\n"
}

func importLines(im imp) []string {
	var out []string
	for _, d := range im.doc {
		out = append(out, d)
	}
	line := ""
	if im.alias != "" {
		line += im.alias + " "
	}
	line += strconv.Quote(im.path)
	if im.comment != "" {
		line += " " + im.comment
	}
	out = append(out, line)
	return out
}
