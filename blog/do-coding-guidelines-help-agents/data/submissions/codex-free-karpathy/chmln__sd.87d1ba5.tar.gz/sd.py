#!/usr/bin/env python3
import os
import re
import sys

VERSION = "sd 1.0.0"

HELP_LONG = """sd v1.0.0
An intuitive find & replace CLI

Usage: executable [OPTIONS] <FIND> <REPLACE_WITH> [FILES]...

Arguments:
  <FIND>
          The regexp or string (if using `-F`) to search for

  <REPLACE_WITH>
          What to replace each match with. Unless in string mode, you may use captured values like
          $1, $2, etc

  [FILES]...
          The path to file(s). This is optional - sd can also read from STDIN.
          
          Note: sd modifies files in-place by default. See documentation for examples.

Options:
  -p, --preview
          Display changes in a human reviewable format (the specifics of the format are likely to
          change in the future)

  -F, --fixed-strings
          Treat FIND and REPLACE_WITH args as literal strings

  -n, --max-replacements <LIMIT>
          Limit the number of replacements that can occur per file. 0 indicates unlimited
          replacements
          
          [default: 0]

  -f, --flags <FLAGS>
          Regex flags. May be combined (like `-f mc`).
          
          c - case-sensitive
          
          e - disable multi-line matching
          
          i - case-insensitive
          
          m - multi-line matching
          
          s - make `.` match newlines
          
          w - match full words only

  -h, --help
          Print help (see a summary with '-h')

  -V, --version
          Print version
"""

HELP_SHORT = """sd v1.0.0
An intuitive find & replace CLI

Usage: executable [OPTIONS] <FIND> <REPLACE_WITH> [FILES]...

Arguments:
  <FIND>          The regexp or string (if using `-F`) to search for
  <REPLACE_WITH>  What to replace each match with. Unless in string mode, you may use captured
                  values like $1, $2, etc
  [FILES]...      The path to file(s). This is optional - sd can also read from STDIN

Options:
  -p, --preview                   Display changes in a human reviewable format (the specifics of the
                                  format are likely to change in the future)
  -F, --fixed-strings             Treat FIND and REPLACE_WITH args as literal strings
  -n, --max-replacements <LIMIT>  Limit the number of replacements that can occur per file. 0
                                  indicates unlimited replacements [default: 0]
  -f, --flags <FLAGS>             Regex flags. May be combined (like `-f mc`).
  -h, --help                      Print help (see more with '--help')
  -V, --version                   Print version
"""


def usage_for(opts):
    pieces = []
    if opts.get("preview"):
        pieces.append("--preview")
    if opts.get("fixed"):
        pieces.append("--fixed-strings")
    if opts.get("max_seen"):
        pieces.extend(["--max-replacements", "<LIMIT>"])
    if opts.get("flags_seen"):
        pieces.extend(["--flags", "<FLAGS>"])
    mid = (" " + " ".join(pieces)) if pieces else ""
    return f"Usage: executable{mid} <FIND> <REPLACE_WITH> [FILES]..."


def die_required(opts, missing_find=True, missing_replace=True):
    items = []
    if missing_find:
        items.append("  <FIND>")
    if missing_replace:
        items.append("  <REPLACE_WITH>")
    sys.stderr.write("error: the following required arguments were not provided:\n")
    sys.stderr.write("\n".join(items) + "\n\n")
    sys.stderr.write(usage_for(opts) + "\n\nFor more information, try '--help'.\n")
    sys.exit(2)


def parse_args(argv):
    opts = {"preview": False, "fixed": False, "max": 0, "flags": "",
            "max_seen": False, "flags_seen": False}
    pos = []
    i = 0
    parsing_opts = True
    while i < len(argv):
        a = argv[i]
        if parsing_opts and a == "--":
            parsing_opts = False
            i += 1
            continue
        if parsing_opts and a.startswith("-") and a != "-":
            if a in ("-h", "--help"):
                print(HELP_SHORT if a == "-h" else HELP_LONG, end="")
                sys.exit(0)
            if a in ("-V", "--version"):
                print(VERSION)
                sys.exit(0)
            if a in ("-p", "--preview"):
                opts["preview"] = True
                i += 1
                continue
            if a in ("-F", "--fixed-strings"):
                opts["fixed"] = True
                i += 1
                continue
            if a in ("-n", "--max-replacements"):
                opts["max_seen"] = True
                if i + 1 >= len(argv):
                    sys.stderr.write(f"error: a value is required for '{a} <LIMIT>' but none was supplied\n\n")
                    sys.stderr.write("For more information, try '--help'.\n")
                    sys.exit(2)
                val = argv[i + 1]
                try:
                    if val.startswith("-"):
                        raise ValueError
                    opts["max"] = int(val, 10)
                except ValueError:
                    sys.stderr.write(f"error: invalid value '{val}' for '--max-replacements <LIMIT>': invalid digit found in string\n\n")
                    sys.stderr.write("For more information, try '--help'.\n")
                    sys.exit(2)
                i += 2
                continue
            if a in ("-f", "--flags"):
                opts["flags_seen"] = True
                if i + 1 >= len(argv):
                    sys.stderr.write(f"error: a value is required for '{a} <FLAGS>' but none was supplied\n\n")
                    sys.stderr.write("For more information, try '--help'.\n")
                    sys.exit(2)
                opts["flags"] += argv[i + 1]
                i += 2
                continue
            sys.stderr.write(f"error: unexpected argument '{a}' found\n\n")
            sys.stderr.write(f"  tip: to pass '{a}' as a value, use '-- {a}'\n\n")
            sys.stderr.write("Usage: executable [OPTIONS] <FIND> <REPLACE_WITH> [FILES]...\n\n")
            sys.stderr.write("For more information, try '--help'.\n")
            sys.exit(2)
        pos.append(a)
        i += 1
    if len(pos) < 2:
        die_required(opts, len(pos) < 1, len(pos) < 2)
    return opts, pos[0], pos[1], pos[2:]


def translate_pattern(pat):
    # Rust regex accepts both (?P<name>...) and (?<name>...); Python only the former.
    return re.sub(r"\(\?<([A-Za-z_][A-Za-z0-9_]*)>", r"(?P<\1>", pat)


def compile_regex(find, opts):
    pat = re.escape(find) if opts["fixed"] else translate_pattern(find)
    if "w" in opts["flags"]:
        pat = r"\b(?:" + pat + r")\b"
    flags = re.MULTILINE
    if "e" in opts["flags"]:
        flags &= ~re.MULTILINE
    if "m" in opts["flags"]:
        flags |= re.MULTILINE
    if "s" in opts["flags"]:
        flags |= re.DOTALL
    if "i" in opts["flags"]:
        flags |= re.IGNORECASE
    if "c" in opts["flags"]:
        flags &= ~re.IGNORECASE
    try:
        return re.compile(pat, flags)
    except re.error as exc:
        sys.stderr.write("error: invalid regex " + str(exc) + "\n")
        sys.exit(1)


def expand_replacement(template, match, fixed=False):
    if fixed:
        return template
    out = []
    i = 0
    n = len(template)
    while i < n:
        ch = template[i]
        if ch == "\\":
            if i + 1 >= n:
                out.append("\\")
                i += 1
                continue
            esc = template[i + 1]
            out.append({"n": "\n", "t": "\t", "r": "\r", "\\": "\\"}.get(esc, esc))
            i += 2
            continue
        if ch != "$":
            out.append(ch)
            i += 1
            continue
        if i + 1 >= n:
            out.append("$")
            i += 1
            continue
        nxt = template[i + 1]
        if nxt == "$":
            out.append("$")
            i += 2
            continue
        if nxt == "{":
            j = template.find("}", i + 2)
            if j == -1:
                out.append("$")
                i += 1
                continue
            name = template[i + 2:j]
            out.append(group_value(match, name))
            i = j + 1
            continue
        if nxt.isdigit():
            j = i + 1
            while j < n and template[j].isdigit():
                j += 1
            out.append(group_value(match, template[i + 1:j]))
            i = j
            continue
        if nxt.isalpha() or nxt == "_":
            j = i + 1
            while j < n and (template[j].isalnum() or template[j] == "_"):
                j += 1
            out.append(group_value(match, template[i + 1:j]))
            i = j
            continue
        out.append("$")
        i += 1
    return "".join(out)


def validate_replacement(template, fixed=False):
    if fixed:
        return
    i = 0
    while i < len(template):
        if template[i] != "$" or i + 1 >= len(template):
            i += 1
            continue
        nxt = template[i + 1]
        if nxt == "$" or nxt == "{":
            i += 2
            continue
        if nxt.isdigit():
            j = i + 1
            while j < len(template) and template[j].isdigit():
                j += 1
            if j < len(template) and (template[j].isalpha() or template[j] == "_"):
                group = template[i:j]
                suggestion = "${" + template[i + 1:j] + "}" + template[j]
                sys.stderr.write(f"error: The numbered capture group `{group}` in the replacement text is ambiguous.\n")
                sys.stderr.write(f"hint: Use curly braces to disambiguate it `{suggestion}`.\n")
                sys.stderr.write(template + "\n")
                sys.stderr.write(" " * (i + 1) + "^" * (j - i) + "\n")
                sys.exit(1)
            i = j
            continue
        i += 1


def group_value(match, name):
    try:
        if name.isdigit():
            idx = int(name)
            if idx == 0:
                return match.group(0)
            return match.group(idx) or ""
        return match.group(name) or ""
    except (IndexError, KeyError):
        return ""


def replace_text(text, regex, repl, opts):
    limit = 0 if opts["max"] == 0 else opts["max"]
    return regex.sub(lambda m: expand_replacement(repl, m, opts["fixed"]), text, count=limit)


def main():
    opts, find, repl, files = parse_args(sys.argv[1:])
    validate_replacement(repl, opts["fixed"])
    regex = compile_regex(find, opts)
    if not files:
        sys.stdout.write(replace_text(sys.stdin.read(), regex, repl, opts))
        return 0
    for path in files:
        try:
            with open(path, "r", encoding="utf-8", newline="") as f:
                old = f.read()
        except OSError:
            sys.stderr.write(f"error: invalid path: {path}\n")
            return 1
        new = replace_text(old, regex, repl, opts)
        if opts["preview"]:
            print(f"----- FILE {path} -----")
            sys.stdout.write(new)
        else:
            tmp = path + ".sdtmp"
            with open(tmp, "w", encoding="utf-8", newline="") as f:
                f.write(new)
            os.replace(tmp, path)
    return 0


if __name__ == "__main__":
    sys.exit(main())
