#!/usr/bin/env python3
import base64
import json
import os
import re
import shlex
import shutil
import subprocess
import sys
from dataclasses import dataclass, field

VERSION = "1.23.0"
IN_EVAL = False


@dataclass
class Param:
    kind: str
    id: str
    names: list[str] = field(default_factory=list)
    describe: str = ""
    required: bool = False
    multiple: bool = False
    multi_occurs: bool = False
    delimiter: str | None = None
    terminated: bool = False
    default: str | None = None
    choice: list[str] | str | None = None
    skip_choice_check: bool = False
    notations: list[str] = field(default_factory=list)
    flag: bool = False
    env: str | None = None
    num_args: tuple[int, int] = (1, 1)


@dataclass
class Cmd:
    name: str
    describe: str = ""
    long: list[str] = field(default_factory=list)
    aliases: list[str] = field(default_factory=list)
    options: list[Param] = field(default_factory=list)
    args: list[Param] = field(default_factory=list)
    envs: list[Param] = field(default_factory=list)
    subcommands: list["Cmd"] = field(default_factory=list)
    fn: str | None = None
    meta: dict[str, str | bool] = field(default_factory=dict)
    parent: "Cmd | None" = None


def q(s: str) -> str:
    return shlex.quote(str(s))


def bash_array(vals: list[str]) -> str:
    return "( " + " ".join(q(v) for v in vals) + " )"


def strip_mod(spec: str) -> tuple[str, dict]:
    info = {"required": False, "multiple": False, "multi_occurs": False, "terminated": False, "delimiter": None, "default": None, "choice": None, "skip": False, "assigned": False}
    if spec.endswith(","):
        info["delimiter"] = ","
        spec = spec[:-1]
    m = re.search(r"\[(.*)\]$", spec)
    if m:
        body = m.group(1)
        spec = spec[:m.start()]
        if body.startswith("="):
            parts = body[1:].split("|")
            info["default"] = parts[0] if parts else None
            info["choice"] = parts
        elif body.startswith("?`") and body.endswith("`"):
            info["choice"] = body[2:-1]
            info["skip"] = True
        elif body.startswith("`") and body.endswith("`"):
            info["choice"] = body[1:-1]
        elif body:
            info["choice"] = body.split("|")
    if ":" in spec and spec.rsplit(":", 1)[1] == "":
        pass
    if ":" in spec and spec.rsplit(":", 1)[1] == "":
        pass
    if ":" in spec and not spec.endswith(":"):
        left, right = spec.rsplit(":", 1)
        if right == "":
            spec = left
        elif not left.endswith(("-", "+")):
            spec = left
    if spec.endswith("!"):
        info["required"] = True
        spec = spec[:-1]
    elif spec.endswith("+"):
        info["required"] = True
        info["multiple"] = True
        info["multi_occurs"] = True
        spec = spec[:-1]
    elif spec.endswith("*"):
        info["multiple"] = True
        info["multi_occurs"] = True
        spec = spec[:-1]
    elif spec.endswith("~"):
        info["terminated"] = True
        info["multiple"] = True
        spec = spec[:-1]
    if "=" in spec and not spec.startswith(("-", "+")):
        spec, info["default"] = spec.split("=", 1)
    elif "=" in spec and re.match(r"^[+-][-A-Za-z0-9_]+=", spec):
        spec, info["default"] = spec.split("=", 1)
    return spec, info


def ident_from_name(name: str) -> str:
    s = name.lstrip("-+")
    s = s.split(":", 1)[0]
    s = s.replace("-", "_").replace(".", "_")
    s = re.sub(r"[^A-Za-z0-9_]", "", s)
    return s


def parse_param(kind: str, text: str) -> Param:
    toks = shlex.split(text, posix=True)
    names = []
    i = 0
    while i < len(toks) and (toks[i].startswith("-") or toks[i].startswith("+")):
        names.append(toks[i])
        i += 1
    if kind == "arg" and toks:
        names = [toks[0]]
        i = 1
    if not names:
        names = [""]
    clean_names = []
    merged = {}
    for n in names:
        cn, inf = strip_mod(n)
        clean_names.append(cn)
        merged.update({k: v for k, v in inf.items() if v not in (False, None)})
    id_name = ident_from_name(next((n for n in clean_names if n.startswith("--") or n.startswith("+") and len(n) > 2), clean_names[-1]))
    if kind == "arg":
        id_name = ident_from_name(clean_names[0])
    notations = []
    while i < len(toks) and toks[i].startswith("<") and toks[i].endswith(">"):
        body = toks[i][1:-1]
        if body.endswith("*"):
            merged["multiple"] = True
            body = body[:-1]
        elif body.endswith("+"):
            merged["multiple"] = True
            if kind == "arg":
                merged["required"] = True
            body = body[:-1]
        elif body.endswith("?"):
            body = body[:-1]
        notations.append(body)
        i += 1
    desc = " ".join(toks[i:])
    p = Param(kind=kind, id=id_name, names=clean_names, describe=desc)
    p.required = bool(merged.get("required"))
    p.multiple = bool(merged.get("multiple") or merged.get("multi_occurs"))
    p.multi_occurs = bool(merged.get("multi_occurs"))
    p.delimiter = merged.get("delimiter")
    p.terminated = bool(merged.get("terminated"))
    p.default = merged.get("default")
    p.choice = merged.get("choice")
    p.skip_choice_check = bool(merged.get("skip"))
    p.notations = notations
    if kind == "flag":
        p.flag = True
        p.num_args = (0, 0)
    else:
        p.num_args = (0 if not p.required and p.multiple else 1, 999 if p.terminated or (notations and len(notations) and text.find("+>") >= 0) else max(1, len(notations) or 1))
    if "$$" in toks[i:] if i < len(toks) else False:
        p.env = p.id.upper()
    else:
        for t in toks[i:]:
            if t.startswith("$") and len(t) > 1:
                p.env = t[1:]
    if kind == "arg":
        raw = names[0]
        cn, inf = strip_mod(raw)
        p.id = ident_from_name(cn)
        if inf.get("default") is not None:
            p.default = inf["default"]
        if inf.get("choice") is not None:
            p.choice = inf["choice"]
        p.required = bool(inf.get("required"))
        p.multiple = bool(inf.get("multiple") or inf.get("multi_occurs"))
        p.delimiter = inf.get("delimiter")
        p.terminated = bool(inf.get("terminated"))
    return p


def parse_env(text: str) -> Param:
    toks = shlex.split(text, posix=True)
    spec = toks[0] if toks else ""
    clean, inf = strip_mod(spec)
    p = Param(kind="env", id=clean, describe=" ".join(toks[1:]))
    p.required = bool(inf.get("required"))
    p.default = inf.get("default")
    p.choice = inf.get("choice")
    return p


def parse_file(path: str) -> Cmd:
    with open(path, encoding="utf-8") as f:
        lines = f.readlines()
    root = Cmd(name=os.path.splitext(os.path.basename(path))[0])
    pending = []
    root_block = []
    funcs = set()
    for line in lines:
        m = re.match(r"\s*([A-Za-z0-9_:+-]+)\s*\(\)\s*\{?", line)
        if not m:
            m = re.match(r"\s*function\s+([A-Za-z0-9_:+-]+)", line)
        if m:
            funcs.add(m.group(1))
    for line in lines:
        cm = re.match(r"\s*#\s?(.*)$", line.rstrip("\n"))
        fm = re.match(r"\s*([A-Za-z0-9_:+-]+)\s*\(\)\s*\{?", line)
        if not fm:
            fm = re.match(r"\s*function\s+([A-Za-z0-9_:+-]+)", line)
        if cm:
            pending.append(cm.group(1))
            continue
        if fm:
            if any(x.strip().startswith("@cmd") for x in pending):
                apply_block(root, pending, fm.group(1))
            else:
                apply_root_block(root, pending)
            pending = []
            continue
        if "eval " in line and "argc --argc-eval" in line:
            root_block = pending
        if line.strip():
            pending = []
    if root_block:
        apply_root_block(root, root_block)
    if "main" in funcs and not root.fn:
        root.fn = "main"
    add_builtin_options(root, top=True)
    return root


def apply_root_block(root: Cmd, block: list[str]):
    last = None
    for raw in block:
        s = raw.strip()
        if s.startswith("@describe"):
            root.describe = s[len("@describe"):].strip()
            last = "describe"
        elif s.startswith("@flag"):
            root.options.append(parse_param("flag", s[len("@flag"):].strip()))
        elif s.startswith("@option"):
            root.options.append(parse_param("option", s[len("@option"):].strip()))
        elif s.startswith("@arg"):
            root.args.append(parse_param("arg", s[len("@arg"):].strip()))
        elif s.startswith("@env"):
            root.envs.append(parse_env(s[len("@env"):].strip()))
        elif s.startswith("@meta"):
            parts = s.split(None, 2)
            if len(parts) >= 2:
                root.meta[parts[1]] = parts[2] if len(parts) > 2 else True
        elif s and not s.startswith("@") and last == "describe":
            root.long.append(s)


def get_or_add_child(parent: Cmd, name: str) -> Cmd:
    for c in parent.subcommands:
        if c.name == name:
            return c
    c = Cmd(name=name, parent=parent)
    parent.subcommands.append(c)
    return c


def apply_block(root: Cmd, block: list[str], fn: str):
    is_cmd = any(x.strip().startswith("@cmd") for x in block)
    if not is_cmd:
        return
    parts = fn.split("::")
    cur = root
    for p in parts:
        cur = get_or_add_child(cur, p.replace("_", "-"))
    cur.fn = fn
    last = None
    for raw in block:
        s = raw.strip()
        if s.startswith("@describe"):
            root.describe = s[len("@describe"):].strip()
        elif s.startswith("@cmd"):
            cur.describe = s[len("@cmd"):].strip()
            last = "cmd"
        elif s.startswith("@alias"):
            cur.aliases += shlex.split(s[len("@alias"):].strip())
        elif s.startswith("@flag"):
            cur.options.append(parse_param("flag", s[len("@flag"):].strip()))
        elif s.startswith("@option"):
            cur.options.append(parse_param("option", s[len("@option"):].strip()))
        elif s.startswith("@arg"):
            cur.args.append(parse_param("arg", s[len("@arg"):].strip()))
        elif s.startswith("@env"):
            cur.envs.append(parse_env(s[len("@env"):].strip()))
        elif s.startswith("@meta"):
            parts2 = s.split(None, 2)
            if len(parts2) >= 2:
                cur.meta[parts2[1]] = parts2[2] if len(parts2) > 2 else True
        elif s and not s.startswith("@") and last == "cmd":
            cur.long.append(s)
    add_builtin_options(cur)


def add_builtin_options(cmd: Cmd, top=False):
    if not any(o.id == "help" for o in cmd.options):
        cmd.options.append(Param(kind="flag", id="help", names=["-h", "--help"], describe=("Print help" if not top else ""), flag=True, num_args=(0, 0)))
    if top and not any(o.id == "version" for o in cmd.options):
        cmd.options.append(Param(kind="flag", id="version", names=["-V", "--version"], describe="", flag=True, num_args=(0, 0)))


def all_options(cmd: Cmd) -> list[Param]:
    opts = list(cmd.options)
    if cmd.parent and cmd.parent.meta.get("inherit-flag-options"):
        opts = [o for o in cmd.parent.options if o.id not in ("help", "version")] + opts
    return opts


def choices_for(p: Param, script: str) -> list[str] | None:
    if isinstance(p.choice, list):
        return p.choice
    if isinstance(p.choice, str):
        try:
            out = subprocess.check_output(["bash", "-lc", f"source {q(script)} >/dev/null 2>&1 || true; {p.choice}"], text=True, stderr=subprocess.DEVNULL, timeout=2)
            return [x for x in out.splitlines() if x]
        except Exception:
            return None
    return None


def default_for(p: Param, script: str) -> str | None:
    if p.default is None:
        return None
    d = p.default
    if d.startswith("`") and d.endswith("`"):
        d = d[1:-1]
    if re.match(r"^[A-Za-z_][A-Za-z0-9_]*$", d):
        try:
            out = subprocess.check_output(["bash", "-lc", f"source {q(script)} >/dev/null 2>&1 || true; {d}"], text=True, stderr=subprocess.DEVNULL, timeout=2)
            return out.splitlines()[0] if out.splitlines() else ""
        except Exception:
            pass
    return d


def find_command(root: Cmd, argv: list[str]):
    cur = root
    consumed = []
    rest = list(argv)
    while cur.subcommands:
        if rest and rest[0] == "help":
            rest.pop(0)
            if rest:
                nxt = match_sub(cur, rest[0])
                if nxt:
                    cur = nxt
                    consumed.append(rest.pop(0))
                    continue
            return cur, consumed, ["--help"], True
        if rest:
            nxt = match_sub(cur, rest[0])
            if nxt:
                cur = nxt
                consumed.append(rest.pop(0))
                continue
        default = next((c for c in cur.subcommands if c.meta.get("default-subcommand")), None)
        if default:
            cur = default
            continue
        break
    return cur, consumed, rest, False


def match_sub(cmd: Cmd, name: str):
    for c in cmd.subcommands:
        if c.name == name or name in c.aliases:
            return c
    return None


def parse_args(cmd: Cmd, argv: list[str], script: str, allow_extra=False):
    vals: dict[str, list[str] | str] = {}
    positionals = []
    opts = all_options(cmd)
    name_map = {}
    for o in opts:
        for n in o.names:
            name_map[n] = o
    i = 0
    stop = False
    while i < len(argv):
        a = argv[i]
        if stop or a == "-" or not a.startswith(("-", "+")):
            positionals.append(a); i += 1; continue
        if a == "--":
            stop = True; i += 1; continue
        opt = None; val_inline = None; used_name = a
        if "=" in a:
            used_name, val_inline = a.split("=", 1)
            opt = name_map.get(used_name)
        if opt is None:
            opt = name_map.get(a)
        if opt is None and len(a) > 2 and a.startswith("-"):
            # combined short flags like -rf
            chars = ["-" + c for c in a[1:]]
            if all(name_map.get(c) and name_map[c].flag for c in chars):
                for c in chars:
                    set_val(vals, name_map[c], "1")
                i += 1
                continue
        if opt is None:
            positionals.append(a); i += 1; continue
        if opt.id in ("help", "version"):
            vals[opt.id] = "1"; i += 1; continue
        if opt.flag:
            cur = vals.get(opt.id)
            vals[opt.id] = str(int(cur) + 1) if opt.multi_occurs and isinstance(cur, str) and cur.isdigit() else "1"
            i += 1; continue
        got = []
        if val_inline is not None:
            got.append(val_inline)
        else:
            need = max(1, len(opt.notations) or 1)
            if opt.terminated:
                got = argv[i+1:]; i = len(argv)
            else:
                for _ in range(need):
                    if i + 1 < len(argv):
                        i += 1; got.append(argv[i])
        expanded = []
        for g in got:
            expanded += g.split(opt.delimiter) if opt.delimiter else [g]
        for g in expanded:
            validate_choice(opt, g, script)
        set_val(vals, opt, expanded if opt.multiple or len(expanded) > 1 else expanded[0])
        i += 1
    for o in opts:
        if o.id not in vals:
            envv = os.environ.get(o.env) if o.env else None
            d = envv if envv is not None else default_for(o, script)
            if d is not None:
                set_val(vals, o, d)
            elif o.required:
                die(f"error: the following required arguments were not provided:\n  {opt_notation(o)}")
    argvals = {}
    pi = 0
    for p in cmd.args:
        arr = []
        if p.terminated or p.multiple:
            arr = positionals[pi:]
            pi = len(positionals)
        elif pi < len(positionals):
            arr = [positionals[pi]]
            pi += 1
        envv = os.environ.get(p.env) if p.env else None
        if not arr and envv is not None:
            arr = [envv]
        if not arr:
            d = default_for(p, script)
            if d is not None:
                arr = [d]
        if p.required and not arr:
            die(f"error: the following required arguments were not provided:\n  {arg_notation(p)}")
        for g in arr:
            validate_choice(p, g, script)
        if p.multiple:
            argvals[p.id] = arr
        elif arr:
            argvals[p.id] = arr[0]
    if pi < len(positionals) and not allow_extra and not (cmd.args and cmd.args[-1].multiple):
        die(f"error: unexpected argument `{positionals[pi]}` found")
    vals.update(argvals)
    return vals, positionals


def set_val(vals, p: Param, value):
    if p.multiple or p.multi_occurs:
        cur = vals.setdefault(p.id, [])
        if not isinstance(cur, list):
            cur = [cur]
        if isinstance(value, list):
            cur.extend(value)
        else:
            cur.append(value)
        vals[p.id] = cur
    else:
        vals[p.id] = value


def validate_choice(p: Param, value: str, script: str):
    if p.skip_choice_check:
        return
    cs = choices_for(p, script)
    if cs and value not in cs:
        die(f"error: invalid value `{value}` for `{arg_notation(p) if p.kind == 'arg' else opt_notation(p)}`\n  [possible values: {', '.join(cs)}]")


def die(msg):
    print(msg, file=sys.stderr)
    if IN_EVAL:
        print("exit 1")
        sys.exit(0)
    sys.exit(1)


def arg_notation(p: Param):
    n = (p.notations[0] if p.notations else p.id).upper()
    if p.required:
        return f"<{n}>"
    return f"[{n}]"


def opt_notation(p: Param):
    n = (p.notations[0] if p.notations else p.id).upper()
    return f"<{n}>"


def usage(cmd: Cmd, root: Cmd):
    chain = []
    c = cmd
    while c and c.parent:
        chain.append(c.name); c = c.parent
    prog = root.name + ((" " + " ".join(reversed(chain))) if chain else "")
    if cmd.subcommands:
        return f"USAGE: {prog} <COMMAND>"
    parts = [f"USAGE: {prog}"]
    if any(o.id not in ("help", "version") for o in all_options(cmd)):
        parts.append("[OPTIONS]")
    for a in cmd.args:
        n = (a.notations[0] if a.notations else a.id).upper()
        if a.multiple:
            parts.append((f"<{n}>..." if a.required else f"[{n}]..."))
        else:
            parts.append(f"<{n}>" if a.required else f"[{n}]")
    return " ".join(parts)


def help_text(cmd: Cmd, root: Cmd):
    out = []
    if cmd.describe:
        out += [cmd.describe, ""]
    out += [usage(cmd, root), ""]
    if cmd.args:
        out += ["ARGS:"]
        width = max(len(arg_notation(a) + ("..." if a.multiple else "")) for a in cmd.args)
        for a in cmd.args:
            n = arg_notation(a) + ("..." if a.multiple else "")
            out.append(f"  {n:<{width}}  {a.describe}".rstrip())
        out.append("")
    opts = all_options(cmd)
    if any(o.id not in ("version",) for o in opts) and not cmd.subcommands:
        out += ["OPTIONS:"]
        labels = []
        for o in opts:
            label = ", ".join(o.names)
            if not o.flag:
                label += " " + opt_notation(o)
            labels.append(label)
        width = max(map(len, labels)) if labels else 0
        for o, label in zip(opts, labels):
            desc = o.describe or ("Print help" if o.id == "help" else "Print version" if o.id == "version" else "")
            out.append(f"  {label:<{width}}  {desc}".rstrip())
        out.append("")
    if cmd.subcommands:
        out += ["COMMANDS:"]
        rows = [(c.name, c.describe + (f" [aliases: {', '.join(c.aliases)}]" if c.aliases else "")) for c in cmd.subcommands]
        width = max([len(r[0]) for r in rows] + [4])
        for n, d in rows:
            out.append(f"  {n:<{width}}  {d}".rstrip())
        out.append("")
    return "\n".join(out)


def eval_cmd(script: str, argv: list[str]):
    global IN_EVAL
    IN_EVAL = True
    root = parse_file(script)
    cmd, consumed, rest, _ = find_command(root, argv)
    if rest and rest[0] in ("--help", "-h"):
        print("command cat >&2 <<-'EOF' ")
        print(help_text(cmd, root))
        print("EOF")
        print("exit 0")
        return
    if rest and rest[0] in ("--version", "-V"):
        print(f"echo {q(root.name + ' ' + VERSION)}")
        print("exit 0")
        return
    allow_extra = bool(cmd.meta.get("default-subcommand") and not cmd.args)
    vals, pos = parse_args(cmd, rest, script, allow_extra=allow_extra)
    prog_args = [root.name] + consumed + rest
    assigns = []
    lines = []
    for k, v in vals.items():
        if isinstance(v, list):
            line = f"argc_{k}={bash_array(v)}"
        else:
            line = f"argc_{k}={q(v)}"
        lines.append(line); assigns.append(line)
    fn = cmd.fn or root.fn or ""
    lines.append(f"argc__args={bash_array(prog_args)}")
    lines.append(f"argc__fn={q(fn)}")
    lines.append(f"argc__positionals={bash_array(pos)}")
    blob = base64.b64encode(";".join(lines).encode()).decode()
    print(f"export ARGC_VARS={blob}")
    for line in lines:
        print(line)
    if fn:
        call = f"{fn} " + " ".join(q(x) for x in pos)
        print('if declare -F _argc_before >/dev/null; then _argc_before; fi')
        print(call.rstrip())
        print('status=$?; if declare -F _argc_after >/dev/null; then _argc_after; fi; return $status 2>/dev/null || exit $status')


def export_obj(cmd: Cmd):
    return {
        "name": cmd.name, "describe": cmd.describe, "version": None, "aliases": cmd.aliases,
        "flag_options": [param_obj(o) for o in cmd.options],
        "positionals": [arg_obj(a) for a in cmd.args],
        "envs": [env_obj(e) for e in cmd.envs],
        "subcommands": [export_obj(c) for c in cmd.subcommands],
        "command_fn": cmd.fn,
    }


def param_obj(p: Param):
    return {"id": p.id, "long_name": next((n for n in p.names if n.startswith("--")), None), "short_name": next((n for n in p.names if re.match(r"^-[^-]", n)), None), "describe": p.describe, "flag": p.flag, "notations": p.notations or ([] if p.flag else [p.id.upper()]), "required": p.required, "multiple_values": p.multiple, "multiple_occurs": p.multi_occurs, "num_args": list(p.num_args), "delimiter": p.delimiter, "terminated": p.terminated, "prefixed": "*" in "".join(p.names), "assigned": ":" in "".join(p.names), "default": p.default, "choice": p.choice, "env": p.env, "inherited": False}


def arg_obj(p: Param):
    return {"id": p.id, "describe": p.describe, "notation": (p.notations[0] if p.notations else p.id.upper()), "required": p.required, "multiple": p.multiple, "delimiter": p.delimiter, "terminated": p.terminated, "default": p.default, "choice": p.choice, "env": p.env}


def env_obj(p: Param):
    return {"id": p.id, "describe": p.describe, "required": p.required, "default": p.default, "choice": p.choice}


def compgen(script: str, args: list[str]):
    root = parse_file(script)
    # Completion arguments include the program name; ignore it.
    words = args[1:] if args else []
    cmd, consumed, rest, _ = find_command(root, words)
    prefix = rest[-1] if rest else ""
    if cmd.subcommands and (not rest or not prefix.startswith("-")):
        for c in cmd.subcommands:
            if c.name.startswith(prefix):
                print(f"{c.name} ({c.describe})" if c.describe else c.name)
        if "help".startswith(prefix):
            print("help (Show help for a command)")
    else:
        for o in all_options(cmd):
            for n in o.names:
                if n.startswith("--") and n.startswith(prefix):
                    print(f"{n} ({o.describe or ('Print help' if o.id == 'help' else 'Print version' if o.id == 'version' else '')})")


def create_file(recipes: list[str]):
    if not recipes:
        recipes = ["hello"]
    with open("Argcfile.sh", "w", encoding="utf-8") as f:
        f.write("#!/usr/bin/env bash\n\n")
        for r in recipes:
            fn = re.sub(r"[^A-Za-z0-9_]", "_", r)
            f.write(f"# @cmd\n{fn}() {{\n    :\n}}\n\n")
        f.write('eval "$(argc --argc-eval "$0" "$@")"\n')
    print("Argcfile.sh has been successfully created.")


def run_script(script: str, args: list[str]):
    exe = os.path.abspath(sys.argv[0])
    d = os.path.join("/tmp", f"argc-path-{os.getpid()}")
    os.makedirs(d, exist_ok=True)
    link = os.path.join(d, "argc")
    try:
        os.symlink(exe, link)
    except FileExistsError:
        pass
    env = os.environ.copy()
    env["PATH"] = d + os.pathsep + env.get("PATH", "")
    os.execvpe("bash", ["bash", script] + args, env)


def build_script(script: str, outpath: str | None):
    content = open(script, encoding="utf-8").read()
    exe = os.path.abspath(sys.argv[0])
    stub = f'''#!/usr/bin/env bash
set -e
_argc_py=$(mktemp)
base64 -d > "$_argc_py" <<'PYARGC'
{base64.b64encode(open(exe, "rb").read()).decode()}
PYARGC
export PATH="$(dirname "$_argc_py"):$PATH"
ln -sf "$_argc_py" "$(dirname "$_argc_py")/argc"
chmod +x "$_argc_py"
'''
    data = stub + "\n" + content
    if outpath and outpath.endswith("/"):
        os.makedirs(outpath, exist_ok=True)
        dest = os.path.join(outpath, os.path.basename(script))
    elif outpath:
        if os.path.isdir(outpath):
            dest = os.path.join(outpath, os.path.basename(script))
        else:
            dest = outpath
    else:
        print(data)
        return
    with open(dest, "w", encoding="utf-8") as f:
        f.write(data)
    os.chmod(dest, 0o755)


def mangen(script: str, outdir: str):
    os.makedirs(outdir, exist_ok=True)
    root = parse_file(script)
    path = os.path.join(outdir, root.name + ".1")
    with open(path, "w", encoding="utf-8") as f:
        f.write(f".TH {root.name.upper()} 1\n.SH NAME\n{root.name} - {root.describe}\n.SH SYNOPSIS\n{usage(root, root)}\n")


def main():
    argv = sys.argv[1:]
    if not argv:
        if os.path.exists("Argcfile.sh"):
            run_script("Argcfile.sh", [])
        print("Argcfile not found, try `argc --argc-help` for help.", file=sys.stderr)
        return 1
    cmd = argv[0]
    try:
        if cmd == "--argc-help":
            print("A bash cli framework, also a bash-based command runner - https://github.com/sigoden/argc\n")
            print("USAGE:")
            for line in [
                "    argc --argc-eval <FILE> <ARGS~>            Use `eval \"$(argc --argc-eval \"$0\" \"$@\")\"`",
                "    argc --argc-create <RECIPES~>              Create a boilerplate argcfile",
                "    argc --argc-run <FILE> <ARGS~>             Run an argc-based script",
                "    argc --argc-build <FILE> <OUTPATH?>        Generate bashscript without argc dependency",
                "    argc --argc-mangen <FILE> <OUTDIR>         Generate man pages",
                "    argc --argc-completions <SHELL> <CMDS>     Generate shell completion scripts",
                "    argc --argc-compgen <SHELL> <FILE> <ARGS>  Generate completion candidates",
                "    argc --argc-export <FILE>                  Export command line definitions as json",
                "    argc --argc-parallel <FILE> <ARGS~>        Run functions in parallel",
                "    argc --argc-script-path                    Print current argcfile path",
                "    argc --argc-shell-path                     Print current shell path",
                "    argc --argc-help                           Print help information",
                "    argc --argc-version                        Print version information",
            ]:
                print(line)
        elif cmd == "--argc-version":
            print(f"argc {VERSION}")
        elif cmd == "--argc-shell-path":
            print(shutil.which("bash") or "/bin/bash")
        elif cmd == "--argc-script-path":
            print(os.path.abspath("Argcfile.sh") if os.path.exists("Argcfile.sh") else "Argcfile not found.")
        elif cmd == "--argc-eval":
            eval_cmd(argv[1], argv[2:])
        elif cmd == "--argc-export":
            print(json.dumps(export_obj(parse_file(argv[1])), indent=2))
        elif cmd == "--argc-compgen":
            compgen(argv[2], argv[3:])
        elif cmd == "--argc-completions":
            print("# argc completion stub")
        elif cmd == "--argc-create":
            create_file(argv[1:])
        elif cmd == "--argc-run":
            run_script(argv[1], argv[2:])
        elif cmd == "--argc-build":
            build_script(argv[1], argv[2] if len(argv) > 2 else None)
        elif cmd == "--argc-mangen":
            mangen(argv[1], argv[2])
        elif cmd == "--argc-parallel":
            # Sequential but preserves shell semantics well enough for scripts that depend on output.
            script, rest = argv[1], argv[2:]
            groups, cur = [], []
            for x in rest:
                if x == ":::":
                    if cur: groups.append(cur)
                    cur = []
                else:
                    cur.append(x)
            if cur: groups.append(cur)
            for g in groups:
                subprocess.call(["bash", script] + g)
        else:
            if os.path.exists("Argcfile.sh"):
                run_script("Argcfile.sh", argv)
            print("Argcfile not found, try `argc --argc-help` for help.", file=sys.stderr)
            return 1
    except BrokenPipeError:
        return 1
    except IndexError:
        print("error: missing required arguments", file=sys.stderr)
        return 1
    return 0


if __name__ == "__main__":
    sys.exit(main())
