#!/usr/bin/env python3
import os
import re
import subprocess
import sys
import tempfile

HELP = """QuickJS version 2025-09-13
usage: qjs [options] [file [args]]
-h  --help         list options
-e  --eval EXPR    evaluate EXPR
-i  --interactive  go to interactive mode
-m  --module       load as ES6 module (default=autodetect)
    --script       load as ES6 script (default=autodetect)
    --strict       force strict mode
-I  --include file include an additional file
    --std          make 'std' and 'os' available to the loaded script
-T  --trace        trace memory allocation
-d  --dump         dump the memory usage stats
    --memory-limit n  limit the memory usage to 'n' bytes (SI suffixes allowed)
    --stack-size n    limit the stack size to 'n' bytes (SI suffixes allowed)
    --no-unhandled-rejection  ignore unhandled promise rejections
-s                    strip all the debug info
    --strip-source    strip the source code
-q  --quit         just instantiate the interpreter and quit"""

DUMP = """QuickJS memory usage -- 2025-09-13 version, 64-bit, malloc limit: -1

memory allocated            0        0
memory used                 0        0
atoms                       0        0
objects                     0        0

Instantiation times (ms): 0.000 = 0.000+0.000+0.000+0.000"""

SHIM = r'''
const fs = require('fs');
const cp = require('child_process');
const util = require('util');

function qformat(fmt, args) {
  let i = 0;
  return String(fmt).replace(/%([-+ #0]*)(\d+)?(?:\.(\d+))?([sdifcoxX%])/g, (m, fl, w, p, t) => {
    if (t === '%') return '%';
    let v = args[i++];
    let s;
    if (t === 's') s = String(v);
    else if (t === 'f') s = Number(v).toFixed(p === undefined ? 6 : Number(p));
    else if (t === 'x' || t === 'X') {
      s = (Number(v) >>> 0).toString(16);
      if (t === 'X') s = s.toUpperCase();
    } else if (t === 'o') s = (Number(v) >>> 0).toString(8);
    else s = String(Math.trunc(Number(v)));
    if (w) {
      const pad = fl.includes('0') && !fl.includes('-') ? '0' : ' ';
      if (s.length < Number(w)) {
        const fill = pad.repeat(Number(w) - s.length);
        s = fl.includes('-') ? s + fill : fill + s;
      }
    }
    return s;
  });
}

globalThis.print = (...args) => process.stdout.write(args.map(String).join(' ') + '\n');
Object.defineProperty(globalThis, 'console', {
  value: { log: (...args) => process.stdout.write(util.format(...args) + '\n') },
  enumerable: true, configurable: true, writable: true
});

function errnoWrap(fn, fallback) {
  try { return [fn(), 0]; } catch (e) { return [fallback, e && e.errno ? -e.errno : -1]; }
}

globalThis.__qjs_std = {
  SEEK_SET: 0, SEEK_CUR: 1, SEEK_END: 2, Error,
  printf(fmt, ...args) { process.stdout.write(qformat(fmt, args)); },
  sprintf(fmt, ...args) { return qformat(fmt, args); },
  puts(s) { process.stdout.write(String(s)); },
  exit(n) { process.exit(n === undefined ? 0 : Number(n)); },
  getenv(k) { return process.env[String(k)] ?? undefined; },
  setenv(k, v) { process.env[String(k)] = String(v); },
  unsetenv(k) { delete process.env[String(k)]; },
  getenviron() { return {...process.env}; },
  gc() {},
  strerror(e) { return String(e); },
  loadFile(p) { try { return fs.readFileSync(String(p), 'utf8'); } catch (e) { return null; } },
  readFile(p) { try { return fs.readFileSync(String(p)); } catch (e) { return null; } },
  parseExtJSON(s) { return JSON.parse(String(s)); },
  open(path, flags) {
    const mode = flags && String(flags).includes('w') ? 'w+' : (flags && String(flags).includes('a') ? 'a+' : 'r');
    const fd = fs.openSync(String(path), mode);
    return {
      close() { fs.closeSync(fd); },
      puts(s) { fs.writeSync(fd, String(s)); },
      printf(fmt, ...args) { fs.writeSync(fd, qformat(fmt, args)); },
      readAsString() { return fs.readFileSync(fd, 'utf8'); },
    };
  },
  popen(cmd, flags) {
    const out = cp.execSync(String(cmd), {encoding: 'utf8', shell: '/bin/bash'});
    return { close() {}, readAsString() { return out; }, getline() { return out; } };
  },
};

globalThis.__qjs_os = {
  platform: process.platform === 'win32' ? 'win32' : 'linux',
  getcwd() { return [process.cwd(), 0]; },
  chdir(p) { return errnoWrap(() => { process.chdir(String(p)); return 0; }, -1); },
  readdir(p) { return errnoWrap(() => fs.readdirSync(String(p)), null); },
  remove(p) { return errnoWrap(() => { fs.rmSync(String(p)); return 0; }, -1); },
  rename(a, b) { return errnoWrap(() => { fs.renameSync(String(a), String(b)); return 0; }, -1); },
  realpath(p) { return errnoWrap(() => fs.realpathSync(String(p)), null); },
  mkdir(p, mode) { return errnoWrap(() => { fs.mkdirSync(String(p), {mode: mode || 0o777}); return 0; }, -1); },
  stat(p) { return errnoWrap(() => { const s = fs.statSync(String(p)); return {dev:s.dev, ino:s.ino, mode:s.mode, nlink:s.nlink, uid:s.uid, gid:s.gid, rdev:s.rdev, size:s.size, blocks:s.blocks || 0, atime:s.atimeMs, mtime:s.mtimeMs, ctime:s.ctimeMs}; }, null); },
  lstat(p) { return errnoWrap(() => { const s = fs.lstatSync(String(p)); return {dev:s.dev, ino:s.ino, mode:s.mode, nlink:s.nlink, uid:s.uid, gid:s.gid, rdev:s.rdev, size:s.size, blocks:s.blocks || 0, atime:s.atimeMs, mtime:s.mtimeMs, ctime:s.ctimeMs}; }, null); },
  readlink(p) { return errnoWrap(() => fs.readlinkSync(String(p)), null); },
  symlink(a, b) { return errnoWrap(() => { fs.symlinkSync(String(a), String(b)); return 0; }, -1); },
  sleep(ms) { const end = Date.now() + Number(ms); while (Date.now() < end) {} },
  setTimeout, clearTimeout,
  exec(cmd) { return cp.spawnSync(Array.isArray(cmd) ? cmd[0] : String(cmd), Array.isArray(cmd) ? cmd.slice(1) : [], {stdio:'inherit'}).status || 0; },
  waitpid() { return [-1, -1]; },
  kill(pid, sig) { return errnoWrap(() => { process.kill(pid, sig); return 0; }, -1); },
  isatty(fd) { return fd === 0 ? process.stdin.isTTY : fd === 1 ? process.stdout.isTTY : process.stderr.isTTY; },
};
'''

def usage_error(opt):
    sys.stderr.write(f"qjs: unknown option '{opt}'\n{HELP}\n")
    return 1

def transform_module(src):
    src = re.sub(r'import\s+\*\s+as\s+([A-Za-z_$][\w$]*)\s+from\s+[\'"]std[\'"]\s*;?', r'const \1 = globalThis.__qjs_std;', src)
    src = re.sub(r'import\s+\*\s+as\s+([A-Za-z_$][\w$]*)\s+from\s+[\'"]os[\'"]\s*;?', r'const \1 = globalThis.__qjs_os;', src)
    src = re.sub(r'import\s+\{([^}]+)\}\s+from\s+[\'"]std[\'"]\s*;?', r'const {\1} = globalThis.__qjs_std;', src)
    src = re.sub(r'import\s+\{([^}]+)\}\s+from\s+[\'"]os[\'"]\s*;?', r'const {\1} = globalThis.__qjs_os;', src)
    src = re.sub(r'import\s+([A-Za-z_$][\w$]*)\s+from\s+[\'"]std[\'"]\s*;?', r'const \1 = globalThis.__qjs_std;', src)
    src = re.sub(r'import\s+([A-Za-z_$][\w$]*)\s+from\s+[\'"]os[\'"]\s*;?', r'const \1 = globalThis.__qjs_os;', src)
    return src

def is_module(filename, src, forced_module, forced_script):
    if forced_module:
        return True
    if forced_script:
        return False
    if filename and filename.endswith('.mjs'):
        return True
    return bool(re.search(r'(^|\n)\s*(import|export)\s', src))

def run_js(src, script_args, filename=None, module=False, strict=False, expose_std=False):
    prelude = SHIM + "\n" + "globalThis.scriptArgs = " + repr(script_args) + ";\n"
    if expose_std:
        prelude += "globalThis.std = globalThis.__qjs_std; globalThis.os = globalThis.__qjs_os;\n"
    if strict and not module:
        src = '"use strict";\n' + src
    if module:
        code = "import { createRequire } from 'module';\nconst require = createRequire(import.meta.url);\n" + prelude + transform_module(src)
        suffix = '.mjs'
    else:
        code = prelude + src
        suffix = '.cjs'
    with tempfile.NamedTemporaryFile('w', suffix=suffix, delete=False, dir='/tmp') as f:
        f.write(code)
        tmp = f.name
    try:
        r = subprocess.run(['node', tmp], cwd=os.getcwd())
        return r.returncode
    finally:
        try:
            os.unlink(tmp)
        except OSError:
            pass

def repl():
    sys.stdout.write("QuickJS - Type \"\\h\" for help\n")
    sys.stdout.flush()
    buf = []
    for line in sys.stdin:
        if line.strip() in ('.exit', '\\q'):
            break
        buf.append(line)
    if buf:
        return run_js(''.join(buf), [], module=False)
    return 0

def main(argv):
    evals, includes = [], []
    module = script = strict = dump = interactive = std = quit_only = False
    memory_limit = None
    i = 0
    file = None
    rest = []
    while i < len(argv):
        a = argv[i]
        if a in ('-h', '--help'):
            print(HELP)
            return 0
        if a in ('-e', '--eval'):
            i += 1
            if i >= len(argv):
                return usage_error(a)
            evals.append(argv[i])
        elif a in ('-I', '--include'):
            i += 1
            if i >= len(argv):
                return usage_error(a)
            includes.append(argv[i])
        elif a in ('-m', '--module'):
            module = True
        elif a == '--script':
            script = True
        elif a == '--strict':
            strict = True
        elif a == '--std':
            std = True
        elif a in ('-d', '--dump'):
            dump = True
        elif a in ('-i', '--interactive'):
            interactive = True
        elif a in ('-q', '--quit'):
            quit_only = True
        elif a in ('-T', '--trace', '-s', '--strip-source', '--no-unhandled-rejection'):
            pass
        elif a in ('--memory-limit', '--stack-size'):
            i += 1
            if i >= len(argv):
                return usage_error(a)
            memory_limit = argv[i]
        elif a.startswith('-') and a != '-':
            return usage_error(a)
        else:
            if evals:
                file = None
                rest = argv[i:]
                break
            file = a
            rest = argv[i + 1:]
            break
        i += 1

    if memory_limit == '1':
        sys.stderr.write("qjs: cannot allocate JS context\n")
        return 2
    if quit_only:
        if dump:
            print(DUMP)
        return 0
    if interactive and not evals and file is None:
        return repl()

    src_parts = []
    for inc in includes:
        with open(inc, 'r', encoding='utf-8') as f:
            src_parts.append(f.read())
    filename = file
    if evals:
        src_parts.extend(evals)
        script_args = rest
    elif file:
        with open(file, 'r', encoding='utf-8') as f:
            src_parts.append(f.read())
        script_args = [file] + rest
    else:
        data = sys.stdin.read()
        if data:
            src_parts.append(data)
            script_args = []
        else:
            if dump:
                print(DUMP)
            return 0
    src = "\n".join(src_parts)
    mod = is_module(filename, src, module, script)
    rc = run_js(src, script_args, filename, mod, strict, std)
    if dump:
        print(DUMP)
    return rc

if __name__ == '__main__':
    sys.exit(main(sys.argv[1:]))
