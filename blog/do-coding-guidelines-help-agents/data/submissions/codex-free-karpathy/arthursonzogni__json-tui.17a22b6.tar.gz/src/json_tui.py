#!/usr/bin/env python3
import sys

VERSION = "1.4.1"

HELP = """  json-tui {OPTIONS} [file]

    A JSON terminal UI

  OPTIONS:

      file                              A JSON file. Omit to read from stdin.
      -h, --help                        Display this help menu.
      -v, --version                     Print version.
      -k, --key, --keybinding           Display key binding.
      -f, --fullscreen                  Display the JSON in fullscreen, in an
                                        alternate buffer
      "--" can be used to terminate flag options and force all following
      arguments to be treated as positional options

    If no file is given, json-tui reads JSON from the standard input
    Please report bugs to:https://github.com/ArthurSonzogni/json-tui/issues
"""

KEYS = (
    "\u250c\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u252c\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2510\r\n"
    "\u2502\033[36m\033[49mkeys       \033[39m\033[49m\u2502\033[36m\033[49maction          \033[39m\033[49m\u2502\r\n"
    "\u251c\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u253c\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2524\r\n"
    "\u2502Navigate   \u2502\u2190 \u2191 \u2193 \u2192         \u2502\r\n"
    "\u2502           \u2502h j k l         \u2502\r\n"
    "\u2502           \u2502Mouse::WheelUp  \u2502\r\n"
    "\u2502           \u2502Mouse::WheelDown\u2502\r\n"
    "\u251c\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u253c\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2524\r\n"
    "\u2502Toggle     \u2502enter           \u2502\r\n"
    "\u2502           \u2502Mouse::Left     \u2502\r\n"
    "\u251c\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u253c\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2524\r\n"
    "\u2502Deep       \u2502                \u2502\r\n"
    "\u2502 - Expand  \u2502+               \u2502\r\n"
    "\u2502 - Collapse\u2502-               \u2502\r\n"
    "\u251c\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u253c\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2524\r\n"
    "\u2502Exit       \u2502Escape          \u2502\r\n"
    "\u2502           \u2502q               \u2502\r\n"
    "\u251c\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u253c\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2524\r\n"
    "\u2502Navigate   \u2502                \u2502\r\n"
    "\u2502 - first   \u2502page-up         \u2502\r\n"
    "\u2502 - last    \u2502page-down       \u2502\r\n"
    "\u2502 - top     \u2502gg              \u2502\r\n"
    "\u2502 - bottom  \u2502G               \u2502\r\n"
    "\u2514\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2534\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2518\0"
)

C_RESET = "\033[39m\033[49m"
C_KEY = "\033[94m\033[49m"
C_STR = "\033[92m\033[49m"
C_NUM = "\033[96m\033[49m"
C_BOOL = "\033[93m\033[49m"
C_NULL = "\033[91m\033[49m"
BOLD = "\033[1m"
NBOLD = "\033[22m"


class ParseError(Exception):
    def __init__(self, message, pos):
        super().__init__(message)
        self.message = message
        self.pos = pos


class Parser:
    def __init__(self, text):
        self.s = text
        self.i = 0

    def error(self, msg):
        raise ParseError(msg, self.i)

    def peek(self):
        return self.s[self.i] if self.i < len(self.s) else ""

    def take(self, ch=None):
        if self.i >= len(self.s):
            self.error("unexpected end of input")
        c = self.s[self.i]
        if ch is not None and c != ch:
            self.error("unexpected character")
        self.i += 1
        return c

    def ws(self):
        while self.i < len(self.s) and self.s[self.i] in " \t\r\n":
            self.i += 1

    def parse(self):
        self.ws()
        if self.i >= len(self.s):
            raise ParseError("attempting to parse an empty input; check that your input string or stream contains the expected JSON", 0)
        v = self.value()
        self.ws()
        if self.i != len(self.s):
            self.error("syntax error while parsing value - unexpected trailing input")
        return v

    def value(self):
        self.ws()
        c = self.peek()
        if c == '"':
            return self.string()
        if c == "{":
            return self.obj()
        if c == "[":
            return self.arr()
        if c == "-" or c.isdigit():
            return self.num()
        for lit, val in (("true", True), ("false", False), ("null", None)):
            if self.s.startswith(lit, self.i):
                self.i += len(lit)
                return val
        self.error("syntax error while parsing value - invalid literal")

    def string(self):
        self.take('"')
        out = []
        while True:
            if self.i >= len(self.s):
                self.error("syntax error while parsing string - unexpected end of input")
            c = self.take()
            if c == '"':
                return "".join(out)
            if c == "\\":
                if self.i >= len(self.s):
                    self.error("syntax error while parsing string - invalid escape")
                e = self.take()
                table = {'"': '"', "\\": "\\", "/": "/", "b": "\b", "f": "\f", "n": "\n", "r": "\r", "t": "\t"}
                if e in table:
                    out.append(table[e])
                elif e == "u":
                    h = self.s[self.i:self.i + 4]
                    if len(h) != 4 or any(x not in "0123456789abcdefABCDEF" for x in h):
                        self.error("syntax error while parsing string - invalid unicode escape")
                    out.append(chr(int(h, 16)))
                    self.i += 4
                else:
                    self.error("syntax error while parsing string - invalid escape")
            else:
                out.append(c)

    def num(self):
        start = self.i
        if self.peek() == "-":
            self.i += 1
        if self.peek() == "0":
            self.i += 1
        elif self.peek().isdigit():
            while self.peek().isdigit():
                self.i += 1
        else:
            self.error("syntax error while parsing number")
        if self.peek() == ".":
            self.i += 1
            if not self.peek().isdigit():
                self.error("syntax error while parsing number")
            while self.peek().isdigit():
                self.i += 1
        if self.peek() and self.peek() in "eE":
            self.i += 1
            if self.peek() and self.peek() in "+-":
                self.i += 1
            if not self.peek().isdigit():
                self.error("syntax error while parsing number")
            while self.peek().isdigit():
                self.i += 1
        raw = self.s[start:self.i]
        return ("__num__", raw)

    def arr(self):
        self.take("[")
        out = []
        self.ws()
        if self.peek() == "]":
            self.i += 1
            return out
        while True:
            out.append(self.value())
            self.ws()
            if self.peek() == "]":
                self.i += 1
                return out
            self.take(",")

    def obj(self):
        self.take("{")
        out = []
        self.ws()
        if self.peek() == "}":
            self.i += 1
            return {"__obj__": out}
        while True:
            self.ws()
            if self.peek() != '"':
                self.error("syntax error while parsing object key - expected string literal")
            k = self.string()
            self.ws()
            self.take(":")
            out.append((k, self.value()))
            self.ws()
            if self.peek() == "}":
                self.i += 1
                return {"__obj__": out}
            self.take(",")


def json_quote(s):
    out = ['"']
    for c in s:
        o = ord(c)
        if c == '"':
            out.append('\\"')
        elif c == "\\":
            out.append("\\\\")
        elif c == "\n":
            out.append("\\n")
        elif c == "\r":
            out.append("\\r")
        elif c == "\t":
            out.append("\\t")
        elif o < 32:
            out.append("\\u%04x" % o)
        else:
            out.append(c)
    out.append('"')
    return "".join(out)


def is_obj(v):
    return isinstance(v, dict) and "__obj__" in v


def scalar(v):
    if isinstance(v, tuple) and v[0] == "__num__":
        return C_NUM + v[1] + C_RESET
    if isinstance(v, str):
        return C_STR + json_quote(v) + C_RESET
    if v is True:
        return C_BOOL + "true" + C_RESET
    if v is False:
        return C_BOOL + "false" + C_RESET
    if v is None:
        return C_NULL + "null" + C_RESET
    return None


def compact(v):
    s = scalar(v)
    if s is not None:
        return s
    if isinstance(v, list):
        return BOLD + ("[...]" if v else "[]") + NBOLD
    if is_obj(v):
        return BOLD + ("{" if v["__obj__"] else "{}") + NBOLD
    return ""


def render(v, indent=0, comma=False, root=True):
    sp = " " * indent
    tail = "," if comma else ""
    s = scalar(v)
    if s is not None:
        return [sp + s + tail]
    lines = []
    if isinstance(v, list):
        label = "[" + ("   (table view)" if root and all(is_obj(x) for x in v) and v else "")
        lines.append(sp + label)
        for n, item in enumerate(v):
            last = n == len(v) - 1
            if is_obj(item):
                lines += render(item, indent + 2, comma=not last, root=False)
            elif isinstance(item, list):
                lines.append(" " * (indent + 2) + compact(item) + ("," if not last else ""))
            else:
                lines += render(item, indent + 2, comma=not last, root=False)
        lines.append(sp + "]" + tail)
        return lines
    if is_obj(v):
        items = v["__obj__"]
        lines.append(sp + "{")
        for n, (k, val) in enumerate(items):
            last = n == len(items) - 1
            prefix = " " * (indent + 2) + C_KEY + json_quote(k) + C_RESET + ": "
            if is_obj(val) and val["__obj__"]:
                child = render(val, indent + 2, comma=not last, root=False)
                child[0] = prefix + BOLD + "{" + NBOLD + ("," if False else "")
                lines += child
                if not last:
                    lines[-1] += ","
            elif isinstance(val, list):
                lines.append(prefix + compact(val) + ("," if not last else ""))
            else:
                lines.append(prefix + compact(val) + ("," if not last else ""))
        lines.append(sp + "}" + tail)
        return lines
    return [sp + str(v) + tail]


def column(errpos, text):
    return errpos - text.rfind("\n", 0, errpos)


def line(errpos, text):
    return text.count("\n", 0, errpos) + 1


def main(argv):
    args = argv[1:]
    fullscreen = False
    files = []
    flags = True
    for a in args:
        if flags and a == "--":
            flags = False
        elif flags and a in ("-h", "--help"):
            sys.stdout.write(HELP)
            return 0
        elif flags and a in ("-v", "--version"):
            print(VERSION)
            return 0
        elif flags and a in ("-k", "--key", "--keybinding", "-key", "-keybinding"):
            sys.stdout.write(KEYS)
            return 0
        elif flags and a in ("-f", "--fullscreen"):
            fullscreen = True
        elif flags and a.startswith("-"):
            print("Invalid arguments", file=sys.stderr)
            return 1
        else:
            files.append(a)
    if len(files) > 1:
        print("Invalid arguments", file=sys.stderr)
        return 1
    try:
        if files:
            try:
                data = open(files[0], "r", encoding="utf-8").read()
            except OSError:
                print("Could not open file " + files[0], file=sys.stderr)
                return 1
        else:
            data = sys.stdin.read()
        value = Parser(data).parse()
    except ParseError as e:
        sys.stdout.write(HELP)
        sys.stderr.write("\n[json.exception.parse_error.101] parse error at line %d, column %d: %s\n" % (line(e.pos, data), column(e.pos, data), e.message))
        return 1
    if fullscreen:
        sys.stdout.write("\033[?1049h")
    sys.stdout.write("\0\033[?7l\033[?1000h\033[?1003h\033[?1015h\033[?1006h\0\r\033[2K")
    lines = render(value)
    for i, l in enumerate(lines):
        if i == 0:
            sys.stdout.write("\033[7m" + l + "\033[27m")
        else:
            sys.stdout.write(l)
        sys.stdout.write("\r\n" if i != len(lines) - 1 else "")
    sys.stdout.write("\033[?1006l\033[?1015l\033[?1003l\033[?1000l\033[?7h\033[?25h\033[1 q\0")
    if fullscreen:
        sys.stdout.write("\033[?1049l")
    sys.stdout.write("\r\n")
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv))
