#!/usr/bin/env python3
import os
import re
import shlex
import subprocess
import sys
import time

VERSION = "tspin 5.6.0"
GROUPS = {
    "numbers", "urls", "pointers", "dates", "paths", "quotes",
    "key-value-pairs", "uuids", "ip-addresses", "processes", "json",
}
COLORS = {
    "red": "31", "green": "32", "yellow": "33",
    "blue": "34", "magenta": "35", "cyan": "36",
}
RESET = "\033[0m"


def style(s, code):
    return f"\033[{code}m{s}{RESET}"


def help_text(long=True):
    if not long:
        return """A log file highlighter

Usage: executable [OPTIONS] [FILE]

Arguments:
  [FILE]  Filepath

Options:
  -f, --follow
          Follow the contents of a file
  -p, --print
          Print the output to stdout
      --config-path <CONFIG_PATH>
          Provide a custom path to a configuration file
  -e, --exec <EXEC>
          Run command and view the output in a pager
      --highlight <COLOR_WORD>
          Highlights in the form color:word1,word2
      --enable <ENABLED_HIGHLIGHTERS>
          Enable specific highlighters [possible values: numbers, urls, pointers, dates, paths,
          quotes, key-value-pairs, uuids, ip-addresses, processes, json]
      --disable <DISABLED_HIGHLIGHTERS>
          Disable specific highlighters [possible values: numbers, urls, pointers, dates, paths,
          quotes, key-value-pairs, uuids, ip-addresses, processes, json]
      --disable-builtin-keywords
          Disable the highlighting of all builtin keyword groups (booleans, nulls, log severities
          and common REST verbs)
      --pager <PAGER>
          Override the default pager command used by tspin. (e.g. `--pager="ov -f [FILE]"`) [env:
          TAILSPIN_PAGER=]
  -h, --help
          Print help (see a summary with '-h')
  -V, --version
          Print version
"""
    return """A log file highlighter

Usage: executable [OPTIONS] [FILE]

Arguments:
  [FILE]
          Filepath

Options:
  -f, --follow
          Follow the contents of a file

  -p, --print
          Print the output to stdout

      --config-path <CONFIG_PATH>
          Provide a custom path to a configuration file

  -e, --exec <EXEC>
          Run command and view the output in a pager

      --highlight <COLOR_WORD>
          Highlights in the form color:word1,word2
          
          [possible values: red, green, yellow, blue, magenta, cyan]

      --enable <ENABLED_HIGHLIGHTERS>
          Enable specific highlighters
          
          [possible values: numbers, urls, pointers, dates, paths, quotes, key-value-pairs, uuids,
          ip-addresses, processes, json]

      --disable <DISABLED_HIGHLIGHTERS>
          Disable specific highlighters
          
          [possible values: numbers, urls, pointers, dates, paths, quotes, key-value-pairs, uuids,
          ip-addresses, processes, json]

      --disable-builtin-keywords
          Disable the highlighting of all builtin keyword groups (booleans, nulls, log severities
          and common REST verbs)

      --pager <PAGER>
          Override the default pager command used by tspin. (e.g. `--pager="ov -f [FILE]"`)
          
          [env: TAILSPIN_PAGER=]

  -h, --help
          Print help (see a summary with '-h')

  -V, --version
          Print version
"""


class Args:
    def __init__(self):
        self.follow = False
        self.print_out = False
        self.config = None
        self.exec_cmd = None
        self.highlights = []
        self.enable = []
        self.disable = []
        self.disable_builtin = False
        self.pager = None
        self.file = None


def die(msg, status=1):
    sys.stderr.write(msg)
    if not msg.endswith("\n"):
        sys.stderr.write("\n")
    raise SystemExit(status)


def parse_csv_values(value, opt):
    out = []
    for part in value.split(","):
        part = part.strip()
        if not part:
            continue
        if part not in GROUPS:
            die(f"error: invalid value '{part}' for '{opt} <{opt[2:].replace('-', '_').upper()}>'\n  [possible values: numbers, urls, pointers, dates, paths, quotes, key-value-pairs, uuids, ip-addresses, processes, json]\n\nFor more information, try '--help'.", 2)
        out.append(part)
    return out


def parse_args(argv):
    a = Args()
    i = 0
    while i < len(argv):
        arg = argv[i]
        if arg == "-h":
            print(help_text(False), end="")
            raise SystemExit(0)
        if arg == "--help":
            print(help_text(True), end="")
            raise SystemExit(0)
        if arg in ("-V", "--version"):
            print(VERSION)
            raise SystemExit(0)
        if arg in ("-f", "--follow"):
            a.follow = True; i += 1; continue
        if arg in ("-p", "--print"):
            a.print_out = True; i += 1; continue
        if arg in ("--disable-builtin-keywords",):
            a.disable_builtin = True; i += 1; continue
        if arg in ("--config-path", "-e", "--exec", "--pager", "--highlight", "--enable", "--disable"):
            if i + 1 >= len(argv):
                die(f"error: a value is required for '{arg} <VALUE>' but none was supplied\n\nFor more information, try '--help'.", 2)
            val = argv[i + 1]
            i += 2
        elif arg.startswith("--config-path="):
            val = arg.split("=", 1)[1]; arg = "--config-path"; i += 1
        elif arg.startswith("--exec="):
            val = arg.split("=", 1)[1]; arg = "--exec"; i += 1
        elif arg.startswith("-e") and arg != "-e":
            val = arg[2:]; arg = "-e"; i += 1
        elif arg.startswith("--pager="):
            val = arg.split("=", 1)[1]; arg = "--pager"; i += 1
        elif arg.startswith("--highlight="):
            val = arg.split("=", 1)[1]; arg = "--highlight"; i += 1
        elif arg.startswith("--enable="):
            val = arg.split("=", 1)[1]; arg = "--enable"; i += 1
        elif arg.startswith("--disable="):
            val = arg.split("=", 1)[1]; arg = "--disable"; i += 1
        elif arg.startswith("-"):
            die(f"error: unexpected argument '{arg}' found\n\n  tip: to pass '{arg}' as a value, use '-- {arg}'\n\nUsage: executable [OPTIONS] [FILE]\n\nFor more information, try '--help'.", 2)
        else:
            if a.file is not None:
                die(f"error: unexpected argument '{arg}' found\n\nUsage: executable [OPTIONS] [FILE]\n\nFor more information, try '--help'.", 2)
            a.file = arg
            i += 1
            continue

        if arg == "--config-path":
            a.config = val
        elif arg in ("-e", "--exec"):
            a.exec_cmd = val
        elif arg == "--pager":
            a.pager = val
        elif arg == "--highlight":
            if ":" not in val:
                die(f"error: invalid value '{val}' for '--highlight <COLOR_WORD>': Expected format COLOR:word1,word2,... found `{val}`\n\nFor more information, try '--help'.", 2)
            color, words = val.split(":", 1)
            if color not in COLORS:
                die(f"error: invalid value '{val}' for '--highlight <COLOR_WORD>': invalid variant: {color}\n\nFor more information, try '--help'.", 2)
            a.highlights.extend((w, COLORS[color]) for w in words.split(",") if w)
        elif arg == "--enable":
            a.enable.extend(parse_csv_values(val, "--enable"))
        elif arg == "--disable":
            a.disable.extend(parse_csv_values(val, "--disable"))
    if a.enable and a.disable:
        die("Error:   × cannot both enable and disable highlighters\n", 1)
    return a


def enabled_groups(args):
    if args.enable:
        return set(args.enable)
    return GROUPS - set(args.disable)


RE_URL = re.compile(r"https?://[^\s\]\)\"']+")
RE_DATE = re.compile(r"\b(?:\d{4}[-/]\d{2}[-/]\d{2}(?:[T ][0-9:.]+(?:Z)?)?|(?:Mon|Tue|Wed|Thu|Fri|Sat|Sun)\s+(?:Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)\s+\d{1,2}\s+[0-9:.]+|(?:Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)\s+\d{1,2}\s+[0-9:.]+|\d{2}:\d{2}:\d{2}(?:[.,]\d+)?)\b")
RE_UUID = re.compile(r"\b[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}\b")
RE_PTR = re.compile(r"\b0x[0-9a-fA-F]+\b")
RE_IP = re.compile(r"(?<![\w:])(?:\d{1,3}\.){3}\d{1,3}(?![\w:])|(?<!\w)(?:[0-9a-fA-F]{1,4}:){2,}[0-9a-fA-F:.%]+")
RE_PATH = re.compile(r"(?<!\w)(?:~|/)[A-Za-z0-9._~+/@%-]+")
RE_KV = re.compile(r"\b([A-Za-z_][A-Za-z0-9_.-]*)(=)")
RE_QUOTE = re.compile(r'"(?:\\.|[^"\\])*"')
RE_NUMBER = re.compile(r"(?<![\w.])\d+(?:\.\d+)?%?(?![\w.])")
RE_SEV = re.compile(r"\b(TRACE|DEBUG|INFO|WARN|WARNING|ERROR|FATAL|CRITICAL)\b|(?<==)(trace|debug|info|warn|warning|error|fatal|critical)\b")
RE_BOOL = re.compile(r"\b(true|false|null|unknown)\b", re.I)
RE_REST = re.compile(r"\b(GET|POST|PUT|PATCH|DELETE|HEAD|OPTIONS)\b")


def add_spans(spans, line, regex, code, group, groups, repl=None):
    if group and group not in groups:
        return
    for m in regex.finditer(line):
        s, e = m.span()
        if s == e:
            continue
        text = line[s:e]
        spans.append((s, e, repl(text, m) if repl else style(text, code)))


def highlight_url(text, _m):
    m = re.match(r"(https?)(://)([^/?#]+)(.*)", text)
    if not m:
        return style(text, "34")
    proto, sep, host, rest = m.groups()
    out = style(proto, "2;31") + sep + style(host, "2;34")
    if rest:
        path, query = (rest.split("?", 1) + [""])[:2] if "?" in rest else (rest, "")
        out += style(path, "34")
        if query:
            out += style("?", "31")
            out += re.sub(r"([A-Za-z_][A-Za-z0-9_-]*)(=)(\d+|true|false|null|[^&]+)",
                          lambda m: style(m.group(1), "35") + style("=", "31") + style(m.group(3), "36"),
                          query)
    return out


def highlight_date(text, _m):
    return re.sub(r"\d+", lambda x: style(x.group(0), "35" if len(x.group(0)) != 2 or x.start() < 5 else "34"), text).replace("-", style("-", "2")).replace(":", style(":", "2")).replace("T", style("T", "31")).replace(" ", style(" ", "31"), 1)


def highlight_kv(text, m):
    return style(m.group(1), "2") + style("=", "37")


def highlight_path(text, _m):
    parts = re.split(r"(/)", text)
    out = []
    for p in parts:
        if not p:
            continue
        out.append(style(p, "33" if p == "/" else "32"))
    return "".join(out)


def highlight_ip(text, _m):
    return re.sub(r"(\d+|[a-fA-F]+|\.|:)",
                  lambda m: style(m.group(0), "31" if m.group(0) in ".:" else "3;34"),
                  text)


def highlight_sev(text, _m):
    t = text.upper()
    if t == "INFO":
        return style(text, "37")
    if t in ("WARN", "WARNING"):
        return style(text, "33")
    if t in ("ERROR", "FATAL", "CRITICAL"):
        return style(text, "31")
    if t == "DEBUG":
        return style(text, "32")
    return style(text, "2")


def highlight_rest(text, _m):
    bg = {"GET": "42", "POST": "43", "PUT": "44", "PATCH": "45", "DELETE": "41", "HEAD": "46", "OPTIONS": "46"}.get(text, "44")
    return style(f" {text} ", f"{bg};30")


def highlight_line(line, args):
    groups = enabled_groups(args)
    spans = []
    add_spans(spans, line, RE_URL, "34", "urls", groups, highlight_url)
    add_spans(spans, line, RE_DATE, "35", "dates", groups, highlight_date)
    add_spans(spans, line, RE_UUID, "3;35", "uuids", groups)
    add_spans(spans, line, RE_PTR, "3;34", "pointers", groups)
    add_spans(spans, line, RE_IP, "3;34", "ip-addresses", groups, highlight_ip)
    add_spans(spans, line, RE_PATH, "32", "paths", groups, highlight_path)
    add_spans(spans, line, RE_QUOTE, "33", "quotes", groups)
    add_spans(spans, line, RE_KV, "2", "key-value-pairs", groups, highlight_kv)
    if not args.disable_builtin:
        add_spans(spans, line, RE_REST, "42;30", None, groups, highlight_rest)
        add_spans(spans, line, RE_SEV, "37", None, groups, highlight_sev)
        add_spans(spans, line, RE_BOOL, "3;31", None, groups)
    for word, code in args.highlights:
        pat = re.compile(re.escape(word))
        add_spans(spans, line, pat, code, None, groups)
    add_spans(spans, line, RE_NUMBER, "36", "numbers", groups)
    spans.sort(key=lambda x: (x[0], -(x[1] - x[0])))
    out = []
    pos = 0
    for s, e, rep in spans:
        if s < pos:
            continue
        out.append(line[pos:s])
        out.append(rep)
        pos = e
    out.append(line[pos:])
    return "".join(out)


def emit_stream(stream, args):
    for line in stream:
        sys.stdout.write(highlight_line(line, args))
    sys.stdout.flush()


def open_file(path):
    try:
        return open(path, "r", encoding="utf-8", errors="replace")
    except OSError as e:
        die(f"Error:   ⚠ {style(path, '33')}: {e.strerror}\n", 1)


def main():
    args = parse_args(sys.argv[1:])
    if args.config and not os.path.exists(args.config):
        die("Error:   × could not find the TOML file\n", 1)
    if args.exec_cmd is not None:
        p = subprocess.Popen(args.exec_cmd, shell=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, encoding="utf-8", errors="replace")
        emit_stream(p.stdout, args)
        raise SystemExit(p.wait())
    if args.file:
        with open_file(args.file) as f:
            emit_stream(f, args)
            if args.follow:
                while True:
                    where = f.tell()
                    line = f.readline()
                    if line:
                        sys.stdout.write(highlight_line(line, args)); sys.stdout.flush()
                    else:
                        f.seek(where); time.sleep(0.25)
    else:
        emit_stream(sys.stdin, args)


if __name__ == "__main__":
    try:
        main()
    except BrokenPipeError:
        try:
            sys.stdout.close()
        finally:
            raise SystemExit(0)
