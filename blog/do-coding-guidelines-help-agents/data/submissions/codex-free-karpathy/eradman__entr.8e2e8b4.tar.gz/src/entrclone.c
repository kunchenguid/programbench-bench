#define _GNU_SOURCE
#include <errno.h>
#include <fcntl.h>
#include <limits.h>
#include <signal.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/inotify.h>
#include <sys/select.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <unistd.h>

#ifndef PATH_MAX
#define PATH_MAX 4096
#endif

struct opts {
    int c;
    int d;
    int x;
    bool a, n, p, r, s, z;
};

struct watch {
    int wd;
    char *path;
    bool dir;
};

static volatile sig_atomic_t interrupted = 0;
static const char *progname;

static void on_sigint(int sig) {
    (void)sig;
    interrupted = 1;
}

static void usage(FILE *f) {
    fprintf(f, "release: 5.7\n");
    fprintf(f, "usage: entr [-acdnprsxz] utility [argument [/_] ...] < filenames\n");
}

static void hint(FILE *f) {
    fprintf(f, "hint: use -h to display option summary\n");
}

static void help(void) {
    usage(stderr);
    fprintf(stderr, "summary:\n");
    fprintf(stderr, "    -a  Do not consolidate events\n");
    fprintf(stderr, "    -c  Clear screen before execution\n");
    fprintf(stderr, "    -d  Track files added or removed from directories\n");
    fprintf(stderr, "    -n  Non-interactive mode\n");
    fprintf(stderr, "    -p  Wait for first event\n");
    fprintf(stderr, "    -r  Run as a background process, use signal to restart\n");
    fprintf(stderr, "    -s  Evaluate using a shell\n");
    fprintf(stderr, "    -x  Format exit status\n");
    fprintf(stderr, "    -z  Exit after the utility completes\n");
    fprintf(stderr, "docs:\n");
    fprintf(stderr, "    man entr\n");
}

static char *xstrdup(const char *s) {
    char *p = strdup(s);
    if (!p) {
        perror("strdup");
        exit(1);
    }
    return p;
}

static char *absolute_path(const char *path) {
    char resolved[PATH_MAX];
    if (realpath(path, resolved))
        return xstrdup(resolved);
    if (path[0] == '/')
        return xstrdup(path);
    char cwd[PATH_MAX];
    if (!getcwd(cwd, sizeof(cwd)))
        return xstrdup(path);
    size_t n = strlen(cwd) + strlen(path) + 2;
    char *out = malloc(n);
    if (!out) {
        perror("malloc");
        exit(1);
    }
    snprintf(out, n, "%s/%s", cwd, path);
    return out;
}

static char *dirname_of(const char *path) {
    char *copy = xstrdup(path);
    char *slash = strrchr(copy, '/');
    if (!slash) {
        free(copy);
        return xstrdup(".");
    }
    if (slash == copy) {
        slash[1] = '\0';
    } else {
        *slash = '\0';
    }
    return copy;
}

static char **read_paths(size_t *count, char **first_abs) {
    char **paths = NULL;
    size_t cap = 0, n = 0;
    char *line = NULL;
    size_t len = 0;
    while (getline(&line, &len, stdin) != -1) {
        line[strcspn(line, "\r\n")] = '\0';
        if (line[0] == '\0')
            continue;
        struct stat st;
        if (stat(line, &st) != 0) {
            fprintf(stderr, "%s: unable to stat '%s'\n", progname, line);
            continue;
        }
        if (n == cap) {
            cap = cap ? cap * 2 : 16;
            char **tmp = realloc(paths, cap * sizeof(*paths));
            if (!tmp) {
                perror("realloc");
                exit(1);
            }
            paths = tmp;
        }
        paths[n++] = xstrdup(line);
        if (!*first_abs)
            *first_abs = absolute_path(line);
    }
    free(line);
    *count = n;
    return paths;
}

static void clear_screen(int c) {
    if (c <= 0)
        return;
    if (c > 1)
        fputs("\033[3J", stdout);
    fputs("\033[2J\033[H", stdout);
    fflush(stdout);
}

static int restart_signal(void) {
    const char *s = getenv("ENTR_RESTART_SIGNAL");
    if (!s || !*s)
        return SIGTERM;
    if (!strcmp(s, "HUP") || !strcmp(s, "SIGHUP")) return SIGHUP;
    if (!strcmp(s, "INT") || !strcmp(s, "SIGINT")) return SIGINT;
    if (!strcmp(s, "QUIT") || !strcmp(s, "SIGQUIT")) return SIGQUIT;
    if (!strcmp(s, "TERM") || !strcmp(s, "SIGTERM")) return SIGTERM;
    if (!strcmp(s, "USR1") || !strcmp(s, "SIGUSR1")) return SIGUSR1;
    if (!strcmp(s, "USR2") || !strcmp(s, "SIGUSR2")) return SIGUSR2;
    return SIGTERM;
}

static pid_t spawn_child(char **argv, int argc, const struct opts *opts, const char *trigger) {
    pid_t pid = fork();
    if (pid < 0) {
        perror("fork");
        return -1;
    }
    if (pid == 0) {
        signal(SIGINT, SIG_DFL);
        if (opts->r)
            setpgid(0, 0);
        if (opts->s) {
            const char *shell = getenv("SHELL");
            if (!shell || !*shell)
                shell = "/bin/sh";
            int extra = argc > 1 ? argc - 1 : 0;
            char **av = calloc((size_t)extra + 5, sizeof(char *));
            if (!av)
                _exit(127);
            av[0] = (char *)shell;
            av[1] = "-c";
            av[2] = argv[0];
            av[3] = (char *)trigger;
            for (int i = 1; i < argc; i++)
                av[i + 3] = argv[i];
            execv(shell, av);
            perror(shell);
            _exit(127);
        } else {
            char **av = calloc((size_t)argc + 1, sizeof(char *));
            if (!av)
                _exit(127);
            for (int i = 0; i < argc; i++) {
                if (!strcmp(argv[i], "/_"))
                    av[i] = (char *)trigger;
                else
                    av[i] = argv[i];
            }
            execvp(av[0], av);
            perror(av[0]);
            _exit(127);
        }
    }
    return pid;
}

static int wait_status(pid_t pid) {
    int st;
    do {
        if (waitpid(pid, &st, 0) < 0) {
            if (errno == EINTR)
                continue;
            return 1;
        }
        break;
    } while (1);
    if (WIFEXITED(st))
        return WEXITSTATUS(st);
    if (WIFSIGNALED(st))
        return 128 + WTERMSIG(st);
    return 1;
}

static int run_once(char **argv, int argc, const struct opts *opts, const char *trigger) {
    clear_screen(opts->c);
    pid_t pid = spawn_child(argv, argc, opts, trigger);
    if (pid < 0)
        return 1;
    return wait_status(pid);
}

static int add_watch(int fd, struct watch **watches, size_t *n, size_t *cap,
                     const char *path, bool dir) {
    uint32_t mask = dir ? (IN_CREATE | IN_DELETE | IN_MOVED_FROM | IN_MOVED_TO)
                        : (IN_CLOSE_WRITE | IN_MODIFY | IN_ATTRIB | IN_MOVE_SELF |
                           IN_DELETE_SELF | IN_IGNORED);
    int wd = inotify_add_watch(fd, path, mask);
    if (wd < 0)
        return -1;
    if (*n == *cap) {
        *cap = *cap ? *cap * 2 : 16;
        struct watch *tmp = realloc(*watches, *cap * sizeof(**watches));
        if (!tmp) {
            perror("realloc");
            exit(1);
        }
        *watches = tmp;
    }
    (*watches)[*n].wd = wd;
    (*watches)[*n].path = xstrdup(path);
    (*watches)[*n].dir = dir;
    (*n)++;
    return 0;
}

static const struct watch *find_watch(struct watch *w, size_t n, int wd) {
    for (size_t i = 0; i < n; i++)
        if (w[i].wd == wd)
            return &w[i];
    return NULL;
}

static int wait_event(int fd, struct watch *watches, size_t nwatches, int dlevel,
                      char **trigger) {
    char buf[8192] __attribute__((aligned(__alignof__(struct inotify_event))));
    for (;;) {
        if (interrupted)
            return 0;
        ssize_t len = read(fd, buf, sizeof(buf));
        if (len < 0) {
            if (errno == EINTR)
                continue;
            perror("read");
            return 1;
        }
        for (char *p = buf; p < buf + len; ) {
            struct inotify_event *ev = (struct inotify_event *)p;
            const struct watch *w = find_watch(watches, nwatches, ev->wd);
            if (w) {
                if (w->dir) {
                    if (dlevel < 2 && ev->len && ev->name[0] == '.') {
                        p += sizeof(*ev) + ev->len;
                        continue;
                    }
                    fprintf(stderr, "%s: directory altered\n", progname);
                    return 2;
                }
                free(*trigger);
                *trigger = absolute_path(w->path);
                if (getenv("EV_TRACE"))
                    fprintf(stderr, "%s: event %u\n", w->path, ev->mask);
                return 3;
            }
            p += sizeof(*ev) + ev->len;
        }
    }
}

static int watch_loop(char **paths, size_t npaths, char **argv, int argc,
                      const struct opts *opts, char *first_abs) {
    int fd = inotify_init1(0);
    if (fd < 0) {
        perror("inotify_init");
        return 1;
    }
    struct watch *watches = NULL;
    size_t nwatches = 0, cap = 0;
    for (size_t i = 0; i < npaths; i++) {
        struct stat st;
        if (stat(paths[i], &st) != 0)
            continue;
        if (S_ISDIR(st.st_mode)) {
            add_watch(fd, &watches, &nwatches, &cap, paths[i], opts->d > 0);
        } else {
            add_watch(fd, &watches, &nwatches, &cap, paths[i], false);
            if (opts->d > 0) {
                char *dir = dirname_of(paths[i]);
                add_watch(fd, &watches, &nwatches, &cap, dir, true);
                free(dir);
            }
        }
    }
    if (nwatches == 0) {
        close(fd);
        return 1;
    }

    char *trigger = xstrdup(first_abs);
    pid_t persistent = -1;
    if (!opts->p) {
        if (opts->r) {
            clear_screen(opts->c);
            persistent = spawn_child(argv, argc, opts, trigger);
        } else {
            int st = run_once(argv, argc, opts, trigger);
            if (opts->z) {
                free(trigger);
                close(fd);
                return st;
            }
        }
    }

    while (!interrupted) {
        int ev = wait_event(fd, watches, nwatches, opts->d, &trigger);
        if (ev == 0)
            break;
        if (ev == 1 || ev == 2) {
            if (persistent > 0) {
                kill(-persistent, restart_signal());
                wait_status(persistent);
            }
            free(trigger);
            close(fd);
            return ev;
        }
        if (opts->r) {
            if (persistent > 0) {
                kill(-persistent, restart_signal());
                wait_status(persistent);
            }
            clear_screen(opts->c);
            persistent = spawn_child(argv, argc, opts, trigger);
            if (opts->z) {
                int st = wait_status(persistent);
                free(trigger);
                close(fd);
                return st;
            }
        } else {
            int st = run_once(argv, argc, opts, trigger);
            if (opts->z) {
                free(trigger);
                close(fd);
                return st;
            }
            if (!opts->a) {
                fcntl(fd, F_SETFL, O_NONBLOCK);
                char drain[8192];
                while (read(fd, drain, sizeof(drain)) > 0) {}
                fcntl(fd, F_SETFL, 0);
            }
        }
    }
    if (persistent > 0) {
        kill(-persistent, restart_signal());
        wait_status(persistent);
    }
    free(trigger);
    close(fd);
    return 0;
}

int main(int argc, char **argv) {
    progname = argv[0];
    struct opts opts = {0};
    opterr = 0;
    int ch;
    while ((ch = getopt(argc, argv, "+acdnprsxzh")) != -1) {
        switch (ch) {
        case 'a': opts.a = true; break;
        case 'c': opts.c++; break;
        case 'd': opts.d++; break;
        case 'n': opts.n = true; break;
        case 'p': opts.p = true; break;
        case 'r': opts.r = true; break;
        case 's': opts.s = true; break;
        case 'x': opts.x++; break;
        case 'z': opts.z = true; break;
        case 'h':
            help();
            return 1;
        default:
            fprintf(stderr, "%s: invalid option -- '%c'\n", progname, optopt ? optopt : '?');
            usage(stderr);
            hint(stderr);
            return 1;
        }
    }
    if (optind >= argc) {
        usage(stderr);
        hint(stderr);
        return 1;
    }

    setenv("PAGER", "/bin/cat", 0);
    struct sigaction sa;
    memset(&sa, 0, sizeof(sa));
    sa.sa_handler = on_sigint;
    sigemptyset(&sa.sa_mask);
    sigaction(SIGINT, &sa, NULL);
    sigaction(SIGTERM, &sa, NULL);

    char *first_abs = NULL;
    size_t npaths = 0;
    char **paths = read_paths(&npaths, &first_abs);
    if (npaths == 0) {
        fprintf(stderr, "%s: No regular files to watch\n", progname);
        return 1;
    }
    int st = watch_loop(paths, npaths, argv + optind, argc - optind, &opts, first_abs);
    for (size_t i = 0; i < npaths; i++)
        free(paths[i]);
    free(paths);
    free(first_abs);
    return st;
}
