#!/usr/bin/env python3
import os, sys, re, json, fnmatch, html
from pathlib import Path

BANNER = r'''
 _ __ _____   _(_)__  _____
| '__/ _ \ \ / / \ \ / / _ \
| | |  __/\ V /| |\ V /  __/
|_|  \___| \_/ |_| \_/ \___|

Example:
  revive -config c.toml -formatter friendly -exclude a.go -exclude b.go ./...
'''
VERSION = 'Version:\ta75b67b\nCommit:\t\ta75b67b73b9edb91dfc9f302dd108fa9d3ea5b05\nBuilt\t\t2026-04-17 19:59 UTC by build.sh'
DEFAULT_RULES = {'package-comments','exported','var-naming'}
CATEGORIES = {'package-comments':'comments','exported':'comments','var-naming':'naming','line-length-limit':'style'}

class Finding:
    def __init__(self, path,line,col,msg,rule,conf=1,severity='warning',end_line=None,end_col=None,offset=0,end_offset=0):
        self.path=path; self.line=line; self.col=col; self.msg=msg; self.rule=rule; self.conf=conf; self.severity=severity
        self.end_line=end_line or line; self.end_col=end_col or col; self.offset=offset; self.end_offset=end_offset or offset
    def obj(self):
        return {"Severity":self.severity,"Failure":self.msg,"RuleName":self.rule,"Category":CATEGORIES.get(self.rule,''),
                "Position":{"Start":{"Filename":self.path,"Offset":self.offset,"Line":self.line,"Column":self.col},
                            "End":{"Filename":self.path,"Offset":self.end_offset,"Line":self.end_line,"Column":self.end_col}},
                "Confidence":self.conf,"ReplacementLine":""}

def usage():
    print(BANNER)
    print('Usage of ./executable:')
    print('  -config string')
    print('\tpath to the configuration TOML file, defaults to $XDG_CONFIG_HOME/revive.toml or $HOME/revive.toml, if present (i.e. -config myconf.toml)')
    print('  -exclude value')
    print('\tlist of globs which specify files to be excluded (i.e. -exclude foo/...)')
    print('  -formatter string')
    print('\tformatter to be used for the output (i.e. -formatter stylish)')
    print('  -max_open_files int')
    print('\tmaximum number of open files at the same time')
    print('  -set_exit_status')
    print('\tset exit status to 1 if any issues are found, overwrites errorCode and warningCode in config')
    print('  -version')
    print('\tget revive version')

def parse_args(argv):
    opts={'config':None,'formatter':'default','exclude':[],'set_exit_status':False,'version':False,'packages':[]}
    i=0
    while i < len(argv):
        a=argv[i]
        if a in ('-h','--help'):
            opts['help']=True; i+=1
        elif a=='-version': opts['version']=True; i+=1
        elif a=='-set_exit_status': opts['set_exit_status']=True; i+=1
        elif a in ('-config','-formatter','-exclude','-max_open_files'):
            if i+1>=len(argv): print(f'flag needs an argument: {a}', file=sys.stderr); sys.exit(2)
            if a=='-config': opts['config']=argv[i+1]
            elif a=='-formatter': opts['formatter']=argv[i+1]
            elif a=='-exclude': opts['exclude'].append(argv[i+1])
            i+=2
        else:
            opts['packages'].append(a); i+=1
    return opts

def parse_config(path):
    cfg={'severity':'warning','confidence':0.0,'rules':None,'line_length':None}
    if not path:
        for p in [os.path.join(os.environ.get('XDG_CONFIG_HOME',''), 'revive.toml') if os.environ.get('XDG_CONFIG_HOME') else None,
                  os.path.join(os.environ.get('HOME',''), 'revive.toml') if os.environ.get('HOME') else None]:
            if p and os.path.exists(p): path=p; break
    if not path: return cfg
    try: txt=Path(path).read_text()
    except Exception as e:
        print(f'cannot read the config file: {e}', file=sys.stderr); sys.exit(1)
    rules=[]; disabled=set(); cur=None
    for raw in txt.splitlines():
        line=raw.split('#',1)[0].strip()
        if not line: continue
        m=re.match(r'\[\s*rule\.([^\]]+)\s*\]', line)
        if m:
            cur=m.group(1).strip().strip('"'); rules.append(cur); continue
        m=re.match(r'severity\s*=\s*["\']([^"\']+)', line)
        if m: cfg['severity']=m.group(1); continue
        m=re.match(r'confidence\s*=\s*([0-9.]+)', line)
        if m:
            try: cfg['confidence']=float(m.group(1))
            except Exception: pass
        if cur:
            if re.match(r'(?i)disabled\s*=\s*true', line): disabled.add(cur)
            m=re.match(r'arguments\s*=\s*\[\s*([0-9]+)', line)
            if m and cur=='line-length-limit': cfg['line_length']=int(m.group(1))
    if rules:
        cfg['rules']=set(rules)-disabled
    return cfg

def relpath(p):
    try: return os.path.relpath(p, os.getcwd())
    except Exception: return str(p)

def excluded(path, patterns):
    rp=relpath(path)
    for pat in patterns:
        p=pat[2:] if pat.startswith('./') else pat
        if p.endswith('/...'):
            base=p[:-4].rstrip('/')
            if base in ('', '.'): return True
            if rp==base or rp.startswith(base+'/'): return True
        if fnmatch.fnmatch(rp, p) or fnmatch.fnmatch(os.path.basename(rp), p) or rp==p:
            return True
    return False

def collect_files(args, excludes):
    targets=args or ['.']
    out=[]
    for t in targets:
        if t.endswith('/...'):
            root=t[:-4] or '.'
            for dirpath, dirs, files in os.walk(root):
                dirs[:] = [d for d in dirs if d not in ('.git','vendor') and not d.startswith('.')]
                for f in files:
                    if f.endswith('.go') and not f.endswith('_test.go'):
                        p=os.path.join(dirpath,f)
                        if not excluded(p, excludes): out.append(p)
        elif os.path.isdir(t):
            for f in os.listdir(t):
                p=os.path.join(t,f)
                if f.endswith('.go') and not f.endswith('_test.go') and not excluded(p, excludes): out.append(p)
        elif t.endswith('.go') and os.path.exists(t) and not excluded(t, excludes):
            out.append(t)
    return sorted(dict.fromkeys(out))

def offset_of(lines, idx, col):
    return sum(len(x) for x in lines[:idx]) + max(col-1,0)

def exported(name): return bool(name) and name[0].isupper()

def go_name(name):
    parts=[p for p in name.split('_') if p]
    if not parts: return name.replace('_','')
    first=parts[0]
    def cap(s): return s[:1].upper()+s[1:].lower() if s.isupper() else s[:1].upper()+s[1:]
    return first + ''.join(cap(p) for p in parts[1:])

def prior_comment_ok(lines, idx, name):
    j=idx-1
    while j>=0 and lines[j].strip()=='' : j-=1
    if j<0: return False
    s=lines[j].strip()
    if not (s.startswith('//') or s.endswith('*/')): return False
    text=s.lstrip('/').lstrip('*').strip()
    return text.startswith(name+' ') or text.startswith(name+',') or text.startswith(name+'.') or text==name

def disabled_lines(lines):
    disabled_all=set(); disabled_rule={}; next_all=set(); next_rule={}; active_all=False; active_rules=set()
    for i,l in enumerate(lines, start=1):
        s=l.strip()
        if 'revive:disable-next-line' in s:
            rule=s.split('revive:disable-next-line',1)[1].strip().lstrip(':').strip()
            if rule: next_rule.setdefault(i+1,set()).add(rule)
            else: next_all.add(i+1)
        if 'revive:disable' in s and 'disable-next-line' not in s:
            rule=s.split('revive:disable',1)[1].strip().lstrip(':').strip()
            if rule: active_rules.add(rule)
            else: active_all=True
        if active_all: disabled_all.add(i)
        for r in active_rules: disabled_rule.setdefault(i,set()).add(r)
        if 'revive:enable' in s:
            rule=s.split('revive:enable',1)[1].strip().lstrip(':').strip()
            if rule: active_rules.discard(rule)
            else: active_all=False; active_rules.clear()
    return disabled_all, disabled_rule, next_all, next_rule

def is_disabled(f, da, dr, na, nr):
    return f.line in da or f.line in na or f.rule in dr.get(f.line,set()) or f.rule in nr.get(f.line,set())

def lint_file(path, cfg):
    try: data=Path(path).read_text(errors='replace')
    except Exception: return []
    lines=data.splitlines(True); text=''.join(lines); short=relpath(path)
    fs=[]
    pkg_m=re.search(r'^\s*package\s+(\w+)', text, re.M)
    pkg=pkg_m.group(1) if pkg_m else ''
    rules=cfg['rules'] if cfg['rules'] is not None else DEFAULT_RULES
    if 'package-comments' in rules and pkg and pkg!='main':
        line_no=text[:pkg_m.start()].count('\n')+1; col=pkg_m.start()-text.rfind('\n',0,pkg_m.start())
        before=text[:pkg_m.start()].rstrip().splitlines()
        ok=bool(before and before[-1].strip().startswith('// Package '+pkg))
        if not ok:
            off=offset_of(lines,line_no-1,col); fs.append(Finding(short,line_no,col,'should have a package comment','package-comments',1,cfg['severity'],line_no,col+len(pkg_m.group(0)),off,off+len(pkg_m.group(0))))
    decls=[]
    for idx,l in enumerate(lines):
        stripped=l.strip()
        for kind,pat in [('function',r'^func\s+(?:\([^)]*\)\s*)?([A-Za-z_]\w*)\s*\('),('type',r'^type\s+([A-Za-z_]\w*)\b'),('var',r'^var\s+([A-Za-z_]\w*)\b'),('const',r'^const\s+([A-Za-z_]\w*)\b')]:
            m=re.match(pat,stripped)
            if m:
                col=l.find(m.group(1))+1; decls.append((idx,kind,m.group(1),col,l)); break
    for idx,kind,name,col,l in decls:
        line=idx+1; off=offset_of(lines,idx,col)
        if 'exported' in rules and exported(name) and not prior_comment_ok(lines,idx,name):
            report_col = l.find('func') + 1 if kind == 'function' else col
            report_off = offset_of(lines, idx, report_col)
            fs.append(Finding(short,line,report_col,f'exported {kind} {name} should have comment or be unexported','exported',1,cfg['severity'],line,col+len(name)+1,report_off,off+len(l)))
        if 'var-naming' in rules and '_' in name and not (name.startswith('_') or name=='_'):
            what = 'func' if kind=='function' else kind
            fs.append(Finding(short,line,col,f"don't use underscores in Go names; {what} {name} should be {go_name(name)}",'var-naming',0.9,cfg['severity'],line,col+len(name),off,off+len(name)))
    if 'line-length-limit' in rules and cfg.get('line_length'):
        lim=cfg['line_length']
        for i,l in enumerate(lines, start=1):
            s=l.rstrip('\n')
            if len(s)>lim:
                fs.append(Finding(short,i,lim+1,f'line is {len(s)} characters','line-length-limit',1,cfg['severity']))
    da,dr,na,nr=disabled_lines(lines)
    return [f for f in fs if f.conf >= cfg['confidence'] and not is_disabled(f,da,dr,na,nr)]

def sort_findings(fs): return sorted(fs, key=lambda f:(f.path,f.line,f.col,f.rule,f.msg))

def fmt_default(fs):
    for f in sort_findings(fs): print(f'{f.path}:{f.line}:{f.col}: {f.msg}')

def fmt_plain(fs):
    for f in sort_findings(fs): print(f'{f.path}:{f.line}:{f.col}: {f.msg} https://revive.run/r#{f.rule}')
    if fs: print()

def fmt_unix(fs):
    for f in sort_findings(fs): print(f'{f.path}:{f.line}:{f.col}: [{f.rule}] {f.msg}')
    if fs: print()

def fmt_json(fs): print(json.dumps([f.obj() for f in fs], separators=(',',':')) if fs else 'null')

def fmt_ndjson(fs):
    for f in fs: print(json.dumps(f.obj(), separators=(',',':')))

def fmt_friendly(fs):
    for f in sort_findings(fs):
        print(f'  \u26a0  https://revive.run/r#{f.rule}  {f.msg}')
        print(f'  {f.path}:{f.line}:{f.col}\n')
    if fs:
        print(f'\u26a0 {len(fs)} problems (0 errors, {len(fs)} warnings)\n')
        counts={}
        for f in fs: counts[f.rule]=counts.get(f.rule,0)+1
        print('Warnings:')
        for r,c in sorted(counts.items(), key=lambda x:(-x[1],x[0])): print(f'  {c}  {r}')
        print()

def fmt_stylish(fs):
    by={}
    for f in sort_findings(fs): by.setdefault(f.path,[]).append(f)
    for p,items in by.items():
        print(p)
        for f in items:
            print(f'  ({f.line}, {f.col})  https://revive.run/r#{f.rule:<16}  {f.msg}')
        print()
    if fs: print(f' \u2716 {len(fs)} problems (0 errors) ({len(fs)} warnings)')

def fmt_checkstyle(fs):
    print("<?xml version='1.0' encoding='UTF-8'?>")
    print('<checkstyle version="5.0">')
    by={}
    for f in sort_findings(fs): by.setdefault(f.path,[]).append(f)
    for p,items in by.items():
        print(f'    <file name="{html.escape(p)}">')
        for f in items:
            msg=html.escape(f'{f.msg} (confidence {f.conf:g})', quote=True)
            print(f'      <error line="{f.line}" column="{f.col}" message="{msg}" severity="{f.severity}" source="revive/{f.rule}"/>')
        print('    </file>')
    print('</checkstyle>')

def fmt_sarif(fs):
    results=[{"ruleId":f.rule,"level":"warning" if f.severity!='error' else 'error',"message":{"text":f.msg},"locations":[{"physicalLocation":{"artifactLocation":{"uri":f.path},"region":{"startLine":f.line,"startColumn":f.col}}}]} for f in fs]
    print(json.dumps({"version":"2.1.0","runs":[{"tool":{"driver":{"name":"revive"}},"results":results}]}, separators=(',',':')))

def main():
    opts=parse_args(sys.argv[1:])
    if opts.get('help'):
        usage(); return 0
    if opts['version']:
        print(VERSION); return 0
    fmts={'default':fmt_default,'plain':fmt_plain,'unix':fmt_unix,'json':fmt_json,'ndjson':fmt_ndjson,'friendly':fmt_friendly,'stylish':fmt_stylish,'checkstyle':fmt_checkstyle,'sarif':fmt_sarif}
    if opts['formatter'] not in fmts:
        print(f'formatting - getting formatter: unknown formatter {opts["formatter"]}')
        return 1
    cfg=parse_config(opts['config'])
    findings=[]
    for f in collect_files(opts['packages'], opts['exclude']): findings.extend(lint_file(f,cfg))
    if opts['formatter'] in ('json','ndjson','checkstyle','sarif'): findings=sort_findings(findings)
    fmts[opts['formatter']](findings)
    return 1 if (opts['set_exit_status'] and findings) else 0

if __name__=='__main__': sys.exit(main())
