#!/usr/bin/env python3
import csv
import fnmatch
import json
import os
import re
import sys

HELP = """trdsql - Execute SQL queries on CSV, LTSV, JSON, YAML and TBLN.

Usage
\ttrdsql [OPTIONS] [SQL(SELECT...)]

Options:
  -A string           analyze the file but only suggest SQL.
  -a string           analyze the file and suggest SQL.
  -config string      configuration file location.
  -db string          specify db name of the setting.
  -dblist             display db information.
  -debug              debug print.
  -driver string      database driver.  [ mysql | postgres | sqlite3 | sqlite3_ext ]
  -dsn string         database driver specific data source name.
  -help               display usage information.
  -q string           read query from the specified file.
  -t string           read table name from the specified file.
  -version            display version information.

Input Formats:
  -icsv               CSV format for input.
  -ig                 guess format from extension. (default "true")
  -ijson              JSON format for input.
  -iltsv              LTSV format for input.
  -itbln              TBLN format for input.
  -itext              text format for input.
  -iwidth             width specification format for input.
  -iyaml              YAML format for input.

Input options:
  -id string          field delimiter for input. (default ",")
  -ih                 the first line is interpreted as column names(CSV only).
  -ijq string         jq expression string for input(JSON/JSONL only).
  -ilr int            limited number of rows to read. (default 0)
  -inull value        value(string) to convert to null on input.
  -inum               add row number column.
  -ir int             number of rows to preread. (default 1)
  -is int             skip header row. (default 0)

Output Formats:
  -oat                ASCII Table format for output.
  -ocsv               CSV format for output.
  -ojson              JSON format for output.
  -ojsonl             JSON lines format for output.
  -oltsv              LTSV format for output.
  -omd                Markdown format for output.
  -oraw               Raw format for output.
  -otbln              TBLN format for output.
  -ovf                Vertical format for output.
  -oyaml              YAML format for output.

Output options:
  -oaq                enclose all fields in quotes for output.
  -ocrlf              use CRLF for output. End each output line with '\\r\\n' instead of '\\n'.
  -od string          field delimiter for output. (default ",")
  -oh                 output column name as header.
  -onowrap            do not wrap long lines(at/md only).
  -onull value        value(string) to convert from null on output.
  -oq string          quote character for output. (default "\\"")
  -out string         output file name.
  -out-without-guess  output without guessing (when using -out).
  -oz string          output compression format. [ gz | bz2 | zstd | lz4 | xz ]

Examples:
  $ trdsql "SELECT c1,c2 FROM test.csv"
  $ trdsql -oltsv "SELECT c1,c2 FROM test.json::.items"
  $ cat test.csv | trdsql -icsv -oltsv "SELECT c1,c2 FROM -"
"""


class Opts:
    def __init__(self):
        self.infmt = None
        self.outfmt = "csv"
        self.idel = ","
        self.odel = ","
        self.ih = False
        self.oh = False
        self.oaq = False
        self.crlf = False
        self.inull = None
        self.onull = ""
        self.inum = False
        self.skip = 0
        self.ilr = 0
        self.query_file = None
        self.table = None
        self.out = None
        self.ijq = None
        self.analyze = None
        self.analyze_only = False


def parse_args(argv):
    o = Opts()
    sql_parts = []
    i = 0
    while i < len(argv):
        a = argv[i]
        if a in ("-help", "--help", "-h"):
            print(HELP, end="")
            sys.exit(0)
        if a == "-version":
            print("trdsql version devel")
            sys.exit(0)
        if a == "-dblist":
            sys.exit(0)
        if a in ("-icsv", "-ijson", "-iltsv", "-itext", "-itbln", "-iwidth", "-iyaml"):
            o.infmt = a[2:]
        elif a in ("-ocsv", "-ojson", "-ojsonl", "-oltsv", "-omd", "-oat", "-oraw", "-otbln", "-ovf", "-oyaml"):
            o.outfmt = a[2:]
            if o.outfmt == "vf":
                o.outfmt = "ovf"
        elif a == "-ih":
            o.ih = True
        elif a == "-oh":
            o.oh = True
        elif a == "-oaq":
            o.oaq = True
        elif a == "-ocrlf":
            o.crlf = True
        elif a == "-inum":
            o.inum = True
        elif a in ("-id", "-od", "-q", "-t", "-out", "-inull", "-onull", "-is", "-ilr", "-ijq", "-a", "-A", "-config", "-db", "-driver", "-dsn", "-oq", "-oz", "-ir"):
            if i + 1 >= len(argv):
                die("flag needs an argument: " + a)
            v = argv[i + 1]
            i += 1
            if a == "-id":
                o.idel = v
            elif a == "-od":
                o.odel = v
            elif a == "-q":
                o.query_file = v
            elif a == "-t":
                o.table = v
            elif a == "-out":
                o.out = v
            elif a == "-inull":
                o.inull = v
            elif a == "-onull":
                o.onull = v
            elif a == "-is":
                o.skip = int(v)
            elif a == "-ilr":
                o.ilr = int(v)
            elif a == "-ijq":
                o.ijq = v
            elif a == "-a":
                o.analyze = v
            elif a == "-A":
                o.analyze = v
                o.analyze_only = True
        elif a in ("-ig", "-debug", "-onowrap", "-out-without-guess"):
            pass
        elif a.startswith("-"):
            pass
        else:
            sql_parts.append(a)
        i += 1
    if o.query_file:
        sql = open(o.query_file, encoding="utf-8").read().strip()
    else:
        sql = " ".join(sql_parts).strip()
    return o, sql


def die(msg, code=1):
    print(msg, file=sys.stderr)
    sys.exit(code)


def split_csv_expr(s):
    out, cur, depth, quote = [], "", 0, None
    i = 0
    while i < len(s):
        c = s[i]
        if quote:
            cur += c
            if c == quote:
                quote = None
        elif c in ("'", '"', "`"):
            quote = c
            cur += c
        elif c == "(":
            depth += 1
            cur += c
        elif c == ")":
            depth -= 1
            cur += c
        elif c == "," and depth == 0:
            out.append(cur.strip())
            cur = ""
        else:
            cur += c
        i += 1
    if cur.strip() or s.strip() == "":
        out.append(cur.strip())
    return out


def split_words(s):
    return re.findall(r"`[^`]*`|'[^']*'|\"[^\"]*\"|\S+", s)


def unquote(s):
    s = s.strip()
    if len(s) >= 2 and s[0] == s[-1] and s[0] in "'\"`":
        return s[1:-1]
    return s


def parse_sql(sql, opts):
    if not sql and opts.table:
        return {"select": ["*"], "table": opts.table, "where": None, "group": None, "order": None, "limit": None, "offset": 0, "distinct": False}
    m = re.match(r"(?is)^\s*select\s+(.*?)\s+from\s+(.+?)\s*$", sql)
    if not m:
        if opts.table:
            return {"select": ["*"], "table": opts.table, "where": None, "group": None, "order": None, "limit": None, "offset": 0, "distinct": False}
        die("syntax error")
    sel = m.group(1).strip()
    rest = m.group(2).strip()
    distinct = False
    if re.match(r"(?is)^distinct\b", sel):
        distinct = True
        sel = re.sub(r"(?is)^distinct\b", "", sel).strip()
    keys = [" where ", " group by ", " order by ", " limit "]
    lower = " " + rest.lower()
    positions = [(lower.find(k), k.strip()) for k in keys if lower.find(k) >= 0]
    positions.sort()
    table_end = positions[0][0] - 1 if positions else len(rest)
    table = unquote(rest[:table_end].strip())
    tail = rest[table_end:].strip()
    parts = {"where": None, "group": None, "order": None, "limit": None, "offset": 0}
    patterns = [("where", r"(?is)\bwhere\b\s+"), ("group", r"(?is)\bgroup\s+by\b\s+"), ("order", r"(?is)\border\s+by\b\s+"), ("limit", r"(?is)\blimit\b\s+")]
    found = []
    for name, pat in patterns:
        mm = re.search(pat, tail)
        if mm:
            found.append((mm.start(), mm.end(), name))
    found.sort()
    for idx, (st, en, name) in enumerate(found):
        end = found[idx + 1][0] if idx + 1 < len(found) else len(tail)
        parts[name] = tail[en:end].strip()
    if parts["limit"]:
        toks = parts["limit"].split()
        if toks:
            try:
                parts["limit"] = int(toks[0])
            except ValueError:
                parts["limit"] = None
            if "offset" in [t.lower() for t in toks]:
                oi = [t.lower() for t in toks].index("offset")
                if oi + 1 < len(toks):
                    parts["offset"] = int(toks[oi + 1])
    return {"select": split_csv_expr(sel), "table": table, "distinct": distinct, **parts}


def table_source(t):
    if "::" in t:
        p, jq = t.split("::", 1)
        return p, jq
    return t, None


def read_rows(path, opts, jq=None):
    if opts.ijq and not jq:
        jq = opts.ijq
    fmt = opts.infmt
    clean_path = path
    if path == "-":
        data = sys.stdin.read()
    else:
        clean_path = path
        data = open(clean_path, encoding="utf-8", newline="").read()
    if not fmt:
        ext = os.path.splitext(clean_path)[1].lower()
        fmt = {" .csv": "csv"}.get(ext, None)
        if ext in (".json", ".jsonl", ".ndjson"):
            fmt = "json"
        elif ext == ".ltsv":
            fmt = "ltsv"
        elif ext in (".txt", ".log"):
            fmt = "csv"
        else:
            fmt = "csv"
    if fmt == "json":
        headers, rows = read_json(data, jq)
    elif fmt == "ltsv":
        headers, rows = read_ltsv(data)
    elif fmt == "text":
        lines = data.splitlines()
        headers = ["c1"]
        rows = [{"c1": ln} for ln in lines]
    else:
        headers, rows = read_csv(data, opts)
    if opts.skip:
        rows = rows[opts.skip:]
    if opts.ilr:
        rows = rows[:opts.ilr]
    if opts.inum:
        headers = ["n"] + headers
        rows = [dict({"n": str(i + 1)}, **r) for i, r in enumerate(rows)]
    return headers, rows


def read_csv(data, opts):
    rdr = csv.reader(data.splitlines(), delimiter=opts.idel)
    raw = list(rdr)
    if not raw:
        return [], []
    if opts.ih:
        headers = [str(x) for x in raw[0]]
        recs = raw[1:]
    else:
        width = max(len(r) for r in raw)
        headers = [f"c{i+1}" for i in range(width)]
        recs = raw
    rows = []
    for rec in recs:
        row = {}
        for i, h in enumerate(headers):
            v = rec[i] if i < len(rec) else ""
            row[h] = None if opts.inull is not None and v == opts.inull else v
        rows.append(row)
    return headers, rows


def read_json(data, jq):
    data = data.strip()
    try:
        obj = json.loads(data)
    except Exception:
        obj = [json.loads(ln) for ln in data.splitlines() if ln.strip()]
    if jq:
        obj = apply_jq(obj, jq)
    if isinstance(obj, dict):
        if len(obj) == 1 and isinstance(next(iter(obj.values())), list):
            obj = next(iter(obj.values()))
        else:
            obj = [obj]
    rows, headers = [], []
    for item in obj if isinstance(obj, list) else [obj]:
        if not isinstance(item, dict):
            item = {"c1": item}
        row = {}
        for k, v in item.items():
            if k not in headers:
                headers.append(k)
            row[k] = "" if v is None else str(v)
        rows.append(row)
    return headers, rows


def apply_jq(obj, jq):
    s = jq.strip()
    if s.startswith("."):
        parts = [p for p in s[1:].split(".") if p]
        cur = obj
        for p in parts:
            if p.endswith("[]"):
                p = p[:-2]
            if isinstance(cur, dict):
                cur = cur.get(p, [])
        return cur
    return obj


def read_ltsv(data):
    headers, rows = [], []
    for ln in data.splitlines():
        if not ln:
            continue
        row = {}
        for part in ln.split("\t"):
            if ":" in part:
                k, v = part.split(":", 1)
                if k not in headers:
                    headers.append(k)
                row[k] = v
        rows.append(row)
    return headers, rows


def to_num(v):
    try:
        f = float(v)
        return int(f) if f.is_integer() else f
    except Exception:
        return None


def value(row, expr):
    expr = expr.strip()
    if re.match(r"(?is)^cast\s*\(", expr):
        mm = re.match(r"(?is)^cast\s*\((.+?)\s+as\s+\w+\s*\)$", expr)
        return to_num(value(row, mm.group(1))) if mm else ""
    mfun = re.match(r"(?is)^(upper|lower|trim|length)\s*\((.*)\)$", expr)
    if mfun:
        v = str(value(row, mfun.group(2)))
        fn = mfun.group(1).lower()
        return {"upper": v.upper(), "lower": v.lower(), "trim": v.strip(), "length": len(v)}[fn]
    if len(expr) >= 2 and expr[0] == expr[-1] and expr[0] in "'\"":
        return expr[1:-1]
    if re.match(r"^-?\d+(\.\d+)?$", expr):
        return to_num(expr)
    for op in ["+", "-", "*", "/"]:
        parts = split_op(expr, op)
        if parts:
            a, b = value(row, parts[0]), value(row, parts[1])
            an, bn = to_num(a), to_num(b)
            if an is None or bn is None:
                return str(a) + str(b) if op == "+" else ""
            return {"+": an + bn, "-": an - bn, "*": an * bn, "/": an / bn if bn != 0 else None}[op]
    return row.get(unquote(expr), "")


def split_op(expr, op):
    depth = 0
    for i, c in enumerate(expr):
        if c == "(":
            depth += 1
        elif c == ")":
            depth -= 1
        elif c == op and depth == 0 and i > 0:
            return expr[:i], expr[i + 1:]
    return None


def truth(row, cond):
    if not cond:
        return True
    parts = re.split(r"(?is)\s+or\s+", cond, maxsplit=1)
    if len(parts) == 2:
        return truth(row, parts[0]) or truth(row, parts[1])
    parts = re.split(r"(?is)\s+and\s+", cond, maxsplit=1)
    if len(parts) == 2:
        return truth(row, parts[0]) and truth(row, parts[1])
    m = re.match(r"(?is)^\s*(.*?)\s+(not\s+like|like)\s+(.*?)\s*$", cond)
    if m:
        left = str(value(row, m.group(1)))
        pat = str(value(row, m.group(3))).replace("%", "*").replace("_", "?")
        ok = fnmatch.fnmatch(left, pat)
        return not ok if m.group(2).lower().startswith("not") else ok
    m = re.match(r"(?is)^\s*(.*?)\s+(not\s+in|in)\s*\((.*?)\)\s*$", cond)
    if m:
        left = value(row, m.group(1))
        vals = [value(row, p) for p in split_csv_expr(m.group(3))]
        ok = any(str(left) == str(v) for v in vals)
        return not ok if m.group(2).lower().startswith("not") else ok
    m = re.match(r"(?is)^\s*(.*?)\s*(<=|>=|<>|!=|=|<|>)\s*(.*?)\s*$", cond)
    if not m:
        return bool(value(row, cond))
    a, op, b = value(row, m.group(1)), m.group(2), value(row, m.group(3))
    an, bn = to_num(a), to_num(b)
    if an is not None and bn is not None:
        a, b = an, bn
    else:
        a, b = str(a), str(b)
    return {"=": a == b, "!=": a != b, "<>": a != b, "<": a < b, ">": a > b, "<=": a <= b, ">=": a >= b}[op]


def expr_alias(expr):
    m = re.match(r"(?is)^(.+?)\s+as\s+([A-Za-z_][\w]*)$", expr)
    if m:
        return m.group(1).strip(), m.group(2)
    m = re.match(r"(?is)^(.+?)\s+([A-Za-z_][\w]*)$", expr.strip())
    if m and not is_agg(expr.strip()):
        left = m.group(1).strip()
        if left and left.lower() not in ("case", "when"):
            return left, m.group(2)
    return expr, expr


def is_agg(expr):
    return re.match(r"(?is)^(count|sum|avg|min|max)\s*\(", expr.strip()) is not None


def agg_value(rows, expr):
    m = re.match(r"(?is)^(count|sum|avg|min|max)\s*\((.*?)\)$", expr.strip())
    if not m:
        return ""
    fn, inner = m.group(1).lower(), m.group(2).strip()
    if fn == "count":
        return len(rows) if inner == "*" else sum(1 for r in rows if value(r, inner) not in ("", None))
    vals = [value(r, inner) for r in rows]
    nums = [to_num(v) for v in vals if to_num(v) is not None]
    if fn == "sum":
        return sum(nums)
    if fn == "avg":
        return sum(nums) / len(nums) if nums else None
    if fn == "min":
        return min(nums if nums else vals) if vals else None
    if fn == "max":
        return max(nums if nums else vals) if vals else None


def execute(plan, headers, rows):
    rows = [r for r in rows if truth(r, plan.get("where"))]
    select = plan["select"]
    order = plan.get("order")
    if order and not plan.get("group") and not any(is_agg(expr_alias(e)[0]) for e in select):
        parts = split_words(order)
        key = unquote(parts[0].rstrip(",")) if parts else ""
        rev = len(parts) > 1 and parts[1].lower() == "desc"
        rows.sort(key=lambda r: (to_num(value(r, key)) if to_num(value(r, key)) is not None else str(value(r, key))), reverse=rev)
    if select == ["*"]:
        out_headers = headers[:]
        out_rows = [{h: r.get(h, "") for h in out_headers} for r in rows]
    else:
        exprs = [expr_alias(e) for e in select]
        if plan.get("group"):
            groups = {}
            gexprs = split_csv_expr(plan["group"])
            for r in rows:
                key = tuple(value(r, g) for g in gexprs)
                groups.setdefault(key, []).append(r)
            rows_for_select = [g[0] for g in groups.values()]
            group_rows = list(groups.values())
        elif any(is_agg(e[0]) for e in exprs):
            rows_for_select = [rows[0] if rows else {}]
            group_rows = [rows]
        else:
            rows_for_select = rows
            group_rows = [[r] for r in rows]
        out_headers = [a for _, a in exprs]
        out_rows = []
        for r, grows in zip(rows_for_select, group_rows):
            out = {}
            for e, a in exprs:
                out[a] = agg_value(grows, e) if is_agg(e) else value(r, e)
            out_rows.append(out)
    if plan.get("distinct"):
        seen, nr = set(), []
        for r in out_rows:
            key = tuple(r.get(h, "") for h in out_headers)
            if key not in seen:
                seen.add(key)
                nr.append(r)
        out_rows = nr
    if plan.get("order"):
        parts = split_words(plan["order"])
        key = unquote(parts[0].rstrip(",")) if parts else ""
        rev = len(parts) > 1 and parts[1].lower() == "desc"
        if key in out_headers:
            out_rows.sort(key=lambda r: (to_num(r.get(key)) if to_num(r.get(key)) is not None else str(r.get(key, ""))), reverse=rev)
    off = plan.get("offset") or 0
    lim = plan.get("limit")
    if lim is not None:
        out_rows = out_rows[off:off + lim]
    elif off:
        out_rows = out_rows[off:]
    return out_headers, out_rows


def fmtv(v, opts):
    if v is None:
        return opts.onull
    if isinstance(v, float) and v.is_integer():
        return str(int(v))
    return str(v)


def render(headers, rows, opts):
    if opts.outfmt == "json":
        return json.dumps([{h: fmtv(r.get(h, ""), opts) for h in headers} for r in rows], indent=2) + "\n"
    if opts.outfmt == "jsonl":
        return "".join(json.dumps({h: fmtv(r.get(h, ""), opts) for h in headers}, separators=(",", ":")) + "\n" for r in rows)
    if opts.outfmt == "ltsv":
        return "".join("\t".join(f"{h}:{fmtv(r.get(h, ''), opts)}" for h in headers) + "\n" for r in rows)
    if opts.outfmt in ("md", "at"):
        data = [[fmtv(r.get(h, ""), opts) for h in headers] for r in rows]
        widths = [len(h) for h in headers]
        for rec in data:
            widths = [max(w, len(v)) for w, v in zip(widths, rec)]
        if opts.outfmt == "md":
            out = ["| " + " | ".join(headers) + " |", "|" + "|".join("-" * (len(h) + 2) for h in headers) + "|"]
            out += ["| " + " | ".join(rec) + " |" for rec in data]
            return "\n".join(out) + "\n"
        border = "+" + "+".join("-" * (w + 2) for w in widths) + "+"
        out = [border, "| " + " | ".join(h.ljust(widths[i]) for i, h in enumerate(headers)) + " |", border]
        out += ["| " + " | ".join(rec[i].ljust(widths[i]) for i in range(len(headers))) + " |" for rec in data]
        out.append(border)
        return "\n".join(out) + "\n"
    if opts.outfmt == "ovf":
        out = []
        for i, r in enumerate(rows, 1):
            out.append(f"---[ {i}]------------------------")
            for h in headers:
                out.append(f"  {h} | {fmtv(r.get(h, ''), opts)}")
        return "\n".join(out) + ("\n" if out else "")
    if opts.outfmt == "yaml":
        out = []
        for r in rows:
            for j, h in enumerate(headers):
                prefix = "- " if j == 0 else "  "
                out.append(f"{prefix}{h}: {fmtv(r.get(h, ''), opts)}")
        return "\n".join(out) + ("\n" if out else "")
    if opts.outfmt == "raw":
        return "".join(write_csv_line([fmtv(r.get(h, ""), opts) for h in headers], opts) for r in rows)
    if opts.outfmt == "tbln":
        out = ["; name: | " + " | ".join(headers) + " |", "; type: | " + " | ".join(["text"] * len(headers)) + " |"]
        out += ["| " + " | ".join(fmtv(r.get(h, ""), opts) for h in headers) + " |" for r in rows]
        return "\n".join(out) + ("\n" if out else "")
    sio = []
    if opts.oh:
        sio.append(write_csv_line(headers, opts))
    for r in rows:
        sio.append(write_csv_line([fmtv(r.get(h, ""), opts) for h in headers], opts))
    return "".join(sio)


def write_csv_line(vals, opts):
    import io
    s = io.StringIO()
    quoting = csv.QUOTE_ALL if opts.oaq else csv.QUOTE_MINIMAL
    w = csv.writer(s, delimiter=opts.odel, lineterminator="\n", quoting=quoting)
    w.writerow(vals)
    return s.getvalue()


def analyze(path, opts):
    headers, rows = read_rows(path, opts)
    sample = rows[0] if rows else {h: "" for h in headers}
    prefix = " -ih" if opts.ih else ""
    cols = ", ".join(headers)
    first = headers[0] if headers else "c1"
    lines = []
    if not opts.analyze_only:
        lines += [
            f"The table name is {path}.",
            "The file type is CSV.",
            "",
            "Data types:",
        ]
        type_rows = [{"column name": h, "type": "text"} for h in headers]
        lines.append(render(["column name", "type"], type_rows, type("O", (), {"outfmt": "at", "onull": "", "oh": False, "oaq": False, "odel": ","})()).rstrip())
        lines += ["", "Data samples:"]
        lines.append(render(headers, [sample], type("O", (), {"outfmt": "at", "onull": "", "oh": False, "oaq": False, "odel": ","})()).rstrip())
        lines += ["", "Examples:"]
    exe = sys.argv[0]
    val = sample.get(first, "")
    lines += [
        f'{exe}{prefix} "SELECT {cols} FROM {path}"',
        f'{exe}{prefix} "SELECT {cols} FROM {path} WHERE {first} = \'{val}\'"',
        f'{exe}{prefix} "SELECT {first}, count({first}) FROM {path} GROUP BY {first}"',
        f'{exe}{prefix} "SELECT {cols} FROM {path} ORDER BY {first} LIMIT 10"',
    ]
    return "\n".join(lines) + "\n"


def main(argv):
    opts, sql = parse_args(argv)
    if opts.analyze:
        sys.stdout.write(analyze(opts.analyze, opts))
        return 0
    if not sql and not opts.table:
        print(HELP, end="")
        return 0
    if opts.table and not sql:
        plan = parse_sql("", opts)
    else:
        plan = parse_sql(sql, opts)
    path, jq = table_source(plan["table"])
    headers, rows = read_rows(path, opts, jq)
    out_headers, out_rows = execute(plan, headers, rows)
    text = render(out_headers, out_rows, opts)
    if opts.crlf:
        text = text.replace("\n", "\r\n")
    if opts.out:
        open(opts.out, "w", encoding="utf-8", newline="").write(text)
    else:
        sys.stdout.write(text)
    return 0


if __name__ == "__main__":
    try:
        sys.exit(main(sys.argv[1:]))
    except BrokenPipeError:
        pass
    except Exception as e:
        print(str(e), file=sys.stderr)
        sys.exit(1)
