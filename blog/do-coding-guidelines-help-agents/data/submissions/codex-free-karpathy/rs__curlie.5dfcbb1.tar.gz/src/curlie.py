#!/usr/bin/env python3
import json
import os
import subprocess
import sys
from urllib.parse import quote


METHODS = {
    "GET", "POST", "PUT", "PATCH", "DELETE", "HEAD", "OPTIONS", "TRACE", "CONNECT"
}

NO_ARG_SHORT = set("046aefFgGIjklLNnOqRsSuvV")
ARG_SHORT = set("AbBcCDEHhKmoPQrtTuUxYz")
NO_ARG_LONG = {
    "anyauth", "append", "basic", "cert-status", "compressed", "compressed-ssh",
    "create-dirs", "crlf", "digest", "disable", "disable-eprt", "disable-epsv",
    "disallow-username-in-url", "doh-cert-status", "doh-insecure", "fail",
    "fail-early", "fail-with-body", "false-start", "form-escape", "ftp-create-dirs",
    "ftp-pasv", "ftp-pret", "ftp-skip-pasv-ip", "ftp-ssl-control", "get", "globoff",
    "haproxy-protocol", "head", "http0.9", "http1.0", "http1.1", "http2",
    "http2-prior-knowledge", "http3", "ignore-content-length", "include",
    "insecure", "ipv4", "ipv6", "junk-session-cookies", "list-only", "location",
    "location-trusted", "manual", "metalink", "negotiate", "netrc", "netrc-optional",
    "no-alpn", "no-buffer", "no-keepalive", "no-npn", "remote-header-name",
    "remote-name", "remote-name-all", "silent", "show-error", "ssl", "ssl-reqd",
    "ssl-allow-beast", "ssl-no-revoke", "styled-output", "tcp-fastopen",
    "tcp-nodelay", "tlsv1", "tlsv1.0", "tlsv1.1", "tlsv1.2", "tlsv1.3",
    "tr-encoding", "verbose", "version",
}


def eprint(*args):
    print(*args, file=sys.stderr)


def usage():
    print("Usage: ./executable [options...] [METHOD] URL [REQUEST_ITEM [REQUEST_ITEM ...]]")


def curl_help(args):
    category = None
    if len(args) > 1:
        category = args[1]
    curl_args = ["--help", category if category is not None else "__curlie__"]
    try:
        p = subprocess.run(["curl"] + curl_args, text=True, capture_output=True)
        usage()
        out = p.stdout
        lines = out.splitlines(True)
        if lines and lines[0].startswith("Usage: curl"):
            out = "".join(lines[1:])
        sys.stdout.write(out)
        sys.stderr.write(p.stderr)
        return p.returncode
    except FileNotFoundError:
        return 127


def has_scheme(s):
    return "://" in s or s.startswith("localhost:") or s.startswith("127.")


def display_url(url):
    if not url:
        return ""
    if "://" in url:
        return url
    return "http://" + url


def shell_quote(arg):
    if arg == "":
        return '""'
    if any(c.isspace() for c in arg):
        return '"' + arg.replace("\\", "\\\\").replace('"', '\\"') + '"'
    return arg


def parse_json_value(text):
    try:
        return json.loads(text)
    except Exception:
        return None


def compact_json(obj):
    return json.dumps(obj, separators=(",", ":"), ensure_ascii=False)


def option_takes_value(opt):
    if opt == "--":
        return False
    if opt.startswith("--"):
        name = opt[2:].split("=", 1)[0]
        if name in NO_ARG_LONG:
            return False
        if "=" in opt:
            return False
        return True
    if opt.startswith("-") and len(opt) == 2:
        ch = opt[1]
        if ch in NO_ARG_SHORT:
            return False
        if ch in ARG_SHORT:
            return True
    return False


def parse(argv):
    curl_mode = False
    pretty = False
    curl_opts = []
    method = None
    url = None
    headers = []
    data = {}
    queries = []
    passthrough_items = []

    i = 0
    positional = []
    while i < len(argv):
        a = argv[i]
        if a == "--curl":
            curl_mode = True
            i += 1
            continue
        if a == "--pretty":
            pretty = True
            i += 1
            continue
        if a in ("--help", "-h"):
            return {"help": argv[i:]}
        if a in ("--version", "-V"):
            return {"version": True}
        if a.startswith("-") and url is None:
            curl_opts.append(a)
            if option_takes_value(a) and i + 1 < len(argv):
                i += 1
                curl_opts.append(argv[i])
            i += 1
            continue
        positional.append(a)
        i += 1

    if positional and positional[0].upper() in METHODS:
        method = positional.pop(0).upper()
    if positional:
        url = positional.pop(0)

    for item in positional:
        if "==" in item and not item.startswith("=="):
            k, v = item.split("==", 1)
            queries.append((k, v))
        elif ":=" in item and not item.startswith(":="):
            k, v = item.split(":=", 1)
            data[k] = parse_json_value(v)
        elif "=" in item and not item.startswith("="):
            k, v = item.split("=", 1)
            data[k] = v
        elif ":" in item:
            headers.append(item)
        else:
            passthrough_items.append(item)

    if queries and url:
        sep = "&" if "?" in url else "?"
        url += sep + "&".join(quote(k, safe="") + "=" + quote(v, safe="") for k, v in queries)

    return {
        "help": None,
        "version": False,
        "curl_mode": curl_mode,
        "pretty": pretty,
        "curl_opts": curl_opts,
        "method": method,
        "url": url,
        "headers": headers,
        "data": data,
        "passthrough_items": passthrough_items,
    }


def build_curl(spec, for_display=False, include_headers_for_pretty=True):
    cmd = ["curl"]
    cmd.extend(spec["curl_opts"])
    if spec["method"]:
        cmd.extend(["-X", spec["method"]])
    for h in spec["headers"]:
        cmd.extend(["-H", h])
    if spec["data"]:
        cmd.extend(["-d", compact_json(spec["data"])])
    if spec["passthrough_items"]:
        cmd.extend(spec["passthrough_items"])
    if spec["url"]:
        cmd.append(spec["url"])
    cmd.extend(["-s", "-S"])
    if spec["pretty"] and include_headers_for_pretty:
        cmd.append("-v")
    if not spec["data"]:
        cmd.append("-d@-")
    cmd.extend(["-H", "Content-Type: application/json", "-H", "Accept: application/json, */*"])
    return cmd


def color_json_text(text):
    try:
        obj = json.loads(text)
    except Exception:
        return text
    return json.dumps(obj, indent=4, ensure_ascii=False) + "\n"


def run_curl(spec):
    if spec["url"]:
        eprint(display_url(spec["url"]))
    cmd = build_curl(spec)
    if spec["pretty"]:
        cmd = [a for a in cmd if a != "-v"]
        insert_at = 1 + len(spec["curl_opts"])
        cmd[insert_at:insert_at] = ["-D", "-"]
    try:
        p = subprocess.run(cmd, input="", capture_output=True, text=True)
    except FileNotFoundError:
        eprint("curl: not found")
        return 127
    if spec["pretty"]:
        head, sep, body = p.stdout.partition("\r\n\r\n")
        if not sep:
            head, sep, body = p.stdout.partition("\n\n")
        if sep and head.startswith("HTTP/"):
            sys.stderr.write(head + sep)
            sys.stdout.write(color_json_text(body))
        else:
            sys.stdout.write(color_json_text(p.stdout))
    else:
        out = p.stdout
        if "-i" in spec["curl_opts"] or "--include" in spec["curl_opts"]:
            head, sep, body = out.partition("\r\n\r\n")
            if not sep:
                head, sep, body = out.partition("\n\n")
            if sep and head.startswith("HTTP/"):
                out = body
        sys.stdout.write(out)
    sys.stderr.write(p.stderr)
    return p.returncode


def main(argv):
    spec = parse(argv)
    if spec.get("help") is not None:
        return curl_help(spec["help"])
    if spec.get("version"):
        try:
            return subprocess.run(["curl", "--version"]).returncode
        except FileNotFoundError:
            return 127
    if spec.get("curl_mode"):
        if spec.get("url"):
            eprint(display_url(spec["url"]))
        cmd = build_curl(spec)
        print(" ".join(shell_quote(a) for a in cmd))
        return 0
    return run_curl(spec)


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
