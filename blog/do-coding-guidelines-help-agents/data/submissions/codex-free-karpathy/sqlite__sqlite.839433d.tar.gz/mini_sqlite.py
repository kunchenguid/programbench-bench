#!/usr/bin/env python3
import csv
import html
import json
import math
import os
import re
import shlex
import sys
from io import StringIO

VERSION = "3.54.0 2026-04-14 20:02:49 49b3bac482c831f503c7f90c35959e7ea731950e991baba86b2ab95987d2539b (64-bit)"

HELP = """Usage: ./executable [OPTIONS] [FILENAME [SQL...]]
FILENAME is the name of an SQLite database. A new database is created
if the file does not previously exist. Defaults to :memory:.
OPTIONS include:
   --                   treat no subsequent arguments as options
   -A ARGS...           run ".archive ARGS" and exit
   -append              append the database to the end of the file
   -ascii               set output mode to 'ascii'
   -bail                stop after hitting an error
   -batch               force batch I/O
   -box                 set output mode to 'box'
   -cmd COMMAND         run "COMMAND" before reading stdin
   -column              set output mode to 'column'
   -csv                 set output mode to 'csv'
   -deserialize         open the database using sqlite3_deserialize()
   -echo                print inputs before execution
   -escape T            ctrl-char escape; T is one of: symbol, ascii, off
   -init FILENAME       read/process named file
   -[no]header          turn headers on or off
   -help                show this message
   -html                set output mode to HTML
   -ifexists            only open if database already exists
   -interactive         force interactive I/O
   -json                set output mode to 'json'
   -line                set output mode to 'line'
   -list                set output mode to 'list'
   -lookaside SIZE N    use N entries of SZ bytes for lookaside memory
   -markdown            set output mode to 'markdown'
   -maxsize N           maximum size for a --deserialize database
   -memtrace            trace all memory allocations and deallocations
   -mmap N              default mmap size set to N
   -newline SEP         set output row separator. Default: '\\n'
   -nofollow            refuse to open symbolic links to database files
   -noinit              Do not read the ~/.sqliterc file at startup
   -nonce STRING        set the safe-mode escape nonce
   -no-rowid-in-view    Disable rowid-in-view using sqlite3_config()
   -nullvalue TEXT      set text string for NULL values. Default ''
   -pagecache SIZE N    use N slots of SZ bytes each for page cache memory
   -pcachetrace         trace all page cache operations
   -quote               set output mode to 'quote'
   -readonly            open the database read-only
   -safe                enable safe-mode
   -screenwidth N       use N as the default screenwidth 
   -separator SEP       set output column separator. Default: '|'
   -stats               print memory stats before each finalize
   -table               set output mode to 'table'
   -tabs                set output mode to 'tabs'
   -unsafe-testing      allow unsafe commands and modes for testing
   -version             show SQLite version
   -vfs NAME            use NAME as the default VFS
   -vfstrace            enable tracing of all VFS calls
   -zip                 open the file as a ZIP Archive"""

HELP_DOT = """.archive ...             Manage SQL archives
.backup ?DB? FILE        Backup DB (default "main") to FILE
.bail on|off             Stop after hitting an error.  Default OFF
.cd DIRECTORY            Change the working directory to DIRECTORY
.changes on|off          Show number of rows changed by SQL
.databases               List names and files of attached databases
.dump ?OBJECTS?          Render database content as SQL
.echo on|off             Turn command echo on or off
.exit ?CODE?             Exit this program with return-code CODE
.headers on|off          Turn display of headers on or off
.help ?-all? ?PATTERN?   Show help text for PATTERN
.import FILE TABLE       Import data from FILE into TABLE
.indexes ?PATTERN?       Show names of indexes matching PATTERN
.mode ?MODE? ?OPTIONS?   Set output mode
.nullvalue STRING        Use STRING in place of NULL values
.once ?OPTIONS? ?FILE?   Output for the next SQL command only to FILE
.open ?OPTIONS? ?FILE?   Close existing database and reopen FILE
.output ?FILE?           Send output to FILE or stdout if FILE is omitted
.print STRING...         Print literal STRING
.quit                    Stop interpreting input stream, exit if primary.
.read FILE               Read input from FILE or command output
.schema ?PATTERN?        Show the CREATE statements matching PATTERN
.separator COL ?ROW?     Change the column and row separators
.shell CMD ARGS...       Run CMD ARGS... in a system shell
.show                    Show current settings
.tables ?TABLE?          List names of tables matching LIKE pattern TABLE
.version                 Show source, library and compiler versions"""


def split_top(s, sep=","):
    out, cur, quote, depth = [], [], None, 0
    i = 0
    while i < len(s):
        c = s[i]
        if quote:
            cur.append(c)
            if c == quote:
                if i + 1 < len(s) and s[i + 1] == quote:
                    cur.append(s[i + 1]); i += 1
                else:
                    quote = None
        elif c in "'\"":
            quote = c; cur.append(c)
        elif c == "(":
            depth += 1; cur.append(c)
        elif c == ")":
            depth -= 1; cur.append(c)
        elif c == sep and depth == 0:
            out.append("".join(cur).strip()); cur = []
        else:
            cur.append(c)
        i += 1
    out.append("".join(cur).strip())
    return out


def split_sql(text):
    out, cur, quote = [], [], None
    i = 0
    while i < len(text):
        c = text[i]
        if quote:
            cur.append(c)
            if c == quote:
                if i + 1 < len(text) and text[i + 1] == quote:
                    cur.append(text[i + 1]); i += 1
                else:
                    quote = None
        elif c in "'\"":
            quote = c; cur.append(c)
        elif c == ";":
            st = "".join(cur).strip()
            if st:
                out.append(st)
            cur = []
        else:
            cur.append(c)
        i += 1
    st = "".join(cur).strip()
    if st:
        out.append(st)
    return out


def unquote_ident(s):
    s = s.strip()
    if len(s) >= 2 and s[0] in "'\"`[":
        return s[1:-1 if s[0] != "[" else None].rstrip("]")
    return s


def sql_string(v):
    if v is None:
        return "NULL"
    if isinstance(v, bool):
        return "1" if v else "0"
    if isinstance(v, (int, float)) and not isinstance(v, bool):
        return str(v)
    return "'" + str(v).replace("'", "''") + "'"


class DB:
    def __init__(self, path):
        self.path = path
        self.tables = {}
        if path != ":memory:" and os.path.exists(path) and os.path.getsize(path):
            try:
                with open(path, "r", encoding="utf-8") as f:
                    data = json.load(f)
                if data.get("format") == "mini-sqlite-json":
                    self.tables = data.get("tables", {})
            except Exception:
                self.tables = {}

    def save(self):
        if self.path == ":memory:":
            return
        with open(self.path, "w", encoding="utf-8") as f:
            json.dump({"format": "mini-sqlite-json", "tables": self.tables}, f)


class Shell:
    def __init__(self, db):
        self.db = db
        self.mode = "list"
        self.headers = False
        self.sep = "|"
        self.rowsep = "\n"
        self.null = ""
        self.echo = False
        self.bail = False
        self.out = sys.stdout
        self.once = None
        self.changed = 0

    def emit(self, s=""):
        print(s, file=self.out)

    def value_to_text(self, v, quote=False):
        if quote:
            return sql_string(v)
        if v is None:
            return self.null
        if isinstance(v, bool):
            return "1" if v else "0"
        return str(v)

    def output_rows(self, cols, rows):
        out = self.out
        if self.once:
            out = open(self.once, "w", encoding="utf-8", newline="")
            self.once = None
        old = self.out
        self.out = out
        try:
            if self.mode in ("list", "ascii"):
                if self.headers:
                    self.emit(self.sep.join(cols))
                for r in rows:
                    self.emit(self.sep.join(self.value_to_text(v) for v in r))
            elif self.mode == "tabs":
                if self.headers:
                    self.emit("\t".join(cols))
                for r in rows:
                    self.emit("\t".join(self.value_to_text(v) for v in r))
            elif self.mode == "csv":
                w = csv.writer(self.out, lineterminator="\r\n")
                if self.headers:
                    w.writerow(cols)
                for r in rows:
                    w.writerow(["" if v is None else v for v in r])
            elif self.mode == "json":
                arr = []
                for r in rows:
                    arr.append({cols[i]: r[i] for i in range(len(cols))})
                self.emit(json.dumps(arr, separators=(",", ":")))
            elif self.mode == "line":
                for r in rows:
                    for c, v in zip(cols, r):
                        self.emit(f"{c} = {self.value_to_text(v)}" if False else f"{c}: {self.value_to_text(v)}")
                    if len(rows) > 1:
                        self.emit()
            elif self.mode == "quote":
                if self.headers:
                    self.emit(",".join(sql_string(c) for c in cols))
                for r in rows:
                    self.emit(",".join(self.value_to_text(v, True) for v in r))
            elif self.mode == "html":
                self.emit("<TR>")
                for c in cols:
                    self.emit("<TH>" + html.escape(c))
                self.emit("</TR>")
                for r in rows:
                    self.emit("<TR>")
                    for v in r:
                        self.emit("<TD>" + ("null" if v is None else html.escape(str(v))))
                    self.emit("</TR>")
            elif self.mode in ("column", "table", "box", "markdown"):
                self.print_table(cols, rows)
            else:
                for r in rows:
                    self.emit(self.sep.join(self.value_to_text(v) for v in r))
        finally:
            self.out = old
            if out is not old:
                out.close()

    def print_table(self, cols, rows):
        data = [[self.value_to_text(v) for v in r] for r in rows]
        widths = [len(c) for c in cols]
        for r in data:
            for i, v in enumerate(r):
                widths[i] = max(widths[i], len(v))
        def fmt(vals):
            return [str(vals[i]).rjust(widths[i]) if str(vals[i]).replace(".", "", 1).isdigit() else str(vals[i]).ljust(widths[i]) for i in range(len(widths))]
        if self.mode == "column":
            if self.headers:
                self.emit("  ".join(fmt(cols)))
                self.emit("  ".join("-" * w for w in widths))
            for r in data:
                self.emit("  ".join(fmt(r)))
        elif self.mode == "markdown":
            self.emit("| " + " | ".join(fmt(cols)) + " |")
            self.emit("|" + "|".join("-" * (w + 2) for w in widths) + "|")
            for r in data:
                self.emit("| " + " | ".join(fmt(r)) + " |")
        else:
            border = "+" + "+".join("-" * (w + 2) for w in widths) + "+"
            self.emit(border)
            self.emit("| " + " | ".join(fmt(cols)) + " |")
            self.emit(border)
            for r in data:
                self.emit("| " + " | ".join(fmt(r)) + " |")
            self.emit(border)

    def run_input(self, text, command_line=False):
        rc = 0
        if not command_line:
            buf = []
            for line in text.splitlines():
                if self.echo:
                    self.emit(line)
                if not buf and line.lstrip().startswith("."):
                    try:
                        if self.dot(line.strip()) == "quit":
                            break
                    except Exception as e:
                        print(f"Error: {e}", file=sys.stderr); rc = 1
                        if self.bail: break
                else:
                    buf.append(line)
                    if ";" in line:
                        sql = "\n".join(buf); buf = []
                        rc = self.run_sql_text(sql, command_line=False) or rc
            if buf:
                rc = self.run_sql_text("\n".join(buf), command_line=False) or rc
            return rc
        return self.run_sql_text(text, command_line=True)

    def run_sql_text(self, text, command_line=False):
        rc = 0
        for idx, st in enumerate(split_sql(text), 1):
            try:
                self.execute(st)
            except Exception as e:
                if command_line:
                    print(f"Error: in prepare, {e}", file=sys.stderr)
                else:
                    print(f"Parse error near line {idx}: {e}", file=sys.stderr)
                rc = 1
                if self.bail:
                    break
        self.db.save()
        return rc

    def dot(self, line):
        parts = shlex.split(line)
        if not parts:
            return
        cmd = parts[0][1:]
        args = parts[1:]
        if cmd in ("quit", "exit"):
            raise SystemExit(int(args[0]) if args else 0)
        if cmd == "help":
            self.emit(HELP_DOT); return
        if cmd == "version":
            self.emit("SQLite " + VERSION); return
        if cmd == "print":
            self.emit(" ".join(args)); return
        if cmd in ("headers", "header"):
            if args: self.headers = args[0].lower() in ("on", "yes", "1", "true")
            return
        if cmd == "mode":
            if args:
                self.mode = args[0].lower()
                if self.mode == "tabs": self.sep = "\t"
                if self.mode == "csv": self.sep = ","
            else:
                self.emit(self.mode)
            return
        if cmd == "separator":
            if args: self.sep = args[0]
            if len(args) > 1: self.rowsep = args[1]
            return
        if cmd == "nullvalue":
            self.null = args[0] if args else ""; return
        if cmd == "tables":
            names = sorted(self.db.tables)
            self.emit(" ".join(names)); return
        if cmd == "schema":
            pat = args[0] if args else None
            for name in sorted(self.db.tables):
                if not pat or pat.strip("%") in name:
                    self.emit(self.db.tables[name].get("sql") or self.create_sql(name) + ";")
            return
        if cmd == "dump":
            self.emit("PRAGMA foreign_keys=OFF;")
            self.emit("BEGIN TRANSACTION;")
            for name in sorted(self.db.tables):
                t = self.db.tables[name]
                self.emit((t.get("sql") or self.create_sql(name)) + ";")
                for row in t["rows"]:
                    self.emit(f"INSERT INTO {name} VALUES(" + ",".join(sql_string(v) for v in row) + ");")
            self.emit("COMMIT;"); return
        if cmd == "read" and args:
            with open(args[0], "r", encoding="utf-8") as f:
                self.run_input(f.read())
            return
        if cmd == "open":
            fileargs = [a for a in args if not a.startswith("-")]
            self.db.save()
            self.db = DB(fileargs[-1] if fileargs else ":memory:")
            return
        if cmd in ("output", "once"):
            if cmd == "output":
                if self.out is not sys.stdout:
                    self.out.close()
                self.out = open(args[0], "w", encoding="utf-8") if args else sys.stdout
            elif args:
                self.once = args[-1]
            return
        if cmd == "show":
            self.emit(f"        echo: {'on' if self.echo else 'off'}")
            self.emit(f"     headers: {'on' if self.headers else 'off'}")
            self.emit(f"        mode: {self.mode}")
            self.emit(f"   nullvalue: \"{self.null}\"")
            self.emit(f"   separator: \"{self.sep}\"")
            return
        if cmd == "bail":
            if args: self.bail = args[0].lower() in ("on", "1", "yes", "true")
            return
        if cmd == "echo":
            if args: self.echo = args[0].lower() in ("on", "1", "yes", "true")
            return
        if cmd == "databases":
            path = "" if self.db.path == ":memory:" else os.path.abspath(self.db.path)
            self.output_rows(["seq", "name", "file"], [[0, "main", path]])
            return
        if cmd == "import" and len(args) >= 2:
            self.import_file(args[0], args[1]); return
        # Unsupported shell conveniences are accepted as no-ops where possible.
        if cmd in ("timer", "stats", "changes", "eqp", "explain", "timeout", "limit", "indexes"):
            return
        raise Exception(f"unknown command or invalid arguments:  \"{line}\"")

    def create_sql(self, name):
        cols = self.db.tables[name]["columns"]
        return f"CREATE TABLE {name}(" + ", ".join(cols) + ")"

    def import_file(self, filename, table):
        with open(filename, newline="", encoding="utf-8") as f:
            rows = list(csv.reader(f, delimiter=self.sep if len(self.sep) == 1 else ","))
        if table not in self.db.tables:
            n = max((len(r) for r in rows), default=0)
            self.db.tables[table] = {"columns": [f"c{i+1}" for i in range(n)], "rows": [], "sql": ""}
        self.db.tables[table]["rows"].extend(rows)
        self.db.save()

    def execute(self, sql):
        s = sql.strip()
        if not s:
            return
        low = s.lower()
        if low in ("begin", "begin transaction", "commit", "end", "rollback"):
            return
        if low.startswith("pragma"):
            self.handle_pragma(s); return
        if low.startswith("create table"):
            self.handle_create(s); return
        if low.startswith("drop table"):
            name = unquote_ident(s.split()[-1])
            self.db.tables.pop(name, None); self.changed = 0; return
        if low.startswith("insert"):
            self.handle_insert(s); return
        if low.startswith("select") or low.startswith("with"):
            cols, rows = self.handle_select(s)
            self.output_rows(cols, rows); return
        if low.startswith("delete"):
            self.handle_delete(s); return
        if low.startswith("update"):
            self.handle_update(s); return
        raise Exception(f'near "{s.split()[0]}": syntax error')

    def handle_pragma(self, s):
        m = re.match(r"pragma\s+(\w+)", s, re.I)
        name = m.group(1).lower() if m else ""
        if name == "table_info":
            tname = re.search(r"\((.*?)\)", s).group(1).strip("'\"")
            t = self.db.tables.get(tname)
            rows = []
            if t:
                for i, c in enumerate(t["columns"]):
                    rows.append([i, c, "", 0, None, 0])
            self.output_rows(["cid", "name", "type", "notnull", "dflt_value", "pk"], rows)
        elif name in ("database_list",):
            path = "" if self.db.path == ":memory:" else os.path.abspath(self.db.path)
            self.output_rows(["seq", "name", "file"], [[0, "main", path]])

    def handle_create(self, s):
        m = re.match(r"create\s+(?:temp(?:orary)?\s+)?table\s+(?:if\s+not\s+exists\s+)?([^\s(]+)\s*\((.*)\)\s*$", s, re.I | re.S)
        if not m:
            raise Exception("near \"create\": syntax error")
        name = unquote_ident(m.group(1))
        defs = split_top(m.group(2))
        cols = []
        for d in defs:
            first = d.strip().split()[0] if d.strip().split() else ""
            if first.lower() not in ("primary", "foreign", "unique", "check", "constraint"):
                cols.append(unquote_ident(first))
        self.db.tables[name] = {"columns": cols, "rows": [], "sql": s}
        self.changed = 0

    def handle_insert(self, s):
        m = re.match(r"insert\s+(?:or\s+\w+\s+)?into\s+([^\s(]+)\s*(?:\((.*?)\))?\s*(.*)$", s, re.I | re.S)
        if not m:
            raise Exception("near \"insert\": syntax error")
        name = unquote_ident(m.group(1))
        if name not in self.db.tables:
            raise Exception(f"no such table: {name}")
        t = self.db.tables[name]
        cols = [unquote_ident(x) for x in split_top(m.group(2))] if m.group(2) else t["columns"]
        rest = m.group(3).strip()
        if rest.lower().startswith("values"):
            vals = rest[6:].strip()
            groups = []
            i = 0
            while i < len(vals):
                while i < len(vals) and vals[i] in " ,\n\t": i += 1
                if i >= len(vals): break
                if vals[i] != "(": raise Exception("near \"values\": syntax error")
                depth, quote, start = 0, None, i
                while i < len(vals):
                    c = vals[i]
                    if quote:
                        if c == quote:
                            if i + 1 < len(vals) and vals[i + 1] == quote: i += 1
                            else: quote = None
                    elif c in "'\"": quote = c
                    elif c == "(": depth += 1
                    elif c == ")":
                        depth -= 1
                        if depth == 0:
                            groups.append(vals[start + 1:i]); i += 1; break
                    i += 1
            for g in groups:
                row = [None] * len(t["columns"])
                vals2 = [self.eval_expr(x, {}) for x in split_top(g)]
                for c, v in zip(cols, vals2):
                    if c in t["columns"]:
                        row[t["columns"].index(c)] = v
                t["rows"].append(row)
            self.changed = len(groups)
        elif rest.lower().startswith("select"):
            scols, rows = self.handle_select(rest)
            for r in rows:
                row = [None] * len(t["columns"])
                for c, v in zip(cols, r):
                    if c in t["columns"]:
                        row[t["columns"].index(c)] = v
                t["rows"].append(row)
            self.changed = len(rows)
        else:
            raise Exception("near \"insert\": syntax error")

    def handle_delete(self, s):
        m = re.match(r"delete\s+from\s+([^\s]+)(?:\s+where\s+(.+))?$", s, re.I | re.S)
        if not m: raise Exception("near \"delete\": syntax error")
        name = unquote_ident(m.group(1)); t = self.db.tables.get(name)
        if not t: raise Exception(f"no such table: {name}")
        if not m.group(2):
            self.changed = len(t["rows"]); t["rows"] = []; return
        kept, n = [], 0
        for row in t["rows"]:
            env = dict(zip(t["columns"], row))
            if self.eval_expr(m.group(2), env): n += 1
            else: kept.append(row)
        t["rows"] = kept; self.changed = n

    def handle_update(self, s):
        m = re.match(r"update\s+([^\s]+)\s+set\s+(.+?)(?:\s+where\s+(.+))?$", s, re.I | re.S)
        if not m: raise Exception("near \"update\": syntax error")
        name = unquote_ident(m.group(1)); t = self.db.tables.get(name)
        if not t: raise Exception(f"no such table: {name}")
        assigns = []
        for a in split_top(m.group(2)):
            k, v = a.split("=", 1); assigns.append((unquote_ident(k), v))
        n = 0
        for row in t["rows"]:
            env = dict(zip(t["columns"], row))
            if not m.group(3) or self.eval_expr(m.group(3), env):
                for k, expr in assigns:
                    if k in t["columns"]:
                        row[t["columns"].index(k)] = self.eval_expr(expr, env)
                n += 1
        self.changed = n

    def handle_select(self, s):
        s = s.strip().rstrip(";")
        m = re.match(r"select\s+(.+?)(?:\s+from\s+([^\s]+)(.*))?$", s, re.I | re.S)
        if not m:
            raise Exception("near \"select\": syntax error")
        exprs, table, tail = m.group(1), m.group(2), m.group(3) or ""
        rows_env = [({}, None)]
        if table:
            name = unquote_ident(table)
            if name.lower() == "sqlite_master":
                rows_env = []
                for tn, t in self.db.tables.items():
                    rows_env.append(({"type": "table", "name": tn, "tbl_name": tn, "rootpage": 0, "sql": t.get("sql") or self.create_sql(tn)}, None))
            else:
                t = self.db.tables.get(name)
                if not t: raise Exception(f"no such table: {name}")
                rows_env = [(dict(zip(t["columns"], r)), t) for r in t["rows"]]
        where = re.search(r"\bwhere\b\s+(.+?)(?=\border\s+by\b|\blimit\b|$)", tail, re.I | re.S)
        order = re.search(r"\border\s+by\b\s+(.+?)(?=\blimit\b|$)", tail, re.I | re.S)
        limit = re.search(r"\blimit\b\s+(\d+)", tail, re.I)
        if where:
            cond = where.group(1).strip()
            rows_env = [(e, t) for e, t in rows_env if self.eval_expr(cond, e)]
        items = split_top(exprs)
        agg_count = len(items) == 1 and re.match(r"count\s*\(\s*\*?\s*\)$", items[0], re.I)
        if agg_count:
            return [self.col_name(items[0])], [[len(rows_env)]]
        out_cols, out_rows = [], []
        for it in items:
            if it == "*" and table and rows_env:
                t = rows_env[0][1]
                out_cols.extend(t["columns"] if t else list(rows_env[0][0].keys()))
            else:
                out_cols.append(self.col_name(it))
        for env, t in rows_env:
            out = []
            for it in items:
                if it == "*":
                    out.extend([env.get(c) for c in (t["columns"] if t else env.keys())])
                else:
                    out.append(self.eval_expr(self.strip_alias(it)[0], env))
            out_rows.append(out)
        if order:
            key = order.group(1).strip().split()[0]
            rev = " desc" in order.group(1).lower()
            idx = out_cols.index(key) if key in out_cols else None
            if idx is not None:
                out_rows.sort(key=lambda r: (r[idx] is None, r[idx]), reverse=rev)
        if limit:
            out_rows = out_rows[:int(limit.group(1))]
        return out_cols, out_rows

    def strip_alias(self, item):
        m = re.match(r"(.+?)\s+as\s+([^\s]+)$", item, re.I | re.S)
        if m: return m.group(1).strip(), unquote_ident(m.group(2))
        parts = item.rsplit(None, 1)
        if len(parts) == 2 and re.match(r"^[A-Za-z_]\w*$", parts[1]) and not re.search(r"[+\-*/<>=]", parts[1]):
            return parts[0], unquote_ident(parts[1])
        return item, None

    def col_name(self, item):
        expr, alias = self.strip_alias(item)
        return alias or expr.strip()

    def eval_expr(self, expr, env):
        expr = expr.strip()
        if expr == "*":
            return None
        if re.match(r"^'.*'$", expr, re.S):
            return expr[1:-1].replace("''", "'")
        if re.match(r'^".*"$', expr, re.S):
            return expr[1:-1].replace('""', '"')
        if re.match(r"^-?\d+$", expr):
            return int(expr)
        if re.match(r"^-?\d+\.\d+", expr):
            return float(expr)
        if expr.lower() == "null":
            return None
        if expr.lower() in ("true", "false"):
            return 1 if expr.lower() == "true" else 0
        if expr in env:
            return env[expr]
        if "." in expr and expr.split(".")[-1] in env:
            return env[expr.split(".")[-1]]
        m = re.match(r"(\w+)\s*\((.*)\)$", expr, re.S)
        if m:
            fn = m.group(1).lower(); args = [] if not m.group(2).strip() else [self.eval_expr(a, env) for a in split_top(m.group(2))]
            if fn == "sqlite_version": return "3.54.0"
            if fn == "sqlite_source_id": return VERSION.split(" ", 2)[2].rsplit(" ", 1)[0]
            if fn == "abs": return None if args[0] is None else abs(args[0])
            if fn == "upper": return None if args[0] is None else str(args[0]).upper()
            if fn == "lower": return None if args[0] is None else str(args[0]).lower()
            if fn == "length": return None if args[0] is None else len(str(args[0]))
            if fn == "typeof":
                v = args[0]
                return "null" if v is None else "integer" if isinstance(v, int) else "real" if isinstance(v, float) else "text"
            if fn in ("coalesce", "ifnull"):
                for a in args:
                    if a is not None: return a
                return None
            if fn == "round": return round(float(args[0]), int(args[1]) if len(args) > 1 else 0)
            if fn == "quote": return sql_string(args[0])
        for op in (" or ", " and "):
            parts = re.split(op, expr, flags=re.I)
            if len(parts) > 1:
                vals = [bool(self.eval_expr(p, env)) for p in parts]
                return int(any(vals) if op.strip() == "or" else all(vals))
        for op in (">=", "<=", "<>", "!=", "=", ">", "<"):
            parts = split_operator(expr, op)
            if parts:
                a, b = self.eval_expr(parts[0], env), self.eval_expr(parts[1], env)
                if a is None or b is None: return None
                return int({"=": a == b, "!=": a != b, "<>": a != b, ">": a > b, "<": a < b, ">=": a >= b, "<=": a <= b}[op])
        py = expr
        names = sorted(env, key=len, reverse=True)
        vals = {}
        for i, n in enumerate(names):
            key = f"__v{i}"
            vals[key] = env[n]
            py = re.sub(rf"\b{re.escape(n)}\b", key, py)
        py = re.sub(r"(?<![<>=!])=(?!=)", "==", py)
        try:
            return eval(py, {"__builtins__": {}}, vals)
        except Exception:
            return expr


def split_operator(expr, op):
    quote = None; depth = 0; i = 0
    while i <= len(expr) - len(op):
        c = expr[i]
        if quote:
            if c == quote: quote = None
        elif c in "'\"": quote = c
        elif c == "(": depth += 1
        elif c == ")": depth -= 1
        elif depth == 0 and expr[i:i+len(op)] == op:
            return expr[:i].strip(), expr[i+len(op):].strip()
        i += 1
    return None


def parse_args(argv):
    opts = {"cmds": [], "db": None, "sql": [], "mode": None, "headers": None, "sep": None, "null": None, "bail": False, "echo": False}
    i = 0
    while i < len(argv):
        a = argv[i]
        if a == "--": i += 1; break
        if a in ("-help", "--help"):
            print(HELP); raise SystemExit(0)
        if a in ("-version", "--version"):
            print(VERSION); raise SystemExit(0)
        if a == "-cmd":
            i += 1; opts["cmds"].append(argv[i])
        elif a in ("-csv", "-json", "-line", "-list", "-column", "-box", "-table", "-tabs", "-quote", "-html", "-markdown", "-ascii"):
            opts["mode"] = a[1:]
        elif a in ("-header", "-headers"):
            opts["headers"] = True
        elif a in ("-noheader", "-noheaders"):
            opts["headers"] = False
        elif a == "-separator":
            i += 1; opts["sep"] = argv[i]
        elif a == "-nullvalue":
            i += 1; opts["null"] = argv[i]
        elif a == "-bail":
            opts["bail"] = True
        elif a == "-echo":
            opts["echo"] = True
        elif a in ("-batch", "-interactive", "-noinit", "-readonly", "-safe", "-unsafe-testing", "-ifexists", "-deserialize", "-append", "-nofollow", "-zip"):
            pass
        elif a in ("-init", "-vfs", "-mmap", "-maxsize", "-newline", "-escape", "-nonce"):
            i += 1
        elif a in ("-lookaside", "-pagecache"):
            i += 2
        elif a.startswith("-"):
            print(f"./executable: Error: unknown option: {a}", file=sys.stderr)
            print("Use -help for a list of options.", file=sys.stderr)
            raise SystemExit(1)
        else:
            break
        i += 1
    rest = argv[i:]
    if rest:
        opts["db"] = rest[0]; opts["sql"] = rest[1:]
    return opts


def main(argv):
    opts = parse_args(argv)
    sh = Shell(DB(opts["db"] or ":memory:"))
    if opts["mode"]: sh.mode = opts["mode"]
    if opts["headers"] is not None: sh.headers = opts["headers"]
    if opts["sep"] is not None: sh.sep = opts["sep"]
    if opts["null"] is not None: sh.null = opts["null"]
    sh.bail = opts["bail"]; sh.echo = opts["echo"]
    for c in opts["cmds"]:
        if c.lstrip().startswith("."): sh.dot(c)
        else: sh.run_sql_text(c, command_line=True)
    if opts["sql"]:
        text = " ".join(opts["sql"])
        if text.lstrip().startswith("."):
            sh.dot(text.strip())
            sh.db.save()
            return 0
        return sh.run_input(text, command_line=True)
    if not sys.stdin.isatty():
        return sh.run_input(sys.stdin.read())
    return 0


if __name__ == "__main__":
    try:
        sys.exit(main(sys.argv[1:]))
    except SystemExit:
        raise
    except Exception as e:
        print(f"Error: {e}", file=sys.stderr)
        sys.exit(1)
