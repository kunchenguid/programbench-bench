#!/usr/bin/env python3
import argparse
import datetime
import os
import re
import sys

BOLD = "\033[1m"
DIM = "\033[2m"
RESET = "\033[0m"

HELP = """json log viewer

Usage: executable [OPTIONS] [INPUT]

Arguments:
  [INPUT]  Sets the input file to use, otherwise assumes stdin [default: -]

Options:
  -a, --additional-value <additional-value>
          adds additional values
      --config-file <config-file>
          configuration file to load
  -m, --message-key <message-key>
          Adds an additional key to detect the message in the log entry. The first matching key will be assigned to `fblog_message`.
      --print-lua
          Prints lua init expressions. Used for fblog debugging.
  -t, --time-key <time-key>
          Adds an additional key to detect the time in the log entry. The first matching key will be assigned to `fblog_timestamp`.
  -l, --level-key <level-key>
          Adds an additional key to detect the level in the log entry. The first matching key will be assigned to `fblog_level`.
      --map-level <from=to>
          Rewrite the log level from one value to another.
  -d, --dump-all
          dumps all values
  -x, --excluded-value <excluded-value>
          Excludes values (--dump-all is enabled implicitly)
  -p, --with-prefix
          consider all text before opening curly brace as prefix
  -f, --filter <filter>
          lua expression to filter log entries. `message ~= nil and string.find(message, "text.*") ~= nil`
      --no-implicit-filter-return-statement
          if you pass a filter expression 'return' is automatically prepended. Pass this switch to disable the implicit return.
      --main-line-format <main-line-format>
          Formats the main fblog output. All log values can be used. fblog provides sanitized variables starting with `fblog_`.
      --additional-value-format <additional-value-format>
          Formats the additional value fblog output.
  -s, --substitute
          Enable substitution of placeholders in the log messages with their corresponding values from the context.
  -c, --context-key <context-key>
          Use this key as the source of substitutions for the message. Value can either be an array ({1}) or an object ({key}).
  -F, --placeholder-format <placeholder-format>
          The format that should be used for substituting values in the message, where the key is the literal word `key`. Example: [[key]] or ${key}.
  -h, --help
          Print help
  -V, --version
          Print version
"""


class JsonParser:
    def __init__(self, text):
        self.s = text
        self.i = 0

    def parse(self):
        self.ws()
        v = self.value()
        self.ws()
        if self.i != len(self.s):
            raise ValueError("trailing characters")
        return v

    def ws(self):
        while self.i < len(self.s) and self.s[self.i] in " \t\r\n":
            self.i += 1

    def ch(self, c):
        if self.i >= len(self.s) or self.s[self.i] != c:
            raise ValueError("expected " + c)
        self.i += 1

    def value(self):
        self.ws()
        if self.i >= len(self.s):
            raise ValueError("unexpected end")
        c = self.s[self.i]
        if c == '"':
            return self.string()
        if c == "{":
            return self.obj()
        if c == "[":
            return self.arr()
        if c == "t" and self.s.startswith("true", self.i):
            self.i += 4
            return True
        if c == "f" and self.s.startswith("false", self.i):
            self.i += 5
            return False
        if c == "n" and self.s.startswith("null", self.i):
            self.i += 4
            return None
        return self.num()

    def string(self):
        self.ch('"')
        out = []
        while self.i < len(self.s):
            c = self.s[self.i]
            self.i += 1
            if c == '"':
                return "".join(out)
            if c != "\\":
                out.append(c)
                continue
            if self.i >= len(self.s):
                raise ValueError("bad escape")
            e = self.s[self.i]
            self.i += 1
            mp = {'"': '"', "\\": "\\", "/": "/", "b": "\b", "f": "\f", "n": "\n", "r": "\r", "t": "\t"}
            if e in mp:
                out.append(mp[e])
            elif e == "u":
                h = self.s[self.i:self.i + 4]
                if len(h) != 4 or not re.fullmatch(r"[0-9a-fA-F]{4}", h):
                    raise ValueError("bad unicode")
                self.i += 4
                out.append(chr(int(h, 16)))
            else:
                raise ValueError("bad escape")
        raise ValueError("unterminated string")

    def num(self):
        m = re.match(r"-?(?:0|[1-9][0-9]*)(?:\.[0-9]+)?(?:[eE][+-]?[0-9]+)?", self.s[self.i:])
        if not m:
            raise ValueError("bad number")
        raw = m.group(0)
        self.i += len(raw)
        return float(raw) if any(c in raw for c in ".eE") else int(raw)

    def obj(self):
        self.ch("{")
        d = {}
        self.ws()
        if self.i < len(self.s) and self.s[self.i] == "}":
            self.i += 1
            return d
        while True:
            self.ws()
            k = self.string()
            self.ws()
            self.ch(":")
            d[k] = self.value()
            self.ws()
            if self.i < len(self.s) and self.s[self.i] == "}":
                self.i += 1
                return d
            self.ch(",")

    def arr(self):
        self.ch("[")
        a = []
        self.ws()
        if self.i < len(self.s) and self.s[self.i] == "]":
            self.i += 1
            return a
        while True:
            a.append(self.value())
            self.ws()
            if self.i < len(self.s) and self.s[self.i] == "]":
                self.i += 1
                return a
            self.ch(",")


def parse_json(s):
    return JsonParser(s).parse()


def c(code, text):
    return f"\033[{code}m{text}{RESET}"


def level_color(level):
    l = str(level or "unknown").lower()
    if l in ("error", "err", "50", "60"):
        return "1;31"
    if l in ("warn", "warning", "30", "40"):
        return "1;33" if l == "warn" else "1;35"
    if l in ("info", "20"):
        return "1;32"
    if l in ("debug", "10"):
        return "1;34"
    return "1;35"


def level_text(level):
    s = str(level if level not in (None, "") else "unknown").upper()
    if s == "WARNING":
        s = "WARNI"
    if len(s) > 5:
        s = s[:5]
    return s.rjust(5)


def fmt_time(v):
    if v is None:
        return ""
    s = str(v)
    if re.fullmatch(r"-?[0-9]{12,}", s):
        try:
            return datetime.datetime.utcfromtimestamp(int(s) / 1000).strftime("%Y-%m-%dT%H:%M:%S")
        except Exception:
            return s[:19]
    if re.match(r"\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}", s):
        return s[:19]
    return s[:19]


def scalar(v, quote_strings=False):
    if v is True:
        return "true"
    if v is False:
        return "false"
    if v is None:
        return "null"
    if isinstance(v, str):
        return '"' + v + '"' if quote_strings else v
    return str(v)


def render_value(v):
    if isinstance(v, dict):
        parts = []
        for k in sorted(v):
            parts.append(f"{c('35', k)}{DIM}: {RESET}{render_value(v[k])}")
        return DIM + "{" + RESET + (DIM + ", " + RESET).join(parts) + DIM + "}" + RESET
    if isinstance(v, list):
        return DIM + "[" + RESET + (DIM + ", " + RESET).join(render_value(x) for x in v) + DIM + "]" + RESET
    if isinstance(v, str):
        return c("1;33", v)
    if isinstance(v, bool):
        return c("1;32" if v else "1;31", "true" if v else "false")
    if isinstance(v, (int, float)):
        return c("1;36", str(v))
    return "null"


def flatten(v, prefix="", depth=0, direct_array=False):
    out = []
    if isinstance(v, dict):
        for k in sorted(v):
            p = k if not prefix else prefix + " > " + k
            out.extend(flatten(v[k], p, depth, False))
    elif isinstance(v, list):
        for i, item in enumerate(v):
            idx = i if depth == 0 else i + 1
            p = f"{prefix}[{idx}]"
            out.extend(flatten(item, p, depth + 1, True))
    else:
        out.append((prefix, v, isinstance(v, str) and direct_array))
    return out


def get_path(obj, path):
    if isinstance(obj, dict) and path in obj:
        return obj[path]
    cur = obj
    for part in [p.strip() for p in path.split(">")]:
        if not part:
            continue
        while True:
            m = re.match(r"^([^\[]*)\[(\d+)\](.*)$", part)
            if m:
                name, idx, rest = m.group(1), int(m.group(2)), m.group(3)
                if name:
                    if not isinstance(cur, dict) or name not in cur:
                        return None
                    cur = cur[name]
                if not isinstance(cur, list) or idx >= len(cur):
                    return None
                cur = cur[idx]
                part = rest
                if not part:
                    break
                if part.startswith("["):
                    continue
                return None
            else:
                if not isinstance(cur, dict) or part not in cur:
                    return None
                cur = cur[part]
                break
    return cur


def detect(obj, keys):
    for k in keys:
        if isinstance(obj, dict) and k in obj:
            return obj[k]
    return None


def invalid(line):
    return c("1;38;2;255;135;22", "??? >") + " " + line


def additional_line(k, v, quote=False):
    return BOLD + "\033[38;2;150;150;150m" + k.rjust(25) + RESET + RESET + ": " + scalar(v, quote)


def formatted_additional_line(fmt, k, v, quote=False):
    return fmt.replace("{{key}}", k).replace("{{value}}", scalar(v, quote))


def load_config(path):
    cfg = {
        "message_keys": ["short_message", "msg", "message"],
        "time_keys": ["timestamp", "time", "@timestamp"],
        "level_keys": ["level", "severity", "log.level", "loglevel"],
        "dump_all_exclude": [],
        "always_print_fields": [],
        "level_map": {},
        "main_line_format": None,
        "additional_value_format": None,
    }
    if not path:
        candidates = [
            "fblog.toml",
            os.path.join(os.environ.get("XDG_CONFIG_HOME", ""), "fblog", "fblog.toml"),
            os.path.join(os.environ.get("HOME", ""), ".config", "fblog", "fblog.toml"),
        ]
        path = next((p for p in candidates if p and os.path.exists(p)), None)
    if not path or not os.path.exists(path):
        return cfg
    section = None
    for raw in open(path, encoding="utf-8", errors="replace"):
        line = raw.strip()
        if not line or line.startswith("#"):
            continue
        if line.startswith("[") and line.endswith("]"):
            section = line[1:-1]
            continue
        if "=" not in line:
            continue
        k, v = [x.strip() for x in line.split("=", 1)]
        if section == "level_map":
            cfg["level_map"][k.strip('"')] = v.strip().strip('"')
            continue
        if v.startswith("["):
            cfg[k] = re.findall(r'"([^"]*)"', v)
        else:
            cfg[k] = v.strip('"')
    return cfg


def eval_filter(expr, obj):
    if not expr:
        return True
    e = expr.strip()
    if e.startswith("return "):
        e = e[7:].strip()
    m = re.fullmatch(r'string\.find\(([^,]+),\s*"([^"]*)"\)\s*~= nil', e)
    if m:
        val = get_lua_var(obj, m.group(1).strip())
        return val is not None and re.search(m.group(2), str(val)) is not None
    m = re.fullmatch(r'([A-Za-z0-9_@. >-]+)\s*(==|~=|>=|<=|>|<)\s*"?([^"]*)"?', e)
    if not m:
        return True
    left, op, right = m.group(1).strip(), m.group(2), m.group(3)
    val = get_lua_var(obj, left)
    if val is None:
        return False
    try:
        a = float(val)
        b = float(right)
    except Exception:
        a = str(val)
        b = right
    return {"==": a == b, "~=": a != b, ">": a > b, "<": a < b, ">=": a >= b, "<=": a <= b}[op]


def get_lua_var(obj, name):
    if isinstance(obj, dict) and name in obj:
        return obj[name]
    cur = obj
    for part in name.split("."):
        if not isinstance(cur, dict) or part not in cur:
            return None
        cur = cur[part]
    return cur


def substitute(msg, ctx, fmt):
    if ctx is None:
        return msg
    pattern = re.escape(fmt).replace("key", r"([^{}#$\[\]]+)")
    def repl(m):
        key = m.group(1)
        val = None
        if isinstance(ctx, dict):
            val = ctx.get(key)
        elif isinstance(ctx, list) and re.fullmatch(r"\d+", key):
            idx = int(key)
            if idx < len(ctx):
                val = ctx[idx]
        if val is None:
            return DIM + "{" + RESET + c("1;31", key) + DIM + "}" + RESET
        return render_value(val)
    return re.sub(pattern, repl, msg)


def simple_template(fmt, vals):
    def repl(m):
        key = m.group(1).strip()
        if key.startswith("fblog_"):
            return str(vals.get(key, ""))
        return str(vals.get(key, ""))
    return re.sub(r"\{\{([^{}]+)\}\}", repl, fmt)


def process_line(line, args, cfg):
    original = line.rstrip("\n")
    prefix = ""
    text = original
    if args.with_prefix and "{" in text:
        pos = text.find("{")
        prefix = text[:pos].rstrip()
        text = text[pos:]
    try:
        obj = parse_json(text)
        if not isinstance(obj, dict):
            raise ValueError("not object")
    except Exception:
        return [invalid(original)]
    if not eval_filter(args.filter, obj):
        return []
    msg = detect(obj, cfg["message_keys"] + args.message_key)
    ts = detect(obj, cfg["time_keys"] + args.time_key)
    lvl = detect(obj, cfg["level_keys"] + args.level_key)
    if lvl is not None and str(lvl) in cfg["level_map"]:
        lvl = cfg["level_map"][str(lvl)]
    for item in args.map_level:
        if "=" in item:
            a, b = item.split("=", 1)
            if str(lvl) == a:
                lvl = b
    if msg is None:
        msg = ""
    if args.substitute:
        msg = substitute(str(msg), get_path(obj, args.context_key or "context"), args.placeholder_format)
    vals = {
        "fblog_timestamp": fmt_time(ts),
        "fblog_level": str(lvl or "unknown"),
        "fblog_message": str(msg),
        "fblog_prefix": prefix,
    }
    if args.main_line_format:
        main = simple_template(args.main_line_format, vals)
    else:
        pre = ""
        if prefix:
            pre = " " + BOLD + "\033[36m" + prefix + RESET + RESET
        main = BOLD + fmt_time(ts) + RESET + " " + c(level_color(lvl), level_text(lvl)) + ":" + pre + " " + str(msg)
    lines = [main]
    field_values = []
    fields = list(args.additional_value) + list(cfg.get("always_print_fields", []))
    excluded = set(args.excluded_value) | set(cfg.get("dump_all_exclude", []))
    if args.dump_all or args.excluded_value:
        field_values = [(k, v, q) for k, v, q in flatten(obj) if k not in excluded]
    else:
        for f in fields:
            v = get_path(obj, f)
            if v is not None:
                field_values.append((f, v, isinstance(v, str) and "[" in f))
    for f, v, quote in field_values:
        if args.additional_value_format:
            lines.append(formatted_additional_line(args.additional_value_format, f, v, quote))
        else:
            lines.append(additional_line(f, v, quote))
    return lines


def main(argv=None):
    argv = list(sys.argv[1:] if argv is None else argv)
    if "-h" in argv or "--help" in argv:
        print(HELP)
        return 0
    p = argparse.ArgumentParser(description="json log viewer")
    p.add_argument("-a", "--additional-value", action="append", default=[], metavar="<additional-value>")
    p.add_argument("--config-file", metavar="<config-file>")
    p.add_argument("-m", "--message-key", action="append", default=[], metavar="<message-key>")
    p.add_argument("--print-lua", action="store_true")
    p.add_argument("-t", "--time-key", action="append", default=[], metavar="<time-key>")
    p.add_argument("-l", "--level-key", action="append", default=[], metavar="<level-key>")
    p.add_argument("--map-level", action="append", default=[], metavar="<from=to>")
    p.add_argument("-d", "--dump-all", action="store_true")
    p.add_argument("-x", "--excluded-value", action="append", default=[], metavar="<excluded-value>")
    p.add_argument("-p", "--with-prefix", action="store_true")
    p.add_argument("-f", "--filter", metavar="<filter>")
    p.add_argument("--no-implicit-filter-return-statement", action="store_true")
    p.add_argument("--main-line-format", metavar="<main-line-format>")
    p.add_argument("--additional-value-format", metavar="<additional-value-format>")
    p.add_argument("-s", "--substitute", action="store_true")
    p.add_argument("-c", "--context-key", metavar="<context-key>")
    p.add_argument("-F", "--placeholder-format", default="{key}", metavar="<placeholder-format>")
    p.add_argument("-V", "--version", action="store_true")
    p.add_argument("input", nargs="?", default="-")
    args = p.parse_args(argv)
    if args.version:
        print("fblog 4.17.0")
        return 0
    if args.print_lua:
        return 0
    cfg = load_config(args.config_file)
    if args.input == "-":
        fh = sys.stdin
    else:
        fh = open(args.input, encoding="utf-8", errors="replace")
    with fh:
        for line in fh:
            for out in process_line(line, args, cfg):
                print(out)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
