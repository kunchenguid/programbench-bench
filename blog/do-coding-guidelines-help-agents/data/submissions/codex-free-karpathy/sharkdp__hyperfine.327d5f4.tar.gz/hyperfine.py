#!/usr/bin/env python3
import csv
import itertools
import json
import math
import os
import shlex
import statistics
import subprocess
import sys
import time


VERSION = "hyperfine 1.20.0"
WARNING_FAST = (
    "  Warning: Command took less than 5 ms to complete. Note that the results "
    "might be inaccurate because hyperfine can not calibrate the shell startup "
    "time much more precise than this limit. You can try to use the "
    "`-N`/`--shell=none` option to disable the shell completely."
)


HELP = """A command-line benchmarking tool.

Usage: executable [OPTIONS] <command>...

Arguments:
  <command>...
          The command to benchmark. This can be the name of an executable, a
          command line like "grep -i todo" or a shell command like "sleep 0.5 &&
          echo test".

Options:
  -w, --warmup <NUM>              Perform NUM warmup runs before the actual benchmark.
  -m, --min-runs <NUM>            Perform at least NUM runs for each command (default: 10).
  -M, --max-runs <NUM>            Perform at most NUM runs for each command.
  -r, --runs <NUM>                Perform exactly NUM runs for each command.
  -s, --setup <CMD>               Execute CMD before each set of timing runs.
  -p, --prepare <CMD>             Execute CMD before each timing run.
  -C, --conclude <CMD>            Execute CMD after each timing run.
  -c, --cleanup <CMD>             Execute CMD after benchmarking each command.
  -P, --parameter-scan <VAR> <MIN> <MAX>
                                  Perform benchmark runs for each value in MIN..MAX.
  -D, --parameter-step-size <DELTA>
                                  Step size for --parameter-scan.
  -L, --parameter-list <VAR> <VALUES>
                                  Perform benchmark runs for comma-separated VALUES.
  -S, --shell <SHELL>             Set the shell used to execute commands.
  -N                              An alias for '--shell=none'.
  -i, --ignore-failure[=<MODE>]   Ignore failures of benchmarked programs.
      --style <TYPE>              Set output style type.
      --sort <METHOD>             Sort order: auto, command, mean-time.
  -u, --time-unit <UNIT>          microsecond, millisecond, second.
      --export-asciidoc <FILE>    Export an AsciiDoc table.
      --export-csv <FILE>         Export CSV.
      --export-json <FILE>        Export JSON.
      --export-markdown <FILE>    Export a Markdown table.
      --export-orgmode <FILE>     Export an org-mode table.
      --show-output               Print benchmark stdout and stderr.
      --output <WHERE>            null, pipe, inherit, or a file.
      --input <WHERE>             null or a file.
  -n, --command-name <NAME>       Give a meaningful name to a command.
  -h, --help                      Print help
  -V, --version                   Print version
"""


class Opts:
    def __init__(self):
        self.warmup = 0
        self.min_runs = 10
        self.max_runs = None
        self.runs = None
        self.setup = None
        self.prepare = []
        self.conclude = []
        self.cleanup = None
        self.scan = None
        self.step = None
        self.lists = []
        self.shell = "default"
        self.ignore_failure = None
        self.style = "auto"
        self.style_specified = False
        self.sort = "auto"
        self.time_unit = None
        self.export_asciidoc = None
        self.export_csv = None
        self.export_json = None
        self.export_markdown = None
        self.export_orgmode = None
        self.show_output = False
        self.output = []
        self.input = "null"
        self.names = []
        self.commands = []


def die(msg, code=1):
    print(msg, file=sys.stderr)
    sys.exit(code)


def need(args, i, n, flag):
    if i + n >= len(args):
        die(f"error: a value is required for '{flag}'")


def parse_args(argv):
    opts = Opts()
    i = 0
    while i < len(argv):
        a = argv[i]
        if a in ("-h", "--help"):
            print(HELP, end="")
            sys.exit(0)
        if a in ("-V", "--version"):
            print(VERSION)
            sys.exit(0)
        if a == "--":
            opts.commands.extend(argv[i + 1 :])
            break
        if not a.startswith("-") or a == "-":
            opts.commands.append(a)
            i += 1
            continue
        if a.startswith("--ignore-failure="):
            opts.ignore_failure = a.split("=", 1)[1] or "all-non-zero"
        elif a == "--ignore-failure" or a == "-i":
            opts.ignore_failure = "all-non-zero"
        elif a.startswith("--shell="):
            opts.shell = a.split("=", 1)[1]
        elif a == "-N":
            opts.shell = "none"
        elif a in ("-w", "--warmup"):
            need(argv, i, 1, a); i += 1; opts.warmup = int(argv[i])
        elif a in ("-m", "--min-runs"):
            need(argv, i, 1, a); i += 1; opts.min_runs = int(argv[i])
        elif a in ("-M", "--max-runs"):
            need(argv, i, 1, a); i += 1; opts.max_runs = int(argv[i])
        elif a in ("-r", "--runs"):
            need(argv, i, 1, a); i += 1; opts.runs = int(argv[i])
        elif a in ("-s", "--setup"):
            need(argv, i, 1, a); i += 1; opts.setup = argv[i]
        elif a in ("-p", "--prepare"):
            need(argv, i, 1, a); i += 1; opts.prepare.append(argv[i])
        elif a in ("-C", "--conclude"):
            need(argv, i, 1, a); i += 1; opts.conclude.append(argv[i])
        elif a in ("-c", "--cleanup"):
            need(argv, i, 1, a); i += 1; opts.cleanup = argv[i]
        elif a in ("-P", "--parameter-scan"):
            need(argv, i, 3, a); opts.scan = (argv[i + 1], argv[i + 2], argv[i + 3]); i += 3
        elif a in ("-D", "--parameter-step-size"):
            need(argv, i, 1, a); i += 1; opts.step = argv[i]
        elif a in ("-L", "--parameter-list"):
            need(argv, i, 2, a); opts.lists.append((argv[i + 1], argv[i + 2])); i += 2
        elif a in ("-S", "--shell"):
            need(argv, i, 1, a); i += 1; opts.shell = argv[i]
        elif a == "--style":
            need(argv, i, 1, a); i += 1; opts.style = argv[i]; opts.style_specified = True
        elif a.startswith("--style="):
            opts.style = a.split("=", 1)[1]; opts.style_specified = True
        elif a == "--sort":
            need(argv, i, 1, a); i += 1; opts.sort = argv[i]
        elif a.startswith("--sort="):
            opts.sort = a.split("=", 1)[1]
        elif a in ("-u", "--time-unit"):
            need(argv, i, 1, a); i += 1; opts.time_unit = argv[i]
        elif a == "--export-asciidoc":
            need(argv, i, 1, a); i += 1; opts.export_asciidoc = argv[i]
        elif a == "--export-csv":
            need(argv, i, 1, a); i += 1; opts.export_csv = argv[i]
        elif a == "--export-json":
            need(argv, i, 1, a); i += 1; opts.export_json = argv[i]
        elif a == "--export-markdown":
            need(argv, i, 1, a); i += 1; opts.export_markdown = argv[i]
        elif a == "--export-orgmode":
            need(argv, i, 1, a); i += 1; opts.export_orgmode = argv[i]
        elif a == "--show-output":
            opts.show_output = True
        elif a == "--output":
            need(argv, i, 1, a); i += 1; opts.output.append(argv[i])
        elif a.startswith("--output="):
            opts.output.append(a.split("=", 1)[1])
        elif a == "--input":
            need(argv, i, 1, a); i += 1; opts.input = argv[i]
        elif a.startswith("--input="):
            opts.input = a.split("=", 1)[1]
        elif a in ("-n", "--command-name"):
            need(argv, i, 1, a); i += 1; opts.names.append(argv[i])
        else:
            die(f"error: unexpected argument '{a}' found\n\nFor more information, try '--help'.")
        i += 1
    if not opts.commands:
        die("error: the following required arguments were not provided:\n  <command>...\n\nUsage: executable [OPTIONS] <command>...\n\nFor more information, try '--help'.", 2)
    if opts.runs is not None:
        opts.min_runs = opts.runs
        opts.max_runs = opts.runs
    if opts.show_output and opts.style_specified:
        die("error: the argument '--style <TYPE>' cannot be used with '--show-output'\n\nFor more information, try '--help'.", 2)
    if opts.step is not None and opts.scan is None:
        die("error: the argument '--parameter-step-size <DELTA>' requires '--parameter-scan <VAR> <MIN> <MAX>'")
    return opts


def decimal_places(s):
    return len(s.split(".", 1)[1].rstrip("0")) if "." in s else 0


def fmt_param(x, places=0):
    if places:
        return f"{x:.{places}f}".rstrip("0").rstrip(".")
    if abs(x - round(x)) < 1e-12:
        return str(int(round(x)))
    return ("%g" % x)


def expand_commands(opts):
    params = []
    if opts.scan:
        var, lo_s, hi_s = opts.scan
        lo, hi = float(lo_s), float(hi_s)
        step = float(opts.step) if opts.step is not None else 1.0
        places = max(decimal_places(lo_s), decimal_places(hi_s), decimal_places(opts.step or ""))
        vals = []
        x = lo
        limit = 100000
        while x <= hi + abs(step) / 1000000 and limit:
            vals.append(fmt_param(x, places))
            x += step
            limit -= 1
        params.append((var, vals))
    for var, values in opts.lists:
        params.append((var, values.split(",")))
    if not params:
        return opts.commands[:]
    expanded = []
    for combo in itertools.product(*[p[1] for p in params]):
        repl = dict(zip([p[0] for p in params], combo))
        for cmd in opts.commands:
            out = cmd
            for k, v in repl.items():
                out = out.replace("{" + k + "}", v)
            expanded.append(out)
    return expanded


def shell_for(opts):
    if opts.shell in ("default", ""):
        return ["/bin/sh", "-c"]
    if opts.shell == "none":
        return None
    return shlex.split(opts.shell) + ["-c"]


def should_ignore(opts, code):
    if code == 0:
        return True
    mode = opts.ignore_failure
    if mode is None:
        return False
    if mode in ("", "all-non-zero"):
        return True
    try:
        return code in {int(x) for x in mode.split(",") if x}
    except ValueError:
        return False


def run_command(cmd, opts, timed=False, iteration=None, hook=False):
    env = os.environ.copy()
    if iteration is not None:
        env["HYPERFINE_ITERATION"] = str(iteration)
    stdin = subprocess.DEVNULL
    if opts.input != "null" and not hook:
        stdin = open(opts.input, "rb")
    stdout = subprocess.DEVNULL
    stderr = subprocess.DEVNULL
    out_handle = None
    where = "inherit" if opts.show_output else (opts.output[0] if opts.output else "null")
    if hook:
        where = "null"
    if where == "inherit":
        stdout = None
        stderr = None
    elif where == "pipe":
        stdout = subprocess.PIPE
        stderr = subprocess.PIPE
    elif where != "null":
        out_handle = open(where, "ab")
        stdout = out_handle
        stderr = out_handle
    start = time.perf_counter()
    ru_start = os.times()
    try:
        shell = shell_for(opts)
        if shell is None:
            args = shlex.split(cmd)
            proc = subprocess.run(args, stdin=stdin, stdout=stdout, stderr=stderr, env=env)
        else:
            proc = subprocess.run(shell + [cmd], stdin=stdin, stdout=stdout, stderr=stderr, env=env)
    finally:
        if stdin is not subprocess.DEVNULL and hasattr(stdin, "close"):
            stdin.close()
        if out_handle:
            out_handle.close()
    elapsed = time.perf_counter() - start
    ru_end = os.times()
    user = max(0.0, ru_end.children_user - ru_start.children_user)
    system = max(0.0, ru_end.children_system - ru_start.children_system)
    return proc.returncode, elapsed, user, system


def stats(values):
    n = len(values)
    mean = sum(values) / n
    sd = statistics.stdev(values) if n > 1 else 0.0
    med = statistics.median(values)
    return mean, sd, med, min(values), max(values)


def unit_for(seconds, explicit=None):
    if explicit in ("microsecond", "microseconds", "us"):
        return "us", "µs", 1_000_000.0
    if explicit in ("millisecond", "milliseconds", "ms"):
        return "ms", "ms", 1000.0
    if explicit in ("second", "seconds", "s"):
        return "s", "s", 1.0
    if seconds < 0.005:
        return "ms", "ms", 1000.0
    if seconds < 1.0:
        return "ms", "ms", 1000.0
    return "s", "s", 1.0


def fmt_num(x):
    if x >= 100:
        return f"{x:.0f}"
    if x >= 10:
        return f"{x:.1f}"
    return f"{x:.2f}" if x < 1 else f"{x:.1f}"


def run_benchmarks(opts):
    commands = expand_commands(opts)
    results = []
    total = len(commands)
    for idx, cmd in enumerate(commands, 1):
        display = opts.names[idx - 1] if idx - 1 < len(opts.names) else cmd
        if opts.style != "none":
            print(f"Benchmark {idx}: {display}")
            sys.stdout.flush()
        if opts.setup:
            rc, _, _, _ = run_command(opts.setup, opts, hook=True)
            if rc != 0:
                die(f"Error: Setup command terminated with non-zero exit code {rc}.")
        for _ in range(opts.warmup):
            rc, _, _, _ = run_command(cmd, opts)
            if not should_ignore(opts, rc):
                die(f"Error: Command terminated with non-zero exit code {rc} during warmup.")
        runs = opts.runs if opts.runs is not None else opts.min_runs
        if opts.max_runs is not None:
            runs = min(runs, opts.max_runs)
        times, users, systems, codes, mem = [], [], [], [], []
        for n in range(1, runs + 1):
            prep = opts.prepare[0] if len(opts.prepare) == 1 else (opts.prepare[idx - 1] if idx - 1 < len(opts.prepare) else None)
            if prep:
                rc, _, _, _ = run_command(prep, opts, iteration=n, hook=True)
                if rc != 0:
                    die(f"Error: Preparation command terminated with non-zero exit code {rc}.")
            sys.stdout.flush()
            rc, elapsed, user, system = run_command(cmd, opts, timed=True, iteration=n)
            if n == 1 and not should_ignore(opts, rc):
                die(f"Error: Command terminated with non-zero exit code {rc} in the first benchmark run. Use the '-i'/'--ignore-failure' option if you want to ignore this. Alternatively, use the '--show-output' option to debug what went wrong.")
            if not should_ignore(opts, rc):
                die(f"Error: Command terminated with non-zero exit code {rc}.")
            conc = opts.conclude[0] if len(opts.conclude) == 1 else (opts.conclude[idx - 1] if idx - 1 < len(opts.conclude) else None)
            if conc:
                run_command(conc, opts, iteration=n, hook=True)
            times.append(elapsed)
            users.append(user)
            systems.append(system)
            codes.append(rc)
            mem.append(0)
        if opts.cleanup:
            run_command(opts.cleanup, opts, hook=True)
        mean, sd, med, mn, mx = stats(times)
        result = {
            "command": display,
            "mean": mean,
            "stddev": sd,
            "median": med,
            "user": sum(users) / len(users),
            "system": sum(systems) / len(systems),
            "min": mn,
            "max": mx,
            "times": times,
            "memory_usage_byte": mem,
            "exit_codes": codes,
        }
        results.append(result)
        if opts.style != "none":
            _, label, mult = unit_for(mean, opts.time_unit)
            if len(times) == 1:
                print(f"  Time (abs ≡):      {fmt_num(mean * mult):>8} {label:<2}               [User: {fmt_num(result['user'] * mult)} {label}, System: {fmt_num(result['system'] * mult)} {label}]")
            else:
                print(f"  Time (mean ± σ):   {fmt_num(mean * mult):>8} {label} ± {fmt_num(sd * mult)} {label}    [User: {fmt_num(result['user'] * mult)} {label}, System: {fmt_num(result['system'] * mult)} {label}]")
                print(f"  Range (min … max): {fmt_num(mn * mult):>8} {label} … {fmt_num(mx * mult)} {label}    {len(times)} runs")
            print(" ")
        if mean < 0.005:
            print("\n" + WARNING_FAST, file=sys.stderr)
        if opts.ignore_failure is not None and any(c != 0 for c in codes):
            print("  Warning: Ignoring non-zero exit code.", file=sys.stderr)
    if opts.style != "none" and len(results) > 1:
        best = min(results, key=lambda r: r["mean"])
        print("Summary")
        print(f"  {best['command']} ran")
        for r in sorted([r for r in results if r is not best], key=lambda x: x["mean"]):
            print(f"    {r['mean'] / best['mean']:.2f} times faster than {r['command']}")
    return results


def rows_for_tables(results, opts):
    order = results[:]
    if opts.sort == "mean-time":
        order.sort(key=lambda r: r["mean"])
    best = min(results, key=lambda r: r["mean"]) if results else None
    _, label, mult = unit_for(best["mean"] if best else 0, opts.time_unit)
    header_unit = "µs" if label == "µs" else label
    rows = []
    for r in order:
        rel = r["mean"] / best["mean"] if best and best["mean"] else 1.0
        rel_sd = rel * math.sqrt((r["stddev"] / r["mean"]) ** 2 + (best["stddev"] / best["mean"]) ** 2) if r["mean"] and best and best["mean"] else 0
        rel_text = "1.00" if abs(rel - 1.0) < 1e-9 else f"{rel:.2f} ± {rel_sd:.2f}"
        rows.append((r["command"], f"{fmt_num(r['mean'] * mult)} ± {fmt_num(r['stddev'] * mult)}", fmt_num(r["min"] * mult), fmt_num(r["max"] * mult), rel_text))
    return header_unit, rows


def write_exports(results, opts):
    if opts.export_json:
        with open(opts.export_json, "w") as f:
            json.dump({"results": results}, f, indent=2)
            f.write("\n")
    if opts.export_csv:
        with open(opts.export_csv, "w", newline="") as f:
            w = csv.writer(f)
            w.writerow(["command", "mean", "stddev", "median", "user", "system", "min", "max"])
            for r in results:
                w.writerow([r["command"], r["mean"], r["stddev"], r["median"], r["user"], r["system"], r["min"], r["max"]])
    unit, rows = rows_for_tables(results, opts)
    if opts.export_markdown:
        with open(opts.export_markdown, "w") as f:
            f.write(f"| Command | Mean [{unit}] | Min [{unit}] | Max [{unit}] | Relative |\n")
            f.write("|:---|---:|---:|---:|---:|\n")
            for c, mean, mn, mx, rel in rows:
                f.write(f"| `{c}` | {mean} | {mn} | {mx} | {rel} |\n")
    if opts.export_asciidoc:
        with open(opts.export_asciidoc, "w") as f:
            f.write('[cols="<,>,>,>,>"]\n|===\n')
            for h in ("Command", f"Mean [{unit}]", f"Min [{unit}]", f"Max [{unit}]", "Relative"):
                f.write(f"| {h} \n")
            f.write("\n")
            for c, mean, mn, mx, rel in rows:
                f.write(f"| `{c}` \n| {mean} \n| {mn} \n| {mx} \n| {rel} \n")
            f.write("|===\n")
    if opts.export_orgmode:
        with open(opts.export_orgmode, "w") as f:
            f.write(f"| Command  |  Mean [{unit}] |  Min [{unit}] |  Max [{unit}] |  Relative |\n")
            f.write("|--+--+--+--+--|\n")
            for c, mean, mn, mx, rel in rows:
                f.write(f"| ={c}=  |  {mean} |  {mn} |  {mx} |  {rel} |\n")


def main():
    opts = parse_args(sys.argv[1:])
    results = run_benchmarks(opts)
    write_exports(results, opts)


if __name__ == "__main__":
    main()
