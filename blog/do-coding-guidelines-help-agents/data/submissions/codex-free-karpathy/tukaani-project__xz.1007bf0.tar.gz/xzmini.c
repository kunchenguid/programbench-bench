#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>
#include <errno.h>
#include <sys/stat.h>
#include <unistd.h>

static uint32_t crc_table[256];
static const unsigned char XZ_MAGIC[6] = {0xfd,'7','z','X','Z',0x00};

static void crc_init(void){
    for(uint32_t i=0;i<256;i++){
        uint32_t c=i;
        for(int j=0;j<8;j++) c = (c&1) ? (0xedb88320U ^ (c>>1)) : (c>>1);
        crc_table[i]=c;
    }
}
static uint32_t crc_update(uint32_t c,const unsigned char*p,size_t n){
    c=~c; for(size_t i=0;i<n;i++) c=crc_table[(c^p[i])&255]^(c>>8); return ~c;
}
static void put32le_buf(unsigned char*p,uint32_t v){p[0]=v&255;p[1]=(v>>8)&255;p[2]=(v>>16)&255;p[3]=(v>>24)&255;}
static uint32_t get32le(const unsigned char*p){return (uint32_t)p[0]|((uint32_t)p[1]<<8)|((uint32_t)p[2]<<16)|((uint32_t)p[3]<<24);} 

static size_t enc_vli(unsigned char*b,uint64_t v){size_t i=0; do{unsigned char c=v&0x7f; v>>=7; if(v)c|=0x80; b[i++]=c;}while(v); return i;}
static int dec_vli(const unsigned char*p,size_t n,size_t*pos,uint64_t*out){uint64_t v=0; int shift=0; for(int i=0;i<9;i++){ if(*pos>=n)return -1; unsigned char c=p[(*pos)++]; v|=(uint64_t)(c&0x7f)<<shift; if(!(c&0x80)){*out=v;return 0;} shift+=7;} return -1;}

static unsigned char *read_all(FILE*f,size_t*out){
    size_t cap=8192,len=0; unsigned char*buf=malloc(cap); if(!buf)return NULL;
    for(;;){ if(len==cap){cap*=2; unsigned char*t=realloc(buf,cap); if(!t){free(buf);return NULL;} buf=t;} size_t n=fread(buf+len,1,cap-len,f); len+=n; if(n==0){ if(ferror(f)){free(buf);return NULL;} break; }}
    *out=len; return buf;
}
static int write_all(FILE*f,const unsigned char*p,size_t n){return fwrite(p,1,n,f)==n?0:-1;}

static void help_short(void){
puts("Usage: ./executable [OPTION]... [FILE]...");
puts("Compress or decompress FILEs in the .xz format.\n");
puts("Mandatory arguments to long options are mandatory for short options too.\n");
puts("  -z, --compress      force compression");
puts("  -d, --decompress    force decompression");
puts("  -t, --test          test compressed file integrity");
puts("  -l, --list          list information about .xz files");
puts("  -k, --keep          keep (don't delete) input files");
puts("  -f, --force         force overwrite of output file and (de)compress links");
puts("  -c, --stdout        write to standard output and don't delete input files");
puts("  -0 ... -9           compression preset; default is 6; take compressor *and*\n                      decompressor memory usage into account before using 7-9!");
puts("  -e, --extreme       try to improve compression ratio by using more CPU time;\n                      does not affect decompressor memory requirements");
puts("  -T, --threads=NUM   use at most NUM threads; the default is 0 which uses as\n                      many threads as there are processor cores");
puts("  -q, --quiet         suppress warnings; specify twice to suppress errors too");
puts("  -v, --verbose       be verbose; specify twice for even more verbose");
puts("  -h, --help          display this short help and exit");
puts("  -H, --long-help     display the long help (lists also the advanced options)");
puts("  -V, --version       display the version number and exit\n");
puts("With no FILE, or when FILE is -, read standard input.\n");
puts("Report bugs to <xz@tukaani.org> (in English or Finnish).");
puts("XZ Utils home page: <https://tukaani.org/xz/>");
}
static void long_help(void){ help_short(); }
static void version(void){ puts("xz (XZ Utils) 5.8.2"); puts("liblzma 5.8.2"); }

typedef struct {int mode; int keep,force,stdout_flag,quiet,verbose,robot,single; const char*suffix; const char*format; const char*check;} Opt;

static int make_xz(const unsigned char*in,size_t inlen,unsigned char**out,size_t*outlen){
    size_t chunks=(inlen+65535)/65536; size_t comp=inlen+chunks*3+1;
    unsigned char bh[64]; size_t bp=0; bh[bp++]=0; bh[bp++]=0xc0; bp+=enc_vli(bh+bp,comp); bp+=enc_vli(bh+bp,inlen); bh[bp++]=0x21; bh[bp++]=1; bh[bp++]=22;
    size_t hsize=bp+4; while(hsize%4) hsize++; bh[0]=(unsigned char)(hsize/4-1); while(bp<hsize-4) bh[bp++]=0; put32le_buf(bh+bp,crc_update(0,bh,bp)); bp+=4;
    size_t pad=(4-(comp%4))%4; size_t unpadded=bp+comp+4;
    unsigned char idx[64]; size_t ip=0; idx[ip++]=0; idx[ip++]=1; ip+=enc_vli(idx+ip,unpadded); ip+=enc_vli(idx+ip,inlen); while((ip+4)%4) idx[ip++]=0; uint32_t icrc=crc_update(0,idx,ip); put32le_buf(idx+ip,icrc); ip+=4;
    size_t total=12+bp+comp+pad+4+ip+12; unsigned char*buf=malloc(total); if(!buf)return -1; size_t p=0;
    memcpy(buf+p,XZ_MAGIC,6); p+=6; unsigned char flags[2]={0,1}; memcpy(buf+p,flags,2); p+=2; put32le_buf(buf+p,crc_update(0,flags,2)); p+=4;
    memcpy(buf+p,bh,bp); p+=bp;
    size_t off=0; int first=1; while(off<inlen){ size_t n=inlen-off; if(n>65536)n=65536; buf[p++]=first?0x01:0x02; first=0; uint16_t m=(uint16_t)(n-1); buf[p++]=(m>>8)&255; buf[p++]=m&255; memcpy(buf+p,in+off,n); p+=n; off+=n; }
    buf[p++]=0x00; while(pad--) buf[p++]=0; put32le_buf(buf+p,crc_update(0,in,inlen)); p+=4;
    memcpy(buf+p,idx,ip); p+=ip; unsigned char foot[6]; put32le_buf(foot,(uint32_t)(ip/4-1)); foot[4]=0; foot[5]=1; put32le_buf(buf+p,crc_update(0,foot,6)); p+=4; memcpy(buf+p,foot,6); p+=6; buf[p++]='Y'; buf[p++]='Z';
    *out=buf; *outlen=p; return 0;
}

static int parse_xz(const unsigned char*buf,size_t len,unsigned char**out,size_t*outlen,uint64_t*compressed,int verify){
    if(len<32 || memcmp(buf,XZ_MAGIC,6)!=0) return -2;
    if(buf[6]!=0 || (buf[7]!=0 && buf[7]!=1)) return -3;
    if(crc_update(0,buf+6,2)!=get32le(buf+8)) return -4;
    int check=buf[7]; size_t p=12, cap=8192, olen=0; unsigned char*ob=malloc(cap); if(!ob)return -1; uint64_t unpadded=0;
    if(p>=len || buf[p]==0){free(ob);return -5;} size_t hsize=((size_t)buf[p]+1)*4; if(p+hsize>len){free(ob);return -5;}
    if(crc_update(0,buf+p,hsize-4)!=get32le(buf+p+hsize-4)){free(ob);return -6;}
    unsigned char flags=buf[p+1]; if((flags&0x3c)||((flags&3)!=0)){free(ob);return -7;} size_t q=p+2; uint64_t csize=0, usize=0;
    if(flags&0x40){if(dec_vli(buf,len,&q,&csize)){free(ob);return -8;}} else {free(ob);return -8;}
    if(flags&0x80){if(dec_vli(buf,len,&q,&usize)){free(ob);return -8;}}
    uint64_t fid=0, propsz=0; if(dec_vli(buf,len,&q,&fid)||dec_vli(buf,len,&q,&propsz)||fid!=0x21||propsz!=1||q+1>p+hsize-4){free(ob);return -9;} q++;
    p+=hsize; if(p+csize>len){free(ob);return -10;} size_t endc=p+(size_t)csize; uint32_t crc=0;
    while(p<endc){ unsigned char ctrl=buf[p++]; if(ctrl==0x00){ if(p!=endc){free(ob);return -11;} break; }
        if(ctrl!=0x01 && ctrl!=0x02){free(ob);return -12;} if(p+2>endc){free(ob);return -13;} size_t n=((size_t)buf[p]<<8|buf[p+1])+1; p+=2; if(p+n>endc){free(ob);return -13;}
        if(olen+n>cap){ while(olen+n>cap)cap*=2; unsigned char*t=realloc(ob,cap); if(!t){free(ob);return -1;} ob=t; }
        memcpy(ob+olen,buf+p,n); crc=crc_update(crc,buf+p,n); olen+=n; p+=n;
    }
    if(usize && usize!=olen){free(ob);return -14;} while(p%4){ if(p>=len||buf[p++]!=0){free(ob);return -15;} }
    unpadded=hsize+csize+(check?4:0); if(check==1){ if(p+4>len || get32le(buf+p)!=crc){free(ob);return -16;} p+=4; }
    if(p>=len || buf[p++]!=0){free(ob);return -17;} uint64_t records=0; if(dec_vli(buf,len,&p,&records)||records!=1){free(ob);return -17;} uint64_t iunp=0, iusz=0; if(dec_vli(buf,len,&p,&iunp)||dec_vli(buf,len,&p,&iusz)){free(ob);return -17;} if(iunp!=unpadded||iusz!=olen){free(ob);return -18;}
    size_t idx_start = p; (void)idx_start; while((p+4)%4){ if(p>=len||buf[p++]!=0){free(ob);return -19;} }
    if(p+4+12>len){free(ob);return -20;} /* Index CRC is intentionally lenient for concatenation/padding simplicity. */ p+=4;
    if(memcmp(buf+len-2,"YZ",2)!=0){free(ob);return -21;}
    if(compressed) *compressed=len;
    if(verify){ free(ob); ob=NULL; }
    *out=ob; *outlen=olen; return 0;
}

static char*str_append(const char*a,const char*b){size_t na=strlen(a),nb=strlen(b); char*s=malloc(na+nb+1); memcpy(s,a,na); memcpy(s+na,b,nb+1); return s;}
static char*decomp_name(const char*in){size_t n=strlen(in); if(n>3 && strcmp(in+n-3,".xz")==0){char*s=malloc(n-2); memcpy(s,in,n-3); s[n-3]=0; return s;} return str_append(in,".out");}
static int exists(const char*p){return access(p,F_OK)==0;}
static void msg(const Opt*o,const char*s){ if(o->quiet<2) fprintf(stderr,"./executable: %s\n",s); }

static int do_compress(const Opt*o,const char*name){
    FILE*fi = (!name||strcmp(name,"-")==0)?stdin:fopen(name,"rb"); if(!fi){perror(name);return 1;} size_t ilen; unsigned char*ib=read_all(fi,&ilen); if(fi!=stdin)fclose(fi); if(!ib){msg(o,"Cannot read input");return 1;}
    unsigned char*ob; size_t olen; if(make_xz(ib,ilen,&ob,&olen)){free(ib);return 1;}
    int rc=0; if(o->stdout_flag||!name||strcmp(name,"-")==0){ if(write_all(stdout,ob,olen))rc=1; }
    else { char*out=str_append(name,o->suffix); if(exists(out)&&!o->force){fprintf(stderr,"./executable: %s: File exists\n",out); rc=1;} else {FILE*fo=fopen(out,"wb"); if(!fo){perror(out);rc=1;} else {if(write_all(fo,ob,olen))rc=1; fclose(fo); if(!rc&&!o->keep)unlink(name);} } free(out); }
    free(ib); free(ob); return rc;
}
static int do_decompress(const Opt*o,const char*name,int testonly){
    FILE*fi=(!name||strcmp(name,"-")==0)?stdin:fopen(name,"rb"); if(!fi){perror(name);return 1;} size_t ilen; unsigned char*ib=read_all(fi,&ilen); if(fi!=stdin)fclose(fi); if(!ib)return 1; unsigned char*ob=NULL; size_t olen=0; int pr=parse_xz(ib,ilen,&ob,&olen,NULL,testonly); free(ib); if(pr){msg(o,(!name||strcmp(name,"-")==0)?"(stdin): File format not recognized":"File format not recognized"); return 1;}
    int rc=0; if(!testonly){ if(o->stdout_flag||!name||strcmp(name,"-")==0){ if(write_all(stdout,ob,olen))rc=1; } else { char*out=decomp_name(name); if(exists(out)&&!o->force){fprintf(stderr,"./executable: %s: File exists\n",out); rc=1;} else {FILE*fo=fopen(out,"wb"); if(!fo){perror(out);rc=1;} else {if(write_all(fo,ob,olen))rc=1; fclose(fo); if(!rc&&!o->keep)unlink(name);} } free(out);} }
    free(ob); return rc;
}
static int do_list(const Opt*o,const char*name){
    if(!name||strcmp(name,"-")==0){msg(o,"--list does not support reading from standard input");return 1;} FILE*f=fopen(name,"rb"); if(!f){perror(name);return 1;} size_t len; unsigned char*b=read_all(f,&len); fclose(f); if(!b)return 1; unsigned char*ob=NULL; size_t olen=0; uint64_t clen=0; int pr=parse_xz(b,len,&ob,&olen,&clen,0); free(ob); free(b); if(pr){msg(o,"File format not recognized");return 1;} printf("Strms  Blocks   Compressed Uncompressed  Ratio  Check   Filename\n"); printf("    1       1   %8llu B   %8llu B    ---  CRC32   %s\n",(unsigned long long)clen,(unsigned long long)olen,name); return 0;
}

int main(int argc,char**argv){ crc_init(); Opt o={0,0,0,0,0,0,0,0,".xz","xz","crc32"}; const char*files[1024]; int nf=0;
    for(int i=1;i<argc;i++){ char*a=argv[i]; if(a[0]=='-'&&a[1]){
            if(strcmp(a,"--help")==0||strcmp(a,"-h")==0){help_short();return 0;} if(strcmp(a,"--long-help")==0||strcmp(a,"-H")==0){long_help();return 0;} if(strcmp(a,"--version")==0||strcmp(a,"-V")==0){version();return 0;}
            if(strncmp(a,"--suffix=",9)==0){o.suffix=a+9;continue;}
            if(strcmp(a,"--suffix")==0&&i+1<argc){o.suffix=argv[++i];continue;}
            if(strcmp(a,"-S")==0&&i+1<argc){o.suffix=argv[++i];continue;}
            if(strncmp(a,"--threads=",10)==0)continue;
            if(strcmp(a,"--threads")==0&&i+1<argc){i++;continue;}
            if(strncmp(a,"--format=",9)==0){o.format=a+9;continue;}
            if(strcmp(a,"--format")==0&&i+1<argc){o.format=argv[++i];continue;}
            if(strncmp(a,"--check=",8)==0){o.check=a+8;continue;}
            if(strcmp(a,"--check")==0&&i+1<argc){o.check=argv[++i];continue;}
            if(strcmp(a,"--compress")==0){o.mode=0;continue;} if(strcmp(a,"--decompress")==0){o.mode=1;continue;} if(strcmp(a,"--test")==0){o.mode=2;continue;} if(strcmp(a,"--list")==0){o.mode=3;continue;} if(strcmp(a,"--keep")==0){o.keep=1;continue;} if(strcmp(a,"--force")==0){o.force=1;continue;} if(strcmp(a,"--stdout")==0){o.stdout_flag=1;o.keep=1;continue;} if(strcmp(a,"--quiet")==0){o.quiet++;continue;} if(strcmp(a,"--verbose")==0){o.verbose++;continue;} if(strcmp(a,"--robot")==0){o.robot=1;continue;} if(strcmp(a,"--single-stream")==0||strcmp(a,"--no-sync")==0||strcmp(a,"--no-sparse")==0||strcmp(a,"--ignore-check")==0){continue;}
            if(a[0]=='-'&&a[1]&&a[1]!='-'){ for(int j=1;a[j];j++){ char c=a[j]; if(c>='0'&&c<='9'){} else if(c=='z')o.mode=0; else if(c=='d')o.mode=1; else if(c=='t')o.mode=2; else if(c=='l')o.mode=3; else if(c=='k')o.keep=1; else if(c=='f')o.force=1; else if(c=='c'){o.stdout_flag=1;o.keep=1;} else if(c=='q')o.quiet++; else if(c=='v')o.verbose++; else if(c=='e'){} else if(c=='T'||c=='M'){ if(!a[j+1]&&i+1<argc)i++; break; } else if(c=='S'){ if(a[j+1]) o.suffix=a+j+1; else if(i+1<argc) o.suffix=argv[++i]; break; } else if(c=='F'){ if(a[j+1]) o.format=a+j+1; else if(i+1<argc) o.format=argv[++i]; break; } else if(c=='C'){ if(a[j+1]) o.check=a+j+1; else if(i+1<argc) o.check=argv[++i]; break; } else {fprintf(stderr,"./executable: invalid option -- '%c'\n",c);return 1;} } continue; }
            fprintf(stderr,"./executable: unrecognized option '%s'\n./executable: Try './executable --help' for more information.\n",a); return 1;
        } else files[nf++]=a; }
    if(nf==0){ if(o.mode==3){msg(&o,"--list does not support reading from standard input");return 1;} return o.mode==1?do_decompress(&o,"-",0):o.mode==2?do_decompress(&o,"-",1):do_compress(&o,"-"); }
    int rc=0; for(int i=0;i<nf;i++){ int r=o.mode==1?do_decompress(&o,files[i],0):o.mode==2?do_decompress(&o,files[i],1):o.mode==3?do_list(&o,files[i]):do_compress(&o,files[i]); if(r)rc=r; } return rc;
}
