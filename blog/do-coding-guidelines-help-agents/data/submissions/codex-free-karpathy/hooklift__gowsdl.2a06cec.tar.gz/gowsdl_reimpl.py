#!/usr/bin/env python3
import os
import re
import sys
import urllib.request
import xml.etree.ElementTree as ET


XSD_NS = "http://www.w3.org/2001/XMLSchema"
WSDL_NS = "http://schemas.xmlsoap.org/wsdl/"
SOAP_NS = "http://schemas.xmlsoap.org/wsdl/soap/"


def local(tag):
    return tag.rsplit("}", 1)[-1] if "}" in tag else tag


def ns(tag):
    if tag.startswith("{"):
        return tag[1:].split("}", 1)[0]
    return ""


def children(el, name=None):
    out = [c for c in list(el) if name is None or local(c.tag) == name]
    return out


def first(el, name):
    for c in list(el):
        if local(c.tag) == name:
            return c
    return None


def qlocal(value):
    if not value:
        return ""
    return value.split(":", 1)[-1]


def export_name(name):
    if not name:
        return "X"
    pieces = re.split(r"([^A-Za-z0-9_]+)", name)
    result = ""
    for p in pieces:
        if not p or re.match(r"[^A-Za-z0-9_]+$", p):
            continue
        sub = p.split("_")
        fixed = []
        for s in sub:
            if not s:
                fixed.append(s)
            elif s.isupper():
                fixed.append(s)
            else:
                fixed.append(s[:1].upper() + s[1:])
        result += "_".join(fixed)
    result = re.sub(r"[^A-Za-z0-9_]", "", result)
    if not result:
        result = "X"
    if result[0].isdigit():
        result = "N" + result
    return result


def unexport_name(name):
    n = export_name(name)
    return n[:1].lower() + n[1:]


def const_suffix(value):
    parts = re.findall(r"[A-Za-z0-9]+", value)
    return "".join(export_name(p) for p in parts) or "Value"


def doc_text(el):
    ann = first(el, "annotation")
    if ann is None:
        return ""
    doc = first(ann, "documentation")
    if doc is None:
        return ""
    return " ".join("".join(doc.itertext()).split())


def collect_nsmap(text):
    nsmap = {}
    for m in re.finditer(r'\sxmlns(?::([^=\s]+))?="([^"]*)"', text):
        nsmap[m.group(1) or ""] = m.group(2)
    return nsmap


class Field:
    def __init__(self, name, go_type, xml_name=None, many=False, attr=False, doc="", chardata=False, namespace=""):
        self.name = name
        self.go_type = go_type
        self.xml_name = xml_name or name
        self.many = many
        self.attr = attr
        self.doc = doc
        self.chardata = chardata
        self.namespace = namespace


class TypeDef:
    def __init__(self, name, kind="struct", fields=None, alias=None, namespace="", doc="", enums=None, xmlname=True):
        self.name = name
        self.kind = kind
        self.fields = fields or []
        self.alias = alias
        self.namespace = namespace
        self.doc = doc
        self.enums = enums or []
        self.xmlname = xmlname


class Model:
    def __init__(self, xml_text):
        self.xml_text = xml_text
        self.root = ET.fromstring(xml_text)
        self.nsmap = collect_nsmap(xml_text)
        self.target_ns = self.root.attrib.get("targetNamespace", "")
        self.types = []
        self.type_by_name = {}
        self.messages = {}
        self.operations = []
        self.actions = {}

    def go_type(self, typ):
        raw = qlocal(typ)
        mapping = {
            "string": "string",
            "normalizedString": "string",
            "token": "string",
            "language": "string",
            "Name": "string",
            "NMTOKEN": "string",
            "ID": "string",
            "IDREF": "string",
            "boolean": "bool",
            "bool": "bool",
            "int": "int",
            "integer": "int",
            "long": "int64",
            "short": "int",
            "byte": "byte",
            "unsignedInt": "uint",
            "unsignedLong": "uint64",
            "unsignedShort": "uint",
            "unsignedByte": "byte",
            "float": "float32",
            "double": "float64",
            "decimal": "float64",
            "base64Binary": "[]byte",
            "hexBinary": "[]byte",
            "dateTime": "soap.XSDDateTime",
            "date": "soap.XSDDate",
            "time": "soap.XSDTime",
            "anyType": "AnyType",
            "anyURI": "AnyURI",
            "NCName": "NCName",
        }
        return mapping.get(raw, export_name(raw))

    def parse(self):
        for schema in self.root.iter():
            if local(schema.tag) != "schema":
                continue
            self.parse_schema(schema)
        self.parse_messages()
        self.parse_operations()

    def add_type(self, td):
        if td.name in {"AnyType", "AnyURI", "NCName"}:
            return
        if td.name not in self.type_by_name:
            self.types.append(td)
        self.type_by_name[td.name] = td

    def parse_schema(self, schema):
        schema_ns = schema.attrib.get("targetNamespace", self.target_ns)
        for node in list(schema):
            lname = local(node.tag)
            if lname == "simpleType" and node.attrib.get("name"):
                self.add_type(self.simple_type(node, export_name(node.attrib["name"]), schema_ns))
            elif lname == "complexType" and node.attrib.get("name"):
                self.add_type(self.complex_type(node, export_name(node.attrib["name"]), schema_ns, xmlname=False))
            elif lname == "element" and node.attrib.get("name"):
                name = export_name(node.attrib["name"])
                if "type" in node.attrib:
                    gt = self.go_type(node.attrib["type"])
                    self.add_type(TypeDef(name, kind="alias", alias=gt, namespace=schema_ns, doc=doc_text(node), xmlname=False))
                else:
                    ct = first(node, "complexType")
                    st = first(node, "simpleType")
                    if ct is not None:
                        td = self.complex_type(ct, name, schema_ns, xmlname=True)
                        td.doc = doc_text(node)
                        self.add_type(td)
                    elif st is not None:
                        self.add_type(self.simple_type(st, name, schema_ns, doc=doc_text(node)))
            elif lname == "attribute" and node.attrib.get("name"):
                st = first(node, "simpleType")
                if st is not None:
                    self.add_type(self.simple_type(st, export_name(node.attrib["name"]), schema_ns))

    def simple_type(self, node, name, schema_ns, doc=""):
        restriction = first(node, "restriction")
        base = restriction.attrib.get("base", "string") if restriction is not None else "string"
        enums = []
        if restriction is not None:
            for e in children(restriction, "enumeration"):
                enums.append((e.attrib.get("value", ""), doc_text(e)))
        return TypeDef(name, kind="simple", alias=self.go_type(base), namespace=schema_ns, doc=doc, enums=enums, xmlname=False)

    def complex_type(self, node, name, schema_ns, xmlname=False):
        fields = []
        sc = first(node, "simpleContent")
        if sc is not None:
            ext = first(sc, "extension")
            base = self.go_type(ext.attrib.get("base", "string")) if ext is not None else "string"
            fields.append(Field("Value", base, chardata=True))
            if ext is not None:
                fields.extend(self.parse_attributes(ext, schema_ns))
            return TypeDef(name, kind="struct", fields=fields, namespace=schema_ns, xmlname=xmlname)
        cc = first(node, "complexContent")
        if cc is not None:
            ext = first(cc, "extension")
            if ext is not None and ext.attrib.get("base"):
                fields.append(Field(export_name(qlocal(ext.attrib["base"])), self.go_type(ext.attrib["base"]), xml_name="-"))
                fields.extend(self.parse_particles(ext, schema_ns))
                fields.extend(self.parse_attributes(ext, schema_ns))
                return TypeDef(name, kind="struct", fields=fields, namespace=schema_ns, xmlname=xmlname)
        fields.extend(self.parse_particles(node, schema_ns))
        fields.extend(self.parse_attributes(node, schema_ns))
        return TypeDef(name, kind="struct", fields=fields, namespace=schema_ns, xmlname=xmlname)

    def parse_particles(self, node, schema_ns):
        fields = []
        for container in list(node):
            if local(container.tag) not in {"sequence", "all", "choice"}:
                continue
            for item in list(container):
                if local(item.tag) == "element":
                    fields.append(self.element_field(item, schema_ns))
                elif local(item.tag) in {"sequence", "all", "choice"}:
                    for sub in children(item, "element"):
                        fields.append(self.element_field(sub, schema_ns))
        return fields

    def element_field(self, item, schema_ns):
        name = item.attrib.get("name") or qlocal(item.attrib.get("ref", "Item"))
        many = item.attrib.get("maxOccurs") == "unbounded" or (item.attrib.get("maxOccurs", "1").isdigit() and int(item.attrib.get("maxOccurs", "1")) > 1)
        if "type" in item.attrib:
            gt = self.go_type(item.attrib["type"])
        else:
            ct = first(item, "complexType")
            st = first(item, "simpleType")
            if ct is not None:
                inline = export_name(name)
                gt = "struct {\n" + self.render_inline_fields(self.complex_type(ct, inline, schema_ns).fields) + "\t}"
            elif st is not None:
                gt = self.simple_type(st, export_name(name), schema_ns).alias
            else:
                gt = "string"
        if many and not gt.startswith("[]"):
            gt = "[]" + gt
        return Field(export_name(name), gt, xml_name=name, many=many, doc=doc_text(item), namespace="")

    def parse_attributes(self, node, schema_ns):
        out = []
        for a in children(node, "attribute"):
            name = a.attrib.get("name") or qlocal(a.attrib.get("ref", "attr"))
            gt = self.go_type(a.attrib.get("type", "string"))
            out.append(Field(export_name(name), gt, xml_name=name, attr=True, doc=doc_text(a), namespace=schema_ns))
        return out

    def render_inline_fields(self, fields):
        s = ""
        for f in fields:
            s += "\t\t" + self.field_line(f) + "\n"
        return s

    def parse_messages(self):
        for msg in self.root.iter():
            if local(msg.tag) != "message":
                continue
            part = first(msg, "part")
            if part is not None:
                self.messages[msg.attrib.get("name", "")] = qlocal(part.attrib.get("element") or part.attrib.get("type", ""))

    def parse_operations(self):
        for bindop in self.root.iter():
            if local(bindop.tag) == "operation":
                for c in list(bindop):
                    if local(c.tag) == "operation" and ns(c.tag) == SOAP_NS:
                        self.actions[bindop.attrib.get("name", "")] = c.attrib.get("soapAction", "''")
        for pt in self.root.iter():
            if local(pt.tag) != "portType":
                continue
            iface = export_name(pt.attrib.get("name", "Service"))
            for op in children(pt, "operation"):
                inp = first(op, "input")
                out = first(op, "output")
                in_msg = qlocal(inp.attrib.get("message", "")) if inp is not None else ""
                out_msg = qlocal(out.attrib.get("message", "")) if out is not None else ""
                self.operations.append({
                    "iface": iface,
                    "name": export_name(op.attrib.get("name", "Operation")),
                    "request": export_name(self.messages.get(in_msg, in_msg or "Request")),
                    "response": export_name(self.messages.get(out_msg, out_msg or "Response")),
                    "action": self.actions.get(op.attrib.get("name", ""), "''") or "''",
                })

    def field_line(self, f):
        if f.chardata:
            return f'{f.name} {f.go_type} `xml:",chardata" json:"-,"`'
        if f.xml_name == "-":
            return f"{f.name} {f.go_type}"
        tagname = f.xml_name
        if f.attr:
            if f.namespace:
                tagname = f"{f.namespace} {tagname}"
            tag = f'xml:"{tagname},attr,omitempty" json:"{f.xml_name},omitempty"'
        else:
            tag = f'xml:"{tagname},omitempty" json:"{tagname},omitempty"'
        return f"{f.name} {f.go_type} `{tag}`"

    def render_type(self, td):
        out = []
        if td.doc:
            out.append(f"// {td.doc}")
        if td.kind == "struct":
            out.append(f"type {td.name} struct {{")
            if td.xmlname:
                out.append(f'\tXMLName xml.Name `xml:"{td.namespace} {td.name}"`')
                out.append("")
            for f in td.fields:
                if f.doc:
                    out.append(f"\t// {f.doc}")
                line = self.field_line(f)
                if "\n" in line:
                    out.extend("\t" + part for part in line.rstrip().splitlines())
                else:
                    out.append("\t" + line)
                out.append("")
            if out[-1] == "":
                out.pop()
            out.append("}")
        elif td.kind == "simple":
            out.append(f"type {td.name} {td.alias}")
            if td.enums:
                out.append("")
                out.append("const (")
                out.append("")
                for val, doc in td.enums:
                    if doc:
                        out.append(f"\t// {doc}")
                    out.append(f'\t{td.name}{const_suffix(val)} {td.name} = "{val}"')
                    out.append("")
                out.append(")")
        elif td.kind == "alias":
            out.append(f"type {td.name} {td.alias}")
            if td.alias in {"soap.XSDDateTime", "soap.XSDDate", "soap.XSDTime"}:
                base = td.alias
                recv = td.name[:1].lower() + "dt"
                out.append("")
                out.append(f"func ({recv} {td.name}) MarshalXML(e *xml.Encoder, start xml.StartElement) error {{")
                out.append(f"\treturn {base}({recv}).MarshalXML(e, start)")
                out.append("}")
                out.append("")
                out.append(f"func ({recv} *{td.name}) UnmarshalXML(d *xml.Decoder, start xml.StartElement) error {{")
                out.append(f"\treturn (*{base})({recv}).UnmarshalXML(d, start)")
                out.append("}")
        return "\n".join(out)

    def client_go(self, package):
        uses_soap_dates = any("soap.XSD" in (t.alias or "") or any("soap.XSD" in f.go_type for f in t.fields) for t in self.types)
        out = [
            "// Code generated by gowsdl DO NOT EDIT.",
            "",
            f"package {package}",
            "",
            "import (",
            '\t"context"',
            '\t"encoding/xml"',
            '\t"github.com/hooklift/gowsdl/soap"',
            '\t"time"',
            ")",
            "",
            "// against \"unused imports\"",
            "var _ time.Time",
            "var _ xml.Name",
            "",
            "type AnyType struct {",
            '\tInnerXML string `xml:",innerxml"`',
            "}",
            "",
            "type AnyURI string",
            "",
            "type NCName string",
            "",
        ]
        for td in self.types:
            out.append(self.render_type(td))
            out.append("")
        by_iface = {}
        for op in self.operations:
            by_iface.setdefault(op["iface"], []).append(op)
        for iface, ops in by_iface.items():
            out.append(f"type {iface} interface {{")
            for op in ops:
                out.append(f"\t{op['name']}(request *{op['request']}) (*{op['response']}, error)")
                out.append("")
                out.append(f"\t{op['name']}Context(ctx context.Context, request *{op['request']}) (*{op['response']}, error)")
                out.append("")
            if out[-1] == "":
                out.pop()
            out.append("}")
            impl = unexport_name(iface)
            out.extend([
                "",
                f"type {impl} struct {{",
                "\tclient *soap.Client",
                "}",
                "",
                f"func New{iface}(client *soap.Client) {iface} {{",
                f"\treturn &{impl}{{",
                "\t\tclient: client,",
                "\t}",
                "}",
                "",
            ])
            for op in ops:
                out.extend([
                    f"func (service *{impl}) {op['name']}Context(ctx context.Context, request *{op['request']}) (*{op['response']}, error) {{",
                    f"\tresponse := new({op['response']})",
                    f'\terr := service.client.CallContext(ctx, "{op["action"]}", request, response)',
                    "\tif err != nil {",
                    "\t\treturn nil, err",
                    "\t}",
                    "",
                    "\treturn response, nil",
                    "}",
                    "",
                    f"func (service *{impl}) {op['name']}(request *{op['request']}) (*{op['response']}, error) {{",
                    f"\treturn service.{op['name']}Context(",
                    "\t\tcontext.Background(),",
                    "\t\trequest,",
                    "\t)",
                    "}",
                    "",
                ])
        return "\n".join(out).rstrip() + "\n"

    def server_go(self, package):
        reqs = []
        resps = {}
        for op in self.operations:
            if op["request"] not in reqs:
                reqs.append(op["request"])
            resps[op["request"]] = op["response"]
        raw = self.xml_text.replace("`", "` + \"`\" + `")
        out = [
            "// Code generated by gowsdl DO NOT EDIT.",
            "",
            f"package {package}",
            "",
            "import (",
            '\t"encoding/xml"',
            '\t"errors"',
            '\t"fmt"',
            '\t"net/http"',
            '\t"reflect"',
            '\t"strings"',
            ")",
            "",
            f"var wsdl = `{raw}`",
            "",
            'var WSDLUndefinedError = errors.New("Server was unable to process request. --> Object reference not set to an instance of an object.")',
            "",
            "type SOAPEnvelopeRequest struct {",
            '\tXMLName xml.Name `xml:"http://schemas.xmlsoap.org/soap/envelope/ Envelope"`',
            "\tBody    SOAPBodyRequest",
            "}",
            "",
            "type SOAPBodyRequest struct {",
            '\tXMLName xml.Name `xml:"http://schemas.xmlsoap.org/soap/envelope/ Body"`',
            "",
        ]
        for r in reqs:
            out.append(f"\t{r} *{r} `xml:,omitempty`")
        out.extend([
            "}",
            "",
            "type SOAPEnvelopeResponse struct {",
            '\tXMLName    xml.Name `xml:"soap:Envelope"`',
            '\tPrefixSoap string   `xml:"xmlns:soap,attr"`',
            '\tPrefixXsi  string   `xml:"xmlns:xsi,attr"`',
            '\tPrefixXsd  string   `xml:"xmlns:xsd,attr"`',
            "",
            "\tBody SOAPBodyResponse",
            "}",
            "",
            "func NewSOAPEnvelopResponse() *SOAPEnvelopeResponse {",
            "\treturn &SOAPEnvelopeResponse{",
            '\t\tPrefixSoap: "http://schemas.xmlsoap.org/soap/envelope/",',
            '\t\tPrefixXsd:  "http://www.w3.org/2001/XMLSchema",',
            '\t\tPrefixXsi:  "http://www.w3.org/2001/XMLSchema-instance",',
            "\t}",
            "}",
            "",
            "type Fault struct {",
            '\tXMLName xml.Name `xml:"SOAP-ENV:Fault"`',
            '\tSpace   string   `xml:"xmlns:SOAP-ENV,omitempty,attr"`',
            "",
            '\tCode   string `xml:"faultcode,omitempty"`',
            '\tString string `xml:"faultstring,omitempty"`',
            '\tActor  string `xml:"faultactor,omitempty"`',
            '\tDetail string `xml:"detail,omitempty"`',
            "}",
            "",
            "type SOAPBodyResponse struct {",
            '\tXMLName xml.Name `xml:"soap:Body"`',
            '\tFault   *Fault   `xml:",omitempty"`',
            "",
        ])
        for r in reqs:
            out.append(f'\t{r} *{resps.get(r, "AnyType")} `xml:",omitempty"`')
        out.append("}")
        out.append("")
        for r in reqs:
            out.extend([
                f"func (service *SOAPBodyRequest) {r}Func(request *{r}) (*{resps.get(r, 'AnyType')}, error) {{",
                "\treturn nil, WSDLUndefinedError",
                "}",
                "",
            ])
        out.extend([
            "func (service *SOAPEnvelopeRequest) call(w http.ResponseWriter, r *http.Request) {",
            '\tw.Header().Add("Content-Type", "text/xml; charset=utf-8")',
            "\tval := reflect.ValueOf(&service.Body).Elem()",
            "\tn := val.NumField()",
            "\tvar field reflect.Value",
            "\tvar name string",
            "\tfind := false",
            "",
            "\tif r.Method == http.MethodGet {",
            "\t\tw.Write([]byte(wsdl))",
            "\t\treturn",
            "\t}",
            "",
            "\tresp := NewSOAPEnvelopResponse()",
            "\tdefer func() {",
            "\t\tif r := recover(); r != nil {",
            "\t\t\tresp.Body.Fault = &Fault{}",
            '\t\t\tresp.Body.Fault.Space = "http://schemas.xmlsoap.org/soap/envelope/"',
            '\t\t\tresp.Body.Fault.Code = "soap:Server"',
            "\t\t\tresp.Body.Fault.Detail = fmt.Sprintf(\"%v\", r)",
            "\t\t\tresp.Body.Fault.String = fmt.Sprintf(\"%v\", r)",
            "\t\t}",
            "\t\txml.NewEncoder(w).Encode(resp)",
            "\t}()",
            "",
            '\theader := r.Header.Get("Content-Type")',
            '\tif strings.Index(header, "application/soap+xml") >= 0 {',
            '\t\tpanic("Could not find an appropriate Transport Binding to invoke.")',
            "\t}",
            "",
            "\terr := xml.NewDecoder(r.Body).Decode(service)",
            "\tif err != nil {",
            "\t\tpanic(err)",
            "\t}",
            "",
            "\tfor i := 0; i < n; i++ {",
            "\t\tfield = val.Field(i)",
            "\t\tname = val.Type().Field(i).Name",
            "\t\tif field.Kind() != reflect.Ptr {",
            "\t\t\tcontinue",
            "\t\t}",
            "\t\tif field.IsNil() {",
            "\t\t\tcontinue",
            "\t\t}",
            "\t\tif field.IsValid() {",
            "\t\t\tfind = true",
            "\t\t\tbreak",
            "\t\t}",
            "\t}",
            "",
            "\tif !find {",
            "\t\tpanic(WSDLUndefinedError)",
            "\t} else {",
            '\t\tm := val.Addr().MethodByName(name + "Func")',
            "\t\tif !m.IsValid() {",
            "\t\t\tpanic(WSDLUndefinedError)",
            "\t\t}",
            "",
            "\t\tvals := m.Call([]reflect.Value{field})",
            "\t\tif vals[1].IsNil() {",
            "\t\t\treflect.ValueOf(&resp.Body).Elem().FieldByName(name).Set(vals[0])",
            "\t\t} else {",
            "\t\t\tpanic(vals[1].Interface())",
            "\t\t}",
            "\t}",
            "",
            "}",
            "",
            "func Endpoint(w http.ResponseWriter, r *http.Request) {",
            "\trequest := SOAPEnvelopeRequest{}",
            "\trequest.call(w, r)",
            "}",
            "",
        ])
        return "\n".join(out)


def usage(prog):
    print(f"Usage: {prog} [options] myservice.wsdl")
    print("  -d string")
    print('\t\tDirectory under which package directory will be created (default "./")')
    print("  -i\tSkips TLS Verification")
    print("  -make-public")
    print("\t\tMake the generated types public/exported (default true)")
    print("  -o string")
    print('\t\tFile where the generated code will be saved (default "myservice.go")')
    print("  -p string")
    print('\t\tPackage under which code will be generated (default "myservice")')
    print("  -v\tShows gowsdl version")


def parse_args(argv):
    opts = {"-d": "./", "-o": "myservice.go", "-p": "myservice", "-i": False, "-make-public": True}
    args = []
    i = 0
    while i < len(argv):
        a = argv[i]
        if a in ("--help", "-h"):
            usage("./executable")
            sys.exit(0)
        if a.startswith("-d="):
            opts["-d"] = a.split("=", 1)[1]
            i += 1
            continue
        if a.startswith("-o="):
            opts["-o"] = a.split("=", 1)[1]
            i += 1
            continue
        if a.startswith("-p="):
            opts["-p"] = a.split("=", 1)[1]
            i += 1
            continue
        if a.startswith("-make-public="):
            opts["-make-public"] = a.split("=", 1)[1].lower() not in {"0", "false", "f"}
            i += 1
            continue
        if a == "-v":
            print("🍀  v0.5.0")
            sys.exit(0)
        if a in ("-i", "-make-public"):
            opts[a] = True
            i += 1
            continue
        if a in ("-d", "-o", "-p"):
            if i + 1 >= len(argv):
                print(f"flag needs an argument: {a}", file=sys.stderr)
                usage("./executable")
                sys.exit(2)
            opts[a] = argv[i + 1]
            i += 2
            continue
        if a.startswith("-") and a not in ("-",):
            print(f"flag provided but not defined: {a}")
            usage("./executable")
            sys.exit(2)
        args.append(a)
        i += 1
    return opts, args


def read_wsdl(path):
    if re.match(r"^https?://", path):
        with urllib.request.urlopen(path) as r:
            return r.read().decode("utf-8")
    full = path if os.path.isabs(path) else os.path.join(os.getcwd(), path)
    with open(full, "r", encoding="utf-8") as f:
        return f.read()


def main():
    opts, args = parse_args(sys.argv[1:])
    if not args:
        usage("./executable")
        return 0
    wsdl_path = args[-1]
    display = wsdl_path if os.path.isabs(wsdl_path) else os.path.join(os.getcwd(), wsdl_path)
    print(f"🍀  Reading file {display}")
    try:
        text = read_wsdl(wsdl_path)
        model = Model(text)
        model.parse()
        outdir = os.path.join(opts["-d"], opts["-p"])
        os.makedirs(outdir, exist_ok=True)
        client = os.path.join(outdir, opts["-o"])
        server = os.path.join(outdir, "server" + os.path.basename(opts["-o"]))
        with open(client, "w", encoding="utf-8") as f:
            f.write(model.client_go(opts["-p"]))
        with open(server, "w", encoding="utf-8") as f:
            f.write(model.server_go(opts["-p"]))
        print("🍀  Done 👍")
        return 0
    except Exception as e:
        print(f"🍀  {e}")
        return 1


if __name__ == "__main__":
    sys.exit(main())
