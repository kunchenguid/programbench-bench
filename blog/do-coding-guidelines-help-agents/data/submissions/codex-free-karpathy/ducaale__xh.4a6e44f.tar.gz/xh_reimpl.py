#!/usr/bin/env python3
import base64
import json
import os
import socket
import ssl
import sys
import urllib.parse

VERSION = "xh 0.25.3\n-native-tls +rustls"

HELP = """xh is a friendly and fast tool for sending HTTP requests

Usage: executable [OPTIONS] <[METHOD] URL> [REQUEST_ITEM]...

Arguments:
  <[METHOD] URL>     The request URL, preceded by an optional HTTP method
  [REQUEST_ITEM]...  Optional key-value pairs to be included in the request.

Options:
  -j, --json
          (default) Serialize data items from the command line as a JSON object
  -f, --form
          Serialize data items from the command line as form fields
      --multipart
          Like --form, but force a multipart/form-data request even without files
      --raw <RAW>
          Pass raw request data without extra processing
      --pretty <STYLE>
          Controls output processing [possible values: all, colors, format, none]
      --format-options <FORMAT_OPTIONS>
          Set output formatting options
  -s, --style <THEME>
          Output coloring style [possible values: auto, solarized, monokai, fruity]
      --response-charset <ENCODING>
          Override the response encoding for terminal display purposes
      --response-mime <MIME_TYPE>
          Override the response mime type for coloring and formatting for the terminal
  -p, --print <FORMAT>
          String specifying what the output should contain
  -h, --headers
          Print only the response headers. Shortcut for --print=h
  -b, --body
          Print only the response body. Shortcut for --print=b
  -m, --meta
          Print only the response metadata. Shortcut for --print=m
  -v, --verbose...
          Print the whole request as well as the response
      --debug
          Print full error stack traces and debug log messages
      --all
          Show any intermediary requests/responses while following redirects with --follow
  -P, --history-print <FORMAT>
          The same as --print but applies only to intermediary requests/responses
  -q, --quiet...
          Do not print to stdout or stderr
  -S, --stream
          Always stream the response body
  -x, --compress...
          Content compressed (encoded) with Deflate algorithm
  -o, --output <FILE>
          Save output to FILE instead of stdout
  -d, --download
          Download the body to a file instead of printing it
  -c, --continue
          Resume an interrupted download. Requires --download and --output
      --session <FILE>
          Create, or reuse and update a session
      --session-read-only <FILE>
          Create or read a session without updating it from the request/response exchange
  -A, --auth-type <AUTH_TYPE>
          Specify the auth mechanism [possible values: basic, bearer, digest]
  -a, --auth <USER[:PASS] | TOKEN>
          Authenticate as USER with PASS (-A basic|digest) or with TOKEN (-A bearer)
      --ignore-netrc
          Do not use credentials from .netrc
      --offline
          Construct HTTP requests without sending them anywhere
      --check-status
          (default) Exit with an error status code if the server replies with an error
  -F, --follow
          Do follow redirects
      --max-redirects <NUM>
          Number of redirects to follow. Only respected if --follow is used
      --timeout <SEC>
          Connection timeout of the request
      --proxy <PROTOCOL:URL>
          Use a proxy for a protocol. For example: --proxy https:http://proxy.host:8080
      --verify <VERIFY>
          If "no", skip SSL verification. If a file path, use it as a CA bundle
      --cert <FILE>
          Use a client side certificate for SSL
      --cert-key <FILE>
          A private key file to use with --cert
      --ssl <VERSION>
          Force a particular TLS version [possible values: auto, tls1, tls1.1, tls1.2, tls1.3]
      --https
          Make HTTPS requests if not specified in the URL
      --http-version <VERSION>
          HTTP version to use [possible values: 1.0, 1.1, 2, 2-prior-knowledge, 3-prior-knowledge]
      --resolve <HOST:ADDRESS>
          Override DNS resolution for specific domain to a custom IP
      --interface <NAME>
          Bind to a network interface or local IP address
  -4, --ipv4
          Resolve hostname to ipv4 addresses only
  -6, --ipv6
          Resolve hostname to ipv6 addresses only
      --unix-socket <FILE>
          Connect using a Unix domain socket
  -I, --ignore-stdin
          Do not attempt to read stdin
      --curl
          Print a translation to a curl command
      --curl-long
          Use the long versions of curl's flags
      --generate <KIND>
          Generate shell completions or man pages
      --help
          Print help
  -V, --version
          Print version

Each option can be reset with a --no-OPTION argument.

Run "xh help" for more complete documentation.
"""


class Opts:
    def __init__(self):
        self.mode = "json"
        self.raw = None
        self.print_fmt = None
        self.offline = False
        self.curl = False
        self.curl_long = False
        self.ignore_stdin = False
        self.https = False
        self.follow = False
        self.timeout = None
        self.output = None
        self.download = False
        self.quiet = 0
        self.auth = None
        self.auth_type = "basic"
        self.verify = None
        self.http_version = "1.1"


def fail(msg, code=1):
    print(f"error: {msg}", file=sys.stderr)
    sys.exit(code)


def shell_quote(s):
    if s == "":
        return "''"
    safe = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789_@%+:,./-"
    if all(c in safe for c in s):
        return s
    return "'" + s.replace("'", "'\\''") + "'"


def parse_args(argv):
    opts = Opts()
    pos = []
    i = 0
    value_opts = {
        "--raw", "--pretty", "--format-options", "--style", "--response-charset",
        "--response-mime", "--print", "-p", "--history-print", "-P", "--output",
        "-o", "--session", "--session-read-only", "--auth-type", "-A", "--auth",
        "-a", "--max-redirects", "--timeout", "--proxy", "--verify", "--cert",
        "--cert-key", "--ssl", "--http-version", "--resolve", "--interface",
        "--unix-socket", "--generate",
    }
    bool_opts = {
        "--json", "-j", "--form", "-f", "--multipart", "--headers", "-h",
        "--body", "-b", "--meta", "-m", "--verbose", "-v", "--debug", "--all",
        "--quiet", "-q", "--stream", "-S", "--compress", "-x", "--download",
        "-d", "--continue", "-c", "--ignore-netrc", "--offline", "--check-status",
        "--follow", "-F", "--https", "--native-tls", "--ipv4", "-4", "--ipv6",
        "-6", "--ignore-stdin", "-I", "--curl", "--curl-long", "--help", "-V",
        "--version",
    }
    while i < len(argv):
        a = argv[i]
        if a == "--":
            pos.extend(argv[i + 1:])
            break
        if a == "help":
            print(HELP)
            sys.exit(0)
        if a in ("--help",):
            print(HELP, end="")
            sys.exit(0)
        if a in ("-V", "--version"):
            print(VERSION)
            sys.exit(0)
        if a.startswith("--no-"):
            name = "--" + a[5:]
            if name == "--offline":
                opts.offline = False
            elif name == "--curl":
                opts.curl = False
            elif name == "--curl-long":
                opts.curl_long = False
            i += 1
            continue
        val = None
        key = a
        if a.startswith("--") and "=" in a:
            key, val = a.split("=", 1)
        if key in value_opts:
            if val is None:
                i += 1
                if i >= len(argv):
                    fail(f"a value is required for '{key}'", 2)
                val = argv[i]
            if key == "--raw":
                opts.raw = val
            elif key in ("--print", "-p"):
                opts.print_fmt = val
            elif key in ("--output", "-o"):
                opts.output = val
            elif key in ("--auth-type", "-A"):
                opts.auth_type = val
            elif key in ("--auth", "-a"):
                opts.auth = val
            elif key == "--timeout":
                opts.timeout = float(val)
            elif key == "--verify":
                opts.verify = val
            elif key == "--http-version":
                opts.http_version = val
            elif key == "--generate":
                generate(val)
                sys.exit(0)
            i += 1
            continue
        if a in bool_opts:
            if a in ("--json", "-j"):
                opts.mode = "json"
            elif a in ("--form", "-f"):
                opts.mode = "form"
            elif a == "--multipart":
                opts.mode = "multipart"
            elif a in ("--headers", "-h"):
                opts.print_fmt = "h"
            elif a in ("--body", "-b"):
                opts.print_fmt = "b"
            elif a in ("--meta", "-m"):
                opts.print_fmt = "m"
            elif a in ("--verbose", "-v"):
                opts.print_fmt = "HhBb"
            elif a in ("--quiet", "-q"):
                opts.quiet += 1
            elif a in ("--download", "-d"):
                opts.download = True
            elif a == "--offline":
                opts.offline = True
            elif a in ("--follow", "-F"):
                opts.follow = True
            elif a == "--https":
                opts.https = True
            elif a in ("--ignore-stdin", "-I"):
                opts.ignore_stdin = True
            elif a == "--curl":
                opts.curl = True
            elif a == "--curl-long":
                opts.curl = True
                opts.curl_long = True
            i += 1
            continue
        if a.startswith("-") and a != "-":
            # Support compact repeats such as -vv and -qq, and simple short flags.
            handled = True
            for ch in a[1:]:
                if ch == "v":
                    opts.print_fmt = "HhBb"
                elif ch == "q":
                    opts.quiet += 1
                elif ch == "I":
                    opts.ignore_stdin = True
                elif ch == "f":
                    opts.mode = "form"
                elif ch == "j":
                    opts.mode = "json"
                elif ch == "F":
                    opts.follow = True
                elif ch == "b":
                    opts.print_fmt = "b"
                elif ch == "h":
                    opts.print_fmt = "h"
                elif ch == "m":
                    opts.print_fmt = "m"
                else:
                    handled = False
                    break
            if handled:
                i += 1
                continue
            fail(f"unexpected argument '{a}' found", 2)
        pos.append(a)
        i += 1
    return opts, pos


def generate(kind):
    if kind == "man":
        try:
            with open("doc/xh.1", "r", encoding="utf-8") as f:
                data = f.read().replace("2025-12-16 0.25.2", "2026-06-15 0.25.3")
                print(data, end="")
        except OSError:
            print(".TH XH 1 2026-06-15 0.25.3 \"User Commands\"\n.SH NAME\nxh \\- Friendly and fast tool for sending HTTP requests")
    elif kind.startswith("complete-"):
        shell = kind.split("-", 1)[1]
        print(f"# completion script for executable ({shell})")
        print("complete -W '--json --form --offline --curl --help --version' executable")
    else:
        fail(f"invalid value '{kind}' for '--generate <KIND>'", 2)


def normalize_url(raw, https=False):
    if raw.startswith(":"):
        raw = "localhost" + (raw[1:] if raw.startswith(":/") else raw)
    if "://" not in raw:
        raw = ("https://" if https else "http://") + raw
    p = urllib.parse.urlsplit(raw)
    path = p.path or "/"
    query = p.query
    host = p.hostname or ""
    port = p.port
    netloc = p.netloc
    if "@" in netloc:
        hostpart = netloc.rsplit("@", 1)[1]
    else:
        hostpart = netloc
    return {
        "scheme": p.scheme,
        "host": host,
        "port": port or (443 if p.scheme == "https" else 80),
        "host_header": hostpart,
        "path": path,
        "query": query,
        "url": urllib.parse.urlunsplit((p.scheme, p.netloc, path, query, "")),
    }


def split_item(item):
    esc = False
    for i, ch in enumerate(item):
        if esc:
            esc = False
            continue
        if ch == "\\":
            esc = True
            continue
        if item.startswith(":=", i):
            return item[:i].replace("\\:", ":"), ":=", item[i + 2:]
        if item.startswith("==", i):
            return item[:i].replace("\\:", ":"), "==", item[i + 2:]
        if ch in "=:@;":
            return item[:i].replace("\\:", ":"), ch, item[i + 1:]
    return None, None, item


def read_value(v):
    if v.startswith("@"):
        with open(v[1:], "r", encoding="utf-8") as f:
            return f.read()
    return v


def parse_request(opts, pos):
    if not pos:
        print("error: the following required arguments were not provided:\n  <[METHOD] URL>\n", file=sys.stderr)
        print("Usage: executable <[METHOD] URL> [REQUEST_ITEM]...\n", file=sys.stderr)
        print("For more information, try '--help'.", file=sys.stderr)
        sys.exit(2)
    methods = {"GET", "POST", "PUT", "PATCH", "DELETE", "HEAD", "OPTIONS", "TRACE", "CONNECT"}
    method = None
    explicit_method = False
    if len(pos) >= 2 and pos[0].upper() in methods:
        method = pos[0].upper()
        explicit_method = True
        url_arg = pos[1]
        items = pos[2:]
    else:
        url_arg = pos[0]
        items = pos[1:]
    headers = []
    query = []
    fields = []
    literal_fields = []
    files = []
    body_file = None
    for item in items:
        if item.startswith("@") and len(item) > 1:
            body_file = item[1:]
            continue
        k, sep, v = split_item(item)
        if sep == "==":
            query.append((k, read_value(v)))
        elif sep == "=":
            fields.append((k, read_value(v)))
        elif sep == ":=":
            try:
                literal_fields.append((k, json.loads(v)))
            except Exception as e:
                fail(f"Invalid value for '[REQUEST_ITEM]...': \"{item}\" {e}", 2)
        elif sep == ":":
            if v == "":
                headers = [(hk, hv) for hk, hv in headers if hk.lower() != k.lower()]
            else:
                headers.append((k, read_value(v)))
        elif sep == ";":
            headers.append((k, ""))
        elif sep == "@":
            files.append((k, v))
        else:
            fail(f"Invalid value for '[REQUEST_ITEM]...': \"{item}\"", 2)
    stdin_body = None
    if not opts.ignore_stdin and not sys.stdin.isatty():
        stdin_body = sys.stdin.buffer.read()
    url = normalize_url(url_arg, opts.https)
    if query:
        q = urllib.parse.urlencode(query)
        url["query"] = (url["query"] + "&" if url["query"] else "") + q
        url["url"] = urllib.parse.urlunsplit((url["scheme"], url["host_header"], url["path"], url["query"], ""))
    has_data = bool(fields or literal_fields or files or opts.raw is not None or body_file or stdin_body is not None)
    if method is None:
        method = "POST" if has_data else "GET"
    body = b""
    content_type = None
    if opts.raw is not None:
        body = opts.raw.encode()
        content_type = "application/json"
    elif body_file:
        with open(body_file, "rb") as f:
            body = f.read()
        content_type = "text/plain"
    elif stdin_body is not None and not (fields or literal_fields):
        body = stdin_body
        content_type = "application/json" if body == b"" else "application/json"
    elif fields or literal_fields:
        if stdin_body not in (None, b""):
            fail("Request body (from stdin) and request data (key=value) cannot be mixed. Pass --ignore-stdin to ignore standard input.")
        if opts.mode == "form":
            body = urllib.parse.urlencode(fields + [(k, json.dumps(v, separators=(",", ":")) if not isinstance(v, str) else v) for k, v in literal_fields]).encode()
            content_type = "application/x-www-form-urlencoded"
        else:
            obj = {}
            for k, v in fields:
                obj[k] = v
            for k, v in literal_fields:
                obj[k] = v
            body = json.dumps(obj, separators=(",", ":")).encode()
            content_type = "application/json"
    elif files:
        boundary = "xh-boundary"
        parts = []
        for name, fn in files:
            with open(fn, "rb") as f:
                data = f.read()
            base = os.path.basename(fn.split(";", 1)[0])
            parts.append(b"--" + boundary.encode() + b"\r\n")
            parts.append(f'Content-Disposition: form-data; name="{name}"; filename="{base}"\r\n\r\n'.encode())
            parts.append(data + b"\r\n")
        parts.append(b"--" + boundary.encode() + b"--\r\n")
        body = b"".join(parts)
        content_type = f"multipart/form-data; boundary={boundary}"
    default_headers = [
        ("Accept-Encoding", "gzip, deflate, br, zstd"),
        ("User-Agent", "xh/0.25.3"),
        ("Connection", "keep-alive"),
    ]
    hdrs = default_headers[:]
    for hk, hv in headers:
        replaced = False
        new_hdrs = []
        for a, b in hdrs:
            if a.lower() == hk.lower():
                if not replaced:
                    new_hdrs.append((hk, hv))
                    replaced = True
            else:
                new_hdrs.append((a, b))
        if not replaced:
            new_hdrs.append((hk, hv))
        hdrs = new_hdrs
    if opts.auth:
        if opts.auth_type == "bearer":
            hdrs.append(("Authorization", "Bearer " + opts.auth))
        else:
            token = base64.b64encode(opts.auth.encode()).decode()
            hdrs.append(("Authorization", "Basic " + token))
    if content_type:
        accept = "application/json, */*;q=0.5" if content_type == "application/json" else "*/*"
        hdrs.append(("Content-Type", content_type))
        if content_type == "application/x-www-form-urlencoded":
            hdrs.append(("Accept", accept))
        else:
            hdrs.append(("Accept", accept))
            hdrs[-1], hdrs[-2] = hdrs[-2], hdrs[-1]
        if content_type != "text/plain" or body_file is None:
            hdrs.append(("Content-Length", str(len(body))))
    else:
        hdrs.append(("Accept", "*/*"))
    hdrs.append(("Host", url["host_header"]))
    return method, url, hdrs, body, content_type, explicit_method


def render_request(method, url, headers, body):
    target = url["path"] + (("?" + url["query"]) if url["query"] else "")
    lines = [f"{method} {target} HTTP/1.1"]
    lines += [f"{k}: {v}" for k, v in headers]
    out = "\n".join(lines) + "\n\n"
    if body:
        out += body.decode("utf-8", "replace")
        out += "\n\n"
    return out


def curl_command(opts, method, url, headers, body, content_type, explicit_method=False):
    cmd = ["curl"]
    if opts.follow:
        cmd.append("--location" if opts.curl_long else "-L")
    if opts.verify in ("no", "false"):
        cmd.append("--insecure" if opts.curl_long else "-k")
    if opts.timeout is not None:
        cmd += ["--max-time" if opts.curl_long else "--max-time", str(int(opts.timeout) if opts.timeout.is_integer() else opts.timeout)]
    use_method = explicit_method or method != "GET" or body
    if use_method:
        cmd += ["--request" if opts.curl_long else "-X", method]
    cmd.append(url["url"])
    skip = {"host", "user-agent", "connection", "accept-encoding", "content-length", "authorization"}
    curl_headers = []
    for k, v in headers:
        lk = k.lower()
        if lk in skip:
            continue
        if lk == "accept" and v == "*/*":
            continue
        if lk == "content-type" and content_type == "application/x-www-form-urlencoded":
            continue
        curl_headers.append((k, v))
    if content_type == "application/json":
        curl_headers.sort(key=lambda kv: 0 if kv[0].lower() == "content-type" else 1)
    for k, v in curl_headers:
        flag = "--header" if opts.curl_long else "-H"
        cmd += [flag, f"{k.lower()}: {v}" if k in ("Content-Type", "Accept") else f"{k}: {v}"]
    if opts.auth:
        if opts.auth_type == "basic":
            cmd += ["--basic" if opts.curl_long else "--basic", "--user" if opts.curl_long else "-u", opts.auth]
        elif opts.auth_type == "bearer":
            pass
    if body:
        if content_type == "application/x-www-form-urlencoded":
            for pair in body.decode().split("&"):
                cmd += ["--data-urlencode", urllib.parse.unquote_plus(pair)]
        else:
            cmd += ["--data" if opts.curl_long else "-d", body.decode("utf-8", "replace")]
    return " ".join(shell_quote(str(x)) for x in cmd)


def http_request(opts, method, url, headers, body):
    target = url["path"] + (("?" + url["query"]) if url["query"] else "")
    req = f"{method} {target} HTTP/{opts.http_version if opts.http_version in ('1.0','1.1') else '1.1'}\r\n"
    req += "".join(f"{k}: {v}\r\n" for k, v in headers)
    req += "\r\n"
    s = socket.create_connection((url["host"], url["port"]), timeout=opts.timeout or None)
    if url["scheme"] == "https":
        ctx = ssl._create_unverified_context() if opts.verify in ("no", "false") else ssl.create_default_context()
        s = ctx.wrap_socket(s, server_hostname=url["host"])
    s.sendall(req.encode() + body)
    chunks = []
    while True:
        data = s.recv(65536)
        if not data:
            break
        chunks.append(data)
    s.close()
    raw = b"".join(chunks)
    head, _, resp_body = raw.partition(b"\r\n\r\n")
    status_line = head.split(b"\r\n", 1)[0].decode("iso-8859-1", "replace")
    raw_lines = head.decode("iso-8859-1", "replace").split("\r\n")
    fixed = [raw_lines[0]]
    canonical = {
        "content-type": "Content-Type",
        "content-length": "Content-Length",
        "last-modified": "Last-Modified",
        "etag": "ETag",
        "server": "Server",
        "date": "Date",
        "location": "Location",
        "set-cookie": "Set-Cookie",
        "connection": "Connection",
    }
    for line in raw_lines[1:]:
        if ":" in line:
            k, v = line.split(":", 1)
            line = canonical.get(k.lower(), "-".join(part.capitalize() for part in k.split("-"))) + ":" + v
        fixed.append(line)
    hdr_text = "\n".join(fixed)
    code = 0
    try:
        status = int(status_line.split()[1])
        if 400 <= status < 500:
            code = 4
        elif 500 <= status:
            code = 5
        elif 300 <= status < 400 and not opts.follow:
            code = 3
    except Exception:
        pass
    fmt = opts.print_fmt or "hb"
    out = ""
    if "H" in fmt or "B" in fmt:
        if "H" in fmt:
            out += render_request(method, url, headers, body)
    if "h" in fmt:
        out += hdr_text + "\n\n"
    if "b" in fmt:
        out += resp_body.decode("utf-8", "replace")
    return out, code


def main():
    opts, pos = parse_args(sys.argv[1:])
    method, url, headers, body, content_type, explicit_method = parse_request(opts, pos)
    if opts.quiet:
        sys.exit(0)
    if opts.curl:
        print(curl_command(opts, method, url, headers, body, content_type, explicit_method))
        return
    if opts.offline:
        out = render_request(method, url, headers, body)
        if opts.output:
            with open(opts.output, "w", encoding="utf-8") as f:
                f.write(out)
        else:
            print(out, end="")
        return
    try:
        out, code = http_request(opts, method, url, headers, body)
        if opts.output:
            mode = "wb" if opts.download else "w"
            with open(opts.output, mode) as f:
                f.write(out.encode() if "b" in mode else out)
        else:
            print(out, end="")
        sys.exit(code)
    except Exception as e:
        print(f"error: {e}", file=sys.stderr)
        sys.exit(1)


if __name__ == "__main__":
    main()
