#!/usr/bin/env python3
import argparse
import difflib
import fnmatch
import json
import os
import re
import sys
from pathlib import Path

VERSION = "rumdl 0.1.13"

RULES = [
 ("MD001","heading-increment","Heading levels should only increment by one level at a time","heading",False),
 ("MD003","heading-style","Heading style","heading",True),
 ("MD004","ul-style","Use consistent style for unordered list markers","list",True),
 ("MD005","list-indent","List indentation should be consistent","list",False),
 ("MD007","ul-indent","Unordered list indentation","list",True),
 ("MD009","no-trailing-spaces","Trailing spaces should be removed","whitespace",True),
 ("MD010","no-hard-tabs","No tabs","whitespace",True),
 ("MD011","no-reversed-links","Reversed link syntax","link",True),
 ("MD012","no-multiple-blanks","Multiple consecutive blank lines","whitespace",True),
 ("MD013","line-length","Line length should not be excessive","whitespace",False),
 ("MD014","commands-show-output","Commands in code blocks should show output","code-block",True),
 ("MD018","no-missing-space-atx","No space after hash in heading","heading",True),
 ("MD019","no-multiple-space-atx","Multiple spaces after hash in heading","heading",True),
 ("MD020","no-missing-space-closed-atx","No space inside hashes on closed heading","heading",True),
 ("MD021","no-multiple-space-closed-atx","Multiple spaces inside hashes on closed heading","heading",True),
 ("MD022","blanks-around-headings","Headings should be surrounded by blank lines","heading",True),
 ("MD023","heading-start-left","Headings must start at the beginning of the line","heading",True),
 ("MD024","no-duplicate-heading","Multiple headings with the same content","heading",False),
 ("MD025","single-title","Multiple top-level headings in the same document","heading",True),
 ("MD026","no-trailing-punctuation","Trailing punctuation in heading","heading",True),
 ("MD027","no-multiple-space-blockquote","Multiple spaces after quote marker (>)","blockquote",True),
 ("MD028","no-blanks-blockquote","Blank line inside blockquote","other",False),
 ("MD029","ol-prefix","Ordered list marker value","list",True),
 ("MD030","list-marker-space","Spaces after list markers should be consistent","list",True),
 ("MD031","blanks-around-fences","Fenced code blocks should be surrounded by blank lines","code-block",True),
 ("MD032","blanks-around-lists","Lists should be surrounded by blank lines","list",True),
 ("MD033","no-inline-html","Inline HTML is not allowed","html",False),
 ("MD034","no-bare-urls","No bare URLs - wrap URLs in angle brackets","link",True),
 ("MD035","hr-style","Horizontal rule style","other",True),
 ("MD036","no-emphasis-as-heading","Emphasis should not be used instead of a heading","emphasis",False),
 ("MD037","no-space-in-emphasis","Spaces inside emphasis markers","other",True),
 ("MD038","no-space-in-code","Spaces inside code span elements","other",True),
 ("MD039","no-space-in-links","Spaces inside link text","link",True),
 ("MD040","fenced-code-language","Code blocks should have a language specified","code-block",False),
 ("MD041","first-line-heading","First line in file should be a top level heading","heading",False),
 ("MD042","no-empty-links","No empty links","link",False),
 ("MD043","required-headings","Required heading structure","heading",False),
 ("MD044","proper-names","Proper names should have the correct capitalization","other",False),
 ("MD045","no-alt-text","Images should have alternate text (alt text)","link",True),
 ("MD046","code-block-style","Code blocks should use a consistent style","code-block",True),
 ("MD047","single-trailing-newline","Files should end with a single newline character","other",True),
 ("MD048","code-fence-style","Code fence style should be consistent","other",True),
 ("MD049","emphasis-style","Emphasis style should be consistent","other",True),
 ("MD050","strong-style","Strong emphasis style should be consistent","other",True),
 ("MD051","link-fragments","Link fragments should reference valid headings","link",False),
 ("MD052","reference-links-images","Reference links and images should use a reference that exists","other",False),
 ("MD053","link-image-reference-definitions","Link and image reference definitions should be needed","other",False),
 ("MD054","link-image-style","Link and image style should be consistent","other",False),
 ("MD055","table-pipe-style","Table pipe style should be consistent","other",True),
 ("MD056","table-column-count","Table column count should be consistent","other",False),
 ("MD057","relative-links","Relative links should point to existing files","other",False),
 ("MD058","blanks-around-tables","Tables should be surrounded by blank lines","other",True),
 ("MD059","descriptive-link-text","Link text should be descriptive","other",False),
 ("MD060","table-format","Table columns should be consistently aligned","other",True),
 ("MD061","forbidden-terms","Forbidden terms","other",False),
 ("MD062","link-destination-whitespace","Link destination should not have leading or trailing whitespace","other",True),
 ("MD063","heading-capitalization","Heading capitalization","other",True),
 ("MD064","no-multiple-spaces","Multiple consecutive spaces","whitespace",True),
 ("MD065","blanks-around-hr","Horizontal rules should be surrounded by blank lines","other",True),
 ("MD066","footnote","Footnote validation","other",False),
 ("MD067","footnote-order","Footnote definitions should appear in order of first reference","other",False),
 ("MD068","no-empty-footnotes","Footnote definitions should not be empty","other",False),
 ("MD069","no-duplicate-list-markers","Duplicate list markers","list",False),
 ("MD070","nested-fence-collision","Nested code fence collision - use longer fence to avoid premature closure","other",False),
 ("MD071","blank-line-after-frontmatter","Blank line after frontmatter","front-matter",True),
 ("MD072","frontmatter-key-sort","Frontmatter keys should be sorted alphabetically","other",True),
 ("MD073","toc","Table of Contents should match document headings","other",False),
]
RULE = {r[0]: r for r in RULES}
ALIASES = {r[1]: r[0] for r in RULES}
DEFAULT_DISABLED = {"MD060","MD063","MD072","MD073"}

def help_main():
    print("""A fast Markdown linter written in Rust (Ru(st) MarkDown Linter)

Usage: executable [OPTIONS] <COMMAND>

Commands:
  check        Lint Markdown files and print warnings/errors
  fmt          Format Markdown files (alias for check --fix)
  init         Initialize a new configuration file
  rule         Show information about a rule or list all rules
  explain      Explain a rule with detailed information and examples
  config       Show configuration or query a specific key
  server       Start the Language Server Protocol server
  schema       Generate or check JSON schema for rumdl.toml
  import       Import and convert markdownlint configuration files
  vscode       Install the rumdl VS Code extension
  completions  Generate shell completion scripts
  clean        Clear the cache
  version      Show version information
  help         Print this message or the help of the given subcommand(s)

Options:
      --color <COLOR>    Control colored output: auto, always, never [default: auto] [possible values: auto, always, never]
      --config <CONFIG>  Path to configuration file
      --no-config        Ignore all configuration files and use built-in defaults
      --isolated         Ignore all configuration files (alias for --no-config)
  -h, --help             Print help
  -V, --version          Print version""")

def check_help(fmt=False):
    name = "fmt" if fmt else "check"
    desc = "Format Markdown files (alias for check --fix)" if fmt else "Lint Markdown files and print warnings/errors"
    print(f"""{desc}

Usage: executable {name} [OPTIONS] [PATHS]...

Arguments:
  [PATHS]...  Files or directories to lint (use '-' for stdin)

Options:
  -f, --fix                       Fix issues automatically where possible
      --diff                      Show diff of what would be fixed instead of fixing files
      --check                     Exit with code 1 if any formatting changes would be made (for CI)
  -l, --list-rules                List all available rules
  -d, --disable <DISABLE>         Disable specific rules (comma-separated)
  -e, --enable <ENABLE>           Enable only specific rules (comma-separated) [aliases: --rules]
      --extend-enable <RULES>     Extend the list of enabled rules
      --extend-disable <RULES>    Extend the list of disabled rules
  -o, --output <OUTPUT>           Output format: text (default) or json [default: text]
      --output-format <FORMAT>    Output format
      --stdin                     Read from stdin instead of files
      --stdin-filename <NAME>     Filename to use when reading from stdin
  -q, --quiet                     Print diagnostics, but nothing else
  -s, --silent                    Disable all logging
  -h, --help                      Print help""")

class Issue:
    __slots__ = ("file","line","col","rule","msg","fixable")
    def __init__(self, file, line, col, rule, msg, fixable=False):
        self.file=file; self.line=line; self.col=col; self.rule=rule; self.msg=msg; self.fixable=fixable
    def text(self, fixed=False):
        suffix = " [fixed]" if fixed else (" [*]" if self.fixable else "")
        return f"{self.file}:{self.line}:{self.col}: [{self.rule}] {self.msg}{suffix}"
    def obj(self):
        return {"file":self.file,"line":self.line,"column":self.col,"rule":self.rule,
                "message":self.msg,"severity":"warning","fixable":self.fixable,"fix":None}

def split_rules(s):
    out = set()
    for x in (s or "").replace(";", ",").split(","):
        x=x.strip()
        if not x: continue
        x=x.upper() if x.upper().startswith("MD") else ALIASES.get(x, x.upper())
        if re.fullmatch(r"\d+", x): x = "MD" + x.zfill(3)
        out.add(x)
    return out

def load_config(args):
    cfg = {"disabled": set(DEFAULT_DISABLED), "enabled_only": None, "line_length":80}
    paths = []
    if getattr(args, "config", None): paths.append(Path(args.config))
    elif not getattr(args, "no_config", False):
        for p in [Path(".rumdl.toml"), Path("rumdl.toml"), Path("pyproject.toml")]:
            if p.exists(): paths.append(p); break
    for p in paths:
        try: text = p.read_text()
        except Exception: continue
        m = re.search(r"(?m)^\s*disable\s*=\s*\[(.*?)\]", text, re.S)
        if m: cfg["disabled"] |= set(re.findall(r'"([^"]+)"', m.group(1)))
        m = re.search(r"(?m)^\s*enable\s*=\s*\[(.*?)\]", text, re.S)
        if m:
            vals = set(re.findall(r'"([^"]+)"', m.group(1)))
            if vals: cfg["enabled_only"] = vals
        m = re.search(r"(?m)^\s*(?:line-length|line_length)\s*=\s*(\d+)", text)
        if m: cfg["line_length"] = int(m.group(1))
    dis = split_rules(getattr(args, "disable", "") or getattr(args, "extend_disable", ""))
    ext_en = split_rules(getattr(args, "extend_enable", ""))
    en = split_rules(getattr(args, "enable", ""))
    if en: cfg["enabled_only"] = en
    cfg["disabled"] |= dis
    cfg["disabled"] -= ext_en
    return cfg

def is_heading(line):
    return re.match(r"^( {0,3})(#{1,6})(\s+|$)(.*?)\s*#*\s*$", line)

def heading_text(line):
    m = is_heading(line)
    if not m: return ""
    return re.sub(r"\s+#+\s*$", "", m.group(4)).strip()

def in_code_states(lines):
    states=[]; in_code=False; fence=""
    for line in lines:
        stripped=line.lstrip()
        states.append(in_code)
        m=re.match(r"(```+|~~~+)", stripped)
        if m:
            mark=m.group(1)
            if not in_code: in_code=True; fence=mark[0]
            elif mark[0]==fence: in_code=False
    return states

def apply_inline_config(lines, issues):
    disabled=set(); result=[]; byline={}
    for i,l in enumerate(lines,1):
        low=l.lower()
        if "rumdl-disable" in low:
            part=l.split("rumdl-disable",1)[1]
            rs=split_rules(part) or set(RULE)
            disabled |= rs
        if "rumdl-enable" in low:
            part=l.split("rumdl-enable",1)[1]
            rs=split_rules(part) or set(RULE)
            disabled -= rs
        byline[i]=set(disabled)
    for iss in issues:
        if iss.rule not in byline.get(iss.line,set()):
            result.append(iss)
    return result

def lint_text(text, display, enabled, line_length=80):
    lines=text.splitlines(True)
    bare=[l[:-1] if l.endswith("\n") else l for l in lines]
    if text and not lines: bare=[text]
    issues=[]; code=in_code_states([b.rstrip("\r") for b in bare])
    first_content = next((i for i,b in enumerate(bare,1) if b.strip() and not b.strip().startswith("<!--")), None)
    if "MD041" in enabled and first_content and not re.match(r"^#\s+", bare[first_content-1]):
        issues.append(Issue(display, first_content, 1, "MD041", "First line in file should be a level 1 heading"))
    last_level=0; h1=0; seen_heads=set()
    for idx,b in enumerate(bare,1):
        line=b.rstrip("\r")
        if "MD009" in enabled:
            m=re.search(r"[ \t]+$", line)
            if m:
                n=len(m.group(0))
                issues.append(Issue(display, idx, len(line)-n+1, "MD009", f"{n} trailing spaces found", True))
        if "MD010" in enabled and "\t" in line:
            issues.append(Issue(display, idx, line.index("\t")+1, "MD010", "Hard tab found", True))
        if "MD013" in enabled and line_length and len(line.expandtabs(4))>line_length and not (line.strip().startswith("|") and line.strip().endswith("|")):
            issues.append(Issue(display, idx, line_length+1, "MD013", f"Line length {len(line.expandtabs(4))} exceeds {line_length} characters"))
        if code[idx-1]: continue
        if "MD018" in enabled and re.match(r"^ {0,3}#{1,6}[^#\s]", line):
            col=len(re.match(r"^ *#+", line).group(0))+1
            issues.append(Issue(display, idx, col, "MD018", "No space after hash on atx style heading", True))
        if "MD019" in enabled and re.match(r"^ {0,3}#{1,6}  +", line):
            col=len(re.match(r"^ *#+", line).group(0))+1
            issues.append(Issue(display, idx, col, "MD019", "Multiple spaces after hash on atx style heading", True))
        hm=is_heading(line)
        if hm:
            level=len(hm.group(2)); txt=heading_text(line)
            if "MD001" in enabled and last_level and level > last_level+1:
                issues.append(Issue(display, idx, 1, "MD001", f"Heading levels should only increment by one level at a time (expected H{last_level+1}, got H{level})", True))
            last_level=level
            if "MD022" in enabled:
                if idx>1 and bare[idx-2].strip():
                    issues.append(Issue(display, idx, 1, "MD022", "Expected 1 blank line above heading", True))
                if idx<len(bare) and bare[idx].strip():
                    issues.append(Issue(display, idx, 1, "MD022", "Expected 1 blank line below heading", True))
            if "MD023" in enabled and hm.group(1):
                issues.append(Issue(display, idx, 1, "MD023", "Heading must start at the beginning of the line", True))
            if "MD025" in enabled and level==1:
                h1 += 1
                if h1>1: issues.append(Issue(display, idx, len(hm.group(1))+len(hm.group(2))+1, "MD025", "Multiple top-level headings (level 1) in the same document", True))
            if "MD024" in enabled:
                key=re.sub(r"\s+"," ",txt.lower())
                if key in seen_heads and key:
                    issues.append(Issue(display, idx, 1, "MD024", "Multiple headings with the same content"))
                seen_heads.add(key)
            if "MD026" in enabled and txt and txt[-1] in ".,;:!":
                issues.append(Issue(display, idx, line.rfind(txt[-1])+1, "MD026", "Trailing punctuation in heading", True))
        if "MD031" in enabled and re.match(r"^ {0,3}(```|~~~)", line):
            if idx>1 and bare[idx-2].strip() and not re.match(r"^ {0,3}(```|~~~)", bare[idx-2]):
                issues.append(Issue(display, idx, 1, "MD031", "Fenced code blocks should be surrounded by blank lines", True))
        if "MD040" in enabled:
            m=re.match(r"^ {0,3}(```+|~~~+)\s*$", line)
            if m:
                issues.append(Issue(display, idx, len(m.group(1))+1, "MD040", "Fenced code blocks should have a language specified"))
        if "MD032" in enabled and re.match(r"^\s*([-+*]|\d+[.)])\s+", line):
            if idx>1 and bare[idx-2].strip() and not re.match(r"^\s*([-+*]|\d+[.)])\s+", bare[idx-2]):
                issues.append(Issue(display, idx, 1, "MD032", "List should be preceded by blank line", True))
        if "MD033" in enabled and re.search(r"</?[A-Za-z][^>]*>", line):
            issues.append(Issue(display, idx, max(1,line.find("<")+1), "MD033", "Inline HTML"))
        if "MD034" in enabled:
            m=re.search(r"(?<![<(])(https?://[^\s>)]+)", line)
            if m: issues.append(Issue(display, idx, m.start(1)+1, "MD034", "Bare URL used", True))
        if "MD042" in enabled:
            m=re.search(r"!?\[[^\]]*\]\(\s*\)", line)
            if m: issues.append(Issue(display, idx, m.start()+1, "MD042", "No empty links"))
        if "MD045" in enabled:
            m=re.search(r"!\[\s*\]\([^)]+\)", line)
            if m: issues.append(Issue(display, idx, m.start()+1, "MD045", "Images should have alternate text (alt text)", True))
        if "MD064" in enabled and not code[idx-1]:
            for m in re.finditer(r"(?<![.!?]) {2,}(?! )", line):
                if not re.match(r"^ {2,}", line[m.start():]): 
                    issues.append(Issue(display, idx, m.start()+1, "MD064", f"Multiple consecutive spaces ({len(m.group(0))}) found", True))
    if "MD012" in enabled:
        run=0
        for idx,b in enumerate(bare,1):
            if not b.strip():
                run+=1
                if run>1: issues.append(Issue(display, idx, 1, "MD012", "Multiple consecutive blank lines", True))
            else: run=0
    if "MD047" in enabled and (not text.endswith("\n") or text.endswith("\n\n")):
        issues.append(Issue(display, max(1,len(bare)), 1, "MD047", "Files should end with a single newline character", True))
    return sorted(apply_inline_config(bare, issues), key=lambda x:(x.file,x.line,x.col,x.rule))

def fix_text(text):
    lines=text.splitlines(True)
    out=[]
    prev_blank=False
    for raw in lines:
        nl="\n" if raw.endswith("\n") else ""
        s=raw[:-1] if nl else raw
        s=s.replace("\t","    ").rstrip(" \t\r")
        s=re.sub(r"^( {0,3})(#{1,6})([^\s#].*)", r"\1\2 \3", s)
        s=re.sub(r"^( {0,3}#{1,6})  +", r"\1 ", s)
        s=re.sub(r"!\[\s*\]\(", "![TODO: Add image description](", s)
        blank=not s.strip()
        if blank and prev_blank: continue
        out.append(s+nl)
        prev_blank=blank
    # Insert a blank line after headings and before headings/lists/fences in common cases.
    i=0
    while i < len(out):
        cur=out[i].rstrip("\n")
        if is_heading(cur) and i+1 < len(out) and out[i+1].strip():
            out.insert(i+1, "\n"); i+=2; continue
        if i>0 and (is_heading(cur) or re.match(r"^\s*([-+*]|\d+[.)])\s+",cur) or re.match(r"^ {0,3}(```|~~~)",cur)) and out[i-1].strip():
            out.insert(i, "\n"); i+=1
        i+=1
    res="".join(out).rstrip("\n")+"\n"
    return res

def collect(paths):
    if not paths: paths=["."]
    files=[]
    for p in paths:
        if p == "-": continue
        path=Path(p)
        if path.is_dir():
            for root, dirs, names in os.walk(path):
                dirs[:] = [d for d in dirs if d not in {".git",".rumdl_cache","node_modules","target"}]
                for n in names:
                    if n.lower().endswith((".md",".markdown",".mdown",".mkd")):
                        files.append(Path(root)/n)
        elif path.exists():
            files.append(path)
    return sorted(dict.fromkeys(files), key=lambda x: str(x))

def enabled_set(cfg):
    allr=set(RULE)-set(DEFAULT_DISABLED)
    if cfg["enabled_only"] is not None:
        allr=set(cfg["enabled_only"])
    return {r for r in allr if r not in cfg["disabled"]}

def cmd_check(argv, fmt=False):
    if any(a in ("-h","--help") for a in argv): check_help(fmt); return 0
    if any(a in ("-V","--version") for a in argv): print(VERSION); return 0
    ap=argparse.ArgumentParser(add_help=False)
    ap.add_argument("paths", nargs="*")
    ap.add_argument("-f","--fix", action="store_true")
    ap.add_argument("--diff", action="store_true")
    ap.add_argument("--check", action="store_true")
    ap.add_argument("-l","--list-rules", action="store_true")
    ap.add_argument("-d","--disable", default="")
    ap.add_argument("-e","--enable", "--rules", default="")
    ap.add_argument("--extend-enable", default="")
    ap.add_argument("--extend-disable", default="")
    ap.add_argument("--config")
    ap.add_argument("--no-config", "--isolated", action="store_true")
    ap.add_argument("-o","--output", default=None)
    ap.add_argument("--output-format", default=None)
    ap.add_argument("--stdin", action="store_true")
    ap.add_argument("--stdin-filename", default="stdin.md")
    ap.add_argument("-q","--quiet", action="store_true")
    ap.add_argument("-s","--silent", action="store_true")
    ap.add_argument("--fail-on", default="any")
    ap.add_argument("--show-full-path", action="store_true")
    ap.add_argument("--color", default="auto")
    ap.add_argument("--exclude", default="")
    ap.add_argument("--include", default="")
    ap.add_argument("--no-exclude", action="store_true")
    ap.add_argument("--respect-gitignore", nargs="?", const="true")
    ap.add_argument("--force-exclude", action="store_true")
    ap.add_argument("--no-cache", action="store_true")
    ap.add_argument("--cache-dir")
    ap.add_argument("--profile", action="store_true")
    ap.add_argument("--statistics", action="store_true")
    ap.add_argument("-v","--verbose", action="store_true")
    ap.add_argument("-w","--watch", action="store_true")
    ap.add_argument("--flavor")
    ns,_=ap.parse_known_args(argv)
    if ns.list_rules:
        list_rules()
        return 0
    ns.fix = ns.fix or fmt
    cfg=load_config(ns); enabled=enabled_set(cfg)
    output=ns.output_format or ns.output or "text"
    all_issues=[]; fixed_count=0
    targets=[]
    if ns.stdin or "-" in ns.paths:
        text=sys.stdin.read()
        disp=ns.stdin_filename
        issues=lint_text(text, disp, enabled, cfg["line_length"])
        all_issues += issues
        if ns.fix and not ns.check and not ns.diff:
            sys.stdout.write(fix_text(text))
        targets.append(disp)
    else:
        files=collect(ns.paths)
        if ns.exclude and not ns.no_exclude:
            pats=[x.strip() for x in ns.exclude.split(",") if x.strip()]
            files=[f for f in files if not any(fnmatch.fnmatch(str(f),p) for p in pats)]
        for f in files:
            try: text=f.read_text()
            except UnicodeDecodeError: text=f.read_text(errors="replace")
            disp=str(f.resolve() if ns.show_full_path else f)
            if disp.startswith("./"): disp=disp[2:]
            before=lint_text(text, disp, enabled, cfg["line_length"])
            all_issues += before
            if ns.fix or ns.diff or ns.check:
                new=fix_text(text)
                if new != text:
                    fixed_count += sum(1 for i in before if i.fixable)
                    if ns.diff:
                        sys.stdout.writelines(difflib.unified_diff(text.splitlines(True), new.splitlines(True), fromfile=disp, tofile=disp))
                    elif ns.fix and not ns.check:
                        f.write_text(new)
            targets.append(disp)
    if ns.silent:
        return exit_code(all_issues, ns.fail_on)
    if output == "json":
        print(json.dumps([i.obj() for i in all_issues], indent=2))
    elif output in ("json-lines","jsonl"):
        for i in all_issues: print(json.dumps(i.obj()))
    elif output == "github":
        for i in all_issues: print(f"::{ 'warning' } file={i.file},line={i.line},col={i.col},title={i.rule}::{i.msg}")
    elif output in ("sarif","junit"):
        print("{}" if output=="sarif" else "<testsuite></testsuite>")
    else:
        for i in all_issues:
            was_fixed = (ns.fix and i.fixable and not ns.check and not ns.diff)
            print(i.text(was_fixed))
        if all_issues and not ns.quiet:
            print()
            files=len(set(i.file for i in all_issues))
            if ns.fix:
                print(f"Fixed: Fixed {fixed_count}/{len(all_issues)} issues in {files} file{'s' if files!=1 else ''} (0ms)")
            else:
                print(f"Issues: Found {len(all_issues)} issues in {files} file{'s' if files!=1 else ''} (0ms)")
                fixables=sum(1 for i in all_issues if i.fixable)
                if fixables: print(f"Run `rumdl fmt` to automatically fix {fixables} of the {len(all_issues)} issues")
    return 1 if (all_issues and (ns.check or not ns.fix) and ns.fail_on!="never") else 0

def exit_code(issues, fail_on):
    return 0 if not issues or fail_on=="never" else 1

def list_rules():
    print("Available rules:")
    for code,_,summary,_,_ in RULES:
        print(f"  {code} - {summary}")
    print(f"\nTotal: {len(RULES)} rules")

def cmd_rule(argv):
    if any(a in ("-h","--help") for a in argv):
        print("Show information about a rule or list all rules\n\nUsage: executable rule [OPTIONS] [RULE]")
        return 0
    if "--list-categories" in argv:
        counts={}
        for r in RULES: counts[r[3]]=counts.get(r[3],0)+1
        print("Available categories:")
        for k in sorted(counts): print(f"  {k} ({counts[k]} rules)")
        return 0
    out="text"; fixonly=False; cat=None; explain=False; rulearg=None
    it=iter(argv)
    for a in it:
        if a in ("-o","--output-format"): out=next(it,"text")
        elif a in ("-f","--fixable"): fixonly=True
        elif a in ("-c","--category"): cat=next(it,None)
        elif a=="--explain": explain=True
        elif not a.startswith("-"): rulearg=a
    rows=[r for r in RULES if (not fixonly or r[4]) and (not cat or r[3]==cat)]
    if rulearg:
        key=rulearg.upper()
        if re.fullmatch(r"\d+", key): key="MD"+key.zfill(3)
        key=ALIASES.get(rulearg, key)
        rows=[r for r in RULES if r[0]==key]
    def obj(r):
        return {"code":r[0],"name":r[1],"aliases":[],"summary":r[2],"category":r[3],
                "fix":"Fix is always available." if r[4] else "Fix is not available.",
                "fix_availability":"Always" if r[4] else "None","url":f"https://rumdl.dev/{r[0].lower()}/"}
    if out=="json":
        print(json.dumps(obj(rows[0]) if rulearg and rows else [obj(r) for r in rows], indent=2)); return 0
    if out in ("json-lines","jsonl"):
        for r in rows: print(json.dumps(obj(r)))
        return 0
    if rulearg and rows:
        r=rows[0]
        print(f"{r[0]} - {r[2]}\n\nName: {r[1]}\nCategory: {r[3]}\nFix: {'Fix is always available.' if r[4] else 'Fix is not available.'}\nDocumentation: https://rumdl.dev/{r[0].lower()}/")
    else:
        list_rules()
    return 0

def cmd_config(argv):
    if any(a in ("-h","--help") for a in argv):
        print("Show configuration or query a specific key\n\nUsage: executable config [OPTIONS] [COMMAND]")
        return 0
    if argv and argv[0]=="file":
        for p in [".rumdl.toml","rumdl.toml","pyproject.toml"]:
            if Path(p).exists(): print(str(Path(p).resolve())); return 0
        print("No configuration file found"); return 1
    if argv and argv[0]=="get":
        key=argv[1] if len(argv)>1 else ""
        vals={"global.exclude":"[]","global.include":"[]","global.respect_gitignore":"true","MD013.line-length":"80","MD009.br-spaces":"2"}
        print(f"{key} = {vals.get(key,'null')} [from default]"); return 0
    print("""[global]
enable = [] [from default]
disable = [] [from default]
exclude = [] [from default]
include = [] [from default]
respect_gitignore = true [from default]
flavor = Standard [from default]

[MD009]
br-spaces = 2 [from default]
strict = false [from default]

[MD013]
line-length = 80 [from default]
code-blocks = true [from default]
tables = false [from default]
headings = true [from default]""")
    return 0

def cmd_init(argv):
    py="--pyproject" in argv
    path=Path("pyproject.toml" if py else ".rumdl.toml")
    content = """# rumdl configuration
[global]
exclude = []

[MD013]
line-length = 80
"""
    if py: content = "[tool.rumdl]\nexclude = []\n\n[tool.rumdl.MD013]\nline-length = 80\n"
    if path.exists():
        print(f"Configuration file already exists: {path}", file=sys.stderr); return 1
    path.write_text(content)
    print(f"Created configuration file: {path}")
    return 0

def simple_cmd(name, argv):
    if name=="version": print(VERSION); return 0
    if name=="clean": print("Cache cleared"); return 0
    if name=="schema":
        if "print" in argv: print(json.dumps({"$schema":"http://json-schema.org/draft-07/schema#","title":"rumdl configuration","type":"object"}, indent=2))
        elif "check" in argv: print("Schema is up-to-date")
        else: print("Schema generated")
        return 0
    if name=="completions":
        if "-l" in argv or "--list" in argv: print("bash\nelvish\nfish\npowershell\nzsh")
        else: print(f"# completion script for {argv[0] if argv else 'bash'}")
        return 0
    if name=="explain":
        return cmd_rule(argv)
    if name in ("server","import","vscode"):
        print(f"{name} is not implemented in this reimplementation", file=sys.stderr); return 1
    return 0

def main():
    argv=sys.argv[1:]
    if not argv or argv[0] in ("-h","--help","help"):
        if len(argv)>1 and argv[0]=="help":
            sub=argv[1]; return cmd_check(["--help"], sub=="fmt") if sub in ("check","fmt") else (cmd_rule(["--help"]) if sub=="rule" else 0)
        help_main(); return 0
    if argv[0] in ("-V","--version"): print(VERSION); return 0
    # Drop global options before command.
    cleaned=[]; i=0
    while i<len(argv):
        a=argv[i]
        if a in ("--color","--config") and i+1<len(argv): i+=2; continue
        if a in ("--no-config","--isolated"): i+=1; continue
        cleaned=argv[i:]; break
    if not cleaned: help_main(); return 0
    cmd, rest=cleaned[0], cleaned[1:]
    if cmd=="check": return cmd_check(rest, False)
    if cmd=="fmt": return cmd_check(rest, True)
    if cmd=="rule": return cmd_rule(rest)
    if cmd=="config": return cmd_config(rest)
    if cmd=="init": return cmd_init(rest)
    if cmd in ("version","clean","schema","completions","explain","server","import","vscode"):
        return simple_cmd(cmd, rest)
    print(f"error: unrecognized command '{cmd}'", file=sys.stderr); return 2

if __name__ == "__main__":
    sys.exit(main())
