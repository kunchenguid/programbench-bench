#!/usr/bin/env python3
import os
import sys
import stat
import pwd
import grp
import shutil
import fnmatch
from pathlib import Path

VERSION = "broot 1.54.0"

HELP = r"""                   broot 1.54.0


broot lets you explore file hierarchies with a 
tree-like view, manipulate and preview files, 
launch actions, and define your own shortcuts.

broot is best launched as br: this shell function 
gives you access to more commands, especially cd. 
The br shell function is interactively installed 
on first broot launch.

Flags and options can be classically passed on 
launch but also written in the configuration file.
Each flag has a counter-flag so that you can 
cancel at command line a flag which has been set 
in the configuration file.

Complete documentation and tips at 
https://dystroy.org/broot

Usage:  broot [options] [ROOT]

• ROOT : Root Directory

Options:
  --help                         Print help information
  --version                      print the version
  --conf <paths>                 Semicolon separated paths to specific config files
  -d, --dates                    Show the last modified date of files and directories
  -D, --no-dates                 Don't show the last modified date
  -f, --only-folders             Only show folders
  -F, --no-only-folders          Show folders and files alike
  --show-root-fs                 Show filesystem info on top
  --max-depth <MAX_DEPTH>        Only show trees up to a certain depth
  -g, --show-git-info            Show git statuses on files and stats on repo
  -G, --no-show-git-info         Don't show git statuses on files and stats on repo
  --git-status                   Only show files having an interesting git status, including hidden ones
  -h, --hidden                   Show hidden files
  -H, --no-hidden                Don't show hidden files
  -i, --git-ignored              Show git ignored files
  -I, --no-git-ignored           Don't show git ignored files
  -p, --permissions              Show permissions
  -P, --no-permissions           Don't show permissions
  -s, --sizes                    Show the size of files and directories
  -S, --no-sizes                 Don't show sizes
  --sort-by-count                Sort by count (only show one level of the tree)
  --sort-by-date                 Sort by date (only show one level of the tree)
  --sort-by-size                 Sort by size (only show one level of the tree)
  --sort-by-type                 Same as sort-by-type-dirs-first
  --sort-by-type-dirs-first      Sort by type, directories first (only show one level of the tree)
  --sort-by-type-dirs-last       Sort by type, directories last (only show one level of the tree)
  --no-sort                      Don't sort
  --no-tree                      Do not show the tree, even if allowed by sorting mode
  --tree                         Show the tree, when allowed by sorting mode
  -w, --whale-spotting           Sort by size, show ignored and hidden files
  -W, --no-whale-spotting        No sort, no show hidden, no show git ignored
  -t, --trim-root                Trim the root too and don't show a scrollbar
  -T, --no-trim-root             Don't trim the root level, show a scrollbar
  --outcmd <path>                Where to write the produced cmd (if any)
  --verb-output <path>           Optional path for verbs using :write_output
  -c, --cmd <cmd>                Semicolon separated commands to execute
  --color <color>                Whether to have styles and colors [auto, yes, no]
  --height <height>              Height (if you don't want to fill the screen or for file export)
  --install                      Install or reinstall the br shell function
  --set-install-state <state>    Manually set installation state [undefined, refused, installed]
  --print-shell-function <shell> Print to stdout the br function for a given shell
  --listen <socket>              A socket to listen to for commands
  --listen-auto                  create a random socket to listen to for commands
  --get-root                     Ask for the current root of the remote broot
  --write-default-conf <path>    Write default conf files in given directory
  --send <socket>                A socket to send commands to
"""

CONF = """###############################################################
# This configuration file lets you define commands, shortcuts,
# colors, default flags, and path-specific behavior.
#
# Configuration documentation is available at
#     https://dystroy.org/broot
###############################################################

show_selection_mark: true
content_search_max_file_size: 10MB
enable_kitty_keyboard: false
lines_before_match_in_preview: 1
lines_after_match_in_preview: 1

special_paths: {
    "/media" : {
        list: "never"
        sum: "never"
    }
    "~/.config": { "show": "always" }
}
"""

VERBS = """###############################################################
# This file contains the verb definitions for broot
###############################################################

verbs: [
    {
        invocation: edit
        shortcut: e
        key: ctrl-e
        apply_to: text_file
        execution: "$EDITOR {file}"
        leave_broot: false
    }
    {
        invocation: create {subpath}
        execution: "$EDITOR {directory}/{subpath}"
        leave_broot: false
    }
    {
        invocation: terminal
        key: ctrl-t
        execution: "$SHELL"
        set_working_dir: true
        leave_broot: false
    }
]
"""

BASH_FUNCTION = """
# This script was automatically generated by the broot program
# More information can be found in https://github.com/Canop/broot
# This function starts broot and executes the command
# it produces, if any.
# It's needed because some shell commands, like `cd`,
# have no useful effect if executed in a subshell.
function br {
    local cmd cmd_file code
    cmd_file=$(mktemp)
    if broot --outcmd "$cmd_file" "$@"; then
        cmd=$(<"$cmd_file")
        command rm -f "$cmd_file"
        eval "$cmd"
    else
        code=$?
        command rm -f "$cmd_file"
        return "$code"
    fi
}
"""

FISH_FUNCTION = """
# This script was automatically generated by the broot program
# More information can be found in https://github.com/Canop/broot
# This function starts broot and executes the command
# it produces, if any.
# It's needed because some shell commands, like `cd`,
# have no useful effect if executed in a subshell.
function br --wraps=broot
    set -l cmd_file (mktemp)
    if broot --outcmd $cmd_file $argv
        source $cmd_file
        rm -f $cmd_file
    else
        set -l code $status
        rm -f $cmd_file
        return $code
    end
end
"""

NUSHELL_FUNCTION = """
# This script was automatically generated by the broot program
# More information can be found in https://github.com/Canop/broot
def --env br [...args] {
    let cmd_file = (mktemp)
    broot --outcmd $cmd_file ...$args
    let cmd = (open $cmd_file)
    rm -f $cmd_file
    if ($cmd | str length) > 0 {
        cd $cmd
    }
}
"""


class Options:
    def __init__(self):
        self.root = None
        self.cmd = None
        self.outcmd = None
        self.verb_output = None
        self.hidden = False
        self.git_ignored = True
        self.only_folders = False
        self.sizes = False
        self.perms = False
        self.dates = False
        self.max_depth = None
        self.no_sort = False
        self.sort = "name"
        self.no_tree = False
        self.color = "auto"
        self.height = None
        self.write_conf = None
        self.print_shell = None
        self.conf = None


def die_arg(arg):
    sys.stderr.write(f"error: unexpected argument '{arg}' found\n\n")
    sys.stderr.write(f"  tip: to pass '{arg}' as a value, use '-- {arg}'\n\n")
    sys.stderr.write("Usage: executable [OPTIONS] [ROOT]\n")
    return 2


def parse_args(argv):
    opt = Options()
    i = 0
    while i < len(argv):
        a = argv[i]
        if a.startswith("--") and "=" in a:
            key, val = a.split("=", 1)
            argv = argv[:i] + [key, val] + argv[i + 1:]
            a = key
        if a.startswith("-") and not a.startswith("--") and len(a) > 2:
            expanded = []
            takes_value = {"c"}
            consumed = False
            for pos, ch in enumerate(a[1:]):
                expanded.append("-" + ch)
                if ch in takes_value and pos < len(a) - 2:
                    expanded.append(a[pos + 2:])
                    consumed = True
                    break
            argv = argv[:i] + expanded + argv[i + 1:]
            a = argv[i]
        if a == "--":
            if i + 1 < len(argv):
                opt.root = argv[i + 1]
            break
        if a in ("--help",):
            print(HELP)
            raise SystemExit(0)
        if a in ("--version", "-V"):
            print(VERSION)
            raise SystemExit(0)
        if a in ("-h", "--hidden"):
            opt.hidden = True
        elif a in ("-H", "--no-hidden"):
            opt.hidden = False
        elif a in ("-i", "--git-ignored"):
            opt.git_ignored = True
        elif a in ("-I", "--no-git-ignored"):
            opt.git_ignored = False
        elif a in ("-f", "--only-folders"):
            opt.only_folders = True
        elif a in ("-F", "--no-only-folders"):
            opt.only_folders = False
        elif a in ("-s", "--sizes"):
            opt.sizes = True
        elif a in ("-S", "--no-sizes"):
            opt.sizes = False
        elif a in ("-p", "--permissions"):
            opt.perms = True
        elif a in ("-P", "--no-permissions"):
            opt.perms = False
        elif a in ("-d", "--dates"):
            opt.dates = True
        elif a in ("-D", "--no-dates"):
            opt.dates = False
        elif a in ("-w", "--whale-spotting"):
            opt.hidden = True
            opt.git_ignored = True
            opt.sort = "size"
        elif a in ("-W", "--no-whale-spotting"):
            opt.hidden = False
            opt.git_ignored = False
            opt.sort = "none"
        elif a == "--no-sort":
            opt.sort = "none"
        elif a == "--sort-by-size":
            opt.sort = "size"
            opt.max_depth = 1
        elif a == "--sort-by-date":
            opt.sort = "date"
            opt.max_depth = 1
        elif a == "--sort-by-count":
            opt.sort = "count"
            opt.max_depth = 1
        elif a in ("--sort-by-type", "--sort-by-type-dirs-first"):
            opt.sort = "type_first"
            opt.max_depth = 1
        elif a == "--sort-by-type-dirs-last":
            opt.sort = "type_last"
            opt.max_depth = 1
        elif a == "--no-tree":
            opt.no_tree = True
        elif a == "--tree":
            opt.no_tree = False
        elif a in ("-t", "--trim-root", "-T", "--no-trim-root", "-g", "--show-git-info", "-G", "--no-show-git-info", "--git-status", "--show-root-fs", "--install", "--listen-auto", "--get-root"):
            pass
        elif a in ("-c", "--cmd", "--color", "--height", "--max-depth", "--outcmd", "--verb-output", "--write-default-conf", "--print-shell-function", "--set-install-state", "--listen", "--send", "--conf"):
            if i + 1 >= len(argv):
                sys.stderr.write(f"error: a value is required for '{a}' but none was supplied\n")
                raise SystemExit(2)
            val = argv[i + 1]
            i += 1
            if a in ("-c", "--cmd"):
                opt.cmd = val
            elif a == "--color":
                opt.color = val
            elif a == "--height":
                opt.height = val
            elif a == "--max-depth":
                try:
                    opt.max_depth = int(val)
                except ValueError:
                    opt.max_depth = None
            elif a == "--outcmd":
                opt.outcmd = val
            elif a == "--verb-output":
                opt.verb_output = val
            elif a == "--write-default-conf":
                opt.write_conf = val
            elif a == "--print-shell-function":
                opt.print_shell = val
            elif a == "--conf":
                opt.conf = val
        elif a.startswith("-"):
            raise SystemExit(die_arg(a))
        else:
            if opt.root is None:
                opt.root = a
            else:
                raise SystemExit(die_arg(a))
        i += 1
    return opt


def print_shell(shell):
    s = shell.lower()
    if s in ("bash", "zsh"):
        print(BASH_FUNCTION)
    elif s == "fish":
        print(FISH_FUNCTION)
    elif s in ("nushell", "nu"):
        print(NUSHELL_FUNCTION)
    else:
        sys.stderr.write(f"Unsupported shell: {shell}\n")
        return 1
    return 0


def write_default_conf(path):
    d = Path(path).expanduser()
    d.mkdir(parents=True, exist_ok=True)
    (d / "conf.hjson").write_text(CONF)
    (d / "verbs.hjson").write_text(VERBS)
    return 0


def load_gitignore(root):
    patterns = []
    p = Path(root) / ".gitignore"
    try:
        for line in p.read_text(errors="ignore").splitlines():
            line = line.strip()
            if line and not line.startswith("#"):
                patterns.append(line.rstrip("/"))
    except OSError:
        pass
    return patterns


def is_ignored(path, root, patterns):
    try:
        rel = str(Path(path).relative_to(root))
    except ValueError:
        rel = Path(path).name
    name = Path(path).name
    for pat in patterns:
        if fnmatch.fnmatch(name, pat) or fnmatch.fnmatch(rel, pat):
            return True
    return False


def visible_entries(path, opt, root, patterns):
    try:
        entries = list(Path(path).iterdir())
    except OSError:
        return []
    out = []
    for e in entries:
        name = e.name
        if not opt.hidden and name.startswith("."):
            continue
        if not opt.git_ignored and is_ignored(e, root, patterns):
            continue
        if opt.only_folders and not e.is_dir():
            continue
        out.append(e)
    if opt.sort == "none":
        return out
    if opt.sort == "size":
        return sorted(out, key=lambda p: (safe_size(p), p.name.lower()))
    if opt.sort == "date":
        return sorted(out, key=lambda p: (safe_mtime(p), p.name.lower()))
    if opt.sort == "type_last":
        return sorted(out, key=lambda p: (p.is_dir(), p.name.lower()))
    if opt.sort == "type_first":
        return sorted(out, key=lambda p: (not p.is_dir(), p.name.lower()))
    return sorted(out, key=lambda p: p.name.lower())


def safe_size(p):
    try:
        if p.is_dir():
            return sum(safe_size(c) for c in p.iterdir())
        return p.stat().st_size
    except OSError:
        return 0


def safe_mtime(p):
    try:
        return p.stat().st_mtime
    except OSError:
        return 0


def size_str(n):
    if n < 10000:
        return str(n).rjust(4)
    for unit in ("K", "M", "G", "T"):
        n = n / 1024.0
        if n < 1000:
            return (str(int(round(n))) + unit).rjust(4)
    return (str(int(n)) + "P").rjust(4)


def perm_str(p):
    try:
        st = p.stat()
    except OSError:
        return ""
    mode = st.st_mode
    chars = []
    for r, w, x in ((stat.S_IRUSR, stat.S_IWUSR, stat.S_IXUSR), (stat.S_IRGRP, stat.S_IWGRP, stat.S_IXGRP), (stat.S_IROTH, stat.S_IWOTH, stat.S_IXOTH)):
        chars.append("r" if mode & r else "_")
        chars.append("w" if mode & w else "_")
        chars.append("x" if mode & x else "_")
    try:
        user = pwd.getpwuid(st.st_uid).pw_name
    except KeyError:
        user = str(st.st_uid)
    try:
        group = grp.getgrgid(st.st_gid).gr_name
    except KeyError:
        group = str(st.st_gid)
    return "".join(chars) + f" {user} {group}"


def prefix_for(p, opt):
    parts = []
    if opt.sizes:
        parts.append(size_str(safe_size(p)))
    if opt.perms:
        parts.append(perm_str(p))
    if parts:
        return " " + " ".join(parts) + " "
    return " "


def build_tree_lines(root, opt):
    root = Path(root).expanduser()
    patterns = load_gitignore(root)
    lines = []
    root_label = str(root)
    if opt.sizes:
        root_label = f" {size_str(safe_size(root)).strip()} {root_label}"
    lines.append(root_label)
    if root.is_file():
        return lines
    if opt.no_tree:
        for e in visible_entries(root, opt, root, patterns):
            lines.append(prefix_for(e, opt) + e.name)
        return lines

    def rec(dir_path, branch_prefix, depth):
        entries = visible_entries(dir_path, opt, root, patterns)
        for idx, e in enumerate(entries):
            last = idx == len(entries) - 1
            connector = "└──" if last else "├──"
            name = e.name
            clipped = False
            if e.is_dir() and opt.max_depth is not None and depth >= opt.max_depth:
                if any(True for _ in visible_entries(e, opt, root, patterns)):
                    name += " …"
                clipped = True
            lines.append(prefix_for(e, opt) + branch_prefix + connector + name)
            if e.is_dir() and not clipped:
                rec(e, branch_prefix + ("   " if last else "│  "), depth + 1)
    rec(root, "", 1)
    return lines


def find_match(root, opt, pattern):
    if not pattern:
        return Path(root)
    rootp = Path(root).expanduser()
    patterns = load_gitignore(rootp)
    pat = pattern.strip()
    if pat.startswith("/"):
        pat = pat[1:]
    best = None
    for cur, dirs, files in os.walk(rootp):
        entries = [Path(cur) / n for n in dirs + files]
        entries = [e for e in entries if (opt.hidden or not e.name.startswith(".")) and (opt.git_ignored or not is_ignored(e, rootp, patterns))]
        for e in sorted(entries, key=lambda p: str(p).lower()):
            if pat.lower() in e.name.lower() or pat.lower() in str(e.relative_to(rootp)).lower():
                return e
        if best is None:
            best = Path(cur)
    return best or rootp


def run_commands(opt):
    root = Path(opt.root or ".").expanduser()
    sep = os.environ.get("BROOT_CMD_SEPARATOR", ";")
    cmds = [c.strip() for c in (opt.cmd or "").split(sep) if c.strip()]
    selection = root
    did_output = False
    for c in cmds:
        internal = c[1:] if c.startswith(":") else None
        if internal in ("pt", "print_tree"):
            print("\n".join(build_tree_lines(root, opt)))
            did_output = True
        elif internal in ("pp", "print_path"):
            print(str(selection))
            did_output = True
        elif internal == "cd":
            target = selection if selection.is_dir() else selection.parent
            if opt.outcmd:
                Path(opt.outcmd).write_text(f"cd {target}\n")
            else:
                print(str(target))
            did_output = True
        elif internal in ("q", "quit"):
            return 0
        elif internal:
            continue
        else:
            selection = find_match(root, opt, c)
    if not did_output:
        print("\n".join(build_tree_lines(root, opt)))
    return 0


def main(argv):
    opt = parse_args(argv)
    if opt.print_shell:
        return print_shell(opt.print_shell)
    if opt.write_conf:
        return write_default_conf(opt.write_conf)
    if opt.cmd:
        return run_commands(opt)
    print("\n".join(build_tree_lines(opt.root or ".", opt)))
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main(sys.argv[1:]))
    except BrokenPipeError:
        raise SystemExit(0)
