#!/usr/bin/env python3
import html
import json
import os
import re
import signal
import sys
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

VERSION = "oranda 0.6.5"
TAGLINE = "🎁 generate beautiful landing pages for your projects"


def print_main_help(long=True):
    if long:
        print(TAGLINE)
        print()
        print("Usage: executable [OPTIONS] <COMMAND>")
        print()
        print("Commands:")
        print("  build     Build an oranda site")
        print("  dev       Start a local development server that recompiles your oranda site if a file changes")
        print("  serve     Start a file server to access your oranda site in a browser")
        print("  generate  Generate infrastructure files for oranda sites")
        print("  help      Print this message or the help of the given subcommand(s)")
        print()
        print("Options:")
        print("  -h, --help")
        print("          Print help (see a summary with '-h')")
        print()
        print("  -V, --version")
        print("          Print version")
        print()
        print("GLOBAL OPTIONS:")
        print("  -v, --verbose")
        print("          Whether to output more detailed debug information")
        print()
        print("      --output-format <OUTPUT_FORMAT>")
        print("          The format of the output")
        print("          ")
        print("          [default: human]")
        print()
        print("          Possible values:")
        print("          - human: Human-readable output")
        print("          - json:  Machine-readable JSON output")
    else:
        print("Usage: executable [OPTIONS] <COMMAND>")


def print_build_help():
    print("Build an oranda site")
    print()
    print("Usage: executable build [OPTIONS]")
    print()
    print("Options:")
    print("      --json-only")
    print("          Only build the artifacts JSON file (if applicable) and other files that may be used to")
    print("          support it, such as installer source files")
    print()
    print("  -h, --help")
    print("          Print help (see a summary with '-h')")
    print()
    print("GLOBAL OPTIONS:")
    print("  -v, --verbose")
    print("          Whether to output more detailed debug information")
    print()
    print("      --output-format <OUTPUT_FORMAT>")
    print("          The format of the output")
    print("          ")
    print("          [default: human]")
    print()
    print("          Possible values:")
    print("          - human: Human-readable output")
    print("          - json:  Machine-readable JSON output")


def print_dev_help():
    print("Start a local development server that recompiles your oranda site if a file changes")
    print()
    print("Usage: executable dev [OPTIONS]")
    print()
    print("Options:")
    print("      --port <PORT>")
    print("          The port for the file server to be launched on")
    print()
    print("      --no-first-build")
    print("          Skip the first build before starting to watch for changes")
    print()
    print("  -i, --include-paths <INCLUDE_PATHS>")
    print("          List of extra paths to watch")
    print()
    print("  -h, --help")
    print("          Print help (see a summary with '-h')")
    print()
    print("GLOBAL OPTIONS:")
    print("  -v, --verbose")
    print("          Whether to output more detailed debug information")
    print()
    print("      --output-format <OUTPUT_FORMAT>")
    print("          The format of the output")
    print("          ")
    print("          [default: human]")
    print()
    print("          Possible values:")
    print("          - human: Human-readable output")
    print("          - json:  Machine-readable JSON output")


def print_serve_help():
    print("Start a file server to access your oranda site in a browser")
    print()
    print("Usage: executable serve [OPTIONS]")
    print()
    print("Options:")
    print("      --port <PORT>")
    print("          [default: 7979]")
    print()
    print("  -h, --help")
    print("          Print help (see a summary with '-h')")
    print()
    print("GLOBAL OPTIONS:")
    print("  -v, --verbose")
    print("          Whether to output more detailed debug information")
    print()
    print("      --output-format <OUTPUT_FORMAT>")
    print("          The format of the output")
    print("          ")
    print("          [default: human]")
    print()
    print("          Possible values:")
    print("          - human: Human-readable output")
    print("          - json:  Machine-readable JSON output")


def print_generate_help(long=True):
    print("Generate infrastructure files for oranda sites")
    print()
    print("Usage: executable generate [OPTIONS] <COMMAND>")
    print()
    print("Commands:")
    print("  ci    Generates a CI file that can be used to deploy your site")
    print("  help  Print this message or the help of the given subcommand(s)")
    print()
    print("Options:")
    if long:
        print("  -o, --output-path <OUTPUT_PATH>")
        print("          Path to the output file")
        print()
        print("  -s, --site-path <SITE_PATH>")
        print("          Path to your oranda site")
        print()
        print("  -h, --help")
        print("          Print help (see a summary with '-h')")
        print()
        print("GLOBAL OPTIONS:")
        print("  -v, --verbose")
        print("          Whether to output more detailed debug information")
        print()
        print("      --output-format <OUTPUT_FORMAT>")
        print("          The format of the output")
        print("          ")
        print("          [default: human]")
        print()
        print("          Possible values:")
        print("          - human: Human-readable output")
        print("          - json:  Machine-readable JSON output")
    else:
        print("  -o, --output-path <OUTPUT_PATH>  Path to the output file")
        print("  -s, --site-path <SITE_PATH>      Path to your oranda site")
        print("  -h, --help                       Print help (see more with '--help')")
        print()
        print("GLOBAL OPTIONS:")
        print("  -v, --verbose                        Whether to output more detailed debug information")
        print("      --output-format <OUTPUT_FORMAT>  The format of the output [default: human] [possible values:")
        print("                                       human, json]")


def print_ci_help():
    print("Generates a CI file that can be used to deploy your site")
    print()
    print("Usage: executable generate ci [OPTIONS]")
    print()
    print("Options:")
    print("      --ci <CI>")
    print("          What CI to generate a file for")
    print("          ")
    print("          [default: github]")
    print()
    print("          Possible values:")
    print("          - github: Deploy to GitHub Pages using GitHub Actions")
    print()
    print("  -o, --output-path <OUTPUT_PATH>")
    print("          Path to the output file")
    print()
    print("  -s, --site-path <SITE_PATH>")
    print("          Path to your oranda site")
    print()
    print("  -h, --help")
    print("          Print help (see a summary with '-h')")
    print()
    print("GLOBAL OPTIONS:")
    print("  -v, --verbose")
    print("          Whether to output more detailed debug information")
    print()
    print("      --output-format <OUTPUT_FORMAT>")
    print("          The format of the output")
    print("          ")
    print("          [default: human]")
    print()
    print("          Possible values:")
    print("          - human: Human-readable output")
    print("          - json:  Machine-readable JSON output")


def err(msg, usage=None, code=2):
    print(msg, file=sys.stderr)
    if usage:
        print(file=sys.stderr)
        print(usage, file=sys.stderr)
        print(file=sys.stderr)
        print("For more information, try '--help'.", file=sys.stderr)
    return code


def load_config(verbose=False):
    p = Path("oranda.json")
    if not p.exists():
        if verbose:
            print("↪ >o_o< DEBUG: No config found, using default values")
        return {}
    try:
        return json.loads(p.read_text())
    except json.JSONDecodeError as e:
        print("  × failed to parse JSON", file=sys.stderr)
        print(f"  ╰─▶ {e.msg} at line {e.lineno} column {e.colno}", file=sys.stderr)
        return None


def dist_dir(config):
    build = config.get("build") if isinstance(config.get("build"), dict) else {}
    return str(build.get("dist_dir") or build.get("dist-dir") or "public")


def read_project(config):
    project = config.get("project") if isinstance(config.get("project"), dict) else {}
    name = project.get("name")
    desc = project.get("description")
    if not name:
        cargo = Path("Cargo.toml")
        if cargo.exists():
            text = cargo.read_text(errors="ignore")
            m = re.search(r'(?m)^name\s*=\s*"([^"]+)"', text)
            if m:
                name = m.group(1)
            m = re.search(r'(?m)^description\s*=\s*"([^"]+)"', text)
            if m and not desc:
                desc = m.group(1)
    if not name and Path("README.md").exists():
        for line in Path("README.md").read_text(errors="ignore").splitlines():
            if line.startswith("# "):
                name = line[2:].strip()
                break
    return name or Path.cwd().name, desc or "Generated with oranda."


def markdown_to_html(text):
    out = []
    in_list = False
    for raw in text.splitlines():
        line = raw.rstrip()
        if line.startswith("#"):
            if in_list:
                out.append("</ul>")
                in_list = False
            level = len(line) - len(line.lstrip("#"))
            title = line[level:].strip()
            level = max(1, min(level, 6))
            out.append(f"<h{level}>{html.escape(title)}</h{level}>")
        elif line.startswith("- ") or line.startswith("* "):
            if not in_list:
                out.append("<ul>")
                in_list = True
            out.append(f"<li>{html.escape(line[2:].strip())}</li>")
        elif not line:
            if in_list:
                out.append("</ul>")
                in_list = False
        else:
            if in_list:
                out.append("</ul>")
                in_list = False
            out.append(f"<p>{html.escape(line)}</p>")
    if in_list:
        out.append("</ul>")
    return "\n".join(out)


def build(json_only=False, verbose=False):
    config = load_config(verbose)
    if config is None:
        return 255
    outdir = Path(dist_dir(config))
    if not json_only:
        outdir.mkdir(parents=True, exist_ok=True)
        name, desc = read_project(config)
        body = ""
        if Path("README.md").exists():
            body = markdown_to_html(Path("README.md").read_text(errors="ignore"))
        css = "body{font-family:system-ui,sans-serif;max-width:900px;margin:4rem auto;padding:0 1rem;line-height:1.5}h1{font-size:3rem;margin-bottom:.25rem}code{background:#f2f2f2;padding:.1rem .25rem;border-radius:4px}"
        (outdir / "oranda.css").write_text(css)
        (outdir / "index.html").write_text(
            "<!doctype html>\n"
            "<html><head><meta charset=\"utf-8\"><meta name=\"viewport\" content=\"width=device-width,initial-scale=1\">"
            f"<title>{html.escape(name)}</title><meta name=\"description\" content=\"{html.escape(desc)}\">"
            "<link rel=\"stylesheet\" href=\"oranda.css\"></head><body>"
            f"<main><h1>{html.escape(name)}</h1><p>{html.escape(desc)}</p>{body}</main>"
            "</body></html>\n"
        )
        (outdir / "artifacts.json").write_text(json.dumps({"artifacts": []}, indent=2) + "\n")
        ico = outdir / "favicon.ico"
        if not ico.exists():
            ico.write_bytes(b"\0\0\1\0\1\0\1\1\0\0\1\0 \0(\0\0\0\x16\0\0\0")
    print(f"✓ >o_o< SUCCESS: Your site build is located in `{outdir}`.")
    return 0


def serve(port):
    root = Path("public")
    if not root.exists():
        print("  × Could not find a build in public", file=sys.stderr)
        print("  help: Did you remember to run `oranda build`?", file=sys.stderr)
        return 1
    os.chdir(root)
    httpd = ThreadingHTTPServer(("0.0.0.0", port), SimpleHTTPRequestHandler)
    print(f"↪ >o_o< INFO: Serving `public` at http://localhost:{port}/")
    signal.signal(signal.SIGTERM, lambda *_: sys.exit(0))
    try:
        httpd.serve_forever()
    except KeyboardInterrupt:
        return 0
    return 0


def generate_ci(output_path=None, site_path=None, ci="github"):
    if ci != "github":
        return err("error: invalid value 'bad' for '--ci <CI>'\n  [possible values: github]")
    site = site_path or "."
    content = f"""name: Deploy oranda site

on:
  push:
    branches: [main]
  workflow_dispatch:

permissions:
  contents: read
  pages: write
  id-token: write

jobs:
  deploy:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - name: Install oranda
        run: curl --proto '=https' --tlsv1.2 -LsSf https://github.com/axodotdev/oranda/releases/download/v0.6.5/oranda-installer.sh | sh
      - name: Build site
        run: oranda build
        working-directory: {site}
      - uses: actions/upload-pages-artifact@v3
        with:
          path: {site}/public
      - uses: actions/deploy-pages@v4
"""
    if output_path is None:
        output_path = ".github/workflows/web.yml"
    p = Path(output_path)
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(content)
    print("✓ >o_o< SUCCESS: Generated CI deploy workflow.")
    return 0


def parse_port(val, usage):
    try:
        p = int(val)
    except ValueError:
        print(f"error: invalid value '{val}' for '--port <PORT>': invalid digit found in string", file=sys.stderr)
        print(file=sys.stderr)
        print(usage, file=sys.stderr)
        print(file=sys.stderr)
        print("For more information, try '--help'.", file=sys.stderr)
        return None
    return p


def normalize_global(argv):
    out = []
    verbose = False
    i = 0
    while i < len(argv):
        a = argv[i]
        if a in ("-v", "--verbose"):
            verbose = True
        elif a == "--output-format":
            if i + 1 >= len(argv):
                return None, verbose, err("error: a value is required for '--output-format <OUTPUT_FORMAT>'")
            if argv[i + 1] not in ("human", "json"):
                print(f"error: invalid value '{argv[i + 1]}' for '--output-format <OUTPUT_FORMAT>'", file=sys.stderr)
                print("  [possible values: human, json]", file=sys.stderr)
                print(file=sys.stderr)
                print("For more information, try '--help'.", file=sys.stderr)
                return None, verbose, 2
            i += 1
        else:
            out.append(a)
        i += 1
    return out, verbose, None


def main(argv):
    argv, verbose, ecode = normalize_global(argv)
    if ecode is not None:
        return ecode
    if not argv or argv[0] in ("-h", "--help"):
        print_main_help(True)
        return 0
    if argv[0] in ("-V", "--version"):
        print(VERSION)
        return 0
    cmd = argv[0]
    args = argv[1:]
    if cmd == "help":
        if not args:
            print_main_help(True)
        elif args[0] == "build":
            print_build_help()
        elif args[0] == "dev":
            print_dev_help()
        elif args[0] == "serve":
            print_serve_help()
        elif args[0] == "generate":
            if len(args) > 1 and args[1] == "ci":
                print_ci_help()
            else:
                print_generate_help(True)
        else:
            return err(f"error: unrecognized subcommand '{args[0]}'", "Usage: executable [OPTIONS] <COMMAND>")
        return 0
    if cmd == "build":
        if "-h" in args or "--help" in args:
            print_build_help()
            return 0
        json_only = False
        for a in args:
            if a == "--json-only":
                json_only = True
            else:
                return err(f"error: unexpected argument '{a}' found", "Usage: executable build [OPTIONS]")
        return build(json_only, verbose)
    if cmd == "serve":
        if "-h" in args or "--help" in args:
            print_serve_help()
            return 0
        port = 7979
        i = 0
        while i < len(args):
            if args[i] == "--port" and i + 1 < len(args):
                parsed = parse_port(args[i + 1], "Usage: executable serve [OPTIONS]")
                if parsed is None:
                    return 2
                port = parsed
                i += 2
            else:
                return err(f"error: unexpected argument '{args[i]}' found", "Usage: executable serve [OPTIONS]")
        return serve(port)
    if cmd == "dev":
        if "-h" in args or "--help" in args:
            print_dev_help()
            return 0
        port = 7979
        first = True
        i = 0
        while i < len(args):
            if args[i] == "--port" and i + 1 < len(args):
                parsed = parse_port(args[i + 1], "Usage: executable dev [OPTIONS]")
                if parsed is None:
                    return 2
                port = parsed
                i += 2
            elif args[i] == "--no-first-build":
                first = False
                i += 1
            elif args[i] in ("-i", "--include-paths") and i + 1 < len(args):
                i += 2
            else:
                return err(f"error: unexpected argument '{args[i]}' found", "Usage: executable dev [OPTIONS]")
        if first:
            code = build(False, verbose)
            if code:
                return code
        return serve(port)
    if cmd == "generate":
        if not args:
            print_generate_help(False)
            return 2
        output = None
        site = None
        i = 0
        while i < len(args) and args[i].startswith("-"):
            if args[i] in ("-h", "--help"):
                print_generate_help(True)
                return 0
            if args[i] in ("-o", "--output-path") and i + 1 < len(args):
                output = args[i + 1]
                i += 2
            elif args[i] in ("-s", "--site-path") and i + 1 < len(args):
                site = args[i + 1]
                i += 2
            else:
                return err(f"error: unexpected argument '{args[i]}' found", "Usage: executable generate [OPTIONS] <COMMAND>")
        if i >= len(args):
            print_generate_help(False)
            return 2
        sub = args[i]
        rest = args[i + 1:]
        if sub == "help":
            print_generate_help(True)
            return 0
        if sub != "ci":
            return err(f"error: unrecognized subcommand '{sub}'", "Usage: executable generate [OPTIONS] <COMMAND>")
        if "-h" in rest or "--help" in rest:
            print_ci_help()
            return 0
        ci = "github"
        j = 0
        while j < len(rest):
            if rest[j] in ("-o", "--output-path") and j + 1 < len(rest):
                output = rest[j + 1]
                j += 2
            elif rest[j] in ("-s", "--site-path") and j + 1 < len(rest):
                site = rest[j + 1]
                j += 2
            elif rest[j] == "--ci" and j + 1 < len(rest):
                ci = rest[j + 1]
                j += 2
            else:
                return err(f"error: unexpected argument '{rest[j]}' found", "Usage: executable generate ci [OPTIONS]")
        if ci != "github":
            print(f"error: invalid value '{ci}' for '--ci <CI>'", file=sys.stderr)
            print("  [possible values: github]", file=sys.stderr)
            print(file=sys.stderr)
            print("For more information, try '--help'.", file=sys.stderr)
            return 2
        return generate_ci(output, site, ci)
    if cmd.startswith("-"):
        return err(f"error: unexpected argument '{cmd}' found", "Usage: executable [OPTIONS] <COMMAND>")
    return err(f"error: unrecognized subcommand '{cmd}'", "Usage: executable [OPTIONS] <COMMAND>")


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
