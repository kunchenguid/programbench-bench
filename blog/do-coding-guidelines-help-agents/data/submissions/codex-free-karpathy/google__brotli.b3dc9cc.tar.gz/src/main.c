#define _POSIX_C_SOURCE 200809L
#include <errno.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <unistd.h>

typedef struct {
  int decompress, test, to_stdout, force, remove_src, verbose;
  const char *output, *suffix;
  char **files;
  int nfiles, capfiles;
} Opts;

typedef struct {
  const unsigned char *p;
  size_t n, bit;
} BitReader;

static const char *HELP =
"Usage: executable [OPTION]... [FILE]...\n"
"Options:\n"
"  -#                          compression level (0-9)\n"
"  -c, --stdout                write on standard output\n"
"  -d, --decompress            decompress\n"
"  -f, --force                 force output file overwrite\n"
"  -h, --help                  display this help and exit\n"
"  -j, --rm                    remove source file(s)\n"
"  -s, --squash                remove destination file if larger than source\n"
"  -k, --keep                  keep source file(s) (default)\n"
"  -n, --no-copy-stat          do not copy source file(s) attributes\n"
"  -o FILE, --output=FILE      output file (only if 1 input file)\n"
"  -q NUM, --quality=NUM       compression level (0-11)\n"
"  -t, --test                  test compressed file integrity\n"
"  -v, --verbose               verbose mode\n"
"  -w NUM, --lgwin=NUM         set LZ77 window size (0, 10-24)\n"
"                              window size = 2**NUM - 16\n"
"                              0 lets compressor choose the optimal value\n"
"  --large_window=NUM          use incompatible large-window brotli\n"
"                              bitstream with window size (0, 10-30)\n"
"                              WARNING: this format is not compatible\n"
"                              with brotli RFC 7932 and may not be\n"
"                              decodable with regular brotli decoders\n"
"  -C B64, --comment=B64       set comment; argument is base64-decoded first;\n"
"                              (maximal decoded length: 80)\n"
"                              when decoding: check stream comment;\n"
"                              when encoding: embed comment (fingerprint)\n"
"  -D FILE, --dictionary=FILE  use FILE as raw (LZ77) dictionary\n"
"  -K, --concatenated          allows concatenated brotli streams as input\n"
"  -S SUF, --suffix=SUF        output file suffix (default:'.br')\n"
"  -V, --version               display version and exit\n"
"  -Z, --best                  use best compression level (11) (default)\n"
"Simple options could be coalesced, i.e. '-9kf' is equivalent to '-9 -k -f'.\n"
"With no FILE, or when FILE is -, read standard input.\n"
"All arguments after '--' are treated as files.\n";

static void *xrealloc(void *p, size_t n) {
  void *q = realloc(p, n);
  if (!q) {
    fprintf(stderr, "out of memory\n");
    exit(1);
  }
  return q;
}

static int append_file(Opts *o, char *s) {
  if (o->nfiles == o->capfiles) {
    o->capfiles = o->capfiles ? o->capfiles * 2 : 8;
    o->files = xrealloc(o->files, (size_t)o->capfiles * sizeof(char *));
  }
  o->files[o->nfiles++] = s;
  return 0;
}

static int parse_num(const char *s, int lo, int hi, const char *msg) {
  char *e = NULL;
  long v = strtol(s, &e, 10);
  if (!*s || *e || v < lo || v > hi) {
    fprintf(stderr, "%s [%s]\n%s", msg, s, HELP);
    exit(1);
  }
  return (int)v;
}

static void need_arg(int *i, int argc, char **argv, const char **out) {
  if (*i + 1 >= argc) {
    fprintf(stderr, "expected parameter after [%s]\n%s", argv[*i], HELP);
    exit(1);
  }
  *out = argv[++*i];
}

static void parse_args(int argc, char **argv, Opts *o) {
  memset(o, 0, sizeof(*o));
  o->suffix = ".br";
  for (int i = 1; i < argc; i++) {
    char *a = argv[i];
    if (!strcmp(a, "--")) {
      while (++i < argc) append_file(o, argv[i]);
      break;
    }
    if (a[0] != '-' || !strcmp(a, "-")) {
      append_file(o, a);
      continue;
    }
    if (!strcmp(a, "--help")) { fputs(HELP, stdout); exit(0); }
    if (!strcmp(a, "--version")) { puts("brotli 1.2.0"); exit(0); }
    if (!strcmp(a, "--stdout")) { o->to_stdout = 1; continue; }
    if (!strcmp(a, "--decompress")) { o->decompress = 1; continue; }
    if (!strcmp(a, "--force")) { o->force = 1; continue; }
    if (!strcmp(a, "--rm")) { o->remove_src = 1; continue; }
    if (!strcmp(a, "--keep")) { o->remove_src = 0; continue; }
    if (!strcmp(a, "--test")) { o->test = 1; o->decompress = 1; o->to_stdout = 1; continue; }
    if (!strcmp(a, "--verbose")) { o->verbose++; continue; }
    if (!strcmp(a, "--best")) continue;
    if (!strcmp(a, "--concatenated") || !strcmp(a, "--no-copy-stat") || !strcmp(a, "--squash")) continue;
    if (!strncmp(a, "--quality=", 10)) { parse_num(a + 10, 0, 11, "error parsing quality value"); continue; }
    if (!strncmp(a, "--lgwin=", 8)) { int v = parse_num(a + 8, 0, 24, "error parsing lgwin value"); if (v > 0 && v < 10) { fprintf(stderr, "lgwin parameter (%d) smaller than the minimum (10)\n%s", v, HELP); exit(1); } continue; }
    if (!strncmp(a, "--large_window=", 15)) { parse_num(a + 15, 0, 30, "error parsing lgwin value"); continue; }
    if (!strncmp(a, "--output=", 9)) { o->output = a + 9; continue; }
    if (!strncmp(a, "--suffix=", 9)) { o->suffix = a + 9; continue; }
    if (!strncmp(a, "--comment=", 10)) continue;
    if (!strncmp(a, "--dictionary=", 13)) continue;
    if (!strncmp(a, "--", 2)) {
      fprintf(stderr, "must pass the parameter as %s=value\n%s", a, HELP);
      exit(1);
    }
    for (int j = 1; a[j]; j++) {
      char c = a[j];
      if (c >= '0' && c <= '9') continue;
      if (c == 'c') o->to_stdout = 1;
      else if (c == 'd') o->decompress = 1;
      else if (c == 'f') o->force = 1;
      else if (c == 'h') { fputs(HELP, stdout); exit(0); }
      else if (c == 'j') o->remove_src = 1;
      else if (c == 'k') o->remove_src = 0;
      else if (c == 'n' || c == 's' || c == 'K' || c == 'Z') {}
      else if (c == 't') { o->test = 1; o->decompress = 1; o->to_stdout = 1; }
      else if (c == 'v') o->verbose++;
      else if (c == 'V') { puts("brotli 1.2.0"); exit(0); }
      else if (c == 'q' || c == 'w' || c == 'o' || c == 'S' || c == 'C' || c == 'D') {
        const char *val = NULL;
        if (a[j + 1]) { val = a + j + 1; j = (int)strlen(a) - 1; }
        else need_arg(&i, argc, argv, &val);
        if (c == 'q') parse_num(val, 0, 11, "error parsing quality value");
        else if (c == 'w') { int v = parse_num(val, 0, 24, "error parsing lgwin value"); if (v > 0 && v < 10) { fprintf(stderr, "lgwin parameter (%d) smaller than the minimum (10)\n%s", v, HELP); exit(1); } }
        else if (c == 'o') o->output = val;
        else if (c == 'S') o->suffix = val;
      } else {
        fprintf(stderr, "invalid option [%c]\n%s", c, HELP);
        exit(1);
      }
    }
  }
  if (o->output && o->nfiles > 1) {
    fprintf(stderr, "output file is specified but multiple input files are provided\n");
    exit(1);
  }
}

static unsigned char *read_all(FILE *f, size_t *len) {
  size_t cap = 8192, n = 0;
  unsigned char *buf = malloc(cap);
  if (!buf) return NULL;
  for (;;) {
    if (n == cap) { cap *= 2; buf = xrealloc(buf, cap); }
    size_t r = fread(buf + n, 1, cap - n, f);
    n += r;
    if (r == 0) {
      if (ferror(f)) { free(buf); return NULL; }
      break;
    }
  }
  *len = n;
  return buf;
}

static int br_read(BitReader *br) {
  if (br->bit >= br->n * 8) return -1;
  int v = (br->p[br->bit >> 3] >> (br->bit & 7)) & 1;
  br->bit++;
  return v;
}

static uint32_t br_read_bits(BitReader *br, int n, int *ok) {
  uint32_t v = 0;
  for (int i = 0; i < n; i++) {
    int b = br_read(br);
    if (b < 0) { *ok = 0; return 0; }
    v |= (uint32_t)b << i;
  }
  return v;
}

static int append_bytes(unsigned char **out, size_t *n, size_t *cap, const unsigned char *p, size_t m) {
  if (*n + m < *n) return -1;
  if (*n + m > *cap) {
    size_t nc = *cap ? *cap : 8192;
    while (nc < *n + m) nc *= 2;
    *out = xrealloc(*out, nc);
    *cap = nc;
  }
  memcpy(*out + *n, p, m);
  *n += m;
  return 0;
}

static int decode_uncompressed(const unsigned char *in, size_t inlen, unsigned char **out, size_t *outlen) {
  if (inlen == 1 && in[0] == 0x33) { *out = NULL; *outlen = 0; return 0; }
  BitReader br = { in, inlen, 4 };
  unsigned char *buf = NULL;
  size_t n = 0, cap = 0;
  int ok = 1;
  for (;;) {
    int islast = br_read(&br);
    if (islast < 0) goto bad;
    if (islast) {
      int empty = br_read(&br);
      if (empty == 1) break;
      if (empty < 0) goto bad;
    }
    uint32_t mnibbles = br_read_bits(&br, 2, &ok);
    if (!ok) goto bad;
    int nbits = (mnibbles == 0) ? 16 : (int)(mnibbles + 4) * 4;
    uint32_t mlen = br_read_bits(&br, nbits, &ok) + 1;
    if (!ok) goto bad;
    int uncompressed = br_read(&br);
    if (uncompressed != 1) goto bad;
    br.bit = (br.bit + 7) & ~(size_t)7;
    if (br.bit / 8 + mlen > inlen) goto bad;
    if (append_bytes(&buf, &n, &cap, in + br.bit / 8, mlen) != 0) goto bad;
    br.bit += (size_t)mlen * 8;
  }
  *out = buf;
  *outlen = n;
  return 0;
bad:
  free(buf);
  return -1;
}

static void write_header(FILE *f, size_t len, int first) {
  size_t v = len - 1;
  unsigned char h[3] = {
    (unsigned char)(0x03 | ((v & 1) << 7)),
    (unsigned char)((v >> 1) & 0xff),
    (unsigned char)(0x80 | ((v >> 9) & 0x7f))
  };
  if (first) {
    fwrite(h, 1, 3, f);
  } else {
    unsigned char s[3] = {0, 0, 0};
    for (int bit = 4; bit < 24; bit++) {
      if ((h[bit >> 3] >> (bit & 7)) & 1) {
        int nb = bit - 4;
        s[nb >> 3] |= (unsigned char)(1u << (nb & 7));
      }
    }
    fwrite(s, 1, 3, f);
  }
}

static int encode(FILE *out, const unsigned char *data, size_t len) {
  if (len == 0) return fputc(0x33, out) == EOF ? -1 : 0;
  size_t off = 0;
  int first = 1;
  while (off < len) {
    size_t chunk = len - off;
    if (chunk > 65536) chunk = 65536;
    write_header(out, chunk, first);
    if (fwrite(data + off, 1, chunk, out) != chunk) return -1;
    off += chunk;
    first = 0;
  }
  return fputc(0x03, out) == EOF ? -1 : 0;
}

static char *out_name(const Opts *o, const char *in) {
  if (o->output) return strdup(o->output);
  size_t n = strlen(in), s = strlen(o->suffix);
  if (o->decompress) {
    if (n >= s && !strcmp(in + n - s, o->suffix)) {
      char *r = malloc(n - s + 1);
      memcpy(r, in, n - s);
      r[n - s] = 0;
      return r;
    }
    char *r = malloc(n + 5);
    sprintf(r, "%s.out", in);
    return r;
  }
  char *r = malloc(n + s + 1);
  sprintf(r, "%s%s", in, o->suffix);
  return r;
}

static int process_stream(const Opts *o, FILE *in, FILE *out) {
  size_t n = 0, outn = 0;
  unsigned char *buf = read_all(in, &n), *dec = NULL;
  if (!buf && n) return 1;
  if (o->decompress) {
    if (decode_uncompressed(buf, n, &dec, &outn) != 0) {
      free(buf);
      return 2;
    }
    if (!o->test && outn && fwrite(dec, 1, outn, out) != outn) { free(buf); free(dec); return 1; }
    free(dec);
  } else {
    if (encode(out, buf, n) != 0) { free(buf); return 1; }
  }
  free(buf);
  return 0;
}

static int exists_file(const char *p) {
  struct stat st;
  return stat(p, &st) == 0;
}

static int process_file(const Opts *o, const char *name) {
  FILE *in = NULL, *out = NULL;
  char *oname = NULL;
  int rc = 0;
  int stdin_in = !strcmp(name, "-");
  in = stdin_in ? stdin : fopen(name, "rb");
  if (!in) {
    fprintf(stderr, "failed to open input file [%s]: %s\n", name, strerror(errno));
    return 1;
  }
  if (o->to_stdout || stdin_in) {
    out = stdout;
  } else {
    oname = out_name(o, name);
    if (!o->force && exists_file(oname)) {
      fprintf(stderr, "failed to open output file [%s]: File exists\n", oname);
      rc = 1;
      goto done;
    }
    out = fopen(oname, "wb");
    if (!out) {
      fprintf(stderr, "failed to open output file [%s]: %s\n", oname, strerror(errno));
      rc = 1;
      goto done;
    }
  }
  rc = process_stream(o, in, out);
  if (rc == 2) {
    fprintf(stderr, "corrupt input [%s]\n", stdin_in ? "<stdin>" : name);
    rc = 1;
  }
  if (out && out != stdout && fclose(out) != 0) rc = 1;
  out = NULL;
  if (rc == 0 && o->remove_src && !stdin_in) unlink(name);
done:
  if (in && in != stdin) fclose(in);
  if (out && out != stdout) fclose(out);
  free(oname);
  return rc;
}

int main(int argc, char **argv) {
  Opts o;
  parse_args(argc, argv, &o);
  int rc = 0;
  if (o.nfiles == 0) rc = process_file(&o, "-");
  else {
    for (int i = 0; i < o.nfiles; i++) {
      if (process_file(&o, o.files[i]) != 0) rc = 1;
    }
  }
  free(o.files);
  return rc;
}
