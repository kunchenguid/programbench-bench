#!/usr/bin/env python3
import argparse
import glob
import os
import re
import shlex
import signal
import subprocess
import sys


VERSION = "0.4.2"


class ShellExit(Exception):
    def __init__(self, code):
        self.code = code


class Shell:
    def __init__(self):
        self.env = dict(os.environ)
        self.aliases = {}
        self.last_status = 0
        self.oldpwd = self.env.get("OLDPWD", os.getcwd())
        self.interactive = False

    def run_file(self, path):
        with open(path, "r", encoding="utf-8") as f:
            return self.run_script(f.read())

    def run_script(self, text):
        status = 0
        for segment, op in self.split_top(text):
            segment = segment.strip()
            if not segment:
                continue
            if op == "&&" and status != 0:
                continue
            # The reference accepts || but executes the RHS regardless.
            status = self.run_segment(segment)
            self.last_status = status
        return status

    def strip_comments(self, s):
        out = []
        quote = None
        esc = False
        for ch in s:
            if esc:
                out.append(ch)
                esc = False
                continue
            if ch == "\\" and quote != "'":
                out.append(ch)
                esc = True
                continue
            if quote:
                out.append(ch)
                if ch == quote:
                    quote = None
                continue
            if ch in "'\"":
                quote = ch
                out.append(ch)
            elif ch == "#":
                break
            else:
                out.append(ch)
        return "".join(out)

    def split_top(self, text):
        items = []
        buf = []
        quote = None
        esc = False
        depth = 0
        i = 0
        op = ";"
        while i < len(text):
            ch = text[i]
            if esc:
                buf.append(ch)
                esc = False
                i += 1
                continue
            if ch == "\\" and quote != "'":
                if i + 1 < len(text) and text[i + 1] == "\n":
                    i += 2
                    continue
                buf.append(ch)
                esc = True
                i += 1
                continue
            if quote:
                buf.append(ch)
                if ch == quote:
                    quote = None
                i += 1
                continue
            if ch in "'\"":
                quote = ch
                buf.append(ch)
                i += 1
                continue
            if text.startswith("$((", i):
                depth += 1
                buf.append("$((")
                i += 3
                continue
            if depth and text.startswith("))", i):
                depth -= 1
                buf.append("))")
                i += 2
                continue
            if depth == 0 and text.startswith("&&", i):
                items.append((self.strip_comments("".join(buf)), op))
                buf = []
                op = "&&"
                i += 2
                continue
            if depth == 0 and text.startswith("||", i):
                items.append((self.strip_comments("".join(buf)), op))
                buf = []
                op = "||"
                i += 2
                continue
            if depth == 0 and ch in ";\n" and self.can_split_command("".join(buf)):
                items.append((self.strip_comments("".join(buf)), op))
                buf = []
                op = ";"
                i += 1
                continue
            buf.append(ch)
            i += 1
        items.append((self.strip_comments("".join(buf)), op))
        return items

    def can_split_command(self, text):
        stripped = text.strip()
        if re.match(r"^if\b", stripped) and not re.search(r"\bfi\s*$", stripped):
            return False
        if re.match(r"^for\b", stripped) and not re.search(r"\bdone\s*$", stripped):
            return False
        return True

    def split_pipes(self, s):
        parts, buf = [], []
        quote = None
        esc = False
        for ch in s:
            if esc:
                buf.append(ch)
                esc = False
                continue
            if ch == "\\" and quote != "'":
                buf.append(ch)
                esc = True
                continue
            if quote:
                buf.append(ch)
                if ch == quote:
                    quote = None
                continue
            if ch in "'\"":
                quote = ch
                buf.append(ch)
            elif ch == "|":
                parts.append("".join(buf).strip())
                buf = []
            else:
                buf.append(ch)
        parts.append("".join(buf).strip())
        return parts

    def run_segment(self, s):
        s = s.strip()
        if not s:
            return 0
        if s.startswith("if "):
            return self.run_if(s)
        if s.startswith("for "):
            return self.run_for(s)
        return self.run_pipeline(self.split_pipes(s))

    def run_if(self, s):
        m = re.match(r"if\s+(.+?)\s*;\s*then\s+(.+?)(?:\s*;\s*else\s+(.+?))?\s*;\s*fi\s*$", s, re.S)
        if not m:
            return self.syntax_error(s)
        cond = self.run_script(m.group(1))
        if cond == 0:
            return self.run_script(m.group(2))
        if m.group(3) is not None:
            return self.run_script(m.group(3))
        return 0

    def run_for(self, s):
        m = re.match(r"for\s+([A-Za-z_][A-Za-z0-9_]*)\s+in\s+(.+?)\s*;\s*do\s+(.+?)\s*;\s*done\s*$", s, re.S)
        if not m:
            return self.syntax_error(s)
        name, words_s, body = m.groups()
        words, _ = self.parse_command(words_s)
        status = 0
        old = self.env.get(name)
        for word in words:
            self.env[name] = word
            status = self.run_script(body)
            self.last_status = status
        if old is None:
            self.env.pop(name, None)
        else:
            self.env[name] = old
        return status

    def syntax_error(self, s):
        print("nsh: parse error", file=sys.stderr)
        return 255

    def parse_command(self, s):
        try:
            protected, literals = self.protect_quotes(s)
            self._quote_literals = literals
            lex = shlex.shlex(protected, posix=True, punctuation_chars=False)
            lex.whitespace_split = True
            lex.commenters = ""
            raw = list(lex)
        except ValueError as e:
            print(f"nsh: parse error: {e}", file=sys.stderr)
            return [], []
        words = []
        redirects = []
        i = 0
        while i < len(raw):
            tok = raw[i]
            target = None
            redir = None
            dup = re.match(r"^([0-9]?)>&([0-9])$", tok)
            if dup:
                redir = (dup.group(1) or "1") + ">&"
                target = dup.group(2)
            else:
                m = re.match(r"^([0-9]?)(>>|>|<)(.+)?$", tok)
            if redir:
                pass
            elif m:
                redir = m.group(1) + m.group(2)
                target = m.group(3)
            elif tok in (">", ">>", "<", "1>", "2>", "1>>", "2>>", ">&", "1>&", "2>&"):
                redir = tok
            if redir:
                if target is None:
                    i += 1
                    if i >= len(raw):
                        return [], []
                    target = raw[i]
                redirects.append((redir, self.expand_word(target, glob_it=False)[0] if target else ""))
            else:
                expanded = self.expand_word(tok, glob_it=True)
                words.extend(expanded)
            i += 1
        return words, redirects

    def protect_quotes(self, s):
        out = []
        literals = []
        i = 0
        while i < len(s):
            if s[i] in "'\"":
                quote = s[i]
                i += 1
                buf = []
                esc = False
                while i < len(s):
                    ch = s[i]
                    if esc:
                        buf.append(ch)
                        esc = False
                    elif ch == "\\" and quote == '"':
                        esc = True
                    elif ch == quote:
                        break
                    else:
                        buf.append(ch)
                    i += 1
                if i >= len(s):
                    raise ValueError("No closing quotation")
                marker = f"__NSH_Q{len(literals)}__"
                literals.append(("".join(buf), quote == '"'))
                out.append(marker)
            else:
                out.append(s[i])
            i += 1
        return "".join(out), literals

    def expand_word(self, word, glob_it=True):
        marker_re = re.compile(r"__NSH_Q(\d+)__")
        has_marker = bool(marker_re.search(word))
        saved = {}
        def stash(m):
            key = f"\x01{m.group(1)}\x02"
            text, do_expand = self._quote_literals[int(m.group(1))]
            saved[key] = self.expand_vars(text) if do_expand else text
            return key
        word = marker_re.sub(stash, word)
        if word == "~" or word.startswith("~/"):
            word = os.path.expanduser(word)
        word = self.expand_vars(word)
        for key, value in saved.items():
            word = word.replace(key, value)
        if glob_it and not has_marker and any(c in word for c in "*?["):
            matches = sorted(glob.glob(word))
            if matches:
                return matches
        return [word]

    def expand_vars(self, word):
        word = re.sub(r"\$\(\((.*?)\)\)", lambda m: str(self.eval_arith(m.group(1))), word)
        word = word.replace("$?", str(self.last_status))
        word = re.sub(r"\$\{([A-Za-z_][A-Za-z0-9_]*)\}", lambda m: self.env.get(m.group(1), ""), word)
        word = re.sub(r"\$([A-Za-z_][A-Za-z0-9_]*)", lambda m: self.env.get(m.group(1), ""), word)
        # Command substitution is parsed by the reference but yields an empty field in simple probes.
        word = re.sub(r"\$\([^)]*\)", "", word)
        word = re.sub(r"`[^`]*`", "", word)
        return word

    def eval_arith(self, expr):
        expr = re.sub(r"[^0-9+\-*/%() <>=!&|]", "", expr)
        try:
            return int(eval(expr, {"__builtins__": {}}, {}))
        except Exception:
            return 0

    def apply_redirects(self, redirects):
        opened = []
        stdin = stdout = stderr = None
        for redir, target in redirects:
            if redir.endswith(">&") or ">&" in redir:
                fd_from = int(redir.split(">&")[0] or "1")
                fd_to = int(target)
                if fd_from == 1 and fd_to == 2:
                    stdout = subprocess.STDOUT if stderr is not None else sys.stderr
                elif fd_from == 2 and fd_to == 1:
                    stderr = subprocess.STDOUT
                continue
            fd = 0 if redir.endswith("<") else int(redir[0]) if redir[0].isdigit() else 1
            append = ">>" in redir
            mode = "r" if fd == 0 else ("a" if append else "w")
            f = open(target, mode)
            opened.append(f)
            if fd == 0:
                stdin = f
            elif fd == 1:
                stdout = f
            elif fd == 2:
                stderr = f
        return stdin, stdout, stderr, opened

    def run_pipeline(self, parts):
        commands = []
        for p in parts:
            words, redirects = self.parse_command(p)
            if not words and not redirects:
                return 0
            if words and words[0] in self.aliases:
                replacement = self.aliases[words[0]]
                words = shlex.split(replacement) + words[1:]
            commands.append((words, redirects))
        if len(commands) == 1:
            return self.run_command(commands[0][0], commands[0][1])
        procs = []
        prev = None
        opened_all = []
        for idx, (words, redirects) in enumerate(commands):
            if not words:
                continue
            stdin, stdout, stderr, opened = self.apply_redirects(redirects)
            opened_all += opened
            if idx > 0 and stdin is None:
                stdin = prev
            if idx < len(commands) - 1:
                pipe_out = subprocess.PIPE
            else:
                pipe_out = stdout
            env, words = self.extract_assignments(words)
            try:
                p = subprocess.Popen(words, stdin=stdin, stdout=pipe_out, stderr=stderr, env=env)
            except FileNotFoundError:
                print(f"nsh: command not found `{words[0]}'", file=sys.stderr)
                return 1
            if prev is not None:
                prev.close()
            prev = p.stdout
            procs.append(p)
        status = 0
        for p in procs:
            status = p.wait()
            if status < 0:
                status = 128 - status
        for f in opened_all:
            f.close()
        return status

    def extract_assignments(self, words):
        env = dict(self.env)
        i = 0
        while i < len(words) and re.match(r"^[A-Za-z_][A-Za-z0-9_]*=.*$", words[i]):
            k, v = words[i].split("=", 1)
            env[k] = v
            i += 1
        if i == len(words):
            self.env.update(env)
            os.environ.update(env)
            return self.env, []
        return env, words[i:]

    def run_command(self, words, redirects):
        if not words:
            return 0
        env, words = self.extract_assignments(words)
        if not words:
            return 0
        cmd = words[0]
        stdin, stdout, stderr, opened = self.apply_redirects(redirects)
        try:
            if cmd == "cd":
                return self.builtin_cd(words[1:], stdout or sys.stdout, stderr or sys.stderr)
            if cmd == "pwd":
                print(os.getcwd(), file=stdout or sys.stdout, flush=True)
                return 0
            if cmd == "echo":
                print(" ".join(words[1:]), file=stdout or sys.stdout, flush=True)
                return 0
            if cmd == "exit":
                raise ShellExit(int(words[1]) if len(words) > 1 and words[1].lstrip("-").isdigit() else self.last_status)
            if cmd == "export":
                return self.builtin_export(words[1:])
            if cmd == "alias":
                return self.builtin_alias(words[1:], stdout or sys.stdout)
            if cmd == "true":
                return 0
            if cmd == "false":
                return 1
            try:
                p = subprocess.Popen(words, stdin=stdin, stdout=stdout, stderr=stderr, env=env)
                status = p.wait()
                return status if status >= 0 else 128 - status
            except FileNotFoundError:
                print(f"nsh: command not found `{cmd}'", file=stderr or sys.stderr)
                return 1
            except PermissionError:
                print(f"nsh: permission denied `{cmd}'", file=stderr or sys.stderr)
                return 1
        finally:
            for f in opened:
                f.close()

    def builtin_cd(self, args, out, err):
        dest = args[0] if args else self.env.get("HOME", os.path.expanduser("~"))
        if dest == "-":
            dest = self.oldpwd
            print(dest, file=out, flush=True)
        try:
            cur = os.getcwd()
            os.chdir(os.path.expanduser(dest))
            self.oldpwd = cur
            self.env["OLDPWD"] = cur
            self.env["PWD"] = os.getcwd()
            os.environ["PWD"] = os.getcwd()
            return 0
        except OSError as e:
            print(f"nsh: cd: {e}", file=err)
            return 1

    def builtin_export(self, args):
        for a in args:
            if "=" in a:
                k, v = a.split("=", 1)
                self.env[k] = v
                os.environ[k] = v
        return 0

    def builtin_alias(self, args, out):
        if not args:
            for k in sorted(self.aliases):
                print(f"{k}='{self.aliases[k]}'", file=out, flush=True)
            return 0
        for a in args:
            if "=" in a:
                k, v = a.split("=", 1)
                self.aliases[k] = v
        return 0


def load_rc(shell):
    paths = []
    xdg = os.environ.get("XDG_CONFIG_HOME")
    if xdg:
        paths.append(os.path.join(xdg, "nsh", "nshrc"))
    home = os.environ.get("HOME")
    if home:
        paths.append(os.path.join(home, ".nshrc"))
    for p in paths:
        if os.path.exists(p):
            shell.run_file(p)
            break


def main(argv):
    if "--help" in argv or "-h" in argv:
        print("nsh 0.4.2")
        print("A command-line shell that focuses on performance and productivity.\n")
        print("USAGE:\n    executable [FLAGS] [OPTIONS] [FILE]\n")
        print("FLAGS:\n    -h, --help       Prints help information\n    -l, --login      Behave like a login shell\n        --norc       Don't load nshrc\n        --version    Print the version\n")
        print("OPTIONS:\n    -c <command>        The command to be executed\n")
        print("ARGS:\n    <FILE>    The file to be executed")
        return 0
    if "--version" in argv:
        print(VERSION)
        return 0
    parser = argparse.ArgumentParser(add_help=False)
    parser.add_argument("-c", dest="command")
    parser.add_argument("-l", "--login", action="store_true")
    parser.add_argument("--norc", action="store_true")
    parser.add_argument("file", nargs="?")
    ns, _ = parser.parse_known_args(argv)
    shell = Shell()
    try:
        if not ns.norc:
            load_rc(shell)
        if ns.command is not None:
            return shell.run_script(ns.command)
        if ns.file:
            return shell.run_file(ns.file)
        # Minimal non-interactive stdin mode.
        if not sys.stdin.isatty():
            return shell.run_script(sys.stdin.read())
        while True:
            try:
                line = input("$ ")
            except EOFError:
                print()
                return shell.last_status
            try:
                shell.last_status = shell.run_script(line)
            except ShellExit as e:
                return e.code
    except ShellExit as e:
        return e.code
    except KeyboardInterrupt:
        return 130


if __name__ == "__main__":
    signal.signal(signal.SIGINT, signal.SIG_DFL)
    sys.exit(main(sys.argv[1:]))
