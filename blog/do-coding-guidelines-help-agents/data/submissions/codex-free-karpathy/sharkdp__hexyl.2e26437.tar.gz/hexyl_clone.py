#!/usr/bin/env python3
import os
import re
import sys

HELP = """A command-line hex viewer

Usage: executable [OPTIONS] [FILE]

Arguments:
  [FILE]
          The file to display. If no FILE argument is given, read from STDIN

Options:
  -n, --length <N>
          Only read N bytes from the input. The N argument can also include a unit with a
          decimal prefix (kB, MB, ..) or binary prefix (kiB, MiB, ..), or can be specified
          using a hex number. The short option '-l' can be used as an alias.
          Examples: --length=64, --length=4KiB, --length=0xff
          
          [aliases: bytes]
          [short aliases: c]

  -s, --skip <N>
          Skip the first N bytes of the input. The N argument can also include a unit (see
          `--length` for details).
          A negative value is valid and will seek from the end of the file.

      --block-size <SIZE>
          Sets the size of the `block` unit to SIZE.
          Examples: --block-size=1024, --block-size=4kB
          
          [default: 512]

  -v, --no-squeezing
          Displays all input data. Otherwise any number of groups of output lines which
          would be identical to the preceding group of lines, are replaced with a line
          comprised of a single asterisk

      --color <WHEN>
          When to use colors
          
          [default: always]

          Possible values:
          - always: Always use colorized output
          - auto:   Only displays colors if the output goes to an interactive terminal
          - never:  Do not use colorized output
          - force:  Override the NO_COLOR environment variable

      --border <STYLE>
          Whether to draw a border
          
          [default: unicode]

          Possible values:
          - unicode: Draw a border with Unicode characters
          - ascii:   Draw a border with ASCII characters
          - none:    Do not draw a border at all

  -p, --plain
          Display output with --no-characters, --no-position, --border=none, and
          --color=never

      --no-characters
          Do not show the character panel on the right

  -C, --characters
          Show the character panel on the right. This is the default, unless
          --no-characters has been specified

      --character-table <FORMAT>
          Defines how bytes are mapped to characters
          
          [default: default]

          Possible values:
          - default:       Show printable ASCII characters as-is, '⋄' for NULL bytes, ' '
            for space, '_' for other ASCII whitespace, '•' for other ASCII characters, and
            '×' for non-ASCII bytes
          - ascii:         Show printable ASCII as-is, ' ' for space, '.' for everything
            else
          - codepage-1047: Show printable EBCDIC as-is, ' ' for space, '.' for everything
            else
          - codepage-437:  Uses code page 437 (for non-ASCII bytes)
          - braille:       Uses braille characters for non-printable bytes

      --color-scheme <FORMAT>
          Defines the color scheme for the characters
          
          [default: default]

          Possible values:
          - default:  Show the default colors: bright black for NULL bytes, green for
            ASCII space characters and non-printable ASCII, cyan for printable ASCII
            characters, and yellow for non-ASCII bytes
          - gradient: Show bright black for NULL bytes, cyan for printable ASCII
            characters, a gradient from pink to violet for non-printable ASCII characters
            and a heatmap-like gradient from red to yellow to white for non-ASCII bytes

  -P, --no-position
          Whether to display the position panel on the left

  -o, --display-offset <N>
          Add N bytes to the displayed file position. The N argument can also include a
          unit (see `--length` for details).
          A negative value is valid and calculates an offset relative to the end of the
          file.
          
          [default: 0]

      --panels <N>
          Sets the number of hex data panels to be displayed. `--panels=auto` will display
          the maximum number of hex data panels based on the current terminal width. By
          default, hexyl will show two panels, unless the terminal is not wide enough for
          that

  -g, --group-size <N>
          Number of bytes/octets that should be grouped together. You can use the
          '--endianness' option to control the ordering of the bytes within a group.
          '--groupsize' can be used as an alias (xxd-compatibility)
          
          [default: 1]

          Possible values:
          - 1: Grouped together every byte/octet
          - 2: Grouped together every 2 bytes/octets
          - 4: Grouped together every 4 bytes/octets
          - 8: Grouped together every 8 bytes/octets

      --endianness <FORMAT>
          Whether to print out groups in little-endian or big-endian format. This option
          only has an effect if the '--group-size' is larger than 1. '-e' can be used as
          an alias for '--endianness=little'
          
          [default: big]

          Possible values:
          - little: Print out groups in little-endian format
          - big:    Print out groups in big-endian format

  -b, --base <B>
          Sets the base used for the bytes. The possible options are binary, octal,
          decimal, and hexadecimal
          
          [default: hexadecimal]

      --terminal-width <N>
          Sets the number of terminal columns to be displayed.
          Since the terminal width may not be an evenly divisible by the width per hex
          data column, this will use the greatest number of hex data panels that can fit
          in the requested width but still leave some space to the right.
          Cannot be used with other width-setting options.

      --print-color-table
          Print a table showing how different types of bytes are colored

  -i, --include
          Output in C include file style

      --completion <SHELL>
          Show shell completion for a certain shell
          
          [possible values: bash, elvish, fish, powershell, zsh]
"""

CP437 = ''.join(chr(i) for i in range(256))
CP437 = (
    "⋄☺☻♥♦♣♠•◘○◙♂♀♪♫☼►◄↕‼¶§▬↨↑↓→←∟↔▲▼"
    " !\"#$%&'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_"
    "`abcdefghijklmnopqrstuvwxyz{|}~⌂ÇüéâäàåçêëèïîìÄÅÉæÆôöòûùÿÖÜ¢£¥₧ƒ"
    "áíóúñÑªº¿⌐¬½¼¡«»░▒▓│┤╡╢╖╕╣║╗╝╜╛┐└┴┬├─┼╞╟╚╔╩╦╠═╬╧╨╤╥╙╘╒╓╫╪"
    "┘┌█▄▌▐▀αßΓπΣσµτΦΘΩδ∞φε∩≡±≥≤⌠⌡÷≈°∙·√ⁿ²■ "
)

EBCDIC_1047 = {
    **{i: "." for i in range(256)},
    0x40: " ", 0x4a: "¢", 0x4b: ".", 0x4c: "<", 0x4d: "(", 0x4e: "+", 0x4f: "|",
    0x50: "&", 0x5a: "!", 0x5b: "$", 0x5c: "*", 0x5d: ")", 0x5e: ";", 0x5f: "¬",
    0x60: "-", 0x61: "/", 0x6a: "¦", 0x6b: ",", 0x6c: "%", 0x6d: "_", 0x6e: ">", 0x6f: "?",
    0x79: "`", 0x7a: ":", 0x7b: "#", 0x7c: "@", 0x7d: "'", 0x7e: "=", 0x7f: '"',
    0x81: "a", 0x82: "b", 0x83: "c", 0x84: "d", 0x85: "e", 0x86: "f", 0x87: "g", 0x88: "h", 0x89: "i",
    0x91: "j", 0x92: "k", 0x93: "l", 0x94: "m", 0x95: "n", 0x96: "o", 0x97: "p", 0x98: "q", 0x99: "r",
    0xa1: "~", 0xa2: "s", 0xa3: "t", 0xa4: "u", 0xa5: "v", 0xa6: "w", 0xa7: "x", 0xa8: "y", 0xa9: "z",
    0xc1: "A", 0xc2: "B", 0xc3: "C", 0xc4: "D", 0xc5: "E", 0xc6: "F", 0xc7: "G", 0xc8: "H", 0xc9: "I",
    0xd1: "J", 0xd2: "K", 0xd3: "L", 0xd4: "M", 0xd5: "N", 0xd6: "O", 0xd7: "P", 0xd8: "Q", 0xd9: "R",
    0xe2: "S", 0xe3: "T", 0xe4: "U", 0xe5: "V", 0xe6: "W", 0xe7: "X", 0xe8: "Y", 0xe9: "Z",
    **{0xf0 + i: str(i) for i in range(10)}
}

def fail(msg, code=2):
    print(msg, file=sys.stderr)
    sys.exit(code)

def parse_count(s, block_size=512, allow_negative=False):
    neg = s.startswith("-")
    if neg:
        if not allow_negative:
            raise ValueError("negative offset specified, but only positive offsets (counts) are accepted in this context")
        s = s[1:]
    m = re.fullmatch(r"(0x[0-9a-fA-F]+|[0-9]+)([A-Za-z]*)", s)
    if not m:
        raise ValueError("invalid digit found in string")
    n = int(m.group(1), 16 if m.group(1).lower().startswith("0x") else 10)
    unit = m.group(2).lower()
    mults = {
        "": 1, "b": 1, "byte": 1, "bytes": 1,
        "kb": 1000, "mb": 1000**2, "gb": 1000**3,
        "kib": 1024, "mib": 1024**2, "gib": 1024**3,
        "block": block_size, "blocks": block_size,
    }
    if unit not in mults:
        raise ValueError("unknown unit")
    n *= mults[unit]
    return -n if neg else n

def take_value(args, i, name):
    a = args[i]
    if "=" in a:
        return a.split("=", 1)[1], i
    if i + 1 >= len(args):
        fail(f"error: a value is required for '{name} <N>' but none was supplied")
    return args[i + 1], i + 1

def parse_args(argv):
    initial_block = 512
    for j, raw in enumerate(argv):
        if raw == "--block-size" and j + 1 < len(argv):
            try:
                initial_block = parse_count(argv[j + 1], 512)
            except ValueError:
                pass
        elif raw.startswith("--block-size="):
            try:
                initial_block = parse_count(raw.split("=", 1)[1], 512)
            except ValueError:
                pass
    opt = {
        "length": None, "skip": 0, "block_size": initial_block, "squeeze": True,
        "border": "unicode", "chars": True, "pos": True, "display_offset": 0,
        "panels": None, "group": 1, "endian": "big", "base": "hexadecimal",
        "terminal_width": 80, "char_table": "default", "include": False,
        "file": None,
    }
    i = 0
    while i < len(argv):
        a = argv[i]
        if a in ("-h", "--help"):
            print(HELP, end="")
            sys.exit(0)
        if a in ("-V", "--version", "--version"):
            print("hexyl 0.16.0")
            sys.exit(0)
        if a == "--print-color-table":
            print("Color table")
            print("NULL  ASCII whitespace  ASCII printable  ASCII other  Non-ASCII")
            sys.exit(0)
        if a == "--completion" or a.startswith("--completion="):
            _, i = take_value(argv, i, "--completion") if a == "--completion" else (a.split("=",1)[1], i)
            sys.exit(0)
        if a in ("-p", "--plain"):
            opt["chars"] = False; opt["pos"] = False; opt["border"] = "none"
        elif a in ("-v", "--no-squeezing"):
            opt["squeeze"] = False
        elif a in ("--no-characters",):
            opt["chars"] = False
        elif a in ("-C", "--characters"):
            opt["chars"] = True
        elif a in ("-P", "--no-position"):
            opt["pos"] = False
        elif a == "-e":
            opt["endian"] = "little"
        elif a == "-i" or a == "--include":
            opt["include"] = True
        elif a in ("-n", "-l", "-c", "--length", "--bytes") or a.startswith("--length=") or a.startswith("--bytes="):
            val, i = take_value(argv, i, a)
            try: opt["length"] = parse_count(val, opt["block_size"])
            except ValueError as e: fail(f"Error: failed to parse `--length` arg \"{val}\" as byte count\n\nCaused by:\n    {e}", 1)
        elif a in ("-s", "--skip") or a.startswith("--skip="):
            val, i = take_value(argv, i, a)
            try: opt["skip"] = parse_count(val, opt["block_size"], True)
            except ValueError as e: fail(f"Error: failed to parse `--skip` arg \"{val}\" as byte count\n\nCaused by:\n    {e}", 1)
        elif a == "--block-size" or a.startswith("--block-size="):
            val, i = take_value(argv, i, a)
            opt["block_size"] = parse_count(val, opt["block_size"])
        elif a == "--border" or a.startswith("--border="):
            opt["border"], i = take_value(argv, i, a)
        elif a == "--color" or a.startswith("--color=") or a == "--color-scheme" or a.startswith("--color-scheme="):
            _, i = take_value(argv, i, a)
        elif a == "--character-table" or a.startswith("--character-table="):
            opt["char_table"], i = take_value(argv, i, a)
        elif a in ("-o", "--display-offset") or a.startswith("--display-offset="):
            val, i = take_value(argv, i, a)
            try: opt["display_offset"] = parse_count(val, opt["block_size"])
            except ValueError as e: fail(f"Error: failed to parse `--display-offset` arg \"{val}\" as byte count\n\nCaused by:\n    {e}", 1)
        elif a == "--panels" or a.startswith("--panels="):
            val, i = take_value(argv, i, a)
            opt["panels"] = None if val == "auto" else int(val)
        elif a in ("-g", "--group-size", "--groupsize") or a.startswith("--group-size=") or a.startswith("--groupsize="):
            val, i = take_value(argv, i, a)
            opt["group"] = int(val)
        elif a == "--endianness" or a.startswith("--endianness="):
            opt["endian"], i = take_value(argv, i, a)
        elif a in ("-b", "--base") or a.startswith("--base="):
            opt["base"], i = take_value(argv, i, a)
        elif a == "--terminal-width" or a.startswith("--terminal-width="):
            val, i = take_value(argv, i, a)
            opt["terminal_width"] = int(val)
        elif a.startswith("-") and len(a) > 1:
            fail(f"error: unexpected argument '{a}' found", 2)
        else:
            if opt["file"] is not None:
                fail("error: unexpected argument found", 2)
            opt["file"] = a
        i += 1
    if opt["group"] not in (1,2,4,8):
        fail("error: invalid value for '--group-size <N>'", 2)
    return opt

def read_data(opt):
    path = opt["file"]
    if path is None:
        data = sys.stdin.buffer.read()
        if opt["skip"] < 0:
            fail("Error: Failed to jump to the desired input position. This could be caused by a negative offset that is too large or by an input that is not seek-able (e.g. if the input comes from a pipe).", 1)
    else:
        try:
            with open(path, "rb") as f:
                data = f.read()
        except OSError as e:
            fail(f"Error: {e}", 1)
    start = opt["skip"]
    if start < 0:
        start = len(data) + start
        if start < 0:
            fail("Error: Failed to jump to the desired input position. This could be caused by a negative offset that is too large or by an input that is not seek-able (e.g. if the input comes from a pipe).", 1)
    if start > len(data):
        start = len(data)
    out = data[start:]
    if opt["length"] is not None:
        out = out[:opt["length"]]
    return out, start

def byte_text(b, base):
    if base in ("hex", "hexadecimal"):
        return f"{b:02x}"
    if base in ("dec", "decimal"):
        return f"{b:03d}"
    if base in ("oct", "octal"):
        return f"{b:03o}"
    if base in ("bin", "binary"):
        return f"{b:08b}"
    return f"{b:02x}"

def digits_per_byte(base):
    return {"hexadecimal":2, "hex":2, "decimal":3, "dec":3, "octal":3, "oct":3, "binary":8, "bin":8}.get(base, 2)

def panel_width(opt):
    g = opt["group"]; d = digits_per_byte(opt["base"])
    groups = (8 + g - 1) // g
    return 1 + groups * d * g + max(0, groups - 1) + 1

def line_width_for_panels(opt, panels):
    widths = []
    if opt["pos"]: widths.append(8)
    widths += [panel_width(opt)] * panels
    if opt["chars"]: widths += [8] * panels
    if opt["border"] != "none":
        return sum(widths) + len(widths) + 1
    return sum(widths) + len(widths) + 1

def choose_panels(opt):
    if opt["panels"]:
        return opt["panels"]
    best = 1
    for p in range(1, 16):
        if line_width_for_panels(opt, p) <= opt["terminal_width"]:
            best = p
    return min(best, 2) if opt["terminal_width"] == 80 else best

def fmt_panel(bs, opt):
    g = opt["group"]
    parts = []
    for i in range(0, len(bs), g):
        chunk = list(bs[i:i+g])
        if opt["endian"] == "little" and len(chunk) == g:
            chunk = list(reversed(chunk))
        parts.append("".join(byte_text(b, opt["base"]) for b in chunk))
    s = " " + " ".join(parts)
    return s.ljust(panel_width(opt))

def char_for(b, table):
    if table == "ascii":
        return chr(b) if 32 <= b <= 126 else "."
    if table == "codepage-437":
        return CP437[b]
    if table == "codepage-1047":
        return EBCDIC_1047.get(b, ".")
    if table == "braille":
        if b == 0: return "⋄"
        if b == 9: return "→"
        if b == 10: return "↵"
        if b == 13: return "←"
        if 32 <= b <= 126: return chr(b)
        return chr(0x2800 + b)
    if b == 0: return "⋄"
    if b == 32: return " "
    if b in (9,10,12,13): return "_"
    if 32 <= b <= 126: return chr(b)
    if b < 128: return "•"
    return "×"

def fmt_chars(bs, table):
    return "".join(char_for(b, table) for b in bs).ljust(8)

def make_cells(offset, bs, opt, panels, special=None):
    cells = []
    if opt["pos"]:
        if special == "star":
            cells.append("*".ljust(8))
        elif special == "nocontent":
            cells.append(" " * 8)
        else:
            cells.append(f"{offset:08x}")
    if special == "nocontent":
        cells.append(" No content".ljust(panel_width(opt)))
        for _ in range(panels - 1):
            cells.append(" " * panel_width(opt))
        if opt["chars"]:
            cells += [" " * 8] * panels
        return cells
    for p in range(panels):
        part = bs[p*8:(p+1)*8] if special != "star" else b""
        cells.append(fmt_panel(part, opt) if special != "star" else " " * panel_width(opt))
    if opt["chars"]:
        for p in range(panels):
            part = bs[p*8:(p+1)*8] if special != "star" else b""
            cells.append(fmt_chars(part, opt["char_table"]) if special != "star" else " " * 8)
    return cells

def render_line(cells, opt, panels):
    if opt["border"] == "none":
        return " " + " ".join(cells) + " "
    outer = "|" if opt["border"] == "ascii" else "│"
    major = outer
    minor = "|" if opt["border"] == "ascii" else "┊"
    s = outer
    idx = 0
    if opt["pos"]:
        s += cells[idx] + major; idx += 1
    for p in range(panels):
        sep = major if p == panels - 1 else minor
        s += cells[idx] + sep; idx += 1
    if opt["chars"]:
        for p in range(panels):
            sep = major if p == panels - 1 else minor
            s += cells[idx] + sep; idx += 1
    return s

def border_line(widths, opt, top=True):
    if opt["border"] == "none":
        return None
    if opt["border"] == "ascii":
        l, m, r, h = "+", "+", "+", "-"
    else:
        l, m, r, h = ("┌","┬","┐","─") if top else ("└","┴","┘","─")
    return l + m.join(h*w for w in widths) + r

def c_include(data, filename):
    name = "stdin" if not filename else os.path.basename(filename)
    name = re.sub(r"\W", "_", name)
    print(f"unsigned char {name}[] = {{")
    vals = [f"0x{b:02x}" for b in data]
    for i in range(0, len(vals), 12):
        tail = "," if i + 12 < len(vals) else ""
        print("  " + ", ".join(vals[i:i+12]) + tail)
    print("};")
    print(f"unsigned int {name}_len = {len(data)};")

def render(data, start, opt):
    if opt["include"]:
        c_include(data, opt["file"])
        return
    panels = choose_panels(opt)
    bpl = panels * 8
    widths = []
    if opt["pos"]: widths.append(8)
    widths += [panel_width(opt)] * panels
    if opt["chars"]: widths += [8] * panels
    top = border_line(widths, opt, True)
    bot = border_line(widths, opt, False)
    if top: print(top)
    if not data:
        print(render_line(make_cells(0, b"", opt, panels, "nocontent"), opt, panels))
        if bot: print(bot)
        return
    prev = None
    squeezed = False
    off = 0
    while off < len(data):
        chunk = data[off:off+bpl]
        full_repeat = len(chunk) == bpl and prev == chunk
        if opt["squeeze"] and full_repeat:
            squeezed = True
        else:
            if squeezed:
                print(render_line(make_cells(0, b"", opt, panels, "star"), opt, panels))
                squeezed = False
            pos = start + off + opt["display_offset"]
            print(render_line(make_cells(pos, chunk, opt, panels), opt, panels))
        if len(chunk) == bpl:
            prev = chunk
        off += bpl
    if squeezed:
        print(render_line(make_cells(0, b"", opt, panels, "star"), opt, panels))
        print(render_line(make_cells(start + len(data) + opt["display_offset"], b"", opt, panels), opt, panels))
    if bot: print(bot)

def main():
    opt = parse_args(sys.argv[1:])
    data, start = read_data(opt)
    render(data, start, opt)

if __name__ == "__main__":
    main()
