#!/usr/bin/env python3
import sys, os, glob, html

VERSION = "svgbob 0.7.6"
HELP = """svgbob 0.7.6
SvgBobRus is an ascii to svg converter

USAGE:
    executable [FLAGS] [OPTIONS] [input] [SUBCOMMAND]

FLAGS:
    -h, --help       Prints help information
    -s               parse an inline string
    -V, --version    Prints version information

OPTIONS:
        --background <background>        backdrop background will be filled with this color (default: 'white')
        --fill-color <fill-color>        solid shapes will be filled with this color (default: 'black')
        --font-family <font-family>      text will be rendered with this font (default: 'arial')
        --font-size <font-size>          text will be rendered with this font size (default: 14)
    -o, --output <output>                where to write svg output [default: STDOUT]
        --scale <scale>                  scale the entire svg (dimensions, font size, stroke width) by this factor
                                         (default: 1)
        --stroke-color <stroke-color>    stroke color for all lines (default: 'black')
        --stroke-width <stroke-width>    stroke width for all lines (default: 2)

ARGS:
    <input>    svgbob text file or inline string to parse [default: STDIN]

SUBCOMMANDS:
    build    Batch convert files to svg.
    help     Prints this message or the help of the given subcommand(s)
"""
BUILD_HELP = """executable-build 0.0.1
Batch convert files to svg.

USAGE:
    executable build [OPTIONS]

FLAGS:
    -h, --help       Prints help information
    -V, --version    Prints version information

OPTIONS:
    -i, --input <input>      set input file pattern like: *.bob or dir/*.bob
    -o, --outdir <outdir>    set dir of svg files
"""

class Opts:
    background='white'; fill_color='black'; stroke_color='black'; font_family='Iosevka Fixed, monospace'; font_size=14; stroke_width=2; scale=1.0

def fmt_num(n):
    if isinstance(n, float) and n.is_integer(): n=int(n)
    return str(n)

def style(o):
    return f'''  <style>.svgbob line, .svgbob path, .svgbob circle, .svgbob rect, .svgbob polygon {{
  stroke: {o.stroke_color};
  stroke-width: {fmt_num(o.stroke_width)};
  stroke-opacity: 1;
  fill-opacity: 1;
  stroke-linecap: round;
  stroke-linejoin: miter;
}}

.svgbob text {{
  white-space: pre;
  fill: {o.stroke_color};
  font-family: {o.font_family};
  font-size: {fmt_num(o.font_size)}px;
}}

.svgbob rect.backdrop {{
  stroke: none;
  fill: {o.background};
}}

.svgbob .broken {{
  stroke-dasharray: 8;
}}

.svgbob .filled {{
  fill: {o.fill_color};
}}

.svgbob .bg_filled {{
  fill: {o.background};
  stroke-width: 1;
}}

.svgbob .nofill {{
  fill: {o.background};
}}

.svgbob .end_marked_arrow {{
  marker-end: url(#arrow);
}}

.svgbob .start_marked_arrow {{
  marker-start: url(#arrow);
}}

.svgbob .end_marked_diamond {{
  marker-end: url(#diamond);
}}

.svgbob .start_marked_diamond {{
  marker-start: url(#diamond);
}}

.svgbob .end_marked_circle {{
  marker-end: url(#circle);
}}

.svgbob .start_marked_circle {{
  marker-start: url(#circle);
}}

.svgbob .end_marked_open_circle {{
  marker-end: url(#open_circle);
}}

.svgbob .start_marked_open_circle {{
  marker-start: url(#open_circle);
}}

.svgbob .end_marked_big_open_circle {{
  marker-end: url(#big_open_circle);
}}

.svgbob .start_marked_big_open_circle {{
  marker-start: url(#big_open_circle);
}}

</style>'''

def defs():
    return '''  <defs>
    <marker id="arrow" viewBox="-2 -2 8 8" refX="4" refY="2" markerWidth="7" markerHeight="7" orient="auto-start-reverse">
      <polygon points="0,0 0,4 4,2 0,0"></polygon>
    </marker>
    <marker id="diamond" viewBox="-2 -2 8 8" refX="4" refY="2" markerWidth="7" markerHeight="7" orient="auto-start-reverse">
      <polygon points="0,2 2,0 4,2 2,4 0,2"></polygon>
    </marker>
    <marker id="circle" viewBox="0 0 8 8" refX="4" refY="4" markerWidth="7" markerHeight="7" orient="auto-start-reverse">
      <circle cx="4" cy="4" r="2" class="filled"></circle>
    </marker>
    <marker id="open_circle" viewBox="0 0 8 8" refX="4" refY="4" markerWidth="7" markerHeight="7" orient="auto-start-reverse">
      <circle cx="4" cy="4" r="2" class="bg_filled"></circle>
    </marker>
    <marker id="big_open_circle" viewBox="0 0 8 8" refX="4" refY="4" markerWidth="7" markerHeight="7" orient="auto-start-reverse">
      <circle cx="4" cy="4" r="3" class="bg_filled"></circle>
    </marker>
  </defs>'''

def grid_lines(text):
    if text.endswith('\n'):
        text=text[:-1]
    lines=text.split('\n') if text!='' else ['']
    return lines

def ch_at(lines,r,c):
    if 0 <= r < len(lines) and 0 <= c < len(lines[r]): return lines[r][c]
    return ' '

def render(text, o):
    lines=grid_lines(text)
    rows=len(lines); cols=max([len(x) for x in lines]+[0])
    def S(n): return fmt_num(n * o.scale)
    width=int((max(1,cols)+1)*8*o.scale); height=int((rows+1)*16*o.scale)
    consumed=set(); elems=[]
    # rectangles with +---+ / | | / +---+
    for r1 in range(rows):
        for c1,ch in enumerate(lines[r1]):
            if ch!='+': continue
            for c2 in range(c1+2, len(lines[r1])):
                if ch_at(lines,r1,c2)!='+': continue
                if not all(ch_at(lines,r1,c) in '-=+' for c in range(c1+1,c2)): continue
                for r2 in range(r1+2, rows):
                    if ch_at(lines,r2,c1)=='+' and ch_at(lines,r2,c2)=='+' and all(ch_at(lines,r2,c) in '-=+' for c in range(c1+1,c2)):
                        if all(ch_at(lines,r,c1) in '|' and ch_at(lines,r,c2) in '|' for r in range(r1+1,r2)):
                            elems.append(f'  <rect x="{S(c1*8+4)}" y="{S(r1*16+8)}" width="{S((c2-c1)*8)}" height="{S((r2-r1)*16)}" class="solid nofill" rx="0"></rect>')
                            for c in range(c1,c2+1): consumed.add((r1,c)); consumed.add((r2,c))
                            for r in range(r1+1,r2): consumed.add((r,c1)); consumed.add((r,c2))
                            break
                
    # horizontal arrows and lines
    for r,line in enumerate(lines):
        c=0
        while c < len(line):
            if (r,c) in consumed:
                c+=1; continue
            if line[c] in '-=':
                s=c
                while c < len(line) and line[c] in '-=': c+=1
                e=c-1
                left_arrow = s>0 and line[s-1]=='<'
                right_arrow = c<len(line) and line[c]=='>'
                left_plus = s>0 and line[s-1]=='+'
                right_plus = c<len(line) and line[c]=='+'
                x1 = (s-1)*8+8 if left_arrow else ((s-1)*8+4 if left_plus else s*8)
                x2 = c*8 if right_arrow else (c*8+4 if right_plus else (e+1)*8)
                if left_arrow:
                    elems.append(f'  <polygon points="{S(s*8)},{S(4)} {S((s-1)*8)},{S(8)} {S(s*8)},{S(12)}" class="filled"></polygon>')
                    consumed.add((r,s-1))
                elems.append(f'  <line x1="{S(x1)}" y1="{S(r*16+8)}" x2="{S(x2)}" y2="{S(r*16+8)}" class="solid"></line>')
                if right_arrow:
                    elems.append(f'  <polygon points="{S(c*8)},{S(4)} {S((c+1)*8)},{S(8)} {S(c*8)},{S(12)}" class="filled"></polygon>')
                    consumed.add((r,c))
                for cc in range(s,e+1): consumed.add((r,cc))
            else:
                c+=1
    # vertical arrows and lines
    for c in range(cols):
        r=0
        while r<rows:
            if (r,c) in consumed or ch_at(lines,r,c)!='|': r+=1; continue
            s=r
            while r<rows and ch_at(lines,r,c)=='|' and (r,c) not in consumed: r+=1
            e=r-1
            up = s>0 and ch_at(lines,s-1,c)=='^'
            down = r<rows and ch_at(lines,r,c)=='v'
            y1 = (s-1)*16+12 if up else s*16
            y2 = r*16+4 if down else (e+1)*16
            if up:
                elems.append(f'  <polygon points="{S(c*8)},{S(12)} {S(c*8+4)},{S(0)} {S(c*8+8)},{S(12)}" class="filled"></polygon>'); consumed.add((s-1,c))
            elems.append(f'  <line x1="{S(c*8+4)}" y1="{S(y1)}" x2="{S(c*8+4)}" y2="{S(y2)}" class="solid"></line>')
            if down:
                elems.append(f'  <polygon points="{S(c*8)},{S(r*16+4)} {S(c*8+8)},{S(r*16+4)} {S(c*8+4)},{S(r*16+16)}" class="filled"></polygon>')
                consumed.add((r,c))
            for rr in range(s,e+1): consumed.add((rr,c))
    # text runs
    diagram=set('-=|<>^v')
    for r,line in enumerate(lines):
        c=0
        while c<len(line):
            while c<len(line) and ((r,c) in consumed or line[c]==' ' or line[c] in diagram): c+=1
            s=c
            while c<len(line) and (r,c) not in consumed and line[c]!=' ' and line[c] not in diagram: c+=1
            if c>s:
                txt=html.escape(line[s:c], quote=False)
                elems.append(f'  <text x="{S(s*8+2)}" y="{S(r*16+12)}" >{txt}</text>')
    out=[f'<svg xmlns="http://www.w3.org/2000/svg" width="{width}" height="{height}" class="svgbob">', style(o), defs(), f'  <rect class="backdrop" x="0" y="0" width="{width}" height="{height}"></rect>']
    out.extend(elems); out.append('</svg>')
    return '\n'.join(out)+'\n'

def parse_main(argv):
    o=Opts(); o=type('O',(),dict(background='white',fill_color='black',stroke_color='black',font_family='Iosevka Fixed, monospace',font_size=14,stroke_width=2,scale=1.0))()
    inline=False; output=None; args=[]; i=0
    while i < len(argv):
        a=argv[i]
        if a in ('-h','--help'):
            print(HELP, end=''); return 0
        if a in ('-V','--version'):
            print(VERSION); return 0
        if a=='-s': inline=True; i+=1; continue
        if a in ('-o','--output'):
            i+=1; output=argv[i] if i<len(argv) else ''; i+=1; continue
        if a.startswith('--'):
            key=a[2:]; i+=1
            if i>=len(argv): print(f'error: The argument \'--{key} <{key}>\' requires a value but none was supplied', file=sys.stderr); return 1
            val=argv[i]; i+=1
            try:
                if key=='background': o.background=val
                elif key=='fill-color': o.fill_color=val
                elif key=='stroke-color': o.stroke_color=val
                elif key=='font-family': o.font_family=val
                elif key=='font-size': o.font_size=int(val)
                elif key=='stroke-width': o.stroke_width=int(val)
                elif key=='scale': o.scale=float(val)
                else:
                    print(f"error: Found argument '--{key}' which wasn't expected, or isn't valid in this context\n\nUSAGE:\n    executable [FLAGS] [OPTIONS] [input] [SUBCOMMAND]\n\nFor more information try --help", file=sys.stderr); return 1
            except ValueError as e:
                print(f'Illegal value for argument {key}: {e}', file=sys.stderr); return 1
        else:
            args.append(a); i+=1
    if inline:
        text=args[0] if args else ''
    elif args:
        try:
            with open(args[0], 'r') as f: text=f.read()
        except OSError as e:
            print(f'Failed to open input file {args[0]}: {e.strerror} (os error {e.errno})', file=sys.stderr); return 1
    else:
        text=sys.stdin.read()
    svg=render(text,o)
    if output and output!='STDOUT':
        with open(output,'w') as f: f.write(svg)
    else:
        sys.stdout.write(svg)
    return 0

def build(argv):
    if '-h' in argv or '--help' in argv:
        print(BUILD_HELP,end=''); return 0
    if '-V' in argv or '--version' in argv:
        print('executable-build 0.0.1'); return 0
    pat=None; outdir='.'; i=0
    while i<len(argv):
        if argv[i] in ('-i','--input') and i+1<len(argv): pat=argv[i+1]; i+=2
        elif argv[i] in ('-o','--outdir') and i+1<len(argv): outdir=argv[i+1]; i+=2
        else: i+=1
    if not pat: return 0
    os.makedirs(outdir, exist_ok=True)
    for p in glob.glob(pat):
        if os.path.isfile(p):
            with open(p) as f: txt=f.read()
            name=os.path.splitext(os.path.basename(p))[0]+'.svg'
            with open(os.path.join(outdir,name),'w') as f: f.write(render(txt, Opts()))
    return 0

def main():
    argv=sys.argv[1:]
    if argv and argv[0]=='help':
        if len(argv)>1 and argv[1]=='build': print(BUILD_HELP,end='')
        else: print(HELP,end='')
        return 0
    if argv and argv[0]=='build': return build(argv[1:])
    return parse_main(argv)
if __name__=='__main__': sys.exit(main())
