#!/usr/bin/env python3
import html
import os
import re
import sys
import zipfile
from pathlib import Path

VERSION = "crowbook 0.17.0"
BANNER = "CROWBOOK 0.17.0"

HELP = """crowbook 0.17.0 by Élisabeth Henry <liz.henry@ouvaton.org>
Render a Markdown book in EPUB, PDF or HTML.
  
USAGE:
    executable [OPTIONS] [BOOK]

OPTIONS:
  -f, --force-emoji
          Force emoji usage even if it might not work on your system
  -s, --single
          Use a single Markdown file instead of a book configuration file
  -n, --no-fancy
          Disably fancy UI
  -v, --verbose
          Print warnings in parsing/rendering
  -a, --autograph
          Prompts for an autograph for this book
  -q, --quiet
          Don't print info/error messages
  -c, --create <files>...
          Create a new book with existing Markdown files
  -o, --output <output>
          Specify output file
  -t, --to <to>
          Generate specific format
      --set <set> <set>...
          Set a list of book options
  -l, --list-options
          List all possible options
  -L, --lang <lang>
          Set the runtime language used by Crowbook
      --print-template <print-template>
          Prints the default content of a template
  -S, --stats
          Print some project statistics
  -h, --help
          Print help
  -V, --version
          Print version

ARGS:
  [BOOK]  File containing the book configuration file, or a Markdown file when called with --single
"""

LIST_OPTIONS = """METADATA
author
  type: metadata (default: "")
  Author of the book
title
  type: metadata (default: "")
  Title of the book
lang
  type: metadata (default: en)
  Language of the book
subject
  type: metadata (default: not set)
  Subject of the book (used for EPUB metadata)
description
  type: metadata (default: not set)
  Description of the book (used for EPUB metadata)
cover
  type: path (default: not set)
  Path to the cover of the book

ADDITIONAL METADATA
subtitle
  type: metadata (default: not set)
  Subtitle of the book
license
  type: metadata (default: not set)
  License of the book
version
  type: metadata (default: not set)
  Version of the book
date
  type: metadata (default: not set)
  Date the book was revised
autograph
  type: metadata (default: not set)
  An autograph

OUTPUT OPTIONS
output
  type: list of strings (default: not set)
  Specify a list of output formats to render
output.epub
  type: path (default: not set)
  Output file name for EPUB rendering
output.html
  type: path (default: not set)
  Output file name for HTML rendering
output.html.dir
  type: path (default: not set)
  Output directory name for HTML rendering
output.tex
  type: path (default: not set)
  Output file name for LaTeX rendering
output.pdf
  type: path (default: not set)
  Output file name for PDF rendering
output.base_path
  type: path (default: "")
  Directory where those output files will we written

RENDERING OPTIONS
rendering.highlight
  type: string (default: syntect)
  If/how highligh code blocks. Possible values: "syntect" (default, performed at runtime), "highlight.js" (HTML-only, uses Javascript), "none"
rendering.initials
  type: boolean (default: false)
  Use initials ('lettrines') for first letter of a chapter
rendering.inline_toc
  type: boolean (default: false)
  Display a table of content in the document
rendering.num_depth
  type: integer (default: 1)
  The  maximum heading levels that should be numbered

HTML OPTIONS
html.css
  type: template path (default: not set)
  Path of a stylesheet for HTML rendering
html.css.print
  type: template path (default: not set)
  Path of a media print stylesheet for HTML rendering
html.js
  type: template path (default: not set)
  Path of a javascript file
html.standalone.template
  type: template path (default: not set)
  Path of an HTML template for standalone HTML
html.dir.template
  type: template path (default: not set)
  Path of a HTML template for multifile HTML

EPUB OPTIONS
epub.version
  type: integer (default: 2)
  EPUB version to generate (2 or 3)
epub.css
  type: template path (default: not set)
  Path of a stylesheet for EPUB
epub.chapter.xhtml
  type: template path (default: not set)
  Path of an xhtml template for each chapter
epub.titlepage.xhtml
  type: template path (default: not set)
  Path of an xhtml template for the title page

LATEX OPTIONS
tex.command
  type: string (default: xelatex)
  LaTeX command to use for generating PDF
tex.template
  type: template path (default: not set)
  Path of a LaTeX template file
tex.class
  type: string (default: book)
  LaTeX class to use

RESOURCES OPTIONS
resources.files
  type: list of strings (default: not set)
  Whitespace-separated list of files to embed in e.g. EPUB file
resources.out_path
  type: path (default: data)
  Paths where additional resources should be copied in the EPUB file or HTML directory

INPUT OPTIONS    #[SERDE(FLATTEN)]
input.clean
  type: boolean (default: true)
  Toggle typographic cleaning of input markdown according to lang
input.yaml_blocks
  type: boolean (default: false)
  Enable/disable inline YAML blocks to override options set in config file

CROWBOOK OPTIONS
crowbook.html_as_text
  type: boolean (default: true)
  Consider HTML blocks as text.
crowbook.markdown.superscript
  type: boolean (default: false)
  If enabled, allow support for superscript and subscript syntax.
crowbook.zip.command
  type: string (default: zip)
  Command to use to zip files (for EPUB/ODT)
"""

CSS = """body {
    font-family: "Linux Libertine", "Georgia", serif;
    text-align: justify;
    font-size: 100%;
}

p {
    text-indent: 1.25em;
    margin:0;
    hyphens: auto;
}

code {
    font-size: 80%;
    font-family: "Linux Libertine Mono", monospace;
    background-color: #F0F0F0;
}

h1, h2, h3, h4, h5, h6 {
    text-align: left;
    font-family: Linux Biolinum, sans-serif;
    font-variant: small-caps;
}

h1.title {
    text-align: center;
    font-size: 300%;
}
h2.author {
    text-align: right;
    font-size: 200%;
}
.chapter {
    margin: 2em auto;
    max-width: 42em;
}
"""

PRINT_CSS = """#page {
    display: block;
}

.chapter {
    page-break-before: always;
}
"""

COMMON_JS = """function on(name) {
    var elements = document.getElementsByClassName(name);
    for (var i = 0; i < elements.length; i++) {
        var elem = elements[i];
        elem.style.backgroundColor = "pink";
    }
}
"""

HTML_TEMPLATE = """<!DOCTYPE html>
<html lang="{{lang}}">
  <head>
    <meta charset="utf-8">
    <meta name="generator" content="crowbook">
    <meta name="viewport" content="width=device-width">
    <meta name="author" content="{{author_raw}}">
    <title>{{title_raw}}</title>
    <style type = "text/css">
      {{style}}
    </style>
  </head>
  <body>
  {{content}}
  </body>
</html>
"""

TEX_TEMPLATE = r"""\documentclass{book}
\usepackage{hyperref}
\title{<<title>>}
\author{<<author>>}
\date{}
\begin{document}
\maketitle
<<content>>
\end{document}
"""

EPUB_CHAPTER = """<?xml version="1.0" encoding="UTF-8"?>
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="{{lang}}" lang="{{lang}}">
  <head>
  <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
  <meta name="generator" content="crowbook" />
  <title>{{title}}</title>
  </head>
  <body>{{content}}</body>
</html>
"""


class ArgError(Exception):
    def __init__(self, message, code=2):
        self.message = message
        self.code = code


def eprint(s=""):
    print(s, file=sys.stderr)


def parse_args(argv):
    opts = {"quiet": False, "single": False, "stats": False, "create": None,
            "to": None, "output": None, "sets": [], "book": None,
            "template": None, "list": False}
    i = 0
    while i < len(argv):
        a = argv[i]
        if a in ("-h", "--help"):
            print(HELP)
            raise SystemExit(0)
        if a in ("-V", "--version"):
            print(VERSION)
            raise SystemExit(0)
        if a in ("-q", "--quiet"):
            opts["quiet"] = True
        elif a in ("-s", "--single"):
            opts["single"] = True
        elif a in ("-S", "--stats"):
            opts["stats"] = True
        elif a in ("-f", "--force-emoji", "-n", "--no-fancy", "-v", "--verbose", "-a", "--autograph"):
            pass
        elif a in ("-l", "--list-options"):
            opts["list"] = True
        elif a in ("-o", "--output"):
            if i + 1 >= len(argv):
                raise ArgError("error: a value is required for '--output <output>' but none was supplied\n\nFor more information, try '--help'.")
            i += 1
            opts["output"] = argv[i]
        elif a in ("-t", "--to"):
            if i + 1 >= len(argv):
                raise ArgError("error: a value is required for '--to <to>' but none was supplied\n  [possible values: epub, pdf, html, tex, odt, html.dir]\n\nFor more information, try '--help'.")
            i += 1
            if argv[i] not in ("epub", "pdf", "html", "tex", "odt", "html.dir"):
                raise ArgError(f"error: invalid value '{argv[i]}' for '--to <to>'\n  [possible values: epub, pdf, html, tex, odt, html.dir]\n\nFor more information, try '--help'.")
            opts["to"] = argv[i]
        elif a in ("-L", "--lang"):
            if i + 1 >= len(argv):
                raise ArgError("error: a value is required for '--lang <lang>' but none was supplied\n\nFor more information, try '--help'.")
            i += 1
        elif a == "--print-template":
            if i + 1 >= len(argv):
                raise ArgError("error: a value is required for '--print-template <print-template>' but none was supplied\n\nFor more information, try '--help'.")
            i += 1
            opts["template"] = argv[i]
        elif a == "--set":
            vals = []
            j = i + 1
            while j < len(argv) and argv[j].startswith("-") is False:
                vals.append(argv[j])
                j += 1
            if len(vals) < 2:
                raise ArgError("error: 2 values required by '--set <set> <set>...'; only 1 was provided\n\nUsage: executable [OPTIONS] [BOOK]\n\nFor more information, try '--help'.")
            opts["sets"].extend(vals)
            i = j - 1
        elif a in ("-c", "--create"):
            files = argv[i + 1:]
            opts["create"] = files
            break
        elif a.startswith("-"):
            raise ArgError(f"error: unexpected argument '{a}' found\n\n  tip: to pass '{a}' as a value, use '-- {a}'\n\nUsage: executable [OPTIONS] [BOOK]\n\nFor more information, try '--help'.")
        else:
            opts["book"] = a
        i += 1
    return opts


def banner(opts):
    if not opts.get("quiet"):
        print(BANNER)


def create_book(files):
    print('"author: Your name"')
    print('"title: Your title"')
    print('"lang: en"')
    print()
    print('"## Output formats"')
    print()
    print('"# Uncomment and fill to generate files"')
    print('"# output.html: some_file.html"')
    print('"# output.epub: some_file.epub"')
    print('"# output.pdf: some_file.pdf"')
    print()
    print('"# Or uncomment the following to generate PDF, HTML and EPUB files based on this file\'s name"')
    print('"# output: [pdf, epub, html]"')
    print()
    print('"# Uncomment and fill to set cover image (for EPUB)"')
    print('"# cover: some_cover.png"')
    print()
    print("## List of chapters")
    for f in files:
        print("+ " + f)


def parse_config(path):
    p = Path(path)
    if not p.exists():
        raise FileNotFoundError(f"Could not find file '{path}' for book")
    meta = {"title": "", "author": "", "lang": "en"}
    chapters = []
    for raw in p.read_text(encoding="utf-8", errors="replace").splitlines():
        line = raw.strip()
        if not line or line.startswith("#"):
            continue
        if line[0:1] in "+-*":
            name = line[1:].strip()
            if name:
                chapters.append((name, line[0]))
        elif ":" in line:
            k, v = line.split(":", 1)
            meta[k.strip()] = v.strip().strip('"')
    return p.parent, meta, chapters


def parse_single(path):
    p = Path(path)
    if not p.exists():
        raise FileNotFoundError(f"{path}: Could not find file '{path}' for book chapter")
    text = p.read_text(encoding="utf-8", errors="replace")
    meta = {"title": "", "author": "", "lang": "en"}
    body = text
    if text.startswith("---\n"):
        end = text.find("\n---", 4)
        if end != -1:
            for line in text[4:end].splitlines():
                if ":" in line:
                    k, v = line.split(":", 1)
                    meta[k.strip()] = v.strip().strip('"')
            body = text[end + 4:].lstrip("\n")
    if not meta["title"]:
        m = re.search(r"^#\s+(.+)$", body, re.M)
        meta["title"] = m.group(1).strip() if m else p.stem
    return p.parent, meta, [(p.name, "+")], {p.name: body}


def inline_md(text):
    s = html.escape(text)
    s = re.sub(r"`([^`]+)`", r"<code>\1</code>", s)
    s = re.sub(r"\*\*([^*]+)\*\*", r"<strong>\1</strong>", s)
    s = re.sub(r"\*([^*]+)\*", r"<em>\1</em>", s)
    s = re.sub(r"\[([^\]]+)\]\(([^)]+)\)", r'<a href="\2">\1</a>', s)
    return s


def markdown_to_html(text):
    out = []
    para = []
    in_list = False
    in_code = False
    code = []
    def flush_para():
        if para:
            out.append("<p>" + inline_md(" ".join(para)) + "</p>")
            para.clear()
    for line in text.splitlines():
        if line.startswith("```"):
            flush_para()
            if in_code:
                out.append("<pre><code>" + html.escape("\n".join(code)) + "</code></pre>")
                code.clear()
                in_code = False
            else:
                in_code = True
            continue
        if in_code:
            code.append(line)
            continue
        if not line.strip():
            flush_para()
            if in_list:
                out.append("</ul>")
                in_list = False
            continue
        m = re.match(r"^(#{1,6})\s+(.*)$", line)
        if m:
            flush_para()
            if in_list:
                out.append("</ul>")
                in_list = False
            n = len(m.group(1))
            out.append(f"<h{n}>{inline_md(m.group(2).strip())}</h{n}>")
        elif re.match(r"^\s*[-*]\s+", line):
            flush_para()
            if not in_list:
                out.append("<ul>")
                in_list = True
            out.append("<li>" + inline_md(re.sub(r"^\s*[-*]\s+", "", line)) + "</li>")
        else:
            para.append(line.strip())
    flush_para()
    if in_list:
        out.append("</ul>")
    if in_code:
        out.append("<pre><code>" + html.escape("\n".join(code)) + "</code></pre>")
    return "\n".join(out)


def md_to_tex(text):
    def esc(s):
        return (s.replace("\\", r"\textbackslash{}").replace("&", r"\&")
                .replace("%", r"\%").replace("$", r"\$").replace("#", r"\#")
                .replace("_", r"\_").replace("{", r"\{").replace("}", r"\}"))
    lines = []
    for line in text.splitlines():
        m = re.match(r"^(#{1,6})\s+(.*)$", line)
        if m:
            cmd = "chapter" if len(m.group(1)) == 1 else "section"
            lines.append("\\" + cmd + "{" + esc(m.group(2).strip()) + "}")
        elif line.strip():
            lines.append(esc(re.sub(r"[*_`]", "", line.strip())) + "\n")
    return "\n".join(lines)


def collect_chapters(base, chapters, single_map=None):
    texts = []
    for name, mark in chapters:
        text = single_map.get(name) if single_map else None
        if text is None:
            p = base / name
            if not p.exists():
                raise FileNotFoundError(f"{name}: Could not find file '{name}' for book chapter")
            text = p.read_text(encoding="utf-8", errors="replace")
        texts.append((name, mark, text))
    return texts


def outputs_for(meta, opts, book_path):
    if opts["to"]:
        out = opts["output"]
        if not out:
            ext = "html" if opts["to"] == "html" else opts["to"]
            out = Path(book_path).with_suffix("." + ext).name if book_path else "output." + ext
        return [(opts["to"], out)]
    outs = []
    for fmt in ("html", "tex", "pdf", "epub", "odt"):
        key = "output." + fmt
        if key in meta:
            outs.append((fmt, meta[key]))
    if "output" in meta and not outs:
        val = meta["output"].strip("[]")
        for fmt in re.split(r"[,\s]+", val):
            if fmt:
                outs.append((fmt, Path(book_path).with_suffix("." + fmt).name))
    return outs or [("html", opts["output"] or (Path(book_path).with_suffix(".html").name if book_path else "output.html"))]


def render_html(meta, chapters):
    content = [f'<h1 class="title">{html.escape(meta.get("title", ""))}</h1>']
    if meta.get("author"):
        content.append(f'<h2 class="author">{html.escape(meta["author"])}</h2>')
    for i, (_, _, text) in enumerate(chapters, 1):
        content.append(f'<div class = "chapter" id = "chapter-{i}">')
        content.append(markdown_to_html(text))
        content.append("</div>")
    return (HTML_TEMPLATE.replace("{{lang}}", html.escape(meta.get("lang", "en")))
            .replace("{{author_raw}}", html.escape(meta.get("author", "")))
            .replace("{{title_raw}}", html.escape(meta.get("title", "")))
            .replace("{{style}}", CSS)
            .replace("{{content}}", "\n".join(content)))


def render_tex(meta, chapters):
    body = "\n".join(md_to_tex(text) for _, _, text in chapters)
    return (TEX_TEMPLATE.replace("<<title>>", meta.get("title", ""))
            .replace("<<author>>", meta.get("author", ""))
            .replace("<<content>>", body))


def write_epub(path, meta, chapters):
    with zipfile.ZipFile(path, "w") as z:
        z.writestr("mimetype", "application/epub+zip")
        z.writestr("META-INF/container.xml", """<?xml version="1.0"?><container version="1.0" xmlns="urn:oasis:names:tc:opendocument:xmlns:container"><rootfiles><rootfile full-path="OEBPS/content.opf" media-type="application/oebps-package+xml"/></rootfiles></container>""")
        manifest = []
        spine = []
        for i, (name, _, text) in enumerate(chapters, 1):
            fname = f"chapter_{i}.xhtml"
            manifest.append(f'<item id="chap{i}" href="{fname}" media-type="application/xhtml+xml"/>')
            spine.append(f'<itemref idref="chap{i}"/>')
            z.writestr("OEBPS/" + fname, EPUB_CHAPTER.replace("{{lang}}", meta.get("lang", "en")).replace("{{title}}", html.escape(name)).replace("{{content}}", markdown_to_html(text)))
        z.writestr("OEBPS/style.css", CSS)
        z.writestr("OEBPS/content.opf", f"""<?xml version="1.0" encoding="UTF-8"?>
<package xmlns="http://www.idpf.org/2007/opf" unique-identifier="bookid" version="2.0">
<metadata xmlns:dc="http://purl.org/dc/elements/1.1/"><dc:title>{html.escape(meta.get('title',''))}</dc:title><dc:creator>{html.escape(meta.get('author',''))}</dc:creator><dc:language>{html.escape(meta.get('lang','en'))}</dc:language></metadata>
<manifest>{''.join(manifest)}<item id="css" href="style.css" media-type="text/css"/></manifest>
<spine>{''.join(spine)}</spine>
</package>""")


def print_stats(chapters):
    print("Chapter    Chars      Words  Chars/Word")
    print("---------")
    total_chars = total_words = 0
    for name, _, text in chapters:
        words = re.findall(r"\b\w+\b", re.sub(r"^#+\s+.*$", "", text, flags=re.M), re.U)
        chars = sum(len(w) for w in words)
        total_chars += chars
        total_words += len(words)
        avg = chars / len(words) if words else 0
        print(f"{name:<9}{chars:>8}{len(words):>11}{avg:>12.2f}")
    print("---------")
    avg = total_chars / total_words if total_words else 0
    print(f"TOTAL:{total_chars:>10}{total_words:>11}{avg:>12.2f}")
    print()


def print_template(name):
    templates = {
        "html.css": CSS,
        "epub.css": CSS,
        "html.css.print": PRINT_CSS,
        "html.js": COMMON_JS,
        "html.standalone.js": "{{common_script}}\n\n{% if one_chapter %}\nfunction showChapter(chap, noreset){\n}\n{% endif %}\n",
        "html.standalone.template": HTML_TEMPLATE,
        "html.dir.template": HTML_TEMPLATE,
        "epub.chapter.xhtml": EPUB_CHAPTER,
        "epub.titlepage.xhtml": EPUB_CHAPTER,
        "tex.template": TEX_TEMPLATE,
    }
    if name not in templates:
        print(f"ERROR {name} is not a valid template name")
    else:
        print(templates[name])


def main(argv):
    try:
        opts = parse_args(argv)
    except ArgError as e:
        eprint(e.message)
        return e.code
    if opts["list"]:
        banner(opts)
        print(LIST_OPTIONS)
        return 0
    if opts["template"]:
        banner(opts)
        print_template(opts["template"])
        return 0
    if opts["create"] is not None:
        banner(opts)
        create_book(opts["create"])
        return 0
    if not opts["book"]:
        banner(opts)
        print("ERROR You must pass the name of a book configuration file.")
        print("For more information try --help.")
        print()
        return 0
    try:
        if opts["single"]:
            base, meta, chapter_refs, single_map = parse_single(opts["book"])
        else:
            base, meta, chapter_refs = parse_config(opts["book"])
            single_map = None
        for i in range(0, len(opts["sets"]), 2):
            if i + 1 < len(opts["sets"]):
                meta[opts["sets"][i]] = opts["sets"][i + 1]
        chapters = collect_chapters(base, chapter_refs, single_map)
    except FileNotFoundError as e:
        banner(opts)
        print("ERROR " + str(e))
        return 0
    banner(opts)
    if opts["stats"]:
        print_stats(chapters)
        return 0
    for fmt, out in outputs_for(meta, opts, opts["book"]):
        if fmt == "html":
            Path(out).write_text(render_html(meta, chapters), encoding="utf-8")
        elif fmt in ("tex", "pdf"):
            Path(out).write_text(render_tex(meta, chapters), encoding="utf-8")
        elif fmt == "epub":
            write_epub(out, meta, chapters)
        elif fmt == "odt":
            Path(out).write_text("Crowbook ODT placeholder\n\n" + "\n".join(t for _, _, t in chapters), encoding="utf-8")
        elif fmt == "html.dir":
            d = Path(out)
            d.mkdir(parents=True, exist_ok=True)
            (d / "index.html").write_text(render_html(meta, chapters), encoding="utf-8")
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
