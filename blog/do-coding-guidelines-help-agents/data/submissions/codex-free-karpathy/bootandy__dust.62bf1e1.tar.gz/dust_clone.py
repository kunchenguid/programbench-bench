#!/usr/bin/env python3
import argparse, os, sys, stat, json, re, time
from dataclasses import dataclass, field

VERSION = "Dust 1.2.3"

@dataclass
class Node:
    path: str
    name: str
    size: int = 0
    is_dir: bool = False
    is_file: bool = False
    children: list = field(default_factory=list)
    files: int = 0
    depth: int = 0
    mtime: float = 0
    atime: float = 0
    ctime: float = 0

HELP = """Like du but more intuitive

Usage: executable [OPTIONS] [PATH]...

Arguments:
  [PATH]...  Input files or directories

Options:
  -d, --depth <DEPTH>              Depth to show
  -T, --threads <THREADS>          Number of threads to use
      --config <FILE>              Specify a config file to use
  -n, --number-of-lines <NUMBER>   Number of lines of output to show. (Default is terminal_height - 10)
  -p, --full-paths                 Subdirectories will not have their path shortened
  -X, --ignore-directory <PATH>    Exclude any file or directory with this path
  -I, --ignore-all-in-file <FILE>  Exclude any file or directory with a regex matching that listed in this file, the file entries will be added to the ignore regexs provided by --invert_filter
  -L, --dereference-links          dereference sym links - Treat sym links as directories and go into them
  -x, --limit-filesystem           Only count the files and directories on the same filesystem as the supplied directory
  -s, --apparent-size              Use file length instead of blocks
  -r, --reverse                    Print tree upside down (biggest highest)
  -c, --no-colors                  No colors will be printed (Useful for commands like: watch)
  -C, --force-colors               Force colors print
  -b, --no-percent-bars            No percent bars or percentages will be displayed
  -B, --bars-on-right              percent bars moved to right side of screen
  -z, --min-size <MIN_SIZE>        Minimum size file to include in output
  -R, --screen-reader              For screen readers. Removes bars. Adds new column: depth level (May want to use -p too for full path)
      --skip-total                 No total row will be displayed
  -f, --filecount                  Directory 'size' is number of child files instead of disk size
  -i, --ignore-hidden              Do not display hidden files
  -v, --invert-filter <REGEX>      Exclude filepaths matching this regex. To ignore png files type: -v "\\.png$"
  -e, --filter <REGEX>             Only include filepaths matching this regex. For png files type: -e "\\.png$"
  -t, --file-types                 show only these file types
  -w, --terminal-width <WIDTH>     Specify width of output overriding the auto detection of terminal width
  -P, --no-progress                Disable the progress indication
      --print-errors               Print path with errors
  -D, --only-dir                   Only directories will be displayed
  -F, --only-file                  Only files will be displayed. (Finds your largest files)
  -o, --output-format <FORMAT>     Changes output display size. si will print sizes in powers of 1000. b k m g t kb mb gb tb will print the whole tree in that size [possible values: si, b, k, m, g, t, kb, mb, gb, tb]
  -S, --stack-size <STACK_SIZE>    Specify memory to use as stack size - use if you see: 'fatal runtime error: stack overflow' (default low memory=1048576, high memory=1073741824)
  -j, --output-json                Output the directory tree as json to the current directory
  -M, --mtime <MTIME>              +/-n matches files modified more/less than n days ago , and n matches files modified exactly n days ago, days are rounded down.That is +n => (-inf, curr-(n+1)), n => [curr-(n+1), curr-n), and -n => (curr-n, +inf)
  -A, --atime <ATIME>              just like -mtime, but based on file access time
  -y, --ctime <CTIME>              just like -mtime, but based on file change time
      --files0-from <FILES0_FROM>  Read NUL-terminated paths from FILE (use `-` for stdin)
      --files-from <FILES_FROM>    Read newline-terminated paths from FILE (use `-` for stdin)
      --collapse <COLLAPSE>        Keep these directories collapsed
  -m, --filetime <FILETIME>        Directory 'size' is max filetime of child files instead of disk size. while a/c/m for last accessed/changed/modified time [possible values: a, c, m]
  -h, --help                       Print help (see more with '--help')
  -V, --version                    Print version
"""

def parse_args(argv):
    if '-V' in argv or '--version' in argv:
        print(VERSION); sys.exit(0)
    if '-h' in argv or '--help' in argv:
        print(HELP); sys.exit(0)
    p = argparse.ArgumentParser(add_help=False, prog='executable')
    p.add_argument('-d','--depth', type=int); p.add_argument('-T','--threads')
    p.add_argument('--config'); p.add_argument('-n','--number-of-lines', type=int, default=999999)
    p.add_argument('-p','--full-paths', action='store_true')
    p.add_argument('-X','--ignore-directory', action='append', default=[])
    p.add_argument('-I','--ignore-all-in-file', action='append', default=[])
    p.add_argument('-L','--dereference-links', action='store_true')
    p.add_argument('-x','--limit-filesystem', action='store_true')
    p.add_argument('-s','--apparent-size', action='store_true')
    p.add_argument('-r','--reverse', action='store_true')
    p.add_argument('-c','--no-colors', action='store_true')
    p.add_argument('-C','--force-colors', action='store_true')
    p.add_argument('-b','--no-percent-bars', action='store_true')
    p.add_argument('-B','--bars-on-right', action='store_true')
    p.add_argument('-z','--min-size', default='0')
    p.add_argument('-R','--screen-reader', action='store_true')
    p.add_argument('--skip-total', action='store_true')
    p.add_argument('-f','--filecount', action='store_true')
    p.add_argument('-i','--ignore-hidden', action='store_true')
    p.add_argument('-v','--invert-filter', action='append', default=[])
    p.add_argument('-e','--filter', action='append', default=[])
    p.add_argument('-t','--file-types', action='store_true')
    p.add_argument('-w','--terminal-width', type=int, default=80)
    p.add_argument('-P','--no-progress', action='store_true')
    p.add_argument('--print-errors', action='store_true')
    p.add_argument('-D','--only-dir', action='store_true')
    p.add_argument('-F','--only-file', action='store_true')
    p.add_argument('-o','--output-format', default='')
    p.add_argument('-S','--stack-size')
    p.add_argument('-j','--output-json', action='store_true')
    p.add_argument('-M','--mtime'); p.add_argument('-A','--atime'); p.add_argument('-y','--ctime')
    p.add_argument('--files0-from'); p.add_argument('--files-from')
    p.add_argument('--collapse', action='append', default=[])
    p.add_argument('-m','--filetime', choices=['a','c','m'])
    p.add_argument('paths', nargs='*')
    try:
        return p.parse_args(argv)
    except SystemExit:
        sys.exit(2)

def parse_size(s):
    if not s: return 0
    m = re.match(r'^([0-9]+(?:\.[0-9]+)?)([kmgtKMGT]?[iI]?[bB]?)?$', s.strip())
    if not m: return 0
    n = float(m.group(1)); u = (m.group(2) or '').lower()
    mult = 1
    if u.startswith('k'): mult = 1024
    elif u.startswith('m'): mult = 1024**2
    elif u.startswith('g'): mult = 1024**3
    elif u.startswith('t'): mult = 1024**4
    return int(n*mult)

def metric(st, apparent):
    return st.st_size if apparent else getattr(st, 'st_blocks', 0) * 512

def time_match(ts, expr):
    if not expr: return True
    now = time.time(); days = int((now - ts)//86400)
    try:
        if expr[0] == '+': return days > int(expr[1:])
        if expr[0] == '-': return days < int(expr[1:])
        return days == int(expr)
    except Exception:
        return True

def should_ignore(path, opts):
    base = os.path.basename(path.rstrip(os.sep))
    if opts.ignore_hidden and base.startswith('.') and base not in ('.','..'):
        return True
    for x in opts.ignore_directory:
        if path == x or base == x or path.endswith(os.sep + x): return True
    for pat in opts.invert_filter:
        try:
            if re.search(pat, path): return True
        except re.error:
            if pat in path: return True
    return False

def include_file(path, st, opts):
    if not time_match(st.st_mtime, opts.mtime) or not time_match(st.st_atime, opts.atime) or not time_match(st.st_ctime, opts.ctime):
        return False
    if opts.filter:
        ok = False
        for pat in opts.filter:
            try: ok = ok or bool(re.search(pat, path))
            except re.error: ok = ok or (pat in path)
        if not ok: return False
    return True

def scan(path, opts, depth=0, root_dev=None):
    try:
        st = os.stat(path) if opts.dereference_links else os.lstat(path)
    except OSError as e:
        print(f"{e.strerror}: {path}", file=sys.stderr if opts.print_errors else sys.stdout)
        return None
    if root_dev is None: root_dev = st.st_dev
    if opts.limit_filesystem and st.st_dev != root_dev: return None
    if should_ignore(path, opts): return None
    isdir = stat.S_ISDIR(st.st_mode)
    isfile = stat.S_ISREG(st.st_mode) or stat.S_ISLNK(st.st_mode)
    n = Node(path=path, name=path, is_dir=isdir, is_file=isfile, depth=depth, mtime=st.st_mtime, atime=st.st_atime, ctime=st.st_ctime)
    own = metric(st, opts.apparent_size)
    if isdir and opts.filter:
        own = 0
    if isdir:
        n.size = own; n.files = 0
        try:
            entries = sorted(os.listdir(path))
        except OSError as e:
            if opts.print_errors: print(f"{e.strerror}: {path}", file=sys.stderr)
            entries = []
        for ent in entries:
            ch = scan(os.path.join(path, ent), opts, depth+1, root_dev)
            if ch is None: continue
            if ch.is_file and ch.size < opts._min_size: continue
            if ch.size == 0 and (ch.is_file or ch.children == [] and not ch.is_dir): continue
            n.children.append(ch); n.size += ch.size; n.files += ch.files
        if opts.filecount: n.size = n.files
        if opts.filetime:
            vals = [getattr(c, {'a':'atime','c':'ctime','m':'mtime'}[opts.filetime]) for c in n.children]
            val = max(vals+[getattr(n, {'a':'atime','c':'ctime','m':'mtime'}[opts.filetime])])
            n.size = int(val); setattr(n, {'a':'atime','c':'ctime','m':'mtime'}[opts.filetime], val)
        if opts.filter and depth > 0 and n.size == 0 and not n.children:
            return None
    else:
        if not include_file(path, st, opts): return None
        n.size = 1 if opts.filecount else own
        n.files = 1
    return n

def fmt_size(v, opts):
    if opts.filecount: return str(v)
    f = opts.output_format.lower()
    units2 = [('T',1000**4),('G',1000**3),('M',1000**2),('K',1000),('B',1)] if f=='si' else [('T',1024**4),('G',1024**3),('M',1024**2),('K',1024),('B',1)]
    fixed = {'b':(1,'B'),'k':(1024,'K'),'m':(1024**2,'M'),'g':(1024**3,'G'),'t':(1024**4,'T'), 'kb':(1000,'K'),'mb':(1000**2,'M'),'gb':(1000**3,'G'),'tb':(1000**4,'T')}
    if f in fixed:
        div,u = fixed[f]
        return f"{int(v/div)}{u}" if f!='b' else f"{int(v)}B"
    for u,div in units2:
        if v >= div or div == 1:
            if div == 1: return f"{int(v)}B"
            x = v/div
            return f"{x:.1f}{u}" if x < 10 else f"{x:.0f}{u}"

def display_name(n, opts):
    return n.path if opts.full_paths else os.path.basename(n.path.rstrip(os.sep)) or n.path

def collect(n, opts, out=None):
    if out is None: out=[]
    show = True
    if opts.only_dir and not n.is_dir: show = False
    if opts.only_file and n.is_dir and n.depth != 0: show = False
    if opts.depth is not None and n.depth > opts.depth: show = False
    if show: out.append(n)
    if opts.depth is None or n.depth < opts.depth:
        for c in n.children: collect(c, opts, out)
    return out

def print_table(roots, opts):
    nodes=[]
    for r in roots: nodes += collect(r, opts, [])
    if opts.skip_total:
        nodes = [n for n in nodes if n.depth != 0]
    if opts.only_file:
        nodes = [n for n in nodes if n.is_file or n.depth == 0]
    nodes.sort(key=lambda n: (n.size, n.path), reverse=opts.reverse)
    if not opts.reverse:
        roots_set = {id(r) for r in roots}
        non = [n for n in nodes if id(n) not in roots_set]
        rootnodes = [n for n in nodes if id(n) in roots_set]
        nodes = non + rootnodes
    if opts.number_of_lines and len(nodes) > opts.number_of_lines:
        nodes = nodes[-opts.number_of_lines:] if not opts.reverse else nodes[:opts.number_of_lines]
    total = max([r.size for r in roots] + [1])
    sw = max([len(fmt_size(n.size, opts)) for n in nodes] + [1])
    nw = max([len(display_name(n, opts)) + n.depth*2 for n in nodes] + [1])
    for n in nodes:
        name = ('  '*n.depth) + display_name(n, opts)
        pct = int((n.size * 100 / total) + 0.5) if total else 0
        if opts.screen_reader:
            print(f"{display_name(n, opts):<{max(8,nw)}} {n.depth:>2} {fmt_size(n.size, opts):>{sw}} {pct:>3}%")
        elif opts.no_percent_bars:
            print(f"{fmt_size(n.size, opts):>{sw}} {name}")
        else:
            barw = max(1, min(56, opts.terminal_width - sw - nw - 12))
            filled = max(1 if n.size else 0, int(barw * n.size / total)) if total else 0
            bar = '█'*filled + ' '*(barw-filled)
            print(f"{fmt_size(n.size, opts):>{sw}} {name:<{nw}} │{bar}│ {pct:>3}%")

def node_json(n, opts):
    return {'size': fmt_size(n.size, opts), 'name': n.path, 'children': [node_json(c, opts) for c in sorted(n.children, key=lambda x:x.size, reverse=True)]}

def file_types(roots, opts):
    totals = {}
    def walk(n):
        if n.is_file:
            base = os.path.basename(n.path)
            ext = os.path.splitext(base)[1] or '(no extension)'
            totals[ext] = totals.get(ext,0) + n.size
        for c in n.children: walk(c)
    for r in roots: walk(r)
    total = sum(totals.values()) or 1
    nodes = [Node(path=k,name=k,size=v) for k,v in totals.items()]
    root = Node(path='(total)',name='(total)',size=sum(totals.values()))
    print_table(nodes + ([] if opts.skip_total else [root]), opts)

def read_paths(opts):
    paths = list(opts.paths) if opts.paths else []
    if opts.files_from:
        data = sys.stdin.read() if opts.files_from == '-' else open(opts.files_from).read()
        paths += [x for x in data.splitlines() if x]
    if opts.files0_from:
        data = sys.stdin.buffer.read() if opts.files0_from == '-' else open(opts.files0_from,'rb').read()
        paths += [x.decode() for x in data.split(b'\0') if x]
    return paths or ['.']

def main(argv):
    opts = parse_args(argv)
    opts._min_size = parse_size(opts.min_size)
    for f in opts.ignore_all_in_file:
        try:
            opts.invert_filter += [ln.strip() for ln in open(f) if ln.strip()]
        except OSError: pass
    roots=[]; bad=False
    for p in read_paths(opts):
        n = scan(p, opts)
        if n is None: bad=True
        else: roots.append(n)
    if not roots:
        sys.exit(1 if bad else 0)
    if opts.file_types:
        file_types(roots, opts); return
    if opts.output_json:
        obj = node_json(roots[0], opts) if len(roots)==1 else {'size':fmt_size(sum(r.size for r in roots),opts),'name':'(total)','children':[node_json(r,opts) for r in roots]}
        print(json.dumps(obj, separators=(',',':'))); return
    print_table(roots, opts)
    if bad: sys.exit(1)

if __name__ == '__main__':
    main(sys.argv[1:])
