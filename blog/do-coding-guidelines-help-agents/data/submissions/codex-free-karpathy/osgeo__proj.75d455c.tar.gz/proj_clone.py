#!/usr/bin/env python3
import sys, math, re

A0 = 6378137.0
E2_WGS84 = 0.0066943799901413165
BANNER = "Rel. 9.9.0, September 15th, 2026"
PROJS = [
("adams_hemi","Adams Hemisphere in a Square"),("adams_ws1","Adams World in a Square I"),("adams_ws2","Adams World in a Square II"),
("aea","Albers Equal Area"),("aeqd","Azimuthal Equidistant"),("affine","Affine transformation"),("airy","Airy"),("aitoff","Aitoff"),
("alsk","Modified Stereographic of Alaska"),("apian","Apian Globular I"),("august","August Epicycloidal"),("axisswap","Axis ordering"),
("bacon","Bacon Globular"),("bertin1953","Bertin 1953"),("bipc","Bipolar conic of western hemisphere"),("boggs","Boggs Eumorphic"),
("bonne","Bonne (Werner lat_1=90)"),("calcofi","Cal Coop Ocean Fish Invest Lines/Stations"),("cart","Geodetic/cartesian conversions"),
("cass","Cassini"),("cc","Central Cylindrical"),("ccon","Central Conic"),("cea","Equal Area Cylindrical"),("chamb","Chamberlin Trimetric"),
("collg","Collignon"),("col_urban","Colombia Urban"),("comill","Compact Miller"),("crast","Craster Parabolic (Putnins P4)"),
("defmodel","Deformation model"),("deformation","Kinematic grid shift"),("denoy","Denoyer Semi-Elliptical"),("airocean","Airocean"),
("eck1","Eckert I"),("eck2","Eckert II"),("eck3","Eckert III"),("eck4","Eckert IV"),("eck5","Eckert V"),("eck6","Eckert VI"),
("eqearth","Equal Earth"),("eqc","Equidistant Cylindrical (Plate Carree)"),("eqdc","Equidistant Conic"),("euler","Euler"),
("etmerc","Extended Transverse Mercator"),("fahey","Fahey"),("fouc","Foucaut"),("fouc_s","Foucaut Sinusoidal"),("gall","Gall (Gall Stereographic)"),
("geoc","Geocentric Latitude"),("geogoffset","Geographic Offset"),("geos","Geostationary Satellite View"),("gins8","Ginsburg VIII (TsNIIGAiK)"),
("gn_sinu","General Sinusoidal Series"),("gnom","Gnomonic"),("goode","Goode Homolosine"),("gridshift","Generic grid shift"),
("gs48","Modified Stereographic of 48 U.S."),("gs50","Modified Stereographic of 50 U.S."),("guyou","Guyou"),
("hammer","Hammer & Eckert-Greifendorff"),("hatano","Hatano Asymmetrical Equal Area"),("healpix","HEALPix"),("rhealpix","rHEALPix"),
("helmert","3(6)-, 4(8)- and 7(14)-parameter Helmert shift"),("hgridshift","Horizontal grid shift"),("horner","Horner polynomial evaluation"),
("igh","Interrupted Goode Homolosine"),("igh_o","Interrupted Goode Homolosine Oceanic View"),("imoll","Interrupted Mollweide"),
("imoll_o","Interrupted Mollweide Oceanic View"),("imw_p","International Map of the World Polyconic"),("isea","Icosahedral Snyder Equal Area"),
("kav5","Kavrayskiy V"),("kav7","Kavrayskiy VII"),("krovak","Krovak"),("labrd","Laborde"),("laea","Lambert Azimuthal Equal Area"),
("lagrng","Lagrange"),("larr","Larrivee"),("lask","Laskowski"),("lonlat","Lat/long (Geodetic)"),("longlat","Lat/long (Geodetic)"),
("merc","Mercator"),("mill","Miller Cylindrical"),("moll","Mollweide"),("nsper","Near-sided perspective"),("ortho","Orthographic"),
("robin","Robinson"),("sinu","Sinusoidal"),("stere","Stereographic"),("tmerc","Transverse Mercator"),("utm","Universal Transverse Mercator (UTM)"),
("webmerc","Web Mercator / Pseudo Mercator")]
ELLPS = "    MERIT a=6378137.0      rf=298.257       MERIT 1983\n    SGS85 a=6378136.0      rf=298.257       Soviet Geodetic System 85\n    GRS80 a=6378137.0      rf=298.257222101 GRS 1980(IUGG, 1980)\n     airy a=6377563.396    rf=299.3249646   Airy 1830\n   bessel a=6377397.155    rf=299.1528128   Bessel 1841\n   clrk66 a=6378206.4      b=6356583.8      Clarke 1866\n   clrk80 a=6378249.145    rf=293.4663      Clarke 1880 mod.\n     intl a=6378388.0      rf=297.          International 1924 (Hayford 1909, 1910)\n    WGS72 a=6378135.0      rf=298.26        WGS 72\n    WGS84 a=6378137.0      rf=298.257223563 WGS 84\n   sphere a=6370997.0      b=6370997.0      Normal Sphere (r=6370997)"
UNITS = "          mm 0.001                millimetre\n          cm 0.01                 centimetre\n           m 1                    metre\n          ft 0.3048               foot\n       us-ft 0.304800609601219    US survey foot\n          km 1000                 kilometre\n          mi 1609.344             Statute mile\n          yd 0.9144               yard\n          in 0.0254               inch"

class Opt:
    inverse=False; reverse=False; swap=False; echo=False; fmt="%.2f"; dms=True; mult=1.0; files=[]; params={}; listopt=None

def usage():
    print(BANNER)
    print("usage: executable [-bdeEfiIlmorsStTvVwW [args]] [+opt[=arg] ...] [file ...]")

def die(msg):
    print(BANNER, file=sys.stderr); print("<executable>: ", file=sys.stderr); print(msg, file=sys.stderr); print("program abnormally terminated", file=sys.stderr); sys.exit(1)

def parse(argv):
    o=Opt(); o.inverse=False; o.reverse=False; o.swap=False; o.echo=False; o.fmt="%.2f"; o.dms=True; o.mult=1.0; o.files=[]; o.params={}; o.listopt=None
    i=0
    while i < len(argv):
        a=argv[i]
        if a.startswith('+'):
            s=a[1:]
            if '=' in s: k,v=s.split('=',1)
            else: k,v=s,"true"
            o.params[k]=v
        elif a.startswith('-') and a!='-':
            if a.startswith('--'): die("invalid option: --")
            j=1
            while j < len(a):
                c=a[j]
                rest=a[j+1:]
                if c=='I': o.inverse=True
                elif c=='r': o.reverse=True
                elif c=='s': o.swap=True
                elif c=='E': o.echo=True
                elif c in 'boStTvV': pass
                elif c=='l':
                    val=rest if rest else ''
                    if val.startswith('='): val=val[1:]
                    o.listopt='l'+val; j=len(a); break
                elif c in 'fdemwW':
                    val=rest
                    if not val:
                        i+=1
                        if i>=len(argv): die("missing argument for -"+c)
                        val=argv[i]
                    if c=='f': o.fmt=val; o.dms=False
                    elif c=='d': o.fmt="%."+str(int(float(val)))+"f"; o.dms=False
                    elif c=='m': o.mult=float(val)
                    elif c=='e': pass
                    elif c in 'wW': pass
                    j=len(a); break
                else:
                    die("invalid option: -"+c)
                j+=1
        else:
            o.files.append(a)
        i+=1
    return o

def flt(params,k,default=0.0):
    try: return float(params.get(k, default))
    except: return default

def radius(params):
    if 'R' in params: return float(params['R'])
    if 'a' in params: return float(params['a'])
    return A0

def e2(params):
    if 'R' in params or params.get('ellps')=='sphere': return 0.0
    if 'b' in params:
        a=radius(params); b=float(params['b']); return max(0.0,1-(b*b)/(a*a))
    if 'rf' in params:
        f=1/float(params['rf']); return 2*f-f*f
    return E2_WGS84

def adjlon(x):
    return (x+math.pi)%(2*math.pi)-math.pi

def parse_ang(s):
    s=s.strip()
    if not s: return 0.0
    sign=1
    up=s.upper()
    if up[-1:] in 'WS': sign=-1; s=s[:-1]
    elif up[-1:] in 'EN': s=s[:-1]
    if s.startswith('-'): sign*=-1; s=s[1:]
    if s.startswith('+'): s=s[1:]
    parts=re.split(r"[dD°'\"/:]+", s)
    parts=[p for p in parts if p!='']
    try:
        if len(parts)>=3: val=float(parts[0])+float(parts[1])/60+float(parts[2])/3600
        elif len(parts)==2: val=float(parts[0])+float(parts[1])/60
        else: val=float(parts[0])
        return sign*val
    except Exception:
        return 0.0

def fmt_num(x,o):
    if not math.isfinite(x): return "*"
    val=x*o.mult
    if abs(val) < 5e-12: val = 0.0
    try: return o.fmt % val
    except Exception: return ("%.2f" % (x*o.mult))

def fmt_ang(deg, ew):
    if not math.isfinite(deg): return "*"
    hemi = ("E" if deg>=0 else "W") if ew else ("N" if deg>=0 else "S")
    v=abs(deg); d=int(math.floor(v+1e-12)); rem=(v-d)*60; m=int(math.floor(rem+1e-12)); sec=(rem-m)*60
    if sec>=59.99995: sec=0; m+=1
    if m>=60: m=0; d+=1
    if abs(sec) < 0.00005 and m==0: return f"{d}d{hemi}"
    if abs(sec) < 0.00005: return f"{d}d{m}'{hemi}"
    return f"{d}d{m}'{sec:.3f}\"{hemi}"

def meridional_arc(phi,a,ecc):
    e4=ecc*ecc; e6=e4*ecc
    return a*((1-ecc/4-3*e4/64-5*e6/256)*phi-(3*ecc/8+3*e4/32+45*e6/1024)*math.sin(2*phi)+(15*e4/256+45*e6/1024)*math.sin(4*phi)-(35*e6/3072)*math.sin(6*phi))

def inv_meridional_arc(M,a,ecc):
    mu=M/(a*(1-ecc/4-3*ecc*ecc/64-5*ecc**3/256))
    e1=(1-math.sqrt(1-ecc))/(1+math.sqrt(1-ecc)) if ecc else 0.0
    return mu+(3*e1/2-27*e1**3/32)*math.sin(2*mu)+(21*e1*e1/16-55*e1**4/32)*math.sin(4*mu)+(151*e1**3/96)*math.sin(6*mu)+(1097*e1**4/512)*math.sin(8*mu)

def msfn(phi,ecc):
    return math.cos(phi)/math.sqrt(1-ecc*math.sin(phi)**2) if ecc else math.cos(phi)

def merc(lon,lat,p,inv=False):
    a=radius(p); ecc=e2(p); e=math.sqrt(ecc); lon0=math.radians(flt(p,'lon_0')); x0=flt(p,'x_0'); y0=flt(p,'y_0')
    if inv:
        lam=(lon-x0)/a+lon0; t=math.exp(-(lat-y0)/a); phi=math.pi/2-2*math.atan(t)
        if ecc:
            for _ in range(8):
                phi=math.pi/2-2*math.atan(t*((1-e*math.sin(phi))/(1+e*math.sin(phi)))**(e/2))
        return math.degrees(adjlon(lam)), math.degrees(phi)
    lr=math.radians(lon); br=math.radians(max(min(lat,89.999999),-89.999999));
    y=math.log(math.tan(math.pi/4+br/2))
    if ecc:
        y -= e/2*math.log((1+e*math.sin(br))/(1-e*math.sin(br)))
    return a*adjlon(lr-lon0)+x0, a*y+y0

def eqc(lon,lat,p,inv=False):
    a=radius(p); ecc=e2(p); lon0=math.radians(flt(p,'lon_0')); lat0=math.radians(flt(p,'lat_0')); lat_ts=math.radians(flt(p,'lat_ts',0)); x0=flt(p,'x_0'); y0=flt(p,'y_0'); c=msfn(lat_ts,ecc)
    M0=meridional_arc(lat0,a,ecc)
    if inv: return math.degrees(adjlon((lon-x0)/(a*c)+lon0)), math.degrees(inv_meridional_arc((lat-y0)+M0,a,ecc))
    return a*c*adjlon(math.radians(lon)-lon0)+x0, meridional_arc(math.radians(lat),a,ecc)-M0+y0

def sinu(lon,lat,p,inv=False):
    a=radius(p); ecc=e2(p); lon0=math.radians(flt(p,'lon_0')); x0=flt(p,'x_0'); y0=flt(p,'y_0')
    if inv:
        phi=inv_meridional_arc(lat-y0,a,ecc); return math.degrees(adjlon((lon-x0)/(a*max(msfn(phi,ecc),1e-15))+lon0)), math.degrees(phi)
    phi=math.radians(lat); return a*adjlon(math.radians(lon)-lon0)*msfn(phi,ecc)+x0, meridional_arc(phi,a,ecc)+y0

def moll(lon,lat,p,inv=False):
    a=radius(p); lon0=math.radians(flt(p,'lon_0')); x0=flt(p,'x_0'); y0=flt(p,'y_0')
    if inv:
        th=math.asin(max(-1,min(1,(lat-y0)/(math.sqrt(2)*a))))
        phi=math.asin(max(-1,min(1,(2*th+math.sin(2*th))/math.pi)))
        lam=lon0+(lon-x0)*math.pi/(2*math.sqrt(2)*a*max(math.cos(th),1e-15))
        return math.degrees(adjlon(lam)), math.degrees(phi)
    phi=math.radians(lat); th=phi
    for _ in range(10):
        den=2+2*math.cos(2*th)
        if abs(den)<1e-14: break
        th -= (2*th+math.sin(2*th)-math.pi*math.sin(phi))/den
    return 2*math.sqrt(2)*a/math.pi*adjlon(math.radians(lon)-lon0)*math.cos(th)+x0, math.sqrt(2)*a*math.sin(th)+y0

def aeqd(lon,lat,p,inv=False):
    a=radius(p); lam0=math.radians(flt(p,'lon_0')); phi0=math.radians(flt(p,'lat_0')); x0=flt(p,'x_0'); y0=flt(p,'y_0')
    sp0,cp0=math.sin(phi0),math.cos(phi0)
    if inv:
        x=(lon-x0); y=(lat-y0); rho=math.hypot(x,y); c=rho/a
        if rho<1e-12: return math.degrees(lam0), math.degrees(phi0)
        sc,cc=math.sin(c),math.cos(c); phi=math.asin(cc*sp0+y*sc*cp0/rho); lam=lam0+math.atan2(x*sc, rho*cp0*cc-y*sp0*sc)
        return math.degrees(adjlon(lam)), math.degrees(phi)
    lam=math.radians(lon); phi=math.radians(lat); d=adjlon(lam-lam0); sp,cp=math.sin(phi),math.cos(phi); cosc=sp0*sp+cp0*cp*math.cos(d); c=math.acos(max(-1,min(1,cosc))); k=1 if abs(c)<1e-12 else c/math.sin(c)
    return a*k*cp*math.sin(d)+x0, a*k*(cp0*sp-sp0*cp*math.cos(d))+y0

def laea(lon,lat,p,inv=False):
    a=radius(p); lam0=math.radians(flt(p,'lon_0')); phi0=math.radians(flt(p,'lat_0')); x0=flt(p,'x_0'); y0=flt(p,'y_0'); sp0,cp0=math.sin(phi0),math.cos(phi0)
    if inv:
        x=lon-x0; y=lat-y0; rho=math.hypot(x,y); c=2*math.asin(min(1,rho/(2*a)))
        if rho<1e-12: return math.degrees(lam0), math.degrees(phi0)
        phi=math.asin(math.cos(c)*sp0+y*math.sin(c)*cp0/rho); lam=lam0+math.atan2(x*math.sin(c),rho*cp0*math.cos(c)-y*sp0*math.sin(c)); return math.degrees(adjlon(lam)),math.degrees(phi)
    lam=math.radians(lon); phi=math.radians(lat); d=adjlon(lam-lam0); sp,cp=math.sin(phi),math.cos(phi); k=math.sqrt(2/(1+sp0*sp+cp0*cp*math.cos(d)))
    return a*k*cp*math.sin(d)+x0, a*k*(cp0*sp-sp0*cp*math.cos(d))+y0

def ortho(lon,lat,p,inv=False):
    a=radius(p); lam0=math.radians(flt(p,'lon_0')); phi0=math.radians(flt(p,'lat_0')); x0=flt(p,'x_0'); y0=flt(p,'y_0'); sp0,cp0=math.sin(phi0),math.cos(phi0)
    if inv:
        x=lon-x0; y=lat-y0; rho=math.hypot(x,y); c=math.asin(min(1,rho/a))
        if rho<1e-12: return math.degrees(lam0), math.degrees(phi0)
        phi=math.asin(math.cos(c)*sp0+y*math.sin(c)*cp0/rho); lam=lam0+math.atan2(x*math.sin(c),rho*cp0*math.cos(c)-y*sp0*math.sin(c)); return math.degrees(adjlon(lam)),math.degrees(phi)
    lam=math.radians(lon); phi=math.radians(lat); d=adjlon(lam-lam0); return a*math.cos(phi)*math.sin(d)+x0, a*(cp0*math.sin(phi)-sp0*math.cos(phi)*math.cos(d))+y0

def stere(lon,lat,p,inv=False):
    a=radius(p); lam0=math.radians(flt(p,'lon_0')); phi0=math.radians(flt(p,'lat_0')); x0=flt(p,'x_0'); y0=flt(p,'y_0'); sp0,cp0=math.sin(phi0),math.cos(phi0)
    if inv: return aeqd(lon,lat,p,True)
    lam=math.radians(lon); phi=math.radians(lat); d=adjlon(lam-lam0); sp,cp=math.sin(phi),math.cos(phi); k=2/(1+sp0*sp+cp0*cp*math.cos(d)); return a*k*cp*math.sin(d)+x0, a*k*(cp0*sp-sp0*cp*math.cos(d))+y0

def lcc(lon,lat,p,inv=False):
    a=radius(p); lam0=math.radians(flt(p,'lon_0')); phi0=math.radians(flt(p,'lat_0')); p1=math.radians(flt(p,'lat_1',flt(p,'lat_0',0))); p2=math.radians(flt(p,'lat_2',math.degrees(p1))); x0=flt(p,'x_0'); y0=flt(p,'y_0')
    n=math.sin(p1) if abs(p1-p2)<1e-12 else math.log(math.cos(p1)/math.cos(p2))/math.log(math.tan(math.pi/4+p2/2)/math.tan(math.pi/4+p1/2))
    F=math.cos(p1)*math.tan(math.pi/4+p1/2)**n/n; rho0=a*F/(math.tan(math.pi/4+phi0/2)**n)
    if inv:
        x=lon-x0; y=rho0-(lat-y0); rho=math.copysign(math.hypot(x,y),n); th=math.atan2(x,y); phi=2*math.atan((a*F/rho)**(1/n))-math.pi/2; lam=lam0+th/n; return math.degrees(adjlon(lam)),math.degrees(phi)
    phi=math.radians(lat); rho=a*F/(math.tan(math.pi/4+phi/2)**n); th=n*adjlon(math.radians(lon)-lam0); return x0+rho*math.sin(th), y0+rho0-rho*math.cos(th)

def aea(lon,lat,p,inv=False):
    a=radius(p); lam0=math.radians(flt(p,'lon_0')); phi0=math.radians(flt(p,'lat_0')); p1=math.radians(flt(p,'lat_1',0)); p2=math.radians(flt(p,'lat_2',math.degrees(p1))); x0=flt(p,'x_0'); y0=flt(p,'y_0')
    n=0.5*(math.sin(p1)+math.sin(p2)); C=math.cos(p1)**2+2*n*math.sin(p1); rho0=a*math.sqrt(max(0,C-2*n*math.sin(phi0)))/n
    if inv:
        x=lon-x0; y=rho0-(lat-y0); rho=math.copysign(math.hypot(x,y),n); phi=math.asin((C-(rho*n/a)**2)/(2*n)); lam=lam0+math.atan2(x,y)/n; return math.degrees(adjlon(lam)),math.degrees(phi)
    phi=math.radians(lat); rho=a*math.sqrt(max(0,C-2*n*math.sin(phi)))/n; th=n*adjlon(math.radians(lon)-lam0); return x0+rho*math.sin(th), y0+rho0-rho*math.cos(th)

def utm(lon,lat,p,inv=False):
    zone=int(float(p.get('zone', math.floor((lon+180)/6)+1 if not inv else 31))); south='south' in p or p.get('south')=='true'; lam0=math.radians(zone*6-183); a=radius(p); ecc=e2({'ellps':'WGS84'}); k0=0.9996; x0=500000; y0=10000000 if south else 0
    ep2=ecc/(1-ecc)
    if inv:
        x=lon-x0; y=lat-y0; M=y/k0; mu=M/(a*(1-ecc/4-3*ecc*ecc/64-5*ecc**3/256)); e1=(1-math.sqrt(1-ecc))/(1+math.sqrt(1-ecc));
        J1=3*e1/2-27*e1**3/32; J2=21*e1*e1/16-55*e1**4/32; J3=151*e1**3/96; J4=1097*e1**4/512; fp=mu+J1*math.sin(2*mu)+J2*math.sin(4*mu)+J3*math.sin(6*mu)+J4*math.sin(8*mu)
        C1=ep2*math.cos(fp)**2; T1=math.tan(fp)**2; N1=a/math.sqrt(1-ecc*math.sin(fp)**2); R1=a*(1-ecc)/(1-ecc*math.sin(fp)**2)**1.5; D=x/(N1*k0)
        phi=fp-(N1*math.tan(fp)/R1)*(D*D/2-(5+3*T1+10*C1-4*C1*C1-9*ep2)*D**4/24+(61+90*T1+298*C1+45*T1*T1-252*ep2-3*C1*C1)*D**6/720)
        lam=lam0+(D-(1+2*T1+C1)*D**3/6+(5-2*C1+28*T1-3*C1*C1+8*ep2+24*T1*T1)*D**5/120)/math.cos(fp); return math.degrees(lam),math.degrees(phi)
    phi=math.radians(lat); lam=math.radians(lon); N=a/math.sqrt(1-ecc*math.sin(phi)**2); T=math.tan(phi)**2; C=ep2*math.cos(phi)**2; A=math.cos(phi)*adjlon(lam-lam0)
    M=a*((1-ecc/4-3*ecc*ecc/64-5*ecc**3/256)*phi-(3*ecc/8+3*ecc*ecc/32+45*ecc**3/1024)*math.sin(2*phi)+(15*ecc*ecc/256+45*ecc**3/1024)*math.sin(4*phi)-(35*ecc**3/3072)*math.sin(6*phi))
    x=x0+k0*N*(A+(1-T+C)*A**3/6+(5-18*T+T*T+72*C-58*ep2)*A**5/120)
    y=y0+k0*(M+N*math.tan(phi)*(A*A/2+(5-T+9*C+4*C*C)*A**4/24+(61-58*T+T*T+600*C-330*ep2)*A**6/720))
    return x,y

def robin(lon,lat,p,inv=False):
    # Compact approximation using natural-earth-like scaling, sufficient for common smoke tests.
    return eqc(lon*0.8487, lat*0.965, p, inv)

def transform(x,y,o):
    if o.reverse: x,y=y,x
    pr=o.params.get('proj','')
    if pr in ('lonlat','longlat','latlong'): die("can't initialize operations that produce angular output coordinates" if not o.inverse else "can't initialize operations that take non-angular input coordinates. Try cct.")
    funcs={'merc':merc,'webmerc':merc,'eqc':eqc,'latlong':eqc,'sinu':sinu,'moll':moll,'aeqd':aeqd,'laea':laea,'ortho':ortho,'stere':stere,'lcc':lcc,'aea':aea,'utm':utm,'tmerc':utm,'robin':robin,'mill':merc}
    f=funcs.get(pr)
    if not f: die("projection initialization failure\ncause: Unknown error (code 2)")
    X,Y=f(x,y,o.params,o.inverse)
    if o.swap: X,Y=Y,X
    return X,Y

def listit(kind):
    if kind=='le': print(ELLPS); return
    if kind=='lu': print(UNITS); return
    if kind and kind.startswith('l') and len(kind)>1 and kind not in ('lp','lP'):
        name=kind[1:]
        for k,d in PROJS:
            if k==name:
                print(f"{k:>9} : {d}");
                if k=='merc': print("\tCyl, Sph&Ell\n\tlat_ts=")
                return
        return
    detailed=(kind=='lP')
    for k,d in PROJS:
        print(f"{k} : {d}")
        if detailed and k in ('merc','aea','aeqd','eqc','lcc'):
            print("\t" + {'merc':'Cyl, Sph&Ell\n\tlat_ts=','aea':'Conic Sph&Ell\n\tlat_1= lat_2=','aeqd':'Azi, Sph&Ell\n\tlat_0 guam','eqc':'Cyl, Sph&Ell\n\tlat_ts=[, lat_0=0]','lcc':'Conic Sph&Ell\n\tlat_1= lat_2='}[k])

def process_line(line,o):
    raw=line.rstrip('\n')
    m=re.match(r'\s*([^\s]+)?\s*([^\s]+)?(.*)$', raw)
    if not m or m.group(1) is None: return raw
    a=m.group(1) or '0'; b=m.group(2) or '0'; rest=m.group(3) or ''
    x=parse_ang(a) if not o.inverse else float(a) if re.match(r'^[+-]?[0-9.]',a) else 0.0
    y=parse_ang(b) if not o.inverse else float(b) if re.match(r'^[+-]?[0-9.]',b) else 0.0
    X,Y=transform(x,y,o)
    if o.inverse and o.dms:
        out=fmt_ang(X,True)+'\t'+fmt_ang(Y,False)
    else:
        out=fmt_num(X,o)+'\t'+fmt_num(Y,o)
    if o.echo: out=(a + ((' '+b) if b else '') + '\t' + out)
    return out + rest

def main():
    o=parse(sys.argv[1:])
    if o.listopt: listit(o.listopt); return
    if not o.params and not o.files:
        usage(); return
    if 'init' in o.params and o.params['init'].lower()=='epsg:4326': die("can't initialize operations that take non-angular input coordinates. Try cct.")
    sources=[]
    if o.files: sources=[open(f, errors='replace') for f in o.files]
    else: sources=[sys.stdin]
    for src in sources:
        for line in src:
            try: print(process_line(line,o))
            except Exception: print('*\t*')

if __name__=='__main__': main()
