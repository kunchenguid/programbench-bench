#!/usr/bin/env python3
import argparse
import re
import sys


VERSION = "melody_cli 0.20.0"


SYMBOLS = {
    "char": ".",
    "space": " ",
    "whitespace": r"\s",
    "digit": r"\d",
    "word": r"\w",
    "start": "^",
    "end": "$",
    "boundary": r"\b",
    "tab": r"\t",
    "newline": r"\n",
    "return": r"\r",
    "feed": r"\f",
    "null": r"\0",
    "alphabetic": "[a-zA-Z]",
    "alphanumeric": "[a-zA-Z0-9]",
}

NEG_SYMBOLS = {
    "space": "[^ ]",
    "whitespace": r"\S",
    "digit": r"\D",
    "word": r"\W",
    "alphabetic": "[^a-zA-Z]",
    "alphanumeric": "[^a-zA-Z0-9]",
}

REGEX_SPECIAL = set(r"\.^$*+?{}[]|()")


class MelodyError(Exception):
    pass


class Parser:
    def __init__(self, text):
        self.text = text
        self.i = 0

    def eof(self):
        self._ws()
        return self.i >= len(self.text)

    def _ws(self):
        while self.i < len(self.text):
            c = self.text[self.i]
            if c.isspace():
                self.i += 1
                continue
            if self.text.startswith("//", self.i):
                self.i += 2
                while self.i < len(self.text) and self.text[self.i] != "\n":
                    self.i += 1
                continue
            break

    def _word(self):
        self._ws()
        start = self.i
        while self.i < len(self.text) and (self.text[self.i].isalnum() or self.text[self.i] == "_"):
            self.i += 1
        return self.text[start:self.i]

    def _peek_word(self):
        pos = self.i
        word = self._word()
        self.i = pos
        return word

    def _expect_word(self, expected):
        word = self._word()
        if word != expected:
            raise MelodyError("expected " + expected)

    def _number(self):
        self._ws()
        start = self.i
        while self.i < len(self.text) and self.text[self.i].isdigit():
            self.i += 1
        if start == self.i:
            raise MelodyError("expected amount")
        return int(self.text[start:self.i])

    def _accept(self, s):
        self._ws()
        if self.text.startswith(s, self.i):
            self.i += len(s)
            return True
        return False

    def parse(self, until=None):
        parts = []
        while True:
            self._ws()
            if self.i >= len(self.text):
                if until:
                    raise MelodyError("expected " + until)
                break
            if until and self.text.startswith(until, self.i):
                self.i += len(until)
                break
            parts.append(self.atom())
            self._ws()
            self._accept(";")
        return "".join(parts)

    def atom(self):
        self._ws()
        word = self._peek_word()

        if word in ("some", "any", "option"):
            self._word()
            self._expect_word("of")
            item = self.atom()
            return self._quantify(item, {"some": "+", "any": "*", "option": "?"}[word])

        if self.i < len(self.text) and self.text[self.i].isdigit():
            low = self._number()
            self._ws()
            if self._peek_word() == "to":
                self._word()
                high = self._number()
                self._expect_word("of")
                return self._quantify(self.atom(), "{%d,%d}" % (low, high))
            self._expect_word("of")
            return self._quantify(self.atom(), "{%d}" % low)

        if word == "not":
            self._word()
            return self.negated()

        if word in ("match", "either", "capture"):
            self._word()
            return self.group(word)

        if word in ("ahead", "behind"):
            self._word()
            return self.assertion(word, False)

        c = self.text[self.i] if self.i < len(self.text) else ""
        if c == '"':
            return self.literal()
        if c == "`":
            return self.raw()
        if c == "<":
            return self.symbol()
        raise MelodyError("expected root")

    def negated(self):
        self._ws()
        word = self._peek_word()
        if word in ("ahead", "behind"):
            self._word()
            return self.assertion(word, True)
        if self.i < len(self.text) and self.text[self.i] == "<":
            name = self.symbol_name()
            if name == "char":
                raise MelodyError("negative char not allowed")
            if name not in NEG_SYMBOLS:
                raise MelodyError("usage of an unrecognized symbol")
            return NEG_SYMBOLS[name]
        raise MelodyError("expected amount, class_content, or assertion_type")

    def group(self, kind):
        self._ws()
        if not self._accept("{"):
            raise MelodyError("expected {")
        body_start = self.i
        items = []
        while True:
            self._ws()
            if self.i >= len(self.text):
                raise MelodyError("expected }")
            if self._accept("}"):
                break
            items.append(self.atom())
            self._ws()
            self._accept(";")
        if kind == "capture":
            return "(" + "".join(items) + ")"
        if kind == "either":
            return "(?:" + "|".join(items) + ")"
        _ = body_start
        return "(?:" + "".join(items) + ")"

    def assertion(self, kind, neg):
        self._ws()
        if not self._accept("{"):
            raise MelodyError("expected {")
        body = self.parse("}")
        if kind == "ahead":
            return ("(?!" if neg else "(?=") + body + ")"
        return ("(?<!" if neg else "(?<=") + body + ")"

    def symbol_name(self):
        self._ws()
        if not self._accept("<"):
            raise MelodyError("expected symbol")
        start = self.i
        while self.i < len(self.text) and self.text[self.i] != ">":
            self.i += 1
        if self.i >= len(self.text):
            raise MelodyError("expected >")
        name = self.text[start:self.i].strip()
        self.i += 1
        return name

    def symbol(self):
        name = self.symbol_name()
        if name not in SYMBOLS:
            raise MelodyError("usage of an unrecognized symbol")
        return SYMBOLS[name]

    def raw(self):
        self.i += 1
        start = self.i
        while self.i < len(self.text) and self.text[self.i] != "`":
            self.i += 1
        if self.i >= len(self.text):
            raise MelodyError("expected raw")
        out = self.text[start:self.i]
        self.i += 1
        return out

    def literal(self):
        self.i += 1
        out = []
        while self.i < len(self.text):
            c = self.text[self.i]
            if c == '"':
                self.i += 1
                return "".join(out)
            if c == "\\" and self.i + 1 < len(self.text):
                self.i += 1
                c = self.text[self.i]
                maps = {"n": "\n", "t": "\t", "r": "\r", "f": "\f", "0": "\0"}
                c = maps.get(c, c)
            if c in REGEX_SPECIAL:
                out.append("\\" + c)
            else:
                out.append(c)
            self.i += 1
        raise MelodyError("expected root")

    def _quantify(self, item, q):
        if len(item) == 1 or item.startswith("\\") and len(item) == 2 or item.startswith("[") and item.endswith("]"):
            return item + q
        if item.startswith("("):
            return item + q
        return "(?:" + item + ")" + q


def compile_melody(text):
    p = Parser(text)
    result = p.parse()
    if not p.eof():
        raise MelodyError("expected root")
    return result


def read_input(path):
    if path is None or path == "-":
        return sys.stdin.read()
    with open(path, "r", encoding="utf-8") as f:
        return f.read()


def print_help():
    print("""A CLI wrapping the Melody language compiler

Usage: executable [OPTIONS] [INPUT_FILE_PATH]

Arguments:
  [INPUT_FILE_PATH]  Read from a file
                     Use '-' and or pipe input to read from stdin

Options:
  -o, --output <OUTPUT_FILE_PATH>           Write to a file
  -n, --no-color                            Print output with no color
  -r, --repl                                Start the Melody REPL
      --generate-completions <completions>  Outputs completions for the selected shell
                                            To use, write the output to the appropriate location for your shell
  -t, --test <test>                         Test the compiled regex against a string
  -f, --test-file <test-file>               Test the compiled regex against the contents of a file
  -h, --help                                Print help
  -V, --version                             Print version""")


def completions(shell):
    opts = "-o -n -r -t -f -h -V --output --no-color --repl --generate-completions --test --test-file --help --version"
    if shell == "bash":
        return "_melody() {\n    COMPREPLY=( $(compgen -W \"%s\" -- \"${COMP_WORDS[COMP_CWORD]}\") )\n}\ncomplete -F _melody melody\n" % opts
    return opts + "\n"


def run_repl():
    while True:
        try:
            line = input("> ")
        except EOFError:
            break
        try:
            print(compile_melody(line))
        except MelodyError as e:
            print("Error: " + str(e), file=sys.stderr)


def main(argv):
    if "--help" in argv or "-h" in argv:
        print_help()
        return 0
    if "--version" in argv or "-V" in argv:
        print(VERSION)
        return 0

    ap = argparse.ArgumentParser(add_help=False)
    ap.add_argument("-o", "--output")
    ap.add_argument("-n", "--no-color", action="store_true")
    ap.add_argument("-r", "--repl", action="store_true")
    ap.add_argument("--generate-completions")
    ap.add_argument("-t", "--test")
    ap.add_argument("-f", "--test-file")
    ap.add_argument("input", nargs="?")
    try:
        ns = ap.parse_args(argv)
    except SystemExit:
        return 2

    if ns.generate_completions:
        sys.stdout.write(completions(ns.generate_completions))
        return 0
    if ns.repl:
        run_repl()
        return 0

    try:
        regex = compile_melody(read_input(ns.input))
    except (OSError, MelodyError) as e:
        print("Error: " + str(e), file=sys.stderr)
        return 65

    if ns.output:
        try:
            with open(ns.output, "w", encoding="utf-8") as f:
                f.write(regex)
        except OSError as e:
            print("Error: " + str(e), file=sys.stderr)
            return 1

    if ns.test_file:
        try:
            with open(ns.test_file, "r", encoding="utf-8") as f:
                target = f.read()
        except OSError as e:
            print("Error: " + str(e), file=sys.stderr)
            return 1
        print(f"{ns.test_file} {'matched' if re.search(regex, target) else 'did not match'}")
        return 0

    if ns.test is not None:
        print(f"'{ns.test}' {'matched' if re.search(regex, ns.test) else 'did not match'}")
        return 0

    if not ns.output:
        print(regex)
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
