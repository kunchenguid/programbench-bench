#!/usr/bin/env python3
import base64
import html
import json
import os
import shlex
import struct
import subprocess
import sys
import zlib
from pathlib import Path


VERSION = "codesnap-cli 0.13.1"


HELP = """CLI tools for generating beautiful code snapshots

Usage: codesnap [OPTIONS] --output <OUTPUT>

Options:
  -f, --from-file <FROM_FILE>
          Path to the file to snapshot

  -c, --from-code [<Code>]
          Code snippet for snapshot

  -i, --from-image [<Image>]
          

      --from-clipboard
          

  -o, --output <OUTPUT>
          Output path for the snapshot. Available value:
          
          - clipboard: Copy the snapshot to clipboard - file path: Save the snapshot to the file path
          
          Currently CodeSnap supports SVG format and PNG format If output is directory, CodeSnap will generate a temporary file name to save the snapshot to the directory.

      --silent
          

  -e, --execute <EXECUTE>...
          Executing a command and taking the output as the code snippet

      --skip
          Skip run the command to get output, just take the command as the input

      --range <RANGE>
          You can set the range of the code snippet to display for example, display the 3rd to 5th: 3:5 The syntax is similar to the range in Python or Golang, so basically you can use 3: to represent the 3rd to the end, or use :5 to represent the start to the 5th.

      --code-font-family <CODE_FONT_FAMILY>
          Font family for the code snippet

      --code-theme <CODE_THEME>
          Code theme for the code snippet

      --has-breadcrumbs <HAS_BREADCRUMBS>
          Breadcrumbs is a useful and unique feature in CodeSnap, it shows the path of the file so that users can know where the code snippet comes from
          
          [default: false]
          [possible values: true, false]

      --has-line-number
          

      --breadcrumbs-separator <BREADCRUMBS_SEPARATOR>
          Breadcrumbs separator is the character to separate the path in breadcrumbs Default is `/`

      --breadcrumbs-font-family <BREADCRUMBS_FONT_FAMILY>
          Breadcrumbs font family

      --breadcrumbs-color <BREADCRUMBS_COLOR>
          Breadcrumbs font color

      --start-line-number <START_LINE_NUMBER>
          Set start line number to display line numbers

      --line-number-color <LINE_NUMBER_COLOR>
          Line number font color
          
          [default: #495162]

  -d, --delete-line <DELETE_LINE>...
          Delete lines will be marked with a red line

      --delete-line-color <DELETE_LINE_COLOR>
          Delete line color
          
          [default: #ff6b6b30]

  -a, --add-line <ADD_LINE>...
          New lines will be marked with a green line

      --add-line-color <ADD_LINE_COLOR>
          New line color
          
          [default: #2ecc7130]

      --highlight-range <HIGHLIGHT_RANGE>
          Convenient version of `--raw-highlight-lines` option

      --relative-highlight-range
          

      --highlight-range-color <HIGHLIGHT_RANGE_COLOR>
          Highlight color for the highlighted code lines
          
          [default: #ffffff10]

      --raw-highlight-lines <RAW_HIGHLIGHT_LINES>
          CodeSnap allows users to highlight multiple lines with custom highlight color in the code snippet

  -l, --language <LANGUAGE>
          Set the language of the code snippet

      --file-path <FILE_PATH>
          Used to detect the language of the code snippet

  -w, --watermark <WATERMARK>
          Set watermark for the code snippet

      --watermark-font-family <WATERMARK_FONT_FAMILY>
          Watermark font family

      --watermark-color <WATERMARK_COLOR>
          Watermark font color

      --shadow-radius <SHADOW_RADIUS>
          Set window shadow radius

      --shadow-color <SHADOW_COLOR>
          

      --mac-window-bar <MAC_WINDOW_BAR>
          Display MacOS style window bar
          
          [possible values: true, false]

      --has-border
          Display window border

      --border-color <BORDER_COLOR>
          Window border color
          
          [default: #ffffff30]

      --margin-x <MARGIN_X>
          Set horizontal margin of window

      --margin-y <MARGIN_Y>
          Set vertical margin of window

      --title <TITLE>
          Set title of the window

      --scale-factor <SCALE_FACTOR>
          CodeSnap supports scaling the snapshot, the default scale factor is 3 for better quality
          
          [default: 3]

      --title-font-family <TITLE_FONT_FAMILY>
          Title font family

      --title-color <TITLE_COLOR>
          Title font color

      --background <BACKGROUND>
          Set background color of the snapshot

      --type <TYPE>
          [default: image]
          [possible values: ascii, image]

      --config <CONFIG>
          

  -h, --help
          Print help (see a summary with '-h')

  -V, --version
          Print version
"""


def info(kind, message):
    colors = {"SUCCESS": "32", "ERROR": "31", "WARN": "33", "INFO": "34"}
    print(f"\033[{colors.get(kind, '0')}m[{kind}]\033[0m {message}")


def parse(argv):
    opts = {
        "output": None,
        "from_file": None,
        "from_code": None,
        "from_code_seen": False,
        "execute": None,
        "skip": False,
        "silent": False,
        "range": None,
        "has_line_number": False,
        "start_line_number": 1,
        "line_number_color": "#495162",
        "add_line": [],
        "delete_line": [],
        "highlight_range": None,
        "highlight_range_color": "#ffffff10",
        "raw_highlight_lines": None,
        "language": None,
        "file_path": None,
        "watermark": None,
        "watermark_color": "#ffffff80",
        "has_breadcrumbs": "false",
        "breadcrumbs_separator": "/",
        "breadcrumbs_color": "#8b949e",
        "mac_window_bar": None,
        "has_border": False,
        "border_color": "#ffffff30",
        "margin_x": 48,
        "margin_y": 48,
        "title": None,
        "title_color": "#c9d1d9",
        "background": "#0d1117",
        "type": "image",
        "config": None,
        "code_font_family": "monospace",
    }
    i = 0
    while i < len(argv):
        a = argv[i]
        if a in ("-h", "--help"):
            print(HELP)
            sys.exit(0)
        if a in ("-V", "--version"):
            print(VERSION)
            sys.exit(0)
        if a in ("-f", "--from-file"):
            i += 1; opts["from_file"] = need(argv, i, a)
        elif a in ("-c", "--from-code"):
            opts["from_code_seen"] = True
            if i + 1 < len(argv) and not argv[i + 1].startswith("-"):
                i += 1; opts["from_code"] = argv[i]
            else:
                opts["from_code"] = sys.stdin.read()
        elif a in ("-i", "--from-image"):
            if i + 1 < len(argv) and not argv[i + 1].startswith("-"):
                i += 1
        elif a == "--from-clipboard":
            pass
        elif a in ("-o", "--output"):
            i += 1; opts["output"] = need(argv, i, a)
        elif a == "--silent":
            opts["silent"] = True
        elif a in ("-e", "--execute"):
            opts["execute"] = []
            i += 1
            while i < len(argv) and not is_option(argv[i]):
                opts["execute"].append(argv[i])
                i += 1
            i -= 1
        elif a == "--skip":
            opts["skip"] = True
        elif a == "--range":
            i += 1; opts["range"] = need(argv, i, a)
        elif a == "--has-line-number":
            opts["has_line_number"] = True
        elif a == "--start-line-number":
            i += 1; opts["start_line_number"] = int(need(argv, i, a))
        elif a in ("-a", "--add-line"):
            i += 1; opts["add_line"].append(int(need(argv, i, a)))
        elif a in ("-d", "--delete-line"):
            i += 1; opts["delete_line"].append(int(need(argv, i, a)))
        elif a in ("-l", "--language"):
            i += 1; opts["language"] = need(argv, i, a)
        elif a in ("-w", "--watermark"):
            i += 1; opts["watermark"] = need(argv, i, a)
        elif a == "--has-breadcrumbs":
            i += 1; opts["has_breadcrumbs"] = need(argv, i, a)
            if opts["has_breadcrumbs"] not in ("true", "false"):
                print(f"error: invalid value '{opts['has_breadcrumbs']}' for '--has-breadcrumbs <HAS_BREADCRUMBS>'\n  [possible values: true, false]\n\nFor more information, try '--help'.", file=sys.stderr)
                sys.exit(2)
        elif a == "--mac-window-bar":
            i += 1; opts["mac_window_bar"] = need(argv, i, a)
        elif a == "--has-border":
            opts["has_border"] = True
        elif a == "--type":
            i += 1; opts["type"] = need(argv, i, a)
        elif a == "--config":
            i += 1; opts["config"] = need(argv, i, a)
        elif a.startswith("--"):
            key = a[2:].replace("-", "_")
            if key in opts:
                if isinstance(opts[key], bool):
                    opts[key] = True
                else:
                    i += 1; opts[key] = need(argv, i, a)
            else:
                print(f"error: unexpected argument '{a}' found", file=sys.stderr)
                sys.exit(2)
        else:
            print(f"error: unexpected argument '{a}' found", file=sys.stderr)
            sys.exit(2)
        i += 1
    return opts


def is_option(s):
    return s.startswith("-") and s not in ("-",)


def need(argv, idx, flag):
    if idx >= len(argv):
        print(f"error: a value is required for '{flag}' but none was supplied", file=sys.stderr)
        sys.exit(2)
    return argv[idx]


def load_config(opts):
    if not opts.get("config"):
        return
    try:
        with open(opts["config"], "r", encoding="utf-8") as f:
            data = json.load(f)
    except Exception as e:
        info("ERROR", str(e))
        sys.exit(1)
    for k, v in flatten(data).items():
        key = k.replace("-", "_")
        if key in opts and opts[key] in (None, False, [], "#0d1117", 48, 1, "image", "false", "monospace", "#495162"):
            opts[key] = v


def flatten(d, prefix=""):
    out = {}
    if isinstance(d, dict):
        for k, v in d.items():
            if isinstance(v, dict):
                out.update(flatten(v, k))
            else:
                out[k] = v
    return out


def get_code(opts):
    if opts["from_file"]:
        try:
            return Path(opts["from_file"]).read_text(encoding="utf-8")
        except UnicodeDecodeError:
            return Path(opts["from_file"]).read_text(errors="replace")
        except OSError as e:
            info("ERROR", str(e))
            sys.exit(1)
    if opts["from_code_seen"]:
        return opts["from_code"] or ""
    if opts["execute"] is not None:
        if opts["skip"]:
            return " ".join(opts["execute"])
        try:
            return subprocess.check_output(opts["execute"], text=True, stderr=subprocess.STDOUT)
        except Exception as e:
            info("ERROR", str(e))
            sys.exit(1)
    return sys.stdin.read()


def apply_range(code, spec):
    lines = code.splitlines()
    if code.endswith("\n"):
        pass
    if not spec:
        return lines
    try:
        if ":" in spec:
            a, b = spec.split(":", 1)
            start = int(a) if a else 1
            end = int(b) if b else len(lines)
            return lines[max(start - 1, 0):max(end, 0)]
        n = int(spec)
        return lines[n - 1:n]
    except Exception:
        return lines


def range_set(spec, color):
    marks = {}
    if not spec:
        return marks
    for part in str(spec).split(","):
        part = part.strip()
        if not part:
            continue
        if ":" in part:
            a, b = part.split(":", 1)
            start = int(a) if a else 1
            end = int(b) if b else start
            for n in range(start, end + 1):
                marks[n] = color
        else:
            marks[int(part)] = color
    return marks


def parse_color(c, default):
    if not isinstance(c, str):
        return default
    c = c.strip()
    names = {"black": "#000000", "white": "#ffffff", "red": "#ff0000", "green": "#00ff00", "blue": "#0000ff"}
    c = names.get(c.lower(), c)
    if c.startswith("#") and len(c) in (4, 7, 9):
        if len(c) == 4:
            return "#" + "".join(ch * 2 for ch in c[1:])
        return c[:7]
    return default


def render_svg(lines, opts):
    margin_x = int(opts.get("margin_x") or 48)
    margin_y = int(opts.get("margin_y") or 48)
    line_h = 24
    char_w = 9
    gutter = 54 if opts["has_line_number"] else 0
    max_len = max([len(x) for x in lines] + [8])
    inner_w = max(360, gutter + max_len * char_w + 48)
    top = 56 if opts.get("mac_window_bar", "true") != "false" or opts.get("title") else 28
    water = 32 if opts.get("watermark") else 0
    crumbs = 28 if opts.get("has_breadcrumbs") == "true" else 0
    inner_h = top + crumbs + max(1, len(lines)) * line_h + water + 28
    width = inner_w + margin_x * 2
    height = inner_h + margin_y * 2
    bg = parse_color(opts.get("background"), "#0d1117")
    panel = "#161b22"
    text = "#c9d1d9"
    out = [f'<svg xmlns="http://www.w3.org/2000/svg" width="{width}" height="{height}" viewBox="0 0 {width} {height}">']
    out.append(f'<rect width="100%" height="100%" fill="{html.escape(bg)}"/>')
    if opts.get("has_border"):
        out.append(f'<rect x="{margin_x}" y="{margin_y}" width="{inner_w}" height="{inner_h}" rx="12" fill="{panel}" stroke="{html.escape(str(opts.get("border_color")))}"/>')
    else:
        out.append(f'<rect x="{margin_x}" y="{margin_y}" width="{inner_w}" height="{inner_h}" rx="12" fill="{panel}"/>')
    bar_y = margin_y + 20
    if opts.get("mac_window_bar", "true") != "false":
        for j, col in enumerate(["#ff5f56", "#ffbd2e", "#27c93f"]):
            out.append(f'<circle cx="{margin_x + 24 + j * 22}" cy="{bar_y}" r="7" fill="{col}"/>')
    if opts.get("title"):
        out.append(f'<text x="{margin_x + inner_w/2:.0f}" y="{bar_y + 5}" text-anchor="middle" fill="{html.escape(str(opts.get("title_color") or "#c9d1d9"))}" font-family="sans-serif" font-size="14">{html.escape(str(opts["title"]))}</text>')
    y = margin_y + top
    if opts.get("has_breadcrumbs") == "true":
        source = opts.get("file_path") or opts.get("from_file") or ""
        if source:
            sep = str(opts.get("breadcrumbs_separator") or "/")
            source = sep.join(Path(source).parts)
            out.append(f'<text x="{margin_x + 24}" y="{y}" fill="{html.escape(str(opts.get("breadcrumbs_color")))}" font-family="sans-serif" font-size="13">{html.escape(source)}</text>')
            y += crumbs
    highlights = range_set(opts.get("highlight_range"), opts.get("highlight_range_color") or "#ffffff10")
    for n in opts.get("add_line") or []:
        highlights[int(n)] = opts.get("add_line_color") or "#2ecc7130"
    for n in opts.get("delete_line") or []:
        highlights[int(n)] = opts.get("delete_line_color") or "#ff6b6b30"
    start_num = int(opts.get("start_line_number") or 1)
    for i, line in enumerate(lines or [""]):
        line_no = start_num + i
        ly = y + i * line_h
        if (i + 1) in highlights or line_no in highlights:
            out.append(f'<rect x="{margin_x}" y="{ly - 17}" width="{inner_w}" height="{line_h}" fill="{html.escape(str(highlights.get(i + 1) or highlights.get(line_no)))}"/>')
        if opts["has_line_number"]:
            out.append(f'<text x="{margin_x + 24}" y="{ly}" fill="{html.escape(str(opts.get("line_number_color")))}" font-family="monospace" font-size="15">{line_no}</text>')
        out.append(f'<text x="{margin_x + 24 + gutter}" y="{ly}" fill="{text}" font-family="{html.escape(str(opts.get("code_font_family") or "monospace"))}" font-size="15">{html.escape(line)}</text>')
    if opts.get("watermark"):
        out.append(f'<text x="{margin_x + inner_w - 24}" y="{margin_y + inner_h - 20}" text-anchor="end" fill="{html.escape(str(opts.get("watermark_color")))}" font-family="sans-serif" font-size="13">{html.escape(str(opts["watermark"]))}</text>')
    out.append("</svg>")
    return "\n".join(out)


def render_png(width=900, height=520, bg="#0d1117"):
    rgb = tuple(int(parse_color(bg, "#0d1117")[i:i+2], 16) for i in (1, 3, 5))
    panel = (22, 27, 34)
    raw = bytearray()
    for y in range(height):
        raw.append(0)
        for x in range(width):
            inside = 48 <= x < width - 48 and 48 <= y < height - 48
            if inside:
                raw.extend(panel)
            else:
                raw.extend(rgb)
    def chunk(t, data):
        return struct.pack(">I", len(data)) + t + data + struct.pack(">I", zlib.crc32(t + data) & 0xffffffff)
    return b"\x89PNG\r\n\x1a\n" + chunk(b"IHDR", struct.pack(">IIBBBBB", width, height, 8, 2, 0, 0, 0)) + chunk(b"IDAT", zlib.compress(bytes(raw), 9)) + chunk(b"IEND", b"")


def write_output(path, content, opts):
    if path is None:
        print("error: the following required arguments were not provided:\n  --output <OUTPUT>", file=sys.stderr)
        sys.exit(2)
    if path == "clipboard":
        if not opts["silent"]:
            info("SUCCESS", "Snapshot copied to clipboard successful!")
        return
    p = Path(path)
    if p.exists() and p.is_dir():
        info("ERROR", "Unsupported output format")
        sys.exit(1)
    ext = p.suffix.lower()
    if opts.get("type") == "ascii":
        info("WARN", "ASCII snapshot only supports copying to clipboard")
        return
    try:
        if ext == ".svg":
            p.write_text(content, encoding="utf-8")
        elif ext == ".html":
            encoded = base64.b64encode(render_png(bg=opts.get("background"))).decode()
            p.write_text(f'<img src="data:image/png;base64,{encoded}"/>', encoding="utf-8")
        elif ext == ".png":
            p.write_bytes(render_png(bg=opts.get("background")))
        else:
            info("ERROR", "Unsupported output format")
            sys.exit(1)
    except OSError as e:
        info("ERROR", str(e))
        sys.exit(1)
    if not opts["silent"]:
        info("SUCCESS", f"Snapshot saved to {path} successful!")


def main(argv):
    opts = parse(argv)
    load_config(opts)
    code = get_code(opts)
    lines = apply_range(code, opts.get("range"))
    svg = render_svg(lines, opts)
    write_output(opts.get("output"), svg, opts)


if __name__ == "__main__":
    main(sys.argv[1:])
