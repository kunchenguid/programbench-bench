#!/usr/bin/env python3
import argparse
import fnmatch
import grp
import os
import pwd
import stat
import sys
from datetime import datetime

ARROW = "\U000f0054"

DETAIL_CHOICES = [
    "dev", "ino", "nlink", "typ", "perm", "oct", "user", "uid", "group", "gid",
    "size", "blocks", "btime", "ctime", "mtime", "atime", "git", "none", "std", "all",
]
SORT_CHOICES = [
    "dev", "ino", "nlink", "typ", "cat", "user", "uid", "group", "gid", "size",
    "blocks", "btime", "ctime", "mtime", "atime", "name", "cname", "ext",
    "inode_", "nlinks_", "typ_", "cat_", "user_", "uid_", "group_", "gid_", "size_",
    "blocks_", "btime_", "ctime_", "mtime_", "atime_", "name_", "cname_", "ext_", "none",
]
TYPE_CHOICES = ["dir", "symlink", "fifo", "socket", "block-device", "char-device", "file", "none", "all"]

LONG_HELP = """pls is a prettier and powerful ls(1) for the pros.

Read docs: https://pls.cli.rs/
Get source: https://github.com/pls-rs/pls/
Sponsor: https://github.com/sponsors/dhruvkb/

Usage: executable [OPTIONS] [PATHS]...

Arguments:
  [PATHS]...
          the paths to list, each of which may be a file or directory
          
          [default: .]

Options:
  -h, --help
          Print help (see a summary with '-h')

  -V, --version
          Print version

Detail view:
  -d, --det <DETAILS>
          the data points to show about each node
          
          [default: none]
          [possible values: dev, ino, nlink, typ, perm, oct, user, uid, group, gid, size, blocks,
          btime, ctime, mtime, atime, git, none, std, all]

  -H, --header <HEADER>
          show headers above columnar data
          
          [default: true]
          [possible values: true, false]

  -u, --unit <UNIT>
          the type of units to use for the node sizes
          
          [default: binary]
          [possible values: binary, decimal, none]

Grid view:
  -g, --grid <GRID>
          display node names in multiple columns
          
          [default: false]
          [possible values: true, false]

  -D, --down <DOWN>
          display node names column-first
          
          [default: false]
          [possible values: true, false]

Presentation:
  -i, --icon <ICON>
          display icons next to node names
          
          [default: true]
          [possible values: true, false]

  -S, --suffix <SUFFIX>
          display node type suffixes after the node name
          
          [default: true]
          [possible values: true, false]

  -l, --sym <SYM>
          show symlink targets
          
          [default: true]
          [possible values: true, false]

  -c, --collapse <COLLAPSE>
          show dependent nodes as children of their principal nodes
          
          [default: true]
          [possible values: true, false]

  -a, --align <ALIGN>
          align items accounting for leading dots
          
          [default: true]
          [possible values: true, false]

Filtering:
  -t, --typ <TYPES>
          the set of node types to include in the output
          
          [default: all]
          [possible values: dir, symlink, fifo, socket, block-device, char-device, file, none, all]

  -I, --imp <IMP>
          the importance cutoff to dim or hide unimportant files
          
          [default: 0]

  -e, --exclude <EXCLUDE>
          the pattern of files to selectively hide from the output

  -o, --only <ONLY>
          the pattern of files to exclusively show in the output

Sorting:
  -s, --sort <SORT_BASES>
          the set of fields to sort by, trailing `_` reverses the direction
          
          [default: cat cname]
          [possible values: dev, ino, nlink, typ, cat, user, uid, group, gid, size, blocks, btime,
          ctime, mtime, atime, name, cname, ext, inode_, nlinks_, typ_, cat_, user_, uid_, group_,
          gid_, size_, blocks_, btime_, ctime_, mtime_, atime_, name_, cname_, ext_, none]
"""

SHORT_HELP = """pls is a prettier and powerful ls(1) for the pros.

Usage: executable [OPTIONS] [PATHS]...

Arguments:
  [PATHS]...  the paths to list, each of which may be a file or directory [default: .]

Options:
  -h, --help     Print help (see more with '--help')
  -V, --version  Print version

Detail view:
  -d, --det <DETAILS>    the data points to show about each node [default: none] [possible values:
                         dev, ino, nlink, typ, perm, oct, user, uid, group, gid, size, blocks,
                         btime, ctime, mtime, atime, git, none, std, all]
  -H, --header <HEADER>  show headers above columnar data [default: true] [possible values: true,
                         false]
  -u, --unit <UNIT>      the type of units to use for the node sizes [default: binary] [possible
                         values: binary, decimal, none]

Grid view:
  -g, --grid <GRID>  display node names in multiple columns [default: false] [possible values: true,
                     false]
  -D, --down <DOWN>  display node names column-first [default: false] [possible values: true, false]

Presentation:
  -i, --icon <ICON>          display icons next to node names [default: true] [possible values:
                             true, false]
  -S, --suffix <SUFFIX>      display node type suffixes after the node name [default: true]
                             [possible values: true, false]
  -l, --sym <SYM>            show symlink targets [default: true] [possible values: true, false]
  -c, --collapse <COLLAPSE>  show dependent nodes as children of their principal nodes [default:
                             true] [possible values: true, false]
  -a, --align <ALIGN>        align items accounting for leading dots [default: true] [possible
                             values: true, false]

Filtering:
  -t, --typ <TYPES>        the set of node types to include in the output [default: all] [possible
                           values: dir, symlink, fifo, socket, block-device, char-device, file,
                           none, all]
  -I, --imp <IMP>          the importance cutoff to dim or hide unimportant files [default: 0]
  -e, --exclude <EXCLUDE>  the pattern of files to selectively hide from the output
  -o, --only <ONLY>        the pattern of files to exclusively show in the output

Sorting:
  -s, --sort <SORT_BASES>  the set of fields to sort by, trailing `_` reverses the direction
                           [default: cat cname] [possible values: dev, ino, nlink, typ, cat, user,
                           uid, group, gid, size, blocks, btime, ctime, mtime, atime, name, cname,
                           ext, inode_, nlinks_, typ_, cat_, user_, uid_, group_, gid_, size_,
                           blocks_, btime_, ctime_, mtime_, atime_, name_, cname_, ext_, none]
"""


def bool_arg(s):
    if s == "true":
        return True
    if s == "false":
        return False
    raise argparse.ArgumentTypeError(f"invalid boolean value: '{s}'")


class Parser(argparse.ArgumentParser):
    def error(self, message):
        self.print_usage(sys.stderr)
        self.exit(2, f"error: {message}\n")


def parse_args(argv):
    if "--help" in argv:
        print(LONG_HELP, end="")
        raise SystemExit(0)
    if "-h" in argv:
        print(SHORT_HELP, end="")
        raise SystemExit(0)
    p = Parser(
        prog="executable",
        description="pls is a prettier and powerful ls(1) for the pros.",
        formatter_class=argparse.RawTextHelpFormatter,
    )
    p.add_argument("-V", "--version", action="store_true")
    p.add_argument("-d", "--det", choices=DETAIL_CHOICES, action="append", default=[])
    p.add_argument("-H", "--header", type=bool_arg, default=True)
    p.add_argument("-u", "--unit", choices=["binary", "decimal", "none"], default="binary")
    p.add_argument("-g", "--grid", type=bool_arg, default=False)
    p.add_argument("-D", "--down", type=bool_arg, default=False)
    p.add_argument("-i", "--icon", type=bool_arg, default=True)
    p.add_argument("-S", "--suffix", type=bool_arg, default=True)
    p.add_argument("-l", "--sym", type=bool_arg, default=True)
    p.add_argument("-c", "--collapse", type=bool_arg, default=True)
    p.add_argument("-a", "--align", type=bool_arg, default=True)
    p.add_argument("-t", "--typ", choices=TYPE_CHOICES, action="append", default=[])
    p.add_argument("-I", "--imp", default="0")
    p.add_argument("-e", "--exclude", action="append", default=[])
    p.add_argument("-o", "--only", action="append", default=[])
    p.add_argument("-s", "--sort", choices=SORT_CHOICES, action="append", default=[])
    p.add_argument("paths", nargs="*", default=["."])
    return p.parse_args(argv)


def mode_type(m):
    if stat.S_ISDIR(m):
        return "dir", "d"
    if stat.S_ISLNK(m):
        return "symlink", "l"
    if stat.S_ISFIFO(m):
        return "fifo", "p"
    if stat.S_ISSOCK(m):
        return "socket", "s"
    if stat.S_ISBLK(m):
        return "block-device", "b"
    if stat.S_ISCHR(m):
        return "char-device", "c"
    return "file", "f"


def clean_name(name):
    return name[1:] if name.startswith(".") else name


def ext_name(name):
    base = clean_name(name)
    if "." not in base or base.endswith("."):
        return ""
    return base.rsplit(".", 1)[1].lower()


class Node:
    def __init__(self, path, display=None):
        self.path = path
        self.name = display if display is not None else os.path.basename(path.rstrip("/")) or path
        self.err = None
        try:
            self.st = os.lstat(path)
            self.kind, self.kind_letter = mode_type(self.st.st_mode)
        except OSError as e:
            self.err = e
            self.st = None
            self.kind = "missing"
            self.kind_letter = "?"


def user_name(uid):
    try:
        return pwd.getpwuid(uid).pw_name
    except KeyError:
        return str(uid)


def group_name(gid):
    try:
        return grp.getgrgid(gid).gr_name
    except KeyError:
        return str(gid)


def perm_string(mode):
    chars = []
    for shift in (6, 3, 0):
        bits = (mode >> shift) & 7
        chars.append(("r" if bits & 4 else "-") + ("w" if bits & 2 else "-") + ("x" if bits & 1 else "-"))
    return " ".join(chars)


def time_string(ts):
    s = datetime.fromtimestamp(ts).strftime("%Y-%b-%d %I:%M%p")
    return s[:-2] + s[-2:].lower()


def size_string(n, unit):
    if unit == "none":
        return str(n)
    base = 1000 if unit == "decimal" else 1024
    labels = ["B", "KB", "MB", "GB", "TB"] if unit == "decimal" else ["B", "KiB", "MiB", "GiB", "TiB"]
    val = float(n)
    idx = 0
    while abs(val) >= base and idx + 1 < len(labels):
        val /= base
        idx += 1
    if idx == 0:
        return f"{val:.1f} {labels[idx]:>3}"
    return f"{val:.1f} {labels[idx]}"


def icon_for(node):
    if node.kind == "dir":
        return "\uf07b"
    if node.kind == "symlink":
        return "\U000f0339"
    if node.kind == "fifo":
        return "\U000f0a5f"
    if node.kind == "socket":
        return "\U000f07d0"
    if node.name.lower().endswith(".txt"):
        return "\ue612"
    return " "


def suffix_for(node):
    if node.kind == "dir":
        return "/"
    if node.kind == "symlink":
        return "@"
    if node.kind == "fifo":
        return "|"
    if node.kind == "socket":
        return "="
    if node.kind == "file" and (node.st.st_mode & stat.S_IXUSR):
        return "*"
    return ""


def display_name(node, args, include_icon=True):
    prefix = ""
    if include_icon and args.icon:
        prefix = icon_for(node) + " "
    align = " " if args.align and not node.name.startswith(".") else ""
    text = prefix + align + node.name
    if args.suffix:
        text += suffix_for(node)
    if args.sym and node.kind == "symlink":
        try:
            text += f" {ARROW} {os.readlink(node.path)}"
        except OSError:
            pass
    return text


def expand_details(items):
    if not items:
        return []
    out = []
    for item in items:
        if item == "none":
            out = []
        elif item == "std":
            out.extend(["nlink", "typ", "perm", "user", "group", "size", "mtime"])
        elif item == "all":
            out.extend(["dev", "ino", "nlink", "typ", "perm", "oct", "user", "uid", "group", "gid",
                        "size", "blocks", "btime", "ctime", "mtime", "atime", "git"])
        else:
            out.append(item)
    seen = []
    for item in out:
        if item not in seen:
            seen.append(item)
    return seen


HEADERS = {
    "dev": "Device", "ino": "inode", "nlink": "Link#", "typ": "T", "perm": "Permissions",
    "oct": "SUGO", "user": "User", "uid": "UID", "group": "Group", "gid": "GID",
    "size": "Size", "blocks": "Blocks", "btime": "Created", "ctime": "Changed",
    "mtime": "Modified", "atime": "Accessed", "git": "Git",
}


def detail_value(node, field, args):
    st = node.st
    if field == "dev":
        return str(st.st_dev)
    if field == "ino":
        return str(st.st_ino)
    if field == "nlink":
        return str(st.st_nlink)
    if field == "typ":
        return node.kind_letter
    if field == "perm":
        return perm_string(st.st_mode)
    if field == "oct":
        return f"{stat.S_IMODE(st.st_mode):o}"
    if field == "user":
        return user_name(st.st_uid)
    if field == "uid":
        return str(st.st_uid)
    if field == "group":
        return group_name(st.st_gid)
    if field == "gid":
        return str(st.st_gid)
    if field == "size":
        if node.kind == "dir":
            return ""
        return size_string(st.st_size, args.unit)
    if field == "blocks":
        return str(getattr(st, "st_blocks", 0))
    if field == "btime":
        return time_string(getattr(st, "st_birthtime", st.st_ctime))
    if field == "ctime":
        return time_string(st.st_ctime)
    if field == "mtime":
        return time_string(st.st_mtime)
    if field == "atime":
        return time_string(st.st_atime)
    if field == "git":
        return ""
    return ""


def sort_key(node, field):
    rev = field.endswith("_")
    base = field[:-1] if rev else field
    if base == "inode":
        base = "ino"
    if base == "nlinks":
        base = "nlink"
    st = node.st
    if base == "cat":
        order = {"dir": 0, "file": 1, "fifo": 1, "symlink": 1, "socket": 1}
        val = order.get(node.kind, 2)
    elif base == "name":
        val = node.name.lower()
    elif base == "cname":
        val = clean_name(node.name).lower()
    elif base == "ext":
        val = (ext_name(node.name), clean_name(node.name).lower())
    elif base == "typ":
        val = node.kind_letter
    elif base == "user":
        val = user_name(st.st_uid)
    elif base == "group":
        val = group_name(st.st_gid)
    elif base == "dev":
        val = st.st_dev
    elif base == "ino":
        val = st.st_ino
    elif base == "nlink":
        val = st.st_nlink
    elif base == "uid":
        val = st.st_uid
    elif base == "gid":
        val = st.st_gid
    elif base == "size":
        val = st.st_size
    elif base == "blocks":
        val = getattr(st, "st_blocks", 0)
    elif base == "ctime":
        val = st.st_ctime
    elif base == "mtime":
        val = st.st_mtime
    elif base == "atime":
        val = st.st_atime
    elif base == "btime":
        val = getattr(st, "st_birthtime", st.st_ctime)
    else:
        val = 0
    return val, rev


def sort_nodes(nodes, sorts):
    if not sorts:
        sorts = ["cat", "cname"]
    if sorts == ["none"] or "none" in sorts:
        return nodes
    result = list(nodes)
    for field in reversed(sorts):
        _, rev = sort_key(result[0], field) if result else (None, False)
        result.sort(key=lambda n, f=field: sort_key(n, f)[0], reverse=rev)
    return result


def filter_nodes(nodes, args):
    types = args.typ or ["all"]
    out = []
    for n in nodes:
        if "none" in types:
            continue
        if "all" not in types and n.kind not in types:
            continue
        if args.exclude and any(fnmatch.fnmatch(n.name, pat) for pat in args.exclude):
            continue
        if args.only and not any(fnmatch.fnmatch(n.name, pat) for pat in args.only):
            continue
        out.append(n)
    return out


def print_detail(nodes, details, args):
    rows = []
    for n in nodes:
        vals = [detail_value(n, f, args) for f in details]
        rows.append(vals + [display_name(n, args, include_icon=args.icon)])
    widths = []
    columns = details + ["name"]
    for idx, col in enumerate(columns):
        candidates = [r[idx] for r in rows]
        if idx < len(details) and args.header:
            candidates.append(HEADERS[details[idx]])
        widths.append(max([len(x) for x in candidates] or [0]))
    right = {"dev", "ino", "nlink", "oct", "uid", "gid", "size", "blocks"}
    if args.header:
        parts = []
        for idx, f in enumerate(details):
            h = HEADERS[f]
            parts.append(h.rjust(widths[idx]) if f in right else h.ljust(widths[idx]))
        parts.append("Name")
        print(" ".join(parts))
    for row in rows:
        parts = []
        for idx, f in enumerate(details):
            v = row[idx]
            parts.append(v.rjust(widths[idx]) if f in right else v.ljust(widths[idx]))
        parts.append(row[-1])
        print(" ".join(parts).rstrip())


def list_path(path, args):
    node = Node(path)
    if node.err:
        print(f"{path}:", flush=True)
        print(f"\terror: {node.err.strerror} (os error {node.err.errno})", file=sys.stderr)
        return 1
    if node.kind == "dir":
        try:
            entries = [Node(os.path.join(path, name), name) for name in os.listdir(path)]
        except OSError as e:
            print(f"{path}:", flush=True)
            print(f"\terror: {e.strerror} (os error {e.errno})", file=sys.stderr)
            return 1
        nodes = [n for n in entries if not n.err]
    else:
        nodes = [node]
    nodes = filter_nodes(nodes, args)
    nodes = sort_nodes(nodes, args.sort)
    details = expand_details(args.det)
    if details:
        print_detail(nodes, details, args)
    else:
        for n in nodes:
            print(display_name(n, args, include_icon=(args.icon and not args.grid)))
    return 0


def main(argv):
    args = parse_args(argv)
    if args.version:
        print("pls 0.0.1-beta.9")
        return 0
    code = 0
    multi = len(args.paths) > 1
    for idx, path in enumerate(args.paths):
        if idx:
            print()
        node = Node(path)
        if node.err or (node.kind == "dir" and (multi or path not in (".", "./"))):
            print(f"{path}:", flush=True)
        if node.err:
            print(f"\terror: {node.err.strerror} (os error {node.err.errno})", file=sys.stderr)
            code = 1
            continue
        code = max(code, list_path(path, args))
    return code


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
