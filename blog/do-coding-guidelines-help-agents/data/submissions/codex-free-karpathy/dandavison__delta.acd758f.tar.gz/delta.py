#!/usr/bin/env python3
import difflib
import os
import re
import sys
from pathlib import Path

VERSION = "delta 0.18.2"
BLUE = "\033[34m"
RED_BG = "\033[48;5;52m"
GREEN_BG = "\033[48;5;22m"
WHITE = "\033[38;5;231m"
DIM = "\033[38;5;238m"
RED_NUM = "\033[38;5;88m"
GREEN_NUM = "\033[38;5;28m"
GREEN = "\033[32m"
RESET = "\033[0m"
CLEAR_EOL = "\033[0K"

VALUE_OPTS = {
    "--blame-code-style", "--blame-format", "--blame-palette", "--blame-separator-format",
    "--blame-separator-style", "--blame-timestamp-format", "--blame-timestamp-output-format",
    "--config", "--commit-decoration-style", "--commit-regex", "--commit-style",
    "--default-language", "--detect-dark-light", "--diff-args", "-@", "--diff-stat-align-width",
    "--features", "--file-added-label", "--file-copied-label", "--file-decoration-style",
    "--file-modified-label", "--file-removed-label", "--file-renamed-label", "--file-style",
    "--file-transformation", "--generate-completion", "--grep-context-line-style", "--grep-file-style",
    "--grep-header-decoration-style", "--grep-header-file-style", "--grep-line-number-style",
    "--grep-output-type", "--grep-match-line-style", "--grep-match-word-style", "--grep-separator-symbol",
    "--hunk-header-decoration-style", "--hunk-header-file-style", "--hunk-header-line-number-style",
    "--hunk-header-style", "--hunk-label", "--hyperlinks-commit-link-format", "--hyperlinks-file-link-format",
    "--inline-hint-style", "--inspect-raw-lines", "--line-buffer-size", "--line-fill-method",
    "--line-numbers-left-format", "--line-numbers-left-style", "--line-numbers-minus-style",
    "--line-numbers-plus-style", "--line-numbers-right-format", "--line-numbers-right-style",
    "--line-numbers-zero-style", "--map-styles", "--max-line-distance", "--max-syntax-highlighting-length",
    "--max-line-length", "--merge-conflict-begin-symbol", "--merge-conflict-end-symbol",
    "--merge-conflict-ours-diff-header-decoration-style", "--merge-conflict-ours-diff-header-style",
    "--merge-conflict-theirs-diff-header-decoration-style", "--merge-conflict-theirs-diff-header-style",
    "--minus-emph-style", "--minus-empty-line-marker-style", "--minus-non-emph-style", "--minus-style",
    "--navigate-regex", "--pager", "--paging", "--plus-emph-style", "--plus-empty-line-marker-style",
    "--plus-non-emph-style", "--plus-style", "--relative-paths", "--right-arrow", "--side-by-side",
    "--syntax-theme", "--tabs", "--theme", "--true-color", "--width", "-w", "--word-diff-regex",
    "--wrap-left-symbol", "--wrap-max-lines", "--wrap-right-percent", "--wrap-right-prefix-symbol",
    "--wrap-right-symbol", "--zero-style", "--24-bit-color",
}
BOOL_OPTS = {
    "--color-only", "--dark", "--diff-highlight", "--diff-so-fancy", "--hyperlinks",
    "--keep-plus-minus-markers", "--light", "--line-numbers", "-n", "--list-languages",
    "--list-syntax-themes", "--navigate", "--no-gitconfig", "--no-symlinks", "--raw",
    "--show-colors", "--show-config", "--show-syntax-themes", "--show-themes", "--side-by-side",
}
THEMES = [
    ("dark", "1337"), ("dark", "Coldark-Cold"), ("dark", "Coldark-Dark"), ("dark", "DarkNeon"),
    ("dark", "Dracula"), ("dark", "Monokai Extended"), ("dark", "Monokai Extended Bright"),
    ("dark", "Monokai Extended Origin"), ("dark", "Nord"), ("dark", "OneHalfDark"),
    ("dark", "Solarized (dark)"), ("dark", "Sublime Snazzy"), ("dark", "TwoDark"),
    ("dark", "Visual Studio Dark+"), ("dark", "ansi"), ("dark", "base16"), ("dark", "base16-256"),
    ("dark", "gruvbox-dark"), ("dark", "zenburn"), ("light", "GitHub"),
    ("light", "Monokai Extended Light"), ("light", "OneHalfLight"), ("light", "Solarized (light)"),
    ("light", "gruvbox-light"),
]
LANGS = [
    ("ActionScript", ["as"]), ("Ada", ["adb", "ads", "gpr"]),
    ("Apache Conf", ["envvars", "htaccess", "HTACCESS", "htgroups", "HTGROUPS", "htpasswd"]),
    ("AppleScript", ["applescript", "script editor"]), ("ARM Assembly", ["s", "S"]),
    ("AsciiDoc (Asciidoctor)", ["adoc", "ad", "asciidoc"]), ("ASP", ["asa"]),
    ("Assembly (x86_64)", ["yasm", "nasm", "asm", "inc", "mac"]),
    ("Authorized Keys", ["authorized_keys", "pub", "authorized_keys2"]), ("AWK", ["awk"]),
    ("Batch File", ["bat", "cmd"]), ("BibTeX", ["bib"]),
    ("Bourne Again Shell (bash)", ["sh", "bash", "zsh", "ash", ".bashrc", ".profile", "PKGBUILD"]),
    ("C", ["c", "h"]), ("C#", ["cs", "csx"]),
    ("C++", ["cpp", "cc", "cp", "cxx", "c++", "C", "h", "hh", "hpp", "hxx"]),
    ("Cabal", ["cabal"]), ("Clojure", ["clj", "cljc", "cljs", "edn"]),
    ("CMake", ["CMakeLists.txt", "cmake"]), ("CoffeeScript", ["coffee", "Cakefile", "cson"]),
    ("Comma Separated Values", ["csv", "tsv"]), ("Command Help", ["cmd-help", "help"]),
    ("Diff", ["diff", "patch"]), ("Go", ["go"]), ("HTML", ["html", "htm"]),
    ("Java", ["java"]), ("JavaScript", ["js", "jsx", "mjs"]), ("JSON", ["json"]),
    ("Markdown", ["md", "markdown"]), ("Python", ["py", "pyw"]), ("Rust", ["rs"]),
    ("TypeScript", ["ts", "tsx"]), ("YAML", ["yaml", "yml"]),
]


def color(s, c):
    return f"{c}{s}{RESET}"


def load_help(long=True):
    p = Path(__file__).with_name("full---help-output.md")
    try:
        txt = p.read_text()
        m = re.search(r"```txt\n(.*?)\n```", txt, re.S)
        if m:
            return m.group(1) + "\n"
    except OSError:
        pass
    return "A viewer for git and diff output\n\nUsage: delta [OPTIONS] [MINUS_FILE] [PLUS_FILE]\n\nOptions:\n  -h, --help     Print help\n  -V, --version  Print version\n"


def show_completion(shell):
    p = Path(__file__).with_name("completion") / f"completion.{ {'bash':'bash','fish':'fish','zsh':'zsh'}.get(shell, shell) }"
    if p.exists():
        sys.stdout.write(p.read_text())
    else:
        print(f"# completion for delta ({shell})")


def list_languages():
    for name, exts in LANGS:
        items = ", ".join(color(e, GREEN) for e in exts)
        print(f"{name:<25} {items}")


def list_themes():
    for kind, name in THEMES:
        print(f"{kind}\t{name}")


def show_colors():
    names = ["Blue", "Green", "Red", "Magenta", "Cyan", "Yellow"]
    for n in names:
        print("\n" + f"\033[1m{n}\033[0m\n")
        print(f"export function color(): string {{ return \"{n.lower()}\" }}")
        print(f"{GREEN_BG}export function hex(): string {{ return \"#000000\" }}{RESET}")


def parse_args(argv):
    opts = {"color_only": False, "line_numbers": False, "raw": False, "width": 80}
    files = []
    i = 0
    while i < len(argv):
        a = argv[i]
        if a == "--":
            files.extend(argv[i+1:]); break
        if a in ("--help", "-h"):
            sys.stdout.write(load_help(a == "--help")); sys.exit(0)
        if a in ("--version", "-V"):
            print(VERSION); sys.exit(0)
        if a == "--generate-completion":
            val = argv[i+1] if i + 1 < len(argv) else "bash"; show_completion(val); sys.exit(0)
        if a.startswith("--generate-completion="):
            show_completion(a.split("=",1)[1]); sys.exit(0)
        if a == "--list-languages":
            list_languages(); sys.exit(0)
        if a in ("--list-syntax-themes",):
            list_themes(); sys.exit(0)
        if a in ("--show-syntax-themes", "--show-themes"):
            list_themes(); sys.exit(0)
        if a == "--show-colors":
            show_colors(); sys.exit(0)
        if a == "--show-config":
            print("delta features =")
            print("delta.syntax-theme = Monokai Extended")
            sys.exit(0)
        if a in ("--color-only",): opts["color_only"] = True; i += 1; continue
        if a in ("--line-numbers", "-n"): opts["line_numbers"] = True; i += 1; continue
        if a == "--raw": opts["raw"] = True; i += 1; continue
        if a.startswith("--width="):
            try: opts["width"] = int(a.split("=",1)[1])
            except ValueError: pass
            i += 1; continue
        if a in VALUE_OPTS:
            i += 2; continue
        if any(a.startswith(o + "=") for o in VALUE_OPTS if o.startswith("--")):
            i += 1; continue
        if a in BOOL_OPTS:
            i += 1; continue
        if a.startswith("-"):
            sys.stderr.write(f"error: unexpected argument '{a}' found\n\nUsage: executable [OPTIONS] [MINUS_FILE] [PLUS_FILE]\n")
            sys.exit(2)
        files.append(a); i += 1
    return opts, files


def unified_for_files(a, b):
    try:
        with open(a, encoding="utf-8", errors="replace") as f: left = f.readlines()
        with open(b, encoding="utf-8", errors="replace") as f: right = f.readlines()
    except OSError as e:
        sys.stderr.write(f"delta: {e}\n"); sys.exit(1)
    return list(difflib.unified_diff(left, right, fromfile=a, tofile=b, lineterm=""))


def parse_hunk_nums(line):
    m = re.match(r"@@ -(\d+)(?:,(\d+))? \+(\d+)(?:,(\d+))? @@", line)
    if not m: return None
    return int(m.group(1)), int(m.group(3))


def render_diff(lines, opts):
    if opts["raw"]:
        sys.stdout.write("".join(lines)); return
    minus_file = plus_file = None
    old_no = new_no = None
    in_diff = False
    for raw in lines:
        line = raw.rstrip("\n")
        if opts["color_only"]:
            render_color_only(line); continue
        if line.startswith("diff --git "):
            in_diff = True
            continue
        if line.startswith("--- "):
            minus_file = line[4:].strip()
            continue
        if line.startswith("+++ "):
            plus_file = line[4:].strip()
            if minus_file and plus_file:
                show_file_header(minus_file, plus_file, opts.get("width",80))
            continue
        if line.startswith("index ") or line.startswith("new file mode") or line.startswith("deleted file mode"):
            continue
        if line.startswith("@@ "):
            nums = parse_hunk_nums(line)
            if nums: old_no, new_no = nums
            show_hunk_header(line)
            continue
        if old_no is None or new_no is None:
            print(line)
            continue
        if line.startswith("-") and not line.startswith("---"):
            text = line[1:]
            prefix = ln_prefix(old_no, None, opts) if opts["line_numbers"] else ""
            print(prefix + RED_BG + text + RESET + RED_BG + CLEAR_EOL + RESET)
            old_no += 1
        elif line.startswith("+") and not line.startswith("+++"): 
            text = line[1:]
            prefix = ln_prefix(None, new_no, opts) if opts["line_numbers"] else ""
            print(prefix + GREEN_BG + WHITE + text + RESET + GREEN_BG + CLEAR_EOL + RESET)
            new_no += 1
        elif line.startswith(" "):
            text = line[1:]
            prefix = ln_prefix(old_no, new_no, opts) if opts["line_numbers"] else ""
            print(prefix + WHITE + text + RESET)
            old_no += 1; new_no += 1
        elif line == r"\ No newline at end of file":
            print(line)
        else:
            print(line)


def render_color_only(line):
    if line.startswith("-") and not line.startswith("---"):
        print(RED_BG + line + RESET + RED_BG + CLEAR_EOL + RESET)
    elif line.startswith("+") and not line.startswith("+++"):
        print(GREEN_BG + line[0] + WHITE + line[1:] + RESET + GREEN_BG + CLEAR_EOL + RESET)
    elif line.startswith(" "):
        print(" " + WHITE + line[1:] + RESET)
    else:
        print(line)


def show_file_header(a, b, width):
    a = a[2:] if a.startswith("a/") else a
    b = b[2:] if b.startswith("b/") else b
    title = a if a == b else f"{a} ⟶   {b}"
    print()
    print(BLUE + title + RESET)
    print(BLUE + "─" * max(10, width) + RESET)
    print()


def show_hunk_header(line):
    nums = parse_hunk_nums(line)
    n = nums[1] if nums else 1
    print(BLUE + "───" + RESET + BLUE + "┐" + RESET)
    print(BLUE + str(n) + RESET + ": " + BLUE + "│" + RESET)
    print(BLUE + "───" + RESET + BLUE + "┘" + RESET)


def ln_prefix(old_no, new_no, opts):
    left = f"{old_no:4d}" if old_no is not None else "    "
    right = f"{new_no:4d}" if new_no is not None else "    "
    c1 = RED_NUM if old_no is not None and new_no is None else DIM
    c2 = GREEN_NUM if new_no is not None and old_no is None else DIM
    return BLUE + c1 + left + " " + BLUE + "⋮" + c2 + right + " " + BLUE + "│" + RESET


def main():
    opts, files = parse_args(sys.argv[1:])
    if len(files) >= 2:
        lines = unified_for_files(files[0], files[1])
    elif len(files) == 1:
        try:
            with open(files[0], encoding="utf-8", errors="replace") as f: lines = f.readlines()
        except OSError as e:
            sys.stderr.write(f"delta: {e}\n"); sys.exit(1)
    else:
        lines = sys.stdin.readlines()
    render_diff(lines, opts)

if __name__ == "__main__":
    main()
