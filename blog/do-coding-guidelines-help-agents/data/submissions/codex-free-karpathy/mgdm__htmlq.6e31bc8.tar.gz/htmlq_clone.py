#!/usr/bin/env python3
import argparse
import html
import re
import sys
from html.parser import HTMLParser
from urllib.parse import urljoin


VOID_TAGS = {
    "area", "base", "br", "col", "embed", "hr", "img", "input", "link",
    "meta", "param", "source", "track", "wbr",
}


class Node:
    def __init__(self, kind, name="", attrs=None, data=""):
        self.kind = kind
        self.name = name.lower() if name else ""
        self.attrs = dict(attrs or [])
        self.data = data
        self.children = []
        self.parent = None

    def append(self, node):
        node.parent = self
        self.children.append(node)


class Parser(HTMLParser):
    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.root = Node("root")
        self.stack = [self.root]

    def handle_starttag(self, tag, attrs):
        node = Node("element", tag, [(k.lower(), "" if v is None else v) for k, v in attrs])
        self.stack[-1].append(node)
        if node.name not in VOID_TAGS:
            self.stack.append(node)

    def handle_startendtag(self, tag, attrs):
        self.handle_starttag(tag, attrs)
        if tag.lower() not in VOID_TAGS:
            self.handle_endtag(tag)

    def handle_endtag(self, tag):
        tag = tag.lower()
        for i in range(len(self.stack) - 1, 0, -1):
            if self.stack[i].name == tag:
                del self.stack[i:]
                return

    def handle_data(self, data):
        if data:
            self.stack[-1].append(Node("text", data=data))


def elements(root):
    out = []
    def walk(n):
        for c in n.children:
            if c.kind == "element":
                out.append(c)
                walk(c)
    walk(root)
    return out


def serialize(node, pretty=False, depth=0):
    if node.kind == "text":
        return html.escape(node.data, quote=False)
    if node.kind == "root":
        return "".join(serialize(c, pretty, depth) for c in node.children)
    attrs = "".join(f' {k}="{html.escape(v, quote=True)}"' for k, v in sorted(node.attrs.items()))
    start = f"<{node.name}{attrs}>"
    if node.name in VOID_TAGS:
        return ("  " * depth + start) if pretty else start
    if not pretty:
        return start + "".join(serialize(c, False, depth) for c in node.children) + f"</{node.name}>"
    if not node.children:
        return "  " * depth + start + f"</{node.name}>"
    parts = ["  " * depth + start]
    for c in node.children:
        s = serialize(c, True, depth + 1)
        if c.kind == "text":
            if s.strip():
                parts.append("  " * (depth + 1) + s)
        else:
            parts.append(s)
    parts.append("  " * depth + f"</{node.name}>")
    return "\n".join(parts)


def text_content(node, ignore_ws=False):
    vals = []
    def walk(n):
        if n.kind == "text":
            if not ignore_ws or n.data.strip():
                vals.append(n.data)
        else:
            for c in n.children:
                walk(c)
    walk(node)
    return vals


def split_groups(s):
    groups, cur, depth, quote = [], "", 0, None
    for ch in s:
        if quote:
            cur += ch
            if ch == quote:
                quote = None
        elif ch in "'\"":
            quote = ch; cur += ch
        elif ch in "[(":
            depth += 1; cur += ch
        elif ch in "])":
            depth -= 1; cur += ch
        elif ch == "," and depth == 0:
            if cur.strip():
                groups.append(cur.strip())
            cur = ""
        else:
            cur += ch
    if cur.strip():
        groups.append(cur.strip())
    return groups


def tokenize_selector(s):
    toks, cur, depth, quote, comb = [], "", 0, None, " "
    i = 0
    while i < len(s):
        ch = s[i]
        if quote:
            cur += ch
            if ch == quote:
                quote = None
        elif ch in "'\"":
            quote = ch; cur += ch
        elif ch in "[(":
            depth += 1; cur += ch
        elif ch in "])":
            depth -= 1; cur += ch
        elif depth == 0 and ch in ">+~":
            if cur.strip():
                toks.append((comb, cur.strip()))
            comb, cur = ch, ""
            while i + 1 < len(s) and s[i + 1].isspace():
                i += 1
        elif depth == 0 and ch.isspace():
            if cur.strip():
                toks.append((comb, cur.strip()))
                cur = ""
                comb = " "
            while i + 1 < len(s) and s[i + 1].isspace():
                i += 1
        else:
            cur += ch
        i += 1
    if cur.strip():
        toks.append((comb, cur.strip()))
    return toks


def parse_simple(s):
    d = {"tag": None, "id": None, "classes": [], "attrs": [], "pseudos": [], "not": None}
    m = re.match(r"^([a-zA-Z][\w-]*|\*)", s)
    pos = 0
    if m:
        d["tag"] = None if m.group(1) == "*" else m.group(1).lower()
        pos = m.end()
    while pos < len(s):
        ch = s[pos]
        if ch == "#":
            m = re.match(r"#([\w-]+)", s[pos:]); d["id"] = m.group(1); pos += m.end()
        elif ch == ".":
            m = re.match(r"\.([\w-]+)", s[pos:]); d["classes"].append(m.group(1)); pos += m.end()
        elif ch == "[":
            end = s.find("]", pos)
            body = s[pos + 1:end].strip()
            m = re.match(r"^([\w:-]+)\s*([~|^$*]?=)?\s*(.*)$", body)
            name, op, val = m.group(1).lower(), m.group(2), m.group(3).strip()
            if (val.startswith('"') and val.endswith('"')) or (val.startswith("'") and val.endswith("'")):
                val = val[1:-1]
            d["attrs"].append((name, op, val))
            pos = end + 1
        elif ch == ":":
            m = re.match(r":([\w-]+)(?:\(([^()]*(?:\([^)]*\)[^()]*)?)\))?", s[pos:])
            name, arg = m.group(1), m.group(2)
            if name == "not" and arg:
                d["not"] = parse_simple(arg.strip())
            else:
                d["pseudos"].append((name, arg))
            pos += m.end()
        else:
            pos += 1
    return d


def element_index(n):
    if not n.parent:
        return 1
    kids = [c for c in n.parent.children if c.kind == "element"]
    return kids.index(n) + 1


def match_nth(idx, arg):
    arg = (arg or "").strip().lower().replace(" ", "")
    if arg == "odd":
        return idx % 2 == 1
    if arg == "even":
        return idx % 2 == 0
    if re.fullmatch(r"\d+", arg):
        return idx == int(arg)
    m = re.fullmatch(r"([+-]?\d*)n([+-]\d+)?", arg)
    if not m:
        return False
    a = m.group(1)
    a = 1 if a in ("", "+") else -1 if a == "-" else int(a)
    b = int(m.group(2) or 0)
    return (idx - b) * a >= 0 and (idx - b) % a == 0


def matches_simple(n, d):
    if n.kind != "element":
        return False
    if d["tag"] and n.name != d["tag"]:
        return False
    if d["id"] and n.attrs.get("id") != d["id"]:
        return False
    classes = n.attrs.get("class", "").split()
    if any(c not in classes for c in d["classes"]):
        return False
    for name, op, val in d["attrs"]:
        if name not in n.attrs:
            return False
        got = n.attrs[name]
        if op == "=" and got != val:
            return False
        if op == "~=" and val not in got.split():
            return False
        if op == "^=" and not got.startswith(val):
            return False
        if op == "$=" and not got.endswith(val):
            return False
        if op == "*=" and val not in got:
            return False
        if op == "|=" and not (got == val or got.startswith(val + "-")):
            return False
    if d["not"] and matches_simple(n, d["not"]):
        return False
    for name, arg in d["pseudos"]:
        idx = element_index(n)
        sibs = [c for c in n.parent.children if c.kind == "element"] if n.parent else [n]
        if name == "first-child" and idx != 1:
            return False
        if name == "last-child" and idx != len(sibs):
            return False
        if name == "nth-child" and not match_nth(idx, arg):
            return False
    return True


def related(n, comb):
    if comb == " ":
        p = n.parent
        while p and p.kind != "root":
            yield p
            p = p.parent
    elif comb == ">":
        if n.parent and n.parent.kind == "element":
            yield n.parent
    elif comb in "+~":
        if not n.parent:
            return
        sibs = [c for c in n.parent.children if c.kind == "element"]
        idx = sibs.index(n)
        rng = [sibs[idx - 1]] if comb == "+" and idx > 0 else sibs[:idx]
        for x in reversed(rng):
            yield x


def matches_chain(n, chain):
    if not matches_simple(n, chain[-1][1]):
        return False
    candidates = [n]
    for comb, simple in reversed(chain[:-1]):
        new = []
        for c in candidates:
            for r in related(c, chain[chain.index((comb, simple)) + 1][0] if False else comb):
                if matches_simple(r, simple):
                    new.append(r)
        if not new:
            return False
        candidates = new
    return True


def select(root, selector):
    found = []
    for group in split_groups(selector):
        raw = tokenize_selector(group)
        if not raw:
            continue
        chain = [(comb, parse_simple(simple)) for comb, simple in raw]
        # Store the relationship from each simple selector to the selector on its left.
        rev = list(reversed(chain))
        for n in elements(root):
            if not matches_simple(n, chain[-1][1]):
                continue
            cur = [n]
            ok = True
            for i in range(len(chain) - 2, -1, -1):
                comb_to_right = chain[i + 1][0]
                nxt = []
                for c in cur:
                    for r in related(c, comb_to_right):
                        if matches_simple(r, chain[i][1]):
                            nxt.append(r)
                if not nxt:
                    ok = False
                    break
                cur = nxt
            if ok and n not in found:
                found.append(n)
    return found


def detect_base(root):
    for n in elements(root):
        if n.name == "base" and n.attrs.get("href"):
            return n.attrs["href"]
    return None


def main():
    p = argparse.ArgumentParser(prog="executable", add_help=False)
    p.add_argument("-h", "--help", action="store_true")
    p.add_argument("-V", "--version", action="store_true")
    p.add_argument("-t", "--text", action="store_true")
    p.add_argument("-p", "--pretty", action="store_true")
    p.add_argument("-w", "--ignore-whitespace", action="store_true")
    p.add_argument("-B", "--detect-base", action="store_true")
    p.add_argument("-a", "--attribute")
    p.add_argument("-b", "--base")
    p.add_argument("-f", "--filename")
    p.add_argument("-o", "--output")
    p.add_argument("-r", "--remove-nodes", action="append", default=[])
    p.add_argument("selector", nargs="*")
    args = p.parse_args()
    if args.help:
        print("""htmlq 0.4.0
Michael Maclean <michael@mgdm.net>
Runs CSS selectors on HTML

USAGE:
    executable [FLAGS] [OPTIONS] [--] [selector]...

FLAGS:
    -B, --detect-base          Try to detect the base URL from the <base> tag in the document. If not found, default to
                               the value of --base, if supplied
    -h, --help                 Prints help information
    -w, --ignore-whitespace    When printing text nodes, ignore those that consist entirely of whitespace
    -p, --pretty               Pretty-print the serialised output
    -t, --text                 Output only the contents of text nodes inside selected elements
    -V, --version              Prints version information

OPTIONS:
    -a, --attribute <attribute>         Only return this attribute (if present) from selected elements
    -b, --base <base>                   Use this URL as the base for links
    -f, --filename <FILE>               The input file. Defaults to stdin
    -o, --output <FILE>                 The output file. Defaults to stdout
    -r, --remove-nodes <SELECTOR>...    Remove nodes matching this expression before output. May be specified multiple
                                        times

ARGS:
    <selector>...    The CSS expression to select [default: html]""")
        return 0
    if args.version:
        print("htmlq 0.4.0")
        return 0
    data = open(args.filename, encoding="utf-8").read() if args.filename else sys.stdin.read()
    parser = Parser()
    parser.feed(data)
    root = parser.root
    for rs in args.remove_nodes:
        for n in list(select(root, rs)):
            if n.parent and n in n.parent.children:
                n.parent.children.remove(n)
    selector = " ".join(args.selector) if args.selector else "html"
    selected = select(root, selector)
    base = detect_base(root) if args.detect_base else None
    if base is None:
        base = args.base
    out = []
    for n in selected:
        if args.attribute:
            if args.attribute in n.attrs:
                val = n.attrs[args.attribute]
                if base and args.attribute.lower() in ("href", "src"):
                    val = urljoin(base, val)
                out.append(val + "\n")
        elif args.text:
            vals = text_content(n, args.ignore_whitespace)
            if args.ignore_whitespace:
                out.append("".join(v + "\n" for v in vals) + "\n")
            else:
                out.append("".join(vals) + "\n")
        else:
            out.append(serialize(n, args.pretty) + "\n")
    result = "".join(out)
    if args.output:
        with open(args.output, "w", encoding="utf-8") as f:
            f.write(result)
    else:
        sys.stdout.write(result)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
