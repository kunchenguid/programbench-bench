#define _GNU_SOURCE
#include <ctype.h>
#include <dirent.h>
#include <errno.h>
#include <limits.h>
#include <signal.h>
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <termios.h>
#include <unistd.h>

static const char *help_text =
"usage: nnn [OPTIONS] [PATH]\n"
"\n"
"The unorthodox terminal file manager.\n"
"\n"
"positional args:\n"
"  PATH   start dir/file [default: .]\n"
"\n"
"optional args:\n"
" -a      auto NNN_FIFO\n"
" -A      no dir auto-enter during filter\n"
" -b key  open bookmark key (trumps -s/S)\n"
" -B      use bsdtar for archives\n"
" -c      cli-only NNN_OPENER (trumps -e)\n"
" -C      8-color scheme\n"
" -d      detail mode\n"
" -D      dirs in context color\n"
" -e      text in $VISUAL/$EDITOR/vi\n"
" -E      internal edits in EDITOR\n"
" -f      use history file\n"
" -F val  fifo mode [0:preview 1:explore]\n"
" -g      regex filters\n"
" -H      show hidden files\n"
" -i      show current file info\n"
" -J      no auto-advance on selection\n"
" -K      detect key collision and exit\n"
" -l val  set scroll lines\n"
" -n      type-to-nav mode\n"
" -N      use native prompt\n"
" -o      open files only on Enter\n"
" -p file selection file [-:stdout]\n"
" -P key  run plugin key\n"
" -Q      no quit confirmation\n"
" -r      use advcpmv patched cp, mv\n"
" -R      no rollover at edges\n"
" -s name load session by name\n"
" -S      persistent session\n"
" -t secs timeout to lock\n"
" -T key  sort order [a/d/e/r/s/t/v]\n"
" -u      use selection (no prompt)\n"
" -U      show user and group\n"
" -V      show version\n"
" -x      notis, selection sync, xterm title\n"
" -z      in order fuzzy filters\n"
" -0      null separator in picker mode\n"
" -h      show help\n"
"\n"
"v5.2\n"
"BSD 2-Clause\n"
"https://github.com/jarun/nnn\n";

struct entry {
    char *name;
    int is_dir;
};

static struct termios saved_term;
static int raw_enabled;

static void die_usage(void)
{
    fputs(help_text, stderr);
}

static void restore_term(void)
{
    if (raw_enabled) {
        tcsetattr(STDIN_FILENO, TCSAFLUSH, &saved_term);
        raw_enabled = 0;
        fputs("\033[?25h\033[?1049l", stdout);
        fflush(stdout);
    }
}

static void on_signal(int sig)
{
    (void)sig;
    restore_term();
    _exit(1);
}

static int cmp_entry(const void *a, const void *b)
{
    const struct entry *ea = (const struct entry *)a;
    const struct entry *eb = (const struct entry *)b;
    if (ea->is_dir != eb->is_dir)
        return eb->is_dir - ea->is_dir;
    return strcasecmp(ea->name, eb->name);
}

static void free_entries(struct entry *entries, size_t n)
{
    for (size_t i = 0; i < n; ++i)
        free(entries[i].name);
    free(entries);
}

static size_t read_entries(const char *path, int show_hidden, struct entry **out)
{
    DIR *dir = opendir(path);
    struct dirent *de;
    struct entry *entries = NULL;
    size_t n = 0, cap = 0;

    if (!dir) {
        *out = NULL;
        return 0;
    }

    while ((de = readdir(dir))) {
        if (!strcmp(de->d_name, ".") || !strcmp(de->d_name, ".."))
            continue;
        if (!show_hidden && de->d_name[0] == '.')
            continue;
        if (n == cap) {
            cap = cap ? cap * 2 : 64;
            entries = realloc(entries, cap * sizeof(*entries));
            if (!entries) {
                closedir(dir);
                exit(2);
            }
        }
        entries[n].name = strdup(de->d_name);
        entries[n].is_dir = de->d_type == DT_DIR;
        if (de->d_type == DT_UNKNOWN) {
            char full[PATH_MAX];
            struct stat st;
            snprintf(full, sizeof(full), "%s/%s", path, de->d_name);
            entries[n].is_dir = !stat(full, &st) && S_ISDIR(st.st_mode);
        }
        ++n;
    }
    closedir(dir);
    qsort(entries, n, sizeof(*entries), cmp_entry);
    *out = entries;
    return n;
}

static void normalize_start(char *buf, size_t bufsz, const char *path)
{
    struct stat st;
    char tmp[PATH_MAX];

    if (!path)
        path = ".";
    if (stat(path, &st) == 0 && S_ISREG(st.st_mode)) {
        strncpy(tmp, path, sizeof(tmp) - 1);
        tmp[sizeof(tmp) - 1] = '\0';
        char *slash = strrchr(tmp, '/');
        if (slash) {
            if (slash == tmp)
                slash[1] = '\0';
            else
                *slash = '\0';
            path = tmp;
        } else {
            path = ".";
        }
    }
    if (!realpath(path, buf)) {
        if (path[0] == '/')
            snprintf(buf, bufsz, "%s", path);
        else {
            char cwd[PATH_MAX];
            if (!getcwd(cwd, sizeof(cwd)))
                strcpy(cwd, ".");
            snprintf(buf, bufsz, "%s/%s", cwd, path);
        }
    }
}

static void write_selection(const char *picker, const char *path, int nul)
{
    FILE *fp;
    if (!picker)
        return;
    if (!strcmp(picker, "-")) {
        fwrite(path, 1, strlen(path), stdout);
        fputc(nul ? '\0' : '\n', stdout);
        fflush(stdout);
        return;
    }
    fp = fopen(picker, "a");
    if (!fp)
        return;
    fwrite(path, 1, strlen(path), fp);
    fputc(nul ? '\0' : '\n', fp);
    fclose(fp);
}

static void draw(const char *cwd, struct entry *entries, size_t n, size_t cur)
{
    int rows = 22;
    printf("\033[H\033[J");
    printf("nnn v5.2  %s\n", cwd);
    printf("%zu entries\n", n);
    for (size_t i = 0; i < n && i < (size_t)rows; ++i) {
        const char *mark = i == cur ? ">" : " ";
        printf("%s %s%s\n", mark, entries[i].name, entries[i].is_dir ? "/" : "");
    }
    printf("\nq: quit  Enter: open  Space: select\n");
    fflush(stdout);
}

static int enable_raw(void)
{
    struct termios raw;
    if (!isatty(STDIN_FILENO))
        return 0;
    if (tcgetattr(STDIN_FILENO, &saved_term) == -1)
        return 0;
    raw = saved_term;
    raw.c_lflag &= (tcflag_t)~(ECHO | ICANON);
    raw.c_cc[VMIN] = 1;
    raw.c_cc[VTIME] = 0;
    if (tcsetattr(STDIN_FILENO, TCSAFLUSH, &raw) == -1)
        return 0;
    raw_enabled = 1;
    atexit(restore_term);
    signal(SIGINT, on_signal);
    signal(SIGTERM, on_signal);
    fputs("\033[?1049h\033[?25l", stdout);
    return 1;
}

static int run_browser(const char *start, int show_hidden, const char *picker, int nul)
{
    char cwd[PATH_MAX];
    struct entry *entries = NULL;
    size_t n = 0, cur = 0;

    normalize_start(cwd, sizeof(cwd), start);
    n = read_entries(cwd, show_hidden, &entries);

    if (!enable_raw()) {
        fprintf(stderr, "0 entries\n");
        free_entries(entries, n);
        pause();
        return 1;
    }

    for (;;) {
        int ch;
        draw(cwd, entries, n, cur);
        ch = getchar();
        if (ch == EOF || ch == 'q' || ch == 'Q' || ch == 27)
            break;
        if ((ch == 'j' || ch == 'n') && cur + 1 < n)
            ++cur;
        else if ((ch == 'k' || ch == 'p') && cur > 0)
            --cur;
        else if (ch == ' ' && n) {
            char sel[PATH_MAX];
            snprintf(sel, sizeof(sel), "%s/%s", cwd, entries[cur].name);
            write_selection(picker, sel, nul);
        } else if ((ch == '\n' || ch == '\r') && n && entries[cur].is_dir) {
            char next[PATH_MAX], real[PATH_MAX];
            snprintf(next, sizeof(next), "%s/%s", cwd, entries[cur].name);
            if (realpath(next, real)) {
                strcpy(cwd, real);
                free_entries(entries, n);
                n = read_entries(cwd, show_hidden, &entries);
                cur = 0;
            }
        }
    }
    free_entries(entries, n);
    return 0;
}

int main(int argc, char **argv)
{
    int opt;
    int show_hidden = 0, nul = 0, keycheck = 0;
    const char *picker = NULL;

    opterr = 1;
    while ((opt = getopt(argc, argv, "aAb:BCcDdEeF:fgHiJKl:nNop:P:QrRs:St:T:uUVxz0h")) != -1) {
        switch (opt) {
        case 'h':
            fputs(help_text, stdout);
            return 0;
        case 'V':
            puts("5.2");
            return 0;
        case 'H':
            show_hidden = 1;
            break;
        case 'K':
            keycheck = 1;
            break;
        case 'p':
            picker = optarg;
            break;
        case '0':
            nul = 1;
            break;
        case '?':
        default:
            die_usage();
            return 1;
        }
    }

    if (keycheck)
        return 0;

    return run_browser(optind < argc ? argv[optind] : ".", show_hidden, picker, nul);
}
