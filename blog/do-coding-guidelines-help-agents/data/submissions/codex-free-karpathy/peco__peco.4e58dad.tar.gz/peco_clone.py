#!/usr/bin/env python3
import os, sys, re, termios, tty

HELP = """Usage: peco [options] [FILE]

Options:
  -h, --help            show this help message and exit
  --query               initial value for query
  --rcfile              path to the settings file
  --version             print the version and exit
  -b, --buffer-size     number of lines to keep in search buffer
  --null                expect NUL (\\0) as separator for target/output
  --initial-index       position of the initial index of the selection (0 base)
  --initial-filter      specify the default filter
  --prompt              specify the prompt string
  --layout              layout to be used. 'top-down', 'bottom-up', or 'top-down-query-bottom'. default is 'top-down'
  --select-1            select first item and immediately exit if the input contains only 1 item
  --exit-0              exit immediately with status 1 if the input is empty
  --select-all          select all items and immediately exit
  --on-cancel           specify action on user cancel. 'success' or 'error'.
                        default is 'success'. This may change in future versions
  --selection-prefix    use a prefix instead of changing line color to indicate currently selected lines.
                        default is to use colors. This option is experimental
  --exec                execute command instead of finishing/terminating peco.
                        Please note that this command will receive selected line(s) from stdin,
                        and will be executed via '/bin/sh -c' or 'cmd /c'
  --print-query         print out the current query as first line of output
  --ansi                enable ANSI color code support
  --height              display height in lines or percentage (e.g. '10', '50%')
"""
VERSION = "peco version v0.5.11 (built with go1.25.0)"
ANSI_RE = re.compile(r"\x1b\[[0-?]*[ -/]*[@-~]")

class Opts:
    def __init__(self):
        self.query=""; self.rcfile=None; self.buffer_size=0; self.null=False
        self.initial_index=0; self.initial_filter="IgnoreCase"; self.prompt="QUERY>"
        self.layout="top-down"; self.select1=False; self.exit0=False; self.selectall=False
        self.on_cancel="success"; self.selection_prefix=None; self.exec_cmd=None
        self.print_query=False; self.ansi=False; self.height=None; self.file=None

def die_parse(msg):
    sys.stderr.write(msg + "\n\n" + HELP)
    sys.stderr.write("Error: failed to setup peco: failed to parse command line: failed to parse command line options: invalid command line options: " + msg + "\n")
    sys.exit(1)

def need_arg(argv, i, flag):
    if i+1 >= len(argv):
        die_parse(f"expected argument for flag `{flag}'")
    return argv[i+1], i+2

def parse(argv):
    o=Opts(); i=0
    while i < len(argv):
        a=argv[i]
        if a in ("-h","--help"):
            sys.stdout.write(HELP); sys.exit(0)
        if a == "--version":
            print(VERSION); sys.exit(0)
        if a.startswith("--") and "=" in a:
            flag,val=a.split("=",1)
            argv=argv[:i]+[flag,val]+argv[i+1:]
            a=flag
        if a == "--query": o.query,i=need_arg(argv,i,a); continue
        if a == "--rcfile": o.rcfile,i=need_arg(argv,i,a); continue
        if a in ("-b","--buffer-size"):
            v,i=need_arg(argv,i,a)
            try: o.buffer_size=int(v)
            except Exception: o.buffer_size=0
            continue
        if a == "--null": o.null=True; i+=1; continue
        if a == "--initial-index":
            v,i=need_arg(argv,i,a)
            try: o.initial_index=max(0,int(v))
            except Exception: o.initial_index=0
            continue
        if a == "--initial-filter": o.initial_filter,i=need_arg(argv,i,a); continue
        if a == "--prompt": o.prompt,i=need_arg(argv,i,a); continue
        if a == "--layout": o.layout,i=need_arg(argv,i,a); continue
        if a == "--select-1": o.select1=True; i+=1; continue
        if a == "--exit-0": o.exit0=True; i+=1; continue
        if a == "--select-all": o.selectall=True; i+=1; continue
        if a == "--on-cancel": o.on_cancel,i=need_arg(argv,i,a); continue
        if a == "--selection-prefix": o.selection_prefix,i=need_arg(argv,i,a); continue
        if a == "--exec": o.exec_cmd,i=need_arg(argv,i,a); continue
        if a == "--print-query": o.print_query=True; i+=1; continue
        if a == "--ansi": o.ansi=True; i+=1; continue
        if a == "--height": o.height,i=need_arg(argv,i,a); continue
        if a.startswith("-"):
            die_parse(f"unknown flag `{a.lstrip('-')}'")
        if o.file is not None:
            die_parse("too many arguments")
        o.file=a; i+=1
    return o

def load_items(o):
    try:
        data = open(o.file,'rb').read() if o.file else sys.stdin.buffer.read()
    except OSError as e:
        sys.stderr.write(f"Error: failed to setup input source: failed to open file for input: {e}\n")
        sys.exit(1)
    if data == b"": return []
    raw = data.splitlines()
    items=[]
    for line in raw:
        if o.null and b"\0" in line:
            disp,res=line.split(b"\0",1)
        else:
            disp=res=line
        d=disp.decode('utf-8','replace'); r=res.decode('utf-8','replace')
        plain=ANSI_RE.sub('', d)
        items.append((d,r,plain))
        if o.buffer_size and len(items)>=o.buffer_size: break
    return items

def terms(q):
    out=[]; cur=''; esc=False
    for ch in q:
        if esc:
            cur += ch; esc=False
        elif ch == '\\':
            esc=True
        elif ch.isspace():
            if cur!='': out.append(cur); cur=''
        else:
            cur += ch
    if esc: cur += '\\'
    if cur!='': out.append(cur)
    pos=[]; neg=[]
    for t in out:
        if t.startswith('-') and len(t)>1: neg.append(t[1:])
        else: pos.append(t)
    return pos,neg

def fuzzy_match(s, pat, case_sensitive):
    if not case_sensitive: s=s.lower(); pat=pat.lower()
    j=0
    for ch in s:
        if j < len(pat) and ch == pat[j]: j += 1
    return j == len(pat)

def line_match(item, q, filt):
    if q == '': return True
    s=item[2]
    pos,neg=terms(q)
    case_sensitive = filt in ("CaseSensitive","Regexp") or (filt=="SmartCase" and any(any(c.isupper() for c in t) for t in pos+neg))
    def contains(term):
        if filt in ("Regexp","IRegexp"):
            flags=0 if filt=="Regexp" else re.I
            try: return re.search(term, s, flags) is not None
            except re.error: return False
        if filt == "Fuzzy":
            return fuzzy_match(s, term, case_sensitive)
        if case_sensitive: return term in s
        return term.lower() in s.lower()
    def neg_contains(term):
        if filt in ("Regexp","IRegexp","Fuzzy"):
            flags=0 if (filt=="Regexp" or case_sensitive) else re.I
            try: return re.search(term, s, flags) is not None
            except re.error: return False
        if case_sensitive: return term in s
        return term.lower() in s.lower()
    for t in pos:
        if not contains(t): return False
    for t in neg:
        if neg_contains(t): return False
    return True

def filtered(items, q, filt):
    if filt not in ("IgnoreCase","CaseSensitive","SmartCase","IRegexp","Regexp","Fuzzy"):
        filt="IgnoreCase"
    return [it for it in items if line_match(it,q,filt)]

def emit(lines, query=None):
    if query is not None: sys.stdout.write(query + "\n")
    for it in lines: sys.stdout.write(it[1] + "\n")
    sys.stdout.flush()

def interactive(o, items):
    q=o.query; idx=o.initial_index; filt=o.initial_filter
    old=None
    if sys.stdin.isatty():
        try:
            old=termios.tcgetattr(sys.stdin.fileno()); tty.setraw(sys.stdin.fileno())
        except Exception: old=None
    try:
        while True:
            matches=filtered(items,q,filt)
            if idx >= len(matches): idx=max(0,len(matches)-1)
            if sys.stderr.isatty():
                sys.stderr.write("\r\x1b[2K" + o.prompt + q + f" [{len(matches)}/{len(items)}]")
                sys.stderr.flush()
            ch=sys.stdin.read(1)
            if ch == '':
                return 1
            if ch in ('\r','\n'):
                if o.print_query: sys.stdout.write(q+"\n")
                if matches and idx < len(matches): sys.stdout.write(matches[idx][1]+"\n")
                return 0
            if ch in ('\x03','\x1b'):
                if ch=='\x1b':
                    seq=sys.stdin.read(2)
                    if seq == '[B': idx += 1; continue
                    if seq == '[A': idx = max(0,idx-1); continue
                    if seq == '[C': idx += 10; continue
                    if seq == '[D': idx = max(0,idx-10); continue
                return 0 if o.on_cancel != 'error' else 1
            if ch in ('\x7f','\b'):
                q=q[:-1]
            elif ch == '\x0e': idx += 1
            elif ch == '\x10': idx = max(0,idx-1)
            elif ch == '\x12':
                order=["IgnoreCase","CaseSensitive","SmartCase","IRegexp","Regexp","Fuzzy"]
                filt=order[(order.index(filt) + 1) % len(order)] if filt in order else "IgnoreCase"
            elif ord(ch) >= 32:
                q += ch; idx=0
    finally:
        if old is not None:
            try: termios.tcsetattr(sys.stdin.fileno(), termios.TCSADRAIN, old)
            except Exception: pass

def main():
    o=parse(sys.argv[1:])
    if o.rcfile and not os.path.exists(o.rcfile):
        sys.stderr.write(f"Error: failed to setup peco: failed to load config file: open {o.rcfile}: no such file or directory\n")
        return 1
    items=load_items(o)
    if o.exit0 and not items: return 1
    if o.selectall:
        emit(items, o.query if o.print_query else None); return 0
    if o.select1 and len(items)==1:
        if o.initial_index >= len(items):
            if o.print_query: sys.stdout.write(o.query+"\n")
            return 0
        emit([items[o.initial_index]], o.query if o.print_query else None); return 0
    return interactive(o, items)
if __name__ == "__main__":
    sys.exit(main())
