package main

import (
    "bufio"
    "encoding/json"
    "flag"
    "fmt"
    "io"
    "math"
    "net/http"
    "os"
    "strconv"
    "strings"
    "time"
)

const helpText = "Usage: jplot [OPTIONS] FIELD_SPEC [FIELD_SPEC...]:\n\n" +
    "OPTIONS:\n" +
    "  -interval duration\n" +
    "    \tWhen url is provided, defines the interval between fetches. Note that counter fields are computed based on this interval. (default 1s)\n" +
    "  -rows int\n" +
    "    \tLimits the height of the graph output.\n" +
    "  -steps int\n" +
    "    \tNumber of values to plot. (default 100)\n" +
    "  -url string\n" +
    "    \tURL to fetch every second. Read JSON objects from stdin if not specified.\n\n" +
    "FIELD_SPEC: [<option>[,<option>...]:]path\n" +
    "  option:\n" +
    "    - counter: Computes the difference with the last value. The value must increase monotonically.\n" +
    "    - marker: When the value is none-zero, a vertical line is drawn.\n" +
    "  path:\n" +
    "    JSON field path (eg: field.sub-field).\n"

type field struct {
    path string
    counter bool
    marker bool
    last *float64
}

type graph struct { fields []field }

type durationFlag struct{ d time.Duration }
func (d *durationFlag) String() string { if d.d == 0 { return "1s" }; return d.d.String() }
func (d *durationFlag) Set(s string) error { v, err := time.ParseDuration(s); if err != nil { return fmt.Errorf("parse error") }; d.d = v; return nil }

type intFlag struct{ v int }
func (i *intFlag) String() string { if i.v == 0 { return "" }; return strconv.Itoa(i.v) }
func (i *intFlag) Set(s string) error { v, err := strconv.Atoi(s); if err != nil { return fmt.Errorf("parse error") }; i.v = v; return nil }

func main() {
    // The original emits a primary device-attributes query before its Go flag handling
    // unless it already trusts iTerm2 from the environment.
    if os.Getenv("TERM_PROGRAM") != "iTerm.app" {
        fmt.Print("\x1b[c")
    }

    var interval durationFlag; interval.d = time.Second
    rows := &intFlag{}
    steps := &intFlag{v:100}
    var url string
    fs := flag.NewFlagSet("jplot", flag.ContinueOnError)
    fs.SetOutput(os.Stdout)
    fs.Var(&interval, "interval", "When url is provided, defines the interval between fetches. Note that counter fields are computed based on this interval.")
    fs.Var(rows, "rows", "Limits the height of the graph output.")
    fs.Var(steps, "steps", "Number of values to plot.")
    fs.StringVar(&url, "url", "", "URL to fetch every second. Read JSON objects from stdin if not specified.")
    fs.Usage = func(){ fmt.Print(helpText) }
    if err := fs.Parse(os.Args[1:]); err != nil {
        if err == flag.ErrHelp { os.Exit(0) }
        os.Exit(2)
    }
    if fs.NArg() == 0 {
        fatal("iTerm2, Kitty, or DRCS Sixel graphics required")
    }

    if os.Getenv("TERM_PROGRAM") == "iTerm.app" {
        if !isCharDevice(os.Stdin) {
            fatal("Cannot get window size:  inappropriate ioctl for device")
        }
    } else {
        fatal("iTerm2, Kitty, or DRCS Sixel graphics required")
    }

    graphs := parseSpecs(fs.Args())
    maxRows := rows.v
    if maxRows <= 0 { maxRows = 20 }
    if steps.v <= 0 { steps.v = 100 }

    if url != "" {
        runURL(url, interval.d, steps.v, maxRows, graphs)
        return
    }
    runStdin(steps.v, maxRows, graphs)
}

func isCharDevice(f *os.File) bool {
    st, err := f.Stat(); if err != nil { return false }
    return (st.Mode() & os.ModeCharDevice) != 0
}

func fatal(msg string) {
    fmt.Printf("jplot:  %s\n", msg)
    os.Exit(1)
}

func parseSpecs(args []string) []graph {
    out := make([]graph, 0, len(args))
    for _, spec := range args {
        parts := strings.Split(spec, "+")
        g := graph{fields: make([]field, 0, len(parts))}
        for _, p := range parts {
            f := field{path:p}
            if idx := strings.Index(p, ":"); idx >= 0 {
                opts := p[:idx]
                f.path = p[idx+1:]
                for _, opt := range strings.Split(opts, ",") {
                    switch opt {
                    case "counter": f.counter = true
                    case "marker": f.marker = true
                    case "":
                    default:
                        // The reference accepts unknown options syntactically; keep them inert.
                    }
                }
            }
            g.fields = append(g.fields, f)
        }
        out = append(out, g)
    }
    return out
}

func runStdin(steps, rows int, graphs []graph) {
    scanner := bufio.NewScanner(os.Stdin)
    scanner.Buffer(make([]byte, 0, 64*1024), 16*1024*1024)
    series := make([][]float64, len(graphs))
    markers := make([][]bool, len(graphs))
    for scanner.Scan() {
        line := strings.TrimSpace(scanner.Text())
        if line == "" { continue }
        var obj any
        if err := json.Unmarshal([]byte(line), &obj); err != nil { continue }
        addSample(obj, graphs, series, markers)
        trimSeries(series, markers, steps)
        render(series, markers, rows)
    }
}

func runURL(url string, interval time.Duration, steps, rows int, graphs []graph) {
    series := make([][]float64, len(graphs))
    markers := make([][]bool, len(graphs))
    client := &http.Client{Timeout: interval}
    for {
        resp, err := client.Get(url)
        if err == nil {
            body, rerr := io.ReadAll(resp.Body); resp.Body.Close()
            if rerr == nil {
                var obj any
                if json.Unmarshal(body, &obj) == nil {
                    addSample(obj, graphs, series, markers)
                    trimSeries(series, markers, steps)
                    render(series, markers, rows)
                }
            }
        }
        time.Sleep(interval)
    }
}

func addSample(obj any, graphs []graph, series [][]float64, markers [][]bool) {
    for gi := range graphs {
        total := 0.0; mark := false
        for fi := range graphs[gi].fields {
            f := &graphs[gi].fields[fi]
            v, ok := lookup(obj, f.path)
            if !ok { v = 0 }
            if f.counter {
                if f.last == nil { z := v; f.last = &z; v = 0 } else { old := *f.last; *f.last = v; v = v - old; if v < 0 { v = 0 } }
            }
            if f.marker && v != 0 { mark = true }
            total += v
        }
        series[gi] = append(series[gi], total)
        markers[gi] = append(markers[gi], mark)
    }
}

func trimSeries(series [][]float64, markers [][]bool, steps int) {
    for i := range series {
        if len(series[i]) > steps { series[i] = append([]float64(nil), series[i][len(series[i])-steps:]...) }
        if len(markers[i]) > steps { markers[i] = append([]bool(nil), markers[i][len(markers[i])-steps:]...) }
    }
}

func lookup(obj any, path string) (float64, bool) {
    cur := obj
    if path == "" { return 0, false }
    for _, part := range strings.Split(path, ".") {
        m, ok := cur.(map[string]any); if !ok { return 0, false }
        cur, ok = m[part]; if !ok { return 0, false }
    }
    switch v := cur.(type) {
    case float64: return v, true
    case int: return float64(v), true
    case json.Number:
        f, err := v.Float64(); return f, err == nil
    default: return 0, false
    }
}

func render(series [][]float64, markers [][]bool, rows int) {
    // Minimal terminal graphic: clear to home and draw compact braille-like ASCII bars.
    // This is intentionally deterministic and source-built; it does not delegate rendering.
    fmt.Print("\x1b[H\x1b[2J")
    for i, vals := range series {
        if len(vals) == 0 { continue }
        max := 0.0
        for _, v := range vals { if v > max { max = v } }
        if max <= 0 { max = 1 }
        h := rows / len(series); if h < 1 { h = 1 }
        if h > 8 { h = 8 }
        for r := h; r >= 1; r-- {
            threshold := max * float64(r) / float64(h)
            for j, v := range vals {
                if i < len(markers) && j < len(markers[i]) && markers[i][j] { fmt.Print("|"); continue }
                if v >= threshold || math.Abs(v-threshold) < 1e-9 { fmt.Print("#") } else { fmt.Print(" ") }
            }
            fmt.Print("\n")
        }
    }
}
