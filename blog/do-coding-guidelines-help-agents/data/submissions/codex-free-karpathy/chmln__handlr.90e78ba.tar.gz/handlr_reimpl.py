#!/usr/bin/env python3
import json
import os
import re
import shlex
import subprocess
import sys
from pathlib import Path

VERSION = "handlr 0.6.4"

COMMON_EXT = {
    ".txt": "text/plain", ".text": "text/plain", ".md": "text/markdown", ".markdown": "text/markdown",
    ".png": "image/png", ".jpg": "image/jpeg", ".jpeg": "image/jpeg", ".gif": "image/gif",
    ".webp": "image/webp", ".svg": "image/svg+xml", ".pdf": "application/pdf",
    ".html": "text/html", ".htm": "text/html", ".css": "text/css", ".csv": "text/csv",
    ".json": "application/json", ".xml": "application/xml", ".zip": "application/zip",
    ".mp3": "audio/mpeg", ".ogg": "audio/ogg", ".mp4": "video/mp4",
}
MAGIC = [(b"\x89PNG\r\n\x1a\n", "image/png"), (b"%PDF-", "application/pdf"), (b"GIF87a", "image/gif"), (b"GIF89a", "image/gif")]
TOKEN_RE = re.compile(r"^[A-Za-z0-9!#$&^_.+-]+/[A-Za-z0-9!#$&^_.+-]+$|^[A-Za-z0-9!#$&^_.+-]+/\*$")


def home():
    return Path(os.environ.get("HOME", str(Path.home())))


def xdg_config_home():
    return Path(os.environ.get("XDG_CONFIG_HOME", home() / ".config"))


def xdg_data_home():
    return Path(os.environ.get("XDG_DATA_HOME", home() / ".local/share"))


def xdg_data_dirs():
    raw = os.environ.get("XDG_DATA_DIRS", "/usr/local/share:/usr/share")
    return [Path(p) for p in raw.split(":") if p]


def app_dirs():
    return [xdg_data_home() / "applications"] + [p / "applications" for p in xdg_data_dirs()]


def mimeapps_path():
    return xdg_config_home() / "mimeapps.list"


def eprint(s=""):
    print(s, file=sys.stderr)


def clap_error(msg, usage):
    eprint(f"error: {msg}\n")
    eprint(usage)
    eprint("\nFor more information try --help")
    return 2


def invalid_value(arg, msg, usage):
    eprint(f"error: Invalid value for '{arg}': {msg}\n")
    eprint("For more information try --help")
    return 2


def main_help():
    return """handlr 0.6.4

USAGE:
    executable <SUBCOMMAND>

FLAGS:
    -h, --help       Prints help information
    -V, --version    Prints version information

SUBCOMMANDS:
    list      List default apps and the associated handlers
    open      Open a path/URL with its default handler
    set       Set the default handler for mime/extension
    unset     Unset the default handler for mime/extension
    launch    Launch the handler for specified extension/mime with optional arguments
    get       Get handler for this mime/extension
    add       Add a handler for given mime/extension Note that the first handler is the default"""

HELP = {
"list": """executable-list 
List default apps and the associated handlers

USAGE:
    executable list [FLAGS]

FLAGS:
    -a, --all        
    -h, --help       Prints help information
    -V, --version    Prints version information""",
"open": """executable-open 
Open a path/URL with its default handler

USAGE:
    executable open <paths>...

ARGS:
    <paths>...    

FLAGS:
    -h, --help       Prints help information
    -V, --version    Prints version information""",
"set": """executable-set 
Set the default handler for mime/extension

USAGE:
    executable set <mime> <handler>

ARGS:
    <mime>       
    <handler>    

FLAGS:
    -h, --help       Prints help information
    -V, --version    Prints version information""",
"unset": """executable-unset 
Unset the default handler for mime/extension

USAGE:
    executable unset <mime>

ARGS:
    <mime>    

FLAGS:
    -h, --help       Prints help information
    -V, --version    Prints version information""",
"launch": """executable-launch 
Launch the handler for specified extension/mime with optional arguments

USAGE:
    executable launch <mime> [args]...

ARGS:
    <mime>       
    <args>...    

FLAGS:
    -h, --help       Prints help information
    -V, --version    Prints version information""",
"get": """executable-get 
Get handler for this mime/extension

USAGE:
    executable get [FLAGS] <mime>

ARGS:
    <mime>    

FLAGS:
        --json       
    -h, --help       Prints help information
    -V, --version    Prints version information""",
"add": """executable-add 
Add a handler for given mime/extension Note that the first handler is the default

USAGE:
    executable add <mime> <handler>

ARGS:
    <mime>       
    <handler>    

FLAGS:
    -h, --help       Prints help information
    -V, --version    Prints version information""",
}

USAGE = {
    "get": "USAGE:\n    executable get [FLAGS] <mime>",
    "set": "USAGE:\n    executable set <mime> <handler>",
    "add": "USAGE:\n    executable add <mime> <handler>",
    "unset": "USAGE:\n    executable unset <mime>",
    "open": "USAGE:\n    executable open <paths>...",
    "launch": "USAGE:\n    executable launch <mime> [args]...",
}


def parse_ini(path):
    sections = {}
    order = []
    if not path.exists():
        return sections, order
    cur = None
    for line in path.read_text(errors="replace").splitlines():
        s = line.strip()
        if not s or s.startswith("#") or s.startswith(";"):
            continue
        if s.startswith("[") and s.endswith("]"):
            cur = s[1:-1]
            if cur not in sections:
                sections[cur] = {}
                order.append(cur)
        elif cur and "=" in line:
            k, v = line.split("=", 1)
            sections[cur][k.strip()] = v.strip()
    return sections, order


def split_list(v):
    return [x for x in v.split(";") if x]


def read_mimeapps():
    p = mimeapps_path()
    sec, _ = parse_ini(p)
    defaults = {k: split_list(v) for k, v in sec.get("Default Applications", {}).items()}
    added = {k: split_list(v) for k, v in sec.get("Added Associations", {}).items()}
    return defaults, added


def write_mimeapps(defaults, added=None):
    p = mimeapps_path()
    p.parent.mkdir(parents=True, exist_ok=True)
    lines = ["[Added Associations]"]
    if added:
        for k in sorted(added):
            if added[k]:
                lines.append(f"{k}={';'.join(added[k])};")
    lines += ["", "[Default Applications]"]
    for k in sorted(defaults):
        if defaults[k]:
            lines.append(f"{k}={';'.join(defaults[k])};")
    p.write_text("\n".join(lines) + "\n")


def parse_desktop(path):
    sec, _ = parse_ini(path)
    d = sec.get("Desktop Entry", {})
    return d


def desktop_id_for(base, file):
    try:
        rel = file.relative_to(base)
        return "-".join(rel.parts)
    except Exception:
        return file.name


def discover_desktops():
    apps = {}
    for base in app_dirs():
        if not base.exists():
            continue
        for f in sorted(base.rglob("*.desktop")):
            did = desktop_id_for(base, f)
            if did not in apps:
                d = parse_desktop(f)
                d["_path"] = str(f)
                d["_id"] = did
                apps[did] = d
    return apps


def system_associations(apps):
    out = {}
    for did, d in apps.items():
        for m in split_list(d.get("MimeType", "")):
            out.setdefault(m, []).append(did)
    return out


def validate_mime(raw, usage):
    if raw.startswith("."):
        m = mime_from_extension(raw)
        if not m:
            raise ValueError(f"could not figure out the mime type of '{raw}'")
        return m
    if not TOKEN_RE.match(raw):
        if "/" not in raw:
            raise ValueError("mime parse error: a slash (/) was missing between the type and subtype")
        badpos = 0
        for i, ch in enumerate(raw):
            if not (ch.isalnum() or ch in "!#$&^_.+-*/"):
                badpos = i; break
        else:
            badpos = 0
        raise ValueError(f"mime parse error: an invalid token was encountered, {ord(raw[badpos]):02X} at position {badpos}")
    return raw


def mime_from_extension(ext):
    ext = ext.lower()
    for gd in [xdg_data_home()/"mime"] + [d/"mime" for d in xdg_data_dirs()]:
        for name in ("globs2", "globs"):
            f = gd / name
            if not f.exists():
                continue
            for line in f.read_text(errors="ignore").splitlines():
                if not line or line.startswith("#"):
                    continue
                parts = line.split(":")
                if name == "globs2" and len(parts) >= 3:
                    mime, glob = parts[-2], parts[-1]
                elif name == "globs" and len(parts) >= 2:
                    mime, glob = parts[0], parts[1]
                else:
                    continue
                if glob.startswith("*.") and ("." + glob[2:].lower()) == ext:
                    return mime
    return COMMON_EXT.get(ext)


def mime_for_path_or_url(s):
    m = re.match(r"^([A-Za-z][A-Za-z0-9+.-]*):", s)
    if m:
        return "x-scheme-handler/" + m.group(1).lower()
    p = Path(s)
    try:
        with p.open("rb") as fh:
            data = fh.read(16)
        for sig, mt in MAGIC:
            if data.startswith(sig):
                return mt
        if data and all((b in b"\t\n\r" or 32 <= b < 127) for b in data):
            if p.suffix.lower() in COMMON_EXT:
                return COMMON_EXT[p.suffix.lower()]
            return "text/plain"
    except Exception:
        pass
    if p.suffix:
        return mime_from_extension(p.suffix) or "application/octet-stream"
    return "application/octet-stream"


def find_handler(mime, apps):
    defaults, _ = read_mimeapps()
    sysassoc = system_associations(apps)
    candidates = []
    if mime in defaults and defaults[mime]:
        candidates = defaults[mime]
    else:
        top = mime.split("/", 1)[0] + "/*" if "/" in mime else None
        if top and top in defaults and defaults[top]:
            candidates = defaults[top]
        elif mime in sysassoc and sysassoc[mime]:
            candidates = sysassoc[mime]
        elif top and top in sysassoc and sysassoc[top]:
            candidates = sysassoc[top]
    for h in candidates:
        if h in apps and apps[h].get("Exec"):
            return h
    return candidates[0] if candidates else None


def validate_handler(handler, apps, usage):
    if handler not in apps:
        return invalid_value("<handler>", f"no handlers found for '{handler}'", usage)
    if not apps[handler].get("Exec"):
        return invalid_value("<handler>", f"malformed desktop entry at {apps[handler].get('_path', handler)}", usage)
    return None


def clean_cmd(exec_line):
    parts = shlex.split(exec_line)
    out = []
    for p in parts:
        if p in ("%f", "%F", "%u", "%U"):
            continue
        if any(code in p for code in ("%f", "%F", "%u", "%U")):
            p = p.replace("%f", "").replace("%F", "").replace("%u", "").replace("%U", "")
            if not p:
                continue
        out.append(p)
    return " ".join(shlex.quote(x) if re.search(r"\s", x) else x for x in out)


def expand_exec(exec_line, args, desktop):
    parts = shlex.split(exec_line)
    out = []
    first = args[0] if args else ""
    used = False
    for p in parts:
        if p in ("%f", "%u"):
            if first:
                out.append(first); used = True
        elif p in ("%F", "%U"):
            out.extend(args); used = True
        elif p == "%%":
            out.append("%")
        elif p in ("%i", "%c", "%k"):
            if p == "%c" and desktop.get("Name"):
                out.append(desktop.get("Name"))
            elif p == "%k" and desktop.get("_path"):
                out.append(desktop.get("_path"))
        else:
            q = p.replace("%%", "%")
            q = q.replace("%f", first).replace("%u", first)
            if "%F" in q or "%U" in q:
                q = q.replace("%F", " ".join(args)).replace("%U", " ".join(args)); used = True
            out.append(q)
    if args and not used:
        out.extend(args)
    return out


def table(rows):
    if not rows:
        return "┌──┐\n│  │\n└──┘"
    w1 = max(len(str(a)) for a, _ in rows)
    w2 = max(len(str(b)) for _, b in rows)
    lines = ["┌" + "─"*(w1+2) + "┬" + "─"*(w2+2) + "┐"]
    for a, b in rows:
        lines.append("│ " + str(a).ljust(w1) + " │ " + str(b).ljust(w2) + " │")
    lines.append("└" + "─"*(w1+2) + "┴" + "─"*(w2+2) + "┘")
    return "\n".join(lines)


def cmd_list(args):
    if args in (["-h"], ["--help"]): print(HELP["list"]); return 0
    if args in (["-V"], ["--version"]): print(VERSION); return 0
    allflag = False
    rest = []
    for a in args:
        if a in ("-a", "--all"): allflag = True
        else: rest.append(a)
    apps = discover_desktops()
    defaults, _ = read_mimeapps()
    rows = [(k, ", ".join(v)) for k, v in sorted(defaults.items()) if v]
    if allflag:
        print("Default Apps")
    print(table(rows))
    if allflag:
        print("System Apps")
        sysassoc = system_associations(apps)
        print(table([(k, ", ".join(v)) for k, v in sorted(sysassoc.items()) if v]))
    return 0


def cmd_get(args):
    if args in (["-h"], ["--help"]): print(HELP["get"]); return 0
    if args in (["-V"], ["--version"]): print(VERSION); return 0
    js = False
    vals = []
    for a in args:
        if a == "--json": js = True
        else: vals.append(a)
    if not vals:
        return clap_error("The following required arguments were not provided:\n    <mime>", USAGE["get"])
    try:
        mime = validate_mime(vals[0], USAGE["get"])
    except ValueError as e:
        return invalid_value("<mime>", str(e), USAGE["get"])
    apps = discover_desktops(); h = find_handler(mime, apps)
    if not h: return 1
    if js:
        d = apps.get(h, {})
        print(json.dumps({"handler": h, "name": d.get("Name", ""), "cmd": clean_cmd(d.get("Exec", ""))}, separators=(",", ":")))
    else:
        print(h)
    return 0


def setlike(args, add=False):
    name = "add" if add else "set"
    if args in (["-h"], ["--help"]): print(HELP[name]); return 0
    if args in (["-V"], ["--version"]): print(VERSION); return 0
    if len(args) < 2:
        missing = []
        if len(args) < 1: missing.append("    <mime>")
        if len(args) < 2: missing.append("    <handler>")
        return clap_error("The following required arguments were not provided:\n" + "\n".join(missing), USAGE[name])
    try:
        mime = validate_mime(args[0], USAGE[name])
    except ValueError as e:
        return invalid_value("<mime>", str(e), USAGE[name])
    apps = discover_desktops(); bad = validate_handler(args[1], apps, USAGE[name])
    if bad is not None: return bad
    defaults, added = read_mimeapps()
    if add:
        defaults.setdefault(mime, []).append(args[1])
    else:
        defaults[mime] = [args[1]]
    write_mimeapps(defaults, added)
    return 0


def cmd_unset(args):
    if args in (["-h"], ["--help"]): print(HELP["unset"]); return 0
    if args in (["-V"], ["--version"]): print(VERSION); return 0
    if not args:
        return clap_error("The following required arguments were not provided:\n    <mime>", USAGE["unset"])
    try:
        mime = validate_mime(args[0], USAGE["unset"])
    except ValueError as e:
        return invalid_value("<mime>", str(e), USAGE["unset"])
    defaults, added = read_mimeapps()
    defaults.pop(mime, None)
    write_mimeapps(defaults, added)
    return 0


def cmd_launch(args):
    if args in (["-h"], ["--help"]): print(HELP["launch"]); return 0
    if args in (["-V"], ["--version"]): print(VERSION); return 0
    if not args:
        return clap_error("The following required arguments were not provided:\n    <mime>", USAGE["launch"])
    mime_raw = args[0]
    rest = args[1:]
    if rest and rest[0] == "--": rest = rest[1:]
    try:
        mime = validate_mime(mime_raw, USAGE["launch"])
    except ValueError as e:
        return invalid_value("<mime>", str(e), USAGE["launch"])
    apps = discover_desktops(); h = find_handler(mime, apps)
    if not h or h not in apps: return 1
    cmd = expand_exec(apps[h].get("Exec", ""), rest, apps[h])
    if not cmd: return 1
    try:
        subprocess.Popen(cmd, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, stdin=subprocess.DEVNULL)
        return 0
    except Exception:
        return 1


def cmd_open(args):
    if args in (["-h"], ["--help"]): print(HELP["open"]); return 0
    if args in (["-V"], ["--version"]): print(VERSION); return 0
    if not args:
        return clap_error("The following required arguments were not provided:\n    <paths>...", USAGE["open"])
    apps = discover_desktops(); ok = True
    for p in args:
        mime = mime_for_path_or_url(p)
        h = find_handler(mime, apps)
        if not h or h not in apps:
            ok = False; continue
        cmd = expand_exec(apps[h].get("Exec", ""), [p], apps[h])
        try:
            subprocess.Popen(cmd, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, stdin=subprocess.DEVNULL)
        except Exception:
            ok = False
    return 0 if ok else 1


def main(argv):
    if len(argv) == 1:
        print(main_help()); return 0
    if argv[1] in ("-h", "--help"):
        print(main_help()); return 0
    if argv[1] in ("-V", "--version"):
        print(VERSION); return 0
    sub = argv[1]
    args = argv[2:]
    if sub == "list": return cmd_list(args)
    if sub == "get": return cmd_get(args)
    if sub == "set": return setlike(args, False)
    if sub == "add": return setlike(args, True)
    if sub == "unset": return cmd_unset(args)
    if sub == "launch": return cmd_launch(args)
    if sub == "open": return cmd_open(args)
    eprint(f"error: Found argument '{sub}' which wasn't expected, or isn't valid in this context\n")
    eprint(f"If you tried to supply `{sub}` as a PATTERN use `-- {sub}`\n")
    eprint("USAGE:\n    executable <SUBCOMMAND>\n")
    eprint("For more information try --help")
    return 2

if __name__ == "__main__":
    sys.exit(main(sys.argv))
