#!/usr/bin/env python3
import os
import stat
import sys

GREEN = "\033[32m"
CYAN = "\033[36m"
RESET = "\033[39m"

FORMATS = {"metric", "binary", "bytes", "gb", "gib", "mb", "mib"}


class Options:
    def __init__(self):
        self.fmt = "binary"
        self.apparent = False
        self.count_hard_links = False
        self.stay_fs = False
        self.ignore_dirs = ["/proc", "/dev", "/sys", "/run"]
        self.no_sort = False
        self.no_total = False
        self.stats = False
        self.seen = set()
        self.entries = 0
        self.smallest = None
        self.largest = None


def top_help(long=False):
    if long:
        print("""A tool to learn about disk usage, fast!

Usage: dua [FLAGS] [OPTIONS] [SUBCOMMAND] [INPUT]...

Commands:
  interactive  Launch the terminal user interface [aliases: i]
  aggregate    Aggregate the consumed space of one or more directories or files [aliases: a]
  completions  Generate shell completions
  help         Print this message or the help of the given subcommand(s)

Arguments:
  [INPUT]...  One or more input files or directories. If unset, we will use all entries in the current working directory

Options:
  -t, --threads <THREADS>          The amount of threads to use. Defaults to 0, indicating the amount of logical processors. Set to 1 to use only a single thread [default: 0]
  -f, --format <FORMAT>            The format with which to print byte counts [default: binary] [possible values: metric, binary, bytes, gb, gib, mb, mib]
  -A, --apparent-size              Display apparent size instead of disk usage
  -l, --count-hard-links           Count hard-linked files each time they are seen
  -x, --stay-on-filesystem         If set, we will not cross filesystems or traverse mount points
  -i, --ignore-dirs <IGNORE_DIRS>  One or more absolute directories to ignore. Note that these are not ignored if they are passed as input path [default: /proc /dev /sys /run]
      --log-file <LOG_FILE>        Write a log file with debug information, including panics
  -h, --help                       Print help (see more with '--help')
  -V, --version                    Print version""")
    else:
        print("""A tool to learn about disk usage, fast!

Usage: dua [FLAGS] [OPTIONS] [SUBCOMMAND] [INPUT]...

Commands:
  interactive  Launch the terminal user interface [aliases: i]
  aggregate    Aggregate the consumed space of one or more directories or files [aliases: a]
  completions  Generate shell completions
  help         Print this message or the help of the given subcommand(s)

Arguments:
  [INPUT]...
          One or more input files or directories. If unset, we will use all entries in the current working directory

Options:
  -t, --threads <THREADS>
          The amount of threads to use. Defaults to 0, indicating the amount of logical processors. Set to 1 to use only a single thread
          
          [default: 0]

  -f, --format <FORMAT>
          The format with which to print byte counts
          
          [default: binary]
          [possible values: metric, binary, bytes, gb, gib, mb, mib]

  -A, --apparent-size
          Display apparent size instead of disk usage

  -l, --count-hard-links
          Count hard-linked files each time they are seen

  -x, --stay-on-filesystem
          If set, we will not cross filesystems or traverse mount points

  -i, --ignore-dirs <IGNORE_DIRS>
          One or more absolute directories to ignore. Note that these are not ignored if they are passed as input path.
          
          Hence, they will only be ignored if they are eventually reached as part of the traversal.
          
          [default: /proc /dev /sys /run]

      --log-file <LOG_FILE>
          Write a log file with debug information, including panics

  -h, --help
          Print help (see a summary with '-h')

  -V, --version
          Print version""")


def aggregate_help():
    print("""Aggregate the consumed space of one or more directories or files

Usage: executable aggregate [OPTIONS] [INPUT]...

Arguments:
  [INPUT]...  One or more input files or directories. If unset, we will use all entries in the current working directory

Options:
      --stats     If set, print additional statistics about the file traversal to stderr
      --no-sort   If set, paths will be printed in their order of occurrence on the command-line. Otherwise they are sorted by their size in bytes, ascending
      --no-total  If set, no total column will be computed for multiple inputs
  -h, --help      Print help""")


def interactive_help():
    print("""Launch the terminal user interface

Usage: executable interactive [OPTIONS] [INPUT]...

Arguments:
  [INPUT]...  One or more input files or directories. If unset, we will use all entries in the current working directory

Options:
  -e, --no-entry-check  Do not check entries for presence when listing a directory to avoid slugging performance on slow filesystems
  -h, --help            Print help""")


def completions_help():
    print("""Generate shell completions

Usage: executable completions <SHELL>

Arguments:
  <SHELL>  The shell to generate a completions-script for [possible values: bash, elvish, fish, powershell, zsh]

Options:
  -h, --help  Print help""")


def die(msg, usage=None):
    print(msg, file=sys.stderr)
    if usage:
        print(file=sys.stderr)
        print(usage, file=sys.stderr)
    print(file=sys.stderr)
    print("For more information, try '--help'.", file=sys.stderr)
    sys.exit(2)


def invalid_format(value):
    print(f"error: invalid value '{value}' for '--format <FORMAT>'", file=sys.stderr)
    print("  [possible values: metric, binary, bytes, gb, gib, mb, mib]", file=sys.stderr)
    print(file=sys.stderr)
    print("For more information, try '--help'.", file=sys.stderr)
    sys.exit(2)


def unexpected(arg, sub="aggregate"):
    print(f"error: unexpected argument '{arg}' found", file=sys.stderr)
    print(file=sys.stderr)
    print(f"  tip: to pass '{arg}' as a value, use '-- {arg}'", file=sys.stderr)
    print(file=sys.stderr)
    print(f"Usage: executable {sub} [OPTIONS] [INPUT]...", file=sys.stderr)
    print(file=sys.stderr)
    print("For more information, try '--help'.", file=sys.stderr)
    sys.exit(2)


def parse(argv):
    opt = Options()
    i = 0
    cmd = None
    inputs = []
    while i < len(argv):
        a = argv[i]
        if a in ("aggregate", "a", "interactive", "i", "completions", "help"):
            cmd = a
            i += 1
            break
        if a in ("-h", "--help"):
            top_help(a == "-h")
            sys.exit(0)
        if a in ("-V", "--version"):
            print("dua 2.32.2")
            sys.exit(0)
        if a in ("-A", "--apparent-size"):
            opt.apparent = True
        elif a in ("-l", "--count-hard-links"):
            opt.count_hard_links = True
        elif a in ("-x", "--stay-on-filesystem"):
            opt.stay_fs = True
        elif a in ("-f", "--format"):
            i += 1
            if i >= len(argv):
                die("error: a value is required for '--format <FORMAT>' but none was supplied")
            if argv[i] not in FORMATS:
                invalid_format(argv[i])
            opt.fmt = argv[i]
        elif a.startswith("--format="):
            val = a.split("=", 1)[1]
            if val not in FORMATS:
                invalid_format(val)
            opt.fmt = val
        elif a in ("-t", "--threads", "-i", "--ignore-dirs", "--log-file"):
            i += 1
            if i >= len(argv):
                die(f"error: a value is required for '{a}' but none was supplied")
            if a in ("-i", "--ignore-dirs"):
                opt.ignore_dirs = argv[i].split()
        elif a.startswith("-") and a != "-":
            die(f"error: unexpected argument '{a}' found")
        else:
            inputs.append(a)
        i += 1
    rest = argv[i:]
    return opt, cmd, inputs + rest


def parse_aggregate(args, opt):
    inputs = []
    i = 0
    while i < len(args):
        a = args[i]
        if a in ("-h", "--help"):
            aggregate_help()
            sys.exit(0)
        if a == "--stats":
            opt.stats = True
        elif a == "--no-sort":
            opt.no_sort = True
        elif a == "--no-total":
            opt.no_total = True
        elif a.startswith("-") and a != "-":
            unexpected(a)
        else:
            inputs.append(a)
        i += 1
    return inputs


def size_of(st, opt):
    return st.st_size if opt.apparent else st.st_blocks * 512


def note_stat(size, opt):
    opt.entries += 1
    opt.smallest = size if opt.smallest is None else min(opt.smallest, size)
    opt.largest = size if opt.largest is None else max(opt.largest, size)


def usage(path, opt, root_dev=None, is_root=False):
    try:
        st = os.lstat(path)
    except OSError:
        return 0, 1, False
    mode = st.st_mode
    is_dir = stat.S_ISDIR(mode)
    if is_dir and opt.stay_fs and root_dev is not None and st.st_dev != root_dev:
        return 0, 0, True
    if is_dir and not is_root and os.path.abspath(path) in opt.ignore_dirs:
        return 0, 0, True
    size = size_of(st, opt)
    if stat.S_ISREG(mode) and not opt.count_hard_links and st.st_nlink > 1:
        key = (st.st_dev, st.st_ino)
        if key in opt.seen:
            size = 0
        else:
            opt.seen.add(key)
    note_stat(size, opt)
    errors = 0
    if is_dir:
        try:
            names = sorted(os.listdir(path))
        except OSError:
            return size, 1, True
        for name in names:
            child = os.path.join(path, name)
            csize, cerr, _ = usage(child, opt, st.st_dev if root_dev is None else root_dev, False)
            size += csize
            errors += cerr
    return size, errors, is_dir


def entry_label(path, display):
    return f"{CYAN}{display}{RESET}" if os.path.isdir(path) and not os.path.islink(path) else display


def fmt_size(n, fmt):
    if fmt == "bytes":
        return f"{n:10d} b"
    units = {
        "binary": (1024.0, ["B", "KiB", "MiB", "GiB", "TiB"]),
        "metric": (1000.0, ["B", "KB", "MB", "GB", "TB"]),
    }
    fixed = {"gb": (1000.0**3, "GB"), "gib": (1024.0**3, "GiB"), "mb": (1000.0**2, "MB"), "mib": (1024.0**2, "MiB")}
    if fmt in fixed:
        div, unit = fixed[fmt]
        return f"{n / div:9.2f} {unit}"
    base, suffixes = units[fmt]
    val = float(n)
    idx = 0
    while val >= base and idx < len(suffixes) - 1:
        val /= base
        idx += 1
    if idx == 0:
        gap = "  " if fmt == "metric" else "   "
        return f"{int(val):7d}{gap}{suffixes[idx]}"
    return f"{val:7.2f} {suffixes[idx]}"


def print_rows(rows, opt, total_errors=0):
    if not opt.no_sort:
        rows = sorted(enumerate(rows), key=lambda x: (x[1][0], x[0]))
        rows = [r for _, r in rows]
    total = 0
    for size, path, display, errors in rows:
        total += size
        suffix = f"  <{errors} IO Error{'s' if errors != 1 else ''}>" if errors else ""
        print(f"{GREEN}{fmt_size(size, opt.fmt)}{RESET} {entry_label(path, display)}{suffix}")
    if len(rows) > 1 and not opt.no_total:
        suffix = f"  <{total_errors} IO Error{'s' if total_errors != 1 else ''}>" if total_errors else ""
        print(f"{GREEN}{fmt_size(total, opt.fmt)}{RESET} total{suffix}")


def aggregate(inputs, opt):
    if not inputs:
        base = "."
        names = sorted(os.listdir(base))
        work = [(os.path.join(base, n), n) for n in names]
    elif len(inputs) == 1 and os.path.isdir(inputs[0]) and not os.path.islink(inputs[0]):
        base = inputs[0]
        try:
            names = sorted(os.listdir(base))
        except OSError:
            names = []
        work = [(os.path.join(base, n), n) for n in names]
    else:
        work = [(p, p) for p in inputs]
    rows = []
    total_errors = 0
    for path, display in work:
        size, errors, _ = usage(path, opt, None, True)
        rows.append((size, path, display, errors))
        total_errors += errors
    print_rows(rows, opt, total_errors)
    if opt.stats:
        smallest = 0 if opt.smallest is None else opt.smallest
        largest = 0 if opt.largest is None else opt.largest
        print(f"Statistics {{ entries_traversed: {opt.entries}, smallest_file_in_bytes: {smallest}, largest_file_in_bytes: {largest} }}", file=sys.stderr)
    return 1 if total_errors else 0


def completions(args):
    if not args or args[0] in ("-h", "--help"):
        completions_help()
        return 0
    shell = args[0]
    if shell not in {"bash", "elvish", "fish", "powershell", "zsh"}:
        die(f"error: invalid value '{shell}' for '<SHELL>'")
    print(f"# completion script for dua ({shell})")
    print("# This reimplementation provides the documented command surface.")
    return 0


def main():
    opt, cmd, collected = parse(sys.argv[1:])
    if cmd == "help":
        if collected and collected[0] in ("aggregate", "a"):
            aggregate_help()
        elif collected and collected[0] == "completions":
            completions_help()
        elif collected and collected[0] in ("interactive", "i"):
            interactive_help()
        else:
            top_help(False)
        return 0
    if cmd in ("interactive", "i"):
        if any(a in ("-h", "--help") for a in collected):
            interactive_help()
            return 0
        return aggregate([a for a in collected if a not in ("-e", "--no-entry-check")], opt)
    if cmd == "completions":
        return completions(collected)
    if cmd in ("aggregate", "a"):
        inputs = parse_aggregate(collected, opt)
    else:
        inputs = collected
    return aggregate(inputs, opt)


if __name__ == "__main__":
    sys.exit(main())
