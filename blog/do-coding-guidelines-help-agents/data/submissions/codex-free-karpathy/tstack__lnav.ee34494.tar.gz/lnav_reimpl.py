#!/usr/bin/env python3
import os
import re
import stat
import subprocess
import sys
from datetime import datetime

VERSION = "lnav 0.14.0-07efb63"


def help_text(argv0):
    return f"""usage: {argv0} [options] [logfile1 logfile2 ...]

A log file viewer for the terminal that indexes log messages to
make it easier to navigate through files quickly.

Key Bindings
  ?    View/leave the online help text.
  q    Quit the program.

Options
  -h         Print this message, then exit.
  -H         Display the internal help text.

  -I dir     An additional configuration directory.
  -W         Print warnings related to lnav's configuration.
  -u         Update formats installed from git repositories.
  -d file    Write debug messages to the given file.
  -V         Print version information.

  -S,--since Only index log content since this time.
  -U,--until Only index log content until this time.
  -r         Recursively load files from the given directory hierarchies.
  -R         Load older rotated log files as well.
  -c cmd     Execute a command after the files have been loaded.
  -f file    Execute the commands in the given file.
  -e cmd     Execute a shell command-line.
  -t         Treat data piped into standard in as a log file.
  -n         Run without the curses UI. (headless mode)
  -N         Do not open the default syslog file if no files are given.
  -q         Do not print informational messages.

Optional arguments
  logfileN   The log files, directories, or remote paths to view.
             If a directory is given, all of the files in the
             directory will be loaded.

Management-Mode Options
  -i         Install the given format files and exit.  Pass 'extra'
             to install the default set of third-party formats.
  -m         Switch to the management command-line mode.  This mode
             is used to work with lnav's configuration.

Examples
 • To load and follow the syslog file:
     $ lnav                                  

 • To load all of the files in /var/log:
     $ lnav /var/log                         

 • To watch the output of make:
     $ lnav -e 'make -j4'                    

Paths
 • This binary:
    🧭 {os.path.abspath(argv0)}
 • Format files are read from:
    📂 /etc/lnav
    📂 /usr/etc/lnav
 • Configuration, session, and format files are stored in:
    📂 {os.path.expanduser('~')}/.config/lnav

 • Local copies of remote files, files extracted from
   archives, execution output, and so on are stored in:
    📂 /tmp/lnav-user-{os.getuid()}-work

Documentation: https://docs.lnav.org
Contact
  💬 https://github.com/tstack/lnav/discussions
  📫 lnav@googlegroups.com
Version: {VERSION}
"""


def arg_error(reason, status):
    print("  error: invalid command-line arguments", file=sys.stderr)
    print(f" reason: {reason}", file=sys.stderr)
    return status


def tui_error():
    print("  error: unable to display interactive text UI", file=sys.stderr)
    print(" reason: stdout is not a TTY", file=sys.stderr)
    print(" = help: pass the -n option to run lnav in headless mode or don't redirect stdout", file=sys.stderr)
    return 1


def management_error():
    print("  error: expecting an operation to perform", file=sys.stderr)
    print(" = help: the available operations are:", file=sys.stderr)
    for line in [
        "          • apps: manage lnav apps",
        "          • config: perform operations on the lnav configuration",
        "          • format: perform operations on log file formats",
        "          • piper: perform operations on piper storage",
        "          • regex101: create and edit log message regular expressions using regex101.com",
        "          • crash: manage crash logs",
    ]:
        print(line, file=sys.stderr)
    return 1


def timestamp_line(line):
    return datetime.now().astimezone().strftime("%Y-%m-%dT%H:%M:%S.%f%z") + " " + line


def parse_time_prefix(line):
    m = re.match(r"^(\d{4})-(\d{2})-(\d{2})[T ](\d{2}):(\d{2}):(\d{2})", line)
    if m:
        return tuple(int(x) for x in m.groups())
    m = re.match(r"^(Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)\s+(\d{1,2})\s+(\d{2}):(\d{2}):(\d{2})", line)
    if m:
        mons = "Jan Feb Mar Apr May Jun Jul Aug Sep Oct Nov Dec".split()
        now = datetime.now()
        return (now.year, mons.index(m.group(1)) + 1, int(m.group(2)), int(m.group(3)), int(m.group(4)), int(m.group(5)))
    return None


def parse_cutoff(text):
    m = re.match(r"^(\d{4})-(\d{2})-(\d{2})(?:[T ](\d{2}):(\d{2})(?::(\d{2}))?)?", text or "")
    if not m:
        return None
    vals = [int(x) if x else 0 for x in m.groups()]
    if vals[3] == 0 and vals[4] == 0 and vals[5] == 0:
        return (vals[0], vals[1], vals[2], 0, 0, 0)
    return tuple(vals)


def collect_paths(paths, recursive):
    out = []
    for p in paths:
        if os.path.isdir(p):
            if recursive:
                for root, dirs, files in os.walk(p):
                    dirs.sort()
                    for name in sorted(files):
                        out.append(os.path.join(root, name))
            else:
                for name in sorted(os.listdir(p)):
                    fp = os.path.join(p, name)
                    if os.path.isfile(fp):
                        out.append(fp)
        else:
            out.append(p)
    return out


def read_file_lines(path):
    try:
        with open(path, "r", errors="replace") as f:
            return f.read().splitlines(True), None
    except OSError as e:
        return None, e


def command_file_error(cmd):
    print(f"  error: unknown command: “{cmd}”", file=sys.stderr)
    print(" = note: did you mean one of the following:", file=sys.stderr)
    for line in [
        "           export-session-to - Export the current lnav state to an executable lnav script file that contains the commands needed to restore the current session",
        "           external-access - Open a port to give remote access to this lnav instance",
        "           filter-expr - Set the filter expression",
        "           mark-expr - Set the bookmark expression",
        "           next-location - Move to the next position in the location history",
        "           next-mark - Move to the next bookmark of the given type in the current view",
        "           next-section - Move to the next section in the document",
        "           unix-time - Convert epoch time to a human-readable form",
        "           xopen - Use an external command to open the given file(s)",
    ]:
        print(line, file=sys.stderr)


def apply_commands(lines, commands):
    result = list(lines)
    for raw in commands:
        cmd = raw.strip()
        if not cmd:
            continue
        if cmd.startswith(":"):
            cmd = cmd[1:].strip()
        if cmd in ("quit", "q", "goto 0", "goto 1"):
            continue
        m = re.match(r"filter-in\s+(.+)", cmd)
        if m:
            pat = m.group(1).strip().strip("'\"")
            try:
                rx = re.compile(pat)
                result = [ln for ln in result if rx.search(ln)]
            except re.error:
                result = [ln for ln in result if pat in ln]
            continue
        m = re.match(r"filter-out\s+(.+)", cmd)
        if m:
            pat = m.group(1).strip().strip("'\"")
            try:
                rx = re.compile(pat)
                result = [ln for ln in result if not rx.search(ln)]
            except re.error:
                result = [ln for ln in result if pat not in ln]
            continue
        if cmd.startswith("write") or cmd.startswith("echo ") or cmd.startswith("comment "):
            continue
        command_file_error(cmd.split()[0] if cmd.split() else cmd)
    return result


def main(argv):
    args = argv[1:]
    opts = {
        "headless": False, "quiet": False, "stdin": False, "recursive": False,
        "commands": [], "cmd_files": [], "execs": [], "since": None, "until": None,
    }
    paths = []
    i = 0
    while i < len(args):
        a = args[i]
        if a == "--":
            paths.extend(args[i + 1:])
            break
        if a in ("-h", "--help"):
            sys.stdout.write(help_text(argv[0]))
            return 0
        if a in ("-V", "--version"):
            print(VERSION)
            return 0
        if a == "-m":
            return management_error()
        if a == "-i":
            if i + 1 >= len(args) or args[i + 1].startswith("-"):
                return arg_error("-i requires file", 107)
            return 0
        if a == "-C":
            return 0
        if a in ("-n",):
            opts["headless"] = True
        elif a == "-q":
            opts["quiet"] = True
        elif a == "-t":
            opts["stdin"] = True
        elif a == "-r":
            opts["recursive"] = True
        elif a in ("-R", "-N", "-W", "-u", "-H"):
            pass
        elif a in ("-I", "-d", "-c", "-f", "-e", "-S", "--since", "-U", "--until"):
            if i + 1 >= len(args) or args[i + 1].startswith("-"):
                names = {"-I": "-I: 1 required TEXT:DIR missing", "-d": "-d: 1 required FILE missing",
                         "-c": "-c: 1 required TEXT missing", "-f": "-f: 1 required FILE missing",
                         "-e": "-e: 1 required TEXT missing", "-S": "--since: 1 required TEXT missing",
                         "--since": "--since: 1 required TEXT missing", "-U": "--until: 1 required TEXT missing",
                         "--until": "--until: 1 required TEXT missing"}
                return arg_error(names[a], 114)
            val = args[i + 1]
            if a == "-c":
                opts["commands"].append(val)
            elif a == "-f":
                opts["cmd_files"].append(val)
            elif a == "-e":
                opts["execs"].append(val)
            elif a in ("-S", "--since"):
                opts["since"] = parse_cutoff(val)
            elif a in ("-U", "--until"):
                opts["until"] = parse_cutoff(val)
            i += 1
        elif a.startswith("-"):
            return arg_error(f"The following argument was not expected: {a}", 109)
        else:
            paths.append(a)
        i += 1

    if not opts["headless"] and not sys.stdout.isatty():
        if paths:
            for p in paths:
                if not os.path.exists(p):
                    print(f"  error: unable to open file: {p}", file=sys.stderr)
                    print(" reason: No such file or directory", file=sys.stderr)
        return tui_error()

    all_lines = []
    status = 0

    for cmd in opts["execs"]:
        proc = subprocess.run(cmd, shell=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, errors="replace")
        all_lines.extend(proc.stdout.splitlines(True))

    if opts["stdin"] or (opts["headless"] and not paths and not opts["execs"] and not sys.stdin.isatty()):
        for line in sys.stdin:
            all_lines.append(timestamp_line(line) if opts["stdin"] else line)

    for p in collect_paths(paths, opts["recursive"]):
        lines, err = read_file_lines(p)
        if err:
            print(f"  error: unable to open file: {p}", file=sys.stderr)
            print(f" reason: {err.strerror}", file=sys.stderr)
            status = 1
            continue
        all_lines.extend(lines)

    dated = []
    undated = []
    for idx, line in enumerate(all_lines):
        key = parse_time_prefix(line)
        if opts["since"] and key and key < opts["since"]:
            continue
        if opts["until"] and key and key > opts["until"]:
            continue
        (dated if key else undated).append((key, idx, line))
    if dated:
        dated.sort(key=lambda x: (x[0], x[1]))
        all_lines = [x[2] for x in dated] + [x[2] for x in undated]
    else:
        all_lines = [x[2] for x in undated]

    for cf in opts["cmd_files"]:
        try:
            with open(cf, "r", errors="replace") as f:
                opts["commands"].extend(f.read().splitlines())
        except OSError as e:
            print(f"  error: unable to open file: {cf}", file=sys.stderr)
            print(f" reason: {e.strerror}", file=sys.stderr)
            status = 1

    all_lines = apply_commands(all_lines, opts["commands"])

    if not opts["quiet"]:
        sys.stdout.writelines(all_lines)
    return status


if __name__ == "__main__":
    sys.exit(main(sys.argv))
