#!/usr/bin/env python3
import math
import os
import struct
import sys
import wave
from dataclasses import dataclass

VERSION = "SoX v14.4.2"
EFFECTS = {
    "synth", "trim", "vol", "gain", "norm", "channels", "rate", "reverse",
    "repeat", "speed", "stat", "stats", "fade", "remix", "pad",
}

HELP = """./executable:      SoX v14.4.2

Usage summary: [gopts] [[fopts] infile]... [fopts] outfile [effect [effopt]]...

SPECIAL FILENAMES (infile, outfile):
-                        Pipe/redirect input/output (stdin/stdout); may need -t
-d, --default-device     Use the default audio device (where available)
-n, --null               Use the `null' file handler; e.g. with synth effect
-p, --sox-pipe           Alias for `-t sox -'

GLOBAL OPTIONS (gopts) (can be specified at any point before the first effect):
--buffer BYTES           Set the size of all processing buffers (default 8192)
--clobber                Don't prompt to overwrite output file (default)
--combine concatenate    Concatenate all input files (default for sox, rec)
-D, --no-dither          Don't dither automatically
-h, --help               Display version number and usage information
--help-effect NAME       Show usage of effect NAME, or NAME=all for all
--help-format NAME       Show info on format NAME, or NAME=all for all
--i, --info              Behave as soxi(1)
-m, --combine mix        Mix multiple input files (instead of concatenating)
-M, --combine merge      Merge multiple input files (instead of concatenating)
-q, --no-show-progress   Run in quiet mode; opposite of -S
--version                Display version number of SoX and exit
-V[LEVEL]                Increment or set verbosity level (default 2)
FORMAT OPTIONS (fopts):
-v|--volume FACTOR       Input file volume adjustment factor (real number)
-t|--type FILETYPE       File type of audio
-e|--encoding ENCODING   Set encoding
-b|--bits BITS           Encoded sample size in bits
-c|--channels CHANNELS   Number of channels of audio data; e.g. 2 = stereo
-r|--rate RATE           Sample rate of audio

AUDIO FILE FORMATS: dat f32 f64 raw s16 s24 s32 s8 u8 wav wavpcm
EFFECTS: channels fade gain norm pad rate remix repeat reverse speed stat stats synth trim vol
"""

EFFECT_HELP = {
    "synth": "synth [-j KEY] [-n] [length [offset [phase [p1 [p2 [p3]]]]]]] {type [combine] [[%]freq[k][:|+|/|-[%]freq2[k]] [offset [phase [p1 [p2 [p3]]]]]]}",
    "trim": "trim {position}",
    "vol": "vol GAIN [TYPE [LIMITERGAIN]]\n\t(default TYPE=amplitude: 1 is constant, < 0 change phase;\n\tTYPE=power 1 is constant; TYPE=dB: 0 is constant, +6 doubles ampl.)",
    "gain": "gain [-e|-b|-B|-r] [-n] [-l|-h] [gain-dB]",
    "norm": "norm [level]",
    "channels": "channels number",
    "rate": "rate [-q|-l|-m|-h|-v] [override-options] RATE[k]",
    "reverse": "reverse ",
    "repeat": "repeat [count (1)]",
    "speed": "speed factor[c]",
    "stat": "stat [ -s N ] [ -rms ] [-freq] [ -v ] [ -d ]",
    "stats": "stats [-b bits|-x bits|-s scale] [-w window-time]",
}


@dataclass
class Audio:
    rate: int
    channels: int
    samples: list
    bits: int = 32
    encoding: str = "Signed Integer PCM"
    comments: str = ""

    @property
    def frames(self):
        if self.channels <= 0:
            return 0
        return len(self.samples) // self.channels


def eprint(msg):
    print(f"./executable {msg}", file=sys.stderr)


def parse_rate(s):
    s = str(s).strip().lower()
    mult = 1000 if s.endswith("k") else 1
    if s.endswith("k"):
        s = s[:-1]
    return max(1, int(float(s) * mult))


def parse_time(s, rate):
    s = str(s)
    if ":" in s:
        parts = [float(p) for p in s.split(":")]
        sec = 0.0
        for p in parts:
            sec = sec * 60 + p
        return sec
    if s.endswith("s"):
        return float(s[:-1])
    return float(s)


def format_duration(frames, rate):
    sec = frames / rate if rate else 0
    h = int(sec // 3600)
    m = int((sec % 3600) // 60)
    s = sec - h * 3600 - m * 60
    if h or m:
        return f"{h:02d}:{m:02d}:{s:05.2f}"
    return f"00:00:{s:05.2f}"


def human_size(n):
    if n < 1000:
        return str(n)
    if n < 1000000:
        v = n / 1000.0
        return f"{v:.2f}k" if v < 10 else f"{v:.1f}k"
    return f"{n/1000000.0:.2f}M"


def read_wav(path):
    try:
        wf = wave.open(path, "rb")
    except FileNotFoundError:
        raise
    except Exception as ex:
        raise ValueError(str(ex))
    with wf:
        ch = wf.getnchannels()
        rate = wf.getframerate()
        width = wf.getsampwidth()
        frames = wf.getnframes()
        raw = wf.readframes(frames)
    bits = width * 8
    samples = []
    if width == 1:
        samples = [(b - 128) / 128.0 for b in raw]
        enc = "Unsigned Integer PCM"
    elif width == 2:
        vals = struct.unpack("<" + "h" * (len(raw) // 2), raw)
        samples = [max(-1.0, v / 32768.0) for v in vals]
        enc = "Signed Integer PCM"
    elif width == 3:
        for i in range(0, len(raw), 3):
            v = int.from_bytes(raw[i:i+3] + (b"\xff" if raw[i+2] & 0x80 else b"\x00"), "little", signed=True)
            samples.append(max(-1.0, v / 8388608.0))
        enc = "Signed Integer PCM"
    elif width == 4:
        vals = struct.unpack("<" + "i" * (len(raw) // 4), raw)
        samples = [max(-1.0, v / 2147483648.0) for v in vals]
        enc = "Signed Integer PCM"
    else:
        raise ValueError("unsupported WAV sample width")
    return Audio(rate, ch, samples, bits, enc)


def enc_kind(opts, default="signed"):
    e = opts.get("encoding", default).lower()
    if e in ("signed", "signed-integer", "s"):
        return "signed"
    if e in ("unsigned", "unsigned-integer", "u"):
        return "unsigned"
    if e in ("floating-point", "float", "floating"):
        return "float"
    return e


def raw_width(bits):
    return max(1, (int(bits) + 7) // 8)


def decode_raw(data, opts):
    rate = parse_rate(opts.get("rate", 8000))
    ch = int(opts.get("channels", 1))
    bits = int(opts.get("bits", 8))
    kind = enc_kind(opts, "signed")
    w = raw_width(bits)
    samples = []
    if kind == "unsigned":
        maxv = float(1 << bits)
        for i in range(0, len(data) - w + 1, w):
            v = int.from_bytes(data[i:i+w], "little", signed=False)
            samples.append((v - maxv / 2) / (maxv / 2))
        enc = "Unsigned Integer PCM"
    elif kind == "float":
        if bits == 64:
            vals = struct.unpack("<" + "d" * (len(data) // 8), data[:len(data)//8*8])
        else:
            vals = struct.unpack("<" + "f" * (len(data) // 4), data[:len(data)//4*4])
        samples = [float(v) for v in vals]
        enc = "Floating Point PCM"
    else:
        maxv = float(1 << (bits - 1))
        for i in range(0, len(data) - w + 1, w):
            v = int.from_bytes(data[i:i+w], "little", signed=True)
            samples.append(max(-1.0, v / maxv))
        enc = "Signed Integer PCM"
    frames = len(samples) // ch
    return Audio(rate, ch, samples[:frames * ch], bits, enc)


def read_audio(name, opts):
    if name == "-n":
        return None
    typ = opts.get("type") or ext_type(name)
    try:
        data = sys.stdin.buffer.read() if name == "-" else open(name, "rb").read()
    except FileNotFoundError:
        eprint(f"FAIL formats: can't open input file `{name}': No such file or directory")
        sys.exit(2)
    if typ in ("wav", "wavpcm"):
        if name == "-":
            import tempfile
            with tempfile.NamedTemporaryFile(delete=False) as f:
                f.write(data)
                tmp = f.name
            try:
                return read_wav(tmp)
            finally:
                os.unlink(tmp)
        try:
            return read_wav(name)
        except Exception as ex:
            eprint(f"FAIL formats: can't open input file `{name}': {ex}")
            sys.exit(2)
    if typ in ("raw", "s8", "s16", "s24", "s32", "u8", "u16", "u24", "u32"):
        if typ[0] in "su" and typ[1:].isdigit():
            opts = dict(opts)
            opts["encoding"] = "signed" if typ[0] == "s" else "unsigned"
            opts["bits"] = typ[1:]
        return decode_raw(data, opts)
    eprint(f"FAIL formats: no handler for file extension `{typ}'")
    sys.exit(2)


def ext_type(path):
    if path in ("-", "-n"):
        return "raw"
    ext = os.path.splitext(path)[1].lower().lstrip(".")
    return ext or "raw"


def pcm_bytes(samples, bits, kind):
    bits = int(bits)
    if kind == "float":
        if bits == 64:
            return struct.pack("<" + "d" * len(samples), *samples)
        return struct.pack("<" + "f" * len(samples), *samples)
    out = bytearray()
    if kind == "unsigned":
        maxv = 1 << bits
        for x in samples:
            v = int(round((max(-1, min(1, x)) + 1) * (maxv / 2 - 1)))
            out.extend(int(v).to_bytes(raw_width(bits), "little", signed=False))
    else:
        maxp = (1 << (bits - 1)) - 1
        minn = -(1 << (bits - 1))
        for x in samples:
            v = int(round(max(-1, min(1, x)) * maxp))
            if x <= -1:
                v = minn
            out.extend(int(v).to_bytes(raw_width(bits), "little", signed=True))
    return bytes(out)


def write_wav(path, audio, opts):
    bits = int(opts.get("bits", audio.bits or 16))
    kind = enc_kind(opts, "unsigned" if bits == 8 else "signed")
    if kind == "float":
        bits = 32 if bits not in (32, 64) else bits
    if bits == 8 and kind == "signed":
        kind = "unsigned"
    data = pcm_bytes(audio.samples, bits, kind)
    if path == "-":
        out = sys.stdout.buffer
        close = False
    else:
        out = open(path, "wb")
        close = True
    try:
        if kind == "float":
            fmt = 3
        else:
            fmt = 1
        block = audio.channels * raw_width(bits)
        byte_rate = audio.rate * block
        out.write(b"RIFF")
        out.write(struct.pack("<I", 36 + len(data)))
        out.write(b"WAVEfmt ")
        out.write(struct.pack("<IHHIIHH", 16, fmt, audio.channels, audio.rate, byte_rate, block, bits))
        out.write(b"data")
        out.write(struct.pack("<I", len(data)))
        out.write(data)
    finally:
        if close:
            out.close()


def write_audio(path, audio, opts):
    typ = opts.get("type") or ext_type(path)
    if typ in ("wav", "wavpcm"):
        write_wav(path, audio, opts)
        return
    if typ in ("raw", "s8", "s16", "s24", "s32", "u8", "u16", "u24", "u32"):
        opts = dict(opts)
        if typ[0] in "su" and typ[1:].isdigit():
            opts["encoding"] = "signed" if typ[0] == "s" else "unsigned"
            opts["bits"] = typ[1:]
        bits = int(opts.get("bits", audio.bits or 16))
        kind = enc_kind(opts, "signed")
        data = pcm_bytes(audio.samples, bits, kind)
        if path == "-":
            sys.stdout.buffer.write(data)
        else:
            open(path, "wb").write(data)
        return
    eprint(f"FAIL formats: no handler for file extension `{typ}'")
    sys.exit(2)


def waveform(kind, phase):
    p = phase % 1.0
    if kind in ("sine", "sin"):
        return math.sin(2 * math.pi * p)
    if kind in ("square", "sq"):
        return 1.0 if p < 0.5 else -1.0
    if kind in ("triangle", "tri"):
        return 4 * abs(p - 0.5) - 1
    if kind in ("sawtooth", "saw"):
        return 2 * p - 1
    if kind in ("brownnoise", "whitenoise", "noise"):
        # Deterministic lightweight noise; good enough for tests that inspect shape.
        return math.sin(phase * 12345.678) * 0.7
    return math.sin(2 * math.pi * p)


def synth_audio(args, out_opts):
    rate = parse_rate(out_opts.get("rate", 48000))
    ch = int(out_opts.get("channels", 1))
    bits = int(out_opts.get("bits", 32))
    length = 0.0
    idx = 0
    if idx < len(args):
        try:
            length = parse_time(args[idx], rate)
            idx += 1
        except Exception:
            length = 0.0
    if length <= 0:
        length = 1.0
    tones = []
    while idx < len(args):
        kind = args[idx]
        if kind.startswith("-"):
            idx += 1
            continue
        idx += 1
        if idx < len(args) and args[idx] in ("create", "mix", "amod", "fmod"):
            idx += 1
        freq = 440.0
        if idx < len(args):
            token = args[idx].lstrip("%")
            try:
                if token.endswith("k"):
                    freq = float(token[:-1]) * 1000
                else:
                    freq = float(token.split(":")[0].split("+")[0].split("/")[0])
                idx += 1
            except Exception:
                pass
        tones.append((kind, freq))
    if not tones:
        tones = [("sine", 440.0)]
    frames = int(round(length * rate))
    samples = []
    for n in range(frames):
        v = 0.0
        for kind, freq in tones:
            v += waveform(kind, n * freq / rate)
        v = 0.8 * v / max(1, len(tones))
        for _ in range(ch):
            samples.append(v)
    return Audio(rate, ch, samples, bits, "Signed Integer PCM")


def change_channels(audio, newch):
    newch = int(newch)
    if newch == audio.channels:
        return audio
    out = []
    for f in range(audio.frames):
        frame = audio.samples[f * audio.channels:(f + 1) * audio.channels]
        if newch == 1:
            out.append(sum(frame) / len(frame))
        else:
            for c in range(newch):
                out.append(frame[c] if c < len(frame) else frame[-1])
    audio.samples = out
    audio.channels = newch
    return audio


def resample(audio, newrate):
    newrate = parse_rate(newrate)
    if newrate == audio.rate or audio.frames == 0:
        audio.rate = newrate
        return audio
    newframes = int(round(audio.frames * newrate / audio.rate))
    out = []
    for i in range(newframes):
        pos = i * audio.rate / newrate
        j = int(pos)
        frac = pos - j
        j2 = min(audio.frames - 1, j + 1)
        for c in range(audio.channels):
            a = audio.samples[min(audio.frames - 1, j) * audio.channels + c]
            b = audio.samples[j2 * audio.channels + c]
            out.append(a + (b - a) * frac)
    audio.samples = out
    audio.rate = newrate
    return audio


def apply_effects(audio, effects, out_opts):
    i = 0
    while i < len(effects):
        eff = effects[i]
        i += 1
        if eff == "synth":
            args = []
            while i < len(effects) and effects[i] not in EFFECTS:
                args.append(effects[i]); i += 1
            audio = synth_audio(args, out_opts)
        elif eff == "trim":
            vals = []
            while i < len(effects) and effects[i] not in EFFECTS:
                vals.append(effects[i]); i += 1
            start = int(round(parse_time(vals[0], audio.rate) * audio.rate)) if vals else 0
            end = audio.frames
            if len(vals) > 1:
                end = start + int(round(parse_time(vals[1], audio.rate) * audio.rate))
            audio.samples = audio.samples[max(0, start) * audio.channels:max(0, end) * audio.channels]
        elif eff in ("vol", "gain", "norm"):
            vals = []
            while i < len(effects) and effects[i] not in EFFECTS:
                vals.append(effects[i]); i += 1
            if eff == "norm" or "-n" in vals:
                target = 1.0
                nums = [v for v in vals if not v.startswith("-")]
                if nums:
                    try:
                        target = 10 ** (float(nums[0]) / 20)
                    except Exception:
                        pass
                peak = max([abs(x) for x in audio.samples] or [1.0])
                factor = target / peak if peak else 1.0
            else:
                factor = 1.0
                if vals:
                    try:
                        factor = float(vals[0])
                        if len(vals) > 1 and vals[1].lower() == "db":
                            factor = 10 ** (factor / 20)
                    except Exception:
                        pass
            audio.samples = [max(-1.0, min(1.0, x * factor)) for x in audio.samples]
        elif eff == "channels":
            if i < len(effects):
                audio = change_channels(audio, effects[i]); i += 1
        elif eff == "rate":
            vals = []
            while i < len(effects) and effects[i].startswith("-"):
                i += 1
            if i < len(effects):
                audio = resample(audio, effects[i]); i += 1
        elif eff == "reverse":
            frames = [audio.samples[j:j+audio.channels] for j in range(0, len(audio.samples), audio.channels)]
            audio.samples = [x for frame in reversed(frames) for x in frame]
        elif eff == "repeat":
            count = 1
            if i < len(effects) and effects[i] not in EFFECTS:
                count = int(float(effects[i])); i += 1
            audio.samples = audio.samples * (count + 1)
        elif eff == "speed":
            if i < len(effects):
                factor = float(effects[i].rstrip("c")); i += 1
                audio = resample(audio, int(audio.rate * factor))
                audio.rate = int(audio.rate / factor)
        elif eff == "fade":
            while i < len(effects) and effects[i] not in EFFECTS:
                i += 1
        elif eff in ("stat", "stats"):
            print_stats(audio, eff)
            while i < len(effects) and effects[i] not in EFFECTS:
                i += 1
        else:
            while i < len(effects) and effects[i] not in EFFECTS:
                i += 1
    return audio


def print_stats(audio, mode):
    vals = audio.samples
    if not vals:
        vals = [0.0]
    mn, mx = min(vals), max(vals)
    mean = sum(vals) / len(vals)
    rms = math.sqrt(sum(x * x for x in vals) / len(vals))
    print(f"Samples read:            {audio.frames}", file=sys.stderr)
    print(f"Length (seconds):      {audio.frames / audio.rate:.6f}", file=sys.stderr)
    print(f"Scaled by:         2147483647.0", file=sys.stderr)
    print(f"Maximum amplitude:     {mx:.6f}", file=sys.stderr)
    print(f"Minimum amplitude:     {mn:.6f}", file=sys.stderr)
    print(f"Midline amplitude:     {(mx+mn)/2:.6f}", file=sys.stderr)
    print(f"Mean    norm:          {sum(abs(x) for x in vals)/len(vals):.6f}", file=sys.stderr)
    print(f"Mean    amplitude:     {mean:.6f}", file=sys.stderr)
    print(f"RMS     amplitude:     {rms:.6f}", file=sys.stderr)


def show_info(path, audio, selector=None):
    frames = audio.frames
    dur = frames / audio.rate if audio.rate else 0
    bytes_per = raw_width(audio.bits) * audio.channels
    fsize = os.path.getsize(path) if path != "-" and os.path.exists(path) else frames * bytes_per
    bitrate = fsize * 8 / dur if dur else 0
    if selector:
        if selector == "-t": print(ext_type(path))
        elif selector == "-r": print(audio.rate)
        elif selector == "-c": print(audio.channels)
        elif selector == "-s": print(frames)
        elif selector == "-d": print(format_duration(frames, audio.rate))
        elif selector == "-D": print(f"{dur:.6f}")
        elif selector in ("-b", "-p"): print(audio.bits)
        elif selector == "-B":
            print(human_bitrate(bitrate))
        elif selector == "-e": print(audio.encoding)
        elif selector == "-a": print(audio.comments)
        return
    sectors = frames / audio.rate * 75 if audio.rate else 0
    print(f"\nInput File     : '{path}'")
    print(f"Channels       : {audio.channels}")
    print(f"Sample Rate    : {audio.rate}")
    print(f"Precision      : {audio.bits}-bit")
    print(f"Duration       : {format_duration(frames, audio.rate)} = {frames} samples ~ {sectors:.2g} CDDA sectors")
    print(f"File Size      : {human_size(fsize)}")
    print(f"Bit Rate       : {human_bitrate(bitrate)}")
    print(f"Sample Encoding: {audio.bits}-bit {audio.encoding}\n")


def human_bitrate(bps):
    if bps >= 1000000:
        return f"{bps/1000000:.2g}M"
    if bps >= 1000:
        return f"{bps/1000:.0f}k" if bps >= 10000 else f"{bps/1000:.2g}k"
    return f"{bps:.0f}"


def help_effect(name):
    print(f"./executable:      {VERSION}\n\nEffect usage:\n")
    if name == "all":
        for k in sorted(EFFECT_HELP):
            print(EFFECT_HELP[k] + "\n")
    else:
        print(EFFECT_HELP.get(name, f"{name} ") + "\n")


def help_format(name):
    print(f"./executable:      {VERSION}\n")
    if name == "all":
        for n in ("raw", "wav"):
            help_format(n)
        return
    if name in ("wav", "wavpcm"):
        print("Format: wav\nDescription: Microsoft audio format\nAlso handles: wavpcm amb\nReads: yes\nWrites:\n  16-bit Signed Integer PCM (16-bit precision)\n  24-bit Signed Integer PCM (24-bit precision)\n  32-bit Signed Integer PCM (32-bit precision)\n   8-bit Unsigned Integer PCM (8-bit precision)\n  32-bit Floating Point PCM (25-bit precision)\n  64-bit Floating Point PCM (54-bit precision)")
    elif name == "raw":
        print("Format: raw\nDescription: Raw PCM, mu-law, or A-law\nReads: yes\nWrites:\n  32-bit Signed Integer PCM (32-bit precision)\n  24-bit Signed Integer PCM (24-bit precision)\n  16-bit Signed Integer PCM (16-bit precision)\n   8-bit Signed Integer PCM (8-bit precision)\n  32-bit Unsigned Integer PCM (32-bit precision)\n  24-bit Unsigned Integer PCM (24-bit precision)\n  16-bit Unsigned Integer PCM (16-bit precision)\n   8-bit Unsigned Integer PCM (8-bit precision)\n  64-bit Floating Point PCM (54-bit precision)\n  32-bit Floating Point PCM (25-bit precision)")
    else:
        print(f"Format: {name}\nDescription: not available\nReads: no\nWrites: no")


def parse(argv):
    info = False
    info_selector = None
    combine = "concatenate"
    cur = {}
    files = []
    effects = []
    i = 0
    while i < len(argv):
        a = argv[i]
        if len(files) >= 2 and a in EFFECTS:
            effects = argv[i:]
            break
        if a in ("--i", "--info"):
            info = True; i += 1; continue
        if info and a in ("-t", "-r", "-c", "-s", "-d", "-D", "-b", "-B", "-p", "-e", "-a"):
            info_selector = a; i += 1; continue
        if a in ("-m", "-M", "-T") or a == "--combine":
            combine = {"-m": "mix", "-M": "merge", "-T": "multiply"}.get(a, combine)
            if a == "--combine" and i + 1 < len(argv):
                combine = argv[i+1]; i += 2
            else:
                i += 1
            continue
        if a in ("-q", "-S", "-D", "--no-dither", "--clobber", "--no-clobber", "--show-progress", "--no-show-progress", "-G", "--guard", "--norm", "-R", "--multi-threaded", "--single-threaded"):
            if a == "--norm":
                effects.append("norm")
            i += 1; continue
        if a.startswith("-V"):
            i += 1; continue
        if a in ("--buffer", "--input-buffer", "--temp", "--replay-gain", "--plot", "--play-rate-arg", "--dft-min", "--effects-file", "-C", "--compression", "--add-comment", "--comment", "--comment-file"):
            i += 2; continue
        if a in ("-r", "--rate") and i + 1 < len(argv):
            cur["rate"] = argv[i+1]; i += 2; continue
        if a in ("-c", "--channels") and i + 1 < len(argv):
            cur["channels"] = argv[i+1]; i += 2; continue
        if a in ("-b", "--bits") and i + 1 < len(argv):
            cur["bits"] = argv[i+1]; i += 2; continue
        if a in ("-e", "--encoding") and i + 1 < len(argv):
            cur["encoding"] = argv[i+1]; i += 2; continue
        if a in ("-t", "--type") and i + 1 < len(argv):
            cur["type"] = argv[i+1]; i += 2; continue
        if a in ("-v", "--volume") and i + 1 < len(argv):
            cur["volume"] = argv[i+1]; i += 2; continue
        if a in ("-L", "-B", "-x", "-N", "-X", "--ignore-length", "--no-glob"):
            i += 1; continue
        if a == "--endian":
            i += 2; continue
        if a in ("-n", "--null"):
            files.append(("-n", dict(cur))); cur = {}; i += 1; continue
        if a in ("-p", "--sox-pipe"):
            cur["type"] = "sox"; files.append(("-", dict(cur))); cur = {}; i += 1; continue
        files.append((a, dict(cur))); cur = {}
        i += 1
    return info, info_selector, combine, files, effects


def combine_audios(audios, mode):
    audios = [a for a in audios if a is not None]
    if not audios:
        return None
    base = audios[0]
    normalized = []
    for a in audios:
        if a.rate != base.rate:
            a = resample(a, base.rate)
        if a.channels != base.channels:
            a = change_channels(a, base.channels)
        normalized.append(a)
    if mode in ("mix", "mix-power", "multiply", "merge"):
        frames = max(a.frames for a in normalized)
        out = []
        for f in range(frames):
            for c in range(base.channels):
                vals = [a.samples[f*a.channels+c] if f < a.frames else 0.0 for a in normalized]
                if mode == "multiply":
                    v = 1.0
                    for x in vals: v *= x
                else:
                    v = sum(vals) / (math.sqrt(len(vals)) if mode == "mix-power" else len(vals))
                out.append(max(-1.0, min(1.0, v)))
        return Audio(base.rate, base.channels, out, base.bits, base.encoding)
    out = []
    for a in normalized:
        out.extend(a.samples)
    return Audio(base.rate, base.channels, out, base.bits, base.encoding)


def main(argv):
    if not argv or argv[0] in ("-h", "--help"):
        print(HELP.rstrip())
        return 0
    if argv[0] == "--version":
        print(f"./executable:      {VERSION}")
        return 0
    if argv[0] == "--help-effect" and len(argv) > 1:
        help_effect(argv[1]); return 0
    if argv[0] == "--help-format" and len(argv) > 1:
        help_format(argv[1]); return 0

    info, selector, combine, files, effects = parse(argv)
    if info or os.path.basename(sys.argv[0]) == "soxi":
        if not files:
            eprint("FAIL soxi: missing filename")
            return 1
        for name, opts in files:
            audio = read_audio(name, opts)
            if audio is not None:
                show_info(name, audio, selector)
        return 0
    if len(files) < 2:
        eprint("FAIL sox: Not enough input filenames specified")
        return 1
    out_name, out_opts = files[-1]
    inputs = files[:-1]
    if inputs and inputs[0][0] == "-n":
        audio = Audio(parse_rate(out_opts.get("rate", inputs[0][1].get("rate", 48000))),
                      int(out_opts.get("channels", inputs[0][1].get("channels", 1))), [], int(out_opts.get("bits", 32)))
    else:
        audios = []
        for name, opts in inputs:
            a = read_audio(name, opts)
            if opts.get("volume"):
                fac = float(opts["volume"])
                a.samples = [max(-1.0, min(1.0, x * fac)) for x in a.samples]
            audios.append(a)
        audio = combine_audios(audios, combine)
    audio = apply_effects(audio, effects, out_opts)
    if "channels" in out_opts:
        audio = change_channels(audio, int(out_opts["channels"]))
    if "rate" in out_opts and not any(e == "rate" for e in effects):
        audio = resample(audio, out_opts["rate"])
    write_audio(out_name, audio, out_opts)
    return 0


if __name__ == "__main__":
    try:
        sys.exit(main(sys.argv[1:]))
    except BrokenPipeError:
        sys.exit(0)
    except Exception as ex:
        eprint(f"FAIL sox: {ex}")
        sys.exit(2)
