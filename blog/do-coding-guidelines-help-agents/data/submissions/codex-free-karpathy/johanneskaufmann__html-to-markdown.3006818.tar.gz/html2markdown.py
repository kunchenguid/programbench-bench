#!/usr/bin/env python3
import argparse
import glob
import os
import re
import sys
from html.parser import HTMLParser
from urllib.parse import urljoin


class Node:
    def __init__(self, tag=None, attrs=None, text=None):
        self.tag = tag
        self.attrs = dict(attrs or [])
        self.text = text
        self.children = []


class Parser(HTMLParser):
    VOID = {"area", "base", "br", "col", "embed", "hr", "img", "input", "link", "meta", "param", "source", "track", "wbr"}

    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.root = Node("root")
        self.stack = [self.root]

    def handle_starttag(self, tag, attrs):
        tag = tag.lower()
        n = Node(tag, attrs)
        self.stack[-1].children.append(n)
        if tag not in self.VOID:
            self.stack.append(n)

    def handle_startendtag(self, tag, attrs):
        self.handle_starttag(tag, attrs)

    def handle_endtag(self, tag):
        tag = tag.lower()
        for i in range(len(self.stack) - 1, 0, -1):
            if self.stack[i].tag == tag:
                del self.stack[i:]
                return

    def handle_data(self, data):
        if data:
            self.stack[-1].children.append(Node(text=data))


def is_ws(s):
    return not s or s.isspace()


def collapse_ws(s):
    return re.sub(r"[ \t\r\n\f]+", " ", s)


def esc_text(s):
    s = s.replace("\r", "")
    s = s.replace("\\", "\\\\")
    s = s.replace("<", "&lt;").replace(">", "&gt;")
    s = s.replace("`", "\\`").replace("[", "\\[")
    out = []
    for i, ch in enumerate(s):
        prev = s[i - 1] if i else ""
        nxt = s[i + 1] if i + 1 < len(s) else ""
        if ch in "*_" and (nxt and not nxt.isspace()):
            out.append("\\" + ch)
        else:
            out.append(ch)
    s = "".join(out)
    s = re.sub(r"(?m)^([ \t]*)(#{1,6})([ \t]+)", r"\1\\\2\3", s)
    s = re.sub(r"(?m)^([ \t]*)([-+*])([ \t]+)", r"\1\\\2\3", s)
    s = re.sub(r"(?m)^([ \t]*)([-=])([ \t]*)$", r"\1\\\2\3", s)
    s = re.sub(r"(?m)^([ \t]*\d+)\\.([ \t]+)", r"\1\\.\2", s)
    return s


def esc_url(s):
    return (s or "").replace(" ", "%20").replace(")", "%29")


def esc_alt(s):
    return re.sub(r"\s+", " ", plain_text(s)).replace("[", "\\[").replace("]", "\\]")


def plain_text(obj):
    if isinstance(obj, str):
        return obj
    if obj.text is not None:
        return obj.text
    return "".join(plain_text(c) for c in obj.children)


def matches(node, selector):
    if not selector or node.text is not None:
        return False
    selector = selector.strip()
    if not selector:
        return False
    if "," in selector:
        return any(matches(node, p) for p in selector.split(","))
    if selector.startswith("#"):
        return node.attrs.get("id") == selector[1:]
    if selector.startswith("."):
        return selector[1:] in node.attrs.get("class", "").split()
    if "." in selector and not selector.startswith("."):
        tag, cls = selector.split(".", 1)
        return node.tag == tag.lower() and cls in node.attrs.get("class", "").split()
    if "#" in selector and not selector.startswith("#"):
        tag, ident = selector.split("#", 1)
        return node.tag == tag.lower() and node.attrs.get("id") == ident
    return node.tag == selector.lower()


def prune(node, exclude=None):
    if node.text is not None:
        return node
    if exclude and matches(node, exclude):
        return None
    kept = []
    for c in node.children:
        p = prune(c, exclude)
        if p is not None:
            kept.append(p)
    node.children = kept
    return node


class Renderer:
    BLOCKS = {"p", "div", "section", "article", "header", "footer", "main", "nav", "aside", "figure", "figcaption"}

    def __init__(self, opts):
        self.opts = opts
        self.list_stack = []

    def absolute(self, href):
        if not href:
            return ""
        if self.opts.domain and not re.match(r"^[a-zA-Z][a-zA-Z0-9+.-]*:", href) and not href.startswith("#"):
            return urljoin(self.opts.domain, href)
        return href

    def render(self, root):
        if self.opts.include_selector:
            nodes = self.find_all(root, self.opts.include_selector)
        else:
            nodes = root.children
        parts = [self.block(n) for n in nodes]
        out = self.join_blocks(parts)
        out = re.sub(r"\n{3,}", "\n\n", out).strip()
        return out + ("\n" if out else "")

    def find_all(self, node, selector):
        found = []
        if node.text is None:
            if matches(node, selector):
                found.append(node)
            for c in node.children:
                found.extend(self.find_all(c, selector))
        return found

    def join_blocks(self, parts):
        out = []
        for p in parts:
            p = p.strip("\n")
            if not p:
                continue
            if out:
                out.append("\n\n")
            out.append(p)
        return "".join(out)

    def children_inline(self, node):
        s = "".join(self.inline(c) for c in node.children)
        s = collapse_ws(s)
        s = re.sub(r" ?\n ?", "\n", s)
        return s.strip(" ")

    def children_block(self, node):
        return self.join_blocks([self.block(c) for c in node.children])

    def inline_children_raw(self, node):
        return "".join(self.inline(c) for c in node.children).strip()

    def inline(self, node):
        if node.text is not None:
            return esc_text(collapse_ws(node.text))
        tag = node.tag
        if tag in {"script", "style", "template"}:
            return ""
        if tag == "br":
            return "  \n"
        if tag in {"strong", "b"}:
            return self.opts.strong + self.inline_children_raw(node).strip() + self.opts.strong
        if tag in {"em", "i"}:
            return "*" + self.inline_children_raw(node).strip() + "*"
        if tag == "code":
            txt = plain_text(node).replace("\n", " ")
            fence = "`"
            while fence in txt:
                fence += "`"
            return fence + txt.strip() + fence
        if tag == "a":
            text = self.inline_children_raw(node).strip() or node.attrs.get("href", "")
            href = self.absolute(node.attrs.get("href", ""))
            title = node.attrs.get("title")
            if title:
                return "[%s](%s \"%s\")" % (text, esc_url(href), title.replace('"', '\\"'))
            return "[%s](%s)" % (text, esc_url(href))
        if tag == "img":
            src = self.absolute(node.attrs.get("src", ""))
            alt = esc_alt(node.attrs.get("alt", ""))
            title = node.attrs.get("title")
            if title:
                return "![%s](%s \"%s\")" % (alt, esc_url(src), title.replace('"', '\\"'))
            return "![%s](%s)" % (alt, esc_url(src))
        if tag in {"del", "s", "strike"} and self.opts.strikethrough:
            return "~~" + self.inline_children_raw(node).strip() + "~~"
        if tag in {"p", "div", "span", "small", "sub", "sup", "mark", "abbr", "cite"}:
            return self.children_inline(node)
        return "".join(self.inline(c) for c in node.children)

    def block(self, node):
        if node.text is not None:
            text = collapse_ws(node.text)
            return esc_text(text).strip() if not is_ws(text) else ""
        tag = node.tag
        if tag in {"script", "style", "template", "head", "meta", "link", "title"}:
            return ""
        if tag in {"h1", "h2", "h3", "h4", "h5", "h6"}:
            level = int(tag[1])
            return "#" * level + " " + self.children_inline(node).strip()
        if tag == "p":
            return self.children_inline(node).strip()
        if tag in {"strong", "b", "em", "i", "code", "a", "img", "del", "s", "strike", "span"}:
            return self.inline(node).strip()
        if tag == "pre":
            txt = plain_text(node)
            txt = txt.strip("\n")
            fence = "```"
            while fence in txt:
                fence += "`"
            return fence + "\n" + txt + "\n" + fence
        if tag == "blockquote":
            inner = self.children_block(node)
            return "\n".join("> " + line if line else "> " for line in inner.splitlines())
        if tag in {"ul", "ol"}:
            return self.list_block(node, ordered=(tag == "ol"))
        if tag == "li":
            return self.children_block(node) or self.children_inline(node)
        if tag == "hr":
            return "* * *"
        if tag == "br":
            return "  \n"
        if tag == "table":
            if self.opts.table:
                return self.table(node)
            return self.children_inline(node)
        if tag in {"thead", "tbody", "tfoot", "tr", "td", "th"}:
            return self.children_inline(node)
        if tag in self.BLOCKS or tag in {"body", "html", "root"}:
            return self.children_block(node) or self.children_inline(node)
        return self.children_block(node) or self.children_inline(node)

    def list_block(self, node, ordered=False):
        items = [c for c in node.children if c.text is None and c.tag == "li"]
        lines = []
        start = 1
        if ordered:
            try:
                start = int(node.attrs.get("start", "1"))
            except ValueError:
                start = 1
        for idx, li in enumerate(items):
            marker = f"{start + idx}. " if ordered else "- "
            body_parts = []
            for c in li.children:
                if c.text is not None and is_ws(c.text):
                    continue
                body_parts.append(self.block(c) if c.text is None and c.tag in {"ul", "ol", "p", "pre", "blockquote", "table"} else self.inline(c))
            body = self.join_blocks(body_parts).strip("\n")
            body_lines = body.splitlines() or [""]
            lines.append(marker + body_lines[0])
            pad = " " * len(marker)
            for extra in body_lines[1:]:
                lines.append(pad + extra)
        return "\n".join(lines)

    def table(self, node):
        rows = []
        for tr in self.find_tag(node, "tr"):
            cells = [c for c in tr.children if c.text is None and c.tag in {"td", "th"}]
            row = [self.children_inline(c).replace("\n", " ").strip() for c in cells]
            if row or not self.opts.table_skip_empty_rows:
                rows.append(row)
        if not rows:
            return ""
        width = max(len(r) for r in rows)
        rows = [r + [""] * (width - len(r)) for r in rows]
        header = rows[0]
        out = ["| " + " | ".join(header) + " |", "|" + "|".join(["---"] * width) + "|"]
        for r in rows[1:]:
            out.append("| " + " | ".join(r) + " |")
        return "\n".join(out)

    def find_tag(self, node, tag):
        found = []
        if node.text is None:
            if node.tag == tag:
                found.append(node)
            for c in node.children:
                found.extend(self.find_tag(c, tag))
        return found


def convert(html, opts):
    p = Parser()
    p.feed(html)
    root = prune(p.root, opts.exclude_selector)
    return Renderer(opts).render(root)


def read_inputs(path):
    if path is None:
        return [(None, sys.stdin.read())]
    paths = []
    if os.path.isdir(path):
        paths = sorted(glob.glob(os.path.join(path, "*")))
    else:
        g = sorted(glob.glob(path))
        paths = g if g else [path]
    out = []
    for p in paths:
        if os.path.isdir(p):
            continue
        with open(p, "r", encoding="utf-8", errors="replace") as f:
            out.append((p, f.read()))
    return out


def output_path(input_path, output, multiple):
    if output is None:
        return None
    if multiple or os.path.isdir(output):
        base = os.path.basename(input_path or "output")
        stem, _ = os.path.splitext(base)
        return os.path.join(output, stem + ".md")
    return output


def main(argv=None):
    if argv is None:
        argv = sys.argv[1:]
    need_arg = {
        "--input": "-input",
        "--output": "-output",
        "--domain": "-domain",
        "--exclude-selector": "-exclude-selector",
        "--include-selector": "-include-selector",
        "--opt-strong-delimiter": "-opt-strong-delimiter",
        "--opt-table-cell-padding-behavior": "-opt-table-cell-padding-behavior",
        "--opt-table-newline-behavior": "-opt-table-newline-behavior",
        "--opt-table-span-cell-behavior": "-opt-table-span-cell-behavior",
    }
    for i, a in enumerate(argv):
        if a in need_arg and (i + 1 == len(argv) or argv[i + 1].startswith("-")):
            print(f"\nerror: flag needs an argument: {need_arg[a]}\n", file=sys.stderr)
            return 1
    ap = argparse.ArgumentParser(add_help=False, usage=argparse.SUPPRESS)
    ap.add_argument("-v", "--version", action="store_true")
    ap.add_argument("--help", action="store_true")
    ap.add_argument("--input")
    ap.add_argument("--output")
    ap.add_argument("--output-overwrite", action="store_true")
    ap.add_argument("--domain")
    ap.add_argument("--exclude-selector")
    ap.add_argument("--include-selector")
    ap.add_argument("--opt-strong-delimiter", dest="strong", default="**")
    ap.add_argument("--opt-table-cell-padding-behavior", default="minimal")
    ap.add_argument("--opt-table-header-promotion", action="store_true")
    ap.add_argument("--opt-table-newline-behavior", default="skip")
    ap.add_argument("--opt-table-presentation-tables", action="store_true")
    ap.add_argument("--opt-table-skip-empty-rows", action="store_true", dest="table_skip_empty_rows")
    ap.add_argument("--opt-table-span-cell-behavior", default="empty")
    ap.add_argument("--plugin-strikethrough", action="store_true", dest="strikethrough")
    ap.add_argument("--plugin-table", action="store_true", dest="table")
    try:
        opts, extra = ap.parse_known_args(argv)
    except SystemExit:
        print("\nerror: invalid arguments\n", file=sys.stderr)
        return 1
    if extra:
        print(f"\nerror: unknown flag: {extra[0]}\n", file=sys.stderr)
        return 1
    if opts.help:
        print(HELP)
        return 0
    if opts.version:
        print("html2markdown\n\nGitVersion:  dev\nGitCommit:   none\nBuildDate:   unknown")
        return 0
    if opts.strong not in ("**", "__"):
        opts.strong = "**"
    try:
        inputs = read_inputs(opts.input)
    except Exception as e:
        print(f"\nerror: {e}\n", file=sys.stderr)
        return 1
    multiple = len(inputs) > 1 or (opts.input and (os.path.isdir(opts.input) or any(ch in opts.input for ch in "*?[")))
    if multiple and opts.output and not os.path.isdir(opts.output):
        print("\nerror: output must be a directory when input is a directory or glob pattern\n", file=sys.stderr)
        return 1
    for inp, html in inputs:
        md = convert(html, opts)
        outp = output_path(inp, opts.output, multiple)
        if outp:
            if os.path.exists(outp) and not opts.output_overwrite:
                print(f'\nerror: output path "{outp}" already exists. Use --output-overwrite to replace existing files\n', file=sys.stderr)
                return 1
            os.makedirs(os.path.dirname(outp) or ".", exist_ok=True)
            with open(outp, "w", encoding="utf-8") as f:
                f.write(md)
        else:
            sys.stdout.write(md)
    return 0


HELP = """# html2markdown - convert html to markdown [version dev]

Convert HTML to Markdown. Even works with entire websites!

## Basics

By default the "Commonmark" Plugin will be enabled. You can customize the options,
for example changing the appearance of bold with --opt-strong-delimiter="__"

Other Plugins can also be enabled. For example "GitHub Flavored Markdown" (GFM)
extends Commonmark with more features.

## Relative / Absolute Links

Use --domain="https://example.com" to convert *relative* links to *absolute* links.
The same also works for images.

## Escaping

Some characters have a special meaning in markdown. The library escapes these — if necessary.
See the documentation for more info.

## Security

Once you convert this markdown *back* to HTML you need to be careful of malicious content. 
Use a HTML sanitizer before displaying the HTML in the browser!


## Examples

    echo "<strong>important</strong>" | html2markdown

    curl --no-progress-meter http://example.com | html2markdown


    html2markdown --input file.html --output file.md

    html2markdown --input "src/*.html" --output "dist/"


## Flags

    -v, --version
        show the version of html2markdown and exit

    --help

    --input PATH
        Input file, directory, or glob pattern (instead of stdin)

    --output PATH
        Output file or directory (instead of stdout)

    --output-overwrite
        Replace existing files

    If --input is a directory or glob pattern, --output must be a directory.



    --domain
        The url of the web page, used to convert relative links to absolute links.

    --exclude-selector
        css query selector to exclude parts of the input

    --include-selector
        css query selector to only include parts of the input

    --opt-strong-delimiter
        Make bold text. Should <strong> be indicated by two asterisks or two underscores?
        "**" or "__" (default: "**")

    --opt-table-cell-padding-behavior
        [for --plugin-table] whether cells in the tables should include extra padding for visual continuity: "aligned", "minimal", or "none"

    --opt-table-header-promotion
        [for --plugin-table] first row should be treated as a header

    --opt-table-newline-behavior
        [for --plugin-table] how tables containing newlines should be handled: "skip" or "preserve"

    --opt-table-presentation-tables
        [for --plugin-table] whether tables with role="presentation" should be converted

    --opt-table-skip-empty-rows
        [for --plugin-table] omit empty rows from the output

    --opt-table-span-cell-behavior
        [for --plugin-table] how colspan/rowspan should be rendered: "empty" or "mirror"

    --plugin-strikethrough
        enable the plugin ~~strikethrough~~

    --plugin-table
        enable the plugin table



For more information visit the documentation:
https://github.com/Johanneskaufmann/html-to-markdown
"""


if __name__ == "__main__":
    sys.exit(main())
