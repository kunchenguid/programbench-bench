#!/usr/bin/env python3
import sys, os, json, fnmatch, re
from collections import OrderedDict
VERSION='tokei 14.0.0 compiled with serialization support: json'
LANGS={
'py':('Python','#',None,None),'pyw':('Python','#',None,None),'rs':('Rust','//','/*','*/'),'c':('C','//','/*','*/'),'h':('C Header','//','/*','*/'),'cc':('C++','//','/*','*/'),'cpp':('C++','//','/*','*/'),'cxx':('C++','//','/*','*/'),'hpp':('C++ Header','//','/*','*/'),'hh':('C++ Header','//','/*','*/'),'java':('Java','//','/*','*/'),'js':('JavaScript','//','/*','*/'),'mjs':('JavaScript','//','/*','*/'),'cjs':('JavaScript','//','/*','*/'),'jsx':('JSX','//','/*','*/'),'ts':('TypeScript','//','/*','*/'),'tsx':('TSX','//','/*','*/'),'go':('Go','//','/*','*/'),'cs':('C#','//','/*','*/'),'swift':('Swift','//','/*','*/'),'kt':('Kotlin','//','/*','*/'),'php':('PHP','//','/*','*/'),'css':('CSS',None,'/*','*/'),'scss':('Sass','//','/*','*/'),'less':('Less','//','/*','*/'),'sh':('Shell','#',None,None),'bash':('BASH','#',None,None),'zsh':('Zsh','#',None,None),'fish':('Fish','#',None,None),'rb':('Ruby','#',None,None),'pl':('Perl','#',None,None),'pm':('Perl','#',None,None),'r':('R','#',None,None),'R':('R','#',None,None),'lua':('Lua','--','--[[',']]'),'sql':('SQL','--','/*','*/'),'hs':('Haskell','--','{-','-}'),'html':('HTML',None,'<!--','-->'),'htm':('HTML',None,'<!--','-->'),'xml':('XML',None,'<!--','-->'),'svg':('SVG',None,'<!--','-->'),'md':('Markdown',None,None,None),'markdown':('Markdown',None,None,None),'mdx':('MDX',None,None,None),'rst':('ReStructuredText',None,None,None),'json':('JSON',None,None,None),'jsonc':('JSON','//','/*','*/'),'toml':('TOML','#',None,None),'yaml':('YAML','#',None,None),'yml':('YAML','#',None,None),'ini':('INI',';',None,None),'cfg':('INI',';',None,None),'conf':('INI','#',None,None),'dockerfile':('Dockerfile','#',None,None),'makefile':('Makefile','#',None,None),'mk':('Makefile','#',None,None),'cmake':('CMake','#',None,None),'tex':('TeX','%',None,None),'scala':('Scala','//','/*','*/'),'dart':('Dart','//','/*','*/'),'m':('Objective-C','//','/*','*/'),'mm':('Objective-C++','//','/*','*/'),'ex':('Elixir','#',None,None),'exs':('Elixir','#',None,None),'erl':('Erlang','%',None,None),'clj':('Clojure',';',None,None),'fs':('F#','//','(*','*)')}
SPECIAL={'Dockerfile':('Dockerfile','#',None,None),'Makefile':('Makefile','#',None,None),'Rakefile':('Rakefile','#',None,None),'CMakeLists.txt':('CMake','#',None,None)}
DISPLAY=[('ABNF','abnf'),('AWK','awk'),('ABAP','abap'),('ActionScript','as'),('Ada','ada, adb, ads, pad'),('Agda','agda'),('C','c, ec, pgc'),('C Header','h'),('C++','cc, cpp, cxx, c++'),('C++ Header','hh, hpp, hxx'),('C#','cs, csx'),('CSS','css'),('Dockerfile','dockerfile, dockerignore'),('Go','go'),('HTML','html, htm'),('Java','java'),('JavaScript','js, mjs, cjs'),('JSON','json'),('Markdown','md, markdown'),('Python','py, pyw'),('Ruby','rb'),('Rust','rs'),('Shell','sh'),('BASH','bash'),('TOML','toml'),('TypeScript','ts'),('XML','xml'),('YAML','yaml, yml')]
HELP='''Count your code, quickly.
Support this project on GitHub Sponsors: https://github.com/sponsors/XAMPPRocky

Usage: executable [OPTIONS] [input]...

Arguments:
  [input]...  The path(s) to the file or directory to be counted. (default current directory)

Options:
  -c, --columns <columns>              Sets a strict column width of the output, only available for
                                       terminal output.
  -e, --exclude <exclude>              Ignore all files & directories matching the pattern.
  -f, --files                          Will print out statistics on individual files.
  -i, --input <file_input>             Gives statistics from a previous tokei run. Can be given a
                                       file path, or "stdin" to read from stdin.
      --hidden                         Count hidden files.
  -l, --languages                      Prints out supported languages and their extensions.
      --no-ignore                      Don't respect ignore files (.gitignore, .ignore, etc.). This
                                       implies --no-ignore-parent, --no-ignore-dot, and
                                       --no-ignore-vcs.
      --no-ignore-parent               Don't respect ignore files (.gitignore, .ignore, etc.) in
                                       parent directories.
      --no-ignore-dot                  Don't respect .ignore and .tokeignore files, including those
                                       in parent directories.
      --no-ignore-vcs                  Don't respect VCS ignore files (.gitignore, .hgignore, etc.)
                                       including those in parent directories.
  -o, --output <output>                Outputs Tokei in a specific format. Compile with additional
                                       features for more format support.
      --streaming <streaming>          prints the (language, path, lines, blanks, code, comments)
                                       records as simple lines or as Json for batch processing
                                       [possible values: simple, json]
  -s, --sort <sort>                    Sort languages based on column [possible values: files,
                                       lines, blanks, code, comments]
  -r, --rsort <rsort>                  Reverse sort languages based on column [possible values:
                                       files, lines, blanks, code, comments]
  -t, --types <types>                  Filters output by language type, separated by a comma. i.e.
                                       -t=Rust,Markdown
  -C, --compact                        Do not print statistics about embedded languages.
  -n, --num-format <num_format_style>  Format of printed numbers, i.e., plain (1234, default),
                                       commas (1,234), dots (1.234), or underscores (1_234). Cannot
                                       be used with --output. [possible values: commas, dots, plain,
                                       underscores]
  -v, --verbose...                     Set log output level:
                                                               1: to show unknown file extensions,
                                                               2: reserved for future debugging,
                                                               3: enable file level trace. Not
                                                               recommended on multiple files
  -h, --help                           Print help
  -V, --version                        Print version'''
class Stat:
 def __init__(self,b=0,c=0,m=0): self.blanks=b; self.code=c; self.comments=m
 def add(self,o): self.blanks+=o.blanks; self.code+=o.code; self.comments+=o.comments
 def lines(self): return self.blanks+self.code+self.comments
 def js(self,blobs=None):
  d=OrderedDict([('blanks',self.blanks),('code',self.code),('comments',self.comments)])
  if blobs is not None: d['blobs']=blobs
  return d
def lang_for(p):
 b=os.path.basename(p)
 if b in SPECIAL: return SPECIAL[b]
 lb=b.lower()
 if lb in ('dockerfile','.dockerignore'): return SPECIAL['Dockerfile']
 if lb in ('makefile','gnumakefile'): return SPECIAL['Makefile']
 if '.' not in b: return None
 e=b.rsplit('.',1)[1]
 return LANGS.get(e) or LANGS.get(e.lower())
def count_c(text,line='//',bs='/*',be='*/',nested=False):
 st=Stat(); depth=0
 for raw in text.splitlines():
  if raw.strip()=='': st.blanks+=1; continue
  i=0; code=False; com=False; q=None; esc=False
  while i<len(raw):
   if depth:
    com=True
    if nested and bs and raw.startswith(bs,i): depth+=1; i+=len(bs); continue
    if be and raw.startswith(be,i): depth-=1; i+=len(be); continue
    i+=1; continue
   ch=raw[i]
   if q:
    code=True
    if esc: esc=False
    elif ch=='\\': esc=True
    elif ch==q: q=None
    i+=1; continue
   if ch in ('"',"'"): code=True; q=ch; i+=1; continue
   if line and raw.startswith(line,i): com=True; break
   if bs and raw.startswith(bs,i): com=True; depth=1; i+=len(bs); continue
   if not ch.isspace(): code=True
   i+=1
  if code: st.code+=1
  elif com: st.comments+=1
  else: st.blanks+=1
 return st
def count_line(text,mark):
 st=Stat()
 for raw in text.splitlines():
  s=raw.strip()
  if not s: st.blanks+=1
  elif s.startswith(mark): st.comments+=1
  else: st.code+=1
 return st
def count_plain(text,as_comments=False):
 st=Stat()
 for raw in text.splitlines():
  if raw.strip():
   if as_comments: st.comments+=1
   else: st.code+=1
  else: st.blanks+=1
 return st
def fence_lang(f):
 aliases={'python':'py','py':'py','rust':'rs','rs':'rs','bash':'bash','sh':'sh','shell':'sh','javascript':'js','js':'js','typescript':'ts','ts':'ts','json':'json','c':'c','cpp':'cpp','c++':'cpp','java':'java','html':'html','css':'css','go':'go','ruby':'rb','sql':'sql'}
 e=aliases.get((f or '').lower()); return LANGS.get(e) if e else None
def count_md(text):
 st=Stat(); blobs={}; inf=False; fl=None; buf=[]
 for raw in text.splitlines():
  s=raw.strip(); m=re.match(r'^(```+|~~~+)\s*([A-Za-z0-9_+.#-]*)',s)
  if m:
   if not inf: inf=True; fl=m.group(2); buf=[]; st.comments+=1
   else:
    lg=fence_lang(fl)
    if lg:
     cs,_=count_text('\n'.join(buf)+('\n' if buf else ''),lg); blobs.setdefault(lg[0],Stat()).add(cs)
    else:
     st.add(count_plain('\n'.join(buf)+('\n' if buf else ''),True))
    inf=False; st.comments+=1
   continue
  if inf: buf.append(raw)
  elif s: st.comments+=1
  else: st.blanks+=1
 return st,blobs
def extract_html(text):
 out=[]; blobs={}; pos=0
 for m in re.finditer(r'(?is)<(script|style)\b[^>]*>(.*?)</\1\s*>',text):
  out.append(text[pos:m.start()]); body=m.group(2); lg=LANGS['js'] if m.group(1).lower()=='script' else LANGS['css']
  cs,_=count_text(body,lg); blobs.setdefault(lg[0],Stat()).add(cs); out.append('<%s></%s>\n'%(m.group(1),m.group(1))); pos=m.end()
 out.append(text[pos:]); return ''.join(out),blobs

def count_rust(text):
 doc=[]; keep=[]
 for raw in text.splitlines():
  st=raw.lstrip()
  if st.startswith('//!') or st.startswith('///'):
   doc.append(st[3:].lstrip()); continue
  keep.append(raw)
 rs=count_c('\n'.join(keep)+('\n' if keep else ''),'//','/*','*/',True)
 blobs={}
 if doc:
  blobs['Markdown']=count_plain('\n'.join(doc)+'\n',True)
 return rs,blobs

def count_html_doc(text):
 main=Stat(); blobs={}; mode=None; buf=[]
 for raw in text.splitlines():
  low=raw.lower(); stripped=raw.strip()
  if mode:
   if ('</script' in low and mode=='JavaScript') or ('</style' in low and mode=='CSS'):
    lg=LANGS['js'] if mode=='JavaScript' else LANGS['css']
    cs,_=count_text('\n'.join(buf)+('\n' if buf else ''),lg); blobs.setdefault(mode,Stat()).add(cs)
    main.code+=1; mode=None; buf=[]
   else:
    buf.append(raw)
   continue
  if '<script' in low:
   main.code+=1
   after=raw[low.find('<script'):]
   if '</script' in low:
    pass
   else: mode='JavaScript'; buf=[]
   continue
  if '<style' in low:
   main.code+=1
   if '</style' not in low: mode='CSS'; buf=[]
   continue
  if not stripped: main.blanks+=1
  elif stripped.startswith('<!--') and stripped.endswith('-->'): main.comments+=1
  else: main.code+=1
 return main,blobs

def count_text(text,lg):
 name,line,bs,be=lg
 if name in ('Markdown','MDX'): return count_md(text)
 if name=='Rust': return count_rust(text)
 if name=='HTML': return count_html_doc(text)
 if name in ('XML','SVG'): return count_c(text,None,'<!--','-->'),{}
 if name in ('JSON',): return count_plain(text),{}
 if bs or (line and line in ('//','--')): return count_c(text,line,bs,be,name=='Rust'),{}
 if line: return count_line(text,line),{}
 return count_plain(text),{}
def read_text(p):
 try:
  data=open(p,'rb').read()
  if b'\0' in data[:4096]: return None
  return data.decode('utf-8','replace')
 except Exception: return None
def ignored(p,root,hidden,pats):
 rel=os.path.relpath(p,root); base=os.path.basename(p)
 if not hidden and any(x.startswith('.') for x in rel.split(os.sep) if x not in ('.','..')): return True
 for pat in pats:
  pat=pat.strip()
  if not pat: continue
  if fnmatch.fnmatch(base,pat) or fnmatch.fnmatch(rel,pat) or fnmatch.fnmatch(p,pat): return True
  if pat.endswith('/') and (rel.startswith(pat[:-1]+'/') or base==pat[:-1]): return True
 return False
def ignore_pats(d):
 r=[]
 for n in ('.tokeignore','.ignore','.gitignore'):
  p=os.path.join(d,n)
  if os.path.exists(p):
   try:
    for l in open(p,encoding='utf-8',errors='ignore'):
     s=l.strip()
     if s and not s.startswith('#') and not s.startswith('!'): r.append(s.lstrip('/'))
   except Exception: pass
 return r
def collect(inputs,opt):
 files=[]
 for inp in [os.path.abspath(x) for x in (inputs or ['.'])]:
  if os.path.isfile(inp): files.append(inp); continue
  if os.path.isdir(inp):
   for d,dirs,names in os.walk(inp):
    pats=list(opt['exclude'])+(ignore_pats(d) if not opt['no_ignore'] else [])
    dirs[:]=[x for x in dirs if x not in ('.git','.hg','.svn') and not ignored(os.path.join(d,x),inp,opt['hidden'],pats)]
    for n in names:
     p=os.path.join(d,n)
     if not ignored(p,inp,opt['hidden'],pats): files.append(p)
 return sorted(set(files))
def build(inputs,opt):
 res={}; want=set(x.strip().lower() for t in opt['types'] for x in t.split(',') if x.strip())
 for p in collect(inputs,opt):
  lg=lang_for(p)
  if not lg:
   if opt['verbose']: print('WARNING: Unknown extension: %s'%p,file=sys.stderr)
   continue
  if want and lg[0].lower() not in want: continue
  txt=read_text(p)
  if txt is None: continue
  st,blobs=count_text(txt,lg); name=os.path.relpath(p)
  ent=res.setdefault(lg[0],{'stats':Stat(),'reports':[],'children':{}}); ent['stats'].add(st); ent['reports'].append({'stats':st,'name':name,'blobs':blobs})
  for bn,bst in blobs.items(): ent['children'].setdefault(bn,[]).append({'stats':bst,'name':name})
 return res
def sort_items(res,opt):
 items=list(res.items()); key=opt.get('sort') or opt.get('rsort')
 if key:
  def val(it): return len(it[1]['reports']) if key=='files' else getattr(it[1]['stats'],key)
  items.sort(key=lambda it:(val(it),it[0]),reverse=bool(opt.get('rsort')))
 else: items.sort(key=lambda it:it[0])
 return items
def nfmt(n,style):
 if style=='commas': return f'{n:,}'
 if style=='underscores': return f'{n:_}'
 if style=='dots': return f'{n:,}'.replace(',','.')
 return str(n)
def json_out(res):
 out=OrderedDict(); total=Stat(); tc=OrderedDict()
 for ln,data in sorted(res.items()):
  reps=[]; children=OrderedDict()
  for rep in data['reports']:
   blobs=OrderedDict((bn,bst.js(OrderedDict())) for bn,bst in sorted(rep['blobs'].items()))
   reps.append(OrderedDict([('stats',rep['stats'].js(blobs)),('name',rep['name'])])); total.add(rep['stats']); tc.setdefault(ln,[]).append(OrderedDict([('stats',rep['stats'].js(blobs)),('name',rep['name'])]))
   for bst in rep['blobs'].values(): total.add(bst)
  for bn,cr in sorted(data['children'].items()): children[bn]=[OrderedDict([('stats',r['stats'].js(OrderedDict())),('name',r['name'])]) for r in cr]
  out[ln]=OrderedDict([('blanks',data['stats'].blanks),('code',data['stats'].code),('comments',data['stats'].comments),('reports',reps),('children',children),('inaccurate',False)])
 out['Total']=OrderedDict([('blanks',total.blanks),('code',total.code),('comments',total.comments),('reports',[]),('children',tc),('inaccurate',False)])
 print(json.dumps(out,separators=(',',':')))
def row(name,files,lines,code,comments,blanks,style):
 f='' if files is None else nfmt(files,style)
 return f' {name:<18} {f:>9} {nfmt(lines,style):>12} {nfmt(code,style):>12} {nfmt(comments,style):>12} {nfmt(blanks,style):>12}'
def table(res,opt):
 heavy='━'*81; mid='─'*81; total=Stat(); tf=0; style=opt['numfmt']
 print(heavy); print(' Language              Files        Lines         Code     Comments       Blanks'); print(heavy)
 for ln,data in sort_items(res,opt):
  st=data['stats']; tf+=len(data['reports']); total.add(st); has=bool(data['children']) and not opt['compact']
  if has: print(mid)
  print(row(ln,len(data['reports']),st.lines(),st.code,st.comments,st.blanks,style))
  child=Stat()
  if has:
   for cn,cr in sorted(data['children'].items()):
    cs=Stat()
    for r in cr: cs.add(r['stats'])
    child.add(cs); print(row('|- '+cn,len(cr),cs.lines(),cs.code,cs.comments,cs.blanks,style))
   allst=Stat(st.blanks,st.code,st.comments); allst.add(child); print(row('(Total)',None,allst.lines(),allst.code,allst.comments,allst.blanks,style))
  if opt['files']:
   print(mid)
   for rep in sorted(data['reports'],key=lambda r:r['name']):
    rs=rep['stats']; print(row(rep['name'],None,rs.lines(),rs.code,rs.comments,rs.blanks,style))
  total.add(child)
 print(heavy); print(row('Total',tf,total.lines(),total.code,total.comments,total.blanks,style)); print(heavy)
def stream(res,mode):
 rec=[]
 for ln,data in sorted(res.items()):
  for rep in data['reports']:
   st=rep['stats']; rec.append((ln,rep['name'],st.lines(),st.code,st.comments,st.blanks))
 if mode=='json':
  for l,p,ln,c,m,b in rec: print(json.dumps({'language':l,'path':p,'lines':ln,'code':c,'comments':m,'blanks':b},separators=(',',':')))
 else:
  print('# language                                        path                                          lines         code       comments      blanks   '); print('########## ################################################################################ ############ ############ ############ ############')
  for l,p,ln,c,m,b in rec: print(f'{l:>10} {p:<80} {ln:>12} {c:>12} {m:>12} {b:>12}')
def languages():
 print('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━'); print('┃ Language                              Extensions                     ┃'); print('┃━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┃')
 for k,v in DISPLAY: print(f'┃ {k:<37} {v:<30} ┃')
 print('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━')
def parse(argv):
 opt={'exclude':[],'files':False,'hidden':False,'no_ignore':False,'types':[],'compact':False,'verbose':0,'output':None,'stream':None,'sort':None,'rsort':None,'numfmt':'plain'}; inputs=[]; i=0
 while i<len(argv):
  a=argv[i]
  if a in ('-h','--help'): print(HELP); sys.exit(0)
  if a in ('-V','--version'): print(VERSION); sys.exit(0)
  if a in ('-l','--languages'): languages(); sys.exit(0)
  if a in ('-f','--files'): opt['files']=True
  elif a=='--hidden': opt['hidden']=True
  elif a.startswith('-v'): opt['verbose']+=max(1,a.count('v'))
  elif a in ('--no-ignore','--no-ignore-parent','--no-ignore-dot','--no-ignore-vcs'): opt['no_ignore']=True
  elif a in ('-C','--compact'): opt['compact']=True
  elif a in ('-e','--exclude'): i+=1; opt['exclude'].append(argv[i])
  elif a.startswith('--exclude='): opt['exclude'].append(a.split('=',1)[1])
  elif a in ('-t','--types','--type'): i+=1; opt['types'].append(argv[i])
  elif a.startswith('-t=') or a.startswith('--types=') or a.startswith('--type='): opt['types'].append(a.split('=',1)[1])
  elif a in ('-o','--output'): i+=1; opt['output']=argv[i]
  elif a.startswith('--output='): opt['output']=a.split('=',1)[1]
  elif a=='--streaming': i+=1; opt['stream']=argv[i]
  elif a.startswith('--streaming='): opt['stream']=a.split('=',1)[1]
  elif a in ('-s','--sort'): i+=1; opt['sort']=argv[i]
  elif a in ('-r','--rsort'): i+=1; opt['rsort']=argv[i]
  elif a in ('-n','--num-format'): i+=1; opt['numfmt']=argv[i]
  elif a.startswith('--num-format='): opt['numfmt']=a.split('=',1)[1]
  elif a in ('-c','--columns','-i','--input'): i+=1
  elif a=='--': inputs+=argv[i+1:]; break
  elif a.startswith('-'): print(f'error: unexpected argument {a!r}',file=sys.stderr); sys.exit(2)
  else: inputs.append(a)
  i+=1
 if opt['output'] and opt['output']!='json': print(f"error: invalid value '{opt['output']}' for '--output <output>': This version of tokei was compiled without any '{opt['output']}' serialization support, to enable serialization, reinstall tokei with the features flag.",file=sys.stderr); sys.exit(2)
 return opt,inputs
def main():
 opt,inputs=parse(sys.argv[1:]); res=build(inputs,opt)
 if opt['output']=='json': json_out(res)
 elif opt['stream']: stream(res,opt['stream'])
 else: table(res,opt)
if __name__=='__main__': main()
