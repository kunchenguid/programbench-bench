package main

import (
	"encoding/json"
	"fmt"
	"os"
	"path/filepath"
	"strings"
	"time"
)

const banner = "##################################################################\n# Content under this line is handled by hostctl. DO NOT EDIT.\n##################################################################"

type Entry struct {
	IP   string
	Host string
}

type Profile struct {
	Name    string
	Enabled bool
	Entries []Entry
}

type Row struct {
	Profile string
	Status  string
	IP      string
	Host    string
}

type State struct {
	Default  []Entry
	Profiles []Profile
	Prefix   string
}

type Opts struct {
	HostFile string
	Out      string
	Columns  []string
	Quiet    bool
	NoColor  bool
	From     string
	IP       string
	All      bool
	Only     bool
	Path     string
	Raw      bool
}

func main() {
	args, opt := parseGlobal(os.Args[1:])
	if opt.HostFile == "" {
		opt.HostFile = "/etc/hosts"
	}
	if opt.Out == "" {
		opt.Out = "table"
	}
	if opt.Raw {
		opt.Out = "raw"
	}
	if opt.IP == "" {
		opt.IP = "127.0.0.1"
	}
	if opt.Path == "" {
		wd, _ := os.Getwd()
		opt.Path = wd
	}
	if len(args) == 0 {
		help()
		return
	}
	if args[0] == "-v" || args[0] == "--version" {
		fmt.Println("hostctl version dev")
		return
	}
	if args[0] == "-h" || args[0] == "--help" {
		help()
		return
	}
	if args[0] == "help" {
		if len(args) > 1 {
			commandHelp(args[1:])
		} else {
			help()
		}
		return
	}
	cmd := args[0]
	args = args[1:]
	if contains(args, "-h") || contains(args, "--help") {
		commandHelp(append([]string{cmd}, args...))
		return
	}
	switch cmd {
	case "list":
		listCmd(args, opt)
	case "status":
		statusCmd(args, opt)
	case "add":
		addCmd(args, opt, false)
	case "replace":
		addCmd(args, opt, true)
	case "remove", "rm":
		removeCmd(args, opt)
	case "enable":
		setStatusCmd(args, opt, true)
	case "disable":
		setStatusCmd(args, opt, false)
	case "toggle":
		toggleCmd(args, opt)
	case "backup":
		backupCmd(opt)
	case "restore":
		restoreCmd(opt)
	case "sync":
		fail("docker sync is not available in this reimplementation")
	default:
		fail(fmt.Sprintf("unknown command %q for %q", cmd, "hostctl"))
	}
}

func parseGlobal(in []string) ([]string, Opts) {
	opt := Opts{}
	out := []string{}
	for i := 0; i < len(in); i++ {
		a := in[i]
		next := func() string {
			if i+1 >= len(in) {
				return ""
			}
			i++
			return in[i]
		}
		switch {
		case a == "--host-file":
			opt.HostFile = next()
		case strings.HasPrefix(a, "--host-file="):
			opt.HostFile = strings.TrimPrefix(a, "--host-file=")
		case a == "-o" || a == "--out":
			opt.Out = next()
		case strings.HasPrefix(a, "--out="):
			opt.Out = strings.TrimPrefix(a, "--out=")
		case a == "-c" || a == "--column":
			opt.Columns = splitCSV(next())
		case strings.HasPrefix(a, "--column="):
			opt.Columns = splitCSV(strings.TrimPrefix(a, "--column="))
		case a == "-q" || a == "--quiet":
			opt.Quiet = true
		case a == "--raw":
			opt.Raw = true
		case a == "--no-color":
			opt.NoColor = true
		case a == "-f" || a == "--from":
			opt.From = next()
		case strings.HasPrefix(a, "--from="):
			opt.From = strings.TrimPrefix(a, "--from=")
		case a == "--ip":
			opt.IP = next()
		case strings.HasPrefix(a, "--ip="):
			opt.IP = strings.TrimPrefix(a, "--ip=")
		case a == "--all":
			opt.All = true
		case a == "--only":
			opt.Only = true
		case a == "--path":
			opt.Path = next()
		case strings.HasPrefix(a, "--path="):
			opt.Path = strings.TrimPrefix(a, "--path=")
		case a == "-w" || a == "--wait" || strings.HasPrefix(a, "--wait="):
			if !strings.Contains(a, "=") {
				_ = next()
			}
		default:
			out = append(out, a)
		}
	}
	return out, opt
}

func splitCSV(s string) []string {
	var r []string
	for _, p := range strings.Split(s, ",") {
		p = strings.TrimSpace(strings.ToLower(p))
		if p != "" {
			r = append(r, p)
		}
	}
	return r
}

func load(path string) State {
	b, err := os.ReadFile(path)
	if err != nil {
		if os.IsNotExist(err) {
			return State{}
		}
		fail(err.Error())
	}
	text := strings.ReplaceAll(string(b), "\r\n", "\n")
	st := State{Prefix: strings.TrimRight(text, "\n")}
	idx := strings.Index(text, banner)
	managed := ""
	if idx >= 0 {
		st.Prefix = strings.TrimRight(text[:idx], "\n")
		managed = text[idx+len(banner):]
	}
	st.Default = parseEntries(st.Prefix, true)
	lines := strings.Split(managed, "\n")
	for i := 0; i < len(lines); i++ {
		line := strings.TrimSpace(lines[i])
		if strings.HasPrefix(line, "# profile.") {
			parts := strings.Fields(line)
			if len(parts) < 3 {
				continue
			}
			p := Profile{Name: parts[2], Enabled: strings.Contains(parts[1], ".on")}
			i++
			for ; i < len(lines); i++ {
				l := strings.TrimSpace(lines[i])
				if l == "# end" {
					break
				}
				for _, e := range parseHostLine(l, false) {
					p.Entries = append(p.Entries, e)
				}
			}
			st.Profiles = append(st.Profiles, p)
		}
	}
	return st
}

func parseEntries(text string, defaultPart bool) []Entry {
	var out []Entry
	for _, line := range strings.Split(text, "\n") {
		out = append(out, parseHostLine(line, defaultPart)...)
	}
	return out
}

func parseHostLine(line string, defaultPart bool) []Entry {
	s := strings.TrimSpace(line)
	if s == "" {
		return nil
	}
	if strings.HasPrefix(s, "#") {
		s = strings.TrimSpace(strings.TrimPrefix(s, "#"))
		if defaultPart {
			return nil
		}
	}
	if i := strings.Index(s, "#"); i >= 0 {
		s = strings.TrimSpace(s[:i])
	}
	f := strings.Fields(s)
	if len(f) < 2 {
		return nil
	}
	if !isIPish(f[0]) {
		return nil
	}
	var out []Entry
	hosts := f[1:]
	if defaultPart && len(hosts) > 1 {
		hosts = hosts[:1]
	}
	for _, h := range hosts {
		out = append(out, Entry{IP: f[0], Host: h})
	}
	return out
}

func isIPish(s string) bool {
	return strings.Contains(s, ".") || strings.Contains(s, ":")
}

func save(path string, st State) {
	var b strings.Builder
	prefix := normalizePrefix(st.Prefix)
	if prefix != "" {
		b.WriteString(prefix)
		b.WriteString("\n\n")
	}
	b.WriteString(banner)
	b.WriteString("\n")
	for _, p := range st.Profiles {
		b.WriteString("\n")
		if p.Enabled {
			fmt.Fprintf(&b, "# profile.on %s\n", p.Name)
		} else {
			fmt.Fprintf(&b, "# profile.off %s\n", p.Name)
		}
		for _, e := range p.Entries {
			if p.Enabled {
				fmt.Fprintf(&b, "%s %s\n", e.IP, e.Host)
			} else {
				fmt.Fprintf(&b, "# %s %s\n", e.IP, e.Host)
			}
		}
		b.WriteString("# end\n")
	}
	if err := os.WriteFile(path, []byte(b.String()), 0644); err != nil {
		fail(err.Error())
	}
}

func normalizePrefix(prefix string) string {
	var out []string
	for _, line := range strings.Split(strings.TrimRight(prefix, "\n"), "\n") {
		s := strings.TrimSpace(line)
		if s == "" || strings.HasPrefix(s, "#") {
			out = append(out, line)
			continue
		}
		if i := strings.Index(s, "#"); i >= 0 {
			s = strings.TrimSpace(s[:i])
		}
		f := strings.Fields(s)
		if len(f) >= 2 {
			out = append(out, f[0]+" "+f[1])
		}
	}
	return strings.TrimRight(strings.Join(out, "\n"), "\n")
}

func profileIndex(st *State, name string) int {
	for i := range st.Profiles {
		if st.Profiles[i].Name == name {
			return i
		}
	}
	return -1
}

func listCmd(args []string, opt Opts) {
	mode := ""
	if len(args) > 0 && (args[0] == "enabled" || args[0] == "on" || args[0] == "disabled" || args[0] == "off") {
		mode = args[0]
		args = args[1:]
	}
	st := load(opt.HostFile)
	var rows []Row
	if mode == "" || mode == "enabled" || mode == "on" {
		if len(args) == 0 {
			for _, e := range st.Default {
				rows = append(rows, Row{"default", "on", e.IP, e.Host})
			}
		}
	}
	for _, p := range st.Profiles {
		if len(args) > 0 && !contains(args, p.Name) {
			continue
		}
		if (mode == "enabled" || mode == "on") && !p.Enabled {
			continue
		}
		if (mode == "disabled" || mode == "off") && p.Enabled {
			continue
		}
		for _, e := range p.Entries {
			rows = append(rows, Row{p.Name, status(p.Enabled), e.IP, e.Host})
		}
	}
	render(rows, opt, true)
}

func statusCmd(args []string, opt Opts) {
	st := load(opt.HostFile)
	var rows []Row
	for _, p := range st.Profiles {
		if len(args) == 0 || contains(args, p.Name) {
			rows = append(rows, Row{Profile: p.Name, Status: status(p.Enabled)})
		}
	}
	render(rows, opt, false)
}

func addCmd(args []string, opt Opts, replace bool) {
	domains := false
	if len(args) > 0 && (args[0] == "domains" || args[0] == "domain") {
		domains = true
		args = args[1:]
	}
	if len(args) < 1 || args[0] == "" {
		fail("missing profile name")
	}
	name := args[0]
	var entries []Entry
	if domains {
		for _, d := range args[1:] {
			entries = append(entries, Entry{IP: opt.IP, Host: d})
		}
		if len(entries) == 0 {
			fail("missing domain name")
		}
	} else {
		if opt.From == "" {
			fail("missing file to read")
		}
		b, err := os.ReadFile(opt.From)
		if err != nil {
			fail(err.Error())
		}
		entries = parseEntries(string(b), false)
	}
	st := load(opt.HostFile)
	i := profileIndex(&st, name)
	if i < 0 {
		st.Profiles = append(st.Profiles, Profile{Name: name, Enabled: true})
		i = len(st.Profiles) - 1
	}
	st.Profiles[i].Enabled = true
	if replace {
		st.Profiles[i].Entries = entries
	} else {
		st.Profiles[i].Entries = append(st.Profiles[i].Entries, entries...)
	}
	save(opt.HostFile, st)
	if domains && !opt.Quiet && opt.Out != "json" {
		info(opt, fmt.Sprintf("Domains '%s' added.", strings.Join(args[1:], ", ")))
	}
	render(profileRows(st.Profiles[i]), opt, true)
}

func removeCmd(args []string, opt Opts) {
	domains := false
	if len(args) > 0 && (args[0] == "domains" || args[0] == "domain") {
		domains = true
		args = args[1:]
	}
	st := load(opt.HostFile)
	if domains {
		if len(args) < 2 {
			fail("missing profile or domain name")
		}
		i := profileIndex(&st, args[0])
		if i < 0 {
			fail("unknown profile name")
		}
		removeSet := map[string]bool{}
		for _, d := range args[1:] {
			removeSet[d] = true
		}
		var kept []Entry
		for _, e := range st.Profiles[i].Entries {
			if !removeSet[e.Host] {
				kept = append(kept, e)
			}
		}
		st.Profiles[i].Entries = kept
		save(opt.HostFile, st)
		if !opt.Quiet && opt.Out != "json" {
			info(opt, fmt.Sprintf("Domains '%s' removed.", strings.Join(args[1:], ", ")))
		}
		render(profileRows(st.Profiles[i]), opt, true)
		return
	}
	if opt.All {
		st.Profiles = nil
		save(opt.HostFile, st)
		if !opt.Quiet && opt.Out != "json" {
			info(opt, "All profiles removed.")
		}
		return
	}
	if len(args) == 0 {
		fail("missing profile name")
	}
	names := map[string]bool{}
	for _, n := range args {
		names[n] = true
	}
	var kept []Profile
	for _, p := range st.Profiles {
		if !names[p.Name] {
			kept = append(kept, p)
		}
	}
	st.Profiles = kept
	save(opt.HostFile, st)
	if !opt.Quiet && opt.Out != "json" {
		info(opt, fmt.Sprintf("Profile(s) '%s' removed.", strings.Join(args, ", ")))
	}
}

func setStatusCmd(args []string, opt Opts, enabled bool) {
	st := load(opt.HostFile)
	if opt.All {
		for i := range st.Profiles {
			st.Profiles[i].Enabled = enabled
		}
		save(opt.HostFile, st)
		render(allRows(st.Profiles), opt, true)
		return
	}
	if len(args) == 0 {
		fail("missing profile name")
	}
	for i := range st.Profiles {
		if opt.Only {
			st.Profiles[i].Enabled = !enabled
		}
	}
	var rows []Row
	for _, n := range args {
		i := profileIndex(&st, n)
		if i < 0 {
			fail("unknown profile name")
		}
		st.Profiles[i].Enabled = enabled
		rows = append(rows, profileRows(st.Profiles[i])...)
	}
	save(opt.HostFile, st)
	render(rows, opt, true)
}

func toggleCmd(args []string, opt Opts) {
	if len(args) == 0 {
		fail("missing profile name")
	}
	st := load(opt.HostFile)
	var rows []Row
	for _, n := range args {
		i := profileIndex(&st, n)
		if i < 0 {
			fail("unknown profile name")
		}
		st.Profiles[i].Enabled = !st.Profiles[i].Enabled
		rows = append(rows, profileRows(st.Profiles[i])...)
	}
	save(opt.HostFile, st)
	render(rows, opt, true)
}

func backupCmd(opt Opts) {
	b, err := os.ReadFile(opt.HostFile)
	if err != nil {
		fail(err.Error())
	}
	dst := filepath.Join(opt.Path, filepath.Base(opt.HostFile)+"."+time.Now().Format("20060102"))
	if err := os.WriteFile(dst, b, 0644); err != nil {
		fail(err.Error())
	}
	if !opt.Quiet && opt.Out != "json" {
		info(opt, fmt.Sprintf("Backup saved at %s", dst))
	}
}

func restoreCmd(opt Opts) {
	if opt.From == "" {
		fail("missing file to restore")
	}
	b, err := os.ReadFile(opt.From)
	if err != nil {
		fail(err.Error())
	}
	if err := os.WriteFile(opt.HostFile, b, 0644); err != nil {
		fail(err.Error())
	}
}

func allRows(ps []Profile) []Row {
	var rows []Row
	for _, p := range ps {
		rows = append(rows, profileRows(p)...)
	}
	return rows
}

func profileRows(p Profile) []Row {
	var rows []Row
	for _, e := range p.Entries {
		rows = append(rows, Row{p.Name, status(p.Enabled), e.IP, e.Host})
	}
	return rows
}

func status(b bool) string {
	if b {
		return "on"
	}
	return "off"
}

func render(rows []Row, opt Opts, detailed bool) {
	if opt.Quiet {
		return
	}
	cols := opt.Columns
	if len(cols) == 0 {
		if detailed {
			cols = []string{"profile", "status", "ip", "domain"}
		} else {
			cols = []string{"profile", "status"}
		}
	}
	switch opt.Out {
	case "json":
		b, _ := json.Marshal(rows)
		fmt.Println(string(b))
	case "markdown":
		infoFile(opt)
		printMarkdown(rows, cols)
	case "raw":
		infoFile(opt)
		printRaw(rows, cols)
	default:
		infoFile(opt)
		printTable(rows, cols)
	}
}

func rowVal(r Row, c string) string {
	switch strings.ToLower(c) {
	case "profile", "name":
		return r.Profile
	case "status":
		return r.Status
	case "ip":
		return r.IP
	case "domain", "host", "hostname":
		return r.Host
	}
	return ""
}

func head(c string) string {
	if strings.ToLower(c) == "domain" || strings.ToLower(c) == "host" || strings.ToLower(c) == "hostname" {
		return "DOMAIN"
	}
	return strings.ToUpper(c)
}

func widths(rows []Row, cols []string) []int {
	w := make([]int, len(cols))
	for i, c := range cols {
		w[i] = len(head(c))
	}
	for _, r := range rows {
		for i, c := range cols {
			if l := len(rowVal(r, c)); l > w[i] {
				w[i] = l
			}
		}
	}
	return w
}

func printRaw(rows []Row, cols []string) {
	w := widths(rows, cols)
	for i, c := range cols {
		if i > 0 {
			fmt.Print("\t")
		}
		fmt.Printf("%-*s", w[i], head(c))
	}
	fmt.Println()
	for _, r := range rows {
		for i, c := range cols {
			if i > 0 {
				fmt.Print("\t")
			}
			fmt.Printf("%-*s", w[i], rowVal(r, c))
		}
		fmt.Println()
	}
}

func printMarkdown(rows []Row, cols []string) {
	w := widths(rows, cols)
	printMDLine := func(vals []string) {
		fmt.Print("|")
		for i, v := range vals {
			fmt.Printf(" %-*s |", w[i], v)
		}
		fmt.Println()
	}
	heads := make([]string, len(cols))
	seps := make([]string, len(cols))
	for i, c := range cols {
		heads[i] = head(c)
		seps[i] = strings.Repeat("-", w[i])
	}
	printMDLine(heads)
	printMDLine(seps)
	for _, r := range rows {
		vals := make([]string, len(cols))
		for i, c := range cols {
			vals[i] = rowVal(r, c)
		}
		printMDLine(vals)
	}
}

func printTable(rows []Row, cols []string) {
	w := widths(rows, cols)
	border := func() {
		fmt.Print("+")
		for _, x := range w {
			fmt.Print(strings.Repeat("-", x+2) + "+")
		}
		fmt.Println()
	}
	line := func(vals []string) {
		fmt.Print("|")
		for i, v := range vals {
			fmt.Printf(" %-*s |", w[i], v)
		}
		fmt.Println()
	}
	border()
	heads := make([]string, len(cols))
	for i, c := range cols {
		heads[i] = head(c)
	}
	line(heads)
	border()
	for _, r := range rows {
		vals := make([]string, len(cols))
		for i, c := range cols {
			vals[i] = rowVal(r, c)
		}
		line(vals)
	}
	border()
}

func infoFile(opt Opts) {
	if opt.HostFile != "/etc/hosts" {
		fmt.Printf("[ℹ] Using hosts file: %s\n\n", opt.HostFile)
	}
}

func info(opt Opts, msg string) {
	infoFile(opt)
	fmt.Printf("[✔] %s\n\n", msg)
}

func fail(msg string) {
	fmt.Fprintf(os.Stderr, "[✖] error: %s\n", msg)
	os.Exit(1)
}

func contains(xs []string, x string) bool {
	for _, y := range xs {
		if y == x {
			return true
		}
	}
	return false
}

func help() {
	fmt.Println(`hostctl is a CLI tool to manage your hosts file with ease.
You can have multiple profiles, enable/disable exactly what
you need each time with a simple interface.

Usage:
  hostctl [command]

Available Commands:
  add         Add content to a profile in your hosts file.
  backup      Creates a backup copy of your hosts file
  disable     Disable a profile from your hosts file.
  enable      Enable a profile on your hosts file.
  list        Shows a detailed list of profiles on your hosts file.
  remove      Remove a profile from your hosts file.
  replace     Replace content to a profile in your hosts file.
  restore     Restore hosts file content from a backup file.
  status      Shows a list of profile names and statuses on your hosts file.
  sync        Sync some system IPs with a profile.
  toggle      Change status of a profile on your hosts file.

Flags:
  -c, --column strings     Column names to show on lists. comma separated
  -h, --help               help for hostctl
      --host-file string   Hosts file path (default "/etc/hosts")
      --no-color           force colorless output
  -o, --out string         Output type (table|raw|markdown|json) (default "table")
  -q, --quiet              Run command without output
      --raw                Output without borders (same as -o raw)
  -v, --version            version for hostctl`)
}

func commandHelp(args []string) {
	cmd := ""
	if len(args) > 0 {
		cmd = args[0]
	}
	switch cmd {
	case "add":
		if len(args) > 1 && (args[1] == "domains" || args[1] == "domain") {
			fmt.Println(`Set content in your hosts file.
If the profile already exists it will be added to it.

Usage:
  hostctl add domains [profile] [domains] [flags]

Aliases:
  domains, domain [profile] [domains] [flags]

Flags:
      --ip string   domains ip (default "127.0.0.1")`)
			return
		}
		fmt.Println(`Reads from a file and set content to a profile in your hosts file.
If the profile already exists it will be added to it.

Usage:
  hostctl add [profiles] [flags]
  hostctl add [command]

Available Commands:
  domains     Add content in your hosts file.

Flags:
  -f, --from string     file to read
  -w, --wait duration   Enables a profile for a specific amount of time. (example: 5m, 1h) (default -1ns)`)
	case "replace":
		fmt.Println(`Reads from a file and set content to a profile in your hosts file.
If the profile already exists it will be overwritten.

Usage:
  hostctl replace [profile] [flags]

Flags:
  -f, --from string   file to read`)
	case "remove", "rm":
		if len(args) > 1 && (args[1] == "domains" || args[1] == "domain") {
			fmt.Println(`Completely remove domains from your hosts file.
It cannot be undone unless you have a backup and restore it.

Usage:
  hostctl remove domains [profile] [domains] [flags]`)
			return
		}
		fmt.Println(`Completely remove a profile content from your hosts file.
It cannot be undone unless you have a backup and restore it.

Usage:
  hostctl remove [profiles] [flags]
  hostctl remove [command]

Flags:
      --all    Remove all profiles`)
	case "enable":
		fmt.Println(`Enables an existing profile.
It will be listed as "on" while it is enabled.

Usage:
  hostctl enable [profiles] [flags]

Flags:
      --all             Enable all profiles
      --only            Disable all other profiles
  -w, --wait duration   Enables a profile for a specific amount of time (default -1ns)`)
	case "disable":
		fmt.Println(`Disable a profile from your hosts file without removing it.
It will be listed as "off" while it is disabled.

Usage:
  hostctl disable [profiles] [flags]

Flags:
      --all             Disable all profiles
      --only            Enable all other profiles
  -w, --wait duration   Enables a profile for a specific amount of time (default -1ns)`)
	case "toggle":
		fmt.Println(`Alternates between on/off status of an existing profile.

Usage:
  hostctl toggle [flags]`)
	case "status":
		fmt.Println(`Shows a list of unique profile names on your hosts file with its status.

The "default" profile is always on and will be skipped.

Usage:
  hostctl status [profiles] [flags]`)
	case "list":
		fmt.Println(`Shows a detailed list of profiles on your hosts file with name, ip and host name.
You can filter by profile name.

The "default" profile is all the content that is not handled by hostctl tool.

Usage:
  hostctl list [profiles] [flags]
  hostctl list [command]

Available Commands:
  disabled    Shows list of disabled profiles on your hosts file.
  enabled     Shows list of enabled profiles on your hosts file.`)
	case "backup":
		fmt.Println(`Creates a backup copy of your hosts file with the date in .YYYYMMDD
as extension.

Usage:
  hostctl backup [flags]

Flags:
      --path string   A path to save the backup`)
	case "restore":
		fmt.Println(`Reads from a file and replace the content of your hosts file.

WARNING: the complete hosts file will be overwritten with the backup data.

Usage:
  hostctl restore [flags]

Flags:
      --from string   The file to restore from`)
	case "sync":
		fmt.Println(`Reads IPs and names from some local system and sync it with a profile in your hosts file.

Usage:
  hostctl sync [command]

Available Commands:
  docker         Sync your Docker containers IPs with a profile.
  docker-compose Sync your docker-compose containers IPs with a profile.`)
	default:
		help()
	}
}
