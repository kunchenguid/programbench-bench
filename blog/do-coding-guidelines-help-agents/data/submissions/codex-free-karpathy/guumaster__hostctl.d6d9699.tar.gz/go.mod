module rehostctl

go 1.20
