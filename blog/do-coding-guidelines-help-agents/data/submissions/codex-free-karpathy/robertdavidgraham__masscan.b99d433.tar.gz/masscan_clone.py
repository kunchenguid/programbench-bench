#!/usr/bin/env python3
import os
import random
import re
import sys
from ipaddress import ip_address

SHORT_HELP = """usage: masscan [options] [<IP|RANGE>... -pPORT[,PORT...]]

examples:
    masscan -p80,8000-8100 10.0.0.0/8 --rate=10000
        scan some web ports on 10.x.x.x at 10kpps

    masscan --nmap
        list those options that are compatible with nmap

    masscan -p80 10.0.0.0/8 --banners -oB <filename>
        save results of scan in binary format to <filename>

    masscan --open --banners --readscan <filename> -oX <savefile>
        read binary scan results in <filename> and save them as xml in <savefile>
"""

LONG_HELP = """usage: masscan [options] [<IP|RANGE>... -pPORT[,PORT...]]
MASSCAN is a fast port scanner. The primary input parameters are the
IP addresses/ranges you want to scan, and the port numbers. An example
is the following, which scans the 10.x.x.x network for web servers:

    masscan 10.0.0.0/8 -p80

The program auto-detects network interface/adapter settings. If this
fails, you'll have to set these manually. The following is an
example of all the parameters that are needed:

    --adapter-ip 192.168.10.123
    --adapter-mac 00-11-22-33-44-55
    --router-mac 66-55-44-33-22-11

Parameters can be set either via the command-line or config-file. The
names are the same for both. Thus, the above adapter settings would
appear as follows in a configuration file:

    adapter-ip = 192.168.10.123
    adapter-mac = 00-11-22-33-44-55
    router-mac = 66-55-44-33-22-11

All single-dash parameters have a spelled out double-dash equivalent,
so '-p80' is the same as '--ports 80' (or 'ports = 80' in config file).
To use the config file, type:

    masscan -c <filename>

To generate a config-file from the current settings, use the --echo
option. This stops the program from actually running, and just echoes
the current configuration instead. This is a useful way to generate
your first config file, or see a list of parameters you didn't know
about. I suggest you try it now:

    masscan -p1234 --echo
"""

NMAP_HELP = """Masscan (https://github.com/robertdavidgraham/masscan)
Usage: masscan [Options] -p{Target-Ports} {Target-IP-Ranges}
TARGET SPECIFICATION:
  Can pass only IPv4/IPv6 address, CIDR networks, or ranges (non-nmap style)
  Ex: 10.0.0.0/8, 192.168.0.1, 10.0.0.1-10.0.0.254
  -iL <inputfilename>: Input from list of hosts/networks
  --exclude <host1[,host2][,host3],...>: Exclude hosts/networks
  --excludefile <exclude_file>: Exclude list from file
  --randomize-hosts: Randomize order of hosts (default)
HOST DISCOVERY:
  -Pn: Treat all hosts as online (default)
  -n: Never do DNS resolution (default)
SCAN TECHNIQUES:
  -sS: TCP SYN (always on, default)
SERVICE/VERSION DETECTION:
  --banners: get the banners of the listening service if available. The
    default timeout for waiting to receive data is 30 seconds.
PORT SPECIFICATION AND SCAN ORDER:
  -p <port ranges>: Only scan specified ports
    Ex: -p22; -p1-65535; -p 111,137,80,139,8080
TIMING AND PERFORMANCE:
  --max-rate <number>: Send packets no faster than <number> per second
  --connection-timeout <number>: time in seconds a TCP connection will
    timeout while waiting for banner data from a port.
FIREWALL/IDS EVASION AND SPOOFING:
  -S/--source-ip <IP_Address>: Spoof source address
  -e <iface>: Use specified interface
  -g/--source-port <portnum>: Use given port number
  --ttl <val>: Set IP time-to-live field
  --spoof-mac <mac address/prefix/vendor name>: Spoof your MAC address
OUTPUT:
  --output-format <format>: Sets output to binary/list/unicornscan/json/ndjson/grepable/xml
  --output-file <file>: Write scan results to file. If --output-format is
     not given default is xml
  -oL/-oJ/-oD/-oG/-oB/-oX/-oU <file>: Output scan in List/JSON/nDjson/Grepable/Binary/XML/Unicornscan format,
     respectively, to the given filename. Shortcut for
     --output-format <format> --output-file <file>
  -v: Increase verbosity level (use -vv or more for greater effect)
  -d: Increase debugging level (use -dd or more for greater effect)
  --open: Only show open (or possibly open) ports
  --packet-trace: Show all packets sent and received
  --iflist: Print host interfaces and routes (for debugging)
  --append-output: Append to rather than clobber specified output files
  --resume <filename>: Resume an aborted scan
MISC:
  --send-eth: Send using raw ethernet frames (default)
  -V: Print version number
  -h: Print this help summary page.
EXAMPLES:
  masscan -v -sS 192.168.0.0/16 10.0.0.0/8 -p 80
  masscan 23.0.0.0/0 -p80 --banners -output-format binary --output-filename internet.scan
  masscan --open --banners --readscan internet.scan -oG internet_scan.grepable
SEE (https://github.com/robertdavidgraham/masscan) FOR MORE HELP
"""

VERSION = """Masscan version 1.3.9-integration ( https://github.com/robertdavidgraham/masscan )
Compiled on: Apr 17 2026 19:59:25
Compiler: gcc 11.4.0
OS: Linux
CPU: x86 (64 bits)
GIT version: unknown
"""

PCAP_FAIL = """[-] FAIL: failed to load libpcap shared library
    [hint]: you must install libpcap or WinPcap
"""

OUTPUT_SHORT = {"-oX": ("xml",), "-oL": ("list",), "-oJ": ("json",), "-oD": ("ndjson",), "-oG": ("grepable",), "-oB": ("binary",), "-oU": ("unicornscan",)}


class Cfg:
    def __init__(self):
        self.seed = None
        self.rate = "100"
        self.shard = "1/1"
        self.ports = ""
        self.ranges = []
        self.output_filename = None
        self.output_format = None
        self.output_append = False
        self.banners = False
        self.adapter = None
        self.adapter_ip = None
        self.adapter_mac = None
        self.router_mac = None
        self.adapter_port = None
        self.echo = False
        self.verbose = 0
        self.debug = 0
        self.readscan = None
        self.excludes = []


def canonical_mac(s):
    return s.replace(":", "-").lower()


def split_csv(v):
    return [x.strip() for x in re.split(r"[,\s]+", v.strip()) if x.strip()]


def canonical_ports(v):
    tcp, udp = [], []
    for part in split_csv(v):
        up = part.upper()
        target = tcp
        if up.startswith("U:"):
            target = udp
            part = part[2:]
        elif up.startswith("T:"):
            part = part[2:]
        for x in part.split(","):
            if x:
                target.append(x)
    out = tcp + ["U:" + x for x in udp]
    return ",".join(out)


def validate_ports(portstr):
    if not portstr:
        return True
    for p in re.split(r"[, ]+", portstr):
        if not p:
            continue
        p = p.upper().replace("T:", "").replace("U:", "")
        nums = p.split("-")
        for n in nums:
            if not n.isdigit():
                return False
            if int(n) > 65535:
                print(f"[-] FAIL: bad target port: {n}")
                print("    Hint: a port is a number [0..65535]")
                sys.exit(0)
    return True


def ip_to_int(s):
    return int(ip_address(s))


def int_to_ip(n):
    return str(ip_address(n))


def add_range(cfg, spec):
    spec = spec.strip()
    if not spec:
        return
    cfg.ranges.append(spec)


def read_list_file(cfg, path):
    try:
        with open(path, "r", encoding="utf-8", errors="ignore") as f:
            for line in f:
                line = line.split("#", 1)[0].strip()
                if line:
                    add_range(cfg, line)
    except OSError as e:
        print("[-] FAIL: parsing IP addresses")
        print(f"[-] {path}: {e.strerror}")
        sys.exit(0)


def read_exclude_file(cfg, path):
    count = 0
    try:
        with open(path, "r", encoding="utf-8", errors="ignore") as f:
            for line in f:
                line = line.split("#", 1)[0].strip()
                if line:
                    cfg.excludes.append(line)
                    count += 1
    except OSError as e:
        print("[-] FAIL: parsing IP addresses")
        print(f"[-] {path}: {e.strerror}")
        sys.exit(0)
    print(f"{path}: excluding {count} ranges from file")


def subtract_single_ip(ranges, excludes):
    exclude_ips = set()
    for e in excludes:
        if "-" not in e and "/" not in e:
            try:
                exclude_ips.add(ip_to_int(e))
            except ValueError:
                pass
    if not exclude_ips:
        return ranges
    out = []
    for r in ranges:
        if "-" in r and "/" not in r:
            a, b = r.split("-", 1)
            try:
                start, end = ip_to_int(a), ip_to_int(b)
                cur = start
                for ex in sorted(x for x in exclude_ips if start <= x <= end):
                    if cur <= ex - 1:
                        out.append(int_to_ip(cur) if cur == ex - 1 else f"{int_to_ip(cur)}-{int_to_ip(ex-1)}")
                    cur = ex + 1
                if cur <= end:
                    out.append(int_to_ip(cur) if cur == end else f"{int_to_ip(cur)}-{int_to_ip(end)}")
                continue
            except ValueError:
                pass
        try:
            if "/" not in r and "-" not in r and ip_to_int(r) in exclude_ips:
                continue
        except ValueError:
            pass
        out.append(r)
    return out


def apply_kv(cfg, key, val):
    k = key.strip().lstrip("-").lower().replace("_", "-")
    v = val.strip()
    if k in ("p", "ports", "port"):
        if validate_ports(v):
            cfg.ports = canonical_ports(v)
    elif k in ("range", "ranges"):
        for x in split_csv(v):
            add_range(cfg, x)
    elif k in ("i", "il", "include-file", "includefile"):
        read_list_file(cfg, v)
    elif k == "exclude":
        cfg.excludes.extend(split_csv(v))
    elif k == "excludefile":
        read_exclude_file(cfg, v)
    elif k in ("rate", "max-rate"):
        cfg.rate = v
    elif k == "seed":
        cfg.seed = v
    elif k in ("shard", "shards"):
        cfg.shard = v
    elif k in ("output-format",):
        cfg.output_format = v
    elif k in ("output-filename", "output-file"):
        cfg.output_filename = v
    elif k == "append-output":
        cfg.output_append = True
    elif k == "banners":
        cfg.banners = True
    elif k in ("adapter", "interface", "e"):
        cfg.adapter = v
    elif k in ("adapter-ip", "source-ip", "s"):
        cfg.adapter_ip = v
    elif k in ("adapter-mac", "spoof-mac"):
        cfg.adapter_mac = canonical_mac(v)
    elif k in ("router-mac", "router-mac-ipv4", "router-mac-ipv6"):
        cfg.router_mac = canonical_mac(v)
    elif k in ("adapter-port", "source-port", "g"):
        cfg.adapter_port = v
    elif k == "echo":
        cfg.echo = True
    elif k == "readscan":
        cfg.readscan = v


def parse_config(cfg, path):
    try:
        with open(path, "r", encoding="utf-8", errors="ignore") as f:
            for line in f:
                line = line.split("#", 1)[0].strip()
                if not line:
                    continue
                if "=" in line:
                    k, v = line.split("=", 1)
                    apply_kv(cfg, k, v)
    except OSError as e:
        print(f"[-] {path}: {e.strerror}")
        sys.exit(0)


def need_arg(argv, i, opt):
    if i + 1 >= len(argv):
        print(f"{opt}: empty parameter")
        sys.exit(0)
    return argv[i + 1]


def parse(argv):
    cfg = Cfg()
    i = 0
    while i < len(argv):
        a = argv[i]
        if a in ("-h", "-?"):
            print(SHORT_HELP, end="")
            sys.exit(0)
        if a == "--help":
            print(LONG_HELP, end="")
            sys.exit(0)
        if a in ("-V", "--version"):
            print(VERSION, end="")
            sys.exit(0)
        if a == "--nmap":
            print(NMAP_HELP, end="")
            sys.exit(0)
        if a in ("--selftest", "--regress"):
            print(PCAP_FAIL, end="")
            print("regression test: success!")
            sys.exit(0)
        if a == "--iflist":
            print(PCAP_FAIL, end="")
            print("libpcap not loaded")
            sys.exit(0)
        if a == "--send-eth":
            print("nmap(send-eth): unnecessary, we always do --send-eth")
            i += 1
            continue
        if a in ("-v", "-d") or re.fullmatch(r"-v+|-d+", a):
            cfg.verbose += a.count("v")
            cfg.debug += a.count("d")
            i += 1
            continue
        if a.startswith("-o") and a[:3] in OUTPUT_SHORT:
            opt = a[:3]
            val = a[3:] or need_arg(argv, i, opt)
            if not a[3:]:
                i += 1
            cfg.output_format = OUTPUT_SHORT[opt][0]
            cfg.output_filename = val
            i += 1
            continue
        if a == "-p" or a == "--ports":
            apply_kv(cfg, "ports", need_arg(argv, i, a))
            i += 2
            continue
        if a.startswith("-p") and len(a) > 2:
            apply_kv(cfg, "ports", a[2:])
            i += 1
            continue
        if a in ("-c", "--conf", "--config"):
            parse_config(cfg, need_arg(argv, i, a))
            i += 2
            continue
        if a in ("-iL", "--include-file", "--includefile", "--excludefile", "--exclude", "--readscan",
                 "--rate", "--max-rate", "--seed", "--shard", "--shards", "--output-format",
                 "--output-file", "--output-filename", "--adapter-ip", "--source-ip", "-S",
                 "--adapter-mac", "--router-mac", "--source-port", "-g", "-e", "--adapter",
                 "--interface", "--spoof-mac", "--ttl", "--connection-timeout"):
            val = need_arg(argv, i, a)
            apply_kv(cfg, a, val)
            i += 2
            continue
        if a in ("--echo", "--banners", "--open", "--append-output", "--packet-trace", "-sS", "-Pn", "-n", "--randomize-hosts"):
            apply_kv(cfg, a, "true")
            i += 1
            continue
        if a.startswith("--"):
            if "=" in a:
                k, v = a[2:].split("=", 1)
                apply_kv(cfg, k, v)
            else:
                print(f"{a[2:]}: empty parameter")
            i += 1
            continue
        if a.startswith("-"):
            i += 1
            continue
        add_range(cfg, a)
        i += 1
    return cfg


def rate_text(rate):
    try:
        f = float(rate)
        if f == int(f):
            return f"{int(f):<10}"
        return f"{f:.6f}"
    except ValueError:
        return rate


def do_echo(cfg):
    print(PCAP_FAIL, end="")
    seed = cfg.seed if cfg.seed is not None else str(random.getrandbits(64))
    print(f"seed = {seed}")
    print(f"rate = {rate_text(cfg.rate)}")
    print(f"shard = {cfg.shard}")
    if cfg.banners:
        print("banners = true")
    print("nocapture = servername")
    print("nocapture = servername")
    print()
    if cfg.output_filename:
        print(f"output-filename = {cfg.output_filename}")
    if cfg.output_format:
        print(f"output-format = {cfg.output_format}")
    if cfg.output_append:
        print("output-append = true")
    print()
    if cfg.adapter:
        print(f"adapter = {cfg.adapter}")
    if cfg.adapter_ip:
        print(f"adapter-ip = {cfg.adapter_ip}")
    if cfg.adapter_mac:
        print(f"adapter-mac = {cfg.adapter_mac}")
    if cfg.router_mac:
        print(f"router-mac-ipv4 = {cfg.router_mac}")
        print(f"router-mac-ipv6 = {cfg.router_mac}")
    if cfg.adapter_port:
        print(f"adapter-port = {cfg.adapter_port}")
    print("# TARGET SELECTION (IP, PORTS, EXCLUDES)")
    print(f"ports = {cfg.ports}")
    for r in subtract_single_ip(cfg.ranges, cfg.excludes):
        print(f"range = {r}")


def do_readscan(path):
    print(PCAP_FAIL, end="")
    if not os.path.exists(path):
        print("[-] FAIL: --readscan")
        print(f"[-] {path}: No such file or directory")
        return
    print(f"[+] --readscan {path}")
    with open(path, "rb") as f:
        magic = f.read(16)
    if not magic.startswith(b"masscan/1.1"):
        print(f"[-] {path}: unknown file format (expeced \"masscan/1.1\")")


def main():
    cfg = parse(sys.argv[1:])
    if cfg.readscan:
        do_readscan(cfg.readscan)
        return
    if cfg.echo:
        do_echo(cfg)
        return
    print(PCAP_FAIL, end="")
    if not cfg.ports and not cfg.ranges:
        print(SHORT_HELP, end="")
    elif not cfg.ports:
        print("FAIL: no ports were specified")
        print(' [hint] try something like "-p80,8000-9000"')
        print(' [hint] try something like "--ports 0-65535"')
    elif not cfg.ranges:
        print("FAIL: target IP address list empty")
        print(' [hint] try something like "--range 10.0.0.0/8"')
        print(' [hint] try something like "--range 192.168.0.100-192.168.0.200"')
    else:
        print("[-] FAIL: could not determine default interface")
        print('    [hint] try "--interface ethX"')
        sys.exit(1)


if __name__ == "__main__":
    main()
