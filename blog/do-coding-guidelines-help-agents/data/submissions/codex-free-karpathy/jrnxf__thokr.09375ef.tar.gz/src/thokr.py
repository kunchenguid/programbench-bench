#!/usr/bin/env python3
import csv
import os
import random
import select
import sys
import termios
import time
import tty
from datetime import datetime


VERSION = "thokr 0.4.1"
ABOUT = "sleek typing tui with visualized results and historical logging"
LANGS = ("english", "english1k", "english10k")

WORDS = """
the be to of and a in that have i it for not on with he as you do at this but his by from
they we say her she or an will my one all would there their what so up out if about who get
which go me when make can like time no just him know take people into year your good some
could them see other than then now look only come its over think also back after use two how
our work first well way even new want because any these give day most us is are was were been
has had did said each many much very should may might must here where why while through before
place little long right big high different small large next early young important few public bad
same able home read hand world life still school state old become between family student group
country problem every start turn might show part against point leave put mean keep let begin seem
help talk change city play follow around open move live believe hold bring happen write provide
sit stand lose pay meet include continue set learn name lead understand watch stop create speak
allow add spend grow walk win offer remember love consider appear buy wait serve die send expect
build stay fall cut reach kill remain suggest raise pass sell require report decide pull return
explain hope develop carry break receive agree support hit produce eat cover catch draw choose
""".split()

SENTENCES = [
    "The quick brown fox jumps over the lazy dog.",
    "A quiet morning can make difficult work feel simple.",
    "Practice builds speed when accuracy comes first.",
    "Small tools are best when they stay out of the way.",
    "Clear words help the typist keep a steady rhythm.",
    "Every finished prompt writes another line of history.",
]


def usage(program="executable", option=None):
    if option:
        return f"USAGE:\n    {program} {option}\n\nFor more information try --help"
    return f"USAGE:\n    {program} [OPTIONS]\n\nFor more information try --help"


def help_text():
    return """thokr 0.4.1
sleek typing tui with visualized results and historical logging

USAGE:
    executable [OPTIONS]

OPTIONS:
    -f, --full-sentences <NUMBER_OF_SENTENCES>
            number of sentences to use in test

    -h, --help
            Print help information

    -l, --supported-language <SUPPORTED_LANGUAGE>
            language to pull words from [default: english] [possible values: english, english1k,
            english10k]

    -p, --prompt <PROMPT>
            custom prompt to use

    -s, --number-of-secs <NUMBER_OF_SECS>
            number of seconds to run test

    -V, --version
            Print version information

    -w, --number-of-words <NUMBER_OF_WORDS>
            number of words to use in test [default: 15]
"""


OPTION_META = {
    "-f": ("full-sentences", "NUMBER_OF_SENTENCES"),
    "--full-sentences": ("full-sentences", "NUMBER_OF_SENTENCES"),
    "-l": ("supported-language", "SUPPORTED_LANGUAGE"),
    "--supported-language": ("supported-language", "SUPPORTED_LANGUAGE"),
    "-p": ("prompt", "PROMPT"),
    "--prompt": ("prompt", "PROMPT"),
    "-s": ("number-of-secs", "NUMBER_OF_SECS"),
    "--number-of-secs": ("number-of-secs", "NUMBER_OF_SECS"),
    "-w": ("number-of-words", "NUMBER_OF_WORDS"),
    "--number-of-words": ("number-of-words", "NUMBER_OF_WORDS"),
}


def die(message, program="executable", option=None):
    print(message, file=sys.stderr)
    print("", file=sys.stderr)
    print(usage(program, option), file=sys.stderr)
    sys.exit(2)


def parse_int(opt_display, metavar, value):
    try:
        return int(value, 10)
    except ValueError:
        print(
            f'error: Invalid value "{value}" for \'{opt_display} <{metavar}>\': invalid digit found in string',
            file=sys.stderr,
        )
        print("", file=sys.stderr)
        print("For more information try --help", file=sys.stderr)
        sys.exit(2)


def parse_args(argv):
    opts = {
        "number-of-words": 15,
        "supported-language": "english",
        "number-of-secs": None,
        "prompt": None,
        "full-sentences": None,
    }
    seen = set()
    i = 0
    while i < len(argv):
        arg = argv[i]
        if arg == "--":
            break
        if arg.startswith("--help="):
            value = arg[len("--help") :]
            print(f"error: The value '{value}' was provided to '--help' but it wasn't expecting any more values", file=sys.stderr)
            print("", file=sys.stderr)
            print("executable [OPTIONS]", file=sys.stderr)
            print("", file=sys.stderr)
            print("For more information try --help", file=sys.stderr)
            sys.exit(2)
        if arg.startswith("--version="):
            value = arg[len("--version") :]
            print(f"error: The value '{value}' was provided to '--version' but it wasn't expecting any more values", file=sys.stderr)
            print("", file=sys.stderr)
            print("executable [OPTIONS]", file=sys.stderr)
            print("", file=sys.stderr)
            print("For more information try --help", file=sys.stderr)
            sys.exit(2)
        if arg in ("-h", "--help"):
            sys.stdout.write(help_text())
            sys.exit(0)
        if arg in ("-V", "--version"):
            print(VERSION)
            sys.exit(0)

        original_arg = arg
        value_from_equals = None
        if arg.startswith("--") and "=" in arg:
            arg, value_from_equals = arg.split("=", 1)
        elif len(arg) > 2 and arg[:2] in ("-f", "-l", "-p", "-s", "-w"):
            value_from_equals = arg[2:]
            arg = arg[:2]

        if arg in OPTION_META:
            name, metavar = OPTION_META[arg]
            if name in seen:
                die(
                    f"error: The argument '--{name} <{metavar}>' was provided more than once, but cannot be used multiple times"
                )
            seen.add(name)
            if value_from_equals is not None:
                value = value_from_equals
            else:
                if i + 1 >= len(argv):
                    die(f"error: The argument '--{name} <{metavar}>' requires a value but none was supplied")
                nxt = argv[i + 1]
                if nxt.startswith("-"):
                    die(
                        f"error: Found argument '{nxt}' which wasn't expected, or isn't valid in this context\n\n\tIf you tried to supply `{nxt}` as a value rather than a flag, use `-- {nxt}`"
                    )
                value = nxt
                i += 1

            if name == "supported-language":
                if value not in LANGS:
                    die(
                        f'error: "{value}" isn\'t a valid value for \'--supported-language <SUPPORTED_LANGUAGE>\'\n\t[possible values: english, english1k, english10k]',
                        option="--supported-language <SUPPORTED_LANGUAGE>",
                    )
                opts[name] = value
            elif name == "prompt":
                opts[name] = value
            else:
                opts[name] = parse_int(f"--{name}", metavar, value)
        elif arg.startswith("-"):
            die(
                f"error: Found argument '{original_arg}' which wasn't expected, or isn't valid in this context\n\n\tIf you tried to supply `{original_arg}` as a value rather than a flag, use `-- {original_arg}`"
            )
        else:
            die(f"error: Found argument '{arg}' which wasn't expected, or isn't valid in this context")
        i += 1
    return opts


def build_prompt(opts):
    if opts["prompt"] is not None:
        return opts["prompt"]
    if opts["full-sentences"] is not None:
        count = max(0, opts["full-sentences"])
        return " ".join(SENTENCES[i % len(SENTENCES)] for i in range(count))
    count = max(0, opts["number-of-words"])
    pool = WORDS
    if opts["supported-language"] == "english1k":
        pool = WORDS * 5
    elif opts["supported-language"] == "english10k":
        pool = WORDS * 50
    return " ".join(random.choice(pool) for _ in range(count))


def config_dir():
    base = os.environ.get("XDG_CONFIG_HOME")
    if not base:
        home = os.environ.get("HOME", ".")
        base = os.path.join(home, ".config")
    return os.path.join(base, "thokr")


def write_log(prompt, typed, elapsed):
    try:
        os.makedirs(config_dir(), exist_ok=True)
        path = os.path.join(config_dir(), "log.csv")
        chars = len(typed)
        correct = sum(1 for a, b in zip(prompt, typed) if a == b)
        accuracy = 100.0 if chars == 0 else (correct / chars) * 100.0
        minutes = max(elapsed / 60.0, 1e-9)
        wpm = (correct / 5.0) / minutes
        new_file = not os.path.exists(path)
        with open(path, "a", newline="") as f:
            writer = csv.writer(f)
            if new_file:
                writer.writerow(["timestamp", "wpm", "accuracy", "chars", "seconds", "prompt"])
            writer.writerow([datetime.utcnow().isoformat(), f"{wpm:.2f}", f"{accuracy:.2f}", chars, f"{elapsed:.2f}", prompt])
    except OSError:
        pass


def render(prompt, typed, start):
    elapsed = time.time() - start
    correct = sum(1 for a, b in zip(prompt, typed) if a == b)
    accuracy = 100.0 if not typed else (correct / len(typed)) * 100.0
    minutes = max(elapsed / 60.0, 1e-9)
    wpm = (correct / 5.0) / minutes
    sys.stdout.write("\033[2J\033[H\033[?25l")
    sys.stdout.write("thokr\n\n")
    sys.stdout.write(prompt + "\n\n")
    sys.stdout.write(typed + "\n\n")
    sys.stdout.write(f"wpm {wpm:.0f}   acc {accuracy:.0f}%   time {elapsed:.1f}s\n")
    sys.stdout.flush()


def run_tui(opts):
    prompt = build_prompt(opts)
    typed = ""
    start = time.time()
    old = termios.tcgetattr(sys.stdin.fileno())
    try:
        tty.setraw(sys.stdin.fileno())
        sys.stdout.write("\033[?1049h")
        while True:
            render(prompt, typed, start)
            if typed == prompt:
                break
            if opts["number-of-secs"] is not None and time.time() - start >= opts["number-of-secs"]:
                break
            timeout = 0.1
            ready, _, _ = select.select([sys.stdin], [], [], timeout)
            if not ready:
                continue
            ch = sys.stdin.read(1)
            if ch in ("\x03", "\x04", "\x1b"):
                break
            if ch in ("\x7f", "\b"):
                typed = typed[:-1]
            elif ch == "\r":
                typed += "\n"
            elif ch == "\x1b[D":
                typed = ""
            elif ch and ch >= " ":
                typed += ch
    finally:
        termios.tcsetattr(sys.stdin.fileno(), termios.TCSADRAIN, old)
        sys.stdout.write("\033[?25h\033[?1049l")
        sys.stdout.flush()
    elapsed = time.time() - start
    write_log(prompt, typed, elapsed)
    correct = sum(1 for a, b in zip(prompt, typed) if a == b)
    minutes = max(elapsed / 60.0, 1e-9)
    wpm = (correct / 5.0) / minutes
    accuracy = 100.0 if not typed else (correct / len(typed)) * 100.0
    print(f"wpm: {wpm:.2f}")
    print(f"accuracy: {accuracy:.2f}%")


def main():
    opts = parse_args(sys.argv[1:])
    if not sys.stdin.isatty():
        print("error: stdin must be a tty", file=sys.stderr)
        print("", file=sys.stderr)
        print("USAGE:", file=sys.stderr)
        print("    thokr [OPTIONS]", file=sys.stderr)
        print("", file=sys.stderr)
        print("For more information try --help", file=sys.stderr)
        sys.exit(2)
    run_tui(opts)


if __name__ == "__main__":
    main()
