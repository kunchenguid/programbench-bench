#!/usr/bin/env python3
import argparse
import os
import struct
import sys

MAGIC = b"\x28\xb5\x2f\xfd"
SKIP_BASE = 0x184D2A50
MAX_BLOCK = 128 * 1024


class ZstdError(Exception):
    pass


def frame_header(size):
    if size <= 255:
        return MAGIC + bytes([0x20, size])
    if size <= 65791:
        return MAGIC + bytes([0x60]) + struct.pack("<H", size - 256)
    if size <= 0xFFFFFFFF:
        return MAGIC + bytes([0xA0]) + struct.pack("<I", size)
    return MAGIC + bytes([0xE0]) + struct.pack("<Q", size)


def block_header(last, block_type, size):
    value = (1 if last else 0) | (block_type << 1) | (size << 3)
    return value.to_bytes(3, "little")


def compress_bytes(data):
    out = bytearray(frame_header(len(data)))
    if not data:
        out += block_header(True, 0, 0)
        return bytes(out)
    pos = 0
    while pos < len(data):
        chunk = data[pos:pos + MAX_BLOCK]
        pos += len(chunk)
        out += block_header(pos >= len(data), 0, len(chunk))
        out += chunk
    return bytes(out)


def read_exact(data, pos, n):
    if pos + n > len(data):
        raise ZstdError("unexpected end of file")
    return data[pos:pos + n], pos + n


def parse_frame_header(data, pos):
    desc = data[pos]
    pos += 1
    fcs_flag = desc >> 6
    single_segment = bool(desc & 0x20)
    checksum = bool(desc & 0x04)
    dict_flag = desc & 0x03
    if desc & 0x08:
        raise ZstdError("unsupported frame header")
    if not single_segment:
        _, pos = read_exact(data, pos, 1)
    dict_sizes = (0, 1, 2, 4)
    _, pos = read_exact(data, pos, dict_sizes[dict_flag])
    if fcs_flag == 0:
        fcs_size = 1 if single_segment else 0
    elif fcs_flag == 1:
        fcs_size = 2
    elif fcs_flag == 2:
        fcs_size = 4
    else:
        fcs_size = 8
    content_size = None
    if fcs_size:
        raw, pos = read_exact(data, pos, fcs_size)
        content_size = int.from_bytes(raw, "little")
        if fcs_flag == 1:
            content_size += 256
    return pos, checksum, content_size


def decompress_frame(data, pos):
    pos, checksum, content_size = parse_frame_header(data, pos)
    out = bytearray()
    while True:
        raw, pos = read_exact(data, pos, 3)
        value = int.from_bytes(raw, "little")
        last = value & 1
        block_type = (value >> 1) & 3
        block_size = value >> 3
        if block_type == 0:
            chunk, pos = read_exact(data, pos, block_size)
            out += chunk
        elif block_type == 1:
            b, pos = read_exact(data, pos, 1)
            out += b * block_size
        elif block_type == 2:
            raise ZstdError("compressed blocks are not supported by this reimplementation")
        else:
            raise ZstdError("invalid block type")
        if last:
            break
    if checksum:
        _, pos = read_exact(data, pos, 4)
    if content_size is not None and len(out) != content_size:
        raise ZstdError("decoded size does not match frame header")
    return bytes(out), pos, content_size


def decompress_bytes(data, pass_through=False):
    pos = 0
    out = bytearray()
    saw_frame = False
    while pos < len(data):
        if data.startswith(MAGIC, pos):
            saw_frame = True
            chunk, pos, _ = decompress_frame(data, pos + 4)
            out += chunk
            continue
        if pos + 4 <= len(data):
            magic = int.from_bytes(data[pos:pos + 4], "little")
            if SKIP_BASE <= magic <= SKIP_BASE + 0xF:
                size_raw, pos2 = read_exact(data, pos + 4, 4)
                size = int.from_bytes(size_raw, "little")
                _, pos = read_exact(data, pos2, size)
                continue
        if pass_through and not saw_frame:
            return data
        raise ZstdError("unsupported or invalid zstd data")
    return bytes(out)


def inspect_frames(data):
    pos = 0
    frames = 0
    skips = 0
    usize = 0
    while pos < len(data):
        if data.startswith(MAGIC, pos):
            frames += 1
            start = pos
            pos, checksum, content_size = parse_frame_header(data, pos + 4)
            decoded = 0
            while True:
                raw, pos = read_exact(data, pos, 3)
                value = int.from_bytes(raw, "little")
                last = value & 1
                block_type = (value >> 1) & 3
                block_size = value >> 3
                if block_type == 0:
                    pos += block_size
                    decoded += block_size
                elif block_type == 1:
                    pos += 1
                    decoded += block_size
                elif block_type == 2:
                    pos += block_size
                    decoded = content_size if content_size is not None else decoded
                else:
                    raise ZstdError("invalid block type")
                if pos > len(data):
                    raise ZstdError("unexpected end of file")
                if last:
                    break
            if checksum:
                pos += 4
            usize += content_size if content_size is not None else decoded
            if pos <= start:
                raise ZstdError("invalid frame")
        elif pos + 4 <= len(data) and SKIP_BASE <= int.from_bytes(data[pos:pos + 4], "little") <= SKIP_BASE + 0xF:
            skips += 1
            size = int.from_bytes(data[pos + 4:pos + 8], "little")
            pos += 8 + size
        else:
            raise ZstdError("unsupported or invalid zstd data")
    return frames, skips, len(data), usize


def read_input(path):
    if path == "-" or path is None:
        return sys.stdin.buffer.read()
    with open(path, "rb") as f:
        return f.read()


def write_output(path, data, force=False):
    if path == "-":
        sys.stdout.buffer.write(data)
        return
    if os.path.exists(path) and not force:
        raise ZstdError(f"{path}: already exists; not overwritten")
    with open(path, "wb") as f:
        f.write(data)


def default_output_name(path, decompress):
    if path in (None, "-"):
        return "-"
    if decompress:
        return path[:-4] if path.endswith(".zst") else path + ".out"
    return path + ".zst"


def human(n):
    return f"{n}   B"


def print_help():
    print("""*** Zstandard CLI (64-bit) v1.6.0, by Yann Collet ***

Compress or decompress the INPUT file(s); reads from STDIN if INPUT is `-` or not provided.

Usage: executable [OPTIONS...] [INPUT... | -] [-o OUTPUT]

Options:
  -o OUTPUT                     Write output to a single file, OUTPUT.
  -k, --keep                    Preserve INPUT file(s). [Default]
  --rm                          Remove INPUT file(s) after successful (de)compression to file.
  -#                            Desired compression level. [Default: 3]
  -d, --decompress              Perform decompression.
  -f, --force                   Disable input and output checks.
  -h                            Display short usage and exit.
  -H, --help                    Display full help and exit.
  -V, --version                 Display the program version and exit.
  -c, --stdout                  Write to STDOUT and keep the INPUT file(s).
  -l                            Print information about Zstandard-compressed files.
  --test                        Test compressed file integrity.""")


def parse_args(argv):
    args = {
        "decompress": False, "stdout": False, "force": False, "rm": False,
        "list": False, "test": False, "output": None, "quiet": 0,
        "pass_through": False, "train": False, "filelist": None,
        "output_dir_flat": None, "recursive": False, "inputs": []
    }
    i = 0
    while i < len(argv):
        a = argv[i]
        if a == "--":
            args["inputs"].extend(argv[i + 1:])
            break
        elif a in ("-h", "-H", "--help"):
            print_help()
            sys.exit(0)
        elif a in ("-V", "--version"):
            print("*** Zstandard CLI (64-bit) v1.6.0, by Yann Collet ***")
            sys.exit(0)
        elif a in ("-d", "--decompress"):
            args["decompress"] = True
        elif a in ("-c", "--stdout"):
            args["stdout"] = True
        elif a in ("-f", "--force"):
            args["force"] = True
        elif a in ("-k", "--keep"):
            args["rm"] = False
        elif a == "--rm":
            args["rm"] = True
        elif a in ("-l", "--list"):
            args["list"] = True
        elif a == "-r":
            args["recursive"] = True
        elif a == "--train":
            args["train"] = True
        elif a in ("-t", "--test", "--test"):
            args["test"] = True
            args["decompress"] = True
        elif a == "--pass-through":
            args["pass_through"] = True
        elif a == "--no-pass-through":
            args["pass_through"] = False
        elif a == "-o":
            i += 1
            if i >= len(argv):
                raise ZstdError("-o: missing output")
            args["output"] = argv[i]
        elif a == "--filelist":
            i += 1
            if i >= len(argv):
                raise ZstdError("--filelist: missing list file")
            args["filelist"] = argv[i]
        elif a.startswith("--filelist="):
            args["filelist"] = a.split("=", 1)[1]
        elif a == "--output-dir-flat":
            i += 1
            if i >= len(argv):
                raise ZstdError("--output-dir-flat: missing directory")
            args["output_dir_flat"] = argv[i]
        elif a.startswith("--output-dir-flat="):
            args["output_dir_flat"] = a.split("=", 1)[1]
        elif a.startswith("-o") and len(a) > 2:
            args["output"] = a[2:]
        elif a.startswith("-q"):
            args["quiet"] += len(a) - 1
        elif a.startswith("-") and len(a) > 1:
            # Accept common compression tuning flags; this implementation always stores raw blocks.
            if a.startswith(("-T", "-b", "-e", "-i", "-M", "-D", "--fast", "--ultra",
                             "--long", "--adapt", "--rsyncable", "--format", "--memory",
                             "--no-check", "--check", "--progress", "--no-progress",
                             "--single-thread", "--auto-threads", "--jobsize",
                             "--stream-size", "--size-hint", "--exclude-compressed",
                             "--maxdict", "--dictID", "--train-cover", "--train-fastcover",
                             "--train-legacy")):
                if a in ("-D", "--maxdict", "--dictID"):
                    i += 1
            elif a[1:].isdigit():
                pass
            else:
                # Short option groups like -dcq.
                for ch in a[1:]:
                    if ch == "d":
                        args["decompress"] = True
                    elif ch == "c":
                        args["stdout"] = True
                    elif ch == "f":
                        args["force"] = True
                    elif ch == "q":
                        args["quiet"] += 1
                    elif ch == "t":
                        args["test"] = True
                        args["decompress"] = True
                    elif ch == "l":
                        args["list"] = True
                    elif ch.isdigit():
                        pass
                    else:
                        raise ZstdError(f"unknown option: -{ch}")
        else:
            args["inputs"].append(a)
        i += 1
    if args["filelist"]:
        with open(args["filelist"], "r", encoding="utf-8") as f:
            args["inputs"].extend(line.rstrip("\n") for line in f if line.rstrip("\n"))
    if args["recursive"]:
        expanded = []
        for item in args["inputs"]:
            if os.path.isdir(item):
                for root, _, files in os.walk(item):
                    for name in files:
                        expanded.append(os.path.join(root, name))
            else:
                expanded.append(item)
        args["inputs"] = expanded
    if not args["inputs"] and not args["train"]:
        args["inputs"] = ["-"]
        args["stdout"] = True
    return args


def main(argv):
    try:
        args = parse_args(argv)
        if args["train"]:
            samples = bytearray()
            for path in args["inputs"]:
                if path != "-" and os.path.isfile(path):
                    samples += read_input(path)[:4096]
            name = args["output"] or "dictionary"
            # This is a small deterministic placeholder. Raw-block compression does not need it,
            # but documented dictionary workflows expect an output file to be created.
            write_output(name, b"\x37\xa4\x30\xec" + samples[:112640], args["force"])
            return 0
        if args["list"]:
            print("Frames  Skips  Compressed  Uncompressed  Ratio  Check  Filename")
            for path in args["inputs"]:
                data = read_input(path)
                frames, skips, csize, usize = inspect_frames(data)
                ratio = (usize / csize) if csize else 0
                print(f"{frames:6d} {skips:6d} {human(csize):>11} {human(usize):>11} {ratio:6.3f}  --     {path}")
            return 0
        for path in args["inputs"]:
            data = read_input(path)
            if args["decompress"]:
                result = decompress_bytes(data, args["pass_through"] or args["force"])
            else:
                result = compress_bytes(data)
            if args["test"]:
                continue
            outpath = "-" if args["stdout"] else (args["output"] or default_output_name(path, args["decompress"]))
            if outpath != "-" and args["output_dir_flat"]:
                os.makedirs(args["output_dir_flat"], exist_ok=True)
                outpath = os.path.join(args["output_dir_flat"], os.path.basename(outpath))
            write_output(outpath, result, args["force"])
            if args["rm"] and path not in (None, "-") and outpath != "-":
                os.unlink(path)
        return 0
    except BrokenPipeError:
        return 0
    except Exception as e:
        try:
            quiet = parse_args(argv).get("quiet", 0)
        except Exception:
            quiet = 0
        if quiet < 2:
            print(f"executable: error: {e}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
