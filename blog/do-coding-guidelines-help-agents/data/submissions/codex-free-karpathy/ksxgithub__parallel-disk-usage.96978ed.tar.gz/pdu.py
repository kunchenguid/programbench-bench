#!/usr/bin/env python3
import os, sys, json, math
from dataclasses import dataclass, field

VERSION = "0.21.1"
SCHEMA = "2024-11-02"

HELP_LONG = """Summarize disk usage of the set of files, recursively for directories.

Copyright: Apache-2.0 © 2021 Hoàng Văn Khải <https://github.com/KSXGitHub/>
Sponsor: https://github.com/sponsors/KSXGitHub

Usage: executable [OPTIONS] [FILES]...

Arguments:
  [FILES]...
          List of files and/or directories

Options:
      --json-input
          Read JSON data from stdin

      --json-output
          Print JSON data instead of an ASCII chart

  -b, --bytes-format <BYTES_FORMAT>
          How to display the numbers of bytes

          Possible values:
          - plain:  Display plain number of bytes without units
          - metric: Use metric scale, i.e. 1K = 1000B, 1M = 1000K, and so on
          - binary: Use binary scale, i.e. 1K = 1024B, 1M = 1024K, and so on
          
          [default: metric]

  -H, --deduplicate-hardlinks
          Detect and subtract the sizes of hardlinks from their parent directory totals
          
          [aliases: --detect-links, --dedupe-links]

      --top-down
          Print the tree top-down instead of bottom-up

      --align-right
          Set the root of the bars to the right

  -q, --quantity <QUANTITY>
          Aspect of the files/directories to be measured

          Possible values:
          - apparent-size: Measure apparent sizes
          - block-size:    Measure block sizes (block-count * 512B)
          - block-count:   Count numbers of blocks
          
          [default: block-size]

  -d, --max-depth <MAX_DEPTH>
          Maximum depth to display the data. Could be either "inf" or a positive integer
          
          [default: 10]
          [aliases: --depth]

  -w, --total-width <TOTAL_WIDTH>
          Width of the visualization
          
          [aliases: --width]

      --column-width <TREE_WIDTH> <BAR_WIDTH>
          Maximum widths of the tree column and width of the bar column

  -m, --min-ratio <MIN_RATIO>
          Minimal size proportion required to appear
          
          [default: 0.01]

      --no-sort
          Do not sort the branches in the tree

  -s, --silent-errors
          Prevent filesystem error messages from appearing in stderr
          
          [aliases: --no-errors]

  -p, --progress
          Report progress being made at the expense of performance

      --threads <THREADS>
          Set the maximum number of threads to spawn. Could be either "auto", "max", or a positive integer
          
          [default: auto]

      --omit-json-shared-details
          Do not output `.shared.details` in the JSON output

      --omit-json-shared-summary
          Do not output `.shared.summary` in the JSON output

  -h, --help
          Print help (see a summary with '-h')

  -V, --version
          Print version

Examples:
    Show disk usage chart of current working directory
    $ pdu

    Show disk usage chart of a single file or directory
    $ pdu path/to/file/or/directory

    Compare disk usages of multiple files and/or directories
    $ pdu file.txt dir/

    Show chart in apparent sizes instead of block sizes
    $ pdu --quantity=apparent-size

    Detect and subtract the sizes of hardlinks from their parent nodes
    $ pdu --deduplicate-hardlinks

    Show sizes in plain numbers instead of metric units
    $ pdu --bytes-format=plain

    Show sizes in base 2¹⁰ units (binary) instead of base 10³ units (metric)
    $ pdu --bytes-format=binary

    Show disk usage chart of all entries regardless of size
    $ pdu --min-ratio=0

    Only show disk usage chart of entries whose size is at least 5% of total
    $ pdu --min-ratio=0.05

    Show disk usage data as JSON instead of chart
    $ pdu --min-ratio=0 --max-depth=inf --json-output | jq

    Visualize existing JSON representation of disk usage data
    $ pdu --json-input < disk-usage.json
"""

HELP_SHORT = """Summarize disk usage of the set of files, recursively for directories.

Usage: executable [OPTIONS] [FILES]...

Arguments:
  [FILES]...  List of files and/or directories

Options:
      --json-input
          Read JSON data from stdin
      --json-output
          Print JSON data instead of an ASCII chart
  -b, --bytes-format <BYTES_FORMAT>
          How to display the numbers of bytes [default: metric] [possible values: plain, metric, binary]
  -H, --deduplicate-hardlinks
          Detect and subtract the sizes of hardlinks from their parent directory totals [aliases: --detect-links, --dedupe-links]
      --top-down
          Print the tree top-down instead of bottom-up
      --align-right
          Set the root of the bars to the right
  -q, --quantity <QUANTITY>
          Aspect of the files/directories to be measured [default: block-size] [possible values: apparent-size, block-size, block-count]
  -d, --max-depth <MAX_DEPTH>
          Maximum depth to display the data. Could be either "inf" or a positive integer [default: 10] [aliases: --depth]
  -w, --total-width <TOTAL_WIDTH>
          Width of the visualization [aliases: --width]
      --column-width <TREE_WIDTH> <BAR_WIDTH>
          Maximum widths of the tree column and width of the bar column
  -m, --min-ratio <MIN_RATIO>
          Minimal size proportion required to appear [default: 0.01]
      --no-sort
          Do not sort the branches in the tree
  -s, --silent-errors
          Prevent filesystem error messages from appearing in stderr [aliases: --no-errors]
  -p, --progress
          Report progress being made at the expense of performance
      --threads <THREADS>
          Set the maximum number of threads to spawn. Could be either "auto", "max", or a positive integer [default: auto]
      --omit-json-shared-details
          Do not output `.shared.details` in the JSON output
      --omit-json-shared-summary
          Do not output `.shared.summary` in the JSON output
  -h, --help
          Print help (see a summary with '-h')
  -V, --version
          Print version
"""

@dataclass
class Node:
    name: str
    size: int = 0
    children: list = field(default_factory=list)
    path: str = ""
    key: tuple = None
    nlink: int = 1
    is_dir: bool = False

    def to_json(self):
        return {"name": self.name, "size": int(self.size), "children": [c.to_json() for c in self.children]}


def err(msg):
    print(msg, file=sys.stderr)

class Opt:
    def __init__(self):
        self.json_input=False; self.json_output=False; self.bytes_format='metric'; self.dedupe=False
        self.top_down=False; self.align_right=False; self.quantity='block-size'; self.max_depth=10
        self.total_width=None; self.column_width=None; self.min_ratio=0.01; self.no_sort=False
        self.silent=False; self.progress=False; self.threads='auto'; self.omit_details=False; self.omit_summary=False
        self.files=[]

def parse(argv):
    o=Opt(); i=0
    def need(opt):
        nonlocal i
        if i+1>=len(argv):
            err(f"error: a value is required for '{opt} <VALUE>' but none was supplied\n\nFor more information, try '--help'."); sys.exit(2)
        i+=1; return argv[i]
    while i < len(argv):
        a=argv[i]
        if a == '--':
            o.files += argv[i+1:]; break
        if a in ('--help',): print(HELP_LONG, end=''); sys.exit(0)
        if a == '-h': print(HELP_SHORT, end=''); sys.exit(0)
        if a in ('--version','-V'): print(f"pdu {VERSION}"); sys.exit(0)
        if a == '--json-input': o.json_input=True
        elif a == '--json-output': o.json_output=True
        elif a in ('-H','--deduplicate-hardlinks','--detect-links','--dedupe-links'): o.dedupe=True
        elif a == '--top-down': o.top_down=True
        elif a == '--align-right': o.align_right=True
        elif a == '--no-sort': o.no_sort=True
        elif a in ('-s','--silent-errors','--no-errors'): o.silent=True
        elif a in ('-p','--progress'): o.progress=True
        elif a == '--omit-json-shared-details': o.omit_details=True
        elif a == '--omit-json-shared-summary': o.omit_summary=True
        elif a.startswith('--bytes-format=') or a.startswith('-b='):
            o.bytes_format=a.split('=',1)[1]
        elif a in ('--bytes-format','-b'):
            o.bytes_format=need(a)
        elif a.startswith('--quantity=') or a.startswith('-q='):
            o.quantity=a.split('=',1)[1]
        elif a in ('--quantity','-q'):
            o.quantity=need(a)
        elif a.startswith('--max-depth=') or a.startswith('--depth=') or a.startswith('-d='):
            val=a.split('=',1)[1]; o.max_depth=parse_depth(val)
        elif a in ('--max-depth','--depth','-d'):
            o.max_depth=parse_depth(need(a))
        elif a.startswith('--total-width=') or a.startswith('--width=') or a.startswith('-w='):
            o.total_width=parse_positive(a.split('=',1)[1], a.split('=',1)[0], 'TOTAL_WIDTH')
        elif a in ('--total-width','--width','-w'):
            o.total_width=parse_positive(need(a), a, 'TOTAL_WIDTH')
        elif a == '--column-width':
            if i+2>=len(argv) or argv[i+1].startswith('-') or argv[i+2].startswith('-'):
                got = 0 if i+1>=len(argv) or argv[i+1].startswith('-') else 1
                err(f"error: 2 values required for '--column-width <TREE_WIDTH> <BAR_WIDTH>' but {got} was provided\n\nUsage: executable [OPTIONS] [FILES]...\n\nFor more information, try '--help'."); sys.exit(2)
            o.column_width=(parse_positive(argv[i+1], '--column-width', 'TREE_WIDTH'), parse_positive(argv[i+2], '--column-width', 'BAR_WIDTH')); i+=2
        elif a.startswith('--min-ratio=') or a.startswith('-m='):
            o.min_ratio=parse_float(a.split('=',1)[1], '--min-ratio')
        elif a in ('--min-ratio','-m'):
            o.min_ratio=parse_float(need(a), a)
        elif a.startswith('--threads='):
            o.threads=parse_threads(a.split('=',1)[1])
        elif a == '--threads':
            o.threads=parse_threads(need(a))
        elif a.startswith('-'):
            err(f"error: unexpected argument '{a}' found\n\n  tip: to pass '{a}' as a value, use '-- {a}'\n\nUsage: executable [OPTIONS] [FILES]...\n\nFor more information, try '--help'."); sys.exit(2)
        else:
            o.files.append(a)
        i+=1
    if o.bytes_format not in ('plain','metric','binary'):
        err(f"error: invalid value '{o.bytes_format}' for '--bytes-format <BYTES_FORMAT>'\n  [possible values: plain, metric, binary]\n\nFor more information, try '--help'."); sys.exit(2)
    if o.quantity not in ('apparent-size','block-size','block-count'):
        err(f"error: invalid value '{o.quantity}' for '--quantity <QUANTITY>'\n  [possible values: apparent-size, block-size, block-count]\n\nFor more information, try '--help'."); sys.exit(2)
    return o

def parse_positive(v, opt, name):
    try: n=int(v)
    except Exception:
        err(f"error: invalid value '{v}' for '{opt} <{name}>': invalid digit found in string\n\nFor more information, try '--help'."); sys.exit(2)
    if n<=0:
        err(f"error: invalid value '{v}' for '{opt} <{name}>': Value is not a positive integer\n\nFor more information, try '--help'."); sys.exit(2)
    return n

def parse_depth(v):
    if v == 'inf': return None
    try: n=int(v)
    except Exception:
        err(f"error: invalid value '{v}' for '--max-depth <MAX_DEPTH>': Value is neither \"inf\" nor a positive integer: invalid digit found in string\n\nFor more information, try '--help'."); sys.exit(2)
    if n<=0:
        detail='number would be zero for non-zero type' if n==0 else 'invalid digit found in string'
        err(f"error: invalid value '{v}' for '--max-depth <MAX_DEPTH>': Value is neither \"inf\" nor a positive integer: {detail}\n\nFor more information, try '--help'."); sys.exit(2)
    return n

def parse_float(v,opt):
    try: return float(v)
    except Exception:
        err(f"error: invalid value '{v}' for '{opt} <MIN_RATIO>': invalid float literal\n\nFor more information, try '--help'."); sys.exit(2)

def parse_threads(v):
    if v in ('auto','max'): return v
    try: n=int(v)
    except Exception:
        err(f"error: invalid value '{v}' for '--threads <THREADS>': Value is neither \"auto\", \"max\", nor a number: invalid digit found in string\n\nFor more information, try '--help'."); sys.exit(2)
    if n<=0:
        err(f"error: invalid value '{v}' for '--threads <THREADS>': Value is neither \"auto\", \"max\", nor a number: number would be zero for non-zero type\n\nFor more information, try '--help'."); sys.exit(2)
    return v

def measure(st, quantity):
    if quantity == 'apparent-size': return int(st.st_size)
    if quantity == 'block-count': return int(getattr(st, 'st_blocks', 0))
    return int(getattr(st, 'st_blocks', 0)) * 512

def scan(path, opt, hardlinks):
    try:
        st=os.lstat(path)
    except OSError as e:
        if not opt.silent: err(f"[error] symlink_metadata {json.dumps(path)}: {e.strerror} (os error {e.errno})")
        return Node(path,0,[],path)
    name = path.rstrip('/') or path
    base = os.path.basename(name) if os.path.dirname(name) else name
    if path in ('.','..') or '/' in path.rstrip('/'):
        node_name = path.rstrip('/') or path
    else:
        node_name = base
    size = measure(st,opt.quantity)
    key=(st.st_dev, st.st_ino)
    n=Node(node_name, size, [], path, key, int(getattr(st, "st_nlink", 1)), os.path.isdir(path) and not os.path.islink(path))
    if opt.dedupe and st.st_nlink>1 and not os.path.isdir(path):
        hardlinks.setdefault(key, {'ino': st.st_ino, 'size': size, 'links': st.st_nlink, 'paths': []})['paths'].append(path)
    if os.path.isdir(path) and not os.path.islink(path):
        try:
            entries=list(os.scandir(path))
        except OSError as e:
            if not opt.silent: err(f"[error] read_dir {json.dumps(path)}: {e.strerror} (os error {e.errno})")
            entries=[]
        total=size; children=[]
        for ent in entries:
            child=scan(os.path.join(path, ent.name), opt, hardlinks)
            child.name=ent.name
            children.append(child); total += child.size
        n.size=total; n.children=children
    return n

def sort_tree(n,opt):
    if not opt.no_sort:
        n.children.sort(key=lambda c: c.size, reverse=True)
    for c in n.children: sort_tree(c,opt)

def prune(n, opt, root_size, depth=1):
    nn=Node(n.name,n.size,[],n.path)
    if opt.max_depth is not None and depth>=opt.max_depth:
        return nn
    for c in n.children:
        if root_size == 0 or opt.min_ratio <= 0 or (c.size / root_size) >= opt.min_ratio:
            nn.children.append(prune(c,opt,root_size,depth+1))
    return nn

def from_json_tree(d):
    return Node(str(d.get('name','')), int(d.get('size',0)), [from_json_tree(x) for x in d.get('children',[])])

def apply_dedupe(node, seen):
    subtract = 0
    for c in node.children:
        subtract += apply_dedupe(c, seen)
    if node.key is not None and node.nlink > 1 and not node.is_dir:
        if node.key in seen:
            subtract += node.size
        else:
            seen.add(node.key)
    if node.children and subtract:
        node.size -= subtract
    return subtract

def hardlink_shared(hardlinks, opt):
    details=[]
    for data in hardlinks.values():
        paths=data['paths']
        if len(paths)>1:
            details.append({'ino': data['ino'], 'size': int(data['size']), 'links': int(data['links']), 'paths': list(reversed(paths))})
    details.sort(key=lambda x: x['ino'])
    shared_size=sum(d['size'] for d in details)
    all_links=sum(d['links'] for d in details)
    detected=sum(len(d['paths']) for d in details)
    return details, {'inodes':len(details),'exclusive_inodes':len(details),'all_links':all_links,'detected_links':detected,'exclusive_links':detected,'shared_size':shared_size,'exclusive_shared_size':shared_size}

def fmt_size(n, mode):
    n=int(n)
    if mode=='plain': return str(n)
    base=1000 if mode=='metric' else 1024
    units=['','K','M','G','T','P','E']
    x=float(n); u=0
    while abs(x)>=base and u<len(units)-1:
        x/=base; u+=1
    if u==0: return str(n)
    return f"{x:.1f}{units[u]}"

def flatten_bottom(n, prefix='', is_last=True, root=True):
    rows=[]
    for idx,c in enumerate(reversed(n.children)):
        orig_index=len(n.children)-1-idx
        child_last=(orig_index==len(n.children)-1)
        rows += flatten_bottom(c, prefix + ('  ' if root else ('│ ' if not is_last else '  ')), child_last, False)
    conn='┌─┴' if n.children else '┌──'
    if root and n.children: conn='┌─┴'
    elif not root and n.children: conn='├─┴' if not is_last else '└─┴'
    elif not root: conn='├──' if not is_last else '└──'
    rows.append((n, prefix+conn))
    return rows

def flatten_top(n, prefix='', is_last=True, root=True):
    if n.children: conn='└─┬' if root else ('└─┬' if is_last else '├─┬')
    else: conn='└──' if is_last else '├──'
    rows=[(n,prefix+conn)]
    for i,c in enumerate(n.children):
        rows += flatten_top(c, prefix + ('  ' if root else ('  ' if is_last else '│ ')), i==len(n.children)-1, False)
    return rows

def chart(root,opt):
    rows = flatten_top(root) if opt.top_down else flatten_bottom(root)
    size_strs=[fmt_size(n.size,opt.bytes_format) for n,_ in rows]
    sw=max(len(s) for s in size_strs) if size_strs else 0
    tree_strs=[conn+n.name for n,conn in rows]
    tw=max(len(s) for s in tree_strs) if tree_strs else 0
    if opt.column_width: tw=min(tw,opt.column_width[0]); bw=opt.column_width[1]
    else:
        totalw=opt.total_width or 120
        bw=max(1,totalw - sw - tw - 9)
    out=[]; total=root.size or 1
    for (n,_),ss,ts in zip(rows,size_strs,tree_strs):
        if len(ts)>tw: ts=ts[:tw]
        ratio=0 if root.size==0 else n.size/root.size
        full=int(round(ratio*bw)); full=max(0,min(bw,full))
        bar='█'*full
        if full<bw and n.size>0 and full==0: bar='░'*bw
        elif full<bw and n.size>0: bar += '░'*(bw-full)
        else: bar += ' '*(bw-full)
        pct=int(round(ratio*100))
        if opt.align_right:
            bar=bar.rjust(bw)
        out.append(f"{ss.rjust(sw)} {ts.ljust(tw)}│{bar}│{str(pct).rjust(3)}%")
    return "\r\r" + "\n".join(out) + "\n"

def main():
    opt=parse(sys.argv[1:])
    shared_details=[]; shared_summary=None
    if opt.json_input:
        try: data=json.load(sys.stdin)
        except Exception as e: err(f"[error] JSON input: {e}"); sys.exit(1)
        root=from_json_tree(data.get('tree', data))
        unit=data.get('unit','bytes')
    else:
        files=opt.files or ['.']
        hardlinks={}
        nodes=[scan(f,opt,hardlinks) for f in files]
        if len(nodes)==1: root=nodes[0]
        else: root=Node('(total)', sum(n.size for n in nodes), nodes)
        unit='blocks' if opt.quantity=='block-count' else 'bytes'
        if opt.dedupe:
            apply_dedupe(root, set())
            if len(nodes) > 1:
                root.size = sum(n.size for n in root.children)
            shared_details, shared_summary = hardlink_shared(hardlinks,opt)
    sort_tree(root,opt)
    root=prune(root,opt,root.size)
    if opt.json_output:
        obj={"schema-version":SCHEMA,"pdu":VERSION,"unit":unit,"tree":root.to_json()}
        if opt.dedupe and (shared_details or shared_summary):
            sh={}
            if not opt.omit_details: sh['details']=shared_details
            if not opt.omit_summary: sh['summary']=shared_summary
            if sh: obj['shared']=sh
        print("\r\r" + json.dumps(obj,separators=(',',':')))
    else:
        sys.stdout.write(chart(root,opt))

if __name__=='__main__': main()
