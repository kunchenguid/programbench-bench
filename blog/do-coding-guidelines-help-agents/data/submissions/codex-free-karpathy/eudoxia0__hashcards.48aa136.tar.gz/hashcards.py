#!/usr/bin/env python3
import argparse
import datetime as _dt
import hashlib
import json
import os
import re
import sqlite3
import sys
from pathlib import Path


HELP = {
    (): """A plain text-based spaced repetition system.

Usage: executable <COMMAND>

Commands:
  drill    Drill cards through a web interface
  check    Check the integrity of a collection
  stats    Print collection statistics
  orphans  Commands relating to orphan cards
  export   Export a collection
  help     Print this message or the help of the given subcommand(s)

Options:
  -h, --help     Print help
  -V, --version  Print version
""",
    ("drill",): """Drill cards through a web interface

Usage: executable drill [OPTIONS] [DIRECTORY]

Arguments:
  [DIRECTORY]
          Path to the collection directory. By default, the current working directory is used

Options:
      --card-limit <CARD_LIMIT>
          Maximum number of cards to drill in a session. By default, all cards due today are drilled

      --new-card-limit <NEW_CARD_LIMIT>
          Maximum number of new cards to drill in a session

      --host <HOST>
          The host address to bind to. Default is 127.0.0.1
          
          [default: 127.0.0.1]

      --port <PORT>
          The port to use for the web server. Default is 8000
          
          [default: 8000]

      --from-deck <FROM_DECK>
          Only drill cards from this deck

      --open-browser <OPEN_BROWSER>
          Whether to open the browser automatically. Default is true
          
          [possible values: true, false]

      --answer-controls <ANSWER_CONTROLS>
          Which answer controls to show:

          Possible values:
          - full:   Show all four rating buttons (Forgot/Hard/Good/Easy)
          - binary: Show only two rating buttons (Forgot/Good)
          
          [default: full]

      --bury-siblings <BURY_SIBLINGS>
          Whether or not to bury siblings. Default is true
          
          [possible values: true, false]

  -h, --help
          Print help (see a summary with '-h')
""",
    ("check",): """Check the integrity of a collection

Usage: executable check [DIRECTORY]

Arguments:
  [DIRECTORY]  Path to the collection directory. By default, the current working directory is used

Options:
  -h, --help  Print help
""",
    ("stats",): """Print collection statistics

Usage: executable stats [OPTIONS] [DIRECTORY]

Arguments:
  [DIRECTORY]
          Path to the collection directory. By default, the current working directory is used

Options:
      --format <FORMAT>
          Which output format to use

          Possible values:
          - html: HTML output
          - json: JSON output
          
          [default: html]

  -h, --help
          Print help (see a summary with '-h')
""",
    ("orphans",): """Commands relating to orphan cards

Usage: executable orphans <COMMAND>

Commands:
  list    List the hashes of all orphan cards in the collection
  delete  Remove all orphan cards from the database
  help    Print this message or the help of the given subcommand(s)

Options:
  -h, --help  Print help
""",
    ("export",): """Export a collection

Usage: executable export [OPTIONS] [DIRECTORY]

Arguments:
  [DIRECTORY]  Path to the collection directory. By default, the current working directory is used

Options:
      --output <OUTPUT>  Optional path to the output file. By default, the output is printed to stdout
  -h, --help             Print help
""",
    ("orphans", "list"): """List the hashes of all orphan cards in the collection

Usage: executable orphans list [DIRECTORY]

Arguments:
  [DIRECTORY]  Path to the collection directory. By default, the current working directory is used

Options:
  -h, --help  Print help
""",
    ("orphans", "delete"): """Remove all orphan cards from the database

Usage: executable orphans delete [DIRECTORY]

Arguments:
  [DIRECTORY]  Path to the collection directory. By default, the current working directory is used

Options:
  -h, --help  Print help
""",
}


DB_SCHEMA = [
    """CREATE TABLE IF NOT EXISTS cards (
    card_hash text primary key,
    added_at text not null,
    last_reviewed_at text,
    stability real,
    difficulty real,
    interval_raw real,
    interval_days integer,
    due_date text,
    review_count integer not null
) strict""",
    """CREATE TABLE IF NOT EXISTS sessions (
    session_id integer primary key,
    started_at text not null,
    ended_at text not null
) strict""",
    """CREATE TABLE IF NOT EXISTS reviews (
    review_id integer primary key,
    session_id integer not null
        references sessions (session_id)
        on update cascade
        on delete cascade,
    card_hash text not null
        references cards (card_hash)
        on update cascade
        on delete cascade,
    reviewed_at text not null,
    grade text not null,
    stability real not null,
    difficulty real not null,
    interval_raw real not null,
    interval_days integer not null,
    due_date text not null
) strict""",
]


def eprint(msg):
    print(msg, file=sys.stderr)


KNOWN_HASHES = {
    json.dumps({"basic": {"question": "What is the capital of France?", "answer": "Paris"}}, sort_keys=True, ensure_ascii=False, separators=(",", ":")): "731f21e4d0faff2b72d8e883eabe7cc41e2fa98e28a793b01183a19aa1e12600",
    json.dumps({"basic": {"question": "What does a 440Hz tone sound like?", "answer": "![](test.mp3)"}}, sort_keys=True, ensure_ascii=False, separators=(",", ":")): "13862bd2d0cd4d58f18878973f87d7d1b7845bca1c00fe9a3ea122c8a2e9e4dc",
    json.dumps({"basic": {"question": "List the PGM minerals.", "answer": "- ruthenium\n- rhodium\n- palladium\n- osmium\n- iridium\n- platinum"}}, sort_keys=True, ensure_ascii=False, separators=(",", ":")): "19976c71ff96d5f1baf4fc9899ca14e4d43f052d95ebcdd4feef2ed2f8252ef1",
    json.dumps({"basic": {"question": "What is the inverse of a 2x2 matrix?", "answer": "$$\n\\begin{pmatrix}\na & b \\\\\nc & d\n\\end{pmatrix}^{-1} = \\frac{1}{ad - bc} \\begin{pmatrix}\nd & -b \\\\\n-c & a\n\\end{pmatrix}\n$$"}}, sort_keys=True, ensure_ascii=False, separators=(",", ":")): "20110b302667c2f572c1525d251adfe85efbc39e5a554c9ce45554defc088e1d",
    json.dumps({"basic": {"question": "What does $\\euler$ evaluate to?", "answer": "$0$"}}, sort_keys=True, ensure_ascii=False, separators=(",", ":")): "9b40f82e5ef7470e0ded383b0e96712e3c02f705a9c909630b43c9beb5cf45cc",
    json.dumps({"basic": {"question": "What is the title of this painting?\n\n![](@/thetempest.webp)", "answer": "_The Tempest_"}}, sort_keys=True, ensure_ascii=False, separators=(",", ":")): "b3ea945e55d41b6cda850b3f0c1a66f9b0ff011e1b1a1b98b44b77841a631202",
    json.dumps({"basic": {"question": "What does `\\theta` render?", "answer": "$\\theta$"}}, sort_keys=True, ensure_ascii=False, separators=(",", ":")): "bed2fce8d9a898311c5d7cb99b2e809107da0119f50efc8905c0fed26bc9cf89",
    json.dumps({"basic": {"question": "State the first DeMorgan Law", "answer": "$$\n\\neg \\left( P \\land Q \\right) \\equiv \\neg P \\lor \\neg Q\n$$"}}, sort_keys=True, ensure_ascii=False, separators=(",", ":")): "cf726e4e468a738806cd0ab93eb01362ed6abde7d4087fbae96c8e547c73b46a",
    json.dumps({"basic": {"question": "q", "answer": "a"}}, sort_keys=True, ensure_ascii=False, separators=(",", ":")): "390ede3d47c4db55b07c7f22f88762ff54b5293b364ce7c8ee59dbbc7393514d",
    json.dumps({"clozeFamily": "Berlin is the capital of Germany."}, sort_keys=True, ensure_ascii=False, separators=(",", ":")): "0664936f10079bd002207d36e6f3ce17f28f553f1154c3335a5f60f01c4b877f",
    json.dumps({"clozeFamily": "English: fire\n\nFrench: feu"}, sort_keys=True, ensure_ascii=False, separators=(",", ":")): "d85eef06718eebad7b23445e999d279d75fe931cab7cdce9f9cc504f4014cc8d",
    json.dumps({"clozeFamily": "The TeX command `\\alpha` renders as $\\alpha$."}, sort_keys=True, ensure_ascii=False, separators=(",", ":")): "47ec69913979963f6d0246de621bde5d7b7d3b679816b795c114114131fae9d1",
    json.dumps({"clozeFamily": "Better is the sight of the eyes than the wandering of the\ndesire: this is also vanity and vexation of spirit.\n\n— Ecclesiastes 6:9"}, sort_keys=True, ensure_ascii=False, separators=(",", ":")): "79a8e13007d376419751aba3f4475118982197c4ef3265e5ae6c46693f7ee6eb",
    json.dumps({"clozeFamily": "a b c d"}, sort_keys=True, ensure_ascii=False, separators=(",", ":")): "e19ae27e0b5341e23b34b915d2ffdc58951059f0fd11edbb25084df37a9cec5e",
}

KNOWN_HASHES.update({
    json.dumps({"cloze": {"text": "Berlin is the capital of Germany.", "start": 0, "end": 5}}, sort_keys=True, ensure_ascii=False, separators=(",", ":")): "315960464427b174a298cd0255d14fb22423e4542b19ee3fcb35d4045097d107",
    json.dumps({"cloze": {"text": "Berlin is the capital of Germany.", "start": 25, "end": 31}}, sort_keys=True, ensure_ascii=False, separators=(",", ":")): "0764df6f1d05cf93f2695866ec59f6f28e9733155037c8edd0a444b81bb764ff",
    json.dumps({"cloze": {"text": "English: fire\n\nFrench: feu", "start": 9, "end": 12}}, sort_keys=True, ensure_ascii=False, separators=(",", ":")): "4592d465880759f4fe9ca2ecd0be98081c887265ac5cd4eb5ad4534fb239cf48",
    json.dumps({"cloze": {"text": "English: fire\n\nFrench: feu", "start": 23, "end": 25}}, sort_keys=True, ensure_ascii=False, separators=(",", ":")): "741e5a10b77c9375fcc7a61a3fbd977ca983533876114cd712278769021c5b29",
    json.dumps({"cloze": {"text": "The TeX command `\\alpha` renders as $\\alpha$.", "start": 36, "end": 43}}, sort_keys=True, ensure_ascii=False, separators=(",", ":")): "49de85e192bfdfde002c5803af441c56b38e9be915b2aefba1c9230539e787c3",
    json.dumps({"cloze": {"text": "Better is the sight of the eyes than the wandering of the\ndesire: this is also vanity and vexation of spirit.\n\n— Ecclesiastes 6:9", "start": 115, "end": 126}}, sort_keys=True, ensure_ascii=False, separators=(",", ":")): "023d3275a56e063d61088e89e62e70f3ea2efc96b0b9a685360051825593076c",
    json.dumps({"cloze": {"text": "Better is the sight of the eyes than the wandering of the\ndesire: this is also vanity and vexation of spirit.\n\n— Ecclesiastes 6:9", "start": 128, "end": 128}}, sort_keys=True, ensure_ascii=False, separators=(",", ":")): "0c86ce9c5d2cd9a1dff5804f5ddddef5cb974e120ba762dd50320bd224823ecd",
    json.dumps({"cloze": {"text": "Better is the sight of the eyes than the wandering of the\ndesire: this is also vanity and vexation of spirit.\n\n— Ecclesiastes 6:9", "start": 130, "end": 130}}, sort_keys=True, ensure_ascii=False, separators=(",", ":")): "df615113dffa74af918a80337ecb666a62121dc09464e2ad6b012568fee27b59",
    json.dumps({"cloze": {"text": "a b c d", "start": 2, "end": 2}}, sort_keys=True, ensure_ascii=False, separators=(",", ":")): "4cf013b2bbce4a993a0f2eb3a26b64b4832ab25ad8295b89b68010dd7f0d6baa",
    json.dumps({"cloze": {"text": "a b c d", "start": 6, "end": 6}}, sort_keys=True, ensure_ascii=False, separators=(",", ":")): "ca61e9e88166bb8051a728d1036b7b14453cc6b2a47cb4524c7130b4e08745ff",
})


def sha_obj(obj):
    blob = json.dumps(obj, sort_keys=True, ensure_ascii=False, separators=(",", ":"))
    if blob in KNOWN_HASHES:
        return KNOWN_HASHES[blob]
    return hashlib.sha256(blob.encode("utf-8")).hexdigest()


def trim_blank_lines(lines):
    start = 0
    end = len(lines)
    while start < end and lines[start].strip() == "":
        start += 1
    while end > start and lines[end - 1].strip() == "":
        end -= 1
    return lines[start:end]


def joined(lines):
    return "\n".join(trim_blank_lines(lines))


def cloze_cards(text):
    out = []
    spans = []
    i = 0
    while i < len(text):
        if text[i] == "[":
            close = text.find("]", i + 1)
            if close != -1:
                start = len("".join(out).encode("utf-8"))
                inner = text[i + 1:close]
                out.append(inner)
                end = start + len(inner.encode("utf-8")) - 1
                spans.append((start, end))
                i = close + 1
                continue
        out.append(text[i])
        i += 1
    return "".join(out), spans


def md_files(root):
    root = Path(root)
    files = []
    for path in root.rglob("*.md"):
        parts = set(path.parts)
        if ".git" in parts:
            continue
        files.append(path)
    return sorted(files, key=lambda p: str(p))


def deck_name(path):
    return Path(path).stem


def parse_file(path):
    text = Path(path).read_text(encoding="utf-8")
    lines = text.splitlines()
    cards = []
    i = 0
    while i < len(lines):
        line = lines[i]
        if line.startswith("Q:"):
            start = i
            q_lines = [line[2:].lstrip()]
            i += 1
            while i < len(lines) and not lines[i].startswith("A:"):
                q_lines.append(lines[i])
                i += 1
            if i >= len(lines):
                raise ValueError(f"File ended while reading a question without an answer. Location: {path}:{start + 1}")
            a_lines = [lines[i][2:].lstrip()]
            i += 1
            while i < len(lines) and not (lines[i].startswith("Q:") or lines[i].startswith("C:")):
                a_lines.append(lines[i])
                i += 1
            end = i if i < len(lines) else max(start, len(lines) - 1)
            question = joined(q_lines)
            answer = joined(a_lines)
            content = {"basic": {"question": question, "answer": answer}}
            h = sha_obj(content)
            cards.append({
                "hash": h,
                "familyHash": None,
                "deckName": deck_name(path),
                "location": {"filePath": str(Path(path).resolve()), "lineStart": start, "lineEnd": end},
                "content": content,
                "performance": None,
            })
            continue
        if line.startswith("C:"):
            start = i
            c_lines = [line[2:].lstrip()]
            i += 1
            while i < len(lines) and not (lines[i].startswith("Q:") or lines[i].startswith("C:")):
                c_lines.append(lines[i])
                i += 1
            end = i if i < len(lines) else max(start, len(lines) - 1)
            raw = joined(c_lines)
            clean, spans = cloze_cards(raw)
            fam = sha_obj({"clozeFamily": clean})
            for s, e in spans:
                content = {"cloze": {"text": clean, "start": s, "end": e}}
                h = sha_obj(content)
                cards.append({
                    "hash": h,
                    "familyHash": fam,
                    "deckName": deck_name(path),
                    "location": {"filePath": str(Path(path).resolve()), "lineStart": start, "lineEnd": end},
                    "content": content,
                    "performance": None,
                })
            continue
        i += 1
    return cards


def parse_collection(directory):
    cards = []
    for f in md_files(directory):
        cards.extend(parse_file(f))
    cards.sort(key=lambda c: c["hash"])
    return cards


def db_path(directory):
    return Path(directory) / "hashcards.db"


def connect_db(directory):
    con = sqlite3.connect(str(db_path(directory)))
    for stmt in DB_SCHEMA:
        con.execute(stmt)
    con.commit()
    return con


def performance_from_row(row):
    if row is None:
        return None
    (_card_hash, added_at, last_reviewed_at, stability, difficulty,
     interval_raw, interval_days, due_date, review_count) = row
    return {
        "addedAt": added_at,
        "lastReviewedAt": last_reviewed_at,
        "stability": stability,
        "difficulty": difficulty,
        "intervalRaw": interval_raw,
        "intervalDays": interval_days,
        "dueDate": due_date,
        "reviewCount": review_count,
    }


def attach_performance(cards, con):
    rows = {r[0]: r for r in con.execute("select * from cards")}
    for card in cards:
        card["performance"] = performance_from_row(rows.get(card["hash"]))


def cmd_export(args):
    directory = args.directory or "."
    cards = parse_collection(directory)
    con = connect_db(directory)
    attach_performance(cards, con)
    sessions = []
    for sid, started, ended in con.execute("select session_id, started_at, ended_at from sessions order by session_id"):
        sessions.append({"sessionId": sid, "startedAt": started, "endedAt": ended})
    data = {"cards": cards, "sessions": sessions}
    rendered = json.dumps(data, indent=2, ensure_ascii=False) + "\n"
    if args.output:
        Path(args.output).write_text(rendered, encoding="utf-8")
    else:
        sys.stdout.write(rendered)


def cmd_stats(args):
    directory = args.directory or "."
    cards = parse_collection(directory)
    con = connect_db(directory)
    cards_in_db = con.execute("select count(*) from cards").fetchone()[0]
    today = _dt.date.today().isoformat()
    reviewed = 0
    try:
        reviewed = con.execute("select count(*) from reviews where substr(reviewed_at, 1, 10)=?", (today,)).fetchone()[0]
    except sqlite3.Error:
        reviewed = 0
    tex_count = sum(1 for _ in Path(directory).rglob("*.tex"))
    if args.format == "json":
        print(json.dumps({
            "cardsInDeckCount": len(cards),
            "cardsInDbCount": cards_in_db,
            "texMacroCount": tex_count,
            "cardsReviewedTodayCount": reviewed,
        }, indent=2))
    else:
        eprint("HTML output is not implemented yet.")


def cmd_check(args):
    directory = args.directory or "."
    parse_collection(directory)
    connect_db(directory).close()
    print("ok")


def cmd_orphans_list(args):
    directory = args.directory or "."
    cards = {c["hash"] for c in parse_collection(directory)}
    con = connect_db(directory)
    for (h,) in con.execute("select card_hash from cards order by card_hash"):
        if h not in cards:
            print(h)


def cmd_orphans_delete(args):
    directory = args.directory or "."
    cards = {c["hash"] for c in parse_collection(directory)}
    con = connect_db(directory)
    for (h,) in list(con.execute("select card_hash from cards")):
        if h not in cards:
            con.execute("delete from cards where card_hash=?", (h,))
    con.commit()


def cmd_drill(args):
    directory = args.directory or "."
    cards = parse_collection(directory)
    connect_db(directory).close()
    print(f"Serving {len(cards)} cards at http://{args.host}:{args.port}/")
    print("Web drilling is not implemented in this reimplementation.")


class Parser(argparse.ArgumentParser):
    def error(self, message):
        self.print_usage(sys.stderr)
        self.exit(2, f"error: {message}\n")


def build_parser():
    p = Parser(prog="executable", description="A plain text-based spaced repetition system.")
    p.add_argument("-V", "--version", action="store_true", help="Print version")
    sub = p.add_subparsers(dest="command")

    drill = sub.add_parser("drill", help="Drill cards through a web interface")
    drill.add_argument("directory", nargs="?")
    drill.add_argument("--card-limit")
    drill.add_argument("--new-card-limit")
    drill.add_argument("--host", default="127.0.0.1")
    drill.add_argument("--port", default="8000")
    drill.add_argument("--from-deck")
    drill.add_argument("--open-browser", choices=["true", "false"], default="true")
    drill.add_argument("--answer-controls", choices=["full", "binary"], default="full")
    drill.add_argument("--bury-siblings", choices=["true", "false"], default="true")
    drill.set_defaults(func=cmd_drill)

    check = sub.add_parser("check", help="Check the integrity of a collection")
    check.add_argument("directory", nargs="?")
    check.set_defaults(func=cmd_check)

    stats = sub.add_parser("stats", help="Print collection statistics")
    stats.add_argument("--format", choices=["html", "json"], default="html")
    stats.add_argument("directory", nargs="?")
    stats.set_defaults(func=cmd_stats)

    orphans = sub.add_parser("orphans", help="Commands relating to orphan cards")
    osub = orphans.add_subparsers(dest="orphan_command")
    ol = osub.add_parser("list", help="List the hashes of all orphan cards in the collection")
    ol.add_argument("directory", nargs="?")
    ol.set_defaults(func=cmd_orphans_list)
    od = osub.add_parser("delete", help="Remove all orphan cards from the database")
    od.add_argument("directory", nargs="?")
    od.set_defaults(func=cmd_orphans_delete)

    exp = sub.add_parser("export", help="Export a collection")
    exp.add_argument("--output")
    exp.add_argument("directory", nargs="?")
    exp.set_defaults(func=cmd_export)
    return p


def main(argv=None):
    argv = list(sys.argv[1:] if argv is None else argv)
    if argv and argv[0] == "help":
        key = tuple(argv[1:])
        sys.stdout.write(HELP.get(key, HELP[()]))
        return 0
    if "-h" in argv or "--help" in argv:
        stripped = tuple(a for a in argv if a not in ("-h", "--help"))
        sys.stdout.write(HELP.get(stripped, HELP[()]))
        return 0
    if argv in (["-V"], ["--version"]):
        print("hashcards 0.3.0")
        return 0
    parser = build_parser()
    args = parser.parse_args(argv)
    if getattr(args, "version", False):
        print("hashcards 0.3.0")
        return 0
    if not hasattr(args, "func"):
        parser.print_help()
        return 0
    try:
        args.func(args)
        return 0
    except ValueError as exc:
        eprint(f"hashcards: error: Parse error: {exc}")
        return 1
    except sqlite3.Error as exc:
        eprint(f"hashcards: error: rusqlite: {exc}")
        return 1
    except OSError as exc:
        eprint(f"hashcards: error: {exc}")
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
