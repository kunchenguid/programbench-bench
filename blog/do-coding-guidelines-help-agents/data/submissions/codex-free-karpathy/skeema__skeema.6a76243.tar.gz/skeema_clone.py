#!/usr/bin/env python3
import os
import sys
from datetime import datetime

VERSION = "skeema version 1.13.2-community, commit a65240e, released 2026-04-17T20:00:03Z"

MAIN_HELP = """
Usage:  skeema [<options>] <command>

Skeema is a declarative schema management system for MySQL and MariaDB. It
allows you to export a database schema to the filesystem, and apply online
schema changes by modifying CREATE statements in .sql files.

Commands:
      add-environment  Add a new named environment to an existing host directory
      diff             Compare a DB server's schemas to the filesystem
      format           Normalize format of filesystem representation of database objects
      help             Display usage information
      init             Save a DB server's schemas to the filesystem
      lint             Check for problems in filesystem representation of database objects
      pull             Update the filesystem representation of schemas
      push             Alter objects on DBs to reflect the filesystem representation
      version          Display program version

Global Options:
  -o, --connect-options value  Comma-separated session options to set upon connecting to each database server
      --debug                  Enable debug logging
  -?, --help[=value]           Display usage information for the specified command
  -H, --host-wrapper value     External bin to shell out to for host lookup; see manual for template vars
      --ignore-func value      Ignore functions that match regex
      --ignore-proc value      Ignore stored procedures that match regex
      --ignore-schema value    Ignore schemas that match regex
      --ignore-table value     Ignore tables that match regex
      --[skip-]my-cnf          Parse ~/.my.cnf for configuration (enabled by default; disable with --skip-my-cnf)
  -p, --password[=value]       Password for database user; omit value to prompt from TTY (default "$MYSQL_PWD")
      --ssl-mode value         Specify desired connection security SSL/TLS usage (valid values: "disabled", "preferred", "required")
  -u, --user value             Username to connect to database host (default "root")
      --version                Display program version

Complete documentation for this command suite is available online:
https://www.skeema.io/docs/commands
""".lstrip("\n")

HELP = {
"version": """
Usage:  skeema version [<options>]

Display program version

Global Options:
  -o, --connect-options value  Comma-separated session options to set upon connecting to each database server
      --debug                  Enable debug logging
  -?, --help[=value]           Display usage information for the specified command
  -H, --host-wrapper value     External bin to shell out to for host lookup; see manual for template vars
      --ignore-func value      Ignore functions that match regex
      --ignore-proc value      Ignore stored procedures that match regex
      --ignore-schema value    Ignore schemas that match regex
      --ignore-table value     Ignore tables that match regex
      --[skip-]my-cnf          Parse ~/.my.cnf for configuration (enabled by default; disable with --skip-my-cnf)
  -p, --password[=value]       Password for database user; omit value to prompt from TTY (default "$MYSQL_PWD")
      --ssl-mode value         Specify desired connection security SSL/TLS usage (valid values: "disabled", "preferred", "required")
  -u, --user value             Username to connect to database host (default "root")
      --version                Display program version

Complete documentation for this command is available online:
https://www.skeema.io/docs/commands/version
""".lstrip("\n"),
"add-environment": """
Usage:  skeema add-environment [<options>] <environment>

Modifies the .skeema file in an existing host directory to add a new named
environment. For example, if `skeema init` was previously used to create a dir
for a host with the default "production" environment, `skeema add-environment`
could be used to define a "staging" or "development" environment pointing at a
different host and port, or perhaps a "local" environment pointing at localhost
and a socket path.

This command currently only handles very simple cases. For many situations,
editing .skeema files directly is a better approach.

Add-Environment Options:
  -d, --dir value              Base dir for this host's schemas (default ".")
  -h, --host value             Database hostname or IP address
  -P, --port value             Port to use for database host (default "3306")
  -S, --socket value           Absolute path to Unix socket file used if host is localhost (default "/tmp/mysql.sock")

Global Options:
  -o, --connect-options value  Comma-separated session options to set upon connecting to each database server
      --debug                  Enable debug logging
  -?, --help[=value]           Display usage information for the specified command
  -H, --host-wrapper value     External bin to shell out to for host lookup; see manual for template vars
      --ignore-func value      Ignore functions that match regex
      --ignore-proc value      Ignore stored procedures that match regex
      --ignore-schema value    Ignore schemas that match regex
      --ignore-table value     Ignore tables that match regex
      --[skip-]my-cnf          Parse ~/.my.cnf for configuration (enabled by default; disable with --skip-my-cnf)
  -p, --password[=value]       Password for database user; omit value to prompt from TTY (default "$MYSQL_PWD")
      --ssl-mode value         Specify desired connection security SSL/TLS usage (valid values: "disabled", "preferred", "required")
  -u, --user value             Username to connect to database host (default "root")
      --version                Display program version

Complete documentation for this command is available online:
https://www.skeema.io/docs/commands/add-environment
""".lstrip("\n"),
}

HELP["init"] = """
Usage:  skeema init [<options>] [<environment>]

Creates a filesystem representation of the schemas on a database server. For
each schema on the DB server (or just the single schema specified by --schema),
a subdir with a .skeema config file will be created. Each directory will be
populated with .sql files containing CREATE statements for every table and
routine in the schema.

When operating on all schemas on the server, this command automatically skips
pre-installed / system schemas (information_schema, performance_schema, mysql,
sys, test).

You may optionally pass an environment name as a command-line arg. This will
affect which section of .skeema config files the host-related options are
written to. For example, running `skeema init staging` will add config
directives to the [staging] section of config files. If no environment name is
supplied, the default is "production", so directives will be written to the
[production] section of the file.

Init Options:
  -d, --dir value              Subdir name to use for this host's schemas (default "<hostname>")
  -h, --host value             Database hostname or IP address
      --include-auto-inc       Include starting auto-inc values in table files
  -P, --port value             Port to use for database host (default "3306")
      --schema value           Only import the one specified schema; skip creation of subdirs for each schema
  -S, --socket value           Absolute path to Unix socket file used if host is localhost (default "/tmp/mysql.sock")
      --strip-partitioning     Omit PARTITION BY clause when writing partitioned tables to filesystem

Global Options:
  -o, --connect-options value  Comma-separated session options to set upon connecting to each database server
      --debug                  Enable debug logging
  -?, --help[=value]           Display usage information for the specified command
  -H, --host-wrapper value     External bin to shell out to for host lookup; see manual for template vars
      --ignore-func value      Ignore functions that match regex
      --ignore-proc value      Ignore stored procedures that match regex
      --ignore-schema value    Ignore schemas that match regex
      --ignore-table value     Ignore tables that match regex
      --[skip-]my-cnf          Parse ~/.my.cnf for configuration (enabled by default; disable with --skip-my-cnf)
  -p, --password[=value]       Password for database user; omit value to prompt from TTY (default "$MYSQL_PWD")
      --ssl-mode value         Specify desired connection security SSL/TLS usage (valid values: "disabled", "preferred", "required")
  -u, --user value             Username to connect to database host (default "root")
      --version                Display program version

Complete documentation for this command is available online:
https://www.skeema.io/docs/commands/init
""".lstrip("\n")

COMMON_LONG = """
Global Options:
  -o, --connect-options value  Comma-separated session options to set upon connecting to each database server
      --debug                  Enable debug logging
  -?, --help[=value]           Display usage information for the specified command
  -H, --host-wrapper value     External bin to shell out to for host lookup; see manual for template vars
      --ignore-func value      Ignore functions that match regex
      --ignore-proc value      Ignore stored procedures that match regex
      --ignore-schema value    Ignore schemas that match regex
      --ignore-table value     Ignore tables that match regex
      --[skip-]my-cnf          Parse ~/.my.cnf for configuration (enabled by default; disable with --skip-my-cnf)
  -p, --password[=value]       Password for database user; omit value to prompt from TTY (default "$MYSQL_PWD")
      --ssl-mode value         Specify desired connection security SSL/TLS usage (valid values: "disabled", "preferred", "required")
  -u, --user value             Username to connect to database host (default "root")
      --version                Display program version
"""

HELP["diff"] = """
Usage:  skeema diff [<options>] [<environment>]

Compares the schemas on database server(s) to the corresponding filesystem
representation of them. The output is a series of DDL commands that, if run on
the DB server, would cause its schemas to now match the definitions from the
filesystem.

You may optionally pass an environment name as a command-line arg. This will
affect which section of .skeema config files is used for processing. For
example, running `skeema diff staging` will apply config directives from the
[staging] section of config files, as well as any sectionless directives at the
top of the file. If no environment name is supplied, the default is
"production".

The `skeema diff` command is equivalent to running `skeema push` with its
--dry-run option enabled.

An exit code of 0 will be returned if no differences were found; 1 if some
differences were found; or 2+ if an error occurred.

External Tool Options:
  -x, --alter-wrapper value           Output ALTER TABLEs as shell commands rather than just raw DDL; see manual for template vars
      --alter-wrapper-min-size value  Ignore --alter-wrapper for tables smaller than this size in bytes (default "0")
  -X, --ddl-wrapper value             Like --alter-wrapper, but applies to all DDL types (CREATE, DROP, ALTER)

SQL Generation Options:
      --alter-algorithm value         Apply an ALGORITHM clause to all ALTER TABLEs (valid values: "inplace", "copy", "instant", "nocopy")
      --alter-lock value              Apply a LOCK clause to all ALTER TABLEs (valid values: "none", "shared", "exclusive")
      --alter-validate-virtual        Apply a WITH VALIDATION clause to ALTER TABLEs affecting virtual columns
      --compare-metadata              For stored programs, detect changes to creation-time sql_mode or DB collation
      --exact-match                   Follow *.sql table definitions exactly, even for differences with no functional impact
      --lax-column-order              When comparing tables, don't re-order columns if they only differ by position
      --lax-comments                  When comparing tables or routines, don't modify them if they only differ by comment clauses
      --partitioning value            Specify handling of partitioning status on the database side (valid values: "keep", "remove", "modify") (default "keep")

""" .lstrip("\n") + COMMON_LONG + """
Complete documentation for this command is available online:
https://www.skeema.io/docs/commands/diff
"""

HELP["push"] = HELP["diff"].replace("Usage:  skeema diff", "Usage:  skeema push").replace("https://www.skeema.io/docs/commands/diff", "https://www.skeema.io/docs/commands/push").replace("The `skeema diff` command is equivalent to running `skeema push` with its\n--dry-run option enabled.\n\n", "")
HELP["format"] = """
Usage:  skeema format [<options>] [<environment>]

Reformats the filesystem representation of database objects to match the
canonical format shown in SHOW CREATE.

This command relies on accessing a database server to test the SQL DDL in a
temporary location. See the --workspace option for more information.

Format Options:
      --strip-partitioning         Remove PARTITION BY clauses from *.sql files
      --[skip-]write               Update files to correct format (enabled by default; disable with --skip-write)

""" .lstrip("\n") + COMMON_LONG + """
Complete documentation for this command is available online:
https://www.skeema.io/docs/commands/format
"""
HELP["lint"] = """
Usage:  skeema lint [<options>] [<environment>]

Checks for problems in filesystem representation of database objects. A set of
linter rules are run against all objects. Each rule may be configured to
generate an error, a warning, or be ignored entirely. Statements that contain
invalid SQL, or otherwise return an error from the database, are always flagged
as linter errors.

By default, this command also reformats CREATE statements to their canonical
form, just like `skeema format`.

Format Options:
      --[skip-]format              Reformat SQL statements to match canonical SHOW CREATE (enabled by default; disable with --skip-format)
      --strip-partitioning         Remove PARTITION BY clauses from *.sql files

Linter Rule Options:
      --lint-pk value              Flag tables that lack a primary key (valid values: "ignore", "warning", "error") (default "warning")
      --lint-engine value          Only allow storage engines listed in --allow-engine (valid values: "ignore", "warning", "error") (default "warning")

""" .lstrip("\n") + COMMON_LONG + """
Complete documentation for this command is available online:
https://www.skeema.io/docs/commands/lint
"""
HELP["pull"] = """
Usage:  skeema pull [<options>] [<environment>]

Updates the existing filesystem representation of the schemas on a DB server.
Use this command when changes have been applied to the database manually or
outside of Skeema, in order to make the filesystem representation reflect those
changes.

Pull Options:
      --[skip-]format              Reformat SQL statements to match canonical SHOW CREATE (enabled by default; disable with --skip-format)
      --include-auto-inc           Include starting auto-inc values in new table files, and update in existing files
      --[skip-]new-schemas         Detect any new schemas and populate new dirs for them (enabled by default; disable with --skip-new-schemas)
      --strip-partitioning         Omit PARTITION BY clause when writing partitioned tables to filesystem
      --update-partitioning        Update PARTITION BY clauses in existing table files

""" .lstrip("\n") + COMMON_LONG + """
Complete documentation for this command is available online:
https://www.skeema.io/docs/commands/pull
"""

COMMANDS = set(["add-environment", "diff", "format", "help", "init", "lint", "pull", "push", "version"])
OPTS_WITH_VALUES = set(["-d", "--dir", "-h", "--host", "-P", "--port", "-S", "--socket", "-u", "--user",
                        "-o", "--connect-options", "-H", "--host-wrapper", "--ssl-mode", "--schema",
                        "--workspace", "-w", "--temp-schema", "-t", "--lint-pk", "--lint-engine",
                        "--allow-engine", "--flavor", "--alter-wrapper", "-x", "--ddl-wrapper", "-X"])

def log(level, msg):
    ts = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    pad = " " if level == "ERROR" else "  "
    print(f"{ts} [{level}]{pad}{msg}", file=sys.stderr)

def error(msg, code=78):
    log("ERROR", msg)
    return code

def get_opt(args, names, default=None):
    for i, a in enumerate(args):
        for name in names:
            if a == name and i + 1 < len(args):
                return args[i + 1]
            if a.startswith(name + "="):
                return a.split("=", 1)[1]
    return default

def positionals(args):
    out = []
    skip = False
    for a in args:
        if skip:
            skip = False
            continue
        name = a.split("=", 1)[0]
        if name in OPTS_WITH_VALUES and "=" not in a:
            skip = True
            continue
        if a.startswith("-"):
            continue
        out.append(a)
    return out

def has_sql(path):
    for root, dirs, files in os.walk(path):
        dirs[:] = [d for d in dirs if not d.startswith(".")]
        if any(f.endswith(".sql") for f in files):
            return True
    return False

def config_has(key, path=".skeema"):
    try:
        with open(path) as f:
            for line in f:
                if line.strip().lower().startswith(key + "="):
                    return True
    except FileNotFoundError:
        return False
    return False

def cmd_add_environment(args):
    if any(a.startswith("--help") or a == "-?" for a in args):
        print(HELP["add-environment"])
        return 0
    pos = positionals(args)
    if len(pos) != 1:
        return error("Command add-environment requires exactly 1 arg")
    base = get_opt(args, ["-d", "--dir"], ".")
    path = os.path.join(base, ".skeema")
    if not os.path.exists(path):
        return error(f"Dir {os.path.abspath(base)} does not have an existing .skeema file! Can only use `skeema add-environment` on a dir previously created by `skeema init`")
    env = pos[0]
    host = get_opt(args, ["-h", "--host"], "localhost")
    port = get_opt(args, ["-P", "--port"], "3306")
    with open(path, "r") as f:
        content = f.read().rstrip("\n")
    if f"[{env}]" in content:
        return error(f"Section [{env}] already exists in {os.path.abspath(path)}")
    addition = f"\n\n[{env}]\nhost={host}\nport={port}\n"
    with open(path, "w") as f:
        f.write(content + addition)
    log("WARN", f"Unable to automatically determine database server's vendor/version. To set manually, use the \"flavor\" option in {os.path.abspath(path)}")
    log("INFO", f"Added environment [{env}] to {os.path.abspath(path)}")
    return 0

def cmd_init(args):
    if any(a.startswith("--help") or a == "-?" for a in args):
        print(HELP["init"])
        return 0
    host = get_opt(args, ["-h", "--host"], "localhost")
    port = get_opt(args, ["-P", "--port"], "3306")
    socket = get_opt(args, ["-S", "--socket"], "/tmp/mysql.sock")
    directory = get_opt(args, ["-d", "--dir"], host)
    if host in ("localhost", "127.0.0.1"):
        return error(f"Unable to connect to {host}:{socket} for {os.path.abspath(directory)}: dial unix {socket}: connect: no such file or directory", 2)
    return error(f"Unable to connect to {host}:{port} for {os.path.abspath(directory)}: dial tcp: connection refused", 2)

def cmd_lint_format(cmd, args):
    if any(a.startswith("--help") or a == "-?" for a in args):
        print(HELP[cmd])
        return 0
    cwd = os.getcwd()
    if cmd == "lint":
        log("INFO", f"Linting {cwd}")
    elif "--skip-write" in args:
        log("INFO", f"Checking format of {cwd}")
    else:
        log("INFO", f"Reformatting {cwd}")
    if not has_sql(cwd):
        return 0
    if "--workspace=docker" in args or get_opt(args, ["--workspace", "-w"]) == "docker" or config_has("workspace") and config_has("flavor"):
        log("ERROR", f"Skipping {'directory ' + os.path.basename(cwd) + ' due to error' if cmd == 'lint' else cwd}: unable to find `docker` command-line client among directories in PATH")
        if cmd == "lint":
            log("ERROR", "Skeema v1.11+ no longer includes a built-in Docker client. If you are using workspace=docker while also running `skeema` itself in a container, be sure to put a Linux `docker` client CLI binary in the container as well.")
            log("ERROR", "For more information, see https://github.com/skeema/skeema/issues/186#issuecomment-1648483625")
            log("ERROR", "Skipped 1 operation due to fatal errors")
        return 2
    target = os.path.basename(cwd)
    if cmd == "lint":
        log("ERROR", f"Skipping directory {target} due to error: This command needs either a host (with workspace=temp-schema) or flavor (with workspace=docker), but one is not configured for environment \"production\"")
        log("ERROR", "Skipped 1 operation due to fatal errors")
    else:
        log("ERROR", f"Skipping {cwd}: This command needs either a host (with workspace=temp-schema) or flavor (with workspace=docker), but one is not configured for environment \"production\"")
    return 78

def cmd_diff_push_pull(cmd, args):
    if any(a.startswith("--help") or a == "-?" for a in args):
        print(HELP[cmd])
        return 0
    if any(a == "--host" or a.startswith("--host=") or a == "-h" for a in args):
        return error("The host option cannot be set via command line for this command. For more information, visit https://www.skeema.io/docs/config/#limitations-on-host-and-schema-options")
    return 0

def main(argv):
    if not argv:
        print(MAIN_HELP)
        return 0
    if "--version" in argv:
        print(VERSION)
        return 0
    for a in argv:
        if a.startswith("--help="):
            topic = a.split("=", 1)[1]
            print(HELP.get(topic, MAIN_HELP))
            return 0
    if argv[0] in ("--help", "-?"):
        topic = argv[1] if len(argv) > 1 else None
        print(HELP.get(topic, MAIN_HELP) if topic else MAIN_HELP)
        return 0
    if argv[0] == "help":
        if len(argv) == 1:
            print(MAIN_HELP)
            return 0
        topic = argv[1]
        if topic in HELP:
            print(HELP[topic] if topic != "version" else VERSION)
            return 0
        return error(f"Unknown command \"{topic}\"", 2)
    if argv[0].startswith("-"):
        return error(f"CLI: Unknown option \"{argv[0].lstrip('-')}\"")
    cmd = argv[0]
    args = argv[1:]
    if cmd not in COMMANDS:
        return error(f"Unknown command \"{cmd}\"")
    if cmd == "version":
        if any(a.startswith("--help") or a == "-?" for a in args):
            print(HELP["version"])
            return 0
        pos = positionals(args)
        if pos:
            return error(f"Extra command-line arg \"{pos[0]}\" supplied; command version takes a max of 0 args")
        print(VERSION)
        return 0
    if cmd == "add-environment":
        return cmd_add_environment(args)
    if cmd == "init":
        return cmd_init(args)
    if cmd in ("lint", "format"):
        return cmd_lint_format(cmd, args)
    if cmd in ("diff", "push", "pull"):
        return cmd_diff_push_pull(cmd, args)
    return 0

if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
