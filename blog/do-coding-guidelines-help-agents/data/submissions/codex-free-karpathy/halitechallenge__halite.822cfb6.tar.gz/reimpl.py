#!/usr/bin/env python3
import argparse, json, math, os, random, select, shlex, subprocess, sys, time

HELP = r'''
USAGE: 

   ./executable  [-i <path to directory>] [-s <positive integer>] [-d <a
                 string containing two space-seprated positive integers>]
                 [-n <{1,2,3,4,5,6}>] [-r] [-t] [-o] [-q] [--] [--version]
                 [-h] <Array of strings> ...


Where: 

   -i <path to directory>,  --replaydirectory <path to directory>
     The path to directory for replay output.

   -s <positive integer>,  --seed <positive integer>
     The seed for the map generator.

   -d <a string containing two space-seprated positive integers>, 
      --dimensions <a string containing two space-seprated positive
      integers>
     The dimensions of the map.

   -n <{1,2,3,4,5,6}>,  --nplayers <{1,2,3,4,5,6}>
     Create a map that will accommodate n players [SINGLE PLAYER MODE
     ONLY].

   -r,  --noreplay
     Turns off the replay generation.

   -t,  --timeout
     Causes game environment to ignore timeouts (give all bots infinite
     time).

   -o,  --override
     Overrides player-sent names using cmd args [SERVER ONLY].

   -q,  --quiet
     Runs game in quiet mode, producing machine-parsable output.

   --,  --ignore_rest
     Ignores the rest of the labeled arguments following this flag.

   --version
     Displays version information and exits.

   -h,  --help
     Displays usage information and exits.

   <Array of strings>  (accepted multiple times)
     Start commands for bots.


   Halite Game Environment
'''

DIRS = {0:(0,0), 1:(0,-1), 2:(1,0), 3:(0,1), 4:(-1,0)}

class Bot:
    def __init__(self, pid, cmd):
        self.pid = pid
        self.cmd = cmd
        self.name = cmd
        self.proc = None
        self.alive = True
        self.last_alive = 0
        self.error = False


def eprint(s):
    print(s, file=sys.stderr)


def parse_args(argv):
    if '--help' in argv or '-h' in argv:
        print(HELP)
        raise SystemExit(0)
    if '--version' in argv:
        print('\n./executable  version: 1.2\n')
        raise SystemExit(0)
    opts = {'replaydir':'.', 'seed':None, 'dims':(20,20), 'nplayers':None,
            'noreplay':False, 'timeout':False, 'override':False, 'quiet':False}
    bots=[]; i=0
    while i < len(argv):
        a=argv[i]
        if a == '--':
            bots += argv[i+1:]; break
        if a in ('-i','--replaydirectory'):
            i+=1; opts['replaydir']=argv[i]
        elif a in ('-s','--seed'):
            i+=1
            try: opts['seed']=int(argv[i])
            except Exception: parse_error('-s (--seed)', argv[i])
        elif a in ('-d','--dimensions'):
            i+=1
            try:
                parts=argv[i].split()
                if len(parts)!=2: raise ValueError
                w,h=int(parts[0]),int(parts[1])
                if w<=0 or h<=0: raise ValueError
                opts['dims']=(w,h)
            except Exception: parse_error('-d (--dimensions)', argv[i])
        elif a in ('-n','--nplayers'):
            i+=1
            try:
                n=int(argv[i]); assert 1<=n<=6
                opts['nplayers']=n
            except Exception: parse_error('-n (--nplayers)', argv[i])
        elif a in ('-r','--noreplay'): opts['noreplay']=True
        elif a in ('-t','--timeout'): opts['timeout']=True
        elif a in ('-o','--override'): opts['override']=True
        elif a in ('-q','--quiet'): opts['quiet']=True
        else:
            bots.append(a)
        i+=1
    return opts,bots


def parse_error(arg, val):
    print(f"PARSE ERROR: Argument: {arg}\n             Couldn't read argument value from string '{val}'\n")
    print("Brief USAGE: \n   ./executable  [-i <path to directory>] [-s <positive integer>] [-d <a")
    print("                 string containing two space-seprated positive integers>]\n                 [-n <{1,2,3,4,5,6}>] [-r] [-t] [-o] [-q] [--] [--version]\n                 [-h] <Array of strings> ...\n")
    print("For complete USAGE and HELP type: \n   ./executable --help\n")
    raise SystemExit(1)


def make_map(w,h,players,seed):
    rng=random.Random(seed)
    prod=[[max(1, min(15, int((rng.random()+rng.random())*5)+1 + ((x*y+x+y)%5))) for x in range(w)] for y in range(h)]
    owner=[[0]*w for _ in range(h)]
    strength=[[rng.randrange(20,180) for x in range(w)] for y in range(h)]
    spots=[(w//2,h//2)]
    if players>=2: spots=[(w//4,h//2),(3*w//4,h//2)]
    if players>=3: spots=[(w//2,h//4),(w//4,3*h//4),(3*w//4,3*h//4)]
    if players>=4: spots=[(w//4,h//4),(3*w//4,h//4),(w//4,3*h//4),(3*w//4,3*h//4)]
    if players>=5: spots += [(w//2,h//2)]
    if players>=6: spots += [(w//2,h//4),(w//2,3*h//4)]
    for pid in range(1,players+1):
        x,y=spots[(pid-1)%len(spots)]
        x%=w; y%=h
        owner[y][x]=pid; strength[y][x]=100
    return prod,owner,strength


def rle_owners(owner):
    flat=[v for row in owner for v in row]
    out=[]; i=0
    while i<len(flat):
        j=i+1
        while j<len(flat) and flat[j]==flat[i]: j+=1
        out += [j-i, flat[i]]; i=j
    return out


def frame_line(owner,strength):
    return ' '.join(map(str, rle_owners(owner)+[v for row in strength for v in row]))+' \n'


def read_line(proc, timeout, infinite=False):
    if proc.poll() is not None:
        # collect any buffered line if present
        r,_,_=select.select([proc.stdout],[],[],0)
        if not r: return None
    if infinite:
        return proc.stdout.readline()
    r,_,_=select.select([proc.stdout],[],[],timeout)
    if not r: return None
    return proc.stdout.readline()


def send(proc, s):
    try:
        proc.stdin.write(s); proc.stdin.flush(); return True
    except Exception:
        return False


def start_bots(cmds, opts, w,h,prod,owner,strength):
    bots=[]
    for cmd in cmds:
        print(cmd)
        if not opts['quiet']:
            print(cmd)
    print(f"{w} {h}")
    for idx,cmd in enumerate(cmds,1):
        b=Bot(idx,cmd)
        try:
            b.proc=subprocess.Popen(cmd, shell=True, stdin=subprocess.PIPE, stdout=subprocess.PIPE,
                                    stderr=subprocess.STDOUT, text=True, bufsize=1, executable='/bin/sh')
            init=f"{idx}\n{w} {h} \n" + ' '.join(str(v) for row in prod for v in row) + ' \n'
            send(b.proc, init)
            if not opts['quiet']: print(f"Init Message sent to player {idx}.")
            line=read_line(b.proc, None if opts['timeout'] else 2.0, opts['timeout'])
            if line is None or line == '':
                b.name=cmd; b.error=True
            else:
                b.name=line.rstrip('\n')[:1024] or cmd
            if opts['override']:
                b.name=cmd
            if not opts['quiet']: print(f"Init Message received from player {idx}, {b.name}.")
        except Exception as ex:
            b.name=str(ex); b.alive=False; b.error=True
        bots.append(b)
    return bots


def parse_moves(line,w,h):
    vals=[]
    try: vals=[int(x) for x in line.split()]
    except Exception: return []
    moves=[]
    for i in range(0,len(vals)-2,3):
        x,y,d=vals[i],vals[i+1],vals[i+2]
        if 0<=x<w and 0<=y<h and 0<=d<=4: moves.append((x,y,d))
    return moves


def step(owner,strength,prod,bots,move_lines):
    h=len(owner); w=len(owner[0])
    intents={}
    moves_grid=[[0]*w for _ in range(h)]
    for b,line in zip(bots,move_lines):
        if not b.alive: continue
        seen=set()
        for x,y,d in parse_moves(line or '',w,h):
            if owner[y][x]==b.pid and (x,y) not in seen:
                intents[(x,y)]=d; moves_grid[y][x]=d; seen.add((x,y))
    incoming=[[[] for _ in range(w)] for __ in range(h)]
    stayed=[[False]*w for _ in range(h)]
    for y in range(h):
        for x in range(w):
            o=owner[y][x]; s=strength[y][x]
            if o==0: continue
            d=intents.get((x,y),0)
            if d==0 or s==0:
                incoming[y][x].append((o,s)); stayed[y][x]=True
            else:
                dx,dy=DIRS[d]; nx=(x+dx)%w; ny=(y+dy)%h
                incoming[ny][nx].append((o,s))
    newo=[[0]*w for _ in range(h)]; news=[[0]*w for _ in range(h)]
    for y in range(h):
        for x in range(w):
            groups={}
            if owner[y][x]==0:
                groups[0]=strength[y][x]
            for o,s in incoming[y][x]: groups[o]=groups.get(o,0)+s
            if not groups:
                newo[y][x]=owner[y][x]; news[y][x]=strength[y][x]
                continue
            # simultaneous combat: each side is reduced by all opposing strengths
            best_o=0; best_s=0
            for o,s in groups.items():
                damage=sum(v for oo,v in groups.items() if oo!=o)
                rem=s-damage
                if rem>best_s: best_o,best_s=o,rem
            newo[y][x]=best_o if best_s>0 else 0
            news[y][x]=min(255, max(0, best_s))
    for y in range(h):
        for x in range(w):
            if newo[y][x] and moves_grid[y][x]==0:
                news[y][x]=min(255, news[y][x]+prod[y][x])
    return newo,news,moves_grid


def main(argv):
    opts,cmds=parse_args(argv)
    if not cmds:
        print('Please provide the launch command string for at least one bot.')
        print('Use the --help flag for usage details.')
        return 1
    seed=opts['seed'] if opts['seed'] is not None else int(time.time())%100000000
    w,h=opts['dims']
    players_for_map=opts['nplayers'] or len(cmds)
    players_for_map=max(players_for_map, len(cmds))
    prod,owner,strength=make_map(w,h,players_for_map,seed)
    bots=start_bots(cmds,opts,w,h,prod,owner,strength)
    maxturn=max(1, int(round(10*math.sqrt(w*h))))
    frames=[]; moves=[]
    frames.append([[[owner[y][x],strength[y][x]] for x in range(w)] for y in range(h)])
    for turn in range(1,maxturn+1):
        if not opts['quiet']: print(f"Turn {turn}")
        line=frame_line(owner,strength)
        move_lines=[]
        for b in bots:
            if b.alive and b.proc:
                if not send(b.proc,line):
                    b.alive=False; b.error=True
                resp=read_line(b.proc, None if opts['timeout'] else 1.0, opts['timeout']) if b.alive else ''
                if resp is None:
                    b.alive=False; b.error=True; resp=''
                    if not opts['quiet']: print(f"Bot #{b.pid} timeout or error (Unix) 0")
                move_lines.append(resp or '')
                if b.alive: b.last_alive=turn
            else:
                move_lines.append('')
        owner,strength,mg=step(owner,strength,prod,bots,move_lines)
        frames.append([[[owner[y][x],strength[y][x]] for x in range(w)] for y in range(h)])
        moves.append(mg)
        alive_owners={v for row in owner for v in row if v>0 and v<=len(bots)}
        for b in bots:
            if b.pid in alive_owners: b.last_alive=turn
    scores=[]
    for b in bots:
        cells=sum(1 for row in owner for v in row if v==b.pid)
        total=sum(strength[y][x] for y in range(h) for x in range(w) if owner[y][x]==b.pid)
        scores.append((cells,total,b.last_alive,b.pid,b))
    scores.sort(key=lambda t:(t[0],t[1],t[2]), reverse=True)
    rank={b.pid:i+1 for i,(*_,b) in enumerate(scores)}
    if opts['quiet']:
        for _,_,last,pid,b in scores:
            print(f"{rank[pid]} {pid} {last}")
        print(' ')
    if not opts['noreplay']:
        if not opts['quiet']:
            print(f"Map seed was {seed}")
        os.makedirs(opts['replaydir'], exist_ok=True)
        path=os.path.join(opts['replaydir'], f"{int(time.time())}-{seed}.hlt")
        if not opts['quiet']: print(f"Opening a file at {path}")
        data={'frames':frames,'height':h,'moves':moves,'num_frames':len(frames),'num_players':len(bots),
              'player_names':[b.name for b in bots],'productions':prod,'version':11,'width':w}
        with open(path,'w') as f: json.dump(data,f,separators=(',',':'))
    if not opts['quiet']:
        for _,_,last,pid,b in scores:
            print(f"Player #{pid}, {b.name}, came in rank #{rank[pid]} and was last alive on frame #{last}!")
    for b in bots:
        if b.proc:
            try: b.proc.kill()
            except Exception: pass
    return 0

if __name__=='__main__':
    try: sys.exit(main(sys.argv[1:]))
    except BrokenPipeError: pass
