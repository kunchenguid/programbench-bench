#!/usr/bin/env python3
import os, sys, struct, argparse

MAGIC = b'\x04\x22\x4d\x18'
LEGACY_MAGIC = b'\x02\x21\x4c\x18'
VERSION = '1.10.0'

PRIME1 = 2654435761
PRIME2 = 2246822519
PRIME3 = 3266489917
PRIME4 = 668265263
PRIME5 = 374761393

def rotl32(x, r):
    return ((x << r) | (x >> (32-r))) & 0xffffffff

def xxh32(data, seed=0):
    data = memoryview(data)
    n = len(data)
    p = 0
    if n >= 16:
        v1 = (seed + PRIME1 + PRIME2) & 0xffffffff
        v2 = (seed + PRIME2) & 0xffffffff
        v3 = seed & 0xffffffff
        v4 = (seed - PRIME1) & 0xffffffff
        limit = n - 16
        while p <= limit:
            for name in range(4):
                lane = struct.unpack_from('<I', data, p)[0]; p += 4
                if name == 0:
                    v1 = (rotl32((v1 + lane * PRIME2) & 0xffffffff, 13) * PRIME1) & 0xffffffff
                elif name == 1:
                    v2 = (rotl32((v2 + lane * PRIME2) & 0xffffffff, 13) * PRIME1) & 0xffffffff
                elif name == 2:
                    v3 = (rotl32((v3 + lane * PRIME2) & 0xffffffff, 13) * PRIME1) & 0xffffffff
                else:
                    v4 = (rotl32((v4 + lane * PRIME2) & 0xffffffff, 13) * PRIME1) & 0xffffffff
        h = (rotl32(v1, 1) + rotl32(v2, 7) + rotl32(v3, 12) + rotl32(v4, 18)) & 0xffffffff
    else:
        h = (seed + PRIME5) & 0xffffffff
    h = (h + n) & 0xffffffff
    while p + 4 <= n:
        k = struct.unpack_from('<I', data, p)[0]; p += 4
        h = (rotl32((h + k * PRIME3) & 0xffffffff, 17) * PRIME4) & 0xffffffff
    while p < n:
        h = (rotl32((h + data[p] * PRIME5) & 0xffffffff, 11) * PRIME1) & 0xffffffff
        p += 1
    h ^= h >> 15; h = (h * PRIME2) & 0xffffffff
    h ^= h >> 13; h = (h * PRIME3) & 0xffffffff
    h ^= h >> 16
    return h & 0xffffffff

def literal_block(src):
    n = len(src)
    out = bytearray([min(n, 15) << 4])
    if n >= 15:
        left = n - 15
        while left >= 255:
            out.append(255)
            left -= 255
        out.append(left)
    out += src
    return bytes(out)

def compress_legacy(src, block_size=8*1024*1024):
    out = bytearray(LEGACY_MAGIC)
    for i in range(0, len(src), block_size):
        block = literal_block(src[i:i+block_size])
        out += struct.pack('<I', len(block)) + block
    return bytes(out)

def compress_frame(src, content_size=False, content_checksum=True, block_size=4*1024*1024, block_checksum=False):
    flg = 0x60
    if block_checksum:
        flg |= 0x10
    if content_size:
        flg |= 0x08
    if content_checksum:
        flg |= 0x04
    bd = 0x70
    header = bytearray([flg, bd])
    if content_size:
        header += struct.pack('<Q', len(src))
    hc = (xxh32(header) >> 8) & 0xff
    out = bytearray(MAGIC + header + bytes([hc]))
    for i in range(0, len(src), block_size):
        block = src[i:i+block_size]
        out += struct.pack('<I', len(block) | 0x80000000)
        out += block
        if block_checksum:
            out += struct.pack('<I', xxh32(block))
    out += b'\0\0\0\0'
    if content_checksum:
        out += struct.pack('<I', xxh32(src))
    return bytes(out)

class LZ4Error(Exception):
    pass

def read_u32(buf, pos):
    if pos + 4 > len(buf):
        raise LZ4Error('Read error : truncated input')
    return struct.unpack_from('<I', buf, pos)[0], pos + 4

def decode_block(block, prefix=b''):
    ip = 0
    out = bytearray()
    n = len(block)
    while ip < n:
        token = block[ip]; ip += 1
        lit_len = token >> 4
        if lit_len == 15:
            while True:
                if ip >= n: raise LZ4Error('Malformed input')
                s = block[ip]; ip += 1; lit_len += s
                if s != 255: break
        if ip + lit_len > n: raise LZ4Error('Malformed input')
        out += block[ip:ip+lit_len]; ip += lit_len
        if ip >= n:
            break
        if ip + 2 > n: raise LZ4Error('Malformed input')
        off = block[ip] | (block[ip+1] << 8); ip += 2
        if off == 0: raise LZ4Error('Malformed input')
        match_len = (token & 15) + 4
        if (token & 15) == 15:
            while True:
                if ip >= n: raise LZ4Error('Malformed input')
                s = block[ip]; ip += 1; match_len += s
                if s != 255: break
        base_len = len(prefix) + len(out)
        start = base_len - off
        if start < 0: raise LZ4Error('Malformed input')
        for i in range(match_len):
            idx = start + i
            if idx < len(prefix):
                b = prefix[idx]
            else:
                b = out[idx - len(prefix)]
            out.append(b)
    return bytes(out)

def decompress_frame(data):
    pos = 0
    result = bytearray()
    while pos < len(data):
        if pos + 4 > len(data):
            raise LZ4Error('Unrecognized header : file cannot be decoded')
        magic = data[pos:pos+4]; pos += 4
        mval = struct.unpack('<I', magic)[0]
        if 0x184d2a50 <= mval <= 0x184d2a5f:
            size, pos = read_u32(data, pos)
            pos += size
            continue
        if magic == LEGACY_MAGIC:
            while pos < len(data):
                size, pos = read_u32(data, pos)
                if pos + size > len(data): raise LZ4Error('Read error : truncated input')
                result += decode_block(data[pos:pos+size])
                pos += size
            return bytes(result)
        if magic != MAGIC:
            raise LZ4Error('Unrecognized header : file cannot be decoded')
        if pos + 3 > len(data): raise LZ4Error('Read error : truncated input')
        flg = data[pos]; bd = data[pos+1]; pos += 2
        if (flg >> 6) != 1: raise LZ4Error('Unsupported frame version')
        block_independent = bool(flg & 0x20)
        block_checksum = bool(flg & 0x10)
        has_content_size = bool(flg & 0x08)
        has_content_checksum = bool(flg & 0x04)
        has_dict = bool(flg & 0x01)
        header = bytearray([flg, bd])
        expected_size = None
        if has_content_size:
            if pos + 8 > len(data): raise LZ4Error('Read error : truncated input')
            expected_size = struct.unpack_from('<Q', data, pos)[0]
            header += data[pos:pos+8]; pos += 8
        if has_dict:
            if pos + 4 > len(data): raise LZ4Error('Read error : truncated input')
            header += data[pos:pos+4]; pos += 4
        hc = data[pos]; pos += 1
        if ((xxh32(header) >> 8) & 0xff) != hc:
            raise LZ4Error('Header checksum error')
        frame_out = bytearray()
        prefix = b''
        while True:
            block_size, pos = read_u32(data, pos)
            if block_size == 0:
                break
            raw = bool(block_size & 0x80000000)
            size = block_size & 0x7fffffff
            if pos + size > len(data): raise LZ4Error('Read error : truncated input')
            block = data[pos:pos+size]; pos += size
            if block_checksum:
                _, pos = read_u32(data, pos)
            decoded = block if raw else decode_block(block, b'' if block_independent else prefix)
            frame_out += decoded
            if not block_independent:
                prefix = (prefix + decoded)[-65536:]
        if has_content_checksum:
            cksum, pos = read_u32(data, pos)
            if xxh32(frame_out) != cksum:
                raise LZ4Error('Content checksum error')
        if expected_size is not None and len(frame_out) != expected_size:
            raise LZ4Error('Content size error')
        result += frame_out
    return bytes(result)

def default_output_name(inp, decompress):
    if decompress:
        if inp.endswith('.lz4'):
            return inp[:-4]
        raise LZ4Error("Cannot determine an output filename")
    return inp + '.lz4'

def read_all(path):
    if path in (None, '-'):
        return sys.stdin.buffer.read()
    with open(path, 'rb') as f:
        return f.read()

def write_all(path, data, force=False):
    if path in (None, '-', 'stdout'):
        sys.stdout.buffer.write(data); return
    if path == 'null':
        return
    if os.path.exists(path) and not force:
        raise LZ4Error(f'{path} already exists; use -f to overwrite')
    with open(path, 'wb') as f:
        f.write(data)

def list_file(path):
    data = read_all(path)
    try:
        dec = decompress_frame(data)
        print('Frames  Type  Block  Compressed  Uncompressed  Ratio  Filename')
        ratio = (len(data) / len(dec) * 100) if dec else 0.0
        print(f'1       LZ4   -      {len(data)}         {len(dec)}            {ratio:.2f}%  {path}')
        return 0
    except Exception as e:
        print(f'{path}: {e}', file=sys.stderr)
        return 1

def usage(long=False):
    text = f'''*** lz4 v{VERSION} 64-bit multithread, by Yann Collet ***
Usage : 
      executable [arg] [input] [output] 

input   : a filename 
          with no FILE, or when FILE is - or stdin, read standard input
Arguments : 
 -1     : fast compression (default) 
 -12    : slowest compression level 
 -T#    : use # threads for compression (default:0==auto) 
 -d     : decompression (default for .lz4 extension)
 -f     : overwrite output without prompting 
 -k     : preserve source files(s)  (default) 
--rm    : remove source file(s) after successful de/compression 
 -h/-H  : display help/long help and exit 

Advanced arguments :
 -V     : display Version number and exit 
 -v     : verbose mode 
 -q     : suppress warnings; specify twice to suppress errors too
 -c     : force write to standard output, even if it is the console
 -t     : test compressed file integrity
 -m     : multiple input files (implies automatic output filenames)
 -r     : operate recursively on directories (sets also -m) 
 -l     : compress using Legacy format (Linux kernel compression)
 -z     : force compression 
 -D FILE: use FILE as dictionary (compression & decompression)
 -B#    : cut file into blocks of size # bytes [32+] 
--content-size : compressed frame includes original size (default:not present)
--list FILE : lists information about .lz4 files (useful for files compressed with --content-size flag)
--fast[=#]: switch to ultra fast compression level (default: 1)
--best  : same as -12
'''
    print(text, end='')

def expand_args(argv):
    out = []
    for a in argv:
        if a.startswith('-') and not a.startswith('--') and len(a) > 2 and a[1].isdigit():
            j = 1
            while j < len(a) and a[j].isdigit():
                j += 1
            out.append('-' + a[1:j])
            out += ['-' + ch for ch in a[j:]]
        elif a.startswith('-') and not a.startswith('--') and len(a) > 2 and not (a[1] in 'BTDbi' or a[1:].isdigit()):
            # Accept common aggregates like -dfc, -9f. Keep numeric levels whole.
            if a[1].isdigit():
                out.append(a)
            else:
                out += ['-' + ch for ch in a[1:]]
        else:
            out.append(a)
    return out

def main(argv):
    argv = expand_args(argv)
    mode = None
    force = False; stdout = False; test = False; multiple = False; rm = False
    content_size = False; content_checksum = True; block_checksum = False; list_mode = False; legacy = False
    files = []
    i = 0
    while i < len(argv):
        a = argv[i]
        if a in ('-h','-H','--help'):
            usage(a == '-H'); return 0
        elif a == '-V':
            print(f'*** LZ4 command line interface {VERSION} ***'); return 0
        elif a in ('-d','--decompress','--uncompress'):
            mode = 'decompress'
        elif a in ('-z','--compress'):
            mode = 'compress'
        elif a == '-t':
            mode = 'decompress'; test = True
        elif a == '-c':
            stdout = True
        elif a == '-f':
            force = True
        elif a == '-m':
            multiple = True
        elif a == '--rm':
            rm = True
        elif a in ('-k','--keep','-q','-v','--sparse','--no-sparse','--best','--favor-decSpeed'):
            pass
        elif a == '--content-size':
            content_size = True
        elif a == '--no-frame-crc':
            content_checksum = False
        elif a == '-BX':
            block_checksum = True
        elif a == '-l':
            legacy = True
        elif a == '--list':
            list_mode = True
        elif a.startswith('--fast') or a.startswith('-B') or a.startswith('-T') or (a.startswith('-') and a[1:].isdigit()):
            pass
        elif a == '-D':
            i += 1
        elif a.startswith('-D'):
            pass
        elif a.startswith('-') and a != '-':
            # Ignore unsupported tuning flags, matching permissive behavior where practical.
            pass
        else:
            files.append(a)
        i += 1
    if list_mode:
        rc = 0
        for f in files:
            rc |= list_file(f)
        return rc
    if not files:
        inp = '-'; outp = '-' if stdout or test else '-'
        mode = mode or 'compress'
        files = [inp]
    if multiple:
        rc = 0
        for inp in files:
            try:
                dec = (mode == 'decompress') or (mode is None and inp.endswith('.lz4'))
                src = read_all(inp)
                data = decompress_frame(src) if dec else (compress_legacy(src) if legacy else compress_frame(src, content_size, content_checksum, block_checksum=block_checksum))
                outp = 'null' if test else default_output_name(inp, dec)
                write_all(outp, data, force)
                if rm and inp != '-': os.unlink(inp)
            except Exception as e:
                print(f'executable: {e}', file=sys.stderr); rc = 1
        return rc
    inp = files[0]
    outp = files[1] if len(files) > 1 else None
    dec = (mode == 'decompress') or (mode is None and inp != '-' and inp.endswith('.lz4'))
    if stdout:
        outp = '-'
    elif test:
        outp = 'null'
    elif outp is None:
        outp = '-' if inp == '-' else default_output_name(inp, dec)
    try:
        src = read_all(inp)
        data = decompress_frame(src) if dec else (compress_legacy(src) if legacy else compress_frame(src, content_size, content_checksum, block_checksum=block_checksum))
        write_all(outp, data, force)
        if rm and inp != '-': os.unlink(inp)
        return 0
    except BrokenPipeError:
        return 0
    except Exception as e:
        print(f'executable: {e}', file=sys.stderr)
        return 1

if __name__ == '__main__':
    sys.exit(main(sys.argv[1:]))
