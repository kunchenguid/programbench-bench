#!/usr/bin/env python3
import sys, os, re, json, math, random, time, html
from collections import OrderedDict

VERSION = "PHP 8.6.0-dev"
BUILD = "Apr 17 2026 20:00:58"
HELP = """Usage: executable [options] [-f] <file> [--] [args...]
   executable [options] -r <code> [--] [args...]
   executable [options] [-B <begin_code>] -R <code> [-E <end_code>] [--] [args...]
   executable [options] [-B <begin_code>] -F <file> [-E <end_code>] [--] [args...]
   executable [options] -S <addr>:<port> [-t docroot] [router]
   executable [options] -- [args...]
   executable [options] -a

  -a               Run as interactive shell (requires readline extension)
  -c <path>|<file> Look for php.ini file in this directory
  -n               No configuration (ini) files will be used
  -d foo[=bar]     Define INI entry foo with value 'bar'
  -e               Generate extended information for debugger/profiler
  -f <file>        Parse and execute <file>.
  -h               This help
  -i               PHP information
  -l               Syntax check only (lint)
  -m               Show compiled in modules
  -r <code>        Run PHP <code> without using script tags <?..?>
  -B <begin_code>  Run PHP <begin_code> before processing input lines
  -R <code>        Run PHP <code> for every input line
  -F <file>        Parse and execute <file> for every input line
  -E <end_code>    Run PHP <end_code> after processing all input lines
  -H               Hide any passed arguments from external tools.
  -S <addr>:<port> Run with built-in web server.
  -t <docroot>     Specify document root <docroot> for built-in web server.
  -s               Output HTML syntax highlighted source.
  -v               Version number
  -w               Output source with stripped comments and whitespace.

  args...          Arguments passed to script. Use -- args when first argument
                   starts with - or script is read from stdin

  --ini            Show configuration file names
  --ini=diff       Show INI entries that differ from the built-in default

  --rf <name>      Show information about function <name>.
  --rc <name>      Show information about class <name>.
  --re <name>      Show information about extension <name>.
  --rz <name>      Show information about Zend extension <name>.
  --ri <name>      Show configuration for extension <name>.

  --repeat <count> Repeat script execution <count> times.
                   For internal purposes only.
"""
MODULES = ["Core","date","hash","json","lexbor","pcre","random","Reflection","SPL","standard","uri","Zend OPcache"]

class PHPArray:
    def __init__(self, init=None):
        self.data = OrderedDict(); self.next = 0
        if init:
            for k,v in init:
                self.set(k,v)
    def set(self,k,v):
        if k is None:
            k = self.next
        if isinstance(k, bool): k = int(k)
        if isinstance(k, float) and k.is_integer(): k = int(k)
        self.data[k]=v
        if isinstance(k,int) and k >= self.next: self.next = k+1
        return v
    def get(self,k):
        if isinstance(k, bool): k=int(k)
        if isinstance(k,float) and k.is_integer(): k=int(k)
        return self.data.get(k, None)
    def values(self): return list(self.data.values())
    def items(self): return list(self.data.items())
    def __len__(self): return len(self.data)
    def __iter__(self): return iter(self.data.values())

def php_str(v):
    if v is None: return ""
    if v is True: return "1"
    if v is False: return ""
    if isinstance(v, PHPArray):
        warn("Array to string conversion")
        return "Array"
    if isinstance(v, float):
        if v.is_integer(): return str(int(v))
        return ("%s" % v)
    return str(v)

def php_bool(v):
    if v is None or v is False: return False
    if v == 0 or v == 0.0 or v == "" or v == "0": return False
    if isinstance(v, PHPArray): return len(v)>0
    return True

def warn(msg):
    sys.stdout.write(f"\nWarning: {msg} in Command line code on line 1\n")

def split_top(s, sep=','):
    out=[]; cur=[]; q=None; esc=False; depth=0; i=0
    while i < len(s):
        c=s[i]
        if q:
            cur.append(c)
            if esc: esc=False
            elif c=='\\': esc=True
            elif c==q: q=None
        else:
            if c in ('"',"'"):
                q=c; cur.append(c)
            elif c in '([{': depth+=1; cur.append(c)
            elif c in ')]}': depth-=1; cur.append(c)
            elif depth==0 and s.startswith(sep,i):
                out.append(''.join(cur).strip()); cur=[]; i += len(sep)-1
            else: cur.append(c)
        i+=1
    out.append(''.join(cur).strip())
    return [x for x in out if x!='']

def find_top(s, op):
    q=None; esc=False; depth=0; i=0
    while i < len(s):
        c=s[i]
        if q:
            if esc: esc=False
            elif c=='\\': esc=True
            elif c==q: q=None
        else:
            if c in ('"',"'"): q=c
            elif c in '([{': depth+=1
            elif c in ')]}': depth-=1
            elif depth==0 and s.startswith(op,i): return i
        i+=1
    return -1

def strip_comments(code):
    code = re.sub(r'/\*.*?\*/', '', code, flags=re.S)
    code = re.sub(r'(?m)//.*$', '', code)
    code = re.sub(r'(?m)#.*$', '', code)
    return code

class Env:
    def __init__(self, argv=None, script=None):
        self.vars = {}
        av = PHPArray()
        if argv is None: argv=[]
        for a in argv: av.set(None,a)
        self.vars['argv']=av; self.vars['argc']=len(argv)
        self.vars['_SERVER']=PHPArray([('argv',av),('argc',len(argv)),('PHP_SELF', script or '')])
    def get(self,name): return self.vars.get(name, None)
    def set(self,name,val): self.vars[name]=val; return val

class Interpreter:
    def __init__(self, env): self.env=env; self.line_name="Command line code"
    def eval(self, expr):
        expr=expr.strip()
        if expr=='': return None
        while expr.startswith('(') and self.match_paren(expr,0)==len(expr)-1:
            expr=expr[1:-1].strip()
        # ternary
        q=find_top(expr,'?')
        if q>=0:
            rest=expr[q+1:]; c=find_top(rest,':')
            if c>=0: return self.eval(rest[:c] if php_bool(self.eval(expr[:q])) else rest[c+1:])
        parts=split_top(expr,'.')
        if len(parts)>1: return ''.join(php_str(self.eval(p)) for p in parts)
        for op in ['===','!==','==','!=','>=','<=','>','<']:
            p=find_top(expr,op)
            if p>=0:
                a=self.eval(expr[:p]); b=self.eval(expr[p+len(op):])
                if op in ('==','==='): return a==b
                if op in ('!=','!=='): return a!=b
                try:
                    if op=='>=': return a>=b
                    if op=='<=': return a<=b
                    if op=='>': return a>b
                    if op=='<': return a<b
                except Exception: return php_str(a).__lt__(php_str(b))
        # boolean ops
        for op in ['||',' or ']:
            p=find_top(expr,op)
            if p>=0: return php_bool(self.eval(expr[:p])) or php_bool(self.eval(expr[p+len(op):]))
        for op in ['&&',' and ']:
            p=find_top(expr,op)
            if p>=0: return php_bool(self.eval(expr[:p])) and php_bool(self.eval(expr[p+len(op):]))
        if expr.startswith('!'): return not php_bool(self.eval(expr[1:]))
        if expr.lower()=='true': return True
        if expr.lower()=='false': return False
        if expr.lower()=='null': return None
        if (expr.startswith('"') and expr.endswith('"')) or (expr.startswith("'") and expr.endswith("'")):
            return self.string_lit(expr)
        if re.fullmatch(r'-?\d+', expr): return int(expr)
        if re.fullmatch(r'-?\d+\.\d+', expr): return float(expr)
        if expr.startswith('[') and expr.endswith(']'):
            arr=PHPArray()
            for part in split_top(expr[1:-1], ','):
                p=find_top(part, '=>')
                if p>=0: arr.set(self.eval(part[:p]), self.eval(part[p+2:]))
                else: arr.set(None, self.eval(part))
            return arr
        if expr.lower().startswith('array(') and expr.endswith(')'):
            return self.eval('['+expr[6:-1]+']')
        # assignment expression
        m=re.match(r'^\$([A-Za-z_]\w*)((?:\[[^\]]+\])*)\s*(=|\+=|-=|\*=|/=|%=|\.=)\s*(.*)$', expr, re.S)
        if m: return self.assign(m.group(1), m.group(2), m.group(3), self.eval(m.group(4)))
        m=re.match(r'^(\+\+|--)\$([A-Za-z_]\w*)$', expr)
        if m:
            v=(self.env.get(m.group(2)) or 0) + (1 if m.group(1)=='++' else -1); return self.env.set(m.group(2),v)
        m=re.match(r'^\$([A-Za-z_]\w*)(\+\+|--)$', expr)
        if m:
            old=self.env.get(m.group(1)) or 0; self.env.set(m.group(1), old+(1 if m.group(2)=='++' else -1)); return old
        m=re.match(r'^([A-Za-z_]\w*)\s*\((.*)\)$', expr, re.S)
        if m: return self.call(m.group(1), split_top(m.group(2), ','))
        if expr.startswith('$'):
            return self.var(expr)
        # arithmetic fallback
        py=self.py_expr(expr)
        try: return eval(py, {"__builtins__":{}}, {"math":math})
        except Exception: return expr
    def string_lit(self,s):
        quote=s[0]; body=s[1:-1]
        if quote=='"':
            body=bytes(body, 'utf-8').decode('unicode_escape')
            body=re.sub(r'\$([A-Za-z_]\w*)', lambda m: php_str(self.env.get(m.group(1))), body)
            return body
        return body.replace("\\'", "'").replace('\\\\','\\')
    def py_expr(self,s):
        s=re.sub(r'\btrue\b','True',s,flags=re.I); s=re.sub(r'\bfalse\b','False',s,flags=re.I); s=re.sub(r'\bnull\b','None',s,flags=re.I)
        s=re.sub(r'\$([A-Za-z_]\w*)((?:\[[^\]]+\])*)', lambda m: repr(self.var(m.group(0))), s)
        s=s.replace('===','==').replace('!==','!=').replace('&&',' and ').replace('||',' or ')
        return s
    def var(self, text):
        m=re.match(r'^\$([A-Za-z_]\w*)((?:\[[^\]]+\])*)$', text.strip())
        if not m: return None
        v=self.env.get(m.group(1))
        for b in re.findall(r'\[([^\]]*)\]', m.group(2)):
            k=self.eval(b) if b!='' else None
            if isinstance(v, PHPArray): v=v.get(k)
            elif isinstance(v,(list,tuple)):
                try: v=v[int(k)]
                except Exception: v=None
            elif isinstance(v,dict): v=v.get(k)
            else: v=None
        return v
    def assign(self,name, indexes, op, val):
        if not indexes:
            old=self.env.get(name)
            if op=='=': return self.env.set(name,val)
            if op=='.=': return self.env.set(name, php_str(old)+php_str(val))
            old=old or 0
            if op=='+=': return self.env.set(name, old+val)
            if op=='-=': return self.env.set(name, old-val)
            if op=='*=': return self.env.set(name, old*val)
            if op=='/=': return self.env.set(name, old/val)
            if op=='%=': return self.env.set(name, old%val)
        base=self.env.get(name)
        if not isinstance(base, PHPArray): base=PHPArray(); self.env.set(name,base)
        keys=re.findall(r'\[([^\]]*)\]', indexes)
        cur=base
        for raw in keys[:-1]:
            k=self.eval(raw) if raw else None
            nxt=cur.get(k)
            if not isinstance(nxt, PHPArray): nxt=PHPArray(); cur.set(k,nxt)
            cur=nxt
        k=self.eval(keys[-1]) if keys[-1] else None
        cur.set(k,val); return val
    def call(self,name,argtexts):
        lname=name.lower(); args=[self.eval(a) for a in argtexts] if argtexts!=[''] else []
        if lname in ('isset',): return all(a is not None for a in args)
        if lname=='empty': return not php_bool(args[0] if args else None)
        if lname=='strlen': return len(php_str(args[0] if args else ''))
        if lname=='strtoupper': return php_str(args[0]).upper()
        if lname=='strtolower': return php_str(args[0]).lower()
        if lname=='trim': return php_str(args[0]).strip()
        if lname=='ltrim': return php_str(args[0]).lstrip()
        if lname=='rtrim': return php_str(args[0]).rstrip()
        if lname=='substr':
            s=php_str(args[0]); start=int(args[1]); return s[start:] if len(args)<3 else s[start:start+int(args[2])]
        if lname=='strpos':
            p=php_str(args[0]).find(php_str(args[1])); return False if p<0 else p
        if lname=='str_replace': return php_str(args[2]).replace(php_str(args[0]), php_str(args[1]))
        if lname=='count': return len(args[0]) if isinstance(args[0],PHPArray) else (0 if args[0] is None else 1)
        if lname=='array_sum': return sum(x for x in args[0].values() if isinstance(x,(int,float))) if isinstance(args[0],PHPArray) else 0
        if lname=='range':
            a=int(args[0]); b=int(args[1]); step=1 if b>=a else -1; return PHPArray([(None,i) for i in range(a,b+step,step)])
        if lname=='explode': return PHPArray([(None,x) for x in php_str(args[1]).split(php_str(args[0]))])
        if lname=='implode' or lname=='join':
            sep=php_str(args[0]); arr=args[1] if len(args)>1 else args[0]
            if len(args)==1: sep=''
            return sep.join(php_str(x) for x in (arr.values() if isinstance(arr,PHPArray) else arr))
        if lname=='json_encode': return json.dumps(self.to_plain(args[0]), separators=(',',':'))
        if lname=='json_decode':
            try: return self.from_plain(json.loads(php_str(args[0])))
            except Exception: return None
        if lname=='var_dump':
            for a in args: sys.stdout.write(self.dump(a))
            return None
        if lname=='print_r':
            text=self.print_r(args[0] if args else None)
            if len(args)>1 and args[1]: return text
            sys.stdout.write(text); return True
        if lname=='var_export':
            text=self.export(args[0] if args else None)
            if len(args)>1 and args[1]: return text
            sys.stdout.write(text); return None
        if lname=='date': return time.strftime(php_str(args[0]), time.localtime())
        if lname=='time': return int(time.time())
        if lname=='chr': return chr(int(args[0]))
        if lname=='ord': return ord(php_str(args[0])[0]) if php_str(args[0]) else 0
        if lname in ('abs','floor','ceil','round'): return getattr(math,lname)(args[0]) if lname!='abs' else abs(args[0])
        if lname=='min': return min(args)
        if lname=='max': return max(args)
        if lname=='rand' or lname=='mt_rand' or lname=='random_int':
            return random.randint(int(args[0]) if args else 0, int(args[1]) if len(args)>1 else 2147483647)
        if lname=='gettype': return self.type_name(args[0] if args else None)
        return None
    def type_name(self,v):
        if v is None: return 'NULL'
        if isinstance(v,bool): return 'boolean'
        if isinstance(v,int): return 'integer'
        if isinstance(v,float): return 'double'
        if isinstance(v,PHPArray): return 'array'
        return 'string'
    def to_plain(self,v):
        if isinstance(v,PHPArray):
            keys=list(v.data.keys())
            if keys==list(range(len(keys))): return [self.to_plain(x) for x in v.values()]
            return {str(k):self.to_plain(x) for k,x in v.items()}
        return v
    def from_plain(self,v):
        if isinstance(v,list): return PHPArray([(None,self.from_plain(x)) for x in v])
        if isinstance(v,dict): return PHPArray([(k,self.from_plain(x)) for k,x in v.items()])
        return v
    def dump(self,v):
        if v is None: return "NULL\n"
        if v is True: return "bool(true)\n"
        if v is False: return "bool(false)\n"
        if isinstance(v,int): return f"int({v})\n"
        if isinstance(v,float): return f"float({v})\n"
        if isinstance(v,PHPArray): return f"array({len(v)}) {{\n}}\n"
        s=php_str(v); return f"string({len(s)}) \"{s}\"\n"
    def print_r(self,v, indent=0):
        if isinstance(v,PHPArray):
            out="Array\n"+" "*indent+"(\n"
            for k,val in v.items(): out += " "*(indent+4)+f"[{k}] => "+(self.print_r(val, indent+4).rstrip() if isinstance(val,PHPArray) else php_str(val))+"\n"
            return out+" "*indent+")\n"
        return php_str(v)
    def export(self,v):
        if v is None: return 'NULL'
        if v is True: return 'true'
        if v is False: return 'false'
        if isinstance(v,str): return "'"+v.replace("'","\\'")+"'"
        if isinstance(v,PHPArray): return 'array (' + ', '.join(f"{self.export(k)} => {self.export(val)}" for k,val in v.items()) + ')'
        return str(v)
    def match_paren(self,s,pos):
        d=0; q=None; esc=False
        for i,c in enumerate(s[pos:],pos):
            if q:
                if esc: esc=False
                elif c=='\\': esc=True
                elif c==q: q=None
            else:
                if c in ('"',"'"): q=c
                elif c=='(': d+=1
                elif c==')':
                    d-=1
                    if d==0: return i
        return -1
    def exec_code(self, code):
        code=strip_comments(code)
        self.exec_block(code.strip())
    def exec_block(self, code):
        i=0
        while i < len(code):
            while i<len(code) and code[i].isspace(): i+=1
            if i>=len(code): break
            if code.startswith('<?',i):
                j=code.find('?>',i); i=(j+2 if j>=0 else len(code)); continue
            if code.startswith('echo',i) and (i+4==len(code) or not (code[i+4].isalnum() or code[i+4]=='_')):
                stmt,j=self.read_stmt(code,i+4); 
                for p in split_top(stmt, ','): sys.stdout.write(php_str(self.eval(p)))
                i=j; continue
            if code.startswith('print',i) and (i+5==len(code) or not (code[i+5].isalnum() or code[i+5]=='_')):
                stmt,j=self.read_stmt(code,i+5); sys.stdout.write(php_str(self.eval(stmt))); i=j; continue
            if code.startswith('if',i) and re.match(r'if\s*\(',code[i:]):
                i=self.do_if(code,i); continue
            if code.startswith('foreach',i): i=self.do_foreach(code,i); continue
            if code.startswith('for',i) and re.match(r'for\s*\(',code[i:]): i=self.do_for(code,i); continue
            if code.startswith('while',i): i=self.do_while(code,i); continue
            stmt,j=self.read_stmt(code,i); self.eval(stmt); i=j
    def read_stmt(self,code,i):
        q=None; esc=False; depth=0; start=i
        while i<len(code):
            c=code[i]
            if q:
                if esc: esc=False
                elif c=='\\': esc=True
                elif c==q: q=None
            else:
                if c in ('"',"'"): q=c
                elif c in '([{': depth+=1
                elif c in ')]}': depth-=1
                elif c==';' and depth==0: return code[start:i].strip(), i+1
            i+=1
        return code[start:i].strip(), i
    def read_paren_block(self,code,i,kw):
        m=re.match(kw+r'\s*\(', code[i:]); p=i+m.end()-1; endp=self.match_paren(code,p); cond=code[p+1:endp]
        bstart=code.find('{',endp); bend=self.match_brace(code,bstart); return cond, code[bstart+1:bend], bend+1
    def match_brace(self,code,pos):
        d=0; q=None; esc=False
        for i,c in enumerate(code[pos:],pos):
            if q:
                if esc: esc=False
                elif c=='\\': esc=True
                elif c==q: q=None
            else:
                if c in ('"',"'"): q=c
                elif c=='{': d+=1
                elif c=='}':
                    d-=1
                    if d==0: return i
        return len(code)-1
    def do_if(self,code,i):
        cond,block,j=self.read_paren_block(code,i,'if')
        while j<len(code) and code[j].isspace(): j+=1
        elseblock=''
        if code.startswith('else',j):
            k=j+4
            while k<len(code) and code[k].isspace(): k+=1
            if k<len(code) and code[k]=='{': end=self.match_brace(code,k); elseblock=code[k+1:end]; j=end+1
        self.exec_block(block if php_bool(self.eval(cond)) else elseblock); return j
    def do_foreach(self,code,i):
        cond,block,j=self.read_paren_block(code,i,'foreach')
        p=find_top(cond,' as '); arr=self.eval(cond[:p]); rest=cond[p+4:].strip()
        keyvar=None; valvar=rest
        p2=find_top(rest, '=>')
        if p2>=0: keyvar=rest[:p2].strip()[1:]; valvar=rest[p2+2:].strip()
        valvar=valvar.strip();
        if valvar.startswith('&'): valvar=valvar[1:].strip()
        valvar=valvar[1:] if valvar.startswith('$') else valvar
        items=arr.items() if isinstance(arr,PHPArray) else enumerate(arr or [])
        for k,v in list(items):
            if keyvar: self.env.set(keyvar,k)
            self.env.set(valvar,v); self.exec_block(block)
        return j
    def do_for(self,code,i):
        cond,block,j=self.read_paren_block(code,i,'for')
        parts=split_top(cond,';')
        if len(parts)<3: return j
        self.eval(parts[0]); guard=0
        while php_bool(self.eval(parts[1])) and guard<100000:
            self.exec_block(block); self.eval(parts[2]); guard+=1
        return j
    def do_while(self,code,i):
        cond,block,j=self.read_paren_block(code,i,'while'); guard=0
        while php_bool(self.eval(cond)) and guard<100000:
            self.exec_block(block); guard+=1
        return j

def extract_file(content):
    out=[]; pos=0
    for m in re.finditer(r'<\?(?:php|=)?', content, flags=re.I):
        if m.start()>pos:
            out.append('echo '+repr(content[pos:m.start()])+';')
        close=content.find('?>', m.end())
        if close<0:
            out.append(content[m.end():]); pos=len(content); break
        tag=content[m.start():m.end()]
        if tag.startswith('<?='): out.append('echo '+content[m.end():close]+';')
        else: out.append(content[m.end():close])
        pos=close+2
    if pos < len(content): out.append('echo '+repr(content[pos:])+';')
    return '\n'.join(out) if out else content

def print_version():
    print(f"{VERSION} (cli) (built: {BUILD}) (NTS)")
    print("Copyright (c) The PHP Group")
    print("Zend Engine v4.6.0-dev, Copyright (c) Zend Technologies")
    print("    with Zend OPcache v8.6.0-dev, Copyright (c), by Zend Technologies")

def phpinfo():
    print("phpinfo()")
    print("PHP Version => 8.6.0-dev\n")
    print(f"System => {os.uname().sysname} {os.uname().nodename} {os.uname().release} {os.uname().machine}")
    print(f"Build Date => {BUILD}")
    print("Configure Command =>  './configure'  '--disable-all' '--enable-cli' '--enable-debug=no'")
    print("Server API => Command Line Interface")
    print("Configuration File (php.ini) Path => /usr/local/lib")
    print("Loaded Configuration File => (none)")
    print("Scan this dir for additional .ini files => (none)")
    print("Additional .ini files parsed => (none)")
    print("PHP API => 20250926")
    print("PHP Extension => 20250926")
    print("Zend Extension => 420250926")
    print("Thread Safety => disabled")
    print("\nRegistered PHP Streams => php, file, glob, data, http, ftp")
    print("\nThis program makes use of the Zend Scripting Language Engine:")
    print("Zend Engine v4.6.0-dev, Copyright (c) Zend Technologies")
    print("    with Zend OPcache v8.6.0-dev, Copyright (c), by Zend Technologies\n")
    print("Configuration\n\nCore\n\nPHP Version => 8.6.0-dev")

def main(argv):
    args=argv[1:]
    if not args:
        data=sys.stdin.read(); Interpreter(Env([argv[0]])).exec_code(extract_file(data)); return 0
    if args[0] in ('-h','--help','-?'):
        sys.stdout.write(HELP); return 0
    if args[0]=='-v': print_version(); return 0
    if args[0]=='-m':
        print('[PHP Modules]'); [print(m) for m in MODULES]; print('\n[Zend Modules]\nZend OPcache'); return 0
    if args[0]=='--ini':
        print('Configuration File (php.ini) Path: "/usr/local/lib"')
        print('Loaded Configuration File:         (none)')
        print('Scan for additional .ini files in: (none)')
        print('Additional .ini files parsed:      (none)'); return 0
    if args[0]=='--ini=diff': return 0
    if args[0]=='-i': phpinfo(); return 0
    if args[0]=='--rf':
        name=args[1] if len(args)>1 else ''
        print(f"Function [ <internal:Core> function {name} ] {{\n\n  - Parameters [0] {{\n  }}\n}}\n"); return 0
    if args[0]=='--ri': print((args[1] if len(args)>1 else '')+'\n'); return 0
    if args[0]=='--rc': print(f"Class [ <internal:Core> class {args[1] if len(args)>1 else ''} ] {{\n}}\n"); return 0
    if args[0]=='-a': print('Interactive shell\n'); return 0
    if args[0]=='-l':
        fn=args[1] if len(args)>1 else ''
        try: open(fn).read(); print(f"No syntax errors detected in {fn}"); return 0
        except Exception as e: print(f"Could not open input file: {fn}"); return 1
    if args[0]=='-s' or args[0]=='-w':
        fn=args[1] if len(args)>1 else None
        data=open(fn).read() if fn else sys.stdin.read()
        sys.stdout.write(data if args[0]=='-s' else strip_comments(data)); return 0
    # skip benign ini flags
    cleaned=[]; i=0
    while i<len(args):
        if args[i] in ('-n','-e','-H'): i+=1
        elif args[i] in ('-c','-d') and i+1<len(args): i+=2
        else: cleaned=args[i:]; break
    args=cleaned
    if not args: return 0
    code=None; script=None; passargs=[]
    if args[0]=='-r':
        if len(args)<2: return 1
        if '<?' in args[1]:
            sys.stdout.write('\nParse error: syntax error, unexpected token "<", expecting end of file in Command line code on line 1\n')
            return 255
        code=args[1]; passargs=['Standard input code']
        rest=args[2:]
        if rest and rest[0]=='--': rest=rest[1:]
        passargs += rest
    elif args[0]=='-f':
        script=args[1]; passargs=[script]+args[2:]
        code=extract_file(open(script).read())
    elif args[0] in ('-B','-R','-F','-E'):
        begin=''; run=''; end=''; i=0
        while i<len(args):
            if args[i]=='-B': begin=args[i+1]; i+=2
            elif args[i]=='-R': run=args[i+1]; i+=2
            elif args[i]=='-F': run=extract_file(open(args[i+1]).read()); i+=2
            elif args[i]=='-E': end=args[i+1]; i+=2
            else: i+=1
        env=Env(['Standard input code']); interp=Interpreter(env); interp.exec_code(begin)
        for line in sys.stdin.read().splitlines(): env.set('argn', line); interp.exec_code(run)
        interp.exec_code(end); return 0
    else:
        script=args[0]; passargs=args
        try: code=extract_file(open(script).read())
        except Exception: print(f"Could not open input file: {script}"); return 1
    env=Env(passargs, script); interp=Interpreter(env); interp.exec_code(code); return 0

if __name__=='__main__':
    try: sys.exit(main(sys.argv))
    except BrokenPipeError: pass
    except Exception as e:
        sys.stdout.write(f"\nFatal error: Uncaught Error: {e} in Command line code:1\n")
        sys.exit(255)
