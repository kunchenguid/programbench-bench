#!/usr/bin/env python3
import gzip
import math
import os
import random
import sys

VERSION = "1.5-r133"


def eprint(s=""):
    print(s, file=sys.stderr)


def open_text(path):
    if path == "-":
        return sys.stdin
    if path.endswith(".gz"):
        return gzip.open(path, "rt")
    return open(path, "r", encoding="utf-8", errors="replace")


def read_records(path):
    fh = open_text(path)
    close = fh is not sys.stdin
    try:
        first = fh.readline()
        while first and first.strip() == "":
            first = fh.readline()
        if not first:
            return
        if first[0] == ">":
            name = first[1:].rstrip("\n\r")
            seq = []
            for line in fh:
                line = line.rstrip("\n\r")
                if line.startswith(">"):
                    yield ("fa", name, "".join(seq), None)
                    name = line[1:]
                    seq = []
                else:
                    seq.append(line.strip())
            yield ("fa", name, "".join(seq), None)
        elif first[0] == "@":
            header = first[1:].rstrip("\n\r")
            while True:
                seq_lines = []
                for line in fh:
                    line = line.rstrip("\n\r")
                    if line.startswith("+"):
                        break
                    seq_lines.append(line.strip())
                seq = "".join(seq_lines)
                qual_lines = []
                n = 0
                while n < len(seq):
                    q = fh.readline()
                    if not q:
                        break
                    q = q.rstrip("\n\r")
                    qual_lines.append(q)
                    n += len(q)
                yield ("fq", header, seq, "".join(qual_lines)[:len(seq)])
                nxt = fh.readline()
                if not nxt:
                    break
                header = nxt[1:].rstrip("\n\r") if nxt.startswith("@") else nxt.rstrip("\n\r")
        else:
            return
    finally:
        if close:
            fh.close()


RCMAP = str.maketrans("ACGTRYKMSWBDHVNacgtrykmswbdhvn", "TGCAYRMKSWVHDBNtgcayrmkswvhdbn")


def revcomp(seq):
    return seq.translate(RCMAP)[::-1]


def wrap(seq, line_len):
    if line_len is None or line_len <= 0:
        return [seq]
    return [seq[i:i + line_len] for i in range(0, len(seq), line_len)] or [""]


def out_record(name, seq, qual=None, fasta=False, line_len=0):
    if fasta or qual is None:
        print(">" + name)
        for s in wrap(seq, line_len):
            print(s)
    else:
        print("@" + name)
        for s in wrap(seq, line_len):
            print(s)
        print("+")
        for q in wrap(qual, line_len):
            print(q)


def parse_opts(argv, optspec):
    opts = {}
    rest = []
    i = 0
    while i < len(argv):
        a = argv[i]
        if not a.startswith("-") or a == "-":
            rest.append(a); i += 1; continue
        if a == "--":
            rest.extend(argv[i + 1:]); break
        j = 1
        while j < len(a):
            c = a[j]
            need = optspec.get(c)
            if need is None:
                opts[c] = True; j += 1
            elif need:
                if j + 1 < len(a):
                    opts[c] = a[j + 1:]; j = len(a)
                else:
                    i += 1
                    opts[c] = argv[i] if i < len(argv) else ""
                    j = len(a)
            else:
                opts[c] = True; j += 1
        i += 1
    return opts, rest


def main_usage():
    print("")
    print("Usage:   seqtk <command> <arguments>")
    print("Version: " + VERSION)
    print("")
    for line in [
        "Command: seq       common transformation of FASTA/Q",
        "         size      report the number sequences and bases",
        "         comp      get the nucleotide composition of FASTA/Q",
        "         sample    subsample sequences",
        "         subseq    extract subsequences from FASTA/Q",
        "         fqchk     fastq QC (base/quality summary)",
        "         mergepe   interleave two PE FASTA/Q files",
        "         split     split one file into multiple smaller files",
        "         trimfq    trim FASTQ using the Phred algorithm",
        "",
        "         hety      regional heterozygosity",
        "         gc        identify high- or low-GC regions",
        "         mutfa     point mutate FASTA at specified positions",
        "         mergefa   merge two FASTA/Q files",
        "         famask    apply a X-coded FASTA to a source FASTA",
        "         dropse    drop unpaired from interleaved PE FASTA/Q",
        "         rename    rename sequence names",
        "         randbase  choose a random base from hets",
        "         cutN      cut sequence at long N",
        "         gap       get the gap locations",
        "         listhet   extract the position of each het",
        "         hpc       homopolyer-compressed sequence",
        "         telo      identify telomere repeats in asm or long reads",
    ]:
        print(line)


def cmd_size(args):
    n = b = 0
    if args:
        for _, _, seq, _ in read_records(args[0]):
            n += 1; b += len(seq)
    print(f"{n}\t{b}")


def cmd_comp(args):
    if not args:
        return
    for _, name, seq, _ in read_records(args[0]):
        vals = {
            "A": 0, "C": 0, "G": 0, "T": 0, "2": 0, "3": 0, "N": 0,
            "CpG": 0, "tv": 0, "ts": 0
        }
        s = seq.upper()
        for ch in s:
            if ch in vals:
                vals[ch] += 1
            elif ch in "RYKMSW":
                vals["2"] += 1
            elif ch in "BDHV":
                vals["3"] += 1
            else:
                vals["N"] += 1
        vals["CpG"] = 2 * sum(1 for i in range(len(s) - 1) if s[i:i + 2] == "CG")
        print("\t".join(map(str, [name.split()[0], len(seq), vals["A"], vals["C"], vals["G"], vals["T"], vals["2"], vals["3"], vals["N"], vals["CpG"], vals["tv"], vals["ts"], 0])))


def load_bed(path):
    regs = {}
    with open_text(path) as fh:
        for line in fh:
            if not line.strip() or line.startswith("#"):
                continue
            f = line.rstrip("\n").split("\t")
            if len(f) < 3:
                continue
            regs.setdefault(f[0], []).append((int(f[1]), int(f[2]), f[5] if len(f) > 5 else "+"))
    return regs


def cmd_seq(args):
    opts, rest = parse_opts(args, {c: True for c in "qQLlnM"} | {c: False for c in "aACr"})
    if not rest:
        return
    line_len = int(opts.get("l", 0) or 0)
    qoff = int(opts.get("Q", 33) or 33)
    qthr = int(opts.get("q", -1) or -1)
    nchar = opts.get("n")
    mask_regs = load_bed(opts["M"]) if "M" in opts else {}
    for typ, name, seq, qual in read_records(rest[0]):
        if "C" in opts:
            name = name.split()[0]
        if "r" in opts:
            seq = revcomp(seq)
            if qual is not None:
                qual = qual[::-1]
        if mask_regs:
            sid = name.split()[0]
            arr = list(seq)
            for st, en, _ in mask_regs.get(sid, []):
                for k in range(max(0, st), min(len(arr), en)):
                    arr[k] = arr[k].lower()
            seq = "".join(arr)
        if qual is not None and qthr >= 0:
            arr = list(seq)
            for i, ch in enumerate(qual[:len(arr)]):
                if ord(ch) - qoff < qthr:
                    arr[i] = nchar if nchar is not None else arr[i].lower()
            seq = "".join(arr)
        out_record(name, seq, None if ("a" in opts or "A" in opts) else qual, fasta=("a" in opts or "A" in opts), line_len=line_len)


def read_name_or_regions(path):
    names = []
    regs = []
    with open_text(path) as fh:
        for line in fh:
            if not line.strip() or line.startswith("#"):
                continue
            f = line.rstrip("\n").split("\t")
            if len(f) >= 3 and f[1].lstrip("-").isdigit() and f[2].lstrip("-").isdigit():
                regs.append((f[0], int(f[1]), int(f[2]), f[5] if len(f) > 5 else "+"))
            else:
                names.append(line.split()[0])
    return names, regs


def cmd_subseq(args):
    opts, rest = parse_opts(args, {"l": True, "t": False, "s": False})
    if len(rest) < 2:
        print("Usage:   seqtk subseq [options] <in.fa> <in.bed>|<name.list>")
        return
    line_len = int(opts.get("l", 0) or 0)
    names, regs = read_name_or_regions(rest[1])
    recs = {name.split()[0]: (typ, name, seq, qual) for typ, name, seq, qual in read_records(rest[0])}
    if regs:
        for sid, st, en, strand in regs:
            if sid not in recs:
                continue
            typ, name, seq, qual = recs[sid]
            sub = seq[st:en]
            qsub = qual[st:en] if qual else None
            if "s" in opts and strand == "-":
                sub = revcomp(sub)
                if qsub: qsub = qsub[::-1]
            if "t" in opts:
                print(f"{sid}\t{st + 1}\t{sub}")
            else:
                suffix = name[len(sid):]
                out_record(f"{sid}:{st + 1}-{en}{suffix}", sub, qsub, fasta=(qsub is None), line_len=line_len)
    else:
        wanted = set(names)
        for typ, name, seq, qual in recs.values():
            if name.split()[0] in wanted:
                out_record(name, seq, qual, fasta=(qual is None), line_len=line_len)


def cmd_sample(args):
    opts, rest = parse_opts(args, {"s": True, "2": False})
    if len(rest) < 2:
        print("\nUsage:   seqtk sample [-2] [-s seed=11] <in.fa> <frac>|<number>")
        return
    random.seed(int(opts.get("s", 11) or 11))
    recs = list(read_records(rest[0]))
    target = rest[1]
    if "." in target or "e" in target.lower():
        picked = [r for r in recs if random.random() < float(target)]
    else:
        n = int(target)
        picked = random.sample(recs, min(n, len(recs)))
    for _, name, seq, qual in picked:
        out_record(name, seq, qual, fasta=(qual is None))


def q_to_err(q):
    return 1.0 / (1.0 + 10 ** (q / 10.0))


def cmd_trimfq(args):
    opts, rest = parse_opts(args, {"q": True, "l": True, "b": True, "e": True, "L": True, "Q": False})
    if not rest:
        print("\nUsage:   seqtk trimfq [options] <in.fq>")
        return
    b = int(opts.get("b", 0) or 0); e = int(opts.get("e", 0) or 0); L = int(opts.get("L", 0) or 0)
    for typ, name, seq, qual in read_records(rest[0]):
        if b or e or L:
            end = len(seq) - e if e else len(seq)
            if L:
                end = min(end, b + L)
            seq2 = seq[b:max(b, end)]
            qual2 = qual[b:max(b, end)] if qual else None
        else:
            seq2, qual2 = seq, qual
        out_record(name, seq2, qual2, fasta=(qual2 is None and "Q" not in opts))


def cmd_fqchk(args):
    opts, rest = parse_opts(args, {"q": True})
    if not rest:
        print("Usage: seqtk fqchk [-q 20] <in.fq>")
        return
    low_thr = int(opts.get("q", 20) or 20)
    rows = []
    lens = []
    distinct = set()
    for _, _, seq, qual in read_records(rest[0]):
        lens.append(len(seq))
        while len(rows) < len(seq):
            rows.append({"b": 0, "A": 0, "C": 0, "G": 0, "T": 0, "N": 0, "q": 0, "err": 0.0, "low": 0, "high": 0})
        for i, base in enumerate(seq.upper()):
            q = ord(qual[i]) - 33 if qual and i < len(qual) else 0
            distinct.add(q)
            r = rows[i]; r["b"] += 1; r["q"] += q; r["err"] += q_to_err(q)
            r[base if base in "ACGT" else "N"] += 1
            if q < low_thr: r["low"] += 1
            else: r["high"] += 1
    if not lens:
        return
    print(f"min_len: {min(lens)}; max_len: {max(lens)}; avg_len: {sum(lens)/len(lens):.2f}; {len(distinct)} distinct quality values")
    print("POS\t#bases\t%A\t%C\t%G\t%T\t%N\tavgQ\terrQ\t%low\t%high")
    allr = {"b": sum(r["b"] for r in rows), "A": sum(r["A"] for r in rows), "C": sum(r["C"] for r in rows), "G": sum(r["G"] for r in rows), "T": sum(r["T"] for r in rows), "N": sum(r["N"] for r in rows), "q": sum(r["q"] for r in rows), "err": sum(r["err"] for r in rows), "low": sum(r["low"] for r in rows), "high": sum(r["high"] for r in rows)}
    def pr(pos, r):
        b = r["b"] or 1; avg = r["q"] / b
        err = -10 * math.log10((r["err"] / b) or 1)
        print(f"{pos}\t{r['b']}\t{100*r['A']/b:.1f}\t{100*r['C']/b:.1f}\t{100*r['G']/b:.1f}\t{100*r['T']/b:.1f}\t{100*r['N']/b:.1f}\t{avg:.1f}\t{err:.1f}\t{100*r['low']/b:.1f}\t{100*r['high']/b:.1f}")
    pr("ALL", allr)
    for i, r in enumerate(rows, 1):
        pr(i, r)


def cmd_mergepe(args):
    if len(args) < 2:
        print("Usage: seqtk mergepe <in1.fq> <in2.fq>"); return
    for r1, r2 in zip(read_records(args[0]), read_records(args[1])):
        for _, name, seq, qual in (r1, r2):
            out_record(name, seq, qual, fasta=(qual is None))


def cmd_split(args):
    opts, rest = parse_opts(args, {"n": True, "l": True})
    if len(rest) < 2:
        print("Usage: seqtk split [options] <prefix> <in.fa>"); return
    n = int(opts.get("n", 10) or 10); line_len = int(opts.get("l", 0) or 0)
    files = [open(f"{rest[0]}.{i}.fa", "w") for i in range(n)]
    old = sys.stdout
    try:
        for k, (_, name, seq, qual) in enumerate(read_records(rest[1])):
            sys.stdout = files[k % n]
            out_record(name, seq, qual, fasta=(qual is None), line_len=line_len)
    finally:
        sys.stdout = old
        for f in files: f.close()


def cmd_gap(args):
    opts, rest = parse_opts(args, {"l": True})
    if not rest:
        print("Usage: seqtk gap [-l 50] <in.fa>"); return
    minl = int(opts.get("l", 50) or 50)
    for _, name, seq, _ in read_records(rest[0]):
        sid = name.split()[0]; i = 0; s = seq.upper()
        while i < len(s):
            if s[i] == "N":
                j = i
                while j < len(s) and s[j] == "N": j += 1
                if j - i >= minl:
                    print(f"{sid}\t{i}\t{j}")
                i = j
            else:
                i += 1


def cmd_hpc(args):
    if not args:
        return
    for _, name, seq, qual in read_records(args[0]):
        out = []
        prev = None
        for ch in seq:
            if prev is None or ch.upper() != prev.upper():
                out.append(ch)
            prev = ch
        out_record(name.split()[0], "".join(out), None, fasta=True)


HET = set("RYSWKMBDHVryswkmbdhv")


def cmd_listhet(args):
    if not args:
        print("Usage: seqtk listhet <in.fa>"); return
    for _, name, seq, _ in read_records(args[0]):
        sid = name.split()[0]
        for i, ch in enumerate(seq, 1):
            if ch in HET:
                print(f"{sid}\t{i}\t{ch}")


def cmd_randbase(args):
    if not args:
        print("Usage: seqtk randbase <in.fa>"); return
    m = {"R":"AG","Y":"CT","S":"CG","W":"AT","K":"GT","M":"AC","B":"CGT","D":"AGT","H":"ACT","V":"ACG"}
    random.seed(11)
    for _, name, seq, _ in read_records(args[0]):
        out = []
        for ch in seq:
            bases = m.get(ch.upper())
            out.append(random.choice(bases) if bases else ch)
        out_record(name, "".join(out), None, fasta=True)


def cmd_cutN(args):
    opts, rest = parse_opts(args, {"n": True, "p": True, "g": False})
    if not rest:
        print("\nUsage:   seqtk cutN [options] <in.fa>"); return
    minl = int(opts.get("n", 1000) or 1000)
    for _, name, seq, _ in read_records(rest[0]):
        sid = name.split()[0]; last = 0; part = 1; i = 0; s = seq.upper()
        while i < len(s):
            if s[i] == "N":
                j = i
                while j < len(s) and s[j] == "N": j += 1
                if j - i >= minl:
                    if "g" in opts:
                        print(f"{sid}\t{i}\t{j}")
                    elif i > last:
                        out_record(f"{sid}:{last + 1}-{i}", seq[last:i], None, fasta=True)
                        part += 1
                    last = j
                i = j
            else:
                i += 1
        if "g" not in opts and last < len(seq):
            out_record(f"{sid}:{last + 1}-{len(seq)}", seq[last:], None, fasta=True)


def cmd_mutfa(args):
    if len(args) < 2:
        print("Usage: seqtk mutfa <in.fa> <in.snp>"); return
    muts = {}
    with open_text(args[1]) as fh:
        for line in fh:
            f = line.split()
            if len(f) >= 4:
                muts.setdefault(f[0], {})[int(f[1]) - 1] = f[3]
    for _, name, seq, _ in read_records(args[0]):
        sid = name.split()[0]; arr = list(seq)
        for pos, base in muts.get(sid, {}).items():
            if 0 <= pos < len(arr): arr[pos] = base
        out_record(name, "".join(arr), None, fasta=True)


def cmd_famask(args):
    if len(args) < 2:
        print("Usage: seqtk famask <src.fa> <mask.fa>"); return
    masks = {n.split()[0]: s for _, n, s, _ in read_records(args[1])}
    for _, name, seq, _ in read_records(args[0]):
        sid = name.split()[0]; mask = masks.get(sid, ""); arr = list(seq)
        for i, ch in enumerate(mask[:len(arr)]):
            if ch.upper() == "X": arr[i] = arr[i].lower()
        out_record(name, "".join(arr), None, fasta=True)


def cmd_rename(args):
    if not args:
        return
    for i, (_, name, seq, qual) in enumerate(read_records(args[0]), 1):
        out_record(str(i), seq, qual, fasta=(qual is None))


def cmd_dropse(args):
    if not args:
        return
    it = iter(read_records(args[0]))
    for r1 in it:
        try: r2 = next(it)
        except StopIteration: break
        n1 = r1[1].split()[0].rstrip("/12")
        n2 = r2[1].split()[0].rstrip("/12")
        if n1 == n2:
            for _, name, seq, qual in (r1, r2):
                out_record(name, seq, qual, fasta=(qual is None))


def cmd_gc(args):
    opts, rest = parse_opts(args, {"w": False, "f": True, "l": True, "x": True})
    if not rest:
        print("Usage: seqtk gc [options] <in.fa>"); return
    minl = int(opts.get("l", 20) or 20); frac = float(opts.get("f", 0.60) or 0.60)
    want_at = "w" in opts
    for _, name, seq, _ in read_records(rest[0]):
        sid = name.split()[0]; s = seq.upper(); i = 0
        while i < len(s):
            ok = (s[i] in "AT") if want_at else (s[i] in "GC")
            if ok:
                j = i
                while j < len(s) and ((s[j] in "AT") if want_at else (s[j] in "GC")): j += 1
                if j - i >= minl:
                    print(f"{sid}\t{i}\t{j}")
                i = j
            else:
                i += 1


def cmd_mergefa(args):
    if len(args) < 2:
        print("\nUsage: seqtk mergefa [options] <in1.fa> <in2.fa>"); return
    rest = [a for a in args if not a.startswith("-")]
    if len(rest) < 2: return
    r2 = {n.split()[0]: s for _, n, s, _ in read_records(rest[1])}
    for _, name, seq, _ in read_records(rest[0]):
        sid = name.split()[0]; b = r2.get(sid)
        if b is None:
            out_record(name, seq, None, fasta=True); continue
        out = [x if x.upper() == y.upper() else "N" for x, y in zip(seq, b)]
        out_record(name, "".join(out), None, fasta=True)


def cmd_hety(args):
    opts, rest = parse_opts(args, {"w": True, "t": True, "m": False})
    if not rest:
        print("\nUsage:   seqtk hety [options] <in.fa>"); return
    w = int(opts.get("w", 50000) or 50000)
    for _, name, seq, _ in read_records(rest[0]):
        sid = name.split()[0]
        for st in range(0, len(seq), w):
            sub = seq[st:st+w]
            het = sum(1 for c in sub if c in HET)
            print(f"{sid}\t{st}\t{st+len(sub)}\t{het}\t{len(sub)}")


def cmd_telo(args):
    # Approximate telomere repeat finder: report counts to stderr like empty original does.
    if not args:
        print("0\t0")
        return
    motif = "TTAGGG"
    total = hits = 0
    for _, name, seq, _ in read_records(args[0]):
        total += len(seq)
        s = seq.upper()
        start = s.find(motif * 2)
        while start >= 0:
            end = start + len(motif) * 2
            while s.startswith(motif, end):
                end += len(motif)
            print(f"{name.split()[0]}\t{start}\t{end}")
            hits += 1
            start = s.find(motif * 2, end)
    eprint(f"{hits}\t{total}")


COMMANDS = {
    "seq": cmd_seq, "size": cmd_size, "comp": cmd_comp, "sample": cmd_sample,
    "subseq": cmd_subseq, "fqchk": cmd_fqchk, "mergepe": cmd_mergepe,
    "split": cmd_split, "trimfq": cmd_trimfq, "gap": cmd_gap, "hpc": cmd_hpc,
    "listhet": cmd_listhet, "randbase": cmd_randbase, "cutN": cmd_cutN,
    "mutfa": cmd_mutfa, "famask": cmd_famask, "rename": cmd_rename,
    "dropse": cmd_dropse, "gc": cmd_gc, "mergefa": cmd_mergefa,
    "hety": cmd_hety, "telo": cmd_telo,
}


def main(argv):
    if not argv:
        main_usage(); return 0
    cmd = argv[0]
    if cmd in ("--help", "-h"):
        eprint(f"[main] unrecognized command '{cmd}'. Abort!")
        return 1
    fn = COMMANDS.get(cmd)
    if not fn:
        eprint(f"[main] unrecognized command '{cmd}'. Abort!")
        return 1
    fn(argv[1:])
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
