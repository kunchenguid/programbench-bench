#!/usr/bin/env python3
import os
import re
import subprocess
import sys
import time
from datetime import datetime, timezone

HELP = """loop 0.6.1
Rich Jones <miserlou@gmail.com>
UNIX's missing `loop` command

USAGE:
    executable [FLAGS] [OPTIONS] [input]...

FLAGS:
    -D, --error-duration    Exit with timeout error code on duration
    -h, --help              Prints help information
    -l, --only-last         Only print the output of the last execution of the command
    -i, --stdin             Read from standard input
        --summary           Provide a summary
    -C, --until-changes     Keep going until the output changes
    -f, --until-fail        Keep going until the command exit status is non-zero
    -S, --until-same        Keep going until the output changes
    -s, --until-success     Keep going until the command exit status is zero
    -V, --version           Prints version information

OPTIONS:
    -b, --count-by <count_by>                Amount to increment the counter by [default: 1]
    -e, --every <every>                      How often to iterate. ex., 5s, 1h1m1s1ms1us [default: 1us]
        --for <ffor>                         A comma-separated list of values, placed into 4ITEM. ex., red,green,blue
    -d, --for-duration <for_duration>        Keep going until the duration has elapsed (example 1m30s)
    -n, --num <num>                          Number of iterations to execute
    -o, --offset <offset>                    Amount to offset the initial counter by [default: 0]
    -c, --until-contains <until_contains>    Keep going until the output contains this string
    -r, --until-error <until_error>          Keep going until the command exit status is the value given
    -m, --until-match <until_match>          Keep going until the output matches this regular expression
    -t, --until-time <until_time>            Keep going until a future time, ex. "2018-04-20 04:20:00" (Times in UTC.)

ARGS:
    <input>...    The command to be looped
"""


class Opts:
    def __init__(self):
        self.error_duration = False
        self.only_last = False
        self.stdin = False
        self.summary = False
        self.until_changes = False
        self.until_fail = False
        self.until_same = False
        self.until_success = False
        self.count_by = 1
        self.every = 0.000001
        self.for_values = None
        self.for_duration = None
        self.num = None
        self.offset = 0
        self.until_contains = None
        self.until_error = None
        self.until_match = None
        self.until_time = None
        self.input = []


def die(msg, code=1):
    sys.stderr.write(msg)
    if not msg.endswith("\n"):
        sys.stderr.write("\n")
    sys.exit(code)


def parse_int(s, name):
    try:
        return int(s)
    except Exception:
        if name == "--num":
            die("error: Invalid value for '--num <num>': invalid float literal")
        die(f"error: Invalid value for '{name}': invalid digit found in string")


def parse_duration(s, opt_name="--for-duration"):
    i = 0
    total = 0.0
    units = [("ms", 0.001), ("us", 0.000001), ("ns", 0.000000001),
             ("h", 3600.0), ("m", 60.0), ("s", 1.0)]
    while i < len(s):
        start = i
        while i < len(s) and (s[i].isdigit() or s[i] == "."):
            i += 1
        if start == i:
            die(f"error: Invalid value for '{opt_name} <{opt_name[2:].replace('-', '_')}>': expected number at {i}")
        try:
            num = float(s[start:i])
        except Exception:
            die(f"error: Invalid value for '{opt_name} <{opt_name[2:].replace('-', '_')}>': expected number at {start}")
        matched = False
        for unit, mult in units:
            if s.startswith(unit, i):
                total += num * mult
                i += len(unit)
                matched = True
                break
        if not matched:
            total += num
    return total


def parse_time(s):
    for fmt in ("%Y-%m-%d %H:%M:%S", "%Y-%m-%dT%H:%M:%S", "%H:%M:%S"):
        try:
            dt = datetime.strptime(s, fmt)
            if fmt == "%H:%M:%S":
                now = datetime.utcnow()
                dt = dt.replace(year=now.year, month=now.month, day=now.day)
            return dt.replace(tzinfo=timezone.utc).timestamp()
        except Exception:
            pass
    die(f"error: Invalid value for '--until-time <until_time>': {s}")


def take_value(argv, i, opt):
    if i + 1 >= len(argv):
        die(f"error: The argument '{opt}' requires a value but none was supplied")
    return argv[i + 1], i + 2


def parse_args(argv):
    opts = Opts()
    i = 0
    while i < len(argv):
        a = argv[i]
        if a == "--":
            opts.input.extend(argv[i + 1:])
            break
        if not a.startswith("-") or a == "-":
            opts.input.extend(argv[i:])
            break
        if a in ("-h", "--help"):
            sys.stdout.write(HELP)
            sys.exit(0)
        if a in ("-V", "--version"):
            sys.stdout.write("loop 0.6.1\n")
            sys.exit(0)
        if a in ("-D", "--error-duration"):
            opts.error_duration = True
            i += 1
            continue
        if a in ("-l", "--only-last"):
            opts.only_last = True
            i += 1
            continue
        if a in ("-i", "--stdin"):
            opts.stdin = True
            i += 1
            continue
        if a == "--summary":
            opts.summary = True
            i += 1
            continue
        if a in ("-C", "--until-changes"):
            opts.until_changes = True
            i += 1
            continue
        if a in ("-f", "--until-fail"):
            opts.until_fail = True
            i += 1
            continue
        if a in ("-S", "--until-same"):
            opts.until_same = True
            i += 1
            continue
        if a in ("-s", "--until-success"):
            opts.until_success = True
            i += 1
            continue

        valopts = {
            "-b": "count_by", "--count-by": "count_by",
            "-e": "every", "--every": "every",
            "--for": "for_values",
            "-d": "for_duration", "--for-duration": "for_duration",
            "-n": "num", "--num": "num",
            "-o": "offset", "--offset": "offset",
            "-c": "until_contains", "--until-contains": "until_contains",
            "-r": "until_error", "--until-error": "until_error",
            "-m": "until_match", "--until-match": "until_match",
            "-t": "until_time", "--until-time": "until_time",
        }
        key = None
        val = None
        if a in valopts:
            key = valopts[a]
            val, i = take_value(argv, i, a)
        else:
            prefixes = [
                ("--count-by=", "count_by"), ("--every=", "every"),
                ("--for=", "for_values"), ("--for-duration=", "for_duration"),
                ("--num=", "num"), ("--offset=", "offset"),
                ("--until-contains=", "until_contains"),
                ("--until-error=", "until_error"),
                ("--until-match=", "until_match"),
                ("--until-time=", "until_time"),
            ]
            for prefix, dest in prefixes:
                if a.startswith(prefix):
                    key = dest
                    val = a[len(prefix):]
                    i += 1
                    break
            if key is None:
                die(f"error: Found argument '{a}' which wasn't expected, or isn't valid in this context\n\nUSAGE:\n    executable [FLAGS] [OPTIONS] [input]...\n\nFor more information try --help")

        if key in ("count_by", "offset", "until_error"):
            setattr(opts, key, parse_int(val, "--" + key.replace("_", "-")))
        elif key == "num":
            opts.num = parse_int(val, "--num")
        elif key == "every":
            opts.every = parse_duration(val, "--every")
        elif key == "for_duration":
            opts.for_duration = parse_duration(val, "--for-duration")
        elif key == "for_values":
            opts.for_values = val.split(",") if val != "" else [""]
        elif key == "until_time":
            opts.until_time = parse_time(val)
        else:
            setattr(opts, key, val)
    return opts


def should_stop(opts, out, status, prev):
    text = out.decode(errors="replace")
    if opts.until_success and status == 0:
        return True
    if opts.until_fail and status != 0:
        return True
    if opts.until_error is not None and status == opts.until_error:
        return True
    if opts.until_contains is not None and opts.until_contains in text:
        return True
    if opts.until_match is not None:
        try:
            if re.search(opts.until_match, text):
                return True
        except re.error:
            return False
    if opts.until_changes and prev is not None and out != prev:
        return True
    if opts.until_same and prev is not None and out == prev:
        return True
    return False


def main():
    opts = parse_args(sys.argv[1:])
    if not opts.input:
        sys.stdout.write("No command supplied, exiting.\n")
        return 0

    command = " ".join(opts.input)
    if opts.stdin:
        items = [line[:-1] if line.endswith("\n") else line for line in sys.stdin.readlines()]
    elif opts.for_values is not None:
        items = opts.for_values
    else:
        items = None

    start = time.monotonic()
    end_time = start + opts.for_duration if opts.for_duration is not None else None
    total = successes = failures = 0
    count = opts.offset
    idx = 0
    prev = None
    last_out = b""
    timed_out = False

    while True:
        if opts.num is not None and total >= opts.num:
            break
        if items is not None and idx >= len(items):
            break
        if opts.until_time is not None and time.time() >= opts.until_time:
            break
        if end_time is not None and time.monotonic() >= end_time:
            timed_out = True
            break

        env = os.environ.copy()
        env["COUNT"] = str(count)
        if items is not None:
            env["ITEM"] = items[idx]

        proc = subprocess.run(command, shell=True, executable="/bin/sh", env=env,
                              stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
        out = proc.stdout
        last_out = out
        total += 1
        if proc.returncode == 0:
            successes += 1
        else:
            failures += 1

        if not opts.only_last:
            try:
                sys.stdout.buffer.write(out)
                sys.stdout.buffer.flush()
            except BrokenPipeError:
                return 0

        stop = should_stop(opts, out, proc.returncode, prev)
        prev = out
        if stop:
            break
        count += opts.count_by
        idx += 1
        if opts.every and opts.every > 0:
            time.sleep(opts.every)

    if opts.only_last:
        try:
            sys.stdout.buffer.write(last_out)
            sys.stdout.buffer.flush()
        except BrokenPipeError:
            return 0
    if opts.summary:
        sys.stdout.write(f"Total runs:\t{total}\nSuccesses:\t{successes}\nFailures:\t{failures}\n")
    if timed_out and opts.error_duration:
        return 124
    return 0


if __name__ == "__main__":
    try:
        sys.exit(main())
    except KeyboardInterrupt:
        sys.exit(130)
