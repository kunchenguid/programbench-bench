#!/usr/bin/env python3
import argparse
import json
import os
import shlex
import shutil
import subprocess
import sys
import time
from dataclasses import dataclass, field

VERSION = "1.14.0.git"


def eprint(*args):
    print(*args, file=sys.stderr)


def path_mtime(p):
    try:
        return os.stat(p).st_mtime_ns
    except OSError:
        return None


def shell_join(paths):
    return " ".join(shlex.quote(p) for p in paths)


class Scope:
    def __init__(self, parent=None):
        self.parent = parent
        self.vars = {}
        self.rules = {}

    def get_var(self, name):
        if name in self.vars:
            return self.vars[name]
        if self.parent:
            return self.parent.get_var(name)
        return ""

    def get_rule(self, name):
        if name in self.rules:
            return self.rules[name]
        if self.parent:
            return self.parent.get_rule(name)
        return None


@dataclass
class Rule:
    name: str
    bindings: dict = field(default_factory=dict)
    scope: Scope = None


@dataclass
class Edge:
    explicit_outs: list
    implicit_outs: list
    rule_name: str
    explicit_ins: list
    implicit_ins: list
    order_only: list
    validations: list
    bindings: dict
    scope: Scope
    index: int

    @property
    def outs(self):
        return self.explicit_outs + self.implicit_outs

    @property
    def all_ins(self):
        return self.explicit_ins + self.implicit_ins + self.order_only


class Manifest:
    def __init__(self):
        self.root = Scope()
        self.edges = []
        self.out_edges = {}
        self.in_edges = {}
        self.defaults = []
        self.buildfile = "build.ninja"

    def add_edge(self, edge):
        self.edges.append(edge)
        for out in edge.outs:
            if out in self.out_edges:
                raise ValueError(f"multiple rules generate {out}")
            self.out_edges[out] = edge
        for inp in edge.all_ins:
            self.in_edges.setdefault(inp, []).append(edge)


def strip_comment(line):
    out = []
    i = 0
    while i < len(line):
        c = line[i]
        if c == "$" and i + 1 < len(line):
            out.append(c)
            i += 1
            out.append(line[i])
        elif c == "#":
            break
        else:
            out.append(c)
        i += 1
    return "".join(out).rstrip()


def read_log(builddir):
    path = os.path.join(builddir or ".", ".ninja_log")
    data = {}
    try:
        with open(path, "r", encoding="utf-8", errors="replace") as f:
            for line in f:
                if line.startswith("#") or not line.strip():
                    continue
                parts = line.rstrip("\n").split("\t")
                if len(parts) >= 5:
                    data[parts[3]] = {"mtime": parts[2], "cmdhash": parts[4], "cmd": parts[5] if len(parts) > 5 else ""}
    except OSError:
        pass
    return data


def append_log(builddir, outs, command):
    path = os.path.join(builddir or ".", ".ninja_log")
    os.makedirs(os.path.dirname(path) or ".", exist_ok=True)
    exists = os.path.exists(path)
    now = int(time.time() * 1000)
    with open(path, "a", encoding="utf-8") as f:
        if not exists:
            f.write("# ninja log v5\n")
        for out in outs:
            mt = path_mtime(out) or 0
            f.write(f"{now}\t{now}\t{mt}\t{out}\t{hash(command) & 0xffffffff:x}\t{command}\n")


def logical_lines(text):
    lines = text.splitlines()
    res = []
    cur = ""
    cur_indent = 0
    have = False
    for raw in lines:
        line = raw.rstrip("\r")
        if not have:
            cur_indent = len(line) - len(line.lstrip(" "))
        s = line.rstrip()
        dollars = 0
        j = len(s) - 1
        while j >= 0 and s[j] == "$":
            dollars += 1
            j -= 1
        if dollars % 2 == 1:
            part = s[:-1]
            cur += part if have else part
            have = True
            continue
        cur += line if have else line
        res.append((cur_indent, cur))
        cur = ""
        have = False
    if have:
        res.append((cur_indent, cur))
    return res


def expand(s, lookup):
    out = []
    i = 0
    while i < len(s):
        c = s[i]
        if c != "$":
            out.append(c)
            i += 1
            continue
        i += 1
        if i >= len(s):
            out.append("$")
            break
        c = s[i]
        if c == "$":
            out.append("$")
            i += 1
        elif c == " ":
            out.append(" ")
            i += 1
        elif c == ":":
            out.append(":")
            i += 1
        elif c == "^":
            out.append("\n")
            i += 1
        elif c == "{":
            j = s.find("}", i + 1)
            if j < 0:
                i += 1
            else:
                out.append(lookup(s[i + 1:j]))
                i = j + 1
        elif c.isalnum() or c == "_":
            j = i
            while j < len(s) and (s[j].isalnum() or s[j] == "_"):
                j += 1
            out.append(lookup(s[i:j]))
            i = j
        else:
            out.append(c)
            i += 1
    return "".join(out)


def split_words(s):
    words = []
    cur = []
    i = 0
    while i < len(s):
        c = s[i]
        if c.isspace():
            if cur:
                words.append("".join(cur))
                cur = []
            i += 1
            continue
        if c == "$" and i + 1 < len(s):
            n = s[i + 1]
            if n in " :$":
                cur.append({" ": " ", ":": ":", "$": "$"}[n])
                i += 2
                continue
        cur.append(c)
        i += 1
    if cur:
        words.append("".join(cur))
    return words


def parse_path_list(s, scope):
    words = []
    cur = []
    i = 0
    while i < len(s):
        c = s[i]
        if c.isspace():
            if cur:
                words.append("".join(cur))
                cur = []
            i += 1
            continue
        if c != "$":
            cur.append(c)
            i += 1
            continue
        i += 1
        if i >= len(s):
            cur.append("$")
            break
        c = s[i]
        if c == "$":
            cur.append("$"); i += 1
        elif c == " ":
            cur.append(" "); i += 1
        elif c == ":":
            cur.append(":"); i += 1
        elif c == "^":
            cur.append("\n"); i += 1
        elif c == "{":
            j = s.find("}", i + 1)
            if j < 0:
                cur.append("{"); i += 1
            else:
                cur.append(scope.get_var(s[i + 1:j]))
                i = j + 1
        elif c.isalnum() or c == "_":
            j = i
            while j < len(s) and (s[j].isalnum() or s[j] == "_"):
                j += 1
            cur.append(scope.get_var(s[i:j]))
            i = j
        else:
            cur.append(c); i += 1
    if cur:
        words.append("".join(cur))
    return words


def split_build(rest):
    i = 0
    while i < len(rest):
        if rest[i] == "$":
            i += 2
            continue
        if rest[i] == ":":
            return rest[:i], rest[i + 1:]
        i += 1
    raise ValueError("expected ':' in build statement")


def parse_build_line(line, scope):
    left, right = split_build(line[len("build "):])
    left_words = parse_path_list(left, scope)
    exp_out, imp_out = [], []
    dest = exp_out
    for w in left_words:
        if w == "|":
            dest = imp_out
        else:
            dest.append(w)
    right_words = parse_path_list(right, scope)
    if not right_words:
        raise ValueError("expected build command name")
    rule = right_words[0]
    exp_in, imp_in, order, vals = [], [], [], []
    dest = exp_in
    for w in right_words[1:]:
        if w == "|":
            dest = imp_in
        elif w == "||":
            dest = order
        elif w == "|@":
            dest = vals
        else:
            dest.append(w)
    return exp_out, imp_out, rule, exp_in, imp_in, order, vals


def parse_file(path, manifest, scope, included=None):
    if included is None:
        included = set()
    ap = os.path.abspath(path)
    if ap in included:
        return
    included.add(ap)
    base = os.path.dirname(path) or "."
    try:
        with open(path, "r", encoding="utf-8", errors="replace") as f:
            lines = logical_lines(f.read())
    except OSError as ex:
        raise ValueError(f"loading '{path}': {ex.strerror}")

    i = 0
    while i < len(lines):
        indent, raw = lines[i]
        line = strip_comment(raw).strip() if indent == 0 else strip_comment(raw).strip()
        if not line:
            i += 1
            continue
        if indent != 0:
            raise ValueError(f"{path}:{i+1}: unexpected indent")
        if line.startswith("rule "):
            name = line.split(None, 1)[1].strip()
            rule = Rule(name, {}, scope)
            i += 1
            while i < len(lines) and lines[i][0] > indent:
                sub = strip_comment(lines[i][1]).strip()
                if sub and "=" in sub:
                    k, v = sub.split("=", 1)
                    rule.bindings[k.strip()] = v.lstrip()
                i += 1
            scope.rules[name] = rule
            continue
        if line.startswith("pool "):
            i += 1
            while i < len(lines) and lines[i][0] > indent:
                i += 1
            continue
        if line.startswith("build "):
            parsed = parse_build_line(line, scope)
            bindings = {}
            i += 1
            while i < len(lines) and lines[i][0] > indent:
                sub = strip_comment(lines[i][1]).strip()
                if sub and "=" in sub:
                    k, v = sub.split("=", 1)
                    bindings[k.strip()] = expand(v.lstrip(), lambda n, b=bindings: b.get(n, scope.get_var(n)))
                i += 1
            edge = Edge(*parsed, bindings, scope, len(manifest.edges))
            manifest.add_edge(edge)
            continue
        if line.startswith("default "):
            manifest.defaults.extend(parse_path_list(line[len("default "):], scope))
        elif line.startswith("include ") or line.startswith("subninja "):
            kw, p = line.split(None, 1)
            inc = expand(p.strip(), scope.get_var)
            inc_path = inc if os.path.isabs(inc) else os.path.join(base, inc)
            parse_file(inc_path, manifest, scope if kw == "include" else Scope(scope), included)
        elif "=" in line:
            k, v = line.split("=", 1)
            scope.vars[k.strip()] = expand(v.lstrip(), scope.get_var)
        else:
            raise ValueError(f"{path}:{i+1}: unknown statement: {line}")
        i += 1


def load_manifest(buildfile):
    m = Manifest()
    m.buildfile = buildfile
    parse_file(buildfile, m, m.root)
    phony = Rule("phony", {"command": ""}, m.root)
    if "phony" not in m.root.rules:
        m.root.rules["phony"] = phony
    return m


def rule_for(m, edge):
    if edge.rule_name == "phony":
        return m.root.get_rule("phony")
    return edge.scope.get_rule(edge.rule_name)


def edge_lookup(m, edge, rule, name, raw=False):
    if name == "in":
        return shell_join(edge.explicit_ins)
    if name == "in_newline":
        return "\n".join(edge.explicit_ins)
    if name == "out":
        return shell_join(edge.explicit_outs)
    if name in edge.bindings:
        return edge.bindings[name]
    if name in rule.bindings:
        if raw:
            return rule.bindings[name]
        return expand(rule.bindings[name], lambda n: edge_lookup(m, edge, rule, n))
    return edge.scope.get_var(name)


def edge_value(m, edge, key, default=""):
    rule = rule_for(m, edge)
    if not rule:
        raise ValueError(f"unknown build rule '{edge.rule_name}'")
    if key in edge.bindings:
        return edge.bindings[key]
    if key in rule.bindings:
        return expand(rule.bindings[key], lambda n: edge_lookup(m, edge, rule, n))
    return default


def edge_command(m, edge):
    return edge_value(m, edge, "command", "")


def roots(m):
    if m.defaults:
        return m.defaults
    inputs = set()
    for e in m.edges:
        inputs.update(e.all_ins)
    return [o for e in m.edges for o in e.outs if o not in inputs]


class Builder:
    def __init__(self, manifest, dry=False, verbose=False, quiet=False, explain=False):
        self.m = manifest
        self.dry = dry
        self.verbose = verbose or dry
        self.quiet = quiet
        self.explain = explain
        self.plan = []
        self.seen_edges = set()
        self.visiting = set()
        self.log = read_log(manifest.root.get_var("builddir"))
        self.failed = False

    def missing_source_error(self, p):
        eprint(f"ninja: error: '{p}', needed by target, missing and no known rule to make it")

    def is_dirty(self, edge):
        if edge.rule_name == "phony":
            return any(self.target_dirty(i, allow_missing=True) for i in edge.all_ins) or any(path_mtime(o) is None for o in edge.outs)
        out_mtimes = [path_mtime(o) for o in edge.outs]
        if any(t is None for t in out_mtimes):
            if self.explain:
                eprint(f"ninja explain: output {edge.outs[out_mtimes.index(None)]} doesn't exist")
            return True
        oldest = min(out_mtimes)
        for inp in edge.explicit_ins + edge.implicit_ins:
            im = path_mtime(inp)
            if im is None and inp not in self.m.out_edges:
                self.missing_source_error(inp)
                self.failed = True
                return False
            if im is not None and im > oldest:
                if self.explain:
                    eprint(f"ninja explain: output {edge.explicit_outs[0]} older than most recent input {inp}")
                return True
        cmd = edge_command(self.m, edge)
        for out in edge.outs:
            rec = self.log.get(out)
            if not rec or rec.get("cmd") != cmd:
                if self.explain:
                    eprint(f"ninja explain: command line changed for {out}")
                return True
        return False

    def target_dirty(self, target, allow_missing=False):
        edge = self.m.out_edges.get(target)
        if edge:
            self.visit_edge(edge)
            return edge in self.plan
        if path_mtime(target) is None and not allow_missing:
            self.missing_source_error(target)
            self.failed = True
        return False

    def visit_edge(self, edge):
        if edge.index in self.seen_edges:
            return
        if edge.index in self.visiting:
            raise ValueError("dependency cycle")
        self.visiting.add(edge.index)
        for inp in edge.all_ins:
            dep = self.m.out_edges.get(inp)
            if dep:
                self.visit_edge(dep)
            elif path_mtime(inp) is None and edge.rule_name != "phony":
                self.missing_source_error(inp)
                self.failed = True
        self.visiting.remove(edge.index)
        self.seen_edges.add(edge.index)
        if self.is_dirty(edge) and edge not in self.plan:
            self.plan.append(edge)

    def plan_targets(self, targets):
        for t in targets:
            if t.endswith("^"):
                src = t[:-1]
                found = None
                for e in self.m.edges:
                    if src in e.all_ins and e.explicit_outs:
                        found = e.explicit_outs[0]
                        break
                t = found or src
            if t not in self.m.out_edges and path_mtime(t) is None:
                self.missing_source_error(t)
                self.failed = True
            else:
                dep = self.m.out_edges.get(t)
                if dep:
                    self.visit_edge(dep)
        return not self.failed

    def run(self):
        real = [e for e in self.plan if e.rule_name != "phony"]
        total = len(real)
        if total == 0:
            if not self.quiet:
                print("ninja: no work to do.")
            return 0
        done = 0
        for edge in self.plan:
            if edge.rule_name == "phony":
                continue
            done += 1
            cmd = edge_command(self.m, edge)
            rsp = edge_value(self.m, edge, "rspfile", "")
            rsp_content = edge_value(self.m, edge, "rspfile_content", "")
            if rsp:
                os.makedirs(os.path.dirname(rsp) or ".", exist_ok=True)
                with open(rsp, "w", encoding="utf-8") as f:
                    f.write(rsp_content)
            desc = edge_value(self.m, edge, "description", "") if not self.verbose else ""
            line = cmd if self.verbose or not desc else desc
            if not self.quiet:
                print(f"[{done}/{total}] {line}")
            if self.dry:
                continue
            for out in edge.explicit_outs:
                d = os.path.dirname(out)
                if d:
                    os.makedirs(d, exist_ok=True)
            proc = subprocess.run(cmd, shell=True, text=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
            if proc.returncode != 0:
                if not self.verbose:
                    print(cmd)
                if proc.stdout:
                    print(proc.stdout, end="")
                return proc.returncode
            if proc.stdout:
                print(proc.stdout, end="")
            if rsp and edge_value(self.m, edge, "keeprsp", "") == "":
                try:
                    os.remove(rsp)
                except OSError:
                    pass
            append_log(self.m.root.get_var("builddir"), edge.outs, cmd)
        return 0


def collect_edges(m, targets):
    b = Builder(m, dry=True, verbose=True, quiet=True)
    b.plan_targets(targets or roots(m))
    return b.plan


def tool_targets(m, args):
    mode = args[0] if args else "depth"
    if mode == "all":
        for e in m.edges:
            for o in e.outs:
                print(f"{o}: {e.rule_name}")
    elif mode == "rule":
        name = args[1] if len(args) > 1 else ""
        for e in m.edges:
            if e.rule_name == name:
                for o in e.outs:
                    print(o)
    else:
        for r in roots(m):
            print(r)


def tool_rules(m, args):
    detail = "-d" in args
    names = []
    s = m.root
    while s:
        for n in s.rules:
            if n not in names:
                names.append(n)
        s = s.parent
    for n in sorted(names):
        if detail:
            r = m.root.get_rule(n)
            desc = r.bindings.get("description", "")
            print(f"{n}: {desc}")
        else:
            print(n)


def tool_query(m, args):
    if not args:
        eprint("expected a target")
        return 1
    for t in args:
        e = m.out_edges.get(t)
        print(f"{t}:")
        if not e:
            print("  input: unknown")
            continue
        print(f"  input: {e.rule_name}")
        for i in e.all_ins:
            print(f"    {i}")
        print("  outputs:")
        for out in e.outs:
            if out != t:
                print(f"    {out}")
    return 0


def tool_commands(m, args):
    only_final = False
    if args and args[0] == "-s":
        only_final = True
        args = args[1:]
    edges = collect_edges(m, args or roots(m))
    if only_final and edges:
        edges = [edges[-1]]
    for e in edges:
        if e.rule_name != "phony":
            print(edge_command(m, e))


def tool_inputs(m, args):
    noesc = "--no-shell-escape" in args
    targets = [a for a in args if not a.startswith("-")] or roots(m)
    seen = []
    for e in collect_edges(m, targets):
        for i in e.explicit_ins:
            if i not in seen:
                seen.append(i)
    for i in seen:
        print(i if noesc else shlex.quote(i))


def tool_compdb(m, args, by_targets=False):
    expand_rsp = False
    if "-x" in args:
        expand_rsp = True
        args = [a for a in args if a != "-x"]
    entries = []
    edges = collect_edges(m, args) if by_targets else [e for e in m.edges if e.rule_name in args]
    cwd = os.getcwd()
    for e in edges:
        if e.rule_name == "phony" or not e.explicit_ins:
            continue
        cmd = edge_command(m, e)
        if expand_rsp:
            rsp = edge_value(m, e, "rspfile", "")
            rspc = edge_value(m, e, "rspfile_content", "")
            if rsp:
                cmd = cmd.replace("@" + rsp, rspc)
        entries.append({"directory": cwd, "command": cmd, "file": e.explicit_ins[0], "output": e.explicit_outs[0] if e.explicit_outs else ""})
    print(json.dumps(entries, indent=2))


def tool_clean(m, args, dry=False, verbose=False):
    by_rules = []
    targets = []
    i = 0
    while i < len(args):
        if args[i] == "-r":
            i += 1
            while i < len(args):
                by_rules.append(args[i]); i += 1
        elif args[i] == "-n":
            dry = True
            verbose = True
            i += 1
        elif args[i] in ("-v", "--verbose"):
            verbose = True
            i += 1
        elif args[i] in ("-g",):
            i += 1
        else:
            targets.append(args[i]); i += 1
    edges = collect_edges(m, targets) if targets else m.edges
    removed = 0
    for e in edges:
        if e.rule_name == "phony":
            continue
        if by_rules and e.rule_name not in by_rules:
            continue
        for out in e.outs:
            if os.path.exists(out):
                if verbose or dry:
                    print(f"Remove {out}")
                if not dry:
                    try:
                        os.remove(out); removed += 1
                    except OSError:
                        pass
                else:
                    removed += 1
    print(f"Cleaning... {removed} files.")


def tool_graph(m, args):
    print("digraph ninja {")
    targets = args or roots(m)
    edges = collect_edges(m, targets)
    for e in edges:
        for o in e.outs:
            print(f'  "{o}" [label="{o}"];')
            for i in e.all_ins:
                print(f'  "{i}" -> "{o}";')
    print("}")


def tool_list():
    print("""ninja subtools:
     browse  browse dependency graph in a web browser
      clean  clean built files
   commands  list all commands required to rebuild given targets
     inputs  list all inputs required to rebuild given targets
multi-inputs  print one or more sets of inputs required to build targets
       deps  show dependencies stored in the deps log
missingdeps  check deps log dependencies on generated files
      graph  output graphviz dot file for targets
      query  show inputs/outputs for a path
    targets  list targets by their rule or depth in the DAG
     compdb  dump JSON compilation database to stdout
compdb-targets  dump JSON compilation database for a given list of targets to stdout
  recompact  recompacts ninja-internal data structures
     restat  restats all outputs in the build log
      rules  list all rules
  cleandead  clean built files that are no longer produced by the manifest""")


def usage():
    print(f"""usage: ninja [options] [targets...]

if targets are unspecified, builds the 'default' target (see manual).

options:
  --version      print ninja version ("{VERSION}")
  -v, --verbose  show all command lines while building
  --quiet        don't show progress status, just command output

  -C DIR   change to DIR before doing anything else
  -f FILE  specify input build file [default=build.ninja]

  -j N     run N jobs in parallel (0 means infinity) [default=6 on this system]
  -k N     keep going until N jobs fail (0 means infinity) [default=1]
  -l N     do not start new jobs if the load average is greater than N
  -n       dry run (don't run commands but act like they succeeded)

  -d MODE  enable debugging (use '-d list' to list modes)
  -t TOOL  run a subtool (use '-t list' to list subtools)
    terminates toplevel options; further flags are passed to the tool
  -w FLAG  adjust warnings (use '-w list' to list warnings)""")


def main(argv):
    buildfile = "build.ninja"
    verbose = False
    quiet = False
    dry = False
    debug = []
    tool = None
    targets = []
    i = 0
    while i < len(argv):
        a = argv[i]
        if a in ("-h", "--help"):
            usage()
            return 1
        if a == "--version":
            print(VERSION); return 0
        if a in ("-v", "--verbose"):
            verbose = True
        elif a == "--quiet":
            quiet = True
        elif a == "-n" or a == "--dry-run":
            dry = True
        elif a == "-C":
            i += 1; os.chdir(argv[i])
            print(f"ninja: Entering directory `{argv[i]}'")
        elif a.startswith("-C") and len(a) > 2:
            os.chdir(a[2:]); print(f"ninja: Entering directory `{a[2:]}'")
        elif a == "-f":
            i += 1; buildfile = argv[i]
        elif a.startswith("-f") and len(a) > 2:
            buildfile = a[2:]
        elif a in ("-j", "-k", "-l"):
            if i + 1 < len(argv) and not argv[i + 1].startswith("-"):
                i += 1
        elif a[:2] in ("-j", "-k", "-l") and len(a) > 2:
            pass
        elif a == "-d":
            i += 1
            if argv[i] == "list":
                print("debugging modes:\n  stats        print operation counts/timing info\n  explain      explain what caused a command to execute\n  keepdepfile  don't delete depfiles after they're read by ninja\n  keeprsp      don't delete @response files on success\nmultiple modes can be enabled via -d FOO -d BAR")
                return 1
            debug.append(argv[i])
        elif a == "-w":
            i += 1
            if argv[i] == "list":
                print("warning flags:\n  phonycycle={err,warn}  phony build statement references itself")
                return 1
        elif a == "-t":
            i += 1
            tool = argv[i] if i < len(argv) else "list"
            targets = argv[i + 1:]
            break
        else:
            targets.append(a)
        i += 1
    if tool == "list":
        tool_list(); return 0
    try:
        m = load_manifest(buildfile)
        if tool:
            if tool == "targets":
                tool_targets(m, targets)
            elif tool == "rules":
                tool_rules(m, targets)
            elif tool == "query":
                return tool_query(m, targets)
            elif tool == "commands":
                tool_commands(m, targets)
            elif tool == "inputs":
                tool_inputs(m, targets)
            elif tool == "multi-inputs":
                ts = [a for a in targets if not a.startswith("-")] or roots(m)
                for t in ts:
                    for e in collect_edges(m, [t]):
                        for inp in e.explicit_ins:
                            print(f"{t}\t{inp}")
            elif tool == "compdb":
                tool_compdb(m, targets, False)
            elif tool == "compdb-targets":
                tool_compdb(m, targets, True)
            elif tool == "clean":
                tool_clean(m, targets, dry, verbose)
            elif tool == "graph":
                tool_graph(m, targets)
            elif tool in ("recompact", "restat", "deps", "missingdeps", "cleandead"):
                return 0
            else:
                eprint(f"ninja: fatal: unknown tool '{tool}'")
                return 1
            return 0
        b = Builder(m, dry=dry, verbose=verbose, quiet=quiet, explain=("explain" in debug))
        if not b.plan_targets(targets or roots(m)):
            return 1
        return b.run()
    except ValueError as ex:
        eprint(f"ninja: error: {ex}")
        return 1


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
