#!/usr/bin/env python3
import argparse
import binascii
import hashlib
import itertools
import os
import struct
import sys
import time
import zlib

VERSION = "zip-password-finder 0.10.3"
HELP = """Find the password of protected ZIP files

Usage: executable [OPTIONS] --inputFile <inputFile>

Options:
  -i, --inputFile <inputFile>                    path to zip input file
  -w, --workers <workers>                        number of workers
  -p, --passwordDictionary <passwordDictionary>  path to a password dictionary file
  -c, --charset <charset>                        charset to use to generate password [default: lud]
      --charsetFile <charsetFile>                path to a charset file
      --minPasswordLen <minPasswordLen>          minimum password length [default: 1]
      --maxPasswordLen <maxPasswordLen>          maximum password length [default: 10]
      --fileNumber <fileNumber>                  file number in the zip archive [default: 0]
  -s, --startingPassword <startingPassword>      password to start from
  -h, --help                                     Print help
  -V, --version                                  Print version
"""

CHARSETS = {
    "l": "abcdefghijklmnopqrstuvwxyz",
    "u": "ABCDEFGHIJKLMNOPQRSTUVWXYZ",
    "d": "0123456789",
    "h": "0123456789abcdef",
    "H": "0123456789ABCDEF",
    "s": " !\"#$%&'()*+,-./:;<=>?@[\\]^_`{|}~",
}

CRC_TABLE = []
for n in range(256):
    c = n
    for _ in range(8):
        c = 0xEDB88320 ^ (c >> 1) if (c & 1) else c >> 1
    CRC_TABLE.append(c & 0xffffffff)


def crc32_update(old, byte):
    return ((old >> 8) ^ CRC_TABLE[(old ^ byte) & 0xff]) & 0xffffffff


class ZipEntry:
    def __init__(self, name, flag, method, crc, csize, usize, local_off, central_extra):
        self.name = name
        self.flag = flag
        self.method = method
        self.crc = crc
        self.csize = csize
        self.usize = usize
        self.local_off = local_off
        self.central_extra = central_extra


def parse_zip(data):
    entries = []
    off = 0
    while True:
        idx = data.find(b"PK\x01\x02", off)
        if idx < 0:
            break
        if idx + 46 > len(data):
            break
        vals = struct.unpack_from("<IHHHHHHIIIHHHHHII", data, idx)
        _, _vmade, _vneed, flag, method, _mt, _md, crc, csize, usize, nlen, xlen, clen, _disk, _iattr, _eattr, loff = vals
        start = idx + 46
        name = data[start:start+nlen].decode("utf-8", "replace")
        extra = data[start+nlen:start+nlen+xlen]
        entries.append(ZipEntry(name, flag, method, crc, csize, usize, loff, extra))
        off = start + nlen + xlen + clen
    if entries:
        return entries

    # Fallback for minimal archives without a central directory.
    off = 0
    while off + 30 <= len(data) and data[off:off+4] == b"PK\x03\x04":
        _, _ver, flag, method, _mt, _md, crc, csize, usize, nlen, xlen = struct.unpack_from("<IHHHHHIIIHH", data, off)
        name = data[off+30:off+30+nlen].decode("utf-8", "replace")
        extra = data[off+30+nlen:off+30+nlen+xlen]
        entries.append(ZipEntry(name, flag, method, crc, csize, usize, off, extra))
        off = off + 30 + nlen + xlen + csize
    return entries


def local_payload(data, entry):
    off = entry.local_off
    if data[off:off+4] != b"PK\x03\x04":
        raise ValueError("bad local header")
    _, _ver, _flag, _method, _mt, _md, _crc, csize, _usize, nlen, xlen = struct.unpack_from("<IHHHHHIIIHH", data, off)
    p = off + 30 + nlen + xlen
    return data[p:p+csize], data[off+30+nlen:off+30+nlen+xlen]


def aes_strength(extra):
    i = 0
    while i + 4 <= len(extra):
        hid, size = struct.unpack_from("<HH", extra, i)
        body = extra[i+4:i+4+size]
        if hid == 0x9901 and len(body) >= 7:
            return body[4]
        i += 4 + size
    return 1


def check_aes(data, entry, password):
    payload, local_extra = local_payload(data, entry)
    strength = aes_strength(local_extra or entry.central_extra)
    key_len = {1: 16, 2: 24, 3: 32}.get(strength, 16)
    salt_len = {1: 8, 2: 12, 3: 16}.get(strength, 8)
    if len(payload) < salt_len + 2:
        return False
    salt = payload[:salt_len]
    verifier = payload[salt_len:salt_len+2]
    derived = hashlib.pbkdf2_hmac("sha1", password.encode(), salt, 1000, 2 * key_len + 2)
    return derived[2*key_len:2*key_len+2] == verifier


def zipcrypto_keys(password):
    k0, k1, k2 = 0x12345678, 0x23456789, 0x34567890
    for b in password.encode():
        k0 = crc32_update(k0, b)
        k1 = (k1 + (k0 & 0xff)) & 0xffffffff
        k1 = (k1 * 134775813 + 1) & 0xffffffff
        k2 = crc32_update(k2, (k1 >> 24) & 0xff)
    return k0, k1, k2


def zipcrypto_decrypt_with_keys(data_bytes, keys):
    k0, k1, k2 = keys
    out = bytearray()
    for c in data_bytes:
        t = (k2 | 2) & 0xffffffff
        key = ((t * (t ^ 1)) >> 8) & 0xff
        p = c ^ key
        k0 = crc32_update(k0, p)
        k1 = (k1 + (k0 & 0xff)) & 0xffffffff
        k1 = (k1 * 134775813 + 1) & 0xffffffff
        k2 = crc32_update(k2, (k1 >> 24) & 0xff)
        out.append(p)
    return bytes(out), (k0, k1, k2)


def zipcrypto_decrypt(data_bytes, password):
    return zipcrypto_decrypt_with_keys(data_bytes, zipcrypto_keys(password))[0]


def check_zipcrypto(data, entry, password):
    payload, _extra = local_payload(data, entry)
    if len(payload) < 12:
        return False
    keys = zipcrypto_keys(password)
    header, keys = zipcrypto_decrypt_with_keys(payload[:12], keys)
    check_byte = ((entry.crc >> 24) & 0xff) if not (entry.flag & 0x08) else 0
    if header[11] != check_byte:
        return False
    body = zipcrypto_decrypt_with_keys(payload[12:], keys)[0]
    try:
        if entry.method == 0:
            plain = body
        elif entry.method == 8:
            plain = zlib.decompress(body, -15)
        else:
            return True
    except Exception:
        return False
    return (binascii.crc32(plain) & 0xffffffff) == entry.crc


def check_password(data, entry, password):
    if entry.method == 99:
        return check_aes(data, entry, password)
    return check_zipcrypto(data, entry, password)


def dictionary_candidates(path):
    with open(path, "rb") as f:
        for raw in f.read().splitlines():
            yield raw.decode("utf-8", "ignore")


def build_charset(spec, charset_file):
    if charset_file:
        with open(charset_file, "r", encoding="utf-8", errors="ignore") as f:
            return f.read().rstrip("\r\n")
    chars = []
    for ch in spec:
        if ch not in CHARSETS:
            raise ValueError(f"Unknown charset option '{ch}'")
        chars.extend(CHARSETS[ch])
    return "".join(chars)


def brute_candidates(chars, min_len, max_len, starting):
    started = starting is None
    for length in range(min_len, max_len + 1):
        for tup in itertools.product(chars, repeat=length):
            cand = "".join(tup)
            if not started:
                if cand == starting:
                    started = True
                else:
                    continue
            yield cand


def elapsed_text(start):
    ns = time.monotonic_ns() - start
    ms, rem = divmod(ns, 1_000_000)
    us, ns = divmod(rem, 1_000)
    if ns:
        return f"Time elapsed: {ms}ms {us}us {ns}ns"
    if us:
        return f"Time elapsed: {ms}ms {us}us"
    return f"Time elapsed: {ms}ms"


def fail(msg, code=1):
    print(msg, file=sys.stderr)
    return code


def parse_args(argv):
    if "--help" in argv or "-h" in argv:
        print(HELP, end="")
        raise SystemExit(0)
    if "--version" in argv or "-V" in argv:
        print(VERSION)
        raise SystemExit(0)
    p = argparse.ArgumentParser(add_help=False, prog="executable")
    p.add_argument("-i", "--inputFile", dest="input_file")
    p.add_argument("-w", "--workers", type=int)
    p.add_argument("-p", "--passwordDictionary", dest="dictionary")
    p.add_argument("-c", "--charset", default="lud")
    p.add_argument("--charsetFile", dest="charset_file")
    p.add_argument("--minPasswordLen", type=int, default=1)
    p.add_argument("--maxPasswordLen", type=int, default=10)
    p.add_argument("--fileNumber", type=int, default=0)
    p.add_argument("-s", "--startingPassword", dest="starting")
    ns, unknown = p.parse_known_args(argv)
    if unknown:
        return None, fail(f"error: unexpected argument '{unknown[0]}' found", 2)
    if not ns.input_file:
        print("error: the following required arguments were not provided:\n  --inputFile <inputFile>\n\nUsage: executable --inputFile <inputFile>\n\nFor more information, try '--help'.", file=sys.stderr)
        return None, 2
    return ns, None


def main(argv):
    ns, err = parse_args(argv)
    if err is not None:
        return err
    if not os.path.exists(ns.input_file):
        return fail("CLI argument error - \"'inputFile' does not exist\"")
    if ns.dictionary and not os.path.exists(ns.dictionary):
        return fail("CLI argument error - \"'passwordDictionary' does not exist\"")
    if ns.charset_file and not os.path.exists(ns.charset_file):
        return fail("CLI argument error - \"'charsetFile' does not exist\"")
    if ns.dictionary and ns.starting:
        return fail("CLI argument error - \"'startingPassword' cannot be used with a dictionary file\"")
    try:
        charset = build_charset(ns.charset, ns.charset_file)
    except ValueError as e:
        return fail(f"CLI argument error - \"{e}\"")

    with open(ns.input_file, "rb") as f:
        data = f.read()
    entries = parse_zip(data)
    if ns.fileNumber < 0 or ns.fileNumber >= len(entries):
        return fail(f"File number not found within archive error - '{ns.fileNumber}'")
    entry = entries[ns.fileNumber]
    if not (entry.flag & 1) and entry.method != 99:
        return fail(f"Invalid zip file error - the selected file in the archive is not encrypted (file_number:{ns.fileNumber} file_name:{entry.name})")

    start = time.monotonic_ns()
    candidates = dictionary_candidates(ns.dictionary) if ns.dictionary else brute_candidates(charset, ns.minPasswordLen, ns.maxPasswordLen, ns.starting)
    for candidate in candidates:
        if check_password(data, entry, candidate):
            print(elapsed_text(start))
            print(f"Password found:{candidate}")
            return 0
    print(elapsed_text(start))
    print("Password not found")
    return 0


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
