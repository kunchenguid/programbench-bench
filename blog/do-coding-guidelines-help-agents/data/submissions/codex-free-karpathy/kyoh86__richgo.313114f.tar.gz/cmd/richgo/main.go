package main

import (
	"bufio"
	"fmt"
	"io"
	"os"
	"os/exec"
	"path/filepath"
	"regexp"
	"strconv"
	"strings"
)

type Style struct {
	Hide       bool
	Bold       bool
	Foreground string
}

type Config struct {
	LabelType       string
	CoverThreshold  float64
	LeaveTestPrefix bool
	Removals        []*regexp.Regexp
	Styles          map[string]Style
}

func defaultConfig() Config {
	return Config{
		LabelType:      "long",
		CoverThreshold: 50,
		Styles: map[string]Style{
			"buildStyle":       {Bold: true, Foreground: "yellow"},
			"startStyle":       {Foreground: "lightBlack"},
			"passStyle":        {Foreground: "green"},
			"failStyle":        {Bold: true, Foreground: "red"},
			"skipStyle":        {Foreground: "lightBlack"},
			"passPackageStyle": {Foreground: "green", Hide: true},
			"failPackageStyle": {Bold: true, Foreground: "red", Hide: true},
			"coveredStyle":     {Foreground: "green"},
			"uncoveredStyle":   {Bold: true, Foreground: "yellow"},
			"fileStyle":        {Foreground: "cyan"},
			"lineStyle":        {Foreground: "magenta"},
		},
	}
}

func main() {
	args := os.Args[1:]
	if len(args) > 0 && args[0] == "testfilter" {
		filter(os.Stdin, os.Stdout, colorEnabled(os.Stdout))
		return
	}
	if len(args) > 0 && args[0] == "test" {
		code := runGoTest(args)
		os.Exit(code)
	}
	os.Exit(runGo(args, false))
}

func runGo(args []string, filterOutput bool) int {
	cmd := exec.Command("go", args...)
	cmd.Stdin = os.Stdin
	if filterOutput {
		out, err := cmd.StdoutPipe()
		if err != nil {
			fmt.Fprintln(os.Stderr, err)
			return 1
		}
		cmd.Stderr = cmd.Stdout
		if err := cmd.Start(); err != nil {
			fmt.Fprintln(os.Stderr, err)
			return 1
		}
		filter(out, os.Stdout, colorEnabled(os.Stdout))
		return waitStatus(cmd.Wait())
	}
	cmd.Stdout = os.Stdout
	cmd.Stderr = os.Stderr
	if err := cmd.Run(); err != nil {
		return waitStatus(err)
	}
	return 0
}

func runGoTest(args []string) int {
	return runGo(args, true)
}

func waitStatus(err error) int {
	if err == nil {
		return 0
	}
	if ee, ok := err.(*exec.ExitError); ok {
		return ee.ExitCode()
	}
	return 1
}

func colorEnabled(w *os.File) bool {
	if os.Getenv("RICHGO_FORCE_COLOR") != "" {
		return true
	}
	st, err := w.Stat()
	return err == nil && (st.Mode()&os.ModeCharDevice) != 0
}

func filter(r io.Reader, w io.Writer, color bool) {
	if !color {
		io.Copy(w, r)
		return
	}
	cfg := loadConfig()
	sc := bufio.NewScanner(r)
	sc.Buffer(make([]byte, 0, 64*1024), 1024*1024)
	for sc.Scan() {
		line := sc.Text()
		if cfg.removed(line) {
			continue
		}
		if out, ok := formatLine(line, cfg); ok {
			if out != "" {
				fmt.Fprintln(w, out)
			}
		} else {
			fmt.Fprintln(w, paint(label(cfg, "")+line, cfg.Styles["startStyle"]))
		}
	}
}

func (c Config) removed(s string) bool {
	for _, re := range c.Removals {
		if re.MatchString(s) {
			return true
		}
	}
	return false
}

var (
	runRe      = regexp.MustCompile(`^=== RUN   (.+)$`)
	resultRe   = regexp.MustCompile(`^--- (PASS|FAIL|SKIP): (.+)$`)
	fileLineRe = regexp.MustCompile(`^(\s*)([^:\s][^:]*):([0-9]+):(.*)$`)
	coverRe    = regexp.MustCompile(`^coverage: ([0-9]+(?:\.[0-9]+)?)% of statements`)
	okRe       = regexp.MustCompile(`^ok\s+(\S+)\s+(.+)$`)
	failPkgRe  = regexp.MustCompile(`^FAIL( .+)$`)
	noTestRe   = regexp.MustCompile(`^\?\s+(\S+)\s+\[no test files\]`)
)

func formatLine(line string, cfg Config) (string, bool) {
	if m := runRe.FindStringSubmatch(line); m != nil {
		return paint(label(cfg, "start")+formatTestName(m[1], cfg), cfg.Styles["startStyle"]), true
	}
	if strings.HasPrefix(line, "=== ") {
		return paint(label(cfg, "")+line, cfg.Styles["startStyle"]), true
	}
	if m := resultRe.FindStringSubmatch(line); m != nil {
		kind := strings.ToLower(m[1])
		style := cfg.Styles[kind+"Style"]
		return paint(label(cfg, kind)+formatTestName(m[2], cfg), style), true
	}
	if m := noTestRe.FindStringSubmatch(line); m != nil {
		return paint(label(cfg, "skip")+m[1]+" [no test files]", cfg.Styles["skipStyle"]), true
	}
	if m := okRe.FindStringSubmatch(line); m != nil {
		st := cfg.Styles["passPackageStyle"]
		rest := m[2]
		if strings.Contains(rest, "coverage:") {
			rest = rest[strings.Index(rest, "coverage:"):]
		} else if strings.HasPrefix(rest, "(") {
			rest = ""
		} else {
			fields := strings.Fields(rest)
			if len(fields) > 1 {
				rest = strings.Join(fields[1:], " ")
			} else {
				rest = ""
			}
		}
		if rest != "" {
			rest = " " + rest
		} else {
			rest = " "
		}
		return paint(label(cfg, "pass")+m[1]+rest, st), true
	}
	if line == "PASS" {
		st := cfg.Styles["passPackageStyle"]
		if st.Hide {
			return "", true
		}
		return paint(label(cfg, "passPackage")+"PASS", st), true
	}
	if line == "FAIL" {
		st := cfg.Styles["failPackageStyle"]
		if st.Hide {
			return "", true
		}
		return paint(label(cfg, "failPackage")+"FAIL", st), true
	}
	if m := failPkgRe.FindStringSubmatch(line); m != nil {
		st := cfg.Styles["failPackageStyle"]
		return paint(label(cfg, "fail")+m[1], st), true
	}
	if m := coverRe.FindStringSubmatch(line); m != nil {
		pct, _ := strconv.ParseFloat(m[1], 64)
		st := cfg.Styles["coveredStyle"]
		if pct < cfg.CoverThreshold {
			st = cfg.Styles["uncoveredStyle"]
		}
		n := int(pct / 10)
		if n < 0 {
			n = 0
		}
		if n > 10 {
			n = 10
		}
		bar := strings.Repeat("#", n) + strings.Repeat("_", 10-n)
		return paint(label(cfg, "cover")+fmt.Sprintf("%s%% [%s]", m[1], bar), st), true
	}
	if m := fileLineRe.FindStringSubmatch(line); m != nil {
		st := cfg.Styles["startStyle"]
		return paint(label(cfg, "")+m[1], st) +
			paint(m[2], cfg.Styles["fileStyle"]) +
			paint(":"+m[3], cfg.Styles["lineStyle"]) +
			paint(":"+m[4], st), true
	}
	if strings.HasPrefix(line, "# ") {
		return paint(label(cfg, "build")+line, cfg.Styles["buildStyle"]), true
	}
	return "", false
}

func formatTestName(s string, cfg Config) string {
	parts := strings.SplitN(s, " ", 2)
	name := parts[0]
	suffix := ""
	if len(parts) == 2 {
		suffix = " " + parts[1]
	}
	if !cfg.LeaveTestPrefix && strings.HasPrefix(name, "Test") {
		name = strings.TrimPrefix(name, "Test")
	}
	indent := strings.Repeat("  ", strings.Count(name, "/"))
	return indent + name + suffix
}

func label(cfg Config, kind string) string {
	if cfg.LabelType == "none" {
		return ""
	}
	if cfg.LabelType == "short" {
		switch kind {
		case "build":
			return "!! "
		case "start":
			return "> "
		case "pass", "passPackage":
			return "o "
		case "fail", "failPackage":
			return "x "
		case "skip":
			return "- "
		case "cover":
			return "% "
		default:
			return "  "
		}
	}
	switch kind {
	case "build":
		return "BUILD| "
	case "start":
		return "START| "
	case "pass", "passPackage":
		return "PASS | "
	case "fail", "failPackage":
		return "FAIL | "
	case "skip":
		return "SKIP | "
	case "cover":
		return "COVER| "
	default:
		return "     | "
	}
}

func paint(s string, st Style) string {
	var codes []string
	if st.Foreground != "" {
		if c := colorCode(st.Foreground); c != "" {
			codes = append(codes, c)
		}
	}
	if st.Bold {
		codes = append(codes, "1")
	}
	if len(codes) == 0 {
		return s
	}
	var b strings.Builder
	for _, c := range codes {
		b.WriteString("\x1b[")
		b.WriteString(c)
		b.WriteString("m")
	}
	b.WriteString(s)
	b.WriteString("\x1b[0m")
	return b.String()
}

func colorCode(name string) string {
	switch strings.ToLower(strings.Trim(name, `"'`)) {
	case "black":
		return "30"
	case "red":
		return "31"
	case "green":
		return "32"
	case "yellow":
		return "33"
	case "blue":
		return "34"
	case "magenta":
		return "35"
	case "cyan":
		return "36"
	case "white":
		return "37"
	case "lightblack", "brightblack", "gray", "grey":
		return "90"
	case "lightred":
		return "91"
	case "lightgreen":
		return "92"
	case "lightyellow":
		return "93"
	case "lightblue":
		return "94"
	case "lightmagenta":
		return "95"
	case "lightcyan":
		return "96"
	case "lightwhite":
		return "97"
	}
	return ""
}

func loadConfig() Config {
	cfg := defaultConfig()
	for _, p := range configPaths() {
		if b, err := os.ReadFile(p); err == nil {
			parseConfig(string(b), &cfg)
			return cfg
		}
	}
	return cfg
}

func configPaths() []string {
	cwd, _ := os.Getwd()
	add := func(base string) []string {
		if base == "" {
			return nil
		}
		return []string{
			filepath.Join(base, ".richstyle"),
			filepath.Join(base, ".richstyle.yaml"),
			filepath.Join(base, ".richstyle.yml"),
		}
	}
	var paths []string
	paths = append(paths, add(cwd)...)
	if os.Getenv("RICHGO_LOCAL") != "1" {
		paths = append(paths, add(os.Getenv("GOPATH"))...)
		paths = append(paths, add(os.Getenv("GOROOT"))...)
		paths = append(paths, add(os.Getenv("HOME"))...)
	}
	return paths
}

func parseConfig(src string, cfg *Config) {
	var section string
	inRemovals := false
	for _, raw := range strings.Split(src, "\n") {
		line := strings.TrimRight(raw, " \t\r")
		clean := strings.TrimSpace(line)
		if clean == "" || strings.HasPrefix(clean, "#") {
			continue
		}
		if strings.HasPrefix(clean, "- ") && inRemovals {
			if re, err := regexp.Compile(unquote(strings.TrimSpace(clean[2:]))); err == nil {
				cfg.Removals = append(cfg.Removals, re)
			}
			continue
		}
		inRemovals = false
		if !strings.Contains(clean, ":") {
			continue
		}
		parts := strings.SplitN(clean, ":", 2)
		key := strings.TrimSpace(parts[0])
		val := strings.TrimSpace(parts[1])
		if val == "" {
			section = key
			if key == "removals" {
				inRemovals = true
			}
			continue
		}
		if section != "" && strings.HasSuffix(section, "Style") {
			st := cfg.Styles[section]
			switch key {
			case "hide":
				st.Hide = parseBool(val)
			case "bold":
				st.Bold = parseBool(val)
			case "foreground":
				st.Foreground = unquote(val)
			}
			cfg.Styles[section] = st
			continue
		}
		section = ""
		switch key {
		case "labelType":
			cfg.LabelType = unquote(val)
		case "coverThreshold":
			if f, err := strconv.ParseFloat(unquote(val), 64); err == nil {
				cfg.CoverThreshold = f
			}
		case "leaveTestPrefix":
			cfg.LeaveTestPrefix = parseBool(val)
		}
	}
}

func parseBool(s string) bool {
	s = strings.ToLower(unquote(s))
	return s == "true" || s == "1" || s == "yes"
}

func unquote(s string) string {
	s = strings.TrimSpace(s)
	s = strings.Trim(s, `"'`)
	return s
}
