module reimpl-richgo

go 1.21
