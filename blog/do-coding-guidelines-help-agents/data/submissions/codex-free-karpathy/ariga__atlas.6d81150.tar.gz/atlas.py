#!/usr/bin/env python3
import base64
import hashlib
import os
import sys
from datetime import datetime


ROOT_HELP = """Manage your database schema as code

Usage:
  atlas [command]

Available Commands:
  completion  Generate the autocompletion script for the specified shell
  help        Help about any command
  license     Display license information
  migrate     Manage versioned migration files
  schema      Work with atlas schemas.
  version     Prints this Atlas CLI version information.

Flags:
  -h, --help   help for atlas

Use "atlas [command] --help" for more information about a command.
"""

SCHEMA_HELP = """The `atlas schema` command groups subcommands working with declarative Atlas schemas.

Usage:
  atlas schema [command]

Available Commands:
  apply       Apply an atlas schema to a target database.
  clean       Removes all objects from the connected database.
  diff        Calculate and print the diff between two schemas.
  fmt         Formats Atlas HCL files
  inspect     Inspect a database and print its schema in Atlas DDL syntax.

Flags:
  -c, --config string        select config (project) file using URL format (default "file://atlas.hcl")
      --env string           set which env from the config file to use
  -h, --help                 help for schema
      --var <name>=<value>   input variables (default [])

Use "atlas schema [command] --help" for more information about a command.
"""

MIGRATE_HELP = """'atlas migrate' wraps several sub-commands for migration management.

Usage:
  atlas migrate [command]

Available Commands:
  apply       Applies pending migration files on the connected database.
  diff        Compute the diff between the migration directory and a desired state and create a new migration file.
  hash        Hash (re-)creates an integrity hash file for the migration directory.
  import      Import a migration directory from another migration management tool to the Atlas format.
  lint        Run analysis on the migration directory
  new         Creates a new empty migration file in the migration directory.
  set         Set the current version of the migration history table.
  status      Get information about the current migration status.
  validate    Validates the migration directories checksum and SQL statements.

Flags:
  -c, --config string        select config (project) file using URL format (default "file://atlas.hcl")
      --env string           set which env from the config file to use
  -h, --help                 help for migrate
      --var <name>=<value>   input variables (default [])

Use "atlas migrate [command] --help" for more information about a command.
"""

FMT_HELP = """'atlas schema fmt' formats all ".hcl" files under the given paths using
canonical HCL layout style as defined by the github.com/hashicorp/hcl/v2/hclwrite package.
Unless stated otherwise, the fmt command will use the current directory.

After running, the command will print the names of the files it has formatted. If all
files in the directory are formatted, no input will be printed out.

Usage:
  atlas schema fmt [path ...] [flags]

Flags:
  -h, --help   help for fmt

Global Flags:
  -c, --config string        select config (project) file using URL format (default "file://atlas.hcl")
      --env string           set which env from the config file to use
      --var <name>=<value>   input variables (default [])
"""

INSPECT_HELP = """'atlas schema inspect' connects to the given database and inspects its schema.
It then prints to the screen the schema of that database in Atlas DDL syntax. This output can be
saved to a file, commonly by redirecting the output to a file named with a ".hcl" suffix:

  atlas schema inspect -u "mysql://user:pass@localhost:3306/dbname" > schema.hcl

Usage:
  atlas schema inspect [flags]

Flags:
  -u, --url string        [driver://username:password@address/dbname?param=value] select a resource using the URL format
      --dev-url string    [driver://username:password@address/dbname?param=value] select a dev database using the URL format
  -s, --schema strings    set schema names
      --exclude strings   list of glob patterns used to filter resources from applying
      --format string     Go template to use to format the output
  -h, --help              help for inspect

Global Flags:
  -c, --config string        select config (project) file using URL format (default "file://atlas.hcl")
      --env string           set which env from the config file to use
      --var <name>=<value>   input variables (default [])
"""

MIGRATE_NEW_HELP = """'atlas migrate new' creates a new migration according to the configured formatter without any statements in it.

Usage:
  atlas migrate new [flags] [name]

Examples:
  atlas migrate new my-new-migration

Flags:
      --dir string          select migration directory using URL format (default "file://migrations")
      --dir-format string   select migration file format (default "atlas")
      --edit                edit the created migration file(s)
  -h, --help                help for new

Global Flags:
  -c, --config string        select config (project) file using URL format (default "file://atlas.hcl")
      --env string           set which env from the config file to use
      --var <name>=<value>   input variables (default [])
"""

MIGRATE_HASH_HELP = """'atlas migrate hash' computes the integrity hash sum of the migration directory and stores it in the atlas.sum file.
This command should be used whenever a manual change in the migration directory was made.

Usage:
  atlas migrate hash [flags]

Examples:
  atlas migrate hash

Flags:
      --dir string          select migration directory using URL format (default "file://migrations")
      --dir-format string   select migration file format (default "atlas")
  -h, --help                help for hash

Global Flags:
  -c, --config string        select config (project) file using URL format (default "file://atlas.hcl")
      --env string           set which env from the config file to use
      --var <name>=<value>   input variables (default [])
"""

MIGRATE_VALIDATE_HELP = """'atlas migrate validate' computes the integrity hash sum of the migration directory and compares it to the
atlas.sum file. If there is a mismatch it will be reported. If the --dev-url flag is given, the migration
files are executed on the connected database in order to validate SQL semantics.

Usage:
  atlas migrate validate [flags]

Examples:
  atlas migrate validate
  atlas migrate validate --dir "file:///path/to/migration/directory"
  atlas migrate validate --dir "file:///path/to/migration/directory" --dev-url "docker://mysql/8/dev"
  atlas migrate validate --env dev --dev-url "docker://postgres/15/dev?search_path=public"

Flags:
      --dev-url string      [driver://username:password@address/dbname?param=value] select a dev database using the URL format
      --dir string          select migration directory using URL format (default "file://migrations")
      --dir-format string   select migration file format (default "atlas")
  -h, --help                help for validate

Global Flags:
  -c, --config string        select config (project) file using URL format (default "file://atlas.hcl")
      --env string           set which env from the config file to use
      --var <name>=<value>   input variables (default [])
"""


def eprint(s):
    print(s, file=sys.stderr)


def fail(msg, extra_install=False):
    eprint("Error: " + msg)
    if extra_install:
        eprint("You're running the community build of Atlas, which may differ from the official version.")
        eprint("If this error persists, try installing the official version as a troubleshooting step:\n")
        eprint("  curl -sSf https://atlasgo.sh | sh\n")
        eprint("More installation options: https://atlasgo.io/docs#installation")
    return 1


def strip_globals(args):
    out = []
    skip_next = False
    takes = {"-c", "--config", "--env", "--var", "--url", "-u", "--dev-url",
             "--format", "--dir", "--dir-format", "--to", "--from", "-f",
             "--schema", "-s", "--exclude", "--include"}
    for a in args:
        if skip_next:
            skip_next = False
            continue
        if a in takes:
            skip_next = True
            continue
        if any(a.startswith(x + "=") for x in takes):
            continue
        if a in ("--edit", "--dry-run", "--auto-approve", "--allow-dirty"):
            continue
        out.append(a)
    return out


def tokenize_hcl(s):
    toks, i, n = [], 0, len(s)
    while i < n:
        c = s[i]
        if c.isspace():
            if c == "\n":
                toks.append(("nl", "\n"))
            i += 1
            continue
        if c == "#":
            j = s.find("\n", i)
            if j == -1:
                j = n
            toks.append(("comment", s[i:j].rstrip()))
            i = j
            continue
        if c == "/" and i + 1 < n and s[i + 1] == "/":
            j = s.find("\n", i)
            if j == -1:
                j = n
            toks.append(("comment", s[i:j].rstrip()))
            i = j
            continue
        if c == '"':
            j, esc = i + 1, False
            while j < n:
                if esc:
                    esc = False
                elif s[j] == "\\":
                    esc = True
                elif s[j] == '"':
                    j += 1
                    break
                j += 1
            toks.append(("word", s[i:j]))
            i = j
            continue
        if c in "{}[]=(),":
            toks.append((c, c))
            i += 1
            continue
        j = i
        while j < n and (not s[j].isspace()) and s[j] not in "{}[]=(),#":
            if s[j:j + 2] == "//":
                break
            j += 1
        toks.append(("word", s[i:j]))
        i = j
    return toks


def format_line_tokens(tokens):
    out = ""
    prev = None
    for typ, val in tokens:
        if typ == "comment":
            if out:
                out += " "
            out += val
            prev = typ
            continue
        if val in (",", ")", "]"):
            out = out.rstrip() + val
        elif val in ("(", "["):
            if val == "[" and prev == "=":
                out += " " + val
            else:
                out = out.rstrip() + val
        elif val == "=":
            out = out.rstrip() + " ="
        elif val == "{":
            out = out.rstrip() + " {"
        else:
            if out and not out.endswith((" ", "(", "[")):
                out += " "
            out += val
        prev = val
    return out.rstrip()


def format_hcl_text(s):
    toks = tokenize_hcl(s)
    original_lines = s.count("\n")
    nonnl = [t for t in toks if t[0] != "nl"]
    if original_lines <= 1:
        return format_line_tokens(nonnl).strip() + ("\n" if s.endswith("\n") else "\n")
    lines, cur, indent = [], [], 0
    blank = False
    for typ, val in toks:
        if typ == "nl":
            if cur:
                lines.append("  " * indent + format_line_tokens(cur))
                cur = []
                blank = False
            elif indent == 0 and not blank and lines:
                lines.append("")
                blank = True
            continue
        if val == "}":
            if cur:
                lines.append("  " * indent + format_line_tokens(cur))
                cur = []
            indent = max(0, indent - 1)
            cur.append((typ, val))
            continue
        cur.append((typ, val))
        if val == "{":
            lines.append("  " * indent + format_line_tokens(cur))
            cur = []
            indent += 1
            blank = False
        elif val == "}":
            lines.append("  " * indent + format_line_tokens(cur))
            cur = []
            blank = False
    if cur:
        lines.append("  " * indent + format_line_tokens(cur))
    while lines and lines[-1] == "":
        lines.pop()
    return "\n".join(lines) + "\n"


def hcl_files(paths):
    if not paths:
        paths = ["."]
    found = []
    for p in paths:
        if not os.path.exists(p):
            raise FileNotFoundError(p)
        if os.path.isdir(p):
            for root, dirs, files in os.walk(p):
                dirs.sort()
                for f in sorted(files):
                    if f.endswith(".hcl"):
                        found.append(os.path.join(root, f))
        elif p.endswith(".hcl"):
            found.append(p)
    return found


def cmd_fmt(args):
    if "--help" in args or "-h" in args:
        print(FMT_HELP, end="")
        return 0
    if any(a.startswith("-") for a in args):
        return fail("unknown flag: " + next(a for a in args if a.startswith("-")))
    try:
        files = hcl_files(args)
    except FileNotFoundError as ex:
        return fail(f"stat {ex.args[0]}: no such file or directory", True)
    for path in files:
        with open(path, "r", encoding="utf-8") as f:
            old = f.read()
        new = format_hcl_text(old)
        if new != old:
            with open(path, "w", encoding="utf-8") as f:
                f.write(new)
            print(path)
    return 0


def parse_dir(args):
    d = "file://migrations"
    i = 0
    rest = []
    while i < len(args):
        a = args[i]
        if a == "--dir" and i + 1 < len(args):
            d = args[i + 1]
            i += 2
            continue
        if a.startswith("--dir="):
            d = a.split("=", 1)[1]
            i += 1
            continue
        if a in ("--dir-format", "--dev-url", "-c", "--config", "--env", "--var"):
            i += 2
            continue
        if any(a.startswith(x + "=") for x in ("--dir-format", "--dev-url", "--config", "--env", "--var")):
            i += 1
            continue
        if a == "--edit":
            i += 1
            continue
        rest.append(a)
        i += 1
    if not d.startswith("file://"):
        raise ValueError(f'missing scheme for dir url. Did you mean "file://{d}"? ')
    return d[7:] or ".", rest


def file_hash(path, name):
    with open(path, "rb") as f:
        data = f.read()
    h = hashlib.sha256(name.encode() + data).digest()
    return "h1:" + base64.b64encode(h).decode()


def migration_entries(d):
    if not os.path.isdir(d):
        return []
    names = [n for n in os.listdir(d) if n.endswith(".sql") and n != "atlas.sum"]
    out = []
    for name in sorted(names):
        out.append((name, file_hash(os.path.join(d, name), name)))
    return out


def write_sum(d):
    os.makedirs(d, exist_ok=True)
    entries = migration_entries(d)
    body = "".join(f"{n} {h}\n" for n, h in entries)
    root = "h1:" + base64.b64encode(hashlib.sha256(body.encode()).digest()).decode()
    with open(os.path.join(d, "atlas.sum"), "w", encoding="utf-8") as f:
        f.write(root + "\n")
        f.write(body)


def cmd_migrate_new(args):
    if "--help" in args or "-h" in args:
        print(MIGRATE_NEW_HELP, end="")
        return 0
    try:
        d, rest = parse_dir(args)
    except ValueError as ex:
        return fail(str(ex))
    if len(rest) > 1:
        return fail(f"accepts at most 1 arg(s), received {len(rest)}")
    name = rest[0] if rest else ""
    ts = datetime.utcnow().strftime("%Y%m%d%H%M%S")
    fname = ts + (("_" + name) if name else "") + ".sql"
    path = os.path.join(d, fname)
    try:
        os.makedirs(d, exist_ok=True)
        with open(path, "x", encoding="utf-8"):
            pass
    except OSError as ex:
        return fail(str(ex))
    write_sum(d)
    return 0


def cmd_migrate_hash(args):
    if "--help" in args or "-h" in args:
        print(MIGRATE_HASH_HELP, end="")
        return 0
    try:
        d, _ = parse_dir(args)
    except ValueError as ex:
        return fail(str(ex))
    write_sum(d)
    return 0


def read_sum(path):
    vals = {}
    if not os.path.exists(path):
        return vals
    with open(path, "r", encoding="utf-8") as f:
        for idx, line in enumerate(f, 1):
            parts = line.strip().split()
            if idx > 1 and len(parts) == 2:
                vals[parts[0]] = (idx, parts[1])
    return vals


def cmd_migrate_validate(args):
    if "--help" in args or "-h" in args:
        print(MIGRATE_VALIDATE_HELP, end="")
        return 0
    try:
        d, _ = parse_dir(args)
    except ValueError as ex:
        return fail(str(ex))
    old = read_sum(os.path.join(d, "atlas.sum"))
    cur = dict(migration_entries(d))
    problems = []
    for name, (line, h) in old.items():
        if name not in cur:
            problems.append(f"\tL{line}: {name} was removed")
        elif cur[name] != h:
            problems.append(f"\tL{line}: {name} was edited")
    for name in sorted(set(cur) - set(old)):
        problems.append(f"\t?: {name} was added")
    if problems:
        print("You have a checksum error in your migration directory.\n")
        print("\n".join(problems))
        print("\nPlease check your migration files and run 'atlas migrate hash' to re-hash the contents\n")
        sys.stdout.flush()
        eprint("Error: checksum mismatch")
        return 1
    return 0


def command_has_flag(args, *names):
    return any(a in names or any(a.startswith(n + "=") for n in names if n.startswith("--")) for a in args)


def schema(args):
    if not args or args[0] in ("--help", "-h") or args[0] not in ("fmt", "inspect", "diff", "apply", "clean"):
        print(SCHEMA_HELP, end="")
        return 0
    sub, rest = args[0], args[1:]
    if sub == "fmt":
        return cmd_fmt(rest)
    if "--help" in rest or "-h" in rest:
        if sub == "inspect":
            print(INSPECT_HELP, end="")
        else:
            print(f"Usage:\n  atlas schema {sub} [flags]\n")
        return 0
    if sub in ("inspect", "apply", "clean") and not command_has_flag(rest, "--url", "-u"):
        return fail('required flag(s) "url" not set')
    if sub == "diff" and (not command_has_flag(rest, "--from", "-f") or not command_has_flag(rest, "--to")):
        return fail('required flag(s) "from", "to" not set')
    return fail("database drivers are not available in this reimplementation")


def migrate(args):
    if not args or args[0] in ("--help", "-h") or args[0] not in ("new", "hash", "validate", "apply", "diff", "lint", "status", "import", "set"):
        print(MIGRATE_HELP, end="")
        return 0
    sub, rest = args[0], args[1:]
    if sub == "new":
        return cmd_migrate_new(rest)
    if sub == "hash":
        return cmd_migrate_hash(rest)
    if sub == "validate":
        return cmd_migrate_validate(rest)
    if "--help" in rest or "-h" in rest:
        print(f"Usage:\n  atlas migrate {sub} [flags]\n")
        return 0
    if sub in ("apply", "status") and not command_has_flag(rest, "--url", "-u"):
        return fail('required flag(s) "url" not set')
    return fail("database drivers are not available in this reimplementation")


def completion(args):
    if not args or args[0] in ("--help", "-h"):
        print("""Generate the autocompletion script for atlas for the specified shell.
See each sub-command's help for details on how to use the generated script.

Usage:
  atlas completion [command]

Available Commands:
  bash        Generate the autocompletion script for bash
  fish        Generate the autocompletion script for fish
  powershell  Generate the autocompletion script for powershell
  zsh         Generate the autocompletion script for zsh

Flags:
  -h, --help   help for completion

Use "atlas completion [command] --help" for more information about a command.""")
        return 0
    print(f"# atlas completion for {args[0]}")
    return 0


def main(argv):
    if not argv or argv[0] in ("--help", "-h"):
        print(ROOT_HELP, end="")
        return 0
    cmd, args = argv[0], argv[1:]
    if cmd == "version":
        if "--help" in args or "-h" in args:
            print("""Prints this Atlas CLI version information.

Usage:
  atlas version [flags]

Flags:
  -h, --help   help for version""")
            return 0
        print("atlas unofficial version - development")
        print("https://github.com/ariga/atlas/releases/latest")
        print("To download an official version, visit: https://atlasgo.io/getting-started#installation")
        return 0
    if cmd == "license":
        if "--help" in args or "-h" in args:
            print("""Display license information

Usage:
  atlas license [flags]

Flags:
  -h, --help   help for license""")
            return 0
        print("LICENSE")
        print("Atlas is licensed under Apache 2.0 as found in https://github.com/ariga/atlas/blob/master/LICENSE.")
        return 0
    if cmd == "schema":
        return schema(args)
    if cmd == "migrate":
        return migrate(args)
    if cmd == "completion":
        return completion(args)
    if cmd == "help":
        if args and args[0] == "schema":
            return schema(["--help"])
        if args and args[0] == "migrate":
            return migrate(["--help"])
        print("""Help provides help for any command in the application.
Simply type atlas help [path to command] for full details.

Usage:
  atlas help [command] [flags]

Flags:
  -h, --help   help for help""")
        return 0
    eprint(f'Error: unknown command "{cmd}" for "atlas"')
    eprint("Run 'atlas --help' for usage.")
    return 1


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
