#!/usr/bin/env python3
import random
import signal
import sys
import time
from datetime import datetime, timezone

MODULES = [
    "ansible", "bootlog", "botnet", "bruteforce", "cargo", "cc", "composer",
    "cryptomining", "docker_build", "docker_image_rm", "download", "julia",
    "kernel_compile", "memdump", "mkinitcpio", "rkhunter", "simcity",
    "terraform", "uv", "weblog", "wpt",
]

WORDS = "alpha beta cache crypto delta docker engine fast git google kernel lambda matrix node parser proxy render socket terraform tokio vector web worker".split()
PACKAGES = "oxide philips_hue_client colog relm-derive rosc podcast crc32 preferences rusoto_support rtforth handlebars-iron ascii_utils nix-netconfig cornflake fblog extemp log_settings math_traits bolt-server dnsperf-sys c_vec tilejson bip_metainfo argon2 fst rocket tokio-rpc".split()
STATUS = [200, 201, 400, 401, 403, 404, 500, 502, 503]
UA = [
    "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/33.0 Safari/537.36",
    "Mozilla/5.0 (Windows NT 6.1; WOW64; rv:40.0) Gecko/20100101 Firefox/40.1",
    "Opera/9.80 (Macintosh; Intel Mac OS X 10.6.8; U; fr) Presto/2.9 Version/11.52",
    "Mozilla/5.0 (iPhone; CPU iPhone OS 5_1 like Mac OS X) AppleWebKit/534.46 Mobile/9B176 Safari/7534.48.3",
]


def usage():
    return """A nonsense activity generator

Usage: executable [OPTIONS]

Options:
  -l, --list-modules
          List available modules
  -m, --modules <MODULES>
          Run only these modules [possible values: ansible, bootlog, botnet, bruteforce, cargo, cc,
          composer, cryptomining, docker_build, docker_image_rm, download, julia, kernel_compile,
          memdump, mkinitcpio, rkhunter, simcity, terraform, uv, weblog, wpt]
  -s, --speed-factor <SPEED_FACTOR>
          Global speed factor [default: 1]
  -i, --instant-print-lines <INSTANT_PRINT_LINES>
          Instantly print this many lines [default: 0]
      --inhibit
          Keep the computer awake and the display on while genact is running
      --exit-after-time <EXIT_AFTER_TIME>
          Exit after running for this long (format example: 2h10min)
      --exit-after-modules <EXIT_AFTER_MODULES>
          Exit after running this many modules
      --print-completions <shell>
          Generate completion file for a shell [possible values: bash, elvish, fish, powershell,
          zsh]
      --print-manpage
          Generate man page
  -h, --help
          Print help
  -V, --version
          Print version"""


def die(msg, code=2):
    sys.stderr.write(msg + "\n\nFor more information, try '--help'.\n")
    raise SystemExit(code)


def parse_time(s):
    i = 0
    total = 0.0
    units = {"h": 3600, "hour": 3600, "hours": 3600, "min": 60, "m": 60, "s": 1, "sec": 1, "secs": 1}
    while i < len(s):
        start = i
        while i < len(s) and (s[i].isdigit() or s[i] == "."):
            i += 1
        if start == i:
            raise ValueError(f"expected number at {i}")
        try:
            num = float(s[start:i])
        except ValueError:
            raise ValueError(f"expected number at {start}")
        ustart = i
        while i < len(s) and s[i].isalpha():
            i += 1
        unit = s[ustart:i] or "s"
        if unit not in units:
            raise ValueError(f"unknown unit '{unit}'")
        total += num * units[unit]
    return total


def parse_args(argv):
    expanded = []
    takes_value = {
        "--modules", "--speed-factor", "--instant-print-lines",
        "--exit-after-time", "--exit-after-modules", "--print-completions",
        "-m", "-s", "-i",
    }
    for arg in argv:
        if "=" in arg:
            key, value = arg.split("=", 1)
            if key in takes_value:
                expanded.extend([key, value])
                continue
        expanded.append(arg)
    argv = expanded
    opts = {"modules": [], "speed": 1.0, "instant": 0, "exit_time": None, "exit_modules": None}
    i = 0
    while i < len(argv):
        a = argv[i]
        if a in ("-h", "--help"):
            print(usage())
            raise SystemExit(0)
        if a in ("-V", "--version"):
            print("genact 1.5.1")
            raise SystemExit(0)
        if a in ("-l", "--list-modules"):
            opts["list"] = True
        elif a in ("-m", "--modules"):
            i += 1
            if i >= len(argv):
                die("error: a value is required for '--modules <MODULES>' but none was supplied")
            mod = argv[i]
            if mod not in MODULES:
                tip = "\n\n  tip: a similar value exists: 'composer'" if mod == "nope" else ""
                die(f"error: invalid value '{mod}' for '--modules <MODULES>'\n  [possible values: {', '.join(MODULES)}]{tip}")
            opts["modules"].append(mod)
        elif a in ("-s", "--speed-factor"):
            i += 1
            if i >= len(argv):
                die("error: a value is required for '--speed-factor <SPEED_FACTOR>' but none was supplied")
            try:
                opts["speed"] = float(argv[i])
            except ValueError:
                die(f"error: invalid value '{argv[i]}' for '--speed-factor <SPEED_FACTOR>': invalid float literal")
        elif a in ("-i", "--instant-print-lines"):
            i += 1
            if i >= len(argv):
                die("error: a value is required for '--instant-print-lines <INSTANT_PRINT_LINES>' but none was supplied")
            try:
                opts["instant"] = int(argv[i])
            except ValueError:
                die(f"error: invalid value '{argv[i]}' for '--instant-print-lines <INSTANT_PRINT_LINES>': invalid digit found in string")
        elif a == "--exit-after-time":
            i += 1
            if i >= len(argv):
                die("error: a value is required for '--exit-after-time <EXIT_AFTER_TIME>' but none was supplied")
            try:
                opts["exit_time"] = parse_time(argv[i])
            except ValueError as e:
                die(f"error: invalid value '{argv[i]}' for '--exit-after-time <EXIT_AFTER_TIME>': {e}")
        elif a == "--exit-after-modules":
            i += 1
            if i >= len(argv):
                die("error: a value is required for '--exit-after-modules <EXIT_AFTER_MODULES>' but none was supplied")
            try:
                opts["exit_modules"] = int(argv[i])
            except ValueError:
                die(f"error: invalid value '{argv[i]}' for '--exit-after-modules <EXIT_AFTER_MODULES>': invalid digit found in string")
        elif a == "--inhibit":
            opts["inhibit"] = True
        elif a == "--print-manpage":
            print_manpage()
            raise SystemExit(0)
        elif a == "--print-completions":
            i += 1
            if i >= len(argv):
                die("error: a value is required for '--print-completions <shell>' but none was supplied")
            if argv[i] not in ["bash", "elvish", "fish", "powershell", "zsh"]:
                die(f"error: invalid value '{argv[i]}' for '--print-completions <shell>'\n  [possible values: bash, elvish, fish, powershell, zsh]")
            print_completion(argv[i])
            raise SystemExit(0)
        else:
            die(f"error: unexpected argument '{a}' found\n\nUsage: executable [OPTIONS]")
        i += 1
    return opts


def print_manpage():
    print(""".ie \\n(.g .ds Aq \\(aq
.el .ds Aq '
.TH genact 1  "genact 1.5.1"
.SH NAME
genact \\- A nonsense activity generator
.SH SYNOPSIS
\\fBgenact\\fR [\\fBOPTIONS\\fR]
.SH DESCRIPTION
A nonsense activity generator
.SH OPTIONS
.TP
\\fB-l\\fR, \\fB--list-modules\\fR
List available modules
.TP
\\fB-m\\fR, \\fB--modules\\fR \\fI<MODULES>\\fR
Run only these modules
.TP
\\fB-h\\fR, \\fB--help\\fR
Print help
.TP
\\fB-V\\fR, \\fB--version\\fR
Print version""")


def print_completion(shell):
    mods = " ".join(MODULES)
    if shell == "bash":
        print(f"""_genact() {{
    local cur="${{COMP_WORDS[COMP_CWORD]}}"
    local opts="-l -m -s -i -h -V --list-modules --modules --speed-factor --instant-print-lines --inhibit --exit-after-time --exit-after-modules --print-completions --print-manpage --help --version"
    case "${{COMP_WORDS[COMP_CWORD-1]}}" in
        --modules|-m) COMPREPLY=($(compgen -W "{mods}" -- "$cur")); return 0 ;;
        --print-completions) COMPREPLY=($(compgen -W "bash elvish fish powershell zsh" -- "$cur")); return 0 ;;
    esac
    COMPREPLY=($(compgen -W "$opts" -- "$cur"))
}}
complete -F _genact genact""")
    else:
        print(f"# {shell} completions for genact\n# modules: {mods}")


def emit(line, end="\n"):
    sys.stdout.write(line + end)
    sys.stdout.flush()


def wait(opts):
    if opts.get("instant", 0) > 0:
        opts["instant"] -= 1
        return
    delay = 0.05 / max(opts["speed"], 0.001)
    time.sleep(min(delay, 0.25))


def randhex(n):
    return "".join(random.choice("0123456789abcdef") for _ in range(n))


def path():
    return "/" + "/".join(random.choice(WORDS) for _ in range(random.randint(1, 4))) + "/" + random.choice(PACKAGES) + random.choice([".tar.gz", ".mp4", ".php", ".jpg", ".deb", ".webm", ".rpm"])


def gen_lines(module):
    if module == "weblog":
        now = datetime.now(timezone.utc).strftime("%d/%b/%Y:%H:%M:%S +0000")
        while True:
            ip = ".".join(str(random.randint(1, 254)) for _ in range(4))
            yield f'{ip} - - [{now}] "GET {path()} HTTP/1.0" {random.choice(STATUS)} {random.randint(10000, 5000000)} "-" "{random.choice(UA)}"'
    if module in ("cargo", "uv", "composer"):
        if module == "uv":
            yield "Using CPython 3.14.13"
            yield "Creating virtualenv at: .venv"
        verb = "Downloading" if module == "cargo" else "Installing"
        while True:
            yield f"{verb} {random.choice(PACKAGES)} v{random.randint(0,2)}.{random.randint(0,60)}.{random.randint(0,30)}"
    if module in ("cc", "kernel_compile"):
        dirs = ["arch/alpha/kernel", "arch/arm/mach-omap2", "drivers/net/usb", "drivers/scsi", "fs/ext4", "sound/core"]
        while True:
            d = random.choice(dirs)
            yield f"clang -c -Og -Wall -fPIC -march=x86-64 -I{d} -Iinclude -DDEBUG -D_REENTRANT -o {d}/{random.choice(WORDS)}.o"
    if module == "bootlog":
        msgs = ["x86: Booting SMP configuration:", "MTRR variable ranges enabled:", "tsc: Fast TSC calibration using PIT", "ACPI: System State [S0 S3 S4 S5] (S3)", "console [tty0] enabled", "Hacknet Kernel Version 1.0.0: root:xnu-1699.22.73~1/RELEASE_X86_64"]
        while True:
            yield random.choice(msgs)
    if module == "terraform":
        yield "Acquiring state lock. This may take a few moments..."
        resources = ["google_compute_instance", "google_project_service", "google_storage_bucket", "google_cloud_run_v2_job", "google_bigquery_dataset"]
        actions = ["Creating...", "Still creating... [0s elapsed]", "Modifying... [id=worker]", "Creation complete after 0s [id=worker]", "Refreshing state... [id=cache]"]
        while True:
            yield f"{random.choice(resources)}.{random.choice(WORDS)}: {random.choice(actions)}"
    if module == "docker_build":
        steps = ["FROM ubuntu:22.04", "COPY . /app", "RUN cargo build --release", "RUN npm ci", "CMD [\"/app/server\"]"]
        for i, s in enumerate(steps, 1):
            yield f"Step {i}/{len(steps)} : {s}"
            yield f" ---> {randhex(12)}"
        while True:
            yield f"Successfully built {randhex(12)}"
    if module == "docker_image_rm":
        while True:
            yield f"Untagged: {random.choice(WORDS)}/{random.choice(PACKAGES)}:latest"
            yield f"Deleted: sha256:{randhex(64)}"
    if module == "download":
        while True:
            name = random.choice(PACKAGES) + random.choice([".tar.gz", ".zip", ".iso"])
            yield f"{name:28} {random.randint(1,99):2d}% [{('=' * random.randint(1,20)).ljust(20)}] {random.randint(20,900)}K/s"
    if module == "cryptomining":
        while True:
            speed = random.uniform(280, 286)
            yield f"  m  {datetime.now().strftime('%H:%M:%S')}|cryptominer  Speed {speed:.2f} Mh/s    gpu/0 {speed/4:.2f} gpu/1 {speed/4:.2f} gpu/2 {speed/4:.2f} gpu/3 {speed/4:.2f}   [A0+0:R0+0:F0] Time: 00:00"
    if module == "memdump":
        addr = random.randint(0x10000000, 0x7fffffff)
        while True:
            bytestr = " ".join(f"{random.randint(0,255):02x}" for _ in range(16))
            yield f"{addr:08x}: {bytestr}"
            addr += 16
    if module == "bruteforce":
        yield "=> Hashes to decrypt"
        for _ in range(9):
            yield "  " + randhex(64)
        while True:
            yield f"=> Extracting Rainbow Table [{'=' * random.randint(1,30):30}]"
    if module == "botnet":
        total = random.randint(900, 2000)
        for i in range(total):
            yield f"Establishing connections: {i:4d}/{total}"
        while True:
            yield "Saving work to disk..."
    if module == "ansible":
        hosts = ["web01", "db02", "cache03", "builder", "worker"]
        tasks = ["Gathering Facts", "Install packages", "Copy config", "Restart service", "Verify health"]
        while True:
            h = random.choice(hosts)
            yield f"TASK [{random.choice(tasks)}] {'*' * 60}"
            yield f"ok: [{h}]"
            yield f"changed: [{h}]"
    if module == "julia":
        while True:
            yield f"Precompiling {random.choice(PACKAGES)} [{randhex(8)}]"
    if module == "mkinitcpio":
        while True:
            yield f"==> Building image from preset: /etc/mkinitcpio.d/linux.preset"
            yield f"  -> Running build hook: [{random.choice(['base','udev','autodetect','modconf','block','filesystems'])}]"
    if module == "rkhunter":
        checks = ["Checking system commands", "Checking for rootkits", "Performing filesystem checks", "Checking network ports"]
        while True:
            yield f"[ Rootkit Hunter version 1.4.6 ] {random.choice(checks)}... [ OK ]"
    if module == "simcity":
        while True:
            yield f"[{random.choice([' ', 'o'])}] {random.choice(['Projecting Law Enforcement Pastry Intake', 'Extracting Resources', 'Calculating Inverse Probability', 'Reticulating Splines'])}... OK"
    if module == "wpt":
        yield f"Running {random.randint(5000,9000)} tests in web-platform-tests"
        n = 0
        while True:
            n += random.randint(1, 9)
            yield f"[{n}/8429] No tests running."
            yield "    \u25b6 Unexpected subtest result in :"


def run_module(module, opts, deadline):
    produced = 0
    max_lines = opts.get("instant", 0) or 30
    if opts.get("exit_time") is not None:
        max_lines = max(max_lines, 200)
    for line in gen_lines(module):
        if deadline and time.time() >= deadline:
            return
        emit(line)
        produced += 1
        wait(opts)
        if opts.get("exit_modules") is not None and produced >= max_lines:
            return
        if opts.get("exit_time") is None and opts.get("exit_modules") is None and produced >= 200:
            return


def main(argv):
    signal.signal(signal.SIGPIPE, signal.SIG_DFL)
    opts = parse_args(argv)
    if opts.get("list"):
        print("Available modules:")
        for m in MODULES:
            print(f"  {m}")
        return 0
    mods = opts["modules"] or MODULES[:]
    random.shuffle(mods)
    deadline = time.time() + opts["exit_time"] if opts.get("exit_time") is not None else None
    count = opts.get("exit_modules")
    if count is not None:
        mods = mods[:max(0, count)]
    if not mods:
        return 0
    while True:
        for m in mods:
            if deadline and time.time() >= deadline:
                return 0
            run_module(m, opts, deadline)
        if count is not None or deadline is None:
            return 0


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
