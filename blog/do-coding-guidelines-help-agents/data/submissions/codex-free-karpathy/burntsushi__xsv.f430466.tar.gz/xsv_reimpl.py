#!/usr/bin/env python3
import sys, os, re, math, random
from collections import Counter, defaultdict

VERSION='0.13.0'
COMMANDS=[('cat','Concatenate by row or column'),('count','Count records'),('fixlengths','Makes all records have same length'),('flatten','Show one field per line'),('fmt','Format CSV output (change field delimiter)'),('frequency','Show frequency tables'),('headers','Show header names'),('help','Show this usage message.'),('index','Create CSV index for faster access'),('input','Read CSV data with special quoting rules'),('join','Join CSV files'),('partition','Partition CSV data based on a column value'),('sample','Randomly sample CSV data'),('reverse','Reverse rows of CSV data'),('search','Search CSV data with regexes'),('select','Select columns from CSV'),('slice','Slice records from CSV'),('sort','Sort CSV data'),('split','Split CSV data into many files'),('stats','Compute basic statistics'),('table','Align CSV data into columns')]

HELP_MAIN="""Usage:
    xsv <command> [<args>...]
    xsv [options]

Options:
    --list        List all commands available.
    -h, --help    Display this message
    <command> -h  Display the command help message
    --version     Print version info and exit

Commands:
""" + ''.join('    %-11s %s\n' % c for c in COMMANDS)

HELP={
'count':"""Prints a count of the number of records in the CSV data.

Usage:
    xsv count [options] [<input>]
""",
'headers':"""Prints the fields of the first row in the CSV data.

Usage:
    xsv headers [options] [<input>...]
""",
'select':"""Select columns from CSV data efficiently.

Usage:
    xsv select [options] [--] <selection> [<input>]
""",
'slice':"""Returns the rows in the range specified (starting at 0, half-open interval).

Usage:
    xsv slice [options] [<input>]
""",
}

def die(msg, code=1):
    sys.stderr.write(str(msg).rstrip()+"\n")
    sys.exit(code)

def read_text(path):
    if path is None or path == '-':
        return sys.stdin.read()
    with open(path, 'r', newline='') as f:
        return f.read()

def parse_csv_text(text, delim=',', quote='"', escape=None, quoting=True):
    rows=[]; row=[]; field=[]; i=0; n=len(text); inq=False
    while i<n:
        ch=text[i]
        if inq:
            if escape and ch==escape and i+1<n:
                field.append(text[i+1]); i+=2; continue
            if quoting and ch==quote:
                if i+1<n and text[i+1]==quote and escape is None:
                    field.append(quote); i+=2; continue
                inq=False; i+=1; continue
            field.append(ch); i+=1; continue
        else:
            if quoting and ch==quote:
                inq=True; i+=1; continue
            if ch==delim:
                row.append(''.join(field)); field=[]; i+=1; continue
            if ch=='\n' or ch=='\r':
                row.append(''.join(field)); field=[]; rows.append(row); row=[]
                if ch=='\r' and i+1<n and text[i+1]=='\n': i+=2
                else: i+=1
                continue
            field.append(ch); i+=1
    if field or row:
        row.append(''.join(field)); rows.append(row)
    return rows

def read_csv(path=None, delim=',', quote='"', escape=None, quoting=True):
    return parse_csv_text(read_text(path), delim, quote, escape, quoting)

def needs_quote(s, delim, quote):
    return s=='' and False or any(c in s for c in [delim, quote, '\n', '\r'])

def csv_line(row, delim=',', quote='"', always=False, ascii_mode=False):
    if ascii_mode:
        delim='\x1f'
    out=[]
    for v in row:
        if v is None: v=''
        v=str(v)
        if always or needs_quote(v, delim, quote):
            out.append(quote + v.replace(quote, quote+quote) + quote)
        else:
            out.append(v)
    return delim.join(out)

def write_rows(rows, output=None, delim=',', quote='"', always=False, term='\n', ascii_mode=False):
    data=''.join(csv_line(r, delim, quote, always, ascii_mode)+term for r in rows)
    if output:
        with open(output,'w',newline='') as f: f.write(data)
    else:
        sys.stdout.write(data)

def parse_opts(args, specs):
    opts={}; rest=[]; i=0
    while i<len(args):
        a=args[i]
        if a=='--': rest += args[i+1:]; break
        if a.startswith('-') and a!='-':
            name=a; val=True
            if '=' in a:
                name,val=a.split('=',1)
            key=None; takes=False
            for names, optkey, need in specs:
                if name in names: key=optkey; takes=need; break
            if key is None:
                rest.append(a); i+=1; continue
            if takes and val is True:
                i+=1
                if i>=len(args): die('error: The argument %s requires a value.'%a)
                val=args[i]
            opts[key]=val
        else:
            rest.append(a)
        i+=1
    return opts, rest

COMMON=[(('-h','--help'),'help',False),(('-n','--no-headers'),'no_headers',False),(('-d','--delimiter'),'delim',True),(('-o','--output'),'output',True)]
def delim_from(opts):
    d=opts.get('delim', ',')
    if d=='\\t': return '\t'
    if len(d)!=1: die('CSV error: delimiter must be a single character')
    return d

def split_selection(s):
    parts=[]; cur=[]; q=False; i=0
    while i<len(s):
        ch=s[i]
        if ch=='"': q=not q; i+=1; continue
        if ch==',' and not q:
            parts.append(''.join(cur)); cur=[]; i+=1; continue
        cur.append(ch); i+=1
    parts.append(''.join(cur))
    return [p.strip() for p in parts if p.strip()!='']

def col_index(tok, headers, ncols):
    tok=tok.strip()
    m=re.match(r'^(.*)\[(\d+)\]$', tok)
    occ=1
    if m:
        tok=m.group(1); occ=int(m.group(2))
    if tok=='': return None
    if tok.isdigit():
        idx=int(tok)-1
        if idx<0: die('Selector index must be >= 1')
        return idx
    if headers is None: die('Selector %r is not a valid index' % tok)
    count=0
    for i,h in enumerate(headers):
        if h==tok:
            count+=1
            if count==occ: return i
    die('Selector column %r does not exist' % tok)

def parse_selection(sel, headers, ncols):
    invert=False
    if sel.startswith('!'):
        invert=True; sel=sel[1:]
    chosen=[]
    for part in split_selection(sel):
        if '-' in part and not (part.startswith('"') and part.endswith('"')):
            a,b=part.split('-',1)
            start=0 if a=='' else col_index(a,headers,ncols)
            end=ncols-1 if b=='' else col_index(b,headers,ncols)
            step=1 if end>=start else -1
            chosen.extend(list(range(start,end+step,step)))
        else:
            chosen.append(col_index(part.strip('"'),headers,ncols))
    if invert:
        s=set(chosen); return [i for i in range(ncols) if i not in s]
    return chosen

def split_header(rows, no_headers=False):
    if not rows: return (None, [])
    if no_headers: return (None, rows)
    return (rows[0], rows[1:])

def cmd_count(args):
    opts,rest=parse_opts(args, COMMON)
    if opts.get('help'): print(HELP['count']); return
    rows=read_csv(rest[0] if rest else None, delim_from(opts))
    c=len(rows) if opts.get('no_headers') else max(0,len(rows)-1)
    print(c)

def cmd_headers(args):
    specs=COMMON+[(( '--just-names', '-j'),'just',False),(('--intersect',),'intersect',False)]
    opts,rest=parse_opts(args,specs)
    if opts.get('help'): print(HELP['headers']); return
    inputs=rest or [None]
    allh=[]
    for p in inputs:
        r=read_csv(p,delim_from(opts)); allh.append(r[0] if r else [])
    if opts.get('intersect') and allh:
        base=[]
        for h in allh[0]:
            if all(h in x for x in allh[1:]) and h not in base: base.append(h)
        headers=base
    else:
        headers=allh[0] if allh else []
    just=opts.get('just') or len(inputs)>1
    for i,h in enumerate(headers,1):
        print(h if just else ('%-3d %s' % (i,h)))

def cmd_select(args):
    opts,rest=parse_opts(args,COMMON)
    if opts.get('help') or not rest: print(HELP['select']); return
    sel=rest[0]; path=rest[1] if len(rest)>1 else None
    rows=read_csv(path,delim_from(opts)); hdr,data=split_header(rows,opts.get('no_headers'))
    n=max([len(r) for r in rows], default=0)
    idx=parse_selection(sel,hdr,n)
    out=[]
    if hdr is not None: out.append([(hdr[i] if i<len(hdr) else '') for i in idx])
    for r in data: out.append([(r[i] if i<len(r) else '') for i in idx])
    write_rows(out,opts.get('output'))

def cmd_slice(args):
    specs=COMMON+[(( '-s','--start'),'start',True),(('-e','--end'),'end',True),(('-l','--len'),'len',True),(('-i','--index'),'index',True)]
    opts,rest=parse_opts(args,specs)
    if opts.get('help'): print(HELP['slice']); return
    rows=read_csv(rest[0] if rest else None,delim_from(opts)); hdr,data=split_header(rows,opts.get('no_headers'))
    if 'index' in opts: start=int(opts['index']); end=start+1
    else:
        start=int(opts.get('start',0)); end=int(opts['end']) if 'end' in opts else None
        if 'len' in opts: end=start+int(opts['len'])
    out=[]
    if hdr is not None: out.append(hdr)
    out.extend(data[start:end])
    write_rows(out,opts.get('output'))

def cmd_reverse(args):
    opts,rest=parse_opts(args,COMMON)
    rows=read_csv(rest[0] if rest else None,delim_from(opts)); hdr,data=split_header(rows,opts.get('no_headers'))
    out=[]
    if hdr is not None: out.append(hdr)
    out.extend(reversed(data))
    write_rows(out,opts.get('output'))

def sort_key(row, idx, numeric):
    vals=[]
    for i in idx:
        v=row[i] if i<len(row) else ''
        if numeric:
            try: vals.append(float(v) if v!='' else float('-inf'))
            except: vals.append(float('-inf'))
        else: vals.append(v)
    return vals

def cmd_sort(args):
    specs=COMMON+[(( '-s','--select'),'select',True),(('-N','--numeric'),'numeric',False),(('-R','--reverse'),'reverse',False)]
    opts,rest=parse_opts(args,specs)
    rows=read_csv(rest[0] if rest else None,delim_from(opts)); hdr,data=split_header(rows,opts.get('no_headers'))
    n=max([len(r) for r in rows], default=0); idx=list(range(n))
    if opts.get('select'): idx=parse_selection(opts['select'],hdr,n)
    data=sorted(data,key=lambda r: sort_key(r,idx,opts.get('numeric')), reverse=bool(opts.get('reverse')))
    out=[]
    if hdr is not None: out.append(hdr)
    out.extend(data); write_rows(out,opts.get('output'))

def cmd_fmt(args):
    specs=COMMON+[(( '-t','--out-delimiter'),'outdelim',True),(('--crlf',),'crlf',False),(('--ascii',),'ascii',False),(('--quote',),'quote',True),(('--quote-always',),'always',False),(('--escape',),'escape',True)]
    opts,rest=parse_opts(args,specs)
    rows=read_csv(rest[0] if rest else None,delim_from(opts))
    od=opts.get('outdelim', ',')
    if od=='\\t': od='\t'
    write_rows(rows,opts.get('output'),od,opts.get('quote','"'),bool(opts.get('always')), '\r\n' if opts.get('crlf') or opts.get('ascii') else '\n', bool(opts.get('ascii')))

def cmd_input(args):
    specs=COMMON+[(( '--quote',),'quote',True),(('--escape',),'escape',True),(('--no-quoting',),'noquoting',False)]
    opts,rest=parse_opts(args,specs)
    rows=read_csv(rest[0] if rest else None,delim_from(opts),opts.get('quote','"'),opts.get('escape'),not opts.get('noquoting'))
    write_rows(rows,opts.get('output'))

def cmd_fixlengths(args):
    specs=COMMON+[(( '-l','--length'),'length',True)]
    opts,rest=parse_opts(args,specs)
    rows=read_csv(rest[0] if rest else None,delim_from(opts))
    if 'length' in opts: L=int(opts['length'])
    else:
        L=max([max(1,len(r)-sum(1 for x in reversed(r) if x=='')) for r in rows], default=0)
    out=[(r[:L]+['']*max(0,L-len(r))) for r in rows]
    write_rows(out,opts.get('output'))

def cmd_flatten(args):
    specs=COMMON+[(( '-c','--condense'),'condense',True),(('-s','--separator'),'sep',True)]
    opts,rest=parse_opts(args,specs)
    rows=read_csv(rest[0] if rest else None,delim_from(opts)); hdr,data=split_header(rows,opts.get('no_headers'))
    if hdr is None: hdr=[str(i) for i in range(0,max([len(r) for r in rows], default=0))]
    width=max(2, max([len(h) for h in hdr], default=0))
    sep=opts.get('sep','#'); cond=int(opts['condense']) if 'condense' in opts else None
    for ri,r in enumerate(data):
        for i,h in enumerate(hdr):
            v=r[i] if i<len(r) else ''
            if cond is not None and len(v)>cond: v=v[:cond] + '...'
            print(h + ' '*(width-len(h)+2) + v)
        if sep and ri != len(data)-1: print(sep)

def cmd_table(args):
    specs=COMMON+[(( '-w','--width'),'width',True),(('-p','--pad'),'pad',True),(('-c','--condense'),'condense',True)]
    opts,rest=parse_opts(args,specs); rows=read_csv(rest[0] if rest else None,delim_from(opts))
    cond=int(opts['condense']) if 'condense' in opts else None
    if cond is not None: rows=[[v[:cond] if len(v)>cond else v for v in r] for r in rows]
    n=max([len(r) for r in rows], default=0); minw=int(opts.get('width',2)); pad=int(opts.get('pad',2))
    widths=[minw]*n
    for r in rows:
        for i,v in enumerate(r): widths[i]=max(widths[i],len(v))
    lines=[]
    for r in rows:
        parts=[]
        for i in range(n):
            v=r[i] if i<len(r) else ''
            parts.append(v + (' '*(widths[i]-len(v) + (pad if i<n-1 else 0))))
        lines.append(''.join(parts).rstrip())
    out='\n'.join(lines)+('\n' if lines else '')
    if opts.get('output'): open(opts['output'],'w').write(out)
    else: sys.stdout.write(out)

def cmd_frequency(args):
    specs=COMMON+[(( '-s','--select'),'select',True),(('-l','--limit'),'limit',True),(('-a','--asc'),'asc',False),(('--no-nulls',),'nonulls',False),(('-j','--jobs'),'jobs',True)]
    opts,rest=parse_opts(args,specs); rows=read_csv(rest[0] if rest else None,delim_from(opts)); hdr,data=split_header(rows,opts.get('no_headers'))
    n=max([len(r) for r in rows], default=0); idx=parse_selection(opts['select'],hdr,n) if opts.get('select') else list(range(n))
    out=[['field','value','count']]; limit=int(opts.get('limit',10))
    for i in idx:
        name=(hdr[i] if hdr and i<len(hdr) else str(i+1)); c=Counter()
        for r in data:
            v=r[i] if i<len(r) else ''
            if v=='' and opts.get('nonulls'): continue
            c['(NULL)' if v=='' else v]+=1
        items=list(c.items())
        items.sort(key=lambda kv:(kv[1], kv[0]) if opts.get('asc') else (-kv[1], kv[0]))
        if limit: items=items[:limit]
        for v,cnt in items: out.append([name,v,str(cnt)])
    write_rows(out,opts.get('output'))

def type_and_nums(vals):
    non=[v for v in vals if v!='']
    if not non: return 'NULL', []
    ints=[]; nums=[]; allint=True; allnum=True
    for v in non:
        if re.fullmatch(r'[+-]?\d+',v): ints.append(int(v)); nums.append(float(int(v)))
        else:
            allint=False
            try: nums.append(float(v))
            except: allnum=False
    if allint: return 'Integer', nums
    if allnum: return 'Float', nums
    return 'Unicode', []

def fmt_num(x):
    if x is None: return ''
    if abs(x-round(x))<1e-12: return str(int(round(x)))
    return ('%.12g'%x)

def median(nums):
    if not nums: return None
    s=sorted(nums); n=len(s); m=n//2
    return s[m] if n%2 else (s[m-1]+s[m])/2.0

def cmd_stats(args):
    specs=COMMON+[(( '-s','--select'),'select',True),(('--everything',),'everything',False),(('--mode',),'mode',False),(('--cardinality',),'cardinality',False),(('--median',),'median',False),(('--nulls',),'nulls',False),(('-j','--jobs'),'jobs',True)]
    opts,rest=parse_opts(args,specs); rows=read_csv(rest[0] if rest else None,delim_from(opts)); hdr,data=split_header(rows,opts.get('no_headers'))
    n=max([len(r) for r in rows], default=0); idx=parse_selection(opts['select'],hdr,n) if opts.get('select') else list(range(n))
    extra=opts.get('everything'); out=[['field','type','sum','min','max','min_length','max_length','mean','stddev']]
    if extra or opts.get('median'): out[0].append('median')
    if extra or opts.get('mode'): out[0].append('mode')
    if extra or opts.get('cardinality'): out[0].append('cardinality')
    for i in idx:
        name=hdr[i] if hdr and i<len(hdr) else str(i+1)
        vals=[r[i] if i<len(r) else '' for r in data]
        typ,nums=type_and_nums(vals); non=[v for v in vals if v!='']
        lens=[len(v) for v in vals]
        row=[name,typ,'','','',str(min(lens) if lens else 0),str(max(lens) if lens else 0),'','']
        if typ in ('Integer','Float'):
            denom=len(vals) if opts.get('nulls') else len(nums)
            s=sum(nums); mn=min(nums) if nums else None; mx=max(nums) if nums else None
            mean=s/denom if denom else None
            sd=None
            if denom and mean is not None:
                sq=sum((x-mean)*(x-mean) for x in nums)
                if opts.get('nulls'): sq += (len(vals)-len(nums))*mean*mean
                sd=math.sqrt(sq/denom)
            row[2:9]=[fmt_num(s),fmt_num(mn),fmt_num(mx),row[5],row[6],fmt_num(mean),fmt_num(sd)]
        elif non:
            row[3]=min(non); row[4]=max(non)
        if extra or opts.get('median'):
            row.append(fmt_num(median(nums)) if nums else '')
        if extra or opts.get('mode'):
            c=Counter(vals); mc=max(c.values()) if c else 0; modes=sorted([k for k,v in c.items() if v==mc])
            row.append(modes[0] if len(modes)==1 else 'N/A')
        if extra or opts.get('cardinality'):
            row.append(str(len(set(vals))))
        out.append(row)
    write_rows(out,opts.get('output'))

def cmd_search(args):
    specs=COMMON+[(( '-i','--ignore-case'),'icase',False),(('-s','--select'),'select',True),(('-v','--invert-match'),'invert',False)]
    opts,rest=parse_opts(args,specs)
    if not rest: die('Usage: xsv search <regex> [<input>]')
    pat=rest[0]; rows=read_csv(rest[1] if len(rest)>1 else None,delim_from(opts)); hdr,data=split_header(rows,opts.get('no_headers'))
    n=max([len(r) for r in rows], default=0); idx=parse_selection(opts['select'],hdr,n) if opts.get('select') else list(range(n))
    flags=re.I if opts.get('icase') else 0; rx=re.compile(pat,flags); out=[]
    if hdr is not None: out.append(hdr)
    for r in data:
        m=any(rx.search(r[i] if i<len(r) else '') for i in idx)
        if m ^ bool(opts.get('invert')): out.append(r)
    write_rows(out,opts.get('output'))

def join_key(r,idx,nocase):
    vals=[]
    for i in idx:
        v=(r[i] if i<len(r) else '').strip()
        if nocase: v=v.lower()
        vals.append(v)
    return tuple(vals)

def cmd_join(args):
    specs=COMMON+[(( '--no-case',),'nocase',False),(('--left',),'left',False),(('--right',),'right',False),(('--full',),'full',False),(('--cross',),'cross',False),(('--nulls',),'nulls',False)]
    opts,rest=parse_opts(args,specs)
    if len(rest)<4: die('Usage: xsv join <columns1> <input1> <columns2> <input2>')
    c1,p1,c2,p2=rest[:4]; r1=read_csv(p1,delim_from(opts)); r2=read_csv(p2,delim_from(opts)); h1,d1=split_header(r1,opts.get('no_headers')); h2,d2=split_header(r2,opts.get('no_headers'))
    n1=max([len(r) for r in r1], default=0); n2=max([len(r) for r in r2], default=0)
    out=[]
    if h1 is not None: out.append(h1+h2)
    if opts.get('cross'):
        for a in d1:
            for b in d2: out.append(a+b)
        write_rows(out,opts.get('output')); return
    i1=parse_selection(c1,h1,n1); i2=parse_selection(c2,h2,n2); mp=defaultdict(list)
    for j,b in enumerate(d2):
        k=join_key(b,i2,opts.get('nocase'))
        if not opts.get('nulls') and any(x=='' for x in k): continue
        mp[k].append((j,b))
    matched=set()
    for a in d1:
        k=join_key(a,i1,opts.get('nocase'))
        if not opts.get('nulls') and any(x=='' for x in k): ms=[]
        else: ms=mp.get(k,[])
        if ms:
            for j,b in ms: out.append(a+b); matched.add(j)
        elif opts.get('left') or opts.get('full'):
            out.append(a+['']*n2)
    if opts.get('right') or opts.get('full'):
        for j,b in enumerate(d2):
            if j not in matched: out.append(['']*n1+b)
    write_rows(out,opts.get('output'))

def cmd_cat(args):
    specs=COMMON+[(( '-p','--pad'),'pad',False)]
    opts,rest=parse_opts(args,specs)
    if not rest: die('Usage: xsv cat rows|columns [<input>...]')
    mode=rest[0]; inputs=rest[1:] or [None]
    datasets=[read_csv(p,delim_from(opts)) for p in inputs]
    out=[]
    if mode=='rows':
        expected=None
        for di,rows in enumerate(datasets):
            use = rows if (di==0 or opts.get('no_headers')) else rows[1:]
            for r in use:
                if expected is None:
                    expected=len(r)
                elif len(r)!=expected:
                    write_rows(out,opts.get('output'))
                    die('CSV error: found record with %d fields, but the previous record has %d fields' % (len(r), expected))
                out.append(r)
    elif mode=='columns':
        maxlen=(max if opts.get('pad') else min)([len(x) for x in datasets]) if datasets else 0
        widths=[max([len(r) for r in ds], default=0) for ds in datasets]
        for i in range(maxlen):
            row=[]
            for ds,w in zip(datasets,widths): row.extend(ds[i] if i<len(ds) else ['']*w)
            out.append(row)
    else: die('Usage: xsv cat rows|columns [<input>...]')
    write_rows(out,opts.get('output'))

def sanitize(s):
    s=s[:255]
    return re.sub(r'[^A-Za-z0-9._-]+','_',s).strip('_') or '_'

def cmd_split(args):
    specs=COMMON+[(( '-s','--size'),'size',True),(('-j','--jobs'),'jobs',True),(('--filename',),'filename',True)]
    opts,rest=parse_opts(args,specs)
    if not rest: die('Usage: xsv split <outdir> [<input>]')
    outdir=rest[0]; rows=read_csv(rest[1] if len(rest)>1 else None,delim_from(opts)); hdr,data=split_header(rows,opts.get('no_headers')); os.makedirs(outdir,exist_ok=True)
    size=int(opts.get('size',500)); tmpl=opts.get('filename','{}.csv')
    for start in range(0,len(data),size):
        chunk=[]
        if hdr is not None: chunk.append(hdr)
        chunk.extend(data[start:start+size]); write_rows(chunk,os.path.join(outdir,tmpl.replace('{}',str(start))))

def cmd_partition(args):
    specs=COMMON+[(( '--filename',),'filename',True),(('-p','--prefix-length'),'prefix',True),(('--drop',),'drop',False)]
    opts,rest=parse_opts(args,specs)
    if len(rest)<2: die('Usage: xsv partition <column> <outdir> [<input>]')
    col,outdir=rest[0],rest[1]; rows=read_csv(rest[2] if len(rest)>2 else None,delim_from(opts)); hdr,data=split_header(rows,opts.get('no_headers')); n=max([len(r) for r in rows], default=0); idx=parse_selection(col,hdr,n)[0]
    os.makedirs(outdir,exist_ok=True); tmpl=opts.get('filename','{}.csv'); buckets={}
    for r in data:
        val=r[idx] if idx<len(r) else ''
        if 'prefix' in opts: val=val[:int(opts['prefix'])]
        fn=os.path.join(outdir,tmpl.replace('{}',sanitize(val)))
        if fn not in buckets:
            buckets[fn]=[]
            if hdr is not None: buckets[fn].append([v for j,v in enumerate(hdr) if not(opts.get('drop') and j==idx)])
        buckets[fn].append([v for j,v in enumerate(r) if not(opts.get('drop') and j==idx)])
    for fn,rs in buckets.items(): write_rows(rs,fn)

def cmd_sample(args):
    specs=COMMON+[(( '--seed',),'seed',True)]
    opts,rest=parse_opts(args,specs)
    if not rest: die('Usage: xsv sample <sample-size> [<input>]')
    k=int(rest[0]); rows=read_csv(rest[1] if len(rest)>1 else None,delim_from(opts)); hdr,data=split_header(rows,opts.get('no_headers'))
    rng=random.Random(int(opts['seed'])) if 'seed' in opts else random.Random()
    sample=data[:] if k>=len(data) else rng.sample(data,k)
    out=[]
    if hdr is not None: out.append(hdr)
    out.extend(sample); write_rows(out,opts.get('output'))

def cmd_index(args):
    specs=COMMON
    opts,rest=parse_opts(args,specs)
    if not rest: die('Usage: xsv index <input>')
    out=opts.get('output') or rest[0]+'.idx'
    # Minimal placeholder index; this reimplementation ignores indexes.
    open(out,'wb').write(b'XSVIDX\0')

def main():
    args=sys.argv[1:]
    if not args or args[0] in ('-h','--help','help'):
        sys.stdout.write(HELP_MAIN); return
    if args[0]=='--version': print(VERSION); return
    if args[0]=='--list':
        print('Installed commands:')
        for c,d in COMMANDS: print('    %-11s %s'%(c,d))
        return
    cmd=args[0].replace('-','_')
    fn=globals().get('cmd_'+cmd)
    if not fn:
        die('Unrecognized command: %s' % args[0])
    if len(args)>1 and args[1] in ('-h','--help'):
        print(HELP.get(args[0], "Usage:\n    xsv %s [options] [<input>]\n" % args[0])); return
    fn(args[1:])
if __name__=='__main__': main()
