#!/usr/bin/env python3
import os, sys, subprocess, tempfile
from collections import OrderedDict

VERSION = "pier 0.1.6"

TOP_HELP = """pier 0.1.6
Benjamin Scholtz, Isak Johansson
A simple script management CLI

USAGE:
    executable [FLAGS] [OPTIONS] <alias> [args]...
    executable [FLAGS] [OPTIONS] <SUBCOMMAND>

FLAGS:
    -h, --help       
            Prints help information

    -V, --version    
            Prints version information

    -v, --verbose    
            The level of verbosity


OPTIONS:
    -c, --config-file <path>    
            Sets a custom config file.
            
            DEFAULT PATH is otherwise determined in this order:
            
            - $PIER_CONFIG_PATH (environment variable if set)
            
            - pier.toml (in the current directory)
            
            - $XDG_CONFIG_HOME/pier/config.toml
            
            - $XDG_CONFIG_HOME/pier/config
            
            - $XDG_CONFIG_HOME/pier.toml
            
            - $HOME/.pier.toml
            
            - $HOME/.pier
            
             [env: PIER_CONFIG_PATH=]

ARGS:
    <alias>      
            The alias or name for the script.

    <args>...    
            The positional arguments to send to script.


SUBCOMMANDS:
    add            Add a new script to config.
    config-init    alias: init - Add a config file.
    copy           alias: cp - Copy existing alias to the new one
    edit           Edit a script matching alias.
    help           Prints this message or the help of the given subcommand(s)
    list           alias: ls - List scripts
    move           alias: mv, rename - Move/rename existing alias to the new one
    remove         alias: rm - Remove a script matching alias.
    run            Run a script matching alias.
    show           Show a script matching alias."""

HELP = {
"add": """executable-add 0.1.6
Add a new script to config.

USAGE:
    executable add [FLAGS] [OPTIONS] --alias <alias> [--] [command]

FLAGS:
    -f, --force      Allows to overwrite the existing script
    -h, --help       Prints help information
    -V, --version    Prints version information

OPTIONS:
    -a, --alias <alias>                The alias or name for the script.
    -d, --description <description>    The description for the script.
    -t, --tag <tags>...                Set which tags the script belongs to.

ARGS:
    <command>    The command/script content to be executed. If this argument is not found it will open your $EDITOR
                 for you to enter the script into.""",
"config-init": """executable-config-init 0.1.6
alias: init - Add a config file.

USAGE:
    executable config-init

FLAGS:
    -h, --help       Prints help information
    -V, --version    Prints version information""",
"copy": """executable-copy 0.1.6
alias: cp - Copy existing alias to the new one

USAGE:
    executable copy <from-alias> <to-alias>

FLAGS:
    -h, --help       Prints help information
    -V, --version    Prints version information

ARGS:
    <from-alias>    The alias of the script that will be copied.
    <to-alias>      The new alias of the copy of the script.""",
"edit": """executable-edit 0.1.6
Edit a script matching alias.

USAGE:
    executable edit <alias>

FLAGS:
    -h, --help       Prints help information
    -V, --version    Prints version information

ARGS:
    <alias>    The alias or name for the script.""",
"list": """executable-list 0.1.6
alias: ls - List scripts

Display options are determined by priority in this order:

1. List only aliases

2. Show full command

3. Command display with (cli option)

4. Command display with (config option)

USAGE:
    executable list [FLAGS] [OPTIONS]

FLAGS:
    -l, --cmd_full        
            Display the full command.

    -h, --help            
            Prints help information

    -q, --list_aliases    
            Only displays aliases of the scripts.

    -V, --version         
            Prints version information


OPTIONS:
    -c, --cmd_width <cmd-width>    
            The max number of characters to display from the command.

    -t, --tag <tags>...            
            Filter based on tags.""",
"move": """executable-move 0.1.6
alias: mv, rename - Move/rename existing alias to the new one

USAGE:
    executable move [FLAGS] <from-alias> <to-alias>

FLAGS:
    -f, --force      Allows to overwrite the existing script
    -h, --help       Prints help information
    -V, --version    Prints version information

ARGS:
    <from-alias>    The alias of the script that will be moved.
    <to-alias>      The new alias of the script.""",
"remove": """executable-remove 0.1.6
alias: rm - Remove a script matching alias.

USAGE:
    executable remove <alias>

FLAGS:
    -h, --help       Prints help information
    -V, --version    Prints version information

ARGS:
    <alias>    The alias or name for the script.""",
"run": """executable-run 0.1.6
Run a script matching alias.

USAGE:
    executable run <alias> [args]...

FLAGS:
    -h, --help       Prints help information
    -V, --version    Prints version information

ARGS:
    <alias>      The alias or name for the script.
    <args>...    The positional arguments to send to script.""",
"show": """executable-show 0.1.6
Show a script matching alias.

USAGE:
    executable show <alias>

FLAGS:
    -h, --help       Prints help information
    -V, --version    Prints version information

ARGS:
    <alias>    The alias or name for the script.""",
}
ALIASES = {"init":"config-init", "ls":"list", "cp":"copy", "mv":"move", "rename":"move", "rm":"remove"}
SUBS = set(HELP) | set(ALIASES)

class Config:
    def __init__(self):
        self.scripts = OrderedDict()
        self.default = {}

def err(msg, code=1):
    print("error: " + msg, file=sys.stderr)
    return code

def unquote(v):
    v = v.strip()
    if len(v) >= 2 and v[0] in "'\"" and v[-1] == v[0]:
        q = v[0]; s = v[1:-1]
        if q == '"':
            s = bytes(s, 'utf-8').decode('unicode_escape')
        else:
            s = s.replace("\\'", "'")
        return s
    return v

def quote(s):
    s = str(s)
    if "'" not in s:
        return "'" + s + "'"
    return '"' + s.replace("\\", "\\\\").replace('"', '\\"').replace("\n", "\\n") + '"'

def parse_array(first, lines_iter):
    txt = first.strip()
    vals = []
    if txt.startswith('[') and ']' in txt:
        inner = txt[1:txt.rfind(']')]
        parts = [p.strip() for p in inner.split(',') if p.strip()]
        return [unquote(p) for p in parts]
    if txt.startswith('['):
        for line in lines_iter:
            t = line.strip()
            if t.startswith(']'):
                break
            if t.endswith(','):
                t = t[:-1]
            if t:
                vals.append(unquote(t))
    return vals

def load_config(path):
    cfg = Config()
    try:
        lines = open(path, encoding='utf-8').read().splitlines()
    except OSError as e:
        raise RuntimeError(f"Unable to read config from file {path}: {e.strerror} (os error {e.errno}) ")
    cur = None
    it = iter(lines)
    for line in it:
        s = line.strip()
        if not s or s.startswith('#'):
            continue
        if s.startswith('[') and s.endswith(']'):
            name = s[1:-1]
            if name.startswith('scripts.'):
                alias = name[len('scripts.'):]
                cfg.scripts.setdefault(alias, {})
                cur = ('script', alias)
            elif name == 'default':
                cur = ('default', None)
            else:
                cur = None
            continue
        if '=' not in s or cur is None:
            continue
        k, v = s.split('=', 1); k = k.strip(); v = v.strip()
        val = parse_array(v, it) if v.startswith('[') else unquote(v)
        if cur[0] == 'script':
            cfg.scripts[cur[1]][k] = val
        else:
            cfg.default[k] = val
    return cfg

def save_config(path, cfg):
    out = []
    for alias, data in cfg.scripts.items():
        out.append(f"[scripts.{alias}]")
        if 'command' in data: out.append(f"command = {quote(data['command'])}")
        if data.get('description') is not None: out.append(f"description = {quote(data.get('description',''))}")
        if data.get('tags'):
            tags = list(data['tags'])
            if len(tags) == 1:
                out.append(f"tags = [{quote(tags[0])}]")
            else:
                out.append("tags = [")
                for t in tags: out.append(f"    {quote(t)},")
                out.append("]")
        out.append("")
    out.append("[default]")
    for k, v in cfg.default.items():
        if isinstance(v, list): out.append(f"{k} = [{', '.join(quote(x) for x in v)}]")
        elif isinstance(v, bool): out.append(f"{k} = {'true' if v else 'false'}")
        elif str(v).isdigit(): out.append(f"{k} = {v}")
        else: out.append(f"{k} = {quote(v)}")
    with open(path, 'w', encoding='utf-8') as f:
        f.write('\n'.join(out) + '\n')

def config_path(given=None, need_existing=True):
    if given:
        return given
    env = os.environ.get('PIER_CONFIG_PATH')
    candidates = []
    if env: candidates.append(env)
    candidates.append(os.path.join(os.getcwd(), 'pier.toml'))
    xdg = os.environ.get('XDG_CONFIG_HOME') or os.path.join(os.path.expanduser('~'), '.config')
    candidates += [os.path.join(xdg, 'pier', 'config.toml'), os.path.join(xdg, 'pier', 'config'), os.path.join(xdg, 'pier.toml')]
    home = os.path.expanduser('~')
    candidates += [os.path.join(home, '.pier.toml'), os.path.join(home, '.pier')]
    for p in candidates:
        if os.path.exists(p): return p
    if need_existing: raise RuntimeError("No default config file found. See help for more info.")
    return os.path.join(xdg, 'pier', 'config.toml')

def read_cfg(path):
    try:
        return load_config(path)
    except RuntimeError as e:
        raise

def require_scripts(cfg):
    if not cfg.scripts:
        raise RuntimeError("No scripts exist. Would you like to add a new script?")

def get_script(cfg, alias):
    require_scripts(cfg)
    if alias not in cfg.scripts:
        raise RuntimeError(f"AliasNotFound:  {alias}")
    return cfg.scripts[alias]

def parse_global(argv):
    cfg = None; rest = []; i = 0; verbose = 0
    while i < len(argv):
        a = argv[i]
        if a in ('-c','--config-file'):
            if i+1 >= len(argv): return cfg, ['--badarg']
            cfg = argv[i+1]; i += 2
        elif a.startswith('--config-file='):
            cfg = a.split('=',1)[1]; i += 1
        elif a in ('-v','--verbose'):
            verbose += 1; i += 1
        else:
            rest = argv[i:]; break
    return cfg, rest

def parse_add(args):
    alias = desc = command = None; tags=[]; force=False; i=0
    while i < len(args):
        a=args[i]
        if a == '--':
            command = ' '.join(args[i+1:]) if i+1 < len(args) else '' ; break
        if a in ('-h','--help'): print(HELP['add']); return None
        if a in ('-V','--version'): print('executable-add 0.1.6'); return None
        if a in ('-f','--force'): force=True; i+=1; continue
        if a in ('-a','--alias'):
            alias=args[i+1] if i+1<len(args) else None; i+=2; continue
        if a.startswith('--alias='):
            alias=a.split('=',1)[1]; i+=1; continue
        if a in ('-d','--description'):
            desc=args[i+1] if i+1<len(args) else ''; i+=2; continue
        if a.startswith('--description='):
            desc=a.split('=',1)[1]; i+=1; continue
        if a in ('-t','--tag'):
            i+=1
            while i < len(args) and not args[i].startswith('-'):
                tags.append(args[i]); i+=1
            continue
        if a.startswith('--tag='):
            tags.append(a.split('=',1)[1]); i+=1; continue
        command = ' '.join(args[i:]); break
    return alias, desc, tags, command, force

def table(rows, cmd_width=None, full=False):
    headers = ['Alias','Tags','Command','Description']
    data=[]
    for alias, s in rows:
        tags = ','.join(s.get('tags') or [])
        cmd = s.get('command','')
        if not full:
            w = int(cmd_width) if cmd_width is not None else 40
            if len(cmd) > w: cmd = cmd[:w]
        data.append([alias, tags, cmd, s.get('description','') or ''])
    widths=[len(h) for h in headers]
    for r in data:
        for idx, cell in enumerate(r): widths[idx]=max(widths[idx], len(cell))
    line = '≖' * (sum(widths) + 3*len(widths) + 1)
    def row(vals):
        return '⋮ ' + ' ⋮ '.join(str(vals[i]).ljust(widths[i]) for i in range(4)) + ' ⋮'
    print(line); print(row(headers)); print(line)
    for r in data: print(row(r))
    print(line)

def cmd_list(cfg, args):
    q=False; full=False; width=None; tags=[]; i=0
    while i < len(args):
        a=args[i]
        if a in ('-h','--help'): print(HELP['list']); return 0
        if a in ('-V','--version'): print('executable-list 0.1.6'); return 0
        if a in ('-q','--list_aliases'): q=True; i+=1; continue
        if a in ('-l','--cmd_full'): full=True; i+=1; continue
        if a in ('-c','--cmd_width'):
            width=args[i+1]; i+=2; continue
        if a.startswith('--cmd_width=') or a.startswith('--cmd-width='):
            width=a.split('=',1)[1]; i+=1; continue
        if a in ('-t','--tag'):
            i+=1
            while i < len(args) and not args[i].startswith('-'):
                tags.append(args[i]); i+=1
            continue
        if a.startswith('--tag='):
            tags.append(a.split('=',1)[1]); i+=1; continue
        i+=1
    require_scripts(cfg)
    rows=[]
    for al, s in cfg.scripts.items():
        st=set(s.get('tags') or [])
        if tags and not any(t in st for t in tags): continue
        rows.append((al,s))
    if q:
        for al,_ in rows: print(al)
    else:
        table(rows, width, full)
    return 0

def open_editor(initial=''):
    editor = os.environ.get('EDITOR') or 'vi'
    fd, name = tempfile.mkstemp(prefix='pier-', text=True)
    os.close(fd)
    with open(name,'w',encoding='utf-8') as f: f.write(initial)
    try:
        rc = subprocess.call([editor, name])
        if rc != 0: raise RuntimeError(f"EditorError: Failed when trying to get input from editor Failed to open `{editor}` as a text editor or editor was terminated with errors.")
        return open(name, encoding='utf-8').read().rstrip('\n')
    finally:
        try: os.unlink(name)
        except OSError: pass

def main(argv):
    cfgfile, rest = parse_global(argv)
    if not rest or rest[0] in ('-h','--help'):
        print(TOP_HELP); return 0
    if rest[0] in ('-V','--version'):
        print(VERSION); return 0
    sub = rest[0]
    if sub == 'help':
        if len(rest) == 1: print(TOP_HELP)
        else: print(HELP.get(ALIASES.get(rest[1], rest[1]), TOP_HELP))
        return 0
    sub = ALIASES.get(sub, sub)
    if sub in HELP and len(rest) > 1 and rest[1] in ('-h','--help'):
        print(HELP[sub]); return 0
    if sub in HELP and len(rest) > 1 and rest[1] in ('-V','--version'):
        print(f"executable-{sub} 0.1.6"); return 0
    try:
        if sub == 'config-init':
            path = config_path(cfgfile, need_existing=False)
            if os.path.exists(path): raise RuntimeError(f"Cannot initialize config at {path}, file already exists.")
            os.makedirs(os.path.dirname(path) or '.', exist_ok=True)
            c=Config(); save_config(path,c); print('Added hello-pier'); return 0
        path = config_path(cfgfile, need_existing=True)
        cfg = read_cfg(path)
        if sub == 'add':
            parsed = parse_add(rest[1:])
            if parsed is None: return 0
            alias, desc, tags, command, force = parsed
            if not alias: return err("The following required arguments were not provided:\n    --alias <alias>")
            if command is None: command = open_editor('')
            if alias in cfg.scripts and not force: raise RuntimeError(f"AliasAlreadyExists:  {alias}")
            d={'command': command}
            if desc is not None: d['description']=desc
            if tags: d['tags']=tags
            cfg.scripts[alias]=d; save_config(path,cfg); print(f"Added {alias}"); return 0
        if sub == 'list': return cmd_list(cfg, rest[1:])
        if sub == 'show':
            s=get_script(cfg, rest[1] if len(rest)>1 else '') ; print(s.get('command','')); return 0
        if sub == 'run' or (ALIASES.get(rest[0], rest[0]) not in HELP):
            if sub == 'run': alias = rest[1] if len(rest)>1 else ''; args = rest[2:]
            else: alias = rest[0]; args = rest[1:]
            s=get_script(cfg, alias)
            return subprocess.call(['/bin/sh','-c',s.get('command',''), alias] + args)
        if sub == 'remove':
            alias = rest[1] if len(rest)>1 else ''; get_script(cfg, alias); del cfg.scripts[alias]; save_config(path,cfg); print(f"Removed {alias}"); return 0
        if sub == 'copy':
            fr = rest[1] if len(rest)>1 else ''; to = rest[2] if len(rest)>2 else ''
            s=get_script(cfg, fr)
            if to in cfg.scripts: raise RuntimeError(f"AliasAlreadyExists:  {to}")
            cfg.scripts[to]=dict(s); save_config(path,cfg); print(f"Copy from alias {fr} to new alias {to}"); return 0
        if sub == 'move':
            args=rest[1:]; force=False
            if args and args[0] in ('-f','--force'): force=True; args=args[1:]
            fr=args[0] if len(args)>0 else ''; to=args[1] if len(args)>1 else ''
            s=get_script(cfg, fr)
            if to in cfg.scripts and not force: raise RuntimeError(f"AliasAlreadyExists:  {to}")
            cfg.scripts[to]=dict(s); del cfg.scripts[fr]; save_config(path,cfg); print(f"Move from alias {fr} to new alias {to}"); return 0
        if sub == 'edit':
            alias=rest[1] if len(rest)>1 else ''; s=get_script(cfg, alias); s['command']=open_editor(s.get('command','')); save_config(path,cfg); print(f"Edited {alias}"); return 0
        return err(f"Found argument '{rest[0]}' which wasn't expected")
    except RuntimeError as e:
        return err(str(e))

if __name__ == '__main__':
    sys.exit(main(sys.argv[1:]))
