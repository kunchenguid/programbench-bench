#!/usr/bin/env python3
import argparse
import datetime
import json
import os
import re
import subprocess
import sys
from pathlib import Path


VERSION = "clog 0.10.0"

HELP = """a conventional changelog for the rest of us

Usage: executable [OPTIONS]

Options:
  -r, --repository <URL>  Repository used for generating commit and issue links (without the .git,
                          e.g. https://github.com/thoughtram/clog)
  -f, --from <COMMIT>     e.g. 12a8546
  -T, --format <STR>      The output format, defaults to markdown [default: markdown] [possible
                          values: markdown, json]
  -M, --major             Increment major version by one (Sets minor and patch to 0)
  -g, --git-dir <PATH>    Local .git directory (defaults to "$(pwd)/.git")
  -w, --work-tree <PATH>  Local working tree of the git project (defaults to "$(pwd)")
  -m, --minor             Increment minor version by one (Sets patch to 0)
  -p, --patch             Increment patch version by one
  -s, --subtitle <STR>
  -t, --to <COMMIT>       e.g. 8057684 [default: HEAD]
  -o, --outfile <PATH>    Where to write the changelog (Defaults to stdout when omitted)
  -c, --config <COMMIT>   The Clog Configuration TOML file to use [default: .clog.toml]
  -i, --infile <PATH>     A changelog to append to, but *NOT* write to (Useful in conjunction with
                          --outfile)
      --setversion <VER>  e.g. 1.0.1
  -F, --from-latest-tag   use latest tag as start (instead of --from)
  -l, --link-style <STR>  The style of repository link to generate [default: github] [possible
                          values: github, gitlab, stash, cgit]
  -C, --changelog <PATH>  A previous changelog to prepend new changes to (this is like using the
                          same file for both --infile and --outfile and should not be used in
                          conjunction with either)
  -h, --help              Print help
  -V, --version           Print version


If your .git directory is a child of your project directory (most common, such as /myproject/.git)
AND not in the current working directory (i.e you need to use --work-tree or --git-dir) you only
need to specify either the --work-tree (i.e. /myproject) OR --git-dir (i.e. /myproject/.git), you
don't need to use both.

If using the --config to specify a clog configuration TOML file NOT in the current working directory
(meaning you need to use --work-tree or --git-dir) AND the TOML file is inside your project
directory (i.e. /myproject/.clog.toml) you do not need to use --work-tree or --git-dir.
"""


SECTION_ORDER = [
    ("breaking", "Breaking Changes"),
    ("feat", "Features"),
    ("fix", "Bug Fixes"),
    ("docs", "Documentation"),
    ("style", "Style Fixes"),
    ("perf", "Performance"),
    ("refactor", "Improvements"),
    ("test", "Tests"),
    ("chore", "Improvements"),
    ("build", "Improvements"),
    ("ci", "Improvements"),
]

TYPE_TO_SECTION = {k: (k, v) for k, v in SECTION_ORDER}
TYPE_TO_SECTION.update({
    "feature": ("feat", "Features"),
    "bug": ("fix", "Bug Fixes"),
    "bugfix": ("fix", "Bug Fixes"),
    "doc": ("docs", "Documentation"),
})


class Parser(argparse.ArgumentParser):
    def error(self, message):
        print(f"error: {message}", file=sys.stderr)
        print("", file=sys.stderr)
        print("Usage: executable [OPTIONS]", file=sys.stderr)
        print("", file=sys.stderr)
        print("For more information, try '--help'.", file=sys.stderr)
        raise SystemExit(2)


def parse_args(argv):
    if "--help" in argv or "-h" in argv:
        print(HELP)
        raise SystemExit(0)
    if "--version" in argv or "-V" in argv:
        print(VERSION)
        raise SystemExit(0)

    p = Parser(add_help=False, prog="executable")
    p.add_argument("-r", "--repository")
    p.add_argument("-f", "--from", dest="from_commit")
    p.add_argument("-T", "--format", default="markdown")
    p.add_argument("-M", "--major", action="store_true")
    p.add_argument("-g", "--git-dir")
    p.add_argument("-w", "--work-tree")
    p.add_argument("-m", "--minor", action="store_true")
    p.add_argument("-p", "--patch", action="store_true")
    p.add_argument("-s", "--subtitle")
    p.add_argument("-t", "--to", default="HEAD")
    p.add_argument("-o", "--outfile")
    p.add_argument("-c", "--config", default=".clog.toml")
    p.add_argument("-i", "--infile")
    p.add_argument("--setversion")
    p.add_argument("-F", "--from-latest-tag", action="store_true")
    p.add_argument("-l", "--link-style", default="github")
    p.add_argument("-C", "--changelog")
    ns = p.parse_args(argv)
    if ns.format not in ("markdown", "json"):
        print(f"error: invalid value '{ns.format}' for '--format <STR>'", file=sys.stderr)
        print("  [possible values: markdown, json]", file=sys.stderr)
        print("", file=sys.stderr)
        print("For more information, try '--help'.", file=sys.stderr)
        raise SystemExit(2)
    if ns.link_style not in ("github", "gitlab", "stash", "cgit"):
        print(f"error: invalid value '{ns.link_style}' for '--link-style <STR>'", file=sys.stderr)
        print("  [possible values: github, gitlab, stash, cgit]", file=sys.stderr)
        raise SystemExit(2)
    return ns


def read_config(path):
    cfg = {}
    try:
        text = Path(path).read_text()
    except OSError:
        return cfg
    in_clog = False
    for raw in text.splitlines():
        line = raw.split("#", 1)[0].strip()
        if not line:
            continue
        if line.startswith("[") and line.endswith("]"):
            in_clog = line == "[clog]"
            continue
        if not in_clog or "=" not in line:
            continue
        k, v = [x.strip() for x in line.split("=", 1)]
        k = k.replace("-", "_")
        if v.lower() in ("true", "false"):
            cfg[k] = v.lower() == "true"
        elif (v.startswith('"') and v.endswith('"')) or (v.startswith("'") and v.endswith("'")):
            cfg[k] = v[1:-1]
        else:
            cfg[k] = v
    return cfg


def git_cmd(args, ns, check=False):
    cmd = ["git"]
    if ns.git_dir:
        cmd += ["--git-dir", ns.git_dir]
    if ns.work_tree:
        cmd += ["--work-tree", ns.work_tree]
    cmd += args
    try:
        return subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                              text=True, check=check).stdout
    except (OSError, subprocess.CalledProcessError):
        return ""


def latest_tag(ns):
    return git_cmd(["describe", "--tags", "--abbrev=0"], ns).strip()


def commit_records(ns, start, end):
    if not start:
        return []
    rev = f"{start}..{end or 'HEAD'}"
    fmt = "%H%x1f%h%x1f%s%x1f%b%x1e"
    out = git_cmd(["log", "--reverse", f"--format={fmt}", rev], ns)
    records = []
    for rec in out.strip("\x1e\n").split("\x1e"):
        if not rec.strip():
            continue
        parts = rec.strip("\n").split("\x1f", 3)
        if len(parts) == 4:
            records.append({"hash": parts[0], "short": parts[1], "subject": parts[2], "body": parts[3]})
    return records


def repo_link(repo, style, kind, ident):
    if not repo:
        return ident
    repo = repo[:-4] if repo.endswith(".git") else repo
    if kind == "commit":
        if style == "gitlab":
            return f"{repo}/commit/{ident}"
        if style == "stash":
            return f"{repo}/commits/{ident}"
        if style == "cgit":
            return f"{repo}/commit/?id={ident}"
        return f"{repo}/commit/{ident}"
    if style == "gitlab":
        return f"{repo}/issues/{ident}"
    if style == "stash":
        return f"{repo}/browse?focusedCommentId={ident}"
    if style == "cgit":
        return f"{repo}/?id={ident}"
    return f"{repo}/issues/{ident}"


def parse_commit(c, repo, style):
    subj = c["subject"].strip()
    body = c["body"] or ""
    m = re.match(r"^([A-Za-z]+)(?:\(([^)]*)\))?(!)?:\s*(.+)$", subj)
    if not m:
        return None
    typ, scope, bang, desc = m.groups()
    typ_l = typ.lower()
    breaking = bool(bang) or "BREAKING CHANGE" in body or "BREAKING-CHANGE" in body
    key, title = ("breaking", "Breaking Changes") if breaking else TYPE_TO_SECTION.get(typ_l, (None, None))
    if key is None:
        return None
    issues = []
    for im in re.finditer(r"(?i)(?:close[sd]?|fix(?:e[sd])?|resolve[sd]?)\s+#(\d+)", body + "\n" + subj):
        num = im.group(1)
        issues.append(f"closes [#{num}]({repo_link(repo, style, 'issue', num)})")
    commit_md = f"[{c['short']}]({repo_link(repo, style, 'commit', c['hash'])})" if repo else c["short"]
    text = f"**{scope}**: {desc}" if scope else desc
    if issues:
        text += " (" + commit_md + ", " + ", ".join(dict.fromkeys(issues)) + ")"
    else:
        text += " (" + commit_md + ")"
    return {"key": key, "title": title, "text": text, "commit": c, "scope": scope, "description": desc}


def previous_text(ns):
    path = ns.changelog or ns.infile
    if not path:
        return ""
    try:
        return Path(path).read_text()
    except OSError:
        return ""


def first_version(text):
    m = re.search(r"<a name=\"([^\"]+)\"", text)
    if m:
        return m.group(1)
    m = re.search(r"^#+\s+v?(\d+\.\d+\.\d+)", text, re.M)
    return m.group(1) if m else None


def bump(ver, ns):
    if ns.setversion:
        return ns.setversion, False
    prev = first_version(previous_text(ns))
    if not prev:
        if ns.major or ns.minor or ns.patch:
            print("\x1b[1;31merror:\x1b[0m Failed to parse version into valid SemVer. Ensure the version is in the X.Y.Z format.", file=sys.stderr)
            raise SystemExit(1)
        return None, False
    prefix = "v" if prev.startswith("v") else ""
    nums = prev[1:] if prefix else prev
    m = re.match(r"^(\d+)\.(\d+)\.(\d+)$", nums)
    if not m:
        return prev, False
    major, minor, patch = map(int, m.groups())
    patch_header = False
    if ns.major:
        major, minor, patch = major + 1, 0, 0
    elif ns.minor:
        minor, patch = minor + 1, 0
    elif ns.patch:
        patch += 1
        patch_header = True
    return f"{prefix}{major}.{minor}.{patch}", patch_header


def render_markdown(version, subtitle, date, patch_header, sections):
    ver = version or ""
    hashes = "###" if patch_header else "##"
    out = [f'<a name="{ver}"></a>', f"{hashes} {ver} {subtitle or ''} ({date})", ""]
    for title, items in sections:
        out += ["", f"#### {title}", ""]
        out += [f"* {item['text']}" for item in items]
    out += ["", "", ""]
    return "\n".join(out)


def render_json(version, subtitle, date, patch_header, sections):
    sec_obj = None
    if sections:
        sec_obj = []
        for title, items in sections:
            sec_obj.append({
                "title": title,
                "commits": [{
                    "hash": it["commit"]["hash"],
                    "short_hash": it["commit"]["short"],
                    "subject": it["commit"]["subject"],
                    "scope": it["scope"],
                    "description": it["description"],
                } for it in items]
            })
    version_s = f'Some("{version}")' if version is not None else "None"
    subtitle_s = "null" if subtitle is None else json.dumps(subtitle)
    sections_s = "null" if sec_obj is None else json.dumps(sec_obj, separators=(",", ":"))
    patch_s = "true" if patch_header else "false"
    return (
        f'{{"header":{{"version":{version_s},"patch_version":{patch_s},'
        f'"subtitle":{subtitle_s},"date":"{date}"}},"sections":{sections_s}}}'
    )


def main(argv):
    ns = parse_args(argv)
    cfg = read_config(ns.config)
    if not ns.repository:
        ns.repository = cfg.get("repository")
    if not ns.from_latest_tag:
        ns.from_latest_tag = bool(cfg.get("from_latest_tag"))
    if not ns.work_tree and not ns.git_dir:
        ns.work_tree = os.getcwd()
        ns.git_dir = os.path.join(os.getcwd(), ".git")

    start = ns.from_commit
    if ns.from_latest_tag and not start:
        start = latest_tag(ns)
    version, patch_header = bump(None, ns)
    date = datetime.date.today().isoformat()

    grouped = {}
    for c in commit_records(ns, start, ns.to):
        item = parse_commit(c, ns.repository, ns.link_style)
        if item:
            grouped.setdefault(item["key"], {"title": item["title"], "items": []})["items"].append(item)
    sections = []
    seen_titles = set()
    for key, title in SECTION_ORDER:
        if key in grouped:
            actual_title = grouped[key]["title"]
            if actual_title in seen_titles:
                sections[-1][1].extend(grouped[key]["items"])
            else:
                sections.append((actual_title, grouped[key]["items"]))
                seen_titles.add(actual_title)

    if ns.format == "json":
        rendered = render_json(version, ns.subtitle, date, patch_header, sections)
    else:
        rendered = render_markdown(version, ns.subtitle, date, patch_header, sections)
        if ns.changelog or ns.infile:
            old = previous_text(ns)
            if old:
                rendered = rendered + old

    if ns.outfile or ns.changelog:
        Path(ns.outfile or ns.changelog).write_text(rendered)
    else:
        sys.stdout.write(rendered)
    sys.stdout.write("changelog written. (took 0 ms)\n")


if __name__ == "__main__":
    main(sys.argv[1:])
