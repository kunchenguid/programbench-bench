#!/usr/bin/env python3
import os
import sys
import textwrap

VERSION = "2027.0-dev-20260414-24ac8ab-unknown"
SHA = "24ac8abecd15814143951f211394c29bdfc42e13"

COMMANDS = [
    ("anaeig", "Analyze eigenvectors/normal modes"),
    ("analyze", "Analyze data sets"),
    ("angle", "Calculate distributions and correlations for angles and dihedrals"),
    ("awh", "Extract data from an accelerated weight histogram (AWH) run"),
    ("bar", "Calculate free energy difference estimates through Bennett's acceptance ratio"),
    ("bundle", "Analyze bundles of axes, e.g., helices"),
    ("check", "Check and compare files"),
    ("chi", "Calculate everything you want to know about chi and other dihedrals"),
    ("cluster", "Cluster structures"),
    ("clustsize", "Calculate size distributions of atomic clusters"),
    ("confrms", "Fit two structures and calculates the RMSD"),
    ("convert-tpr", "Make a modified run-input file"),
    ("convert-trj", "Converts between different trajectory types"),
    ("covar", "Calculate and diagonalize the covariance matrix"),
    ("current", "Calculate dielectric constants and current autocorrelation function"),
    ("density", "Calculate the density of the system"),
    ("densmap", "Calculate 2D planar or axial-radial density maps"),
    ("densorder", "Calculate surface fluctuations"),
    ("dielectric", "Calculate frequency dependent dielectric constants"),
    ("dipoles", "Compute the total dipole plus fluctuations"),
    ("disre", "Analyze distance restraints"),
    ("distance", "Calculate distances between pairs of positions"),
    ("dos", "Analyze density of states and properties based on that"),
    ("dssp", "Calculate protein secondary structure via DSSP algorithm"),
    ("dump", "Make binary files human readable"),
    ("dyecoupl", "Extract dye dynamics from trajectories"),
    ("editconf", "Convert and manipulates structure files"),
    ("eneconv", "Convert energy files"),
    ("enemat", "Extract an energy matrix from an energy file"),
    ("energy", "Writes energies to xvg files and display averages"),
    ("extract-cluster", "Allows extracting frames corresponding to clusters from trajectory"),
    ("filter", "Frequency filter trajectories, useful for making smooth movies"),
    ("freevolume", "Calculate free volume"),
    ("gangle", "Calculate angles"),
    ("genconf", "Multiply a conformation in 'random' orientations"),
    ("genion", "Generate monoatomic ions on energetically favorable positions"),
    ("genrestr", "Generate position restraints or distance restraints for index groups"),
    ("grompp", "Make a run input file"),
    ("gyrate", "Calculate radius of gyration of a molecule"),
    ("gyrate-legacy", "Calculate the radius of gyration"),
    ("h2order", "Compute the orientation of water molecules"),
    ("hbond", "Compute and analyze hydrogen bonds."),
    ("hbond-legacy", "Compute and analyze hydrogen bonds"),
    ("helix", "Calculate basic properties of alpha helices"),
    ("helixorient", "Calculate local pitch/bending/rotation/orientation inside helices"),
    ("help", "Print help information"),
    ("hydorder", "Compute tetrahedrality parameters around a given atom"),
    ("insert-molecules", "Insert molecules into existing vacancies"),
    ("lie", "Estimate free energy from linear combinations"),
    ("make_edi", "Generate input files for essential dynamics sampling"),
    ("make_ndx", "Make index files"),
    ("mdmat", "Calculate residue contact maps"),
    ("mdrun", "Perform a simulation, do a normal mode analysis or an energy minimization"),
    ("mindist", "Calculate the minimum distance between two groups"),
    ("mk_angndx", "Generate index files for 'gmx angle'"),
    ("msd", "Compute mean squared displacements"),
    ("nmeig", "Diagonalize the Hessian for normal mode analysis"),
    ("nmens", "Generate an ensemble of structures from the normal modes"),
    ("nmr", "Analyze nuclear magnetic resonance properties from an energy file"),
    ("nmtraj", "Generate a virtual oscillating trajectory from an eigenvector"),
    ("nonbonded-benchmark", "Benchmarking tool for the non-bonded pair kernels."),
    ("order", "Compute the order parameter per atom for carbon tails"),
    ("pairdist", "Calculate pairwise distances between groups of positions"),
    ("pdb2gmx", "Convert coordinate files to topology and FF-compliant coordinate files"),
    ("pme_error", "Estimate the error of using PME with a given input file"),
    ("polystat", "Calculate static properties of polymers"),
    ("potential", "Calculate the electrostatic potential across the box"),
    ("principal", "Calculate principal axes of inertia for a group of atoms"),
    ("rama", "Compute Ramachandran plots"),
    ("rdf", "Calculate radial distribution functions"),
    ("report-methods", "Write short summary about the simulation setup to a text file and/or to the standard output."),
    ("rms", "Calculate RMSDs with a reference structure and RMSD matrices"),
    ("rmsdist", "Calculate atom pair distances averaged with power -2, -3 or -6"),
    ("rmsf", "Calculate atomic fluctuations"),
    ("rotacf", "Calculate the rotational correlation function for molecules"),
    ("rotmat", "Plot the rotation matrix for fitting to a reference structure"),
    ("saltbr", "Compute salt bridges"),
    ("sans-legacy", "Compute small angle neutron scattering spectra"),
    ("sasa", "Compute solvent accessible surface area"),
    ("saxs-legacy", "Compute small angle X-ray scattering spectra"),
    ("scattering", "Calculate small angle scattering profiles for SANS or SAXS"),
    ("select", "Print general information about selections"),
    ("sham", "Compute free energies or other histograms from histograms"),
    ("sigeps", "Convert c6/12 or c6/cn combinations to and from sigma/epsilon"),
    ("solvate", "Solvate a system"),
    ("sorient", "Analyze solvent orientation around solutes"),
    ("spatial", "Calculate the spatial distribution function"),
    ("spol", "Analyze solvent dipole orientation and polarization around solutes"),
    ("tcaf", "Calculate viscosities of liquids"),
    ("traj", "Plot x, v, f, box, temperature and rotational energy from trajectories"),
    ("trajectory", "Print coordinates, velocities, and/or forces for selections"),
    ("trjcat", "Concatenate trajectory files"),
    ("trjconv", "Convert and manipulates trajectory files"),
    ("trjorder", "Order molecules according to their distance to a group"),
    ("tune_pme", "Time mdrun as a function of PME ranks to optimize settings"),
    ("vanhove", "Compute Van Hove displacement and correlation functions"),
    ("velacc", "Calculate velocity autocorrelation functions"),
    ("wham", "Perform weighted histogram analysis after umbrella sampling"),
    ("wheel", "Plot helical wheels"),
    ("x2top", "Generate a primitive topology from coordinates"),
    ("xpm2ps", "Convert XPM (XPixelMap) matrices to postscript or XPM"),
]
COMMAND_DESCRIPTIONS = dict(COMMANDS)
COMMAND_NAMES = set(COMMAND_DESCRIPTIONS)

QUOTE = 'GROMACS reminds you: "There are way too many quotes" (Sebastian Wingbermuehle)'


def wrap(text, width=78, indent=""):
    return "\n".join(textwrap.wrap(text, width=width, subsequent_indent=indent))


def exe_name():
    return os.path.basename(sys.argv[0]) or "executable"


def displayed_path():
    invoked = sys.argv[0]
    if invoked.startswith("./"):
        return os.path.join(os.getcwd(), invoked)
    return os.path.abspath(invoked)


def banner(module, args, quiet=False, quote=True):
    if quiet:
        return
    print(f"        :-) GROMACS - {module}, {VERSION} (-:\n")
    print(f"Executable:   {displayed_path()}")
    print("Data prefix:  /usr/local/gromacs")
    print(f"Working dir:  {os.getcwd()}")
    print("Command line:")
    cmd = " ".join([exe_name()] + args)
    print(f"  {cmd}\n")
    if quote:
        print(f"\n{QUOTE}\n")


def common_help():
    print("""SYNOPSIS

gmx [-[no]h] [-[no]quiet] [-[no]version] [-[no]copyright] [-nice <int>]
    [-[no]backup]

OPTIONS

Other options:

 -[no]h                     (no)
           Print help and quit
 -[no]quiet                 (no)
           Do not print common startup info or quotes
 -[no]version               (no)
           Print extended version information and quit
 -[no]copyright             (no)
           Print copyright information on startup
 -nice   <int>              (19)
           Set the nicelevel (default depends on command)
 -[no]backup                (yes)
           Write backups if output files exist

Additional help is available on the following topics:
    commands    List of available commands
    selections  Selection syntax and usage
To access the help, use 'gmx help <topic>'.
For help on a command, use 'gmx help <command>'.""")


def version():
    print(f"""GROMACS version:     {VERSION}
GIT SHA1 hash:       {SHA}
Branched from:       unknown
Precision:           mixed
Memory model:        64 bit
MPI library:         thread_mpi
MPI version:         built in
OpenMP support:      enabled (GMX_OPENMP_MAX_THREADS = 128)
GPU support:         disabled
SIMD instructions:   None
CPU FFT library:     fftw-3.3.10
GPU FFT library:     none
Multi-GPU FFT:       none
RDTSCP:              enabled
TNG support:         enabled
Hwloc support:       disabled
Tracing support:     disabled
Colvars support:     enabled (version 2025-10-13)
CP2K support:        disabled
Torch support:       disabled
Plumed support:      enabled
C compiler:          /usr/bin/cc GNU 11.4.0
C++ compiler:        /usr/bin/c++ GNU 11.4.0
BLAS library:        Internal
LAPACK library:      Internal
""")


def commands_help():
    print("""LIST OF AVAILABLE COMMANDS

Usage: gmx [<options>] <command> [<args>]

Available commands:""")
    for name, desc in COMMANDS:
        prefix = f"    {name:<20} "
        lines = textwrap.wrap(desc, width=57)
        if not lines:
            print(prefix)
        else:
            print(prefix + lines[0])
            for line in lines[1:]:
                print(" " * 25 + line)
    print("For help on a command, use 'gmx help <command>'.")


def selections_help():
    print("""SELECTION SYNTAX AND USAGE

Selections are used to select atoms/molecules/residues for analysis. In
contrast to traditional index files, selections can be dynamic, i.e., select
different atoms for different trajectory frames. The GROMACS manual contains a
short introductory section to selections in the Analysis chapter.

Available subtopics:
    arithmetic   Arithmetic expressions in selections
    cmdline      Specifying selections from command line
    evaluation   Selection evaluation and optimization
    examples     Selection examples
    keywords     Selection keywords
    limitations  Selection limitations
    positions    Specifying positions in selections
    syntax       Selection syntax""")


def mdrun_help():
    print("""SYNOPSIS

gmx mdrun [-s [<.tpr>]] [-cpi [<.cpt>]] [-deffnm <string>] [-nt <int>]
          [-ntmpi <int>] [-ntomp <int>] [-[no]v] [-[no]append]
          [-nsteps <int>] [-maxh <real>]

DESCRIPTION

gmx mdrun is the main computational chemistry engine within GROMACS.
Obviously, it performs Molecular Dynamics simulations, but it can also perform
Stochastic Dynamics, Energy Minimization, test particle insertion or
(re)calculation of energies.

The mdrun program reads the run input file (-s). mdrun produces a log file,
trajectory, final structure, and energy file. Running mdrun efficiently in
parallel is a complex topic covered in the GROMACS user guide.

OPTIONS

Options to specify input files:

 -s      [<.tpr>]           (topol.tpr)
           Portable xdr run input file
 -cpi    [<.cpt>]           (state.cpt)      (Opt.)
           Checkpoint file

Options to specify output files:

 -o      [<.trr/.cpt/...>]  (traj.trr)
           Full precision trajectory: trr cpt tng h5md
 -x      [<.xtc/.tng>]      (traj_comp.xtc)  (Opt.)
           Compressed trajectory
 -cpo    [<.cpt>]           (state.cpt)      (Opt.)
           Checkpoint file
 -c      [<.gro/.g96/...>]  (confout.gro)
           Structure file
 -e      [<.edr>]           (ener.edr)
           Energy file
 -g      [<.log>]           (md.log)
           Log file

Other options:

 -deffnm <string>
           Set the default filename for all file options
 -nt     <int>              (0)
           Total number of threads to start
 -[no]v                     (no)
           Be loud and noisy
 -nsteps <int>              (-2)
           Run this number of steps, overrides .mdp file option
 -maxh   <real>             (-1)
           Terminate after 0.99 times this time (hours)""")


def grompp_help():
    print("""SYNOPSIS

gmx grompp [-f [<.mdp>]] [-c [<.gro/.g96/...>]] [-r [<.gro/.g96/...>]]
           [-p [<.top>]] [-n [<.ndx>]] [-o [<.tpr>]] [-po [<.mdp>]]
           [-pp [<.top>]] [-maxwarn <int>]

DESCRIPTION

gmx grompp (the gromacs preprocessor) reads a molecular topology file, checks
the validity of the file, expands the topology from a molecular description to
an atomic description, and writes a binary run input file.

OPTIONS

 -f      [<.mdp>]           (grompp.mdp)
           grompp input file with MD parameters
 -c      [<.gro/.g96/...>]  (conf.gro)
           Structure file
 -p      [<.top>]           (topol.top)
           Topology file
 -o      [<.tpr>]           (topol.tpr)
           Portable xdr run input file
 -maxwarn <int>             (0)
           Number of allowed warnings during input processing""")


def pdb2gmx_help():
    print("""SYNOPSIS

gmx pdb2gmx [-f [<.gro/.g96/...>]] [-o [<.gro/.g96/...>]] [-p [<.top>]]
            [-i [<.itp>]] [-n [<.ndx>]] [-water <enum>] [-ff <string>]

DESCRIPTION

gmx pdb2gmx reads a coordinate file and builds a molecular topology. This
reimplementation reports the command-line interface but does not include the
GROMACS force-field database.

OPTIONS

 -f      [<.gro/.g96/...>]  (eiwit.pdb)
           Structure file
 -o      [<.gro/.g96/...>]  (conf.gro)
           Structure file
 -p      [<.top>]           (topol.top)
           Topology file
 -water  <enum>             (select)
           Water model to use: select, none, spc, spce, tip3p, tip4p""")


def generic_command_help(cmd):
    desc = COMMAND_DESCRIPTIONS.get(cmd, "GROMACS command")
    print(f"""SYNOPSIS

gmx {cmd} [<options>]

DESCRIPTION

{wrap(desc)}.

OPTIONS

 -h
           Print help and quit
 -quiet
           Do not print common startup info or quotes
 -version
           Print extended version information and quit
""")


def command_help(cmd):
    if cmd == "mdrun":
        mdrun_help()
    elif cmd == "grompp":
        grompp_help()
    elif cmd == "pdb2gmx":
        pdb2gmx_help()
    else:
        generic_command_help(cmd)


def fatal(program, message, source="src/gromacs/commandline/cmdlineparser.cpp", line=271,
          function="void gmx::CommandLineParser::parse(int*, char**)"):
    print("-------------------------------------------------------")
    print(f"Program:     {program}, version {VERSION}")
    print(f"Source file: {source} (line {line})")
    print(f"Function:    {function}\n")
    print("Error in user input:")
    print(message)
    print("\nFor more information and tips for troubleshooting, please check the GROMACS")
    print("website at https://manual.gromacs.org/current/user-guide/run-time-errors.html")
    print("-------------------------------------------------------")


def parse_common(args):
    quiet = False
    rest = []
    i = 0
    while i < len(args):
        a = args[i]
        if a in ("-quiet", "--quiet"):
            quiet = True
        elif a in ("-noquiet", "--noquiet"):
            quiet = False
        elif a == "-nice" and i + 1 < len(args):
            i += 1
        elif a in ("-backup", "-nobackup", "--backup", "--nobackup", "-copyright", "--copyright"):
            pass
        else:
            rest.append(a)
        i += 1
    return quiet, rest


def unsupported_run(cmd):
    if cmd == "mdrun":
        fatal(f"gmx {cmd}", """Invalid input values
  In option s
    Required option was not provided, and the default file 'topol' does not
    exist or is not accessible.
    The following extensions were tried to complete the file name:
      .tpr""", "src/gromacs/options/options.cpp", 184,
              "void gmx::internal::OptionSectionImpl::finish()")
    elif cmd == "grompp":
        fatal(f"gmx {cmd}", """Invalid input values
  In option f
    Required option was not provided, and the default file 'grompp' does not
    exist or is not accessible.
    The following extensions were tried to complete the file name:
      .mdp""", "src/gromacs/options/options.cpp", 184,
              "void gmx::internal::OptionSectionImpl::finish()")
    else:
        fatal(f"gmx {cmd}", "This clean-room reimplementation provides command-line help, but not the\nfull molecular simulation and analysis engine.")


def main():
    args = sys.argv[1:]
    quiet, rest = parse_common(args)

    if not rest:
        banner(exe_name(), args, quiet)
        common_help()
        return 0

    if rest[0] in ("-version", "--version"):
        banner(exe_name(), args, quiet, quote=False)
        version()
        return 0

    if rest[0] == "--help":
        banner(exe_name(), args, quiet, quote=False)
        fatal(exe_name(), "Invalid command-line options\n    Unknown command-line option --help")
        return 1

    if rest[0] in ("-h", "-help", "help"):
        if rest[0] == "help" and len(rest) > 1:
            topic = rest[1]
            banner("gmx help", args, quiet, quote=(topic != "commands"))
            if topic == "commands":
                commands_help()
            elif topic == "selections":
                selections_help()
            elif topic in COMMAND_NAMES:
                command_help(topic)
            else:
                fatal("gmx help", f"'{topic}' is not a GROMACS command or help topic.")
                return 1
        else:
            banner("gmx help" if rest[0] == "help" else exe_name(), args, quiet)
            common_help()
        return 0

    cmd = rest[0]
    if cmd not in COMMAND_NAMES:
        banner(exe_name(), args, quiet, quote=False)
        fatal(exe_name(), f"'{cmd}' is not a GROMACS command.",
              "src/gromacs/commandline/cmdlinemodulemanager.cpp", 389,
              "gmx::ICommandLineModule* gmx::CommandLineModuleManager::Impl::processCommonOptions(gmx::CommandLineCommonOptionsHolder*, int*, char***)")
        return 1

    if any(a in ("-h", "-help", "--help") for a in rest[1:]):
        banner(f"gmx {cmd}", args, quiet, quote=False)
        command_help(cmd)
        return 0

    if any(a in ("-version", "--version") for a in rest[1:]):
        banner(f"gmx {cmd}", args, quiet, quote=False)
        version()
        return 0

    banner(f"gmx {cmd}", args, quiet, quote=False)
    unsupported_run(cmd)
    return 1


if __name__ == "__main__":
    sys.exit(main())
