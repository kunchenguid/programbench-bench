#define _XOPEN_SOURCE 700

#include <ctype.h>
#include <getopt.h>
#include <locale.h>
#include <ncurses.h>
#include <signal.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <unistd.h>

typedef struct {
    int y;
    int len;
    int speed;
    int tick;
} Stream;

static volatile sig_atomic_t stop_requested = 0;

static const char *usage_text =
" Usage: cmatrix -[abBcfhlsmVxk] [-u delay] [-C color] [-t tty] [-M message]\n"
" -a: Asynchronous scroll\n"
" -b: Bold characters on\n"
" -B: All bold characters (overrides -b)\n"
" -c: Use Japanese characters as seen in the original matrix. Requires appropriate fonts\n"
" -f: Force the linux $TERM type to be on\n"
" -l: Linux mode (uses matrix console font)\n"
" -L: Lock mode (can be closed from another terminal)\n"
" -o: Use old-style scrolling\n"
" -h: Print usage and exit\n"
" -n: No bold characters (overrides -b and -B, default)\n"
" -s: \"Screensaver\" mode, exits on first keystroke\n"
" -x: X window mode, use if your xterm is using mtx.pcf\n"
" -V: Print version information and exit\n"
" -M [message]: Prints your message in the center of the screen. Overrides -L's default message.\n"
" -u delay (0 - 10, default 4): Screen update delay\n"
" -C [color]: Use this color for matrix (default green)\n"
" -r: rainbow mode\n"
" -m: lambda mode\n"
" -k: Characters change while scrolling. (Works without -o opt.)\n"
" -t [tty]: Set tty to use\n";

static void print_usage(void) {
    fputs(usage_text, stdout);
}

static void print_version(void) {
    puts(" CMatrix version 2.0 (compiled 19:59:42, Apr 17 2026)");
    puts("Email: abishekvashok@gmail.com");
    puts("Web: https://github.com/abishekvashok/cmatrix");
}

static void on_signal(int sig) {
    (void)sig;
    stop_requested = 1;
}

static int color_from_name(const char *name) {
    char buf[32];
    size_t n = strlen(name);
    if (n >= sizeof(buf)) {
        return -1;
    }
    for (size_t i = 0; i <= n; i++) {
        buf[i] = (char)tolower((unsigned char)name[i]);
    }
    if (strcmp(buf, "green") == 0) return COLOR_GREEN;
    if (strcmp(buf, "red") == 0) return COLOR_RED;
    if (strcmp(buf, "blue") == 0) return COLOR_BLUE;
    if (strcmp(buf, "white") == 0) return COLOR_WHITE;
    if (strcmp(buf, "yellow") == 0) return COLOR_YELLOW;
    if (strcmp(buf, "cyan") == 0) return COLOR_CYAN;
    if (strcmp(buf, "magenta") == 0) return COLOR_MAGENTA;
    if (strcmp(buf, "black") == 0) return COLOR_BLACK;
    return -1;
}

static char matrix_char(bool lambda_mode) {
    static const char chars[] =
        "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz"
        "!@#$%^&*()_+-=[]{};:',.<>/?\\|`~";
    if (lambda_mode) {
        return 'L';
    }
    return chars[rand() % (int)(sizeof(chars) - 1)];
}

static void init_stream(Stream *s, int rows, bool async) {
    s->y = -(rand() % (rows + 1));
    s->len = 3 + rand() % (rows > 3 ? rows : 4);
    s->speed = async ? (1 + rand() % 4) : 1;
    s->tick = rand() % s->speed;
}

static int pair_for_color(int fg) {
    switch (fg) {
        case COLOR_RED: return 2;
        case COLOR_BLUE: return 3;
        case COLOR_WHITE: return 4;
        case COLOR_YELLOW: return 5;
        case COLOR_CYAN: return 6;
        case COLOR_MAGENTA: return 7;
        case COLOR_BLACK: return 8;
        case COLOR_GREEN:
        default: return 1;
    }
}

static void setup_colors(void) {
    if (!has_colors()) {
        return;
    }
    start_color();
    use_default_colors();
    init_pair(1, COLOR_GREEN, -1);
    init_pair(2, COLOR_RED, -1);
    init_pair(3, COLOR_BLUE, -1);
    init_pair(4, COLOR_WHITE, -1);
    init_pair(5, COLOR_YELLOW, -1);
    init_pair(6, COLOR_CYAN, -1);
    init_pair(7, COLOR_MAGENTA, -1);
    init_pair(8, COLOR_BLACK, -1);
}

static void draw_message(const char *message, bool lock_mode) {
    const char *text = message;
    if (!text && lock_mode) {
        text = "Computer locked.";
    }
    if (!text || !*text) {
        return;
    }
    int rows, cols;
    getmaxyx(stdscr, rows, cols);
    int len = (int)strlen(text);
    int x = (cols - len) / 2;
    if (x < 0) {
        x = 0;
        len = cols;
    }
    attron(A_BOLD);
    mvaddnstr(rows / 2, x, text, len);
    attroff(A_BOLD);
}

static void run_matrix(bool async, bool bold, bool all_bold, bool no_bold,
                       bool screensaver, bool rainbow, bool lambda_mode,
                       bool changing, bool shadow_only, bool lock_mode,
                       int delay, int fg, const char *message) {
    (void)changing;
    setlocale(LC_ALL, "");
    srand((unsigned int)(time(NULL) ^ getpid()));

    initscr();
    cbreak();
    noecho();
    nodelay(stdscr, TRUE);
    keypad(stdscr, TRUE);
    curs_set(0);
    setup_colors();
    clear();

    int rows, cols;
    getmaxyx(stdscr, rows, cols);
    if (cols < 1) cols = 1;
    Stream *streams = calloc((size_t)cols, sizeof(Stream));
    if (!streams) {
        endwin();
        fprintf(stderr, "Out of memory\n");
        exit(1);
    }
    for (int x = 0; x < cols; x++) {
        init_stream(&streams[x], rows, async);
    }

    int base_pair = pair_for_color(fg);
    int frame = 0;
    while (!stop_requested) {
        int ch = getch();
        if (ch != ERR) {
            if (screensaver) {
                break;
            }
            if ((ch == 'q' || ch == 'Q') && !lock_mode) break;
            if (ch == 'a') async = !async;
            if (ch == 'b') { bold = true; all_bold = false; no_bold = false; }
            if (ch == 'B') { all_bold = true; no_bold = false; }
            if (ch == 'n') { bold = false; all_bold = false; no_bold = true; }
            if (ch >= '0' && ch <= '9') delay = ch - '0';
            if (ch == '!') base_pair = pair_for_color(COLOR_RED);
            if (ch == '@') base_pair = pair_for_color(COLOR_GREEN);
            if (ch == '#') base_pair = pair_for_color(COLOR_YELLOW);
            if (ch == '$') base_pair = pair_for_color(COLOR_BLUE);
            if (ch == '%') base_pair = pair_for_color(COLOR_MAGENTA);
            if (ch == '^') base_pair = pair_for_color(COLOR_CYAN);
            if (ch == '&') base_pair = pair_for_color(COLOR_WHITE);
            if (ch == ')') base_pair = pair_for_color(COLOR_BLACK);
        }

        getmaxyx(stdscr, rows, cols);
        erase();
        for (int x = 0; x < cols; x += 2) {
            Stream *s = &streams[x];
            if (++s->tick >= s->speed) {
                s->tick = 0;
                s->y++;
            }
            if (s->y - s->len > rows) {
                init_stream(s, rows, async);
            }
            for (int i = 0; i < s->len; i++) {
                int y = s->y - i;
                if (y < 0 || y >= rows) continue;
                int pair = rainbow ? 1 + ((x + y + frame) % 7) : base_pair;
                int attr = has_colors() ? COLOR_PAIR(pair) : 0;
                if (!shadow_only && i == 0) attr |= A_BOLD;
                if (all_bold || (bold && (rand() % 5 == 0))) attr |= A_BOLD;
                if (no_bold || shadow_only) attr &= ~A_BOLD;
                attron(attr);
                mvaddch(y, x, shadow_only ? ' ' : matrix_char(lambda_mode));
                attroff(attr);
            }
        }
        draw_message(message, lock_mode);
        refresh();
        frame++;
        napms(10 + delay * 10);
    }

    free(streams);
    curs_set(1);
    clear();
    refresh();
    endwin();
}

int main(int argc, char **argv) {
    bool async = false, bold = false, all_bold = false, no_bold = true;
    bool screensaver = false, rainbow = false, lambda_mode = false;
    bool changing = false, shadow_only = false, lock_mode = false;
    int delay = 4;
    int fg = COLOR_GREEN;
    const char *message = NULL;

    opterr = 0;
    int opt;
    while ((opt = getopt(argc, argv, "abBcfhlLo?nsmxVrkM:u:C:t:")) != -1) {
        switch (opt) {
            case 'a': async = true; break;
            case 'b': bold = true; no_bold = false; break;
            case 'B': all_bold = true; no_bold = false; break;
            case 'c': shadow_only = true; break;
            case 'f': break;
            case 'l': break;
            case 'L': lock_mode = true; break;
            case 'o': break;
            case 'h':
            case '?':
                print_usage();
                return 0;
            case 'n': bold = false; all_bold = false; no_bold = true; break;
            case 's': screensaver = true; break;
            case 'm': lambda_mode = true; break;
            case 'x': break;
            case 'V': print_version(); return 0;
            case 'r': rainbow = true; break;
            case 'k': changing = true; break;
            case 'M': message = optarg; break;
            case 'u': delay = atoi(optarg); break;
            case 'C': {
                int c = color_from_name(optarg);
                if (c < 0) {
                    puts(" Invalid color selection");
                    puts(" Valid colors are green, red, blue, white, yellow, cyan, magenta and black.");
                    return 0;
                }
                fg = c;
                break;
            }
            case 't':
                break;
            default:
                print_usage();
                return 0;
        }
    }

    signal(SIGINT, on_signal);
    signal(SIGTERM, on_signal);
    run_matrix(async, bold, all_bold, no_bold, screensaver, rainbow,
               lambda_mode, changing, shadow_only, lock_mode, delay, fg, message);
    return 0;
}
