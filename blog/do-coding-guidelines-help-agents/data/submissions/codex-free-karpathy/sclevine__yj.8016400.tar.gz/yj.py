#!/usr/bin/env python3
import json
import math
import re
import sys


HELP = """Usage: ./executable [-][ytjcrneikhv]

Convert between YAML, TOML, JSON, and HCL.
Preserves map order.

-x[x]  Convert using stdin. Valid options:
          -yj, -y = YAML to JSON (default)
          -yy     = YAML to YAML
          -yt     = YAML to TOML
          -yc     = YAML to HCL
          -tj, -t = TOML to JSON
          -ty     = TOML to YAML
          -tt     = TOML to TOML
          -tc     = TOML to HCL
          -jj     = JSON to JSON
          -jy, -r = JSON to YAML
          -jt     = JSON to TOML
          -jc     = JSON to HCL
          -cy     = HCL to YAML
          -ct     = HCL to TOML
          -cj, -c = HCL to JSON
          -cc     = HCL to HCL
-n     Do not covert inf, -inf, and NaN to/from strings (YAML or TOML only)
-e     Escape HTML (JSON out only)
-i     Indent output (JSON or TOML out only)
-k     Attempt to parse keys as objects or numeric types (YAML out only)
-h     Show this help message
-v     Show version
"""


def split_top(s, sep=","):
    out, cur, depth, quote, esc = [], [], 0, None, False
    for ch in s:
        if quote:
            cur.append(ch)
            if esc:
                esc = False
            elif ch == "\\":
                esc = True
            elif ch == quote:
                quote = None
        else:
            if ch in "'\"":
                quote = ch
                cur.append(ch)
            elif ch in "[{(":
                depth += 1
                cur.append(ch)
            elif ch in "]})":
                depth -= 1
                cur.append(ch)
            elif ch == sep and depth == 0:
                out.append("".join(cur).strip())
                cur = []
            else:
                cur.append(ch)
    out.append("".join(cur).strip())
    return [x for x in out if x != ""]


def unquote(s):
    s = s.strip()
    if len(s) >= 2 and s[0] == s[-1] and s[0] in "'\"":
        if s[0] == '"':
            try:
                return json.loads(s)
            except Exception:
                return s[1:-1]
        return s[1:-1].replace("''", "'")
    return s


def parse_scalar(s, no_special=False):
    s = s.strip()
    low = s.lower()
    if s == "":
        return ""
    if len(s) >= 2 and s[0] == s[-1] and s[0] in "'\"":
        return unquote(s)
    if low in ("null", "~"):
        return None
    if low == "true":
        return True
    if low == "false":
        return False
    if low in (".inf", "+.inf", "inf", "+inf"):
        return sys.float_info.max if no_special else "Infinity"
    if low in ("-.inf", "-inf"):
        return -sys.float_info.max if no_special else "-Infinity"
    if low in (".nan", "nan"):
        return None if no_special else "NaN"
    if s.startswith("[") and s.endswith("]"):
        body = s[1:-1].strip()
        return [] if not body else [parse_scalar(x, no_special) for x in split_top(body)]
    if s.startswith("{") and s.endswith("}"):
        body = s[1:-1].strip()
        d = {}
        if body:
            for part in split_top(body):
                k, v = split_key_value(part, ":")
                d[unquote(k)] = parse_scalar(v, no_special)
        return d
    num = s.replace("_", "")
    try:
        if re.match(r"^[+-]?(0|[1-9][0-9]*|0[0-9]+)$", num):
            return int(num, 10)
        if re.match(r"^[+-]?([0-9]+\.[0-9]*|[0-9]*\.[0-9]+)([eE][+-]?[0-9]+)?$", num) or re.match(r"^[+-]?[0-9]+[eE][+-]?[0-9]+$", num):
            return float(num)
    except Exception:
        pass
    return s


def split_key_value(line, sep=":"):
    quote, esc, depth = None, False, 0
    for i, ch in enumerate(line):
        if quote:
            if esc:
                esc = False
            elif ch == "\\":
                esc = True
            elif ch == quote:
                quote = None
        else:
            if ch in "'\"":
                quote = ch
            elif ch in "[{(":
                depth += 1
            elif ch in "]})":
                depth -= 1
            elif ch == sep and depth == 0:
                return line[:i].strip(), line[i + 1 :].strip()
    raise ValueError("missing separator")


def strip_comment(line):
    quote, esc = None, False
    for i, ch in enumerate(line):
        if quote:
            if esc:
                esc = False
            elif ch == "\\":
                esc = True
            elif ch == quote:
                quote = None
        elif ch in "'\"":
            quote = ch
        elif ch == "#":
            return line[:i]
    return line


def yaml_lines(text):
    rows = []
    for raw in text.splitlines():
        line = strip_comment(raw).rstrip()
        if not line.strip() or line.strip() == "---" or line.strip() == "...":
            continue
        rows.append((len(line) - len(line.lstrip(" ")), line.lstrip(" ")))
    return rows


def parse_yaml(text, no_special=False):
    rows = yaml_lines(text)
    if not rows:
        return None

    def parse_block(i, indent):
        if i >= len(rows):
            return None, i
        if rows[i][1].startswith("- ") and rows[i][0] == indent:
            arr = []
            while i < len(rows) and rows[i][0] == indent and rows[i][1].startswith("- "):
                item = rows[i][1][2:].strip()
                if item == "":
                    val, i = parse_block(i + 1, indent + 2)
                    arr.append(val)
                elif ":" in item and not item.startswith(("{", "[")):
                    try:
                        k, v = split_key_value(item, ":")
                        obj = {unquote(k): parse_scalar(v, no_special) if v else None}
                        i += 1
                        while i < len(rows) and rows[i][0] > indent:
                            extra, i = parse_block(i, rows[i][0])
                            if isinstance(extra, dict):
                                obj.update(extra)
                            else:
                                break
                        arr.append(obj)
                    except Exception:
                        arr.append(parse_scalar(item, no_special))
                        i += 1
                else:
                    arr.append(parse_scalar(item, no_special))
                    i += 1
            return arr, i
        obj = {}
        while i < len(rows) and rows[i][0] == indent and not rows[i][1].startswith("- "):
            k, v = split_key_value(rows[i][1], ":")
            key = unquote(k)
            if v == "":
                val, i = parse_block(i + 1, indent + 2)
            else:
                val = parse_scalar(v, no_special)
                i += 1
            obj[key] = val
        return obj, i

    val, _ = parse_block(0, rows[0][0])
    return val


def toml_value(s, no_special=False):
    s = s.strip()
    low = s.lower()
    if low in ("inf", "+inf"):
        return sys.float_info.max if no_special else "Infinity"
    if low == "-inf":
        return -sys.float_info.max if no_special else "-Infinity"
    if low == "nan":
        return None if no_special else "NaN"
    return parse_scalar(s, no_special)


def parse_toml(text, no_special=False):
    root, cur = {}, None
    for raw in text.splitlines():
        line = strip_comment(raw).strip()
        if not line:
            continue
        if line.startswith("[[") and line.endswith("]]"):
            name = unquote(line[2:-2].strip())
            arr = root.setdefault(name, [])
            obj = {}
            arr.append(obj)
            cur = obj
        elif line.startswith("[") and line.endswith("]"):
            path = [unquote(p.strip()) for p in line[1:-1].split(".")]
            cur = root
            for p in path:
                cur = cur.setdefault(p, {})
        elif "=" in line:
            k, v = split_key_value(line, "=")
            target = root if cur is None else cur
            target[unquote(k)] = toml_value(v, no_special)
    return root


def tokenize_hcl(s):
    toks, i = [], 0
    while i < len(s):
        c = s[i]
        if c.isspace():
            i += 1
        elif c == "#":
            while i < len(s) and s[i] != "\n":
                i += 1
        elif c in "{}[]=,":
            toks.append(c)
            i += 1
        elif c in "'\"":
            q, j, esc = c, i + 1, False
            while j < len(s):
                if esc:
                    esc = False
                elif s[j] == "\\":
                    esc = True
                elif s[j] == q:
                    j += 1
                    break
                j += 1
            toks.append(s[i:j])
            i = j
        else:
            j = i
            while j < len(s) and not s[j].isspace() and s[j] not in "{}[]=,":
                j += 1
            toks.append(s[i:j])
            i = j
    return toks


def parse_hcl(text):
    toks, pos = tokenize_hcl(text), 0

    def val():
        nonlocal pos
        if toks[pos] == "[":
            pos += 1
            arr = []
            while pos < len(toks) and toks[pos] != "]":
                if toks[pos] == ",":
                    pos += 1
                    continue
                arr.append(val())
            pos += 1
            return arr
        if toks[pos] == "{":
            pos += 1
            obj = obj_body("}")
            pos += 1
            return obj
        tok = toks[pos]
        pos += 1
        return parse_scalar(tok)

    def obj_body(end=None):
        nonlocal pos
        obj = {}
        while pos < len(toks) and (end is None or toks[pos] != end):
            if toks[pos] == ",":
                pos += 1
                continue
            key = unquote(toks[pos])
            pos += 1
            if pos < len(toks) and toks[pos] == "=":
                pos += 1
                obj[key] = val()
            elif pos < len(toks) and toks[pos] == "{":
                pos += 1
                block = obj_body("}")
                pos += 1
                obj.setdefault(key, []).append(block)
            else:
                obj[key] = None
        return obj

    return obj_body()


def json_dumps(v, indent=False, escape_html=False):
    s = json.dumps(v, ensure_ascii=False, separators=(",", ": ") if indent else (",", ":"), indent=2 if indent else None, allow_nan=False)
    if escape_html:
        s = s.replace("<", "\\u003c").replace(">", "\\u003e").replace("&", "\\u0026")
    return s + "\n"


def scalar_yaml(v, key=False, parse_keys=False):
    if v is None:
        return "null"
    if v is True:
        return "true"
    if v is False:
        return "false"
    if isinstance(v, (int, float)):
        return str(v)
    s = str(v)
    if key and s and s[0] in "[{":
        return "'" + s.replace("'", "''") + "'"
    if key and parse_keys:
        return s
    if s == "":
        return '""'
    low = s.lower()
    need = (
        s[0].isspace()
        or s[-1].isspace()
        or s[0] in "[]{}&*!|>'\"%@`"
        or ": " in s
        or low in ("true", "false", "null", "~", "yes", "no")
        or (key and re.match(r"^[+-]?([0-9]+|[0-9]*\.[0-9]+)$", s))
    )
    if need:
        return json.dumps(s)
    return s


def yaml_emit(v, indent=0, parse_keys=False):
    sp = " " * indent
    if isinstance(v, dict):
        out = []
        for k, val in v.items():
            kk = scalar_yaml(k, True, parse_keys)
            if isinstance(val, (dict, list)):
                if isinstance(val, list) and val and all(not isinstance(x, (dict, list)) for x in val) and False:
                    out.append(f"{sp}{kk}: {val}")
                else:
                    out.append(f"{sp}{kk}:")
                    out.append(yaml_emit(val, indent + 2, parse_keys).rstrip("\n"))
            else:
                out.append(f"{sp}{kk}: {scalar_yaml(val)}")
        return "\n".join(out) + "\n"
    if isinstance(v, list):
        out = []
        for item in v:
            if isinstance(item, dict):
                if len(item) == 1 and all(not isinstance(x, (dict, list)) for x in item.values()):
                    k, val = next(iter(item.items()))
                    vv = json.dumps(val, ensure_ascii=False) if isinstance(val, str) else scalar_yaml(val)
                    out.append(f"{sp}- {scalar_yaml(k, True, parse_keys)}: {vv}")
                else:
                    out.append(f"{sp}-")
                    out.append(yaml_emit(item, indent + 2, parse_keys).rstrip("\n"))
            elif isinstance(item, list):
                out.append(f"{sp}-")
                out.append(yaml_emit(item, indent + 2, parse_keys).rstrip("\n"))
            else:
                out.append(f"{sp}- {scalar_yaml(item)}")
        return "\n".join(out) + "\n"
    return sp + scalar_yaml(v) + "\n"


def toml_scalar(v):
    if v is True:
        return "true"
    if v is False:
        return "false"
    if isinstance(v, (int, float)):
        return str(v)
    return json.dumps("" if v is None else str(v), ensure_ascii=False)


def toml_inline(v):
    if isinstance(v, list):
        return "[" + ", ".join(toml_inline(x) for x in v) + "]"
    if isinstance(v, dict):
        return "{ " + ", ".join(f"{k} = {toml_inline(x)}" for k, x in v.items()) + " }"
    return toml_scalar(v)


def toml_emit(v, indent=False):
    if not isinstance(v, dict):
        return toml_inline(v) + "\n"
    lines = []
    tables = []
    for k, val in v.items():
        if isinstance(val, dict) or (isinstance(val, list) and val and all(isinstance(x, dict) for x in val)):
            tables.append((k, val))
        elif val is not None:
            lines.append(f"{k} = {toml_inline(val)}")
    for k, val in tables:
        if lines:
            lines.append("")
        if isinstance(val, dict):
            lines.append(f"[{k}]")
            pad = "  " if indent else ""
            for kk, vv in val.items():
                if not isinstance(vv, (dict, list)) or (isinstance(vv, list) and not (vv and all(isinstance(x, dict) for x in vv))):
                    lines.append(f"{pad}{kk} = {toml_inline(vv)}")
        else:
            for obj in val:
                lines.append(f"[[{k}]]")
                pad = "  " if indent else ""
                for kk, vv in obj.items():
                    lines.append(f"{pad}{kk} = {toml_inline(vv)}")
                lines.append("")
            if lines and lines[-1] == "":
                lines.pop()
    return "\n".join(lines) + "\n"


def hcl_scalar(v):
    if v is True:
        return "true"
    if v is False:
        return "false"
    if v is None:
        return "null"
    if isinstance(v, (int, float)):
        return str(v)
    return json.dumps(str(v), ensure_ascii=False)


def hcl_inline(v):
    if isinstance(v, list) and all(not isinstance(x, dict) for x in v):
        return "[" + ", ".join(hcl_inline(x) for x in v) + "]"
    if isinstance(v, dict):
        inner = []
        for k, val in v.items():
            inner.append(f'  {json.dumps(str(k))} = {hcl_inline(val)}')
        return "{\n" + "\n\n".join(inner) + "\n}"
    return hcl_scalar(v)


def hcl_emit(v):
    if not isinstance(v, dict):
        return hcl_inline(v) + "\n"
    out = []
    for k, val in v.items():
        qk = json.dumps(str(k))
        if isinstance(val, list) and val and all(isinstance(x, dict) for x in val):
            for obj in val:
                out.append(f"{qk} = " + hcl_inline(obj))
        else:
            out.append(f"{qk} = {hcl_inline(val)}")
    return "\n\n".join(out) + ("\n" if out else "")


def parse_flags(argv):
    valid = set("ytjcrneikhv-")
    chars = []
    for arg in argv[1:]:
        if arg.startswith("-"):
            chars.extend(list(arg[1:]))
        else:
            chars.extend(list(arg))
    bad = [c for c in chars if c not in valid]
    return chars, bad


def main():
    chars, bad = parse_flags(sys.argv)
    if "h" in chars:
        print(HELP)
    if "v" in chars:
        print("v0.0.0")
    if bad:
        print(f"Error: invalid flags specified: {' '.join(bad)}", file=sys.stderr)
        return 1
    if "h" in chars or "v" in chars:
        return 0

    conv = "".join(c for c in chars if c in "ytjc")
    if "r" in chars:
        conv = "jy"
    elif conv == "t":
        conv = "tj"
    elif conv == "c":
        conv = "cj"
    elif conv == "y" or conv == "":
        conv = "yj"
    elif len(conv) == 1:
        conv += "j"
    else:
        conv = conv[:2]
    src, dst = conv[0], conv[1]
    text = sys.stdin.read()
    no_special = "n" in chars
    try:
        if src == "j":
            data = json.loads(text)
        elif src == "y":
            data = parse_yaml(text, no_special)
        elif src == "t":
            data = parse_toml(text, no_special)
        else:
            data = parse_hcl(text)
    except Exception as e:
        name = {"j": "JSON", "y": "YAML", "t": "TOML", "c": "HCL"}[src]
        print(f"Error parsing {name}: {e}", file=sys.stderr)
        return 1

    if dst == "j":
        sys.stdout.write(json_dumps(data, "i" in chars, "e" in chars))
    elif dst == "y":
        sys.stdout.write(yaml_emit(data, parse_keys="k" in chars))
    elif dst == "t":
        sys.stdout.write(toml_emit(data, "i" in chars))
    else:
        sys.stdout.write(hcl_emit(data))
    return 0


if __name__ == "__main__":
    sys.exit(main())
