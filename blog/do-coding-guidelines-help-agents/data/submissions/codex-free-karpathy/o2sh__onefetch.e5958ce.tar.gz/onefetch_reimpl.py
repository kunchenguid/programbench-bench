#!/usr/bin/env python3
import json
import os
import re
import subprocess
import sys
import time
from collections import Counter, defaultdict

VERSION = "onefetch 2.25.0"

FIELDS = [
    "project", "description", "head", "pending", "version", "created",
    "languages", "dependencies", "authors", "last-change", "contributors",
    "url", "commits", "churn", "lines-of-code", "size", "license",
]

LANGS = [
    "ABNF", "ABAP", "Ada", "Agda", "Arduino C++", "Assembly", "ATS",
    "AutoHotKey", "BASH", "C", "CMake", "C#", "Ceylon", "Clojure",
    "CoffeeScript", "ColdFusion", "Coq", "C++", "Crystal", "CSS", "CUDA",
    "D", "Dart", "Dockerfile", "Emacs Lisp", "Elixir", "Elm", "Emojicode",
    "Erlang", "F#", "Fish", "Forth", "FORTRAN Legacy", "FORTRAN Modern",
    "GDScript", "GLSL", "Go", "GraphQL", "Groovy", "Haskell", "Haxe",
    "HCL", "HLSL", "HolyC", "HTML", "Idris", "Java", "JavaScript", "JSON",
    "Jsonnet", "JSX", "Julia", "Jupyter Notebooks", "Kotlin", "LLVM", "Lean",
    "Common Lisp", "Lua", "Makefile", "Markdown", "Modelica", "Nim", "Nix",
    "OCaml", "Objective-C", "Odin", "OpenSCAD", "Org", "Oz", "Pascal",
    "Perl", "PHP", "PowerShell", "Processing", "Prolog", "Protocol Buffers",
    "PureScript", "Python", "QML", "R", "Racket", "Ruby", "Rust", "Scala",
    "Shell", "Solidity", "SQL", "Svelte", "Swift", "TOML", "TypeScript",
    "Vim script", "Vue", "XML", "YAML", "Zig",
]

PM = ["Npm", "Cargo"]

EXT_LANG = {
    ".py": ("Python", "programming"), ".rs": ("Rust", "programming"),
    ".c": ("C", "programming"), ".h": ("C", "programming"),
    ".cpp": ("C++", "programming"), ".cc": ("C++", "programming"),
    ".hpp": ("C++", "programming"), ".go": ("Go", "programming"),
    ".java": ("Java", "programming"), ".js": ("JavaScript", "programming"),
    ".jsx": ("JSX", "programming"), ".ts": ("TypeScript", "programming"),
    ".tsx": ("TypeScript", "programming"), ".rb": ("Ruby", "programming"),
    ".php": ("PHP", "programming"), ".swift": ("Swift", "programming"),
    ".kt": ("Kotlin", "programming"), ".kts": ("Kotlin", "programming"),
    ".scala": ("Scala", "programming"), ".sh": ("Shell", "programming"),
    ".bash": ("BASH", "programming"), ".zsh": ("Shell", "programming"),
    ".fish": ("Fish", "programming"), ".lua": ("Lua", "programming"),
    ".pl": ("Perl", "programming"), ".r": ("R", "programming"),
    ".R": ("R", "programming"), ".dart": ("Dart", "programming"),
    ".ex": ("Elixir", "programming"), ".exs": ("Elixir", "programming"),
    ".erl": ("Erlang", "programming"), ".hrl": ("Erlang", "programming"),
    ".hs": ("Haskell", "programming"), ".ml": ("OCaml", "programming"),
    ".mli": ("OCaml", "programming"), ".fs": ("F#", "programming"),
    ".fsx": ("F#", "programming"), ".cs": ("C#", "programming"),
    ".zig": ("Zig", "programming"), ".nim": ("Nim", "programming"),
    ".jl": ("Julia", "programming"), ".clj": ("Clojure", "programming"),
    ".cljs": ("Clojure", "programming"), ".vue": ("Vue", "programming"),
    ".svelte": ("Svelte", "programming"), ".html": ("HTML", "markup"),
    ".htm": ("HTML", "markup"), ".css": ("CSS", "programming"),
    ".scss": ("CSS", "programming"), ".less": ("CSS", "programming"),
    ".md": ("Markdown", "prose"), ".markdown": ("Markdown", "prose"),
    ".xml": ("XML", "markup"), ".yaml": ("YAML", "data"),
    ".yml": ("YAML", "data"), ".json": ("JSON", "data"),
    ".toml": ("TOML", "data"), ".sql": ("SQL", "programming"),
    ".proto": ("Protocol Buffers", "programming"), ".graphql": ("GraphQL", "data"),
    ".gql": ("GraphQL", "data"), ".nix": ("Nix", "programming"),
    ".cmake": ("CMake", "programming"), ".ps1": ("PowerShell", "programming"),
}

HELP_LONG = """Command-line Git information tool

Usage: executable [OPTIONS] [INPUT]

Arguments:
  [INPUT]
          Run as if onefetch was started in <input> instead of the current working directory

Options:
  -h, --help
          Print help (see a summary with '-h')

  -V, --version
          Print version

INFO:
  -d, --disabled-fields <FIELD>...
          Allows you to disable FIELD(s) from appearing in the output

      --no-title
          Hides the title

      --number-of-authors <NUM>
          Maximum NUM of authors to be shown
          
          [default: 3]

      --number-of-languages <NUM>
          Maximum NUM of languages to be shown
          
          [default: 6]

      --number-of-file-churns <NUM>
          Maximum NUM of file churns to be shown
          
          [default: 3]

      --churn-pool-size <NUM>
          Minimum NUM of commits from HEAD used to compute the churn summary
          
          By default, the actual value is non-deterministic due to time-based computation and will
          be displayed under the info title "Churn (NUM)"

  -e, --exclude <EXCLUDE>...
          Ignore all files & directories matching EXCLUDE

      --no-bots[=<REGEX>]
          Exclude [bot] commits. Use <REGEX> to override the default pattern

      --no-merges
          Ignores merge commits

  -E, --email
          Show the email address of each author

      --http-url
          Display repository URL as HTTP

      --hide-token
          Hide token in repository URL

      --include-hidden
          Count hidden files and directories

  -T, --type <TYPE>...
          Filters output by language type
          
          [default: programming markup]
          [possible values: programming, markup, prose, data]

TEXT FORMATTING:
  -t, --text-colors <X>...
          Changes the text colors (X X X...)

  -z, --iso-time
          Use ISO 8601 formatted timestamps

      --number-separator <SEPARATOR>
          Which thousands SEPARATOR to use
          
          [default: plain]
          [possible values: plain, comma, space, underscore]

      --no-bold
          Turns off bold formatting

ASCII:
      --ascii-input <STRING>
          Takes a non-empty STRING as input to replace the ASCII logo

  -c, --ascii-colors <X>...
          Colors (X X X...) to print the ascii art

  -a, --ascii-language <LANGUAGE>
          Which LANGUAGE's ascii art to print

      --true-color <WHEN>
          Specify when to use true color
          
          If set to auto: true color will be enabled if supported by the terminal
          
          [default: auto]
          [possible values: auto, never, always]

IMAGE:
  -i, --image <IMAGE>
          Path to the IMAGE file

      --image-protocol <PROTOCOL>
          Which image PROTOCOL to use
          
          [possible values: kitty, sixel, iterm]

      --color-resolution <VALUE>
          VALUE of color resolution to use with SIXEL backend
          
          [default: 64]
          [possible values: 16, 32, 64, 128, 256]

VISUALS:
      --no-color-palette
          Hides the color palette

      --no-art
          Hides the ascii art or image if provided

      --nerd-fonts
          Use Nerd Font icons
          
          Replaces language chips with Nerd Font icons

DEVELOPER:
  -o, --output <FORMAT>
          Outputs Onefetch in a specific format
          
          [possible values: json, yaml]

      --generate <SHELL>
          If provided, outputs the completion file for given SHELL
          
          [possible values: bash, elvish, fish, powershell, zsh]

OTHER:
  -l, --languages
          Prints out supported languages

  -p, --package-managers
          Prints out supported package managers
"""

HELP_SHORT = """Command-line Git information tool

Usage: executable [OPTIONS] [INPUT]

Arguments:
  [INPUT]  Run as if onefetch was started in <input> instead of the current working directory

Options:
  -h, --help     Print help (see more with '--help')
  -V, --version  Print version
"""

def run(cmd, cwd, check=False):
    p = subprocess.run(cmd, cwd=cwd, text=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    if check and p.returncode != 0:
        raise RuntimeError(p.stderr.strip() or p.stdout.strip())
    return p.stdout.strip()

def git(cwd, args, check=False):
    return run(["git"] + args, cwd, check)

def die(msg, code=1):
    print(msg, file=sys.stderr)
    sys.exit(code)

def parse(argv):
    opts = {
        "disabled": set(), "exclude": [], "types": ["programming", "markup"],
        "num_authors": 3, "num_langs": 6, "num_churn": 3, "churn_pool": None,
        "email": False, "no_merges": False, "no_bots": False, "bot_re": r"\[bot\]|bot$",
        "include_hidden": False, "output": None, "no_title": False, "http_url": False,
        "hide_token": False, "iso_time": False, "number_separator": "plain",
        "generate": None, "path": None, "languages": False, "package_managers": False,
    }
    i = 0
    while i < len(argv):
        a = argv[i]
        if a in ("-h", "--help"):
            print(HELP_SHORT if a == "-h" else HELP_LONG, end="" if a == "--help" else "\n")
            sys.exit(0)
        if a in ("-V", "--version"):
            print(VERSION); sys.exit(0)
        if a in ("-l", "--languages"):
            opts["languages"] = True; i += 1; continue
        if a in ("-p", "--package-managers"):
            opts["package_managers"] = True; i += 1; continue
        if a in ("-o", "--output"):
            i += 1
            if i >= len(argv): die("error: a value is required for '--output <FORMAT>'")
            if argv[i] not in ("json", "yaml"): die(f"error: invalid value '{argv[i]}' for '--output <FORMAT>'")
            opts["output"] = argv[i]; i += 1; continue
        if a == "--generate":
            i += 1
            if i >= len(argv): die("error: a value is required for '--generate <SHELL>'")
            opts["generate"] = argv[i]; i += 1; continue
        if a in ("-d", "--disabled-fields"):
            i += 1
            while i < len(argv) and argv[i] in FIELDS:
                opts["disabled"].add(argv[i]); i += 1
            continue
        if a in ("-e", "--exclude"):
            i += 1
            while i < len(argv) and not argv[i].startswith("-"):
                opts["exclude"].append(argv[i]); i += 1
            continue
        if a in ("-T", "--type"):
            vals = []
            i += 1
            while i < len(argv) and argv[i] in ("programming", "markup", "prose", "data"):
                vals.append(argv[i]); i += 1
            if vals: opts["types"] = vals
            continue
        if a in ("--number-of-authors", "--number-of-languages", "--number-of-file-churns", "--churn-pool-size"):
            key = {"--number-of-authors": "num_authors", "--number-of-languages": "num_langs",
                   "--number-of-file-churns": "num_churn", "--churn-pool-size": "churn_pool"}[a]
            i += 1
            if i >= len(argv): die(f"error: a value is required for '{a}'")
            try: opts[key] = int(argv[i])
            except ValueError: die(f"error: invalid value '{argv[i]}' for '{a} <NUM>'")
            i += 1; continue
        if a == "--no-bots" or a.startswith("--no-bots="):
            opts["no_bots"] = True
            if "=" in a: opts["bot_re"] = a.split("=", 1)[1]
            i += 1; continue
        if a in ("-E", "--email"):
            opts["email"] = True; i += 1; continue
        if a == "--no-merges":
            opts["no_merges"] = True; i += 1; continue
        if a == "--include-hidden":
            opts["include_hidden"] = True; i += 1; continue
        if a == "--no-title":
            opts["no_title"] = True; i += 1; continue
        if a == "--http-url":
            opts["http_url"] = True; i += 1; continue
        if a == "--hide-token":
            opts["hide_token"] = True; i += 1; continue
        if a == "-z" or a == "--iso-time":
            opts["iso_time"] = True; i += 1; continue
        if a == "--number-separator":
            i += 1
            if i < len(argv): opts["number_separator"] = argv[i]; i += 1
            continue
        if a in ("--no-bold", "--no-color-palette", "--no-art", "--nerd-fonts", "--true-color",
                 "--ascii-input", "-c", "--ascii-colors", "-a", "--ascii-language", "-t",
                 "--text-colors", "-i", "--image", "--image-protocol", "--color-resolution"):
            # Presentation options are accepted. Options with obvious values consume one or more.
            consumes = a in ("--true-color", "--ascii-input", "-a", "--ascii-language", "-i",
                             "--image", "--image-protocol", "--color-resolution")
            multi = a in ("-c", "--ascii-colors", "-t", "--text-colors")
            i += 1
            if consumes and i < len(argv): i += 1
            if multi:
                while i < len(argv) and not argv[i].startswith("-"): i += 1
            continue
        if a.startswith("-"):
            die(f"error: unexpected argument '{a}' found")
        if opts["path"] is None:
            opts["path"] = a; i += 1; continue
        die(f"error: unexpected argument '{a}' found")
    return opts

def repo_root(path):
    path = os.path.abspath(path or os.getcwd())
    p = subprocess.run(["git", "-C", path, "rev-parse", "--show-toplevel"], text=True,
                       stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    if p.returncode != 0:
        die(f"Error: Could not find a git repository in '{path}' or in any of its parents")
    return p.stdout.strip()

def rel_files(root, include_hidden, excludes):
    raw = git(root, ["ls-tree", "-r", "--name-only", "HEAD"])
    out = []
    for rel in raw.splitlines():
        parts = rel.split("/")
        if not include_hidden and any(p.startswith(".") for p in parts):
            continue
        if not excluded(rel, excludes):
            out.append(rel)
    return sorted(out)

def excluded(path, patterns):
    p = path.strip("./")
    for pat in patterns:
        q = pat.strip("./")
        if not q:
            continue
        if p == q or p.startswith(q.rstrip("/") + "/") or re.fullmatch(q.replace("*", ".*"), p):
            return True
    return False

def human_size(n):
    if n < 1024: return f"{n} B"
    units = ["KiB", "MiB", "GiB"]
    x = float(n)
    for u in units:
        x /= 1024.0
        if x < 1024:
            return f"{x:.2f} {u}"
    return f"{x:.2f} TiB"

def when(ts, iso=False):
    if not ts: return ""
    if iso:
        return time.strftime("%Y-%m-%dT%H:%M:%S%z", time.localtime(ts))
    diff = max(0, int(time.time() - ts))
    if diff < 60: return "now"
    for sec, name in [(31536000, "year"), (2592000, "month"), (86400, "day"), (3600, "hour"), (60, "minute")]:
        if diff >= sec:
            n = diff // sec
            return f"{n} {name}{'' if n == 1 else 's'} ago"
    return "now"

def fmt_num(n, sep):
    s = str(n)
    if sep == "comma": return f"{n:,}"
    if sep == "underscore": return f"{n:_}"
    if sep == "space": return f"{n:,}".replace(",", " ")
    return s

def language_for(rel):
    base = os.path.basename(rel)
    if base == "Dockerfile": return ("Dockerfile", "programming")
    if base in ("Makefile", "makefile", "GNUmakefile"): return ("Makefile", "programming")
    if base == "CMakeLists.txt": return ("CMake", "programming")
    return EXT_LANG.get(os.path.splitext(base)[1])

def head_blob(root, rel):
    p = subprocess.run(["git", "show", f"HEAD:{rel}"], cwd=root, stdout=subprocess.PIPE, stderr=subprocess.DEVNULL)
    return p.stdout if p.returncode == 0 else b""

def count_lines_blob(data):
    try:
        if b"\0" in data:
            return 0
        if not data:
            return 0
        return len(data.splitlines())
    except Exception:
        return 0

def detect_license(root):
    for name in ("LICENSE", "LICENSE.md", "LICENSE.txt", "COPYING"):
        p = os.path.join(root, name)
        if os.path.exists(p):
            try:
                txt = open(p, "r", errors="ignore").read(4096).lower()
            except OSError:
                continue
            if "mit license" in txt or txt.strip() == "mit":
                return "MIT"
            if "apache license" in txt:
                return "Apache-2.0"
            if "gnu general public license" in txt or "gpl" in txt:
                return "GPL"
            if "bsd" in txt and "redistribution" in txt:
                return "BSD"
    return ""

def remote_url(root, opts):
    url = git(root, ["config", "--get", "remote.origin.url"])
    if opts["http_url"] and url.startswith("git@") and ":" in url:
        host = url.split("@", 1)[1].split(":", 1)[0]
        path = url.split(":", 1)[1]
        url = f"https://{host}/{path}"
    if opts["hide_token"]:
        url = re.sub(r"(https?://)[^/@]+@", r"\1", url)
    return url

def gather(root, opts):
    if git(root, ["rev-parse", "--verify", "HEAD"]).strip() == "":
        die("Error: Failed to traverse Git commit history\n\nCaused by:\n    Branch 'refs/heads/master' does not have any commits")
    gitver = run(["git", "--version"], root)
    username = git(root, ["config", "--get", "user.name"])
    head = git(root, ["rev-parse", "--short=7", "HEAD"], True)
    branch = git(root, ["branch", "--show-current"]) or git(root, ["name-rev", "--name-only", "HEAD"])
    status = git(root, ["status", "--porcelain"])
    added = deleted = modified = 0
    for line in status.splitlines():
        xy = line[:2]
        if "A" in xy or line.startswith("??"): added += 1
        if "D" in xy: deleted += 1
        if "M" in xy or "R" in xy or "C" in xy: modified += 1
    log_args = ["log", "--pretty=%an%x00%ae%x00%ct%x00%P"]
    if opts["no_merges"]:
        log_args.insert(1, "--no-merges")
    raw = git(root, log_args)
    commits = []
    for line in raw.splitlines():
        parts = line.split("\0")
        if len(parts) >= 4:
            name, email, ts, parents = parts[0], parts[1], int(parts[2] or 0), parts[3]
            if opts["no_bots"] and re.search(opts["bot_re"], name, re.I):
                continue
            commits.append((name, email, ts, parents))
    if not commits:
        commits = []
    total_commits = len(commits)
    first_ts = commits[-1][2] if commits else 0
    last_ts = commits[0][2] if commits else 0
    ac = Counter((n, e) for n, e, _, _ in commits)
    authors = []
    for (n, e), c in sorted(ac.items(), key=lambda x: (-x[1], x[0][0].lower()))[:max(0, opts["num_authors"])]:
        authors.append({"name": n, "email": e if opts["email"] else None,
                        "nbrOfCommits": c, "contribution": int(round((c * 100.0 / total_commits))) if total_commits else 0})
    files = rel_files(root, opts["include_hidden"], opts["exclude"])
    lang_lines = Counter()
    loc = 0
    size = 0
    for rel in files:
        blob = head_blob(root, rel)
        size += len(blob)
        lf = language_for(rel)
        if lf and lf[1] in opts["types"]:
            lines = count_lines_blob(blob)
            lang_lines[lf[0]] += lines
            if lf[1] == "programming":
                loc += lines
    total_lang = sum(lang_lines.values())
    langs = []
    for lang, cnt in sorted(lang_lines.items(), key=lambda x: (-x[1], x[0]))[:max(0, opts["num_langs"])]:
        pct = round(cnt * 100.0 / total_lang, 1) if total_lang else 0.0
        langs.append({"language": lang, "percentage": pct})
    churn_pool = opts["churn_pool"] or min(1, max(1, total_commits))
    churn_raw = git(root, ["log", f"-n{churn_pool}", "--name-only", "--pretty=format:"])
    cc = Counter(x for x in churn_raw.splitlines() if x.strip())
    churn = [{"filePath": p, "nbrOfCommits": c} for p, c in sorted(cc.items(), key=lambda x: (-x[1], x[0]))[:max(0, opts["num_churn"])]]
    branches = git(root, ["branch", "--format=%(refname:short)"]).splitlines()
    tags = git(root, ["tag", "--list"]).splitlines()
    repo_name = ""
    url = remote_url(root, opts)
    m = re.search(r"[:/]([^/:]+?)(?:\.git)?$", url)
    if m:
        repo_name = m.group(1)
    version = ""
    for fn in ("package.json", "Cargo.toml"):
        p = os.path.join(root, fn)
        if os.path.exists(p):
            txt = open(p, "r", errors="ignore").read(8192)
            vm = re.search(r'(?m)^\s*"?version"?\s*[:=]\s*"?([^",\n]+)', txt)
            if vm:
                version = vm.group(1).strip()
                break
    return {
        "title": {"gitUsername": username, "gitVersion": gitver},
        "project": {"repoName": repo_name, "numberOfBranches": max(0, len(branches) - 1), "numberOfTags": len(tags)},
        "description": {"description": git(root, ["config", "--get", "github.description"]) or None},
        "head": {"headRefs": {"shortCommitId": head, "refs": [branch] if branch else []}},
        "pending": {"added": added, "deleted": deleted, "modified": modified},
        "version": {"version": version},
        "created": {"creationDate": when(first_ts, opts["iso_time"])},
        "languages": {"languagesWithPercentage": langs},
        "dependencies": {"dependencies": ""},
        "authors": {"authors": authors},
        "last-change": {"lastChange": when(last_ts, opts["iso_time"])},
        "contributors": {"totalNumberOfAuthors": len(ac)},
        "url": {"repoUrl": url},
        "commits": {"numberOfCommits": total_commits, "isShallow": os.path.exists(os.path.join(root, ".git", "shallow"))},
        "churn": {"file_churns": churn, "churn_pool_size": churn_pool},
        "lines-of-code": {"linesOfCode": loc},
        "size": {"repoSize": human_size(size), "fileCount": len(files)},
        "license": {"license": detect_license(root)},
    }

def info_fields(data, disabled):
    mapping = [
        ("project", "ProjectInfo"), ("description", "DescriptionInfo"), ("head", "HeadInfo"),
        ("pending", "PendingInfo"), ("version", "VersionInfo"), ("created", "CreatedInfo"),
        ("languages", "LanguagesInfo"), ("dependencies", "DependenciesInfo"), ("authors", "AuthorsInfo"),
        ("last-change", "LastChangeInfo"), ("contributors", "ContributorsInfo"), ("url", "UrlInfo"),
        ("commits", "CommitsInfo"), ("churn", "ChurnInfo"), ("lines-of-code", "LocInfo"),
        ("size", "SizeInfo"), ("license", "LicenseInfo"),
    ]
    out = []
    for k, label in mapping:
        if k in disabled:
            continue
        if k == "languages" and not data[k]["languagesWithPercentage"]:
            continue
        if k == "lines-of-code" and data[k]["linesOfCode"] == 0:
            continue
        out.append({label: data[k]})
    return out

def yaml_scalar(v):
    if v is None: return "null"
    if v is True: return "true"
    if v is False: return "false"
    if isinstance(v, (int, float)): return str(v)
    if v == "": return "''"
    return str(v)

def to_yaml(obj, indent=0):
    sp = " " * indent
    lines = []
    if isinstance(obj, dict):
        for k, v in obj.items():
            if isinstance(v, (dict, list)):
                lines.append(f"{sp}{k}:")
                lines.extend(to_yaml(v, indent + 2))
            else:
                lines.append(f"{sp}{k}: {yaml_scalar(v)}")
    elif isinstance(obj, list):
        for item in obj:
            if isinstance(item, dict) and len(item) == 1:
                k, v = next(iter(item.items()))
                lines.append(f"{sp}- {k}:")
                lines.extend(to_yaml(v, indent + 4))
            elif isinstance(item, (dict, list)):
                lines.append(f"{sp}-")
                lines.extend(to_yaml(item, indent + 2))
            else:
                lines.append(f"{sp}- {yaml_scalar(item)}")
    return lines

def plain(data, opts):
    rows = []
    if not opts["no_title"]:
        title = data["title"]["gitVersion"]
        if data["title"]["gitUsername"]:
            title = f"{data['title']['gitUsername']} ~ {title}"
        rows.append(title)
        rows.append("-" * len(title))
    d = opts["disabled"]
    if "project" not in d and data["project"]["repoName"]: rows.append(f"Project: {data['project']['repoName']}")
    if "head" not in d: rows.append(f"HEAD: {data['head']['headRefs']['shortCommitId']} ({', '.join(data['head']['headRefs']['refs'])})")
    if "pending" not in d and any(data["pending"].values()):
        p = data["pending"]; rows.append(f"Pending: {p['added']}+ {p['deleted']}- {p['modified']}~")
    if "version" not in d and data["version"]["version"]: rows.append(f"Version: {data['version']['version']}")
    if "created" not in d: rows.append(f"Created: {data['created']['creationDate']}")
    if "languages" not in d and data["languages"]["languagesWithPercentage"]:
        rows.append("Languages: " + ", ".join(f"{x['language']} ({x['percentage']:.1f} %)" for x in data["languages"]["languagesWithPercentage"]))
    if "authors" not in d and data["authors"]["authors"]:
        first = True
        for a in data["authors"]["authors"]:
            name = a["name"] + (f" <{a['email']}>" if a["email"] else "")
            rows.append(("Author: " if first and len(data["authors"]["authors"]) == 1 else "Authors: " if first else "         ") + f"{a['contribution']}% {name} {a['nbrOfCommits']}")
            first = False
    if "last-change" not in d: rows.append(f"Last change: {data['last-change']['lastChange']}")
    if "contributors" not in d and data["contributors"]["totalNumberOfAuthors"] > 1:
        rows.append(f"Contributors: {data['contributors']['totalNumberOfAuthors']}")
    if "url" not in d and data["url"]["repoUrl"]: rows.append(f"URL: {data['url']['repoUrl']}")
    if "commits" not in d: rows.append(f"Commits: {fmt_num(data['commits']['numberOfCommits'], opts['number_separator'])}")
    if "churn" not in d and data["churn"]["file_churns"]:
        label = f"Churn ({data['churn']['churn_pool_size']})"
        first = True
        for c in data["churn"]["file_churns"]:
            rows.append((label + ": " if first else " " * (len(label) + 2)) + f"{c['filePath']} {c['nbrOfCommits']}")
            first = False
    if "lines-of-code" not in d and data["lines-of-code"]["linesOfCode"]:
        rows.append(f"Lines of code: {fmt_num(data['lines-of-code']['linesOfCode'], opts['number_separator'])}")
    if "size" not in d: rows.append(f"Size: {data['size']['repoSize']} ({fmt_num(data['size']['fileCount'], opts['number_separator'])} files)")
    if "license" not in d and data["license"]["license"]: rows.append(f"License: {data['license']['license']}")
    return "\n".join(rows)

def completion(shell):
    if shell == "bash":
        return "_onefetch() {\n    COMPREPLY=( $(compgen -W \"--help --version --languages --package-managers --output --disabled-fields --no-art --no-color-palette\" -- \"${COMP_WORDS[COMP_CWORD]}\") )\n}\ncomplete -F _onefetch onefetch\n"
    return f"# completion for {shell}\n"

def main():
    opts = parse(sys.argv[1:])
    if opts["languages"]:
        print("\n".join(LANGS)); return
    if opts["package_managers"]:
        print("\n".join(PM)); return
    if opts["generate"]:
        print(completion(opts["generate"]), end=""); return
    root = repo_root(opts["path"])
    data = gather(root, opts)
    output = {"title": data["title"], "infoFields": info_fields(data, opts["disabled"])}
    if opts["output"] == "json":
        print(json.dumps(output, indent=2))
    elif opts["output"] == "yaml":
        print("\n".join(to_yaml(output)))
    else:
        print(plain(data, opts))

if __name__ == "__main__":
    main()
