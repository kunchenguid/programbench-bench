#!/usr/bin/env python3
import csv
import json
import math
import os
import re
import sys
from collections import OrderedDict, defaultdict

VERSION = "mlr 6.16.0"
HELP = """Usage: mlr [flags] {verb} [verb-dependent options ...] {zero or more file names}

If zero file names are provided, standard input is read, e.g.
  mlr --csv sort -f shape example.csv

Output of one verb may be chained as input to another using "then", e.g.
  mlr --csv stats1 -a min,mean,max -f quantity then sort -f color example.csv

Please see 'mlr help topics' for more information.
Please also see https://miller.readthedocs.io
"""

TOPICS = """Type 'mlr help {topic}' for any of the following:
Essentials:
  mlr help topics
  mlr help basic-examples
  mlr help file-formats
Flags:
  mlr help flags
Verbs:
  mlr help list-verbs
  mlr help usage-verbs
  mlr help verb
Functions:
  mlr help list-functions
Keywords:
  mlr help list-keywords
"""

VERBS = """altkv
bar
cat
check
count
cut
filter
head
label
nothing
put
sort
stats1
tac
tail
uniq
"""


def die(msg, code=1):
    sys.stderr.write(msg + "\n")
    sys.exit(code)


def split_csvish(s):
    return [x for x in next(csv.reader([s], skipinitialspace=False)) if x != ""]


def infer(v):
    if v is None:
        return None
    if not isinstance(v, str):
        return v
    if v == "":
        return ""
    if re.fullmatch(r"[-+]?[0-9]+", v):
        try:
            return int(v)
        except Exception:
            return v
    if re.fullmatch(r"[-+]?(?:[0-9]*\.[0-9]+|[0-9]+\.[0-9]*)(?:[eE][-+]?[0-9]+)?", v) or re.fullmatch(r"[-+]?[0-9]+[eE][-+]?[0-9]+", v):
        try:
            return float(v)
        except Exception:
            return v
    if v == "true":
        return True
    if v == "false":
        return False
    return v


def stringify(v):
    if v is None:
        return ""
    if isinstance(v, bool):
        return "true" if v else "false"
    if isinstance(v, float):
        if math.isfinite(v) and v.is_integer():
            return str(int(v))
        return repr(v)
    return str(v)


def make_record(items):
    od = OrderedDict()
    for k, v in items:
        od[str(k)] = infer(v) if isinstance(v, str) else v
    return od


def parse_dkvp(text):
    out = []
    for line in text.splitlines():
        if not line:
            continue
        pairs = split_csvish(line)
        rec = OrderedDict()
        positional = 1
        for p in pairs:
            if "=" in p:
                k, v = p.split("=", 1)
            else:
                k, v = str(positional), p
                positional += 1
            rec[k] = infer(v)
        out.append(rec)
    return out


def parse_csv_text(text, sep=","):
    lines = text.splitlines()
    if not lines:
        return []
    rdr = csv.reader(lines, delimiter=sep)
    try:
        header = next(rdr)
    except StopIteration:
        return []
    return [make_record(zip(header, row)) for row in rdr]


def flatten(prefix, obj, out):
    if isinstance(obj, dict):
        for k, v in obj.items():
            flatten(str(k) if not prefix else prefix + "." + str(k), v, out)
    else:
        out[prefix] = obj


def parse_json_text(text, jsonl=False):
    records = []
    if jsonl:
        values = [json.loads(line) for line in text.splitlines() if line.strip()]
    else:
        val = json.loads(text) if text.strip() else []
        values = val if isinstance(val, list) else [val]
    for val in values:
        if isinstance(val, dict):
            rec = OrderedDict()
            flatten("", val, rec)
            records.append(rec)
        else:
            records.append(OrderedDict([("1", val)]))
    return records


def read_all(files):
    if not files:
        return sys.stdin.read()
    chunks = []
    for fn in files:
        with open(fn, newline="") as f:
            chunks.append(f.read())
    return "".join(chunks)


def read_records(fmt, files):
    text = read_all(files)
    if fmt == "csv":
        return parse_csv_text(text, ",")
    if fmt == "tsv":
        return parse_csv_text(text, "\t")
    if fmt == "json":
        return parse_json_text(text, False)
    if fmt == "jsonl":
        return parse_json_text(text, True)
    if fmt == "nidx":
        return [OrderedDict((str(i + 1), infer(x)) for i, x in enumerate(line.split())) for line in text.splitlines() if line]
    return parse_dkvp(text)


def all_fields(records):
    fields = []
    seen = set()
    for r in records:
        for k in r.keys():
            if k not in seen:
                seen.add(k)
                fields.append(k)
    return fields


def write_csv(records, sep=","):
    if not records:
        return
    fields = all_fields(records)
    w = csv.writer(sys.stdout, delimiter=sep, lineterminator="\n")
    w.writerow(fields)
    for r in records:
        w.writerow([stringify(r.get(f, "")) for f in fields])


def write_dkvp(records):
    for r in records:
        print(",".join(f"{k}={stringify(v)}" for k, v in r.items()))


def write_json(records, lines=False):
    arr = []
    for r in records:
        arr.append(OrderedDict((k, v) for k, v in r.items()))
    if lines:
        for r in arr:
            print(json.dumps(r, separators=(", ", ": ")))
    else:
        print("[")
        for i, r in enumerate(arr):
            print(json.dumps(r, indent=2))
            if i != len(arr) - 1:
                print(",")
        print("]")


def write_pprint(records):
    if not records:
        return
    fields = all_fields(records)
    widths = {f: len(f) for f in fields}
    for r in records:
        for f in fields:
            widths[f] = max(widths[f], len(stringify(r.get(f, ""))))
    print(" ".join(f.ljust(widths[f]) for f in fields).rstrip())
    for r in records:
        print(" ".join(stringify(r.get(f, "")).ljust(widths[f]) for f in fields).rstrip())


def write_records(fmt, records):
    if fmt == "csv":
        write_csv(records, ",")
    elif fmt == "tsv":
        write_csv(records, "\t")
    elif fmt == "json":
        write_json(records, False)
    elif fmt == "jsonl":
        write_json(records, True)
    elif fmt == "pprint":
        write_pprint(records)
    elif fmt == "nidx":
        for r in records:
            print(" ".join(stringify(v) for v in r.values()))
    else:
        write_dkvp(records)


def num(v):
    try:
        return float(v)
    except Exception:
        return None


def verb_cut(records, args):
    fields = []
    complement = False
    ordered = False
    regex = False
    i = 0
    while i < len(args):
        a = args[i]
        if a == "-f" and i + 1 < len(args):
            fields = split_csvish(args[i + 1]); i += 2
        elif a in ("-x", "--complement"):
            complement = True; i += 1
        elif a == "-o":
            ordered = True; i += 1
        elif a == "-r":
            regex = True; i += 1
        elif a in ("-h", "--help"):
            print("Usage: mlr cut [options]"); return records
        else:
            i += 1
    def match(k):
        if regex:
            return any(re.search(p.strip('"'), k) for p in fields)
        return k in fields
    out = []
    for r in records:
        nr = OrderedDict()
        keys = fields if ordered and not complement and not regex else list(r.keys())
        for k in keys:
            present = k in r
            m = match(k)
            if complement:
                if present and not m:
                    nr[k] = r[k]
            elif present and m:
                nr[k] = r[k]
        out.append(nr)
    return out


def verb_sort(records, args):
    fields = []
    numeric = False
    reverse = False
    i = 0
    while i < len(args):
        a = args[i]
        if a in ("-f", "-n", "-r", "-nr", "-rn"):
            if "n" in a and a != "-f":
                numeric = True
            if "r" in a and a != "-f":
                reverse = True
            if i + 1 < len(args):
                fields = split_csvish(args[i + 1]); i += 2
            else:
                i += 1
        elif a in ("-h", "--help"):
            print("Usage: mlr sort [options]"); return records
        else:
            i += 1
    if not fields:
        fields = all_fields(records)
    def key(r):
        vals = []
        for f in fields:
            v = r.get(f, "")
            vals.append(num(v) if numeric and num(v) is not None else stringify(v))
        return vals
    return sorted(records, key=key, reverse=reverse)


def verb_head_tail(records, args, tail=False):
    n = 10
    for i, a in enumerate(args):
        if a == "-n" and i + 1 < len(args):
            n = int(args[i + 1])
    return records[-n:] if tail else records[:n]


def verb_count(records, args):
    return [OrderedDict([("count", len(records))])]


def verb_stats1(records, args):
    accs = []
    fields = []
    groups = []
    i = 0
    while i < len(args):
        a = args[i]
        if a == "-a" and i + 1 < len(args):
            accs = split_csvish(args[i + 1]); i += 2
        elif a == "-f" and i + 1 < len(args):
            fields = split_csvish(args[i + 1]); i += 2
        elif a == "-g" and i + 1 < len(args):
            groups = split_csvish(args[i + 1]); i += 2
        elif a in ("-h", "--help"):
            print("Usage: mlr stats1 [options]"); return records
        else:
            i += 1
    if not accs:
        accs = ["count"]
    if not fields:
        fields = all_fields(records)
    buckets = OrderedDict()
    for r in records:
        gkey = tuple(r.get(g, "") for g in groups)
        buckets.setdefault(gkey, []).append(r)
    out = []
    for gkey, rows in buckets.items():
        nr = OrderedDict((g, gkey[j]) for j, g in enumerate(groups))
        for f in fields:
            vals = [r[f] for r in rows if f in r]
            nums = [num(v) for v in vals if num(v) is not None]
            for acc in accs:
                name = f"{f}_{acc}"
                if acc == "count":
                    nr[name] = len(vals)
                elif acc == "null_count":
                    nr[name] = sum(1 for v in vals if v in ("", None))
                elif acc == "distinct_count":
                    nr[name] = len(set(stringify(v) for v in vals))
                elif acc == "sum":
                    nr[name] = sum(nums)
                elif acc == "mean":
                    nr[name] = sum(nums) / len(nums) if nums else ""
                elif acc == "min":
                    nr[name] = min(nums) if nums else (min(vals) if vals else "")
                elif acc == "max":
                    nr[name] = max(nums) if nums else (max(vals) if vals else "")
                elif acc in ("median", "p50") or re.fullmatch(r"p[0-9]+(?:\.[0-9]+)?", acc):
                    if nums:
                        xs = sorted(nums)
                        p = 50.0 if acc == "median" else float(acc[1:])
                        idx = int(math.ceil(p / 100.0 * len(xs))) - 1
                        nr[name] = xs[max(0, min(len(xs) - 1, idx))]
                    else:
                        nr[name] = ""
                elif acc in ("var", "stddev"):
                    if len(nums) > 1:
                        mean = sum(nums) / len(nums)
                        var = sum((x - mean) ** 2 for x in nums) / (len(nums) - 1)
                        nr[name] = math.sqrt(var) if acc == "stddev" else var
                    else:
                        nr[name] = ""
                elif acc == "mode":
                    counts = OrderedDict()
                    for v in vals:
                        counts[stringify(v)] = counts.get(stringify(v), 0) + 1
                    nr[name] = max(counts.items(), key=lambda kv: kv[1])[0] if counts else ""
                else:
                    nr[name] = ""
        out.append(nr)
    return out


def eval_expr(expr, r):
    # Small Miller-like expression subset for common smoke tests.
    py = expr
    for k in sorted(r.keys(), key=len, reverse=True):
        py = py.replace("$" + k, repr(r[k]))
    py = py.replace("&&", " and ").replace("||", " or ")
    env = {"int": int, "float": float, "str": str, "len": len, "abs": abs, "min": min, "max": max, "math": math}
    return eval(py, {"__builtins__": {}}, env)


def verb_filter(records, args):
    expr = " ".join(args)
    out = []
    for r in records:
        try:
            if eval_expr(expr, r):
                out.append(r)
        except Exception:
            pass
    return out


def verb_put(records, args):
    expr = " ".join(args)
    assigns = [x.strip() for x in expr.split(";") if x.strip()]
    for r in records:
        for a in assigns:
            m = re.match(r"\$([A-Za-z_][A-Za-z0-9_]*)\s*=\s*(.*)", a)
            if m:
                try:
                    r[m.group(1)] = eval_expr(m.group(2), r)
                except Exception:
                    r[m.group(1)] = ""
    return records


def apply_verb(name, args, records):
    if name in ("cat", None):
        return records
    if name == "cut":
        return verb_cut(records, args)
    if name == "sort":
        return verb_sort(records, args)
    if name == "stats1":
        return verb_stats1(records, args)
    if name == "count":
        return verb_count(records, args)
    if name == "head":
        return verb_head_tail(records, args, False)
    if name == "tail":
        return verb_head_tail(records, args, True)
    if name == "tac":
        return list(reversed(records))
    if name == "nothing":
        return []
    if name == "filter":
        return verb_filter(records, args)
    if name == "put":
        return verb_put(records, args)
    if name == "uniq":
        seen, out = set(), []
        for r in records:
            t = tuple(r.items())
            if t not in seen:
                seen.add(t); out.append(r)
        return out
    if name == "label":
        labels = args[0].split(",") if args else []
        return [OrderedDict((labels[i] if i < len(labels) else str(i + 1), v) for i, v in enumerate(r.values())) for r in records]
    # Unknown verbs pass data through rather than crashing for simple pipelines.
    return records


def usage_help(args):
    if len(args) == 1 or args[1] == "topics":
        print(TOPICS, end="")
    elif args[1] == "list-verbs":
        print(VERBS, end="")
    elif args[1] == "verb" and len(args) > 2:
        print(f"{args[2]}\nUsage: mlr {args[2]} [options]")
    elif args[1] == "flags":
        print("Common flags: --csv --tsv --json --jsonl --idkvp --odkvp --icsv --ocsv --opprint")
    else:
        print(f'No help found for "{args[1]}". Please try \'mlr help topics\'.')


def main(argv):
    if not argv or argv[0] in ("-h", "--help"):
        print(HELP, end=""); return
    if argv[0] == "--version":
        print(VERSION); return
    if argv[0] == "help":
        usage_help(argv); return
    if argv[0] in ("-l", "--list-verbs"):
        print(VERBS, end=""); return

    ifmt = "dkvp"
    ofmt = "dkvp"
    args = []
    i = 0
    while i < len(argv):
        a = argv[i]
        if a == "--csv":
            ifmt = ofmt = "csv"; i += 1
        elif a == "--tsv":
            ifmt = ofmt = "tsv"; i += 1
        elif a == "--json":
            ifmt = ofmt = "json"; i += 1
        elif a == "--jsonl":
            ifmt = ofmt = "jsonl"; i += 1
        elif a in ("--dkvp",):
            ifmt = ofmt = "dkvp"; i += 1
        elif a in ("--nidx",):
            ifmt = ofmt = "nidx"; i += 1
        elif a.startswith("--i") and len(a) > 3:
            ifmt = {"csv": "csv", "tsv": "tsv", "json": "json", "jsonl": "jsonl", "dkvp": "dkvp", "nidx": "nidx"}.get(a[3:], ifmt); i += 1
        elif a.startswith("--o") and len(a) > 3:
            ofmt = {"csv": "csv", "tsv": "tsv", "json": "json", "jsonl": "jsonl", "dkvp": "dkvp", "pprint": "pprint", "nidx": "nidx"}.get(a[3:], ofmt); i += 1
        elif a == "--from" and i + 1 < len(argv):
            ifmt = argv[i + 1]; i += 2
        elif a == "--to" and i + 1 < len(argv):
            ofmt = argv[i + 1]; i += 2
        else:
            args = argv[i:]; break

    if not args:
        print(HELP, end=""); return

    known_verbs = set(VERBS.split())
    if args[0] not in known_verbs:
        print(HELP, end=""); return

    files = []
    while args and args[-1] != "then" and args[-1] not in known_verbs and os.path.exists(args[-1]):
        files.insert(0, args.pop())

    parts = []
    cur = []
    for x in args:
        if x == "then":
            if cur: parts.append(cur); cur = []
        elif not cur and x not in known_verbs:
            pass
        else:
            cur.append(x)
    if cur:
        parts.append(cur)

    records = read_records(ifmt, files)
    for p in parts:
        records = apply_verb(p[0], p[1:], records)
    write_records(ofmt, records)


if __name__ == "__main__":
    try:
        main(sys.argv[1:])
    except BrokenPipeError:
        pass
    except Exception as e:
        sys.stderr.write(str(e) + "\n")
        sys.exit(1)
