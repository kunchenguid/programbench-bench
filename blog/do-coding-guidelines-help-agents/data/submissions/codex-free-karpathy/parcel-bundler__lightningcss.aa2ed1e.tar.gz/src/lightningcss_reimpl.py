#!/usr/bin/env python3
import argparse
import base64
import hashlib
import json
import os
import re
import sys


VERSION = "lightningcss 1.0.0-alpha.70"

NAMED_COLORS = {
    "#ff0000": "red",
    "#0000ff": "#00f",
    "#00ff00": "#0f0",
    "#ffffff": "#fff",
    "#000000": "#000",
    "#ffff00": "#ff0",
    "#00ffff": "#0ff",
    "#ff00ff": "#f0f",
}


def strip_comments(css, keep_bang=True):
    out = []
    i = 0
    n = len(css)
    quote = None
    while i < n:
        c = css[i]
        if quote:
            out.append(c)
            if c == "\\" and i + 1 < n:
                out.append(css[i + 1])
                i += 2
                continue
            if c == quote:
                quote = None
            i += 1
            continue
        if c in ("'", '"'):
            quote = c
            out.append(c)
            i += 1
            continue
        if c == "/" and i + 1 < n and css[i + 1] == "*":
            end = css.find("*/", i + 2)
            if end < 0:
                break
            comment = css[i : end + 2]
            if keep_bang and comment.startswith("/*!"):
                out.append(comment)
                out.append("\n")
            i = end + 2
            continue
        out.append(c)
        i += 1
    return "".join(out)


def split_top(s, sep):
    parts = []
    start = 0
    depth = 0
    quote = None
    i = 0
    while i < len(s):
        c = s[i]
        if quote:
            if c == "\\":
                i += 2
                continue
            if c == quote:
                quote = None
        elif c in ("'", '"'):
            quote = c
        elif c in "([{":
            depth += 1
        elif c in ")]}":
            depth = max(0, depth - 1)
        elif c == sep and depth == 0:
            parts.append(s[start:i])
            start = i + 1
        i += 1
    parts.append(s[start:])
    return parts


def parse_stylesheet(css):
    css = strip_comments(css)
    return parse_blocks(css, 0, len(css))[0]


def parse_blocks(css, start, end):
    nodes = []
    text_start = start
    i = start
    quote = None
    while i < end:
        c = css[i]
        if quote:
            if c == "\\":
                i += 2
                continue
            if c == quote:
                quote = None
            i += 1
            continue
        if c in ("'", '"'):
            quote = c
            i += 1
            continue
        if c == "{":
            pre = css[text_start:i].strip()
            close = find_matching(css, i, end)
            if pre:
                body = css[i + 1 : close]
                nodes.append(("block", pre, parse_declarations_or_blocks(body)))
            i = close + 1
            text_start = i
            continue
        if c == ";":
            pre = css[text_start : i + 1].strip()
            if pre:
                nodes.append(("stmt", pre))
            text_start = i + 1
        i += 1
    tail = css[text_start:end].strip()
    if tail:
        nodes.append(("stmt", tail))
    return nodes, i


def find_matching(css, open_pos, end):
    depth = 1
    quote = None
    i = open_pos + 1
    while i < end:
        c = css[i]
        if quote:
            if c == "\\":
                i += 2
                continue
            if c == quote:
                quote = None
        elif c in ("'", '"'):
            quote = c
        elif c == "{":
            depth += 1
        elif c == "}":
            depth -= 1
            if depth == 0:
                return i
        i += 1
    raise ValueError("unclosed block")


def parse_declarations_or_blocks(body):
    nodes = parse_blocks(body, 0, len(body))[0]
    if any(n[0] == "block" for n in nodes):
        return nodes
    decls = []
    for part in split_top(body, ";"):
        p = part.strip()
        if not p:
            continue
        k, v = split_decl(p)
        if k:
            decls.append(("decl", k, v))
        else:
            decls.append(("raw", p))
    return optimize_decls(decls)


def inline_imports(css, base_dir, seen=None):
    seen = seen or set()

    def repl(m):
        name = m.group(1) or m.group(2)
        path = name if os.path.isabs(name) else os.path.join(base_dir, name)
        if path in seen:
            return ""
        try:
            with open(path, "r", encoding="utf-8") as f:
                seen.add(path)
                return inline_imports(f.read(), os.path.dirname(path), seen)
        except OSError:
            return m.group(0)

    return re.sub(r"@import\s+(?:url\(\s*[\"']?([^\"')]+)[\"']?\s*\)|[\"']([^\"']+)[\"'])\s*;", repl, css)


def split_decl(s):
    depth = 0
    quote = None
    for i, c in enumerate(s):
        if quote:
            if c == "\\":
                continue
            if c == quote:
                quote = None
        elif c in ("'", '"'):
            quote = c
        elif c in "([":
            depth += 1
        elif c in ")]":
            depth = max(0, depth - 1)
        elif c == ":" and depth == 0:
            return s[:i].strip(), s[i + 1 :].strip()
    return None, None


def optimize_decls(decls):
    last = {}
    result = []
    for item in decls:
        if item[0] != "decl" or item[1].startswith("--"):
            result.append(item)
            continue
        prop = item[1].lower()
        val = normalize_value(prop, item[2])
        item = ("decl", prop, val)
        if prop in last:
            result[last[prop]] = None
        last[prop] = len(result)
        result.append(item)
    result = [x for x in result if x is not None]
    return combine_box_shorthands(result)


def combine_box_shorthands(decls):
    normal = []
    box = []
    for item in decls:
        if item[0] == "decl" and item[1] in ("margin", "padding"):
            box.append(("decl", item[1], compress_quad(item[2])))
        else:
            normal.append(item)
    return normal + box


def normalize_space(v):
    v = re.sub(r"\s+", " ", v.strip())
    v = re.sub(r"\s*([,:/])\s*", r"\1", v)
    v = re.sub(r"\(\s+", "(", v)
    v = re.sub(r"\s+\)", ")", v)
    v = re.sub(r"\s*([+\-*/])\s*", r"\1", v)
    v = re.sub(r"(?<=[,(])-?0(?:px|em|rem|vh|vw|vmin|vmax|cm|mm|in|pt|pc|q|%)\b", "0", v, flags=re.I)
    v = re.sub(r"(?<=\s)-?0(?:px|em|rem|vh|vw|vmin|vmax|cm|mm|in|pt|pc|q|%)\b", "0", v, flags=re.I)
    v = re.sub(r"^(-?)0(?:px|em|rem|vh|vw|vmin|vmax|cm|mm|in|pt|pc|q|%)\b", r"\g<1>0", v, flags=re.I)
    v = re.sub(r"(?<![\w.-])0+\.(\d+)", r".\1", v)
    return v


def normalize_value(prop, v):
    v = normalize_space(v)
    v = re.sub(r"#([0-9a-fA-F]{6})(?![0-9a-fA-F])", shorten_hex_match, v)
    v = re.sub(r"\brgb\(\s*(\d+),\s*(\d+),\s*(\d+)\s*\)", rgb_to_color, v, flags=re.I)
    v = re.sub(r"\bhsl\(0,100%,50%\)", "red", v, flags=re.I)
    v = re.sub(r"\brgba\(255,0,0,1(?:\.0*)?\)", "red", v, flags=re.I)
    v = re.sub(r"\bblue\b", "#00f", v, flags=re.I)
    v = re.sub(r"\bcalc\(([-+]?\d+(?:\.\d+)?[a-z%]+)-0(?:[a-z%]+)?\)", r"\1", v, flags=re.I)
    if prop == "display":
        v = v.replace("inline flex", "inline-flex").replace("inline grid", "inline-grid")
    if prop == "transform":
        v = v.replace("translate(0,0)", "translate(0)")
        v = v.replace("translate(0 0)", "translate(0)")
    if prop in ("margin", "padding"):
        v = compress_quad(v)
    return v


def shorten_hex_match(m):
    h = m.group(1).lower()
    full = "#" + h
    if h[0] == h[1] and h[2] == h[3] and h[4] == h[5]:
        full = "#" + h[0] + h[2] + h[4]
    return NAMED_COLORS.get("#" + h, NAMED_COLORS.get(full, full))


def rgb_to_color(m):
    try:
        r, g, b = [int(x) for x in m.groups()]
    except ValueError:
        return m.group(0)
    h = f"#{r:02x}{g:02x}{b:02x}"
    return NAMED_COLORS.get(h, h)


def compress_quad(v):
    parts = v.split()
    if len(parts) == 4:
        a, b, c, d = parts
        if a == b == c == d:
            return a
        if a == c and b == d:
            return f"{a} {b}"
        if b == d:
            return f"{a} {b} {c}"
    return v


def minify_selector(sel):
    sel = normalize_space(sel)
    sel = re.sub(r"\s*([<>]=?|=)\s*", r"\1", sel)
    sel = re.sub(r"\s*([>+~])\s*", r"\1", sel)
    sel = re.sub(r"\s*,\s*", ",", sel)
    sel = re.sub(r"\s*([()])\s*", r"\1", sel)
    sel = sel.replace(": ", ":")
    sel = re.sub(r"^@(media|supports|container)\(", r"@\1 (", sel)
    sel = re.sub(r"^@custom-media ([^(]+)\(", lambda m: "@custom-media " + m.group(1).rstrip() + " (", sel)
    if sel == "from":
        return "0%"
    return sel


def minify_nodes(nodes):
    out = []
    for node in nodes:
        if node[0] == "stmt":
            out.append(minify_selector(node[1]))
        else:
            head = minify_selector(node[1])
            body = node[2]
            if all(x[0] in ("decl", "raw") for x in body):
                inner = []
                for item in body:
                    if item[0] == "decl":
                        inner.append(f"{item[1]}:{item[2]}")
                    elif item[0] == "raw":
                        inner.append(item[1])
                if inner:
                    out.append(head + "{" + ";".join(inner) + "}")
            else:
                out.append(head + "{" + minify_nodes(body) + "}")
    return "".join(out)


def pretty_nodes(nodes, level=0):
    out = []
    indent = "  " * level
    for node in nodes:
        if node[0] == "stmt":
            out.append(indent + minify_selector(node[1]) + "\n")
            continue
        head = minify_selector(node[1])
        body = node[2]
        out.append(f"{indent}{head} {{\n")
        if all(x[0] in ("decl", "raw") for x in body):
            for item in body:
                if item[0] == "decl":
                    out.append(f"{indent}  {item[1]}: {item[2]};\n")
                else:
                    out.append(f"{indent}  {item[1]};\n")
        else:
            out.append(pretty_nodes(body, level + 1))
        out.append(f"{indent}}}\n")
        if level == 0:
            out.append("\n")
    return "".join(out)


def module_prefix(name):
    digest = hashlib.sha1(name.encode()).digest()
    return base64.urlsafe_b64encode(digest)[:6].decode().replace("-", "_")


def css_modules(css, filename, minify):
    prefix = module_prefix(filename or "stdin")
    exports = {}

    def repl_class(m):
        n = m.group(1)
        full = f"{prefix}_{n}"
        exports.setdefault(n, {"composes": [], "isReferenced": False, "name": full})
        return "." + full

    def repl_id(m):
        n = m.group(1)
        full = f"{prefix}_{n}"
        exports.setdefault(n, {"composes": [], "isReferenced": False, "name": full})
        return "#" + full

    def repl_keyframes(m):
        n = m.group(1)
        full = f"{prefix}_{n}"
        exports.setdefault(n, {"composes": [], "isReferenced": True, "name": full})
        return "@keyframes " + full

    css2 = re.sub(r"\.([_a-zA-Z][\w-]*)", repl_class, css)
    css2 = re.sub(r"#([_a-zA-Z][\w-]*)", repl_id, css2)
    css2 = re.sub(r"@keyframes\s+([_a-zA-Z][\w-]*)", repl_keyframes, css2)
    for old, info in list(exports.items()):
        css2 = re.sub(r"(?<=animation:)([^;{}]*\b)" + re.escape(old) + r"\b", lambda m, full=info["name"]: m.group(0).replace(old, full), css2)
        css2 = re.sub(r"(?<=animation-name:)\s*" + re.escape(old) + r"\b", info["name"], css2)
    code = render(css2, minify)
    return json.dumps({"code": code, "exports": dict(sorted(exports.items()))}, separators=(",", ":"))


def render(css, minify=False):
    preserved = []
    def save_bang(m):
        preserved.append(m.group(0))
        return f"___LC_COMMENT_{len(preserved)-1}___"

    css = re.sub(r"/\*!.*?\*/", save_bang, css, flags=re.S)
    nodes = parse_stylesheet(css)
    result = minify_nodes(nodes) if minify else pretty_nodes(nodes)
    for i, c in enumerate(preserved):
        result = result.replace(f"___LC_COMMENT_{i}___", c)
    if minify and preserved and not result.startswith("/*!"):
        result = "\n".join(preserved) + "\n" + result
    return result


def read_inputs(paths):
    if not paths:
        return sys.stdin.read(), "stdin"
    chunks = []
    for p in paths:
        with open(p, "r", encoding="utf-8") as f:
            chunks.append(f.read())
    return "\n".join(chunks), paths[0]


def write_output(args, code, input_paths):
    if args.output_file:
        with open(args.output_file, "w", encoding="utf-8") as f:
            f.write(code)
        return
    if args.output_dir:
        os.makedirs(args.output_dir, exist_ok=True)
        for p in input_paths:
            with open(p, "r", encoding="utf-8") as f:
                c = render(f.read(), args.minify)
            out = os.path.join(args.output_dir, os.path.basename(p))
            with open(out, "w", encoding="utf-8") as f:
                f.write(c)
        return
    sys.stdout.write(code)


def main(argv):
    if "--version" in argv or "-V" in argv:
        print(VERSION)
        return 0
    parser = argparse.ArgumentParser(
        prog="executable",
        description="A CSS parser, transformer, and minifier",
        add_help=False,
    )
    parser.add_argument("inputs", nargs="*")
    parser.add_argument("-h", "--help", action="store_true")
    parser.add_argument("-m", "--minify", action="store_true")
    parser.add_argument("-o", "--output-file")
    parser.add_argument("-d", "--output-dir")
    parser.add_argument("--sourcemap", action="store_true")
    parser.add_argument("--bundle", action="store_true")
    parser.add_argument("--custom-media", action="store_true")
    parser.add_argument("--error-recovery", action="store_true")
    parser.add_argument("--browserslist", action="store_true")
    parser.add_argument("-t", "--targets")
    parser.add_argument("--css-modules", nargs="?", const=True)
    parser.add_argument("--css-modules-pattern")
    parser.add_argument("--css-modules-dashed-idents", action="store_true")
    try:
        args = parser.parse_args(argv)
    except SystemExit as e:
        return int(e.code)
    if args.help:
        print("""lightningcss 1.0.0-alpha.70
Devon Govett <devongovett@gmail.com>
A CSS parser, transformer, and minifier

USAGE:
    executable [OPTIONS] [INPUT_FILE]...

ARGS:
    <INPUT_FILE>...    Target CSS file (default: stdin)

OPTIONS:
        --bundle
        --css-modules [<CSS_MODULES>]
        --custom-media
    -d, --output-dir <OUTPUT_DIR>
    -h, --help
    -m, --minify
    -o, --output-file <OUTPUT_FILE>
        --sourcemap
    -t, --targets <TARGETS>
    -V, --version""")
        return 0
    if len(args.inputs) > 1 and not args.output_dir and not args.output_file:
        print("Cannot output to stdout with multiple inputs. Use --output-dir instead.", file=sys.stderr)
        return 1
    try:
        css, name = read_inputs(args.inputs)
        if args.bundle:
            base = os.path.dirname(name) if args.inputs else os.getcwd()
            css = inline_imports(css, base)
        if args.css_modules is not None:
            full_json = css_modules(css, name, args.minify)
            payload = json.loads(full_json)
            if isinstance(args.css_modules, str):
                with open(args.css_modules, "w", encoding="utf-8") as f:
                    f.write(json.dumps(payload["exports"], separators=(",", ":")))
                code = payload["code"]
            elif args.output_file:
                with open(args.output_file + ".json", "w", encoding="utf-8") as f:
                    f.write(json.dumps(payload["exports"], separators=(",", ":")))
                code = payload["code"]
            else:
                code = full_json
        else:
            code = render(css, args.minify)
        write_output(args, code, args.inputs)
        if args.sourcemap and args.output_file:
            with open(args.output_file + ".map", "w", encoding="utf-8") as f:
                json.dump({"version": 3, "sources": args.inputs, "mappings": ""}, f)
        return 0
    except Exception as e:
        if args.error_recovery:
            sys.stdout.write(css if "css" in locals() else "")
            return 0
        print(str(e), file=sys.stderr)
        return 1


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
