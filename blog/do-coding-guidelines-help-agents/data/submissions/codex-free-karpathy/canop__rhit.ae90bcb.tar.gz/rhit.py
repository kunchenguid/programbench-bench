#!/usr/bin/env python3
import argparse, csv, gzip, json, os, re, sys
from dataclasses import dataclass
from datetime import datetime, time
from collections import Counter, defaultdict

MONTHS={m:i+1 for i,m in enumerate('Jan Feb Mar Apr May Jun Jul Aug Sep Oct Nov Dec'.split())}
LOG_RE=re.compile(r'^(\S+) \S+ \S+ \[([^\]]+)\] "([A-Z]+) (\S+) [^"]*" (\d{3}) (\d+|-) "([^"]*)" "[^"]*"')
DEFAULT_FIELDS=['date','status','ref','path']
ALL_FIELDS=['date','time','method','status','ip','ref','path']
RESOURCE_RE=re.compile(r'\.(?:png|jpe?g|gif|svg|ico|css|js|map|woff2?|ttf|eot|webp|avif|mp4|mp3|pdf|zip|gz|tgz|bz2|xz)$',re.I)

@dataclass
class Hit:
    raw:str; dt:datetime; ip:str; method:str; path:str; status:str; bytes:int; ref:str
    @property
    def date(self): return self.dt.strftime('%Y/%m/%d')
    @property
    def tim(self): return self.dt.strftime('%H:%M:%S')


def parse_line(line):
    m=LOG_RE.match(line.rstrip('\n'))
    if not m: return None
    ip,ds,method,path,status,b,ref=m.groups()
    # 21/Jan/2021:05:49:52 +0000
    try:
        left=ds.split()[0]
        day,mon,rest=left.split('/',2)
        year,hh,mm,ss=rest.split(':')
        dt=datetime(int(year),MONTHS[mon],int(day),int(hh),int(mm),int(ss))
    except Exception:
        return None
    return Hit(line.rstrip('\n'),dt,ip,method,path,status,0 if b=='-' else int(b),ref)


def open_text(path):
    if path.endswith('.gz'):
        return gzip.open(path,'rt',errors='replace')
    return open(path,'rt',errors='replace')


def collect_paths(args):
    if not args:
        p='/var/log/nginx'
        if not os.path.exists(p):
            print('No nginx log found at default location, do you have nginx set up?', file=sys.stderr)
            print('If necessary, provide the path to the log file(s) as argument.', file=sys.stderr)
            print("More information with 'rhit --help'.", file=sys.stderr)
            print('Error: PathNotFound("/var/log/nginx")', file=sys.stderr)
            sys.exit(1)
        args=[p]
    out=[]
    for p in args:
        if os.path.isdir(p):
            for root,_,files in os.walk(p):
                for n in sorted(files):
                    full=os.path.join(root,n)
                    if n.endswith(('.log','.log.1','.gz')) or 'access' in n:
                        out.append(full)
        elif os.path.exists(p):
            out.append(p)
        else:
            print(f'Error: PathNotFound("{p}")', file=sys.stderr); sys.exit(1)
    return out


def load_hits(paths):
    hits=[]
    for p in paths:
        try:
            with open_text(p) as f:
                for line in f:
                    h=parse_line(line)
                    if h: hits.append(h)
        except Exception as e:
            print(f'Error: {e}', file=sys.stderr); sys.exit(1)
    return hits


def match_re_expr(expr, value):
    if expr is None: return True
    expr=expr.strip()
    if not expr: return True
    # Common documented form: comma means AND, leading ! negates a regex.
    parts=[p.strip() for p in expr.split(',') if p.strip()]
    for p in parts:
        neg=p.startswith('!')
        if neg: p=p[1:].strip()
        try: ok=re.search(p,value) is not None
        except re.error: ok=p in value
        if neg: ok=not ok
        if not ok: return False
    return True


def match_status(spec, status):
    if spec is None: return True
    st=int(status)
    positives=[]; negatives=[]
    for raw in spec.split(','):
        raw=raw.strip();
        if not raw: continue
        neg=raw.startswith('!')
        if neg: raw=raw[1:]
        def one():
            if re.fullmatch(r'\dxx', raw): return st//100==int(raw[0])
            if re.fullmatch(r'\d{3}-\d{3}', raw):
                a,b=map(int,raw.split('-')); return a<=st<=b
            return st==int(raw)
        (negatives if neg else positives).append(one())
    if any(negatives): return False
    return any(positives) if positives else True


def parse_date_token(tok, default_year=None):
    comps=tok.split('T',1); datep=comps[0]; timep=comps[1] if len(comps)>1 else None
    bits=[int(x) for x in datep.split('/') if x!='']
    if len(bits)==1: y,m,d=bits[0],1,1; max_kind='year'
    elif len(bits)==2:
        if default_year and bits[0]<=12: y,m,d=default_year,bits[0],bits[1]; max_kind='day'
        else: y,m,d=bits[0],bits[1],1; max_kind='month'
    else: y,m,d=bits[0],bits[1],bits[2]; max_kind='day'
    hh=mm=ss=0
    if timep:
        tbits=[int(x) for x in timep.split(':')]
        hh=tbits[0]; mm=tbits[1] if len(tbits)>1 else 0; ss=tbits[2] if len(tbits)>2 else 0; max_kind='second'
    start=datetime(y,m,d,hh,mm,ss)
    if max_kind=='year': end=datetime(y,12,31,23,59,59)
    elif max_kind=='month':
        import calendar; end=datetime(y,m,calendar.monthrange(y,m)[1],23,59,59)
    elif max_kind=='day' and not timep: end=datetime(y,m,d,23,59,59)
    else: end=start
    return start,end


def match_date(spec,h,years):
    if spec is None: return True
    neg=spec.startswith('!'); s=spec[1:] if neg else spec
    default_year=years[0] if len(years)==1 else None
    ok=True
    try:
        if s.startswith('>'):
            a,_=parse_date_token(s[1:],default_year); ok=h.dt>a
        elif s.startswith('<'):
            _,b=parse_date_token(s[1:],default_year); ok=h.dt<b
        elif '-' in s and not s.startswith('-'):
            a,b=s.split('-',1); start,_=parse_date_token(a,default_year); _,end=parse_date_token(b,default_year); ok=start<=h.dt<=end
        else:
            start,end=parse_date_token(s,default_year); ok=start<=h.dt<=end
    except Exception:
        print('Error: DateTime(IntExpected(ParseIntError { kind: Empty }))', file=sys.stderr); sys.exit(1)
    return not ok if neg else ok


def match_time(spec,h):
    if spec is None: return True
    s=spec.strip(); op=None
    if s and s[0] in '<>!': op=s[0]; s=s[1:]
    try:
        bits=[int(x) for x in s.split(':')]
        t=time(bits[0], bits[1] if len(bits)>1 else 0, bits[2] if len(bits)>2 else 0)
    except Exception:
        print('Error: TimeFilter(InvalidFormat)', file=sys.stderr); sys.exit(1)
    ht=h.dt.time()
    if op=='>': return ht>t
    if op=='<': return ht<t
    if op=='!': return ht!=t
    return ht==t


def filter_hits(hits,args):
    years=sorted(set(h.dt.year for h in hits))
    res=[]
    for h in hits:
        if not match_date(args.date,h,years): continue
        if not match_time(args.time,h): continue
        if args.ip is not None and not match_re_expr(args.ip,h.ip): continue
        if args.method is not None:
            m=args.method; neg=m.startswith('!'); val=m[1:] if neg else m
            ok=(h.method==val) if val not in ('none','other') else False
            if neg: ok=not ok
            if not ok: continue
        if args.path is not None and not match_re_expr(args.path,h.path): continue
        if args.referer is not None and not match_re_expr(args.referer,h.ref): continue
        if not match_status(args.status,h.status): continue
        res.append(h)
    return res


def output_raw(hits):
    for h in hits: print(h.raw)

def csvq(s):
    return '"' + str(s).replace('"', '""') + '"'

def output_csv(hits):
    print('date,time,remote address,method,path,status,bytes sent,referer')
    for h in hits:
        print(','.join([h.date,h.tim,h.ip,h.method,csvq(h.path),h.status,str(h.bytes),csvq(h.ref)]))

def output_json(hits):
    arr=[{'date':h.date,'time':h.tim,'remote_addr':h.ip,'method':h.method,'path':h.path,'status':h.status,'bytes_sent':h.bytes,'referer':h.ref} for h in hits]
    print(json.dumps(arr, indent=2))


def parse_fields(s):
    if not s: return DEFAULT_FIELDS[:]
    fields=DEFAULT_FIELDS[:]
    tokens=re.split(r'[,+]',s)
    if s.startswith('a') or s.startswith('all'):
        fields=ALL_FIELDS[:]
    elif not s.startswith(('+','-')):
        fields=[]
    for tok in re.finditer(r'([+-]?)([A-Za-z]+)',s):
        sign,name=tok.group(1),tok.group(2)
        fmap={'d':'date','date':'date','t':'time','time':'time','m':'method','method':'method','s':'status','status':'status','i':'ip','ip':'ip','r':'ref','ref':'ref','referer':'ref','p':'path','path':'path','a':'ALL','all':'ALL'}
        f=fmap.get(name)
        if f=='ALL':
            if sign=='-': fields=[]
            else: fields=ALL_FIELDS[:]
        elif f:
            if sign=='-': fields=[x for x in fields if x!=f]
            elif f in fields: fields=[x for x in fields if x!=f]+[f]
            else: fields.append(f)
    return fields or DEFAULT_FIELDS[:]


def table(title, rows, headers):
    print(title)
    print(' | '.join(headers))
    print('-+-'.join('-'*len(h) for h in headers))
    for r in rows: print(' | '.join(str(x) for x in r))


def output_tables(hits,args):
    if not hits:
        print('0 hits')
        return
    total_b=sum(h.bytes for h in hits); ds=[h.date for h in hits]
    print(f'{len(hits)} hits and {total_b} from {min(ds)} to {max(ds)}')
    fields=parse_fields(args.fields)
    max_rows=max(3, {0:3,1:10,2:20,3:40,4:80,5:160,6:100000}.get(args.length,10))
    total=len(hits)
    for f in fields:
        if f=='date': key=lambda h:h.date; name='date'; title='dates'
        elif f=='time': key=lambda h:h.tim[:2]+':00'; name='time'; title='hours'
        elif f=='method': key=lambda h:h.method; name='method'; title='HTTP methods'
        elif f=='status': key=lambda h:h.status; name='status'; title='HTTP status codes'
        elif f=='ip': key=lambda h:h.ip; name='remote address'; title='remote addresses'
        elif f=='ref': key=lambda h:h.ref; name='referrer'; title='referrers'
        else: key=lambda h:h.path; name='path'; title='paths'
        subset=hits
        if f=='path' and not args.all_paths:
            subset=[h for h in hits if not RESOURCE_RE.search(h.path)]
        groups=defaultdict(lambda:[0,0])
        for h in subset:
            k=key(h)
            if f=='ref' and k=='-': continue
            groups[k][0]+=1; groups[k][1]+=h.bytes
        metric=1 if args.key=='bytes' else 0
        rows=[]
        for i,(k,(cnt,byt)) in enumerate(sorted(groups.items(), key=lambda kv:(-kv[1][metric], kv[0]))[:max_rows],1):
            rows.append([i,k,cnt,f'{cnt*100/total:.1f}%',byt])
        if f=='date': rows=[[k,v[0],v[1]] for k,v in sorted(groups.items())]; table('',rows,['date','hits','bytes'])
        else:
            suffix='' if f!='path' or args.all_paths else ' (excluding resources like images, css, etc.)'
            print(f'{len(groups)} {title}{suffix}. ')
            table('',rows,['#',name,'hits','%','bytes'])

def build_parser():
    p=argparse.ArgumentParser(add_help=False)
    p.add_argument('files', nargs='*')
    p.add_argument('--help', action='store_true'); p.add_argument('--version', action='store_true')
    p.add_argument('--color', choices=['auto','yes','no'], default='auto')
    p.add_argument('-k','--key', default='hits'); p.add_argument('-l','--length', type=int, default=1)
    p.add_argument('-f','--fields', '--field', dest='fields')
    p.add_argument('-c','--changes', action='store_true')
    p.add_argument('-d','--date'); p.add_argument('-i','--ip'); p.add_argument('-m','--method')
    p.add_argument('-p','--path'); p.add_argument('-r','--referer'); p.add_argument('-s','--status'); p.add_argument('-t','--time')
    p.add_argument('-a','--all', dest='all_paths', action='store_true')
    p.add_argument('--no-name-check', action='store_true'); p.add_argument('--silent-load', action='store_true')
    p.add_argument('-o','--output', default='tables')
    return p

def print_help():
    print('rhit 2.0.4')
    print('\nRhit analyzes your nginx logs.')
    print('\nUsage: rhit [options] [FILES]')
    print('\nOptions: --help --version --color auto|yes|no -k/--key hits|bytes -l/--length N -f/--fields FIELDS')
    print('         -d/--date DATE -i/--ip IP -m/--method METHOD -p/--path PATH -r/--referer REFERER')
    print('         -s/--status STATUS -t/--time TIME -a/--all -o/--output tables|raw|csv|json --silent-load')


def main():
    parser=build_parser(); args=parser.parse_args()
    if args.help: print_help(); return 0
    if args.version: print('rhit 2.0.4'); return 0
    if args.key and args.key[0]=='b': args.key='bytes'
    else: args.key='hits'
    out=args.output.lower(); out={'r':'raw','c':'csv','j':'json','t':'tables'}.get(out[0],out) if out else 'tables'
    hits=load_hits(collect_paths(args.files))
    hits=filter_hits(hits,args)
    if out=='raw': output_raw(hits)
    elif out=='csv': output_csv(hits)
    elif out=='json': output_json(hits)
    else: output_tables(hits,args)
    return 0
if __name__=='__main__': sys.exit(main())
