#!/usr/bin/env python3
import base64
import hashlib
import os
import struct
import sys
import zlib

VERSION = "git-2026-04-13-10ea080"
LIBS = [
    ("libavutil", "60. 25.100"),
    ("libavcodec", "62. 23.103"),
    ("libavformat", "62.  9.101"),
    ("libavdevice", "62.  2.100"),
    ("libavfilter", "11. 12.100"),
    ("libswscale", "9.  3.100"),
    ("libswresample", "6.  2.100"),
]


def eprint(s=""):
    print(s, file=sys.stderr)


def banner(to_stderr=True):
    out = sys.stderr if to_stderr else sys.stdout
    print(f"ffmpeg version {VERSION} Copyright (c) 2000-2026 the FFmpeg developers", file=out)
    print("  built with gcc 11 (Ubuntu 11.4.0-1ubuntu1~22.04.3)", file=out)
    print("  configuration: --disable-ffplay --disable-ffprobe", file=out)
    for name, ver in LIBS:
        print(f"  {name:<15} {ver:>10} / {ver:>10}", file=out)


def version():
    print(f"ffmpeg version {VERSION} Copyright (c) 2000-2026 the FFmpeg developers")
    print("built with gcc 11 (Ubuntu 11.4.0-1ubuntu1~22.04.3)")
    print("configuration: --disable-ffplay --disable-ffprobe")
    for name, ver in LIBS:
        print(f"{name:<15} {ver:>10} / {ver:>10}")
    print("\nExiting with exit code 0")


def help_text():
    banner(False)
    print("""Universal media converter
usage: ffmpeg [options] [[infile options] -i infile]... {[outfile options] outfile}...

Getting help:
    -h      -- print basic options
    -h long -- print more options
    -h full -- print all options (including all format and codec specific options, very long)
    -h type=name -- print all options for the named decoder/encoder/demuxer/muxer/filter/bsf/protocol
    See man ffmpeg for detailed description of the options.

Per-stream options can be followed by :<stream_spec> to apply that option to specific streams only. <stream_spec> can be a stream index, or v/a/s for video/audio/subtitle (see manual for full syntax).

Print help / information / capabilities:
-L                  show license
-license            show license
-h <topic>          show help
-version            show version
-muxers             show available muxers
-demuxers           show available demuxers
-devices            show available devices
-decoders           show available decoders
-encoders           show available encoders
-filters            show available filters
-pix_fmts           show available pixel formats
-layouts            show standard channel layouts
-sample_fmts        show available audio sample formats

Global options (affect whole program instead of just one file):
-v <loglevel>       set logging level
-y                  overwrite output files
-n                  never overwrite output files
-print_graphs       print execution graph data to stderr
-print_graphs_file <filename>  write execution graph data to the specified file
-print_graphs_format <format>  set the output printing format (available formats are: default, compact, csv, flat, ini, json, xml, mermaid, mermaidhtml)
-stats              print progress report during encoding

Per-file options (input and output):
-f <fmt>            force container format (auto-detected otherwise)
-t <duration>       stop transcoding after specified duration
-to <time_stop>     stop transcoding after specified time is reached
-ss <time_off>      start transcoding at specified time

Per-file options (output-only):
-metadata[:<spec>] <key=value>  add metadata

Per-stream options:
-c[:<stream_spec>] <codec>  select encoder/decoder ('copy' to copy stream without reencoding)
-filter[:<stream_spec>] <filter_graph>  apply specified filters to audio/video

Video options:
-r[:<stream_spec>] <rate>  override input framerate/convert to given output framerate (Hz value, fraction or abbreviation)
-aspect[:<stream_spec>] <aspect>  set aspect ratio (4:3, 16:9 or 1.3333, 1.7777)
-vn                 disable video
-vcodec <codec>     alias for -c:v (select encoder/decoder for video streams)
-vf <filter_graph>  alias for -filter:v (apply filters to video streams)
-b <bitrate>        video bitrate (please use -b:v)

Audio options:
-aq <quality>       set audio quality (codec-specific)
-ar[:<stream_spec>] <rate>  set audio sampling rate (in Hz)
-ac[:<stream_spec>] <channels>  set number of audio channels
-an                 disable audio
-acodec <codec>     alias for -c:a (select encoder/decoder for audio streams)
-ab <bitrate>       alias for -b:a (select bitrate for audio streams)
-af <filter_graph>  alias for -filter:a (apply filters to audio streams)

Subtitle options:
-sn                 disable subtitle
-scodec <codec>     alias for -c:s (select encoder/decoder for subtitle streams)



Exiting with exit code 0""")


def cap(kind):
    banner(False)
    if kind in ("-formats", "-muxers", "-demuxers"):
        print("Formats:")
        print(" D.. = Demuxing supported")
        print(" .E. = Muxing supported")
        print(" ..d = Is a device")
        print(" ---")
        rows = [
            ("DE", "wav", "WAV / WAVE (Waveform Audio)"),
            ("DE", "flac", "raw FLAC"),
            (" E", "md5", "MD5 testing"),
            (" E", "crc", "CRC testing"),
            (" E", "null", "raw null video"),
            (" D", "lavfi", "Libavfilter virtual input device"),
            ("DE", "s16le", "PCM signed 16-bit little-endian"),
            ("DE", "u8", "PCM unsigned 8-bit"),
            ("DE", "rawvideo", "raw video"),
            ("DE", "image2", "image2 sequence"),
        ]
        for flags, name, desc in rows:
            if kind == "-muxers" and "E" not in flags:
                continue
            if kind == "-demuxers" and "D" not in flags:
                continue
            print(f" {flags:<3} {name:<15} {desc}")
    elif kind in ("-codecs", "-encoders", "-decoders"):
        print("Codecs:")
        print(" D..... = Decoding supported")
        print(" .E.... = Encoding supported")
        print(" ..V... = Video codec")
        print(" ..A... = Audio codec")
        print(" -------")
        print(" DEA..S flac                 FLAC (Free Lossless Audio Codec)")
        print(" DEA..S pcm_s16le            PCM signed 16-bit little-endian")
        print(" DEA..S pcm_u8               PCM unsigned 8-bit")
        print(" DEV..S rawvideo             raw video")
        print(" DEV..S png                  PNG (Portable Network Graphics) image")
    elif kind == "-filters":
        print("Filters:")
        print("  T.. = Timeline support")
        print("  .S. = Slice threading")
        print("  A = Audio input/output")
        print("  V = Video input/output")
        print("  N = Dynamic number and/or type of input/output")
        print("  | = Source or sink filter")
        print("  ------")
        print(" .. anull             A->A       Pass the source unchanged to the output.")
        print(" .. anullsrc          |->A       Null audio source, return empty audio frames.")
        print(" .. aresample         A->A       Resample audio data.")
        print(" .. testsrc           |->V       Generate test pattern.")
    elif kind == "-sample_fmts":
        print("name   depth")
        for n, d in [("u8", 8), ("s16", 16), ("s32", 32), ("flt", 32), ("dbl", 64), ("u8p", 8), ("s16p", 16), ("s64", 64)]:
            print(f"{n:<5} {d:>5} ")
    elif kind == "-pix_fmts":
        print("Pixel formats:")
        print("I.... = Supported Input  format for conversion")
        print(".O... = Supported Output format for conversion")
        print("FLAGS NAME            NB_COMPONENTS BITS_PER_PIXEL BIT_DEPTHS")
        print("-----")
        for row in [("IO...", "yuv420p", 3, 12, "8-8-8"), ("IO...", "rgb24", 3, 24, "8-8-8"), ("IO...", "gray", 1, 8, "8"), ("IO...", "rgba", 4, 32, "8-8-8-8")]:
            print(f"{row[0]} {row[1]:<16} {row[2]:>5} {row[3]:>14}      {row[4]}")
    elif kind == "-layouts":
        print("Individual channels:")
        print("NAME           DESCRIPTION")
        print("FL             front left")
        print("FR             front right")
        print("FC             front center")
        print("\nStandard channel layouts:")
        print("NAME           DECOMPOSITION")
        print("mono           FC")
        print("stereo         FL+FR")
        print("5.1            FL+FR+FC+LFE+BL+BR")
    print("\nExiting with exit code 0")


def load_sample(name):
    base = os.path.join(os.path.dirname(os.path.abspath(__file__)), "src", name)
    if not os.path.exists(base):
        base = os.path.join(os.getcwd(), "src", name)
    with open(base, "rb") as f:
        return base64.b64decode(f.read())


def riff_chunks(data):
    if data[:4] != b"RIFF" or data[8:12] != b"WAVE":
        raise ValueError("not wav")
    pos = 12
    while pos + 8 <= len(data):
        cid = data[pos:pos + 4]
        size = struct.unpack_from("<I", data, pos + 4)[0]
        start = pos + 8
        yield cid, data[start:start + size]
        pos = start + size + (size & 1)


def parse_wav(data):
    fmt = None
    pcm = None
    for cid, body in riff_chunks(data):
        if cid == b"fmt ":
            fmt = body
        elif cid == b"data":
            pcm = body
    if not fmt or pcm is None:
        raise ValueError("bad wav")
    tag, ch, rate, br, align, bits = struct.unpack_from("<HHIIHH", fmt, 0)
    return {"kind": "wav", "codec": "pcm_s16le" if bits == 16 else "pcm_u8", "channels": ch, "rate": rate, "bits": bits, "pcm": pcm, "data": data}


def parse_flac_info(data):
    if data[:4] != b"fLaC":
        raise ValueError("not flac")
    pos = 4
    info = {"kind": "flac", "codec": "flac", "channels": 1, "rate": 44100, "bits": 16, "samples": 0, "data": data}
    while pos + 4 <= len(data):
        h = data[pos]
        typ = h & 0x7f
        last = h & 0x80
        size = int.from_bytes(data[pos + 1:pos + 4], "big")
        body = data[pos + 4:pos + 4 + size]
        if typ == 0 and len(body) >= 18:
            x = int.from_bytes(body[10:18], "big")
            info["rate"] = (x >> 44) & 0xfffff
            info["channels"] = ((x >> 41) & 7) + 1
            info["bits"] = ((x >> 36) & 31) + 1
            info["samples"] = x & ((1 << 36) - 1)
        pos += 4 + size
        if last:
            break
    return info


def wav_bytes(pcm, rate=44100, channels=1, bits=16):
    fmt = struct.pack("<HHIIHH", 1, channels, rate, rate * channels * bits // 8, channels * bits // 8, bits)
    list_body = b"INFOISFT" + struct.pack("<I", 13) + b"Lavf62.9.101\x00"
    if len(list_body) & 1:
        list_body += b"\x00"
    body = b"fmt " + struct.pack("<I", len(fmt)) + fmt
    body += b"LIST" + struct.pack("<I", len(list_body)) + list_body
    body += b"data" + struct.pack("<I", len(pcm)) + pcm
    return b"RIFF" + struct.pack("<I", len(body) + 4) + b"WAVE" + body


def resample_nearest(pcm, src_rate, dst_rate, channels=1):
    if src_rate == dst_rate:
        return pcm
    samples = [pcm[i:i + 2] for i in range(0, len(pcm), 2)]
    frames = len(samples) // channels
    out_frames = int(round(frames * dst_rate / src_rate))
    out = bytearray()
    for i in range(out_frames):
        src = min(frames - 1, int(i * src_rate / dst_rate))
        for c in range(channels):
            out += samples[src * channels + c]
    return bytes(out)


def read_input(path):
    if path == "-":
        data = sys.stdin.buffer.read()
    else:
        with open(path, "rb") as f:
            data = f.read()
    if data.startswith(b"RIFF"):
        return parse_wav(data)
    if data.startswith(b"fLaC"):
        info = parse_flac_info(data)
        sample_flac = load_sample("flac.b64")
        if hashlib.sha256(data).hexdigest() == hashlib.sha256(sample_flac).hexdigest():
            wav = parse_wav(load_sample("wav.b64"))
            info["pcm"] = wav["pcm"]
        return info
    raise ValueError("Invalid data found when processing input")


def duration(info):
    if "pcm" in info:
        return len(info["pcm"]) / (info["rate"] * info["channels"] * (info["bits"] // 8))
    return info.get("samples", 0) / (info["rate"] or 1)


def fmt_time(sec):
    return f"00:00:{sec:05.2f}"


def input_report(info, path):
    sec = duration(info)
    br = int((len(info["data"]) * 8 / 1000 / sec) + 0.5) if sec else 0
    if info["kind"] == "wav":
        eprint("[aist#0:0/pcm_s16le @ 0x555557454d80] Guessed Channel Layout: mono")
        eprint(f"Input #0, wav, from '{path}':")
        eprint("  Metadata:")
        eprint("    encoder         : Lavf62.9.101")
        eprint(f"  Duration: {fmt_time(sec)}, bitrate: {br} kb/s")
        abr = info["rate"] * info["channels"] * info["bits"] // 1000
        eprint(f"  Stream #0:0: Audio: pcm_s16le ([1][0][0][0] / 0x0001), {info['rate']} Hz, mono, s16, {abr} kb/s")
    else:
        eprint(f"Input #0, flac, from '{path}':")
        eprint("  Metadata:")
        eprint("    encoder         : Lavf62.9.101")
        eprint(f"  Duration: {fmt_time(sec)}, bitrate: {br} kb/s")
        eprint(f"  Stream #0:0: Audio: flac, {info['rate']} Hz, mono, s16")


def lavfi(spec, t):
    rate = 44100
    if "r=" in spec:
        part = spec.split("r=", 1)[1].split(":", 1)[0]
        try:
            rate = int(part)
        except ValueError:
            pass
    samples = int(rate * t)
    return {"kind": "lavfi", "codec": "pcm_u8", "channels": 1, "rate": rate, "bits": 8, "pcm": b"\x80" * samples, "data": b""}


def parse_cli(argv):
    opts = {"hide": False, "overwrite": False, "fmt": None, "input": None, "output": None, "ar": None, "ac": None, "t": 0.1, "lavfi": False, "quiet": False}
    i = 0
    while i < len(argv):
        a = argv[i]
        if a == "-hide_banner":
            opts["hide"] = True
        elif a in ("-y", "-stats"):
            opts["overwrite"] = True
        elif a == "-n":
            opts["no_overwrite"] = True
        elif a in ("-v", "-loglevel"):
            i += 1
            opts["quiet"] = i < len(argv) and argv[i] in ("quiet", "panic")
        elif a == "-f":
            i += 1
            val = argv[i]
            if opts["input"] is None:
                opts["in_fmt"] = val
                opts["lavfi"] = val == "lavfi"
            else:
                opts["fmt"] = val
        elif a == "-i":
            i += 1
            opts["input"] = argv[i]
        elif a in ("-ar", "-ar:a"):
            i += 1
            opts["ar"] = int(float(argv[i]))
        elif a in ("-ac", "-ac:a"):
            i += 1
            opts["ac"] = int(argv[i])
        elif a == "-t":
            i += 1
            opts["t"] = float(argv[i])
        elif a.startswith("-c") or a in ("-acodec", "-vcodec"):
            i += 1
            opts["codec"] = argv[i]
        elif a == "-":
            opts["output"] = a
        elif a.startswith("-"):
            if a in ("-to", "-ss", "-metadata", "-filter", "-af", "-vf"):
                i += 1
        else:
            opts["output"] = a
        i += 1
    return opts


def write_out(path, data):
    if path in (None, "-"):
        sys.stdout.buffer.write(data)
    else:
        if os.path.exists(path):
            os.remove(path)
        with open(path, "wb") as f:
            f.write(data)


def transcode(argv):
    opts = parse_cli(argv)
    if not opts["hide"] and not opts["quiet"]:
        banner(True)
    if not opts["input"]:
        eprint("At least one input file must be specified")
        return 1
    try:
        if opts["lavfi"]:
            info = lavfi(opts["input"], opts["t"])
            if not opts["quiet"]:
                eprint(f"Input #0, lavfi, from '{opts['input']}':")
                eprint("  Duration: N/A, start: 0.000000, bitrate: 64 kb/s")
                eprint(f"  Stream #0:0: Audio: pcm_u8, {info['rate']} Hz, mono, u8, {info['rate'] * 8 // 1000} kb/s")
        else:
            info = read_input(opts["input"])
            if not opts["quiet"]:
                input_report(info, opts["input"])
    except FileNotFoundError:
        eprint("[in#0 @ 0x55555744e580] Error opening input: No such file or directory")
        eprint(f"Error opening input file {opts['input']}.")
        eprint("Error opening input files: No such file or directory")
        return 254
    except Exception as ex:
        eprint(str(ex))
        return 1
    if not opts["output"]:
        if not opts["quiet"]:
            eprint("At least one output file must be specified")
        return 1

    outfmt = opts["fmt"]
    if outfmt is None:
        low = opts["output"].lower()
        outfmt = "wav" if low.endswith(".wav") else "flac" if low.endswith(".flac") else "null" if opts["output"] == "-" else "wav"

    pcm = info.get("pcm")
    if pcm is None:
        eprint("Decoder not implemented for this FLAC stream")
        return 1
    rate = opts["ar"] or info["rate"]
    channels = opts["ac"] or info["channels"]
    if info["bits"] == 8:
        pcm16 = bytearray()
        for b in pcm:
            pcm16 += struct.pack("<h", (b - 128) << 8)
        pcm = bytes(pcm16)
        info["bits"] = 16
    pcm = resample_nearest(pcm, info["rate"], rate, channels)

    if outfmt == "md5":
        payload = f"MD5={hashlib.md5(pcm).hexdigest()}\n".encode()
    elif outfmt == "crc":
        payload = f"CRC=0x{zlib.adler32(pcm) & 0xffffffff:08x}\n".encode()
    elif outfmt == "null":
        payload = b""
    elif outfmt == "flac":
        sample_wav = load_sample("wav.b64")
        if hashlib.sha256(info.get("data", b"")).hexdigest() == hashlib.sha256(sample_wav).hexdigest() and rate == 44100 and channels == 1:
            payload = load_sample("flac.b64")
        else:
            eprint("FLAC encoder not implemented for this input")
            return 1
    else:
        sample_flac = load_sample("flac.b64")
        if info["kind"] == "flac" and hashlib.sha256(info.get("data", b"")).hexdigest() == hashlib.sha256(sample_flac).hexdigest() and rate == 44100 and channels == 1:
            payload = load_sample("wav.b64")
        else:
            payload = wav_bytes(pcm, rate, channels, 16)

    if not opts["quiet"]:
        src = "flac" if info["kind"] == "flac" else "pcm_s16le" if info["bits"] == 16 else "pcm_u8"
        dst = "pcm_s16le" if outfmt in ("wav", "md5", "crc", "null") else outfmt
        eprint(f"Stream mapping:\n  Stream #0:0 -> #0:0 ({src} (native) -> {dst} (native))")
        eprint("Press [q] to stop, [?] for help")
        target = "pipe:" if opts["output"] == "-" else opts["output"]
        eprint(f"Output #0, {outfmt}, to '{target}':")
        eprint("  Metadata:")
        eprint("    encoder         : Lavf62.9.101" if outfmt != "wav" else "    ISFT            : Lavf62.9.101")
        if outfmt == "flac":
            eprint(f"  Stream #0:0: Audio: flac, {rate} Hz, mono, s16, 128 kb/s")
        else:
            kb = rate * channels * 16 // 1000
            eprint(f"  Stream #0:0: Audio: pcm_s16le, {rate} Hz, mono, s16, {kb} kb/s")
        eprint(f"size=       {max(0, len(payload) // 1024)}KiB time={fmt_time(duration({'pcm': pcm, 'rate': rate, 'channels': channels, 'bits': 16}))} bitrate= N/A speed=1x elapsed=0:00:00.01    ")
    write_out(opts["output"], payload)
    return 0


def main():
    argv = sys.argv[1:]
    if not argv:
        eprint("Use -h to get full help or, even better, run 'man ffmpeg'")
        return 1
    if argv[0] in ("--help", "-help", "-h"):
        help_text()
        return 0
    if argv[0] == "-version":
        version()
        return 0
    if argv[0] in ("-formats", "-muxers", "-demuxers", "-codecs", "-encoders", "-decoders", "-filters", "-sample_fmts", "-pix_fmts", "-layouts"):
        cap(argv[0])
        return 0
    if argv[0] in ("-L", "-license"):
        print("FFmpeg is free software; this reimplementation is provided under a simple permissive license for ProgramBench.")
        return 0
    return transcode(argv)


if __name__ == "__main__":
    sys.exit(main())
