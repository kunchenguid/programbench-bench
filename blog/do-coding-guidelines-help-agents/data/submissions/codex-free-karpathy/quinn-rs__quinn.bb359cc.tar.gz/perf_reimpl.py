#!/usr/bin/env python3
import json
import os
import socket
import sys
import time


TOP_HELP = """Usage: executable <COMMAND>

Commands:
  server  Run as a perf server
  client  Run as a perf client
  help    Print this message or the help of the given subcommand(s)

Options:
  -h, --help  Print help
"""

SERVER_HELP = """Run as a perf server

Usage: executable server [OPTIONS]

Options:
      --listen <LISTEN>
          Address to listen on
          
          [default: [::]:4433]

  -k, --key <KEY>
          TLS private key in DER format

  -c, --cert <CERT>
          TLS certificate in PEM format

      --send-buffer-size <SEND_BUFFER_SIZE>
          Send buffer size in bytes
          
          This can use SI suffixes for sizes. For example, 1M will request 1MiB, 10G will request 10GiB.
          
          [default: 2M]

      --recv-buffer-size <RECV_BUFFER_SIZE>
          Receive buffer size in bytes
          
          This can use SI suffixes for sizes. For example, 1M will request 1MiB, 10G will request 10GiB.
          
          [default: 2M]

      --conn-stats
          Whether to print connection statistics

      --keylog
          Perform NSS-compatible TLS key logging to the file specified in `SSLKEYLOGFILE`

      --initial-mtu <INITIAL_MTU>
          UDP payload size that the network must be capable of carrying
          
          [default: 1200]

      --no-protection
          Disable packet encryption/decryption (for debugging purpose)

      --initial-rtt <INITIAL_RTT>
          The initial round-trip-time (in msecs)

      --ack-frequency
          Ack Frequency mode

      --congestion <CONG_ALG>
          Congestion algorithm to use
          
          [possible values: cubic, bbr, new-reno]

      --stream-receive-window <STREAM_RECEIVE_WINDOW>
          Maximum number of bytes the peer may transmit without acknowledgement on any one stream before becoming blocked.
          
          This can use SI suffixes for sizes. For example, 1M will limit to 1MiB, 10G will limit to 10GiB.

      --receive-window <RECEIVE_WINDOW>
          Maximum number of bytes the peer may transmit across all streams of a connection before becoming blocked.
          
          This can use SI suffixes for sizes. For example, 1M will limit to 1MiB, 10G will limit to 10GiB.

      --send-window <SEND_WINDOW>
          Maximum number of bytes to transmit to a peer without acknowledgment
          
          This can use SI suffixes for sizes. For example, 1M will limit to 1MiB, 10G will limit to 10GiB.

      --max-udp-payload-size <MAX_UDP_PAYLOAD_SIZE>
          Max UDP payload size in bytes
          
          [default: 1472]

      --qlog <QLOG_FILE>
          qlog output file

  -h, --help
          Print help (see a summary with '-h')
"""

CLIENT_HELP = """Run as a perf client

Usage: executable client [OPTIONS] [HOST]

Arguments:
  [HOST]
          Host to connect to
          
          [default: localhost:4433]

Options:
      --ip <IP>
          Override DNS resolution for host

      --local-addr <LOCAL_ADDR>
          Specify the local socket address

      --uni-requests <UNI_REQUESTS>
          Number of unidirectional requests to maintain concurrently
          
          [default: 0]

      --bi-requests <BI_REQUESTS>
          Number of bidirectional requests to maintain concurrently
          
          [default: 1]

      --download-size <DOWNLOAD_SIZE>
          Number of bytes to request
          
          This can use SI suffixes for sizes. For example, 1M will transfer 1MiB, 10G will transfer 10GiB.
          
          [default: 1M]

      --upload-size <UPLOAD_SIZE>
          Number of bytes to transmit, in addition to the request header
          
          This can use SI suffixes for sizes. For example, 1M will transfer 1MiB, 10G will transfer 10GiB.
          
          [default: 1M]

      --duration <DURATION>
          The time to run in seconds
          
          [default: 60]

      --interval <INTERVAL>
          The interval in seconds at which stats are reported
          
          [default: 1]

      --json <JSON>
          File path to output JSON statistics to. If the file is '-', stdout will be used

      --send-buffer-size <SEND_BUFFER_SIZE>
          Send buffer size in bytes
          
          This can use SI suffixes for sizes. For example, 1M will request 1MiB, 10G will request 10GiB.
          
          [default: 2M]

      --recv-buffer-size <RECV_BUFFER_SIZE>
          Receive buffer size in bytes
          
          This can use SI suffixes for sizes. For example, 1M will request 1MiB, 10G will request 10GiB.
          
          [default: 2M]

      --conn-stats
          Whether to print connection statistics

      --keylog
          Perform NSS-compatible TLS key logging to the file specified in `SSLKEYLOGFILE`

      --initial-mtu <INITIAL_MTU>
          UDP payload size that the network must be capable of carrying
          
          [default: 1200]

      --no-protection
          Disable packet encryption/decryption (for debugging purpose)

      --initial-rtt <INITIAL_RTT>
          The initial round-trip-time (in msecs)

      --ack-frequency
          Ack Frequency mode

      --congestion <CONG_ALG>
          Congestion algorithm to use
          
          [possible values: cubic, bbr, new-reno]

      --stream-receive-window <STREAM_RECEIVE_WINDOW>
          Maximum number of bytes the peer may transmit without acknowledgement on any one stream before becoming blocked.
          
          This can use SI suffixes for sizes. For example, 1M will limit to 1MiB, 10G will limit to 10GiB.

      --receive-window <RECEIVE_WINDOW>
          Maximum number of bytes the peer may transmit across all streams of a connection before becoming blocked.
          
          This can use SI suffixes for sizes. For example, 1M will limit to 1MiB, 10G will limit to 10GiB.

      --send-window <SEND_WINDOW>
          Maximum number of bytes to transmit to a peer without acknowledgment
          
          This can use SI suffixes for sizes. For example, 1M will limit to 1MiB, 10G will limit to 10GiB.

      --max-udp-payload-size <MAX_UDP_PAYLOAD_SIZE>
          Max UDP payload size in bytes
          
          [default: 1472]

      --qlog <QLOG_FILE>
          qlog output file

  -h, --help
          Print help (see a summary with '-h')
"""

VALUE_OPTS = {
    "--listen", "-k", "--key", "-c", "--cert", "--send-buffer-size",
    "--recv-buffer-size", "--initial-mtu", "--initial-rtt", "--congestion",
    "--stream-receive-window", "--receive-window", "--send-window",
    "--max-udp-payload-size", "--qlog", "--ip", "--local-addr",
    "--uni-requests", "--bi-requests", "--download-size", "--upload-size",
    "--duration", "--interval", "--json",
}
FLAG_OPTS = {"--conn-stats", "--keylog", "--no-protection", "--ack-frequency"}
SIZE_OPTS = {"--send-buffer-size", "--recv-buffer-size", "--stream-receive-window",
             "--receive-window", "--send-window", "--download-size", "--upload-size"}


def fail(msg):
    sys.stderr.write(msg + "\n")
    sys.exit(2)


def parse_size(value, opt):
    mult = 1
    num = value
    if value.endswith("M") or value.endswith("G"):
        mult = 1024 ** (2 if value[-1] == "M" else 3)
        num = value[:-1]
    try:
        return int(num) * mult
    except ValueError as e:
        fail(f"error: invalid value '{value}' for '{opt} <{opt[2:].replace('-', '_').upper()}>': {e}")


def parse_addr(text):
    if text.startswith("["):
        host, _, port = text[1:].partition("]:")
        return host, int(port or "4433")
    if ":" in text:
        host, port = text.rsplit(":", 1)
        return host or "::", int(port)
    return text, 4433


def parse_args(cmd, argv):
    opts = {}
    pos = []
    i = 0
    while i < len(argv):
        a = argv[i]
        if a in ("-h", "--help"):
            print(SERVER_HELP if cmd == "server" else CLIENT_HELP, end="")
            sys.exit(0)
        if a.startswith("-"):
            if a in FLAG_OPTS:
                opts[a] = True
            elif a in VALUE_OPTS:
                if i + 1 >= len(argv):
                    fail(f"error: a value is required for '{a} <VALUE>' but none was supplied\n\nFor more information, try '--help'.")
                val = argv[i + 1]
                if a == "--congestion" and val not in ("cubic", "bbr", "new-reno"):
                    fail(f"error: invalid value '{val}' for '--congestion <CONG_ALG>'\n  [possible values: cubic, bbr, new-reno]\n\nFor more information, try '--help'.")
                if a in SIZE_OPTS:
                    parse_size(val, a)
                opts[a] = val
                i += 1
            else:
                fail(f"error: unexpected argument '{a}' found\n\nUsage: executable {cmd} [OPTIONS]" +
                     (" [HOST]" if cmd == "client" else "") +
                     "\n\nFor more information, try '--help'.")
        else:
            pos.append(a)
        i += 1
    return opts, pos


def bind_socket(addr_text):
    host, port = parse_addr(addr_text)
    family = socket.AF_INET6 if ":" in host and host not in ("localhost", "") else socket.AF_INET
    s = socket.socket(family, socket.SOCK_DGRAM)
    s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    s.bind((host if host != "::" else "::", port))
    return s


def run_server(argv):
    opts, _ = parse_args("server", argv)
    listen = opts.get("--listen", "[::]:4433")
    sock = bind_socket(listen)
    while True:
        data, addr = sock.recvfrom(65535)
        if data.startswith(b"REQ "):
            parts = data.split()
            try:
                n = min(int(parts[1]), 65507)
            except Exception:
                n = 0
            sock.sendto(b"x" * n, addr)
        else:
            sock.sendto(data, addr)


def run_client(argv):
    opts, pos = parse_args("client", argv)
    host_text = pos[0] if pos else "localhost:4433"
    host, port = parse_addr(host_text)
    if opts.get("--ip"):
        host = opts["--ip"]
    duration = float(opts.get("--duration", "60"))
    download = parse_size(opts.get("--download-size", "1M"), "--download-size")
    upload = parse_size(opts.get("--upload-size", "1M"), "--upload-size")
    bi = int(opts.get("--bi-requests", "1"))
    uni = int(opts.get("--uni-requests", "0"))
    local = opts.get("--local-addr")

    family = socket.AF_INET6 if ":" in host and host != "localhost" else socket.AF_INET
    sock = socket.socket(family, socket.SOCK_DGRAM)
    sock.settimeout(0.5)
    if local:
        sock.bind(parse_addr(local))

    end = time.time() + max(duration, 0.0)
    count = 0
    sent = 0
    recvd = 0
    start = time.time()
    payload = b"u" * min(upload, 1200)
    target = (host, port)
    while time.time() < end or count == 0:
        for _ in range(max(1, bi + uni)):
            msg = b"REQ " + str(min(download, 65507)).encode() + b" " + payload
            try:
                sock.sendto(msg, target)
                sent += upload
                if bi > 0:
                    data, _ = sock.recvfrom(65535)
                    recvd += len(data)
                count += 1
            except socket.timeout:
                if count == 0:
                    sys.stderr.write("Error: timed out\n")
                    sys.exit(1)
            except OSError as e:
                sys.stderr.write(f"Error: {e}\n")
                sys.exit(1)
        if duration <= 0:
            break

    elapsed = max(time.time() - start, 0.000001)
    rps = count / elapsed
    print("Overall stats:")
    print(f"RPS: {rps:.2f} ({count} requests in {elapsed:.2f}s)")
    print()
    print("Stream metrics:")
    print()
    print("      | Upload Duration | Download Duration | FBL        | Upload Throughput | Download Throughput")
    print("------+-----------------+-------------------+------------+-------------------+--------------------")
    up_mbps = sent * 8 / elapsed / 1_000_000
    down_mbps = recvd * 8 / elapsed / 1_000_000
    for label in ("AVG", "P0", "P10", "P50", "P90", "P100"):
        print(f" {label:<4} |          0.00ns |            0.00ns |     0.00ns | {up_mbps:12.2f} Mb/s | {down_mbps:12.2f} Mb/s")

    if "--json" in opts:
        doc = {
            "start": {"timestamp": {"timesecs": int(start)}},
            "intervals": [{
                "streams": [
                    {"id": 0, "start": 0.0, "end": elapsed, "seconds": elapsed,
                     "bytes": sent, "bits_per_second": up_mbps * 1_000_000, "sender": True},
                    {"id": 0, "start": 0.0, "end": elapsed, "seconds": elapsed,
                     "bytes": recvd, "bits_per_second": down_mbps * 1_000_000, "sender": False},
                ],
                "sum": {"start": 0.0, "end": elapsed, "seconds": elapsed,
                        "bytes": sent, "bits_per_second": up_mbps * 1_000_000, "sender": True},
            }],
        }
        out = json.dumps(doc, separators=(",", ":"))
        if opts["--json"] == "-":
            print(out)
        else:
            with open(opts["--json"], "w", encoding="utf-8") as f:
                f.write(out)


def main():
    argv = sys.argv[1:]
    if argv and argv[0] == "help" and len(argv) > 1:
        if argv[1] == "server":
            print(SERVER_HELP, end="")
            sys.exit(0)
        if argv[1] == "client":
            print(CLIENT_HELP, end="")
            sys.exit(0)
    if not argv or argv[0] in ("-h", "--help", "help"):
        print(TOP_HELP, end="")
        sys.exit(0 if argv and argv[0] in ("-h", "--help", "help") else 2)
    cmd = argv[0]
    if cmd == "server":
        run_server(argv[1:])
    elif cmd == "client":
        run_client(argv[1:])
    else:
        fail(f"error: unrecognized subcommand '{cmd}'\n\nUsage: executable <COMMAND>\n\nFor more information, try '--help'.")


if __name__ == "__main__":
    main()
