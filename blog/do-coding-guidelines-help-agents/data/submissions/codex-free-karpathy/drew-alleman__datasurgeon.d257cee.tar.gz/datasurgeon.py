#!/usr/bin/env python3
import argparse
import csv
import os
import re
import sys
import time


PLUGIN_PATH = "/home/agent/.DataSurgeon/plugins.json"


def compile_patterns():
    return [
        ("email", re.compile(r"[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}")),
        ("phone_number", re.compile(r"(?<!\d)\d{3}[\s.-]\d{3}[\s.-]\d{4}(?!\d)")),
        ("hashes", re.compile(r"\b(?:[A-Fa-f0-9]{128}|[A-Fa-f0-9]{96}|[A-Fa-f0-9]{64}|[A-Fa-f0-9]{56}|[A-Fa-f0-9]{40}|[A-Fa-f0-9]{32}|[A-Fa-f0-9]{16})\b")),
        ("ip_address", re.compile(r"\b(?:(?:25[0-5]|2[0-4]\d|1?\d?\d)\.){3}(?:25[0-5]|2[0-4]\d|1?\d?\d)\b")),
        ("ipv6_address", re.compile(r"\b(?:[A-Fa-f0-9]{1,4}:){2,7}[A-Fa-f0-9]{1,4}\b")),
        ("mac_address", re.compile(r"\b(?:[A-Fa-f0-9]{2}:){5}[A-Fa-f0-9]{2}\b")),
        ("credit_card", re.compile(r"\b(?:\d[ -]*?){13,16}\b")),
        ("url", re.compile(r"\bhttps?://[^\s<>()\"']+")),
        ("files", re.compile(r"(?:^|[\s\\/])[\w.-]+\.(?:txt|log|csv|json|xml|html?|pdf|docx?|xlsx?|pptx?|zip|tar|gz|rar|7z|jpg|jpeg|png|gif|exe|dll|so|conf|ini|yaml|yml|py|rs|go|c|cpp|h|java|js|ts|sh)\b", re.I)),
        ("bitcoin_wallet", re.compile(r"\b(?:bc1[ac-hj-np-z02-9]{11,71}|[13][a-km-zA-HJ-NP-Z1-9]{25,34})\b")),
        ("aws", re.compile(r"\b(?:AKIA|ASIA)[A-Z0-9]{16}\b")),
        ("google", re.compile(r"\b[0-9a-fA-F]{40}\b")),
        ("dns", re.compile(r"\b(?:[A-Za-z0-9-]+\.)+[A-Za-z]{2,}\b")),
        ("social_security", re.compile(r"\b\d{3}-\d{2}-\d{4}\b")),
    ]


PATTERNS = dict(compile_patterns())


FLAG_TO_KIND = [
    ("email", "email"),
    ("phone", "phone_number"),
    ("hash", "hashes"),
    ("ip_addr", "ip_address"),
    ("ipv6_addr", "ipv6_address"),
    ("mac_addr", "mac_address"),
    ("credit_card", "credit_card"),
    ("url", "url"),
    ("files", "files"),
    ("bitcoin", "bitcoin_wallet"),
    ("aws", "aws"),
    ("google", "google"),
    ("dns", "dns"),
    ("social", "social_security"),
]


class Parser(argparse.ArgumentParser):
    def error(self, message):
        self.print_usage(sys.stderr)
        print(f"error: {message}", file=sys.stderr)
        raise SystemExit(2)


def build_parser():
    p = Parser(
        prog="executable",
        add_help=False,
        formatter_class=argparse.RawTextHelpFormatter,
    )
    p.add_argument("-f", "--file", default="")
    p.add_argument("--add", default="")
    p.add_argument("--update", default="")
    p.add_argument("--remove", default="")
    p.add_argument("--list", action="store_true", dest="list_plugins")
    p.add_argument("-C", "--clean", action="store_true")
    p.add_argument("--directory", default="")
    p.add_argument("--ignore", action="store_true")
    p.add_argument("-l", "--line", action="store_true")
    p.add_argument("-T", "--thorough", action="store_true")
    p.add_argument("-D", "--display", action="store_true")
    p.add_argument("-S", "--suppress", action="store_true")
    p.add_argument("--drop", default="")
    p.add_argument("--filter", default="")
    p.add_argument("-X", "--hide", action="store_true")
    p.add_argument("-o", "--output", default="")
    p.add_argument("-t", "--time", action="store_true")
    p.add_argument("-e", "--email", action="store_true")
    p.add_argument("-p", "--phone", action="store_true")
    p.add_argument("-H", "--hash", action="store_true")
    p.add_argument("-i", "--ip-addr", action="store_true", dest="ip_addr")
    p.add_argument("-6", "--ipv6-addr", action="store_true", dest="ipv6_addr")
    p.add_argument("-m", "--mac-addr", action="store_true", dest="mac_addr")
    p.add_argument("-c", "--credit-card", action="store_true", dest="credit_card")
    p.add_argument("-u", "--url", action="store_true")
    p.add_argument("-F", "--files", action="store_true")
    p.add_argument("-b", "--bitcoin", action="store_true")
    p.add_argument("-a", "--aws", action="store_true")
    p.add_argument("-g", "--google", action="store_true")
    p.add_argument("-d", "--dns", action="store_true")
    p.add_argument("-s", "--social", action="store_true")
    p.add_argument("-h", "--help", action="store_true")
    p.add_argument("-V", "--version", action="store_true")
    return p


HELP = """Note: All extraction features (e.g: -i) work on a specified file (-f) or an output stream.

Usage: executable [OPTIONS]

Options:
  -f, --file <file>            File to extract information from [default: ""]
      --add <add>              Adds a plugin from a GitHub repository (e.g ds --add https://github.com/Drew-Alleman/ds-winreg-plugin/) [default: ""]
      --update <update>        Updates a plugin from a GitHub repository. You can also use `ds --update all` to update all plugins. (e.g ds --update https://github.com/DataSurgeon-ds/ds-cve-plugin/) [default: ""]
      --remove <remove>        Removes a plugin from a GitHub repository (e.g ds --remove https://github.com/Drew-Alleman/ds-winreg-plugin/) [default: ""]
      --list                   List all added plugins
  -C, --clean                  Only displays the matched result, rather than the entire line
      --directory <directory>  Process all files found in the specified directory [default: ""]
      --ignore                 Silences error messages
  -l, --line                   Displays the line number where the match occurred
  -T, --thorough               Doesn't stop at first match (useful for -C if multiple unique matches are on the same line
  -D, --display                Displays the filename assoicated with the content found (https://github.com/Drew-Alleman/DataSurgeon#reading-all-files-in-a-directory)
  -S, --suppress               Suppress the 'Reading standard input' message when not providing a file
      --drop <drop>            Specify a regular expression to exclude certain patterns from the search. (e.g --drop "^.{1,10}$" will hide all matches not under 10 characters) [default: ""]
      --filter <filter>        Include only lines that match the specified regex. (e.g: '--filter ^error' will only include lines that start with the word 'error' [default: ""]
  -X, --hide                   Hides the identifier string infront of the desired content (e.g: 'hash: ', 'url: ', 'email: ' will not be displayed.
  -o, --output <output>        Output's the results of the procedure to a local file (recommended for large files) [default: ""]
  -t, --time                   Time how long the operation took
  -e, --email                  Extract email addresses
  -p, --phone                  Extracts phone numbers
  -H, --hash                   Extract hashes (NTLM, LM, bcrypt, Oracle, MD5, SHA-1, SHA-224, SHA-256, SHA-384, SHA-512, SHA3-224, SHA3-256, SHA3-384, SHA3-512, MD4)
  -i, --ip-addr                Extract IP addresses
  -6, --ipv6-addr              Extract IPv6 addresses
  -m, --mac-addr               Extract MAC addresses
  -c, --credit-card            Extract credit card numbers
  -u, --url                    Extract urls
  -F, --files                  Extract filenames
  -b, --bitcoin                Extract bitcoin wallets
  -a, --aws                    Extract AWS keys
  -g, --google                 Extract Google service account private key ids (used for google automations services)
  -d, --dns                    Extract Domain Name System records
  -s, --social                 Extract social security numbers
  -h, --help                   Print help
  -V, --version                Print version"""


def plugin_warning():
    print(f"Failed to open plugins.json file. PLUGIN_PATH: {PLUGIN_PATH}", file=sys.stderr)


def selected_kinds(args):
    kinds = [kind for attr, kind in FLAG_TO_KIND if getattr(args, attr)]
    return kinds or [kind for _, kind in FLAG_TO_KIND]


def iter_inputs(args):
    if args.directory:
        for root, _, names in os.walk(args.directory):
            for name in sorted(names):
                path = os.path.join(root, name)
                try:
                    with open(path, "r", errors="ignore") as f:
                        for no, line in enumerate(f, 1):
                            yield path, no, line.rstrip("\n")
                except OSError as e:
                    print(f"[-] {e}", file=sys.stderr)
        return
    if args.file:
        if not os.path.exists(args.file):
            print(f"[-] File not found: {args.file}", file=sys.stderr)
            raise SystemExit(1)
        with open(args.file, "r", errors="ignore") as f:
            for no, line in enumerate(f, 1):
                yield args.file, no, line.rstrip("\n")
        return
    if not args.suppress:
        print("[*] Reading standard input. If you meant to analyze a file use 'ds -f <FILE>' (ctrl+c to exit)", file=sys.stderr)
    for no, line in enumerate(sys.stdin, 1):
        yield "", no, line.rstrip("\n")


def clean_file_match(text):
    return text.lstrip(" /\\")


def records(args):
    drop_re = re.compile(args.drop) if args.drop else None
    filter_re = re.compile(args.filter) if args.filter else None
    kinds = selected_kinds(args)
    for path, no, line in iter_inputs(args):
        for kind in kinds:
            pat = PATTERNS[kind]
            matches = list(pat.finditer(line))
            if not matches:
                continue
            use_matches = matches if args.thorough else matches[:1]
            for m in use_matches:
                data = m.group(0) if args.clean else line
                if args.clean and kind == "files":
                    data = clean_file_match(data)
                if filter_re and not filter_re.search(data):
                    continue
                if drop_re and drop_re.search(data):
                    continue
                yield kind, data, path, no
                if not args.thorough:
                    break


def format_record(kind, data, path, no, args):
    prefix = "" if args.hide else f"{kind}: "
    if args.display:
        if prefix:
            prefix = f"{kind}, "
        prefix += f"file: {path} "
    if args.line:
        if args.hide and not args.display:
            return f"{data}, line: {no}"
        if args.display:
            return f"{prefix}{data}, line: {no}"
        return f"{kind}, {data}, line: {no}"
    return f"{prefix}{data}"


def main(argv):
    parser = build_parser()
    args = parser.parse_args(argv)
    plugin_warning()

    if args.help:
        print(HELP)
        return 0
    if args.version:
        print("DataSurgeon: https://github.com/Drew-Alleman/DataSurgeon 1.2.8")
        return 0
    if args.list_plugins:
        plugin_warning()
        print(f"No plugins found. Plugin File: {PLUGIN_PATH}")
        return 1
    if args.add:
        print("[-] Error: Failed to parse plugins.json from the provided URL. Reason: builder error: relative URL without a base", file=sys.stderr)
        return 1
    if args.update:
        print("[-] Error: Failed to update plugin", file=sys.stderr)
        return 1
    if args.remove:
        print("[-] Error: Failed to remove plugin", file=sys.stderr)
        return 1

    start = time.time()
    rows = list(records(args))
    if args.output:
        with open(args.output, "w", newline="") as f:
            w = csv.writer(f, lineterminator="\n")
            w.writerow(["content_type", " data"])
            for kind, data, _, _ in rows:
                w.writerow([kind, f" {data}"])
    else:
        for kind, data, path, no in rows:
            print(format_record(kind, data, path, no, args))
    if args.time:
        print(f"Time elapsed: {time.time() - start:.2f}s")
    return 0


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
