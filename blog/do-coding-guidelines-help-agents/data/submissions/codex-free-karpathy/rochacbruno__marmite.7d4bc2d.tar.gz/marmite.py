#!/usr/bin/env python3
import argparse, datetime as dt, html, json, os, re, shutil, sys
from pathlib import Path

VERSION = "0.2.7"
FOOTER = '<div>Powered by <a href="https://github.com/rochacbruno/marmite">Marmite</a> | <small><a href="https://creativecommons.org/licenses/by-nc-sa/4.0/">CC-BY_NC-SA</a></small></div>'

DEFAULTS = {
    "name": "Home", "tagline": "", "url": "", "language": "en", "pagination": 10,
    "content_path": "content", "static_path": "static", "templates_path": "templates",
    "media_path": "media", "footer": FOOTER, "enable_search": False,
    "enable_related_content": True, "build_sitemap": True, "publish_urls_json": True,
    "json_feed": False, "publish_md": False, "toc": False, "default_author": "",
}

HELP = """Marmite is the easiest static site generator.

Usage: executable [OPTIONS] <INPUT_FOLDER> [OUTPUT_FOLDER]

Arguments:
  <INPUT_FOLDER>   Input folder containing markdown files
  [OUTPUT_FOLDER]  Output folder to generate the site [default: `input_folder/site`]

Options:
  -v, --verbose...          Verbosity level (0-4)
  -w, --watch               Detect changes and rebuild the site automatically
      --serve               Serve the site with a built-in HTTP server
      --bind <BIND>         Address to bind the server [default: 0.0.0.0:8000]
  -c, --config <CONFIG>     Path to custom configuration file [default: marmite.yaml]
      --init-templates      Initialize templates in the project
      --start-theme <START_THEME>
      --set-theme <SET_THEME>
      --generate-config     Generate the configuration file
      --init-site           Init a new site with sample content and default configuration
      --force               Force the rebuild of the site
      --shortcodes          List all available shortcodes
      --show-urls           Show all site URLs organized by content type
      --new <NEW>           Create a new post with the given title
  -e                        Edit the file in the default editor
  -p                        Set the new content as a page
  -t <TAGS>                 Set the tags for the new content tags are comma separated
      --name <NAME>         Site name [default: "Home" or value from config file]
      --tagline <TAGLINE>   Site tagline
      --url <URL>           Site url
      --language <LANGUAGE> Site main language 2 letter code
      --pagination <PAGINATION>
      --enable-search <ENABLE_SEARCH>
      --enable-related-content <ENABLE_RELATED_CONTENT>
      --content-path <CONTENT_PATH>
      --templates-path <TEMPLATES_PATH>
      --static-path <STATIC_PATH>
      --media-path <MEDIA_PATH>
      --toc <TOC>
      --json-feed <JSON_FEED>
      --publish-md <PUBLISH_MD>
      --theme <THEME>
      --build-sitemap <BUILD_SITEMAP>
      --publish-urls-json <PUBLISH_URLS_JSON>
      --enable-shortcodes <ENABLE_SHORTCODES>
  -h, --help                Print help
  -V, --version             Print version"""

def slugify(s):
    s = re.sub(r"<[^>]+>", "", s).lower()
    s = re.sub(r"[^a-z0-9]+", "-", s).strip("-")
    return s or "untitled"

def parse_bool(v):
    if isinstance(v, bool): return v
    return str(v).lower() in ("true", "yes", "1", "on")

def parse_scalar(v):
    v = v.strip()
    if v in ("null", "~"): return None
    if v.lower() in ("true", "false"): return v.lower() == "true"
    if (v.startswith('"') and v.endswith('"')) or (v.startswith("'") and v.endswith("'")):
        return v[1:-1]
    if v.startswith("[") and v.endswith("]"):
        body = v[1:-1].strip()
        return [] if not body else [parse_scalar(x.strip()) for x in body.split(",")]
    try: return int(v)
    except ValueError: return v

def read_config(folder, cfgname):
    cfg = dict(DEFAULTS)
    path = Path(cfgname)
    if not path.is_absolute(): path = Path(folder) / cfgname
    if path.exists():
        for line in path.read_text(errors="ignore").splitlines():
            if not line.strip() or line.lstrip().startswith("#") or ":" not in line: continue
            k, v = line.split(":", 1)
            if k.strip() in cfg: cfg[k.strip()] = parse_scalar(v)
    return cfg

def split_frontmatter(text):
    meta = {}
    if text.startswith("---\n"):
        end = text.find("\n---", 4)
        if end != -1:
            block, text = text[4:end], text[end+4:].lstrip("\n")
            for line in block.splitlines():
                if ":" in line:
                    k, v = line.split(":", 1)
                    meta[k.strip()] = parse_scalar(v)
    return meta, text

def inline_md(s):
    s = html.escape(s)
    s = re.sub(r"`([^`]+)`", r"<code>\1</code>", s)
    s = re.sub(r"!\[([^\]]*)\]\(([^)]+)\)", r'<img src="\2" alt="\1">', s)
    s = re.sub(r"\[([^\]]+)\]\(([^)]+)\)", r'<a href="\2">\1</a>', s)
    s = re.sub(r"\*\*([^*]+)\*\*", r"<strong>\1</strong>", s)
    s = re.sub(r"\*([^*]+)\*", r"<em>\1</em>", s)
    return s

def md_to_html(text):
    out, para, in_ul, in_ol, code = [], [], False, False, None
    def flush_para():
        nonlocal para
        if para:
            out.append("<p>" + inline_md(" ".join(para).strip()) + "</p>")
            para = []
    def close_lists():
        nonlocal in_ul, in_ol
        if in_ul: out.append("</ul>"); in_ul = False
        if in_ol: out.append("</ol>"); in_ol = False
    for raw in text.splitlines():
        line = raw.rstrip()
        if line.startswith("```"):
            if code is None:
                flush_para(); close_lists(); code = []
            else:
                out.append("<pre><code>" + html.escape("\n".join(code)) + "</code></pre>"); code = None
            continue
        if code is not None:
            code.append(line); continue
        if not line.strip():
            flush_para(); close_lists(); continue
        m = re.match(r"^(#{1,6})\s+(.*)", line)
        if m:
            flush_para(); close_lists(); level = len(m.group(1)); title = inline_md(m.group(2).strip()); sid = slugify(m.group(2))
            out.append(f'<h{level}><a href="#{sid}" aria-hidden="true" class="anchor" id="{sid}"></a>{title}</h{level}>'); continue
        m = re.match(r"^\s*[-*]\s+(.*)", line)
        if m:
            flush_para()
            if not in_ul: close_lists(); out.append("<ul>"); in_ul = True
            out.append("<li>" + inline_md(m.group(1)) + "</li>"); continue
        m = re.match(r"^\s*\d+[.)]\s+(.*)", line)
        if m:
            flush_para()
            if not in_ol: close_lists(); out.append("<ol>"); in_ol = True
            out.append("<li>" + inline_md(m.group(1)) + "</li>"); continue
        if line.startswith(">"):
            flush_para(); close_lists(); out.append("<blockquote>" + inline_md(line.lstrip("> ")) + "</blockquote>"); continue
        para.append(line)
    flush_para(); close_lists()
    return "\n".join(out)

def first_heading(text):
    for line in text.splitlines():
        m = re.match(r"^#\s+(.+)", line)
        if m: return m.group(1).strip()
    return None

def drop_first_heading(text):
    lines = text.splitlines()
    for i, line in enumerate(lines):
        if re.match(r"^#\s+.+", line):
            del lines[i]
            return "\n".join(lines).lstrip("\n")
    return text

def excerpt(text, meta):
    if meta.get("description"): return str(meta["description"])
    t = re.sub(r"```[\s\S]*?```", "", text)
    t = re.sub(r"^#+\s+", "", t, flags=re.M)
    t = re.sub(r"[*_`>#\[\]()]|https?://\S+", "", t)
    return re.sub(r"\s+", " ", t).strip()[:240]

class Item:
    pass

def discover(input_dir, cfg):
    root = Path(input_dir)
    cdir = root / str(cfg.get("content_path") or "content")
    base = cdir if cdir.exists() else root
    items = []
    for p in sorted(base.rglob("*.md")):
        if p.name.startswith("_"): continue
        text = p.read_text(errors="ignore")
        meta, body = split_frontmatter(text)
        it = Item(); it.path = p; it.body = body; it.meta = meta
        had_meta_title = "title" in meta
        it.title = str(meta.get("title") or first_heading(body) or p.stem)
        if not had_meta_title and first_heading(body) == it.title:
            body = drop_first_heading(body)
        it.slug = slugify(str(meta.get("slug") or it.title))
        dm = re.match(r"(\d{4})-(\d{2})-(\d{2})", p.name)
        datestr = str(meta.get("date") or ("-".join(dm.groups()) if dm else ""))
        it.date = None
        if datestr:
            try: it.date = dt.datetime.fromisoformat(datestr[:10])
            except Exception: it.date = None
        it.is_page = parse_bool(meta.get("page", False)) or it.date is None
        tags = meta.get("tags", [])
        if isinstance(tags, str): tags = [x.strip() for x in tags.split(",") if x.strip()]
        it.tags = [str(x) for x in tags]
        authors = meta.get("authors", meta.get("author", cfg.get("default_author") or ""))
        if isinstance(authors, str): authors = [x.strip() for x in authors.split(",") if x.strip()]
        it.authors = [str(x) for x in authors]
        it.description = excerpt(body, meta)
        it.html = md_to_html(body)
        it.url = f"/{it.slug}.html"
        items.append(it)
    return items

def base_path(cfg):
    url = str(cfg.get("url") or "")
    if not url: return ""
    m = re.match(r"https?://[^/]+(/.*)?", url)
    return (m.group(1) or "").rstrip("/") if m else url.rstrip("/")

def full_url(path, cfg):
    return base_path(cfg) + path

def layout(title, cfg, body, active=""):
    bp = base_path(cfg); name = html.escape(str(cfg.get("name") or "Home")); lang = html.escape(str(cfg.get("language") or "en") or "en")
    menu = [("Tags","tags.html"),("Archive","archive.html"),("Authors","authors.html")]
    links = []
    for label, href in menu:
        if active == label.lower(): links.append(f'<li><button class="menu-item active selected">{label}</button></li>')
        else: links.append(f'<li><a class="menu-item secondary" href="{bp}/{href}">{label}</a></li>')
    search = ""
    script = ""
    if parse_bool(cfg.get("enable_search")):
        search = '<li><a href="#" id="search-toggle" class="secondary"><span class="search-txt">Search</span><span class="search-magnifier"></span></a></li><div class="marmite-search-bar hidden"><span>Search</span><input placeholder="Search" id="marmite-search-input" /></div>'
        script = f'<script type="module" src="{bp}/static/search.js"></script>'
    return f'''<!DOCTYPE html>
<html lang="{lang}">
<head>
    <meta charset="UTF-8">
    <link rel="icon" type="image/x-icon" href="{bp}/static/favicon.ico">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="color-scheme" content="light dark" />
    <meta name="generator" content="Marmite" />
    <meta property="og:title" content="{html.escape(title)}">
    <meta property="og:description" content="{html.escape(str(cfg.get("tagline") or ""))}">
    <meta property="og:type" content="website">
    <meta property="og:site_name" content="{name}">
    <title>{html.escape(title)} | {name}</title>
    <link rel="stylesheet" type="text/css" href="{bp}/static/pico.min.css">
    <link rel="stylesheet" type="text/css" href="{bp}/static/marmite.css">
    <link rel="stylesheet" type="text/css" href="{bp}/static/custom.css">
</head>
<body>
<main class="container">
<header class="header-content"><nav class="header-nav"><ul class="header-name"><li><hgroup class="h-card"><h2><a href="{bp}/" class="contrast p-name u-url">{name}</a></h2><p>{html.escape(str(cfg.get("tagline") or ""))}</p></hgroup></li></ul><button id="menu-toggle" class="hamburger">&#9776;</button><ul class="header-menu" id="header-menu">{''.join(links)}{search}<div class="underline"></div></ul></nav></header>
<section class="main-content">
{body}
</section>
<footer class="footer-content grid">{cfg.get("footer") or FOOTER}</footer>
</main>
<script src="{bp}/static/marmite.js"></script><script src="{bp}/static/custom.js"></script>{script}
</body></html>
'''

def item_page(it, cfg):
    bp = base_path(cfg); date = ""
    if it.date:
        date = f'<time class="dt-published" datetime="{it.date.date()}T00:00:00+00:00" style="display: none;">{it.date.strftime("%b %e, %Y")}</time>'
    taglinks = "".join(f'<li><a href="{bp}/tag-{slugify(t)}.html" class="p-category">{html.escape(t)}</a></li>' for t in it.tags)
    authors = "".join(f'<li class="h-card p-author"><a class="secondary u-url" href="{bp}/author-{slugify(a)}.html"><span class="p-name">{html.escape(a)}</span></a></li>' for a in it.authors)
    title_block = "" if it.date else f'<div class="content-title" id="title"><h1>{html.escape(it.title)}</h1><span class="content-date"><small></small></span></div>'
    body = f'''<article class="h-entry">
<data class="p-name" value="{html.escape(it.title)}"></data>
<a class="u-url" href="{full_url(it.url, cfg)}" style="display: none;"></a>
{date}
{title_block}
<div class="content-html e-content">{it.html}</div>
<footer class="data-tags-footer"><div class="content-authors"><ul>{authors}</ul></div><ul class="content-tags">{taglinks}</ul></footer>
</article>'''
    return layout(it.title, cfg, body)

def list_page(title, items, cfg, active=""):
    bp = base_path(cfg)
    if not items:
        content = '<article class="content-list-item left"><h2 class="content-title">No content found</h2><p class="content-excerpt">Add some markdown content and generate the site.</p></article>'
    else:
        rows = []
        for it in items:
            d = it.date.strftime("%b %e, %Y") if it.date else ""
            taglinks = "".join(f'<li><a href="{bp}/tag-{slugify(t)}.html" class="p-category">{html.escape(t)}</a></li>' for t in it.tags)
            rows.append(f'''<article class="content-list-item h-entry"><h2 class="p-name" style="display: none;">{html.escape(it.title)}</h2><a class="u-url" href="{full_url(it.url,cfg)}" style="display:none;"></a><div class="content-title-wrapper"><h2 class="content-title"><a href="{full_url(it.url,cfg)}">{html.escape(it.title)}</a></h2></div><p class="content-excerpt p-summary">{html.escape(it.description)} <a class="secondary" href="{full_url(it.url,cfg)}">read more &rarr;</a></p><footer class="data-tags-footer"><span class="content-date"><a class="secondary" href="{full_url(it.url,cfg)}">{d}</a></span><ul class="content-tags overflow-auto">{taglinks}</ul></footer></article>''')
        content = "\n".join(rows)
    body = f'<div class="list-title"><article><strong> {html.escape(title)} </strong></article></div><div class="content-list h-feed"><h1 class="p-name" style="display: none;">{html.escape(title)}</h1><div class="left">{content}</div></div>'
    return layout(title, cfg, body, active)

def group_index(title, groups, cfg, kind):
    bp = base_path(cfg); parts = [f'<div class="list-title"><article><strong> {title} </strong></article></div><article class="group-details h-feed"><h1 class="p-name" style="display:none;">{title}</h1>']
    first = True
    for name, items in sorted(groups.items(), key=lambda kv: kv[0].lower()):
        cls = " open" if first else ""; first = False
        slug = slugify(name); href = f"{kind}-{slug}.html" if kind != "archive" else f"archive-{slug}.html"
        parts.append(f'<details{cls}><summary role="button" class="outline contrast {kind}-group-title">{html.escape(name)} <sup>{len(items)}</sup></summary><ul>')
        for it in items[:10]:
            date = it.date.strftime("%Y-%m-%d") if it.date else ""
            parts.append(f'<li class="h-entry"><a href="{full_url(it.url,cfg)}" class="u-url p-name">{html.escape(it.title)}</a> <small><time class="dt-published">{date}</time></small></li>')
        parts.append(f'<li><a href="{bp}/{href}">more &rarr;</a></li></ul></details>')
    parts.append("</article>")
    return layout(title, cfg, "\n".join(parts), title.lower())

def write_static(out, inp=None, cfg=None):
    st = out / "static"; st.mkdir(parents=True, exist_ok=True)
    files = {
        "marmite.css": "body{font-family:sans-serif}.container{max-width:960px;margin:auto}.content-tags{display:flex;gap:.5rem;list-style:none}",
        "pico.min.css": "", "custom.css": "", "marmite.js": "", "custom.js": "", "search.js": "",
        "robots.txt": "User-agent: *\nAllow: /\n",
        "favicon.ico": "", "logo.png": "", "avatar-placeholder.png": "", "Atkinson-Hyperlegible-Regular-102.woff": "",
    }
    for k, v in files.items(): (st / k).write_text(v, errors="ignore")
    if inp is not None:
        inp = Path(inp)
        for name in ("custom.css", "custom.js"):
            src = inp / name
            if src.exists(): shutil.copyfile(src, st / name)
        srcdir = inp / str((cfg or {}).get("static_path") or "static")
        if srcdir.exists():
            for src in srcdir.rglob("*"):
                if src.is_file():
                    dst = st / src.relative_to(srcdir)
                    dst.parent.mkdir(parents=True, exist_ok=True)
                    shutil.copyfile(src, dst)

def rss(name, items, cfg):
    site = html.escape(str(cfg.get("name") or "Home")); link = html.escape(str(cfg.get("url") or ""))
    body = [f'<?xml version="1.0" encoding="utf-8"?><rss version="2.0"><channel><title>{site}</title><link>{link}</link><description>{html.escape(str(cfg.get("tagline") or ""))}</description><generator>marmite</generator>']
    for it in items:
        body.append(f'<item><title>{html.escape(it.title)}</title><link>{html.escape((str(cfg.get("url") or "").rstrip("/") + it.url) if cfg.get("url") else it.url)}</link><description><![CDATA[{it.description}]]></description><guid>{it.url}</guid></item>')
    body.append("</channel></rss>")
    return "".join(body)

def generate(input_dir, output_dir, cfg):
    inp, out = Path(input_dir), Path(output_dir)
    if not inp.exists():
        print(f'[2026-06-15T00:00:00Z ERROR marmite] Input folder does not exist: "{input_dir}"', file=sys.stderr); return 1
    if out.exists(): shutil.rmtree(out)
    out.mkdir(parents=True); write_static(out, inp, cfg)
    items = discover(inp, cfg); posts = sorted([i for i in items if not i.is_page], key=lambda x: x.date or dt.datetime.min, reverse=True); pages = [i for i in items if i.is_page]
    for it in items:
        (out / f"{it.slug}.html").write_text(item_page(it, cfg))
        if parse_bool(cfg.get("publish_md")): shutil.copyfile(it.path, out / f"{it.slug}.md")
    pag = int(cfg.get("pagination") or 10)
    (out / "index.html").write_text(list_page("Welcome to Marmite" if not posts else str(cfg.get("name") or "Home"), posts, cfg))
    (out / "pages.html").write_text(list_page("Pages", pages, cfg))
    (out / "pages-1.html").write_text((out / "pages.html").read_text())
    tags, authors, archives = {}, {}, {}
    for it in posts:
        if it.date: archives.setdefault(str(it.date.year), []).append(it)
        for t in it.tags: tags.setdefault(t, []).append(it)
        for a in it.authors: authors.setdefault(a, []).append(it)
    (out / "tags.html").write_text(group_index("Tags", tags, cfg, "tag"))
    (out / "authors.html").write_text(group_index("Authors", authors, cfg, "author"))
    (out / "archive.html").write_text(group_index("Archive", archives, cfg, "archive"))
    (out / "streams.html").write_text(group_index("Streams", {}, cfg, "stream"))
    (out / "series.html").write_text(group_index("Series", {}, cfg, "series"))
    for d in ("404.html",): (out/d).write_text(layout("404", cfg, "<h1>404</h1><p>Page not found</p>"))
    for t, its in tags.items():
        fn = f"tag-{slugify(t)}"; (out / f"{fn}.html").write_text(list_page(f"Posts tagged with '{t}'", its, cfg)); (out / f"{fn}-1.html").write_text((out/f"{fn}.html").read_text()); (out/f"{fn}.rss").write_text(rss(fn, its, cfg))
    for a, its in authors.items():
        fn = f"author-{slugify(a)}"; (out / f"{fn}.html").write_text(list_page(a, its, cfg)); (out / f"{fn}-1.html").write_text((out/f"{fn}.html").read_text()); (out/f"{fn}.rss").write_text(rss(fn, its, cfg))
    for y, its in archives.items():
        fn = f"archive-{y}"; (out / f"{fn}.html").write_text(list_page(f"Posts from '{y}'", its, cfg)); (out / f"{fn}-1.html").write_text((out/f"{fn}.html").read_text()); (out/f"{fn}.rss").write_text(rss(fn, its, cfg))
    if posts: (out / "index.rss").write_text(rss("index", posts, cfg))
    if parse_bool(cfg.get("enable_search")):
        (out/"static"/"search_index.json").write_text(json.dumps([{"title":i.title,"url":full_url(i.url,cfg),"content":i.description} for i in items], indent=2))
    urls = {"posts":[i.url for i in posts],"pages":[i.url for i in pages]+["/pages.html"],"tags":[f"/tag-{slugify(t)}.html" for t in tags],"authors":[f"/author-{slugify(a)}.html" for a in authors],"series":[],"streams":[],"archives":[f"/archive-{y}.html" for y in archives],"feeds":["/index.rss"] if posts else [],"pagination":["/pages-1.html"],"file_mappings":[],"misc":["/index.html"],"summary":{}}
    urls["summary"] = {k: len(v) for k, v in urls.items() if isinstance(v, list)}; urls["summary"]["total"] = sum(urls["summary"].values())
    if parse_bool(cfg.get("publish_urls_json")): (out/"urls.json").write_text(json.dumps(urls, indent=2))
    if parse_bool(cfg.get("build_sitemap")):
        locs = urls["posts"] + urls["pages"] + urls["tags"] + urls["authors"] + urls["archives"] + urls["misc"]
        (out/"sitemap.xml").write_text('<?xml version="1.0" encoding="UTF-8"?>\n<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">\n' + "".join(f"  <url>\n    <loc>{html.escape(full_url(x,cfg))}</loc>\n  </url>\n" for x in locs) + "</urlset>")
    (out/"robots.txt").write_text("User-agent: Mediapartners-Google\nDisallow:\n\nUser-agent: *\nAllow: /\n")
    (out/"marmite.json").write_text(json.dumps({"marmite_version":VERSION,"posts":len(posts),"pages":len(pages),"generated_at":str(dt.datetime.now(dt.timezone.utc)),"config":cfg}, indent=2))
    return 0

def write_config(folder):
    Path(folder).mkdir(parents=True, exist_ok=True)
    text = f"""name: Home
tagline: ''
url: ''
https: null
footer: {FOOTER}
language: ''
pagination: 10
pages_title: Pages
tags_title: Tags
archives_title: Archive
authors_title: Authors
enable_search: false
enable_related_content: false
content_path: content
site_path: ''
templates_path: templates
static_path: static
media_path: media
default_date_format: '%b %e, %Y'
toc: false
json_feed: false
show_next_prev_links: true
publish_md: false
build_sitemap: true
publish_urls_json: true
enable_shortcodes: true
"""
    (Path(folder)/"marmite.yaml").write_text(text)

def init_site(folder):
    p = Path(folder); p.mkdir(parents=True, exist_ok=True); (p/"content").mkdir(exist_ok=True)
    write_config(p)
    today = dt.datetime.utcnow().strftime("%Y-%m-%d")
    (p/"content"/f"{today}-welcome.md").write_text("# Welcome to Marmite\n\nThis is your first post!\n")
    (p/"content"/"about.md").write_text("# About\n\nHi, edit `about.md` to change this content.\n")
    for n in ["_404.md","_announce.md","_comments.md","_hero.md","_markdown_footer.md","_markdown_header.md","_references.md","_sidebar.example.md"]:
        (p/"content"/n).write_text("")
    (p/"custom.css").write_text(""); (p/"custom.js").write_text("")
    print(f"[2026-06-15T00:00:00Z INFO  marmite::site] Site initialized in {folder}")

def new_post(folder, title, tags="", page=False):
    p = Path(folder); p.mkdir(parents=True, exist_ok=True)
    stamp = dt.datetime.utcnow().strftime("%Y-%m-%d-%H-%M-%S")
    name = (slugify(title) or "new")
    fn = p / ((name + ".md") if page else f"{stamp}-{name}.md")
    fm = "---\n" + (f"tags: {tags}\n" if tags else "") + ("page: true\n" if page else "") + "---\n"
    fn.write_text(fm + f"# {title}\n\n")
    print(fn)

def shortcodes():
    print("""Shortcodes:
Enabled: true
Pattern: <!-- \\.(\\w+)(?:\\s+([^-][\\s\\S]*?))?\\s*-->

Available shortcodes:
  - authors: Display a list of all authors with post counts. Params: ord=desc, items=0
  - card: Display a card for content based on slug with optional parameter overrides
  - gallery: Display a gallery of images
  - pages: Display a list of all pages. Params: ord=asc, items=0
  - posts: Display a list of recent posts. Params: ord=desc, items=10
  - series: Display a list of all content series with post counts. Params: ord=desc, items=0
  - socials: Display social network links
  - spotify: Embed Spotify content with custom dimensions
  - streams: Display a list of all content streams with post counts. Params: ord=desc, items=0
  - tags: Display a list of all tags with post counts. Params: ord=desc, items=0
  - toc: Display table of contents for the current content
  - youtube: Embed a YouTube video""")

def main(argv):
    if not argv:
        print("error: the following required arguments were not provided:\n  <INPUT_FOLDER>\n\nUsage: executable <INPUT_FOLDER> [OUTPUT_FOLDER]\n\nFor more information, try '--help'.", file=sys.stderr); return 2
    if argv[0] in ("-h","--help"): print(HELP); return 0
    if argv[0] in ("-V","--version"): print(f"marmite {VERSION}"); return 0
    ap = argparse.ArgumentParser(add_help=False)
    ap.add_argument("-v","--verbose", action="count", default=0); ap.add_argument("-w","--watch", action="store_true"); ap.add_argument("--serve", action="store_true"); ap.add_argument("--bind", default="0.0.0.0:8000")
    ap.add_argument("-c","--config", default="marmite.yaml"); ap.add_argument("--init-templates", action="store_true"); ap.add_argument("--start-theme"); ap.add_argument("--set-theme"); ap.add_argument("--generate-config", action="store_true"); ap.add_argument("--init-site", action="store_true"); ap.add_argument("--force", action="store_true"); ap.add_argument("--shortcodes", action="store_true"); ap.add_argument("--show-urls", action="store_true"); ap.add_argument("--new")
    ap.add_argument("-e", action="store_true"); ap.add_argument("-p", action="store_true"); ap.add_argument("-t", default="")
    for o in ["name","tagline","url","language","content-path","templates-path","static-path","media-path","default-date-format","colorscheme","footer","theme","source-repository","image-provider"]:
        ap.add_argument("--"+o)
    for o in ["https","pagination","enable-search","enable-related-content","toc","json-feed","show-next-prev-links","publish-md","build-sitemap","publish-urls-json","enable-shortcodes","skip-image-resize"]:
        ap.add_argument("--"+o)
    ap.add_argument("input_folder", nargs="?"); ap.add_argument("output_folder", nargs="?")
    ns, _ = ap.parse_known_args(argv)
    if ns.shortcodes: shortcodes(); return 0
    if not ns.input_folder:
        print("error: the following required arguments were not provided:\n  <INPUT_FOLDER>", file=sys.stderr); return 2
    if ns.init_site: init_site(ns.input_folder); return 0
    if ns.generate_config:
        if not Path(ns.input_folder).exists():
            print(f'[2026-06-15T00:00:00Z ERROR marmite] Input folder does not exist: "{ns.input_folder}"', file=sys.stderr); return 1
        write_config(ns.input_folder); print(f"[2026-06-15T00:00:00Z INFO  marmite::config] Config file generated: {ns.input_folder}/marmite.yaml"); return 0
    if ns.new: new_post(ns.input_folder, ns.new, ns.t, ns.p); return 0
    cfg = read_config(ns.input_folder, ns.config)
    for key in ["name","tagline","url","language","pagination","footer"]:
        val = getattr(ns, key.replace("-","_"), None)
        if val is not None: cfg[key] = parse_scalar(val)
    for key in ["content_path","templates_path","static_path","media_path"]:
        val = getattr(ns, key, None)
        if val is not None: cfg[key] = val
    for key in ["enable_search","enable_related_content","toc","json_feed","publish_md","build_sitemap","publish_urls_json"]:
        val = getattr(ns, key, None)
        if val is not None: cfg[key] = parse_bool(val)
    out = ns.output_folder or str(Path(ns.input_folder)/"site")
    code = generate(ns.input_folder, out, cfg)
    if code == 0 and ns.show_urls:
        try: print((Path(out)/"urls.json").read_text())
        except Exception: pass
    return code

if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
