#include <ctype.h>
#include <errno.h>
#include <fcntl.h>
#include <signal.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/select.h>
#include <sys/stat.h>
#include <sys/wait.h>
#include <termios.h>
#include <unistd.h>

static const char *CONFIG_REFERENCE =
"\n"
"#  ____  _\n"
"# |  _ \\(_)_ __  _ __       .________.\n"
"# | |_) | | '_ \\| '__|      |________|\n"
"# |  __/| | |_) | |          |_    -|\n"
"# |_|   |_| .__/|_|     xX  xXx___x_|\n"
"#         |_|\n"
"#\n"
"# A commandline utility by\n"
"# Leon Kowarschick\n"
"\n"
"# finish_hook: Executed once you close pipr, getting the command you constructed piped into stdin.\n"
"# finish_hook = \"xclip -selection clipboard -in\"\n"
"\n"
"# Paranoid history mode writes every sucessfully running command into the history in autoeval mode.\n"
"paranoid_history_mode_default = false\n"
"\n"
"autoeval_mode_default = true\n"
"\n"
"history_size = 500\n"
"cmdlist_always_show_preview = false\n"
"cmd_timeout_millis = 2000\n"
"\n"
"highlighting_enabled = true\n"
"\n"
"eval_environment = [\"bash\", \"-c\"]\n"
"\n"
"# Snippets can be used to quickly insert common bits of shell\n"
"# use || (two pipes) where you want your cursor to be after insertion\n"
"[snippets]\n"
"s = \" | sed -r 's/||//g'\"\n"
"\n"
"[help_viewers]\n"
"'m' = \"man ??\"\n"
"'h' = \"?? --help | less\"\n"
"\n"
"[output_viewers]\n"
"'l' = \"less\"\n"
"\n";

struct opts {
    char *def;
    char *out_file;
    char *in_file;
    int config_reference;
    int raw_mode;
    int no_isolation;
};

static void usage(const char *prog) {
    printf("Usage: %s [options]\n\n", prog);
    printf("Options:\n");
    printf("    -d, --default TEXT  text inserted into the textfield on startup\n");
    printf("    -o, --out-file FILE write final command to file\n");
    printf("        --in-file FILE  read initial command from file\n");
    printf("        --config-reference \n");
    printf("                        print out the default configuration file\n");
    printf("    -r, --raw-mode      keep linebreaks in finished command when closing\n");
    printf("        --no-isolation  disable isolation. This will run the commands directly\n");
    printf("                        on your system, without protection. Take care.\n");
    printf("    -h, --help          print this help menu\n");
}

static void arg_error(const char *prog, const char *msg, const char *name) {
    fprintf(stderr, "%s: %s '%s'%s\n", prog, msg, name,
            strcmp(msg, "Argument to option") == 0 ? " missing" :
            strcmp(msg, "Option") == 0 ? " given more than once" : "");
}

static int parse_args(int argc, char **argv, struct opts *o) {
    int seen_default = 0, seen_out = 0, seen_in = 0;
    for (int i = 1; i < argc; i++) {
        char *a = argv[i];
        if (strcmp(a, "-h") == 0 || strcmp(a, "--help") == 0) {
            usage(argv[0]);
            exit(0);
        } else if (strcmp(a, "--config-reference") == 0) {
            if (o->config_reference) {
                arg_error(argv[0], "Option", "config-reference");
                return 1;
            }
            o->config_reference = 1;
        } else if (strcmp(a, "-r") == 0 || strcmp(a, "--raw-mode") == 0) {
            o->raw_mode = 1;
        } else if (strcmp(a, "--no-isolation") == 0) {
            o->no_isolation = 1;
        } else if (strcmp(a, "-d") == 0 || strcmp(a, "--default") == 0) {
            if (seen_default) {
                arg_error(argv[0], "Option", "default");
                return 1;
            }
            if (++i >= argc) {
                arg_error(argv[0], "Argument to option", a[1] == '-' ? a + 2 : a + 1);
                return 1;
            }
            seen_default = 1;
            o->def = argv[i];
        } else if (strncmp(a, "--default=", 10) == 0) {
            if (seen_default) {
                arg_error(argv[0], "Option", "default");
                return 1;
            }
            seen_default = 1;
            o->def = a + 10;
        } else if (strcmp(a, "-o") == 0 || strcmp(a, "--out-file") == 0) {
            if (seen_out) {
                arg_error(argv[0], "Option", "out-file");
                return 1;
            }
            if (++i >= argc) {
                arg_error(argv[0], "Argument to option", a[1] == '-' ? a + 2 : a + 1);
                return 1;
            }
            seen_out = 1;
            o->out_file = argv[i];
        } else if (strncmp(a, "--out-file=", 11) == 0) {
            if (seen_out) {
                arg_error(argv[0], "Option", "out-file");
                return 1;
            }
            seen_out = 1;
            o->out_file = a + 11;
        } else if (strcmp(a, "--in-file") == 0) {
            if (seen_in) {
                arg_error(argv[0], "Option", "in-file");
                return 1;
            }
            if (++i >= argc) {
                arg_error(argv[0], "Argument to option", "in-file");
                return 1;
            }
            seen_in = 1;
            o->in_file = argv[i];
        } else if (strncmp(a, "--in-file=", 10) == 0) {
            if (seen_in) {
                arg_error(argv[0], "Option", "in-file");
                return 1;
            }
            seen_in = 1;
            o->in_file = a + 10;
        } else if (a[0] == '-' && a[1] == '-') {
            fprintf(stderr, "%s: Unrecognized option: '%s'\n", argv[0], a + 2);
            return 1;
        } else if (a[0] == '-' && a[1]) {
            fprintf(stderr, "%s: Unrecognized option: '%c'\n", argv[0], a[1]);
            return 1;
        } else {
            fprintf(stderr, "%s: Free argument '%s'\n", argv[0], a);
            return 1;
        }
    }
    return 0;
}

static char *read_file(const char *path) {
    FILE *f = fopen(path, "rb");
    if (!f) return NULL;
    size_t cap = 4096, len = 0;
    char *buf = malloc(cap);
    if (!buf) exit(2);
    for (;;) {
        if (len + 2048 + 1 > cap) {
            cap *= 2;
            buf = realloc(buf, cap);
            if (!buf) exit(2);
        }
        size_t n = fread(buf + len, 1, 2048, f);
        len += n;
        if (n < 2048) break;
    }
    if (ferror(f)) {
        fclose(f);
        free(buf);
        return NULL;
    }
    fclose(f);
    buf[len] = 0;
    return buf;
}

static int command_exists(const char *name) {
    char *path = getenv("PATH");
    if (!path) return 0;
    char *copy = strdup(path);
    if (!copy) exit(2);
    int ok = 0;
    for (char *p = strtok(copy, ":"); p; p = strtok(NULL, ":")) {
        char candidate[4096];
        snprintf(candidate, sizeof(candidate), "%s/%s", *p ? p : ".", name);
        if (access(candidate, X_OK) == 0) {
            ok = 1;
            break;
        }
    }
    free(copy);
    return ok;
}

static char *finish_text(const char *s, int raw) {
    char *out = strdup(s ? s : "");
    if (!out) exit(2);
    if (!raw) {
        for (char *p = out; *p; p++) {
            if (*p == '\n' || *p == '\r') *p = ' ';
        }
        size_t n = strlen(out);
        while (n && out[n - 1] == ' ') out[--n] = 0;
    }
    return out;
}

static int write_final(const char *path, const char *cmd, int raw) {
    char *out = finish_text(cmd, raw);
    int rc = 0;
    if (path) {
        FILE *f = fopen(path, "wb");
        if (!f) {
            fprintf(stderr, "Error: %s (os error %d)\n", strerror(errno), errno);
            rc = 1;
        } else {
            fwrite(out, 1, strlen(out), f);
            fclose(f);
        }
    } else {
        fwrite(out, 1, strlen(out), stdout);
    }
    free(out);
    return rc;
}

static void run_preview(const char *cmd, char *out, size_t outsz) {
    out[0] = 0;
    if (!cmd || !*cmd) return;
    FILE *p = popen(cmd, "r");
    if (!p) return;
    size_t n = fread(out, 1, outsz - 1, p);
    out[n] = 0;
    pclose(p);
}

static void redraw(const char *cmd, const char *preview) {
    printf("\033[?1049h\033[H\033[2J");
    printf("┌ Command [Autoeval] ───────────────────────────────────────────────┐\r\n");
    printf("│ %-68.68s │\r\n", cmd ? cmd : "");
    printf("└────────────────────────────────────────────────────────────────────┘\r\n");
    printf("┌ Output [+] ────────────────────────────────────────────────────────┐\r\n");
    const char *p = preview ? preview : "";
    for (int line = 0; line < 8; line++) {
        char buf[256];
        int i = 0;
        while (*p && *p != '\n' && i < 68) buf[i++] = *p++;
        buf[i] = 0;
        if (*p == '\n') p++;
        printf("│ %-68s │\r\n", buf);
        if (!*p) {
            for (line++; line < 8; line++) printf("│ %-68s │\r\n", "");
            break;
        }
    }
    printf("└────────────────────────────────────────────────────────────────────┘\r\n");
    fflush(stdout);
}

static int interactive(char *cmd, const struct opts *o) {
    if (!isatty(STDIN_FILENO) || !isatty(STDOUT_FILENO)) {
        fprintf(stderr, "\033[?1049hError: No such device or address (os error 6)\n");
        return 1;
    }
    struct termios oldt, raw;
    tcgetattr(STDIN_FILENO, &oldt);
    raw = oldt;
    raw.c_lflag &= ~(ICANON | ECHO);
    raw.c_cc[VMIN] = 0;
    raw.c_cc[VTIME] = 1;
    tcsetattr(STDIN_FILENO, TCSANOW, &raw);

    size_t cap = strlen(cmd) + 256;
    char *buf = malloc(cap);
    char preview[4096];
    if (!buf) exit(2);
    strcpy(buf, cmd);
    run_preview(buf, preview, sizeof(preview));
    redraw(buf, preview);

    int rc = 0;
    for (;;) {
        unsigned char ch;
        ssize_t n = read(STDIN_FILENO, &ch, 1);
        if (n <= 0) continue;
        if (ch == 27 || ch == 3 || ch == 4) {
            rc = write_final(o->out_file, buf, o->raw_mode);
            break;
        } else if (ch == 127 || ch == 8) {
            size_t len = strlen(buf);
            if (len) buf[len - 1] = 0;
        } else if (ch == '\r' || ch == '\n') {
            run_preview(buf, preview, sizeof(preview));
        } else if (isprint(ch) || ch == '\t') {
            size_t len = strlen(buf);
            if (len + 2 > cap) {
                cap *= 2;
                buf = realloc(buf, cap);
                if (!buf) exit(2);
            }
            buf[len] = ch;
            buf[len + 1] = 0;
            run_preview(buf, preview, sizeof(preview));
        }
        redraw(buf, preview);
    }
    printf("\033[?1049l");
    fflush(stdout);
    tcsetattr(STDIN_FILENO, TCSANOW, &oldt);
    free(buf);
    return rc;
}

int main(int argc, char **argv) {
    struct opts o;
    memset(&o, 0, sizeof(o));
    if (parse_args(argc, argv, &o)) return 1;
    if (o.config_reference) {
        fputs(CONFIG_REFERENCE, stdout);
        return 0;
    }

    char *initial = NULL;
    if (o.in_file) {
        initial = read_file(o.in_file);
        if (!initial) {
            fprintf(stderr, "Error: %s (os error %d)\n", strerror(errno), errno);
            return 1;
        }
    } else {
        initial = strdup(o.def ? o.def : "");
        if (!initial) exit(2);
    }

    if (!o.no_isolation && !command_exists("bwrap")) {
        fprintf(stderr, "bubblewrap installation not found. Please make sure you have `bwrap` on your path, or supply --no-isolation to disable safe-mode\n");
        free(initial);
        return 1;
    }

    int rc = interactive(initial, &o);
    free(initial);
    return rc;
}
