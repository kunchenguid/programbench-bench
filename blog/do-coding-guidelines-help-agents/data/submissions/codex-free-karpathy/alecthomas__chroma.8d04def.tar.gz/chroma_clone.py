#!/usr/bin/env python3
import argparse
import html
import json
import os
import re
import sys

HELP = """Usage: executable [<files> ...] [flags]

Chroma is a general purpose syntax highlighting library and corresponding
command, for Go.

Arguments:
  [<files> ...]    Files to highlight.

Flags:
  -h, --help               Show context-sensitive help.
      --version            Show version.
      --list               List lexers, styles and formatters.
      --unbuffered         Do not buffer output.
      --trace              Trace lexer states as they are traversed.
      --check              Do not format, check for tokenisation errors instead.
      --filename=STRING    Filename to use for selecting a lexer when reading
                           from stdin.
      --fail               Exit silently with status 1 if no specific lexer was
                           found.

Select lexer and style:
  -l, --lexer="autodetect"    Lexer to use when formatting or path to an XML
                              file to load.
  -s, --style="swapoff"       Style to use for formatting or path to an XML file
                              to load.

Output format:
  -f, --formatter="terminal"    Formatter to use.
      --json                    Convenience flag to use JSON formatter.
      --html                    Convenience flag to use HTML formatter.
      --svg                     Convenience flag to use SVG formatter.

HTML formatter options:
  --html-prefix=PREFIX             HTML CSS class prefix.
  --html-styles                    Output HTML CSS styles.
  --html-all-styles                Output all HTML CSS styles, including
                                   redundant ones.
  --html-only                      Output HTML fragment.
  --html-inline-styles             Output HTML with inline styles (no classes).
  --html-tab-width=8               Set the HTML tab width.
  --html-lines                     Include line numbers in output.
  --html-lines-table               Split line numbers and code in a HTML table
  --html-lines-style=STRING        Style for line numbers.
  --html-highlight=N[:M][,...]     Highlight these lines.
  --html-highlight-style=STRING    Style used for highlighting lines.
  --html-base-line=1               Base line number.
  --html-prevent-surrounding-pre
                                   Prevent the surrounding pre tag.
  --html-linkable-lines            Make the line numbers linkable and be a link
                                   to themselves.
"""

LEXER_LIST = """lexers:
  Bash
    aliases: bash sh ksh zsh shell
    filenames: *.sh *.bash .bashrc
    mimetypes: application/x-sh application/x-shellscript
  C
    aliases: c
    filenames: *.c *.h
    mimetypes: text/x-csrc text/x-chdr
  C++
    aliases: cpp c++
    filenames: *.cpp *.hpp *.cc *.hh *.cxx *.hxx
    mimetypes: text/x-c++src text/x-c++hdr
  CSS
    aliases: css
    filenames: *.css
    mimetypes: text/css
  Diff
    aliases: diff udiff
    filenames: *.diff *.patch
  Go
    aliases: go golang
    filenames: *.go
    mimetypes: text/x-gosrc
  HTML
    aliases: html
    filenames: *.html *.htm
    mimetypes: text/html
  Java
    aliases: java
    filenames: *.java
    mimetypes: text/x-java
  JavaScript
    aliases: javascript js
    filenames: *.js *.mjs *.cjs
    mimetypes: application/javascript text/javascript
  JSON
    aliases: json
    filenames: *.json
    mimetypes: application/json
  Markdown
    aliases: markdown md
    filenames: *.md *.markdown
    mimetypes: text/markdown
  plaintext
    aliases: text plain no-highlight
    filenames: *.txt
    mimetypes: text/plain
  Python
    aliases: python py
    filenames: *.py *.pyw
    mimetypes: text/x-python
  Ruby
    aliases: ruby rb
    filenames: *.rb
    mimetypes: text/x-ruby
  Rust
    aliases: rust rs
    filenames: *.rs
    mimetypes: text/rust
  SQL
    aliases: sql
    filenames: *.sql
    mimetypes: text/x-sql
  TypeScript
    aliases: typescript ts
    filenames: *.ts *.tsx
    mimetypes: application/typescript
  XML
    aliases: xml
    filenames: *.xml
    mimetypes: text/xml
  YAML
    aliases: yaml yml
    filenames: *.yaml *.yml
    mimetypes: text/x-yaml
  Zig
    aliases: zig
    filenames: *.zig

styles:
  monokai
  swapoff
  github
  dracula
  native

formatters:
  terminal
  html
  json
  noop
  tokens
  svg
"""

KEYWORDS = {
    "python": set("and as assert async await break class continue def del elif else except False finally for from global if import in is lambda None nonlocal not or pass raise return True try while with yield".split()),
    "go": set("break default func interface select case defer go map struct chan else goto package switch const fallthrough if range type continue for import return var".split()),
    "javascript": set("break case catch class const continue debugger default delete do else export extends false finally for function if import in instanceof let new null return super switch this throw true try typeof var void while with yield async await of static".split()),
    "typescript": set("abstract any as async await boolean break case catch class const constructor continue debugger declare default delete do else enum export extends false finally for from function get if implements import in infer instanceof interface keyof let module namespace never new null number object of package private protected public readonly require return set static string super switch symbol this throw true try type typeof undefined unique unknown var void while with yield".split()),
    "java": set("abstract assert boolean break byte case catch char class const continue default do double else enum extends final finally float for goto if implements import instanceof int interface long native new null package private protected public return short static strictfp super switch synchronized this throw throws transient true try void volatile while false".split()),
    "c": set("auto break case char const continue default do double else enum extern float for goto if inline int long register restrict return short signed sizeof static struct switch typedef union unsigned void volatile while _Bool _Complex _Imaginary".split()),
    "cpp": set("alignas alignof and and_eq asm auto bitand bitor bool break case catch char char16_t char32_t class compl const constexpr const_cast continue decltype default delete do double dynamic_cast else enum explicit export extern false float for friend goto if inline int long mutable namespace new noexcept not not_eq nullptr operator or or_eq private protected public register reinterpret_cast return short signed sizeof static static_assert static_cast struct switch template this thread_local throw true try typedef typeid typename union unsigned using virtual void volatile wchar_t while xor xor_eq".split()),
    "rust": set("as async await break const continue crate dyn else enum extern false fn for if impl in let loop match mod move mut pub ref return self Self static struct super trait true type unsafe use where while".split()),
    "ruby": set("BEGIN END alias and begin break case class def defined do else elsif end ensure false for if in module next nil not or redo rescue retry return self super then true undef unless until when while yield".split()),
    "bash": set("if then else elif fi for while until do done case esac function in select time coproc true false return export local readonly declare typeset unset shift break continue".split()),
    "sql": set("select from where and or not insert update delete create table alter drop join left right inner outer on group by order having limit offset values into set as null is like in distinct union all case when then else end primary key foreign references".split()),
}

ALIASES = {
    "py": "python", "python": "python", "python3": "python",
    "go": "go", "golang": "go",
    "js": "javascript", "javascript": "javascript", "jsx": "javascript",
    "ts": "typescript", "tsx": "typescript", "typescript": "typescript",
    "java": "java", "c": "c", "cpp": "cpp", "c++": "cpp", "cc": "cpp",
    "rs": "rust", "rust": "rust", "rb": "ruby", "ruby": "ruby",
    "sh": "bash", "bash": "bash", "shell": "bash", "zsh": "bash",
    "sql": "sql", "json": "json", "html": "html", "xml": "xml",
    "css": "css", "yaml": "yaml", "yml": "yaml", "markdown": "markdown",
    "md": "markdown", "diff": "diff", "text": "plaintext", "plain": "plaintext",
    "plaintext": "plaintext", "no-highlight": "plaintext",
}

EXTS = {
    ".py": "python", ".go": "go", ".js": "javascript", ".mjs": "javascript",
    ".cjs": "javascript", ".ts": "typescript", ".tsx": "typescript",
    ".java": "java", ".c": "c", ".h": "c", ".cpp": "cpp", ".cc": "cpp",
    ".cxx": "cpp", ".hpp": "cpp", ".hh": "cpp", ".rs": "rust", ".rb": "ruby",
    ".sh": "bash", ".bash": "bash", ".zsh": "bash", ".sql": "sql",
    ".json": "json", ".html": "html", ".htm": "html", ".xml": "xml",
    ".css": "css", ".yaml": "yaml", ".yml": "yaml", ".md": "markdown",
    ".markdown": "markdown", ".diff": "diff", ".patch": "diff", ".txt": "plaintext",
}

HTML_CLASS = {
    "Text": "", "TextWhitespace": "w", "Keyword": "k", "KeywordDeclaration": "kd",
    "KeywordNamespace": "kn", "KeywordType": "kt", "Name": "n", "NameOther": "nx",
    "NameFunction": "nf", "NameBuiltin": "nb", "LiteralString": "s",
    "LiteralNumberInteger": "mi", "LiteralNumberFloat": "mf", "Operator": "o",
    "Punctuation": "p", "CommentSingle": "c1", "Comment": "c", "NameTag": "nt",
    "NameAttribute": "na", "GenericInserted": "gi", "GenericDeleted": "gd",
    "GenericSubheading": "gu",
}

ANSI = {
    "Text": "\033[1m\033[37m", "TextWhitespace": "\033[1m\033[37m",
    "Keyword": "\033[1m\033[36m", "KeywordDeclaration": "\033[1m\033[36m",
    "KeywordNamespace": "\033[1m\033[31m", "KeywordType": "\033[1m\033[36m",
    "Name": "\033[1m\033[37m", "NameOther": "\033[1m\033[33m",
    "NameFunction": "\033[1m\033[33m", "NameBuiltin": "\033[1m\033[37m",
    "LiteralString": "\033[37m", "LiteralNumberInteger": "\033[33m",
    "LiteralNumberFloat": "\033[33m", "Operator": "\033[1m\033[31m",
    "Punctuation": "\033[1m\033[37m", "CommentSingle": "\033[1m\033[30m",
    "Comment": "\033[1m\033[30m", "NameTag": "\033[1m\033[31m",
    "NameAttribute": "\033[1m\033[33m", "GenericInserted": "\033[1m\033[32m",
    "GenericDeleted": "\033[1m\033[31m", "GenericSubheading": "\033[1m\033[36m",
}
RESET = "\033[0m"

TOKEN_RE = re.compile(r"\s+|//[^\n]*|#[^\n]*|/\*.*?\*/|\"(?:\\.|[^\"\\])*\"|'(?:\\.|[^'\\])*'|`(?:\\.|[^`\\])*`|\d+\.\d+|\d+|[A-Za-z_][A-Za-z0-9_]*|==|!=|<=|>=|&&|\|\||[-+*/%=<>!&|^~.;,()[\]{}?:]", re.S)


def normalize_lexer(name):
    if not name or name == "autodetect":
        return "autodetect"
    return ALIASES.get(name.lower(), None)


def detect_lexer(filename, text, requested):
    if requested and requested != "autodetect":
        return normalize_lexer(requested)
    if filename:
        base = os.path.basename(filename)
        if base in ("Makefile", "Dockerfile"):
            return "bash"
        ext = os.path.splitext(filename)[1].lower()
        if ext in EXTS:
            return EXTS[ext]
    s = text.lstrip()
    if s.startswith("#!"):
        first = s.splitlines()[0]
        if "python" in first:
            return "python"
        if "bash" in first or "sh" in first:
            return "bash"
    if s.startswith("<"):
        return "html" if re.search(r"</?[A-Za-z][^>]*>", s[:200]) else "xml"
    if s.startswith("{") or s.startswith("["):
        return "json"
    return "plaintext"


def token(ttype, value):
    return {"type": ttype, "value": value}


def lex_plain(text):
    return [token("TextWhitespace" if v.isspace() else "Text", v) for v in re.findall(r"\s+|\S+", text)]


def lex_code(text, lang):
    kws = KEYWORDS.get(lang, set())
    out = []
    prev_sig = None
    for m in TOKEN_RE.finditer(text):
        v = m.group(0)
        if v.isspace():
            out.append(token("TextWhitespace", v))
            continue
        if v.startswith("//") or v.startswith("#") or v.startswith("/*"):
            if lang in ("python", "bash", "ruby") and v.startswith("#") or v.startswith("//") or v.startswith("/*"):
                out.append(token("CommentSingle", v))
            else:
                out.append(token("Text", v))
            prev_sig = "comment"
            continue
        if v[0] in "\"'`":
            out.append(token("LiteralString", v))
        elif re.fullmatch(r"\d+\.\d+", v):
            out.append(token("LiteralNumberFloat", v))
        elif v.isdigit():
            out.append(token("LiteralNumberInteger", v))
        elif re.fullmatch(r"[A-Za-z_][A-Za-z0-9_]*", v):
            low = v if lang != "sql" else v.lower()
            if low in kws:
                t = "Keyword"
                if lang == "go" and low in ("func", "var", "const", "type"):
                    t = "KeywordDeclaration"
                if lang == "go" and low in ("package", "import"):
                    t = "KeywordNamespace"
                if lang in ("c", "cpp", "java", "rust", "typescript") and low in ("int", "char", "float", "double", "void", "bool", "boolean", "string", "str", "usize", "i32", "u32"):
                    t = "KeywordType"
                out.append(token(t, v))
            elif prev_sig in ("def", "func", "function", "fn") or (lang == "go" and prev_sig == "func"):
                out.append(token("NameFunction", v))
            elif v in ("print", "println", "len", "range", "str", "int", "float", "console", "fmt"):
                out.append(token("NameBuiltin", v))
            else:
                out.append(token("NameOther" if lang == "go" else "Name", v))
        elif re.fullmatch(r"[-+*/%=<>!&|^~]+", v):
            out.append(token("Operator", v))
        else:
            out.append(token("Punctuation", v))
        if re.fullmatch(r"[A-Za-z_][A-Za-z0-9_]*", v):
            prev_sig = v if v in ("def", "func", "function", "fn") else None
        elif not v.isspace():
            prev_sig = None
    return out


def lex_markup(text, lang):
    out = []
    pos = 0
    for m in re.finditer(r"<!--.*?-->|</?[A-Za-z0-9:_-]+|[A-Za-z_:][-A-Za-z0-9_:.]*(?=\=)|\"[^\"]*\"|'[^']*'|[<>/=]", text, re.S):
        if m.start() > pos:
            out.extend(lex_plain(text[pos:m.start()]))
        v = m.group(0)
        if v.startswith("<!--"):
            out.append(token("Comment", v))
        elif v.startswith("<"):
            if len(v) > 1 and v[-1] not in ">/":
                out.append(token("Punctuation", v[0:1]))
                out.append(token("NameTag", v[1:]))
            else:
                out.append(token("Punctuation", v))
        elif v in "<>/=":
            out.append(token("Punctuation", v))
        elif v[0] in "\"'":
            out.append(token("LiteralString", v))
        else:
            out.append(token("NameAttribute", v))
        pos = m.end()
    if pos < len(text):
        out.extend(lex_plain(text[pos:]))
    return out


def lex_json(text):
    out = []
    for v in re.findall(r"\s+|\"(?:\\.|[^\"\\])*\"|-?\d+\.\d+|-?\d+|true|false|null|[{}\[\]:,]", text):
        if v.isspace():
            out.append(token("TextWhitespace", v))
        elif v[0] == '"':
            out.append(token("LiteralString", v))
        elif re.match(r"-?\d+\.\d+$", v):
            out.append(token("LiteralNumberFloat", v))
        elif re.match(r"-?\d+$", v):
            out.append(token("LiteralNumberInteger", v))
        elif v in ("true", "false", "null"):
            out.append(token("KeywordConstant", v))
        else:
            out.append(token("Punctuation", v))
    return out


def lex_diff(text):
    out = []
    for line in text.splitlines(True):
        if line.startswith("+") and not line.startswith("+++"):
            out.append(token("GenericInserted", line))
        elif line.startswith("-") and not line.startswith("---"):
            out.append(token("GenericDeleted", line))
        elif line.startswith("@@"):
            out.append(token("GenericSubheading", line))
        else:
            out.append(token("Text", line))
    return out


def lex(text, lang):
    if lang in ("html", "xml"):
        return lex_markup(text, lang)
    if lang == "json":
        return lex_json(text)
    if lang == "diff":
        return lex_diff(text)
    if lang == "plaintext" or lang is None:
        return lex_plain(text)
    return coalesce(lex_code(text, lang))


def coalesce(tokens):
    out = []
    for t in tokens:
        if out and out[-1]["type"] == t["type"] == "Punctuation":
            out[-1]["value"] += t["value"]
        else:
            out.append(t)
    return out


def html_escape_value(v):
    return html.escape(v, quote=True).replace('"', "&#34;")


def css():
    return """/* Background */ .bg { color: #f8f8f2; background-color: #272822; }
/* PreWrapper */ .chroma { color: #f8f8f2; background-color: #272822; -webkit-text-size-adjust: none; }
/* Error */ .chroma .err { color: #960050; background-color: #1e0010 }
/* Line */ .chroma .line { display: flex; }
/* Keyword */ .chroma .k { color: #66d9ef }
/* KeywordDeclaration */ .chroma .kd { color: #66d9ef }
/* KeywordNamespace */ .chroma .kn { color: #f92672 }
/* KeywordType */ .chroma .kt { color: #66d9ef }
/* Name */ .chroma .n { color: #f8f8f2 }
/* NameOther */ .chroma .nx { color: #a6e22e }
/* NameFunction */ .chroma .nf { color: #a6e22e }
/* NameBuiltin */ .chroma .nb { color: #f8f8f2 }
/* NameAttribute */ .chroma .na { color: #a6e22e }
/* NameTag */ .chroma .nt { color: #f92672 }
/* LiteralString */ .chroma .s { color: #e6db74 }
/* LiteralNumberInteger */ .chroma .mi { color: #ae81ff }
/* LiteralNumberFloat */ .chroma .mf { color: #ae81ff }
/* Operator */ .chroma .o { color: #f92672 }
/* Comment */ .chroma .c { color: #75715e }
/* CommentSingle */ .chroma .c1 { color: #75715e }
/* GenericDeleted */ .chroma .gd { color: #f92672 }
/* GenericInserted */ .chroma .gi { color: #a6e22e }
/* GenericSubheading */ .chroma .gu { color: #75715e }
"""


def fmt_terminal(tokens):
    return "".join(ANSI.get(t["type"], ANSI["Text"]) + t["value"] + RESET for t in tokens)


def fmt_noop(tokens):
    return "".join(t["value"] for t in tokens)


def fmt_tokens(tokens):
    return "".join('&Token{%s, %s}\n' % (t["type"], json.dumps(t["value"])) for t in tokens)


def fmt_json(tokens):
    lines = ["["]
    for i, t in enumerate(tokens):
        comma = "," if i != len(tokens) - 1 else ""
        lines.append('  {"type":%s,"value":%s}%s' % (json.dumps(t["type"]), json.dumps(t["value"]), comma))
    lines.append("]")
    return "\n".join(lines) + "\n"


def html_tokens(tokens, inline=False):
    out = []
    for t in tokens:
        val = html_escape_value(t["value"])
        cls = HTML_CLASS.get(t["type"], "")
        if cls:
            if inline:
                out.append('<span style="%s">%s</span>' % (inline_style(t["type"]), val))
            else:
                out.append('<span class="%s">%s</span>' % (cls, val))
        else:
            out.append(val)
    return "".join(out)


def inline_style(ttype):
    colors = {
        "Keyword": "color:#66d9ef", "KeywordDeclaration": "color:#66d9ef",
        "KeywordNamespace": "color:#f92672", "KeywordType": "color:#66d9ef",
        "NameOther": "color:#a6e22e", "NameFunction": "color:#a6e22e",
        "NameTag": "color:#f92672", "NameAttribute": "color:#a6e22e",
        "LiteralString": "color:#e6db74", "LiteralNumberInteger": "color:#ae81ff",
        "LiteralNumberFloat": "color:#ae81ff", "Operator": "color:#f92672",
        "Comment": "color:#75715e", "CommentSingle": "color:#75715e",
        "GenericInserted": "color:#a6e22e", "GenericDeleted": "color:#f92672",
        "GenericSubheading": "color:#75715e",
    }
    return colors.get(ttype, "")


def split_line_tokens(tokens):
    lines = [[]]
    for t in tokens:
        parts = t["value"].splitlines(True)
        for p in parts:
            if p.endswith("\n"):
                lines[-1].append(token(t["type"], p[:-1] + "\n"))
                lines.append([])
            else:
                lines[-1].append(token(t["type"], p))
    if lines and not lines[-1]:
        lines.pop()
    return lines or [[]]


def fmt_html(tokens, args):
    if args.html_styles:
        return css()
    body = []
    base = args.html_base_line
    for i, line in enumerate(split_line_tokens(tokens), base):
        content = html_tokens(line, args.html_inline_styles)
        if args.html_lines:
            body.append('<span class="ln">%d</span>' % i)
        body.append('<span class="line"><span class="cl">%s</span></span>' % content)
    pre = '<pre class="chroma"><code>%s</code></pre>\n' % "".join(body)
    if args.html_prevent_surrounding_pre:
        pre = "".join(html_tokens(line, args.html_inline_styles) for line in split_line_tokens(tokens))
    if args.html_only:
        return pre
    return '<html>\n<style type="text/css">\n%sbody { color:#f8f8f2;background-color:#272822;; }\n</style><body class="bg">\n%s</body>\n</html>\n' % (css(), pre)


def fmt_svg(tokens):
    text = html.escape(fmt_noop(tokens))
    lines = text.splitlines() or [""]
    tspans = []
    for i, line in enumerate(lines, 1):
        tspans.append('<text x="0" y="%.1fem" xml:space="preserve">%s</text>' % (i * 1.2, line))
    return '<?xml version="1.0" encoding="UTF-8"?>\n<svg width="800px" height="%dpx" xmlns="http://www.w3.org/2000/svg"><rect width="100%%" height="100%%" fill="#272822"/><g font-family="monospace" font-size="14px" fill="#f8f8f2">%s</g></svg>\n' % (max(30, 20 * len(lines)), "".join(tspans))


def build_parser():
    p = argparse.ArgumentParser(add_help=False)
    p.add_argument("files", nargs="*")
    p.add_argument("-h", "--help", action="store_true")
    p.add_argument("--version", action="store_true")
    p.add_argument("--list", action="store_true")
    p.add_argument("--unbuffered", action="store_true")
    p.add_argument("--trace", action="store_true")
    p.add_argument("--check", action="store_true")
    p.add_argument("--filename")
    p.add_argument("--fail", action="store_true")
    p.add_argument("-l", "--lexer", default="autodetect")
    p.add_argument("-s", "--style", default="swapoff")
    p.add_argument("-f", "--formatter", default="terminal")
    p.add_argument("--json", action="store_true", dest="jsonflag")
    p.add_argument("--html", action="store_true", dest="htmlflag")
    p.add_argument("--svg", action="store_true", dest="svgflag")
    p.add_argument("--html-prefix", default="")
    p.add_argument("--html-styles", action="store_true")
    p.add_argument("--html-all-styles", action="store_true")
    p.add_argument("--html-only", action="store_true")
    p.add_argument("--html-inline-styles", action="store_true")
    p.add_argument("--html-tab-width", type=int, default=8)
    p.add_argument("--html-lines", action="store_true")
    p.add_argument("--html-lines-table", action="store_true")
    p.add_argument("--html-lines-style", default="")
    p.add_argument("--html-highlight", default="")
    p.add_argument("--html-highlight-style", default="")
    p.add_argument("--html-base-line", type=int, default=1)
    p.add_argument("--html-prevent-surrounding-pre", action="store_true")
    p.add_argument("--html-linkable-lines", action="store_true")
    return p


def error(msg, code=1):
    print("executable: error: " + msg, file=sys.stderr)
    return code


def read_inputs(files):
    if not files:
        return [(None, sys.stdin.read())]
    data = []
    for f in files:
        try:
            with open(f, "r", encoding="utf-8", errors="replace") as fh:
                data.append((f, fh.read()))
        except OSError as e:
            return e
    return data


def main(argv):
    if "--help" in argv or "-h" in argv:
        print(HELP, end="")
        return 0
    if "--list=styles" in argv or "--list=lexers" in argv:
        return error('--list: bool value must be true, 1, yes, false, 0 or no but got "%s"' % argv[[a.startswith("--list=") for a in argv].index(True)].split("=", 1)[1], 80)
    parser = build_parser()
    try:
        args = parser.parse_args(argv)
    except SystemExit:
        return 80
    if args.version:
        print("?-?-?")
        return 0
    if args.list:
        print(LEXER_LIST, end="")
        return 0
    if args.jsonflag:
        args.formatter = "json"
    if args.htmlflag:
        args.formatter = "html"
    if args.svgflag:
        args.formatter = "svg"
    if args.html_styles:
        sys.stdout.write(css())
        return 0
    if args.style == "swapoff":
        return error("open swapoff: no such file or directory")
    inputs = read_inputs(args.files)
    if isinstance(inputs, OSError):
        return error("[<files> ...]: %s" % inputs, 80)
    all_tokens = []
    for filename, text in inputs:
        lang = detect_lexer(args.filename or filename, text, args.lexer)
        if lang is None:
            if args.fail:
                return 1
            lang = "plaintext"
        if args.fail and lang == "plaintext" and (args.lexer and args.lexer not in ("autodetect", "plaintext", "text", "plain")):
            return 1
        all_tokens.extend(lex(text, lang))
    fmt = args.formatter
    if fmt == "terminal":
        sys.stdout.write(fmt_terminal(all_tokens))
    elif fmt == "html":
        sys.stdout.write(fmt_html(all_tokens, args))
    elif fmt == "json":
        sys.stdout.write(fmt_json(all_tokens))
    elif fmt == "tokens":
        sys.stdout.write(fmt_tokens(all_tokens))
    elif fmt == "noop":
        sys.stdout.write(fmt_noop(all_tokens))
    elif fmt == "svg":
        sys.stdout.write(fmt_svg(all_tokens))
    else:
        return error("could not find formatter %q" % fmt, 1)
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
