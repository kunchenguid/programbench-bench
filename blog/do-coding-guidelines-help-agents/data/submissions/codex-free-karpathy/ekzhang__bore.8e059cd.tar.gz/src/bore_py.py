#!/usr/bin/env python3
import os
import random
import socket
import sys
import threading
import time
import uuid

CONTROL_PORT = 7835
VERSION = "bore-cli 0.6.0"


def eprint(msg):
    print(msg, file=sys.stderr, flush=True)


def info(msg):
    eprint(msg)


def die(msg, code=1):
    eprint(msg)
    sys.exit(code)


def top_help():
    print("""A modern, simple TCP tunnel in Rust that exposes local ports to a remote server, bypassing standard NAT connection firewalls.

Usage: executable <COMMAND>

Commands:
  local   Starts a local proxy to the remote server
  server  Runs the remote proxy server
  help    Print this message or the help of the given subcommand(s)

Options:
  -h, --help     Print help
  -V, --version  Print version""")


def local_help():
    print("""Starts a local proxy to the remote server

Usage: executable local [OPTIONS] --to <TO> <LOCAL_PORT>

Arguments:
  <LOCAL_PORT>  The local port to expose [env: BORE_LOCAL_PORT=]

Options:
  -l, --local-host <HOST>  The local host to expose [default: localhost]
  -t, --to <TO>            Address of the remote server to expose local ports to [env: BORE_SERVER=]
  -p, --port <PORT>        Optional port on the remote server to select [default: 0]
  -s, --secret <SECRET>    Optional secret for authentication [env: BORE_SECRET]
  -h, --help               Print help""")


def server_help():
    print("""Runs the remote proxy server

Usage: executable server [OPTIONS]

Options:
      --min-port <MIN_PORT>          Minimum accepted TCP port number [env: BORE_MIN_PORT=] [default: 1024]
      --max-port <MAX_PORT>          Maximum accepted TCP port number [env: BORE_MAX_PORT=] [default: 65535]
  -s, --secret <SECRET>              Optional secret for authentication [env: BORE_SECRET]
      --bind-addr <BIND_ADDR>        IP address to bind to, clients must reach this [default: 0.0.0.0]
      --bind-tunnels <BIND_TUNNELS>  IP address where tunnels will listen on, defaults to --bind-addr
  -h, --help                         Print help""")


def parse_int(value, name):
    try:
        n = int(value)
    except Exception:
        die(f"error: invalid value '{value}' for '{name}': invalid digit found in string")
    if n < 0 or n > 65535:
        die(f"error: invalid value '{value}' for '{name}': port must be in 0..=65535")
    return n


def parse_opts(argv, specs):
    opts = {}
    pos = []
    i = 0
    while i < len(argv):
        a = argv[i]
        if a == "--":
            pos.extend(argv[i + 1:])
            break
        if a.startswith("--"):
            if "=" in a:
                key, value = a.split("=", 1)
            else:
                key, value = a, None
            if key not in specs:
                die(f"error: unexpected argument '{a}' found")
            if value is None and i + 1 >= len(argv):
                die(f"error: a value is required for '{a} <{specs[key].upper()}>' but none was supplied")
            opts[specs[key]] = value if value is not None else argv[i + 1]
            i += 1 if value is not None else 2
        elif a.startswith("-") and a != "-":
            if a not in specs:
                die(f"error: unexpected argument '{a}' found")
            if i + 1 >= len(argv):
                die(f"error: a value is required for '{a} <{specs[a].upper()}>' but none was supplied")
            opts[specs[a]] = argv[i + 1]
            i += 2
        else:
            pos.append(a)
            i += 1
    return opts, pos


def recvall_line(f):
    line = f.readline()
    if not line:
        return None
    return line.decode("utf-8", "replace").rstrip("\n")


def send_line(sock, line):
    sock.sendall((line + "\n").encode())


def pipe_one(src, dst):
    try:
        while True:
            data = src.recv(65536)
            if not data:
                break
            dst.sendall(data)
    except OSError:
        pass
    finally:
        try:
            dst.shutdown(socket.SHUT_WR)
        except OSError:
            pass


def bidir(a, b):
    t1 = threading.Thread(target=pipe_one, args=(a, b), daemon=True)
    t2 = threading.Thread(target=pipe_one, args=(b, a), daemon=True)
    t1.start()
    t2.start()
    t1.join()
    t2.join()
    for s in (a, b):
        try:
            s.close()
        except OSError:
            pass


class TunnelServer:
    def __init__(self, min_port, max_port, secret, bind_addr, bind_tunnels):
        self.min_port = min_port
        self.max_port = max_port
        self.secret = secret or ""
        self.bind_addr = bind_addr
        self.bind_tunnels = bind_tunnels or bind_addr
        self.pending = {}
        self.pending_lock = threading.Lock()

    def run(self):
        srv = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        srv.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        srv.bind((self.bind_addr, CONTROL_PORT))
        srv.listen(128)
        info(f"server listening addr={self.bind_addr}")
        while True:
            conn, addr = srv.accept()
            threading.Thread(target=self.handle_control, args=(conn, addr), daemon=True).start()

    def handle_control(self, conn, addr):
        f = conn.makefile("rb")
        first = recvall_line(f)
        if first is None:
            conn.close()
            return
        parts = first.split(" ", 3)
        if parts[0] == "DATA" and len(parts) >= 2:
            cid = parts[1]
            with self.pending_lock:
                ent = self.pending.get(cid)
                if ent:
                    ent["data"] = conn
                    ent["event"].set()
                else:
                    conn.close()
            return
        if parts[0] != "HELLO" or len(parts) < 3:
            conn.close()
            return
        try:
            requested = int(parts[1])
        except ValueError:
            send_line(conn, "ERR invalid port")
            conn.close()
            return
        got_secret = parts[2] if len(parts) >= 3 else ""
        if self.secret and got_secret != self.secret:
            send_line(conn, "ERR authentication failed")
            conn.close()
            return
        if requested and (requested < self.min_port or requested > self.max_port):
            send_line(conn, "ERR requested port outside allowed range")
            conn.close()
            return
        try:
            listener = self.bind_tunnel_listener(requested)
        except OSError as ex:
            send_line(conn, f"ERR {ex}")
            conn.close()
            return
        port = listener.getsockname()[1]
        send_line(conn, f"OK {port}")
        info(f"new client host={self.bind_tunnels} port={port}")
        try:
            while True:
                remote, raddr = listener.accept()
                cid = str(uuid.uuid4())
                event = threading.Event()
                with self.pending_lock:
                    self.pending[cid] = {"event": event, "data": None}
                try:
                    send_line(conn, f"CONN {cid}")
                except OSError:
                    remote.close()
                    break
                info(f"new connection addr={raddr[0]}:{raddr[1]} port={port}")
                threading.Thread(target=self.finish_proxy, args=(cid, remote), daemon=True).start()
        finally:
            listener.close()
            conn.close()

    def bind_tunnel_listener(self, requested):
        ports = [requested]
        if requested == 0:
            population = list(range(self.min_port, self.max_port + 1))
            random.shuffle(population)
            ports = population
        last_error = None
        for port in ports:
            listener = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            listener.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            try:
                listener.bind((self.bind_tunnels, port))
                listener.listen(128)
                return listener
            except OSError as ex:
                last_error = ex
                listener.close()
        if last_error is not None:
            raise last_error
        raise OSError("no ports available")

    def finish_proxy(self, cid, remote):
        ent = None
        with self.pending_lock:
            ent = self.pending.get(cid)
        if not ent or not ent["event"].wait(10):
            remote.close()
            with self.pending_lock:
                self.pending.pop(cid, None)
            return
        with self.pending_lock:
            data = self.pending.pop(cid, {}).get("data")
        if data is None:
            remote.close()
            return
        bidir(remote, data)


def run_server(argv):
    if "-h" in argv or "--help" in argv:
        server_help()
        return
    specs = {
        "--min-port": "min_port",
        "--max-port": "max_port",
        "-s": "secret",
        "--secret": "secret",
        "--bind-addr": "bind_addr",
        "--bind-tunnels": "bind_tunnels",
    }
    opts, pos = parse_opts(argv, specs)
    if pos:
        die(f"error: unexpected argument '{pos[0]}' found")
    min_port = parse_int(opts.get("min_port", os.getenv("BORE_MIN_PORT", "1024")), "--min-port <MIN_PORT>")
    max_port = parse_int(opts.get("max_port", os.getenv("BORE_MAX_PORT", "65535")), "--max-port <MAX_PORT>")
    if min_port > max_port:
        die("error: min port cannot be greater than max port")
    secret = opts.get("secret", os.getenv("BORE_SECRET", ""))
    bind_addr = opts.get("bind_addr", "0.0.0.0")
    bind_tunnels = opts.get("bind_tunnels", bind_addr)
    TunnelServer(min_port, max_port, secret, bind_addr, bind_tunnels).run()


def run_local(argv):
    if "-h" in argv or "--help" in argv:
        local_help()
        return
    specs = {
        "-l": "local_host",
        "--local-host": "local_host",
        "-t": "to",
        "--to": "to",
        "-p": "port",
        "--port": "port",
        "-s": "secret",
        "--secret": "secret",
    }
    opts, pos = parse_opts(argv, specs)
    local_port_s = pos[0] if pos else os.getenv("BORE_LOCAL_PORT")
    to = opts.get("to", os.getenv("BORE_SERVER"))
    if not to or not local_port_s:
        die("""error: the following required arguments were not provided:
  --to <TO>
  <LOCAL_PORT>

Usage: executable local --to <TO> <LOCAL_PORT>

For more information, try '--help'.""")
    if len(pos) > 1:
        die(f"error: unexpected argument '{pos[1]}' found")
    local_port = parse_int(local_port_s, "<LOCAL_PORT>")
    remote_port = parse_int(opts.get("port", "0"), "--port <PORT>")
    local_host = opts.get("local_host", "localhost")
    secret = opts.get("secret", os.getenv("BORE_SECRET", ""))
    control = socket.create_connection((to, CONTROL_PORT))
    send_line(control, f"HELLO {remote_port} {secret}")
    f = control.makefile("rb")
    resp = recvall_line(f)
    if not resp:
        die("error: server closed connection")
    if not resp.startswith("OK "):
        die(resp[4:] if resp.startswith("ERR ") else resp)
    assigned = int(resp.split()[1])
    info(f"connected to server remote_port={assigned}")
    info(f"listening at {to}:{assigned}")
    while True:
        line = recvall_line(f)
        if line is None:
            die("control connection closed")
        parts = line.split()
        if len(parts) == 2 and parts[0] == "CONN":
            cid = parts[1]
            threading.Thread(target=local_proxy, args=(to, cid, local_host, local_port), daemon=True).start()


def local_proxy(to, cid, local_host, local_port):
    try:
        upstream = socket.create_connection((local_host, local_port))
        data = socket.create_connection((to, CONTROL_PORT))
        send_line(data, f"DATA {cid}")
        info("new connection")
        bidir(upstream, data)
        info("connection exited")
    except OSError as ex:
        eprint(f"error: {ex}")


def main(argv):
    if not argv or argv[0] in ("-h", "--help", "help"):
        if len(argv) >= 2 and argv[0] == "help" and argv[1] == "local":
            local_help()
        elif len(argv) >= 2 and argv[0] == "help" and argv[1] == "server":
            server_help()
        else:
            top_help()
        return
    if argv[0] in ("-V", "--version"):
        print(VERSION)
        return
    cmd = argv[0]
    if cmd == "local":
        run_local(argv[1:])
    elif cmd == "server":
        run_server(argv[1:])
    else:
        die(f"""error: unrecognized subcommand '{cmd}'

Usage: executable <COMMAND>

For more information, try '--help'.""")


if __name__ == "__main__":
    try:
        main(sys.argv[1:])
    except KeyboardInterrupt:
        pass
