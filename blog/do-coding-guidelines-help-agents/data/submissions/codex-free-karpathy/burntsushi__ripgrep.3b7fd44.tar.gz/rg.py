#!/usr/bin/env python3
import base64
import fnmatch
import json
import os
import re
import stat
import sys
import time

VERSION = """ripgrep 14.1.1 (rev 719e15af5e)

features:-pcre2
simd(compile):+SSE2,-SSSE3,-AVX2
simd(runtime):+SSE2,+SSSE3,+AVX2"""

SHORT_HELP = """ripgrep 14.1.1 (rev 719e15af5e)
Andrew Gallant <jamslam@gmail.com>

ripgrep (rg) recursively searches the current directory for lines matching
a regex pattern. By default, ripgrep will respect gitignore rules and
automatically skip hidden files/directories and binary files.

Use -h for short descriptions and --help for more details.

Project home page: https://github.com/BurntSushi/ripgrep

USAGE:
  rg [OPTIONS] PATTERN [PATH ...]

POSITIONAL ARGUMENTS:
  <PATTERN>   A regular expression used for searching.
  <PATH>...   A file or directory to search.

INPUT OPTIONS:
  -e, --regexp=PATTERN            A pattern to search for.
  -f, --file=PATTERNFILE          Search for patterns from the given file.

SEARCH OPTIONS:
  -F, --fixed-strings             Treat all patterns as literals.
  -i, --ignore-case               Case insensitive search.
  -v, --invert-match              Invert matching.
  -x, --line-regexp               Show matches surrounded by line boundaries.
  -S, --smart-case                Smart case search.
  -a, --text                      Search binary files as if they were text.
  -w, --word-regexp               Show matches surrounded by word boundaries.

FILTER OPTIONS:
  -L, --follow                    Follow symbolic links.
  -g, --glob=GLOB                 Include or exclude file paths.
  -., --hidden                    Search hidden files and directories.
  -d, --max-depth=NUM             Descend at most NUM directories.
  --no-ignore                     Don't use ignore files.
  -t, --type=TYPE                 Only search files matching TYPE.
  -T, --type-not=TYPE             Do not search files matching TYPE.
  -u, --unrestricted              Reduce the level of "smart" filtering.

OUTPUT OPTIONS:
  -A, --after-context=NUM         Show NUM lines after each match.
  -B, --before-context=NUM        Show NUM lines before each match.
  -b, --byte-offset               Print the byte offset for each matching line.
  --column                        Show column numbers.
  -C, --context=NUM               Show NUM lines before and after each match.
  --heading                       Print matches grouped by each file.
  --include-zero                  Include zero matches in summary output.
  -n, --line-number               Show line numbers.
  -N, --no-line-number            Suppress line numbers.
  -0, --null                      Print a NUL byte after file paths.
  -o, --only-matching             Print only matched parts of a line.
  --passthru                      Print both matching and non-matching lines.
  -q, --quiet                     Do not print anything to stdout.
  -r, --replace=TEXT              Replace matches with the given text.
  --sort=SORTBY                   Sort results in ascending order.
  --trim                          Trim prefix whitespace from matches.
  --vimgrep                       Print results in a vim compatible format.
  -H, --with-filename             Print the file path with each matching line.
  -I, --no-filename               Never print the path with each matching line.

OUTPUT MODES:
  -c, --count                     Show count of matching lines for each file.
  --count-matches                 Show count of every match for each file.
  -l, --files-with-matches        Print the paths with at least one match.
  --files-without-match           Print the paths that contain zero matches.
  --json                          Show search results in a JSON Lines format.

OTHER BEHAVIORS:
  --files                         Print each file that would be searched.
  --pcre2-version                 Print the version of PCRE2 that ripgrep uses.
  --type-list                     Show all supported file types.
  -V, --version                   Print ripgrep's version."""

TYPE_GLOBS = {
    "c": ["*.[chH]", "*.[chH].in"],
    "cpp": ["*.[ChH]", "*.[ch]pp", "*.[ch]xx", "*.cc", "*.hh", "*.hpp", "*.inl"],
    "py": ["*.py", "*.pyw"],
    "python": ["*.py", "*.pyw"],
    "rs": ["*.rs"],
    "rust": ["*.rs"],
    "go": ["*.go"],
    "js": ["*.js", "*.jsx", "*.mjs", "*.cjs"],
    "javascript": ["*.js", "*.jsx", "*.mjs", "*.cjs"],
    "ts": ["*.ts", "*.tsx"],
    "typescript": ["*.ts", "*.tsx"],
    "java": ["*.java"],
    "json": ["*.json"],
    "md": ["*.md", "*.markdown"],
    "markdown": ["*.md", "*.markdown"],
    "toml": ["*.toml", "Cargo.lock"],
    "yaml": ["*.yaml", "*.yml"],
    "html": ["*.htm", "*.html"],
    "css": ["*.css", "*.scss"],
    "sh": ["*.sh", "*.bash", "*.zsh"],
    "shell": ["*.sh", "*.bash", "*.zsh"],
    "txt": ["*.txt"],
    "make": ["Makefile", "makefile", "*.mk"],
}


class Opt:
    def __init__(self):
        self.patterns = []
        self.pattern_files = []
        self.paths = []
        self.fixed = False
        self.ignore_case = False
        self.smart_case = False
        self.invert = False
        self.line_regexp = False
        self.word = False
        self.text = False
        self.hidden = False
        self.follow = False
        self.no_ignore = False
        self.unrestricted = 0
        self.globs = []
        self.types = []
        self.type_nots = []
        self.max_depth = None
        self.files = False
        self.type_list = False
        self.count = False
        self.count_matches = False
        self.files_with_matches = False
        self.files_without_match = False
        self.json = False
        self.quiet = False
        self.line_number = False
        self.no_line_number = False
        self.with_filename = None
        self.only_matching = False
        self.column = False
        self.byte_offset = False
        self.vimgrep = False
        self.null = False
        self.after = 0
        self.before = 0
        self.context = False
        self.heading = False
        self.passthru = False
        self.include_zero = False
        self.replace = None
        self.sort = None
        self.sortr = None
        self.trim = False
        self.max_count = None
        self.stats = False
        self.max_columns = 0
        self.max_columns_preview = False
        self.path_separator = None
        self.multiline = False
        self.null_data = False


def die(msg, code=2):
    sys.stderr.write(f"rg: {msg}\n")
    sys.exit(code)


def take_value(args, i, arg, name):
    if "=" in arg and arg.startswith("--"):
        return arg.split("=", 1)[1], i
    if i + 1 >= len(args):
        die(f"argument required for {name}")
    return args[i + 1], i + 1


def parse_args(argv):
    opt = Opt()
    positional = []
    after_dd = False
    i = 0
    while i < len(argv):
        a = argv[i]
        if after_dd:
            positional.append(a); i += 1; continue
        if a == "--":
            after_dd = True; i += 1; continue
        if a in ("-h", "--help"):
            print(SHORT_HELP); sys.exit(0)
        if a in ("-V", "--version"):
            print(VERSION); sys.exit(0)
        if a == "--pcre2-version":
            print("PCRE2 is not available in this build of ripgrep.", file=sys.stderr); sys.exit(2)
        if a in ("-P", "--pcre2") or a.startswith("--engine=pcre2") or a == "--engine" and i + 1 < len(argv) and argv[i+1] == "pcre2":
            print("PCRE2 is not available in this build of ripgrep.", file=sys.stderr); sys.exit(2)
        if a == "--type-list":
            opt.type_list = True; i += 1; continue
        if a == "--files":
            opt.files = True; i += 1; continue
        if a.startswith("--"):
            name = a.split("=", 1)[0]
            if name in ("--regexp",):
                v, i = take_value(argv, i, a, name); opt.patterns.append(v)
            elif name in ("--file",):
                v, i = take_value(argv, i, a, name); opt.pattern_files.append(v)
            elif name in ("--glob", "--iglob"):
                v, i = take_value(argv, i, a, name); opt.globs.append(v)
            elif name == "--type":
                v, i = take_value(argv, i, a, name); opt.types.append(v)
            elif name == "--type-not":
                v, i = take_value(argv, i, a, name); opt.type_nots.append(v)
            elif name == "--type-add":
                v, i = take_value(argv, i, a, name)
                if ":" in v:
                    tname, glob = v.split(":", 1)
                    TYPE_GLOBS.setdefault(tname, []).append(glob)
            elif name == "--type-clear":
                v, i = take_value(argv, i, a, name)
                TYPE_GLOBS[v] = []
            elif name == "--max-depth":
                v, i = take_value(argv, i, a, name); opt.max_depth = int(v)
            elif name == "--max-count":
                v, i = take_value(argv, i, a, name); opt.max_count = int(v)
            elif name in ("--after-context", "--before-context", "--context"):
                v, i = take_value(argv, i, a, name)
                if name == "--after-context": opt.after = int(v)
                elif name == "--before-context": opt.before = int(v)
                else: opt.after = opt.before = int(v); opt.context = True
            elif name == "--replace":
                v, i = take_value(argv, i, a, name); opt.replace = v
            elif name == "--sort":
                v, i = take_value(argv, i, a, name); opt.sort = v
            elif name == "--sortr":
                v, i = take_value(argv, i, a, name); opt.sortr = v
            elif name == "--max-columns":
                v, i = take_value(argv, i, a, name); opt.max_columns = int(v)
            elif name == "--path-separator":
                v, i = take_value(argv, i, a, name); opt.path_separator = v or None
            elif name in ("--fixed-strings", "--fixed-string"): opt.fixed = True
            elif name == "--ignore-case": opt.ignore_case = True
            elif name == "--case-sensitive": opt.ignore_case = False; opt.smart_case = False
            elif name == "--smart-case": opt.smart_case = True
            elif name == "--invert-match": opt.invert = True
            elif name == "--line-regexp": opt.line_regexp = True
            elif name == "--word-regexp": opt.word = True
            elif name in ("--text", "--binary"): opt.text = True
            elif name == "--hidden": opt.hidden = True
            elif name == "--follow": opt.follow = True
            elif name.startswith("--no-ignore"): opt.no_ignore = True
            elif name == "--count": opt.count = True
            elif name == "--count-matches": opt.count_matches = True
            elif name == "--files-with-matches": opt.files_with_matches = True
            elif name == "--files-without-match": opt.files_without_match = True
            elif name == "--json": opt.json = True
            elif name == "--quiet": opt.quiet = True
            elif name == "--line-number": opt.line_number = True
            elif name == "--no-line-number": opt.no_line_number = True
            elif name == "--with-filename": opt.with_filename = True
            elif name == "--no-filename": opt.with_filename = False
            elif name == "--only-matching": opt.only_matching = True
            elif name == "--column": opt.column = True
            elif name == "--byte-offset": opt.byte_offset = True
            elif name == "--vimgrep": opt.vimgrep = True; opt.line_number = True; opt.column = True; opt.with_filename = True
            elif name == "--null": opt.null = True
            elif name == "--heading": opt.heading = True
            elif name in ("--passthru", "--passthrough"): opt.passthru = True
            elif name == "--include-zero": opt.include_zero = True
            elif name == "--trim": opt.trim = True
            elif name == "--stats": opt.stats = True
            elif name == "--max-columns-preview": opt.max_columns_preview = True
            elif name == "--multiline": opt.multiline = True
            elif name == "--null-data": opt.null_data = True; opt.text = True
            elif name.startswith("--no-") or name in ("--engine", "--color", "--colors", "--threads", "--encoding", "--dfa-size-limit", "--regex-size-limit", "--mmap", "--crlf", "--pre", "--pre-glob", "--search-zip", "--block-buffered", "--line-buffered", "--debug", "--trace", "--no-config", "--generate", "--hostname-bin", "--hyperlink-format", "--field-match-separator", "--field-context-separator", "--context-separator", "--glob-case-insensitive", "--ignore-file", "--ignore-file-case-insensitive", "--max-filesize", "--one-file-system", "--auto-hybrid-regex", "--no-pcre2-unicode", "--sort-files"):
                if name in ("--color", "--colors", "--threads", "--encoding", "--dfa-size-limit", "--regex-size-limit", "--pre", "--pre-glob", "--generate", "--hostname-bin", "--hyperlink-format", "--field-match-separator", "--field-context-separator", "--context-separator", "--ignore-file", "--max-filesize", "--engine"):
                    if "=" not in a:
                        i += 1
            else:
                die(f"unrecognized flag {a}")
            i += 1; continue
        if a.startswith("-") and a != "-":
            j = 1
            while j < len(a):
                c = a[j]
                rest = a[j+1:]
                if c in "efgTtdmABCMr":
                    v = rest
                    if not v:
                        if i + 1 >= len(argv): die(f"argument required for -{c}")
                        i += 1; v = argv[i]
                    if c == "e": opt.patterns.append(v)
                    elif c == "f": opt.pattern_files.append(v)
                    elif c == "g": opt.globs.append(v)
                    elif c == "t": opt.types.append(v)
                    elif c == "T": opt.type_nots.append(v)
                    elif c == "d": opt.max_depth = int(v)
                    elif c == "m": opt.max_count = int(v)
                    elif c == "A": opt.after = int(v)
                    elif c == "B": opt.before = int(v)
                    elif c == "C": opt.after = opt.before = int(v); opt.context = True
                    elif c == "M": opt.max_columns = int(v)
                    elif c == "r": opt.replace = v
                    break
                elif c == "F": opt.fixed = True
                elif c == "i": opt.ignore_case = True
                elif c == "s": opt.ignore_case = False; opt.smart_case = False
                elif c == "S": opt.smart_case = True
                elif c == "v": opt.invert = True
                elif c == "x": opt.line_regexp = True
                elif c == "w": opt.word = True
                elif c == "a": opt.text = True
                elif c == ".": opt.hidden = True
                elif c == "L": opt.follow = True
                elif c == "u": opt.unrestricted += 1
                elif c == "c": opt.count = True
                elif c == "l": opt.files_with_matches = True
                elif c == "q": opt.quiet = True
                elif c == "n": opt.line_number = True
                elif c == "N": opt.no_line_number = True
                elif c == "H": opt.with_filename = True
                elif c == "I": opt.with_filename = False
                elif c == "o": opt.only_matching = True
                elif c == "b": opt.byte_offset = True
                elif c == "0": opt.null = True
                elif c == "p": opt.heading = True; opt.line_number = True
                elif c == "U": opt.multiline = True
                elif c == "z": pass
                else: die(f"unrecognized flag -{c}")
                j += 1
            i += 1; continue
        positional.append(a); i += 1
    if opt.unrestricted >= 1: opt.no_ignore = True
    if opt.unrestricted >= 2: opt.hidden = True
    if opt.unrestricted >= 3: opt.text = True
    if not opt.patterns and not opt.pattern_files and not opt.files and not opt.type_list:
        if positional:
            opt.patterns.append(positional.pop(0))
        else:
            die("requires at least one pattern to execute a search")
    use_stdin = False
    try:
        mode = os.fstat(0).st_mode
        use_stdin = stat.S_ISFIFO(mode) or stat.S_ISREG(mode)
    except OSError:
        pass
    opt.paths = (positional or ["-"]) if (not opt.files and not positional and use_stdin and opt.patterns) else positional
    if not opt.paths:
        opt.paths = ["."]
    return opt


def print_type_list():
    for k in sorted(TYPE_GLOBS):
        print(f"{k}: {', '.join(TYPE_GLOBS[k])}")


def load_patterns(opt):
    pats = list(opt.patterns)
    for pf in opt.pattern_files:
        data = sys.stdin.read().splitlines() if pf == "-" else open(pf, "r", errors="replace").read().splitlines()
        pats.extend(data)
    if not pats:
        pats = [""]
    if opt.fixed:
        pats = [re.escape(p) for p in pats]
    if opt.word:
        pats = [r"(?<!\w)(?:" + p + r")(?!\w)" for p in pats]
    if opt.line_regexp:
        pats = [r"^(?:" + p + r")$" for p in pats]
    flags = re.MULTILINE
    if opt.smart_case and not any(any(ch.isupper() for ch in p) for p in pats):
        flags |= re.IGNORECASE
    if opt.ignore_case:
        flags |= re.IGNORECASE
    if opt.multiline:
        flags |= re.DOTALL
    try:
        return re.compile("|".join(f"(?:{p})" for p in pats), flags)
    except re.error as e:
        sys.stderr.write(f"rg: regex parse error:\n    {pats[0]}\n    {e}\n")
        sys.exit(2)


def is_hidden(path, root=None):
    parts = path.split(os.sep)
    return any(p.startswith(".") and p not in (".", "..") for p in parts if p)


def read_ignore_file(path):
    out = []
    try:
        with open(path, "r", errors="replace") as f:
            for line in f:
                s = line.strip()
                if not s or s.startswith("#"): continue
                out.append(s)
    except OSError:
        pass
    return out


def ignored_by_patterns(rel, pats):
    ignored = False
    base = os.path.basename(rel)
    for p in pats:
        neg = p.startswith("!")
        if neg: p = p[1:]
        p = p.rstrip("/")
        matched = fnmatch.fnmatch(rel, p) or fnmatch.fnmatch(base, p)
        if "/" not in p:
            matched = matched or any(fnmatch.fnmatch(part, p) for part in rel.split(os.sep))
        if matched:
            ignored = not neg
    return ignored


def type_match(path, names):
    if not names: return True
    base = os.path.basename(path)
    for name in names:
        globs = TYPE_GLOBS.get(name, [])
        if any(fnmatch.fnmatch(base, g) for g in globs):
            return True
    return False


def glob_allowed(path, globs):
    if not globs: return True
    rel = path[2:] if path.startswith("./") else path
    state = None
    for g in globs:
        neg = g.startswith("!")
        pat = g[1:] if neg else g
        if fnmatch.fnmatch(rel, pat) or fnmatch.fnmatch(os.path.basename(rel), pat):
            state = not neg
    return True if state is None else state


def iter_files(paths, opt):
    files = []
    for p in paths:
        if p == "-":
            files.append("-"); continue
        if os.path.isfile(p) or (os.path.islink(p) and not os.path.isdir(p)):
            files.append(p); continue
        if not os.path.isdir(p):
            sys.stderr.write(f"{p}: No such file or directory (os error 2)\n")
            continue
        root0 = p
        base_ignore = [] if opt.no_ignore else read_ignore_file(os.path.join(root0, ".gitignore")) + read_ignore_file(os.path.join(root0, ".ignore")) + read_ignore_file(os.path.join(root0, ".rgignore"))
        for root, dirs, names in os.walk(p, followlinks=opt.follow):
            relroot = os.path.relpath(root, root0)
            depth = 0 if relroot == "." else relroot.count(os.sep) + 1
            if opt.max_depth is not None and depth >= opt.max_depth:
                dirs[:] = []
            keepdirs = []
            for d in dirs:
                full = os.path.join(root, d)
                rel = os.path.relpath(full, root0)
                if not opt.hidden and is_hidden(rel): continue
                if not opt.no_ignore and ignored_by_patterns(rel, base_ignore): continue
                keepdirs.append(d)
            dirs[:] = keepdirs
            for n in names:
                full = os.path.join(root, n)
                rel = os.path.relpath(full, root0)
                shown = full if p != "." else rel
                if not opt.hidden and is_hidden(rel): continue
                if not opt.no_ignore and ignored_by_patterns(rel, base_ignore): continue
                if not glob_allowed(shown, opt.globs): continue
                if opt.types and not type_match(shown, opt.types): continue
                if opt.type_nots and type_match(shown, opt.type_nots): continue
                files.append(shown)
    if opt.sort in ("path",) or opt.sort is not None:
        files.sort()
    if opt.sortr is not None:
        files.sort(reverse=True)
    return files


def read_file(path, opt):
    if path == "-":
        b = sys.stdin.buffer.read()
    else:
        try:
            with open(path, "rb") as f: b = f.read()
        except OSError as e:
            sys.stderr.write(f"{path}: {e.strerror} (os error {e.errno})\n"); return None
    if not opt.text and b"\x00" in b:
        return None
    return b


def data_obj(b):
    try:
        return {"text": b.decode("utf-8")}
    except UnicodeDecodeError:
        return {"bytes": base64.b64encode(b).decode("ascii")}


def path_display(p, opt):
    if p == "-": return "<stdin>"
    if opt.path_separator and opt.path_separator != os.sep:
        return p.replace(os.sep, opt.path_separator)
    return p


def split_lines(b, opt):
    sep = b"\x00" if opt.null_data else b"\n"
    parts = b.splitlines(True) if sep == b"\n" else [x + sep for x in b.split(sep)[:-1]] + ([b.split(sep)[-1]] if b.split(sep)[-1] else [])
    if b and (not parts or not parts[-1]):
        return parts
    return parts


def prefix(path, lno, col, off, opt, many):
    fields = []
    show_file = opt.with_filename if opt.with_filename is not None else many
    if show_file:
        fields.append(path_display(path, opt))
    if opt.line_number or opt.vimgrep:
        fields.append(str(lno))
    if opt.column or opt.vimgrep:
        fields.append(str(col))
    if opt.byte_offset:
        fields.append(str(off))
    return (":".join(fields) + ":") if fields else ""


def replacement_to_py(rep):
    if rep is None: return None
    s = rep.replace("$$", "\0")
    s = re.sub(r"\$\{(\d+)\}", r"\\\1", s)
    s = re.sub(r"\$(\d+)", r"\\\1", s)
    return s.replace("\0", "$")


def search_file(path, data, rx, opt, many, json_started):
    text = data.decode("utf-8", errors="replace")
    lines = text.splitlines(True)
    matched_lines = 0
    total_matches = 0
    any_match = False
    out_lines = []
    before_buf = []
    after_left = 0
    byte_base = 0
    line_limit_hit = False
    pyrep = replacement_to_py(opt.replace)
    for idx, line in enumerate(lines, 1):
        rawline = line[:-1] if line.endswith("\n") else line
        scanline = rawline[:-1] if rawline.endswith("\r") else rawline
        matches = list(rx.finditer(scanline))
        is_match = bool(matches)
        if opt.invert: is_match = not is_match
        if opt.passthru: printable = True
        else: printable = is_match
        if is_match:
            any_match = True; matched_lines += 1
            total_matches += max(1, len(matches))
        if opt.max_count is not None and matched_lines > opt.max_count:
            line_limit_hit = True; break
        if opt.quiet and any_match:
            return True, matched_lines, total_matches, json_started
        if opt.json and is_match:
            if not json_started:
                print(json.dumps({"type":"begin","data":{"path":data_obj(path_display(path,opt).encode())}}, separators=(",",":")))
                json_started = True
            submatches = [{"match":data_obj(m.group(0).encode()),"start":m.start(),"end":m.end()} for m in matches]
            print(json.dumps({"type":"match","data":{"path":data_obj(path_display(path,opt).encode()),"lines":data_obj(line.encode()),"line_number":idx,"absolute_offset":byte_base,"submatches":submatches}}, separators=(",",":")))
        elif printable and not (opt.count or opt.count_matches or opt.files_with_matches or opt.files_without_match):
            if opt.before and is_match:
                for blno, boff, bline in before_buf:
                    out_lines.append(prefix(path, blno, 1, boff, opt, many) + bline.rstrip("\n"))
                before_buf = []
            if opt.only_matching and matches and not opt.invert:
                for m in matches:
                    s = m.group(0)
                    if pyrep is not None: s = m.expand(pyrep)
                    out_lines.append(prefix(path, idx, m.start()+1, byte_base + len(scanline[:m.start()].encode()), opt, many) + s)
                    if opt.vimgrep is False:
                        pass
            elif opt.vimgrep and matches and not opt.invert:
                for m in matches:
                    s = scanline
                    if pyrep is not None: s = rx.sub(pyrep, scanline)
                    out_lines.append(prefix(path, idx, m.start()+1, byte_base + len(scanline[:m.start()].encode()), opt, many) + s)
            else:
                s = scanline
                if opt.trim: s = s.lstrip(" \t\r\n\v\f")
                if pyrep is not None and matches and not opt.invert: s = rx.sub(pyrep, s)
                if opt.max_columns and len(s.encode()) > opt.max_columns:
                    if opt.max_columns_preview:
                        s = s[:opt.max_columns]
                    else:
                        s = f"[Omitted long matching line]"
                out_lines.append(prefix(path, idx, 1, byte_base, opt, many) + s)
            if is_match and opt.after:
                after_left = opt.after
        elif after_left and not is_match:
            out_lines.append(prefix(path, idx, 1, byte_base, opt, many) + scanline)
            after_left -= 1
        if opt.before:
            before_buf.append((idx, byte_base, scanline))
            if len(before_buf) > opt.before: before_buf.pop(0)
        byte_base += len(line.encode())
    if opt.count or opt.count_matches:
        n = total_matches if (opt.count_matches or opt.only_matching) else matched_lines
        if n or opt.include_zero:
            if many or opt.with_filename:
                out_lines.append(f"{path_display(path,opt)}:{n}")
            else:
                out_lines.append(str(n))
    elif opt.files_with_matches and any_match:
        out_lines.append(path_display(path, opt) + ("\0" if opt.null else ""))
    elif opt.files_without_match and not any_match:
        out_lines.append(path_display(path, opt) + ("\0" if opt.null else ""))
    if out_lines and not opt.quiet:
        if opt.heading and many and not (opt.count or opt.count_matches or opt.files_with_matches or opt.files_without_match):
            print(path_display(path, opt))
            stripped = []
            for l in out_lines:
                pd = path_display(path, opt) + ":"
                stripped.append(l[len(pd):] if l.startswith(pd) else l)
            out_lines = stripped
        end = "" if (opt.null and (opt.files or opt.files_with_matches or opt.files_without_match)) else "\n"
        sys.stdout.write("\n".join(out_lines) + end)
    status_match = (not any_match) if opt.files_without_match else any_match
    return status_match, matched_lines, total_matches, json_started


def main(argv):
    start = time.time()
    opt = parse_args(argv)
    if opt.type_list:
        print_type_list(); return 0
    rx = None if opt.files else load_patterns(opt)
    files = iter_files(opt.paths, opt)
    if opt.files:
        sep = "\0" if opt.null else "\n"
        sys.stdout.write(sep.join(path_display(f, opt) for f in files if f != "-"))
        if files: sys.stdout.write(sep)
        return 0
    many = (sum(1 for f in files if f != "-") > 1) or any(os.path.isdir(p) for p in opt.paths if p != "-")
    found = False
    searched = 0
    matched_total = 0
    json_started = False
    for f in files:
        data = read_file(f, opt)
        if data is None: continue
        searched += 1
        any_match, ml, tm, json_started = search_file(f, data, rx, opt, many, json_started)
        if any_match: found = True
        matched_total += ml
        if opt.quiet and found: return 0
    if opt.json:
        print(json.dumps({"type":"summary","data":{"elapsed_total":{"human":f"{time.time()-start:.6f}s","nanos":int((time.time()-start)*1e9),"secs":time.time()-start},"stats":{"bytes_searched":0,"bytes_printed":0,"matched_lines":matched_total,"matches":matched_total,"searches":searched,"searches_with_match":0}}}, separators=(",",":")))
    if opt.stats and not opt.json:
        print(f"\n{matched_total} matched lines")
        print(f"{searched} files searched")
        print(f"{time.time()-start:.6f} seconds")
    return 0 if found else 1


if __name__ == "__main__":
    try:
        sys.exit(main(sys.argv[1:]))
    except BrokenPipeError:
        try:
            sys.stdout.close()
        finally:
            sys.exit(0)
