module cleanroom-gdu

go 1.20
